"""Helper for ``ask_followup_question`` — owns the user-facing Panel
render, the blocking input call, the per-turn call cap, hook firing, and
telemetry.

Sits behind the tool handler so the handler stays small and the I/O
machinery is isolated for testing (the handler-level tests in
``test_ask_followup.py`` monkeypatch ``_get_prompt_fn`` and
``_get_console_fn`` so no real stdin/stdout is touched).

The dispatch flow leans on the same window the y/n/a/d Permission Panel
uses (`fred/permissions.py:627-643`): by the time
``Registry.dispatch`` reaches the handler, the ``rich.Live`` region from
``Renderer.assistant_turn`` has already exited (the ``with`` context
manager closes its Live block before the per-call dispatch loop runs in
``session._run_loop``). Stdin is uncontested at this moment, so an
inline blocking ``Prompt.ask`` is safe.
"""
from __future__ import annotations

import contextvars
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.text import Text


# Cap on `ask_followup_question` calls per turn. The model is told it
# may call up to this many times; after that the helper returns an
# error string instead of pausing again. Prevents the model from
# hammering the user with clarifications instead of making reasonable
# assumptions and proceeding.
_MAX_CALLS_PER_TURN = 2


@dataclass
class AskFollowupContext:
    """Per-turn state injected by ``session._run_loop`` before dispatch.

    ``yolo`` mirrors ``PermissionPolicy.yolo``; in yolo mode the tool
    returns an error string instead of pausing for input (yolo runs are
    uninterruptible by contract).

    ``hooks_config`` is the loaded HookConfig; the helper fires
    ``UserPromptSubmit`` after capturing the user's answer so existing
    pre-submit hooks (lint, security scrubs) still run.

    ``tracer`` and ``turn`` are passed through for telemetry attribution
    (events land on the same turn row as the dispatched tool call).

    ``calls_this_turn`` is mutated by the helper; the cap-per-turn check
    reads and increments it.
    """

    yolo: bool = False
    hooks_config: Any = None
    tracer: Any = None
    turn: Any = None
    console: Console | None = None
    calls_this_turn: int = 0


_ASK_FOLLOWUP_CTX: contextvars.ContextVar[AskFollowupContext | None] = (
    contextvars.ContextVar("_ASK_FOLLOWUP_CTX", default=None)
)


def set_ask_followup_context(ctx: AskFollowupContext) -> contextvars.Token:
    return _ASK_FOLLOWUP_CTX.set(ctx)


def reset_ask_followup_context(token: contextvars.Token) -> None:
    _ASK_FOLLOWUP_CTX.reset(token)


def get_ask_followup_context() -> AskFollowupContext | None:
    return _ASK_FOLLOWUP_CTX.get()


# --- indirection seams for tests -----------------------------------------

# Tests monkeypatch these to avoid touching real stdin / a real Console.
# Same pattern ``test_permissions.py`` uses to swap ``Prompt.ask``.

def _get_prompt_fn() -> Callable[..., str]:
    return Prompt.ask


def _get_default_console() -> Console:
    # Defensive fallback when the dispatch context didn't supply one.
    # Production paths set ``ctx.console`` from the Renderer's console
    # in session._run_loop, so this branch is mostly for direct
    # handler-level tests.
    return Console()


# --- main entry ----------------------------------------------------------


@dataclass
class AskAnswer:
    """Structured result of one prompt cycle."""

    text: str
    kind: str  # "option_picked" | "free_text" | "yolo_rejected" | "subagent_rejected" | "cap_exceeded"
    option_index: int | None = None
    wait_ms: int = 0


def prompt_user(
    question: str,
    options: list[str] | None,
) -> AskAnswer:
    """Render the question Panel and capture the user's answer.

    Returns an :class:`AskAnswer` regardless of outcome; the caller
    formats the string surface for the model. ``KeyboardInterrupt`` and
    ``EOFError`` propagate so the existing ``session._run_loop`` arm at
    ``session.py:728-738`` can abort the turn cleanly.
    """
    ctx = get_ask_followup_context()
    if ctx is None:
        # No dispatch context — running outside a session loop (handler
        # tests, REPL inspection). Fall back to a minimal best-effort
        # path so the tool still functions without crashing.
        ctx = AskFollowupContext()

    # Yolo: refuse to pause for input. Returning an error string lets
    # the model self-correct ("make best guess and proceed") instead of
    # blocking the autonomous run.
    if ctx.yolo:
        return AskAnswer(
            text=(
                "Error: yolo mode is on; cannot pause for user input. "
                "Make your best guess from existing context and proceed. "
                "Do not call ask_followup_question again this turn."
            ),
            kind="yolo_rejected",
        )

    # Cap per turn. Strictly enforced — the third call returns an error.
    if ctx.calls_this_turn >= _MAX_CALLS_PER_TURN:
        return AskAnswer(
            text=(
                f"Error: ask_followup_question called too many times this "
                f"turn ({_MAX_CALLS_PER_TURN} max). Make your best guess "
                "and proceed."
            ),
            kind="cap_exceeded",
        )
    ctx.calls_this_turn += 1

    console = ctx.console or _get_default_console()
    _render_question_panel(console, question, options)

    t0 = time.perf_counter()
    try:
        answer_text, kind, option_index = _collect_answer(console, options)
    except (KeyboardInterrupt, EOFError):
        # Propagate so session._run_loop's KeyboardInterrupt arm handles
        # it. We DO emit a telemetry event for the abort.
        if ctx.tracer is not None:
            try:
                ctx.tracer.event(
                    "ask_followup",
                    payload={
                        "question_chars": len(question),
                        "option_count": len(options or []),
                        "answer_kind": "aborted",
                        "answer_chars": 0,
                        "answer_index_if_option": None,
                        "wait_ms": int((time.perf_counter() - t0) * 1000),
                        "calls_this_turn": ctx.calls_this_turn,
                    },
                    turn=ctx.turn,
                )
            except Exception:
                pass
        raise
    wait_ms = int((time.perf_counter() - t0) * 1000)

    # Fire UserPromptSubmit hook so existing pre-submit hooks (lint,
    # security) still apply. A blocked answer surfaces back to the
    # model as a structured Error string the model can recover from.
    blocked_msg = _maybe_run_user_prompt_submit(ctx, answer_text)
    if blocked_msg is not None:
        if ctx.tracer is not None:
            try:
                ctx.tracer.event(
                    "ask_followup",
                    payload={
                        "question_chars": len(question),
                        "option_count": len(options or []),
                        "answer_kind": "hook_blocked",
                        "answer_chars": len(answer_text),
                        "answer_index_if_option": option_index,
                        "wait_ms": wait_ms,
                        "calls_this_turn": ctx.calls_this_turn,
                    },
                    turn=ctx.turn,
                )
            except Exception:
                pass
        return AskAnswer(
            text=f"Error: answer rejected by UserPromptSubmit hook: {blocked_msg}",
            kind="hook_blocked",
            option_index=option_index,
            wait_ms=wait_ms,
        )

    if ctx.tracer is not None:
        try:
            ctx.tracer.event(
                "ask_followup",
                payload={
                    "question_chars": len(question),
                    "option_count": len(options or []),
                    "answer_kind": kind,
                    "answer_chars": len(answer_text),
                    "answer_index_if_option": option_index,
                    "wait_ms": wait_ms,
                    "calls_this_turn": ctx.calls_this_turn,
                },
                turn=ctx.turn,
            )
        except Exception:
            pass

    return AskAnswer(
        text=answer_text, kind=kind, option_index=option_index, wait_ms=wait_ms,
    )


# --- internal helpers ----------------------------------------------------


def _render_question_panel(
    console: Console, question: str, options: list[str] | None,
) -> None:
    body = Text(question, no_wrap=False)
    if options:
        body.append("\n\n")
        for i, opt in enumerate(options, start=1):
            display = opt if len(opt) <= 80 else opt[:77] + "…"
            body.append(f"{i}. {display}\n")
        body.append(
            f"\npick 1-{len(options)} or type a free-form answer",
            style="dim",
        )
    else:
        body.append("\n\n")
        body.append("type your answer", style="dim")
    console.print(Panel(
        body,
        title="[yellow]?[/] [bold]Question[/]",
        title_align="left",
        border_style="yellow",
        expand=False,
    ))


def _collect_answer(
    console: Console, options: list[str] | None,
) -> tuple[str, str, int | None]:
    """Loop until the user enters a non-empty answer. Returns
    ``(text, kind, option_index)`` where ``kind`` is ``"option_picked"``
    or ``"free_text"`` and ``option_index`` is 1-based when an option
    was picked, else None.

    Numeric input matching a valid option index is classified as
    ``option_picked``; free-text exactly matching an option string is
    also classified as ``option_picked`` (mirrors Cline's behavior).
    Empty input re-prompts.
    """
    prompt_fn = _get_prompt_fn()
    while True:
        raw = prompt_fn(
            "›",
            console=console,
            default="",
            show_default=False,
        )
        text = (raw or "").strip()
        if not text:
            console.print(
                "[dim]empty answer; type something or Ctrl-C to abort[/]"
            )
            continue
        if options:
            if text.isdigit():
                idx = int(text)
                if 1 <= idx <= len(options):
                    chosen = options[idx - 1]
                    return chosen, "option_picked", idx
            for i, opt in enumerate(options, start=1):
                if text == opt:
                    return opt, "option_picked", i
        return text, "free_text", None


def _maybe_run_user_prompt_submit(
    ctx: AskFollowupContext, answer: str,
) -> str | None:
    """Fire the UserPromptSubmit hook; return the blocking command's
    string (truncated) when blocked, else None.

    The helper is best-effort: any exception in the hook runner falls
    through as 'not blocked' so a misconfigured hook doesn't strand the
    user mid-turn. That mirrors the cli.py REPL path.
    """
    if ctx.hooks_config is None:
        return None
    try:
        from fred.hooks import run_hooks  # local import to avoid cycle
    except Exception:
        return None
    try:
        outcome = run_hooks(
            "UserPromptSubmit",
            ctx.hooks_config,
            user_input=answer,
        )
    except Exception:
        return None
    # The hook runner returns a structured outcome dict; conventions vary
    # across the codebase, so we accept either shape ("blocked": True /
    # "block_reason": "..."). Defensive: any unrecognized outcome is
    # treated as not-blocked.
    if isinstance(outcome, dict):
        if outcome.get("blocked"):
            cmd = outcome.get("blocking_command") or outcome.get("block_reason") or "<unknown>"
            return str(cmd)[:200]
    return None
