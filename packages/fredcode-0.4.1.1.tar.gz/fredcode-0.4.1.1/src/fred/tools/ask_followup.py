"""ask_followup_question tool — bounded clarification.

Model-callable: when the model needs a piece of information from the
user that can't be defended by reasonable assumption, it calls
``ask_followup_question(question, options=[...])``. The session loop's
dispatch helper renders a yellow Panel, blocks on the user's input
(stdin is uncontested at dispatch time — the rich.Live region exited
when assistant_turn finished streaming), and returns the answer as the
tool result string for the next iteration.

Heavy lifting lives in ``fred.tools._ask_prompt`` so the handler stays
small and the I/O machinery is isolated for testing.

The tool is excluded from sub-agent registry subsets (parent-only — see
``fred.tools.agent_tool._PARENT_ONLY_TOOLS``); a sub-agent that emits it
gets the standard ``unknown_tool`` error from the registry, which the
parent then sees as a sub-agent failure.

Yolo mode short-circuits with an error string ("make best guess and
proceed") instead of pausing for input — yolo runs are uninterruptible
by contract, the opposite of how the y/n/a/d Permission Panel treats
yolo (which bypasses by *granting*; here "granting" would mean blocking
on stdin, which violates the contract).
"""
from __future__ import annotations

from pydantic import BaseModel, Field, field_validator

from fred.tools._ask_prompt import prompt_user
from fred.tools.base import Tool


_MAX_OPTIONS = 5
_MAX_OPTION_LEN = 200


class AskFollowupArgs(BaseModel):
    question: str = Field(
        ...,
        min_length=1,
        max_length=1000,
        description=(
            "The clarifying question to put to the user. Be terse and "
            "specific — the user is in the middle of work and reading the "
            "minimum that gets you unblocked."
        ),
    )
    options: list[str] | None = Field(
        default=None,
        max_length=_MAX_OPTIONS,
        description=(
            "Optional list of up to 5 multiple-choice answer strings. The "
            "user can pick by number or type a free-form answer. If you "
            "have no clear options, omit this field."
        ),
    )

    @field_validator("options")
    @classmethod
    def _normalize_options(cls, v: list[str] | None) -> list[str] | None:
        if v is None:
            return None
        # Empty list normalizes to None so the prompt path is symmetric.
        if len(v) == 0:
            return None
        cleaned: list[str] = []
        for opt in v:
            opt = opt.strip()
            if not opt:
                raise ValueError("option strings must be non-empty")
            if len(opt) > _MAX_OPTION_LEN:
                raise ValueError(
                    f"option strings must be ≤ {_MAX_OPTION_LEN} chars; got "
                    f"{len(opt)}"
                )
            cleaned.append(opt)
        return cleaned


def run(args: AskFollowupArgs) -> str:
    """Pause the session, prompt the user, return the answer.

    The string format is ``<answer>{text}</answer>`` so the model can
    parse the boundary unambiguously when the answer text contains
    incidental whitespace or quotes. Error returns (yolo, cap, hook
    block) start with ``Error:`` so the model can branch on the prefix.
    """
    answer = prompt_user(args.question, args.options)
    if answer.kind in ("yolo_rejected", "cap_exceeded", "hook_blocked"):
        # Pre-formatted error message from the helper; pass through.
        return answer.text
    return f"<answer>{answer.text}</answer>"


tool = Tool(
    name="ask_followup_question",
    description=(
        "Pause for a bounded clarification from the user. Use ONLY when "
        "the next action would otherwise be a coin flip with destructive "
        "consequences (e.g. branching on which of two files to edit, or "
        "whether to delete vs. rename). For recoverable choices, prefer "
        "making a reasonable assumption, stating it inline, and proceeding. "
        "Pass `options` (≤5) for multiple-choice; omit for free-form. "
        "Capped at 2 calls per turn; not available to sub-agents."
    ),
    args_model=AskFollowupArgs,
    handler=run,
    requires_permission=False,
)
