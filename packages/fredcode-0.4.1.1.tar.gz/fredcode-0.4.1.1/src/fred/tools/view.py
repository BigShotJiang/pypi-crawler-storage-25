"""view tool: read a file with line numbers, or list a directory."""
from __future__ import annotations

import os
from pathlib import Path

from pydantic import BaseModel, Field

from fred.tools._session_files import mark_tracked
from fred.tools.base import Tool, truncate

MAX_LINES_DEFAULT = 2000


class ViewArgs(BaseModel):
    path: str = Field(..., description="Absolute or relative path to a file or directory.")
    start_line: int | None = Field(None, ge=1, description="1-indexed first line to show.")
    end_line: int | None = Field(None, ge=1, description="1-indexed last line to show (inclusive).")


def _is_binary(p: Path) -> bool:
    try:
        with p.open("rb") as f:
            chunk = f.read(1024)
        return b"\x00" in chunk
    except OSError:
        return False


def _list_dir(p: Path) -> str:
    entries = []
    try:
        for child in sorted(p.iterdir(), key=lambda c: (not c.is_dir(), c.name.lower())):
            kind = "dir " if child.is_dir() else "file"
            try:
                size = child.stat().st_size if child.is_file() else 0
            except OSError:
                size = 0
            entries.append(f"  {kind}  {child.name}{'  (' + str(size) + 'B)' if child.is_file() else ''}")
    except PermissionError as e:
        return f"Error: {e}"
    return f"Directory: {p}\n" + "\n".join(entries) if entries else f"Directory: {p}\n  (empty)"


def run(args: ViewArgs) -> str:
    p = Path(args.path).expanduser()
    if not p.exists():
        return f"Error: path does not exist: {p}"
    if p.is_dir():
        return _list_dir(p)
    if _is_binary(p):
        return f"Error: refusing to view binary file: {p}"
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        return f"Error: cannot read {p}: {e}"

    lines = text.splitlines()
    total = len(lines)
    start = max(1, args.start_line or 1)
    if args.end_line is not None:
        end = min(total, args.end_line)
    elif args.start_line is None:
        end = min(total, MAX_LINES_DEFAULT)
    else:
        end = total
    if start > total:
        return f"Error: start_line {start} exceeds file length ({total} lines)"

    selected = lines[start - 1 : end]
    body = "\n".join(f"{n:>5}\t{line}" for n, line in enumerate(selected, start=start))
    hint = ""
    if end < total:
        hint = f"\n[showing lines {start}-{end} of {total}; pass start_line/end_line for more]"
    # Mark this file as "the model has seen it this session" so a follow-up
    # `str_replace` is allowed (P1.4 prior-Read enforcement). Directory
    # listings and binary refusals don't count — the model hasn't seen the
    # actual contents in those cases.
    mark_tracked(p)
    return truncate(body + hint)


tool = Tool(
    name="view",
    description=(
        "Read a file with line numbers, or list a directory. For files, returns "
        "tab-separated `lineno<TAB>content`. Files >2000 lines are truncated unless "
        "start_line/end_line are provided. Refuses binary files. Use this BEFORE "
        "editing a file with str_replace."
    ),
    args_model=ViewArgs,
    handler=run,
    requires_permission=False,
)
