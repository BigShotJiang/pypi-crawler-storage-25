from importlib.metadata import PackageNotFoundError as _PackageNotFoundError
from importlib.metadata import version as _pkg_version

from fred._ssl import inject as _inject_ssl

_inject_ssl()

# Single source of truth: pyproject.toml's [project].version, surfaced
# via package metadata. Editable installs without metadata fall back to
# a sentinel so we never raise at import time.
try:
    __version__ = _pkg_version("fredcode")
except _PackageNotFoundError:  # pragma: no cover — editable/dev runtime
    __version__ = "0.0.0+dev"
