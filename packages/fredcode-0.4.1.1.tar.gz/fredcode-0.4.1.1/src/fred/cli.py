"""fred CLI: REPL by default, -p for one-shot."""
from __future__ import annotations

import json
import os
import re
import subprocess
import time
import uuid
from datetime import date
from pathlib import Path
from typing import Literal, Optional

import typer
from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.shortcuts import CompleteStyle
from rich.align import Align
from rich.console import Console, Group
from rich.panel import Panel
from rich.text import Text

from fred import __version__
from fred import auth as _auth
from fred.agent import run_turn
from fred.checkpoints import Checkpointer, prune_stale
from fred.client import DEFAULT_BASE_URL, DEFAULT_MODEL, DSClient
from fred.config import ModelConfig, get_api_key, load_model_config
from fred.context import compact_messages
from fred.hooks import VALID_EVENTS, list_hooks_for, load_hooks_config, run_hooks
from fred.input_parse import count_mentions, expand_bang, expand_mentions
from fred.mcp import (
    cleanup_servers as mcp_cleanup_servers,
    connect_servers as mcp_connect_servers,
    load_mcp_config,
    register_mcp_tools as mcp_register_tools,
    summarize_servers as mcp_summarize_servers,
)
from fred.mode import reset_mode_state, set_mode_state
from fred.permissions import (
    PermissionPolicy,
    add_rule as add_permission_rule,
    list_active_rules,
    normalize_approval_mode,
    remove_rule as remove_permission_rule,
)
from fred.plan_file import plan_file_path
from fred.render import Renderer
from fred.repomap import RepoMap
from fred.repomap.repo_map import build_repo_map_message
from fred.rules import RuleSet, env_disables_rules
from fred.slash_commands import SlashCommandCompleter
from fred.prompt_cache import PromptsUnavailableError
from fred.system_prompt import build as build_system_prompt
from fred.telemetry import make_tracer
from fred import update_check
from fred.tools._sandbox import (
    SandboxMode,
    current_sandbox_mode,
    normalize_mode as normalize_sandbox_mode,
    reset_sandbox_mode,
    set_sandbox_mode,
)
from fred.tools._session_files import reset_tracked_files, set_tracked_files
from fred.tools import bash_bg as _bash_bg
from fred.tools.registry import Registry, default_registry

Mode = Literal["act", "plan"]
OutputStyle = Literal["concise", "explanatory"]

app = typer.Typer(add_completion=False, help="fred — DeepSeek-powered agentic coding CLI")


def _build_initial_messages(
    mode: Mode = "act",
    *,
    output_style: OutputStyle = "concise",
) -> tuple[list[dict], "object"]:
    from fred.config import load_project_memory
    registry = default_registry()
    memory = load_project_memory()
    # Capture `today` once per REPL session / /clear so the system-prompt
    # bytes don't shift at midnight and break DeepSeek's prefix cache.
    today = date.today().isoformat()
    try:
        sys_prompt = build_system_prompt(
            registry, project_memory=memory, today=today, mode=mode,
            output_style=output_style,
        )
    except PromptsUnavailableError as e:
        # The wheel ships zero prompt text; the active prompts come from
        # FredWeb and are cached locally after `fred login`. If we got
        # here without a cache, exit cleanly rather than crashing the
        # user with a stack trace.
        print(f"fred: {e}", file=sys.stderr)
        raise typer.Exit(code=3) from None
    return [{"role": "system", "content": sys_prompt}], registry


SLASH_HELP = """\
Slash commands:
  /help                       show this help
  /clear                      reset conversation (keeps system prompt)
  /tools                      list registered tools
  /todos                      show current todo list
  /yolo                       toggle permission bypass
  /sandbox [mode|approval m]  show or set sandbox/approval mode (P4.1)
  /cost                       show running session cost
  /think on|off               toggle thinking display
  /think show                 reprint last turn's thinking
  /save [path]                dump transcript as JSONL
  /init                       generate AGENTS.md by scanning the repo
  /model                      show all four model slots (main/editor/weak/subagent_main)
  /model <name>               swap the main slot (backwards compat)
  /model <slot> <n>           swap one of main|editor|weak|subagent_main
  /flash                      collapse all four slots to deepseek-v4-flash
  /pro                        enable architect: main=pro, editor+weak+subagent_main=flash
  /last [n]                   reprint Nth-most-recent tool result (default 1)
  /repomap                    print the current rendered repo map (debug)
  /rules                      list active + available rules (.fred/rules/*.md)
  /hooks                      list active hooks per event (.fred/settings.json)
  /perms                      list active permission rules (allow/ask/deny)
  /perms add <rule> <list>    append rule to local file (list: allow|ask|deny)
  /perms remove <rule>        remove rule from any list in local file
  /mcp                        list connected MCP servers + their tool counts
  /subagents                  list subagent profiles + their tool subsets
  /mode plan|act|toggle       switch between plan and act mode (Shift+Tab cycles)
  /style concise|explanatory  flip output style for the next turn
  /compact [focus]            summarize older history (focus hint optional)
  /checkpoints                list recent shadow-git checkpoints (last 20)
  /restore <sha>              restore workspace to a checkpoint (with confirm)
  /telemetry                  show telemetry routing (default sends to fredcode.net)
  /telemetry on               clear opt-out (effective next session)
  /telemetry off              opt out of behavioral telemetry (effective next session)
  /exit                       quit
"""


# Multi-model routing slots. Single source of truth for the slot
# vocabulary used by `/model`, `tracer.event("model_routed", ...)`, and
# the banner formatter.
_MODEL_SLOTS = ("main", "editor", "weak", "subagent_main")


# Architect mode pairs a heavy main model with a cheap editor pass that
# reviews/repairs file-edit tool_calls. `/pro` enables the topology
# (main=pro, editor+weak+subagent_main=flash); the dispatch itself
# lives in `fred.editor_pass` and runs from `session.run_session`.
class _RunMode(str):
    NORMAL = "normal"
    ARCHITECT = "architect"


# Match @-prefixed paths the user may have referenced in their message.
# Mirrors the lighter pattern in input_parse so the cli can extract
# them for repo-map personalization without doing a full expansion.
_AT_MENTION_RE = re.compile(r"(?:^|\s)@([\w./\-]+)")


class _SessionState:
    """REPL-scoped state surfaced to the per-turn repo map provider.

    Tracks the files the agent has touched this session (via `view`,
    `str_replace`, etc.) and the @-mentions / identifiers from the
    most recent user input. Both feed the repo map's personalization
    vector so the model sees symbols related to where it's working.

    `plan_file_path` (P2.2) is the conventional scratchpad path the
    model can write to during plan mode. Always set; the file is only
    materialized if the model chooses to write to it.

    Kept deliberately small — anything more elaborate belongs in the
    `SessionState` dataclass that lands with P1.4.
    """

    def __init__(self) -> None:
        self.viewed_files: set[Path] = set()
        self.mentioned_files: set[Path] = set()
        self.mentioned_idents: set[str] = set()
        self.plan_file_path: Path | None = None

    def update_from_user_input(self, line: str) -> None:
        """Pull @-paths and naked identifiers out of `line` for next turn.

        We're conservative: identifiers must be at least 4 chars and
        contain a letter, so common words like "the" or "and" don't
        flood the personalization vector. Anything more sophisticated
        gets in the way of the simple "model said `Foo` -> show me Foo"
        signal we're after.
        """
        self.mentioned_files.clear()
        self.mentioned_idents.clear()
        for m in _AT_MENTION_RE.finditer(line):
            path = Path(m.group(1)).resolve() if m.group(1) else None
            if path is not None and path.exists():
                self.mentioned_files.add(path)
        # Pick out CamelCase / snake_case names as candidate idents.
        for tok in re.findall(r"[A-Za-z_][A-Za-z0-9_]{3,}", line):
            if any(c.isalpha() for c in tok):
                self.mentioned_idents.add(tok)


def _make_repo_map_provider(
    repo_map: RepoMap | None, state: _SessionState,
):
    """Build the zero-arg callable plumbed into `run_session`.

    Returns "" when `repo_map` is None (feature disabled, scan failed,
    etc.) — `run_session` treats empty as "skip injection." Catches
    exceptions broadly because the repo map must NOT take down a turn.
    """
    if repo_map is None:
        return None

    def provider() -> str:
        try:
            rendered = repo_map.get_repo_map(
                chat_files=set(),
                mentioned_idents=set(state.mentioned_idents),
                viewed_files=set(state.viewed_files),
                mentioned_files=set(state.mentioned_files),
            )
            return build_repo_map_message(rendered)
        except Exception:
            return ""

    return provider


def _git_status_short() -> str | None:
    """Return 'branch · N modified' or None if not a git repo / git missing."""
    try:
        branch = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=2,
        )
        if branch.returncode != 0:
            return None
        st = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, timeout=2,
        )
        modified = len([l for l in st.stdout.splitlines() if l.strip()])
        suffix = f" · {modified} modified" if modified else " · clean"
        return branch.stdout.strip() + suffix
    except (subprocess.SubprocessError, FileNotFoundError, OSError):
        return None


# ASCII rendition of the wolf logo from FredWeb's marketing site.
# Same silhouette: pointed ears, narrow squinting eyes, smiling muzzle.
# Drawn so a violet→fuchsia→amber gradient (matching the web hero) flows
# diagonally across the lines. Suppressed via NO_COLOR or FRED_NO_BANNER.
_WOLF_ART = (
    "    ╱╲     ╱╲    ",
    "   ╱  ╲___╱  ╲   ",
    "  │  ◜     ◝  │  ",
    "  │  ◕  ▽  ◕  │  ",
    "   ╲   \\─/   ╱   ",
    "    ╲___╲╱___╱   ",
)
_WOLF_GRADIENT = (
    "violet1",
    "magenta",
    "magenta1",
    "deep_pink2",
    "orange1",
    "yellow1",
)


def _wolf_renderable() -> Text:
    """Gradient-colored wolf art as a single Text block. Centered as a
    unit by ``Align.center`` at the call site so the relative alignment
    of each row is preserved (per-line centering would skew rows whose
    visible width differs due to wide Unicode glyphs)."""
    txt = Text()
    last = len(_WOLF_ART) - 1
    for i, (line, color) in enumerate(zip(_WOLF_ART, _WOLF_GRADIENT)):
        suffix = "\n" if i < last else ""
        txt.append(line + suffix, style=f"bold {color}")
    return txt


def _should_show_wolf(console: Console, *, width: int, height: int) -> bool:
    """Skip on NO_COLOR / FRED_NO_BANNER, when the console isn't a TTY,
    when the terminal is too narrow for the wolf to read, or too short
    to absorb 8+ extra rows without pushing content off-screen."""
    if os.environ.get("NO_COLOR") or os.environ.get("FRED_NO_BANNER"):
        return False
    if not console.is_terminal:
        return False
    if width < 60 or height < 24:
        return False
    return True


def _format_mcp_line(mcp_session) -> str | None:
    """One-line summary of connected MCP servers, or None when 0 connected.
    Truncates to first two names + `+N more` so the row stays single-line."""
    if mcp_session is None:
        return None
    try:
        rows = mcp_summarize_servers(mcp_session)
    except Exception:
        return None
    connected = [r for r in rows if r.get("status") == "connected"]
    if not connected:
        return None
    if len(connected) <= 2:
        return " · ".join(r["name"] for r in connected)
    visible = " · ".join(r["name"] for r in connected[:2])
    return f"{visible} · +{len(connected) - 2} more"


def _banner_update_status() -> str | None:
    """Return the latest PyPI version when an update is available; else None.
    Reads the existing update_check cache — never blocks on network."""
    try:
        from fred.update_check import _is_newer, _load_cache
    except ImportError:
        return None
    try:
        cache = _load_cache() or {}
    except Exception:
        return None
    latest = cache.get("latest")
    current_at_fetch = cache.get("current_at_fetch")
    if not isinstance(latest, str) or not isinstance(current_at_fetch, str):
        return None
    if current_at_fetch != __version__:
        return None
    try:
        if not _is_newer(latest, __version__):
            return None
    except Exception:
        return None
    return latest


def _format_model_line(model_cfg: ModelConfig) -> str:
    """Render the banner's `model:` value, expanding only when slots differ.

    When all four slots resolve to the same name we collapse to one
    label (`deepseek-v4-flash`) — the dominant case for users who haven't
    customized routing. When any slot diverges from main we tack on the
    differing ones so the banner makes the architect/editor topology
    visible:
      `deepseek-v4-pro (editor: …-flash, weak: …-flash, subagent_main: …-flash)`
    """
    main = model_cfg.main_model
    extras: list[str] = []
    if model_cfg.editor_model != main:
        extras.append(f"editor: {model_cfg.editor_model}")
    if model_cfg.weak_model != main:
        extras.append(f"weak: {model_cfg.weak_model}")
    if model_cfg.subagent_main_model != main:
        extras.append(f"subagent_main: {model_cfg.subagent_main_model}")
    if not extras:
        return main
    return f"{main} ({', '.join(extras)})"


def _render_no_credentials_panel(console: Console | None = None) -> None:
    """Print a friendly sign-in panel when the CLI runs without credentials.

    Replaces the previous bare typer.echo, which dumped a single-sentence
    error to stderr that buried the three real onramps. A first-time
    user shouldn't have to grep for `FRED_API_KEY` to figure out how to
    authenticate.

    Layout: command on its own line, indented description on the next.
    Two-line block per option scans cleanly at any terminal width and
    avoids the wrap-jaggies of inline `cmd → description`.
    """
    console = console or Console(stderr=True)
    body = Text()
    body.append("No credentials yet — pick the option that fits.\n\n", style="dim")
    body.append("fred login", style="bold cyan")
    body.append("\n  Browser flow. Fastest path. ")
    body.append("$1 in free credits on signup.\n\n", style="bold green")
    body.append("fred login --device-code", style="bold cyan")
    body.append("\n  Headless / SSH / containers without a browser.\n\n")
    body.append('export FRED_API_KEY="fred_live_…"', style="bold cyan")
    body.append("\n  CI scripts. Skip the login flow entirely.\n\n")
    body.append("Already paying DeepSeek directly? Set ", style="dim")
    body.append("DEEPSEEK_API_KEY", style="dim italic")
    body.append(" to bypass the proxy.", style="dim")
    console.print(
        Panel(
            body,
            title="[bold cyan]Sign in to Fred[/]",
            title_align="left",
            border_style="cyan",
            padding=(1, 2),
            expand=False,
        )
    )
    console.print(
        "[dim]docs · app.fredcode.net/docs/getting-started[/]",
        style="dim",
        highlight=False,
    )


def _render_banner(
    console: Console, model: str | ModelConfig, yolo: bool, registry: Registry,
    *, plan_mode: bool = False, output_style: OutputStyle = "concise",
    sandbox_mode: str | None = None, approval_mode: str | None = None,
    mcp_session=None,
) -> None:
    """Render the launch banner: a centered panel with the wolf logo at top
    and metadata rows below. The panel border + title color shift with
    state (yolo / plan / update-available / normal). Falls back to a
    one-line summary on very narrow terminals.

    `model` accepts either a string (legacy) or a `ModelConfig` (full
    four-slot routing). The wolf is suppressed via NO_COLOR or
    FRED_NO_BANNER, on non-TTY consoles, or when the terminal is too
    narrow / short to comfortably absorb ~8 extra rows.
    """
    if isinstance(model, ModelConfig):
        model_cfg = model
    else:
        model_cfg = ModelConfig(
            main_model=model,
            editor_model=model,
            weak_model=model,
            subagent_main_model=model,
        )

    cwd = str(Path.cwd())
    home = str(Path.home())
    if cwd.startswith(home):
        cwd = "~" + cwd[len(home):]
    git = _git_status_short()
    perm = "[red]YOLO[/]" if yolo else "ask-permission"
    mode_badge = "[red]PLAN[/]" if plan_mode else "[dim]act[/]"
    mcp_line = _format_mcp_line(mcp_session)
    update_latest = _banner_update_status()

    size = console.size
    width = size.width if size.width else 80
    height = size.height if size.height else 24

    # Very narrow terminals (tmux splits, phone shells): fall back to one
    # line. Substring assertions for "fred", model name, "ask-permission"
    # / "YOLO" still hold.
    if width < 40:
        perm_short = "[red]YOLO[/]" if yolo else "ask-permission"
        line = (
            f"[bold magenta]fred[/] {__version__} · "
            f"{_format_model_line(model_cfg)} · {perm_short}"
        )
        console.print(Text.from_markup(line))
        if update_latest:
            console.print(
                f"[dim orange1]↑ {update_latest} available[/]",
            )
        console.print(
            "[dim]/help for commands · @path to embed · "
            "!cmd for shell · /exit[/]"
        )
        return

    body = Text()

    def row(label: str, value: str) -> None:
        body.append(f"  {label:<8}", style="bold")
        # `value` may carry Rich markup like "[dim]act[/]" — interpret it.
        body.append_text(Text.from_markup(value))
        body.append("\n")

    row("model", _format_model_line(model_cfg))
    row("cwd", cwd)
    if git:
        row("branch", git)
    row("perm", f"{perm} · {len(registry.names())} tools")
    row("mode", mode_badge)
    if output_style != "concise":
        row("style", output_style)
    # Surface sandbox + approval only when non-default. Keeps the banner
    # identical for the dominant case (workspace-write + on_request).
    if sandbox_mode is not None and sandbox_mode != "workspace-write":
        row("sandbox", sandbox_mode)
    if approval_mode is not None and approval_mode != "on_request":
        if approval_mode == "never":
            row("approval", f"[red]{approval_mode}[/]")
        else:
            row("approval", approval_mode)
    if mcp_line:
        row("mcp", mcp_line)
    body.append(
        "\n  /help for commands · @path to embed · "
        "!cmd for shell · /exit",
        style="dim",
    )

    # Compose contents: wolf (centered as a block) above rows when room
    # allows. ``Align.center`` treats the multi-line wolf as one unit so
    # per-line alignment within the art is preserved.
    if _should_show_wolf(console, width=width, height=height):
        contents = Group(Align.center(_wolf_renderable()), Text(""), body)
    else:
        contents = body

    if update_latest:
        title = (
            f"[bold magenta]fred[/] {__version__} "
            f"[bold orange1]· ↑ {update_latest} available[/]"
        )
    else:
        title = (
            f"[bold magenta]fred[/] {__version__} "
            f"[green]· ✓ up to date[/]"
        )

    if yolo:
        border = "bold red"
    elif plan_mode:
        border = "bold yellow"
    elif update_latest:
        border = "bold orange1"
    else:
        border = "bold magenta"

    panel_width = min(72, max(40, width - 4))
    panel = Panel(
        contents,
        title=title,
        title_align="left",
        border_style=border,
        padding=(0, 1),
        width=panel_width,
    )
    console.print(Align.center(panel))


def _persist_model_prefs(model_cfg: ModelConfig) -> None:
    """Mirror the live ModelConfig into ~/.config/fred/preferences.json so
    `/model` mutations survive across CLI restarts. Called after every
    successful model change.

    Best-effort: a write failure logs but does not abort the slash command.
    """
    from fred.preferences import load_preferences, save_preferences

    prefs = load_preferences()
    prefs.main_model = model_cfg.main_model
    prefs.editor_model = model_cfg.editor_model
    prefs.weak_model = model_cfg.weak_model
    prefs.subagent_main_model = model_cfg.subagent_main_model
    prefs.preset = _infer_preset_label(model_cfg)
    save_preferences(prefs)


def _infer_preset_label(model_cfg: ModelConfig) -> str | None:
    """Tag the active topology with an audit label.

    Returns one of:
      - ``"flash"`` if every slot is `deepseek-v4-flash`.
      - ``"architect"`` if main is `deepseek-v4-pro` and editor / weak /
        subagent_main are all `deepseek-v4-flash` (the `/pro` shape).
      - ``"premium"`` if every slot is `deepseek-v4-pro`.
      - ``None`` otherwise (custom shape).

    The label is purely informational — the canonical truth is the
    per-slot field. `_format_model_line` continues to render from those
    fields directly.
    """
    main = model_cfg.main_model
    others = (
        model_cfg.editor_model,
        model_cfg.weak_model,
        model_cfg.subagent_main_model,
    )
    if main == "deepseek-v4-flash" and all(o == "deepseek-v4-flash" for o in others):
        return "flash"
    if main == "deepseek-v4-pro" and all(o == "deepseek-v4-flash" for o in others):
        return "architect"
    if main == "deepseek-v4-pro" and all(o == "deepseek-v4-pro" for o in others):
        return "premium"
    return None


def _confirm_pro_switch(console: Console) -> bool:
    """Prompt the user to confirm enabling architect mode. Returns True
    if confirmed (or skipped via FRED_NO_CONFIRM_PRO).

    `/pro` enables architect topology: main runs deepseek-v4-pro for
    reasoning, while editor / weak / subagent_main stay on flash for
    cheap auxiliary work. The editor pass adds ~one extra flash call
    per file-edit tool_call. The first time a user flips to it, we
    want them to see that fact and acknowledge it. The persistent flag
    in preferences.json silences subsequent prompts.
    """
    if os.environ.get("FRED_NO_CONFIRM_PRO"):
        return True
    from fred.preferences import load_preferences, save_preferences

    prefs = load_preferences()
    if prefs.warned_about_architect:
        return True
    console.print(
        "[yellow]Enabling architect mode.[/]\n"
        "  main           = deepseek-v4-pro    "
        "(~12× output cost vs flash)\n"
        "  editor         = deepseek-v4-flash  "
        "(one extra call per file-edit tool_call)\n"
        "  weak           = deepseek-v4-flash  (compaction)\n"
        "  subagent_main  = deepseek-v4-flash  (subagents)\n"
        "  Typical mixed-coding turn: ~$0.012 vs ~$0.007 on flash-only.\n"
        "  Set FRED_NO_CONFIRM_PRO=1 to silence this prompt for scripts."
    )
    try:
        answer = input("Continue? [Y/n] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        console.print("[dim]cancelled.[/]")
        return False
    if answer in ("", "y", "yes"):
        prefs.warned_about_architect = True
        save_preferences(prefs)
        return True
    console.print("[dim]cancelled.[/]")
    return False


def _telemetry_status_line() -> str:
    """Compose a one-line description of where telemetry is going right now."""
    import os

    from fred.auth import load_credentials
    from fred.preferences import load_preferences

    if os.environ.get("FRED_TELEMETRY_DB_URL"):
        return "self-hosted (FRED_TELEMETRY_DB_URL set)"
    prefs = load_preferences()
    if prefs.telemetry_opted_out:
        return "off (you have opted out)"
    if load_credentials() is None:
        return "off (not logged in — run `fred login`)"
    return "on → api.fredcode.net (default)"


def _maybe_show_first_run_notice(tracer, console: Console) -> None:
    """Print the one-time telemetry disclosure on first non-Null session.

    Idempotent: persisted via `telemetry_first_run_shown` in
    preferences.json. Quiet for opted-out users (NullTracer skips
    this) and for self-hosted users (their data goes to their own DB,
    no central disclosure needed). Only fires when the central
    RemoteWriter is actually about to send.
    """
    import os

    # Don't disclose self-hosted users — their data isn't going to us.
    if os.environ.get("FRED_TELEMETRY_DB_URL"):
        return
    # Don't disclose if telemetry is off (NullTracer's session_id is "").
    if not getattr(tracer, "session_id", None):
        return
    from fred.preferences import load_preferences, save_preferences

    prefs = load_preferences()
    if prefs.telemetry_first_run_shown:
        return
    console.print(
        "[dim]Fred sends anonymized behavioral telemetry to improve the product. "
        "Run [bold]/telemetry off[/bold] to opt out. Details: "
        "https://app.fredcode.net/docs/telemetry[/dim]"
    )
    prefs.telemetry_first_run_shown = True
    save_preferences(prefs)


def _render_init_diff(old: str, new: str, console: Console) -> None:
    """Print a colorized unified diff between an existing and new AGENTS.md.

    Stdlib `difflib` only — no new deps. Green for additions, red for
    deletions, dim for context.
    """
    import difflib

    diff = list(difflib.unified_diff(
        old.splitlines(keepends=False),
        new.splitlines(keepends=False),
        fromfile="AGENTS.md (current)",
        tofile="AGENTS.md (proposed)",
        lineterm="",
    ))
    if not diff:
        console.print("[dim](proposed content is identical to current AGENTS.md)[/]")
        return
    for line in diff:
        if line.startswith("+++") or line.startswith("---"):
            console.print(f"[bold]{line}[/]")
        elif line.startswith("@@"):
            console.print(f"[cyan]{line}[/]")
        elif line.startswith("+"):
            console.print(f"[green]{line}[/]", highlight=False)
        elif line.startswith("-"):
            console.print(f"[red]{line}[/]", highlight=False)
        else:
            console.print(f"[dim]{line}[/]", highlight=False)


def _handle_init_slash(
    *,
    client: DSClient,
    registry,
    permissions,
    renderer: Renderer,
    console: Console,
    tracer,
    repo_map_provider,
) -> str:
    """Run the `/init` flow and return one of:
    ``"wrote_fresh" / "wrote_improve" / "wrote_migrate" / "cancelled" / "error"``.

    The slash handler (caller) emits a single ``slash_command`` event with
    that outcome. Per-step detail (mode, regenerations, draft size, token
    cost) lands in a structured ``init_run`` event we emit here.
    """
    import time as _time
    from pathlib import Path
    from rich.markdown import Markdown
    from fred.init_prompt import (
        detect_init_mode,
        directive_for_mode,
        init_system_prompt,
    )
    from fred.session import run_session
    from fred.tools.agent_tool import AGENT_PROFILES

    cwd = Path.cwd()
    mode, existing_path = detect_init_mode(cwd)
    target_path = cwd / "AGENTS.md"

    # Build the constrained read-only registry. `init` profile = {view,
    # grep, glob, repo_map} ∩ parent registry — same shape as `explore`.
    available = AGENT_PROFILES["init"] & set(registry.names())
    sub_registry = registry.subset(available)

    # Headless renderer so the subagent's streaming UI doesn't pollute
    # the parent transcript. We'll render a clean preview Panel from the
    # captured `final_text` instead.
    headless = Renderer(
        console=renderer.console,
        stream=False,
        show_thinking=False,
        headless=True,
    )

    existing_text = ""
    if mode == "improve" and existing_path is not None:
        try:
            existing_text = existing_path.read_text(encoding="utf-8", errors="replace")
        except OSError as e:
            console.print(f"[red]could not read {existing_path}: {e}[/]")
            return "error"

    console.print(
        f"[dim]/init: scanning repo at {cwd} ({mode} mode)…[/]"
    )

    regenerations = 0
    started = _time.perf_counter()

    while True:
        directive = directive_for_mode(mode)
        if regenerations > 0:
            directive = (
                directive
                + "\n\nThe previous draft was rejected by the user. Try again "
                "with a different angle or more depth, addressing whatever "
                "made the prior version less useful."
            )
        initial = [
            {"role": "system", "content": init_system_prompt()},
            {"role": "user", "content": directive},
        ]
        try:
            result = run_session(
                initial,
                client,
                sub_registry,
                permissions=permissions,
                max_iters=15,
                mode="act",
                tracer=tracer,
                renderer=headless,
                repo_map_provider=repo_map_provider,
                iteration_slot="subagent_main",
            )
        except KeyboardInterrupt:
            console.print("[dim]/init cancelled.[/]")
            tracer.event("init_run", payload={
                "outcome": "cancelled", "mode": mode, "path": str(target_path),
                "regenerations": regenerations, "elapsed_s": round(
                    _time.perf_counter() - started, 3,
                ),
            })
            return "cancelled"
        draft = (result.final_text or "").strip()
        if not draft:
            console.print(
                "[red]/init: subagent returned no draft. "
                "Try again or check API status.[/]"
            )
            tracer.event("init_run", payload={
                "outcome": "error", "mode": mode, "path": str(target_path),
                "regenerations": regenerations, "error": "empty_draft",
            })
            return "error"

        # Strip a stray fenced wrapper if the model added one despite the
        # system prompt asking it not to. Cheap and safe.
        if draft.startswith("```markdown\n") and draft.endswith("\n```"):
            draft = draft[len("```markdown\n"):-len("\n```")]
        elif draft.startswith("```\n") and draft.endswith("\n```"):
            draft = draft[len("```\n"):-len("\n```")]

        # Preview Panel (uses Markdown rendering so the user sees the
        # actual structure, not raw bytes). Title carries the line count.
        line_count = draft.count("\n") + 1
        console.print(Panel(
            Markdown(draft),
            title=f"[bold]AGENTS.md draft[/]  ([dim]{line_count} lines · "
                  f"{mode} mode[/])",
            title_align="left",
            border_style="cyan",
            padding=(1, 2),
            expand=False,
        ))

        # Mode-specific menu. Improve mode adds [d]iff to the choices.
        if mode == "improve":
            prompt_str = "  [w]rite (overwrite), [d]iff, [r]egenerate, [c]ancel? "
            allowed = {"w", "d", "r", "c"}
        else:
            prompt_str = "  [w]rite, [r]egenerate, [c]ancel? "
            allowed = {"w", "r", "c"}
        try:
            answer = input(prompt_str).strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = "c"
        if answer not in allowed:
            answer = "c"

        if answer == "c":
            console.print("[dim]/init cancelled. No file written.[/]")
            tracer.event("init_run", payload={
                "outcome": "cancelled", "mode": mode, "path": str(target_path),
                "regenerations": regenerations,
                "draft_lines": line_count,
                "iterations_used": _count_assistant(result.messages),
                "total_tokens": result.total_tokens_in + result.total_tokens_out,
                "elapsed_s": round(_time.perf_counter() - started, 3),
            })
            return "cancelled"
        if answer == "r":
            regenerations += 1
            continue
        if answer == "d":
            _render_init_diff(existing_text, draft, console)
            try:
                follow = input(
                    "  [w]rite (overwrite), [r]egenerate, [c]ancel? "
                ).strip().lower()
            except (EOFError, KeyboardInterrupt):
                follow = "c"
            if follow == "r":
                regenerations += 1
                continue
            if follow != "w":
                console.print("[dim]/init cancelled. No file written.[/]")
                tracer.event("init_run", payload={
                    "outcome": "cancelled", "mode": mode,
                    "path": str(target_path),
                    "regenerations": regenerations,
                    "draft_lines": line_count,
                    "iterations_used": _count_assistant(result.messages),
                    "total_tokens": result.total_tokens_in + result.total_tokens_out,
                    "elapsed_s": round(_time.perf_counter() - started, 3),
                })
                return "cancelled"
            answer = "w"

        # Write path. Fresh mode uses O_EXCL so a concurrent file-creation
        # race doesn't silently overwrite. Improve / migrate already
        # confirmed an overwrite via the explicit menu choice.
        try:
            if mode == "fresh":
                with open(target_path, "x", encoding="utf-8") as f:
                    f.write(draft if draft.endswith("\n") else draft + "\n")
            else:
                target_path.write_text(
                    draft if draft.endswith("\n") else draft + "\n",
                    encoding="utf-8",
                )
        except FileExistsError:
            # Race: AGENTS.md appeared between detect and write.
            console.print(
                "[red]/init: AGENTS.md was created by something else "
                "while you were reviewing. Run /init again to enter improve "
                "mode against the new file.[/]"
            )
            tracer.event("init_run", payload={
                "outcome": "error", "mode": mode, "path": str(target_path),
                "regenerations": regenerations, "error": "race_create",
            })
            return "error"
        except OSError as e:
            console.print(f"[red]/init: could not write {target_path}: {e}[/]")
            tracer.event("init_run", payload={
                "outcome": "error", "mode": mode, "path": str(target_path),
                "regenerations": regenerations,
                "error": f"{type(e).__name__}: {e}",
            })
            return "error"

        outcome = f"wrote_{mode}"
        console.print(
            f"[green]✓ wrote {target_path.relative_to(cwd) if target_path.is_relative_to(cwd) else target_path} "
            f"({line_count} lines)[/]"
        )

        # In migrate mode, offer to symlink CLAUDE.md → AGENTS.md so both
        # names continue to resolve. Default no — silent symlinking would
        # surprise users who deliberately maintain CLAUDE.md.
        if mode == "migrate" and existing_path is not None:
            try:
                offer = input(
                    f"  symlink {existing_path.name} → AGENTS.md? (y/N) "
                ).strip().lower()
            except (EOFError, KeyboardInterrupt):
                offer = ""
            if offer == "y":
                try:
                    existing_path.unlink()
                    existing_path.symlink_to("AGENTS.md")
                    console.print(
                        f"[dim]✓ {existing_path.name} → AGENTS.md (symlink)[/]"
                    )
                except OSError as e:
                    console.print(
                        f"[red]symlink failed: {e}. "
                        f"AGENTS.md was still written; you may delete or "
                        f"replace {existing_path.name} manually.[/]"
                    )

        tracer.event("init_run", payload={
            "outcome": outcome, "mode": mode, "path": str(target_path),
            "draft_lines": line_count,
            "draft_chars": len(draft),
            "regenerations": regenerations,
            "iterations_used": _count_assistant(result.messages),
            "total_tokens": result.total_tokens_in + result.total_tokens_out,
            "elapsed_s": round(_time.perf_counter() - started, 3),
        })
        return outcome


def _count_assistant(messages) -> int:
    """Count assistant messages — proxy for iteration count."""
    return sum(1 for m in messages if m.get("role") == "assistant")


def _handle_telemetry_slash(arg: str | None, *, console: Console, tracer) -> None:
    """Handle `/telemetry [...]` invocations.

    Forms:
      - `/telemetry`             — print current routing
      - `/telemetry on`          — clear opt-out (effective next session)
      - `/telemetry off`         — set opt-out (effective next session)
      - `/telemetry status`      — alias for the no-arg form
    """
    from fred.preferences import load_preferences, save_preferences

    sub = (arg or "").strip().lower() or "status"
    if sub == "status":
        console.print(f"[dim]telemetry: {_telemetry_status_line()}[/]")
        tracer.event("slash_command", payload={"cmd": "/telemetry", "sub": "status"})
        return
    if sub == "on":
        prefs = load_preferences()
        was = prefs.telemetry_opted_out
        prefs.telemetry_opted_out = False
        save_preferences(prefs)
        if was:
            console.print(
                "[dim]telemetry will resume next session. "
                "(Restart fred to apply now.)[/]"
            )
        else:
            console.print("[dim]telemetry was already on.[/]")
        tracer.event("slash_command", payload={
            "cmd": "/telemetry", "sub": "on", "changed": was,
        })
        return
    if sub == "off":
        prefs = load_preferences()
        was_off = prefs.telemetry_opted_out
        prefs.telemetry_opted_out = True
        save_preferences(prefs)
        if was_off:
            console.print("[dim]telemetry was already off.[/]")
        else:
            console.print(
                "[dim]telemetry will stop sending next session. "
                "Current session continues until you /exit.[/]"
            )
        tracer.event("slash_command", payload={
            "cmd": "/telemetry", "sub": "off", "changed": not was_off,
        })
        return
    console.print(
        f"[red]usage: /telemetry [status|on|off]  (got {sub!r})[/]"
    )


def _handle_model_slash(
    arg: str | None,
    *,
    client: DSClient,
    model_cfg: ModelConfig,
    console: Console,
    tracer,
) -> ModelConfig:
    """Handle `/model [...]` invocations. Returns the (possibly updated) config.

    Three forms:
      - `/model`               — print all four slots; no mutation.
      - `/model <name>`        — backwards compat: swap main slot.
      - `/model <slot> <name>` — slot-aware: swap one of
        main|editor|weak|subagent_main.

    `client.model` is kept in sync with the main slot so the existing
    `client.model` direct-assignment path used by the agent loop still
    routes correctly. Editor, weak, and subagent_main slots live on
    `model_cfg`; the callsites that want them call
    `client.with_model(model_cfg.editor_model)` at dispatch time.

    Side-effects:
      - tracer event `slash_command` always fires.
      - tracer event `model_routed` fires only on actual change, with
        `{slot, model, reason: "user_/model"}`.
    """
    if not arg:
        # No-arg form: print all four slots, regardless of whether they
        # match. Telemetry records `changed=False` for analysis parity.
        from fred.preferences import load_preferences

        prefs_preset = load_preferences().preset
        preset_line = f"\npreset: {prefs_preset}" if prefs_preset else ""
        console.print(
            f"[dim]main:           {model_cfg.main_model}\n"
            f"editor:         {model_cfg.editor_model}\n"
            f"weak:           {model_cfg.weak_model}\n"
            f"subagent_main:  {model_cfg.subagent_main_model}{preset_line}[/]"
        )
        tracer.event("slash_command", payload={
            "cmd": "/model",
            "main": model_cfg.main_model,
            "editor": model_cfg.editor_model,
            "weak": model_cfg.weak_model,
            "subagent_main": model_cfg.subagent_main_model,
            "changed": False,
        })
        return model_cfg

    parts = arg.strip().split(maxsplit=1)
    first = parts[0]
    if first in _MODEL_SLOTS and len(parts) == 2:
        # Slot-aware form: `/model <slot> <name>`.
        slot = first
        new_name = parts[1].strip()
        old_name = model_cfg.for_slot(slot)
        if slot == "main":
            client.model = new_name
        model_cfg = _replace_slot(model_cfg, slot, new_name)
        changed = new_name != old_name
        console.print(f"[dim]{slot} → {new_name}[/]")
        # When the user pins main but leaves the others alone, surface
        # the routing so the user sees the divergence at swap time.
        if slot == "main" and (
            model_cfg.editor_model != new_name
            or model_cfg.weak_model != new_name
            or model_cfg.subagent_main_model != new_name
        ):
            console.print(
                f"[dim]  (editor: {model_cfg.editor_model}, "
                f"weak: {model_cfg.weak_model}, "
                f"subagent_main: {model_cfg.subagent_main_model})[/]"
            )
        tracer.event("slash_command", payload={
            "cmd": "/model",
            "slot": slot,
            "model": new_name,
            "previous": old_name,
            "changed": changed,
        })
        if changed:
            tracer.event("model_routed", payload={
                "slot": slot,
                "model": new_name,
                "reason": "user_/model",
            })
            _persist_model_prefs(model_cfg)
        return model_cfg

    if first in _MODEL_SLOTS and len(parts) == 1:
        # `/model main` etc. without a name — likely a typo; show usage
        # and don't mutate.
        console.print(
            "[red]usage: /model <slot> <name>  "
            "(slot in main|editor|weak|subagent_main)[/]"
        )
        tracer.event("slash_command", payload={
            "cmd": "/model", "slot": first, "error": "missing_name",
        })
        return model_cfg

    # Backwards-compat: `/model <name>` (single token, not a slot keyword)
    # swaps the main slot.
    new_name = arg.strip()
    old_main = client.model
    client.model = new_name
    model_cfg = _replace_slot(model_cfg, "main", new_name)
    changed = new_name != old_main
    console.print(f"[dim]model → {new_name}[/]")
    if changed and (
        model_cfg.editor_model != new_name
        or model_cfg.weak_model != new_name
        or model_cfg.subagent_main_model != new_name
    ):
        console.print(
            f"[dim]  (editor: {model_cfg.editor_model}, "
            f"weak: {model_cfg.weak_model}, "
            f"subagent_main: {model_cfg.subagent_main_model})[/]"
        )
    tracer.event("slash_command", payload={
        "cmd": "/model",
        "model": new_name,
        "previous": old_main,
        "changed": changed,
    })
    if changed:
        tracer.event("model_routed", payload={
            "slot": "main",
            "model": new_name,
            "reason": "user_/model",
        })
        _persist_model_prefs(model_cfg)
    return model_cfg


def _replace_slot(model_cfg: ModelConfig, slot: str, new_name: str) -> ModelConfig:
    """Return a new ModelConfig with one slot swapped, preserving the rest."""
    return ModelConfig(
        main_model=new_name if slot == "main" else model_cfg.main_model,
        editor_model=new_name if slot == "editor" else model_cfg.editor_model,
        weak_model=new_name if slot == "weak" else model_cfg.weak_model,
        subagent_main_model=(
            new_name if slot == "subagent_main" else model_cfg.subagent_main_model
        ),
    )


def _apply_topology(
    cmd: str,
    *,
    client: DSClient,
    model_cfg: ModelConfig,
    console: Console,
    tracer,
) -> ModelConfig:
    """Apply a named topology preset (`/flash` or `/pro`) to all four slots.

    `/flash` collapses every slot to deepseek-v4-flash. `/pro` enables
    architect topology: main=deepseek-v4-pro, others=deepseek-v4-flash.

    Side effects (per slot that actually changed):
      - tracer event `model_routed` with `reason="user_<cmd>"`.
      - one combined `slash_command` event with the resulting topology.
    Persistence is a single `_persist_model_prefs` call after all slot
    swaps so the JSON file stays consistent.
    """
    flash = "deepseek-v4-flash"
    pro = "deepseek-v4-pro"
    if cmd == "/flash":
        target = ModelConfig(
            main_model=flash,
            editor_model=flash,
            weak_model=flash,
            subagent_main_model=flash,
        )
    else:  # /pro
        target = ModelConfig(
            main_model=pro,
            editor_model=flash,
            weak_model=flash,
            subagent_main_model=flash,
        )

    # Keep client.model in sync with the main slot (the agent loop
    # reads this directly when constructing each iteration's request).
    client.model = target.main_model

    reason = f"user_{cmd}"
    changed: list[tuple[str, str, str]] = []
    for slot in _MODEL_SLOTS:
        old = model_cfg.for_slot(slot)
        new = target.for_slot(slot)
        if old != new:
            changed.append((slot, old, new))
            tracer.event("model_routed", payload={
                "slot": slot,
                "model": new,
                "previous": old,
                "reason": reason,
            })

    tracer.event("slash_command", payload={
        "cmd": cmd,
        "main": target.main_model,
        "editor": target.editor_model,
        "weak": target.weak_model,
        "subagent_main": target.subagent_main_model,
        "changed": bool(changed),
    })

    if changed:
        _persist_model_prefs(target)
        console.print(f"[dim]{cmd} → {_format_model_line(target)}[/]")
    else:
        console.print(f"[dim]{cmd} (already active)[/]")

    return target


@app.callback(invoke_without_command=True)
def _run(
    ctx: typer.Context,
    prompt: Optional[str] = typer.Option(
        None, "-p", "--prompt", help="One-shot mode: run this prompt and exit."
    ),
    yolo: bool = typer.Option(
        False, "--yolo", help="Skip permission prompts. Dangerous."
    ),
    plan: bool = typer.Option(
        False, "--plan",
        help="Start in plan mode: read-only, produce a plan, call ExitPlanMode to switch.",
    ),
    no_stream: bool = typer.Option(
        False, "--no-stream", help="Disable rich.Live streaming (use on tmux/Windows Terminal if it flickers)."
    ),
    model: str = typer.Option(
        DEFAULT_MODEL, "--model", help="DeepSeek model to use."
    ),
    architect: bool = typer.Option(
        False, "--architect",
        help="Force the editor pass even when editor_model == main_model "
             "(useful for evaluation runs).",
    ),
    output_style: str = typer.Option(
        "concise", "--output-style",
        help="Output style: concise (default, terse) or explanatory "
             "(short paragraph of reasoning per significant change).",
    ),
    sandbox: Optional[str] = typer.Option(
        None, "--sandbox",
        help="macOS sandbox mode: ro|workspace-write|full. Overrides "
             "FRED_SANDBOX_MODE and .fred/settings.json. Default workspace-write.",
    ),
    approval: Optional[str] = typer.Option(
        None, "--approval",
        help="Approval mode for permission prompts: untrusted|on_request|never. "
             "Overrides FRED_APPROVAL_MODE. Default on_request. 'never' skips "
             "the y/n/a/d Panel entirely (subset of YOLO; sandbox is the defense).",
    ),
    no_telemetry: bool = typer.Option(
        False, "--no-telemetry",
        help="Disable telemetry for THIS session only. Doesn't change your "
             "persisted opt-out preference. To opt out persistently, run "
             "/telemetry off in the REPL or `fred telemetry off`.",
    ),
    show_version: bool = typer.Option(
        False, "--version", help="Print version and exit."
    ),
) -> None:
    if show_version:
        typer.echo(f"fred {__version__}")
        raise typer.Exit()

    # If a subcommand (login/logout/whoami) was invoked, let it run instead.
    if ctx.invoked_subcommand is not None:
        return

    # P3.3: validate the output style early so a typo fails fast with a
    # clear message rather than silently falling back to the default.
    if output_style not in ("concise", "explanatory"):
        typer.echo(
            f"Invalid --output-style {output_style!r}. "
            "Expected 'concise' or 'explanatory'.",
            err=True,
        )
        raise typer.Exit(code=1)
    output_style_state: list[str] = [output_style]

    if not get_api_key():
        _render_no_credentials_panel()
        raise typer.Exit(code=1)

    console = Console()
    renderer = Renderer(console=console, stream=not no_stream)

    # P4.1: validate the two new orthogonal axis flags up-front so a typo
    # fails loud rather than silently falling back to the default.
    sandbox_mode_override: SandboxMode | None = None
    if sandbox is not None:
        sandbox_mode_override = normalize_sandbox_mode(sandbox)
        if sandbox_mode_override is None:
            typer.echo(
                f"Invalid --sandbox {sandbox!r}. "
                "Expected ro|workspace-write|full.",
                err=True,
            )
            raise typer.Exit(code=1)
    if approval is not None:
        if normalize_approval_mode(approval) is None:
            typer.echo(
                f"Invalid --approval {approval!r}. "
                "Expected untrusted|on_request|never.",
                err=True,
            )
            raise typer.Exit(code=1)

    permissions = PermissionPolicy(
        yolo=yolo, console=console, approval_mode=approval,
    )

    # Install the session-scoped sandbox mode. None defers to env / settings.
    _sandbox_mode_token = set_sandbox_mode(sandbox_mode_override)

    # Multi-model routing: build the four-slot config now so the
    # banner, tracer snapshot, and `/model` slash all read from the same
    # source of truth. Explicit `--model` overrides `FRED_MAIN_MODEL` for
    # the main slot only; editor, weak, and subagent_main still inherit
    # from main when their env vars / prefs are unset, which is the
    # friendly default.
    model_cfg = load_model_config()
    if model != DEFAULT_MODEL:
        new_main = model
        new_editor = model_cfg.editor_model
        new_weak = model_cfg.weak_model
        new_subagent_main = model_cfg.subagent_main_model
        if new_editor == model_cfg.main_model:
            new_editor = new_main
        if new_weak == model_cfg.main_model:
            new_weak = new_main
        if new_subagent_main == model_cfg.main_model:
            new_subagent_main = new_main
        model_cfg = ModelConfig(
            main_model=new_main,
            editor_model=new_editor,
            weak_model=new_weak,
            subagent_main_model=new_subagent_main,
        )

    client = DSClient(model=model_cfg.main_model)

    # P2.2 plan/act mode. The `mode_state` list is the SINGLE source of
    # truth for the current mode — slash commands, the Shift+Tab
    # keybinding, and `exit_plan_mode` (called by the model) all mutate
    # the same list, and `Registry.dispatch` reads from it via the
    # `fred.mode` ContextVar installed below. The initial value comes
    # from the `--plan` flag.
    initial_mode: Mode = "plan" if plan else "act"
    mode_state: list[str] = [initial_mode]
    _mode_state_token = set_mode_state(mode_state)
    # PR-D1: install a session-scoped todo list so sub-agents (which
    # dispatch fresh run_session calls) get their own isolated lists.
    # Without this the module-global _state would leak across the
    # parent → subagent boundary; the `plan` subagent profile in
    # particular has todo_write AND would otherwise share the parent's
    # storage. Token is held for the lifetime of the REPL.
    from fred.tools.todo import install_todo_list, reset_todo_list as _reset_todos
    _todos_token = install_todo_list()
    messages, registry = _build_initial_messages(
        mode=initial_mode, output_style=output_style_state[0],  # type: ignore[arg-type]
    )

    # Convenience: short helper that reads the live mode (the slash
    # command + keybinding mutate `mode_state[0]`, so this always
    # returns the current value, not a captured snapshot).
    def current_mode() -> Mode:
        return "plan" if mode_state[0] == "plan" else "act"

    # P3.3: helper for the live output style (mutated by `/style`).
    def current_output_style() -> OutputStyle:
        v = output_style_state[0]
        return "explanatory" if v == "explanatory" else "concise"

    # Plan-file scratchpad path (P2.2). Computed once per session;
    # exposed via session_state so the banner / future status line
    # can show it. The directory is created lazily.
    session_state = _SessionState()
    session_state.plan_file_path = plan_file_path(uuid.uuid4().hex)

    run_mode = _RunMode.ARCHITECT if architect else _RunMode.NORMAL

    tracer = make_tracer(session_disabled=no_telemetry)
    # First-run notice — print once on the first session that successfully
    # constructs a non-NullTracer, then never again. Lives here (after
    # tracer construction, before start_session) so users see the
    # disclosure exactly when telemetry is about to fire.
    _maybe_show_first_run_notice(tracer, console)
    if prompt is None:
        # Background PyPI poll for the update notice. Daemon thread,
        # never blocks startup, silent on every error. One-shot mode
        # (-p) deliberately skips this — scriptable users get no notice
        # and no PyPI traffic.
        update_check.kickoff()
    tracer.start_session(
        model=model_cfg.main_model,
        base_url=DEFAULT_BASE_URL,
        yolo=yolo,
        one_shot=prompt is not None,
        system_prompt=messages[0]["content"],
        registry_names=registry.names(),
        registry_perms={n: registry.get(n).requires_permission for n in registry.names()},
        config_snapshot={
            "main_model": model_cfg.main_model,
            "editor_model": model_cfg.editor_model,
            "weak_model": model_cfg.weak_model,
            "subagent_main_model": model_cfg.subagent_main_model,
            "run_mode": run_mode,
            # P3.3: persists the starting output style so analytics can
            # join sessions to behavior outcomes (e.g. "do explanatory
            # sessions complete in fewer iterations?").
            "output_style": output_style_state[0],
        },
    )
    # Thread the local session_id into the proxy via x-fred-session-id
    # so usage_events rows the proxy writes can be joined back to this
    # CLI session in /usage and /admin/models. NullTracer returns "" —
    # in that case the header isn't sent.
    if tracer.session_id:
        client.correlation_session_id = tracer.session_id
    if plan:
        # The flag-driven entry into plan mode is the first user-visible
        # mode change of the session — emit a `mode_change` event with
        # source="flag" so analytics can attribute it correctly.
        tracer.event("mode_change", payload={
            "from": "act", "to": "plan", "source": "flag",
        })

    # --- Repo map (P1.1). Cold-start scan now so the first turn has
    # a populated tag cache and personalization can take effect. The
    # feature can be disabled via `FRED_REPOMAP=0` (e.g., in CI or for
    # tiny one-off invocations where the scan would be wasted work).
    repo_map_obj: RepoMap | None = None
    if os.environ.get("FRED_REPOMAP", "1") != "0":
        try:
            repo_map_obj = RepoMap(Path.cwd())
            tracer.event("repo_map_scan_start", payload={"root": str(Path.cwd())})
            renderer.info("repo map: scanning…")
            stats = repo_map_obj.scan()
            tracer.event("repo_map_scan_complete", payload=stats)
            renderer.info(
                f"repo map: parsed {stats['files_parsed']}/{stats['files_seen']} files "
                f"in {stats['parse_ms'] + stats['walk_ms']}ms "
                f"({len(stats['languages_found'])} language(s))"
            )
        except Exception as e:
            # Best-effort: if the scan fails (sqlite db corrupt, perms,
            # ...), drop the repo map silently and continue.
            tracer.event("repo_map_scan_failed", payload={
                "type": type(e).__name__, "message": str(e)[:200],
            })
            repo_map_obj = None

    repo_map_provider = _make_repo_map_provider(repo_map_obj, session_state)

    # P1.4 prior-Read enforcement: install the session-scoped tracked-files
    # set so `view` / `create_file` populate it via `mark_tracked` and
    # `str_replace` can consult it. We share the SAME object as
    # `session_state.viewed_files` so the repo-map personalization
    # (which already reads viewed_files) keeps working without duplicate
    # bookkeeping. The token is reset in the `finally` block below.
    _tracked_files_token = set_tracked_files(session_state.viewed_files)

    # P3.4 background bash: install a fresh per-session state for the
    # bash_bg / bash_read / bash_kill tools so handles never leak across
    # CLI invocations (or `/clear`, which forks the ContextVar). Also
    # install a tracer-emitter shim so the bash_bg events land in the
    # session's tracer rather than the module-level NullTracer fallback.
    _bash_bg_state_token = _bash_bg.set_session_state()

    def _bash_bg_emit(kind: str, payload: dict) -> None:
        # Wraps Tracer.event so the bash_bg module stays decoupled from
        # the tracer interface. Errors are swallowed inside _bash_bg._emit.
        tracer.event(kind, payload=payload)

    _bash_bg_emit_token = _bash_bg.set_event_emitter(_bash_bg_emit)

    # P2.4 hooks: load `~/.fred/settings.json` and project-level
    # `.fred/settings.json` and merge them. UserPromptSubmit + Stop fire
    # from the cli; PreToolUse + PostToolUse fire inside `run_session`.
    hooks_config = load_hooks_config(Path.cwd())

    # P4.2 MCP: spawn user-configured MCP servers and merge their tools
    # into the active registry. `mcp_session` is None when no servers
    # are configured (the common case). Failures degrade to info lines
    # and crashed entries — they never bring down the session.
    mcp_configs = load_mcp_config(Path.cwd())
    mcp_session = None
    if mcp_configs:
        def _mcp_event(kind: str, payload: dict) -> None:
            try:
                tracer.event(kind, payload=payload)
            except Exception:
                pass

        try:
            mcp_session = mcp_connect_servers(
                mcp_configs,
                on_event=_mcp_event,
                on_info=renderer.info,
            )
            tools_added = mcp_register_tools(
                registry, mcp_session, on_event=_mcp_event,
            )
            if tools_added:
                renderer.info(f"mcp: registered {tools_added} tool(s)")
        except Exception as e:
            tracer.event("mcp_load_failed", payload={
                "type": type(e).__name__, "message": str(e)[:200],
            })
            mcp_session = None

    # P3.2 rules: discover `.fred/rules/*.md` once at session start. The
    # set is passed to `run_turn`/`run_session` and is the source of
    # truth for the per-iteration "active" + "available" rule blocks.
    # `FRED_RULES=0` disables the feature entirely; matches FRED_REPOMAP.
    rule_set: RuleSet | None = None
    if not env_disables_rules():
        try:
            rule_set = RuleSet.load(Path.cwd())
            if rule_set.rules:
                renderer.info(
                    f"rules: loaded {len(rule_set.rules)} from "
                    f"{', '.join(str(s) for s in rule_set.sources)}"
                )
        except Exception as e:
            tracer.event("rules_load_failed", payload={
                "type": type(e).__name__, "message": str(e)[:200],
            })
            rule_set = None

    def _chat_files_provider() -> set[Path]:
        """Snapshot the files referenced this turn for glob matching."""
        return set(session_state.viewed_files) | set(session_state.mentioned_files)

    # P4.3: shadow-git checkpoints. Construct the Checkpointer once per
    # session; the bare repo is initialized lazily on the first
    # successful tool dispatch. Disabled when ``FRED_CHECKPOINTS=0`` —
    # matches the on/off switch used by other Phase-3/4 features.
    checkpointer: Checkpointer | None = None
    if os.environ.get("FRED_CHECKPOINTS", "1") != "0":
        try:
            checkpointer = Checkpointer(Path.cwd())
        except Exception as e:
            tracer.event("checkpoints_init_failed", payload={
                "type": type(e).__name__, "message": str(e)[:200],
            })
            checkpointer = None
        # Once-per-week stale-workspace prune. Best-effort; failures
        # silent so a slow disk doesn't delay session startup. The
        # function emits its own short-circuit when the marker says
        # "not due yet" so this is essentially free on most launches.
        try:
            pruned = prune_stale()
            for entry in pruned:
                tracer.event("checkpoint_pruned", payload=entry)
        except Exception:
            pass

    # P3.3: status line state. We sample the per-turn telemetry event so
    # we don't flood `fred_events` on chatty sessions: emit when the
    # session cost crosses a $0.01 boundary OR every 10 turns.
    last_status_cost_cents = [0]
    turns_since_status_event = [0]

    def _emit_status_line() -> None:
        cache_rate: float | None = None
        if renderer.session_in > 0 and renderer.session_cached > 0:
            cache_rate = renderer.session_cached / renderer.session_in
        repo_size: int | None = None
        if repo_map_obj is not None:
            stats = getattr(repo_map_obj, "last_scan_stats", None) or {}
            files_parsed = stats.get("files_parsed")
            if isinstance(files_parsed, int) and files_parsed > 0:
                repo_size = files_parsed
        try:
            from fred.tools.todo import get_todos
            todos = get_todos()
        except Exception:
            todos = []
        total = len(todos) if todos else 0
        in_progress = sum(1 for t in todos if getattr(t, "status", "") == "in_progress")

        # Token / cost / cache stats now live in the persistent bottom
        # toolbar (`Renderer.footer_text`). The end-of-turn rule is
        # purely a visual divider for what the toolbar can't carry:
        # mode, repo size, and todo progress.
        line = renderer.print_status_line(
            model_cfg=model_cfg,
            mode=current_mode(),
            repo_map_size=repo_size,
            todos_active=(in_progress, total) if total > 0 else None,
        )

        turns_since_status_event[0] += 1
        cents = int(renderer.session_cost * 100)
        cost_crossed = cents != last_status_cost_cents[0]
        time_for_emit = turns_since_status_event[0] >= 10
        if cost_crossed or time_for_emit:
            last_status_cost_cents[0] = cents
            turns_since_status_event[0] = 0
            tracer.event("status_line_rendered", payload={
                "model": model_cfg.main_model,
                "mode": current_mode(),
                "output_style": current_output_style(),
                "session_in": renderer.session_in,
                "session_out": renderer.session_out,
                "session_cached": renderer.session_cached,
                "session_cost": round(renderer.session_cost, 6),
                "cache_hit_rate": round(cache_rate, 4) if cache_rate is not None else None,
                "repo_map_size": repo_size,
                "todos_total": total,
                "todos_in_progress": in_progress,
                "rendered_chars": len(line),
            })

    end_reason = "natural"
    try:
        if prompt is not None:
            try:
                # UserPromptSubmit hook (P2.4): exit-2 cancels the turn
                # before any model call. The one-shot path mirrors the
                # REPL behavior — we print a banner and return without
                # an error code so a successful "blocked" hook isn't
                # mistaken for a runtime crash by callers.
                up_outcome = run_hooks(
                    "UserPromptSubmit",
                    hooks_config,
                    tracer=tracer,
                    user_input=prompt,
                )
                if up_outcome is not None and up_outcome.blocked:
                    cmd = up_outcome.hook.command if up_outcome.hook else ""
                    console.print(f"[red]⊘ blocked by UserPromptSubmit hook: {cmd}[/]")
                    end_reason = "hook_blocked"
                    return
                session_state.update_from_user_input(prompt)
                run_turn(
                    prompt, messages, client, registry, renderer, permissions,
                    tracer=tracer, repo_map_provider=repo_map_provider,
                    hooks_config=hooks_config,
                    rule_set=rule_set,
                    chat_files_provider=_chat_files_provider,
                    checkpointer=checkpointer,
                    architect=architect,
                )
                # P3.3: status line after the one-shot turn so the user
                # sees the post-completion summary even when there's no
                # REPL prompt to follow. Errors here are non-fatal.
                try:
                    _emit_status_line()
                except Exception:
                    pass
            except KeyboardInterrupt:
                end_reason = "interrupt"
            return

        # Update status is shown inside the banner title now (folded from
        # the previous separate `maybe_print_notice` line).
        _render_banner(
            console, model_cfg, yolo, registry,
            plan_mode=current_mode() == "plan",
            output_style=current_output_style(),
            sandbox_mode=current_sandbox_mode(),
            approval_mode=permissions.approval_mode,
            mcp_session=mcp_session,
        )

        # Shift+Tab keybinding (P2.2). prompt_toolkit's KeyBindings table
        # captures `mode_state` and the tracer/console; pressing the
        # combination cycles plan ↔ act and emits a `mode_change` event.
        kb = KeyBindings()

        @kb.add("s-tab")
        def _toggle_mode_keybinding(event) -> None:
            old = current_mode()
            new: Mode = "plan" if old == "act" else "act"
            mode_state[0] = new
            tracer.event("mode_change", payload={
                "from": old, "to": new, "source": "keybind",
            })
            console.print(f"[dim]mode → {new}[/]")

        # Persistent bottom toolbar: model · mode · turn · total · hotkeys.
        # The earlier rev disabled bottom_toolbar because returning None
        # left a stray white bar on macOS Terminal.app (the toolbar Window
        # allocates a row regardless of content). `Renderer.footer_text`
        # is contractually non-empty, which sidesteps that bug.
        # `refresh_interval=0.5` keeps the bar live so mode toggles
        # (shift+tab, /pro, etc.) reflect within half a second.
        def _bottom_toolbar() -> str:
            hotkeys = (
                "shift+tab plan" if current_mode() == "act" else "shift+tab act"
            )
            hotkeys += " · /exit"
            try:
                return renderer.footer_text(
                    model_cfg=model_cfg,
                    mode=current_mode(),
                    hotkey_hint=hotkeys,
                )
            except Exception:
                # Never let a formatter exception kill the input loop —
                # fall back to a static string so the bar still renders.
                return f"fred · {current_mode()} · {hotkeys}"

        session_input = PromptSession(
            message=HTML("<ansicyan>› </ansicyan>"),
            key_bindings=kb,
            completer=SlashCommandCompleter(
                on_open=lambda count: tracer.event(
                    "slash_dropdown_open", payload={"count": count}
                ),
            ),
            complete_while_typing=True,
            complete_style=CompleteStyle.COLUMN,
            reserve_space_for_menu=8,
            bottom_toolbar=_bottom_toolbar,
            refresh_interval=0.5,
        )
        while True:
            try:
                line = session_input.prompt()
            except EOFError:
                end_reason = "eof"
                console.print("\n[dim]bye.[/]")
                return
            except KeyboardInterrupt:
                end_reason = "interrupt"
                console.print("\n[dim]bye.[/]")
                return
            line = line.strip()
            if not line:
                continue
            if line.startswith("/"):
                parts = line.split(maxsplit=1)
                cmd = parts[0].lower()
                arg = parts[1] if len(parts) > 1 else None
                if cmd in ("/exit", "/quit"):
                    tracer.event("slash_command", payload={"cmd": cmd})
                    end_reason = "exit_cmd"
                    return
                if cmd == "/help":
                    tracer.event("slash_command", payload={"cmd": cmd})
                    console.print(SLASH_HELP)
                    continue
                if cmd == "/clear":
                    tracer.event("slash_command", payload={"cmd": cmd})
                    # /clear rebuilds the system prompt; carry the live
                    # mode AND the live output style through so the
                    # prompt template matches the post-clear contract
                    # (act vs plan, concise vs explanatory).
                    messages, registry = _build_initial_messages(
                        mode=current_mode(),
                        output_style=current_output_style(),
                    )
                    console.print("[dim]conversation cleared.[/]")
                    continue
                if cmd == "/tools":
                    tracer.event("slash_command", payload={"cmd": cmd})
                    for name in registry.names():
                        desc = (registry.get(name).description or "").splitlines()[0]
                        console.print(f"  [bold]{name}[/]  [dim]{desc}[/]")
                    continue
                if cmd == "/todos":
                    # Between-turn inspection; same render path as the
                    # post-turn show_todos() — empty list still prints a
                    # one-line note so the user gets feedback either way.
                    tracer.event("slash_command", payload={"cmd": cmd})
                    from fred.tools.todo import get_todos
                    if get_todos():
                        renderer.show_todos()
                    else:
                        console.print("[dim]no todos.[/]")
                    continue
                if cmd == "/yolo":
                    permissions.yolo = not permissions.yolo
                    tracer.event("slash_command", payload={
                        "cmd": cmd, "yolo": permissions.yolo,
                    })
                    console.print(f"[dim]YOLO {'on' if permissions.yolo else 'off'}.[/]")
                    continue
                if cmd == "/sandbox":
                    # P4.1: print current sandbox + approval modes, with
                    # an optional inline mode swap (`/sandbox ro` etc).
                    sub = (arg or "").strip().lower()
                    if not sub:
                        cur_sb = current_sandbox_mode()
                        cur_app = permissions.approval_mode
                        tracer.event("slash_command", payload={
                            "cmd": cmd, "sandbox": cur_sb, "approval": cur_app,
                        })
                        console.print(
                            f"[dim]sandbox:  {cur_sb}\n"
                            f"approval: {cur_app}\n"
                            f"\n"
                            f"usage: /sandbox <mode>          "
                            f"(mode: ro|workspace-write|full)\n"
                            f"       /sandbox approval <mode> "
                            f"(mode: untrusted|on_request|never)[/]"
                        )
                        continue
                    parts2 = sub.split(maxsplit=1)
                    if parts2[0] == "approval" and len(parts2) == 2:
                        new_app = normalize_approval_mode(parts2[1])
                        if new_app is None:
                            tracer.event("slash_command", payload={
                                "cmd": cmd, "axis": "approval",
                                "arg": parts2[1], "error": "invalid_mode",
                            })
                            console.print(
                                "[red]usage: /sandbox approval "
                                "untrusted|on_request|never[/]"
                            )
                            continue
                        old_app = permissions.approval_mode
                        permissions.approval_mode = new_app
                        tracer.event("slash_command", payload={
                            "cmd": cmd, "axis": "approval",
                            "from": old_app, "to": new_app,
                        })
                        console.print(f"[dim]approval → {new_app}[/]")
                        continue
                    new_sb = normalize_sandbox_mode(parts2[0])
                    if new_sb is None:
                        tracer.event("slash_command", payload={
                            "cmd": cmd, "axis": "sandbox",
                            "arg": sub, "error": "invalid_mode",
                        })
                        console.print(
                            "[red]usage: /sandbox <mode>  "
                            "(mode: ro|workspace-write|full) | "
                            "/sandbox approval <mode>[/]"
                        )
                        continue
                    old_sb = current_sandbox_mode()
                    # Re-install the ContextVar with the new mode.
                    reset_sandbox_mode(_sandbox_mode_token)
                    _sandbox_mode_token = set_sandbox_mode(new_sb)
                    tracer.event("slash_command", payload={
                        "cmd": cmd, "axis": "sandbox",
                        "from": old_sb, "to": new_sb,
                    })
                    console.print(f"[dim]sandbox → {new_sb}[/]")
                    continue
                if cmd == "/cost":
                    tracer.event("slash_command", payload={"cmd": cmd})
                    console.print(renderer.cost_summary())
                    _print_server_cost(console)
                    continue
                if cmd == "/think":
                    tracer.event("slash_command", payload={"cmd": cmd, "arg": arg})
                    sub = (arg or "").strip().lower()
                    if sub in ("on", "off"):
                        renderer.show_thinking = (sub == "on")
                        console.print(f"[dim]thinking display {sub}.[/]")
                    elif sub == "show":
                        if renderer.last_reasoning:
                            console.print(Panel(
                                renderer.last_reasoning,
                                title="thinking (last turn)",
                                title_align="left",
                                border_style="grey50",
                                expand=False,
                            ))
                        else:
                            console.print("[dim]no recent reasoning.[/]")
                    else:
                        console.print("[red]usage: /think on|off|show[/]")
                    continue
                if cmd == "/save":
                    path = arg.strip() if arg else f"fred-transcript-{int(time.time())}.jsonl"
                    saved = False
                    error = None
                    try:
                        with open(path, "w") as f:
                            for m in messages:
                                f.write(json.dumps(m) + "\n")
                        saved = True
                        console.print(f"[dim]saved {len(messages)} messages to {path}[/]")
                    except OSError as e:
                        error = f"{type(e).__name__}: {e}"
                        console.print(f"[red]save failed: {e}[/]")
                    tracer.event("slash_command", payload={
                        "cmd": cmd, "path": path, "messages": len(messages),
                        "saved": saved, "error": error,
                    })
                    continue
                if cmd == "/init":
                    outcome = _handle_init_slash(
                        client=client,
                        registry=registry,
                        permissions=permissions,
                        renderer=renderer,
                        console=console,
                        tracer=tracer,
                        repo_map_provider=repo_map_provider,
                    )
                    tracer.event("slash_command", payload={
                        "cmd": cmd, "outcome": outcome,
                    })
                    continue
                if cmd == "/model":
                    model_cfg = _handle_model_slash(
                        arg, client=client, model_cfg=model_cfg,
                        console=console, tracer=tracer,
                    )
                    continue
                if cmd == "/telemetry":
                    _handle_telemetry_slash(arg, console=console, tracer=tracer)
                    continue
                if cmd in ("/flash", "/pro"):
                    if cmd == "/pro" and not _confirm_pro_switch(console):
                        tracer.event("slash_command", payload={
                            "cmd": cmd, "cancelled": True,
                        })
                        continue
                    model_cfg = _apply_topology(
                        cmd,
                        client=client,
                        model_cfg=model_cfg,
                        console=console,
                        tracer=tracer,
                    )
                    continue
                if cmd == "/repomap":
                    tracer.event("slash_command", payload={"cmd": cmd})
                    if repo_map_obj is None:
                        console.print("[dim]repo map disabled or scan failed.[/]")
                        continue
                    rendered = repo_map_obj.get_repo_map(
                        chat_files=set(),
                        mentioned_idents=set(session_state.mentioned_idents),
                        viewed_files=set(session_state.viewed_files),
                        mentioned_files=set(session_state.mentioned_files),
                    )
                    if not rendered:
                        console.print("[dim](repo map empty)[/]")
                    else:
                        # Print as a Panel so the user can see exactly
                        # what the model is being shown each turn.
                        console.print(Panel(
                            rendered,
                            title="repo map",
                            title_align="left",
                            border_style="dim",
                            expand=False,
                        ))
                    continue
                if cmd == "/rules":
                    # P3.2: list active + available rules. "Active" =
                    # rules that would render in THIS moment's block
                    # given current chat_files + the (session-scoped)
                    # explicit set. We can't reach the explicit set
                    # from outside `run_session` cleanly; the live set
                    # is owned by the loop. Between turns, the explicit
                    # set is whatever the most recent run_session
                    # mutated — exposed via `request_rule_tool`'s
                    # `get_request_rule_context()` ContextVar reader.
                    tracer.event("slash_command", payload={"cmd": cmd})
                    if rule_set is None or not rule_set.rules:
                        console.print(
                            "[dim]no rules loaded. Add `.fred/rules/*.md` "
                            "(or `~/.fred/rules/*.md`) to enable.[/]"
                        )
                        continue
                    from fred.tools.request_rule import get_request_rule_context
                    ctx = get_request_rule_context()
                    explicit = set(ctx.explicit) if ctx is not None else set()
                    active_rules = rule_set.applicable_for(
                        chat_files=_chat_files_provider(),
                        explicit=explicit,
                    )
                    active_names = {r.name for r in active_rules}
                    available_rules = rule_set.available_descriptions(
                        active_names=active_names
                    )
                    body = Text()
                    body.append("active\n", style="bold")
                    if active_rules:
                        for r in active_rules:
                            tag = (
                                "always" if r.always_apply
                                else "requested" if r.name in explicit
                                else "glob"
                            )
                            body.append(
                                f"  • {r.name}  ", style=""
                            )
                            body.append(f"[{tag}]", style="dim")
                            if r.description:
                                desc = r.description.splitlines()[0]
                                body.append(f"  {desc}\n", style="dim")
                            else:
                                body.append("\n")
                    else:
                        body.append("  (none)\n", style="dim")
                    body.append("\navailable (request via request_rule)\n", style="bold")
                    if available_rules:
                        for r in available_rules:
                            body.append(f"  • {r.name}  ", style="")
                            desc = (
                                r.description.splitlines()[0]
                                if r.description else ""
                            )
                            body.append(f"{desc}\n", style="dim")
                    else:
                        body.append("  (none)\n", style="dim")
                    console.print(Panel(
                        body,
                        title="rules",
                        title_align="left",
                        border_style="dim",
                        expand=False,
                    ))
                    continue
                if cmd == "/subagents":
                    # P2.1: surface the active agent profiles. `general`
                    # resolves dynamically from the parent registry, so
                    # its concrete tool set varies as new tools land.
                    tracer.event("slash_command", payload={"cmd": cmd})
                    from fred.tools.agent_tool import AGENT_PROFILES, subset_for
                    rows: list[str] = []
                    for label in ("explore", "plan", "general"):
                        try:
                            tools_in = sorted(subset_for(label, registry))
                        except ValueError:
                            tools_in = []
                        rows.append(
                            f"  [bold]{label}[/]  [dim]({len(tools_in)} tools)[/]  "
                            f"{', '.join(tools_in) if tools_in else '(none)'}"
                        )
                    console.print(Panel(
                        "\n".join(rows),
                        title="subagent profiles",
                        title_align="left",
                        border_style="dim",
                        expand=False,
                    ))
                    continue
                if cmd == "/mode":
                    sub = (arg or "").strip().lower()
                    old = current_mode()
                    new: Mode | None = None
                    if sub in ("plan", "act"):
                        new = "plan" if sub == "plan" else "act"
                    elif sub in ("toggle", ""):
                        new = "plan" if old == "act" else "act"
                    else:
                        tracer.event("slash_command", payload={
                            "cmd": cmd, "arg": arg, "error": "invalid_mode",
                        })
                        console.print("[red]usage: /mode plan|act|toggle[/]")
                        continue
                    tracer.event("slash_command", payload={
                        "cmd": cmd, "arg": sub or "toggle", "from": old, "to": new,
                    })
                    if new == old:
                        console.print(f"[dim]mode: {new} (unchanged)[/]")
                        continue
                    mode_state[0] = new
                    tracer.event("mode_change", payload={
                        "from": old, "to": new, "source": "slash",
                    })
                    console.print(f"[dim]mode → {new}[/]")
                    continue
                if cmd == "/style":
                    # P3.3: flip the output style for the next turn. The
                    # in-flight system prompt isn't rebuilt here — `/clear`
                    # rebuilds the prompt, and the next /clear after a
                    # /style change picks up the new fragment. We do
                    # update the `output_style_state` so subsequent
                    # banner re-renders, status lines, and telemetry
                    # snapshots reflect the choice immediately.
                    sub = (arg or "").strip().lower()
                    old_style = current_output_style()
                    new_style: OutputStyle | None = None
                    if sub in ("concise", "explanatory"):
                        new_style = "concise" if sub == "concise" else "explanatory"
                    elif sub in ("toggle", ""):
                        new_style = (
                            "explanatory" if old_style == "concise" else "concise"
                        )
                    else:
                        tracer.event("slash_command", payload={
                            "cmd": cmd, "arg": arg, "error": "invalid_style",
                        })
                        console.print(
                            "[red]usage: /style concise|explanatory|toggle[/]"
                        )
                        continue
                    tracer.event("slash_command", payload={
                        "cmd": cmd,
                        "arg": sub or "toggle",
                        "from": old_style,
                        "to": new_style,
                    })
                    if new_style == old_style:
                        console.print(
                            f"[dim]output style: {new_style} (unchanged)[/]"
                        )
                        continue
                    output_style_state[0] = new_style
                    # The system-prompt fragment for `explanatory` lands
                    # in the prefix on the next /clear (or the next
                    # session). Document the lag in the user-facing line
                    # so they know to /clear if they want it active for
                    # the very next call.
                    tracer.event("output_style_change", payload={
                        "from": old_style,
                        "to": new_style,
                        "source": "slash",
                    })
                    console.print(
                        f"[dim]output style → {new_style} "
                        f"(/clear to apply to current conversation)[/]"
                    )
                    continue
                if cmd == "/compact":
                    # Manual compaction (P2.5). The optional `arg` becomes
                    # the focus hint passed to the weak-model summary.
                    focus = arg.strip() if arg else None
                    tracer.event("slash_command", payload={
                        "cmd": cmd, "focus": focus,
                    })
                    weak_cfg = load_model_config()
                    weak_client = client.with_model(weak_cfg.weak_model)
                    try:
                        new_messages, stats = compact_messages(
                            messages, weak_client, focus=focus,
                            tracer=tracer, turn=0,
                        )
                    except Exception as exc:
                        console.print(
                            f"[red]compaction failed:[/] {type(exc).__name__}: {exc}"
                        )
                        tracer.event("compaction_run", payload={
                            "trigger": "manual",
                            "before_tokens": 0,
                            "after_tokens": 0,
                            "summary_chars": 0,
                            "focus": focus,
                            "elapsed_ms": 0,
                            "error_type": type(exc).__name__,
                        })
                        continue
                    messages[:] = new_messages
                    tracer.event("compaction_run", payload={
                        "trigger": "manual",
                        "before_tokens": stats["before_tokens"],
                        "after_tokens": stats["after_tokens"],
                        "summary_chars": stats["summary_chars"],
                        "focus": focus,
                        "elapsed_ms": stats["elapsed_ms"],
                        "usage": stats.get("usage"),
                        "cost_billed_microcents": stats.get(
                            "cost_billed_microcents", 0,
                        ),
                    })
                    renderer.compaction_notification(
                        stats["before_tokens"], stats["after_tokens"], focus,
                    )
                    if stats.get("usage"):
                        renderer.show_usage(
                            stats["usage"],
                            weak_cfg.weak_model,
                            slot="weak",
                        )
                    continue
                if cmd == "/last":
                    try:
                        n = int(arg) if arg else 1
                    except ValueError:
                        tracer.event("slash_command", payload={
                            "cmd": cmd, "arg": arg, "error": "invalid_int",
                        })
                        console.print(f"[red]/last expects an integer (got {arg!r})[/]")
                        continue
                    items = list(renderer.recent_results)
                    idx = len(items) - n
                    found = bool(items) and 0 <= idx < len(items) and n > 0
                    tracer.event("slash_command", payload={
                        "cmd": cmd, "n": n, "found": found,
                        "available": len(items),
                    })
                    if not found:
                        console.print("[dim]no recent result at that position.[/]")
                        continue
                    title, full = items[idx]
                    console.print(Panel(
                        full or "(empty)",
                        title=title,
                        title_align="left",
                        border_style="dim",
                        expand=False,
                    ))
                    continue
                if cmd == "/mcp":
                    # P4.2: list connected MCP servers + tool counts.
                    rows = mcp_summarize_servers(mcp_session) if mcp_session else []
                    tracer.event("slash_command", payload={
                        "cmd": cmd, "total": len(rows),
                    })
                    if not rows:
                        console.print(
                            "[dim]no MCP servers configured. Add them to "
                            ".fred/settings.json under `mcp`.[/]"
                        )
                        continue
                    body = Text()
                    for row in rows:
                        # Status colour: green/yellow/red. The status
                        # vocabulary mirrors `mcp.lifecycle` constants.
                        status = row["status"]
                        colour = (
                            "green" if status == "connected"
                            else "red" if status == "crashed"
                            else "dim"
                        )
                        body.append(f"{row['name']}", style="bold")
                        body.append(f"  [{status}]", style=colour)
                        body.append(
                            f"  · {row['transport']}"
                            f"  · {row['tool_count']} tool"
                            f"{'s' if row['tool_count'] != 1 else ''}"
                            f"  · {row['init_ms']}ms\n",
                            style="dim",
                        )
                        if row["error"]:
                            err_short = (
                                row["error"] if len(row["error"]) <= 80
                                else row["error"][:80] + "…"
                            )
                            body.append(f"  error: {err_short}\n", style="red")
                        for tool_name in row["tools"][:8]:
                            body.append(
                                f"  • mcp__{row['name']}__{tool_name}\n",
                                style="dim",
                            )
                        if len(row["tools"]) > 8:
                            body.append(
                                f"  …and {len(row['tools']) - 8} more\n",
                                style="dim",
                            )
                    console.print(Panel(
                        body,
                        title="MCP servers",
                        title_align="left",
                        border_style="cyan",
                        expand=False,
                    ))
                    continue
                if cmd == "/hooks":
                    total = sum(len(hooks_config.get(ev, [])) for ev in VALID_EVENTS)
                    tracer.event("slash_command", payload={
                        "cmd": cmd, "total": total,
                    })
                    if total == 0:
                        console.print(
                            "[dim]no hooks configured. Add them to "
                            ".fred/settings.json or ~/.fred/settings.json.[/]"
                        )
                        continue
                    body = Text()
                    for ev in VALID_EVENTS:
                        entries = hooks_config.get(ev, [])
                        if not entries:
                            continue
                        body.append(f"{ev}\n", style="bold")
                        for h in entries:
                            cmd_short = (
                                h.command if len(h.command) <= 60
                                else h.command[:60] + "…"
                            )
                            matcher_str = h.matcher or "*"
                            body.append(
                                f"  • [{matcher_str}]  {cmd_short}  "
                                f"(timeout {h.timeout}s)\n",
                                style="dim",
                            )
                    console.print(Panel(
                        body,
                        title="active hooks",
                        title_align="left",
                        border_style="cyan",
                        expand=False,
                    ))
                    continue
                if cmd == "/perms":
                    # P3.1 permission rules. Three forms:
                    #   /perms                          → list active rules
                    #   /perms add <rule> <list>        → append to local file
                    #   /perms remove <rule>            → remove from any list
                    sub = (arg or "").strip()
                    if not sub:
                        # List form: read live rules off the policy so the
                        # user sees what was loaded at session start PLUS
                        # any [a]llow picks they made this session (the
                        # Panel writes through to permissions.rules).
                        active = list(list_active_rules(permissions.rules))
                        tracer.event("slash_command", payload={
                            "cmd": cmd, "action": "list",
                            "total": len(active),
                        })
                        if not active:
                            console.print(
                                "[dim]no permission rules. Add them to "
                                ".fred/settings.json (project) or "
                                ".fred/settings.local.json (local, "
                                "gitignored).[/]"
                            )
                            continue
                        body = Text()
                        # Group by list_name for a clean read; the helper
                        # already yields in deny → ask → allow order.
                        current_list: str | None = None
                        for list_name, rule in active:
                            if list_name != current_list:
                                body.append(f"{list_name}\n", style="bold")
                                current_list = list_name
                            body.append(f"  • {rule}\n", style="dim")
                        console.print(Panel(
                            body,
                            title="permission rules",
                            title_align="left",
                            border_style="cyan",
                            expand=False,
                        ))
                        continue
                    parts2 = sub.split()
                    action = parts2[0].lower()
                    if action == "add":
                        # Expect: add <rule...> <list_name>. The list name
                        # is the LAST whitespace-separated token so a
                        # rule containing spaces (e.g. "Bash(git status *)")
                        # round-trips cleanly.
                        if len(parts2) < 3:
                            tracer.event("slash_command", payload={
                                "cmd": cmd, "action": "add",
                                "error": "missing_args",
                            })
                            console.print(
                                "[red]usage: /perms add <rule> <list>  "
                                "(list: allow|ask|deny)[/]"
                            )
                            continue
                        list_name = parts2[-1].lower()
                        rule_str = " ".join(parts2[1:-1]).strip()
                        if list_name not in ("allow", "ask", "deny") or not rule_str:
                            tracer.event("slash_command", payload={
                                "cmd": cmd, "action": "add",
                                "error": "invalid_args",
                                "list": list_name,
                            })
                            console.print(
                                "[red]usage: /perms add <rule> <list>  "
                                "(list: allow|ask|deny)[/]"
                            )
                            continue
                        try:
                            added = add_permission_rule(rule_str, list_name)
                        except ValueError as e:
                            tracer.event("slash_command", payload={
                                "cmd": cmd, "action": "add",
                                "error": str(e),
                            })
                            console.print(f"[red]/perms add: {e}[/]")
                            continue
                        # Mirror the addition into the live engine so the
                        # rule takes effect this session without a reload.
                        if added:
                            getattr(permissions.rules, list_name).append(rule_str)
                        tracer.event("slash_command", payload={
                            "cmd": cmd, "action": "add",
                            "list": list_name, "rule": rule_str,
                            "added": bool(added),
                        })
                        if added:
                            console.print(
                                f"[dim]added {list_name}: {rule_str}[/]"
                            )
                        else:
                            console.print(
                                f"[dim]rule already in {list_name}: "
                                f"{rule_str}[/]"
                            )
                        continue
                    if action == "remove":
                        if len(parts2) < 2:
                            tracer.event("slash_command", payload={
                                "cmd": cmd, "action": "remove",
                                "error": "missing_args",
                            })
                            console.print(
                                "[red]usage: /perms remove <rule>[/]"
                            )
                            continue
                        rule_str = " ".join(parts2[1:]).strip()
                        removed = remove_permission_rule(rule_str)
                        # Live engine cleanup so the rule stops firing
                        # this session even before the next reload.
                        if removed:
                            for bucket_name in ("allow", "ask", "deny"):
                                bucket = getattr(permissions.rules, bucket_name)
                                while rule_str in bucket:
                                    bucket.remove(rule_str)
                        tracer.event("slash_command", payload={
                            "cmd": cmd, "action": "remove",
                            "rule": rule_str, "removed": bool(removed),
                        })
                        if removed:
                            console.print(f"[dim]removed: {rule_str}[/]")
                        else:
                            console.print(
                                f"[dim]not found in any list: {rule_str}[/]"
                            )
                        continue
                    tracer.event("slash_command", payload={
                        "cmd": cmd, "action": action, "error": "unknown_action",
                    })
                    console.print(
                        "[red]usage: /perms | /perms add <rule> <list> | "
                        "/perms remove <rule>[/]"
                    )
                    continue
                if cmd == "/checkpoints":
                    # P4.3: list the most-recent shadow-git checkpoints
                    # taken in this workspace. Empty list when the
                    # checkpointer is disabled, the bare repo doesn't
                    # exist yet (no write tools have run this session),
                    # or git failed to read.
                    tracer.event("slash_command", payload={"cmd": cmd})
                    if checkpointer is None:
                        console.print(
                            "[dim]checkpoints disabled "
                            "(set FRED_CHECKPOINTS=1 to enable).[/]"
                        )
                        continue
                    entries = checkpointer.list(limit=20)
                    if not entries:
                        console.print(
                            "[dim]no checkpoints yet. "
                            "They land after each successful write tool.[/]"
                        )
                        continue
                    body = Text()
                    for entry in entries:
                        ts = entry.ts.astimezone().strftime("%H:%M:%S")
                        body.append(f"  {entry.sha[:7]}  ", style="cyan")
                        body.append(f"{ts}  ", style="dim")
                        msg = entry.message
                        if len(msg) > 80:
                            msg = msg[:80] + "…"
                        body.append(f"{msg}\n")
                    console.print(Panel(
                        body,
                        title=f"checkpoints (last {len(entries)})",
                        title_align="left",
                        border_style="dim",
                        expand=False,
                    ))
                    continue
                if cmd == "/restore":
                    # P4.3: rewind the workspace to a specific checkpoint
                    # SHA. Requires explicit `y/n` confirmation because
                    # this OVERWRITES files on disk — defense in depth
                    # for an interactive `Live`-region-quiet REPL where
                    # an accidental enter could otherwise nuke work.
                    target_sha = (arg or "").strip()
                    if checkpointer is None:
                        tracer.event("slash_command", payload={
                            "cmd": cmd, "error": "disabled",
                        })
                        console.print(
                            "[dim]checkpoints disabled "
                            "(set FRED_CHECKPOINTS=1 to enable).[/]"
                        )
                        continue
                    if not target_sha:
                        tracer.event("slash_command", payload={
                            "cmd": cmd, "error": "missing_sha",
                        })
                        console.print(
                            "[red]usage: /restore <sha>  "
                            "(use /checkpoints to find one)[/]"
                        )
                        continue
                    # Confirm before mutating the worktree. The default
                    # answer is `n`; only an explicit `y` proceeds.
                    console.print(
                        f"[yellow]restore workspace to {target_sha[:7]}? "
                        "this overwrites files on disk.[/]"
                    )
                    try:
                        answer = input("  proceed? (y/N): ").strip().lower()
                    except (EOFError, KeyboardInterrupt):
                        answer = ""
                    if answer != "y":
                        tracer.event("slash_command", payload={
                            "cmd": cmd, "sha": target_sha,
                            "confirmed": False,
                        })
                        console.print("[dim]restore cancelled.[/]")
                        continue
                    stats = checkpointer.restore(target_sha)
                    tracer.event("slash_command", payload={
                        "cmd": cmd, "sha": target_sha,
                        "confirmed": True,
                        "files_changed": stats.get("files_changed"),
                    })
                    tracer.event("checkpoint_restore", payload={
                        "sha": target_sha,
                        "files_changed": stats.get("files_changed"),
                        "files_only": stats.get("files_only", False),
                    })
                    console.print(
                        f"[dim]restored {target_sha[:7]} "
                        f"({stats.get('files_changed', 0)} file(s) "
                        f"checked out).[/]"
                    )
                    continue
                tracer.event("slash_command", payload={"cmd": cmd, "unknown": True})
                console.print(f"[red]unknown command: {line}[/]  (try /help)")
                continue
            if line.startswith("!"):
                replacement, raw_cmd, rc = expand_bang(line)
                console.print(f"[cyan]$ {raw_cmd}[/]")
                console.print(replacement)
                tracer.event("input_bang", payload={
                    "cmd": (raw_cmd or "")[:200],
                    "exit": rc,
                    "out_len": len(replacement),
                })
                line = replacement
            mention_count = count_mentions(line) if "@" in line else 0
            if mention_count:
                expanded = expand_mentions(line)
                tracer.event("input_mentions", payload={
                    "count": mention_count,
                    "in_len": len(line),
                    "out_len": len(expanded),
                })
                line = expanded

            # UserPromptSubmit hook (P2.4): exit-2 cancels the turn before
            # any model call. We print a brief banner and continue the REPL
            # so the user can edit + retry.
            up_outcome = run_hooks(
                "UserPromptSubmit",
                hooks_config,
                tracer=tracer,
                user_input=line,
            )
            if up_outcome is not None and up_outcome.blocked:
                cmd_short = up_outcome.hook.command if up_outcome.hook else ""
                console.print(f"[red]⊘ blocked by UserPromptSubmit hook: {cmd_short}[/]")
                continue

            session_state.update_from_user_input(line)
            run_turn(
                line, messages, client, registry, renderer, permissions,
                tracer=tracer, repo_map_provider=repo_map_provider,
                hooks_config=hooks_config,
                rule_set=rule_set,
                chat_files_provider=_chat_files_provider,
                checkpointer=checkpointer,
                architect=architect,
            )
            # Path tracking for the repo map's personalization vector
            # is driven by the tools themselves (`view`, `create_file`,
            # `str_replace` call `mark_tracked` on success via the
            # `_session_files` ContextVar installed at session start).
            # No post-turn sweep is needed — it would over-count
            # against the P1.4 prior-Read enforcement contract.
            renderer.show_todos()
            # P3.3: status line after each turn finishes. The line is
            # mutually exclusive with the assistant Live region (already
            # exited above by `run_turn`), so this is the right
            # integration seam. Defense-in-depth: never let a bad status
            # render kill the REPL.
            try:
                _emit_status_line()
            except Exception:
                pass
    except Exception as e:
        end_reason = "crash"
        tracer.event("api_error", payload={"type": type(e).__name__, "message": str(e)[:500]})
        raise
    finally:
        # P3.4: terminate any still-running background bash procs BEFORE
        # the Stop hook fires so the tracer event order is sensible
        # (bash_bg_kill before Stop). The ContextVar is still installed
        # at this point; cleanup() walks the session-scoped procs dict.
        try:
            _bash_bg.cleanup()
        except Exception:
            pass
        # P4.2: SIGTERM every MCP server with a brief grace period so
        # the tracer's `mcp_server_disconnect` events land before the
        # Stop hook fires. Graceful failures are swallowed; cleanup is
        # idempotent so a re-run during shutdown is safe.
        if mcp_session is not None:
            try:
                def _mcp_emit(kind: str, payload: dict) -> None:
                    try:
                        tracer.event(kind, payload=payload)
                    except Exception:
                        pass
                mcp_cleanup_servers(mcp_session, on_event=_mcp_emit)
            except Exception:
                pass
        # Stop hook (P2.4): best-effort, exit codes are advisory. We swallow
        # all exceptions because nothing in the shutdown path can recover
        # from a hook failure.
        try:
            run_hooks(
                "Stop",
                hooks_config,
                tracer=tracer,
                reason=end_reason,
            )
        except Exception:
            pass
        _bash_bg.reset_event_emitter(_bash_bg_emit_token)
        _bash_bg.reset_session_state(_bash_bg_state_token)
        reset_tracked_files(_tracked_files_token)
        reset_mode_state(_mode_state_token)
        _reset_todos(_todos_token)
        reset_sandbox_mode(_sandbox_mode_token)
        tracer.end_session(reason=end_reason)
        # 5s drain — gives the remote-writer path time to flush an
        # in-flight POST when the upstream is slow (5xx + retries).
        # Local Postgres writes are sub-second; this only matters for
        # the centralized telemetry path.
        tracer.drain(timeout=5.0)


def _print_server_cost(console: Console) -> None:
    """Append a single line with server-authoritative balance + last-hour
    spend. Silent fallback on any error so /cost stays robust."""
    creds = _auth.load_credentials()
    if not creds:
        return
    try:
        import httpx

        auth_base = _auth.DEFAULT_AUTH_BASE_URL.rstrip("/")
        with httpx.Client(timeout=2.5) as client:
            resp = client.get(
                f"{auth_base}/api/cli/whoami",
                headers={"Authorization": f"Bearer {creds.api_key}"},
            )
        if resp.status_code != 200:
            return
        body = resp.json()
        bal = body.get("balanceMicrocents", 0) / 1_000_000
        bal_str = f"${bal:.4f}" if abs(bal) < 0.01 else f"${bal:.2f}"
        if body.get("isInternal"):
            console.print("[dim]server  : balance ∞ (internal account)[/]")
        else:
            console.print(f"[dim]server  : balance {bal_str}[/]")
    except Exception:
        # Server unreachable, no creds, etc — silently skip.
        return


@app.command(name="login")
def cmd_login(
    device_code: bool = typer.Option(
        False,
        "--device-code",
        help="Headless flow — print a URL + code, poll until approved. Use on SSH boxes.",
    ),
) -> None:
    """Authenticate with Fred and store a credential locally."""
    console = Console()
    flow = _auth.LoginFlow()
    try:
        creds = flow.login_device_code() if device_code else flow.login_browser()
    except _auth.LoginError as e:
        console.print(f"[red]Login failed:[/] {e}")
        raise typer.Exit(code=1)
    _auth.save_credentials(creds)
    who = creds.email or "(unknown email)"
    console.print(f"[green]✓[/] Logged in as [bold]{who}[/]")
    console.print(f"  base_url: {creds.base_url}")
    console.print(f"  saved to: {_auth.DEFAULT_CRED_PATH}")


@app.command(name="logout")
def cmd_logout() -> None:
    """Revoke the stored credential and remove it from disk."""
    console = Console()
    creds = _auth.load_credentials()
    if not creds:
        console.print("[dim]Already logged out.[/]")
        return
    revoked = _auth.revoke_remote(creds)
    _auth.delete_credentials()
    if revoked:
        console.print(f"[green]✓[/] Logged out and revoked the active key for {creds.email}.")
    else:
        console.print(
            f"[yellow]![/] Removed local credentials for {creds.email}, but couldn't reach the "
            "server to revoke. The key will continue to work until it expires."
        )


@app.command(name="whoami")
def cmd_whoami() -> None:
    """Print the active account email + balance + key prefix."""
    import httpx

    console = Console()
    creds = _auth.load_credentials()
    if not creds:
        console.print("[dim]Not logged in. Run `fred login`.[/]")
        raise typer.Exit(code=1)
    auth_base = _auth.DEFAULT_AUTH_BASE_URL.rstrip("/")
    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.get(
                f"{auth_base}/api/cli/whoami",
                headers={"Authorization": f"Bearer {creds.api_key}"},
            )
    except httpx.HTTPError as e:
        console.print(f"[red]Could not reach Fred:[/] {e}")
        raise typer.Exit(code=1)
    if resp.status_code == 401:
        console.print("[red]Credential rejected.[/] Run `fred logout` then `fred login` again.")
        raise typer.Exit(code=1)
    if resp.status_code != 200:
        console.print(f"[red]Server error {resp.status_code}:[/] {resp.text[:200]}")
        raise typer.Exit(code=1)
    body = resp.json()
    bal = body.get("balanceMicrocents", 0)
    bal_dollars = bal / 1_000_000
    bal_str = f"${bal_dollars:.4f}" if abs(bal_dollars) < 0.01 else f"${bal_dollars:.2f}"
    is_internal = body.get("isInternal")
    prefix = body.get("keyPrefix") or creds.api_key[:13]
    console.print(f"  email   : {body.get('email') or creds.email}")
    console.print(
        f"  balance : {bal_str}{' [dim](internal — billing disabled)[/]' if is_internal else ''}"
    )
    console.print(f"  key     : [dim]{prefix}…[/]")
    last = body.get("keyLastUsedAt")
    if last:
        console.print(f"  last use: [dim]{last}[/]")


@app.command(name="update")
def cmd_update(
    yes: bool = typer.Option(
        False, "--yes", "-y",
        help="Skip the y/N confirmation and run the upgrade immediately.",
    ),
    no_run: bool = typer.Option(
        False, "--no",
        help="Print the upgrade command and exit without running it.",
    ),
    check: bool = typer.Option(
        False, "--check",
        help="Force a fresh PyPI fetch instead of reading the cache.",
    ),
) -> None:
    """Check for and apply Fred updates."""
    console = Console()
    method = update_check.detect_install_method()
    latest = update_check.fetch_latest(force=check)
    rc = update_check.prompt_and_run_upgrade(
        method, latest, assume_yes=yes, no_run=no_run, console=console,
    )
    raise typer.Exit(code=rc)


@app.command(name="telemetry")
def cmd_telemetry(
    action: str = typer.Argument(
        "status",
        help="One of: status, on, off. Default: status.",
    ),
) -> None:
    """Manage behavioral telemetry routing (status, on, off)."""
    from fred.preferences import load_preferences, save_preferences

    console = Console()
    sub = action.strip().lower()
    if sub == "status":
        console.print(f"telemetry: {_telemetry_status_line()}")
        raise typer.Exit()
    if sub == "on":
        prefs = load_preferences()
        was = prefs.telemetry_opted_out
        prefs.telemetry_opted_out = False
        save_preferences(prefs)
        console.print(
            "telemetry: on (default routing to api.fredcode.net)"
            if was
            else "telemetry was already on."
        )
        raise typer.Exit()
    if sub == "off":
        prefs = load_preferences()
        was_off = prefs.telemetry_opted_out
        prefs.telemetry_opted_out = True
        save_preferences(prefs)
        console.print(
            "telemetry: off (opted out)"
            if not was_off
            else "telemetry was already off."
        )
        raise typer.Exit()
    console.print(f"[red]unknown action {action!r}; expected status, on, or off[/]")
    raise typer.Exit(code=2)


def main() -> None:
    app()


if __name__ == "__main__":
    main()
