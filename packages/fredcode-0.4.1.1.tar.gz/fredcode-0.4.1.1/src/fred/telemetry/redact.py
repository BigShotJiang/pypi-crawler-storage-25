"""Helpers for telemetry payloads: stable JSON, truncation, password-stripping."""
from __future__ import annotations

import hashlib
import json
from urllib.parse import urlparse, urlunparse


def canonical_json(value: object) -> str:
    """Stable JSON encoding for fingerprinting (sorted keys, no whitespace)."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def args_fingerprint(tool_name: str, args: object) -> str:
    payload = tool_name + "\x00" + canonical_json(args)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def truncate_field(s: str | None, limit: int) -> tuple[str | None, bool, int]:
    """Return (value, truncated_flag, full_byte_length).

    Bytes are measured as UTF-8 to match what Postgres stores. Truncation slices
    on the byte boundary nearest to (but not exceeding) `limit`, then decodes
    with `errors='ignore'` to avoid splitting a multi-byte char.
    """
    if s is None:
        return None, False, 0
    encoded = s.encode("utf-8")
    full = len(encoded)
    if full <= limit:
        return s, False, full
    truncated = encoded[:limit].decode("utf-8", errors="ignore")
    return truncated, True, full


def redact_url(url: str) -> str:
    """Strip the password from a postgres URL for safe display."""
    try:
        parts = urlparse(url)
    except Exception:
        return "<unparseable url>"
    if parts.password:
        netloc = parts.hostname or ""
        if parts.username:
            netloc = f"{parts.username}:***@{netloc}"
        if parts.port:
            netloc = f"{netloc}:{parts.port}"
        parts = parts._replace(netloc=netloc)
    return urlunparse(parts)
