"""Shared queue + drain machinery for telemetry writers.

Both ``BatchWriter`` (Postgres) and ``RemoteWriter`` (HTTP) need the
same producer/consumer plumbing: a bounded ``queue.Queue``, a
non-blocking ``submit`` that drops on full, a deadline-driven
``_collect_batch``, and a ``threading.Event``-based shutdown that
wakes a daemon blocked in ``queue.get`` via a ``None`` sentinel push.
That scaffolding used to live duplicated in both writers — ~150 lines
of subtly-different copies of the same loop, which is exactly the
shape of code where a one-side fix doesn't propagate.

Subclasses own:

- ``_to_wire(kind, params)`` — convert a tracer envelope into the
  payload that goes on the queue. ``BatchWriter`` keeps the
  ``(kind, params)`` tuple unchanged; ``RemoteWriter`` maps it to a
  PII-stripped dict and returns ``None`` for envelope kinds that
  shouldn't ship.
- ``_run_loop()`` — the daemon body. Each writer's retry/backoff
  semantics are different enough that unifying them would just push
  the if-statements into a config object. ``BatchWriter`` re-enqueues
  on transient ``OperationalError``; ``RemoteWriter`` retries inside
  its POST and drops after ``MAX_ATTEMPTS``. Both use
  ``self._collect_batch()`` and check ``self._stopped`` at loop head.
"""
from __future__ import annotations

import queue
import threading
import time
from abc import ABC, abstractmethod
from typing import Any


class TelemetryEngine(ABC):
    """Base class for telemetry writers.

    Public surface:

    - ``submit(kind, params)`` — non-blocking enqueue; drops silently
      and increments ``dropped_events`` on full queue.
    - ``start()`` — idempotent thread spin-up.
    - ``drain(timeout)`` — set the stop flag, wake the consumer, join
      with a deadline. Safe to call once at session end.
    - ``dropped_events`` — int counter, only mutated by ``submit``.

    Implementation contract for subclasses:

    - ``_to_wire(kind, params) -> Any | None`` returns the value put
      on the queue, or ``None`` to drop the envelope silently.
    - ``_run_loop()`` is the daemon body. Read items via
      ``self._collect_batch()``; check ``self._stopped`` at the head
      of every iteration; do whatever the backend needs after that.
    """

    def __init__(
        self,
        *,
        queue_size: int,
        batch_max: int,
        flush_interval_s: float,
        thread_name: str = "fred-telemetry",
    ) -> None:
        self._q: queue.Queue[Any] = queue.Queue(maxsize=queue_size)
        self._batch_max = batch_max
        self._flush_interval = flush_interval_s
        self._stopped = threading.Event()
        self._thread = threading.Thread(
            target=self._run_loop, name=thread_name, daemon=True
        )
        self._shutdown_sent = False
        self.dropped_events = 0

    # ---- producer side ---------------------------------------------------

    def start(self) -> None:
        """Spin up the daemon. Idempotent — safe to call twice."""
        if not self._thread.is_alive():
            self._thread.start()

    def submit(self, kind: str, params: dict) -> None:
        """Non-blocking enqueue. Drops silently on a full queue."""
        evt = self._to_wire(kind, params)
        if evt is None:
            return
        try:
            self._q.put_nowait(evt)
        except queue.Full:
            self.dropped_events += 1

    def drain(self, timeout: float = 2.0) -> None:
        """Best-effort shutdown.

        Sets the stop flag *before* the wakeup push so a consumer that
        returns from ``queue.get`` sees the flag immediately. The
        ``None`` push wakes a consumer blocked on an empty queue
        without dropping a real event — the previous sentinel-via-pop
        path could lose an event when the queue was full at drain
        time.
        """
        if self._shutdown_sent:
            return
        self._shutdown_sent = True
        self._stopped.set()
        try:
            self._q.put_nowait(None)
        except queue.Full:
            # Queue is full of real events; the consumer will see
            # ``_stopped`` at the next ``flush_interval`` poll boundary.
            pass
        self._thread.join(timeout=timeout)

    # ---- consumer side ---------------------------------------------------

    def _collect_batch(self) -> list[Any]:
        """Block briefly on the first item, drain the rest non-blocking.

        Returns whatever it has when the deadline expires or
        ``batch_max`` is hit. Wakeup ``None``s pushed by ``drain`` are
        skipped so they never end up in a real batch.
        """
        deadline = time.monotonic() + self._flush_interval
        batch: list[Any] = []
        try:
            first = self._q.get(timeout=self._flush_interval)
        except queue.Empty:
            return batch
        if first is None:
            return batch
        batch.append(first)
        while len(batch) < self._batch_max:
            timeout = max(0.0, deadline - time.monotonic())
            if timeout == 0.0:
                break
            try:
                env = self._q.get(timeout=timeout)
            except queue.Empty:
                break
            if env is None:
                continue
            batch.append(env)
        return batch

    @abstractmethod
    def _to_wire(self, kind: str, params: dict) -> Any | None:
        """Convert an envelope to the shape that goes on the queue.

        Return ``None`` to drop the envelope silently — RemoteWriter
        does this for tracer envelope kinds that aren't allowed to ship.
        """

    @abstractmethod
    def _run_loop(self) -> None:
        """Daemon-thread body. Subclass owns the retry strategy."""
