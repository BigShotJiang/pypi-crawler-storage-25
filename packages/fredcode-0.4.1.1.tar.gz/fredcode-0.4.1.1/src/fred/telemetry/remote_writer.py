"""HTTP batch writer for centralized telemetry to api.fredcode.net.

Same ``submit()`` + ``drain()`` interface as ``BatchWriter`` (the
self-hosted Postgres writer), inherited from
``fred.telemetry._engine.TelemetryEngine``. The base owns the queue,
the wakeup-via-``None`` shutdown protocol, and ``_collect_batch``;
this class adds the privacy-policy mapping (``_to_wire``) and the
HTTP retry loop (``_run_loop``).

Privacy contract enforced client-side:

- Every envelope is mapped to a remote event format that DROPS text
  fields (user_input, assistant_text, system_prompt_text, result_text,
  args, raw_arguments) and identifying machine-state fields (hostname,
  cwd, git_commit). The server validates again as a second line of
  defense.
- The mapping ``_to_wire(...)`` is the single chokepoint where this
  policy lives. New envelope kinds default to ``None`` (drop silently)
  rather than passing arbitrary fields through.

Retry policy: HTTP failures retry up to ``_MAX_ATTEMPTS`` with
exponential backoff; after that the batch is dropped and counted as
``failed_total``.
"""
from __future__ import annotations

import json
import time
from datetime import datetime
from typing import Any

import httpx

from fred.telemetry._engine import TelemetryEngine

_QUEUE_MAX = 10_000
_BATCH_FLUSH_AT = 50
_BATCH_INTERVAL_S = 5.0
_MAX_ATTEMPTS = 3
_HTTP_TIMEOUT_S = 10.0


def _iso(value: Any) -> str | None:
    """Serialize a datetime (or already-string) to ISO-8601 with TZ."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value)


def _maybe_parse_json(value: Any) -> Any:
    """If value is a JSON string, parse it; otherwise pass through.

    PgTracer hands JSON-encoded strings into `tool_catalog`, `config_snapshot`,
    and event `payload`. The remote endpoint expects native JSON values
    (the Worker's neon driver serializes JSONB itself), so we round-trip
    the string into a dict/list before queueing.
    """
    if value is None:
        return None
    if isinstance(value, str):
        try:
            return json.loads(value)
        except (json.JSONDecodeError, ValueError):
            return None
    return value


class RemoteWriter(TelemetryEngine):
    """Background HTTP POST batcher for the central telemetry endpoint."""

    def __init__(self, endpoint: str, api_key: str) -> None:
        super().__init__(
            queue_size=_QUEUE_MAX,
            batch_max=_BATCH_FLUSH_AT,
            flush_interval_s=_BATCH_INTERVAL_S,
            thread_name="fred-telemetry-writer",
        )
        self._endpoint = endpoint
        self._api_key = api_key
        # Surfaced by the future ``/telemetry status`` slash if we ever
        # want to debug a quiet pipeline. ``dropped_events`` (inherited)
        # counts queue-full drops at submit time; ``failed_total``
        # counts batches that exhausted retries inside the POST loop.
        self.sent_total = 0
        self.failed_total = 0

    # Convenience alias — the original RemoteWriter exposed
    # ``dropped_total`` for queue-full drops; keep the name available so
    # an external observability hook that read the field still works.
    @property
    def dropped_total(self) -> int:
        return self.dropped_events

    # ---- TelemetryEngine hooks --------------------------------------------

    def _to_wire(self, envelope_kind: str, params: dict) -> dict | None:
        """Convert a PgTracer envelope to the remote event shape.

        This is the privacy chokepoint. New PgTracer envelope kinds
        default to `None` (drop) rather than passing arbitrary fields
        through. Adding a new kind here is the deliberate moment to
        decide what gets sent.
        """
        if envelope_kind == "session_start":
            return {
                "kind": "session_start",
                "session_id": params["session_id"],
                "parent_session_id": params.get("parent_session_id"),
                "session_kind": params.get("session_kind", "root"),
                "started_at": _iso(params["started_at"]),
                # PgTracer params use "fred_version" for legacy reasons; the
                # remote schema calls it "fred_version".
                "fred_version": params.get("fred_version", "unknown"),
                "python_version": params["python_version"],
                "os": params["os"],
                "shell": params.get("shell"),
                "git_dirty": params.get("git_dirty"),
                "agents_md_sha256": params.get("agents_md_sha256"),
                "model": params["model"],
                "yolo_initial": bool(params.get("yolo_initial")),
                "one_shot": bool(params.get("one_shot")),
                "system_prompt_sha256": params["system_prompt_sha256"],
                "client_pid": int(params["client_pid"]),
                "tool_catalog": _maybe_parse_json(params.get("tool_catalog")),
                "config_snapshot": _maybe_parse_json(params.get("config_snapshot")),
                # Drop: hostname, cwd, git_commit, system_prompt_text, base_url
            }
        if envelope_kind == "session_end":
            return {
                "kind": "session_end",
                "session_id": params["session_id"],
                "ended_at": _iso(params["ended_at"]),
                "end_reason": params["end_reason"],
            }
        if envelope_kind == "turn":
            user_input = params.get("user_input")
            assistant_text = params.get("assistant_text")
            return {
                "kind": "turn_complete",
                "turn_id": params["turn_id"],
                "session_id": params["session_id"],
                "turn_index": int(params["turn_index"]),
                "iteration_index": int(params["iteration_index"]),
                "started_at": _iso(params["started_at"]),
                "ended_at": _iso(params.get("ended_at")),
                "finish_reason": params.get("finish_reason"),
                "prompt_tokens": params.get("prompt_tokens"),
                "completion_tokens": params.get("completion_tokens"),
                "cached_tokens": params.get("cached_tokens"),
                "context_used_est": params.get("context_used_est"),
                "budget_status": params.get("budget_status"),
                "api_error_type": params.get("api_error_type"),
                "duration_ms": params.get("duration_ms"),
                "num_tool_calls": int(params.get("num_tool_calls") or 0),
                "mode": params.get("mode", "act"),
                "slot": params.get("slot", "main"),
                "model": params.get("model"),
                "cost_billed_microcents": params.get("cost_billed_microcents"),
                # Lengths only — never the text. PgTracer may have
                # already nulled these via FRED_TELEMETRY_NO_TEXT; if
                # so the chars become None.
                "user_input_chars": len(user_input) if user_input else None,
                "assistant_text_chars": len(assistant_text) if assistant_text else None,
                # Drop: user_input, assistant_text, *_truncated, api_error_message
            }
        if envelope_kind == "tool_call":
            return {
                "kind": "tool_call",
                "tool_call_id": params["tool_call_id"],
                "turn_id": params["turn_id"],
                "session_id": params["session_id"],
                "call_index": int(params["call_index"]),
                "openai_call_id": params["openai_call_id"],
                "tool_name": params["tool_name"],
                "args_fingerprint": params["args_fingerprint"],
                "parse_error": params.get("parse_error"),
                "permission_outcome": params.get("permission_outcome"),
                "permission_prompt_ms": params.get("permission_prompt_ms"),
                "outcome": params["outcome"],
                "handler_exception_type": params.get("handler_exception_type"),
                "result_full_bytes": params.get("result_full_bytes"),
                "result_starts_with_error": bool(
                    params.get("result_starts_with_error", False)
                ),
                "duration_ms": int(params["duration_ms"]),
                "started_at": _iso(params["started_at"]),
                "ended_at": _iso(params["ended_at"]),
                # Drop: args, raw_arguments, result_text, result_truncated
            }
        if envelope_kind == "event":
            return {
                "kind": "event",
                "session_id": params["session_id"],
                "turn_id": params.get("turn_id"),
                "ts": _iso(params.get("ts")),
                # PgTracer's nested `kind` is the event name; the outer
                # "kind" in our wire format is always "event".
                "event_kind": params.get("kind", "unknown"),
                "payload": _maybe_parse_json(params.get("payload")),
            }
        return None

    # ---- consumer side ----------------------------------------------------

    def _run_loop(self) -> None:
        """Daemon loop: drain the queue into batches, POST, repeat."""
        with httpx.Client(timeout=_HTTP_TIMEOUT_S) as client:
            while not self._stopped.is_set():
                batch = self._collect_batch()
                if not batch:
                    continue
                self._post_with_retry(client, batch)
            # Final flush: drain whatever's still queued so a slow caller
            # that submitted right before drain() doesn't lose events.
            tail = self._collect_batch()
            if tail:
                self._post_with_retry(client, tail)

    def _post_with_retry(self, client: httpx.Client, batch: list[dict]) -> None:
        body = {"events": batch}
        for attempt in range(1, _MAX_ATTEMPTS + 1):
            try:
                resp = client.post(
                    self._endpoint,
                    json=body,
                    headers={"Authorization": f"Bearer {self._api_key}"},
                )
                if resp.status_code in (200, 202):
                    self.sent_total += len(batch)
                    return
                # 4xx: don't retry, bad request
                if 400 <= resp.status_code < 500:
                    self.failed_total += len(batch)
                    return
                # 5xx: retry with backoff
            except httpx.HTTPError:
                pass
            if attempt < _MAX_ATTEMPTS:
                time.sleep(0.5 * (2 ** (attempt - 1)))
        self.failed_total += len(batch)
