"""Postgres-backed telemetry for fred.

Importing this module never connects to anything. Call `make_tracer()` to
construct a Tracer; if `FRED_TELEMETRY_DB_URL` is unset, you get a NullTracer
with zero overhead.
"""
from fred.telemetry.tracer import (
    IterationHandle,
    NullTracer,
    PgTracer,
    Tracer,
    TurnHandle,
    make_tracer,
)

__all__ = [
    "IterationHandle",
    "NullTracer",
    "PgTracer",
    "Tracer",
    "TurnHandle",
    "make_tracer",
]
