"""The Tracer interface, NullTracer, and PgTracer.

The agent loop calls Tracer methods at well-known seams. NullTracer no-ops;
PgTracer enqueues envelopes onto a BatchWriter for a background thread to
INSERT.

UUIDs are minted on the producer side so callers (and replay tooling) can
reference rows immediately without RETURNING round-trips.
"""
from __future__ import annotations

import json
import os
import platform
import socket
import subprocess
import sys
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol

from fred.client import ToolCall
from fred.cost import billed_microcents
from fred.telemetry.redact import args_fingerprint, sha256_text, truncate_field


_RESULT_LIMIT = 64 * 1024
_TEXT_LIMIT = 32 * 1024


def _no_text() -> bool:
    return os.environ.get("FRED_TELEMETRY_NO_TEXT") == "1"


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _git_meta() -> tuple[str | None, bool | None]:
    try:
        commit = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            check=True, capture_output=True, text=True, timeout=2,
        ).stdout.strip()
    except Exception:
        return None, None
    try:
        status = subprocess.run(
            ["git", "status", "--porcelain"],
            check=True, capture_output=True, text=True, timeout=2,
        ).stdout
        return commit, bool(status.strip())
    except Exception:
        return commit, None


def _agents_md_hash() -> str | None:
    for name in ("AGENTS.md", "CLAUDE.md"):
        p = Path.cwd() / name
        if p.exists():
            try:
                return sha256_text(p.read_text(encoding="utf-8"))
            except OSError:
                return None
    return None


@dataclass
class TurnHandle:
    turn_index: int
    user_input: str | None


@dataclass
class IterationHandle:
    turn_id: str
    session_id: str
    turn_index: int
    iteration_index: int
    started_at: datetime
    user_input: str | None
    context_used_est: int
    budget_status: str
    # P2.2: mode for this iteration ("act" | "plan"). Persisted on
    # `fred_turns.mode`; defaults to "act" so legacy callers keep
    # working unchanged.
    mode: str = "act"
    # Multi-model routing slot the iteration consumed. One of
    # main|editor|weak|subagent_main. Subagents pass "subagent_main"
    # via `run_session(iteration_slot=...)`. Persisted on
    # `fred_turns.slot`.
    slot: str = "main"
    # Concrete model name behind the slot at iteration time. Persisted
    # on `fred_turns.model` so per-row cost reconstruction stays valid
    # even after `/model` swaps. None for legacy / NullTracer paths.
    model: str | None = None
    # How the iteration terminated. Set by the session loop immediately
    # before `end_iteration(...)` at every return path. Persisted on
    # `fred_turns.terminator_kind`. NULL is the legacy signal (the column
    # was added before any callsite wired it). Values:
    # 'attempt_completion' | 'exit_plan_mode' | 'natural_stop' |
    # 'error_abort' | 'interrupt' | 'compaction_break' | 'runaway_guard'.
    terminator_kind: str | None = None
    # PR-D2: per-iteration todo snapshot (todos_state_payload(...) shape).
    # Mirrors the per-iteration `todos_state` event row but lives on the
    # turn so analytics queries don't need a fred_events join. Set by
    # session.py at the same callsite that emits the event. None on
    # NullTracer paths or when the snapshot wasn't computed.
    todos_snapshot: dict | None = None


class Tracer(Protocol):
    @property
    def session_id(self) -> str: ...
    def start_session(self, *, model: str, base_url: str, yolo: bool, one_shot: bool,
                      system_prompt: str, registry_names: list[str],
                      registry_perms: dict[str, bool],
                      config_snapshot: dict | None = None) -> None: ...
    def end_session(self, *, reason: str) -> None: ...
    def start_turn(self, *, user_input: str | None) -> TurnHandle: ...
    def start_iteration(self, turn: TurnHandle, *, iteration_index: int,
                        context_used_est: int, budget_status: str,
                        mode: str = "act",
                        slot: str = "main",
                        model: str | None = None) -> IterationHandle: ...
    def end_iteration(self, it: IterationHandle, *, assistant_text: str,
                      tool_calls: list[ToolCall], finish_reason: str | None,
                      usage: dict | None,
                      api_error: BaseException | None) -> None: ...
    def record_tool_call(self, it: IterationHandle, *, call: ToolCall, call_index: int,
                         outcome: str, permission_outcome: str | None,
                         permission_prompt_ms: int | None, result: str,
                         duration_ms: int, started_at: datetime, ended_at: datetime,
                         handler_exception_type: str | None) -> None: ...
    def event(self, kind: str, *, payload: dict | None = None,
              turn: TurnHandle | None = None) -> None: ...
    def drain(self, timeout: float = 2.0) -> None: ...
    def fork_subagent(self, *, parent_session_id: str | None,
                      parent_iteration_id: str | None,
                      agent_label: str,
                      agent_tool_subset: list[str]) -> "Tracer": ...


class NullTracer:
    """No-op Tracer. Used when telemetry is disabled."""

    # NullTracer is parameter-free; the empty session_id is fine for callers
    # that propagate it as `parent_session_id` (the schema's NULL semantics
    # are preserved by the PgTracer path, not by NullTracer's bookkeeping).
    session_id: str = ""

    def start_session(self, **_): pass
    def end_session(self, **_): pass

    def start_turn(self, *, user_input=None) -> TurnHandle:
        return TurnHandle(turn_index=0, user_input=user_input)

    def start_iteration(self, turn, *, iteration_index, context_used_est, budget_status,
                        mode="act", slot="main", model=None):
        return IterationHandle(
            turn_id="", session_id="", turn_index=turn.turn_index,
            iteration_index=iteration_index, started_at=_now(),
            user_input=turn.user_input if iteration_index == 0 else None,
            context_used_est=context_used_est, budget_status=budget_status,
            mode=mode, slot=slot, model=model,
        )

    def end_iteration(self, it, **_): pass
    def record_tool_call(self, it, **_): pass
    def event(self, kind, *, payload=None, turn=None): pass
    def drain(self, timeout=2.0): pass

    def fork_subagent(self, **_) -> "NullTracer":
        # A child NullTracer is indistinguishable from any other NullTracer;
        # the recursion-prevention contract (no `agent` tool inside subagents)
        # lives at the registry layer in `agent_tool.py`, not here.
        return NullTracer()


class PgTracer:
    """Real Tracer. Lazily-built envelopes; all DB work is done in BatchWriter."""

    def __init__(self, writer, *, parent_session_id: str | None = None,
                 session_kind: str = "root") -> None:
        self._writer = writer
        self._session_id: str = str(uuid.uuid4())
        self._turn_index: int = -1
        # P2.1: when this tracer was forked from a parent session (subagent
        # dispatch), `_parent_session_id` is the parent's UUID and
        # `_session_kind` is one of "subagent" / "plan". Both surface in
        # the fred_sessions row so cost rollups (fred_session_cost_rollup
        # view) can attribute child tokens up to root sessions.
        self._parent_session_id = parent_session_id
        self._session_kind = session_kind
        # Map IterationHandle.turn_id -> turn metadata so we can write the row
        # only ONCE (on end_iteration), not twice. We don't need per-turn
        # flushing because the row is small and writing one INSERT per
        # iteration is cheap.

    # ---- session ---------------------------------------------------------

    @property
    def session_id(self) -> str:
        return self._session_id

    def start_session(self, *, model, base_url, yolo, one_shot, system_prompt,
                      registry_names, registry_perms, config_snapshot=None):
        commit, dirty = _git_meta()
        params = {
            "session_id": self._session_id,
            "started_at": _now(),
            "fred_version": _fred_version(),
            "python_version": platform.python_version(),
            "os": f"{platform.system()} {platform.release()}",
            "shell": os.environ.get("SHELL"),
            "cwd": str(Path.cwd()),
            "git_commit": commit,
            "git_dirty": dirty,
            "agents_md_sha256": _agents_md_hash(),
            "model": model,
            "base_url": str(base_url),
            "yolo_initial": bool(yolo),
            "one_shot": bool(one_shot),
            "system_prompt_sha256": sha256_text(system_prompt),
            "system_prompt_text": None if _no_text() else system_prompt,
            "client_pid": os.getpid(),
            "hostname": socket.gethostname(),
            "tool_catalog": json.dumps([
                {"name": n, "requires_permission": registry_perms.get(n, False)}
                for n in registry_names
            ]),
            # P2.3: per-session snapshot of the multi-model routing slots
            # (and any other start-time config). NULL for callers that
            # don't pass a snapshot (e.g. older test harnesses) — the
            # column is nullable.
            "config_snapshot": (
                json.dumps(config_snapshot) if config_snapshot is not None else None
            ),
            # P2.1: parent/child session linkage for subagent dispatch.
            # NULL on root sessions; set on child sessions via fork_subagent.
            "parent_session_id": self._parent_session_id,
            "session_kind": self._session_kind,
        }
        self._writer.submit("session_start", params)

    def end_session(self, *, reason):
        self._writer.submit("session_end", {
            "session_id": self._session_id,
            "ended_at": _now(),
            "end_reason": reason,
        })

    # ---- turn / iteration ------------------------------------------------

    def start_turn(self, *, user_input):
        self._turn_index += 1
        return TurnHandle(turn_index=self._turn_index, user_input=user_input)

    def start_iteration(self, turn, *, iteration_index, context_used_est, budget_status,
                        mode="act", slot="main", model=None):
        return IterationHandle(
            turn_id=str(uuid.uuid4()),
            session_id=self._session_id,
            turn_index=turn.turn_index,
            iteration_index=iteration_index,
            started_at=_now(),
            user_input=turn.user_input if iteration_index == 0 else None,
            context_used_est=context_used_est,
            budget_status=budget_status,
            mode=mode,
            slot=slot,
            model=model,
        )

    def end_iteration(self, it, *, assistant_text, tool_calls, finish_reason,
                      usage, api_error):
        ended_at = _now()
        duration_ms = int((ended_at - it.started_at).total_seconds() * 1000)
        usage = usage or {}
        cached = (usage.get("prompt_tokens_details") or {}).get("cached_tokens")
        ui = None if _no_text() else it.user_input
        ui_val, ui_trunc, _ = truncate_field(ui, _TEXT_LIMIT)
        at = None if _no_text() else assistant_text
        at_val, at_trunc, _ = truncate_field(at, _TEXT_LIMIT)
        api_err_type = type(api_error).__name__ if api_error is not None else None
        api_err_msg, api_err_trunc, _ = truncate_field(
            str(api_error) if api_error is not None else None, 2000,
        )
        cost_billed_microcents = (
            billed_microcents(usage, it.model) if it.model and usage else None
        )
        self._writer.submit("turn", {
            "turn_id": it.turn_id,
            "session_id": it.session_id,
            "turn_index": it.turn_index,
            "iteration_index": it.iteration_index,
            "started_at": it.started_at,
            "ended_at": ended_at,
            "user_input": ui_val,
            "user_input_truncated": ui_trunc,
            "assistant_text": at_val,
            "assistant_text_truncated": at_trunc,
            "finish_reason": finish_reason,
            "prompt_tokens": usage.get("prompt_tokens"),
            "completion_tokens": usage.get("completion_tokens"),
            "cached_tokens": cached,
            "context_used_est": it.context_used_est,
            "budget_status": it.budget_status,
            "api_error_type": api_err_type,
            "api_error_message": api_err_msg,
            "api_error_message_truncated": api_err_trunc,
            "duration_ms": duration_ms,
            "num_tool_calls": len(tool_calls or []),
            "mode": it.mode,
            "slot": it.slot,
            "model": it.model,
            "cost_billed_microcents": cost_billed_microcents,
            "terminator_kind": it.terminator_kind,
            "todos_snapshot": (
                json.dumps(it.todos_snapshot)
                if it.todos_snapshot is not None else None
            ),
        })

    # ---- tool calls / events ---------------------------------------------

    def record_tool_call(self, it, *, call, call_index, outcome, permission_outcome,
                         permission_prompt_ms, result, duration_ms,
                         started_at, ended_at, handler_exception_type):
        result_val, result_trunc, result_full = truncate_field(
            None if _no_text() else result, _RESULT_LIMIT,
        )
        # If NO_TEXT, we still want to know how big the result was.
        if _no_text():
            result_full = len((result or "").encode("utf-8"))
        args_for_db = None if _no_text() else json.dumps(call.arguments)
        raw_args_for_db = None if _no_text() else call.raw_arguments
        self._writer.submit("tool_call", {
            "tool_call_id": str(uuid.uuid4()),
            "turn_id": it.turn_id,
            "session_id": it.session_id,
            "call_index": call_index,
            "openai_call_id": call.id,
            "tool_name": call.name,
            "args": args_for_db,
            "raw_arguments": raw_args_for_db,
            "parse_error": call.parse_error,
            "args_fingerprint": args_fingerprint(call.name, call.arguments),
            "permission_outcome": permission_outcome,
            "permission_prompt_ms": permission_prompt_ms,
            "outcome": outcome,
            "handler_exception_type": handler_exception_type,
            "result_text": result_val,
            "result_truncated": result_trunc,
            "result_full_bytes": result_full,
            "result_starts_with_error": (result or "").startswith("Error:"),
            "duration_ms": duration_ms,
            "started_at": started_at,
            "ended_at": ended_at,
        })

    def event(self, kind, *, payload=None, turn=None):
        self._writer.submit("event", {
            "session_id": self._session_id,
            "turn_id": None,  # turn-scoped events are rare; we can populate later
            "ts": _now(),
            "kind": kind,
            "payload": json.dumps(payload) if payload is not None else None,
        })

    def drain(self, timeout=2.0):
        self._writer.drain(timeout=timeout)

    def fork_subagent(self, *, parent_session_id, parent_iteration_id,
                      agent_label, agent_tool_subset):
        """Mint a child PgTracer pinned to this writer + a fresh session_id.

        The child shares the same BatchWriter (one connection, one queue),
        so envelopes for parent + child interleave on the same daemon
        thread. The child's `start_session` call must be issued by the
        subagent caller before any child events fire — the schema's
        FK from `fred_events.session_id` to `fred_sessions.session_id`
        depends on the row existing.

        `parent_iteration_id` is currently advisory (we don't have a
        column for it — `parent_session_id` is the granularity that
        matters for cost rollup). It rides along in the dispatch event
        for forensics. `agent_label` and `agent_tool_subset` are echoed
        into the parent's `subagent_dispatched` event by the agent_tool
        handler; this method itself doesn't fire that event.
        """
        return PgTracer(
            self._writer,
            parent_session_id=parent_session_id or self._session_id,
            session_kind="subagent",
        )


def _fred_version() -> str:
    # Avoid a circular import at module-load time.
    from fred import __version__
    return __version__


def make_tracer(*, session_disabled: bool = False) -> Tracer:
    """Construct a Tracer based on the configured source.

    Resolution order, top wins:
      1. `FRED_TELEMETRY_DB_URL` env var — self-hosted Postgres path.
         Used by the Fred team's own dogfooding setups and by anyone
         who'd rather pipe telemetry into their own DB. Forces the
         PgTracer/BatchWriter combo regardless of opt-out state.
      2. Authenticated user + not opted out → centralized RemoteTracer
         pointed at api.fredcode.net/v1/telemetry/events. This is the
         default for everyone who's run `fred login`. Behavioral data
         only — see RemoteWriter for the privacy chokepoint.
      3. Otherwise → NullTracer (no auth → nowhere to send; opted-out
         users → don't send).

    Errors at construction time degrade to NullTracer with a single
    stderr line. Off is silent (no warning at startup).

    `session_disabled=True` (set by the --no-telemetry CLI flag)
    short-circuits all paths to NullTracer for the current process
    only — the persisted opt-out preference is unchanged.
    """
    if session_disabled:
        return NullTracer()
    # Self-hosted dev override.
    url = os.environ.get("FRED_TELEMETRY_DB_URL")
    if url:
        try:
            from fred.telemetry.writer import BatchWriter
        except ImportError as e:
            print(
                f"fred: self-hosted telemetry disabled — psycopg not installed "
                f"(install fredcode[telemetry]): {e}",
                file=sys.stderr,
            )
            return NullTracer()
        writer = BatchWriter(url)
        writer.start()
        return PgTracer(writer)

    # Centralized path: requires login + not opted out. Lazy imports to
    # keep tracer.py importable from tests that don't have the rest of
    # the fred package on path.
    from fred.auth import load_credentials
    from fred.preferences import load_preferences

    prefs = load_preferences()
    if prefs.telemetry_opted_out:
        return NullTracer()
    creds = load_credentials()
    if creds is None or not creds.api_key:
        # No auth → no destination. Silent — first-launch users see this
        # path until they `fred login`; they'll opt in implicitly by
        # logging in.
        return NullTracer()

    base_url = (creds.base_url or "https://api.fredcode.net/v1").rstrip("/")
    endpoint = f"{base_url}/telemetry/events"
    try:
        from fred.telemetry.remote_writer import RemoteWriter
    except ImportError as e:
        print(
            f"fred: telemetry disabled — httpx unavailable: {e}",
            file=sys.stderr,
        )
        return NullTracer()
    writer = RemoteWriter(endpoint, creds.api_key)
    writer.start()
    return PgTracer(writer)
