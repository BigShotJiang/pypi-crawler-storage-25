"""MCP JSON-RPC client over stdio (P4.2).

A single ``MCPClient`` owns a server subprocess and the framing on both
stdio pipes. JSON-RPC 2.0 is encoded as newline-delimited JSON per the
MCP spec; servers that emit content-length-framed responses can be
adapted later, but every reference implementation we'll plug into for
v1 (filesystem, git, github, sqlite) speaks newline-JSON.

Lifecycle
~~~~~~~~~

* ``MCPClient(config)`` — pure construction; no I/O.
* ``start()`` — spawns the subprocess, sends ``initialize``, waits for
  the result (synchronous; bounded by ``config.init_timeout``), then
  sends the ``notifications/initialized`` notice and fetches the
  ``tools/list`` payload. After a successful ``start()`` the client is
  ready to ``call_tool(name, arguments)``.
* ``call_tool(name, arguments)`` — sends ``tools/call`` and blocks for
  the response. Raises ``MCPRpcError`` on a server-reported JSON-RPC
  error and ``MCPClientError`` on a transport failure (process died,
  malformed framing, timeout).
* ``shutdown()`` — sends a best-effort ``shutdown`` notification, sends
  SIGTERM to the process group, waits a grace period, then SIGKILL on
  timeout. Idempotent.

Threading model
~~~~~~~~~~~~~~~

A single daemon ``stderr`` reader is the only background thread the
client owns; reads on stdout are synchronous from the calling thread
(the agent loop). MCP request/response is request-reply with sequential
``id``s; we don't need an async dispatcher for v1. A future async
upgrade can swap ``call_tool`` to use a queue without changing the
public surface.

Sharp-edge alignment
~~~~~~~~~~~~~~~~~~~

* Errors NEVER raise out of the public surface other than via the
  ``MCPClientError`` / ``MCPRpcError`` types — the lifecycle layer
  catches both and translates them into ``Error: ...`` strings the
  model can read.
* The subprocess inherits the parent's environment verbatim plus the
  resolved ``env`` dict from config. This is documented as a trust
  surface: only register MCP servers from settings files you control.
* Stderr output from the server is logged via the optional
  ``on_stderr`` callback (used to surface a single ``info`` line at
  session start) — never written to stdout, never sent to the model.
"""
from __future__ import annotations

import json
import os
import signal
import subprocess
import threading
import time
from typing import Any, Callable

from fred.mcp.config import MCPServerConfig

# Wire constants. The MCP spec pins JSON-RPC 2.0; ``protocolVersion`` is
# the value we advertise in ``initialize.params``. Servers may reply with
# their own (newer) version; we accept whatever they offer as long as
# initialization succeeds.
JSONRPC_VERSION = "2.0"
MCP_PROTOCOL_VERSION = "2025-03-26"  # matches modelcontextprotocol.io/specification

# Timeouts in seconds. ``call_tool`` blocks at most this long before we
# declare the call orphaned (server hung). Override with the env var
# ``FRED_MCP_CALL_TIMEOUT``; we cap below at 10 minutes to match fred's
# overall request budget.
_DEFAULT_CALL_TIMEOUT_SEC = 60.0
_MAX_CALL_TIMEOUT_SEC = 600.0


def _call_timeout() -> float:
    """Read the per-call timeout from the env at call time (testable)."""
    raw = os.environ.get("FRED_MCP_CALL_TIMEOUT")
    if raw is None:
        return _DEFAULT_CALL_TIMEOUT_SEC
    try:
        v = float(raw)
    except (TypeError, ValueError):
        return _DEFAULT_CALL_TIMEOUT_SEC
    if v <= 0:
        return _DEFAULT_CALL_TIMEOUT_SEC
    return min(v, _MAX_CALL_TIMEOUT_SEC)


class MCPClientError(Exception):
    """Transport / framing failure. Server may have crashed."""


class MCPRpcError(Exception):
    """JSON-RPC error response from the server (non-zero ``error.code``).

    The full error envelope is preserved on ``self.error`` for callers
    that want to forward the structured payload to the model.
    """

    def __init__(self, message: str, *, code: int = 0, data: Any = None) -> None:
        super().__init__(message)
        self.code = code
        self.data = data


class MCPClient:
    """Stdio JSON-RPC client for one MCP server."""

    def __init__(
        self,
        config: MCPServerConfig,
        *,
        on_stderr: Callable[[str], None] | None = None,
    ) -> None:
        self.config = config
        self._on_stderr = on_stderr
        self._proc: subprocess.Popen | None = None
        self._stderr_thread: threading.Thread | None = None
        self._stderr_buf: list[str] = []
        self._stderr_lock = threading.Lock()
        self._next_id = 1
        # I/O lock: ``call_tool`` is sequential, but we still guard the
        # write/read pair so a future parallel caller doesn't interleave
        # frames on the wire. Cheap; never held across long awaits.
        self._io_lock = threading.Lock()
        # Captured tool list from `tools/list`. List of dicts with
        # ``name`` / ``description`` / ``inputSchema`` per MCP spec.
        self.tools: list[dict] = []
        # Captured server `serverInfo` for the lifecycle summary.
        self.server_info: dict = {}
        self.protocol_version: str = ""
        self.is_started = False
        # Set when the subprocess died unexpectedly. Calls return
        # structured errors after this flips; the registry adapter can
        # re-spawn (P4.2 future work) without restarting the session.
        self.is_crashed = False
        self.crash_reason: str | None = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Spawn the server and complete the MCP handshake.

        Steps:
          1. ``Popen`` with stdin / stdout / stderr pipes; merged env.
          2. Send ``initialize`` request, wait for response.
          3. Send ``notifications/initialized`` notice.
          4. Send ``tools/list`` request, capture response.

        Raises ``MCPClientError`` on any failure; the caller is
        responsible for catching and degrading gracefully. After a
        failed ``start()`` the client is in a partially-initialized
        state — call ``shutdown()`` to release the subprocess.
        """
        if self.is_started:
            return
        env = os.environ.copy()
        env.update(self.config.resolve_env())
        try:
            self._proc = subprocess.Popen(
                [self.config.command, *self.config.args],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
                cwd=self.config.cwd,
                # Line-buffered text mode on stdin/stdout so newline-
                # delimited JSON-RPC frames flush immediately. UTF-8 by
                # default on Python 3.11+; explicit for clarity.
                bufsize=1,
                text=True,
                encoding="utf-8",
                # New session so SIGTERM on the process group catches
                # any subprocess the server might spawn.
                start_new_session=True,
            )
        except (OSError, ValueError) as e:
            raise MCPClientError(f"spawn failed: {type(e).__name__}: {e}") from e

        # Drain stderr on a daemon thread. Buffer the last ~10KB for
        # forensics if the server crashes early; forward each line to
        # the optional ``on_stderr`` callback.
        self._stderr_thread = threading.Thread(
            target=self._drain_stderr, daemon=True,
            name=f"mcp-stderr-{self.config.name}",
        )
        self._stderr_thread.start()

        # Initialize handshake. Bound the wait by ``init_timeout``.
        timeout = float(self.config.effective_init_timeout())
        try:
            init_resp = self._call(
                "initialize",
                params={
                    "protocolVersion": MCP_PROTOCOL_VERSION,
                    "capabilities": {
                        # We're a stdio client that wants to call tools
                        # but doesn't expose any of its own (yet) and
                        # doesn't subscribe to roots / prompts / etc.
                        "tools": {},
                    },
                    "clientInfo": {
                        "name": "fred",
                        "version": _fred_version(),
                    },
                },
                timeout=timeout,
            )
        except MCPClientError as e:
            raise MCPClientError(f"initialize: {e}") from e
        result = (init_resp or {}).get("result") or {}
        self.protocol_version = str(result.get("protocolVersion") or "")
        self.server_info = result.get("serverInfo") or {}

        # Per spec: send ``notifications/initialized`` after handshake.
        # We don't expect a response (notifications have no ``id``).
        try:
            self._notify("notifications/initialized")
        except MCPClientError:
            # A failure to send the notice is not fatal — most servers
            # accept tools/call without it. We capture the error in the
            # crash reason for forensics but don't abort startup.
            pass

        try:
            tools_resp = self._call("tools/list", params={}, timeout=timeout)
        except MCPClientError as e:
            raise MCPClientError(f"tools/list: {e}") from e
        result = (tools_resp or {}).get("result") or {}
        raw_tools = result.get("tools") or []
        if not isinstance(raw_tools, list):
            raw_tools = []
        # Filter to dicts that have a string ``name``; everything else
        # is dropped so a malformed tool entry doesn't break adapter
        # construction downstream.
        self.tools = [
            t for t in raw_tools
            if isinstance(t, dict) and isinstance(t.get("name"), str)
        ]
        self.is_started = True

    def shutdown(self, *, grace_sec: float = 2.0) -> None:
        """Best-effort terminate the server. Idempotent."""
        proc = self._proc
        if proc is None:
            return
        # Try a graceful ``shutdown`` notification first. Many servers
        # treat it as advisory; we then SIGTERM the process group
        # regardless to bound shutdown latency. Swallow ALL exceptions
        # — the subprocess may already be dead (BrokenPipeError on
        # write), or stdin may have been closed; either way we just
        # want to escalate to SIGTERM next.
        try:
            self._notify("shutdown")
        except (MCPClientError, OSError, BrokenPipeError, Exception):
            pass
        # SIGTERM the process group, wait, escalate to SIGKILL.
        try:
            os.killpg(proc.pid, signal.SIGTERM)
        except (OSError, ProcessLookupError):
            pass
        try:
            proc.wait(timeout=grace_sec)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except (OSError, ProcessLookupError):
                pass
            try:
                proc.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                pass
        # Close pipes explicitly so the GC finalizer doesn't fire a
        # BrokenPipeError after the subprocess died (the warning would
        # leak into pytest's `unraisable` collector).
        for fp in (proc.stdin, proc.stdout, proc.stderr):
            try:
                if fp is not None:
                    fp.close()
            except (OSError, BrokenPipeError, Exception):
                pass
        self._proc = None
        self.is_started = False

    # ------------------------------------------------------------------
    # Tool calls
    # ------------------------------------------------------------------

    def call_tool(
        self,
        name: str,
        arguments: dict | None,
        *,
        timeout: float | None = None,
    ) -> dict:
        """Send a ``tools/call`` and return the parsed ``result`` block.

        ``arguments`` is the validated args dict (already passed through
        the adapter's pydantic args model). The MCP spec wraps it under
        ``params.arguments``; we send ``params.name = name`` alongside.

        Raises ``MCPClientError`` if the transport drops out (server
        crash, framing error, timeout) or ``MCPRpcError`` if the server
        returns a non-zero JSON-RPC ``error`` envelope.
        """
        if not self.is_started:
            raise MCPClientError("client not started")
        if self.is_crashed:
            raise MCPClientError(
                f"server already crashed: {self.crash_reason or 'unknown'}"
            )
        envelope = self._call(
            "tools/call",
            params={"name": name, "arguments": arguments or {}},
            timeout=timeout if timeout is not None else _call_timeout(),
        )
        if "error" in (envelope or {}):
            err = envelope["error"] or {}
            raise MCPRpcError(
                str(err.get("message") or "MCP server returned an error"),
                code=int(err.get("code") or 0),
                data=err.get("data"),
            )
        return (envelope or {}).get("result") or {}

    # ------------------------------------------------------------------
    # JSON-RPC plumbing
    # ------------------------------------------------------------------

    def _call(self, method: str, *, params: dict, timeout: float) -> dict:
        """Send a request frame and return the matching response envelope.

        We tag each request with a fresh integer id and match the response
        by id. The MCP spec allows servers to send NOTIFICATIONS
        (``method`` set, no ``id``) interleaved with responses; we drop
        those silently (there's nothing for the client to do with them
        in v1) and keep reading until we find our response or hit the
        timeout.
        """
        with self._io_lock:
            req_id = self._next_id
            self._next_id += 1
            payload: dict[str, Any] = {
                "jsonrpc": JSONRPC_VERSION,
                "id": req_id,
                "method": method,
                "params": params,
            }
            self._write_frame(payload)
            deadline = time.monotonic() + timeout
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise MCPClientError(
                        f"timed out after {timeout:.1f}s waiting for "
                        f"response to {method!r}"
                    )
                envelope = self._read_frame(remaining)
                # Notification (no id): just drop.
                if "id" not in envelope:
                    continue
                if envelope.get("id") == req_id:
                    return envelope
                # Mismatched response (server is buggy or interleaving):
                # drop and keep reading. We don't queue them because v1
                # is sequential.
                continue

    def _notify(self, method: str, *, params: dict | None = None) -> None:
        """Send a notification frame (no id, no response expected)."""
        with self._io_lock:
            payload: dict[str, Any] = {
                "jsonrpc": JSONRPC_VERSION,
                "method": method,
            }
            if params is not None:
                payload["params"] = params
            self._write_frame(payload)

    def _write_frame(self, payload: dict) -> None:
        proc = self._proc
        if proc is None or proc.stdin is None:
            raise MCPClientError("subprocess not running (stdin closed)")
        try:
            line = json.dumps(payload, separators=(",", ":"))
            proc.stdin.write(line + "\n")
            proc.stdin.flush()
        except (OSError, ValueError) as e:
            self._mark_crashed(f"write failed: {type(e).__name__}: {e}")
            raise MCPClientError(str(e)) from e

    def _read_frame(self, timeout: float) -> dict:
        proc = self._proc
        if proc is None or proc.stdout is None:
            raise MCPClientError("subprocess not running (stdout closed)")
        # ``readline`` blocks indefinitely on a hung server; we run it on
        # a worker thread and bound the wait via ``threading.Event``.
        # Cheaper than asyncio for one-shot reads; matches the rest of
        # fred's sync-thread plumbing in ``bash.py``.
        result_box: list[str | None] = [None]
        err_box: list[BaseException | None] = [None]
        done = threading.Event()

        def _worker() -> None:
            try:
                line = proc.stdout.readline()
                result_box[0] = line
            except BaseException as e:  # noqa: BLE001 — read crash escapes
                err_box[0] = e
            finally:
                done.set()

        t = threading.Thread(target=_worker, daemon=True)
        t.start()
        if not done.wait(timeout):
            # Don't kill the worker thread (it's daemon); just escalate
            # to caller. The next read will pick up when stdout produces.
            raise MCPClientError(f"read timeout after {timeout:.1f}s")
        if err_box[0] is not None:
            self._mark_crashed(
                f"read failed: {type(err_box[0]).__name__}: {err_box[0]}"
            )
            raise MCPClientError(str(err_box[0]))
        line = result_box[0]
        if not line:
            # EOF — server closed stdout. Almost certainly a crash; the
            # subprocess might also have exited cleanly, in which case
            # we still mark crashed because subsequent calls can't be
            # satisfied.
            self._mark_crashed("EOF on stdout (server exited)")
            raise MCPClientError("EOF on stdout")
        line = line.rstrip("\n")
        if not line.strip():
            # Blank line — keep reading (some servers prepend banners).
            return self._read_frame(timeout)
        try:
            envelope = json.loads(line)
        except ValueError as e:
            raise MCPClientError(f"malformed JSON-RPC frame: {e}") from e
        if not isinstance(envelope, dict):
            raise MCPClientError(
                f"JSON-RPC frame is not an object: {type(envelope).__name__}"
            )
        return envelope

    # ------------------------------------------------------------------
    # Stderr drain
    # ------------------------------------------------------------------

    def _drain_stderr(self) -> None:
        proc = self._proc
        if proc is None or proc.stderr is None:
            return
        try:
            for line in iter(proc.stderr.readline, ""):
                if not line:
                    break
                line = line.rstrip("\n")
                with self._stderr_lock:
                    self._stderr_buf.append(line)
                    # Cap at ~200 lines so a chatty server doesn't grow
                    # the buffer unbounded.
                    if len(self._stderr_buf) > 200:
                        self._stderr_buf = self._stderr_buf[-200:]
                if self._on_stderr is not None:
                    try:
                        self._on_stderr(line)
                    except Exception:
                        # Stderr forwarding is best-effort.
                        pass
        except (OSError, ValueError):
            return

    def stderr_tail(self, n: int = 10) -> list[str]:
        """Return the last ``n`` stderr lines for diagnostics."""
        with self._stderr_lock:
            return list(self._stderr_buf[-n:])

    # ------------------------------------------------------------------
    # Crash handling
    # ------------------------------------------------------------------

    def _mark_crashed(self, reason: str) -> None:
        if self.is_crashed:
            return
        self.is_crashed = True
        self.crash_reason = reason


def _fred_version() -> str:
    # Avoid a circular import at module load.
    from fred import __version__
    return __version__
