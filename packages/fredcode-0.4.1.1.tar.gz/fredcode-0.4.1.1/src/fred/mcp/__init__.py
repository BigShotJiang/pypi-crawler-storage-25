"""MCP (Model Context Protocol) integration for fred (P4.2).

Spawns user-configured MCP servers as stdio subprocesses, talks JSON-RPC 2.0
to them, and adapts each remote tool into a `fred.tools.base.Tool` so the
existing `Registry` / dispatch / permission machinery can consume them with
no special-casing in the agent loop.

Public surface (re-exported here for callers):

    from fred.mcp import (
        MCPClient, MCPServerConfig, connect_servers, register_mcp_tools,
        cleanup_servers, load_mcp_config, summarize_servers,
    )

Architecture overview
---------------------

* ``client.MCPClient`` owns one server subprocess and its JSON-RPC framing.
  ``initialize`` is sent on ``start()``; ``tools/list`` follows; subsequent
  ``tools/call`` requests dispatch tool invocations.
* ``registry.MCPToolAdapter`` wraps an MCP tool definition as a ``Tool``
  whose pydantic args model is built dynamically from the remote tool's
  JSON schema (via ``pydantic.create_model``). Tool name format is
  ``mcp__<server>__<tool>`` — same syntax the P3.1 ``RuleEngine`` already
  matches against.
* ``config.MCPServerConfig`` parses the `.fred/settings.json` ``mcp`` array
  and resolves ``$VAR`` references inside the optional ``env`` table.
* ``lifecycle.connect_servers`` spawns servers in parallel via a thread
  pool; ``cleanup_servers`` SIGTERMs them at session end. A server crash
  mid-call surfaces as a structured ``Error: ...`` string, never an
  exception out of the dispatch path.

The integration is feature-flagged off by default; servers only spawn when
``.fred/settings.json`` declares an ``mcp`` array. A missing/malformed
config is a no-op (no spawn, no warning beyond a single info line).

Schema deferral
---------------

By default, MCP tools register with a STUB description (one line, no
JSON schema fragment) so the prompt prefix doesn't grow by ~5K tokens
per server. The full schema is fetched on-demand the first time the
model invokes the tool, validated against, and cached on the adapter.
``ENABLE_TOOL_SEARCH=auto`` (default) and ``FRED_MCP_SCHEMAS=eager`` /
``ENABLE_TOOL_SEARCH=false`` flip between deferred and eager loading.

Trust + secrets
---------------

MCP servers are user-trusted code. The subprocess inherits fred's
environment verbatim (``os.environ.copy()``) — including
``FRED_API_KEY`` / ``DEEPSEEK_API_KEY`` — so a server can call back into
Fred if the user wires that up. Don't register a server from a
settings file you don't trust. The redactor at ``telemetry/redact.py``
treats MCP arguments and results as user-controlled text identical to
built-in tool outputs.
"""
from __future__ import annotations

from fred.mcp.client import MCPClient, MCPClientError, MCPRpcError
from fred.mcp.config import (
    MCPServerConfig,
    load_mcp_config,
    parse_mcp_servers,
)
from fred.mcp.lifecycle import (
    MCPSession,
    cleanup_servers,
    connect_servers,
    register_mcp_tools,
    summarize_servers,
)

__all__ = [
    "MCPClient",
    "MCPClientError",
    "MCPRpcError",
    "MCPServerConfig",
    "MCPSession",
    "cleanup_servers",
    "connect_servers",
    "load_mcp_config",
    "parse_mcp_servers",
    "register_mcp_tools",
    "summarize_servers",
]
