"""Aider-style architect/editor second pass.

When the architect (`main_model`) emits a file-edit tool_call
(``str_replace``, ``create_file``), the editor pass runs the proposed
call through the editor model — a cheaper second model whose only job
is to verify and, if necessary, repair the architect's arguments
against the live file.

Wired from `fred.session.run_session` between the pre-handler hook and
``registry.dispatch``. Failures are non-fatal: on any exception the
original tool_call dispatches as-is and a one-time-per-session renderer
notice fires.

Activation rules:
  - The tool must be in `EDITOR_REVIEWED_TOOLS`.
  - `model_cfg.editor_model != model_cfg.main_model`, OR the user
    started the session with `--architect` (which forces the pass
    even when slots collapse — useful for evaluation).
  - The architect actually emitted at least one tool_call this iteration.

Cost guard: `MAX_EDITOR_CALLS_PER_ITERATION` caps the number of editor
runs per iteration so a pathological turn with dozens of edits cannot
balloon the bill. Calls past the cap pass through unchanged and emit
an `editor_skipped` event.
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from fred.client import ToolCall

if TYPE_CHECKING:
    from fred.client import DSClient
    from fred.config import ModelConfig
    from fred.tools.registry import Registry


# Tools the editor pass second-guesses. Read-only tools (view, grep,
# glob, repo_map) and side-effect tools the editor cannot meaningfully
# verify (bash, web_*, agent, todo_write) bypass the pass.
EDITOR_REVIEWED_TOOLS: frozenset[str] = frozenset({"str_replace", "create_file"})

# Per-iteration safety cap. After this many editor invocations in one
# iteration, subsequent file-edit calls pass through unchanged. The cap
# is intentionally generous — typical turns have 1–3 edits — but bounds
# pathological behavior.
MAX_EDITOR_CALLS_PER_ITERATION = 8


_EDITOR_SYSTEM_PROMPT = """\
You are the editor model in an architect/editor split. Another model (the
architect) just proposed a file-edit tool call. Your job is to review and,
if necessary, repair the call's arguments by verifying them against the
file's actual contents on disk.

Rules:
  - If the architect's arguments are already correct, re-emit the SAME
    tool call with identical arguments.
  - If `old_str` does not match the file verbatim (whitespace drift,
    missing context, ambiguous match), repair it using the file contents
    you were shown — keep the architect's intent, not its literal bytes.
  - If `path` is clearly wrong (e.g. a relative path that does not exist),
    correct it.
  - Return EXACTLY ONE tool call. No prose, no commentary, no second
    proposal. Do not explain your reasoning in text — just emit the
    repaired (or unchanged) tool call.
"""


def maybe_editor_repair(
    tc: ToolCall,
    *,
    client: "DSClient",
    model_cfg: "ModelConfig",
    registry: "Registry",
    user_message: str,
    architect_text: str,
    architect_reasoning: str,
    tracer: Any,
    turn: int,
    renderer: Any,
    architect_flag: bool = False,
) -> ToolCall:
    """Run the editor pass on ``tc`` if eligible. Returns the repaired
    (or original, on bypass/error) ToolCall.

    Identity (``tc.id``, ``tc.name``) is preserved on the returned call
    so the OpenAI tool_call_id wiring downstream stays consistent — only
    ``arguments`` and ``raw_arguments`` may differ.
    """
    if tc.name not in EDITOR_REVIEWED_TOOLS:
        return tc
    if not architect_flag and model_cfg.editor_model == model_cfg.main_model:
        return tc

    started = time.perf_counter()
    editor_model = model_cfg.editor_model

    try:
        tool = registry.get(tc.name)
        if tool is None:
            return tc
        tool_def = tool.to_openai()

        # Read the target file fresh from disk for str_replace so the
        # editor verifies against ground truth, not the architect's
        # recollection. create_file is a write — no current contents to
        # show, just the proposed body.
        path_arg = tc.arguments.get("path") or ""
        file_contents: str | None = None
        if tc.name == "str_replace" and path_arg:
            try:
                file_contents = Path(path_arg).read_text(encoding="utf-8")
            except OSError:
                file_contents = "(file not readable)"

        user_block_lines = [
            f"Originating user message:\n{user_message or '(none)'}",
            "",
            f"Architect's reply text:\n{architect_text or '(empty)'}",
            "",
            f"Architect's reasoning:\n{architect_reasoning or '(empty)'}",
            "",
            "Architect's proposed call:",
            f"  name: {tc.name}",
            f"  arguments: {json.dumps(tc.arguments, indent=2)}",
        ]
        if file_contents is not None:
            user_block_lines.extend([
                "",
                f"Current contents of {path_arg}:",
                "```",
                file_contents,
                "```",
            ])
        user_block = "\n".join(user_block_lines)

        editor_client = client.with_model(editor_model)
        tracer.event("model_routed", payload={
            "slot": "editor",
            "model": editor_model,
            "reason": "repair",
        }, turn=turn)

        editor_messages = [
            {"role": "system", "content": _EDITOR_SYSTEM_PROMPT},
            {"role": "user", "content": user_block},
        ]
        stream = editor_client.stream_chat(editor_messages, tools=[tool_def])
        for _ev in stream:
            pass
        result = stream.result()

        if renderer is not None and result.usage:
            renderer.show_usage(result.usage, editor_model, slot="editor")

        if not result.tool_calls:
            tracer.event("editor_repair", payload={
                "tool": tc.name,
                "outcome": "no_tool_call",
                "elapsed_ms": int((time.perf_counter() - started) * 1000),
            }, turn=turn)
            return tc

        repaired = result.tool_calls[0]
        if repaired.parse_error:
            tracer.event("editor_repair", payload={
                "tool": tc.name,
                "outcome": "parse_error",
                "error": repaired.parse_error,
                "elapsed_ms": int((time.perf_counter() - started) * 1000),
            }, turn=turn)
            return tc

        changed_keys = sorted(
            k for k in set(tc.arguments) | set(repaired.arguments)
            if tc.arguments.get(k) != repaired.arguments.get(k)
        )
        outcome = "changed" if changed_keys else "unchanged"
        tracer.event("editor_repair", payload={
            "tool": tc.name,
            "outcome": outcome,
            "changed_keys": changed_keys,
            "elapsed_ms": int((time.perf_counter() - started) * 1000),
        }, turn=turn)
        return ToolCall(
            id=tc.id,
            name=tc.name,
            arguments=repaired.arguments,
            raw_arguments=repaired.raw_arguments,
            parse_error=None,
        )
    except Exception as exc:
        tracer.event("editor_repair", payload={
            "tool": tc.name,
            "outcome": "error",
            "error_type": type(exc).__name__,
            "elapsed_ms": int((time.perf_counter() - started) * 1000),
        }, turn=turn)
        if renderer is not None:
            renderer.editor_failure_notice(editor_model, type(exc).__name__)
        return tc
