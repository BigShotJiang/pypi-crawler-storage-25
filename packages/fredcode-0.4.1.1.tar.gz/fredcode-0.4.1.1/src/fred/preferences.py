"""User preferences store at ~/.config/fred/preferences.json.

Separate file from credentials.json so re-auth (which rewrites the
creds file) doesn't blow away preferences.

Stores per-slot model choices, /pro confirmation flag, telemetry
opt-out, and the once-shown first-run notice flag. New keys can be
added freely; load tolerates missing keys.

Mode 0600 — preferences are user-private even when individual fields
aren't strictly secret. The chmod is enforced on every write.
"""
from __future__ import annotations

import json
import os
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

DEFAULT_PREFS_PATH = Path.home() / ".config" / "fred" / "preferences.json"


@dataclass
class Preferences:
    """Persisted preferences. version=1 is the current schema."""

    version: int = 1
    main_model: str | None = None
    editor_model: str | None = None
    weak_model: str | None = None
    subagent_main_model: str | None = None
    # `/pro` topology confirmation flag. Once set, the disclosure is
    # skipped on subsequent invocations. Reset by deleting the prefs file.
    warned_about_architect: bool = False
    # Audit/display label for the active topology. Inferred by
    # `_persist_model_prefs` from the slot shape: "flash" (all four
    # match flash), "architect" (main=pro, others=flash), "premium"
    # (all match pro), or None for custom/unmatched shapes.
    preset: str | None = None
    # Behavioral telemetry opt-out. Default: send (opt-out semantics).
    # The CLI ships behavioral telemetry — sessions, turns, tool calls,
    # slash commands — to api.fredcode.net so we can recursively
    # improve the product. NEVER prompt or response text. NEVER tool
    # args. NEVER file contents. See /docs/telemetry.
    #
    # Set via `/telemetry off` in REPL or `fred telemetry off` from a
    # shell. Reading this field requires `auth.load_credentials()` to
    # succeed — without an authenticated user there's no destination
    # to send to and the tracer becomes a NullTracer regardless.
    telemetry_opted_out: bool = False
    # First-run notice shown once on the first session that successfully
    # constructs a non-NullTracer. Set after print so the dim line
    # appears exactly once per machine.
    telemetry_first_run_shown: bool = False

    @classmethod
    def from_json(cls, data: dict[str, Any]) -> "Preferences":
        return cls(
            version=int(data.get("version", 1)),
            main_model=data.get("main_model"),
            editor_model=data.get("editor_model"),
            weak_model=data.get("weak_model"),
            subagent_main_model=data.get("subagent_main_model"),
            warned_about_architect=bool(data.get("warned_about_architect", False)),
            preset=data.get("preset"),
            telemetry_opted_out=bool(data.get("telemetry_opted_out", False)),
            telemetry_first_run_shown=bool(data.get("telemetry_first_run_shown", False)),
        )


def _ensure_dir(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def load_preferences(path: Path | None = None) -> Preferences:
    """Return preferences or defaults. Never raises — a malformed file
    logs a warning and falls back to defaults rather than blocking startup.
    """
    p = path or DEFAULT_PREFS_PATH
    if not p.exists():
        return Preferences()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        print(f"fred: could not read preferences at {p}: {e}", file=sys.stderr)
        return Preferences()
    try:
        return Preferences.from_json(data)
    except (KeyError, ValueError) as e:
        print(f"fred: malformed preferences at {p}: {e}", file=sys.stderr)
        return Preferences()


def save_preferences(prefs: Preferences, path: Path | None = None) -> None:
    """Atomic write with mode 0600. Logs and returns on failure rather
    than raising — preferences are best-effort."""
    p = path or DEFAULT_PREFS_PATH
    _ensure_dir(p)
    old_umask = os.umask(0o077)
    try:
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(asdict(prefs), indent=2) + "\n", encoding="utf-8")
        os.chmod(tmp, 0o600)
        tmp.replace(p)
    except OSError as e:
        print(f"fred: could not write preferences to {p}: {e}", file=sys.stderr)
    finally:
        os.umask(old_umask)
