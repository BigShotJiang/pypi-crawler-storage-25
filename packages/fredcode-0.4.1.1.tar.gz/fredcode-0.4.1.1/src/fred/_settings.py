"""Shared ``.fred/<file>`` discovery walker.

Both ``fred.hooks`` and ``fred.permissions`` need to find every
``.fred/<filename>`` between cwd and ``$HOME`` so user-level config
layers cleanly under project-level config. The walk algorithm — stop
at the first ``.git`` boundary, the filesystem root, or ``$HOME`` —
used to be duplicated in both modules character-for-character; it
lives here so a future change to the scoping rule doesn't drift
between the hooks and the permission rules.
"""
from __future__ import annotations

from pathlib import Path


def walk_up_for_settings(start: Path, filename: str) -> list[Path]:
    """Yield existing ``.fred/<filename>`` paths walking upward from ``start``.

    Stops at the first ``.git`` boundary, the filesystem root, or
    ``$HOME``, whichever comes first. Returned nearest-first so
    callers can layer outer files under inner ones with a simple
    ``reversed()`` if they prefer outer→inner order.

    Only paths that already exist are returned; callers don't need to
    re-stat to filter out the missing entries.
    """
    paths: list[Path] = []
    current = start.resolve()
    home = Path.home().resolve()
    while True:
        candidate = current / ".fred" / filename
        if candidate.exists():
            paths.append(candidate)
        if (current / ".git").exists():
            break
        if current == current.parent:
            break
        if current == home:
            break
        current = current.parent
    return paths
