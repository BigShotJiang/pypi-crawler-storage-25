"""Tree-sitter parser/language access with lazy per-language loading.

`tree-sitter-language-pack` provides Language and Parser instances for
~150 languages, but importing them eagerly costs both startup time and
memory. We load them on first use and cache the (Language, Parser) pair
for the lifetime of the process.

`filename_to_lang` is exported by `grep_ast` and maps suffixes/file
shebangs to the canonical language id used by tree-sitter; we keep the
import inside the function so module import time stays cheap.
"""
from __future__ import annotations

import warnings
from functools import lru_cache
from pathlib import Path

# tree-sitter emits a FutureWarning on some versions; silence at import.
warnings.filterwarnings("ignore", category=FutureWarning, module="tree_sitter.*")

# Languages we ship a tags.scm for at v1. Anything else falls through
# silently (the file is walked but no tags are extracted).
SUPPORTED_LANGUAGES = frozenset({
    "python",
    "javascript",
    "typescript",
    "tsx",
    "go",
    "rust",
})


def filename_to_language(path: str | Path) -> str | None:
    """Map a file path to a tree-sitter language id, or None if unknown.

    Defers to `grep_ast.filename_to_lang` (which knows extension and
    shebang rules), then filters down to languages we actually have a
    tags query for. We special-case `.tsx` because grep_ast collapses
    it to "typescript" but the typescript grammar can't parse JSX —
    we ship a separate `tsx-tags.scm` and use the `tsx` parser.
    """
    try:
        from grep_ast import filename_to_lang
    except ImportError:
        return None
    suffix = str(path).rsplit(".", 1)[-1].lower() if "." in str(path) else ""
    # grep_ast collapses tsx -> typescript; route .tsx files to the
    # tsx grammar explicitly so JSX-bearing files actually parse.
    if suffix == "tsx":
        return "tsx" if "tsx" in SUPPORTED_LANGUAGES else None
    lang = filename_to_lang(str(path))
    if lang is None:
        return None
    if lang not in SUPPORTED_LANGUAGES:
        return None
    return lang


@lru_cache(maxsize=None)
def get_language_and_parser(lang: str):
    """Return (Language, Parser) for `lang`, cached for the process lifetime.

    Returns (None, None) on any import or load failure — callers should
    treat that as "skip this file" rather than an error. We deliberately
    swallow exceptions here because tree_sitter's failure modes vary
    across language-pack versions and we don't want a single broken
    grammar to break the whole repo map.

    Note: tree_sitter_language_pack uses a HOME-derived cache directory
    for downloaded grammars (`~/Library/Caches/tree-sitter-language-pack`
    on macOS). Re-pointing HOME after a successful load (e.g., in test
    fixtures) will trip a `LanguageNotFoundError` here on subsequent
    languages — passing `cache_dir` to RepoMap avoids that without
    swapping HOME.
    """
    try:
        from tree_sitter_language_pack import get_language, get_parser
        language = get_language(lang)
        parser = get_parser(lang)
        return language, parser
    except Exception:
        return None, None


@lru_cache(maxsize=None)
def get_query_text(lang: str) -> str | None:
    """Read the bundled `<lang>-tags.scm` query, cached. None if missing.

    The queries live next to this module in `queries/` and ship inside
    the wheel via the force-include directive in pyproject.toml. For
    editable installs the file path resolves the same way.
    """
    here = Path(__file__).parent
    path = here / "queries" / f"{lang}-tags.scm"
    try:
        return path.read_text(encoding="utf-8")
    except (FileNotFoundError, OSError):
        return None
