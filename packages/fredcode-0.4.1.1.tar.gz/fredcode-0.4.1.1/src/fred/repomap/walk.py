"""Pathspec-respecting walk over a project directory.

We pull file paths via `os.walk`, then apply a layered set of filters:
- `.gitignore` patterns rooted at the project (via `pathspec`)
- a hardcoded skiplist for generated/vendored paths that gitignore
  doesn't always cover (`node_modules`, `dist`, `vendor`, `.venv`, ...)
- per-file size cap (1MB)
- NUL-byte sniff for binary files
- the `parser.SUPPORTED_LANGUAGES` filter — we only expose files whose
  extension maps to a tags.scm we ship, so unsupported languages don't
  push out interesting ones from the budget.

The walk is intentionally Aider-shaped: in v1 we don't try to be
clever about symlinks or cross-filesystem boundaries. `os.walk`
default behavior (no follow_symlinks) is what we want.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Iterator

from fred.repomap.parser import filename_to_language

# Paths that are virtually never useful in a repo map. Gitignore covers
# most of these in practice but vendored/generated content sometimes
# slips into the index — defense in depth.
_HARDCODED_SKIP_DIRS = frozenset({
    "node_modules", "vendor", "dist", "build", ".venv", "venv",
    ".tox", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "__pycache__", ".git", ".hg", ".svn", ".idea", ".vscode",
    "target",  # rust
    ".next", ".nuxt",  # node frameworks
})

# Filename suffixes that are usually generated and not worth mapping.
_GENERATED_SUFFIXES = (
    ".pb.py", ".pb.go", ".pb.rs", ".pb.ts",
    "_pb2.py", "_pb2_grpc.py",
    ".min.js", ".min.css",
    ".bundle.js", ".bundle.css",
    ".lock",  # pnpm-lock.yaml etc.
)

MAX_FILE_BYTES = 1_000_000  # 1MB hard cap


def _load_gitignore(root: Path):
    """Build a pathspec from `<root>/.gitignore`, or None if absent.

    Uses pathspec's `gitignore` factory (the modern replacement for
    the deprecated `gitwildmatch`). On older pathspec we fall back
    to `gitwildmatch` to keep the dep range loose.
    """
    gi_path = root / ".gitignore"
    if not gi_path.is_file():
        return None
    try:
        from pathspec import PathSpec
    except ImportError:
        return None
    try:
        with open(gi_path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError:
        return None
    # Try the modern factory first, then fall back.
    for factory in ("gitignore", "gitwildmatch"):
        try:
            return PathSpec.from_lines(factory, lines)
        except (LookupError, ValueError):
            continue
    return None


def _looks_binary(path: Path) -> bool:
    """Cheap NUL-byte sniff over the first 8KB."""
    try:
        with open(path, "rb") as f:
            chunk = f.read(8192)
        return b"\x00" in chunk
    except OSError:
        return True


def walk_project(root: Path) -> Iterator[Path]:
    """Yield absolute paths to source files under `root` worth mapping.

    Filters applied (in order):
    1. Hardcoded skip-dirs are pruned during walk.
    2. `.gitignore` patterns drop matching files.
    3. Generated suffixes drop matching files.
    4. Files >1MB or NUL-containing are dropped.
    5. Files whose extension doesn't map to a supported language are
       dropped (so the budget isn't wasted on, say, README.md).

    `root` is converted to an absolute path; results are absolute paths
    rooted under `root`.
    """
    root = root.resolve()
    spec = _load_gitignore(root)

    for dirpath, dirnames, filenames in os.walk(root):
        # Prune skip dirs in-place so os.walk doesn't descend.
        dirnames[:] = [d for d in dirnames if d not in _HARDCODED_SKIP_DIRS]

        for fname in filenames:
            if fname.startswith("."):
                # dotfiles are usually config/git noise; skip.
                continue
            if any(fname.endswith(suf) for suf in _GENERATED_SUFFIXES):
                continue

            full = Path(dirpath) / fname
            try:
                rel = full.relative_to(root).as_posix()
            except ValueError:
                continue

            # Gitignore eval. PathSpec wants relative posix paths.
            if spec is not None and spec.match_file(rel):
                continue

            # Language gate before the (more expensive) stat — only
            # files we have a tags.scm for.
            if filename_to_language(full) is None:
                continue

            try:
                size = full.stat().st_size
            except (FileNotFoundError, OSError):
                continue
            if size > MAX_FILE_BYTES:
                continue
            if _looks_binary(full):
                continue

            yield full
