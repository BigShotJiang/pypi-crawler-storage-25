"""RepoMap orchestrator: walk -> parse -> rank -> render.

`RepoMap.scan(progress=None)` is the cold-start scan that populates
the disk-backed tag cache. Subsequent calls to `get_repo_map(...)`
reuse cached parses for unchanged files (same `(path, mtime, size)`)
and re-run PageRank + rendering — both are cheap relative to parsing.

`get_repo_map(chat_files, mentioned_idents)` returns a markdown blob
sized to fit roughly within `map_tokens` tokens (default 1500). The
budget is enforced via Aider's binary-search heuristic: pick the
largest prefix of ranked tags that renders inside ±15% of the target.

Token counting uses `tiktoken`'s cl100k_base encoder when available,
falling back to a 4-chars-per-token approximation otherwise. Both
DeepSeek and Anthropic tokenizers are close enough to cl100k that
this is a fine sizing heuristic.
"""
from __future__ import annotations

import time
from pathlib import Path
from typing import Callable

from fred.repomap import render as renderer_mod
from fred.repomap.cache import TagCache, file_signature
from fred.repomap.graph import build_graph_and_rank
from fred.repomap.parser import filename_to_language
from fred.repomap.tags import Tag, extract_tags
from fred.repomap.walk import walk_project

# Default budget: ~1500 tokens fits comfortably in the system prefix
# without crowding out tools schema or AGENTS.md. Adjust via env or
# constructor arg if a future model has a wildly different context.
DEFAULT_MAP_TOKENS = 1500


def _count_tokens(text: str) -> int:
    """Approximate token count. Tries tiktoken first, then falls back to len/4."""
    if not text:
        return 0
    try:
        import tiktoken
        enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(text, disallowed_special=()))
    except Exception:
        return max(1, len(text) // 4)


class RepoMap:
    """Stateful repo map builder bound to a project root.

    Lifecycle:
      rm = RepoMap(root)
      rm.scan(progress=...)           # cold-start parse
      block = rm.get_repo_map(...)    # per-turn rendering

    The instance keeps the `TagCache` open and a per-process
    `tags_by_file` dict so re-walks only re-parse files whose
    (mtime, size) changed.
    """

    def __init__(
        self,
        root: str | Path,
        *,
        map_tokens: int = DEFAULT_MAP_TOKENS,
        cache_dir: Path | None = None,
    ):
        self.root = Path(root).resolve()
        self.map_tokens = map_tokens
        self._tag_cache = TagCache(self.root, cache_dir=cache_dir)
        # In-memory snapshot of (rel_fname -> tags). Populated by scan()
        # and refreshed lazily on subsequent get_repo_map() calls when
        # individual files change.
        self._tags_by_file: dict[str, list[Tag]] = {}
        self._mtime_lookup: dict[str, float] = {}
        self._abs_lookup: dict[str, str] = {}
        # Stats from the last scan, surfaced via `last_scan_stats` for
        # the renderer/tracer.
        self.last_scan_stats: dict = {}

    # --- public surface ---

    def scan(
        self,
        *,
        progress: Callable[[int, int], None] | None = None,
    ) -> dict:
        """Walk the project, parse every supported file, fill the tag cache.

        `progress(idx, total)` is called per file scanned so the caller
        can render a status line. Returns a stats dict suitable for the
        `repo_map_scan_complete` telemetry event.
        """
        t_start = time.perf_counter()
        files = list(walk_project(self.root))
        t_walk = time.perf_counter()

        # Reset the cumulative state — `scan` is the cold-start.
        self._tags_by_file.clear()
        self._mtime_lookup.clear()
        self._abs_lookup.clear()
        self._tag_cache.reset_stats()

        languages_found: set[str] = set()
        parse_failures = 0

        for idx, abs_path in enumerate(files):
            if progress is not None:
                try:
                    progress(idx, len(files))
                except Exception:
                    pass

            try:
                rel_fname = abs_path.relative_to(self.root).as_posix()
            except ValueError:
                continue

            sig = file_signature(str(abs_path))
            if sig is None:
                continue
            mtime, size = sig

            self._mtime_lookup[rel_fname] = mtime
            self._abs_lookup[rel_fname] = str(abs_path)

            # Cache lookup by (path, mtime, size).
            cached = self._tag_cache.get(str(abs_path), mtime, size)
            if cached is not None:
                tags = cached
            else:
                try:
                    code = abs_path.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    parse_failures += 1
                    continue
                tags = extract_tags(str(abs_path), rel_fname, code)
                self._tag_cache.set(str(abs_path), mtime, size, tags)

            lang = filename_to_language(abs_path)
            if lang:
                languages_found.add(lang)
            if tags:
                self._tags_by_file[rel_fname] = tags

        t_done = time.perf_counter()
        self.last_scan_stats = {
            "files_seen": len(files),
            "files_parsed": len(self._tags_by_file),
            "walk_ms": int((t_walk - t_start) * 1000),
            "parse_ms": int((t_done - t_walk) * 1000),
            "parse_failures": parse_failures,
            "languages_found": sorted(languages_found),
            "cache_hits": self._tag_cache.hits,
            "cache_misses": self._tag_cache.misses,
            "root": str(self.root),
        }
        return self.last_scan_stats

    def _refresh_changed(self) -> None:
        """Re-parse files whose `(mtime, size)` changed since the last scan.

        Cheaper than a full `scan()` on every turn — lstat-only walk
        over files we already know about, plus a discovery pass for
        new files. Internal helper for `get_repo_map`.
        """
        # Discovery: walk and pick up new files. Cheap because the
        # walker filters non-source files before stat'ing.
        seen: set[str] = set()
        for abs_path in walk_project(self.root):
            try:
                rel_fname = abs_path.relative_to(self.root).as_posix()
            except ValueError:
                continue
            seen.add(rel_fname)
            sig = file_signature(str(abs_path))
            if sig is None:
                continue
            mtime, size = sig
            old_mtime = self._mtime_lookup.get(rel_fname)

            self._mtime_lookup[rel_fname] = mtime
            self._abs_lookup[rel_fname] = str(abs_path)

            if old_mtime == mtime:
                # Cached and unchanged.
                continue

            cached = self._tag_cache.get(str(abs_path), mtime, size)
            if cached is not None:
                if cached:
                    self._tags_by_file[rel_fname] = cached
                else:
                    self._tags_by_file.pop(rel_fname, None)
                continue

            try:
                code = abs_path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                self._tags_by_file.pop(rel_fname, None)
                continue
            tags = extract_tags(str(abs_path), rel_fname, code)
            self._tag_cache.set(str(abs_path), mtime, size, tags)
            if tags:
                self._tags_by_file[rel_fname] = tags
            else:
                self._tags_by_file.pop(rel_fname, None)

        # Drop files that have disappeared.
        for stale in [k for k in list(self._mtime_lookup) if k not in seen]:
            self._mtime_lookup.pop(stale, None)
            self._abs_lookup.pop(stale, None)
            self._tags_by_file.pop(stale, None)

    def get_repo_map(
        self,
        chat_files: set[Path] | None = None,
        mentioned_idents: set[str] | None = None,
        *,
        viewed_files: set[Path] | None = None,
        mentioned_files: set[Path] | None = None,
        budget_tokens: int | None = None,
    ) -> str:
        """Render the repo map, sized to fit within `budget_tokens` tokens.

        Inputs use absolute Paths so callers don't need to know the
        project root convention. Internally we convert to rel paths.

        Returns "" when there's nothing meaningful to render (empty
        project, all files in chat, etc.) — callers should treat
        empty-string as "skip injecting a repo map this turn."
        """
        if budget_tokens is None:
            budget_tokens = self.map_tokens
        if budget_tokens <= 0:
            return ""

        chat_files = chat_files or set()
        mentioned_idents = mentioned_idents or set()
        viewed_files = viewed_files or set()
        mentioned_files = mentioned_files or set()

        # Refresh stale entries before ranking (cheap when nothing changed).
        self._refresh_changed()

        if not self._tags_by_file:
            return ""

        chat_rel = self._to_rel_set(chat_files)
        viewed_rel = self._to_rel_set(viewed_files)
        mentioned_rel = self._to_rel_set(mentioned_files)

        ranked, definitions = build_graph_and_rank(
            self._tags_by_file,
            chat_rel_fnames=chat_rel,
            mentioned_idents=mentioned_idents,
            viewed_rel_fnames=viewed_rel,
            mentioned_rel_fnames=mentioned_rel,
        )
        if not ranked:
            return ""

        # Binary search over the prefix of ranked tags. The starting
        # `middle` matches Aider's heuristic (max_tokens / 25 — typical
        # tag costs ~25 tokens), capped at the available count.
        # We resolve abs paths through the same lookup the renderer
        # needs.
        return self._fit_budget(
            ranked, definitions, chat_rel, budget_tokens,
        )

    def render_stats(self, rendered: str, render_ms: int) -> dict:
        """Build a `repo_map_render` telemetry payload from the last call."""
        return {
            "files_in_map": len(set(line.split(":")[0]
                                     for line in rendered.splitlines()
                                     if line and not line.startswith(("│", "⋮", " ")))),
            "symbols_kept": rendered.count("│"),
            "budget_used_tokens": _count_tokens(rendered),
            "render_ms": render_ms,
            "cache_hits": self._tag_cache.hits,
            "cache_misses": self._tag_cache.misses,
        }

    def close(self) -> None:
        self._tag_cache.close()

    # --- internal ---

    def _to_rel_set(self, paths: set[Path]) -> set[str]:
        out: set[str] = set()
        for p in paths:
            try:
                p_abs = p.resolve()
                rel = p_abs.relative_to(self.root).as_posix()
                out.add(rel)
            except (ValueError, OSError):
                # Path outside root — skip (we can't map it anyway).
                continue
        return out

    def _fit_budget(
        self,
        ranked: list[tuple[str, str, float]],
        definitions: dict[tuple[str, str], list[Tag]],
        chat_rel_fnames: set[str],
        budget_tokens: int,
    ) -> str:
        """Binary search for the largest prefix that fits within ±15%."""
        if not ranked:
            return ""

        num = len(ranked)
        lower, upper = 0, num
        best_tree = ""
        best_tokens = 0
        ok_err = 0.15

        # Aider's seed: roughly 25 tokens per tag (after rendering).
        middle = min(max(budget_tokens // 25, 1), num)
        # Cap iterations defensively — log2(num) + 4 should cover any
        # repo, but a stuck loop here would block the agent thread.
        max_iters = 32

        while lower <= upper and max_iters > 0:
            max_iters -= 1
            tree = renderer_mod.to_tree(
                ranked[:middle],
                definitions,
                chat_rel_fnames,
                mtime_lookup=self._mtime_lookup,
            )
            tokens = _count_tokens(tree)
            pct_err = abs(tokens - budget_tokens) / max(budget_tokens, 1)
            within_budget = tokens <= budget_tokens
            improved = tokens > best_tokens

            if (within_budget and improved) or pct_err < ok_err:
                best_tree = tree
                best_tokens = tokens
                if pct_err < ok_err:
                    break

            if tokens < budget_tokens:
                lower = middle + 1
            else:
                upper = middle - 1
            if lower > upper:
                break
            middle = (lower + upper) // 2
            if middle <= 0 or middle > num:
                break

        return best_tree


def build_repo_map_message(rendered: str) -> str:
    """Wrap the rendered tree in a system-segment-friendly preamble.

    The wrapping is deliberately minimal — the model only needs to know
    "this is a map of the repo, the symbols listed are likely related
    to your task." Anything more verbose eats the token budget.
    """
    if not rendered:
        return ""
    return (
        "## Repository map\n"
        "Symbols below are the most relevant classes/functions in the codebase. "
        "Use them to integrate with existing code.\n\n"
        f"{rendered}"
    )
