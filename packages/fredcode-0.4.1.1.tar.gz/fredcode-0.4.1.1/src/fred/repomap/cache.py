"""Diskcache-backed per-file tag cache.

Keyed by absolute path; the value records (mtime, size, tags) so we
can reject stale entries without re-parsing. The cache lives at
`~/.fred/cache/repomap/<repo-hash>/` where `<repo-hash>` is the sha256
of the project root path (or git remote URL when available) — that
keeps caches isolated between repos that share file paths.

Failure modes:
- diskcache import error -> in-memory dict fallback
- corrupted sqlite db    -> caught by diskcache itself; we re-raise
                            on fatal errors and let the caller decide
"""
from __future__ import annotations

import hashlib
import os
import subprocess
from pathlib import Path

from fred.repomap.tags import Tag

# Bumped on schema changes (e.g. added/removed Tag fields).
CACHE_VERSION = 1


def _git_remote_url(root: Path) -> str | None:
    """Return the origin remote URL if `root` is a git repo, else None.

    Used as a stable id for cache scoping — two worktrees of the same
    repo share the cache, two unrelated checkouts don't.
    """
    try:
        result = subprocess.run(
            ["git", "config", "--get", "remote.origin.url"],
            capture_output=True, text=True, timeout=2, cwd=str(root),
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    return None


def repo_cache_dir(root: Path, base_dir: Path | None = None) -> Path:
    """The diskcache directory for `root`. Creates parent dirs lazily.

    `root` is expected to be the project root (typically `Path.cwd()`).
    The hash input is the git remote URL when available — cache is
    shared across worktrees of the same upstream — falling back to the
    absolute root path so unrelated projects stay isolated.

    `base_dir` overrides the default `~/.fred/cache/repomap/`. Tests
    pass an isolated `tmp_path` to keep cache state hermetic without
    swapping HOME (which breaks tree-sitter-language-pack's own cache).
    """
    key_input = _git_remote_url(root) or str(root.resolve())
    digest = hashlib.sha256(key_input.encode("utf-8")).hexdigest()[:16]
    if base_dir is None:
        base_dir = Path.home() / ".fred" / "cache" / "repomap"
    base = Path(base_dir) / f"v{CACHE_VERSION}-{digest}"
    base.parent.mkdir(parents=True, exist_ok=True)
    return base


class TagCache:
    """Per-file tag cache keyed by absolute path.

    `get(abs_fname, mtime, size)` returns the cached tag list when the
    (mtime, size) matches; otherwise returns None (caller re-parses).
    `set(abs_fname, mtime, size, tags)` records a fresh entry.

    Stats counters track per-instance hits/misses for telemetry; reset
    via `reset_stats()`.
    """

    def __init__(self, root: Path, *, cache_dir: Path | None = None):
        self.root = root
        self._cache_dir = cache_dir
        self._memory: dict[str, dict] = {}
        self._cache = None
        self._init_disk_cache()
        self.hits = 0
        self.misses = 0

    def _init_disk_cache(self) -> None:
        """Open the diskcache, falling back to in-memory dict on failure."""
        try:
            from diskcache import Cache
            path = repo_cache_dir(self.root, base_dir=self._cache_dir)
            self._cache = Cache(str(path))
        except Exception:
            # diskcache is unavailable or sqlite is unhappy. The dict
            # fallback gives in-process correctness even though there
            # is no cross-session persistence.
            self._cache = None

    def _backing(self):
        return self._cache if self._cache is not None else self._memory

    def get(self, abs_fname: str, mtime: float, size: int) -> list[Tag] | None:
        """Return cached tags if (mtime, size) matches, else None."""
        backing = self._backing()
        try:
            entry = backing.get(abs_fname) if hasattr(backing, "get") else backing[abs_fname]
        except KeyError:
            entry = None
        except Exception:
            # Corrupted db etc.; treat as miss.
            entry = None
        if (
            entry is None
            or entry.get("mtime") != mtime
            or entry.get("size") != size
        ):
            self.misses += 1
            return None
        self.hits += 1
        return entry.get("tags", [])

    def set(self, abs_fname: str, mtime: float, size: int, tags: list[Tag]) -> None:
        """Record `tags` against (abs_fname, mtime, size)."""
        backing = self._backing()
        entry = {"mtime": mtime, "size": size, "tags": tags}
        try:
            if hasattr(backing, "__setitem__"):
                backing[abs_fname] = entry
        except Exception:
            # Disk write failed; degrade to in-memory.
            self._memory[abs_fname] = entry

    def reset_stats(self) -> None:
        self.hits = 0
        self.misses = 0

    def close(self) -> None:
        """Release the underlying diskcache (idempotent)."""
        if self._cache is not None:
            try:
                self._cache.close()
            except Exception:
                pass
            self._cache = None


def file_signature(abs_fname: str) -> tuple[float, int] | None:
    """Return (mtime, size) for `abs_fname`, or None if missing."""
    try:
        st = os.stat(abs_fname)
        return st.st_mtime, st.st_size
    except (FileNotFoundError, OSError):
        return None
