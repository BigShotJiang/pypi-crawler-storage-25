"""Per-file tag extraction via tree-sitter queries.

A `Tag` is one definition or reference of an identifier in a file:
    Tag(rel_fname=..., fname=..., line=..., name="run_session", kind="def")

We map the per-language `tags.scm` capture names to two kinds: tags
whose capture name starts with `name.definition.` are `def`s; those
starting with `name.reference.` are `ref`s. Any other capture is
ignored (e.g. doc-comment associations, scope captures).

The `extract_tags` function is best-effort and returns an empty list
on any failure — callers must not assume "no tags" means "file is
empty"; it may also mean "we couldn't parse this file."
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

from fred.repomap.parser import (
    filename_to_language,
    get_language_and_parser,
    get_query_text,
)


@dataclass(frozen=True)
class Tag:
    """One definition or reference event extracted from a file.

    `kind`: "def" for a definition, "ref" for a reference (call site,
    type use, etc.). Lines are 0-indexed (matching tree-sitter's
    `start_point[0]`).
    """
    rel_fname: str
    fname: str
    line: int
    name: str
    kind: str  # "def" or "ref"


def _run_captures(query, root_node):
    """Execute a tree-sitter Query against a root node.

    Tree-sitter's Python bindings shifted the captures API between
    0.23.x (Query.captures) and 0.24+ (QueryCursor.captures). Support
    both so our minimum version line stays loose.
    """
    if hasattr(query, "captures"):
        return query.captures(root_node)
    from tree_sitter import QueryCursor
    cursor = QueryCursor(query)
    return cursor.captures(root_node)


def extract_tags(fname: str | Path, rel_fname: str, code: str) -> list[Tag]:
    """Parse `code` and return a flat list of Tag rows. Best-effort.

    Returns an empty list if the language isn't supported, the parser
    fails to load, the query fails to compile, or the captures are
    structurally surprising — every error path is treated as "skip
    this file" because the repo map is a hint, not a contract.
    """
    lang = filename_to_language(fname)
    if lang is None:
        return []

    language, parser = get_language_and_parser(lang)
    if language is None or parser is None:
        return []

    query_text = get_query_text(lang)
    if not query_text:
        return []

    try:
        from tree_sitter import Query
        tree = parser.parse(bytes(code, "utf-8"))
        query = Query(language, query_text)
        captures = _run_captures(query, tree.root_node)
    except Exception:
        return []

    # `captures` is a dict[capture_name -> list[Node]] in modern bindings;
    # walk it to build flat (name, capture_name) pairs. Old bindings
    # returned a list of (Node, capture_name) tuples — handle both.
    tags: list[Tag] = []
    fname_str = str(fname)

    if isinstance(captures, dict):
        items = []
        for cap_name, nodes in captures.items():
            for node in nodes:
                items.append((node, cap_name))
    else:
        items = list(captures)

    for node, cap_name in items:
        if cap_name.startswith("name.definition."):
            kind = "def"
        elif cap_name.startswith("name.reference."):
            kind = "ref"
        else:
            continue

        try:
            ident = node.text.decode("utf-8")
        except (UnicodeDecodeError, AttributeError):
            continue

        try:
            line = node.start_point[0]
        except (AttributeError, IndexError):
            line = 0

        tags.append(Tag(
            rel_fname=rel_fname,
            fname=fname_str,
            line=line,
            name=ident,
            kind=kind,
        ))

    return tags


def split_defs_refs(tags: list[Tag]) -> tuple[dict, dict]:
    """Partition a tag list into defs (set per ident) and refs (count per file).

    Used by the graph builder. `defs[ident] -> set[rel_fname]` (which
    files declare this identifier) and `refs[ident] -> list[rel_fname]`
    (one entry per reference; downstream `Counter()` collapses to
    counts).
    """
    defines: dict[str, set[str]] = defaultdict(set)
    references: dict[str, list[str]] = defaultdict(list)
    for tag in tags:
        if tag.kind == "def":
            defines[tag.name].add(tag.rel_fname)
        elif tag.kind == "ref":
            references[tag.name].append(tag.rel_fname)
    return defines, references
