"""Render ranked symbols as a markdown-ish tree using grep-ast TreeContext.

The output format mirrors Aider's:

    src/foo.py:
    ⋮…
    │class Foo:
    ⋮…
    │    def bar(self):
    ⋮…

`TreeContext` does the per-file rendering — given a set of "lines of
interest" it walks the tree-sitter parse tree and prints those lines
plus their parent context (class/function headers), eliding the rest
with `⋮…`.

Hard caps:
- Each line is truncated to 100 chars, defending against minified JS.
- Per-file contexts are cached by (rel_fname, mtime) so repeated calls
  with the same file content reuse the parse tree.
"""
from __future__ import annotations

from pathlib import Path

from fred.repomap.tags import Tag


# Per-file TreeContext cache: rel_fname -> (mtime, TreeContext)
_tree_context_cache: dict[str, tuple[float, object]] = {}

# Per-(file, lois) rendering cache: avoids re-rendering identical
# slices when the model and personalization both stabilize.
_rendered_cache: dict[tuple[str, tuple[int, ...], float], str] = {}


def _get_tree_context(abs_fname: str, rel_fname: str, mtime: float):
    """Return a (cached) TreeContext for `abs_fname`, or None on failure."""
    cached = _tree_context_cache.get(rel_fname)
    if cached is not None and cached[0] == mtime:
        return cached[1]

    try:
        from grep_ast import TreeContext
    except ImportError:
        return None

    try:
        code = Path(abs_fname).read_text(encoding="utf-8", errors="replace")
    except (OSError, UnicodeDecodeError):
        return None
    if not code.endswith("\n"):
        code += "\n"

    try:
        ctx = TreeContext(
            rel_fname,
            code,
            color=False,
            line_number=False,
            child_context=False,
            last_line=False,
            margin=0,
            mark_lois=False,
            loi_pad=0,
            show_top_of_file_parent_scope=False,
        )
    except Exception:
        return None
    _tree_context_cache[rel_fname] = (mtime, ctx)
    return ctx


def render_file_tree(
    abs_fname: str, rel_fname: str, lines_of_interest: list[int], mtime: float,
) -> str:
    """Render one file's tree-context block, cached per (file, lois, mtime)."""
    key = (rel_fname, tuple(sorted(lines_of_interest)), mtime)
    cached = _rendered_cache.get(key)
    if cached is not None:
        return cached

    ctx = _get_tree_context(abs_fname, rel_fname, mtime)
    if ctx is None:
        return ""
    try:
        ctx.lines_of_interest = set()
        ctx.add_lines_of_interest(lines_of_interest)
        ctx.add_context()
        rendered = ctx.format()
    except Exception:
        return ""
    _rendered_cache[key] = rendered
    return rendered


def to_tree(
    ranked_tags: list[tuple[str, str, float]],
    definitions: dict[tuple[str, str], list[Tag]],
    chat_rel_fnames: set[str],
    *,
    mtime_lookup: dict[str, float],
) -> str:
    """Render the top-N ranked symbols as a single markdown blob.

    `ranked_tags` is the sorted list from `graph.build_graph_and_rank`;
    we group consecutive entries by file and emit one TreeContext block
    per group. Files that appear in `chat_rel_fnames` are skipped — the
    model already has those bytes verbatim, no need to also map them.

    Lines are hard-capped at 100 chars per the plan's spec; the
    truncation is the defense-in-depth layer for cases where TreeContext
    happens to walk into a generated/minified region.
    """
    if not ranked_tags:
        return ""

    # Re-sort within files by line so renderer's loi list is monotonic.
    by_file: dict[str, list[Tag]] = {}
    for rel_fname, ident, _rank in ranked_tags:
        if rel_fname in chat_rel_fnames:
            continue
        for tag in definitions.get((rel_fname, ident), []):
            by_file.setdefault(rel_fname, []).append(tag)

    out_chunks: list[str] = []
    # Preserve the rank ordering by walking the input list once and
    # tracking which files we've already emitted.
    seen_files: set[str] = set()
    for rel_fname, _ident, _rank in ranked_tags:
        if rel_fname in chat_rel_fnames or rel_fname in seen_files:
            continue
        seen_files.add(rel_fname)
        tags = by_file.get(rel_fname)
        if not tags:
            # File made the cut on rank but no definitions to render.
            out_chunks.append(f"\n{rel_fname}\n")
            continue

        # Use the first tag's abs path; all tags from the same file
        # share fname.
        abs_fname = tags[0].fname
        lois = sorted({t.line for t in tags})
        mtime = mtime_lookup.get(rel_fname, 0.0)

        block = render_file_tree(abs_fname, rel_fname, lois, mtime)
        if not block:
            # Render failure: still surface the filename so the model
            # knows the file exists.
            out_chunks.append(f"\n{rel_fname}\n")
            continue
        out_chunks.append(f"\n{rel_fname}:\n{block}")

    raw = "".join(out_chunks)
    # Hard 100-char cap per line.
    capped = "\n".join(line[:100] for line in raw.splitlines())
    if capped and not capped.endswith("\n"):
        capped += "\n"
    return capped


def reset_caches() -> None:
    """Clear the module-level caches. Used by tests."""
    _tree_context_cache.clear()
    _rendered_cache.clear()
