"""Config: env vars, project-memory loader, credential precedence."""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path


def load_project_memory(cwd: Path | None = None) -> str | None:
    """Load AGENTS.md if present in cwd. If CLAUDE.md also present, log a note."""
    cwd = cwd or Path.cwd()
    agents = cwd / "AGENTS.md"
    claude = cwd / "CLAUDE.md"
    if agents.exists():
        if claude.exists():
            print(
                "fred: AGENTS.md and CLAUDE.md both present in cwd; using AGENTS.md, ignoring CLAUDE.md.",
                file=sys.stderr,
            )
        try:
            return agents.read_text(encoding="utf-8")
        except OSError as e:
            print(f"fred: failed to read AGENTS.md: {e}", file=sys.stderr)
            return None
    if claude.exists():
        try:
            return claude.read_text(encoding="utf-8")
        except OSError as e:
            print(f"fred: failed to read CLAUDE.md: {e}", file=sys.stderr)
            return None
    return None


_DEEPSEEK_DEPRECATION_PRINTED = False


def _warn_deepseek_legacy() -> None:
    global _DEEPSEEK_DEPRECATION_PRINTED
    if _DEEPSEEK_DEPRECATION_PRINTED:
        return
    _DEEPSEEK_DEPRECATION_PRINTED = True
    print(
        "fred: using DEEPSEEK_API_KEY directly. This bypasses Fred's billing/usage tracking. "
        "Run `fred login` to switch to a managed credential, or set FRED_API_KEY explicitly to silence this notice.",
        file=sys.stderr,
    )


def get_api_key() -> str | None:
    """Resolution order:
    1. FRED_API_KEY env (explicit override; CI use case).
    2. ~/.config/fred/credentials.json (or macOS keychain).
    3. DEEPSEEK_API_KEY env (legacy direct-to-DeepSeek; prints deprecation).
    """
    explicit = os.environ.get("FRED_API_KEY")
    if explicit:
        return explicit
    # Lazy-import to avoid an import cycle: auth → config (no), but cli/client → config → auth.
    from fred import auth as _auth

    creds = _auth.load_credentials()
    if creds and creds.api_key:
        return creds.api_key
    legacy = os.environ.get("DEEPSEEK_API_KEY")
    if legacy:
        _warn_deepseek_legacy()
        return legacy
    return None


def get_base_url() -> str:
    """Same precedence: FRED_BASE_URL > credentials.base_url > default."""
    explicit = os.environ.get("FRED_BASE_URL")
    if explicit:
        return explicit
    from fred import auth as _auth

    creds = _auth.load_credentials()
    if creds and creds.base_url:
        return creds.base_url
    # Backward-compat: env-only DEEPSEEK_API_KEY users go to DeepSeek directly.
    if os.environ.get("DEEPSEEK_API_KEY") and not creds:
        return "https://api.deepseek.com/v1"
    return "https://api.fredcode.net/v1"


def get_telemetry_db_url() -> str | None:
    return os.environ.get("FRED_TELEMETRY_DB_URL")


# ---------- Multi-model routing (P2.3) ------------------------------------


@dataclass(frozen=True)
class ModelConfig:
    """Four-slot model routing.

    Each slot has a real consumer in the dispatch loop:
      - ``main_model`` — every regular turn (`session.run_session`).
      - ``editor_model`` — Aider-style review/repair pass on file-edit
        tool_calls (str_replace, create_file). See `fred.editor_pass`.
      - ``weak_model`` — auto-compaction at 85% budget and `/compact`.
      - ``subagent_main_model`` — child sessions spawned via the `agent`
        tool. Falls through to ``main_model`` when not pinned.

    Equality is structural so tests can compare configs cleanly; the
    dataclass is frozen because reading a config is hot-path-ish (every
    iteration consults it via the slash-command-mutated cli.py state)
    and accidental mutation of an instance held by multiple call sites
    would silently route to the wrong slot.
    """

    main_model: str
    editor_model: str
    weak_model: str
    subagent_main_model: str

    def for_slot(self, slot: str) -> str:
        """Look up the model name for a slot keyword.

        `slot` is one of `"main"`, `"editor"`, `"weak"`, `"subagent_main"`.
        Anything else raises `ValueError`. Used by `/model <slot> <name>`
        and by callsites that consult the slot map programmatically.
        """
        if slot == "main":
            return self.main_model
        if slot == "editor":
            return self.editor_model
        if slot == "weak":
            return self.weak_model
        if slot == "subagent_main":
            return self.subagent_main_model
        raise ValueError(
            f"unknown model slot: {slot!r} (expected main|editor|weak|subagent_main)"
        )


def load_model_config() -> ModelConfig:
    """Read the four model slots from env / preferences / default.

    Resolution per slot (top wins):
      1. Env: `FRED_MAIN_MODEL` (and `FRED_EDITOR_MODEL` /
         `FRED_WEAK_MODEL` / `FRED_SUBAGENT_MAIN_MODEL`). Env wins so CI
         runs are predictable regardless of the developer's local
         preferences file.
      2. ~/.config/fred/preferences.json — set by `/model`, `/flash`,
         `/pro`, persisted across CLI restarts.
      3. Hardcoded `DEFAULT_MODEL`.

    Editor, weak, and subagent_main slots fall through to ``main_model``
    when not pinned, so setting just ``main_model`` in preferences flips
    all four.

    Reading at call time (not import time) lets `/model` mutations
    propagate without a process restart, and lets tests use
    `monkeypatch.setenv(...)` per case.
    """
    # Lazy import to avoid a circular import: client → config → client.
    from fred.client import DEFAULT_MODEL
    from fred.preferences import load_preferences

    prefs = load_preferences()

    main = os.environ.get("FRED_MAIN_MODEL") or prefs.main_model or DEFAULT_MODEL
    editor = os.environ.get("FRED_EDITOR_MODEL") or prefs.editor_model or main
    weak = os.environ.get("FRED_WEAK_MODEL") or prefs.weak_model or main
    subagent_main = (
        os.environ.get("FRED_SUBAGENT_MAIN_MODEL")
        or prefs.subagent_main_model
        or main
    )
    return ModelConfig(
        main_model=main,
        editor_model=editor,
        weak_model=weak,
        subagent_main_model=subagent_main,
    )
