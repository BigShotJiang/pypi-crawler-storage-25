"""Backend-agnostic cache-prefix abstraction.

DeepSeek caches prompt prefixes automatically at 64-token block granularity:
no markers required — just send byte-stable prefix bytes and the platform
hits its cache. Anthropic uses explicit `cache_control: {type: "ephemeral"}`
markers (max 4 per request, on tools/system/messages, 5m or 1h TTL).

Both backends share the same intent: encode where the prefix ends and the
volatile tail begins. `CacheableRequest` records that intent once; the
per-backend formatters emit the wire shape each provider expects.

DeepSeek docs: https://api-docs.deepseek.com/guides/kv_cache
Anthropic docs: https://docs.anthropic.com/en/docs/build-with-claude/prompt-caching
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Segment:
    """A piece of message content with a cacheability hint.

    `content`: the raw string body (already-rendered system prompt, project
    memory, repo map, etc.).

    `cacheable`: whether this segment is part of the byte-stable prefix
    that should hit the provider's prompt cache. Volatile tail content
    (the live conversation, latest user input) sets this False.
    """
    content: str
    cacheable: bool = True


@dataclass
class CacheableRequest:
    """An ordered list of cacheable system segments + the message tail.

    Construction order: cacheable system segments first (large, byte-stable
    prefix), then the conversation messages list (system+user+assistant+tool
    role messages, raw OpenAI/Anthropic shape) as the volatile tail.

    The `system_segments` list is intended for content that lives in the
    system role for OpenAI-style APIs and gets concatenated into one system
    message there. For Anthropic, each segment becomes its own
    {type: text, ...} block, with cache_control on the LAST cacheable one
    so the entire prefix up to and including it gets cached.

    `tail_messages` is the raw role-shaped message list (user/assistant/tool)
    that follows the system prefix. The DeepSeek formatter prepends a single
    concatenated system message; Anthropic gets a separate `system` array.
    """
    system_segments: list[Segment] = field(default_factory=list)
    tail_messages: list[dict] = field(default_factory=list)

    def for_deepseek(self) -> list[dict]:
        """Emit OpenAI-shape messages with no cache markers.

        DeepSeek's prefix cache is automatic; the only requirement is that
        the bytes match across calls. Concatenate all cacheable+volatile
        system segments into one system message (preserving order), then
        append the tail messages verbatim.
        """
        out: list[dict] = []
        if self.system_segments:
            sys_text = "".join(s.content for s in self.system_segments)
            out.append({"role": "system", "content": sys_text})
        out.extend(self.tail_messages)
        return out

    def for_anthropic(self) -> list[dict]:
        """Emit Anthropic Messages-API shape with explicit cache_control.

        Returns a dict-shape compatible with Anthropic's `messages.create`:
          {"system": [<text-block>, ...], "messages": [...]}
        embedded into a single dict for caller convenience. The LAST cacheable
        system segment carries `cache_control: {type: "ephemeral"}` so the
        entire prefix up to and including it gets cached (Anthropic caches
        the longest matching prefix that ends at a marker).

        Anthropic limits markers to 4 per request and supports tools/system/
        messages positions; placing one on the final cacheable system segment
        is the lowest-friction shape and covers the common case where tools
        + system are both stable.
        """
        last_cacheable_idx = -1
        for i, seg in enumerate(self.system_segments):
            if seg.cacheable:
                last_cacheable_idx = i

        sys_blocks: list[dict] = []
        for i, seg in enumerate(self.system_segments):
            block: dict = {"type": "text", "text": seg.content}
            if i == last_cacheable_idx:
                block["cache_control"] = {"type": "ephemeral"}
            sys_blocks.append(block)

        return [
            {"system": sys_blocks, "messages": list(self.tail_messages)},
        ]


def cacheable_prefix_size_estimate(messages: list[dict]) -> int:
    """Rough byte count of a message list's likely-cacheable prefix.

    Used for telemetry — counts bytes of the leading run of messages that
    don't include the final user turn (anything before the trailing
    user/tool messages of the current turn).

    Heuristic: walk from the start, sum content bytes until we hit the
    last contiguous user/tool message. The estimate is intentionally
    fuzzy; it's a comparison metric across turns, not a billing line.
    """
    if not messages:
        return 0
    # Find the index of the last user message — everything before it is
    # the steady-state prefix from the cache's POV.
    last_user_idx = -1
    for i, m in enumerate(messages):
        if m.get("role") == "user":
            last_user_idx = i
    if last_user_idx <= 0:
        return 0
    prefix = messages[:last_user_idx]
    total = 0
    for m in prefix:
        c = m.get("content")
        if isinstance(c, str):
            total += len(c.encode("utf-8"))
        elif isinstance(c, list):
            for blk in c:
                if isinstance(blk, dict):
                    t = blk.get("text") or ""
                    total += len(t.encode("utf-8"))
    return total
