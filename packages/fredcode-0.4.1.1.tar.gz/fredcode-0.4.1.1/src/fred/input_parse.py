"""Input shortcuts: @path file embedding and !cmd shell expansion."""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

_MENTION = re.compile(r"(?<![A-Za-z0-9_])@([\w./~\-]+)")
_MAX_EMBED = 4000
_BANG_TIMEOUT_S = 30


def expand_mentions(text: str) -> str:
    """Replace each @path token with a fenced file embedding.

    Tokens whose path doesn't resolve are left untouched. Each embedded
    file is capped at _MAX_EMBED chars; a truncation marker is appended
    when capped.
    """
    def repl(m: re.Match) -> str:
        raw = m.group(1)
        p = Path(raw).expanduser()
        if not p.is_file():
            return m.group(0)
        try:
            content = p.read_text(errors="replace")
        except OSError:
            return m.group(0)
        if len(content) > _MAX_EMBED:
            content = content[:_MAX_EMBED] + "\n…[truncated]"
        ext = p.suffix.lstrip(".")
        return f'<file path="{raw}">\n```{ext}\n{content}\n```\n</file>'

    return _MENTION.sub(repl, text)


def expand_bang(text: str) -> tuple[str, str | None, int | None]:
    """Run a leading-`!` line as a shell command and wrap the output.

    On non-`!` input, returns (text, None, None) unchanged. On `!cmd`,
    runs with a 30s timeout, caps stdout+stderr at _MAX_EMBED chars,
    and returns (wrapped_replacement, raw_cmd, exit_code) where the
    wrapper also exposes exit_code as an attribute on the <shell> tag.
    Exit code is -1 on timeout.
    """
    if not text.startswith("!"):
        return text, None, None
    cmd = text[1:].strip()
    try:
        r = subprocess.run(
            cmd, shell=True, capture_output=True, text=True,
            timeout=_BANG_TIMEOUT_S,
        )
        captured = (r.stdout or "") + (r.stderr or "")
        rc = r.returncode
    except subprocess.TimeoutExpired:
        captured = f"[timeout after {_BANG_TIMEOUT_S}s]"
        rc = -1
    if len(captured) > _MAX_EMBED:
        captured = captured[:_MAX_EMBED] + "\n…[truncated]"
    return f'<shell cmd="{cmd}" exit="{rc}">\n{captured}\n</shell>', cmd, rc


def count_mentions(text: str) -> int:
    """Return the number of resolvable @path mentions in `text`.

    Counts only tokens whose path is an existing file — matches the
    paths that `expand_mentions` would actually rewrite.
    """
    n = 0
    for m in _MENTION.finditer(text):
        if Path(m.group(1)).expanduser().is_file():
            n += 1
    return n
