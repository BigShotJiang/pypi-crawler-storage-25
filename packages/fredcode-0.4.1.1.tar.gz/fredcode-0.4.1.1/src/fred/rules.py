"""`.fred/rules/*.md` system (P3.2 — Cursor-style conditional rule injection).

Rule files are markdown documents with YAML frontmatter. Two roots are
walked, in this precedence order (project rules win on name collision):

  - Project: ``<cwd>/.fred/rules/*.md``  (and any parent directory walking
    upward toward home; the first ``.fred/rules`` directory found wins —
    matches how editors like Cursor scope rules to the nearest project).
  - User:    ``~/.fred/rules/*.md``      (always loaded, layered behind
    project rules).

Frontmatter schema (all optional except ``name``)::

    ---
    name: rule-id
    description: "what this rule is for / when to ask for it"
    alwaysApply: false
    globs: ["src/api/**/*.py"]
    ---
    body markdown...

Selection per turn (``RuleSet.applicable_for``):

* ``alwaysApply: true`` — included every turn.
* ``globs`` set — included when any path in ``chat_files`` matches
  any glob (via ``pathspec``).
* description-only (no ``alwaysApply``, no ``globs``) — NOT included
  automatically; surfaced in the "available" list so the model can
  pull them in via ``request_rule(name)``.
* explicitly requested — once a rule's name lands in the ``explicit``
  set (mutated by the ``request_rule`` tool), it is rendered as
  active for the rest of the session.

Rendering (``RuleSet.render_block``):

* Returns "" when the active list is empty AND no description-only
  rules are available — keeps the injection a no-op for empty
  ``.fred/rules`` dirs.
* Otherwise emits a markdown block with one or two sections:
  ``# Rules (active)`` then ``# Rules (available, request via
  request_rule)``.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

# python-frontmatter is the canonical parser; it returns a Post object
# with `.metadata` (dict from YAML) and `.content` (the body).
try:
    import frontmatter as _frontmatter
except ImportError:  # pragma: no cover — pyproject.toml installs it
    _frontmatter = None  # type: ignore[assignment]

try:
    from pathspec import PathSpec
except ImportError:  # pragma: no cover — pyproject.toml installs pathspec
    PathSpec = None  # type: ignore[assignment]


# Rule files live under ``.fred/rules/`` in either the project tree or the
# user's home directory. We deliberately mirror the same path under both
# roots so a rule "feels the same" regardless of scope.
RULES_SUBDIR = Path(".fred") / "rules"


@dataclass
class Rule:
    """A single rule loaded from disk.

    `name` is required (defaults to the file stem when frontmatter omits it
    so a missing ``name:`` field still gives a usable identifier — the
    file path is the natural ID). `body` is the markdown body the model
    sees when the rule is rendered as active. `source_path` is kept for
    debugging / `/rules` output and not part of the rule contract.
    """

    name: str
    description: str = ""
    always_apply: bool = False
    globs: tuple[str, ...] = ()
    body: str = ""
    source_path: Path | None = None


@dataclass
class RuleSet:
    """An ordered list of `Rule` instances loaded from a project + user dir.

    Order in `rules` reflects discovery order (project first, then user)
    minus any duplicates that lost a name collision. Lookup by name uses
    `by_name` for O(1) access from the `request_rule` tool handler.
    """

    rules: list[Rule] = field(default_factory=list)
    by_name: dict[str, Rule] = field(default_factory=dict)
    # The directories we walked to populate this set, kept for debug
    # surfacing via `/rules`.
    sources: list[Path] = field(default_factory=list)

    # ------------------------------------------------------------------ load

    @classmethod
    def load(cls, start_dir: str | Path | None = None) -> "RuleSet":
        """Discover and parse ``.fred/rules/*.md`` files.

        Search order:
          1. Project rules: walk from ``start_dir`` (defaults to ``cwd``)
             upward toward ``$HOME``. The first ``.fred/rules`` directory
             found is the project rule set; we DON'T merge across multiple
             nested ``.fred/rules`` because that would let an outer dir
             silently override an inner one in confusing ways.
          2. User rules: ``~/.fred/rules`` (always considered).

        Project rules win on name collision (same file stem) — the user
        layer is the fallback / shared baseline.
        """
        start = Path(start_dir or Path.cwd()).resolve()
        sources: list[Path] = []

        project_rules_dir = _find_project_rules_dir(start)
        if project_rules_dir is not None:
            sources.append(project_rules_dir)

        try:
            home = Path.home()
        except (RuntimeError, KeyError):
            home = None
        user_rules_dir: Path | None = None
        if home is not None:
            user_rules_dir = (home / RULES_SUBDIR).resolve()
            # Skip if user dir is the same as project dir (e.g. running
            # fred from $HOME) — avoids duplicate registration.
            if user_rules_dir.is_dir() and user_rules_dir != project_rules_dir:
                sources.append(user_rules_dir)

        rules: list[Rule] = []
        seen_names: set[str] = set()
        for rules_dir in sources:
            for rule in _load_rules_from_dir(rules_dir):
                if rule.name in seen_names:
                    # Project layer wins — first registration sticks.
                    continue
                seen_names.add(rule.name)
                rules.append(rule)
        return cls(
            rules=rules,
            by_name={r.name: r for r in rules},
            sources=sources,
        )

    # ------------------------------------------------------------- selection

    def applicable_for(
        self,
        chat_files: Iterable[Path] | None = None,
        explicit: Iterable[str] | None = None,
    ) -> list[Rule]:
        """Return the rules that should render in the active block this turn.

        Selection logic (rules can match for more than one reason; we
        deduplicate by name while preserving order):

        * ``alwaysApply: true`` — always.
        * ``globs`` set + any path in ``chat_files`` matches — included.
        * ``name`` in ``explicit`` (model-requested via ``request_rule``)
          — included regardless of frontmatter.

        Description-only rules without globs/alwaysApply are NOT in the
        active list unless explicitly requested.
        """
        chat_set = set(chat_files or ())
        explicit_set = set(explicit or ())
        # Project root is the reference point for relativizing paths. We
        # compute it once from the first source dir if available; falling
        # back to cwd if no rules dir was found.
        project_root = self._infer_project_root()
        rel_chat: list[str] = []
        for p in chat_set:
            try:
                rel = Path(p).resolve().relative_to(project_root).as_posix()
            except (ValueError, OSError):
                # Outside the project root — skip; globs are scoped to the
                # project tree.
                continue
            rel_chat.append(rel)

        out: list[Rule] = []
        for rule in self.rules:
            if rule.always_apply:
                out.append(rule)
                continue
            if rule.name in explicit_set:
                out.append(rule)
                continue
            if rule.globs and rel_chat and _any_glob_match(rule.globs, rel_chat):
                out.append(rule)
                continue
        return out

    def available_descriptions(
        self,
        active_names: Iterable[str] | None = None,
    ) -> list[Rule]:
        """Return rules that have a description but aren't in the active set.

        These are surfaced under the "Rules (available)" section so the
        model knows it can pull them via ``request_rule``. Rules without
        any description are silently dropped — there'd be nothing useful
        to show next to the name.
        """
        active = set(active_names or ())
        return [
            r for r in self.rules
            if r.name not in active and r.description.strip()
        ]

    # ------------------------------------------------------------- rendering

    def render_block(
        self,
        active: list[Rule] | None = None,
        *,
        chat_files: Iterable[Path] | None = None,
        explicit: Iterable[str] | None = None,
    ) -> str:
        """Compose the markdown block injected as a system segment.

        Either pass an explicit ``active`` list (test convenience) or let
        ``render_block`` compute it from ``chat_files`` + ``explicit``.

        Returns "" when there's nothing to show (no active rules AND no
        available descriptions). Callers can pass an empty string to
        ``run_session`` and skip injection entirely — matches the
        convention used by the repo-map provider.
        """
        if active is None:
            active = self.applicable_for(chat_files=chat_files, explicit=explicit)
        active_names = [r.name for r in active]
        available = self.available_descriptions(active_names=active_names)
        if not active and not available:
            return ""
        lines: list[str] = []
        if active:
            lines.append("# Rules (active)")
            for rule in active:
                lines.append(f"## {rule.name}")
                body = rule.body.strip()
                if body:
                    lines.append(body)
                lines.append("")  # blank line between rules
        if available:
            if active:
                # Visual separator if both sections are present.
                lines.append("")
            lines.append("# Rules (available, request via request_rule)")
            for rule in available:
                desc = rule.description.strip().splitlines()[0] if rule.description else ""
                if desc:
                    lines.append(f"- {rule.name} — {desc}")
                else:
                    lines.append(f"- {rule.name}")
        # Trim trailing blanks so the block doesn't accidentally pad
        # subsequent system segments.
        text = "\n".join(lines).rstrip() + "\n"
        return text

    # ------------------------------------------------------------- internals

    def _infer_project_root(self) -> Path:
        """Best-effort project root for relativizing chat_files vs globs.

        We use the parent of the first project rules dir (so
        ``<root>/.fred/rules`` -> ``<root>``). When no project rules dir
        is available — e.g. only the user-level layer is loaded — fall
        back to ``cwd``.
        """
        for src in self.sources:
            try:
                # `<root>/.fred/rules` -> `<root>`
                root = src.parent.parent
                # Sanity: a user dir's parent.parent is `~` — only treat
                # this as a project root if the path doesn't equal home.
                home = Path.home() if _has_home() else None
                if home is None or root != home:
                    return root
            except (ValueError, OSError):
                continue
        return Path.cwd()


# ---------------------------------------------------------------------- IO


def _find_project_rules_dir(start: Path) -> Path | None:
    """Walk from ``start`` upward looking for ``.fred/rules``.

    Stops at the user's home directory (don't accidentally pick up
    ``~/.fred/rules`` as a project rule set when running from anywhere
    inside ``$HOME``). Returns ``None`` if nothing is found.
    """
    home = Path.home() if _has_home() else None
    cur = start
    while True:
        candidate = cur / RULES_SUBDIR
        if candidate.is_dir():
            # Don't treat ~/.fred/rules as a "project" set — that's the
            # user-layer source loaded separately.
            if home is not None and candidate.resolve() == (home / RULES_SUBDIR).resolve():
                return None
            return candidate.resolve()
        parent = cur.parent
        if parent == cur:
            return None
        # Don't walk past home (defensive — we don't want global picks).
        if home is not None and cur == home:
            return None
        cur = parent


def _load_rules_from_dir(rules_dir: Path) -> list[Rule]:
    """Parse every ``*.md`` directly under ``rules_dir``.

    Files that fail to parse are skipped silently (best-effort — a
    malformed rule must not take down the agent loop). Order is
    deterministic via ``sorted(...)`` on filename.
    """
    out: list[Rule] = []
    try:
        entries = sorted(rules_dir.iterdir())
    except OSError:
        return out
    for path in entries:
        if not path.is_file() or path.suffix.lower() != ".md":
            continue
        rule = _parse_rule_file(path)
        if rule is not None:
            out.append(rule)
    return out


def _parse_rule_file(path: Path) -> Rule | None:
    """Read + parse a single rule file. Returns None on any failure."""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return None
    metadata: dict
    body: str
    if _frontmatter is not None:
        try:
            post = _frontmatter.loads(text)
        except Exception:
            return None
        metadata = post.metadata or {}
        body = post.content or ""
    else:  # pragma: no cover — fallback for missing dep
        metadata, body = {}, text

    name = str(metadata.get("name") or path.stem).strip()
    if not name:
        return None
    description = str(metadata.get("description") or "").strip()
    always_apply = bool(metadata.get("alwaysApply") or False)
    raw_globs = metadata.get("globs") or ()
    if isinstance(raw_globs, str):
        # Allow a single-string convenience form.
        globs: tuple[str, ...] = (raw_globs,)
    else:
        try:
            globs = tuple(str(g) for g in raw_globs if str(g).strip())
        except TypeError:
            globs = ()
    return Rule(
        name=name,
        description=description,
        always_apply=always_apply,
        globs=globs,
        body=body.strip(),
        source_path=path,
    )


# --------------------------------------------------------------- glob match


def _any_glob_match(globs: tuple[str, ...], rel_paths: list[str]) -> bool:
    """True if any of ``globs`` matches any path in ``rel_paths``.

    We use ``pathspec``'s gitignore-style matchers so the glob semantics
    line up with what ``.gitignore`` users already know — the same dep
    is already in ``walk.py`` for the repo map. This makes patterns
    like ``src/api/**/*.py`` work as expected without reimplementing
    glob trees. Tries the modern ``gitignore`` factory first (replaces
    the deprecated ``gitwildmatch``), falling back if a pathspec
    install is too old.
    """
    if not globs or not rel_paths or PathSpec is None:
        return False
    spec = None
    for factory in ("gitignore", "gitwildmatch"):
        try:
            spec = PathSpec.from_lines(factory, globs)
            break
        except (LookupError, ValueError):
            continue
    if spec is None:
        return False
    for rel in rel_paths:
        if spec.match_file(rel):
            return True
    return False


def _has_home() -> bool:
    try:
        Path.home()
        return True
    except (RuntimeError, KeyError):
        return False


# ------------------------------------------------------------ system block


def build_rules_message(block: str) -> str:
    """Wrap a rendered block in a tiny preamble for the system segment.

    Mirrors the convention used by ``repomap.repo_map.build_repo_map_message``
    so the model sees consistent section headers across the system tail.
    Returns "" when the block is empty so the caller can skip injection.
    """
    if not block:
        return ""
    return block if block.endswith("\n") else block + "\n"


def env_disables_rules() -> bool:
    """Honor ``FRED_RULES=0`` to disable the feature entirely.

    Mirrors the ``FRED_REPOMAP=0`` toggle used by the repo map. The default
    is on — rules are a low-friction guidance layer; users opt out
    explicitly when they don't want them.
    """
    return os.environ.get("FRED_RULES", "1") == "0"
