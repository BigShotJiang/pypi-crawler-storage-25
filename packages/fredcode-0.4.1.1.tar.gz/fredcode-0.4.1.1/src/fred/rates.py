"""Runtime rate-card cache.

Loads the most recent rate card published by FredWeb's /api/pricing
endpoint. The cache file lives at ~/.config/fred/rate-card.json. When
absent or stale, callers fall back to the wheel-bundled defaults in
``bundled_rates``.

The cache is refreshed by ``refresh_from_server`` after every
successful ``fred login``. The shape of the cache matches FredWeb's
publicRateCards() output exactly — the refresh path just persists the
response verbatim plus a ``fetched_at`` timestamp.
"""
from __future__ import annotations

import json
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx

from fred.bundled_rates import BUNDLED_CARDS, BundledCard, Rates, get_bundled_card

DEFAULT_RATE_CARD_PATH = Path.home() / ".config" / "fred" / "rate-card.json"
STALE_THRESHOLD_S = 7 * 24 * 60 * 60  # 7 days


@dataclass(frozen=True)
class CachedCard:
    """Customer-facing rate card from /api/pricing."""

    model: str
    upstream: Rates
    billed: Rates


def _rates_from_dict(d: dict[str, Any]) -> Rates:
    """FredWeb's `Rates` shape uses camelCase. Bundle in snake_case."""
    return Rates(
        input_uncached=int(d["inputUncached"]),
        input_cached=int(d["inputCached"]),
        output=int(d["output"]),
    )


def _load_cache_file(path: Path) -> tuple[list[CachedCard], float] | None:
    """Return (cards, fetched_at_epoch) or None if absent/malformed."""
    if not path.exists():
        return None
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        print(f"fred: could not read rate-card cache: {e}", file=sys.stderr)
        return None
    try:
        models = raw.get("models", [])
        cards: list[CachedCard] = []
        for m in models:
            # Skip retired cards — they're public_rate_cards entries with
            # an effectiveTo set; the active cards are what users care about.
            if m.get("effectiveTo") is not None:
                continue
            cards.append(
                CachedCard(
                    model=m["model"],
                    upstream=_rates_from_dict(m["upstream"]),
                    billed=_rates_from_dict(m["billed"]),
                )
            )
        fetched_at = float(raw.get("fetched_at", 0))
        return cards, fetched_at
    except (KeyError, TypeError, ValueError) as e:
        print(f"fred: malformed rate-card cache: {e}", file=sys.stderr)
        return None


def get_active_card(model: str, path: Path | None = None) -> CachedCard | BundledCard:
    """Return the active card for ``model``. Cache wins over bundled
    fallback. If neither has the model, returns the bundled flash card
    so display code never crashes — the pricing math itself is enforced
    server-side, this is for cost preview only.
    """
    cache = _load_cache_file(path or DEFAULT_RATE_CARD_PATH)
    if cache is not None:
        for c in cache[0]:
            if c.model == model:
                return c
    bundled = get_bundled_card(model)
    if bundled is not None:
        return bundled
    # Last-ditch fallback — keep render code happy.
    return BUNDLED_CARDS[0]


def known_models(path: Path | None = None) -> tuple[str, ...]:
    """Models known to either the cache or the bundled fallback."""
    seen: list[str] = []
    cache = _load_cache_file(path or DEFAULT_RATE_CARD_PATH)
    if cache is not None:
        for c in cache[0]:
            if c.model not in seen:
                seen.append(c.model)
    for c in BUNDLED_CARDS:
        if c.model not in seen:
            seen.append(c.model)
    return tuple(seen)


def cache_age_seconds(path: Path | None = None) -> float | None:
    """Return seconds since the cache was fetched, or None if no cache.
    Used by the CLI to surface a "stale rate card" notice on startup.
    """
    cache = _load_cache_file(path or DEFAULT_RATE_CARD_PATH)
    if cache is None:
        return None
    fetched_at = cache[1]
    if fetched_at <= 0:
        return None
    return max(0.0, time.time() - fetched_at)


def is_stale(path: Path | None = None) -> bool:
    age = cache_age_seconds(path)
    if age is None:
        return False  # missing cache is "no opinion" — let bundled handle it
    return age > STALE_THRESHOLD_S


def refresh_from_server(
    base_url: str,
    *,
    timeout: float = 10.0,
    path: Path | None = None,
) -> bool:
    """Fetch active rate cards from FredWeb's ``/api/pricing`` and persist
    to ``~/.config/fred/rate-card.json``.

    Best-effort: returns ``True`` on success, ``False`` (with a stderr
    note) on any failure. Never raises — a missing or stale cache is
    handled by the bundled fallback in ``bundled_rates``.

    Called after a successful ``fred login`` so the next session sees
    fresh prices in cost previews. CI / scripted runs that don't want
    network can set ``FRED_NO_RATE_CARD_REFRESH=1`` and call sites
    should respect it.
    """
    target_path = path or DEFAULT_RATE_CARD_PATH
    url = f"{base_url.rstrip('/')}/api/pricing"
    try:
        with httpx.Client(timeout=timeout) as client:
            resp = client.get(url)
        if resp.status_code != 200:
            print(
                f"fred: rate-card refresh got HTTP {resp.status_code}; keeping existing cache",
                file=sys.stderr,
            )
            return False
        payload = resp.json()
    except (httpx.HTTPError, ValueError) as e:
        print(f"fred: rate-card refresh failed ({e}); keeping existing cache", file=sys.stderr)
        return False

    if not isinstance(payload, dict) or not isinstance(payload.get("models"), list):
        print("fred: rate-card refresh got unexpected payload shape; keeping existing cache",
              file=sys.stderr)
        return False

    payload["fetched_at"] = time.time()
    try:
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    except OSError as e:
        print(f"fred: could not write rate-card cache: {e}", file=sys.stderr)
        return False
    return True
