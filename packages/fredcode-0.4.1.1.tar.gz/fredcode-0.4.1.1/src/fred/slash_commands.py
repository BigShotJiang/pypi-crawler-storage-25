"""Slash-command registry and prompt_toolkit completer for the fred REPL.

The completer powers the inline dropdown that appears when the user types
`/` at the prompt. It only fires for inputs that begin with a slash and
have no whitespace before the cursor, matching the dispatcher contract in
cli.py (slash commands only dispatch when ``line.startswith("/")``).

Filtering is case-insensitive prefix on ``cmd.name``. With 25-30 static
items, no fuzzy matching or threading is needed.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable, Optional

from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document
from prompt_toolkit.formatted_text import HTML


@dataclass(frozen=True)
class SlashCommand:
    name: str          # includes leading slash, e.g. "/help"
    description: str   # short hint shown as display_meta in the menu


# Curated reading order: action → display → modes → telemetry → exit.
# /quit is intentionally not surfaced — it's an alias of /exit handled at
# the dispatcher (cli.py). One canonical entry per concept.
SLASH_COMMANDS: tuple[SlashCommand, ...] = (
    SlashCommand("/help",        "show slash-command help"),
    SlashCommand("/clear",       "reset conversation (keeps system prompt)"),
    SlashCommand("/tools",       "list registered tools"),
    SlashCommand("/todos",       "show current todo list"),
    SlashCommand("/yolo",        "toggle permission bypass"),
    SlashCommand("/sandbox",     "show or set sandbox/approval mode"),
    SlashCommand("/cost",        "show running session cost"),
    SlashCommand("/think",       "toggle thinking display (on|off|show)"),
    SlashCommand("/save",        "dump transcript as JSONL"),
    SlashCommand("/model",       "show or swap model slots"),
    SlashCommand("/flash",       "switch main to deepseek-v4-flash"),
    SlashCommand("/pro",         "switch main to deepseek-v4-pro"),
    SlashCommand("/last",        "reprint Nth-most-recent tool result"),
    SlashCommand("/repomap",     "print the current rendered repo map"),
    SlashCommand("/rules",       "list active + available rules"),
    SlashCommand("/hooks",       "list active hooks per event"),
    SlashCommand("/perms",       "list/add/remove permission rules"),
    SlashCommand("/mcp",         "list connected MCP servers"),
    SlashCommand("/subagents",   "list subagent profiles + tools"),
    SlashCommand("/mode",        "switch plan/act mode"),
    SlashCommand("/style",       "flip output style for next turn"),
    SlashCommand("/compact",     "summarize older history"),
    SlashCommand("/checkpoints", "list recent shadow-git checkpoints"),
    SlashCommand("/restore",     "restore workspace to a checkpoint"),
    SlashCommand("/telemetry",   "show or change telemetry routing"),
    SlashCommand("/exit",        "quit"),
)


class SlashCommandCompleter(Completer):
    """Completer that surfaces ``SLASH_COMMANDS`` when the user types ``/``.

    The optional ``on_open`` callback fires once per distinct partial value
    (de-dup'd by ``_opened_for``) so a tracer event can be emitted without
    spamming on every keystroke.
    """

    def __init__(
        self,
        commands: tuple[SlashCommand, ...] = SLASH_COMMANDS,
        on_open: Optional[Callable[[int], None]] = None,
    ) -> None:
        self._commands = commands
        self._on_open = on_open
        self._opened_for: Optional[str] = None

    def get_completions(
        self, document: Document, complete_event
    ) -> Iterable[Completion]:
        text = document.text_before_cursor
        if not text.startswith("/"):
            return
        # Past the command word — no argument completion in v1.
        if " " in text:
            return

        partial = text.lower()

        if self._on_open is not None and partial != self._opened_for:
            try:
                self._on_open(
                    sum(
                        1
                        for c in self._commands
                        if c.name.lower().startswith(partial)
                    )
                )
            except Exception:
                pass
            self._opened_for = partial

        for cmd in self._commands:
            if not cmd.name.lower().startswith(partial):
                continue
            yield Completion(
                text=cmd.name + " ",
                start_position=-len(text),
                display=HTML(f"<b>{cmd.name}</b>"),
                display_meta=cmd.description,
            )
