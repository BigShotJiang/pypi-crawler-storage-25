"""Persistent todo-list context injection.

The agent loop injects the current todo list as a synthetic system
message on every iteration so the model can see and update it. The
block sits AFTER the cacheable system+tools prefix and BEFORE
conversation history, so DeepSeek's prefix cache (and Anthropic's
``cache_control``) still hit on the prefix while the todo block consumes
a small number of fresh tokens per turn.

Sentinel: every injected block starts with ``# Todos (current)``.
Subsequent turns detect that prefix in messages[1:N] and replace the
prior block to keep the messages list bounded.

PR-D1 simplification: the prior ``FRED_AUTO_SEED_TODOS`` env gate +
``_should_auto_seed`` heuristic + two-branch empty-state hint are gone.
Always-on todos is always-on; the empty-state placeholder is one stable
line (~80 bytes — one DeepSeek 64-token cache block) regardless of the
user prompt's shape, which keeps cache invalidation independent of
prompt content.
"""
from __future__ import annotations

from fred.tools.todo import GLYPH, TodoItem, get_todos

# Sentinel: any system message whose content begins with this header is
# treated as a previously-injected todo block and replaced on re-injection.
TODO_BLOCK_HEADER = "# Todos (current)"

# Single stable empty-state placeholder. Replaces the prior two-branch
# (env-gated nudge vs default hint) variants; PR-D1 dropped the env gate.
_EMPTY_PLACEHOLDER = (
    "_(no todos yet — call todo_write at the start of any task with "
    "more than one step)_"
)


def render_todo_block(todos: list[TodoItem] | None = None) -> str:
    """Build the markdown block injected as a system message each turn.

    ``todos`` is fetched from ``fred.tools.todo.get_todos()`` when None
    — passing it explicitly is for tests and headless callers.
    """
    if todos is None:
        todos = get_todos()
    lines = [TODO_BLOCK_HEADER]
    if not todos:
        lines.append(_EMPTY_PLACEHOLDER)
    else:
        for t in todos:
            glyph = GLYPH.get(t.status, GLYPH["pending"])
            lines.append(f"{glyph} {t.content}")
    return "\n".join(lines)


def is_todo_block_message(message: dict) -> bool:
    """True if ``message`` is a previously-injected todo system message.

    Detection is by sentinel content prefix. Robust against multiple
    re-injections per turn — only the LAST injected block remains.
    """
    if message.get("role") != "system":
        return False
    content = message.get("content")
    if not isinstance(content, str):
        return False
    return content.startswith(TODO_BLOCK_HEADER)


def inject_todo_block(
    messages: list[dict],
    *,
    todos: list[TodoItem] | None = None,
) -> tuple[list[dict], int]:
    """Return a new messages list with the todo block injected.

    Position: AFTER the leading cacheable prefix (system + any prior
    cacheable system messages) and BEFORE any user/assistant/tool
    history. In practice that means right after the FIRST contiguous
    run of system messages that are NOT prior todo-block injections.

    Behavior:
    - If a prior todo-block system message exists in ``messages``, it
      is removed before the fresh one is inserted (no duplicates).
    - If ``messages`` has no leading system message, the todo block is
      inserted at index 0.
    - Returns ``(new_messages, injected_chars)`` where
      ``injected_chars`` is ``len(block.encode("utf-8"))`` for
      telemetry.

    Does NOT mutate the input list.
    """
    block = render_todo_block(todos=todos)
    injected_chars = len(block.encode("utf-8"))

    # Strip any prior injection(s) so the list stays bounded.
    cleaned = [m for m in messages if not is_todo_block_message(m)]

    # Find the index AFTER the leading run of system messages.
    insert_at = 0
    for i, m in enumerate(cleaned):
        if m.get("role") == "system":
            insert_at = i + 1
        else:
            break

    out = list(cleaned)
    out.insert(insert_at, {"role": "system", "content": block})
    return out, injected_chars


def todos_state_payload(todos: list[TodoItem], injected_chars: int) -> dict:
    """Build the per-turn ``todos_state`` telemetry payload.

    Counts pending / in_progress / completed; includes the byte-length
    of the injected block so we can correlate context budget against
    todo presence. Schema is additive — ``fred_events.payload`` is
    JSONB, so new fields can join later without a migration.
    """
    pending = sum(1 for t in todos if t.status == "pending")
    in_progress = sum(1 for t in todos if t.status == "in_progress")
    completed = sum(1 for t in todos if t.status == "completed")
    return {
        "count_total": len(todos),
        "count_pending": pending,
        "count_in_progress": in_progress,
        "count_completed": completed,
        "injected_chars": injected_chars,
    }
