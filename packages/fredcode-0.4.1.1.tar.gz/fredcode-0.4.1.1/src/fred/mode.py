"""Plan/Act mode state for the agent loop (P2.2).

Mode is a property of the in-flight session: ``"act"`` (default) lets the
model use the full registry; ``"plan"`` restricts dispatch to a read-only
allowlist plus the ``exit_plan_mode`` tool. The mode is plumbed via a
``ContextVar`` (matching the P1.3 ``bash.on_line`` and P1.4
``_session_files`` precedents) so that ``Registry.dispatch``'s public
signature stays unchanged.

Lifecycle:
- ``cli.py`` installs the session-scoped one-element list before the
  REPL loop via ``set_mode_state(["act"|"plan"])``. The list is held by
  reference, so a single mutation (slash command, keybinding, the
  ``exit_plan_mode`` tool) is visible everywhere that reads the mode.
- ``Registry.dispatch`` reads the current mode and gates tool calls.
- ``exit_plan_mode``'s handler flips the mode back to ``"act"``.

The list-of-one wrapper lets the same Python object be shared across
all readers; mutating ``state[0] = "act"`` propagates to every holder
without forcing each call site to re-read the ``ContextVar``.
"""
from __future__ import annotations

import contextvars
from typing import Literal

Mode = Literal["act", "plan"]

# A single-element list is the simplest thread-safe-enough mutable
# container for the mode. None means "no mode tracker installed" and
# the dispatcher treats it as ``"act"`` (backwards-compat fallback —
# mirrors `_session_files.tracking_active()` semantics).
_MODE_STATE: contextvars.ContextVar[list[str] | None] = contextvars.ContextVar(
    "fred_mode_state", default=None,
)


def set_mode_state(state: list[str]) -> contextvars.Token:
    """Install the session-scoped mode state (a one-element list).

    Pair with ``reset_mode_state(token)`` in a try/finally so the
    ContextVar is always restored. The same list object is used by
    all readers; mutating ``state[0]`` flips the mode.
    """
    return _MODE_STATE.set(state)


def reset_mode_state(token: contextvars.Token) -> None:
    _MODE_STATE.reset(token)


def current_mode() -> Mode:
    """Return the current mode (``"act"`` or ``"plan"``).

    Defaults to ``"act"`` when no state is installed. This keeps tools
    that run outside the REPL (one-shot tests, embedded harnesses) on
    the historical full-registry path.
    """
    state = _MODE_STATE.get()
    if state is None:
        return "act"
    val = state[0] if state else "act"
    if val == "plan":
        return "plan"
    return "act"


def set_current_mode(mode: Mode) -> None:
    """Mutate the installed mode state in place.

    No-op when no state is installed (a tool that calls this from a
    headless harness silently does nothing). Used by ``exit_plan_mode``
    to flip back to act after the model commits to a plan.
    """
    state = _MODE_STATE.get()
    if state is None:
        return
    if state:
        state[0] = mode
    else:
        state.append(mode)


# Plan-mode tool allowlist. Anything not in this set is rejected with
# the documented error wording when the dispatcher runs in plan mode.
# `exit_plan_mode` and `todo_write` are always allowed so the model
# can outline a plan and switch back to act on its own. `repo_map` is
# included for forward-compat with a future debug tool of that name
# (currently the repo map is a system-context injection, not a tool).
PLAN_TOOLS: frozenset[str] = frozenset(
    {
        "view", "grep", "glob", "repo_map", "exit_plan_mode", "todo_write",
        # PR-C1: ask_followup_question has no filesystem effects, so it's
        # safe in plan mode. The model may need to clarify before producing
        # a useful plan.
        "ask_followup_question",
    }
)


def mode_blocked_message(name: str) -> str:
    """The model-facing error string for a tool blocked by plan mode.

    Wording is part of the model contract; tests pin it.
    """
    return (
        f"Error: tool {name} not available in plan mode. "
        "Use ExitPlanMode to continue."
    )
