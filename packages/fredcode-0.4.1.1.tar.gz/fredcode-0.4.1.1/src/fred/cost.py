"""Single source of truth for cost math.

Both the renderer (which displays upstream costs in ``/cost``) and the
telemetry tracer (which logs billed costs in ``compaction_run`` events
and the ``cost_billed_microcents`` column) used to compute these
numbers inline with hand-mirrored formulas. This module collapses the
two copies onto one path so the user-visible ``/cost`` figure can never
drift from what telemetry records, even if a future refactor of the
rate-card schema lands.

Rate-card values live in microcents-per-1M-tokens — same units as
``FredWeb/src/lib/pricing.ts`` and ``fred.bundled_rates``. The helpers
below fold that scale into the units callers want: integer microcents
for telemetry, dollars-as-float for display.
"""
from __future__ import annotations

from typing import Mapping

from fred.rates import get_active_card


def _split_tokens(usage: Mapping) -> tuple[int, int, int]:
    """Pull ``(uncached_in, cached_in, out)`` from a usage dict.

    Tolerates both DeepSeek's current sibling format (``prompt_cache_hit_tokens``)
    and the legacy nested ``prompt_tokens_details.cached_tokens`` path.
    Missing fields are treated as zero so callers don't crash on a
    partial usage dict — this gets called from the telemetry path which
    must never raise.
    """
    in_tok = usage.get("prompt_tokens", 0) or 0
    out_tok = usage.get("completion_tokens", 0) or 0
    cached = (
        usage.get("prompt_cache_hit_tokens")
        or (usage.get("prompt_tokens_details") or {}).get("cached_tokens", 0)
        or 0
    )
    non_cached = max(0, in_tok - cached)
    return non_cached, cached, out_tok


def billed_microcents(usage: Mapping, model: str) -> int:
    """What we charge the user, in integer microcents.

    Used by telemetry. Must match what the proxy worker debits against
    ``credits_ledger`` — sub-microcent fractions are floored (mirrors
    the Worker's ``Math.floor(total / 1_000_000)``).
    """
    non_cached, cached, out_tok = _split_tokens(usage)
    card = get_active_card(model)
    raw = (
        non_cached * card.billed.input_uncached
        + cached * card.billed.input_cached
        + out_tok * card.billed.output
    )
    return int(raw // 1_000_000)


def upstream_dollars(usage: Mapping, model: str) -> float:
    """What Fred pays DeepSeek, in dollars-as-float, for display only.

    Used by the renderer's ``/cost`` panel. Float arithmetic is fine
    here — the value never round-trips back into billing math.
    """
    non_cached, cached, out_tok = _split_tokens(usage)
    card = get_active_card(model)
    return (
        non_cached * card.upstream.input_uncached
        + cached * card.upstream.input_cached
        + out_tok * card.upstream.output
    ) / 1_000_000_000_000
