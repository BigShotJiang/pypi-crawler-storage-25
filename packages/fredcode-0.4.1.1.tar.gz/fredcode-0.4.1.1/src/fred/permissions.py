"""Permission gate for destructive tools.

PermissionPolicy is session-scoped. `--yolo` bypasses entirely. Each tool
call that requires permission gets a y/n/a/d prompt; choosing 'a' adds the
tool name to an always-allow set for the rest of the session, 'd' shows
the full args dict and re-prompts.

`last_outcome` and `last_prompt_ms` are populated on every `check()` call
so the registry can record telemetry without changing the bool return
contract.

P3.1 layers a `RuleEngine` on top of the Panel. Three lists — ``allow`` /
``ask`` / ``deny`` — of ``Tool(specifier)`` patterns are loaded from
``.fred/settings.json`` (project) and ``.fred/settings.local.json``
(local, gitignored). Evaluation runs deny → ask → allow on every
permission-required tool BEFORE the y/n/a/d Panel:

  - rule_deny  → return False, surface ``rule_deny`` outcome
  - rule_allow → return True, surface ``rule_allow`` outcome
  - ask        → still show the Panel (lets ask-rules override the
                 in-session ``always_allow`` so the user can soft-
                 quarantine a tool/specifier they previously [a]llowed)
  - no match   → existing y/n/a/d Panel runs unchanged

Picking [a] at the Panel persists a rule to ``settings.local.json`` via
``append_allow_rule``; that rule is loaded next session.

Wildcards are deliberately conservative:

  - Pattern syntax is the shared ``Tool(<glob>)`` grammar from
    ``_matchers.py`` so the hook system, the `/perms` slash, and the
    rule engine all speak the same language.
  - Bash specifiers containing shell-control metacharacters (``;``,
    ``&&``, ``||``, ``|``, ``&``, backticks, ``$()``, newlines) are
    NEVER allowed by an allow-rule glob even when the glob otherwise
    matches. ``Bash(git *)`` does NOT let ``git status; rm -rf /``
    through. Deny-rules still match these strings (so users can
    deny a quoting bypass intentionally).
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Literal

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.text import Text

from fred._settings import walk_up_for_settings
from fred._matchers import (
    _canonical_tool_name,
    _specifier_for,
    match_tool_pattern,
)
from fred.tools.base import Tool

RuleVerdict = Literal["allow", "ask", "deny"]


def _summary_for(tool_name: str, args: dict) -> Text:
    t = Text()
    if tool_name == "bash":
        t.append("$ ", style="bold cyan")
        t.append(args.get("command", ""))
    elif tool_name == "create_file":
        t.append("create ", style="bold green")
        t.append(args.get("path", ""))
        size = len(args.get("content", "") or "")
        t.append(f"  ({size} chars)", style="dim")
    elif tool_name == "str_replace":
        t.append("edit   ", style="bold yellow")
        t.append(args.get("path", ""))
        old_lines = (args.get("old_str") or "").splitlines()
        new_lines = (args.get("new_str") or "").splitlines()
        t.append(f"\n  -{len(old_lines)} lines  +{len(new_lines)} lines",
                 style="dim")
    elif tool_name == "web_search":
        from fred.web_pricing import estimate_search_microcents, fmt_dollars

        q = (args.get("query") or "")[:120]
        depth = args.get("search_depth") or "basic"
        cost = fmt_dollars(estimate_search_microcents(search_depth=depth))
        t.append("search ", style="bold blue")
        t.append(f'"{q}"', style="bold")
        if args.get("max_results"):
            t.append(f"\n  max_results: {args['max_results']}", style="dim")
        if args.get("topic", "general") != "general":
            t.append(f"  topic: {args['topic']}", style="dim")
        if depth != "basic":
            t.append(f"  depth: {depth}", style="dim")
        t.append(f"\n  ~{cost} ({depth})", style="dim cyan")
    elif tool_name == "web_fetch":
        from fred.web_pricing import estimate_extract_microcents, fmt_dollars

        urls = args.get("urls") or []
        depth = args.get("extract_depth") or "basic"
        cost = fmt_dollars(
            estimate_extract_microcents(urls=len(urls), extract_depth=depth)
        )
        t.append("fetch  ", style="bold blue")
        t.append(
            f"{len(urls)} URL{'s' if len(urls) != 1 else ''}", style="bold"
        )
        for u in urls[:5]:
            t.append(f"\n  {u}", style="dim")
        if len(urls) > 5:
            t.append(f"\n  …  +{len(urls) - 5} more", style="dim")
        t.append(f"\n  ~{cost} ({depth} extract)", style="dim cyan")
    elif tool_name.startswith("mcp__"):
        # P4.2: MCP tool — render as `mcp · [server] tool_name` plus a
        # short args summary so the user sees enough context to decide
        # on the y/n/a/d Panel without expanding [d]etails for every
        # call. Tool name shape is ``mcp__<server>__<tool>``.
        rest = tool_name[len("mcp__"):]
        server, _, tool_short = rest.partition("__")
        t.append("mcp    ", style="bold magenta")
        t.append(f"[{server or 'unknown'}] ", style="cyan")
        t.append(tool_short or rest, style="bold")
        if args:
            args_text = repr(args)
            if len(args_text) > 200:
                args_text = args_text[:200] + "…"
            t.append("\n  ", style="dim")
            t.append(args_text, style="dim")
    else:
        # Generic: short repr
        text = repr(args)
        if len(text) > 200:
            text = text[:200] + "…"
        t.append(text, style="dim")
    return t


# ---------------------------------------------------------------------------
# Rule engine

# Shell metacharacters that an allow-rule glob must NEVER pass through
# for the ``bash`` tool. These are the operators that combine multiple
# commands or perform unquoted substitution; if any appear in the bash
# command string, an allow-rule glob does not authorize the call (deny-
# rules can still flag the same string for telemetry / explicit refusal).
# Backticks and ``$(`` cover Bash command substitution; ``;``, ``&&``,
# ``||``, ``|``, and ``&`` cover chaining and pipelines. Newlines are
# also rejected because a multi-line command lets attackers smuggle a
# second command past a single-line glob.
_SHELL_BYPASS_RE = re.compile(r"[;&|`\n\r]|\$\(|&&|\|\|")


def _bash_string_has_bypass(spec: str) -> bool:
    """True iff `spec` contains a shell metacharacter that an allow-rule
    glob must refuse to authorize. Used only by the allow-rule path —
    deny-rules still match the same string by design."""
    return _SHELL_BYPASS_RE.search(spec) is not None


@dataclass
class RuleEngine:
    """Evaluate permission rules in deny → ask → allow order.

    The three lists are immutable inputs; the engine itself does no I/O.
    Persistence (load/append) lives in module-level helpers below so the
    engine can be unit-tested with hand-built rule lists.
    """

    deny: list[str] = field(default_factory=list)
    ask: list[str] = field(default_factory=list)
    allow: list[str] = field(default_factory=list)
    # Filled in by ``evaluate`` so callers (telemetry, ``/perms``) can
    # surface the exact pattern that won. Reset on every call.
    last_match: str | None = None

    def evaluate(self, tool_name: str, args: dict) -> RuleVerdict | None:
        """Evaluate the three lists and return the first verdict.

        Order: deny first (so an explicit deny beats every ask/allow),
        then ask (so a user can shadow an old session-allow with a
        fresh prompt), then allow. Returns ``None`` if nothing matched;
        the caller falls through to the y/n/a/d Panel.

        For ``bash`` tools, the allow-rule path additionally rejects any
        command containing a shell-bypass metacharacter — see
        ``_SHELL_BYPASS_RE``. Deny-rules deliberately do NOT apply that
        guard: a user wanting to deny ``Bash(git *)`` should still trip
        the rule on ``git push; rm -rf /``.
        """
        self.last_match = None
        for rule in self.deny:
            if match_tool_pattern(rule, tool_name, args):
                self.last_match = rule
                return "deny"
        for rule in self.ask:
            if match_tool_pattern(rule, tool_name, args):
                self.last_match = rule
                return "ask"
        for rule in self.allow:
            if match_tool_pattern(rule, tool_name, args):
                # Shell-injection guard: an allow-rule glob must not
                # authorize a bash command that smuggles in additional
                # statements. Skip without setting last_match — falling
                # through to the Panel is safer than mis-attributing
                # the (now-not-granted) outcome to this rule.
                if _canonical_tool_name(tool_name) == "bash":
                    spec = _specifier_for(tool_name, args)
                    if _bash_string_has_bypass(spec):
                        continue
                self.last_match = rule
                return "allow"
        return None


# ---------------------------------------------------------------------------
# Persistence: walk cwd → home for project + local settings, like hooks.

_LOCAL_FILENAME = "settings.local.json"
_PROJECT_FILENAME = "settings.json"


def _read_settings(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _normalize_rule_list(raw) -> list[str]:
    """Coerce a settings-file ``permissions[<list>]`` blob to a list[str].

    Tolerant: skips non-string entries, blanks, and accidental nesting.
    A malformed entry is dropped silently so a typo in the local file
    doesn't fail-closed the whole session.
    """
    if not isinstance(raw, list):
        return []
    out: list[str] = []
    for entry in raw:
        if isinstance(entry, str):
            s = entry.strip()
            if s:
                out.append(s)
    return out


def _extract_rules(settings: dict) -> tuple[list[str], list[str], list[str]]:
    """Pull (allow, ask, deny) out of a parsed settings dict."""
    perms = settings.get("permissions") if isinstance(settings, dict) else None
    if not isinstance(perms, dict):
        return [], [], []
    return (
        _normalize_rule_list(perms.get("allow")),
        _normalize_rule_list(perms.get("ask")),
        _normalize_rule_list(perms.get("deny")),
    )


def load_permission_rules(start: Path | None = None) -> RuleEngine:
    """Build a RuleEngine from the cwd-anchored settings layers.

    Layer order (later layers EXTEND earlier ones — never replace, since
    rule lists compose semantically: a project-deny shouldn't mask a
    user's local-deny):

      1. ``~/.fred/settings.json`` (user-global, optional)
      2. Project-level ``.fred/settings.json`` walked from `start` upward
         (one or more files; closer-to-`start` files appear later but
         all are concatenated)
      3. Local override ``.fred/settings.local.json`` walked the same way
         (gitignored — for "always allow" picks at the Panel)

    Within each list, evaluation order in ``RuleEngine`` is
    deny → ask → allow, but the input *order* of patterns within a list
    is preserved as-is so a more-specific allow placed ahead of a
    broader allow wins (first-match-wins inside each list).
    """
    start = start or Path.cwd()

    sources: list[Path] = []
    user_settings = Path.home() / ".fred" / _PROJECT_FILENAME
    if user_settings.exists():
        sources.append(user_settings)
    # Project files: farthest-first so the closest one's rules are
    # appended last; combined with first-match-wins per list, this
    # gives closer files precedence within a list when they all add
    # narrowing-style entries.
    project_paths = list(reversed(walk_up_for_settings(start, _PROJECT_FILENAME)))
    sources.extend(project_paths)
    # Local files: same walk, applied AFTER the project files so a
    # local entry shadows project entries within its list.
    local_paths = list(reversed(walk_up_for_settings(start, _LOCAL_FILENAME)))
    sources.extend(local_paths)

    allow: list[str] = []
    ask: list[str] = []
    deny: list[str] = []
    for path in sources:
        a, s, d = _extract_rules(_read_settings(path))
        allow.extend(a)
        ask.extend(s)
        deny.extend(d)

    return RuleEngine(allow=allow, ask=ask, deny=deny)


def _local_settings_path(start: Path | None = None) -> Path:
    """Return the path to write/read for the project-local settings file.

    If a ``.fred/settings.local.json`` already exists somewhere in the
    walk, write to the closest one. Otherwise create one at
    ``<start>/.fred/settings.local.json`` so the entry lives next to the
    project's ``.fred/`` (which AGENTS.md auto-loading already populates).
    """
    start = (start or Path.cwd()).resolve()
    existing = walk_up_for_settings(start, _LOCAL_FILENAME)
    if existing:
        return existing[0]
    return start / ".fred" / _LOCAL_FILENAME


def _write_settings(path: Path, data: dict) -> None:
    """Atomically rewrite the local settings file. Best-effort: never raises."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        # tmp + rename so a concurrent reader never sees a partial file.
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(
            json.dumps(data, indent=2, sort_keys=False) + "\n",
            encoding="utf-8",
        )
        tmp.replace(path)
    except OSError:
        # Persistence is best-effort: the in-session always-allow set
        # already covers the user's intent for the current run.
        return


def _rule_for(tool_name: str, args: dict) -> str:
    """Compose the canonical rule string for a tool/args pair.

    For tools with a known specifier (``bash``, ``view``, ``str_replace``,
    ``create_file``, ``glob``, ``grep``) we render ``Tool(specifier)``
    with the specifier verbatim; the user wants "allow exactly this
    command" semantics when they hit [a], not a wildcard expansion.
    Anything else degrades to the bare ``Tool`` name — broad but
    unambiguous.
    """
    canonical = _canonical_tool_name(tool_name)
    if canonical in ("bash", "view", "create_file", "str_replace", "glob", "grep"):
        # Title-case the leading letter so the rule reads like the
        # examples in AGENTS.md / docs (``Bash(...)``, not ``bash(...)``).
        display = canonical[0].upper() + canonical[1:]
        spec = _specifier_for(tool_name, args)
        return f"{display}({spec})"
    return tool_name


def append_allow_rule(
    tool_name: str,
    args: dict,
    *,
    start: Path | None = None,
) -> str | None:
    """Append the ``allow`` rule for ``tool_name(args)`` to the local file.

    Returns the rule string that was added, or ``None`` if the rule was
    already present. Never raises: if the write fails, the in-session
    allow-set still applies for the rest of the run.
    """
    rule = _rule_for(tool_name, args)
    path = _local_settings_path(start)
    data = _read_settings(path)
    if not isinstance(data, dict):
        data = {}
    perms = data.get("permissions")
    if not isinstance(perms, dict):
        perms = {}
        data["permissions"] = perms
    allow = perms.get("allow")
    if not isinstance(allow, list):
        allow = []
        perms["allow"] = allow
    if rule in allow:
        return None
    allow.append(rule)
    _write_settings(path, data)
    return rule


def add_rule(
    rule: str,
    list_name: Literal["allow", "ask", "deny"],
    *,
    start: Path | None = None,
) -> bool:
    """Append `rule` to the named list in the local file.

    Returns True if the rule was newly added, False if it was already
    present. Used by ``/perms add`` in cli.py.
    """
    if list_name not in ("allow", "ask", "deny"):
        raise ValueError(f"unknown list: {list_name!r}")
    path = _local_settings_path(start)
    data = _read_settings(path)
    if not isinstance(data, dict):
        data = {}
    perms = data.get("permissions")
    if not isinstance(perms, dict):
        perms = {}
        data["permissions"] = perms
    bucket = perms.get(list_name)
    if not isinstance(bucket, list):
        bucket = []
        perms[list_name] = bucket
    if rule in bucket:
        return False
    bucket.append(rule)
    _write_settings(path, data)
    return True


def remove_rule(
    rule: str,
    *,
    start: Path | None = None,
) -> bool:
    """Remove `rule` from any of the three lists in the local file.

    Returns True if the rule was found and removed, False otherwise.
    Walks all three buckets so the user doesn't have to remember which
    list they originally put the rule in. Used by ``/perms remove``.
    """
    path = _local_settings_path(start)
    data = _read_settings(path)
    if not isinstance(data, dict):
        return False
    perms = data.get("permissions")
    if not isinstance(perms, dict):
        return False
    removed = False
    for list_name in ("allow", "ask", "deny"):
        bucket = perms.get(list_name)
        if not isinstance(bucket, list):
            continue
        if rule in bucket:
            bucket.remove(rule)
            removed = True
    if removed:
        _write_settings(path, data)
    return removed


def list_active_rules(rules: RuleEngine) -> Iterable[tuple[str, str]]:
    """Iterate (list_name, rule) pairs for ``/perms`` printing.

    Order: deny first (most consequential), then ask, then allow —
    matching the engine's evaluation order so the user reads top-to-
    bottom and sees what fires first.
    """
    for list_name, bucket in (
        ("deny", rules.deny), ("ask", rules.ask), ("allow", rules.allow),
    ):
        for rule in bucket:
            yield list_name, rule


# ---------------------------------------------------------------------------
# Approval mode (P4.1).
#
# Orthogonal to sandbox mode: approval governs the y/n/a/d Panel gate,
# sandbox governs OS-enforced ground truth. Three values, ported from
# Codex CLI:
#
#   - ``untrusted``  — show Panel for ALL permission-required tools
#                      (matches the conservative default).
#   - ``on_request`` — show Panel only when no rule grants; the existing
#                      always_allow set short-circuits (this is the
#                      pre-P4.1 behavior, the friendly default).
#   - ``never``      — skip the Panel entirely. Subset of YOLO: the user
#                      acknowledges they've configured rules + a sandbox.
#                      Documented as "be careful — sandbox is your
#                      defense" in the CLI banner.
#
# Resolution priority: explicit attribute on PermissionPolicy >
# FRED_APPROVAL_MODE env var > "on_request" default. Env var read at
# Policy construction so tests can ``monkeypatch.setenv`` per case.

ApprovalMode = Literal["untrusted", "on_request", "never"]
VALID_APPROVAL_MODES: tuple[ApprovalMode, ...] = (
    "untrusted", "on_request", "never",
)
DEFAULT_APPROVAL_MODE: ApprovalMode = "on_request"


def normalize_approval_mode(raw: str | None) -> ApprovalMode | None:
    """Return a known ApprovalMode or None on invalid/missing input."""
    if raw is None:
        return None
    s = raw.strip().lower().replace("-", "_")
    if s in VALID_APPROVAL_MODES:
        return s  # type: ignore[return-value]
    return None


def resolve_approval_mode(explicit: str | None = None) -> ApprovalMode:
    """Resolve the active approval mode (explicit > env > default)."""
    e = normalize_approval_mode(explicit)
    if e is not None:
        return e
    import os as _os
    e = normalize_approval_mode(_os.environ.get("FRED_APPROVAL_MODE"))
    if e is not None:
        return e
    return DEFAULT_APPROVAL_MODE


# ---------------------------------------------------------------------------
# PermissionPolicy

class PermissionPolicy:
    def __init__(
        self,
        yolo: bool = False,
        console: Console | None = None,
        *,
        rules: RuleEngine | None = None,
        rules_start: Path | None = None,
        approval_mode: str | None = None,
    ) -> None:
        self.yolo = yolo
        self.always_allow: set[str] = set()
        self._console = console or Console()
        self.last_outcome: str | None = None
        self.last_prompt_ms: int | None = None
        # P3.1: the rule engine consulted before the Panel. Tests pass
        # an explicit ``rules`` (often empty) to exercise the legacy
        # y/n/a/d behavior in isolation; production sessions let
        # ``load_permission_rules`` walk cwd → home for the user's
        # configured rules. ``rules_start`` lets tests scope the local
        # settings file walk to a tmp_path.
        self._rules_start = rules_start
        if rules is not None:
            self.rules = rules
        else:
            self.rules = load_permission_rules(rules_start)
        # Surfaces the rule string that produced ``rule_allow`` /
        # ``rule_deny`` so callers can attach it to telemetry.
        self.last_matched_rule: str | None = None
        # P4.1: approval-mode axis. ``never`` short-circuits the Panel
        # the same way ``yolo`` does; ``untrusted`` forces the Panel
        # even when always_allow would normally short-circuit; default
        # ``on_request`` preserves the legacy pre-P4.1 behavior.
        self.approval_mode: ApprovalMode = resolve_approval_mode(approval_mode)

    def check(self, tool: Tool, args: dict) -> bool:
        self.last_prompt_ms = None
        self.last_matched_rule = None
        if self.yolo:
            self.last_outcome = "yolo"
            return True
        # P4.1 approval=never: behaves like yolo but emits a distinct
        # outcome label so analytics can tell them apart. Document
        # carefully in the CLI banner — sandbox is the defense.
        if self.approval_mode == "never":
            self.last_outcome = "approval_never"
            return True

        # P3.1: rule engine runs BEFORE the in-session always-allow set
        # so a freshly added ``ask`` rule can shadow an earlier session
        # [a]ll-allow grant. The Panel still shows on ``ask``.
        verdict = self.rules.evaluate(tool.name, args)
        if verdict == "deny":
            self.last_outcome = "rule_deny"
            self.last_matched_rule = self.rules.last_match
            return False
        # P4.1 approval=untrusted: skip the rule_allow / always_allow
        # short-circuits and force the Panel. Deny rules still apply
        # (they're a hard floor); allow rules become advisory.
        if self.approval_mode == "untrusted":
            # Fall through to the Panel even when allow / always_allow
            # would normally short-circuit.
            pass
        else:
            if verdict == "allow":
                self.last_outcome = "rule_allow"
                self.last_matched_rule = self.rules.last_match
                return True
            # ``ask`` falls through to the Panel; ``None`` (no match) also
            # falls through. The session always_allow set is consulted only
            # when no rule matched at all — an explicit ``ask`` rule
            # supersedes a stale session grant.
            if verdict is None and tool.name in self.always_allow:
                self.last_outcome = "always_allow"
                return True

        body = _summary_for(tool.name, args)
        body.append("\n\n")
        body.append("[y]es  [n]o  [a]lways for ", style="bold")
        body.append(tool.name, style="bold cyan")
        body.append("  [d]etails", style="bold")
        self._console.print(Panel(
            body,
            title=f"[yellow]?[/] [bold]{tool.name}[/]",
            title_align="left",
            border_style="yellow",
            expand=False,
        ))

        t0 = time.perf_counter()
        while True:
            answer = Prompt.ask(
                "",
                choices=["y", "n", "a", "d"],
                default="y",
                show_choices=False,
                console=self._console,
            )
            if answer == "d":
                self._console.print(Panel(
                    json.dumps(args, indent=2, default=str),
                    title="full args",
                    title_align="left",
                    border_style="dim",
                    expand=False,
                ))
                continue
            break
        self.last_prompt_ms = int((time.perf_counter() - t0) * 1000)
        if answer == "a":
            self.always_allow.add(tool.name)
            self.last_outcome = "user_a"
            # Persist the picked allow rule so the same call doesn't
            # need a Panel next session. Persistence is best-effort —
            # a write failure just means the session-only set still
            # covers the rest of THIS run.
            try:
                added = append_allow_rule(
                    tool.name, args, start=self._rules_start,
                )
                if added is not None:
                    # Mirror the appended rule into the live engine so
                    # subsequent calls THIS session take the
                    # ``rule_allow`` path instead of always_allow. Both
                    # behave identically here, but keeping them in
                    # sync makes telemetry attribution honest.
                    self.rules.allow.append(added)
            except Exception:
                pass
            return True
        if answer == "y":
            self.last_outcome = "user_y"
            return True
        self.last_outcome = "user_n"
        return False
