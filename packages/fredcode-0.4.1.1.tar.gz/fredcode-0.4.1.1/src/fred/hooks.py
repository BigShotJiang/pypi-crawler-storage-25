"""User-configurable hook system (P2.4).

A hook is a shell command the user wires into one of four lifecycle events:

  - ``PreToolUse``: fires after the permission gate has granted the call but
    BEFORE the tool's handler runs. Exit 2 blocks the call. Stdout may
    return JSON ``{"updatedInput": {...}}`` to mutate the args the tool
    sees.
  - ``PostToolUse``: fires AFTER the handler returns, BEFORE the result is
    appended to the model conversation. Exit 2 cannot un-run the tool but
    is surfaced as an error in the wire result so the model sees it.
  - ``UserPromptSubmit``: fires in the REPL after the user hits Enter and
    before the agent starts a turn. Exit 2 cancels the turn (the loop
    prints a banner and returns to the prompt).
  - ``Stop``: fires once on session shutdown. Exit codes are advisory;
    failures here cannot fail the host.

Configuration shape (``.fred/settings.json`` at project root and/or
``~/.fred/settings.json``):

    {
      "hooks": {
        "PreToolUse": [
          {"matcher": "Bash(rm -rf *)", "command": "echo blocked", "timeout": 5}
        ],
        "PostToolUse": [...],
        "UserPromptSubmit": [...],
        "Stop": [...]
      }
    }

User-level (``~/.fred/settings.json``) hooks load first, then project-level
(``.fred/settings.json`` walked from cwd up to a git root) overrides any
keys with the same event. Within an event, hooks run in declaration order;
the FIRST exit-2 short-circuits the rest.

Wire format
-----------

The hook subprocess receives a JSON object on stdin matching the
event-specific shape returned by ``_payload_for``:

  - PreToolUse:  ``{"event": "PreToolUse", "tool_name": "...", "tool_input": {...}}``
  - PostToolUse: ``{"event": "PostToolUse", "tool_name": "...", "tool_input": {...}, "tool_output": "..."}``
  - UserPromptSubmit: ``{"event": "UserPromptSubmit", "user_input": "..."}``
  - Stop:        ``{"event": "Stop", "reason": "..."}``

Hooks may emit JSON on stdout to influence the host:

  - PreToolUse: ``{"updatedInput": {"command": "ls -1"}}`` replaces the
    args the tool handler will receive. Other shapes are ignored.

Exit-code semantics
-------------------

  - 0:  allow / continue. Stdout (if JSON) may carry an ``updatedInput``
    payload for PreToolUse.
  - 2:  BLOCK. Surface a structured error.
  - other non-zero: warn-only. The hook's stderr is discarded; we record
    the exit code via telemetry but don't disrupt the agent loop. This
    matches Claude Code's behavior and keeps a flaky hook from breaking
    the user's session.

Trust + secrets
---------------

Hooks are trusted code (the user wrote them; the user installed them).
The subprocess inherits the parent's full environment via
``os.environ.copy()``, including ``FRED_API_KEY`` / ``DEEPSEEK_API_KEY``.
Do NOT register a hook from an untrusted ``settings.json`` file.

Telemetry
---------

Every hook invocation emits a ``hook_run`` event with payload:

    {
      "event": str,                # e.g. "PreToolUse"
      "matcher": str | None,       # the pattern that matched, or None
      "command": str,              # the shell command (truncated to 200ch)
      "exit_code": int | None,     # subprocess returncode, None on timeout
      "duration_ms": int,
      "blocked": bool,             # True iff exit 2
      "hook_stdout_chars": int,    # CHAR COUNT, never the body — secrets-safe
      "timed_out": bool,
    }

The ``hook_stdout_chars`` field is a count, not the content. The redactor
audit (``telemetry/redact.py``) treats hook output as user-controlled and
never sends the bytes to the DB.
"""
from __future__ import annotations

import json
import os
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from fred._matchers import match_tool_pattern
from fred._settings import walk_up_for_settings
from fred.telemetry import NullTracer, Tracer, TurnHandle

VALID_EVENTS: tuple[str, ...] = (
    "PreToolUse",
    "PostToolUse",
    "UserPromptSubmit",
    "Stop",
)

# Per-hook default subprocess timeout. The user can raise it per hook via
# the ``timeout`` config field; we cap below at ``_MAX_TIMEOUT_SEC`` so a
# pathological config can't deadlock the agent loop.
_DEFAULT_TIMEOUT_SEC = 30
_MAX_TIMEOUT_SEC = 600


@dataclass(frozen=True)
class HookConfig:
    """A single configured hook entry."""

    event: str
    matcher: str | None  # None means "no matcher" (catch-all). For non-tool
                         # events (UserPromptSubmit, Stop), the matcher is
                         # ignored — those events aren't tool-scoped.
    command: str
    timeout: int = _DEFAULT_TIMEOUT_SEC

    def effective_timeout(self) -> int:
        if self.timeout <= 0:
            return _DEFAULT_TIMEOUT_SEC
        return min(self.timeout, _MAX_TIMEOUT_SEC)


@dataclass
class HookOutcome:
    """The post-run summary surfaced to callers and telemetry."""

    blocked: bool
    exit_code: int | None
    duration_ms: int
    stdout: str
    stderr: str
    timed_out: bool
    updated_input: dict | None = None
    # The hook config that produced this outcome — useful for the
    # block-reason error rendering. ``None`` only on the
    # "no matching hook" code path (where we never invoke anything).
    hook: HookConfig | None = None


# ---------------------------------------------------------------------------
# Settings loading


def _read_settings(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _parse_hook_entries(event: str, raw: Any) -> list[HookConfig]:
    """Parse the array under ``settings["hooks"][event]`` into HookConfigs.

    Tolerant: skips entries that don't have a ``command`` string. Bad
    timeout values fall back to the default. We never raise from here —
    a malformed hook must not break the agent loop.
    """
    if not isinstance(raw, list):
        return []
    out: list[HookConfig] = []
    for entry in raw:
        if not isinstance(entry, dict):
            continue
        cmd = entry.get("command")
        if not isinstance(cmd, str) or not cmd.strip():
            continue
        matcher = entry.get("matcher")
        if matcher is not None and not isinstance(matcher, str):
            matcher = None
        timeout = entry.get("timeout", _DEFAULT_TIMEOUT_SEC)
        if not isinstance(timeout, int) or timeout <= 0:
            timeout = _DEFAULT_TIMEOUT_SEC
        out.append(HookConfig(
            event=event, matcher=matcher, command=cmd, timeout=timeout,
        ))
    return out


def load_hooks_config(start: Path | None = None) -> dict[str, list[HookConfig]]:
    """Load and merge user-level + project-level hooks for `start` cwd.

    Resolution order (later wins per-event when the keys collide):

      1. ``~/.fred/settings.json`` (user-level)
      2. Project-level ``.fred/settings.json`` walked from `start` upward,
         with the file CLOSEST to `start` overriding farther ancestors.

    Returns a dict keyed by event name; missing events map to an empty
    list. Unknown event keys in settings are dropped silently.
    """
    start = start or Path.cwd()
    sources: list[Path] = []
    user_settings = Path.home() / ".fred" / "settings.json"
    if user_settings.exists():
        sources.append(user_settings)
    # Walking returns nearest-first; we want farthest-first so the closest
    # one is applied last and therefore wins.
    project_paths = list(reversed(walk_up_for_settings(start, "settings.json")))
    sources.extend(project_paths)

    merged: dict[str, list[HookConfig]] = {ev: [] for ev in VALID_EVENTS}
    for path in sources:
        data = _read_settings(path)
        hooks = data.get("hooks") if isinstance(data, dict) else None
        if not isinstance(hooks, dict):
            continue
        for event in VALID_EVENTS:
            entries = _parse_hook_entries(event, hooks.get(event))
            if entries:
                # Override semantics: a layer that defines the event REPLACES
                # the lower layer's entries. Layers that don't mention the
                # event leave it untouched. This matches the documented
                # "local overrides project; project overrides user" rule.
                merged[event] = entries
    return merged


# ---------------------------------------------------------------------------
# Hook execution


def _payload_for(
    event: str,
    *,
    tool_name: str | None = None,
    tool_input: dict | None = None,
    tool_output: str | None = None,
    user_input: str | None = None,
    reason: str | None = None,
) -> dict:
    """Shape the JSON-stdin object the subprocess will receive."""
    payload: dict[str, Any] = {"event": event}
    if event == "PreToolUse":
        payload["tool_name"] = tool_name
        payload["tool_input"] = tool_input or {}
    elif event == "PostToolUse":
        payload["tool_name"] = tool_name
        payload["tool_input"] = tool_input or {}
        payload["tool_output"] = tool_output or ""
    elif event == "UserPromptSubmit":
        payload["user_input"] = user_input or ""
    elif event == "Stop":
        payload["reason"] = reason or ""
    return payload


def _run_one(
    hook: HookConfig,
    payload: dict,
) -> HookOutcome:
    """Spawn a single hook subprocess. Never raises on hook misbehavior.

    We use ``shell=True`` so users can write multi-command pipelines in
    their config. ``input=`` is a JSON string; the child reads it from
    stdin. The parent env (incl. API keys) is inherited verbatim — hooks
    are trusted, and they often need FRED_API_KEY to call back into Fred.
    """
    env = os.environ.copy()
    stdin_blob = json.dumps(payload, separators=(",", ":"))
    started = time.perf_counter()
    timed_out = False
    stdout = ""
    stderr = ""
    exit_code: int | None = None
    try:
        cp = subprocess.run(
            hook.command,
            shell=True,
            input=stdin_blob,
            capture_output=True,
            text=True,
            timeout=hook.effective_timeout(),
            env=env,
        )
        stdout = cp.stdout or ""
        stderr = cp.stderr or ""
        exit_code = cp.returncode
    except subprocess.TimeoutExpired as e:
        timed_out = True
        stdout = e.stdout if isinstance(e.stdout, str) else (
            e.stdout.decode("utf-8", "replace") if e.stdout else ""
        )
        stderr = e.stderr if isinstance(e.stderr, str) else (
            e.stderr.decode("utf-8", "replace") if e.stderr else ""
        )
    except (OSError, ValueError) as e:
        # Spawn failure: surface as a non-blocking warn (exit_code stays
        # None so callers know the subprocess didn't actually run).
        stderr = f"{type(e).__name__}: {e}"

    duration_ms = int((time.perf_counter() - started) * 1000)
    blocked = exit_code == 2
    updated_input = _maybe_extract_updated_input(stdout) if not timed_out else None
    return HookOutcome(
        blocked=blocked,
        exit_code=exit_code,
        duration_ms=duration_ms,
        stdout=stdout,
        stderr=stderr,
        timed_out=timed_out,
        updated_input=updated_input,
        hook=hook,
    )


def _maybe_extract_updated_input(stdout: str) -> dict | None:
    """Try to parse stdout as JSON and return ``updatedInput`` if present.

    Hooks that don't speak the JSON protocol just print logs to stdout —
    we silently ignore non-JSON output so a ``echo blocked`` hook stays
    convenient to write.
    """
    s = (stdout or "").strip()
    if not s or s[0] not in "{[":
        return None
    try:
        parsed = json.loads(s)
    except ValueError:
        return None
    if isinstance(parsed, dict):
        ui = parsed.get("updatedInput")
        if isinstance(ui, dict):
            return ui
    return None


def _emit_telemetry(
    tracer: Tracer,
    turn: TurnHandle | None,
    hook: HookConfig,
    outcome: HookOutcome,
) -> None:
    """Fire-and-forget hook_run event. The tracer is daemon-thread-backed;
    this call is non-blocking by contract."""
    cmd_short = hook.command if len(hook.command) <= 200 else hook.command[:200]
    tracer.event(
        "hook_run",
        payload={
            "event": hook.event,
            "matcher": hook.matcher,
            "command": cmd_short,
            "exit_code": outcome.exit_code,
            "duration_ms": outcome.duration_ms,
            "blocked": outcome.blocked,
            "hook_stdout_chars": len(outcome.stdout or ""),
            "timed_out": outcome.timed_out,
        },
        turn=turn,
    )


def run_hooks(
    event: str,
    hooks_config: dict[str, list[HookConfig]],
    *,
    tracer: Tracer | None = None,
    turn: TurnHandle | None = None,
    tool_name: str | None = None,
    tool_input: dict | None = None,
    tool_output: str | None = None,
    user_input: str | None = None,
    reason: str | None = None,
) -> HookOutcome | None:
    """Run all hooks registered for `event` in declaration order.

    Returns the FIRST blocking outcome (exit 2) if any hook blocks, else
    the LAST outcome from a non-blocking hook (so callers can inspect
    ``updated_input`` from a PreToolUse hook). Returns ``None`` when no
    hooks fire (no matchers matched, or no hooks configured for the
    event).

    Tool-scoped events (PreToolUse / PostToolUse) consult the matcher
    field; non-tool events ignore the matcher and fire every hook in the
    list.
    """
    if tracer is None:
        tracer = NullTracer()
    entries = hooks_config.get(event, [])
    if not entries:
        return None

    is_tool_event = event in ("PreToolUse", "PostToolUse")
    last_outcome: HookOutcome | None = None
    for hook in entries:
        if is_tool_event and not match_tool_pattern(
            hook.matcher, tool_name or "", tool_input or {},
        ):
            continue
        payload = _payload_for(
            event,
            tool_name=tool_name,
            tool_input=tool_input,
            tool_output=tool_output,
            user_input=user_input,
            reason=reason,
        )
        outcome = _run_one(hook, payload)
        _emit_telemetry(tracer, turn, hook, outcome)
        last_outcome = outcome
        if outcome.blocked:
            return outcome
    return last_outcome


def list_hooks_for(
    hooks_config: dict[str, list[HookConfig]],
) -> Iterable[tuple[str, HookConfig]]:
    """Iterate (event, hook) pairs in event order then declaration order.

    Used by the ``/hooks`` slash command to print a stable summary.
    """
    for event in VALID_EVENTS:
        for hook in hooks_config.get(event, []):
            yield event, hook
