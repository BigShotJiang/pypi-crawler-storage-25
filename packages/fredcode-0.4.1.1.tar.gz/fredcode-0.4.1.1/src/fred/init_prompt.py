"""System prompt + user directives for the ``/init`` slash command.

``/init`` runs as a constrained read-only subagent that scans the
current repo and produces an AGENTS.md draft. The prompt bodies live
on FredWeb (see :mod:`fred.prompt_cache`); this module owns the
mode-detection logic and the lookup keys.

Three runtime modes — the model sees the same system prompt for all
three; only the user directive differs:

- ``"fresh"`` — no AGENTS.md and no CLAUDE.md exist
- ``"improve"`` — AGENTS.md exists (precedence)
- ``"migrate"`` — only CLAUDE.md exists

``detect_init_mode(cwd)`` dispatches to the right directive based on
what's on disk. AGENTS.md wins if both are present (matches
``config.load_project_memory`` precedence).
"""
from __future__ import annotations

from pathlib import Path
from typing import Literal

from fred.prompt_cache import get_component

InitMode = Literal["fresh", "improve", "migrate"]

_DIRECTIVE_KEY_BY_MODE: dict[InitMode, str] = {
    "fresh": "init_directive_fresh",
    "improve": "init_directive_improve",
    "migrate": "init_directive_migrate",
}


def init_system_prompt() -> str:
    """Return the persistent role + structure + hard rules sent to the
    init subagent. Raises :class:`PromptsUnavailableError` if the on-disk
    prompt cache is missing."""
    return get_component("init_system")


def directive_for_mode(mode: InitMode) -> str:
    """Return the user directive string for an init mode. Raises
    :class:`PromptsUnavailableError` if the cache is missing."""
    return get_component(_DIRECTIVE_KEY_BY_MODE[mode])


def detect_init_mode(cwd: Path) -> tuple[InitMode, Path | None]:
    """Inspect cwd for AGENTS.md / CLAUDE.md and pick a mode.

    Returns ``("fresh", None)`` if neither exists, ``("improve",
    agents_path)`` if AGENTS.md exists (regardless of CLAUDE.md, since
    AGENTS.md takes precedence in :func:`config.load_project_memory`),
    or ``("migrate", claude_path)`` if only CLAUDE.md exists.
    """
    agents_path = cwd / "AGENTS.md"
    claude_path = cwd / "CLAUDE.md"
    if agents_path.exists():
        return "improve", agents_path
    if claude_path.exists():
        return "migrate", claude_path
    return "fresh", None
