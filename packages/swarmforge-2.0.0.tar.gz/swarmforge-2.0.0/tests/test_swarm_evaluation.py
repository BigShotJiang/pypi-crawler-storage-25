from swarmforge.evaluation.swarm import (
    build_graph_snapshot,
    build_heuristic_swarm_intents,
    build_intent_based_swarm_scenario_seeds,
    build_scenario_follow_up_user_beats,
    build_simulator_context,
    classify_assistant_turn,
    classify_scenario_feasibility,
    determine_next_user_input,
    sanitize_turn_context_for_simulator,
)
from swarmforge.swarm import SwarmDefinition, SwarmEdge, SwarmNode, SwarmVariable


def _swarm_definition():
    return SwarmDefinition(
        id="swarm-1",
        name="Support",
        nodes=[
            SwarmNode(
                id="triage",
                node_key="triage",
                name="Triage",
                intent="Route support issues",
                capabilities=["Classify requests", "Route to specialists"],
                system_prompt="Route incoming support requests.",
                is_entry_node=True,
            ),
            SwarmNode(
                id="billing",
                node_key="billing",
                name="Billing",
                intent="Handle billing questions",
                capabilities=["Explain invoices", "Resolve charges"],
                system_prompt="Handle billing support.",
            ),
            SwarmNode(
                id="faq",
                node_key="faq",
                name="FAQ",
                intent="Answer company policy questions",
                capabilities=["Answer policies", "Clarify returns"],
                system_prompt="Handle FAQ support.",
            ),
        ],
        edges=[
            SwarmEdge(
                id="edge-1",
                source_node_id="triage",
                target_node_id="billing",
                required_variables=["account_id"],
                handoff_description="Billing handoff",
            ),
            SwarmEdge(
                id="edge-2",
                source_node_id="billing",
                target_node_id="faq",
                required_variables=[],
                handoff_description="FAQ handoff",
            ),
        ],
        variables=[SwarmVariable(key_name="account_id")],
    )


def _graph_snapshot():
    return build_graph_snapshot(_swarm_definition())


def test_classify_scenario_feasibility_reports_conditional_when_route_needs_variables():
    feasibility = classify_scenario_feasibility(
        _graph_snapshot(),
        {
            "expected_routing": ["triage", "billing", "faq"],
            "required_agent_coverage": ["triage", "billing", "faq"],
        },
    )

    assert feasibility["status"] == "conditionally_feasible"
    assert feasibility["required_variables"] == ["account_id"]
    assert feasibility["reason"] == "requires_handoff_variables"


def test_classify_scenario_feasibility_reports_impossible_when_path_missing():
    feasibility = classify_scenario_feasibility(
        _graph_snapshot(),
        {
            "expected_routing": ["triage", "faq"],
            "required_agent_coverage": ["triage", "faq", "technical"],
        },
    )

    assert feasibility["status"] == "impossible"
    assert feasibility["reason"] == "scenario_references_unknown_nodes"
    assert feasibility["missing_nodes"] == ["technical"]


def test_classify_scenario_feasibility_allows_implicit_reroute_via_triage():
    swarm = SwarmDefinition(
        id="swarm-1",
        name="Support",
        nodes=_swarm_definition().nodes,
        edges=[
            SwarmEdge(
                id="edge-1",
                source_node_id="triage",
                target_node_id="billing",
                required_variables=["account_id"],
                handoff_description="Billing handoff",
            ),
            SwarmEdge(
                id="edge-2",
                source_node_id="triage",
                target_node_id="faq",
                required_variables=[],
                handoff_description="FAQ handoff",
            ),
        ],
    )
    feasibility = classify_scenario_feasibility(
        build_graph_snapshot(swarm),
        {
            "expected_routing": ["triage", "billing", "faq"],
            "required_agent_coverage": ["triage", "billing", "faq"],
        },
    )

    assert feasibility["status"] == "conditionally_feasible"
    assert feasibility["reason"] == "requires_handoff_variables"
    assert feasibility["resolved_paths"] == [["triage", "billing"], ["billing", "triage", "faq"]]


def test_build_scenario_follow_up_user_beats_backfills_legacy_seed():
    beats = build_scenario_follow_up_user_beats(
        _graph_snapshot(),
        {
            "expected_routing": ["triage", "billing"],
            "required_agent_coverage": ["triage", "billing", "faq"],
        },
    )

    assert beats
    assert all("agent_" not in beat for beat in beats)
    assert all("Remaining objective:" not in beat for beat in beats)


def test_build_heuristic_swarm_intents_returns_user_facing_titles():
    intents = build_heuristic_swarm_intents(_graph_snapshot(), 3)

    assert len(intents) == 3
    assert intents[0]["id"] == "intent_1"
    assert all(intent["title"] for intent in intents)
    assert all("agent_" not in intent["title"] for intent in intents)


def test_build_intent_based_swarm_scenario_seeds_applies_confirmed_titles():
    seeds = build_intent_based_swarm_scenario_seeds(
        _graph_snapshot(),
        ["Dispute an unexpected invoice", "Clarify refund policy details"],
        2,
        2,
    )

    assert len(seeds) == 2
    assert seeds[0]["starting_prompt"].startswith("I need help with dispute an unexpected invoice")
    assert seeds[0]["conversation_plan"].startswith("Primary user intent: Dispute an unexpected invoice.")
    assert seeds[0]["success_criteria"][0] == "Address the user intent: Dispute an unexpected invoice."


def test_build_scenario_follow_up_user_beats_discards_invalid_ai_beats():
    beats = build_scenario_follow_up_user_beats(
        _graph_snapshot(),
        {
            "follow_up_user_beats": [
                "I also need help with an agent that handle any billing issue recieved from the user.",
            ],
            "expected_routing": ["triage", "billing"],
            "required_agent_coverage": ["triage", "billing", "faq"],
        },
    )

    assert beats == ["I also have a general policy question."]


def test_sanitized_simulator_context_excludes_evaluator_metadata():
    turn_context = {
        "transfer_requested": True,
        "handoff_occurred": True,
        "handoff_details": [
            {
                "missing_variables": ["account_id"],
                "required_variables": ["account_id"],
                "resolved_variables": {"account_id": "ACME-991"},
                "global_variables": {"account_id": "ACME-991"},
            }
        ],
    }

    sanitized = sanitize_turn_context_for_simulator(turn_context)
    simulator_context = build_simulator_context(
        {"starting_prompt": "I need help with a charge."},
        "Can you share your account id?",
        turn_context,
        True,
        ["I also have a general policy question."],
        [],
        2,
        3,
    )

    assert sanitized == {
        "requested_fields": ["account_id"],
        "transfer_requested": True,
        "handoff_occurred": True,
        "handoff_blocked": False,
    }
    assert simulator_context["user_goal"] == "I need help with a charge."
    assert simulator_context["pending_follow_up_user_beats"] == ["I also have a general policy question."]
    assert simulator_context["consumed_follow_up_user_beats"] == []
    assert simulator_context["handoff_blocked"] is False
    assert simulator_context["assistant_turn_kind"] == "request_fields"
    assert simulator_context["awaiting_user_reply"] is True
    assert "remaining_objective" not in simulator_context
    assert "expected_routing" not in simulator_context


def test_classify_assistant_turn_uses_structured_turn_context():
    assert classify_assistant_turn(
        "Before I transfer you to billing, I still need your account ID.",
        {"requested_fields": ["account_id"], "transfer_requested": True, "handoff_occurred": False},
    ) == "request_fields"
    assert classify_assistant_turn(
        "Could you describe the billing error you are seeing?",
        {"requested_fields": [], "transfer_requested": False, "handoff_occurred": False},
    ) == "question"
    assert classify_assistant_turn(
        "Handing off to billing.",
        {"requested_fields": [], "transfer_requested": True, "handoff_occurred": True},
    ) == "handoff"


def test_determine_next_user_input_uses_simulator_reply_when_present():
    next_user_input, decision_source, next_beat_index = determine_next_user_input(
        signal="CONTINUE",
        next_user_input="I also need help with a policy question.",
        follow_up_user_beats=["I also need help with a policy question."],
        next_beat_index=0,
        missing_agents=["faq"],
        needs_more_turns=False,
    )

    assert next_user_input == "I also need help with a policy question."
    assert decision_source == "simulator_generated"
    assert next_beat_index == 1


def test_determine_next_user_input_uses_pending_beat_when_simulator_stops_early():
    next_user_input, decision_source, next_beat_index = determine_next_user_input(
        signal="STOP",
        next_user_input=None,
        follow_up_user_beats=["I also have a general policy question."],
        next_beat_index=0,
        missing_agents=["faq"],
        needs_more_turns=True,
    )

    assert next_user_input == "I also have a general policy question."
    assert decision_source == "follow_up_beat"
    assert next_beat_index == 1
