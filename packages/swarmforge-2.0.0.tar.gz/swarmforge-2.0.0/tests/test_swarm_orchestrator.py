import asyncio

from swarmforge.swarm import (
    AgentTurnResult,
    InMemorySessionStore,
    SwarmDefinition,
    SwarmEdge,
    SwarmNode,
    SwarmSession,
    SwarmVariable,
    function_tool,
    process_swarm_stream,
)


class _FunctionTurnRunner:
    def __init__(self, func):
        self._func = func

    async def run_turn(self, *, agent_node, contents, config):
        return await self._func(agent_node=agent_node, contents=contents, config=config)


def _build_swarm(*, nodes, edges=(), variables=()):
    return SwarmDefinition(
        id="swarm-1",
        name="Support Swarm",
        nodes=list(nodes),
        edges=list(edges),
        variables=list(variables),
    )


async def _collect_events(session, store, turn_runner, extract_required_variables=None):
    events = []
    async for event in process_swarm_stream(
        session,
        "Where is my issue?",
        store=store,
        turn_runner=turn_runner,
        extract_required_variables=extract_required_variables,
    ):
        events.append(event)
    return events


async def _collect_events_with_tools(
    session,
    store,
    turn_runner,
    *,
    tool_registry=None,
    tool_state=None,
):
    events = []
    async for event in process_swarm_stream(
        session,
        "Where is my issue?",
        store=store,
        turn_runner=turn_runner,
        tool_registry=tool_registry,
        tool_state=tool_state,
    ):
        events.append(event)
    return events


def test_process_swarm_stream_executes_node_tools_before_finishing():
    node = SwarmNode(
        id="ops",
        node_key="ops",
        name="Ops",
        intent="Handle operational requests",
        system_prompt="You are an operations specialist.",
        enabled_tools=[
            {
                "type": "function",
                "function": {
                    "name": "lookup_order",
                    "description": "Fetch order status",
                    "parameters": {
                        "type": "object",
                        "properties": {"order_id": {"type": "string"}},
                        "required": ["order_id"],
                    },
                },
                "mock_response": {"status": "shipped"},
            }
        ],
        is_entry_node=True,
    )
    session = SwarmSession(id="session-1", swarm=_build_swarm(nodes=[node]))
    store = InMemorySessionStore()

    call_count = 0

    async def fake_run_turn(*, agent_node, contents, config):
        nonlocal call_count
        call_count += 1
        assert agent_node.name == "Ops"
        assert any(tool.get("function", {}).get("name") == "lookup_order" for tool in config.tools)
        assert contents[0]["role"] == "user"
        if call_count == 1:
            return AgentTurnResult(tool_calls=[{"id": "tool-1", "name": "lookup_order", "args": {"order_id": "123"}}])
        return AgentTurnResult(response_text="Order 123 has shipped.")

    events = asyncio.run(_collect_events(session, store, _FunctionTurnRunner(fake_run_turn)))

    assert [event["event"] for event in events] == ["open", "tool_use", "chunk", "done"]
    assert events[1]["data"]["functionCalls"][0]["name"] == "lookup_order"
    assert events[2]["data"]["text"] == "Order 123 has shipped."
    assert session.agent_histories[node.id][0]["role"] == "user"
    assert "<USER_MESSAGE>" in session.agent_histories[node.id][0]["content"]
    assert session.agent_histories[node.id][-1] == {"role": "model", "content": "Order 123 has shipped."}
    checkpoints = asyncio.run(store.list_checkpoints(session.id))
    assert [checkpoint.action_type for checkpoint in checkpoints] == ["agent_response"]


def test_process_swarm_stream_blocks_handoff_when_required_variables_missing():
    triage = SwarmNode(
        id="triage",
        node_key="triage",
        name="Triage",
        intent="Route support issues",
        system_prompt="You are a triage specialist.",
        is_entry_node=True,
    )
    billing = SwarmNode(
        id="billing",
        node_key="billing",
        name="Billing",
        intent="Handle payment issues",
        system_prompt="You are a billing specialist.",
    )
    swarm = _build_swarm(
        nodes=[triage, billing],
        edges=[
            SwarmEdge(
                id="edge-1",
                source_node_id=triage.id,
                target_node_id=billing.id,
                required_variables=["account_id"],
                handoff_description="Send billing issues after collecting the customer account id.",
            )
        ],
    )
    session = SwarmSession(id="session-1", swarm=swarm)
    store = InMemorySessionStore()

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents, config
        return AgentTurnResult(tool_calls=[{"id": "handoff-1", "name": "transfer_to_agent", "args": {"target_node_key": "billing", "target_agent": "Billing"}}])

    async def fake_extractor(**_kwargs):
        return {}

    events = asyncio.run(_collect_events(session, store, _FunctionTurnRunner(fake_run_turn), fake_extractor))

    assert [event["event"] for event in events] == ["open", "tool_use", "handoff_blocked", "chunk", "done"]
    assert events[2]["data"]["to"] == "Billing"
    assert events[2]["data"]["toNodeKey"] == "billing"
    assert events[2]["data"]["handoffType"] == "blocked"
    assert events[2]["data"]["missingVariables"] == ["account_id"]
    assert session.current_node_id == triage.id
    assert session.global_variables["_active_intent"] == "route_support_issues"
    checkpoints = asyncio.run(store.list_checkpoints(session.id))
    assert [checkpoint.action_type for checkpoint in checkpoints] == ["handoff_blocked"]
    assert checkpoints[0].state_snapshot["handoff"]["missing_variables"] == ["account_id"]


def test_process_swarm_stream_applies_required_variables_before_handoff():
    triage = SwarmNode(
        id="triage",
        node_key="triage",
        name="Triage",
        intent="Route support issues",
        system_prompt="You are a triage specialist.",
        is_entry_node=True,
    )
    billing = SwarmNode(
        id="billing",
        node_key="billing",
        name="Billing",
        intent="Handle payment issues",
        system_prompt="You are a billing specialist.",
    )
    swarm = _build_swarm(
        nodes=[triage, billing],
        edges=[
            SwarmEdge(
                id="edge-1",
                source_node_id=triage.id,
                target_node_id=billing.id,
                required_variables=["account_id"],
                handoff_description="Send billing issues after collecting the customer account id.",
            )
        ],
        variables=[SwarmVariable(key_name="account_id", reducer_rule="overwrite")],
    )
    session = SwarmSession(id="session-1", swarm=swarm)
    store = InMemorySessionStore()

    async def fake_run_turn(*, agent_node, contents, config):
        del contents
        if agent_node.name == "Triage":
            assert any(tool.get("function", {}).get("name") == "transfer_to_agent" for tool in config.tools)
            return AgentTurnResult(tool_calls=[{"id": "handoff-1", "name": "transfer_to_agent", "args": {"target_node_key": "billing", "target_agent": "Billing"}}])
        assert "HANDOFF CONTEXT (read-only)" in config.system_instruction
        return AgentTurnResult(response_text="I can help with billing for account ACME-991.")

    async def fake_extractor(**_kwargs):
        return {"account_id": "ACME-991"}

    events = asyncio.run(_collect_events(session, store, _FunctionTurnRunner(fake_run_turn), fake_extractor))

    assert [event["event"] for event in events] == ["open", "tool_use", "handoff", "chunk", "done"]
    assert events[2]["data"]["to"] == "Billing"
    assert events[2]["data"]["toNodeKey"] == "billing"
    assert events[2]["data"]["handoffType"] == "agent_transfer"
    assert events[2]["data"]["requiredVariables"] == ["account_id"]
    assert events[2]["data"]["resolvedVariables"] == {"account_id": "ACME-991"}
    assert events[2]["data"]["globalVariables"] == {"account_id": "ACME-991"}
    assert session.current_node_id == billing.id
    assert session.global_variables["account_id"] == "ACME-991"
    intent_state = session.global_variables["intent_state"]
    assert isinstance(intent_state, dict)
    assert any(bucket.get("account_id") == "ACME-991" for bucket in intent_state.values())
    checkpoints = asyncio.run(store.list_checkpoints(session.id))
    assert [checkpoint.action_type for checkpoint in checkpoints] == ["handoff", "agent_response"]


def test_process_swarm_stream_builds_behavior_and_context_instruction_blocks():
    billing = SwarmNode(
        id="billing",
        node_key="billing",
        name="Billing",
        intent="Handle billing issues",
        system_prompt="You are a billing specialist.",
    )
    technical = SwarmNode(
        id="technical",
        node_key="technical",
        name="Technical",
        intent="Handle technical issues",
        system_prompt="You are a technical specialist.",
        behavior_config={
            "history_scope": "shared",
            "scratchpad_policy": "handoff_focus",
            "seed_context": {
                "summary": "Returning deployment incident for a verified customer.",
                "verified_facts": ["The customer already verified identity"],
                "constraints": ["Avoid repeating identity verification"],
                "preferences": ["Prefer minimal questions"],
            },
        },
        is_entry_node=True,
    )
    session = SwarmSession(id="session-1", swarm=_build_swarm(nodes=[billing, technical]))
    session.agent_histories[billing.id] = [
        {"role": "user", "content": "My billing already shows account 882910."},
        {"role": "model", "content": "I have the account id and will hand this over."},
    ]
    store = InMemorySessionStore()
    captured = []

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents
        captured.append(config.system_instruction)
        return AgentTurnResult(response_text="I can continue from the prior context.")

    events = asyncio.run(_collect_events(session, store, _FunctionTurnRunner(fake_run_turn)))

    assert [event["event"] for event in events] == ["open", "chunk", "done"]
    assert len(captured) == 1
    instruction = captured[0]
    assert "AGENT BEHAVIOR RULES" in instruction
    assert "AGENT CONTEXT CONTRACT (read-only)" in instruction
    assert "Seeded summary: Returning deployment incident for a verified customer." in instruction
    assert "Seeded verified facts: The customer already verified identity" in instruction
    assert "Seeded constraints: Avoid repeating identity verification" in instruction
    assert "Seeded preferences: Prefer minimal questions" in instruction
    assert "CROSS-AGENT HISTORY (read-only)" in instruction
    assert "account 882910" in instruction
    context = session.agent_contexts[technical.id]
    assert context.history_scope == "shared"
    assert context.scratchpad_policy == "handoff_focus"
    assert context.seed_context.summary == "Returning deployment incident for a verified customer."


def test_process_swarm_stream_exposes_node_contract_and_visible_globals():
    node = SwarmNode(
        id="billing",
        node_key="billing",
        name="Billing",
        intent="Handle billing issues",
        capabilities=["Resolve invoices", "Answer charge questions"],
        system_prompt="You are a billing specialist.",
        is_entry_node=True,
    )
    session = SwarmSession(id="session-1", swarm=_build_swarm(nodes=[node]))
    session.state["account_id"] = "ACME-991"
    store = InMemorySessionStore()
    captured = {}

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents
        captured["system_instruction"] = config.system_instruction
        captured["visible_global_variables"] = config.visible_global_variables
        captured["visible_state"] = config.visible_state
        captured["state"] = config.state
        return AgentTurnResult(response_text="Billing can help.")

    events = asyncio.run(_collect_events(session, store, _FunctionTurnRunner(fake_run_turn)))

    assert [event["event"] for event in events] == ["open", "chunk", "done"]
    assert captured["visible_global_variables"] == {"account_id": "ACME-991"}
    assert captured["visible_state"] == {"account_id": "ACME-991"}
    assert captured["state"] == {"account_id": "ACME-991"}
    assert "NODE CONTRACT" in captured["system_instruction"]
    assert "Responsibility / intent: Handle billing issues" in captured["system_instruction"]
    assert "Capabilities: Resolve invoices, Answer charge questions" in captured["system_instruction"]


def test_process_swarm_stream_requests_mock_when_tool_has_no_saved_response():
    node = SwarmNode(
        id="ops",
        node_key="ops",
        name="Ops",
        intent="Handle operational requests",
        system_prompt="You are an operations specialist.",
        enabled_tools=[
            {
                "type": "function",
                "function": {
                    "name": "lookup_order",
                    "description": "Fetch order status",
                    "parameters": {
                        "type": "object",
                        "properties": {"order_id": {"type": "string"}},
                        "required": ["order_id"],
                    },
                },
            }
        ],
        is_entry_node=True,
    )
    session = SwarmSession(id="session-1", swarm=_build_swarm(nodes=[node]))
    store = InMemorySessionStore()

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents, config
        return AgentTurnResult(tool_calls=[{"id": "tool-1", "name": "lookup_order", "args": {"order_id": "123"}}])

    events = asyncio.run(_collect_events(session, store, _FunctionTurnRunner(fake_run_turn)))

    assert [event["event"] for event in events] == ["open", "tool_use", "tool_mock_required"]
    assert events[2]["data"]["toolName"] == "lookup_order"
    assert events[2]["data"]["nodeKey"] == "ops"
    checkpoints = asyncio.run(store.list_checkpoints(session.id))
    assert [checkpoint.action_type for checkpoint in checkpoints] == ["tool_mock_required"]
    assert checkpoints[0].state_snapshot["tool_mock"]["tool_name"] == "lookup_order"


def test_process_swarm_stream_falls_back_after_tool_only_iterations():
    node = SwarmNode(
        id="ops",
        node_key="ops",
        name="Ops",
        intent="Handle operational requests",
        system_prompt="You are an operations specialist.",
        enabled_tools=[
            {
                "type": "function",
                "function": {
                    "name": "track_order",
                    "description": "Track order status",
                    "parameters": {
                        "type": "object",
                        "properties": {"order_id": {"type": "string"}},
                        "required": ["order_id"],
                    },
                },
                "mock_response": {"status": "in_transit"},
            }
        ],
        is_entry_node=True,
    )
    session = SwarmSession(id="session-1", swarm=_build_swarm(nodes=[node]))
    store = InMemorySessionStore()

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, config
        return AgentTurnResult(tool_calls=[{"id": f"tool-{len(contents)}", "name": "track_order", "args": {"order_id": "373923DX"}}])

    events = asyncio.run(_collect_events(session, store, _FunctionTurnRunner(fake_run_turn)))

    assert [event["event"] for event in events] == ["open", "tool_use", "tool_use", "tool_use", "chunk", "done"]
    assert events[-2]["data"]["text"] == "I completed the tool step and am ready to continue."
    assert events[-1]["data"]["fullText"].endswith("ready to continue.")


def test_process_swarm_stream_executes_runtime_tool_handlers_with_context():
    captured = {}

    async def lookup_order(order_id, context):
        captured["order_id"] = order_id
        captured["account_id"] = context.visible_global_variables["account_id"]
        captured["state_account_id"] = context.state["account_id"]
        captured["agent_name"] = context.agent_node.name
        captured["session_id"] = context.session.id
        return {
            "status": "shipped",
            "order_id": order_id,
            "account_id": context.state["account_id"],
        }

    node = SwarmNode(
        id="ops",
        node_key="ops",
        name="Ops",
        intent="Handle operational requests",
        system_prompt="You are an operations specialist.",
        enabled_tools=[
            function_tool(
                name="lookup_order",
                description="Fetch order status",
                parameters={
                    "type": "object",
                    "properties": {"order_id": {"type": "string"}},
                    "required": ["order_id"],
                },
                handler=lookup_order,
            )
        ],
        is_entry_node=True,
    )
    session = SwarmSession(id="session-1", swarm=_build_swarm(nodes=[node]))
    session.global_variables["account_id"] = "ACME-991"
    store = InMemorySessionStore()

    call_count = 0

    async def fake_run_turn(*, agent_node, contents, config):
        nonlocal call_count
        call_count += 1
        assert agent_node.name == "Ops"
        assert any(tool.get("function", {}).get("name") == "lookup_order" for tool in config.tools)
        if call_count == 1:
            return AgentTurnResult(tool_calls=[{"id": "tool-1", "name": "lookup_order", "args": {"order_id": "123"}}])
        assert any(item.get("role") == "tool" and '"status": "shipped"' in item.get("content", "") for item in contents)
        return AgentTurnResult(response_text="Order 123 has shipped for account ACME-991.")

    events = asyncio.run(_collect_events(session, store, _FunctionTurnRunner(fake_run_turn)))

    assert [event["event"] for event in events] == ["open", "tool_use", "chunk", "done"]
    assert events[-1]["data"]["fullText"] == "Order 123 has shipped for account ACME-991."
    assert captured == {
        "order_id": "123",
        "account_id": "ACME-991",
        "state_account_id": "ACME-991",
        "agent_name": "Ops",
        "session_id": "session-1",
    }


def test_process_swarm_stream_executes_registry_mapped_tools_with_external_state():
    captured = {}

    async def lookup_order(order_id: str, state=None, context=None):
        captured["order_id"] = order_id
        captured["tenant"] = state["tenant"]
        captured["request_id"] = state["request_id"]
        captured["tool_name"] = context.tool_name
        return {
            "status": "shipped",
            "order_id": order_id,
            "tenant": state["tenant"],
            "request_id": state["request_id"],
        }

    registry = {"lookup_order": lookup_order}

    node = SwarmNode(
        id="ops",
        node_key="ops",
        name="Ops",
        intent="Handle operational requests",
        system_prompt="You are an operations specialist.",
        enabled_tools=[function_tool(handler=lookup_order)],
        is_entry_node=True,
    )
    session = SwarmSession(id="session-1", swarm=_build_swarm(nodes=[node]))
    store = InMemorySessionStore()

    call_count = 0

    async def fake_run_turn(*, agent_node, contents, config):
        nonlocal call_count
        call_count += 1
        assert agent_node.name == "Ops"
        assert any(tool.get("function", {}).get("name") == "lookup_order" for tool in config.tools)
        if call_count == 1:
            return AgentTurnResult(tool_calls=[{"id": "tool-1", "name": "lookup_order", "args": {"order_id": "123"}}])
        assert any(item.get("role") == "tool" and '"request_id": "req-77"' in item.get("content", "") for item in contents)
        return AgentTurnResult(response_text="Order 123 has shipped for tenant acme.")

    events = asyncio.run(
        _collect_events_with_tools(
            session,
            store,
            _FunctionTurnRunner(fake_run_turn),
            tool_registry=registry,
            tool_state={"tenant": "acme", "request_id": "req-77"},
        )
    )

    assert [event["event"] for event in events] == ["open", "tool_use", "chunk", "done"]
    assert events[-1]["data"]["fullText"] == "Order 123 has shipped for tenant acme."
    assert captured == {
        "order_id": "123",
        "tenant": "acme",
        "request_id": "req-77",
        "tool_name": "lookup_order",
    }


def test_process_swarm_stream_queues_triage_intents_and_routes_first_intent():
    triage = SwarmNode(
        id="triage",
        node_key="triage",
        name="Triage",
        intent="Route support issues",
        system_prompt="You are a triage specialist.",
        is_entry_node=True,
    )
    billing = SwarmNode(
        id="billing",
        node_key="billing",
        name="Billing",
        intent="Handle billing issues",
        system_prompt="You are a billing specialist.",
    )
    technical = SwarmNode(
        id="technical",
        node_key="technical",
        name="Technical",
        intent="Handle technical issues",
        system_prompt="You are a technical specialist.",
    )
    swarm = _build_swarm(
        nodes=[triage, billing, technical],
        edges=[
            SwarmEdge(
                id="edge-1",
                source_node_id=triage.id,
                target_node_id=billing.id,
                required_variables=[],
                handoff_description="Send billing issues to billing.",
            ),
            SwarmEdge(
                id="edge-2",
                source_node_id=triage.id,
                target_node_id=technical.id,
                required_variables=[],
                handoff_description="Send technical issues to technical support.",
            ),
        ],
    )
    session = SwarmSession(id="session-1", swarm=swarm)
    store = InMemorySessionStore()

    async def fake_run_turn(*, agent_node, contents, config):
        del contents, config
        if agent_node.name == "Triage":
            return AgentTurnResult(
                response_text='{"intents":[{"intent":"billing issues","target_agent":"Billing"},{"intent":"technical issues","target_agent":"Technical"}]}'
            )
        if agent_node.name == "Billing":
            return AgentTurnResult(response_text="I can help with your billing request first.")
        return AgentTurnResult(response_text="I can now help with the technical request.")

    events = asyncio.run(_collect_events(session, store, _FunctionTurnRunner(fake_run_turn)))

    handoff_events = [event for event in events if event["event"] == "handoff"]
    assert events[0]["event"] == "open"
    assert events[-1]["event"] == "done"
    assert handoff_events[0]["data"]["handoffType"] == "queued_intent"
    assert any(event["data"]["to"] == "Technical" for event in handoff_events)
    assert any(event["data"]["handoffType"] == "queued_intent" and event["data"]["to"] == "Technical" for event in handoff_events)
    assert session.current_node_id == technical.id
    assert session.global_variables["intent_stack"] == []
