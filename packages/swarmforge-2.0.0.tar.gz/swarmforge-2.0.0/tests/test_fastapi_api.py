import asyncio

import httpx

from swarmforge import __version__
from swarmforge.api import create_fastapi_app, create_swarm_app
from swarmforge.evaluation.provider import ModelConfig
from swarmforge.swarm import (
    AgentTurnResult,
    GlobalVariableManager,
    InMemorySessionStore,
    SwarmDefinition,
    SwarmEdge,
    SwarmNode,
    SwarmVariable,
    SystemPromptContext,
)


class _FunctionTurnRunner:
    def __init__(self, func):
        self._func = func

    async def run_turn(self, *, agent_node, contents, config):
        return await self._func(agent_node=agent_node, contents=contents, config=config)


def _single_agent_swarm_payload():
    return {
        "id": "single-agent",
        "name": "Single Agent",
        "nodes": [
            {
                "node_key": "assistant",
                "name": "Assistant",
                "system_prompt": "You are a helpful assistant.",
                "is_entry_node": True,
            }
        ],
        "edges": [],
        "variables": [],
    }


def _bound_support_swarm() -> SwarmDefinition:
    return SwarmDefinition(
        id="support",
        name="Support Swarm",
        nodes=[
            SwarmNode(
                id="triage",
                node_key="triage",
                name="Triage",
                system_prompt="You triage support requests.",
                intent="Route support issues",
                capabilities=["Route to specialists"],
                is_entry_node=True,
            ),
            SwarmNode(
                id="billing",
                node_key="billing",
                name="Billing",
                system_prompt="You solve billing requests.",
                intent="Handle billing issues",
                capabilities=["Resolve billing questions"],
            ),
        ],
        edges=[
            SwarmEdge(
                id="triage->billing",
                source_node_id="triage",
                target_node_id="billing",
                handoff_description="Transfer billing issues after account verification.",
                required_variables=["account_id"],
            )
        ],
        variables=[SwarmVariable(key_name="account_id", description="Customer account id")],
    )


async def _request(app, method: str, path: str, **kwargs):
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
        return await client.request(method, path, **kwargs)


def test_fastapi_health_and_stateless_run():
    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents, config
        return AgentTurnResult(response_text="Hello from the swarm API.")

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    health = asyncio.run(_request(app, "GET", "/health"))
    assert health.status_code == 200
    assert health.json() == {"status": "ok"}

    root = asyncio.run(_request(app, "GET", "/"))
    assert root.status_code == 200
    assert root.json()["docs"] == "/docs"

    favicon = asyncio.run(_request(app, "GET", "/favicon.ico"))
    assert favicon.status_code == 204

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run",
            json={
                "swarm": _single_agent_swarm_payload(),
                "user_input": "Say hello.",
            },
        )
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["events"][-1]["event"] == "done"
    assert payload["events"][-1]["data"]["fullText"] == "Hello from the swarm API."
    assert payload["session"]["current_node_key"] == "assistant"


def test_fastapi_run_request_accepts_state_payload_and_injects_into_swarm():
    captured = {}

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents
        captured["visible_global_variables"] = config.visible_global_variables
        captured["state"] = config.state
        return AgentTurnResult(response_text="Hello from the swarm API.")

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run",
            json={
                "swarm": _single_agent_swarm_payload(),
                "user_input": "Say hello.",
                "state": {"account_id": "ACME-991", "priority": "high"},
            },
        )
    )

    assert response.status_code == 200
    assert captured["visible_global_variables"] == {"account_id": "ACME-991", "priority": "high"}
    assert captured["state"] == {"account_id": "ACME-991", "priority": "high"}
    assert response.json()["session"]["snapshot"]["global_variables"]["account_id"] == "ACME-991"
    assert response.json()["session"]["snapshot"]["state"]["account_id"] == "ACME-991"


def test_bound_swarm_app_exposes_fixed_swarm_routes_and_extractor():
    async def extract_required_variables(user_input: str = "", **_kwargs):
        if "ACME-991" in user_input:
            return {"account_id": "ACME-991"}
        return {}

    async def fake_run_turn(*, agent_node, contents, config):
        del contents, config
        if agent_node.node_key == "triage":
            return AgentTurnResult(
                response_text="Routing to billing.",
                tool_calls=[
                    {
                        "id": "handoff-1",
                        "name": "transfer_to_agent",
                        "args": {
                            "target_node_key": "billing",
                            "reason": "Billing request confirmed.",
                        },
                    }
                ],
            )
        return AgentTurnResult(response_text="Billing handled the request.")

    app = create_swarm_app(
        _bound_support_swarm(),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
        extract_required_variables=extract_required_variables,
    )

    swarm_response = asyncio.run(_request(app, "GET", "/swarm"))
    assert swarm_response.status_code == 200
    assert swarm_response.json()["swarm"]["swarm"]["id"] == "support"

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions",
            json={"session_id": "session-1"},
        )
    )

    assert created.status_code == 200
    assert created.json()["session"]["current_node_key"] == "triage"
    assert "runtime" not in created.json()["session"]

    runtime_response = asyncio.run(_request(app, "GET", "/sessions/session-1/runtime"))
    assert runtime_response.status_code == 200
    assert runtime_response.json()["runtime"]["entry_node"]["node_key"] == "triage"

    sent = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions/session-1/messages",
            json={"user_input": "My billing issue is on account ACME-991."},
        )
    )

    assert sent.status_code == 200
    payload = sent.json()
    assert payload["events"][-1]["data"]["fullText"] == "Billing handled the request."
    assert payload["session"]["current_node_key"] == "billing"
    assert payload["session"]["snapshot"]["global_variables"]["account_id"] == "ACME-991"
    assert any(event["event"] == "handoff" for event in payload["events"])

    runtime_after_send = asyncio.run(_request(app, "GET", "/sessions/session-1/runtime"))
    assert runtime_after_send.status_code == 200
    assert runtime_after_send.json()["runtime"]["current_node"]["scratchpad"]["latest_agent_response"] == "Billing handled the request."

    streamed = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions/session-1/messages/stream",
            json={"user_input": "I still need help with billing."},
        )
    )

    assert streamed.status_code == 200
    assert "event: done" in streamed.text


def test_fastapi_session_state_endpoints_expose_runtime_state():
    async def fake_run_turn(**_kwargs):
        return AgentTurnResult(response_text="ok")

    app = create_swarm_app(
        _bound_support_swarm(),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions",
            json={"session_id": "vars-1", "state": {"account_id": "ACME-100"}},
        )
    )

    assert created.status_code == 200
    assert "runtime" not in created.json()["session"]

    fetched = asyncio.run(_request(app, "GET", "/sessions/vars-1/state"))
    assert fetched.status_code == 200
    assert fetched.json()["state"]["visible"]["account_id"] == "ACME-100"
    legacy_fetched = asyncio.run(_request(app, "GET", "/sessions/vars-1/variables"))
    assert legacy_fetched.status_code == 200
    assert legacy_fetched.json()["variables"]["visible"]["account_id"] == "ACME-100"

    runtime = asyncio.run(_request(app, "GET", "/sessions/vars-1/runtime"))
    assert runtime.status_code == 200
    assert runtime.json()["runtime"]["global_state"]["visible"]["account_id"] == "ACME-100"
    assert runtime.json()["runtime"]["state"]["visible"]["account_id"] == "ACME-100"

    updated = asyncio.run(
        _request(
            app,
            "PATCH",
            "/sessions/vars-1/state",
            json={"state": {"account_id": "ACME-991", "priority": "high"}, "mode": "merge"},
        )
    )

    assert updated.status_code == 200
    assert updated.json()["state"]["visible"] == {"account_id": "ACME-991", "priority": "high"}
    assert updated.json()["variables"]["visible"] == {"account_id": "ACME-991", "priority": "high"}
    runtime_after_update = asyncio.run(_request(app, "GET", "/sessions/vars-1/runtime"))
    assert runtime_after_update.json()["runtime"]["global_state"]["definitions"][0]["key_name"] == "account_id"


def test_fastapi_message_request_can_merge_global_variables():
    captured = {}

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents
        captured["visible_global_variables"] = config.visible_global_variables
        return AgentTurnResult(response_text="ok")

    app = create_swarm_app(
        _bound_support_swarm(),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions",
            json={"session_id": "msg-vars-1"},
        )
    )
    assert created.status_code == 200

    sent = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions/msg-vars-1/messages",
            json={
                "user_input": "Help with billing.",
                "state": {"account_id": "ACME-555", "priority": "high"},
                "state_mode": "merge",
            },
        )
    )

    assert sent.status_code == 200
    assert captured["visible_global_variables"] == {"account_id": "ACME-555", "priority": "high"}
    assert sent.json()["session"]["snapshot"]["global_variables"]["account_id"] == "ACME-555"


def test_fastapi_message_request_still_accepts_legacy_global_variable_keys():
    captured = {}

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents
        captured["visible_global_variables"] = config.visible_global_variables
        return AgentTurnResult(response_text="ok")

    app = create_swarm_app(
        _bound_support_swarm(),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions",
            json={"session_id": "msg-vars-legacy-1"},
        )
    )
    assert created.status_code == 200

    sent = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions/msg-vars-legacy-1/messages",
            json={
                "user_input": "Help with billing.",
                "global_variables": {"account_id": "ACME-556"},
                "global_variable_mode": "merge",
            },
        )
    )

    assert sent.status_code == 200
    assert captured["visible_global_variables"] == {"account_id": "ACME-556"}


def test_bound_swarm_supports_callable_system_prompts_with_context():
    captured = {}

    def triage_prompt(context: SystemPromptContext) -> str:
        account_id = str(context.state.get("account_id") or "unknown")
        return f"You triage support requests. Current account context: {account_id}."

    swarm = SwarmDefinition(
        id="support",
        name="Support Swarm",
        nodes=[
            SwarmNode(
                id="triage",
                node_key="triage",
                name="Triage",
                system_prompt=triage_prompt,
                intent="Route support issues",
                capabilities=["Route to specialists"],
                is_entry_node=True,
            )
        ],
        variables=[SwarmVariable(key_name="account_id", description="Customer account id")],
    )

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents
        captured["system_instruction"] = config.system_instruction
        return AgentTurnResult(response_text="ok")

    app = create_swarm_app(
        swarm,
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    swarm_response = asyncio.run(_request(app, "GET", "/swarm"))
    assert swarm_response.status_code == 200
    assert str(swarm_response.json()["swarm"]["nodes"][0]["system_prompt"]).startswith("<callable:triage_prompt>")

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions",
            json={"session_id": "prompt-1"},
        )
    )
    assert created.status_code == 200

    sent = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions/prompt-1/messages",
            json={
                "user_input": "Route this request.",
                "global_variables": {"account_id": "ACME-991"},
            },
        )
    )

    assert sent.status_code == 200
    assert "Current account context: ACME-991." in captured["system_instruction"]


def test_fastapi_stream_run_initializes_request_variables_through_manager():
    class UppercaseVariables(GlobalVariableManager):
        def normalize_value(self, key, value, *, session, current_node=None):
            if key == "account_id":
                return str(value).strip().upper()
            return value

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents, config
        return AgentTurnResult(response_text="ok")

    swarm_payload = _single_agent_swarm_payload()
    swarm_payload["variables"] = [
        {"key_name": "account_id", "description": "Customer account id", "reducer_rule": "overwrite"}
    ]

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
        state_manager_factory=lambda swarm: UppercaseVariables.from_swarm(swarm),
    )

    streamed = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run/stream",
            json={
                "session_id": "stream-vars-1",
                "swarm": swarm_payload,
                "user_input": "Say hello.",
                "state": {"account_id": "acme-991"},
            },
        )
    )

    assert streamed.status_code == 200
    fetched = asyncio.run(_request(app, "GET", "/v1/sessions/stream-vars-1"))
    assert fetched.status_code == 200
    assert fetched.json()["session"]["snapshot"]["global_variables"]["account_id"] == "ACME-991"


def test_fastapi_custom_store_session_message_flow():
    async def fake_run_turn(*, agent_node, contents, config):
        del contents, config
        return AgentTurnResult(response_text=f"{agent_node.name} handled the request.")

    store = InMemorySessionStore()
    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        session_store=store,
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/sessions",
            json={
                "session_id": "session-1",
                "swarm": _single_agent_swarm_payload(),
            },
        )
    )

    assert created.status_code == 200
    assert created.json()["session"]["id"] == "session-1"

    sent = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/sessions/session-1/messages",
            json={"user_input": "Help me."},
        )
    )

    assert sent.status_code == 200
    payload = sent.json()
    assert payload["events"][-1]["data"]["fullText"] == "Assistant handled the request."
    assert payload["session"]["current_agent"] == "Assistant"
    assert payload["checkpoints"][-1]["action_type"] == "agent_response"

    second_app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        session_store=store,
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )
    fetched = asyncio.run(_request(second_app, "GET", "/v1/sessions/session-1"))
    assert fetched.status_code == 200
    assert fetched.json()["session"]["id"] == "session-1"

    runtime = asyncio.run(_request(second_app, "GET", "/v1/sessions/session-1/runtime"))
    assert runtime.status_code == 200
    assert runtime.json()["runtime"]["current_node"]["name"] == "Assistant"


def test_fastapi_executes_registered_runtime_tools():
    async def lookup_order(order_id, context):
        return {
            "status": "shipped",
            "order_id": order_id,
            "session_id": context.session.id,
        }

    call_count = 0

    async def fake_run_turn(*, agent_node, contents, config):
        nonlocal call_count
        call_count += 1
        assert agent_node.name == "Assistant"
        assert any(tool.get("function", {}).get("name") == "lookup_order" for tool in config.tools)
        if call_count == 1:
            return AgentTurnResult(tool_calls=[{"id": "tool-1", "name": "lookup_order", "args": {"order_id": "123"}}])
        assert any(item.get("role") == "tool" and '"session_id": "' in item.get("content", "") for item in contents)
        return AgentTurnResult(response_text="Order 123 is shipped.")

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
        tool_registry={"lookup_order": lookup_order},
    )

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run",
            json={
                "session_id": "runtime-tool-1",
                "swarm": {
                    "id": "single-agent",
                    "name": "Single Agent",
                    "nodes": [
                        {
                            "node_key": "assistant",
                            "name": "Assistant",
                            "system_prompt": "You are a helpful assistant.",
                            "intent": "Handle the full request",
                            "capabilities": ["Answer questions"],
                            "enabled_tools": [
                                {
                                    "type": "function",
                                    "function": {
                                        "name": "lookup_order",
                                        "description": "Fetch order status",
                                        "parameters": {
                                            "type": "object",
                                            "properties": {"order_id": {"type": "string"}},
                                            "required": ["order_id"],
                                        },
                                    },
                                }
                            ],
                            "is_entry_node": True,
                        }
                    ],
                    "edges": [],
                    "variables": [],
                },
                "user_input": "Where is order 123?",
            },
        )
    )

    assert response.status_code == 200
    payload = response.json()
    assert [event["event"] for event in payload["events"]] == ["open", "tool_use", "chunk", "done"]
    assert payload["events"][-1]["data"]["fullText"] == "Order 123 is shipped."


def test_fastapi_executes_registry_mapped_tools_with_external_state():
    async def lookup_order(order_id: str, state=None):
        return {
            "status": "shipped",
            "order_id": order_id,
            "tenant": state["tenant"],
        }

    registry = {"lookup_order": lookup_order}

    call_count = 0

    async def fake_run_turn(*, agent_node, contents, config):
        nonlocal call_count
        call_count += 1
        assert agent_node.name == "Assistant"
        assert any(tool.get("function", {}).get("name") == "lookup_order" for tool in config.tools)
        if call_count == 1:
            return AgentTurnResult(tool_calls=[{"id": "tool-1", "name": "lookup_order", "args": {"order_id": "123"}}])
        assert any(item.get("role") == "tool" and '"tenant": "acme"' in item.get("content", "") for item in contents)
        return AgentTurnResult(response_text="Order 123 is shipped for tenant acme.")

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
        tool_registry=registry,
        tool_state={"tenant": "acme"},
    )

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run",
            json={
                "session_id": "sdk-tool-1",
                "swarm": {
                    "id": "single-agent",
                    "name": "Single Agent",
                    "nodes": [
                        {
                            "node_key": "assistant",
                            "name": "Assistant",
                            "system_prompt": "You are a helpful assistant.",
                            "intent": "Handle the full request",
                            "capabilities": ["Answer questions"],
                            "enabled_tools": [
                                {
                                    "type": "function",
                                    "function": {
                                        "name": "lookup_order",
                                        "description": "Fetch order status",
                                        "parameters": {
                                            "type": "object",
                                            "properties": {"order_id": {"type": "string"}},
                                            "required": ["order_id"],
                                        },
                                    },
                                }
                            ],
                            "is_entry_node": True,
                        }
                    ],
                    "edges": [],
                    "variables": [],
                },
                "user_input": "Where is order 123?",
            },
        )
    )

    assert response.status_code == 200
    payload = response.json()
    assert [event["event"] for event in payload["events"]] == ["open", "tool_use", "chunk", "done"]
    assert payload["events"][-1]["data"]["fullText"] == "Order 123 is shipped for tenant acme."


def test_fastapi_sse_streams_incremental_events():
    async def fake_run_turn(*, agent_node, contents, config):
        del contents, config
        return AgentTurnResult(response_text=f"{agent_node.name} partial")

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run/stream",
            json={
                "session_id": "stream-1",
                "swarm": _single_agent_swarm_payload(),
                "user_input": "Stream this response.",
            },
        )
    )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    body = response.text
    assert "event: open" in body
    assert "event: chunk" in body
    assert "event: done" in body
    assert "event: session" in body
    assert "event: checkpoints" in body


def test_fastapi_uses_server_default_model_config_for_requests():
    captured = []

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents, config
        return AgentTurnResult(response_text="ok")

    def turn_runner_factory(config):
        captured.append(config)
        return _FunctionTurnRunner(fake_run_turn)

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=turn_runner_factory,
    )

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run",
            json={
                "swarm": _single_agent_swarm_payload(),
                "user_input": "Say hello.",
                "provider": {
                    "provider": "gemini",
                    "model": "gemini-3-flash-preview",
                },
            },
        )
    )

    assert response.status_code == 200
    assert captured[0].provider == "openrouter"
    assert captured[0].model == "openrouter/auto"
    assert captured[0].api_key == "sk-or-test"


def test_fastapi_openapi_examples_use_server_defaults():
    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: None,
    )

    response = asyncio.run(_request(app, "GET", "/openapi.json"))
    assert response.status_code == 200
    schema = response.json()

    run_examples = schema["paths"]["/v1/swarm/run"]["post"]["requestBody"]["content"]["application/json"]["examples"]
    assert "default" in run_examples
    assert "provider" not in run_examples["default"]["value"]

    message_examples = schema["paths"]["/v1/sessions/{session_id}/messages"]["post"]["requestBody"]["content"]["application/json"]["examples"]
    assert "default" in message_examples
    assert "provider" not in message_examples["default"]["value"]


def test_fastapi_openapi_uses_package_version():
    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: None,
    )

    response = asyncio.run(_request(app, "GET", "/openapi.json"))
    assert response.status_code == 200
    assert response.json()["info"]["version"] == __version__


def test_fastapi_defaults_to_in_memory_store():
    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: None,
    )

    assert isinstance(app.state.runtime.store, InMemorySessionStore)


def test_fastapi_accepts_browser_cors_preflight():
    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: None,
    )

    response = asyncio.run(
        _request(
            app,
            "OPTIONS",
            "/v1/sessions",
            headers={
                "Origin": "http://localhost:5173",
                "Access-Control-Request-Method": "POST",
            },
        )
    )

    assert response.status_code == 200
    assert response.headers["access-control-allow-origin"] == "*"
