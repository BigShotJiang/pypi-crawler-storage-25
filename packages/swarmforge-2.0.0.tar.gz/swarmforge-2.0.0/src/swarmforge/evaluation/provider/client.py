"""OpenAI-compatible client wrapper supporting multiple providers."""

from __future__ import annotations

from typing import Any, Dict, List, Type

from openai import LengthFinishReasonError, OpenAI
from openai.types.chat import ChatCompletion
from pydantic import BaseModel

from .config import ModelConfig


class OpenAIClientWrapper:
    """Thin wrapper around the OpenAI SDK with pluggable base URLs."""

    def __init__(self, config: ModelConfig) -> None:
        self.config = config
        self.client = OpenAI(
            base_url=config.base_url,
            api_key=config.api_key,
            default_headers=config.default_headers,
        )

    def chat_completion(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]] | None = None,
        timeout: float | None = None,
        temperature: float | None = None,
        response_format: Type[BaseModel] | None = None,
        extra_params: Dict[str, Any] | None = None,
    ) -> ChatCompletion:
        params: Dict[str, Any] = {
            "model": self.config.model,
            "messages": messages,
            "temperature": temperature if temperature is not None else self.config.temperature,
            "max_tokens": self.config.max_tokens,
        }
        params.update(self.config.default_chat_params)

        if tools:
            params["tools"] = tools

        if timeout:
            params["timeout"] = timeout

        if extra_params:
            params.update(extra_params)

        if response_format is not None:
            try:
                return self.client.beta.chat.completions.parse(
                    **params,
                    response_format=response_format,
                )
            except LengthFinishReasonError as exc:
                return exc.completion

        return self.client.chat.completions.create(**params)
