from __future__ import annotations

from typing import TYPE_CHECKING

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from code_review_agent.models import AgentStatus, OutputFormat, Severity
from code_review_agent.theme import SEVERITY_STYLES

if TYPE_CHECKING:
    from pathlib import Path

    from code_review_agent.models import AgentResult, ReviewReport

_SEVERITY_COLORS: dict[Severity, str] = {Severity(k): v for k, v in SEVERITY_STYLES.items()}

_SEVERITY_ORDER: list[Severity] = list(Severity)


def _failed_agents(report: ReviewReport) -> list[AgentResult]:
    """Return agent results with status FAILED."""
    return [r for r in report.agent_results if r.status == AgentStatus.FAILED]


def render_report_rich(report: ReviewReport) -> None:
    """Print the review report to the terminal using Rich formatting."""
    console = Console()
    failed = _failed_agents(report)

    # Header panel.
    header_lines: list[str] = []
    if report.pr_url is not None:
        header_lines.append(f"[bold]PR:[/bold]          {report.pr_url}")
    header_lines.append(
        f"[bold]Reviewed at:[/bold] {report.reviewed_at.strftime('%Y-%m-%d %H:%M:%S UTC')}"
    )

    risk_color = _SEVERITY_COLORS.get(report.risk_level, "white")
    header_lines.append(
        f"[bold]Risk level:[/bold]  [{risk_color}]{report.risk_level.upper()}[/{risk_color}]"
    )

    totals = report.total_findings
    counts_parts = []
    for sev in _SEVERITY_ORDER:
        count = totals[sev]
        if count > 0:
            color = _SEVERITY_COLORS.get(sev, "white")
            counts_parts.append(f"[{color}]{sev}: {count}[/{color}]")
        else:
            counts_parts.append(f"[dim]{sev}: {count}[/dim]")
    header_lines.append(f"[bold]Findings:[/bold]    {' | '.join(counts_parts)}")

    if failed:
        total_agents = len(report.agent_results)
        header_lines.append(
            f"[bold yellow]Warnings:[/bold yellow]    "
            f"{len(failed)} of {total_agents} agents failed. "
            f"Review is incomplete."
        )

    if report.token_usage is not None:
        usage = report.token_usage
        token_line = (
            f"[bold]Tokens:[/bold]      "
            f"{usage.prompt_tokens:,} prompt + "
            f"{usage.completion_tokens:,} completion = "
            f"{usage.total_tokens:,} total "
            f"({usage.llm_calls} calls)"
        )
        if usage.estimated_cost_usd is not None:
            token_line += f" [dim](~${usage.estimated_cost_usd:.4f})[/dim]"
        header_lines.append(token_line)

    for warning in report.fetch_warnings:
        header_lines.append(f"[bold yellow]Warning:[/bold yellow]     {warning}")

    console.print(
        Panel(
            "\n".join(header_lines),
            title="Code Review Report",
            border_style=_SEVERITY_COLORS.get(report.risk_level, "white"),
        )
    )

    # Overall summary.
    console.print(f"\n[bold]Overall Summary[/bold]\n{report.overall_summary}\n")

    # Per-agent results.
    for result in report.agent_results:
        if result.status == AgentStatus.FAILED:
            console.print(
                f"[bold red]!! {result.agent_name.upper()} Agent[/bold red]  [red]FAILED[/red]"
            )
            error_msg = result.error_message or "Unknown error"
            console.print(f"   [red]{error_msg}[/red]\n")
        else:
            finding_count = len(result.findings)
            count_style = "green" if finding_count == 0 else "yellow"
            console.print(
                f"[bold]>> {result.agent_name.upper()} Agent[/bold]  "
                f"[{count_style}]{finding_count} findings[/{count_style}]"
                f"  [dim]{result.execution_time_seconds:.1f}s[/dim]"
            )
            console.print(f"   {result.summary}\n")

    # Findings table grouped by severity.
    all_findings = [
        (finding, result.agent_name)
        for result in report.agent_results
        for finding in result.findings
    ]
    if not all_findings:
        console.print("[green]No findings -- the code looks good.[/green]")
        return

    table = Table(title="All Findings", show_lines=True)
    table.add_column("Severity", width=10)
    table.add_column("Agent", width=14)
    table.add_column("Category", width=18)
    table.add_column("Title", width=40)
    table.add_column("Location", width=25)

    sorted_findings = sorted(
        all_findings,
        key=lambda item: _SEVERITY_ORDER.index(item[0].severity),
    )

    for finding, agent_name in sorted_findings:
        color = _SEVERITY_COLORS.get(finding.severity, "white")
        location = ""
        if finding.file_path is not None:
            location = finding.file_path
            if finding.line_number is not None:
                location += f":{finding.line_number}"
        table.add_row(
            f"[{color}]{finding.severity.upper()}[/{color}]",
            agent_name,
            finding.category,
            finding.title,
            location,
        )

    console.print(table)


def render_report_markdown(report: ReviewReport) -> str:
    """Render the review report as a markdown string."""
    lines: list[str] = ["# Code Review Report", ""]
    failed = _failed_agents(report)

    if report.pr_url is not None:
        lines.append(f"**PR:** {report.pr_url}")
    lines.append(f"**Reviewed at:** {report.reviewed_at.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    lines.append(f"**Risk level:** {report.risk_level.upper()}")

    totals = report.total_findings
    counts_str = " | ".join(f"{sev}: {totals[sev]}" for sev in _SEVERITY_ORDER)
    lines.append(f"**Findings:** {counts_str}")

    if failed:
        total_agents = len(report.agent_results)
        lines.append(
            f"**WARNING:** {len(failed)} of {total_agents} agents failed. Review is incomplete."
        )

    if report.token_usage is not None:
        usage = report.token_usage
        token_line = (
            f"**Tokens:** {usage.prompt_tokens:,} prompt + "
            f"{usage.completion_tokens:,} completion = "
            f"{usage.total_tokens:,} total ({usage.llm_calls} calls)"
        )
        if usage.estimated_cost_usd is not None:
            token_line += f" (~${usage.estimated_cost_usd:.4f})"
        lines.append(token_line)

    for warning in report.fetch_warnings:
        lines.append(f"**WARNING:** {warning}")

    lines.extend(["", "## Overall Summary", "", report.overall_summary, ""])

    # Per-agent sections.
    for result in report.agent_results:
        title = result.agent_name.replace("_", " ").title()

        if result.status == AgentStatus.FAILED:
            lines.append(f"## {title} Agent (FAILED)")
            lines.append("")
            error_msg = result.error_message or "Unknown error"
            lines.append(f"**Error:** {error_msg}")
            lines.append("")
            continue

        lines.append(f"## {title} Agent")
        lines.append("")
        lines.append(
            f"*{len(result.findings)} findings | "
            f"{result.execution_time_seconds:.1f}s execution time*"
        )
        lines.append("")
        lines.append(result.summary)
        lines.append("")

        if result.findings:
            for finding in result.findings:
                severity_label = finding.severity.upper()
                lines.append(f"### [{severity_label}] {finding.title}")
                lines.append("")
                lines.append(f"**Category:** {finding.category}")
                if finding.file_path is not None:
                    location = finding.file_path
                    if finding.line_number is not None:
                        location += f":{finding.line_number}"
                    lines.append(f"**Location:** `{location}`")
                lines.append("")
                lines.append(finding.description)
                if finding.suggestion is not None:
                    lines.append("")
                    lines.append(f"**Suggestion:** {finding.suggestion}")
                lines.append("")

    return "\n".join(lines)


def render_report_json(report: ReviewReport) -> str:
    """Render the review report as a JSON string."""
    return report.model_dump_json(indent=2)


def save_report(
    report: ReviewReport, path: Path, *, output_format: OutputFormat = OutputFormat.RICH
) -> None:
    """Save the review report to the specified file path.

    Format is determined by the ``output_format`` flag:
    - RICH/default: markdown
    - JSON: JSON
    """
    if output_format == OutputFormat.JSON:
        content = render_report_json(report=report)
    else:
        content = render_report_markdown(report=report)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
