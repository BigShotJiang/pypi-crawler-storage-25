# =============================================================================
# Highflame Taxonomy — Python Package
# =============================================================================
"""
Unified vulnerability taxonomy with multi-framework compliance mappings.

All constants, dataclasses, and utility functions are re-exported from the
generated taxonomy module. This package has zero external dependencies.

Usage:
    from highflame_taxonomy import VULN_PROMPT_INJECTION, VULNERABILITIES
    from highflame_taxonomy import enrich_finding, compliance_matrix, recommend_domains
"""

from highflame_taxonomy.taxonomy import *  # noqa: F401, F403
