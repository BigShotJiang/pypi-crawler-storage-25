from logging import getLogger
import json

import httpx

from .config import build_auth_headers, config
from .models import SnowglobeData, SnowglobeMessage
from snowglobe.http_retry import (
    HttpRetryPolicy,
    async_request_with_retries,
    build_retry_policy,
)

LOGGER = getLogger(__name__)
HTTP_RETRY_POLICY: HttpRetryPolicy = build_retry_policy(logger=LOGGER)


async def _request_with_retries(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    **kwargs,
) -> httpx.Response:
    return await async_request_with_retries(
        client,
        method,
        url,
        policy=HTTP_RETRY_POLICY,
        logger=LOGGER,
        **kwargs,
    )


async def fetch_experiments(app_id: str = None) -> list[dict]:
    """
    Fetch experiments from the Snowglobe server.

    Returns:
        list[dict]: A list of experiments.
    """
    async with httpx.AsyncClient() as client:
        experiments_url = f"{config.CONTROL_PLANE_URL}/api/experiments"

        if app_id:
            experiments_url += f"?appId={app_id}"
        try:
            # get elapsed time for this request
            import time

            start_time = time.monotonic()
            experiments_response = await _request_with_retries(
                client,
                "GET",
                experiments_url,
                headers=build_auth_headers(),
                timeout=60.0,  # Set timeout to 60 seconds
            )
        except httpx.ConnectTimeout:
            elapsed_time = time.monotonic() - start_time
            raise Exception(
                f"Warning: Connection timed out while fetching experiments. Elapsed time: {elapsed_time:.2f} seconds. Polling will continue. If this persists please contact Snowglobe support."
            )

    if not experiments_response.status_code == 200:
        try:
            message = experiments_response.json().get("message")
        except Exception:
            message = experiments_response.text
        LOGGER.error(f"Error fetching experiments: {message}")
        raise Exception(
            f"{experiments_response.status_code} - {message or 'Unknown error'}"
        )
    experiments = experiments_response.json()
    return experiments

def expand_tool_calls(test) -> list[SnowglobeMessage]:
    tool_messages = []
    turn_metadata = test.get("turn_metadata", {}) or {}
    tool_calls = turn_metadata.get("response_tool_calls", [])
    tool_results = turn_metadata.get("response_tool_results", [])
    if tool_calls:
        canonical_tool_calls = [
            {
                "id": call["id"],
                "type": "function",
                "function": {
                    "name": call["name"],
                    "arguments": json.dumps(call.get("arguments", {})),
                },
            } for call in tool_calls]
        tool_messages.append(
            SnowglobeMessage(
                role="assistant",
                content="",
                tool_calls=canonical_tool_calls,
                snowglobe_data=SnowglobeData(
                    conversation_id=test["conversation_id"],
                    test_id=test["id"],
                ),
            )
        )

        for tool_result in tool_results:
            tool_messages.append(
                SnowglobeMessage(
                    role="tool",
                    content=tool_result.get("content"),
                    tool_call_id=tool_result.get("tool_call_id"),
                    snowglobe_data=SnowglobeData(
                        conversation_id=test["conversation_id"],
                        test_id=test["id"],
                    ),
                )
            )
    
    return tool_messages
    

async def fetch_messages(*, test) -> list[SnowglobeMessage]:
    """
    Fetch messages from the Snowglobe server for a given test.

    Args:
        test (str): The test identifier.

    Returns:
        list[SnowglobeMessage]: A list of messages associated with the test.
    """
    # init messages
    messages = [
        SnowglobeMessage(
            role="user",
            content=test["prompt"],
            snowglobe_data=SnowglobeData(
                conversation_id=test["conversation_id"],
                test_id=test["id"],
            ),
        ),
    ]
    # expand tool calls if they exist
    tool_messages = expand_tool_calls(test)
    for tool_message in tool_messages:
        messages.append(tool_message)
    # if full turn append response
    if "response" in test and test["response"]:
        messages.append(
            SnowglobeMessage(
                role="assistant",
                content=test["response"],
                snowglobe_data=SnowglobeData(
                    conversation_id=test["conversation_id"],
                    test_id=test["id"],
                ),
            )
        )

    # build rest of messages
    parent_id = test.get("parent_test_id")
    async with httpx.AsyncClient() as client:
        while parent_id:
            # get parent test
            parent_test_response = await _request_with_retries(
                client,
                "GET",
                f"{config.CONTROL_PLANE_URL}/api/experiments/{test['experiment_id']}/tests/{parent_id}",
                headers=build_auth_headers(),
                timeout=60.0,
            )

            if not parent_test_response.status_code == 200:
                raise Exception(
                    f"Error fetching parent test {parent_id}: {parent_test_response.text}"
                )

            parent_test = parent_test_response.json()

            parent_id = parent_test.get("parent_test_id")

            messages.insert(
                0,
                SnowglobeMessage(
                    role="assistant",
                    content=parent_test["response"],
                    snowglobe_data=SnowglobeData(
                        conversation_id=parent_test["conversation_id"],
                        test_id=parent_test["id"],
                    ),
                ),
            )

            tool_messages = expand_tool_calls(parent_test)

            # reverse insert the tool messages so they are in the correct order
            for tool_message in reversed(tool_messages):
                messages.insert(0, tool_message)

            messages.insert(
                0,
                SnowglobeMessage(
                    role="user",
                    content=parent_test["prompt"],
                    snowglobe_data=SnowglobeData(
                        conversation_id=parent_test["conversation_id"],
                        test_id=parent_test["id"],
                    ),
                ),
            )

    return messages
