from typing import Dict, List, Optional

from pydantic import BaseModel


class SnowglobeData(BaseModel):
    conversation_id: str
    test_id: str


class SnowglobeMessage(BaseModel):
    role: str
    content: Optional[str] = None
    tool_calls: Optional[List[Dict]] = None
    tool_call_id: Optional[str] = None
    snowglobe_data: Optional[SnowglobeData] = None


class CompletionFunctionOutputs(BaseModel):
    response: str


class CompletionRequest(BaseModel):
    messages: List[SnowglobeMessage]

    def to_openai_messages(self, system_prompt: Optional[str] = None) -> List[Dict]:
        """Return a list of OpenAI messages from the Snowglobe messages"""
        oai_messages = []

        if system_prompt:
            oai_messages.append({"role": "system", "content": system_prompt})
        for msg in self.messages:
            oai_message = {"role": msg.role, "content": msg.content}
            # check for tool_calls and if they exist add them to the message
            if msg.tool_calls:
                oai_message["tool_calls"] = msg.tool_calls
            # if the role is tool include the tool_call_id as top lvl
            if msg.role == "tool" and msg.tool_call_id:
                oai_message["tool_call_id"] = msg.tool_call_id
            oai_messages.append(oai_message)

        return oai_messages

    def get_prompt(self) -> str:
        """Return the prompt from the Snowglobe messages"""
        return self.to_openai_messages(system_prompt=None)[-1]["content"]

    def get_conversation_id(self) -> str:
        """Return the conversation id from the Snowglobe messages"""
        return self.messages[0].snowglobe_data.conversation_id


class RiskEvaluationRequest(BaseModel):
    messages: List[SnowglobeMessage]


class RiskEvaluationOutputs(BaseModel):
    triggered: bool
    tags: Optional[Dict[str, str]] = None
    reason: Optional[str] = None
    severity: Optional[int] = None
