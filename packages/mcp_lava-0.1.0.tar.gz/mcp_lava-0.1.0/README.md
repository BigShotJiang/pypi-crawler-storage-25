# mcp-lava

An MCP server that lets an LLM control a Linaro LAVA instance by *wrapping* `lavacli`.

## Why wrap `lavacli`?
- Reuses `lavacli`'s subcommands and output formats (many support `--json` / `--yaml`).
- Avoids re-implementing the LAVA XML-RPC API.

## Setup

1) Create/activate a venv, then install this server:

```powershell
cd C:\work\mcp-lava
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -U pip
pip install -e .
```

2) `lavacli` is installed as a dependency. If you want to use a local checkout instead, install it into the same venv (editable):

```powershell
pip install -e C:\work\lavacli
```

3) Run the MCP server (stdio transport):

```powershell
mcp-lava
```

Alternative (equivalent):

```powershell
python -m mcp_lava.server
```

## Authentication (identity-based)

This server bootstraps a **lavacli identity** at startup, then runs all subsequent
lavacli commands using `--identity`.

Environment variables (required):
- `LAVA_URL` (base URL or RPC endpoint; if it doesn't end with `/RPC2`, the server appends it)
- `LAVA_USERNAME`
- `LAVA_AUTHENTICATION_TOKEN`

Optional:
- `LAVA_IDENTITY` (defaults to `mcp`)
- `LAVA_SSL_VERIFY` (`true`/`false`, defaults to `true`)

On startup, the server runs (conceptually):

```bash
lavacli identities add --token <TOKEN> --uri <URL>/RPC2 --username <USERNAME> <IDENTITY>
```

**Note:** The token may be visible in the process command line *only during this bootstrap step*.
Regular `lavacli ...` invocations will not include the token in their argv.

Tool arguments `uri`/`token` are no longer supported.

## Tools

### `lava_run`
Run *any* `lavacli` command.

- `args` must be an **argv token list** (a list of strings), i.e. the exact tokens
  you would type after `lavacli`.

Examples:

- `lavacli devices list` → `args=["devices", "list"]`
- `lavacli devices show qemu0` → `args=["devices", "show", "qemu0"]`
- `lavacli devices list --json` → `args=["devices", "list", "--json"]`

Do **not** pass a single space-separated string like `args=["devices list"]`.

### `lava_help`
Get `lavacli --help`, or help for a specific command group.

### `lava_command_tree`
Introspect the installed `lavacli` Python package and return its command/subcommand tree.

