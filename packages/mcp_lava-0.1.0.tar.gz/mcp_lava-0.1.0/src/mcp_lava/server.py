# -*- coding: utf-8 -*-
#
# Copyright 2026 NXP
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from typing import Any, Optional
from urllib.parse import urlparse

from lavacli.utils import flow_yaml, safe_yaml

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("mcp-lava")

# Chosen once at server startup (see `run()`).
_LAVACLI_BASE_CMD: Optional[list[str]] = None
_LAVA_IDENTITY: Optional[str] = None


@dataclass
class LavaAuth:
    """Bootstrap configuration for creating a lavacli identity.

    mcp-lava creates/updates a lavacli identity at server startup (via
    `lavacli identities add ...`) so that subsequent lavacli calls can use
    `--identity` (and avoid embedding secrets in `--uri`).

    Environment variables:
    - LAVA_URL                  (base URL or RPC endpoint)
    - LAVA_USERNAME             (LAVA username)
    - LAVA_AUTHENTICATION_TOKEN (LAVA API token)
    - LAVA_IDENTITY             (identity name; default: "mcp")
    - LAVA_SSL_VERIFY           ("true"/"false", default true)

    Notes:
    - The token will appear in the *bootstrap* subprocess command line while
      `lavacli identities add --token ...` runs.
    - Regular lavacli commands will not include the token in their argv.
    """

    url: str
    username: Optional[str] = None
    token: Optional[str] = None
    identity: str = "mcp"
    verify_ssl_cert: bool = True


def _choose_lavacli_base_cmd() -> list[str]:
    """Choose how we will invoke lavacli.

    Decided once at MCP server startup.
    """

    exe = shutil.which("lavacli")
    if exe:
        return [exe]
    return [sys.executable, "-m", "lavacli"]


def _lavacli_base_cmd() -> list[str]:
    """Return the base lavacli command chosen at startup."""

    global _LAVACLI_BASE_CMD
    if _LAVACLI_BASE_CMD is None:
        # Fallback for direct module use/tests.
        _LAVACLI_BASE_CMD = _choose_lavacli_base_cmd()
    return _LAVACLI_BASE_CMD


def _parse_bool(s: Optional[str], default: bool) -> bool:
    if s is None:
        return default
    v = s.strip().lower()
    if v in {"1", "true", "t", "yes", "y", "on"}:
        return True
    if v in {"0", "false", "f", "no", "n", "off"}:
        return False
    return default


def _normalize_rpc2_url(url: str) -> str:
    """Return a lavacli-compatible XML-RPC endpoint URL.

    Accepts either a base URL (e.g. https://lava.example.com) or a full RPC2
    endpoint (e.g. https://lava.example.com/RPC2). Ensures the path ends with
    /RPC2.
    """

    p = urlparse(url)
    path = p.path or ""
    if path.endswith("/"):
        path = path[:-1]
    if not path:
        path = "/RPC2"
    elif not path.endswith("/RPC2"):
        path = path + "/RPC2"
    return f"{p.scheme}://{p.netloc}{path}"


def _auth_from_env() -> Optional[LavaAuth]:
    env = os.environ

    url = env.get("LAVA_URL")
    if not url:
        return None

    return LavaAuth(
        url=url,
        username=env.get("LAVA_USERNAME"),
        token=env.get("LAVA_AUTHENTICATION_TOKEN"),
        identity=env.get("LAVA_IDENTITY") or "mcp",
        verify_ssl_cert=_parse_bool(env.get("LAVA_SSL_VERIFY"), True),
    )


def _get_subprocess_timeout_secs() -> Optional[float]:
    """Return timeout (seconds) for lavacli subprocess calls.

    Set MCP_LAVA_TIMEOUT_SECS to control this.

    - Unset: defaults to 120 seconds
    - "0" or negative: no timeout
    """

    raw = os.environ.get("MCP_LAVA_TIMEOUT_SECS")
    if raw is None or not raw.strip():
        return 120.0
    try:
        v = float(raw)
    except ValueError:
        return 120.0
    return None if v <= 0 else v


def _run_subprocess(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    """Run a subprocess safely (avoid hangs on stdin, apply timeout)."""

    try:
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=os.environ.copy(),
            stdin=subprocess.DEVNULL,
            timeout=_get_subprocess_timeout_secs(),
        )
    except subprocess.TimeoutExpired as e:
        # Preserve any partial output for debugging.
        out = (e.stdout or "").strip()
        err = (e.stderr or "").strip()
        detail = err or out
        raise RuntimeError(
            f"lavacli timed out after {e.timeout}s: {' '.join(cmd)}"
            + (f"\n{detail}" if detail else "")
        )


def _bootstrap_identity(auth: LavaAuth) -> None:
    """Create/update a lavacli identity so later calls can use --identity.

    We use `lavacli identities add ...` to create the identity and then (optionally)
    patch the resulting `lavacli.yaml` to include `verify_ssl_cert`.
    """

    if not auth.username or not auth.token:
        raise RuntimeError(
            "Missing LAVA_USERNAME or LAVA_AUTHENTICATION_TOKEN in environment; "
            "cannot create lavacli identity."
        )

    rpc2 = _normalize_rpc2_url(auth.url)

    # Note: token is visible in this subprocess argv while it runs.
    cmd = _lavacli_base_cmd() + [
        "identities",
        "add",
        "--token",
        auth.token,
        "--uri",
        rpc2,
        "--username",
        auth.username,
        auth.identity,
    ]

    p = _run_subprocess(cmd)
    if p.returncode != 0:
        msg = (p.stderr or p.stdout).strip()
        raise RuntimeError(
            msg if msg else f"Failed to bootstrap identity '{auth.identity}'"
        )

    # Persist SSL verify choice in lavacli config so RequestsTransport can pick it up.
    # lavacli reads this from identity config as `verify_ssl_cert`.
    if auth.verify_ssl_cert is not True:
        config_dir = os.environ.get("XDG_CONFIG_HOME", "~/.config")
        config_filename = os.path.expanduser(os.path.join(config_dir, "lavacli.yaml"))

        try:
            with open(config_filename, encoding="utf-8") as f:
                data = safe_yaml.load(f.read())
            if not isinstance(data, dict):
                data = {}
        except FileNotFoundError:
            data = {}

        ident = data.get(auth.identity)
        if not isinstance(ident, dict):
            ident = {}
            data[auth.identity] = ident

        ident["verify_ssl_cert"] = bool(auth.verify_ssl_cert)

        with open(config_filename, "w", encoding="utf-8") as f:
            flow_yaml.dump(data, f)


def _run_lavacli(args: list[str]) -> subprocess.CompletedProcess[str]:
    """Run lavacli using the identity created at server startup."""

    global _LAVA_IDENTITY
    if _LAVA_IDENTITY:
        cmd = _lavacli_base_cmd() + ["--identity", _LAVA_IDENTITY] + args
    else:
        # Should only happen if server started without LAVA_URL (no bootstrap).
        cmd = _lavacli_base_cmd() + args
    return _run_subprocess(cmd)


def _ensure_ok(p: subprocess.CompletedProcess[str]) -> str:
    if p.returncode != 0:
        msg = (p.stderr or p.stdout).strip()
        raise RuntimeError(
            msg if msg else f"lavacli failed with exit code {p.returncode}"
        )
    return p.stdout


def _parse_maybe_json(text: str) -> Any:
    t = text.strip()
    if not t:
        return ""
    # Heuristic: only parse JSON if it looks like JSON.
    if (t.startswith("{") and t.endswith("}")) or (
        t.startswith("[") and t.endswith("]")
    ):
        try:
            return json.loads(t)
        except Exception:
            return t
    return t


@mcp.tool()
def lava_run(args: list[str]) -> Any:
    """Run an arbitrary `lavacli` command.

    **IMPORTANT:** `args` must be a *tokenized argv list* (list of strings), i.e.
    exactly what you would type *after* `lavacli`, split into separate elements.

    Correct examples:
    - `lavacli devices list` -> `args=["devices", "list"]`
    - `lavacli devices show qemu0` -> `args=["devices", "show", "qemu0"]`
    - `lavacli devices list --json` -> `args=["devices", "list", "--json"]`

    Incorrect example (single string):
    - `args=["devices list"]`

    Authentication is handled via a lavacli identity created when the MCP server
    starts (see `run()`).

    Returns:
    - Parsed JSON if stdout looks like JSON, else raw stdout text.
    """

    # Defensive validation: some clients/LLMs may accidentally send a single
    # space-separated string (e.g. ["devices list"]).
    if not isinstance(args, list) or any(not isinstance(a, str) for a in args):
        raise TypeError(
            "lava_run(args=...) expects a list of strings (argv tokens). "
            "Example: args=['devices','list']"
        )
    if len(args) == 1 and (" " in args[0] or "	" in args[0]):
        raise ValueError(
            "lava_run(args=...) must be tokenized. "
            "Use args=['devices','list'] instead of args=['devices list']."
        )

    p = _run_lavacli(args=args)
    out = _ensure_ok(p)
    return _parse_maybe_json(out)


@mcp.tool()
def lava_help(topic: Optional[str] = None) -> str:
    """Return `lavacli --help` or help for a subcommand group."""

    args = ["--help"] if not topic else [topic, "--help"]
    p = _run_lavacli(args=args)
    # lavacli often returns 0 for help; but be tolerant.
    if p.returncode != 0 and p.stdout.strip():
        return p.stdout
    if p.returncode != 0:
        raise RuntimeError((p.stderr or p.stdout).strip())
    return p.stdout


def _extract_subparser_choices(parser: argparse.ArgumentParser) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for action in parser._actions:
        if isinstance(action, argparse._SubParsersAction):
            for name, subp in action.choices.items():
                out[name] = _extract_subparser_choices(subp)
    return out


@mcp.tool()
def lava_command_tree() -> dict[str, Any]:
    """Introspect the installed `lavacli` Python package and return its command tree.

    This does *not* contact the LAVA server.
    """

    import lavacli
    from lavacli.utils import VERSION_LATEST
    from lavacli import commands as lava_commands  # type: ignore

    commands: dict[str, Any] = {
        "aliases": lava_commands.aliases,
        "devices": lava_commands.devices,
        "device-types": lava_commands.device_types,
        "events": lava_commands.events,
        "groups": lava_commands.groups,
        "identities": lava_commands.identities,
        "jobs": lava_commands.jobs,
        "lab": lava_commands.lab,
        "results": lava_commands.results,
        "system": lava_commands.system,
        "tags": lava_commands.tags,
        "tokens": lava_commands.tokens,
        "users": lava_commands.users,
        "utils": lava_commands.utils,
        "workers": lava_commands.workers,
    }

    tree: dict[str, Any] = {}
    for name, mod in sorted(commands.items()):
        p = argparse.ArgumentParser(prog=f"lavacli {name}")
        mod.configure_parser(p, VERSION_LATEST)
        tree[name] = _extract_subparser_choices(p)

    return {
        "lavacli_version": getattr(lavacli, "__version__", None),
        "commands": tree,
    }


def run() -> None:
    """Console entrypoint.

    On startup we:
    1) Decide how we will invoke lavacli (`lavacli` binary vs `python -m lavacli`).
    2) Bootstrap a lavacli identity from environment variables.
    3) Start the MCP server over stdio.

    Required env vars for bootstrapping:
    - LAVA_URL
    - LAVA_USERNAME
    - LAVA_AUTHENTICATION_TOKEN

    Optional:
    - LAVA_IDENTITY (defaults to "mcp")
    - LAVA_SSL_VERIFY (defaults to true)
    """

    global _LAVACLI_BASE_CMD, _LAVA_IDENTITY
    _LAVACLI_BASE_CMD = _choose_lavacli_base_cmd()

    auth = _auth_from_env()
    if auth is None:
        raise RuntimeError("LAVA_URL is not set; cannot bootstrap lavacli identity.")

    _bootstrap_identity(auth)
    _LAVA_IDENTITY = auth.identity

    mcp.run()


if __name__ == "__main__":
    run()
