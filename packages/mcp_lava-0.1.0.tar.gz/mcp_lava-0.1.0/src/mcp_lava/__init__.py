# -*- coding: utf-8 -*-
#
# Copyright 2026 NXP
#
# SPDX-License-Identifier: GPL-2.0-or-later

__all__ = ["__version__"]
__version__ = "0.1.0"
