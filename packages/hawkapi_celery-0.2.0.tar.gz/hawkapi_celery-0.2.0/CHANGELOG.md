# Changelog

## 0.2.0 — 2026-05-16

Security & correctness:

- `_run_coroutine` no longer conflates the "no running loop" `RuntimeError` with the active-loop guard; it inspects `asyncio.get_running_loop()` explicitly and raises a clear error inside an event loop. Removed process-wide `asyncio.set_event_loop()` side effects.
- `create_celery` validates `task_serializer` is contained in `accept_content` and raises `ValueError` otherwise.
- `@task` no longer drops `max_retries=0` / `bind=False` / other falsy-but-meaningful overrides; only non-default kwargs are forwarded.
- Context propagation stores reset tokens in a module-level `dict[str, Token]` keyed by `task.request.id` instead of mutating `task.request._hawkapi_token`.
- `init_celery` / `resolve_celery` use `WeakKeyDictionary` keyed by the app object to avoid `id()` ABA collisions.

## 0.1.0 — 2026-05-16

Initial release.

- `init_celery(app, ...)` + `app.state.celery`.
- `@task(celery_app, ...)` decorator with `async def` support (runs coroutines on a private event loop) and auto-retry knobs.
- Beat schedule helpers — `Periodic`, `add_periodic`, `every`, `every_seconds`, re-exported `crontab`.
- Healthchecks — `check_broker`, `check_workers`, `healthcheck` → `HealthReport`.
- Request-context propagation between HTTP handlers and workers (`bind_context`, `current_context`, `attach_context_signals`).
- DI helpers — `Depends(get_celery)`, `get_task_result(task_id, request)`.
- Test fixtures — `eager_mode`, `record_tasks` / `TaskRecorder`.
- Retry helper — `compute_backoff` with decorrelated jitter.
- Extras: `[redis]`.
