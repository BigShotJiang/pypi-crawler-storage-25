"""Test helpers — eager-mode and task capture."""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any

from celery import Celery
from celery.signals import before_task_publish


@dataclass(slots=True)
class CapturedTask:
    name: str
    args: tuple[Any, ...] = ()
    kwargs: dict[str, Any] = field(default_factory=dict)
    headers: dict[str, Any] = field(default_factory=dict)


class TaskRecorder:
    """Captures every task publish on a Celery app — useful in tests."""

    def __init__(self) -> None:
        self.captured: list[CapturedTask] = []

    def __len__(self) -> int:
        return len(self.captured)

    def clear(self) -> None:
        self.captured.clear()


@contextmanager
def record_tasks(celery_app: Celery) -> Generator[TaskRecorder, None, None]:
    """Capture every task publish for the duration of the block."""
    recorder = TaskRecorder()

    def _capture(
        sender: str | None = None,
        body: Any = None,
        headers: dict[str, Any] | None = None,
        **_: Any,
    ) -> None:
        args: tuple[Any, ...] = ()
        kwargs: dict[str, Any] = {}
        if isinstance(body, tuple) and len(body) >= 2:
            a, k = body[0], body[1]
            if isinstance(a, (list, tuple)):
                args = tuple(a)
            if isinstance(k, dict):
                kwargs = dict(k)
        recorder.captured.append(
            CapturedTask(
                name=sender or "",
                args=args,
                kwargs=kwargs,
                headers=dict(headers or {}),
            )
        )

    before_task_publish.connect(_capture, weak=False, sender=None)
    try:
        yield recorder
    finally:
        before_task_publish.disconnect(_capture)
        # Reference to celery_app keeps signature stable / lets us extend later.
        _ = celery_app


@contextmanager
def eager_mode(celery_app: Celery, *, propagate: bool = True) -> Generator[Celery, None, None]:
    """Run all tasks synchronously in-process — drop-in for tests."""
    prev_always = celery_app.conf.task_always_eager
    prev_prop = celery_app.conf.task_eager_propagates
    celery_app.conf.task_always_eager = True
    celery_app.conf.task_eager_propagates = propagate
    try:
        yield celery_app
    finally:
        celery_app.conf.task_always_eager = prev_always
        celery_app.conf.task_eager_propagates = prev_prop


__all__ = ["CapturedTask", "TaskRecorder", "eager_mode", "record_tasks"]
