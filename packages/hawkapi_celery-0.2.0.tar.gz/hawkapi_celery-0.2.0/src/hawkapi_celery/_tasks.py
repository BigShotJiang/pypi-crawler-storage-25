"""Task decorators — sync, async-coroutine, and retry helpers."""

from __future__ import annotations

import asyncio
import functools
import inspect
import random
from collections.abc import Callable
from typing import Any, ParamSpec, TypeVar

from celery import Celery

P = ParamSpec("P")
R = TypeVar("R")


def task(
    celery_app: Celery,
    *,
    name: str | None = None,
    queue: str | None = None,
    bind: bool = False,
    autoretry_for: tuple[type[BaseException], ...] = (),
    retry_backoff: bool | int | float = False,
    retry_backoff_max: int = 600,
    retry_jitter: bool = True,
    max_retries: int = 3,
    **task_kwargs: Any,
) -> Callable[[Callable[P, R]], Any]:
    """Register ``fn`` as a Celery task with sensible retry defaults.

    The wrapper auto-detects ``async def`` and runs the coroutine on a private
    event loop for each invocation. For sync functions it forwards as-is.
    """

    def decorator(fn: Callable[P, R]) -> Any:
        register_kwargs: dict[str, Any] = {
            "name": name or f"{fn.__module__}.{fn.__qualname__}",
        }
        if queue is not None:
            register_kwargs["queue"] = queue
        if bind:
            register_kwargs["bind"] = True
        if autoretry_for:
            register_kwargs["autoretry_for"] = autoretry_for
        if retry_backoff is not False:
            register_kwargs["retry_backoff"] = retry_backoff
        if retry_backoff_max != 600:
            register_kwargs["retry_backoff_max"] = retry_backoff_max
        if retry_jitter is not True:
            register_kwargs["retry_jitter"] = retry_jitter
        if max_retries != 3:
            register_kwargs["max_retries"] = max_retries
        register_kwargs.update(task_kwargs)

        if inspect.iscoroutinefunction(fn):

            @functools.wraps(fn)
            def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
                return _run_coroutine(fn, *args, **kwargs)  # type: ignore[arg-type]

            return celery_app.task(**register_kwargs)(wrapper)
        return celery_app.task(**register_kwargs)(fn)

    return decorator


def _run_coroutine(coro_fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    """Run ``coro_fn(*args, **kwargs)`` on a private event loop.

    Raises ``RuntimeError`` if called from within an already-running event loop —
    we never want to block the outer loop or attempt re-entry.
    """
    try:
        running = asyncio.get_running_loop()
    except RuntimeError:
        running = None
    if running is not None and running.is_running():
        raise RuntimeError("cannot run coroutine task inside an active event loop")
    new_loop = asyncio.new_event_loop()
    try:
        return new_loop.run_until_complete(coro_fn(*args, **kwargs))
    finally:
        new_loop.close()


def compute_backoff(
    attempt: int, *, base: float = 1.0, cap: float = 60.0, jitter: bool = True
) -> float:
    """Compute exponential backoff with optional decorrelated jitter.

    Useful when scheduling manual retries via ``task.retry(countdown=...)``.
    """
    delay = min(cap, base * (2 ** max(0, attempt - 1)))
    if jitter:
        delay = random.uniform(base, max(base, delay))  # noqa: S311 - not crypto
    return delay


__all__ = ["compute_backoff", "task"]
