"""Periodic-task helpers — declarative schedule entries."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from typing import Any

from celery import Celery
from celery.schedules import crontab


@dataclass(slots=True)
class Periodic:
    """One periodic-task entry. Use :func:`add_periodic` to register."""

    task: str
    schedule: float | timedelta | crontab
    args: tuple[Any, ...] = ()
    kwargs: dict[str, Any] = field(default_factory=dict)
    options: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        entry: dict[str, Any] = {"task": self.task, "schedule": self.schedule}
        if self.args:
            entry["args"] = list(self.args)
        if self.kwargs:
            entry["kwargs"] = dict(self.kwargs)
        if self.options:
            entry["options"] = dict(self.options)
        return entry


def add_periodic(celery_app: Celery, name: str, periodic: Periodic) -> None:
    """Add ``periodic`` to the Celery beat schedule under ``name``."""
    schedule: dict[str, Any] = dict(celery_app.conf.beat_schedule or {})
    schedule[name] = periodic.to_dict()
    celery_app.conf.beat_schedule = schedule


def every_seconds(seconds: float) -> float:
    return float(seconds)


def every(timedelta_value: timedelta) -> timedelta:
    return timedelta_value


__all__ = ["Periodic", "add_periodic", "crontab", "every", "every_seconds"]
