"""Propagate request context (request_id, user_id, etc.) from HTTP handlers to Celery workers.

Usage:

.. code-block:: python

    from hawkapi_celery import bind_context, attach_context_signals

    attach_context_signals(celery_app)            # once, at startup

    # In a handler:
    with bind_context(request_id=request_id, user_id=user.id):
        my_task.delay(...)

The context dict is shipped in the task's ``headers["hawkapi_context"]`` and
restored into a module-level :class:`ContextVar` on the worker side. Read it
back inside the task with :func:`current_context`.
"""

from __future__ import annotations

import contextvars
from collections.abc import Generator
from contextlib import contextmanager
from typing import Any

from celery import Celery
from celery.signals import before_task_publish, task_postrun, task_prerun

_CONTEXT_VAR: contextvars.ContextVar[dict[str, Any] | None] = contextvars.ContextVar(
    "hawkapi_celery_context", default=None
)
_HEADER_KEY = "hawkapi_context"

# Keyed by task.request.id; tokens are popped in task_postrun. Living on a
# module-level dict (rather than mutating ``task.request``) keeps Celery's
# request stack immutable from our side.
_PENDING_TOKENS: dict[str, contextvars.Token[dict[str, Any] | None]] = {}


def current_context() -> dict[str, Any]:
    """Return the active context dict (empty if unset)."""
    return dict(_CONTEXT_VAR.get() or {})


@contextmanager
def bind_context(**values: Any) -> Generator[None, None, None]:
    """Temporarily merge ``values`` into the active context."""
    merged = {**(_CONTEXT_VAR.get() or {}), **values}
    token = _CONTEXT_VAR.set(merged)
    try:
        yield
    finally:
        _CONTEXT_VAR.reset(token)


def set_context(values: dict[str, Any]) -> contextvars.Token[dict[str, Any] | None]:
    """Set the active context unconditionally and return a reset token."""
    return _CONTEXT_VAR.set(dict(values))


def reset_context(token: contextvars.Token[dict[str, Any] | None]) -> None:
    _CONTEXT_VAR.reset(token)


def attach_context_signals(celery_app: Celery) -> None:
    """Wire the publisher → worker context propagation. Idempotent per app."""
    flag = "_hawkapi_context_signals"
    if getattr(celery_app, flag, False):
        return
    setattr(celery_app, flag, True)

    @before_task_publish.connect(weak=False)
    def _publish(headers: dict[str, Any] | None = None, **_: Any) -> None:
        if headers is None:
            return
        ctx = _CONTEXT_VAR.get()
        if ctx:
            headers[_HEADER_KEY] = dict(ctx)

    @task_prerun.connect(weak=False)
    def _prerun(task: Any = None, **_: Any) -> None:
        if task is None:
            return
        try:
            headers = task.request.headers or {}
            task_id = task.request.id
        except AttributeError:
            return
        ctx = headers.get(_HEADER_KEY) if isinstance(headers, dict) else None
        if isinstance(ctx, dict) and task_id:
            _PENDING_TOKENS[task_id] = _CONTEXT_VAR.set(dict(ctx))

    @task_postrun.connect(weak=False)
    def _postrun(task: Any = None, **_: Any) -> None:
        if task is None:
            return
        try:
            task_id = task.request.id
        except AttributeError:
            return
        token = _PENDING_TOKENS.pop(task_id, None) if task_id else None
        if token is not None:
            import contextlib

            with contextlib.suppress(ValueError, LookupError):
                _CONTEXT_VAR.reset(token)


__all__ = [
    "attach_context_signals",
    "bind_context",
    "current_context",
    "reset_context",
    "set_context",
]
