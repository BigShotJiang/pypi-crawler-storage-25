"""hawkapi-celery — Celery integration for HawkAPI.

Async tasks, beat scheduler, broker/worker healthchecks, request-context
propagation between HTTP handlers and Celery workers, and eager-mode fixtures
for testing.
"""

from __future__ import annotations

from ._app import CeleryConfig, create_celery
from ._beat import Periodic, add_periodic, crontab, every, every_seconds
from ._context import (
    attach_context_signals,
    bind_context,
    current_context,
    reset_context,
    set_context,
)
from ._health import HealthReport, check_broker, check_workers, healthcheck
from ._plugin import get_celery, get_task_result, init_celery, resolve_celery
from ._tasks import compute_backoff, task
from ._testing import CapturedTask, TaskRecorder, eager_mode, record_tasks

__version__ = "0.2.0"

__all__ = [
    "CapturedTask",
    "CeleryConfig",
    "HealthReport",
    "Periodic",
    "TaskRecorder",
    "__version__",
    "add_periodic",
    "attach_context_signals",
    "bind_context",
    "check_broker",
    "check_workers",
    "compute_backoff",
    "create_celery",
    "crontab",
    "current_context",
    "eager_mode",
    "every",
    "every_seconds",
    "get_celery",
    "get_task_result",
    "healthcheck",
    "init_celery",
    "record_tasks",
    "reset_context",
    "resolve_celery",
    "set_context",
    "task",
]
