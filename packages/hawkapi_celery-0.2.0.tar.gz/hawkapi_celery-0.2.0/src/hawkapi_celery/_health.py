"""Healthcheck helpers — broker ping + worker discovery."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from celery import Celery


@dataclass(slots=True)
class HealthReport:
    broker_ok: bool
    workers_alive: int
    workers: dict[str, Any] = field(default_factory=dict)
    error: str = ""


def check_broker(celery_app: Celery, *, timeout: float = 5.0) -> bool:
    """Open a broker connection and verify it is reachable."""
    try:
        with celery_app.connection_for_read() as conn:  # type: ignore[attr-defined]
            conn.ensure_connection(max_retries=1, interval_start=0, timeout=timeout)
        return True
    except Exception:
        return False


def check_workers(celery_app: Celery, *, timeout: float = 5.0) -> dict[str, Any]:
    """Return a mapping of worker-name -> ping response. Empty dict if no workers."""
    try:
        replies = celery_app.control.ping(timeout=timeout)
    except Exception:
        return {}
    result: dict[str, Any] = {}
    for reply in replies or []:
        for worker, payload in reply.items():
            result[worker] = payload
    return result


def healthcheck(celery_app: Celery, *, timeout: float = 5.0) -> HealthReport:
    """Combined broker + worker probe."""
    try:
        broker_ok = check_broker(celery_app, timeout=timeout)
        workers = check_workers(celery_app, timeout=timeout) if broker_ok else {}
        return HealthReport(
            broker_ok=broker_ok,
            workers_alive=len(workers),
            workers=workers,
        )
    except Exception as exc:
        return HealthReport(broker_ok=False, workers_alive=0, error=str(exc))


__all__ = ["HealthReport", "check_broker", "check_workers", "healthcheck"]
