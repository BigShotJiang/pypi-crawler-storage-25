"""Celery app construction + sensible defaults."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from celery import Celery


@dataclass(slots=True)
class CeleryConfig:
    broker_url: str = "redis://localhost:6379/0"
    result_backend: str = "redis://localhost:6379/0"
    task_serializer: str = "json"
    result_serializer: str = "json"
    accept_content: list[str] = field(default_factory=lambda: ["json"])
    timezone: str = "UTC"
    enable_utc: bool = True
    task_track_started: bool = True
    task_time_limit: int = 600
    task_soft_time_limit: int = 540
    worker_prefetch_multiplier: int = 1
    worker_max_tasks_per_child: int = 1000
    task_default_queue: str = "default"
    task_default_priority: int = 5
    task_always_eager: bool = False
    task_eager_propagates: bool = False
    beat_schedule: dict[str, Any] = field(default_factory=dict)
    include: list[str] = field(default_factory=list)
    extra_kwargs: dict[str, Any] = field(default_factory=dict)


def create_celery(name: str = "hawkapi", *, config: CeleryConfig | None = None) -> Celery:
    """Build a Celery app from :class:`CeleryConfig` with sensible defaults."""
    config = config or CeleryConfig()
    if config.task_serializer not in config.accept_content:
        raise ValueError(
            f"task_serializer {config.task_serializer!r} not in "
            f"accept_content {config.accept_content!r}"
        )
    app = Celery(name, broker=config.broker_url, backend=config.result_backend)
    app.conf.update(
        broker_url=config.broker_url,
        result_backend=config.result_backend,
        task_serializer=config.task_serializer,
        result_serializer=config.result_serializer,
        accept_content=list(config.accept_content),
        timezone=config.timezone,
        enable_utc=config.enable_utc,
        task_track_started=config.task_track_started,
        task_time_limit=config.task_time_limit,
        task_soft_time_limit=config.task_soft_time_limit,
        worker_prefetch_multiplier=config.worker_prefetch_multiplier,
        worker_max_tasks_per_child=config.worker_max_tasks_per_child,
        task_default_queue=config.task_default_queue,
        task_default_priority=config.task_default_priority,
        task_always_eager=config.task_always_eager,
        task_eager_propagates=config.task_eager_propagates,
        beat_schedule=dict(config.beat_schedule),
        include=list(config.include),
        **config.extra_kwargs,
    )
    return app


__all__ = ["CeleryConfig", "create_celery"]
