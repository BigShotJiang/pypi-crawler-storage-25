"""Plugin entry point + DI helpers."""

from __future__ import annotations

import contextlib
import weakref
from typing import Any

from celery import Celery
from celery.result import AsyncResult
from hawkapi import HTTPException, Request

from ._app import CeleryConfig, create_celery
from ._context import attach_context_signals


class _StateNamespace:
    celery: Any


_ACTIVE_APPS: weakref.WeakKeyDictionary[Any, Celery] = weakref.WeakKeyDictionary()
_LAST_APP: list[Celery | None] = [None]


def _try_remember(app: Any, celery_app: Celery) -> None:
    # Unhashable / non-weakref-able app — skip the cache silently.
    with contextlib.suppress(TypeError):
        _ACTIVE_APPS[app] = celery_app


def init_celery(
    app: Any,
    *,
    celery_app: Celery | None = None,
    config: CeleryConfig | None = None,
    name: str = "hawkapi",
    propagate_context: bool = True,
) -> Celery:
    """Attach a Celery app to ``app.state.celery`` and register it for DI lookup.

    Pass an existing ``celery_app=`` to wire up a Celery instance you built yourself;
    otherwise pass a ``config=`` (or nothing for defaults) and we will build one for you.
    """
    if celery_app is None:
        celery_app = create_celery(name, config=config or CeleryConfig())

    if propagate_context:
        attach_context_signals(celery_app)

    if getattr(app, "state", None) is None:
        app.state = _StateNamespace()
    app.state.celery = celery_app
    _try_remember(app, celery_app)
    _LAST_APP[0] = celery_app
    return celery_app


def resolve_celery(app: Any) -> Celery | None:
    if app is None:
        return _LAST_APP[0]
    try:
        found = _ACTIVE_APPS.get(app)
    except TypeError:
        found = None
    if found is not None:
        return found
    state = getattr(app, "state", None)
    if state is not None and hasattr(state, "celery"):
        return state.celery  # type: ignore[no-any-return]
    return _LAST_APP[0]


def get_celery(request: Request) -> Celery:
    found = resolve_celery(request.scope.get("app"))
    if found is None:
        raise HTTPException(500, detail="Celery not configured — call init_celery(app, ...) first")
    return found


def get_task_result(task_id: str, request: Request) -> AsyncResult:
    """Resolve an ``AsyncResult`` for ``task_id`` against the configured Celery app."""
    return AsyncResult(task_id, app=get_celery(request))


__all__ = ["get_celery", "get_task_result", "init_celery", "resolve_celery"]
