"""Task decorator — sync, async, retry helpers."""

from __future__ import annotations

from celery import Celery

from hawkapi_celery import compute_backoff, eager_mode, task


def test_sync_task_runs_inline(celery_app: Celery) -> None:
    @task(celery_app, name="t.add")
    def add(a: int, b: int) -> int:
        return a + b

    with eager_mode(celery_app):
        result = add.delay(2, 3).get()
    assert result == 5


def test_async_task_runs_via_event_loop(celery_app: Celery) -> None:
    @task(celery_app, name="t.aadd")
    async def aadd(a: int, b: int) -> int:
        return a + b

    with eager_mode(celery_app):
        result = aadd.delay(10, 20).get()
    assert result == 30


def test_task_registers_under_explicit_name(celery_app: Celery) -> None:
    @task(celery_app, name="custom.name")
    def fn() -> str:
        return "ok"

    assert fn.name == "custom.name"
    assert "custom.name" in celery_app.tasks


def test_compute_backoff_increases() -> None:
    a1 = compute_backoff(1, base=1, cap=60, jitter=False)
    a2 = compute_backoff(3, base=1, cap=60, jitter=False)
    assert a2 > a1


def test_compute_backoff_capped() -> None:
    assert compute_backoff(20, base=1, cap=10, jitter=False) == 10


def test_run_coroutine_raises_clear_error_in_async_context(celery_app: Celery) -> None:
    """When invoked from inside an active event loop, the wrapper must bail loudly."""
    import asyncio

    import pytest

    @task(celery_app, name="t.inner_async")
    async def inner() -> int:
        return 1

    async def outer() -> None:
        with eager_mode(celery_app):
            # Calling .delay().get() inside an active loop hits _run_coroutine.
            inner.delay().get()

    with pytest.raises(RuntimeError, match="cannot run coroutine task inside an active event loop"):
        asyncio.run(outer())


def test_max_retries_zero_is_passed_through(celery_app: Celery) -> None:
    @task(celery_app, name="t.no_retry", max_retries=0)
    def fn() -> str:
        return "ok"

    registered = celery_app.tasks["t.no_retry"]
    assert registered.max_retries == 0


def test_bind_false_default_does_not_override(celery_app: Celery) -> None:
    """``bind=False`` is the default and should not be forwarded as a kwarg."""

    @task(celery_app, name="t.unbound")
    def fn() -> str:
        return "ok"

    # The task should be registered cleanly without raising.
    assert "t.unbound" in celery_app.tasks
