"""Periodic / beat configuration helpers."""

from __future__ import annotations

from datetime import timedelta

from celery import Celery

from hawkapi_celery import Periodic, add_periodic, crontab, every, every_seconds


def test_periodic_to_dict_only_includes_set_fields() -> None:
    p = Periodic(task="myapp.cleanup", schedule=60.0)
    d = p.to_dict()
    assert d == {"task": "myapp.cleanup", "schedule": 60.0}


def test_periodic_to_dict_includes_args_and_kwargs() -> None:
    p = Periodic(
        task="myapp.sync",
        schedule=60.0,
        args=(1, 2),
        kwargs={"flag": True},
        options={"queue": "high"},
    )
    d = p.to_dict()
    assert d["args"] == [1, 2]
    assert d["kwargs"] == {"flag": True}
    assert d["options"] == {"queue": "high"}


def test_add_periodic_registers_entry(celery_app: Celery) -> None:
    add_periodic(celery_app, "cleanup", Periodic(task="myapp.cleanup", schedule=300.0))
    add_periodic(celery_app, "report", Periodic(task="myapp.report", schedule=every_seconds(60)))
    schedule = celery_app.conf.beat_schedule
    assert "cleanup" in schedule
    assert "report" in schedule
    assert schedule["report"]["schedule"] == 60.0


def test_every_returns_timedelta() -> None:
    td = every(timedelta(minutes=5))
    assert isinstance(td, timedelta)
    assert td.total_seconds() == 300


def test_crontab_export() -> None:
    cb = crontab(hour=0, minute=0)
    assert cb is not None
