"""Context propagation between publisher and worker."""

from __future__ import annotations

from celery import Celery

from hawkapi_celery import (
    attach_context_signals,
    bind_context,
    current_context,
    eager_mode,
    record_tasks,
    task,
)


def test_current_context_empty_by_default() -> None:
    assert current_context() == {}


def test_bind_context_merges_and_resets() -> None:
    with bind_context(user_id="u-1"):
        ctx = current_context()
        assert ctx == {"user_id": "u-1"}
        with bind_context(request_id="r-2"):
            assert current_context() == {"user_id": "u-1", "request_id": "r-2"}
        assert current_context() == {"user_id": "u-1"}
    assert current_context() == {}


def test_publish_attaches_context_to_headers(celery_app: Celery) -> None:
    attach_context_signals(celery_app)

    @task(celery_app, name="ctx.noop")
    def noop() -> str:
        return "ok"

    # Eager mode short-circuits publish — so use record_tasks against an
    # async-publish scenario instead.
    with record_tasks(celery_app) as recorder, bind_context(request_id="r-99"):
        # Force a publish path (not eager) via apply_async with always_eager=False.
        prev = celery_app.conf.task_always_eager
        celery_app.conf.task_always_eager = False
        try:
            noop.apply_async()
        finally:
            celery_app.conf.task_always_eager = prev
    assert recorder.captured
    assert recorder.captured[0].headers.get("hawkapi_context") == {"request_id": "r-99"}


def test_attach_context_signals_idempotent(celery_app: Celery) -> None:
    attach_context_signals(celery_app)
    attach_context_signals(celery_app)
    attach_context_signals(celery_app)
    # No exceptions — and the flag prevents duplicate signal connections.
    assert getattr(celery_app, "_hawkapi_context_signals", False) is True


def test_worker_side_restores_context(celery_app: Celery) -> None:
    attach_context_signals(celery_app)
    observed: dict[str, str] = {}

    @task(celery_app, name="ctx.peek")
    def peek() -> dict[str, str]:
        observed.update(current_context())
        return dict(current_context())

    with eager_mode(celery_app), bind_context(user_id="alice"):
        peek.apply_async()
    assert observed.get("user_id") == "alice"
