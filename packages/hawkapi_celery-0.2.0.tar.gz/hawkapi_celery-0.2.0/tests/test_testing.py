"""eager_mode + record_tasks."""

from __future__ import annotations

from celery import Celery

from hawkapi_celery import eager_mode, record_tasks, task


def test_eager_mode_toggles_config(celery_app: Celery) -> None:
    celery_app.conf.task_always_eager = False
    with eager_mode(celery_app):
        assert celery_app.conf.task_always_eager is True
    assert celery_app.conf.task_always_eager is False


def test_record_tasks_captures_publish(celery_app: Celery) -> None:
    @task(celery_app, name="rec.work")
    def work(x: int) -> int:
        return x * 2

    celery_app.conf.task_always_eager = False
    with record_tasks(celery_app) as recorder:
        work.apply_async(args=(21,))
    assert len(recorder) == 1
    assert recorder.captured[0].name == "rec.work"
    assert recorder.captured[0].args == (21,)


def test_record_tasks_clear() -> None:
    from hawkapi_celery import TaskRecorder

    r = TaskRecorder()
    r.captured.append(...)  # type: ignore[arg-type]
    assert len(r) == 1
    r.clear()
    assert len(r) == 0
