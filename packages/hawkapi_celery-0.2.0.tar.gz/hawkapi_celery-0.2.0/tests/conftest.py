"""Build a Celery app with the in-memory broker + cache backend for tests."""

from __future__ import annotations

import pytest

from hawkapi_celery import CeleryConfig, create_celery


@pytest.fixture
def celery_app():  # type: ignore[no-untyped-def]
    return create_celery(
        "hawkapi-celery-tests",
        config=CeleryConfig(
            broker_url="memory://",
            result_backend="cache+memory://",
            task_always_eager=True,
            task_eager_propagates=True,
        ),
    )
