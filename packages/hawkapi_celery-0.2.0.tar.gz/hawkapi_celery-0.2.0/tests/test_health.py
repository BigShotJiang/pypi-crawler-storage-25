"""Healthcheck helpers — broker + worker probes."""

from __future__ import annotations

from typing import Any

from celery import Celery

from hawkapi_celery import HealthReport, check_broker, check_workers, healthcheck


def test_check_broker_against_unreachable_returns_false() -> None:
    bogus = Celery(
        "bogus", broker="redis://does-not-resolve.invalid:1/0", backend="cache+memory://"
    )
    assert check_broker(bogus, timeout=0.1) is False


def test_check_workers_returns_empty_when_no_workers(celery_app: Celery) -> None:
    workers = check_workers(celery_app, timeout=0.1)
    assert workers == {}


def test_healthcheck_combines_broker_and_workers(monkeypatch, celery_app: Celery) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.setattr("hawkapi_celery._health.check_broker", lambda *a, **k: True)
    monkeypatch.setattr(
        "hawkapi_celery._health.check_workers",
        lambda *a, **k: {"worker@host": {"ok": "pong"}},
    )
    report = healthcheck(celery_app)
    assert isinstance(report, HealthReport)
    assert report.broker_ok is True
    assert report.workers_alive == 1
    assert "worker@host" in report.workers


def test_healthcheck_reports_failure_when_broker_down(monkeypatch, celery_app: Celery) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.setattr("hawkapi_celery._health.check_broker", lambda *a, **k: False)

    def _no_workers(*_: Any, **__: Any) -> dict[str, Any]:
        return {}

    monkeypatch.setattr("hawkapi_celery._health.check_workers", _no_workers)
    report = healthcheck(celery_app)
    assert report.broker_ok is False
    assert report.workers_alive == 0
