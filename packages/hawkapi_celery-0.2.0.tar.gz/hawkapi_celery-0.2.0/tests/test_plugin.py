"""Plugin entry point + DI."""

from __future__ import annotations

from typing import Any

from celery import Celery
from hawkapi import Depends, HawkAPI
from hawkapi.testing import TestClient

from hawkapi_celery import (
    CeleryConfig,
    get_celery,
    init_celery,
    resolve_celery,
)


def test_init_celery_with_explicit_app() -> None:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)
    celery = init_celery(
        app,
        config=CeleryConfig(broker_url="memory://", result_backend="cache+memory://"),
    )
    assert app.state.celery is celery
    assert isinstance(celery, Celery)


def test_resolve_celery_falls_back_to_last() -> None:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)
    init_celery(app, config=CeleryConfig(broker_url="memory://", result_backend="cache+memory://"))
    assert resolve_celery(None) is not None


def test_get_celery_dep_returns_app() -> None:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)
    init_celery(app, config=CeleryConfig(broker_url="memory://", result_backend="cache+memory://"))

    @app.get("/info")
    async def info(c: Celery = Depends(get_celery)) -> dict[str, Any]:
        return {"broker": c.conf.broker_url}

    client = TestClient(app)
    r = client.get("/info")
    assert r.status_code == 200
    assert r.json() == {"broker": "memory://"}


def test_get_celery_500_when_not_configured() -> None:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)

    @app.get("/info")
    async def info(c: Celery = Depends(get_celery)) -> dict[str, Any]:
        return {"ok": True}

    import hawkapi_celery._plugin as _p

    saved = _p._LAST_APP[0]
    _p._LAST_APP[0] = None
    _p._ACTIVE_APPS.pop(app, None)
    try:
        client = TestClient(app)
        r = client.get("/info")
        assert r.status_code == 500
    finally:
        _p._LAST_APP[0] = saved
