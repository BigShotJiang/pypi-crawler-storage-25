"""Celery app construction."""

from __future__ import annotations

from celery import Celery

from hawkapi_celery import CeleryConfig, create_celery


def test_create_celery_uses_defaults() -> None:
    app = create_celery()
    assert isinstance(app, Celery)
    assert app.conf.task_serializer == "json"
    assert app.conf.timezone == "UTC"


def test_create_celery_applies_config() -> None:
    app = create_celery(
        "myapp",
        config=CeleryConfig(
            broker_url="memory://",
            result_backend="cache+memory://",
            timezone="Europe/Berlin",
            task_time_limit=42,
        ),
    )
    assert app.main == "myapp"
    assert app.conf.broker_url == "memory://"
    assert app.conf.timezone == "Europe/Berlin"
    assert app.conf.task_time_limit == 42


def test_create_celery_extra_kwargs() -> None:
    app = create_celery(config=CeleryConfig(extra_kwargs={"task_acks_late": True}))
    assert app.conf.task_acks_late is True


def test_accept_content_validation() -> None:
    """task_serializer must be listed in accept_content; otherwise create_celery rejects it."""
    import pytest

    bad_serializer = "pickle"  # deliberately not in accept_content
    with pytest.raises(ValueError, match="not in accept_content"):
        create_celery(config=CeleryConfig(task_serializer=bad_serializer, accept_content=["json"]))


def test_accept_content_validation_passes_when_consistent() -> None:
    app = create_celery(
        config=CeleryConfig(
            task_serializer="json",
            accept_content=["json", "yaml"],
        )
    )
    assert app.conf.task_serializer == "json"
