"""Batch prepare lifecycle for auto-scaling large batch operations."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Awaitable, Callable

from ._constants import PREPARE_POLL_INTERVAL, PREPARE_TIMEOUT
from .exceptions import BatchPrepareError

logger = logging.getLogger("prismadata.prepare")


def batch_prepare(
    post_fn: Callable[..., Any],
    total_items: int,
) -> dict[str, Any]:
    """Signal the API that a large batch is starting.

    Args:
        post_fn: Callable that POSTs to an API path (client._post).
        total_items: Total number of items in the batch.

    Returns:
        Response dict with ``session_id`` and ``max_workers``.
    """
    logger.info("Preparing batch for %d items", total_items)
    return post_fn("/v1/batch/prepare", {"total_items": total_items})


def wait_until_ready(
    get_fn: Callable[..., Any],
    session_id: str,
    timeout: int = PREPARE_TIMEOUT,
    interval: int = PREPARE_POLL_INTERVAL,
) -> None:
    """Poll until the infrastructure is ready.

    Args:
        get_fn: Callable that GETs from an API path (client._get).
        session_id: Session ID from batch_prepare response.
        timeout: Max seconds to wait.
        interval: Seconds between polls.

    Raises:
        BatchPrepareError: If not ready within timeout.
    """
    deadline = time.monotonic() + timeout
    logger.info("Waiting for batch session %s to be ready (timeout=%ds)", session_id, timeout)
    while True:
        status = get_fn(f"/v1/batch/prepare/{session_id}/status")
        if status.get("ready"):
            logger.info("Batch session %s is ready", session_id)
            return
        if time.monotonic() >= deadline:
            raise BatchPrepareError(
                f"Batch prepare timed out after {timeout}s for session {session_id}"
            )
        time.sleep(interval)


def batch_complete(
    post_fn: Callable[..., Any],
    session_id: str,
) -> None:
    """Signal the API that the batch is finished (scale down).

    Always called in a finally block — swallows errors to avoid
    masking the original exception.
    """
    try:
        post_fn(f"/v1/batch/complete/{session_id}", {})
        logger.info("Batch session %s completed", session_id)
    except Exception:
        logger.warning("Failed to complete batch session %s", session_id, exc_info=True)


async def async_batch_prepare(
    post_fn: Callable[..., Awaitable[Any]],
    total_items: int,
) -> dict[str, Any]:
    """Async version of batch_prepare."""
    logger.info("Preparing batch for %d items", total_items)
    return await post_fn("/v1/batch/prepare", {"total_items": total_items})


async def async_wait_until_ready(
    get_fn: Callable[..., Awaitable[Any]],
    session_id: str,
    timeout: int = PREPARE_TIMEOUT,
    interval: int = PREPARE_POLL_INTERVAL,
) -> None:
    """Async version of wait_until_ready."""
    deadline = time.monotonic() + timeout
    logger.info("Waiting for batch session %s to be ready (timeout=%ds)", session_id, timeout)
    while True:
        status = await get_fn(f"/v1/batch/prepare/{session_id}/status")
        if status.get("ready"):
            logger.info("Batch session %s is ready", session_id)
            return
        if time.monotonic() >= deadline:
            raise BatchPrepareError(
                f"Batch prepare timed out after {timeout}s for session {session_id}"
            )
        await asyncio.sleep(interval)


async def async_batch_complete(
    post_fn: Callable[..., Awaitable[Any]],
    session_id: str,
) -> None:
    """Async version of batch_complete."""
    try:
        await post_fn(f"/v1/batch/complete/{session_id}", {})
        logger.info("Batch session %s completed", session_id)
    except Exception:
        logger.warning("Failed to complete batch session %s", session_id, exc_info=True)
