# filereaderpy
File Reader/Writer
Now binary writing and reading have arrived.
You can get help by visiting filereaderpy.great-site.net
JSON, YAML, and XML text translation is now available.