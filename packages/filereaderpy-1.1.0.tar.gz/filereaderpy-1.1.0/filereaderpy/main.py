print("You can get help by visiting filereaderpy.great-site.net")

p = ""
w = ""

def read():
    with open(p, "r") as fr:
        reads = fr.read()

def write():
    with open(p, "w") as fw:
        fw.write(w)

def readb():
    with open(p, "rb") as fr:
        reads = fr.read()

def writeb():
    with open(p, "wb") as fw:
        fw.write(w)

def xmltostring():
    with open(p, "r") as fr:
        xmltostrings = fr.read()
        xmltostrings = xmltostrings.replace("<", "").replace(">", "").replace("/", "").replace("<!--", "").replace("-->", "").replace("=", "").replace("'").replace("?", "").replace("!", "").replace("&", "").replace(";", "")

def jsontostring():
    with open(p, "r") as fr:
        jsontostrings = fr.read()
        jsontostrings = jsontostrings.replace("{", "").replace("}", "").replace(":", "").replace(",", "").replace("[", "").replace("]", "").replace("true", "doğru").replace("false", "yanlış").replace("null", "boş")

def yamltostring():
    with open(p, "r") as fr:
        yamltostrings = fr.read()
        yamltostrings = yamltostrings.replace(":", "").replace("-", "").replace("#", "").replace("'", "").replace("|", "").replace(">", "").replace("?", "").replace("[", "").replace("]", "").replace("{", "").replace("}", "")
