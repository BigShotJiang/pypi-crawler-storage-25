> [!WARNING]
> This repository has been **deprecated** and is no longer maintained.  
> The project has been refactored and renamed to **bykcli**.  
>  
> 👉 Please migrate to the new project.

## 简介

[![PyPI](https://img.shields.io/pypi/v/fcbyk-cli.svg)](https://pypi.org/project/fcbyk-cli/)
[![Tests](https://github.com/fcbyk/fcbyk-cli/actions/workflows/test.yml/badge.svg)](https://github.com/fcbyk/fcbyk-cli/actions/workflows/test.yml)
[![License](https://img.shields.io/github/license/fcbyk/fcbyk-cli.svg)](https://github.com/fcbyk/fcbyk-cli/blob/main/LICENSE)

**`fcbyk-cli`** 是一个轻量、实用的命令行工具集合，

它用于通过终端快速完成一些 **零散但真实存在的需求**：
- 没有现成软件可用
- 或者已有软件过于臃肿、广告过多、不够轻量
- 又或者只是想用一条命令把事情做完

**`fcbyk-cli`** 的目标不是 “做一个大全”，  
而是用 **小而直接的工具**，解决当下遇到的问题。

## 已有功能 (子命令)

- [`lansend`](https://github.com/fcbyk/fcbyk-cli/blob/main/docs/LANSend.md)：在指定端口开启 `http服务器`，用于局域网内共享文件
- [`ai`](https://github.com/fcbyk/fcbyk-cli/blob/main/docs/AI.md)：在控制台与 `ai` 聊天 （需自行配置`api-key`）
- [`pick`](https://github.com/fcbyk/fcbyk-cli/blob/main/docs/Pick.md)：随机抽取一个元素（可用于抽奖、随机选择等）
- [`slide`](https://github.com/fcbyk/fcbyk-cli/blob/main/docs/Slide.md)：同一局域网内，手机控制电脑PTT翻页
- [`alias`](https://github.com/fcbyk/fcbyk-cli/blob/main/docs/Alias.md)：为常用命令添加别名，方便快速执行
- [`servers`](https://github.com/fcbyk/fcbyk-cli/blob/main/docs/Servers.md)：统一管理由各子命令启动的后台 Web 服务进程

## 快速开始

- 使用 pip 安装

```bash
pip install fcbyk-cli
```

- 显示帮助信息

```bash
fcbyk
```
