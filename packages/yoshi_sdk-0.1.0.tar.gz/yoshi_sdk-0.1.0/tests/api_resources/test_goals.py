# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from yoshi_sdk import Yoshi, AsyncYoshi
from tests.utils import assert_matches_type
from yoshi_sdk.types import GoalListResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestGoals:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Yoshi) -> None:
        goal = client.goals.list()
        assert_matches_type(GoalListResponse, goal, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Yoshi) -> None:
        goal = client.goals.list(
            status="active",
        )
        assert_matches_type(GoalListResponse, goal, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Yoshi) -> None:
        response = client.goals.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        goal = response.parse()
        assert_matches_type(GoalListResponse, goal, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Yoshi) -> None:
        with client.goals.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            goal = response.parse()
            assert_matches_type(GoalListResponse, goal, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncGoals:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncYoshi) -> None:
        goal = await async_client.goals.list()
        assert_matches_type(GoalListResponse, goal, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncYoshi) -> None:
        goal = await async_client.goals.list(
            status="active",
        )
        assert_matches_type(GoalListResponse, goal, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncYoshi) -> None:
        response = await async_client.goals.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        goal = await response.parse()
        assert_matches_type(GoalListResponse, goal, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncYoshi) -> None:
        async with async_client.goals.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            goal = await response.parse()
            assert_matches_type(GoalListResponse, goal, path=["response"])

        assert cast(Any, response.is_closed) is True
