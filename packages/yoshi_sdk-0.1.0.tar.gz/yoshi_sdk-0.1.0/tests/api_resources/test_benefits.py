# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from yoshi_sdk import Yoshi, AsyncYoshi
from tests.utils import assert_matches_type
from yoshi_sdk.types import BenefitSummaryResponse, BenefitExpiringResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestBenefits:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_expiring(self, client: Yoshi) -> None:
        benefit = client.benefits.expiring()
        assert_matches_type(BenefitExpiringResponse, benefit, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_expiring_with_all_params(self, client: Yoshi) -> None:
        benefit = client.benefits.expiring(
            days=1,
        )
        assert_matches_type(BenefitExpiringResponse, benefit, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_expiring(self, client: Yoshi) -> None:
        response = client.benefits.with_raw_response.expiring()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        benefit = response.parse()
        assert_matches_type(BenefitExpiringResponse, benefit, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_expiring(self, client: Yoshi) -> None:
        with client.benefits.with_streaming_response.expiring() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            benefit = response.parse()
            assert_matches_type(BenefitExpiringResponse, benefit, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_summary(self, client: Yoshi) -> None:
        benefit = client.benefits.summary()
        assert_matches_type(BenefitSummaryResponse, benefit, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_summary(self, client: Yoshi) -> None:
        response = client.benefits.with_raw_response.summary()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        benefit = response.parse()
        assert_matches_type(BenefitSummaryResponse, benefit, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_summary(self, client: Yoshi) -> None:
        with client.benefits.with_streaming_response.summary() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            benefit = response.parse()
            assert_matches_type(BenefitSummaryResponse, benefit, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncBenefits:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_expiring(self, async_client: AsyncYoshi) -> None:
        benefit = await async_client.benefits.expiring()
        assert_matches_type(BenefitExpiringResponse, benefit, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_expiring_with_all_params(self, async_client: AsyncYoshi) -> None:
        benefit = await async_client.benefits.expiring(
            days=1,
        )
        assert_matches_type(BenefitExpiringResponse, benefit, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_expiring(self, async_client: AsyncYoshi) -> None:
        response = await async_client.benefits.with_raw_response.expiring()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        benefit = await response.parse()
        assert_matches_type(BenefitExpiringResponse, benefit, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_expiring(self, async_client: AsyncYoshi) -> None:
        async with async_client.benefits.with_streaming_response.expiring() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            benefit = await response.parse()
            assert_matches_type(BenefitExpiringResponse, benefit, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_summary(self, async_client: AsyncYoshi) -> None:
        benefit = await async_client.benefits.summary()
        assert_matches_type(BenefitSummaryResponse, benefit, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_summary(self, async_client: AsyncYoshi) -> None:
        response = await async_client.benefits.with_raw_response.summary()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        benefit = await response.parse()
        assert_matches_type(BenefitSummaryResponse, benefit, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_summary(self, async_client: AsyncYoshi) -> None:
        async with async_client.benefits.with_streaming_response.summary() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            benefit = await response.parse()
            assert_matches_type(BenefitSummaryResponse, benefit, path=["response"])

        assert cast(Any, response.is_closed) is True
