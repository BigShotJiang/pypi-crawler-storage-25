# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from yoshi_sdk import Yoshi, AsyncYoshi
from tests.utils import assert_matches_type
from yoshi_sdk.pagination import SyncCursorPage, AsyncCursorPage
from yoshi_sdk.types.paper_trading.accounts import (
    TradeListResponse,
    TradeCreateResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestTrades:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Yoshi) -> None:
        trade = client.paper_trading.accounts.trades.create(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            side="buy",
            symbol="x",
        )
        assert_matches_type(TradeCreateResponse, trade, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Yoshi) -> None:
        trade = client.paper_trading.accounts.trades.create(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            side="buy",
            symbol="x",
            notional=1,
            quantity=1,
            skip_approval=True,
        )
        assert_matches_type(TradeCreateResponse, trade, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Yoshi) -> None:
        response = client.paper_trading.accounts.trades.with_raw_response.create(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            side="buy",
            symbol="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        trade = response.parse()
        assert_matches_type(TradeCreateResponse, trade, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Yoshi) -> None:
        with client.paper_trading.accounts.trades.with_streaming_response.create(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            side="buy",
            symbol="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            trade = response.parse()
            assert_matches_type(TradeCreateResponse, trade, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_create(self, client: Yoshi) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `account_id` but received ''"):
            client.paper_trading.accounts.trades.with_raw_response.create(
                account_id="",
                side="buy",
                symbol="x",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Yoshi) -> None:
        trade = client.paper_trading.accounts.trades.list(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(SyncCursorPage[TradeListResponse], trade, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Yoshi) -> None:
        trade = client.paper_trading.accounts.trades.list(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            cursor="cursor",
            limit=1,
        )
        assert_matches_type(SyncCursorPage[TradeListResponse], trade, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Yoshi) -> None:
        response = client.paper_trading.accounts.trades.with_raw_response.list(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        trade = response.parse()
        assert_matches_type(SyncCursorPage[TradeListResponse], trade, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Yoshi) -> None:
        with client.paper_trading.accounts.trades.with_streaming_response.list(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            trade = response.parse()
            assert_matches_type(SyncCursorPage[TradeListResponse], trade, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_list(self, client: Yoshi) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `account_id` but received ''"):
            client.paper_trading.accounts.trades.with_raw_response.list(
                account_id="",
            )


class TestAsyncTrades:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncYoshi) -> None:
        trade = await async_client.paper_trading.accounts.trades.create(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            side="buy",
            symbol="x",
        )
        assert_matches_type(TradeCreateResponse, trade, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncYoshi) -> None:
        trade = await async_client.paper_trading.accounts.trades.create(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            side="buy",
            symbol="x",
            notional=1,
            quantity=1,
            skip_approval=True,
        )
        assert_matches_type(TradeCreateResponse, trade, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncYoshi) -> None:
        response = await async_client.paper_trading.accounts.trades.with_raw_response.create(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            side="buy",
            symbol="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        trade = await response.parse()
        assert_matches_type(TradeCreateResponse, trade, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncYoshi) -> None:
        async with async_client.paper_trading.accounts.trades.with_streaming_response.create(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            side="buy",
            symbol="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            trade = await response.parse()
            assert_matches_type(TradeCreateResponse, trade, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_create(self, async_client: AsyncYoshi) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `account_id` but received ''"):
            await async_client.paper_trading.accounts.trades.with_raw_response.create(
                account_id="",
                side="buy",
                symbol="x",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncYoshi) -> None:
        trade = await async_client.paper_trading.accounts.trades.list(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(AsyncCursorPage[TradeListResponse], trade, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncYoshi) -> None:
        trade = await async_client.paper_trading.accounts.trades.list(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            cursor="cursor",
            limit=1,
        )
        assert_matches_type(AsyncCursorPage[TradeListResponse], trade, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncYoshi) -> None:
        response = await async_client.paper_trading.accounts.trades.with_raw_response.list(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        trade = await response.parse()
        assert_matches_type(AsyncCursorPage[TradeListResponse], trade, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncYoshi) -> None:
        async with async_client.paper_trading.accounts.trades.with_streaming_response.list(
            account_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            trade = await response.parse()
            assert_matches_type(AsyncCursorPage[TradeListResponse], trade, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_list(self, async_client: AsyncYoshi) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `account_id` but received ''"):
            await async_client.paper_trading.accounts.trades.with_raw_response.list(
                account_id="",
            )
