# Accounts

Types:

```python
from yoshi_sdk.types import AccountListResponse
```

Methods:

- <code title="get /accounts">client.accounts.<a href="./src/yoshi_sdk/resources/accounts/accounts.py">list</a>(\*\*<a href="src/yoshi_sdk/types/account_list_params.py">params</a>) -> <a href="./src/yoshi_sdk/types/account_list_response.py">AccountListResponse</a></code>

## BalanceSeries

Types:

```python
from yoshi_sdk.types.accounts import BalanceSeriesListResponse
```

Methods:

- <code title="get /accounts/{id}/balances">client.accounts.balance_series.<a href="./src/yoshi_sdk/resources/accounts/balance_series.py">list</a>(id, \*\*<a href="src/yoshi_sdk/types/accounts/balance_series_list_params.py">params</a>) -> <a href="./src/yoshi_sdk/types/accounts/balance_series_list_response.py">BalanceSeriesListResponse</a></code>

# Transactions

Types:

```python
from yoshi_sdk.types import TransactionListResponse
```

Methods:

- <code title="get /transactions">client.transactions.<a href="./src/yoshi_sdk/resources/transactions.py">list</a>(\*\*<a href="src/yoshi_sdk/types/transaction_list_params.py">params</a>) -> <a href="./src/yoshi_sdk/types/transaction_list_response.py">SyncCursorPage[TransactionListResponse]</a></code>

# Scores

Types:

```python
from yoshi_sdk.types import ScoreListResponse
```

Methods:

- <code title="get /scores">client.scores.<a href="./src/yoshi_sdk/resources/scores.py">list</a>() -> <a href="./src/yoshi_sdk/types/score_list_response.py">ScoreListResponse</a></code>

# Goals

Types:

```python
from yoshi_sdk.types import GoalListResponse
```

Methods:

- <code title="get /goals">client.goals.<a href="./src/yoshi_sdk/resources/goals.py">list</a>(\*\*<a href="src/yoshi_sdk/types/goal_list_params.py">params</a>) -> <a href="./src/yoshi_sdk/types/goal_list_response.py">GoalListResponse</a></code>

# Recurring

Types:

```python
from yoshi_sdk.types import RecurringListResponse
```

Methods:

- <code title="get /recurring">client.recurring.<a href="./src/yoshi_sdk/resources/recurring.py">list</a>() -> <a href="./src/yoshi_sdk/types/recurring_list_response.py">RecurringListResponse</a></code>

# Benefits

Types:

```python
from yoshi_sdk.types import BenefitExpiringResponse, BenefitSummaryResponse
```

Methods:

- <code title="get /benefits/expiring">client.benefits.<a href="./src/yoshi_sdk/resources/benefits.py">expiring</a>(\*\*<a href="src/yoshi_sdk/types/benefit_expiring_params.py">params</a>) -> <a href="./src/yoshi_sdk/types/benefit_expiring_response.py">BenefitExpiringResponse</a></code>
- <code title="get /benefits/summary">client.benefits.<a href="./src/yoshi_sdk/resources/benefits.py">summary</a>() -> <a href="./src/yoshi_sdk/types/benefit_summary_response.py">BenefitSummaryResponse</a></code>

# Investments

Types:

```python
from yoshi_sdk.types import InvestmentListResponse
```

Methods:

- <code title="get /investments">client.investments.<a href="./src/yoshi_sdk/resources/investments.py">list</a>(\*\*<a href="src/yoshi_sdk/types/investment_list_params.py">params</a>) -> <a href="./src/yoshi_sdk/types/investment_list_response.py">InvestmentListResponse</a></code>

# Income

Types:

```python
from yoshi_sdk.types import IncomeRetrieveResponse
```

Methods:

- <code title="get /income">client.income.<a href="./src/yoshi_sdk/resources/income.py">retrieve</a>() -> <a href="./src/yoshi_sdk/types/income_retrieve_response.py">IncomeRetrieveResponse</a></code>

# Me

Types:

```python
from yoshi_sdk.types import MeRetrieveResponse, MeSummaryResponse
```

Methods:

- <code title="get /me">client.me.<a href="./src/yoshi_sdk/resources/me.py">retrieve</a>() -> <a href="./src/yoshi_sdk/types/me_retrieve_response.py">MeRetrieveResponse</a></code>
- <code title="get /me/summary">client.me.<a href="./src/yoshi_sdk/resources/me.py">summary</a>(\*\*<a href="src/yoshi_sdk/types/me_summary_params.py">params</a>) -> <a href="./src/yoshi_sdk/types/me_summary_response.py">MeSummaryResponse</a></code>

# PaperTrading

## Accounts

Types:

```python
from yoshi_sdk.types.paper_trading import AccountCreateResponse, AccountListResponse
```

Methods:

- <code title="post /paper-trading/accounts">client.paper_trading.accounts.<a href="./src/yoshi_sdk/resources/paper_trading/accounts/accounts.py">create</a>(\*\*<a href="src/yoshi_sdk/types/paper_trading/account_create_params.py">params</a>) -> <a href="./src/yoshi_sdk/types/paper_trading/account_create_response.py">AccountCreateResponse</a></code>
- <code title="get /paper-trading/accounts">client.paper_trading.accounts.<a href="./src/yoshi_sdk/resources/paper_trading/accounts/accounts.py">list</a>() -> <a href="./src/yoshi_sdk/types/paper_trading/account_list_response.py">AccountListResponse</a></code>

### Holdings

Types:

```python
from yoshi_sdk.types.paper_trading.accounts import HoldingListResponse
```

Methods:

- <code title="get /paper-trading/accounts/{accountId}/holdings">client.paper_trading.accounts.holdings.<a href="./src/yoshi_sdk/resources/paper_trading/accounts/holdings.py">list</a>(account_id) -> <a href="./src/yoshi_sdk/types/paper_trading/accounts/holding_list_response.py">HoldingListResponse</a></code>

### Trades

Types:

```python
from yoshi_sdk.types.paper_trading.accounts import TradeCreateResponse, TradeListResponse
```

Methods:

- <code title="post /paper-trading/accounts/{accountId}/trades">client.paper_trading.accounts.trades.<a href="./src/yoshi_sdk/resources/paper_trading/accounts/trades.py">create</a>(account_id, \*\*<a href="src/yoshi_sdk/types/paper_trading/accounts/trade_create_params.py">params</a>) -> <a href="./src/yoshi_sdk/types/paper_trading/accounts/trade_create_response.py">TradeCreateResponse</a></code>
- <code title="get /paper-trading/accounts/{accountId}/trades">client.paper_trading.accounts.trades.<a href="./src/yoshi_sdk/resources/paper_trading/accounts/trades.py">list</a>(account_id, \*\*<a href="src/yoshi_sdk/types/paper_trading/accounts/trade_list_params.py">params</a>) -> <a href="./src/yoshi_sdk/types/paper_trading/accounts/trade_list_response.py">SyncCursorPage[TradeListResponse]</a></code>

# Approvals

Types:

```python
from yoshi_sdk.types import ApprovalRetrieveResponse
```

Methods:

- <code title="get /approvals/{threadId}">client.approvals.<a href="./src/yoshi_sdk/resources/approvals.py">retrieve</a>(thread_id) -> <a href="./src/yoshi_sdk/types/approval_retrieve_response.py">ApprovalRetrieveResponse</a></code>
