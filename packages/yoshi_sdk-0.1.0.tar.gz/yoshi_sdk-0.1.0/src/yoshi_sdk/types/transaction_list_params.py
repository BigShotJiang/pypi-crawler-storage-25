# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["TransactionListParams"]


class TransactionListParams(TypedDict, total=False):
    account_id: str
    """Filter by account ID"""

    cursor: str
    """Opaque cursor from a previous response"""

    limit: int
    """Items per page (1-100, default 50)"""
