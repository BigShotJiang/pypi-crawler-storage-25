# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from datetime import datetime

from .._models import BaseModel

__all__ = ["ScoreListResponse", "Data", "Meta"]


class Data(BaseModel):
    baseline: float

    capacity: float

    observation_date: str

    recovery: float

    yoshi: float


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class ScoreListResponse(BaseModel):
    data: Data

    meta: Meta
