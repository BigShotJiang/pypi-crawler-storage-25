# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["MeSummaryResponse", "Data", "DataAccounts", "DataAccountsItem", "DataGoal", "DataScores", "Meta"]


class DataAccountsItem(BaseModel):
    id: str

    balance_available: Optional[float] = None

    balance_current: Optional[float] = None

    balance_limit: Optional[float] = None

    hidden: bool

    institution_name: Optional[str] = None

    name: str

    status: str

    subtype: Optional[str] = None

    type: str


class DataAccounts(BaseModel):
    items: List[DataAccountsItem]

    total: int


class DataGoal(BaseModel):
    id: str

    current_value: Optional[float] = None

    goal_type: str

    name: str

    status: str

    target_amount: Optional[float] = None

    target_date: Optional[str] = None


class DataScores(BaseModel):
    baseline: float

    capacity: float

    observation_date: str

    recovery: float

    yoshi: float


class Data(BaseModel):
    accounts: DataAccounts

    goals: List[DataGoal]

    scores: Optional[DataScores] = None


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class MeSummaryResponse(BaseModel):
    data: Data

    meta: Meta
