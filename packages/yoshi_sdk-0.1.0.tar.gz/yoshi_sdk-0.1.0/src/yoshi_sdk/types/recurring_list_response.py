# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["RecurringListResponse", "Data", "DataStream", "Meta"]


class DataStream(BaseModel):
    id: str

    account_id: str

    account_name: Optional[str] = None

    average_amount: Optional[float] = None

    currency_code: Optional[str] = None

    description: str

    direction: str

    first_date: Optional[str] = None

    frequency: str

    is_active: bool

    last_amount: Optional[float] = None

    last_date: Optional[str] = None

    merchant_name: Optional[str] = None

    predicted_next_date: Optional[str] = None

    status: str


class Data(BaseModel):
    streams: List[DataStream]


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class RecurringListResponse(BaseModel):
    data: Data

    meta: Meta
