# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["MeRetrieveResponse", "Data", "Meta"]


class Data(BaseModel):
    id: str

    created_at: str

    email: str

    image: Optional[str] = None

    preferred_name: Optional[str] = None


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class MeRetrieveResponse(BaseModel):
    data: Data

    meta: Meta
