# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from datetime import datetime

from ..._models import BaseModel

__all__ = ["BalanceSeriesListResponse", "Data", "DataPoint", "Meta"]


class DataPoint(BaseModel):
    balance: float

    date: str


class Data(BaseModel):
    account_id: str

    account_name: str

    days: int

    iso_currency_code: str

    points: List[DataPoint]


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class BalanceSeriesListResponse(BaseModel):
    data: Data

    meta: Meta
