# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["GoalListResponse", "Data", "DataGoal", "Meta"]


class DataGoal(BaseModel):
    id: str

    current_value: Optional[float] = None

    goal_type: str

    name: str

    status: str

    target_amount: Optional[float] = None

    target_date: Optional[str] = None


class Data(BaseModel):
    goals: List[DataGoal]


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class GoalListResponse(BaseModel):
    data: Data

    meta: Meta
