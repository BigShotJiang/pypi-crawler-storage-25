# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from datetime import datetime

from .._models import BaseModel

__all__ = ["BenefitExpiringResponse", "Data", "DataExpiring", "Meta"]


class DataExpiring(BaseModel):
    benefit_name: str

    benefit_type: str

    card_issuer: str

    card_product_name: str

    days_remaining: float

    period_end: str

    period_id: str

    status: str

    value_limit_cents: float

    value_remaining_cents: float

    value_used_cents: float


class Data(BaseModel):
    expiring: List[DataExpiring]


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class BenefitExpiringResponse(BaseModel):
    data: Data

    meta: Meta
