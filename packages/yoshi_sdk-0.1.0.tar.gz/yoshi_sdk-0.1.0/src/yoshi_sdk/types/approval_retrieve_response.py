# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["ApprovalRetrieveResponse", "Data", "Meta"]


class Data(BaseModel):
    action_id: Optional[str] = None

    created_at: Optional[str] = None

    description: Optional[str] = None

    status: str

    thread_id: str

    updated_at: Optional[str] = None


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class ApprovalRetrieveResponse(BaseModel):
    data: Data

    meta: Meta
