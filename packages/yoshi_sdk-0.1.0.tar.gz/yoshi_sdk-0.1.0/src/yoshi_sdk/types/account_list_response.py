# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["AccountListResponse", "Data", "DataAccount", "Meta"]


class DataAccount(BaseModel):
    id: str

    apy_percent_display: Optional[str] = None

    as_of: Optional[str] = None

    balance_available: Optional[float] = None

    balance_current: Optional[float] = None

    balance_limit: Optional[float] = None

    external_source: str

    hidden: bool

    institution_logo: Optional[str] = None

    institution_name: Optional[str] = None

    interest_rate_percentage: Optional[float] = None

    mask: Optional[str] = None

    name: str

    next_payment_due_date: Optional[str] = None

    status: str

    subtype: Optional[str] = None

    type: str


class Data(BaseModel):
    accounts: List[DataAccount]


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class AccountListResponse(BaseModel):
    data: Data

    meta: Meta
