# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["BenefitSummaryResponse", "Data", "DataPeriod", "Meta"]


class DataPeriod(BaseModel):
    benefit_description: Optional[str] = None

    benefit_name: str

    benefit_type: str

    card_issuer: str

    card_product_name: str

    card_product_slug: str

    days_remaining: float

    max_uses_per_period: Optional[float] = None

    period_end: str

    period_id: str

    period_start: str

    reset_cadence: str

    status: str

    usage_pct: float

    uses_count: float

    value_limit_cents: float

    value_remaining_cents: float

    value_used_cents: float


class Data(BaseModel):
    periods: List[DataPeriod]

    total_remaining_cents: float

    total_used_cents: float

    total_value_cents: float


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class BenefitSummaryResponse(BaseModel):
    data: Data

    meta: Meta
