# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, TypedDict

__all__ = ["InvestmentListParams"]


class InvestmentListParams(TypedDict, total=False):
    account_id: str

    category: str
    """Filter by asset class"""

    sort_by: Literal[
        "symbol", "last_price", "day_change", "total_gain_loss", "current_value", "quantity", "cost_basis_total"
    ]

    sort_dir: Literal["asc", "desc"]
