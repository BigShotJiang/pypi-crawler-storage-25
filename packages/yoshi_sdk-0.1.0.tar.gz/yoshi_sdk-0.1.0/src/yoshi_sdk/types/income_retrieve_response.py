# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from datetime import datetime

from .._models import BaseModel

__all__ = [
    "IncomeRetrieveResponse",
    "Data",
    "DataDebt",
    "DataEmergencyFund",
    "DataExpenses",
    "DataInvestments",
    "DataVariability",
    "DataWindow",
    "Meta",
]


class DataDebt(BaseModel):
    amount: float

    percent: float

    breakdown: Optional[Dict[str, float]] = None


class DataEmergencyFund(BaseModel):
    amount: float

    percent: float

    breakdown: Optional[Dict[str, float]] = None


class DataExpenses(BaseModel):
    amount: float

    percent: float

    breakdown: Optional[Dict[str, float]] = None


class DataInvestments(BaseModel):
    amount: float

    percent: float

    breakdown: Optional[Dict[str, float]] = None


class DataVariability(BaseModel):
    max: float

    min: float

    range: float


class DataWindow(BaseModel):
    end: str

    months: int

    start: str


class Data(BaseModel):
    debt: DataDebt

    emergency_fund: DataEmergencyFund

    expenses: DataExpenses

    generated_at: str

    investments: DataInvestments

    monthly_income: float

    variability: DataVariability

    window: DataWindow


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class IncomeRetrieveResponse(BaseModel):
    data: Data

    meta: Meta
