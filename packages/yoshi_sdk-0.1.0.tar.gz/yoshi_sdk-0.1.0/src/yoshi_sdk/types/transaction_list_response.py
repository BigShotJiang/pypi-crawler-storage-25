# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .._models import BaseModel

__all__ = ["TransactionListResponse"]


class TransactionListResponse(BaseModel):
    id: str

    account_id: str

    account_name: str

    amount: float

    amount_absolute: float

    cash_flow_direction: str

    category_label: str

    category_tier1: str

    category_tier2: Optional[str] = None

    counterparty_logo_url: Optional[str] = None

    counterparty_name: str

    date_authorized: Optional[str] = None

    date_posted: str

    is_internal_transfer: bool

    original_description: Optional[str] = None

    pending: bool
