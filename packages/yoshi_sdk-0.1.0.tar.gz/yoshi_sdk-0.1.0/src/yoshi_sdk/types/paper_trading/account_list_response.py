# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from ..._models import BaseModel

__all__ = ["AccountListResponse", "Data", "DataAccount", "Meta"]


class DataAccount(BaseModel):
    id: str

    as_of: Optional[str] = None

    balance_available: Optional[float] = None

    balance_current: Optional[float] = None

    created_at: Optional[str] = None

    name: Optional[str] = None

    status: str


class Data(BaseModel):
    accounts: List[DataAccount]


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class AccountListResponse(BaseModel):
    data: Data

    meta: Meta
