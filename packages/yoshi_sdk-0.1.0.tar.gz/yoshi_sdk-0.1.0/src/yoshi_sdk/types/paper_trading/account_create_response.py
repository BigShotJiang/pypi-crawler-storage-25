# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from ..._models import BaseModel

__all__ = ["AccountCreateResponse", "Data", "Meta"]


class Data(BaseModel):
    action_id: str

    approval_status_url: Optional[str] = None

    approval_url: str

    description: str

    status: str

    thread_id: Optional[str] = None


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class AccountCreateResponse(BaseModel):
    data: Data

    meta: Meta
