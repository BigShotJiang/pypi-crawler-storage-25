# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["AccountCreateParams"]


class AccountCreateParams(TypedDict, total=False):
    name: str

    skip_approval: bool
    """Skip the approval flow and execute immediately.

    Not supported yet — reserved for future use.
    """

    starting_cash_balance: str
