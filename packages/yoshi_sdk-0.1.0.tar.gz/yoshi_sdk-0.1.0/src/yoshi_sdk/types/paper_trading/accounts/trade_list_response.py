# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ...._models import BaseModel

__all__ = ["TradeListResponse"]


class TradeListResponse(BaseModel):
    id: str

    amount: Optional[float] = None

    created_at: Optional[str] = None

    date: Optional[str] = None

    name: Optional[str] = None

    price: Optional[float] = None

    quantity: Optional[float] = None

    subtype: Optional[str] = None

    symbol: Optional[str] = None

    type: Optional[str] = None
