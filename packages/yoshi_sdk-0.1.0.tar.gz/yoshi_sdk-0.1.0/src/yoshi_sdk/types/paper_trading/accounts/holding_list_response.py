# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from ...._models import BaseModel

__all__ = ["HoldingListResponse", "Data", "DataHolding", "Meta"]


class DataHolding(BaseModel):
    id: str

    as_of: Optional[str] = None

    cost_basis: Optional[float] = None

    institution_price: Optional[float] = None

    institution_value: Optional[float] = None

    name: Optional[str] = None

    quantity: float

    security_id: str

    security_type: Optional[str] = None

    symbol: Optional[str] = None


class Data(BaseModel):
    holdings: List[DataHolding]


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class HoldingListResponse(BaseModel):
    data: Data

    meta: Meta
