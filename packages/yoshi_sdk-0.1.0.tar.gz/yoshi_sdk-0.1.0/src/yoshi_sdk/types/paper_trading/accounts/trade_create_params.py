# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["TradeCreateParams"]


class TradeCreateParams(TypedDict, total=False):
    side: Required[Literal["buy", "sell"]]

    symbol: Required[str]

    notional: float

    quantity: float

    skip_approval: bool
    """Skip the approval flow and execute immediately.

    Not supported yet — reserved for future use.
    """
