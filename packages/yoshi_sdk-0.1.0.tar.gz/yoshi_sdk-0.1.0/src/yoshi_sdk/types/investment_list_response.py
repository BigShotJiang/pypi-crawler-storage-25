# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["InvestmentListResponse", "Data", "DataAccountTotal", "DataGroup", "DataGroupHolding", "Meta"]


class DataAccountTotal(BaseModel):
    cost_basis_total: float

    current_value: float

    day_change: float

    day_change_percent: Optional[float] = None

    total_gain_loss: float

    total_gain_loss_percent: Optional[float] = None


class DataGroupHolding(BaseModel):
    asset_class: Optional[str] = None

    average_cost_basis: Optional[float] = None

    category: Optional[str] = None

    cost_basis_total: Optional[float] = None

    current_value: float

    day_change: Optional[float] = None

    day_change_percent: Optional[float] = None

    last_price: Optional[float] = None

    last_price_at: Optional[str] = None

    name: Optional[str] = None

    percent_of_account: float

    quantity: float

    security_id: str

    security_type: Optional[str] = None

    symbol: Optional[str] = None

    total_gain_loss: Optional[float] = None

    total_gain_loss_percent: Optional[float] = None


class DataGroup(BaseModel):
    asset_class: Optional[str] = None

    holdings: List[DataGroupHolding]


class Data(BaseModel):
    account_total: DataAccountTotal

    groups: List[DataGroup]


class Meta(BaseModel):
    request_id: str

    timestamp: datetime


class InvestmentListResponse(BaseModel):
    data: Data

    meta: Meta
