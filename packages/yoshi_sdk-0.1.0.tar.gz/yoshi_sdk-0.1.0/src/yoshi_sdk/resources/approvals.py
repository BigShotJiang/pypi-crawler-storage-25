# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .._types import Body, Query, Headers, NotGiven, not_given
from .._utils import path_template
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.approval_retrieve_response import ApprovalRetrieveResponse

__all__ = ["ApprovalsResource", "AsyncApprovalsResource"]


class ApprovalsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ApprovalsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return ApprovalsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ApprovalsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return ApprovalsResourceWithStreamingResponse(self)

    def retrieve(
        self,
        thread_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ApprovalRetrieveResponse:
        """
        Check the approval status of a pending action (paper trading account creation,
        trade execution, etc.).

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return self._get(
            path_template("/approvals/{thread_id}", thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ApprovalRetrieveResponse,
        )


class AsyncApprovalsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncApprovalsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return AsyncApprovalsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncApprovalsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return AsyncApprovalsResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        thread_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ApprovalRetrieveResponse:
        """
        Check the approval status of a pending action (paper trading account creation,
        trade execution, etc.).

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not thread_id:
            raise ValueError(f"Expected a non-empty value for `thread_id` but received {thread_id!r}")
        return await self._get(
            path_template("/approvals/{thread_id}", thread_id=thread_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ApprovalRetrieveResponse,
        )


class ApprovalsResourceWithRawResponse:
    def __init__(self, approvals: ApprovalsResource) -> None:
        self._approvals = approvals

        self.retrieve = to_raw_response_wrapper(
            approvals.retrieve,
        )


class AsyncApprovalsResourceWithRawResponse:
    def __init__(self, approvals: AsyncApprovalsResource) -> None:
        self._approvals = approvals

        self.retrieve = async_to_raw_response_wrapper(
            approvals.retrieve,
        )


class ApprovalsResourceWithStreamingResponse:
    def __init__(self, approvals: ApprovalsResource) -> None:
        self._approvals = approvals

        self.retrieve = to_streamed_response_wrapper(
            approvals.retrieve,
        )


class AsyncApprovalsResourceWithStreamingResponse:
    def __init__(self, approvals: AsyncApprovalsResource) -> None:
        self._approvals = approvals

        self.retrieve = async_to_streamed_response_wrapper(
            approvals.retrieve,
        )
