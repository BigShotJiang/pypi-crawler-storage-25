# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .._types import Body, Query, Headers, NotGiven, not_given
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.income_retrieve_response import IncomeRetrieveResponse

__all__ = ["IncomeResource", "AsyncIncomeResource"]


class IncomeResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> IncomeResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return IncomeResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> IncomeResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return IncomeResourceWithStreamingResponse(self)

    def retrieve(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> IncomeRetrieveResponse:
        """Get income analysis and distribution."""
        return self._get(
            "/income",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=IncomeRetrieveResponse,
        )


class AsyncIncomeResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncIncomeResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return AsyncIncomeResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncIncomeResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return AsyncIncomeResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> IncomeRetrieveResponse:
        """Get income analysis and distribution."""
        return await self._get(
            "/income",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=IncomeRetrieveResponse,
        )


class IncomeResourceWithRawResponse:
    def __init__(self, income: IncomeResource) -> None:
        self._income = income

        self.retrieve = to_raw_response_wrapper(
            income.retrieve,
        )


class AsyncIncomeResourceWithRawResponse:
    def __init__(self, income: AsyncIncomeResource) -> None:
        self._income = income

        self.retrieve = async_to_raw_response_wrapper(
            income.retrieve,
        )


class IncomeResourceWithStreamingResponse:
    def __init__(self, income: IncomeResource) -> None:
        self._income = income

        self.retrieve = to_streamed_response_wrapper(
            income.retrieve,
        )


class AsyncIncomeResourceWithStreamingResponse:
    def __init__(self, income: AsyncIncomeResource) -> None:
        self._income = income

        self.retrieve = async_to_streamed_response_wrapper(
            income.retrieve,
        )
