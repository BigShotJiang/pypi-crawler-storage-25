# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import investment_list_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.investment_list_response import InvestmentListResponse

__all__ = ["InvestmentsResource", "AsyncInvestmentsResource"]


class InvestmentsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> InvestmentsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return InvestmentsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> InvestmentsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return InvestmentsResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        account_id: str | Omit = omit,
        category: str | Omit = omit,
        sort_by: Literal[
            "symbol", "last_price", "day_change", "total_gain_loss", "current_value", "quantity", "cost_basis_total"
        ]
        | Omit = omit,
        sort_dir: Literal["asc", "desc"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InvestmentListResponse:
        """
        Get investment holdings grouped by asset class.

        Args:
          category: Filter by asset class

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/investments",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "account_id": account_id,
                        "category": category,
                        "sort_by": sort_by,
                        "sort_dir": sort_dir,
                    },
                    investment_list_params.InvestmentListParams,
                ),
            ),
            cast_to=InvestmentListResponse,
        )


class AsyncInvestmentsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncInvestmentsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return AsyncInvestmentsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncInvestmentsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return AsyncInvestmentsResourceWithStreamingResponse(self)

    async def list(
        self,
        *,
        account_id: str | Omit = omit,
        category: str | Omit = omit,
        sort_by: Literal[
            "symbol", "last_price", "day_change", "total_gain_loss", "current_value", "quantity", "cost_basis_total"
        ]
        | Omit = omit,
        sort_dir: Literal["asc", "desc"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InvestmentListResponse:
        """
        Get investment holdings grouped by asset class.

        Args:
          category: Filter by asset class

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/investments",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "account_id": account_id,
                        "category": category,
                        "sort_by": sort_by,
                        "sort_dir": sort_dir,
                    },
                    investment_list_params.InvestmentListParams,
                ),
            ),
            cast_to=InvestmentListResponse,
        )


class InvestmentsResourceWithRawResponse:
    def __init__(self, investments: InvestmentsResource) -> None:
        self._investments = investments

        self.list = to_raw_response_wrapper(
            investments.list,
        )


class AsyncInvestmentsResourceWithRawResponse:
    def __init__(self, investments: AsyncInvestmentsResource) -> None:
        self._investments = investments

        self.list = async_to_raw_response_wrapper(
            investments.list,
        )


class InvestmentsResourceWithStreamingResponse:
    def __init__(self, investments: InvestmentsResource) -> None:
        self._investments = investments

        self.list = to_streamed_response_wrapper(
            investments.list,
        )


class AsyncInvestmentsResourceWithStreamingResponse:
    def __init__(self, investments: AsyncInvestmentsResource) -> None:
        self._investments = investments

        self.list = async_to_streamed_response_wrapper(
            investments.list,
        )
