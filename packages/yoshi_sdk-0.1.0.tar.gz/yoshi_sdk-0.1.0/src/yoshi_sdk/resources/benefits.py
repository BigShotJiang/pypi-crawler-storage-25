# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import benefit_expiring_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.benefit_summary_response import BenefitSummaryResponse
from ..types.benefit_expiring_response import BenefitExpiringResponse

__all__ = ["BenefitsResource", "AsyncBenefitsResource"]


class BenefitsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> BenefitsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return BenefitsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> BenefitsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return BenefitsResourceWithStreamingResponse(self)

    def expiring(
        self,
        *,
        days: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BenefitExpiringResponse:
        """
        Get benefits expiring soon that have remaining value.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/benefits/expiring",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"days": days}, benefit_expiring_params.BenefitExpiringParams),
            ),
            cast_to=BenefitExpiringResponse,
        )

    def summary(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BenefitSummaryResponse:
        """
        Get a summary of the user's card benefit periods with usage and remaining value.
        """
        return self._get(
            "/benefits/summary",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BenefitSummaryResponse,
        )


class AsyncBenefitsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncBenefitsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return AsyncBenefitsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncBenefitsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return AsyncBenefitsResourceWithStreamingResponse(self)

    async def expiring(
        self,
        *,
        days: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BenefitExpiringResponse:
        """
        Get benefits expiring soon that have remaining value.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/benefits/expiring",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"days": days}, benefit_expiring_params.BenefitExpiringParams),
            ),
            cast_to=BenefitExpiringResponse,
        )

    async def summary(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BenefitSummaryResponse:
        """
        Get a summary of the user's card benefit periods with usage and remaining value.
        """
        return await self._get(
            "/benefits/summary",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BenefitSummaryResponse,
        )


class BenefitsResourceWithRawResponse:
    def __init__(self, benefits: BenefitsResource) -> None:
        self._benefits = benefits

        self.expiring = to_raw_response_wrapper(
            benefits.expiring,
        )
        self.summary = to_raw_response_wrapper(
            benefits.summary,
        )


class AsyncBenefitsResourceWithRawResponse:
    def __init__(self, benefits: AsyncBenefitsResource) -> None:
        self._benefits = benefits

        self.expiring = async_to_raw_response_wrapper(
            benefits.expiring,
        )
        self.summary = async_to_raw_response_wrapper(
            benefits.summary,
        )


class BenefitsResourceWithStreamingResponse:
    def __init__(self, benefits: BenefitsResource) -> None:
        self._benefits = benefits

        self.expiring = to_streamed_response_wrapper(
            benefits.expiring,
        )
        self.summary = to_streamed_response_wrapper(
            benefits.summary,
        )


class AsyncBenefitsResourceWithStreamingResponse:
    def __init__(self, benefits: AsyncBenefitsResource) -> None:
        self._benefits = benefits

        self.expiring = async_to_streamed_response_wrapper(
            benefits.expiring,
        )
        self.summary = async_to_streamed_response_wrapper(
            benefits.summary,
        )
