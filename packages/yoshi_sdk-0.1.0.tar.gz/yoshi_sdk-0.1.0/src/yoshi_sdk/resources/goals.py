# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import goal_list_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.goal_list_response import GoalListResponse

__all__ = ["GoalsResource", "AsyncGoalsResource"]


class GoalsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> GoalsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return GoalsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> GoalsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return GoalsResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        status: Literal["active", "paused", "completed", "cancelled"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GoalListResponse:
        """
        List financial goals with optional status filter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/goals",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"status": status}, goal_list_params.GoalListParams),
            ),
            cast_to=GoalListResponse,
        )


class AsyncGoalsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncGoalsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return AsyncGoalsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncGoalsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return AsyncGoalsResourceWithStreamingResponse(self)

    async def list(
        self,
        *,
        status: Literal["active", "paused", "completed", "cancelled"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GoalListResponse:
        """
        List financial goals with optional status filter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/goals",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"status": status}, goal_list_params.GoalListParams),
            ),
            cast_to=GoalListResponse,
        )


class GoalsResourceWithRawResponse:
    def __init__(self, goals: GoalsResource) -> None:
        self._goals = goals

        self.list = to_raw_response_wrapper(
            goals.list,
        )


class AsyncGoalsResourceWithRawResponse:
    def __init__(self, goals: AsyncGoalsResource) -> None:
        self._goals = goals

        self.list = async_to_raw_response_wrapper(
            goals.list,
        )


class GoalsResourceWithStreamingResponse:
    def __init__(self, goals: GoalsResource) -> None:
        self._goals = goals

        self.list = to_streamed_response_wrapper(
            goals.list,
        )


class AsyncGoalsResourceWithStreamingResponse:
    def __init__(self, goals: AsyncGoalsResource) -> None:
        self._goals = goals

        self.list = async_to_streamed_response_wrapper(
            goals.list,
        )
