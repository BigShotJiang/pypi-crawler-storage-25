# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.accounts import balance_series_list_params
from ...types.accounts.balance_series_list_response import BalanceSeriesListResponse

__all__ = ["BalanceSeriesResource", "AsyncBalanceSeriesResource"]


class BalanceSeriesResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> BalanceSeriesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return BalanceSeriesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> BalanceSeriesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return BalanceSeriesResourceWithStreamingResponse(self)

    def list(
        self,
        id: str,
        *,
        days: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BalanceSeriesListResponse:
        """
        Get historical daily balance series for an account.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/accounts/{id}/balances", id=id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"days": days}, balance_series_list_params.BalanceSeriesListParams),
            ),
            cast_to=BalanceSeriesListResponse,
        )


class AsyncBalanceSeriesResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncBalanceSeriesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return AsyncBalanceSeriesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncBalanceSeriesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return AsyncBalanceSeriesResourceWithStreamingResponse(self)

    async def list(
        self,
        id: str,
        *,
        days: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BalanceSeriesListResponse:
        """
        Get historical daily balance series for an account.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/accounts/{id}/balances", id=id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"days": days}, balance_series_list_params.BalanceSeriesListParams),
            ),
            cast_to=BalanceSeriesListResponse,
        )


class BalanceSeriesResourceWithRawResponse:
    def __init__(self, balance_series: BalanceSeriesResource) -> None:
        self._balance_series = balance_series

        self.list = to_raw_response_wrapper(
            balance_series.list,
        )


class AsyncBalanceSeriesResourceWithRawResponse:
    def __init__(self, balance_series: AsyncBalanceSeriesResource) -> None:
        self._balance_series = balance_series

        self.list = async_to_raw_response_wrapper(
            balance_series.list,
        )


class BalanceSeriesResourceWithStreamingResponse:
    def __init__(self, balance_series: BalanceSeriesResource) -> None:
        self._balance_series = balance_series

        self.list = to_streamed_response_wrapper(
            balance_series.list,
        )


class AsyncBalanceSeriesResourceWithStreamingResponse:
    def __init__(self, balance_series: AsyncBalanceSeriesResource) -> None:
        self._balance_series = balance_series

        self.list = async_to_streamed_response_wrapper(
            balance_series.list,
        )
