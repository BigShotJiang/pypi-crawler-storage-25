# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from .accounts.accounts import (
    AccountsResource,
    AsyncAccountsResource,
    AccountsResourceWithRawResponse,
    AsyncAccountsResourceWithRawResponse,
    AccountsResourceWithStreamingResponse,
    AsyncAccountsResourceWithStreamingResponse,
)

__all__ = ["PaperTradingResource", "AsyncPaperTradingResource"]


class PaperTradingResource(SyncAPIResource):
    @cached_property
    def accounts(self) -> AccountsResource:
        return AccountsResource(self._client)

    @cached_property
    def with_raw_response(self) -> PaperTradingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return PaperTradingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PaperTradingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return PaperTradingResourceWithStreamingResponse(self)


class AsyncPaperTradingResource(AsyncAPIResource):
    @cached_property
    def accounts(self) -> AsyncAccountsResource:
        return AsyncAccountsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncPaperTradingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#accessing-raw-response-data-eg-headers
        """
        return AsyncPaperTradingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPaperTradingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/yoshi-ai-dev/yoshi-python#with_streaming_response
        """
        return AsyncPaperTradingResourceWithStreamingResponse(self)


class PaperTradingResourceWithRawResponse:
    def __init__(self, paper_trading: PaperTradingResource) -> None:
        self._paper_trading = paper_trading

    @cached_property
    def accounts(self) -> AccountsResourceWithRawResponse:
        return AccountsResourceWithRawResponse(self._paper_trading.accounts)


class AsyncPaperTradingResourceWithRawResponse:
    def __init__(self, paper_trading: AsyncPaperTradingResource) -> None:
        self._paper_trading = paper_trading

    @cached_property
    def accounts(self) -> AsyncAccountsResourceWithRawResponse:
        return AsyncAccountsResourceWithRawResponse(self._paper_trading.accounts)


class PaperTradingResourceWithStreamingResponse:
    def __init__(self, paper_trading: PaperTradingResource) -> None:
        self._paper_trading = paper_trading

    @cached_property
    def accounts(self) -> AccountsResourceWithStreamingResponse:
        return AccountsResourceWithStreamingResponse(self._paper_trading.accounts)


class AsyncPaperTradingResourceWithStreamingResponse:
    def __init__(self, paper_trading: AsyncPaperTradingResource) -> None:
        self._paper_trading = paper_trading

    @cached_property
    def accounts(self) -> AsyncAccountsResourceWithStreamingResponse:
        return AsyncAccountsResourceWithStreamingResponse(self._paper_trading.accounts)
