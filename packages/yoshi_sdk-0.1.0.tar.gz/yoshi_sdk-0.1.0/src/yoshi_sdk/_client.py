# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Dict, Mapping, cast
from typing_extensions import Self, Literal, override

import httpx

from . import _exceptions
from ._qs import Querystring
from ._types import (
    Omit,
    Timeout,
    NotGiven,
    Transport,
    ProxiesTypes,
    RequestOptions,
    not_given,
)
from ._utils import is_given, get_async_library
from ._compat import cached_property
from ._models import SecurityOptions
from ._version import __version__
from ._streaming import Stream as Stream, AsyncStream as AsyncStream
from ._exceptions import YoshiError, APIStatusError
from ._base_client import (
    DEFAULT_MAX_RETRIES,
    SyncAPIClient,
    AsyncAPIClient,
)

if TYPE_CHECKING:
    from .resources import (
        me,
        goals,
        income,
        scores,
        accounts,
        benefits,
        approvals,
        recurring,
        investments,
        transactions,
        paper_trading,
    )
    from .resources.me import MeResource, AsyncMeResource
    from .resources.goals import GoalsResource, AsyncGoalsResource
    from .resources.income import IncomeResource, AsyncIncomeResource
    from .resources.scores import ScoresResource, AsyncScoresResource
    from .resources.benefits import BenefitsResource, AsyncBenefitsResource
    from .resources.approvals import ApprovalsResource, AsyncApprovalsResource
    from .resources.recurring import RecurringResource, AsyncRecurringResource
    from .resources.investments import InvestmentsResource, AsyncInvestmentsResource
    from .resources.transactions import TransactionsResource, AsyncTransactionsResource
    from .resources.accounts.accounts import AccountsResource, AsyncAccountsResource
    from .resources.paper_trading.paper_trading import PaperTradingResource, AsyncPaperTradingResource

__all__ = [
    "ENVIRONMENTS",
    "Timeout",
    "Transport",
    "ProxiesTypes",
    "RequestOptions",
    "Yoshi",
    "AsyncYoshi",
    "Client",
    "AsyncClient",
]

ENVIRONMENTS: Dict[str, str] = {
    "production": "https://api.yoshi.ai/v1",
    "staging": "https://staging-api.yoshi.ai/v1",
}


class Yoshi(SyncAPIClient):
    # client options
    api_key: str

    _environment: Literal["production", "staging"] | NotGiven

    def __init__(
        self,
        *,
        api_key: str | None = None,
        environment: Literal["production", "staging"] | NotGiven = not_given,
        base_url: str | httpx.URL | None | NotGiven = not_given,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#client) for more details.
        http_client: httpx.Client | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new synchronous Yoshi client instance.

        This automatically infers the `api_key` argument from the `YOSHI_API_KEY` environment variable if it is not provided.
        """
        if api_key is None:
            api_key = os.environ.get("YOSHI_API_KEY")
        if api_key is None:
            raise YoshiError(
                "The api_key client option must be set either by passing api_key to the client or by setting the YOSHI_API_KEY environment variable"
            )
        self.api_key = api_key

        self._environment = environment

        base_url_env = os.environ.get("YOSHI_BASE_URL")
        if is_given(base_url) and base_url is not None:
            # cast required because mypy doesn't understand the type narrowing
            base_url = cast("str | httpx.URL", base_url)  # pyright: ignore[reportUnnecessaryCast]
        elif is_given(environment):
            if base_url_env and base_url is not None:
                raise ValueError(
                    "Ambiguous URL; The `YOSHI_BASE_URL` env var and the `environment` argument are given. If you want to use the environment, you must pass base_url=None",
                )

            try:
                base_url = ENVIRONMENTS[environment]
            except KeyError as exc:
                raise ValueError(f"Unknown environment: {environment}") from exc
        elif base_url_env is not None:
            base_url = base_url_env
        else:
            self._environment = environment = "production"

            try:
                base_url = ENVIRONMENTS[environment]
            except KeyError as exc:
                raise ValueError(f"Unknown environment: {environment}") from exc

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

        self._idempotency_header = "Idempotency-Key"

    @cached_property
    def accounts(self) -> AccountsResource:
        from .resources.accounts import AccountsResource

        return AccountsResource(self)

    @cached_property
    def transactions(self) -> TransactionsResource:
        from .resources.transactions import TransactionsResource

        return TransactionsResource(self)

    @cached_property
    def scores(self) -> ScoresResource:
        from .resources.scores import ScoresResource

        return ScoresResource(self)

    @cached_property
    def goals(self) -> GoalsResource:
        from .resources.goals import GoalsResource

        return GoalsResource(self)

    @cached_property
    def recurring(self) -> RecurringResource:
        from .resources.recurring import RecurringResource

        return RecurringResource(self)

    @cached_property
    def benefits(self) -> BenefitsResource:
        from .resources.benefits import BenefitsResource

        return BenefitsResource(self)

    @cached_property
    def investments(self) -> InvestmentsResource:
        from .resources.investments import InvestmentsResource

        return InvestmentsResource(self)

    @cached_property
    def income(self) -> IncomeResource:
        from .resources.income import IncomeResource

        return IncomeResource(self)

    @cached_property
    def me(self) -> MeResource:
        from .resources.me import MeResource

        return MeResource(self)

    @cached_property
    def paper_trading(self) -> PaperTradingResource:
        from .resources.paper_trading import PaperTradingResource

        return PaperTradingResource(self)

    @cached_property
    def approvals(self) -> ApprovalsResource:
        from .resources.approvals import ApprovalsResource

        return ApprovalsResource(self)

    @cached_property
    def with_raw_response(self) -> YoshiWithRawResponse:
        return YoshiWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> YoshiWithStreamedResponse:
        return YoshiWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @override
    def _auth_headers(self, security: SecurityOptions) -> dict[str, str]:
        return {
            **(self._bearer_auth if security.get("bearer_auth", False) else {}),
        }

    @property
    def _bearer_auth(self) -> dict[str, str]:
        api_key = self.api_key
        return {"Authorization": f"Bearer {api_key}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": "false",
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        environment: Literal["production", "staging"] | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.Client | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            base_url=base_url or self.base_url,
            environment=environment or self._environment,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class AsyncYoshi(AsyncAPIClient):
    # client options
    api_key: str

    _environment: Literal["production", "staging"] | NotGiven

    def __init__(
        self,
        *,
        api_key: str | None = None,
        environment: Literal["production", "staging"] | NotGiven = not_given,
        base_url: str | httpx.URL | None | NotGiven = not_given,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultAsyncHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#asyncclient) for more details.
        http_client: httpx.AsyncClient | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new async AsyncYoshi client instance.

        This automatically infers the `api_key` argument from the `YOSHI_API_KEY` environment variable if it is not provided.
        """
        if api_key is None:
            api_key = os.environ.get("YOSHI_API_KEY")
        if api_key is None:
            raise YoshiError(
                "The api_key client option must be set either by passing api_key to the client or by setting the YOSHI_API_KEY environment variable"
            )
        self.api_key = api_key

        self._environment = environment

        base_url_env = os.environ.get("YOSHI_BASE_URL")
        if is_given(base_url) and base_url is not None:
            # cast required because mypy doesn't understand the type narrowing
            base_url = cast("str | httpx.URL", base_url)  # pyright: ignore[reportUnnecessaryCast]
        elif is_given(environment):
            if base_url_env and base_url is not None:
                raise ValueError(
                    "Ambiguous URL; The `YOSHI_BASE_URL` env var and the `environment` argument are given. If you want to use the environment, you must pass base_url=None",
                )

            try:
                base_url = ENVIRONMENTS[environment]
            except KeyError as exc:
                raise ValueError(f"Unknown environment: {environment}") from exc
        elif base_url_env is not None:
            base_url = base_url_env
        else:
            self._environment = environment = "production"

            try:
                base_url = ENVIRONMENTS[environment]
            except KeyError as exc:
                raise ValueError(f"Unknown environment: {environment}") from exc

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

        self._idempotency_header = "Idempotency-Key"

    @cached_property
    def accounts(self) -> AsyncAccountsResource:
        from .resources.accounts import AsyncAccountsResource

        return AsyncAccountsResource(self)

    @cached_property
    def transactions(self) -> AsyncTransactionsResource:
        from .resources.transactions import AsyncTransactionsResource

        return AsyncTransactionsResource(self)

    @cached_property
    def scores(self) -> AsyncScoresResource:
        from .resources.scores import AsyncScoresResource

        return AsyncScoresResource(self)

    @cached_property
    def goals(self) -> AsyncGoalsResource:
        from .resources.goals import AsyncGoalsResource

        return AsyncGoalsResource(self)

    @cached_property
    def recurring(self) -> AsyncRecurringResource:
        from .resources.recurring import AsyncRecurringResource

        return AsyncRecurringResource(self)

    @cached_property
    def benefits(self) -> AsyncBenefitsResource:
        from .resources.benefits import AsyncBenefitsResource

        return AsyncBenefitsResource(self)

    @cached_property
    def investments(self) -> AsyncInvestmentsResource:
        from .resources.investments import AsyncInvestmentsResource

        return AsyncInvestmentsResource(self)

    @cached_property
    def income(self) -> AsyncIncomeResource:
        from .resources.income import AsyncIncomeResource

        return AsyncIncomeResource(self)

    @cached_property
    def me(self) -> AsyncMeResource:
        from .resources.me import AsyncMeResource

        return AsyncMeResource(self)

    @cached_property
    def paper_trading(self) -> AsyncPaperTradingResource:
        from .resources.paper_trading import AsyncPaperTradingResource

        return AsyncPaperTradingResource(self)

    @cached_property
    def approvals(self) -> AsyncApprovalsResource:
        from .resources.approvals import AsyncApprovalsResource

        return AsyncApprovalsResource(self)

    @cached_property
    def with_raw_response(self) -> AsyncYoshiWithRawResponse:
        return AsyncYoshiWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncYoshiWithStreamedResponse:
        return AsyncYoshiWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @override
    def _auth_headers(self, security: SecurityOptions) -> dict[str, str]:
        return {
            **(self._bearer_auth if security.get("bearer_auth", False) else {}),
        }

    @property
    def _bearer_auth(self) -> dict[str, str]:
        api_key = self.api_key
        return {"Authorization": f"Bearer {api_key}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": f"async:{get_async_library()}",
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        environment: Literal["production", "staging"] | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.AsyncClient | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            base_url=base_url or self.base_url,
            environment=environment or self._environment,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class YoshiWithRawResponse:
    _client: Yoshi

    def __init__(self, client: Yoshi) -> None:
        self._client = client

    @cached_property
    def accounts(self) -> accounts.AccountsResourceWithRawResponse:
        from .resources.accounts import AccountsResourceWithRawResponse

        return AccountsResourceWithRawResponse(self._client.accounts)

    @cached_property
    def transactions(self) -> transactions.TransactionsResourceWithRawResponse:
        from .resources.transactions import TransactionsResourceWithRawResponse

        return TransactionsResourceWithRawResponse(self._client.transactions)

    @cached_property
    def scores(self) -> scores.ScoresResourceWithRawResponse:
        from .resources.scores import ScoresResourceWithRawResponse

        return ScoresResourceWithRawResponse(self._client.scores)

    @cached_property
    def goals(self) -> goals.GoalsResourceWithRawResponse:
        from .resources.goals import GoalsResourceWithRawResponse

        return GoalsResourceWithRawResponse(self._client.goals)

    @cached_property
    def recurring(self) -> recurring.RecurringResourceWithRawResponse:
        from .resources.recurring import RecurringResourceWithRawResponse

        return RecurringResourceWithRawResponse(self._client.recurring)

    @cached_property
    def benefits(self) -> benefits.BenefitsResourceWithRawResponse:
        from .resources.benefits import BenefitsResourceWithRawResponse

        return BenefitsResourceWithRawResponse(self._client.benefits)

    @cached_property
    def investments(self) -> investments.InvestmentsResourceWithRawResponse:
        from .resources.investments import InvestmentsResourceWithRawResponse

        return InvestmentsResourceWithRawResponse(self._client.investments)

    @cached_property
    def income(self) -> income.IncomeResourceWithRawResponse:
        from .resources.income import IncomeResourceWithRawResponse

        return IncomeResourceWithRawResponse(self._client.income)

    @cached_property
    def me(self) -> me.MeResourceWithRawResponse:
        from .resources.me import MeResourceWithRawResponse

        return MeResourceWithRawResponse(self._client.me)

    @cached_property
    def paper_trading(self) -> paper_trading.PaperTradingResourceWithRawResponse:
        from .resources.paper_trading import PaperTradingResourceWithRawResponse

        return PaperTradingResourceWithRawResponse(self._client.paper_trading)

    @cached_property
    def approvals(self) -> approvals.ApprovalsResourceWithRawResponse:
        from .resources.approvals import ApprovalsResourceWithRawResponse

        return ApprovalsResourceWithRawResponse(self._client.approvals)


class AsyncYoshiWithRawResponse:
    _client: AsyncYoshi

    def __init__(self, client: AsyncYoshi) -> None:
        self._client = client

    @cached_property
    def accounts(self) -> accounts.AsyncAccountsResourceWithRawResponse:
        from .resources.accounts import AsyncAccountsResourceWithRawResponse

        return AsyncAccountsResourceWithRawResponse(self._client.accounts)

    @cached_property
    def transactions(self) -> transactions.AsyncTransactionsResourceWithRawResponse:
        from .resources.transactions import AsyncTransactionsResourceWithRawResponse

        return AsyncTransactionsResourceWithRawResponse(self._client.transactions)

    @cached_property
    def scores(self) -> scores.AsyncScoresResourceWithRawResponse:
        from .resources.scores import AsyncScoresResourceWithRawResponse

        return AsyncScoresResourceWithRawResponse(self._client.scores)

    @cached_property
    def goals(self) -> goals.AsyncGoalsResourceWithRawResponse:
        from .resources.goals import AsyncGoalsResourceWithRawResponse

        return AsyncGoalsResourceWithRawResponse(self._client.goals)

    @cached_property
    def recurring(self) -> recurring.AsyncRecurringResourceWithRawResponse:
        from .resources.recurring import AsyncRecurringResourceWithRawResponse

        return AsyncRecurringResourceWithRawResponse(self._client.recurring)

    @cached_property
    def benefits(self) -> benefits.AsyncBenefitsResourceWithRawResponse:
        from .resources.benefits import AsyncBenefitsResourceWithRawResponse

        return AsyncBenefitsResourceWithRawResponse(self._client.benefits)

    @cached_property
    def investments(self) -> investments.AsyncInvestmentsResourceWithRawResponse:
        from .resources.investments import AsyncInvestmentsResourceWithRawResponse

        return AsyncInvestmentsResourceWithRawResponse(self._client.investments)

    @cached_property
    def income(self) -> income.AsyncIncomeResourceWithRawResponse:
        from .resources.income import AsyncIncomeResourceWithRawResponse

        return AsyncIncomeResourceWithRawResponse(self._client.income)

    @cached_property
    def me(self) -> me.AsyncMeResourceWithRawResponse:
        from .resources.me import AsyncMeResourceWithRawResponse

        return AsyncMeResourceWithRawResponse(self._client.me)

    @cached_property
    def paper_trading(self) -> paper_trading.AsyncPaperTradingResourceWithRawResponse:
        from .resources.paper_trading import AsyncPaperTradingResourceWithRawResponse

        return AsyncPaperTradingResourceWithRawResponse(self._client.paper_trading)

    @cached_property
    def approvals(self) -> approvals.AsyncApprovalsResourceWithRawResponse:
        from .resources.approvals import AsyncApprovalsResourceWithRawResponse

        return AsyncApprovalsResourceWithRawResponse(self._client.approvals)


class YoshiWithStreamedResponse:
    _client: Yoshi

    def __init__(self, client: Yoshi) -> None:
        self._client = client

    @cached_property
    def accounts(self) -> accounts.AccountsResourceWithStreamingResponse:
        from .resources.accounts import AccountsResourceWithStreamingResponse

        return AccountsResourceWithStreamingResponse(self._client.accounts)

    @cached_property
    def transactions(self) -> transactions.TransactionsResourceWithStreamingResponse:
        from .resources.transactions import TransactionsResourceWithStreamingResponse

        return TransactionsResourceWithStreamingResponse(self._client.transactions)

    @cached_property
    def scores(self) -> scores.ScoresResourceWithStreamingResponse:
        from .resources.scores import ScoresResourceWithStreamingResponse

        return ScoresResourceWithStreamingResponse(self._client.scores)

    @cached_property
    def goals(self) -> goals.GoalsResourceWithStreamingResponse:
        from .resources.goals import GoalsResourceWithStreamingResponse

        return GoalsResourceWithStreamingResponse(self._client.goals)

    @cached_property
    def recurring(self) -> recurring.RecurringResourceWithStreamingResponse:
        from .resources.recurring import RecurringResourceWithStreamingResponse

        return RecurringResourceWithStreamingResponse(self._client.recurring)

    @cached_property
    def benefits(self) -> benefits.BenefitsResourceWithStreamingResponse:
        from .resources.benefits import BenefitsResourceWithStreamingResponse

        return BenefitsResourceWithStreamingResponse(self._client.benefits)

    @cached_property
    def investments(self) -> investments.InvestmentsResourceWithStreamingResponse:
        from .resources.investments import InvestmentsResourceWithStreamingResponse

        return InvestmentsResourceWithStreamingResponse(self._client.investments)

    @cached_property
    def income(self) -> income.IncomeResourceWithStreamingResponse:
        from .resources.income import IncomeResourceWithStreamingResponse

        return IncomeResourceWithStreamingResponse(self._client.income)

    @cached_property
    def me(self) -> me.MeResourceWithStreamingResponse:
        from .resources.me import MeResourceWithStreamingResponse

        return MeResourceWithStreamingResponse(self._client.me)

    @cached_property
    def paper_trading(self) -> paper_trading.PaperTradingResourceWithStreamingResponse:
        from .resources.paper_trading import PaperTradingResourceWithStreamingResponse

        return PaperTradingResourceWithStreamingResponse(self._client.paper_trading)

    @cached_property
    def approvals(self) -> approvals.ApprovalsResourceWithStreamingResponse:
        from .resources.approvals import ApprovalsResourceWithStreamingResponse

        return ApprovalsResourceWithStreamingResponse(self._client.approvals)


class AsyncYoshiWithStreamedResponse:
    _client: AsyncYoshi

    def __init__(self, client: AsyncYoshi) -> None:
        self._client = client

    @cached_property
    def accounts(self) -> accounts.AsyncAccountsResourceWithStreamingResponse:
        from .resources.accounts import AsyncAccountsResourceWithStreamingResponse

        return AsyncAccountsResourceWithStreamingResponse(self._client.accounts)

    @cached_property
    def transactions(self) -> transactions.AsyncTransactionsResourceWithStreamingResponse:
        from .resources.transactions import AsyncTransactionsResourceWithStreamingResponse

        return AsyncTransactionsResourceWithStreamingResponse(self._client.transactions)

    @cached_property
    def scores(self) -> scores.AsyncScoresResourceWithStreamingResponse:
        from .resources.scores import AsyncScoresResourceWithStreamingResponse

        return AsyncScoresResourceWithStreamingResponse(self._client.scores)

    @cached_property
    def goals(self) -> goals.AsyncGoalsResourceWithStreamingResponse:
        from .resources.goals import AsyncGoalsResourceWithStreamingResponse

        return AsyncGoalsResourceWithStreamingResponse(self._client.goals)

    @cached_property
    def recurring(self) -> recurring.AsyncRecurringResourceWithStreamingResponse:
        from .resources.recurring import AsyncRecurringResourceWithStreamingResponse

        return AsyncRecurringResourceWithStreamingResponse(self._client.recurring)

    @cached_property
    def benefits(self) -> benefits.AsyncBenefitsResourceWithStreamingResponse:
        from .resources.benefits import AsyncBenefitsResourceWithStreamingResponse

        return AsyncBenefitsResourceWithStreamingResponse(self._client.benefits)

    @cached_property
    def investments(self) -> investments.AsyncInvestmentsResourceWithStreamingResponse:
        from .resources.investments import AsyncInvestmentsResourceWithStreamingResponse

        return AsyncInvestmentsResourceWithStreamingResponse(self._client.investments)

    @cached_property
    def income(self) -> income.AsyncIncomeResourceWithStreamingResponse:
        from .resources.income import AsyncIncomeResourceWithStreamingResponse

        return AsyncIncomeResourceWithStreamingResponse(self._client.income)

    @cached_property
    def me(self) -> me.AsyncMeResourceWithStreamingResponse:
        from .resources.me import AsyncMeResourceWithStreamingResponse

        return AsyncMeResourceWithStreamingResponse(self._client.me)

    @cached_property
    def paper_trading(self) -> paper_trading.AsyncPaperTradingResourceWithStreamingResponse:
        from .resources.paper_trading import AsyncPaperTradingResourceWithStreamingResponse

        return AsyncPaperTradingResourceWithStreamingResponse(self._client.paper_trading)

    @cached_property
    def approvals(self) -> approvals.AsyncApprovalsResourceWithStreamingResponse:
        from .resources.approvals import AsyncApprovalsResourceWithStreamingResponse

        return AsyncApprovalsResourceWithStreamingResponse(self._client.approvals)


Client = Yoshi

AsyncClient = AsyncYoshi
