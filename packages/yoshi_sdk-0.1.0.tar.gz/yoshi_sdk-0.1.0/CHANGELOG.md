# Changelog

## 0.1.0 (2026-04-15)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/yoshi-ai-dev/yoshi-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** add benefits endpoints, approval_status_url field, update transaction types ([edd049b](https://github.com/yoshi-ai-dev/yoshi-python/commit/edd049baf7883bff4946e24e1c50ff410dc42be1))
* **api:** add hidden param to accounts/me, fields to paper_trading/transaction responses ([0741186](https://github.com/yoshi-ai-dev/yoshi-python/commit/07411862a0871ca58ceb231f3e667632894b625e))
* **api:** add hidden parameter to accounts.list and me.summary ([a1751ee](https://github.com/yoshi-ai-dev/yoshi-python/commit/a1751ee51806ba423b1057fcbaced6880d2de952))
* **api:** api update ([3e63be0](https://github.com/yoshi-ai-dev/yoshi-python/commit/3e63be0cfe23414ec5a265145edc04de10e5d1a4))
* **api:** api update ([50db2b2](https://github.com/yoshi-ai-dev/yoshi-python/commit/50db2b25db07df0cd820b75f5eff9dd6bf2cfdd6))
* **api:** api update ([e21187c](https://github.com/yoshi-ai-dev/yoshi-python/commit/e21187c397637327edb770f10cb416e913af4b48))
* **api:** api update ([ca78eb3](https://github.com/yoshi-ai-dev/yoshi-python/commit/ca78eb34a7b26d905c137301d10f9db027cb373f))


### Bug Fixes

* **api:** remove auto-pagination from transactions/trades list methods, update response types ([f7ddf77](https://github.com/yoshi-ai-dev/yoshi-python/commit/f7ddf77c9754109dadfef8f39883c7b6d2bb5552))


### Chores

* Auto OpenAPI Spec ([13e39c1](https://github.com/yoshi-ai-dev/yoshi-python/commit/13e39c1c336a5455b2cb20ae73d132a2cdeeb199))
* **internal:** regenerate SDK with no functional changes ([9d9fb95](https://github.com/yoshi-ai-dev/yoshi-python/commit/9d9fb95fcd8fc1b79e8b476fbf9146c252f94344))
* update SDK settings ([58a4ea9](https://github.com/yoshi-ai-dev/yoshi-python/commit/58a4ea91f9d117e67e1c91c82b6ea390533d171f))
* update SDK settings ([50c5de7](https://github.com/yoshi-ai-dev/yoshi-python/commit/50c5de7678507411f19df04fd6fd052b8b3127c5))
* update SDK settings ([874253e](https://github.com/yoshi-ai-dev/yoshi-python/commit/874253ee71bf549340037e5bd0f703d8ea1ccfa7))
* update SDK settings ([3266753](https://github.com/yoshi-ai-dev/yoshi-python/commit/32667530e5796486822bbdcae9ef166a14cd8323))
* update SDK settings ([4fc5b6b](https://github.com/yoshi-ai-dev/yoshi-python/commit/4fc5b6baeefead5639cd0f17ca347589371b2b4c))
