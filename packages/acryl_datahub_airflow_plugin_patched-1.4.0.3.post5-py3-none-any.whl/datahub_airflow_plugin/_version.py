# Published at https://pypi.org/project/acryl-datahub-airflow-plugin-patched/.
__package_name__ = "acryl-datahub-airflow-plugin-patched"
__version__ = "1.4.0.3.post5"
