"""AWS Secrets Manager utilities."""

from __future__ import annotations

import asyncio

import structlog

logger = structlog.get_logger(__name__)


async def fetch_secret(secret_id: str, region: str = "ap-south-1") -> str:
    """Fetch a plaintext secret string from AWS Secrets Manager.

    Runs the boto3 call in a thread so it is safe to await from async code.

    Args:
        secret_id: The secret name or ARN.
        region: AWS region for the Secrets Manager endpoint.

    Returns:
        The secret value as a plain string.

    Raises:
        RuntimeError: If the secret cannot be retrieved or is empty/binary.
    """
    import boto3
    from botocore.exceptions import ClientError

    def _get() -> str:
        client = boto3.client("secretsmanager", region_name=region)
        try:
            resp = client.get_secret_value(SecretId=secret_id)
        except ClientError as exc:
            raise RuntimeError(
                f"Failed to fetch secret '{secret_id}' from Secrets Manager: {exc}"
            ) from exc
        value: str = resp.get("SecretString") or ""
        if not value:
            raise RuntimeError(
                f"Secret '{secret_id}' is empty or binary — expected a plaintext string"
            )
        return value

    logger.debug("secrets_manager_fetch", secret_id=secret_id, region=region)
    return await asyncio.to_thread(_get)
