from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from pulse_engine.pipeline.schemas import PipelineConfig, StepStatus


@dataclass
class PipelineStatus:
    status: str  # pending, running, completed, failed, cancelled
    started_at: str | None = None
    steps: list[StepStatus] = field(default_factory=list)


class BaseTranslator(ABC):
    @abstractmethod
    async def submit(
        self,
        pipeline_run_id: str,
        parsed_config: PipelineConfig,
        module_images: dict[str, str],
        global_config: dict[str, Any],
        tenant_id: str,
        pulse_engine_url: str,
        pulse_api_token: str,
    ) -> str:
        """Submit pipeline to orchestrator. Returns orchestrator's native run ID."""
        ...


class BaseStatusProvider(ABC):
    @abstractmethod
    async def get_status(self, orchestrator_run_id: str) -> PipelineStatus:
        """Query orchestrator and return normalized status."""
        ...

    @abstractmethod
    async def cancel(self, orchestrator_run_id: str) -> bool:
        """Cancel a running pipeline. Returns True if successfully cancelled."""
        ...
