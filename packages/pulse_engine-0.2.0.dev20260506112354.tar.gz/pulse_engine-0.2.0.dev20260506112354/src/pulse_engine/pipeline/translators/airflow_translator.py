from __future__ import annotations

from typing import Any

from pulse_engine.pipeline.schemas import PipelineConfig
from pulse_engine.pipeline.translators.base import BaseTranslator


class AirflowTranslator(BaseTranslator):
    async def submit(
        self,
        pipeline_run_id: str,
        parsed_config: PipelineConfig,
        module_images: dict[str, str],
        global_config: dict[str, Any],
        tenant_id: str,
        pulse_engine_url: str,
        pulse_api_token: str,
    ) -> str:
        raise NotImplementedError(
            "Airflow translator is not yet implemented. Use orchestrator='prefect'."
        )
