from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from pulse_engine.pipeline.models import (
    ModuleRegistryModel,
    PipelineRunModel,
    PipelineStepRunModel,
)


class ModuleRegistryRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def upsert(
        self, tenant_id: str, product: str, module_name: str, image: str
    ) -> ModuleRegistryModel:
        existing = await self.get(tenant_id, product, module_name)
        if existing:
            existing.image = image
            await self._session.flush()
            return existing

        model = ModuleRegistryModel(
            id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            product=product,
            module_name=module_name,
            image=image,
        )
        self._session.add(model)
        await self._session.flush()
        return model

    async def get(
        self, tenant_id: str, product: str, module_name: str
    ) -> ModuleRegistryModel | None:
        stmt = select(ModuleRegistryModel).where(
            ModuleRegistryModel.tenant_id == tenant_id,
            ModuleRegistryModel.product == product,
            ModuleRegistryModel.module_name == module_name,
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_by_product(
        self, tenant_id: str, product: str
    ) -> list[ModuleRegistryModel]:
        stmt = select(ModuleRegistryModel).where(
            ModuleRegistryModel.tenant_id == tenant_id,
            ModuleRegistryModel.product == product,
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    async def get_images_map(self, tenant_id: str, product: str) -> dict[str, str]:
        modules = await self.list_by_product(tenant_id, product)
        return {m.module_name: m.image for m in modules}

    async def delete(self, tenant_id: str, product: str, module_name: str) -> bool:
        stmt = delete(ModuleRegistryModel).where(
            ModuleRegistryModel.tenant_id == tenant_id,
            ModuleRegistryModel.product == product,
            ModuleRegistryModel.module_name == module_name,
        )
        result = await self._session.execute(stmt)
        await self._session.flush()
        return bool(getattr(result, "rowcount", 0) > 0)


class PipelineRunRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create(
        self,
        tenant_id: str,
        product: str,
        orchestrator: str,
        config_snapshot: dict[str, Any],
        global_config: dict[str, Any],
    ) -> PipelineRunModel:
        model = PipelineRunModel(
            id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            product=product,
            orchestrator=orchestrator,
            config_snapshot=config_snapshot,
            global_config=global_config,
            status="pending",
        )
        self._session.add(model)
        await self._session.flush()
        return model

    async def get(self, run_id: str, tenant_id: str) -> PipelineRunModel | None:
        stmt = select(PipelineRunModel).where(
            PipelineRunModel.id == run_id,
            PipelineRunModel.tenant_id == tenant_id,
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def update_status(self, run_id: str, status: str) -> None:
        stmt = select(PipelineRunModel).where(PipelineRunModel.id == run_id)
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        if model:
            model.status = status
            await self._session.flush()

    async def set_orchestrator_run_id(
        self, run_id: str, orchestrator_run_id: str
    ) -> None:
        stmt = select(PipelineRunModel).where(PipelineRunModel.id == run_id)
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        if model:
            model.orchestrator_run_id = orchestrator_run_id
            await self._session.flush()

    async def list_runs(
        self,
        tenant_id: str,
        product: str | None = None,
        status: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> tuple[list[PipelineRunModel], int]:
        stmt = select(PipelineRunModel).where(PipelineRunModel.tenant_id == tenant_id)
        count_stmt = (
            select(func.count())
            .select_from(PipelineRunModel)
            .where(PipelineRunModel.tenant_id == tenant_id)
        )

        if product:
            stmt = stmt.where(PipelineRunModel.product == product)
            count_stmt = count_stmt.where(PipelineRunModel.product == product)
        if status:
            stmt = stmt.where(PipelineRunModel.status == status)
            count_stmt = count_stmt.where(PipelineRunModel.status == status)

        stmt = stmt.order_by(PipelineRunModel.created_at.desc())
        stmt = stmt.limit(limit).offset(offset)

        result = await self._session.execute(stmt)
        count_result = await self._session.execute(count_stmt)

        return list(result.scalars().all()), count_result.scalar_one()


class PipelineStepRunRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def upsert(
        self,
        pipeline_run_id: str,
        tenant_id: str,
        step_name: str,
        module_type: str,
        status: str,
        started_at: datetime | None = None,
        completed_at: datetime | None = None,
        error_message: str | None = None,
        output_ref: dict[str, Any] | None = None,
    ) -> PipelineStepRunModel:
        stmt = select(PipelineStepRunModel).where(
            PipelineStepRunModel.pipeline_run_id == pipeline_run_id,
            PipelineStepRunModel.tenant_id == tenant_id,
            PipelineStepRunModel.step_name == step_name,
        )
        result = await self._session.execute(stmt)
        existing = result.scalar_one_or_none()

        if existing:
            existing.status = status
            if started_at is not None:
                existing.started_at = started_at
            if completed_at is not None:
                existing.completed_at = completed_at
            if error_message is not None:
                existing.error_message = error_message
            if output_ref is not None:
                existing.output_ref = output_ref
            await self._session.flush()
            return existing

        model = PipelineStepRunModel(
            id=str(uuid.uuid4()),
            pipeline_run_id=pipeline_run_id,
            tenant_id=tenant_id,
            step_name=step_name,
            module_type=module_type,
            status=status,
            started_at=started_at,
            completed_at=completed_at,
            error_message=error_message,
            output_ref=output_ref,
        )
        self._session.add(model)
        await self._session.flush()
        return model

    async def list_by_run(
        self, pipeline_run_id: str, tenant_id: str
    ) -> list[PipelineStepRunModel]:
        stmt = (
            select(PipelineStepRunModel)
            .where(
                PipelineStepRunModel.pipeline_run_id == pipeline_run_id,
                PipelineStepRunModel.tenant_id == tenant_id,
            )
            .order_by(PipelineStepRunModel.created_at)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())
