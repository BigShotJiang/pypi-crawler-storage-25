"""FastAPI endpoint tests using TestClient."""
from __future__ import annotations

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from evalgrid.api.app import app
from evalgrid.api.database import Base, get_db


@pytest.fixture()
def client(tmp_path):
    db_file = tmp_path / "test.db"
    engine = create_async_engine(f"sqlite+aiosqlite:///{db_file.as_posix()}")
    Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    async def override_get_db():
        async with Session() as session:
            yield session

    async def create_tables():
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    app.dependency_overrides[get_db] = override_get_db

    with patch("evalgrid.api.app.init_db", new=create_tables):
        with patch("evalgrid.api.database.SessionLocal", new=Session):
            with TestClient(app) as c:
                yield c

    app.dependency_overrides.clear()


def test_health_endpoint_returns_ok(client):
    # /health was enriched in Phase 4 of the v0.1.3 patch — version, DB
    # round-trip, resolved dirs. The original status:"ok" + 200 contract
    # must still hold for back-compat with anything pinging it.
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["db"] == "ok"
    assert "version" in body
    assert "scenarios_dir" in body


def test_get_runs_returns_empty_list_initially(client):
    response = client.get("/api/runs")
    assert response.status_code == 200
    assert response.json() == []


def test_post_run_without_api_key_returns_400_with_message(client, monkeypatch):
    # The API checks for a provider key when mock=False; absence → 400 with a useful message.
    # FIX 5: must specify a target (scenarios/suite/tag/mock) to get past the validator,
    # so we pass a tag to keep this test focused on the API-key path.
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    response = client.post("/api/runs", json={"mock": False, "tags": ["any"]})
    assert response.status_code == 400
    assert "API key" in response.json()["detail"]


def test_post_run_empty_body_returns_422(client, monkeypatch):
    """FIX 5: empty-body POST must fail with 422 before any side effects."""
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    response = client.post("/api/runs", json={})
    assert response.status_code == 422
    detail = response.json()["detail"]
    # FastAPI wraps validator errors; the original message must surface
    msg = detail if isinstance(detail, str) else " ".join(
        str(e.get("msg", "")) for e in (detail or [])
    )
    assert "scenarios, suite, tag, or mock" in msg


def test_post_run_mock_starts_run(client, tmp_path, monkeypatch):
    """POST /api/runs with mock=True should return a run_id with status 'running'."""
    scen_dir = tmp_path / "scenarios"
    scen_dir.mkdir(exist_ok=True)
    (scen_dir / "hello.yml").write_text(
        "id: hello-world\nname: Hello World\nprompt: Be helpful.\ntest_input: Say hello\n"
    )
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)

    response = client.post("/api/runs", json={"mock": True})
    assert response.status_code == 200
    data = response.json()
    assert "run_id" in data
    assert data["status"] == "running"


def test_post_run_path_traversal_returns_400(client):
    """POST /api/runs with a path traversal attempt should return 400."""
    response = client.post(
        "/api/runs",
        json={"mock": True, "scenarios_dir": "../../../etc"},
    )
    assert response.status_code == 400


def test_get_run_by_id_returns_404_for_unknown_id(client):
    response = client.get("/api/runs/00000000-0000-0000-0000-000000000000")
    assert response.status_code == 404


def test_post_run_no_csrf_required(client, tmp_path, monkeypatch):
    """POST /api/runs works without any CSRF header — CSRF removed in favour of CORS."""
    scen_dir = tmp_path / "scenarios"
    scen_dir.mkdir(exist_ok=True)
    (scen_dir / "hello.yml").write_text(
        "id: hello-world\nname: Hello World\nprompt: Be helpful.\ntest_input: Say hello\n"
    )
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)

    response = client.post("/api/runs", json={"mock": True})
    assert response.status_code == 200


def test_scenario_create_rejects_oversized_prompt(client):
    """POST /api/scenarios should reject prompts longer than 16 000 chars."""
    response = client.post(
        "/api/scenarios",
        json={
            "name": "big-scenario",
            "prompt": "x" * 16001,
            "test_input": "hello",
        },
    )
    assert response.status_code == 422


def test_scenario_create_rejects_oversized_test_input(client):
    """POST /api/scenarios should reject test_input longer than 8 000 chars."""
    response = client.post(
        "/api/scenarios",
        json={
            "name": "big-scenario",
            "prompt": "Be helpful.",
            "test_input": "x" * 8001,
        },
    )
    assert response.status_code == 422


def test_get_scenarios_returns_loaded_scenarios(client, tmp_path, monkeypatch):
    scen_dir = tmp_path / "scenarios"
    scen_dir.mkdir(exist_ok=True)
    (scen_dir / "hello.yml").write_text(
        "id: hello-world\nname: Hello World\nprompt: Be helpful.\ntest_input: Say hello\n"
    )
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)

    response = client.get("/api/scenarios")
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["id"] == "hello-world"
