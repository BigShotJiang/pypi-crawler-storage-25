"""Shared pytest fixtures for evalgrid tests."""
from __future__ import annotations

from unittest.mock import MagicMock

import pytest


@pytest.fixture
def tmp_scenarios_dir(tmp_path):
    d = tmp_path / "scenarios"
    d.mkdir()
    return d


@pytest.fixture
def mock_litellm_response():
    """Factory: call with a content string to get a fake litellm response object."""
    def _make(content: str):
        msg = MagicMock()
        msg.content = content
        choice = MagicMock()
        choice.message = msg
        resp = MagicMock()
        resp.choices = [choice]
        return resp
    return _make


@pytest.fixture
async def test_db():
    """Async session factory backed by an in-memory SQLite database."""
    from sqlalchemy.ext.asyncio import (
        AsyncSession,
        async_sessionmaker,
        create_async_engine,
    )

    from evalgrid.api.database import Base

    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    yield Session
    await engine.dispose()
