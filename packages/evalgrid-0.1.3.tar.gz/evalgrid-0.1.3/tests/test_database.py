"""Tests for database initialization and ORM models."""
from __future__ import annotations

import uuid
from datetime import UTC, datetime

import pytest
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from evalgrid.api.database import Base, RunRecord, ScenarioResultRecord


@pytest.fixture()
async def db_session():
    """In-memory async SQLite session for isolated database tests."""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with Session() as session:
        yield session
    await engine.dispose()


async def test_init_db_creates_tables(tmp_path):
    """init_db() should create the runs and scenario_results tables."""
    db_file = tmp_path / "test.db"
    engine = create_async_engine(f"sqlite+aiosqlite:///{db_file.as_posix()}")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    # If tables exist, querying them returns no rows without error
    Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with Session() as session:
        rows = await session.execute(select(RunRecord))
        assert rows.scalars().all() == []
    await engine.dispose()


async def test_run_record_can_be_created_and_queried(db_session: AsyncSession):
    """RunRecord should persist and be retrievable by run_id."""
    run_id = str(uuid.uuid4())
    record = RunRecord(
        run_id=run_id,
        started_at=datetime.now(UTC),
        results=[],
        passed=0,
        total=0,
        pass_rate=0.0,
    )
    db_session.add(record)
    await db_session.commit()

    row = await db_session.execute(select(RunRecord).where(RunRecord.run_id == run_id))
    fetched = row.scalar_one_or_none()
    assert fetched is not None
    assert fetched.run_id == run_id
    assert fetched.pass_rate == 0.0


async def test_scenario_result_record_linked_to_run(db_session: AsyncSession):
    """ScenarioResultRecord should store step data and link to its parent run."""
    run_id = str(uuid.uuid4())
    run = RunRecord(
        run_id=run_id,
        started_at=datetime.now(UTC),
        results=[],
        passed=1,
        total=1,
        pass_rate=1.0,
    )
    db_session.add(run)
    await db_session.flush()

    sr = ScenarioResultRecord(
        run_id=run_id,
        scenario_id="hello-world",
        scenario_name="Hello World",
        agent_type="generic",
        status="pass",
        overall_score=0.95,
        pass_rate=1.0,
        reasoning="Agent greeted correctly",
        steps=[{"step_index": 0, "action": "greet", "score": 0.95}],
        started_at=datetime.now(UTC),
    )
    db_session.add(sr)
    await db_session.commit()

    rows = await db_session.execute(
        select(ScenarioResultRecord).where(ScenarioResultRecord.run_id == run_id)
    )
    results = rows.scalars().all()
    assert len(results) == 1
    assert results[0].scenario_id == "hello-world"
    assert results[0].overall_score == 0.95
    assert len(results[0].steps) == 1
