"""Security primitive tests — API-key redaction, CORS allowlist,
global exception sanitization, stale-run cleanup."""
from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import patch

import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from evalgrid.api.app import _sanitize_error, app, lifespan
from evalgrid.api.database import Base, RunRecord, get_db
from evalgrid.core.runner import _API_KEY_RE


# ── 1. API-key redaction regex ─────────────────────────────────────────────────


@pytest.mark.parametrize("key", [
    "sk-ant-api01-ABCdef0123456789-_abcdef",
    "sk-proj-1234567890abcdef",
    "pypi-AgEIcHlwaS5vcmcCJDc",
    "AIzaSyA0123456789abcdefABCDEFghijklmnopqrs",
])
def test_api_key_redaction_regex_catches_common_prefixes(key):
    msg = f"Boom: provider rejected request, key={key}"
    sanitized = _sanitize_error(msg)
    assert key not in sanitized, f"Key leaked through sanitizer: {sanitized!r}"
    assert "[REDACTED]" in sanitized


def test_runner_api_key_regex_matches_same_prefixes():
    """The runner-side regex must match the same prefixes as the API-side one."""
    for key in [
        "sk-ant-abcdefghijklmnop",
        "sk-1234567890abcdef",
        "pypi-AgEIcHlwaS5vcmcCJDc",
    ]:
        assert _API_KEY_RE.search(f"err {key} end") is not None, f"Missed: {key}"


def test_redaction_leaves_normal_text_untouched():
    msg = "Scenario foo failed: connection refused"
    assert _sanitize_error(msg) == msg


# ── 2. CORS allowlist ──────────────────────────────────────────────────────────


@pytest.fixture()
def client(tmp_path):
    db_file = tmp_path / "test.db"
    engine = create_async_engine(f"sqlite+aiosqlite:///{db_file.as_posix()}")
    Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    async def override_get_db():
        async with Session() as session:
            yield session

    async def create_tables():
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    app.dependency_overrides[get_db] = override_get_db

    with patch("evalgrid.api.app.init_db", new=create_tables):
        with patch("evalgrid.api.database.SessionLocal", new=Session):
            with TestClient(app) as c:
                yield c

    app.dependency_overrides.clear()


def test_cors_allows_localhost_origin(client):
    resp = client.get("/health", headers={"Origin": "http://localhost:5173"})
    assert resp.status_code == 200
    assert resp.headers.get("access-control-allow-origin") == "http://localhost:5173"


def test_cors_rejects_evil_origin(client):
    resp = client.get("/health", headers={"Origin": "http://evil.example.com"})
    # Request still succeeds — but no allow-origin header echoed back
    assert resp.status_code == 200
    assert "access-control-allow-origin" not in resp.headers


def test_cors_preflight_rejects_disallowed_origin(client):
    resp = client.options(
        "/api/runs",
        headers={
            "Origin": "http://evil.example.com",
            "Access-Control-Request-Method": "POST",
        },
    )
    assert resp.headers.get("access-control-allow-origin") != "http://evil.example.com"


# ── 3. Global exception handler sanitization ──────────────────────────────────


@pytest.mark.asyncio
async def test_global_exception_handler_redacts_api_key_in_500():
    """A 500 caused by an exception containing an API key must redact it."""
    import json

    from evalgrid.api.app import global_exception_handler

    leaked = "sk-ant-api01-LEAKEDKEY-abcdef1234567890"

    # Minimal request stand-in — handler only reads request.url.path for logging
    class _FakeURL:
        path = "/test-leak"

    class _FakeRequest:
        url = _FakeURL()

    response = await global_exception_handler(_FakeRequest(), RuntimeError(f"upstream said: {leaked}"))
    assert response.status_code == 500
    body = json.loads(response.body)
    assert leaked not in body["detail"], f"Key leaked in 500 response: {body['detail']!r}"
    assert "[REDACTED]" in body["detail"]


def test_http_exception_passes_through_unredacted(client):
    """HTTPException with a benign detail should still surface cleanly."""
    resp = client.get("/api/runs/this-id-does-not-exist")
    # 404 from the get_run endpoint
    assert resp.status_code == 404
    assert "not found" in resp.json()["detail"].lower()


# ── 4. Stale-run cleanup on startup ───────────────────────────────────────────


@pytest.mark.asyncio
async def test_stale_run_cleanup_marks_unfinished_runs_as_failed(tmp_path):
    """A run with finished_at=NULL at startup should be marked failed."""
    db_file = tmp_path / "stale.db"
    db_url = f"sqlite+aiosqlite:///{db_file.as_posix()}"
    engine = create_async_engine(db_url)
    Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    # Seed a run with finished_at=None (simulating an in-flight run from a prior session)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    async with Session() as db:
        db.add(RunRecord(
            run_id="stale-run-id",
            started_at=datetime.now(UTC),
            finished_at=None,
            results=[],
        ))
        await db.commit()

    # Run the lifespan startup against this DB
    with patch("evalgrid.api.app.SessionLocal", new=Session, create=True):
        with patch("evalgrid.api.database.SessionLocal", new=Session):
            # Manually exercise the lifespan body — bypass FastAPI's lifecycle plumbing
            async with lifespan(app):
                pass

    # Verify the stale run was finalized
    async with Session() as db:
        rows = await db.execute(select(RunRecord).where(RunRecord.run_id == "stale-run-id"))
        record = rows.scalar_one()
        assert record.finished_at is not None, "Stale run not marked finished"
        assert record.pass_rate == 0.0
        assert record.results == [{"error": "Server restarted"}]

    await engine.dispose()
