"""Tests for scenario YAML loader."""

import textwrap
from pathlib import Path

import pytest

from evalgrid.core import ScenarioLoader
from evalgrid.core.models import AgentType


def _write_scenario(tmp_path: Path, content: str, name: str = "test.yml") -> Path:
    p = tmp_path / name
    p.write_text(textwrap.dedent(content))
    return p


def test_load_minimal_scenario(tmp_path):
    path = _write_scenario(
        tmp_path,
        """
        id: minimal
        name: Minimal Test
        prompt: You are helpful.
        test_input: Hello
        """,
    )
    loader = ScenarioLoader()
    s = loader.load_file(path)
    assert s.id == "minimal"
    assert s.name == "Minimal Test"
    assert s.agent_type == AgentType.GENERIC
    assert s.expected_actions == []


def test_load_full_scenario(tmp_path):
    path = _write_scenario(
        tmp_path,
        """
        id: full-test
        name: Full Test
        description: A full scenario
        agent_type: sdr
        prompt: You are an SDR.
        test_input: Qualify this lead.
        expected_actions:
          - action: qualify_lead
            required: true
            description: Qualify using BANT
          - action: suggest_next_step
            required: false
        success_criteria: Correctly identify BANT criteria.
        tags:
          - sdr
          - bant
        timeout_seconds: 90
        """,
    )
    loader = ScenarioLoader()
    s = loader.load_file(path)
    assert s.id == "full-test"
    assert s.agent_type == AgentType.SDR
    assert len(s.expected_actions) == 2
    assert s.expected_actions[0].required is True
    assert s.expected_actions[1].required is False
    assert "sdr" in s.tags
    assert s.timeout_seconds == 90


def test_load_dir(tmp_path):
    for i in range(3):
        _write_scenario(
            tmp_path,
            f"""
            id: scenario-{i}
            name: Scenario {i}
            prompt: You are helpful.
            test_input: Input {i}
            """,
            name=f"scenario_{i}.yml",
        )
    # Skipped file
    (tmp_path / "_skip.yml").write_text("id: skip\nname: Skip\nprompt: x\ntest_input: y")

    loader = ScenarioLoader()
    scenarios = loader.load_dir(tmp_path)
    assert len(scenarios) == 3
    ids = {s.id for s in scenarios}
    assert "skip" not in ids


def test_load_missing_required_field(tmp_path):
    path = _write_scenario(tmp_path, "id: bad\nname: Bad\n")  # missing prompt and test_input
    loader = ScenarioLoader()
    with pytest.raises(Exception):
        loader.load_file(path)


def test_loader_skipped_reason_is_human_readable(tmp_path):
    """Skipped scenarios must produce user-readable reasons, not raw Python tracebacks."""
    _write_scenario(
        tmp_path,
        "id: t\nname: T\nprompt: x\ntest_input: y\nexpected_actions: not-a-list\n",
        name="bad_type.yml",
    )
    loader = ScenarioLoader()
    loader.load_dir(tmp_path)
    assert len(loader.skipped) == 1
    reason = loader.skipped[0]["reason"]
    assert "string indices" not in reason, f"Raw Python error leaked: {reason}"
    assert "expected_actions" in reason
    assert "list" in reason
