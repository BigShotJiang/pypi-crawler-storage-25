"""Tests for core data models."""

import pytest

from evalgrid.core.models import (
    AgentType,
    EvalConfig,
    ExpectedAction,
    PassFail,
    Scenario,
    ScenarioResult,
    StepResult,
)


def test_scenario_required_actions():
    s = Scenario(
        id="test",
        name="Test",
        prompt="You are helpful.",
        test_input="Hello",
        expected_actions=[
            ExpectedAction(action="greet", required=True),
            ExpectedAction(action="optional_thing", required=False),
        ],
    )
    assert len(s.required_actions) == 1
    assert s.required_actions[0].action == "greet"


def test_scenario_result_pass_rate():
    steps = [
        StepResult(step_index=0, action="a", status=PassFail.PASS, score=1.0),
        StepResult(step_index=1, action="b", status=PassFail.FAIL, score=0.0),
        StepResult(step_index=2, action="c", status=PassFail.PASS, score=1.0),
    ]
    result = ScenarioResult(
        scenario_id="x",
        scenario_name="X",
        agent_type=AgentType.GENERIC,
        status=PassFail.FAIL,
        steps=steps,
        pass_rate=2 / 3,
    )
    assert abs(result.pass_rate - 2 / 3) < 0.001


def test_eval_config_defaults():
    from evalgrid.core.models import JudgeConfig
    config = EvalConfig()
    assert config.model == "claude-sonnet-4-6"
    assert config.max_concurrent == 5
    assert config.retry_on_error is True
    assert isinstance(config.judge, JudgeConfig)
    assert config.judge.provider == "anthropic"
    assert config.judge.model == "claude-sonnet-4-6"
    assert config.judge.api_key_env == "ANTHROPIC_API_KEY"


def test_step_result_score_bounds():
    with pytest.raises(Exception):
        StepResult(step_index=0, action="a", status=PassFail.PASS, score=1.5)

    with pytest.raises(Exception):
        StepResult(step_index=0, action="a", status=PassFail.PASS, score=-0.1)
