"""Tests for the deterministic assertion layer (core/assertions.py)."""
from __future__ import annotations

import pytest

from evalgrid.core.assertions import AssertionChecker
from evalgrid.core.models import CheckConfig


@pytest.fixture()
def checker() -> AssertionChecker:
    return AssertionChecker()


# ── valid_json ────────────────────────────────────────────────────────────────


def test_valid_json_passes_on_well_formed_json(checker):
    res = checker._run(CheckConfig(type="valid_json"), '{"a": 1, "b": [2, 3]}')
    assert res.passed is True
    assert res.name == "valid_json"


def test_valid_json_fails_on_garbage(checker):
    res = checker._run(CheckConfig(type="valid_json"), "not json at all {")
    assert res.passed is False
    assert "Invalid JSON" in res.details


def test_valid_json_ignores_surrounding_whitespace(checker):
    res = checker._run(CheckConfig(type="valid_json"), "   \n{}\n   ")
    assert res.passed is True


# ── no_markdown ───────────────────────────────────────────────────────────────


def test_no_markdown_passes_on_plain_text(checker):
    res = checker._run(CheckConfig(type="no_markdown"), "Just a plain sentence.")
    assert res.passed is True


def test_no_markdown_fails_on_fenced_code_block(checker):
    res = checker._run(CheckConfig(type="no_markdown"), "Here:\n```python\nx=1\n```")
    assert res.passed is False
    assert "fenced code block" in res.details


def test_no_markdown_fails_on_heading(checker):
    res = checker._run(CheckConfig(type="no_markdown"), "# Heading\nbody")
    assert res.passed is False
    assert "heading" in res.details


def test_no_markdown_fails_on_bold(checker):
    res = checker._run(CheckConfig(type="no_markdown"), "**bold** start of line")
    assert res.passed is False
    assert "bold" in res.details


# ── required_fields ───────────────────────────────────────────────────────────


def test_required_fields_passes_when_all_present(checker):
    res = checker._run(
        CheckConfig(type="required_fields", fields=["a", "b"]),
        '{"a": 1, "b": 2, "c": 3}',
    )
    assert res.passed is True


def test_required_fields_fails_listing_missing_keys(checker):
    res = checker._run(
        CheckConfig(type="required_fields", fields=["a", "missing"]),
        '{"a": 1}',
    )
    assert res.passed is False
    assert "missing" in res.details


def test_required_fields_fails_when_output_not_json(checker):
    res = checker._run(
        CheckConfig(type="required_fields", fields=["a"]),
        "not json",
    )
    assert res.passed is False
    assert "not valid JSON" in res.details


# ── enum ──────────────────────────────────────────────────────────────────────


def test_enum_passes_when_value_in_allowed(checker):
    res = checker._run(
        CheckConfig(type="enum", field="decision", allowed=["APPROVE", "REJECT"]),
        '{"decision": "APPROVE"}',
    )
    assert res.passed is True


def test_enum_fails_when_value_not_in_allowed(checker):
    res = checker._run(
        CheckConfig(type="enum", field="decision", allowed=["APPROVE", "REJECT"]),
        '{"decision": "MAYBE"}',
    )
    assert res.passed is False
    assert "MAYBE" in res.details


def test_enum_fails_when_field_missing(checker):
    res = checker._run(
        CheckConfig(type="enum", field="decision", allowed=["A"]),
        '{"other": "A"}',
    )
    assert res.passed is False


# ── forbidden_regex ───────────────────────────────────────────────────────────


def test_forbidden_regex_passes_when_no_match(checker):
    res = checker._run(
        CheckConfig(type="forbidden_regex", pattern=r"\bsecret\b"),
        "this is fine",
    )
    assert res.passed is True


def test_forbidden_regex_fails_on_match_case_insensitive(checker):
    res = checker._run(
        CheckConfig(type="forbidden_regex", pattern=r"password"),
        "Your PASSWORD is hunter2",
    )
    assert res.passed is False
    assert "PASSWORD" in res.details or "password" in res.details.lower()


# ── contains ──────────────────────────────────────────────────────────────────


def test_contains_passes_when_substring_present_case_insensitive(checker):
    res = checker._run(
        CheckConfig(type="contains", text="success"),
        "Operation completed: SUCCESS!",
    )
    assert res.passed is True


def test_contains_fails_when_absent(checker):
    res = checker._run(
        CheckConfig(type="contains", text="error"),
        "Everything fine",
    )
    assert res.passed is False
    assert "error" in res.details


# ── max_length ────────────────────────────────────────────────────────────────


def test_max_length_passes_at_or_under_limit(checker):
    res = checker._run(CheckConfig(type="max_length", value=10), "1234567890")
    assert res.passed is True


def test_max_length_fails_when_over(checker):
    res = checker._run(CheckConfig(type="max_length", value=5), "1234567890")
    assert res.passed is False
    assert "10" in res.details and "5" in res.details


# ── json_schema ───────────────────────────────────────────────────────────────


def test_json_schema_passes_when_valid(checker):
    schema = {"type": "object", "properties": {"x": {"type": "integer"}}, "required": ["x"]}
    res = checker._run(
        CheckConfig(type="json_schema", **{"schema": schema}),
        '{"x": 5}',
    )
    assert res.passed is True


def test_json_schema_fails_with_error_path_on_invalid(checker):
    schema = {"type": "object", "properties": {"x": {"type": "integer"}}, "required": ["x"]}
    res = checker._run(
        CheckConfig(type="json_schema", **{"schema": schema}),
        '{"x": "not an int"}',
    )
    assert res.passed is False
    assert res.error_path == "x"


def test_json_schema_fails_on_missing_schema(checker):
    res = checker._run(CheckConfig(type="json_schema"), '{"x": 1}')
    assert res.passed is False
    assert "No schema" in res.details


def test_json_schema_strict_rejects_extra_properties(checker):
    schema = {"type": "object", "properties": {"x": {"type": "integer"}}}
    res = checker._run(
        CheckConfig(type="json_schema", strict=True, **{"schema": schema}),
        '{"x": 1, "extra": "not allowed"}',
    )
    assert res.passed is False


def test_json_schema_fails_when_output_not_json(checker):
    res = checker._run(
        CheckConfig(type="json_schema", **{"schema": {"type": "object"}}),
        "not json",
    )
    assert res.passed is False
    assert "Invalid JSON" in res.details


# ── Unknown check type ────────────────────────────────────────────────────────


def test_unknown_check_type_fails_with_message(checker):
    res = checker._run(CheckConfig(type="not_a_real_check"), "anything")
    assert res.passed is False
    assert "Unknown check type" in res.details


# ── Exception path (e.g. invalid regex) ───────────────────────────────────────


def test_invalid_regex_pattern_caught_as_failure(checker):
    res = checker._run(
        CheckConfig(type="forbidden_regex", pattern="[unclosed"),
        "whatever",
    )
    assert res.passed is False
    assert "exception" in res.details.lower()


# ── hard_fail flag propagation ────────────────────────────────────────────────


def test_hard_fail_true_propagates_to_result(checker):
    res = checker._run(CheckConfig(type="valid_json", hard_fail=True), "not json")
    assert res.passed is False
    assert res.hard_fail is True


def test_hard_fail_false_propagates_to_result(checker):
    res = checker._run(CheckConfig(type="valid_json", hard_fail=False), "not json")
    assert res.passed is False
    assert res.hard_fail is False


# ── run_checks runs all in order ──────────────────────────────────────────────


def test_run_checks_returns_one_result_per_check(checker):
    checks = [
        CheckConfig(type="valid_json"),
        CheckConfig(type="max_length", value=10),
    ]
    results = checker.run_checks(checks, "ok")
    assert len(results) == 2
    assert results[0].name == "valid_json"
    assert results[1].name == "max_length"
