"""CLI smoke test — catches import-time errors and missing entry points."""
from click.testing import CliRunner

from evalgrid.cli.main import cli


def test_cli_help_runs():
    result = CliRunner().invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "evalgrid" in result.output
