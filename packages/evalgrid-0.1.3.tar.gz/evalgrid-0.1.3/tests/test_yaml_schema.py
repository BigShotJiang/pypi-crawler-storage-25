"""YAML scenario schema validation tests."""
from pathlib import Path

import pytest

from evalgrid.core.loader import ScenarioLoader

FIXTURES = Path(__file__).parent / "fixtures"


def test_valid_scenario_loads_without_error():
    scenario = ScenarioLoader().load_file(FIXTURES / "valid_scenario.yml")
    assert scenario.id == "valid-test-scenario"
    assert scenario.prompt


def test_invalid_yaml_rejected_with_clear_error():
    with pytest.raises(KeyError) as exc_info:
        ScenarioLoader().load_file(FIXTURES / "invalid_scenario.yml")
    assert "prompt" in str(exc_info.value)
