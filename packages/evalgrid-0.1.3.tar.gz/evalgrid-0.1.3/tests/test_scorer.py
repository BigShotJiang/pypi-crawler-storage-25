"""Tests for the MockScorer (no API calls required)."""

import pytest

from evalgrid.core.models import AgentType, ExpectedAction, PassFail, Scenario
from evalgrid.core.scorer import MockScorer


@pytest.fixture
def sample_scenario():
    return Scenario(
        id="test-scenario",
        name="Test Scenario",
        agent_type=AgentType.GENERIC,
        prompt="You are helpful.",
        test_input="Hello, how are you?",
        expected_actions=[
            ExpectedAction(action="greet_user", required=True),
            ExpectedAction(action="offer_help", required=True),
        ],
        success_criteria="Agent greets and offers help.",
    )


def test_mock_scorer_passes_all(sample_scenario):
    scorer = MockScorer()
    result = scorer.score(sample_scenario, "Hello! I'm great, how can I help you?")
    assert result.status == PassFail.PASS
    assert result.overall_score == 1.0
    assert result.pass_rate == 1.0
    assert len(result.steps) == 2
    assert all(s.status == PassFail.PASS for s in result.steps)


def test_mock_scorer_sets_scenario_metadata(sample_scenario):
    scorer = MockScorer()
    result = scorer.score(sample_scenario, "anything")
    assert result.scenario_id == "test-scenario"
    assert result.scenario_name == "Test Scenario"
    assert result.agent_type == AgentType.GENERIC


def test_mock_scorer_empty_actions():
    scenario = Scenario(
        id="empty",
        name="Empty",
        prompt="Be helpful.",
        test_input="Hi",
        expected_actions=[],
    )
    scorer = MockScorer()
    result = scorer.score(scenario, "Hi there!")
    assert result.status == PassFail.PASS
    assert result.steps == []


# ── Real Scorer (litellm mocked) ─────────────────────────────────────────────

import json  # noqa: E402
from unittest.mock import patch  # noqa: E402

from evalgrid.core.models import EvalConfig  # noqa: E402
from evalgrid.core.scorer import Scorer  # noqa: E402


def _refund_scenario() -> Scenario:
    return Scenario(
        id="t1",
        name="Refund Scenario",
        prompt="You are a support agent.",
        test_input="Process a refund for order #123.",
        expected_actions=[
            ExpectedAction(action="call_refund_tool", required=True,
                           description="Call the refund tool"),
        ],
    )


def test_scorer_parses_valid_pass_fail(mock_litellm_response):
    payload = json.dumps({
        "overall_score": 1.0,
        "overall_status": "pass",
        "reasoning": "agent called the refund tool",
        "steps": [{
            "step_index": 0,
            "action": "call_refund_tool",
            "expected_action": "call_refund_tool",
            "status": "pass",
            "score": 1.0,
            "reasoning": "tool was called",
        }],
    })
    with patch("litellm.completion", return_value=mock_litellm_response(payload)):
        result = Scorer(EvalConfig()).score(_refund_scenario(), "I called the refund tool")

    assert result.status == PassFail.PASS
    assert result.reasoning == "agent called the refund tool"


def test_scorer_handles_garbage_output(mock_litellm_response):
    garbage = "Sure, here's my analysis... the agent did fine I think"
    with patch("litellm.completion", return_value=mock_litellm_response(garbage)):
        result = Scorer(EvalConfig()).score(_refund_scenario(), "something")

    assert result.status == PassFail.ERROR
    assert result.error


def test_scorer_handles_malformed_llm_output(mock_litellm_response):
    malformed = '{"overall_score": 1.0, "steps": [}'  # syntactically invalid JSON
    with patch("litellm.completion", return_value=mock_litellm_response(malformed)):
        result = Scorer(EvalConfig()).score(_refund_scenario(), "output")

    assert result.status == PassFail.ERROR
    assert result.error is not None


def test_scorer_handles_litellm_timeout():
    import asyncio

    with patch("litellm.completion", side_effect=TimeoutError("timed out")):
        with pytest.raises(asyncio.TimeoutError):
            Scorer(EvalConfig(retry_on_error=False)).score(_refund_scenario(), "output")
