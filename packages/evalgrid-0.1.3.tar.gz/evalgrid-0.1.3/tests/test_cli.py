"""CLI integration tests."""
from __future__ import annotations

from click.testing import CliRunner

from evalgrid.cli.main import cli
from evalgrid.core.models import PassFail

_SAMPLE_SCENARIO = """\
id: cli-test
name: CLI Test
prompt: You are helpful.
test_input: Say hello
expected_actions:
  - action: greet_user
    required: true
"""


def test_evalgrid_run_with_mock_returns_zero_exit_code(tmp_path):
    scen_dir = tmp_path / "scenarios"
    scen_dir.mkdir()
    (scen_dir / "test.yml").write_text(_SAMPLE_SCENARIO)

    results_dir = tmp_path / "results"
    config_file = tmp_path / "config.yml"
    config_file.write_text(
        f"output_dir: {results_dir.as_posix()}\n"
    )

    result = CliRunner().invoke(
        cli,
        ["run", "--scenarios-dir", str(scen_dir), "--mock", "--config", str(config_file)],
    )
    assert result.exit_code == 0, result.output


def test_evalgrid_run_with_no_api_key_returns_one(tmp_path):
    scen_dir = tmp_path / "scenarios"
    scen_dir.mkdir()
    (scen_dir / "test.yml").write_text(_SAMPLE_SCENARIO)

    result = CliRunner().invoke(
        cli,
        ["run", "--scenarios-dir", str(scen_dir)],
        env={"ANTHROPIC_API_KEY": "", "OPENAI_API_KEY": ""},
    )
    assert result.exit_code == 1


def test_run_exits_2_on_error_status(tmp_path, monkeypatch):
    scen_dir = tmp_path / "scenarios"
    scen_dir.mkdir()
    (scen_dir / "test.yml").write_text(_SAMPLE_SCENARIO)

    db_path = tmp_path / "test.db"
    results_dir = tmp_path / "results"
    config_file = tmp_path / "config.yml"
    config_file.write_text(f"output_dir: {results_dir.as_posix()}\n")
    monkeypatch.setenv("DATABASE_URL", f"sqlite+aiosqlite:///{db_path.as_posix()}")

    from evalgrid.core.models import ScenarioResult
    from evalgrid.core.runner import ScenarioRunner

    def error_run_scenario(self, scenario):
        return ScenarioResult(
            scenario_id=scenario.id,
            scenario_name=scenario.name,
            agent_type=scenario.agent_type,
            status=PassFail.ERROR,
            error="mock auth error",
        )

    monkeypatch.setattr(ScenarioRunner, "run_scenario", error_run_scenario)

    result = CliRunner().invoke(
        cli,
        ["run", "--scenarios-dir", str(scen_dir), "--mock", "--config", str(config_file)],
    )
    assert result.exit_code == 2, result.output


def test_init_force_overwrites_existing_directory(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".evalgrid").mkdir()
    (tmp_path / ".evalgrid" / "stale.txt").write_text("existing")

    result = CliRunner().invoke(cli, ["init", "--force"])
    assert result.exit_code == 0, result.output
    assert (tmp_path / ".evalgrid" / "config.yml").exists()


def test_init_yes_exits_when_already_initialized(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".evalgrid").mkdir()

    result = CliRunner().invoke(cli, ["init", "--yes"])
    assert result.exit_code == 0
    assert (
        "already initialized" in result.output.lower()
        or "use --force" in result.output.lower()
    )
