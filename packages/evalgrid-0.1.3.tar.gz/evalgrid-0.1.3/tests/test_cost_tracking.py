"""Tests for token-usage and USD-cost tracking on ScenarioResult."""
from __future__ import annotations

import json
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from evalgrid.core.models import AgentType, EvalConfig, ExpectedAction, PassFail, Scenario
from evalgrid.core.runner import ScenarioRunner, extract_usage_cost
from evalgrid.core.scorer import MockScorer, Scorer


def _response_with_usage(content: str, prompt_tokens: int, completion_tokens: int):
    """Build a minimal LiteLLM-shaped response with the .usage and .choices fields."""
    return SimpleNamespace(
        choices=[SimpleNamespace(message=SimpleNamespace(content=content))],
        usage=SimpleNamespace(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
        ),
        model="claude-sonnet-4-6",  # required for litellm.completion_cost lookup
    )


# ── extract_usage_cost ────────────────────────────────────────────────────────


def test_extract_usage_cost_reads_token_counts():
    resp = _response_with_usage("x", prompt_tokens=120, completion_tokens=45)
    pt, ct, _ = extract_usage_cost(resp)
    assert pt == 120
    assert ct == 45


def test_extract_usage_cost_returns_zero_when_usage_missing():
    resp = SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content="x"))])
    pt, ct, cost = extract_usage_cost(resp)
    assert (pt, ct, cost) == (0, 0, 0.0)


def test_extract_usage_cost_does_not_raise_on_unknown_model():
    """Models with no LiteLLM pricing data should yield cost=0, not raise."""
    resp = SimpleNamespace(
        choices=[SimpleNamespace(message=SimpleNamespace(content="x"))],
        usage=SimpleNamespace(prompt_tokens=10, completion_tokens=5),
        model="some-unknown-local-model",
    )
    pt, ct, cost = extract_usage_cost(resp)
    assert pt == 10
    assert ct == 5
    assert cost == 0.0  # pricing lookup fails -> 0.0


def test_extract_usage_cost_passes_through_litellm_cost():
    """When litellm.completion_cost returns a value, we propagate it untouched."""
    resp = _response_with_usage("x", prompt_tokens=1000, completion_tokens=500)
    with patch("litellm.completion_cost", return_value=0.0042):
        _, _, cost = extract_usage_cost(resp)
    assert cost == 0.0042


# ── MockScorer reports zero cost ──────────────────────────────────────────────


def test_mock_scorer_reports_zero_cost():
    scenario = Scenario(
        id="t", name="T", prompt="P", test_input="I",
        expected_actions=[ExpectedAction(action="a")],
    )
    result = MockScorer().score(scenario, "anything")
    assert result.prompt_tokens == 0
    assert result.completion_tokens == 0
    assert result.cost_usd == 0.0


# ── Scorer populates judge cost from response ─────────────────────────────────


def _refund_scenario() -> Scenario:
    return Scenario(
        id="t1", name="T1", prompt="be helpful", test_input="refund order 1",
        expected_actions=[ExpectedAction(action="call_refund_tool", required=True)],
    )


def test_scorer_populates_judge_cost_from_response():
    payload = json.dumps({
        "overall_score": 1.0,
        "overall_status": "pass",
        "reasoning": "ok",
        "steps": [{"step_index": 0, "action": "call_refund_tool",
                   "expected_action": "call_refund_tool",
                   "status": "pass", "score": 1.0, "reasoning": "called"}],
    })
    resp = _response_with_usage(payload, prompt_tokens=800, completion_tokens=200)
    with patch("litellm.completion", return_value=resp), \
         patch("litellm.completion_cost", return_value=0.0123):
        result = Scorer(EvalConfig()).score(_refund_scenario(), "output")
    assert result.prompt_tokens == 800
    assert result.completion_tokens == 200
    assert result.cost_usd == pytest.approx(0.0123)
    assert result.status == PassFail.PASS


# ── Runner sums agent + judge cost ────────────────────────────────────────────


def test_runner_sums_agent_and_judge_cost():
    """Two LiteLLM calls happen per scenario (agent + judge); their costs should be summed."""
    payload = json.dumps({
        "overall_score": 1.0, "overall_status": "pass", "reasoning": "ok",
        "steps": [{"step_index": 0, "action": "x", "expected_action": "x",
                   "status": "pass", "score": 1.0, "reasoning": ""}],
    })
    # Agent call returns 500/100, judge call returns 800/200.
    responses = [
        _response_with_usage("agent output", prompt_tokens=500, completion_tokens=100),
        _response_with_usage(payload, prompt_tokens=800, completion_tokens=200),
    ]
    costs = [0.005, 0.012]  # agent cost, judge cost
    scenario = Scenario(
        id="t", name="T", prompt="P", test_input="I",
        expected_actions=[ExpectedAction(action="x", required=True)],
    )
    with patch("litellm.completion", side_effect=responses), \
         patch("litellm.completion_cost", side_effect=costs):
        result = ScenarioRunner(EvalConfig()).run_scenario(scenario)
    assert result.prompt_tokens == 1300  # 500 + 800
    assert result.completion_tokens == 300  # 100 + 200
    assert result.cost_usd == pytest.approx(0.017)  # 0.005 + 0.012
    assert result.status == PassFail.PASS


def test_runner_records_agent_cost_on_hard_fail_short_circuit():
    """Hard-fail check short-circuits before judge runs — but agent cost still recorded."""
    from evalgrid.core.models import CheckConfig

    scenario = Scenario(
        id="t", name="T", prompt="P", test_input="I",
        expected_actions=[ExpectedAction(action="x", required=True)],
        checks=[CheckConfig(type="valid_json", hard_fail=True)],
    )
    # Agent returns garbage; the valid_json hard-fail check fires, no judge call happens.
    agent_resp = _response_with_usage("not json", prompt_tokens=400, completion_tokens=60)
    with patch("litellm.completion", side_effect=[agent_resp]), \
         patch("litellm.completion_cost", return_value=0.007):
        result = ScenarioRunner(EvalConfig()).run_scenario(scenario)
    assert result.hard_failed is True
    assert result.status == PassFail.FAIL
    assert result.prompt_tokens == 400  # agent only — judge was short-circuited
    assert result.completion_tokens == 60
    assert result.cost_usd == pytest.approx(0.007)  # exactly one LiteLLM call costed


def test_mock_runner_reports_zero_cost():
    """mock=True + agent_fn path should produce zero cost end-to-end."""
    scenario = Scenario(
        id="t", name="T", prompt="P", test_input="I",
        expected_actions=[ExpectedAction(action="x", required=True)],
    )
    runner = ScenarioRunner(
        EvalConfig(),
        scorer=MockScorer(),
        agent_fn=lambda s: ("[mock output]", 0),
        mock=True,
    )
    result = runner.run_scenario(scenario)
    assert result.prompt_tokens == 0
    assert result.completion_tokens == 0
    assert result.cost_usd == 0.0
