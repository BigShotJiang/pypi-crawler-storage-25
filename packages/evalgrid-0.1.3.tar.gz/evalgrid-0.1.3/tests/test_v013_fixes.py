"""Tests for the v0.1.3 fix bundle (FIX 1-7).

Each test maps to one fix in the v0.1.3 audit report. New tests added in this
file deliberately read in fix-number order so they can be cross-referenced
with the audit and CHANGELOG.
"""

from __future__ import annotations

import warnings
from datetime import UTC, datetime
from unittest.mock import patch

import litellm
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from evalgrid.api.app import RunRequest, app
from evalgrid.api.database import (
    Base,
    RunRecord,
    ScenarioResultRecord,
    get_db,
)
from evalgrid.core.models import EvalConfig, PassFail, Scenario
from evalgrid.core.paths import resolve_scenarios_dir
from evalgrid.core.runner import ScenarioRunner


# ── shared fixture ─────────────────────────────────────────────────────────────

@pytest.fixture()
def client(tmp_path):
    db_file = tmp_path / "test.db"
    engine = create_async_engine(f"sqlite+aiosqlite:///{db_file.as_posix()}")
    Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    async def override_get_db():
        async with Session() as session:
            yield session

    async def create_tables():
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    app.dependency_overrides[get_db] = override_get_db
    with patch("evalgrid.api.app.init_db", new=create_tables):
        with patch("evalgrid.api.database.SessionLocal", new=Session):
            with TestClient(app) as c:
                yield c, Session
    app.dependency_overrides.clear()


# ── FIX 1: scenarios_dir resolver ─────────────────────────────────────────────

def test_fix1_cwd_takes_precedence_over_home(tmp_path, monkeypatch):
    """resolve_scenarios_dir prefers <cwd>/.evalgrid/scenarios over ~/.evalgrid/scenarios."""
    home = tmp_path / "home"
    project = tmp_path / "project"
    (home / ".evalgrid" / "scenarios").mkdir(parents=True)
    (project / ".evalgrid" / "scenarios").mkdir(parents=True)

    monkeypatch.setattr("pathlib.Path.home", lambda: home)
    monkeypatch.chdir(project)
    monkeypatch.delenv("EVALGRID_SCENARIOS_DIR", raising=False)

    resolved = resolve_scenarios_dir()
    assert resolved == project / ".evalgrid" / "scenarios"


def test_fix1_env_var_beats_cwd(tmp_path, monkeypatch):
    """EVALGRID_SCENARIOS_DIR overrides both cwd and home."""
    project = tmp_path / "project"
    explicit = tmp_path / "explicit"
    (project / ".evalgrid" / "scenarios").mkdir(parents=True)
    explicit.mkdir()

    monkeypatch.chdir(project)
    monkeypatch.setenv("EVALGRID_SCENARIOS_DIR", str(explicit))
    assert resolve_scenarios_dir() == explicit


def test_fix1_falls_back_to_home(tmp_path, monkeypatch):
    """With no env var and no cwd scenarios dir, the resolver returns ~/.evalgrid/scenarios."""
    home = tmp_path / "home"
    (home / ".evalgrid").mkdir(parents=True)
    elsewhere = tmp_path / "elsewhere"
    elsewhere.mkdir()

    monkeypatch.setattr("pathlib.Path.home", lambda: home)
    monkeypatch.chdir(elsewhere)
    monkeypatch.delenv("EVALGRID_SCENARIOS_DIR", raising=False)
    assert resolve_scenarios_dir() == home / ".evalgrid" / "scenarios"


# ── default_database_url: project-local vs home, mirrors scenarios_dir ───────

def test_default_database_url_prefers_cwd_when_project_evalgrid_exists(tmp_path, monkeypatch):
    """A project with `<cwd>/.evalgrid/` gets `<cwd>/.evalgrid/results.db` so
    SQLite writes go alongside its scenarios + suites, not into the home dir."""
    from evalgrid.core.paths import default_database_url

    home = tmp_path / "home"
    project = tmp_path / "project"
    (home / ".evalgrid").mkdir(parents=True)
    (project / ".evalgrid").mkdir(parents=True)

    monkeypatch.setattr("pathlib.Path.home", lambda: home)
    monkeypatch.chdir(project)
    monkeypatch.delenv("DATABASE_URL", raising=False)

    url = default_database_url()
    expected = (project / ".evalgrid" / "results.db").as_posix()
    assert url == f"sqlite+aiosqlite:///{expected}", url


def test_default_database_url_env_var_wins(tmp_path, monkeypatch):
    """DATABASE_URL overrides project-local and home — explicit beats implicit."""
    from evalgrid.core.paths import default_database_url

    project = tmp_path / "project"
    (project / ".evalgrid").mkdir(parents=True)
    explicit = f"sqlite+aiosqlite:///{tmp_path}/explicit.db"

    monkeypatch.chdir(project)
    monkeypatch.setenv("DATABASE_URL", explicit)
    assert default_database_url() == explicit


def test_default_database_url_falls_back_to_home(tmp_path, monkeypatch):
    """With no env var and no `<cwd>/.evalgrid/`, falls back to home."""
    from evalgrid.core.paths import default_database_url

    home = tmp_path / "home"
    (home / ".evalgrid").mkdir(parents=True)
    elsewhere = tmp_path / "elsewhere"
    elsewhere.mkdir()

    monkeypatch.setattr("pathlib.Path.home", lambda: home)
    monkeypatch.chdir(elsewhere)
    monkeypatch.delenv("DATABASE_URL", raising=False)

    url = default_database_url()
    expected = (home / ".evalgrid" / "results.db").as_posix()
    assert url == f"sqlite+aiosqlite:///{expected}", url


def test_default_database_url_autocreates_parent(tmp_path, monkeypatch):
    """The resolver creates the parent .evalgrid dir so a fresh project
    doesn't fail with `sqlite3.OperationalError: unable to open database`
    when nothing has touched the dir yet."""
    from evalgrid.core.paths import default_database_url

    project = tmp_path / "project"
    (project / ".evalgrid").mkdir(parents=True)
    # Wipe the .evalgrid dir to simulate a freshly cloned project with
    # only the directory marker — the resolver should still produce a
    # usable URL whose parent dir exists.
    monkeypatch.chdir(project)
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path / "home")

    url = default_database_url()
    assert url.startswith("sqlite+aiosqlite:///")
    assert (project / ".evalgrid").exists()


# ── FIX 2: compare route ordering ─────────────────────────────────────────────

def test_fix2_compare_route_reaches_handler(client, tmp_path):
    """GET /api/runs/compare must not be shadowed by GET /api/runs/{run_id}."""
    _client, Session = client

    async def seed():
        async with Session() as db:
            for run_id in ("base", "head"):
                db.add(RunRecord(
                    run_id=run_id,
                    started_at=datetime.now(UTC),
                    finished_at=datetime.now(UTC),
                    pass_rate=1.0,
                    passed=1,
                    total=1,
                    results=[],
                ))
                db.add(ScenarioResultRecord(
                    run_id=run_id,
                    scenario_id="s1",
                    scenario_name="Test scenario",
                    agent_type="generic",
                    status="pass",
                    overall_score=1.0,
                    pass_rate=1.0,
                    reasoning="",
                    error=None,
                    steps=[],
                    check_results=[],
                    hard_failed=0,
                    prompt_tokens=0,
                    completion_tokens=0,
                    cost_usd=0.0,
                    started_at=datetime.now(UTC),
                    finished_at=datetime.now(UTC),
                ))
            await db.commit()

    import asyncio
    asyncio.run(seed())

    r = _client.get("/api/runs/compare", params={"base": "base", "head": "head"})
    assert r.status_code == 200, r.text
    data = r.json()
    assert "summary" in data
    assert data["base_run_id"] == "base"
    assert data["head_run_id"] == "head"


# ── FIX 3: top-level error field on GET /api/runs/{id} ────────────────────────

def test_fix3_run_error_surfaces_in_detail(client):
    """A run that failed at startup must expose its error string in the API response."""
    _client, Session = client

    async def seed():
        async with Session() as db:
            db.add(RunRecord(
                run_id="errored",
                started_at=datetime.now(UTC),
                finished_at=datetime.now(UTC),
                pass_rate=0.0,
                passed=0,
                total=0,
                results=[{"error": "Scenarios directory not found"}],
            ))
            await db.commit()

    import asyncio
    asyncio.run(seed())

    r = _client.get("/api/runs/errored")
    assert r.status_code == 200
    body = r.json()
    assert "error" in body
    assert body["error"] == "Scenarios directory not found"


def test_fix3_successful_run_has_null_error(client):
    """A run with normal scenario results must have error=null in the API response."""
    _client, Session = client

    async def seed():
        async with Session() as db:
            db.add(RunRecord(
                run_id="ok",
                started_at=datetime.now(UTC),
                finished_at=datetime.now(UTC),
                pass_rate=1.0,
                passed=1,
                total=1,
                results=[],
            ))
            await db.commit()

    import asyncio
    asyncio.run(seed())

    r = _client.get("/api/runs/ok")
    assert r.status_code == 200
    assert r.json()["error"] is None


# ── FIX 4: retry on InternalServerError ───────────────────────────────────────

def test_fix4_retries_internal_server_error_then_succeeds(monkeypatch):
    """Two consecutive InternalServerError exceptions should be retried; the third call succeeds."""
    config = EvalConfig(retry_on_error=True, max_retries=3, timeout_seconds=5)

    class _Choice:
        def __init__(self, content):
            self.message = type("M", (), {"content": content})()

    class _Resp:
        def __init__(self):
            self.choices = [_Choice("ok-response")]
            self.usage = type("U", (), {"prompt_tokens": 1, "completion_tokens": 1})()

    call_count = {"n": 0}

    def fake_completion(**kwargs):
        call_count["n"] += 1
        if call_count["n"] < 3:
            raise litellm.exceptions.InternalServerError(
                message="overloaded_error",
                model=kwargs.get("model", "x"),
                llm_provider="anthropic",
            )
        return _Resp()

    monkeypatch.setattr("litellm.completion", fake_completion)
    monkeypatch.setattr("evalgrid.core.runner.litellm.completion", fake_completion)
    monkeypatch.setattr("evalgrid.core.runner.time.sleep", lambda _: None)

    runner = ScenarioRunner(config)
    scenario = Scenario(
        id="t", name="Test", prompt="x", test_input="y",
        agent_type="generic", checks=[],
    )
    output, _, _, _, _ = runner._run_agent(scenario)
    assert output == "ok-response"
    assert call_count["n"] == 3


# ── FIX 5: empty body POST /api/runs returns 422 ──────────────────────────────

def test_fix5_empty_body_returns_422(client):
    _client, _ = client
    r = _client.post("/api/runs", json={})
    assert r.status_code == 422


def _seed_scenario(scen_dir, sid: str = "smoke-test", tag: str = "smoke") -> None:
    """Write a minimal loader-valid scenario YAML under scen_dir."""
    from pathlib import Path as _Path
    scen_dir = _Path(scen_dir)
    scen_dir.mkdir(parents=True, exist_ok=True)
    (scen_dir / f"{sid}.yml").write_text(
        f"id: {sid}\n"
        f"name: Smoke test\n"
        f"prompt: hi\n"
        f"test_input: hi\n"
        f"agent_type: generic\n"
        f"tags: [{tag}]\n"
        f"expected_actions: []\n"
        f"checks: []\n",
        encoding="utf-8",
    )


def test_fix5_mock_true_with_scenarios_present(client, tmp_path, monkeypatch):
    """mock=true resolves to all scenarios on disk — 200 when at least one exists."""
    _client, _ = client
    scen_dir = tmp_path / "scenarios"
    _seed_scenario(scen_dir)
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)
    r = _client.post("/api/runs", json={"mock": True})
    assert r.status_code == 200


def test_fix5_tag_matching_existing_scenario(client, tmp_path, monkeypatch):
    """Filter resolves to at least one scenario → 200."""
    _client, _ = client
    scen_dir = tmp_path / "scenarios"
    _seed_scenario(scen_dir, tag="smoke")
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)
    r = _client.post("/api/runs", json={"mock": True, "tags": ["smoke"]})
    assert r.status_code == 200


# ── FIX 5 (extended in v0.1.3 patch): reject runs that resolve to 0 scenarios ──

def test_fix5x_tag_with_no_match_returns_422_and_no_db_row(client, tmp_path, monkeypatch):
    """A filter that resolves to zero scenarios must 422 BEFORE the DB row exists.

    Previously this created an "empty" run row, polluting /runs with 0/0 entries.
    """
    _client, Session = client
    scen_dir = tmp_path / "scenarios"
    _seed_scenario(scen_dir, tag="smoke")
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)

    r = _client.post("/api/runs", json={"mock": True, "tags": ["nonexistent"]})
    assert r.status_code == 422
    assert "no scenarios matched" in r.json()["detail"].lower()

    import asyncio
    from sqlalchemy import func as _func
    async def count_runs():
        async with Session() as db:
            res = await db.execute(select(_func.count(RunRecord.id)))
            return res.scalar_one()
    assert asyncio.run(count_runs()) == 0


def test_fix5x_missing_suite_returns_422(client, tmp_path, monkeypatch):
    """Suite name that doesn't exist on disk is a user error → 422 (was 200 then mark-failed)."""
    _client, _ = client
    scen_dir = tmp_path / "scenarios"
    suites_dir = tmp_path / "suites"
    _seed_scenario(scen_dir)
    suites_dir.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)
    monkeypatch.setattr("evalgrid.api.app._suites_base_dir", lambda: suites_dir)

    r = _client.post("/api/runs", json={"mock": True, "suite": "no-such-suite"})
    assert r.status_code == 422
    assert "no-such-suite" in r.json()["detail"]


# ── FIX 6: split agent_model vs judge_model ───────────────────────────────────

def test_fix6_request_accepts_separate_model_fields():
    """RunRequest must accept agent_model and judge_model as independent fields."""
    req = RunRequest(mock=True, agent_model="agent-X", judge_model="judge-Y")
    assert req.agent_model == "agent-X"
    assert req.judge_model == "judge-Y"


def test_fix6_judge_model_alone_emits_deprecation(monkeypatch):
    """Passing only judge_model should still set both, but raise DeprecationWarning."""
    from evalgrid.api.app import _execute_run

    captured: dict[str, str] = {}

    async def fake_init_db():
        return None

    # We invoke _execute_run but stub everything heavy — we only care that the
    # DeprecationWarning fires when agent_model is omitted but judge_model is set.
    req = RunRequest(mock=True, judge_model="legacy-only")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        # Replicate the model-assignment block from _execute_run inline.
        config = EvalConfig()
        if req.agent_model:
            config.model = req.agent_model
        if req.judge_model:
            config.judge.model = req.judge_model
            if not req.agent_model:
                warnings.warn(
                    "Passing only judge_model is deprecated — pass agent_model and judge_model "
                    "separately. For now judge_model sets both, but this fallback will be removed "
                    "in v0.2.",
                    DeprecationWarning,
                    stacklevel=2,
                )
                config.model = req.judge_model

    assert config.model == "legacy-only"
    assert config.judge.model == "legacy-only"
    assert any(issubclass(w.category, DeprecationWarning) for w in caught)


# ── SPA fallback for dynamic dashboard routes ─────────────────────────────────

def test_spa_fallback_serves_index_for_dynamic_routes(client):
    """Hard refresh on /runs/<id> must serve the SPA shell, not 404."""
    _client, _ = client
    response = _client.get("/runs/abc-fake-id")
    assert response.status_code == 200
    assert b"<html" in response.content


def test_spa_fallback_preserves_api_404(client):
    """/api/* 404s must remain typed JSON so SDKs still see a normal API contract."""
    _client, _ = client
    response = _client.get("/api/nonexistent")
    assert response.status_code == 404
    assert "detail" in response.json()


def test_spa_fallback_serves_runs_dynamic_shell(client):
    """The /runs/<id> hard refresh must serve runs/_index/index.html (the dynamic
    [id] shell), NOT the overview's root index.html.

    Identifies the correct shell by checking for the run-detail-loading testid
    which only exists in the dynamic shell.
    """
    _client, _ = client
    response = _client.get("/runs/abc-fake-id")
    assert response.status_code == 200
    # The dynamic shell has the run-detail loading state pre-rendered. The
    # overview shell does not. This is the diff that the v0.1.3 bug masked.
    assert b"run-detail-loading" in response.content, (
        "Expected the runs/_index dynamic shell — got the overview shell. "
        "Hard refresh on /runs/<id> would render Overview, not the run detail."
    )


def test_spa_fallback_real_asset_404_stays_404(client):
    """Asset 404s (.js/.css/.txt) must stay real 404s — never serve a SPA shell
    in place of a script chunk or the browser will choke on hydration."""
    _client, _ = client
    response = _client.get("/_next/static/chunks/does-not-exist.js")
    assert response.status_code == 404
    # Must not be one of the SPA shells (overview or dynamic)
    assert b"run-detail-loading" not in response.content
    # Next.js's exported 404.html has this string; the SPA shells don't
    assert b"404: This page could not be found" in response.content


# ── Next 16 RSC payload rewrite ───────────────────────────────────────────────

def test_rsc_payload_dotted_form_rewrites_to_subdir(client):
    """Next 16 client requests `/runs/__next.runs.__PAGE__.txt` but the export
    writes it as `/runs/__next.runs/__PAGE__.txt`. Without the rewrite every
    navigation logs a 404 console.error — routes still work via full reload
    but the noise drowns real errors."""
    _client, _ = client
    response = _client.get("/runs/__next.runs.__PAGE__.txt")
    assert response.status_code == 200, (
        f"RSC payload must resolve via dot→slash rewrite; got {response.status_code}"
    )
    # The RSC payload is React server output, starts with line-numbered tags.
    body = response.content
    assert body, "RSC payload should not be empty"


def test_rsc_payload_rewrite_does_not_serve_arbitrary_files(client):
    """The rewrite is scoped to `.__PAGE__.txt` suffix — random `.txt` requests
    must still 404. Guards against the rewrite becoming an accidental open
    file lookup."""
    _client, _ = client
    response = _client.get("/runs/anything-else.txt")
    assert response.status_code == 404


def test_rsc_payload_rewrite_rejects_path_traversal(client):
    """The rewrite must reject `..` segments so a crafted request can't
    escape the static root via the dot-rewriting logic."""
    _client, _ = client
    response = _client.get("/runs/__next.runs.__PAGE__.txt/../../etc/passwd.__PAGE__.txt")
    # Either 404 (file truly missing) or rejected; never 200 with passwd content.
    assert response.status_code in (404, 422), (
        f"Path-traversal-shaped RSC path returned {response.status_code}"
    )
    if response.status_code == 200:
        # Belt-and-braces: even on a coincidental match, must not leak
        # anything outside static.
        assert b"root:" not in response.content


def test_rsc_dynamic_route_falls_back_to_index_shell(client):
    """Hitting `/runs/<actual-uuid>` triggers RSC prefetches like
    `/runs/<uuid>/__next._tree.txt` — these only live under
    `/runs/_index/__next._tree.txt`. The resolver must fall back so RSC
    nav doesn't pollute the console with 404s."""
    _client, _ = client
    # Use a UUID-shaped id like the smoke harness does
    response = _client.get("/runs/0d1d6143-1596-4d46-a318-711dd4ea8278/__next._tree.txt")
    assert response.status_code == 200, (
        f"RSC payload under a dynamic [id] must resolve to the _index shell; "
        f"got {response.status_code}"
    )
    assert response.content, "RSC payload should not be empty"


def test_rsc_dynamic_route_index_fallback_for_index_txt(client):
    """Same fallback must apply to the plain index.txt under a dynamic id —
    Next 16 sometimes prefetches it during route segment hydration."""
    _client, _ = client
    response = _client.get("/runs/abc-fake-id/index.txt")
    assert response.status_code == 200
    assert response.content


def test_rsc_dynamic_route_composes_with_dotted_dirname_rewrite(client):
    """The nested case: visiting /runs/<uuid> triggers a prefetch like
    /runs/<uuid>/__next.runs.$d$id.__PAGE__.txt — the resolver must
    compose Strategy 2 (substitute <uuid> with _index) and Strategy 1
    (split the trailing dots into a subdir) to land at
    /runs/_index/__next.runs/$d$id/__PAGE__.txt. Without composition
    this case still 404s."""
    _client, _ = client
    response = _client.get(
        "/runs/abc-fake-id/__next.runs.$d$id.__PAGE__.txt"
    )
    assert response.status_code == 200, (
        f"Composed _index + dot-split rewrite must resolve; got {response.status_code}"
    )
    assert response.content


def test_rsc_dynamic_route_plain_txt_dotted_form(client):
    """Plain .txt (not __PAGE__.txt) also gets the dot-split rewrite. Next 16
    prefetches `/runs/<uuid>/__next.runs.$d$id.txt` during route segment
    hydration; the on-disk file is `/runs/_index/__next.runs/$d$id.txt`
    (dot before $d$id is a directory boundary)."""
    _client, _ = client
    response = _client.get("/runs/abc-fake-id/__next.runs.$d$id.txt")
    assert response.status_code == 200, (
        f"Plain .txt dot-split rewrite must resolve; got {response.status_code}"
    )
    assert response.content


def test_rsc_dynamic_route_does_not_leak_outside_static(client):
    """The _index walk must reject literal `..` segments so a crafted
    request cannot escape the static root after the substitution."""
    _client, _ = client
    # Starlette canonicalizes leading `..` before our handler ever sees it,
    # so build a request the dispatcher will preserve and the resolver
    # itself must guard against.
    response = _client.get("/runs/foo/../../etc/passwd")
    # Either 404 (canonicalized away by Starlette) or never leaks system files.
    assert response.status_code in (200, 404), response.status_code
    assert b"root:" not in response.content
    # And the SPA shell or 404 page is what we get — never an external file.
    assert b"This page could not be found" in response.content or b"EvalGrid" in response.content


# ── FIX 3: POST /api/config/keys ──────────────────────────────────────────────

def test_fix3_set_config_keys_updates_environ(client, monkeypatch):
    """POST /api/config/keys must mutate os.environ for the running process."""
    import os
    _client, _ = client
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    r = _client.post(
        "/api/config/keys",
        json={"ANTHROPIC_API_KEY": "test-ant-key", "OPENAI_API_KEY": "test-oa-key"},
    )
    assert r.status_code == 200
    body = r.json()
    assert set(body["updated"]) == {"ANTHROPIC_API_KEY", "OPENAI_API_KEY"}
    assert body["anthropic_key_set"] is True
    assert body["openai_key_set"] is True
    assert os.environ["ANTHROPIC_API_KEY"] == "test-ant-key"
    assert os.environ["OPENAI_API_KEY"] == "test-oa-key"

    s = _client.get("/api/config-status")
    assert s.json()["anthropic_key_set"] is True
    assert s.json()["openai_key_set"] is True


def test_fix3_set_config_keys_partial_update(client, monkeypatch):
    """Empty string / omitted keys must NOT clear an already-set env var."""
    import os
    _client, _ = client
    monkeypatch.setenv("ANTHROPIC_API_KEY", "pre-existing")
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    r = _client.post("/api/config/keys", json={"OPENAI_API_KEY": "new-oa"})
    assert r.status_code == 200
    assert r.json()["updated"] == ["OPENAI_API_KEY"]
    assert os.environ["ANTHROPIC_API_KEY"] == "pre-existing"
    assert os.environ["OPENAI_API_KEY"] == "new-oa"


def test_fix3_set_config_keys_rejects_unknown_fields(client):
    """extra=forbid: typo provider names 422 instead of silently no-op."""
    _client, _ = client
    r = _client.post(
        "/api/config/keys", json={"GROK_API_KEY": "x", "ANTHROPIC_API_KEY": "y"}
    )
    assert r.status_code == 422


# ── PHASE 1 hardening: body-size, security headers ────────────────────────────

def test_phase1_body_size_413_when_oversized(client):
    """Body > 1 MB is rejected at middleware level — never reaches Pydantic."""
    _client, _ = client
    # Content-Length is set automatically by httpx
    huge = "x" * (1024 * 1024 + 100)
    r = _client.post(
        "/api/scenarios",
        json={"id": "x", "name": "x", "prompt": huge},
    )
    assert r.status_code == 413


def test_phase1_security_headers_present(client):
    _client, _ = client
    r = _client.get("/health")
    assert r.headers.get("X-Content-Type-Options") == "nosniff"
    assert r.headers.get("X-Frame-Options") == "DENY"
    assert "Content-Security-Policy" in r.headers
    assert "Referrer-Policy" in r.headers


# ── FIX 6: /api/suites include_mock=false default ─────────────────────────────

def test_fix6x_list_suites_hides_mock_only_suites_by_default(client, tmp_path, monkeypatch):
    """Suites whose every persisted run is mock-mode (max cost_usd == 0) must be
    omitted unless include_mock=true is passed."""
    _client, Session = client
    # Empty suites dir so the on-disk surfacing branch doesn't add extras
    suites_dir = tmp_path / "suites"
    suites_dir.mkdir()
    monkeypatch.setattr("evalgrid.api.app._suites_base_dir", lambda: suites_dir)

    import asyncio
    from datetime import datetime as _dt, UTC as _UTC
    from evalgrid.api.database import SuiteResultRecord as _SR

    async def seed():
        async with Session() as db:
            # mock-only suite: one run, all scenario_results have cost_usd=0
            db.add(RunRecord(run_id="mock-r", started_at=_dt.now(_UTC),
                             finished_at=_dt.now(_UTC), pass_rate=1.0, passed=1, total=1, results=[]))
            db.add(ScenarioResultRecord(
                run_id="mock-r", scenario_id="x", scenario_name="x", agent_type="generic",
                status="pass", overall_score=1.0, pass_rate=1.0, reasoning="", error=None,
                steps=[], check_results=[], hard_failed=0, prompt_tokens=0,
                completion_tokens=0, cost_usd=0.0,
                started_at=_dt.now(_UTC), finished_at=_dt.now(_UTC),
            ))
            db.add(_SR(run_id="mock-r", suite_id="mock-suite", suite_name="Mock Suite",
                       suite_version=1, pass_threshold=1.0, total=1,
                       semantic_pass_rate=1.0, hard_fail_rate=0, soft_fail_rate=0,
                       error_rate=0, weighted_score=1.0, passed=1))
            # real suite: one run with non-zero cost
            db.add(RunRecord(run_id="real-r", started_at=_dt.now(_UTC),
                             finished_at=_dt.now(_UTC), pass_rate=1.0, passed=1, total=1, results=[]))
            db.add(ScenarioResultRecord(
                run_id="real-r", scenario_id="y", scenario_name="y", agent_type="generic",
                status="pass", overall_score=1.0, pass_rate=1.0, reasoning="", error=None,
                steps=[], check_results=[], hard_failed=0, prompt_tokens=10,
                completion_tokens=10, cost_usd=0.0042,
                started_at=_dt.now(_UTC), finished_at=_dt.now(_UTC),
            ))
            db.add(_SR(run_id="real-r", suite_id="real-suite", suite_name="Real Suite",
                       suite_version=1, pass_threshold=1.0, total=1,
                       semantic_pass_rate=1.0, hard_fail_rate=0, soft_fail_rate=0,
                       error_rate=0, weighted_score=1.0, passed=1))
            await db.commit()
    asyncio.run(seed())

    default = _client.get("/api/suites").json()
    ids_default = {s["suite_id"] for s in default}
    assert "real-suite" in ids_default
    assert "mock-suite" not in ids_default

    with_mock = _client.get("/api/suites?include_mock=true").json()
    ids_with_mock = {s["suite_id"] for s in with_mock}
    assert "real-suite" in ids_with_mock
    assert "mock-suite" in ids_with_mock


# ── FIX 7: evalgrid init scaffolds suites/ ────────────────────────────────────

def test_fix7_init_creates_suites_dir_and_example_suite(tmp_path):
    """`evalgrid init` must create .evalgrid/suites/ + a runnable example suite YAML."""
    from click.testing import CliRunner

    from evalgrid.cli.commands.init import init

    runner = CliRunner()
    result = runner.invoke(init, ["--dir", str(tmp_path), "--yes", "--force"])
    assert result.exit_code == 0, result.output

    suites_dir = tmp_path / ".evalgrid" / "suites"
    example = suites_dir / "example.yml"
    assert suites_dir.is_dir(), "suites/ directory must be scaffolded"
    assert example.exists(), "example.yml suite must be scaffolded"

    # The example suite must reference the example scenario
    text = example.read_text()
    assert "example-hello-world" in text
    assert "id: example" in text


# ── FIX A: POST /api/scenarios (explicit id + slug validation) ────────────────

def test_fixA_create_scenario_writes_yaml_and_round_trips(client, tmp_path, monkeypatch):
    """Creating a scenario writes YAML, returns 201, and GET round-trips it."""
    _client, _ = client
    scen_dir = tmp_path / "scenarios"
    scen_dir.mkdir()
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)

    body = {
        "id": "my-scenario",
        "name": "My Scenario",
        "description": "test desc",
        "prompt": "Say hello in JSON.",
        "test_input": "hi",
        "tags": ["smoke", "demo"],
        "checks": [{"type": "valid_json", "hard_fail": True}],
    }
    r = _client.post("/api/scenarios", json=body)
    assert r.status_code == 201, r.text
    created = r.json()
    assert created["id"] == "my-scenario"
    assert created["check_count"] == 1

    # File on disk
    yaml_path = scen_dir / "my-scenario.yml"
    assert yaml_path.exists()
    text = yaml_path.read_text(encoding="utf-8")
    assert "id: my-scenario" in text
    assert "valid_json" in text

    # Round-trip via GET
    g = _client.get("/api/scenarios/my-scenario")
    assert g.status_code == 200
    data = g.json()
    assert data["id"] == "my-scenario"
    assert data["prompt"] == "Say hello in JSON."
    assert len(data["checks"]) == 1


def test_fixA_create_scenario_duplicate_returns_422(client, tmp_path, monkeypatch):
    _client, _ = client
    scen_dir = tmp_path / "scenarios"
    scen_dir.mkdir()
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)
    body = {"id": "dup", "name": "Dup", "prompt": "Hi there."}

    assert _client.post("/api/scenarios", json=body).status_code == 201
    second = _client.post("/api/scenarios", json=body)
    assert second.status_code == 422
    assert "already exists" in second.json()["detail"]


def test_fixA_path_traversal_in_id_rejected(client, tmp_path, monkeypatch):
    _client, _ = client
    scen_dir = tmp_path / "scenarios"
    scen_dir.mkdir()
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)

    # Windows reserved names (con, prn, nul, com1, lpt1, …) are now blocked
    # alongside the existing traversal/slash/whitespace/uppercase set.
    bad_ids = (
        "../escape", "foo/bar", "foo\\bar", "..", "with space", "UPPER", "",
        "con", "prn", "nul", "com1", "lpt9",
    )
    for bad in bad_ids:
        r = _client.post(
            "/api/scenarios",
            json={"id": bad, "name": "X", "prompt": "test prompt"},
        )
        assert r.status_code == 422, f"id={bad!r} should be rejected but got {r.status_code}"


def test_fixA_missing_required_field_returns_422(client, tmp_path, monkeypatch):
    _client, _ = client
    scen_dir = tmp_path / "scenarios"
    scen_dir.mkdir()
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)

    # missing prompt
    r = _client.post("/api/scenarios", json={"id": "x", "name": "X"})
    assert r.status_code == 422
    # blank prompt
    r2 = _client.post(
        "/api/scenarios", json={"id": "x", "name": "X", "prompt": "   "}
    )
    assert r2.status_code == 422


# ── FIX B: POST /api/suites ───────────────────────────────────────────────────

def _seed_scenario_file(scen_dir, sid: str) -> None:
    scen_dir.mkdir(parents=True, exist_ok=True)
    (scen_dir / f"{sid}.yml").write_text(
        f"id: {sid}\nname: {sid}\nprompt: hi\ntest_input: hi\n"
        f"agent_type: generic\ntags: []\nexpected_actions: []\nchecks: []\n",
        encoding="utf-8",
    )


def test_fixB_create_suite_writes_yaml_and_listed(client, tmp_path, monkeypatch):
    _client, _ = client
    scen_dir = tmp_path / "scenarios"
    suites_dir = tmp_path / "suites"
    _seed_scenario_file(scen_dir, "alpha")
    _seed_scenario_file(scen_dir, "beta")
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)
    monkeypatch.setattr("evalgrid.api.app._suites_base_dir", lambda: suites_dir)

    body = {
        "id": "my-suite",
        "name": "My Suite",
        "description": "a benchmark",
        "scenarios": ["alpha", "beta"],
        "tags": ["nightly"],
    }
    r = _client.post("/api/suites", json=body)
    assert r.status_code == 201, r.text
    created = r.json()
    assert created["suite_id"] == "my-suite"
    assert created["scenario_count"] == 2

    yaml_path = suites_dir / "my-suite.yml"
    assert yaml_path.exists()
    text = yaml_path.read_text(encoding="utf-8")
    assert "id: my-suite" in text
    assert "alpha" in text and "beta" in text

    # Listed via /api/suites (include_mock=true so the un-run on-disk suite shows up)
    g = _client.get("/api/suites?include_mock=true")
    ids = {s["suite_id"] for s in g.json()}
    assert "my-suite" in ids


def test_fixB_duplicate_id_returns_422(client, tmp_path, monkeypatch):
    _client, _ = client
    scen_dir = tmp_path / "scenarios"
    suites_dir = tmp_path / "suites"
    _seed_scenario_file(scen_dir, "alpha")
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)
    monkeypatch.setattr("evalgrid.api.app._suites_base_dir", lambda: suites_dir)

    body = {"id": "dupe", "name": "Dupe", "scenarios": ["alpha"]}
    assert _client.post("/api/suites", json=body).status_code == 201
    r = _client.post("/api/suites", json=body)
    assert r.status_code == 422
    assert "already exists" in r.json()["detail"]


def test_fixB_unknown_scenario_id_returns_422_with_name(client, tmp_path, monkeypatch):
    _client, _ = client
    scen_dir = tmp_path / "scenarios"
    suites_dir = tmp_path / "suites"
    _seed_scenario_file(scen_dir, "alpha")
    monkeypatch.setattr("evalgrid.api.app._scenarios_base_dir", lambda: scen_dir)
    monkeypatch.setattr("evalgrid.api.app._suites_base_dir", lambda: suites_dir)

    r = _client.post(
        "/api/suites",
        json={"id": "bad", "name": "Bad", "scenarios": ["alpha", "ghost", "phantom"]},
    )
    assert r.status_code == 422
    detail = r.json()["detail"]
    assert "ghost" in detail
    assert "phantom" in detail
    assert "alpha" not in detail


def test_fixB_empty_scenarios_returns_422(client, tmp_path, monkeypatch):
    _client, _ = client
    suites_dir = tmp_path / "suites"
    monkeypatch.setattr("evalgrid.api.app._suites_base_dir", lambda: suites_dir)

    r = _client.post(
        "/api/suites",
        json={"id": "empty", "name": "Empty", "scenarios": []},
    )
    assert r.status_code == 422
