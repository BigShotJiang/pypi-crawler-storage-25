# BACKLOG

Tracks deferred work that came out of the v0.1.3 audit and rollout. The fixes
shipped in v0.1.3 are documented in [CHANGELOG.md](./CHANGELOG.md).

## v0.1.4 candidates

- **API key management UI in Settings.** Today provider keys are env-var only; changing them requires restarting `evalgrid server`. Add a UI surface that writes to a local credential store and reloads keys without a restart.
- **Scenario editor.** Create / edit YAMLs from the dashboard. v0.1.3 ships read-only display of the prompt / inputs / actions / checks (FIX 12).
- **Compare runs UI.** Backend ships in v0.1.3 (FIX 2 — `/api/runs/compare` is reachable again). Build the diff visualization on top.
- **Per-attempt flakiness telemetry.** Today we only know pass/fail per run — add which attempts failed, which retried, and retry-distribution histograms.

## v0.2 candidates

- **PR Checks page.** Wire `/pr-checks` to the GitHub Status Check API. Route file is preserved at `dashboard/app/pr-checks/page.tsx`.
- **Reports page.** Implement `/api/reports` plus the UI at `dashboard/app/reports/page.tsx`. Today's CLI `--report` flag writes to disk; the UI surface should index those.
- **Body size limit middleware.** Currently nothing caps `POST /api/runs` or `POST /api/scenarios` body size. The Pydantic field-level `max_length` on `ScenarioCreate` is partial — DoS hardening should add a global limit.
- **XSS sanitization on scenario storage.** Scenarios are stored as raw YAML; the dashboard renders them with React (so script tags don't execute), but values containing HTML are passed through verbatim. Sanitize on write or render with strict CSP.
- **Remove the `judge_model`-sets-both fallback.** v0.1.3 emits a DeprecationWarning when only `judge_model` is provided to `POST /api/runs`; v0.2 should remove the fallback and require `agent_model` to be set explicitly.

## v1.0 candidates

- **Datasets page.** Implement `/datasets` with dataset versioning (JSONL/Parquet/CSV). Route file is preserved at `dashboard/app/datasets/page.tsx`.
- **Multi-tenant auth + workspaces.** Today evalgrid is a single-user local tool. Workspaces, role-based access, and shared run history are v1.0 surfaces.
- **User profiles.** Profile photos and identity ship alongside multi-tenant auth.

## Notes

- All three v0.2+ route files (`/pr-checks`, `/reports`, `/datasets`) are hidden from the sidebar but kept on disk so re-enabling is a one-line nav-list change. Each carries a top-of-file comment pointing here.
- The Playwright audit harness under `dashboard/tests/e2e-audit/` should be re-run before every release. It writes per-spec findings JSON plus a summary `AUDIT_REPORT.md`.
