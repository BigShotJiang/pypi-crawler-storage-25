# Contributing to evalgrid

Thank you for your interest in contributing to evalgrid.

## Prerequisites

- Python 3.11 or newer
- Node.js 18+ (only if working on the dashboard)
- Git

## Dev Setup

```bash
git clone https://github.com/naman006-rai/evalgrid.git
cd evalgrid
pip install -e ".[dev]"
```

This installs evalgrid in editable mode along with test dependencies (pytest, ruff, mypy).

## Running Tests

```bash
pytest tests/ -v
```

All tests must pass before submitting a pull request. The CI workflow runs the full suite automatically.

To run a specific test file:

```bash
pytest tests/test_api.py -v
```

## Dashboard

The dashboard is Next.js 16 + React 19 + Tailwind 4 + shadcn/ui (Radix
under the hood). It compiles to a static export bundled inside the wheel
under `evalgrid/static/`.

### Local dev (hot reload)

In one terminal, start the backend:

```bash
EVALGRID_SCENARIOS_DIR=.evalgrid/scenarios EVALGRID_SUITES_DIR=.evalgrid/suites \
  python -m uvicorn evalgrid.api.app:app --port 8000
```

In another, start the dashboard dev server:

```bash
cd dashboard
npm install
npm run dev    # localhost:3000, proxies /api/* to localhost:8000
```

### Production build (bundled into the wheel)

```bash
cd dashboard
EVALGRID_BUILD=export npm run build
cp -r out/* ../evalgrid/static/    # PowerShell: Copy-Item -Recurse -Force out\* ..\evalgrid\static\
cd ..
python -m build --wheel
```

**Do NOT** add anything under `evalgrid/static/` to `.gitignore`. Hatchling
respects `.gitignore` for wheel inclusion; excluding any part of the static
export silently strips the SPA shells and breaks `/runs/<id>` hard refresh.
This regressed v0.1.3 RC1.

### UI smoke test

After any dashboard change, run the Python Playwright smoke against the
bundled wheel:

```bash
pip install playwright && python -m playwright install chromium
python .claude/skills/webapp-testing/scripts/with_server.py \
  --server "evalgrid server --port 8000" --port 8000 \
  -- python scripts/webapp_smoke.py
```

This runs in CI too — see `.github/workflows/ci.yml :: e2e-smoke`.

### Full Playwright suite (Node)

```bash
cd dashboard
# Backend on 8000 + Next.js dev on 3000 must already be running:
npx playwright test tests/e2e-audit/
```

Specs are flaky in dev when run in batches (Next.js HMR races). Run
specific files when iterating: `npx playwright test 21-create-flow.spec.ts`.

## Code Style

Python code is linted with `ruff` and type-checked with `mypy`:

```bash
ruff check evalgrid/
mypy evalgrid/
```

## PR Guidelines

1. Fork the repo and create a branch: `git checkout -b feat/my-feature`
2. Write tests for your change (keep coverage above 80%)
3. Run the full suite: `pytest tests/ -v`
4. Run linting: `ruff check evalgrid/`
5. Open a pull request against `main` with a clear description of what changes and why
6. CI will run evals and tests automatically — fix any failures before requesting review

## Reporting Issues

Open a GitHub issue at <https://github.com/naman006-rai/evalgrid/issues>.

Include:
- evalgrid version (`pip show evalgrid`)
- Python version (`python --version`)
- Steps to reproduce
- Expected vs actual behavior
