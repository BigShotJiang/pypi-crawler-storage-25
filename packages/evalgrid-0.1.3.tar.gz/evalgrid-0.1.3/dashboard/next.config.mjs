/** @type {import('next').NextConfig} */
import { execSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const isProd = process.env.EVALGRID_BUILD === 'export';

// Deterministic BUILD_ID so two wheels of the same release are byte-equivalent.
// Priority: EVALGRID_BUILD_ID env (CI/release override) → project version from
// ../pyproject.toml (stable across commits in a release) → short git SHA
// (dev only) → literal fallback (source tarballs without git or pyproject).
// The version source is the right primary: BUILD_ID changes per release so
// stale assets invalidate, but doesn't churn per-commit during development.
function resolveBuildId() {
  if (process.env.EVALGRID_BUILD_ID) return process.env.EVALGRID_BUILD_ID;
  try {
    const here = dirname(fileURLToPath(import.meta.url));
    const pyproject = readFileSync(resolve(here, '..', 'pyproject.toml'), 'utf8');
    const m = pyproject.match(/^version\s*=\s*"([^"]+)"/m);
    if (m) return `v${m[1]}`;
  } catch {
    /* fall through */
  }
  try {
    return execSync('git rev-parse HEAD', { stdio: ['ignore', 'pipe', 'ignore'] })
      .toString()
      .trim()
      .slice(0, 12);
  } catch {
    return 'evalgrid-nogit';
  }
}

const baseConfig = {
  // Surface TS errors at build time — silent rot was hiding regressions
  // (see audit P2: dashboard ships whatever typecheck-fails locally).
  typescript: {
    ignoreBuildErrors: false,
  },
  images: {
    unoptimized: true,
  },
  outputFileTracingRoot: process.cwd(),
  generateBuildId: () => resolveBuildId(),
};

// In dev, proxy /api/* to FastAPI. In the static-export build the dashboard
// is served by FastAPI on the same origin, so /api/* resolves natively.
// EVALGRID_API_URL lets contributors run the backend on a different port or
// host (e.g. `EVALGRID_API_URL=http://127.0.0.1:8001 npm run dev`) without
// editing this file — useful when one port is held by another worktree.
const devBackend = (process.env.EVALGRID_API_URL || 'http://localhost:8000').replace(/\/$/, '');
const devConfig = {
  ...baseConfig,
  async rewrites() {
    return [
      { source: '/api/:path*', destination: `${devBackend}/api/:path*` },
    ];
  },
};

const exportConfig = {
  ...baseConfig,
  output: 'export',
  trailingSlash: true,
};

export default isProd ? exportConfig : devConfig;
