import { test, expect } from "@playwright/test";
import { startSurvey, networkErrors, safeScreenshot } from "./helpers";
import * as fs from "fs";

const NAME = "08-datasets";

test("Datasets route — coming-in-v0.3 empty state", async ({ page }) => {
  const survey = startSurvey(page);
  const findings: Record<string, any> = { route: "/datasets" };

  await page.goto("/datasets", { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(500);

  findings.consoleErrors = survey.consoleErrors.length;
  findings.networkErrors = networkErrors(survey).map((n) => `${n.method} ${n.url} → ${n.status}`);
  findings.unexpectedApiCalls = survey.network
    .filter((n) => n.url.includes("/api/"))
    .map((n) => n.url);
  findings.emptyStateVisible = await page
    .locator("text=Datasets ship in a future release")
    .isVisible()
    .catch(() => false);

  for (const s of [
    { w: 1920, h: 1080 },
    { w: 1440, h: 900 },
    { w: 768, h: 1024 },
    { w: 375, h: 667 },
  ]) {
    await page.setViewportSize({ width: s.w, height: s.h });
    await page.waitForTimeout(150);
    await safeScreenshot(page, `tests/e2e-audit/screenshots/${NAME}-${s.w}x${s.h}.png`);
  }

  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}.json`, JSON.stringify(findings, null, 2));
  expect(survey.pageErrors).toEqual([]);
});
