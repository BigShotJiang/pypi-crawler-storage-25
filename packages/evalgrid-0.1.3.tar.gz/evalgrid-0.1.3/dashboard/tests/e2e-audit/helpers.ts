import type { Page, ConsoleMessage, Request, Response } from "@playwright/test";

export interface NetworkLog {
  url: string;
  method: string;
  status: number | null;
  ok: boolean;
  timing: number; // ms
}

export interface ConsoleLog {
  type: string;
  text: string;
  location?: string;
}

export interface RouteSurvey {
  consoleErrors: ConsoleLog[];
  consoleWarnings: ConsoleLog[];
  network: NetworkLog[];
  pageErrors: string[];
}

/** Attach observers and return a survey object that accumulates issues until the test ends. */
export function startSurvey(page: Page): RouteSurvey {
  const survey: RouteSurvey = {
    consoleErrors: [],
    consoleWarnings: [],
    network: [],
    pageErrors: [],
  };

  page.on("console", (msg: ConsoleMessage) => {
    const entry: ConsoleLog = {
      type: msg.type(),
      text: msg.text(),
      location: msg.location()?.url,
    };
    if (msg.type() === "error") survey.consoleErrors.push(entry);
    else if (msg.type() === "warning") survey.consoleWarnings.push(entry);
  });

  page.on("pageerror", (err: Error) => {
    survey.pageErrors.push(err.message);
  });

  const inflight = new Map<Request, number>();
  page.on("request", (req: Request) => inflight.set(req, Date.now()));
  page.on("requestfailed", (req: Request) => {
    const started = inflight.get(req);
    inflight.delete(req);
    survey.network.push({
      url: req.url(),
      method: req.method(),
      status: null,
      ok: false,
      timing: started ? Date.now() - started : 0,
    });
  });
  page.on("response", (res: Response) => {
    const req = res.request();
    const started = inflight.get(req);
    inflight.delete(req);
    survey.network.push({
      url: res.url(),
      method: req.method(),
      status: res.status(),
      ok: res.ok(),
      timing: started ? Date.now() - started : 0,
    });
  });

  return survey;
}

export function isApiCall(url: string): boolean {
  return url.includes("/api/");
}

export function networkErrors(survey: RouteSurvey): NetworkLog[] {
  return survey.network.filter((n) => isApiCall(n.url) && (n.status === null || n.status >= 400));
}

export async function safeScreenshot(page: Page, path: string): Promise<void> {
  try {
    await page.screenshot({ path, fullPage: true });
  } catch {
    // ignore — page may already be closing
  }
}
