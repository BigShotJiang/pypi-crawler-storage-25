import { test, expect } from "@playwright/test";
import { startSurvey, networkErrors, safeScreenshot } from "./helpers";
import * as fs from "fs";

const NAME = "03-run-detail";

test.describe("Run Detail route", () => {
  test("fetches /api/runs/{id}, renders scenarios + cost", async ({ page, request }) => {
    const findings: Record<string, any> = { route: "/runs/{id}" };

    const runsResp = await request.get("http://localhost:8000/api/runs");
    if (!runsResp.ok()) {
      findings.skipped = `GET /api/runs → ${runsResp.status()}`;
      fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}.json`, JSON.stringify(findings, null, 2));
      test.skip();
      return;
    }
    const runs = (await runsResp.json()) as any[];
    if (runs.length === 0) {
      findings.skipped = "no runs in DB — cannot test detail";
      fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}.json`, JSON.stringify(findings, null, 2));
      test.skip();
      return;
    }

    const run = runs.find((r) => r.status === "completed") ?? runs[0];
    findings.testedRunId = run.run_id;

    const survey = startSurvey(page);
    await page.goto(`/runs/${run.run_id}`, { waitUntil: "domcontentloaded" });
    await page.waitForTimeout(1000);

    findings.consoleErrors = survey.consoleErrors.length;
    findings.networkErrors = networkErrors(survey).map((n) => `${n.method} ${n.url} → ${n.status}`);
    findings.apiCalls = survey.network
      .filter((n) => n.url.includes("/api/"))
      .map((n) => `${n.method} ${n.url} → ${n.status} (${n.timing}ms)`);

    findings.title = await page.getByTestId("run-detail-title").textContent();
    findings.passRateDisplay = await page.getByTestId("run-detail-pass-rate").textContent().catch(() => null);
    findings.passedCount = await page.getByTestId("run-detail-passed").textContent().catch(() => null);
    findings.failedCount = await page.getByTestId("run-detail-failed").textContent().catch(() => null);
    findings.costDisplay = await page.getByTestId("run-detail-cost").textContent().catch(() => null);

    const apiDetail = await request.get(`http://localhost:8000/api/runs/${run.run_id}`);
    if (apiDetail.ok()) {
      const detail = await apiDetail.json();
      findings.apiPassed = detail.passed;
      findings.apiTotal = detail.total;
      findings.apiPassRate = detail.pass_rate;
      findings.apiScenarioCount = (detail.scenario_results || []).length;
      const rowCount = await page.locator('[data-testid^="scenario-row-"]').count();
      findings.uiScenarioRowCount = rowCount;
      findings.uiMatchesApi = rowCount === findings.apiScenarioCount;
      const totalCostApi = (detail.scenario_results || []).reduce(
        (acc: number, s: any) => acc + (s.cost_usd || 0),
        0,
      );
      findings.apiTotalCost = totalCostApi;
    }

    // 404 path
    const badPage = await page.context().newPage();
    await badPage.goto(`/runs/this-id-definitely-does-not-exist-${Date.now()}`, { waitUntil: "domcontentloaded" });
    await badPage.waitForTimeout(500);
    findings.badId_errorVisible = await badPage.locator("text=Failed to load:").isVisible().catch(() => false);
    await badPage.close();

    for (const s of [
      { w: 1920, h: 1080 },
      { w: 1440, h: 900 },
      { w: 768, h: 1024 },
      { w: 375, h: 667 },
    ]) {
      await page.setViewportSize({ width: s.w, height: s.h });
      await page.waitForTimeout(200);
      await safeScreenshot(page, `tests/e2e-audit/screenshots/${NAME}-${s.w}x${s.h}.png`);
    }

    fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}.json`, JSON.stringify(findings, null, 2));
    expect(survey.pageErrors).toEqual([]);
  });
});
