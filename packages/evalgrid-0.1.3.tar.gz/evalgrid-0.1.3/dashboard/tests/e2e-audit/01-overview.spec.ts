import { test, expect } from "@playwright/test";
import { startSurvey, networkErrors, safeScreenshot } from "./helpers";
import * as fs from "fs";
import * as path from "path";

const ROUTE = "/";
const NAME = "01-overview";

test.describe("Overview route", () => {
  test("renders, fetches API, surveys elements, captures viewports", async ({ page, browser }) => {
    const survey = startSurvey(page);
    const findings: Record<string, any> = { route: ROUTE };

    await page.goto(ROUTE, { waitUntil: "domcontentloaded" });
    await page.waitForTimeout(1500);

    // RENDER
    await expect(page.getByTestId("page-title")).toHaveText("Overview");
    findings.title_ok = true;
    findings.consoleErrors = survey.consoleErrors.length;
    findings.pageErrors = survey.pageErrors;
    findings.networkErrors = networkErrors(survey).map((n) => `${n.method} ${n.url} → ${n.status}`);
    findings.apiCalls = survey.network
      .filter((n) => n.url.includes("/api/"))
      .map((n) => `${n.method} ${n.url} → ${n.status} (${n.timing}ms)`);

    // KPI cards
    const statCards = await page.locator('[data-testid^="stat-card-"]').all();
    findings.statCardCount = statCards.length;
    findings.statCardValues = [];
    for (const c of statCards) {
      const title = (await c.locator(".uppercase").first().textContent())?.trim() ?? "";
      const value = (await c.locator(".text-2xl").first().textContent())?.trim() ?? "";
      findings.statCardValues.push({ title, value });
    }

    // Cross-reference with API
    const apiResp = await page.request.get("http://localhost:8000/api/runs");
    if (apiResp.ok()) {
      const runs = await apiResp.json();
      findings.apiRunCount = runs.length;
      findings.apiCompletedCount = runs.filter((r: any) => r.status === "completed").length;
      const totalRunsCard = findings.statCardValues.find((c: any) => c.title.includes("TOTAL RUNS"));
      findings.totalRunsMatchesApi =
        totalRunsCard && String(runs.length) === totalRunsCard.value;
    } else {
      findings.apiUnreachable = `GET /api/runs → ${apiResp.status()}`;
    }

    // Recent Runs Table
    const recentRunsRows = await page.locator('[data-testid^="run-row-"]').count();
    findings.recentRunsRows = recentRunsRows;

    // Empty / data states
    findings.emptyStates = {
      reliabilityChart: await page.getByTestId("reliability-chart-empty").isVisible().catch(() => false),
      regressionBreakdown: await page.getByTestId("regression-breakdown-empty").isVisible().catch(() => false),
      flakySuites: await page.getByTestId("flaky-suites-empty").isVisible().catch(() => false),
      failedScenarios: await page.getByTestId("failed-scenarios-empty").isVisible().catch(() => false),
      recentRuns: await page.getByTestId("recent-runs-empty").isVisible().catch(() => false),
    };
    findings.chartsRendered = {
      reliability: await page.getByTestId("reliability-chart").isVisible().catch(() => false),
      regression: await page.getByTestId("regression-breakdown").isVisible().catch(() => false),
    };

    // Screenshots at 4 viewports
    const sizes = [
      { w: 1920, h: 1080 },
      { w: 1440, h: 900 },
      { w: 768, h: 1024 },
      { w: 375, h: 667 },
    ];
    for (const s of sizes) {
      await page.setViewportSize({ width: s.w, height: s.h });
      await page.waitForTimeout(300);
      await safeScreenshot(page, `tests/e2e-audit/screenshots/${NAME}-${s.w}x${s.h}.png`);
    }

    // Layout-shift detection (revisit) — re-load, capture two snapshots 2s apart
    await page.setViewportSize({ width: 1920, height: 1080 });
    await page.goto(ROUTE, { waitUntil: "domcontentloaded" });
    const initialBB = await page.locator("body").boundingBox();
    await page.waitForTimeout(2000);
    const settledBB = await page.locator("body").boundingBox();
    findings.bodyHeightShift = initialBB && settledBB ? Math.abs((settledBB.height || 0) - (initialBB.height || 0)) : null;

    // Tab through interactive elements
    const interactiveCount = await page.locator("button, a, input, select, textarea, [tabindex]").count();
    findings.interactiveCount = interactiveCount;

    // Save findings JSON
    const out = path.join("tests/e2e-audit/test-results", `${NAME}.json`);
    fs.mkdirSync(path.dirname(out), { recursive: true });
    fs.writeFileSync(out, JSON.stringify(findings, null, 2));

    // Don't fail just because mocks aren't present; this is a SURVEY test.
    expect(survey.pageErrors).toEqual([]);
  });
});
