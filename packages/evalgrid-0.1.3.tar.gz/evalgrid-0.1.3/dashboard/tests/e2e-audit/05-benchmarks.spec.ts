import { test, expect } from "@playwright/test";
import { startSurvey, networkErrors, safeScreenshot } from "./helpers";
import * as fs from "fs";

const NAME = "05-benchmarks";

test("Benchmarks route", async ({ page, request }) => {
  const survey = startSurvey(page);
  const findings: Record<string, any> = { route: "/benchmarks" };

  await page.goto("/benchmarks", { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(1000);

  await expect(page.getByTestId("page-title")).toHaveText("Benchmarks");

  findings.consoleErrors = survey.consoleErrors.length;
  findings.networkErrors = networkErrors(survey).map((n) => `${n.method} ${n.url} → ${n.status}`);
  findings.apiCalls = survey.network
    .filter((n) => n.url.includes("/api/"))
    .map((n) => `${n.method} ${n.url} → ${n.status} (${n.timing}ms)`);

  const apiResp = await request.get("http://localhost:8000/api/suites");
  if (apiResp.ok()) {
    const suites = (await apiResp.json()) as any[];
    findings.apiSuiteCount = suites.length;
  }
  findings.uiCardCount = await page.locator('[data-testid^="benchmark-card-"]').count();

  await page.getByTestId("benchmarks-search").fill("zzzzzzzz");
  await page.waitForTimeout(200);
  findings.search_no_match = await page.locator('[data-testid^="benchmark-card-"]').count();
  await page.getByTestId("benchmarks-search").fill("");

  for (const s of [
    { w: 1920, h: 1080 },
    { w: 1440, h: 900 },
    { w: 768, h: 1024 },
    { w: 375, h: 667 },
  ]) {
    await page.setViewportSize({ width: s.w, height: s.h });
    await page.waitForTimeout(200);
    await safeScreenshot(page, `tests/e2e-audit/screenshots/${NAME}-${s.w}x${s.h}.png`);
  }

  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}.json`, JSON.stringify(findings, null, 2));
  expect(survey.pageErrors).toEqual([]);
});
