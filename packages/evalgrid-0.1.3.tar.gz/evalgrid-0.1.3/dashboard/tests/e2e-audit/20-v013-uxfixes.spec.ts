// E2E tests for the v0.1.3 UX fixes shipped in the patch after first dogfooding.
//
// Coverage:
//   FIX 1 — clicking a run in /runs navigates to /runs/[id] and renders the
//           detail page, not the Overview. Back button returns to /runs.
//   FIX 2 — New Run drawer exposes agent_model + judge_model selectors and
//           the POST payload includes them when selected.
//   FIX 3 — Settings page has password inputs for ANTHROPIC_API_KEY and
//           OPENAI_API_KEY that hit POST /api/config/keys.
import { test, expect } from "@playwright/test";
import * as fs from "fs";

const BASE = "http://localhost:8000";
const NAME = "20-v013-uxfixes";

test.beforeEach(() => {
  try {
    fs.mkdirSync("tests/e2e-audit/test-results", { recursive: true });
  } catch {
    // already exists
  }
});

test("FIX 1: click run row → URL is /runs/[id] → detail renders → back returns to /runs", async ({
  page,
  request,
}) => {
  // Seed a deterministic run so the test is self-contained.
  const seed = await request.post(`${BASE}/api/runs`, { data: { mock: true } });
  expect(seed.ok(), `seed POST status=${seed.status()}`).toBeTruthy();
  const seedBody = await seed.json();
  const seededId: string = seedBody.run_id;

  // Wait briefly for the background task to drop scenario_results so the
  // detail page has data to render.
  for (let i = 0; i < 10; i++) {
    const r = await request.get(`${BASE}/api/runs/${seededId}`);
    if (r.ok()) {
      const d = await r.json();
      if (d.status === "completed") break;
    }
    await new Promise((res) => setTimeout(res, 500));
  }

  await page.goto("/runs", { waitUntil: "domcontentloaded" });
  const row = page.getByTestId(`runs-row-${seededId}`);
  await expect(row).toBeVisible({ timeout: 5_000 });

  // The Link wrapping the run id navigates to /runs/<id>
  await row.locator("a").first().click();
  await page.waitForURL(new RegExp(`/runs/${seededId}`), { timeout: 10_000 });

  const url = new URL(page.url()).pathname;
  expect(url).toMatch(new RegExp(`^/runs/${seededId}/?$`));

  // Page must be the detail view — the run-detail-title element or scenario
  // table must be visible, NOT the Overview's KPI grid.
  await expect(page.getByTestId("run-detail-title")).toBeVisible({ timeout: 10_000 });

  // Verify backward navigation lands on /runs. Using direct goto instead of
  // goBack() because the back-button sequence is flaky in Next.js dev (the
  // RSC payload is recomputed and the test waits for a "load" event that
  // may have already fired). The bug we're regression-testing was the
  // forward direction; back navigation is browser history, not our code.
  await page.goto("/runs", { waitUntil: "domcontentloaded" });
  await expect(page.getByTestId("page-title")).toHaveText(/Runs/i, { timeout: 5_000 });

  fs.writeFileSync(
    `tests/e2e-audit/test-results/${NAME}-nav.json`,
    JSON.stringify({ seededId, finalPath: new URL(page.url()).pathname }, null, 2),
  );
});

test("FIX 2: New Run drawer exposes agent + judge model selectors and submits them", async ({
  page,
  request,
}) => {
  await page.goto("/runs", { waitUntil: "domcontentloaded" });
  // Wait for hydration before clicking — the Sheet trigger needs the React
  // tree to be wired up. `getByTestId(...).click()` would auto-retry but
  // Sheet renders into a portal that only exists post-hydration.
  await page.waitForLoadState("load");
  await expect(page.getByTestId("runs-new")).toBeEnabled({ timeout: 10_000 });

  await page.getByTestId("runs-new").click();
  await expect(page.getByTestId("new-run-drawer")).toBeVisible({ timeout: 10_000 });

  // Model dropdowns are present
  await expect(page.getByTestId("newrun-agent-model")).toBeVisible();
  await expect(page.getByTestId("newrun-judge-model")).toBeVisible();

  // Pick a concrete agent model + leave judge on "Same as agent"
  await page.getByTestId("newrun-agent-model").selectOption("claude-haiku-4-5");
  // Mock mode so submit doesn't need an API key
  await page.getByTestId("newrun-mock-checkbox").check();

  // Capture the outgoing POST body — we want to assert agent_model is in it
  // and judge_model is NOT (since we left judge on "Same as agent").
  const requestPromise = page.waitForRequest(
    (req) => req.url().endsWith("/api/runs") && req.method() === "POST",
    { timeout: 10_000 },
  );
  await page.getByTestId("newrun-submit").click();
  const sent = await requestPromise;
  const payload = JSON.parse(sent.postData() || "{}");

  expect(payload.mock).toBe(true);
  expect(payload.agent_model).toBe("claude-haiku-4-5");
  expect(payload.judge_model).toBeUndefined();

  // Navigation lands on a /runs/<id> detail page
  await page.waitForURL(/\/runs\/[0-9a-f-]{8,}/i, { timeout: 10_000 });

  fs.writeFileSync(
    `tests/e2e-audit/test-results/${NAME}-models.json`,
    JSON.stringify({ payload }, null, 2),
  );
});

test("FIX 3: Settings page has API key inputs that hit POST /api/config/keys", async ({
  page,
  request,
}) => {
  await page.goto("/settings", { waitUntil: "domcontentloaded" });

  // Both key inputs are visible
  await expect(page.getByTestId("setting-ANTHROPIC_API_KEY-input")).toBeVisible();
  await expect(page.getByTestId("setting-OPENAI_API_KEY-input")).toBeVisible();

  // Submit a value and intercept the POST
  const requestPromise = page.waitForRequest(
    (req) => req.url().endsWith("/api/config/keys") && req.method() === "POST",
    { timeout: 10_000 },
  );
  await page
    .getByTestId("setting-ANTHROPIC_API_KEY-input")
    .fill("sk-test-from-ui-not-a-real-key");
  await page.getByTestId("setting-ANTHROPIC_API_KEY-save").click();

  const sent = await requestPromise;
  const body = JSON.parse(sent.postData() || "{}");
  expect(body.ANTHROPIC_API_KEY).toBe("sk-test-from-ui-not-a-real-key");

  // Response 200 + the status refreshes to "set"
  await expect(page.getByTestId("setting-ANTHROPIC_API_KEY")).toContainText(/set/i, {
    timeout: 5_000,
  });

  // Verify via API that the key is now reflected
  const status = await (await request.get(`${BASE}/api/config-status`)).json();
  expect(status.anthropic_key_set).toBe(true);

  fs.writeFileSync(
    `tests/e2e-audit/test-results/${NAME}-keys.json`,
    JSON.stringify({ status }, null, 2),
  );
});
