import { test, expect } from "@playwright/test";
import * as fs from "fs";

const BASE = "http://localhost:8000";
const NAME = "15-scenarios-api";

test("GET /api/scenarios — shape & performance", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "/api/scenarios" };
  const t0 = Date.now();
  const r = await request.get(`${BASE}/api/scenarios`);
  findings.status = r.status();
  findings.elapsedMs = Date.now() - t0;
  if (r.ok()) {
    const body = (await r.json()) as any[];
    findings.count = body.length;
    findings.isArray = Array.isArray(body);
    if (body.length > 0) {
      findings.requiredFieldsPresent = [
        "id",
        "name",
        "agent_type",
        "tags",
        "step_count",
        "suite",
      ].every((k) => k in body[0]);
      findings.sampleKeys = Object.keys(body[0]);
    }
  }
  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-list.json`, JSON.stringify(findings, null, 2));
  expect(findings.status).toBe(200);
});

test("GET /api/scenarios — path traversal rejected via scenarios_dir param", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "/api/scenarios?scenarios_dir=" };
  const r = await request.get(`${BASE}/api/scenarios?scenarios_dir=${encodeURIComponent("../../etc")}`);
  findings.status = r.status();
  findings.rejected = r.status() === 400 || r.status() === 422;
  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-traversal.json`, JSON.stringify(findings, null, 2));
});

test("POST /api/scenarios — required field validation", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "POST /api/scenarios" };
  const empty = await request.post(`${BASE}/api/scenarios`, { data: {} });
  findings.empty_status = empty.status();

  const xss = await request.post(`${BASE}/api/scenarios`, {
    data: {
      name: `audit-xss-${Date.now()}`,
      description: "",
      agent_type: "generic",
      prompt: "<script>alert(1)</script>",
      test_input: "hello",
      expected_actions: [],
      tags: [],
      scenarios_dir: "",
    },
  });
  findings.xss_status = xss.status();
  findings.xss_body = (await xss.text()).slice(0, 200);

  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-post.json`, JSON.stringify(findings, null, 2));
});
