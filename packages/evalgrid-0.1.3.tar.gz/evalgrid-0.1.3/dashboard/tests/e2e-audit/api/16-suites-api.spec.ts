import { test, expect } from "@playwright/test";
import * as fs from "fs";

const BASE = "http://localhost:8000";
const NAME = "16-suites-api";

test("GET /api/suites — shape & performance", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "/api/suites" };
  const t0 = Date.now();
  const r = await request.get(`${BASE}/api/suites`);
  findings.status = r.status();
  findings.elapsedMs = Date.now() - t0;
  if (r.ok()) {
    const body = (await r.json()) as any[];
    findings.count = body.length;
    if (body.length > 0) {
      findings.requiredFieldsPresent = [
        "suite_id",
        "suite_name",
        "run_count",
        "latest_run",
        "latest_passed",
      ].every((k) => k in body[0]);
      findings.sampleKeys = Object.keys(body[0]);
    }
  }
  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-list.json`, JSON.stringify(findings, null, 2));
  expect(findings.status).toBe(200);
});

test("GET /api/suites/{id}/history — 200 or 404", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "/api/suites/{id}/history" };
  const list = await request.get(`${BASE}/api/suites`);
  if (list.ok()) {
    const suites = (await list.json()) as any[];
    if (suites.length > 0) {
      const r = await request.get(`${BASE}/api/suites/${suites[0].suite_id}/history`);
      findings.happy_status = r.status();
      if (r.ok()) {
        const body = (await r.json()) as any[];
        findings.history_count = body.length;
      }
    } else {
      findings.skipped = "no suites";
    }
  }
  // Bad id
  const bad = await request.get(`${BASE}/api/suites/__nope__/history`);
  findings.bad_status = bad.status();
  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-history.json`, JSON.stringify(findings, null, 2));
});
