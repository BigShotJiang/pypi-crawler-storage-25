import { test, expect } from "@playwright/test";
import * as fs from "fs";

const BASE = "http://localhost:8000";
const NAME = "17-flakiness-api";

test("GET /api/flakiness — window sweep", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "/api/flakiness", windows: {} };
  for (const w of [1, 5, 10, 20, 50]) {
    const t0 = Date.now();
    const r = await request.get(`${BASE}/api/flakiness?window=${w}`);
    const ms = Date.now() - t0;
    if (r.ok()) {
      const body = (await r.json()) as any[];
      findings.windows[`w${w}`] = {
        status: r.status(),
        elapsedMs: ms,
        count: body.length,
        flakyCount: body.filter((x) => x.is_flaky).length,
      };
    } else {
      findings.windows[`w${w}`] = { status: r.status(), error: (await r.text()).slice(0, 100) };
    }
  }
  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}.json`, JSON.stringify(findings, null, 2));
});

test("GET /api/flakiness — bad window param", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "/api/flakiness?window=bad" };
  const r = await request.get(`${BASE}/api/flakiness?window=not-a-number`);
  findings.status = r.status();
  findings.rejected = r.status() === 422 || r.status() === 400;
  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-bad.json`, JSON.stringify(findings, null, 2));
});
