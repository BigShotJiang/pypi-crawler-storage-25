import { test, expect } from "@playwright/test";
import * as fs from "fs";

const BASE = "http://localhost:8000";
const NAME = "18-misc-api";

test("GET /api/config-status", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "/api/config-status" };
  const r = await request.get(`${BASE}/api/config-status`);
  findings.status = r.status();
  if (r.ok()) {
    const body = await r.json();
    findings.body = body;
    findings.shapeOk = [
      "anthropic_key_set",
      "openai_key_set",
      "any_key_set",
      "mock_available",
    ].every((k) => k in body);
  }
  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-config.json`, JSON.stringify(findings, null, 2));
  expect(findings.status).toBe(200);
});

test("GET /api/runs/compare — needs base & head params", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "/api/runs/compare" };

  // No params
  const noParams = await request.get(`${BASE}/api/runs/compare`);
  findings.noParams_status = noParams.status();

  const list = await request.get(`${BASE}/api/runs`);
  const runs = (await list.json()) as any[];
  if (runs.length >= 2) {
    const t0 = Date.now();
    const ok = await request.get(
      `${BASE}/api/runs/compare?base=${runs[1].run_id}&head=${runs[0].run_id}`,
    );
    findings.happy_status = ok.status();
    findings.happy_elapsedMs = Date.now() - t0;
    if (ok.ok()) {
      const body = await ok.json();
      findings.shapeOk =
        "scenarios" in body && "summary" in body && "base_run_id" in body && "head_run_id" in body;
      findings.summary = body.summary;
    } else {
      findings.happy_error = (await ok.text()).slice(0, 200);
    }
  } else {
    findings.skipped_happyPath = "needs at least 2 runs";
  }

  // 404 with bogus ids
  const bogus = await request.get(`${BASE}/api/runs/compare?base=__nope1__&head=__nope2__`);
  findings.bogus_status = bogus.status();
  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-compare.json`, JSON.stringify(findings, null, 2));
});

test("GET /health", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "/health" };
  const r = await request.get(`${BASE}/health`);
  findings.status = r.status();
  findings.body = r.ok() ? await r.json() : await r.text();
  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-health.json`, JSON.stringify(findings, null, 2));
  expect(findings.status).toBe(200);
});

test("CORS preflight / unsupported route returns 404, not 500", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "/api/__nope__" };
  const r = await request.get(`${BASE}/api/this-endpoint-does-not-exist`);
  findings.status = r.status();
  findings.is404 = r.status() === 404;
  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-404.json`, JSON.stringify(findings, null, 2));
});
