import { test, expect } from "@playwright/test";
import * as fs from "fs";

const BASE = "http://localhost:8000";
const NAME = "14-runs-api";

test("GET /api/runs — happy path, shape, performance", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "/api/runs" };
  const t0 = Date.now();
  const r = await request.get(`${BASE}/api/runs`);
  findings.status = r.status();
  findings.elapsedMs = Date.now() - t0;
  findings.ok = r.ok();
  if (r.ok()) {
    const body = await r.json();
    findings.isArray = Array.isArray(body);
    findings.count = body.length;
    if (body.length > 0) {
      const sample = body[0];
      findings.requiredFieldsPresent = [
        "run_id",
        "started_at",
        "pass_rate",
        "passed",
        "total",
        "status",
        "scenario_names",
        "skipped_count",
      ].every((k) => k in sample);
      findings.sampleKeys = Object.keys(sample);
    }
  } else {
    findings.error = await r.text();
  }
  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-list.json`, JSON.stringify(findings, null, 2));
  expect(findings.status).toBe(200);
});

test("GET /api/runs/{id} — happy and 404", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "/api/runs/{id}" };
  const list = await request.get(`${BASE}/api/runs`);
  const runs = (await list.json()) as any[];
  if (runs.length === 0) {
    findings.skipped = "no runs to test";
    fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-detail.json`, JSON.stringify(findings, null, 2));
    return;
  }
  const t0 = Date.now();
  const r = await request.get(`${BASE}/api/runs/${runs[0].run_id}`);
  findings.happyStatus = r.status();
  findings.happyElapsedMs = Date.now() - t0;
  if (r.ok()) {
    const d = await r.json();
    findings.shapeOk = "scenario_results" in d && "run_id" in d;
    findings.scenarioCount = (d.scenario_results || []).length;
  }
  const r404 = await request.get(`${BASE}/api/runs/__definitely_does_not_exist__`);
  findings.notFoundStatus = r404.status();
  findings.notFoundIsExpected = r404.status() === 404;

  // SQL injection-style
  const rSqli = await request.get(`${BASE}/api/runs/${encodeURIComponent("'+OR+1=1")}`);
  findings.sqliStatus = rSqli.status();
  findings.sqliSafe = rSqli.status() === 404 || rSqli.status() === 422 || rSqli.status() === 400;

  // Path traversal-style on id
  const rTrav = await request.get(`${BASE}/api/runs/${encodeURIComponent("../../etc/passwd")}`);
  findings.traversalStatus = rTrav.status();

  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-detail.json`, JSON.stringify(findings, null, 2));
});

test("POST /api/runs — bad input handling", async ({ request }) => {
  const findings: Record<string, any> = { endpoint: "POST /api/runs" };

  // Empty body
  const empty = await request.post(`${BASE}/api/runs`, { data: {} });
  findings.empty_status = empty.status();
  findings.empty_body = (await empty.text()).slice(0, 200);

  // Wrong type
  const wrongType = await request.post(`${BASE}/api/runs`, {
    data: { scenarios_dir: 123 as any, tags: "not-a-list" as any, mock: "yes" as any },
  });
  findings.wrongType_status = wrongType.status();

  // Path traversal in scenarios_dir
  const trav = await request.post(`${BASE}/api/runs`, {
    data: { scenarios_dir: "../../etc", tags: [], scenario_ids: [], mock: true },
  });
  findings.traversal_status = trav.status();
  findings.traversal_rejected = trav.status() === 400 || trav.status() === 422;

  // Oversized payload
  const big = await request.post(`${BASE}/api/runs`, {
    data: { scenarios_dir: "x".repeat(1_000_000), tags: [], scenario_ids: [], mock: true },
  });
  findings.oversized_status = big.status();

  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-post.json`, JSON.stringify(findings, null, 2));
});
