// End-to-end create flow: scenario → benchmark → run via UI dialogs.
// Covers FIX A (POST /api/scenarios), FIX B (POST /api/suites), FIX C/D dialogs.

import { test, expect } from "@playwright/test";
import * as fs from "fs";

const BASE = "http://localhost:8000";
const NAME = "21-create-flow";

test.beforeEach(() => {
  try {
    fs.mkdirSync("tests/e2e-audit/test-results", { recursive: true });
  } catch {
    // already exists
  }
});

test("Create scenario → benchmark → run from the dashboard", async ({ page, request }) => {
  // Unique ids per run so the test is idempotent across re-runs without
  // touching the DB. The leading "e2e-" prefix lets cleanup-audit-data.py
  // recognise them — they're already in SCENARIO_PREFIXES.
  const stamp = Date.now().toString(36);
  const scenarioId = `e2e-demo-${stamp}`;
  const suiteId = `e2e-demo-suite-${stamp}`;

  // ── Scenario create ────────────────────────────────────────────────────────
  await page.goto("/scenarios", { waitUntil: "domcontentloaded" });
  await page.waitForLoadState("load");
  await expect(page.getByTestId("scenarios-new")).toBeEnabled({ timeout: 10_000 });

  await page.getByTestId("scenarios-new").click();
  await expect(page.getByTestId("new-scenario-dialog")).toBeVisible({ timeout: 10_000 });

  await page.getByTestId("newscen-id").fill(scenarioId);
  await page.getByTestId("newscen-name").fill(`E2E Demo ${stamp}`);
  await page.getByTestId("newscen-prompt").fill("Say hello in valid JSON.");
  await page.getByTestId("newscen-test-input").fill("hello");
  await page.getByTestId("newscen-tags").fill("e2e, smoke");

  // Add a valid_json check to exercise the checks array
  await page.getByTestId("newscen-add-check").click();
  await expect(page.getByTestId("newscen-check-0")).toBeVisible();

  // Capture the POST so we can assert payload shape
  const createScenarioReqP = page.waitForRequest(
    (req) => req.url().endsWith("/api/scenarios") && req.method() === "POST",
    { timeout: 10_000 },
  );
  await page.getByTestId("newscen-submit").click();
  const createScenarioReq = await createScenarioReqP;
  const scenPayload = JSON.parse(createScenarioReq.postData() || "{}");
  expect(scenPayload.id).toBe(scenarioId);
  expect(scenPayload.prompt).toContain("hello");
  expect(scenPayload.checks?.length).toBe(1);

  // Dialog should close, scenario should be in the list and selected
  await expect(page.getByTestId("new-scenario-dialog")).toBeHidden({ timeout: 5_000 });
  await expect(page.getByTestId(`scenario-item-${scenarioId}`)).toBeVisible({
    timeout: 5_000,
  });

  // Round-trip via the API
  const sr = await request.get(`${BASE}/api/scenarios/${scenarioId}`);
  expect(sr.ok()).toBeTruthy();
  expect((await sr.json()).id).toBe(scenarioId);

  // ── Benchmark create ───────────────────────────────────────────────────────
  await page.goto("/benchmarks", { waitUntil: "domcontentloaded" });
  await page.waitForLoadState("load");
  await expect(page.getByTestId("benchmarks-new")).toBeEnabled({ timeout: 10_000 });

  await page.getByTestId("benchmarks-new").click();
  await expect(page.getByTestId("new-suite-dialog")).toBeVisible({ timeout: 10_000 });

  await page.getByTestId("newsuite-id").fill(suiteId);
  await page.getByTestId("newsuite-name").fill(`E2E Suite ${stamp}`);

  // Wait for the scenario list to load, then pick our scenario + one other
  await expect(page.getByTestId("newsuite-scenario-list")).toBeVisible();
  await page.getByTestId("newsuite-scenario-filter").fill(scenarioId);
  await expect(page.getByTestId(`newsuite-scenario-${scenarioId}`)).toBeVisible({
    timeout: 5_000,
  });
  await page.getByTestId(`newsuite-scenario-${scenarioId}`).click();

  // Also add the example-hello-world scenario if it exists, for >1 scenario coverage
  await page.getByTestId("newsuite-scenario-filter").fill("example");
  const example = page.getByTestId("newsuite-scenario-example-hello-world");
  if (await example.count()) {
    await example.click();
  }

  const createSuiteReqP = page.waitForRequest(
    (req) => req.url().endsWith("/api/suites") && req.method() === "POST",
    { timeout: 10_000 },
  );
  await page.getByTestId("newsuite-submit").click();
  const createSuiteReq = await createSuiteReqP;
  const suitePayload = JSON.parse(createSuiteReq.postData() || "{}");
  expect(suitePayload.id).toBe(suiteId);
  expect(suitePayload.scenarios).toContain(scenarioId);

  await expect(page.getByTestId("new-suite-dialog")).toBeHidden({ timeout: 5_000 });

  // ── Run the new suite via the New Run drawer ───────────────────────────────
  await page.goto("/runs", { waitUntil: "domcontentloaded" });
  await page.waitForLoadState("load");
  await expect(page.getByTestId("runs-new")).toBeEnabled({ timeout: 10_000 });
  await page.getByTestId("runs-new").click();
  await expect(page.getByTestId("new-run-drawer")).toBeVisible({ timeout: 10_000 });
  await page.getByTestId("newrun-suite-select").selectOption(suiteId);
  await page.getByTestId("newrun-mock-checkbox").check();
  await page.getByTestId("newrun-submit").click();

  await page.waitForURL(/\/runs\/[0-9a-f-]{8,}/i, { timeout: 10_000 });
  const newRunId = new URL(page.url()).pathname.replace(/^\/runs\//, "").replace(/\/$/, "");

  // Poll API until terminal — mock runs finish fast
  let finalStatus: string | null = null;
  for (let i = 0; i < 15; i++) {
    const r = await request.get(`${BASE}/api/runs/${newRunId}`);
    if (r.ok()) {
      const d = await r.json();
      finalStatus = d.status;
      if (d.status === "completed" || d.finished_at) break;
    }
    await page.waitForTimeout(500);
  }

  fs.writeFileSync(
    `tests/e2e-audit/test-results/${NAME}.json`,
    JSON.stringify({ scenarioId, suiteId, newRunId, finalStatus }, null, 2),
  );

  expect(finalStatus).toBe("completed");
});
