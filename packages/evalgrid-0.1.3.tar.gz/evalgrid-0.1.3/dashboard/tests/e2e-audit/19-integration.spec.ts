import { test, expect } from "@playwright/test";
import { startSurvey } from "./helpers";
import * as fs from "fs";

const BASE = "http://localhost:8000";
const NAME = "19-integration";

test("Integration: list → row click → detail render → API matches", async ({ page, request }) => {
  const survey = startSurvey(page);
  const findings: Record<string, any> = { flow: "view-run-detail" };

  await page.goto("/runs", { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(800);

  const rows = await page.locator('[data-testid^="runs-row-"]').all();
  if (!rows.length) {
    findings.skipped = "no runs in UI list";
    fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-detail.json`, JSON.stringify(findings, null, 2));
    test.skip();
    return;
  }

  // Get the run id from data-testid
  const firstId = await rows[0].getAttribute("data-testid");
  const runId = firstId?.replace("runs-row-", "") ?? null;
  findings.firstRunId = runId;

  // Click into detail via the run id link
  await rows[0].locator("a").first().click();
  await page.waitForLoadState("load");
  await page.waitForTimeout(800);

  findings.urlAfterClick = new URL(page.url()).pathname;
  findings.detailRendered = await page.getByTestId("run-detail-title").isVisible().catch(() => false);

  if (runId) {
    const apiR = await request.get(`${BASE}/api/runs/${runId}`);
    if (apiR.ok()) {
      const detail = await apiR.json();
      findings.apiScenarioCount = (detail.scenario_results || []).length;
      const uiScenarioRowCount = await page.locator('[data-testid^="scenario-row-"]').count();
      findings.uiScenarioRowCount = uiScenarioRowCount;
      findings.uiMatchesApi = uiScenarioRowCount === findings.apiScenarioCount;
    }
  }

  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-detail.json`, JSON.stringify(findings, null, 2));
  expect(survey.pageErrors).toEqual([]);
});

test("Integration: New Run drawer launches a mock run end-to-end", async ({ page, request }) => {
  // FIX 11 (v0.1.3): the New Run button is wired. This test exercises the
  // full UI flow — open drawer, enable mock mode, submit, follow the new
  // run through to completion — without spending any API budget.
  const survey = startSurvey(page);
  const findings: Record<string, any> = { flow: "new-run-drawer-mock" };

  const before = await request.get(`${BASE}/api/runs`);
  findings.beforeCount = before.ok() ? ((await before.json()) as any[]).length : -1;

  await page.goto("/runs", { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(500);

  // Open the drawer
  const newRunBtn = page.getByTestId("runs-new");
  await expect(newRunBtn).toBeVisible({ timeout: 5000 });
  await expect(newRunBtn).toBeEnabled();
  await newRunBtn.click();

  const drawer = page.getByTestId("new-run-drawer");
  await expect(drawer).toBeVisible({ timeout: 5000 });
  findings.drawerOpened = true;

  // Enable mock mode (no API key required, deterministic pass)
  const mockCheckbox = page.getByTestId("newrun-mock-checkbox");
  await mockCheckbox.check();
  await expect(mockCheckbox).toBeChecked();

  // Submit
  const submit = page.getByTestId("newrun-submit");
  await expect(submit).toBeEnabled();
  await submit.click();

  // Drawer should close and route should change to /runs/<new-id>
  await page.waitForURL(/\/runs\/[0-9a-f-]{8,}/i, { timeout: 10_000 });
  const newRunId = new URL(page.url()).pathname.replace(/^\/runs\//, "").replace(/\/$/, "");
  findings.newRunId = newRunId;
  findings.urlAfterSubmit = new URL(page.url()).pathname;

  // The drawer should be gone
  await expect(drawer).toBeHidden({ timeout: 3000 });

  // Navigate back to /runs and verify the new run is in the list
  await page.goto("/runs", { waitUntil: "domcontentloaded" });
  const newRow = page.getByTestId(`runs-row-${newRunId}`);
  await expect(newRow).toBeVisible({ timeout: 5_000 });
  findings.newRowVisibleInList = true;

  // Poll the API until the run reaches a terminal state (mock runs finish fast)
  let finalStatus: string | null = null;
  let polledPassRate: number | null = null;
  for (let i = 0; i < 10; i++) {
    const r = await request.get(`${BASE}/api/runs/${newRunId}`);
    if (r.ok()) {
      const d = await r.json();
      finalStatus = d.status;
      polledPassRate = d.pass_rate;
      if (d.status === "completed" || d.finished_at) break;
    }
    await page.waitForTimeout(1000);
  }
  findings.finalStatus = finalStatus;
  findings.passRate = polledPassRate;

  await page.screenshot({ path: `tests/e2e-audit/test-results/${NAME}-new-run.png`, fullPage: true });
  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-new-run.json`, JSON.stringify(findings, null, 2));

  // Hard assertions
  expect(finalStatus).toBe("completed");
  expect(survey.pageErrors).toEqual([]);
});

test("Integration: trigger run via API directly, then check UI updates", async ({ page, request }) => {
  const findings: Record<string, any> = { flow: "api-create-run-then-ui" };

  // Snapshot run count
  const before = await request.get(`${BASE}/api/runs`);
  const beforeCount = before.ok() ? ((await before.json()) as any[]).length : -1;
  findings.beforeCount = beforeCount;

  // Trigger in MOCK mode so no API key required
  const create = await request.post(`${BASE}/api/runs`, {
    data: { scenarios_dir: "", tags: [], scenario_ids: [], mock: true },
  });
  findings.create_status = create.status();
  if (!create.ok()) {
    findings.create_error = (await create.text()).slice(0, 300);
    fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-trigger.json`, JSON.stringify(findings, null, 2));
    return;
  }
  const created = await create.json();
  findings.created_run_id = created.run_id;
  findings.created_status = created.status;

  // Poll for completion (max 30s)
  let polledStatus: string | null = null;
  for (let i = 0; i < 30; i++) {
    await new Promise((r) => setTimeout(r, 1000));
    const r = await request.get(`${BASE}/api/runs/${created.run_id}`);
    if (r.ok()) {
      const d = await r.json();
      polledStatus = d.status;
      if (d.status === "completed" || d.finished_at) {
        findings.polled_pass_rate = d.pass_rate;
        findings.polled_total = d.total;
        break;
      }
    }
  }
  findings.polled_final_status = polledStatus;

  // Reload UI and check the new run appears
  await page.goto("/runs", { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(500);
  findings.ui_shows_new_run = await page
    .locator(`[data-testid="runs-row-${created.run_id}"]`)
    .isVisible()
    .catch(() => false);

  const after = await request.get(`${BASE}/api/runs`);
  findings.afterCount = after.ok() ? ((await after.json()) as any[]).length : -1;
  findings.dbDelta = findings.afterCount - findings.beforeCount;

  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}-trigger.json`, JSON.stringify(findings, null, 2));
});
