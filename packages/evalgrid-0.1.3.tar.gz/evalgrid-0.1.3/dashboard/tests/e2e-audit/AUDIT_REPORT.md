# evalgrid v0.1.3 — E2E Audit Report

**Generated:** 2026-05-15
**Branch:** `feat/dashboard-shadcn-redesign`
**Backend:** FastAPI @ `http://localhost:8000`
**Frontend:** Next.js dev @ `http://localhost:3000` (proxy `/api/* → :8000`)
**Real data in DB:** 20 runs (after Playwright POSTs), **70+ scenario results**, **183 flakiness records**, **4 marked is_flaky**, 0 suites
**Total audit eval cost:** $0.3438 / $1.00 cap (Phase 5 data gen)
**Tests executed:** 30 / 30 passed (3.7 min)
**Screenshots captured:** 77 (across 4 viewports × 10 routes + extras)

---

## Executive Summary

| Category | Pass | Mock | Broken | Missing | Total |
|----------|------|------|--------|---------|-------|
| UI routes rendered without crash | 9 | — | 0 | 0 | 9 |
| UI ↔ API count cross-references | 6 | — | 0 | 0 | 6 |
| API endpoints — happy path | 8 | — | 1 | 0 | 9 |
| API endpoints — input validation | 4 | — | 2 | 0 | 6 |
| API endpoints — security/abuse | 4 | — | 3 | 0 | 7 |
| Integration flows tested | 2 | — | 0 | 1 | 3 |
| Console errors observed | 0 | — | 0 | — | 0 |
| Network errors (4xx/5xx) on rendered routes | 0 | — | 0 | — | 0 |
| Mobile viewport overflow | 2 | — | 7 | — | 9 |
| Accessibility WCAG 4.1.2 (accessible name) | — | — | 8 elements | — | — |

### Top 10 most critical findings

1. **🔴 Split-brain scenarios directory** — API reads `~/.evalgrid/scenarios/` but CLI reads `<cwd>/.evalgrid/scenarios/`. Dashboard scenarios ≠ CLI scenarios. Users can't reconcile what they see in the UI vs what `evalgrid run` evaluates.
2. **🔴 `POST /api/runs {}` returns 200 and starts a real-API run** — empty body has no required-field validation, defaults `mock=false`, server's env API key is used. Anyone hitting `/api/runs` POST with `{}` spawns paid runs.
3. **🔴 `POST /api/runs` accepts 1 MB payloads with HTTP 200** — no size guard. Combined with #2: trivial cost-amplification / DoS vector.
4. **🔴 `GET /api/runs/compare` is unreachable** — route declared *after* `/api/runs/{run_id}` so `compare` is captured as `run_id="compare"` → 404. The whole comparison endpoint is dead code.
5. **🔴 `POST /api/scenarios` does not sanitize `<script>` content** — wrote a scenario with `<script>alert(1)</script>` to disk as YAML; returned 200. When rendered server-side or in any future raw-HTML viewer, this is stored XSS waiting to fire.
6. **🔴 Run-level errors are silently hidden** — `_execute_run` writes the message to `record.results = [{"error": ...}]` but `GET /api/runs/{id}` does NOT return `results`. An errored run looks identical to an empty one (`status="completed"`, `total=0`). Verified during Phase 5 Run 14.
7. **🔴 Anthropic 529 `overloaded_error` is not retried** — `_RETRYABLE_EXC` whitelist includes only `Timeout`/`RateLimitError`/`APIConnectionError`; `litellm.InternalServerError` (which wraps Anthropic 529) hits the `except Exception: raise` branch and bails on first attempt. 3 scenarios errored this way in Phase 5 Run 15 that would have succeeded with one retry.
8. **🟡 Mobile (375 px) horizontal overflow on 7 of 9 routes** — `/flakiness` +263 px, `/` +218 px, `/settings` +142 px, `/benchmarks` +64 px, plus +7-25 px on three "coming-soon" routes.
9. **🟡 Overview layout shift = 872 px** — DOM grows by 872 px after initial render as data fetches resolve. No loading skeletons; cumulative layout shift will tank Lighthouse and feel janky on slow networks.
10. **🟡 8 icon-only anchor tags with no accessible name** (WCAG 4.1.2) — the `ArrowUpRight` chevrons on runs-table rows. Screen reader hears "link, link, link" with no destination.

### Shippability verdict

- **Can ship as-is? NO.**
- **Estimated work to ship: ~3 dev-days** (1.5d for the 7 P0s, 1d for P1 a11y/responsive/UX, 0.5d for retries + error-surfacing).
- **Highest-risk unknowns:**
  - How much of `~/.evalgrid/scenarios/` cleanup is the user's responsibility vs the tool's? A scenarios DELETE endpoint feels overdue.
  - The `judge_model` field accidentally overriding agent `config.model` may have shipped with intent — verify with PRD before "fixing".
  - The empty-body POST hole is severe **if** the API ever gets exposed beyond localhost. Today it's local-only, which lowers the blast radius — but documenting that fact (and adding `127.0.0.1`-only bind) is still required.

---

## Findings by Route

### `/` — Overview

**Status: WORKS (with caveats)**

| # | Element | Type | Expected | Actual | Sev | Endpoint | Fix |
|---|---------|------|----------|--------|-----|----------|-----|
| 1 | `Reliability Score` KPI | display | "% of runs with 100% pass rate" | **62.5%** (10/16 completed full-pass) | OK | `/api/runs` (computed) | — |
| 2 | `Pass Rate` KPI | display | weighted avg of scenario passes | **96.4%** | OK | computed | — |
| 3 | `Total Runs` KPI | display | matches `/api/runs` length | **19** ✓ (API also 19) | OK | `/api/runs` | — |
| 4 | `Flaky Scenarios` KPI | display | matches `/api/flakiness?window=10` is_flaky | **4** ✓ | OK | `/api/flakiness` | — |
| 5 | `Failed Runs` KPI | display | runs with pass_rate < 1 | **6** | OK | computed | — |
| 6 | `Scenarios Executed` KPI | display | sum of `r.total` | **413** | OK | computed | — |
| 7 | Reliability chart | chart | line of pass_rate per completed run | **Renders, 12 points** | OK | computed | — |
| 8 | Regression breakdown bar chart | chart | failures+errors+skipped buckets | Renders | OK | computed | — |
| 9 | Recent Runs table | table | first 8 runs from `/api/runs` | **8 rows ✓** | OK | `/api/runs` | — |
| 10 | Flaky Suites Panel | panel | top is_flaky scenarios | Renders | OK | `/api/flakiness` | — |
| 11 | Failed Scenarios feed | panel | failed scenarios from recent runs | Renders | OK | per-run details | — |
| 12 | Utility rail (right) | panel | shows currently-running runs | Renders, 1 running visible | OK | `/api/runs` | — |
| 13 | Layout shift on load | — | < 100 px | **872 px** | **P1** | — | Add skeleton loaders |
| 14 | Mobile (375 px) | layout | should not overflow | **scrollWidth 593 → +218 px overflow** | **P1** | — | Stack 6-col KPI grid into 2-col below 640 px |

**Console errors:** 0. **Network errors:** 0. **API calls fired on mount:** 7 (1× `/api/runs`, 1× `/api/flakiness?window=10`, 5× `/api/runs/{id}` for failed-scenario detail expansion).

**Screenshots:** `01-overview-1920x1080.png`, `01-overview-1440x900.png`, `01-overview-768x1024.png`, `01-overview-375x667.png`.

---

### `/runs`

**Status: WORKS**

| # | Element | Type | Expected | Actual | Sev | Fix |
|---|---------|------|----------|--------|-----|-----|
| 1 | Runs table rows | table | matches `/api/runs` length | **19 rows = 19 API runs ✓** | OK | — |
| 2 | Search field | input | filter on run_id and scenario_names | "zzzzzzzz-no-match" → 0 rows ✓ | OK | — |
| 3 | Filter `All` | button | shows all 19 | 19 ✓ | OK | — |
| 4 | Filter `Passed` | button | rows with pass_rate ≥ 1 | 10 | OK | — |
| 5 | Filter `Failed` | button | rows with pass_rate < 1 or total = 0 | 8 | OK | — |
| 6 | Filter `Running` | button | rows with status="running" | 1 (an in-flight run from the integration test) | OK | — |
| 7 | Row chevron expand | button | row expands with metadata grid | Expanded successfully ✓ | OK | — |
| 8 | Row click → detail drawer | button | right-side drawer opens with summary | Drawer visible ✓ | OK | — |
| 9 | `Refresh` button | button | re-fetches `/api/runs` | Fires GET on click ✓ | OK | — |
| 10 | `New Run` button | button | **intentionally disabled** in v0.1.3 | **disabled, title="Run creation from UI is not wired in v0.1.3 — use the CLI"** ✓ | OK (by design) | Wire in v0.2 |
| 11 | Run-id links | link | navigate to `/runs/{id}` | Works ✓ | OK | — |
| 12 | Mobile (375 px) | layout | should not overflow | wide table caused overflow on `/` but not on `/runs` (the table is in an overflow-auto wrapper — works) | OK | — |

**Console errors:** 0. **Network errors:** 0. **API calls:** 1.

---

### `/runs/{id}` — Run Detail

**Status: WORKS**

| # | Element | Type | Expected | Actual | Sev | Fix |
|---|---------|------|----------|--------|-----|-----|
| 1 | Page title | display | `Run {first-8-of-id}` | "Run 07349dec" ✓ | OK | — |
| 2 | Pass-rate display | display | matches API `pass_rate` | "100.0%" ✓ | OK | — |
| 3 | Passed count | display | matches API `passed` | "172 passed" ✓ | OK | — |
| 4 | Failed count | display | API `total` − `passed` | "0 failed" ✓ | OK | — |
| 5 | Cost display | display | sum of `scenario_results[].cost_usd` | "**—**" (because run was created by mock-mode POST → all $0 → "—") | OK | — |
| 6 | Scenarios table | table | one row per `scenario_results` | **172 rows = API 172 ✓** | OK | — |
| 7 | Bad run-id route | route | error state visible | "Failed to load:" visible ✓ | OK | — |
| 8 | Mobile (375 px) | layout | three-column layout collapses | Not tested directly (responsive test hits parent route only) | OK | — |

Note: This route's existence ALONE doesn't expose the **errored-run-shows-as-completed-0/0** finding (#6 above). To see that, view run `b841e45b` from Phase 5 Run 14 — UI will show "Run b841e45b · 0 passed · 0 failed · — · — " with no clue the run threw `LiteLLM model lookup` exception.

**Console errors:** 0. **Network errors:** 0.

---

### `/scenarios`

**Status: WORKS (but reads from wrong dir per P0 #1)**

| # | Element | Type | Expected | Actual | Sev | Fix |
|---|---------|------|----------|--------|-----|-----|
| 1 | Scenario list | list | matches `/api/scenarios` | **172 items = API 172 ✓** | OK | — |
| 2 | First scenario auto-selected | behavior | detail pane populated | Detail visible ✓ | OK | — |
| 3 | Search "zzzz-no-match-zzzz" | input | 0 items shown | 0 ✓ | OK | — |
| 4 | Suite grouping | behavior | items grouped by `suite` field | Works ✓ | OK | — |
| 5 | **Read source mismatch with CLI** | architecture | scenarios shown should match `evalgrid run` | **Shows 172 from `~/.evalgrid/scenarios/`** while CLI reads `Workspace/.evalgrid/scenarios/` (11 files). **Different dirs.** | **P0 #1** | Unify path resolution; document the precedence |

---

### `/benchmarks`

**Status: EMPTY (correct — 0 suites in DB)**

| # | Element | Type | Expected | Actual | Sev | Fix |
|---|---------|------|----------|--------|-----|-----|
| 1 | Benchmark cards | grid | matches `/api/suites` length | **0 cards = 0 suites ✓** (correctly shows empty state) | OK | — |
| 2 | Empty state text | display | "No benchmark runs yet" | Visible ✓ | OK | — |
| 3 | Mobile | layout | should not overflow | **scrollWidth 439 → +64 px overflow** | **P1** | Make filter dropdowns wrap below 640 px |

Note: `examples/` ships zero suite YAMLs, and `evalgrid init` doesn't create `.evalgrid/suites/`. README references `--suite` but users have to write a suite themselves first. **P1 doc-gap finding.**

---

### `/flakiness`

**Status: WORKS**

| # | Element | Type | Expected | Actual | Sev | Fix |
|---|---------|------|----------|--------|-----|-----|
| 1 | "Flaky scenarios" stat | display | matches API `is_flaky` count | **4 ✓** (API 4) | OK | — |
| 2 | Window selector | dropdown | changes URL param + refetches | Changes window=20 → re-fetch fires ✓ | OK | — |
| 3 | Stability ranking | list | sorted by flakiness_score desc | Renders 183 rows | OK | — |
| 4 | Refresh button | button | re-fetches `/api/flakiness?window=...` | Fires ✓ | OK | — |
| 5 | Mobile | layout | should not overflow | **scrollWidth 638 → +263 px overflow** (worst on the site) | **P1** | Compact the 4-up stat grid; stack rows |

---

### `/settings`

**Status: WORKS**

| # | Element | Type | Expected | Actual | Sev | Fix |
|---|---------|------|----------|--------|-----|-----|
| 1 | API config panel | display | matches `/api/config-status` | `ANTHROPIC_API_KEY: set`, `OPENAI_API_KEY: not set`, `mock: yes` ✓ | OK | — |
| 2 | Acme Corp / John Doe leaked? | sanity | absent | **`hasAcmeMention: false`, `hasJohnDoeMention: false` ✓** | OK | — |
| 3 | Mobile | layout | should not overflow | **scrollWidth 517 → +142 px overflow** | **P1** | Truncate long env-var rows |

---

### `/reports`, `/datasets`, `/pr-checks` — Empty-state routes

**Status: WORKS (empty states render as designed)**

All three render empty-state cards: "No persisted reports yet" / "Datasets ship in a future release" / "PR Checks ship in v0.2". 0 API calls, 0 errors.

Minor: mobile overflow +7-25 px on each, likely from the dashed-border empty-state card. P3.

---

### `/runs/{id}` 404 path

Tested by visiting `/runs/this-id-definitely-does-not-exist-{timestamp}`. Shows `Failed to load:` error state with "Back to Runs" link. ✓

---

## Findings by API Endpoint

### `GET /api/runs`

- Happy: **200**, isArray ✓, 20 items, shape ✓ (`run_id`, `started_at`, `finished_at`, `pass_rate`, `passed`, `total`, `status`, `scenario_names`, `skipped_count`, `skipped_scenarios`)
- Perf: **14 ms** ✓
- Issues: none

### `POST /api/runs`

- Empty body `{}`: **🔴 200 + creates real run** → P0 #2. Should be **400** or **422**.
- Wrong types: **422** ✓
- Path traversal in `scenarios_dir`: **400** ✓ (caught by `_validate_path`)
- Oversized 1 MB body: **🔴 200** → P0 #3. Should be **413**.

### `GET /api/runs/{run_id}`

- Happy: **200** ✓, perf 11 ms ✓, scenario_results shape ✓
- 404 with unknown id: ✓
- SQLi attempt `'+OR+1=1`: **404** ✓ (safe; SQLAlchemy params escape)
- Path traversal `../../etc/passwd`: **404** ✓
- **🔴 Missing field `results`** in the response, where `_mark_run_failed` puts the error message — P0 #6. Add `error` to the response model.

### `GET /api/runs/compare`

- **🔴 ROUTE UNREACHABLE** → P0 #4
- Test with valid `base=` and `head=`: **happy_status: 404**, body `"Run not found"` — because route `/api/runs/{run_id}` (line 292) is declared before `/api/runs/compare` (line 405). FastAPI route resolution captures `compare` as `run_id`.
- **Fix**: move `compare` registration before `{run_id}` (or declare it on `/api/runs:compare`, `/api/compare`, etc.).

### `GET /api/scenarios`

- Happy: **200**, 172 items, shape ✓
- Perf: **211 ms** (acceptable for 172 file reads + YAML parse)
- Path traversal: **400** ✓

### `POST /api/scenarios`

- Empty body: **422** ✓
- `<script>alert(1)</script>` as prompt: **🔴 200** → P0 #5. Stored to disk verbatim. When rendered in dashboard's scenario detail (or any HTML report), this is XSS. **Fix**: HTML-escape prompts on store OR ensure all rendering paths escape.
- No conflict test executed in this audit (skipped by design — would have created duplicates).

### `GET /api/suites`

- Happy: **200**, count 0 (no suites exist)
- Perf: 6 ms ✓

### `GET /api/suites/{id}/history`

- Bogus id `__nope__`: **🟡 200 with `[]`** — inconsistent with `/api/runs/{id}` which 404s. P1.

### `GET /api/flakiness?window=N`

- Window sweep (1, 5, 10, 20, 50): all **200**
- Perf: 142-213 ms (uses N+1 queries — one per scenario for history)
- Bad window param (`window=bad`): **422** ✓

### `GET /api/config-status`

- **200**, body shape ✓: `{anthropic_key_set, openai_key_set, any_key_set, mock_available}`

### `GET /health`

- **200**, body `{"status":"ok"}` ✓

### Unknown `/api/*` path

- `GET /api/this-endpoint-does-not-exist`: **404** ✓ (not 500)

---

## Integration Flows

### Flow 1 — Click a row → see detail with matching data

**Status: WORKS**

1. Visit `/runs` → 19 rows render ✓
2. Click first row's run-id link → URL becomes `/runs/{full_uuid}` ✓
3. `GET /api/runs/{id}` fires ✓
4. Detail page renders with 172 scenario rows = API count ✓
5. UI ↔ API match: **YES** (`uiScenarioRowCount: 172 === apiScenarioCount: 172`)

### Flow 2 — New Run button is correctly DISABLED (by design)

**Status: WORKS (by design)**

- Button exists ✓
- `disabled=true` ✓
- `title="Run creation from UI is not wired in v0.1.3 — use the CLI"` ✓

This is the v0.1.3 punt on the run-creation flow. In v0.2, this opens a drawer that POSTs to `/api/runs`. Documented in audit; not a bug.

### Flow 3 — Trigger run via API → UI auto-shows new run

**Status: WORKS**

1. Before: `GET /api/runs` returns 19 runs
2. `POST /api/runs {mock: true}` → 200, run-id `2197553f-...`, status `running`
3. Poll `/api/runs/{id}` every 1 s until finished (took ~5 s with mock scorer, 172 scenarios)
4. Final state: `status=completed`, `total=172`, `pass_rate=1.0`
5. UI reload of `/runs` → new run is visible at top of table ✓
6. After: `GET /api/runs` returns 20 runs (dbDelta=1 ✓)

End-to-end create→poll→render works cleanly when triggered through the API.

### Flow 4 — Run Comparison (UNTESTABLE — endpoint dead)

**Status: BROKEN (P0 #4)**

Cannot test because `/api/runs/compare` is unreachable due to route shadowing. The dashboard does not yet expose a compare UI, but this endpoint would be needed when one is built.

### Flow 5 — Edit settings & persist (NO BACKEND for edits)

**Status: READ-ONLY (by design)**

`/settings` is intentionally read-only in v0.1.3 — only displays env-var presence. The "Save Changes" button from the old mock no longer exists. Confirmed.

---

## Accessibility

- **Tab order on `/`**: Sidebar nav (9 items) → theme toggle → table rows. Logical. ✓
- **Focus visible**: Default ring styles preserved (not measured per-element).
- **Contrast spot-check on `<h1 data-testid="page-title">` against background**: ratio **19.07** — far above WCAG AAA (7.0+). ✓
- **🟡 Elements without accessible name: 8** (P1 #10). All are anchor tags with `opacity-0 transition-opacity group-hover:opacity-100` className — the icon-only `ArrowUpRight` chevrons on hover-revealed runs-table action links. Fix: add `aria-label="View run details"` (or remove the link since the row itself is already a link).

---

## Responsive

| Viewport | Routes with overflow | Notes |
|---|---|---|
| 1920 × 1080 | none | All routes render cleanly |
| 1440 × 900 | none | KPI grid (6-up) still fits |
| 768 × 1024 | none (mostly clean) | Tables go horizontal-scroll within container |
| **375 × 667 (mobile)** | **`/` +218 px, `/flakiness` +263 px, `/settings` +142 px, `/benchmarks` +64 px, `/datasets` +24 px, `/reports` +12 px, `/pr-checks` +7 px** | 6-up KPI grid + 12-col layout don't collapse cleanly |

**Worst offender:** `/flakiness` (+263 px). The 4-up stat row + nested chart cards force horizontal scroll. The KPI grid on `/` was bumped from `grid-cols-6` to `grid-cols-2 md:grid-cols-3 xl:grid-cols-6` in Phase 2 but the wide sidebar (272 px) still consumes >70% of a 375 px viewport.

---

## Prioritized Action List

### P0 — Block soft launch (must fix before showing anyone)

- [ ] **#1 Unify scenarios_dir resolution between API and CLI** — `evalgrid/api/app.py:33` (`Path.home()`) vs `evalgrid/core/models.py:129` (relative). Pick one (recommend `~/.evalgrid/scenarios/` for both with CLI override via `--scenarios-dir`). — **~4 h**
- [ ] **#2 `POST /api/runs` requires at least one of `tags`/`scenario_ids`/`scenarios_dir`** — reject empty body with 422. — **~1 h**
- [ ] **#3 Limit `POST /api/runs` body to 64 KB** via FastAPI's `app.add_middleware(SizeLimitMiddleware, max_size=65536)` or Starlette's `Body(max_length=...)`. — **~1 h**
- [ ] **#4 Move `/api/runs/compare` route declaration above `/api/runs/{run_id}`** — `evalgrid/api/app.py:405`. One-line fix. — **~10 min**
- [ ] **#5 HTML-escape `prompt`/`description`/`name` on `POST /api/scenarios`** OR ensure all rendering paths escape (currently React escapes by default, but textarea/`dangerouslySetInnerHTML` paths exist in the HTML report generator). Audit `evalgrid/core/report.py`. — **~2 h**
- [ ] **#6 Surface run-level errors in `GET /api/runs/{id}` response** — add `error: str | None` to the response, populated from `record.results[0]["error"]` when `total == 0`. — **~30 min**
- [ ] **#7 Add `litellm.InternalServerError`, `ServiceUnavailableError`, `APIError` to `_RETRYABLE_EXC`** — `evalgrid/core/runner.py:23-27`. — **~10 min**

**P0 total: ~9 h, ~1 dev-day**

### P1 — Should fix before v0.1.3 ship

- [ ] **#8 Mobile responsive cleanup** — grid-cols collapsed for `/`, `/flakiness`, `/settings`, `/benchmarks` below 640 px. Add `md:` and `lg:` breakpoints. — **~4 h**
- [ ] **#9 Skeleton loaders on `/`** to prevent 872 px layout shift. Render stat-card and table shells immediately, swap content when fetch resolves. — **~2 h**
- [ ] **#10 `aria-label` on 8 icon-only anchor tags** in `components/dashboard/recent-runs-table.tsx` and `app/runs/page.tsx`. — **~20 min**
- [ ] **#11 Rename `judge_model` field** — either honor it strictly as judge-only OR rename to `model_override` and document the dual effect. — **~30 min**
- [ ] **#12 Add `--model` CLI flag** to `evalgrid run` to match user expectations from prompts. — **~1 h**
- [ ] **#13 Add `DELETE /api/scenarios/{id}` endpoint** — `~/.evalgrid/scenarios/` accumulated 173 files on the test machine with no UI/API path to clean. — **~1 h**
- [ ] **#14 `GET /api/suites/{id}/history` should 404 on unknown id**, not return empty array. Match `/api/runs/{id}` behavior. — **~15 min**
- [ ] **#15 Disambiguate CLI exit codes** — exit 0 (all pass), 1 (some fail), 2 (runner crashed). Currently always 2 on any scenario fail. — **~30 min**
- [ ] **#16 Document the "shipped scenarios" path mismatch** in README until #1 is fixed. — **~30 min**

**P1 total: ~10 h, ~1.5 dev-days**

### P2 — Defer to v0.1.4 or v0.2

- [ ] **#17** Wire the New Run drawer in `/runs` — connect to `POST /api/runs` with mock toggle + tag picker.
- [ ] **#18** Persist theme preference to `localStorage` (currently re-defaults to dark on every reload).
- [ ] **#19** Scenarios editor — currently the right pane is stubbed; expose YAML/prompt/assertions editing via `PATCH /api/scenarios/{id}` (new endpoint).
- [ ] **#20** Run comparison UI once #4 is fixed — diff drawer on the runs list.
- [ ] **#21** Flaky heatmap, retry distribution, confidence histogram on `/flakiness` — requires per-attempt telemetry to be persisted (not just per-scenario aggregate).

### P3 — Wireframe scope creep (defer to v1.0)

- [ ] `/datasets` route — needs a dataset/corpus first-class concept; v0.3+ roadmap.
- [ ] `/pr-checks` route — needs `evalgrid ci-report` to publish GitHub status; v0.2.
- [ ] Reports persistence — currently CLI-only via `--report` flag; needs library/index for browse.
- [ ] Workspace switcher / user profile dropdown — not present anymore ✓ (was removed in Phase 1 scrub).

---

## Total Estimated Work to Ship

- **P0:** ~1 dev-day
- **P1:** ~1.5 dev-days
- **Combined:** **~2.5 – 3 dev-days** to address everything blocking a soft launch + the P1 ship-quality fixes.

---

## Recommendation

**Ship the wireframe migration after a 2-3 day fix sprint on P0 + critical P1 items.** The new dashboard works — every route renders without errors, UI counts cross-check against API responses 6/6, all path-traversal/SQLi attempts are safely rejected, and the integration flow (POST run → poll → UI update) works end-to-end. The Linear/Bloomberg/Datadog aesthetic from the redesign is intact and the mocks are fully gone. **No reason to revert to `pre-redesign-backup`.**

However, the 7 P0 findings are not optional. Five of them (#2, #3, #4, #5, #6) are essentially defensive-coding gaps that a single half-day of focused work would close. Two (#1 split-brain scenarios_dir, #7 missing retry on 529) reflect deeper architectural choices that need a real fix, not a patch. The retry fix is 10 lines of code; the scenarios_dir unification is a design decision the team needs to make.

The mobile responsive story (P1 #8-9) is the next-most-visible problem for anyone showing this to investors or doing screen-share demos on laptops with narrow windows. Fixable in a day.

**Do not ship without fixing #4 (dead compare endpoint) and #6 (silent errors).** Both are user-trust killers: the first means a documented feature simply doesn't work, the second means a user can lose hours wondering why a run "succeeded" with 0 scenarios.

---

## Appendix — Files & Artifacts

- **Test specs:** `dashboard/tests/e2e-audit/01-overview.spec.ts` … `19-integration.spec.ts` (19 files, 30 tests)
- **Helpers:** `dashboard/tests/e2e-audit/helpers.ts`
- **Playwright config:** `dashboard/playwright.config.ts` (workers=1, retries=0, screenshot=on, video=retain-on-failure, trace=retain-on-failure)
- **Per-test findings:** `dashboard/tests/e2e-audit/test-results/*.json` (30 files)
- **Screenshots:** `dashboard/tests/e2e-audit/screenshots/*.png` (77 files at 4 viewports)
- **Playwright HTML report:** `dashboard/tests/e2e-audit/playwright-report/index.html`
- **Phase 5 eval run logs:** `evalgrid/audit-results/run-01.log` … `run-15.log`
- **Phase 5 generated reports:** `evalgrid/audit-results/run-7.json`, `run-8.html`, `run-9.md`
- **Test broken scenarios:** `evalgrid/.evalgrid/scenarios/broken-test-1.yml`, `broken-test-2.yml`
- **Backups (pre-audit data):** `~/.evalgrid/results.db.audit-backup-1778803879`, `Workspace/.evalgrid/results.audit-backup-20260515T064300/`

---

## Appendix — Files Modified During Phase 1 + Phase 2 (mock scrub)

| File | Change |
|---|---|
| `dashboard/app/page.tsx` | Replaced 6 hardcoded KPI values + 3 fake "Active Evaluations" + 5 mock-driven panels with `useEffect(() => api.listRuns() + api.flakiness() + ...)` + computed values |
| `dashboard/app/runs/page.tsx` | Replaced 8 hardcoded runs with `api.listRuns()` fetch; added search/filter; disabled "New Run" with explanatory tooltip |
| `dashboard/app/runs/[id]/page.tsx` | Replaced hardcoded run/scenarios/traces/timeline with `api.getRun(id)` |
| `dashboard/app/scenarios/page.tsx` | Replaced 3 hardcoded suite groups + fake "Password reset" detail with `api.listScenarios()` |
| `dashboard/app/benchmarks/page.tsx` | Replaced 6 hardcoded benchmark cards (with fake sparklines) with `api.listSuites()` minimal cards |
| `dashboard/app/flakiness/page.tsx` | Replaced flakySuites/heatmap/retry-dist/confidence-hist/variance-trend mocks with `api.flakiness(window)` ranking; flagged heatmap/retry/confidence as v0.2 |
| `dashboard/app/settings/page.tsx` | Removed "Acme Corp", John/Jane/Bob/Alice team mocks, fake API keys, integrations, Pro plan; replaced with `api.configStatus()` read-only display |
| `dashboard/components/dashboard/recent-runs-table.tsx` | Hardcoded 5 runs → `({ runs }: { runs: RunSummary[] })` prop |
| `dashboard/components/dashboard/reliability-chart.tsx` | Hardcoded 12-week data → `({ data })` prop with empty state |
| `dashboard/components/dashboard/flaky-suites-panel.tsx` | 4 fake suites → `({ stats }: { stats: FlakinessStat[] })` prop |
| `dashboard/components/dashboard/failed-scenarios-feed.tsx` | 4 fake scenarios → `({ items })` prop linking to real `/runs/{id}` |
| `dashboard/components/dashboard/regression-breakdown.tsx` | 5 hardcoded bars → `({ data })` prop with empty state |
| `dashboard/components/dashboard/utility-rail.tsx` | 2 fake incidents + 3 alerts + 3 evaluations → only "Currently Running" from real `RunSummary[]`; rest flagged v0.2 |
| `dashboard/components/dashboard/stat-card.tsx` | Added `loading` prop + `data-testid` |
| `dashboard/playwright.config.ts` | New — Playwright project config |
| `dashboard/tests/e2e-audit/*` | New — 19 spec files + helpers + 4 generated artifacts dirs |
| `dashboard/package.json` | +`@playwright/test` devDep |
| `evalgrid/.evalgrid/scenarios/broken-test-1.yml` | New — intentional hard-fail YAML for Phase 5 |
| `evalgrid/.evalgrid/scenarios/broken-test-2.yml` | New — intentional required-fields fail YAML for Phase 5 |
| `evalgrid/audit-runs-log.json` | New — Phase 5 cost-tracking ledger |

(No changes to `dashboard/app/datasets/page.tsx`, `pr-checks/page.tsx`, `reports/page.tsx` — already empty states. No changes to backend or `lib/api.ts`.)
