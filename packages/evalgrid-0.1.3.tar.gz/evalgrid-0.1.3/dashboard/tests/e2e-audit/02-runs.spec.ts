import { test, expect } from "@playwright/test";
import { startSurvey, networkErrors, safeScreenshot } from "./helpers";
import * as fs from "fs";

const ROUTE = "/runs";
const NAME = "02-runs";

test.describe("Runs route", () => {
  test("renders, fetches, surveys filters/search/expand", async ({ page }) => {
    const survey = startSurvey(page);
    const findings: Record<string, any> = { route: ROUTE };

    await page.goto(ROUTE, { waitUntil: "domcontentloaded" });
    await page.waitForTimeout(1200);

    await expect(page.getByTestId("page-title")).toHaveText("Runs");
    findings.consoleErrors = survey.consoleErrors.length;
    findings.networkErrors = networkErrors(survey).map((n) => `${n.method} ${n.url} → ${n.status}`);
    findings.apiCalls = survey.network
      .filter((n) => n.url.includes("/api/"))
      .map((n) => `${n.method} ${n.url} → ${n.status} (${n.timing}ms)`);

    const rowCount = await page.locator('[data-testid^="runs-row-"]').count();
    findings.rowCount = rowCount;

    const apiResp = await page.request.get("http://localhost:8000/api/runs");
    if (apiResp.ok()) {
      const runs = await apiResp.json();
      findings.apiRunCount = runs.length;
      findings.uiMatchesApi = rowCount === runs.length;
    }

    // Filters
    for (const f of ["all", "pass", "fail", "running"]) {
      await page.getByTestId(`runs-filter-${f}`).click();
      await page.waitForTimeout(300);
      const count = await page.locator('[data-testid^="runs-row-"]').count();
      findings[`filter_${f}_rowCount`] = count;
    }
    await page.getByTestId("runs-filter-all").click();

    // Search
    await page.getByTestId("runs-search").fill("zzzzzzzz-no-match");
    await page.waitForTimeout(200);
    findings.search_no_match_rowCount = await page.locator('[data-testid^="runs-row-"]').count();
    await page.getByTestId("runs-search").fill("");

    // Expand first row, capture state
    const firstRow = page.locator('[data-testid^="runs-row-"]').first();
    if (await firstRow.count()) {
      const firstExpand = firstRow.locator("button").first();
      await firstExpand.click();
      await page.waitForTimeout(300);
      findings.row_expand_visible = await page
        .locator('[data-testid^="runs-row-expanded-"]')
        .isVisible();
    }

    // Click row → open right-side drawer
    if (await firstRow.count()) {
      await firstRow.click();
      await page.waitForTimeout(300);
      findings.detailDrawerVisible = await page
        .getByTestId("runs-detail-drawer")
        .isVisible()
        .catch(() => false);
    }

    // New Run button — should be disabled in v0.1.3
    findings.newRunButton = {
      disabled: await page.getByTestId("runs-new-disabled").isDisabled().catch(() => null),
      title: await page.getByTestId("runs-new-disabled").getAttribute("title").catch(() => null),
    };

    // Refresh button
    await page.getByTestId("runs-refresh").click();
    await page.waitForTimeout(300);

    for (const s of [
      { w: 1920, h: 1080 },
      { w: 1440, h: 900 },
      { w: 768, h: 1024 },
      { w: 375, h: 667 },
    ]) {
      await page.setViewportSize({ width: s.w, height: s.h });
      await page.waitForTimeout(200);
      await safeScreenshot(page, `tests/e2e-audit/screenshots/${NAME}-${s.w}x${s.h}.png`);
    }

    fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}.json`, JSON.stringify(findings, null, 2));
    expect(survey.pageErrors).toEqual([]);
  });
});
