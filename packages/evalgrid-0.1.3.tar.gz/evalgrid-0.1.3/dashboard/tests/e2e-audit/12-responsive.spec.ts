import { test, expect } from "@playwright/test";
import { startSurvey, safeScreenshot } from "./helpers";
import * as fs from "fs";

const NAME = "12-responsive";

const ROUTES = [
  "/",
  "/runs",
  "/scenarios",
  "/benchmarks",
  "/flakiness",
  "/settings",
  "/datasets",
  "/pr-checks",
  "/reports",
];

const SIZES = [
  { w: 1920, h: 1080, label: "desktop-xl" },
  { w: 1440, h: 900, label: "desktop-laptop" },
  { w: 768, h: 1024, label: "tablet" },
  { w: 375, h: 667, label: "mobile" },
];

test.setTimeout(300_000);

test("Responsive sweep — every route at 4 viewport sizes", async ({ page }) => {
  const survey = startSurvey(page);
  const findings: Record<string, any> = { route: "responsive", overflowReports: [] };

  for (const route of ROUTES) {
    for (const sz of SIZES) {
      await page.setViewportSize({ width: sz.w, height: sz.h });
      await page.goto(route, { waitUntil: "domcontentloaded" });
      await page.waitForLoadState("load");
      await page.waitForTimeout(600);
      // Horizontal overflow detection
      const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
      const clientWidth = await page.evaluate(() => document.documentElement.clientWidth);
      if (scrollWidth > clientWidth + 2) {
        findings.overflowReports.push({
          route,
          size: sz.label,
          scrollWidth,
          clientWidth,
          overflowPx: scrollWidth - clientWidth,
        });
      }
      const fname = `${NAME}${route.replace(/\//g, "_") || "_root"}-${sz.label}.png`;
      await safeScreenshot(page, `tests/e2e-audit/screenshots/${fname}`);
    }
  }

  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}.json`, JSON.stringify(findings, null, 2));
  expect(survey.pageErrors).toEqual([]);
});
