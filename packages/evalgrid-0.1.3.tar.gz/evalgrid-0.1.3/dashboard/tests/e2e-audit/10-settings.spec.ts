import { test, expect } from "@playwright/test";
import { startSurvey, networkErrors, safeScreenshot } from "./helpers";
import * as fs from "fs";

const NAME = "10-settings";

test("Settings route — env keys read-only", async ({ page, request }) => {
  const survey = startSurvey(page);
  const findings: Record<string, any> = { route: "/settings" };

  await page.goto("/settings", { waitUntil: "domcontentloaded" });
  await page.waitForLoadState("load");
  await page.waitForTimeout(1500);

  findings.consoleErrors = survey.consoleErrors.length;
  findings.networkErrors = networkErrors(survey).map((n) => `${n.method} ${n.url} → ${n.status}`);
  findings.apiCalls = survey.network
    .filter((n) => n.url.includes("/api/"))
    .map((n) => `${n.method} ${n.url} → ${n.status}`);

  const apiResp = await request.get("http://localhost:8000/api/config-status");
  if (apiResp.ok()) {
    findings.apiConfig = await apiResp.json();
  }

  findings.contentVisible = await page.getByTestId("settings-content").isVisible().catch(() => false);
  // Check no Acme Corp / John Doe leaked
  findings.hasAcmeMention = (await page.content()).includes("Acme Corp");
  findings.hasJohnDoeMention = (await page.content()).includes("john@acme");

  for (const s of [
    { w: 1920, h: 1080 },
    { w: 1440, h: 900 },
    { w: 768, h: 1024 },
    { w: 375, h: 667 },
  ]) {
    await page.setViewportSize({ width: s.w, height: s.h });
    await page.waitForTimeout(200);
    await safeScreenshot(page, `tests/e2e-audit/screenshots/${NAME}-${s.w}x${s.h}.png`);
  }

  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}.json`, JSON.stringify(findings, null, 2));
  expect(survey.pageErrors).toEqual([]);
});
