import { test, expect } from "@playwright/test";
import { startSurvey, safeScreenshot } from "./helpers";
import * as fs from "fs";

const NAME = "11-navigation";

test("Sidebar navigation hits all 9 routes", async ({ page }) => {
  const survey = startSurvey(page);
  const findings: Record<string, any> = { route: "navigation" };

  await page.goto("/", { waitUntil: "domcontentloaded" });

  const expected = [
    ["Overview", "/"],
    ["Runs", "/runs"],
    ["Benchmarks", "/benchmarks"],
    ["Flakiness", "/flakiness"],
    ["Scenarios", "/scenarios"],
    ["Reports", "/reports"],
    ["Datasets", "/datasets"],
    ["PR Checks", "/pr-checks"],
    ["Settings", "/settings"],
  ];

  findings.navResults = [];
  for (const [label, href] of expected) {
    const link = page.locator(`aside a[href="${href}"]`).first();
    const ok = await link.isVisible();
    if (ok) {
      await link.click();
      await page.waitForLoadState("load");
      await page.waitForTimeout(300);
      const url = new URL(page.url()).pathname;
      findings.navResults.push({ label, expected: href, actual: url, match: url === href });
    } else {
      findings.navResults.push({ label, expected: href, actual: null, match: false });
    }
  }

  // Theme toggle
  const themeBtn = page.locator("aside button", { hasText: /Light Mode|Dark Mode/ }).first();
  const beforeMode = await themeBtn.textContent();
  await themeBtn.click();
  await page.waitForTimeout(200);
  const afterMode = await themeBtn.textContent();
  findings.themeToggle = { before: beforeMode?.trim(), after: afterMode?.trim() };

  await safeScreenshot(page, `tests/e2e-audit/screenshots/${NAME}-nav.png`);

  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}.json`, JSON.stringify(findings, null, 2));
  expect(survey.pageErrors).toEqual([]);
});
