import { test, expect } from "@playwright/test";
import { startSurvey, networkErrors, safeScreenshot } from "./helpers";
import * as fs from "fs";

const NAME = "04-scenarios";

test("Scenarios route — list, group, select, search", async ({ page, request }) => {
  const survey = startSurvey(page);
  const findings: Record<string, any> = { route: "/scenarios" };

  await page.goto("/scenarios", { waitUntil: "domcontentloaded" });
  await page.waitForLoadState("load");
  await page.waitForTimeout(1500);

  await expect(page.getByTestId("page-title").or(page.getByText("Scenarios").first())).toBeVisible();

  findings.consoleErrors = survey.consoleErrors.length;
  findings.networkErrors = networkErrors(survey).map((n) => `${n.method} ${n.url} → ${n.status}`);
  findings.apiCalls = survey.network
    .filter((n) => n.url.includes("/api/"))
    .map((n) => `${n.method} ${n.url} → ${n.status} (${n.timing}ms)`);

  const apiResp = await request.get("http://localhost:8000/api/scenarios");
  if (apiResp.ok()) {
    const scens = (await apiResp.json()) as any[];
    findings.apiScenarioCount = scens.length;
  }

  const itemCount = await page.locator('[data-testid^="scenario-item-"]').count();
  findings.uiScenarioItems = itemCount;

  if (itemCount > 0) {
    await page.locator('[data-testid^="scenario-item-"]').first().click();
    await page.waitForTimeout(200);
    findings.detailVisible = await page.getByTestId("scenario-detail").isVisible().catch(() => false);
    findings.detailName = await page.getByTestId("scenario-detail-name").textContent().catch(() => null);
  }

  // Search
  await page.getByTestId("scenarios-search").fill("zzzz-no-match-zzzz");
  await page.waitForTimeout(200);
  findings.search_no_match_items = await page.locator('[data-testid^="scenario-item-"]').count();
  await page.getByTestId("scenarios-search").fill("");

  for (const s of [
    { w: 1920, h: 1080 },
    { w: 1440, h: 900 },
    { w: 768, h: 1024 },
    { w: 375, h: 667 },
  ]) {
    await page.setViewportSize({ width: s.w, height: s.h });
    await page.waitForTimeout(200);
    await safeScreenshot(page, `tests/e2e-audit/screenshots/${NAME}-${s.w}x${s.h}.png`);
  }

  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}.json`, JSON.stringify(findings, null, 2));
  expect(survey.pageErrors).toEqual([]);
});
