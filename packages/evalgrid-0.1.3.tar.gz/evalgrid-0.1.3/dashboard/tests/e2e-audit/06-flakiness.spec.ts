import { test, expect } from "@playwright/test";
import { startSurvey, networkErrors, safeScreenshot } from "./helpers";
import * as fs from "fs";

const NAME = "06-flakiness";

test("Flakiness route", async ({ page, request }) => {
  const survey = startSurvey(page);
  const findings: Record<string, any> = { route: "/flakiness" };

  await page.goto("/flakiness", { waitUntil: "domcontentloaded" });
  await page.waitForLoadState("load");
  await page.waitForTimeout(1500);

  await expect(page.getByTestId("page-title")).toHaveText("Flakiness Analysis");

  findings.consoleErrors = survey.consoleErrors.length;
  findings.networkErrors = networkErrors(survey).map((n) => `${n.method} ${n.url} → ${n.status}`);
  findings.apiCalls = survey.network
    .filter((n) => n.url.includes("/api/"))
    .map((n) => `${n.method} ${n.url} → ${n.status} (${n.timing}ms)`);

  const apiResp = await request.get("http://localhost:8000/api/flakiness?window=10");
  if (apiResp.ok()) {
    const stats = (await apiResp.json()) as any[];
    findings.apiStatCount = stats.length;
    findings.apiFlakyCount = stats.filter((s: any) => s.is_flaky).length;
    const uiFlakyText = await page.getByTestId("flakiness-stat-flaky").textContent();
    findings.uiFlakyDisplay = uiFlakyText;
    findings.uiMatchesApi = String(findings.apiFlakyCount) === uiFlakyText?.trim();
  }

  // Window switcher
  await page.getByTestId("flakiness-window").selectOption("20");
  await page.waitForTimeout(500);
  await page.getByTestId("flakiness-window").selectOption("10");

  for (const s of [
    { w: 1920, h: 1080 },
    { w: 1440, h: 900 },
    { w: 768, h: 1024 },
    { w: 375, h: 667 },
  ]) {
    await page.setViewportSize({ width: s.w, height: s.h });
    await page.waitForTimeout(200);
    await safeScreenshot(page, `tests/e2e-audit/screenshots/${NAME}-${s.w}x${s.h}.png`);
  }

  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}.json`, JSON.stringify(findings, null, 2));
  expect(survey.pageErrors).toEqual([]);
});
