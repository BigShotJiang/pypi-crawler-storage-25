import { test, expect } from "@playwright/test";
import { startSurvey } from "./helpers";
import * as fs from "fs";

const NAME = "13-keyboard-a11y";

test("Keyboard navigation and accessibility basics", async ({ page }) => {
  const survey = startSurvey(page);
  const findings: Record<string, any> = { route: "a11y" };

  await page.goto("/", { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(800);

  // Count interactives without accessible name
  findings.elementsWithoutAccessibleName = await page.evaluate(() => {
    const interactives = Array.from(
      document.querySelectorAll("button, a, input, select, textarea, [role=button]"),
    );
    const issues: { tag: string; role: string | null; selector: string }[] = [];
    for (const el of interactives) {
      const e = el as HTMLElement;
      const text = (e.innerText || "").trim();
      const aria = e.getAttribute("aria-label");
      const title = e.getAttribute("title");
      if (!text && !aria && !title) {
        issues.push({
          tag: e.tagName,
          role: e.getAttribute("role"),
          selector: e.className.slice(0, 100),
        });
      }
    }
    return issues.slice(0, 50);
  });

  // Tab order on overview
  await page.focus("body");
  const tabSequence: { tag: string; testId: string | null; text: string | null }[] = [];
  for (let i = 0; i < 20; i++) {
    await page.keyboard.press("Tab");
    const focused = await page.evaluate(() => {
      const el = document.activeElement as HTMLElement | null;
      if (!el || el === document.body) return null;
      return {
        tag: el.tagName,
        testId: el.getAttribute("data-testid"),
        text: (el.innerText || "").slice(0, 40).trim() || null,
      };
    });
    if (focused) tabSequence.push(focused);
  }
  findings.tabSequence = tabSequence;

  // Color contrast — sample: page-title against background
  findings.contrastSpotCheck = await page.evaluate(() => {
    function srgb(c: number): number {
      const s = c / 255;
      return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
    }
    function lum(rgb: string): number | null {
      const m = rgb.match(/\d+/g);
      if (!m) return null;
      const [r, g, b] = m.map(Number);
      return 0.2126 * srgb(r) + 0.7152 * srgb(g) + 0.0722 * srgb(b);
    }
    const el = document.querySelector('[data-testid="page-title"]') as HTMLElement | null;
    if (!el) return null;
    const cs = getComputedStyle(el);
    const fg = lum(cs.color);
    let bg: number | null = null;
    let parent = el.parentElement;
    while (parent && bg === null) {
      const b = getComputedStyle(parent).backgroundColor;
      if (b && !b.includes("rgba(0, 0, 0, 0)")) bg = lum(b);
      parent = parent.parentElement;
    }
    if (fg === null || bg === null) return null;
    const ratio = (Math.max(fg, bg) + 0.05) / (Math.min(fg, bg) + 0.05);
    return { color: cs.color, ratio: Number(ratio.toFixed(2)) };
  });

  fs.writeFileSync(`tests/e2e-audit/test-results/${NAME}.json`, JSON.stringify(findings, null, 2));
  expect(survey.pageErrors).toEqual([]);
});
