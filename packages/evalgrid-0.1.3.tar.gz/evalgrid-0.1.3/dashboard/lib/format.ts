// Shared formatting helpers. Previously duplicated across runs/page.tsx,
// runs/[id]/run-detail-client.tsx, benchmarks/page.tsx, scenarios/page.tsx
// — drift risk was real. Single source now.

/** "5s ago", "12m ago", "3h ago", "2d ago". null/invalid → "—". */
export function relativeTime(iso: string | null): string {
  if (!iso) return "—"
  const ts = Date.parse(iso)
  if (Number.isNaN(ts)) return "—"
  const diff = Date.now() - ts
  const secs = Math.max(0, Math.round(diff / 1000))
  if (secs < 60) return `${secs}s ago`
  const mins = Math.round(secs / 60)
  if (mins < 60) return `${mins}m ago`
  const hours = Math.round(mins / 60)
  if (hours < 24) return `${hours}h ago`
  return `${Math.round(hours / 24)}d ago`
}

/** "12s", "1m 4s", "—" when not finished or invalid. */
export function durationLabel(
  startedAt: string,
  finishedAt: string | null,
): string {
  if (!finishedAt) return "—"
  const dur = Date.parse(finishedAt) - Date.parse(startedAt)
  if (!Number.isFinite(dur) || dur < 0) return "—"
  const secs = Math.round(dur / 1000)
  if (secs < 60) return `${secs}s`
  const m = Math.floor(secs / 60)
  return `${m}m ${secs - m * 60}s`
}
