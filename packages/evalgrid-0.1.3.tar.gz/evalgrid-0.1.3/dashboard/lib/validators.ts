// Slug pattern mirrored from evalgrid/api/app.py::_SLUG_RE.
// Keep these two in sync — they validate the same filesystem-safe id format.
// If you change one, change both, OR (better) generate from OpenAPI codegen
// when that lands (v0.2 candidate).
export const SLUG_RE = /^[a-z0-9][a-z0-9-]{0,127}$/

export function isValidSlug(value: string): boolean {
  return SLUG_RE.test(value)
}

export const SLUG_HINT = "letters, numbers, hyphens only (lowercase)"
export const SLUG_ERROR =
  "letters, numbers, hyphens only (lowercase, must start with letter/digit)"
