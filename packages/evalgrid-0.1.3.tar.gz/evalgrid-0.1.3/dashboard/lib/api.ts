// Minimal client for the evalgrid FastAPI backend.
// All requests are same-origin via the /api/* proxy in next.config.mjs.

export type RunSummary = {
  run_id: string;
  started_at: string;
  finished_at: string | null;
  pass_rate: number;
  passed: number;
  total: number;
  status: "running" | "completed";
  scenario_names: string[];
  skipped_count: number;
  skipped_scenarios: { file: string; reason: string }[];
};

export type ScenarioResult = {
  scenario_id: string;
  scenario_name: string;
  agent_type: string;
  status: "pass" | "fail" | "error" | "skip";
  overall_score: number;
  pass_rate: number;
  reasoning: string;
  error: string | null;
  steps: any[];
  check_results: any[];
  hard_failed: boolean;
  prompt_tokens: number;
  completion_tokens: number;
  cost_usd: number;
};

export type RunDetail = {
  run_id: string;
  started_at: string;
  finished_at: string | null;
  pass_rate: number | null;
  passed: number | null;
  total: number | null;
  status: "running" | "completed";
  // FIX 3 (v0.1.3) — runs that fail at startup expose the failure reason here.
  error: string | null;
  scenario_results: ScenarioResult[];
};

export type ScenarioListItem = {
  id: string;
  name: string;
  description: string;
  agent_type: string;
  tags: string[];
  step_count: number;
  suite: string;
};

export type ExpectedAction = {
  action: string;
  required: boolean;
  description: string;
  params: Record<string, unknown>;
};

export type ScenarioCheck = {
  type: string;
  hard_fail: boolean;
  fields: string[];
  field: string;
  allowed: string[];
  pattern: string;
  text: string;
  value: number;
};

export type ScenarioRecentRun = {
  run_id: string;
  status: string;
  overall_score: number;
  cost_usd: number;
  started_at: string | null;
  finished_at: string | null;
  hard_failed: boolean;
};

export type ScenarioDetail = {
  id: string;
  name: string;
  description: string;
  agent_type: string;
  prompt: string;
  test_input: string;
  success_criteria: string;
  tags: string[];
  timeout_seconds: number;
  weight: number;
  suite: string;
  expected_actions: ExpectedAction[];
  checks: ScenarioCheck[];
  recent_runs: ScenarioRecentRun[];
};

export type SuiteListItem = {
  suite_id: string;
  suite_name: string;
  run_count: number;
  latest_run: string | null;
  latest_passed: boolean | null;
};

export type FlakinessStat = {
  scenario_id: string;
  scenario_name: string;
  run_count: number;
  pass_count: number;
  fail_count: number;
  error_count: number;
  pass_rate: number;
  flakiness_score: number;
  is_flaky: boolean;
  last_status: string;
};

export type ConfigStatus = {
  anthropic_key_set: boolean;
  openai_key_set: boolean;
  any_key_set: boolean;
  mock_available: boolean;
};

export type NewRunBody = {
  mock?: boolean;
  tags?: string[];
  suite?: string;
  agent_model?: string;
  judge_model?: string;
};

export type KeyUpdateBody = {
  ANTHROPIC_API_KEY?: string;
  OPENAI_API_KEY?: string;
};

export type KeyUpdateResult = {
  updated: string[];
  anthropic_key_set: boolean;
  openai_key_set: boolean;
};

export type ScenarioCheckInput = {
  type: string;
  hard_fail?: boolean;
  fields?: string[];
  field?: string;
  pattern?: string;
};

export type NewScenarioBody = {
  id: string;
  name: string;
  description?: string;
  agent_type?: string;
  prompt: string;
  test_input?: string;
  expected_actions?: Array<Record<string, unknown>>;
  checks?: ScenarioCheckInput[];
  tags?: string[];
};

export type NewScenarioResult = {
  id: string;
  name: string;
  description: string;
  agent_type: string;
  tags: string[];
  step_count: number;
  check_count: number;
};

export type NewSuiteBody = {
  id: string;
  name: string;
  description?: string;
  scenarios: string[];
  tags?: string[];
  pass_threshold?: number;
};

export type NewSuiteResult = {
  suite_id: string;
  suite_name: string;
  scenario_count: number;
  tags: string[];
};

async function get<T>(path: string): Promise<T> {
  const res = await fetch(path, { cache: "no-store" });
  if (!res.ok) {
    let detail = "";
    try {
      const body = await res.json();
      detail = body?.detail || JSON.stringify(body);
    } catch {
      detail = res.statusText;
    }
    throw new Error(`${res.status} ${path}: ${detail}`);
  }
  return res.json();
}

async function post<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    cache: "no-store",
  });
  if (!res.ok) {
    let detail = "";
    try {
      const json = await res.json();
      if (typeof json?.detail === "string") {
        detail = json.detail;
      } else if (Array.isArray(json?.detail)) {
        detail = json.detail.map((d: any) => d?.msg || JSON.stringify(d)).join("; ");
      } else {
        detail = JSON.stringify(json);
      }
    } catch {
      detail = res.statusText;
    }
    throw new Error(`${res.status} ${path}: ${detail}`);
  }
  return res.json();
}

export const api = {
  listRuns: () => get<RunSummary[]>("/api/runs"),
  getRun: (id: string) => get<RunDetail>(`/api/runs/${encodeURIComponent(id)}`),
  createRun: (body: NewRunBody) => post<RunSummary>("/api/runs", body),
  listScenarios: () => get<ScenarioListItem[]>("/api/scenarios"),
  getScenario: (id: string) =>
    get<ScenarioDetail>(`/api/scenarios/${encodeURIComponent(id)}`),
  // include_mock=false hides suites whose every persisted run is mock-mode.
  // The drawer passes include_mock=true so a mock-only example suite is still
  // listed as a runnable option; the Benchmarks page uses the default.
  listSuites: (includeMock = false) =>
    get<SuiteListItem[]>(`/api/suites?include_mock=${includeMock}`),
  flakiness: (window = 10) => get<FlakinessStat[]>(`/api/flakiness?window=${window}`),
  configStatus: () => get<ConfigStatus>("/api/config-status"),
  setKeys: (body: KeyUpdateBody) => post<KeyUpdateResult>("/api/config/keys", body),
  createScenario: (body: NewScenarioBody) =>
    post<NewScenarioResult>("/api/scenarios", body),
  createSuite: (body: NewSuiteBody) => post<NewSuiteResult>("/api/suites", body),
};
