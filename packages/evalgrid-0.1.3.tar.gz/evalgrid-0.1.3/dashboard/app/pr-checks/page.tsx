"use client";
// Hidden from nav until backend ships in v0.2 — see BACKLOG.md.
// Route file preserved so the surface can be re-enabled without re-wiring imports.

import { MainLayout } from "@/components/layout/main-layout";
import { EmptyState } from "@/components/states/empty";
import { GitPullRequest } from "lucide-react";

export default function PRChecksPage() {
  return (
    <MainLayout>
      <div className="p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold text-foreground">PR Checks</h1>
          <p className="text-sm text-muted-foreground">
            Required GitHub status checks on every pull request.
          </p>
        </div>
        <EmptyState
          icon={<GitPullRequest className="h-10 w-10" />}
          title="PR Checks ship in v0.2"
          description="evalgrid ci-report will post a markdown comment to your PR with pass-rate, score delta vs baseline, and set a required commit status. Currently in development."
        />
      </div>
    </MainLayout>
  );
}
