import type { Metadata } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Toaster } from '@/components/ui/sonner'
import { ThemeProvider } from '@/components/theme-provider'
import './globals.css'

const _geist = Geist({ subsets: ["latin"] });
const _geistMono = Geist_Mono({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: 'EvalGrid - AI Reliability Observatory',
  description: 'Infrastructure-grade AI evaluation monitoring and reliability platform',
  // Generator string intentionally omitted — was leaking 'v0.app' on every page.
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  // suppressHydrationWarning is required on <html> because next-themes
  // injects the resolved theme class via a pre-hydration script — React
  // would otherwise warn about server/client class mismatch on every page.
  // The bg-background class moves to <body> so the html element stays
  // under next-themes' sole control. defaultTheme="dark" preserves the
  // prior look-and-feel; localStorage 'evalgrid-theme' key makes the
  // user's choice persist across refreshes + route transitions.
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="font-sans antialiased bg-background">
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem={false}
          disableTransitionOnChange
          storageKey="evalgrid-theme"
        >
          {children}
          <Toaster position="bottom-right" richColors closeButton />
        </ThemeProvider>
      </body>
    </html>
  )
}
