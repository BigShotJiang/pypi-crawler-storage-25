"use client"

import { Fragment, useEffect, useMemo, useState } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { StatusBadge } from "@/components/ui/status-badge"
import { ErrorState, EmptyState } from "@/components/states/empty"
import { NewRunDrawer } from "@/components/runs/new-run-drawer"
import {
  Search,
  ChevronRight,
  ChevronDown,
  Play,
  RefreshCw,
} from "lucide-react"
import Link from "next/link"
import { api, type RunSummary } from "@/lib/api"
import { relativeTime, durationLabel as durationLabelShared } from "@/lib/format"

type FilterKey = "all" | "pass" | "fail" | "running"

function statusOf(r: RunSummary): { key: FilterKey; label: string; badge: "success" | "warning" | "error" | "info" } {
  if (r.status === "running") return { key: "running", label: "Running", badge: "info" }
  if (r.total === 0) return { key: "fail", label: "Empty", badge: "warning" }
  if (r.pass_rate >= 1) return { key: "pass", label: "Passed", badge: "success" }
  if (r.pass_rate >= 0.5) return { key: "fail", label: "Partial", badge: "warning" }
  return { key: "fail", label: "Failed", badge: "error" }
}

// Thin RunSummary adapter — the shared durationLabel takes (started, finished?).
function durationLabel(r: RunSummary): string {
  return durationLabelShared(r.started_at, r.finished_at)
}

const filters: { label: string; value: FilterKey }[] = [
  { label: "All", value: "all" },
  { label: "Passed", value: "pass" },
  { label: "Failed", value: "fail" },
  { label: "Running", value: "running" },
]

export default function RunsPage() {
  const [runs, setRuns] = useState<RunSummary[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [refreshTick, setRefreshTick] = useState(0)
  const [selectedFilter, setSelectedFilter] = useState<FilterKey>("all")
  const [search, setSearch] = useState("")
  const [expandedRow, setExpandedRow] = useState<string | null>(null)
  const [selectedRun, setSelectedRun] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    setRuns(null)
    api
      .listRuns()
      .then((r) => {
        if (!cancelled) {
          setRuns(r)
          setError(null)
        }
      })
      .catch((e) => {
        if (!cancelled) setError(e?.message || String(e))
      })
    return () => {
      cancelled = true
    }
  }, [refreshTick])

  const filteredRuns = useMemo(() => {
    if (!runs) return []
    const q = search.trim().toLowerCase()
    return runs.filter((r) => {
      const s = statusOf(r).key
      if (selectedFilter !== "all" && s !== selectedFilter) return false
      if (q) {
        const haystack = [
          r.run_id,
          ...r.scenario_names,
        ]
          .join(" ")
          .toLowerCase()
        if (!haystack.includes(q)) return false
      }
      return true
    })
  }, [runs, selectedFilter, search])

  const selectedRunData = useMemo(
    () => (runs ?? []).find((r) => r.run_id === selectedRun) || null,
    [runs, selectedRun],
  )

  return (
    <MainLayout>
      <div className="flex min-h-screen flex-col lg:h-screen lg:flex-row">
        <div className="min-w-0 flex-1 overflow-auto p-4 sm:p-6">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
            <div className="min-w-0">
              <h1 className="text-2xl font-semibold text-foreground" data-testid="page-title">Runs</h1>
              <p className="text-sm text-muted-foreground">
                Operational run management and history
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setRefreshTick((t) => t + 1)}
                className="flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm font-medium text-foreground hover:bg-muted"
                data-testid="runs-refresh"
              >
                <RefreshCw className="h-4 w-4" />
                Refresh
              </button>
              <NewRunDrawer
                trigger={
                  <button
                    type="button"
                    className="flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
                    data-testid="runs-new"
                  >
                    <Play className="h-4 w-4" />
                    New Run
                  </button>
                }
              />
            </div>
          </div>

          <div className="mb-4 flex flex-wrap items-center gap-3">
            <div className="relative w-full min-w-0 max-w-md flex-1 sm:w-auto">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                type="text"
                placeholder="Search by run ID or scenario name..."
                className="w-full rounded-md border border-border bg-card py-2 pl-9 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                data-testid="runs-search"
              />
            </div>
            <div className="flex flex-wrap items-center gap-1 rounded-md border border-border p-1" data-testid="runs-filters">
              {filters.map((filter) => (
                <button
                  key={filter.value}
                  onClick={() => setSelectedFilter(filter.value)}
                  className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
                    selectedFilter === filter.value
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                  data-testid={`runs-filter-${filter.value}`}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>

          {error && (
            <div className="mb-4" data-testid="runs-error">
              <ErrorState error={error} />
            </div>
          )}

          <div className="overflow-x-auto rounded-xl border border-border bg-card">
            {runs === null ? (
              <div className="p-8 text-center text-sm text-muted-foreground">Loading runs…</div>
            ) : filteredRuns.length === 0 ? (
              <EmptyState
                title="No runs match"
                description={runs.length === 0 ? "No runs yet — click New Run, or trigger via the CLI: evalgrid run" : "Try clearing the filter or search."}
              />
            ) : (
              <table className="w-full min-w-[640px]" data-testid="runs-table">
                <thead>
                  <tr className="border-b border-border">
                    <th className="px-3 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground sm:px-4">Run</th>
                    <th className="px-3 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground sm:px-4">Status</th>
                    <th className="px-3 py-3 text-right text-xs font-medium uppercase tracking-wider text-muted-foreground sm:px-4">Pass rate</th>
                    <th className="px-3 py-3 text-right text-xs font-medium uppercase tracking-wider text-muted-foreground sm:px-4">Passed / Total</th>
                    <th className="hidden px-3 py-3 text-right text-xs font-medium uppercase tracking-wider text-muted-foreground sm:table-cell sm:px-4">Duration</th>
                    <th className="hidden px-3 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground md:table-cell sm:px-4">Scenarios</th>
                    <th className="hidden px-3 py-3 text-right text-xs font-medium uppercase tracking-wider text-muted-foreground sm:table-cell sm:px-4">Started</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredRuns.map((run) => {
                    const st = statusOf(run)
                    const isExpanded = expandedRow === run.run_id
                    return (
                      <Fragment key={run.run_id}>
                        <tr
                          className={`group cursor-pointer transition-colors hover:bg-muted/50 ${
                            selectedRun === run.run_id ? "bg-muted/50" : ""
                          }`}
                          onClick={() =>
                            setSelectedRun(selectedRun === run.run_id ? null : run.run_id)
                          }
                          data-testid={`runs-row-${run.run_id}`}
                        >
                          <td className="px-3 py-3 sm:px-4">
                            <div className="flex items-center gap-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  setExpandedRow(isExpanded ? null : run.run_id)
                                }}
                                className="text-muted-foreground hover:text-foreground"
                                aria-label={isExpanded ? "Collapse row" : "Expand row"}
                              >
                                {isExpanded ? (
                                  <ChevronDown className="h-4 w-4" />
                                ) : (
                                  <ChevronRight className="h-4 w-4" />
                                )}
                              </button>
                              <Link
                                href={`/runs/${run.run_id}`}
                                onClick={(e) => e.stopPropagation()}
                                className="font-mono text-xs font-medium text-foreground hover:text-primary"
                              >
                                {run.run_id.slice(0, 12)}
                              </Link>
                            </div>
                          </td>
                          <td className="px-3 py-3 sm:px-4">
                            <StatusBadge status={st.badge as any} label={st.label} />
                          </td>
                          <td className="px-3 py-3 text-right sm:px-4">
                            <span className="tabular-nums text-sm font-medium text-foreground">
                              {run.total > 0 ? `${(run.pass_rate * 100).toFixed(1)}%` : "—"}
                            </span>
                          </td>
                          <td className="px-3 py-3 text-right sm:px-4">
                            <span className="tabular-nums text-sm text-muted-foreground">
                              {run.passed} / {run.total}
                            </span>
                          </td>
                          <td className="hidden px-3 py-3 text-right sm:table-cell sm:px-4">
                            <span className="tabular-nums text-sm text-muted-foreground">
                              {durationLabel(run)}
                            </span>
                          </td>
                          <td className="hidden max-w-[200px] truncate px-3 py-3 md:table-cell sm:px-4">
                            <span className="text-xs text-muted-foreground">
                              {run.scenario_names.slice(0, 2).join(", ")}
                              {run.scenario_names.length > 2 ? ` +${run.scenario_names.length - 2}` : ""}
                            </span>
                          </td>
                          <td className="hidden px-3 py-3 text-right sm:table-cell sm:px-4">
                            <span className="text-xs text-muted-foreground">{relativeTime(run.started_at)}</span>
                          </td>
                        </tr>
                        {isExpanded && (
                          <tr className="bg-muted/30">
                            <td colSpan={7} className="px-3 py-4 sm:px-4" data-testid={`runs-row-expanded-${run.run_id}`}>
                              <div className="ml-2 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:ml-6 lg:grid-cols-4">
                                <div className="rounded-lg border border-border bg-card p-3">
                                  <p className="text-xs text-muted-foreground">Run ID</p>
                                  <p className="mt-1 truncate font-mono text-xs text-foreground">{run.run_id}</p>
                                </div>
                                <div className="rounded-lg border border-border bg-card p-3">
                                  <p className="text-xs text-muted-foreground">Skipped</p>
                                  <p className="mt-1 tabular-nums text-lg font-semibold text-foreground">{run.skipped_count}</p>
                                </div>
                                <div className="rounded-lg border border-border bg-card p-3">
                                  <p className="text-xs text-muted-foreground">Started</p>
                                  <p className="mt-1 break-words text-xs text-foreground">{new Date(run.started_at).toLocaleString()}</p>
                                </div>
                                <div className="rounded-lg border border-border bg-card p-3">
                                  <p className="text-xs text-muted-foreground">Finished</p>
                                  <p className="mt-1 break-words text-xs text-foreground">{run.finished_at ? new Date(run.finished_at).toLocaleString() : "—"}</p>
                                </div>
                                {run.skipped_scenarios.length > 0 && (
                                  <div className="col-span-1 sm:col-span-2 lg:col-span-4">
                                    <p className="mb-2 text-xs font-medium text-muted-foreground">Skipped scenarios</p>
                                    <ul className="space-y-1 text-xs text-muted-foreground">
                                      {run.skipped_scenarios.slice(0, 5).map((s, i) => (
                                        <li key={i}>
                                          <code className="font-mono break-all">{s.file}</code> — {s.reason}
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                )}
                              </div>
                            </td>
                          </tr>
                        )}
                      </Fragment>
                    )
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {selectedRunData && (
          <div className="hidden w-[400px] shrink-0 overflow-auto border-l border-border bg-card/30 p-4 xl:block" data-testid="runs-detail-drawer">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-foreground">Run Details</h3>
              <Link
                href={`/runs/${selectedRunData.run_id}`}
                className="text-xs font-medium text-primary hover:text-primary/80"
              >
                Full view
              </Link>
            </div>
            <div className="space-y-4">
              <div className="rounded-xl border border-border bg-card p-4">
                <h4 className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Summary
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between gap-2">
                    <span className="text-muted-foreground">Run ID</span>
                    <span className="truncate font-mono text-xs text-foreground">{selectedRunData.run_id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Pass rate</span>
                    <span className="tabular-nums font-medium text-foreground">
                      {selectedRunData.total > 0 ? `${(selectedRunData.pass_rate * 100).toFixed(1)}%` : "—"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Duration</span>
                    <span className="tabular-nums text-foreground">{durationLabel(selectedRunData)}</span>
                  </div>
                  <div className="flex justify-between gap-2">
                    <span className="text-muted-foreground">Started</span>
                    <span className="truncate text-foreground">{new Date(selectedRunData.started_at).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}
