"use client"

import { useEffect, useMemo, useRef, useState } from "react"
import { useParams, usePathname } from "next/navigation"
import { MainLayout } from "@/components/layout/main-layout"
import { StatusBadge } from "@/components/ui/status-badge"
import { EmptyState, ErrorState } from "@/components/states/empty"
import {
  ArrowLeft,
  Clock,
  DollarSign,
  Zap,
  Timer,
  CheckCircle2,
  XCircle,
  AlertTriangle,
} from "lucide-react"
import Link from "next/link"
import { api, type RunDetail, type ScenarioResult } from "@/lib/api"
import { durationLabel as durationLabelShared } from "@/lib/format"

function durationLabel(d: RunDetail): string {
  return durationLabelShared(d.started_at, d.finished_at)
}

function statusBadge(s: ScenarioResult["status"]): "success" | "warning" | "error" | "info" {
  if (s === "pass") return "success"
  if (s === "skip") return "warning"
  if (s === "fail") return "error"
  return "error"
}

// Polling cadence: 1s, 2s, 4s, 8s, capped at 8s. A 30 s run was previously
// 15 fetches; now ~6. A 10-minute run drops from 300 → ~75. Same UX (UI
// updates within seconds of completion) at a fraction of the server load.
const POLL_DELAYS_MS = [1000, 2000, 4000, 8000] as const

export default function RunDetailClient() {
  // The static export pre-renders this route with the sentinel `_index`
  // (see generateStaticParams in page.tsx). On a hard refresh / deep link
  // the bundled SPA shell hydrates with params.id === "_index", which would
  // otherwise cause `getRun("_index")` to 404. The actual id is in the URL
  // path; usePathname() is reactive across SPA navigation too, so this also
  // works for client-side router transitions inside the SPA.
  const params = useParams<{ id: string }>()
  const pathname = usePathname()
  const id = useMemo(() => {
    const match = pathname?.match(/^\/runs\/([^/]+)\/?$/)
    const fromUrl = match?.[1]
    if (fromUrl && fromUrl !== "_index") {
      return decodeURIComponent(fromUrl)
    }
    if (params?.id && params.id !== "_index") {
      return params.id
    }
    return undefined
  }, [pathname, params?.id])
  const [run, setRun] = useState<RunDetail | null>(null)
  const [error, setError] = useState<string | null>(null)
  const pollRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const pollStepRef = useRef<number>(0)

  useEffect(() => {
    if (!id) return
    let cancelled = false
    setRun(null)
    pollStepRef.current = 0

    const schedule = (delayMs: number) => {
      if (pollRef.current) clearTimeout(pollRef.current)
      pollRef.current = setTimeout(load, delayMs)
    }

    const load = () =>
      api
        .getRun(id)
        .then((r) => {
          if (cancelled) return
          setRun(r)
          setError(null)
          if (r.status === "running") {
            const step = Math.min(pollStepRef.current, POLL_DELAYS_MS.length - 1)
            schedule(POLL_DELAYS_MS[step])
            pollStepRef.current = step + 1
          } else if (pollRef.current) {
            clearTimeout(pollRef.current)
            pollRef.current = null
          }
        })
        .catch((e) => {
          if (!cancelled) setError(e?.message || String(e))
        })

    load()

    return () => {
      cancelled = true
      if (pollRef.current) {
        clearTimeout(pollRef.current)
        pollRef.current = null
      }
    }
  }, [id])

  if (error) {
    return (
      <MainLayout>
        <div className="p-4 sm:p-6">
          <Link
            href="/runs"
            className="mb-4 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Runs
          </Link>
          <ErrorState error={error} />
        </div>
      </MainLayout>
    )
  }

  if (!run) {
    return (
      <MainLayout>
        <div className="p-4 text-sm text-muted-foreground sm:p-6" data-testid="run-detail-loading">
          Loading run…
        </div>
      </MainLayout>
    )
  }

  const scenarios = run.scenario_results ?? []
  const passed = scenarios.filter((s) => s.status === "pass").length
  const failed = scenarios.filter((s) => s.status === "fail" || s.status === "error").length
  const skipped = scenarios.filter((s) => s.status === "skip").length
  const totalCost = scenarios.reduce((acc, s) => acc + (s.cost_usd || 0), 0)
  const totalTokens = scenarios.reduce(
    (acc, s) => acc + (s.prompt_tokens || 0) + (s.completion_tokens || 0),
    0,
  )

  return (
    <MainLayout>
      <div className="flex min-h-screen flex-col overflow-hidden lg:h-screen lg:flex-row">
        <div className="w-full shrink-0 overflow-auto border-b border-border bg-card/30 p-4 lg:w-[320px] lg:border-b-0 lg:border-r">
          <Link
            href="/runs"
            className="mb-4 flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Runs
          </Link>

          <div className="mb-6">
            <div className="flex items-center justify-between gap-2">
              <h1 className="min-w-0 truncate text-lg font-semibold text-foreground" data-testid="run-detail-title">
                Run {run.run_id.slice(0, 8)}
              </h1>
              <StatusBadge
                status={
                  run.error
                    ? "error"
                    : run.status === "running"
                    ? "info"
                    : run.pass_rate === 1
                    ? "success"
                    : "error"
                }
                label={
                  run.error
                    ? "Errored"
                    : run.status === "running"
                    ? "Running"
                    : run.pass_rate === 1
                    ? "Passed"
                    : "Failed"
                }
              />
            </div>
            <p className="mt-1 truncate font-mono text-xs text-muted-foreground">{run.run_id}</p>
          </div>

          {/* FIX 3 — surface run-level startup errors prominently */}
          {run.error && (
            <div
              className="mb-6 rounded-xl border border-error/40 bg-error/10 p-3"
              data-testid="run-detail-error"
              role="alert"
            >
              <p className="text-xs font-medium uppercase tracking-wider text-error">Run errored</p>
              <p className="mt-1 break-words text-sm text-foreground">{run.error}</p>
            </div>
          )}

          <div className="mb-6 space-y-3">
            <div className="rounded-xl border border-border bg-card p-4">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Pass Rate</span>
                <span
                  className={`tabular-nums text-lg font-semibold ${
                    (run.pass_rate ?? 0) >= 0.95
                      ? "text-success"
                      : (run.pass_rate ?? 0) >= 0.75
                      ? "text-warning"
                      : "text-error"
                  }`}
                  data-testid="run-detail-pass-rate"
                >
                  {(run.total ?? 0) > 0 ? `${((run.pass_rate ?? 0) * 100).toFixed(1)}%` : "—"}
                </span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-muted">
                <div
                  className={`h-full rounded-full ${
                    (run.pass_rate ?? 0) >= 0.95 ? "bg-success" : "bg-warning"
                  }`}
                  style={{ width: `${((run.pass_rate ?? 0) * 100).toFixed(0)}%` }}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-lg border border-border bg-card p-3">
                <p className="text-xs text-muted-foreground">Passed</p>
                <p className="mt-1 tabular-nums text-lg font-semibold text-success">{run.passed ?? 0}</p>
              </div>
              <div className="rounded-lg border border-border bg-card p-3">
                <p className="text-xs text-muted-foreground">Total</p>
                <p className="mt-1 tabular-nums text-lg font-semibold text-foreground">{run.total ?? 0}</p>
              </div>
            </div>
          </div>

          <div className="mb-6 space-y-2">
            <h3 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Metrics
            </h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between rounded-lg border border-border bg-card/50 p-2.5">
                <span className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Timer className="h-4 w-4" />
                  Duration
                </span>
                <span className="tabular-nums text-sm font-medium text-foreground">
                  {durationLabel(run)}
                </span>
              </div>
              <div className="flex items-center justify-between rounded-lg border border-border bg-card/50 p-2.5">
                <span className="flex items-center gap-2 text-sm text-muted-foreground">
                  <DollarSign className="h-4 w-4" />
                  Cost
                </span>
                <span className="tabular-nums text-sm font-medium text-foreground" data-testid="run-detail-cost">
                  {totalCost > 0 ? `$${totalCost.toFixed(4)}` : "—"}
                </span>
              </div>
              <div className="flex items-center justify-between rounded-lg border border-border bg-card/50 p-2.5">
                <span className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Zap className="h-4 w-4" />
                  Tokens
                </span>
                <span className="tabular-nums text-sm font-medium text-foreground">
                  {totalTokens.toLocaleString()}
                </span>
              </div>
              <div className="flex items-center justify-between rounded-lg border border-border bg-card/50 p-2.5">
                <span className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  Started
                </span>
                <span className="truncate text-xs text-foreground">{new Date(run.started_at).toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="min-w-0 flex-1 overflow-auto p-4 sm:p-6">
          <div className="mb-6 flex flex-wrap items-center gap-x-6 gap-y-2">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-success" />
              <span className="text-sm font-medium text-foreground" data-testid="run-detail-passed">{passed} passed</span>
            </div>
            <div className="flex items-center gap-2">
              <XCircle className="h-5 w-5 text-error" />
              <span className="text-sm font-medium text-foreground" data-testid="run-detail-failed">{failed} failed</span>
            </div>
            {skipped > 0 && (
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-warning" />
                <span className="text-sm font-medium text-foreground">{skipped} skipped</span>
              </div>
            )}
            <span className="text-sm text-muted-foreground">{scenarios.length} total</span>
          </div>

          {scenarios.length === 0 ? (
            run.error ? (
              <EmptyState
                title="Run errored before any scenarios completed"
                description="See the error banner on the left for the failure reason."
              />
            ) : (
              <EmptyState
                title="No scenario results yet"
                description="The run may still be running, or no scenarios matched."
              />
            )
          ) : (
            <>
              {scenarios.filter((s) => s.status !== "pass").length > 0 && (
                <div className="mb-6">
                  <h2 className="mb-3 text-sm font-semibold text-foreground">Failed scenarios</h2>
                  <div className="space-y-2">
                    {scenarios
                      .filter((s) => s.status !== "pass" && s.status !== "skip")
                      .map((s) => (
                        <div
                          key={s.scenario_id}
                          className="rounded-xl border border-error/20 bg-error/5 p-4"
                          data-testid={`scenario-failed-${s.scenario_id}`}
                        >
                          <div className="flex items-start gap-3">
                            <XCircle className="mt-0.5 h-5 w-5 shrink-0 text-error" />
                            <div className="min-w-0 flex-1">
                              <p className="truncate font-medium text-foreground">{s.scenario_name}</p>
                              {s.error && (
                                <p className="mt-1 break-words text-sm text-error">{s.error}</p>
                              )}
                              {s.reasoning && (
                                <p className="mt-2 line-clamp-3 text-xs text-muted-foreground">
                                  {s.reasoning}
                                </p>
                              )}
                              <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                                <span>Pass rate: {(s.pass_rate * 100).toFixed(1)}%</span>
                                <span>Score: {(s.overall_score * 100).toFixed(1)}%</span>
                                <span>Cost: ${s.cost_usd.toFixed(4)}</span>
                                <span>Tokens: {(s.prompt_tokens + s.completion_tokens).toLocaleString()}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              )}

              <div className="mb-6">
                <h2 className="mb-3 text-sm font-semibold text-foreground">All scenarios</h2>
                <div className="overflow-x-auto rounded-xl border border-border bg-card">
                  <table className="w-full min-w-[480px]" data-testid="run-detail-scenarios-table">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="px-3 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground sm:px-4">Scenario</th>
                        <th className="px-3 py-3 text-center text-xs font-medium uppercase tracking-wider text-muted-foreground sm:px-4">Status</th>
                        <th className="px-3 py-3 text-right text-xs font-medium uppercase tracking-wider text-muted-foreground sm:px-4">Score</th>
                        <th className="px-3 py-3 text-right text-xs font-medium uppercase tracking-wider text-muted-foreground sm:px-4">Cost</th>
                        <th className="px-3 py-3 text-right text-xs font-medium uppercase tracking-wider text-muted-foreground sm:px-4">Tokens</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {scenarios.map((s) => (
                        <tr key={s.scenario_id} className="group" data-testid={`scenario-row-${s.scenario_id}`}>
                          <td className="max-w-[200px] truncate px-3 py-3 sm:px-4">
                            <span className="text-sm font-medium text-foreground">{s.scenario_name}</span>
                          </td>
                          <td className="px-3 py-3 text-center sm:px-4">
                            <StatusBadge status={statusBadge(s.status) as any} label={s.status} />
                          </td>
                          <td className="px-3 py-3 text-right sm:px-4">
                            <span
                              className={`tabular-nums text-sm ${
                                s.overall_score >= 0.9
                                  ? "text-success"
                                  : s.overall_score >= 0.75
                                  ? "text-warning"
                                  : "text-error"
                              }`}
                            >
                              {(s.overall_score * 100).toFixed(1)}%
                            </span>
                          </td>
                          <td className="px-3 py-3 text-right sm:px-4">
                            <span className="tabular-nums text-sm text-muted-foreground">
                              ${s.cost_usd.toFixed(4)}
                            </span>
                          </td>
                          <td className="px-3 py-3 text-right sm:px-4">
                            <span className="tabular-nums text-sm text-muted-foreground">
                              {(s.prompt_tokens + s.completion_tokens).toLocaleString()}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </MainLayout>
  )
}
