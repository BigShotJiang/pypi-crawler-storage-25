// Server-component wrapper for the dynamic /runs/[id] route.
//
// Static export emits a single shell at /runs/_index/ via the sentinel
// generateStaticParams below. FastAPI's SPAStaticFiles walks the URL tree
// and serves this shell for any /runs/<id>/ deep link or hard refresh.
//
// IMPORTANT: the shell is pre-rendered with params.id === "_index". The
// real id lives in the URL path, so RunDetailClient derives it from
// usePathname() rather than trusting params.id. See run-detail-client.tsx.
import RunDetailClient from "./run-detail-client"

export function generateStaticParams() {
  return [{ id: "_index" }]
}

export default function RunDetailPage() {
  return <RunDetailClient />
}
