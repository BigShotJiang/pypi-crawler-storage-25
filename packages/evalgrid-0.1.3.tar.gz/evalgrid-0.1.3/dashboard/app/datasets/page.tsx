"use client";
// Hidden from nav until backend ships in v1.0 — see BACKLOG.md.
// Route file preserved so the surface can be re-enabled without re-wiring imports.

import { MainLayout } from "@/components/layout/main-layout";
import { EmptyState } from "@/components/states/empty";
import { Database } from "lucide-react";

export default function DatasetsPage() {
  return (
    <MainLayout>
      <div className="p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold text-foreground">Datasets</h1>
          <p className="text-sm text-muted-foreground">
            Versioned input corpora for evaluation.
          </p>
        </div>
        <EmptyState
          icon={<Database className="h-10 w-10" />}
          title="Datasets ship in a future release"
          description="evalgrid currently runs against YAML scenarios in .evalgrid/scenarios. A first-class dataset surface (JSONL/Parquet/CSV with versioning) is on the v0.3+ roadmap."
        />
      </div>
    </MainLayout>
  );
}
