"use client"

import { useEffect, useMemo, useState } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { EmptyState, ErrorState } from "@/components/states/empty"
import { StatusBadge } from "@/components/ui/status-badge"
import {
  Search,
  FileCode,
  ChevronRight,
  ChevronDown,
  Tag,
  Plus,
} from "lucide-react"
import Link from "next/link"
import { api, type ScenarioDetail, type ScenarioListItem } from "@/lib/api"
import { NewScenarioDialog } from "@/components/scenarios/new-scenario-dialog"
import { relativeTime } from "@/lib/format"

// relativeTime moved to @/lib/format

function statusToBadge(s: string): "success" | "warning" | "error" | "info" {
  if (s === "pass") return "success"
  if (s === "skip") return "warning"
  if (s === "fail") return "error"
  if (s === "error") return "error"
  return "info"
}

export default function ScenariosPage() {
  const [items, setItems] = useState<ScenarioListItem[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set())
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [search, setSearch] = useState("")
  const [detail, setDetail] = useState<ScenarioDetail | null>(null)
  const [detailError, setDetailError] = useState<string | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [refreshTick, setRefreshTick] = useState(0)

  useEffect(() => {
    let cancelled = false
    api
      .listScenarios()
      .then((s) => {
        if (cancelled) return
        setItems(s)
        setError(null)
        if (s.length > 0 && !selectedId) {
          setExpandedGroups(new Set([s[0].suite]))
          setSelectedId(s[0].id)
        }
      })
      .catch((e) => {
        if (!cancelled) setError(e?.message || String(e))
      })
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshTick])

  useEffect(() => {
    if (!selectedId) {
      setDetail(null)
      return
    }
    let cancelled = false
    setDetailLoading(true)
    setDetailError(null)
    api
      .getScenario(selectedId)
      .then((d) => {
        if (cancelled) return
        setDetail(d)
        setDetailLoading(false)
      })
      .catch((e) => {
        if (cancelled) return
        setDetailError(e?.message || String(e))
        setDetail(null)
        setDetailLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [selectedId])

  const grouped = useMemo(() => {
    if (!items) return new Map<string, ScenarioListItem[]>()
    const q = search.trim().toLowerCase()
    const filtered = q
      ? items.filter(
          (s) =>
            s.name.toLowerCase().includes(q) ||
            s.id.toLowerCase().includes(q) ||
            s.tags.some((t) => t.toLowerCase().includes(q)),
        )
      : items
    const m = new Map<string, ScenarioListItem[]>()
    for (const s of filtered) {
      const k = s.suite || "default"
      const arr = m.get(k) ?? []
      arr.push(s)
      m.set(k, arr)
    }
    return m
  }, [items, search])

  const toggleGroup = (name: string) => {
    setExpandedGroups((prev) => {
      const next = new Set(prev)
      if (next.has(name)) next.delete(name)
      else next.add(name)
      return next
    })
  }

  return (
    <MainLayout>
      <div className="flex min-h-screen flex-col overflow-hidden lg:h-screen lg:flex-row">
        <div className="flex w-full shrink-0 items-center justify-between border-b border-border bg-card/60 px-3 py-2 lg:hidden">
          <h2 className="text-sm font-semibold text-foreground">Scenarios</h2>
          <div className="flex items-center gap-2">
            <NewScenarioDialog
              onCreated={(id) => {
                setSelectedId(id)
                setRefreshTick((t) => t + 1)
              }}
              trigger={
                <button
                  type="button"
                  className="flex items-center gap-1 rounded-md bg-primary px-2 py-1 text-xs font-medium text-primary-foreground hover:bg-primary/90"
                  data-testid="scenarios-new-mobile"
                >
                  <Plus className="h-3 w-3" /> New
                </button>
              }
            />
            <button
              type="button"
              className="rounded-md border border-border px-3 py-1.5 text-xs font-medium text-foreground"
              onClick={() => setSidebarOpen((v) => !v)}
            >
              {sidebarOpen ? "Hide list" : "Show list"}
            </button>
          </div>
        </div>

        <div
          className={`${sidebarOpen ? "block" : "hidden"} w-full shrink-0 overflow-auto border-border bg-card/30 lg:block lg:w-[280px] lg:border-r`}
        >
          <div className="sticky top-0 z-10 flex flex-col gap-2 border-b border-border bg-card/80 p-3 backdrop-blur-sm">
            <NewScenarioDialog
              onCreated={(id) => {
                setSelectedId(id)
                setRefreshTick((t) => t + 1)
              }}
              trigger={
                <button
                  type="button"
                  className="hidden w-full items-center justify-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 lg:flex"
                  data-testid="scenarios-new"
                >
                  <Plus className="h-4 w-4" /> New Scenario
                </button>
              }
            />
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                type="text"
                placeholder="Search scenarios..."
                className="w-full rounded-md border border-border bg-background py-2 pl-9 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
                data-testid="scenarios-search"
              />
            </div>
          </div>

          <div className="p-2" data-testid="scenarios-list">
            {items === null ? (
              <p className="px-2 py-4 text-xs text-muted-foreground">Loading…</p>
            ) : items.length === 0 ? (
              <p className="px-2 py-4 text-xs text-muted-foreground">
                No scenarios found. Run <code className="font-mono">evalgrid init</code> to create some.
              </p>
            ) : (
              Array.from(grouped.entries()).map(([groupName, scenarios]) => (
                <div key={groupName} className="mb-1">
                  <button
                    onClick={() => toggleGroup(groupName)}
                    className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-sm font-medium text-foreground hover:bg-muted"
                    data-testid={`scenarios-group-${groupName}`}
                  >
                    {expandedGroups.has(groupName) ? (
                      <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />
                    ) : (
                      <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                    )}
                    <span className="truncate">{groupName}</span>
                    <span className="ml-auto text-xs text-muted-foreground">
                      {scenarios.length}
                    </span>
                  </button>
                  {expandedGroups.has(groupName) && (
                    <div className="ml-4 space-y-0.5">
                      {scenarios.map((s) => (
                        <button
                          key={s.id}
                          onClick={() => {
                            setSelectedId(s.id)
                            setSidebarOpen(false)
                          }}
                          className={`flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-sm transition-colors ${
                            selectedId === s.id
                              ? "bg-primary/10 text-primary"
                              : "text-muted-foreground hover:bg-muted hover:text-foreground"
                          }`}
                          data-testid={`scenario-item-${s.id}`}
                        >
                          <FileCode className="h-3.5 w-3.5 shrink-0" />
                          <span className="truncate">{s.name}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>

        <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
          {error && (
            <div className="p-4">
              <ErrorState error={error} />
            </div>
          )}

          {!error && !selectedId && items && items.length === 0 && (
            <div className="p-6">
              <EmptyState
                title="No scenarios yet"
                description="Run `evalgrid init` to create the example scenarios."
              />
            </div>
          )}

          {selectedId && (
            <div className="flex flex-1 flex-col overflow-hidden" data-testid="scenario-detail">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border bg-card px-4 py-3">
                <div className="flex min-w-0 items-center gap-3">
                  <FileCode className="h-5 w-5 shrink-0 text-primary" />
                  <div className="min-w-0">
                    <h2 className="truncate font-semibold text-foreground" data-testid="scenario-detail-name">
                      {detail?.name ?? selectedId}
                    </h2>
                    <p className="truncate text-xs text-muted-foreground">
                      {(detail?.suite ?? "default")} / <span className="font-mono">{selectedId}</span>
                    </p>
                  </div>
                </div>
                {detail && (
                  <span className="rounded-md bg-muted px-2 py-0.5 text-xs text-muted-foreground">
                    {detail.agent_type}
                  </span>
                )}
              </div>

              <div className="flex-1 overflow-auto p-4 sm:p-6">
                {detailLoading && (
                  <div className="text-sm text-muted-foreground">Loading scenario…</div>
                )}
                {detailError && <ErrorState error={detailError} />}
                {detail && !detailLoading && (
                  <div className="space-y-4">
                    <div className="rounded-xl border border-border bg-card p-4">
                      <h3 className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Description</h3>
                      <p className="text-sm text-foreground">
                        {detail.description || (
                          <span className="text-muted-foreground">No description</span>
                        )}
                      </p>
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                      <div className="rounded-xl border border-border bg-card p-4">
                        <h3 className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Steps</h3>
                        <p className="tabular-nums text-2xl font-semibold text-foreground">{detail.expected_actions.length}</p>
                      </div>
                      <div className="rounded-xl border border-border bg-card p-4">
                        <h3 className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Checks</h3>
                        <p className="tabular-nums text-2xl font-semibold text-foreground">{detail.checks.length}</p>
                      </div>
                      <div className="rounded-xl border border-border bg-card p-4">
                        <h3 className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Timeout</h3>
                        <p className="tabular-nums text-2xl font-semibold text-foreground">{detail.timeout_seconds}s</p>
                      </div>
                      <div className="rounded-xl border border-border bg-card p-4">
                        <h3 className="mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                          <Tag className="h-3.5 w-3.5" /> Tags
                        </h3>
                        <div className="flex flex-wrap gap-1.5">
                          {detail.tags.length === 0 ? (
                            <span className="text-xs text-muted-foreground">—</span>
                          ) : (
                            detail.tags.map((t) => (
                              <span
                                key={t}
                                className="rounded-md bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary"
                              >
                                {t}
                              </span>
                            ))
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="rounded-xl border border-border bg-card p-4" data-testid="scenario-prompt">
                      <h3 className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Prompt</h3>
                      <pre className="overflow-x-auto whitespace-pre-wrap break-words rounded-md bg-muted/60 p-3 text-xs text-foreground">
                        {detail.prompt}
                      </pre>
                    </div>

                    <div className="rounded-xl border border-border bg-card p-4" data-testid="scenario-test-input">
                      <h3 className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Test input</h3>
                      <pre className="overflow-x-auto whitespace-pre-wrap break-words rounded-md bg-muted/60 p-3 text-xs text-foreground">
                        {detail.test_input}
                      </pre>
                    </div>

                    {detail.success_criteria && (
                      <div className="rounded-xl border border-border bg-card p-4">
                        <h3 className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Success criteria</h3>
                        <p className="break-words text-sm text-foreground">{detail.success_criteria}</p>
                      </div>
                    )}

                    {detail.expected_actions.length > 0 && (
                      <div className="rounded-xl border border-border bg-card p-4" data-testid="scenario-expected-actions">
                        <h3 className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">Expected actions</h3>
                        <ul className="space-y-2">
                          {detail.expected_actions.map((a, i) => (
                            <li key={i} className="rounded-md border border-border bg-muted/30 p-2 text-sm">
                              <div className="flex flex-wrap items-center gap-2">
                                <code className="font-mono text-xs text-foreground">{a.action}</code>
                                <span
                                  className={`rounded-md px-2 py-0.5 text-[10px] font-medium ${
                                    a.required ? "bg-error/15 text-error" : "bg-muted text-muted-foreground"
                                  }`}
                                >
                                  {a.required ? "required" : "optional"}
                                </span>
                              </div>
                              {a.description && (
                                <p className="mt-1 break-words text-xs text-muted-foreground">{a.description}</p>
                              )}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {detail.checks.length > 0 && (
                      <div className="rounded-xl border border-border bg-card p-4" data-testid="scenario-checks">
                        <h3 className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">Checks</h3>
                        <ul className="space-y-2">
                          {detail.checks.map((c, i) => (
                            <li key={i} className="rounded-md border border-border bg-muted/30 p-2 text-sm">
                              <div className="flex flex-wrap items-center gap-2">
                                <code className="font-mono text-xs text-foreground">{c.type}</code>
                                {c.hard_fail && (
                                  <span className="rounded-md bg-error/15 px-2 py-0.5 text-[10px] font-medium text-error">
                                    hard fail
                                  </span>
                                )}
                              </div>
                              <div className="mt-1 grid grid-cols-1 gap-1 break-words text-xs text-muted-foreground sm:grid-cols-2">
                                {c.fields.length > 0 && <span>fields: {c.fields.join(", ")}</span>}
                                {c.field && <span>field: {c.field}</span>}
                                {c.allowed.length > 0 && <span>allowed: {c.allowed.join(", ")}</span>}
                                {c.pattern && <span>pattern: {c.pattern}</span>}
                                {c.text && <span>text: {c.text}</span>}
                                {c.value > 0 && <span>value: {c.value}</span>}
                              </div>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="rounded-xl border border-border bg-card p-4" data-testid="scenario-recent-runs">
                      <h3 className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">Recent runs</h3>
                      {detail.recent_runs.length === 0 ? (
                        <p className="text-xs text-muted-foreground">
                          No runs have executed this scenario yet.
                        </p>
                      ) : (
                        <div className="overflow-x-auto">
                          <table className="w-full min-w-[400px] text-sm">
                            <thead>
                              <tr className="border-b border-border text-left text-xs text-muted-foreground">
                                <th className="px-2 py-2 font-medium uppercase tracking-wider">Run</th>
                                <th className="px-2 py-2 font-medium uppercase tracking-wider">Status</th>
                                <th className="px-2 py-2 text-right font-medium uppercase tracking-wider">Score</th>
                                <th className="px-2 py-2 text-right font-medium uppercase tracking-wider">Cost</th>
                                <th className="px-2 py-2 text-right font-medium uppercase tracking-wider">When</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-border">
                              {detail.recent_runs.map((r) => (
                                <tr key={r.run_id}>
                                  <td className="px-2 py-2">
                                    <Link
                                      href={`/runs/${r.run_id}`}
                                      className="font-mono text-xs text-foreground hover:text-primary"
                                    >
                                      {r.run_id.slice(0, 8)}
                                    </Link>
                                  </td>
                                  <td className="px-2 py-2">
                                    <StatusBadge status={statusToBadge(r.status) as any} label={r.status} />
                                  </td>
                                  <td className="px-2 py-2 text-right tabular-nums text-xs text-foreground">
                                    {(r.overall_score * 100).toFixed(0)}%
                                  </td>
                                  <td className="px-2 py-2 text-right tabular-nums text-xs text-muted-foreground">
                                    {r.cost_usd > 0 ? `$${r.cost_usd.toFixed(4)}` : "—"}
                                  </td>
                                  <td className="px-2 py-2 text-right text-xs text-muted-foreground">
                                    {relativeTime(r.finished_at ?? r.started_at)}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>

                    <div className="rounded-xl border border-dashed border-border bg-card/40 p-4 text-xs text-muted-foreground">
                      Inline scenario editing ships in v0.2 — for now, edit YAML files in your scenarios directory.
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  )
}
