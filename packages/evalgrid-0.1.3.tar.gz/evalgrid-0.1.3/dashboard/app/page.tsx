"use client"

import { useEffect, useMemo, useState } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { StatCard } from "@/components/dashboard/stat-card"
import { ReliabilityChart, type ReliabilityPoint } from "@/components/dashboard/reliability-chart"
import { RecentRunsTable } from "@/components/dashboard/recent-runs-table"
import { FlakySuitesPanel } from "@/components/dashboard/flaky-suites-panel"
import {
  FailedScenariosFeed,
  type FailedScenarioItem,
} from "@/components/dashboard/failed-scenarios-feed"
import { UtilityRail } from "@/components/dashboard/utility-rail"
import { RegressionBreakdown, type RegressionDatum } from "@/components/dashboard/regression-breakdown"
import { api, type RunSummary, type FlakinessStat, type RunDetail } from "@/lib/api"
import { ErrorState } from "@/components/states/empty"
import {
  Activity,
  CheckCircle2,
  AlertTriangle,
  Zap,
  XCircle,
  Hash,
} from "lucide-react"

function computeReliabilitySeries(runs: RunSummary[]): ReliabilityPoint[] {
  const completed = runs.filter((r) => r.status === "completed" && r.total > 0)
  if (!completed.length) return []
  const sorted = [...completed].sort(
    (a, b) => Date.parse(a.started_at) - Date.parse(b.started_at),
  )
  return sorted.map((r) => ({
    date: new Date(r.started_at).toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
    }),
    reliability: r.pass_rate * 100,
  }))
}

export default function OverviewPage() {
  const [runs, setRuns] = useState<RunSummary[] | null>(null)
  const [flakiness, setFlakiness] = useState<FlakinessStat[] | null>(null)
  const [failedScenarios, setFailedScenarios] = useState<FailedScenarioItem[]>([])
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false

    ;(async () => {
      try {
        const [runsResp, flakeResp] = await Promise.all([
          api.listRuns(),
          api.flakiness(10).catch(() => [] as FlakinessStat[]),
        ])
        if (cancelled) return
        setRuns(runsResp)
        setFlakiness(flakeResp)

        // Fetch run detail for the most recent failed runs to surface failed scenarios.
        const failingRuns = runsResp
          .filter((r) => r.status === "completed" && r.total > 0 && r.pass_rate < 1)
          .slice(0, 5)
        const details: RunDetail[] = await Promise.all(
          failingRuns.map((r) => api.getRun(r.run_id).catch(() => null as any)),
        )
        if (cancelled) return
        const failed: FailedScenarioItem[] = []
        for (const d of details) {
          if (!d) continue
          for (const sr of d.scenario_results || []) {
            if (sr.status !== "pass") {
              failed.push({
                run_id: d.run_id,
                scenario_id: sr.scenario_id,
                scenario_name: sr.scenario_name,
                error: sr.error,
                reasoning: sr.reasoning,
                started_at: d.started_at,
              })
            }
          }
        }
        setFailedScenarios(failed.slice(0, 6))
      } catch (e: any) {
        if (!cancelled) setError(e?.message || String(e))
      }
    })()

    return () => {
      cancelled = true
    }
  }, [])

  const loading = runs === null

  const completedRuns = useMemo(
    () => (runs ?? []).filter((r) => r.status === "completed" && r.total > 0),
    [runs],
  )

  const kpis = useMemo(() => {
    if (!completedRuns.length) {
      return {
        reliability: "—",
        passRate: "—",
        totalRuns: runs?.length ?? 0,
        flakyCount: flakiness?.filter((s) => s.is_flaky).length ?? 0,
        failedRuns: 0,
        scenariosRun: 0,
      }
    }
    const totalPassed = completedRuns.reduce((acc, r) => acc + r.passed, 0)
    const totalRun = completedRuns.reduce((acc, r) => acc + r.total, 0)
    const overallPass = totalRun > 0 ? totalPassed / totalRun : 0
    const fullPassRate =
      completedRuns.filter((r) => r.pass_rate >= 1).length / completedRuns.length
    return {
      reliability: `${(fullPassRate * 100).toFixed(1)}%`,
      passRate: `${(overallPass * 100).toFixed(1)}%`,
      totalRuns: runs?.length ?? 0,
      flakyCount: flakiness?.filter((s) => s.is_flaky).length ?? 0,
      failedRuns: completedRuns.filter((r) => r.pass_rate < 1).length,
      scenariosRun: totalRun,
    }
  }, [completedRuns, runs, flakiness])

  const reliabilitySeries = useMemo(
    () => computeReliabilitySeries(runs ?? []),
    [runs],
  )

  const regressionData: RegressionDatum[] = useMemo(() => {
    if (!completedRuns.length) return []
    // Aggregate by failure category — we don't store this granularly server-side,
    // so derive a simple breakdown from per-run pass/fail counts.
    const failed = completedRuns.reduce((acc, r) => acc + (r.total - r.passed), 0)
    const errored = completedRuns.filter((r) => r.pass_rate === 0).length
    const skipped = (runs ?? []).reduce((acc, r) => acc + r.skipped_count, 0)
    return [
      { name: "Failures", regressions: failed, color: "var(--color-error)" },
      { name: "Errors", regressions: errored, color: "var(--color-warning)" },
      { name: "Skipped", regressions: skipped, color: "var(--color-chart-2, var(--color-muted-foreground))" },
    ].filter((d) => d.regressions > 0)
  }, [completedRuns, runs])

  return (
    <MainLayout>
      <div className="flex">
        <div className="min-w-0 flex-1 p-4 sm:p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-semibold text-foreground" data-testid="page-title">Overview</h1>
            <p className="text-sm text-muted-foreground">
              AI evaluation reliability at a glance
            </p>
          </div>

          {error && (
            <div className="mb-4" data-testid="overview-error">
              <ErrorState error={error} />
            </div>
          )}

          <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-6">
            <StatCard
              title="Reliability Score"
              value={kpis.reliability}
              icon={<Activity className="h-4 w-4 text-primary" />}
              loading={loading}
            />
            <StatCard
              title="Pass Rate"
              value={kpis.passRate}
              icon={<CheckCircle2 className="h-4 w-4 text-success" />}
              loading={loading}
            />
            <StatCard
              title="Total Runs"
              value={kpis.totalRuns}
              icon={<Hash className="h-4 w-4 text-muted-foreground" />}
              loading={loading}
            />
            <StatCard
              title="Flaky Scenarios"
              value={kpis.flakyCount}
              icon={<Zap className="h-4 w-4 text-warning" />}
              loading={loading}
            />
            <StatCard
              title="Failed Runs"
              value={kpis.failedRuns}
              icon={<XCircle className="h-4 w-4 text-error" />}
              loading={loading}
            />
            <StatCard
              title="Scenarios Executed"
              value={kpis.scenariosRun}
              icon={<AlertTriangle className="h-4 w-4 text-muted-foreground" />}
              loading={loading}
            />
          </div>

          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12 min-w-0 overflow-hidden rounded-xl border border-border bg-card p-4 sm:p-5 xl:col-span-8">
              <div className="mb-4">
                <h2 className="text-sm font-semibold text-foreground">
                  Reliability Over Time
                </h2>
                <p className="text-xs text-muted-foreground">
                  Pass rate per completed run
                </p>
              </div>
              <ReliabilityChart data={reliabilitySeries} />
            </div>

            <div className="col-span-12 min-w-0 overflow-hidden rounded-xl border border-border bg-card p-4 sm:p-5 xl:col-span-4">
              <div className="mb-4">
                <h2 className="text-sm font-semibold text-foreground">
                  Failure Breakdown
                </h2>
                <p className="text-xs text-muted-foreground">Across recent runs</p>
              </div>
              <RegressionBreakdown data={regressionData} />
            </div>

            <div className="col-span-12 rounded-xl border border-border bg-card p-5 xl:col-span-8">
              <div className="mb-4">
                <h2 className="text-sm font-semibold text-foreground">Recent Runs</h2>
                <p className="text-xs text-muted-foreground">Latest evaluation results</p>
              </div>
              <RecentRunsTable runs={(runs ?? []).slice(0, 8)} />
            </div>

            <div className="col-span-12 min-w-0 overflow-hidden rounded-xl border border-border bg-card p-4 sm:p-5 xl:col-span-4">
              <div className="mb-4">
                <h2 className="text-sm font-semibold text-foreground">Flaky Scenarios</h2>
                <p className="text-xs text-muted-foreground">Last 10-run window</p>
              </div>
              <FlakySuitesPanel stats={flakiness ?? []} />
            </div>

            <div className="col-span-12 min-w-0 overflow-hidden rounded-xl border border-border bg-card p-4 sm:p-5">
              <div className="mb-4">
                <h2 className="text-sm font-semibold text-foreground">Failed Scenarios</h2>
                <p className="text-xs text-muted-foreground">From most-recent failing runs</p>
              </div>
              <FailedScenariosFeed items={failedScenarios} />
            </div>
          </div>
        </div>

        <div className="hidden w-[320px] shrink-0 border-l border-border bg-card/30 p-4 xl:block">
          <UtilityRail runs={runs ?? []} />
        </div>
      </div>
    </MainLayout>
  )
}
