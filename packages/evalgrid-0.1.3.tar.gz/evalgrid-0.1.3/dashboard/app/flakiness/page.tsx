"use client"

import { useEffect, useMemo, useState } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { EmptyState, ErrorState } from "@/components/states/empty"
import {
  Zap,
  Percent,
  BarChart3,
  Hash,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  ChevronRight,
} from "lucide-react"
import { api, type FlakinessStat } from "@/lib/api"

export default function FlakinessPage() {
  const [stats, setStats] = useState<FlakinessStat[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [windowSize, setWindowSize] = useState(10)

  useEffect(() => {
    let cancelled = false
    setStats(null)
    api
      .flakiness(windowSize)
      .then((s) => {
        if (!cancelled) {
          setStats(s)
          setError(null)
        }
      })
      .catch((e) => {
        if (!cancelled) setError(e?.message || String(e))
      })
    return () => {
      cancelled = true
    }
  }, [windowSize])

  const summary = useMemo(() => {
    if (!stats) return null
    const flaky = stats.filter((s) => s.is_flaky)
    const avgFlake =
      flaky.length === 0
        ? 0
        : flaky.reduce((acc, s) => acc + s.flakiness_score, 0) / flaky.length
    const totalRuns = stats.reduce((acc, s) => acc + s.run_count, 0)
    const totalFails = stats.reduce((acc, s) => acc + s.fail_count + s.error_count, 0)
    return {
      flakyCount: flaky.length,
      avgFlakinessPct: avgFlake * 100,
      scenariosTracked: stats.length,
      totalRuns,
      totalFails,
    }
  }, [stats])

  return (
    <MainLayout>
      <div className="p-4 sm:p-6">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <h1 className="text-2xl font-semibold text-foreground" data-testid="page-title">Flakiness Analysis</h1>
            <p className="text-sm text-muted-foreground">
              Per-scenario stability across the last {windowSize} runs
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={windowSize}
              onChange={(e) => setWindowSize(Number(e.target.value))}
              className="rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground"
              data-testid="flakiness-window"
            >
              <option value={5}>Window: 5</option>
              <option value={10}>Window: 10</option>
              <option value={20}>Window: 20</option>
              <option value={50}>Window: 50</option>
            </select>
            <button
              onClick={() => setWindowSize((w) => w)}
              className="flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm font-medium text-foreground hover:bg-muted"
              data-testid="flakiness-refresh"
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </button>
          </div>
        </div>

        {error && <ErrorState error={error} />}

        {!error && stats === null && (
          <p className="text-sm text-muted-foreground">Loading flakiness data…</p>
        )}

        {!error && stats !== null && (
          <>
            <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-xl border border-border bg-card p-4">
                <div className="flex items-center gap-2">
                  <Zap className="h-4 w-4 text-warning" />
                  <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Flaky Scenarios
                  </span>
                </div>
                <p className="mt-2 text-2xl font-semibold tabular-nums text-foreground" data-testid="flakiness-stat-flaky">
                  {summary?.flakyCount ?? 0}
                </p>
              </div>
              <div className="rounded-xl border border-border bg-card p-4">
                <div className="flex items-center gap-2">
                  <Percent className="h-4 w-4 text-primary" />
                  <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Avg Flakiness
                  </span>
                </div>
                <p className="mt-2 text-2xl font-semibold tabular-nums text-foreground">
                  {(summary?.avgFlakinessPct ?? 0).toFixed(1)}%
                </p>
              </div>
              <div className="rounded-xl border border-border bg-card p-4">
                <div className="flex items-center gap-2">
                  <Hash className="h-4 w-4 text-muted-foreground" />
                  <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Scenarios Tracked
                  </span>
                </div>
                <p className="mt-2 text-2xl font-semibold tabular-nums text-foreground">
                  {summary?.scenariosTracked ?? 0}
                </p>
              </div>
              <div className="rounded-xl border border-border bg-card p-4">
                <div className="flex items-center gap-2">
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                  <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Total Failures
                  </span>
                </div>
                <p className="mt-2 text-2xl font-semibold tabular-nums text-foreground">
                  {summary?.totalFails ?? 0}
                </p>
              </div>
            </div>

            {stats.length === 0 ? (
              <EmptyState
                title="No scenario history yet"
                description="Run a few evaluations to populate flakiness statistics."
              />
            ) : (
              <div className="rounded-xl border border-border bg-card p-5">
                <h2 className="mb-4 text-sm font-semibold text-foreground">
                  Scenario stability ranking
                </h2>
                <div className="space-y-2" data-testid="flakiness-ranking">
                  {stats.map((s, i) => (
                    <div
                      key={s.scenario_id}
                      className="group flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border bg-card/50 p-3"
                      data-testid={`flakiness-row-${s.scenario_id}`}
                    >
                      <div className="flex min-w-0 flex-1 items-center gap-3">
                        <span
                          className={`flex h-6 w-6 shrink-0 items-center justify-center rounded text-xs font-semibold ${
                            s.is_flaky
                              ? "bg-warning/10 text-warning"
                              : s.pass_rate === 1
                              ? "bg-success/10 text-success"
                              : "bg-error/10 text-error"
                          }`}
                        >
                          {i + 1}
                        </span>
                        <div className="min-w-0">
                          <p className="truncate font-medium text-foreground">{s.scenario_name}</p>
                          <p className="truncate text-xs text-muted-foreground">
                            {s.run_count} runs · {s.pass_count}P / {s.fail_count}F / {s.error_count}E · last: {s.last_status}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p
                            className={`tabular-nums text-lg font-semibold ${
                              s.is_flaky ? "text-warning" : s.pass_rate === 1 ? "text-success" : "text-error"
                            }`}
                          >
                            {(s.flakiness_score * 100).toFixed(0)}%
                          </p>
                          <p className="text-xs text-muted-foreground">flakiness</p>
                        </div>
                        <div className="text-right">
                          <p className="tabular-nums text-sm font-medium text-foreground">
                            {(s.pass_rate * 100).toFixed(0)}%
                          </p>
                          <p className="flex items-center justify-end gap-0.5 text-xs">
                            {s.pass_rate >= 0.5 ? (
                              <TrendingUp className="h-3 w-3 text-success" />
                            ) : (
                              <TrendingDown className="h-3 w-3 text-error" />
                            )}
                            <span className="text-muted-foreground">pass</span>
                          </p>
                        </div>
                        <ChevronRight className="h-4 w-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-4 rounded-xl border border-dashed border-border bg-card/40 p-4 text-xs text-muted-foreground">
              Retry distribution, confidence histograms, and per-hour heatmaps require additional
              per-attempt telemetry — they ship in v0.2.
            </div>
          </>
        )}
      </div>
    </MainLayout>
  )
}
