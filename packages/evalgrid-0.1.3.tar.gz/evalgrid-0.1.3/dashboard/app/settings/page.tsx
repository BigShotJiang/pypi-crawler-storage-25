"use client"

import { useEffect, useState } from "react"
import { toast } from "sonner"
import { MainLayout } from "@/components/layout/main-layout"
import { ErrorState } from "@/components/states/empty"
import { Settings, Key, CheckCircle2, XCircle, Loader2 } from "lucide-react"
import { api, type ConfigStatus } from "@/lib/api"

export default function SettingsPage() {
  const [config, setConfig] = useState<ConfigStatus | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    api
      .configStatus()
      .then((c) => {
        if (!cancelled) {
          setConfig(c)
          setError(null)
        }
      })
      .catch((e) => {
        if (!cancelled) setError(e?.message || String(e))
      })
    return () => {
      cancelled = true
    }
  }, [])

  // Optimistic state update from the POST response — no refetch needed.
  const onKeyUpdated = (label: "ANTHROPIC_API_KEY" | "OPENAI_API_KEY") => {
    setConfig((prev) =>
      prev === null
        ? prev
        : {
            ...prev,
            anthropic_key_set:
              label === "ANTHROPIC_API_KEY" ? true : prev.anthropic_key_set,
            openai_key_set:
              label === "OPENAI_API_KEY" ? true : prev.openai_key_set,
            any_key_set:
              prev.any_key_set ||
              label === "ANTHROPIC_API_KEY" ||
              label === "OPENAI_API_KEY",
          },
    )
  }

  return (
    <MainLayout>
      <div className="p-4 sm:p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold text-foreground" data-testid="page-title">Settings</h1>
          <p className="text-sm text-muted-foreground">
            Configure the running evalgrid server. Keys you enter here are kept
            in process memory only.
          </p>
        </div>

        {error && <ErrorState error={error} />}

        {!error && (
          <div className="max-w-2xl space-y-6" data-testid="settings-content">
            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold text-foreground">
                <Key className="h-4 w-4 text-primary" /> API Provider Keys
              </h2>
              {config === null ? (
                <p className="text-sm text-muted-foreground">Loading…</p>
              ) : (
                <div className="space-y-3" data-testid="settings-keys">
                  <KeyInput
                    label="ANTHROPIC_API_KEY"
                    isSet={config.anthropic_key_set}
                    onSaved={() => onKeyUpdated("ANTHROPIC_API_KEY")}
                  />
                  <KeyInput
                    label="OPENAI_API_KEY"
                    isSet={config.openai_key_set}
                    onSaved={() => onKeyUpdated("OPENAI_API_KEY")}
                  />
                  <KeyStatus label="Mock mode available" set={config.mock_available} />
                </div>
              )}
              <p className="mt-4 text-xs text-muted-foreground">
                Keys are stored in server process memory only. They are cleared on
                restart and never written to disk. For permanent configuration set
                the env var in the shell that runs{" "}
                <code className="rounded bg-muted px-1">evalgrid server</code>.
              </p>
            </div>

            <div className="rounded-xl border border-dashed border-border bg-card/40 p-6">
              <h2 className="mb-2 flex items-center gap-2 text-sm font-semibold text-foreground">
                <Settings className="h-4 w-4 text-muted-foreground" /> Team, billing &amp; integrations
              </h2>
              <p className="text-sm text-muted-foreground">
                Multi-user workspaces, billing, third-party integrations, audit logs, and 2FA
                ship in v0.2+. Today evalgrid runs as a single-user local tool against your own
                API keys.
              </p>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}

function KeyInput({
  label,
  isSet,
  onSaved,
}: {
  label: "ANTHROPIC_API_KEY" | "OPENAI_API_KEY"
  isSet: boolean
  onSaved: () => void
}) {
  const [value, setValue] = useState("")
  const [submitting, setSubmitting] = useState(false)

  const onSave = async () => {
    const trimmed = value.trim()
    if (!trimmed || submitting) return
    setSubmitting(true)
    try {
      await api.setKeys({ [label]: trimmed } as any)
      toast.success("Key updated for this session", {
        description: `${label} is set in server memory until restart.`,
      })
      setValue("")
      onSaved()
    } catch (err: any) {
      toast.error("Could not save key", {
        description: err?.message ?? String(err),
      })
    } finally {
      setSubmitting(false)
    }
  }

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault()
      onSave()
    }
  }

  return (
    <div
      className="flex flex-col gap-2 rounded-lg border border-border bg-card/50 p-3"
      data-testid={`setting-${label}`}
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <code className="break-all font-mono text-sm text-foreground">{label}</code>
        <span
          className={`flex items-center gap-1.5 text-xs font-medium ${
            isSet ? "text-success" : "text-error"
          }`}
        >
          {isSet ? (
            <>
              <CheckCircle2 className="h-4 w-4" /> set (in memory)
            </>
          ) : (
            <>
              <XCircle className="h-4 w-4" /> not set
            </>
          )}
        </span>
      </div>
      <div className="flex gap-2">
        <input
          type="password"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder={isSet ? "Enter a new key to replace…" : "Paste your key…"}
          className="min-w-0 flex-1 rounded-md border border-border bg-background px-3 py-2 font-mono text-sm text-foreground focus:border-primary focus:outline-none"
          data-testid={`setting-${label}-input`}
          autoComplete="off"
        />
        <button
          type="button"
          onClick={onSave}
          disabled={!value.trim() || submitting}
          className="flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
          data-testid={`setting-${label}-save`}
        >
          {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}
        </button>
      </div>
    </div>
  )
}

function KeyStatus({ label, set }: { label: string; set: boolean }) {
  return (
    <div
      className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border bg-card/50 p-3"
      data-testid={`setting-${label}`}
    >
      <code className="break-all font-mono text-sm text-foreground">{label}</code>
      <span
        className={`flex items-center gap-1.5 text-xs font-medium ${
          set ? "text-success" : "text-error"
        }`}
      >
        {set ? (
          <>
            <CheckCircle2 className="h-4 w-4" /> set
          </>
        ) : (
          <>
            <XCircle className="h-4 w-4" /> not set
          </>
        )}
      </span>
    </div>
  )
}
