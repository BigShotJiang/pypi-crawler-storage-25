"use client"

import { useEffect, useState } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { StatusBadge } from "@/components/ui/status-badge"
import { EmptyState, ErrorState } from "@/components/states/empty"
import {
  Search,
  Calendar,
  Activity,
  ChevronRight,
  Plus,
} from "lucide-react"
import { api, type SuiteListItem } from "@/lib/api"
import { NewSuiteDialog } from "@/components/benchmarks/new-suite-dialog"
import { relativeTime } from "@/lib/format"

// relativeTime moved to @/lib/format

export default function BenchmarksPage() {
  const [suites, setSuites] = useState<SuiteListItem[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState("")
  const [refreshTick, setRefreshTick] = useState(0)

  useEffect(() => {
    let cancelled = false
    api
      .listSuites()
      .then((s) => {
        if (!cancelled) {
          setSuites(s)
          setError(null)
        }
      })
      .catch((e) => {
        if (!cancelled) setError(e?.message || String(e))
      })
    return () => {
      cancelled = true
    }
  }, [refreshTick])

  const filtered = (suites ?? []).filter((s) => {
    if (!search.trim()) return true
    const q = search.trim().toLowerCase()
    return (
      s.suite_name.toLowerCase().includes(q) ||
      s.suite_id.toLowerCase().includes(q)
    )
  })

  return (
    <MainLayout>
      <div className="p-4 sm:p-6">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <h1 className="text-2xl font-semibold text-foreground" data-testid="page-title">Benchmarks</h1>
            <p className="text-sm text-muted-foreground">
              Benchmark suites recorded by <code className="rounded bg-muted px-1 text-xs">evalgrid run --suite</code>
            </p>
          </div>
          <NewSuiteDialog
            onCreated={() => setRefreshTick((t) => t + 1)}
            trigger={
              <button
                type="button"
                className="flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
                data-testid="benchmarks-new"
              >
                <Plus className="h-4 w-4" />
                New Benchmark
              </button>
            }
          />
        </div>

        <div className="mb-6 flex flex-wrap items-center gap-3">
          <div className="relative w-full min-w-0 max-w-md flex-1 sm:w-auto">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              type="text"
              placeholder="Search benchmarks..."
              className="w-full rounded-md border border-border bg-card py-2 pl-9 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              data-testid="benchmarks-search"
            />
          </div>
        </div>

        {error && <ErrorState error={error} />}

        {!error && suites === null && (
          <p className="text-sm text-muted-foreground">Loading benchmarks…</p>
        )}

        {!error && suites !== null && filtered.length === 0 && (
          <EmptyState
            title={suites.length === 0 ? "No benchmark runs yet" : "No matches"}
            description={
              suites.length === 0
                ? "Define a suite under ~/.evalgrid/suites/ and run it with: evalgrid run --suite my-suite"
                : "Try a different search term."
            }
          />
        )}

        {filtered.length > 0 && (
          <div className="grid grid-cols-1 gap-4 xl:grid-cols-2" data-testid="benchmarks-grid">
            {filtered.map((suite) => (
              <div
                key={suite.suite_id}
                className="group cursor-pointer rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary/50"
                data-testid={`benchmark-card-${suite.suite_id}`}
              >
                <div className="mb-4 flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-foreground group-hover:text-primary">
                        {suite.suite_name}
                      </h3>
                      <StatusBadge
                        status={
                          suite.latest_passed === null
                            ? "info"
                            : suite.latest_passed
                            ? "success"
                            : "error"
                        }
                        label={
                          suite.latest_passed === null
                            ? "No data"
                            : suite.latest_passed
                            ? "passed"
                            : "failed"
                        }
                        showDot={false}
                      />
                    </div>
                    <p className="mt-1 font-mono text-xs text-muted-foreground">{suite.suite_id}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between border-t border-border pt-4">
                  <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Activity className="h-3.5 w-3.5" />
                    {suite.run_count} runs
                  </span>
                  <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Calendar className="h-3.5 w-3.5" />
                    {relativeTime(suite.latest_run)}
                  </span>
                  <ChevronRight className="h-4 w-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  )
}
