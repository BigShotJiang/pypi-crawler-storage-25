"use client"

// Create-only dialog for benchmark suites. Same controlled-state pattern as
// new-scenario-dialog. Multi-select implemented with native checkboxes — a
// Combobox would be nicer but it's deferred to v0.1.4 along with edit/delete.

import { useEffect, useMemo, useState } from "react"
import { toast } from "sonner"
import { Loader2, Search } from "lucide-react"

import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { api, type NewSuiteBody, type ScenarioListItem } from "@/lib/api"
import { Field, inputClass } from "@/components/ui/form-field"
import { isValidSlug, SLUG_ERROR, SLUG_HINT } from "@/lib/validators"

interface NewSuiteDialogProps {
  trigger: React.ReactNode
  onCreated?: (id: string) => void
}

export function NewSuiteDialog({ trigger, onCreated }: NewSuiteDialogProps) {
  const [open, setOpen] = useState(false)
  const [id, setId] = useState("")
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [tagsText, setTagsText] = useState("")
  const [scenarios, setScenarios] = useState<ScenarioListItem[] | null>(null)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [search, setSearch] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const [serverError, setServerError] = useState<string | null>(null)

  useEffect(() => {
    if (!open) return
    let cancelled = false
    api
      .listScenarios()
      .then((s) => {
        if (!cancelled) setScenarios(s)
      })
      .catch((e) => {
        if (!cancelled) toast.error(`Failed to load scenarios: ${e?.message || e}`)
      })
    return () => {
      cancelled = true
    }
  }, [open])

  const reset = () => {
    setId("")
    setName("")
    setDescription("")
    setTagsText("")
    setSelected(new Set())
    setSearch("")
    setServerError(null)
  }

  const filtered = useMemo(() => {
    if (!scenarios) return [] as ScenarioListItem[]
    const q = search.trim().toLowerCase()
    if (!q) return scenarios
    return scenarios.filter(
      (s) =>
        s.id.toLowerCase().includes(q) ||
        s.name.toLowerCase().includes(q) ||
        s.tags.some((t) => t.toLowerCase().includes(q)),
    )
  }, [scenarios, search])

  const toggle = (sid: string) => {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(sid)) next.delete(sid)
      else next.add(sid)
      return next
    })
  }

  const idValid = isValidSlug(id)
  const idError = id && !idValid ? SLUG_ERROR : ""
  const nameValid = name.trim().length > 0
  const canSubmit =
    idValid && nameValid && selected.size > 0 && !submitting

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!canSubmit) return
    setSubmitting(true)
    setServerError(null)
    try {
      const body: NewSuiteBody = {
        id: id.trim(),
        name: name.trim(),
        description: description.trim(),
        scenarios: Array.from(selected),
        tags: tagsText
          .split(",")
          .map((t) => t.trim())
          .filter(Boolean),
      }
      const created = await api.createSuite(body)
      toast.success("Benchmark created", {
        description: `${created.suite_name} — ${created.scenario_count} scenario(s)`,
      })
      reset()
      setOpen(false)
      onCreated?.(created.suite_id)
    } catch (err: any) {
      const msg = err?.message ?? String(err)
      setServerError(msg)
      toast.error("Could not create benchmark", { description: msg })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        setOpen(o)
        if (!o) setServerError(null)
      }}
    >
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent
        className="max-h-[90vh] overflow-y-auto sm:max-w-2xl"
        data-testid="new-suite-dialog"
      >
        <DialogHeader>
          <DialogTitle>New Benchmark</DialogTitle>
          <DialogDescription>
            A suite is a set of scenarios run together with a pass threshold.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4 px-1">
          <Field label="ID" hint={idError || SLUG_HINT} error={idError} htmlFor="newsuite-id">
            <input
              type="text"
              value={id}
              onChange={(e) => setId(e.target.value)}
              placeholder="my-benchmark"
              className={inputClass(!!idError)}
              data-testid="newsuite-id"
              autoFocus
            />
          </Field>

          <Field label="Name">
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="My Benchmark"
              className={inputClass(false)}
              data-testid="newsuite-name"
            />
          </Field>

          <Field label="Description (optional)">
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              className={inputClass(false)}
              data-testid="newsuite-description"
            />
          </Field>

          <Field label="Tags (optional)" hint="comma-separated">
            <input
              type="text"
              value={tagsText}
              onChange={(e) => setTagsText(e.target.value)}
              placeholder="nightly, regression"
              className={inputClass(false)}
              data-testid="newsuite-tags"
            />
          </Field>

          <div className="flex flex-col gap-2 rounded-md border border-border bg-card/30 p-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Scenarios ({selected.size} selected)
              </span>
              <div className="relative w-48">
                <Search className="absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Filter…"
                  className="w-full rounded-md border border-border bg-background py-1 pl-7 pr-2 text-xs"
                  data-testid="newsuite-scenario-filter"
                />
              </div>
            </div>
            <div
              className="max-h-64 overflow-y-auto rounded-md border border-border bg-background"
              data-testid="newsuite-scenario-list"
            >
              {scenarios === null ? (
                <p className="p-2 text-xs text-muted-foreground">Loading…</p>
              ) : filtered.length === 0 ? (
                <p className="p-2 text-xs text-muted-foreground">
                  No scenarios match. Create one from the Scenarios page first.
                </p>
              ) : (
                <ul className="divide-y divide-border">
                  {filtered.map((s) => (
                    <li key={s.id}>
                      <label
                        className="flex cursor-pointer items-center gap-2 px-2 py-1.5 text-sm hover:bg-muted/40"
                        data-testid={`newsuite-scenario-${s.id}`}
                      >
                        <input
                          type="checkbox"
                          checked={selected.has(s.id)}
                          onChange={() => toggle(s.id)}
                          className="h-4 w-4 rounded border-border accent-primary"
                        />
                        <code className="font-mono text-xs text-foreground">{s.id}</code>
                        <span className="truncate text-xs text-muted-foreground">
                          {s.name}
                        </span>
                        {s.tags.length > 0 && (
                          <span className="ml-auto flex gap-1">
                            {s.tags.slice(0, 3).map((t) => (
                              <span
                                key={t}
                                className="rounded bg-primary/10 px-1.5 py-0.5 text-[10px] text-primary"
                              >
                                {t}
                              </span>
                            ))}
                          </span>
                        )}
                      </label>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            {selected.size === 0 && (
              <p className="text-xs text-muted-foreground">
                Select at least one scenario to enable Create.
              </p>
            )}
          </div>

          {serverError && (
            <p className="rounded-md border border-error/30 bg-error/10 p-2 text-xs text-error" data-testid="newsuite-server-error">
              {serverError}
            </p>
          )}

          <DialogFooter className="flex-row justify-end gap-2">
            <DialogClose asChild>
              <button
                type="button"
                className="rounded-md border border-border px-3 py-2 text-sm font-medium text-foreground hover:bg-muted"
              >
                Cancel
              </button>
            </DialogClose>
            <button
              type="submit"
              disabled={!canSubmit}
              className="flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
              data-testid="newsuite-submit"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              Create benchmark
            </button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

// Field + inputClass moved to @/components/ui/form-field. Validators moved
// to @/lib/validators.
