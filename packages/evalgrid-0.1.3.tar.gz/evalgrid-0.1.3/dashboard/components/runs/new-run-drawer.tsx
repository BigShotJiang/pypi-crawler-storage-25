"use client"

import { useEffect, useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { Loader2, Play } from "lucide-react"

import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet"
import { api, type NewRunBody, type ScenarioListItem, type SuiteListItem } from "@/lib/api"

interface NewRunDrawerProps {
  trigger: React.ReactNode
}

// A small curated list — covers Anthropic + OpenAI defaults. Anything not in
// this list can be entered via "Custom…". The CLI accepts any LiteLLM model
// id; the UI just surfaces the common ones to keep the drawer scannable.
const AGENT_MODEL_PRESETS = [
  { value: "", label: "Default (from config)" },
  { value: "claude-haiku-4-5", label: "claude-haiku-4-5" },
  { value: "claude-sonnet-4-6", label: "claude-sonnet-4-6" },
  { value: "claude-opus-4-7", label: "claude-opus-4-7" },
  { value: "gpt-4o", label: "gpt-4o" },
  { value: "gpt-4o-mini", label: "gpt-4o-mini" },
  { value: "__custom__", label: "Custom…" },
] as const

const JUDGE_MODEL_PRESETS = [
  { value: "", label: "Same as agent" },
  { value: "claude-haiku-4-5", label: "claude-haiku-4-5" },
  { value: "claude-sonnet-4-6", label: "claude-sonnet-4-6" },
  { value: "claude-opus-4-7", label: "claude-opus-4-7" },
  { value: "gpt-4o", label: "gpt-4o" },
  { value: "gpt-4o-mini", label: "gpt-4o-mini" },
  { value: "__custom__", label: "Custom…" },
] as const

export function NewRunDrawer({ trigger }: NewRunDrawerProps) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [scenarios, setScenarios] = useState<ScenarioListItem[] | null>(null)
  const [suites, setSuites] = useState<SuiteListItem[] | null>(null)
  const [tag, setTag] = useState<string>("")
  const [suite, setSuite] = useState<string>("")
  const [mock, setMock] = useState<boolean>(false)
  const [agentPreset, setAgentPreset] = useState<string>("")
  const [agentCustom, setAgentCustom] = useState<string>("")
  const [judgePreset, setJudgePreset] = useState<string>("")
  const [judgeCustom, setJudgeCustom] = useState<string>("")
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (!open) return
    let cancelled = false
    // include_mock=true so the example suite still appears even if it has
    // only ever been run in mock mode — otherwise fresh installs can't
    // launch the bundled example from the UI.
    Promise.all([api.listScenarios(), api.listSuites(true)])
      .then(([s, su]) => {
        if (cancelled) return
        setScenarios(s)
        setSuites(su)
      })
      .catch((e) => {
        if (!cancelled) toast.error(`Failed to load options: ${e?.message || e}`)
      })
    return () => {
      cancelled = true
    }
  }, [open])

  const distinctTags = useMemo(() => {
    if (!scenarios) return [] as string[]
    const set = new Set<string>()
    for (const s of scenarios) for (const t of s.tags) set.add(t)
    return Array.from(set).sort()
  }, [scenarios])

  const canSubmit = !!(tag || suite || mock)

  const resolveModel = (preset: string, custom: string): string | undefined => {
    if (preset === "__custom__") return custom.trim() || undefined
    return preset || undefined
  }

  const reset = () => {
    setTag("")
    setSuite("")
    setMock(false)
    setAgentPreset("")
    setAgentCustom("")
    setJudgePreset("")
    setJudgeCustom("")
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!canSubmit || submitting) return
    setSubmitting(true)
    try {
      const body: NewRunBody = {}
      if (tag) body.tags = [tag]
      if (suite) body.suite = suite
      if (mock) body.mock = true
      const agentModel = resolveModel(agentPreset, agentCustom)
      const judgeModel = resolveModel(judgePreset, judgeCustom)
      if (agentModel) body.agent_model = agentModel
      // "Same as agent" → omit judge_model; the backend uses agent_model for both
      if (judgeModel && judgeModel !== agentModel) body.judge_model = judgeModel

      const created = await api.createRun(body)
      toast.success("Run started", {
        description: `Run ${created.run_id.slice(0, 8)} is now executing.`,
      })
      reset()
      setOpen(false)
      router.push(`/runs/${created.run_id}`)
    } catch (err: any) {
      toast.error("Could not start run", {
        description: err?.message ?? String(err),
      })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>{trigger}</SheetTrigger>
      <SheetContent side="right" className="w-full sm:max-w-md" data-testid="new-run-drawer">
        <SheetHeader>
          <SheetTitle>New Run</SheetTitle>
          <SheetDescription>
            Launch an evaluation. Filter by tag or suite, or run in mock mode (no API calls).
          </SheetDescription>
        </SheetHeader>
        <form onSubmit={handleSubmit} className="flex flex-1 flex-col gap-4 overflow-y-auto px-4">
          <div className="flex flex-col gap-1.5">
            <label htmlFor="newrun-tag" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Tag
            </label>
            <select
              id="newrun-tag"
              value={tag}
              onChange={(e) => setTag(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:outline-none"
              data-testid="newrun-tag-select"
            >
              <option value="">All scenarios</option>
              {distinctTags.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="newrun-suite" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Suite
            </label>
            <select
              id="newrun-suite"
              value={suite}
              onChange={(e) => setSuite(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:outline-none"
              data-testid="newrun-suite-select"
            >
              <option value="">None</option>
              {(suites ?? []).map((s) => (
                <option key={s.suite_id} value={s.suite_id}>
                  {s.suite_name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="newrun-agent-model" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Agent Model
            </label>
            <select
              id="newrun-agent-model"
              value={agentPreset}
              onChange={(e) => setAgentPreset(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:outline-none"
              data-testid="newrun-agent-model"
            >
              {AGENT_MODEL_PRESETS.map((p) => (
                <option key={p.value} value={p.value}>
                  {p.label}
                </option>
              ))}
            </select>
            {agentPreset === "__custom__" && (
              <input
                type="text"
                value={agentCustom}
                onChange={(e) => setAgentCustom(e.target.value)}
                placeholder="e.g. claude-3-7-sonnet-latest or any LiteLLM model id"
                className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:outline-none"
                data-testid="newrun-agent-model-custom"
              />
            )}
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="newrun-judge-model" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Judge Model
            </label>
            <select
              id="newrun-judge-model"
              value={judgePreset}
              onChange={(e) => setJudgePreset(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:outline-none"
              data-testid="newrun-judge-model"
            >
              {JUDGE_MODEL_PRESETS.map((p) => (
                <option key={p.value} value={p.value}>
                  {p.label}
                </option>
              ))}
            </select>
            {judgePreset === "__custom__" && (
              <input
                type="text"
                value={judgeCustom}
                onChange={(e) => setJudgeCustom(e.target.value)}
                placeholder="e.g. gpt-4o or any LiteLLM model id"
                className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:outline-none"
                data-testid="newrun-judge-model-custom"
              />
            )}
          </div>

          <label className="flex items-center gap-2 rounded-md border border-border bg-card/50 p-3 text-sm text-foreground">
            <input
              type="checkbox"
              checked={mock}
              onChange={(e) => setMock(e.target.checked)}
              data-testid="newrun-mock-checkbox"
              className="h-4 w-4 rounded border-border accent-primary"
            />
            <span>
              Mock mode <span className="text-xs text-muted-foreground">— no API calls, deterministic pass</span>
            </span>
          </label>

          {!canSubmit && (
            <p className="text-xs text-muted-foreground">
              Pick a tag, suite, or enable mock mode to enable Run.
            </p>
          )}

          <SheetFooter className="mt-auto flex-row justify-end gap-2 p-0 pb-2">
            <SheetClose asChild>
              <button
                type="button"
                className="rounded-md border border-border px-3 py-2 text-sm font-medium text-foreground hover:bg-muted"
              >
                Cancel
              </button>
            </SheetClose>
            <button
              type="submit"
              disabled={!canSubmit || submitting}
              className="flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
              data-testid="newrun-submit"
            >
              {submitting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Play className="h-4 w-4" />
              )}
              Run
            </button>
          </SheetFooter>
        </form>
      </SheetContent>
    </Sheet>
  )
}
