"use client"

import Link from "next/link"
import { StatusBadge } from "@/components/ui/status-badge"
import { Clock, ArrowUpRight } from "lucide-react"
import type { RunSummary } from "@/lib/api"

function relativeTime(iso: string | null): string {
  if (!iso) return "—"
  const ts = Date.parse(iso)
  if (Number.isNaN(ts)) return "—"
  const diffMs = Date.now() - ts
  const secs = Math.max(0, Math.round(diffMs / 1000))
  if (secs < 60) return `${secs}s ago`
  const mins = Math.round(secs / 60)
  if (mins < 60) return `${mins}m ago`
  const hours = Math.round(mins / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.round(hours / 24)
  return `${days}d ago`
}

function statusOf(run: RunSummary): "success" | "warning" | "error" | "info" {
  if (run.status === "running") return "info"
  if (run.total === 0) return "warning"
  if (run.pass_rate >= 1) return "success"
  if (run.pass_rate >= 0.5) return "warning"
  return "error"
}

export function RecentRunsTable({ runs }: { runs: RunSummary[] }) {
  if (!runs.length) {
    return (
      <div className="rounded-lg border border-dashed border-border bg-card/40 p-6 text-center text-sm text-muted-foreground" data-testid="recent-runs-empty">
        No runs yet. Trigger an evaluation to see results here.
      </div>
    )
  }
  return (
    <div className="overflow-x-auto" data-testid="recent-runs-table">
      <table className="w-full">
        <thead>
          <tr className="border-b border-border">
            <th className="pb-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Run</th>
            <th className="pb-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Status</th>
            <th className="pb-3 text-right text-xs font-medium uppercase tracking-wider text-muted-foreground">Pass rate</th>
            <th className="pb-3 text-right text-xs font-medium uppercase tracking-wider text-muted-foreground">Passed / Total</th>
            <th className="pb-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Scenarios</th>
            <th className="pb-3 text-right text-xs font-medium uppercase tracking-wider text-muted-foreground">Time</th>
            <th className="pb-3"></th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {runs.map((run) => {
            const status = statusOf(run)
            const label =
              run.status === "running"
                ? "Running"
                : run.total === 0
                ? "Empty"
                : run.pass_rate >= 1
                ? "Passed"
                : run.pass_rate >= 0.5
                ? "Partial"
                : "Failed"
            return (
              <tr key={run.run_id} className="group" data-testid={`run-row-${run.run_id}`}>
                <td className="py-3">
                  <Link
                    href={`/runs/${run.run_id}`}
                    className="font-mono text-xs font-medium text-foreground hover:text-primary"
                  >
                    {run.run_id.slice(0, 8)}
                  </Link>
                </td>
                <td className="py-3">
                  <StatusBadge status={status as any} label={label} />
                </td>
                <td className="py-3 text-right">
                  <span className="tabular-nums text-sm font-medium text-foreground">
                    {run.total > 0 ? `${(run.pass_rate * 100).toFixed(1)}%` : "—"}
                  </span>
                </td>
                <td className="py-3 text-right">
                  <span className="tabular-nums text-sm text-muted-foreground">
                    {run.passed} / {run.total}
                  </span>
                </td>
                <td className="py-3">
                  <span className="truncate text-xs text-muted-foreground">
                    {run.scenario_names.slice(0, 2).join(", ")}
                    {run.scenario_names.length > 2 ? ` +${run.scenario_names.length - 2}` : ""}
                  </span>
                </td>
                <td className="py-3 text-right">
                  <span className="flex items-center justify-end gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {relativeTime(run.started_at)}
                  </span>
                </td>
                <td className="py-3 text-right">
                  <Link
                    href={`/runs/${run.run_id}`}
                    className="opacity-0 transition-opacity group-hover:opacity-100"
                  >
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground hover:text-foreground" />
                  </Link>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
