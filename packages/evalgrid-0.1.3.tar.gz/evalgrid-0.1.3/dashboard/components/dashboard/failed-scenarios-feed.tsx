"use client"

import { XCircle, Clock, ArrowRight } from "lucide-react"
import Link from "next/link"

export type FailedScenarioItem = {
  run_id: string
  scenario_id: string
  scenario_name: string
  error: string | null
  reasoning: string
  started_at: string
}

function relativeTime(iso: string): string {
  const ts = Date.parse(iso)
  if (Number.isNaN(ts)) return "—"
  const diffMs = Date.now() - ts
  const secs = Math.max(0, Math.round(diffMs / 1000))
  if (secs < 60) return `${secs}s ago`
  const mins = Math.round(secs / 60)
  if (mins < 60) return `${mins}m ago`
  const hours = Math.round(mins / 60)
  if (hours < 24) return `${hours}h ago`
  return `${Math.round(hours / 24)}d ago`
}

export function FailedScenariosFeed({ items }: { items: FailedScenarioItem[] }) {
  if (!items.length) {
    return (
      <div className="rounded-lg border border-dashed border-border bg-card/40 p-4 text-center text-sm text-muted-foreground" data-testid="failed-scenarios-empty">
        No failures in recent runs.
      </div>
    )
  }
  return (
    <div className="space-y-2" data-testid="failed-scenarios-feed">
      {items.slice(0, 6).map((item) => (
        <Link
          key={`${item.run_id}-${item.scenario_id}`}
          href={`/runs/${item.run_id}`}
          className="group block rounded-lg border border-border bg-card/50 p-3 transition-colors hover:bg-card"
          data-testid={`failed-scenario-${item.scenario_id}`}
        >
          <div className="flex items-start gap-3">
            <div className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded bg-error/10">
              <XCircle className="h-3.5 w-3.5 text-error" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <p className="truncate text-sm font-medium text-foreground">
                  {item.scenario_name}
                </p>
                <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
              </div>
              <p className="text-xs text-muted-foreground">run {item.run_id.slice(0, 8)}</p>
              <p className="mt-1.5 line-clamp-2 text-xs text-error/80">
                {item.error || item.reasoning || "No reason provided"}
              </p>
              <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                {relativeTime(item.started_at)}
              </p>
            </div>
          </div>
        </Link>
      ))}
    </div>
  )
}
