"use client"

import { Activity, Loader2 } from "lucide-react"
import type { RunSummary } from "@/lib/api"

export function UtilityRail({ runs }: { runs: RunSummary[] }) {
  const running = runs.filter((r) => r.status === "running")
  return (
    <div className="space-y-6" data-testid="utility-rail">
      <div className="rounded-xl border border-border bg-card p-4">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
          {running.length > 0 ? (
            <Loader2 className="h-4 w-4 animate-spin text-primary" />
          ) : (
            <Activity className="h-4 w-4 text-muted-foreground" />
          )}
          Currently Running
          <span className="ml-auto rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
            {running.length}
          </span>
        </h3>
        {running.length === 0 ? (
          <p className="text-xs text-muted-foreground">No active runs.</p>
        ) : (
          <div className="space-y-2">
            {running.map((r) => (
              <div
                key={r.run_id}
                className="rounded-lg border border-border bg-card/50 p-2.5"
                data-testid={`running-run-${r.run_id}`}
              >
                <p className="truncate font-mono text-xs text-foreground">{r.run_id.slice(0, 12)}</p>
                <p className="text-xs text-muted-foreground">started {new Date(r.started_at).toLocaleTimeString()}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="rounded-xl border border-dashed border-border bg-card/40 p-4 text-xs text-muted-foreground">
        <p className="mb-1 font-medium text-foreground">Incidents &amp; alerts</p>
        <p>Real-time incident routing and alert rules ship in v0.2.</p>
      </div>
    </div>
  )
}
