"use client"

import {
  Area,
  AreaChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts"

export type ReliabilityPoint = { date: string; reliability: number }

export function ReliabilityChart({ data }: { data: ReliabilityPoint[] }) {
  if (!data.length) {
    return (
      <div className="flex h-[280px] w-full items-center justify-center rounded-lg border border-dashed border-border bg-card/40 text-sm text-muted-foreground" data-testid="reliability-chart-empty">
        No runs yet to chart.
      </div>
    )
  }
  return (
    <div className="h-[280px] w-full" data-testid="reliability-chart">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="reliabilityGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.2} />
              <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
          <XAxis
            dataKey="date"
            axisLine={false}
            tickLine={false}
            tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
            dy={10}
          />
          <YAxis
            domain={[0, 100]}
            axisLine={false}
            tickLine={false}
            tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
            dx={-10}
            tickFormatter={(value) => `${value}%`}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "var(--color-card)",
              border: "1px solid var(--color-border)",
              borderRadius: "8px",
              boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
            }}
            labelStyle={{ color: "var(--color-foreground)", fontWeight: 500 }}
            itemStyle={{ color: "var(--color-primary)" }}
            formatter={(value: number) => [`${value.toFixed(1)}%`, "Reliability"]}
          />
          <Area
            type="monotone"
            dataKey="reliability"
            stroke="var(--color-primary)"
            strokeWidth={2}
            fill="url(#reliabilityGradient)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}
