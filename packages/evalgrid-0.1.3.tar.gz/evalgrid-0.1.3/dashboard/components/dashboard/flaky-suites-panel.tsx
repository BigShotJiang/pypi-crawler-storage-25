"use client"

import { AlertTriangle } from "lucide-react"
import type { FlakinessStat } from "@/lib/api"

export function FlakySuitesPanel({ stats }: { stats: FlakinessStat[] }) {
  const flaky = stats.filter((s) => s.is_flaky)
  if (!flaky.length) {
    return (
      <div className="rounded-lg border border-dashed border-border bg-card/40 p-4 text-center text-sm text-muted-foreground" data-testid="flaky-suites-empty">
        No flaky scenarios detected yet.
      </div>
    )
  }
  return (
    <div className="space-y-3" data-testid="flaky-suites-panel">
      {flaky.slice(0, 5).map((s) => (
        <div
          key={s.scenario_id}
          className="flex items-center justify-between rounded-lg border border-border bg-card/50 p-3"
          data-testid={`flaky-row-${s.scenario_id}`}
        >
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-warning/10">
              <AlertTriangle className="h-4 w-4 text-warning" />
            </div>
            <div className="min-w-0">
              <p className="truncate text-sm font-medium text-foreground">{s.scenario_name}</p>
              <p className="text-xs text-muted-foreground">{s.run_count} runs · {s.pass_count}P / {s.fail_count}F / {s.error_count}E</p>
            </div>
          </div>
          <div className="text-right">
            <p className="tabular-nums text-sm font-semibold text-warning">
              {(s.flakiness_score * 100).toFixed(0)}%
            </p>
            <p className="text-xs text-muted-foreground">flakiness</p>
          </div>
        </div>
      ))}
    </div>
  )
}
