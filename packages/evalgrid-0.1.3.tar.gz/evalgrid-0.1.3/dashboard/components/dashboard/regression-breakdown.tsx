"use client"

import {
  Bar,
  BarChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from "recharts"

export type RegressionDatum = { name: string; regressions: number; color: string }

export function RegressionBreakdown({ data }: { data: RegressionDatum[] }) {
  if (!data.length) {
    return (
      <div className="flex h-[200px] w-full items-center justify-center rounded-lg border border-dashed border-border bg-card/40 text-sm text-muted-foreground" data-testid="regression-breakdown-empty">
        Not enough run history to compute regressions.
      </div>
    )
  }
  return (
    <div className="h-[200px] w-full" data-testid="regression-breakdown">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
          <XAxis
            type="number"
            axisLine={false}
            tickLine={false}
            tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
          />
          <YAxis
            type="category"
            dataKey="name"
            axisLine={false}
            tickLine={false}
            tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
            width={80}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "var(--color-card)",
              border: "1px solid var(--color-border)",
              borderRadius: "8px",
            }}
            formatter={(value: number) => [value, "Count"]}
          />
          <Bar dataKey="regressions" radius={[0, 4, 4, 0]} barSize={20}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
