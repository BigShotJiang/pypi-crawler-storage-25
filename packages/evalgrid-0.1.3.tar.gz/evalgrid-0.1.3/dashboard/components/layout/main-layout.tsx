"use client"

import { useState, useEffect } from "react"
import { Menu } from "lucide-react"
import { useTheme } from "next-themes"
import { Sidebar } from "./sidebar"

interface MainLayoutProps {
  children: React.ReactNode
}

export function MainLayout({ children }: MainLayoutProps) {
  // Theme is owned by next-themes (configured in app/layout.tsx). The previous
  // implementation kept local state + force-added `dark` to <html> on mount,
  // which meant every route transition snapped the UI back to dark and lost
  // any toggle. resolvedTheme reads from localStorage on every mount, so the
  // user's choice now survives nav, refresh, and back/forward.
  const { resolvedTheme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)

  // useTheme is undefined on the server / pre-hydration. Render the toggle
  // in its default state until mounted to avoid a brief icon flip.
  useEffect(() => {
    setMounted(true)
  }, [])

  const isDarkMode = mounted ? resolvedTheme !== "light" : true
  const toggleTheme = () => setTheme(isDarkMode ? "light" : "dark")

  return (
    <div className="min-h-screen bg-background">
      <Sidebar
        isDarkMode={isDarkMode}
        onToggleTheme={toggleTheme}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />
      <main className="lg:pl-[272px]">
        {/* Mobile top bar — sidebar toggle (sticky so it survives long scrolls) */}
        <div className="sticky top-0 z-20 flex h-12 items-center gap-2 border-b border-border bg-background/80 px-3 backdrop-blur lg:hidden">
          <button
            type="button"
            onClick={() => setSidebarOpen(true)}
            className="rounded-md border border-border p-2 text-foreground hover:bg-muted"
            aria-label="Open navigation"
            data-testid="mobile-nav-toggle"
          >
            <Menu className="h-4 w-4" />
          </button>
          <span className="text-sm font-semibold text-foreground">EvalGrid</span>
        </div>
        <div className="min-h-screen">{children}</div>
      </main>
    </div>
  )
}
