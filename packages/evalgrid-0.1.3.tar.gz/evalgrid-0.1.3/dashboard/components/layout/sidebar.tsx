"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  Play,
  BarChart3,
  Zap,
  FileCode,
  Settings,
  Moon,
  Sun,
} from "lucide-react"

// v0.1.3 — Datasets / PR Checks / Reports were removed from nav because the
// backend hasn't shipped yet. The route files remain so they can be re-enabled
// in v0.2+ without re-wiring imports. See BACKLOG.md.
const navigation = [
  { name: "Overview", href: "/", icon: LayoutDashboard },
  { name: "Runs", href: "/runs", icon: Play },
  { name: "Benchmarks", href: "/benchmarks", icon: BarChart3 },
  { name: "Flakiness", href: "/flakiness", icon: Zap },
  { name: "Scenarios", href: "/scenarios", icon: FileCode },
  { name: "Settings", href: "/settings", icon: Settings },
]

interface SidebarProps {
  isDarkMode: boolean
  onToggleTheme: () => void
  open: boolean
  onClose: () => void
}

export function Sidebar({ isDarkMode, onToggleTheme, open, onClose }: SidebarProps) {
  const pathname = usePathname()

  return (
    <>
      {/* Backdrop — only visible when the sidebar is open on small viewports */}
      <div
        onClick={onClose}
        className={cn(
          "fixed inset-0 z-30 bg-black/50 transition-opacity lg:hidden",
          open ? "opacity-100" : "pointer-events-none opacity-0",
        )}
        aria-hidden="true"
      />

      <aside
        className={cn(
          "fixed left-0 top-0 z-40 flex h-screen w-[272px] max-w-[85vw] flex-col bg-sidebar transition-transform lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
        )}
      >
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-white/[0.02] to-transparent" />

        <div className="relative flex h-16 items-center gap-3 border-b border-sidebar-border px-6">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <svg
              className="h-4 w-4 text-primary-foreground"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
            >
              <path d="M3 3v18h18" />
              <path d="M7 14l4-4 4 4 5-5" />
            </svg>
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-sidebar-foreground">EvalGrid</span>
            <span className="text-[10px] font-medium uppercase tracking-wider text-sidebar-muted">
              AI Reliability Observatory
            </span>
          </div>
        </div>

        <nav className="relative flex-1 space-y-1 overflow-y-auto px-3 py-4">
          {navigation.map((item) => {
            const isActive =
              pathname === item.href ||
              (item.href !== "/" && pathname.startsWith(item.href))

            return (
              <Link
                key={item.name}
                href={item.href}
                onClick={onClose}
                className={cn(
                  "group relative flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-foreground"
                    : "text-sidebar-muted hover:bg-sidebar-accent/50 hover:text-sidebar-foreground",
                )}
              >
                {isActive && (
                  <div className="absolute left-0 top-1/2 h-4 w-0.5 -translate-y-1/2 rounded-full bg-primary" />
                )}
                <item.icon
                  className={cn(
                    "h-4 w-4 shrink-0",
                    isActive
                      ? "text-primary"
                      : "text-sidebar-muted group-hover:text-sidebar-foreground",
                  )}
                />
                {item.name}
              </Link>
            )
          })}
        </nav>

        <div className="relative border-t border-sidebar-border p-3">
          <button
            onClick={onToggleTheme}
            className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-sidebar-muted transition-colors hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
          >
            {isDarkMode ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
            <span>{isDarkMode ? "Light Mode" : "Dark Mode"}</span>
          </button>
        </div>
      </aside>
    </>
  )
}
