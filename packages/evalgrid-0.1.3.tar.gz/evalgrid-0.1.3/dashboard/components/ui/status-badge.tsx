import { cn } from "@/lib/utils"

type StatusType = "success" | "error" | "warning" | "info" | "neutral"

interface StatusBadgeProps {
  status: StatusType
  label: string
  className?: string
  showDot?: boolean
}

const statusStyles: Record<StatusType, string> = {
  success: "bg-success/10 text-success border-success/20",
  error: "bg-error/10 text-error border-error/20",
  warning: "bg-warning/10 text-warning border-warning/20",
  info: "bg-primary/10 text-primary border-primary/20",
  neutral: "bg-muted text-muted-foreground border-border",
}

const dotStyles: Record<StatusType, string> = {
  success: "bg-success",
  error: "bg-error",
  warning: "bg-warning",
  info: "bg-primary",
  neutral: "bg-muted-foreground",
}

export function StatusBadge({
  status,
  label,
  className,
  showDot = true,
}: StatusBadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 text-xs font-medium",
        statusStyles[status],
        className
      )}
    >
      {showDot && (
        <span className={cn("h-1.5 w-1.5 rounded-full", dotStyles[status])} />
      )}
      {label}
    </span>
  )
}
