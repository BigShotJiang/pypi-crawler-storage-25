"use client"

// Tiny shared form-field helpers. Both dialogs (new-scenario, new-suite)
// duplicated Field + inputClass — extracted here so the two stay aligned.

import * as React from "react"

export function Field({
  label,
  hint,
  error,
  htmlFor,
  children,
}: {
  label: string
  hint?: string
  error?: string
  htmlFor?: string
  children: React.ReactNode
}) {
  const hintId = htmlFor && (hint || error) ? `${htmlFor}-hint` : undefined
  // Pass `id` + `aria-describedby` through to the child input/textarea/select
  // so screen readers announce the hint with the field (a11y P3 from audit).
  const child = React.isValidElement(children) && hintId
    ? React.cloneElement(children as React.ReactElement<any>, {
        "aria-describedby": hintId,
      })
    : children
  return (
    <label className="flex flex-col gap-1" htmlFor={htmlFor}>
      <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      {child}
      {(hint || error) && (
        <span
          id={hintId}
          className={`text-xs ${
            error ? "text-error" : "text-muted-foreground"
          }`}
        >
          {error || hint}
        </span>
      )}
    </label>
  )
}

export function inputClass(hasError: boolean): string {
  return `w-full rounded-md border bg-background px-3 py-2 text-sm text-foreground focus:outline-none ${
    hasError
      ? "border-error focus:border-error"
      : "border-border focus:border-primary"
  }`
}
