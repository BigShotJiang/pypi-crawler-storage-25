"use client"

// Create-only dialog for scenarios. Edit + delete ship in v0.1.4 — this is
// the minimum surface that lets a user go from `evalgrid init` to a custom
// eval without leaving the dashboard.
//
// Implementation note: this uses plain controlled state instead of
// react-hook-form, matching the New Run drawer. The forms here are small
// enough that RHF's validation engine is overkill; field-level errors come
// straight from the 422 response body.

import { useState } from "react"
import { toast } from "sonner"
import { Loader2, Plus, Trash2 } from "lucide-react"

import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { api, type NewScenarioBody, type ScenarioCheckInput } from "@/lib/api"
import { Field, inputClass } from "@/components/ui/form-field"
import { isValidSlug, SLUG_ERROR, SLUG_HINT } from "@/lib/validators"

interface NewScenarioDialogProps {
  trigger: React.ReactNode
  onCreated?: (id: string) => void
}

type CheckRow = {
  type: "valid_json" | "required_fields" | "regex_match"
  fields: string
  pattern: string
  hard_fail: boolean
}

export function NewScenarioDialog({ trigger, onCreated }: NewScenarioDialogProps) {
  const [open, setOpen] = useState(false)
  const [id, setId] = useState("")
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [agentType, setAgentType] = useState("generic")
  const [prompt, setPrompt] = useState("")
  const [testInput, setTestInput] = useState("")
  const [tagsText, setTagsText] = useState("")
  const [checks, setChecks] = useState<CheckRow[]>([])
  const [submitting, setSubmitting] = useState(false)
  const [serverError, setServerError] = useState<string | null>(null)

  const reset = () => {
    setId("")
    setName("")
    setDescription("")
    setAgentType("generic")
    setPrompt("")
    setTestInput("")
    setTagsText("")
    setChecks([])
    setServerError(null)
  }

  const idValid = isValidSlug(id)
  const idError = id && !idValid ? SLUG_ERROR : ""
  const nameValid = name.trim().length > 0
  const promptValid = prompt.trim().length >= 10
  const promptError = prompt && !promptValid ? "must be at least 10 characters" : ""
  const canSubmit = idValid && nameValid && promptValid && !submitting

  const addCheck = () =>
    setChecks((rows) => [
      ...rows,
      { type: "valid_json", fields: "", pattern: "", hard_fail: true },
    ])

  const updateCheck = (idx: number, patch: Partial<CheckRow>) =>
    setChecks((rows) => rows.map((r, i) => (i === idx ? { ...r, ...patch } : r)))

  const removeCheck = (idx: number) =>
    setChecks((rows) => rows.filter((_, i) => i !== idx))

  const buildPayload = (): NewScenarioBody => {
    const body: NewScenarioBody = {
      id: id.trim(),
      name: name.trim(),
      description: description.trim(),
      agent_type: agentType,
      prompt,
      test_input: testInput,
      tags: tagsText
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean),
    }
    const built: ScenarioCheckInput[] = checks.map((c) => {
      const out: ScenarioCheckInput = { type: c.type, hard_fail: c.hard_fail }
      if (c.type === "required_fields" && c.fields) {
        out.fields = c.fields.split(",").map((s) => s.trim()).filter(Boolean)
      }
      if (c.type === "regex_match" && c.pattern) {
        out.pattern = c.pattern
      }
      return out
    })
    if (built.length > 0) body.checks = built
    return body
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!canSubmit) return
    setSubmitting(true)
    setServerError(null)
    try {
      const created = await api.createScenario(buildPayload())
      toast.success("Scenario created", {
        description: `${created.name} — ${created.step_count} step(s), ${created.check_count} check(s)`,
      })
      reset()
      setOpen(false)
      onCreated?.(created.id)
    } catch (err: any) {
      const msg = err?.message ?? String(err)
      setServerError(msg)
      toast.error("Could not create scenario", { description: msg })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        setOpen(o)
        if (!o) setServerError(null)
      }}
    >
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent
        className="max-h-[90vh] overflow-y-auto sm:max-w-2xl"
        data-testid="new-scenario-dialog"
      >
        <DialogHeader>
          <DialogTitle>New Scenario</DialogTitle>
          <DialogDescription>
            Define a new evaluation. Saved as YAML in your scenarios directory.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4 px-1">
          <Field label="ID" hint={idError || SLUG_HINT} error={idError} htmlFor="newscen-id">
            <input
              type="text"
              value={id}
              onChange={(e) => setId(e.target.value)}
              placeholder="my-eval"
              className={inputClass(!!idError)}
              data-testid="newscen-id"
              autoFocus
            />
          </Field>

          <Field label="Name">
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="My Evaluation"
              className={inputClass(false)}
              data-testid="newscen-name"
            />
          </Field>

          <Field label="Description (optional)">
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              className={inputClass(false)}
              data-testid="newscen-description"
            />
          </Field>

          <Field label="Agent type">
            <select
              value={agentType}
              onChange={(e) => setAgentType(e.target.value)}
              className={inputClass(false)}
              data-testid="newscen-agent-type"
            >
              <option value="generic">generic</option>
              <option value="coding">coding</option>
              <option value="rag">rag</option>
              <option value="tool_use">tool_use</option>
            </select>
          </Field>

          <Field label="Prompt" hint={promptError || "minimum 10 characters"} error={promptError}>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={5}
              className={`${inputClass(!!promptError)} font-mono text-xs`}
              data-testid="newscen-prompt"
            />
          </Field>

          <Field label="Test input (optional)">
            <textarea
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              rows={3}
              className={`${inputClass(false)} font-mono text-xs`}
              data-testid="newscen-test-input"
            />
          </Field>

          <Field label="Tags" hint="comma-separated">
            <input
              type="text"
              value={tagsText}
              onChange={(e) => setTagsText(e.target.value)}
              placeholder="smoke, demo"
              className={inputClass(false)}
              data-testid="newscen-tags"
            />
          </Field>

          <div className="flex flex-col gap-2 rounded-md border border-border bg-card/30 p-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Checks ({checks.length})
              </span>
              <button
                type="button"
                onClick={addCheck}
                className="flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs text-foreground hover:bg-muted"
                data-testid="newscen-add-check"
              >
                <Plus className="h-3 w-3" /> Add check
              </button>
            </div>
            {checks.map((c, i) => (
              <div
                key={i}
                className="flex flex-wrap items-center gap-2 rounded-md border border-border bg-background p-2 text-sm"
                data-testid={`newscen-check-${i}`}
              >
                <select
                  value={c.type}
                  onChange={(e) =>
                    updateCheck(i, { type: e.target.value as CheckRow["type"] })
                  }
                  className="rounded-md border border-border bg-background px-2 py-1 text-xs"
                >
                  <option value="valid_json">valid_json</option>
                  <option value="required_fields">required_fields</option>
                  <option value="regex_match">regex_match</option>
                </select>
                {c.type === "required_fields" && (
                  <input
                    type="text"
                    value={c.fields}
                    onChange={(e) => updateCheck(i, { fields: e.target.value })}
                    placeholder="field1, field2"
                    className="min-w-0 flex-1 rounded-md border border-border bg-background px-2 py-1 text-xs"
                  />
                )}
                {c.type === "regex_match" && (
                  <input
                    type="text"
                    value={c.pattern}
                    onChange={(e) => updateCheck(i, { pattern: e.target.value })}
                    placeholder="^[A-Z].*"
                    className="min-w-0 flex-1 rounded-md border border-border bg-background px-2 py-1 font-mono text-xs"
                  />
                )}
                <label className="flex items-center gap-1 text-xs text-muted-foreground">
                  <input
                    type="checkbox"
                    checked={c.hard_fail}
                    onChange={(e) =>
                      updateCheck(i, { hard_fail: e.target.checked })
                    }
                  />
                  hard fail
                </label>
                <button
                  type="button"
                  onClick={() => removeCheck(i)}
                  className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-error"
                  aria-label="Remove check"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>

          {serverError && (
            <p className="rounded-md border border-error/30 bg-error/10 p-2 text-xs text-error" data-testid="newscen-server-error">
              {serverError}
            </p>
          )}

          <DialogFooter className="flex-row justify-end gap-2">
            <DialogClose asChild>
              <button
                type="button"
                className="rounded-md border border-border px-3 py-2 text-sm font-medium text-foreground hover:bg-muted"
              >
                Cancel
              </button>
            </DialogClose>
            <button
              type="submit"
              disabled={!canSubmit}
              className="flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
              data-testid="newscen-submit"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              Create scenario
            </button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

// Field + inputClass moved to @/components/ui/form-field (shared with the
// New Benchmark dialog). Validators moved to @/lib/validators.
