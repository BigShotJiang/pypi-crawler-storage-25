import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./tests/e2e-audit",
  outputDir: "./tests/e2e-audit/test-results",
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [
    ["list"],
    ["html", { outputFolder: "./tests/e2e-audit/playwright-report", open: "never" }],
    ["json", { outputFile: "./tests/e2e-audit/test-results/results.json" }],
  ],
  use: {
    baseURL: "http://localhost:3000",
    screenshot: "on",
    video: "retain-on-failure",
    trace: "retain-on-failure",
    actionTimeout: 10_000,
    navigationTimeout: 30_000,
    ignoreHTTPSErrors: true,
  },
  projects: [
    {
      name: "chromium-1920",
      use: {
        ...devices["Desktop Chrome"],
        viewport: { width: 1920, height: 1080 },
      },
    },
  ],
  timeout: 60_000,
  expect: { timeout: 10_000 },
});
