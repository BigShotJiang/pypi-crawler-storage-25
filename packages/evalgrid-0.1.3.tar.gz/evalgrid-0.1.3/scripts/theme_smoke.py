"""Browser-validate that the dark/light theme persists across route
navigation, hard refresh, deep-link, and browser back/forward.

Run while a fresh wheel-installed `evalgrid server --port 8000` is up.
Exits non-zero on any persistence failure or console error spike.
"""

from __future__ import annotations

import os
import sys

from playwright.sync_api import sync_playwright

BASE = os.environ.get("EVALGRID_BASE_URL", "http://127.0.0.1:8000")
ROUTES = ["/", "/runs/", "/scenarios/", "/benchmarks/", "/flakiness/", "/settings/"]


def html_class(page) -> str:
    return page.evaluate("document.documentElement.className")


def storage_theme(page) -> str:
    return page.evaluate("localStorage.getItem('evalgrid-theme')")


def assert_theme(page, expected: str, where: str) -> None:
    cls = html_class(page)
    has_dark = "dark" in cls.split()
    actual = "dark" if has_dark else "light"
    if actual != expected:
        raise AssertionError(
            f"theme regression at {where}: expected {expected}, got {actual} "
            f"(html.className={cls!r}, localStorage={storage_theme(page)!r})"
        )


def main() -> int:
    findings: dict[str, object] = {}
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page(viewport={"width": 1440, "height": 900})

        console_errors: list[str] = []
        page.on("pageerror", lambda exc: console_errors.append(f"pageerror: {exc}"))
        page.on(
            "console",
            lambda msg: console_errors.append(f"console.error: {msg.text}")
            if msg.type == "error"
            else None,
        )

        # ── Step 1: default load is dark (defaultTheme="dark", no storage) ──
        page.evaluate("localStorage.clear()") if False else None  # no-op safety
        page.goto(f"{BASE}/", wait_until="domcontentloaded")
        page.evaluate("localStorage.removeItem('evalgrid-theme')")
        page.reload(wait_until="domcontentloaded")
        page.wait_for_timeout(200)
        assert_theme(page, "dark", "first visit (no storage)")
        findings["first_visit_theme"] = html_class(page)

        # ── Step 2: switch to light via toggle and verify it persists ──
        page.evaluate(
            "() => { localStorage.setItem('evalgrid-theme', 'light'); "
            "document.documentElement.classList.remove('dark'); }"
        )
        page.reload(wait_until="domcontentloaded")
        page.wait_for_timeout(200)
        assert_theme(page, "light", "after setting localStorage=light + reload")
        findings["after_set_light"] = storage_theme(page)

        # ── Step 3: navigate all routes — must stay light ──
        nav_themes: dict[str, str] = {}
        for r in ROUTES:
            page.goto(f"{BASE}{r}", wait_until="domcontentloaded")
            page.wait_for_timeout(150)
            assert_theme(page, "light", f"after nav to {r}")
            nav_themes[r] = html_class(page)
        findings["nav_themes"] = nav_themes

        # ── Step 4: deep-link directly (new context, simulate fresh tab) ──
        # localStorage is per-origin so a new context starts empty by default;
        # but to test deep-link persistence in the SAME origin we re-use page
        # and just hard-refresh on a non-root route.
        page.goto(f"{BASE}/scenarios/", wait_until="domcontentloaded")
        page.wait_for_timeout(150)
        assert_theme(page, "light", "after deep-link to /scenarios/")

        # ── Step 5: browser back/forward ──
        page.go_back(wait_until="domcontentloaded")
        page.wait_for_timeout(150)
        assert_theme(page, "light", "after browser-back")
        page.go_forward(wait_until="domcontentloaded")
        page.wait_for_timeout(150)
        assert_theme(page, "light", "after browser-forward")

        # ── Step 6: flip back to dark and verify it sticks too ──
        page.evaluate("localStorage.setItem('evalgrid-theme', 'dark')")
        page.reload(wait_until="domcontentloaded")
        page.wait_for_timeout(150)
        assert_theme(page, "dark", "after flipping back to dark")
        page.goto(f"{BASE}/runs/", wait_until="domcontentloaded")
        page.wait_for_timeout(150)
        assert_theme(page, "dark", "after dark + nav to /runs/")

        # ── Step 7: mobile viewport sanity ──
        page.set_viewport_size({"width": 375, "height": 667})
        page.goto(f"{BASE}/", wait_until="domcontentloaded")
        page.wait_for_timeout(150)
        assert_theme(page, "dark", "mobile viewport, dark sticky")

        findings["console_errors_count"] = len(console_errors)
        # Allow the 1 intentional /api/nonexistent probe family (smoke script
        # doesn't run here, so 0 expected unless the dashboard itself logs).
        if len(console_errors) > 3:
            print(f"WARNING: {len(console_errors)} console errors (expected ≤3)")
            for e in console_errors[:10]:
                print(" -", e[:160])

        browser.close()

    print("\nFINDINGS:")
    for k, v in findings.items():
        print(f"  {k}: {v}")
    print("\nALL THEME ASSERTIONS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
