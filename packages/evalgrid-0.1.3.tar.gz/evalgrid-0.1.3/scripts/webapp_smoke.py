"""Playwright smoke test for the wheel-bundled evalgrid dashboard.

Walks every nav route, exercises the three create flows (scenario / suite /
run), and asserts the SPA shell routing fix from the v0.1.3 patch is live.

Run via the webapp-testing skill helper:
    py -3 -m pip install playwright && py -3 -m playwright install chromium
    py -3 .claude/skills/webapp-testing/scripts/with_server.py \\
        --server "evalgrid server --port 8000" --port 8000 \\
        -- py -3 scripts/webapp_smoke.py
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

from playwright.sync_api import Page, expect, sync_playwright

import os

# Allow CI / local re-runs to override the port without editing the script.
BASE = os.environ.get("EVALGRID_BASE_URL", "http://localhost:8000")
RESULTS = Path("smoke-results")


def shoot(page: Page, name: str) -> None:
    RESULTS.mkdir(exist_ok=True)
    page.screenshot(path=str(RESULTS / f"{name}.png"), full_page=True)


def main() -> int:
    findings: dict[str, object] = {}
    failures: list[str] = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        page = ctx.new_page()

        # Capture page errors AND console.error() calls. `pageerror` only
        # catches uncaught exceptions; many real frontend bugs surface as
        # console.error (e.g. React hydration mismatches, failed fetches).
        console_errors: list[str] = []
        page.on("pageerror", lambda exc: console_errors.append(f"pageerror: {exc}"))

        def _on_console(msg) -> None:
            try:
                if msg.type == "error":
                    console_errors.append(f"console.error: {msg.text}")
            except Exception:
                # Defensive — don't let a console handler hang the test
                pass

        page.on("console", _on_console)

        # ── Nav route walk ──────────────────────────────────────────────────
        # wait_until="domcontentloaded" → Playwright resolves as soon as the navigation
        # response is received, before HTML parse. Faster + more reliable
        # than domcontentloaded for the static export (which loads many async
        # script tags that can race). The screenshot still captures the
        # rendered state because of the 400ms settle delay below.
        routes = ["/", "/runs/", "/scenarios/", "/benchmarks/", "/flakiness/", "/settings/"]
        route_status: dict[str, int] = {}
        for r in routes:
            resp = page.goto(BASE + r, wait_until="domcontentloaded", timeout=45_000)
            route_status[r] = resp.status if resp else 0
            page.wait_for_timeout(400)
            shoot(page, f"route-{r.strip('/').replace('/', '-') or 'root'}")
            if resp is None or resp.status != 200:
                failures.append(f"route {r} returned {resp.status if resp else 'no-response'}")
        findings["route_status"] = route_status

        # ── FIX 1 regression: /runs/<id> hard refresh → runs/_index shell ───
        page.goto(f"{BASE}/runs/fake-id-from-smoke", wait_until="domcontentloaded")
        html = page.content()
        spa_marker_present = "run-detail-loading" in html
        findings["spa_shell_marker_present"] = spa_marker_present
        if not spa_marker_present:
            failures.append("/runs/<id> served wrong shell — run-detail-loading marker missing")

        # ── Open the New Run drawer + verify model selectors (FIX 2) ────────
        page.goto(f"{BASE}/runs/", wait_until="domcontentloaded")
        page.wait_for_timeout(500)
        page.get_by_test_id("runs-new").click()
        drawer = page.get_by_test_id("new-run-drawer")
        expect(drawer).to_be_visible(timeout=8_000)
        expect(page.get_by_test_id("newrun-agent-model")).to_be_visible()
        expect(page.get_by_test_id("newrun-judge-model")).to_be_visible()
        shoot(page, "new-run-drawer")
        findings["new_run_drawer_model_selectors"] = True
        # Regression guard: Escape must close the drawer (Radix default).
        # Reported broken during QA but didn't reproduce — lock in the
        # current correct behavior so any future onKeyDown blocker is caught.
        page.keyboard.press("Escape")
        expect(drawer).to_be_hidden(timeout=3_000)
        findings["drawer_escape_closes"] = True

        # ── Settings page: key inputs visible (FIX 3) ───────────────────────
        page.goto(f"{BASE}/settings/", wait_until="domcontentloaded")
        page.wait_for_timeout(500)
        anth = page.get_by_test_id("setting-ANTHROPIC_API_KEY-input")
        oai = page.get_by_test_id("setting-OPENAI_API_KEY-input")
        expect(anth).to_be_visible()
        expect(oai).to_be_visible()
        shoot(page, "settings-with-key-inputs")
        findings["settings_key_inputs_visible"] = True

        # ── Full UI create flow (FIX A + B) ─────────────────────────────────
        stamp = str(int(time.time()))[-6:]
        scenario_id = f"e2e-demo-{stamp}"
        suite_id = f"e2e-demo-suite-{stamp}"

        page.goto(f"{BASE}/scenarios/", wait_until="domcontentloaded")
        page.wait_for_timeout(500)
        page.get_by_test_id("scenarios-new").click()
        expect(page.get_by_test_id("new-scenario-dialog")).to_be_visible(timeout=8_000)
        page.get_by_test_id("newscen-id").fill(scenario_id)
        page.get_by_test_id("newscen-name").fill(f"Smoke {stamp}")
        page.get_by_test_id("newscen-prompt").fill("Respond with PONG in JSON.")
        page.get_by_test_id("newscen-tags").fill("smoke")
        shoot(page, "new-scenario-dialog-filled")
        page.get_by_test_id("newscen-submit").click()
        expect(page.get_by_test_id("new-scenario-dialog")).to_be_hidden(timeout=8_000)
        expect(page.get_by_test_id(f"scenario-item-{scenario_id}")).to_be_visible(timeout=5_000)
        shoot(page, "scenarios-after-create")
        findings["scenario_created_id"] = scenario_id

        page.goto(f"{BASE}/benchmarks/", wait_until="domcontentloaded")
        page.wait_for_timeout(500)
        page.get_by_test_id("benchmarks-new").click()
        expect(page.get_by_test_id("new-suite-dialog")).to_be_visible(timeout=8_000)
        page.get_by_test_id("newsuite-id").fill(suite_id)
        page.get_by_test_id("newsuite-name").fill(f"Smoke Suite {stamp}")
        page.get_by_test_id("newsuite-scenario-filter").fill(scenario_id)
        expect(page.get_by_test_id(f"newsuite-scenario-{scenario_id}")).to_be_visible(timeout=5_000)
        page.get_by_test_id(f"newsuite-scenario-{scenario_id}").click()
        shoot(page, "new-suite-dialog-filled")
        page.get_by_test_id("newsuite-submit").click()
        expect(page.get_by_test_id("new-suite-dialog")).to_be_hidden(timeout=8_000)
        shoot(page, "benchmarks-after-create")
        findings["suite_created_id"] = suite_id

        # ── Launch the new suite in mock mode → confirm completion ──────────
        page.goto(f"{BASE}/runs/", wait_until="domcontentloaded")
        page.wait_for_timeout(500)
        page.get_by_test_id("runs-new").click()
        expect(page.get_by_test_id("new-run-drawer")).to_be_visible(timeout=8_000)
        page.get_by_test_id("newrun-suite-select").select_option(suite_id)
        page.get_by_test_id("newrun-mock-checkbox").check()
        # Capture the response so we can pull run_id straight out — more
        # reliable than scraping window.location which races the SPA router.
        with page.expect_response(
            lambda r: r.url.endswith("/api/runs") and r.request.method == "POST",
            timeout=10_000,
        ) as resp_info:
            page.get_by_test_id("newrun-submit").click()
        create_resp = resp_info.value
        findings["create_run_status"] = create_resp.status
        if create_resp.status != 200:
            failures.append(f"POST /api/runs returned {create_resp.status}: {create_resp.text()[:200]}")
            new_run_id = ""
        else:
            new_run_id = create_resp.json()["run_id"]
        findings["new_run_id"] = new_run_id

        import urllib.request
        final_status = None
        for _ in range(15):
            try:
                with urllib.request.urlopen(f"{BASE}/api/runs/{new_run_id}", timeout=3) as r:
                    data = json.loads(r.read())
                final_status = data.get("status")
                if final_status == "completed":
                    findings["run_pass_rate"] = data.get("pass_rate")
                    findings["run_total"] = data.get("total")
                    break
            except Exception:
                pass
            time.sleep(0.5)
        findings["final_status"] = final_status
        if final_status != "completed":
            failures.append(f"mock run did not complete: final_status={final_status}")

        # ── Run-detail deep-link regression (the "Run not found" bug) ───────
        # Previously: hitting /runs/<id> from a hard refresh hydrated with
        # params.id === "_index" (the static-export sentinel) and the page
        # then fetched /api/runs/_index → "Run not found". The fix is in
        # run-detail-client.tsx (usePathname-derived id). Verify here so any
        # future regression in dynamic-route id resolution is caught.
        page.goto(f"{BASE}/runs/{new_run_id}/", wait_until="domcontentloaded")
        title_locator = page.get_by_test_id("run-detail-title")
        expected_prefix = f"Run {new_run_id[:8]}"
        try:
            expect(title_locator).to_be_visible(timeout=8_000)
            expect(title_locator).to_contain_text(expected_prefix, timeout=2_000)
            findings["run_detail_title"] = title_locator.inner_text()
        except Exception as exc:
            err_locator = page.get_by_test_id("run-detail-error")
            err_visible = err_locator.count() > 0 and err_locator.first.is_visible()
            findings["run_detail_error_visible"] = err_visible
            failures.append(
                "run-detail page did not render run data within 8s — likely "
                "params.id stuck at '_index'. "
                f"error banner visible: {err_visible}; exception: {exc}"
            )
        shoot(page, "run-detail-after-mock")

        # ── API contract checks ─────────────────────────────────────────────
        api_404 = ctx.request.get(f"{BASE}/api/nonexistent")
        findings["api_404_status"] = api_404.status
        findings["api_404_json"] = api_404.headers.get("content-type", "").startswith("application/json")
        if api_404.status != 404:
            failures.append(f"/api/nonexistent expected 404 got {api_404.status}")

        empty_post = ctx.request.post(f"{BASE}/api/runs", data="{}", headers={"content-type": "application/json"})
        findings["empty_post_status"] = empty_post.status
        if empty_post.status != 422:
            failures.append(f"POST /api/runs {{}} expected 422 got {empty_post.status}")

        findings["console_errors"] = console_errors

        browser.close()

    RESULTS.mkdir(exist_ok=True)
    (RESULTS / "findings.json").write_text(json.dumps(findings, indent=2))

    print("\n=== webapp smoke findings ===")
    print(json.dumps(findings, indent=2))
    if failures:
        print(f"\nFAILURES ({len(failures)}):")
        for f in failures:
            print(f"  • {f}")
        return 1
    print("\nALL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
