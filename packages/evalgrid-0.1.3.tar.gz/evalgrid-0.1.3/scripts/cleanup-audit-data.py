#!/usr/bin/env python3
"""Wipe audit-test + mock-mode pollution from the local DB and scenarios dir.

This script removes:
  * Scenario YAML files whose filename matches the audit prefixes
    (audit-xss-*, crud-*, conflict-test-*, etc.).
  * DB rows in `scenario_results` referencing those scenario ids.
  * Runs that are empty (status='empty' / total=0) OR that only contain
    results pointing at deleted scenarios.
  * "All-mock" runs whose every scenario_result has cost_usd == 0 AND whose
    scenario_ids are all in the bundled example list — these are dev-mode
    leftovers from `evalgrid run --mock`. Also drops their suite_results.
  * Recomputes nothing — flakiness is derived live from `scenario_results`
    so it falls into place once orphaned rows are gone.

Reports counts at the end. Idempotent.

Usage:
    py -3 scripts/cleanup-audit-data.py            # dry run (default)
    py -3 scripts/cleanup-audit-data.py --execute  # commit deletions
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import delete, func, select  # noqa: E402
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine  # noqa: E402

from evalgrid.api.database import (  # noqa: E402
    Base,
    RunRecord,
    ScenarioResultRecord,
    SuiteResultRecord,
)
from evalgrid.core.paths import default_database_url, resolve_scenarios_dir  # noqa: E402

# Audit/test-generated scenario prefixes. None of these correspond to user evals.
SCENARIO_PREFIXES = (
    "audit-xss-",
    "crud-create-",
    "crud-dup-",
    "crud-list-",
    "crud-sandbox-",
    "conflict-test",
    "real-llm-",
    "run-conc-",
    "run-detail-",
    "run-list-",
    "run-mock-",
    "ui-seed-",
    "ui-dup-",
    "ui-run-",
    "ui-scenario-",
    "e2e-demo",
    "e2e-seed-",
    "broken-test-",
)

EXACT_AUDIT_IDS = frozenset({"cli-test", "smoke-test", "test-scenario"})

# Scenarios shipped in the v0.1.3 example pack. A run that consists ONLY of
# these scenario_ids and has zero total cost is a mock-mode dev-test leftover.
EXAMPLE_SCENARIO_IDS = frozenset({"example-hello-world"})


def _is_audit_scenario_id(scenario_id: str) -> bool:
    if scenario_id in EXACT_AUDIT_IDS:
        return True
    return any(scenario_id.startswith(p) for p in SCENARIO_PREFIXES)


def _scenario_files_to_delete(scen_dir: Path) -> list[Path]:
    if not scen_dir.exists():
        return []
    out: list[Path] = []
    for ext in ("*.yml", "*.yaml"):
        for path in scen_dir.rglob(ext):
            if _is_audit_scenario_id(path.stem):
                out.append(path)
    return out


async def _identify_all_mock_example_runs(db) -> list[str]:
    """Find run ids whose entire scenario_results set is (a) cost_usd==0 across
    every row AND (b) only contains scenario_ids in EXAMPLE_SCENARIO_IDS.
    """
    rows = await db.execute(
        select(
            ScenarioResultRecord.run_id,
            func.max(ScenarioResultRecord.cost_usd).label("max_cost"),
            func.count(ScenarioResultRecord.id).label("n_rows"),
        ).group_by(ScenarioResultRecord.run_id)
    )
    candidates: list[str] = []
    for run_id, max_cost, n_rows in rows.all():
        if max_cost is None or max_cost > 0 or n_rows == 0:
            continue
        id_rows = await db.execute(
            select(ScenarioResultRecord.scenario_id)
            .where(ScenarioResultRecord.run_id == run_id)
            .distinct()
        )
        sids = {r[0] for r in id_rows.all()}
        if sids and sids.issubset(EXAMPLE_SCENARIO_IDS):
            candidates.append(run_id)
    return candidates


async def main(execute: bool) -> None:
    db_url = default_database_url()
    scen_dir = resolve_scenarios_dir()

    mode = "EXECUTE" if execute else "DRY-RUN (use --execute to commit)"
    print(f"Mode:      {mode}")
    print(f"DB:        {db_url}")
    print(f"Scenarios: {scen_dir}\n")

    # ── filesystem cleanup ────────────────────────────────────────────────────
    files = _scenario_files_to_delete(scen_dir)
    if execute:
        for f in files:
            try:
                f.unlink()
            except OSError as exc:
                print(f"  skip {f}: {exc}")
    for f in files[:20]:
        print(f"  scenario file: {f.name}")
    if len(files) > 20:
        print(f"  ... and {len(files) - 20} more")
    print(f"Scenario files {'deleted' if execute else 'would delete'}: {len(files)}\n")

    # ── DB cleanup ────────────────────────────────────────────────────────────
    engine = create_async_engine(db_url, echo=False)
    Session = async_sessionmaker(engine, expire_on_commit=False)

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with Session() as db:
        sid_rows = await db.execute(
            select(ScenarioResultRecord.scenario_id).distinct()
        )
        all_ids = [r[0] for r in sid_rows.all()]
        audit_ids = [sid for sid in all_ids if _is_audit_scenario_id(sid)]

        scenarios_total_before = len(all_ids)
        scenarios_deleted = 0
        if audit_ids:
            if execute:
                res = await db.execute(
                    delete(ScenarioResultRecord).where(
                        ScenarioResultRecord.scenario_id.in_(audit_ids)
                    )
                )
                scenarios_deleted = res.rowcount or 0
            else:
                count_q = await db.execute(
                    select(func.count(ScenarioResultRecord.id)).where(
                        ScenarioResultRecord.scenario_id.in_(audit_ids)
                    )
                )
                scenarios_deleted = count_q.scalar_one()

        # 2. All-mock example dev runs — delete these after audit cleanup so
        # the audit-only runs are already gone when we evaluate "all-mock"
        if execute:
            mock_dev_runs = await _identify_all_mock_example_runs(db)
            if mock_dev_runs:
                await db.execute(
                    delete(ScenarioResultRecord).where(
                        ScenarioResultRecord.run_id.in_(mock_dev_runs)
                    )
                )
                await db.execute(
                    delete(SuiteResultRecord).where(
                        SuiteResultRecord.run_id.in_(mock_dev_runs)
                    )
                )
        else:
            mock_dev_runs = await _identify_all_mock_example_runs(db)
        mock_runs_deleted = len(mock_dev_runs)

        # 3. Empty / orphaned runs (must run after the above purges)
        run_rows = await db.execute(select(RunRecord))
        all_runs = run_rows.scalars().all()
        runs_to_delete: list[str] = []
        for r in all_runs:
            remaining = await db.execute(
                select(ScenarioResultRecord.id)
                .where(ScenarioResultRecord.run_id == r.run_id)
                .limit(1)
            )
            has_results = remaining.first() is not None
            is_empty_or_zero = (r.total or 0) == 0 or not has_results
            if is_empty_or_zero or r.run_id in mock_dev_runs:
                runs_to_delete.append(r.run_id)

        runs_deleted = 0
        if runs_to_delete and execute:
            await db.execute(
                delete(SuiteResultRecord).where(
                    SuiteResultRecord.run_id.in_(runs_to_delete)
                )
            )
            res = await db.execute(
                delete(RunRecord).where(RunRecord.run_id.in_(runs_to_delete))
            )
            runs_deleted = res.rowcount or 0
        elif runs_to_delete:
            runs_deleted = len(runs_to_delete)

        if execute:
            await db.commit()

        remaining_ids_rows = await db.execute(
            select(ScenarioResultRecord.scenario_id).distinct()
        )
        scenarios_remaining = len({r[0] for r in remaining_ids_rows.all()})

        remaining_runs_rows = await db.execute(select(RunRecord.run_id))
        runs_remaining = len(remaining_runs_rows.all())

    await engine.dispose()

    verb = "deleted" if execute else "would delete"
    print(f"Scenario_result rows {verb}:    {scenarios_deleted}")
    print(f"All-mock example runs {verb}:   {mock_runs_deleted}")
    print(f"Empty / orphan runs {verb}:     {runs_deleted}")
    print(f"Distinct scenarios in DB:        {scenarios_total_before} -> {scenarios_remaining}")
    print(f"Runs remaining in DB:            {runs_remaining}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Wipe audit + mock pollution.")
    parser.add_argument(
        "--execute",
        action="store_true",
        help="Actually delete rows (default is dry-run).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Explicitly request a dry run (default behavior, kept for clarity).",
    )
    args = parser.parse_args()
    asyncio.run(main(execute=args.execute))
