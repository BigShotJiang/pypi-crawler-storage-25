# Roadmap

EvalGrid is in early development. This file tracks where the project is going.
Pull requests, issues, and feedback welcome.

## v0.1 (current)
- Local-first agent evaluation framework
- YAML scenario format with per-step verdicts
- LLM-as-judge scorer via LiteLLM (any provider)
- React dashboard for run history and scenario management
- CLI: `evalgrid init`, `run`, `server`, `scenario add`
- Mock mode for testing without API keys
- SQLite-backed run history at `~/.evalgrid/results.db`

## v0.2 (in development) — CI/CD for AI agents
The goal of v0.2 is to make EvalGrid a deploy-blocking gate, not just a dashboard.

- **GitHub Status Check integration** — required-check compatible, blocks PR merges on regression
- **Statistical regression detection** — N-trial sampling with significance testing to keep false-positive rate low
- **Baseline locking** — `.evalgrid/baseline.json` tied to git SHA, immutable per commit
- **Tolerance configuration** — per-scenario noise tolerances in YAML
- **Trajectory diff** — when a check fails, show step-by-step divergence from baseline

## v0.3 and beyond
- Optional hosted dashboard for teams (free tier + paid for collaboration features)
- Slack/Discord regression alerts
- Golden-set drift detection
- Plugin system for custom scorers

## Design principles
1. **Local-first.** The CLI and self-hosted dashboard work fully offline (with your own API keys for LLM calls).
2. **BYOK.** API keys stay in your environment. EvalGrid never proxies LLM calls through a hosted service.
3. **Provider-agnostic.** Via LiteLLM — Claude, GPT, Gemini, Llama, local Ollama, anything LiteLLM supports.
4. **Deterministic-friendly.** v0.2 will ship N-trial sampling for regression stability.

## Status
v0.1 is alpha-quality but functional. The framework runs reliably for local development. Production CI integration ships in v0.2.

If you're building agents and want eval-driven workflows now, v0.1 works.
If you need to gate PRs on regression detection, watch for v0.2.
