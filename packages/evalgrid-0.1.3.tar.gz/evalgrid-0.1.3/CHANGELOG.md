# Changelog

All notable changes to evalgrid are documented in this file.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/). This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.3] - 2026-05-17

### Added
- New Next.js + shadcn/ui dashboard with dark mode by default.
- **"New Run" drawer** in the dashboard — launch evaluations by tag, suite, or in mock mode without dropping to the CLI. Drawer exposes Agent Model and Judge Model dropdowns so model overrides are first-class UI. Detail page polls until the run completes (now with exponential backoff).
- **`POST /api/scenarios`** (explicit id + slug-safe validation, race-safe `open(..., "x")` writes) and **"New Scenario" dialog** on `/scenarios`. Form covers id/name/description/agent_type/prompt/test_input/tags + a dynamic checks array. 422 surfaces field-level errors inline.
- **`POST /api/suites`** (validates every referenced scenario exists on disk; names missing ones in the 422 detail) and **"New Benchmark" dialog** on `/benchmarks`. Multi-select scenario picker with filter.
- **Settings page** now accepts API keys via password inputs, posting to **`POST /api/config/keys`** (in-memory only — never persisted, cleared on restart, capped at 512 chars per key, unknown fields rejected via Pydantic `extra="forbid"`).
- **Scenario detail page** displays the full prompt, test input, success criteria, expected actions, checks, and the scenario's last 5 run results. Inline editing deferred to v0.2.
- **SPA shell routing for dynamic routes** — hard refresh on `/runs/<id>` or `/scenarios/<id>` now serves the correct dynamic `_index/` shell instead of the Overview. `SPAStaticFiles` walks the URL tree to find the deepest matching shell; asset 404s (`.js`/`.css`/`.woff2`/`.txt`) stay real 404s.
- **`GET /api/scenarios/{id}`** returns the full scenario YAML structure + recent run history.
- **`GET /api/suites`** now (a) surfaces suites that exist on disk but haven't been run yet and (b) accepts `include_mock=false` (default) to hide suites whose every persisted run is mock-mode.
- **Concurrent-run cap** (default 2, tunable via `EVALGRID_MAX_CONCURRENT_RUNS`) bounds SQLite write contention and unintentional LLM-API fanout.
- **Security headers middleware**: CSP, X-Content-Type-Options, X-Frame-Options, Referrer-Policy. **Body-size middleware** caps POST/PUT/PATCH at 1 MB.
- **`/health` endpoint enriched** with version, DB ping result, and resolved scenarios/suites dirs (was bare `{"status": "ok"}`).
- **`evalgrid init`** scaffolds `.evalgrid/suites/` with a runnable `example.yml` suite — `evalgrid init && evalgrid run --suite example` works without setup.
- **`scripts/cleanup-audit-data.py`** for removing audit-test pollution from the local DB. Dry-run by default; `--execute` to commit. Also drops all-mock dev runs.
- **`scripts/webapp_smoke.py`** Python Playwright smoke harness + CI `e2e-smoke` job that runs it on every PR against the bundled wheel. Guards against any future repeat of the SPA-shell-strip regression. Run helper `scripts/with_server.py` vendored alongside so CI doesn't depend on a `.claude/` skill bundle.
- **`security-scan` CI job** runs `pip-audit` on every PR (soft-fail signal for now).

### Fixed
- **scenarios_dir resolution unified** across CLI and dashboard: `EVALGRID_SCENARIOS_DIR` → `<cwd>/.evalgrid/scenarios/` → `~/.evalgrid/scenarios/`. Mirrored for suites via `EVALGRID_SUITES_DIR`.
- **`/api/runs/compare` no longer 404s** — was shadowed by `/api/runs/{run_id}` because of FastAPI declaration order.
- **Run-level errors surface in API + UI.** `GET /api/runs/{id}` returns `error: str | null`; dashboard renders a destructive banner.
- **Anthropic 529 + APIConnectionError** retried via existing backoff (`litellm.exceptions.InternalServerError` added to `_RETRYABLE_EXC`).
- **`POST /api/runs`** rejects empty body (422 via `model_validator`) AND rejects filters that resolve to zero scenarios (422 BEFORE the DB row is created — was polluting the runs list with empty 0/0 entries).
- **`agent_model` and `judge_model`** are now independent API fields. Passing only `judge_model` emits a `DeprecationWarning` (fallback removed in v0.2).
- **N+1 query elimination** in `list_suites`: single GROUP BY JOIN to `scenario_results` + batched latest-passed lookup. Was 3×N queries per page load.
- **Duplicate filesystem walk eliminated**: `create_run` resolves scenarios once, passes the list into `_execute_run` instead of having the background task re-parse every YAML.
- **Run-detail polling** uses exponential backoff (1s/2s/4s/8s cap) — a 10-minute run drops from 300 → ~75 fetches.
- **Settings key save** is optimistic — POST response updates state directly, no refetch round-trip.
- **Slug validator** rejects Windows reserved names (CON/PRN/AUX/NUL/COM1-9/LPT1-9), path traversal, and uppercase.
- **Race-safe scenario + suite writes** via `open(..., "x")` — concurrent same-id POSTs 422 cleanly.
- **`KeyUpdate`** rejects unknown fields (`extra="forbid"`) — typo provider names 422 instead of silent no-op.
- **Mobile viewport (375px+) layout** across all dashboard routes. Sidebar hidden behind hamburger toggle below `lg`.
- **Stale-run reaper log** aggregated into one summary line per startup (was one per stale run).
- Dashboard `v0.app` generator-string meta and Vercel Analytics import removed.
- **TS build errors no longer ignored** (`next.config.mjs: ignoreBuildErrors: false`).
- **Dependency upper bounds** added (`litellm>=1.50,<2.0`, `fastapi>=0.115,<0.120`, `pydantic>=2.5,<3.0`, etc.) so minor-version breaks elsewhere can't break the released wheel.
- **`evalgrid.__version__`** now reads `0.1.3` (was stuck at `0.1.0` since v0.1.0).
- **Deterministic Next.js `BUILD_ID`** (`dashboard/next.config.mjs: generateBuildId`). Resolves in this priority: `EVALGRID_BUILD_ID` env (CI/release override) → project version from `../pyproject.toml` (e.g. `v0.1.3` — stable across commits in a release) → short git SHA (dev fallback) → literal `evalgrid-nogit`. Two wheels of the same release are now byte-equivalent. Previously Next.js generated a random ID per build.
- **Next 16 RSC payload 404 noise** — `SPAStaticFiles._resolve_rsc_payload` handles two distinct Next 16 export/RSC-client mismatches: (1) dotted dirnames (`/<route>/__next.<seg>.__PAGE__.txt` is on disk at `/<route>/__next.<seg>/__PAGE__.txt`; the last dot is a directory boundary, with right-to-left dot splitting for nested dynamic routes); (2) dynamic-route `_index` fallback (visiting `/runs/<actual-id>` triggers RSC fetches under `/runs/<id>/…` but those payloads only live under `/runs/_index/…`, the placeholder shell from `generateStaticParams() -> [{id:"_index"}]`). Pages always rendered; the rewrite eliminates the per-navigation 404 console.error storm (≈44 per nav → 0 expected for known paths). Path-traversal guarded.
- **Theme persistence regression** — picking Light Mode used to snap back to Dark on every route transition because `dashboard/app/layout.tsx` hardcoded `className="dark bg-background"` on `<html>` AND `dashboard/components/layout/main-layout.tsx` used local `useState(true)` + `useEffect(() => documentElement.classList.add("dark"))` with no persistence. Fixed by wiring the already-installed `next-themes` provider into the root layout (`attribute="class"`, `defaultTheme="dark"`, `storageKey="evalgrid-theme"`, `disableTransitionOnChange`), moving `bg-background` to `<body>`, adding `suppressHydrationWarning` to `<html>`, and replacing the homegrown local state in `MainLayout` with `useTheme()`. Theme now persists across refreshes, route transitions, deep links, browser back/forward, and mobile viewports.
- **Run-detail page "Run not found" on deep link** — the dynamic `/runs/[id]` route is pre-rendered as a single shell via `generateStaticParams() -> [{id:"_index"}]`. The shell hydrated with `params.id === "_index"` on hard refresh, so the page issued `GET /api/runs/_index` → 404 → "Run not found". Fixed by deriving the id from `usePathname()` in `run-detail-client.tsx` (with a fallback to `params.id` for in-SPA navigations), so the real URL segment always wins.
- **Project-local SQLite path** — `default_database_url()` previously always returned `~/.evalgrid/results.db` while scenarios + suites resolved via `<cwd>/.evalgrid/`. The mismatch caused `sqlite3.OperationalError: attempt to write a readonly database` when the home path was locked AND a project-state/dashboard-state split-brain. Fixed by mirroring the `resolve_scenarios_dir` precedence: `DATABASE_URL` env → `<cwd>/.evalgrid/results.db` if `<cwd>/.evalgrid/` exists → `~/.evalgrid/results.db`. Parent dirs are auto-created so a fresh `evalgrid init` project works end-to-end without extra mkdirs.
- **Dashboard dev backend URL is env-configurable** — `dashboard/next.config.mjs` hardcoded `http://localhost:8000` in the dev rewrites destination, so multiple worktrees / nonstandard ports silently proxied to a stale server. Now reads `process.env.EVALGRID_API_URL` (e.g. `EVALGRID_API_URL=http://127.0.0.1:8001 npm run dev`) with the same localhost:8000 fallback.

### Removed
- Datasets, PR Checks, and Reports nav entries (deferred to v0.2+; route files preserved). Mock user-profile icon (deferred to v1.0).

### Internal
- Comprehensive Playwright E2E audit suite under `dashboard/tests/e2e-audit/` plus new `20-v013-uxfixes.spec.ts` (FIX 1/2/3 regression coverage) and `21-create-flow.spec.ts` (scenario→suite→run end-to-end via UI dialogs). All `networkidle` waits swept to `domcontentloaded` to kill dev-mode HMR flakiness.
- **138 pytest tests** covering FIX 1-7, FIX A/B, body-size + security headers + slug Windows-reserved + key-extra-forbid hardening + eight Next 16 RSC rewrite cases (`.__PAGE__.txt` dotted dirname, plain `.txt` dot-split, dynamic `_index` fallback, composed `_index` + dot-split for nested dynamic, scope guards, path-traversal guards) + four `default_database_url` cases (cwd-preferred, env override, home fallback, parent auto-create). Up from 92 at v0.1.2. `scripts/webapp_smoke.py` extended with two new assertions: drawer Escape closes (regression guard) + run-detail page renders the actual run id after a deep link (regression guard for the `_index` hydration bug).
- Shared frontend helpers extracted (`dashboard/lib/format.ts`, `dashboard/lib/validators.ts`, `dashboard/components/ui/form-field.tsx`) to kill `relativeTime` / `durationLabel` / `Field` / `inputClass` / `SLUG_RE` duplication across dialogs + pages.
- `CONTRIBUTING.md` expanded with a Dashboard development section including an explicit warning never to gitignore anything under `evalgrid/static/` (the v0.1.3 RC1 failure mode).

## [0.1.2]

### Added
- Per-run cost tracking: `ScenarioResult` now carries `prompt_tokens`, `completion_tokens`, and `cost_usd` summed across the agent and judge LiteLLM calls. CLI run table gains a "Cost" column; total cost prints in the summary. Mock-mode runs report zero cost. Cost is `0.0` for models LiteLLM has no pricing data for (local Ollama or new model names) — token counts are still reported.

### Tests
- 29 new tests for the deterministic assertion layer (`core/assertions.py`), backfilling all 8 check types (valid_json, no_markdown, required_fields, enum, forbidden_regex, contains, max_length, json_schema), plus unknown-check-type, invalid-regex, and hard/soft-fail flag propagation.
- 9 new tests for cost tracking covering token extraction, pricing-lookup defensiveness, judge-cost propagation, agent+judge summing in the runner, and hard-fail short-circuit accounting.

### Internal
- Extracted dashboard `useConfigStatus` hook into `dashboard/src/hooks/useConfigStatus.ts`.

## [0.1.1]

### Fixed
- Agent calls now resolve provider API keys from environment based on model prefix. Previously, all agent calls used the judge's API key, breaking advertised multi-provider configurations (e.g., GPT-4o agent with Claude judge).
- `evalgrid run` and `--fail-fast` now correctly exit non-zero on PassFail.ERROR (auth failures, invalid judge JSON, rate limits). Previously, ERROR results were treated as successes.
- Stale test in tests/test_cli.py now asserts the correct exit code 2 for hard failures.
- CLI help text uses ASCII hyphens instead of em-dashes for Windows console compatibility.

### Added
- `evalgrid init --force` and `--yes` / `-y` flags for non-interactive CI usage.

## [0.1.0]

### Added
- First public release.
- YAML scenario format with per-step verdicts.
- LLM-as-judge scoring via LiteLLM (Anthropic, OpenAI, Google, local Ollama, any LiteLLM provider).
- React dashboard for run history at localhost:8000.
- CLI: init, run, server, scenario.
- Mock mode for testing without API keys.
- 8 deterministic check types: valid_json, no_markdown, required_fields, enum, forbidden_regex, contains, max_length, json_schema.
- Benchmark suites with 4-rate scoring.
- HTML and Markdown reports via --report flag.
- Scenario YAML validation via `evalgrid scenario validate`.
- Flakiness detection: CLI + API + dashboard view.
- Granular CI exit codes (0 = pass, 1 = soft failure, 2 = hard failure).
- MIT licensed. Published to PyPI via OIDC trusted publishing.
