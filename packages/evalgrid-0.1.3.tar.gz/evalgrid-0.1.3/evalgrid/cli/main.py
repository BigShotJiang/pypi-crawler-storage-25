"""evalgrid CLI entry point."""

import click

from .commands.flakiness import flakiness
from .commands.init import init
from .commands.run import run
from .commands.scenario import scenario
from .commands.server import server


@click.group()
@click.version_option(package_name="evalgrid")
def cli() -> None:
    """evalgrid - AI agent evaluation framework."""


cli.add_command(flakiness)
cli.add_command(init)
cli.add_command(run)
cli.add_command(scenario)
cli.add_command(server)
