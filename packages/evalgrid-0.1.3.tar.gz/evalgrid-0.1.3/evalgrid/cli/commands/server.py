"""evalgrid server — start the dashboard API server."""

from __future__ import annotations

import click
from rich.console import Console

console = Console(legacy_windows=False)
_err_console = Console(stderr=True, legacy_windows=False)

_LOCALHOST = {"127.0.0.1", "localhost", "::1"}


@click.command()
@click.option("--bind", default="127.0.0.1", show_default=True,
              help="Address to bind the server to")
@click.option("--port", default=8000, show_default=True)
@click.option("--reload", is_flag=True, help="Auto-reload on file changes")
def server(bind: str, port: int, reload: bool) -> None:
    """Start the evalgrid dashboard server."""
    try:
        import uvicorn
    except ImportError:
        console.print("[red]uvicorn not installed. Run: pip install evalgrid[/red]")
        raise SystemExit(1)

    if bind not in _LOCALHOST:
        _err_console.print(
            f"[bold yellow]WARNING: Binding to {bind} exposes the server to the network. "
            "evalgrid is designed for local use only.[/bold yellow]"
        )

    console.print(f"[bold green]Starting evalgrid dashboard at http://{bind}:{port}[/bold green]")
    uvicorn.run(
        "evalgrid.api.app:app",
        host=bind,
        port=port,
        reload=reload,
        log_level="info",
    )
