"""evalgrid scenario — manage eval scenarios."""

from __future__ import annotations

from pathlib import Path

import click
import yaml
from rich.console import Console
from rich.prompt import Confirm, Prompt
from rich.syntax import Syntax

console = Console(legacy_windows=False)

AGENT_TYPES = ["generic", "sdr", "coding", "support", "research", "custom"]


@click.group()
def scenario() -> None:
    """Manage eval scenarios."""


@scenario.command("add")
@click.option("--scenarios-dir", default=".evalgrid/scenarios", show_default=True)
@click.option("--output", default=None,
              help="Output file path (default: auto-named in scenarios-dir)")
def add(scenarios_dir: str, output: str | None) -> None:
    """Interactively create a new eval scenario."""
    console.print("\n[bold]Create a new eval scenario[/bold]\n")

    name = Prompt.ask("[cyan]Scenario name[/cyan]")
    description = Prompt.ask("[cyan]Description[/cyan]", default="")

    console.print(f"\n[cyan]Agent type[/cyan] ({', '.join(AGENT_TYPES)})")
    agent_type = Prompt.ask("", default="generic", choices=AGENT_TYPES, show_choices=False)

    console.print("\n[cyan]System prompt[/cyan] (the agent's instructions):")
    console.print("[dim]Enter multiple lines, finish with a blank line[/dim]")
    prompt_lines: list[str] = []
    while True:
        line = input()
        if line == "" and prompt_lines:
            break
        prompt_lines.append(line)
    prompt = "\n".join(prompt_lines)

    console.print("\n[cyan]Test input[/cyan] (the message sent to the agent):")
    test_input = Prompt.ask("")

    console.print("\n[cyan]Success criteria[/cyan] (how to judge overall pass/fail):")
    success_criteria = Prompt.ask("")

    expected_actions = []
    console.print("\n[cyan]Expected actions[/cyan] (leave name blank to finish):")
    i = 0
    while True:
        action = Prompt.ask(f"  Action {i + 1} name", default="")
        if not action:
            break
        desc = Prompt.ask(f"  Action {i + 1} description", default="")
        required = Confirm.ask("  Required?", default=True)
        expected_actions.append({"action": action, "description": desc, "required": required})
        i += 1

    tags_raw = Prompt.ask("\n[cyan]Tags[/cyan] (comma-separated)", default="")
    tags = [t.strip() for t in tags_raw.split(",") if t.strip()]

    scenario_id = name.lower().replace(" ", "-").replace("_", "-")
    scenario_id = "".join(c for c in scenario_id if c.isalnum() or c == "-")

    data = {
        "id": scenario_id,
        "name": name,
        "description": description,
        "agent_type": agent_type,
        "prompt": prompt,
        "test_input": test_input,
        "success_criteria": success_criteria,
        "expected_actions": expected_actions,
        "tags": tags,
        "timeout_seconds": 60,
    }

    yaml_text = yaml.dump(data, default_flow_style=False, sort_keys=False, allow_unicode=True)

    console.print("\n[bold]Preview:[/bold]")
    console.print(Syntax(yaml_text, "yaml", theme="monokai"))

    if not Confirm.ask("\nSave this scenario?", default=True):
        console.print("[yellow]Cancelled.[/yellow]")
        return

    if output:
        out_path = Path(output)
    else:
        out_path = Path(scenarios_dir) / f"{scenario_id}.yml"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(yaml_text)
    console.print(f"\n[green]OK Saved to {out_path}[/green]")
    console.print(f"\nRun it with: [cyan]evalgrid run --scenario-id {scenario_id}[/cyan]")


@scenario.command("list")
@click.option("--scenarios-dir", default=".evalgrid/scenarios", show_default=True)
def list_scenarios(scenarios_dir: str) -> None:
    """List all available scenarios."""
    from rich import box
    from rich.table import Table

    from evalgrid.core import ScenarioLoader

    scen_dir = Path(scenarios_dir)
    if not scen_dir.exists():
        console.print(f"[red]Directory not found: {scen_dir}[/red]")
        return

    loader = ScenarioLoader()
    scenarios = loader.load_dir(scen_dir)

    if not scenarios:
        console.print("[yellow]No scenarios found.[/yellow]")
        return

    table = Table(box=box.SIMPLE_HEAD, header_style="bold")
    table.add_column("ID")
    table.add_column("Name")
    table.add_column("Type")
    table.add_column("Steps")
    table.add_column("Tags")

    for s in scenarios:
        table.add_row(
            s.id, s.name, s.agent_type.value, str(len(s.expected_actions)), ", ".join(s.tags)
        )

    console.print(table)
    console.print(f"\n[dim]{len(scenarios)} scenario(s) found[/dim]")


@scenario.command("validate")
@click.argument("path")
def validate(path: str) -> None:
    """Validate a scenario YAML file."""
    from evalgrid.core import ScenarioLoader

    loader = ScenarioLoader()
    try:
        s = loader.load_file(Path(path))
        console.print(f"[green]OK Valid scenario: {s.name} ({s.id})[/green]")
        console.print(f"  Agent type: {s.agent_type.value}")
        console.print(f"  Expected actions: {len(s.expected_actions)}")
        console.print(f"  Required: {len(s.required_actions)}")
    except Exception as e:
        console.print(f"[red]FAIL Invalid scenario: {e}[/red]")
        raise SystemExit(1)
