"""evalgrid flakiness — show scenario stability across historical runs."""

from __future__ import annotations

import asyncio
import sys

import click
from rich import box
from rich.console import Console
from rich.table import Table

from evalgrid.core.models import FlakinessStat
from evalgrid.core.paths import default_database_url

console = Console(legacy_windows=False)

_WINDOW_DEFAULT = 10


async def _load_stats(db_url: str, window: int, scenario_id: str | None) -> list[FlakinessStat]:
    from sqlalchemy import select, func, desc
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

    from evalgrid.api.database import ScenarioResultRecord

    engine = create_async_engine(db_url, echo=False)
    Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    stats: list[FlakinessStat] = []

    async with Session() as db:
        # Distinct scenario IDs
        q = select(
            ScenarioResultRecord.scenario_id,
            ScenarioResultRecord.scenario_name,
        ).distinct()
        if scenario_id:
            q = q.where(ScenarioResultRecord.scenario_id == scenario_id)
        rows = await db.execute(q)
        scenarios = rows.all()

        for sid, sname in scenarios:
            # Last `window` runs for this scenario, newest first
            hist_q = (
                select(ScenarioResultRecord.status)
                .where(ScenarioResultRecord.scenario_id == sid)
                .order_by(ScenarioResultRecord.id.desc())
                .limit(window)
            )
            hist = await db.execute(hist_q)
            statuses = [r[0] for r in hist.all()]
            if not statuses:
                continue

            run_count = len(statuses)
            pass_count = sum(1 for s in statuses if s == "pass")
            fail_count = sum(1 for s in statuses if s == "fail")
            error_count = sum(1 for s in statuses if s == "error")
            pass_rate = pass_count / run_count if run_count else 0.0
            flakiness_score = 1.0 - abs(2 * pass_rate - 1.0)
            is_flaky = 0.0 < pass_rate < 1.0

            stats.append(FlakinessStat(
                scenario_id=sid,
                scenario_name=sname,
                run_count=run_count,
                pass_count=pass_count,
                fail_count=fail_count,
                error_count=error_count,
                pass_rate=pass_rate,
                flakiness_score=flakiness_score,
                is_flaky=is_flaky,
                last_status=statuses[0],
            ))

    await engine.dispose()
    # Sort: flaky first, then by flakiness_score desc, then by name
    return sorted(stats, key=lambda s: (-s.flakiness_score, s.scenario_name))


@click.command()
@click.option("--window", default=_WINDOW_DEFAULT, show_default=True,
              help="Number of recent runs to analyse per scenario")
@click.option("--scenario-id", default=None, help="Analyse a specific scenario only")
@click.option("--flaky-only", is_flag=True, help="Show only flaky scenarios")
def flakiness(window: int, scenario_id: str | None, flaky_only: bool) -> None:
    """Show scenario stability across historical runs."""
    try:
        stats = asyncio.run(_load_stats(default_database_url(), window, scenario_id))
    except Exception as exc:
        console.print(f"[red]Could not load flakiness data: {exc}[/red]")
        sys.exit(3)

    if not stats:
        console.print("[yellow]No run history found. Run some evals first.[/yellow]")
        sys.exit(0)

    if flaky_only:
        stats = [s for s in stats if s.is_flaky]
        if not stats:
            console.print("[green]No flaky scenarios detected.[/green]")
            sys.exit(0)

    flaky_count = sum(1 for s in stats if s.is_flaky)
    window_label = f"last {window} runs"
    console.print(f"\n[bold]Flakiness analysis[/bold]  ({window_label})\n")

    table = Table(box=box.SIMPLE_HEAD, show_header=True, header_style="bold")
    table.add_column("Scenario")
    table.add_column("Runs", width=5, justify="right")
    table.add_column("Pass", width=5, justify="right")
    table.add_column("Fail", width=5, justify="right")
    table.add_column("Err", width=4, justify="right")
    table.add_column("Pass rate", width=9, justify="right")
    table.add_column("Flakiness", width=9, justify="right")
    table.add_column("Last", width=6)

    for s in stats:
        if s.is_flaky:
            name_col = f"[yellow]{s.scenario_name}[/yellow]"
            flak_col = f"[yellow]{s.flakiness_score:.2f}[/yellow]"
        elif s.pass_rate == 1.0:
            name_col = s.scenario_name
            flak_col = "[green]0.00[/green]"
        else:
            name_col = f"[red]{s.scenario_name}[/red]"
            flak_col = f"[dim]0.00[/dim]"

        last_color = "green" if s.last_status == "pass" else ("yellow" if s.last_status == "error" else "red")
        table.add_row(
            name_col,
            str(s.run_count),
            str(s.pass_count),
            str(s.fail_count),
            str(s.error_count),
            f"{s.pass_rate:.0%}",
            flak_col,
            f"[{last_color}]{s.last_status}[/{last_color}]",
        )

    console.print(table)

    if flaky_count:
        console.print(f"[yellow]{flaky_count}/{len(stats)} scenario(s) are flaky[/yellow]")
        sys.exit(1)
    else:
        console.print(f"[green]All {len(stats)} scenarios are stable[/green]")
        sys.exit(0)
