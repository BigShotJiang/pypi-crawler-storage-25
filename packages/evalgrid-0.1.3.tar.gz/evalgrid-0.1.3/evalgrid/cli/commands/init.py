"""evalgrid init — scaffold .evalgrid/ in the current project."""

from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel

console = Console(legacy_windows=False)

CONFIG_TEMPLATE = """\
# evalgrid configuration
model: claude-sonnet-4-6
max_concurrent: 5
timeout_seconds: 120
retry_on_error: true
max_retries: 2
output_dir: .evalgrid/results
scenarios_dir: .evalgrid/scenarios
suites_dir: .evalgrid/suites
# Database path: ~/.evalgrid/results.db (override via DATABASE_URL env var)

# Choose your judge model (used to score agent responses)
judge:
  # Anthropic (default)
  provider: anthropic
  model: claude-sonnet-4-6
  api_key_env: ANTHROPIC_API_KEY

  # OpenAI alternative:
  # provider: openai
  # model: gpt-4o
  # api_key_env: OPENAI_API_KEY

  # Google alternative:
  # provider: google
  # model: gemini/gemini-1.5-pro
  # api_key_env: GEMINI_API_KEY

  # Local Ollama (no API key needed):
  # provider: ollama
  # model: ollama/llama3.1:70b
  # api_key_env: ""

  # OpenRouter (200+ models, one key):
  # provider: openrouter
  # model: openrouter/anthropic/claude-sonnet-4
  # api_key_env: OPENROUTER_API_KEY
"""

EXAMPLE_SCENARIO = """\
id: example-hello-world
name: Hello World
description: Verify the agent responds politely to a greeting
agent_type: generic
prompt: |
  You are a helpful AI assistant. Respond to user messages in a friendly,
  concise way. Always greet the user back and offer to help.
test_input: "Hello! Can you help me today?"
expected_actions:
  - action: greet_user
    required: true
    description: Agent greets the user back
  - action: offer_assistance
    required: true
    description: Agent offers to help
  - action: ask_followup
    required: false
    description: Agent asks what the user needs help with
success_criteria: >
  The agent should acknowledge the greeting warmly and clearly offer assistance.
  The tone should be friendly and professional.
tags:
  - greeting
  - basic
timeout_seconds: 30
"""

EXAMPLE_SUITE = """\
# Example suite — runs the example scenarios shipped with `evalgrid init`.
# Use:  evalgrid run --suite example
id: example
name: Example Suite
description: Default suite shipped with evalgrid init. Verifies the install end-to-end.
version: 1
pass_threshold: 1.0
scenarios:
  - example-hello-world
"""

GITIGNORE_ADDITION = """
# evalgrid
.evalgrid/results/
.evalgrid/results.db
"""


@click.command()
@click.option("--dir", "target_dir", default=".", help="Project directory to initialize")
@click.option("--with-examples", is_flag=True, default=True, help="Copy example scenarios")
@click.option("--force", is_flag=True, help="Overwrite existing .evalgrid/ without prompting")
@click.option("--yes", "-y", is_flag=True, help="Skip prompts; exit gracefully if .evalgrid/ exists")
def init(target_dir: str, with_examples: bool, force: bool, yes: bool) -> None:
    """Scaffold a .evalgrid/ folder in your project."""
    root = Path(target_dir).resolve()
    evalgrid_dir = root / ".evalgrid"

    if evalgrid_dir.exists():
        if force:
            pass
        elif yes:
            click.echo(f"Already initialized at {evalgrid_dir}. Use --force to overwrite.")
            return
        else:
            console.print("[yellow]! .evalgrid/ already exists.[/yellow]")
            if not click.confirm("Reinitialize?", default=False):
                return

    (evalgrid_dir / "scenarios").mkdir(parents=True, exist_ok=True)
    (evalgrid_dir / "results").mkdir(parents=True, exist_ok=True)
    (evalgrid_dir / "suites").mkdir(parents=True, exist_ok=True)

    config_path = evalgrid_dir / "config.yml"
    config_path.write_text(CONFIG_TEMPLATE)

    if with_examples:
        example_path = evalgrid_dir / "scenarios" / "example-hello-world.yml"
        example_path.write_text(EXAMPLE_SCENARIO)
        suite_path = evalgrid_dir / "suites" / "example.yml"
        suite_path.write_text(EXAMPLE_SUITE)

    gitignore = root / ".gitignore"
    if gitignore.exists():
        content = gitignore.read_text()
        if ".evalgrid/results" not in content:
            gitignore.write_text(content + GITIGNORE_ADDITION)

    console.print(
        Panel.fit(
            "[bold green]evalgrid initialized![/bold green]\n\n"
            f"[dim]Config:[/dim]    [cyan]{config_path.relative_to(root)}[/cyan]\n"
            f"[dim]Scenarios:[/dim] [cyan]{(evalgrid_dir / 'scenarios').relative_to(root)}"
            "[/cyan]\n"
            f"[dim]Suites:[/dim]    [cyan]{(evalgrid_dir / 'suites').relative_to(root)}"
            "[/cyan]\n\n"
            "[bold]Next steps:[/bold]\n\n"
            "  1. Try it now (no API key required):\n"
            "     [cyan]evalgrid run --mock[/cyan]\n\n"
            "  2. Or run the bundled example suite:\n"
            "     [cyan]evalgrid run --suite example[/cyan]\n\n"
            "  3. To run with real AI scoring, set your API key:\n"
            "     [cyan]Linux/macOS:[/cyan]  export ANTHROPIC_API_KEY=sk-ant-...\n"
            "     [cyan]Windows:[/cyan]      $env:ANTHROPIC_API_KEY = \"sk-ant-...\"\n\n"
            "  4. Open the dashboard:\n"
            "     [cyan]evalgrid server[/cyan]  ->  http://localhost:8000",
            title="evalgrid",
            border_style="green",
        )
    )
