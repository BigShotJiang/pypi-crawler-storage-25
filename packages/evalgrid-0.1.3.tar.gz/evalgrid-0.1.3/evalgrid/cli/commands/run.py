"""evalgrid run — execute all scenarios and report results."""

from __future__ import annotations

import asyncio
import json
import os
import sys
import uuid
from datetime import UTC, datetime
from pathlib import Path

import click
import yaml
from rich import box
from rich.console import Console
from rich.live import Live
from rich.table import Table

from evalgrid.core import EvalConfig, ScenarioLoader, ScenarioResult
from evalgrid.core.models import PassFail, SuiteResult
from evalgrid.core.paths import default_database_url, resolve_scenarios_dir
from evalgrid.core.runner import ScenarioRunner

console = Console(legacy_windows=False)


def _load_config(config_path: Path) -> EvalConfig:
    if config_path.exists():
        with open(config_path) as f:
            data = yaml.safe_load(f) or {}
        if "database_url" in data:
            console.print(
                "[yellow]Warning:[/yellow] 'database_url' in config is ignored. "
                "Set the DATABASE_URL environment variable instead."
            )
        return EvalConfig(**data)
    return EvalConfig()


def _result_row(result: ScenarioResult) -> tuple[str, ...]:
    if result.status == PassFail.PASS:
        icon = "+"
    elif result.status == PassFail.ERROR:
        icon = "!"
    else:
        icon = "x"
    color = (
        "green" if result.status == PassFail.PASS
        else ("yellow" if result.status == PassFail.ERROR else "red")
    )
    passed = sum(1 for s in result.steps if s.status == PassFail.PASS)
    total = len(result.steps)
    cost_cell = f"${result.cost_usd:.4f}" if result.cost_usd > 0 else "[dim]-[/dim]"
    return (
        f"[{color}]{icon}[/{color}]",
        result.scenario_name,
        result.agent_type.value,
        f"[{color}]{result.status.value.upper()}[/{color}]",
        f"{result.overall_score:.2f}",
        f"{passed}/{total}",
        cost_cell,
        result.error or result.reasoning[:80] if result.status != PassFail.PASS else "",
    )


async def _persist_to_db(
    db_url: str,
    run_id: str,
    started_at: datetime,
    results: list[ScenarioResult],
    passed: int,
    total: int,
    pass_rate: float,
    skipped: list[dict[str, str]] | None = None,
    suite_result: "SuiteResult | None" = None,
    suite_version: int = 1,
) -> None:
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

    from evalgrid.api.database import Base, RunRecord, ScenarioResultRecord, SuiteResultRecord

    engine = create_async_engine(db_url, echo=False)
    Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    now = datetime.now(UTC)
    async with Session() as db:
        db.add(RunRecord(
            run_id=run_id,
            started_at=started_at,
            finished_at=now,
            passed=passed,
            total=total,
            pass_rate=pass_rate,
            results=[r.model_dump(mode="json") for r in results],
            skipped_scenarios=skipped or [],
        ))
        for result in results:
            db.add(ScenarioResultRecord(
                run_id=run_id,
                scenario_id=result.scenario_id,
                scenario_name=result.scenario_name,
                agent_type=result.agent_type.value,
                status=result.status.value,
                overall_score=result.overall_score,
                pass_rate=result.pass_rate,
                reasoning=result.reasoning,
                error=result.error,
                steps=[s.model_dump(mode="json") for s in result.steps],
                prompt_tokens=result.prompt_tokens,
                completion_tokens=result.completion_tokens,
                cost_usd=result.cost_usd,
                started_at=result.started_at,
                finished_at=result.finished_at,
            ))
        if suite_result is not None:
            db.add(SuiteResultRecord(
                run_id=run_id,
                suite_id=suite_result.suite_id,
                suite_name=suite_result.suite_name,
                suite_version=suite_version,
                pass_threshold=suite_result.pass_threshold,
                total=suite_result.total,
                semantic_pass_rate=suite_result.semantic_pass_rate,
                hard_fail_rate=suite_result.hard_fail_rate,
                soft_fail_rate=suite_result.soft_fail_rate,
                error_rate=suite_result.error_rate,
                weighted_score=suite_result.weighted_score,
                passed=int(suite_result.passed),
                created_at=now,
            ))
        await db.commit()

    await engine.dispose()


@click.command()
@click.option("--scenarios-dir", default=None, help="Override scenarios directory")
@click.option("--config", "config_path", default=".evalgrid/config.yml", show_default=True)
@click.option("--suite", "suite_id", default=None, help="Run scenarios in a named suite")
@click.option("--tag", multiple=True, help="Only run scenarios with this tag (repeatable)")
@click.option("--scenario-id", multiple=True, help="Only run specific scenario IDs")
@click.option("--output", default=None, help="Save JSON results to file")
@click.option("--report", "report_path", default=None, help="Generate HTML/Markdown report (.html or .md)")
@click.option("--fail-fast", is_flag=True, help="Stop on first failure")
@click.option("--mock", is_flag=True, help="Use mock scorer (no API calls)")
def run(
    scenarios_dir: str | None,
    config_path: str,
    suite_id: str | None,
    tag: tuple[str, ...],
    scenario_id: tuple[str, ...],
    output: str | None,
    report_path: str | None,
    fail_fast: bool,
    mock: bool,
) -> None:
    """Run all eval scenarios and report pass/fail."""
    from evalgrid.core.suite_loader import SuiteLoader, compute_suite_result

    config = _load_config(Path(config_path))

    # FIX 1 (v0.1.3) — unify scenarios_dir resolution with the API.
    # Explicit --scenarios-dir always wins. Otherwise honor a user-customized
    # config.scenarios_dir; if the user left it at the package default, fall
    # back to the shared resolver (env var > cwd > home).
    if scenarios_dir:
        scen_dir = Path(scenarios_dir)
    else:
        default_config_dir = EvalConfig.model_fields["scenarios_dir"].default
        if config.scenarios_dir and config.scenarios_dir != default_config_dir:
            scen_dir = Path(config.scenarios_dir)
        else:
            scen_dir = resolve_scenarios_dir()
    if not scen_dir.exists():
        console.print(f"[red]Scenarios directory not found: {scen_dir}[/red]")
        console.print("Run [cyan]evalgrid init[/cyan] first.")
        sys.exit(1)

    loader = ScenarioLoader()
    scenarios = loader.load_dir(scen_dir)

    if loader.skipped:
        n = len(loader.skipped)
        console.print(
            f"[yellow]Warning: {n} scenario(s) skipped due to validation errors:[/yellow]"
        )
        for skip in loader.skipped:
            console.print(f"  [dim]• {skip['file']}: {skip['reason']}[/dim]")

    if not scenarios:
        console.print(f"[yellow]No scenarios found in {scen_dir}[/yellow]")
        sys.exit(0)

    # Load suite and filter scenarios
    active_suite = None
    if suite_id:
        suites_dir = Path(config.suites_dir)
        suite_path = suites_dir / f"{suite_id}.yml"
        if not suite_path.exists():
            suite_path = suites_dir / f"{suite_id}.yaml"
        if not suite_path.exists():
            console.print(f"[red]Suite not found: {suite_id}[/red]")
            console.print(f"Expected: {suites_dir / suite_id}.yml")
            sys.exit(3)
        active_suite = SuiteLoader().load_file(suite_path)
        scenarios = SuiteLoader().filter_scenarios(active_suite, scenarios)
        console.print(f"[dim]Suite: {active_suite.name} · threshold {active_suite.pass_threshold:.0%}[/dim]")

    # Filter by tag/id (additional filters on top of suite)
    if tag:
        scenarios = [s for s in scenarios if any(t in s.tags for t in tag)]
    if scenario_id:
        scenarios = [s for s in scenarios if s.id in scenario_id]

    if not scenarios:
        console.print("[yellow]No scenarios match the given filters.[/yellow]")
        sys.exit(0)

    api_key_env = config.judge.api_key_env
    if not mock and api_key_env and not os.environ.get(api_key_env):
        console.print(f"[red]Error:[/red] {api_key_env} is not set.\n")
        console.print("Set your API key first:")
        console.print(f"  [cyan]Linux/macOS:[/cyan]  export {api_key_env}=<your-key>")
        console.print(f"  [cyan]Windows:[/cyan]      $env:{api_key_env} = \"<your-key>\"")
        provider, model = config.judge.provider, config.judge.model
        console.print(
            f"\nConfigured provider: [cyan]{provider}[/cyan]  model: [cyan]{model}[/cyan]"
        )
        console.print("\nOr run without an API key:")
        console.print("  [cyan]evalgrid run --mock[/cyan]")
        sys.exit(1)

    console.print(f"\n[bold]Running {len(scenarios)} scenario(s)...[/bold]\n")

    if mock:
        from evalgrid.core.scorer import MockScorer
        runner_instance = ScenarioRunner(
            config,
            scorer=MockScorer(),
            agent_fn=lambda s: ("[mock agent output]", 0),
            mock=True,
        )
    else:
        runner_instance = ScenarioRunner(config)

    table = Table(box=box.SIMPLE_HEAD, show_header=True, header_style="bold")
    table.add_column("", width=2)
    table.add_column("Scenario")
    table.add_column("Type")
    table.add_column("Status", width=8)
    table.add_column("Score", width=6)
    table.add_column("Steps", width=6)
    table.add_column("Cost", width=9, justify="right")
    table.add_column("Notes")

    results: list[ScenarioResult] = []
    run_id = str(uuid.uuid4())
    run_started_at = datetime.now(UTC)
    stop = False

    with Live(table, console=console, refresh_per_second=4):
        for scenario in scenarios:
            result = runner_instance.run_scenario(scenario)
            results.append(result)
            table.add_row(*_result_row(result))
            if result.status != PassFail.PASS:
                if fail_fast:
                    stop = True
                    break

    # Summary
    passed_count = sum(1 for r in results if r.status == PassFail.PASS)
    total = len(results)
    overall_pass_rate = passed_count / total if total else 0.0

    color = "green" if passed_count == total else ("yellow" if passed_count > 0 else "red")
    console.print(
        f"\n[bold {color}]{passed_count}/{total} scenarios passed[/bold {color}] "
        f"({overall_pass_rate:.0%})"
    )

    total_cost = sum(r.cost_usd for r in results)
    if total_cost > 0:
        console.print(f"[dim]Total cost: ${total_cost:.4f}[/dim]")

    # Suite summary — three separate rates, never collapsed
    suite_result = None
    if active_suite:
        suite_result = compute_suite_result(active_suite, results, scenarios)
        suite_color = "green" if suite_result.passed else "red"
        suite_label = "PASS" if suite_result.passed else "FAIL"
        console.print(f"\n[bold]Suite: {active_suite.name}[/bold]")
        console.print(
            f"  [{suite_color}]{suite_label}[/{suite_color}]"
            f"  threshold {suite_result.pass_threshold:.0%}"
        )
        console.print(f"  Semantic pass  {suite_result.semantic_pass_rate:.0%}")
        console.print(f"  Hard-fail rate {suite_result.hard_fail_rate:.0%}")
        console.print(f"  Soft-fail rate {suite_result.soft_fail_rate:.0%}")
        console.print(f"  Weighted score {suite_result.weighted_score:.2f}")

    # Generate report
    if report_path:
        from evalgrid.core.report import _git_sha, _evalgrid_version, write_report
        rp = Path(report_path)
        meta = {
            "model": config.model,
            "git_sha": _git_sha(),
            "version": _evalgrid_version(),
            "suite": suite_result,
        }
        write_report(rp, results, passed_count, total, run_started_at, meta)
        console.print(f"\n[dim]Report saved to {report_path}[/dim]")

    # Save results
    if output:
        out_path = Path(output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(
            json.dumps(
                {
                    "run_at": datetime.now(UTC).isoformat(),
                    "pass_rate": overall_pass_rate,
                    "passed": passed_count,
                    "total": total,
                    "results": [r.model_dump(mode="json") for r in results],
                },
                indent=2,
            )
        )
        console.print(f"\n[dim]Results saved to {output}[/dim]")

    # Save to default results dir
    results_dir = Path(config.output_dir)
    results_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(UTC).strftime("%Y%m%dT%H%M%S")
    default_out = results_dir / f"run-{ts}.json"
    default_out.write_text(
        json.dumps(
            {
                "run_at": datetime.now(UTC).isoformat(),
                "pass_rate": overall_pass_rate,
                "passed": passed_count,
                "total": total,
                "results": [r.model_dump(mode="json") for r in results],
            },
            indent=2,
        )
    )

    # Persist to SQLite so the dashboard can display this run
    try:
        asyncio.run(_persist_to_db(
            default_database_url(),
            run_id,
            run_started_at,
            results,
            passed_count,
            total,
            overall_pass_rate,
            skipped=loader.skipped,
            suite_result=suite_result,
            suite_version=active_suite.version if active_suite else 1,
        ))
        console.print(f"[dim]Run saved to database (id: {run_id})[/dim]")
    except Exception as exc:
        console.print(f"[yellow]Warning: could not write to database: {exc}[/yellow]")

    # Granular exit codes for CI gating
    # 0 = all pass / suite threshold met   1 = soft failures   2 = hard failures / errors
    has_hard = any(r.hard_failed or r.status == PassFail.ERROR for r in results)
    has_soft = any(r.status == PassFail.FAIL and not r.hard_failed for r in results)
    if suite_result is not None and not suite_result.passed:
        exit_code = 2 if has_hard else 1
    else:
        exit_code = 2 if has_hard else (1 if has_soft else 0)
    sys.exit(exit_code)
