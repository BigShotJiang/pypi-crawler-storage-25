from evalgrid.cli.main import cli as main

__all__ = ["main"]
