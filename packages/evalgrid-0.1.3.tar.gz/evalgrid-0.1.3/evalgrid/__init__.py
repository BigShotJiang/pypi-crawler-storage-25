"""evalgrid — open-source AI agent evaluation framework."""

__version__ = "0.1.3"
