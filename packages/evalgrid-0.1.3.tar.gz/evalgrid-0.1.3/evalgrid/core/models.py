"""Core data models for evalgrid."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class AgentType(StrEnum):
    GENERIC = "generic"
    SDR = "sdr"
    CODING = "coding"
    SUPPORT = "support"
    RESEARCH = "research"
    FINANCE = "finance"
    LEGAL = "legal"
    CUSTOM = "custom"


class PassFail(StrEnum):
    PASS = "pass"
    FAIL = "fail"
    SKIP = "skip"
    ERROR = "error"


class CheckConfig(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    type: str
    hard_fail: bool = True
    fields: list[str] = Field(default_factory=list)   # required_fields
    field: str = ""                                    # enum
    allowed: list[str] = Field(default_factory=list)  # enum
    pattern: str = ""                                  # forbidden_regex
    text: str = ""                                     # contains
    value: int = 0                                     # max_length
    schema_def: dict[str, Any] = Field(default_factory=dict, alias="schema")  # json_schema
    strict: bool = False  # json_schema: auto-inject additionalProperties: false


class CheckResult(BaseModel):
    name: str
    passed: bool
    hard_fail: bool = True
    details: str = ""
    error_path: str = ""   # JSON pointer path for json_schema failures


class ExpectedAction(BaseModel):
    action: str
    params: dict[str, Any] = Field(default_factory=dict)
    required: bool = True
    description: str = ""


class StepResult(BaseModel):
    step_index: int
    action: str
    expected_action: str | None = None
    status: PassFail
    score: float = Field(ge=0.0, le=1.0, default=0.0)
    reasoning: str = ""
    actual_output: str = ""
    latency_ms: int = 0


class ScenarioResult(BaseModel):
    scenario_id: str
    scenario_name: str
    agent_type: AgentType
    status: PassFail
    overall_score: float = Field(ge=0.0, le=1.0, default=0.0)
    steps: list[StepResult] = Field(default_factory=list)
    pass_rate: float = Field(ge=0.0, le=1.0, default=0.0)
    reasoning: str = ""
    error: str | None = None
    check_results: list[CheckResult] = Field(default_factory=list)
    hard_failed: bool = False
    # Cost tracking: sum of agent + judge LiteLLM calls. Zero in mock mode.
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_usd: float = 0.0
    started_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    finished_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class Scenario(BaseModel):
    id: str
    name: str
    description: str = ""
    agent_type: AgentType = AgentType.GENERIC
    prompt: str
    test_input: str
    expected_actions: list[ExpectedAction] = Field(default_factory=list)
    success_criteria: str = ""
    tags: list[str] = Field(default_factory=list)
    timeout_seconds: int = 60
    checks: list[CheckConfig] = Field(default_factory=list)
    weight: float = 1.0
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def required_actions(self) -> list[ExpectedAction]:
        return [a for a in self.expected_actions if a.required]


DEFAULT_JUDGE_MODEL = "claude-sonnet-4-6"


class JudgeConfig(BaseModel):
    provider: str = "anthropic"
    model: str = DEFAULT_JUDGE_MODEL
    api_key_env: str = "ANTHROPIC_API_KEY"
    api_key: str | None = None  # direct key — takes precedence over api_key_env


class EvalConfig(BaseModel):
    model: str = DEFAULT_JUDGE_MODEL
    max_concurrent: int = 5
    timeout_seconds: int = 120
    retry_on_error: bool = True
    max_retries: int = 2
    output_dir: str = ".evalgrid/results"
    scenarios_dir: str = ".evalgrid/scenarios"
    suites_dir: str = ".evalgrid/suites"
    judge: JudgeConfig = Field(default_factory=JudgeConfig)


class SuiteConfig(BaseModel):
    id: str
    name: str
    description: str = ""
    version: int = 1                                     # bump when benchmark definition changes
    scenarios: list[str] = Field(default_factory=list)  # scenario IDs
    tags: list[str] = Field(default_factory=list)        # OR match by tags
    pass_threshold: float = Field(default=1.0, ge=0.0, le=1.0)


class SuiteResult(BaseModel):
    suite_id: str
    suite_name: str
    pass_threshold: float
    total: int
    # ── three distinct rates — never collapsed into one ──────────────────────
    semantic_pass_rate: float   # fraction where judge passed (no hard fail)
    hard_fail_rate: float       # fraction with a hard assertion failure
    soft_fail_rate: float       # fraction with judge FAIL but no hard fail
    error_rate: float           # fraction that raised ERROR
    # ── aggregate ────────────────────────────────────────────────────────────
    weighted_score: float       # weight-normalized average of overall_score
    passed: bool                # meets pass_threshold on semantic_pass_rate


class FlakinessStat(BaseModel):
    scenario_id: str
    scenario_name: str
    run_count: int              # number of historical runs in the window
    pass_count: int
    fail_count: int
    error_count: int
    pass_rate: float            # pass_count / run_count
    flakiness_score: float      # 1 - |2*pass_rate - 1|  (0=stable, 1=maximally flaky)
    is_flaky: bool              # True when 0 < pass_rate < 1 (any non-stable variance)
    last_status: str            # status of most recent run
