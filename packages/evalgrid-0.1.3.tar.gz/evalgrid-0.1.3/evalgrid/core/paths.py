"""Shared filesystem path helpers — single source of truth for default paths."""

from __future__ import annotations

import logging
import os
from pathlib import Path

logger = logging.getLogger("evalgrid")

_VALID_DB_PREFIXES = ("sqlite+aiosqlite://",)


def default_database_url() -> str:
    """Return the canonical async SQLite URL.

    Resolution order (highest precedence first):
      1. ``DATABASE_URL`` environment variable (any sqlite+aiosqlite URL)
      2. ``<cwd>/.evalgrid/results.db`` if ``<cwd>/.evalgrid/`` exists
         (project-local — keeps state with scenarios/suites for that project)
      3. ``~/.evalgrid/results.db`` (global fallback)

    The project-local check mirrors :func:`resolve_scenarios_dir` so a project
    that has scenarios + suites under ``./.evalgrid/`` also gets its results
    persisted there, instead of mixing project work into the home directory
    (which previously caused readonly-DB failures when the home path was
    locked, and ``evalgrid run`` writing to a different DB than the dashboard
    read from).

    The parent directory is created on first use so a fresh ``evalgrid init``
    project that has just ``./.evalgrid/scenarios/`` works end-to-end without
    a separate mkdir step.
    """
    env = os.environ.get("DATABASE_URL")
    if env:
        if not any(env.startswith(prefix) for prefix in _VALID_DB_PREFIXES):
            logger.warning(
                "DATABASE_URL '%s...' does not start with a supported prefix %s. "
                "Only sqlite+aiosqlite:// is validated; other backends may not work correctly.",
                env[:30],
                _VALID_DB_PREFIXES,
            )
        return env
    cwd_evalgrid = Path.cwd() / ".evalgrid"
    if cwd_evalgrid.exists():
        cwd_evalgrid.mkdir(parents=True, exist_ok=True)
        db_path = (cwd_evalgrid / "results.db").as_posix()
    else:
        home_evalgrid = Path.home() / ".evalgrid"
        home_evalgrid.mkdir(parents=True, exist_ok=True)
        db_path = (home_evalgrid / "results.db").as_posix()
    return f"sqlite+aiosqlite:///{db_path}"


def resolve_scenarios_dir() -> Path:
    """Resolve the canonical scenarios directory.

    Resolution order (highest precedence first):
      1. ``EVALGRID_SCENARIOS_DIR`` environment variable
      2. ``<cwd>/.evalgrid/scenarios/`` (if it exists)
      3. ``~/.evalgrid/scenarios/`` (always returned as fallback)

    This is shared between the CLI and the FastAPI server so both see the same
    scenarios — previously the API hard-coded the home directory while the CLI
    used the current working directory, which produced the split-brain bug.
    """
    env = os.environ.get("EVALGRID_SCENARIOS_DIR")
    if env:
        return Path(env).expanduser()
    cwd_candidate = Path.cwd() / ".evalgrid" / "scenarios"
    if cwd_candidate.exists():
        return cwd_candidate
    return Path.home() / ".evalgrid" / "scenarios"


def resolve_suites_dir() -> Path:
    """Resolve the canonical suites directory.

    Resolution order mirrors :func:`resolve_scenarios_dir`:
      1. ``EVALGRID_SUITES_DIR`` environment variable
      2. ``<cwd>/.evalgrid/suites/`` (if it exists)
      3. ``~/.evalgrid/suites/`` (fallback)
    """
    env = os.environ.get("EVALGRID_SUITES_DIR")
    if env:
        return Path(env).expanduser()
    cwd_candidate = Path.cwd() / ".evalgrid" / "suites"
    if cwd_candidate.exists():
        return cwd_candidate
    return Path.home() / ".evalgrid" / "suites"
