"""Load scenarios from YAML files."""

from __future__ import annotations

import logging
import uuid
from pathlib import Path

import yaml

from .models import AgentType, CheckConfig, ExpectedAction, Scenario

logger = logging.getLogger("evalgrid")


def _friendly_reason(exc: Exception) -> str:
    """Translate a raw exception into a user-readable error message."""
    if isinstance(exc, yaml.YAMLError):
        first_line = str(exc).split("\n")[0].strip()
        return f"invalid YAML syntax: {first_line}"

    try:
        import pydantic
        if isinstance(exc, pydantic.ValidationError):
            first = exc.errors()[0]
            field = ".".join(str(loc) for loc in first["loc"])
            msg = first["msg"].lower()
            if "valid list" in msg:
                return f"'{field}' must be a list"
            if "valid string" in msg:
                return f"'{field}' must be a string"
            return f"'{field}': {first['msg']}"
    except ImportError:
        pass

    if isinstance(exc, KeyError):
        return f"missing required field: {exc}"

    if isinstance(exc, TypeError):
        s = str(exc)
        if "must be a list" in s or "must be a dict" in s:
            return s
        if "string indices" in s or "must be integer" in s:
            return (
                "schema mismatch — check that all fields have the correct type "
                "(list vs string, dict vs list)"
            )
        return f"could not parse: {type(exc).__name__}: {exc}"

    if isinstance(exc, ValueError):
        return str(exc)

    return f"could not parse: {type(exc).__name__}: {exc}"


class ScenarioLoader:
    def __init__(self) -> None:
        self.skipped: list[dict[str, str]] = []

    def load_file(self, path: Path) -> Scenario:
        with open(path) as f:
            data = yaml.safe_load(f)

        if data is None:
            raise ValueError("empty or whitespace-only file")

        raw_actions = data.get("expected_actions", [])
        if not isinstance(raw_actions, list):
            raise TypeError(
                f"'expected_actions' must be a list (got {type(raw_actions).__name__})"
            )

        expected_actions = [
            ExpectedAction(
                action=a["action"],
                params=a.get("params", {}),
                required=a.get("required", True),
                description=a.get("description", ""),
            )
            for a in raw_actions
        ]

        raw_checks = data.get("checks", [])
        if not isinstance(raw_checks, list):
            raise TypeError("'checks' must be a list")
        checks = [
            CheckConfig(
                type=c["type"],
                hard_fail=c.get("hard_fail", True),
                fields=c.get("fields", []),
                field=c.get("field", ""),
                allowed=c.get("allowed", []),
                pattern=c.get("pattern", ""),
                text=c.get("text", ""),
                value=c.get("value", 0),
                schema_def=c.get("schema", {}),
                strict=c.get("strict", False),
            )
            for c in raw_checks
        ]

        return Scenario(
            id=data.get("id", str(uuid.uuid4())),
            name=data.get("name", path.stem),
            description=data.get("description", ""),
            agent_type=AgentType(data.get("agent_type", "generic")),
            prompt=data["prompt"],
            test_input=data["test_input"],
            expected_actions=expected_actions,
            success_criteria=data.get("success_criteria", ""),
            tags=data.get("tags", []),
            timeout_seconds=data.get("timeout_seconds", 60),
            checks=checks,
            weight=float(data.get("weight", 1.0)),
            metadata=data.get("metadata", {}),
        )

    def load_dir(self, directory: Path) -> list[Scenario]:
        self.skipped = []
        scenarios = []
        for path in sorted(directory.rglob("*.yml")) + sorted(directory.rglob("*.yaml")):
            if path.name.startswith("_"):
                continue
            try:
                scenarios.append(self.load_file(path))
            except Exception as e:
                reason = _friendly_reason(e)
                self.skipped.append({"file": path.name, "reason": reason})
                logger.warning("Failed to load %s: %s", path, reason)
        return scenarios
