"""Report generators — HTML and Markdown output from run results."""

from __future__ import annotations

import html
import subprocess
from datetime import datetime
from pathlib import Path

from .models import CheckResult, PassFail, ScenarioResult


# ── provenance helpers ───────────────────────────────────────────────────────

def _git_sha() -> str:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True, timeout=3,
        )
        return result.stdout.strip() if result.returncode == 0 else ""
    except Exception:
        return ""


def _evalgrid_version() -> str:
    try:
        from importlib.metadata import version
        return version("evalgrid")
    except Exception:
        return ""


# ── helpers ─────────────────────────────────────────────────────────────────

def _status_icon(status: str) -> str:
    return {"pass": "✓", "fail": "✗", "error": "!", "skip": "–"}.get(status, "?")


def _score_pct(score: float) -> str:
    return f"{round(score * 100)}%"


def _esc(s: str) -> str:
    return html.escape(s or "")


# ── Markdown ─────────────────────────────────────────────────────────────────

def generate_markdown(
    results: list[ScenarioResult],
    passed: int,
    total: int,
    run_at: datetime,
    meta: dict | None = None,
) -> str:
    meta = meta or {}
    lines: list[str] = []
    pass_rate = passed / total if total else 0.0
    badge = "✓" if passed == total else ("~" if passed > 0 else "✗")
    ts = run_at.strftime("%Y-%m-%d %H:%M UTC")
    model = meta.get("model", "")

    lines += [
        f"# evalgrid run — {ts}",
        "",
        f"**{badge} {passed}/{total} passed** ({pass_rate:.0%})"
        + (f"  ·  model: `{model}`" if model else ""),
        "",
    ]

    # Provenance block
    prov_parts = []
    if model:
        prov_parts.append(f"model: `{model}`")
    if meta.get("version"):
        prov_parts.append(f"evalgrid: `{meta['version']}`")
    if meta.get("git_sha"):
        prov_parts.append(f"git: `{meta['git_sha']}`")
    if prov_parts:
        lines += [
            "<details><summary>Provenance</summary>",
            "",
            "| Key | Value |",
            "|---|---|",
        ]
        if model:
            lines.append(f"| model | `{model}` |")
        if meta.get("version"):
            lines.append(f"| evalgrid | `{meta['version']}` |")
        if meta.get("git_sha"):
            lines.append(f"| git sha | `{meta['git_sha']}` |")
        lines.append(f"| timestamp | `{ts}` |")
        lines += ["", "</details>", ""]

    # Suite summary (three rates, never collapsed)
    suite = meta.get("suite") if meta else None
    if suite is not None:
        suite_icon = "✓" if suite.passed else "✗"
        lines += [
            "## Suite",
            "",
            f"**{suite_icon} {suite.suite_name}** · threshold {suite.pass_threshold:.0%} · "
            f"{'PASS' if suite.passed else 'FAIL'}",
            "",
            "| Metric | Value |",
            "|---|---|",
            f"| Semantic pass rate | {suite.semantic_pass_rate:.0%} |",
            f"| Hard-fail rate | {suite.hard_fail_rate:.0%} |",
            f"| Soft-fail rate | {suite.soft_fail_rate:.0%} |",
            f"| Weighted score | {suite.weighted_score:.2f} |",
            "",
        ]

    # Summary table
    lines += [
        "## Results",
        "",
        "| Scenario | Type | Status | Score | Checks |",
        "|---|---|---|---|---|",
    ]
    for r in results:
        icon = _status_icon(r.status.value)
        checks_summary = ""
        if r.check_results:
            n_pass = sum(1 for c in r.check_results if c.passed)
            n_total = len(r.check_results)
            checks_summary = f"{n_pass}/{n_total}"
        lines.append(
            f"| {r.scenario_name} "
            f"| {r.agent_type.value} "
            f"| {icon} {r.status.value.upper()} "
            f"| {_score_pct(r.overall_score)} "
            f"| {checks_summary} |"
        )

    # Detail blocks for non-passing scenarios
    failures = [r for r in results if r.status != PassFail.PASS]
    if failures:
        lines += ["", "## Failures", ""]
        for r in failures:
            icon = _status_icon(r.status.value)
            lines += [
                f"### {icon} {r.scenario_name}",
                "",
            ]

            if r.check_results:
                lines.append("**Deterministic checks**")
                lines.append("")
                for c in r.check_results:
                    ci = "✓" if c.passed else ("✗" if c.hard_fail else "~")
                    line = f"- {ci} `{c.name}`"
                    if not c.passed and c.error_path:
                        line += f"  · path: `{c.error_path}`"
                    if not c.passed and c.details:
                        line += f"  · {c.details}"
                    lines.append(line)
                lines.append("")

            if r.error:
                lines += [f"**Error:** `{r.error}`", ""]

            if r.reasoning:
                lines += [f"> {r.reasoning}", ""]

            lines.append("---")
            lines.append("")
    else:
        lines += ["", "> All scenarios passed.", ""]

    lines += [
        "",
        f"*Generated by [evalgrid](https://github.com/naman006-rai/evalgrid)*",
    ]
    return "\n".join(lines)


# ── HTML ─────────────────────────────────────────────────────────────────────

_CSS = """
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
  background: #0f1117; color: #e2e4e9; line-height: 1.5;
  padding: 32px 16px; min-height: 100vh;
}
a { color: #7c84ff; }
.wrap { max-width: 860px; margin: 0 auto; }
header { margin-bottom: 32px; }
header h1 { font-size: 20px; font-weight: 700; letter-spacing: -0.02em; color: #fff; margin-bottom: 8px; }
.meta { font-size: 13px; color: #6b7280; }
.summary { display: flex; align-items: center; gap: 14px; margin-top: 16px; flex-wrap: wrap; }
.badge { display: inline-flex; align-items: center; gap: 6px; padding: 5px 12px; border-radius: 99px;
  font-size: 13px; font-weight: 600; letter-spacing: -0.01em; }
.badge.pass  { background: rgba(34,197,94,0.15);  color: #22c55e; border: 1px solid rgba(34,197,94,0.3);  }
.badge.fail  { background: rgba(239,68,68,0.15);  color: #ef4444; border: 1px solid rgba(239,68,68,0.3);  }
.badge.warn  { background: rgba(234,179,8,0.15);  color: #eab308; border: 1px solid rgba(234,179,8,0.3);  }
.pass-rate { font-size: 28px; font-weight: 700; letter-spacing: -0.03em; }
.pass-rate.green { color: #22c55e; } .pass-rate.yellow { color: #eab308; } .pass-rate.red { color: #ef4444; }

.scenarios { display: flex; flex-direction: column; gap: 12px; }
.scenario { border-radius: 14px; background: #1a1d27; border: 1px solid #2a2d3a; overflow: hidden; }
.scenario-header {
  display: flex; align-items: center; gap: 12px; padding: 14px 18px;
  border-bottom: 1px solid #2a2d3a; flex-wrap: wrap;
}
.scenario-header h2 { font-size: 14px; font-weight: 600; flex: 1; min-width: 0;
  letter-spacing: -0.01em; color: #fff; }
.tag { font-size: 11px; color: #9ca3af; font-family: monospace;
  background: #22263a; padding: 2px 7px; border-radius: 4px; }
.score-pill { font-size: 13px; font-weight: 700; font-variant-numeric: tabular-nums; }
.score-pill.green { color: #22c55e; } .score-pill.yellow { color: #eab308; } .score-pill.red { color: #ef4444; }

.section { padding: 14px 18px; border-top: 1px solid #2a2d3a; }
.section-label {
  font-size: 10.5px; font-weight: 600; color: #6b7280; letter-spacing: 0.06em;
  text-transform: uppercase; margin-bottom: 10px; display: flex; align-items: center; gap: 6px;
}
.check-row { display: flex; align-items: flex-start; gap: 10px; padding: 6px 0; }
.check-icon { font-size: 13px; flex-shrink: 0; margin-top: 1px; }
.check-icon.ok { color: #22c55e; } .check-icon.fail { color: #ef4444; } .check-icon.soft { color: #eab308; }
.check-name { font-family: monospace; font-size: 12.5px; color: #e2e4e9; font-weight: 500; }
.check-badge { font-size: 10px; color: #6b7280; background: #22263a;
  padding: 1px 6px; border-radius: 4px; margin-left: 4px; }
.check-path { font-family: monospace; font-size: 11px; color: #9ca3af;
  background: #22263a; padding: 1px 6px; border-radius: 4px; margin-left: 6px; }
.check-details { font-size: 12px; color: #9ca3af; margin-top: 3px; }
.check-details.err { color: #f87171; }

.steps { display: flex; flex-direction: column; }
.step-row { display: flex; align-items: flex-start; gap: 12px; padding: 10px 0; border-top: 1px solid #2a2d3a; }
.step-row:first-child { border-top: none; }
.step-dot { width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; margin-top: 6px; }
.step-idx { font-family: monospace; font-size: 11px; color: #6b7280; width: 20px; flex-shrink: 0; padding-top: 2px; }
.step-body { flex: 1; min-width: 0; }
.step-action { font-family: monospace; font-size: 12.5px; color: #e2e4e9; font-weight: 500; }
.step-verdict { font-size: 12px; color: #9ca3af; margin-top: 3px; line-height: 1.5; }
.step-score { font-family: monospace; font-size: 13px; font-weight: 700; flex-shrink: 0; margin-top: 1px; }

.error-box { background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.25);
  border-radius: 8px; padding: 10px 14px; font-family: monospace; font-size: 12px;
  color: #f87171; word-break: break-word; line-height: 1.5; }
.reasoning { font-size: 13px; color: #9ca3af; font-style: italic; line-height: 1.5; }
.score-bar-wrap { width: 60px; height: 3px; border-radius: 99px; background: #2a2d3a; overflow: hidden; flex-shrink: 0; margin-top: 8px; }
.score-bar { height: 100%; border-radius: 99px; }
footer { margin-top: 40px; text-align: center; font-size: 12px; color: #4b5563; }
"""


def _score_color(score: float, status: str = "") -> str:
    if status == "error":
        return "yellow"
    if score >= 0.85:
        return "green"
    if score >= 0.6:
        return "yellow"
    return "red"


def _checks_html(checks: list[CheckResult], hard_failed: bool) -> str:
    if not checks:
        return ""
    n_pass = sum(1 for c in checks if c.passed)
    label_extra = ' <span style="color:#ef4444">· hard fail</span>' if hard_failed else ""
    rows = []
    for c in checks:
        if c.passed:
            icon_cls, icon = "ok", "✓"
        elif c.hard_fail:
            icon_cls, icon = "fail", "✗"
        else:
            icon_cls, icon = "soft", "~"

        soft_badge = '<span class="check-badge">soft</span>' if not c.hard_fail else ""
        path_badge = (
            f'<span class="check-path">{_esc(c.error_path)}</span>' if c.error_path else ""
        )
        details_div = (
            f'<div class="check-details {"err" if not c.passed else ""}">{_esc(c.details)}</div>'
            if c.details
            else ""
        )
        rows.append(f"""
          <div class="check-row">
            <span class="check-icon {icon_cls}">{icon}</span>
            <div style="flex:1;min-width:0">
              <span class="check-name">{_esc(c.name)}</span>{soft_badge}{path_badge}
              {details_div}
            </div>
          </div>""")

    return f"""
        <div class="section">
          <div class="section-label">
            Deterministic · {n_pass}/{len(checks)} passed{label_extra}
          </div>
          {"".join(rows)}
        </div>"""


def _steps_html(result: ScenarioResult) -> str:
    if not result.steps:
        return ""
    rows = []
    for i, s in enumerate(result.steps):
        score = s.score if isinstance(s.score, float) else (1.0 if s.status == PassFail.PASS else 0.0)
        color = _score_color(score)
        color_val = {"green": "#22c55e", "yellow": "#eab308", "red": "#ef4444"}[color]
        rows.append(f"""
          <div class="step-row">
            <span class="step-dot" style="background:{color_val}"></span>
            <span class="step-idx">{str(i+1).zfill(2)}</span>
            <div class="step-body">
              <div class="step-action">{_esc(s.action)}</div>
              {f'<div class="step-verdict">{_esc(s.reasoning or s.actual_output)}</div>' if (s.reasoning or s.actual_output) else ''}
            </div>
            <div style="text-align:right">
              <div class="step-score" style="color:{color_val}">{round(score*100)}%</div>
              <div class="score-bar-wrap">
                <div class="score-bar" style="width:{round(score*100)}%;background:{color_val}"></div>
              </div>
            </div>
          </div>""")

    return f"""
        <div class="section">
          <div class="section-label">Judge · {len(result.steps)} steps</div>
          <div class="steps">{"".join(rows)}</div>
        </div>"""


def _scenario_html(r: ScenarioResult) -> str:
    color = _score_color(r.overall_score, r.status.value)
    status_badge_cls = "pass" if r.status == PassFail.PASS else ("fail" if r.status == PassFail.FAIL else "warn")
    icon = _status_icon(r.status.value)

    checks_section = _checks_html(r.check_results, r.hard_failed)

    error_section = ""
    if r.error:
        error_section = f"""
        <div class="section">
          <div class="section-label">Error</div>
          <div class="error-box">{_esc(r.error)}</div>
        </div>"""

    reasoning_section = ""
    if r.reasoning and r.status != PassFail.PASS:
        reasoning_section = f"""
        <div class="section">
          <div class="reasoning">{_esc(r.reasoning)}</div>
        </div>"""

    steps_section = _steps_html(r)

    return f"""
      <div class="scenario">
        <div class="scenario-header">
          <span class="badge {status_badge_cls}">{icon} {r.status.value.upper()}</span>
          <h2>{_esc(r.scenario_name)}</h2>
          <span class="tag">{_esc(r.agent_type.value)}</span>
          <span class="score-pill {color}">{_score_pct(r.overall_score)}</span>
        </div>
        {checks_section}
        {error_section}
        {reasoning_section}
        {steps_section}
      </div>"""


def _suite_html(suite: object | None) -> str:
    if suite is None:
        return ""
    s = suite  # type: ignore[assignment]
    icon = "✓" if s.passed else "✗"
    color = "#22c55e" if s.passed else "#ef4444"
    badge_cls = "pass" if s.passed else "fail"
    rows = [
        ("Semantic pass rate", f"{s.semantic_pass_rate:.0%}"),
        ("Hard-fail rate",     f"{s.hard_fail_rate:.0%}"),
        ("Soft-fail rate",     f"{s.soft_fail_rate:.0%}"),
        ("Weighted score",     f"{s.weighted_score:.2f}"),
    ]
    rows_html = "".join(
        f'<tr><td style="padding:5px 0;color:#9ca3af;font-size:12.5px">{k}</td>'
        f'<td style="padding:5px 0 5px 16px;font-size:12.5px;font-family:monospace;color:#e2e4e9">{v}</td></tr>'
        for k, v in rows
    )
    return f"""
  <div style="margin-bottom:16px;background:#1a1d27;border:1px solid #2a2d3a;border-radius:14px;padding:14px 18px">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
      <span style="font-size:11px;font-weight:600;color:#9ca3af;text-transform:uppercase;letter-spacing:.06em">Suite</span>
      <span class="badge {badge_cls}" style="font-size:12px">{icon} {_esc(s.suite_name)}</span>
      <span style="font-size:11px;color:#6b7280">threshold {s.pass_threshold:.0%}</span>
    </div>
    <table style="border-collapse:collapse">{rows_html}</table>
  </div>"""


def generate_html(
    results: list[ScenarioResult],
    passed: int,
    total: int,
    run_at: datetime,
    meta: dict | None = None,
) -> str:
    meta = meta or {}
    model = meta.get("model", "")
    pass_rate = passed / total if total else 0.0
    color = "green" if passed == total else ("yellow" if passed > 0 else "red")
    ts = run_at.strftime("%Y-%m-%d %H:%M UTC")
    scenarios_html = "\n".join(_scenario_html(r) for r in results)

    prov_items = []
    if model:
        prov_items.append(("model", model))
    if meta.get("version"):
        prov_items.append(("evalgrid", meta["version"]))
    if meta.get("git_sha"):
        prov_items.append(("git", meta["git_sha"]))
    prov_items.append(("timestamp", ts))
    prov_html = "  ·  ".join(
        f'<span style="color:#6b7280">{k}:</span> <code style="font-family:monospace;font-size:11px">{_esc(v)}</code>'
        for k, v in prov_items
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>evalgrid — {_esc(ts)}</title>
<style>{_CSS}</style>
</head>
<body>
<div class="wrap">
  <header>
    <h1>evalgrid</h1>
    <div class="meta" style="font-size:12px;color:#4b5563;margin-top:6px">{prov_html}</div>
    <div class="summary">
      <span class="pass-rate {color}">{passed}/{total}</span>
      <span class="badge {"pass" if passed==total else ("warn" if passed>0 else "fail")}">
        {round(pass_rate*100)}% passed
      </span>
    </div>
  </header>
  {_suite_html(meta.get("suite") if meta else None)}
  <div class="scenarios">
    {scenarios_html}
  </div>
  <footer>
    Generated by <a href="https://github.com/naman006-rai/evalgrid">evalgrid</a>
  </footer>
</div>
</body>
</html>
"""


# ── dispatch ─────────────────────────────────────────────────────────────────

def write_report(
    path: Path,
    results: list[ScenarioResult],
    passed: int,
    total: int,
    run_at: datetime,
    meta: dict | None = None,
) -> None:
    suffix = path.suffix.lower()
    if suffix in (".md", ".markdown"):
        content = generate_markdown(results, passed, total, run_at, meta)
    else:
        content = generate_html(results, passed, total, run_at, meta)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
