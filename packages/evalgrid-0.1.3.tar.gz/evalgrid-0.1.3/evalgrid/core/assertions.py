"""Deterministic assertion checker — structural checks that run before the LLM judge."""

from __future__ import annotations

import json
import re

import jsonschema

from .models import CheckConfig, CheckResult


class AssertionChecker:
    def run_checks(self, checks: list[CheckConfig], output: str) -> list[CheckResult]:
        return [self._run(c, output) for c in checks]

    def _run(self, check: CheckConfig, output: str) -> CheckResult:
        try:
            match check.type:
                case "valid_json":
                    return self._valid_json(check, output)
                case "no_markdown":
                    return self._no_markdown(check, output)
                case "required_fields":
                    return self._required_fields(check, output)
                case "enum":
                    return self._enum(check, output)
                case "forbidden_regex":
                    return self._forbidden_regex(check, output)
                case "contains":
                    return self._contains(check, output)
                case "max_length":
                    return self._max_length(check, output)
                case "json_schema":
                    return self._json_schema(check, output)
                case _:
                    return CheckResult(
                        name=check.type,
                        passed=False,
                        hard_fail=check.hard_fail,
                        details=f"Unknown check type: {check.type!r}",
                    )
        except Exception as exc:
            return CheckResult(
                name=check.type,
                passed=False,
                hard_fail=check.hard_fail,
                details=f"Check raised an exception: {exc}",
            )

    # ── individual checks ────────────────────────────────────────────────────

    def _valid_json(self, check: CheckConfig, output: str) -> CheckResult:
        try:
            json.loads(output.strip())
            return CheckResult(name="valid_json", passed=True, hard_fail=check.hard_fail)
        except json.JSONDecodeError as exc:
            return CheckResult(
                name="valid_json",
                passed=False,
                hard_fail=check.hard_fail,
                details=f"Invalid JSON: {exc.msg} at line {exc.lineno}",
            )

    def _no_markdown(self, check: CheckConfig, output: str) -> CheckResult:
        indicators = [
            (r"```", "fenced code block (```)"),
            (r"^#{1,6}\s", "markdown heading"),
            (r"^\*\*\S", "bold marker"),
        ]
        for pattern, label in indicators:
            if re.search(pattern, output, re.MULTILINE):
                return CheckResult(
                    name="no_markdown",
                    passed=False,
                    hard_fail=check.hard_fail,
                    details=f"Detected {label}",
                )
        return CheckResult(name="no_markdown", passed=True, hard_fail=check.hard_fail)

    def _required_fields(self, check: CheckConfig, output: str) -> CheckResult:
        try:
            data = json.loads(output.strip())
        except json.JSONDecodeError:
            return CheckResult(
                name="required_fields",
                passed=False,
                hard_fail=check.hard_fail,
                details="Output is not valid JSON — cannot check fields",
            )
        missing = [f for f in check.fields if f not in data]
        if missing:
            return CheckResult(
                name="required_fields",
                passed=False,
                hard_fail=check.hard_fail,
                details=f"Missing: {', '.join(missing)}",
            )
        return CheckResult(name="required_fields", passed=True, hard_fail=check.hard_fail)

    def _enum(self, check: CheckConfig, output: str) -> CheckResult:
        try:
            data = json.loads(output.strip())
        except json.JSONDecodeError:
            return CheckResult(
                name="enum",
                passed=False,
                hard_fail=check.hard_fail,
                details="Output is not valid JSON — cannot check enum",
            )
        val = data.get(check.field)
        if val not in check.allowed:
            return CheckResult(
                name="enum",
                passed=False,
                hard_fail=check.hard_fail,
                details=f"'{check.field}' = {val!r}, expected one of {check.allowed}",
            )
        return CheckResult(name="enum", passed=True, hard_fail=check.hard_fail)

    def _forbidden_regex(self, check: CheckConfig, output: str) -> CheckResult:
        m = re.search(check.pattern, output, re.IGNORECASE)
        if m:
            return CheckResult(
                name="forbidden_regex",
                passed=False,
                hard_fail=check.hard_fail,
                details=f"Forbidden pattern matched: {m.group()!r}",
            )
        return CheckResult(name="forbidden_regex", passed=True, hard_fail=check.hard_fail)

    def _contains(self, check: CheckConfig, output: str) -> CheckResult:
        if check.text.lower() in output.lower():
            return CheckResult(name="contains", passed=True, hard_fail=check.hard_fail)
        return CheckResult(
            name="contains",
            passed=False,
            hard_fail=check.hard_fail,
            details=f"Expected text not found: {check.text!r}",
        )

    def _max_length(self, check: CheckConfig, output: str) -> CheckResult:
        if len(output) <= check.value:
            return CheckResult(name="max_length", passed=True, hard_fail=check.hard_fail)
        return CheckResult(
            name="max_length",
            passed=False,
            hard_fail=check.hard_fail,
            details=f"Output length {len(output)} exceeds limit {check.value}",
        )

    def _json_schema(self, check: CheckConfig, output: str) -> CheckResult:
        if not check.schema_def:
            return CheckResult(
                name="json_schema",
                passed=False,
                hard_fail=check.hard_fail,
                details="No schema provided for json_schema check",
            )
        try:
            data = json.loads(output.strip())
        except json.JSONDecodeError as exc:
            return CheckResult(
                name="json_schema",
                passed=False,
                hard_fail=check.hard_fail,
                details=f"Invalid JSON: {exc.msg} at line {exc.lineno}",
            )
        schema = dict(check.schema_def)
        if check.strict and "additionalProperties" not in schema:
            schema["additionalProperties"] = False
        validator = jsonschema.Draft7Validator(schema)
        errors = sorted(validator.iter_errors(data), key=lambda e: list(e.path))
        if errors:
            first = errors[0]
            path = " → ".join(str(p) for p in first.absolute_path) or "(root)"
            return CheckResult(
                name="json_schema",
                passed=False,
                hard_fail=check.hard_fail,
                details=f"{path}: {first.message}",
                error_path=path,
            )
        return CheckResult(name="json_schema", passed=True, hard_fail=check.hard_fail)
