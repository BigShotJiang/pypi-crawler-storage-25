"""Scenario runner — executes scenarios and collects results."""

from __future__ import annotations

import asyncio
import os
import re
import time
from collections.abc import Callable
from datetime import UTC, datetime

import httpx
import litellm

from .assertions import AssertionChecker
from .models import EvalConfig, PassFail, Scenario, ScenarioResult
from .scorer import Scorer

litellm.suppress_debug_info = True

_API_KEY_RE = re.compile(r"(?:sk-ant-|sk-|pypi-)[A-Za-z0-9\-_]{6,}")

# Retryable transient failures from upstream model providers.
# InternalServerError covers Anthropic 5xx including the 529 overloaded_error,
# which we previously bailed on immediately.
_RETRYABLE_EXC = (
    litellm.exceptions.Timeout,
    litellm.exceptions.RateLimitError,
    litellm.exceptions.APIConnectionError,
    litellm.exceptions.InternalServerError,
    httpx.TimeoutException,
)

AgentFn = Callable[["Scenario"], tuple[str, int]]


def extract_usage_cost(response) -> tuple[int, int, float]:
    """Pull token counts and USD cost from a LiteLLM completion response.

    Defensive: never raises. Returns (0, 0, 0.0) when usage or pricing is unavailable
    for the model (common with local/Ollama and some OpenRouter routes).
    """
    pt = 0
    ct = 0
    cost = 0.0
    try:
        usage = getattr(response, "usage", None)
        if usage is not None:
            pt = int(getattr(usage, "prompt_tokens", 0) or 0)
            ct = int(getattr(usage, "completion_tokens", 0) or 0)
    except Exception:
        pass
    try:
        cost = float(litellm.completion_cost(completion_response=response) or 0.0)
    except Exception:
        cost = 0.0
    return pt, ct, cost


class ScenarioRunner:
    def __init__(
        self,
        config: EvalConfig,
        scorer: Scorer | None = None,
        agent_fn: AgentFn | None = None,
        mock: bool = False,
    ) -> None:
        self.config = config
        self.scorer = scorer if scorer is not None else Scorer(config)
        self._agent_fn = agent_fn
        self._checker = AssertionChecker()
        self._mock = mock

    def _run_agent(self, scenario: Scenario) -> tuple[str, int, int, int, float]:
        """Run the agent and return (output, latency_ms, prompt_tokens, completion_tokens, cost_usd).

        Custom agent_fn injections (mock path) get zero usage/cost — they don't call LiteLLM.
        """
        if self._agent_fn is not None:
            output, latency = self._agent_fn(scenario)
            return output, latency, 0, 0, 0.0

        api_key = self.config.judge.api_key or (
            os.environ.get(self.config.judge.api_key_env) if self.config.judge.api_key_env else None
        )

        max_attempts = (self.config.max_retries + 1) if self.config.retry_on_error else 1
        last_exc: Exception | None = None
        for attempt in range(max_attempts):
            if attempt > 0:
                time.sleep(2 ** attempt)
            try:
                start = time.perf_counter()
                response = litellm.completion(
                    model=self.config.model,
                    max_tokens=4096,
                    messages=[
                        {"role": "system", "content": scenario.prompt},
                        {"role": "user", "content": scenario.test_input},
                    ],
                    api_key=api_key,
                    timeout=self.config.timeout_seconds,
                )
                latency_ms = int((time.perf_counter() - start) * 1000)
                pt, ct, cost = extract_usage_cost(response)
                return response.choices[0].message.content, latency_ms, pt, ct, cost
            except _RETRYABLE_EXC as e:
                last_exc = e
            except Exception:
                raise
        raise last_exc  # type: ignore[misc]

    def run_scenario(self, scenario: Scenario) -> ScenarioResult:
        result = ScenarioResult(
            scenario_id=scenario.id,
            scenario_name=scenario.name,
            agent_type=scenario.agent_type,
            status=PassFail.ERROR,
            started_at=datetime.now(UTC),
        )
        try:
            actual_output, latency_ms, agent_pt, agent_ct, agent_cost = self._run_agent(scenario)

            # Deterministic assertions — skipped in mock mode (mock output is a placeholder)
            check_results = [] if self._mock else self._checker.run_checks(scenario.checks, actual_output)
            hard_failed = any(not c.passed and c.hard_fail for c in check_results)

            if hard_failed:
                failed_names = ", ".join(c.name for c in check_results if not c.passed and c.hard_fail)
                result.status = PassFail.FAIL
                result.check_results = check_results
                result.hard_failed = True
                result.reasoning = f"Hard assertion failed: {failed_names}"
                result.prompt_tokens = agent_pt
                result.completion_tokens = agent_ct
                result.cost_usd = agent_cost
                result.finished_at = datetime.now(UTC)
                return result

            # Semantic judge — only reached when no hard assertions failed
            scored = self.scorer.score(scenario, actual_output, latency_ms)
            scored.started_at = result.started_at
            scored.finished_at = datetime.now(UTC)
            scored.check_results = check_results
            scored.prompt_tokens += agent_pt
            scored.completion_tokens += agent_ct
            scored.cost_usd += agent_cost
            return scored
        except Exception as e:
            result.error = _API_KEY_RE.sub("[REDACTED]", str(e))
            result.finished_at = datetime.now(UTC)
            return result

    def run_all(
        self,
        scenarios: list[Scenario],
        on_result: Callable[[ScenarioResult], None] | None = None,
    ) -> list[ScenarioResult]:
        results = []
        for scenario in scenarios:
            result = self.run_scenario(scenario)
            results.append(result)
            if on_result:
                on_result(result)
        return results

    async def run_all_async(
        self,
        scenarios: list[Scenario],
        on_result: Callable[[ScenarioResult], None] | None = None,
    ) -> list[ScenarioResult]:
        sem = asyncio.Semaphore(self.config.max_concurrent)

        async def _run(scenario: Scenario) -> ScenarioResult:
            async with sem:
                loop = asyncio.get_running_loop()
                result = await loop.run_in_executor(None, self.run_scenario, scenario)
                if on_result:
                    on_result(result)
                return result

        tasks = [_run(s) for s in scenarios]
        return await asyncio.gather(*tasks)
