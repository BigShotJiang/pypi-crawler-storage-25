"""Suite loader — reads named benchmark suite definitions from YAML."""

from __future__ import annotations

import logging
from pathlib import Path

import yaml

from .models import Scenario, ScenarioResult, SuiteConfig, SuiteResult

logger = logging.getLogger("evalgrid")


class SuiteLoader:
    def load_file(self, path: Path) -> SuiteConfig:
        with open(path) as f:
            data = yaml.safe_load(f) or {}
        return SuiteConfig(
            id=data.get("id", path.stem),
            name=data.get("name", path.stem),
            description=data.get("description", ""),
            version=int(data.get("version", 1)),
            scenarios=data.get("scenarios", []),
            tags=data.get("tags", []),
            pass_threshold=float(data.get("pass_threshold", 1.0)),
        )

    def load_dir(self, directory: Path) -> list[SuiteConfig]:
        suites = []
        for path in sorted(directory.glob("*.yml")) + sorted(directory.glob("*.yaml")):
            if path.name.startswith("_"):
                continue
            try:
                suites.append(self.load_file(path))
            except Exception as exc:
                logger.warning("Failed to load suite %s: %s", path, exc)
        return suites

    def filter_scenarios(
        self, suite: SuiteConfig, scenarios: list[Scenario]
    ) -> list[Scenario]:
        """Return only scenarios that belong to this suite."""
        if suite.scenarios:
            id_set = set(suite.scenarios)
            return [s for s in scenarios if s.id in id_set]
        if suite.tags:
            tag_set = set(suite.tags)
            return [s for s in scenarios if tag_set & set(s.tags)]
        return scenarios


def compute_suite_result(
    suite: SuiteConfig,
    results: list[ScenarioResult],
    scenarios: list[Scenario],
) -> SuiteResult:
    total = len(results)
    if total == 0:
        return SuiteResult(
            suite_id=suite.id,
            suite_name=suite.name,
            pass_threshold=suite.pass_threshold,
            total=0,
            semantic_pass_rate=0.0,
            hard_fail_rate=0.0,
            soft_fail_rate=0.0,
            error_rate=0.0,
            weighted_score=0.0,
            passed=False,
        )

    from .models import PassFail

    n_semantic_pass = sum(1 for r in results if r.status == PassFail.PASS)
    n_hard_fail = sum(1 for r in results if r.hard_failed)
    n_soft_fail = sum(1 for r in results if r.status == PassFail.FAIL and not r.hard_failed)
    n_error = sum(1 for r in results if r.status == PassFail.ERROR)

    # Weighted score — matched by scenario id order; fall back to 1.0 weight if not found
    weight_map = {s.id: s.weight for s in scenarios}
    pairs = [(r, weight_map.get(r.scenario_id, 1.0)) for r in results]
    total_weight = sum(w for _, w in pairs)
    weighted_score = (
        sum(r.overall_score * w for r, w in pairs) / total_weight
        if total_weight > 0 else 0.0
    )

    semantic_pass_rate = n_semantic_pass / total
    return SuiteResult(
        suite_id=suite.id,
        suite_name=suite.name,
        pass_threshold=suite.pass_threshold,
        total=total,
        semantic_pass_rate=semantic_pass_rate,
        hard_fail_rate=n_hard_fail / total,
        soft_fail_rate=n_soft_fail / total,
        error_rate=n_error / total,
        weighted_score=weighted_score,
        passed=semantic_pass_rate >= suite.pass_threshold,
    )
