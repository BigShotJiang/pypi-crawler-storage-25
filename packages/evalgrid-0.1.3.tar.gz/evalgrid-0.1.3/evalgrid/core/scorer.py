"""LiteLLM-powered scenario scorer — supports any provider."""

from __future__ import annotations

import json
import os
import time

import httpx
import litellm

from .models import EvalConfig, PassFail, Scenario, ScenarioResult, StepResult

litellm.suppress_debug_info = True

# Retryable transient failures — keep in sync with runner._RETRYABLE_EXC.
_RETRYABLE_EXC = (
    litellm.exceptions.Timeout,
    litellm.exceptions.RateLimitError,
    litellm.exceptions.APIConnectionError,
    litellm.exceptions.InternalServerError,
    httpx.TimeoutException,
)

SCORING_PROMPT = """\
You are an expert AI agent evaluator. Your task is to evaluate whether an AI agent's response
correctly follows a scenario's expected actions and meets the success criteria.

## Scenario
Name: {scenario_name}
Description: {description}
Agent Type: {agent_type}

## Test Input
{test_input}

## Agent Prompt
{prompt}

## Expected Actions
{expected_actions}

## Success Criteria
{success_criteria}

## Agent's Actual Response
{actual_output}

## Instructions
Evaluate each expected action and the overall response. For each step:
1. Determine if the action was performed correctly (pass/fail)
2. Assign a score from 0.0 to 1.0
3. Provide brief reasoning

Return a JSON object with this exact structure:
{{
  "overall_score": <float 0.0-1.0>,
  "overall_status": "pass" | "fail",
  "reasoning": "<overall evaluation reasoning>",
  "steps": [
    {{
      "step_index": <int>,
      "action": "<what the agent did>",
      "expected_action": "<what was expected>",
      "status": "pass" | "fail" | "skip",
      "score": <float 0.0-1.0>,
      "reasoning": "<step-level reasoning>"
    }}
  ]
}}

Be strict but fair. A "pass" requires the agent to have substantially met the expected action.
"""


class Scorer:
    def __init__(self, config: EvalConfig) -> None:
        self.config = config

    def score(self, scenario: Scenario, actual_output: str, latency_ms: int = 0) -> ScenarioResult:
        expected_actions_text = "\n".join(
            f"{i + 1}. {ea.action}"
            + (f" (params: {ea.params})" if ea.params else "")
            + (" [required]" if ea.required else " [optional]")
            + (f" — {ea.description}" if ea.description else "")
            for i, ea in enumerate(scenario.expected_actions)
        ) or "No specific actions required — evaluate based on success criteria."

        prompt = SCORING_PROMPT.format(
            scenario_name=scenario.name,
            description=scenario.description,
            agent_type=scenario.agent_type.value,
            test_input=scenario.test_input,
            prompt=scenario.prompt,
            expected_actions=expected_actions_text,
            success_criteria=scenario.success_criteria or "Follow expected actions accurately.",
            actual_output=actual_output,
        )

        api_key = self.config.judge.api_key or (
            os.environ.get(self.config.judge.api_key_env) if self.config.judge.api_key_env else None
        )

        max_attempts = (self.config.max_retries + 1) if self.config.retry_on_error else 1
        response = None
        last_exc: Exception | None = None
        for attempt in range(max_attempts):
            if attempt > 0:
                time.sleep(2 ** attempt)
            try:
                response = litellm.completion(
                    model=self.config.judge.model,
                    max_tokens=2048,
                    messages=[
                        {
                            "role": "system",
                            "content": (
                                "You are an expert AI agent evaluator. "
                                "Always respond with valid JSON only."
                            ),
                        },
                        {"role": "user", "content": prompt},
                    ],
                    api_key=api_key,
                    timeout=self.config.timeout_seconds,
                )
                break
            except _RETRYABLE_EXC as e:
                last_exc = e
            except Exception:
                raise
        if response is None:
            raise last_exc  # type: ignore[misc]

        from .runner import extract_usage_cost
        judge_pt, judge_ct, judge_cost = extract_usage_cost(response)

        raw = response.choices[0].message.content.strip()
        # Strip optional ```json ... ``` or ``` ... ``` fences
        if raw.startswith("```"):
            raw = raw[raw.index("\n") + 1 :]
            if raw.endswith("```"):
                raw = raw[: raw.rfind("```")]
        try:
            data = json.loads(raw.strip())
        except json.JSONDecodeError:
            return ScenarioResult(
                scenario_id=scenario.id,
                scenario_name=scenario.name,
                agent_type=scenario.agent_type,
                status=PassFail.ERROR,
                error=f"Judge returned non-JSON output: {raw[:200]}",
                prompt_tokens=judge_pt,
                completion_tokens=judge_ct,
                cost_usd=judge_cost,
            )

        steps = []
        for i, s in enumerate(data.get("steps", [])):
            try:
                status = PassFail(s.get("status", "fail"))
            except ValueError:
                status = PassFail.FAIL
            try:
                step_index = int(s.get("step_index", i))
            except (ValueError, TypeError):
                step_index = i
            try:
                score = max(0.0, min(1.0, float(s.get("score", 0.0))))
            except (ValueError, TypeError):
                score = 0.0
            steps.append(StepResult(
                step_index=step_index,
                action=s.get("action", ""),
                expected_action=s.get("expected_action"),
                status=status,
                score=score,
                reasoning=s.get("reasoning", ""),
                actual_output=actual_output if step_index == 0 else "",
                latency_ms=latency_ms if step_index == 0 else 0,
            ))

        pass_count = sum(1 for s in steps if s.status == PassFail.PASS)
        pass_rate = pass_count / len(steps) if steps else 0.0
        try:
            overall_status = PassFail(data.get("overall_status", "fail"))
        except ValueError:
            overall_status = PassFail.FAIL

        return ScenarioResult(
            scenario_id=scenario.id,
            scenario_name=scenario.name,
            agent_type=scenario.agent_type,
            status=overall_status,
            overall_score=float(data.get("overall_score", 0.0)),
            steps=steps,
            pass_rate=pass_rate,
            reasoning=data.get("reasoning", ""),
            prompt_tokens=judge_pt,
            completion_tokens=judge_ct,
            cost_usd=judge_cost,
        )


class MockScorer(Scorer):
    """Deterministic scorer for testing — no API calls."""

    def __init__(self) -> None:  # no config required
        pass

    def score(self, scenario: Scenario, actual_output: str, latency_ms: int = 0) -> ScenarioResult:
        steps = [
            StepResult(
                step_index=i,
                action=ea.action,
                expected_action=ea.action,
                status=PassFail.PASS,
                score=1.0,
                reasoning="Mock pass",
                latency_ms=latency_ms if i == 0 else 0,
            )
            for i, ea in enumerate(scenario.expected_actions)
        ]
        return ScenarioResult(
            scenario_id=scenario.id,
            scenario_name=scenario.name,
            agent_type=scenario.agent_type,
            status=PassFail.PASS,
            overall_score=1.0,
            steps=steps,
            pass_rate=1.0,
            reasoning="Mock scorer — all steps pass",
        )
