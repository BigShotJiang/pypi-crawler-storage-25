"""FastAPI application — eval runner + results API."""

from __future__ import annotations

import asyncio
import logging
import os
import re
import uuid
import warnings
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator, model_validator
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.types import Scope

from evalgrid.core import EvalConfig, ScenarioLoader, SuiteLoader
from evalgrid.core.models import PassFail
from evalgrid.core.paths import resolve_scenarios_dir, resolve_suites_dir
from evalgrid.core.runner import ScenarioRunner

from .database import RunRecord, ScenarioResultRecord, SuiteResultRecord, get_db, init_db

logger = logging.getLogger("evalgrid")


# ── Path resolution ────────────────────────────────────────────────────────────
# Indirected through a function so tests can monkeypatch a single attribute and
# the CLI/server see the same resolution at every call site.
def _scenarios_base_dir() -> Path:
    """Module-level shim around :func:`resolve_scenarios_dir` for monkeypatching."""
    return resolve_scenarios_dir()


def _suites_base_dir() -> Path:
    return resolve_suites_dir()


_API_KEY_RE = re.compile(
    r"(?:sk-ant-|sk-|pypi-)[A-Za-z0-9\-_]{6,}"
    r"|AIza[A-Za-z0-9\-_]{30,}"
)


def _sanitize_error(msg: str) -> str:
    return _API_KEY_RE.sub("[REDACTED]", msg)


def _iso(dt: datetime | None) -> str | None:
    """Return ISO-8601 string with explicit UTC offset so browsers parse it correctly."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.isoformat()


def _extract_run_error(record: RunRecord) -> str | None:
    """Pull a top-level error string off RunRecord.results, if any."""
    results = record.results or []
    if isinstance(results, list) and len(results) == 1 and isinstance(results[0], dict):
        err = results[0].get("error")
        if isinstance(err, str) and err:
            return err
    return None


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:  # noqa: ARG001
    await init_db()

    # Mark any runs that were left running (server restart) as failed
    from .database import SessionLocal
    try:
        async with SessionLocal() as db:
            stale_rows = await db.execute(
                select(RunRecord).where(RunRecord.finished_at.is_(None))
            )
            stale = stale_rows.scalars().all()
            for record in stale:
                record.finished_at = datetime.now(UTC)
                record.total = record.total or 0
                record.passed = record.passed or 0
                record.pass_rate = 0.0
                record.results = [{"error": "Server restarted"}]
            if stale:
                # One aggregated line per server start instead of one per run —
                # otherwise a few crashed sessions later this is a wall of
                # warnings that drowns out anything actually interesting.
                sample = ", ".join(r.run_id[:8] for r in stale[:3])
                more = f" (+{len(stale) - 3} more)" if len(stale) > 3 else ""
                logger.warning(
                    "Marked %d stale run(s) as failed on startup: %s%s",
                    len(stale), sample, more,
                )
                await db.commit()
    except Exception as exc:
        logger.warning("Stale run cleanup skipped: %s", exc)

    yield


app = FastAPI(title="evalgrid API", version="0.1.3", lifespan=lifespan)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.error("Unhandled exception on %s: %s", request.url.path, exc)
    sanitized = _sanitize_error(str(exc))
    return JSONResponse(status_code=500, content={"detail": f"Internal server error: {sanitized}"})


app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:5173",
        "http://localhost:8000",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:8000",
    ],
    allow_methods=["*"],
    allow_headers=["*"],
)


# 1 MB body cap on writes. Prompts/test_inputs already have field-level Pydantic
# caps but expected_actions / checks / suite scenarios lists were uncapped —
# protects against accidental multi-MB POSTs eating memory before validation.
_MAX_BODY_BYTES = 1 * 1024 * 1024


@app.middleware("http")
async def body_size_guard(request: Request, call_next):
    if request.method in ("POST", "PUT", "PATCH"):
        cl = request.headers.get("content-length")
        if cl and cl.isdigit() and int(cl) > _MAX_BODY_BYTES:
            return JSONResponse(
                {"detail": f"Request body exceeds {_MAX_BODY_BYTES} bytes"},
                status_code=413,
            )
    return await call_next(request)


# Conservative CSP: same-origin everything, plus 'unsafe-inline' for the
# Next.js inline runtime script. data: for icons. Acceptable defense-in-depth
# for a localhost-only app; can tighten with nonces later if it ever moves
# behind a reverse proxy.
@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: blob:; "
        "font-src 'self' data:; "
        "connect-src 'self'; "
        "frame-ancestors 'none'",
    )
    return response


# ── Schema ────────────────────────────────────────────────────────────────────

class RunRequest(BaseModel):
    scenarios_dir: str = ""
    tags: list[str] = []
    scenario_ids: list[str] = []
    suite: str | None = None
    mock: bool = False
    agent_model: str | None = None
    judge_model: str | None = None
    api_key: str | None = None

    @model_validator(mode="after")
    def _require_target(self) -> "RunRequest":
        """A run must specify at least one target: scenarios, suite, tag, or mock mode."""
        if not (self.scenario_ids or self.tags or self.suite or self.mock):
            raise ValueError(
                "Must specify scenarios, suite, tag, or mock mode"
            )
        return self


class RunSummary(BaseModel):
    run_id: str
    started_at: str
    finished_at: str | None = None
    pass_rate: float
    passed: int
    total: int
    status: str
    scenario_names: list[str] = []
    skipped_count: int = 0
    skipped_scenarios: list[dict[str, str]] = []


# Slug pattern shared by scenario + suite ids. Conservative on purpose — these
# values land in filesystem paths and YAML field references, so we reject
# anything that needs escaping. Path traversal segments (`..`) and any
# separator (`/`, `\`) are rejected by the regex; whitespace too.
_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,127}$")

# Windows reserved filenames. Creating a YAML for any of these crashes on
# Windows with "file in use by another process" — surface as a clean 422.
_WINDOWS_RESERVED = frozenset({
    "con", "prn", "aux", "nul",
    *(f"com{i}" for i in range(1, 10)),
    *(f"lpt{i}" for i in range(1, 10)),
})


def _validate_slug(value: str, field: str) -> str:
    """Return the value if it's a clean kebab-case slug, else raise ValueError.

    Used by Pydantic field validators on ScenarioCreate.id and SuiteCreate.id.
    """
    if not value:
        raise ValueError(f"{field} is required")
    if value in {".", ".."} or ".." in value or "/" in value or "\\" in value:
        raise ValueError(
            f"{field} contains path separators or traversal — use letters, "
            f"numbers and hyphens only"
        )
    if not _SLUG_RE.match(value):
        raise ValueError(
            f"{field} must match {_SLUG_RE.pattern} (lowercase letters, "
            f"numbers and hyphens; must start with a letter or digit)"
        )
    if value in _WINDOWS_RESERVED:
        raise ValueError(
            f"{field}={value!r} is a Windows reserved filename (CON/PRN/AUX/"
            "NUL/COM[1-9]/LPT[1-9]) — pick a different id"
        )
    return value


class ScenarioCreate(BaseModel):
    """Create payload for `POST /api/scenarios` — id is explicit, not derived.

    The pre-v0.1.3-patch version derived id from name by slugifying. That made
    it impossible to create two scenarios with the same name and impossible to
    pre-decide an id from the UI. The new contract takes id explicitly.
    """

    id: str = Field(..., max_length=128)
    name: str = Field(..., max_length=200, min_length=1)
    description: str = Field(default="", max_length=1000)
    agent_type: str = "generic"
    prompt: str = Field(..., max_length=16000, min_length=1)
    test_input: str = Field(default="", max_length=8000)
    expected_actions: list[dict[str, Any]] = Field(default_factory=list)
    checks: list[dict[str, Any]] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    scenarios_dir: str = ""

    @field_validator("id")
    @classmethod
    def _id_must_be_slug(cls, v: str) -> str:
        return _validate_slug(v, "id")

    @field_validator("prompt")
    @classmethod
    def _prompt_must_not_be_blank(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("prompt must not be blank")
        return v


class SuiteCreate(BaseModel):
    """Create payload for `POST /api/suites`."""

    id: str = Field(..., max_length=128)
    name: str = Field(..., max_length=200, min_length=1)
    description: str = Field(default="", max_length=1000)
    scenarios: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    pass_threshold: float = Field(default=1.0, ge=0.0, le=1.0)

    @field_validator("id")
    @classmethod
    def _id_must_be_slug(cls, v: str) -> str:
        return _validate_slug(v, "id")

    @field_validator("scenarios")
    @classmethod
    def _scenarios_must_not_be_empty(cls, v: list[str]) -> list[str]:
        if not v:
            raise ValueError("scenarios must contain at least one scenario id")
        return v


def _validate_path(scenarios_dir: str) -> Path:
    """Resolve and validate that the path stays within the resolved scenarios base."""
    _base = _scenarios_base_dir().resolve()
    if ".." in scenarios_dir:
        raise HTTPException(status_code=400, detail="Path outside allowed scenarios directory")
    resolved = (_base / scenarios_dir).resolve()
    if not resolved.is_relative_to(_base):
        raise HTTPException(status_code=400, detail="Path outside allowed scenarios directory")
    return resolved


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health(db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    """Liveness + readiness in one. Returns version, DB round-trip status,
    and whether the scenarios dir resolves to something that exists. Useful
    for `curl http://localhost:8000/health` ops debugging vs a bare 'ok'.
    """
    db_ok = True
    try:
        await db.execute(select(1))
    except Exception as exc:
        logger.warning("Health check DB ping failed: %s", exc)
        db_ok = False

    scen_dir = _scenarios_base_dir()
    suites_dir = _suites_base_dir()
    return {
        "status": "ok" if db_ok else "degraded",
        "version": app.version,
        "db": "ok" if db_ok else "error",
        "scenarios_dir": str(scen_dir),
        "scenarios_dir_exists": scen_dir.exists(),
        "suites_dir": str(suites_dir),
        "suites_dir_exists": suites_dir.exists(),
    }


@app.get("/api/flakiness")
async def get_flakiness(
    window: int = 10,
    db: AsyncSession = Depends(get_db),
) -> list[dict[str, Any]]:
    """Scenario stability across the last `window` runs per scenario."""
    id_rows = await db.execute(
        select(
            ScenarioResultRecord.scenario_id,
            ScenarioResultRecord.scenario_name,
        ).distinct()
    )
    scenarios = id_rows.all()

    result = []
    for sid, sname in scenarios:
        hist = await db.execute(
            select(ScenarioResultRecord.status)
            .where(ScenarioResultRecord.scenario_id == sid)
            .order_by(ScenarioResultRecord.id.desc())
            .limit(window)
        )
        statuses = [r[0] for r in hist.all()]
        if not statuses:
            continue
        run_count = len(statuses)
        pass_count = sum(1 for s in statuses if s == "pass")
        fail_count = sum(1 for s in statuses if s == "fail")
        error_count = sum(1 for s in statuses if s == "error")
        pass_rate = pass_count / run_count if run_count else 0.0
        flakiness_score = 1.0 - abs(2 * pass_rate - 1.0)
        result.append({
            "scenario_id": sid,
            "scenario_name": sname,
            "run_count": run_count,
            "pass_count": pass_count,
            "fail_count": fail_count,
            "error_count": error_count,
            "pass_rate": pass_rate,
            "flakiness_score": flakiness_score,
            "is_flaky": 0.0 < pass_rate < 1.0,
            "last_status": statuses[0],
        })

    result.sort(key=lambda x: -x["flakiness_score"])
    return result


@app.get("/api/config-status")
async def config_status() -> dict[str, Any]:
    anthropic_set = bool(os.environ.get("ANTHROPIC_API_KEY"))
    openai_set = bool(os.environ.get("OPENAI_API_KEY"))
    return {
        "anthropic_key_set": anthropic_set,
        "openai_key_set": openai_set,
        "any_key_set": anthropic_set or openai_set,
        "mock_available": True,
    }


class KeyUpdate(BaseModel):
    """In-memory key update body. Both fields optional — pass only what you want to set."""

    anthropic_api_key: str | None = Field(default=None, alias="ANTHROPIC_API_KEY", max_length=512)
    openai_api_key: str | None = Field(default=None, alias="OPENAI_API_KEY", max_length=512)

    # populate_by_name lets us accept either alias or python name; extra=forbid
    # means a typo like POSTHOG_API_KEY returns 422 instead of silently no-op.
    model_config = {"populate_by_name": True, "extra": "forbid"}


@app.post("/api/config/keys")
async def set_config_keys(req: KeyUpdate) -> dict[str, Any]:
    """Set provider API keys in this server's process memory.

    Keys are written to ``os.environ`` for the current Python process only.
    Nothing is persisted to disk; on server restart they're gone. Existing
    consumers of these env vars (litellm via the runner/scorer) pick them up
    on the next call.

    **Security**: this endpoint accepts secrets over HTTP. Only safe behind a
    localhost-only bind. There is no auth and there will not be — multi-user
    secret management is deferred to v0.2+. Empty strings are treated as
    "no update" rather than "clear" to avoid clobbering an env-provided value
    by accident.
    """
    updated: list[str] = []
    if req.anthropic_api_key:
        os.environ["ANTHROPIC_API_KEY"] = req.anthropic_api_key
        updated.append("ANTHROPIC_API_KEY")
    if req.openai_api_key:
        os.environ["OPENAI_API_KEY"] = req.openai_api_key
        updated.append("OPENAI_API_KEY")
    return {
        "updated": updated,
        "anthropic_key_set": bool(os.environ.get("ANTHROPIC_API_KEY")),
        "openai_key_set": bool(os.environ.get("OPENAI_API_KEY")),
    }


def _resolve_scenarios_for_request(req: "RunRequest", scen_dir: Path) -> list:
    """Apply the request's suite/tag/scenario_ids filters to scenarios on disk.

    Returns the filtered scenario list. Raises HTTPException(422) if a referenced
    suite is missing — that's a user error, not a server error. Returning [] is
    valid here; callers decide whether empty is acceptable (e.g. a UI preview
    might allow it, but `POST /api/runs` rejects it).
    """
    if not scen_dir.exists():
        raise HTTPException(
            status_code=422,
            detail=f"Scenarios directory not found: {scen_dir}",
        )
    loader = ScenarioLoader()
    scenarios = loader.load_dir(scen_dir)

    if req.suite:
        suites_dir = _suites_base_dir()
        suite_path = suites_dir / f"{req.suite}.yml"
        if not suite_path.exists():
            suite_path = suites_dir / f"{req.suite}.yaml"
        if not suite_path.exists():
            raise HTTPException(
                status_code=422,
                detail=f"Suite '{req.suite}' not found in {suites_dir}",
            )
        suite = SuiteLoader().load_file(suite_path)
        scenarios = SuiteLoader().filter_scenarios(suite, scenarios)

    if req.tags:
        scenarios = [s for s in scenarios if any(t in s.tags for t in req.tags)]
    if req.scenario_ids:
        scenarios = [s for s in scenarios if s.id in req.scenario_ids]

    return scenarios


@app.post("/api/runs", response_model=RunSummary)
async def create_run(
    req: RunRequest,
    background: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
) -> RunSummary:
    _validate_path(req.scenarios_dir)

    if not req.mock and not req.api_key and not any(
        os.environ.get(k) for k in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY")
    ):
        raise HTTPException(
            status_code=400,
            detail=(
                "No provider API key found in environment "
                "(set ANTHROPIC_API_KEY or OPENAI_API_KEY)"
            ),
        )

    # Resolve scenarios upfront — fail with 422 if the filter matches nothing,
    # so we never create an empty run row. We pass the resolved list into the
    # background task so it doesn't re-parse every YAML from disk a second
    # time (was O(scenarios) duplicate IO per request).
    scen_dir = (_scenarios_base_dir().resolve() / req.scenarios_dir).resolve()
    resolved = _resolve_scenarios_for_request(req, scen_dir)
    if not resolved:
        raise HTTPException(
            status_code=422,
            detail="No scenarios matched the filter (check tag/suite/scenario_ids)",
        )

    run_id = str(uuid.uuid4())
    record = RunRecord(
        run_id=run_id,
        started_at=datetime.now(UTC),
        results=[],
    )
    db.add(record)
    await db.commit()

    background.add_task(_execute_run, run_id, req, resolved)

    return RunSummary(
        run_id=run_id,
        started_at=_iso(record.started_at) or "",
        pass_rate=0.0,
        passed=0,
        total=0,
        status="running",
    )


@app.get("/api/runs", response_model=list[RunSummary])
async def list_runs(db: AsyncSession = Depends(get_db)) -> list[RunSummary]:
    rows = await db.execute(select(RunRecord).order_by(RunRecord.started_at.desc()).limit(100))
    records = rows.scalars().all()

    run_ids = [r.run_id for r in records]
    name_rows = await db.execute(
        select(ScenarioResultRecord.run_id, ScenarioResultRecord.scenario_name)
        .where(ScenarioResultRecord.run_id.in_(run_ids))
    )
    names_by_run: dict[str, list[str]] = {}
    for run_id, scenario_name in name_rows:
        names_by_run.setdefault(run_id, []).append(scenario_name)

    return [
        RunSummary(
            run_id=r.run_id,
            started_at=_iso(r.started_at) or "",
            finished_at=_iso(r.finished_at),
            pass_rate=r.pass_rate or 0.0,
            passed=r.passed or 0,
            total=r.total or 0,
            status="completed" if r.finished_at else "running",
            scenario_names=names_by_run.get(r.run_id, []),
            skipped_count=len(r.skipped_scenarios or []),
            skipped_scenarios=r.skipped_scenarios or [],
        )
        for r in records
    ]


# IMPORTANT: /api/runs/compare must be declared BEFORE /api/runs/{run_id}.
# FastAPI matches routes in declaration order, so the dynamic {run_id} segment
# would otherwise shadow the literal "compare" path.

@app.get("/api/runs/compare")
async def compare_runs(
    base: str,
    head: str,
    db: AsyncSession = Depends(get_db),
) -> dict[str, Any]:
    """Diff two runs at scenario level. Returns per-scenario verdicts and a summary."""
    base_rows = await db.execute(
        select(ScenarioResultRecord).where(ScenarioResultRecord.run_id == base)
    )
    head_rows = await db.execute(
        select(ScenarioResultRecord).where(ScenarioResultRecord.run_id == head)
    )
    base_results = {r.scenario_id: r for r in base_rows.scalars().all()}
    head_results = {r.scenario_id: r for r in head_rows.scalars().all()}

    if not base_results and not head_results:
        raise HTTPException(status_code=404, detail="No scenario results found for one or both runs")

    base_run_row = await db.execute(select(RunRecord).where(RunRecord.run_id == base))
    head_run_row = await db.execute(select(RunRecord).where(RunRecord.run_id == head))
    base_run = base_run_row.scalar_one_or_none()
    head_run = head_run_row.scalar_one_or_none()

    all_ids = set(base_results) | set(head_results)
    scenarios = []
    for sid in all_ids:
        b = base_results.get(sid)
        h = head_results.get(sid)
        b_status = b.status if b else None
        h_status = h.status if h else None
        b_score = b.overall_score if b else None
        h_score = h.overall_score if h else None
        delta = (h_score - b_score) if (h_score is not None and b_score is not None) else None

        if b is None:
            verdict = "new"
        elif h is None:
            verdict = "removed"
        elif b_status == "pass" and h_status != "pass":
            verdict = "new_fail"
        elif b_status != "pass" and h_status == "pass":
            verdict = "resolved"
        elif b_status == "pass" and h_status == "pass":
            verdict = "regressed" if (delta is not None and delta < -0.15) else "stable_pass"
        else:
            verdict = "stable_fail"

        scenarios.append({
            "scenario_id": sid,
            "scenario_name": (h or b).scenario_name,  # type: ignore[union-attr]
            "base_status": b_status,
            "head_status": h_status,
            "base_score": b_score,
            "head_score": h_score,
            "score_delta": delta,
            "verdict": verdict,
        })

    _verdict_order = {
        "new_fail": 0, "stable_fail": 1, "regressed": 2, "resolved": 3,
        "stable_pass": 4, "new": 5, "removed": 6,
    }
    scenarios.sort(key=lambda s: (_verdict_order.get(s["verdict"], 9), s["scenario_name"]))

    summary = {
        "new_failures": sum(1 for s in scenarios if s["verdict"] == "new_fail"),
        "resolved": sum(1 for s in scenarios if s["verdict"] == "resolved"),
        "regressions": sum(1 for s in scenarios if s["verdict"] == "regressed"),
        "stable_pass": sum(1 for s in scenarios if s["verdict"] == "stable_pass"),
        "stable_fail": sum(1 for s in scenarios if s["verdict"] == "stable_fail"),
        "new_scenarios": sum(1 for s in scenarios if s["verdict"] == "new"),
        "removed_scenarios": sum(1 for s in scenarios if s["verdict"] == "removed"),
    }

    return {
        "base_run_id": base,
        "head_run_id": head,
        "base_started_at": _iso(base_run.started_at) if base_run else None,
        "head_started_at": _iso(head_run.started_at) if head_run else None,
        "summary": summary,
        "scenarios": scenarios,
    }


@app.get("/api/runs/{run_id}")
async def get_run(run_id: str, db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    row = await db.execute(select(RunRecord).where(RunRecord.run_id == run_id))
    record = row.scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=404, detail="Run not found")

    result_rows = await db.execute(
        select(ScenarioResultRecord).where(ScenarioResultRecord.run_id == run_id)
    )
    scenario_results = result_rows.scalars().all()

    return {
        "run_id": record.run_id,
        "started_at": _iso(record.started_at),
        "finished_at": _iso(record.finished_at),
        "pass_rate": record.pass_rate,
        "passed": record.passed,
        "total": record.total,
        "status": "completed" if record.finished_at else "running",
        "error": _extract_run_error(record),
        "scenario_results": [
            {
                "scenario_id": r.scenario_id,
                "scenario_name": r.scenario_name,
                "agent_type": r.agent_type,
                "status": r.status,
                "overall_score": r.overall_score,
                "pass_rate": r.pass_rate,
                "reasoning": r.reasoning,
                "error": r.error,
                "steps": r.steps,
                "check_results": r.check_results or [],
                "hard_failed": bool(r.hard_failed),
                "prompt_tokens": r.prompt_tokens or 0,
                "completion_tokens": r.completion_tokens or 0,
                "cost_usd": r.cost_usd or 0.0,
            }
            for r in scenario_results
        ],
    }


@app.post("/api/scenarios", status_code=201)
async def create_scenario(req: ScenarioCreate) -> dict[str, Any]:
    """Persist a scenario YAML to the resolved scenarios dir.

    The id is taken verbatim from the request (validated as a slug). Duplicate
    ids 422 — the older 409 behaviour was inconsistent with the rest of the
    create paths which all return 422 on validation conflicts.
    """
    actions = req.expected_actions or [
        {
            "action": "complete_task",
            "required": True,
            "description": "Agent completes the task correctly",
        }
    ]

    scenario_data: dict[str, Any] = {
        "id": req.id,
        "name": req.name,
        "description": req.description,
        "agent_type": req.agent_type,
        "prompt": req.prompt,
        "test_input": req.test_input,
        "expected_actions": actions,
        "tags": req.tags,
    }
    if req.checks:
        scenario_data["checks"] = req.checks

    scen_dir = _validate_path(req.scenarios_dir)
    scen_dir.mkdir(parents=True, exist_ok=True)

    path = scen_dir / f"{req.id}.yml"
    # Open with O_EXCL ("x") so two concurrent POSTs with the same id race
    # cleanly: only one creates the file, the other gets FileExistsError →
    # 422. Previously a .exists() check + open("w") had a TOCTOU window.
    try:
        with open(path, "x", encoding="utf-8") as f:
            yaml.safe_dump(
                scenario_data, f, default_flow_style=False, allow_unicode=True, sort_keys=False
            )
    except FileExistsError:
        raise HTTPException(
            status_code=422,
            detail=f"Scenario with id '{req.id}' already exists",
        )

    return {
        "id": req.id,
        "name": req.name,
        "description": req.description,
        "agent_type": req.agent_type,
        "tags": req.tags,
        "step_count": len(actions),
        "check_count": len(req.checks),
    }


def _existing_scenario_ids(scen_dir: Path) -> set[str]:
    """Return the set of scenario ids present on disk under scen_dir."""
    if not scen_dir.exists():
        return set()
    loader = ScenarioLoader()
    ids: set[str] = set()
    for path in sorted(scen_dir.rglob("*.yml")) + sorted(scen_dir.rglob("*.yaml")):
        if path.name.startswith("_"):
            continue
        try:
            ids.add(loader.load_file(path).id)
        except Exception:
            continue
    return ids


@app.post("/api/suites", status_code=201)
async def create_suite(req: SuiteCreate) -> dict[str, Any]:
    """Persist a SuiteConfig YAML under the resolved suites dir.

    Rejects with 422 if any of the referenced scenario ids don't exist on disk
    so the user sees a precise error instead of an empty run later.
    """
    suites_dir = _suites_base_dir()
    suites_dir.mkdir(parents=True, exist_ok=True)

    path = suites_dir / f"{req.id}.yml"
    # Validate scenario references BEFORE opening O_EXCL — keeps the error
    # path symmetric (no orphan empty file if scenario validation fails).
    known = _existing_scenario_ids(_scenarios_base_dir())
    unknown = [sid for sid in req.scenarios if sid not in known]
    if unknown:
        raise HTTPException(
            status_code=422,
            detail=(
                f"Unknown scenario id(s): {', '.join(unknown)} "
                f"— create them first or correct the spelling"
            ),
        )

    suite_data: dict[str, Any] = {
        "id": req.id,
        "name": req.name,
        "description": req.description,
        "version": 1,
        "scenarios": req.scenarios,
        "tags": req.tags,
        "pass_threshold": req.pass_threshold,
    }
    try:
        with open(path, "x", encoding="utf-8") as f:
            yaml.safe_dump(
                suite_data, f, default_flow_style=False, allow_unicode=True, sort_keys=False
            )
    except FileExistsError:
        raise HTTPException(
            status_code=422,
            detail=f"Suite with id '{req.id}' already exists",
        )

    return {
        "suite_id": req.id,
        "suite_name": req.name,
        "scenario_count": len(req.scenarios),
        "tags": req.tags,
    }


@app.get("/api/scenarios")
async def list_scenarios(scenarios_dir: str = "") -> list[dict[str, Any]]:
    scen_dir = _validate_path(scenarios_dir)
    if not scen_dir.exists():
        return []
    loader = ScenarioLoader()
    result = []
    for path in sorted(scen_dir.rglob("*.yml")) + sorted(scen_dir.rglob("*.yaml")):
        if path.name.startswith("_"):
            continue
        try:
            s = loader.load_file(path)
            rel = path.relative_to(scen_dir)
            suite = rel.parts[0] if len(rel.parts) > 1 else "default"
            result.append({
                "id": s.id,
                "name": s.name,
                "description": s.description,
                "agent_type": s.agent_type.value,
                "tags": s.tags,
                "step_count": len(s.expected_actions),
                "suite": suite,
            })
        except Exception as e:
            logger.warning("Failed to load scenario %s: %s", path, e)
    return result


@app.get("/api/scenarios/{scenario_id}")
async def get_scenario(
    scenario_id: str,
    scenarios_dir: str = "",
    db: AsyncSession = Depends(get_db),
) -> dict[str, Any]:
    """Return full scenario YAML + the last 5 runs for this scenario.

    Read-only — editing scenarios from the dashboard is deferred to v0.2.
    """
    scen_dir = _validate_path(scenarios_dir)
    if not scen_dir.exists():
        raise HTTPException(status_code=404, detail="Scenarios directory not found")

    loader = ScenarioLoader()
    matched: Path | None = None
    scenario_obj = None
    for path in sorted(scen_dir.rglob("*.yml")) + sorted(scen_dir.rglob("*.yaml")):
        if path.name.startswith("_"):
            continue
        try:
            s = loader.load_file(path)
        except Exception:
            continue
        if s.id == scenario_id:
            matched = path
            scenario_obj = s
            break

    if matched is None or scenario_obj is None:
        raise HTTPException(status_code=404, detail=f"Scenario '{scenario_id}' not found")

    rel = matched.relative_to(scen_dir)
    suite = rel.parts[0] if len(rel.parts) > 1 else "default"

    recent_rows = await db.execute(
        select(ScenarioResultRecord)
        .where(ScenarioResultRecord.scenario_id == scenario_id)
        .order_by(ScenarioResultRecord.id.desc())
        .limit(5)
    )
    recent = recent_rows.scalars().all()

    return {
        "id": scenario_obj.id,
        "name": scenario_obj.name,
        "description": scenario_obj.description,
        "agent_type": scenario_obj.agent_type.value,
        "prompt": scenario_obj.prompt,
        "test_input": scenario_obj.test_input,
        "success_criteria": scenario_obj.success_criteria,
        "tags": scenario_obj.tags,
        "timeout_seconds": scenario_obj.timeout_seconds,
        "weight": scenario_obj.weight,
        "suite": suite,
        "expected_actions": [
            {
                "action": a.action,
                "required": a.required,
                "description": a.description,
                "params": a.params,
            }
            for a in scenario_obj.expected_actions
        ],
        "checks": [
            {
                "type": c.type,
                "hard_fail": c.hard_fail,
                "fields": c.fields,
                "field": c.field,
                "allowed": c.allowed,
                "pattern": c.pattern,
                "text": c.text,
                "value": c.value,
            }
            for c in scenario_obj.checks
        ],
        "recent_runs": [
            {
                "run_id": r.run_id,
                "status": r.status,
                "overall_score": r.overall_score,
                "cost_usd": r.cost_usd or 0.0,
                "started_at": _iso(r.started_at),
                "finished_at": _iso(r.finished_at),
                "hard_failed": bool(r.hard_failed),
            }
            for r in recent
        ],
    }


@app.get("/api/suites")
async def list_suites(
    db: AsyncSession = Depends(get_db),
    include_mock: bool = False,
) -> list[dict[str, Any]]:
    """Return distinct benchmark suites with latest run status.

    Surfaces both (a) suites known to the DB from past runs and (b) suite YAMLs
    on disk that haven't been run yet — the New Run drawer needs the latter so
    fresh installs can launch the example suite without first running it.

    ``include_mock=false`` (the default for the dashboard's Benchmarks page)
    hides suites whose every persisted run is mock-mode — i.e. every scenario
    result for every run has ``cost_usd == 0``. Suites that have never run are
    always shown (they're not mock — they're un-run). Set ``include_mock=true``
    to see the full list including dev-mode runs.

    Previously this method did N+1 queries (latest-passed per suite, run-ids
    per suite, cost-hit per suite). Now it's two queries total: one suite
    aggregate joined to scenario_results for max-cost, one latest-passed
    lookup per remaining suite in a single batched IN-clause.
    """
    from sqlalchemy import desc, func, or_

    # ONE QUERY: per-suite aggregate joined to scenario_results so we can
    # tell mock-only from real at the same time. LEFT JOIN so suites with
    # zero scenario_results (shouldn't happen but defensive) still appear
    # with max_cost=NULL — treated as mock for filtering purposes.
    suite_agg = (
        select(
            SuiteResultRecord.suite_id,
            SuiteResultRecord.suite_name,
            func.count(func.distinct(SuiteResultRecord.id)).label("run_count"),
            func.max(SuiteResultRecord.created_at).label("latest_run"),
            func.coalesce(func.max(ScenarioResultRecord.cost_usd), 0.0).label("max_cost"),
        )
        .outerjoin(
            ScenarioResultRecord,
            ScenarioResultRecord.run_id == SuiteResultRecord.run_id,
        )
        .group_by(SuiteResultRecord.suite_id, SuiteResultRecord.suite_name)
        .order_by(desc(func.max(SuiteResultRecord.created_at)))
    )
    rows = (await db.execute(suite_agg)).all()

    candidate_ids = [
        row.suite_id for row in rows
        if include_mock or (row.max_cost is not None and row.max_cost > 0)
    ]

    # ONE more query: latest-passed for the surviving candidates in batch.
    latest_passed_by_id: dict[str, bool | None] = {}
    if candidate_ids:
        # Per-suite latest passed: order each suite's rows by created_at desc,
        # take the first. Window functions are SQLite-supported; fallback is
        # per-id but we keep it to a single round-trip via IN clause + GROUP.
        latest_query = await db.execute(
            select(
                SuiteResultRecord.suite_id,
                SuiteResultRecord.passed,
                SuiteResultRecord.created_at,
            )
            .where(SuiteResultRecord.suite_id.in_(candidate_ids))
            .order_by(SuiteResultRecord.suite_id, desc(SuiteResultRecord.created_at))
        )
        for sid, passed, _ts in latest_query.all():
            # First row per suite_id (because of order_by) is the latest.
            latest_passed_by_id.setdefault(
                sid, bool(passed) if passed is not None else None,
            )

    result: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for row in rows:
        if not include_mock and (row.max_cost is None or row.max_cost <= 0):
            # Mock-only: skip THIS DB entry but don't claim the id — the
            # on-disk loader below should still surface the suite YAML so
            # users can launch real runs of it.
            continue
        result.append({
            "suite_id": row.suite_id,
            "suite_name": row.suite_name,
            "run_count": row.run_count,
            "latest_run": _iso(row.latest_run),
            "latest_passed": latest_passed_by_id.get(row.suite_id),
        })
        seen_ids.add(row.suite_id)

    suites_dir = _suites_base_dir()
    if suites_dir.exists():
        loader = SuiteLoader()
        for suite in loader.load_dir(suites_dir):
            if suite.id not in seen_ids:
                result.append({
                    "suite_id": suite.id,
                    "suite_name": suite.name,
                    "run_count": 0,
                    "latest_run": None,
                    "latest_passed": None,
                })

    return result


@app.get("/api/suites/{suite_id}/history")
async def suite_history(suite_id: str, db: AsyncSession = Depends(get_db)) -> list[dict[str, Any]]:
    """Return benchmark history for a suite — all runs, ordered newest first."""
    rows = await db.execute(
        select(SuiteResultRecord)
        .where(SuiteResultRecord.suite_id == suite_id)
        .order_by(SuiteResultRecord.created_at.desc())
        .limit(200)
    )
    records = rows.scalars().all()
    return [
        {
            "run_id": r.run_id,
            "suite_id": r.suite_id,
            "suite_name": r.suite_name,
            "suite_version": r.suite_version,
            "pass_threshold": r.pass_threshold,
            "total": r.total,
            "semantic_pass_rate": r.semantic_pass_rate,
            "hard_fail_rate": r.hard_fail_rate,
            "soft_fail_rate": r.soft_fail_rate,
            "error_rate": r.error_rate,
            "weighted_score": r.weighted_score,
            "passed": bool(r.passed),
            "created_at": _iso(r.created_at),
        }
        for r in records
    ]


# ── Background task ────────────────────────────────────────────────────────────

async def _mark_run_failed(run_id: str, error_message: str) -> None:
    from .database import SessionLocal
    async with SessionLocal() as db:
        row = await db.execute(select(RunRecord).where(RunRecord.run_id == run_id))
        record = row.scalar_one_or_none()
        if record:
            record.finished_at = datetime.now(UTC)
            record.total = 0
            record.passed = 0
            record.pass_rate = 0.0
            record.results = [{"error": error_message}]
            await db.commit()


# Concurrent-run cap: keeps SQLite write contention bounded and avoids
# unintentional fanout of LLM API calls. Tunable via EVALGRID_MAX_CONCURRENT
# env var; default 2 is conservative for local single-user.
_MAX_CONCURRENT_RUNS = int(os.environ.get("EVALGRID_MAX_CONCURRENT_RUNS", "2"))
_run_semaphore: asyncio.Semaphore | None = None
_run_semaphore_lock = asyncio.Lock()


async def _get_run_semaphore() -> asyncio.Semaphore:
    """Lazy singleton — needs the running loop, can't init at import time.

    The asyncio.Lock guards the lazy init so two `_execute_run` background
    tasks scheduled at the same instant can't each create a separate
    semaphore (which would silently double the effective concurrency).
    """
    global _run_semaphore
    if _run_semaphore is None:
        async with _run_semaphore_lock:
            if _run_semaphore is None:
                _run_semaphore = asyncio.Semaphore(_MAX_CONCURRENT_RUNS)
    return _run_semaphore


async def _execute_run(
    run_id: str,
    req: RunRequest,
    pre_resolved: list | None = None,
) -> None:
    """Background-task runner. ``pre_resolved`` (added in v0.1.3 patch) is the
    scenario list already filtered by create_run — when present we skip the
    re-parse-from-disk step. None is still accepted for back-compat with any
    direct caller, but the public API path always passes a list now."""
    from .database import SessionLocal

    sem = await _get_run_semaphore()
    async with sem:
        config = EvalConfig()

        # Model assignment — agent_model and judge_model are independent. Passing
        # only judge_model retains the pre-v0.1.3 behaviour of setting both (with a
        # DeprecationWarning) so old API clients keep working.
        if req.agent_model:
            config.model = req.agent_model
        if req.judge_model:
            config.judge.model = req.judge_model
            if not req.agent_model:
                warnings.warn(
                    "Passing only judge_model is deprecated — pass agent_model and judge_model "
                    "separately. For now judge_model sets both, but this fallback will be removed "
                    "in v0.2.",
                    DeprecationWarning,
                    stacklevel=2,
                )
                config.model = req.judge_model
        if req.api_key:
            config.judge.api_key = req.api_key
        scen_dir = (_scenarios_base_dir().resolve() / req.scenarios_dir).resolve()

        if not scen_dir.exists():
            await _mark_run_failed(run_id, f"Scenarios directory not found: {scen_dir}")
            return

        async def _run_with_timeout() -> None:
            # If create_run pre-resolved (the normal path), reuse it. Otherwise
            # re-resolve so a manual scheduler/test that calls _execute_run
            # directly still works.
            if pre_resolved is not None:
                scenarios = pre_resolved
                skipped: list[dict[str, str]] = []
            else:
                loader = ScenarioLoader()
                scenarios = loader.load_dir(scen_dir)
                skipped = loader.skipped
                if req.suite:
                    suites_dir = _suites_base_dir()
                    suite_path = suites_dir / f"{req.suite}.yml"
                    if not suite_path.exists():
                        suite_path = suites_dir / f"{req.suite}.yaml"
                    if not suite_path.exists():
                        await _mark_run_failed(
                            run_id, f"Suite '{req.suite}' not found in {suites_dir}"
                        )
                        return
                    suite = SuiteLoader().load_file(suite_path)
                    scenarios = SuiteLoader().filter_scenarios(suite, scenarios)
                if req.tags:
                    scenarios = [s for s in scenarios if any(t in s.tags for t in req.tags)]
                if req.scenario_ids:
                    scenarios = [s for s in scenarios if s.id in req.scenario_ids]

            if skipped:
                async with SessionLocal() as db:
                    row = await db.execute(select(RunRecord).where(RunRecord.run_id == run_id))
                    record = row.scalar_one_or_none()
                    if record:
                        record.skipped_scenarios = skipped
                        await db.commit()

            if req.mock:
                from evalgrid.core.scorer import MockScorer
                runner = ScenarioRunner(
                    config,
                    scorer=MockScorer(),
                    agent_fn=lambda s: ("[mock agent output]", 0),
                    mock=True,
                )
            else:
                runner = ScenarioRunner(config)

            loop = asyncio.get_running_loop()
            results = []
            for scenario in scenarios:
                result = await loop.run_in_executor(None, runner.run_scenario, scenario)
                results.append(result)

                async with SessionLocal() as db:
                    sr = ScenarioResultRecord(
                        run_id=run_id,
                        scenario_id=result.scenario_id,
                        scenario_name=result.scenario_name,
                        agent_type=result.agent_type.value,
                        status=result.status.value,
                        overall_score=result.overall_score,
                        pass_rate=result.pass_rate,
                        reasoning=result.reasoning,
                        error=result.error,
                        steps=[s.model_dump(mode="json") for s in result.steps],
                        check_results=[c.model_dump(mode="json") for c in result.check_results],
                        hard_failed=result.hard_failed,
                        prompt_tokens=result.prompt_tokens,
                        completion_tokens=result.completion_tokens,
                        cost_usd=result.cost_usd,
                        started_at=result.started_at,
                        finished_at=result.finished_at,
                    )
                    db.add(sr)
                    await db.commit()

            passed = sum(1 for r in results if r.status == PassFail.PASS)
            total = len(results)

            async with SessionLocal() as db:
                row = await db.execute(select(RunRecord).where(RunRecord.run_id == run_id))
                record = row.scalar_one_or_none()
                if record:
                    record.finished_at = datetime.now(UTC)
                    record.passed = passed
                    record.total = total
                    record.pass_rate = passed / total if total else 0.0
                    await db.commit()

        try:
            await asyncio.wait_for(_run_with_timeout(), timeout=1800)
        except TimeoutError:
            logger.error("Run %s timed out after 1800s", run_id)
            await _mark_run_failed(run_id, "Run timed out (30 minute limit exceeded)")
        except Exception as exc:
            await _mark_run_failed(run_id, _sanitize_error(str(exc)))


# Serve React dashboard — EVALGRID_DASHBOARD_DIR (override) or evalgrid/static/ (wheel) or dashboard/dist/ (dev)
_dashboard_override = os.environ.get("EVALGRID_DASHBOARD_DIR")
if _dashboard_override:
    _dashboard = Path(_dashboard_override)
else:
    _dashboard = Path(__file__).parent.parent / "static"
    if not _dashboard.exists():
        _dashboard = Path(__file__).parent.parent.parent / "dashboard" / "dist"


class SPAStaticFiles(StaticFiles):
    """StaticFiles that serves the closest matching SPA shell on 404.

    Next.js exports one HTML file per route, plus a placeholder shell for
    each dynamic ``[id]`` route (via ``generateStaticParams() ->
    [{id: "_index"}]``). Returning the wrong shell hands the browser the
    wrong loading state and the wrong client bundle — the v0.1.3 bug was
    that every ``/runs/<id>`` hard refresh landed on the Overview because
    the fallback always served root ``index.html``.

    Resolution walks up from the requested path, preferring the dynamic
    ``_index/`` shell at each depth before falling back to the literal
    route shell and finally the root. ``/api/*`` 404s stay typed JSON.
    Asset 404s (.js/.css/.woff2/.txt/.json) stay real 404s so the client
    sees the right failure mode instead of HTML rendered as a script.
    """

    def _resolve_spa_shell(self, request_path: str) -> Path | None:
        static_root = Path(self.directory)
        parts = [p for p in request_path.strip("/").split("/") if p]

        if parts:
            direct = static_root.joinpath(*parts, "index.html")
            if direct.exists():
                return direct

        for depth in range(len(parts) - 1, -1, -1):
            base = static_root.joinpath(*parts[:depth]) if depth else static_root
            dynamic = base / "_index" / "index.html"
            if dynamic.exists():
                return dynamic
            literal = base / "index.html"
            if literal.exists():
                return literal

        root_shell = static_root / "index.html"
        return root_shell if root_shell.exists() else None

    def _resolve_rsc_payload(self, request_path: str) -> Path | None:
        """Map Next.js 16 RSC client requests to their on-disk export files.

        Next 16 RSC navigation issues prefetches the export layout doesn't
        serve directly. Two transforms — applied compositionally so nested
        cases work:

        1. **Dotted dirnames** for `*.__PAGE__.txt`: the last dot before
           `__PAGE__.txt` is actually a directory boundary
           (`__next.<seg>.__PAGE__.txt` is on disk at `__next.<seg>/__PAGE__.txt`).
           Nested dynamic routes encode extra segments as more dots
           (`__next.runs.$d$id.__PAGE__.txt` ↔ `__next.runs/$d$id/__PAGE__.txt`).

        2. **Dynamic-route `_index` fallback**: visiting `/runs/<actual-id>`
           triggers RSC fetches under `/runs/<id>/…` but those payloads
           only live under `/runs/_index/…` (the placeholder shell from
           `generateStaticParams() -> [{id:"_index"}]`). Walk inner
           segments right-to-left replacing each with `_index`.

        Composed: each `_index` substitution also tries every dotted-dirname
        split on the trailing segment. Without the composition the nested
        case `/runs/<id>/__next.runs.$d$id.__PAGE__.txt` would still 404.

        Without these rewrites every dashboard navigation logs a 404
        console.error before falling back to a full reload — routes still
        work but the noise drowns real errors.
        """
        static_root = Path(self.directory).resolve()
        parts = [p for p in request_path.strip("/").split("/") if p]
        if not parts or any(p in ("..", "") for p in parts):
            return None

        def _safe(*components: str) -> Path | None:
            if any(c in ("..", "") for c in components):
                return None
            candidate = static_root.joinpath(*components)
            try:
                resolved = candidate.resolve()
                resolved.relative_to(static_root)
            except (ValueError, OSError):
                return None
            return resolved if resolved.is_file() else None

        def _split_stem(stem: str) -> list[list[str]]:
            """Right-to-left cumulative dot splits of `stem`. Returns the
            list of segment-lists, including the no-split case first."""
            results: list[list[str]] = [[stem]]
            dot_positions = [i for i, ch in enumerate(stem) if ch == "."]
            for n in range(1, len(dot_positions) + 1):
                cuts = sorted(dot_positions[-n:])
                seg_parts: list[str] = []
                start = 0
                for cut in cuts:
                    seg_parts.append(stem[start:cut])
                    start = cut + 1
                seg_parts.append(stem[start:])
                results.append(seg_parts)
            return results

        def _try_with_dot_rewrites(prefix_parts: list[str], last_seg: str) -> Path | None:
            # As-requested first (literal flat file at this position).
            match = _safe(*prefix_parts, last_seg)
            if match is not None:
                return match

            # Shape A: `<stem>.__PAGE__.txt` — filename literal is
            # `__PAGE__.txt`, the stem-splits all become dirnames.
            page_marker = ".__PAGE__.txt"
            if last_seg.endswith(page_marker):
                stem = last_seg[: -len(page_marker)]
                if stem and stem not in ("..", "."):
                    for seg_parts in _split_stem(stem):
                        if any(p in ("..", "") for p in seg_parts):
                            continue
                        match = _safe(*prefix_parts, *seg_parts, "__PAGE__.txt")
                        if match is not None:
                            return match

            # Shape B: `<stem>.txt` — filename literal is `<last_split>.txt`,
            # earlier splits are dirnames. (Skip the no-split case; that's
            # the as-requested above.)
            txt_marker = ".txt"
            if last_seg.endswith(txt_marker) and not last_seg.endswith(page_marker):
                stem = last_seg[: -len(txt_marker)]
                if stem and stem not in ("..", "."):
                    for seg_parts in _split_stem(stem):
                        if len(seg_parts) == 1:
                            continue  # already tried as-requested
                        if any(p in ("..", "") for p in seg_parts):
                            continue
                        seg_parts_with_ext = (
                            seg_parts[:-1] + [seg_parts[-1] + ".txt"]
                        )
                        match = _safe(*prefix_parts, *seg_parts_with_ext)
                        if match is not None:
                            return match
            return None

        last_seg = parts[-1]
        prefix = parts[:-1]

        # Attempt 1: as-requested prefix.
        match = _try_with_dot_rewrites(prefix, last_seg)
        if match is not None:
            return match

        # Attempt 2: replace each inner prefix segment with `_index`,
        # right-to-left, retrying the dot rewrites at each substitution.
        for depth in range(len(prefix) - 1, -1, -1):
            rewritten_prefix = prefix[:depth] + ["_index"] + prefix[depth + 1:]
            if rewritten_prefix == prefix:
                continue
            match = _try_with_dot_rewrites(rewritten_prefix, last_seg)
            if match is not None:
                return match
        return None

    async def get_response(self, path: str, scope: Scope):  # type: ignore[override]
        response = None
        try:
            response = await super().get_response(path, scope)
        except StarletteHTTPException as exc:
            if exc.status_code != 404:
                raise

        if response is not None and response.status_code != 404:
            return response

        raw_path = scope.get("path", "")
        req_path = raw_path if isinstance(raw_path, str) else ""
        if req_path.startswith("/api/"):
            return JSONResponse({"detail": "Not found"}, status_code=404)

        suffix = Path(req_path).suffix.lower()
        if suffix and suffix != ".html":
            rsc = self._resolve_rsc_payload(req_path)
            if rsc is not None:
                return FileResponse(rsc)
            return response if response is not None else JSONResponse(
                {"detail": "Not found"}, status_code=404,
            )

        shell = self._resolve_spa_shell(req_path)
        if shell is not None:
            return FileResponse(shell)
        return JSONResponse({"detail": "Not found"}, status_code=404)


if _dashboard.exists():
    app.mount("/", SPAStaticFiles(directory=_dashboard, html=True), name="static")
