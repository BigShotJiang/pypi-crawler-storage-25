"""Database setup — SQLite (dev) / Postgres (prod)."""

from __future__ import annotations

import logging
from collections.abc import AsyncGenerator
from datetime import datetime
from pathlib import Path
from typing import Any

from sqlalchemy import JSON, DateTime, Float, ForeignKey, Integer, String, Text, func, text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from evalgrid.core.paths import default_database_url

logger = logging.getLogger("evalgrid")

DATABASE_URL = default_database_url()

engine = create_async_engine(DATABASE_URL, echo=False)
SessionLocal = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class RunRecord(Base):
    __tablename__ = "runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    run_id: Mapped[str] = mapped_column(String, unique=True, index=True)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    pass_rate: Mapped[float] = mapped_column(Float, default=0.0)
    passed: Mapped[int] = mapped_column(Integer, default=0)
    total: Mapped[int] = mapped_column(Integer, default=0)
    results: Mapped[list[Any]] = mapped_column(JSON, default=list)
    skipped_scenarios: Mapped[list[dict[str, str]] | None] = mapped_column(JSON, nullable=True)


class ScenarioResultRecord(Base):
    __tablename__ = "scenario_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    run_id: Mapped[str] = mapped_column(String, ForeignKey("runs.run_id"), index=True)
    scenario_id: Mapped[str] = mapped_column(String, index=True)
    scenario_name: Mapped[str] = mapped_column(String)
    agent_type: Mapped[str] = mapped_column(String)
    status: Mapped[str] = mapped_column(String)
    overall_score: Mapped[float] = mapped_column(Float)
    pass_rate: Mapped[float] = mapped_column(Float)
    reasoning: Mapped[str] = mapped_column(Text, default="")
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    steps: Mapped[list[Any]] = mapped_column(JSON, default=list)
    check_results: Mapped[list[Any]] = mapped_column(JSON, default=list)
    hard_failed: Mapped[bool] = mapped_column(Integer, default=0)
    prompt_tokens: Mapped[int] = mapped_column(Integer, default=0)
    completion_tokens: Mapped[int] = mapped_column(Integer, default=0)
    cost_usd: Mapped[float] = mapped_column(Float, default=0.0)
    started_at: Mapped[datetime] = mapped_column(DateTime)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class SuiteResultRecord(Base):
    """Suite-level benchmark result — persisted as a first-class entity for history and trends."""

    __tablename__ = "suite_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    run_id: Mapped[str] = mapped_column(String, ForeignKey("runs.run_id"), index=True)
    suite_id: Mapped[str] = mapped_column(String, index=True)
    suite_name: Mapped[str] = mapped_column(String)
    suite_version: Mapped[int] = mapped_column(Integer, default=1)
    pass_threshold: Mapped[float] = mapped_column(Float)
    total: Mapped[int] = mapped_column(Integer)
    # ── four distinct rates — never collapsed ─────────────────────────────────
    semantic_pass_rate: Mapped[float] = mapped_column(Float)
    hard_fail_rate: Mapped[float] = mapped_column(Float)
    soft_fail_rate: Mapped[float] = mapped_column(Float)
    error_rate: Mapped[float] = mapped_column(Float)
    weighted_score: Mapped[float] = mapped_column(Float)
    passed: Mapped[bool] = mapped_column(Integer)  # met threshold
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())


async def init_db() -> None:
    """Initialize the database, creating parent directories as needed."""
    url_str = str(engine.url)
    if url_str.startswith("sqlite"):
        db_path_str = url_str.split(":///", 1)[-1]
        if db_path_str and db_path_str != ":memory:":
            db_path = Path(db_path_str).expanduser()
            db_path.parent.mkdir(parents=True, exist_ok=True)

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        for stmt in [
            "ALTER TABLE runs ADD COLUMN skipped_scenarios JSON DEFAULT '[]'",
            "ALTER TABLE scenario_results ADD COLUMN check_results JSON DEFAULT '[]'",
            "ALTER TABLE scenario_results ADD COLUMN hard_failed INTEGER DEFAULT 0",
            "ALTER TABLE scenario_results ADD COLUMN prompt_tokens INTEGER DEFAULT 0",
            "ALTER TABLE scenario_results ADD COLUMN completion_tokens INTEGER DEFAULT 0",
            "ALTER TABLE scenario_results ADD COLUMN cost_usd REAL DEFAULT 0.0",
        ]:
            try:
                await conn.execute(text(stmt))
            except Exception as e:
                if "duplicate column" not in str(e).lower():
                    logger.warning("Migration failed (%s): %s", stmt.split()[4], e)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with SessionLocal() as session:
        yield session
