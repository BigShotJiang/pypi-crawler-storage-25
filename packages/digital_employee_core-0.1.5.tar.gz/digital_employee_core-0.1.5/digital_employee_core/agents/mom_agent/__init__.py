"""MoM Agent package for digital employee core.

This package provides MoM (Minute of Meeting) agents and their variants.
"""

from digital_employee_core.agents.mom_agent.mom_agent import create_mom_agent
from digital_employee_core.agents.mom_agent.mom_docs_agent.mom_docs_agent import create_mom_docs_agent
from digital_employee_core.agents.mom_agent.mom_mail_agent.mom_mail_agent import create_mom_mail_agent

__all__ = [
    "create_mom_agent",
    "create_mom_docs_agent",
    "create_mom_mail_agent",
]
