"""MoM Docs Agent package for digital employee core.

This package provides the MoM agent with Google Docs capabilities.
"""

from digital_employee_core.agents.mom_agent.mom_docs_agent.mom_docs_agent import create_mom_docs_agent

__all__ = [
    "create_mom_docs_agent",
]
