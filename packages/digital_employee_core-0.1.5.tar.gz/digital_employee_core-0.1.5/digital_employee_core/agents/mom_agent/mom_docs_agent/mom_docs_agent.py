"""Minute of Meeting (MoM) Agents with Google Docs Capabilities for Digital Employee Core.

This module provides pre-configured Agent instances for generating meeting minutes
using the Meemo platform and creating Google Docs.

Authors:
    Immanuel Rhesa (immanuel.rhesa@gdplabs.id)

References:
    NONE
"""

from importlib.resources import files

from glaip_sdk import Agent

from digital_employee_core.connectors.mcps import google_docs_mcp, meemo_mcp
from digital_employee_core.connectors.tools import time_tool
from digital_employee_core.constants.models import GPT_5_2_MODEL_NAME

# Load base instructions from parent directory
_BASE_INSTRUCTIONS_FILE = files("digital_employee_core.agents.mom_agent") / "mom_agent.md"
_BASE_INSTRUCTIONS = _BASE_INSTRUCTIONS_FILE.read_text(encoding="utf-8")

# Load extension instructions from markdown file
_EXTENSION_INSTRUCTIONS_FILE = files(__package__) / "mom_docs_agent.md"
_EXTENSION_INSTRUCTIONS = _EXTENSION_INSTRUCTIONS_FILE.read_text(encoding="utf-8")

# Combine base and extension instructions
_MOM_DOCS_AGENT_INSTRUCTIONS = f"{_BASE_INSTRUCTIONS}\n\n{_EXTENSION_INSTRUCTIONS}"


def create_mom_docs_agent(name: str, model: str = GPT_5_2_MODEL_NAME) -> Agent:
    """Create a MoM docs agent with a configurable name.

    Args:
        name (str): The name for the agent.
        model (str): The model to use for the agent. Defaults to GPT_5_2_MODEL_NAME.

    Returns:
        Agent: A new Agent instance configured for meeting minutes operations with Google Docs capabilities,
            with the specified name.
    """
    return Agent(
        name=name,
        description="Agent specialized in generating meeting minutes using the Meemo platform and creating Google Docs",
        instruction=_MOM_DOCS_AGENT_INSTRUCTIONS,
        tools=[time_tool],
        mcps=[meemo_mcp, google_docs_mcp],
        model=model,
    )
