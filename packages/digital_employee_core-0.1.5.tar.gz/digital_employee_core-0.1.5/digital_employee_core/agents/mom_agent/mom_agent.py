"""Minute of Meeting (MoM) Agents for Digital Employee Core.

This module provides pre-configured Agent instances for generating meeting minutes
using the Meemo platform.

Authors:
    Immanuel Rhesa (immanuel.rhesa@gdplabs.id)

References:
    NONE
"""

from importlib.resources import files

from glaip_sdk import Agent

from digital_employee_core.connectors.mcps import meemo_mcp
from digital_employee_core.connectors.tools import time_tool
from digital_employee_core.constants.models import GPT_5_2_MODEL_NAME

# Load instructions from markdown file
_INSTRUCTIONS_FILE = files(__package__) / "mom_agent.md"
_MOM_AGENT_INSTRUCTIONS = _INSTRUCTIONS_FILE.read_text(encoding="utf-8")


def create_mom_agent(name: str, model: str = GPT_5_2_MODEL_NAME) -> Agent:
    """Create a MoM agent with a configurable name.

    Args:
        name (str): The name for the agent.
        model (str): The model to use for the agent. Defaults to GPT_5_2_MODEL_NAME.

    Returns:
        Agent: A new Agent instance configured for meeting minutes operations with the specified name.
    """
    return Agent(
        name=name,
        description="Agent specialized in generating and managing meeting minutes using the Meemo platform",
        instruction=_MOM_AGENT_INSTRUCTIONS,
        tools=[time_tool],
        mcps=[meemo_mcp],
        model=model,
    )
