"""MoM Mail Agent package for digital employee core.

This package provides the MoM agent with email distribution capabilities.
"""

from digital_employee_core.agents.mom_agent.mom_mail_agent.mom_mail_agent import create_mom_mail_agent

__all__ = [
    "create_mom_mail_agent",
]
