"""Step builder abstract base class.

This module provides the StepBuilder abstract base class that any builder
can implement to create a pipeline step.

Authors:
    Immanuel Rhesa (immanuel.rhesa@gdplabs.id)

References:
    NONE
"""

from abc import ABC, abstractmethod
from typing import Any

from gllm_pipeline.steps import ComponentStep


class StepBuilder(ABC):
    """Abstract base class for step builders.

    Any builder that can create a pipeline step should inherit from this class.
    This allows DigitalEmployeePipelineBuilder to accept different types of step builders.
    """

    @abstractmethod
    def build_step(self, **kwargs: Any) -> ComponentStep:
        """Build a ComponentStep from this builder.

        Subclasses can accept additional parameters via kwargs to support
        different building contexts (e.g., identity, configurations).

        Args:
            **kwargs (Any): Additional parameters that subclasses may need.

        Returns:
            ComponentStep: The build pipeline step.

        Raises:
            NotImplementedError: If the method is not implemented by the subclass.
        """
        raise NotImplementedError
