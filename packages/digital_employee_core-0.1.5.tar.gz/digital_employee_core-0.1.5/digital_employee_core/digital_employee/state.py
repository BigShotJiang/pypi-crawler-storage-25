"""State definitions for the digital employee pipeline.

This module provides the state types used throughout the digital employee
pipeline execution.

Authors:
    Immanuel Rhesa (immanuel.rhesa@gdplabs.id)
    Vio Albert Ferdinand (vio.a.ferdinand@gdplabs.id)

References:
    NONE
"""

from typing import Any, TypedDict


class DigitalEmployeeState(TypedDict, total=False):
    """State definition for the digital employee pipeline.

    Attributes:
        message (str): The input message to process.
        agent_response (str): The response from the agent step.
        runtime_config (dict[str, Any]): Runtime configuration for the agent.
        run_kwargs (dict[str, Any]): Additional keyword arguments for agent execution
            (e.g., local, verbose, temperature, etc.).
    """

    message: str
    agent_response: str
    runtime_config: dict[str, Any]
    run_kwargs: dict[str, Any]
