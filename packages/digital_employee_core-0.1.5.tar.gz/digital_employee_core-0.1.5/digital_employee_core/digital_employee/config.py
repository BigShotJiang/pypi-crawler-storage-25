"""Configuration and credentials management for digital employee.

This module provides classes for managing configuration credentials.

Authors:
    Immanuel Rhesa (immanuel.rhesa@gdplabs.id)

References:
    NONE
"""

import os
from dataclasses import dataclass


@dataclass
class DigitalEmployeeConfig:
    """Represents a single configuration for digital employee.

    This class combines both configuration and credential information.

    Attributes:
        key (str): The configuration key identifier (e.g., "GOOGLE_MCP_X_API_KEY", "SPREADSHEET_ID").
        value (str): The configuration value or credential.
    """

    key: str
    value: str

    @classmethod
    def from_env(cls, *keys: str | tuple[str, str]) -> list["DigitalEmployeeConfig"]:
        """Create configuration instances from environment variables.

        Args:
            *keys (str | tuple[str, str]): The keys of the environment variables to retrieve.
                Can be either:
                - A string key only (uses empty string as default)
                - A tuple of (key, default_value)

        Returns:
            list[DigitalEmployeeConfig]: List of configuration instances.

        Examples:
            >>> DigitalEmployeeConfig.from_env("KEY1", "KEY2")
            >>> DigitalEmployeeConfig.from_env(("KEY1", "default1"), ("KEY2", "default2"))
            >>> DigitalEmployeeConfig.from_env("KEY1", ("KEY2", "default2"))
        """
        result: list[DigitalEmployeeConfig] = []
        for k in keys:
            key, default = k if isinstance(k, tuple) else (k, "")
            result.append(cls(key=key, value=os.getenv(key, default)))
        return result
