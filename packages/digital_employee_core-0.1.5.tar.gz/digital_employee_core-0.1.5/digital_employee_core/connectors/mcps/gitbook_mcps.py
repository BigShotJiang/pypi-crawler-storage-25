"""Gitbook MCPs initialization module.

Authors:
    Berty C L Tobing (berty.c.l.tobing@gdplabs.id)
    Richard Gunawan (richard.gunawan@gdplabs.id)

References:
    NONE
"""

from glaip_sdk import MCP

# CATAPA Gitbook MCP
gitbook_catapa_mcp = MCP(
    name="digital_employee_gitbook_catapa_mcp",
    description=(
        "This MCP contains everything you need to know about CATAPA, Claudia, and Digital employee from GitBook"
    ),
    transport="http",
    config={"url": "https://gdplabs.gitbook.io/catapa/~gitbook/mcp"},
)

# CATAPA Internal Gitbook MCP
gitbook_catapa_internal_mcp = MCP(
    name="digital_employee_gitbook_catapa_internal_mcp",
    description=(
        "This MCP contains everything you need to know about Internal GDP Labs' use case from CATAPA, Claudia, and "
        "Digital employee from GitBook"
    ),
    transport="http",
    config={"url": "https://gdplabs.gitbook.io/catapa-internal/~gitbook/mcp"},
)

# GL AIP Gitbook MCP
gitbook_gl_aip_mcp = MCP(
    name="digital_employee_gitbook_gl_aip_mcp",
    description=(
        "This MCP contains everything you need to know about GDP Labs AI Agents Package (GL AIP) from GL AIP GitBook."
    ),
    transport="http",
    config={"url": "https://gdplabs.gitbook.io/gl-aip/~gitbook/mcp"},
)

# GL Connectors Gitbook MCP
gitbook_gl_connectors_mcp = MCP(
    name="digital_employee_gitbook_gl_connectors_mcp",
    description="This MCP contains everything you need to know about GL Connector from GL Connector GitBook.",
    transport="http",
    config={"url": "https://gdplabs.gitbook.io/bosa/~gitbook/mcp"},
)

# GL SDK Gitbook MCP
gitbook_gl_sdk_mcp = MCP(
    name="digital_employee_gitbook_gl_sdk_mcp",
    description="This MCP contains everything you need to know about GL SDK from GL SDK GitBook.",
    transport="http",
    config={"url": "https://gdplabs.gitbook.io/sdk/~gitbook/mcp"},
)

# GL Smart Search Gitbook MCP
gitbook_gl_smart_search_mcp = MCP(
    name="digital_employee_gitbook_gl_smart_search_mcp",
    description="This MCP contains everything you need to know about GL Smart Search from GL Smart Search GitBook.",
    transport="http",
    config={"url": "https://gdplabs.gitbook.io/smart-search/~gitbook/mcp"},
)

# GLChat Gitbook MCP
gitbook_glchat_mcp = MCP(
    name="digital_employee_gitbook_glchat_mcp",
    description="This MCP contains everything you need to know about GLChat from GLChat GitBook.",
    transport="http",
    config={"url": "https://gdplabs.gitbook.io/glchat/~gitbook/mcp"},
)

# Meemo Gitbook MCP
gitbook_meemo_mcp = MCP(
    name="digital_employee_gitbook_meemo_mcp",
    description="This MCP contains everything you need to know about Meemo from Meemo GitBook.",
    transport="http",
    config={"url": "https://gdplabs.gitbook.io/meemo/~gitbook/mcp"},
)
