import json
import os

import pytest

from flyql.columns import parse, diagnose
from flyql.core.column import Column, ColumnSchema
from flyql.core.validator import (
    CODE_ARG_COUNT,
    CODE_ARG_TYPE,
    CODE_CHAIN_TYPE,
    CODE_RENDERER_ARG_COUNT,
    CODE_RENDERER_ARG_TYPE,
    CODE_UNKNOWN_COLUMN,
    CODE_UNKNOWN_RENDERER,
    CODE_UNKNOWN_TRANSFORMER,
    Diagnostic,
    ErrorEntry,
)
from flyql.errors_generated import VALIDATOR_REGISTRY
from flyql.core.range import Range
from flyql.flyql_type import Type, parse_flyql_type
from flyql.renderers import ArgSpec, Renderer, RendererRegistry
from flyql.transformers.base import Transformer
from flyql.transformers.registry import TransformerRegistry, default_registry

FIXTURE_PATH = os.path.join(
    os.path.dirname(__file__),
    "..",
    "..",
    "..",
    "tests-data",
    "columns",
    "validator.json",
)
SHARED_DATA = json.loads(open(FIXTURE_PATH, "r").read())


def make_column(name: str, type_str: str) -> Column:
    return Column(
        name=name,
        column_type=parse_flyql_type(type_str),
        match_name=name,
    )


def _build_column_from_def(d: dict) -> Column:
    children = None
    if "children" in d and isinstance(d["children"], dict):
        children = {}
        for child_name, child_def in d["children"].items():
            children[child_name] = _build_column_from_def(child_def)
    return Column(
        name=d["name"],
        column_type=parse_flyql_type(d["type"]),
        match_name=d["name"],
        children=children,
    )


def make_schema(defs) -> ColumnSchema:
    m = {}
    for d in defs:
        col = _build_column_from_def(d)
        m[d["name"]] = col
    return ColumnSchema(m)


@pytest.mark.parametrize("tc", SHARED_DATA["tests"], ids=lambda tc: tc["name"])
def test_shared_fixtures(tc):
    caps = tc.get("capabilities", {"transformers": True})
    try:
        parsed = parse(tc["input"], capabilities=caps)
    except Exception:
        parsed = []
    schema = make_schema(tc["columns"])
    diags = diagnose(parsed, schema)
    assert len(diags) == len(
        tc["expected_diagnostics"]
    ), f"Expected {len(tc['expected_diagnostics'])} diagnostics, got {len(diags)}"
    for i, expected in enumerate(tc["expected_diagnostics"]):
        assert diags[i].code == expected["code"]
        assert diags[i].severity == expected["severity"]
        assert diags[i].range.start == expected["range"][0]
        assert diags[i].range.end == expected["range"][1]
        if "message_contains" in expected:
            assert expected["message_contains"] in diags[i].message


def _schema_from_column(name: str, normalized_type: str) -> ColumnSchema:
    return ColumnSchema.from_columns([make_column(name, normalized_type)])


def test_empty_returns_empty():
    diags = diagnose([], _schema_from_column("level", "string"))
    assert diags == []


def test_valid_column_no_diagnostics():
    cols = parse("level", capabilities={"transformers": True})
    diags = diagnose(cols, _schema_from_column("level", "string"))
    assert diags == []


def test_valid_column_with_transformer():
    cols = parse("level|upper", capabilities={"transformers": True})
    diags = diagnose(cols, _schema_from_column("level", "string"))
    assert diags == []


def test_unknown_column():
    cols = parse("foo", capabilities={"transformers": True})
    diags = diagnose(cols, _schema_from_column("level", "string"))
    assert len(diags) == 1
    assert diags[0].code == CODE_UNKNOWN_COLUMN
    assert diags[0].range.start == 0
    assert diags[0].range.end == 3


def test_unknown_transformer():
    cols = parse("level|zzzz", capabilities={"transformers": True})
    diags = diagnose(cols, _schema_from_column("level", "string"))
    assert len(diags) == 1
    assert diags[0].code == CODE_UNKNOWN_TRANSFORMER
    assert diags[0].range.start == 6
    assert diags[0].range.end == 10


def test_chain_type_mismatch():
    cols = parse("level|len|upper", capabilities={"transformers": True})
    diags = diagnose(cols, _schema_from_column("level", "string"))
    assert any(d.code == CODE_CHAIN_TYPE for d in diags)


class _AcceptsAny(Transformer):
    @property
    def name(self) -> str:
        return "accepts_any"

    @property
    def input_type(self) -> Type:
        return Type.Any

    @property
    def output_type(self) -> Type:
        return Type.String

    def sql(self, dialect, column_ref, args=None):
        return column_ref

    def apply(self, value, args=None):
        return value


class _AcceptsAnyReturningArray(Transformer):
    @property
    def name(self) -> str:
        return "accepts_any_returning_array"

    @property
    def input_type(self) -> Type:
        return Type.Any

    @property
    def output_type(self) -> Type:
        return Type.Array

    def sql(self, dialect, column_ref, args=None):
        return column_ref

    def apply(self, value, args=None):
        return value


def _registry_with_any() -> TransformerRegistry:
    reg = default_registry()
    reg.register(_AcceptsAny())
    reg.register(_AcceptsAnyReturningArray())
    return reg


def test_any_input_transformer_accepts_any_column_type():
    cols = parse("level|accepts_any", capabilities={"transformers": True})
    diags = diagnose(
        cols,
        _schema_from_column("level", "int"),
        registry=_registry_with_any(),
    )
    assert not any(d.code == CODE_CHAIN_TYPE for d in diags)


def test_chain_remains_strict_after_any_input_returning_array():
    cols = parse(
        "level|accepts_any_returning_array|upper",
        capabilities={"transformers": True},
    )
    diags = diagnose(
        cols,
        _schema_from_column("level", "int"),
        registry=_registry_with_any(),
    )
    chain_diags = [d for d in diags if d.code == CODE_CHAIN_TYPE]
    assert len(chain_diags) == 1
    assert "upper" in chain_diags[0].message


def test_dotted_column_highlights_base():
    cols = parse("resource.service.name", capabilities={"transformers": True})
    diags = diagnose(cols, _schema_from_column("level", "string"))
    assert len(diags) == 1
    assert diags[0].range.start == 0
    assert diags[0].range.end == 8  # "resource"


class _HrefRenderer(Renderer):
    arg_schema = (ArgSpec(type=Type.String, required=True),)

    @property
    def name(self) -> str:
        return "href"


class _StarsRenderer(Renderer):
    arg_schema = (ArgSpec(type=Type.Int, required=True),)

    @property
    def name(self) -> str:
        return "stars"


class _TruncateRenderer(Renderer):
    arg_schema = (ArgSpec(type=Type.Int, required=True),)

    @property
    def name(self) -> str:
        return "truncate"


class TestRendererValidation:
    def _caps(self):
        return {"transformers": True, "renderers": True}

    def _schema(self):
        return _schema_from_column("url", "string")

    def _registry(self):
        reg = RendererRegistry()
        reg.register(_HrefRenderer())
        reg.register(_StarsRenderer())
        reg.register(_TruncateRenderer())
        return reg

    def test_unknown_renderer(self):
        cols = parse('url as link|unknown("x")', capabilities=self._caps())
        diags = diagnose(cols, self._schema(), renderer_registry=self._registry())
        assert len(diags) == 1
        assert diags[0].code == CODE_UNKNOWN_RENDERER

    def test_valid_renderer_zero_diagnostics(self):
        cols = parse('url as link|href("/x")', capabilities=self._caps())
        diags = diagnose(cols, self._schema(), renderer_registry=self._registry())
        assert diags == []

    def test_renderer_arg_count(self):
        cols = parse('url as link|href("/x", "extra")', capabilities=self._caps())
        diags = diagnose(cols, self._schema(), renderer_registry=self._registry())
        assert any(d.code == CODE_RENDERER_ARG_COUNT for d in diags)

    def test_renderer_arg_type(self):
        cols = parse("url as link|href(42)", capabilities=self._caps())
        diags = diagnose(cols, self._schema(), renderer_registry=self._registry())
        assert any(d.code == CODE_RENDERER_ARG_TYPE for d in diags)

    def test_per_renderer_diagnose_hook(self):
        class _HrefWithHook(Renderer):
            arg_schema = (ArgSpec(type=Type.String, required=True),)

            @property
            def name(self) -> str:
                return "href"

            def diagnose(self, arguments, parsed_column):
                if arguments and "{{value}}" not in arguments[0]:
                    return [
                        Diagnostic(
                            range=Range(0, 1),
                            message="href template should contain {{value}}",
                            severity="warning",
                            code="custom_href_no_placeholder",
                        )
                    ]
                return []

        reg = RendererRegistry()
        reg.register(_HrefWithHook())
        cols = parse('url as link|href("/static")', capabilities=self._caps())
        diags = diagnose(cols, self._schema(), renderer_registry=reg)
        assert any(d.code == "custom_href_no_placeholder" for d in diags)

    def test_registry_level_diagnose_hook(self):
        reg = self._registry()

        def chain_hook(parsed_column, chain):
            names = [r["name"] for r in chain]
            if "truncate" in names and "href" in names:
                ti = names.index("truncate")
                hi = names.index("href")
                if ti < hi:
                    return [
                        Diagnostic(
                            range=Range(0, 1),
                            message="href cannot follow truncate",
                            severity="error",
                            code="chain_forbidden",
                        )
                    ]
            return []

        reg.set_diagnose(chain_hook)
        cols = parse('url as link|truncate(10)|href("/x")', capabilities=self._caps())
        diags = diagnose(cols, self._schema(), renderer_registry=reg)
        assert any(d.code == "chain_forbidden" for d in diags)

    def test_none_registry_emits_unknown_renderer(self):
        cols = parse('url as link|href("/x")', capabilities=self._caps())
        diags = diagnose(cols, self._schema(), renderer_registry=None)
        assert len(diags) == 1
        assert diags[0].code == CODE_UNKNOWN_RENDERER


# ---------------------------------------------------------------------------
# Diagnostic.error population (rich error objects)
# ---------------------------------------------------------------------------


def _href_registry() -> RendererRegistry:
    reg = RendererRegistry()

    class _Href(Renderer):
        arg_schema = (ArgSpec(type=Type.String, required=True),)

        @property
        def name(self) -> str:
            return "href"

    reg.register(_Href())
    return reg


_COLUMNS_PAYLOAD_CASES = [
    ("foo", _schema_from_column("level", "string"), CODE_UNKNOWN_COLUMN, False),
    (
        "level|zzzz",
        _schema_from_column("level", "string"),
        CODE_UNKNOWN_TRANSFORMER,
        False,
    ),
    (
        "level|len|upper",
        _schema_from_column("level", "string"),
        CODE_CHAIN_TYPE,
        False,
    ),
    (
        'url as link|wat("/x")',
        _schema_from_column("url", "string"),
        CODE_UNKNOWN_RENDERER,
        True,
    ),
    (
        "url as link|href",
        _schema_from_column("url", "string"),
        CODE_RENDERER_ARG_COUNT,
        True,
    ),
    (
        "url as link|href(123)",
        _schema_from_column("url", "string"),
        CODE_RENDERER_ARG_TYPE,
        True,
    ),
]


@pytest.mark.parametrize(
    "query,schema,expected_code,with_renderer", _COLUMNS_PAYLOAD_CASES
)
def test_columns_diagnostic_error_populated(
    query: str, schema: ColumnSchema, expected_code: str, with_renderer: bool
) -> None:
    caps = (
        {"transformers": True, "renderers": True}
        if with_renderer
        else {"transformers": True}
    )
    cols = parse(query, capabilities=caps)
    rreg = _href_registry() if with_renderer else None
    diags = diagnose(cols, schema, renderer_registry=rreg)
    matching = [d for d in diags if d.code == expected_code]
    assert (
        matching
    ), f"no diagnostic with code {expected_code!r} from {query!r}; got {[d.code for d in diags]}"
    for d in matching:
        assert d.error is not None, f"{d.code}: error is None"
        assert isinstance(d.error, ErrorEntry)
        assert d.error.code == d.code
        assert d.error.name == VALIDATOR_REGISTRY[d.code].name


def test_user_extension_diagnostic_has_no_registry_entry():
    # Decision 7: user-supplied codes (e.g. "custom_href_no_placeholder")
    # produce Diagnostics with error=None — no crash.
    d = Diagnostic(
        range=Range(0, 1),
        message="x",
        severity="warning",
        code="custom_href_no_placeholder",
    )
    assert d.error is None
