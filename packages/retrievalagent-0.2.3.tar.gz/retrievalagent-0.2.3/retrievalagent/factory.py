from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from .core import AgenticRAG

_BACKEND_ALIASES: dict[str, str] = {
    "memory": "InMemoryBackend",
    "in_memory": "InMemoryBackend",
    "inmemory": "InMemoryBackend",
    "chroma": "ChromaDBBackend",
    "chromadb": "ChromaDBBackend",
    "qdrant": "QdrantBackend",
    "lance": "LanceDBBackend",
    "lancedb": "LanceDBBackend",
    "duckdb": "DuckDBBackend",
    "duck": "DuckDBBackend",
    "pgvector": "PgvectorBackend",
    "postgres": "PgvectorBackend",
    "pg": "PgvectorBackend",
    "postgres_fts": "PostgresFTSBackend",
    "pg_fts": "PostgresFTSBackend",
    "sqlite": "SQLiteFTSBackend",
    "sqlite_fts": "SQLiteFTSBackend",
    "meilisearch": "MeilisearchBackend",
    "meili": "MeilisearchBackend",
    "azure": "AzureAISearchBackend",
    "azure_ai_search": "AzureAISearchBackend",
    "azureaisearch": "AzureAISearchBackend",
}

_RERANKER_ALIASES: dict[str, str] = {
    "cohere": "CohereReranker",
    "huggingface": "HuggingFaceReranker",
    "hf": "HuggingFaceReranker",
    "jina": "JinaReranker",
    "llm": "LLMReranker",
    "rerankers": "RerankersReranker",
}


def _build_backend(
    backend_str: str,
    index: str,
    url: str | None,
    embed_fn: Callable[[str], list[float]] | None,
    backend_kwargs: dict[str, Any],
) -> Any:
    cls_name = _BACKEND_ALIASES.get(backend_str.lower())
    if cls_name is None:
        raise ValueError(
            f"Unknown backend {backend_str!r}. "
            f"Choose from: {', '.join(sorted(_BACKEND_ALIASES))}."
        )

    from . import backend as _backend_mod

    cls = getattr(_backend_mod, cls_name)

    import inspect

    sig = inspect.signature(cls.__init__)
    params = set(sig.parameters)

    kw: dict[str, Any] = {}
    if url is not None and "url" in params:
        kw["url"] = url
    if url is not None and "endpoint" in params:
        kw["endpoint"] = url
    if embed_fn is not None and "embed_fn" in params:
        kw["embed_fn"] = embed_fn
    kw.update(backend_kwargs)

    _takes_index = {
        "MeilisearchBackend",
        "ChromaDBBackend",
        "LanceDBBackend",
        "QdrantBackend",
        "DuckDBBackend",
        "PgvectorBackend",
        "PostgresFTSBackend",
        "SQLiteFTSBackend",
        "AzureAISearchBackend",
    }
    if cls_name in _takes_index:
        return cls(index, **kw)
    return cls(**kw)


def _build_collections_map(
    collections: list[str] | dict[str, str],
    *,
    backend_str: str,
    url: str | None,
    embed_fn: Callable[[str], list[float]] | None,
    backend_kwargs: dict[str, Any],
) -> dict[str, Any]:
    names = list(collections.keys() if isinstance(collections, dict) else collections)
    if not names:
        raise ValueError("collections must contain at least one name")
    return {
        name: _build_backend(backend_str, name, url, embed_fn, backend_kwargs)
        for name in names
    }


def _build_reranker(
    reranker_str: str,
    reranker_model: str | None,
    reranker_kwargs: dict[str, Any],
) -> Any:
    cls_name = _RERANKER_ALIASES.get(reranker_str.lower())
    if cls_name is None:
        raise ValueError(
            f"Unknown reranker {reranker_str!r}. "
            f"Choose from: {', '.join(sorted(_RERANKER_ALIASES))}."
        )

    from . import rerankers as _rerankers_mod

    cls = getattr(_rerankers_mod, cls_name)

    import inspect

    sig = inspect.signature(cls.__init__)
    params = set(sig.parameters)

    kw: dict[str, Any] = {}
    if reranker_model is not None and "model" in params:
        kw["model"] = reranker_model
    kw.update(reranker_kwargs)
    return cls(**kw)


def _default_mem0_config() -> dict[str, Any] | None:
    """Auto-build a mem0 config from environment.

    If AZURE_OPENAI_API_KEY is set, build a config that points mem0's
    LLM and embedder at Azure OpenAI (matches our own model wiring).
    Otherwise return None and let mem0 use its OpenAI default
    (requires OPENAI_API_KEY).
    """
    if not os.getenv("AZURE_OPENAI_API_KEY"):
        return None
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    api_key = os.getenv("AZURE_OPENAI_API_KEY", "")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
    chat_deployment = os.getenv(
        "AZURE_OPENAI_DEPLOYMENT", os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT", "")
    )
    embed_deployment = os.getenv(
        "AZURE_OPENAI_EMBEDDING_DEPLOYMENT",
        os.getenv("AZURE_OPENAI_EMBED_DEPLOYMENT", ""),
    )
    if not (endpoint and api_key and chat_deployment and embed_deployment):
        return None
    azure_kwargs_chat = {
        "azure_deployment": chat_deployment,
        "api_key": api_key,
        "api_version": api_version,
        "azure_endpoint": endpoint,
    }
    azure_kwargs_embed = {
        "azure_deployment": embed_deployment,
        "api_key": api_key,
        "api_version": api_version,
        "azure_endpoint": endpoint,
    }
    return {
        "llm": {
            "provider": "azure_openai",
            "config": {
                "model": chat_deployment,
                "azure_kwargs": azure_kwargs_chat,
            },
        },
        "embedder": {
            "provider": "azure_openai",
            "config": {
                "model": embed_deployment,
                "azure_kwargs": azure_kwargs_embed,
            },
        },
    }


def init_agent(
    index: str = "",
    *,
    collections: list[str] | dict[str, str] | None = None,
    model: str | None = None,
    gen_model: str | None = None,
    backend: str | Any | None = None,
    backend_url: str | None = None,
    backend_kwargs: dict[str, Any] | None = None,
    reranker: str | Any | None = None,
    reranker_model: str | None = None,
    reranker_kwargs: dict[str, Any] | None = None,
    embed_fn: Callable[[str], list[float]] | None = None,
    memory: bool | str | Any = False,
    memory_config: dict[str, Any] | None = None,
    **kwargs: Any,
) -> "AgenticRAG":
    """One-line agent builder.

    Memory shortcut:
        memory=True            → mem0.Memory() with default settings
        memory="mem0"          → same
        memory=Memory(...)     → use the provided mem0/AsyncMemory instance
        memory=<langgraph store> → use as memory_store
        memory=False (default) → no long-term memory
    `memory_config` is forwarded to mem0.Memory.from_config when memory=True.
    """
    from .core import AgenticRAG

    memory_kind: str | None = None
    if memory is not False and memory is not None:
        if memory is True or memory == "mem0":
            from mem0 import Memory  # type: ignore[import-untyped]

            cfg = memory_config or _default_mem0_config()
            mem0_instance = Memory.from_config(cfg) if cfg else Memory()
            kwargs.setdefault("mem0_memory", mem0_instance)
            memory_kind = "mem0"
        elif hasattr(memory, "search") or hasattr(memory, "asearch"):
            cls_name = type(memory).__name__.lower()
            if "memory" in cls_name and "store" not in cls_name:
                kwargs.setdefault("mem0_memory", memory)
                memory_kind = f"mem0 ({type(memory).__name__})"
            else:
                kwargs.setdefault("memory_store", memory)
                memory_kind = f"langgraph store ({type(memory).__name__})"
        else:
            raise TypeError(
                f"Unsupported memory= value: {type(memory).__name__}. "
                "Pass True/'mem0', a mem0 Memory/AsyncMemory instance, "
                "or a LangGraph BaseStore."
            )

    if memory_kind:
        import sys as _sys

        print(
            f"[retrievalagent] memory enabled: {memory_kind} "
            "(read-gate=memory_relevance_threshold, "
            "write-gate=memory_storage_threshold; both env-overridable)",
            file=_sys.stderr,
        )

    resolved_backend: Any = None
    resolved_collections: dict[str, Any] | None = None
    collection_descriptions: dict[str, str] | None = None

    if collections is not None:
        if isinstance(collections, dict):
            collection_descriptions = dict(collections)
        resolved_collections = _build_collections_map(
            collections,
            backend_str=backend if isinstance(backend, str) else "memory",
            url=backend_url,
            embed_fn=embed_fn,
            backend_kwargs=backend_kwargs or {},
        )
    elif backend is None or isinstance(backend, str):
        if not index:
            raise ValueError("init_agent requires `index` or `collections`")
        resolved_backend = _build_backend(
            backend or "memory",
            index,
            backend_url,
            embed_fn,
            backend_kwargs or {},
        )
    else:
        resolved_backend = backend

    resolved_reranker: Any | None = None
    if reranker is not None:
        if isinstance(reranker, str):
            resolved_reranker = _build_reranker(
                reranker, reranker_model, reranker_kwargs or {}
            )
        else:
            resolved_reranker = reranker

    def _coerce_model(m: Any) -> Any:
        """Accept either a langchain model string ("openai:gpt-5.4") or
        an already-built BaseChatModel-like instance. Strings go through
        langchain.chat_models.init_chat_model so any provider it supports
        works (openai:, anthropic:, ollama:, vertexai:, azure_openai:, …).
        Temperature is left at the model's default — newer reasoning
        models (gpt-5.x, o1/o3) reject explicit temperatures.
        """
        if isinstance(m, str):
            from langchain.chat_models import (
                init_chat_model,  # type: ignore[import-untyped]
            )

            return init_chat_model(m)
        return m

    if model is not None:
        llm = _coerce_model(model)
        kwargs["llm"] = llm
        kwargs["gen_llm"] = _coerce_model(gen_model) if gen_model else llm
    elif gen_model is not None:
        kwargs["gen_llm"] = _coerce_model(gen_model)

    if embed_fn is not None:
        kwargs.setdefault("embed_fn", embed_fn)

    if resolved_reranker is not None:
        kwargs["reranker"] = resolved_reranker

    if "config" not in kwargs:
        from .config import RAGConfig

        kwargs["config"] = RAGConfig.auto()

    # Long-term memory writes are gated by the LLM final-grade decision.
    # If the user enabled memory but didn't touch final_grade, turn it on
    # automatically — otherwise the write_memory node would never fire.
    if memory_kind and hasattr(kwargs["config"], "enable_final_grade"):
        cfg_obj = kwargs["config"]
        if not cfg_obj.enable_final_grade:
            cfg_obj.enable_final_grade = True

    if resolved_collections is not None:
        return AgenticRAG(
            index=index or ",".join(resolved_collections),
            collections=resolved_collections,
            collection_descriptions=collection_descriptions,
            **kwargs,
        )
    return AgenticRAG(index=index, backend=resolved_backend, **kwargs)
