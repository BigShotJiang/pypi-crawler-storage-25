## 2.4.0.20260518 (2026-05-18)

Upgrade black to 26.5.0 ([#15801](https://github.com/python/typeshed/pull/15801))

## 2.4.0.20260408 (2026-04-08)

Use dashes instead of underscores for METADATA.toml field names ([#15614](https://github.com/python/typeshed/pull/15614))

## 2.4.0.20260402 (2026-04-02)

Rename `requires` to `dependencies` in METADATA files ([#15594](https://github.com/python/typeshed/pull/15594))

## 2.4.0.20251115 (2025-11-15)

[hvac] remove most Incompletes ([#15029](https://github.com/python/typeshed/pull/15029))

## 2.4.0.20251101 (2025-11-01)

[hvac] Update to 2.4.* ([#14953](https://github.com/python/typeshed/pull/14953))

## 2.3.0.20250914 (2025-09-14)

Update mypy to 1.18.1 ([#14699](https://github.com/python/typeshed/pull/14699))

## 2.3.0.20250809 (2025-08-09)

Mark stub-only private symbols as `@type_check_only` in third-party stubs ([#14545](https://github.com/python/typeshed/pull/14545))

## 2.3.0.20250516 (2025-05-16)

Replace `Incomplete | None = None` in third party stubs ([#14063](https://github.com/python/typeshed/pull/14063))

## 2.3.0.20250429 (2025-04-29)

[hvac] Clarify and improve some annotations ([#13886](https://github.com/python/typeshed/pull/13886))

## 2.3.0.20240621 (2024-06-21)

Bump hvac to 2.3.* ([#12168](https://github.com/python/typeshed/pull/12168))

## 2.2.0.20240522 (2024-05-22)

[stubsabot] Bump hvac to 2.2.* ([#11839](https://github.com/python/typeshed/pull/11839))

## 2.1.0.20240514 (2024-05-14)

Complete types for hvac.v1.Client ([#11886](https://github.com/python/typeshed/pull/11886))

## 2.1.0.20240329 (2024-03-29)

Improve hvac adapter types ([#11659](https://github.com/python/typeshed/pull/11659))

## 2.1.0.20240326 (2024-03-26)

Add type stubs for hvac ([#11591](https://github.com/python/typeshed/pull/11591))

