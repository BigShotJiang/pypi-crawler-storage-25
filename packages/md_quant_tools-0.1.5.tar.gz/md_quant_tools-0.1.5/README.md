# Quant Tools Package

A lightweight Python package for quantitative finance calculations, including Black-Scholes pricing, statistical analysis (ADF, Kalman Filter), and optimization methods.

## 1. Installation (For the Developer)

As the author of this package, you will always want to install it from the source code in "editable" mode. This allows you to modify the source files (`pricing.py`, `C++ files`, etc.) and have those changes instantly available across all your projects.

### Case A: Working inside the `md_quant` directory
If you are modifying the package itself, open your terminal in this directory and run:
```bash
pip install -e .
```

### Case B: Using `md_quant` in ANOTHER project on your PC
If you create a new trading algorithm in a completely different folder (e.g., `E:\nouveau_projet_trading`), do NOT copy the files! Instead:
1. Open your terminal in your **new project's directory**.
2. Activate your new project's virtual environment (if you use one).
3. Point `pip` to your master `md_quant` directory using the `-e` (editable) flag:
```bash
pip install -e E:\m.drici\md_quant
```
*Result: Your new project can now `import md_quant`. Any changes you make to `E:\m.drici\md_quant` in the future will automatically update in this new project without needing to reinstall.*

## 2. How to Update

### Code Changes
Since the package is installed in editable mode, you **do not** need to run any commands to update the code. simply save your changes in `params.py`, `stats.py`, etc., and they will be live instantly.

### Adding New Dependencies
If you add a new library to `install_requires` in `setup.py`, you must update the installation:

```bash
pip install -e . --upgrade
```

## 3. Usage

You can import functions from `md_quant` in any Python script on your system, regardless of where the script is located.

### Examples

**Option Pricing (params.py)**
```python
from md_quant.pricing import bs_price, bs_vega, EuropeanOption

# Calculate Price
price = bs_price(S=100, K=100, T=1, r=0.05, sigma=0.2, option_type='call')
```

**Statistical Analysis (stats.py)**
```python
from md_quant.stats import z_score, adf, kalman_dynamic_beta

# Calculate Z-Score
z = z_score(price_series, window=20)
```

**Optimization (optimization.py)**
```python
from md_quant.optimization import newton_raphson, dichotomy
```

## 4. Installation for End Users

If you only need to *use* the `md_quant` package (without seeing the source code or compiling the C++ modules), you can install the pre-compiled version directly from PyPI.

Simply open your terminal and run:
```bash
pip install md-quant-tools
```
This will automatically download and install the pre-compiled binary package matching your operating system.

## 5. Developer: Publishing to PyPI

The publishing process to PyPI is fully automated via GitHub Actions (`build_wheels.yml`). 

**Important Note on Automation:**
J'ai configuré l'automatisation pour qu'elle ne publie pas sur PyPI à chaque petit commit, mais **uniquement quand tu crées une Release / Tag**.

To publish a new version:
1. Update the `version` number in `setup.py`.
2. Commit and push your changes to the `main` branch.
3. Go to GitHub -> **Releases** -> **Create a new release**.
4. Create a new tag (e.g., `v0.1.1`) matching your new version.
5. Click **Publish release**.

GitHub Actions will then automatically compile the C++ wheels for Windows, Mac, and Linux, and upload them securely to PyPI.
