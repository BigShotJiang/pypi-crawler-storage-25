
import numpy as np
from md_quant import pricing

def levenberg_marquardt(residual_func, initial_params, args=(), tol=1e-5, max_iter=100, bounds=None):
    params = np.array(initial_params, dtype=float)
    n_params = len(params)
    lam = 1e-3
    v = 2.0
    residuals = residual_func(params, *args)
    current_cost = 0.5 * np.sum(residuals**2)
    for i in range(max_iter):
        J = np.zeros((len(residuals), n_params))
        epsilon = 1e-5
        for j in range(n_params):
            p_perturbed = params.copy()
            p_perturbed[j] += epsilon
            r_perturbed = residual_func(p_perturbed, *args)
            J[:, j] = (r_perturbed - residuals) / epsilon
        JtJ = J.T @ J
        Jtr = J.T @ residuals
        while True:
            H_damped = JtJ + lam * np.eye(n_params)
            try:
                delta = -np.linalg.solve(H_damped, Jtr)
            except np.linalg.LinAlgError:
                delta = None
            if delta is not None:
                new_params = params + delta
                if bounds:
                    for k, (low, high) in enumerate(bounds):
                        new_params[k] = np.clip(new_params[k], low, high)
                new_residuals = residual_func(new_params, *args)
                new_cost = 0.5 * np.sum(new_residuals**2)
                if new_cost < current_cost:
                    params = new_params
                    residuals = new_residuals
                    current_cost = new_cost
                    lam /= v
                    break
                else:
                    lam *= v
                    if lam > 1e9: break
            else:
                lam *= v
                if lam > 1e9: break
        if np.linalg.norm(Jtr) < tol:
            break
    return params

def calibrate_heston_lm(strikes, market_prices, S0, T, r):
    def residuals(params, strikes, market_prices, S0, T, r):
        v0, kappa, theta, sigma, rho = params
        model_prices = []
        for K in strikes:
            p = pricing.heston_call_price(S0, K, T, r, v0, kappa, theta, sigma, rho)
            # Relative error
            model_prices.append(p / market_prices[strikes == K][0])
        return np.array(model_prices) - 1.0
    bounds = [
        (0.01, 1.0), (0.01, 20.0), (0.01, 1.0), (0.01, 5.0), (-0.99, 0.99)
    ]
    initial_guess = [0.04, 3.0, 0.04, 0.6, -0.7]
    optimized_params = levenberg_marquardt(residuals, initial_guess, args=(strikes, market_prices, S0, T, r), bounds=bounds)
    return optimized_params

def differential_evolution(objective_func, bounds, args=(), pop_size=10, max_iter=100, F=0.5, CR=0.7):
    bounds = np.array(bounds)
    min_b = bounds[:, 0]
    max_b = bounds[:, 1]
    diff = max_b - min_b
    dim = len(bounds)
    population = min_b + np.random.rand(pop_size, dim) * diff
    fitness = np.array([objective_func(ind, *args) for ind in population])
    best_idx = np.argmin(fitness)
    best_vector = population[best_idx].copy()
    best_cost = fitness[best_idx]
    for it in range(max_iter):
        for i in range(pop_size):
            idxs = [idx for idx in range(pop_size) if idx != i]
            a, b, c = population[np.random.choice(idxs, 3, replace=False)]
            mutant = a + F * (b - c)
            mutant = np.clip(mutant, min_b, max_b)
            cross_points = np.random.rand(dim) < CR
            if not np.any(cross_points):
                cross_points[np.random.randint(0, dim)] = True
            trial = np.where(cross_points, mutant, population[i])
            trial_cost = objective_func(trial, *args)
            if trial_cost < fitness[i]:
                population[i] = trial
                fitness[i] = trial_cost
                if trial_cost < best_cost:
                    best_cost = trial_cost
                    best_vector = trial
    return best_vector

def calibrate_heston_de(strikes, market_prices, S0, T, r):
    def residuals_sum_sq(params, strikes, market_prices, S0, T, r):
        v0, kappa, theta, sigma, rho = params
        sse = 0.0
        for i, K in enumerate(strikes):
            model_p = pricing.heston_call_price(S0, K, T, r, v0, kappa, theta, sigma, rho)
            sse += ((model_p - market_prices[i]) / market_prices[i])**2
        return sse
    bounds = [
        (0.01, 1.0), (0.01, 20.0), (0.01, 1.0), (0.01, 5.0), (-0.99, 0.99)
    ]
    optimized_params = differential_evolution(residuals_sum_sq, bounds, args=(strikes, market_prices, S0, T, r), pop_size=15, max_iter=50)
    return optimized_params

def calibrate_heston_hybrid(strikes, market_prices, S0, T, r):
    print("  [Hybrid] Step 1: Differential Evolution (Global search)...")
    def q5_residuals_scalar(params, strikes, market_prices, S0, T, r):
        v0, kappa, theta, sigma, rho = params
        sse = 0.0
        is_T_list = hasattr(T, '__len__')
        for i, K in enumerate(strikes):
            t_val = T[i] if is_T_list else T
            if v0<0 or kappa<0 or theta<0 or sigma<0 or abs(rho)>0.99: return 1e9
            p = pricing.heston_call_price(S0, K, t_val, r, v0, kappa, theta, sigma, rho)
            sse += ((p - market_prices[i]) / market_prices[i])**2
        return sse
    bounds = [
        (0.01, 1.0), (0.01, 20.0), (0.01, 1.0), (0.01, 5.0), (-0.99, 0.99)
    ]
    de_params = differential_evolution(q5_residuals_scalar, bounds, args=(strikes, market_prices, S0, T, r), pop_size=20, max_iter=40)
    print(f"  [Hybrid] DE Params: {de_params}")
    print("  [Hybrid] Step 2: Levenberg-Marquardt (Refinement)...")
    def q5_residuals_vector(params, strikes, market_prices, S0, T, r):
        v0, kappa, theta, sigma, rho = params
        model_prices = []
        is_T_list = hasattr(T, '__len__')
        for i, K in enumerate(strikes):
            t_val = T[i] if is_T_list else T
            p = pricing.heston_call_price(S0, K, t_val, r, v0, kappa, theta, sigma, rho)
            model_prices.append(p / market_prices[i])
        return np.array(model_prices) - 1.0
    refined_params = levenberg_marquardt(q5_residuals_vector, de_params, args=(strikes, market_prices, S0, T, r), bounds=bounds, max_iter=30)
    return refined_params
