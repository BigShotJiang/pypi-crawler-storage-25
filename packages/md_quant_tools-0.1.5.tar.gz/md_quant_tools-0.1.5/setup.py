import sys
import os
from setuptools import setup, find_packages
from pybind11.setup_helpers import Pybind11Extension

sources = [
    "src/optimization.cpp",
    "src/rolling_ols.cpp",
    "src/lets_be_rational.cpp",
    "src/normaldistribution.cpp",
    "src/rationalcubic.cpp",
    "src/erf_cody.cpp"
]

extra_compile_args = ['/utf-8', '/DNO_XL_API'] if sys.platform == 'win32' else ['-DNO_XL_API']

ext_modules = [
    Pybind11Extension(
        "md_quant._cpp_core",
        sources,
        include_dirs=["src"],
        cxx_std=17,
        extra_compile_args=extra_compile_args
    ),
]

setup(
    name="md-quant-tools",
    version="0.1.5",
    packages=find_packages(),
    ext_modules=ext_modules,
    install_requires=[
        "numpy",
        "pandas",
        "scipy",
        "matplotlib",
        "seaborn",
        "statsmodels",
        "pybind11>=2.4",
    ],
    author="M. Drici",
    description="Quantitative Finance Tools",
    zip_safe=False,
)
