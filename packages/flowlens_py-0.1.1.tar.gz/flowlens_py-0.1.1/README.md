# FlowLens 🔍

**FlowLens** is a Python tracing engine designed to audit the logical execution of algorithms. It transforms code execution into an interactive HTML report, allowing you to visualize process flow, response times, and the nature of every operation.

## Key Features 🚀

*   **Visual Traceability**: Converts complex logic into a clear, step-by-step visual timeline.
*   **Performance Monitoring**: Automatically tracks execution time for every tracked function.
*   **Process Categorization**: Identifies and labels internal calculations versus data outputs.
*   **Zero Configuration UI**: Generates a clean, modern HTML report that opens automatically in your browser.

## Installation 🛠️

You can install FlowLens directly from PyPI:
```bash
pip install flowlens


from flowlens import lens

@lens.track_stats
def my_algorithm(data):
    # Your logic here
    return "Result"

if __name__ == "__main__":
    lens.start()
    my_algorithm("Hello World")
    lens.stop()