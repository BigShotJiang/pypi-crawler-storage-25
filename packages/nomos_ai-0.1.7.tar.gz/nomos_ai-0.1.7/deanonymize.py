#!/usr/bin/env python3
"""
NomosAI – Désanonymiseur (restauration à partir d'un index)
=============================================================
Remplace les placeholders d'un document anonymisé ([PERSONNE_1], [EMAIL_2]…)
par les valeurs originales stockées dans le fichier index généré lors de
l'anonymisation.

L'index attendu est le fichier `<nom>-index.md` produit par anonymize.py.
Il peut aussi s'agir d'un index créé manuellement avec le même format de
tableau Markdown.

Utilisation :
    # Index auto-détecté  (<fichier_anonymise>-index.md)
    python deanonymize.py contrat_anonymise.md

    # Index explicite
    python deanonymize.py contrat_anonymise.md --index contrat_anonymise-index.md

    # Sortie explicite
    python deanonymize.py contrat_anonymise.md --output contrat_restaure.md

    # Dossier complet (chaque .md + son -index.md voisin)
    python deanonymize.py dossier_anonymise/ --output dossier_restaure/

⚠  Ce script restaure des données personnelles.
   Réservez-le aux personnes habilitées à accéder aux données originales.
"""

import argparse
import re
import sys
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Parsing de l'index
# ---------------------------------------------------------------------------

# Ligne de tableau Markdown :  | `[PLACEHOLDER]` | valeur originale | `TYPE` |
_ROW_RE = re.compile(
    r"^\|\s*`(\[[^\]]+\])`\s*\|\s*(.*?)\s*\|\s*`[^`]+`\s*\|$"
)


def parse_index(index_path: Path) -> dict[str, str]:
    """
    Lit un fichier index (-index.md) et retourne le mapping
    placeholder → valeur originale.

    Les caractères `|` dans la valeur originale sont stockés comme ``\\|`` dans
    l'index ; on les restaure ici.
    """
    content = index_path.read_text(encoding="utf-8")
    mapping: dict[str, str] = {}

    for line in content.splitlines():
        m = _ROW_RE.match(line.strip())
        if not m:
            continue
        placeholder = m.group(1)          # ex. [PERSONNE_1]
        original    = m.group(2).strip()  # valeur, peut être vide
        # Restaurer les échappements écrits par _write_index
        original = original.replace(r"\|", "|").replace(r"\n", "\n")
        mapping[placeholder] = original

    if not mapping:
        sys.exit(
            f"[ERREUR] Aucun placeholder trouvé dans l'index : {index_path}\n"
            "Vérifiez que le fichier est bien un index NomosAI (-index.md)."
        )

    return mapping


# ---------------------------------------------------------------------------
# Restauration d'un texte
# ---------------------------------------------------------------------------

def restore_text(text: str, mapping: dict[str, str]) -> str:
    """
    Remplace tous les placeholders connus dans `text` par leur valeur
    originale.

    Ordre de remplacement : les placeholders les plus longs en premier pour
    éviter que `[PERSONNE_1]` ne soit remplacé avant `[PERSONNE_10]`
    (ce qui laisserait `0]` dans le texte).
    """
    # Tri par longueur décroissante du placeholder (ex. PERSONNE_10 avant PERSONNE_1)
    for placeholder in sorted(mapping, key=len, reverse=True):
        original = mapping[placeholder]
        text = text.replace(placeholder, original)
    return text


# ---------------------------------------------------------------------------
# Traitement d'un fichier
# ---------------------------------------------------------------------------

def _resolve_index(doc_path: Path, index_arg: Optional[Path]) -> Path:
    """Retourne le chemin de l'index à utiliser."""
    if index_arg:
        if not index_arg.exists():
            sys.exit(f"[ERREUR] Index introuvable : {index_arg}")
        return index_arg

    # Convention : <stem>-index.md voisin du fichier anonymisé
    candidate = doc_path.with_name(doc_path.stem + "-index.md")
    if candidate.exists():
        return candidate

    sys.exit(
        f"[ERREUR] Index non trouvé pour {doc_path.name}\n"
        f"Chemin attendu : {candidate}\n"
        "Utilisez --index <chemin> pour en spécifier un explicitement."
    )


def process_file(
    doc_path: Path,
    output_path: Path,
    index_path: Optional[Path],
    verbose: bool = True,
) -> int:
    """
    Restaure un fichier anonymisé.
    Retourne le nombre de placeholders remplacés.
    """
    idx_path = _resolve_index(doc_path, index_path)
    mapping  = parse_index(idx_path)

    text     = doc_path.read_text(encoding="utf-8")
    restored = restore_text(text, mapping)

    # Compter les remplacements effectifs
    replaced = sum(text.count(ph) for ph in mapping if ph in text)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(restored, encoding="utf-8")

    if verbose:
        print(f"  Index         : {idx_path.name}  ({len(mapping)} entrées)")
        print(f"  Remplace      : {replaced} occurrence(s) -> {output_path}")

    return replaced


# ---------------------------------------------------------------------------
# Traitement d'un dossier
# ---------------------------------------------------------------------------

def process_folder(
    input_dir: Path,
    output_dir: Path,
    recursive: bool,
) -> None:
    """Restaure tous les .md d'un dossier qui ont un -index.md voisin."""
    pattern = "**/*.md" if recursive else "*.md"
    candidates = [
        f for f in input_dir.glob(pattern)
        if f.is_file()
        and not f.name.endswith("-index.md")
        and f.with_name(f.stem + "-index.md").exists()
    ]

    if not candidates:
        print(f"Aucun fichier .md avec index trouvé dans {input_dir}")
        return

    print(f"\nDossier source  : {input_dir}")
    print(f"Dossier sortie  : {output_dir}")
    print(f"Fichiers trouvés: {len(candidates)}\n")

    errors: list[str] = []
    for i, doc in enumerate(candidates, 1):
        rel = doc.relative_to(input_dir)
        out = output_dir / rel
        print(f"[{i}/{len(candidates)}] {rel}")
        try:
            process_file(doc, out, index_path=None, verbose=True)
        except SystemExit as e:
            print(f"  [SAUTÉ] {e}", file=sys.stderr)
            errors.append(str(rel))
        except Exception as e:
            print(f"  [ERREUR] {e}", file=sys.stderr)
            errors.append(str(rel))
        print()

    print(f"Terminé — {len(candidates) - len(errors)}/{len(candidates)} fichier(s) restauré(s).")
    if errors:
        print("Échecs :", ", ".join(errors))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Restaure un document anonymisé NomosAI en remplaçant les "
            "placeholders ([PERSONNE_1], [EMAIL_2]…) par les valeurs "
            "originales stockées dans l'index."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "input",
        type=Path,
        help="Fichier .md anonymisé ou dossier contenant des fichiers anonymisés",
    )
    parser.add_argument(
        "-i", "--index",
        type=Path,
        default=None,
        metavar="INDEX",
        help=(
            "Fichier index (-index.md) à utiliser. "
            "Par défaut : <input_stem>-index.md dans le même répertoire."
        ),
    )
    parser.add_argument(
        "-o", "--output",
        type=Path,
        default=None,
        metavar="SORTIE",
        help=(
            "Fichier ou dossier de sortie. "
            "Par défaut : <input_stem>_restaure.md (fichier) "
            "ou <input>_restaure/ (dossier)."
        ),
    )
    parser.add_argument(
        "-r", "--recursive",
        action="store_true",
        help="Parcourt les sous-dossiers (mode dossier uniquement)",
    )
    parser.add_argument(
        "-q", "--quiet",
        action="store_true",
        help="Réduit la verbosité",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    input_path: Path = args.input.resolve()

    if not input_path.exists():
        sys.exit(f"[ERREUR] Introuvable : {input_path}")

    # ── Mode dossier ──────────────────────────────────────────────────────────
    if input_path.is_dir():
        if args.index:
            sys.exit("[ERREUR] --index n'est pas compatible avec le mode dossier.")
        output_dir = args.output or input_path.parent / (input_path.name + "_restaure")
        process_folder(input_path, output_dir.resolve(), recursive=args.recursive)
        return

    # ── Mode fichier unique ───────────────────────────────────────────────────
    if input_path.suffix.lower() != ".md":
        sys.exit(
            f"[ERREUR] Ce script attend un fichier .md anonymisé "
            f"(reçu : {input_path.suffix!r})."
        )

    output_path = args.output or input_path.with_name(
        input_path.stem.removesuffix("_anonymise") + "_restaure.md"
    )
    if not args.quiet:
        print(f"Restauration de  : {input_path.name}")
    process_file(
        input_path,
        output_path.resolve(),
        index_path=args.index,
        verbose=not args.quiet,
    )


if __name__ == "__main__":
    main()
