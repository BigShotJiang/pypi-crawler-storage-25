"""
Moteur d'anonymisation Presidio.

Fonctionnalités clés :
  - Support natif du français (fr_core_news_lg) + reconnaisseurs personnalisés
  - Placeholders numérotés et stables : [PERSON_1], [PERSON_2]…
    La même entité source reçoit toujours le même placeholder dans un document.
  - Collecte des statistiques de détection pour le rapport d'anonymisation.
"""

import re
import subprocess
import sys
from typing import Optional
from collections import defaultdict

from nomosai.recognizers_fr import get_french_recognizers, FRENCH_ENTITY_LABELS
from nomosai.readers import Block


# ---------------------------------------------------------------------------
# Labels globaux (entités Presidio standard → label lisible)
# ---------------------------------------------------------------------------

ENTITY_LABELS: dict[str, str] = {
    "PERSON":             "PERSONNE",
    "EMAIL_ADDRESS":      "EMAIL",
    "PHONE_NUMBER":       "TELEPHONE",
    "LOCATION":           "ADRESSE",
    "IP_ADDRESS":         "IP",
    "URL":                "URL",
    "CREDIT_CARD":        "CARTE_BANCAIRE",
    "IBAN_CODE":          "IBAN",
    "US_SSN":             "SSN",
    "DATE_TIME":          "DATE",
    "NRP":                "ID_NATIONAL",
    "MEDICAL_LICENSE":    "LICENCE_MEDICALE",
    "CRYPTO":             "CRYPTO",
    "ORGANIZATION":       "ORGANISATION",
    **FRENCH_ENTITY_LABELS,
}

# Entités activées par défaut.
# DATE_TIME : rarement PII seul et génère du bruit dans les rapports.
# FILE_PATH  : masqué seulement si l'utilisateur l'active explicitement
#              (sauf si le chemin contient un nom de personne — hors portée regex).
_ENTITIES_OPT_IN = {"DATE_TIME", "FILE_PATH"}

DEFAULT_ENTITIES = [e for e in ENTITY_LABELS if e not in _ENTITIES_OPT_IN]

# Score minimum par type d'entité (au-dessus du seuil global --score-threshold).
# spaCy fr_core_news_lg sur-détecte LOCATION dans les tableaux PDF et les données
# structurées → on relève son seuil minimum.
_ENTITY_MIN_SCORES: dict[str, float] = {
    "LOCATION":       0.80,   # trop de faux positifs dans texte structuré
    "FR_SIREN":       0.70,   # 9 chiffres ambigus sans contexte
    "FR_CNI":         0.70,   # 12 chiffres ambigus
    "FR_POSTAL_CODE": 0.70,   # 5 chiffres très ambigus
}

# ---------------------------------------------------------------------------
# Filtres de faux positifs évidents (indépendants du type d'entité)
# Ces patterns ne devraient jamais être traités comme des PII.
# ---------------------------------------------------------------------------

# Types d'entités intrinsèquement numériques : le filtre "valeur numérique pure"
# NE doit PAS s'appliquer à eux (un SIRET ou un numéro de téléphone est bien
# une séquence de chiffres et d'espaces mais c'est une PII valide).
_NUMERIC_ENTITY_TYPES: frozenset[str] = frozenset({
    "PHONE_NUMBER", "FR_SIRET", "FR_SIREN", "FR_NIR",
    "FR_TVA", "FR_CNI", "FR_POSTAL_CODE", "IBAN_CODE", "CREDIT_CARD",
})

_FP_PATTERNS: list[re.Pattern] = [
    re.compile(r"^[A-Za-zÀ-ÿ]$"),                     # lettre seule  (F, P, E…)
    re.compile(r"^[A-Za-zÀ-ÿ]{1,3}$"),                # sigle ≤ 3 car. (NR, NC, ET…)
    re.compile(r"^\.{2,}$"),                           # séparateur ……
    re.compile(r"^[IVXivx]+\.\d"),                     # numéro de section  II.4
    re.compile(r"^[A-Z]{1,2}\.\d"),                    # numéro de section  I.1
    re.compile(r"^[b-c]-\s*$"),                        # étiquette de liste  b-  c-
    re.compile(r"^[~\-–—]+$"),                         # tiret/tilde seul
]

# Patterns numériques : uniquement pour les types NON numériques.
# Un SIRET (14 chiffres avec espaces) passerait sinon dans "valeur numérique pure".
_FP_NUMERIC_PATTERNS: list[re.Pattern] = [
    re.compile(r"^\d[\d\s,.\-]*$"),          # valeur numérique pure  14 800 €
    re.compile(r"^[Nn]\s*[=:]\s*[\d\s]+$"),  # effectif  N=1 035
    re.compile(r"^n\s*=\s*[\d\s]+$"),        # effectif  n=5 991
]


# Patterns supplémentaires applicables uniquement à PERSON
_FP_PERSON_PATTERNS: list[re.Pattern] = [
    # Fragments en majuscules issus de tables (≥ 2 mots tout en caps)
    # ex. « REPARTITION DE LA », « RENAUX PORTEURS D »
    re.compile(r"^(?:[A-ZÀÂÉÈÊËÎÏÔÙÛÜ]{2,}\s+){1,}[A-ZÀÂÉÈÊËÎÏÔÙÛÜ]*$"),
    # Artefacts OCR : lettres isolées séparées par des espaces  « nais s ance »
    re.compile(r"(?<!\w)[a-z]\s[a-z](?!\w)"),
    # Fragments de phrase commençant en minuscule
    re.compile(r"^[a-zàâéèêëîïôùûü]"),
    # Numéro de section ou identifiant alphanumérique seul  « II.3 » « III.5 »
    re.compile(r"^[IVXivx]+\.\d"),
    # Syntagme se terminant par une préposition/article français
    # « Travaux de », « Signé par », « Mise en », « Née le », « Contient des »
    re.compile(
        r"\s+(?:de|d[u']|des|par|le|la|les|en|au|aux|une?|leur[s]?|avec|sur|sous|dans|et|ou|pour)$",
        re.IGNORECASE,
    ),
    # Commence par article défini/indéfini + nom commun → fragment de phrase
    # « Le débiteur », « La cuisine », « Je vous »  (uppercase après = vrai nom propre)
    re.compile(r"^(?:Je|Le|La|Les|Une?|Du|Des)\s+[a-zàâéèêëîïôùûü]"),
    # En-tête de section romaine avec lettre : « IV. Pièce », « XI. Fondement »
    # (le pattern existant ne couvre que les cas « II.4 » avec chiffre)
    re.compile(r"^[IVXivx]+\.\s+[A-Za-zÀ-ÿ]"),
    # Étiquettes de champs et termes génériques jamais synonymes d'un prénom
    re.compile(
        r"^(?:Adresse|Appartement|Agence|Pièce|Devis|Signé[e]?|Établi[e]?|Mode"
        r"|Constat|Merci|Niveau|Fin|Née?|Représentée?|Identification|Date)\b",
        re.IGNORECASE,
    ),
    # Grade militaire/civil utilisé comme nom de rue (jamais un prénom)
    # « Maréchal Foch », « Général de Gaulle », « Amiral Dupont »
    re.compile(
        r"^(?:Maréchal|Général|Amiral|Colonel|Commandant|Lieutenant|Capitaine|Sergent)\b",
        re.IGNORECASE,
    ),
    # Désignation judiciaire/administrative : mot + lettre capitale seule en fin
    # « Lyon B », « Paris A » → code de greffe, pas un nom propre
    re.compile(r"\s+[A-Z]$"),
    # Salutation seule sans prénom : « Monsieur », « Madame »
    re.compile(r"^(?:Monsieur|Madame|Mademoiselle|Bonjour|Cordialement)$", re.IGNORECASE),
]

# Patterns de faux positifs spécifiques à LOCATION
# spaCy sur-détecte des abréviations et formules de politesse comme des lieux.
_FP_LOCATION_PATTERNS: list[re.Pattern] = [
    re.compile(r"^[A-Z]{2,6}$"),   # sigle tout-caps : IBAN, TVA, SIRET…
    re.compile(r"^[A-Z]{2}\d"),     # préfixe IBAN/code pays : FR76, DE49…
    # Fragment de désignation judiciaire/administrative : « Lyon B », « Paris A »
    re.compile(r"\s+[A-Z]$"),
]

# Mots français courants jamais synonymes d'un nom de lieu
_FP_LOCATION_WORDS: frozenset[str] = frozenset({
    "cordialement", "préjudices", "préjudice", "dommages", "dommage",
})

# Mots/expressions jamais synonymes d'une organisation
_FP_ORGANIZATION_WORDS: frozenset[str] = frozenset({
    "téléphone", "banque", "email", "adresse", "fax", "mobile", "internet",
    "préjudice", "préjudice moral", "dommages", "dommage",
})


def _is_false_positive(text: str, entity_type: str = "") -> bool:
    """Retourne True si le texte est un faux positif évident pour le type donné."""
    stripped = text.strip()
    if not stripped:
        return True
    if len(stripped) <= 1:
        return True
    if any(p.fullmatch(stripped) for p in _FP_PATTERNS):
        return True
    # Les patterns numériques ne filtrent pas les types intrinsèquement numériques
    # (SIRET, PHONE, NIR…) pour lesquels une séquence de chiffres EST la PII.
    if entity_type not in _NUMERIC_ENTITY_TYPES:
        if any(p.fullmatch(stripped) for p in _FP_NUMERIC_PATTERNS):
            return True
    if entity_type == "PERSON":
        for p in _FP_PERSON_PATTERNS:
            if p.search(stripped):
                return True
    if entity_type == "LOCATION":
        if any(p.search(stripped) for p in _FP_LOCATION_PATTERNS):
            return True
        if stripped.lower() in _FP_LOCATION_WORDS:
            return True
    if entity_type == "ORGANIZATION":
        if stripped.lower() in _FP_ORGANIZATION_WORDS:
            return True
    return False


def _deduplicate_spans(results: list, text: str) -> list:
    """
    Élimine les spans qui se chevauchent APRÈS filtrage.

    Pourquoi c'est indispensable :
    La boucle de remplacement travaille de droite à gauche sur la MÊME chaîne
    `anonymized` en utilisant les indices de l'original.  Si deux spans
    (A=[0,17] et B=[3,17]) passent tous les deux le filtre, remplacer B en
    premier allonge/raccourcit `anonymized`, et le `end` de A pointe ensuite
    au mauvais endroit → corruption du type "[PERSONNE_15]ONNE_14]".

    Stratégie : pour chaque groupe de spans qui se chevauchent, garder celui
    qui a le meilleur score, puis la plus grande longueur à égalité.
    """
    if not results:
        return results

    # Priorité : score desc, puis longueur (span plus englobant) desc
    ranked = sorted(results, key=lambda r: (r.score, r.end - r.start), reverse=True)
    accepted: list = []
    for r in ranked:
        overlaps = any(r.start < a.end and r.end > a.start for a in accepted)
        if not overlaps:
            accepted.append(r)
    return accepted


# ---------------------------------------------------------------------------
# Installation automatique du modèle spaCy si absent
# ---------------------------------------------------------------------------

_SPACY_MODEL_WHEELS: dict[str, str] = {
    "fr_core_news_lg": "https://github.com/explosion/spacy-models/releases/download/fr_core_news_lg-3.8.0/fr_core_news_lg-3.8.0-py3-none-any.whl",
    "en_core_web_lg":  "https://github.com/explosion/spacy-models/releases/download/en_core_web_lg-3.8.0/en_core_web_lg-3.8.0-py3-none-any.whl",
}


def _ensure_spacy_model(model_name: str) -> None:
    import spacy
    if spacy.util.is_package(model_name):
        return

    wheel = _SPACY_MODEL_WHEELS.get(model_name, model_name)
    print(f"Téléchargement du modèle spaCy {model_name!r}…", file=sys.stderr)

    # uv pip (environnements gérés par uv, sans pip)
    try:
        subprocess.run(
            ["uv", "pip", "install", "--python", sys.executable, wheel],
            check=True,
        )
        return
    except (FileNotFoundError, subprocess.CalledProcessError):
        pass

    # pip classique (environnements pip)
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", wheel],
            check=True,
        )
        return
    except subprocess.CalledProcessError:
        pass

    sys.exit(
        f"Impossible d'installer le modèle spaCy {model_name!r}.\n"
        f"Lancez manuellement : uv pip install {wheel}"
    )


# ---------------------------------------------------------------------------
# Construction de l'analyseur
# ---------------------------------------------------------------------------

def build_analyzer(language: str = "fr"):
    """Crée un AnalyzerEngine Presidio avec le modèle spaCy approprié."""
    try:
        from presidio_analyzer import AnalyzerEngine
        from presidio_analyzer.nlp_engine import NlpEngineProvider
    except ImportError:
        sys.exit("Dépendance manquante : pip install presidio-analyzer")

    spacy_models = {
        "fr": "fr_core_news_lg",
        "en": "en_core_web_lg",
        "de": "de_core_news_lg",
        "es": "es_core_news_lg",
        "it": "it_core_news_lg",
        "nl": "nl_core_news_lg",
        "pt": "pt_core_news_lg",
    }
    model_name = spacy_models.get(language, f"{language}_core_news_lg")
    _ensure_spacy_model(model_name)

    provider = NlpEngineProvider(nlp_configuration={
        "nlp_engine_name": "spacy",
        "models": [{"lang_code": language, "model_name": model_name}],
    })
    nlp_engine = provider.create_engine()

    analyzer = AnalyzerEngine(
        nlp_engine=nlp_engine,
        supported_languages=[language],
    )

    # Ajout des reconnaisseurs français
    if language == "fr":
        registry = analyzer.registry
        for recognizer in get_french_recognizers():
            registry.add_recognizer(recognizer)

    return analyzer


# ---------------------------------------------------------------------------
# Anonymisation avec placeholders numérotés
# ---------------------------------------------------------------------------

class DocumentAnonymizer:
    """
    Anonymise un document en préservant la cohérence des références :
    la même entité source reçoit toujours le même placeholder numéroté.

    Exemple : "Jean Dupont" → "[PERSONNE_1]" partout dans le document.
    """

    def __init__(self, analyzer, language: str = "fr", score_threshold: float = 0.55):
        self.analyzer = analyzer
        self.language = language
        self.score_threshold = score_threshold

        # Mapping : (entity_type, original_lower) → placeholder "[TYPE_N]"
        self._registry: dict[tuple[str, str], str] = {}
        # Valeur originale (casse préservée) par placeholder
        self._originals: dict[str, str] = {}
        # Compteurs par type
        self._counters: dict[str, int] = defaultdict(int)
        # Statistiques : entity_type → count occurrences
        self.stats: dict[str, int] = defaultdict(int)

    def reset(self):
        """Réinitialise pour un nouveau document."""
        self._registry.clear()
        self._originals.clear()
        self._counters.clear()
        self.stats.clear()

    def load_index(self, entries: list[dict]) -> None:
        """
        Pré-charge un index existant pour garantir la cohérence des placeholders
        entre plusieurs documents d'un même projet.

        Les entrées doivent avoir les clés : placeholder, original, entity_type.
        Le compteur de chaque type est calé sur le numéro le plus élevé déjà utilisé.
        """
        _num_re = re.compile(r"_(\d+)\]$")
        for entry in entries:
            entity_type = entry.get("entity_type", "")
            original = entry.get("original", "")
            placeholder = entry.get("placeholder", "")
            if not (entity_type and original and placeholder):
                continue
            key = (entity_type, original.lower().strip())
            self._registry[key] = placeholder
            self._originals[placeholder] = original.strip()
            m = _num_re.search(placeholder)
            if m:
                n = int(m.group(1))
                if self._counters[entity_type] < n:
                    self._counters[entity_type] = n

    def _get_placeholder(self, entity_type: str, original: str) -> str:
        label = ENTITY_LABELS.get(entity_type, entity_type)
        key = (entity_type, original.lower().strip())
        if key not in self._registry:
            self._counters[entity_type] += 1
            placeholder = f"[{label}_{self._counters[entity_type]}]"
            self._registry[key] = placeholder
            self._originals[placeholder] = original.strip()
        return self._registry[key]

    def get_index(self) -> list[dict]:
        """
        Retourne la liste des correspondances placeholder ↔ valeur originale,
        triées par type d'entité puis par numéro.

        Chaque élément : {"placeholder": str, "original": str, "entity_type": str, "label": str}
        """
        entries = []
        for (entity_type, _), placeholder in self._registry.items():
            entries.append({
                "placeholder": placeholder,
                "original": self._originals.get(placeholder, ""),
                "entity_type": entity_type,
                "label": ENTITY_LABELS.get(entity_type, entity_type),
            })
        entries.sort(key=lambda e: (e["label"], e["placeholder"]))
        return entries

    def anonymize_text(
        self,
        text: str,
        entities: Optional[list[str]] = None,
    ) -> str:
        if not text.strip():
            return text

        target_entities = entities or DEFAULT_ENTITIES

        results = self.analyzer.analyze(
            text=text,
            language=self.language,
            entities=target_entities,
            score_threshold=self.score_threshold,
        )

        if not results:
            return text

        # ── Phase 1 : filtres (score par entité + faux positifs) ──────────────
        candidates = []
        for r in results:
            min_score = _ENTITY_MIN_SCORES.get(r.entity_type)
            if min_score is not None and r.score < min_score:
                continue
            if _is_false_positive(text[r.start:r.end], r.entity_type):
                continue
            candidates.append(r)

        if not candidates:
            return text

        # ── Phase 2 : déduplication des spans chevauchants ───────────────────
        # Indispensable : deux recognizers peuvent retourner des spans qui se
        # recouvrent partiellement.  Remplacer de droite à gauche avec des
        # indices issus du texte original devient incorrect dès qu'un span
        # précédent a modifié la longueur de la chaîne → corruption du type
        # "[PERSONNE_15]ONNE_14]".
        candidates = _deduplicate_spans(candidates, text)

        # ── Phase 3 : remplacement de droite à gauche ────────────────────────
        # Les indices sont stables car on traite les positions décroissantes
        # et les spans sont garantis non-chevauchants après la phase 2.
        candidates_sorted = sorted(candidates, key=lambda r: r.start, reverse=True)

        anonymized = text
        for r in candidates_sorted:
            original = text[r.start:r.end]
            placeholder = self._get_placeholder(r.entity_type, original)
            anonymized = anonymized[:r.start] + placeholder + anonymized[r.end:]
            self.stats[r.entity_type] += 1

        return anonymized

    def anonymize_blocks(
        self,
        blocks: list[Block],
        entities: Optional[list[str]] = None,
    ) -> list[Block]:
        """Anonymise une liste de blocs en place (retourne de nouveaux blocs)."""
        from nomosai.readers import Block as _Block
        result = []
        for block in blocks:
            anonymized_text = self.anonymize_text(block.text, entities)
            # Pour les tableaux, anonymiser aussi les cellules
            new_cells = None
            if block.cells:
                new_cells = [
                    [self.anonymize_text(cell, entities) for cell in row]
                    for row in block.cells
                ]
                # Reconstruire le texte depuis les cellules anonymisées
                anonymized_text = "\n".join(" | ".join(row) for row in new_cells)
            result.append(_Block(type=block.type, text=anonymized_text, cells=new_cells))
        return result
