#!/usr/bin/env python3
"""
NomosAI MCP Server
==================
Expose les capacités d'anonymisation de NomosAI comme outils MCP pour agents LLM.

Transport : stdio (par défaut, compatible Claude Desktop / Claude Code)

Outils disponibles :
    anonymize_file   — traite un fichier (.docx, .pdf, .txt, .md, .rst), écrit le .md anonymisé
    list_entities    — liste les types de PII disponibles avec leurs descriptions

Usage :
    uvx nomos-ai

Configuration Claude Desktop (%APPDATA%\\Claude\\claude_desktop_config.json) :
    {
      "mcpServers": {
        "nomos-ai": {
          "command": "uvx",
          "args": ["nomos-ai"]
        }
      }
    }
"""

import datetime
import json
import re
import threading
from pathlib import Path
from typing import Optional

from mcp.server.fastmcp import FastMCP, Context
from pydantic import create_model, Field

from nomosai.engine import (
    build_analyzer,
    DocumentAnonymizer,
    DEFAULT_ENTITIES,
    ENTITY_LABELS,
)
from nomosai.readers import read_document, SUPPORTED_EXTENSIONS
from nomosai.formatter import to_markdown


# ---------------------------------------------------------------------------
# Serveur MCP
# ---------------------------------------------------------------------------

mcp = FastMCP(
    name="nomos-ai",
    instructions=(
        "Serveur d'anonymisation NomosAI.\n\n"
        "CONFIDENTIALITÉ : utilisez toujours anonymize_file avec le chemin du fichier — "
        "le contenu brut ne circule jamais dans le contexte LLM.\n\n"
        "SÉLECTION DES ENTITÉS avant chaque appel à anonymize_file :\n"
        "  • Demande générique (pas d'entités précisées)\n"
        "    → anonymize_file(elicit_entities=True)\n"
        "    L'utilisateur choisit parmi 8 catégories via un formulaire.\n"
        "  • Entités explicitement nommées par l'utilisateur\n"
        "    → anonymize_file(entities=[<codes>]) avec les codes du tableau ci-dessous.\n"
        "  • 'Par défaut' / 'comme d'habitude'\n"
        "    → anonymize_file() sans entities ni elicit_entities.\n\n"
        "CATÉGORIES ET CODES D'ENTITÉS :\n"
        "  Personnes     PERSON\n"
        "  Identité¹     FR_NIR  FR_CNI  FR_PASSPORT  FR_DRIVING_LICENSE  MEDICAL_LICENSE\n"
        "  Organisations ORGANIZATION  FR_SIRET  FR_SIREN  FR_TVA\n"
        "  Contacts      EMAIL_ADDRESS  PHONE_NUMBER\n"
        "  Localisation  LOCATION  FR_POSTAL_CODE\n"
        "  Financier     IBAN_CODE  CREDIT_CARD\n"
        "  Web           URL  IP_ADDRESS\n"
        "  Opt-in²       DATE_TIME  FILE_PATH\n"
        "¹ Entités françaises uniquement (language='fr').\n"
        "² Désactivées par défaut — à activer explicitement si demandé.\n\n"
        "Formats supportés : .docx .pdf .txt .md .rst"
    ),
)


# ---------------------------------------------------------------------------
# Cache des analyseurs (build_analyzer est coûteux : ~5-10s par langue)
# ---------------------------------------------------------------------------

_analyzer_cache: dict[str, object] = {}
_cache_lock = threading.Lock()

SUPPORTED_LANGUAGES = {"fr", "en", "de", "es", "it", "nl", "pt"}

_SPACY_MODELS = {
    "fr": "fr_core_news_lg",
    "en": "en_core_web_lg",
    "de": "de_core_news_lg",
    "es": "es_core_news_lg",
    "it": "it_core_news_lg",
    "nl": "nl_core_news_lg",
    "pt": "pt_core_news_lg",
}

_OPT_IN_ENTITIES = {"DATE_TIME", "FILE_PATH"}

_FRENCH_ONLY = {
    "FR_NIR", "FR_SIRET", "FR_SIREN", "FR_TVA",
    "FR_PASSPORT", "FR_CNI", "FR_DRIVING_LICENSE", "FR_POSTAL_CODE",
    "FILE_PATH",
}

_ENTITY_DESCRIPTIONS = {
    "PERSON":             "Noms de personnes physiques",
    "ORGANIZATION":       "Noms d'organisations ou entreprises",
    "LOCATION":           "Lieux géographiques, adresses",
    "EMAIL_ADDRESS":      "Adresses e-mail",
    "PHONE_NUMBER":       "Numéros de téléphone",
    "IBAN_CODE":          "Codes IBAN bancaires",
    "CREDIT_CARD":        "Numéros de carte de crédit",
    "MEDICAL_LICENSE":    "Licences médicales",
    "URL":                "URLs et liens web",
    "IP_ADDRESS":         "Adresses IP",
    "FR_NIR":             "Numéro INSEE / Sécurité Sociale (15 chiffres)",
    "FR_SIRET":           "SIRET — identifiant établissement (14 chiffres)",
    "FR_SIREN":           "SIREN — identifiant entreprise (9 chiffres)",
    "FR_TVA":             "Numéro TVA intracommunautaire",
    "FR_PASSPORT":        "Numéro de passeport français",
    "FR_CNI":             "Carte Nationale d'Identité (12 chiffres)",
    "FR_DRIVING_LICENSE": "Permis de conduire format post-2013 (AA-NNN-AA)",
    "FR_POSTAL_CODE":     "Code postal français (avec contexte)",
    "DATE_TIME":          "Dates et heures — opt-in, génèrent du bruit par défaut",
    "FILE_PATH":          "Chemins de fichiers Windows/Unix — opt-in",
}

# (field_name, label, entities_covered, default_on)
_ENTITY_GROUPS: list[tuple[str, str, list[str], bool]] = [
    (
        "personnes",
        "Personnes — noms et prénoms",
        ["PERSON"],
        True,
    ),
    (
        "identite",
        "Documents d'identité — NIR/sécu, CNI, passeport, permis, licences",
        ["FR_NIR", "FR_CNI", "FR_PASSPORT", "FR_DRIVING_LICENSE", "MEDICAL_LICENSE"],
        True,
    ),
    (
        "organisations",
        "Organisations — noms, SIRET, SIREN, TVA",
        ["ORGANIZATION", "FR_SIRET", "FR_SIREN", "FR_TVA"],
        True,
    ),
    (
        "contacts",
        "Coordonnées — e-mails et téléphones",
        ["EMAIL_ADDRESS", "PHONE_NUMBER"],
        True,
    ),
    (
        "localisation",
        "Localisation — lieux, adresses, codes postaux",
        ["LOCATION", "FR_POSTAL_CODE"],
        True,
    ),
    (
        "financier",
        "Données financières — IBAN et cartes bancaires",
        ["IBAN_CODE", "CREDIT_CARD"],
        True,
    ),
    (
        "web",
        "Identifiants numériques — URLs et adresses IP",
        ["URL", "IP_ADDRESS"],
        True,
    ),
    (
        "dates_et_fichiers",
        "Dates / chemins de fichiers (opt-in — peuvent générer du bruit)",
        ["DATE_TIME", "FILE_PATH"],
        False,
    ),
]


def _build_entity_schema(language: str) -> type:
    """Construit un modèle Pydantic à 7-8 catégories pour l'élicitation groupée."""
    fields: dict = {}
    for field_name, label, entities, default in _ENTITY_GROUPS:
        available = [e for e in entities if e not in _FRENCH_ONLY or language == "fr"]
        if not available:
            continue
        fields[field_name] = (bool, Field(default=default, description=label))
    return create_model("EntitySelection", **fields)


def _resolve_group_entities(groups_data: dict, language: str) -> list[str]:
    """Traduit la sélection par catégories en liste de types d'entités."""
    result: list[str] = []
    for field_name, _, entities, default in _ENTITY_GROUPS:
        if not groups_data.get(field_name, default):
            continue
        for entity in entities:
            if entity in _FRENCH_ONLY and language != "fr":
                continue
            if entity not in result:
                result.append(entity)
    return result


def _get_analyzer(language: str):
    """Retourne l'analyseur Presidio pour la langue, en le construisant une seule fois."""
    if language not in _analyzer_cache:
        with _cache_lock:
            if language not in _analyzer_cache:
                _analyzer_cache[language] = build_analyzer(language)
    return _analyzer_cache[language]


def _validate_entities(entities: Optional[list[str]]) -> tuple[list[str], list[str]]:
    """Retourne (entités_valides, entités_inconnues)."""
    if entities is None:
        return DEFAULT_ENTITIES, []
    all_known = set(ENTITY_LABELS.keys())
    valid = [e for e in entities if e in all_known]
    unknown = [e for e in entities if e not in all_known]
    return (valid if valid else DEFAULT_ENTITIES), unknown


_GLOBAL_INDEX_NAME = "_nomos_index.md"
_GLOBAL_ROW_RE = re.compile(r"^\|\s*`(\[[^\]]+\])`\s*\|\s*(.*?)\s*\|\s*`([^`]+)`\s*\|$")


def _find_confidential_dir(input_path: Path, output_path: Path) -> Optional[Path]:
    """Localise le répertoire documents-confidentiels/ du projet NomosAI.

    Cherche d'abord dans les ancêtres du fichier d'entrée (cas typique : le fichier
    est dans documents-confidentiels/ ou ses sources sont dans un projet NomosAI initié).
    Cherche ensuite dans les ancêtres du fichier de sortie.
    """
    for path in (input_path, output_path):
        for ancestor in path.parents:
            if ancestor.name == "documents-confidentiels" and ancestor.is_dir():
                return ancestor
        for ancestor in path.parents:
            candidate = ancestor / "documents-confidentiels"
            if candidate.is_dir():
                return candidate
    return None


def _read_global_index(conf_dir: Path) -> list[dict]:
    """Lit _nomos_index.md depuis documents-confidentiels/ et retourne les entrées existantes."""
    index_path = conf_dir / _GLOBAL_INDEX_NAME
    if not index_path.exists():
        return []
    entries = []
    try:
        for line in index_path.read_text(encoding="utf-8").splitlines():
            m = _GLOBAL_ROW_RE.match(line.strip())
            if not m:
                continue
            placeholder = m.group(1)
            original = m.group(2).strip().replace(r"\|", "|").replace(r"\n", "\n")
            entity_type = m.group(3).strip()
            if placeholder and original and entity_type:
                from nomosai.engine import ENTITY_LABELS as _EL
                entries.append({
                    "placeholder": placeholder,
                    "original": original,
                    "entity_type": entity_type,
                    "label": _EL.get(entity_type, entity_type),
                })
    except Exception:
        pass
    return entries


def _merge_index_entries(existing: list[dict], new: list[dict]) -> list[dict]:
    """Fusionne deux listes d'entrées d'index (clé unique = placeholder)."""
    merged = {e["placeholder"]: e for e in existing}
    for entry in new:
        merged[entry["placeholder"]] = entry
    return list(merged.values())


def _write_global_index(conf_dir: Path, entries: list[dict]) -> Path:
    """Écrit (ou met à jour) _nomos_index.md dans documents-confidentiels/."""
    index_path = conf_dir / _GLOBAL_INDEX_NAME
    date_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "---",
        f"generated: {date_str}",
        f"total_entities: {len(entries)}",
        "---",
        "",
        "# Index global d'anonymisation NomosAI",
        "",
        "> Ce fichier est **confidentiel** — il contient les données personnelles originales.",
        "> Ne pas inclure dans les exports anonymisés.",
        "",
        "| Placeholder | Valeur originale | Entité |",
        "| --- | --- | --- |",
    ]
    for entry in sorted(entries, key=lambda e: (e.get("label", ""), e["placeholder"])):
        original = (
            entry["original"]
            .replace("|", "\\|")
            .replace("\r\n", "\\n")
            .replace("\n", "\\n")
            .replace("\r", "\\n")
        )
        lines.append(f"| `{entry['placeholder']}` | {original} | `{entry['entity_type']}` |")
    lines += ["", "---", ""]
    index_path.write_text("\n".join(lines), encoding="utf-8")
    return index_path


# ---------------------------------------------------------------------------
# Gabarits pour initiate_project
# ---------------------------------------------------------------------------

_HOOK_SCRIPT = '''\
#!/usr/bin/env python3
"""Hook NomosAI — bloque la lecture directe dans documents-confidentiels/"""
import json
import pathlib
import sys


def main() -> None:
    try:
        data = json.load(sys.stdin)
    except Exception:
        sys.exit(0)

    path_str = data.get("file_path", data.get("path", ""))
    if not path_str:
        sys.exit(0)

    try:
        parts = pathlib.PurePath(path_str).parts
    except Exception:
        sys.exit(0)

    if "documents-confidentiels" in parts:
        print("BLOQUE : Lecture directe interdite dans documents-confidentiels/", file=sys.stderr)
        print("Ce dossier contient des donnees a caractere personnel (DCP).", file=sys.stderr)
        print("Utilisez anonymize_file via le serveur MCP nomos-ai.", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
'''


def _build_claude_md(project_name: str) -> str:
    return f"""\
# {project_name}

Ce projet est un espace de travail juridique assisté par IA.
L'agent est configuré pour des tâches bureaucratiques : recherche sémantique,
rédaction et édition de textes juridiques. Le code informatique ne doit être
produit que si explicitement demandé ou strictement nécessaire, et tout
artefact doit être supprimé dès que possible.

## Structure du projet

| Répertoire                    | Rôle                                                                         |
|-------------------------------|------------------------------------------------------------------------------|
| `documents-confidentiels/`    | Documents originaux pouvant contenir des DCP — lecture directe **interdite** |
| `sources/`                    | Documents sources lisibles directement: publics ou non confidentiels         |
| `documents-anonymisés/`       | Documents anonymisés produits par NomosAI                                    |
| `livrables/`                  | Livrables finaux en cours de production                                      |
| `artefacts/`                  | Fichiers temporaires produits par l'agent (à nettoyer dès que possible)      |

## documents-confidentiels/

Contient des documents potentiellement confidentiels avec des données à caractère
personnel (DCP). **L'agent ne doit jamais lire directement le contenu de ces fichiers.**

Actions autorisées :
- Lister les fichiers présents (`ls documents-confidentiels/`)
- Traiter les fichiers via le serveur MCP `nomos-ai` (outil `anonymize_file`)

Un hook de sécurité bloque automatiquement la lecture directe via les outils Claude Code.
Les commandes shell de lecture directe (cat, type…) sont également à proscrire.

## sources/

Documents sources que l'agent peut lire et analyser directement.
Ces documents ne contiennent pas de DCP ou ont été anonymisés au préalable.

## documents-anonymisés/

Répertoire de sortie des documents anonymisés par NomosAI.
L'agent peut lire et écrire dans ce répertoire.
Les fichiers ici proviennent du traitement par `anonymize_file`.

## livrables/

Livrables finaux destinés à être remis ou partagés.
L'agent y dépose les documents aboutis issus de son travail.

## artefacts/

Fichiers temporaires produits par l'agent lors de l'exécution de tâches
(scripts, fichiers intermédiaires, conversions, etc.).
**Supprimer ces fichiers dès qu'ils ne sont plus nécessaires** afin de garder
l'espace de travail propre.

## Règles générales

1. **Tâches documentaires uniquement** : recherche sémantique, rédaction et
   édition de textes juridiques. Ne pas produire de code sauf si explicitement
   demandé ou strictement nécessaire à la réalisation de la tâche.
2. **Confidentialité** : ne jamais exposer le contenu de `documents-confidentiels/` dans
   le contexte LLM. Utiliser exclusivement `anonymize_file` via le MCP `nomos-ai`.
3. **Nettoyage** : les artefacts dans `artefacts/` doivent être supprimés dès
   qu'ils ne sont plus utiles.
"""


def _build_settings() -> str:
    settings = {
        "hooks": {
            "PreToolUse": [
                {
                    "matcher": "Read|Edit",
                    "hooks": [
                        {
                            "type": "command",
                            "command": "python .claude/hooks/block_confidentiel.py",
                        }
                    ],
                }
            ]
        }
    }
    return json.dumps(settings, indent=2, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Outils MCP
# ---------------------------------------------------------------------------

@mcp.tool()
async def anonymize_file(
    ctx: Context,
    file_path: str,
    output_path: Optional[str] = None,
    language: str = "fr",
    entities: Optional[list[str]] = None,
    elicit_entities: bool = False,
    score_threshold: float = 0.55,
    write_index: bool = True,
) -> dict:
    """
    Anonymise un fichier document (.docx, .pdf, .txt, .md, .rst).

    Lit le document, détecte et remplace les PII, puis écrit un fichier Markdown
    anonymisé avec frontmatter YAML. Génère optionnellement
    un fichier d'index confidentiel (placeholder → valeur originale).

    Args:
        ctx: Contexte MCP (injecté automatiquement par FastMCP).
        file_path: Chemin absolu ou relatif vers le document source.
        output_path: Chemin du fichier .md de sortie. Par défaut : <nom>_anonymise.md.
        language: Code langue — 'fr' (défaut), 'en', 'de', 'es', 'it', 'nl', 'pt'.
        entities: Types d'entités à détecter. None = tous les types par défaut.
        elicit_entities: Si True et entities est None, présente un formulaire interactif
            pour que l'utilisateur choisisse les types d'entités. Ignoré si entities
            est fourni. Défaut False.
        score_threshold: Seuil de confiance 0.0–1.0 (défaut 0.55).
        write_index: Écrire le fichier d'index confidentiel (défaut True).

    Returns:
        dict avec : success, input_path, output_path, index_path, stats, total_entities
    """
    input_p = Path(file_path).resolve()

    if not input_p.exists():
        return {
            "success": False,
            "error_type": "FileNotFound",
            "error": f"Fichier introuvable : {input_p}",
        }

    suffix = input_p.suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        return {
            "success": False,
            "error_type": "UnsupportedFormat",
            "error": (
                f"Format '{suffix}' non supporté. "
                f"Supportés : {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
            ),
        }

    if language not in SUPPORTED_LANGUAGES:
        return {
            "success": False,
            "error_type": "UnsupportedLanguage",
            "error": f"Langue '{language}' non supportée. Supportées : {sorted(SUPPORTED_LANGUAGES)}",
        }

    elicitation_fallback = False
    if elicit_entities and entities is None:
        EntitySchema = _build_entity_schema(language)
        try:
            elicit_result = await ctx.elicit(
                message=(
                    "Cochez ou décochez les catégories à anonymiser, "
                    "puis confirmez avec Accepter — ou Refuser pour utiliser les réglages par défaut."
                ),
                schema=EntitySchema,
            )
            if elicit_result.action == "accept" and elicit_result.data is not None:
                entities = _resolve_group_entities(elicit_result.data.model_dump(), language)
            else:
                elicitation_fallback = True
        except Exception:
            elicitation_fallback = True

    out_p = (
        Path(output_path).resolve()
        if output_path
        else input_p.with_name(input_p.stem + "_anonymise.md")
    )

    valid_entities, unknown = _validate_entities(entities)

    try:
        analyzer = _get_analyzer(language)
    except OSError as e:
        model = _SPACY_MODELS.get(language, f"{language}_core_news_lg")
        return {
            "success": False,
            "error_type": "SpacyModelMissing",
            "error": f"Exécutez : python -m spacy download {model}",
            "detail": str(e),
        }

    try:
        blocks = read_document(input_p)
    except Exception as e:
        return {"success": False, "error_type": "ReadError", "error": str(e)}

    if not blocks:
        return {
            "success": False,
            "error_type": "EmptyDocument",
            "error": f"Aucun texte extrait de {input_p.name}",
        }

    conf_dir = _find_confidential_dir(input_p, out_p)

    anonymizer = DocumentAnonymizer(
        analyzer,
        language=language,
        score_threshold=score_threshold,
    )

    # Pré-charge l'index global pour garantir la cohérence des placeholders
    # entre tous les documents du projet.
    existing_entries: list[dict] = []
    if conf_dir:
        existing_entries = _read_global_index(conf_dir)
        if existing_entries:
            anonymizer.load_index(existing_entries)

    try:
        anon_blocks = anonymizer.anonymize_blocks(blocks, valid_entities)
        md = to_markdown(
            anon_blocks,
            source_path=input_p,
            language=language,
            stats=dict(anonymizer.stats),
            score_threshold=score_threshold,
        )
        out_p.parent.mkdir(parents=True, exist_ok=True)
        out_p.write_text(md, encoding="utf-8")
    except Exception as e:
        return {"success": False, "error_type": "AnonymizationError", "error": str(e)}

    index_path_str = None
    if write_index:
        try:
            target_dir = conf_dir if conf_dir else out_p.parent
            all_entries = _merge_index_entries(existing_entries, anonymizer.get_index())
            idx_p = _write_global_index(target_dir, all_entries)
            index_path_str = str(idx_p)
        except Exception:
            pass  # non bloquant : l'anonymisation a réussi

    result = {
        "success": True,
        "input_path": str(input_p),
        "output_path": str(out_p),
        "index_path": index_path_str,
        "format_detected": suffix,
        "stats": dict(anonymizer.stats),
        "total_entities": sum(anonymizer.stats.values()),
        "language": language,
        "score_threshold": score_threshold,
    }
    if unknown:
        result["warnings"] = [f"Types d'entités inconnus ignorés : {unknown}"]
    if elicitation_fallback:
        result["elicitation_fallback"] = True
    return result


@mcp.tool()
def deanonymize_file(
    anonymized_file_path: str,
    index_path: Optional[str] = None,
    output_path: Optional[str] = None,
) -> dict:
    """
    Restaure un document anonymisé NomosAI en remplaçant les placeholders
    ([PERSONNE_1], [EMAIL_2]…) par les valeurs originales stockées dans l'index.

    L'index est le fichier confidentiel <nom>-index.md généré lors de l'anonymisation.
    Si index_path est absent, il est cherché automatiquement à côté du fichier anonymisé
    sous le nom <stem>-index.md.

    Args:
        anonymized_file_path: Chemin vers le fichier .md anonymisé.
        index_path: Chemin vers le fichier index (-index.md). Auto-détecté si absent.
        output_path: Chemin de sortie. Par défaut : <stem>_restaure.md.

    Returns:
        dict avec : success, input_path, index_path, output_path, replacements_count
    """
    _ROW_RE = re.compile(
        r"^\|\s*`(\[[^\]]+\])`\s*\|\s*(.*?)\s*\|\s*`[^`]+`\s*\|$"
    )

    doc_p = Path(anonymized_file_path).resolve()

    if not doc_p.exists():
        return {
            "success": False,
            "error_type": "FileNotFound",
            "error": f"Fichier introuvable : {doc_p}",
        }

    if doc_p.suffix.lower() != ".md":
        return {
            "success": False,
            "error_type": "InvalidFormat",
            "error": f"Le fichier doit être un .md anonymisé (reçu : {doc_p.suffix!r})",
        }

    # Résolution de l'index
    if index_path:
        idx_p = Path(index_path).resolve()
        if not idx_p.exists():
            return {
                "success": False,
                "error_type": "FileNotFound",
                "error": f"Index introuvable : {idx_p}",
            }
    else:
        # 1. Index global NomosAI dans documents-confidentiels/ (nouveau comportement)
        conf_dir = _find_confidential_dir(doc_p, doc_p)
        global_idx = (conf_dir / _GLOBAL_INDEX_NAME) if conf_dir else None
        # 2. Ancien index par document à côté du fichier (rétrocompatibilité)
        legacy_idx = doc_p.with_name(doc_p.stem + "-index.md")

        if global_idx and global_idx.exists():
            idx_p = global_idx
        elif legacy_idx.exists():
            idx_p = legacy_idx
        else:
            return {
                "success": False,
                "error_type": "IndexNotFound",
                "error": (
                    f"Aucun index trouvé (cherché : {global_idx}, {legacy_idx}).\n"
                    "Utilisez index_path pour en spécifier un explicitement."
                ),
            }

    # Parsing de l'index
    try:
        content = idx_p.read_text(encoding="utf-8")
        mapping: dict[str, str] = {}
        for line in content.splitlines():
            m = _ROW_RE.match(line.strip())
            if not m:
                continue
            placeholder = m.group(1)
            original = m.group(2).strip().replace(r"\|", "|").replace(r"\n", "\n")
            mapping[placeholder] = original
    except Exception as e:
        return {"success": False, "error_type": "IndexParseError", "error": str(e)}

    if not mapping:
        return {
            "success": False,
            "error_type": "EmptyIndex",
            "error": f"Aucun placeholder trouvé dans l'index : {idx_p}",
        }

    # Restauration du texte
    try:
        text = doc_p.read_text(encoding="utf-8")
        replacements = sum(text.count(ph) for ph in mapping)
        # Remplacer les plus longs en premier (évite [PERSONNE_1] avant [PERSONNE_10])
        for placeholder in sorted(mapping, key=len, reverse=True):
            text = text.replace(placeholder, mapping[placeholder])

        stem = doc_p.stem.removesuffix("_anonymise")
        out_p = Path(output_path).resolve() if output_path else doc_p.with_name(stem + "_restaure.md")
        out_p.parent.mkdir(parents=True, exist_ok=True)
        out_p.write_text(text, encoding="utf-8")
    except Exception as e:
        return {"success": False, "error_type": "RestoreError", "error": str(e)}

    return {
        "success": True,
        "input_path": str(doc_p),
        "index_path": str(idx_p),
        "output_path": str(out_p),
        "entries_in_index": len(mapping),
        "replacements_count": replacements,
    }


@mcp.tool()
def list_entities(language: str = "fr") -> dict:
    """
    Liste tous les types de PII que NomosAI peut détecter.

    Ne nécessite pas de chargement d'analyseur — répond instantanément.
    Les entités FR_* sont uniquement disponibles avec language='fr'.
    Les entités opt-in (DATE_TIME, FILE_PATH) doivent être explicitement
    listées dans le paramètre 'entities' de anonymize_file.

    Args:
        language: Code langue pour filtrer les entités pertinentes.

    Returns:
        dict avec : default_entities, opt_in_entities, total_default, total_opt_in
    """
    default_list = []
    opt_in_list = []

    for entity_type, label in ENTITY_LABELS.items():
        is_opt_in = entity_type in _OPT_IN_ENTITIES
        is_french_only = entity_type in _FRENCH_ONLY

        if is_french_only and language != "fr":
            continue

        entry = {
            "entity_type": entity_type,
            "label": label,
            "description": _ENTITY_DESCRIPTIONS.get(entity_type, ""),
            "opt_in": is_opt_in,
        }
        if is_french_only:
            entry["french_only"] = True

        if is_opt_in:
            opt_in_list.append(entry)
        else:
            default_list.append(entry)

    return {
        "language": language,
        "default_entities": default_list,
        "opt_in_entities": opt_in_list,
        "total_default": len(default_list),
        "total_opt_in": len(opt_in_list),
        "note": (
            "Les entités opt_in doivent être explicitement listées dans le paramètre "
            "'entities' pour être activées."
        ),
    }


@mcp.tool()
def initiate_project(
    directory: str,
    project_name: Optional[str] = None,
) -> dict:
    """
    Initialise un espace de travail juridique NomosAI dans le répertoire spécifié.

    Crée la structure de répertoires standard, un fichier CLAUDE.md avec les
    instructions de l'agent, et un hook de sécurité qui bloque la lecture
    directe des fichiers dans le dossier documents-confidentiels/.

    Structure créée :
        documents-confidentiels/   — Documents confidentiels (DCP) : traitement via nomos-ai MCP uniquement
        sources/                   — Documents sources lisibles directement par l'agent
        documents-anonymisés/      — Sorties anonymisées produites par NomosAI
        livrables/                 — Livrables finaux en cours de production
        artefacts/                 — Fichiers temporaires produits par l'agent (à nettoyer)
        .claude/settings.json      — Hook bloquant la lecture directe de documents-confidentiels/
        CLAUDE.md                  — Instructions de l'agent pour ce projet

    Args:
        directory: Chemin absolu ou relatif vers le répertoire du projet.
                   Le répertoire est créé s'il n'existe pas.
        project_name: Nom du projet (titre du CLAUDE.md). Défaut : nom du répertoire.

    Returns:
        dict avec : success, project_path, created_dirs, claude_md_path, hook_path, settings_path
    """
    project_path = Path(directory).resolve()

    try:
        project_path.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return {
            "success": False,
            "error_type": "DirectoryCreateError",
            "error": f"Impossible de créer le répertoire : {e}",
        }

    name = project_name or project_path.name

    subdirs = ["documents-confidentiels", "sources", "documents-anonymisés", "livrables", "artefacts"]
    created_dirs: list[str] = []
    for subdir in subdirs:
        subdir_path = project_path / subdir
        try:
            subdir_path.mkdir(exist_ok=True)
            created_dirs.append(str(subdir_path))
        except Exception as e:
            return {
                "success": False,
                "error_type": "DirectoryCreateError",
                "error": f"Impossible de créer {subdir}/ : {e}",
                "created_dirs": created_dirs,
            }

    hooks_dir = project_path / ".claude" / "hooks"
    try:
        hooks_dir.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return {
            "success": False,
            "error_type": "DirectoryCreateError",
            "error": f"Impossible de créer .claude/hooks/ : {e}",
        }

    hook_script_path = hooks_dir / "block_confidentiel.py"
    try:
        hook_script_path.write_text(_HOOK_SCRIPT, encoding="utf-8")
    except Exception as e:
        return {
            "success": False,
            "error_type": "FileWriteError",
            "error": f"Impossible d'écrire le script de hook : {e}",
        }

    settings_path = project_path / ".claude" / "settings.json"
    try:
        settings_path.write_text(_build_settings(), encoding="utf-8")
    except Exception as e:
        return {
            "success": False,
            "error_type": "FileWriteError",
            "error": f"Impossible d'écrire settings.json : {e}",
        }

    claude_md_path = project_path / "CLAUDE.md"
    try:
        claude_md_path.write_text(_build_claude_md(name), encoding="utf-8")
    except Exception as e:
        return {
            "success": False,
            "error_type": "FileWriteError",
            "error": f"Impossible d'écrire CLAUDE.md : {e}",
        }

    return {
        "success": True,
        "project_path": str(project_path),
        "project_name": name,
        "created_dirs": created_dirs,
        "claude_md_path": str(claude_md_path),
        "hook_path": str(hook_script_path),
        "settings_path": str(settings_path),
        "message": (
            f"Projet '{name}' initialisé. "
            "Le hook bloque la lecture directe de documents-confidentiels/ (outils Read et Edit). "
            "Placez les documents confidentiels dans documents-confidentiels/ et utilisez "
            "anonymize_file via nomos-ai MCP pour les traiter."
        ),
    }


# ---------------------------------------------------------------------------
# Warm-up : charge le modèle français en arrière-plan au démarrage
# ---------------------------------------------------------------------------

def _warmup() -> None:
    # subprocess output must be suppressed: stdout is the MCP stdio channel and
    # any stray bytes corrupt the JSON-RPC stream.
    import subprocess, sys
    try:
        _get_analyzer("fr")
    except OSError:
        # spaCy model absent — download silently so no output leaks to stdout.
        subprocess.run(
            [sys.executable, "-m", "spacy", "download", "fr_core_news_lg"],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            _get_analyzer("fr")
        except Exception:
            pass
    except Exception:
        pass


threading.Thread(target=_warmup, daemon=True, name="nomos-warmup").start()


# ---------------------------------------------------------------------------
# Point d'entrée
# ---------------------------------------------------------------------------

def main():
    mcp.run()


if __name__ == "__main__":
    main()
