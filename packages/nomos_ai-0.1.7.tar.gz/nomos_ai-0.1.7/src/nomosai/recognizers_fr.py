"""
Reconnaisseurs Presidio pour les entités personnelles françaises.

Entités couvertes :
  FR_NIR            Numéro de Sécurité Sociale (INSEE)
  FR_SIRET          Identifiant établissement (14 chiffres)
  FR_SIREN          Identifiant entreprise (9 chiffres)
  FR_TVA            Numéro TVA intracommunautaire
  FR_PASSPORT       Passeport français
  FR_CNI            Carte Nationale d'Identité
  FR_DRIVING_LICENSE Permis de conduire (format post-2013)
  FR_POSTAL_CODE    Code postal (avec contexte)
  PHONE_NUMBER      Numéros français (local, +33, 0033)
  FILE_PATH         Chemins de fichiers Windows ou Unix
  PERSON            Noms précédés d'un titre civil/médical (Pr/Dr/M./Mme)
"""

from presidio_analyzer import PatternRecognizer, Pattern


# ---------------------------------------------------------------------------
# NIR – Numéro de Sécurité Sociale
# Règle : [1-2 ou 1-3 pour cas spéciaux] + AA + MM + DEP + COM + ORD + CLE
# Format compact 15 chiffres ou espacé par groupes
# ---------------------------------------------------------------------------

_NIR_PATTERN = (
    r"\b"
    r"[12789]"                              # sexe
    r"\s?[0-9]{2}"                          # année
    r"\s?(?:0[1-9]|1[0-2]|20)"             # mois (01-12 ou 20=inconnu)
    r"\s?(?:2[AB]|97[1-6]|[0-9]{2})"       # département (métropole, DOM, 2A/2B)
    r"\s?[0-9]{3}"                          # commune
    r"\s?[0-9]{3}"                          # ordre
    r"\s?[0-9]{2}"                          # clé
    r"\b"
)

NIR_RECOGNIZER = PatternRecognizer(
    supported_entity="FR_NIR",
    name="French NIR Recognizer",
    supported_language="fr",
    patterns=[Pattern("NIR", _NIR_PATTERN, score=0.85)],
    context=[
        "numéro de sécurité sociale", "n° sécurité sociale",
        "nss", "nir", "sécu", "sécurité sociale",
        "assurance maladie", "carte vitale",
    ],
)


# ---------------------------------------------------------------------------
# SIRET (14 chiffres) et SIREN (9 chiffres)
# Le SIRET contient le SIREN, donc on détecte d'abord le SIRET.
# ---------------------------------------------------------------------------

SIRET_RECOGNIZER = PatternRecognizer(
    supported_entity="FR_SIRET",
    name="French SIRET Recognizer",
    supported_language="fr",
    patterns=[
        Pattern("SIRET_SPACED", r"\b[0-9]{3}[\s.\-]?[0-9]{3}[\s.\-]?[0-9]{3}[\s.\-]?[0-9]{5}\b", score=0.75),
    ],
    context=["siret", "n° siret", "numéro siret", "établissement"],
)

SIREN_RECOGNIZER = PatternRecognizer(
    supported_entity="FR_SIREN",
    name="French SIREN Recognizer",
    supported_language="fr",
    patterns=[
        Pattern("SIREN_SPACED", r"\b[0-9]{3}[\s.\-]?[0-9]{3}[\s.\-]?[0-9]{3}\b", score=0.55),
    ],
    context=["siren", "n° siren", "numéro siren", "rcs", "registre du commerce"],
)


# ---------------------------------------------------------------------------
# TVA intracommunautaire française : FR + 2 alphanum + 9 chiffres SIREN
# ---------------------------------------------------------------------------

TVA_RECOGNIZER = PatternRecognizer(
    supported_entity="FR_TVA",
    name="French TVA Recognizer",
    supported_language="fr",
    patterns=[
        # La norme exclut O et I du code à 2 caractères (confusion avec 0 et 1).
        # Séparateurs optionnels tolérés dans le SIREN pour les formats imprimés.
        Pattern("FR_TVA", r"\bFR\s?[A-HJ-NP-Z0-9]{2}\s?[0-9]{3}[\s.\-]?[0-9]{3}[\s.\-]?[0-9]{3}\b", score=0.85),
    ],
    context=["tva", "tva intracommunautaire", "n° tva", "numéro de tva"],
)


# ---------------------------------------------------------------------------
# Téléphone français
# Formats : 0X XX XX XX XX, +33X XX XX XX XX, 0033X XX XX XX XX
# ---------------------------------------------------------------------------

# Séparateurs possibles entre les groupes de chiffres dans un numéro français.
# Le PDF peut produire des espaces insécables (\xa0) ou des espaces fine (\u202f)
# à la place des espaces ordinaires → le \s de Python re ne les couvre pas
# toujours selon la locale.  On les liste explicitement.
_SEP = r"[\s\xa0\u202f.\-]?"

PHONE_FR_RECOGNIZER = PatternRecognizer(
    supported_entity="PHONE_NUMBER",
    name="French Phone Recognizer",
    supported_language="fr",
    patterns=[
        Pattern("FR_PHONE_LOCAL",  rf"\b0[1-9](?:{_SEP}[0-9]{{2}}){{4}}\b",                score=0.75),
        # \b ne fonctionne pas avant "+" (non-word) → on utilise un lookbehind (?<!\d)
        Pattern("FR_PHONE_INTL",   rf"(?<!\d)\+33{_SEP}[1-9](?:{_SEP}[0-9]{{2}}){{4}}\b", score=0.85),
        Pattern("FR_PHONE_00",     rf"\b0033{_SEP}[1-9](?:{_SEP}[0-9]{{2}}){{4}}\b",       score=0.85),
    ],
)


# ---------------------------------------------------------------------------
# Passeport français : 2 chiffres + 2 lettres + 5 chiffres (post-2006)
# ex. 06AB12345
# ---------------------------------------------------------------------------

PASSPORT_FR_RECOGNIZER = PatternRecognizer(
    supported_entity="FR_PASSPORT",
    name="French Passport Recognizer",
    supported_language="fr",
    patterns=[
        Pattern("FR_PASSPORT", r"\b[0-9]{2}[A-Z]{2}[0-9]{5}\b", score=0.75),
    ],
    context=["passeport", "n° passeport", "numéro de passeport", "passport"],
)


# ---------------------------------------------------------------------------
# Carte Nationale d'Identité
# Format : 12 chiffres (depuis 1988)
# ---------------------------------------------------------------------------

CNI_RECOGNIZER = PatternRecognizer(
    supported_entity="FR_CNI",
    name="French CNI Recognizer",
    supported_language="fr",
    patterns=[
        Pattern("FR_CNI", r"\b[0-9]{12}\b", score=0.55),
    ],
    context=[
        "carte d'identité", "cni", "carte nationale", "pièce d'identité",
        "n° carte", "numéro carte", "ci n°",
    ],
)


# ---------------------------------------------------------------------------
# Permis de conduire post-2013 : AA-NNN-AA
# ---------------------------------------------------------------------------

DRIVING_LICENSE_FR_RECOGNIZER = PatternRecognizer(
    supported_entity="FR_DRIVING_LICENSE",
    name="French Driving License Recognizer",
    supported_language="fr",
    patterns=[
        Pattern("FR_DL", r"\b[A-Z]{2}-[0-9]{3}-[A-Z]{2}\b", score=0.75),
    ],
    context=["permis de conduire", "n° permis", "numéro de permis", "permis b"],
)


# ---------------------------------------------------------------------------
# Code postal (avec contexte obligatoire pour éviter les faux positifs)
# ---------------------------------------------------------------------------

POSTAL_CODE_FR_RECOGNIZER = PatternRecognizer(
    supported_entity="FR_POSTAL_CODE",
    name="French Postal Code Recognizer",
    supported_language="fr",
    patterns=[
        # Métropole (depts 01-95) : 2 chiffres dept + 3 chiffres ordre = 5 chiffres
        # DOM (depts 971-976)     : 3 chiffres dept + 2 chiffres ordre = 5 chiffres
        Pattern(
            "FR_POSTAL",
            r"\b(?:(?:0[1-9]|[1-8][0-9]|9[0-5])[0-9]{3}|97[1-6][0-9]{2})\b",
            score=0.50,
        ),
    ],
    context=[
        "code postal", "cedex", "bp ", "boîte postale", " cedex ", " cs ",
        # Mots d'adresse courants qui signalent la présence d'un code postal
        "adresse", "siège", "domicile", "résidence", "situé", "située",
        "avenue", "boulevard", "rue", "allée", "impasse", "chemin", "route",
    ],
)


# ---------------------------------------------------------------------------
# IBAN français (format regex uniquement — sans validation du checksum mod-97)
# Le reconnaisseur intégré de Presidio rejette les IBAN dont le checksum est
# invalide (données de test, saisie avec faute…).  On utilise ici une approche
# format-only pour garantir la détection dans tout document.
#
# Format FR : FR + 2 chiffres + 23 chiffres BBAN = 27 caractères
# Groupements courants : FR76 BBBB BGGG GGAA AAAA AAAA ARR
# Exemple : FR76 3000 4005 5000 0012 4587 963
# ---------------------------------------------------------------------------

FR_IBAN_RECOGNIZER = PatternRecognizer(
    supported_entity="IBAN_CODE",
    name="French IBAN Recognizer",
    supported_language="fr",
    patterns=[
        # Format avec espaces (groupes de 4, dernier groupe de 3)
        Pattern(
            "FR_IBAN_SPACED",
            r"\bFR\d{2}(?:[\s\xa0 ]?\d{4}){5}[\s\xa0 ]?\d{3}\b",
            score=0.90,
        ),
    ],
    context=["iban", "rib", "virement", "banque", "compte", "bic", "swift", "domiciliation"],
)


# ---------------------------------------------------------------------------
# Adresses de voies françaises
# Exemples : 118 avenue Maréchal Foch, 24 rue des Tilleuls, 17 chemin Pasteur
# spaCy rate les noms de rues contenant un titre militaire (Maréchal, Général…)
# car il essaie de les classer comme PERSON et non comme LOC.
# ---------------------------------------------------------------------------

_STREET_TYPES = (
    r"(?:rue|avenue|boulevard|allée|allee|impasse|chemin|route|place|square"
    r"|passage|cité|cite|villa|hameau|lotissement|résidence|residence|voie"
    r"|ruelle|sente|clos|domaine|lieu-dit|lieudit)"
)

FR_STREET_ADDRESS_RECOGNIZER = PatternRecognizer(
    supported_entity="LOCATION",
    name="French Street Address Recognizer",
    supported_language="fr",
    patterns=[
        # Numéro + type de voie + nom → confiance élevée sans contexte
        # Exemples : 118 avenue Maréchal Foch  /  24 rue des Tilleuls
        # Le nom peut commencer par une préposition (des, du, de la, le, la…)
        Pattern(
            "FR_STREET_WITH_NUM",
            rf"\b\d{{1,5}}\s+{_STREET_TYPES}\s+[A-Za-zÀ-ÿ][^\n,;]{{2,50}}",
            score=0.85,
        ),
        # Type de voie + nom sans numéro → contexte requis pour éviter les FP
        # Exemples : avenue du Général de Gaulle  /  rue de la Paix
        Pattern(
            "FR_STREET_NO_NUM",
            rf"\b{_STREET_TYPES}\s+[A-Za-zÀ-ÿ][^\n,;]{{2,50}}",
            score=0.60,
        ),
    ],
    context=[
        "adresse", "siège", "domicile", "résidence", "situé", "située",
        "demeurant", "chantier", "habite", "sis", "sise",
    ],
)


# ---------------------------------------------------------------------------
# Chemins de fichiers (Windows et Unix) — fuite d'information structurelle
# Ex. : G:\etudes\QVGreffe\...\rapport.doc  ou  /home/user/data/file.csv
# ---------------------------------------------------------------------------

FILE_PATH_RECOGNIZER = PatternRecognizer(
    supported_entity="FILE_PATH",
    name="File Path Recognizer",
    supported_language="fr",
    patterns=[
        # Windows : lettre de lecteur + au moins un répertoire  C:\dir\file.ext
        Pattern(
            "WINDOWS_PATH",
            r"[A-Za-z]:\\(?:[^\\/:*?\"<>|\r\n\t]+\\)+[^\\/:*?\"<>|\r\n\t]*",
            score=0.95,
        ),
        # UNC : \\serveur\partage\...
        Pattern(
            "UNC_PATH",
            r"\\\\[^\\/:*?\"<>|\r\n\t ]+(?:\\[^\\/:*?\"<>|\r\n\t ]+)+",
            score=0.90,
        ),
        # Unix : /chemin/abs/fichier  (au moins deux composants)
        Pattern(
            "UNIX_PATH",
            r"(?<!\w)/(?:[^/\r\n\t ]+/)+[^/\r\n\t ]*",
            score=0.80,
        ),
    ],
)


# ---------------------------------------------------------------------------
# Personnes avec titre civil ou médical français
# Exemples : Pr Roland Sambuc, Dr Juliette Bloch, M. le Pr Serge BRIANÇON,
#            Mme Sylvie Mercier, Monsieur Jean-Pierre Durand
# Complète la détection NLP de spaCy qui rate les titres peu fréquents.
# ---------------------------------------------------------------------------

_LETTRE_MAJ = r"[A-ZÀÂÄÉÈÊËÎÏÔÙÛÜŸŒÆ]"
_MOT_NOM    = r"[A-ZÀÂÄÉÈÊËÎÏÔÙÛÜŸŒÆa-zàâäéèêëîïôùûüÿœæ\-']+"

FR_TITLED_PERSON_RECOGNIZER = PatternRecognizer(
    supported_entity="PERSON",
    name="French Titled Person Recognizer",
    supported_language="fr",
    patterns=[
        Pattern(
            "FR_TITLED_PERSON",
            # Titre : Pr / Dr / M / Mme / Monsieur / Madame (avec variantes)
            r"\b(?:Pr\.?|Dr\.?|M(?:\.|\s+le\s+Pr\.?)|Mme\.?|Monsieur|Madame)\s+"
            # 1 à 3 mots commençant par une majuscule (prénom + nom, ou nom seul)
            + rf"(?:{_LETTRE_MAJ}{_MOT_NOM})(?:\s+{_LETTRE_MAJ}{_MOT_NOM}){{0,2}}",
            score=0.82,
        ),
    ],
)


# ---------------------------------------------------------------------------
# Auteurs en format citation bibliographique
# Exemples : Sambuc R.  Ware JE  Snow K  Couchoud, C.  Disney AP
# Presidio ajoute +0.35 si un mot de contexte est trouvé à proximité, ce qui
# fait passer le score effectif de 0.60 → ~0.95 dans une section bibliographie.
# ---------------------------------------------------------------------------

FR_AUTHOR_CITATION_RECOGNIZER = PatternRecognizer(
    supported_entity="PERSON",
    name="French Author Citation Recognizer",
    supported_language="fr",
    patterns=[
        Pattern(
            "AUTHOR_INITIALS",
            # NomDeFamille (,) initiale(s)  ex. Ware JE  Couchoud, C.  Snow K
            r"\b[A-ZÀÂÉÈÊËÎÏÔÙÛÜ][a-zàâéèêëîïôùûüœ\-']{2,},?\s+[A-Z]{1,3}\.?\b",
            score=0.60,
        ),
        Pattern(
            "AUTHOR_INITIALS_FIRST",
            # Initiale Nom  ex. C. Couchoud  JE Ware
            r"\b[A-Z]{1,2}\.?\s+[A-ZÀÂÉÈÊËÎÏÔÙÛÜ][a-zàâéèêëîïôùûüœ\-']{2,}\b",
            score=0.60,
        ),
    ],
    context=[
        # En anglais (références anglophones fréquentes dans les revues médicales)
        "in:", "al.", "et al", "doi", "pubmed", "pmid",
        "j.", "am.", "eur.", "int.", "rev.", "med.", "clin.",
        "kidney", "transplant", "nephrol", "renal", "health",
        # En français
        "bibliographie", "références", "auteur",
    ],
)


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

def get_french_recognizers() -> list:
    """Retourne la liste complète des reconnaisseurs français."""
    return [
        NIR_RECOGNIZER,
        SIRET_RECOGNIZER,
        SIREN_RECOGNIZER,
        TVA_RECOGNIZER,
        PHONE_FR_RECOGNIZER,
        PASSPORT_FR_RECOGNIZER,
        CNI_RECOGNIZER,
        DRIVING_LICENSE_FR_RECOGNIZER,
        POSTAL_CODE_FR_RECOGNIZER,
        FR_IBAN_RECOGNIZER,
        FR_STREET_ADDRESS_RECOGNIZER,
        FILE_PATH_RECOGNIZER,
        FR_TITLED_PERSON_RECOGNIZER,
        FR_AUTHOR_CITATION_RECOGNIZER,
    ]


# Labels pour les entités françaises spécifiques
FRENCH_ENTITY_LABELS: dict[str, str] = {
    "FR_NIR":             "NIR",
    "FR_SIRET":           "SIRET",
    "FR_SIREN":           "SIREN",
    "FR_TVA":             "TVA",
    "FR_PASSPORT":        "PASSEPORT",
    "FR_CNI":             "CNI",
    "FR_DRIVING_LICENSE": "PERMIS",
    "FR_POSTAL_CODE":     "CODE_POSTAL",
    "FILE_PATH":          "CHEMIN_FICHIER",
}
