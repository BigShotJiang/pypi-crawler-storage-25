"""
Lecteurs de documents avec préservation maximale de la structure.

Chaque lecteur retourne une liste de blocs :
    [{"type": "heading1"|"heading2"|"heading3"|"paragraph"|"table"|"list_item",
      "text": "..."}]

Cela permet au formateur Markdown de reconstruire fidèlement la structure.
"""

import sys
import re
from pathlib import Path
from dataclasses import dataclass
from typing import Literal


BlockType = Literal["heading1", "heading2", "heading3", "paragraph", "table_row", "list_item", "hr"]


@dataclass
class Block:
    type: BlockType
    text: str
    # Pour les tableaux : lignes brutes (list[list[str]])
    cells: list[list[str]] | None = None


# ---------------------------------------------------------------------------
# DOCX
# ---------------------------------------------------------------------------

def read_docx(path: Path) -> list[Block]:
    try:
        from docx import Document
        from docx.oxml.ns import qn
    except ImportError:
        sys.exit("Dépendance manquante : pip install python-docx")

    doc = Document(path)
    blocks: list[Block] = []

    _HEADING_MAP = {
        "Heading 1": "heading1",
        "Heading 2": "heading2",
        "Heading 3": "heading3",
        "Title":     "heading1",
        "Subtitle":  "heading2",
    }

    def _para_blocks(doc_element) -> list[Block]:
        result = []
        for para in doc_element.paragraphs:
            text = para.text.strip()
            if not text:
                continue
            style = para.style.name if para.style else ""
            btype = _HEADING_MAP.get(style, "paragraph")
            # Heuristique de secours si style non reconnu
            if btype == "paragraph":
                if para.style and "List" in para.style.name:
                    btype = "list_item"
            result.append(Block(type=btype, text=text))
        return result

    def _table_block(table) -> Block:
        rows = []
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            rows.append(cells)
        # Déduplique les cellules fusionnées (python-docx les répète)
        seen = set()
        unique_rows = []
        for row in rows:
            key = tuple(row)
            if key not in seen:
                seen.add(key)
                unique_rows.append(row)
        # Représentation textuelle pour l'anonymisation
        text_parts = []
        for row in unique_rows:
            text_parts.append(" | ".join(row))
        return Block(type="table_row", text="\n".join(text_parts), cells=unique_rows)

    # Parcours dans l'ordre du document (paragraphes + tableaux)
    from docx.oxml.ns import qn as _qn
    body = doc.element.body
    for child in body.iterchildren():
        tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
        if tag == "p":
            from docx.text.paragraph import Paragraph
            para = Paragraph(child, doc)
            text = para.text.strip()
            if not text:
                continue
            style = para.style.name if para.style else ""
            btype = _HEADING_MAP.get(style, "paragraph")
            if btype == "paragraph" and para.style and "List" in para.style.name:
                btype = "list_item"
            blocks.append(Block(type=btype, text=text))
        elif tag == "tbl":
            from docx.table import Table
            table = Table(child, doc)
            blocks.append(_table_block(table))

    return blocks


# ---------------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------------

def read_pdf(path: Path) -> list[Block]:
    """Essaie pdfplumber (structure), sinon pdfminer, sinon pypdf."""

    # --- pdfplumber : meilleure extraction structurée ---
    try:
        import pdfplumber
        blocks: list[Block] = []
        with pdfplumber.open(str(path)) as pdf:
            for page in pdf.pages:
                text = page.extract_text(x_tolerance=3, y_tolerance=3)
                if not text:
                    continue
                for line in text.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    blocks.append(Block(type="paragraph", text=line))
        if blocks:
            return _merge_pdf_blocks(blocks)
    except ImportError:
        pass

    # --- pdfminer : fallback ---
    try:
        from pdfminer.high_level import extract_text
        text = extract_text(str(path))
        if text and text.strip():
            return _text_to_blocks(text)
    except ImportError:
        pass

    # --- pypdf : dernier recours ---
    try:
        from pypdf import PdfReader
        reader = PdfReader(str(path))
        pages = [page.extract_text() or "" for page in reader.pages]
        full_text = "\n\n".join(p.strip() for p in pages if p.strip())
        return _text_to_blocks(full_text)
    except ImportError:
        sys.exit("Dépendance manquante : pip install pdfplumber  (ou pdfminer.six)")


def _merge_pdf_blocks(blocks: list[Block]) -> list[Block]:
    """Fusionne les lignes courtes consécutives en paragraphes."""
    merged: list[Block] = []
    buffer = ""
    for block in blocks:
        text = block.text
        # Heuristique : ligne très courte et en MAJUSCULES → titre
        if text.isupper() and len(text) <= 70:
            if buffer:
                merged.append(Block(type="paragraph", text=buffer.strip()))
                buffer = ""
            merged.append(Block(type="heading2", text=text.title()))
            continue
        # Ligne finissant par ponctuation de fin de phrase → fin de §
        if buffer and text and text[0].isupper() and buffer.rstrip()[-1:] in ".;:!?":
            merged.append(Block(type="paragraph", text=buffer.strip()))
            buffer = text
        else:
            buffer = (buffer + " " + text).strip() if buffer else text
    if buffer:
        merged.append(Block(type="paragraph", text=buffer.strip()))
    return merged


def _text_to_blocks(text: str) -> list[Block]:
    """Convertit du texte brut en blocs."""
    blocks: list[Block] = []
    for para in re.split(r"\n{2,}", text):
        para = para.strip()
        if not para:
            continue
        if para.isupper() and len(para) <= 70:
            blocks.append(Block(type="heading2", text=para.title()))
        else:
            blocks.append(Block(type="paragraph", text=para))
    return blocks


# ---------------------------------------------------------------------------
# Texte / Markdown brut
# ---------------------------------------------------------------------------

def read_text(path: Path) -> list[Block]:
    text = path.read_text(encoding="utf-8", errors="replace")
    blocks: list[Block] = []
    for line in text.splitlines():
        stripped = line.rstrip()
        if stripped.startswith("# "):
            blocks.append(Block(type="heading1", text=stripped[2:].strip()))
        elif stripped.startswith("## "):
            blocks.append(Block(type="heading2", text=stripped[3:].strip()))
        elif stripped.startswith("### "):
            blocks.append(Block(type="heading3", text=stripped[4:].strip()))
        elif stripped.startswith(("- ", "* ", "+ ")):
            blocks.append(Block(type="list_item", text=stripped[2:].strip()))
        elif stripped == "---":
            blocks.append(Block(type="hr", text="---"))
        elif stripped:
            blocks.append(Block(type="paragraph", text=stripped))
    return blocks


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

SUPPORTED_EXTENSIONS = {".docx", ".pdf", ".txt", ".md", ".rst"}


def read_document(path: Path) -> list[Block]:
    suffix = path.suffix.lower()
    readers = {
        ".docx": read_docx,
        ".pdf":  read_pdf,
        ".txt":  read_text,
        ".md":   read_text,
        ".rst":  read_text,
    }
    reader = readers.get(suffix)
    if reader is None:
        raise ValueError(
            f"Format non supporté '{suffix}'. Supportés : {', '.join(readers)}"
        )
    return reader(path)


def blocks_to_text(blocks: list[Block]) -> str:
    """Extrait le texte brut de tous les blocs (pour Presidio)."""
    return "\n\n".join(b.text for b in blocks if b.text.strip())
