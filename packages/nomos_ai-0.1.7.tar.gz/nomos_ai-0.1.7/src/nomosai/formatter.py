"""
Formateur Markdown optimisé pour les LLMs.

Sortie structurée :
  - Frontmatter YAML (métadonnées lisibles par machine)
  - Corps du document avec structure préservée (titres, listes, tableaux)

Les placeholders numérotés ([PERSONNE_1], [EMAIL_2]…) permettent aux LLMs
de suivre les références croisées dans le document anonymisé.
"""

from __future__ import annotations

import datetime
from pathlib import Path

from nomosai.readers import Block
from nomosai.engine import ENTITY_LABELS


# ---------------------------------------------------------------------------
# Formateur principal
# ---------------------------------------------------------------------------

def to_markdown(
    blocks: list[Block],
    source_path: Path,
    language: str,
    stats: dict[str, int],
    score_threshold: float,
) -> str:
    """Assemble le document Markdown final."""

    frontmatter = _build_frontmatter(source_path, language, stats, score_threshold)
    body = _build_body(blocks)

    return frontmatter + body


# ---------------------------------------------------------------------------
# Frontmatter YAML
# ---------------------------------------------------------------------------

def _build_frontmatter(
    source_path: Path,
    language: str,
    stats: dict[str, int],
    score_threshold: float,
) -> str:
    now = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    total = sum(stats.values())

    lines = [
        "---",
        f'source: "{source_path.name}"',
        f"processed_at: {now}",
        f"language: {language}",
        f"score_threshold: {score_threshold}",
        f"total_entities_redacted: {total}",
    ]

    if stats:
        lines.append("entities_redacted:")
        for entity_type, count in sorted(stats.items(), key=lambda x: -x[1]):
            label = ENTITY_LABELS.get(entity_type, entity_type)
            lines.append(f"  {label}: {count}")

    lines += ["---"]
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Corps du document
# ---------------------------------------------------------------------------

def _build_body(blocks: list[Block]) -> str:
    md_lines: list[str] = []
    prev_type: str | None = None
    table_buffer: list[list[str]] = []

    def _flush_table():
        nonlocal table_buffer
        if not table_buffer:
            return
        # En-tête = première ligne
        header = table_buffer[0]
        md_lines.append("| " + " | ".join(header) + " |")
        md_lines.append("| " + " | ".join(["---"] * len(header)) + " |")
        for row in table_buffer[1:]:
            # Aligner sur la longueur de l'en-tête
            row_padded = row + [""] * (len(header) - len(row))
            md_lines.append("| " + " | ".join(row_padded[:len(header)]) + " |")
        md_lines.append("")
        table_buffer = []

    for block in blocks:
        # Ajouter une ligne vide entre sections si nécessaire
        needs_blank = (
            prev_type is not None
            and prev_type != block.type
            and block.type not in ("table_row",)
            and prev_type not in ("table_row",)
        )

        # Gestion des tableaux (groupés)
        if block.type == "table_row":
            if block.cells:
                table_buffer.extend(block.cells)
            else:
                # Pas de structure de cellules : traiter comme paragraphe
                if table_buffer:
                    _flush_table()
                md_lines.append(block.text)
                md_lines.append("")
            prev_type = "table_row"
            continue
        else:
            if table_buffer:
                _flush_table()

        if needs_blank and md_lines and md_lines[-1] != "":
            md_lines.append("")

        text = block.text.strip()
        if not text:
            if md_lines and md_lines[-1] != "":
                md_lines.append("")
            prev_type = block.type
            continue

        if block.type == "heading1":
            md_lines.append(f"# {text}")
        elif block.type == "heading2":
            md_lines.append(f"## {text}")
        elif block.type == "heading3":
            md_lines.append(f"### {text}")
        elif block.type == "list_item":
            md_lines.append(f"- {text}")
        elif block.type == "hr":
            md_lines.append("---")
        else:
            md_lines.append(text)

        prev_type = block.type

    # Flush tableau final si besoin
    if table_buffer:
        _flush_table()

    # Dédoublonner les lignes vides consécutives
    collapsed: list[str] = []
    prev_blank = False
    for line in md_lines:
        is_blank = line == ""
        if is_blank and prev_blank:
            continue
        collapsed.append(line)
        prev_blank = is_blank

    return "\n".join(collapsed).strip() + "\n\n"


