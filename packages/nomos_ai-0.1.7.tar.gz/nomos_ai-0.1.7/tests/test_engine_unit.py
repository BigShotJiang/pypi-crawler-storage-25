"""
Tests unitaires purs pour engine.py — aucune dépendance Presidio/spaCy.
Le moteur NLP est remplacé par un mock qui retourne des spans prédéfinis.
"""

import re
import pytest
from nomosai.engine import (
    _is_false_positive,
    _deduplicate_spans,
    DocumentAnonymizer,
    ENTITY_LABELS,
)


# ---------------------------------------------------------------------------
# Mock minimal d'un analyseur Presidio
# ---------------------------------------------------------------------------

class _Span:
    def __init__(self, entity_type, start, end, score=0.9):
        self.entity_type = entity_type
        self.start = start
        self.end = end
        self.score = score


class _MockAnalyzer:
    def __init__(self, *spans):
        self._spans = list(spans)

    def analyze(self, text, language, entities, score_threshold):
        return [s for s in self._spans if s.score >= score_threshold]


def _make_anon(*spans, threshold=0.55):
    return DocumentAnonymizer(_MockAnalyzer(*spans), language="fr", score_threshold=threshold)


# ---------------------------------------------------------------------------
# _is_false_positive
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text,entity_type,expected", [
    # Filtres globaux
    ("",        "PERSON",   True),   # vide
    ("A",       "PERSON",   True),   # lettre seule
    ("NC",      "PERSON",   True),   # sigle ≤ 3 lettres
    ("ET",      "LOCATION", True),   # sigle ≤ 3 lettres autre type
    ("123.45",  "PERSON",   True),   # numérique
    ("...",     "PERSON",   True),   # séparateur points
    ("II.4",    "PERSON",   True),   # numéro de section
    ("b- ",     "PERSON",   True),   # étiquette de liste
    # Valeurs valides
    ("Jean Dupont",     "PERSON",        False),
    ("Paris",           "LOCATION",      False),
    ("jean@test.com",   "EMAIL_ADDRESS", False),
    # Filtres spécifiques PERSON — existants
    ("REPARTITION DE LA", "PERSON", True),   # tout-caps multi-mots (entête tableau)
    ("n a m e",           "PERSON", True),   # OCR : lettres isolées par espace
    ("un fragment",       "PERSON", True),   # commence en minuscule
    ("II.3",              "PERSON", True),   # numéro de section romain
    # Filtre tout-caps NE s'applique PAS aux autres types
    ("REPARTITION DE LA", "LOCATION", False),

    # --- Régressions : fragments se terminant par une préposition/article ---
    ("Travaux de",        "PERSON", True),   # "de" final
    ("Contient des",      "PERSON", True),   # "des" final
    ("Adresse du",        "PERSON", True),   # "du" final
    ("Date de",           "PERSON", True),   # "de" final
    ("Signé par",         "PERSON", True),   # "par" final
    ("Mode de",           "PERSON", True),   # "de" final
    ("Mail de",           "PERSON", True),   # "de" final
    ("Constat du",        "PERSON", True),   # "du" final
    ("Établi par",        "PERSON", True),   # "par" final
    ("Mise en",           "PERSON", True),   # "en" final
    ("Préjudice de",      "PERSON", True),   # "de" final
    ("Fin du",            "PERSON", True),   # "du" final
    ("Niveau de",         "PERSON", True),   # "de" final
    ("Merci de",          "PERSON", True),   # "de" final
    ("Née le",            "PERSON", True),   # "le" final
    ("Représentée par",   "PERSON", True),   # "par" final
    ("Identification des","PERSON", True),   # "des" final

    # --- Régressions : fragments commençant par article + nom commun ---
    ("Le débiteur",  "PERSON", True),   # article + minuscule
    ("La cuisine",   "PERSON", True),   # article + minuscule
    ("Je vous",      "PERSON", True),   # pronom + minuscule
    # Vrai nom propre avec particule → NE doit PAS être filtré
    ("Le Pen",       "PERSON", False),  # particule nobiliaire : "P" majuscule

    # --- Régressions : en-têtes de sections romaines avec lettre ---
    ("II. Objet",      "PERSON", True),
    ("IV. Pièce",      "PERSON", True),
    ("V. Pièce",       "PERSON", True),
    ("IX. Pièce",      "PERSON", True),
    ("XI. Fondement",  "PERSON", True),

    # --- Régressions : étiquettes de champs ---
    ("Appartement",      "PERSON", True),
    ("Pièce n",          "PERSON", True),
    ("Devis n",          "PERSON", True),
    ("Agence Foch",      "PERSON", True),
    ("Constat du",       "PERSON", True),
    # --- Régressions : salutation seule ---
    ("Monsieur",         "PERSON", True),
    ("Madame",           "PERSON", True),

    # --- Régressions : grade militaire comme nom de rue ---
    ("Maréchal Foch",    "PERSON", True),   # grade + nom historique (nom de rue)
    ("Général de Gaulle","PERSON", True),   # idem
    ("Amiral Dupont",    "PERSON", True),
    # Vrai nom propre sans grade → NE doit PAS être filtré
    ("Ferdinand Foch",   "PERSON", False),

    # --- Désignation judiciaire : mot + lettre seule en fin ---
    ("Lyon B",           "PERSON",   True),   # code greffe détecté comme PERSON
    ("Lyon B",           "LOCATION", True),   # même pattern pour LOCATION
    ("Paris A",          "PERSON",   True),
    ("Paris A",          "LOCATION", True),
    # Vrai nom court → NE doit PAS être filtré (lettre précédée d'un point)
    ("Lyon",             "PERSON",   False),

    # --- Régressions LOCATION ---
    ("IBAN",             "LOCATION", True),   # sigle tout-caps
    ("FR76",             "LOCATION", True),   # préfixe IBAN
    ("DE49",             "LOCATION", True),   # préfixe IBAN étranger
    ("Cordialement",     "LOCATION", True),   # mot de politesse (deny-list)
    ("Préjudices",       "LOCATION", True),   # terme juridique (deny-list)
    # Villes réelles → NE doivent PAS être filtrées
    ("Lyon",             "LOCATION", False),
    ("Villeurbanne",     "LOCATION", False),
    ("Paris",            "LOCATION", False),

    # --- Régressions ORGANIZATION ---
    ("Téléphone",        "ORGANIZATION", True),   # étiquette de champ
    ("Banque",           "ORGANIZATION", True),   # mot générique
    ("Préjudice moral",  "ORGANIZATION", True),   # terme juridique
    # Vraies organisations → NE doivent PAS être filtrées
    ("BATICONFORT",      "ORGANIZATION", False),
    ("Crédit Lyonnais",  "ORGANIZATION", False),
    ("AquaService",      "ORGANIZATION", False),

    # --- Types intrinsèquement numériques : jamais filtrés comme "valeur numérique" ---
    # SIRET (14 chiffres avec espaces) → anciennement bloqué par _FP_NUMERIC_PATTERNS
    ("812 457 963 00028",   "FR_SIRET",    False),
    ("73282932000074",      "FR_SIRET",    False),
    ("732 829 320 00074",   "FR_SIRET",    False),
    # Téléphone local (10 chiffres avec séparateurs)
    ("06 42 18 73 59",      "PHONE_NUMBER", False),
    ("04 78 54 22 18",      "PHONE_NUMBER", False),
    ("0612345678",          "PHONE_NUMBER", False),
    # NIR (15 chiffres)
    ("185057510039942",     "FR_NIR",      False),
    ("1 85 05 75 100 399 42", "FR_NIR",   False),
    # IBAN
    ("FR7614508040000000000000000", "IBAN_CODE", False),
    # Postal code avec contexte (5 chiffres)
    ("75001",               "FR_POSTAL_CODE", False),
    ("69006",               "FR_POSTAL_CODE", False),
    # Valeur numérique pure sans type numérique → toujours filtrée
    ("14 800",              "PERSON",       True),
    ("N = 1 035",           "LOCATION",     True),
])
def test_is_false_positive(text, entity_type, expected):
    assert _is_false_positive(text, entity_type) == expected, (
        f"_is_false_positive({text!r}, {entity_type!r}) attendu={expected}"
    )


# ---------------------------------------------------------------------------
# _deduplicate_spans
# ---------------------------------------------------------------------------

def test_deduplicate_no_overlap_keeps_both():
    spans = [_Span("PERSON", 0, 10), _Span("EMAIL_ADDRESS", 15, 30)]
    assert len(_deduplicate_spans(spans, "")) == 2


def test_deduplicate_overlap_keeps_higher_score():
    # A=[0,17] et B=[3,17] se chevauchent → conserver A (score plus élevé)
    spans = [_Span("PERSON", 0, 17, 0.9), _Span("PERSON", 3, 17, 0.6)]
    result = _deduplicate_spans(spans, "Jean Dupont text")
    assert len(result) == 1
    assert result[0].start == 0


def test_deduplicate_overlap_same_score_keeps_longer():
    # Même score → garder le span le plus long (englobant)
    spans = [_Span("PERSON", 0, 15, 0.9), _Span("PERSON", 3, 10, 0.9)]
    result = _deduplicate_spans(spans, "Jean Dupont text")
    assert len(result) == 1
    assert result[0].end == 15


def test_deduplicate_empty():
    assert _deduplicate_spans([], "") == []


# ---------------------------------------------------------------------------
# DocumentAnonymizer — cohérence des placeholders
# ---------------------------------------------------------------------------

def test_same_value_gets_same_placeholder():
    text = "Jean Dupont et Jean Dupont sont là."
    anon = _make_anon(
        _Span("PERSON", 0, 11),   # Jean Dupont
        _Span("PERSON", 15, 26),  # Jean Dupont
    )
    result = anon.anonymize_text(text)
    placeholders = re.findall(r"\[PERSONNE_\d+\]", result)
    assert len(placeholders) == 2
    assert placeholders[0] == placeholders[1]


def test_different_values_get_different_placeholders():
    text = "Jean Dupont et Marie Curie."
    anon = _make_anon(
        _Span("PERSON", 0, 11),   # Jean Dupont
        _Span("PERSON", 15, 26),  # Marie Curie
    )
    result = anon.anonymize_text(text)
    assert "[PERSONNE_1]" in result
    assert "[PERSONNE_2]" in result


def test_placeholder_format_matches_label():
    text = "jean@example.com"
    anon = _make_anon(_Span("EMAIL_ADDRESS", 0, 16))
    result = anon.anonymize_text(text)
    # Le label de EMAIL_ADDRESS est "EMAIL" dans ENTITY_LABELS
    assert re.fullmatch(r"\[EMAIL_\d+\]", result)


def test_placeholder_numbering_is_sequential():
    # Les valeurs d'un seul caractère sont filtrées comme faux positifs (normal).
    # On utilise des noms suffisamment longs pour passer les filtres.
    text = "Alice Dupont, Marie Martin et Jean Leclerc."
    anon = _make_anon(
        _Span("PERSON", 0, 12),   # Alice Dupont
        _Span("PERSON", 14, 26),  # Marie Martin
        _Span("PERSON", 30, 42),  # Jean Leclerc
    )
    result = anon.anonymize_text(text)
    assert "[PERSONNE_1]" in result
    assert "[PERSONNE_2]" in result
    assert "[PERSONNE_3]" in result


def test_empty_text_returned_unchanged():
    anon = _make_anon()
    assert anon.anonymize_text("") == ""
    assert anon.anonymize_text("   ") == "   "


def test_no_pii_text_returned_unchanged():
    text = "Ce texte ne contient aucune PII."
    anon = _make_anon()
    assert anon.anonymize_text(text) == text


def test_replacement_is_right_to_left_safe():
    # Deux entités non-chevauchantes : le remplacement de droite à gauche
    # ne doit pas corrompre les indices.
    text = "Alice Dupont envoya à Bob Martin un message."
    anon = _make_anon(
        _Span("PERSON", 0, 12),   # Alice Dupont
        _Span("PERSON", 22, 32),  # Bob Martin
    )
    result = anon.anonymize_text(text)
    assert result.count("[PERSONNE_") == 2
    # Aucune corruption type "[PERSONNE_1]NNE_2]" — une `]` suivie d'une
    # lettre majuscule indique que le span précédent a écrasé le suivant.
    assert not re.search(r"\][A-Z]", result), f"Artefact de corruption : {result!r}"


# ---------------------------------------------------------------------------
# get_index
# ---------------------------------------------------------------------------

def test_get_index_returns_required_keys():
    text = "Jean Dupont, jean@test.com"
    anon = _make_anon(
        _Span("PERSON", 0, 11),
        _Span("EMAIL_ADDRESS", 13, 26),
    )
    anon.anonymize_text(text)
    for entry in anon.get_index():
        assert {"placeholder", "original", "entity_type", "label"} <= set(entry.keys())


def test_get_index_preserves_original_value():
    text = "Jean Dupont"
    anon = _make_anon(_Span("PERSON", 0, 11))
    anon.anonymize_text(text)
    index = anon.get_index()
    assert len(index) == 1
    assert index[0]["original"] == "Jean Dupont"
    assert index[0]["entity_type"] == "PERSON"
    assert index[0]["label"] == ENTITY_LABELS["PERSON"]


def test_get_index_empty_after_reset():
    anon = _make_anon(_Span("PERSON", 0, 11))
    anon.anonymize_text("Jean Dupont")
    anon.reset()
    assert anon.get_index() == []


# ---------------------------------------------------------------------------
# load_index
# ---------------------------------------------------------------------------

def test_load_index_reuses_existing_placeholder():
    existing = [{"placeholder": "[PERSONNE_1]", "original": "Jean Dupont", "entity_type": "PERSON"}]
    anon = _make_anon(_Span("PERSON", 0, 11))
    anon.load_index(existing)
    result = anon.anonymize_text("Jean Dupont")
    assert result == "[PERSONNE_1]"


def test_load_index_advances_counter_past_max():
    # [PERSONNE_3] préchargé → la prochaine nouvelle personne reçoit [PERSONNE_4]
    existing = [{"placeholder": "[PERSONNE_3]", "original": "Autre Nom", "entity_type": "PERSON"}]
    anon = _make_anon(_Span("PERSON", 0, 11))
    anon.load_index(existing)
    result = anon.anonymize_text("Jean Dupont")
    assert "[PERSONNE_4]" in result


def test_load_index_ignores_malformed_entries():
    malformed = [{"placeholder": "", "original": "", "entity_type": ""}]
    anon = _make_anon(_Span("PERSON", 0, 11))
    anon.load_index(malformed)   # ne doit pas lever d'exception
    result = anon.anonymize_text("Jean Dupont")
    assert "[PERSONNE_1]" in result


# ---------------------------------------------------------------------------
# stats
# ---------------------------------------------------------------------------

def test_stats_incremented_per_entity_type():
    text = "Jean Dupont, jean@test.com"
    anon = _make_anon(
        _Span("PERSON", 0, 11),
        _Span("EMAIL_ADDRESS", 13, 26),
    )
    anon.anonymize_text(text)
    assert anon.stats["PERSON"] == 1
    assert anon.stats["EMAIL_ADDRESS"] == 1


def test_reset_clears_stats_and_index():
    anon = _make_anon(_Span("PERSON", 0, 11))
    anon.anonymize_text("Jean Dupont")
    anon.reset()
    assert sum(anon.stats.values()) == 0
    assert anon.get_index() == []


# ---------------------------------------------------------------------------
# score_threshold filtré par le mock
# ---------------------------------------------------------------------------

def test_low_score_entity_below_threshold_not_replaced():
    text = "Jean Dupont"
    # Le span a un score inférieur au seuil du mock → le mock retourne []
    anon = _make_anon(_Span("PERSON", 0, 11, score=0.3))
    result = anon.anonymize_text(text)
    assert result == text  # non anonymisé


# ---------------------------------------------------------------------------
# Filtres internes du moteur (lignes 288 / 290 / 294)
# Ces spans passent le seuil global mais sont rejetés par les filtres internes.
# ---------------------------------------------------------------------------

def test_per_entity_min_score_filters_location():
    # LOCATION requiert score ≥ 0.80 (_ENTITY_MIN_SCORES).
    # Un span à 0.65 passe le seuil global (0.55) mais est rejeté → ligne 288.
    text = "Paris est une ville."
    anon = _make_anon(_Span("LOCATION", 0, 5, score=0.65))
    result = anon.anonymize_text(text)
    assert result == text  # non anonymisé


def test_false_positive_in_results_filtered():
    # Le mock retourne un span sur "NC" (sigle 2 lettres → faux positif) → ligne 290.
    text = "NC est un sigle."
    anon = _make_anon(_Span("PERSON", 0, 2, score=0.9))
    result = anon.anonymize_text(text)
    assert result == text  # NC filtré comme faux positif


def test_all_results_filtered_returns_unchanged():
    # Tous les spans rejetés → candidates vide → return text inchangé → ligne 294.
    text = "Paris NC rapport"
    anon = _make_anon(
        _Span("LOCATION", 0, 5, score=0.65),  # rejeté par min score LOCATION
        _Span("PERSON", 6, 8, score=0.9),     # rejeté comme faux positif (NC)
    )
    result = anon.anonymize_text(text)
    assert result == text


# ---------------------------------------------------------------------------
# anonymize_blocks (lignes 324-338)
# ---------------------------------------------------------------------------

def test_anonymize_blocks_empty_returns_empty():
    anon = _make_anon()
    assert anon.anonymize_blocks([]) == []


def test_anonymize_blocks_text_block_anonymized():
    from nomosai.readers import Block
    blocks = [Block(type="paragraph", text="Jean Dupont signe.")]
    anon = _make_anon(_Span("PERSON", 0, 11))
    result = anon.anonymize_blocks(blocks)
    assert len(result) == 1
    assert result[0].type == "paragraph"
    assert "[PERSONNE_" in result[0].text


def test_anonymize_blocks_preserves_block_type():
    from nomosai.readers import Block
    blocks = [
        Block(type="heading1", text="Titre du rapport"),
        Block(type="paragraph", text="Jean Dupont"),
    ]
    anon = _make_anon(_Span("PERSON", 0, 11))
    result = anon.anonymize_blocks(blocks)
    assert result[0].type == "heading1"
    assert result[1].type == "paragraph"


def test_anonymize_blocks_table_cells_anonymized():
    from nomosai.readers import Block
    blocks = [Block(
        type="table_row",
        text="",
        cells=[["Jean Dupont", "Directeur"]],
    )]
    anon = _make_anon(_Span("PERSON", 0, 11))
    result = anon.anonymize_blocks(blocks)
    assert result[0].cells is not None
    assert "[PERSONNE_" in result[0].cells[0][0]


def test_anonymize_blocks_no_cells_text_anonymized():
    from nomosai.readers import Block
    blocks = [Block(type="table_row", text="Jean Dupont", cells=None)]
    anon = _make_anon(_Span("PERSON", 0, 11))
    result = anon.anonymize_blocks(blocks)
    assert "[PERSONNE_" in result[0].text
