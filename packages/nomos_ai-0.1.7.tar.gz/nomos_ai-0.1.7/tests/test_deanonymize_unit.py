"""
Tests unitaires purs pour deanonymize.py — aucune dépendance externe.
Couvre restore_text() et parse_index().
"""

import pytest
from pathlib import Path
from deanonymize import restore_text, parse_index


# ---------------------------------------------------------------------------
# restore_text
# ---------------------------------------------------------------------------

def test_restore_basic():
    mapping = {"[PERSONNE_1]": "Jean Dupont"}
    assert restore_text("[PERSONNE_1] a signé.", mapping) == "Jean Dupont a signé."


def test_restore_multiple_types():
    mapping = {"[PERSONNE_1]": "Jean Dupont", "[EMAIL_1]": "jean@test.com"}
    text = "[PERSONNE_1] a pour email [EMAIL_1]."
    assert restore_text(text, mapping) == "Jean Dupont a pour email jean@test.com."


def test_restore_repeated_placeholder():
    mapping = {"[PERSONNE_1]": "Jean Dupont"}
    text = "[PERSONNE_1] a contacté [PERSONNE_1]."
    assert restore_text(text, mapping) == "Jean Dupont a contacté Jean Dupont."


def test_restore_long_before_short_placeholder():
    # [PERSONNE_10] doit être traité avant [PERSONNE_1] pour éviter
    # que "0]" ne reste dans le texte final.
    mapping = {"[PERSONNE_1]": "Alice", "[PERSONNE_10]": "Bob"}
    text = "[PERSONNE_10] et [PERSONNE_1]"
    assert restore_text(text, mapping) == "Bob et Alice"


def test_restore_many_numbered_placeholders_no_collision():
    mapping = {f"[PERSONNE_{i}]": f"Personne{i}" for i in range(1, 12)}
    parts = [f"[PERSONNE_{i}]" for i in range(1, 12)]
    text = " ".join(parts)
    result = restore_text(text, mapping)
    for i in range(1, 12):
        assert f"Personne{i}" in result
    assert "[PERSONNE_" not in result


def test_restore_empty_mapping():
    text = "Aucun placeholder ici."
    assert restore_text(text, {}) == text


def test_restore_unknown_placeholder_left_intact():
    mapping = {"[PERSONNE_1]": "Alice"}
    text = "Bonjour [PERSONNE_99]"
    result = restore_text(text, mapping)
    assert "[PERSONNE_99]" in result  # inconnu → laissé tel quel


def test_restore_value_with_special_characters():
    mapping = {"[PERSONNE_1]": "O'Brien-Dupont"}
    assert restore_text("[PERSONNE_1]", mapping) == "O'Brien-Dupont"


def test_restore_empty_text():
    assert restore_text("", {"[PERSONNE_1]": "Alice"}) == ""


# ---------------------------------------------------------------------------
# parse_index
# ---------------------------------------------------------------------------

_INDEX_STANDARD = """\
---
source: test.pdf
generated: 2024-01-01 00:00:00
total_entities: 2
---

# Index d'anonymisation

| Placeholder | Valeur originale | Type |
| --- | --- | --- |
| `[PERSONNE_1]` | Jean Dupont | `PERSONNE` |
| `[EMAIL_1]` | jean@test.com | `EMAIL` |

---
"""


def test_parse_index_basic(tmp_path):
    idx = tmp_path / "doc-index.md"
    idx.write_text(_INDEX_STANDARD, encoding="utf-8")
    mapping = parse_index(idx)
    assert mapping["[PERSONNE_1]"] == "Jean Dupont"
    assert mapping["[EMAIL_1]"] == "jean@test.com"


def test_parse_index_escaped_pipe(tmp_path):
    content = (
        "| Placeholder | Valeur originale | Type |\n"
        "| --- | --- | --- |\n"
        r"| `[PERSONNE_1]` | Dupont \| Fils | `PERSONNE` |" + "\n"
    )
    idx = tmp_path / "doc-index.md"
    idx.write_text(content, encoding="utf-8")
    mapping = parse_index(idx)
    assert mapping["[PERSONNE_1]"] == "Dupont | Fils"


def test_parse_index_escaped_newline(tmp_path):
    content = (
        "| Placeholder | Valeur originale | Type |\n"
        "| --- | --- | --- |\n"
        r"| `[PERSONNE_1]` | Ligne1\nLigne2 | `PERSONNE` |" + "\n"
    )
    idx = tmp_path / "doc-index.md"
    idx.write_text(content, encoding="utf-8")
    mapping = parse_index(idx)
    assert "\n" in mapping["[PERSONNE_1]"]


def test_parse_index_ignores_header_separator_rows(tmp_path):
    content = (
        "| Placeholder | Valeur originale | Type |\n"
        "| --- | --- | --- |\n"
        "| `[PERSONNE_1]` | Alice | `PERSONNE` |\n"
    )
    idx = tmp_path / "doc-index.md"
    idx.write_text(content, encoding="utf-8")
    mapping = parse_index(idx)
    # La ligne `| --- | --- | --- |` ne doit pas être dans le mapping
    assert len(mapping) == 1


def test_parse_index_empty_file_raises_systemexit(tmp_path):
    idx = tmp_path / "empty-index.md"
    idx.write_text("# Aucun placeholder\n", encoding="utf-8")
    with pytest.raises(SystemExit):
        parse_index(idx)


def test_parse_index_multiple_entries(tmp_path):
    entries = "\n".join(
        f"| `[PERSONNE_{i}]` | Personne{i} | `PERSONNE` |"
        for i in range(1, 6)
    )
    content = (
        "| Placeholder | Valeur originale | Type |\n"
        "| --- | --- | --- |\n"
        + entries + "\n"
    )
    idx = tmp_path / "doc-index.md"
    idx.write_text(content, encoding="utf-8")
    mapping = parse_index(idx)
    assert len(mapping) == 5
    assert mapping["[PERSONNE_3]"] == "Personne3"


# ---------------------------------------------------------------------------
# Round-trip restore_text + parse_index
# ---------------------------------------------------------------------------

def test_roundtrip_parse_then_restore(tmp_path):
    content = (
        "| Placeholder | Valeur originale | Type |\n"
        "| --- | --- | --- |\n"
        "| `[PERSONNE_1]` | Jean Dupont | `PERSONNE` |\n"
        "| `[EMAIL_1]` | jean@dupont.fr | `EMAIL` |\n"
    )
    idx = tmp_path / "doc-index.md"
    idx.write_text(content, encoding="utf-8")
    mapping = parse_index(idx)

    anonymized = "[PERSONNE_1] a envoyé un email depuis [EMAIL_1]."
    restored = restore_text(anonymized, mapping)
    assert "Jean Dupont" in restored
    assert "jean@dupont.fr" in restored
    assert "[PERSONNE_" not in restored
    assert "[EMAIL_" not in restored
