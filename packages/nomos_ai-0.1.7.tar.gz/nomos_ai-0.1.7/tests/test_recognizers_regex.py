"""
Tests des patterns regex des reconnaisseurs français — aucun modèle spaCy requis.
Vérifie directement les expressions régulières des PatternRecognizer de recognizers_fr.py.
"""

import re
import pytest
from nomosai.recognizers_fr import (
    NIR_RECOGNIZER,
    SIRET_RECOGNIZER,
    SIREN_RECOGNIZER,
    TVA_RECOGNIZER,
    PHONE_FR_RECOGNIZER,
    PASSPORT_FR_RECOGNIZER,
    CNI_RECOGNIZER,
    DRIVING_LICENSE_FR_RECOGNIZER,
    POSTAL_CODE_FR_RECOGNIZER,
    FR_IBAN_RECOGNIZER,
    FR_STREET_ADDRESS_RECOGNIZER,
    FILE_PATH_RECOGNIZER,
    FR_TITLED_PERSON_RECOGNIZER,
)


def _patterns(recognizer):
    return [re.compile(p.regex) for p in recognizer.patterns]


def _any_match(recognizer, text):
    return any(p.search(text) for p in _patterns(recognizer))


# ---------------------------------------------------------------------------
# FR_NIR — Numéro de Sécurité Sociale (15 chiffres)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", [
    "1 85 05 75 100 399 42",   # homme, format espacé
    "185057510039942",          # compact
    "2 93 10 99 100 001 78",   # femme
    "7 12 03 2B 001 001 00",   # département 2B (Haute-Corse)
])
def test_nir_valid(text):
    assert _any_match(NIR_RECOGNIZER, text), f"NIR non détecté : {text!r}"


@pytest.mark.parametrize("text", [
    "0850575100399 42",   # sexe 0 → invalide
    "3850575100399 42",   # sexe 3 → invalide
    "ABCDEFGHIJKLMNO",   # non numérique
    "12345",              # trop court
])
def test_nir_invalid(text):
    assert not _any_match(NIR_RECOGNIZER, text), f"NIR ne devrait pas matcher : {text!r}"


# ---------------------------------------------------------------------------
# FR_SIRET — 14 chiffres
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", [
    "73282932000074",         # compact
    "732 829 320 00074",      # espacé
    "732.829.320.00074",      # points
    "732-829-320-00074",      # tirets
])
def test_siret_valid(text):
    assert _any_match(SIRET_RECOGNIZER, text), f"SIRET non détecté : {text!r}"


@pytest.mark.parametrize("text", [
    "7328293200007",    # 13 chiffres (trop court)
    "732829320000740",  # 15 chiffres (trop long)
])
def test_siret_invalid_length(text):
    assert not _any_match(SIRET_RECOGNIZER, text), f"SIRET ne devrait pas matcher : {text!r}"


# ---------------------------------------------------------------------------
# FR_SIREN — 9 chiffres
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", [
    "732829320",     # compact
    "732 829 320",   # espacé
    "732.829.320",   # points
])
def test_siren_valid(text):
    assert _any_match(SIREN_RECOGNIZER, text), f"SIREN non détecté : {text!r}"


@pytest.mark.parametrize("text", [
    "73282932",    # 8 chiffres
    "7328293201",  # 10 chiffres
])
def test_siren_invalid(text):
    assert not _any_match(SIREN_RECOGNIZER, text), f"SIREN ne devrait pas matcher : {text!r}"


# ---------------------------------------------------------------------------
# FR_IBAN — IBAN français (format regex, sans validation checksum)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", [
    "FR76 3000 4005 5000 0012 4587 963",   # format espacé (doc test — checksum invalide)
    "FR7630004005500000124587963",          # format compact
    "FR76 1234 5678 9012 3456 7890 123",   # autre BBAN valide (5×4 + 3 chiffres)
    "FR00 0000 0000 0000 0000 0000 000",   # chiffres zéro (checksum invalide mais format ok)
])
def test_iban_valid(text):
    assert _any_match(FR_IBAN_RECOGNIZER, text), f"IBAN non détecté : {text!r}"


@pytest.mark.parametrize("text", [
    "DE89370400440532013000",    # IBAN allemand (pas FR)
    "FR761234",                  # trop court
    "GB29NWBK60161331926819",    # IBAN britannique
])
def test_iban_invalid(text):
    assert not _any_match(FR_IBAN_RECOGNIZER, text), f"IBAN ne devrait pas matcher : {text!r}"


# ---------------------------------------------------------------------------
# FR_TVA — FR + 2 alphanum + 9 chiffres SIREN
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", [
    "FR07732829320",          # code numérique
    "FR 07 732 829 320",      # espacé
    "FRA7732829320",          # 1 lettre + 1 chiffre
    "FRAB732829320",          # 2 lettres valides
    "FR87732829320",          # chiffres uniquement dans le code
])
def test_tva_valid(text):
    assert _any_match(TVA_RECOGNIZER, text), f"TVA non détectée : {text!r}"


@pytest.mark.parametrize("text", [
    "DE07732829320",   # indicatif allemand
    "FR0773282932",    # trop court (8 chiffres au lieu de 9)
    "FRO7732829320",   # O interdit (confusion avec 0)
    "FRI7732829320",   # I interdit (confusion avec 1)
])
def test_tva_invalid(text):
    assert not _any_match(TVA_RECOGNIZER, text), f"TVA ne devrait pas matcher : {text!r}"


# ---------------------------------------------------------------------------
# PHONE_NUMBER — numéros français locaux et 0033
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", [
    "01 23 45 67 89",
    "06 12 34 56 78",
    "06.12.34.56.78",
    "0612345678",
    "09 87 65 43 21",
    "06 42 18 73 59",   # cas réel du document test
    "04 78 54 22 18",   # numéro professionnel
    "06 71 33 48 91",   # mobile artisan
])
def test_phone_local_valid(text):
    local_patterns = [re.compile(p.regex) for p in PHONE_FR_RECOGNIZER.patterns
                      if p.name == "FR_PHONE_LOCAL"]
    assert any(p.search(text) for p in local_patterns), f"Téléphone local non détecté : {text!r}"


@pytest.mark.parametrize("text", [
    "+33612345678",         # format compact norme ITU
    "+33 6 12 34 56 78",   # format espacé
    "+33 1 23 45 67 89",   # fixe Paris
])
def test_phone_intl_plus33_valid(text):
    intl_patterns = [re.compile(p.regex) for p in PHONE_FR_RECOGNIZER.patterns
                     if p.name == "FR_PHONE_INTL"]
    assert any(p.search(text) for p in intl_patterns), f"Téléphone +33 non détecté : {text!r}"


@pytest.mark.parametrize("text", [
    "0033612345678",
    "0033 6 12 34 56 78",
])
def test_phone_0033_valid(text):
    intl_patterns = [re.compile(p.regex) for p in PHONE_FR_RECOGNIZER.patterns
                     if p.name == "FR_PHONE_00"]
    assert any(p.search(text) for p in intl_patterns), f"Téléphone 0033 non détecté : {text!r}"


@pytest.mark.parametrize("text", [
    "00 00 00 00 00",   # commence par 00 (invalide comme numéro local)
    "12 34 56 78 90",   # ne commence pas par 0
])
def test_phone_local_invalid(text):
    local_patterns = [re.compile(p.regex) for p in PHONE_FR_RECOGNIZER.patterns
                      if p.name == "FR_PHONE_LOCAL"]
    assert not any(p.search(text) for p in local_patterns), f"Téléphone ne devrait pas matcher : {text!r}"


# ---------------------------------------------------------------------------
# FR_PASSPORT — 2 chiffres + 2 lettres maj + 5 chiffres
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", [
    "06AB12345",
    "12ZZ99999",
    "99AA00001",
])
def test_passport_valid(text):
    assert _any_match(PASSPORT_FR_RECOGNIZER, text), f"Passeport non détecté : {text!r}"


@pytest.mark.parametrize("text", [
    "6AB12345",    # un chiffre au lieu de deux au début
    "06AB1234",    # quatre chiffres finaux au lieu de cinq
    "06ab12345",   # lettres minuscules
    "AAAB12345",   # lettres au lieu de chiffres au début
])
def test_passport_invalid(text):
    patterns = _patterns(PASSPORT_FR_RECOGNIZER)
    assert not any(p.fullmatch(text) for p in patterns), f"Passeport ne devrait pas matcher : {text!r}"


# ---------------------------------------------------------------------------
# FR_CNI — 12 chiffres exactement
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", [
    "123456789012",
    "000000000001",
    "999999999999",
])
def test_cni_valid(text):
    assert _any_match(CNI_RECOGNIZER, text), f"CNI non détectée : {text!r}"


@pytest.mark.parametrize("text", [
    "12345678901",    # 11 chiffres
    "1234567890123",  # 13 chiffres
    "12345678901A",   # lettre incluse
])
def test_cni_invalid(text):
    patterns = _patterns(CNI_RECOGNIZER)
    # fullmatch pour éviter les faux positifs de sous-chaînes
    assert not any(p.fullmatch(text) for p in patterns), f"CNI ne devrait pas matcher : {text!r}"


# ---------------------------------------------------------------------------
# FR_DRIVING_LICENSE — format post-2013 : AA-NNN-AA
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", [
    "AB-123-CD",
    "ZZ-999-AA",
    "FR-042-XY",
])
def test_driving_license_valid(text):
    assert _any_match(DRIVING_LICENSE_FR_RECOGNIZER, text), f"Permis non détecté : {text!r}"


@pytest.mark.parametrize("text", [
    "AB-12-CD",    # trois chiffres requis, seulement deux
    "A-123-CD",    # deux lettres requises au début, une seule
    "ab-123-cd",   # minuscules
    "AB123CD",     # pas de tirets
])
def test_driving_license_invalid(text):
    patterns = _patterns(DRIVING_LICENSE_FR_RECOGNIZER)
    assert not any(p.fullmatch(text) for p in patterns), f"Permis ne devrait pas matcher : {text!r}"


# ---------------------------------------------------------------------------
# FR_POSTAL_CODE — codes postaux métropolitains (5 chiffres)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", [
    "75001",   # Paris 1er
    "13100",   # Aix-en-Provence
    "01000",   # Bourg-en-Bresse
    "95100",   # Argenteuil
    "69006",   # Lyon 6e — cas réel du document test
    "69003",   # Lyon 3e
    "69100",   # Villeurbanne
    "97100",   # Basse-Terre (Guadeloupe)
    "97600",   # Mayotte
])
def test_postal_code_valid(text):
    assert _any_match(POSTAL_CODE_FR_RECOGNIZER, text), f"Code postal non détecté : {text!r}"


@pytest.mark.parametrize("text", [
    "00100",   # département 00 → invalide (notre pattern, pas \d{5} générique)
    "ABCDE",   # non numérique
    "7501",    # 4 chiffres
    "750011",  # 6 chiffres
    "99999",   # département 99 → invalide (notre pattern valide jusqu'à 97)
])
def test_postal_code_invalid(text):
    assert not _any_match(POSTAL_CODE_FR_RECOGNIZER, text), f"Code postal ne devrait pas matcher : {text!r}"


# ---------------------------------------------------------------------------
# FR_STREET_ADDRESS — adresses de voies françaises (LOCATION)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", [
    "118 avenue Maréchal Foch",    # cas réel doc test (titre militaire dans nom de rue)
    "24 rue des Tilleuls",         # rue lowercase
    "17 chemin Pasteur",
    "3 boulevard Victor Hugo",
    "1 place de la République",
    "52 allée des Roses",
    "10 impasse du Moulin",
])
def test_street_with_number_valid(text):
    patterns = [re.compile(p.regex) for p in FR_STREET_ADDRESS_RECOGNIZER.patterns
                if p.name == "FR_STREET_WITH_NUM"]
    assert any(p.search(text) for p in patterns), f"Adresse non détectée : {text!r}"


@pytest.mark.parametrize("text", [
    "avenue Maréchal Foch",        # sans numéro → pattern no_num (score bas, contexte requis)
    "rapport.pdf",                 # aucun type de voie
    "Article 3 alinéa 2",         # structure similaire mais pas une adresse
])
def test_street_with_number_not_matched_by_num_pattern(text):
    patterns = [re.compile(p.regex) for p in FR_STREET_ADDRESS_RECOGNIZER.patterns
                if p.name == "FR_STREET_WITH_NUM"]
    assert not any(p.search(text) for p in patterns), f"Ne devrait pas matcher (num) : {text!r}"


@pytest.mark.parametrize("text", [
    "avenue Maréchal Foch",
    "rue de la Paix",
    "boulevard du Général de Gaulle",
])
def test_street_no_number_valid(text):
    patterns = [re.compile(p.regex) for p in FR_STREET_ADDRESS_RECOGNIZER.patterns
                if p.name == "FR_STREET_NO_NUM"]
    assert any(p.search(text) for p in patterns), f"Adresse sans numéro non détectée : {text!r}"


# ---------------------------------------------------------------------------
# FILE_PATH — chemins Windows et Unix
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", [
    r"C:\Users\jean\Documents\rapport.pdf",
    r"G:\etudes\QVGreffe\rapport.doc",
    r"\\SERVER\partage\fichier.docx",
    "/home/user/data/file.csv",
    "/var/log/app/error.log",
])
def test_filepath_valid(text):
    assert _any_match(FILE_PATH_RECOGNIZER, text), f"Chemin non détecté : {text!r}"


@pytest.mark.parametrize("text", [
    "rapport.pdf",      # nom de fichier seul sans chemin
    "dossier/",         # un seul composant
])
def test_filepath_invalid(text):
    assert not _any_match(FILE_PATH_RECOGNIZER, text), f"Chemin ne devrait pas matcher : {text!r}"


# ---------------------------------------------------------------------------
# FR_TITLED_PERSON — nom précédé d'un titre civil ou médical
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", [
    "Dr. Martin Dupont",
    "Dr Martin Dupont",
    "Pr Roland Sambuc",
    "M. Jean-Pierre Durand",
    "Mme Sylvie Mercier",
    "Monsieur Jean Dupont",
    "Madame Marie Curie",
])
def test_titled_person_valid(text):
    assert _any_match(FR_TITLED_PERSON_RECOGNIZER, text), f"Personne titrée non détectée : {text!r}"


@pytest.mark.parametrize("text", [
    "Jean Dupont",    # pas de titre → non couvert par ce reconnaisseur
    "M",              # titre seul sans nom
])
def test_titled_person_no_title_not_matched(text):
    assert not _any_match(FR_TITLED_PERSON_RECOGNIZER, text), f"Ne devrait pas matcher sans titre complet : {text!r}"


# ---------------------------------------------------------------------------
# Vérification structurelle des reconnaisseurs (non-régression du registre)
# ---------------------------------------------------------------------------

def test_all_recognizers_have_at_least_one_pattern():
    recognizers = [
        NIR_RECOGNIZER, SIRET_RECOGNIZER, SIREN_RECOGNIZER, TVA_RECOGNIZER,
        PHONE_FR_RECOGNIZER, PASSPORT_FR_RECOGNIZER, CNI_RECOGNIZER,
        DRIVING_LICENSE_FR_RECOGNIZER, POSTAL_CODE_FR_RECOGNIZER,
        FILE_PATH_RECOGNIZER, FR_TITLED_PERSON_RECOGNIZER,
    ]
    for rec in recognizers:
        assert len(rec.patterns) >= 1, f"{rec.name} n'a aucun pattern"


def test_all_recognizers_have_valid_regex():
    recognizers = [
        NIR_RECOGNIZER, SIRET_RECOGNIZER, SIREN_RECOGNIZER, TVA_RECOGNIZER,
        PHONE_FR_RECOGNIZER, PASSPORT_FR_RECOGNIZER, CNI_RECOGNIZER,
        DRIVING_LICENSE_FR_RECOGNIZER, POSTAL_CODE_FR_RECOGNIZER,
        FILE_PATH_RECOGNIZER, FR_TITLED_PERSON_RECOGNIZER,
    ]
    for rec in recognizers:
        for pattern in rec.patterns:
            try:
                re.compile(pattern.regex)
            except re.error as e:
                pytest.fail(f"Regex invalide dans {rec.name}/{pattern.name}: {e}")


# ---------------------------------------------------------------------------
# get_french_recognizers — registre complet (ligne 282)
# ---------------------------------------------------------------------------

def test_get_french_recognizers_returns_all_instances():
    from nomosai.recognizers_fr import get_french_recognizers
    recs = get_french_recognizers()
    assert len(recs) >= 10, "Le registre FR doit contenir au moins 10 reconnaisseurs"
    names = [r.name for r in recs]
    assert "French NIR Recognizer" in names
    assert "French SIRET Recognizer" in names
    assert "French SIREN Recognizer" in names
    assert "French Phone Recognizer" in names
    assert "French Titled Person Recognizer" in names


def test_get_french_recognizers_all_support_fr_language():
    from nomosai.recognizers_fr import get_french_recognizers
    for rec in get_french_recognizers():
        assert "fr" in rec.supported_language, f"{rec.name} ne déclare pas la langue 'fr'"
