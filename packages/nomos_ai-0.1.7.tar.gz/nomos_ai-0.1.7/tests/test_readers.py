"""
Tests unitaires pour readers.py — aucune dépendance PDF/DOCX.
Couvre Block, read_txt (via read_document), read_md.
"""

import pytest
from pathlib import Path

from nomosai.readers import Block, read_document, SUPPORTED_EXTENSIONS


# ---------------------------------------------------------------------------
# Block dataclass
# ---------------------------------------------------------------------------

def test_block_requires_type_and_text():
    b = Block(type="paragraph", text="Bonjour")
    assert b.type == "paragraph"
    assert b.text == "Bonjour"
    assert b.cells is None


def test_block_with_cells():
    b = Block(type="table_row", text="", cells=[["A", "B"]])
    assert b.cells == [["A", "B"]]


def test_block_types_are_strings():
    for btype in ("heading1", "heading2", "heading3", "paragraph", "table_row", "list_item", "hr"):
        b = Block(type=btype, text="x")
        assert b.type == btype


# ---------------------------------------------------------------------------
# SUPPORTED_EXTENSIONS
# ---------------------------------------------------------------------------

def test_supported_extensions_includes_common_formats():
    for ext in (".txt", ".md", ".docx", ".pdf"):
        assert ext in SUPPORTED_EXTENSIONS, f"Extension manquante : {ext}"


def test_supported_extensions_are_lowercase():
    for ext in SUPPORTED_EXTENSIONS:
        assert ext == ext.lower(), f"Extension non en minuscules : {ext}"


# ---------------------------------------------------------------------------
# read_document — fichier .txt
# ---------------------------------------------------------------------------

def test_read_txt_plain_text(tmp_path):
    doc = tmp_path / "test.txt"
    doc.write_text("Bonjour le monde.\nDeuxième ligne.", encoding="utf-8")
    blocks = read_document(doc)
    assert isinstance(blocks, list)
    assert len(blocks) >= 1
    full_text = " ".join(b.text for b in blocks)
    assert "Bonjour le monde" in full_text


def test_read_txt_empty_returns_no_blocks(tmp_path):
    doc = tmp_path / "empty.txt"
    doc.write_text("", encoding="utf-8")
    blocks = read_document(doc)
    assert blocks == []


def test_read_txt_whitespace_only_returns_no_blocks(tmp_path):
    doc = tmp_path / "whitespace.txt"
    doc.write_text("   \n\n   \n", encoding="utf-8")
    blocks = read_document(doc)
    assert blocks == []


def test_read_txt_multiline_produces_multiple_blocks(tmp_path):
    doc = tmp_path / "multi.txt"
    doc.write_text("Ligne un.\n\nLigne deux.\n\nLigne trois.", encoding="utf-8")
    blocks = read_document(doc)
    assert len(blocks) >= 2


def test_read_txt_block_types_are_paragraph(tmp_path):
    doc = tmp_path / "para.txt"
    doc.write_text("Un paragraphe simple.", encoding="utf-8")
    blocks = read_document(doc)
    for b in blocks:
        assert b.type in ("paragraph", "heading1", "heading2", "heading3", "list_item", "hr")


# ---------------------------------------------------------------------------
# read_document — fichier .md
# ---------------------------------------------------------------------------

def test_read_md_heading1(tmp_path):
    doc = tmp_path / "doc.md"
    doc.write_text("# Titre principal\n\nUn paragraphe.", encoding="utf-8")
    blocks = read_document(doc)
    types = [b.type for b in blocks]
    assert "heading1" in types


def test_read_md_heading2(tmp_path):
    doc = tmp_path / "doc.md"
    doc.write_text("## Sous-titre\n\nTexte.", encoding="utf-8")
    blocks = read_document(doc)
    types = [b.type for b in blocks]
    assert "heading2" in types


def test_read_md_heading3(tmp_path):
    doc = tmp_path / "doc.md"
    doc.write_text("### Section\n\nTexte.", encoding="utf-8")
    blocks = read_document(doc)
    types = [b.type for b in blocks]
    assert "heading3" in types


def test_read_md_list_item(tmp_path):
    doc = tmp_path / "doc.md"
    doc.write_text("- Élément A\n- Élément B\n", encoding="utf-8")
    blocks = read_document(doc)
    types = [b.type for b in blocks]
    assert "list_item" in types


def test_read_md_horizontal_rule(tmp_path):
    doc = tmp_path / "doc.md"
    doc.write_text("Avant\n\n---\n\nAprès.", encoding="utf-8")
    blocks = read_document(doc)
    types = [b.type for b in blocks]
    assert "hr" in types


def test_read_md_paragraph_text_preserved(tmp_path):
    doc = tmp_path / "doc.md"
    doc.write_text("Un texte de paragraphe.", encoding="utf-8")
    blocks = read_document(doc)
    full = " ".join(b.text for b in blocks)
    assert "Un texte de paragraphe." in full


def test_read_md_mixed_content(tmp_path):
    content = (
        "# Chapitre 1\n\n"
        "Introduction du chapitre.\n\n"
        "## Section 1.1\n\n"
        "- Point A\n"
        "- Point B\n\n"
        "Conclusion.\n"
    )
    doc = tmp_path / "doc.md"
    doc.write_text(content, encoding="utf-8")
    blocks = read_document(doc)
    types = {b.type for b in blocks}
    assert "heading1" in types
    assert "heading2" in types
    assert "paragraph" in types or "list_item" in types


def test_read_md_empty_returns_no_blocks(tmp_path):
    doc = tmp_path / "empty.md"
    doc.write_text("", encoding="utf-8")
    blocks = read_document(doc)
    assert blocks == []


# ---------------------------------------------------------------------------
# read_document — extension non supportée
# ---------------------------------------------------------------------------

def test_read_document_unsupported_extension_raises(tmp_path):
    doc = tmp_path / "test.xyz"
    doc.write_text("contenu", encoding="utf-8")
    with pytest.raises((ValueError, SystemExit, Exception)):
        read_document(doc)
