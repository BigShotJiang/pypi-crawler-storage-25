"""
Tests unitaires purs pour les fonctions helper de server.py et l'outil MCP
list_entities — aucun chargement de modèle NLP requis.
"""

import json
import re
import pytest
from pathlib import Path
from nomosai.server import (
    _validate_entities,
    _merge_index_entries,
    _find_confidential_dir,
    _read_global_index,
    _write_global_index,
    _build_settings,
    _build_claude_md,
    list_entities,
)
from nomosai.engine import DEFAULT_ENTITIES


# ---------------------------------------------------------------------------
# _validate_entities — contrat : (valid_list, unknown_list)
# ---------------------------------------------------------------------------

def test_validate_none_returns_default_entities():
    valid, unknown = _validate_entities(None)
    assert valid == DEFAULT_ENTITIES
    assert unknown == []


def test_validate_known_entities_returned_as_valid():
    valid, unknown = _validate_entities(["PERSON", "EMAIL_ADDRESS"])
    assert "PERSON" in valid
    assert "EMAIL_ADDRESS" in valid
    assert unknown == []


def test_validate_unknown_entities_reported():
    valid, unknown = _validate_entities(["PERSON", "FAKE_ENTITY"])
    assert "FAKE_ENTITY" in unknown
    assert "PERSON" in valid


def test_validate_all_unknown_falls_back_to_defaults():
    valid, unknown = _validate_entities(["NONEXISTENT_A", "NONEXISTENT_B"])
    assert valid == DEFAULT_ENTITIES
    assert set(unknown) == {"NONEXISTENT_A", "NONEXISTENT_B"}


def test_validate_mixed_preserves_only_known():
    valid, unknown = _validate_entities(["PERSON", "BAD1", "EMAIL_ADDRESS", "BAD2"])
    assert set(valid) == {"PERSON", "EMAIL_ADDRESS"}
    assert set(unknown) == {"BAD1", "BAD2"}


# ---------------------------------------------------------------------------
# _merge_index_entries — contrat : clé unique = placeholder
# ---------------------------------------------------------------------------

def _entry(placeholder, original, entity_type="PERSON"):
    return {"placeholder": placeholder, "original": original,
            "entity_type": entity_type, "label": entity_type}


def test_merge_adds_new_entries():
    existing = [_entry("[PERSONNE_1]", "Alice")]
    new = [_entry("[EMAIL_1]", "alice@test.com", "EMAIL_ADDRESS")]
    merged = _merge_index_entries(existing, new)
    assert len(merged) == 2


def test_merge_deduplicates_by_placeholder_new_wins():
    existing = [_entry("[PERSONNE_1]", "Alice")]
    new = [_entry("[PERSONNE_1]", "Alice Updated")]
    merged = _merge_index_entries(existing, new)
    assert len(merged) == 1
    assert merged[0]["original"] == "Alice Updated"


def test_merge_empty_existing():
    new = [_entry("[PERSONNE_1]", "Bob")]
    assert len(_merge_index_entries([], new)) == 1


def test_merge_empty_new():
    existing = [_entry("[PERSONNE_1]", "Alice")]
    assert len(_merge_index_entries(existing, [])) == 1


def test_merge_both_empty():
    assert _merge_index_entries([], []) == []


# ---------------------------------------------------------------------------
# _find_confidential_dir — contrat : retrouve documents-confidentiels/ par heuristique
# ---------------------------------------------------------------------------

def test_find_confidential_dir_as_ancestor_of_input(tmp_path):
    conf = tmp_path / "documents-confidentiels"
    conf.mkdir()
    doc = conf / "document.pdf"
    doc.touch()
    out = tmp_path / "documents-anonymisés" / "document.md"
    result = _find_confidential_dir(doc, out)
    assert result == conf


def test_find_confidential_dir_as_sibling_of_input_parent(tmp_path):
    conf = tmp_path / "documents-confidentiels"
    conf.mkdir()
    sources = tmp_path / "sources"
    sources.mkdir()
    doc = sources / "document.pdf"
    doc.touch()
    out = tmp_path / "documents-anonymisés" / "document.md"
    result = _find_confidential_dir(doc, out)
    assert result == conf


def test_find_confidential_dir_not_found(tmp_path):
    doc = tmp_path / "document.pdf"
    doc.touch()
    out = tmp_path / "document_anonymise.md"
    result = _find_confidential_dir(doc, out)
    assert result is None


def test_find_confidential_dir_found_via_output_path(tmp_path):
    # Le répertoire documents-confidentiels/ est ancêtre du chemin de sortie
    conf = tmp_path / "projet" / "documents-confidentiels"
    conf.mkdir(parents=True)
    doc = tmp_path / "autre" / "doc.pdf"
    doc.parent.mkdir(parents=True)
    doc.touch()
    out = tmp_path / "projet" / "documents-confidentiels" / "documents-anonymisés" / "doc.md"
    result = _find_confidential_dir(doc, out)
    assert result == conf


# ---------------------------------------------------------------------------
# list_entities — outil MCP, aucun modèle requis
# ---------------------------------------------------------------------------

def test_list_entities_returns_required_keys():
    result = list_entities("fr")
    assert "default_entities" in result
    assert "opt_in_entities" in result
    assert "total_default" in result
    assert "total_opt_in" in result
    assert "language" in result
    assert "note" in result


def test_list_entities_fr_includes_french_specific():
    result = list_entities("fr")
    default_types = {e["entity_type"] for e in result["default_entities"]}
    assert "FR_NIR" in default_types
    assert "FR_SIRET" in default_types
    assert "FR_SIREN" in default_types
    assert "FR_TVA" in default_types


def test_list_entities_en_excludes_french_only():
    result = list_entities("en")
    all_types = (
        {e["entity_type"] for e in result["default_entities"]}
        | {e["entity_type"] for e in result["opt_in_entities"]}
    )
    assert "FR_NIR" not in all_types
    assert "FR_SIRET" not in all_types


def test_list_entities_opt_in_contains_datetime_and_filepath():
    result = list_entities("fr")
    opt_in_types = {e["entity_type"] for e in result["opt_in_entities"]}
    assert "DATE_TIME" in opt_in_types
    assert "FILE_PATH" in opt_in_types


def test_list_entities_opt_in_not_in_default():
    result = list_entities("fr")
    default_types = {e["entity_type"] for e in result["default_entities"]}
    assert "DATE_TIME" not in default_types
    assert "FILE_PATH" not in default_types


def test_list_entities_counts_match_list_lengths():
    result = list_entities("fr")
    assert result["total_default"] == len(result["default_entities"])
    assert result["total_opt_in"] == len(result["opt_in_entities"])


def test_list_entities_each_entry_has_required_keys():
    result = list_entities("fr")
    required = {"entity_type", "label", "description", "opt_in"}
    for entry in result["default_entities"] + result["opt_in_entities"]:
        assert required <= set(entry.keys()), f"Missing keys in {entry}"


def test_list_entities_language_echoed():
    assert list_entities("fr")["language"] == "fr"
    assert list_entities("en")["language"] == "en"


# ---------------------------------------------------------------------------
# _build_settings — gabarit JSON pour les hooks Claude Code
# ---------------------------------------------------------------------------

def test_build_settings_is_valid_json():
    settings = json.loads(_build_settings())
    assert isinstance(settings, dict)


def test_build_settings_has_pretooluse_hook():
    settings = json.loads(_build_settings())
    assert "hooks" in settings
    hooks = settings["hooks"]
    assert "PreToolUse" in hooks
    assert len(hooks["PreToolUse"]) > 0


def test_build_settings_hook_targets_read_and_edit():
    settings = json.loads(_build_settings())
    matchers = [h["matcher"] for h in settings["hooks"]["PreToolUse"]]
    assert any("Read" in m for m in matchers)
    assert any("Edit" in m for m in matchers)


def test_build_settings_hook_references_block_script():
    settings = json.loads(_build_settings())
    commands = [
        h["command"]
        for group in settings["hooks"]["PreToolUse"]
        for h in group.get("hooks", [])
    ]
    assert any("block_confidentiel" in cmd for cmd in commands)


# ---------------------------------------------------------------------------
# _build_claude_md — gabarit Markdown pour les projets juridiques
# ---------------------------------------------------------------------------

def test_build_claude_md_contains_project_name():
    md = _build_claude_md("MonProjet")
    assert "MonProjet" in md


def test_build_claude_md_documents_all_subdirs():
    md = _build_claude_md("Test")
    for subdir in ("documents-confidentiels/", "sources/", "documents-anonymisés/", "livrables/", "artefacts/"):
        assert subdir in md, f"Répertoire manquant dans CLAUDE.md : {subdir}"


def test_build_claude_md_mentions_anonymize_file_tool():
    md = _build_claude_md("Test")
    assert "anonymize_file" in md


def test_build_claude_md_mentions_confidential_restriction():
    md = _build_claude_md("Test")
    # Le CLAUDE.md doit signaler que la lecture directe est interdite
    assert "interdit" in md.lower() or "interdite" in md.lower()


# ---------------------------------------------------------------------------
# MCP tools — chemins d'erreur qui ne nécessitent pas de modèle NLP
# ---------------------------------------------------------------------------


async def test_mcp_anonymize_file_file_not_found(mock_ctx):
    from nomosai.server import anonymize_file
    result = await anonymize_file(ctx=mock_ctx, file_path="/nonexistent/document.pdf")
    assert result["success"] is False
    assert result["error_type"] == "FileNotFound"


async def test_mcp_anonymize_file_unsupported_format(tmp_path, mock_ctx):
    from nomosai.server import anonymize_file
    doc = tmp_path / "document.xyz"
    doc.write_text("contenu", encoding="utf-8")
    result = await anonymize_file(ctx=mock_ctx, file_path=str(doc))
    assert result["success"] is False
    assert result["error_type"] == "UnsupportedFormat"


async def test_mcp_anonymize_file_unsupported_language(tmp_path, mock_ctx):
    from nomosai.server import anonymize_file
    doc = tmp_path / "document.txt"
    doc.write_text("contenu", encoding="utf-8")
    result = await anonymize_file(ctx=mock_ctx, file_path=str(doc), language="xx")
    assert result["success"] is False
    assert result["error_type"] == "UnsupportedLanguage"


def test_mcp_deanonymize_file_not_found():
    from nomosai.server import deanonymize_file
    result = deanonymize_file(anonymized_file_path="/nonexistent/doc.md")
    assert result["success"] is False
    assert result["error_type"] == "FileNotFound"


def test_mcp_deanonymize_file_wrong_extension(tmp_path):
    from nomosai.server import deanonymize_file
    doc = tmp_path / "doc.txt"
    doc.write_text("contenu", encoding="utf-8")
    result = deanonymize_file(anonymized_file_path=str(doc))
    assert result["success"] is False
    assert result["error_type"] == "InvalidFormat"


def test_mcp_deanonymize_file_index_not_found(tmp_path):
    from nomosai.server import deanonymize_file
    doc = tmp_path / "doc_anonymise.md"
    doc.write_text("[PERSONNE_1] a signé.", encoding="utf-8")
    result = deanonymize_file(anonymized_file_path=str(doc))
    assert result["success"] is False
    assert result["error_type"] == "IndexNotFound"


def test_mcp_deanonymize_file_explicit_index_not_found(tmp_path):
    from nomosai.server import deanonymize_file
    doc = tmp_path / "doc_anonymise.md"
    doc.write_text("[PERSONNE_1] a signé.", encoding="utf-8")
    result = deanonymize_file(
        anonymized_file_path=str(doc),
        index_path="/nonexistent/index.md",
    )
    assert result["success"] is False
    assert result["error_type"] == "FileNotFound"


def test_mcp_deanonymize_file_empty_index(tmp_path):
    from nomosai.server import deanonymize_file
    doc = tmp_path / "doc_anonymise.md"
    doc.write_text("[PERSONNE_1] a signé.", encoding="utf-8")
    idx = tmp_path / "doc_anonymise-index.md"
    idx.write_text("# Index vide\nAucun placeholder.\n", encoding="utf-8")
    result = deanonymize_file(anonymized_file_path=str(doc))
    assert result["success"] is False
    assert result["error_type"] == "EmptyIndex"


def test_mcp_deanonymize_file_success(tmp_path):
    from nomosai.server import deanonymize_file
    doc = tmp_path / "doc_anonymise.md"
    doc.write_text("[PERSONNE_1] a signé.", encoding="utf-8")
    idx = tmp_path / "doc_anonymise-index.md"
    idx.write_text(
        "| Placeholder | Valeur originale | Type |\n"
        "| --- | --- | --- |\n"
        "| `[PERSONNE_1]` | Jean Dupont | `PERSONNE` |\n",
        encoding="utf-8",
    )
    result = deanonymize_file(anonymized_file_path=str(doc))
    assert result["success"] is True
    assert result["replacements_count"] == 1
    output = Path(result["output_path"]).read_text(encoding="utf-8")
    assert "Jean Dupont" in output


def test_mcp_initiate_project_creates_structure(tmp_path):
    from nomosai.server import initiate_project
    project_dir = tmp_path / "mon_projet"
    result = initiate_project(directory=str(project_dir), project_name="MonProjet")
    assert result["success"] is True
    for subdir in ("documents-confidentiels", "sources", "documents-anonymisés", "livrables", "artefacts"):
        assert (project_dir / subdir).is_dir(), f"Répertoire manquant : {subdir}/"
    assert Path(result["claude_md_path"]).exists()
    assert Path(result["hook_path"]).exists()
    assert Path(result["settings_path"]).exists()


def test_mcp_initiate_project_claude_md_contains_name(tmp_path):
    from nomosai.server import initiate_project
    result = initiate_project(directory=str(tmp_path / "p"), project_name="TestNomosAI")
    assert "TestNomosAI" in Path(result["claude_md_path"]).read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# _read_global_index — lecture de l'index global depuis documents-confidentiels/
# ---------------------------------------------------------------------------

def _write_index_file(conf_dir: Path, content: str) -> None:
    (conf_dir / "_nomos_index.md").write_text(content, encoding="utf-8")


def test_read_global_index_no_file_returns_empty(tmp_path):
    result = _read_global_index(tmp_path)
    assert result == []


def test_read_global_index_parses_valid_row(tmp_path):
    _write_index_file(tmp_path, (
        "---\n"
        "generated: 2026-01-01 00:00:00\n"
        "total_entities: 1\n"
        "---\n\n"
        "| Placeholder | Valeur originale | Entité |\n"
        "| --- | --- | --- |\n"
        "| `[PERSONNE_1]` | Jean Dupont | `PERSON` |\n"
    ))
    entries = _read_global_index(tmp_path)
    assert len(entries) == 1
    assert entries[0]["placeholder"] == "[PERSONNE_1]"
    assert entries[0]["original"] == "Jean Dupont"
    assert entries[0]["entity_type"] == "PERSON"


def test_read_global_index_skips_non_matching_lines(tmp_path):
    _write_index_file(tmp_path, (
        "# Index global\n"
        "\n"
        "| --- | --- | --- |\n"
        "| `[EMAIL_1]` | alice@test.com | `EMAIL_ADDRESS` |\n"
    ))
    entries = _read_global_index(tmp_path)
    assert len(entries) == 1
    assert entries[0]["placeholder"] == "[EMAIL_1]"


def test_read_global_index_unescapes_pipe(tmp_path):
    _write_index_file(tmp_path, (
        "| `[PERSONNE_1]` | Jean \\| Dupont | `PERSON` |\n"
    ))
    entries = _read_global_index(tmp_path)
    assert entries[0]["original"] == "Jean | Dupont"


def test_read_global_index_unescapes_newline(tmp_path):
    _write_index_file(tmp_path, (
        "| `[PERSONNE_1]` | Jean\\nDupont | `PERSON` |\n"
    ))
    entries = _read_global_index(tmp_path)
    assert entries[0]["original"] == "Jean\nDupont"


def test_read_global_index_unreadable_file_returns_empty(tmp_path):
    # Crée un RÉPERTOIRE au lieu d'un fichier → read_text() lève une exception
    (tmp_path / "_nomos_index.md").mkdir()
    result = _read_global_index(tmp_path)
    assert result == []


def test_read_global_index_multiple_entries(tmp_path):
    _write_index_file(tmp_path, (
        "| `[PERSONNE_1]` | Alice Martin | `PERSON` |\n"
        "| `[EMAIL_1]` | alice@test.com | `EMAIL_ADDRESS` |\n"
        "| `[PERSONNE_2]` | Bob Dupont | `PERSON` |\n"
    ))
    entries = _read_global_index(tmp_path)
    assert len(entries) == 3
    placeholders = {e["placeholder"] for e in entries}
    assert "[PERSONNE_1]" in placeholders
    assert "[EMAIL_1]" in placeholders
    assert "[PERSONNE_2]" in placeholders


# ---------------------------------------------------------------------------
# _write_global_index — écriture de l'index global dans documents-confidentiels/
# ---------------------------------------------------------------------------

def test_write_global_index_creates_file(tmp_path):
    entries = [{"placeholder": "[PERSONNE_1]", "original": "Alice", "entity_type": "PERSON", "label": "PERSONNE"}]
    idx_path = _write_global_index(tmp_path, entries)
    assert idx_path.exists()
    assert idx_path.name == "_nomos_index.md"


def test_write_global_index_contains_placeholder(tmp_path):
    entries = [{"placeholder": "[EMAIL_1]", "original": "alice@test.com", "entity_type": "EMAIL_ADDRESS", "label": "EMAIL"}]
    _write_global_index(tmp_path, entries)
    content = (tmp_path / "_nomos_index.md").read_text(encoding="utf-8")
    assert "`[EMAIL_1]`" in content
    assert "alice@test.com" in content
    assert "`EMAIL_ADDRESS`" in content


def test_write_global_index_escapes_pipe_in_original(tmp_path):
    entries = [{"placeholder": "[PERSONNE_1]", "original": "Jean | Dupont", "entity_type": "PERSON", "label": "PERSONNE"}]
    _write_global_index(tmp_path, entries)
    content = (tmp_path / "_nomos_index.md").read_text(encoding="utf-8")
    assert r"Jean \| Dupont" in content


def test_write_global_index_contains_total_entities(tmp_path):
    entries = [
        {"placeholder": "[PERSONNE_1]", "original": "Alice", "entity_type": "PERSON", "label": "PERSONNE"},
        {"placeholder": "[EMAIL_1]", "original": "alice@test.com", "entity_type": "EMAIL_ADDRESS", "label": "EMAIL"},
    ]
    _write_global_index(tmp_path, entries)
    content = (tmp_path / "_nomos_index.md").read_text(encoding="utf-8")
    assert "total_entities: 2" in content


def test_write_then_read_roundtrip(tmp_path):
    entries = [
        {"placeholder": "[PERSONNE_1]", "original": "Jean Dupont", "entity_type": "PERSON", "label": "PERSONNE"},
        {"placeholder": "[EMAIL_1]", "original": "jean@test.com", "entity_type": "EMAIL_ADDRESS", "label": "EMAIL"},
    ]
    _write_global_index(tmp_path, entries)
    read_back = _read_global_index(tmp_path)
    assert len(read_back) == 2
    placeholders = {e["placeholder"] for e in read_back}
    assert "[PERSONNE_1]" in placeholders
    assert "[EMAIL_1]" in placeholders
