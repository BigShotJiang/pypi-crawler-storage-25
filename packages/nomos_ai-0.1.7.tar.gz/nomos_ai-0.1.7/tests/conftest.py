import pytest


def pytest_addoption(parser):
    parser.addoption(
        "--run-slow",
        action="store_true",
        default=False,
        help="Run slow integration tests (requires Presidio + spaCy fr_core_news_lg)",
    )


def pytest_collection_modifyitems(config, items):
    if not config.getoption("--run-slow"):
        skip = pytest.mark.skip(reason="use --run-slow to run integration tests")
        for item in items:
            if "slow" in item.keywords:
                item.add_marker(skip)


from unittest.mock import AsyncMock, MagicMock


@pytest.fixture
def mock_ctx():
    """Context MCP mocké pour les tests unitaires des outils async."""
    ctx = MagicMock()
    ctx.elicit = AsyncMock()
    return ctx


@pytest.fixture(scope="session")
def fr_anonymizer():
    """Session-scoped anonymizer backed by the real Presidio+spaCy pipeline."""
    try:
        from nomosai.engine import build_analyzer, DocumentAnonymizer
        analyzer = build_analyzer("fr")
        return DocumentAnonymizer(analyzer, language="fr", score_threshold=0.55)
    except OSError:
        pytest.skip("spaCy model fr_core_news_lg not installed")
    except ImportError:
        pytest.skip("presidio-analyzer not installed")
