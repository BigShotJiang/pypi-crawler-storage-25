"""
Tests unitaires pour formatter.py — aucune dépendance Presidio/spaCy.
Vérifie la sortie Markdown produite par to_markdown() et ses sous-fonctions.
"""

import re
import datetime
from pathlib import Path
import pytest

from nomosai.readers import Block
from nomosai.formatter import to_markdown


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _source(name="rapport.pdf") -> Path:
    return Path(name)


def _blocks(*args) -> list[Block]:
    """Crée des blocs depuis des tuples (type, text)."""
    return [Block(type=t, text=txt) for t, txt in args]


# ---------------------------------------------------------------------------
# to_markdown — structure globale
# ---------------------------------------------------------------------------

def test_to_markdown_contains_frontmatter_delimiters():
    md = to_markdown(_blocks(("paragraph", "Texte.")), _source(), "fr", {}, 0.55)
    assert md.startswith("---\n")
    # Deux délimiteurs "---" : ouverture et fermeture du frontmatter
    assert md.count("---") >= 2


def test_to_markdown_body_after_frontmatter():
    blocks = _blocks(("paragraph", "Contenu du document."))
    md = to_markdown(blocks, _source(), "fr", {}, 0.55)
    # Le corps vient après le second "---"
    after_fm = md.split("---\n", 2)[-1]
    assert "Contenu du document." in after_fm


# ---------------------------------------------------------------------------
# Frontmatter YAML
# ---------------------------------------------------------------------------

def test_frontmatter_source_field():
    md = to_markdown(_blocks(("paragraph", "x")), Path("mon_rapport.pdf"), "fr", {}, 0.55)
    assert 'source: "mon_rapport.pdf"' in md


def test_frontmatter_language_field():
    md = to_markdown(_blocks(("paragraph", "x")), _source(), "fr", {}, 0.55)
    assert "language: fr" in md


def test_frontmatter_score_threshold_field():
    md = to_markdown(_blocks(("paragraph", "x")), _source(), "fr", {}, 0.70)
    assert "score_threshold: 0.7" in md


def test_frontmatter_total_entities_zero_when_no_stats():
    md = to_markdown(_blocks(("paragraph", "x")), _source(), "fr", {}, 0.55)
    assert "total_entities_redacted: 0" in md


def test_frontmatter_entities_listed_when_stats_present():
    stats = {"PERSON": 3, "EMAIL_ADDRESS": 1}
    md = to_markdown(_blocks(("paragraph", "x")), _source(), "fr", stats, 0.55)
    assert "entities_redacted:" in md
    assert "PERSONNE: 3" in md
    assert "EMAIL: 1" in md


def test_frontmatter_no_entities_section_when_empty_stats():
    md = to_markdown(_blocks(("paragraph", "x")), _source(), "fr", {}, 0.55)
    # "total_entities_redacted: 0" est toujours présent ;
    # vérifier que la SECTION YAML avec ses enfants (labels indentés) n'existe pas.
    assert not re.search(r"^entities_redacted:$", md, re.MULTILINE)


# ---------------------------------------------------------------------------
# Corps du document — types de blocs
# ---------------------------------------------------------------------------

def test_body_heading1():
    md = to_markdown(_blocks(("heading1", "Titre principal")), _source(), "fr", {}, 0.55)
    assert "# Titre principal" in md


def test_body_heading2():
    md = to_markdown(_blocks(("heading2", "Sous-titre")), _source(), "fr", {}, 0.55)
    assert "## Sous-titre" in md


def test_body_heading3():
    md = to_markdown(_blocks(("heading3", "Section")), _source(), "fr", {}, 0.55)
    assert "### Section" in md


def test_body_paragraph():
    md = to_markdown(_blocks(("paragraph", "Un paragraphe ordinaire.")), _source(), "fr", {}, 0.55)
    assert "Un paragraphe ordinaire." in md


def test_body_list_item():
    md = to_markdown(_blocks(("list_item", "Élément de liste")), _source(), "fr", {}, 0.55)
    assert "- Élément de liste" in md


def test_body_hr():
    md = to_markdown(_blocks(("hr", "---")), _source(), "fr", {}, 0.55)
    # L'output contient au moins une ligne "---" pour la règle horizontale
    assert "---" in md


def test_body_empty_block_skipped():
    blocks = [
        Block(type="paragraph", text=""),
        Block(type="paragraph", text="Contenu réel."),
    ]
    md = to_markdown(blocks, _source(), "fr", {}, 0.55)
    assert "Contenu réel." in md


def test_body_multiple_block_types():
    blocks = [
        Block(type="heading1", text="Chapitre 1"),
        Block(type="paragraph", text="Introduction."),
        Block(type="list_item", text="Point A"),
        Block(type="list_item", text="Point B"),
    ]
    md = to_markdown(blocks, _source(), "fr", {}, 0.55)
    assert "# Chapitre 1" in md
    assert "Introduction." in md
    assert "- Point A" in md
    assert "- Point B" in md


# ---------------------------------------------------------------------------
# Corps du document — tableaux
# ---------------------------------------------------------------------------

def test_body_table_row_renders_markdown_table():
    blocks = [
        Block(type="table_row", text="", cells=[["Nom", "Prénom"]]),
        Block(type="table_row", text="", cells=[["Dupont", "Jean"]]),
    ]
    md = to_markdown(blocks, _source(), "fr", {}, 0.55)
    assert "| Nom | Prénom |" in md
    assert "| --- |" in md
    assert "| Dupont | Jean |" in md


def test_body_table_row_without_cells_falls_back_to_text():
    blocks = [Block(type="table_row", text="Ligne texte", cells=None)]
    md = to_markdown(blocks, _source(), "fr", {}, 0.55)
    assert "Ligne texte" in md


def test_body_table_then_non_table_flushes_table():
    # Transition table → paragraphe déclenche _flush_table (ligne 125 formatter.py)
    blocks = [
        Block(type="table_row", text="", cells=[["Col1", "Col2"]]),
        Block(type="table_row", text="", cells=[["Val1", "Val2"]]),
        Block(type="paragraph", text="Après le tableau."),
    ]
    md = to_markdown(blocks, _source(), "fr", {}, 0.55)
    assert "| Col1 | Col2 |" in md
    assert "Après le tableau." in md


def test_body_table_row_no_cells_after_table_rows_flushes():
    # table_row sans cells après table_row avec cells → _flush_table (ligne 118)
    blocks = [
        Block(type="table_row", text="", cells=[["Entête A"]]),
        Block(type="table_row", text="Texte brut", cells=None),
    ]
    md = to_markdown(blocks, _source(), "fr", {}, 0.55)
    assert "| Entête A |" in md
    assert "Texte brut" in md


# ---------------------------------------------------------------------------
# Pas de doublons de lignes vides consécutives dans le corps
# ---------------------------------------------------------------------------

def test_body_no_consecutive_blank_lines():
    blocks = [
        Block(type="paragraph", text="Para 1"),
        Block(type="paragraph", text=""),
        Block(type="paragraph", text=""),
        Block(type="paragraph", text="Para 2"),
    ]
    md = to_markdown(blocks, _source(), "fr", {}, 0.55)
    assert "\n\n\n" not in md
