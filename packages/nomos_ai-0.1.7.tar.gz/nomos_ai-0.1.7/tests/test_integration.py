"""
Tests d'intégration — pipeline complet Presidio + spaCy fr_core_news_lg.

Ces tests sont lents (chargement du modèle ~10s) et sont ignorés par défaut.
Pour les exécuter : pytest --run-slow

La fixture `fr_anonymizer` est définie dans conftest.py (scope session).
"""

import re
import pytest
from deanonymize import restore_text


# Helper : reset avant chaque appel pour repartir d'un index vide
def _anon(anonymizer, text, entities=None):
    anonymizer.reset()
    return anonymizer.anonymize_text(text, entities)


# ---------------------------------------------------------------------------
# Détection de personnes (avec et sans titre)
# ---------------------------------------------------------------------------

@pytest.mark.slow
@pytest.mark.parametrize("text,expected_label", [
    ("Dr. Martin Dupont a signé le rapport.", "PERSONNE"),
    ("Mme Sylvie Mercier est présente.", "PERSONNE"),
    ("M. Jean-Pierre Durand a été convoqué.", "PERSONNE"),
    ("Pr Roland Sambuc a publié cette étude.", "PERSONNE"),
])
def test_person_with_title_anonymized(fr_anonymizer, text, expected_label):
    result = _anon(fr_anonymizer, text)
    assert f"[{expected_label}_" in result, f"Personne non anonymisée dans : {result!r}"


@pytest.mark.slow
def test_person_name_consistency_across_occurrences(fr_anonymizer):
    fr_anonymizer.reset()
    text = "Dr. Jean Dupont a contacté Dr. Jean Dupont hier."
    result = fr_anonymizer.anonymize_text(text)
    placeholders = re.findall(r"\[PERSONNE_\d+\]", result)
    assert len(placeholders) == 2, f"Devrait trouver 2 occurrences dans : {result!r}"
    assert placeholders[0] == placeholders[1], "Même personne → même placeholder"


# ---------------------------------------------------------------------------
# Détection d'emails
# ---------------------------------------------------------------------------

@pytest.mark.slow
@pytest.mark.parametrize("email", [
    "jean.dupont@cabinet.fr",
    "contact@entreprise.com",
    "support+filtre@domaine.org",
])
def test_email_anonymized(fr_anonymizer, email):
    result = _anon(fr_anonymizer, f"Contactez {email} pour toute question.")
    assert "[EMAIL_" in result, f"Email non anonymisé dans : {result!r}"


# ---------------------------------------------------------------------------
# Détection de téléphones
# ---------------------------------------------------------------------------

@pytest.mark.slow
@pytest.mark.parametrize("text", [
    "Appelez le 01 23 45 67 89.",
    "Mon mobile : 06 12 34 56 78.",
    "Numéro international : 0033 6 12 34 56 78.",
])
def test_phone_anonymized(fr_anonymizer, text):
    result = _anon(fr_anonymizer, text)
    assert "[TELEPHONE_" in result, f"Téléphone non anonymisé dans : {result!r}"


# ---------------------------------------------------------------------------
# Entités françaises spécifiques
# ---------------------------------------------------------------------------

@pytest.mark.slow
def test_siret_with_context_anonymized(fr_anonymizer):
    result = _anon(fr_anonymizer, "Le SIRET de la société est 73282932000074.")
    assert "[SIRET_" in result, f"SIRET non anonymisé dans : {result!r}"


@pytest.mark.slow
def test_nir_with_context_anonymized(fr_anonymizer):
    result = _anon(fr_anonymizer, "Numéro de sécurité sociale : 1 85 05 75 100 399 42.")
    assert "[NIR_" in result, f"NIR non anonymisé dans : {result!r}"


@pytest.mark.slow
def test_tva_with_context_anonymized(fr_anonymizer):
    result = _anon(fr_anonymizer, "Notre numéro de TVA intracommunautaire est FR07732829320.")
    assert "[TVA_" in result, f"TVA non anonymisée dans : {result!r}"


# ---------------------------------------------------------------------------
# Faux positifs — ne doivent PAS être anonymisés
# ---------------------------------------------------------------------------

@pytest.mark.slow
@pytest.mark.parametrize("text", [
    "Résultat : NC",
    "Section II.4 du rapport",
    "N = 1 035 patients",
])
def test_false_positives_not_anonymized(fr_anonymizer, text):
    result = _anon(fr_anonymizer, text)
    assert "[" not in result, f"Faux positif anonymisé dans : {result!r}"


# ---------------------------------------------------------------------------
# get_index — contrat de la structure retournée
# ---------------------------------------------------------------------------

@pytest.mark.slow
def test_get_index_contains_detected_entities(fr_anonymizer):
    fr_anonymizer.reset()
    text = "Dr. Jean Dupont a contacté jean@example.com."
    fr_anonymizer.anonymize_text(text)
    index = fr_anonymizer.get_index()
    assert len(index) >= 1
    for entry in index:
        assert "placeholder" in entry
        assert "original" in entry
        assert "entity_type" in entry
        assert "label" in entry


# ---------------------------------------------------------------------------
# Round-trip : anonymisation → restauration via restore_text
# ---------------------------------------------------------------------------

@pytest.mark.slow
def test_roundtrip_anonymize_then_restore(fr_anonymizer):
    original = "Dr. Jean Dupont travaille avec jean@example.com depuis Paris."
    fr_anonymizer.reset()
    anonymized = fr_anonymizer.anonymize_text(original)
    index = fr_anonymizer.get_index()
    mapping = {e["placeholder"]: e["original"] for e in index}
    restored = restore_text(anonymized, mapping)
    # Les valeurs détectées ont été restaurées
    for entry in index:
        assert entry["original"] in restored, f"Valeur non restaurée : {entry['original']!r}"


@pytest.mark.slow
def test_roundtrip_no_residual_placeholders(fr_anonymizer):
    original = "M. Pierre Martin, SIRET 73282932000074, email p.martin@cabinet.fr."
    fr_anonymizer.reset()
    anonymized = fr_anonymizer.anonymize_text(original)
    index = fr_anonymizer.get_index()
    mapping = {e["placeholder"]: e["original"] for e in index}
    restored = restore_text(anonymized, mapping)
    # Aucun placeholder résiduel dans le texte restauré
    assert not re.search(r"\[[A-Z_]+_\d+\]", restored), f"Placeholder résiduel dans : {restored!r}"


# ---------------------------------------------------------------------------
# MCP tool : anonymize_text (contrat de la réponse)
# ---------------------------------------------------------------------------

@pytest.mark.slow
def test_mcp_anonymize_text_success_contract(fr_anonymizer):
    from nomosai.server import anonymize_text as mcp_anonymize_text
    result = mcp_anonymize_text(
        text="Dr. Jean Dupont a signé.",
        language="fr",
        score_threshold=0.55,
    )
    assert result["success"] is True
    assert "anonymized_text" in result
    assert "stats" in result
    assert "total_entities" in result
    assert "index" in result
    assert isinstance(result["index"], list)


# Les tests d'erreur MCP (FileNotFound, UnsupportedFormat, etc.) sont dans
# test_server_unit.py — ils ne nécessitent pas de modèle NLP.
