Chapitres / notions de la formations:
- procedure d'installation
- vocabulaire: agent, sous-agent, AGI, LLM
- specificite de l'IA legale + problematique + obligations legales
- .CLAUDE.md, gestion / organisation de l'espace de travail
- skills -> assistant juridique
- MCP (API)
- gestion de contexte (token), gestion de modeles
- anonymisation
- methode de travail globale (outils, environment editeur de texte...)
- (paperasse, gestion, taff secretariat)


ToDo:
- determiner procedure de travail recommende Claude CoWork, VS Code, integration work, markdown...
- assistant juridique skill a recreer
- faire un cas de droit simple / cas d'ecole pour demos (Publique/Prive)
- finir une solution propre et simple d'utilisation pour anonymiser des docs
- formation maman step 2
- demarchage premiers clients
- materiel de formation, slide