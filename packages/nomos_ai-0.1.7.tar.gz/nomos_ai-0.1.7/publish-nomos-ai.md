# NomosAI — Anonymiseur de documents juridiques

Distribué comme **serveur MCP** — utilisable directement depuis Claude Desktop ou Claude Code, sans interface graphique.

## Publier une nouvelle version sur PyPI

### Première publication (une seule fois)

1. Créer un compte sur [pypi.org](https://pypi.org/account/register/)
2. Générer un token API : **Account Settings → API tokens → Add API token**
3. Publier :

```bash
uv build
uv publish --token pypi-<VOTRE_TOKEN>
```

For a specific version, specify version in pyproject.toml, then:

```bash
uv build
uv publish --token pypi-<VOTRE_TOKEN> dist/nomos_ai-0.1.1-py3-none-any.whl dist/nomos_ai-0.1.1.tar.gz
```

### Mettre à jour une version existante

```bash
# 1. Incrémenter la version dans pyproject.toml
#    ex. version = "0.1.0"  →  version = "0.2.0"

# 2. Construire et publier
uv build
uv publish --token pypi-<VOTRE_TOKEN>
```

### Vérifier l'installation depuis PyPI

Sur une machine sans l'environnement de développement :

```bash
uvx nomos-ai
# → le serveur MCP démarre (attend sur stdin, pas d'erreur)
```

### Stocker le token de façon permanente

Pour ne pas retaper le token à chaque publication, créer `~/.pypirc` :

```ini
[pypi]
  username = __token__
  password = pypi-<VOTRE_TOKEN>
```

Puis publier simplement avec :

```bash
uv publish
```
