# Jentic API Tools - LLM

Unified LLM provider abstraction for consistent LLM usage across the Jentic API Tools monorepo. Supports Anthropic Claude, AWS Bedrock, OpenAI, and Google Gemini behind a common interface.

## Key Features

The package provides an `LLMHelper` facade that automatically selects the configured provider and model, with a `light_mode` option for cheaper operations. Under the hood, each provider implements the `LLMProvider` abstract base class with a synchronous `call` method. Response parsing utilities handle markdown fence stripping, JSON extraction, and success field parsing from canonical LLM payloads. A `SemanticContextBuilder` constructs structured context strings from OpenAPI specs for inclusion in prompts.

## Dependencies

Internal: `jentic.apitools.common`. External: requests, boto3.

## Installation

```bash
pip install jentic-apitools-llm
```

## Quick Start

```python
from jentic.apitools.llm import LLMHelper

helper = LLMHelper()  # Uses settings defaults
response = helper.call_llm("Summarize this API endpoint.")

# Light mode for cheaper operations
helper = LLMHelper(light_mode=True)
response = helper.call_llm("Quick summary.")
```

## Testing

```bash
pytest tests -v
```
