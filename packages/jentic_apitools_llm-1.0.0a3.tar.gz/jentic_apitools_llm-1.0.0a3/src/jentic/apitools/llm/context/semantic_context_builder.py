"""
Context builder for semantic quality analysis of OpenAPI operations.

This module provides functions to extract and prepare context from
OpenAPI specifications for LLM-powered analysis.
"""

from __future__ import annotations

from typing import Any, Dict, List


__all__ = [
    "extract_semantic_context",
    "extract_operation_context",
    "batch_operations_smart",
    "prepare_batch_for_llm",
]


def extract_semantic_context(spec: dict[str, Any]) -> dict[str, Any]:
    """
    Extract high-level semantic context from OpenAPI spec.

    This context is shared across all operations in batches to provide
    understanding of the API's purpose, domain, and common patterns.

    Target: ~500-1000 tokens

    Args:
        spec: OpenAPI specification dictionary.

    Returns:
        Dictionary with semantic context including:
        - API overview (info)
        - Top referenced schemas (limited to 10-15)
        - Security schemes
        - Tags and their descriptions
        - Domain terminology
    """
    context: dict[str, Any] = {}

    # 1. API Overview - Essential context
    info = spec.get("info", {})
    context["api_info"] = {
        "title": info.get("title", ""),
        "description": info.get("description", ""),
        "version": info.get("version", ""),
        "purpose": info.get("summary", ""),
    }

    # 2. Tags - Categorization and domain understanding
    tags_list = spec.get("tags", [])
    if isinstance(tags_list, list):
        context["tags"] = [
            {
                "name": tag.get("name", ""),
                "description": tag.get("description", ""),
            }
            for tag in tags_list
            if isinstance(tag, dict) and tag.get("name")
        ][:20]  # Limit to first 20 tags

    # 3. Security Schemes - Access patterns
    components = spec.get("components", {})
    security_schemes = components.get("securitySchemes", {})
    if isinstance(security_schemes, dict):
        context["security_schemes"] = {
            name: {
                "type": scheme.get("type"),
                "description": scheme.get("description", "")[:100],  # Truncate long descriptions
            }
            for name, scheme in list(security_schemes.items())[:5]  # Limit to 5 schemes
            if isinstance(scheme, dict)
        }

    # 4. Top Schemas - Domain models (limited selection)
    # Count references to identify most used schemas
    schema_refs: dict[str, int] = {}

    def count_refs_recursive(obj: Any, current_count: dict[str, int]) -> None:
        """Recursively count $ref occurrences in spec."""
        if isinstance(obj, dict):
            if "$ref" in obj:
                ref = obj["$ref"]
                if isinstance(ref, str) and ref.startswith("#/components/schemas/"):
                    schema_name = ref.split("/")[-1]
                    current_count[schema_name] = current_count.get(schema_name, 0) + 1
            for value in obj.values():
                count_refs_recursive(value, current_count)
        elif isinstance(obj, list):
            for item in obj:
                count_refs_recursive(item, current_count)

    count_refs_recursive(spec, schema_refs)

    # Get top 10-15 most referenced schemas
    top_schemas = sorted(schema_refs.items(), key=lambda x: x[1], reverse=True)[:15]
    schemas = components.get("schemas", {})

    if isinstance(schemas, dict) and top_schemas:
        context["top_schemas"] = {}
        for schema_name, _ref_count in top_schemas:
            if schema_name in schemas:
                schema_def = schemas[schema_name]
                if isinstance(schema_def, dict):
                    # Include minimal schema info
                    properties = schema_def.get("properties", {})
                    properties_count = len(properties) if isinstance(properties, dict) else 0
                    context["top_schemas"][schema_name] = {
                        "type": schema_def.get("type"),
                        "description": schema_def.get("description", "")[:150],  # Truncate
                        "properties_count": properties_count,
                    }

    return context


def extract_operation_context(
    spec: dict[str, Any],
    path: str,
    method: str,
    operation: dict[str, Any],
    operation_id: str | None = None,
) -> dict[str, Any]:
    """
    Extract context for a single operation.

    Args:
        spec: OpenAPI specification dictionary.
        path: Path string (e.g., "/users/{id}").
        method: HTTP method (e.g., "get", "post").
        operation: Operation object from spec.
        operation_id: Optional operation ID for reference.

    Returns:
        Dictionary with operation context including:
        - Path and method
        - Current summary/description
        - Parameters
        - Request/response schemas (references only)
        - Tags
    """
    context: dict[str, Any] = {
        "path": path,
        "method": method.upper(),
        "operation_id": operation_id or operation.get("operationId", f"{method}_{path}"),
    }

    # Current documentation
    context["current_summary"] = operation.get("summary", "")
    context["current_description"] = operation.get("description", "")

    # Tags for categorization
    tags = operation.get("tags", [])
    if isinstance(tags, list):
        context["tags"] = [tag for tag in tags if isinstance(tag, str)]

    # Parameters - names and locations only
    parameters = operation.get("parameters", [])
    if isinstance(parameters, list):
        context["parameters"] = []
        for param in parameters:
            if isinstance(param, dict):
                if "$ref" in param:
                    context["parameters"].append({"$ref": param["$ref"]})
                else:
                    context["parameters"].append(
                        {
                            "name": param.get("name", ""),
                            "in": param.get("in", ""),
                            "required": param.get("required", False),
                            "description": param.get("description", "")[:100],  # Truncate
                        }
                    )

    # Request body - schema reference only
    request_body = operation.get("requestBody", {})
    if isinstance(request_body, dict):
        content = request_body.get("content", {})
        if isinstance(content, dict):
            # Get first content type (usually application/json)
            for _content_type, media_type in content.items():
                if isinstance(media_type, dict):
                    schema = media_type.get("schema", {})
                    if isinstance(schema, dict):
                        if "$ref" in schema:
                            context["request_schema"] = schema["$ref"]
                        else:
                            context["request_schema"] = {"type": schema.get("type", "object")}
                    break

    # Responses - schema references only for success responses
    responses = operation.get("responses", {})
    if isinstance(responses, dict):
        context["response_schemas"] = {}
        for status_code, response in responses.items():
            # Focus on 2xx responses
            if str(status_code).startswith("2") or status_code == "default":
                if isinstance(response, dict):
                    content = response.get("content", {})
                    if isinstance(content, dict):
                        for _content_type, media_type in content.items():
                            if isinstance(media_type, dict):
                                schema = media_type.get("schema", {})
                                if isinstance(schema, dict):
                                    if "$ref" in schema:
                                        context["response_schemas"][status_code] = schema["$ref"]
                                    else:
                                        context["response_schemas"][status_code] = {
                                            "type": schema.get("type", "object")
                                        }
                                break

    return context


def estimate_operation_tokens(operation_context: dict) -> int:
    """
    Estimate tokens for an operation based on description/summary length.

    Uses a conservative heuristic: ~4 characters ≈ 1 token for English text.
    Adds overhead for structured output per operation.

    Args:
        operation_context: Operation context dictionary from extract_operation_context()

    Returns:
        Estimated number of tokens for this operation's output
    """
    summary = operation_context.get("current_summary", "") or ""
    description = operation_context.get("current_description", "") or ""

    # Include parameter descriptions in the estimate
    params = operation_context.get("parameters", [])
    param_text = ""
    for param in params:
        if isinstance(param, dict):
            param_text += param.get("description", "") or ""

    total_chars = len(summary) + len(description) + len(param_text)

    # Add overhead for structured output per operation:
    # - operation_id, path, method fields (~30 tokens)
    # - LLM suggestion text (~50 tokens)
    # - JSON structure overhead (~20 tokens)
    overhead_tokens = 100

    return (total_chars // 4) + overhead_tokens


def batch_operations_smart(
    spec: dict[str, Any], batch_size: int = 7, max_output_tokens: int = 8000
) -> list[list[dict[str, Any]]]:
    """
    Group operations into smart batches for LLM processing.

    Strategy:
    1. Group by path (CRUD operations together)
    2. Group by tag (related functionality)
    3. Limit batch size by count AND estimated token usage
    4. Reserve ~50% of max_output_tokens for LLM-generated suggestions

    Args:
        spec: OpenAPI specification dictionary
        batch_size: Maximum number of operations per batch (default: 7)
        max_output_tokens: Maximum output tokens for LLM response (default: 8000)

    Returns:
        List of batches, where each batch is a list of operation contexts
    """
    http_methods = ["get", "post", "put", "patch", "delete", "options", "head", "trace"]

    # Token budget: reserve 25% for LLM suggestions
    token_budget_per_batch = (max_output_tokens * 3) // 4

    # First pass: Group operations by path
    path_groups: Dict[str, List[dict]] = {}

    paths = spec.get("paths", {})
    if not isinstance(paths, dict):
        return []

    for path_string, path_item in paths.items():
        if not isinstance(path_item, dict):
            continue

        operations_in_path: List[Dict[str, Any]] = []
        for method, operation in path_item.items():
            if method.lower() not in http_methods:
                continue
            if not isinstance(operation, dict):
                continue

            # Extract operation context
            operation_id = operation.get("operationId")
            op_context = extract_operation_context(
                spec, path_string, method, operation, operation_id
            )
            operations_in_path.append(op_context)

        if operations_in_path:
            path_groups[path_string] = operations_in_path

    # Second pass: Create batches with token awareness
    batches: list[list[dict[str, Any]]] = []
    current_batch: list[dict[str, Any]] = []
    current_batch_tokens = 0

    # Group by path first (keeps CRUD together)
    for _path_string, operations in path_groups.items():
        for operation in operations:
            op_tokens = estimate_operation_tokens(operation)

            # Check if adding this operation would exceed limits
            would_exceed_count = len(current_batch) >= batch_size
            would_exceed_tokens = (current_batch_tokens + op_tokens) > token_budget_per_batch

            # Start new batch if current one is full (by count or tokens)
            if current_batch and (would_exceed_count or would_exceed_tokens):
                batches.append(current_batch)
                current_batch = []
                current_batch_tokens = 0

            current_batch.append(operation)
            current_batch_tokens += op_tokens

    # Add remaining operations as final batch
    if current_batch:
        batches.append(current_batch)

    return batches


def prepare_batch_for_llm(
    semantic_context: dict[str, Any],
    operations_batch: list[dict[str, Any]],
) -> dict[str, Any]:
    """
    Prepare a complete context package for LLM analysis.

    Args:
        semantic_context: Shared semantic context from extract_semantic_context().
        operations_batch: List of operation contexts from batch_operations_smart().

    Returns:
        Complete context dictionary ready for LLM prompt.
    """
    return {
        "semantic_context": semantic_context,
        "operations": operations_batch,
        "batch_size": len(operations_batch),
    }
