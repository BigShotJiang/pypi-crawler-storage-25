"""
Base classes and utilities for LLM providers.

This module provides the abstract base class for LLM providers
and shared utility functions for processing LLM responses.
"""

from __future__ import annotations

import json
import logging
import re
from abc import ABC, abstractmethod


__all__ = [
    "LLMError",
    "LLMTruncatedError",
    "LLMProvider",
    "clean_llm_response",
    "parse_llm_json",
    "llm_call_success",
]


logger = logging.getLogger(__name__)


class LLMError(Exception):
    """Raised for any problem during an LLM request/response cycle."""


class LLMTruncatedError(LLMError):
    """Raised when LLM response is truncated due to max_tokens limit.

    Attributes:
        partial_response: The truncated response text that was received
        output_tokens: Number of tokens in the output (if available)
    """

    def __init__(
        self, message: str, partial_response: str = "", output_tokens: int | None = None
    ) -> None:
        super().__init__(message)
        self.partial_response = partial_response
        self.output_tokens = output_tokens


class LLMProvider(ABC):
    """
    Abstract contract implemented by concrete vendor helpers.

    All LLM providers must implement the `call` method to send prompts
    and receive responses from their respective APIs.

    Attributes:
        max_tokens: Maximum number of tokens for the response.
    """

    def __init__(self, max_tokens: int = 4096) -> None:
        self.max_tokens = max_tokens

    @abstractmethod
    def call(
        self,
        prompt: str,
        *,
        system_prompt: str | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
    ) -> str:
        """
        Send prompt to the LLM and return raw response text.

        Args:
            prompt: The user prompt to send to the LLM.
            system_prompt: Optional system prompt for context.
            model: Optional model override.
            max_tokens: Optional max tokens override.

        Returns:
            The LLM's response text.
        """


def clean_llm_response(text: str) -> str:
    """Strip markdown fences and whitespace from *text*.

    Also fixes invalid JSON escape sequences that LLMs sometimes produce
    when echoing back strings containing backslashes.

    The function assume the LLM returns a payload in the form::

        {
          "success": true | false,
          "output": "<string>"
        }
    """

    text = text.strip()

    if text.startswith("```"):
        text = re.sub(r"^```(?:\w+)?\n?", "", text)
        text = re.sub(r"\n?```$", "", text)

    # Fix invalid JSON escape sequences (e.g., \_ becomes \\_)
    # Valid JSON escapes are: \" \\ \/ \b \f \n \r \t \uXXXX
    # Only add backslash if there's an ODD number (actual invalid escape)
    # Even number of backslashes means they're all paired and char is regular
    def _fix_backslashes(match):
        backslashes = match.group(1)
        if len(backslashes) % 2 == 1:  # Odd = invalid escape, add one
            return backslashes + "\\"
        return backslashes  # Even = valid, leave alone

    text = re.sub(r'(\\+)(?!["\\/bfnrtu])', _fix_backslashes, text)

    # Fix malformed Unicode escape sequences like \uZZZZ or \u123 by
    # escaping the backslash so JSON treats them as literal text rather
    # than invalid escape sequences.
    def _escape_malformed_unicode(match):
        # Replace the single backslash-u with a double backslash-u.
        # The characters following \u are left unchanged.
        return "\\\\u"

    text = re.sub(r"\\u(?![0-9a-fA-F]{4})", _escape_malformed_unicode, text)

    return text.strip()


def parse_llm_json(text: str) -> dict | None:
    """
    Parse the expected JSON payload from an LLM response.

    The response text may be wrapped in markdown fences (```json ... ```),
    which are removed before parsing. Returns None if parsing fails.

    Args:
        text: Raw LLM response text.

    Returns:
        Parsed JSON object, or None if parsing fails.
    """
    cleaned = clean_llm_response(text)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError as exc:
        logger.error("Failed to parse JSON: %s", exc)
        logger.debug("Unparseable JSON content: %s", text)
        return None


def llm_call_success(text: str) -> bool | None:
    """
    Extract the boolean `success` field from a canonical LLM JSON payload.

    Expects the LLM to return a payload in the form:
        {"success": true | false, "output": "<string>"}

    Args:
        text: Raw LLM response text (not cleaned).

    Returns:
        The boolean value of the `success` field, or None if missing
        or if the text is not valid JSON.
    """
    try:
        cleaned = clean_llm_response(text)
        obj = json.loads(cleaned)
    except json.JSONDecodeError:
        return None

    val = obj.get("success")
    return val if isinstance(val, bool) else None
