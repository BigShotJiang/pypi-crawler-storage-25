"""
Public facade for Jentic LLM helpers.

This module provides a unified interface for interacting with various
LLM providers (OpenAI, Claude, Gemini, Bedrock).

Example usage::

    from jentic.apitools.llm import LLMHelper

    helper = LLMHelper(provider="OPENAI", model="gpt-4o-mini")
    text = helper.call_llm("Hello!")

    # Or use directly with API key
    helper = LLMHelper(provider="CLAUDE", api_key="sk-...")
    response = helper.call_llm("Analyze this code", system_prompt="You are a code reviewer")
"""

from __future__ import annotations

import logging
from typing import Any

from jentic.apitools.common.settings import get_settings, settings

from .base import (
    LLMError,
    LLMProvider,
    LLMTruncatedError,
    clean_llm_response,
    llm_call_success,
    parse_llm_json,
)
from .providers.anthropic import AnthropicProvider
from .providers.bedrock import BedrockProvider
from .providers.gemini import GeminiProvider
from .providers.openai import OpenAIProvider


__all__ = [
    "LLMError",
    "LLMTruncatedError",
    "LLMProvider",
    "clean_llm_response",
    "parse_llm_json",
    "llm_call_success",
    "LLMHelper",
    # Providers
    "OpenAIProvider",
    "AnthropicProvider",
    "GeminiProvider",
    "BedrockProvider",
    # Settings (re-exported for convenience)
    "settings",
    "get_settings",
]


logger = logging.getLogger(__name__)


_PROVIDER_MAP: dict[str, type[LLMProvider]] = {
    "OPENAI": OpenAIProvider,
    "CLAUDE": AnthropicProvider,
    "ANTHROPIC": AnthropicProvider,
    "GEMINI": GeminiProvider,
    "BEDROCK": BedrockProvider,
}


class LLMHelper:
    """
    Thin convenience wrapper retaining legacy API while delegating to provider class.

    This class provides a unified interface for interacting with different LLM providers.
    It handles provider selection, model defaults, and API configuration.

    Attributes:
        provider: The provider name (e.g., "OPENAI", "CLAUDE").
        api_key: The API key being used (if available).
        model: The model being used.

    Example::

        # Using environment defaults
        helper = LLMHelper()

        # Explicit provider and model
        helper = LLMHelper(provider="OPENAI", model="gpt-4o")

        # Light mode for faster/cheaper operations
        helper = LLMHelper(light_mode=True)
    """

    def __init__(
        self,
        provider: str | None = None,
        light_mode: bool = False,
        **kwargs: Any,
    ) -> None:
        """
        Initialize LLMHelper with specified or default provider.

        Args:
            provider: LLM provider name (OPENAI, CLAUDE, ANTHROPIC, GEMINI, BEDROCK).
                     If not specified, uses config default.
            light_mode: If True, use light/fast provider and model for cheaper operations.
            **kwargs: Additional arguments passed to the provider (api_key, model, etc.).
        """
        # Get fresh settings to pick up any env var changes
        llm_settings = get_settings().llm

        # Determine provider and model based on light mode
        if light_mode:
            llm_model = llm_settings.llm_light_model
            if provider is None:
                provider = llm_settings.light_provider
        else:
            llm_model = llm_settings.llm_model
            if provider is None:
                provider = llm_settings.provider

        provider = provider.upper()

        try:
            provider_cls: type[LLMProvider] = _PROVIDER_MAP[provider]
        except KeyError as exc:
            raise LLMError(f"Unknown LLM_PROVIDER: {provider}") from exc

        # Fill in defaults from config where not explicitly provided
        if provider == "OPENAI":
            kwargs.setdefault("model", llm_model)
            kwargs.setdefault("api_url", llm_settings.openai_api_url)
        elif provider in {"CLAUDE", "ANTHROPIC"}:
            kwargs.setdefault("model", llm_model)
            kwargs.setdefault("api_url", llm_settings.anthropic_api_url)
        elif provider == "GEMINI":
            kwargs.setdefault("model", llm_model)
            kwargs.setdefault("api_url_template", llm_settings.gemini_api_url)
        elif provider == "BEDROCK":
            kwargs.setdefault("model", llm_model)

        kwargs.setdefault("max_tokens", llm_settings.max_tokens)

        # Instantiate concrete provider helper
        self._delegate = provider_cls(**kwargs)

        # Expose commonly expected attributes for tests / backwards-compat
        self.provider: str = provider
        # Some provider classes expose .api_key – fall back to explicit kwarg or None
        self.api_key = getattr(self._delegate, "api_key", kwargs.get("api_key"))
        self.model = getattr(self._delegate, "model", kwargs.get("model"))

    def call_llm(
        self,
        prompt: str,
        *,
        system_prompt: str | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
    ) -> str:
        """
        Send a prompt to the LLM and return the response.

        Args:
            prompt: The user prompt to send.
            system_prompt: Optional system message for context.
            model: Optional model override for this call.
            max_tokens: Optional max tokens override for this call.

        Returns:
            The LLM's response text.
        """
        logger.info("Calling LLM %s - %s", self.provider, self.model)
        result = self._delegate.call(
            prompt, system_prompt=system_prompt, model=model, max_tokens=max_tokens
        )
        logger.info("Called LLM %s - %s", self.provider, self.model)
        return result

    # Static helpers re-exported for convenience
    clean_llm_response = staticmethod(clean_llm_response)
    parse_llm_json = staticmethod(parse_llm_json)
    llm_call_success = staticmethod(llm_call_success)
