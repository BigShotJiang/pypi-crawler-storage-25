"""
OpenAI LLM provider implementation.

This module provides the OpenAIProvider class for interacting with
the OpenAI chat completions API.
"""

from __future__ import annotations

import logging

import requests

from jentic.apitools.common.settings import get_settings

from ..base import LLMError, LLMProvider


__all__ = ["OpenAIProvider"]


logger = logging.getLogger(__name__)


class OpenAIProvider(LLMProvider):
    """
    Implementation for OpenAI chat completions API.

    Attributes:
        api_key: OpenAI API key.
        api_url: API endpoint URL.
        model: Model to use for completions.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        model: str = "gpt-4o",
        api_url: str | None = None,
        max_tokens: int = 4096,
    ) -> None:
        super().__init__(max_tokens=max_tokens)
        llm_settings = get_settings().llm
        self.api_key = api_key or llm_settings.openai_api_key
        if not self.api_key:
            raise LLMError("OPENAI_API_KEY not set via param or environment")
        self.api_url = api_url or llm_settings.openai_api_url
        self.model = model
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def call(
        self,
        prompt: str,
        *,
        system_prompt: str | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
    ) -> str:
        """
        Send a prompt to OpenAI and return the response.

        Args:
            prompt: The user prompt.
            system_prompt: Optional system message.
            model: Optional model override.
            max_tokens: Optional max tokens override.

        Returns:
            The assistant's response text.

        Raises:
            LLMError: If the API request fails or response is malformed.
        """
        messages: list[dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        data = {
            "model": model or self.model,
            "messages": messages,
            "max_tokens": max_tokens or self.max_tokens,
            "temperature": 0.0,
        }

        logger.debug("Calling OpenAI API")
        resp = requests.post(self.api_url, headers=self.headers, json=data, timeout=300)
        logger.debug("Called OpenAI API: %s %s", resp.status_code, resp.text[:200])

        if not resp.ok:
            logger.error("Error calling OpenAI API: %s %s", resp.status_code, resp.text[:200])
            raise LLMError(f"OpenAI API error: {resp.status_code} {resp.text}")

        try:
            return resp.json()["choices"][0]["message"]["content"].strip()
        except Exception as exc:
            raise LLMError(f"Malformed OpenAI response: {resp.text}") from exc
