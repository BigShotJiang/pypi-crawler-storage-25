"""
Anthropic Claude LLM provider implementation.

This module provides the AnthropicProvider class for interacting with
the Anthropic Claude messages API.
"""

from __future__ import annotations

import logging
from typing import Any

import requests

from jentic.apitools.common.settings import get_settings

from ..base import LLMError, LLMProvider


__all__ = ["AnthropicProvider"]


logger = logging.getLogger(__name__)


class AnthropicProvider(LLMProvider):
    """
    Implementation for Anthropic Claude messages API.

    Attributes:
        api_key: Anthropic API key.
        api_url: API endpoint URL.
        model: Model to use for completions.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        model: str = "claude-sonnet-4-20250514",
        api_url: str | None = None,
        max_tokens: int = 4096,
    ) -> None:
        super().__init__(max_tokens=max_tokens)
        llm_settings = get_settings().llm
        self.api_key = api_key or llm_settings.anthropic_api_key
        if not self.api_key:
            raise LLMError("ANTHROPIC_API_KEY not set via param or environment")
        self.api_url = api_url or llm_settings.anthropic_api_url
        self.model = model
        self.headers = {
            "x-api-key": self.api_key,
            "content-type": "application/json",
            "anthropic-version": "2023-06-01",
        }

    def call(
        self,
        prompt: str,
        *,
        system_prompt: str | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
    ) -> str:
        """
        Send a prompt to Claude and return the response.

        Args:
            prompt: The user prompt.
            system_prompt: Optional system message.
            model: Optional model override.
            max_tokens: Optional max tokens override.

        Returns:
            The assistant's response text.

        Raises:
            LLMError: If the API request fails or response is malformed.
        """
        data: dict[str, Any] = {
            "model": model or self.model,
            "max_tokens": max_tokens or self.max_tokens,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.0,
        }
        if system_prompt:
            data["system"] = system_prompt

        logger.debug("Calling Anthropic API")
        resp = requests.post(self.api_url, headers=self.headers, json=data, timeout=300)
        logger.debug("Called Anthropic API %s %s", resp.status_code, resp.text[:200])

        if not resp.ok:
            raise LLMError(f"Claude API error: {resp.status_code} {resp.text[:200]}")

        result = resp.json()

        # Handle modern content blocks format
        content_blocks = result.get("content")
        if content_blocks and isinstance(content_blocks, list):
            text = "".join(block.get("text", "") for block in content_blocks).strip()
            if text:
                return text

        # Handle legacy completion format
        legacy_text = result.get("completion", "").strip()
        if legacy_text:
            return legacy_text

        raise LLMError(f"Malformed Claude response: {result}")
