"""
AWS Bedrock LLM provider implementation.

This module provides the BedrockProvider class for interacting with
AWS Bedrock's Converse API.
"""

from __future__ import annotations

import logging
from typing import Any

from jentic.apitools.common.settings import get_settings

from ..base import LLMError, LLMProvider, LLMTruncatedError


__all__ = ["BedrockProvider"]


logger = logging.getLogger(__name__)


def _model_supports_json_format(model_id: str) -> bool:
    """
    Check if the Bedrock model supports native JSON format.

    Args:
        model_id: The Bedrock model ID.

    Returns:
        True if the model supports response_format in additionalModelRequestFields.
    """
    return "mistral.pixtral" in model_id


def _model_supports_system_prompt(model_id: str) -> bool:
    """
    Check if the Bedrock model supports system prompts.

    Args:
        model_id: The Bedrock model ID.

    Returns:
        True if the model supports system prompts.
    """
    if "anthropic.claude" in model_id:
        return True
    if "amazon.nova" in model_id:
        return True
    if "meta.llama3" in model_id:
        return True
    return False


class BedrockProvider(LLMProvider):
    """
    Implementation for AWS Bedrock Converse API.

    Note: Uses boto3 for AWS authentication. Requires appropriate
    AWS credentials configured (environment variables, config file,
    or IAM role).

    Attributes:
        region_name: AWS region for the Bedrock service.
        model: Model ID to use for completions.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,  # Not used, kept for interface consistency
        model: str = "eu.anthropic.claude-sonnet-4-20250514-v1:0",
        api_url: str | None = None,  # Not used, kept for interface consistency
        max_tokens: int = 8000,
    ) -> None:
        """
        Initialize BedrockProvider.

        Note:
            The api_key and api_url parameters are not used.
            Authentication is handled by boto3 using AWS credentials.
        """
        super().__init__(max_tokens=max_tokens)
        llm_settings = get_settings().llm
        self.region_name = llm_settings.aws_region
        self.model = model

        try:
            import boto3

            self.client = boto3.client(
                "bedrock-runtime",
                region_name=self.region_name,
            )
        except ImportError as exc:
            raise LLMError(
                "boto3 is required for BedrockProvider. Install the 'bedrock' or 'all' extra, for example: uv pip install -e '.[bedrock]'"
            ) from exc
        except Exception as exc:
            raise LLMError(f"Failed to initialize Bedrock client: {exc}") from exc

    def _create_bedrock_message(self, message: str) -> dict[str, Any]:
        """
        Convert a message string to Bedrock Converse API format.

        Args:
            message: String message.

        Returns:
            Bedrock-formatted message dictionary.
        """
        return {
            "role": "user",
            "content": [{"text": message}],
        }

    def call(
        self,
        prompt: str,
        *,
        system_prompt: str | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
    ) -> str:
        """
        Send a prompt to Bedrock and return the response.

        Args:
            prompt: The user prompt.
            system_prompt: Optional system message.
            model: Optional model override.
            max_tokens: Optional max tokens override.

        Returns:
            The assistant's response text.

        Raises:
            LLMError: If the API request fails or response is malformed.
        """
        from botocore.exceptions import ClientError

        try:
            model_id = model or self.model
            bedrock_message = self._create_bedrock_message(prompt)

            converse_params: dict[str, Any] = {
                "modelId": model_id,
                "messages": [bedrock_message],
            }

            # Build inference configuration
            inference_config = {
                "temperature": 0.0,
                "maxTokens": max_tokens or self.max_tokens,
            }
            converse_params["inferenceConfig"] = inference_config

            # Add JSON format support for compatible models
            if _model_supports_json_format(model_id):
                converse_params["additionalModelRequestFields"] = {
                    "response_format": {"type": "json_object"}
                }

            # Add system prompt for compatible models
            if system_prompt and _model_supports_system_prompt(model_id):
                converse_params["system"] = [{"text": system_prompt}]

            logger.debug("Calling Bedrock API")
            response = self.client.converse(**converse_params)
            logger.debug("Called Bedrock API")

            # Extract text from response
            text = ""
            if "output" in response and "message" in response["output"]:
                content_blocks = response["output"]["message"].get("content", [])
                for block in content_blocks:
                    if "text" in block:
                        text += block["text"]

            text = text.strip()
            if not text:
                raise LLMError(f"No output: {str(response)}")

            # Check for truncation due to max_tokens
            stop_reason = response.get("stopReason", "")
            output_tokens = response.get("usage", {}).get("outputTokens")
            if stop_reason == "max_tokens":
                raise LLMTruncatedError(
                    f"Response truncated at {output_tokens} tokens (stopReason: max_tokens)",
                    partial_response=text,
                    output_tokens=output_tokens,
                )

            return text

        except ClientError as exc:
            raise LLMError(f"Bedrock API error: {str(exc)}") from exc
        except Exception as exc:
            if isinstance(exc, LLMError):
                raise
            raise LLMError(f"Unexpected error calling Bedrock API: {str(exc)}") from exc
