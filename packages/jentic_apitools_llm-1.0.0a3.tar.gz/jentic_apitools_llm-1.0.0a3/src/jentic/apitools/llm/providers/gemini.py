"""
Google Gemini LLM provider implementation.

This module provides the GeminiProvider class for interacting with
the Google Gemini REST API.
"""

from __future__ import annotations

import logging

import requests

from jentic.apitools.common.settings import get_settings

from ..base import LLMError, LLMProvider


__all__ = ["GeminiProvider"]


logger = logging.getLogger(__name__)


class GeminiProvider(LLMProvider):
    """
    Implementation for Google Gemini REST API.

    Attributes:
        api_key: Gemini API key.
        api_url_template: API URL template with {model} placeholder.
        model: Model to use for completions.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        model: str = "gemini-2.5-flash",
        api_url_template: str | None = None,
        max_tokens: int = 4096,
    ) -> None:
        super().__init__(max_tokens=max_tokens)
        llm_settings = get_settings().llm
        self.api_key = api_key or llm_settings.gemini_api_key
        if not self.api_key:
            raise LLMError("GEMINI_API_KEY not set via param or environment")
        self.model = model
        self.api_url_template = api_url_template or llm_settings.gemini_api_url
        self.headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self.api_key,
        }

    def call(
        self,
        prompt: str,
        *,
        system_prompt: str | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
    ) -> str:
        """
        Send a prompt to Gemini and return the response.

        Args:
            prompt: The user prompt.
            system_prompt: Optional system message (prepended to prompt).
            model: Optional model override.
            max_tokens: Optional max tokens override.

        Returns:
            The assistant's response text.

        Raises:
            LLMError: If the API request fails or response is malformed.
        """
        url = self.api_url_template.format(model=model or self.model)

        parts: list[dict[str, str]] = []
        if system_prompt:
            parts.append({"text": system_prompt})
        parts.append({"text": prompt})

        data = {
            "contents": [{"role": "user", "parts": parts}],
            "generationConfig": {
                "maxOutputTokens": max_tokens or self.max_tokens,
                "temperature": 0.0,
            },
        }

        logger.debug("Calling Gemini API")
        resp = requests.post(url, headers=self.headers, json=data, timeout=300)
        logger.debug("Called Gemini API: %s", resp.status_code)

        if not resp.ok:
            raise LLMError(f"Gemini API error: {resp.status_code} {resp.text}")

        result = resp.json()

        # Extract text from response
        if result.get("candidates"):
            content = result["candidates"][0].get("content")
            if content and content.get("parts"):
                return content["parts"][0].get("text", "").strip()

        raise LLMError("Malformed Gemini response: No valid content found")
