from pydantic import BaseModel, Field
from requests import post
from typing import Optional, Union, List

from ishelly.components.base import JSONRPCRequest


# Configuration
class SwitchConfig(BaseModel):
    id: int = Field(..., description="Id of the Switch component instance")
    name: Optional[Union[str, None]] = Field(
        None, description="Name of the switch instance"
    )
    in_mode: Optional[str] = Field(
        None,
        description="Mode of the associated input. Range of values: momentary, follow, flip, detached, cycle, activate",
    )
    in_locked: Optional[bool] = Field(
        None,
        description="If True, all changes to physical inputs are ignored, regardless of mode",
    )
    initial_state: str = Field(..., description="Output state to set on power_on")
    auto_on: bool = Field(
        ...,
        description="True if the 'Automatic ON' function is enabled, false otherwise",
    )
    auto_on_delay: float = Field(
        ..., description="Seconds to pass until the component is switched back on"
    )
    auto_off: bool = Field(
        ...,
        description="True if the 'Automatic OFF' function is enabled, false otherwise",
    )
    auto_off_delay: float = Field(
        ..., description="Seconds to pass until the component is switched back off"
    )
    autorecover_voltage_errors: Optional[bool] = Field(
        None,
        description="True if switch output state should be restored after over/undervoltage error is cleared, false otherwise",
    )
    input_id: Optional[int] = Field(
        None, description="Id of the Input component which controls the Switch"
    )
    power_limit: Optional[int] = Field(
        None, description="Limit (in Watts) over which overpower condition occurs"
    )
    voltage_limit: Optional[int] = Field(
        None, description="Limit (in Volts) over which overvoltage condition occurs"
    )
    undervoltage_limit: Optional[int] = Field(
        None, description="Limit (in Volts) under which undervoltage condition occurs"
    )
    current_limit: Optional[float] = Field(
        None, description="Limit (in Amperes) over which overcurrent condition occurs"
    )
    reverse: Optional[bool] = Field(
        None,
        description="Reverse measurement direction of active power and energy (requires restart)",
    )
    restart_required: Optional[bool] = Field(
        None,
        description="Is a restart required?",
    )


# Status
class ActiveEnergy(BaseModel):
    total: float = Field(..., description="Total energy consumed in Watt-hours")
    by_minute: List[float] = Field(
        ...,
        description="Energy consumption by minute (in Milliwatt-hours) for the last three minutes",
    )
    minute_ts: int = Field(
        ...,
        description="Unix timestamp of the first second of the last minute (in UTC)",
    )


class Temperature(BaseModel):
    tC: Optional[Union[float, None]] = Field(None, description="Temperature in Celsius")
    tF: Optional[Union[float, None]] = Field(
        None, description="Temperature in Fahrenheit"
    )


class SwitchStatus(BaseModel):
    id: int = Field(..., description="Id of the Switch component instance")
    source: str = Field(..., description="Source of the last command")
    output: bool = Field(
        ..., description="true if the output channel is currently on, false otherwise"
    )
    timer_started_at: Optional[float] = Field(
        None, description="Unix timestamp, start time of the timer (in UTC)"
    )
    timer_duration: Optional[float] = Field(
        None, description="Duration of the timer in seconds"
    )
    apower: Optional[float] = Field(
        None, description="Last measured instantaneous active power (in Watts)"
    )
    voltage: Optional[float] = Field(None, description="Last measured voltage in Volts")
    current: Optional[float] = Field(
        None, description="Last measured current in Amperes"
    )
    pf: Optional[float] = Field(None, description="Last measured power factor")
    freq: Optional[float] = Field(
        None, description="Last measured network frequency in Hz"
    )
    aenergy: Optional[ActiveEnergy] = Field(
        None, description="Information about the active energy counter"
    )
    ret_aenergy: Optional[ActiveEnergy] = Field(
        None, description="Information about the returned active energy counter"
    )
    temperature: Optional[Temperature] = Field(
        None, description="Information about the temperature"
    )
    errors: Optional[List[str]] = Field(None, description="Error conditions occurred")


# Methods
# Switch.Set
class SwitchSetParams(BaseModel):
    id: int = Field(..., description="Id of the Switch component instance")
    on: bool = Field(..., description="State to set the switch")
    toggle_after: Optional[float] = Field(
        None, description="Seconds to pass until the switch state is toggled"
    )


class SwitchSetRequest(JSONRPCRequest):
    method: str = Field("Switch.Set", description="Method to be invoked")
    params: SwitchSetParams = Field(..., description="Parameters for the method")


class SwitchSetResponse(BaseModel):
    was_on: bool = Field(
        ...,
        description="True if the switch was on before the method was executed, false otherwise",
    )


# Switch.Toggle
class SwitchToggleParams(BaseModel):
    id: int = Field(..., description="Id of the Switch component instance")


class SwitchToggleRequest(JSONRPCRequest):
    method: str = Field("Switch.Toggle", description="Method to be invoked")
    params: SwitchToggleParams = Field(..., description="Parameters for the method")


class SwitchToggleResponse(BaseModel):
    was_on: bool = Field(
        ...,
        description="True if the switch was on before the method was executed, false otherwise",
    )


# Switch.GetStatus
class SwitchGetStatusParams(BaseModel):
    id: int = Field(..., description="Id of the Switch component instance")


class SwitchGetStatusRequest(JSONRPCRequest):
    method: str = Field("Switch.GetStatus", description="Method to be invoked")
    params: SwitchGetStatusParams = Field(..., description="Parameters for the method")


# Switch.SetConfig
class SwitchSetConfigParams(BaseModel):
    id: int = Field(..., description="Id of the Switch component instance")
    config: SwitchConfig = Field(..., description="Configuration for the Switch")


class SwitchSetConfigRequest(JSONRPCRequest):
    method: str = Field("Switch.SetConfig", description="Method to be invoked")
    params: SwitchSetConfigParams = Field(..., description="Parameters for the method")


class SwitchSetConfigResponse(BaseModel):
    restart_required: bool = Field(
        ...,
        description="True if a restart is required to apply the new configuration",
    )


# Switch.GetConfig
class SwitchGetConfigParams(BaseModel):
    id: int = Field(..., description="Id of the Switch component instance")


class SwitchGetConfigRequest(JSONRPCRequest):
    method: str = Field("Switch.GetConfig", description="Method to be invoked")
    params: SwitchGetConfigParams = Field(..., description="Parameters for the method")


# Switch.ResetCounters
class SwitchResetCountersParams(BaseModel):
    id: int = Field(..., description="Id of the Switch component instance")
    type: Optional[List[str]] = Field(
        None,
        description="Array of counter names to reset. If omitted, all counters are reset. Values: aenergy, ret_aenergy",
    )


class SwitchResetCountersRequest(JSONRPCRequest):
    method: str = Field("Switch.ResetCounters", description="Method to be invoked")
    params: SwitchResetCountersParams = Field(
        ..., description="Parameters for the method"
    )


class ResetEnergy(BaseModel):
    total: float = Field(
        ..., description="Total energy consumed in Watt-hours at time of reset"
    )


class SwitchResetCountersResponse(BaseModel):
    aenergy: Optional[ResetEnergy] = Field(
        None, description="Active energy counter value at the time of reset"
    )
    ret_aenergy: Optional[ResetEnergy] = Field(
        None, description="Returned active energy counter value at the time of reset"
    )


class Switch:
    def __init__(self, device_rpc_url: str, switch_id: int):
        self.switch_id = switch_id
        self.device_rpc_url = device_rpc_url

    def set(self, params: SwitchSetParams) -> SwitchSetResponse:
        req = SwitchSetRequest(id=1, params=params)
        response = post(self.device_rpc_url, json=req.model_dump())
        return SwitchSetResponse(**response.json()["result"])

    def toggle(self) -> SwitchToggleResponse:
        req = SwitchToggleRequest(id=1, params=SwitchToggleParams(id=self.switch_id))
        response = post(self.device_rpc_url, json=req.model_dump())
        return SwitchToggleResponse(**response.json()["result"])

    def get_status(self) -> SwitchStatus:
        req = SwitchGetStatusRequest(
            id=1, params=SwitchGetStatusParams(id=self.switch_id)
        )
        response = post(self.device_rpc_url, json=req.model_dump())
        return SwitchStatus(**response.json()["result"])

    def set_config(self, config: SwitchConfig) -> SwitchSetConfigResponse:
        req = SwitchSetConfigRequest(
            id=1, params=SwitchSetConfigParams(id=self.switch_id, config=config)
        )
        response = post(self.device_rpc_url, json=req.model_dump())
        return SwitchSetConfigResponse(**response.json()["result"])

    def get_config(self) -> SwitchConfig:
        req = SwitchGetConfigRequest(
            id=1, params=SwitchGetConfigParams(id=self.switch_id)
        )
        response = post(self.device_rpc_url, json=req.model_dump())
        return SwitchConfig(**response.json()["result"])

    def reset_counters(
        self, type: Optional[List[str]] = None
    ) -> SwitchResetCountersResponse:
        req = SwitchResetCountersRequest(
            id=1, params=SwitchResetCountersParams(id=self.switch_id, type=type)
        )
        response = post(self.device_rpc_url, json=req.model_dump())
        return SwitchResetCountersResponse(**response.json()["result"])
