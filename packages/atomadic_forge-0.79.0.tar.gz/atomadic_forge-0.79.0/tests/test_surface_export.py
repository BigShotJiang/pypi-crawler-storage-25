"""Tests for the canonical surface artifact emitter (Phase 1, v0.12.0).

The artifact is the single source of truth for tools, recipes,
schemas, and legacy-endpoint redirects. Consumers (the website, the
badge, the cognition worker, the CLI's own ``forge surface check``
gate) read it instead of maintaining their own copy.

These tests pin three properties:

1. **Content-addressed under fixed inputs.** Same TOOLS / SCHEMA /
   recipes inputs → same content (timestamp aside). This is what
   makes the CI drift gate work.
2. **Tool surface ↔ schema registry agreement.** Every tool name in
   TOOLS has a registered schema_version, and vice-versa. Drift
   between the two registries is exactly what the artifact prevents.
3. **diff_surfaces is symmetric on add/remove.** Adding tool X then
   removing it returns to baseline.
"""
from __future__ import annotations

import json

from atomadic_forge.a1_at_functions.mcp_protocol import TOOLS
from atomadic_forge.a3_og_features.surface_export import (
    LEGACY_ENDPOINT_MAP,
    SCHEMA_VERSION_SURFACE_V1,
    diff_surfaces,
    export_surface,
)

# ── shape ────────────────────────────────────────────────────────────

def test_export_surface_returns_expected_top_level_keys():
    s = export_surface()
    expected = {
        "schema_version", "package_version", "generated_at_utc",
        "tools_count", "recipes_count", "tools", "recipes",
        "legacy_endpoint_map", "redaction_hooks",
        "schema_version_registry",
    }
    assert expected.issubset(s.keys()), s.keys()
    assert s["schema_version"] == SCHEMA_VERSION_SURFACE_V1


def test_export_surface_tools_count_matches_tools_dict():
    s = export_surface()
    assert s["tools_count"] == len(TOOLS)
    assert len(s["tools"]) == len(TOOLS)


def test_export_surface_each_tool_entry_has_required_fields():
    s = export_surface()
    for entry in s["tools"]:
        assert set(entry).issuperset(
            {"name", "schema_version", "description",
             "input_schema", "handler_qualname"}
        ), entry


# ── content-addressed property ───────────────────────────────────────

def test_export_surface_is_deterministic_modulo_timestamp():
    """Two calls in a row return identical content (timestamp aside).

    This is what the CI drift gate relies on — re-emitting always
    produces byte-identical output for unchanged inputs.
    """
    a = export_surface()
    b = export_surface()
    a.pop("generated_at_utc")
    b.pop("generated_at_utc")
    assert json.dumps(a, sort_keys=True) == json.dumps(b, sort_keys=True)


# ── registry parity ──────────────────────────────────────────────────

def test_every_tool_has_a_schema_version_registry_entry():
    """Every TOOL name must appear in SCHEMA_VERSIONS.

    Reverse direction (every SCHEMA_VERSIONS entry maps to a live
    TOOL) is NOT enforced — some are reserved for tools not yet
    wired (round-2 transmuter pipeline, etc.).
    """
    s = export_surface()
    missing = [
        t["name"] for t in s["tools"]
        if t["schema_version"] is None
    ]
    assert not missing, (
        f"Tools without schema_version: {missing}. "
        f"Add them to a0_qk_constants/schema_version_registry.SCHEMA_VERSIONS."
    )


# ── legacy endpoint map ──────────────────────────────────────────────

def test_legacy_endpoint_map_targets_are_live_tools():
    """Every redirect target must be a tool that actually exists.

    Drift guard: if cognition_worker reads a `legacy_endpoint_map`
    pointing at a tool we deleted, every legacy call breaks
    silently. This test fails loud instead.
    """
    live_tool_names = set(TOOLS.keys())
    broken = {
        old: new for old, new in LEGACY_ENDPOINT_MAP.items()
        if new not in live_tool_names
    }
    assert not broken, (
        f"Legacy endpoint map points at tools that don't exist: {broken}. "
        f"Update LEGACY_ENDPOINT_MAP in surface_export.py."
    )


def test_legacy_endpoint_map_keys_are_not_live_tools():
    """A legacy name must NOT also be a current tool.

    If both, callers can't tell which surface they hit. Either it's
    deprecated (in the legacy map only) or current (in TOOLS only).
    """
    live = set(TOOLS.keys())
    overlap = set(LEGACY_ENDPOINT_MAP) & live
    assert not overlap, (
        f"These names are both legacy AND live tools: {overlap}. "
        f"Pick one."
    )


# ── recipes ──────────────────────────────────────────────────────────

def test_export_surface_recipes_present_and_shaped():
    s = export_surface()
    assert s["recipes_count"] >= 1
    for r in s["recipes"]:
        assert {"name", "schema_version", "description",
                "checklist_steps", "validation_gate_steps"} <= set(r)


# ── diff_surfaces ────────────────────────────────────────────────────

def _surface_with_tool_swap(*, add: list[str] = (),
                              remove: list[str] = ()) -> dict:
    """Build a synthetic surface for diff testing."""
    base = export_surface()
    tools = [t for t in base["tools"] if t["name"] not in remove]
    for name in add:
        tools.append({
            "name": name,
            "schema_version": f"atomadic-forge.{name}/v1",
            "description": "synthetic",
            "input_schema": {},
            "handler_qualname": None,
        })
    base["tools"] = tools
    base["tools_count"] = len(tools)
    return base


def test_diff_surfaces_reports_added_tool():
    before = export_surface()
    after = _surface_with_tool_swap(add=["new_tool_xyz"])
    delta = diff_surfaces(before, after)
    assert delta["tools_added"] == ["new_tool_xyz"]
    assert delta["tools_removed"] == []


def test_diff_surfaces_reports_removed_tool():
    before = export_surface()
    sample = before["tools"][0]["name"]
    after = _surface_with_tool_swap(remove=[sample])
    delta = diff_surfaces(before, after)
    assert delta["tools_removed"] == [sample]
    assert delta["tools_added"] == []


def test_diff_surfaces_reports_no_change_for_identical_surfaces():
    s = export_surface()
    delta = diff_surfaces(s, s)
    assert delta["tools_added"] == []
    assert delta["tools_removed"] == []
    assert delta["tools_with_schema_change"] == []


def test_diff_surfaces_reports_schema_change():
    before = export_surface()
    after = json.loads(json.dumps(before))  # deep copy
    after["tools"][0]["schema_version"] = "atomadic-forge.bumped/v2"
    delta = diff_surfaces(before, after)
    assert delta["tools_with_schema_change"] == [before["tools"][0]["name"]]


# ── package_version is real ──────────────────────────────────────────

def test_package_version_is_resolvable():
    s = export_surface()
    v = s["package_version"]
    assert v and v != "0.0.0+dev", (
        "Surface emitter could not resolve atomadic-forge package "
        "version via importlib.metadata. Check pip install -e ."
    )
