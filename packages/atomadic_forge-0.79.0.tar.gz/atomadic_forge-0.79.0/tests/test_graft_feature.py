"""Tests for `forge graft` — the surgical single-symbol grafter.

Closes the gap that ``transmute auto`` is whole-repo-only. Graft pulls
one named function or class out of a source file and drops it in the
right tier of the target, ready for ``forge auto-wire`` to surface a
CLI + MCP route automatically.
"""
from __future__ import annotations

from pathlib import Path

from atomadic_forge.a1_at_functions.graft_extract import (
    extract_symbol,
    render_grafted_module,
)
from atomadic_forge.a3_og_features.graft_feature import graft


def _seed_source(tmp_path: Path, body: str = "") -> Path:
    """Write a tiny Python source file under tmp_path and return its path."""
    tmp_path.mkdir(parents=True, exist_ok=True)
    src = tmp_path / "donor.py"
    src.write_text(body, encoding="utf-8")
    return src


def _seed_target(tmp_path: Path) -> Path:
    """Build the smallest tier-organized target tree the graft accepts."""
    pkg = tmp_path / "src" / "demo"
    for tier in (
        "a0_qk_constants", "a1_at_functions", "a2_mo_composites",
        "a3_og_features", "a4_sy_orchestration",
    ):
        (pkg / tier).mkdir(parents=True, exist_ok=True)
        (pkg / tier / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "__init__.py").write_text(
        "\"\"\"demo.\"\"\"\n__version__ = \"0.1.0\"\n", encoding="utf-8")
    return tmp_path


def test_extract_function_with_imports(tmp_path):
    """Stand-alone function extracted clean with its stdlib import."""
    src = _seed_source(
        tmp_path,
        "import math\n"
        "import os\n"
        "\n"
        "def add(a: float, b: float) -> float:\n"
        '    """sum."""\n'
        "    return a + b + math.pi\n",
    )
    extract = extract_symbol(src, "add")
    assert extract.kind == "function"
    assert "math" in extract.imports_needed
    # `os` was imported but not used inside `add`.
    assert "os" not in extract.imports_needed
    rendered = render_grafted_module(extract, source_file=src)
    assert "import math" in rendered
    assert "import os" not in rendered
    assert "def add(a: float, b: float) -> float:" in rendered


def test_extract_class(tmp_path):
    src = _seed_source(
        tmp_path,
        "class Node:\n"
        "    def __init__(self, value):\n"
        "        self.value = value\n",
    )
    extract = extract_symbol(src, "Node")
    assert extract.kind == "class"
    assert "class Node:" in extract.source


def test_graft_writes_renamed_function_to_a1(tmp_path):
    """Real graft: rename `_priv` -> `priv`, land in a1, wire PASS."""
    src = _seed_source(
        tmp_path / "src",
        "import math\n"
        "\n"
        "def _priv(x: float) -> float:\n"
        '    """square root."""\n'
        "    return math.sqrt(x)\n",
    )
    target = _seed_target(tmp_path / "tgt")
    report = graft(
        source_file=src,
        symbol_name="_priv",
        target_root=target,
        package="demo",
        rename_to="priv",
    )
    assert report.written
    assert report.symbol_name == "priv"
    dest = Path(report.target_path)
    assert dest.exists()
    text = dest.read_text(encoding="utf-8")
    # Renamed binding present, original underscore name is not.
    assert "def priv(x: float) -> float:" in text
    assert "def _priv(" not in text
    # Schema-version marker emitted so surface-gaps can pick it up.
    assert "SCHEMA_VERSION_GRAFT_PRIV" in text


def test_graft_dry_run_does_not_write(tmp_path):
    src = _seed_source(
        tmp_path / "src",
        "def hello() -> str:\n"
        "    return 'hi'\n",
    )
    target = _seed_target(tmp_path / "tgt")
    report = graft(
        source_file=src,
        symbol_name="hello",
        target_root=target,
        package="demo",
        dry_run=True,
    )
    assert report.written is False
    assert not Path(report.target_path).exists()


def test_graft_refuses_overwrite_by_default(tmp_path):
    src = _seed_source(
        tmp_path / "src",
        "def hello() -> str:\n    return 'hi'\n",
    )
    target = _seed_target(tmp_path / "tgt")
    # First graft: writes.
    graft(source_file=src, symbol_name="hello",
          target_root=target, package="demo")
    # Second graft without overwrite: errors.
    import pytest
    with pytest.raises(FileExistsError):
        graft(source_file=src, symbol_name="hello",
              target_root=target, package="demo")
    # Third graft with overwrite: succeeds.
    report = graft(source_file=src, symbol_name="hello",
                   target_root=target, package="demo", overwrite=True)
    assert report.written
    assert report.backup_path is not None


def test_graft_unknown_symbol_raises(tmp_path):
    src = _seed_source(tmp_path / "src", "x = 1\n")
    target = _seed_target(tmp_path / "tgt")
    import pytest
    with pytest.raises(KeyError):
        graft(source_file=src, symbol_name="not_there",
              target_root=target, package="demo")
