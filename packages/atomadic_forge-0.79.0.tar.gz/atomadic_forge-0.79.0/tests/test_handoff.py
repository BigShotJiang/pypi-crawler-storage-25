"""Tests for the v0.14.0a9 forge handoff tool."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from atomadic_forge.a0_qk_constants.handoff_constants import (
    AXIOM_GUARD_PASS,
    AXIOM_GUARD_QUARANTINE,
    HANDOFF_DIR_REL,
    KEY_CONTEXT_MAX_CHARS,
    SCHEMA_VERSION_HANDOFF_V1,
)
from atomadic_forge.a1_at_functions.handoff_builder import (
    make_handoff_entry,
    parse_pytest_summary,
)
from atomadic_forge.a3_og_features.handoff_feature import (
    list_handoffs,
    read_handoff,
    write_handoff,
)


def test_parse_pytest_summary_typical_line() -> None:
    out = parse_pytest_summary("==== 1133 passed, 0 failed, 2 skipped in 12.3s ====")
    assert out == {"passed": 1133, "failed": 0, "skipped": 2}


def test_parse_pytest_summary_errors_count_as_failed() -> None:
    out = parse_pytest_summary("3 passed, 1 error in 0.4s")
    assert out["passed"] == 3
    assert out["failed"] == 1


def test_parse_pytest_summary_empty_returns_zeros() -> None:
    assert parse_pytest_summary("") == {"passed": 0, "failed": 0, "skipped": 0}


def test_make_handoff_entry_minimum_fields() -> None:
    entry = make_handoff_entry(agent_name="claude")
    assert entry["schema_version"] == SCHEMA_VERSION_HANDOFF_V1
    assert entry["agent_name"] == "claude"
    assert entry["session_id"].startswith("HOFF-")
    assert entry["axiom_guard_status"] == AXIOM_GUARD_PASS
    assert entry["test_results"] == {"passed": 0, "failed": 0, "skipped": 0}
    assert entry["work_completed"] == []
    assert entry["files_modified"] == []
    assert entry["files_created"] == []
    assert entry["pending_tasks"] == []
    assert entry["warnings"] == []


def test_make_handoff_entry_normalizes_paths() -> None:
    entry = make_handoff_entry(
        files_modified=[r"src\foo.py", "src/foo.py", "  src/bar.py  ", ""],
        files_created=[r"a\b\c.py"],
    )
    assert entry["files_modified"] == ["src/foo.py", "src/bar.py"]
    assert entry["files_created"] == ["a/b/c.py"]


def test_make_handoff_entry_truncates_key_context() -> None:
    long_text = "x" * (KEY_CONTEXT_MAX_CHARS + 500)
    entry = make_handoff_entry(key_context=long_text)
    assert len(entry["key_context"]) == KEY_CONTEXT_MAX_CHARS
    assert entry["key_context"].endswith("...")


def test_make_handoff_entry_rejects_bad_axiom_guard() -> None:
    with pytest.raises(ValueError, match="axiom_guard_status"):
        make_handoff_entry(axiom_guard_status="MAYBE")


def test_make_handoff_entry_session_id_overrides() -> None:
    entry = make_handoff_entry(session_id="HOFF-custom-1")
    assert entry["session_id"] == "HOFF-custom-1"


def test_write_and_read_roundtrip(tmp_path: Path) -> None:
    out = write_handoff(
        project_root=tmp_path,
        agent_name="claude",
        work_completed=["built handoff tool"],
        pending_tasks=["polish README"],
        key_context="building forge handoff for demo",
        axiom_guard_status=AXIOM_GUARD_PASS,
    )
    assert out["wrote"] is True
    handoff_path = Path(out["handoff_file"])
    assert handoff_path.is_file()
    assert HANDOFF_DIR_REL.replace("/", "\\") in str(handoff_path) \
        or HANDOFF_DIR_REL in str(handoff_path).replace("\\", "/")

    # Round-trip: file contents match returned entry.
    on_disk = json.loads(handoff_path.read_text(encoding="utf-8"))
    assert on_disk == out["entry"]

    # read_handoff finds it by session_id.
    fetched = read_handoff(
        project_root=tmp_path,
        session_id=out["entry"]["session_id"],
    )
    assert fetched == out["entry"]


def test_read_handoff_missing_returns_none(tmp_path: Path) -> None:
    assert read_handoff(project_root=tmp_path, session_id="HOFF-nope") is None


def test_list_handoffs_empty_dir(tmp_path: Path) -> None:
    out = list_handoffs(project_root=tmp_path)
    assert out["total_count"] == 0
    assert out["entries"] == []
    assert out["skipped"] == []


def test_list_handoffs_newest_first(tmp_path: Path) -> None:
    import time
    write_handoff(project_root=tmp_path, agent_name="first",
                   session_id="HOFF-001")
    time.sleep(0.01)
    write_handoff(project_root=tmp_path, agent_name="second",
                   session_id="HOFF-002")
    out = list_handoffs(project_root=tmp_path)
    assert out["total_count"] == 2
    assert out["entries"][0]["session_id"] == "HOFF-002"
    assert out["entries"][1]["session_id"] == "HOFF-001"


def test_list_handoffs_skips_malformed(tmp_path: Path) -> None:
    handoff_dir = tmp_path / HANDOFF_DIR_REL
    handoff_dir.mkdir(parents=True)
    (handoff_dir / "good.json").write_text(
        json.dumps({"session_id": "HOFF-good", "schema_version": SCHEMA_VERSION_HANDOFF_V1}),
        encoding="utf-8",
    )
    (handoff_dir / "bad.json").write_text("{not json", encoding="utf-8")
    out = list_handoffs(project_root=tmp_path)
    assert out["total_count"] == 1
    assert len(out["skipped"]) == 1
    assert "bad.json" in out["skipped"][0]


def test_list_handoffs_limit(tmp_path: Path) -> None:
    for i in range(5):
        write_handoff(project_root=tmp_path, session_id=f"HOFF-{i:03d}")
    out = list_handoffs(project_root=tmp_path, limit=3)
    assert out["total_count"] == 5
    assert len(out["entries"]) == 3


def test_quarantine_status_round_trips(tmp_path: Path) -> None:
    out = write_handoff(
        project_root=tmp_path,
        axiom_guard_status=AXIOM_GUARD_QUARANTINE,
        warnings=["regression in test_foo"],
    )
    assert out["entry"]["axiom_guard_status"] == AXIOM_GUARD_QUARANTINE
    assert out["entry"]["warnings"] == ["regression in test_foo"]


def _decode_mcp_result(response: dict) -> dict:
    """The MCP dispatcher wraps tool output as content[0].text JSON."""
    result = response["result"]
    if "structuredContent" in result and result["structuredContent"]:
        return result["structuredContent"]
    text = result["content"][0]["text"]
    return json.loads(text)


def test_mcp_handoff_create_dispatches_through_a1(tmp_path: Path) -> None:
    """Importing the a3 mcp_server wires the dispatcher; the a1 stub
    must be replaced by the real handler."""
    import atomadic_forge.a3_og_features.mcp_server  # noqa: F401  — wiring import
    from atomadic_forge.a1_at_functions.mcp_protocol import dispatch_request

    response = dispatch_request(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": "hive",
                "arguments": {
                    "action": "handoff_create",
                    "agent_name": "claude",
                    "work_completed": ["wrote handoff"],
                    "pending_tasks": ["push"],
                    "axiom_guard_status": "PASS",
                    "project_root": str(tmp_path),
                },
            },
        },
        project_root=tmp_path,
    )
    assert response is not None
    assert "error" not in response, response
    body = _decode_mcp_result(response)
    assert body.get("wrote") is True, body
    assert body["entry"]["agent_name"] == "claude"


def test_mcp_handoff_list_dispatches(tmp_path: Path) -> None:
    import atomadic_forge.a3_og_features.mcp_server  # noqa: F401
    from atomadic_forge.a1_at_functions.mcp_protocol import dispatch_request

    write_handoff(project_root=tmp_path, session_id="HOFF-listcheck")

    response = dispatch_request(
        {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {
                "name": "hive",
                "arguments": {"action": "handoff_list", "project_root": str(tmp_path), "limit": 5},
            },
        },
        project_root=tmp_path,
    )
    assert response is not None
    assert "error" not in response, response
    body = _decode_mcp_result(response)
    assert body["total_count"] == 1
    assert body["entries"][0]["session_id"] == "HOFF-listcheck"


def test_mcp_tools_list_includes_handoff() -> None:
    import atomadic_forge.a3_og_features.mcp_server  # noqa: F401
    from atomadic_forge.a1_at_functions.mcp_protocol import dispatch_request

    response = dispatch_request(
        {"jsonrpc": "2.0", "id": 3, "method": "tools/list"},
        project_root=Path("."),
    )
    assert response is not None
    names = {t["name"] for t in response["result"]["tools"]}
    assert "hive" in names
