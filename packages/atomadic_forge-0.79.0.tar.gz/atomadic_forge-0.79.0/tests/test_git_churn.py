"""Unit tests for a1 git_churn — file-level commit frequency analysis."""
from atomadic_forge.a1_at_functions.git_churn import (
    SCHEMA_VERSION_GIT_CHURN_V1,
    compute_git_churn,
)


def test_compute_git_churn_no_git_returns_unavailable(tmp_path):
    result = compute_git_churn(tmp_path)
    assert result["schema_version"] == SCHEMA_VERSION_GIT_CHURN_V1
    assert result["available"] is False
    assert "reason" in result


def test_compute_git_churn_fields_when_available(tmp_path, monkeypatch):
    """Patch subprocess so we can exercise the parser without a real repo."""
    from atomadic_forge.a1_at_functions import git_churn as _mod

    fake_log = (
        "\n"
        "src/foo.py\n"
        "src/bar.py\n"
        "\n"
        "src/foo.py\n"
        "\n"
        "src/baz.py\n"
    )
    fake_total = "3\n"
    fake_first = "2024-01-01 00:00:00 +0000\n"
    fake_last = "2024-06-01 00:00:00 +0000"

    call_count = [0]

    def fake_run(args, cwd):
        call_count[0] += 1
        if args[:2] == ["log", "--name-only"]:
            return fake_log
        if args[:2] == ["rev-list", "--count"]:
            return fake_total
        if args[1] == "--reverse":
            return fake_first
        if args[1] == "-1":
            return fake_last
        return None

    monkeypatch.setattr(_mod, "_run_git", fake_run)
    (tmp_path / ".git").mkdir()

    result = compute_git_churn(tmp_path, src_only=True)
    assert result["available"] is True
    assert result["total_commits"] == 3
    assert result["files_tracked"] >= 1
    assert isinstance(result["hotspot_files"], list)
    assert isinstance(result["stable_files"], list)
    assert isinstance(result["avg_commits_per_file"], float)
    assert isinstance(result["median_commits_per_file"], int)
    assert result["first_commit_date"] == "2024-01-01"
    assert result["last_commit_date"] == "2024-06-01"
    # foo.py has 2 commits, baz.py has 1 — both under src/
    paths = {h["path"] for h in result["hotspot_files"]}
    assert "src/foo.py" in paths


def test_compute_git_churn_src_only_filters(tmp_path, monkeypatch):
    from atomadic_forge.a1_at_functions import git_churn as _mod

    fake_log = "\nsrc/core.py\nsetup.py\n"

    monkeypatch.setattr(_mod, "_run_git", lambda args, cwd: (
        fake_log if args[:2] == ["log", "--name-only"] else
        "1\n" if args[:2] == ["rev-list", "--count"] else
        "2024-01-01 00:00:00 +0000\n"
    ))
    (tmp_path / ".git").mkdir()

    result = compute_git_churn(tmp_path, src_only=True)
    paths = {h["path"] for h in result["hotspot_files"]}
    assert "setup.py" not in paths

    result_all = compute_git_churn(tmp_path, src_only=False)
    paths_all = {h["path"] for h in result_all["hotspot_files"]}
    assert "setup.py" in paths_all
