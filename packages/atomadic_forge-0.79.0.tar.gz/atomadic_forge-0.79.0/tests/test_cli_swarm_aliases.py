"""Regression: every multi-word top-level verb must be reachable in its
hyphenated form.  ``commandsmith discover`` normalizes module names to
hyphens, so ``commandsmith smoke`` was calling ``forge recon-swarm --help``
against a CLI that only registered ``forge recon_swarm`` — three verbs
failed their own smoke.  Both forms are now registered as aliases.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]


def _help_ok(verb: str) -> bool:
    import os
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    out = subprocess.run(
        [sys.executable, "-m", "atomadic_forge", verb, "--help"],
        cwd=REPO_ROOT, capture_output=True, text=True, timeout=30,
        env=env, encoding="utf-8", errors="replace",
    )
    return out.returncode == 0


def test_recon_swarm_both_forms():
    assert _help_ok("recon-swarm")
    assert _help_ok("recon_swarm")


def test_emergent_swarm_both_forms():
    assert _help_ok("emergent-swarm")
    assert _help_ok("emergent_swarm")


def test_guard_install_both_forms():
    assert _help_ok("guard-install")
    assert _help_ok("guard_install")
