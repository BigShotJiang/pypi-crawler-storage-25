"""Tier verification — generic repo public surface sync.

Golden Path Lane C W6 follow-on tests. Product teams can run
``forge metrics repo`` against their own repo to update repo-local
metrics and public copy without mutating Forge's ``forge_metrics.json``.
"""
from __future__ import annotations

import json

from typer.testing import CliRunner

from atomadic_forge.a1_at_functions.repo_public_surface import (
    compute_repo_public_metrics_from_records,
    infer_project_identity_from_metadata,
    render_readme_with_metrics,
    render_text_with_metric_markers,
)
from atomadic_forge.a2_mo_composites.repo_public_surface_sync import (
    compute_repo_public_metrics,
    plan_repo_public_surface_sync,
)
from atomadic_forge.commands.metrics import app


def _product_repo(tmp_path):
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "toast-product"\nversion = "1.2.3"\n',
        encoding="utf-8",
    )
    (tmp_path / "README.md").write_text("# Toast Product\n", encoding="utf-8")
    (tmp_path / "server.json").write_text(
        json.dumps({
            "name": "io.github.example/toast-product",
            "version": "0.0.1",
            "description": "old",
            "packages": [{"identifier": "toast-product", "version": "0.0.1"}],
        }),
        encoding="utf-8",
    )
    src = tmp_path / "src" / "toast_product"
    src.mkdir(parents=True)
    (src / "__init__.py").write_text("", encoding="utf-8")
    (src / "core.py").write_text("def toast(x):\n    return x\n", encoding="utf-8")
    tests = tmp_path / "tests"
    tests.mkdir()
    (tests / "test_core.py").write_text("def test_toast():\n    assert True\n", encoding="utf-8")


def test_compute_repo_public_metrics_for_product_repo(tmp_path):
    _product_repo(tmp_path)

    metrics = compute_repo_public_metrics(tmp_path)

    assert metrics["schema_version"] == "atomadic-forge.repo_metrics/v1"
    assert metrics["project"] == "toast-product"
    assert metrics["version"] == "1.2.3"
    assert metrics["source_file_count"] == 3
    assert metrics["test_file_count"] == 1
    assert metrics["languages"] == ["Python"]


def test_pure_metrics_compute_from_loaded_records():
    identity = infer_project_identity_from_metadata(
        "fallback",
        pyproject_text='[project]\nname = "loaded"\nversion = "4.5.6"\n',
    )
    metrics = compute_repo_public_metrics_from_records(
        identity,
        [
            {"path": "src/app/core.py", "suffix": ".py", "text": "x = 1\n"},
            {"path": "node_modules/pkg/index.js", "suffix": ".js", "text": "x"},
            {"path": "tests/test_core.py", "suffix": ".py", "text": "def test_x():\n    pass\n"},
        ],
    )

    assert metrics["project"] == "loaded"
    assert metrics["version"] == "4.5.6"
    assert metrics["source_file_count"] == 2
    assert metrics["test_file_count"] == 1


def test_plan_public_surface_updates_readme_and_server(tmp_path):
    _product_repo(tmp_path)

    plan = plan_repo_public_surface_sync(tmp_path)

    paths = {w["path"] for w in plan["writes"]}
    assert paths == {"repo_metrics.json", "README.md", "server.json"}
    server = next(w for w in plan["writes"] if w["path"] == "server.json")
    server_data = json.loads(server["content"])
    assert server_data["version"] == "1.2.3"
    assert server_data["packages"][0]["version"] == "1.2.3"
    assert "3 source files" in server_data["description"]


def test_readme_metrics_block_is_bounded_and_idempotent():
    metrics = {
        "version": "1.0.0",
        "source_file_count": 2,
        "source_line_count": 10,
        "test_file_count": 1,
        "languages": ["Python"],
    }

    once = render_readme_with_metrics("# App\n", metrics)
    twice = render_readme_with_metrics(once, {**metrics, "source_file_count": 3})

    assert once.count("<!-- forge:metrics:start -->") == 1
    assert twice.count("<!-- forge:metrics:start -->") == 1
    assert "**3**" in twice


def test_readme_existing_by_the_numbers_section_is_replaced():
    metrics = {
        "version": "2.0.0",
        "source_file_count": 8,
        "source_line_count": 80,
        "test_file_count": 2,
        "languages": ["Python"],
    }
    readme = "# App\n\n## By the Numbers\n\nold copy\n\n---\n\n## Install\n"

    out = render_readme_with_metrics(readme, metrics)

    assert "old copy" not in out
    assert "## Install" in out
    assert "<!-- forge:metrics:start -->" in out


def test_inline_metric_markers_update_any_text():
    text = (
        "Files: <!-- forge:metric key=source_file_count format=comma -->0"
        "<!-- /forge:metric -->; "
        "Langs: <!-- forge:metric languages -->none<!-- /forge:metric -->"
    )

    out = render_text_with_metric_markers(
        text,
        {"source_file_count": 1234, "languages": ["Python", "Go"]},
    )

    assert "1,234" in out
    assert "Python, Go" in out


def test_inline_metric_markers_ignore_fenced_examples():
    text = (
        "Live: <!-- forge:metric source_file_count -->0<!-- /forge:metric -->\n"
        "```md\n"
        "Example: <!-- forge:metric source_file_count -->0<!-- /forge:metric -->\n"
        "```\n"
    )

    out = render_text_with_metric_markers(text, {"source_file_count": 9})

    assert "Live: <!-- forge:metric source_file_count -->9<!-- /forge:metric -->" in out
    assert "Example: <!-- forge:metric source_file_count -->0<!-- /forge:metric -->" in out


def test_configured_plan_updates_marked_docs_and_public_artifact(tmp_path):
    _product_repo(tmp_path)
    config_dir = tmp_path / ".atomadic-forge"
    config_dir.mkdir()
    (config_dir / "repo-metrics.config.json").write_text(
        json.dumps({
            "artifact_path": "public/metrics.json",
            "document_globs": ["website/**/*.md"],
            "readme_block": False,
            "sync_server_json": False,
            "extra_metrics": {"customer_count": 42},
            "aliases": {"customers": "customer_count"},
        }),
        encoding="utf-8",
    )
    website = tmp_path / "website"
    website.mkdir()
    (website / "index.md").write_text(
        "Customers: <!-- forge:metric customers -->0<!-- /forge:metric -->\n",
        encoding="utf-8",
    )

    plan = plan_repo_public_surface_sync(tmp_path)

    paths = {w["path"] for w in plan["writes"]}
    assert "public/metrics.json" in paths
    assert "website/index.md" in paths
    assert "server.json" not in paths
    site = next(w for w in plan["writes"] if w["path"] == "website/index.md")
    assert "Customers: <!-- forge:metric customers -->42<!-- /forge:metric -->" in site["content"]
    artifact = next(w for w in plan["writes"] if w["path"] == "public/metrics.json")
    assert json.loads(artifact["content"])["customer_count"] == 42


def test_metrics_repo_command_dry_run_does_not_touch_forge_metrics(tmp_path):
    _product_repo(tmp_path)
    forge_metrics = tmp_path / "forge_metrics.json"
    forge_metrics.write_text('{"do_not_touch": true}\n', encoding="utf-8")

    result = CliRunner().invoke(app, ["repo", "--project", str(tmp_path)])

    assert result.exit_code == 0
    assert "would write repo_metrics.json" in result.stdout
    assert json.loads(forge_metrics.read_text()) == {"do_not_touch": True}
    assert not (tmp_path / "repo_metrics.json").exists()


def test_metrics_repo_command_apply_writes_product_surface(tmp_path):
    _product_repo(tmp_path)

    result = CliRunner().invoke(app, ["repo", "--project", str(tmp_path), "--apply"])

    assert result.exit_code == 0
    assert (tmp_path / "repo_metrics.json").exists()
    assert "<!-- forge:metrics:start -->" in (tmp_path / "README.md").read_text()


def test_metrics_repo_init_config_command(tmp_path):
    result = CliRunner().invoke(app, ["repo", "--project", str(tmp_path), "--init-config", "--apply"])

    assert result.exit_code == 0
    assert (tmp_path / ".atomadic-forge" / "repo-metrics.config.json").exists()
