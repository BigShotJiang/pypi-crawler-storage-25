"""Tests for the v0.13.2 hive sync pipeline.

Agent registry + consensus + observe primitives. Pin five properties:

1. Round-trip: register → list → deactivate → list (excludes deactivated).
2. D_max enforcement: refuses past 23 agents.
3. Default subscriptions: per-canonical-role defaults applied when
   subscribes_to is omitted.
4. Consensus tally: latest vote per voter wins; quorum + verdict
   computed deterministically.
5. Empty-state safety: query/observe on a fresh repo returns empty,
   never errors.
"""
from __future__ import annotations

import datetime as _dt
from pathlib import Path

import pytest

from atomadic_forge.a0_qk_constants.hive_constants import (
    D_MAX_AGENTS,
    EVENT_COMMIT_TO_MAIN,
    EVENT_NEW_WISDOM,
    ROLE_COGNITION,
    ROLE_DOC,
    ROLE_FORGE,
    ROLE_RESEARCH,
)
from atomadic_forge.a1_at_functions.hive_consensus_math import (
    resolve_consensus,
    tally_votes,
)
from atomadic_forge.a3_og_features.hive_sync import (
    deactivate_agent,
    get_consensus_result,
    list_agents,
    observe,
    propose_consensus,
    register_agent,
    vote_consensus,
)


def _now_utc_iso() -> str:
    """Current UTC timestamp in the schema's RFC3339-Z form.

    Consensus tests pin the proposal timestamp to "now" so the 1-hour
    consensus timeout doesn't drift the verdict from PENDING -> TIMEOUT
    when CI runs hours after midnight. Pre-existing tests had a
    hardcoded ``2026-05-06T12:00:00Z`` that became time-bombs once
    real-time crossed 13:00 UTC on that day.
    """
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ── round-trip ──────────────────────────────────────────────────────

def test_register_then_list_roundtrip(tmp_path: Path):
    out = register_agent(
        project_root=tmp_path,
        agent_name="alpha", role=ROLE_FORGE,
        capabilities=["edit_files"],
    )
    assert out["registered"] is True
    listed = list_agents(project_root=tmp_path)
    assert listed["agent_count"] == 1
    assert listed["agents"][0]["agent_name"] == "alpha"


def test_deactivate_drops_from_active_list(tmp_path: Path):
    register_agent(project_root=tmp_path, agent_name="alpha", role=ROLE_FORGE)
    register_agent(project_root=tmp_path, agent_name="beta", role=ROLE_DOC)
    assert list_agents(project_root=tmp_path)["agent_count"] == 2

    out = deactivate_agent(project_root=tmp_path, agent_name="alpha")
    assert out["deactivated"] is True

    active = list_agents(project_root=tmp_path)
    assert active["agent_count"] == 1
    assert active["agents"][0]["agent_name"] == "beta"

    full = list_agents(project_root=tmp_path, include_deactivated=True)
    # include_deactivated returns the raw log: alpha-active, beta,
    # alpha-deact = 3 entries.
    assert full["agent_count"] == 3
    # Direct load_agents must agree.
    from atomadic_forge.a1_at_functions.hive_io import load_agents
    assert len(load_agents(tmp_path)) == 3


def test_deactivate_unknown_returns_clean_no(tmp_path: Path):
    out = deactivate_agent(project_root=tmp_path, agent_name="ghost")
    assert out["deactivated"] is False
    assert "no active agent" in out["reason"]


# ── D_max enforcement ──────────────────────────────────────────────

def test_register_refuses_past_d_max(tmp_path: Path):
    for i in range(D_MAX_AGENTS):
        register_agent(project_root=tmp_path, agent_name=f"a{i}", role="forge")
    with pytest.raises(ValueError, match="D_max"):
        register_agent(project_root=tmp_path,
                        agent_name="overflow", role="forge")


# ── default subscriptions ───────────────────────────────────────────

def test_default_subscriptions_per_canonical_role(tmp_path: Path):
    out = register_agent(project_root=tmp_path, agent_name="f", role=ROLE_FORGE)
    subs = set(out["entry"]["subscribes_to"])
    assert EVENT_NEW_WISDOM in subs
    # Forge is wired to verify.fail by default.
    assert any("verify" in s for s in subs)


def test_explicit_subscriptions_override_default(tmp_path: Path):
    out = register_agent(
        project_root=tmp_path, agent_name="custom", role=ROLE_RESEARCH,
        subscribes_to=[EVENT_COMMIT_TO_MAIN],
    )
    assert out["entry"]["subscribes_to"] == [EVENT_COMMIT_TO_MAIN]


# ── consensus math ──────────────────────────────────────────────────

def test_tally_votes_latest_per_voter_wins():
    events = [
        {"kind": "vote", "voter": "a", "vote": "approve"},
        {"kind": "vote", "voter": "a", "vote": "reject"},     # latest
        {"kind": "vote", "voter": "b", "vote": "approve"},
        {"kind": "vote", "voter": "c", "vote": "refine"},
        {"kind": "proposal", "intent": "x"},                   # ignored
    ]
    out = tally_votes(events)
    assert out["counts"] == {"approve": 1, "reject": 1, "refine": 1, "abstain": 0}
    assert out["vote_count"] == 3


def test_resolve_consensus_pass_with_majority_approves():
    proposal = {"timestamp_utc": _now_utc_iso()}
    events = [proposal,
              {"kind": "vote", "voter": "a", "vote": "approve"},
              {"kind": "vote", "voter": "b", "vote": "approve"},
              {"kind": "vote", "voter": "c", "vote": "reject"}]
    res = resolve_consensus(
        proposal=proposal, events=events,
        active_agent_count=4, quorum_min=2,
    )
    assert res["verdict"] == "PASS"
    assert res["resolved"] is True


def test_resolve_consensus_pending_below_quorum():
    proposal = {"timestamp_utc": _now_utc_iso()}
    events = [proposal,
              {"kind": "vote", "voter": "a", "vote": "approve"}]
    res = resolve_consensus(
        proposal=proposal, events=events,
        active_agent_count=4, quorum_min=2,
    )
    assert res["verdict"] == "PENDING"
    assert res["resolved"] is False


def test_resolve_consensus_refine_when_refines_dominate():
    proposal = {"timestamp_utc": _now_utc_iso()}
    events = [proposal,
              {"kind": "vote", "voter": "a", "vote": "refine"},
              {"kind": "vote", "voter": "b", "vote": "refine"},
              {"kind": "vote", "voter": "c", "vote": "approve"}]
    res = resolve_consensus(
        proposal=proposal, events=events,
        active_agent_count=4, quorum_min=2,
    )
    assert res["verdict"] == "REFINE"


# ── consensus orchestrator round-trip ───────────────────────────────

def test_propose_then_vote_then_result(tmp_path: Path):
    register_agent(project_root=tmp_path, agent_name="alpha", role=ROLE_FORGE)
    register_agent(project_root=tmp_path, agent_name="beta", role=ROLE_COGNITION)

    p = propose_consensus(
        project_root=tmp_path,
        intent="ship v0.13.2", proposer="alpha",
    )
    cid = p["consensus_id"]
    assert cid.startswith("CNS-")

    vote_consensus(project_root=tmp_path, consensus_id=cid,
                    voter="alpha", vote="approve")
    vote_consensus(project_root=tmp_path, consensus_id=cid,
                    voter="beta", vote="approve")

    res = get_consensus_result(project_root=tmp_path, consensus_id=cid)
    assert res["found"] is True
    assert res["verdict"] == "PASS"
    assert res["intent"] == "ship v0.13.2"


def test_record_resolution_freezes_verdict(tmp_path: Path):
    register_agent(project_root=tmp_path, agent_name="alpha", role=ROLE_FORGE)
    register_agent(project_root=tmp_path, agent_name="beta", role=ROLE_DOC)
    cid = propose_consensus(project_root=tmp_path,
                             intent="x", proposer="alpha")["consensus_id"]
    vote_consensus(project_root=tmp_path, consensus_id=cid,
                    voter="alpha", vote="approve")
    vote_consensus(project_root=tmp_path, consensus_id=cid,
                    voter="beta", vote="approve")
    res1 = get_consensus_result(project_root=tmp_path, consensus_id=cid,
                                  record_resolution=True)
    assert res1["verdict"] == "PASS"
    # Subsequent reads return the recorded resolution unchanged.
    res2 = get_consensus_result(project_root=tmp_path, consensus_id=cid)
    assert res2["verdict"] == "PASS"


# ── empty-state safety ──────────────────────────────────────────────

def test_observe_on_empty_repo_safe(tmp_path: Path):
    out = observe(project_root=tmp_path, agent_name="ghost")
    assert out["event_count"] == 0
    assert out["events"] == []
    assert out["active_agent_count"] == 0


def test_get_consensus_result_unknown_id(tmp_path: Path):
    out = get_consensus_result(project_root=tmp_path,
                                 consensus_id="CNS-nonexistent")
    assert out["found"] is False


def test_vote_invalid_value_rejected(tmp_path: Path):
    register_agent(project_root=tmp_path, agent_name="a", role=ROLE_FORGE)
    cid = propose_consensus(project_root=tmp_path,
                              intent="x", proposer="a")["consensus_id"]
    with pytest.raises(ValueError):
        vote_consensus(project_root=tmp_path, consensus_id=cid,
                        voter="a", vote="maybe")
