"""Polyglot expansion 2026-05-05: Swift / Kotlin / Go / .mts harvest.

These tests pin the contract Forge needs to ingest OpenClaw end-to-end.
Each test scaffolds a tiny synthetic repo containing files in the new
languages and asserts harvest_repo counts them, surfaces them in
``symbols``, and lifts the right ``primary_language`` when a non-Python
language dominates.
"""

from pathlib import Path

import pytest

from atomadic_forge.a0_qk_constants.lang_extensions import (
    GO_EXTS,
    KOTLIN_EXTS,
    LANG_OF_EXT,
    SWIFT_EXTS,
    TYPESCRIPT_EXTS,
    file_class_for_path,
    lang_for_path,
)
from atomadic_forge.a1_at_functions.scout_walk import harvest_repo

# ---------------------------------------------------------------------------
# a0 lang_extensions — pure constant + lookup contracts
# ---------------------------------------------------------------------------


def test_swift_kotlin_go_frozensets_contain_canonical_extensions():
    assert ".swift" in SWIFT_EXTS
    assert ".kt" in KOTLIN_EXTS
    assert ".kts" in KOTLIN_EXTS
    assert ".go" in GO_EXTS


def test_typescript_exts_now_includes_mts_and_cts():
    assert ".mts" in TYPESCRIPT_EXTS
    assert ".cts" in TYPESCRIPT_EXTS
    # legacy still present
    assert ".ts" in TYPESCRIPT_EXTS
    assert ".tsx" in TYPESCRIPT_EXTS


def test_lang_of_ext_maps_each_new_language():
    assert LANG_OF_EXT[".swift"] == "swift"
    assert LANG_OF_EXT[".kt"] == "kotlin"
    assert LANG_OF_EXT[".kts"] == "kotlin"
    assert LANG_OF_EXT[".go"] == "go"
    assert LANG_OF_EXT[".mts"] == "typescript"
    assert LANG_OF_EXT[".cts"] == "typescript"


@pytest.mark.parametrize(
    "path,expected",
    [
        ("apps/macos/Foo.swift", "swift"),
        ("android/Bar.kt", "kotlin"),
        ("android/build.gradle.kts", "kotlin"),
        ("bridges/go/main.go", "go"),
        ("bridges/typescript/index.mts", "typescript"),
        ("README.md", None),
        ("data.json", None),
    ],
)
def test_lang_for_path_returns_canonical_label(path, expected):
    assert lang_for_path(path) == expected


def test_file_class_classifies_new_languages_as_source():
    assert file_class_for_path("apps/macos/Foo.swift") == "source"
    assert file_class_for_path("android/Bar.kt") == "source"
    assert file_class_for_path("bridges/go/main.go") == "source"


# ---------------------------------------------------------------------------
# a1 harvest_repo — file-level polyglot harvest
# ---------------------------------------------------------------------------


def _scaffold_polyglot_repo(root: Path) -> None:
    """Lay down a tiny multi-language repo (Swift + Kotlin + Go + TS).

    Files are placed under aN_* directories in some cases to exercise
    the path-based tier guess.
    """
    # Swift — under an "apps/macos" path so tier guess falls back to a3.
    (root / "apps" / "macos").mkdir(parents=True)
    (root / "apps" / "macos" / "AppDelegate.swift").write_text(
        "import SwiftUI\n@main struct App {}\n", encoding="utf-8",
    )
    (root / "apps" / "macos" / "ViewModel.swift").write_text(
        "class ViewModel {}\n", encoding="utf-8",
    )

    # Kotlin — under android/ with both .kt and .kts
    (root / "android").mkdir(parents=True)
    (root / "android" / "MainActivity.kt").write_text(
        "package com.example\nclass MainActivity {}\n", encoding="utf-8",
    )
    (root / "android" / "build.gradle.kts").write_text(
        "plugins { kotlin(\"jvm\") }\n", encoding="utf-8",
    )

    # Go — under a bridges/ path
    (root / "bridges" / "go").mkdir(parents=True)
    (root / "bridges" / "go" / "main.go").write_text(
        "package main\nfunc main() {}\n", encoding="utf-8",
    )

    # TypeScript .mts — modern ES module variant
    (root / "bridges" / "typescript").mkdir(parents=True)
    (root / "bridges" / "typescript" / "index.mts").write_text(
        "export const hello = 'world';\n", encoding="utf-8",
    )

    # A Python file under an a1_ tier directory so tier_distribution has
    # at least one canonical entry to pin.
    (root / "src" / "pkg" / "a1_at_functions").mkdir(parents=True)
    (root / "src" / "pkg" / "a1_at_functions" / "__init__.py").write_text("", encoding="utf-8")
    (root / "src" / "pkg" / "a1_at_functions" / "helpers.py").write_text(
        "def hello() -> str:\n    return 'hi'\n", encoding="utf-8",
    )


def test_harvest_repo_counts_swift_kotlin_go_files(tmp_path):
    _scaffold_polyglot_repo(tmp_path)
    report = harvest_repo(tmp_path)
    assert report["swift_file_count"] == 2
    assert report["kotlin_file_count"] == 2
    assert report["go_file_count"] == 1
    # .mts is rolled into typescript bucket
    assert report["typescript_file_count"] == 1
    assert report["python_file_count"] >= 1


def test_harvest_repo_language_distribution_includes_new_languages(tmp_path):
    _scaffold_polyglot_repo(tmp_path)
    report = harvest_repo(tmp_path)
    dist = report["language_distribution"]
    assert dist["swift"] == 2
    assert dist["kotlin"] == 2
    assert dist["go"] == 1
    assert dist["typescript"] == 1
    assert dist["python"] >= 1


def test_harvest_repo_primary_language_is_swift_when_swift_dominates(tmp_path):
    # Stack the deck heavily Swift to verify the primary picker doesn't
    # silently default to python.
    (tmp_path / "ios").mkdir()
    for i in range(5):
        (tmp_path / "ios" / f"M{i}.swift").write_text("class A{}\n", encoding="utf-8")
    (tmp_path / "tiny.py").write_text("x = 1\n", encoding="utf-8")
    report = harvest_repo(tmp_path)
    assert report["primary_language"] == "swift"


def test_harvest_repo_surfaces_swift_files_as_symbols(tmp_path):
    """Post-2026-05-06: Swift files emit one ``module`` record PLUS per-symbol
    records (functions / classes / methods).  Two files → at least two
    ``module`` records; richer surface adds further per-symbol entries."""
    _scaffold_polyglot_repo(tmp_path)
    report = harvest_repo(tmp_path)
    swift_symbols = [s for s in report["symbols"] if s.get("language") == "swift"]
    module_records = [s for s in swift_symbols if s["kind"] == "module"]
    assert len(module_records) == 2
    for s in module_records:
        assert s["file"].endswith(".swift")
        assert s["tier_guess"].startswith("a")
    # ViewModel.swift contains ``class ViewModel`` so a class record exists.
    class_records = [s for s in swift_symbols if s["kind"] == "class"]
    assert any(s["name"] == "ViewModel" for s in class_records)


def test_harvest_repo_kotlin_kts_treated_as_kotlin(tmp_path):
    """Both ``.kt`` and ``.kts`` files are harvested as Kotlin.  Multiple
    records per file are expected post-2026-05-06 (module + per-symbol),
    so we assert the *set* of files covered, not record count."""
    _scaffold_polyglot_repo(tmp_path)
    report = harvest_repo(tmp_path)
    kotlin_symbols = [s for s in report["symbols"] if s.get("language") == "kotlin"]
    files = {s["file"] for s in kotlin_symbols}
    assert files == {"android/MainActivity.kt", "android/build.gradle.kts"}


def test_harvest_repo_path_tier_guess_uses_canonical_directories(tmp_path):
    """Files under aN_* dirs inherit that tier on every emitted record
    (module + per-symbol).  Path-based placement always wins over
    content-based tier guessing."""
    (tmp_path / "src" / "pkg" / "a2_mo_composites").mkdir(parents=True)
    (tmp_path / "src" / "pkg" / "a2_mo_composites" / "Service.swift").write_text(
        "class Service {}\n", encoding="utf-8",
    )
    report = harvest_repo(tmp_path)
    swift = [s for s in report["symbols"] if s.get("language") == "swift"]
    assert len(swift) >= 1
    for record in swift:
        assert record["tier_guess"] == "a2_mo_composites"


def test_harvest_repo_omits_node_modules_for_new_languages(tmp_path):
    # node_modules with stray Swift / Go files should NOT be harvested.
    (tmp_path / "node_modules" / "junk").mkdir(parents=True)
    (tmp_path / "node_modules" / "junk" / "vendor.swift").write_text("", encoding="utf-8")
    (tmp_path / "node_modules" / "junk" / "vendor.go").write_text("package x\n", encoding="utf-8")
    (tmp_path / "real.swift").write_text("class A{}\n", encoding="utf-8")
    report = harvest_repo(tmp_path)
    assert report["swift_file_count"] == 1
    assert report["go_file_count"] == 0
