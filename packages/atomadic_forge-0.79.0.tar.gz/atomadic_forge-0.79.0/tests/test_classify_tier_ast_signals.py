"""AST-aware classifier signals — frozen dataclass / Protocol / all-static / cached_property.

Covers the v0.14.0a9 enhancement that lets the body extractor's richer
signal dict drive tier decisions BEFORE the name-based heuristics fire.
"""
from __future__ import annotations

import ast
import textwrap

from atomadic_forge.a1_at_functions.body_extractor import detect_class_signals
from atomadic_forge.a1_at_functions.classify_tier import (
    classify_tier,
    classify_tier_with_confidence,
)


def _class_node(src: str) -> ast.ClassDef:
    tree = ast.parse(textwrap.dedent(src))
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            return node
    raise AssertionError("source contained no ClassDef")


# ---------- detect_class_signals ----------------------------------------


def test_detect_signals_protocol_class() -> None:
    node = _class_node(
        """
        from typing import Protocol
        class Pingable(Protocol):
            def ping(self) -> bool: ...
        """
    )
    sig = detect_class_signals(node)
    assert sig["is_protocol"] is True
    assert sig["has_self_assign"] is False


def test_detect_signals_protocol_dotted() -> None:
    node = _class_node(
        """
        import typing
        class T(typing.Protocol):
            def f(self) -> int: ...
        """
    )
    assert detect_class_signals(node)["is_protocol"] is True


def test_detect_signals_frozen_dataclass() -> None:
    node = _class_node(
        """
        from dataclasses import dataclass
        @dataclass(frozen=True)
        class Point:
            x: int
            y: int
        """
    )
    sig = detect_class_signals(node)
    assert sig["is_frozen_dataclass"] is True
    assert sig["has_self_assign"] is False


def test_detect_signals_unfrozen_dataclass_not_marked_frozen() -> None:
    node = _class_node(
        """
        from dataclasses import dataclass
        @dataclass
        class Bag:
            items: list
        """
    )
    assert detect_class_signals(node)["is_frozen_dataclass"] is False


def test_detect_signals_all_static_methods() -> None:
    node = _class_node(
        """
        class StringUtils:
            @staticmethod
            def upper(s): return s.upper()
            @staticmethod
            def lower(s): return s.lower()
        """
    )
    sig = detect_class_signals(node)
    assert sig["all_static_methods"] is True


def test_detect_signals_mixed_static_and_instance_not_all_static() -> None:
    node = _class_node(
        """
        class Hybrid:
            @staticmethod
            def helper(): pass
            def method(self): pass
        """
    )
    assert detect_class_signals(node)["all_static_methods"] is False


def test_detect_signals_empty_class_not_all_static() -> None:
    node = _class_node("class Empty: pass\n")
    assert detect_class_signals(node)["all_static_methods"] is False


def test_detect_signals_cached_property() -> None:
    node = _class_node(
        """
        from functools import cached_property
        class Lazy:
            @cached_property
            def value(self): return expensive()
        """
    )
    assert detect_class_signals(node)["has_cached_property"] is True


def test_detect_signals_self_assign_still_works() -> None:
    node = _class_node(
        """
        class Bucket:
            def __init__(self):
                self.data = []
        """
    )
    sig = detect_class_signals(node)
    assert sig["has_self_assign"] is True
    assert sig["is_frozen_dataclass"] is False


# ---------- classify_tier overrides ------------------------------------


def test_protocol_class_lands_a0() -> None:
    sig = detect_class_signals(_class_node(
        "from typing import Protocol\nclass UserAPI(Protocol):\n  def f(self): ...\n"
    ))
    assert classify_tier(name="UserAPI", kind="class", path="api.py",
                          body_signals=sig) == "a0_qk_constants"


def test_frozen_dataclass_lands_a1() -> None:
    sig = detect_class_signals(_class_node(
        "from dataclasses import dataclass\n@dataclass(frozen=True)\n"
        "class UserBucket:\n  name: str\n"
    ))
    assert classify_tier(name="UserBucket", kind="class", path="store.py",
                          body_signals=sig) == "a1_at_functions"


def test_all_static_class_lands_a1() -> None:
    sig = detect_class_signals(_class_node(
        "class Helpers:\n  @staticmethod\n  def add(a,b): return a+b\n"
    ))
    assert classify_tier(name="Helpers", kind="class", path="util.py",
                          body_signals=sig) == "a1_at_functions"


def test_cached_property_lands_a2() -> None:
    sig = detect_class_signals(_class_node(
        "from functools import cached_property\n"
        "class LazyView:\n  @cached_property\n  def x(self): return 1\n"
    ))
    assert classify_tier(name="LazyView", kind="class", path="ui.py",
                          body_signals=sig) == "a2_mo_composites"


def test_existing_self_assign_still_promotes_to_a2() -> None:
    """Regression — the original promotion rule must still apply."""
    sig = detect_class_signals(_class_node(
        "class Cache:\n  def __init__(self): self.items = {}\n"
    ))
    assert classify_tier(name="Cache", kind="class", path="store.py",
                          body_signals=sig) == "a2_mo_composites"


# ---------- confidence-scored variant ----------------------------------


def test_confidence_protocol_high() -> None:
    sig = detect_class_signals(_class_node(
        "from typing import Protocol\nclass T(Protocol):\n  def f(self): ...\n"
    ))
    out = classify_tier_with_confidence(
        name="T", kind="class", path="x.py", body_signals=sig,
    )
    assert out["tier"] == "a0_qk_constants"
    assert out["confidence"] >= 0.9
    assert "is_protocol" in out["reasons"]


def test_confidence_function_default_is_lower_than_named_atom() -> None:
    bare = classify_tier_with_confidence(name="add", kind="function")
    named = classify_tier_with_confidence(name="parse_input", kind="function")
    assert bare["tier"] == "a1_at_functions"
    assert named["tier"] == "a1_at_functions"
    # The named hit should outscore the bare kind-only fallback.
    assert named["confidence"] > bare["confidence"]


def test_confidence_unknown_falls_through_with_low_score() -> None:
    out = classify_tier_with_confidence(name="qzx", kind="other")
    assert out["confidence"] <= 0.6
