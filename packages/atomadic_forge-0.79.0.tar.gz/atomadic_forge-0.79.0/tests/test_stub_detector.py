"""Tests for the stub-body detector + certify integration."""

from pathlib import Path

from atomadic_forge.a1_at_functions.certify_checks import certify
from atomadic_forge.a1_at_functions.stub_detector import (
    detect_stubs_in_file,
    stub_penalty,
)


def _write(p: Path, body: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(body, encoding="utf-8")


def test_detects_pass_only_function(tmp_path):
    _write(tmp_path / "f.py", "def foo():\n    pass\n")
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert any(f["kind"] == "pass_only" and f["qualname"] == "foo"
               for f in findings)


def test_detects_not_implemented(tmp_path):
    _write(tmp_path / "f.py",
           "def bar():\n    raise NotImplementedError()\n")
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert any(f["kind"] == "not_implemented" for f in findings)


def test_detects_todo_marker(tmp_path):
    _write(tmp_path / "f.py",
           'def baz(x):\n    # TODO: implement\n    return x\n')
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert any(f["kind"] == "todo_marker" for f in findings)


def test_detects_implement_me_comment(tmp_path):
    """Regression: codellama emitted `# Implement me!` literally."""
    _write(tmp_path / "f.py",
           "def slug():\n    # Implement me!\n    pass\n")
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    kinds = {f["kind"] for f in findings}
    assert kinds & {"pass_only", "todo_marker"}


def test_does_not_flag_real_function(tmp_path):
    _write(tmp_path / "f.py",
           '"""real."""\ndef add(a, b):\n    """sum."""\n    return a + b\n')
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert findings == []


def test_does_not_flag_todo_text_inside_docstrings(tmp_path):
    _write(
        tmp_path / "f.py",
        '"""Mention # TODO in docs without creating a stub finding."""\n'
        'def explain():\n'
        '    """No # Implement me! penalty for prompt prose."""\n'
        '    return "documented"\n',
    )
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert findings == []


def test_does_not_flag_abstractmethod(tmp_path):
    """@abstractmethod methods are contracts, not stubs (GAP-001)."""
    _write(
        tmp_path / "f.py",
        "from abc import ABC, abstractmethod\n"
        "class Base(ABC):\n"
        "    @abstractmethod\n"
        "    def run(self):\n"
        "        raise NotImplementedError()\n"
        "    @abstractmethod\n"
        "    def step(self):\n"
        "        pass\n",
    )
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert findings == []


def test_does_not_flag_abc_qualified_abstractmethod(tmp_path):
    """`@abc.abstractmethod` (attribute form) is also recognized."""
    _write(
        tmp_path / "f.py",
        "import abc\n"
        "class Base(abc.ABC):\n"
        "    @abc.abstractmethod\n"
        "    def go(self):\n"
        "        raise NotImplementedError\n",
    )
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert findings == []


def test_still_flags_undecorated_not_implemented(tmp_path):
    """A class named Base does NOT exempt undecorated stubs — author must opt in."""
    _write(
        tmp_path / "f.py",
        "class BaseThing:\n"
        "    def compress(self):\n"
        "        raise NotImplementedError\n",
    )
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert any(f["kind"] == "not_implemented" for f in findings)


def test_does_not_flag_private_class_methods(tmp_path):
    """Methods on a _PrivateClass are private API, not LLM stubs (GAP-005)."""
    _write(
        tmp_path / "f.py",
        "class _MockProvider:\n"
        "    def load(self, folder_path):\n"
        "        pass\n"
        "    def save(self):\n"
        "        raise NotImplementedError\n",
    )
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert findings == []


def test_still_flags_public_class_methods(tmp_path):
    """Public-class methods without @abstractmethod remain flagged."""
    _write(
        tmp_path / "f.py",
        "class PublicWidget:\n"
        "    def render(self):\n"
        "        pass\n",
    )
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert any(f["qualname"] == "PublicWidget.render" for f in findings)


def test_does_not_flag_private_pass(tmp_path):
    """A private `_helper` legitimately passing should not count."""
    _write(tmp_path / "f.py",
           "def _abstract():\n    pass\n")
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert findings == []


def test_stub_penalty_capped(tmp_path):
    findings = [{"file": f"file_{i}.py", "qualname": f"f_{i}",
                  "lineno": 1, "kind": "pass_only", "excerpt": ""}
                 for i in range(20)]
    assert stub_penalty(findings) == 40  # cap


def test_does_not_flag_visitor_pass_methods(tmp_path):
    """GAP-013: ast.NodeVisitor subclasses ``pass`` for node types they
    intentionally ignore. That's the pattern, not a stub."""
    _write(
        tmp_path / "f.py",
        "import ast\n"
        "class CallVisitor(ast.NodeVisitor):\n"
        "    def visit_Name(self, node):\n"
        "        pass\n"
        "    def visit_Constant(self, node):\n"
        "        pass\n"
        "    def visit_Call(self, node):\n"
        "        return self.calls.append(node)\n",
    )
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert findings == []


def test_visitor_only_skips_visit_prefix_methods(tmp_path):
    """A non-visit_* method on a Visitor class is still flagged."""
    _write(
        tmp_path / "f.py",
        "import ast\n"
        "class V(ast.NodeVisitor):\n"
        "    def helper(self):\n"
        "        pass\n",
    )
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert any(f["qualname"] == "V.helper" for f in findings)


def test_does_not_flag_null_handler(tmp_path):
    """GAP-009: stdlib pattern — NullHandler.handle/emit are intentional no-ops."""
    _write(
        tmp_path / "f.py",
        "class NullHandler:\n"
        "    def handle(self, record):\n"
        "        pass\n"
        "    def emit(self, record):\n"
        "        pass\n",
    )
    findings = detect_stubs_in_file(tmp_path / "f.py", repo_root=tmp_path)
    assert findings == []


def test_todo_markers_have_capped_penalty(tmp_path):
    """GAP-010: TODO markers are informational; cap their penalty at 5
    so a file riddled with comment notes doesn't dominate the gate."""
    findings = [
        {"file": f"f{i}.py", "qualname": f"<line {i}>",
         "lineno": i, "kind": "todo_marker", "excerpt": ""}
        for i in range(50)
    ]
    # 50 TODOs without any real-stub findings -> capped at 5 points.
    assert stub_penalty(findings) == 5


def test_real_stubs_combine_with_todo_cap(tmp_path):
    real = [{"file": "a.py", "qualname": "X.run", "lineno": 1,
              "kind": "pass_only", "excerpt": ""}]
    todos = [{"file": f"f{i}.py", "qualname": f"<line {i}>",
               "lineno": i, "kind": "todo_marker", "excerpt": ""}
              for i in range(20)]
    # 1 real (8 pts) + 5 cap = 13 total.
    assert stub_penalty(real + todos) == 13


def test_stub_penalty_dedupes_by_qualname(tmp_path):
    """GAP-006: materialize duplicates parent classes across subclass
    files. One underlying stubbed method should count as one issue,
    not N — even when emitted into N files.
    """
    findings = [
        {"file": f"a1_at_functions/sub_{i}.py",
         "qualname": "BaseCompressor.compress",
         "lineno": 58, "kind": "not_implemented", "excerpt": ""}
        for i in range(14)
    ]
    # Same qualname x14 -> 1 unique issue -> 8 point penalty.
    assert stub_penalty(findings) == 8


def test_stub_penalty_keeps_distinct_line_markers(tmp_path):
    """``<line N>`` TODO markers are file-local — they remain distinct
    findings (post GAP-010 they each weigh 1 instead of 8)."""
    findings = [
        {"file": "a.py", "qualname": "<line 1>", "lineno": 1,
         "kind": "todo_marker", "excerpt": ""},
        {"file": "b.py", "qualname": "<line 1>", "lineno": 1,
         "kind": "todo_marker", "excerpt": ""},
    ]
    # 2 distinct TODOs, 1 point each, well under the 5-point cap.
    assert stub_penalty(findings) == 2


def test_certify_deducts_for_stubs(tmp_path):
    pkg = tmp_path / "src" / "demo"
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    for tier in ("a0_qk_constants", "a1_at_functions", "a2_mo_composites",
                 "a3_og_features", "a4_sy_orchestration"):
        d = pkg / tier
        d.mkdir()
        (d / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "a1_at_functions" / "stubby.py").write_text(
        "def needs_work():\n    pass\n", encoding="utf-8")
    (tmp_path / "README.md").write_text("# demo\n", encoding="utf-8")
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_x.py").write_text(
        "import demo\ndef test_one():\n    assert demo is not None\n",
        encoding="utf-8")
    result = certify(tmp_path, project="demo", package="demo")
    # Score weights (rubric sums to 100; this fixture lacks the
    # operational-axis files so the operational component is 0):
    #   structural:  docs(10)+layout(10)+wire(10)+tests-present(5) = 35
    #   runtime:     import(25)
    #   behavioral:  pass-ratio(1.0) * 30                          = 30
    #   operational: ci(0) + changelog(0)                          = 0
    #   stub penalty: -8 (one stub)
    # Total: 35 + 25 + 30 + 0 - 8 = 82.
    assert result["score"] == 82
    assert result["no_stub_bodies"] is False
    assert result["package_importable"] is True
    assert any("Stub bodies detected" in i for i in result["issues"])


def test_certify_score_pristine_with_no_stubs(tmp_path):
    pkg = tmp_path / "src" / "demo"
    pkg.mkdir(parents=True)
    for tier in ("a0_qk_constants", "a1_at_functions", "a2_mo_composites",
                 "a3_og_features", "a4_sy_orchestration"):
        d = pkg / tier
        d.mkdir()
        (d / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "a1_at_functions" / "real.py").write_text(
        "def add(a, b):\n    return a + b\n", encoding="utf-8")
    (tmp_path / "README.md").write_text("# demo\n", encoding="utf-8")
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_x.py").write_text(
        "import demo\ndef test_x():\n    assert demo is not None\n",
        encoding="utf-8")
    result = certify(tmp_path, project="demo", package="demo")
    # Score weights (rubric sums to 100):
    #   structural:  docs(10)+layout(10)+wire(10)+tests-present(5) = 35
    #   runtime:     import(25)                                    = 25
    #   behavioral:  pass-ratio(1.0) * 30                          = 30
    #   operational: ci(0) + changelog(0)                          = 0
    # Total: 35 + 25 + 30 + 0 = 90.  This fixture deliberately omits
    # .github/workflows/ and CHANGELOG.md so it cannot earn the
    # operational axis — see ``test_certify_operational_axis.py`` for
    # the 100/100 path.
    assert result["score"] == 90
    assert result["test_pass_ratio"] == 1.0
    assert result["no_stub_bodies"] is True
    assert result["package_importable"] is True


def test_certify_penalises_unimportable_package(tmp_path):
    """Wire-clean tier tree but a syntax error → loses runtime AND behavioral points."""
    pkg = tmp_path / "src" / "demo"
    pkg.mkdir(parents=True)
    for tier in ("a0_qk_constants", "a1_at_functions", "a2_mo_composites",
                 "a3_og_features", "a4_sy_orchestration"):
        d = pkg / tier
        d.mkdir()
        (d / "__init__.py").write_text("", encoding="utf-8")
    # __init__.py triggers a syntax error during `python -c "import demo"`.
    (pkg / "__init__.py").write_text("def broken(\n    return\n", encoding="utf-8")
    (tmp_path / "README.md").write_text("# demo\n", encoding="utf-8")
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_x.py").write_text(
        "def test_one():\n    assert True\n", encoding="utf-8")
    result = certify(tmp_path, project="demo", package="demo")
    assert result["package_importable"] is False
    # structural 35 + runtime 0 + behavioral 0 (tests can't run if package
    # doesn't import — the runner is gated on importable) = 35.
    assert result["score"] == 35
    assert any("fails to import" in i for i in result["issues"])
