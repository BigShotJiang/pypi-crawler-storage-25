"""Per-symbol Python-parity tests for Rust / Go / Swift / Kotlin.

The 2026-05-06 polyglot lift made every language readable by Forge.
This test suite pins the *symbol-level* contract: harvest_repo emits
one record per public function / class / struct / method / constant
in a native-language file, with proper tier classification and
effect detection — matching what Python and JS already produce.
"""
from __future__ import annotations

import pytest

from atomadic_forge.a1_at_functions.polyglot_classify import (
    classify_native_tier,
    detect_native_effects,
)
from atomadic_forge.a1_at_functions.polyglot_surface import (
    NativeSurface,
    parse_go_surface,
    parse_kotlin_surface,
    parse_rust_surface,
    parse_surface_for_language,
    parse_swift_surface,
)
from atomadic_forge.a1_at_functions.scout_walk import harvest_repo

# ────────────────────────────────────────────────────────────────────
# Rust surface parser
# ────────────────────────────────────────────────────────────────────


def test_rust_surface_extracts_pub_fn_struct_enum_trait():
    src = """
        pub fn add(a: u8, b: u8) -> u8 { a + b }
        pub async fn fetch_data() -> Result<String, std::io::Error> { Ok(String::new()) }
        pub struct User { pub name: String }
        pub enum Color { Red, Green, Blue }
        pub trait Greeter { fn greet(&self); }
        pub const MAX: u32 = 99;
        // pub fn ignored() {}
        /* pub fn also_ignored() {} */
        fn private_fn() {}
    """
    s = parse_rust_surface(src)
    assert s.language == "rust"
    assert "add" in s.pub_functions
    assert "fetch_data" in s.pub_functions
    assert "private_fn" not in s.pub_functions  # not pub
    assert "ignored" not in s.pub_functions  # commented out
    assert "User" in s.pub_classes
    assert "Color" in s.pub_classes
    assert "Greeter" in s.pub_classes
    assert "MAX" in s.pub_constants
    assert s.has_state  # any pub class triggers it


def test_rust_surface_extracts_impl_methods():
    src = """
        pub struct Counter { val: u32 }
        impl Counter {
            pub fn new() -> Self { Self { val: 0 } }
            pub fn inc(&mut self) { self.val += 1 }
            fn private_helper(&self) {}
        }
    """
    s = parse_rust_surface(src)
    assert s.pub_classes == ["Counter"]
    method_names = {(p, m) for p, m in s.pub_methods}
    assert ("Counter", "new") in method_names
    assert ("Counter", "inc") in method_names
    assert ("Counter", "private_helper") not in method_names


def test_rust_surface_io_signal_from_use_statements():
    src = "use std::fs;\nuse std::net::TcpStream;\npub fn open() -> std::io::Result<()> { Ok(()) }\n"
    s = parse_rust_surface(src)
    assert s.has_io is True


def test_rust_surface_main_entry_signal():
    src = "fn main() { println!(\"hi\"); }"
    s = parse_rust_surface(src)
    assert s.has_main_entry is True


# ────────────────────────────────────────────────────────────────────
# Go surface parser
# ────────────────────────────────────────────────────────────────────


def test_go_surface_extracts_exported_funcs_types_methods():
    src = """
        package foo

        import "os"
        import "net/http"

        type User struct {
            Name string
            age  int
        }

        type Greeter interface {
            Greet() string
        }

        func NewUser(name string) *User { return &User{Name: name} }

        func (u *User) Greet() string { return "Hello, " + u.Name }
        func (u *User) hidden() {}      // lowercase = unexported

        const MaxUsers = 100
        var DefaultName = "anon"

        func privateHelper() {}
    """
    s = parse_go_surface(src)
    assert s.language == "go"
    assert "NewUser" in s.pub_functions
    assert "privateHelper" not in s.pub_functions
    assert "User" in s.pub_classes
    assert "Greeter" in s.pub_classes
    method_names = {(p, m) for p, m in s.pub_methods}
    assert ("User", "Greet") in method_names
    # lowercase method name is unexported — should not appear
    assert all(not m[1].startswith("h") or m[1][0].isupper() for m in method_names)
    assert "MaxUsers" in s.pub_constants
    assert "DefaultName" in s.pub_constants
    assert s.has_io is True  # net/http import


def test_go_surface_main_entry_signal():
    src = "package main\n\nfunc main() { print(\"hi\") }\n"
    s = parse_go_surface(src)
    assert s.has_main_entry is True


# ────────────────────────────────────────────────────────────────────
# Swift surface parser
# ────────────────────────────────────────────────────────────────────


def test_swift_surface_extracts_top_level_funcs_classes_protocols():
    src = """
        import Foundation

        public struct User {
            public let name: String
            public func greet() -> String { return "Hello, \\(name)" }
        }

        public protocol Greeter {
            func greet() -> String
        }

        public class Service {
            public func run() { }
        }

        public enum Color { case red, green }

        public func makeUser(name: String) -> User { return User(name: name) }
    """
    s = parse_swift_surface(src)
    assert s.language == "swift"
    assert "makeUser" in s.pub_functions
    assert {"User", "Greeter", "Service", "Color"}.issubset(set(s.pub_classes))
    method_pairs = {(p, m) for p, m in s.pub_methods}
    # Methods inside types live in pub_methods, not pub_functions.
    assert ("User", "greet") in method_pairs
    assert ("Service", "run") in method_pairs
    assert "greet" not in s.pub_functions
    assert "run" not in s.pub_functions
    assert s.has_io is True  # Foundation import
    assert s.has_state is True


def test_swift_surface_main_entry_signal():
    src = "@main struct App { static func main() {} }"
    s = parse_swift_surface(src)
    assert s.has_main_entry is True


# ────────────────────────────────────────────────────────────────────
# Kotlin surface parser
# ────────────────────────────────────────────────────────────────────


def test_kotlin_surface_extracts_top_level_funs_classes_objects():
    src = """
        package com.example

        import java.io.File

        data class User(val name: String)

        sealed class Result
        class Service { fun run() {} }
        object Constants { const val MAX = 99 }
        interface Greeter { fun greet(): String }

        fun makeUser(name: String): User = User(name)

        const val DEFAULT_NAME: String = "anon"
    """
    s = parse_kotlin_surface(src)
    assert s.language == "kotlin"
    assert "makeUser" in s.pub_functions
    assert {"User", "Result", "Service", "Constants", "Greeter"}.issubset(set(s.pub_classes))
    assert "DEFAULT_NAME" in s.pub_constants
    assert "MAX" in s.pub_constants
    assert s.has_io is True  # java.io import
    assert s.has_state is True  # has classes/objects


def test_kotlin_surface_main_entry_signal():
    src = "package x\n\nfun main() { println(\"hi\") }"
    s = parse_kotlin_surface(src)
    assert s.has_main_entry is True


# ────────────────────────────────────────────────────────────────────
# Tier classifier — path → tier rule wins
# ────────────────────────────────────────────────────────────────────


def test_classify_native_path_tier_wins_over_signals():
    # File lives under a1_at_functions but has a class (would otherwise be a2)
    surface = parse_rust_surface("pub struct S {}\n")
    tier = classify_native_tier(
        path="src/foo/a1_at_functions/util.rs", surface=surface,
    )
    assert tier == "a1_at_functions"


def test_classify_native_main_entry_to_a4():
    surface = parse_rust_surface("fn main() {}\n")
    tier = classify_native_tier(path="bin/main.rs", surface=surface)
    assert tier == "a4_sy_orchestration"


def test_classify_native_io_only_to_a4():
    surface = parse_rust_surface("use std::fs;\n")
    tier = classify_native_tier(path="some/where/file.rs", surface=surface)
    assert tier == "a4_sy_orchestration"


def test_classify_native_classes_to_a2():
    surface = parse_go_surface("package x\ntype Foo struct { name string }\n")
    tier = classify_native_tier(path="some/path/foo.go", surface=surface)
    assert tier == "a2_mo_composites"


def test_classify_native_pure_functions_to_a1():
    surface = parse_rust_surface("pub fn add(a: u8, b: u8) -> u8 { a + b }\n")
    tier = classify_native_tier(path="lib/util.rs", surface=surface)
    assert tier == "a1_at_functions"


def test_classify_native_constants_only_to_a0():
    surface = parse_rust_surface("pub const MAX: u32 = 99;\npub const MIN: u32 = 0;\n")
    tier = classify_native_tier(path="lib/limits.rs", surface=surface)
    assert tier == "a0_qk_constants"


def test_classify_native_unknown_to_a3():
    surface = NativeSurface(language="rust")
    tier = classify_native_tier(path="random/file.rs", surface=surface)
    assert tier == "a3_og_features"


# ────────────────────────────────────────────────────────────────────
# Effect detector
# ────────────────────────────────────────────────────────────────────


def test_detect_native_effects_pure_functions_only():
    surface = parse_rust_surface("pub fn add(a: u8, b: u8) -> u8 { a + b }\n")
    assert detect_native_effects(surface) == ["pure"]


def test_detect_native_effects_state_when_class_present():
    surface = parse_go_surface("package x\ntype Foo struct{}\n")
    eff = detect_native_effects(surface)
    assert "state" in eff
    assert "pure" not in eff  # state replaces pure


def test_detect_native_effects_combines_state_and_io():
    surface = parse_kotlin_surface(
        "package x\nimport java.net.URL\nclass Service {}\n"
    )
    eff = detect_native_effects(surface)
    assert set(eff) == {"state", "io"}


# ────────────────────────────────────────────────────────────────────
# Surface router
# ────────────────────────────────────────────────────────────────────


@pytest.mark.parametrize("language", ["rust", "go", "swift", "kotlin"])
def test_parse_surface_for_language_dispatches(language):
    s = parse_surface_for_language(language, "")
    assert isinstance(s, NativeSurface)
    assert s.language == language


def test_parse_surface_for_language_returns_none_for_python():
    assert parse_surface_for_language("python", "def f(): pass") is None


# ────────────────────────────────────────────────────────────────────
# scout_walk — per-symbol records emitted for native langs
# ────────────────────────────────────────────────────────────────────


def test_harvest_repo_rust_emits_per_symbol_records(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "a1_at_functions").mkdir()
    (tmp_path / "src" / "a1_at_functions" / "math.rs").write_text(
        "pub fn add(a: u8, b: u8) -> u8 { a + b }\n"
        "pub fn sub(a: u8, b: u8) -> u8 { a - b }\n"
        "pub const PI: f64 = 3.14;\n",
        encoding="utf-8",
    )
    report = harvest_repo(tmp_path)
    rust_symbols = [s for s in report["symbols"] if s.get("language") == "rust"]
    kinds = {s["kind"] for s in rust_symbols}
    assert "module" in kinds
    assert "function" in kinds
    assert "const" in kinds
    fn_names = {s["name"] for s in rust_symbols if s["kind"] == "function"}
    assert {"add", "sub"} == fn_names
    const_names = {s["name"] for s in rust_symbols if s["kind"] == "const"}
    assert "PI" in const_names
    # File lives under a1_at_functions/ — every record should carry that tier.
    for s in rust_symbols:
        assert s["tier_guess"] == "a1_at_functions"


def test_harvest_repo_go_emits_per_symbol_records_with_methods(tmp_path):
    (tmp_path / "internal").mkdir()
    (tmp_path / "internal" / "user.go").write_text(
        "package internal\n\n"
        "type User struct { Name string }\n"
        "func NewUser(name string) *User { return &User{Name: name} }\n"
        "func (u *User) Greet() string { return u.Name }\n",
        encoding="utf-8",
    )
    report = harvest_repo(tmp_path)
    go_symbols = [s for s in report["symbols"] if s.get("language") == "go"]
    method_records = [s for s in go_symbols if s["kind"] == "method"]
    assert any(s["name"] == "User.Greet" for s in method_records)
    fn_records = [s for s in go_symbols if s["kind"] == "function"]
    assert any(s["name"] == "NewUser" for s in fn_records)
    class_records = [s for s in go_symbols if s["kind"] == "class"]
    assert any(s["name"] == "User" for s in class_records)


def test_harvest_repo_swift_emits_methods_separately(tmp_path):
    (tmp_path / "Sources").mkdir()
    (tmp_path / "Sources" / "App.swift").write_text(
        "import Foundation\n"
        "public class Service {\n"
        "    public func run() {}\n"
        "    public func stop() {}\n"
        "}\n",
        encoding="utf-8",
    )
    report = harvest_repo(tmp_path)
    swift = [s for s in report["symbols"] if s.get("language") == "swift"]
    methods = [s for s in swift if s["kind"] == "method"]
    method_names = {s["name"] for s in methods}
    assert "Service.run" in method_names
    assert "Service.stop" in method_names
    classes = [s for s in swift if s["kind"] == "class"]
    assert any(s["name"] == "Service" for s in classes)


def test_harvest_repo_kotlin_emits_per_symbol_records(tmp_path):
    (tmp_path / "src" / "main" / "kotlin").mkdir(parents=True)
    (tmp_path / "src" / "main" / "kotlin" / "User.kt").write_text(
        "package com.example\n\n"
        "data class User(val name: String)\n"
        "fun makeUser(name: String): User = User(name)\n"
        "const val DEFAULT: String = \"anon\"\n",
        encoding="utf-8",
    )
    report = harvest_repo(tmp_path)
    kt = [s for s in report["symbols"] if s.get("language") == "kotlin"]
    kinds = {s["kind"] for s in kt}
    assert {"module", "function", "class", "const"}.issubset(kinds)


def test_harvest_repo_classifies_io_heavy_native_files_to_boundary(tmp_path):
    """An I/O-heavy file with no aN_*/ parent directory should land at a3
    or a4 — not get incorrectly bucketed to a1 just because it has fns."""
    (tmp_path / "lib.rs").write_text(
        "use std::fs;\nuse std::net::TcpStream;\n"
        "pub fn read_file(path: &str) {}\n",
        encoding="utf-8",
    )
    report = harvest_repo(tmp_path)
    rust = [s for s in report["symbols"] if s.get("language") == "rust"]
    # File-level record should reflect the I/O boundary placement.
    module_record = next(s for s in rust if s["kind"] == "module")
    assert module_record["tier_guess"] in (
        "a3_og_features", "a4_sy_orchestration",
    )
    assert "io" in module_record["effects"]


def test_harvest_repo_effect_distribution_includes_native_effects(tmp_path):
    (tmp_path / "x.rs").write_text(
        "pub fn pure_fn() {}\n", encoding="utf-8",
    )
    (tmp_path / "y.go").write_text(
        "package y\nimport \"net/http\"\ntype S struct{}\n", encoding="utf-8",
    )
    report = harvest_repo(tmp_path)
    eff = report["effect_distribution"]
    # Both pure and state/io should have been bumped by native files.
    assert eff["pure"] >= 1
    assert eff["state"] + eff["io"] >= 1
