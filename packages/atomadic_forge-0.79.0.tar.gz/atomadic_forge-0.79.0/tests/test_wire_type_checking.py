"""Wire-check edge cases — TYPE_CHECKING / dynamic imports / star imports / cycles.

v0.14.0a9 enhancements:
  * ``if TYPE_CHECKING:`` guarded imports are NOT runtime violations.
  * ``importlib.import_module(...)`` calls surface as warnings.
  * ``from .X import *`` always surfaces (defeats the contract).
  * ``--strict-cycles`` opts into same-tier circular-import detection.
"""
from __future__ import annotations

from pathlib import Path

from atomadic_forge.a1_at_functions.wire_check import scan_violations


def _make_pkg(root: Path, files: dict[str, str]) -> None:
    """Materialize a synthetic tier-organized package under ``root``."""
    for rel, content in files.items():
        target = root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")


def test_type_checking_guard_is_not_a_violation(tmp_path: Path) -> None:
    pkg = tmp_path / "pkg"
    _make_pkg(pkg, {
        "a1_at_functions/__init__.py": "",
        "a3_og_features/__init__.py": "",
        "a3_og_features/feature.py": "class Feature: pass\n",
        "a1_at_functions/util.py": (
            "from __future__ import annotations\n"
            "from typing import TYPE_CHECKING\n"
            "if TYPE_CHECKING:\n"
            "    from ..a3_og_features.feature import Feature\n"
        ),
    })
    report = scan_violations(pkg)
    assert report["verdict"] == "PASS", report
    assert report["violation_count"] == 0
    # And the import IS surfaced under type_only_imports for review.
    assert any(
        e["from_tier"] == "a1_at_functions" and e["to_tier"] == "a3_og_features"
        for e in report["type_only_imports"]
    )


def test_unguarded_runtime_import_still_violates(tmp_path: Path) -> None:
    """Regression — the type-only check must not weaken normal scanning."""
    pkg = tmp_path / "pkg"
    _make_pkg(pkg, {
        "a1_at_functions/__init__.py": "",
        "a3_og_features/__init__.py": "",
        "a3_og_features/feature.py": "class Feature: pass\n",
        "a1_at_functions/util.py": (
            "from ..a3_og_features.feature import Feature\n"
        ),
    })
    report = scan_violations(pkg)
    assert report["verdict"] == "FAIL"
    assert report["violation_count"] == 1


def test_typing_dotted_protocol_is_recognized(tmp_path: Path) -> None:
    """``import typing`` / ``if typing.TYPE_CHECKING`` also passes."""
    pkg = tmp_path / "pkg"
    _make_pkg(pkg, {
        "a1_at_functions/__init__.py": "",
        "a3_og_features/__init__.py": "",
        "a3_og_features/feature.py": "class Feature: pass\n",
        "a1_at_functions/util.py": (
            "import typing\n"
            "if typing.TYPE_CHECKING:\n"
            "    from ..a3_og_features.feature import Feature\n"
        ),
    })
    report = scan_violations(pkg)
    assert report["verdict"] == "PASS"


def test_dynamic_import_module_string_is_warned(tmp_path: Path) -> None:
    pkg = tmp_path / "pkg"
    _make_pkg(pkg, {
        "a1_at_functions/__init__.py": "",
        "a1_at_functions/dynamic.py": (
            "import importlib\n"
            "_mod = importlib.import_module('pkg.a3_og_features.feature')\n"
        ),
    })
    report = scan_violations(pkg)
    assert report["verdict"] == "PASS"  # not a hard violation
    warnings = report["dynamic_import_warnings"]
    assert len(warnings) == 1
    assert warnings[0]["module"] == "pkg.a3_og_features.feature"


def test_dynamic_import_module_nonliteral_marked_dynamic(tmp_path: Path) -> None:
    pkg = tmp_path / "pkg"
    _make_pkg(pkg, {
        "a1_at_functions/__init__.py": "",
        "a1_at_functions/dynamic.py": (
            "import importlib\n"
            "name = 'pkg.foo'\n"
            "_mod = importlib.import_module(name)\n"
        ),
    })
    report = scan_violations(pkg)
    assert report["dynamic_import_warnings"][0]["module"] == "<dynamic>"


def test_star_import_always_warned(tmp_path: Path) -> None:
    pkg = tmp_path / "pkg"
    _make_pkg(pkg, {
        "a1_at_functions/__init__.py": "",
        "a1_at_functions/sibling.py": "FOO = 1\n",
        "a1_at_functions/util.py": "from .sibling import *\n",
    })
    report = scan_violations(pkg)
    assert report["verdict"] == "PASS"  # same-tier import is allowed
    star = report["star_import_warnings"]
    assert len(star) == 1
    assert star[0]["module"] == "sibling"


def test_strict_cycles_off_by_default(tmp_path: Path) -> None:
    """Same-tier cycles are NOT in the report unless strict_cycles=True."""
    pkg = tmp_path / "pkg"
    _make_pkg(pkg, {
        "a2_mo_composites/__init__.py": "",
        "a2_mo_composites/foo.py": "from .bar import B\n",
        "a2_mo_composites/bar.py": "from .foo import A\n",
    })
    report_default = scan_violations(pkg)
    assert "same_tier_cycles" not in report_default


def test_strict_cycles_on_detects_pair(tmp_path: Path) -> None:
    pkg = tmp_path / "pkg"
    _make_pkg(pkg, {
        "a2_mo_composites/__init__.py": "",
        "a2_mo_composites/foo.py": "from .bar import B\n",
        "a2_mo_composites/bar.py": "from .foo import A\n",
    })
    report = scan_violations(pkg, strict_cycles=True)
    assert "same_tier_cycles" in report
    cycles = report["same_tier_cycles"]
    assert len(cycles) == 1
    files = cycles[0]["files"]
    assert "a2_mo_composites/foo.py" in files
    assert "a2_mo_composites/bar.py" in files


def test_strict_cycles_no_false_positive_on_one_way_import(tmp_path: Path) -> None:
    pkg = tmp_path / "pkg"
    _make_pkg(pkg, {
        "a2_mo_composites/__init__.py": "",
        "a2_mo_composites/a.py": "from .b import B\n",
        "a2_mo_composites/b.py": "X = 1\n",  # no import back
    })
    report = scan_violations(pkg, strict_cycles=True)
    assert report["same_tier_cycles"] == []


def test_existing_tests_still_pass_with_new_fields(tmp_path: Path) -> None:
    """The v1 schema gains new fields but old fields keep their meaning."""
    pkg = tmp_path / "pkg"
    _make_pkg(pkg, {
        "a1_at_functions/__init__.py": "",
        "a1_at_functions/clean.py": "x = 1\n",
    })
    report = scan_violations(pkg)
    # Schema still v1, old keys all present.
    assert report["schema_version"] == "atomadic-forge.wire/v1"
    assert report["verdict"] == "PASS"
    assert report["violation_count"] == 0
    assert report["violations"] == []
    # New keys are present-but-empty so consumers can rely on them.
    assert report["type_only_imports"] == []
    assert report["dynamic_import_warnings"] == []
    assert report["star_import_warnings"] == []
