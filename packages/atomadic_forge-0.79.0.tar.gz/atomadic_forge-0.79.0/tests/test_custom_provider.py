"""Pin the v0.18.0 flexible-LLM-provider contract.

Forge previously hardcoded six provider classes (Anthropic / OpenAI /
Gemini / Ollama / OpenRouter / AAAA-Nexus).  v0.18.0 adds the
:class:`CustomProviderClient` + ``custom_providers`` config so users can
wire any OpenAI-compatible service (DeepSeek, Groq, Together, Fireworks,
xAI, Mistral, Perplexity, Cerebras, Hyperbolic, …) without writing
Python.

This file pins:
  * Preset registry covers every provider documented in the README.
  * ``from_config`` validates required fields with or without preset.
  * Resolver looks up custom providers from config, falls back to
    presets, and finally to the hardcoded backward-compat names.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from atomadic_forge.a0_qk_constants.config_defaults import (
    CONFIG_FILE_NAME,
    DEFAULT_CONFIG,
    LOCAL_CONFIG_DIR,
)
from atomadic_forge.a1_at_functions.custom_provider_client import (
    CustomProviderClient,
    from_config,
    list_presets,
    resolve_preset,
)
from atomadic_forge.a1_at_functions.provider_resolver import resolve_provider

# ────────────────────────────────────────────────────────────────────
# Preset registry
# ────────────────────────────────────────────────────────────────────


@pytest.mark.parametrize("name", [
    "openai", "openrouter", "deepseek", "groq", "together",
    "fireworks", "xai", "mistral", "perplexity", "cerebras", "hyperbolic",
])
def test_preset_has_required_fields(name):
    p = resolve_preset(name)
    assert p is not None, f"preset {name!r} missing"
    assert p["base_url"].startswith("http")
    assert p["model"]
    assert p["api_key_env"]


def test_list_presets_is_sorted():
    presets = list_presets()
    assert presets == sorted(presets)
    assert "groq" in presets and "deepseek" in presets


def test_resolve_preset_unknown_returns_none():
    assert resolve_preset("not-a-real-provider") is None


# ────────────────────────────────────────────────────────────────────
# CustomProviderClient construction + validation
# ────────────────────────────────────────────────────────────────────


def test_from_config_with_preset_only():
    client = from_config({"name": "deepseek", "preset": "deepseek"})
    assert isinstance(client, CustomProviderClient)
    assert client.name == "deepseek"
    assert client.base_url.startswith("https://api.deepseek.com")
    assert client.model == "deepseek-chat"
    assert client._api_key_env == "DEEPSEEK_API_KEY"


def test_from_config_user_overrides_preset():
    """User-supplied fields win over preset defaults."""
    client = from_config({
        "name": "groq-with-override",
        "preset": "groq",
        "model": "mixtral-8x7b-32768",
    })
    assert client.model == "mixtral-8x7b-32768"  # user override
    assert client.base_url.startswith("https://api.groq.com")  # from preset


def test_from_config_full_manual():
    client = from_config({
        "name": "my-private-llm",
        "base_url": "https://internal.corp/v1",
        "model": "llama-99",
        "api_key_env": "CORP_LLM_KEY",
    })
    assert client.name == "my-private-llm"
    assert client.base_url == "https://internal.corp/v1"
    assert client.model == "llama-99"
    assert client._api_key_env == "CORP_LLM_KEY"


def test_from_config_unknown_preset_raises():
    with pytest.raises(ValueError, match="unknown preset"):
        from_config({"name": "x", "preset": "not-real"})


def test_from_config_missing_required_raises():
    with pytest.raises(ValueError, match="required field"):
        from_config({"name": "incomplete", "base_url": "https://x"})


def test_from_config_extra_headers_attached():
    client = from_config({
        "name": "openrouter-custom",
        "base_url": "https://openrouter.ai/api/v1",
        "model": "x/y",
        "api_key_env": "OR_KEY",
        "extra_headers": {"HTTP-Referer": "https://demo", "X-Title": "Demo"},
    })
    assert client.extra_headers == {
        "HTTP-Referer": "https://demo", "X-Title": "Demo",
    }


# ────────────────────────────────────────────────────────────────────
# Network call shape (mocked)
# ────────────────────────────────────────────────────────────────────


def test_call_raises_when_api_key_env_unset(monkeypatch):
    monkeypatch.delenv("MY_KEY", raising=False)
    client = CustomProviderClient(
        name="my", base_url="https://x", model="m", api_key_env="MY_KEY",
    )
    with pytest.raises(RuntimeError, match="MY_KEY not set"):
        client.call("hello")


def test_call_uses_chat_completions_endpoint(monkeypatch):
    monkeypatch.setenv("FAKE_KEY", "sk-test")
    client = CustomProviderClient(
        name="fake", base_url="https://example.com/v1",
        model="fake-model", api_key_env="FAKE_KEY",
    )
    captured: dict = {}

    class _Resp:
        def __init__(self, data):
            self._data = data
        def __enter__(self):
            return self
        def __exit__(self, *args):
            pass
        def read(self):
            return json.dumps(self._data).encode("utf-8")

    def fake_urlopen(req, timeout):
        captured["url"] = req.full_url
        captured["body"] = json.loads(req.data.decode("utf-8"))
        captured["headers"] = dict(req.headers)
        return _Resp({"choices": [{"message": {"content": "hi back"}}]})

    monkeypatch.setattr(
        "atomadic_forge.a1_at_functions.custom_provider_client."
        "urllib.request.urlopen",
        fake_urlopen,
    )
    out = client.call("ping", system="be brief", max_tokens=100, temperature=0.5)
    assert out == "hi back"
    assert captured["url"] == "https://example.com/v1/chat/completions"
    assert captured["body"]["model"] == "fake-model"
    assert captured["body"]["max_tokens"] == 100
    assert captured["body"]["messages"][0] == {
        "role": "system", "content": "be brief",
    }
    # Check Authorization header (Werkzeug-style title case).
    auth = (captured["headers"].get("Authorization")
            or captured["headers"].get("authorization"))
    assert auth == "Bearer sk-test"


# ────────────────────────────────────────────────────────────────────
# Resolver — config-based custom provider lookup
# ────────────────────────────────────────────────────────────────────


def _write_local_config(project_dir: Path, custom_providers: list[dict]) -> None:
    cfg_dir = project_dir / LOCAL_CONFIG_DIR
    cfg_dir.mkdir(parents=True, exist_ok=True)
    (cfg_dir / CONFIG_FILE_NAME).write_text(
        json.dumps({
            **DEFAULT_CONFIG,
            "custom_providers": custom_providers,
        }, indent=2),
        encoding="utf-8",
    )


def test_resolver_loads_custom_provider_from_config(tmp_path):
    _write_local_config(tmp_path, [{
        "name": "my-llm",
        "base_url": "https://my.private/v1",
        "model": "private-7b",
        "api_key_env": "MY_PRIVATE_KEY",
    }])
    client = resolve_provider("my-llm", project_root=tmp_path)
    assert isinstance(client, CustomProviderClient)
    assert client.name == "my-llm"
    assert client.base_url == "https://my.private/v1"


def test_resolver_falls_back_to_preset_when_no_config_match(tmp_path):
    """`forge --provider deepseek` works without ANY config entry."""
    client = resolve_provider("deepseek", project_root=tmp_path)
    assert isinstance(client, CustomProviderClient)
    assert client.name == "deepseek"


def test_resolver_env_var_overrides_preset_model(tmp_path, monkeypatch):
    monkeypatch.setenv("FORGE_GROQ_MODEL", "llama3-70b-8192")
    client = resolve_provider("groq", project_root=tmp_path)
    assert client.model == "llama3-70b-8192"


def test_resolver_unknown_provider_lists_alternatives(tmp_path):
    with pytest.raises(ValueError, match="unknown provider"):
        resolve_provider("gibberish-llm-xyz", project_root=tmp_path)


def test_resolver_keeps_hardcoded_backward_compat(tmp_path):
    """`forge --provider stub` still hits StubLLMClient."""
    from atomadic_forge.a1_at_functions.llm_client import StubLLMClient
    client = resolve_provider("stub", project_root=tmp_path)
    assert isinstance(client, StubLLMClient)


def test_resolver_config_match_wins_over_preset(tmp_path):
    """If a custom_providers entry shares a name with a preset, the
    config wins (so users can override preset defaults)."""
    _write_local_config(tmp_path, [{
        "name": "groq",
        "base_url": "https://my-proxy.tld/v1",
        "model": "proxy-model",
        "api_key_env": "PROXY_KEY",
    }])
    client = resolve_provider("groq", project_root=tmp_path)
    assert client.base_url == "https://my-proxy.tld/v1"
    assert client.model == "proxy-model"
    assert client._api_key_env == "PROXY_KEY"
