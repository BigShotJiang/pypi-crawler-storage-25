"""Regression: ``forge sbom`` text output dereferences nested CycloneDX
correctly so ``components: N`` reflects the real count, not 0.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]


def test_sbom_text_summary_shows_real_component_count(tmp_path):
    proj = tmp_path / "demo"
    proj.mkdir()
    (proj / "pyproject.toml").write_text(
        "[project]\nname = \"demo\"\nversion = \"0.1.0\"\n"
        "dependencies = [\"requests>=2\", \"rich>=14\"]\n",
        encoding="utf-8",
    )
    out = subprocess.run(
        [sys.executable, "-m", "atomadic_forge", "sbom", str(proj)],
        cwd=REPO_ROOT, capture_output=True, text=True, check=True,
    )
    text = out.stdout
    assert "components: 2" in text, text
    assert "components: 0" not in text, text
