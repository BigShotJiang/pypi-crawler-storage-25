"""Tests for the a3 ``create_from_intent`` orchestrator."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from atomadic_forge.a3_og_features import create_feature
from atomadic_forge.a3_og_features.create_feature import (
    SCHEMA_VERSION_CREATE_V1,
    create_from_intent,
    resolve_seed_repo,
)


def _fake_swarm_report() -> dict:
    return {
        "schema_version": "atomadic-forge.emergent_swarm/v1",
        "generated_at_utc": "2026-05-06T00:00:00Z",
        "repo_count": 1,
        "union_catalog_size": 3,
        "chain_count_considered": 2,
        "candidate_count": 1,
        "cross_repo_chain_count": 0,
        "novel_composition_count": 1,
        "static_confirmed_count": 0,
        "d_max_cap": 23,
        "per_repo": [
            {"package": "fake_pkg", "card_count": 3, "exists": True},
        ],
        "candidates": [
            {
                "candidate_id": "emrg-fake1234",
                "name": "fake-composition",
                "summary": "test composition",
                "chain": {
                    "chain": [
                        "atomadic_forge.a1_at_functions.scaffold_starter.render_gitignore",
                    ],
                    "bridges": [],
                    "tiers": ["a1_at_functions"],
                    "domains": ["scaffold"],
                    "crosses_domains": 1,
                    "crosses_tiers": 1,
                    "final_output_type": "str",
                    "pure": True,
                },
                "score": 80.0,
                "score_boosted": 80.0,
                "score_breakdown": {"novelty": 40, "purity": 40},
                "suggested_tier": "a3_og_features",
                "novelty_signals": ["fake test signal"],
                "origin_repos": ["fake_pkg"],
                "crosses_repos": 1,
                "edge_confidence": "ast_inferred",
                "novel_composition": True,
            },
        ],
    }


def _fake_seed_repo(root: Path) -> Path:
    """Build a minimal tier-organized seed repo on disk."""
    pkg = root / "fake_pkg"
    for tier in (
        "a0_qk_constants",
        "a1_at_functions",
        "a2_mo_composites",
        "a3_og_features",
        "a4_sy_orchestration",
    ):
        d = pkg / tier
        d.mkdir(parents=True, exist_ok=True)
        (d / "__init__.py").write_text(f'"""tier {tier}."""\n', encoding="utf-8")
    (pkg / "__init__.py").write_text('"""fake_pkg."""\n', encoding="utf-8")
    return pkg


def _fake_flat_module_repo(root: Path) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    (root / "pyproject.toml").write_text(
        "[tool.setuptools]\npy-modules = ['flat_tool']\n",
        encoding="utf-8",
    )
    (root / "flat_tool.py").write_text(
        "def render_map(value: str) -> str:\n"
        "    return value\n",
        encoding="utf-8",
    )
    return root


def _fake_node_repo(root: Path) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    (root / "package.json").write_text(
        '{"name": "@scope/agentic-tools-mcp"}\n',
        encoding="utf-8",
    )
    (root / "src").mkdir()
    (root / "src" / "index.ts").write_text(
        "export function createMemory(value: string) { return value }\n",
        encoding="utf-8",
    )
    return root


def _fake_source_only_polyglot_repo(root: Path) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    (root / "Sources").mkdir()
    (root / "Sources" / "MemoryStore.swift").write_text(
        "public func createMemory(_ value: String) -> String { value }\n",
        encoding="utf-8",
    )
    return root


def test_resolve_seed_repo_tier_bearing_directly(tmp_path: Path) -> None:
    pkg = _fake_seed_repo(tmp_path)
    src_root, name = resolve_seed_repo(pkg)
    assert src_root == pkg.resolve()
    assert name == "fake_pkg"


def test_resolve_seed_repo_src_layout(tmp_path: Path) -> None:
    src = tmp_path / "src"
    src.mkdir()
    pkg = _fake_seed_repo(src)
    src_root, name = resolve_seed_repo(tmp_path)
    assert src_root == pkg.resolve()
    assert name == "fake_pkg"


def test_resolve_seed_repo_missing(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="does not exist"):
        resolve_seed_repo(tmp_path / "nonexistent")


def test_resolve_seed_repo_no_package(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="could not resolve"):
        resolve_seed_repo(tmp_path)


def test_resolve_seed_repo_flat_py_modules(tmp_path: Path) -> None:
    repo = _fake_flat_module_repo(tmp_path / "repo")
    src_root, name = resolve_seed_repo(repo)
    assert src_root == repo.resolve()
    assert name == "flat_tool"


def test_resolve_seed_repo_node_package(tmp_path: Path) -> None:
    repo = _fake_node_repo(tmp_path / "repo")
    src_root, name = resolve_seed_repo(repo)
    assert src_root == repo.resolve()
    assert name == "agentic_tools_mcp"


def test_resolve_seed_repo_source_only_polyglot(tmp_path: Path) -> None:
    repo = _fake_source_only_polyglot_repo(tmp_path / "memory-kit")
    src_root, name = resolve_seed_repo(repo)
    assert src_root == repo.resolve()
    assert name == "memory_kit"


def test_create_from_intent_writes_receipt_and_package(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    pkg = _fake_seed_repo(tmp_path / "seed")
    out = tmp_path / "out"

    captured: dict = {}

    def _fake_swarm(*, repos, **kwargs):
        captured["repos"] = repos
        captured["kwargs"] = kwargs
        return _fake_swarm_report()

    monkeypatch.setattr(create_feature, "emergent_swarm", _fake_swarm)

    receipt = create_from_intent(
        "test intent",
        seed_repos=[pkg],
        out_dir=out,
        package="generated_demo",
        top_n=1,
        run_certify=False,
    )

    assert receipt["schema_version"] == SCHEMA_VERSION_CREATE_V1
    assert receipt["intent"] == "test intent"
    assert receipt["package"] == "generated_demo"
    assert receipt["scan_summary"]["candidate_count"] == 1
    assert len(receipt["seed_repos"]) == 1
    assert receipt["seed_repos"][0]["package"] == "fake_pkg"

    # Receipt persisted on disk.
    receipt_path = out / ".atomadic-forge" / "create.json"
    assert receipt_path.is_file()
    on_disk = json.loads(receipt_path.read_text(encoding="utf-8"))
    assert on_disk["schema_version"] == SCHEMA_VERSION_CREATE_V1

    # Scan report persisted at the path the receipt advertises.
    scan_path = Path(receipt["scan_report_path"])
    assert scan_path.is_file()
    assert json.loads(scan_path.read_text(encoding="utf-8"))["candidate_count"] == 1

    # Materialize wrote the package skeleton.
    pyproject = out / "pyproject.toml"
    assert pyproject.is_file()
    feature_dir = out / "src" / "generated_demo" / "a3_og_features"
    assert feature_dir.is_dir()
    feature_files = [p for p in feature_dir.glob("*_emergent.py")]
    assert len(feature_files) == 1

    # emergent_swarm was called with resolved seeds.
    assert captured["repos"] == [(pkg.resolve(), "fake_pkg")]


def test_create_from_intent_hydrates_remote_seed(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    pkg = _fake_seed_repo(tmp_path / "hydrated")
    out = tmp_path / "out"

    def _fake_hydrate(seeds, *, cache_root, runner=None):
        assert seeds == ["https://github.com/org/repo.git"]
        assert cache_root == out.resolve() / ".atomadic-forge" / "seed_repos"
        return [pkg], [{
            "original": "https://github.com/org/repo.git",
            "path": str(pkg),
            "remote_url": "https://github.com/org/repo.git",
            "status": "cloned",
        }]

    def _fake_swarm(*, repos, **kwargs):
        return _fake_swarm_report()

    monkeypatch.setattr(create_feature, "hydrate_seed_repos", _fake_hydrate)
    monkeypatch.setattr(create_feature, "emergent_swarm", _fake_swarm)

    receipt = create_from_intent(
        "remote seed",
        seed_repos=["https://github.com/org/repo.git"],
        out_dir=out,
        package="generated_demo",
        top_n=1,
        run_certify=False,
    )

    assert receipt["seed_hydration"][0]["status"] == "cloned"
    assert receipt["seed_repos"][0]["package"] == "fake_pkg"


def test_create_from_intent_passes_seed_import_roots(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    _fake_seed_repo(tmp_path / "seed" / "src")
    out = tmp_path / "out"
    captured: dict = {}

    def _fake_swarm(*, repos, **kwargs):
        return _fake_swarm_report()

    def _fake_materialize(*args, **kwargs):
        captured["test_extra_src_roots"] = kwargs["test_extra_src_roots"]
        return {
            "schema_version": "atomadic-forge.materialize/v1",
            "generated_at_utc": "2026-05-06T00:00:00Z",
            "out_dir": str(out),
            "package": "generated_demo",
            "candidates_selected": [],
            "files_written": [],
            "certify_score": None,
            "certify_grade": None,
            "wire_violations": 0,
            "summary_line": "ok",
        }

    monkeypatch.setattr(create_feature, "emergent_swarm", _fake_swarm)
    monkeypatch.setattr(create_feature, "materialize_from_report_path", _fake_materialize)

    create_from_intent(
        "seed imports",
        seed_repos=[tmp_path / "seed"],
        out_dir=out,
        package="generated_demo",
        top_n=1,
        run_certify=False,
    )

    assert captured["test_extra_src_roots"] == [str((tmp_path / "seed" / "src").resolve())]


def test_create_from_intent_passes_relative_cached_seed_roots(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    out = tmp_path / "out"
    cached = _fake_seed_repo(out / ".atomadic-forge" / "seed_repos" / "repo" / "src")
    captured: dict = {}

    def _fake_hydrate(seeds, *, cache_root, runner=None):
        return [cached.parent.parent], [{
            "original": "https://github.com/org/repo.git",
            "path": str(cached.parent.parent),
            "remote_url": "https://github.com/org/repo.git",
            "status": "cloned",
        }]

    def _fake_swarm(*, repos, **kwargs):
        return _fake_swarm_report()

    def _fake_materialize(*args, **kwargs):
        captured["test_extra_src_roots"] = kwargs["test_extra_src_roots"]
        return {
            "schema_version": "atomadic-forge.materialize/v1",
            "generated_at_utc": "2026-05-06T00:00:00Z",
            "out_dir": str(out),
            "package": "generated_demo",
            "candidates_selected": [],
            "files_written": [],
            "certify_score": None,
            "certify_grade": None,
            "wire_violations": 0,
            "summary_line": "ok",
        }

    monkeypatch.setattr(create_feature, "hydrate_seed_repos", _fake_hydrate)
    monkeypatch.setattr(create_feature, "emergent_swarm", _fake_swarm)
    monkeypatch.setattr(create_feature, "materialize_from_report_path", _fake_materialize)

    create_from_intent(
        "relative cache",
        seed_repos=["https://github.com/org/repo.git"],
        out_dir=out,
        package="generated_demo",
        top_n=1,
        run_certify=False,
    )

    assert captured["test_extra_src_roots"] == [
        ".atomadic-forge/seed_repos/repo/src",
    ]


def test_create_from_intent_rejects_invalid_package(tmp_path: Path) -> None:
    pkg = _fake_seed_repo(tmp_path / "seed")
    with pytest.raises(ValueError, match="valid Python identifier"):
        create_from_intent(
            "x",
            seed_repos=[pkg],
            out_dir=tmp_path / "out",
            package="not-an-identifier",
            top_n=1,
            run_certify=False,
        )


def test_create_from_intent_requires_seed(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="at least one seed"):
        create_from_intent(
            "x",
            seed_repos=[],
            out_dir=tmp_path / "out",
            package="ok_pkg",
            top_n=1,
            run_certify=False,
        )
