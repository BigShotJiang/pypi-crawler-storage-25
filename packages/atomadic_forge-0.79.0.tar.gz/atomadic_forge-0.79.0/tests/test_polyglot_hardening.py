"""Polyglot hardening — adversarial edge cases + idiomatic real-world fixtures.

Covers what the smoke tests don't:

  * Malformed source (broken braces, unclosed strings, half-written code) —
    the parser must not crash; an empty surface is the contract.
  * Empty / whitespace / comments-only files.
  * Generic / parametric type signatures (Rust ``fn foo<T: Clone>``,
    Kotlin ``fun <T> id(x: T): T``).
  * Inheritance, traits, protocols, conformances, extensions.
  * Async / suspend functions.
  * Mixed-language repos (Python + Rust + Go + Swift + Kotlin all in one).
  * Real-world idiomatic fixtures that mirror what production code looks
    like (Cargo lib crate, Go module with multiple packages, SwiftPM
    target, Gradle project).
  * Wire violations across languages in the same fixture.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from atomadic_forge.a1_at_functions.polyglot_classify import (
    classify_native_tier,
    detect_native_effects,
)
from atomadic_forge.a1_at_functions.polyglot_imports import (
    parse_go_imports,
    parse_kotlin_imports,
    parse_rust_imports,
    parse_swift_imports,
)
from atomadic_forge.a1_at_functions.polyglot_surface import (
    NativeSurface,
    parse_go_surface,
    parse_kotlin_surface,
    parse_rust_surface,
    parse_swift_surface,
)
from atomadic_forge.a1_at_functions.scout_walk import harvest_repo
from atomadic_forge.a1_at_functions.wire_check import scan_violations

# ────────────────────────────────────────────────────────────────────
# Adversarial: malformed source must not crash any parser
# ────────────────────────────────────────────────────────────────────


@pytest.mark.parametrize(
    "parser,name",
    [
        (parse_rust_surface, "rust"),
        (parse_go_surface, "go"),
        (parse_swift_surface, "swift"),
        (parse_kotlin_surface, "kotlin"),
    ],
)
def test_parser_handles_empty_source(parser, name):
    s = parser("")
    assert isinstance(s, NativeSurface)
    assert s.pub_functions == []
    assert s.pub_classes == []


@pytest.mark.parametrize(
    "parser",
    [parse_rust_surface, parse_go_surface, parse_swift_surface, parse_kotlin_surface],
)
def test_parser_handles_whitespace_only(parser):
    s = parser("   \n\n  \t\n")
    assert isinstance(s, NativeSurface)
    assert s.statement_count == 0


@pytest.mark.parametrize(
    "parser",
    [parse_rust_surface, parse_go_surface, parse_swift_surface, parse_kotlin_surface],
)
def test_parser_handles_comments_only(parser):
    src = "// just a comment\n/* and a block */\n// nothing else here\n"
    s = parser(src)
    assert s.pub_functions == []
    assert s.pub_classes == []


@pytest.mark.parametrize(
    "parser,broken",
    [
        (parse_rust_surface, "pub fn add(a: u8, b: u8 -> u8 { a + b\n"),  # missing )
        (parse_rust_surface, "pub struct User { name: String\n"),  # unclosed brace
        (parse_go_surface, "package x\nfunc Bad("),  # truncated
        (parse_go_surface, 'package x\nimport "broken'),  # unterminated string
        (parse_swift_surface, "public class Service {\n    public func run("),  # truncated
        (parse_kotlin_surface, "class Foo {\nfun bar("),  # truncated
        (parse_kotlin_surface, 'val s = "unterminated'),  # bad string
    ],
)
def test_parser_resilient_to_malformed_source(parser, broken):
    """The parser must NEVER raise on malformed input — empty or partial
    surface is the contract."""
    s = parser(broken)
    assert isinstance(s, NativeSurface)
    # Parsers may extract whatever they could before the break; the only
    # hard requirement is the call doesn't throw.


@pytest.mark.parametrize(
    "import_parser,broken",
    [
        (parse_rust_imports, "use crate::"),  # truncated path
        (parse_rust_imports, "/*\nuse crate::a1_at_functions::x"),  # unterminated comment
        (parse_go_imports, 'import "'),  # unterminated string
        (parse_swift_imports, "import"),  # bare keyword
        (parse_kotlin_imports, "import com."),  # truncated FQN
    ],
)
def test_import_parser_resilient(import_parser, broken):
    out = import_parser(broken)
    assert isinstance(out, list)


# ────────────────────────────────────────────────────────────────────
# Generics / type parameters
# ────────────────────────────────────────────────────────────────────


def test_rust_generic_function_extracted():
    src = "pub fn id<T: Clone + Send>(x: T) -> T { x }\n"
    assert "id" in parse_rust_surface(src).pub_functions


def test_rust_generic_struct_with_lifetimes():
    src = "pub struct Holder<'a, T: 'a> { val: &'a T }\n"
    assert "Holder" in parse_rust_surface(src).pub_classes


def test_go_generic_function_extracted():
    src = "package x\nfunc Identity[T any](x T) T { return x }\n"
    assert "Identity" in parse_go_surface(src).pub_functions


def test_swift_generic_function():
    src = "public func identity<T>(_ x: T) -> T { return x }\n"
    assert "identity" in parse_swift_surface(src).pub_functions


def test_kotlin_generic_function():
    src = "fun <T> identity(x: T): T = x\n"
    assert "identity" in parse_kotlin_surface(src).pub_functions


# ────────────────────────────────────────────────────────────────────
# Inheritance / traits / protocols / conformance
# ────────────────────────────────────────────────────────────────────


def test_rust_trait_impl_methods_attributed_to_correct_parent():
    src = """
        pub trait Greeter { fn greet(&self) -> String; }
        pub struct English;
        impl Greeter for English {
            fn greet(&self) -> String { String::from("hi") }
        }
        impl English {
            pub fn new() -> Self { English }
        }
    """
    s = parse_rust_surface(src)
    assert "Greeter" in s.pub_classes
    assert "English" in s.pub_classes
    method_pairs = set(s.pub_methods)
    assert ("English", "new") in method_pairs


def test_swift_extension_block_recognised():
    """Swift `extension` blocks expose new methods on existing types.
    The enclosing-type tracker must label methods inside ``extension Foo``
    as belonging to ``Foo``."""
    src = """
        public struct User { public let name: String }

        extension User {
            public func greet() -> String { return "Hi, \\(name)" }
            public func farewell() -> String { return "Bye" }
        }
    """
    s = parse_swift_surface(src)
    method_owners = {p for p, _ in s.pub_methods}
    assert "User" in method_owners


def test_kotlin_class_inheritance_does_not_leak_parent():
    """`class Bar : Foo()` should still emit Bar — the colon separator
    must not break the regex."""
    src = """
        open class Foo
        class Bar : Foo() { fun method() {} }
    """
    s = parse_kotlin_surface(src)
    assert "Bar" in s.pub_classes
    assert "Foo" in s.pub_classes


# ────────────────────────────────────────────────────────────────────
# Async / suspend
# ────────────────────────────────────────────────────────────────────


def test_rust_async_fn_extracted():
    src = "pub async fn fetch_data() -> Result<String, ()> { Ok(String::new()) }\n"
    assert "fetch_data" in parse_rust_surface(src).pub_functions


def test_swift_async_throws_func():
    src = "public func loadAsync() async throws -> String { return \"\" }\n"
    assert "loadAsync" in parse_swift_surface(src).pub_functions


def test_kotlin_suspend_function_extracted():
    src = "suspend fun fetchData(): String { return \"\" }\n"
    assert "fetchData" in parse_kotlin_surface(src).pub_functions


def test_go_method_on_pointer_receiver_extracted():
    src = """
        package x
        type Service struct{}
        func (s *Service) Start() error { return nil }
        func (s Service) Stop() {}
    """
    s = parse_go_surface(src)
    method_pairs = set(s.pub_methods)
    assert ("Service", "Start") in method_pairs
    assert ("Service", "Stop") in method_pairs


# ────────────────────────────────────────────────────────────────────
# Mixed-language repo: full pipeline doesn't lose info
# ────────────────────────────────────────────────────────────────────


def _seven_lang_pkg(root: Path) -> None:
    """Lay down a tier-organised 7-language package."""
    pkg = root / "src" / "polyglot_demo"
    pkg.mkdir(parents=True)
    # Python in canonical layout
    (pkg / "a1_at_functions").mkdir()
    (pkg / "a1_at_functions" / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "a1_at_functions" / "math.py").write_text(
        "def add(a, b): return a + b\n", encoding="utf-8",
    )
    # JS / TS
    (pkg / "a3_og_features").mkdir()
    (pkg / "a3_og_features" / "feature.js").write_text(
        "export function run() {}\n", encoding="utf-8",
    )
    (pkg / "a3_og_features" / "feature.ts").write_text(
        "export function runTs(): void {}\n", encoding="utf-8",
    )
    # Rust
    (pkg / "a2_mo_composites").mkdir()
    (pkg / "a2_mo_composites" / "service.rs").write_text(
        "pub struct Service { pub active: bool }\n"
        "impl Service { pub fn new() -> Self { Self { active: false } } }\n",
        encoding="utf-8",
    )
    # Go
    (pkg / "a4_sy_orchestration").mkdir()
    (pkg / "a4_sy_orchestration" / "main.go").write_text(
        'package main\nimport "os"\nfunc main() { _ = os.Args }\n', encoding="utf-8",
    )
    # Swift
    (pkg / "a3_og_features" / "App.swift").write_text(
        "public class App {\n    public func run() {}\n}\n", encoding="utf-8",
    )
    # Kotlin
    (pkg / "a3_og_features" / "Worker.kt").write_text(
        "package com.demo.a3_og_features\n"
        "class Worker { fun start() {} }\n",
        encoding="utf-8",
    )


def test_seven_language_pkg_full_harvest(tmp_path):
    _seven_lang_pkg(tmp_path)
    report = harvest_repo(tmp_path)
    dist = report["language_distribution"]
    assert dist["python"] >= 1
    assert dist["javascript"] == 1
    assert dist["typescript"] == 1
    assert dist["rust"] == 1
    assert dist["go"] == 1
    assert dist["swift"] == 1
    assert dist["kotlin"] == 1
    # Per-symbol harvesting works across all languages.  Python's AST
    # harvester predates the polyglot lift and doesn't tag the
    # ``language`` field on symbols — those records show up with
    # ``language=None``.  The other six languages must be present.
    languages = {s.get("language") for s in report["symbols"]}
    assert {"javascript", "typescript",
            "rust", "go", "swift", "kotlin"}.issubset(languages)
    # Tier discipline carries across.  Each Rust symbol under
    # a2_mo_composites/ should report that tier.
    for s in report["symbols"]:
        if s.get("language") == "rust":
            assert s["tier_guess"] == "a2_mo_composites"
        if s.get("language") == "go":
            assert s["tier_guess"] == "a4_sy_orchestration"


def test_seven_language_pkg_wire_clean_when_imports_downward_only(tmp_path):
    _seven_lang_pkg(tmp_path)
    report = scan_violations(tmp_path)
    assert report["verdict"] == "PASS"
    assert report["violation_count"] == 0


def test_seven_language_pkg_wire_detects_simultaneous_violations(tmp_path):
    """Inject one upward import per language — wire must catch them all."""
    _seven_lang_pkg(tmp_path)
    pkg = tmp_path / "src" / "polyglot_demo"
    # Python a1 importing a3
    (pkg / "a1_at_functions" / "bad.py").write_text(
        "from polyglot_demo.a3_og_features.feature import run\n",
        encoding="utf-8",
    )
    # Rust a2 importing a3
    (pkg / "a2_mo_composites" / "bad.rs").write_text(
        "use crate::a3_og_features::Whatever;\npub fn x() {}\n",
        encoding="utf-8",
    )
    # JS a1 importing a4 (use a1 dir to ensure violation)
    (pkg / "a1_at_functions" / "bad.js").write_text(
        "import { x } from '../a4_sy_orchestration/main.js';\nexport const y = 1;\n",
        encoding="utf-8",
    )
    report = scan_violations(tmp_path)
    languages = {v["language"] for v in report["violations"]}
    assert "python" in languages
    assert "rust" in languages
    assert "javascript" in languages
    # Each violation carries a registered F-code.
    for v in report["violations"]:
        assert v["f_code"].startswith("F00") and len(v["f_code"]) == 5


# ────────────────────────────────────────────────────────────────────
# Edge: stdlib-only Rust and Go shouldn't classify as a4
# ────────────────────────────────────────────────────────────────────


def test_rust_pure_math_lib_classifies_to_a1():
    """Pure math helpers without I/O should land at a1, not a3."""
    src = (
        "pub fn add(a: u8, b: u8) -> u8 { a + b }\n"
        "pub fn sub(a: u8, b: u8) -> u8 { a - b }\n"
    )
    s = parse_rust_surface(src)
    tier = classify_native_tier(path="lib/math.rs", surface=s)
    assert tier == "a1_at_functions"
    assert detect_native_effects(s) == ["pure"]


def test_go_pure_helpers_classify_to_a1():
    src = (
        "package math\n"
        "func Add(a, b int) int { return a + b }\n"
        "func Sub(a, b int) int { return a - b }\n"
    )
    s = parse_go_surface(src)
    tier = classify_native_tier(path="pkg/math/math.go", surface=s)
    assert tier == "a1_at_functions"


# ────────────────────────────────────────────────────────────────────
# Idiomatic real-world fixture: a small, complete Rust crate
# ────────────────────────────────────────────────────────────────────


def _idiomatic_rust_crate(root: Path) -> None:
    """A small but complete Rust crate that mirrors how Cargo crates
    are actually laid out: lib.rs declaring tier modules, real impl
    blocks, real I/O, real const tables."""
    src_dir = root / "src"
    src_dir.mkdir()
    (src_dir / "lib.rs").write_text(
        "pub mod a0_qk_constants;\n"
        "pub mod a1_at_functions;\n"
        "pub mod a2_mo_composites;\n"
        "pub mod a3_og_features;\n"
        "pub mod a4_sy_orchestration;\n",
        encoding="utf-8",
    )
    for tier in (
        "a0_qk_constants", "a1_at_functions", "a2_mo_composites",
        "a3_og_features", "a4_sy_orchestration",
    ):
        (src_dir / tier).mkdir()
        (src_dir / tier / "mod.rs").write_text(
            f"//! tier {tier}\n", encoding="utf-8",
        )
    (src_dir / "a0_qk_constants" / "limits.rs").write_text(
        "pub const MAX_USERS: u32 = 1000;\npub const MIN_AGE: u8 = 13;\n",
        encoding="utf-8",
    )
    (src_dir / "a1_at_functions" / "math.rs").write_text(
        "pub fn add(a: u32, b: u32) -> u32 { a + b }\n"
        "pub fn double(x: u32) -> u32 { x * 2 }\n",
        encoding="utf-8",
    )
    (src_dir / "a2_mo_composites" / "user.rs").write_text(
        "pub struct User { pub name: String, age: u8 }\n"
        "impl User {\n"
        "    pub fn new(name: String, age: u8) -> Self { Self { name, age } }\n"
        "    pub fn name(&self) -> &str { &self.name }\n"
        "}\n",
        encoding="utf-8",
    )
    (src_dir / "a3_og_features" / "registry.rs").write_text(
        "use crate::a2_mo_composites::user::User;\n"
        "use crate::a1_at_functions::math::double;\n"
        "pub struct Registry { users: Vec<User> }\n"
        "impl Registry {\n"
        "    pub fn new() -> Self { Self { users: Vec::new() } }\n"
        "    pub fn capacity(&self) -> u32 { double(self.users.len() as u32) }\n"
        "}\n",
        encoding="utf-8",
    )
    (src_dir / "a4_sy_orchestration" / "main.rs").write_text(
        "use std::io;\n"
        "use crate::a3_og_features::registry::Registry;\n"
        "pub fn main() -> io::Result<()> {\n"
        "    let _ = Registry::new();\n"
        "    Ok(())\n"
        "}\n",
        encoding="utf-8",
    )
    (root / "Cargo.toml").write_text(
        '[package]\nname = "demo"\nversion = "0.1.0"\nedition = "2021"\n',
        encoding="utf-8",
    )


def test_idiomatic_rust_crate_full_harvest(tmp_path):
    _idiomatic_rust_crate(tmp_path)
    report = harvest_repo(tmp_path)
    rust_symbols = [s for s in report["symbols"] if s.get("language") == "rust"]
    by_kind: dict[str, list[dict]] = {}
    for s in rust_symbols:
        by_kind.setdefault(s["kind"], []).append(s)
    # Module records — one per .rs file we wrote
    assert len(by_kind.get("module", [])) >= 8  # lib.rs + 5 mod.rs + 5 leaf files
    # Per-symbol records
    assert any(s["name"] == "add" for s in by_kind.get("function", []))
    assert any(s["name"] == "User" for s in by_kind.get("class", []))
    assert any(s["name"] == "User.new" for s in by_kind.get("method", []))
    assert any(s["name"] == "MAX_USERS" for s in by_kind.get("const", []))


def test_idiomatic_rust_crate_wire_clean(tmp_path):
    """Verify the example crate's import graph is upward-only."""
    _idiomatic_rust_crate(tmp_path)
    report = scan_violations(tmp_path / "src")
    assert report["verdict"] == "PASS", report["violations"]


def test_idiomatic_rust_crate_caught_violation_when_added(tmp_path):
    """Inject an a1 → a3 use statement and watch wire fire F0042."""
    _idiomatic_rust_crate(tmp_path)
    bad = tmp_path / "src" / "a1_at_functions" / "bad.rs"
    bad.write_text(
        "use crate::a3_og_features::registry::Registry;\n"
        "pub fn nope() -> u32 { 0 }\n",
        encoding="utf-8",
    )
    report = scan_violations(tmp_path / "src")
    assert report["verdict"] == "FAIL"
    f_codes = {v["f_code"] for v in report["violations"] if v["language"] == "rust"}
    assert "F0042" in f_codes
