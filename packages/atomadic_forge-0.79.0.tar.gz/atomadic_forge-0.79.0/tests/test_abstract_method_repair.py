"""Tests for abstract_method_repair — closes the abstract-by-convention gap."""
from __future__ import annotations

from pathlib import Path

from atomadic_forge.a1_at_functions.abstract_method_repair import (
    apply_repairs,
    find_abstract_repairs,
    repair_abstract_by_convention,
)


def _seed(pkg_root: Path) -> None:
    """A package whose Base class uses the abstract-by-convention pattern."""
    pkg_root.mkdir(parents=True, exist_ok=True)
    (pkg_root / "base.py").write_text(
        '"""Abstract base compressor."""\n'
        "\n"
        "class BaseCompressor:\n"
        '    """Abstract base compressor."""\n'
        "\n"
        "    def compress(self, messages):\n"
        "        raise NotImplementedError\n",
        encoding="utf-8",
    )
    (pkg_root / "concrete.py").write_text(
        "\n"
        "class EngramCompressor:\n"
        "    def compress(self, messages):\n"
        '        return ("compressed", 1)\n',
        encoding="utf-8",
    )


def test_finds_abstract_by_convention(tmp_path):
    _seed(tmp_path / "pkg")
    repairs = find_abstract_repairs(tmp_path / "pkg")
    quals = [r.qualname for r in repairs]
    assert quals == ["BaseCompressor.compress"]


def test_skips_when_no_concrete_override_exists(tmp_path):
    """A Base class with no subclass override is genuinely undefined —
    don't auto-decorate; the author hasn't expressed intent yet."""
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / "base.py").write_text(
        "class BaseThing:\n"
        '    """Abstract."""\n'
        "    def run(self):\n"
        "        raise NotImplementedError\n",
        encoding="utf-8",
    )
    repairs = find_abstract_repairs(pkg)
    assert repairs == []


def test_skips_when_already_decorated(tmp_path):
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / "base.py").write_text(
        "from abc import abstractmethod\n"
        "class BaseCompressor:\n"
        '    """Abstract base compressor."""\n'
        "    @abstractmethod\n"
        "    def compress(self, messages):\n"
        "        raise NotImplementedError\n",
        encoding="utf-8",
    )
    (pkg / "concrete.py").write_text(
        "class EngramCompressor:\n"
        "    def compress(self, messages):\n"
        "        return ('x', 1)\n",
        encoding="utf-8",
    )
    repairs = find_abstract_repairs(pkg)
    assert repairs == []


def test_apply_repairs_inserts_decorator_and_import(tmp_path):
    pkg = tmp_path / "pkg"
    _seed(pkg)
    repairs = find_abstract_repairs(pkg)
    summary = apply_repairs(repairs)
    assert summary["files_touched"] == 1
    assert summary["methods_decorated"] == 1

    after = (pkg / "base.py").read_text(encoding="utf-8")
    assert "from abc import abstractmethod" in after
    assert "@abstractmethod\n    def compress" in after


def test_repair_abstract_by_convention_is_idempotent(tmp_path):
    pkg = tmp_path / "pkg"
    _seed(pkg)
    first = repair_abstract_by_convention(pkg)
    second = repair_abstract_by_convention(pkg)
    assert first["methods_decorated"] == 1
    # Second pass: the file is already decorated; planned == 0.
    assert second["repairs_planned"] == 0
    assert second["methods_decorated"] == 0


def test_handles_class_without_base_prefix_but_abstract_docstring(tmp_path):
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / "iface.py").write_text(
        "class Compressor:\n"
        '    """Interface — subclasses must implement compress."""\n'
        "    def compress(self, messages):\n"
        "        raise NotImplementedError\n",
        encoding="utf-8",
    )
    (pkg / "impl.py").write_text(
        "class FastCompressor:\n"
        "    def compress(self, messages):\n"
        "        return ('y', 2)\n",
        encoding="utf-8",
    )
    repairs = find_abstract_repairs(pkg)
    quals = [r.qualname for r in repairs]
    assert quals == ["Compressor.compress"]
