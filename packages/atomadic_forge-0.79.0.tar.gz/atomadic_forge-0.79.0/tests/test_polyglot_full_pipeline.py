"""Full-polyglot pipeline tests — Python, JS, TS, Rust, Go, Swift, Kotlin.

Pins the 2026-05-06 polyglot lift contract: Forge can read every supported
language (recon + wire) and write every supported language (scaffold + emit
plumbing).  Each test is hermetic — uses ``tmp_path`` and never touches
the host repo.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from atomadic_forge.a0_qk_constants.gen_language import (
    ALLOWED_FILE_EXTS,
    EMITS_BUILD_GRADLE,
    EMITS_CARGO_TOML,
    EMITS_GO_MOD,
    EMITS_PACKAGE_SWIFT,
    LANGUAGES,
    MAIN_EXT,
    PKG_ROOT_TEMPLATE,
    normalize_language,
    pkg_root_for,
)
from atomadic_forge.a0_qk_constants.lang_extensions import (
    ALL_SOURCE_EXTS,
    LANG_OF_EXT,
    RUST_EXTS,
    file_class_for_path,
    lang_for_path,
)
from atomadic_forge.a1_at_functions.polyglot_imports import (
    parse_go_imports,
    parse_imports_for_language,
    parse_kotlin_imports,
    parse_rust_imports,
    parse_swift_imports,
)
from atomadic_forge.a1_at_functions.scaffold_polyglot import (
    render_build_gradle_kts,
    render_cargo_toml,
    render_go_mod,
    render_go_tier_file,
    render_kotlin_tier_file,
    render_package_swift,
    render_rust_lib_rs,
    render_rust_tier_mod_rs,
)
from atomadic_forge.a1_at_functions.scout_walk import harvest_repo
from atomadic_forge.a1_at_functions.wire_check import scan_violations
from atomadic_forge.a3_og_features.forge_loop import _scaffold_package

# ────────────────────────────────────────────────────────────────────
# a0 lang_extensions — Rust joins the canonical registry
# ────────────────────────────────────────────────────────────────────


def test_rust_extension_registered():
    assert ".rs" in RUST_EXTS
    assert ".rs" in ALL_SOURCE_EXTS
    assert LANG_OF_EXT[".rs"] == "rust"


def test_rust_path_classified_as_source():
    assert file_class_for_path("src/main.rs") == "source"
    assert lang_for_path("crates/foo/src/lib.rs") == "rust"


# ────────────────────────────────────────────────────────────────────
# a0 gen_language — Language literal expanded to all 7
# ────────────────────────────────────────────────────────────────────


@pytest.mark.parametrize("lang", LANGUAGES)
def test_every_language_has_a_root_template(lang):
    assert lang in PKG_ROOT_TEMPLATE
    assert "{package}" in PKG_ROOT_TEMPLATE[lang] or lang == "rust"


@pytest.mark.parametrize("lang", LANGUAGES)
def test_every_language_has_an_allowed_ext_set(lang):
    exts = ALLOWED_FILE_EXTS[lang]
    assert isinstance(exts, frozenset) and len(exts) >= 2
    assert ".md" in exts


@pytest.mark.parametrize("lang", LANGUAGES)
def test_every_language_has_a_main_extension(lang):
    assert MAIN_EXT[lang].startswith(".")


@pytest.mark.parametrize("alias,canonical", [
    ("py", "python"), ("js", "javascript"), ("node", "javascript"),
    ("ts", "typescript"), ("rs", "rust"), ("rust", "rust"),
    ("golang", "go"), ("go", "go"),
    ("swift", "swift"), ("kt", "kotlin"), ("kotlin", "kotlin"),
])
def test_normalize_language_aliases(alias, canonical):
    assert normalize_language(alias) == canonical


def test_emit_flag_tables_are_disjoint_per_language():
    """Each language enables exactly one of: pyproject, package.json,
    Cargo.toml, go.mod, Package.swift, build.gradle.kts (or none for JS/TS
    which use package.json from the JS scaffolder)."""
    for lang in LANGUAGES:
        flags = [
            EMITS_CARGO_TOML[lang],
            EMITS_GO_MOD[lang],
            EMITS_PACKAGE_SWIFT[lang],
            EMITS_BUILD_GRADLE[lang],
        ]
        # At most one native-language manifest per language.
        assert sum(flags) <= 1, lang


def test_pkg_root_for_rust_is_src_dir():
    # Rust is a special-case: the crate root holds Cargo.toml and the
    # package _root_ Forge tracks is `src/`.
    assert pkg_root_for("rust", "anything") == "src"


# ────────────────────────────────────────────────────────────────────
# a1 polyglot_imports — per-language regex parsers
# ────────────────────────────────────────────────────────────────────


def test_rust_use_and_mod_extracted():
    src = """
        use crate::a3_og_features::Foo;
        use crate::a2_mo_composites::{Bar, Baz};
        pub use crate::a4_sy_orchestration::handler;
        mod a1_at_functions;
        // use commented::out::ignored;
        /* mod also_ignored; */
    """
    out = parse_rust_imports(src)
    assert "crate::a3_og_features::Foo" in out
    assert "crate::a2_mo_composites" in out
    assert "crate::a4_sy_orchestration::handler" in out
    assert "a1_at_functions" in out
    assert "commented::out::ignored" not in out
    assert "also_ignored" not in out


def test_go_single_and_block_imports():
    src = """
        package main

        import "example.com/proj/a1_at_functions"

        import (
            "example.com/proj/a2_mo_composites"
            alias "example.com/proj/a3_og_features"
            // "ignored/comment"
        )
    """
    out = parse_go_imports(src)
    assert "example.com/proj/a1_at_functions" in out
    assert "example.com/proj/a2_mo_composites" in out
    assert "example.com/proj/a3_og_features" in out
    assert "ignored/comment" not in out


def test_swift_imports_strip_qualifiers():
    src = """
        import Foundation
        import struct Foundation.URL
        @testable import a4_sy_orchestration
        import enum a3_og_features.Routes
        // import IgnoredCommented
    """
    out = parse_swift_imports(src)
    assert "Foundation" in out
    assert "Foundation.URL" in out
    assert "a4_sy_orchestration" in out
    assert "a3_og_features.Routes" in out
    assert "IgnoredCommented" not in out


def test_kotlin_imports_and_package_decl():
    src = """
        package com.example.a3_og_features

        import com.example.a1_at_functions.helper
        import com.example.a2_mo_composites.*
        // import com.ignored.X
    """
    out = parse_kotlin_imports(src)
    assert "com.example.a3_og_features" in out  # the package decl
    assert "com.example.a1_at_functions.helper" in out
    assert "com.example.a2_mo_composites.*" in out
    assert "com.ignored.X" not in out


def test_parse_imports_router_dispatches_correctly():
    assert parse_imports_for_language("rust", "use crate::a1_at_functions::x;") \
        == ["crate::a1_at_functions::x"]
    assert parse_imports_for_language("python", "import os") == []


# ────────────────────────────────────────────────────────────────────
# a1 scout_walk — harvest_repo counts Rust files
# ────────────────────────────────────────────────────────────────────


def _polyglot_tree(root: Path) -> None:
    """Lay down a 7-language polyglot fixture under ``root``."""
    # Python under tier dir
    (root / "src" / "pkg" / "a1_at_functions").mkdir(parents=True)
    (root / "src" / "pkg" / "a1_at_functions" / "helpers.py").write_text(
        "def f(): return 1\n", encoding="utf-8",
    )
    # JS, TS
    (root / "web").mkdir()
    (root / "web" / "app.js").write_text("export const x = 1;\n", encoding="utf-8")
    (root / "web" / "app.ts").write_text("export const x: number = 1;\n", encoding="utf-8")
    # Swift
    (root / "ios").mkdir()
    (root / "ios" / "App.swift").write_text("class A {}\n", encoding="utf-8")
    # Kotlin
    (root / "android").mkdir()
    (root / "android" / "Main.kt").write_text("class M {}\n", encoding="utf-8")
    # Go
    (root / "bridge_go").mkdir()
    (root / "bridge_go" / "main.go").write_text("package main\n", encoding="utf-8")
    # Rust
    (root / "rust_crate").mkdir()
    (root / "rust_crate" / "lib.rs").write_text(
        "pub fn f() -> u8 { 1 }\n", encoding="utf-8",
    )


def test_harvest_repo_counts_rust(tmp_path):
    _polyglot_tree(tmp_path)
    report = harvest_repo(tmp_path)
    assert report["rust_file_count"] == 1
    assert report["language_distribution"]["rust"] == 1


def test_harvest_repo_full_seven_lang_distribution(tmp_path):
    _polyglot_tree(tmp_path)
    report = harvest_repo(tmp_path)
    dist = report["language_distribution"]
    assert dist["python"] >= 1
    assert dist["javascript"] == 1
    assert dist["typescript"] == 1
    assert dist["swift"] == 1
    assert dist["kotlin"] == 1
    assert dist["go"] == 1
    assert dist["rust"] == 1


def test_harvest_repo_primary_language_rust_dominates(tmp_path):
    (tmp_path / "src").mkdir()
    for i in range(5):
        (tmp_path / "src" / f"f{i}.rs").write_text(
            "pub fn f() {}\n", encoding="utf-8",
        )
    (tmp_path / "tiny.py").write_text("x = 1\n", encoding="utf-8")
    assert harvest_repo(tmp_path)["primary_language"] == "rust"


# ────────────────────────────────────────────────────────────────────
# a1 wire_check — upward-import detection across all 4 new languages
# ────────────────────────────────────────────────────────────────────


def _native_tier_tree(root: Path, language: str,
                      ext: str, importer_payload: str,
                      target_filename: str = "ok") -> None:
    """Create a violating tier-organised tree.

    ``importer_payload`` is the source of the *importer* file at a1 that
    references something at a3 — should be flagged as a violation.
    """
    (root / "a3_og_features").mkdir()
    (root / "a3_og_features" / f"{target_filename}{ext}").write_text(
        f"// {language} placeholder\n", encoding="utf-8",
    )
    (root / "a1_at_functions").mkdir()
    (root / "a1_at_functions" / f"importer{ext}").write_text(
        importer_payload, encoding="utf-8",
    )


def test_wire_detects_rust_upward_import(tmp_path):
    _native_tier_tree(
        tmp_path, "rust", ".rs",
        importer_payload="use crate::a3_og_features::ok;\n",
    )
    report = scan_violations(tmp_path)
    assert report["verdict"] == "FAIL"
    rust_v = [v for v in report["violations"] if v["language"] == "rust"]
    assert len(rust_v) == 1
    assert rust_v[0]["from_tier"] == "a1_at_functions"
    assert rust_v[0]["to_tier"] == "a3_og_features"
    assert rust_v[0]["f_code"] == "F0042"


def test_wire_detects_go_upward_import(tmp_path):
    _native_tier_tree(
        tmp_path, "go", ".go",
        importer_payload=(
            'package a1_at_functions\n'
            'import "example.com/proj/a3_og_features"\n'
        ),
    )
    report = scan_violations(tmp_path)
    go_v = [v for v in report["violations"] if v["language"] == "go"]
    assert len(go_v) == 1
    assert go_v[0]["from_tier"] == "a1_at_functions"
    assert go_v[0]["to_tier"] == "a3_og_features"


def test_wire_detects_swift_upward_import(tmp_path):
    _native_tier_tree(
        tmp_path, "swift", ".swift",
        importer_payload="import a3_og_features\n",
    )
    report = scan_violations(tmp_path)
    swift_v = [v for v in report["violations"] if v["language"] == "swift"]
    assert len(swift_v) == 1
    assert swift_v[0]["to_tier"] == "a3_og_features"


def test_wire_detects_kotlin_upward_import(tmp_path):
    _native_tier_tree(
        tmp_path, "kotlin", ".kt",
        importer_payload=(
            "package com.example.a1_at_functions\n"
            "import com.example.a3_og_features.Foo\n"
        ),
    )
    report = scan_violations(tmp_path)
    kotlin_v = [v for v in report["violations"] if v["language"] == "kotlin"]
    assert len(kotlin_v) == 1
    assert kotlin_v[0]["from_tier"] == "a1_at_functions"
    assert kotlin_v[0]["to_tier"] == "a3_og_features"


def test_wire_passes_when_imports_are_downward_only(tmp_path):
    """a3 importing a1 is the legal direction; should NOT flag."""
    (tmp_path / "a1_at_functions").mkdir()
    (tmp_path / "a1_at_functions" / "helper.rs").write_text(
        "pub fn f() -> u8 { 1 }\n", encoding="utf-8",
    )
    (tmp_path / "a3_og_features").mkdir()
    (tmp_path / "a3_og_features" / "feature.rs").write_text(
        "use crate::a1_at_functions::f;\n", encoding="utf-8",
    )
    report = scan_violations(tmp_path)
    assert report["verdict"] == "PASS"
    assert report["violation_count"] == 0


# ────────────────────────────────────────────────────────────────────
# a1 scaffold_polyglot — pure renderers
# ────────────────────────────────────────────────────────────────────


def test_render_cargo_toml_basic_shape():
    out = render_cargo_toml(package="my-crate", description="hello")
    assert '[package]' in out
    assert 'name = "my_crate"' in out  # `-` swapped for `_`
    assert 'edition = "2021"' in out
    assert '[lib]' in out
    assert '[dependencies]' in out


def test_render_rust_lib_rs_declares_all_tiers():
    out = render_rust_lib_rs()
    for tier in ("a0_qk_constants", "a1_at_functions", "a2_mo_composites",
                 "a3_og_features", "a4_sy_orchestration"):
        assert f"pub mod {tier};" in out


def test_render_rust_tier_mod_rs_has_doc_header():
    out = render_rust_tier_mod_rs(tier="a1_at_functions")
    assert "a1_at_functions" in out
    assert out.startswith("//!")


def test_render_go_mod_default_module_path():
    out = render_go_mod(package="proj")
    assert "module example.com/proj" in out
    assert "go 1.22" in out


def test_render_go_tier_file_declares_package():
    out = render_go_tier_file(tier="a2_mo_composites")
    assert "package a2_mo_composites" in out


def test_render_package_swift_basic_shape():
    out = render_package_swift(package="proj")
    assert "// swift-tools-version:" in out
    assert 'name: "proj"' in out
    assert 'targets: ["proj"]' in out


def test_render_build_gradle_kts_basic_shape():
    out = render_build_gradle_kts(package="proj")
    assert 'kotlin("jvm")' in out
    assert "mavenCentral()" in out
    assert "jvmToolchain(17)" in out


def test_render_kotlin_tier_file_uses_canonical_package():
    out = render_kotlin_tier_file(package="proj", tier="a3_og_features")
    assert "package com.proj.a3_og_features" in out


# ────────────────────────────────────────────────────────────────────
# a3 forge_loop._scaffold_package — emit shells for every language
# ────────────────────────────────────────────────────────────────────


def test_scaffold_python_shell_unchanged(tmp_path):
    pkg_root = _scaffold_package(tmp_path, "demo", language="python")
    assert (tmp_path / "pyproject.toml").exists()
    assert (pkg_root / "__init__.py").exists()
    assert (pkg_root / "a1_at_functions" / "__init__.py").exists()
    assert (tmp_path / "tests" / "conftest.py").exists()


def test_scaffold_javascript_shell(tmp_path):
    _scaffold_package(tmp_path, "demo", language="javascript")
    assert (tmp_path / "package.json").exists()
    assert (tmp_path / "demo" / "a3_og_features").is_dir()


def test_scaffold_typescript_shell(tmp_path):
    _scaffold_package(tmp_path, "demo", language="typescript")
    assert (tmp_path / "package.json").exists()


def test_scaffold_rust_shell(tmp_path):
    _scaffold_package(tmp_path, "my-crate", language="rust")
    cargo = tmp_path / "Cargo.toml"
    lib_rs = tmp_path / "src" / "lib.rs"
    mod_rs_a1 = tmp_path / "src" / "a1_at_functions" / "mod.rs"
    assert cargo.exists()
    assert "my_crate" in cargo.read_text(encoding="utf-8")
    assert lib_rs.exists()
    assert "pub mod a1_at_functions;" in lib_rs.read_text(encoding="utf-8")
    assert mod_rs_a1.exists()
    # Rust scaffold writes its own .gitignore (Cargo flavour).
    assert "/target" in (tmp_path / ".gitignore").read_text(encoding="utf-8")


def test_scaffold_go_shell(tmp_path):
    _scaffold_package(tmp_path, "proj", language="go")
    assert (tmp_path / "go.mod").exists()
    tier_go = tmp_path / "proj" / "a1_at_functions" / "a1_at_functions.go"
    assert tier_go.exists()
    assert "package a1_at_functions" in tier_go.read_text(encoding="utf-8")


def test_scaffold_swift_shell(tmp_path):
    _scaffold_package(tmp_path, "Demo", language="swift")
    assert (tmp_path / "Package.swift").exists()
    assert (tmp_path / "Sources" / "Demo" / "a3_og_features").is_dir()
    placeholder = (tmp_path / "Sources" / "Demo" / "a1_at_functions"
                   / "a1_at_functions.swift")
    assert placeholder.exists()


def test_scaffold_kotlin_shell(tmp_path):
    _scaffold_package(tmp_path, "demo", language="kotlin")
    assert (tmp_path / "build.gradle.kts").exists()
    assert (tmp_path / "settings.gradle.kts").exists()
    tier_kt = (tmp_path / "src" / "main" / "kotlin" / "demo"
               / "a3_og_features" / "a3_og_features.kt")
    assert tier_kt.exists()
    assert "package com.demo.a3_og_features" in tier_kt.read_text(encoding="utf-8")
