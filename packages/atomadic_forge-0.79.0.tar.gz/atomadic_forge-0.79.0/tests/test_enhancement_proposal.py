"""Tests for the v0.14.0a11 enhancement-proposal stack.

Covers the pure builder, the a3 orchestrator (with both OFFLINE and
trust-gate-supplied paths), and the MCP dispatcher wiring.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from atomadic_forge.a0_qk_constants.enhancement_proposal_constants import (
    SCHEMA_VERSION_ENHANCEMENT_PROPOSAL_V1,
    TRUST_VERDICT_FAIL,
    TRUST_VERDICT_OFFLINE,
    TRUST_VERDICT_PASS,
)
from atomadic_forge.a1_at_functions.enhancement_proposal_builder import (
    make_proposal,
)
from atomadic_forge.a3_og_features.enhancement_proposal_feature import (
    list_proposals,
    read_proposal,
    submit_proposal,
)

# ---- builder -----------------------------------------------------------


def test_make_proposal_minimum_fields() -> None:
    p = make_proposal(title="X", description="Y")
    assert p["schema_version"] == SCHEMA_VERSION_ENHANCEMENT_PROPOSAL_V1
    assert p["proposal_id"].startswith("FEP-")
    assert p["title"] == "X"
    assert p["description"] == "Y"
    assert p["evidence"] == []
    assert p["trust_verdict"] == TRUST_VERDICT_OFFLINE
    assert p["trust_score"] is None
    assert p["publishable"] is False
    assert p["approved"] is False


def test_make_proposal_publishable_when_pass_above_threshold() -> None:
    p = make_proposal(
        title="X", description="Y",
        trust_verdict=TRUST_VERDICT_PASS, trust_score=0.9,
        trust_threshold=0.75,
    )
    assert p["publishable"] is True


def test_make_proposal_not_publishable_when_pass_below_threshold() -> None:
    p = make_proposal(
        title="X", description="Y",
        trust_verdict=TRUST_VERDICT_PASS, trust_score=0.5,
        trust_threshold=0.75,
    )
    assert p["publishable"] is False


def test_make_proposal_not_publishable_on_fail() -> None:
    p = make_proposal(
        title="X", description="Y",
        trust_verdict=TRUST_VERDICT_FAIL, trust_score=0.95,
    )
    assert p["publishable"] is False


def test_make_proposal_not_publishable_on_offline_even_with_score() -> None:
    p = make_proposal(
        title="X", description="Y",
        trust_verdict=TRUST_VERDICT_OFFLINE, trust_score=0.99,
    )
    assert p["publishable"] is False


def test_make_proposal_rejects_empty_title() -> None:
    with pytest.raises(ValueError, match="title"):
        make_proposal(title="", description="Y")


def test_make_proposal_rejects_empty_description() -> None:
    with pytest.raises(ValueError, match="description"):
        make_proposal(title="X", description="")


def test_make_proposal_rejects_bad_verdict() -> None:
    with pytest.raises(ValueError, match="trust_verdict"):
        make_proposal(title="X", description="Y", trust_verdict="MAYBE")


def test_make_proposal_rejects_out_of_range_score() -> None:
    with pytest.raises(ValueError, match="trust_score"):
        make_proposal(title="X", description="Y",
                       trust_verdict=TRUST_VERDICT_PASS, trust_score=1.5)


def test_make_proposal_normalizes_evidence() -> None:
    p = make_proposal(title="X", description="Y",
                        evidence=["  foo.py:10  ", "", "bar.py:20"])
    assert p["evidence"] == ["foo.py:10", "bar.py:20"]


# ---- a3 orchestrator: offline path -------------------------------------


def test_submit_proposal_offline_default(tmp_path: Path) -> None:
    out = submit_proposal(
        project_root=tmp_path,
        title="forge stub_detector",
        description="Detect placeholder bodies (pass / NotImplementedError) "
                     "and surface them in certify.",
    )
    assert out["submitted"] is True
    p = out["proposal"]
    assert p["trust_verdict"] == TRUST_VERDICT_OFFLINE
    assert p["publishable"] is False
    proposal_path = Path(out["proposal_file"])
    assert proposal_path.is_file()
    on_disk = json.loads(proposal_path.read_text(encoding="utf-8"))
    assert on_disk == p


def test_submit_proposal_appends_to_log_jsonl(tmp_path: Path) -> None:
    submit_proposal(
        project_root=tmp_path,
        title="A", description="first proposal",
    )
    submit_proposal(
        project_root=tmp_path,
        title="B", description="second proposal",
    )
    log = list_proposals(project_root=tmp_path)
    assert log["total_count"] == 2
    titles = [e["title"] for e in log["entries"]]
    assert "A" in titles
    assert "B" in titles


# ---- a3 orchestrator: trust-gate path ----------------------------------


def test_submit_proposal_with_passing_gate_above_threshold(tmp_path: Path) -> None:
    def gate(payload: dict) -> dict:
        return {"verdict": TRUST_VERDICT_PASS, "trust_score": 0.92,
                "reason": "looks legit"}
    out = submit_proposal(
        project_root=tmp_path,
        title="A", description="B",
        trust_threshold=0.75,
        trust_gate=gate,
    )
    p = out["proposal"]
    assert p["trust_verdict"] == TRUST_VERDICT_PASS
    assert p["trust_score"] == pytest.approx(0.92)
    assert p["publishable"] is True
    assert p["approved"] is False  # publish stays human-gated
    assert "looks legit" in p["trust_reason"]


def test_submit_proposal_with_failing_gate(tmp_path: Path) -> None:
    def gate(payload: dict) -> dict:
        return {"verdict": TRUST_VERDICT_FAIL, "trust_score": 0.10,
                "reason": "duplicates existing tool"}
    out = submit_proposal(
        project_root=tmp_path,
        title="A", description="B",
        trust_gate=gate,
    )
    p = out["proposal"]
    assert p["trust_verdict"] == TRUST_VERDICT_FAIL
    assert p["publishable"] is False


def test_submit_proposal_gate_exception_degrades_to_offline(tmp_path: Path) -> None:
    def gate(payload: dict) -> dict:
        raise RuntimeError("nexus unreachable")
    out = submit_proposal(
        project_root=tmp_path,
        title="A", description="B",
        trust_gate=gate,
    )
    p = out["proposal"]
    assert p["trust_verdict"] == TRUST_VERDICT_OFFLINE
    assert p["publishable"] is False
    assert "nexus unreachable" in p["trust_reason"]


def test_submit_proposal_gate_garbage_score_dropped_to_none(tmp_path: Path) -> None:
    def gate(payload: dict) -> dict:
        return {"verdict": TRUST_VERDICT_PASS, "trust_score": "not a number"}
    out = submit_proposal(
        project_root=tmp_path,
        title="A", description="B",
        trust_gate=gate,
    )
    assert out["proposal"]["trust_score"] is None
    assert out["proposal"]["publishable"] is False


# ---- read_proposal / list_proposals ------------------------------------


def test_read_proposal_round_trip(tmp_path: Path) -> None:
    out = submit_proposal(project_root=tmp_path, title="A", description="B")
    fetched = read_proposal(
        project_root=tmp_path,
        proposal_id=out["proposal"]["proposal_id"],
    )
    assert fetched == out["proposal"]


def test_read_proposal_missing_returns_none(tmp_path: Path) -> None:
    assert read_proposal(project_root=tmp_path, proposal_id="FEP-noexist") is None


def test_list_proposals_empty(tmp_path: Path) -> None:
    out = list_proposals(project_root=tmp_path)
    assert out["total_count"] == 0
    assert out["entries"] == []


def test_list_proposals_skips_malformed_lines(tmp_path: Path) -> None:
    # Pre-seed a malformed log line.
    log_dir = tmp_path / ".atomadic-forge" / "enhancement_proposals"
    log_dir.mkdir(parents=True)
    log = log_dir / "forge_enhancement_proposals.jsonl"
    log.write_text("{not json}\n", encoding="utf-8")
    submit_proposal(project_root=tmp_path, title="A", description="B")
    out = list_proposals(project_root=tmp_path)
    assert out["total_count"] == 1
    assert out["skipped_lines"] == [1]


# ---- MCP dispatcher wiring --------------------------------------------


def _decode_mcp_result(response: dict) -> dict:
    result = response["result"]
    if "structuredContent" in result and result["structuredContent"]:
        return result["structuredContent"]
    return json.loads(result["content"][0]["text"])


def test_mcp_enhancement_propose_dispatches(tmp_path: Path) -> None:
    import atomadic_forge.a3_og_features.mcp_server  # noqa: F401  — wire
    from atomadic_forge.a1_at_functions.mcp_protocol import dispatch_request

    response = dispatch_request(
        {
            "jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {
                "name": "hive",
                "arguments": {
                    "action": "enhance_propose",
                    "title": "forge stub_detector",
                    "description": "Detect stub bodies during certify",
                    "evidence": ["src/foo.py:42"],
                    "project_root": str(tmp_path),
                },
            },
        },
        project_root=tmp_path,
    )
    assert response is not None
    assert "error" not in response, response
    body = _decode_mcp_result(response)
    assert body["submitted"] is True
    assert body["proposal"]["title"] == "forge stub_detector"
    assert body["proposal"]["trust_verdict"] == TRUST_VERDICT_OFFLINE


def test_mcp_enhancement_list_dispatches(tmp_path: Path) -> None:
    import atomadic_forge.a3_og_features.mcp_server  # noqa: F401
    from atomadic_forge.a1_at_functions.mcp_protocol import dispatch_request

    submit_proposal(project_root=tmp_path, title="A", description="B")

    response = dispatch_request(
        {
            "jsonrpc": "2.0", "id": 2, "method": "tools/call",
            "params": {
                "name": "hive",
                "arguments": {"action": "enhance_list", "project_root": str(tmp_path)},
            },
        },
        project_root=tmp_path,
    )
    assert response is not None
    body = _decode_mcp_result(response)
    assert body["total_count"] == 1


def test_mcp_tools_list_includes_enhancement() -> None:
    import atomadic_forge.a3_og_features.mcp_server  # noqa: F401
    from atomadic_forge.a1_at_functions.mcp_protocol import dispatch_request

    response = dispatch_request(
        {"jsonrpc": "2.0", "id": 3, "method": "tools/list"},
        project_root=Path("."),
    )
    names = {t["name"] for t in response["result"]["tools"]}
    assert "hive" in names
