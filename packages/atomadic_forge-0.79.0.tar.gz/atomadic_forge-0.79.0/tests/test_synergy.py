"""Test synergy surface extractor + detector + per-kind renderer."""
from __future__ import annotations

import ast

from atomadic_forge.a0_qk_constants.synergy_types import (
    FeatureSurfaceCard,
    SynergyCandidateCard,
)
from atomadic_forge.a1_at_functions.synergy_detect import detect_synergies
from atomadic_forge.a1_at_functions.synergy_render import render_synergy_adapter
from atomadic_forge.a1_at_functions.synergy_surface_extract import (
    harvest_feature_surfaces,
)


def _card(**overrides) -> FeatureSurfaceCard:
    name = overrides.get("name", "x")
    base: FeatureSurfaceCard = FeatureSurfaceCard(
        name=name,
        # Default module to name-derived path so distinct cards in the same
        # test live in distinct modules (synergy_detect skips same-module
        # pairs as colocation, not synergy).
        module=overrides.get("module", f"pkg.{name}"),
        help_text=overrides.get("help_text", ""),
        inputs=overrides.get("inputs", []),
        input_files=overrides.get("input_files", []),
        outputs=overrides.get("outputs", []),
        output_files=overrides.get("output_files", []),
        schemas=overrides.get("schemas", []),
        vocabulary=overrides.get("vocabulary", []),
        phase_hint=overrides.get("phase_hint", "misc"),
    )
    return base


def test_json_artifact_synergy_detected():
    producer = _card(name="scout",
                     outputs=["json-out", "save"],
                     output_files=["scout.json"],
                     phase_hint="recon")
    consumer = _card(name="emergent",
                     inputs=["report-path"],
                     input_files=["report.json"],
                     phase_hint="ingest")
    cands = detect_synergies([producer, consumer])
    kinds = {c["kind"] for c in cands}
    assert "json_artifact" in kinds


def test_json_artifact_rejects_generic_project_paths():
    producer = _card(name="surface",
                     outputs=["out"],
                     output_files=["out"],
                     phase_hint="emit")
    consumer = _card(name="hive",
                     inputs=["project-root"],
                     input_files=["project-root"],
                     phase_hint="register")
    cands = detect_synergies([producer, consumer])
    assert not any(c["kind"] == "json_artifact" for c in cands)


def test_shared_schema_synergy():
    producer = _card(name="cherry", schemas=["atomadic-forge.cherry/v1"])
    consumer = _card(name="register", schemas=["atomadic-forge.cherry/v1"])
    cands = detect_synergies([producer, consumer])
    assert any(c["kind"] == "shared_schema" for c in cands)


def test_phase_omission_synergy():
    producer = _card(name="ingest", phase_hint="ingest", vocabulary=["foo"])
    consumer = _card(name="plan", phase_hint="plan", vocabulary=["bar"])
    cands = detect_synergies([producer, consumer])
    assert any(c["kind"] == "phase_omission" for c in cands)


def test_each_renderer_emits_valid_python():
    """Per-kind templates must produce parseable Python."""
    base = SynergyCandidateCard(
        candidate_id="syn-test", producer="alpha", consumer="beta",
        kind="json_artifact", why=["test"],
        score=80.0, score_breakdown={"x": 80},
        proposed_adapter_name="alpha-then-beta",
        proposed_summary="run alpha then beta",
    )
    for kind in ("json_artifact", "in_memory_pipe", "phase_omission",
                 "shared_schema", "shared_vocabulary"):
        card = dict(base)
        card["kind"] = kind  # type: ignore[typeddict-item]
        src = render_synergy_adapter(card)  # type: ignore[arg-type]
        ast.parse(src)  # raises SyntaxError on regression — caught the v1 unclosed-bracket bug
        if kind != "in_memory_pipe":
            assert "atomadic_forge.a4_sy_orchestration.cli" in src
        assert "unified_cli" not in src


def test_json_bool_option_is_not_artifact_output(tmp_path):
    """A stdout JSON switch must not masquerade as a file handoff."""
    commands = tmp_path / "pkg" / "commands"
    commands.mkdir(parents=True)
    (commands / "report.py").write_text(
        '''"""Report command."""\n'''
        "from __future__ import annotations\n\n"
        "from pathlib import Path\n"
        "from typing import Annotated\n\n"
        "import typer\n\n"
        "app = typer.Typer()\n\n"
        "@app.command('run')\n"
        "def run(\n"
        "    project: Annotated[Path, typer.Argument()],\n"
        "    json_out: Annotated[bool, typer.Option('--json')] = False,\n"
        "    save: Annotated[Path | None, typer.Option('--save')] = None,\n"
        ") -> None:\n"
        "    \"\"\"Inspect project and optionally save report.json.\"\"\"\n"
        "    return None\n",
        encoding="utf-8",
    )

    cards = harvest_feature_surfaces(tmp_path, "pkg")
    card = next(c for c in cards if c["name"] == "report")
    assert "json-out" not in card["outputs"]
    assert "save" in card["outputs"]
    assert "project" in card["input_files"]
    assert "save" in card["output_files"]
