"""Regression tests for smell_score's density-based formula.

Pre-fix formula: ``100 - (2*cc + long + 3*dup_groups)`` floored at 0.
On any moderately-sized Python tree the penalty exceeded 100 almost
immediately, so the headline number was always 0.0 — useless.

Post-fix formula: density-based.
  weighted = 2*cc + 1*long + 3*dup_groups
  denom    = max(50, function_count)
  density  = weighted / denom
  score    = clamp(0, 100, 100 - density * 50)
And ``smell_score_components`` exposes every term so the score is
defensible.
"""
from __future__ import annotations

from pathlib import Path

from atomadic_forge.a1_at_functions.smell_scan import smell_scan


def _make_pkg(tmp_path: Path, body: str) -> Path:
    """Write a single .py file at tmp_path/pkg/m.py and return tmp_path."""
    (tmp_path / "pkg").mkdir()
    (tmp_path / "pkg" / "m.py").write_text(body, encoding="utf-8")
    return tmp_path


def test_smell_score_clean_tree_is_100(tmp_path: Path):
    body = "\n".join(
        f"def f{i}(): return {i}"
        for i in range(20)
    ) + "\n"
    _make_pkg(tmp_path, body)
    r = smell_scan(tmp_path, package_subdir="pkg")
    assert r.complexity_findings == []
    assert r.long_function_findings == []
    assert r.duplication_findings == []
    assert r.smell_score == 100.0, r.smell_score_components


def test_smell_score_components_exposed(tmp_path: Path):
    _make_pkg(tmp_path, "def f(): return 1\n")
    r = smell_scan(tmp_path, package_subdir="pkg")
    c = r.smell_score_components
    assert "weighted_findings" in c
    assert "function_count" in c
    assert "denom" in c
    assert "density" in c
    assert "formula" in c
    assert c["weights"] == {"cc": 2, "long": 1, "dup_group": 3}


def test_smell_score_is_not_floored_at_zero_for_real_codebases(tmp_path: Path):
    """Regression: pre-fix repos with hundreds of findings reported 0.0.

    Build a synthetic repo with several long functions and confirm the
    score stays in a meaningful 30..95 band, not 0.
    """
    long_body = "\n".join("    pass" for _ in range(60))
    body = "\n\n".join(
        f"def long_fn_{i}():\n{long_body}"
        for i in range(15)
    ) + "\n" + "\n\n".join(
        f"def short_fn_{i}(): return {i}"
        for i in range(40)
    )
    _make_pkg(tmp_path, body)
    r = smell_scan(tmp_path, package_subdir="pkg")
    # 15 long findings, 0 cc, 0 dup. function_count=55.
    assert len(r.long_function_findings) == 15
    # weighted = 15. denom = max(50, 55) = 55. density ≈ 0.273.
    # score = 100 - 0.273*50 ≈ 86.4 — meaningful, NOT 0.0.
    assert 80.0 <= r.smell_score <= 95.0, r.smell_score_components


def test_smell_score_clamps_to_zero_for_extreme_density():
    """The score never goes negative even when density >> 2.

    Direct unit test on the formula by constructing a tiny "repo" with
    enough findings to push density above 2.0.
    """
    # weighted=200, denom=50 (floor) → density=4.0 → 100-200 = -100 → clamp 0
    weighted = 200
    denom = 50
    density = weighted / denom
    score = max(0.0, min(100.0, 100.0 - density * 50.0))
    assert score == 0.0


def test_smell_score_clamps_to_hundred_for_zero_findings():
    weighted = 0
    denom = 50
    density = weighted / denom if denom else 0.0
    score = max(0.0, min(100.0, 100.0 - density * 50.0))
    assert score == 100.0
