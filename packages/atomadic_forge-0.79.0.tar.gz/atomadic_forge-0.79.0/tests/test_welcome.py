"""Tests for v0.14.0a12 forge welcome — first-call handshake."""
from __future__ import annotations

import json
from pathlib import Path

from atomadic_forge.a0_qk_constants.welcome_constants import (
    SCHEMA_VERSION_WELCOME_V1,
    TOP_N_PRIORITIES,
    TOP_N_STRENGTHS,
)
from atomadic_forge.a1_at_functions.welcome_narrator import (
    build_agent_guidance,
    build_capability_showcase,
    build_narrative,
    detect_priorities,
    detect_strengths,
    health_label_for,
    safety_net_summary,
    suggest_next_call,
)
from atomadic_forge.a3_og_features.welcome_feature import welcome

# ---------- health label ------------------------------------------------


def test_health_label_thresholds() -> None:
    assert health_label_for(100) == "production-ready"
    assert health_label_for(95) == "production-ready"
    assert health_label_for(90) == "ship-ready"
    assert health_label_for(80) == "improving"
    assert health_label_for(60) == "needs work"
    assert health_label_for(10) == "early"
    assert health_label_for(None) == "unknown"


# ---------- detect_strengths -------------------------------------------


def test_detect_strengths_clean_repo_lists_all_three() -> None:
    s = detect_strengths(
        scout={
            "symbol_count": 100,
            "tier_distribution": {"a1_at_functions": 80, "a2_mo_composites": 20},
            "effect_distribution": {"pure": 90, "io": 10, "state": 0},
        },
        certify={"score": 100, "ci_workflow_present": True, "changelog_present": True},
        wire={"verdict": "PASS", "violation_count": 0},
    )
    assert len(s) == TOP_N_STRENGTHS
    # All strengths should be substantive (each > 30 chars).
    for line in s:
        assert len(line) > 30


def test_detect_strengths_failing_repo_returns_few_or_none() -> None:
    s = detect_strengths(
        scout={"symbol_count": 5, "tier_distribution": {"a4_sy_orchestration": 5},
                "effect_distribution": {"io": 5}},
        certify={"score": 30, "ci_workflow_present": False, "changelog_present": False},
        wire={"verdict": "FAIL", "violation_count": 3},
    )
    assert len(s) <= TOP_N_STRENGTHS  # may be 0


def test_detect_strengths_handles_missing_inputs() -> None:
    s = detect_strengths(scout=None, certify=None, wire=None)
    assert s == []


# ---------- detect_priorities ------------------------------------------


def test_detect_priorities_lists_violations_first() -> None:
    p = detect_priorities(
        scout=None,
        certify={"recommendations": ["Add CI workflow."]},
        wire={
            "violation_count": 1,
            "violations": [{"file": "a1/foo.py", "from_tier": "a1_at_functions",
                            "to_tier": "a3_og_features", "imported": "X"}],
        },
    )
    assert len(p) <= TOP_N_PRIORITIES
    assert p[0]["what"].startswith("Resolve 1 upward-import violation")
    assert "next_call" in p[0]


def test_detect_priorities_falls_through_to_recommendations() -> None:
    p = detect_priorities(
        scout=None,
        certify={"recommendations": ["Add changelog."]},
        wire={"verdict": "PASS", "violation_count": 0},
    )
    assert any("changelog" in entry["what"].lower() for entry in p)


def test_detect_priorities_surfaces_star_imports_when_room() -> None:
    p = detect_priorities(
        scout=None,
        certify={},
        wire={
            "verdict": "PASS",
            "violation_count": 0,
            "star_import_warnings": [{"x": 1}, {"y": 2}],
        },
    )
    assert any("import *" in entry["what"] for entry in p)


def test_detect_priorities_caps_at_top_n() -> None:
    p = detect_priorities(
        scout=None,
        certify={"recommendations": ["a", "b", "c", "d", "e"]},
        wire={"verdict": "PASS", "violation_count": 0},
    )
    assert len(p) <= TOP_N_PRIORITIES


# ---------- suggest_next_call ------------------------------------------


def test_suggest_next_call_violations_route_to_repair() -> None:
    nc = suggest_next_call(certify={"score": 100}, wire={"violation_count": 1})
    assert "wire" in nc
    assert "suggest-repairs" in nc


def test_suggest_next_call_low_score_routes_to_certify() -> None:
    nc = suggest_next_call(certify={"score": 60}, wire={"violation_count": 0})
    assert "certify" in nc


def test_suggest_next_call_high_score_routes_to_emergent() -> None:
    nc = suggest_next_call(certify={"score": 100}, wire={"violation_count": 0})
    assert "emergent" in nc


# ---------- build_narrative --------------------------------------------


def test_build_narrative_includes_repo_score_and_next_call() -> None:
    n = build_narrative(
        repo_name="atomadic-forge",
        scout={"primary_language": "python", "symbol_count": 100,
                "tier_distribution": {"a1_at_functions": 100}},
        certify={"score": 100},
        wire={"verdict": "PASS", "violation_count": 0},
        strengths=["Strong a1."],
        priorities=[{"what": "Try emergent", "why": "discovery", "next_call": "..."}],
        next_call="forge emergent scan --json",
        forge_version="0.14.0",
        tool_count=66,
    )
    assert "atomadic-forge" in n
    assert "100/100" in n
    assert "production-ready" in n
    assert "Strong a1." in n
    assert "Try emergent" in n
    assert "forge emergent scan --json" in n
    assert "good hands" in n


def test_build_narrative_omits_priorities_section_when_empty() -> None:
    n = build_narrative(
        repo_name="X", scout={}, certify={"score": 100},
        wire={"verdict": "PASS", "violation_count": 0},
        strengths=[], priorities=[],
        next_call="x", forge_version="0", tool_count=0,
    )
    assert "What I'm watching" not in n


# ---------- build_agent_guidance ---------------------------------------


def test_agent_guidance_clean_repo_leads_with_score_and_violations() -> None:
    g = build_agent_guidance(
        repo_name="X",
        scout={"primary_language": "python", "symbol_count": 100},
        certify={"score": 100},
        wire={"verdict": "PASS", "violation_count": 0},
        strengths=[], priorities=[],
    )
    assert "100/100" in g["lead"]
    assert "deterministic" in g["lead"].lower()
    assert "voice_contract" in g
    assert g["reassurance_points"]


def test_agent_guidance_failing_repo_does_not_sugar_coat() -> None:
    g = build_agent_guidance(
        repo_name="X",
        scout={"symbol_count": 10}, certify={"score": 40},
        wire={"verdict": "FAIL", "violation_count": 5},
        strengths=[], priorities=[{"what": "fix x", "why": "y", "next_call": "z"}],
    )
    assert "40/100" in g["lead"]
    assert "honest" in g["lead"].lower() or "don't sugar" in g["lead"].lower()


def test_agent_guidance_priority_framing_when_no_priorities() -> None:
    g = build_agent_guidance(
        repo_name="X", scout={}, certify={"score": 100},
        wire={"verdict": "PASS", "violation_count": 0},
        strengths=[], priorities=[],
    )
    assert "emergent" in g["priority_framing"]


# ---------- a3 welcome orchestrator (integration) ----------------------


def test_welcome_runs_end_to_end_on_fixture_repo(tmp_path: Path) -> None:
    """Build a tiny tier-organized fixture and run welcome on it."""
    (tmp_path / "src" / "fixturepkg" / "a1_at_functions").mkdir(parents=True)
    (tmp_path / "src" / "fixturepkg" / "__init__.py").write_text("", encoding="utf-8")
    (tmp_path / "src" / "fixturepkg" / "a1_at_functions" / "__init__.py").write_text("", encoding="utf-8")
    (tmp_path / "src" / "fixturepkg" / "a1_at_functions" / "add.py").write_text(
        '"""Tier a1 — pure addition."""\n'
        "def add(a, b): return a + b\n",
        encoding="utf-8",
    )
    out = welcome(project_root=tmp_path, skip_certify=True)
    assert out["schema_version"] == SCHEMA_VERSION_WELCOME_V1
    assert out["repo_name"] == tmp_path.name
    assert "narrative" in out
    assert "agent_guidance" in out
    assert out["scan"]["scout"]["symbol_count"] >= 1
    assert out["scan"]["wire"]["verdict"] == "PASS"
    assert out["available_tools"] >= 8


def test_welcome_certify_failure_is_reported_not_crashed(tmp_path: Path,
                                                            monkeypatch) -> None:
    """If certify raises, welcome must still return a usable response."""
    from atomadic_forge.a3_og_features import welcome_feature as wf
    def boom(*a, **k):
        raise RuntimeError("simulated certify failure")
    monkeypatch.setattr(wf, "_certify", boom)
    out = welcome(project_root=tmp_path, skip_certify=False)
    assert out["scan"]["certify"]["verdict"] == "ERROR"
    assert "narrative" in out  # still got the rest


def test_welcome_since_receipt_diff(tmp_path: Path) -> None:
    receipt = tmp_path / "prior.json"
    receipt.write_text(json.dumps({"score": 80, "timestamp": "2026-05-01"}),
                        encoding="utf-8")
    out = welcome(project_root=tmp_path, skip_certify=True,
                   since_receipt=receipt)
    assert out["since_last_scan"] is not None
    assert out["since_last_scan"]["prior_score"] == 80


def test_welcome_scope_guard_refuses_oversized_tree(tmp_path: Path) -> None:
    """Synthesise 12 .py files, cap at 5, expect REFUSE without scout."""
    for i in range(12):
        (tmp_path / f"mod_{i}.py").write_text("x = 1\n", encoding="utf-8")
    out = welcome(project_root=tmp_path, max_files=5)
    assert out["verdict"] == "REFUSE"
    assert out["reason"] == "scope_guard"
    assert out["scope_guard_max_files"] == 5
    assert out["source_file_count_at_least"] >= 6  # cap+1 trip point
    # Scout/wire/certify keys must not be populated when guard tripped.
    assert "scan" not in out
    assert "Scope guard tripped" in out["narrative"]


def test_welcome_scope_guard_force_bypasses(tmp_path: Path) -> None:
    """--force allows the walk even past max-files."""
    for i in range(8):
        (tmp_path / f"mod_{i}.py").write_text("x = 1\n", encoding="utf-8")
    out = welcome(project_root=tmp_path, max_files=3, force=True,
                   skip_certify=True)
    assert out.get("verdict") != "REFUSE"
    assert out["scan"]["scout"]["symbol_count"] >= 0  # didn't bail


def test_welcome_since_receipt_missing_returns_none(tmp_path: Path) -> None:
    out = welcome(project_root=tmp_path, skip_certify=True,
                   since_receipt=tmp_path / "doesnotexist.json")
    assert out["since_last_scan"] is None


# ---------- MCP dispatcher ---------------------------------------------


def _decode(response: dict) -> dict:
    result = response["result"]
    if "structuredContent" in result and result["structuredContent"]:
        return result["structuredContent"]
    return json.loads(result["content"][0]["text"])


def test_mcp_welcome_dispatches(tmp_path: Path) -> None:
    import atomadic_forge.a3_og_features.mcp_server  # noqa: F401
    from atomadic_forge.a1_at_functions.mcp_protocol import dispatch_request

    response = dispatch_request(
        {
            "jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {
                "name": "welcome",
                "arguments": {
                    "project_root": str(tmp_path),
                    "skip_certify": True,
                },
            },
        },
        project_root=tmp_path,
    )
    assert response is not None
    assert "error" not in response, response
    body = _decode(response)
    assert body["schema_version"] == SCHEMA_VERSION_WELCOME_V1
    assert body["repo_name"] == tmp_path.name
    assert "narrative" in body
    assert "agent_guidance" in body


def test_capability_showcase_groups_present() -> None:
    s = build_capability_showcase()
    expected_groups = {
        "map_the_repo", "get_a_verdict", "fix_things_safely",
        "discover_patterns", "coordinate_with_others",
    }
    assert expected_groups.issubset(s.keys())
    for group, entries in s.items():
        assert entries, f"{group} should have at least one entry"
        for entry in entries:
            assert {"name", "what", "when", "next_call"}.issubset(entry.keys())
            assert len(entry["what"]) > 30
            assert entry["next_call"]  # non-empty


def test_capability_showcase_includes_core_verbs() -> None:
    s = build_capability_showcase()
    flat_names = {e["name"] for entries in s.values() for e in entries}
    # Spot-check that the headline tools are reachable from the tour.
    assert any("recon" in n for n in flat_names)
    assert any("certify" in n for n in flat_names)
    assert any("wire" in n for n in flat_names)
    assert any("emergent_scan" in n for n in flat_names)


def test_safety_net_lists_concrete_guarantees() -> None:
    bullets = safety_net_summary()
    assert len(bullets) >= 3
    blob = " ".join(bullets).lower()
    # Must reference the actual safety properties.
    assert "deterministic" in blob
    assert "--apply" in blob or "apply" in blob
    assert "receipt" in blob or "rollback" in blob


def test_welcome_includes_capability_showcase_and_safety_net(tmp_path: Path) -> None:
    out = welcome(project_root=tmp_path, skip_certify=True)
    assert "capability_showcase" in out
    assert "safety_net" in out
    assert isinstance(out["capability_showcase"], dict)
    assert isinstance(out["safety_net"], list)
    assert len(out["safety_net"]) >= 3


def test_welcome_narrative_mentions_capability_groups_and_safety(tmp_path: Path) -> None:
    out = welcome(project_root=tmp_path, skip_certify=True)
    n = out["narrative"]
    assert "Map the repo" in n
    assert "Get a verdict" in n
    assert "Safety net" in n
    assert "Read-only by default" in n


def test_mcp_tools_list_includes_welcome() -> None:
    import atomadic_forge.a3_og_features.mcp_server  # noqa: F401
    from atomadic_forge.a1_at_functions.mcp_protocol import dispatch_request

    response = dispatch_request(
        {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
        project_root=Path("."),
    )
    names = {t["name"] for t in response["result"]["tools"]}
    assert "welcome" in names


def test_mcp_tools_list_marks_welcome_as_recommended_first_call() -> None:
    """tools/list must surface welcome as the recommended first call
    both at serverInfo level (single hint) and on the per-tool entry
    (machine-readable flag)."""
    import atomadic_forge.a3_og_features.mcp_server  # noqa: F401
    from atomadic_forge.a1_at_functions.mcp_protocol import dispatch_request

    response = dispatch_request(
        {"jsonrpc": "2.0", "id": 3, "method": "tools/list"},
        project_root=Path("."),
    )
    server_info = response["result"]["serverInfo"]
    assert server_info["recommended_first_call"] == "welcome"

    by_name = {t["name"]: t for t in response["result"]["tools"]}
    assert by_name["welcome"]["recommended_first_call"] is True
    # Spot-check a non-welcome tool stays False so the flag has discriminatory power.
    assert by_name["audit"]["recommended_first_call"] is False


def test_only_one_tool_is_marked_recommended_first_call() -> None:
    """The hint is a SINGLE first-call recommendation. If we ever
    accidentally tag two tools, the serverInfo signal would silently
    pick whichever came first — a gnarly bug to debug. Fail loud."""
    from atomadic_forge.a1_at_functions.mcp_protocol import TOOLS
    flagged = [name for name, spec in TOOLS.items()
                if spec.get("recommended_first_call")]
    assert flagged == ["welcome"], (
        f"Exactly one tool may be flagged recommended_first_call; "
        f"found {flagged}"
    )


def test_welcome_description_signals_first_call_in_natural_language() -> None:
    """The structured flag is for clients that read it; the description
    is for clients (and LLMs) that read tool descriptions to decide
    what to call. Both must point to welcome."""
    from atomadic_forge.a1_at_functions.mcp_protocol import TOOLS
    desc = TOOLS["welcome"]["description"]
    assert "RECOMMENDED FIRST CALL" in desc
