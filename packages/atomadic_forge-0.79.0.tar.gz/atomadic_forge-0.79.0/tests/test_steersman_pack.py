"""Tier verification — 1B steersman decision packs.

Golden Path Lane C W6 follow-on tests. The steersman surface lets a tiny
local model choose routes over AST locks while Forge keeps code mutation
deterministic and scope-bound.
"""
from __future__ import annotations

import json

from atomadic_forge.a1_at_functions.mcp_protocol import (
    dispatch_request,
)
from atomadic_forge.a1_at_functions.steersman_pack import (
    build_steersman_pack,
    finalize_steersman_pack,
    parse_steersman_choices,
)


def _scope_plan() -> dict:
    return {
        "schema_version": "atomadic-forge.ast_scope_plan/v1",
        "blueprint": {
            "compressed_context": {"raw_tokens_estimate": 100_000},
            "nodes": [
                {
                    "node_id": "ast-one",
                    "qualname": "mess.app.processData",
                    "kind": "function",
                    "file": "mess/app.py",
                    "start_line": 10,
                    "end_line": 30,
                    "tier": "",
                },
                {
                    "node_id": "ast-two",
                    "qualname": "mess.app.Service",
                    "kind": "class",
                    "file": "mess/app.py",
                    "start_line": 40,
                    "end_line": 100,
                    "tier": "",
                },
            ],
        },
        "locks": {
            "locks": [
                {"node_id": "ast-one", "lock_id": "lock-one"},
                {"node_id": "ast-two", "lock_id": "lock-two"},
            ],
        },
    }


def test_steersman_pack_is_tiny_and_code_forbidden():
    pack = build_steersman_pack(ast_scope_plan=_scope_plan(), intent="toast spaghetti")

    assert pack["schema_version"] == "atomadic-forge.steersman_pack/v1"
    assert pack["model_contract"]["may_write_code"] is False
    assert pack["question_count"] == 2
    assert pack["questions"][0]["default_choice"] == "a1_at_functions"
    assert pack["questions"][1]["default_choice"] == "a2_mo_composites"
    assert pack["compressed_context"]["prompt_tokens_estimate"] < 300


def test_parse_steersman_choices_accepts_json_map_and_defaults_bad_choices():
    pack = build_steersman_pack(ast_scope_plan=_scope_plan())
    response = json.dumps({
        pack["questions"][0]["question_id"]: "keep",
        pack["questions"][1]["question_id"]: "not-allowed",
    })

    out = parse_steersman_choices(response=response, questions=pack["questions"])

    assert out[0]["choice"] == "keep"
    assert out[0]["source"] == "model"
    assert out[1]["choice"] == "a2_mo_composites"
    assert out[1]["source"] == "deterministic_default"


def test_finalize_pack_reports_99_plus_token_savings():
    pack = build_steersman_pack(ast_scope_plan=_scope_plan())

    out = finalize_steersman_pack(pack=pack)

    assert out["verdict"] == "PASS"
    assert out["compressed_context"]["token_savings_pct"] >= 99.0
    assert "tiny-model decision" in out["summary"]


def test_mcp_plan_steersman_without_model(tmp_path):
    src = tmp_path / "src" / "demo"
    src.mkdir(parents=True)
    (src / "mess.py").write_text(
        "def processData(value):\n    return value.strip()\n",
        encoding="utf-8",
    )
    req = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": "plan",
            "arguments": {
                "action": "steersman",
                "project_roots": [str(tmp_path)],
                "targets": ["processData"],
                "intent": "turn spaghetti into shippable product",
            },
        },
    }

    body = json.loads(dispatch_request(req, project_root=tmp_path)["result"]["content"][0]["text"])

    assert body["verdict"] == "PASS"
    assert body["question_count"] == 1
    assert body["model"]["ran"] is False
    assert body["decisions"][0]["choice"] == "a1_at_functions"


def test_mcp_plan_steersman_run_model_gracefully_defaults_without_ollama(tmp_path):
    src = tmp_path / "src" / "demo"
    src.mkdir(parents=True)
    (src / "mess.py").write_text(
        "def processData(value):\n    return value.strip()\n",
        encoding="utf-8",
    )
    req = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": "plan",
            "arguments": {
                "action": "steersman",
                "project_roots": [str(tmp_path)],
                "targets": ["processData"],
                "run_model": True,
                "model": "definitely-not-installed:1b",
            },
        },
    }

    body = json.loads(dispatch_request(req, project_root=tmp_path)["result"]["content"][0]["text"])

    assert body["model"]["ran"] is False
    assert body["model"]["provider"] == "ollama"
    assert body["model"]["fallback"] == "deterministic_default_decisions"
    assert body["decisions"][0]["choice"] == "a1_at_functions"
