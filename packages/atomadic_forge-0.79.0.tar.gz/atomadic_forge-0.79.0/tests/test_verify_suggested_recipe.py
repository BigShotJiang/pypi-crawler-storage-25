"""Tests for verify_umbrella's REFINE → suggested_recipe linkage.

The umbrella wraps wire + certify (+ optional score_patch / preflight)
into a single verdict. v0.10.x adds ``suggested_recipe`` so a REFINE
or FAIL verdict points the agent at the canonical golden-path recipe
instead of just naming the broken axis.

These tests use minimal fake reports — no real walks — so they're
fast and independent of repo state.
"""
from __future__ import annotations

import pytest

from atomadic_forge.a1_at_functions.recipes import get_recipe, list_recipes
from atomadic_forge.a3_og_features.verify_umbrella import (
    _RECIPE_FOR_AXIS,
    _suggested_recipe,
)


def _certify_report(*, score: float = 100.0, axes: dict | None = None,
                    issues: list | None = None) -> dict:
    """Minimal certify-shaped dict for the helper to read."""
    return {
        "schema_version": "atomadic-forge.certify/v1",
        "score": score,
        "issues": issues or [],
        "axes": axes or {
            "documentation":  {"ok": True, "score_weight": 10},
            "tests_present":  {"ok": True, "score_weight": 5},
            "tier_layout":    {"ok": True, "score_weight": 10},
            "wire_clean":     {"ok": True, "score_weight": 10},
            "no_stubs":       {"ok": True, "score_weight": 0},
            "importable":     {"ok": True, "score_weight": 25},
            "tests_pass":     {"ok": True, "score_weight": 30},
            "ci_workflow":    {"ok": True, "score_weight": 5},
            "changelog":      {"ok": True, "score_weight": 5},
        },
    }


# ── pass-through ─────────────────────────────────────────────────────

def test_suggested_recipe_is_none_when_everything_passes():
    out = _suggested_recipe(
        certify_report=_certify_report(),
        wire_violations=0,
        score_patch_report=None,
        preflight_report=None,
        score=100.0,
        fail_under=75.0,
    )
    assert out is None


# ── wire dominates ───────────────────────────────────────────────────

def test_wire_violation_returns_fix_wire_violation():
    # Even if certify also has issues, wire wins.
    axes = _certify_report()["axes"]
    axes["wire_clean"] = {"ok": False, "score_weight": 10}
    axes["tests_pass"] = {"ok": False, "score_weight": 30}
    out = _suggested_recipe(
        certify_report=_certify_report(score=50.0, axes=axes),
        wire_violations=3,
        score_patch_report=None,
        preflight_report=None,
        score=50.0,
        fail_under=75.0,
    )
    assert out == "fix_wire_violation"


# ── certify axes → recipe ────────────────────────────────────────────

@pytest.mark.parametrize("failing_axis,expected_recipe", [
    ("tests_pass",    "fix_test_detection"),
    ("tests_present", "fix_test_detection"),
    ("ci_workflow",   "release_hardening"),
    ("changelog",     "release_hardening"),
    ("tier_layout",   "add_feature"),
    ("documentation", "dev_cycle"),
])
def test_failing_axis_resolves_to_documented_recipe(
    failing_axis: str, expected_recipe: str,
):
    axes = _certify_report()["axes"]
    axes[failing_axis] = {"ok": False, "score_weight": axes[failing_axis]["score_weight"]}
    out = _suggested_recipe(
        certify_report=_certify_report(score=70.0, axes=axes),
        wire_violations=0,
        score_patch_report=None,
        preflight_report=None,
        score=70.0,
        fail_under=75.0,
    )
    assert out == expected_recipe


def test_highest_weight_failing_axis_wins_when_multiple_are_red():
    # tests_pass (weight=30) should beat documentation (weight=10).
    axes = _certify_report()["axes"]
    axes["tests_pass"]    = {"ok": False, "score_weight": 30}
    axes["documentation"] = {"ok": False, "score_weight": 10}
    out = _suggested_recipe(
        certify_report=_certify_report(score=40.0, axes=axes),
        wire_violations=0,
        score_patch_report=None,
        preflight_report=None,
        score=40.0,
        fail_under=75.0,
    )
    assert out == "fix_test_detection"


# ── score_patch / preflight side-channels ────────────────────────────

def test_score_patch_test_risk_returns_release_hardening():
    out = _suggested_recipe(
        certify_report=_certify_report(),
        wire_violations=0,
        score_patch_report={
            "needs_human_review": True,
            "test_risk": True,
        },
        preflight_report=None,
        score=100.0,
        fail_under=75.0,
    )
    assert out == "release_hardening"


def test_preflight_write_scope_too_broad_returns_dev_cycle():
    out = _suggested_recipe(
        certify_report=_certify_report(),
        wire_violations=0,
        score_patch_report=None,
        preflight_report={"write_scope_too_broad": True},
        score=100.0,
        fail_under=75.0,
    )
    assert out == "dev_cycle"


# ── drift protection ─────────────────────────────────────────────────

def test_every_mapped_recipe_resolves_in_recipes_module():
    """Drift guard: every recipe name we suggest MUST be a real recipe.

    If someone renames a recipe in ``a1_at_functions/recipes.py``
    without updating ``_RECIPE_FOR_AXIS``, this test fails loud.
    """
    catalogue = set(list_recipes())
    for axis, recipe_name in _RECIPE_FOR_AXIS.items():
        assert recipe_name in catalogue, (
            f"axis {axis!r} maps to {recipe_name!r} but no such recipe "
            f"exists. Update _RECIPE_FOR_AXIS or add the recipe."
        )
        # Defensive: get_recipe must also return a non-None body.
        assert get_recipe(recipe_name) is not None, recipe_name
