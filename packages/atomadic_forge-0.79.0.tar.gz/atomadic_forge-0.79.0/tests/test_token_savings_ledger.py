"""Tests for the auto-ledger token-savings flow.

Every Forge verb that calls ``enrich_response`` with a positive
``tokens_saved_estimate`` should automatically append a ledger entry.
The total surfaced via ``read_savings_summary`` is the boastable
public metric.
"""
from __future__ import annotations

from pathlib import Path

from atomadic_forge.a1_at_functions.lifetime_savings import (
    read_savings_summary,
)
from atomadic_forge.a1_at_functions.response_enricher import (
    enrich_response,
    make_scope,
)


def test_enrich_writes_ledger_entry(tmp_path: Path) -> None:
    """Positive scope + project_root + tool ⇒ ledger row appended."""
    scope = make_scope(files_scanned=10, basis_kind="files")
    out = enrich_response(
        {"schema_version": "test/v1"},
        scope=scope,
        summary="tested",
        project_root=tmp_path,
        tool="recon",
    )
    assert out["scope"]["tokens_saved_estimate"] > 0
    summary = read_savings_summary(project_root=tmp_path)
    assert summary["ledger_present"]
    assert summary["entry_count"] == 1
    assert summary["tokens_saved_lifetime"] == out["scope"]["tokens_saved_estimate"]
    assert summary["by_tool"]["recon"] == out["scope"]["tokens_saved_estimate"]


def test_enrich_without_project_root_skips_ledger(tmp_path: Path) -> None:
    """Old-style call (no project_root) must not write to any ledger."""
    enrich_response(
        {"schema_version": "test/v1"},
        scope=make_scope(files_scanned=10, basis_kind="files"),
        summary="tested",
    )
    summary = read_savings_summary(project_root=tmp_path)
    assert summary["ledger_present"] is False
    assert summary["tokens_saved_lifetime"] == 0


def test_enrich_zero_estimate_skips_ledger(tmp_path: Path) -> None:
    """An estimate of 0 must not create a ledger entry."""
    enrich_response(
        {"schema_version": "test/v1"},
        scope=make_scope(basis_kind="none"),
        summary="tested",
        project_root=tmp_path,
        tool="recon",
    )
    summary = read_savings_summary(project_root=tmp_path)
    assert summary["ledger_present"] is False


def test_multiple_calls_accumulate(tmp_path: Path) -> None:
    """Three enriched calls land three entries; totals add."""
    for i in range(3):
        enrich_response(
            {},
            scope=make_scope(files_scanned=5 + i, basis_kind="files"),
            project_root=tmp_path,
            tool=f"tool_{i}",
        )
    summary = read_savings_summary(project_root=tmp_path)
    assert summary["entry_count"] == 3
    # by_tool keys should be the three distinct tool names
    assert set(summary["by_tool"].keys()) == {"tool_0", "tool_1", "tool_2"}
