"""Tests for the v0.14.0a11 response enrichment (scope + summary)."""
from __future__ import annotations

from atomadic_forge.a0_qk_constants.response_enrichment import (
    SCHEMA_VERSION_SCOPE_V1,
    TOKENS_PER_FILE_REVIEW,
    TOKENS_PER_SYMBOL_TRAVERSAL,
)
from atomadic_forge.a1_at_functions.response_enricher import (
    enrich_response,
    make_scope,
    summarize_certify,
    summarize_emergent,
    summarize_for,
    summarize_recon,
    summarize_wire,
)

# ---- make_scope --------------------------------------------------------


def test_make_scope_files_basis_math() -> None:
    s = make_scope(files_scanned=10, basis_kind="files")
    assert s["schema_version"] == SCHEMA_VERSION_SCOPE_V1
    assert s["files_scanned"] == 10
    assert s["tokens_saved_estimate"] == 10 * TOKENS_PER_FILE_REVIEW
    assert "10 files" in s["tokens_saved_basis"]
    assert "manual review" in s["tokens_saved_basis"]


def test_make_scope_symbols_basis_math() -> None:
    s = make_scope(symbols_analyzed=100, basis_kind="symbols")
    assert s["tokens_saved_estimate"] == 100 * TOKENS_PER_SYMBOL_TRAVERSAL
    assert "100 symbols" in s["tokens_saved_basis"]
    assert "traversal" in s["tokens_saved_basis"]


def test_make_scope_both_basis_math() -> None:
    s = make_scope(files_scanned=5, symbols_analyzed=20, basis_kind="both")
    expected = 5 * TOKENS_PER_FILE_REVIEW + 20 * TOKENS_PER_SYMBOL_TRAVERSAL
    assert s["tokens_saved_estimate"] == expected
    assert "5 files" in s["tokens_saved_basis"]
    assert "20 symbols" in s["tokens_saved_basis"]


def test_make_scope_none_basis_emits_zero() -> None:
    s = make_scope(files_scanned=1000, basis_kind="none")
    assert s["tokens_saved_estimate"] == 0
    assert "not applicable" in s["tokens_saved_basis"]


def test_make_scope_clamps_negative_inputs() -> None:
    s = make_scope(files_scanned=-5, symbols_analyzed=-10, basis_kind="files")
    assert s["files_scanned"] == 0
    assert s["symbols_analyzed"] == 0
    assert s["tokens_saved_estimate"] == 0


def test_make_scope_carries_duration_and_tiers() -> None:
    s = make_scope(scan_duration_ms=4242, tiers_traversed=5)
    assert s["scan_duration_ms"] == 4242
    assert s["tiers_traversed"] == 5


# ---- enrich_response ---------------------------------------------------


def test_enrich_response_preserves_existing_keys() -> None:
    base = {"schema_version": "atomadic-forge.foo/v1", "score": 100, "verdict": "PASS"}
    out = enrich_response(base, scope=make_scope(files_scanned=1),
                            summary="Score 100/100, verdict PASS, 0 blockers.")
    assert out["score"] == 100
    assert out["verdict"] == "PASS"
    assert "scope" in out
    assert "summary" in out


def test_enrich_response_does_not_mutate_input() -> None:
    base = {"score": 100}
    enrich_response(base, scope=make_scope(), summary="x")
    assert "scope" not in base
    assert "summary" not in base


def test_enrich_response_omits_empty_summary() -> None:
    out = enrich_response({"a": 1}, summary="")
    assert "summary" not in out


# ---- summarize_certify --------------------------------------------------


def test_summarize_certify_clean_repo() -> None:
    s = summarize_certify({
        "score": 100,
        "verdict": "PASS",
        "health_summary": {"verdict": "PASS", "blockers": 0},
        "issues": [],
        "recommendations": [],
    })
    assert "100/100" in s
    assert "PASS" in s
    assert "0 blockers" in s
    assert "clean" in s.lower()


def test_summarize_certify_with_recommendation() -> None:
    s = summarize_certify({
        "score": 80,
        "verdict": "FAIL",
        "health_summary": {"verdict": "FAIL", "blockers": 2},
        "recommendations": ["Add CI workflow at .github/workflows/ci.yml."],
    })
    assert "80" in s
    assert "Suggestion" in s
    assert "CI workflow" in s


def test_summarize_certify_with_issue_only() -> None:
    s = summarize_certify({
        "score": 70,
        "verdict": "FAIL",
        "health_summary": {"blockers": 1},
        "issues": ["No tests detected."],
        "recommendations": [],
    })
    assert "first issue" in s.lower() or "No tests detected" in s


# ---- summarize_recon ----------------------------------------------------


def test_summarize_recon_balanced() -> None:
    s = summarize_recon({
        "symbols": [{"x": 1}] * 100,
        "tier_distribution": {"a0_qk_constants": 20, "a1_at_functions": 20,
                                "a2_mo_composites": 20, "a3_og_features": 20,
                                "a4_sy_orchestration": 20},
    })
    assert "100 symbols" in s
    assert "5 tiers" in s
    assert "balanced" in s.lower()


def test_summarize_recon_skewed_flags_largest() -> None:
    s = summarize_recon({
        "symbols": [{"x": 1}] * 100,
        "tier_distribution": {"a1_at_functions": 80, "a2_mo_composites": 20},
    })
    assert "a1_at_functions" in s
    assert "80%" in s
    assert "Suggestion" in s


# ---- summarize_emergent -------------------------------------------------


def test_summarize_emergent_with_candidates() -> None:
    s = summarize_emergent({
        "candidates": [{"name": "auth_chain", "score": 0.9}],
        "catalog_size": 100,
    })
    assert "1 emergent" in s
    assert "auth_chain" in s
    assert "Suggestion" in s


def test_summarize_emergent_empty() -> None:
    s = summarize_emergent({"candidates": [], "catalog_size": 100})
    assert "0 emergent" in s
    assert "No suggestions" in s


# ---- summarize_wire -----------------------------------------------------


def test_summarize_wire_clean() -> None:
    s = summarize_wire({"verdict": "PASS", "violation_count": 0})
    assert "PASS" in s
    assert "0 violations" in s
    assert "clean" in s.lower()


def test_summarize_wire_with_violation() -> None:
    s = summarize_wire({
        "verdict": "FAIL", "violation_count": 1,
        "violations": [{"file": "a1/foo.py", "from_tier": "a1_at_functions",
                        "to_tier": "a3_og_features", "imported": "X"}],
    })
    assert "1 violations" in s
    assert "a1/foo.py" in s
    assert "Suggestion" in s


def test_summarize_wire_warnings_block() -> None:
    s = summarize_wire({
        "verdict": "PASS", "violation_count": 0,
        "type_only_imports": [{"x": 1}, {"y": 2}],
        "star_import_warnings": [{"z": 3}],
        "dynamic_import_warnings": [],
    })
    assert "2 type-only" in s
    assert "1 star-import" in s


# ---- summarize_for dispatch --------------------------------------------


def test_summarize_for_known_tools() -> None:
    assert summarize_for("certify", {"score": 100, "verdict": "PASS",
                                       "health_summary": {"blockers": 0}})
    assert summarize_for("recon", {"symbols": [], "tier_distribution": {}})


def test_summarize_for_unknown_tool_returns_empty() -> None:
    assert summarize_for("does_not_exist", {}) == ""


def test_summarize_for_swallows_summarizer_errors() -> None:
    """A broken report shape must not propagate — return empty so the
    tool response still reaches the caller."""
    assert summarize_for("certify", "not a dict at all") == ""  # type: ignore[arg-type]
