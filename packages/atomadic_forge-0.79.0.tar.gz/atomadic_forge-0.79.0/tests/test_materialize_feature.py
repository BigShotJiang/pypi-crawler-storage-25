"""Tests for the materialize feature: emergent candidates -> package."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from atomadic_forge.a3_og_features.materialize_feature import (
    Materializer,
    materialize_from_report_path,
)


def _fake_candidate(cid: str, name: str = "alpha-bravo") -> dict:
    return {
        "candidate_id": cid,
        "name": name,
        "summary": "test composition",
        "chain": {
            "chain": [
                "atomadic_forge.a1_at_functions.scaffold_starter.render_gitignore",
            ],
            "bridges": [],
            "tiers": ["a1_at_functions"],
            "domains": ["scaffold"],
            "crosses_domains": 1,
            "crosses_tiers": 1,
            "final_output_type": "str",
            "pure": True,
        },
        "score": 80.0,
        "score_breakdown": {"novelty": 40, "purity": 40},
        "suggested_tier": "a3_og_features",
        "novelty_signals": ["fake test signal"],
    }


def _fake_report(*candidate_ids: str) -> dict:
    return {
        "schema_version": "atomadic-forge.emergent.scan/v1",
        "generated_at_utc": "2026-05-06T00:00:00Z",
        "catalog_size": 1,
        "chain_count_considered": 1,
        "candidates": [_fake_candidate(cid) for cid in candidate_ids],
        "domain_inventory": {"scaffold": 1},
        "tier_inventory": {"a1_at_functions": 1},
    }


def test_materialize_writes_full_scaffold(tmp_path: Path) -> None:
    report = _fake_report("emrg-aaa", "emrg-bbb")
    out = tmp_path / "pkg"

    result = Materializer().materialize(
        report,  # type: ignore[arg-type]
        out_dir=out,
        package="demo_pkg",
        top_n=2,
        run_certify=False,
    )

    # Tier scaffold present.
    for tier in ("a0_qk_constants", "a1_at_functions", "a2_mo_composites",
                 "a3_og_features", "a4_sy_orchestration"):
        assert (out / "src" / "demo_pkg" / tier / "__init__.py").exists()

    # Project surface present.
    assert (out / "pyproject.toml").exists()
    assert (out / "README.md").exists()
    assert (out / ".gitignore").exists()
    assert (out / ".github" / "workflows" / "ci.yml").exists()
    assert (out / "CHANGELOG.md").exists()
    assert (out / "tests" / "conftest.py").exists()
    assert (out / "tests" / "__init__.py").exists()

    # One feature + one test per candidate.
    feature_dir = out / "src" / "demo_pkg" / "a3_og_features"
    feature_files = sorted(p.name for p in feature_dir.glob("*_emergent.py"))
    assert len(feature_files) == 2
    test_files = sorted(p.name for p in (out / "tests").glob("test_*.py"))
    assert len(test_files) == 2

    # Report shape.
    assert result["package"] == "demo_pkg"
    assert result["candidates_selected"] == ["emrg-aaa", "emrg-bbb"]
    assert result["wire_violations"] == 0
    assert result["certify_score"] is None  # certify skipped
    # Files written includes scaffold + features + tests + inits.
    roles = {f["role"] for f in result["files_written"]}
    assert {"feature", "test", "scaffold", "init"} <= roles


def test_materialize_passes_seed_import_roots_to_conftest(tmp_path: Path) -> None:
    out = tmp_path / "pkg"
    Materializer().materialize(
        _fake_report("emrg-aaa"),  # type: ignore[arg-type]
        out_dir=out,
        package="demo_pkg",
        top_n=1,
        run_certify=False,
        test_extra_src_roots=[str(tmp_path / "seed" / "src")],
    )

    conftest = (out / "tests" / "conftest.py").read_text(encoding="utf-8")
    assert "Optional harvested seed roots" in conftest
    assert str(tmp_path / "seed" / "src").replace("\\", "\\\\") in conftest


def test_materialize_top_n_truncates(tmp_path: Path) -> None:
    report = _fake_report("a", "b", "c", "d", "e")
    result = Materializer().materialize(
        report,  # type: ignore[arg-type]
        out_dir=tmp_path / "pkg",
        package="demo",
        top_n=2,
        run_certify=False,
    )
    assert result["candidates_selected"] == ["a", "b"]


def test_materialize_explicit_ids_wins_over_top_n(tmp_path: Path) -> None:
    report = _fake_report("a", "b", "c", "d")
    result = Materializer().materialize(
        report,  # type: ignore[arg-type]
        out_dir=tmp_path / "pkg",
        package="demo",
        top_n=99,
        candidate_ids=["c", "a"],
        run_certify=False,
    )
    # Order follows report order, not the input list — that matches the
    # selector implementation (filtering preserves report order).
    assert result["candidates_selected"] == ["a", "c"]


def test_materialize_unknown_id_raises(tmp_path: Path) -> None:
    report = _fake_report("a")
    with pytest.raises(KeyError):
        Materializer().materialize(
            report,  # type: ignore[arg-type]
            out_dir=tmp_path / "pkg",
            package="demo",
            candidate_ids=["nonexistent"],
            run_certify=False,
        )


def test_materialize_refuses_nonempty_unrelated_dir(tmp_path: Path) -> None:
    out = tmp_path / "pkg"
    out.mkdir()
    (out / "stale.txt").write_text("don't blow this away", encoding="utf-8")
    with pytest.raises(ValueError, match="non-empty"):
        Materializer().materialize(
            _fake_report("a"),  # type: ignore[arg-type]
            out_dir=out,
            package="demo",
            run_certify=False,
        )


def test_materialize_idempotent_on_prior_materialize(tmp_path: Path) -> None:
    """Re-running on a previously materialized dir is allowed."""
    out = tmp_path / "pkg"
    Materializer().materialize(
        _fake_report("a"),  # type: ignore[arg-type]
        out_dir=out,
        package="demo",
        run_certify=False,
    )
    # Marker should exist; second call should not raise.
    assert (out / ".atomadic-forge" / "materialize.json").exists()
    Materializer().materialize(
        _fake_report("a", "b"),  # type: ignore[arg-type]
        out_dir=out,
        package="demo",
        top_n=2,
        run_certify=False,
    )


def test_materialize_zero_candidates_still_scaffolds(tmp_path: Path) -> None:
    report = _fake_report()  # no candidates
    result = Materializer().materialize(
        report,  # type: ignore[arg-type]
        out_dir=tmp_path / "pkg",
        package="empty_demo",
        run_certify=False,
    )
    assert result["candidates_selected"] == []
    assert (tmp_path / "pkg" / "pyproject.toml").exists()
    # Tier dirs exist, but no feature .py files.
    feature_dir = tmp_path / "pkg" / "src" / "empty_demo" / "a3_og_features"
    assert feature_dir.exists()
    assert not list(feature_dir.glob("*_emergent.py"))


def test_materialize_from_report_path_roundtrip(tmp_path: Path) -> None:
    report_path = tmp_path / "scan.json"
    report_path.write_text(json.dumps(_fake_report("a")), encoding="utf-8")

    result = materialize_from_report_path(
        report_path,
        out_dir=tmp_path / "pkg",
        package="demo",
        top_n=1,
        run_certify=False,
    )
    assert result["candidates_selected"] == ["a"]


def test_materialize_from_report_path_validates_shape(tmp_path: Path) -> None:
    bad = tmp_path / "bad.json"
    bad.write_text(json.dumps({"not": "a report"}), encoding="utf-8")
    with pytest.raises(ValueError, match="not a valid emergent scan report"):
        materialize_from_report_path(
            bad,
            out_dir=tmp_path / "pkg",
            package="demo",
        )
