"""Tests for cherry_pick.select_items — including non-tier dir filter (GAP-004)."""

from atomadic_forge.a1_at_functions.cherry_pick import select_items


def _scout(symbols: list[dict]) -> dict:
    return {
        "schema_version": "atomadic-forge.scout/v1",
        "repo": "/seed/foo",
        "symbols": symbols,
    }


def _sym(qual: str, file: str, *, tier: str = "a1_at_functions",
         name: str | None = None) -> dict:
    return {
        "qualname": qual,
        "name": name or qual.split(".")[-1],
        "file": file,
        "tier_guess": tier,
        "complexity": 100,
        "has_self_assign": False,
        "effects": ["pure"],
    }


def test_pick_all_excludes_test_files_by_default():
    """GAP-004: test files must not be promoted into the absorbed package."""
    scout = _scout([
        _sym("real.helper", "src/foo/helper.py"),
        _sym("test_thing.MockProvider.load",
             "tests/test_thing.py"),
        _sym("benchmarks.bench_run", "benchmarks/bench_run.py"),
        _sym("examples.demo", "examples/demo.py"),
    ])
    result = select_items(scout, pick_all=True)
    quals = [it["qualname"] for it in result["items"]]
    assert quals == ["real.helper"]


def test_pick_all_can_opt_in_to_test_dirs():
    """include_non_tier_dirs=True restores prior behavior for explicit users."""
    scout = _scout([
        _sym("real.helper", "src/foo/helper.py"),
        _sym("test_thing.MockProvider.load", "tests/test_thing.py"),
    ])
    result = select_items(scout, pick_all=True, include_non_tier_dirs=True)
    quals = sorted(it["qualname"] for it in result["items"])
    assert quals == ["real.helper", "test_thing.MockProvider.load"]


def test_explicit_names_still_filter_non_tier():
    """Asking for a qualname under tests/ by name also defaults to skip."""
    scout = _scout([
        _sym("test_thing.MockProvider.load", "tests/test_thing.py"),
    ])
    result = select_items(
        scout, names=["test_thing.MockProvider.load"], pick_all=False)
    assert result["items"] == []


def test_windows_style_path_separator_recognized():
    """Path classification works regardless of slash flavor."""
    scout = _scout([
        _sym("test_thing.X", r"tests\unit\test_thing.py"),
    ])
    result = select_items(scout, pick_all=True)
    assert result["items"] == []
