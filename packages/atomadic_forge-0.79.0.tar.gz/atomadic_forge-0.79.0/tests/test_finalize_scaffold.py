"""Tests for the run_finalize scaffold-emitter (README, pyproject, tests, CI, CHANGELOG).

Closes the gap that absorbed packages were emitted bare-bones (5/100
certify) instead of as complete shippable scaffolds. The emitter must:

  * Write README.md, pyproject.toml, .gitignore, .github/workflows/ci.yml,
    CHANGELOG.md, tests/__init__.py, tests/conftest.py, tests/test_smoke.py.
  * Never overwrite existing files (preserve user-authored content).
  * Surface the written set in the report under scaffold_files_written.
"""
from __future__ import annotations

from pathlib import Path

from atomadic_forge.a3_og_features.forge_pipeline import (
    _emit_scaffold_files,
    run_finalize,
)


def _seed(target: Path) -> Path:
    """Create a tiny source repo with one Python module Forge can absorb."""
    target.mkdir(parents=True, exist_ok=True)
    (target / "pyproject.toml").write_text(
        '[project]\nname = "seedmod"\nversion = "0.0.1"\n',
        encoding="utf-8",
    )
    src = target / "src" / "seedmod"
    src.mkdir(parents=True, exist_ok=True)
    (src / "__init__.py").write_text("", encoding="utf-8")
    (src / "core.py").write_text(
        '"""Seed module."""\n\n\ndef hello(name: str) -> str:\n'
        '    return f"hi {name}"\n',
        encoding="utf-8",
    )
    return target


def test_emit_scaffold_writes_full_set(tmp_path):
    output = tmp_path / "out"
    output.mkdir()
    written = _emit_scaffold_files(
        output=output,
        package="abc_pkg",
        source_repos=["https://github.com/example/source"],
        components_emitted=42,
        tier_distribution={"a1_at_functions": 30, "a2_mo_composites": 12},
        digest="deadbeefcafe1234",
    )
    assert "README.md" in written
    assert "CHANGELOG.md" in written
    assert ".github/workflows/ci.yml" in written
    assert "tests/test_smoke.py" in written
    assert (output / "README.md").exists()
    assert (output / "CHANGELOG.md").exists()
    assert (output / ".github/workflows/ci.yml").exists()
    assert (output / "tests/test_smoke.py").exists()
    # The README must surface the harvest metadata in the showcase format.
    readme_text = (output / "README.md").read_text(encoding="utf-8")
    assert "abc_pkg" in readme_text
    assert "42" in readme_text  # symbol count
    assert "deadbeefcafe1234" in readme_text  # digest
    assert "https://github.com/example/source" in readme_text


def test_emit_scaffold_never_overwrites_existing_readme(tmp_path):
    """User-authored README/CHANGELOG must survive a re-run."""
    output = tmp_path / "out"
    output.mkdir()
    custom_readme = "# my hand-written README\n\ndo not touch.\n"
    (output / "README.md").write_text(custom_readme, encoding="utf-8")
    custom_log = "# my CHANGELOG\n\n- did stuff.\n"
    (output / "CHANGELOG.md").write_text(custom_log, encoding="utf-8")

    written = _emit_scaffold_files(
        output=output,
        package="abc_pkg",
        source_repos=[],
        components_emitted=10,
        tier_distribution={"a1_at_functions": 10},
        digest="aaaa",
    )
    assert "README.md" not in written
    assert "CHANGELOG.md" not in written
    assert (output / "README.md").read_text(encoding="utf-8") == custom_readme
    assert (output / "CHANGELOG.md").read_text(encoding="utf-8") == custom_log
    # Other files were still emitted.
    assert (output / "tests/test_smoke.py").exists()


def test_run_finalize_emits_complete_shippable_scaffold(tmp_path):
    target = _seed(tmp_path / "seed")
    output = tmp_path / "out"
    report = run_finalize(
        target=target,
        output=output,
        package="seed_absorbed",
        apply=True,
    )
    assert report["applied"] is True
    written = report["scaffold_files_written"]
    for required in (
        "README.md", "pyproject.toml", ".gitignore",
        ".github/workflows/ci.yml", "CHANGELOG.md",
        "tests/__init__.py", "tests/conftest.py", "tests/test_smoke.py",
    ):
        assert required in written, f"emitter must write {required}"
    # Wire law must hold and certify must run on the new package.
    assert report["wire"]["verdict"] == "PASS"
    assert "score" in report["certify"]
