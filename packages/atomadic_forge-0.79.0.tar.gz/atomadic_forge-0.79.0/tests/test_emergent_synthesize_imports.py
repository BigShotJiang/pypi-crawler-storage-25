"""Regression: ``_imports_for`` must skip class-method qualnames.

A qualname like ``pkg.mod.Class.method`` rpartitions into module=``pkg.mod.Class``
and name=``method``.  The previous guard checked ``"." in name``, which never
fires post-rpartition, so the synthesizer emitted::

    from pkg.mod.Class import method

That import fails at module load (``Class`` is not a package).  The render body
already skips method steps with a ``NOTE: wire the receiver manually`` line, so
the matching import line is unused — it just had to be omitted.
"""

from __future__ import annotations

import ast

from atomadic_forge.a1_at_functions.emergent_synthesize import (
    _imports_for,
    render_emergent_feature,
)


def test_imports_for_skips_class_method_qualname():
    qualnames = [
        "pkg.mod.helper.parse_signal",                       # function
        "pkg.feature.Commandsmith.write_manifest",           # method on a class
        "other.cli.provider.load_provider_data",             # function
    ]
    lines = _imports_for(qualnames)
    assert "from pkg.mod.helper import parse_signal" in lines
    assert "from other.cli.provider import load_provider_data" in lines
    assert all("Commandsmith" not in line for line in lines), lines


def test_render_emergent_feature_emits_parseable_python_for_method_chain():
    card = {
        "candidate_id": "emrg-test001",
        "name": "alpha-beta-gamma-pipeline",
        "suggested_tier": "a3_og_features",
        "score": 74,
        "score_breakdown": {"cross_domain": 24, "pure": 10},
        "novelty_signals": ["spans three or more domains"],
        "summary": "Compose 3 steps across 3 domains",
        "chain": {
            "chain": [
                "pkg.alpha.helpers.detect_signal",
                "pkg.beta.Commandsmith.write_manifest",
                "pkg.gamma.utils.load_provider_data",
            ],
            "bridges": ["dict[str, bool]", "Path", "dict[str, Any] | None"],
        },
    }
    src = render_emergent_feature(card)
    # The dangerous line must not appear.
    assert "from pkg.beta.Commandsmith import write_manifest" not in src
    # The whole module must parse.
    ast.parse(src)


def test_render_emergent_feature_imports_steps_lazily():
    card = {
        "candidate_id": "emrg-test002",
        "name": "alpha-beta-pipeline",
        "suggested_tier": "a3_og_features",
        "score": 80,
        "score_breakdown": {"cross_domain": 24},
        "novelty_signals": ["spans domains"],
        "summary": "Compose 2 steps",
        "chain": {
            "chain": [
                "missing.alpha.detect_signal",
                "missing.beta.load_provider_data",
            ],
            "bridges": ["dict[str, bool]"],
        },
    }
    src = render_emergent_feature(card)
    assert "from missing.alpha import detect_signal" not in src.split("def ", 1)[0]
    assert "from missing.alpha import detect_signal as _step_1_detect_signal" in src
    ast.parse(src)
