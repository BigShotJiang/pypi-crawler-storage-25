"""Tests for a1 harvest_concept_bridge — TAU_TRUST gap → synthesis plan."""

from atomadic_forge.a1_at_functions.harvest_concept_bridge import (
    SCHEMA_VERSION_CONCEPT_BRIDGE_V1,
    extract_synthesis_plan,
    run_concept_bridge,
)


def _make_candidates(n=3):
    return [
        {
            "qualname": f"module.dead_code_check_{i}",
            "source_repo": ".",
            "target_tier": "a1_at_functions",
            "confidence": 0.75,
            "effects": ["pure"],
            "complexity": 5,
        }
        for i in range(n)
    ]


def test_schema_version():
    result = extract_synthesis_plan([])
    assert result["schema_version"] == SCHEMA_VERSION_CONCEPT_BRIDGE_V1


def test_empty_candidates():
    result = extract_synthesis_plan([])
    assert result["synthesis_plan_count"] == 0
    assert result["synthesis_plans"] == []


def test_plans_generated():
    candidates = _make_candidates(3)
    result = extract_synthesis_plan(candidates)
    assert result["synthesis_plan_count"] == 3
    assert len(result["synthesis_plans"]) == 3


def test_plan_fields_present():
    candidates = _make_candidates(1)
    result = extract_synthesis_plan(candidates)
    plan = result["synthesis_plans"][0]
    for field in ("priority", "source_qualname", "concept", "suggested_module",
                  "suggested_function", "suggested_args", "wire_stubs_cmd",
                  "target_tier", "effects"):
        assert field in plan, f"missing {field}"


def test_top_n_respected():
    candidates = _make_candidates(10)
    result = extract_synthesis_plan(candidates, top_n=3)
    assert result["synthesis_plan_count"] == 3


def test_min_confidence_filter():
    candidates = _make_candidates(5)
    result = extract_synthesis_plan(candidates, min_confidence=0.9)
    assert result["synthesis_plan_count"] == 0


def test_recommended_actions_present():
    candidates = _make_candidates(5)
    result = extract_synthesis_plan(candidates)
    assert isinstance(result["recommended_actions"], list)


def test_run_concept_bridge_no_candidates(tmp_path):
    result = run_concept_bridge(tmp_path, candidates=None)
    assert result["available"] is False
    assert "reason" in result


def test_run_concept_bridge_with_candidates(tmp_path):
    candidates = _make_candidates(2)
    result = run_concept_bridge(tmp_path, candidates=candidates)
    assert result["schema_version"] == SCHEMA_VERSION_CONCEPT_BRIDGE_V1
    assert result["synthesis_plan_count"] == 2


def test_run_concept_bridge_bad_json(tmp_path):
    bad = tmp_path / "bad.json"
    bad.write_text("not json", encoding="utf-8")
    result = run_concept_bridge(tmp_path, harvest_json_path=str(bad))
    assert result["available"] is False
