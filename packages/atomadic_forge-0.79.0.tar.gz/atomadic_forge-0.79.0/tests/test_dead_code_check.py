"""Tests for a1 dead_code_check — vulture-synthesis dead symbol detector."""
from pathlib import Path

from atomadic_forge.a1_at_functions.dead_code_check import (
    SCHEMA_VERSION_DEAD_CODE_V1,
    check_dead_code,
)


def test_schema_version(tmp_path):
    result = check_dead_code(tmp_path)
    assert result["schema_version"] == SCHEMA_VERSION_DEAD_CODE_V1


def test_unavailable_on_empty_dir(tmp_path):
    result = check_dead_code(tmp_path)
    assert result["available"] is False
    assert "reason" in result


def _make_pkg(tmp_path, pkg_name="mypkg"):
    pkg = tmp_path / "src" / pkg_name
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    return pkg


def test_finds_dead_function(tmp_path):
    pkg = _make_pkg(tmp_path)
    (pkg / "tools.py").write_text(
        "def alive_func():\n    return 1\n"
        "def dead_func():\n    return 2\n",
        encoding="utf-8",
    )
    (pkg / "main.py").write_text(
        "from .tools import alive_func\n"
        "alive_func()\n",
        encoding="utf-8",
    )
    result = check_dead_code(tmp_path)
    assert result["available"] is True
    names = {s["qualname"].rsplit(".", 1)[-1] for s in result["dead_symbols"]}
    assert "dead_func" in names
    assert "alive_func" not in names


def test_live_function_excluded(tmp_path):
    pkg = _make_pkg(tmp_path)
    (pkg / "utils.py").write_text(
        "def my_util():\n    return 42\n",
        encoding="utf-8",
    )
    (pkg / "main.py").write_text(
        "from .utils import my_util\nmy_util()\n",
        encoding="utf-8",
    )
    result = check_dead_code(tmp_path)
    assert result["available"] is True
    names = {s["qualname"].rsplit(".", 1)[-1] for s in result["dead_symbols"]}
    assert "my_util" not in names


def test_dunder_excluded(tmp_path):
    pkg = _make_pkg(tmp_path)
    (pkg / "cls.py").write_text(
        "class Foo:\n    def __init__(self):\n        pass\n",
        encoding="utf-8",
    )
    result = check_dead_code(tmp_path)
    names = {s["qualname"].rsplit(".", 1)[-1] for s in result["dead_symbols"]}
    assert "__init__" not in names


def test_dead_by_kind_structure(tmp_path):
    pkg = _make_pkg(tmp_path)
    (pkg / "mod.py").write_text("def lone_fn():\n    pass\n", encoding="utf-8")
    result = check_dead_code(tmp_path)
    assert "dead_by_kind" in result
    for k in ("function", "class", "variable", "import"):
        assert k in result["dead_by_kind"]


def test_on_forge_itself():
    root = Path(__file__).parent.parent
    result = check_dead_code(root)
    assert result["available"] is True
    assert isinstance(result["dead_symbol_count"], int)
    assert isinstance(result["dead_symbols"], list)
