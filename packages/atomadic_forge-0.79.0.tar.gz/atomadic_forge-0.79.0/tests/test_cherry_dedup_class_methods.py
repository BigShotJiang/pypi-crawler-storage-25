"""Tests for cherry-pick class/method dedup (47-file class explosion fix).

When scout enumerates a class plus every public method as separate
symbols, the cherry manifest must collapse the methods under the class
so finalize copies the source file once — not once per method.
"""
from __future__ import annotations

from atomadic_forge.a1_at_functions.cherry_pick import select_items


def _scout_with_class_and_methods(method_count: int = 47) -> dict:
    """A fake scout report with one class + N public methods, all in one file."""
    symbols = [
        {
            "name": "IndexStore",
            "qualname": "IndexStore",
            "file": "src/jcm/search_index.py",
            "tier_guess": "a2_mo_composites",
            "complexity": 200,
            "has_self_assign": True,
            "effects": ["io"],
            "kind": "class",
        }
    ]
    for i in range(method_count):
        symbols.append({
            "name": f"method_{i}",
            "qualname": f"IndexStore.method_{i}",
            "file": "src/jcm/search_index.py",
            "tier_guess": "a1_at_functions",
            "complexity": 50,
            "has_self_assign": False,
            "effects": ["pure"],
            "kind": "method",
        })
    return {"repo": "jcm", "symbols": symbols}


def test_class_picked_methods_folded():
    """When the class is in the manifest, none of its methods survive cherry."""
    report = _scout_with_class_and_methods(47)
    manifest = select_items(report, pick_all=True)
    quals = [it["qualname"] for it in manifest["items"]]
    assert "IndexStore" in quals
    # Not one method survives — they ride along inside the class body.
    assert not any("." in q for q in quals)
    # Exactly one item, not 48.
    assert len(manifest["items"]) == 1


def test_orphan_methods_kept_when_class_absent():
    """If scout dropped the parent class, the methods are still cherry-picked
    so capability isn't silently lost."""
    report = _scout_with_class_and_methods(3)
    # Strip the class; keep only the methods.
    report["symbols"] = [s for s in report["symbols"] if s["kind"] == "method"]
    manifest = select_items(report, pick_all=True)
    quals = [it["qualname"] for it in manifest["items"]]
    assert quals == [
        "IndexStore.method_0", "IndexStore.method_1", "IndexStore.method_2",
    ]


def test_free_function_alongside_class():
    """A free function in the same module is independent — kept."""
    report = _scout_with_class_and_methods(2)
    report["symbols"].append({
        "name": "tokenize",
        "qualname": "tokenize",
        "file": "src/jcm/search_index.py",
        "tier_guess": "a1_at_functions",
        "complexity": 30,
        "has_self_assign": False,
        "effects": ["pure"],
        "kind": "function",
    })
    manifest = select_items(report, pick_all=True)
    quals = sorted(it["qualname"] for it in manifest["items"])
    assert quals == ["IndexStore", "tokenize"]
