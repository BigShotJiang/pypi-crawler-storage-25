"""Tests for a1 surface_gap_check — wiring gap detector."""
from pathlib import Path

from atomadic_forge.a1_at_functions.surface_gap_check import (
    SCHEMA_VERSION_SURFACE_GAP_V1,
    check_surface_gaps,
)


def test_surface_gaps_schema_version(tmp_path):
    result = check_surface_gaps(tmp_path)
    assert result["schema_version"] == SCHEMA_VERSION_SURFACE_GAP_V1


def test_surface_gaps_unavailable_on_non_forge_root(tmp_path):
    result = check_surface_gaps(tmp_path)
    assert result["available"] is False
    assert "reason" in result


def test_surface_gaps_on_forge_itself():
    """Run against the actual forge repo — must find some gaps and return available."""
    root = Path(__file__).parent.parent
    result = check_surface_gaps(root)
    assert result["available"] is True
    assert result["total_entry_points_scanned"] > 0
    assert "mcp_gaps" in result
    assert "cli_gaps" in result
    assert "both_gaps" in result
    assert isinstance(result["mcp_gap_count"], int)
    assert isinstance(result["cli_gap_count"], int)


def _make_mini_pkg(tmp_path, pkg_name="mypkg"):
    """Create minimal forge-like package structure."""
    a1_dir = tmp_path / "src" / pkg_name / "a1_at_functions"
    a1_dir.mkdir(parents=True)
    a4_dir = tmp_path / "src" / pkg_name / "a4_sy_orchestration"
    a4_dir.mkdir(parents=True)
    (tmp_path / "src" / pkg_name / "__init__.py").write_text("", encoding="utf-8")
    return a1_dir, a4_dir


def test_surface_gaps_detects_unwired_function(tmp_path):
    """A new a1 function with no MCP/CLI mention should appear in gaps."""
    a1_dir, a4_dir = _make_mini_pkg(tmp_path)

    (a1_dir / "new_tool.py").write_text(
        'SCHEMA_VERSION_NEW_TOOL_V1 = "x/v1"\n'
        "def compute_new_thing(project_root):\n    return {}\n",
        encoding="utf-8",
    )
    (a1_dir / "mcp_protocol.py").write_text("# placeholder MCP\n", encoding="utf-8")
    (a4_dir / "cli.py").write_text("# placeholder CLI\n", encoding="utf-8")

    result = check_surface_gaps(tmp_path)
    assert result["available"] is True
    qualnames = {g["qualname"] for g in result["both_gaps"]}
    assert "new_tool.compute_new_thing" in qualnames


def test_surface_gaps_mcp_wired_not_in_both_gaps(tmp_path):
    """Function mentioned in mcp_protocol.py should NOT appear in both_gaps."""
    a1_dir, a4_dir = _make_mini_pkg(tmp_path)

    (a1_dir / "wired_tool.py").write_text(
        'SCHEMA_VERSION_WIRED_V1 = "x/v1"\n'
        "def compute_wired(project_root):\n    return {}\n",
        encoding="utf-8",
    )
    (a1_dir / "mcp_protocol.py").write_text(
        "from .wired_tool import compute_wired\n", encoding="utf-8"
    )
    (a4_dir / "cli.py").write_text("# no mention\n", encoding="utf-8")

    result = check_surface_gaps(tmp_path)
    both_names = {g["qualname"] for g in result["both_gaps"]}
    assert "wired_tool.compute_wired" not in both_names
