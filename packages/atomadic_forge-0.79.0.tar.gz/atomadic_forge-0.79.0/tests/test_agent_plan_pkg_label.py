"""Regression: ``forge plan`` next_command must not emit a literal ``your_pkg``
placeholder when the package name can be inferred from the certify report or
the project root.  Boris-rehearsal showed users would copy the suggestion
verbatim and create a broken test file.
"""

from __future__ import annotations

from atomadic_forge.a1_at_functions.agent_plan_emitter import (
    _infer_pkg_label,
    emit_agent_plan,
)


def test_infer_pkg_label_uses_certify_project():
    label = _infer_pkg_label({"project": "atomadic-forge"}, package=None)
    assert label == "atomadic_forge"


def test_infer_pkg_label_uses_project_root_basename():
    label = _infer_pkg_label({}, package=None,
                             project_root="/repos/posterous-export")
    assert label == "posterous_export"


def test_infer_pkg_label_explicit_package_wins():
    label = _infer_pkg_label({"project": "ignored"}, package="explicit_pkg",
                             project_root="/repos/ignored")
    assert label == "explicit_pkg"


def test_infer_pkg_label_falls_back_to_placeholder():
    assert _infer_pkg_label(None, package=None) == "your_pkg"


def test_emit_agent_plan_test_card_uses_real_package_name():
    plan = emit_agent_plan(
        project_root="/repos/superscript-heroku",
        goal="improve",
        certify_report={
            "project": "superscript-heroku",
            "documentation_complete": True,
            "tests_present": False,
        },
    )
    test_cards = [c for c in plan["top_actions"]
                  if c["id"].startswith("tests-")]
    assert test_cards, plan
    next_cmd = test_cards[0]["next_command"]
    assert "your_pkg" not in next_cmd, next_cmd
    assert "superscript_heroku" in next_cmd, next_cmd
