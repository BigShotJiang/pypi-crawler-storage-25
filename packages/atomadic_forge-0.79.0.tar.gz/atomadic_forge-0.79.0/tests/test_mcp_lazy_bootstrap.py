"""Pin the lazy a3-bootstrap contract for ``mcp_protocol`` direct callers.

A downstream consumer that imports :mod:`atomadic_forge.a1_at_functions.mcp_protocol`
directly (without going through ``forge mcp serve``) must still get
real handler results when calling tool wrappers — the upward-only tier
law forbids a static import from a1 to a3, but the wrappers' first
call lazily ``importlib.import_module``s a3 to trigger handler
registration.

Tests verify the bootstrap *machinery* (flag flip + handler rebind) on
a tiny tmp fixture rather than invoking expensive handlers against the
host repo.  Calling ``_tool_verify`` against the live atomadic-forge
clone would recursively invoke pytest from inside pytest and time
certify's internal 60s budget out — so we use cheap probes instead.
"""
from __future__ import annotations

import pytest


@pytest.fixture()
def fresh_mcp_protocol():
    """Yield ``mcp_protocol`` with the bootstrap flag reset.

    Resets ``_A3_BOOTSTRAP_DONE`` to False at setup, restores at teardown
    so test order stays independent.  Note we do NOT delete
    ``atomadic_forge.*`` from ``sys.modules`` — that would break
    ``test_mcp_protocol`` cases whose top-level imports captured a
    pre-fixture module reference.
    """
    from atomadic_forge.a1_at_functions import mcp_protocol as proto
    saved = proto._A3_BOOTSTRAP_DONE
    proto._A3_BOOTSTRAP_DONE = False
    try:
        yield proto
    finally:
        proto._A3_BOOTSTRAP_DONE = saved


def test_bootstrap_helper_flips_flag(fresh_mcp_protocol):
    """``_bootstrap_a3_handlers()`` flips the idempotency flag on first
    call and is a no-op afterward."""
    proto = fresh_mcp_protocol
    assert proto._A3_BOOTSTRAP_DONE is False
    proto._bootstrap_a3_handlers()
    assert proto._A3_BOOTSTRAP_DONE is True
    proto._bootstrap_a3_handlers()  # idempotent
    proto._bootstrap_a3_handlers()
    assert proto._A3_BOOTSTRAP_DONE is True


def test_bootstrap_rebinds_registered_handlers(fresh_mcp_protocol):
    """After bootstrap, every registered handler global is no longer
    its ``_unbound`` stub."""
    proto = fresh_mcp_protocol
    proto._bootstrap_a3_handlers()
    # Spot-check a handful of representative handlers across the
    # registered surface.
    assert proto._verify_handler is not proto._tool_verify_unbound
    assert proto._emergent_scan_handler is not proto._tool_emergent_scan_unbound
    assert proto._synergy_scan_handler is not proto._tool_synergy_scan_unbound
    assert proto._cna_check_handler is not proto._tool_cna_check_unbound
    assert proto._wisdom_query_handler is not proto._tool_wisdom_query_unbound


def test_wrapper_triggers_bootstrap_on_first_call(fresh_mcp_protocol, tmp_path):
    """Calling any wrapper before bootstrap flips the flag.

    Uses ``_tool_cna_check`` against an empty tmp directory — cheap
    real invocation, no recursive pytest, no host-repo scan.
    """
    proto = fresh_mcp_protocol
    assert proto._A3_BOOTSTRAP_DONE is False
    out = proto._tool_cna_check(tmp_path, {"proposed_name": "totally_unique_xyz"})
    assert proto._A3_BOOTSTRAP_DONE is True
    # Real handler returned a verdict — not the wired:false stub.
    assert out.get("wired") is not False
    assert out.get("verdict") in {"PASS", "REFINE", "REJECT"}


def test_wrapper_returns_real_data_for_handoff_list(fresh_mcp_protocol, tmp_path):
    """``handoff_list`` against an empty dir returns a real (empty) listing,
    not a wired:false stub."""
    proto = fresh_mcp_protocol
    out = proto._tool_handoff_list(tmp_path, {"project_root": str(tmp_path)})
    assert out.get("wired") is not False
    # Real handler returns a structured listing — no stub.
    assert "schema_version" in out


def test_wrapper_returns_real_data_for_wisdom_query(fresh_mcp_protocol, tmp_path):
    """``wisdom_query`` against an empty wisdom DB returns real metadata."""
    proto = fresh_mcp_protocol
    out = proto._tool_wisdom_query(tmp_path, {"scope": "forge"})
    assert out.get("wired") is not False
    # Real handler returns query envelope, not the stub.
    assert "schema_version" in out


def test_bootstrap_swallows_import_error(monkeypatch, fresh_mcp_protocol):
    """If a3 can't be imported (rare — packaging error), the helper
    returns silently so callers can fall back to the stub message."""
    proto = fresh_mcp_protocol
    proto._A3_BOOTSTRAP_DONE = False
    real_import = __import__

    def fake_import(name, *a, **kw):
        if name == "atomadic_forge.a3_og_features.mcp_server":
            raise ImportError("simulated missing a3")
        return real_import(name, *a, **kw)

    monkeypatch.setattr("builtins.__import__", fake_import)
    proto._bootstrap_a3_handlers()  # must not raise
    assert proto._A3_BOOTSTRAP_DONE is True
