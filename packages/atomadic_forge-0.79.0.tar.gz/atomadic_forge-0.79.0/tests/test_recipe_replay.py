"""Tests for `forge replay` — deterministic recipe execution."""
from __future__ import annotations

from pathlib import Path

import pytest

from atomadic_forge.a3_og_features.recipe_replay import (
    SCHEMA_VERSION_REPLAY_V1,
    TOKENS_PER_LLM_DISPATCH,
    replay_recipe,
)


def test_unknown_recipe_raises(tmp_path: Path) -> None:
    with pytest.raises(KeyError):
        replay_recipe(recipe_name="not_a_real_recipe", project_root=tmp_path)


def test_dry_run_marks_all_skipped_no_savings(tmp_path: Path, monkeypatch) -> None:
    """Dry-run runs no commands, logs no savings."""
    # Inject a recipe with two trivial commands.
    from atomadic_forge.a1_at_functions import recipes as r
    monkeypatch.setitem(r._RECIPES, "test_demo", {
        "schema_version": "atomadic-forge.recipe/v1",
        "name": "test_demo",
        "validation_gate": ["python -c \"print('ok')\"",
                             "python -c \"print('also ok')\""],
    })
    report = replay_recipe(recipe_name="test_demo",
                            project_root=tmp_path, dry_run=True)
    assert report.schema_version == SCHEMA_VERSION_REPLAY_V1
    assert report.verdict == "DRY_RUN"
    assert report.skipped_count == 2
    assert report.pass_count == 0
    assert report.tokens_saved_estimate == 0


def test_all_pass_logs_full_savings(tmp_path: Path, monkeypatch) -> None:
    """All pass ⇒ verdict PASS and N × 80 token savings."""
    from atomadic_forge.a1_at_functions import recipes as r
    monkeypatch.setitem(r._RECIPES, "test_pass", {
        "schema_version": "atomadic-forge.recipe/v1",
        "name": "test_pass",
        "validation_gate": ["python -c \"print('a')\"",
                             "python -c \"print('b')\""],
    })
    report = replay_recipe(recipe_name="test_pass", project_root=tmp_path)
    assert report.verdict == "PASS"
    assert report.pass_count == 2
    assert report.fail_count == 0
    assert report.tokens_saved_estimate == 2 * TOKENS_PER_LLM_DISPATCH


def test_first_fail_skips_remaining_by_default(tmp_path: Path, monkeypatch) -> None:
    """stop_on_fail (default) marks remaining steps skipped after a fail."""
    from atomadic_forge.a1_at_functions import recipes as r
    monkeypatch.setitem(r._RECIPES, "test_fail", {
        "schema_version": "atomadic-forge.recipe/v1",
        "name": "test_fail",
        "validation_gate": [
            "python -c \"import sys; sys.exit(3)\"",
            "python -c \"print('never runs')\"",
        ],
    })
    report = replay_recipe(recipe_name="test_fail", project_root=tmp_path)
    assert report.verdict == "FAIL"
    assert report.fail_count == 1
    assert report.skipped_count == 1


def test_keep_going_runs_every_step(tmp_path: Path, monkeypatch) -> None:
    """stop_on_fail=False keeps running after a failure."""
    from atomadic_forge.a1_at_functions import recipes as r
    monkeypatch.setitem(r._RECIPES, "test_keep", {
        "schema_version": "atomadic-forge.recipe/v1",
        "name": "test_keep",
        "validation_gate": [
            "python -c \"import sys; sys.exit(1)\"",
            "python -c \"print('still runs')\"",
        ],
    })
    report = replay_recipe(recipe_name="test_keep",
                            project_root=tmp_path, stop_on_fail=False)
    assert report.verdict == "PARTIAL"
    assert report.pass_count == 1
    assert report.fail_count == 1
    assert report.skipped_count == 0
