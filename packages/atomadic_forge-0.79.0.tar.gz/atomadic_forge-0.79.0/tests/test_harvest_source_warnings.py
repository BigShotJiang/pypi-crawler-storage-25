"""Tests for GAP-014 fix — harvest must fail loudly on bad sources.

Pre-fix behavior: passing a non-existent source path or a source with
no scout-walkable symbols returned `candidate_count: 0` silently. Users
had no way to know whether the empty result meant "no graft candidates"
or "your path was wrong". Post-fix: the report carries `per_source`
and `source_warnings`, and the CLI exits 3 if every source was bad.
"""
from __future__ import annotations

from pathlib import Path

from atomadic_forge.a3_og_features.cherry_hunter import harvest


def _seed_minimal_target(tmp_path: Path) -> Path:
    """Build the smallest tier-organized package the scout walker
    accepts as a target."""
    pkg = tmp_path / "src" / "tgt"
    for tier in (
        "a0_qk_constants", "a1_at_functions", "a2_mo_composites",
        "a3_og_features", "a4_sy_orchestration",
    ):
        (pkg / tier).mkdir(parents=True, exist_ok=True)
        (pkg / tier / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "__init__.py").write_text(
        "\"\"\"tgt.\"\"\"\n__version__ = \"0.1.0\"\n", encoding="utf-8")
    (pkg / "a1_at_functions" / "real.py").write_text(
        "def add(a, b):\n    return a + b\n", encoding="utf-8")
    return tmp_path


def test_harvest_surfaces_missing_source(tmp_path):
    """Non-existent source path → per_source records exists=False and
    source_warnings carries a clear message."""
    target = _seed_minimal_target(tmp_path / "target")
    bad_source = tmp_path / "does-not-exist"
    report = harvest(target=target, sources=[bad_source])
    assert report["candidate_count"] == 0
    per_source = report["per_source"]
    assert len(per_source) == 1
    assert per_source[0]["exists"] is False
    warnings = report["source_warnings"]
    assert any("not found on disk" in w for w in warnings), warnings


def test_harvest_surfaces_empty_source(tmp_path):
    """Source path exists but has 0 walkable Python symbols → per_source
    records exists=True/symbol_count=0, source_warnings explains why."""
    target = _seed_minimal_target(tmp_path / "target")
    empty_source = tmp_path / "empty-source"
    empty_source.mkdir()
    (empty_source / "README.md").write_text("# nothing here\n", encoding="utf-8")
    report = harvest(target=target, sources=[empty_source])
    assert report["candidate_count"] == 0
    per_source = report["per_source"]
    assert len(per_source) == 1
    assert per_source[0]["exists"] is True
    assert per_source[0]["symbol_count"] == 0
    warnings = report["source_warnings"]
    assert any("0 symbols" in w for w in warnings), warnings


def test_harvest_no_warnings_when_source_is_healthy(tmp_path):
    """Healthy tier-organized source → per_source has symbol_count > 0
    and source_warnings is empty (no false-positive noise)."""
    target = _seed_minimal_target(tmp_path / "target")
    source_root = _seed_minimal_target(tmp_path / "source")
    # Add a function to the source that the target doesn't have.
    src_pkg = source_root / "src" / "tgt"
    (src_pkg / "a1_at_functions" / "extra.py").write_text(
        "def multiply(a, b):\n    return a * b\n", encoding="utf-8")
    report = harvest(target=target, sources=[source_root])
    per_source = report["per_source"]
    assert len(per_source) == 1
    assert per_source[0]["exists"] is True
    assert per_source[0]["symbol_count"] > 0
    assert report["source_warnings"] == []
