"""End-to-end tests: drive `forge` CLI + MCP dispatcher against synthetic
polyglot repos.

Hardens the integration boundary that unit tests can't cover:

  * CliRunner invokes the actual Typer app (``forge recon``, ``forge wire``,
    ``forge certify``, ``forge plan``, ``forge auto``) on tmp polyglot
    repos and asserts JSON outputs match expected schemas + counts.
  * The MCP dispatcher (used by ``forge mcp serve`` and via
    :mod:`mcp_protocol.dispatch_request`) is exercised through the
    ``_tool_*`` adapters that LLM agents and IDEs call into.

Both layers must produce identical structured data for every supported
language.  Fixtures are built fresh per test so the host repo isn't
involved.
"""
from __future__ import annotations

import json
from pathlib import Path

import typer.testing

from atomadic_forge.a1_at_functions import mcp_protocol
from atomadic_forge.a4_sy_orchestration.cli import app

runner = typer.testing.CliRunner()


# ────────────────────────────────────────────────────────────────────
# Synthetic polyglot fixture builders
# ────────────────────────────────────────────────────────────────────


def _rust_repo(root: Path) -> Path:
    """Tier-organised Rust source tree (no Cargo.toml — tests target src/)."""
    src = root / "src"
    src.mkdir()
    (src / "a0_qk_constants").mkdir()
    (src / "a0_qk_constants" / "limits.rs").write_text(
        "pub const MAX_USERS: u32 = 100;\n", encoding="utf-8",
    )
    (src / "a1_at_functions").mkdir()
    (src / "a1_at_functions" / "math.rs").write_text(
        "pub fn add(a: u8, b: u8) -> u8 { a + b }\n"
        "pub fn sub(a: u8, b: u8) -> u8 { a - b }\n",
        encoding="utf-8",
    )
    (src / "a2_mo_composites").mkdir()
    (src / "a2_mo_composites" / "user.rs").write_text(
        "pub struct User { pub name: String }\n"
        "impl User { pub fn new(name: String) -> Self { Self { name } } }\n",
        encoding="utf-8",
    )
    return src


def _go_repo(root: Path) -> Path:
    pkg = root / "pkg"
    (pkg / "a1_at_functions").mkdir(parents=True)
    (pkg / "a1_at_functions" / "math.go").write_text(
        "package a1_at_functions\n"
        "func Add(a, b int) int { return a + b }\n",
        encoding="utf-8",
    )
    (pkg / "a3_og_features").mkdir()
    (pkg / "a3_og_features" / "service.go").write_text(
        "package a3_og_features\n"
        'import "net/http"\n'
        "type Service struct { client *http.Client }\n"
        "func NewService() *Service { return &Service{} }\n",
        encoding="utf-8",
    )
    return root


def _swift_repo(root: Path) -> Path:
    sources = root / "Sources" / "Demo"
    (sources / "a1_at_functions").mkdir(parents=True)
    (sources / "a1_at_functions" / "Math.swift").write_text(
        "public func add(_ a: Int, _ b: Int) -> Int { return a + b }\n",
        encoding="utf-8",
    )
    (sources / "a2_mo_composites").mkdir()
    (sources / "a2_mo_composites" / "User.swift").write_text(
        "public class User {\n"
        "    public let name: String\n"
        "    public init(name: String) { self.name = name }\n"
        "    public func greet() -> String { return \"Hi \\(name)\" }\n"
        "}\n",
        encoding="utf-8",
    )
    return root


def _kotlin_repo(root: Path) -> Path:
    base = root / "src" / "main" / "kotlin" / "com" / "demo"
    (base / "a1_at_functions").mkdir(parents=True)
    (base / "a1_at_functions" / "Math.kt").write_text(
        "package com.demo.a1_at_functions\n"
        "fun add(a: Int, b: Int): Int = a + b\n",
        encoding="utf-8",
    )
    (base / "a2_mo_composites").mkdir()
    (base / "a2_mo_composites" / "User.kt").write_text(
        "package com.demo.a2_mo_composites\n"
        "data class User(val name: String) { fun greet(): String = \"Hi $name\" }\n",
        encoding="utf-8",
    )
    return root


def _polyglot_repo_with_violation(root: Path) -> Path:
    """A 4-language tree with one upward-import violation per native lang."""
    # Rust: a1 → a3
    (root / "a1_at_functions").mkdir()
    (root / "a1_at_functions" / "bad.rs").write_text(
        "use crate::a3_og_features::Whatever;\npub fn x() {}\n",
        encoding="utf-8",
    )
    # Go: a1 → a3
    (root / "a1_at_functions" / "bad.go").write_text(
        'package a1_at_functions\nimport "x.com/a3_og_features"\n',
        encoding="utf-8",
    )
    # Swift: a1 → a3
    (root / "a1_at_functions" / "Bad.swift").write_text(
        "import a3_og_features\npublic func bad() {}\n",
        encoding="utf-8",
    )
    # Kotlin: a1 → a3
    (root / "a1_at_functions" / "Bad.kt").write_text(
        "package com.x.a1_at_functions\n"
        "import com.x.a3_og_features.Foo\n"
        "fun bad() {}\n",
        encoding="utf-8",
    )
    (root / "a3_og_features").mkdir()
    (root / "a3_og_features" / "ok.rs").write_text("pub fn ok() {}\n", encoding="utf-8")
    return root


# ────────────────────────────────────────────────────────────────────
# CLI: ``forge recon`` on every native-lang repo
# ────────────────────────────────────────────────────────────────────


def test_cli_recon_rust_repo(tmp_path):
    src = _rust_repo(tmp_path)
    result = runner.invoke(app, ["recon", str(src), "--json"])
    assert result.exit_code == 0, result.stdout
    data = json.loads(result.stdout)
    # Three .rs files: limits.rs, math.rs, user.rs
    assert data["rust_file_count"] == 3
    assert data["primary_language"] == "rust"
    assert data["language_distribution"]["rust"] == 3


def test_cli_recon_go_repo(tmp_path):
    _go_repo(tmp_path)
    result = runner.invoke(app, ["recon", str(tmp_path), "--json"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data["go_file_count"] == 2
    assert data["primary_language"] == "go"


def test_cli_recon_swift_repo(tmp_path):
    _swift_repo(tmp_path)
    result = runner.invoke(app, ["recon", str(tmp_path), "--json"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data["swift_file_count"] == 2
    assert data["primary_language"] == "swift"


def test_cli_recon_kotlin_repo(tmp_path):
    _kotlin_repo(tmp_path)
    result = runner.invoke(app, ["recon", str(tmp_path), "--json"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data["kotlin_file_count"] == 2
    assert data["primary_language"] == "kotlin"


# ────────────────────────────────────────────────────────────────────
# CLI: ``forge wire`` detects violations across native langs
# ────────────────────────────────────────────────────────────────────


def test_cli_wire_clean_rust_repo(tmp_path):
    src = _rust_repo(tmp_path)
    result = runner.invoke(app, ["wire", str(src), "--json"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data["verdict"] == "PASS"
    assert data["violation_count"] == 0


def test_cli_wire_violations_per_native_language(tmp_path):
    src = _polyglot_repo_with_violation(tmp_path)
    result = runner.invoke(app, ["wire", str(src), "--json"])
    # `forge wire` exits non-zero when violations exist (default behaviour).
    assert result.exit_code in (0, 1)
    data = json.loads(result.stdout)
    assert data["verdict"] == "FAIL"
    languages_violated = {v["language"] for v in data["violations"]}
    assert {"rust", "go", "swift", "kotlin"}.issubset(languages_violated)
    # F-codes are stable for canonical pairs.
    f_codes = {v["f_code"] for v in data["violations"]}
    assert "F0042" in f_codes  # a1 → a3


# ────────────────────────────────────────────────────────────────────
# CLI: ``forge plan`` (auto_plan) handles polyglot repos
# ────────────────────────────────────────────────────────────────────


def test_cli_plan_runs_on_rust_repo(tmp_path):
    src = _rust_repo(tmp_path)
    # `plan` requires a positional TARGET; the parent of `src/` is the
    # root of the synthetic crate.  Option flag is ``--top`` (not
    # ``--top-n``).
    result = runner.invoke(app, ["plan", str(src.parent), "--top", "3", "--json"])
    assert result.exit_code == 0, result.stdout
    data = json.loads(result.stdout)
    assert "verdict" in data
    assert "top_actions" in data


# ────────────────────────────────────────────────────────────────────
# MCP dispatcher: same tools agents call via JSON-RPC
# ────────────────────────────────────────────────────────────────────


def test_mcp_recon_dispatch_rust(tmp_path):
    src = _rust_repo(tmp_path)
    out = mcp_protocol._tool_recon(tmp_path, {"target": str(src)})
    assert out["schema_version"].startswith("atomadic-forge.scout")
    assert out["rust_file_count"] == 3
    assert out["language_distribution"]["rust"] == 3


def test_mcp_recon_dispatch_go(tmp_path):
    _go_repo(tmp_path)
    out = mcp_protocol._tool_recon(tmp_path, {"target": str(tmp_path)})
    assert out["go_file_count"] == 2


def test_mcp_recon_dispatch_swift(tmp_path):
    _swift_repo(tmp_path)
    out = mcp_protocol._tool_recon(tmp_path, {"target": str(tmp_path)})
    assert out["swift_file_count"] == 2


def test_mcp_recon_dispatch_kotlin(tmp_path):
    _kotlin_repo(tmp_path)
    out = mcp_protocol._tool_recon(tmp_path, {"target": str(tmp_path)})
    assert out["kotlin_file_count"] == 2


def test_mcp_wire_dispatch_polyglot_violations(tmp_path):
    src = _polyglot_repo_with_violation(tmp_path)
    out = mcp_protocol._tool_wire(tmp_path, {"source": str(src)})
    assert out["verdict"] == "FAIL"
    by_lang: dict[str, int] = {}
    for v in out["violations"]:
        by_lang[v["language"]] = by_lang.get(v["language"], 0) + 1
    for lang in ("rust", "go", "swift", "kotlin"):
        assert by_lang.get(lang, 0) >= 1, f"{lang} violation missing"


def test_mcp_wire_dispatch_with_suggest_repairs(tmp_path):
    """The optional `suggest_repairs` flag should attach a proposed_fix
    field to every native-language violation, just like Python/JS."""
    src = _polyglot_repo_with_violation(tmp_path)
    out = mcp_protocol._tool_wire(
        tmp_path, {"source": str(src), "suggest_repairs": True},
    )
    for v in out["violations"]:
        # Either a proposed mechanical fix (mv command sketch) or the
        # reasoning string — but never empty.
        assert v.get("proposed_fix"), v


def test_mcp_recon_verbose_returns_symbols(tmp_path):
    """verbose=True keeps the `symbols` list — agents that need per-symbol
    detail set this."""
    src = _rust_repo(tmp_path)
    out = mcp_protocol._tool_recon(
        tmp_path, {"target": str(src), "verbose": True},
    )
    assert "symbols" in out
    rust = [s for s in out["symbols"] if s.get("language") == "rust"]
    assert any(s["kind"] == "function" and s["name"] == "add" for s in rust)
    assert any(s["kind"] == "class" and s["name"] == "User" for s in rust)
    assert any(s["kind"] == "method" and s["name"] == "User.new" for s in rust)
    assert any(s["kind"] == "const" and s["name"] == "MAX_USERS" for s in rust)


# ────────────────────────────────────────────────────────────────────
# Cross-language consistency: CLI and MCP return the same shape
# ────────────────────────────────────────────────────────────────────


def test_cli_and_mcp_agree_on_rust_recon(tmp_path):
    src = _rust_repo(tmp_path)
    cli_data = json.loads(
        runner.invoke(app, ["recon", str(src), "--json"]).stdout
    )
    mcp_data = mcp_protocol._tool_recon(tmp_path, {"target": str(src)})
    # Both surfaces must agree on the headline counts.
    for k in ("rust_file_count", "primary_language",
              "python_file_count", "javascript_file_count",
              "typescript_file_count", "swift_file_count",
              "kotlin_file_count", "go_file_count"):
        assert cli_data[k] == mcp_data[k], f"mismatch on {k}"


def test_cli_and_mcp_agree_on_polyglot_violation_count(tmp_path):
    src = _polyglot_repo_with_violation(tmp_path)
    cli_data = json.loads(
        runner.invoke(app, ["wire", str(src), "--json"]).stdout
    )
    mcp_data = mcp_protocol._tool_wire(tmp_path, {"source": str(src)})
    assert cli_data["violation_count"] == mcp_data["violation_count"]
    assert cli_data["verdict"] == mcp_data["verdict"]


# ────────────────────────────────────────────────────────────────────
# Smoke: forge auto on a Python+native mixed repo
# ────────────────────────────────────────────────────────────────────


def test_forge_recon_handles_node_modules_for_rust_too(tmp_path):
    """node_modules / target / .git must be skipped for native-lang files
    just like for Python — vendored Rust crates inside target/ shouldn't
    inflate the rust_file_count."""
    (tmp_path / "target").mkdir()
    (tmp_path / "target" / "stub.rs").write_text("pub fn vendored() {}\n", encoding="utf-8")
    (tmp_path / "real.rs").write_text("pub fn legit() {}\n", encoding="utf-8")
    out = mcp_protocol._tool_recon(tmp_path, {"target": str(tmp_path)})
    assert out["rust_file_count"] == 1
