"""Tests for a1 maintainability_index — radon MI synthesis."""
from pathlib import Path

from atomadic_forge.a1_at_functions.maintainability_index import (
    SCHEMA_VERSION_MAINTAINABILITY_V1,
    compute_maintainability_index,
)


def test_schema_version(tmp_path):
    result = compute_maintainability_index(tmp_path)
    assert result["schema_version"] == SCHEMA_VERSION_MAINTAINABILITY_V1


def test_unavailable_on_empty_dir(tmp_path):
    result = compute_maintainability_index(tmp_path)
    assert result["available"] is False
    assert "reason" in result


def _make_pkg_with_module(tmp_path, src="def fn():\n    return 1\n"):
    pkg = tmp_path / "src" / "mypkg"
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "module.py").write_text(src, encoding="utf-8")
    return pkg


def test_available_on_valid_package(tmp_path):
    _make_pkg_with_module(tmp_path)
    result = compute_maintainability_index(tmp_path)
    assert result["available"] is True
    assert result["modules_scanned"] >= 1


def test_result_fields_present(tmp_path):
    _make_pkg_with_module(tmp_path)
    result = compute_maintainability_index(tmp_path)
    for key in ("avg_mi", "median_mi", "rank_distribution", "worst_modules", "best_modules"):
        assert key in result, f"missing {key}"


def test_rank_distribution_keys(tmp_path):
    _make_pkg_with_module(tmp_path)
    result = compute_maintainability_index(tmp_path)
    dist = result["rank_distribution"]
    for rank in ("A", "B", "C", "D"):
        assert rank in dist


def test_mi_score_range(tmp_path):
    _make_pkg_with_module(tmp_path)
    result = compute_maintainability_index(tmp_path)
    for m in result["worst_modules"]:
        assert 0.0 <= m["mi_score"] <= 100.0
        assert m["rank"] in ("A", "B", "C", "D")


def test_on_forge_itself():
    root = Path(__file__).parent.parent
    result = compute_maintainability_index(root)
    assert result["available"] is True
    assert result["modules_scanned"] > 0
    assert 0 <= result["avg_mi"] <= 100
