"""Tests for the v0.13 wisdom DB — IO, recall, capture, and the
recon/verify hooks that auto-fire it.

Wisdom is the cross-session institutional memory layer between raw
lineage events and curated recipes. These tests pin five properties:

1. Round-trip: record → list → query returns what we wrote.
2. Empty-state safety: query/recall on a fresh repo returns empty
   results, not errors.
3. Recall ranking: scope/tag matches outrank generic high-confidence.
4. Capture threshold: trivial sessions don't trigger prompts; real
   work does.
5. Supersession: superseded entries drop from active_wisdom but
   stay in load_wisdom (audit trail).
"""
from __future__ import annotations

from pathlib import Path

import pytest

from atomadic_forge.a0_qk_constants.wisdom_constants import (
    DEFAULT_MIN_LINEAGE_EVENTS,
    SCHEMA_VERSION_WISDOM_V1,
    WISDOM_SCOPE_FORGE,
    WISDOM_SCOPE_GENERAL,
    WISDOM_SCOPE_REPO,
)
from atomadic_forge.a1_at_functions.wisdom_capture import (
    assemble_capture_prompt,
    threshold_met,
)
from atomadic_forge.a1_at_functions.wisdom_io import (
    active_wisdom,
    append_wisdom,
    load_wisdom,
    make_entry,
    wisdom_file_path,
)
from atomadic_forge.a1_at_functions.wisdom_recall import rank_for_recall
from atomadic_forge.a3_og_features.wisdom_feature import (
    list_wisdom,
    query_wisdom,
    recall_for_recon,
    record_wisdom,
)

# ── round-trip ──────────────────────────────────────────────────────

def test_record_then_query_roundtrip(tmp_path: Path):
    out = record_wisdom(
        project_root=tmp_path,
        insight="Worker MCP requires args.repo, not args.target.",
        scope=WISDOM_SCOPE_FORGE,
        tags=["worker", "contract"],
        confidence=0.95,
    )
    assert out["recorded"] is True
    assert out["entry"]["id"].startswith("WIS-")
    assert out["entry"]["schema_version"] == SCHEMA_VERSION_WISDOM_V1

    listed = list_wisdom(project_root=tmp_path)
    assert listed["entry_count"] == 1
    assert listed["entries"][0]["insight"].startswith("Worker MCP")


def test_record_idempotent_on_duplicate_id(tmp_path: Path):
    """Same insight + same timestamp produces same id; re-write is a no-op."""
    entry = make_entry(insight="dup test", scope="repo", confidence=0.5)
    p1 = append_wisdom(tmp_path, entry)
    p2 = append_wisdom(tmp_path, entry)
    assert p1 == p2
    # File contains exactly one entry.
    assert len(load_wisdom(tmp_path)) == 1


# ── empty-state safety ──────────────────────────────────────────────

def test_query_on_empty_repo_returns_clean_empty(tmp_path: Path):
    out = query_wisdom(project_root=tmp_path, scope="repo", top_n=5)
    assert out["total_entries_considered"] == 0
    assert out["results_returned"] == 0
    assert out["top_entries"] == []


def test_recall_for_recon_handles_missing_db(tmp_path: Path):
    """recon hook calls this; must not crash on a fresh repo."""
    out = recall_for_recon(project_root=tmp_path)
    assert out["results_returned"] == 0
    assert out["top_entries"] == []


def test_iter_wisdom_skips_malformed_lines(tmp_path: Path):
    path = wisdom_file_path(tmp_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        '{"id":"WIS-good","insight":"valid","scope":"repo"}\n'
        'not-a-json-line\n'
        '{"id":"WIS-good2","insight":"also valid","scope":"repo"}\n',
        encoding="utf-8",
    )
    entries = load_wisdom(tmp_path)
    assert len(entries) == 2  # malformed line skipped
    assert {e["id"] for e in entries} == {"WIS-good", "WIS-good2"}


# ── recall ranking ──────────────────────────────────────────────────

def test_scope_match_outranks_generic_high_confidence():
    entries = [
        {  # generic, high confidence
            "id": "WIS-generic",
            "insight": "generic wisdom",
            "scope": WISDOM_SCOPE_GENERAL,
            "tags": [],
            "confidence": 0.99,
            "timestamp_utc": "2026-01-01T00:00:00Z",
        },
        {  # repo-scoped, medium confidence — should win on a repo query
            "id": "WIS-repo",
            "insight": "repo specific",
            "scope": WISDOM_SCOPE_REPO,
            "tags": [],
            "confidence": 0.50,
            "timestamp_utc": "2026-01-01T00:00:00Z",
        },
    ]
    out = rank_for_recall(entries, scope=WISDOM_SCOPE_REPO, top_n=2)
    assert out["top_entries"][0]["id"] == "WIS-repo"


def test_tag_overlap_boosts_relevance():
    entries = [
        {"id": "A", "insight": "x", "scope": "repo",
         "tags": ["worker"], "confidence": 0.5,
         "timestamp_utc": "2026-01-01T00:00:00Z"},
        {"id": "B", "insight": "y", "scope": "repo",
         "tags": ["worker", "contract", "drift"], "confidence": 0.5,
         "timestamp_utc": "2026-01-01T00:00:00Z"},
    ]
    out = rank_for_recall(entries, tags=["worker", "contract", "drift"], top_n=2)
    assert out["top_entries"][0]["id"] == "B"


def test_text_substring_matches_case_insensitive():
    entries = [
        {"id": "X", "insight": "Worker MCP requires args.repo.",
         "scope": "forge", "tags": [], "confidence": 0.5,
         "timestamp_utc": "2026-01-01T00:00:00Z"},
        {"id": "Y", "insight": "Unrelated wisdom about something else.",
         "scope": "forge", "tags": [], "confidence": 0.5,
         "timestamp_utc": "2026-01-01T00:00:00Z"},
    ]
    out = rank_for_recall(entries, text="worker", top_n=2)
    assert out["top_entries"][0]["id"] == "X"


# ── capture threshold ───────────────────────────────────────────────

def test_threshold_met_for_real_work():
    assert threshold_met(
        lineage_event_count=DEFAULT_MIN_LINEAGE_EVENTS,
        score_delta=0.0,
        session_secs=0,
    ) is True


def test_threshold_not_met_for_trivial_session():
    assert threshold_met(
        lineage_event_count=0,
        score_delta=0.0,
        session_secs=0,
    ) is False


def test_threshold_met_for_score_movement():
    assert threshold_met(
        lineage_event_count=0,
        score_delta=2.5,
        session_secs=0,
    ) is True


def test_capture_prompt_emits_draft_when_threshold_met():
    out = assemble_capture_prompt(
        project_name="test-repo",
        score_before=85.0,
        score_after=95.0,
        lineage_events=[
            "fixed wire violation in a3/foo.py",
            "added 3 tests",
            "certify score moved 85 → 95",
            "schema_version registry updated",
        ],
        session_secs=300,
    )
    assert out["auto_record_threshold_met"] is True
    assert "test-repo" in out["suggested_insight"]
    assert "85.0 → 95.0" in out["suggested_insight"]
    assert "+10.0" in out["suggested_insight"]
    assert "wire" in out["draft_tags"]
    assert "tests" in out["draft_tags"]
    assert "schema" in out["draft_tags"]
    assert out["next_command"] is not None


def test_capture_prompt_silent_below_threshold():
    out = assemble_capture_prompt(
        project_name="test-repo",
        score_before=100.0,
        score_after=100.0,
        lineage_events=[],
        session_secs=0,
    )
    assert out["auto_record_threshold_met"] is False
    assert out["next_command"] is None


# ── supersession ────────────────────────────────────────────────────

def test_supersession_drops_from_active_but_stays_in_load(tmp_path: Path):
    e1 = record_wisdom(
        project_root=tmp_path, insight="initial wisdom",
        scope="repo", confidence=0.5,
    )
    old_id = e1["entry"]["id"]
    record_wisdom(
        project_root=tmp_path, insight="corrected wisdom — initial was wrong",
        scope="repo", confidence=0.9, supersedes=old_id,
    )
    # Both visible in load
    assert len(load_wisdom(tmp_path)) == 2
    # Only the corrected one in active
    active = active_wisdom(tmp_path)
    assert len(active) == 1
    assert active[0]["insight"].startswith("corrected wisdom")


# ── content-shape contract ──────────────────────────────────────────

def test_make_entry_rejects_empty_insight():
    with pytest.raises(ValueError):
        make_entry(insight="", scope="repo")
    with pytest.raises(ValueError):
        make_entry(insight="   ", scope="repo")


def test_make_entry_clamps_confidence_to_unit_interval():
    e_high = make_entry(insight="x", scope="repo", confidence=2.5)
    e_low = make_entry(insight="x", scope="repo", confidence=-0.5)
    assert e_high["confidence"] == 1.0
    assert e_low["confidence"] == 0.0


def test_make_entry_dedupes_and_sorts_tags():
    e = make_entry(
        insight="x", scope="repo",
        tags=["b", "a", "b", "c", "a"],
    )
    assert e["tags"] == ["a", "b", "c"]
