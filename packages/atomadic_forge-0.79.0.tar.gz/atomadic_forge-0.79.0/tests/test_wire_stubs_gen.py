"""Tests for a1 wire_stubs_gen — MCP handler + CLI stub auto-generator."""
from pathlib import Path

from atomadic_forge.a1_at_functions.wire_stubs_gen import (
    SCHEMA_VERSION_WIRE_STUBS_V1,
    generate_wire_stubs,
)


def test_wire_stubs_schema_version_on_known_function():
    root = Path(__file__).parent.parent
    result = generate_wire_stubs(root, module_stem="git_churn", fn_name="compute_git_churn")
    assert result["schema_version"] == SCHEMA_VERSION_WIRE_STUBS_V1
    assert result["available"] is True


def test_wire_stubs_generates_mcp_handler():
    root = Path(__file__).parent.parent
    result = generate_wire_stubs(root, module_stem="git_churn", fn_name="compute_git_churn")
    handler = result["mcp_handler"]
    assert "def _tool_" in handler
    assert "compute_git_churn" in handler
    assert "project_root" in handler


def test_wire_stubs_generates_cli_command():
    root = Path(__file__).parent.parent
    result = generate_wire_stubs(root, module_stem="git_churn", fn_name="compute_git_churn")
    cli = result["cli_command"]
    assert "@app.command(" in cli
    assert "compute_git_churn" in cli
    assert "typer" in cli


def test_wire_stubs_generates_test_skeleton():
    root = Path(__file__).parent.parent
    result = generate_wire_stubs(root, module_stem="git_churn", fn_name="compute_git_churn")
    test = result["test_skeleton"]
    assert "def test_" in test
    assert "compute_git_churn" in test


def test_wire_stubs_action_and_cli_name():
    root = Path(__file__).parent.parent
    result = generate_wire_stubs(root, module_stem="git_churn", fn_name="compute_git_churn")
    assert result["action_name"] == "git_churn"
    assert result["cli_command_name"] == "git-churn"


def test_wire_stubs_unavailable_on_missing_function(tmp_path):
    result = generate_wire_stubs(tmp_path, module_stem="nonexistent", fn_name="fake_fn")
    assert result["available"] is False
    assert "reason" in result


def test_wire_stubs_on_call_graph_summary():
    root = Path(__file__).parent.parent
    result = generate_wire_stubs(
        root, module_stem="call_graph", fn_name="build_call_graph_summary"
    )
    assert result["available"] is True
    assert result["action_name"] == "call_graph_summary"
    assert result["cli_command_name"] == "call-graph-summary"
