"""Tests for the v0.14.0a5 Nexus bridge.

Pin three properties:

1. ``NexusToolNotShipped`` is raised for any tool not in
   ``LIVE_NEXUS_TOOLS`` — defensive against shipping a feature
   that depends on hypothetical primitives.
2. ``mirror_wisdom_to_lineage`` skips with a clear reason when
   the env has no auth token (default test environment).
3. Confidence threshold gates the mirror — low-conf entries
   never hit the network.
"""
from __future__ import annotations

import pytest

from atomadic_forge.a0_qk_constants.nexus_constants import (
    LIVE_NEXUS_TOOLS,
    NEXUS_TOOL_LINEAGE_RECORD,
)
from atomadic_forge.a2_mo_composites.nexus_client import (
    NexusClient,
    NexusToolNotShipped,
)
from atomadic_forge.a3_og_features.nexus_bridge import (
    is_nexus_configured,
    mirror_ast_locks_to_lineage,
    mirror_consensus_to_lineage,
    mirror_wisdom_to_lineage,
)


def _clear_nexus_env(monkeypatch):
    for name in (
        "ATOMADIC_MASTER_KEY",
        "ATOMADIC_SUBSCRIPTION_KEY",
        "FORGE_API_KEY",
        "FORGE_MASTER_API_KEY",
        "AAAA_NEXUS_API_KEY",
        "ATOMADIC_VAULT_ENV",
    ):
        monkeypatch.delenv(name, raising=False)

# ── guard against unshipped primitives ──────────────────────────────

@pytest.mark.parametrize("hypothetical_tool", [
    "nexus_consensus_create",
    "nexus_consensus_vote",
    "nexus_consensus_result",
    "nexus_swarm_relay",
    "nexus_swarm_inbox",
    "nexus_agent_plan",
    "nexus_agent_topology",
    "nexus_lora_capture_fix",
])
def test_call_refuses_unshipped_nexus_tool(hypothetical_tool: str):
    client = NexusClient(base_url="https://atomadic.tech",
                          auth_token="fake-token-for-test")
    with pytest.raises(NexusToolNotShipped) as exc_info:
        client.call(hypothetical_tool, {"x": 1})
    msg = str(exc_info.value)
    assert hypothetical_tool in msg
    assert "WIS-cog-2026-05-06-handshake" in msg


def test_live_tools_set_is_exactly_seven():
    """The 7 primitives Cognition's handshake confirmed exist on the
    deployed Nexus. Adding more requires re-probing tools/list."""
    assert len(LIVE_NEXUS_TOOLS) == 7
    assert NEXUS_TOOL_LINEAGE_RECORD in LIVE_NEXUS_TOOLS


# ── bridge skip-paths ───────────────────────────────────────────────

def test_mirror_wisdom_skips_below_confidence_threshold(monkeypatch):
    monkeypatch.setenv("ATOMADIC_MASTER_KEY", "test-token")
    out = mirror_wisdom_to_lineage(
        wisdom_entry={"id": "WIS-x", "confidence": 0.5},
        min_confidence=0.85,
    )
    assert out["mirrored"] is False
    assert "0.50" in out["reason"]
    assert "0.85" in out["reason"]


def test_mirror_wisdom_skips_when_no_auth(monkeypatch):
    _clear_nexus_env(monkeypatch)
    out = mirror_wisdom_to_lineage(
        wisdom_entry={"id": "WIS-x", "confidence": 0.95},
    )
    assert out["mirrored"] is False
    assert "no auth" in out["reason"]
    assert "x402" in out["premium_hint"]


def test_mirror_consensus_skips_when_no_auth(monkeypatch):
    _clear_nexus_env(monkeypatch)
    out = mirror_consensus_to_lineage(
        consensus_id="CNS-x", intent="test",
        proposer="test", verdict="PASS", tally={"approve": 3},
    )
    assert out["mirrored"] is False
    assert "no auth" in out["reason"]


def test_is_nexus_configured_reflects_env(monkeypatch):
    _clear_nexus_env(monkeypatch)
    assert is_nexus_configured() is False
    monkeypatch.setenv("ATOMADIC_MASTER_KEY", "test")
    assert is_nexus_configured() is True


# ── env-var precedence ──────────────────────────────────────────────

def test_subscription_key_preferred_over_master(monkeypatch):
    """Subscription key is narrower scope; preferred when both set."""
    monkeypatch.setenv("ATOMADIC_MASTER_KEY", "master-key")
    monkeypatch.setenv("ATOMADIC_SUBSCRIPTION_KEY", "sub-key")
    client = NexusClient.from_env()
    assert client.auth_token == "sub-key"


def test_master_key_used_when_no_subscription(monkeypatch):
    _clear_nexus_env(monkeypatch)
    monkeypatch.setenv("ATOMADIC_MASTER_KEY", "master-key")
    client = NexusClient.from_env()
    assert client.auth_token == "master-key"


def test_no_keys_yields_no_token(monkeypatch):
    _clear_nexus_env(monkeypatch)
    client = NexusClient.from_env()
    assert client.auth_token is None


def test_forge_master_key_alias_is_used(monkeypatch):
    _clear_nexus_env(monkeypatch)
    monkeypatch.setenv("FORGE_MASTER_API_KEY", "ak_master_test")
    client = NexusClient.from_env()
    assert client.auth_token == "ak_master_test"


def test_vault_env_file_supplies_nexus_key(tmp_path, monkeypatch):
    _clear_nexus_env(monkeypatch)
    vault = tmp_path / "VAULT.env"
    vault.write_text(
        "AAAA_NEXUS_URL=https://nexus.example\n"
        "FORGE_MASTER_API_KEY='ak_master_from_vault'\n",
        encoding="utf-8",
    )
    monkeypatch.setenv("ATOMADIC_VAULT_ENV", str(vault))

    client = NexusClient.from_env()

    assert client.base_url == "https://nexus.example"
    assert client.auth_token == "ak_master_from_vault"


def test_ast_lock_mirror_skips_with_premium_hint_when_no_auth(monkeypatch):
    _clear_nexus_env(monkeypatch)
    out = mirror_ast_locks_to_lineage(
        ast_scope_plan={
            "schema_version": "atomadic-forge.ast_scope_plan/v1",
            "blueprint": {"node_count": 0, "compressed_context": {}},
            "locks": {"locks": []},
        },
    )
    assert out["mirrored"] is False
    assert "no auth" in out["reason"]
    assert "x402" in out["premium_hint"]


def test_ast_lock_mirror_uses_live_lineage_record(monkeypatch):
    from atomadic_forge.a3_og_features import nexus_bridge

    captured = {}

    class FakeClient:
        def lineage_record(self, *, intent, payload):
            captured["intent"] = intent
            captured["payload"] = payload
            return {"ok": True}

    monkeypatch.setattr(nexus_bridge, "_get_client", lambda: FakeClient())
    out = mirror_ast_locks_to_lineage(
        ast_scope_plan={
            "schema_version": "atomadic-forge.ast_scope_plan/v1",
            "blueprint": {
                "node_count": 1,
                "compressed_context": {"token_savings_pct": 95.0},
            },
            "locks": {
                "blueprint_hash": "abc",
                "locks": [{"lock_id": "lock-1"}],
            },
        },
    )

    assert out["mirrored"] is True
    assert captured["intent"] == "ast_scope_locks_minted"
    assert captured["payload"]["lock_count"] == 1
    assert captured["payload"]["blueprint_hash"] == "abc"
