"""Tests for the behavioral pytest runner — the breakthrough check."""

from __future__ import annotations

from pathlib import Path

from atomadic_forge.a1_at_functions.test_runner import (
    _parse_pytest_summary,
    run_pytest,
)


def _scaffold(tmp_path: Path, package: str = "demo") -> Path:
    pkg = tmp_path / "src" / package
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    return tmp_path


def test_no_tests_dir_returns_did_not_run(tmp_path):
    _scaffold(tmp_path)
    rep = run_pytest(output_root=tmp_path, package="demo")
    assert rep["ran"] is False
    assert rep["passed"] == 0
    assert rep["pass_ratio"] == 0.0


def test_runs_passing_tests_and_credits_full_ratio(tmp_path):
    root = _scaffold(tmp_path)
    pkg = root / "src" / "demo"
    (pkg / "add.py").write_text("def add(a, b):\n    return a + b\n",
                                  encoding="utf-8")
    tests = root / "tests"
    tests.mkdir()
    (tests / "__init__.py").write_text("", encoding="utf-8")
    (tests / "conftest.py").write_text(
        "import sys\nfrom pathlib import Path\n"
        "sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'src'))\n",
        encoding="utf-8")
    (tests / "test_add.py").write_text(
        "from demo.add import add\n"
        "def test_add(): assert add(2, 3) == 5\n",
        encoding="utf-8")
    rep = run_pytest(output_root=root, package="demo")
    assert rep["ran"] is True
    assert rep["passed"] == 1
    assert rep["failed"] == 0
    assert rep["pass_ratio"] == 1.0


def test_runner_ignores_parent_pytest_addopts(tmp_path):
    parent = tmp_path / "parent"
    parent.mkdir()
    (parent / "pyproject.toml").write_text(
        "[tool.pytest.ini_options]\naddopts = '-q'\n",
        encoding="utf-8",
    )
    root = _scaffold(parent / "generated")
    pkg = root / "src" / "demo"
    (pkg / "add.py").write_text("def add(a, b):\n    return a + b\n",
                                  encoding="utf-8")
    tests = root / "tests"
    tests.mkdir()
    (tests / "test_add.py").write_text(
        "from demo.add import add\n"
        "def test_add(): assert add(2, 3) == 5\n",
        encoding="utf-8",
    )

    rep = run_pytest(output_root=root, package="demo")

    assert rep["ran"] is True
    assert rep["passed"] == 1
    assert rep["pass_ratio"] == 1.0


def test_catches_failing_tests(tmp_path):
    """The breakthrough behavior: identity-function stubs fail real tests."""
    root = _scaffold(tmp_path)
    pkg = root / "src" / "demo"
    # Identity-function stub — gamed wire and import in earlier refines.
    (pkg / "uppercase.py").write_text(
        "def uppercase(text):\n    return text\n",
        encoding="utf-8")
    tests = root / "tests"
    tests.mkdir()
    (tests / "__init__.py").write_text("", encoding="utf-8")
    (tests / "conftest.py").write_text(
        "import sys\nfrom pathlib import Path\n"
        "sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'src'))\n",
        encoding="utf-8")
    (tests / "test_uppercase.py").write_text(
        "from demo.uppercase import uppercase\n"
        "def test_uppercase():\n    assert uppercase('hi') == 'HI'\n",
        encoding="utf-8")
    rep = run_pytest(output_root=root, package="demo")
    assert rep["ran"] is True
    assert rep["passed"] == 0
    assert rep["failed"] == 1
    assert rep["pass_ratio"] == 0.0
    # The failure should be visible in the summary
    assert "FAIL" in rep["pytest_summary"].upper() or rep["failure_excerpts"]


def test_partial_pass_ratio(tmp_path):
    root = _scaffold(tmp_path)
    pkg = root / "src" / "demo"
    (pkg / "ops.py").write_text(
        "def add(a, b): return a + b\n"
        "def sub(a, b): return a + b\n",  # bug — should be a - b
        encoding="utf-8")
    tests = root / "tests"
    tests.mkdir()
    (tests / "__init__.py").write_text("", encoding="utf-8")
    (tests / "conftest.py").write_text(
        "import sys\nfrom pathlib import Path\n"
        "sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'src'))\n",
        encoding="utf-8")
    (tests / "test_ops.py").write_text(
        "from demo.ops import add, sub\n"
        "def test_add(): assert add(2,3) == 5\n"
        "def test_sub(): assert sub(5,3) == 2\n",
        encoding="utf-8")
    rep = run_pytest(output_root=root, package="demo")
    assert rep["passed"] == 1
    assert rep["failed"] == 1
    assert rep["pass_ratio"] == 0.5


# ── Pytest summary parser regression tests (FORGE_DELUXE_EXPERIENCE.md §M-2) ──
# Bug class: a single positional regex matching all four counters at once
# silently returned (0,0,0,0) when pytest's summary line included qualifiers
# like xfailed/xpassed/warnings/deselected/rerun in unexpected positions.
# Forge's parser already uses per-token regexes anchored on the "in <N>s"
# trailer, so it shouldn't have this bug — these tests lock that in so a
# future "let's consolidate the regexes" refactor can't regress.


def test_parse_summary_with_xfailed_does_not_zero_passed():
    line = "===== 225 passed, 2 xfailed in 5.42s ====="
    p, f, e, s = _parse_pytest_summary(line)
    assert p == 225
    assert f == 0
    assert e == 0
    assert s == 0


def test_parse_summary_with_xpassed_and_warnings_works():
    line = "===== 99 passed, 5 xfailed, 1 xpassed, 2 warnings in 8.21s ====="
    p, f, e, s = _parse_pytest_summary(line)
    assert p == 99
    assert f == 0


def test_parse_summary_failed_passed_error_skipped_classic():
    line = "===== 4 failed, 5 passed, 1 error, 3 skipped in 2.5s ====="
    p, f, e, s = _parse_pytest_summary(line)
    assert (p, f, e, s) == (5, 4, 1, 3)


def test_parse_summary_minimal_form():
    p, f, e, s = _parse_pytest_summary("1 passed in 0.03s")
    assert p == 1
    assert f == 0


def test_parse_summary_failed_then_passed_swapped_order():
    p, f, e, s = _parse_pytest_summary("===== 2 failed, 3 passed in 1.12s =====")
    assert p == 3
    assert f == 2


def test_parse_summary_warnings_only_returns_zeros():
    """Lines with `in 5s` but no count keywords should not falsely match."""
    p, f, e, s = _parse_pytest_summary("started subprocess in 5s")
    assert (p, f, e, s) == (0, 0, 0, 0)


def test_parse_summary_plural_errors_form():
    """Pytest emits ``2 errors`` (plural) when count > 1; the parser
    must still extract the count. Locked in so a future ``\\b`` boundary
    tightening can't accidentally limit matching to the singular form.
    """
    p, f, e, s = _parse_pytest_summary("===== 0 passed, 2 errors in 0.5s =====")
    assert (p, f, e, s) == (0, 0, 2, 0)


def test_parse_summary_singular_error_form_still_works():
    p, f, e, s = _parse_pytest_summary("===== 1 error in 0.1s =====")
    assert (p, f, e, s) == (0, 0, 1, 0)
