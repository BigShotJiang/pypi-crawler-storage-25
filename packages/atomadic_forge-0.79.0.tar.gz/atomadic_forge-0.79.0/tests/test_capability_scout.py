"""Tests for a1 capability_scout — GitHub repo search for harvest targets."""
from unittest.mock import patch

from atomadic_forge.a1_at_functions.capability_scout import (
    SCHEMA_VERSION_CAPABILITY_SCOUT_V1,
    scout_capabilities,
)


def _fake_gh_items():
    return [
        {
            "id": 1,
            "full_name": "example/dead-code-detector",
            "html_url": "https://github.com/example/dead-code-detector",
            "clone_url": "https://github.com/example/dead-code-detector.git",
            "stargazers_count": 1200,
            "language": "Python",
            "description": "Find dead code in Python projects",
            "topics": ["dead-code", "ast", "python"],
            "pushed_at": "2025-01-15T00:00:00Z",
        },
        {
            "id": 2,
            "full_name": "example/tiny-tool",
            "html_url": "https://github.com/example/tiny-tool",
            "clone_url": "https://github.com/example/tiny-tool.git",
            "stargazers_count": 5,
            "language": "Python",
            "description": "A tiny tool",
            "topics": [],
            "pushed_at": "2020-01-01T00:00:00Z",
        },
    ]


def test_capability_scout_schema_version():
    with patch("atomadic_forge.a1_at_functions.capability_scout._gh_search",
               return_value=_fake_gh_items()):
        result = scout_capabilities(["dead code detection"])
    assert result["schema_version"] == SCHEMA_VERSION_CAPABILITY_SCOUT_V1


def test_capability_scout_returns_targets():
    with patch("atomadic_forge.a1_at_functions.capability_scout._gh_search",
               return_value=_fake_gh_items()):
        result = scout_capabilities(["dead code detection"], min_score=0.0)
    assert result["total_candidates"] >= 1
    assert len(result["targets"]) >= 1


def test_capability_scout_filters_by_min_score():
    with patch("atomadic_forge.a1_at_functions.capability_scout._gh_search",
               return_value=_fake_gh_items()):
        result = scout_capabilities(["dead code detection"], min_score=80.0)
    # tiny-tool should be filtered out
    for t in result["targets"]:
        assert t["harvest_score"] >= 80.0


def test_capability_scout_deduplicates():
    with patch("atomadic_forge.a1_at_functions.capability_scout._gh_search",
               return_value=_fake_gh_items()):
        result = scout_capabilities(
            ["dead code", "dead code again"], min_score=0.0, dedupe=True
        )
    ids = [t["repo"] for t in result["targets"]]
    assert len(ids) == len(set(ids))


def test_capability_scout_sorts_by_score():
    with patch("atomadic_forge.a1_at_functions.capability_scout._gh_search",
               return_value=_fake_gh_items()):
        result = scout_capabilities(["dead code"], min_score=0.0)
    scores = [t["harvest_score"] for t in result["targets"]]
    assert scores == sorted(scores, reverse=True)


def test_capability_scout_network_failure_returns_empty():
    with patch("atomadic_forge.a1_at_functions.capability_scout._gh_search",
               return_value=[]):
        result = scout_capabilities(["anything"])
    assert result["total_candidates"] == 0
    assert result["targets"] == []
