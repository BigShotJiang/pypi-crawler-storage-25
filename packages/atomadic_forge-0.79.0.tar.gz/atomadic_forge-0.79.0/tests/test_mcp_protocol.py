"""Tier verification — Golden Path Lane C W4: forge mcp serve.

Two layers of coverage:

  Pure dispatch (mcp_protocol.py):
    * initialize handshake returns the pinned protocolVersion +
      serverInfo + capability flags
    * tools/list and resources/list return the pinned set
    * tools/call routes recon / wire / certify / enforce / audit_list
      and wraps results in the MCP content envelope
    * resources/read serves docs + lineage
    * unknown methods surface JSON-RPC -32601, unknown tools / bad
      params surface -32601 / -32602; tool exceptions surface -32000
      WITHOUT crashing the dispatcher

  Stdio loop (mcp_server.py):
    * end-to-end ping round-trip via in-memory stdin/stdout
    * shutdown method exits the loop cleanly with rc=0
"""
from __future__ import annotations

import io
import json
from pathlib import Path

from typer.testing import CliRunner

from atomadic_forge.a1_at_functions.mcp_protocol import (
    PROTOCOL_VERSION,
    RESOURCES,
    SERVER_NAME,
    TOOLS,
    _json_default,
    dispatch_request,
    register_emergent_scan_handler,
)
from atomadic_forge.a3_og_features.mcp_server import serve_stdio
from atomadic_forge.a4_sy_orchestration.cli import app

runner = CliRunner()

# ---- handshake ---------------------------------------------------------

def test_initialize_returns_pinned_protocol(tmp_path):
    req = {"jsonrpc": "2.0", "id": 1, "method": "initialize",
           "params": {"clientInfo": {"name": "test"}}}
    resp = dispatch_request(req, project_root=tmp_path)
    assert resp["jsonrpc"] == "2.0"
    assert resp["id"] == 1
    result = resp["result"]
    assert result["protocolVersion"] == PROTOCOL_VERSION
    assert result["serverInfo"]["name"] == SERVER_NAME
    assert "tools" in result["capabilities"]
    assert "resources" in result["capabilities"]


def test_ping_returns_empty_object(tmp_path):
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 99, "method": "ping"},
        project_root=tmp_path,
    )
    assert resp["result"] == {}


def test_initialized_notification_returns_none(tmp_path):
    """notifications/initialized has no id and gets no response."""
    resp = dispatch_request(
        {"jsonrpc": "2.0", "method": "notifications/initialized"},
        project_root=tmp_path,
    )
    assert resp is None


def test_initialized_alias_notification_returns_none(tmp_path):
    """Some stdio hosts send the LSP-style initialized notification."""
    resp = dispatch_request(
        {"jsonrpc": "2.0", "method": "initialized"},
        project_root=tmp_path,
    )
    assert resp is None


# ---- tools/list + resources/list ---------------------------------------

def test_tools_list_pinned(tmp_path):
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
        project_root=tmp_path,
    )
    names = {t["name"] for t in resp["result"]["tools"]}
    pinned = {
        # v0.32–v0.36: recon+explain+call_graph+smell_scan+lineage → explore
        # v0.32–v0.35+v0.36: certify+wire+enforce+guard+validate → audit
        "explore", "audit",
        # v0.46.0: nexus restored standalone (absorbed into hive v0.45.0, restored v0.46.0):
        "nexus",
        # v0.46.0: wisdom restored standalone (absorbed into explore v0.44.0, restored v0.46.0):
        "wisdom",
        # v0.43.0: context_pack absorbed into plan (context|compose|policy|recipes):
        # v0.34.0: recipes → workflow; v0.35.0+v0.36.0: all planning in one place
        "plan",          # ← auto_plan + adapt_plan + plan_apply (v0.30.0)
        # v0.42.0: preflight absorbed into audit (check|score|tests|cna|rollback|diff):
        # v0.41.0: tool_factory+discover absorbed (scaffold→plan, discover→explore):
        # v0.40.0: verify absorbed into audit (composite+gate+health actions):
        # v0.39.0: transmute+loop absorbed into plan (12 actions total):
        # v0.33.0: hive_agent+hive_consensus → hive:
        "hive",
        # v0.38.0: session(handoff+enhancement) absorbed into hive
        # v0.14.0a12: welcome — first-call handshake:
        "welcome",
        # v0.47.0: `forge create` exposed as MCP tool (intent + seed_repos -> pip package):
        "create",
        # v0.48.0: flagship transmuter pipeline restored standalone (auto/cherry/finalize):
        "transmute",
        # v0.48.0: LLM iteration loops restored standalone (iterate/resume/evolve/evolve_step):
        "loop",
    }
    assert pinned == names == set(TOOLS.keys()), (
        f"tools/list drifted: returned {names}, expected {pinned}"
    )
    # Every tool must have a JSON Schema for inputs.
    for tool in resp["result"]["tools"]:
        assert "inputSchema" in tool
        assert tool["inputSchema"]["type"] == "object"
        assert "cli_command" in tool
        assert tool["forge_version"]
        assert tool["server_source_path"].endswith("mcp_protocol.py")
    assert resp["result"]["serverInfo"]["source_path"].endswith("mcp_protocol.py")
    # v0.10.0: audit_list merged into lineage; v0.36.0: lineage absorbed into explore.
    # cli_command annotations follow the surviving tools.
    explore = next(t for t in resp["result"]["tools"] if t["name"] == "explore")
    assert "cli_command" in explore
    audit = next(t for t in resp["result"]["tools"] if t["name"] == "audit")
    assert "cli_command" in audit


def test_resources_list_pinned(tmp_path):
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 3, "method": "resources/list"},
        project_root=tmp_path,
    )
    uris = {r["uri"] for r in resp["result"]["resources"]}
    pinned = {
        "forge://docs/receipt",
        "forge://docs/formalization",
        "forge://lineage/chain",
        "forge://schema/receipt",
        "forge://summary/blockers",
    }
    assert uris == pinned == set(RESOURCES.keys())


# ---- tools/call --------------------------------------------------------

def _sample_tier_tree(root: Path) -> Path:
    pkg = root / "src" / "demo"
    a1 = pkg / "a1_at_functions"
    a1.mkdir(parents=True)
    (pkg / "__init__.py").write_text('"""demo."""\n', encoding="utf-8")
    (a1 / "__init__.py").write_text('"""a1."""\n', encoding="utf-8")
    (a1 / "ok.py").write_text(
        '"""a1 helper."""\ndef ok(x):\n    return x\n', encoding="utf-8")
    return pkg


def test_tools_call_recon(tmp_path):
    pkg = _sample_tier_tree(tmp_path)
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 4, "method": "tools/call",
         "params": {"name": "explore", "arguments": {"action": "recon", "target": str(pkg)}}},
        project_root=tmp_path,
    )
    body = json.loads(resp["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.scout/v1"
    assert body["primary_language"] == "python"


def test_tools_call_doctor_with_include_worktree(tmp_path, monkeypatch):
    """v0.10.0: worktree_status was folded into doctor as
    include_worktree=true. The worktree payload now nests under
    `worktree` in the doctor response."""
    # Block git's parent-walk so this test works inside a CI clone — without
    # this env var, `git rev-parse --show-toplevel` finds the surrounding
    # atomadic-forge clone and reports is_git_repo=True.
    monkeypatch.setenv("GIT_CEILING_DIRECTORIES", str(tmp_path.parent))
    for _var in ("GIT_DIR", "GIT_WORK_TREE", "GIT_COMMON_DIR"):
        monkeypatch.delenv(_var, raising=False)
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 4, "method": "tools/call",
         "params": {"name": "audit",
                    "arguments": {"action": "health",
                                  "project_root": str(tmp_path),
                                  "include_worktree": True}}},
        project_root=tmp_path,
    )
    body = json.loads(resp["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.doctor/v1"
    assert "worktree" in body
    assert body["worktree"]["is_git_repo"] is False


def test_tools_call_wire_pass(tmp_path):
    pkg = _sample_tier_tree(tmp_path)
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 5, "method": "tools/call",
         "params": {"name": "audit", "arguments": {"action": "wire", "source": str(pkg)}}},
        project_root=tmp_path,
    )
    body = json.loads(resp["result"]["content"][0]["text"])
    assert body["verdict"] == "PASS"


def test_tools_call_wire_with_suggest_repairs(tmp_path):
    pkg = tmp_path / "pkg"
    a1 = pkg / "a1_at_functions"; a1.mkdir(parents=True)
    a3 = pkg / "a3_og_features"; a3.mkdir(parents=True)
    (a3 / "feat.py").write_text(
        '"""a3."""\nclass F:\n    pass\n', encoding="utf-8")
    (a1 / "h.py").write_text(
        "from ..a3_og_features.feat import F\n", encoding="utf-8")
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 6, "method": "tools/call",
         "params": {"name": "audit",
                    "arguments": {"action": "wire",
                                   "source": str(pkg),
                                   "suggest_repairs": True}}},
        project_root=tmp_path,
    )
    body = json.loads(resp["result"]["content"][0]["text"])
    assert body["verdict"] == "FAIL"
    assert body["auto_fixable"] >= 1
    assert "repair_suggestions" in body


def test_tools_call_enforce_dry_run(tmp_path):
    pkg = _sample_tier_tree(tmp_path)
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 7, "method": "tools/call",
         "params": {"name": "audit",
                    "arguments": {"action": "enforce", "source": str(pkg)}}},
        project_root=tmp_path,
    )
    body = json.loads(resp["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.enforce/v1"
    assert body["apply"] is False
    assert body["pre_violations"] == 0


def test_tools_call_lineage_mode_all_empty(tmp_path):
    """v0.10.0: audit_list was merged into lineage with mode='all'.
    Empty repo → empty artifacts list."""
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 8, "method": "tools/call",
         "params": {"name": "explore",
                    "arguments": {"action": "lineage",
                                  "mode": "all",
                                  "project_root": str(tmp_path)}}},
        project_root=tmp_path,
    )
    body = json.loads(resp["result"]["content"][0]["text"])
    # The merged tool delegates to _tool_audit_list, which still uses
    # the audit.list schema version internally.
    assert body["schema_version"] == "atomadic-forge.audit.list/v1"
    assert body["artifacts"] == []


def test_mcp_doctor_cli_json(tmp_path):
    result = runner.invoke(app, ["mcp", "doctor", "--project", str(tmp_path), "--json"])
    assert result.exit_code == 0
    body = json.loads(result.stdout)
    assert body["schema_version"] == "atomadic-forge.mcp_doctor/v1"
    assert body["verdict"] == "PASS"
    assert body["framed_stdio_smoke"] == "PASS"


def test_tools_call_unknown_tool_returns_method_not_found(tmp_path):
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 9, "method": "tools/call",
         "params": {"name": "definitely-not-a-tool"}},
        project_root=tmp_path,
    )
    assert resp["error"]["code"] == -32601


def test_tools_call_handler_exception_does_not_crash(tmp_path, monkeypatch):
    """A tool whose handler raises must surface a JSON-RPC error,
    never a Python traceback that kills the dispatcher."""
    from atomadic_forge.a1_at_functions import mcp_protocol as proto

    def boom(_root, _args):
        raise ValueError("synthetic test error")

    original = proto.TOOLS["explore"]["handler"]
    proto.TOOLS["explore"]["handler"] = boom
    try:
        resp = dispatch_request(
            {"jsonrpc": "2.0", "id": 10, "method": "tools/call",
             "params": {"name": "explore", "arguments": {"action": "recon"}}},
            project_root=tmp_path,
        )
    finally:
        proto.TOOLS["explore"]["handler"] = original
    assert "error" in resp
    assert resp["error"]["code"] in {-32000, -32603}
    assert "synthetic test error" in resp["error"]["message"]


# ---- resources/read ----------------------------------------------------

def test_resources_read_lineage_empty(tmp_path):
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 11, "method": "resources/read",
         "params": {"uri": "forge://lineage/chain"}},
        project_root=tmp_path,
    )
    contents = resp["result"]["contents"]
    assert contents[0]["uri"] == "forge://lineage/chain"
    assert contents[0]["mimeType"] == "application/json"
    body = json.loads(contents[0]["text"])
    assert body["entries"] == []


def test_resources_read_schema(tmp_path):
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 12, "method": "resources/read",
         "params": {"uri": "forge://schema/receipt"}},
        project_root=tmp_path,
    )
    body = json.loads(resp["result"]["contents"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.receipt/v1"
    assert "PASS" in body["valid_verdicts"]


def test_resources_read_unknown_uri(tmp_path):
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 13, "method": "resources/read",
         "params": {"uri": "forge://nope/123"}},
        project_root=tmp_path,
    )
    assert resp["error"]["code"] == -32602


# ---- error paths -------------------------------------------------------

def test_unknown_method_returns_method_not_found(tmp_path):
    resp = dispatch_request(
        {"jsonrpc": "2.0", "id": 14, "method": "totally/made/up"},
        project_root=tmp_path,
    )
    assert resp["error"]["code"] == -32601


def test_non_dict_request_returns_invalid_request(tmp_path):
    resp = dispatch_request("not-a-dict", project_root=tmp_path)  # type: ignore[arg-type]
    assert resp["error"]["code"] == -32600


def test_request_without_method_returns_invalid_request(tmp_path):
    resp = dispatch_request({"jsonrpc": "2.0", "id": 15},
                              project_root=tmp_path)
    assert resp["error"]["code"] == -32600


# ---- stdio loop --------------------------------------------------------

def test_serve_stdio_ping_round_trip(tmp_path):
    """Send an initialize + ping + shutdown sequence and confirm the
    loop responds + exits cleanly with rc=0."""
    inp = io.StringIO(
        json.dumps({"jsonrpc": "2.0", "id": 1, "method": "initialize"}) + "\n"
        + json.dumps({"jsonrpc": "2.0", "id": 2, "method": "ping"}) + "\n"
        + json.dumps({"jsonrpc": "2.0", "id": 3, "method": "shutdown"}) + "\n"
    )
    out = io.StringIO()
    err = io.StringIO()
    rc = serve_stdio(project_root=tmp_path, stdin=inp, stdout=out, stderr=err)
    assert rc == 0
    lines = [ln for ln in out.getvalue().splitlines() if ln.strip()]
    # initialize + ping + shutdown all produce one response each.
    assert len(lines) == 3
    init_resp = json.loads(lines[0])
    assert init_resp["result"]["serverInfo"]["name"] == SERVER_NAME
    ping_resp = json.loads(lines[1])
    assert ping_resp["result"] == {}
    shutdown_resp = json.loads(lines[2])
    assert shutdown_resp["id"] == 3


def _mcp_frame(msg: dict) -> bytes:
    body = json.dumps(msg).encode("utf-8")
    return f"Content-Length: {len(body)}\r\n\r\n".encode("ascii") + body


def _mcp_framed_bodies(raw: bytes) -> list[dict]:
    out = []
    cursor = 0
    while cursor < len(raw):
        header_end = raw.find(b"\r\n\r\n", cursor)
        assert header_end != -1, raw[cursor:]
        header = raw[cursor:header_end].decode("ascii")
        length = int(header.split(":", 1)[1].strip())
        start = header_end + 4
        body = raw[start:start + length]
        out.append(json.loads(body.decode("utf-8")))
        cursor = start + length
    return out


def test_serve_stdio_content_length_framed_round_trip(tmp_path):
    """MCP hosts may use Content-Length framing instead of JSON lines."""
    inp = io.BytesIO(b"".join([
        _mcp_frame({"jsonrpc": "2.0", "id": 1, "method": "initialize"}),
        _mcp_frame({"jsonrpc": "2.0", "method": "initialized"}),
        _mcp_frame({"jsonrpc": "2.0", "id": 2, "method": "ping"}),
        _mcp_frame({"jsonrpc": "2.0", "id": 3, "method": "shutdown"}),
    ]))
    out = io.BytesIO()
    err = io.StringIO()

    rc = serve_stdio(project_root=tmp_path, stdin=inp, stdout=out, stderr=err)

    assert rc == 0
    raw = out.getvalue()
    assert raw.count(b"Content-Length:") == 3
    bodies = _mcp_framed_bodies(raw)
    assert bodies[0]["result"]["serverInfo"]["name"] == SERVER_NAME
    assert bodies[1]["result"] == {}
    assert bodies[2]["id"] == 3


def test_serve_stdio_recovers_from_bad_json(tmp_path):
    """A malformed line surfaces parse error but the loop continues."""
    inp = io.StringIO(
        "this is not json\n"
        + json.dumps({"jsonrpc": "2.0", "id": 1, "method": "ping"}) + "\n"
        + json.dumps({"jsonrpc": "2.0", "id": 2, "method": "shutdown"}) + "\n"
    )
    out = io.StringIO()
    rc = serve_stdio(project_root=tmp_path, stdin=inp, stdout=out,
                      stderr=io.StringIO())
    assert rc == 0
    lines = [ln for ln in out.getvalue().splitlines() if ln.strip()]
    parse_err = json.loads(lines[0])
    assert parse_err["error"]["code"] == -32700
    ping_ok = json.loads(lines[1])
    assert ping_ok["result"] == {}


def test_serve_stdio_missing_project_returns_rc_1():
    rc = serve_stdio(project_root=Path("/definitely/not/a/path/anywhere"),
                      stdin=io.StringIO(""), stdout=io.StringIO(),
                      stderr=io.StringIO())
    assert rc == 1


# ---- Round-1 substrate hardening ---------------------------------------

# Forge is the architecture-substrate other AI coding tools depend on.
# These tests lock in two non-negotiable substrate guarantees:
#   1) ``dispatch_request`` NEVER raises into the transport — every
#      handler exception class becomes a clean JSON-RPC -32000 error.
#   2) Every tool's result round-trips through the explicit
#      ``_json_default`` so the wire stays JSON-safe even if a future
#      tool returns a structured Python type.

def test_dispatch_request_swallows_TypeError_no_crash(tmp_path):
    """Substrate guarantee: a handler raising ``TypeError`` (signature
    drift, None-deref, etc.) must produce a -32000 error response, NOT
    propagate up and kill the stdio loop. The previous narrow
    ``except (ValueError, OSError, RuntimeError)`` let TypeError escape,
    which is the documented root cause of the deluxe ``-32000 Connection
    closed`` failures (FORGE_DELUXE_EXPERIENCE.md v2 P1).
    """
    # Inject a broken emergent_scan handler that raises TypeError.
    def broken(_pr, _args):
        raise TypeError("simulated signature drift")
    register_emergent_scan_handler(broken)
    try:
        req = {"jsonrpc": "2.0", "id": 7, "method": "tools/call",
               "params": {"name": "explore", "arguments": {"action": "scan"}}}
        resp = dispatch_request(req, project_root=tmp_path)
        assert resp is not None
        assert resp.get("error", {}).get("code") == -32000
        assert "TypeError" in resp["error"]["message"]
    finally:
        register_emergent_scan_handler(None)  # type: ignore[arg-type]


def test_dispatch_request_swallows_KeyError_AttributeError(tmp_path):
    """Same substrate guarantee for KeyError / AttributeError — common
    in handlers that drift relative to their schema."""
    for exc_cls in (KeyError, AttributeError, ZeroDivisionError):
        def broken(_pr, _args, _exc=exc_cls):
            raise _exc("simulated")
        register_emergent_scan_handler(broken)
        try:
            req = {"jsonrpc": "2.0", "id": 7, "method": "tools/call",
                   "params": {"name": "explore", "arguments": {"action": "scan"}}}
            resp = dispatch_request(req, project_root=tmp_path)
            assert resp is not None, exc_cls
            assert resp.get("error", {}).get("code") == -32000, exc_cls
            assert exc_cls.__name__ in resp["error"]["message"]
        finally:
            register_emergent_scan_handler(None)  # type: ignore[arg-type]


def test_json_default_handles_set_frozenset_path_bytes_dataclass():
    """Locks in the explicit serializer's contract.  Previously
    ``default=str`` coerced ``{1, 2}`` into the string ``'{1, 2}'`` —
    valid JSON but useless to clients. The replacement returns a
    JSON-array, posix-string, base64-bytes, and asdict-dataclass."""
    import dataclasses

    @dataclasses.dataclass
    class Sample:
        x: int
        y: str

    payload = {
        "set": {1, 2, 3},
        "frozenset": frozenset(["a", "b"]),
        "path_obj": Path("a/b/c.py"),
        "raw_bytes": b"\xff\x00\xab",
        "card": Sample(x=5, y="hello"),
    }
    encoded = json.dumps(payload, default=_json_default)
    decoded = json.loads(encoded)
    assert decoded["set"] == [1, 2, 3]  # sorted list, not a string
    assert sorted(decoded["frozenset"]) == ["a", "b"]
    assert decoded["path_obj"] == "a/b/c.py"  # posix style
    assert decoded["raw_bytes"] == {"__bytes_b64__": "/wCr"}
    assert decoded["card"] == {"x": 5, "y": "hello"}  # asdict, not repr


def test_every_tool_result_round_trips_through_json_default(tmp_path):
    """Substrate contract: every tool's result must round-trip through
    ``json.dumps(default=_json_default)`` cleanly. If a future tool
    returns a value the serializer can't handle, this test fails before
    the MCP wire ever sees the broken payload.

    We exercise read-only / safe tools that work on any tmp_path.
    Mutation-class tools (auto_apply, enforce --apply) require staged
    state; they're covered by their dedicated end-to-end tests."""
    from atomadic_forge.a1_at_functions import mcp_protocol as mp

    safe_to_call: list[str] = [
        "explore", "audit",
        "list_recipes", "doctor",
        "what_failed_last_time",
    ]

    failures: list[tuple[str, str]] = []
    for name in safe_to_call:
        if name not in mp.TOOLS:
            continue
        handler = mp.TOOLS[name]["handler"]
        try:
            # Use minimal valid args per tool. Fall back to {} when the
            # tool accepts a free-form arguments dict.
            args: dict = {}
            if name == "score_patch":
                args = {"diff": "diff --git a/x.py b/x.py\n--- a/x.py\n+++ b/x.py\n@@\n+pass\n"}
            elif name == "what_failed_last_time":
                args = {"area": "x"}
            result = handler(tmp_path, args)
            encoded = json.dumps(result, default=_json_default)
            json.loads(encoded)  # Must round-trip.
        except Exception as exc:  # noqa: BLE001
            failures.append((name, f"{type(exc).__name__}: {exc}"))
    assert not failures, f"tools failing JSON round-trip: {failures}"


# ---- Round-2 transmuter pipeline (auto / cherry / finalize) ------------

# These three MCP tools expose forge's existing CLI pipeline (scout →
# cherry → assimilate → wire → certify) to AI coding agents. The
# substrate boundary: agent = LLM, forge = analytical certainty. None
# of these handlers invoke an LLM internally — they're pure deterministic
# pipeline.


def _spaghetti_repo(tmp_path) -> Path:
    src = tmp_path / "spaghetti"
    src.mkdir()
    (src / "foo.py").write_text(
        "def double(x):\n    return x * 2\n", encoding="utf-8")
    (src / "bar.py").write_text(
        "class Bar:\n    def name(self):\n        return 'bar'\n",
        encoding="utf-8")
    return src


def test_auto_dry_run_returns_pipeline_report(tmp_path):
    """Substrate guarantee: ``auto`` runs the full pipeline without an
    LLM and without writing files when apply=false. Returns a
    structured report covering scout/cherry/finalize stages."""
    src = _spaghetti_repo(tmp_path)
    out = tmp_path / "shipped"
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "transmute", "arguments": {
                "action": "auto", "target": str(src), "output": str(out),
                "package": "demo", "apply": False}}}
    resp = dispatch_request(req, project_root=src)
    assert "result" in resp, resp
    body = json.loads(resp["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.auto/v1"
    assert body["scout"]["symbol_count"] >= 2
    assert body["cherry"]["items"] >= 2
    assert body["applied"] is False
    # Dry-run MUST NOT have written anything.
    assert not (out / "src" / "demo").exists()


def test_auto_apply_writes_tier_organized_package(tmp_path):
    """apply=true materializes a real tier-organized package."""
    src = _spaghetti_repo(tmp_path)
    out = tmp_path / "shipped"
    req = {"jsonrpc": "2.0", "id": 2, "method": "tools/call",
            "params": {"name": "transmute", "arguments": {
                "action": "auto", "target": str(src), "output": str(out),
                "package": "demo", "apply": True}}}
    resp = dispatch_request(req, project_root=src)
    assert "result" in resp, resp
    body = json.loads(resp["result"]["content"][0]["text"])
    assert body["applied"] is True
    pkg_root = out / "src" / "demo"
    assert pkg_root.exists()
    # Tier directories scaffolded.
    assert (pkg_root / "a1_at_functions").exists()


def test_auto_rejects_invalid_on_conflict(tmp_path):
    """The handler validates the on_conflict enum — invalid values
    surface as a JSON-RPC -32000 error (caught by the broadened
    dispatcher except) rather than crashing the transport."""
    src = _spaghetti_repo(tmp_path)
    req = {"jsonrpc": "2.0", "id": 3, "method": "tools/call",
            "params": {"name": "transmute", "arguments": {
                "action": "auto", "target": str(src), "output": str(tmp_path / "out"),
                "on_conflict": "bogus"}}}
    resp = dispatch_request(req, project_root=src)
    assert "error" in resp
    assert resp["error"]["code"] == -32000
    assert "on_conflict" in resp["error"]["message"]


def test_cherry_returns_manifest(tmp_path):
    """cherry builds (or loads) the scout report and emits the
    cherry.json manifest. pick_all selects every classifiable symbol."""
    src = _spaghetti_repo(tmp_path)
    req = {"jsonrpc": "2.0", "id": 4, "method": "tools/call",
            "params": {"name": "transmute", "arguments": {
                "action": "cherry", "target": str(src), "pick_all": True}}}
    resp = dispatch_request(req, project_root=src)
    assert "result" in resp, resp
    body = json.loads(resp["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.cherry/v1"
    assert len(body["items"]) >= 2
    qualnames = {it["qualname"] for it in body["items"]}
    assert any("double" in q for q in qualnames)


def test_cherry_pick_all_alias_via_pick_list(tmp_path):
    """Passing pick=['all'] is equivalent to pick_all=true (CLI parity)."""
    src = _spaghetti_repo(tmp_path)
    req = {"jsonrpc": "2.0", "id": 5, "method": "tools/call",
            "params": {"name": "transmute", "arguments": {
                "action": "cherry", "target": str(src), "pick": ["all"]}}}
    resp = dispatch_request(req, project_root=src)
    body = json.loads(resp["result"]["content"][0]["text"])
    assert len(body["items"]) >= 2


def test_finalize_dry_run_does_not_write(tmp_path):
    """finalize apply=false must not touch the output directory."""
    src = _spaghetti_repo(tmp_path)
    out = tmp_path / "shipped"
    # First build a cherry manifest so finalize has something to consume.
    cherry_req = {"jsonrpc": "2.0", "id": 6, "method": "tools/call",
                   "params": {"name": "transmute", "arguments": {
                       "action": "cherry", "target": str(src), "pick_all": True}}}
    dispatch_request(cherry_req, project_root=src)
    # Now finalize.
    fin_req = {"jsonrpc": "2.0", "id": 7, "method": "tools/call",
                "params": {"name": "transmute", "arguments": {
                    "action": "finalize", "target": str(src), "output": str(out),
                    "package": "demo", "apply": False}}}
    resp = dispatch_request(fin_req, project_root=src)
    body = json.loads(resp["result"]["content"][0]["text"])
    assert body["applied"] is False
    assert not (out / "src" / "demo").exists()


def test_auto_cherry_finalize_descriptions_carry_use_this_when():
    """Round-2 substrate adoption: every new MCP tool description must
    begin with 'Use this when:' so agents browsing the registry see the
    trigger before the body."""
    assert "plan" in TOOLS
    assert TOOLS["plan"]["description"].startswith("Use this when:"), "plan (transmute actions)"


def test_auto_dry_run_result_round_trips_json(tmp_path):
    """Substrate JSON-safety contract: the new tools must round-trip
    through the explicit ``_json_default`` helper introduced in Round 1."""
    src = _spaghetti_repo(tmp_path)
    out = tmp_path / "shipped"
    handler = TOOLS["transmute"]["handler"]
    result = handler(src, {"action": "auto", "target": str(src), "output": str(out),
                             "apply": False})
    encoded = json.dumps(result, default=_json_default)
    decoded = json.loads(encoded)
    assert decoded["schema_version"] == "atomadic-forge.auto/v1"


# ---- Round-3 agent-driven iterate (substrate boundary) -----------------

# Round 3 closes the substrate-boundary gap from Round 2. The transmuter
# pipeline (auto/cherry/finalize) is deterministic — no LLM ever needed.
# But iterate / evolve are LLM-driven loops. The R3 fix: forge stops
# holding an LLM client, and the agent drives its own LLM, calling forge
# tools (iterate_start / iterate_continue) for analytical certainty
# between turns. NO LLM is constructed inside forge.


def test_iterate_start_returns_session_and_prompts(tmp_path):
    """iterate_start opens a session, returns the system prompt + first
    user prompt for the agent's LLM, and persists state to disk so
    iterate_continue can find it on a later MCP request."""
    output = tmp_path / "gen"
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "loop", "arguments": {
                "action": "iterate",
                "intent": "Build a CLI that converts CSV to JSON",
                "output": str(output), "package": "csv2json",
                "max_iterations": 2, "target_score": 75.0}}}
    resp = dispatch_request(req, project_root=tmp_path)
    assert "result" in resp, resp
    body = json.loads(resp["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.iterate_start/v1"
    assert body["session_id"]
    assert body["system_prompt"]
    assert body["first_prompt"]
    # Session was persisted.
    assert (tmp_path / ".atomadic-forge" / "iterate_sessions"
            / f"{body['session_id']}.json").exists()


def test_iterate_continue_writes_files_and_returns_next_prompt(tmp_path):
    """iterate_continue parses files from the (simulated) LLM response,
    writes them, runs wire+certify, returns next_prompt for the agent
    to feed back into ITS OWN LLM."""
    output = tmp_path / "gen"
    start = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
              "params": {"name": "loop", "arguments": {
                  "action": "iterate",
                  "intent": "Build a calculator",
                  "output": str(output), "package": "calc",
                  "max_iterations": 3}}}
    sid = json.loads(dispatch_request(start, project_root=tmp_path)
                      ["result"]["content"][0]["text"])["session_id"]
    response = json.dumps([
        {"path": "src/calc/a1_at_functions/add.py",
         "content": "def add(a,b):\n    return a+b\n"},
        {"path": "src/calc/a4_sy_orchestration/cli.py",
         "content": "def main():\n    print('hi')\n"},
    ])
    cont = {"jsonrpc": "2.0", "id": 2, "method": "tools/call",
             "params": {"name": "loop", "arguments": {
                 "action": "resume", "session_id": sid, "response": response}}}
    resp = dispatch_request(cont, project_root=tmp_path)
    body = json.loads(resp["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.iterate_continue/v1"
    assert body["session_id"] == sid
    assert len(body["files_written_this_turn"]) == 2
    assert body["wire_verdict"] in {"PASS", "FAIL"}
    # Score may not hit target on first turn — should still get a next prompt.
    assert body["done"] is False
    assert body["next_prompt"]


def test_iterate_continue_unknown_session_returns_error(tmp_path):
    """Bogus session_id returns a structured error, not a -32000 crash."""
    cont = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
             "params": {"name": "loop", "arguments": {
                 "action": "resume", "session_id": "deadbeef0000", "response": "[]"}}}
    resp = dispatch_request(cont, project_root=tmp_path)
    body = json.loads(resp["result"]["content"][0]["text"])
    assert body["done"] is True
    assert body["halt_reason"] == "unknown_session"


def test_iterate_continue_halts_at_max_iterations(tmp_path):
    """When the agent's LLM keeps responding without converging, the
    loop terminates cleanly at max_iterations rather than running
    forever."""
    output = tmp_path / "gen"
    start = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
              "params": {"name": "loop", "arguments": {
                  "action": "iterate",
                  "intent": "thing", "output": str(output),
                  "package": "thing", "max_iterations": 1,
                  "target_score": 99.99}}}  # impossible target
    sid = json.loads(dispatch_request(start, project_root=tmp_path)
                      ["result"]["content"][0]["text"])["session_id"]
    response = json.dumps([
        {"path": "src/thing/a1_at_functions/x.py",
         "content": "def x():\n    pass\n"},
    ])
    cont = {"jsonrpc": "2.0", "id": 2, "method": "tools/call",
             "params": {"name": "loop", "arguments": {
                 "action": "resume", "session_id": sid, "response": response}}}
    body = json.loads(dispatch_request(cont, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["done"] is True
    assert body["halt_reason"] == "max_iterations"


def test_iterate_no_llm_client_constructed_in_forge(tmp_path):
    """Substrate guarantee: iterate_start must NOT construct an LLM
    client. The whole point of Round 3 is that forge holds no LLM —
    the calling agent drives the LLM. We verify by patching the
    factory and asserting it's never called."""
    from atomadic_forge.a1_at_functions import llm_client as _llm_client
    calls = {"count": 0}
    real = _llm_client.resolve_default_client

    def spy(*a, **kw):
        calls["count"] += 1
        return real(*a, **kw)

    _llm_client.resolve_default_client = spy
    try:
        req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
                "params": {"name": "loop", "arguments": {
                    "action": "iterate",
                    "intent": "x", "output": str(tmp_path / "gen"),
                    "package": "x"}}}
        resp = dispatch_request(req, project_root=tmp_path)
        assert "result" in resp, resp
        sid = json.loads(resp["result"]["content"][0]["text"])["session_id"]
        cont = {"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                 "params": {"name": "loop", "arguments": {
                     "action": "resume", "session_id": sid, "response": "[]"}}}
        dispatch_request(cont, project_root=tmp_path)
    finally:
        _llm_client.resolve_default_client = real
    assert calls["count"] == 0, (
        "Forge constructed an LLM client during agent-driven iterate — "
        "the substrate boundary is broken. Round 3 contract: agent "
        "drives the LLM, forge stays LLM-free."
    )


def test_iterate_descriptions_carry_use_this_when():
    assert "plan" in TOOLS
    assert TOOLS["plan"]["description"].startswith("Use this when:"), "plan (loop actions)"


# ---- Round-4 cross-repo cherry-hunter (MHED-trust-gated) ---------------

# Round 4: the genuinely novel capability. recon_swarm walks N≤23 repos
# and returns a unified scout report; harvest diffs the union
# against a target and proposes graft candidates trust threshold-gated against
# the system's trust threshold. Hard caps come from system
# invariants — depth cap of 23 is the system's maximum delegation depth, not
# an arbitrary number. ZERO LLM is invoked.


def _make_tier_repo(root: Path, name: str, fn_name: str) -> Path:
    repo = root / name
    (repo / "a1_at_functions").mkdir(parents=True)
    (repo / "a1_at_functions" / f"{fn_name}.py").write_text(
        f"def {fn_name}(x):\n    return x\n", encoding="utf-8")
    return repo


def test_recon_swarm_returns_union_with_omega_invariant_holds(tmp_path):
    r1 = _make_tier_repo(tmp_path, "r1", "alpha")
    r2 = _make_tier_repo(tmp_path, "r2", "beta")
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "recon", "repos": [str(r1), str(r2)]}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.recon_swarm/v1"
    assert body["repo_count"] == 2
    assert body["union_symbol_count"] >= 2
    # OMEGA_0 anchor: the "no unmapped noise" invariant must hold.
    assert body["omega_invariant_holds"] is True
    assert body["omega_anchor"] == 0
    assert body["d_max_cap"] == 23


def test_recon_swarm_refuses_above_d_max(tmp_path):
    """delegation depth cap = 23 (from system invariant). 24+ repos must be refused
    via -32000, NOT silently truncated. Forge fails loud — ALWAYS."""
    r1 = _make_tier_repo(tmp_path, "r1", "x")
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "recon", "repos": [str(r1)] * 24}}}
    resp = dispatch_request(req, project_root=tmp_path)
    assert "error" in resp, resp
    assert resp["error"]["code"] == -32000
    assert "delegation depth cap" in resp["error"]["message"]


def test_harvest_proposes_target_lacks_source_has(tmp_path):
    """Target has `core`; sources have `alpha`, `beta`. Cherry hunt
    surfaces `alpha` and `beta` as graft candidates, NOT `core`."""
    target = _make_tier_repo(tmp_path, "tgt", "core")
    src1 = _make_tier_repo(tmp_path, "s1", "alpha")
    src2 = _make_tier_repo(tmp_path, "s2", "beta")
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "harvest",
                "target": str(target),
                "sources": [str(src1), str(src2)]}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.harvest/v1"
    qualnames = {c["qualname"] for c in body["candidates"]}
    assert "alpha" in qualnames or any("alpha" in q for q in qualnames)
    # Target's own `core` must NOT appear in the proposals.
    assert not any("core" == c["qualname"] for c in body["candidates"])


def test_harvest_carries_tau_trust_threshold(tmp_path):
    """Every cherry-hunt response cites the system trust threshold."""
    target = _make_tier_repo(tmp_path, "tgt", "core")
    src = _make_tier_repo(tmp_path, "s1", "alpha")
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "harvest",
                "target": str(target), "sources": [str(src)]}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    # trust threshold to 12 sig figs ≈ 0.998354360943...
    assert abs(body["tau_trust_threshold"] - (1820 / 1823)) < 1e-12
    # Each candidate carries an explicit trust_gated boolean.
    for c in body["candidates"]:
        assert isinstance(c["trust_gated"], bool)


def test_harvest_hydrates_remote_sources_before_scan(tmp_path, monkeypatch):
    """capability_scout clone_url values should flow into harvest directly."""
    target = _make_tier_repo(tmp_path, "tgt", "core")
    src = _make_tier_repo(tmp_path, "remote", "remote_alpha")

    from atomadic_forge.a3_og_features import cherry_hunter

    def fake_hydrate(seeds, *, cache_root, runner=None):
        assert seeds == ["https://github.com/org/remote.git"]
        assert cache_root == target.resolve() / ".atomadic-forge" / "seed_repos"
        return [src], [{
            "original": "https://github.com/org/remote.git",
            "path": str(src),
            "remote_url": "https://github.com/org/remote.git",
            "status": "cloned",
        }]

    monkeypatch.setattr(cherry_hunter, "hydrate_seed_repos", fake_hydrate)

    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "harvest",
                "target": str(target),
                "sources": ["https://github.com/org/remote.git"]}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])

    assert body["seed_hydration"][0]["status"] == "cloned"
    assert any("remote_alpha" in c["qualname"] for c in body["candidates"])


def test_harvest_descriptions_carry_use_this_when():
    assert "explore" in TOOLS
    assert TOOLS["explore"]["description"].startswith("Use this when:"), "explore"


def test_mhed_invariants_module_self_check():
    """The system constants module must load with all sovereign
    invariants intact. OMEGA_0 must literally equal zero — that's the
    corpus's no-hallucination anchor."""
    from atomadic_forge.a0_qk_constants.mhed_invariants import (
        D_MAX_DELEGATION,
        OMEGA_0,
        TAU_TRUST,
        TAU_TRUST_FLOAT,
    )
    assert D_MAX_DELEGATION == 23
    assert OMEGA_0 == 0
    assert TAU_TRUST.numerator == 1820
    assert TAU_TRUST.denominator == 1823
    assert abs(TAU_TRUST_FLOAT - 0.998354360943) < 1e-9


# ---- Round 3.5: agent-driven evolve (recursive iterate) ---------------

# evolve sequences N≤23 iterate rounds. Each round's output becomes
# seed for the next. Forge holds zero LLM clients — agent drives.
# Hard cap: delegation depth cap = 23 (corpus sovereign invariant).


def test_evolve_start_returns_session_and_first_prompt(tmp_path):
    output = tmp_path / "gen"
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "loop", "arguments": {
                "action": "evolve",
                "intent": "Build a calc", "output": str(output),
                "package": "calc", "rounds": 2,
                "iterations_per_round": 1, "target_score": 75.0}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.evolve_start/v1"
    assert body["evolve_session_id"].startswith("ev_")
    assert body["iterate_session_id"]
    assert body["rounds_total"] == 2
    assert body["d_max_cap"] == 23
    assert body["first_prompt"]


def test_evolve_step_round_transition_then_finalize(tmp_path):
    """Two-round evolve: first response triggers a round transition;
    second response triggers finalization with rounds_exhausted."""
    output = tmp_path / "gen"
    start = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
              "params": {"name": "loop", "arguments": {
                  "action": "evolve",
                  "intent": "thing", "output": str(output),
                  "package": "thing", "rounds": 2,
                  "iterations_per_round": 1}}}
    body = json.loads(dispatch_request(start, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    eid = body["evolve_session_id"]

    files = json.dumps([
        {"path": "src/thing/a1_at_functions/x.py",
         "content": "def x():\n    return 1\n"},
    ])
    step1 = {"jsonrpc": "2.0", "id": 2, "method": "tools/call",
              "params": {"name": "loop", "arguments": {
                  "action": "evolve_step", "evolve_session_id": eid, "response": files}}}
    b1 = json.loads(dispatch_request(step1, project_root=tmp_path)
                     ["result"]["content"][0]["text"])
    # iterations_per_round=1 + impossible-to-meet target_score → round
    # ends after one turn → next round opens.
    assert b1.get("round_complete") is True
    assert b1.get("new_round_started") is True
    assert b1["round_idx"] == 1
    assert b1["next_first_prompt"]

    step2 = {"jsonrpc": "2.0", "id": 3, "method": "tools/call",
              "params": {"name": "loop", "arguments": {
                  "action": "evolve_step", "evolve_session_id": eid, "response": files}}}
    b2 = json.loads(dispatch_request(step2, project_root=tmp_path)
                     ["result"]["content"][0]["text"])
    assert b2.get("evolve_complete") is True
    assert b2.get("halt_reason") in {"rounds_exhausted", "stagnation"}
    assert b2.get("rounds_completed") == 2
    assert isinstance(b2.get("score_trajectory"), list)


def test_evolve_start_refuses_above_d_max(tmp_path):
    """corpus depth cap of 23 is a hard cap on rounds; 24+ must fail loud."""
    output = tmp_path / "gen"
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "loop", "arguments": {
                "action": "evolve", "intent": "x", "output": str(output), "rounds": 24}}}
    resp = dispatch_request(req, project_root=tmp_path)
    assert "error" in resp
    assert resp["error"]["code"] == -32000
    assert "delegation depth cap" in resp["error"]["message"]


def test_evolve_step_unknown_session_returns_error(tmp_path):
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "loop", "arguments": {
                "action": "evolve_step", "evolve_session_id": "ev_deadbeef", "response": "[]"}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body.get("evolve_complete") is True
    assert body.get("halt_reason") == "unknown_session"


def test_evolve_descriptions_carry_use_this_when():
    assert "plan" in TOOLS
    assert TOOLS["plan"]["description"].startswith("Use this when:")


def test_evolve_holds_no_llm_client(tmp_path):
    """Substrate guarantee: forge does NOT construct an LLM client
    during the evolve loop. The whole point is that the agent drives
    the LLM; forge sequences the rounds."""
    from atomadic_forge.a1_at_functions import llm_client as _llm_client
    calls = {"count": 0}
    real = _llm_client.resolve_default_client

    def spy(*a, **kw):
        calls["count"] += 1
        return real(*a, **kw)

    _llm_client.resolve_default_client = spy
    try:
        start = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
                  "params": {"name": "loop", "arguments": {
                      "action": "evolve",
                      "intent": "x", "output": str(tmp_path / "gen"),
                      "rounds": 1}}}
        body = json.loads(dispatch_request(start, project_root=tmp_path)
                           ["result"]["content"][0]["text"])
        step = {"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                 "params": {"name": "loop", "arguments": {
                     "action": "evolve_step",
                     "evolve_session_id": body["evolve_session_id"],
                     "response": "[]"}}}
        dispatch_request(step, project_root=tmp_path)
    finally:
        _llm_client.resolve_default_client = real
    assert calls["count"] == 0, (
        "Forge constructed an LLM client during agent-driven evolve — "
        "substrate boundary broken."
    )


# ---- tool_factory (forge eats forge — meta-tool that scaffolds tools) ---


def test_tool_factory_emits_full_scaffold(tmp_path):
    """tool_factory (now plan action=scaffold) returns the four-piece scaffold for a new tool."""
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "plan", "arguments": {
                "action": "scaffold",
                "tool_name": "verify",
                "use_this_when": "you want one composite go/no-go gate "
                                 "covering wire + certify + score_patch",
                "body_description": "Returns a single PASS/REFINE verdict "
                                    "synthesizing structural integrity "
                                    "across wire, certify, and patch risk."}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.tool_factory/v1"
    assert body["tool_name"] == "verify"
    # All four scaffold sections present.
    assert "stub_block" in body["a1_inserts"]
    assert "tools_entry" in body["a1_inserts"]
    assert "all_export_entry" in body["a1_inserts"]
    assert "import_line" in body["a3_inserts"]
    assert "bound_block" in body["a3_inserts"]
    assert "test_block" in body["test_inserts"]
    assert isinstance(body["acceptance_checklist"], list)
    assert len(body["acceptance_checklist"]) >= 5
    # Use-this-when prepended verbatim.
    assert "Use this when:" in body["a1_inserts"]["tools_entry"]


def test_tool_factory_rejects_invalid_tool_name(tmp_path):
    """Names with leading underscores / dashes / spaces are refused."""
    for bad_name in ("_leading", "-dashed", "with space", "Camel"):
        req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
                "params": {"name": "plan", "arguments": {
                    "action": "scaffold",
                    "tool_name": bad_name,
                    "use_this_when": "x",
                    "body_description": "y"}}}
        resp = dispatch_request(req, project_root=tmp_path)
        # The dispatcher catches the ValueError and returns -32000; the
        # broadened except from R1 ensures the transport stays alive.
        assert resp.get("error", {}).get("code") == -32000, bad_name


def test_tool_factory_apply_mutates_files_idempotent(tmp_path, monkeypatch):
    """The auto-apply path actually mutates mcp_protocol.py +
    mcp_server.py + test_mcp_protocol.py with the scaffold pieces.
    Idempotent: re-running with the same tool_name is a no-op."""
    # Build a minimal mock repo with the three files.
    src = tmp_path / "src" / "atomadic_forge"
    (src / "a1_at_functions").mkdir(parents=True)
    (src / "a3_og_features").mkdir(parents=True)
    (tmp_path / "tests").mkdir()

    proto = src / "a1_at_functions" / "mcp_protocol.py"
    proto.write_text(
        '"""mock."""\n'
        'TOOLS: dict[str, dict[str, Any]] = {\n'
        '    "recon_swarm": {"name": "recon_swarm"},\n'
        "}\n"
        "\n"
        "__all__ = [\n"
        '    "TOOLS",\n'
        '    "register_synergy_scan_handler",\n'
        "]\n",
        encoding="utf-8",
    )
    server = src / "a3_og_features" / "mcp_server.py"
    server.write_text(
        '"""mock."""\n'
        "from ..a1_at_functions.mcp_protocol import (\n"
        "    register_synergy_scan_handler,\n"
        ")\n"
        "from .synergy_feature import SynergyScan as _SynergyScan\n",
        encoding="utf-8",
    )
    test_file = tmp_path / "tests" / "test_mcp_protocol.py"
    test_file.write_text(
        "PINNED = {\n"
        "        # tool_factory: meta-tool that scaffolds new MCP tools (forge eats forge):\n"
        '        "tool_factory",\n'
        "}\n",
        encoding="utf-8",
    )

    from atomadic_forge.a3_og_features.tool_factory import scaffold_tool

    artifact = scaffold_tool(
        tool_name="brand_new_demo",
        use_this_when="you want to verify the auto-apply path works",
        body_description="Test artifact for the apply-mode dogfood loop.",
        apply=True, project_root=tmp_path,
    )
    assert artifact.applied is True
    assert len(artifact.files_modified) >= 3
    # Verify the inserts actually landed.
    proto_after = proto.read_text(encoding="utf-8")
    assert '"brand_new_demo"' in proto_after
    assert "_tool_brand_new_demo_unbound" in proto_after
    assert "register_brand_new_demo_handler" in proto_after
    server_after = server.read_text(encoding="utf-8")
    assert "register_brand_new_demo_handler" in server_after
    assert "_bound_brand_new_demo" in server_after
    test_after = test_file.read_text(encoding="utf-8")
    assert "brand_new_demo" in test_after

    # Idempotency: a second apply should refuse (tool already present).
    art2 = scaffold_tool(
        tool_name="brand_new_demo",
        use_this_when="x", body_description="y",
        apply=True, project_root=tmp_path,
    )
    assert art2.applied is False
    assert any("already present" in n for n in art2.notes)


def test_tool_factory_bound_block_unpacks_kwargs(tmp_path):
    """Regression for WIS-3cd3c921: bound block must call impl with
    ``**args`` (after merging project_root), NOT a single positional
    dict. Pre-fix this emitted ``_impl(args)`` which raised TypeError
    on every keyword-only handler (e.g. wisdom_feature.record_wisdom).
    """
    from atomadic_forge.a3_og_features.tool_factory import scaffold_tool
    art = scaffold_tool(
        tool_name="kwargs_check",
        use_this_when="you want to verify the bound block unpacks kwargs",
        body_description="Regression guard for the kwargs-only adapter fix.",
        handler_module="atomadic_forge.a3_og_features.wisdom_feature",
        handler_callable="record_wisdom",
    )
    bound = art.a3_inserts["bound_block"]
    # Must unpack kwargs.
    assert "_impl(**_kw)" in bound, bound
    # Must merge project_root from dispatcher context.
    assert "_kw.setdefault('project_root', project_root)" in bound, bound
    # Must NOT use the broken positional shape.
    assert "_kwargs_check_impl(args)" not in bound, bound


def test_tool_factory_clean_call_does_not_pollute_description(tmp_path):
    """Regression for WIS-c423811c (later reclassified as misdiagnosis):
    a clean spec must produce a clean description — no XML tags, no
    embedded JSON Schema text, no leakage from sibling parameters.
    """
    from atomadic_forge.a3_og_features.tool_factory import scaffold_tool
    art = scaffold_tool(
        tool_name="clean_check",
        use_this_when="you want a clean output verification",
        body_description="Plain body, no special characters.",
        input_schema={
            "type": "object",
            "properties": {"x": {"type": "string"}},
            "additionalProperties": False,
        },
        handler_module="atomadic_forge.a3_og_features.wisdom_feature",
        handler_callable="record_wisdom",
    )
    tools_entry = art.a1_inserts["tools_entry"]
    # The description must NOT contain schema-text leakage.
    assert "</body_description>" not in tools_entry
    assert "<parameter name" not in tools_entry
    # The inputSchema must carry the actual schema, not an empty {}.
    assert "'properties': {'x':" in tools_entry or '"properties": {"x":' in tools_entry
    # The description should start with the trigger sentence.
    assert "Use this when: you want a clean output verification" in tools_entry


def test_tool_factory_create_module_emits_starter_template(tmp_path):
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "plan", "arguments": {
                "action": "scaffold",
                "tool_name": "self_evolve",
                "use_this_when": "you want forge to evolve forge",
                "body_description": "Recursive forge-on-forge.",
                "create_module": True,
                "handler_callable": "self_evolve"}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["optional_module_text"]
    assert 'SCHEMA_VERSION_V1 = "atomadic-forge.self_evolve/v1"' in body["optional_module_text"]


def test_tool_factory_description_carries_use_this_when():
    assert TOOLS["plan"]["description"].startswith("Use this when:")


# ---- call_graph (harvested from Code Pathfinder competitive audit) ----


def test_call_graph_walks_a_package(tmp_path):
    """Build a tiny package with a known call edge and verify
    call_graph finds it forwards (callees) and backwards (callers)."""
    pkg = tmp_path / "src" / "demo"
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "a1.py").write_text(
        "def helper(x):\n    return x + 1\n", encoding="utf-8")
    (pkg / "a4.py").write_text(
        "from demo.a1 import helper\n"
        "def main(x):\n    return helper(x) + 1\n",
        encoding="utf-8")

    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "call_graph",
                "qualname": "demo.a1.helper",
                "project_root": str(tmp_path),
                "package": "demo",
                "direction": "callers",
                "max_depth": 2,
            }}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.call_graph/v1"
    # target_in_graph means "did the package walk see the symbol at all"
    # (helper is a function in the package, so True even though we asked
    # for callers direction).
    assert body["target_in_graph"] is True
    # main calls helper → main appears as a caller of helper.
    caller_qualnames = {c["qualname"] for c in body["callers"]}
    assert "demo.a4.main" in caller_qualnames


def test_call_graph_callees_direction(tmp_path):
    pkg = tmp_path / "src" / "demo"
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "a1.py").write_text(
        "def leaf():\n    return 1\n"
        "def mid():\n    return leaf()\n"
        "def root():\n    return mid()\n",
        encoding="utf-8")

    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "call_graph",
                "qualname": "demo.a1.root",
                "project_root": str(tmp_path),
                "package": "demo",
                "direction": "callees",
                "max_depth": 3,
            }}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    callees = {c["qualname"] for c in body["callees"]}
    # root → mid → leaf transitively.
    assert "demo.a1.mid" in callees
    assert "demo.a1.leaf" in callees


def test_call_graph_rejects_invalid_max_depth(tmp_path):
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "call_graph",
                "qualname": "x.y.z",
                "max_depth": 99,
            }}}
    resp = dispatch_request(req, project_root=tmp_path)
    assert resp.get("error", {}).get("code") == -32000
    assert "max_depth" in resp["error"]["message"]


def test_call_graph_description_carries_use_this_when():
    assert TOOLS["explore"]["description"].startswith("Use this when:")


# ---- verify (umbrella composite) + smell_scan + call_graph aliases ----


def test_verify_returns_synthesized_verdict_on_clean_repo(tmp_path):
    """verify on a tier-clean tree returns a single synthesized verdict
    + the underlying gate reports."""
    pkg = tmp_path / "src" / "demo"
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "a1_at_functions").mkdir()
    (pkg / "a1_at_functions" / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "a1_at_functions" / "x.py").write_text(
        "def x():\n    return 1\n", encoding="utf-8")

    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "audit", "arguments": {
                "action": "composite",
                "project_root": str(tmp_path),
                "package": "demo",
                "fail_under": 0.0}}}  # accept any score for the test
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.verify/v1"
    assert body["verdict"] in {"PASS", "REFINE", "FAIL"}
    assert "wire" in body["gates_run"]
    assert "certify" in body["gates_run"]
    assert "next_command" in body
    assert isinstance(body["score"], float)


def test_verify_with_diff_invokes_score_patch(tmp_path):
    diff = (
        "diff --git a/x.py b/x.py\n"
        "--- a/x.py\n+++ b/x.py\n"
        "@@\n+def x():\n+    return 1\n"
    )
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "audit", "arguments": {
                "action": "composite",
                "project_root": str(tmp_path),
                "diff": diff,
                "fail_under": 0.0}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert "score_patch" in body["gates_run"]
    assert body["score_patch"] is not None


def test_smell_scan_finds_high_complexity_function(tmp_path):
    """A function with 12 branch points should trigger CC > 10."""
    src = tmp_path / "complicated.py"
    branches = "\n".join(
        f"    if x == {i}:\n        return {i}" for i in range(12)
    )
    src.write_text(
        f"def messy(x):\n{branches}\n    return -1\n",
        encoding="utf-8",
    )
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "smell_scan",
                "project_root": str(tmp_path),
                "cc_threshold": 10}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.smell_scan/v1"
    assert body["function_count"] >= 1
    assert any(f["qualname"] == "messy" and f["complexity"] > 10
               for f in body["complexity_findings"])
    assert body["smell_score"] < 100  # penalty applied


def test_smell_scan_finds_duplicated_function_bodies(tmp_path):
    """Two functions with the same body shape should appear in
    duplication_findings."""
    # Identical body shape (≥5 LOC so the dup filter applies).
    body = (
        "def f(x):\n"
        "    a = x + 1\n"
        "    b = a * 2\n"
        "    c = b - 1\n"
        "    d = c * 3\n"
        "    e = d + 1\n"
        "    return e\n"
    )
    (tmp_path / "a.py").write_text(body, encoding="utf-8")
    (tmp_path / "b.py").write_text(body, encoding="utf-8")
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "smell_scan",
                "project_root": str(tmp_path)}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    # alpha and beta have identical AST shape.
    assert len(body["duplication_findings"]) >= 1


def test_call_graph_resolves_init_reexport_alias(tmp_path):
    """When pkg/__init__.py does `from .foo import bar`, callers
    that resolve to ``pkg.bar`` should canonicalize to ``pkg.foo.bar``."""
    pkg = tmp_path / "src" / "demo"
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text(
        "from .foo import bar\n", encoding="utf-8")
    (pkg / "foo.py").write_text(
        "def bar(x):\n    return x\n", encoding="utf-8")
    (pkg / "user.py").write_text(
        "from demo import bar\n"
        "def caller(x):\n    return bar(x)\n",
        encoding="utf-8")

    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "call_graph",
                "qualname": "demo.foo.bar",
                "project_root": str(tmp_path),
                "package": "demo",
                "direction": "callers",
                "max_depth": 2}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["alias_count"] >= 1
    # demo.user.caller should be a caller of demo.foo.bar (canonical).
    caller_qualnames = {c["qualname"] for c in body["callers"]}
    assert "demo.user.caller" in caller_qualnames


def test_verify_smell_call_graph_descriptions_carry_use_this_when():
    for name in ("audit", "explore"):
        assert TOOLS[name]["description"].startswith("Use this when:"), name


# ---- call_graph_summary (pyan whole-graph synthesis) -------------------


def test_call_graph_summary_returns_portfolio(tmp_path):
    """Whole-package summary surfaces hotspots and orphans."""
    pkg = tmp_path / "src" / "demo"
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "core.py").write_text(
        "def leaf():\n    return 1\n"
        "def hot(x):\n    return leaf() + leaf() + x\n",
        encoding="utf-8")
    (pkg / "util.py").write_text(
        "from demo.core import hot\n"
        "def run(x):\n    return hot(x)\n",
        encoding="utf-8")

    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
           "params": {"name": "explore", "arguments": {
               "action": "call_graph_summary",
               "project_root": str(tmp_path),
               "package": "demo",
               "top_n": 5,
           }}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                      ["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.call_graph_summary/v1"
    assert body["total_callers"] >= 1
    assert "hotspots" in body
    assert "uncalled_callers" in body
    assert isinstance(body["max_call_depth"], int)


def test_call_graph_summary_schema_in_explore_enum():
    schema = TOOLS["explore"]["inputSchema"]
    assert "call_graph_summary" in schema["properties"]["action"]["enum"]


# ---- churn (repomix git-log synthesis) ---------------------------------


def test_churn_on_non_git_dir_returns_unavailable(tmp_path):
    """churn degrades gracefully when git history is absent."""
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
           "params": {"name": "explore", "arguments": {
               "action": "churn",
               "project_root": str(tmp_path),
           }}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                      ["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.git_churn/v1"
    assert body["available"] is False


def test_churn_schema_in_explore_enum():
    schema = TOOLS["explore"]["inputSchema"]
    assert "churn" in schema["properties"]["action"]["enum"]


def test_churn_explore_description_mentions_churn():
    assert "churn" in TOOLS["explore"]["description"]


# ---- cna_check (hardwired CNA gate) -----------------------------------


def test_cna_check_pass_on_novel_name(tmp_path):
    """Proposed name with no overlap → PASS verdict."""
    src = tmp_path / "demo.py"
    src.write_text(
        "def alpha():\n    return 1\n", encoding="utf-8")
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "audit", "arguments": {
                    "action": "cna",
                "proposed_name": "zylophone_quark",
                "project_root": str(tmp_path)}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.cna_check/v1"
    assert body["verdict"] == "PASS"
    assert body["name_overlaps"] == []


def test_cna_check_reject_on_exact_name_collision(tmp_path):
    """Proposed name == existing symbol → REJECT (hard band)."""
    src = tmp_path / "demo.py"
    src.write_text(
        "def alpha():\n    return 1\n", encoding="utf-8")
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "audit", "arguments": {
                    "action": "cna",
                "proposed_name": "alpha",
                "project_root": str(tmp_path)}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["verdict"] == "REJECT"
    assert any(f["band"] == "hard" for f in body["name_overlaps"])
    assert "alpha" in body["next_command"].lower() or "REJECT" in body["next_command"]


def test_cna_check_reject_on_identical_body(tmp_path):
    """Proposed body whose AST shape matches an existing function →
    REJECT (the harder of the two body / name signals)."""
    body_text = (
        "def x_alpha():\n"
        "    a = 1\n"
        "    b = 2\n"
        "    c = 3\n"
        "    d = 4\n"
        "    return d\n"
    )
    src = tmp_path / "existing.py"
    src.write_text(body_text, encoding="utf-8")
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "audit", "arguments": {
                    "action": "cna",
                "proposed_name": "totally_unrelated_zigzag_xyz",
                "proposed_body": body_text,
                "project_root": str(tmp_path)}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["verdict"] == "REJECT"
    assert len(body["body_overlaps"]) >= 1


def test_cna_check_description_carries_use_this_when():
    assert TOOLS["audit"]["description"].startswith("Use this when:")


# ---- emergent_swarm (Round 5: cross-repo emergent compositions) -------


def test_emergent_swarm_runs_on_single_repo(tmp_path):
    """v1 smoke: at minimum, emergent_swarm should accept a single
    repo and return a structured response with the schema."""
    pkg = tmp_path / "src" / "demo"
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "a1_at_functions").mkdir()
    (pkg / "a1_at_functions" / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "a1_at_functions" / "x.py").write_text(
        "def x(a: int) -> int:\n    return a + 1\n", encoding="utf-8")

    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "swarm",
                "repos": [{"src_root": str(pkg), "package": "demo"}],
                "top_n": 5, "max_depth": 2,
                "domain_jump_required": False}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.emergent_swarm/v1"
    assert body["repo_count"] == 1
    assert body["d_max_cap"] == 23
    assert "per_repo" in body
    assert isinstance(body["candidates"], list)


def test_emergent_swarm_refuses_above_d_max(tmp_path):
    """corpus depth cap of 23 enforced — fail-loud not silent-truncate."""
    repo = {"src_root": str(tmp_path), "package": "demo"}
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "swarm", "repos": [repo] * 24}}}
    resp = dispatch_request(req, project_root=tmp_path)
    assert "error" in resp
    assert resp["error"]["code"] == -32000
    assert "delegation depth cap" in resp["error"]["message"]


# ---- v0.9.x token-reduction sprint -----------------------------------


def test_pinned_tools_snapshot_matches_tools_dict(tmp_path):
    """F-3 fix: the pinned-tools assertion auto-derives from
    ``set(TOOLS.keys())`` rather than a hand-maintained literal. This
    test guards the discoverable surface — adding a new tool without
    updating the snapshot file is an intentional CI failure that
    forces conscious surface decisions."""
    import json as _j
    from pathlib import Path as _P
    snapshot_path = (
        _P(__file__).resolve().parent / "tools_snapshot.json"
    )
    actual = sorted(TOOLS.keys())
    if not snapshot_path.exists():
        # First-run bootstrap.
        snapshot_path.write_text(
            _j.dumps(actual, indent=2), encoding="utf-8",
        )
    expected = _j.loads(snapshot_path.read_text(encoding="utf-8"))
    if expected != actual:
        added = sorted(set(actual) - set(expected))
        removed = sorted(set(expected) - set(actual))
        diff = (
            f"\n  added:   {added}"
            f"\n  removed: {removed}"
            f"\n\nIf intentional, regenerate via:\n"
            f"  python -c 'import json,pathlib; "
            f"from atomadic_forge.a1_at_functions.mcp_protocol "
            f"import TOOLS; "
            f"pathlib.Path(\"tests/tools_snapshot.json\")"
            f".write_text(json.dumps(sorted(TOOLS.keys()),indent=2))'"
        )
        raise AssertionError(
            f"TOOLS surface drift detected: {diff}"
        )


def test_forge_locate_returns_tools_dict_range(tmp_path):
    """forge_locate finds the TOOLS dict insertion point in a small
    mock mcp_protocol.py."""
    proto = tmp_path / "src" / "atomadic_forge" / "a1_at_functions"
    proto.mkdir(parents=True)
    (proto / "mcp_protocol.py").write_text(
        "from typing import Any\n"
        "TOOLS: dict[str, dict[str, Any]] = {\n"
        '    "x": {},\n'
        "}\n"
        "__all__ = [\n"
        '    "TOOLS",\n'
        "]\n",
        encoding="utf-8",
    )
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "plan", "arguments": {
                "action": "locate",
                "point": "tools_dict",
                "project_root": str(tmp_path)}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["found"] is True
    assert body["line_start"] == 2
    assert body["line_end"] == 4


def test_forge_locate_unknown_point_returns_structured_error(tmp_path):
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "plan", "arguments": {
                "action": "locate",
                "point": "not_a_real_anchor"}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["found"] is False
    assert "unknown" in body["note"].lower()


def test_commit_compose_emits_structured_body(tmp_path):
    """forge_util commit returns a populated CommitComposeArtifact even
    when there's no git diff (notes that fact instead of crashing)."""
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "plan", "arguments": {
                "action": "commit",
                "intent": "ship the v0.9.x token-reduction sprint",
                "commit_type": "ship",
                "include_coauthor": True,
                "project_root": str(tmp_path)}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.commit_compose/v1"
    assert body["subject"].startswith("ship: ")
    assert "Co-Authored-By: Claude" in body["full_message"]


def test_commit_compose_rejects_unknown_type(tmp_path):
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "plan", "arguments": {
                "action": "commit",
                "intent": "x",
                "commit_type": "absurdtype"}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["full_message"] == ""
    assert any("unknown commit_type" in n for n in body["notes"])


def test_schema_version_registry_covers_every_tool():
    """F-6 fix: registry is the single source of truth for tool
    schema versions. Every tool in TOOLS must have an entry here, or
    the test fails — preventing future drift."""
    from atomadic_forge.a0_qk_constants.schema_version_registry import (
        SCHEMA_VERSIONS,
    )
    missing = sorted(set(TOOLS.keys()) - set(SCHEMA_VERSIONS.keys()))
    assert not missing, (
        f"Tools in TOOLS but missing from SCHEMA_VERSIONS: {missing}. "
        f"Add the entry to "
        f"src/atomadic_forge/a0_qk_constants/schema_version_registry.py."
    )


def test_emergent_swarm_cycle2_corroborates_with_call_graph(tmp_path):
    """Cycle 2 sharpening: chains whose edges ALSO appear as call-graph
    caller→callee edges get edge_confidence=static_call_confirmed.
    Chains without that corroboration stay ast_inferred AND get
    novel_composition=true (the prime emergent-scan signal)."""
    pkg = tmp_path / "src" / "demo"
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "a1_at_functions").mkdir()
    (pkg / "a1_at_functions" / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "a1_at_functions" / "x.py").write_text(
        "def x(a: int) -> int:\n    return a + 1\n", encoding="utf-8")

    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "explore", "arguments": {
                "action": "swarm",
                "repos": [{"src_root": str(pkg), "package": "demo"}],
                "top_n": 5, "max_depth": 2,
                "corroborate_with_call_graph": True,
                "domain_jump_required": False}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["corroborate_with_call_graph"] is True
    assert "novel_composition_count" in body
    assert "static_confirmed_count" in body


def test_emergent_swarm_description_carries_use_this_when():
    assert TOOLS["explore"]["description"].startswith("Use this when:")


# ---- guard_install (standing guard) -----------------------------------


def test_guard_install_dry_run_lists_planned_writes(tmp_path):
    """apply=false plans the writes without touching the filesystem."""
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "audit", "arguments": {
                "action": "guard",
                "project_root": str(tmp_path),
                "min_certify_score": 90,
                "apply": False}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert body["schema_version"] == "atomadic-forge.guard_install/v1"
    # Four planned files.
    assert len(body["files_written"]) == 4
    paths = set(body["files_written"])
    assert any("pre-commit" in p for p in paths)
    assert any("forge-guard" in p for p in paths)
    assert any("pyproject.guard" in p for p in paths)
    assert any("CONTRIBUTING.guard" in p for p in paths)
    # Dry-run does not touch the filesystem.
    assert not (tmp_path / ".github").exists()


def test_guard_install_apply_writes_files(tmp_path):
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "audit", "arguments": {
                "action": "guard",
                "project_root": str(tmp_path),
                "min_certify_score": 95,
                "max_cyclomatic": 8,
                "strict_mode": True,
                "apply": True}}}
    dispatch_request(req, project_root=tmp_path)
    assert (tmp_path / ".github" / "workflows" / "forge-guard.yml").exists()
    assert (tmp_path / "pyproject.guard.toml").exists()
    assert (tmp_path / "CONTRIBUTING.guard.md").exists()
    # Contract values made it into the pyproject template.
    pyproject = (tmp_path / "pyproject.guard.toml").read_text(encoding="utf-8")
    assert "min_certify_score = 95" in pyproject
    assert "max_cyclomatic = 8" in pyproject
    assert "strict_mode = true" in pyproject
    # Workflow has the threshold injected.
    workflow = (tmp_path / ".github" / "workflows" / "forge-guard.yml").read_text(encoding="utf-8")
    assert "--fail-under 95" in workflow


def test_guard_install_skips_existing_files_without_overwrite(tmp_path):
    """Default behavior: existing files stay put unless overwrite=true."""
    pre_existing = tmp_path / "pyproject.guard.toml"
    pre_existing.write_text("# pre-existing content\n", encoding="utf-8")
    req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "audit", "arguments": {
                "action": "guard",
                "project_root": str(tmp_path),
                "apply": True, "overwrite": False}}}
    body = json.loads(dispatch_request(req, project_root=tmp_path)
                       ["result"]["content"][0]["text"])
    assert "pyproject.guard.toml" in body["files_skipped"]
    # Pre-existing content untouched.
    assert pre_existing.read_text(encoding="utf-8") == "# pre-existing content\n"


def test_guard_install_description_carries_use_this_when():
    assert TOOLS["audit"]["description"].startswith("Use this when:")


def test_emergent_swarm_and_guard_install_complete_the_billion_dollar_loop():
    """Sanity test on the strategic positioning: the substrate now has
    BOTH proactive composition discovery (emergent) AND
    architectural-regression prevention (maintain guard). Together they
    close the 'spaghetti can never come back' loop forge needs to be
    investor-ready."""
    assert "explore" in TOOLS
    assert "audit" in TOOLS


def test_score_patch_refines_when_diff_has_no_chunks():
    """Substrate trust contract: ``score_patch`` must NOT return a green
    PASS when the input doesn't parse into any file chunks. An agent
    that trusts a silent green on malformed input would ship unscored
    code. Round-1 fix sets ``needs_human_review=True`` and emits a
    structured 'could not score' note."""
    from atomadic_forge.a1_at_functions.patch_scorer import score_patch

    result = score_patch("this is not a real diff at all")
    assert result["file_count"] == 0
    assert result["needs_human_review"] is True
    assert any("could not" in n.lower() or "did not parse" in n.lower()
               or "needs_human_review" in n.lower()
               for n in result.get("notes", []))
