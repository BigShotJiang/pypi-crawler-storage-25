"""Tests for a2 remote seed hydration cache.

Golden Path Lane C W4 follow-on coverage for remote harvest/create seeds.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from atomadic_forge.a2_mo_composites.remote_seed_store import (
    RemoteSeedError,
    hydrate_seed_repo,
    normalize_remote_seed_url,
)


def _ok(_cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(_cmd, 0, stdout="", stderr="")


def test_normalize_remote_seed_url_preserves_https() -> None:
    assert (
        normalize_remote_seed_url("https://github.com/org/repo.git")
        == "https://github.com/org/repo.git"
    )


def test_normalize_remote_seed_url_repairs_path_mangled_https() -> None:
    assert (
        normalize_remote_seed_url(Path("https:/github.com/org/repo.git"))
        == "https://github.com/org/repo.git"
    )


def test_normalize_remote_seed_url_returns_none_for_local_path(tmp_path: Path) -> None:
    assert normalize_remote_seed_url(tmp_path) is None


def test_hydrate_local_seed_returns_resolved_path(tmp_path: Path) -> None:
    seed = tmp_path / "seed"
    seed.mkdir()
    out = hydrate_seed_repo(seed, cache_root=tmp_path / "cache")
    assert out.path == seed.resolve()
    assert out.remote_url is None
    assert out.status == "local"


def test_hydrate_remote_seed_clones_into_cache(tmp_path: Path) -> None:
    calls: list[list[str]] = []

    def runner(cmd: list[str]) -> subprocess.CompletedProcess[str]:
        calls.append(cmd)
        # Simulate git clone creating a repo.
        Path(cmd[-1]).mkdir(parents=True, exist_ok=True)
        (Path(cmd[-1]) / ".git").mkdir()
        return _ok(cmd)

    out = hydrate_seed_repo(
        "https://github.com/org/repo.git",
        cache_root=tmp_path / "cache",
        runner=runner,
    )

    assert out.status == "cloned"
    assert out.remote_url == "https://github.com/org/repo.git"
    assert out.path == (tmp_path / "cache" / "github.com-org-repo").resolve()
    assert calls[0][:5] == ["git", "-c", "core.longpaths=true", "clone", "--depth=1"]


def test_hydrate_remote_seed_updates_existing_cache(tmp_path: Path) -> None:
    repo = tmp_path / "cache" / "github.com-org-repo"
    (repo / ".git").mkdir(parents=True)
    calls: list[list[str]] = []

    def runner(cmd: list[str]) -> subprocess.CompletedProcess[str]:
        calls.append(cmd)
        return _ok(cmd)

    out = hydrate_seed_repo(
        "https://github.com/org/repo.git",
        cache_root=tmp_path / "cache",
        runner=runner,
    )

    assert out.status == "updated"
    assert calls[0][:7] == [
        "git", "-c", "core.longpaths=true", "-C", str(repo.resolve()),
        "fetch", "--depth=1",
    ]
    assert calls[1][:7] == [
        "git", "-c", "core.longpaths=true", "-C", str(repo.resolve()),
        "reset", "--hard",
    ]


def test_hydrate_remote_seed_failure_is_f_coded(tmp_path: Path) -> None:
    def runner(cmd: list[str]) -> subprocess.CompletedProcess[str]:
        return subprocess.CompletedProcess(cmd, 1, stdout="", stderr="network down")

    with pytest.raises(RemoteSeedError, match="F0018"):
        hydrate_seed_repo(
            "https://github.com/org/repo.git",
            cache_root=tmp_path / "cache",
            runner=runner,
        )
