"""Unit tests for a1 call_graph_summary — whole-package portfolio view."""
from pathlib import Path

from atomadic_forge.a1_at_functions.call_graph import (
    SCHEMA_VERSION_CALL_GRAPH_SUMMARY_V1,
    build_call_graph_summary,
)


def _make_pkg(tmp_path: Path, name: str = "demo") -> Path:
    pkg = tmp_path / "src" / name
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    return pkg


def test_summary_schema_version(tmp_path):
    _make_pkg(tmp_path)
    result = build_call_graph_summary({"project_root": str(tmp_path), "package": "demo"})
    assert result["schema_version"] == SCHEMA_VERSION_CALL_GRAPH_SUMMARY_V1


def test_summary_hotspot_is_most_called(tmp_path):
    pkg = _make_pkg(tmp_path)
    (pkg / "lib.py").write_text(
        "def leaf():\n    return 1\n"
        "def mid():\n    return leaf()\n"
        "def top():\n    return leaf() + mid()\n",
        encoding="utf-8")
    result = build_call_graph_summary(
        {"project_root": str(tmp_path), "package": "demo", "top_n": 5})
    hotspots = result["hotspots"]
    assert len(hotspots) >= 1
    # leaf() is called by mid and top → highest fan-in
    top_name = hotspots[0]["qualname"]
    assert "leaf" in top_name


def test_summary_uncalled_callers_found(tmp_path):
    pkg = _make_pkg(tmp_path)
    (pkg / "isolated.py").write_text(
        "def orphan():\n    return 42\n",
        encoding="utf-8")
    result = build_call_graph_summary(
        {"project_root": str(tmp_path), "package": "demo", "top_n": 10})
    uncalled = result["uncalled_callers"]
    assert any("orphan" in name for name in uncalled)


def test_summary_max_depth_non_negative(tmp_path):
    _make_pkg(tmp_path)
    result = build_call_graph_summary({"project_root": str(tmp_path), "package": "demo"})
    assert isinstance(result["max_call_depth"], int)
    assert result["max_call_depth"] >= 0


def test_summary_total_edges_matches_calls(tmp_path):
    pkg = _make_pkg(tmp_path)
    (pkg / "a.py").write_text(
        "def x():\n    return 1\n"
        "def y():\n    return x()\n",
        encoding="utf-8")
    result = build_call_graph_summary(
        {"project_root": str(tmp_path), "package": "demo"})
    assert result["total_edges"] >= 1
