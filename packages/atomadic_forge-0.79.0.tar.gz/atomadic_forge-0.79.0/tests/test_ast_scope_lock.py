"""Tier verification — AST scope locks for Nexus-backed swarms.

Golden Path Lane C W6 follow-on tests. These pin the local, deterministic
side of multi-repo AST blueprints before the a3 Nexus bridge optionally
attests the locks through lineage.
"""
from __future__ import annotations

import json

from atomadic_forge.a1_at_functions.ast_scope_lock import (
    ast_scope_plan,
    build_ast_scope_blueprint,
    mint_ast_locks,
)
from atomadic_forge.a1_at_functions.mcp_protocol import dispatch_request


def _write_repo(root):
    src = root / "src" / "demo" / "a1_at_functions"
    src.mkdir(parents=True)
    target = src / "auth.py"
    target.write_text(
        """
def keep_token(value):
    return value.strip()


class AuthClient:
    def refresh(self, token):
        return keep_token(token)
""".lstrip(),
        encoding="utf-8",
    )
    return target


def test_blueprint_targets_one_ast_node(tmp_path):
    _write_repo(tmp_path)

    out = build_ast_scope_blueprint(
        project_roots=[tmp_path],
        targets=["AuthClient.refresh"],
    )

    assert out["schema_version"] == "atomadic-forge.ast_scope/v1"
    assert out["node_count"] == 1
    node = out["nodes"][0]
    assert node["kind"] == "method"
    assert node["qualname"].endswith("AuthClient.refresh")
    assert node["start_line"] <= node["end_line"]
    assert out["compressed_context"]["token_savings_pct"] >= 0.0


def test_locks_are_deterministic_and_scope_bounded(tmp_path):
    _write_repo(tmp_path)
    blueprint = build_ast_scope_blueprint(
        project_roots=[tmp_path],
        targets=["keep_token", "AuthClient.refresh"],
    )

    left = mint_ast_locks(blueprint, agent_ids=["agent-a", "agent-b"], ttl_secs=120)
    right = mint_ast_locks(blueprint, agent_ids=["agent-a", "agent-b"], ttl_secs=120)

    assert left == right
    assert left["lock_count"] == 2
    assert left["locks"][0]["agent_id"] == "agent-a"
    assert left["locks"][1]["agent_id"] == "agent-b"
    assert left["locks"][0]["allowed_file"].endswith("auth.py")
    assert left["locks"][0]["nexus_live_op"] == "lineage_record"


def test_ast_scope_plan_returns_pass_summary(tmp_path):
    _write_repo(tmp_path)

    out = ast_scope_plan(
        project_roots=[tmp_path],
        targets=["keep_token"],
        agent_ids=["agent-a"],
    )

    assert out["schema_version"] == "atomadic-forge.ast_scope_plan/v1"
    assert out["verdict"] == "PASS"
    assert "estimated token savings" in out["summary"]


def test_mcp_audit_ast_scope_gracefully_skips_nexus_without_key(tmp_path, monkeypatch):
    _write_repo(tmp_path)
    for name in (
        "ATOMADIC_MASTER_KEY",
        "ATOMADIC_SUBSCRIPTION_KEY",
        "FORGE_API_KEY",
        "FORGE_MASTER_API_KEY",
        "AAAA_NEXUS_API_KEY",
        "ATOMADIC_VAULT_ENV",
    ):
        monkeypatch.delenv(name, raising=False)

    req = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": "audit",
            "arguments": {
                "action": "ast_scope",
                "project_roots": [str(tmp_path)],
                "targets": ["AuthClient.refresh"],
                "agent_ids": ["agent-a"],
                "attest_nexus": True,
            },
        },
    }

    body = json.loads(dispatch_request(req, project_root=tmp_path)["result"]["content"][0]["text"])
    assert body["verdict"] == "PASS"
    assert body["locks"]["lock_count"] == 1
    assert body["nexus"]["mirrored"] is False
    assert "x402" in body["nexus"]["premium_hint"]
