# Changelog

## Unreleased

## v0.79.0 — 2026-05-08

- feat(forge): replay â€” deterministic golden-recipe execution
- fix(compat): replace datetime.UTC with timezone.utc for Python 3.10 compat
- fix(ci): null-safe head_commit.message in metrics-auto-regen if condition
- chore(metrics): sync forge_metrics.json after cli_verb_count method change
- fix(surface): regenerate surface.json with package_version 0.78.0
- fix(metrics): replace upward a4 import in _live_cli_verb_count with file scan
- chore(release): sync artifacts + doc anchors for v0.78.0


## v0.78.0 — 2026-05-08

- feat(forge): token-savings auto-ledger across every enriched verb


## v0.77.0 — 2026-05-08

- fix(forge): cherry-pick â€” collapse Class.method explosion (root-cause)
- feat(doc-update): auto-update 6 previously missed doc files on release


## v0.76.0 — 2026-05-08

- feat(forge): graft â€” surgical single-symbol cross-repo capability transfer
- fix(lint): clear 14 ruff violations blocking CI
- release: v0.75.3
- fix(forge): GAP-014 â€” harvest fail-loud on missing/empty sources


## v0.75.3 — 2026-05-08

### Changed

- d4b631b feat(metrics): sync tagged repo metrics surfaces (GP Lane C W6)


## v0.75.2 — 2026-05-08

### Changed

- c411603 fix(docs): close wrapped whitepaper drift (GP Lane C W6)


## v0.75.1 — 2026-05-08

### Changed

- 7f63594 feat(metrics): add repo public surface sync (GP Lane C W6)
- d8ac951 docs: sync README + metrics for v0.75.0 â€” 300-seed proof banner


## v0.75.0 — 2026-05-08

- docs: HARVEST_LEDGER â€” ðŸŽ¯ðŸŽ¯ðŸŽ¯ðŸŽ¯ HOLY GRAIL: 300 SEEDS ABSORBED (v0.75.0)


## v0.74.0 — 2026-05-08

- docs: HARVEST_LEDGER â€” 275 seeds (v0.74.0)


## v0.73.0 — 2026-05-08

- docs: HARVEST_LEDGER â€” ðŸŽ¯ðŸŽ¯ðŸŽ¯ QUARTER-THOUSAND: 250 SEEDS (v0.73.0)


## v0.72.0 — 2026-05-08

- docs: HARVEST_LEDGER â€” v0.72.0 milestone, 225 seeds


## v0.71.0 — 2026-05-08

- docs: HARVEST_LEDGER â€” ðŸŽ¯ðŸŽ¯ BICENTENNIAL: 200 SEEDS ABSORBED (v0.71.0)


## v0.70.0 — 2026-05-08

- docs: HARVEST_LEDGER â€” ðŸŽ¯ 175-seed milestone (v0.70.0)


## v0.69.0 — 2026-05-08

- docs: HARVEST_LEDGER â€” ðŸŽ¯ 150-seed milestone (v0.69.0)


## v0.68.0 — 2026-05-08

- docs: HARVEST_LEDGER â€” 125-seed milestone (v0.68.0)


## v0.67.0 — 2026-05-08

- docs: HARVEST_LEDGER â€” ðŸŽ¯ century mark, 101 seeds absorbed


## v0.66.0 — 2026-05-08

- docs: HARVEST_LEDGER refresh â€” 97 absorbed, full domain coverage


## v0.65.0 — 2026-05-08

- docs: HARVEST_LEDGER refresh â€” 73 seeds, 31 at 100/100, 0 below 60


## v0.64.0 — 2026-05-08

- docs: HARVEST_LEDGER refresh â€” 50+ seeds, fastapi/cookiecutter/copier landed


## v0.63.0 — 2026-05-08

- docs: HARVEST_LEDGER.md â€” proof the prompt-to-shippable spec is met


## v0.62.0 — 2026-05-08

- fix(forge): GAP-013 visitor-pattern + broaden abstract-by-convention detector


## v0.61.0 — 2026-05-08

- fix(forge): close audit findings â€” doc-update schema drift + GAP-009/010 + CHANGELOG gate


## v0.60.0 — 2026-05-08 — Forge spec met: 100/100 absorbed packages + auto-repair

### Added

- `a1_at_functions/abstract_method_repair.py` — post-emit auto-decorator
  for the abstract-by-convention pattern (Base/Abstract/Interface
  classes with `pass`/`NotImplementedError`/`...`/docstring-only methods
  whose subclasses override). Inserts `@abstractmethod` and ensures
  `from abc import abstractmethod` is imported. Idempotent.
- 6 unit tests under `tests/test_abstract_method_repair.py`.

### Fixed

- **GAP-007 closed.** When `transmute auto` absorbs a real-world repo
  using abstract-by-convention, run_finalize now post-processes the
  package to add the decorator automatically. Closes the residual 92/100
  scores on `claw-compactor` and `augmented-codebase-indexer`.
- Detector recognizes contract-only bodies in four shapes:
  `raise NotImplementedError`, bare `pass`, ellipsis `...`, and
  docstring-only (implicit pass). Recognizes abstract-class signals via
  Base/Abstract prefix, Interface/Protocol/ABC suffix, OR docstring
  tokens (abstract / interface / must be implemented / must override).

### Validation

- 8 of 10 absorbed seeds at 100/100 after this fix:
  `jcodemunch-mcp` · `CodeGrok_mcp` · `RepoMap-AI` · `tokcodecut` ·
  `claw-compactor` (was 92) · `augmented-codebase-indexer` (was 92) ·
  `coco-search` · `Gravitas-Core` · `nocturne_memory` ·
  `strands-mcp-server` · `CodeBase_RAG`. Remaining drift is upstream
  quality (real TODO markers in flyto-indexer, etc.) — Forge correctly
  surfaces those without auto-fabricating implementations.


## v0.59.0 — 2026-05-08 — transmute auto emits 100/100 shippable scaffolds

### Added

- `_emit_scaffold_files` in `a3_og_features/forge_pipeline.py` — emits
  the full shippable scaffold after symbol copy: `README.md` (showcase
  format with provenance + stats + tier breakdown), `pyproject.toml`,
  `.gitignore`, `.github/workflows/ci.yml`, `CHANGELOG.md`,
  `tests/__init__.py` + `tests/conftest.py`, and an auto-generated
  `tests/test_smoke.py` that imports each populated tier.
- `render_readme` upgraded with optional harvest-metadata kwargs
  (`source_repos`, `symbol_count`, `tier_distribution`, `file_count`,
  `digest`). Backward compatible.
- 3 emitter tests in `tests/test_finalize_scaffold.py`, 4 in
  `tests/test_cherry_pick.py`.

### Fixed

- **GAP-002 closed.** Absorbed packages are now production-quality from
  the first emission instead of bare-bones 5/100 scratch.
- **GAP-004 closed.** `cherry_pick.select_items` now drops symbols whose
  source file lives under `tests/`, `test/`, `benchmarks/`, `examples/`
  by default (`include_non_tier_dirs=True` to opt in). Closes the leak
  surfaced by jcodemunch-mcp where 26 `_MetadataProvider.load` test
  fixtures were promoted into the absorbed package's tier surface.
- **GAP-005 closed.** stub_detector skips methods on private classes
  (`_PrivateClass.method`) — the class-level underscore makes the entire
  surface private, not LLM-stubbed.
- **GAP-006 closed.** `stub_penalty` dedupes by qualname. Materialize
  duplicates a parent class into N subclass files; that's one quality
  issue, not N.
- File-emit pass guarantees no overwrite of user-authored files
  (README/CHANGELOG/CI/etc) on re-run.

### Validation

- 4 of 6 absorbed seeds at 100/100 after this fix; 2 at 92/100 due to
  abstract-by-convention residual (closed in v0.60.0).
- pytest: 1609 passed, 2 skipped, 0 failed.


## v0.58.0 — 2026-05-08 — AST scope locks + 1B steersman + portable release

### Added

- `a1_at_functions/ast_scope_lock.py` — multi-repo AST blueprints,
  deterministic edit locks, optional Nexus lineage attestation envelopes.
- `a1_at_functions/steersman_pack.py` — A/B semantic-router prompts for
  1B local models (Ollama llama3.2:1b default). Code-write forbidden.
- `a2_mo_composites/remote_seed_store.py` — GitHub URL hydration with
  Windows long-path clone support, polyglot manifest detection.
- New MCP actions wired: `audit ast_scope` and `plan steersman`.
- `scripts/release.py` — cross-platform release driver. Makefile
  `release` target now delegates to it.

### Fixed

- **GAP-001 closed.** `stub_detector._is_abstract_method` skips any
  function decorated with `@abstractmethod`-family decorators
  (`@abstractmethod`, `@abc.abstractmethod`, `@abstractclassmethod`,
  `@abstractstaticmethod`, `@abstractproperty`, plus `abc.`-qualified
  attribute forms).
- **GAP-003 closed.** `make release V=x.y.z` required POSIX `make`,
  unavailable on Windows shells. New `python scripts/release.py x.y.z`
  works everywhere; Makefile target delegates to it for parity.
- `tests/test_nexus_bridge.py::test_master_key_used_when_no_subscription`:
  clear the full alias set before setting master key, so certify-under-
  MCP env (which injects FORGE_API_KEY) is deterministic.

### Validation

- pytest: 1594 passed, 2 skipped. wire: PASS, 0 violations.
  certify: 100/100. New MCP surfaces respond live with token-savings
  telemetry.


## v0.57.1 — 2026-05-08

### Changed

- 582dc31 fix(ci): repair v0.57.0 CI failures â€” metrics, changelog, surface


## v0.57.0 — 2026-05-08

### Changed

- 5429260 release: v0.57.0
- f5243d1 feat(v0.57.0): forge bump + self-verify pipeline + context git-state
- 41c391e ci: extend doc-update to all sections in both workflows
- 93306a9 fix(docs): harden doc-drift regex + fix remaining stale values


## v0.56.0 — 2026-05-08 — Zero-token automation: auto-wire, doc-drift, lean preservation

### Added

**`apply_wire_stubs` — direct MCP+CLI injection** (zero copy-paste wiring)

`wire_stubs_gen.apply_wire_stubs()` injects a new MCP handler, both explore and
audit dispatch elifs, updated enum lists, a CLI command, and a test skeleton
directly into the correct files. No manual copy-paste required.

- `forge wire-stubs <module> <function> --apply [--dry-run]`
- MCP: `audit(action='wire_stubs')` with `apply=true`

**`forge auto-wire` — batch auto-wiring of all surface gaps**

One command: `surface-gaps` → `apply_wire_stubs` for every unwired a1 entry
point, with full dry-run support.

- `forge auto-wire [--top-n N] [--dry-run] [--tools explore,audit]`
- MCP: `audit(action='auto_wire')`

**`forge doc-update` — zero-LLM-token documentation regeneration**

Reads `forge_metrics.json` + live MCP/CLI source, rewrites bounded sections in
README, CHANGELOG, WHITEPAPER, IDE_INTEGRATION, and AGENTS_GUIDE.

- `forge doc-update [--sections readme,changelog,extended_docs] [--dry-run]`
- MCP: `audit(action='doc_update')`
- Integrated into `metrics-auto-regen.yml` and `publish-on-tag.yml`
- Schema: `atomadic-forge.doc_auto_update/v1`

**`forge doc-drift` — CI-gateable doc staleness detector**

Scans docs for stale MCP tool/action/test counts vs live `forge_metrics.json`.
Exits 1 when drift is found — suitable as a pre-push or CI gate.

- `forge doc-drift [--json]`
- MCP: `audit(action='doc_drift')`

### Fixed

**`forge_metrics.py` — lean_theorems preservation**

`forge metrics --apply` no longer zeroes the lean_theorems count when the proof
corpus is unavailable. Prior count is preserved whenever `found=False` but the
existing `forge_metrics.json` has `count > 0`. Same preservation for
`tests_passing` across local runs.

**16-item documentation discrepancy audit resolved**

- WHITEPAPER: 5× "46 MCP tools" → "10 MCP tools dispatching 79 actions"
- `docs/IDE_INTEGRATION.md`: "66 tools" → "10 tools dispatching 79 actions"
- `docs/MCP_TOOLS.md`: created (fixed broken README link)
- README, AGENTS_GUIDE: pipeline terminology `scout→assimilate` → `recon→cherry→wire`
- AGENTS.md: removed non-existent `launch/forge/GOLDEN_PATH-20260428.md` path
- `docs/RECEIPT.md`: `forge_version: "0.2.2"` → `"0.56.0"`
- `docs/FORMALIZATION.md`: `post-v0.14` → `post-v0.55.0`
- `tests/README.md`: created with tier map, fixture conventions, run commands

### Metrics

| Metric | v0.55.x → v0.56.0 |
|--------|-------------------|
| MCP actions | 76 → **79** |
| CLI verbs | 80 → **83** |
| Source files | 221 → **222** |
| Tests | 1,465 → **1,560** |
| Certify score | 100/100 |
| Wire violations | 0 |

## v0.55.0 — 2026-05-08 — Auto-wire pipeline, doc-update automation

### Added

**`apply_wire_stubs` — direct MCP+CLI injection** (zero copy-paste wiring)

`wire_stubs_gen.apply_wire_stubs()` injects a new MCP handler, both explore and
audit dispatch elifs, updated enum lists, a CLI command, and a test skeleton
directly into the correct files — no manual copy-paste required.

- `forge wire-stubs <module> <function> --apply`
- `forge wire-stubs <module> <function> --dry-run`

**`forge auto-wire` — batch auto-wiring of all surface gaps**

New CLI command that runs `surface-gaps` then calls `apply_wire_stubs` for
every unwired a1 entry point in one shot.

- `forge auto-wire [--top-n N] [--dry-run] [--tools explore,audit]`
- MCP: `audit(action='auto_wire')`

**`doc_auto_update` — zero-LLM-token documentation regeneration**

New `a1_at_functions/doc_auto_update.py` reads `forge_metrics.json` and live
MCP/CLI source, then rewrites bounded sections in README.md and CHANGELOG.md
programmatically — no LLM needed.

- `forge doc-update [--sections readme,changelog] [--dry-run]`
- MCP: `audit(action='doc_update')`
- Integrated into `metrics-auto-regen.yml` and `publish-on-tag.yml` CI pipelines
- Schema: `atomadic-forge.doc_auto_update/v1`


## v0.54.0 — 2026-05-07 — Synthesis pipeline: gap analysis, TAU_TRUST bridge, auto-wiring tools

### Added

**`surface_gaps` — a1 MCP/CLI coverage gap finder** (pipeline gap analysis)

New `a1_at_functions/surface_gaps.py` with `find_surface_gaps()`. AST-walks the
a1 tier and compares entry points against registered MCP actions and CLI verbs,
returning a list of functions with no MCP coverage, no CLI coverage, or both.

- `forge surface-gaps`
- MCP: `explore(action='surface_gaps')`, `audit(action='surface_gaps')`
- Schema: `atomadic-forge.surface_gaps/v1`

**`wire_stubs` — auto-wiring scaffold generator** (pipeline gap analysis)

New `a1_at_functions/wire_stubs.py` with `generate_wire_stubs()`. Given a module
path and function name, emits a ready-to-paste MCP handler block, a CLI stub
entry, and a test skeleton — removing the manual plumbing step for every new
a1 function.

- `forge wire-stubs <module> <function>`
- MCP: `audit(action='wire_stubs')`
- Schema: `atomadic-forge.wire_stubs/v1`

**`capability_scout` — GitHub harvest target search** (pipeline gap analysis)

New `a1_at_functions/capability_scout.py` with `search_capability_repos()`.
Accepts one or more freeform query strings and returns ranked GitHub repositories
suitable as harvest candidates, enriched with star count, last-push date, and
primary language.

- `forge capability-scout --queries "q1,q2"`
- MCP: `explore(action='capability_scout')`
- Schema: `atomadic-forge.capability_scout/v1`

**`dead_code` — AST-walk dead symbol detector** (vulture synthesis)

New `a1_at_functions/dead_code.py` with `detect_dead_symbols()`. Walks the
package AST using vulture and returns symbols that are defined but never
referenced, grouped by tier with confidence scores.

- `forge dead-code`
- MCP: `explore(action='dead_code')`, `audit(action='dead_code')`
- Schema: `atomadic-forge.dead_code/v1`

**`maintainability` — Maintainability Index per module** (radon synthesis)

New `a1_at_functions/maintainability.py` with `compute_maintainability()`.
Runs radon MI analysis across every source module and returns per-file grades
(A/B/C/D) with raw MI score, ranked from least to most maintainable.

- `forge maintainability`
- MCP: `explore(action='maintainability')`, `audit(action='maintainability')`
- Schema: `atomadic-forge.maintainability/v1`

**`concept_bridge` — TAU_TRUST harvest bridge** (TAU_TRUST bridge)

New `a1_at_functions/concept_bridge.py` with `bridge_harvest_concepts()`.
Reads a `harvest.json` produced by `forge harvest`, filters candidates whose
trust score falls below TAU_TRUST (1820/1823), and converts each into an
actionable synthesis plan with a recommended absorb sequence and preflight
checklist.

- `forge concept-bridge --harvest-json path/to/harvest.json`
- MCP: `explore(action='concept_bridge')`, `audit(action='concept_bridge')`
- Schema: `atomadic-forge.concept_bridge/v1`

### metrics

- CLI verbs: 80 (+6)
- MCP actions: 76 (+10)
- Tests: 1465 (+42 over v0.53.0)
- Source files: 221 (+6)

## v0.53.0 — 2026-05-07 — Harvest synthesis: call-graph-summary, git churn, token budget

### feat(synthesis): three new a1 capabilities absorbed from harvest pipeline

**`call_graph_summary` — whole-package call-graph portfolio** (pyan synthesis)

Adds `build_call_graph_summary()` to `a1_at_functions/call_graph.py`.
Surfaces orphan functions (uncalled callers), hotspot functions by fan-in,
and maximum call-chain depth for an entire package in one shot — distinct from
the per-symbol BFS that `call_graph` already provides.

- `forge call-graph-summary --project <root> [--package NAME] [--top-n N] [--json]`
- MCP: `explore(action='call_graph_summary')`
- Schema: `atomadic-forge.call_graph_summary/v1`

**`git_churn` — file-level commit frequency** (Repomix synthesis)

New `a1_at_functions/git_churn.py` with `compute_git_churn()`.
Runs `git log --name-only` to build hotspot/stable file rankings, average and
median commits per file, first/last commit dates. Returns a minimal error dict
when git is unavailable so callers degrade gracefully.

- `forge churn --project <root> [--since '6 months ago'] [--top-n N] [--all-files] [--json]`
- MCP: `explore(action='churn')`
- Schema: `atomadic-forge.git_churn/v1`

**`token_estimate` — context-pack payload sizing** (Repomix synthesis)

`emit_context_pack()` now includes `token_estimate: int` — a `len(json.dumps(pack)) // 4`
approximation so agents can budget against context limits before dispatching.

### metrics

- CLI verbs: 74 (+2)
- MCP actions: 66 (+2)
- Tests: 1423 (+14 over v0.52.1)

## v0.52.1 — 2026-05-07 — IP scrub: no private identifiers in public repo

### fix(security): remove all private identifiers from public surfaces

All internal project names, repo identifiers, and deploy-key secret
names replaced with neutral public-safe labels throughout:

- CI workflow secrets and env vars renamed to neutral `PROOF_CORPUS_*` prefix
- Hardcoded SSH clone URL moved to `PROOF_CORPUS_REPO_URL` org secret
- Python API param renamed to `proof_corpus_root`; internal helper to `_find_proof_corpus`
- CLI flag renamed to `forge metrics --proof-corpus`
- All docs (CHANGELOG, README, .gitignore) use neutral labels

Zero functional changes. certify: 100/100. wire: 0 violations.

### fix(test): git-ceiling tests clear inherited worktree env vars

`test_worktree_status_non_git_runs` and
`test_tools_call_doctor_with_include_worktree` now explicitly unset
`GIT_DIR`/`GIT_WORK_TREE`/`GIT_COMMON_DIR` so they pass when running
from inside a git worktree on Windows.

### feat(emergent-swarm): hub-node penalty in `emergent_swarm` scoring

Symbols that appear in more than 3 chains are now penalised in
`score_boosted`. For each doubling of cross-chain frequency above the
threshold, 10 points are deducted from `score_boosted` (floor at 0).
This prevents a single high-connectivity connector symbol from occupying
all top-N emergent candidates; genuinely novel cross-repo chains surface
instead. Affected candidates gain two new output fields:
`hub_penalty` and `hub_max_symbol_freq`.

### fix(forge_metrics): theorem count now reads from build attestation

`forge_metrics.py` now reads `dist/BUILD_ATTESTATION_*.json` when the
file exists, using the machine-verified Lean4 count as the canonical
source rather than a raw file scan. Count corrected: 886 → 872.
`forge_metrics.json` updated accordingly with `"basis": "build_attestation"`.

### feat(absorb): new `forge absorb` command and supporting a1/a3 modules

`harvest_absorb.py` (a1) — pure helpers for absorbing external Python
repos: layout detection, package resolution, fingerprinting.
`absorb_feature.py` (a3) — feature composing `harvest_absorb` and
`emergent_swarm` for cross-repo composition.
`commands/absorb.py` — CLI command exposing the absorb feature.

### fix(mcp_protocol): remove duplicate dict-key lint violations

Removed two pre-existing duplicate dict-key entries from `mcp_protocol.py`.

## v0.51.6 — 2026-05-07 — sequential cascade: registry fires AFTER PyPI lands

v0.51.5 fired release.yml + mcp-registry-publish.yml in parallel. The
registry workflow's wait-for-PyPI loop timed out (60s) because PyPI
build+publish+CDN propagation took longer.

Switched to a strict sequential cascade:
1. publish-on-tag.yml fires release.yml only
2. release.yml builds, uploads, publishes to PyPI
3. release.yml's LAST step fires mcp-registry-publish.yml
4. mcp-registry-publish.yml's wait-for-PyPI loop now never has to
   wait long because PyPI is already there

This is the final piece of the zero-touch chain.

## v0.51.5 — 2026-05-07 — final cascade fix: workflow_dispatch instead of release event

v0.51.4's PAT-based cascade failed because the fine-grained
WORKER_DEPLOY_PAT lacks `Contents: Write` on this repo (would need
the user to widen its scope in GitHub UI). Pivoted to a different
mechanism that works with the default GITHUB_TOKEN:

GitHub Actions' anti-recursion rule blocks RELEASE events created
via GITHUB_TOKEN, but `workflow_dispatch` events ARE allowed.
publish-on-tag.yml now:

1. Creates the GH Release using GITHUB_TOKEN (allowed; release
   exists, just doesn't fan out automatically).
2. Explicitly fires `release.yml` and `mcp-registry-publish.yml` via
   `gh workflow run` — these dispatch events DO trigger workflow
   runs, even via GITHUB_TOKEN.

Required workflow updates:
- `permissions: actions: write` on publish-on-tag.yml so it can
  fire workflow_dispatch.
- `release.yml` accepts `workflow_dispatch` with optional `version`
  input, and the PyPI publish-job's `if` clause now allows both
  release and workflow_dispatch events.
- `mcp-registry-publish.yml` already had workflow_dispatch.

## v0.51.4 — 2026-05-07 — cascade fix: use PAT for release creation (GH-token doesn't trigger downstream)

GitHub Actions intentionally BLOCKS workflows that were created by
`GITHUB_TOKEN`-authenticated steps from triggering OTHER workflows —
an anti-recursion safety. v0.51.3's `gh release create` used the
default `github.token`, so the `release: published` event was
silenced and neither release.yml (PyPI) nor mcp-registry-publish.yml
(Registry) fired downstream.

Fix: use `WORKER_DEPLOY_PAT` (already configured) for the release
creation. PAT-authored release events DO trigger downstream
workflows. Falls back to `github.token` if the PAT is unset (logs
the limitation but doesn't fail).

Also softened the worker-dispatch step to never block: 403/404 from
the cross-repo dispatch logs a warning and continues — the worker
repo's own tag-trigger CI is the canonical fallback.

This is the FINAL workflow fix needed for true zero-touch publish.

## v0.51.3 — 2026-05-07 — auto-heal hotfix: install [dev] extras + drop strict-mode

v0.51.2's auto-heal step exited 1 because:
- `pip install -e .` skips `[dev]` extras → `pytest` not installed → command failed
- Even with `set +e`, a later `set -e` re-enabled errexit and the
  no-match grep tripped it

Both fixed: install with `[dev]` extras for pytest; auto-heal step
runs in fully permissive mode with `exit 0` at the end so it can
never block a release. Pure workflow fix — zero source changes.

## v0.51.2 — 2026-05-07 — zero-touch publish chain (machines do what machines can do)

### fix(ci): every manual step from v0.50/v0.51 publish is now automated

Two gaps left manual touches in the v0.50/v0.51 releases:

1. **`publish-on-tag.yml` verify step was over-strict** — diff-based
   verification of `forge_metrics.json` failed on subtle CI-vs-local
   recompute artifacts. Required a human to run `gh release create`
   manually after every tag.

2. **`mcp-registry-publish.yml` raced PyPI** — fired on tag push
   *before* `release.yml` finished publishing to PyPI, so the
   registry's PyPI-presence check 404'd. Required a human to
   re-trigger the workflow once PyPI was live.

Both fixed in v0.51.2:

* `publish-on-tag.yml` now AUTO-HEALS the metrics artifact at tag time
  (regenerate, never fail). Release creation is idempotent — won't
  fight a manual `gh release create` if one already ran.
* `mcp-registry-publish.yml` triggers on `release: published`, NOT on
  tag push. Plus a 60-second wait-for-PyPI-200 belt-and-suspenders
  loop at the start of the publish step.
* New `release-readiness.yml` CI gate fails any PR/push to main that
  would block publish-time (missing README mcp-name marker, server.json
  name drift, CHANGELOG missing the version entry). Catches the gap
  BEFORE the tag, not after.

### Atomadic axiom enforcement

> Do not make Thomas (or any human) do what the machines can do for him.

This release exercises the chain end-to-end with zero manual touches:
push the tag, the entire fan-out (PyPI, GitHub Release, MCP Registry,
Cloudflare Worker) lands on its own.

## v0.51.1 — 2026-05-07 — hotfix: MCP Registry ownership marker in README

PyPI releases are immutable, and v0.51.0 shipped without the
`mcp-name: io.github.atomadictech/atomadic-forge` marker the MCP
Registry now requires for PyPI-package ownership validation. v0.51.1
ships the marker so registry.modelcontextprotocol.io can register
this version. Pure metadata change — zero behavioral diff vs v0.51.0.

## v0.51.0 — 2026-05-07 — IP-boundary scrub on public surfaces

### chore(ip): strip codex-internal math from every public surface

Audit found proprietary math/codex internals leaking through public
surfaces (tool descriptions exposed via `tools/list`, source-code
docstrings, doc files, the whitepaper, the system-invariants module).
This release scrubs all of them while keeping the credibility markers:

**Public-safe (kept):**
- `886+ Lean4 theorems` count + the fact of formal verification
- The constant VALUES (`D_MAX_DELEGATION=23`, `TAU_TRUST≈0.99835`)
- The variable NAMES (so existing imports keep working)
- Behavioural descriptions ("trust-gated", "delegation depth cap")

**IP-protected (stripped from public):**
- Specific theorem names (no longer cited anywhere public)
- Internal framework names (removed from all public surfaces)
- Math derivations (no `⌊Δ_RG/η⌋`, no Leech / Niemeier / Coxeter–Todd /
  Golay / Monster group / E₈ geometry references)
- Greek-letter math (`τ_TRUST` → `TAU_TRUST`, `τ_trust` → `trust threshold`
  in user-visible strings)
- Specific theorem citations ("BEP Theorem 1/2/3" → "the convergence
  guarantee", "the corpus theorem")

**Files touched:** mhed_invariants.py docstring, hive_constants.py,
mcp_protocol.py tool descriptions, cherry_hunter.py, emergent_swarm.py,
forge_evolve_session.py, mcp_server.py, commands/harvest.py, cli.py
help text, FORMALIZATION.md, HIVE_PRIMITIVES.md, AGENTS.md,
04-llm-loops.md, FORGE-AGENT-INSTRUCTIONS.md, RECEIPT.md,
AGENTS_GUIDE.md, compliance/*.md, WHITEPAPER.md, 4 test files.
ZERO functional changes — all numeric values intact, all behaviour
preserved. Surface tests 137/137 pass.

### test: this release also exercises the v0.50.0 single-tag publish chain

Pushing `v0.51.0` should fire: `publish-on-tag.yml` (verify metrics →
GitHub Release → release.yml → PyPI publish → repository_dispatch to
worker) AND `mcp-registry-publish.yml` (rewrite server.json with live
counts → mcp-publisher publish → registry smoke-check). All four
surfaces (PyPI, Worker, MCP Registry, GitHub Release) should reflect
v0.51.0 within ~30 seconds.

## v0.50.0 — 2026-05-07 — one tag publishes everywhere

### feat: full single-tag publish chain (PyPI + worker + badges in lockstep)

Pushing a single `vX.Y.Z` tag now drives the whole pipeline:

1. `publish-on-tag.yml` verifies `forge_metrics.json` is current at the
   tag (fail-loud if stale — no shipping wrong numbers to public surfaces).
2. GitHub Release is created from the matching CHANGELOG section.
3. `release.yml` builds + publishes to PyPI.
4. `repository_dispatch` fires `forge-released` to the worker repo,
   which redeploys via `wrangler deploy` with the matching version env.

Public surfaces (atomadic.tech, shields.io badges, MCP endpoint, doctor
response, package version banner) all reflect the same tag within ~30s.

### feat: shields.io endpoint badges

The Cloudflare Worker now serves shields.io v1 endpoint badges:

```
https://img.shields.io/endpoint?url=https://forge.atomadic.tech/badge/<metric>
```

Available metrics: `mcp_tools`, `mcp_actions`, `cli_verbs`, `tests_passing`,
`test_files`, `test_functions`, `source_files`, `source_lines`,
`monadic_tiers`, `lean_theorems`, `package_version`.

Each badge reads `forge_metrics.json` (5-min edge cache). Drop one in any
README, docs site, or status page — the number updates without anyone
editing the file.

README header gained a row of live badges: tools, actions, CLI verbs,
tests passing, source files, Lean4 theorem count. Static "100/100
certify" badge retired in favor of dynamic numbers.

### feat: auto-regen on every push to main

`metrics-auto-regen.yml`: any push to `main` that touches source, tests,
or `pyproject.toml` triggers a regeneration. If the artifact drifted, a
follow-up `chore(metrics): auto-regenerate [skip ci]` commit is pushed
back to main. Stale numbers self-heal — no human intervention.

When the `PROOF_CORPUS_DEPLOY_KEY` org secret is configured, the
auto-regen also clones the IP-protected proof corpus over deploy-key
SSH and refreshes the Lean theorem count. Without the secret, the prior
lean count is preserved (never zeroed by a routine push).

### chore: corrected misnamed metric units

Earlier responses cited "1,493 passing" alongside "test_files: 96" and
"124/124 passed" — three different units (full-suite passes, file count,
targeted-subset passes). The artifact now carries all three explicitly:
`test_files`, `test_functions`, `tests_passing`.

## v0.49.0 — 2026-05-07 — single source of truth: `forge_metrics.json`

### feat: canonical metrics artifact for every public surface

Every public number Forge claims about itself — MCP tool count, action
count, CLI verb count, source/test files, lines of code, and the count
of formally-verified Lean4 theorems in the IP-protected proof corpus
moat — now lives in one canonical artifact: `forge_metrics.json` at the
repo root, regenerated on every push by `forge metrics --apply`.

Public surfaces (README, CHANGELOG badges, the welcome handshake, the
Cloudflare Worker, shields.io endpoints, atomadic.tech site) read from
this file. CI gate (`metrics-drift.yml`) fails any PR that lets the
artifact drift out of sync with the live forge surface.

**Live numbers (this commit):**
- 10 MCP tools · 64 actions
- 71 CLI verbs
- 211 source files · ~40,110 LOC
- 96 test files
- **886 Lean4 theorems across 38 files** (formal-proof moat)
- monadic tiers = 5

### feat(cli/mcp): `forge metrics` verb — print or write the artifact

```
forge metrics                  # print live metrics summary
forge metrics --apply          # rewrite forge_metrics.json
forge metrics --json           # machine-readable JSON to stdout
forge metrics --self-cert      # also embed certify score (slower)
```

The verb composes a pure tier-a1 aggregator (`forge_metrics.py`) with
the live MCP TOOLS dict and CLI registry. Source paths from the
IP-protected proof corpus are NEVER written into the public
artifact — only aggregate counts. Path resolution is via the
`FORGE_PROOF_CORPUS` env var; gitignore protects the proof corpus
directory from ever being checked in.

### chore: corrected stale README numbers

The "By the Numbers" table previously cited Lean4=624 (stale by 262)
and source files=193 (stale by 18). Now derived live from
`forge_metrics.json` and verified against the IP repo.

## v0.48.0 — 2026-05-07 — flagship `transmute` + `loop` split out of plan (8→10 tools)

### refactor(mcp): surface the flagship pipeline; reduce plan overload

The v0.46.0 consolidation buried the flagship `auto` pipeline inside
`plan(action='auto')` — semantically wrong (`plan` means *planning*, not
*executing the absorption pipeline*) and bad for discoverability (agents
reading `tools/list` couldn't see "auto" at all).

**v0.48.0 splits two semantic clusters back out:**

- **`transmute` (3 actions)** — the spaghetti→certified flagship:
  `auto` (single-shot scout→cherry→assimilate→wire→certify) ·
  `cherry` (produce cherry.json manifest) ·
  `finalize` (materialize a cherry.json into a package).
  This is the headline Forge capability and now appears at the top level
  of `tools/list` again.

- **`loop` (4 actions)** — LLM-driven iteration sessions:
  `iterate` · `resume` · `evolve` · `evolve_step`.
  Distinct from `plan` because these REQUIRE an external LLM client —
  Forge has no embedded LLM. Splitting clarifies that contract.

**`plan` (16 → 9 actions)** — now cleanly scoped to "orient + dev utilities":
context, compose, policy, recipes, generate, apply, locate, commit, scaffold.

**Backward compat:** every legacy name still works.
`LEGACY_ENDPOINT_MAP` updated: `auto/cherry/finalize/transmute → transmute`,
`iterate/evolve/loop → loop`. Schema bumps: `transmute → /v2`, `loop → /v2`,
`plan → /v6` (action enum changed). Total tool count: **10**.

### chore: schema registry & surface map updated

`transmute` → `/v2`, `loop` → `/v2` restored in registry. `plan` schema bumped
implicitly via action enum change.

## v0.47.0 — 2026-05-07 — `create` exposed as MCP tool (7→8 tools)

### feat(mcp): forge create now callable over MCP

`create` was previously CLI-only. Exposes `create_from_intent` (intent + seed_repos → pip package)
as a standalone MCP tool — runs the full Phase 1 pipeline (emergent_swarm cross-repo composition
discovery → materialize top-N candidates → optional certify). Returns the create receipt with
scan_summary, materialize report, and scan_report_path for re-runs without re-scanning.

Schema: `atomadic-forge.create/v1`. Total tool count: **8**.

## v0.46.0 — 2026-05-07 — MCP Surface Redesign: 66→7 tools, 64 actions

### feat(mcp): complete tool surface consolidation with action-dispatch architecture

Reduced the MCP tool count from **66 to 7** by consolidating related operations
under action-dispatch. Each of the 66 original tool names redirects automatically
via `LEGACY_ENDPOINT_MAP` — zero callers broken, zero migrations required.

**Measured token savings: ~8,630 tokens per `tools/list` call (−51%)** vs the prior
66-tool surface (`tools/list` payload dropped from 67.7 KB → 33.2 KB, measured
on v0.23.0 vs v0.47.0 by dispatching the actual JSON-RPC call). Per-session
savings depend on how many `tools/list` calls a client issues — typically
~8.6K–26K tokens. The earlier draft of these notes claimed ~250K tokens/session
and ~99 KB → ~25 KB; both were estimates that didn't survive measurement.
Response-size caps across high-volume tools (smell_scan, wisdom_list, etc.)
saved an additional ~189 KB per heavy round-trip — those numbers were
verified directly and stand.

**Final 7-tool surface (64 actions):**

| Tool | Actions | Scope |
|------|---------|-------|
| `welcome` | — | RECOMMENDED FIRST CALL: onboarding scan, score, narrative, safety net |
| `explore` | 9 | Codebase analysis & discovery: `recon` · `explain` · `call_graph` · `smell_scan` · `lineage` · `harvest` · `synergy` · `scan` · `swarm` |
| `audit` | 14 | Quality gates & change safety: `certify` · `wire` · `enforce` · `validate` · `guard` · `composite` · `gate` · `health` · `check` · `score` · `tests` · `cna` · `rollback` · `diff` |
| `plan` | 16 | Orient + plan + execute: `context` · `compose` · `policy` · `recipes` · `generate` · `apply` · `locate` · `commit` · `iterate` · `resume` · `evolve` · `evolve_step` · `auto` · `cherry` · `finalize` · `scaffold` |
| `hive` | 13 | Multi-agent coordination: `register` · `list` · `deactivate` · `observe` · `propose` · `vote` · `needs_vote` · `result` · `recap` · `handoff_create` · `handoff_list` · `enhance_propose` · `enhance_list` |
| `wisdom` | 5 | Institutional memory DB: `record` · `query` · `list` · `recall` · `promote` |
| `nexus` | 7 | AAAA-Nexus auth primitives (via `op=`): `identity_verify` · `federation_mint` · `authorize_action` · `sys_trust_gate` · `contract_verify` · `lineage_record` · `ratchet_register` |

Each tool uses `action=` dispatch; `nexus` uses `op=` to avoid collision with
`authorize_action`'s pass-through `action` parameter.

### perf: response-size caps across high-volume tools

Default payload sizes reduced at the source so agents never receive multi-KB
responses they didn't ask for:

| Tool | Before | After | Mechanism |
|------|--------|-------|-----------|
| `emergent_scan` | 32 KB | 7.5 KB | `top_n` 25→10, optional `include_chains` |
| `synergy_scan` | 14 KB | 5.7 KB | `top_n` 25→10, optional `include_details` |
| `smell_scan` | 61 KB | 12 KB | `top_n_findings=20` cap, always emits `*_count` |
| `wisdom_list` | 71 KB | ~5 KB | `limit=20` default, `limit=0` for full dump |
| `wisdom_promote` | 46 KB | 5 KB | `include_bodies=false` default |

Full detail always recoverable via the respective opt-in params.

## v0.23.0 — 2026-05-07 — wisdom_promote body trim (46 KB → 5 KB)

### perf(wisdom_promote): strip draft_markdown bodies from default response

`wisdom_promote` response was 46 KB (3 drafts × full markdown). Default now
returns metadata only — `body_chars`, `body_omitted: true` — at ~5 KB.

- `include_bodies=true` restores full markdown in the response.
- `write=true` also implicitly includes bodies (you're persisting them anyway).
- Added `hint` field explaining the param when bodies are omitted.

Response reduction: 46,352 → 4,759 bytes (90%).

## v0.22.0 — 2026-05-07 — plan maintenance hints, CLI map completions, description fixes

### feat(plan): inject maintenance_hints when repo already passes at 100/100

When `certify=100` and `wire=PASS`, the `plan` tool now emits `maintenance_hints`
— top-5 CC complexity hotspots from `smell_scan` — so agents always have an
actionable next step even on a clean repo. Adds `maintenance_hint_count` field.
No change to existing fields; no impact on repos with real actions to take.

### fix(CLI map): complete _CLI_FALLBACKS for 15 previously missing tools

`trust_gate_response` was incorrectly listed as "MCP-only" — the CLI is
`forge trust-gate`. Added correct CLI equivalents (or intentional MCP-only
annotations) for: `guard_install`, `tool_factory`, `iterate_start`,
`iterate_continue`, `evolve_start`, `evolve_step`, `lineage`, `harvest`,
and all 9 hive subtools.

### fix(lineage): add CLI equivalent to description

Description now notes `forge surface list/show/log` as the CLI counterpart,
fixing the gap where agents had no way to discover the CLI equivalent.

## v0.21.0 — 2026-05-07 — wisdom_list limit, commit_compose prefix fix

### perf(wisdom_list): cap default response at 20 entries (71 KB → ~5 KB)

New `limit` parameter (default 20) prevents `wisdom_list` from dumping the
entire wisdom DB in one call. Always emits:

- `total_count` — full entry count regardless of cap.
- `returned_count` — entries actually returned.
- `truncated: true` + `hint` string when the DB exceeds the limit.

Pass `limit=0` to retrieve all entries. Mirrors the `top_n_findings` pattern
added to `smell_scan` in v0.20.0.

### fix(commit_compose): strip duplicate conventional-commit prefix from intent

`commit_compose` now strips any leading `TYPE:` or `TYPE(scope):` prefix from
`intent` before prepending the `commit_type` label. Prevents double-prefix
subjects like `fix: fix(scope): add param` when callers pass a
conventionally-formatted intent string.

## v0.20.0 — 2026-05-07 — context_pack synthesis, synergy_scan fix, smell_scan token reduction

### feat(context_pack): embed policy + workflow_recipe — replaces two extra tool calls

`context_pack` now returns two new fields on every call:

- **`policy`** — the full `[tool.forge.agent]` policy dict (`protected_files`,
  `max_files_per_patch`, `require_human_review_for`). Agents no longer need a
  separate `load_policy` call on first connect.
- **`workflow_recipe`** — when `intent` is provided, `compose_tools` is run
  automatically and the matched recipe (step-by-step tool sequence) is embedded.
  Agents that pass `intent` get both grounding and a workflow plan in one call.

`load_policy` and `compose_tools` remain available as standalone tools for
targeted use. Their descriptions updated to note the context_pack embedding.

Extracted `_build_policy` and `_build_workflow_recipe` helpers, keeping
`emit_context_pack` CC below the 10-threshold flagged by smell_scan.

### fix(synergy_scan): MCP returned 0 candidates vs 20 from CLI

`_bound_synergy_scan` in `mcp_server.py` was passing `project_root` as
`src_root` to `SynergyScan`. The scanner expects the `src/` directory, not the
repo root. Fixed: now uses `root/"src"` when that directory exists, falling back
to `root`. Result: 0 → 20 synergy candidates in MCP calls (parity with CLI).

### perf(smell_scan): response slimmed from 61.6 KB to ~12 KB

New `top_n_findings` parameter (default 20) caps the findings arrays returned
while always emitting `*_count` summary fields so agents see the full totals:

- `complexity_findings_count`, `long_function_findings_count`,
  `duplication_findings_count` — always present regardless of cap.
- Returned findings are sorted by worst score (highest CC / longest LOC).
- `findings_capped_at` field indicates the cap in effect.
- `top_n_findings: 0` disables the cap entirely for full reports.

## v0.19.0 — 2026-05-07 — MCP/CLI parity sweep: 8 tool fixes, call_graph overhaul, smell improvements

### fix(recon): MCP recon now returns prior_wisdom

`_tool_recon` in `mcp_protocol.py` now injects the same `prior_wisdom`
field that the CLI has always produced via `recall_for_recon`. Agents
calling `recon` over MCP now see the top-5 repo-scoped wisdom entries in
the response — matching CLI parity and giving every MCP agent the
institutional memory it needs before starting work.

### perf(mcp): certify skip-tests, wire dynamic-import allowlist, verify slim summaries

**certify**

- New `skip_tests: bool = False` parameter on `certify()` — skips the
  pytest run, credits the behavioural axis at 1.0, and adds
  `tests_skipped: true` to the result.  Reduces certify time from ~40s
  to ~500ms in CI pipelines that run pytest separately.
- `pytest_summary` raw dot-string is now stripped from the `test_run`
  dict at source; agents receive structured counts only (no 1500-char dot
  strings).
- MCP tool schema updated with a `skip_tests` boolean input parameter.

**wire**

- `_tool_wire` reads `[tool.forge.wire].allowed_dynamic_imports` from
  `pyproject.toml`.
- Response now includes `new_dynamic_warnings` (count of genuinely new
  warnings) and `whitelisted_dynamic_warnings_count`.
- `dynamic_import_warnings` array shows only non-whitelisted warnings.
- `pyproject.toml` gained a `[tool.forge.wire]` section with three
  known-safe dynamic-import entries documented.

**verify**

- `wire` and `certify` keys in the verify response are now slim
  summaries instead of full payloads (~80% response size reduction).
  - Wire summary: `{verdict, violation_count, auto_fixable, new_dynamic_warnings}`
  - Certify summary: `{score, verdict, blockers, score_components, issues, tests_skipped}`
- New top-level `wisdom_draft: {insight, tags, command}` field — no
  more digging into the nested `wisdom_capture_prompt` structure.
- `auto_record_threshold_met` now fires on any PASS verdict, not only
  score-delta events.

### fix(batch3): select-tests CLI broken, test discovery gap, certify --skip-tests, context_pack best_next

- `select-tests` CLI: Typer group positional `Argument` never parsed — converted
  `intent` to `--intent / -i` option (the only correct workaround for Typer groups).
- `test_selector`: stem-component token heuristic (≥6-char tokens) now catches
  test files like `test_certify_operational_axis.py` for `certify_checks.py`.
  Before: only exact `test_<stem>.py` mirror matches. After: 7 targeted tests
  for a 3-file change instead of 1.
- `forge certify --skip-tests` CLI flag (was MCP-only and Python API-only).
- `context_pack.best_next_action` was always `null` on clean repos — now derives
  a meaningful suggestion from the focus mode (recon / preflight / release / lineage).

### fix(batch4): call_graph fully repaired — relative imports + package normalization; smell_scan build/ exclusion

**call_graph** — two independent bugs both produced `target_in_graph: false`:
- `package` defaulted to `project_root.name` (e.g. `"atomadic-forge"` with
  hyphen); Python package is `"atomadic_forge"` — all qualnames in the graph
  were wrong. Fix: `_detect_package_name()` reads `[project].name` from
  `pyproject.toml` and normalizes `"-"` → `"_"`.
- Relative imports (`from ..a1_at_functions.certify_checks import certify as _certify`)
  resolved to bare paths missing the package prefix (`a1_at_functions.certify_checks.certify`
  instead of `atomadic_forge.a1_at_functions.certify_checks.certify`). Fix:
  `_collect_imports()` now accepts `module_dotted` and resolves `node.level`
  against it. `certify()` callers: 0 → **36**.

**smell_scan** — `_walk_functions()` now skips `build/`, `dist/`, `.eggs/`,
`.tox/`, `node_modules/`. The scanner was walking compiled artifacts in `build/`
and double-counting every function. Forge repo smell_score: 67.1 → **89.7**.

### fix(batch5): trust-gate CLI crash, welcome certify verdict None

- `trust_gate_cmd`: `d = verdict.schema` set `d` to the schema-version string,
  not a payload dict; subsequent `.get("safe_to_act")` crashed with
  `AttributeError`. Fix: `dataclasses.asdict(verdict)` for the full dict.
- `welcome_feature.py`: `scan.certify.verdict` was always `None` because the
  code read `certify_report.get("verdict")` (top-level, doesn't exist in normal
  runs) instead of `certify_report["health_summary"]["verdict"]`. Fixed with
  fallback chain: `health_summary.verdict` (normal) → `top-level verdict` (error
  fallback path).

## v0.18.0 — 2026-05-07 flexible LLM providers + VS Code extension + hook repairs

### Flexible LLM provider config

Forge previously hardcoded six provider classes (Anthropic, OpenAI, Gemini,
Ollama, OpenRouter, AAAA-Nexus).  v0.18.0 adds a generic OpenAI-compatible
client + a `custom_providers` config field so users can wire ANY
chat-completions-API service (DeepSeek, Groq, Together, Fireworks, xAI,
Mistral, Perplexity, Cerebras, Hyperbolic, internal proxies, …) without
writing Python.

- **NEW** `a1.custom_provider_client` — `CustomProviderClient` honours the
  same `LLMClient` Protocol as the hardcoded clients.  11 bundled presets
  (openai, openrouter, deepseek, groq, together, fireworks, xai, mistral,
  perplexity, cerebras, hyperbolic) for one-line setup.
- **NEW** `a0.config_defaults.custom_providers: list[CustomProviderEntry]`
  — declare any provider as `{name, base_url, model, api_key_env, format}`.
  Resolver looks up config entries first (overrides win over presets), then
  falls back to bundled presets, then to hardcoded backward-compat names.
- **NEW** CLI: `forge config provider {add | list | remove | presets}`.
  `add` accepts a `--preset` for one-line setup, plus optional
  `--base-url`, `--model`, `--api-key-env`, `--format`, `--global`.
- **NEW** env-var override on every preset: `FORGE_<NAME>_MODEL` swaps the
  default model without rewriting config (e.g. `FORGE_GROQ_MODEL=…`).
- 27 new tests in `test_custom_provider.py` pinning the registry,
  validation, network call shape, and resolver fallback chain.

### VS Code extension

NEW `vscode-extension/` directory ships a complete VS Code package:

- **Status bar** — live certify score + wire violation count, click to
  re-verify; turns red below the configured `failUnder` threshold.
- **Activity-bar panel** — two tree views: Wire Violations (click-through
  to file) + Certify Axes (which of the 9 axes are passing).
- **10 commands** mapped 1:1 to forge CLI verbs (recon, wire, certify,
  verify, smell, context-pack, enforce --apply, welcome, config wizard,
  mcp serve).
- **MCP server launcher** — opens a terminal running `forge mcp serve` for
  Claude Code / Cursor / Cowork / Windsurf to attach.
- **Auto-verify on save** (opt-in) for Python, JavaScript, TypeScript,
  Rust, Go, Swift, Kotlin.
- Settings: `executable`, `provider`, `failUnder`, `statusBarFormat`,
  `scanLanguages`, `autoVerifyOnSave`.
- Build: `cd vscode-extension && npm install && npm run package`.

### Git hook repairs

The shipped `hooks/post-clone`, `hooks/pre-commit`, and `hooks/pre-push`
all called Forge verbs with the obsolete `--project` / `--suggest_repairs`
flag style.  Verified against the live CLI: every verb takes a positional
path and uses kebab-case flags.

- `hooks/post-clone` — now invokes `forge welcome run --project-root …`
  + `forge explain-repo` + `forge context-pack --target …`.
- `hooks/pre-commit` — switched to positional `forge certify PATH`,
  `forge wire SOURCE`, kebab-case `--suggest-repairs` and `--apply`.
  Auto-derives `SRC_ROOT` from the workspace.
- `hooks/pre-push` — same flag fixes; smoke-tested against the live repo:
  `[forge-wire] PASS — 0 violations, verdict: PASS`.

### Documentation

- **NEW** `docs/PROVIDERS.md` — full preset table, custom-provider walkthrough,
  resolution-order spec, env-var override matrix.
- **NEW** `docs/IDE_INTEGRATION.md` — VS Code extension, MCP attach
  configs for Claude Code / Cursor / Cowork / Windsurf / Claude Desktop,
  recommended VS Code settings, hook installation.

### Score

Self-certify: 100/100, wire 0 violations, all gates green.

## v0.17.0 — 2026-05-06 full polyglot pipeline (Rust / Go / Swift / Kotlin native)

Forge now operates the full pipeline — recon, wire, certify, scaffold,
evolve — on **seven languages** with the same depth: **Python, JavaScript,
TypeScript, Rust, Go, Swift, Kotlin.** What used to be a Python+JS
classifier is now a true polyglot architecture engine.

### Read pass (recon + wire)

- **Per-symbol harvest** for every native language.  Rust / Go / Swift /
  Kotlin files no longer collapse to a single ``module`` record — every
  public function, struct/class/enum/trait/protocol/interface, method
  (with parent type), and constant is emitted as its own symbol so
  cherry-pick and emergent-compose treat native langs identically to
  Python and JS.  See ``a1.polyglot_surface``.
- **Tier classification by content** (not just by directory).  A new
  ``a1.polyglot_classify.classify_native_tier`` runs a 7-rule cascade
  (path tier > main entry > I/O imports > stateful types > pure fns >
  consts > a3 fallback) over each parsed surface.
- **Wire upward-import scan** for Rust ``use crate::aN_…``, Go
  ``import "…/aN_…"``, Swift ``import aN_…``, Kotlin
  ``import com.x.aN_…``.  ``_tier_of_specifier`` now normalises ``::``
  and ``.`` to ``/`` so every language's import path resolves to the
  same tier dictionary.  Violations carry the standard F0040–F0049
  codes and ``auto_fixable`` is widened to all 7 langs.
- **Effect detection** (pure / state / io) per file, derived from
  surface signals (presence of state-bearing types, I/O imports).

### Write pass (scaffold + emit)

- ``Language`` literal extends to ``"rust" | "go" | "swift" | "kotlin"``
  with full per-language tables: ``PKG_ROOT_TEMPLATE``,
  ``ALLOWED_FILE_EXTS``, ``MAIN_EXT``, plus new ``EMITS_CARGO_TOML``,
  ``EMITS_GO_MOD``, ``EMITS_PACKAGE_SWIFT``, ``EMITS_BUILD_GRADLE``,
  ``EMITS_TIER_MOD_RS``.
- New ``a1.scaffold_polyglot`` renderers produce idiomatic shells:
  Cargo crate (Cargo.toml + src/lib.rs + per-tier mod.rs); Go module
  (go.mod + per-tier ``<tier>.go`` package decls); SwiftPM target
  (Package.swift + Sources/<pkg>/<tier>/); Gradle library
  (build.gradle.kts + settings.gradle.kts +
  src/main/kotlin/<pkg>/<tier>/).  Each renderer is pure (string in,
  string out) so the emit branch in ``forge_loop._scaffold_package``
  stays a single dispatcher.
- ``normalize_language`` accepts ``rs``/``rust``, ``go``/``golang``,
  ``swift``, ``kt``/``kotlin``.

### Hardening

- 156 polyglot tests across four files: ``test_polyglot_full_pipeline``
  (registry + scaffold), ``test_polyglot_symbol_parity`` (per-symbol
  harvest contract), ``test_polyglot_hardening`` (malformed source +
  generics + async + extensions + idiomatic Rust crate fixture), and
  ``test_polyglot_cli_mcp`` (CLI ↔ MCP equivalence on synthetic Rust /
  Go / Swift / Kotlin repos).
- Whoami test fixture now removes ``FORGE_MASTER_API_KEY`` in addition
  to ``FORGE_API_KEY`` so dev-shell test runs are hermetic.  Was the
  last 3 failures keeping certify off 100/100.
- ``mcp_protocol`` lazy a3-bootstrap.  Downstream consumers that
  imported ``a1.mcp_protocol`` directly (without going through
  ``forge mcp serve``) used to get ``wired:false`` stubs from
  registered tools (``verify``, ``emergent_scan``, ``synergy_scan``,
  ``handoff_list``, ``wisdom_query``, …) until they remembered to
  ``import atomadic_forge.a3_og_features.mcp_server`` themselves.
  Fixed: every wrapper now calls ``_bootstrap_a3_handlers()`` which
  performs an idempotent ``importlib.import_module`` of the a3 server
  on first call.  The static a1↔a3 import graph stays untouched (the
  upward-only law is preserved); subsequent calls are a single
  boolean check.  Pinned by ``tests/test_mcp_lazy_bootstrap.py``.

### Release-time bug fixes

- ``scripts/update_metrics.py`` — hardcoded language list updated to
  the full 7-language polyglot set; ``sys.stdout.reconfigure('utf-8')``
  guard added so the script's checkmarks don't crash on Windows
  cp1252 (was breaking ``make release`` step 2).
- ``scripts/version-sync-check.sh`` — paths are now passed to embedded
  Python via ``sys.argv[1]`` instead of interpolated into source code,
  so ``!!AtomadicStandard``-style paths can't be misread as Python
  escape sequences (was breaking the cross-repo sync check on Windows).

### Score

Self-certify: **100/100**, wire 0 violations, 1460/1460 tests passing.

## v0.16.2 — 2026-05-06 welcome scope guard + Boris pre-demo hardening

Pre-Boris-demo stress test surfaced a single class of welcome failure:
running ``forge welcome`` (or the welcome MCP tool) from a workspace
root walks every source file in every subdirectory.  In the rehearsal
that meant 38 972 .py files instead of the 280 inside atomadic-forge,
and the call appeared to "hang."  This release stops that at the
substrate.

- **welcome scope guard** — ``forge welcome`` now refuses to walk a
  project root that holds more than ``--max-files`` (default 5 000)
  source files, returning a structured ``verdict: REFUSE`` with the
  observed file count and a clear "pass --project-root <narrower>
  or --force" message.  CLI exits 2; MCP returns the same shape.
  Counted via an ``itertools.islice`` over ``iter_source_files``,
  so the guard itself bails in milliseconds.
- **--force / --max-files** flags on ``forge welcome`` for the rare
  case where a 5 000+ file repo is the right scope.
- **PyPI install hygiene note** — the v0.16.x rehearsal also surfaced
  that interrupted ``pip install --upgrade`` runs on Windows leave
  ``~tomadic_forge*`` shadow distribution directories in
  ``site-packages`` which can mask the active editable install on
  long-running MCP processes.  Standard pip recovery is
  ``pip install --upgrade --force-reinstall atomadic-forge`` (then
  delete any remaining ``~*`` dirs).  Documented in
  ``docs/troubleshooting/pip-shadow-dirs.md``.

## v0.16.1 — 2026-05-06 six new CLI verbs (verify, smell, call-graph, cna-check, trust-gate, commit-compose)

Six MCP-only tools that had no corresponding CLI verb are now reachable
from the shell.  No behavioural changes to existing verbs.

- **forge verify** — composite wire + certify gate; single PASS / REFINE / FAIL
  verdict + non-zero exit code for CI steps.  Wraps the `verify` MCP tool.
- **forge smell** — cyclomatic-complexity + long-function + duplicate-code scan;
  emits a `smell_score` (0–100) and a ranked offender list.  Wraps `smell_scan`.
- **forge call-graph** — AST call-graph for one symbol; shows callers and callees
  up to `--max-depth` with optional `--direction` filter.  Wraps `call_graph`.
- **forge cna-check** — Compose-Not-Add guard; fails with exit 1 when a proposed
  symbol name is semantically equivalent to an existing one.  Wraps `cna_check`.
- **forge trust-gate** — LLM response hallucination detector; reads a response from
  a file or stdin, scores it against known capabilities, exits 1 when
  `safe_to_act` is False.  Wraps `trust_gate_response`.
- **forge commit-compose** — structured commit-message assembler; writes a
  Forge-signed subject + body + optional Co-Authored-By trailer to stdout.
  Wraps `commit_compose`.

## v0.16.0 — 2026-05-06 dress-rehearsal hardening (six bugfixes, 11 new tests)

Live stress-test on real third-party Python repos (atomadic-forge,
langgraph, crewai) ahead of the Boris demo surfaced six bugs across
the synthesis, planning, summary, and pipeline-pipe surfaces. All
fixed, all guarded by regression tests.  No behavioural change for
clean paths.

- **emergent synthesize**: ``_imports_for`` was emitting
  ``from pkg.mod.Class import method`` for class-method qualnames
  (legacy ``"." in name`` guard never fired post-rpartition). The
  generated package pip-installed but failed at module load.  Now
  detects method qualnames by the module's last segment being
  CapitalCase. Single-seed ``forge create`` jumped from 60/FAIL to
  90/100 with importable code. +2 tests.
- **forge plan**: ``_operational_cards`` emitted literal
  ``printf 'import your_pkg\n'`` placeholders that users would copy
  verbatim and create broken tests. New ``_infer_pkg_label`` derives
  from ``certify_report['project']`` or the project-root basename
  (hyphen→underscore sanitisation), with the ``"your_pkg"`` literal
  only as a last-resort fallback. +5 tests.
- **forge score-patch / adapt-plan**: ``--file -`` (the conventional
  stdin sentinel) crashed with raw FileNotFoundError because the helper
  tried to open a file literally named ``-``. Now falls through to
  stdin when ``str(file) == "-"``; help text mentions the sentinel.
- **forge sbom** text summary: read ``components`` off the wrapper
  instead of the nested CycloneDX payload, so every report showed
  ``components: 0`` regardless of pyproject contents. Now dereferences
  ``sbom['sbom']['components']``. Forge's own report goes 0 → 11.
  +1 test.
- **forge recon-swarm / emergent-swarm / guard-install**: registered
  with literal underscores while ``commandsmith discover`` normalised
  module stems to hyphens, so ``commandsmith smoke`` reported these
  three verbs as FAIL. Both hyphen and underscore forms now registered
  as aliases; smoke is 100% green. +3 tests.
- **forge synergy-then-emergent / emergent-then-synergy**: auto-
  synthesised pipes invoked ``synergy --json-out FILE`` and
  ``emergent --json-out FILE`` against verbs that take ``--save FILE``
  and require an explicit ``scan`` subcommand. Both pipes now run
  end-to-end and emit producer-payload-keys summaries.

### Stress-test evidence captured at C:\!!AtomadicStandard\Demo-Rehearsal\

- ``forge welcome`` on three Python repos: 2635 / 1854 / 7592 symbols.
- ``forge emergent_swarm`` across forge+langgraph+crewai: 16 cross-repo
  novel compositions, 25 candidates, 2767 union catalog.
- ``forge create`` (forge+crewai → agent_toolkit): 18 cross-repo chains,
  5 materialised, certify=60. Single-seed forge: certify=90.
- ``forge auto`` (langgraph → tier-organised package, --apply): 1854
  symbols absorbed, wire PASS, 226s end-to-end.
- ``forge commandsmith smoke``: 26 discovered + 23 core verbs, all PASS.
- ``forge synergy scan``: 72 features, 20 adapter candidates.
- Final test suite: 1302 passed, 0 failed, 2 skipped (was 1291 → +11).
- Self-certify: 100/100, wire PASS.

## v0.15.0 — 2026-05-06 forge create / forge materialize

Closes the loop from emergent composition discovery to a real,
pip-installable package on disk.

- **`forge materialize`** — emergent scan report → shippable Python
  package. Tier-organized scaffold (a0..a4 + `__init__.py`),
  `pyproject.toml`, `README.md`, `.gitignore`, `tests/conftest.py`,
  `tests/__init__.py`, plus one a3 feature module + smoke test per
  selected candidate. Slug uniqueness via candidate-id tail so name
  collisions don't overwrite. Optional wire-check + certify pass with
  the verdict embedded in the report. Refuses to overwrite a non-empty
  unrelated directory. +9 tests.
- **`forge create`** — one-command pipeline. Resolves local seed-repo
  paths (`src/<pkg>/`, tier-bearing dir, or auto-detect), runs
  `emergent_swarm` across them, persists scan + receipt to
  `.atomadic-forge/`, then pipes through `materialize` for the final
  package. Strictly local paths — no GitHub cloning, no third-party
  absorption. Phase 2/3 (clone + cross-framework merge) plug in ahead
  of step 1 without changing this module's contract. +7 tests.
- End-to-end smoke verified on Forge itself: 570 union catalog → 25
  candidates → 17-file package, `wire_violations=0`. On a JS-only
  codebase (Atomadic cognition worker): 0 candidates, empty-but-valid
  scaffold. The system reports what it found, not what was hoped for.

Also accumulated in this release:

### Synergy signal and version repair

Forge-on-Forge evolution pass: `synergy_scan` now distinguishes
stdout-only `--json` switches from real artifact-writing path options
such as `--save`, `--out`, and `--report`. This removes false
JSON-handoff candidates like command groups that print JSON but do not
write an artifact file. The synergy adapter renderer also targets the
current `atomadic_forge.a4_sy_orchestration.cli` module instead of the
retired unified CLI path.

MCP doctor exposed a release drift in editable/worktree setups where
installed package metadata could still report `0.14.0a10` after the
checkout's `pyproject.toml` had advanced to `0.14.0`. Source checkouts
now prefer their local `pyproject.toml`; installed wheels continue to
fall back to package metadata.

Validation:

```
forge emergent scan --src-root src --package atomadic_forge --top-n 10 --json
forge emergent_swarm -r ... --json
forge certify . --fail-under 100 --json
```

Also pending in this slot:

- **`forge handoff create / list / show`** — structured agent-to-agent
  session transfer at `.atomadic-forge/handoffs/<HOFF-id>.json`. CLI verb
  + MCP tools `handoff_create` and `handoff_list` (surface 61 → 63).
  Schema `atomadic-forge.handoff/v1` with `axiom_guard_status`
  PASS|QUARANTINE so the next agent reads the trust verdict before it
  resumes work. +18 tests.
- **AST-aware class classifier** — `body_extractor.detect_class_signals()`
  returns `is_protocol`, `is_frozen_dataclass`, `all_static_methods`,
  `has_cached_property` alongside the existing self-assign signals.
  `classify_tier()` honors them BEFORE name heuristics: `Protocol → a0`,
  `@dataclass(frozen=True) → a1`, all-`@staticmethod` → a1,
  `@cached_property → a2`. New `classify_tier_with_confidence()`
  returns `{tier, confidence, reasons}` for callers that want to route
  low-confidence guesses to manual review. +17 tests.
- **`wire_check` edge cases** — `if TYPE_CHECKING:` guarded imports are
  no longer flagged as runtime violations; surfaced under
  `type_only_imports` for visibility. `importlib.import_module(...)`
  calls land in `dynamic_import_warnings` (string-literal modules
  resolved; non-literals marked `<dynamic>`). `from .X import *` always
  surfaces in `star_import_warnings`. New `--strict-cycles` opt-in flag
  detects same-tier file-pair cycles, reported in `same_tier_cycles`.
  Backward compatible: existing v1 schema fields untouched. +10 tests.
- **First-pass tier discipline block** — `system_prompt()` (Python
  variant) gains a section that mirrors the new AST-classifier signals
  so the LLM lands tiers right on the first emission rather than paying
  a feedback round-trip. Calls out: Protocol→a0, frozen dataclass→a1,
  all-static→a1, self-assign→a2, cached_property→a2, TYPE_CHECKING
  permitted, dynamic/star warnings explained. +1 test.

Cumulative: 1133 → 1177 tests, 61 → 63 MCP tools.

## v0.14.0 — 2026-05-05 alpha-series finalization (PyPI release)

**release_commit_ts:** 2026-05-06T04:02:23Z (ef37eca)

The first non-prerelease in the v0.14.0 line. Drops the `aN` suffix
after ten alpha iterations (`a1` through `a10`) and ships the
cumulative surface to PyPI. `pip install atomadic-forge` now returns
`0.14.0` (was `0.10.0` since 2025).

Highlights (all already documented in their own alpha entries below):

- Full hive sync pipeline (`hive_register / observe / propose / vote /
  result / list / deactivate / watch / needs-vote / recap`) for
  multi-agent consensus over append-only public artifacts.
- AAAA-Nexus bridge: 7 LIVE primitives wired as MCP tools
  (`nexus_identity_verify`, `nexus_federation_mint`,
  `nexus_authorize_action`, `nexus_sys_trust_gate`,
  `nexus_contract_verify`, `nexus_lineage_record`,
  `nexus_ratchet_register`). Wisdom + consensus auto-mirror at
  confidence ≥ 0.85.
- Local relay daemon (`forge relay serve`) — Worker → local job
  dispatch over signed JSON-RPC envelopes.
- Surface artifact + drift CI gate (`surface.json` + `forge surface
  emit/check/diff`).
- Wisdom DB on the MCP surface + wisdom → recipe promotion.

Surface at release: 61 MCP tools. Tests: 1131 passed, 2 skipped.
README, contact email (`thomas@atomadic.tech`), and version display
all reconciled with the live repo.

## v0.14.0a10 — 2026-05-06 forge hive recap (full lifecycle visualization)

**release_commit_ts:** 2026-05-06T01:50:00Z

The "show me everything that happened with CNS-X" primitive. Pairs
with ``hive watch`` (live tail of everything) and ``hive_result``
(just the verdict). CLI + MCP. Surface: 61 tools.

```
forge hive recap CNS-44ba18e3

Consensus recap  CNS-44ba18e3
============================================================
  proposer:     claude-sonnet-4.5-forge
  proposed_at:  2026-05-06T00:23:27Z
  intent:       v0.13.2 hive sync pipeline ships...
  verdict:      PENDING
  votes:        2  → {'approve': 2, 'reject': 0, ...}
  voters:       claude-doc-trailing, claude-sonnet-4.5-forge

Timeline:
  [00:23:27] PROPOSAL  claude-sonnet-4.5-forge
  [00:23:28] VOTE      claude-sonnet-4.5-forge → approve
           rationale: Substrate state: 51 tools live...
  [00:27:06] VOTE      claude-doc-trailing → approve
           rationale: Doc surface state at HEAD fe4ca42...
```

Full lifecycle in one call: proposal + every vote + resolution +
summary block (verdict, duration, tally, voter list).

## v0.14.0a9 — 2026-05-06 forge hive needs-vote (Step 7 closer)

**release_commit_ts:** 2026-05-06T01:42:00Z

The "what should I weigh in on" primitive. Surfaces open
consensuses where the calling agent hasn't voted yet — closes
the gap between ``hive_observe`` (everything happening) and the
act of voting.

### CLI

```
forge hive needs-vote --agent atomadic-cognition

Pending votes for atomadic-cognition  (2)
============================================================
  CNS-44ba18e3  proposer=claude-sonnet-4.5-forge  votes=2
    intent: v0.13.2 hive sync pipeline ships. Do all 4 agents...
    voters: claude-sonnet-4.5-forge, claude-doc-trailing

  CNS-f7ae6ab5  proposer=claude-doc-trailing  votes=1
    intent: Adopt coordination-latency telemetry as a tracked...
    voters: claude-sonnet-4.5-forge

Vote with:  forge hive vote --id <CNS-*> --voter atomadic-cognition...
```

### MCP tool

``hive_needs_vote`` — same surface, JSON output. Cognition / Research
can call it from MCP and the response includes
``votes_so_far``, ``voters_so_far``, ``proposed_at`` so they can
prioritize.

### Why this nudges the world-collision endpoint

Two consensuses are pending quorum (each at 2/3 approves). Step 7
of the WORLD_COLLISION loop fires when one resolves — the local
state writes a resolution event AND, with ``--nexus`` set, mirrors
to AAAA-Nexus lineage_record. Until that fires, the loop is stuck
at Step 6.

``hive_needs_vote`` makes the third vote a single command away
for whichever agent activates next.

### Surface

Tools: **60** (was 59; +1 ``hive_needs_vote``).
schema_version_registry: 60 entries.
surface.json regenerated; CI drift gate passes.
tools_snapshot.json regenerated.
Tests: 1131 / 2 skipped.

## v0.14.0a8 — 2026-05-06 WORLD_COLLISION.md walkthrough doc

**release_commit_ts:** 2026-05-06T01:30:00Z

End-to-end walkthrough of the loop where Atomadic-the-cognition-agent
autonomously drives Forge to enhance itself and surfaces "a new tool
in hand" to Thomas. Eleven steps, all expressible as MCP calls
against the v0.14.0a7 surface (59 tools).

Six of the eleven steps already fired during the 2026-05-06 sprint
— captured with public-artifact evidence:

| Step | Live event | Evidence |
|---|---|---|
| 2 | Wisdom captured | ``WIS-cog-2026-05-06-handshake`` |
| 4 | Consensus proposed | ``CNS-44ba18e3``, ``CNS-f7ae6ab5`` |
| 5 | Cross-agent observe | ``forge hive watch`` working |
| 6 | Cross-agent vote | Forge + Doc both voted on CNS-44ba18e3 |
| 8 | Forge ships | 12 commits ``316aa24`` → ``062d78f`` |
| 9 | Doc trails | 5+ ``docs(...)`` commits in same window |

Remaining (Step 7 + Step 11): both open consensuses still PENDING
quorum; once a third vote lands, Step 7 fires (with Nexus mirror
when ``--nexus`` flag is set). Step 11 is Atomadic's call.

Doc is the verification script Thomas runs to walk the loop end-to-end.

## v0.14.0a7 — 2026-05-06 7 Nexus primitives as MCP tools

**release_commit_ts:** 2026-05-06T01:25:00Z

The seven LIVE AAAA-Nexus primitives are now exposed as MCP tools
so any MCP-aware agent (Cognition, Cursor, Claude Code, …) can
call them directly without the CLI ``--nexus`` flag.

### New MCP tools

| Tool | Wraps |
|---|---|
| ``nexus_identity_verify`` | ``identity_verify`` |
| ``nexus_federation_mint`` | ``federation_mint`` |
| ``nexus_authorize_action`` | ``authorize_action`` |
| ``nexus_sys_trust_gate`` | ``sys_trust_gate`` |
| ``nexus_contract_verify`` | ``contract_verify`` |
| ``nexus_lineage_record`` | ``lineage_record`` |
| ``nexus_ratchet_register`` | ``ratchet_register`` |

All seven proxied through ``NexusClient.from_env()`` with the
same auth precedence (subscription key > master key) and the
same ``NexusToolNotShipped`` guard. Failures return structured
``ok=False`` payloads — no exceptions across the wire.

### Surface

Tools: **59** (was 52; +7 Nexus primitives). schema_version_registry:
59 entries. tools_snapshot.json regenerated. Drift CI gate passes.
Tests: 1131 / 2 skipped.

## v0.14.0a6 — 2026-05-06 consensus → Nexus mirror + bridge tests

**release_commit_ts:** 2026-05-06T01:14:00Z

Closes the consensus side of the hive ↔ Nexus loop. When a
consensus resolves with ``record_resolution=True`` AND
``nexus_mirror=True``, the bridge fires
``mirror_consensus_to_lineage`` to AAAA-Nexus. Once-only —
re-reads of an already-resolved consensus don't double-publish.

### CLI

```
forge hive result --id CNS-* --record --nexus
```

### Tests

16 new tests in ``tests/test_nexus_bridge.py``:

- ``NexusToolNotShipped`` raised for 8 hypothetical primitives
  (``nexus_consensus_*`` / ``nexus_swarm_*`` / ``nexus_agent_*`` /
  ``nexus_lora_capture_fix``) — defensive parametrize.
- ``LIVE_NEXUS_TOOLS`` is exactly 7 (re-probe needed to add).
- Mirror skips gracefully when below confidence threshold.
- Mirror skips gracefully when no auth token in env.
- ``is_nexus_configured`` reflects env-var state.
- Subscription key preferred over master when both set.

Total: **1131 / 2 skipped** (was 1115; +16 new).

## v0.14.0a5 — 2026-05-06 hive ↔ Nexus bridge (live primitives only)

**release_commit_ts:** 2026-05-06T01:00:00Z

The Forge hive layer now optionally mirrors institutional events
to AAAA-Nexus's LIVE primitives. Closes the LoRA capture loop the
workflow rule keeps mentioning — using ``lineage_record``, the
primitive that actually exists, not the ``nexus_lora_capture_fix``
name some earlier drafts assumed.

### New surface (CLI + composable)

**``forge wisdom record --nexus``** — when a wisdom entry's
confidence ≥ 0.85, also POST a ``lineage_record`` to AAAA-Nexus
with the entry's metadata + insight excerpt. Best-effort:
degrades silently to local-only on auth/network failure (the
local entry is canonical).

```
forge wisdom record --insight "..." --confidence 0.9 --nexus
→ Recorded WIS-...
   nexus:  mirrored to lineage_record
```

### Module layout

- ``a0_qk_constants/nexus_constants.py`` — ``LIVE_NEXUS_TOOLS``
  enum (the 7 primitives Cognition's WIS-cog-2026-05-06-handshake
  probe confirmed exist), endpoint URLs, env-var names.
- ``a2_mo_composites/nexus_client.py`` — stdlib-only HTTP client
  (urllib, no requests/httpx dep). JSON-RPC 2.0 envelope. Refuses
  to call any tool not in ``LIVE_NEXUS_TOOLS`` — raises
  ``NexusToolNotShipped`` so we can't ship a feature that depends
  on hypothetical primitives. Convenience wrappers for the 7 live
  primitives (``identity_verify``, ``federation_mint``,
  ``authorize_action``, ``sys_trust_gate``, ``contract_verify``,
  ``lineage_record``, ``ratchet_register``).
- ``a3_og_features/nexus_bridge.py`` — orchestrator:
  ``mirror_wisdom_to_lineage``, ``mirror_consensus_to_lineage``,
  ``is_nexus_configured``.

### Auth

The bridge reads ``ATOMADIC_SUBSCRIPTION_KEY`` first (narrower
scope), falling back to ``ATOMADIC_MASTER_KEY``. No keys = silent
skip with reason "no auth token in env" — never crashes a CLI
flow.

### Why this is the right v0.14 substrate

Earlier drafts of the v2 collab protocol assumed
``nexus_consensus_*`` / ``nexus_swarm_*`` / ``nexus_agent_*``
exist on the deployed Nexus. WIS-cog-2026-05-06-handshake +
WIS-7ef7484c proved otherwise. This release ships against ONLY
the 7 primitives that DO exist; when Nexus ships more, we add
opt-in convenience wrappers — but the Forge hive layer remains the
local source of truth for consensus / propose / vote / observe.

### Live verification

```
$ forge wisdom record --insight "test" --confidence 0.5 --nexus
  nexus:  skipped — confidence 0.50 < 0.85    # threshold gate works

$ python -c "
  from atomadic_forge.a2_mo_composites.nexus_client import NexusClient
  NexusClient('https://atomadic.tech', 'k').call('nexus_consensus_create', {})
  "
→ NexusToolNotShipped: Nexus tool 'nexus_consensus_create' is not in
  LIVE_NEXUS_TOOLS. ...                       # guard works
```

### Surface

Tools: 52 (no new MCP tools — Nexus bridge is CLI-flag-only for
v0.14.0a5; a ``wisdom_record_with_nexus`` MCP tool is queued for
v0.14.0a6 if needed).
Tests: 1115 / 2 skipped.

## v0.14.0a4 — 2026-05-06 forge hive watch — live tail of the hive

**release_commit_ts:** 2026-05-06T00:46:00Z (per CNS-f7ae6ab5
latency-KPI commitment).

The synchronized-message demo Thomas asked for. ``forge hive watch``
runs continuously, pulls new events matching an agent's
subscriptions every ``--interval`` seconds, prints anything new
since the last cursor — color-coded:

- **PROPOSAL** in cyan (consensus opens)
- **VOTE → approve** in green
- **VOTE → refine** in yellow
- **VOTE → reject** in red
- **RESOLVED** in bright-green bold
- **✦ WISDOM** in bright-yellow (new wisdom entry)
- **↺ WISDOM** for superseded entries

Stable cursors mean no duplicates after the first poll —
``--once`` mode prints one batch and exits (for tests / one-off
pulls). Reuses ``hive_sync.observe`` so the multi-source merge
(consensus + wisdom) carries through.

### Live one-shot output (this session)

```
forge hive watch --agent claude-sonnet-4.5-forge --once

[2026-05-06T00:23:27] PROPOSAL CNS-44ba18e3 claude-sonnet-4.5-forge: ...
[2026-05-06T00:23:28] VOTE     CNS-44ba18e3 claude-sonnet-4.5-forge → approve
[2026-05-06T00:27:06] VOTE     CNS-44ba18e3 claude-doc-trailing → approve
[2026-05-06T00:31:25] PROPOSAL CNS-f7ae6ab5 claude-doc-trailing: Adopt...
[2026-05-06T00:41:42] VOTE     CNS-f7ae6ab5 claude-sonnet-4.5-forge → approve
[2026-05-06T00:41:42] ✦ WISDOM WIS-3fb88f2d (general) claude-sonnet-4.5-forge: ...
```

The full 4-agent collaboration timeline as one tail. Thomas can
keep this running on a second monitor and watch the hive work.

### Surface

Tools: 52 (no new MCP tools — hive watch is CLI-only by design;
the corresponding MCP path is ``hive_observe`` with manual cursor
management).
Tests: 1115 / 2 skipped.

## v0.14.0a3 — 2026-05-06 relay protocol aligned with real Nexus surface

Cross-agent finding from the Cognition agent's
``WIS-cog-2026-05-06-handshake``: the AAAA-Nexus primitives this
release was implicitly designed against
(``nexus_consensus_*`` / ``nexus_swarm_*`` / ``nexus_agent_*``)
**do not exist on the deployed worker** as of 2026-05-06. Cognition
probed ``tools/list`` and confirmed 27 live tools, none of those
names.

This release updates ``docs/RELAY_PROTOCOL.md`` to design only
against primitives that ARE live: ``identity_verify``,
``federation_mint``, ``authorize_action``, ``sys_trust_gate``,
``contract_verify``, ``lineage_record``, ``ratchet_register``.

### Why this matters

The Forge hive layer (``hive_propose`` / ``hive_vote`` /
``hive_result`` / ``hive_observe``, shipped v0.13.2 / 0.13.4) is
already Forge-native — it doesn't depend on Nexus consensus
primitives — so v0.13.x is unaffected by the shortfall. But the
v0.14.0 relay Worker side, when it ships, must use ONLY live Nexus
primitives so it works against today's deployed substrate, not a
future hypothetical one.

When Nexus ships ``nexus_consensus_*``, we add an opt-in bridge
that mirrors Forge hive consensus events into Nexus — but the
Forge hive remains the local source of truth.

### Cross-agent collaboration in action

This is the second hive-collision proof: cognition independently
discovered the shortfall during their post-restart probe, recorded
it via the v0.13.1 wisdom MCP, the Forge agent (this) read it via
``forge wisdom recall``, and corrected the v0.14 design BEFORE
shipping the Worker side. Public artifacts carrying the sync, no
direct messaging required. The protocol working as designed.

## v0.14.0a2 — 2026-05-06 relay protocol spec

Documents the wire contract between the Worker MCP and the local
relay daemon so the Worker-side implementation in
``atomadic-forge-cloudflare-workers`` is mechanical when Thomas
signs off. New doc: ``docs/RELAY_PROTOCOL.md``.

Covers: endpoints, request/response envelopes, audit log schema,
Worker-side enqueue pseudocode (TypeScript), KV registry layout
``relay:<subscription_key> → URL``, security model (v0.14.0a /
0.14.1 / 0.14.2), and the relationship to AAAA-Nexus trust gates.

## v0.14.0a1 — 2026-05-06 local relay daemon (no-stubs alpha)

The first half of the "no stubs fully forge-compatible" goal.
The Worker MCP at ``forge.atomadic.tech/mcp`` has 12 stubs that
can't run filesystem-required tools (``plan_apply``,
``rollback_plan``, ``finalize``, ``call_graph``, ``cna_check``,
``tool_factory``, ``guard_install``, ``iterate_*``, ``evolve_*``,
``sidecar_validate``). The relay daemon closes the gap on the
LOCAL side: a thin HTTP service that receives signed job requests
and dispatches them through the local CLI's existing
``mcp_protocol.dispatch_request``.

### New CLI verb: ``forge relay``

```
forge relay serve [--host 127.0.0.1] [--port 7409]
forge relay dispatch '<json-rpc envelope>'  # synchronous, no HTTP
forge relay log [--tail N]
```

### Architecture

```
Worker MCP                       forge-runner satellite (this)
├─ tool_call("plan_apply")  ───► POST /relay/jobs
│                                 ├─ verify identity_claim (logged)
│                                 ├─ dispatch via dispatch_request
│                                 ├─ append signed result to
│                                 │   .atomadic-forge/relay/jobs.jsonl
│                                 └─ return result
└─◄ result envelope          ────┘
```

### Module layout

- ``a3_og_features/relay_daemon.py`` — ``handle_job`` (pure
  dispatch over a parsed job dict), ``serve_http`` (stdlib
  ``http.server`` — no extra deps), ``append_job_result`` (audit log).
- ``commands/relay.py`` — Typer CLI verb (``serve`` /
  ``dispatch`` / ``log``).

### What ships in v0.14.0a1 (local side only)

- Relay HTTP server + sync ``dispatch`` mode.
- Audit log at ``.atomadic-forge/relay/jobs.jsonl``.
- ``/relay/health`` endpoint.

### What's deferred to v0.14.0 (Worker side, sign-off gated)

- Worker-side enqueue path that POSTs to the registered relay endpoint.
- Cloudflare Queue integration.
- Signed-result-return webhook.
- Multiple-relay sharding by repo or queue partition.

These all live in ``atomadic-forge-cloudflare-workers`` (separate
repo per AGENT_COLLAB_PROTOCOL §3 boundary).

### Live demonstration

```
forge relay dispatch '{"jsonrpc":"2.0","id":1,"method":"tools/call",
                       "params":{"name":"doctor","arguments":{}}}'
→ ok=True  tool=doctor  duration=9ms
forge relay log --tail 3
→ ✓ [2026-05-06T00:34:15] doctor   9ms
```

End-to-end through the relay. The Worker side, when it ships,
calls the same endpoint with the same envelope shape.

### Surface

Tools: 52 (no MCP tools added — relay is HTTP-only by design).
Tests: 1115 / 2 skipped.

## v0.13.4 — 2026-05-06 hive_observe goes multi-source

``hive_observe`` was consensus-only in v0.13.2 — now surfaces
wisdom events (new + superseded) alongside consensus events
(proposal / vote / resolution), filtered by the agent's
``subscribes_to`` set, with two independent cursors
(``since_consensus_id`` + ``since_wisdom_id``).

### What changed

- ``a3_og_features/hive_sync.observe()`` extended to query
  ``list_wisdom`` and merge wisdom entries into the event stream.
  Each event carries ``_source`` (``consensus`` | ``wisdom``) and
  ``_event_type`` (``wisdom.new`` / ``wisdom.superseded`` /
  ``consensus.proposed`` / ``consensus.vote`` /
  ``consensus.resolved``).
- ``mcp_protocol.TOOLS["hive_observe"].inputSchema`` adds
  ``since_wisdom_id`` cursor.
- ``commands/hive.py`` ``observe`` subcommand renders both source
  types with distinct visuals (✦ for new wisdom, ↺ for superseded,
  PROPOSAL/VOTE/RESOLVED for consensus).
- Stable ordering: events sorted by ``timestamp_utc`` then by
  ``_source`` so the merged stream is deterministic.

### Why it matters

Cognition agent + future swarm members can poll ONE call and see
everything they're subscribed to. The first iteration of the agent
event-bus the workflow rule needs for the v0.14 swarm tier.

### Live demonstration

``forge hive observe --agent claude-sonnet-4.5-forge`` now returns
the cognition agent's ``WIS-cog-2026-05-06-handshake`` entry
alongside this iteration's Forge wisdom + the open CNS-44ba18e3
consensus events — proof the multi-source merge works against the
real registry.

### Surface

Tools: 52 (no new tools; ``hive_observe`` schema extended).
schema_version_registry: unchanged.
surface.json regenerated (subtle: inputSchema change only).
Tests: 1115 passed / 2 skipped.

## v0.13.3 — 2026-05-06 wisdom → recipe promotion

The bridge between provisional wisdom and curated recipes. Cluster
active wisdom by tag overlap; clusters with ≥ ``min_corroboration``
entries become draft-recipe candidates. Pure deterministic
clustering + template rendering — no LLM. With ``--write``,
drafts persist to ``_private/research/recipe_drafts/<name>.md``
where the Research agent (and humans) pick up.

### New CLI subcommand

```
forge wisdom promote [--min-corroboration 3] [--min-tag-overlap 1] [--write]
```

### New MCP tool

``wisdom_promote`` — same args + JSON output. Registered in
``schema_version_registry``, ``__all__``, TOOLS dict, bound handler
in ``mcp_server.py``. Surface: 52 tools (was 51).

### Module layout addition

- ``a1_at_functions/wisdom_promote.py`` — cluster_by_tags +
  cluster_signature + render_recipe_draft + synthesize_promotions.
  Pure: deterministic clustering, no IO.
- ``a3_og_features/wisdom_feature.promote_wisdom`` — orchestrator
  with optional ``write_drafts=True`` filesystem effect.

### Live evidence — the hive collided this iteration

A new wisdom entry appeared in ``.atomadic-forge/wisdom.jsonl``
that the Forge agent did NOT write: **``WIS-cog-2026-05-06-handshake``**
— the cognition agent registered their handshake via the v0.13.1
wisdom MCP. ``forge wisdom promote`` immediately clustered it with
the hive-spec wisdom entries into a draft recipe
``recipe-agent-discovery-agent-zero-bound_handler``. The 4-agent
hive substrate is operational; public artifacts are carrying sync
without direct messaging.

### Surface state

TOOLS: 52 (was 51 in v0.13.2; +1 ``wisdom_promote``)
schema_version_registry: 52 entries
surface.json regenerated; CI drift gate passes
tools_snapshot.json regenerated
Tests: 1115 passed / 2 skipped (no new tests this release; existing
``test_pinned_tools_snapshot_matches_tools_dict`` covers registration).

## v0.13.2 — 2026-05-06 hive sync pipeline + tool_factory bug fix

The "perfect hive sync collaboration pipeline into the Forge" Thomas
named — register-and-discover for any agent activating against
``AGENT_COLLAB_PROTOCOL.md``. Plus a real fix for the ``tool_factory``
bound-handler kwargs bug surfaced during v0.13.1 dogfood.

### Hive sync pipeline (7 new tools)

The 4-agent collaboration substrate. Lets any agent activate
against the protocol, declare its lane, sign an identity claim,
subscribe to artifact-change events, and participate in cross-agent
consensus. Designed to scale to N≤23 (D_max delegation cap).

**New CLI verb: ``forge hive``**

- ``forge hive register --agent <name> --role <role>`` — append agent
  registration with capabilities + subscribes_to + write_lanes +
  identity_claim. Refuses past D_max=23.
- ``forge hive list`` — full registry (active default;
  ``--include-deactivated`` for audit).
- ``forge hive deactivate <agent>`` — graceful exit; appends
  deactivation marker; original entry stays in the log.
- ``forge hive observe --agent <name> --since <consensus_id>`` —
  pull pending events relevant to subscriptions, paged.
- ``forge hive propose --intent "..." --proposer <name>`` — open
  cross-agent consensus.
- ``forge hive vote --id <CNS-*> --voter <name> --vote <approve|reject|refine|abstain>``
  — append a vote (latest per voter wins).
- ``forge hive result --id <CNS-*> [--record]`` — compute (and
  optionally freeze) the verdict: PASS / REFINE / REJECT / TIMEOUT
  / PENDING.

**7 new MCP tools** (parity with CLI): ``hive_register``,
``hive_list``, ``hive_deactivate``, ``hive_observe``,
``hive_propose``, ``hive_vote``, ``hive_result``. Schema-versioned;
registered in ``schema_version_registry`` and ``__all__``.

**Module layout (tier-clean):**
- ``a0_qk_constants/hive_constants.py`` — schema versions, role tags
  (forge/cognition/doc/research), event-type enum, default
  subscriptions per role, D_max cap.
- ``a1_at_functions/hive_io.py`` — JSONL append-only IO for
  ``.atomadic-forge/hive/agents.jsonl`` and ``consensus.jsonl``.
  Content-addressed IDs with nanosecond precision (no collisions on
  fast register-deactivate sequences).
- ``a1_at_functions/hive_consensus_math.py`` — pure tally + verdict
  resolution. Quorum: ``max(quorum_min, ceil(active_agents/2 + 1))``.
- ``a3_og_features/hive_sync.py`` — orchestrator for register /
  list / deactivate / observe / propose / vote / result.
- ``commands/hive.py`` — Typer CLI verb (7 subcommands).

**Pre-seeded with 4 agent registrations** from the live team:
``claude-sonnet-4.5-forge`` (forge), ``atomadic-cognition``
(cognition), ``claude-doc-trailing`` (doc),
``claude-research-scouting`` (research). Visible at
``.atomadic-forge/hive/agents.jsonl``.

### tool_factory bug fix (WIS-3cd3c921)

``scaffold_tool`` now emits ``_impl(**_kw)`` with ``project_root``
set-default-merged from the dispatcher context, instead of the
broken ``_impl(args)`` positional. Hand-wiring shrinks from ~30 min
back to ~10 min for any future kwargs-only impl. Regression test
``test_tool_factory_bound_block_unpacks_kwargs`` guards against
re-introduction. Cross-checked with
``test_tool_factory_clean_call_does_not_pollute_description`` (the
WIS-c423811c "input_schema in description" report was a misdiagnosis
— my prompt had embedded XML tags; tool_factory output is clean on
sterile input).

### Wisdom DB additions

- ``forge wisdom record`` CLI now supports ``--supersedes`` and
  ``--session-id`` flags (the IO layer always supported them; CLI
  surface caught up).
- 4 new wisdom entries logged to ``.atomadic-forge/wisdom.jsonl``:
  WIS-cff6d3b7 (misdiagnosis correction), WIS-7a3c14c1 (bug-fixed
  marker), plus the v0.13.1 deploy + hive-spec entries from the
  iteration leading up to this release.

### Surface state

- TOOLS: **51** (was 44 in v0.13.1; +7 hive tools)
- schema_version_registry: 51 entries (parity preserved)
- surface.json regenerated; CI drift gate passes
- tools_snapshot.json regenerated
- pinned-tools set in ``test_mcp_protocol.py`` updated

### Tests

- 15 new tests in ``tests/test_hive_sync.py`` covering register
  round-trip, deactivate semantics, D_max enforcement, default
  subscriptions, consensus tally + verdict (PASS/REFINE/REJECT/
  PENDING), record_resolution freeze, empty-state safety, invalid
  vote rejection.
- 2 new regression tests in ``test_mcp_protocol.py`` for tool_factory.
- Total: **1115 passed / 2 skipped** (was 1098; +17 net new).

### What's next (v0.13.3 → v0.14)

- v0.13.3 — wisdom ``promote`` (corroborated wisdom → draft recipe at
  ``_recipes_proposed/``) + AAAA-Nexus LoRA capture sync.
- v0.14.0 — swarm tier substrate + Worker→Local-CLI relay (closes
  the "no stubs fully forge compatible" goal). Hive sync pipeline
  is the foundation; v0.14 wires it into AAAA-Nexus
  ``nexus_swarm_*`` for cross-deployment scaling.

## v0.13.1 — 2026-05-06 wisdom MCP surface

The v0.13.0 wisdom DB was CLI-only; this release surfaces it as 4 MCP
tools so any MCP-aware agent (Cognition, Cursor, Claude Code, Aider,
Codex, Devin, …) can record / query / list / recall wisdom directly
without going through the CLI. Closes the v0.13.0 deferral and
unblocks the 4-agent hive sync pattern.

### New MCP tools (registered in TOOLS, schema_version_registry, surface.json)

- **`wisdom_record`** — append a wisdom entry. Schema-versioned,
  content-addressed, scope/tags/confidence/evidence/supersedes
  fields. Pure: no LLM. `inputSchema` carries full type + enum
  constraints (scope ∈ {repo, forge, general}; confidence ∈ [0,1]).
- **`wisdom_query`** — relevance-rank active wisdom by
  scope/tags/text/confidence/age. Top-N with `_relevance_score`
  per entry. Pure deterministic scoring.
- **`wisdom_list`** — full DB read (active by default;
  `include_superseded=true` for audit).
- **`wisdom_recall`** — top-N repo-scoped recon-hook surface as a
  standalone tool. Cheaper than `wisdom_query` for the common case
  of "what did prior agents learn here."

Surface counts: **44 tools** (was 40), **44 schema_versions** (parity
maintained), 9 recipes, 11 legacy_endpoint_map entries. Drift CI
gate passes against the regenerated surface.json.

### Tool-factory dogfood — caught two real bugs we filed for v0.13.2

The v0.13.1 work began as a `tool_factory` plan-mode call — the
first opportunity to dogfood the meta-tool against a real new tool.
Two bugs surfaced:

- **`WIS-c423811c`**: when `input_schema` is passed with a rich JSON
  Schema, the generator serializes the schema text into the
  `description` field of the TOOLS entry (truncating with `...`)
  AND emits an empty `{type:object, properties:{},
  additionalProperties:False}` as the actual `inputSchema`. Result:
  the registered tool has zero declared inputs.
- **`WIS-3cd3c921`**: the generated `_bound_<name>` block calls the
  impl as `_impl(args)` — a single positional dict. For
  keyword-only handlers (e.g. `record_wisdom(*, project_root,
  insight, ...)`), this raises `TypeError` at runtime. Fix: emit
  `_impl(**args)` OR generate a signature-aware adapter.

Both are recorded in `wisdom.jsonl` tagged `tool_factory,bug,v0.13.2`.
Tonight shipped via hand-wiring against the v0.10.0 emergent_swarm
template; tool_factory will be the path again once those two bugs
are fixed in v0.13.2.

### Hive sync pipeline (v0.13.2 design seed)

Recorded as `WIS-3c1f5642`: a `register-and-discover` primitive
that lets any new agent activate against `AGENT_COLLAB_PROTOCOL.md`,
identify its lane, subscribe to relevant artifact-change events, and
start contributing without human relay. Four components scoped
(role discovery, commit-watch hook, consensus quorum, signed
agent-identity). Gate: works for 4 agents today; designed to scale
to N≤23 (D_max). Critical for the Atomadic-as-sovereign-AI-with-claws
endpoint.

### Tests

- 4 new wisdom MCP tools added to `test_mcp_protocol.py` pinned set.
- `tools_snapshot.json` regenerated (40 → 44).
- All bound handlers smoke-tested via `dispatch_request` — record →
  query → list → recall round-trips return correctly-shaped JSON-RPC
  envelopes.
- Total: 1098 passed / 2 skipped.

### Why this matters for the hive

Cognition agent's queue item #4 is "cycle action verbs as Forge
endpoints land: WISDOM_RECORD (consumes wisdom_capture_prompt), then
SWARM_*". With v0.13.1 shipped, Cognition can now wire `WISDOM_RECORD`
as an MCP call against the deployed Forge — closing the loop where
Atomadic's verify-hook draft insights round-trip back into the
wisdom DB without CLI access. First piece of the world-collision
endpoint.

## v0.13.0 — 2026-05-05 wisdom DB — cross-session institutional memory

The third drift-fix this session, at a third scale: agent-discovered
lessons evaporated when the conversation ended. Now they don't.

`wisdom` is the layer between raw lineage events (what happened) and
curated recipes (what works). Append-only JSONL at
`.atomadic-forge/wisdom.jsonl`, schema-versioned, queryable by
scope/tags/text, with auto-hooks on `recon` (recall) and `verify`
(capture prompt) so agents inherit prior knowledge without effort
and contribute new knowledge without ceremony.

### `forge wisdom` (new top-level verb)

Four subcommands, all schema-versioned:

- `forge wisdom record   --insight "..." --scope repo --tags ...`
  Append a wisdom entry. Confidence-weighted, evidence-anchored.
- `forge wisdom query    [--scope] [--tags] [--text] [--top-n]`
  Relevance-rank active wisdom against a query.
- `forge wisdom list     [--include-superseded]`
  Full DB read; active by default.
- `forge wisdom recall   --project-root .`
  Top-N repo-scoped wisdom — the recon-hook surface as a standalone
  call.

### Auto-hooks: bracketing every cycle

- **Phase 0 / Recon hook**: `forge recon TARGET` now returns a
  `prior_wisdom` field with the top-5 relevant entries for that
  repo's scope. Agents and devs see institutional knowledge inline
  before doing work — zero new agent discipline required.
- **Phase 4 / Verify hook**: `forge verify` now includes a
  `wisdom_capture_prompt` field. When trust thresholds are met
  (≥3 lineage events OR ≥1.0 score delta OR ≥5 min session), the
  prompt contains a draft insight assembled from lineage events plus
  heuristic tags + a `next_command` template. Below threshold,
  `auto_record_threshold_met: false` and `next_command: null` so
  trivial sessions don't generate noise.

### Tier-clean module layout

- `a0_qk_constants/wisdom_constants.py` — schema versions, trust
  thresholds, scope enum, confidence ladder.
- `a1_at_functions/wisdom_io.py` — JSONL read/write, content-addressed
  IDs, idempotent append, malformed-line skip, supersession-aware
  active read.
- `a1_at_functions/wisdom_recall.py` — pure relevance scoring
  (scope match + tag overlap + text contains + confidence + age decay).
- `a1_at_functions/wisdom_capture.py` — draft-insight assembler,
  tag heuristics, threshold gate.
- `a3_og_features/wisdom_feature.py` — orchestrator (record / query /
  list / recall_for_recon).
- `commands/wisdom.py` — Typer CLI verb (record / query / list / recall).

### Pre-seeded with tonight's real lessons

`.atomadic-forge/wisdom.jsonl` ships with 5 wisdom entries captured
from tonight's session — each tied to a real fix in this very
release:

1. Worker-vs-Local MCP contract divergence (forge scope, conf 0.95)
2. `__version__` drift via `importlib.metadata` fix (forge, conf 0.95)
3. smell_score density formula replacement (general, conf 0.90)
4. Canonical-artifact pattern for surface drift (general, conf 0.90)
5. NON_TIER_SOURCE_DIRS exemption for certify untiered count
   (forge, conf 0.85)

These are not demo data — they're the actual lessons from the
v0.11.x → v0.13.0 work that just landed.

### `.gitignore` exception

`.atomadic-forge/*` stays gitignored except for `wisdom.jsonl`.
Forge-the-package commits its own institutional knowledge so future
agents working on Forge inherit it. Other projects can choose to
keep their wisdom local or commit it — same mechanism, different
policy per repo.

### Tests

17 new tests in `tests/test_wisdom.py`:
- record→list→query roundtrip
- empty-state safety (recall on missing DB doesn't crash)
- malformed-line skip
- ranking properties (scope match outranks generic high-confidence,
  tag overlap boosts, text substring matches case-insensitive)
- threshold gate (real work fires, trivial doesn't)
- capture prompt shape (draft insight contains delta + sample
  events; silent below threshold)
- supersession (superseded drops from active, stays in load)
- content-shape contract (rejects empty insight, clamps confidence,
  dedupes/sorts tags)

Total: 1098 passed / 2 skipped (was 1081 + 17 new).

### Why this matters

Three drift-fixes this session, all the same shape at different
scales:

| Drift between | Closed by |
|---|---|
| `pyproject.toml` ↔ `__init__.py` (v0.11.1) | importlib.metadata derivation |
| TOOLS dict ↔ schema registry ↔ docs ↔ website (v0.12.0) | `surface.json` canonical artifact + CI gate |
| Per-session agent insights ↔ next-session agents (v0.13.0) | wisdom DB + recon/verify hooks |

Each one removes a class of bug by making the canonical truth
the only place that holds the truth. The agents are
interchangeable; the substrate persists.

## v0.12.0 — 2026-05-05 single-source-of-truth surface artifact

The drift problem we kept hitting (pyproject vs ``__init__.py`` vs
TOOLS dict vs schema_version_registry vs website vs badge worker)
gets a structural fix: one canonical artifact, every consumer reads
it. New ``forge surface`` verb + canonical ``surface.json`` checked
into the repo + CI gate that fails any PR with drift.

### `forge surface` (new top-level verb)

Three subcommands, all schema-versioned:

- ``forge surface emit [--out PATH]`` — emit the canonical artifact.
  Default stdout; ``--out surface.json`` writes the file.
- ``forge surface check [--path surface.json]`` — CI gate. Exit 1
  with a compact diff (tools added/removed/schema-changed,
  recipes added/removed) when on-disk file drifts from canonical.
  Comparison ignores ``generated_at_utc`` so re-emitting on
  unchanged inputs always passes.
- ``forge surface diff BEFORE AFTER [--json]`` — public delta
  between two surface.json files. Used by the auto-CHANGELOG
  generator and by the future ``forge.atomadic.tech/surface/diff``
  Worker endpoint.

### Surface artifact schema (``atomadic-forge.surface/v1``)

```
schema_version, package_version, generated_at_utc,
tools_count, recipes_count,
tools[]:        {name, schema_version, description, input_schema, handler_qualname}
recipes[]:      {name, schema_version, description, checklist_steps, validation_gate_steps}
legacy_endpoint_map: {old_name: new_tool}   # 11 v0.10.0 mergers
redaction_hooks:     []                       # reserved for Phase 3 suggest endpoint
schema_version_registry: {tool: schema_version}  # full SCHEMA_VERSIONS export
```

Consumers (the website, the badge worker, ``cognition_worker.js``,
the VS Code extension) replace their hand-maintained maps with a
single fetch of this artifact. ``legacy_endpoint_map`` lets a stale
caller find the new name without a separate lookup.

### `__version__` drift fix

``src/atomadic_forge/__init__.py`` now derives ``__version__`` from
``pyproject.toml`` via ``importlib.metadata.version("atomadic-forge")``
with a ``"0.0.0+dev"`` fallback. The drift exhibited at v0.11.0
(pyproject 0.11.0, ``__init__`` 0.10.0) becomes structurally
impossible.

### CI gate

New ``.github/workflows/surface-drift.yml`` runs on every PR that
touches the registries OR ``surface.json``. Fails with a one-line
``forge surface emit --out surface.json && git add surface.json``
fix-up command when drift is detected.

### Tests

13 new tests in ``tests/test_surface_export.py``:

- artifact shape + every-tool-has-schema-version
- content-addressed property (deterministic modulo timestamp)
- registry parity (legacy_endpoint_map targets exist; no overlap)
- diff_surfaces correctness (added/removed/schema-changed)

Total: 1081 passed / 2 skipped (was 1068).

## v0.11.1 — 2026-05-05 agent-feedback patch batch + repo hygiene

Four targeted signal-cleanup fixes filed by an external agent session
that exercised the v0.10.0 / v0.11.0 MCP surface end-to-end, plus a
public-vs-private doc separation pass before the next push. Cosmetic
in surface, correctness in substance — every changed signal is one
fewer false-positive an agent has to learn to ignore.

- **`certify` / `count_untiered_source_files`** —
  ``a0_qk_constants/lang_extensions.py`` adds ``NON_TIER_SOURCE_DIRS``
  (``tests``, ``test``, ``scripts``, ``examples``, ``benchmarks``,
  ``bench``). ``a1_at_functions/certify_checks.py`` excludes paths
  with any segment in that set from the untiered count. Test files are
  real Python but conventionally outside the a0..a4 production surface;
  counting them produced ~50% false-positive untiered_source_count
  (37/76 on cognition, 95/137 on forge itself). Score unchanged at 100;
  signal cleaned. Tests in ``tests/test_ignore_and_docs.py``.
- **`verify` → `suggested_recipe`** —
  ``a3_og_features/verify_umbrella.py`` adds a ``suggested_recipe``
  field to every response. Maps the dominant failing axis
  (``wire_clean``, ``tests_pass``, ``ci_workflow``, ``tier_layout``,
  …) to a canonical golden-path recipe (``fix_wire_violation``,
  ``fix_test_detection``, ``release_hardening``, ``add_feature``, …).
  ``None`` when verdict is PASS. Drift-guarded by
  ``test_every_mapped_recipe_resolves_in_recipes_module``.
- **`smell_scan` headline number is now defensible** —
  ``a1_at_functions/smell_scan.py`` replaces the always-zero
  ``100 - (2*cc + long + 3*dup)`` formula with a density-based one:
  ``score = clamp(0, 100, 100 - (weighted/max(50, function_count)) * 50)``.
  On forge itself, ``smell_score`` went from ``0.0`` (useless) to
  ``78.2`` (interpretable: clean codebase with known hotspots). Adds
  ``smell_score_components`` to the response so the formula is visible
  to callers. Tests in ``tests/test_smell_score_formula.py``.
- **`docs/TOOL_FACTORY_WALKTHROUGH.md`** — new walkthrough doc covering
  the plan→review→apply loop for adding MCP tools via
  ``tool_factory``. Strategic for the "Forge eats Forge" demo arc.

### Repo hygiene (public vs private boundary)

Pre-push cleanup of the public surface to match the ASS-ADE
public/private discipline. The following moved out of the tracked
public repo:

- `LAUNCH_CHECKLIST.md` → `_private/LAUNCH_CHECKLIST.md` (gitignored)
- `COMPETITIVE_AUDIT.md` → `_private/COMPETITIVE_AUDIT.md` (gitignored)
- agent-session feedback → `_private/FORGE_FEEDBACK.md` (gitignored)
- `DEMO_SCRIPT.md` → moved out of the repo entirely to
  `outreach/demo/forge_DEMO_SCRIPT.md` (lives next to the live demo
  cheat sheet + bat scripts)

`_private/` is in `.gitignore`; these files remain on disk for the
maintainer but never enter git history.

### Versions

- `pyproject.toml` and `src/atomadic_forge/__init__.py` both at
  ``0.11.1`` (the ``__init__.py`` line was lagging at ``0.10.0`` —
  drift fixed). Future version bumps should touch both in one commit.

Tests: 1068 / 2 skipped (was 1063 + 5 new).

## v0.11.0 — 2026-05-05 polyglot expansion + CLI parity for Round-4/5 verbs

Two threads land in this release: a polyglot scope expansion that lets
Forge harvest Swift / Kotlin / Go / `.mts` / `.cts` source alongside the
existing Python / JavaScript / TypeScript triad, and CLI parity for the
Round-4 / Round-5 cross-repo + guard verbs that were previously MCP-only.

### Polyglot expansion (commit 980dcfe)

- `a0/lang_extensions.py` — added `SWIFT_EXTS = {.swift}`,
  `KOTLIN_EXTS = {.kt, .kts}`, `GO_EXTS = {.go}`. Extended
  `TYPESCRIPT_EXTS` with `.mts` and `.cts` so modern TS module files
  are no longer dropped. `LANG_OF_EXT` and `ALL_SOURCE_EXTS` inherit
  the additions automatically.
- `a1/scout_walk.py` — new `_harvest_polyglot_file()` for the languages
  that don't yet have a tier-specific parser. Each file becomes one
  `module`-kind symbol with a path-derived `tier_guess` (canonical
  `aN_*` directory > `sources/src` > `tests/test` > `a3` fallback)
  and conservative `state` default effects. `harvest_repo` dispatch
  + counters extended; `language_distribution` now exposes
  `swift / kotlin / go` alongside the existing trio.
- New return fields: `swift_file_count`, `kotlin_file_count`,
  `go_file_count`. Existing fields preserved exactly.
- 18 new tests (`tests/test_polyglot_swift_kotlin_go.py`); full suite
  1048 passed + 2 skipped (was 1030 + 2). Zero regressions.
- Live ingest verification on OpenClaw (~15K files):
  primary_language `typescript`, 33,034 symbols, distribution
  `typescript: 11,824 · swift: 621 · javascript: 166 · kotlin: 144 ·
  go: 27 · python: 10` — load-bearing files Forge previously skipped
  now surface end-to-end.

Symbol-level extraction (functions / classes / structs) for the new
languages stays a Phase 2 step; this release unblocks file- and
module-level workflows for absorption pipelines.

### CLI parity for Round-4 / Round-5 verbs

- `a4/cli.py` `_register_specialty_apps()` now wires four MCP-only
  tools as CLI verbs so demo paths and shell users hit the same
  handlers:
  - `recon_swarm` (Round-4: walk N repos, return unified scout)
  - `harvest` (Round-4: cross-repo capability gap finder, τ_TRUST gated)
  - `emergent_swarm` (Round-5: cross-repo emergent composition discovery)
  - `guard_install` (Round-5: install four-layer architectural guard)

### Tool surface

40 tools (unchanged from v0.10.0). The polyglot work is internal to
`recon` / `wire` / `certify` / `emergent_scan` / `harvest` etc. — no
new tools added, no tools removed.

### Verdict

PASS — evidence: 1048/1048 tests, live OpenClaw harvest independently
confirms the new file counts, monadic law respected, IP boundary intact
in cognition consumer (no codex names introduced in the polyglot path).

---

## v0.10.0 — 2026-05-04 surface consolidation (47 → 40 tools)

The "merge synthesis and cut" release. After v0.9.0 closed the
token-friction loop, the user asked for a sharper tool surface:
fewer overlapping verbs, no capability loss. This release merges
11 prior tool entries into 4 unified ones plus 2 fold operations.

### Merged

- **`lineage`** (new) — replaces `audit_list` + `why_did_this_change`
  + `what_failed_last_time`. Auto-detects `mode` from args:
  `file=...` → `by_file`, `area=...` → `failed_for_area`, else `all`.
  Schema version: `atomadic-forge.lineage/v1` (the underlying
  delegated tools still tag their own schema versions on the
  response body, preserving downstream compatibility).
- **`recipes`** (new) — replaces `list_recipes` + `get_recipe`.
  No `name` arg → catalogue summary; with `name` → full recipe body.
  Schema: `atomadic-forge.recipes/v1`.
- **`plan`** (new) — replaces `auto_plan` + `adapt_plan`. Passing
  a `plan` dict routes to the adapt path; otherwise generates a
  fresh plan via auto_plan, optionally chained with adapt via
  `capability_filter`. Schema: `atomadic-forge.agent_plan/v1`.
- **`plan_apply`** (new) — replaces `auto_step` + `auto_apply`.
  Passing `card_id` applies one card; omitting it applies all-
  applyable cards. Schema: `atomadic-forge.plan_apply/v1`.

### Folded

- **`doctor`** absorbs `worktree_status` via the new
  `include_worktree=true` arg.
- **`verify`** absorbs `exported_api_check` via the new
  `check_exports=true` arg (with `source` or `path` argument).

### Removed (folded — ZERO capability loss)

`audit_list`, `why_did_this_change`, `what_failed_last_time`,
`list_recipes`, `get_recipe`, `auto_plan`, `adapt_plan`,
`auto_step`, `auto_apply`, `worktree_status`, `exported_api_check`.

The CLI verbs and the underlying a1/a3 implementations are
retained — only the MCP surface entries collapsed. Any agent
using the old MCP names must migrate per the table above.

### Validation

- pytest: **1030 passed**, 2 skipped, 0 failed
- ruff: clean
- forge wire: 0 violations
- TOOLS count: **40** (was 47)
- backward-compat path: dispatcher delegation — every new merged
  tool calls the existing `_tool_*` impl, so behavior is unchanged

### Why this matters for the buyer/agent UX

47 tools was too many: agents (and humans) felt choice paralysis,
and three "lineage flavors" + two "plan flavors" + two "apply
flavors" added cognitive overhead with no gain. The merged tools
expose intent directly through a single primary verb whose mode
is inferred from the args you'd already pass. The smaller surface
also reduces tools/list payload size — a recurring tax on every
MCP cold-start.

### Migration cheat sheet (old → new)

| Old MCP name | New call |
|---|---|
| `audit_list` | `lineage` (no args) |
| `why_did_this_change {file: "src/x.py"}` | `lineage {file: "src/x.py"}` |
| `what_failed_last_time {area: "auth"}` | `lineage {area: "auth"}` |
| `list_recipes` | `recipes` |
| `get_recipe {name: "release_check"}` | `recipes {name: "release_check"}` |
| `auto_plan {target: "."}` | `plan {target: "."}` |
| `adapt_plan {plan, agent_capabilities}` | `plan {plan, agent_capabilities}` |
| `auto_step {card_id}` | `plan_apply {card_id}` |
| `auto_apply` | `plan_apply` |
| `worktree_status` | `doctor {include_worktree: true}` |
| `exported_api_check {source}` | `verify {check_exports: true, source}` |

---

## v0.9.0 — 2026-05-05 token-reduction sprint (close 6 of 8 frictions)

Honest-reflection release. After v0.8.0 shipped 17 new MCP tools, I
audited the session for repetitive patterns: ~46,000 tokens of pure
boilerplate / re-reading / hand-narration across the session. This
release closes 6 of the 8 friction categories with small CNA-pure
additions. Remaining waste per session drops from ~46k tokens to
~15k; the ~36k saved compounds every future session.

### Added

- **`forge_locate` MCP tool** (a1) — returns just the file path +
  line range + 5-line preview for any well-known forge insertion
  point (tools_dict, all_export, register_block, mcp_server_imports,
  test_pinned_set). Saves ~12k tokens per session vs re-reading the
  full mcp_protocol.py / mcp_server.py files. Pure analytical,
  sub-second. (Closes friction F-2.)

- **`commit_compose` MCP tool** (a3) — accepts intent + commit_type
  + optional body, runs `git diff --numstat HEAD`, emits a structured
  commit body with files-changed list, +/- line totals, and the
  co-author trailer. Drops commit-message token cost from ~1500
  hand-typed tokens to ~150 spec tokens. (Closes friction F-5.)

- **`a0/schema_version_registry.py`** — canonical SCHEMA_VERSIONS
  dict mapping `tool_name` → `schema_version_str`. 47 entries (full
  TOOLS surface registered). `schema_version_for(name)` raises
  KeyError on unknown names; new tool without a registry entry is a
  CI failure via `test_schema_version_registry_covers_every_tool`.
  (Closes friction F-6.)

- **`tools_snapshot.json` + auto-derived pinned-tools test** —
  `test_pinned_tools_snapshot_matches_tools_dict` diffs
  `set(TOOLS.keys())` against the snapshot file. Auto-bootstraps;
  CI fails on drift with a regenerate command in the error message.
  Zero manual maintenance going forward. (Closes friction F-3.)

- **`tool_factory(apply=True)` mode** (was added in v0.8.0 commit
  `716ead8`, surfaced here for the changelog) — auto-applies the
  scaffold inserts to mcp_protocol.py + mcp_server.py +
  test_mcp_protocol.py. Idempotent. Saves ~5–6k tokens per
  substantial session. (Closes friction F-1.)

### Validation

- pytest: **1031 passed**, 2 skipped, 0 failed (was 1029)
- ruff: clean
- forge wire: 0 violations
- forge certify: 100/100 PASS
- TOOLS count: **47** (was 46)

### Token-saving estimate (recurring per session)

| Friction | Pre-fix waste | Status |
|---|---|---|
| F-1 boilerplate dance | ~6,000 | ✅ FIXED |
| F-2 re-reading large files | ~12,000 | ✅ FIXED (NEW) |
| F-3 pinned-tools drift | ~600 | ✅ FIXED (NEW) |
| F-4 ruff/pytest cycle | ~6,000 | ⏳ Behavioral (Makefile.forge) |
| F-5 long commit messages | ~12,000 | ✅ FIXED (NEW) |
| F-6 schema version drift | ~200 | ✅ FIXED (NEW) |
| F-7 doc dual-maintenance | ~1,500 | ⏳ Behavioral |
| F-8 todo reminders | ~7,500 | ⏳ Out of scope |

After this release: ~36k tokens saved per substantial session,
recurring. ~$0.15/session in API cost — but more importantly that's
36k tokens reinvested in actual capability development every time.

### Notes

The remaining frictions (F-4, F-7, F-8) are behavioral or system-
side; the tooling fix has shipped (Makefile.forge, source-of-truth
notes), the burden is to actually use them consistently.

The next permanent token-reduction layer is **atomadic-lang's
`Φ_tri = 46/43` triality compression** — 4× fewer tokens at the
LLM-call boundary, codex-anchored. Until lang ships, the sprint
above is the practical bridge.

---

## v0.8.0 — 2026-05-05 substrate-position release (R3.5 + R4 + R5 + harvest)

The biggest single release in forge's history. 17 new MCP tools live;
989 → 1028 tests; certify 100/100 throughout. **Spaghetti can never
silently come back** after `guard_install --apply`. Investor packet
shipped (WHITEPAPER + PITCH + DEMO_SCRIPT + COMPETITIVE_AUDIT +
RESEARCH_BREAKTHROUGH + Receipt v1 dogfood artifact).

### Added — agent-driven LLM loop substrate

- `iterate_start` / `iterate_continue` — agent-driven sessions.
  Forge holds ZERO LLM clients; the calling agent drives its own
  LLM and calls forge between turns. Substrate-boundary contract
  test asserts call count stays at zero.
- `evolve_start` / `evolve_step` — recursive iterate, D_max=23
  bounded. Halts on convergence, stagnation, or regression.

### Added — cross-repo intelligence

- `recon_swarm` — D_max-bounded portfolio walk; OMEGA_0 invariant
  per scan.
- `harvest` (renamed from `cherry_hunt` after research) — τ_trust =
  1820/1823 Lean-4-verified gating. Conservative by default.
- `emergent_swarm` — cross-repo emergent composition discovery.
  Cycle 2 sharpening: chain edges cross-validated against
  `call_graph`; corroborated edges tagged `static_call_confirmed`
  per SOTA Codebase-Memory MCP / SemanticForge multi-pass
  reconciliation patterns.

### Added — composite gates and the standing immune system

- `verify` — composite go/no-go gate. wire + certify (always-on)
  + score_patch + preflight_change (optional). Single
  PASS/REFINE/FAIL verdict. Direct competitive answer to Qodo's
  PR-time verification loop.
- `cna_check` — hardwired Compose-Not-Add gate. intent_similarity
  + code_signature + dedup_engine. PASS/REFINE/REJECT.
- `guard_install` — four-layer architectural immune system in one
  MCP call: pre-commit hook + GitHub Action + pyproject contract
  + CONTRIBUTING block. **After this runs, agents/LLMs/humans
  cannot silently regress structural integrity.**

### Added — code intelligence (harvested from competitors)

- `call_graph` — caller/callee BFS; `__init__.py` re-export
  canonicalization. Harvested from Code Pathfinder.
- `smell_scan` — cyclomatic complexity + long-function +
  duplicated-body. Harvested from Sonar.

### Added — meta and infrastructure

- `tool_factory` — meta-tool that scaffolds new MCP tools from a
  spec. **Forge eats forge.**
- Sovereign-invariants module (`a0/mhed_invariants.py`):
  Lean-4-verified `D_MAX_DELEGATION = 23`, `TAU_TRUST ≈ 0.998354`,
  `OMEGA_0 ≡ 0`, `PHI_ANCHOR = 137`, `PHI_TRI = 46/43`. Self-asserts
  at import.
- `Makefile.forge` — `make -f Makefile.forge ship-check` chains
  ruff + pytest + wire + certify.

### Added — investor packet

- `WHITEPAPER.md` v0.1 — ~3000 words. Market thesis, wedge, five
  killer capabilities, sovereign-invariant moat, live demo metrics
  (real reproducible numbers), Year 1 floor / Year 3 base /
  Year 5 substrate revenue trajectory, funding ask: **$2M
  pre-seed @ $12M cap**.
- `PITCH.md` — 1-page cold-outreach version.
- `DEMO_SCRIPT.md` — 7 reproducible terminal demos.
- `COMPETITIVE_AUDIT.md` — capability matrix vs Code Pathfinder,
  Moderne, Augment, Sourcegraph, Qodo, Sonar.
- `RESEARCH_BREAKTHROUGH.md` — 3-round web-research log.
- `receipts/forge-self-2026-05-05.json` — real Receipt v1 dogfood
  artifact (forge certifies itself 100/100 PASS).

### Changed (substrate hardening)

- `cherry_hunt` → `harvest` rename (Git-namespace SEO collision).
- `dispatch_request` exception clause broadened to `Exception`.
  Eliminates `-32000 Connection closed` for any signature drift.
- Explicit `_json_default` at MCP wire (replaces `default=str`).
  Round-trips set/frozenset/bytes/Path/dataclass.
- `score_patch` returns REFINE on no-chunks input (was silent PASS).
- `_build_dest_path` Windows backslash normalization.
- `dedup_engine` no longer double-walks.
- `call_graph` `__init__.py` re-export canonicalization.

### Validation

- pytest: **1028 passed**, 2 skipped, 0 failed
- ruff: clean
- forge wire: 0 violations
- forge certify: **100/100 PASS**
- TOOLS count: **46** (was 29 in v0.7.x)

### Known follow-ups (v0.9.x)

- Semantic NL search (embedding model boundary design)
- Three-phase reconciliation Phase 3 (LSP type signatures)
- `self_evolve` recursive forge-on-forge loop
- emergent_swarm against the lang stress-test merge corpus

---

## Unreleased — 2026-05-04 Round 2 MCP bridge: transmuter pipeline exposed

Exposed 5 CLI verbs as MCP tools (`auto`, `cherry`, `finalize`, `iterate`,
`evolve`). Forge's full transmuter pipeline is now agent-callable from any
MCP-aware AI coding tool (Cursor, Claude Code, Aider, Devin, and any
custom MCP client).

### Added

- **`auto` MCP tool** — the flagship single-shot pipeline (scout → cherry
  → assimilate → wire → certify) as a single agent-callable tool.
  Signature: `target`, `output`, `package`, `apply`, `on_conflict`.
  Returns `atomadic-forge.auto/v1`.
- **`cherry` MCP tool** — cherry-pick manifest from a scouted repo.
  Surgical control over which symbols get imported before assimilation.
  Signature: `target`, `names`, `pick_all`, `only_tier`.
- **`finalize` MCP tool** — materialize a cherry-pick manifest into a
  tier-organized output package, then wire and certify.
  Signature: `target`, `output`, `package`, `cherry_manifest`, `apply`,
  `on_conflict`. Returns `atomadic-forge.assimilate/v1`.
- **`iterate` MCP tool** — LLM ↔ Forge loop: intent → code →
  tier-enforce → score → iterate until certify >= target_score.
  Signature: `intent`, `output`, `package`, `seed_repo`,
  `max_iterations`, `max_fix_rounds`, `target_score`, `apply`,
  `language`. Returns `atomadic-forge.iterate/v1`.
- **`evolve` MCP tool** — recursive iterate; the growing package becomes
  the seed for the next round so the LLM sees richer compositional
  context each time. Halts on convergence, regression, stagnation, or
  rounds cap. Signature: `intent`, `output`, `package`, `seed_repo`,
  `rounds`, `iterations_per_round`, `target_score`,
  `stop_on_regression`, `stagnation_threshold`, `language`. Returns
  `atomadic-forge.evolve/v1`.
- Total MCP tool count: **34** (was 29).

### Docs updated

- `README.md` — "From spaghetti to shippable in one MCP call" headline
  section; updated tool count to 34.
- `docs/AGENTS_GUIDE.md` — "The transmuter" section with trigger map,
  argument shapes, and four-tier integration ladder.
- `docs/COMMANDS.md` — MCP equivalents table for all five pipeline tools,
  including return schemas.
- `docs/01-getting-started.md` — "From any repo to shippable in one call"
  MCP example section.
- `docs/04-llm-loops.md` — "MCP tool usage" section for `iterate` and
  `evolve` with full parameter reference.

---

## Unreleased — 2026-05-04 field-report fixes + MCP registry hardening

### Fixed

- **`enforce` destination path** — the absorb pipeline now correctly nests
  emitted files under `src/<pkg>/aN_*/` instead of `<pkg>/aN_*/` when the
  output directory has an `src/` wrapper. Fixes the most-reported field
  report from teams absorbing into an existing `src/` layout.
- **`dedup` defensive caps** — `dedup_engine` now enforces
  `DEDUP_MAX_FILES = 5000` and `DEDUP_MAX_DUPLICATES_PER_GROUP = 64` to
  prevent unbounded corpus walks on very large monorepos. The truncated
  result is flagged with a `"max_files cap reached"` note so callers know
  to scope down or raise the cap.
- **pytest parser regression** — test-detection in `certify` no longer
  misclassifies parametrized `@pytest.mark.*` test stubs as non-test code.
  Covered by new regression tests.

### Improved

- **29 "Use this when:" trigger prefixes** — every tool in the MCP
  `TOOLS` registry now starts with a one-line `"Use this when: …"` phrase
  so agent tool-selection systems can pick the right tool without reading
  the full description. Applies to all 29 tools: `recon`, `wire`,
  `certify`, `enforce`, `audit_list`, `auto_plan`, `auto_step`,
  `auto_apply`, `context_pack`, `preflight_change`, `score_patch`,
  `select_tests`, `rollback_plan`, `explain_repo`, `adapt_plan`,
  `compose_tools`, `load_policy`, `why_did_this_change`,
  `what_failed_last_time`, `list_recipes`, `get_recipe`,
  `worktree_status`, `trust_gate_response`, `exported_api_check`,
  `emergent_scan`, `synergy_scan`, `doctor`, `sidecar_validate`,
  `manifest_diff`.

### Coming next (Round 1 hardening — landing now)

- Broader dispatcher `except` clause to prevent raw Python tracebacks
  from escaping the MCP boundary on unexpected error types.
- Explicit JSON serializer for non-serializable MCP tool results.
- `score_patch` returns `REFINE` (not `PASS`) on empty or malformed diff
  input.
- `dedup` double-walk fix — the corpus walker no longer counts the same
  path twice when symlinks resolve to the same inode.
- Backslash path normalization — Windows paths from `worktree_status` are
  now forward-slash normalized before being returned to MCP clients.
- Contract tests covering all five fixes above.

---

## 0.7.0 — Pricing v4 + Founder's Pack live

Forge Standard's monetization layer goes live. Two-product roadmap (Standard
mature + Deluxe in active development) is published; only Standard is sold
today, Deluxe holds until its catalog has real exclusive tools.

### Added

- **Forge Standard tier ladder** — Free / Basic $19 / Dev $39 / Pro $99/user /
  Enterprise (from $2,500/mo). Yearly billing saves 2 months.
- **Atomadic Lifetime Founder** — $999 one-time, first 25 only. Lifetime Forge
  Standard Pro + Lifetime AAAA-Nexus Pro + Lifetime Forge Deluxe (when launched)
  + every future Atomadic product. Numbered master keys F001–F025.
- **Prepaid call packs** — $25 / $100 / $500 / $2,500 with up to 50% bonus
  credits for higher tiers; subscribers get an additional 25% off.
- **x402 PAYMENT-REQUIRED** on `forge.atomadic.tech/mcp` — pay-per-call
  pricing per tool class ($0.001 reads → $0.25 mutating).
- **`forge-auth-worker`** — `checkout.session.completed` webhook now mints
  numbered master keys for Founder's Pack purchases and credits buyers'
  ledgers for credit-pack purchases.
- **Site surfaces** — new `/pricing` page (5-tier ladder + Founder's Pack +
  prepaid packs), `/subscribe` redirects to `/pricing`, `/account` shows
  Founder badge + dual MCP config snippets (hosted HTTP + local stdio).
- **`COMMERCIAL_LICENSE.md`** — explicit BSL→commercial conversion paths
  for procurement teams.
- **Plan type expansion** in `forge-auth-worker` — added v4 plan names
  (`basic`, `dev`, `pro`) and `forge_founder_lifetime` to ForgePlan + the
  KNOWN_PLANS allow-list. Legacy v1 plans (`starter`, `founding`,
  `professional`, `enterprise`) remain valid for existing customers.

### Status

- Forge **Deluxe** subscription tier and `/deluxe/mcp` are *live but not
  publicly listed* — endpoint works for Founder keys (alpha access), public
  pricing page does not advertise it. Listing waits until Deluxe has 5+
  exclusive tools beyond Standard.

## Unreleased

### Added

- `forge worktree status` and MCP `worktree_status` give agents a
  pre-edit checkout report: git root, branch, upstream drift, dirty
  files, remotes, version surfaces, resolved `forge` command, stale
  install detection, and concrete recommendations.

### Improved

- `context-pack` accepts `--focus`, `--intent`, and repeatable
  `--file` arguments. Targeted packs add file context, preflight
  results, selected tests, and concrete next-step suggestions while
  preserving the original first-call orientation fields.
- MCP `context_pack` accepts the same `focus`, `intent`, and `files`
  arguments as the CLI.
- `tools/list` now reports Forge version and server source path so
  agents can diagnose stale MCP hosts without guessing.
- `forge mcp doctor` now includes Python executable, resolved
  `forge` command path, source module paths, and a recommended
  `python -m atomadic_forge mcp serve` config.
- `forge explain-repo` now computes repo purpose/scout/wire/certify
  context before calling the a1 explainer, matching the MCP path.
- Recipe listing JSON now includes `recipe_count`, and the human CLI
  list no longer truncates descriptions.
- Synced `atomadic_forge.__version__` and README current-version
  snippets with the published `0.6.1` package metadata.

---

## 0.6.1 - MCP registry publication metadata

Patch release for MCP registry publication metadata. The package
version is `0.6.1`; source docs and runtime version surfaces should
report the same line.

---

## 0.6.0 - Frontier features: dedup, budget, memory, swarm hiring, Ling-2.6-1T

Major minor — five new capabilities cherry-picked from forge-deluxe-seed
plus a frontier free-tier LLM, plus three MCP bug fixes and agent-optimized
certify output.

### Added — capabilities

- **`dedup_engine`** — orchestrates `intent_similarity` + `code_signature`
  + `research_note_distiller` to catch duplicate research notes AND
  duplicate code logic at the gate. The "never reinvent the wheel"
  primitive, ported with 13 tests.

- **`cost_circuit_breaker`** — multi-tier (per-task / per-session /
  per-day) USD + token budget with hard-kill, soft-warn-at-80%, and
  no-progress stuck detection. Defaults match OpenHands
  (MAX_ITERATIONS=100, $100/day). Closes the production-incident gap
  ($47k loop, $30k loop) called out in cycle-14 SOTA research.

- **`hierarchical_memory`** — 4-tier MemGPT pattern (M0 working /
  M1 core pinned / M2 episodic / M3 reflection) with Park-2023
  recency × importance × relevance scoring. Pure stdlib sqlite3 —
  air-gappable.

- **`agent_hire_protocol`** — 5-step swarm SOP (sealed-probe vetting
  → trust gate → similarity check → contract → signed receipt) with
  D_max=3 (ChatDev empirical limit) for safe multi-agent fanout.

- **`ling` / `--provider ling`** — wires Ling-2.6-1T (1T-param MoE,
  262K context, SOTA SWE-bench) via OpenRouter at the **free tier**.
  Forge users now get a frontier model for iterate/evolve at zero
  cost; OpenRouter default model also bumped from gemma-3-27b-it
  to ling-2.6-1t.

### Fixed

### Fixed

- **P0 (critical)** `recon` MCP tool no longer overflows LLM context
  windows. `symbols[]` (771 K chars on forge itself) is stripped from
  the default response; pass `verbose: true` to get the full walk.
  `symbol_count` remains so agents still see cardinality inline.

- **P1 (high)** `certify` behavioral score no longer reports `ran:
  false, pass_ratio: 0.0` on repos using `xfailed`/`xpassed` pytest
  status words. The `_parse_pytest_summary` parser now uses independent
  per-metric regex patterns instead of a single monolithic regex that
  choked on unknown status words between "passed" and "in Xs".
  Atomadic-Lang's certify score recovers from 70 to 100.

- **P2 (high)** `auto_plan` verdict no longer reports `PASS` for repos
  with score < 75 and no action cards. `not cards` alone was treated as
  PASS regardless of score; now requires `score >= 75`. No-input plans
  (score defaults to 0.0) correctly return `FAIL`.

### Added — certify polish

- `certify` output now includes `health_summary` (score + verdict +
  blockers + scan_duration_ms) — a single at-a-glance block for agent
  loops that don't want to parse the full response.

- `certify` output now includes `axes` dict with per-axis `ok` bool and
  `how_to_fix` string. When an axis fails, agents get an explicit action
  ("Add README.md at the project root." / "Run forge wire src
  --suggest-repairs -- N violation(s).") instead of just a flag.

- `certify` now reports `scan_duration_ms` at top level and inside
  `health_summary` — agents doing performance budgeting can use this
  for timeout planning.

- New recipe `bump_version` — checklist for patch/minor/major bumps:
  edit pyproject.toml, update __version__, write CHANGELOG entry,
  certify, commit, tag.

- New recipe `fix_test_detection` — debugging guide for when certify
  reports `ran=false` or `pass_ratio=0` despite pytest passing locally:
  traces xfailed parse failure, wrong-package import filter, and import
  smoke failure paths.

### Internal

- CI Ruff lint debt cleared: 50 errors → 0 across recent merges
  (I001/F401/UP037/UP006/UP035 auto-fixed; UP038/B006/E701/E702/F841
  manually). Lint now blocks regressions instead of being permanently red.

- Test count: 937 → 975 (+38) — every new capability shipped with
  pinning tests; certify holds 100.0/100 across the lift.

- README provider matrix updated: Anthropic default → `claude-sonnet-4-6`,
  OpenAI default → `gpt-4o-mini` (with override hints), `ling` row added.

- Live demo (`forge.atomadic.tech`) and invest links surfaced in README.

---

## 0.5.3 - Documentation metadata sync

Small follow-up to `0.5.2` so the published package description and
current-facing docs no longer advertise stale `0.3.x` version strings,
old test counts, or the pre-`0.5.2` MCP tool count.

### Fixed

- README install and contributor snippets now show the current Forge
  version family and `937 passed, 2 skipped`.
- Current ecosystem positioning now reflects the `0.5.3` PyPI line and
  23-tool MCP surface.
- First-run and VS Code extension docs now reference the current MCP
  surface/version expectations.

---

## 0.5.2 - Agent ergonomics and language-aware guidance

Implements the first round of quality-of-life improvements from the
Forge agent review. This release makes Forge friendlier when an agent
uses it on JavaScript repos, documentation/research patches, or live
MCP connections.

### Added

- `forge mcp doctor` smoke-tests MCP stdio with framed `initialize`,
  `tools/list`, and `shutdown` requests. It reports version, project
  root, tool count, framed-stdio status, server exit code, and a
  recovery hint.
- `tools/list` entries now include a `cli_command` fallback so agents
  can switch from MCP to shell without guessing command names.
- Shared validation heuristics now detect `package.json` scripts,
  JS/TS tests, tier roots, and release-gate commands.

### Improved

- `context-pack` prefers `npm run verify` / `npm test` for JavaScript
  projects and derives `forge wire` gates from real tier roots.
- `preflight` recognizes non-code artifacts such as `docs/`,
  `research/`, `.github/`, and `cognition/guides/` as valid project
  memory instead of misplaced source.
- `select-tests` discovers JS/TS test files and avoids mirror pytest
  requirements for documentation-only changes.
- `score-patch` no longer treats docs/research-only diffs as code
  changes without tests, and emits language-aware validation commands
  when a project root is provided.
- `compose-tools verify_patch` now maps to
  `score_patch -> select_tests -> wire -> certify`.
- Hidden worktrees, experiment directories, build output, and
  `node_modules` are skipped when deriving release-gate wire roots.

### Tests

- Added regression tests for JavaScript validation selection,
  non-code artifact preflight, docs-only patch scoring, exact
  `verify_patch` recipe matching, MCP CLI fallback metadata, and
  `forge mcp doctor`.

---

## 0.5.1 — MCP stdio framing compatibility

Fixes `forge mcp serve` for MCP hosts that use LSP-style
`Content-Length` framing over stdio instead of newline-delimited JSON.
Modern Codex / VS Code MCP bridges can spawn the server, list tools,
and then send framed `tools/call` requests; before this patch Forge
could misread the frame header as JSON and leave the host waiting until
its tool-call timeout.

### Fixed

- `forge mcp serve` now accepts both newline-delimited JSON-RPC and
  `Content-Length` framed JSON-RPC on stdin.
- MCP responses are written in the same framing style as the request
  that triggered them, preserving compatibility with shell smoke tests
  and stricter MCP clients.
- The dispatcher now treats both `notifications/initialized` and
  `initialized` as no-response initialization notifications.
- The VS Code extension manifest version now tracks the `0.5.1`
  package release.

### Tests

- Added a framed stdio regression test for initialize → initialized →
  ping → shutdown.
- Verified framed `tools/call list_recipes` against the real
  `forge mcp serve` command.

---

## 0.3.5 — Copilot's Copilot CLI parity + GUI version sync

The MCP exposes 21 tools. Until 0.3.5, only 12 of them had CLI
front-doors — the other 9 were JSON-RPC-only, which meant a developer
or agent shell-running `forge` couldn't sample the same intelligence
without spawning the MCP server, speaking JSON-RPC, and parsing
`content[0].text`. This release closes the gap.

### Added — 9 new top-level CLI verbs

Every MCP-only Codex tool now has a CLI sibling that prints JSON to
stdout, suitable for piping into `jq`, scripts, or an agent's Bash
subprocess:

| Verb | Codex # | What it does |
|---|---|---|
| `forge explain-repo <root>` | #6 | Humane operational orientation: one-liner + core flow + do_not_break list + important tests + release state |
| `forge score-patch [--file diff.patch]` | #3 | Patch risk scorer: arch / test / public-API / release risk + needs_human_review boolean |
| `forge select-tests <intent> --file ... --file ...` | #7 | Minimum + full-confidence test sets per intent; mirror-name matches plus tier-mate tests |
| `forge rollback-plan --file ... --file ...` | #11 | Structured undo plan: files to remove, caches to clean, docs to restore, tests to rerun, risk level |
| `forge compose-tools <goal>` | #9 | Tool-use planner: keyword → ordered MCP tool sequence (orient / release_check / fix_violation / before_edit / verify_patch) |
| `forge why-did-this-change <file>` | #5 | Agent memory: every lineage entry + plan event that touched the file |
| `forge what-failed-last-time <area>` | #5 | Failed / rolled-back plan events matching an area substring |
| `forge adapt-plan --cap apply --cap shell` | #8 | Capability-aware card filtering: tag each card with recommended_handling |
| `forge load-policy <root>` | #10 | Read `[tool.forge.agent]` from pyproject.toml (protected_files / release_gate / max_files_per_patch / require_human_review_for) |

All verbs default to JSON output. None mutate the repo.

### Why this matters for agents

Before 0.3.5, an agent that wanted to compose a release-check tool
chain had to either spawn `forge mcp serve`, hand-craft a tools/call
JSON-RPC envelope, send it over stdio, and parse the wrapped text
content — or skip the intelligence entirely. After 0.3.5, the same
agent runs:

```bash
forge compose-tools "release_check" | jq .steps
forge select-tests "fix(api): rate limit" --file src/api/limit.py
forge score-patch --file my.diff
```

Three Bash calls. Same data. Zero JSON-RPC.

### GUI version sync

`forge-web` PWA + `forge-studio` Tauri both pull their version label
from `forge-ui-core`'s `ForgeShell.tsx` default. That default was
still pinned to `0.3.2`. Now `0.3.5` so both shells correctly identify
themselves at the bottom of the sidebar.

### Tests

902 passing, 2 skipped (no test changes — every new verb is a thin
wrapper around an already-tested a1 function).
`forge wire src/atomadic_forge` PASS, `forge certify .` holds at
**100/100**.

---

## 0.3.4 — `forge whoami` for agents and humans

Adds the agent-empowerment QOL win that 0.3.3 was missing: when the
MCP gate refuses with `subscription required`, agents (and humans)
need a cheap way to ask **"who is the gate seeing me as, and from
which source?"** without burning a real tool call. `forge whoami` is
that command.

### Added

- **`forge whoami`** new top-level CLI verb (and `--json` for scripted
  consumers). Returns:
  ```json
  {
    "ok": true,
    "source": "credentials_file" | "env" | "missing",
    "key_prefix": "fk_live_b3502…",
    "email": "tom@example.com",
    "plan": "pro",
    "verify_ok": true,
    "verify_reason": "",
    "credentials_path": "~/.atomadic-forge/credentials.toml",
    "env_var": "FORGE_API_KEY"
  }
  ```
  Resolution order matches the MCP gate exactly (env → credentials.toml).
  `--no-verify` skips the network roundtrip for offline triage.
- **6 new unit tests** for whoami covering missing-key, env-key,
  credentials-file-key, env-wins-over-file, --no-verify, and
  verify-rejection.

### Why this matters for agents

Before 0.3.4, an agent that hit `MCP error -32001: Forge subscription
required` had two options: ask the human to restart the MCP, or fail.
With 0.3.4 the agent can call `forge whoami --json` (via Bash) and
get a structured answer it can act on:

  * `source == "missing"` → tell the user to run `forge login`
  * `source == "credentials_file"` + `verify_ok == false` → key is
    revoked or stale; `forge login` again
  * `source == "env"` + `verify_ok == false` → CI env var is wrong
  * everything green → restart the MCP host (the running subprocess
    needs a respawn to see the new env)

This closes the loop for the auth experience — the agent can diagnose
its own failure mode.

### Tests

902 passing, 2 skipped. `forge wire src/atomadic_forge` PASS,
`forge certify .` holds at **100/100**.

---

## 0.3.3 — MCP gate reads credentials.toml + actionable error message

Hot-fix release. Closes the gap where `forge login` writes a key to
`~/.atomadic-forge/credentials.toml` but `forge mcp serve` rejects every
tool call with `Forge subscription required` because it only checks
`FORGE_API_KEY` env. After 0.3.3, `forge login` once is enough — every
MCP host (Claude Code / Cursor / Aider / Devin / VS Code Copilot) picks
the key up automatically with no shell-scoped env-var ritual.

### Added

- **`read_api_key_from_credentials_file(path)`** — pure a1 helper that
  parses `~/.atomadic-forge/credentials.toml` (the file `forge login`
  writes) and returns the `[forge_auth].api_key` value, only when it
  has the `fk_live_` prefix. Six new unit tests cover missing file,
  wrong prefix, missing section, malformed TOML, string-path argument,
  and the canonical login output.
- **MCP `_auth_check` falls back to credentials.toml** when
  `FORGE_API_KEY` is not in env. Resolution order is documented in the
  docstring: env first (CI / explicit override), then credentials file
  (one-time `forge login`).
- **Actionable auth-error message** — when neither env nor credentials
  file yields a key, the JSON-RPC error now reads
  `"Forge subscription key not configured. Run forge login once …"`
  (was: `"FORGE_API_KEY not set or wrong prefix"`).

### Tests

896 passing, 2 skipped (was 841/2 at 0.3.2 — +6 new tests for the
credentials.toml fallback). `forge wire src/atomadic_forge` PASS,
`forge certify .` holds at **100/100**.

---

## 0.3.2 — Cyberpunk Forge Studio UI + recovery fixes

841 tests passing, 2 skipped. `forge wire src/atomadic_forge` PASS,
`forge certify .` = **100/100**.

### Added

- **Forge Studio cyberpunk UI reskin** — Full visual overhaul from
  slate/blue inline-styles to the Atomadic cyber design system.
  Tailwind v4 (`@tailwindcss/vite`), `motion` (Framer Motion v12),
  `lucide-react`. New primitives: `NeonButton`, `ActionableCard`,
  `ScoreGauge`, `PipelineStepper`. Collapsible sidebar with `layoutId`
  animated active indicator, mobile bottom bar.
- **ProjectScanDashboard** — animated stat cards, wire verdict banner,
  motion tier bars, F-code violation list with severity colours.
- **All panels reskinned** — ArchitectureGraph, ComplexityHeatmap,
  DebtCounter, AgentTopologyMap, ErrorBanner all use cyber palette.
- **`forge status` verb** — shows MCP connection status.

### Fixed

- **Wire scan phantom violations** — `.pytest_tmp_run/` test fixtures
  no longer pollute wire results; `path_parts_contain_ignored_dir()`
  now used throughout.
- **`forge audit list` / `forge audit log`** — default to CWD
  (`Path(".")`) instead of requiring explicit path argument.
- **DebtCounter** — `fCodeSeverity(v.f_code)` replaces broken
  `SEVERITY_WEIGHTS[v.severity]` (was always returning weight 1).
- **WireViolation TypeScript interface** — aligned with actual JSON
  schema (`f_code`, `from_tier`, `to_tier`).
- **ArchitectureGraph** — staircase node layout instead of single column.
- **`forge doctor`** — optional dep checks (complexipy, bandit, mypy).
- **`commandsmith smoke`** — `--include-core` flag tests all 23 core verbs.

## 0.3.1 — Golden Path lanes B/C/D/F/G ship

783 tests passing, 2 skipped. `forge wire src/atomadic_forge` PASS,
`forge certify .` = **100/100**.

### Added — Golden Path lanes shipped

- **Lane B (Studio)** — Tauri + React + TypeScript visual sandbox:
  Project Scan Dashboard, Architecture Graph (Cytoscape), Cognitive
  Heatmap, Real-Time Debt Counter, Agent Topology Map. `forge-studio/`.
- **Lane C W3 (Badge worker)** — Cloudflare Worker emitting
  shields.io-compatible SVG badges from Receipts in a `FORGE_RECEIPTS`
  KV namespace. `cloudflare-workers/badge/`.
- **Lane D W8 (Sidecar grammar)** — `.forge` v1.0 spec + parser. Per-
  symbol effect / compose_with / proves declarations.
  `a1.sidecar_parser`, `docs/SIDECAR.md`.
- **Lane D W11 (Sidecar validator)** — AST cross-check of `.forge`
  against source. 7 drift classes (S0000–S0006) promoted into the
  F-code namespace as F0100–F0106. `a1.sidecar_validator`,
  `forge sidecar parse / validate`.
- **Lane D W12 (LSP)** — `forge lsp serve` Content-Length framed JSON-
  RPC server. Live diagnostics, hover, goto-source for `.forge` files.
- **Lane D W14 (VS Code extension)** — `vscode-forge-extension/`.
  Language client wired to `forge lsp serve`.
- **Lane F W16-W18 (CS-1 + compliance)** — CS-1 Conformity Statement
  renderer + EU AI Act Annex IV / SR 11-7 / FDA PCCP / CMMC-AI / NIST
  AI RMF mappings. `a1.cs1_renderer`, `forge cs1`.
- **Lane G (Signing + SBOM + policy templates)** — Ed25519 local
  signer (soft-fail without `cryptography`), CycloneDX 1.5 SBOM
  emitter, three policy stances (strict / permissive / regulated),
  `--seed-determinism` on `forge auto`. `a1.local_signer`,
  `a1.sbom_emitter`, `forge sbom`, `--local-sign` on certify.

### Codex "Copilot's Copilot" — completed

All 12 items closed: compact summaries, action cards, context_pack,
preflight_change, score_patch, plan persistence (`plan-list / plan-
show / plan-step / plan-apply`), MCP `auto_plan` tool, `--version`,
`--score` field on summaries, agent_summary/v1 + agent_plan/v1
schemas, repo_explainer, tool_composer.

## Unreleased — _Pre-audit lanes + Golden Path Lane A W0_

Five commits since `v0.3.0`. Trajectory: 643 → **702 passing**, 2
skipped (+59). `forge wire src/atomadic_forge` PASS at every commit.
`forge certify .` = 100/100 held.

### Added — Lane D W12 forge-lsp stdio LSP server (`d23005f`)

Closes Lane D W12. **Editor-agnostic LSP server** gives every client
(VS Code, Neovim, Helix, IntelliJ) live diagnostics + hover +
goto-source on `.forge` sidecar files. The Lane D arc reaches the
in-editor surface — sidecar feedback now arrives where the agent
actually edits.

- **`a1_at_functions/lsp_protocol.py`** — pure dispatcher (~280 LOC).
  `dispatch_request(req, *, state) -> (responses, notifications)`.
  In-memory `LspState` document store keyed by URI.
  - `initialize` / `initialized` / `shutdown` / `exit` — handshake +
    clean shutdown
  - `textDocument/didOpen` / `didChange` / `didSave` / `didClose` —
    document lifecycle
  - `textDocument/hover` — markdown summary of the cursor's symbol
    (effect, tier, `compose_with`, `proves`)
  - `textDocument/definition` — goto-source: `name: login` line in
    `foo.py.forge` → `foo.py:login`
  - `textDocument/publishDiagnostics` (server-initiated) — emitted
    after every did{Open,Change,Save} with the validator's findings
    promoted to F0100-F0106 codes
  Pure: bounded I/O for source-file resolution only (no LSP-side
  shell-out, no LLM call).
- **`a3_og_features/lsp_server.py`** — stdio LSP framing (~70 LOC).
  `serve_stdio(*, stdin, stdout, stderr) -> int`. Reads
  Content-Length-framed JSON-RPC, dispatches, writes responses +
  notifications back. Bad JSON surfaces `-32700` without killing the
  loop.
- **`forge lsp serve`** — sub-app verb. Docstring includes VS Code +
  Neovim `lspconfig` snippets so consumers can drop the server in
  without hunting docs.

**Tests** (+18 in `tests/test_lsp_protocol.py`): handshake (4),
diagnostics (3), hover (2), definition (2), lifecycle (3), URI
parsing (2). 702 passing / 2 skipped (was 684).

### Added — Lane D W11 follow-up: F0100-F0106 sidecar drift codes (`7099360`)

Promotes the local `S0xxx` labels emitted by `sidecar_validator` into
the **global F-code registry** so downstream tools (`forge audit` /
`agent_summary` / `score_patch` / `plan-apply`) can address sidecar
drift in the same namespace as wire violations.

- **`a0_qk_constants/error_codes.py`** registry seeds:
  | F-code | Severity | What |
  |---|---|---|
  | `F0100` | error | sidecar source unparseable |
  | `F0101` | error | sidecar declares missing symbol |
  | `F0102` | warn | sidecar coverage incomplete |
  | `F0103` | error | `Pure`-declared violates purity |
  | `F0106` | warn | sidecar tier mismatch |
- **`SIDECAR_S_TO_F`** mapping (`S0000 -> F0100`, `S0001 -> F0101`,
  …) so the validator doesn't have to know the F-code seeding
  pattern.
- `ValidationFinding` gains an optional `f_code` field. Every
  finding whose `code` is in the mapping gets the registered F-code
  attached automatically before the report returns.

Lane D W8/W11 drift codes are now **first-class F-coded errors** —
addressable, dashboard-friendly, route-able through
`forge enforce` (when an auto-fix path lands in W14).

**Tests** (+2 in `tests/test_error_codes.py`): registry pinned set
extended with F0100-F0106 by name; `SIDECAR_S_TO_F` mapping pinned;
validator dogfood test confirms a synthesized `S0001` finding
carries `f_code='F0101'`. 684 passing.

### Added — Lane D W11 sidecar cross-validator (`60c174e`)

Closes Lane D W11. The W8 spec ships the *grammar*; W11 ships the
**verifier** that catches sidecar drift by cross-checking declared
effects against the source AST.

- **`a1_at_functions/sidecar_validator.py`** — pure (~120 LOC).
  `validate_sidecar(sidecar, *, source_text, source_path) ->
  ValidationReport` (`atomadic-forge.sidecar.validate/v1`). Pure AST
  walk + sidecar dict walk; no exec, no LLM, no network. Soft on
  parse failures (returns `verdict='unparseable'` instead of
  raising).
- **5-of-7 named drift classes detected today**:
  | Code | Class | Severity |
  |---|---|---|
  | `S0000` | source did not parse | `unparseable` |
  | `S0001` | sidecar declares a symbol the source doesn't have | error |
  | `S0002` | source has an undeclared public symbol | warn (gradual coverage is OK) |
  | `S0003` | `Pure`-declared symbol violates purity (IO, network, non-determinism in source) | error |
  | `S0006` | declared `tier` mismatches detected path tier | warn |
  | `S0005` | `compose_with` name resolution | reserved (W20) |
  | `S0007` | `proves:` clauses against Lean4 corpus | reserved (W20) |
- **CLI verbs**: `forge sidecar parse <file.forge>` and
  `forge sidecar validate <source.py>` — both `--json`-friendly,
  exit 1 on FAIL. The validator auto-resolves the sibling
  `<source>.forge` via `find_sidecar_for`.

**Reserved for later in Lane D**:
- **W12** — `forge-lsp` server (in-editor sidecar diagnostics).
- **W14** — VS Code extension (hover + diagnostics surface).
- **W18** — JetBrains plugin.
- **W20** — Bao-Rompf compose-by-law checker (`S0005`) + Lean4
  `proves:` discharger (`S0007`).

**Tests** (+11 in `tests/test_sidecar_validate.py`): happy path,
S0000-S0006 unit tests, CLI parse / validate FAIL / PASS.

### Added — Lane D W8 `.forge` sidecar v1.0 (`b4ad686`)

### Added — Lane D W8 `.forge` sidecar v1.0 (`b4ad686`)

The "**TypeScript for architecture**" paradigm from BEP-1, now real.
A `.forge` sidecar is a YAML file beside any source file
(`users/auth.py.forge`) that declares the per-symbol contract Forge
would otherwise infer heuristically. **Opt-in, gradual, never
required** — adoption-curve modeled on TypeScript itself.

- **Schema** `atomadic-forge.sidecar/v1` at
  `a0_qk_constants/sidecar_schema.py` — pinned by tests, pure a0
  (imports only `__future__` + `typing`).
  - **`EffectKind`** enum (the seven-effect categorical lattice from
    Bao-Rompf 2025): `Pure`, `IO`, `NetIO`, `KeyedCache`, `Logging`,
    `Random`, `Mutation`.
  - **`SidecarSymbol`** TypedDict: `name`, `effect`, `compose_with`,
    `proves`, `tier`, `notes`.
  - **`SidecarFile`** TypedDict: `schema_version`, `target`,
    `symbols`, `extra`.
- **Parser** at `a1_at_functions/sidecar_parser.py` — pure (~140 LOC):
  - `parse_sidecar_text(text, *, source) -> ParseResult`
  - `parse_sidecar_file(path) -> ParseResult`
  - `find_sidecar_for(source_file) -> Path` — convention:
    `users/auth.py` → `users/auth.py.forge`
  - YAML errors / missing files / non-mapping top-levels become
    structured `errors` lists; **never raise**. Unknown effects
    preserved with a warning (forward-compat). Unknown top-level
    fields preserved in `extra`.
- **Spec doc** at `docs/SIDECAR.md` — v1.0 grammar + worked example
  covering `NetIO` + `Pure` + `Logging` + `compose_with` + `proves`.
- `pyyaml >= 6, < 7` added as runtime dep (parser hard-requires).

**Reserved for later in Lane D:**
- **W11** — `sidecar_validate` (cross-check declared effects against
  source AST).
- **W12** — `forge-lsp` + VS Code extension (hover + diagnostics).
- **W20** — Bao-Rompf `compose_with` checker + Lean4 `proves:`
  discharger.

This shipment lands the **"five surfaces, one Receipt"** convergence
predicted by BEP-1: terminal Card, PR comment, README badge, MCP
resource, signed CS-1 PDF — and now the per-source-file effect
signature that makes the polyglot Receipt rendering precise rather
than heuristic.

**Tests** (+16 in `tests/test_sidecar.py`): schema (3), happy path
(4), error paths (5), forward-compat (3), tier discipline (1). 671
passing / 2 skipped (was 655). Wire scan PASS.

### Added — Codex-6 policy-as-code + recipes CLI + Receipt v1.1 (`c74670b`)

### Added — Codex-6 policy-as-code + recipes CLI + Receipt v1.1 (`c74670b`)

Three small but high-leverage additions on top of `v0.3.0`:

**(1) Policy-as-code is now ENFORCED, not just queryable.**

- `preflight_change` reads `[tool.forge.agent].max_files_per_patch`
  from `pyproject.toml` and uses it as the scope threshold (default
  remains 8 when no policy declared). An explicit caller-supplied
  `--scope-threshold` still wins.
- `preflight_change` tags any `proposed_file` matching
  `protected_files` with a per-file note **and** emits an overall
  "request human review" note listing the matches.
- `score_patch` grows an optional `project_root` kwarg. When provided
  AND `[tool.forge.agent]` declares `protected_files`, any diff
  touching a protected file forces `needs_human_review = True`
  regardless of diff size. Closes Codex's framing — *"Forge enforces
  the local social contract, not just the tier law."*

**(2) New CLI verb: `forge recipes [name]`** — same data the MCP
`list_recipes` / `get_recipe` tools return, but exposed for direct
human / shell-script use.

```bash
forge recipes                    # list every golden-path recipe
forge recipes release_hardening  # show one recipe (checklist +
                                 # file_scope_hints + validation_gate)
forge recipes --json | jq        # machine-readable
```

**(3) Receipt v1.1 — `polyglot_breakdown` field shipped (Lane A W8 seed).**

`ForgeReceiptV1` gains an optional `polyglot_breakdown` block
populated automatically by `build_receipt` from the scout report:

- per-language file counts
- per-language symbol counts
- `primary_language` verdict

Per-language certify scores stay for `v0.4` once the JS/TS
behavioural pytest gate lands (Golden Path Lane A W8 acceptance);
today's seed gives downstream consumers (Lane B Studio, Lane F CS-1
Conformity Statement, README badges) enough to render *"this repo is
80% Python, 15% TS"* directly from the Receipt.

This is the v1.0 → v1.1 bump promised in
`a0_qk_constants/receipt_schema.py`'s versioning roadmap (W8) — now
shipped one major lane ahead of W8 schedule.

**Tests** (+12 in `tests/test_codex_6_enforce_polyglot.py`): 655
passing / 2 skipped (was 643). Wire scan PASS.

## 0.3.0 — _Copilot's Copilot complete · 21 MCP tools · `forge --version` (`009d6d7`, tag `v0.3.0`)_

**The architectural control plane for AI coding agents.** Codex's
framing landed: Forge is not the agent — it's the always-on senior
engineer beside the agent. Cumulative trajectory since `0.2.2`
(reference `ee8b8cb`):

- **31 commits**, **+342 tests** (301 → **643 passing**, 2 skipped).
- `forge wire src/atomadic_forge` **PASS at every commit** —
  tier discipline held across the entire release.
- `forge certify .` = **100/100** held (pre-bump verification).
- `python -m build --no-isolation` produces a clean
  `atomadic_forge-0.3.0.tar.gz` + `atomadic_forge-0.3.0-py3-none-any.whl`.
- `forge mcp serve | tools/list` returns **21 tools** + 5 resources
  (pinned by tests).

**Lane status at v0.3.0**:
- **Lane A: 6-of-7 named deliverables shipped** (W2 RefAgent
  framework remains; recommended for a delegated agent).
- **Lane C: 3-of-6 shipped** (W1 forge-action, W2 pre-commit-hooks,
  W4 mcp serve).
- **Codex direction: 5-of-5 shipped** — Codex-1 (agent_summary),
  Codex-2 (agent_plan), Codex-3 (plan-apply chain), Codex-4
  (3 hero copilot's-copilot primitives), Codex-5 (full 12-item
  enumeration closed in one sweep).

Lane A is **6 weeks ahead of W0 baseline** — the entire critical-path
stack from schema → emitter → renderer → signer → F-codes → enforce
shipped on master.

### Added — pre-audit operational scaffolding

- **`forge audit list / show / log`** (`7cd840a`, audit-D1) — surfaces
  the Vanguard lineage chain as a verb. Reads
  `.atomadic-forge/lineage.jsonl`; populates Receipt's
  `lineage.lineage_path` field at GP Lane A W4. New module:
  `a1_at_functions/lineage_reader.py`.
- **`forge wire --suggest-repairs`** (`4786836`, audit-D2) — emits a
  per-violation repair hint and an `auto_fixable` count; populates
  Receipt's `wire.auto_fixable` field. Prerequisite for `forge enforce`
  at GP Lane A W6.
- **`forge wire --fail-on-violations`** (`8385cea`, audit-G1) — exits
  non-zero when any upward import is detected. Drop-in CI gate
  consumed by `forge-action` at GP Lane C W1.
- **`forge diff MANIFEST_A MANIFEST_B`** (`6249e74`, audit-D4) —
  schema-aware compare of two scout/certify manifests. Powers Lane B's
  "Shadow Merge" view (W8) and Lane E's PR-comment delta.
- **`--progress` on `forge recon` / `forge auto`** (`ec59a75`, audit-B2)
  — per-file stderr progress line. New module:
  `a1_at_functions/progress_reporter.py`. Feeds Lane B Forge Studio's
  progress pane.
- **F-coded error hints in CLI errors** (`375fe85`, audit-B4) —
  recovery-template hints attached to common CLI failure modes.
  Scaffolding for Lane A W5's full F0001–F0099 catalog. New module:
  `a1_at_functions/error_hints.py`.
- **Pre-audit smoke test** (`b4c8579`, audit-H1) — pins file:line
  claims so `lane-plan.md` cannot drift from the source.
- **`docs/FIRST_10_MINUTES.md` consolidation** (`109e857`, audit-F) —
  unifies onboarding; `docs/CI_CD.md`, `docs/MULTI_REPO.md`,
  `docs/AIR_GAPPED.md` are the deeper paths.

### Added — Golden Path Lane A W0 (critical-path)

- **Forge Receipt JSON v1 wire-format schema** (`f6c487a`, GP-A W0) at
  `a0_qk_constants/receipt_schema.py` (278 LOC) + `docs/RECEIPT.md`
  (305 lines) + `tests/test_receipt_schema.py` (206 LOC). Versioning
  roadmap explicit (v1.0 → v1.1 W8 polyglot_breakdown → v1.2 W12
  slsa_attestation → v2.0 W24 bao_rompf_witnesses). Both Lean4 corpora
  cited (`aethel-nexus-proofs` — 29 theorems, 0 sorry, 0 axioms — and
  `proof-corpus-v22` — 538 theorems, 0 sorry). All signing / lineage
  / attestation fields default to `None` so unsigned dev Receipts
  remain structurally valid. Tier-pure a0.

### Added — Golden Path Lane A W1 (emitter + card)

- **`receipt_emitter.py` + `card_renderer.py`** (`237c35f`, GP-A W1) —
  paired pure-a1 deliverables. Emitter is the inverse of the schema:
  pure transformer `(CertifyResult, WireReport, ScoutReport) →
  ForgeReceiptV1`. Card renderer is the 60×24 box-drawing renderer
  that powers the "62 → 5" viral demo (Lane E W2).
- **`forge certify --emit-receipt PATH`** writes a v1 Receipt JSON.
- **`forge certify --print-card`** prints the rendered card to stdout —
  the artifact the Lane E W2 demo screen-grabs.
- Both flags compose with `--json`, `--fail-under`, `--package`.

### Added — Golden Path Lane A W2 (signer)

- **`receipt_signer.py` + `forge certify --sign`** (`0670880`, GP-A W2).
  Stateful signer wrapping AAAA-Nexus `/v1/verify/forge-receipt` with
  graceful-degradation: missing API key, 4xx, 5xx, network error all
  fall back to unsigned-but-structurally-valid. The signer never
  throws.

### Added — Golden Path Lane A W5 (F-code registry)

- **F-code registry** (`f4c2548`, GP-A W5) at
  `a0_qk_constants/error_codes.py` — every Forge error now carries a
  stable 4-digit code (`F0042`-style) that is **never reused or
  renumbered**. 12 seed codes covering scout, cherry-pick, wire,
  certify, stub-detect, import-repair, assimilate, signing namespaces.
  Adding an F-code is additive; renumbering is a major schema bump.

### Added — Golden Path Lane A W6 (enforce)

- **`forge enforce`** (`b4e7ff2`, GP-A W6) — F-code-routed mechanical
  fixer. Pure planner at `a1_at_functions/enforce_planner.py` produces
  an `EnforceAction` list keyed by F-code; the executor applies them
  with rollback safety. Acceptance gate met: F0042 (a1 upward import)
  auto-resolvable; smoke covers 7 fix paths.

### Added — Golden Path Lane C W1 (forge-action)

- **`forge-action` composite GitHub Action + self-certify dogfood**
  (`dae64d1`, GP-C W1) — the Action's CI runs `forge certify .`
  against itself before publishing, propagating the BEP self-host gate
  pattern from Lane A to Lane C. Drop-in for any consuming repo via
  `.github/workflows/*.yml`.

### Added — Golden Path Lane C W2 (pre-commit hooks)

- **`.pre-commit-hooks.yaml` manifest** (`6c8a36b`, GP-C W2) — Husky-
  style capture: once one developer adds Forge to
  `.pre-commit-config.yaml`, every contributor inherits the gate. Hook
  runs `forge wire --fail-on-violations` (read-only by default; opt-in
  to fail-below via repo-side config). Powers the W3 distribution loop.

### Added — Golden Path Lane A W4 (Vanguard local chain)

- **Local Vanguard chain stub** (`a8e2c7e`, GP-A W4) — every Receipt
  now gets a real `lineage_path` populated from a content-addressed
  local chain, with the same graceful-degradation contract as the W2
  signer: when AAAA-Nexus `/v1/forge/lineage` ships, the publisher
  slots in transparently. Until then the chain is local-only and
  Receipt-verified. Closes Lane A W4.

### Added — Golden Path Lane A W3 (Compiler Feedback Loop)

- **`forge iterate --max-fix-rounds N`** (`6bae93b`, GP-A W3) — pure
  helper at `a1_at_functions/compiler_feedback.py` wired into
  `forge_loop.run_iterate`. The Compiler Agent of the RefAgent family:
  drives a build-error → fix loop iteratively until 100% compile or
  the round-budget is exhausted. Each iterate turn now runs
  `_run_fix_rounds` after the file write. Report includes a new
  `fix_rounds` field (count of fix iterations consumed).
- 8 new tests at `tests/test_compiler_feedback.py` — pure-module
  coverage + a stub-LLM `run_iterate` simulating broken-then-fixed
  sequences.

### Added — agent-native blocker summary surface (Codex-1 feedback)

- **`agent_summary` MCP tool + `a1_at_functions/agent_summary.py`**
  (`69d4ea9`) — pure helper that returns a compact, agent-friendly
  summary of the top blockers for a given project (certify axes
  failing, wire violations, stub bodies, missing CI/CHANGELOG). Seed
  for the broader Codex-direction redesign tracked on
  `gp-codex-2-agent-plan-cards` (return action cards instead of giant
  manifests). Exposed as a 6th MCP tool alongside the W4 surface.

### Added — Codex-2 agent plan cards (`atomadic-forge.agent_plan/v1`)

- **`agent_plan/v1` schema + `forge plan` + `auto_plan` MCP tool**
  (`c7ad6d8`, Codex-2) — sister schema to the Forge Receipt, tuned for
  proposal-engine mode: returns ranked "next best action" cards
  instead of giant manifests. New a0 schema at
  `a0_qk_constants/agent_plan_schema.py`, paired emitter at
  `a1_at_functions/agent_plan_emitter.py`, CLI verb `forge plan`, and
  a new MCP tool `auto_plan` exposed alongside the W4 surface (now 7
  tools total).
- Each plan card carries: `goal`, `top_actions[]` (with `id`, `kind`,
  `why`, `write_scope`, `risk`, `commands`, `applyable`),
  `next_command`, and a verdict (PASS / REFINE / QUARANTINE / REJECT).
- Same forward-compat schema discipline as the Receipt:
  `schema_version` regex, optional fields default to `None` / `[]`,
  consumers ignore unknown fields.

### Added — Codex-3 plan apply chain (`2cafbcc`)

- **`forge plan` `--save` + `plan-list` / `plan-show` / `plan-step` /
  `plan-apply` verbs + MCP tools** — closing the proposal-engine vision
  from Codex-1/2: agent inspects an emitted plan card → accepts /
  steps / applies → Forge applies the chosen actions with rollback
  safety → state persists across runs.
- New a2 composite `a2_mo_composites/plan_store.py` — append-only plan
  store + per-card state at `.atomadic-forge/plans/<id>.[state.]json`.
  `compute_plan_id` is **content-addressed** so re-emitting a
  structurally-identical plan yields the same id (re-emit-safe).
- New a3 feature `a3_og_features/forge_plan_apply.py` —
  `apply_card` / `apply_all_applyable` orchestrators with two routes:
  - architectural F0041–F0046 → `forge enforce --apply` (rollback-safe)
  - operational F0050 (docs missing) → bounded stub README writer
  Halts on first failed / rolled_back; records every event to plan state.

### Added — Codex-4 copilot's copilot (`fa50644`)

Direct response to Codex's "Forge is the architectural control plane
*around* any agent" directive. Three pure-a1 primitives + 3 MCP tools
+ 2 CLI verbs land Forge as the **always-on senior engineer** sitting
beside any coding agent:

- **`a1_at_functions/agent_context_pack.py`** — emits
  `atomadic-forge.context_pack/v1`. The bundle an agent should load
  on first orientation: repo purpose (README → pyproject → dirname),
  pinned 5-tier law, tier_map, blockers digest, best-next-action,
  detected test commands, release gate, risky files, recent lineage,
  pinned `forge://` resources.
- **`a1_at_functions/preflight_change.py`** — emits
  `atomadic-forge.preflight/v1`. Per-file: detected_tier,
  forbidden_imports, mirror-style likely_tests, siblings_to_read,
  cross-tier warnings, scope-too-broad flag at 8 files default.
- **`a1_at_functions/patch_scorer.py`** — emits
  `atomadic-forge.patch_score/v1`. Parses unified-diff and surfaces
  architectural_risk (new upward imports), public_api_risk
  (`__init__.py` touched), release_risk (pyproject / version /
  CHANGELOG / LICENSE), test_risk (code without tests), >200-line
  blast-radius flag → `needs_human_review` boolean + suggested
  validation commands.
- **3 new MCP tools**: `context_pack`, `preflight_change`,
  `score_patch` (registered alongside the W4 / Codex-1/2/3 surface —
  **10 tools total**). All three are pure-a1 — no a3 injection
  needed; they read from reports + filesystem only.
- **`forge context-pack [target] [--json]`** — runs scout + wire +
  certify, emits the bundle. The single command an agent should run
  on first orientation.
- **`forge preflight <intent> <file...> [--scope-threshold N] [--json]`** —
  pre-edit guardrail. CLI exits 1 when write_scope too broad.
  (`score_patch` is intentionally MCP-only — diff strings are
  awkward as positional CLI args.)
- **+29 tests** at `tests/test_copilots_copilot.py` (10 context_pack /
  10 preflight / 8 score_patch / 1 mcp_protocol update). Trajectory:
  **301 → 611 passing**, 2 skipped. `forge wire` PASS at every
  commit. `forge certify .` = **100/100** held.
- Live smoke against Codex's atomadic-lang downstream: `forge
  context-pack ./atomadic-lang` returned tier_map 282 files / 0
  blockers / `release_gate: ruff && pytest && wire && certify ≥ 75`.

Companion to Codex-1 (`69d4ea9`, agent_summary), Codex-2 (`c7ad6d8`,
agent_plan), and Codex-3 (`2cafbcc`, plan-apply chain).

### Added — Codex-5 Copilot's Copilot complete + `forge --version` (`276a092`)

Closed Codex's full 12-item "Copilot's Copilot" enumeration in one
sweep on top of the 3 hero primitives shipped in Codex-4. **Eight new
pure modules + 11 new MCP tools + one production-hardening flag.**
Total live MCP surface jumped from **10 → 21 tools**.

**8 new modules** (a0 + a1 only — pure, tier-clean):

| File | Codex # | Purpose |
|---|---|---|
| `a0_qk_constants/policy_schema.py` | #10 | `atomadic-forge.policy/v1` TypedDict + sane defaults (max_files_per_patch, protected_files, release_gate, require_human_review_for) |
| `a1_at_functions/policy_loader.py` | #10 | pure `pyproject.toml [tool.forge.agent]` reader + `file_is_protected` matcher (exact + suffix) |
| `a1_at_functions/test_selector.py` | #7 | `select_tests({changed_files, intent})` → `minimum` (mirror match) + `full` (tier-mate) test sets |
| `a1_at_functions/rollback_planner.py` | #11 | `rollback_plan({changed_files})` → files-to-remove, caches, tests-to-rerun, risk_level (low/medium/high — high if a release file like pyproject / version / CHANGELOG / LICENSE is touched) |
| `a1_at_functions/agent_memory.py` | #5 | `why_did_this_change({file})` + `what_failed_last_time({area})` → queries `.atomadic-forge/lineage.jsonl` and plan-state files |
| `a1_at_functions/repo_explainer.py` | #6 | humane operational orientation card — purpose, entry-points, do-not-break list, release_state derived from wire/certify |
| `a1_at_functions/plan_adapter.py` | #8 | capability-aware card filtering — `apply` / `delegate` / `ask_human` / `report_only` based on agent capabilities (`edit_files`, `run_commands`, `network`, `review`, `delegate`) |
| `a1_at_functions/tool_composer.py` | #9 | goal-keyword → ordered tool sequence; recipe library (`orient`, `release_check`, `fix_violation`, `before_edit`, `verify_patch`) |
| `a1_at_functions/recipes.py` | #12 | golden-path recipes — `release_hardening`, `add_cli_command`, `fix_wire_violation`, `add_feature`, `publish_mcp` (each a step-by-step playbook agents can `list` / `get`) |

**11 new MCP tools** registered alongside the W4 / Codex-1..4 surface:

`select_tests`, `rollback_plan`, `explain_repo`, `adapt_plan`,
`compose_tools`, `load_policy`, `why_did_this_change`,
`what_failed_last_time`, `list_recipes`, `get_recipe`. (`score_patch`
shipped in Codex-4 was the 11th; this commit takes the running total
from 10 → 21.)

**Production hardening:**

- **`forge --version` / `forge -V`** was throwing "Try forge --help".
  Added a root callback with an `is_eager` `--version` option that
  prints `atomadic-forge X.Y.Z` and exits 0. Test pins this.
- **`forge mcp serve --help`** docstring updated to enumerate the 21
  tools + 5 resources (was 8 / 5). MCP test pins the full set.

**Tests** (+32 in `tests/test_codex_5_complete.py` + 1 update in
`tests/test_mcp_protocol.py`): 643 passing / 2 skipped (was 611).
Each new module has v1-schema, dispatch, and edge-case coverage.

**Codex's 12-item enumeration is now FULLY shipped:**

| # | Item | Where |
|---|---|---|
| 1 | First-call context pack | `context_pack` (Codex-4 / `fa50644`) |
| 2 | Preflight before edit | `preflight_change` (Codex-4 / `fa50644`) |
| 3 | Patch risk scoring | `score_patch` (Codex-4 / `fa50644`) |
| 4 | Active guardrail | composed via `preflight_change` + `score_patch` + `auto_step` (no separate verb needed) |
| 5 | Agent memory / lineage | `why_did_this_change`, `what_failed_last_time` (Codex-5) |
| 6 | Explain this repo | `explain_repo` (Codex-5) |
| 7 | Test selection | `select_tests` (Codex-5) |
| 8 | Capability-aware planning | `adapt_plan` (Codex-5) |
| 9 | MCP tool composer | `compose_tools` (Codex-5) |
| 10 | Policy as code | `load_policy` (`[tool.forge.agent]`) (Codex-5) |
| 11 | Undo plan | `rollback_plan` (Codex-5) |
| 12 | Golden-path recipes | `list_recipes` / `get_recipe` (Codex-5) |

### Added — release-bump cosmetics (`009d6d7`)

- `pyproject.toml` `version = "0.3.0"`
- Tag `v0.3.0` pushed to `origin`
- Wheel + sdist confirmed via `python -m build --no-isolation`
- README badge bumped from `0.2.2 (100/100 certify + GitHub-ready)`
  to reflect the v0.3.0 21-tool architectural-control-plane surface
  (cleanup-crew rolling).

### Added — Codex docs walkthrough (`178d020`)

- New affordances walkthrough for the Atomadic-Lang downstream agent —
  concrete `try-these` snippets covering the agent flows AGENTS_GUIDE.md
  describes, runnable end-to-end against a fresh checkout.

### Added — Golden Path Lane C W4 (forge mcp serve)

- **`forge mcp serve`** (`9f63085`, GP-C W4) — stdio JSON-RPC server
  exposing the entire Forge pipeline to any coding agent that speaks
  MCP (Cursor, Claude Code, Aider, Devin, Sweep). 5 tools (`recon`,
  `wire`, `certify`, `enforce`, `audit_list`) + 4 resources, soft-fail
  contract, tier-clean. New modules:
  `a1_at_functions/mcp_protocol.py` (pure JSON-RPC framing),
  `a3_og_features/mcp_server.py` (stdio loop), CLI verb in
  `a4_sy_orchestration/cli.py`.
- **F0042 case study** during W4 development: an a3-import sneaking
  into a1 was caught by `forge wire` mid-implementation. Fix was the
  canonical injection refactor — the enforce handler registration moved
  to a3 where it belongs. Tier discipline held by construction.
- 21 new tests at `tests/test_mcp_protocol.py` covering the JSON-RPC
  init/tools-list/shutdown round-trip + every tool's
  inputSchema/outputSchema contract.
- **Live demo on Forge itself**:
  ```
  printf '%s\n%s\n%s\n' \
    '{"jsonrpc":"2.0","id":1,"method":"initialize"}' \
    '{"jsonrpc":"2.0","id":2,"method":"tools/list"}' \
    '{"jsonrpc":"2.0","id":3,"method":"shutdown"}' \
    | forge mcp serve --project .
  ```
  Returns server info, 5 tools, clean shutdown — single round-trip
  proves the surface is reachable from any MCP client.

### Fixed

- **`datetime.utcnow()` deprecation sweep** (`3359fb6`, audit-A1) —
  replaced with `datetime.now(timezone.utc)` across a3 features.
  Prerequisite for the GP P1 self-certify gate.

### Documentation

- `docs/COMMANDS.md` updated with the 5 new user-facing surfaces:
  `forge audit list/show/log`, `forge diff`, `forge wire
  --fail-on-violations`, `forge wire --suggest-repairs`,
  `forge recon --progress`.

### Notes for downstream consumers

- The Receipt schema is **forward-compatible by design** — every new
  field defaults to `None` or `[]` / `{}`. Adding a *required* field is
  a major version bump; reserved field names are documented in the
  schema docstring.
- `forge wire --fail-on-violations` is the load-bearing primitive for
  the planned `atomadictech/forge-action` GitHub Action (GP Lane C W1).
- 9 audit-lane commits + 1 GP-A W0 commit currently sit on a feature
  branch. Cut as `0.3.0-rc1` when GP-A W1 (`receipt_emitter` +
  `card_renderer`) lands.

## 0.2.2 — _Operational axis + 100/100 self-certify_

`forge certify` now scores the full 0–100 range.  The v1 rubric topped
out at 90 (35 structural + 25 runtime + 30 behavioural) with 10 points
of reserved headroom that no axis credited.  This release closes the
gap with a new **operational axis** worth 10 points total:

| Axis | Points | Check |
|---|---|---|
| CI workflow present | 5 | `.github/workflows/*.yml` (or `.yaml`) — at least one non-empty file |
| Changelog / release notes | 5 | `CHANGELOG.md` (or `.rst`, `RELEASE_NOTES.md`, `HISTORY.md`, `NEWS.md`) ≥ 200 bytes at root |

Both checks are pure structural file-existence — no API calls, no slow
runtime paths.  The CI axis credits intent (a workflow exists); the
behavioural axis already credits actual test-pass behaviour, so there's
no double-counting.

### Added

- `check_ci_workflow(root)` — pure helper at `a1_at_functions/certify_checks.py`
- `check_changelog(root)` — pure helper at the same module
- `score_components.operational` — new key in the certify result dict
- `ci_workflow_present` and `changelog_present` — new top-level booleans
  in the certify result dict
- `detail.ci` and `detail.changelog` — new entries in the detail dict
- 22 new tests in `tests/test_certify_operational_axis.py` covering both
  helpers, the integrated 100/100 path, partial-credit (CI-only,
  changelog-only), and the issue/recommendation surfacing on misses
- README badge updated from 90/100 → 100/100

### Fixed

- The `# Score weights (sum to 100):` comment in `certify_checks.py` now
  actually sums to 100 (was 90 in v0.2.1; the reserved headroom is now
  spoken for).
- Forge's own self-certify: **90 → 100**.  299 passing tests, 1
  skipped (was 274 + 1).  Wire scan: PASS, 0 violations.
- `forge demo run` now exits non-zero when the generated CLI demo fails,
  while still writing the artifact for debugging.
- `commandsmith sync` now regenerates a Ruff-clean command registry.
- `forge certify --fail-under <score>` gives CI an explicit score gate.
- Certification scans ignore `.pytest_tmp*` scratch trees and generated
  smoke tests are Ruff-clean, so local verification does not depend on
  manual cleanup order.

### Notes for downstream certify consumers

If your tooling asserts on a specific score value (e.g. `assert
result["score"] == 90`), audit it: a project with `.github/workflows/`
and `CHANGELOG.md` will now legitimately score higher than before.
The fixture-based tests in `tests/test_stub_detector.py` were
unaffected because their temp roots don't include the operational-axis
files.

## 0.2.1 — _Provider resilience + forge stress-test fixes_

Discovered and fixed during a live stress-test: using Forge itself to
absorb 23,487 symbols from five major agent frameworks (langchain,
autogen, instructor, mem0, browser-use) while running `iterate`, `evolve`,
`emergent`, `synergy`, and `commandsmith` end-to-end.  All fixes are in the
forge source; the evolution run produced `generated/tool-agent` (60/100) and
`generated/sovereign` (74/100) plus 12 registered CLI commands (12/12 smoke PASS).

### Added

- `forge chat ask` and `forge chat repl` — a Forge-aware chat copilot that
  uses the same provider layer as `iterate` / `evolve`, supports `nexus`,
  `openrouter`, `gemini`, `anthropic`, `openai`, `ollama`, and `stub`, and
  packs bounded repo context while skipping `.env` and obvious secret files.
- Deterministic Python quality phases after generation: missing docstrings
  are filled, `docs/API.md` and `docs/TESTING.md` are created, and
  `tests/test_generated_smoke.py` is added before final certification.
- `.atomadic-forge/quality.json` records the docstring/docs/tests phase
  results for every Python `iterate` / `evolve` output.
- GitHub readiness assets: CI and release workflows, Dependabot config,
  bug/feature issue forms, PR template, security policy, and source
  distribution manifest.
- Shared provider resolver used by `chat`, `demo`, `iterate`, and `evolve`
  so aliases and help text no longer drift between commands.
- CLI UX docs for chat, offline demo expectations, corrected certify scoring,
  and the actual `--provider auto` resolution order.

### Bug fixes

**Bug 1 — `forge iterate` missing `nexus` provider**
`commands/iterate.py` had no `nexus`/`aaaa-nexus` case in `_resolve_provider()`
even though `forge evolve` already supported it.  Added
`if name in ("nexus", "aaaa-nexus", "aaaa_nexus", "helix"): return AAAANexusClient()`.

**Bug 2 — `forge iterate` missing `openrouter` provider**
No OpenRouter support existed anywhere in forge.  Added `OpenRouterClient` to
`a1_at_functions/llm_client.py` (OpenRouter's OpenAI-compatible endpoint,
default model `google/gemma-3-27b-it:free`).  Added `openrouter`/`router`
cases to both `iterate` and `evolve` provider resolvers.

**Bug 3 — `forge iterate` only accepted a single `--seed`**
`seed_repo: Path | None` rejected multiple seeds.  Changed to
`seed_repo: list[Path] | None` in both `commands/iterate.py` and
`a3_og_features/forge_loop.py`.  The seed catalog is now accumulated
from all provided `--seed` paths.

**Bug 4 — OpenRouter 400 on models without system-role support**
`gemma-3-27b-it` (and similar models) return HTTP 400
`"Developer instruction is not enabled"` when a `system` role message is
sent.  `OpenRouterClient.call()` now retries with the system prompt folded
into the user message on the first such failure.

**Bug 5 — `parse_files_from_response` failed on truncated JSON arrays**
When an LLM response was cut off mid-array the balanced-bracket scanner
returned `[]`, writing 0 files.  Added a third strategy: regex-based
extraction of complete `{"path", "content"}` objects from a partial array.
Also fixed the fence regex from non-greedy to greedy capture.

**Bug 6 — Seed catalog flooded the prompt with 460 K+ symbols**
Multiple large seeds (langchain + mem0) pushed 460 K+ symbols into the
prompt, confusing the LLM.  `pack_initial_intent()` now deduplicates
method-level entries to base class names and caps the display at 30 unique
top-level symbols.

**Bug 7 — SyntaxWarning noise from third-party forged files**
mem0's regex strings used invalid escapes (`\.`), causing Python
`SyntaxWarning` on every forge command that loaded the seed catalog.  Added
`warnings.filterwarnings("ignore", category=SyntaxWarning)` at CLI import
time in `a4_sy_orchestration/cli.py`.

**Bug 8 — `commandsmith smoke` referenced non-existent `unified_cli` module**
The smoke test invoked
`atomadic_forge.a4_sy_orchestration.unified_cli` which doesn't exist.
Changed to `atomadic_forge.a4_sy_orchestration.cli`.  The current command
surface now passes smoke test (12/12 PASS).

**Bug 9 — Generated synergy adapters referenced `unified_cli`**
The synergy-implement template hardcoded `unified_cli` in subprocess calls.
Replaced with `cli` in all three generated adapter files
(`emergent_then_synergy.py`, `synergy_then_emergent.py`,
`evolve_then_iterate.py`) and registered them in `cli.py`.

**Bug 10 — `forge certify` stub scan recursed into `forged/` directories**
When certifying a project root without a `src/` directory,
`detect_stubs` ran `rglob("*.py")` on the full tree — including 17 727
stub skeletons in `forged/*/src/` — dragging the score from 60 → 20/100.
`certify_checks.py` now sets `src_for_stubs = None` and skips stub
detection entirely when there is no `src/` layout.

### New / changed modules

| File | Tier | Change |
|------|------|--------|
| `a1_at_functions/llm_client.py` | a1 | `OpenRouterClient` added; `resolve_default_client()` includes openrouter in auto-chain |
| `commands/iterate.py` | a4 | nexus + openrouter providers; multi-seed `list[Path]` |
| `commands/evolve.py` | a4 | nexus + openrouter providers |
| `a3_og_features/forge_loop.py` | a3 | multi-seed accumulation loop |
| `a1_at_functions/forge_feedback.py` | a1 | 3-strategy tolerant JSON parser; seed dedup + 30-symbol cap |
| `a4_sy_orchestration/cli.py` | a4 | SyntaxWarning suppressor; 3 new synergy adapters registered |
| `a3_og_features/commandsmith_feature.py` | a3 | smoke test CLI path fixed |
| `a1_at_functions/certify_checks.py` | a1 | stub scan scoped to `src/` only; no-src fallback skips scan |
| `commands/emergent_then_synergy.py` | a4 | new — emergent → synergy pipeline adapter |
| `commands/synergy_then_emergent.py` | a4 | new — synergy → emergent pipeline adapter |
| `commands/evolve_then_iterate.py` | a4 | new — evolve → iterate pipeline adapter |

### Provider matrix (updated)

| Provider | Cost | Env var | Default model |
|----------|------|---------|---------------|
| `gemini` | free tier | `GEMINI_API_KEY` / `GOOGLE_AI_STUDIO_KEY` | `gemini-2.5-flash` |
| `nexus` / `aaaa-nexus` | paid | `AAAA_NEXUS_API_KEY` | (Nexus default) |
| `anthropic` | paid | `ANTHROPIC_API_KEY` | `claude-3-5-sonnet-latest` |
| `openai` | paid | `OPENAI_API_KEY` | `gpt-4o-mini` |
| `openrouter` | free tier available | `OPENROUTER_API_KEY` | `google/gemma-3-27b-it:free` |
| `ollama` | free, local | `FORGE_OLLAMA=1` | `qwen2.5-coder:7b` |
| `stub` | free, offline | n/a | n/a |

---

## 0.2.0 — _Polyglot (JavaScript / TypeScript) support_

Forge is no longer Python-only. `recon`, `wire`, and `certify` now classify
JavaScript and TypeScript files into the same 5-tier monadic layout that has
always governed Python source. The same constraint substrate now answers for
Cloudflare Workers, Node back-ends, React-Native modules, and any mixed-language
repository — without adding a Node dependency to Forge itself.

### What landed

- **Polyglot file scanning.** `recon` walks `.py`, `.js`, `.mjs`, `.cjs`,
  `.jsx`, `.ts`, and `.tsx` in a single pass. `node_modules/`, `.next/`,
  `.wrangler/`, `dist/`, `build/`, `coverage/`, and `.turbo/` are skipped
  automatically.
- **Pure-Python JS parser.** ES6 `import` (named, default, namespace,
  side-effect, `import type` for TS), dynamic `import()`, and CommonJS
  `require()` (including destructured) are all parsed via regex + a
  brace-walking surface scanner. Comments and string literals are stripped
  first so a fake `import x from 'y'` inside a string never registers.
- **Tier classification for JS/TS.** Files placed inside an `aN_*` directory
  obey the law strictly. Files outside get a `suggested_tier` inferred from
  their character — a Cloudflare Worker default-`{ fetch, scheduled }` is a4,
  a class-with-state module is a2, an `export-const`-only module is a0, and so on.
- **Polyglot wire-check.** Upward-import detection works against JS specifiers
  like `"../a3_og_features/foo"` exactly as it works for Python `from`-imports.
  Each violation now carries a `language` field (`"python"` / `"javascript"`
  / `"typescript"`) so reports can group by source.
- **Polyglot certify.**
  - `tests` PASS recognises `tests/*.test.{js,mjs,jsx,cjs,ts,tsx}`,
    `*.spec.*`, and the Jest `__tests__/` convention alongside Python's
    `tests/test_*.py` and `*_test.py`.
  - Tier-layout PASS counts JS-style top-level or nested `aN_*` directories
    anywhere under the repo root, not just under `src/<pkg>/`.
  - Failure messages are now specific (e.g. *"found 2 tier directories
    (a1_at_functions, a4_sy_orchestration); need 3+"*).
- **Per-language recon output.** `forge recon` prints
  `python files: N`, `javascript files: M`, `typescript files: K`, plus a
  `primary_language` verdict and a `recommendations` list when JS/TS files
  exist outside tier directories.
- **Three static showcase demo presets.** `forge demo` now ships
  `js-counter` (clean a0..a4 JS package; wire PASS, certify 60/100 —
  the honest ceiling for a JS-only package while behavioural scoring
  remains Python-only), `js-bad-wire` (deliberately upward-imports —
  wire surfaces the violation with `language: "javascript"`), and
  `mixed-py-js` (one Python tier and one JS tier under the same root).
  These run *without an LLM* — they showcase recon/wire/certify on
  pre-built source, no API key required.

### New / changed modules (monadic tier placement)

| File | Tier | Purpose |
|------|------|---------|
| `a0_qk_constants/lang_extensions.py` | a0 (new) | Canonical `.py` / `.js` / `.mjs` / `.cjs` / `.jsx` / `.ts` / `.tsx` extension sets + `lang_for_path` lookup |
| `a1_at_functions/js_parser.py` | a1 (new) | Pure regex + brace-walker for ES6 / CommonJS imports, exports, default-object handlers (Worker shape), state signals, tier classifier, effect detector |
| `a1_at_functions/scout_walk.py` | a1 (extended) | Walks JS/TS as well as Python; per-file `suggested_tier`; per-language counts in the report |
| `a1_at_functions/wire_check.py` | a1 (extended) | Polyglot upward-import scanner; each violation carries a `language` field; `node_modules/` and `__pycache__/` skipped |
| `a1_at_functions/certify_checks.py` | a1 (extended) | `tests` and `tier_layout` checks recognise JS conventions; specific failure messages |
| `a4_sy_orchestration/cli.py` | a4 (extended) | `forge recon` prints per-language counts and detected `primary_language` |
| `a3_og_features/demo_runner.py` | a3 (extended) | `DemoPreset.kind` (`"llm"` / `"showcase"`) + `run_showcase` for static-package demos |
| `a3_og_features/demo_packages/` | a3 (new) | Source files for `js-counter`, `js-bad-wire`, `mixed-py-js` showcase presets |

### Tests

42 new tests for the JS/TS scanner (ES6 / dynamic / CommonJS imports,
TypeScript imports, comment + string-literal stripping, classifying a
`worker.js` as a4, classifying a constants module as a0, JS-only repo
recon, TypeScript counted, JS/TS upward-import detection in wire, JS
test recognition in certify, polyglot tier-layout detection, and the
specific layout-failure message), plus 20 follow-up tests for the
canonical `IGNORED_DIRS` list, the file-class taxonomy
(`source` / `documentation` / `config` / `asset` / `other`), and
nested-`docs/` / `guides/` discovery in `check_documentation`.

Total: **212 tests**, all passing.

### Atomadic recon proof point

| Repo state | Python | JavaScript | Primary | Certify |
|------------|-------:|-----------:|---------|--------:|
| Atomadic — before 0.2 | 1 | 0 (not seen) | python | 45/100 (tests FAIL) |
| Atomadic — after  0.2 | 1 | 3 | javascript | 50/100 (tests PASS via `cognition.test.js`; layout still FAIL with specific reason: "0 tier directories present") |

The remaining gap is real architecture work, not Forge limitation.

### Known limits (still honest)

- The JS parser is regex-based, not a real AST. It handles the surface
  (imports / exports / class / default-object handlers / state signals)
  the tier law cares about. JSX expressions, decorators, and exotic-shape
  TypeScript generics are silently ignored where they would not affect the
  tier verdict.
- The runtime importability check (the +25 score component for "package
  actually loads in a fresh subprocess") remains Python-only. JS/TS packages
  are scored on documentation, tests, layout, and upward-import discipline;
  the behavioural pytest gate stays a Python-side check too.
- Rust / Go support is still on the roadmap.

---

## 0.1.1 — _forge init setup wizard + forge config management_

First-run experience: new users can configure Forge in 60 seconds without
touching environment variables or config files by hand.

### New commands

- `forge init` — top-level alias for the interactive setup wizard.
- `forge config wizard` — same wizard from within the config sub-group.
- `forge config show` — print the current merged config (local > global > defaults);
  API keys are masked automatically. `--json` for scripting.
- `forge config set KEY VALUE` — set a single key in the local (or `--global`) config file;
  booleans and numbers are auto-coerced.
- `forge config test [--provider P]` — live-test the configured LLM connection and
  print status, model, and round-trip latency.

### New modules (monadic tier placement)

| File | Tier | Purpose |
|------|------|---------|
| `a0_qk_constants/config_defaults.py` | a0 | `DEFAULT_CONFIG`, `ForgeConfig` TypedDict, file-location constants |
| `a1_at_functions/config_io.py` | a1 | `load_config`, `save_config`, `merge_configs`, `validate_config`, `read_config_file` |
| `a1_at_functions/provider_detect.py` | a1 | `detect_ollama`, `list_ollama_models`, `test_provider` |
| `a3_og_features/setup_wizard.py` | a3 | `run_wizard` — 5-step interactive wizard with rich panels |
| `commands/config_cmd.py` | a4 | Typer sub-app with `wizard`, `show`, `set`, `test` sub-commands |

### Config merge priority

`local .atomadic-forge/config.json` → `global ~/.atomadic-forge/config.json` → built-in defaults.
`None` values are skipped so keys always fall through to the next layer.

### Tests

56 new tests covering:
- All default key presence and value ranges
- `save_config` / `read_config_file` round-trip and error paths
- `merge_configs` all priority combinations
- `load_config` with and without local config files
- `validate_config` valid/invalid providers, scores, and URLs
- `detect_ollama` / `test_provider` error paths (monkeypatched urllib)
- CLI smoke: `config show`, `config show --json`, `config set`, `config test --json`, `init --help`

Total: **150 tests**, all passing.

---

## 0.1.0 — _Initial cut + 6 refine cycles + breakthrough + showcase_

First public-shaped release. Forged out of `ASS-ADE-SEED` by isolating the
absorb-and-emerge wedge, then sharpened across six refine cycles into a
genuine architecture substrate for AI-generated code.

### Pipeline verbs

- `forge auto` — scout + cherry + assimilate + wire + certify in one shot.
- `forge recon` / `forge cherry` / `forge finalize` — granular workflow.
- `forge wire` — upward-import scanner.
- `forge certify` — docs/tests/layout/imports/behavior score with stub-body penalty.
- `forge doctor` — environment diagnostic.

### Code-generation verbs (LLM-driven)

- `forge iterate run` — LLM ↔ Forge 3-way constraint loop.
- `forge evolve run --auto N` — recursive self-improvement; halts on
  convergence, regression (optional), or stagnation (3 flat rounds default).
- `forge demo run --preset NAME` — one-shot launch-video verb. Presets:
  `calc`, `kv`, `slug`, all live-validated against Gemini.
- `forge feature-then-emergent` — universal pipe: any feature → emergent scan.

### Specialty verbs (lazily registered)

- `forge emergent scan` — symbol-level composition discovery.
- `forge synergy scan` / `synergy implement` — feature-pair detection +
  auto-generated adapters.
- `forge commandsmith discover/sync/wrap/smoke` — auto-register CLI
  commands across the catalog.

### Refine cycle highlights

| Cycle | Headline change | Live verification |
|-------|----------------|---------------------|
| 0.1.0 base | 5-tier law + import-linter contract; `auto`/`recon`/`cherry`/`finalize`/`wire`/`certify`/`doctor`. | 47 tests passing. |
| Refine 1 | Stub-body detector (catches `pass`, `NotImplementedError`, `# TODO`). Stagnation halt for evolve. Per-file feedback. | URL-shortener trajectory `50→50→50→50` (stuck). |
| Refine 2 | Runtime import smoke (subprocess `python -c "import <pkg>"`). Few-shot in system prompt. Retry-on-bad-parse. Score rebalance. | URL-shortener `70→70→70→85` — **converged Round 3**, runnable CLI. |
| Refine 3 | Round-0 scaffolds (pyproject + README + tests/conftest + tier inits). Tier `__init__` re-export rebuilder (idempotent, banner-gated). | URL-shortener `69→100` — **converged Round 1**. |
| Refine 4 | Validation: same model + same task, `100→100→100→100`, **but identity-function stubs gamed every check**. Score lied. | mdconv with codellama emitted `def parse(x): return x`; certify said 100. |
| Refine 5 (BREAKTHROUGH) | Behavioral pytest runner (subprocess pytest). Score weights: structural 35 + runtime 25 + behavioral 30. Per-file pytest failure callouts in feedback. | mdconv `60→60→60→60→60` — score now reflects honest behavior. Identity gaming closed. |
| Refine 6 | `forge demo` one-shot launch verb with 3 live-validated presets. | calc/kv/slug all 90/100 with Gemini in 22–72s. |
| Doc + transparency | Auto-doc synthesizer (rich READMEs from emitted symbols), append-only evolution log + transcript log. Wrong-package gameability fix (test runner now requires tests to import the requested package). | New gap caught + closed in the same session. |

### Substrate properties (now provable from the artifact alone)

- **Wire scan** — every emitted file lives in the legal tier.
- **Import smoke** — package actually loads in a fresh subprocess.
- **Behavioral pytest** — LLM's own tests must actually pass.
- **Stub detector** — `pass` / `NotImplementedError` / `# TODO` deduct.
- **Wrong-package gating** — tests that don't import the requested package
  don't credit the behavioral score.

### Per-run artifacts (auto-emitted)

Every successful run leaves under `<output>/.atomadic-forge/`:

- `EVOLVE_LOG.md` + `evolve_log.jsonl` — append-only run history.
- `lineage.jsonl` — append-only artifact provenance.
- `transcripts/run-<ts>.jsonl` — every LLM prompt + response (full transparency).
- `evolve.json` / `iterate.json` / `demo.json` / `scout.json` — per-phase
  structured reports with stable schema versions.

### LLM provider matrix

| Provider | Cost | Default model |
|----------|------|---------------|
| `gemini` | **free tier** | `gemini-2.5-flash` |
| `anthropic` | paid | `claude-3-5-sonnet-latest` |
| `openai` | paid | `gpt-4o-mini` |
| `ollama` | **free, local** | `qwen2.5-coder:7b` |
| `stub` | free, offline | n/a (deterministic) |

### Documentation

- `docs/SHOWCASE.md` — live runs + trajectories.
- `docs/LANDSCAPE.md` — comparison vs Cursor/Devin/Lovable/Bolt/Copilot.
- `docs/WHY_NOW.md` — the urgency case for the architecture substrate.
- `docs/COMMANDS.md` — full reference for all 13+ verbs.
- `docs/ROADMAP.md` — 0.2 / 0.3 / 1.0 milestones.
- `docs/tutorials/01-quickstart.md` — 60-second getting-started.
- `docs/tutorials/02-your-first-package.md` — own intent string.
- `docs/tutorials/03-the-five-tier-law.md` — the architecture itself.
- `docs/tutorials/04-plug-in-llms.md` — provider matrix.
- `docs/tutorials/05-multi-repo-absorb.md` — the absorb flow.

### Known limits (honest)

- Python only — multi-language ships in 0.3.
- Auto output is bootstrapped material; integration tests + secrets +
  observability remain human responsibilities.
- No semantic merge across conflicting symbols (rename / first / last /
  fail per `--on-conflict`).
- Cryptographic certificate signing chain ships in 0.2.
- The behavioral pytest check is the strongest signal but tests authored
  by the LLM can themselves be weak; adversarial-test generation in 0.2.

### Dropped from the parent (ASS-ADE-SEED)

- `chat`, `voice`, `agent`, `a2a` → moving to Atomadic Assistant.
- `pay`, `wallet`, `vrf`, `defi`, `mev`, `vanguard`, `aegis`, `bitnet`
  → stay in AAAA-Nexus.
- `discord`, `hello`, `heartbeat` → infrastructure, not Forge surface.

### Test counts

- 90+ pytest tests, all passing.
- All scenarios live-validated end-to-end against ollama (codellama:7b)
  and Google Gemini 2.5 Flash on free tier.
