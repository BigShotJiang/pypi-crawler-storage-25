# FAQ & Troubleshooting

## General questions

### What's the difference between Forge and a code formatter?

**Formatters** (Black, ruff) clean up whitespace and style.

**Forge** reorganizes architecture — moving symbols between tiers, enforcing import discipline, rebuilding structure.

Example:
- Black: `"hello"` → `"hello"` (no change if already formatted)
- Forge: A 500-line god class → splits into a0 (config), a1 (logic), a2 (state), a3 (orchestration)

### Is Forge a code generator?

No. Forge is a **code absorber**. It reorganizes code that already exists.

For **code generation**, use `forge iterate` or `forge evolve` (LLM loops).

### Can Forge handle non-Python languages?

**Yes — as of 0.2, Forge classifies JavaScript and TypeScript with the
same 5-tier law it has always applied to Python.** Walked extensions:
`.py`, `.js`, `.mjs`, `.cjs`, `.jsx`, `.ts`, `.tsx`. `node_modules/`,
`dist/`, `.next/`, `.wrangler/`, and other vendored / build directories
are skipped automatically; no Node install required.

`forge recon` reports per-language counts and a `primary_language`
verdict. `forge wire` detects upward imports in JS specifiers
(`"../a3_og_features/foo"`) the same way it does in Python `from`-imports;
each violation in the JSON report is tagged with `language`. `forge
certify` recognises JS test conventions (`*.test.*`, `*.spec.*`,
`__tests__/`) and JS-style `aN_*/` directories anywhere under the root.

What's still Python-only:
- The runtime-import smoke check (the +25 score component for "package
  actually loads in a fresh subprocess").
- The behavioural pytest gate (the +30 component for "the package's own
  tests pass").

JS/TS-only packages are scored on the +45 polyglot-aware structural
axes (docs / tests-present / tier layout / upward-import discipline)
plus the stub-body penalty. Wiring `npm test` / Vitest into the
behavioural gate is on the post-v0.14 roadmap (see
[ROADMAP.md](ROADMAP.md#beyond-v015--themes-not-commitments)).
Rust and Go module-level classification ships today; symbol-level
extraction for those languages is also on the post-v0.14 roadmap.

Try the showcase presets to see the pipeline against real JS source —
no LLM key needed:

```bash
forge demo run --preset js-counter   # clean JS package, certify 60/100
forge demo run --preset js-bad-wire  # one upward import; wire flags it
forge demo run --preset mixed-py-js  # Python tier + JS tier in one root
```

### What if my repo doesn't have tests or documentation?

Forge handles it. The output will score 0/25 on those checks:

```
  documentation:  0/25 (README.md not found)
  tests:         0/25 (tests/ not found)
```

But it will still absorb the code. The STATUS.md report will list tests and docs as required follow-up.

### What is the wisdom DB and why is it gitignored-with-an-exception?

The wisdom DB (`v0.13.0`+) at `.atomadic-forge/wisdom.jsonl` is
append-only institutional memory scoped to a repo. Per-session agent
insights survive across conversations, so the next agent that opens
this repo inherits prior lessons via:

- **`forge recon`** — response includes a `prior_wisdom` field
  (top-5 entries by relevance score).
- **`forge verify`** — when trust thresholds are met (≥3 lineage
  events, or ≥1.0 score delta, or ≥5-min session), response includes
  a `wisdom_capture_prompt` with a draft insight + a `next_command`
  template the agent can submit verbatim.

Standalone CLI: `forge wisdom record / query / list / recall`.

The `.gitignore` exception is intentional: `.atomadic-forge/*` stays
gitignored *except* `wisdom.jsonl`. Forge-the-package commits its own
wisdom so future agents working on Forge inherit it. Other repos
choose per-policy — keep wisdom local (don't commit), or share it
(commit). Same mechanism, different policy.

Full reference: [02-commands.md#forge-wisdom](02-commands.md#forge-wisdom).

### What is `surface.json` and why is it checked in?

`surface.json` (`v0.12.0`+) is the canonical artifact at the repo
root that emits the full MCP tool / recipe / schema-version registry.
Schema: `atomadic-forge.surface/v1`. Three CLI verbs maintain it:
`forge surface emit / check / diff`.

**Why checked in:** so downstream consumers (the website, the badge
worker, `cognition_worker.js`, the VS Code extension, agent
platforms) can fetch one artifact instead of maintaining a hand-
rolled tool map. `legacy_endpoint_map` lets stale callers resolve
retired names (`audit_list` → `lineage`, etc.) in one lookup.

**CI gate:** `.github/workflows/surface-drift.yml` runs `forge
surface check` on every PR that touches the registries OR
`surface.json`. On drift, the failure prints the one-line fix-up:
`forge surface emit --out surface.json && git add surface.json`.

Full reference: [02-commands.md#forge-surface](02-commands.md#forge-surface).

### Worker MCP and local Python MCP — are they the same?

Same tool *names*, different argument *contracts*. The Worker MCP at
`forge.atomadic.tech/mcp` accepts `args.repo` (owner/repo or GitHub
URL); the local Python MCP accepts `args.project_root` /
`args.target` (filesystem paths). 12 tools on the Worker are stubs
that redirect to local CLI today; v0.14 closes that with the Worker
→ Local-CLI relay (see [ROADMAP.md](ROADMAP.md#v0140--swarm-tier-substrate--worker--local-cli-relay)).

Full contract comparison: [WORKER_VS_LOCAL_MCP.md](WORKER_VS_LOCAL_MCP.md).

### Can I absorb multiple repos into one output?

Yes. Use `forge cherry` from repo-a, then `forge cherry` from repo-b, then `--on-conflict rename` to merge them:

```bash
forge cherry ./repo-a --pick all
# .atomadic-forge/cherry.json contains repo-a symbols

forge finalize ./repo-a ./output --apply --on-conflict rename --package merged

forge cherry ./repo-b --pick all
# Overwrites cherry.json with repo-b symbols

forge finalize ./repo-b ./output --apply --on-conflict rename --package merged
# Merges repo-b into the same output tree
```

Result: `output/src/merged/` contains both repos, with name collisions resolved via renaming.

## Installation & setup

### `pip install atomadic-forge` gives permission error

Try:
```bash
pip install --user atomadic-forge
# or
python -m pip install --user atomadic-forge
```

### Command `forge` not found

Install didn't register the CLI. Try:
```bash
python -m atomadic_forge --help
# or
pip install -e .
# (from the Forge repo)
```

### Tests are failing with httpbin errors

This is a known environment issue (httpbin/werkzeug version conflict). It's not Forge's code.

**Solution:**
```bash
pip uninstall pytest-httpbin -y
python -m pytest tests/
# Should pass (192 tests as of 0.2)
```

### DeprecationWarning about `datetime.utcnow()`

Fixed in the latest version. Update:
```bash
pip install --upgrade atomadic-forge
```

## Using forge auto

### Dry-run takes a long time

Dry-run still classifies every symbol and computes tiers. Large repos (5000+ files) can take time.

**Solution:** Use `forge recon` instead for just the analysis, without the full pipeline:
```bash
forge recon ./large-repo
# Faster: just stats, no full materialization
```

### Output has too many symbols I don't want

Use `forge cherry` to pick specific symbols:

```bash
forge cherry ./repo --pick ModuleA --pick ClassB
forge finalize ./repo ./output --apply
```

### Conflict resolution: what does `--on-conflict` do?

When two symbols have the same name (e.g., two `User` classes), Forge handles it:

- `rename` — Rename the second one (default): `User` → `User_1`
- `first` — Keep the first, skip the second
- `last` — Keep the last, overwrite the first
- `fail` — Error if a collision exists

```bash
# Keep only first repo's symbols
forge auto ./repo-a ./output --apply --on-conflict first

# Or rename collisions
forge auto ./repo-a ./output --apply --on-conflict rename
```

## Wire check (import violations)

### My code fails wire check. How do I fix it?

`forge wire` reports upward imports. Example:

```
a1_at_functions/utils.py: a1 ← a2_mo_composites.Store (upward import)
```

**This means:** `a1_at_functions/utils.py` imports from `a2_mo_composites/Store`, which is a tier violation.

**How to fix:**

**Option A:** Move `utils.py` to a higher tier (a2 or a3):

```bash
# Move the file
mv ./output/src/myapp/a1_at_functions/utils.py \
   ./output/src/myapp/a2_mo_composites/utils.py

# Update module docstring
# """Tier a2 — composite utilities"""
```

**Option B:** Extract pure logic into a1, leave stateful parts in a2:

```python
# a1_at_functions/parse_utils_pure.py
def parse_data(raw: str) -> dict:
    # Pure logic, no Store dependency
    return ...

# a2_mo_composites/data_processor.py
from ..a1_at_functions.parse_utils_pure import parse_data
from .Store import Store

def process_with_store(raw: str, store: Store) -> dict:
    parsed = parse_data(raw)  # Use pure helper
    return store.save(parsed)
```

**Option C:** Move the imported symbol to a lower tier:

```bash
# If Store's only job is to be used by a1 functions, 
# move Store from a2 to a1 (if it qualifies as pure)
```

### I'm getting "X violations" but the code works fine

Wire violations are **architectural**, not functional. Code can work fine but still violate the tiers.

Example: A pure function (a1) that imports a stateful class (a2) will *work*, but it violates the law because a1 should never depend on state.

**Why fix it?**
- Predictability: a1 functions are always composable without side effects
- Testability: Pure functions are trivial to test
- Maintainability: Clear boundaries prevent spaghetti code

Fix the violations before shipping.

## Certify scoring

### My code scores 50/100. How do I improve?

```
Certify: myapp
  documentation:       0/25 ← Add README.md
  tests:              25/25 ✓
  tier_layout:        25/25 ✓
  import_discipline:   0/25 ← Fix wire violations
  
  TOTAL: 50/100
```

**To reach 100:**
1. Add README.md and/or docs/ to reach 25/25 on documentation
2. Run `forge wire` and fix all violations to reach 25/25 on import_discipline

**To reach 75 (production-ready):**
- Fix the worst issues (documentation or import_discipline)
- Tests and tier_layout are usually OK after absorption

### Do I need 100/100 to ship?

No. 75+/100 is acceptable for production. But:
- Documentation (25 pts) is easy: add README.md
- Tests (25 pts) are worth doing (your existing tests are absorbed)
- Tier layout (25 pts) is automatic (Forge creates all 5 tiers)
- Import discipline (25 pts) is the hard one (requires manual fixes)

So aim for 75+ before shipping.

## LLM loops

### `forge iterate` generated bad code

Try:
1. Use a better provider (Claude > Gemini > GPT)
2. Be more specific in the intent prompt
3. Run more iterations (--max-iterations 5 instead of 3)
4. Inspect intermediate outputs and fix them manually

### Rate limit errors

```
Error: 429 Too Many Requests
```

**Solution:**
- Use local Ollama (no rate limits): `export FORGE_OLLAMA=1`
- Use stub provider for testing: `--provider stub`
- Wait a bit and retry

### Ollama is slow, crashing, or returns 500

First unload any large model that is still resident:

```bash
ollama ps
ollama stop codellama:7b-instruct
```

Then use the low-load Forge profile:

```bash
export FORGE_OLLAMA=1
export FORGE_OLLAMA_MODEL=qwen2.5-coder:1.5b
export FORGE_OLLAMA_NUM_PREDICT=768
export FORGE_OLLAMA_TIMEOUT=180
forge chat ask "Reply OK" --provider ollama --no-cwd-context
```

If that works, scale back up later to `qwen2.5-coder:7b` when the machine
is idle. If it still fails, restart Ollama and retry the one-line chat
smoke before running `iterate` or `evolve`.

### API key not found

```
Error: GEMINI_API_KEY not set
```

**Solution:**
```bash
export GEMINI_API_KEY=your-key-here
# Then try again
```

### Code quality declining over rounds

Forge detects stagnation:

```
Halt reason: stagnation_detected
```

This means the score stopped improving. **Fix manually:**

```bash
# Inspect what's wrong
forge wire ./output/src/myapp
cat ./output/STATUS.md

# Manually fix the issues
# Then run another iteration
```

## Performance & scalability

### forge auto is slow on large repos (10k+ files)

Forge classifies every symbol. On very large codebases, this takes time.

**Workarounds:**
- Use `forge cherry` to pick specific modules, absorb in batches
- Use `--provider stub` to test the pipeline without LLM calls
- Run on a faster machine

### Can I run Forge on a CI/CD pipeline?

Yes. Example GitHub Actions:

```yaml
- name: Absorb and verify
  run: |
    pip install atomadic-forge
    forge auto ./src ./output --apply --package myapp
    forge wire ./output/src/myapp
    forge certify ./output --package myapp
```

Example GitLab CI:

```yaml
absorb:
  script:
    - pip install atomadic-forge
    - forge auto ./src ./output --apply --package myapp
    - forge wire ./output/src/myapp
    - forge certify ./output --package myapp
```

## Advanced questions

### Can I customize the tier classification?

Not yet, but the scout report logs the rationale per symbol. You can override manually by moving files after absorption.

### Can I extend Forge with custom verbs?

Yes (roadmap for 0.2). The output is JSON at each stage (scout, cherry, assimilate, wire, certify). You can write custom tools that pipe this JSON.

Example:

```bash
forge auto ./repo ./output --json | \
  jq '.tier_dist' | \
  custom_analysis_script.py
```

### How is Forge licensed?

Business Source License 1.1 (BSL-1.1):
- **Free for non-production use** (development, testing, learning)
- **Commercial license required for production**
- **Converts to Apache 2.0 on 2030-04-27**

## Getting help

### I found a bug

Open an issue on GitHub: [atomadictech/atomadic-forge/issues](https://github.com/atomadictech/atomadic-forge/issues)

Include:
- What you ran
- What you expected
- What actually happened
- Output of `forge doctor`

### I want to contribute

See [CONTRIBUTING.md](../CONTRIBUTING.md)

### I have a feature request

File an issue on GitHub with the `feature-request` label.

## Using Forge from a coding agent

### Can I plug Forge into Cursor / Claude Code / Aider / Devin?

Yes — Forge ships an **MCP server**. Add this to your agent's MCP
config:

```json
{
  "mcpServers": {
    "atomadic-forge": {
      "command": "forge",
      "args": ["mcp", "serve", "--project", "."],
      "transport": "stdio"
    }
  }
}
```

Once registered (Forge ≥ v0.14.0a10), the agent gets **61 tools** + **5
resources**. The 61 tools group into *inventory / utility* (`recon` /
`wire` / `certify` / `verify` / `enforce` / `lineage` /
`emergent_scan` / `emergent_swarm` / `synergy_scan` / `doctor` /
`sidecar_validate` / `manifest_diff` / `call_graph` / `smell_scan` /
`wisdom_record` + `wisdom_query` + `wisdom_list` + `wisdom_recall` /
`surface`), *action loop* (`plan` / `plan_apply`), *Copilot's
Copilot* (`context_pack` / `preflight_change` / `score_patch` /
`select_tests` / `rollback_plan` / `explain_repo` / `compose_tools` /
`load_policy` / `recipes` / `forge_locate` / `commit_compose` /
`cna_check` / `trust_gate_response`), *transmuter / cross-repo*
(`auto` / `cherry` / `finalize` / `iterate_start` /
`iterate_continue` / `evolve_start` / `evolve_step` / `harvest` /
`recon_swarm` / `tool_factory` / `guard_install`), *hive
coordination* (`hive_register` / `hive_observe` / `hive_propose` /
`hive_vote` / `hive_result` / `hive_list` / `hive_deactivate` /
`hive_needs_vote` / `hive_recap` since v0.14.0a9–v0.14.0a10), and
*AAAA-Nexus primitives* (`nexus_identity_verify` / `nexus_federation_mint` /
`nexus_authorize_action` / `nexus_sys_trust_gate` / `nexus_contract_verify` /
`nexus_lineage_record` / `nexus_ratchet_register` since v0.14.0a7).
See the full **[Agents Guide](AGENTS_GUIDE.md)** for
integration patterns, the agent-friendly `context_pack` and
`explain_repo` tools, the Forge Receipt schema agents should
consume, F-code routing for mechanical fixes, the proposal-engine
flow, and best practices.

For MCP troubleshooting, run `forge mcp doctor --project . --json`.
As of `0.5.2`, `tools/list` also includes a `cli_command` fallback for
each MCP tool, and validation hints are language-aware.

### What's the difference between AGENTS.md and the Agents Guide?

- **`AGENTS.md`** at the repo root is for agents *building* Forge —
  the dev contract: tier discipline, F-code namespace, schema
  versioning, branch hygiene, the verification lane.
- **`docs/AGENTS_GUIDE.md`** is for agents *using* Forge — Cursor /
  Claude Code / Aider / etc. integrating via MCP, calling the 23
  tools, consuming Receipts, running `preflight_change` /
  `score_patch` guardrails, applying mechanical fixes via `enforce`.

Both files together describe a complete agent contract: how to ship
*to* Forge and how to ship *with* Forge.

## Further reading

- [Getting started](01-getting-started.md)
- [Command reference](02-commands.md)
- [Tutorial: Absorb a real repo](03-tutorial.md)
- [LLM loops](04-llm-loops.md)
- **[Agents Guide — using Forge from an MCP client](AGENTS_GUIDE.md)**
- [Forge Receipt schema](RECEIPT.md)
- [Architecture guide](../ARCHITECTURE.md)
- [Dev-agent operating manual (`AGENTS.md`)](../AGENTS.md)
