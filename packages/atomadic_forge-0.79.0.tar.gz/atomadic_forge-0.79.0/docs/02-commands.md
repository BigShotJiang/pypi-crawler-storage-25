# Command Reference

All Forge commands are available via `forge VERB [OPTIONS] [ARGS]`.

For help: `forge --help` or `forge VERB --help`.

## Setup and configuration

### forge init

**Start here.** Interactive 5-step wizard that configures your LLM provider, API keys, project defaults, and writes `.atomadic-forge/config.json`.

```bash
forge init
```

**What it does (5 steps):**

1. **LLM Provider** — choose Ollama, Gemini, Claude, OpenAI, or Auto
2. **Model selection** — lists available Ollama models; recommends cloud models
3. **API key** — masked password input with immediate validation (skipped for Ollama/Auto)
4. **Project defaults** — target score, auto-apply flag, output/source directories
5. **Verification** — tests the LLM connection and prints a configuration summary

**Example flow:**

```
╭─ Atomadic Forge — Setup   [Step 1/5: LLM Provider] ─╮
│                                                       │
│  [1] Ollama (local, free, private)                    │
│  [2] Gemini (Google)                                  │
│  [3] Claude (Anthropic)                               │
│  [4] OpenAI (GPT)                                     │
│  [5] Auto (detect best available)                     │
│                                                       │
╰───────────────────────────────────────────────────────╯
Select provider [5]:
```

After all steps, a summary panel is printed and config is saved to `.atomadic-forge/config.json`.

**Notes:**
- Completely safe to re-run; existing values are offered as defaults at every prompt.
- Use `forge config wizard` for the same wizard from within the `config` sub-group.
- Config priority: local `.atomadic-forge/config.json` → global `~/.atomadic-forge/config.json` → built-in defaults.

---

### forge config

Config management sub-group: show, set, test, wizard.

```bash
forge config SUBCOMMAND [OPTIONS]
```

**Subcommands:**

#### forge config show

Print the current merged configuration (local → global → defaults).

```bash
forge config show [--project DIR] [--json]
```

**Options:**
- `--project DIR` — project directory to load local config from (default: cwd)
- `--json` — emit a JSON object `{config: {...}, issues: [...]}`

**Example:**

```bash
forge config show
# Output:
# Atomadic Forge — config
# --------------------------------------------
#   provider                     auto
#   ollama_url                   http://localhost:11434
#   ollama_model                 mistral:7b-instruct
#   gemini_key                   (not set)
#   default_target_score         75.0
#   auto_apply                   False
#   output_dir                   ./forged
#   sources_dir                  ./sources
#   package_prefix               forged
#
#   Config is valid.

forge config show --json
```

API keys are automatically masked (first 8 + last 4 chars) in human-readable output.

---

#### forge config set

Set a single config key in the local (or global) config file.

```bash
forge config set KEY VALUE [--project DIR] [--global]
```

**Arguments:**
- `KEY` — config key to set (e.g. `provider`, `ollama_model`, `default_target_score`)
- `VALUE` — value to assign (automatically coerced: `true`/`false` → bool, numeric → int/float)

**Options:**
- `--project DIR` — project directory (default: cwd)
- `--global` — write to `~/.atomadic-forge/config.json` instead of `.atomadic-forge/config.json`

**Examples:**

```bash
# Set provider for this project
forge config set provider ollama

# Set target score (auto-coerced to float)
forge config set default_target_score 80.0

# Enable auto-apply globally
forge config set auto_apply true --global

# Set Ollama model
forge config set ollama_model qwen2.5-coder:7b
```

---

#### forge config test

Test the configured LLM provider connection.

```bash
forge config test [--project DIR] [--provider PROVIDER] [--json]
```

**Options:**
- `--provider PROVIDER` — override the configured provider for this test only
- `--project DIR` — project directory (default: cwd)
- `--json` — emit `{ok, model, error, latency_ms}`

**Examples:**

```bash
# Test whatever provider is configured
forge config test

# Test a specific provider
forge config test --provider ollama
forge config test --provider stub   # always succeeds, no network call

# JSON output (good for scripting)
forge config test --json
```

**Output:**

```
Provider test — ollama

  Status:    OK
  Model:     mistral:7b-instruct
  Latency:   143ms
```

---

#### forge config wizard

Same as `forge init` — runs the interactive 5-step setup wizard.

```bash
forge config wizard [--project DIR]
```

---

## Core commands (the absorb pipeline)

### forge auto

**Flagship command.** Scout → cherry-pick → materialize → wire → certify in one shot.

```bash
forge auto TARGET OUTPUT [OPTIONS]
```

**Arguments:**
- `TARGET` — Path to source repository to absorb
- `OUTPUT` — Path where materialized tier tree will be written

**Options:**
- `--package NAME` — Python package name (default: `absorbed`)
- `--apply` — Actually write files (default: dry-run)
- `--on-conflict STRATEGY` — How to handle name collisions: `rename` | `first` | `last` | `fail` (default: `rename`)
- `--json` — Output JSON instead of human-readable

**Example:**

```bash
# Dry-run: see what would happen
forge auto ./legacy-repo ./output

# Actually apply
forge auto ./legacy-repo ./output --apply --package myapp

# Apply with conflict strategy
forge auto ./repo-a ./output --apply --package merged --on-conflict rename
```

**Output:**
- Materialized tier tree at `output/src/PACKAGE/`
- STATUS.md listing required follow-up
- .atomadic-forge/ diagnostics (scout, cherry, assimilate, wire, certify)

---

### forge recon

Walk a repository, classify every public symbol, show tier/effect
distributions. Polyglot: walks Python (`.py`), JavaScript
(`.js`/`.mjs`/`.cjs`/`.jsx`), and TypeScript (`.ts`/`.tsx`) in a single
pass; `node_modules/`, `dist/`, `.next/`, `.wrangler/` and friends are
skipped automatically.

```bash
forge recon TARGET [OPTIONS]
```

**Arguments:**
- `TARGET` — Path to repository to analyze

**Options:**
- `--json` — Output full JSON report (includes per-symbol rationale and `suggested_tier`)

**Example (Python repo):**

```bash
forge recon ./repo
# Recon: ./repo
# ------------------------------------------------------------
#   python files:     45
#   javascript files: 0
#   typescript files: 0
#   primary language: python
#   symbols:          222
#   tier dist:        {a0: 7, a1: 130, a2: 42, a3: 32, a4: 11}
#   effect dist:      {pure: 210, state: 0, io: 12}
```

**Example (JavaScript / Cloudflare Worker repo):**

```bash
forge recon ./my-worker
# Recon: ./my-worker
# ------------------------------------------------------------
#   python files:     0
#   javascript files: 4
#   typescript files: 1
#   primary language: javascript
#   symbols:          17
#   tier dist:        {a0: 1, a1: 2, a2: 1, a4: 1}
#   effect dist:      {pure: 9, state: 5, io: 3}
#   recommendations:
#     - JS/TS files are not yet split into aN_* tier directories —
#       see suggested_tier per file in symbols[].
```

The JSON output contains a `language_distribution` map keyed by
`"python"` / `"javascript"` / `"typescript"`, and per-symbol
`suggested_tier` so you can see where Forge would place each file under
the 5-tier law.

```bash
forge recon ./repo --json > report.json
```

---

### forge cherry

Build a cherry-pick manifest (which symbols to absorb).

```bash
forge cherry TARGET [OPTIONS]
```

**Arguments:**
- `TARGET` — Path to repository

**Options:**
- `--pick all` — Include all symbols (default)
- `--pick QUALNAME` — Include specific symbol (repeat to add more)

**Example:**

```bash
# Pick all symbols
forge cherry ./repo --pick all

# Pick specific symbols only
forge cherry ./repo --pick Module.function --pick Class
```

**Output:**
- Cherry manifest at `.atomadic-forge/cherry.json`

---

### forge finalize

Materialize, wire, certify (the second half of the absorb pipeline).

Useful if you want to customize the cherry-pick before materialization.

```bash
forge finalize TARGET OUTPUT [OPTIONS]
```

**Arguments:**
- `TARGET` — Repository or path with `.atomadic-forge/cherry.json`
- `OUTPUT` — Destination for materialized tree

**Options:**
- `--apply` — Write files
- `--package NAME` — Python package name

**Example:**

```bash
# Step 1: Scout and cherry-pick
forge recon ./repo
forge cherry ./repo --pick all

# Step 2: Materialize
forge finalize ./repo ./output --apply --package myapp
```

---

### forge wire

Scan a tier-organized package for upward-import violations. Polyglot —
detects violations in Python `from`-imports and JS/TS module specifiers
(`"../a3_og_features/foo"`) alike. `node_modules/` is skipped.

```bash
forge wire PACKAGE [OPTIONS]
```

**Arguments:**
- `PACKAGE` — Path to tier-organized package root (a0, a1, a2, a3, a4 directories)

**Options:**
- `--json` — Output JSON violation list (each violation includes `language: "python" | "javascript" | "typescript"`)

**Example (Python):**

```bash
forge wire ./output/src/myapp

# Wire scan: ./output/src/myapp
#   verdict:    FAIL
#   violations: 5
#     - a1_at_functions/helper.py: a1 ← a2_mo_composites.Store (upward import)
#     - a0_qk_constants/config.py: a0 ← a1_at_functions.parse_config
#     ... (list of violations)
```

**Example (JavaScript):**

```bash
forge wire ./packages/web

# Wire scan: ./packages/web
#   verdict:    FAIL
#   violations: 1
#     - a1_at_functions/echo.js: a1 ⟵ a3_og_features.../a3_og_features/feature.js
```

The JSON form makes the language explicit:

```json
{
  "schema_version": "atomadic-forge.wire/v1",
  "violations": [
    {
      "file": "a1_at_functions/echo.js",
      "from_tier": "a1_at_functions",
      "to_tier": "a3_og_features",
      "imported": "../a3_og_features/feature.js",
      "language": "javascript"
    }
  ],
  "verdict": "FAIL"
}
```

**What violations mean:**
- `a1 ← a2` — Function imports from Composite (illegal)
- `a0 ← a1` — Constant imports from Function (illegal)
- Other tiers can import upward but are constrained by their layer

**Fixing violations:**
Move the offending import to a higher tier, or move the imported symbol to a lower tier.

---

### forge certify

Score conformance: documentation, tests, tier layout, import discipline,
runtime importability (Python only), and behavioural pytest pass-ratio
(Python only). Polyglot-aware where it can be:

- `tests` PASS recognises Python (`tests/test_*.py`, `*_test.py`) AND
  JavaScript / TypeScript (`tests/*.test.{js,mjs,jsx,cjs,ts,tsx}`,
  `*.spec.*`, and the Jest `__tests__/` directory convention).
- `tier_layout` PASS counts JS-style top-level or nested `aN_*`
  directories anywhere under the repo root, not just under
  `src/<pkg>/`. Failure messages name how many tiers were found and
  which (e.g. *"found 2 tier directories (a1_at_functions,
  a4_sy_orchestration); need 3+"*).
- The runtime-import smoke (+25 points, runs `python -c "import <pkg>"`
  in a fresh subprocess) and the behavioural pytest gate (+30 points)
  remain Python-only. JS/TS-only packages are scored on the +45
  polyglot-aware structural axes (docs / tests-present / tier layout /
  upward-import discipline).

```bash
forge certify OUTPUT [OPTIONS]
```

**Arguments:**
- `OUTPUT` — Path to materialized tree (or root with `--package`)

**Options:**
- `--package NAME` — Python package name (if not in root)
- `--fail-under SCORE` — Exit 1 when the score is below this threshold
- `--skip-tests` — Skip the pytest run; credits the behavioural axis at
  1.0 and adds `tests_skipped: true` to the result. Reduces runtime from
  ~40s to ~500ms. Use in CI pipelines that run pytest separately.
- `--json` — Output JSON

**Example:**

```bash
forge certify ./output --package myapp
forge certify ./output --package myapp --fail-under 90

# Fast mode: skip pytest (useful when tests run in a separate CI step)
forge certify ./output --package myapp --skip-tests

# Output:
# Certify: myapp
#   documentation: 25/25 ✓ (README.md present)
#   tests:         25/25 ✓ (tests/ directory present)
#   tier_layout:   25/25 ✓ (5/5 tiers used)
#   import_discipline: 0/25 ✗ (5 violations from wire)
#   
#   TOTAL: 75/100 (needs work: fix upward imports)
```

**Scoring:**
- Structural: docs (10), tier layout (10), upward-import discipline (10),
  tests present (5)
- Runtime: package import smoke (25)
- Behavioural: generated Python tests pass-ratio (up to 30)
- Stub bodies (`pass`, `NotImplementedError`, TODO implementations) deduct
  points even when imports and tests are present
- ≥75 = acceptable for a generated package; ≥90 is release-candidate quality
- <50 = needs significant work

---

## LLM loop commands

### forge chat

Chat copilot over Forge docs/source and your configured AI agent.

```bash
forge chat SUBCOMMAND [OPTIONS]
```

**Subcommands:**
- `ask "QUESTION"` — One-shot answer, optionally JSON
- `repl` — Interactive terminal session; type `/exit` to leave

**Options:**
- `--provider PROVIDER` — `auto` | `nexus` | `aaaa-nexus` | `gemini` |
  `anthropic` | `openai` | `openrouter` | `ollama` | `stub`
- `--context PATH` / `-c PATH` — file or directory to include. Repeatable.
- `--cwd-context / --no-cwd-context` — default is to use cwd when no explicit
  `--context` is supplied.
- `--max-files N` and `--max-chars N` — bound the context sent to the provider.

**Examples:**

```bash
# Ask with bounded current-repo context
forge chat ask "what CLI checks should I run before publishing?"

# Use your AAAA-Nexus agent as the copilot
export AAAA_NEXUS_API_KEY=an_...
forge chat repl --provider nexus --context src --context docs

# Scriptable offline smoke
forge chat ask "hello" --provider stub --no-cwd-context --json
```

The context packer skips ignored directories, assets, `.env`, key/certificate
files, and filenames containing obvious secret/credential markers.

---

### forge iterate

LLM loop: user intent → code → absorb → wire → score → iterate.

Single shot (one user prompt → N iterations → done).

```bash
forge iterate SUBCOMMAND [OPTIONS]
```

**Subcommands:**
- `run "INTENT" OUTPUT` — Execute the loop
- `preflight "INTENT"` — Dry-run (show system prompt + first user prompt, no LLM call)

**Options (for `run`):**
- `--package NAME` — Python package name
- `--provider PROVIDER` — LLM provider: `gemini` | `nexus` | `aaaa-nexus` | `anthropic` | `openai` | `openrouter` | `ollama` | `stub` | `auto` (default: `auto`)
- `--max-iterations N` — Max rounds (default: 4)
- `--seed PATH` — Absorb a repo's symbol catalog into the LLM context as building-block hints. Repeat the flag to provide multiple seed repos.

**Environment variables:**
- `AAAA_NEXUS_API_KEY` — For `--provider nexus` / `aaaa-nexus`
- `ANTHROPIC_API_KEY` — For `--provider anthropic`
- `GEMINI_API_KEY` / `GOOGLE_API_KEY` — For `--provider gemini`
- `OPENAI_API_KEY` — For `--provider openai`
- `OPENROUTER_API_KEY` — For `--provider openrouter`; override model with `FORGE_OPENROUTER_MODEL`
- `FORGE_OLLAMA=1` — Enable Ollama (must be running on localhost:11434)
- `FORGE_OLLAMA_MODEL` — Local model, default `qwen2.5-coder:7b`
- `FORGE_OLLAMA_NUM_PREDICT` — Cap local output tokens per call
- `FORGE_OLLAMA_TIMEOUT` — Local provider read timeout in seconds
- `OLLAMA_BASE_URL` — Alternate Ollama endpoint

**Example:**

```bash
export GEMINI_API_KEY=your-key-here

# Dry-run: see system prompt + first user message
forge iterate preflight "Build a tiny calculator CLI"

# Execute with Gemini (free tier)
forge iterate run "Build a tiny calculator CLI" ./output \
    --package calc --provider gemini --max-iterations 4

# Execute with AAAA-Nexus (reliable for long runs)
export AAAA_NEXUS_API_KEY=an_...
forge iterate run "..." ./output --provider nexus

# Execute with OpenRouter (free tier — 200+ models)
export OPENROUTER_API_KEY=sk-or-...
forge iterate run "..." ./output --provider openrouter

# Execute with a low-load local model on a busy PC
export FORGE_OLLAMA=1
export FORGE_OLLAMA_MODEL=qwen2.5-coder:1.5b
export FORGE_OLLAMA_NUM_PREDICT=768
export FORGE_OLLAMA_TIMEOUT=180
forge iterate run "..." ./output --provider ollama --max-iterations 2

# Execute with Claude (paid)
export ANTHROPIC_API_KEY=sk-...
forge iterate run "..." ./output --provider anthropic

# Use local Ollama (free, fully private)
# First: ollama run qwen2.5-coder:7b
forge iterate run "..." ./output --provider ollama

# Multi-seed: provide two absorbed repos as building-block context
forge iterate run "Build a tool-use agent" ./output \
    --seed ./forged/langchain-picks \
    --seed ./forged/mem0-picks \
    --provider nexus --max-iterations 4
```

**Output:**
- Materialized code at `output/src/PACKAGE/`
- Transcript of LLM loop iterations in `iterate.json`
- Wire violations and certify scores logged per round
- Python outputs also get `.atomadic-forge/quality.json`, generated
  `docs/API.md`, `docs/TESTING.md`, missing docstrings, and
  `tests/test_generated_smoke.py`

---

### forge evolve

Recursive self-improvement: N rounds of `iterate`, catalog grows each round.

```bash
forge evolve SUBCOMMAND [OPTIONS]
```

**Subcommands:**
- `run "INTENT" OUTPUT` — Execute N rounds

**Options:**
- `--auto N` — Run exactly N rounds
- `--target-score SCORE` — Keep improving until reaching score (default: none)
- `--package NAME` — Python package name
- `--provider PROVIDER` — LLM provider (see `iterate`)

**Example:**

```bash
# Run exactly 5 rounds
forge evolve run "Build a markdown-to-PDF service" ./output \
    --auto 5 --provider gemini --package pdf_service

# Run until reaching score of 80/100
forge evolve run "..." ./output \
    --target-score 80 --provider gemini
```

**How it works:**
1. Round 1: Generate initial code from intent
2. Round 2: Absorb round 1 code, identify missing pieces, generate new features
3. Round 3: Absorb rounds 1+2, improve further
4. ... repeat until `--auto N` rounds or `--target-score` reached

**Output:**
- Final merged code at `output/src/PACKAGE/`
- Per-round reports showing score trajectory
- Halt reason (`rounds_exhausted` | `target_score_reached` | `stagnation_detected`)
- Each Python round includes the same quality phases as `iterate`: generated
  docstrings, docs, and import-smoke tests before final scoring

---

## Specialty commands

### forge emergent

Symbol-level composition discovery — find chains where output of A flows into B.

```bash
forge emergent SUBCOMMAND [OPTIONS]
```

**Subcommands:**
- `scan` — Scan a tier tree, return composition chains
- `synthesize CANDIDATE_ID` — Materialize one candidate as an a3 feature module
- `show CANDIDATE_ID` — Print one candidate's full chain + score breakdown

**Important flags:**
- `--src-root DIR` — Path to the `src/` dir (defaults to `src/`)
- `--package NAME` — Importable package name to scan (defaults to `atomadic_forge`)

> **Tip:** Always pass `--src-root` and `--package` for third-party repos.
> The bare `forge emergent scan` defaults to scanning Forge's own catalog.

**Example:**

```bash
forge emergent scan --src-root ./output/src --package myapp
# 354 catalog · 32 domains · 15 candidates returned
```

---

### forge materialize  *(v0.15.0+)*

Turn an emergent scan report into a real, pip-installable Python package
with proper tier layout (a0..a4 + tests + pyproject + README + .gitignore)
and one a3 feature module + smoke test per selected candidate.

```bash
forge materialize run --report PATH --out-dir DIR --package NAME [--top-n N]
```

**What it does:**
- Reads an `emergent scan` JSON report (or accepts one over stdin).
- Picks the top-N candidates and generates one tier-clean module per pick.
- Scaffolds `pyproject.toml`, `README.md`, `.gitignore`, `tests/` with a
  smoke test per generated module.
- Runs `forge wire` and `forge certify` on the new package and embeds
  the verdict into the receipt at `.atomadic-forge/materialize.json`.
- Refuses to overwrite a non-empty unrelated directory.

**Example:**

```bash
forge emergent scan --src-root src --package myapp --save scan.json
forge materialize run --report scan.json --out-dir ./toolkit --package toolkit --top-n 5
```

---

### forge create  *(v0.15.0+)*

One-command pipeline: **intent + seed repos → shippable package**. Resolves
local seed-repo paths, runs `emergent_swarm` across them, persists scan +
receipt to `.atomadic-forge/`, then pipes through `materialize` for the
final package.

```bash
forge create -i "INTENT" -s SEED_REPO [-s SEED_REPO ...] \
             --out-dir DIR --package NAME [--top-n N]
```

**Required:**
- `-i, --intent TEXT` — Plain-English description of the package
- `--out-dir DIR` — Where to write the new package
- `--package NAME` — Importable Python package name

**Useful flags:**
- `-s, --seed-repo DIR` — Local repo to scan (repeatable, max 23). Auto-detects
  either `src/<pkg>/` layout or a tier-bearing package dir.
- `--top-n N` — Materialize the top-N candidates (default 5)
- `--swarm-depth N` — Max chain length for emergent_swarm (default 3)
- `--require-pure` — Restrict to chains where every step is heuristically pure
- `--no-certify` — Skip the certify pass on the new package
- `--json` — Emit machine-readable JSON

**End-to-end example (cross-repo):**

```bash
forge create -i "cross-repo agent toolkit" \
  -s ./atomadic-forge \
  -s ./crewai/lib/crewai \
  --out-dir ./agent_toolkit \
  --package agent_toolkit \
  --top-n 5
# 18 cross-repo chains · 5 picks · 21 files written · wire PASS
```

The materialised package contains importable a3 feature modules wiring the
discovered chains together. Class-method qualnames are detected (Python
class methods can't be imported as `pkg.mod.Class.method`) and the
generated module emits a `# NOTE: wire the receiver manually.` line for
those steps instead.

> **Layout requirement:** seed repos must have `src/<pkg>/` or top-level
> `aN_*` tier directories. Use `forge auto` first if the seed has neither.

---

### forge synergy

Feature-level producer/consumer detection + auto-generate adapters.

```bash
forge synergy SUBCOMMAND [OPTIONS]
```

**Subcommands:**
- `scan [PACKAGE]` — Detect synergies (5 kinds: json_artifact, in_memory_pipe, etc.)
- `implement` — Auto-generate adapter modules (marked with `# REVIEW:`)

**Example:**

```bash
forge synergy scan ./output/src/myapp
forge synergy implement ./output/src/myapp
```

---

### forge emergent-then-synergy

Pipeline adapter: run `forge emergent scan` and pipe the result into
`forge synergy scan`. Useful for discovering composition chains and
immediately finding feature wiring opportunities in one step.

```bash
forge emergent-then-synergy
```

---

### forge synergy-then-emergent

Pipeline adapter: run `forge synergy scan` and pipe the result into
`forge emergent scan`. Surfaces emergent type-compatibility chains for
features that synergy already identified as producer/consumer pairs.

```bash
forge synergy-then-emergent
```

---

### forge evolve-then-iterate

Pipeline adapter: run `forge evolve run` and immediately follow with
`forge iterate run` on the evolved catalog. Useful for a final single-shot
refinement pass after recursive self-improvement converges.

```bash
forge evolve-then-iterate
```

---

### forge commandsmith

Auto-register CLI commands and regenerate `_registry.py`.

```bash
forge commandsmith SUBCOMMAND [OPTIONS]
```

**Subcommands:**
- `discover` — Find all CLI commands in `commands/`
- `sync` — Regenerate registry + docs + smoke-test results

**Example:**

```bash
forge commandsmith sync ./output/src/myapp
```

---

## Utility commands

### forge doctor

Print environment diagnostic.

```bash
forge doctor
```

**Output:**
```
Atomadic Forge — doctor
  atomadic_forge_version   0.1.0
  python                   3.12.10
  executable               /usr/bin/python3.12
  platform                 linux
  stdout_encoding          utf-8
```

---

## Surface and introspection commands

### forge surface

Emit, verify, and diff the canonical `surface.json` artifact — the
single source of truth for Forge's tool/recipe/schema registry.

```bash
forge surface SUBCOMMAND [OPTIONS]
```

**Subcommands:**

#### forge surface emit

Emit the canonical artifact to stdout or a file.

```bash
forge surface emit [--out PATH]
```

**Options:**
- `--out PATH` — write to a file instead of stdout (use `--out surface.json` to update the checked-in artifact)

```bash
# Print to stdout
forge surface emit

# Write to canonical location (update the artifact)
forge surface emit --out surface.json
```

---

#### forge surface check

CI gate: exit 1 if the on-disk `surface.json` drifts from the
computed canonical. Used by `.github/workflows/surface-drift.yml`.

```bash
forge surface check [--path surface.json]
```

**Options:**
- `--path PATH` — path to the existing artifact (default: `surface.json`)

If drift is detected, the error message prints the fix-up command:

```
forge surface emit --out surface.json && git add surface.json
```

Comparison ignores `generated_at_utc` so re-emitting on unchanged
inputs always passes.

---

#### forge surface diff

Report the public delta between two `surface.json` files. Used by the
auto-CHANGELOG generator.

```bash
forge surface diff BEFORE AFTER [--json]
```

**Arguments:**
- `BEFORE` — path to the older artifact
- `AFTER` — path to the newer artifact

**Options:**
- `--json` — emit structured JSON delta

**Output columns:** tools added/removed/schema-changed, recipes
added/removed.

---

> **MCP contract note:** the Worker MCP at `forge.atomadic.tech/mcp`
> and the local Python MCP share tool names but accept different
> arguments. See [WORKER_VS_LOCAL_MCP.md](WORKER_VS_LOCAL_MCP.md) for
> the full contract comparison before debugging Worker calls.

---

## Wisdom commands

### forge wisdom

Append-only institutional memory for a repo. Wisdom entries survive
session boundaries and are surfaced automatically by `forge recon`
(prior knowledge before work) and `forge verify` (capture prompt after
work).

> **MCP surface (since v0.13.1).** Each subcommand has a 1:1 MCP tool:
> `forge wisdom record` ≡ `wisdom_record`,
> `forge wisdom query` ≡ `wisdom_query`,
> `forge wisdom list` ≡ `wisdom_list`,
> `forge wisdom recall` ≡ `wisdom_recall`.
> Agents that prefer the structured-tool surface (better lineage,
> trust-gated, observable) can call the MCP tool directly instead of
> shelling out to the CLI. The `wisdom_capture_prompt.next_command`
> string returned by `verify` still emits the CLI form; agents can
> either run it verbatim or translate the args into the MCP call.

```bash
forge wisdom SUBCOMMAND [OPTIONS]
```

**Subcommands:**

#### forge wisdom record

Append a new wisdom entry.

```bash
forge wisdom record --insight "TEXT" [--scope SCOPE] [--tags TAG ...] \
  [--confidence FLOAT] [--evidence PATH ...]
```

**Options:**
- `--insight TEXT` — the lesson (required)
- `--scope SCOPE` — `forge`, `general`, or a custom repo name (default: `general`)
- `--tags TAG` — repeatable; used for retrieval ranking
- `--confidence FLOAT` — 0.0–1.0 (default: `0.8`)
- `--evidence PATH` — repeatable; file path or qualname that backs the claim

```bash
forge wisdom record \
  --insight "Worker MCP requires args.repo; local MCP requires args.project_root" \
  --scope forge \
  --tags contract drift mcp worker \
  --confidence 0.95 \
  --evidence docs/WORKER_VS_LOCAL_MCP.md
```

---

#### forge wisdom query

Relevance-ranked search over the active wisdom DB.

```bash
forge wisdom query [QUERY] [--scope SCOPE] [--tags TAG ...] \
  [--top-n N] [--project-root DIR]
```

**Options:**
- `QUERY` — free-text query matched by substring
- `--scope SCOPE` — filter by scope
- `--tags TAG` — filter by tag (repeatable)
- `--top-n N` — return top N entries (default: 5)

```bash
# Find all wisdom about MCP contracts
forge wisdom query "mcp contract" --tags mcp

# Find forge-scoped entries about drift
forge wisdom query --scope forge --tags drift
```

---

#### forge wisdom list

Full DB read. Active entries only by default.

```bash
forge wisdom list [--include-superseded] [--project-root DIR]
```

**Options:**
- `--include-superseded` — also return entries marked superseded

---

#### forge wisdom recall

Top-N repo-scoped wisdom — the same surface `forge recon` exposes via
its `prior_wisdom` field, available as a standalone call.

```bash
forge wisdom recall [--project-root DIR] [--top-n N]
```

```bash
# What does this repo already know?
forge wisdom recall --project-root .
```

---

#### forge wisdom promote (since v0.13.3)

Cluster active wisdom by tag overlap; emit draft recipes from
clusters that meet the corroboration threshold. Pure clustering —
no LLM. The bridge between provisional knowledge and curated
process.

```bash
forge wisdom promote [--min-corroboration N] [--min-tag-overlap N] [--write]
```

**Options:**
- `--min-corroboration N` — minimum entries per cluster to promote (default: 3)
- `--min-tag-overlap N` — minimum shared tags between cluster members (default: 1)
- `--write` — actually write draft recipes to `_private/research/recipe_drafts/<name>.md`. Without this flag, returns the drafts in the response payload only (dry-run preview).

```bash
# Preview what would be promoted
forge wisdom promote

# Apply: write drafts to _private/research/recipe_drafts/
forge wisdom promote --write

# Tighter clustering
forge wisdom promote --min-corroboration 5 --min-tag-overlap 2 --write
```

**MCP equivalent:** `wisdom_promote`.

---

#### forge wisdom record --nexus (since v0.14.0a5)

Extends `forge wisdom record` with an opt-in mirror to AAAA-Nexus's
LIVE `lineage_record` primitive. Confidence threshold: ≥0.85.

```bash
forge wisdom record --insight "..." --confidence 0.95 --nexus
```

**Behaviour:**
- Local entry written to `.atomadic-forge/wisdom.jsonl` (canonical).
- If `--nexus` is set AND confidence ≥0.85, also POSTs to AAAA-Nexus
  `lineage_record` for cross-repo institutional memory.
- Best-effort: degrades silently on auth / network failure. Local
  entry stays canonical regardless.
- Refuses to call any Nexus primitive outside the 7-LIVE set
  (`identity_verify`, `federation_mint`, `authorize_action`,
  `sys_trust_gate`, `contract_verify`, `lineage_record`,
  `ratchet_register`) via `NexusToolNotShipped` guard.

**Auto-hooks (no extra commands required):**

- `forge recon TARGET` — response includes `prior_wisdom` (top-5
  relevant entries). Agents inherit institutional knowledge before
  doing any work.
- `forge verify` — response includes `wisdom_capture_prompt` when trust
  thresholds are met (≥3 lineage events, or ≥1.0 score delta, or ≥5
  min session). Contains a draft insight + suggested `next_command` for
  one-call recording. Below threshold: `auto_record_threshold_met:
  false`, `next_command: null`.

**Storage:** `.atomadic-forge/wisdom.jsonl` — append-only JSONL,
schema-versioned (`atomadic-forge.wisdom/v1`), content-addressed IDs.
Committed to source when you want future agents to inherit knowledge;
kept local when you don't.

---

## AAAA-Nexus primitive tools (v0.14.0a7+)

The seven LIVE AAAA-Nexus primitives are exposed as Forge MCP tools.
There is no CLI verb — these are MCP-only. The CLI flag equivalents
are `forge wisdom record --nexus` (mirrors to `lineage_record`) and
`forge hive result --nexus` (mirrors a resolution to `lineage_record`).

| MCP tool | AAAA-Nexus primitive | Purpose |
|---|---|---|
| `nexus_identity_verify` | `identity_verify` | Caller identity attestation. |
| `nexus_federation_mint` | `federation_mint` | Portable federation token bound to a DID. |
| `nexus_authorize_action` | `authorize_action` | Pre-call permission check. |
| `nexus_sys_trust_gate` | `sys_trust_gate` | Drift / hallucination check pre-dispatch. |
| `nexus_contract_verify` | `contract_verify` | Manifest-drift check vs subscription. |
| `nexus_lineage_record` | `lineage_record` | Persistent lineage of a dispatch chain. |
| `nexus_ratchet_register` | `ratchet_register` | Anti-replay ratchet stamp. |

**Auth precedence:** `subscription > master`. Set
`AAAA_NEXUS_API_KEY` (subscription) or `FORGE_MASTER_API_KEY`
(master) — Forge picks the highest-priority value present.

**Hard guard:** the underlying `NexusClient` raises
`NexusToolNotShipped` if any tool name outside the 7 LIVE primitives
is requested — by design, per `WIS-cog-2026-05-06-handshake`.
Planned-but-vapor names (`nexus_consensus_*`, `nexus_swarm_*`,
`nexus_agent_*`) are **not** callable.

**Failure semantics:** all seven return structured `ok=False`
responses on auth / network failure rather than raising. The caller
decides whether to degrade or retry.

---

## Worker → Local relay commands (v0.14.0a1+)

### forge relay

A thin stdlib HTTP service that lets the Worker MCP at
`forge.atomadic.tech/mcp` forward signed JSON-RPC envelopes to a
local Forge install for tools that require filesystem access. The
local-side gap-closer for the 12 Worker stubs.

> **Status:** alpha. Local side shipped in v0.14.0a1; wire-contract
> spec shipped in v0.14.0a2 ([RELAY_PROTOCOL.md](RELAY_PROTOCOL.md)).
> Worker side ships separately. Audit-log discipline included. See
> [WORKER_VS_LOCAL_MCP.md](WORKER_VS_LOCAL_MCP.md) for the contract
> divergence the relay closes.

```bash
forge relay SUBCOMMAND [OPTIONS]
```

**Subcommands:**

#### forge relay serve

Block in the foreground accepting POST `/relay/jobs` requests.

```bash
forge relay serve [--host 127.0.0.1] [--port 7409]
```

**Options:**
- `--host HOST` — bind interface (default: `127.0.0.1`)
- `--port PORT` — bind port (default: `7409`)

The accepted envelope is the standard MCP `tools/call` JSON-RPC
shape plus an `identity_claim` field; the relay dispatches through
`mcp_protocol.dispatch_request` and returns the signed result.

#### forge relay dispatch

Synchronous dispatch — same code path as `serve` but no HTTP. Useful
for smoke tests and end-to-end verification.

```bash
forge relay dispatch '<json-rpc envelope>'
```

```bash
forge relay dispatch '{"jsonrpc":"2.0","id":1,"method":"tools/call",
                       "params":{"name":"doctor","arguments":{}}}'
# → ok=True  tool=doctor  duration=9ms
```

#### forge relay log

Show recent entries from the audit log.

```bash
forge relay log [--tail N]
```

**Storage:** `.atomadic-forge/relay/jobs.jsonl` — append-only audit
record of every relayed call with input envelope, output payload,
duration, and identity_claim.

---

## Hive coordination commands (v0.13.2+)

### forge hive

Multi-agent coordination via append-only public artifacts. The seven
subcommands operationalize the four-agent loop (Forge / Cognition /
Doc / Research) without direct messaging.

> Full conceptual reference: [HIVE_PRIMITIVES.md](HIVE_PRIMITIVES.md).
> Each subcommand has a 1:1 MCP tool of the same name (snake-cased):
> `forge hive register` ≡ `hive_register`, etc.

```bash
forge hive SUBCOMMAND [OPTIONS]
```

**Subcommands:**

#### forge hive register

Activate against `AGENT_COLLAB_PROTOCOL.md` and declare your lane.

```bash
forge hive register --agent NAME --role ROLE \
  [--capabilities CAP ...] [--subscribes-to EVENT ...] \
  [--write-lanes PATH ...] [--identity SIGNED] [--notes "..."]
```

Refuses past `D_max = 23`. Default subscriptions auto-derive per role.

#### forge hive list

Show registered agents + their capabilities + subscriptions + write
lanes.

```bash
forge hive list [--include-deactivated]
```

#### forge hive deactivate

Append a deactivation marker (preserves audit; original entry stays).

```bash
forge hive deactivate AGENT_NAME
```

#### forge hive observe

Pull events the agent hasn't seen yet (relative to a cursor).

```bash
forge hive observe --agent NAME [--since CNS-XXXX] [--limit N]
```

#### forge hive propose

Open a consensus proposal. Returns a `consensus_id`.

```bash
forge hive propose --proposer NAME --intent "..." \
  [--payload JSON]
```

#### forge hive vote

Vote against an open proposal. Vote values: `approve` / `reject` /
`refine` / `abstain`. Latest vote per voter wins (changes of mind
allowed).

```bash
forge hive vote --id CNS-XXXX --voter NAME --vote VOTE \
  [--rationale "..."]
```

#### forge hive result

Read the verdict for a consensus. With `--record`, freezes the
verdict via a resolution event. With `--nexus` (added v0.14.0a6),
also mirrors the freshly-recorded resolution to AAAA-Nexus's
`lineage_record` (best-effort; local stays canonical on failure).

```bash
forge hive result --id CNS-XXXX [--record] [--nexus]
```

**Verdicts:** `PASS` / `REFINE` / `REJECT` / `TIMEOUT` / `PENDING`.
**Quorum:** `max(2, ceil(active_agents/2 + 1))` — refuses to resolve
under quorum.

**Nexus mirror semantics (v0.14.0a6+):** the mirror fires only on
freshly-recorded resolutions, so re-reading a resolved consensus
won't double-publish. Subject to the same `NexusToolNotShipped` guard
as `forge wisdom record --nexus`.

#### forge hive recap (since v0.14.0a10)

Full-lifecycle replay of a single consensus — proposal + every vote +
resolution + summary (verdict, duration, voters). The "what happened
on this consensus?" primitive.

```bash
forge hive recap CNS-XXXX [--project-root DIR] [--json]
```

Returns proposer, `proposed_at`, intent, every vote (with rationale
+ timestamp), the resolution event if any, and a summary block:
verdict, duration (proposal → resolution), and the full voter list.

Useful for: audit trail of a closed consensus; understanding why a
proposal landed where it did; quoting an old consensus in
documentation or release notes.

**MCP equivalent:** `hive_recap` (confirmed against `surface.json` at
HEAD `7397743`).

---

#### forge hive needs-vote (since v0.14.0a9)

Surface open consensuses where the calling agent hasn't voted yet —
the "what should I weigh in on?" primitive. Closes the gap between
`hive_observe` (everything happening) and the act of voting.

```bash
forge hive needs-vote --agent NAME
```

Returns PENDING proposals where the named agent hasn't voted,
ordered by `proposed_at`, with `votes_so_far` + `voters_so_far`
context so the caller can prioritize.

**MCP equivalent:** `hive_needs_vote`.

---

#### forge hive watch (since v0.14.0a4)

Live tail. Polls `hive_observe` every `--interval` seconds, prints
new events since the last cursor with stable color coding.

```bash
forge hive watch --agent NAME [--interval SECONDS] [--once]
```

**Options:**
- `--agent NAME` — observe through this agent's subscription set
- `--interval SECONDS` — poll cadence (default: 5)
- `--once` — print one batch and exit (useful in tests / CI)

**Color legend:** proposals cyan · approve votes green · refine
yellow · reject red · resolutions bright-green bold · new wisdom ✦ ·
superseded wisdom ↺. Stable cursors mean no duplicates after the
first poll.

**Storage:** `.atomadic-forge/hive/agents.jsonl` (registry),
`.atomadic-forge/hive/consensus.jsonl` (proposals/votes/resolutions).
Both append-only, content-addressed, supersession-aware on read.

---

## Global options

All commands support:
- `--help` — Show help text
- `--version` — Print version and exit

## Exit codes

- 0 — Success
- 1 — Error (see stderr)
- 2 — Usage error (wrong args)
