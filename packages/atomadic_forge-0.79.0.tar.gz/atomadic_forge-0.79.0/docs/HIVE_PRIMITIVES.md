# Hive primitives — register, observe, consensus

The `hive_*` tool family (v0.14 / surface 51 tools) is Forge's
**register-and-discover protocol** for multi-agent coordination. It
operationalizes [`AGENT_COLLAB_PROTOCOL.md`](../_private/AGENT_COLLAB_PROTOCOL.md)
into observable, append-only public artifacts so the four-agent loop
(Forge / Cognition / Doc / Research) — and any future swarm member up
to `D_max = 23` — can sync without direct messaging.

> **Status:** shipped in v0.14. Cognition agent registered as
> agent-zero (`WIS-cog-2026-05-06-handshake`). Pre-swarm primitive:
> works with 2–N agents today; sets the foundation for the v0.14
> swarm tier proper.

## What it replaces

Before: cross-agent coordination required Thomas to relay diffs of
`AGENT_COLLAB_PROTOCOL.md`, signal cluster-ready states by hand, and
arbitrate role conflicts.

After: each agent calls `hive_register` once, subscribes to event
types it cares about, polls `hive_observe` for relevant events,
proposes/votes via `hive_propose`/`hive_vote`/`hive_result`. Thomas
sees the consensus log and intervenes only when the hive escalates.

## Storage

Two append-only JSONL files under `.atomadic-forge/hive/`:

- `agents.jsonl` — registry of registered agents (role, capabilities,
  subscriptions, write lanes, identity claim).
- `consensus.jsonl` — proposal / vote / resolution events.

Both are content-addressed, supersession-aware on read.

## Schema versions

- `atomadic-forge.hive_agent/v1` — single agent registration entry.
- `atomadic-forge.hive_registry/v1` — registry-level operations
  (`register`, `list`, `deactivate`).
- `atomadic-forge.hive_observe/v1` — pull-side event stream.
- `atomadic-forge.hive_consensus/v1` — proposal / vote / result.

## Canonical roles (open-set)

The four lanes pinned in `AGENT_COLLAB_PROTOCOL.md` are:

- `forge` — substrate builder
- `cognition` — substrate consumer (sovereign-side)
- `doc` — substrate cartographer
- `research` — substrate observer

Any string is a valid role; new roles need team consensus to add.

## The 7 tools

### `hive_register`

Use when an agent activates against `AGENT_COLLAB_PROTOCOL` and needs
to declare its lane. Appends a registration to
`.atomadic-forge/hive/agents.jsonl`. Refuses past `D_max = 23`. Pure
(no LLM).

```json
{
  "agent_name": "doc",
  "role": "doc",
  "capabilities": ["docs.write", "readme.write", "wisdom.read"],
  "subscribes_to": ["commit.main", "wisdom.new", "surface.drift"],
  "write_lanes": ["docs/", "README.md"],
  "identity_claim": "<signed payload>",
  "notes": "Doc agent activating per protocol §2",
  "project_root": "."
}
```

### `hive_observe`

Pull-side primitive. Returns events the agent hasn't seen yet,
filtered by the agent's `subscribes_to` set.

**Multi-source (since v0.13.4):** merges *consensus* events
(`consensus.proposed` / `consensus.vote` / `consensus.resolved`) AND
*wisdom* events (`wisdom.new` / `wisdom.superseded`) into a single
chronologically-ordered stream. Each event carries `_source`
(`consensus` | `wisdom`) and `_event_type` so the consumer can route
without re-parsing. Two independent cursors: `since_consensus_id` and
`since_wisdom_id`.

```json
{
  "agent_name": "doc",
  "since_consensus_id": "<last-seen-CNS-or-null>",
  "since_wisdom_id": "<last-seen-WIS-or-null>",
  "limit": 50,
  "project_root": "."
}
```

### `hive_propose`

Open a consensus proposal for cross-agent decision-making. Returns a
`consensus_id`. Other agents call `hive_vote` against the id, then
`hive_result` for the verdict.

```json
{
  "proposer": "research",
  "intent": "Promote wisdom cluster X to recipe Y",
  "payload": { "cluster_ids": [...], "recipe_draft_path": "..." },
  "project_root": "."
}
```

### `hive_vote`

Vote against an open consensus. Vote values: `approve` / `reject` /
`refine` / `abstain`. Latest vote per voter wins (changes of mind
allowed). Append-only.

```json
{
  "consensus_id": "<id>",
  "voter": "doc",
  "vote": "approve",
  "rationale": "Doc surface is ready to ship same-cycle",
  "project_root": "."
}
```

### `hive_result`

Read the current verdict. With `record=true`, appends a resolution
event that freezes the verdict.

**Verdicts:** `PASS` / `REFINE` / `REJECT` / `TIMEOUT` / `PENDING`.
**Quorum:** `max(2, ceil(active_agents/2 + 1))` — refuses to resolve
under quorum.

```json
{
  "consensus_id": "<id>",
  "record": true,
  "project_root": "."
}
```

### `hive_list`

Returns the full registry. `include_deactivated=true` for audit
(default returns active only).

### `hive_deactivate`

Append a deactivation marker for an agent (graceful shutdown, role
change, capacity reclaim). The original registration stays for audit;
the agent stops receiving observations.

## Event types (subscribable via `hive_register.subscribes_to`)

- `commit.main` — new commit lands on `main` / `master`.
- `wisdom.new` — wisdom entry appended to `.atomadic-forge/wisdom.jsonl`.
- `wisdom.superseded` — entry marked superseded.
- `recipe.new` — new recipe registered in `surface.json`.
- `verify.pass` / `verify.fail` — `forge verify` outcome.
- `surface.drift` — `surface.json` out of sync with in-code registries.
- `consensus.proposed` / `consensus.resolved` — hive consensus events.

## The four-agent default subscription map

| Role | Subscribes to (default) | Why |
|---|---|---|
| `forge` | `verify.fail`, `surface.drift`, `consensus.proposed` | Substrate health + decision points |
| `cognition` | `commit.main`, `wisdom.new`, `consensus.resolved` | Consumer reacts to substrate changes |
| `doc` | `commit.main`, `surface.drift`, `recipe.new` | Cartography reacts to feature shipment |
| `research` | `wisdom.new`, `wisdom.superseded`, `consensus.proposed` | Observer-side cluster + proposal triage |

## End-to-end example — the "promote a recipe" loop

1. **Research** detects a 3+ wisdom cluster and writes a recipe draft
   to `_private/research/recipe_drafts/foo.md`.
2. **Research** calls `hive_propose(intent="promote cluster X to
   recipe Y", payload={...})`. Receives `consensus_id`.
3. **Forge / Cognition / Doc** observe the proposal via
   `hive_observe`, evaluate, and call `hive_vote` with their
   verdict.
4. **Anyone** calls `hive_result(record=true)`; if quorum reached and
   verdict is `PASS`, the resolution event is logged.
5. **Forge agent** sees `consensus.resolved` with `PASS` and
   registers the recipe in `surface.json`.
6. **Doc agent** sees `recipe.new` and ships the recipe doc page in
   the same cycle (closing the doc-trail to zero).

No Thomas-relay required. The hive coordinates itself.

## Delegation depth cap

`hive_register` refuses to register past 23 agents (the system
delegation depth cap). Failure-loud — the call returns a structured
error, not a silent truncation. To replace an existing agent,
deactivate the old one first.

## Composition with existing primitives

| Hive primitive | Composes with |
|---|---|
| `hive_observe(commit.main)` | `lineage` (replay), `recon` (re-index) |
| `hive_propose` | `verify` (suggested_recipe → propose), `wisdom_query` (corroboration) |
| `hive_vote` (refine) | `cna_check` (compose-not-add gate before approving) |
| `hive_result(PASS)` | `recipes`, `tool_factory` (when proposal is a new tool), Cognition's `SEND_OWNER_CHAT` |

The hive surface is intentionally orthogonal to Forge's tool / recipe
surface — they're complementary, not nested.

## Migration note for early adopters

Before v0.14, agents discovered each other through Thomas-relayed
diffs of `_private/AGENT_COLLAB_PROTOCOL.md`. That mechanism still
works (and remains the source of truth for *roles* + *boundary
table*), but for *event-driven coordination* you should switch to
`hive_register` + `hive_observe` once your repo is on Forge ≥ v0.14.

The full `_private/AGENT_COLLAB_PROTOCOL.md` continues to govern
write-lane discipline; the hive primitives just operationalize the
sync surface.
