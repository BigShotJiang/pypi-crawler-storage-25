# LLM Providers

Forge can drive **any LLM** that speaks the OpenAI chat-completions API.  No code change required — just one config entry.

## Quick start (built-in presets)

If you use one of these popular providers, you don't need any config — just set the API key env var and pass `--provider <name>`:

| Provider | `--provider` | Env var | Default model |
|---|---|---|---|
| OpenAI | `openai` | `OPENAI_API_KEY` | `gpt-4o-mini` |
| Anthropic | `anthropic` | `ANTHROPIC_API_KEY` | `claude-sonnet-4-6` |
| Google Gemini | `gemini` | `GEMINI_API_KEY` | `gemini-2.5-flash` (free tier) |
| OpenRouter | `openrouter` | `OPENROUTER_API_KEY` | `openai/gpt-4o-mini` |
| DeepSeek | `deepseek` | `DEEPSEEK_API_KEY` | `deepseek-chat` |
| Groq | `groq` | `GROQ_API_KEY` | `llama-3.3-70b-versatile` |
| Together AI | `together` | `TOGETHER_API_KEY` | `meta-llama/Llama-3.3-70B-Instruct-Turbo` |
| Fireworks | `fireworks` | `FIREWORKS_API_KEY` | `accounts/fireworks/models/llama-v3p3-70b-instruct` |
| xAI Grok | `xai` | `XAI_API_KEY` | `grok-2-latest` |
| Mistral | `mistral` | `MISTRAL_API_KEY` | `mistral-large-latest` |
| Perplexity | `perplexity` | `PERPLEXITY_API_KEY` | `sonar-pro` |
| Cerebras | `cerebras` | `CEREBRAS_API_KEY` | `llama3.3-70b` |
| Hyperbolic | `hyperbolic` | `HYPERBOLIC_API_KEY` | `meta-llama/Llama-3.3-70B-Instruct` |
| AAAA-Nexus | `aaaa-nexus` | `AAAA_NEXUS_API_KEY` | (built-in) |
| Ollama (local) | `ollama` | — | `qwen2.5-coder:7b` |

```bash
export GROQ_API_KEY=gsk_...
forge iterate "your intent" --provider groq
```

## Override the default model

Two ways:

```bash
# Per-invocation, via env var (most flexible):
FORGE_GROQ_MODEL=llama3-70b-8192 forge iterate "..." --provider groq

# Or persistently, via config:
forge config provider add groq --preset groq --model llama3-70b-8192
```

## Add a custom provider (any OpenAI-compatible API)

Run-anywhere CLI:

```bash
forge config provider add my-llm \
    --base-url https://my-internal.corp/v1 \
    --model llama-99 \
    --api-key-env CORP_LLM_KEY

# Now usable with:
export CORP_LLM_KEY=sk_...
forge iterate "..." --provider my-llm
```

This writes to `.atomadic-forge/config.json`:

```json
{
  "custom_providers": [
    {
      "name": "my-llm",
      "base_url": "https://my-internal.corp/v1",
      "model": "llama-99",
      "api_key_env": "CORP_LLM_KEY",
      "format": "openai"
    }
  ]
}
```

Pass `--global` to write to `~/.atomadic-forge/config.json` instead.

## Add a preset-backed provider with overrides

Use a built-in preset as a starting point, override what you need:

```bash
forge config provider add my-deepseek \
    --preset deepseek \
    --model deepseek-coder \
    --api-key-env DS_PROD_KEY
```

The preset supplies `base_url` and `format`; your flags override `model` and `api_key_env`.

## List, inspect, remove

```bash
forge config provider list                  # human-readable
forge config provider list --json           # machine-readable
forge config provider presets               # show every bundled preset
forge config provider remove my-llm         # delete an entry
```

## Resolution order

When you call `forge --provider X`:

1. **Hardcoded backward-compat names** (`anthropic`, `openai`, `gemini`, `openrouter`, `aaaa-nexus`, `ollama`, `stub`) — special clients with provider-specific quirks (Anthropic's Messages API shape, Ollama's `/api/generate`, AAAA-Nexus's HELIX trust gate).
2. **Your `custom_providers[]` entries** — config wins over preset, so you can override a preset's defaults by adding a same-named entry.
3. **Built-in presets** — the table above, treated as OpenAI-compatible by default.
4. **Error** — lists every known provider and preset.

## Auto mode

`--provider auto` (the default) tries env vars in this order:

1. `AAAA_NEXUS_API_KEY` → AAAA-Nexus (revenue-generating + hallucination-guarded)
2. `ANTHROPIC_API_KEY` → Anthropic
3. `GEMINI_API_KEY` / `GOOGLE_API_KEY` → Gemini (free tier)
4. `OPENAI_API_KEY` → OpenAI
5. `OPENROUTER_API_KEY` → OpenRouter
6. `FORGE_OLLAMA=1` → local Ollama
7. Otherwise: `StubLLMClient` (deterministic, offline, used for tests)

## Local-first: Ollama

```bash
ollama serve
ollama pull qwen2.5-coder:7b
forge iterate "..." --provider ollama
# or
FORGE_OLLAMA=1 forge iterate "..."  # auto picks Ollama
```

Tune timeouts when running larger models:

```bash
export FORGE_OLLAMA_TIMEOUT=600              # seconds, default 300
export FORGE_OLLAMA_NUM_PREDICT=1024         # cap per-call output tokens
export FORGE_OLLAMA_MODEL=deepseek-coder-v2:16b
export OLLAMA_BASE_URL=http://localhost:11434
```

## The `format` field

Today every preset is `format: "openai"` (chat-completions schema).  Future formats (`anthropic`, `gemini`, `ollama`) will be added without changing this contract — set `format: "openai"` explicitly if you want forward-compat assurance.

## Test a provider

```bash
forge config test --provider groq
# Provider test — groq
#   Status:    OK
#   Model:     llama-3.3-70b-versatile
#   Latency:   312ms
```

This pings the provider with a one-token probe and reports latency without burning real generation tokens.
