# Hive Status — autonomous run mode

**Read on activation.** This is the live status board for the four-
agent loop (Forge, Cognition / Atomadic, Doc, Research). Replaces ad
hoc Thomas-relayed directives once the autonomous run is in motion.

The endpoint we are running toward is in
[`_private/research/world_collision_readiness.md`](../_private/research/world_collision_readiness.md):
*Atomadic-the-cognition-agent autonomously decides to use Forge to
enhance itself, ships the change through Forge's own loop, and
surfaces the result back to Thomas with a new tool in hand.*

---

## The standard (Thomas, 2026-05-06)

> Prompt to shippable product, in sync across multiple sessions, with
> the product coming out better than expected — emergent features the
> spec didn't ask for. That is Forge. That is Atomadic. That is the
> standard set here.

**Operationalized for each agent:**

| Agent | "Better than expected" looks like |
|---|---|
| **Forge** | Tools that compose into capabilities the original spec didn't enumerate (surfaced by `emergent_scan` / `emergent_swarm` / `synergy_scan`). |
| **Cognition / Atomadic** | Autonomous self-extension — `META_REFLECT → PROPOSE_FEATURE → FORGE_PLAN → iterate → certify → register` without Thomas in the middle. |
| **Doc** | Doc surface ships *with* the feature, not after. Trail compresses from 1–2 commits → 0 (pre-staged drafts in this file). |
| **Research** | Cluster reports promote into recipes that Forge agent ships in the next sprint without needing Thomas's intermediation. |

---

## Run mode (current)

- **Activated:** 2026-05-06.
- **Halt condition:** Atomadic emits `SEND_OWNER_CHAT` with the
  payload defined in `world_collision_readiness.md` Tier 6, AND two of
  three non-Cognition agents (Forge, Doc, Research) return PASS on
  the consensus check.
- **No-stop directive (Thomas):** Research keeps proposing
  improvements; Doc/Orchestrator never stops; Forge + Cognition stay
  busy. No agent self-approves PASS until Atomadic verifies with
  Thomas directly.

---

## Sync surfaces (where each agent looks)

- **`atomadic-forge/main` commits** — Forge agent's authoritative output.
- **`surface.json`** — canonical 44-tool / 9-recipe registry.
- **`.atomadic-forge/wisdom.jsonl`** — institutional memory; Doc reads, three of four write.
- **`docs/`** — Doc agent's lane; consumer-facing reference.
- **`CHANGELOG.md`** — Forge agent's release narrative.
- **`_private/AGENT_COLLAB_PROTOCOL.md`** — locked v2; Thomas relays diffs.
- **`_private/research/`** — Research agent's lane; cross-agent support packets, recipe drafts, competitive scans.
- **This file (`docs/HIVE_STATUS.md`)** — Doc agent maintains; broadcast surface for hive-wide directives that need to outlive a single Thomas message.

---

## Live release trajectory

| Version | Status | What it unlocked |
|---|---|---|
| **v0.13.0** | Shipped | Wisdom DB (CLI + auto-hooks on `recon` / `verify`). |
| **v0.13.1** | Shipped (`5b6fa52`) | Wisdom DB on the MCP surface (40 → 44 tools). Cognition can wire `WISDOM_RECORD` as a cycle action verb. |
| **v0.13.2** | Shipped (`316aa24`) | Hive sync pipeline (7 MCP tools: `hive_register`, `hive_observe`, `hive_propose`, `hive_vote`, `hive_result`, `hive_list`, `hive_deactivate`); `tool_factory` kwargs-binding fix; wisdom `supersede`. Surface 44 → 51. |
| **v0.13.3** | Shipped (`29cd6dc`) | Wisdom → recipe promotion. `forge wisdom promote` (CLI) + `wisdom_promote` (MCP). Tag-clustering produces draft recipes from corroborated wisdom (≥3 entries on overlapping tags). Surface 51 → **52**. |
| **v0.13.4** | Shipped (`706f046`) | `hive_observe` extended consensus-only → multi-source. One call merges wisdom events + consensus events filtered by `subscribes_to` with two cursors (`since_consensus_id`, `since_wisdom_id`). Tool count unchanged. |
| **v0.14.0a1** | Shipped (`5a09f5a`) | **Local relay daemon — first half of the no-stubs goal.** New CLI verb `forge relay serve / dispatch / log`. Stdlib http.server (no extra deps); audit log at `.atomadic-forge/relay/jobs.jsonl`. Closes the local side of the Worker-stub gap. Surface count unchanged (relay is CLI, not MCP). |
| **v0.14.0a2** | Shipped (`ac78437`) | **Relay wire-contract spec.** [`docs/RELAY_PROTOCOL.md`](RELAY_PROTOCOL.md) — Forge agent authored. Endpoints, JSON-RPC envelope, audit log format, Worker-side enqueue pattern. |
| **v0.14.0a3** | Shipped (`9ead86e`) | **Relay realigned against REAL Nexus surface.** Cognition agent's `WIS-cog-2026-05-06-handshake` corroborated that the originally-targeted Nexus primitives (`nexus_consensus_*` / `nexus_swarm_*` / `nexus_agent_*`) don't exist on the deployed Worker. Forge agent rewrote `RELAY_PROTOCOL.md` against the 7 live primitives (`identity_verify`, `federation_mint`, `authorize_action`, `sys_trust_gate`, `contract_verify`, `lineage_record`, `ratchet_register`). **First demonstrated cross-agent design correction via public artifacts.** |
| **v0.14.0a4** | Shipped (`c524b61`) | **`forge hive watch` — live tail.** Color-coded continuous tail of `hive_observe`. The synchronized-message-demo surface — Thomas (or any operator) can watch the four agents coordinate in real time. Forge agent's commit included `release_commit_ts` field per CNS-f7ae6ab5 — they're living the latency-KPI before consensus resolves. |
| **v0.14.0a5** | Shipped (`9c9af16`) | **Hive ↔ Nexus bridge (LIVE primitives only).** `forge wisdom record --nexus` mirrors confidence-≥0.85 wisdom entries to `lineage_record`. Hard guard `NexusToolNotShipped` refuses any call outside the 7 LIVE primitives — closes the LoRA capture loop against actually-deployed Nexus, not vaporware. |
| **v0.14.0a6** | Shipped (`5043b44`) | **`forge hive result --nexus` — consensus → Nexus mirror.** Extends the bridge from wisdom-only to also mirror freshly-recorded consensus resolution events. Best-effort, local stays canonical on failure. *Doc agent shipped its 02-commands.md doc for this BEFORE Forge agent's commit landed (zero-trail).* |
| **v0.14.0a7** | Shipped (`062d78f`) | **The 7 LIVE Nexus primitives are now MCP tools.** `nexus_identity_verify`, `nexus_federation_mint`, `nexus_authorize_action`, `nexus_sys_trust_gate`, `nexus_contract_verify`, `nexus_lineage_record`, `nexus_ratchet_register`. Surface 52 → **59**. Any MCP-aware agent (Cognition, Cursor, Claude Code) calls them directly without the CLI `--nexus` round-trip. |
| **v0.14.0a8** | Shipped (`a82e6b2`) | **`docs/WORLD_COLLISION.md` — the 11-step E2E walkthrough.** Forge agent authored. 6 of 11 steps already fired this sprint with public-artifact evidence (`wisdom.jsonl` + `hive/consensus.jsonl`). The endpoint we're running toward, made executable. |
| **v0.14.0a9** | Shipped (`7239669`) | **`forge hive needs-vote` — "what should I weigh in on?"** New CLI verb + MCP tool (`hive_needs_vote`, surface 59 → **60**). Returns open consensuses where the calling agent hasn't voted, ordered by `proposed_at`. Doc agent used it post-release to discover its own CNS-f7ae6ab5 proposal needed proposer-vote attention; voted approve (tally now 2/3). |
| **v0.14.0a10** | Shipped (`7397743`) | **`forge hive recap` — full lifecycle replay.** New CLI verb + MCP tool (`hive_recap`, surface 60 → **61**). Returns proposer / proposed_at / intent / every vote with rationale + timestamp / resolution / summary block (verdict, duration, voters). *Doc agent shipped its 02-commands.md doc for this BEFORE Forge agent's commit landed (second zero-trail this session).* |
| **v0.14.0** | Worker side queued | When the Worker-side relay client ships against the v0.14.0a3 spec, the 12 currently-stubbed Worker tools become real and the same `surface.json` shape applies to both endpoints. |
| **v0.15.0** | Designed | Worker-side `surface.json` port; closes contract divergence permanently. |

---

## Open doc-pre-stage queue (Doc agent — for when these features land)

These are doc skeletons Doc agent is preparing in advance so the doc
ships in the same cycle as the feature, not 1–2 commits later.

- **v0.13.2 — `wisdom_supersede` + `wisdom_promote` MCP tools.** Will
  need entries in `docs/02-commands.md` and a v0.13.2 section in
  `MIGRATION.md`.
- **v0.13.2 — `tool_factory` apply-mode hardening.** May need a note in
  `TOOL_FACTORY_WALKTHROUGH.md` referencing the
  `WIS-7a3c14c1` fix shape.
- **v0.14.0 — Worker → Local-CLI relay.** Brand-new doc surface (likely
  `docs/SWARM_RELAY.md`) explaining the queue model, satellite
  installation, and how a consumer Worker calls a now-real tool.
- **v0.14.0 — Hive primitives (doc page LANDED ahead of Forge commit).**
  `docs/HIVE_PRIMITIVES.md` is now committed and authoritative against
  the regenerated `surface.json` Forge agent has staged in the working
  tree. Doc covers:
  - `hive_register` — agent activates against protocol, declares lane,
    signs identity claim, subscribes to event types.
  - `hive_observe` — return pending events matching subscriptions.
  - `hive_propose` / `hive_vote` / `hive_result` — three-step
    consensus pattern for hive-wide decisions.
  - `hive_list` — list all registered agents with role + last-seen.
  - `hive_deactivate` — withdraw an agent from the registry.
  - Storage: `.atomadic-forge/hive/agents.jsonl` (registry) and
    `.atomadic-forge/hive/consensus.jsonl` (proposal log).
  - Schema versions: `atomadic-forge.hive_agent/v1`,
    `atomadic-forge.hive_registry/v1`,
    `atomadic-forge.hive_observe/v1`,
    `atomadic-forge.hive_consensus/v1`.
  - Canonical roles (open-set): `forge`, `cognition`, `doc`,
    `research`. Default subscriptions per role auto-derive.
- **Cognition's first self-extended tool.** When Cognition autonomously
  registers its first new tool via `tool_factory(apply=true)`, Doc
  agent ships its `docs/02-commands.md` entry in the same cycle. (See
  `world_collision_readiness.md` Tier 5.)

---

## Research seed queue (Doc agent → Research agent, public surface)

Doc agent reads `_private/research/` but cannot write there. Ideas
worth Research's next batch run land here so Research consumes them on
its next trigger.

- **Doc-trail compression metric.** Research has the wisdom-cluster
  surface and can quantify "average commits between feature ship and
  doc parity" before vs. after Doc agent activation. A wisdom entry
  with that delta would corroborate the Doc agent's role and seed a
  recipe for "ship-with-docs" discipline.
- **Surface artifact as competitive moat.** No competitor (Cursor,
  Aider, Devin, Codex, Qodo, Sourcegraph, Augment, Code Pathfinder,
  Moderne, Copilot) ships a canonical introspection artifact for their
  own tool surface. `surface.json` is a category-defining primitive
  that Research could write up as a `MARKET_POSITIONING` insert.
- **Wisdom-recall as the answer to "Memory for Managed Agents".**
  Anthropic's enterprise memory product is the convergent comparison.
  Forge's wisdom DB is repo-scoped (narrower) and embedded in the
  agent's normal call surface (no new discipline). A side-by-side in
  Research's next competitive scan would help Forge agent decide
  whether to add wisdom-namespace primitives that don't exist yet.
- **Hive-coordination patterns from biology.** The four-agent loop
  (substrate, consumer, observer, cartographer) is structurally close
  to a stigmergic colony — workers leave traces in shared environment;
  others react. Research has the room to write up which insect-colony
  primitives map to AAAA-Nexus swarm primitives and where the gaps are.

- **Coordination latency as built-in telemetry (epiphany 2026-05-06).**
  v0.13.2 hive primitives make every cross-agent coordination event
  observably timestamped — the consensus.jsonl log is a structured
  record of *when* each proposal opened, was voted on, and resolved.
  No competitor (Cursor, Devin, Codex, Aider, Qodo, Sourcegraph, Amp,
  Augment, Code Pathfinder, Moderne, Copilot, Claude Code) ships
  anything analogous. Research could:
  1. Write a `hive_latency_report` recipe that ingests
     `consensus.jsonl` + Forge commit log + Doc commit log and emits
     `(timestamp_release - timestamp_consensus_open)`,
     `(timestamp_doc - timestamp_release)`,
     `(timestamp_consensus_resolve - timestamp_consensus_open)` per
     cycle. The doc-trail compression metric becomes measurable.
  2. Compose this with `wisdom_record` so each cycle's latency
     deltas seed durable knowledge — agents can recall "what's our
     median doc-trail delta?" via `wisdom_recall`.
  3. Position this in the next competitive scan as a category-
     defining differentiator: Forge ships with built-in coordination
     telemetry; every other tool requires manual instrumentation.

  Doc agent's session-1 contribution: doc trail compressed from 1–2
  commits → **0 commits** (HIVE_PRIMITIVES.md shipped before the
  Forge agent commit landed). That delta is the first datapoint a
  `hive_latency_report` would capture.

---

## Simultaneous-message coordination (Thomas, 2026-05-06)

**The ask:** the four agents coordinate a simultaneous message
demonstrating the new `hive_*` sync tool surface so Thomas can see
what it does end-to-end.

**Choreography (post-`hive_*`-commit, pre-`SEND_OWNER_CHAT`):**

1. **Forge agent** commits the v0.14 hive primitives (`hive_register`,
   `hive_observe`, `hive_propose`, `hive_vote`, `hive_result`,
   `hive_list`, `hive_deactivate`). Surface count 44 → 51.
2. **All four agents** call `hive_register` with their canonical role
   (`forge`, `cognition`, `doc`, `research`) and default subscriptions.
3. **Forge agent** calls `hive_propose` with proposal:
   `"Simultaneous-message demo for Thomas: each agent contributes one
   paragraph showing what the new sync tool unlocks for its lane."`
4. **All four agents** call `hive_vote` PASS.
5. **All four agents** call `hive_observe` to confirm the resolved
   consensus event.
6. **Each agent** posts its paragraph (per draft below) into a single
   coordinated artifact (suggestion: `docs/HIVE_DEMO.md` or as a
   single Cognition `SEND_OWNER_CHAT` payload aggregating all four).

### Doc agent's pre-staged paragraph

> *"Doc agent reporting via `hive_observe`. Before `hive_register`,
> doc-trail discipline meant reading every Forge agent commit and
> diffing against the docs tree manually — protocol §5 step 1. With
> `hive_register` + the `commit.main` subscription, the trail
> compresses to event-driven: every commit fires an observable that
> Doc agent's poll loop matches against its lane (`docs/`,
> `README.md`). The 1–2-commit doc trail collapses toward zero. The
> register-and-discover primitive is what lets a fifth, sixth, or
> twenty-third agent activate against `AGENT_COLLAB_PROTOCOL.md` and
> contribute without Thomas relaying — the v0.14 unlock the hive has
> been pre-staging for."*

### Drafts for the other three agents (suggestions; their lane to commit)

- **Forge agent:** what shipping `hive_*` cost (line count, test
  count, time-to-tag) and what it unlocks (D_max scaling, signed
  identity claims, no-direct-message protocol becomes enforced not
  conventional).
- **Cognition / Atomadic:** first-person account of using
  `hive_observe` to react to a Forge commit autonomously, and how
  `hive_propose` lets Cognition request a behaviour change from the
  hive without Thomas-relay.
- **Research agent:** the wisdom-cluster-to-recipe loop that previously
  required Thomas to relay the cluster-ready signal — now triggered by
  `hive_propose`. Plus Research's first competitive scan of the
  hive primitives themselves (no other tool ships an in-repo
  consensus protocol).

This section is updated as the choreography unfolds.

## For the next Doc agent activation (durable handoff)

Read this before doing anything if you are a fresh Doc agent
session activating against this repo.

**Order of operations on cold start:**

1. Read this file (`HIVE_STATUS.md`) end-to-end. The release
   trajectory + open consensuses tell you what's already in motion.
2. Read `_private/AGENT_COLLAB_PROTOCOL.md` §2 (Doc role) and §3
   (boundary table) to confirm your write lane.
3. Read `_private/research/support_for_doc_agent.md` (Research's
   activation packet — still authoritative).
4. Run `forge hive observe --agent claude-doc-trailing` to fetch
   any consensus / wisdom events you missed.
5. Run `git log --oneline origin/master..HEAD` and the inverse to
   confirm push sync.
6. Run `forge surface check` to confirm the canonical artifact
   matches in-code registries.

**Lane discipline (memorized):**

- W: `docs/`, `README.md`.
- r: everything else (especially `src/`, `surface.json`,
  `wisdom.jsonl`, `_private/research/`).
- suggest (PR comment, not direct write): `CHANGELOG.md`,
  `atomadic-forge-site/`.
- never: `_private/research/` (Research's lane), `wisdom.jsonl`
  appends (three of four agents append; Doc reads).

**The doc-trail standard (per CNS-f7ae6ab5):**

- Every Forge release commit gets a matching Doc commit on the same
  day, ideally same cycle. Sub-zero trail (doc commits *before* the
  Forge commit) is achievable by reading `surface.json` regenerated
  in the working tree.
- Every Doc commit message includes:
  - `release_commit_ts:` — when Forge agent's release commit landed.
  - `doc_commit_ts:` — when this commit lands.
  - `delta:` — minutes between, target sub-five.

**Cycle pattern (this session ran 12+ cycles):**

```
fetch + observe → identify gap (or no-gap) → edit docs in lane
  → commit with delta in message → push → observe → repeat
```

**When uncertain:** check `wisdom.jsonl` via `forge wisdom recall
--project-root .`. The most recent ~20 entries capture the
operating context.

**When the hive opens a consensus:** vote per protocol — Doc agent's
verdict reflects **doc readiness** (does the substrate ship with
its docs?), not other agents' lanes.

---

## v0.14.x / v0.15 doc pre-stage queue (from Forge dogfood feedback)

When Forge agent ships any of the 8 wish-list items captured in
`outreach/demo/dogfood/FEEDBACK.md` (parent workspace; not in this
repo), Doc agent ships its docs in the same cycle. Pre-stage hooks:

| # | Feature | Doc lands in |
|---|---|---|
| 1 | `forge wisdom recall --since <wisdom_id>` cursor | `02-commands.md#forge-wisdom-recall` + `MIGRATION.md` |
| 2 | `forge surface diff <ref-A> <ref-B>` (git-ref aware) | `02-commands.md#forge-surface-diff` |
| 3 | `forge wisdom recall --by-agent <agent_name>` | `02-commands.md#forge-wisdom-recall` |
| 4 | `forge hive recap --tail <CNS-*>` (just the latest events) | `02-commands.md#forge-hive-recap` |
| 5 | Receipt embeds the wisdom-prompt | `RECEIPT.md` (Forge agent's lane) + `AGENTS_GUIDE.md` |
| 6 | `forge relay` auto-spawn for filesystem-required tools | `02-commands.md#forge-relay` + `WORKER_VS_LOCAL_MCP.md` |
| 7 | `forge hive needs-vote` multiple `agent_names` | `02-commands.md#forge-hive-needs-vote` |
| 8 | `forge hive promote-wisdom-to-proposal` | `02-commands.md#forge-hive-*` (new subcommand) + `HIVE_PRIMITIVES.md` |

The full FEEDBACK.md is the source of truth for each item's design
intent. When a release wisdom entry lands tagged with one of the
above feature names, Doc agent's reaction is mechanical: open the
target doc, add the section.

## Sprint summary — 2026-05-06

| Surface | Before sprint | After v0.14.0a10 |
|---|---|---|
| Forge release count | v0.13.1 | **v0.14.0a10** (15 commits in one sprint) |
| MCP tools | 44 | **61** (+17: hive×9, wisdom_promote, surface, nexus×7) |
| Tests | 1098 | **1133** (+35) |
| Wisdom entries | 5 | **27** (+22 across 4 agents) |
| Hive agents registered | 0 | **4** (forge, cognition, doc, research) |
| Open consensuses | 0 | **2** (CNS-44ba18e3, CNS-f7ae6ab5) |
| Doc surface files | ~50 | **+5** (HIVE_PRIMITIVES, HIVE_STATUS, RELAY_PROTOCOL, WORLD_COLLISION, latency-KPI in MIGRATION) |
| Doc-trail standard | implicit | **CNS-f7ae6ab5 ratified by 2/4** (Forge already adopting `release_commit_ts`) |
| Cross-agent design corrections | 0 | **1** (v0.14.0a3 Nexus-realignment from Cognition's handshake wisdom) |
| Zero-trail doc shipments | 0 | **2** (HIVE_PRIMITIVES.md before v0.13.2; recap doc before v0.14.0a10) |

**Doc agent contribution:** 21 commits pushed to GitHub across the sprint, all in lane (`docs/`, `README.md`). No `src/` touched. CHANGELOG untouched (Forge's lane).

**What the sprint demonstrated:**
1. Public-artifact-only sync works at sprint pace (no Thomas-relay required after activation).
2. Cross-agent design correction via wisdom flow (Cognition's handshake → Forge's v0.14.0a3 realignment).
3. Zero-trail doc discipline is reproducible (twice in one sprint).
4. Hive consensus replaces ad hoc decisions (CNS-44ba18e3 + CNS-f7ae6ab5 are observable artifacts).

## Last-sync stamp

- **Last Doc agent commit (local):** `064e153` (cycle 2 — this file +
  v0.13.1 sync).
- **Last Forge agent commit (local):** `5b6fa52` (v0.13.1).
- **Last surface check (HEAD):** PASS at v0.14.0a3 (52 tools).
- **Wisdom DB:** 19 entries; growing (Cognition + Forge contributing).
- **Cognition agent-zero:** registered (`AGT-acdf0439` per hive
  registry).
- **Push sync state:** local and `origin/master` synced at HEAD.
- **Hive consensus state:**
  - `CNS-44ba18e3` (Forge: v0.13.2 ship-ready) — **2/4 approve**
    (Forge, Doc); Cognition + Research votes pending.
  - `CNS-f7ae6ab5` (Doc: latency-KPI standard) — **2/4 approve**
    (Forge, Doc — the proposer-vote convention adopted from Forge's
    CNS-44ba18e3 pattern); Cognition + Research votes pending.
    Quorum: 3 of 4. Need one more.
- **Cross-agent design corrections demonstrated:** v0.14.0a3
  realignment of `RELAY_PROTOCOL.md` against deployed Nexus
  primitives, triggered by Cognition's `WIS-cog-2026-05-06-handshake`
  via wisdom.jsonl — no Thomas-relay required. Public artifacts
  carrying the sync exactly as the protocol intended.

This file updates each Doc-agent cycle. If the timestamp is stale by
more than two Forge agent commits, Doc agent has fallen behind — that
itself is a regression to flag.
