# Relay Protocol — Worker → Local-CLI bridge

**Status:** v0.14.0-alpha (local side ships in the
``atomadic-forge`` Python package; Worker side ships in
``atomadic-forge-cloudflare-workers`` once Thomas signs off).

**Goal:** every Forge tool callable from anywhere — no stubs, no
"requires local CLI" envelopes. The Worker MCP at
``forge.atomadic.tech/mcp`` enqueues filesystem-required calls to
a registered relay endpoint; the relay (running on a developer's
machine, a CI runner, or a build-agent VM) dispatches via the
local CLI and returns a signed result.

This doc defines the wire contract between the two sides so the
Worker implementation is mechanical when it ships.

---

## Endpoint

```
POST  http://<relay-host>:<port>/relay/jobs
GET   http://<relay-host>:<port>/relay/health
```

Default port: ``7409``. Default host: ``127.0.0.1`` for security
(the relay is intended to run on the same machine as the agent
holding the Forge subscription key; expose to LAN/internet only
behind your own auth).

## Request envelope

The relay accepts the same shape as a JSON-RPC ``tools/call`` request,
plus an ``identity_claim`` field for attribution:

```json
{
  "jsonrpc": "2.0",
  "id": "<int|string>",
  "method": "tools/call",
  "params": {
    "name": "plan_apply",
    "arguments": {
      "plan_id": "PLAN-abc123",
      "card_id": "card-1",
      "project_root": "/abs/path/to/repo"
    }
  },
  "identity_claim": "<opaque token>"
}
```

The ``identity_claim`` is logged but NOT cryptographically verified
in v0.14.0-alpha. Attestation is a v0.14.1 deliverable (sign with
the Forge subscription key + AAAA-Nexus trust gate).

## Response envelope

```json
{
  "schema_version": "atomadic-forge.relay_job/v1",
  "started_at_utc": "2026-05-06T01:23:45Z",
  "duration_ms": 142,
  "ok": true,
  "identity_claim": "<echoed>",
  "method": "tools/call",
  "tool_name": "plan_apply",
  "response": {<JSON-RPC tools/call response — full envelope>},
  "error": null
}
```

On failure (impl raises, JSON parse error, unknown tool):

```json
{
  "ok": false,
  "error": "<ExcType>: <message>",
  "response": null,
  "...": "..."
}
```

The relay never raises across the wire — failures are surfaced
in the response body so clients can log + retry without exception
handling.

## Health endpoint

```
GET /relay/health
→ {"schema_version":"atomadic-forge.relay_health/v1",
   "ok":true,
   "project_root":"<abs path>"}
```

Worker callers should ping ``/relay/health`` before enqueuing the
first job to confirm the relay is reachable AND scoped to the
correct project_root.

## Audit log

Every dispatched job appends to
``.atomadic-forge/relay/jobs.jsonl`` on the relay side:

```jsonl
{"schema_version":"atomadic-forge.relay_job/v1","started_at_utc":"...","duration_ms":9,"ok":true,...}
```

Same log shape as the wire response. Tail-pollable via
``forge relay log --tail N``.

## Worker-side enqueue (TypeScript, ships in v0.14.0)

Pseudo-code for the Cloudflare Worker side:

```typescript
// In atomadic-forge-cloudflare-workers/mcp/src/a3_og_features/tool_dispatcher.ts
// for any case branch that currently returns localOnlyRedirect():

case "plan_apply": {
  const relayUrl = await env.FORGE_RELAY_REGISTRY.get(
    `relay:${subscriptionKey}`
  );
  if (!relayUrl) {
    // No registered relay — fall back to the v0.13.x "use local CLI" envelope.
    return localOnlyRedirect(name);
  }
  const job = {
    jsonrpc: "2.0", id: Date.now(),
    method: "tools/call",
    params: { name, arguments: args },
    identity_claim: subscriptionKey,
  };
  const r = await fetch(relayUrl + "/relay/jobs", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(job),
  });
  return await r.json();
}
```

KV layout: ``relay:<subscription_key>`` → relay URL string. Set
when the user registers a relay via ``forge.atomadic.tech/relay/register``
(v0.14.1 surface) or directly via Wrangler.

## Tools the relay can handle

Any tool registered in the Forge ``TOOLS`` dict (52 as of v0.13.4).
Filesystem-required tools that previously redirected become
relay-eligible:

- ``plan_apply``, ``rollback_plan``, ``finalize``,
  ``call_graph``, ``cna_check``, ``tool_factory``,
  ``guard_install``, ``iterate_start``, ``iterate_continue``,
  ``evolve_start``, ``evolve_step``, ``sidecar_validate``.

Plus all read-only tools (``recon``, ``verify``, ``certify``,
``emergent_swarm``, ``wisdom_*``, ``hive_*``, …) — though for
those the Worker can usually still serve directly via GitHub API
without the relay.

## Security model

v0.14.0-alpha:
- Bind to ``127.0.0.1`` by default (loopback only).
- ``identity_claim`` is logged for audit but not verified.
- No rate limiting; relays are short-lived per developer.

v0.14.1 (next):
- Sign request body with shared HMAC key per (worker, relay) pair.
- Verify signature before dispatch; refuse on mismatch.
- Append signed receipt (Sigstore + AAAA-Nexus) to the
  ``response.signature`` field.

v0.14.2 (later):
- Per-tool capability matrix — relay can refuse to dispatch tools
  outside its declared lane.
- Multiple relays per subscription, sharded by repo or queue
  partition (the swarm tier scaling story).

## Relationship to AAAA-Nexus

The relay protocol is stateless w.r.t. AAAA-Nexus, by design — it's
the local-side mechanical bridge. Trust gating, identity
attestation, and lineage recording happen at the Worker level
BEFORE the relay dispatch; verified results return to the Worker
for post-call signing. The relay just executes.

This keeps the relay binary surface tiny (~250 LOC of stdlib
Python) and the trust substrate centralized.

### AAAA-Nexus primitives the Worker side actually uses (as of 2026-05-06)

The Cognition agent probed AAAA-Nexus's deployed ``tools/list`` on
2026-05-06T00:00 UTC and confirmed the following primitives are
LIVE (27 tools total). The relay protocol's Worker side is
designed against these REAL names — not the
``nexus_consensus_*`` / ``nexus_swarm_*`` names that earlier
drafts of the v2 collab protocol assumed (those don't exist yet
on the deployed worker per WIS-cog-2026-05-06-handshake):

| Nexus primitive | Used by relay flow for |
|---|---|
| ``identity_verify`` | Verify caller identity claim before enqueue. |
| ``federation_mint`` | Mint a portable federation token bound to a DID; the Worker passes this through as the ``identity_claim`` so the relay (and downstream auditors) can attest the call. |
| ``authorize_action`` | Pre-call gate: is this caller permitted to invoke this tool against this repo? |
| ``sys_trust_gate`` | Drift / hallucination check on the Worker's pre-call view of the repo before dispatching. |
| ``contract_verify`` | Check the repo manifest hasn't drifted since the subscription was issued. |
| ``lineage_record`` | Append the (proposal → dispatch → result) chain to the persistent lineage log. |
| ``ratchet_register`` | Anti-replay: each relay job carries a monotonic ratchet stamp; replays rejected. |

What's NOT yet live on AAAA-Nexus (and our designs around it):

- ``nexus_consensus_*`` / ``nexus_swarm_*`` / ``nexus_agent_*`` — these
  are referenced in some workflow rules and earlier drafts of the
  collab protocol but **do not exist on the deployed worker** as of
  2026-05-06. Our v0.13.2 hive substrate (``hive_propose`` /
  ``hive_vote`` / ``hive_result`` / ``hive_observe``) is
  **Forge-native** and stands in for them; the swarm tier in v0.14
  builds against the Forge hive layer, not against assumed Nexus
  primitives. When Nexus ships those primitives, we add an opt-in
  bridge that mirrors hive consensus events into Nexus — but the
  Forge hive remains the local source of truth.

### Implementation note

The Worker-side enqueue pseudocode in this doc deliberately uses
ONLY primitives that exist today (``identity_verify``,
``federation_mint``, ``authorize_action``, ``sys_trust_gate``,
``lineage_record``). When v0.14.0 ships the Worker code, expect
exactly this surface — no dependency on unshipped Nexus primitives.

## What's already shipped (v0.14.0a1)

- ``a3_og_features/relay_daemon.py`` — handle_job + serve_http.
- ``commands/relay.py`` — CLI verb (serve / dispatch / log).
- Audit log at ``.atomadic-forge/relay/jobs.jsonl``.
- Live-tested: ``forge relay dispatch '{"jsonrpc":"2.0","id":1,
  "method":"tools/call","params":{"name":"doctor","arguments":{}}}'``
  returns ``ok=true`` in <10ms.

## What ships next (gated)

- **v0.14.0** (Worker-side enqueue + KV registry) — needs Thomas
  sign-off on the ``atomadic-forge-cloudflare-workers`` repo touch.
- **v0.14.1** — HMAC signing + signed receipt.
- **v0.14.2** — capability matrix + multi-relay sharding (the
  swarm tier scaling primitive).

When v0.14.0 ships, the world-collision endpoint becomes reachable:
Atomadic discovers a need → Forge plans it → relay applies it on
the developer's box → result returns signed → Atomadic surfaces
"Thomas, I made a thing." End-to-end, no stubs.
