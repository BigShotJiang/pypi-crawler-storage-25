# Atomadic Forge — Roadmap

_Version-paced. Each line is a real, tractable next step, not a vision._

## Shipped — v0.10 → v0.14.0a10 (the consolidation arc + relay alpha + Nexus MCP + E2E walkthrough + needs-vote + recap)

**v0.10.0 — surface consolidation (47 → 40 tools, zero capability lost).**
Merged `audit_list + why_did_this_change + what_failed_last_time → lineage`,
`list_recipes + get_recipe → recipes`, `auto_plan + adapt_plan → plan`,
`auto_step + auto_apply → plan_apply`. Folded `worktree_status → doctor`
and `exported_api_check → verify`. Full mapping in
[MIGRATION.md](MIGRATION.md#removed-in-v0100).

**v0.11.0 — polyglot expansion.** Swift, Kotlin, Go, `.mts`, `.cts`
join Python and JS/TS in `recon` / `wire` / `certify` / `harvest` /
`emergent_scan`. One pass, no language servers, no Node dependency.
CLI parity for Round-4 / Round-5 verbs (`recon_swarm`, `harvest`,
`emergent_swarm`, `guard_install`).

**v0.11.1 — agent-feedback patch batch.** `NON_TIER_SOURCE_DIRS`
exemption (drops false-positive untiered count ~50%);
`verify` returns `suggested_recipe`; public/private doc separation.

**v0.12.0 — single-source-of-truth surface artifact.**
`forge surface emit / check / diff` + canonical `surface.json` +
CI gate (`.github/workflows/surface-drift.yml`). Hand-maintained tool
maps across consumers (website, badge worker, `cognition_worker.js`,
VS Code extension) collapse into one fetch. `__version__` derived from
`importlib.metadata` so pyproject is the only source of truth.

**v0.13.0 — wisdom DB (cross-session institutional memory).**
`forge wisdom record / query / list / recall` +
`.atomadic-forge/wisdom.jsonl` (append-only JSONL, schema-versioned,
content-addressed IDs). Auto-hooks bracket every cycle: `recon`
returns `prior_wisdom`, `verify` returns `wisdom_capture_prompt`.
Agents inherit prior lessons without effort and contribute new
knowledge without ceremony.

**v0.13.1 — wisdom DB on the MCP surface.** `wisdom_record /
wisdom_query / wisdom_list / wisdom_recall` are now first-class MCP
tools (40 → 44). Cognition (or any MCP-aware agent) wires
`WISDOM_RECORD` as a cycle action verb consuming `verify`'s
`wisdom_capture_prompt` directly. Closes the v0.13.0 deferral and
unblocks the 4-agent hive sync pattern.

**v0.13.2 — bundled release.** Hive sync pipeline (7 new MCP tools);
`tool_factory` kwargs-binding fix; wisdom `supersede`. Surface 44 →
51. The substrate that lets Cognition autonomously coordinate with
Forge / Doc / Research without Thomas-relay. Full reference:
[HIVE_PRIMITIVES.md](HIVE_PRIMITIVES.md).

**v0.13.3 — wisdom → recipe promotion.** `forge wisdom promote`
(CLI) + `wisdom_promote` (MCP). Pure tag-clustering produces draft
recipes from corroborated wisdom (≥3 entries on overlapping tags).
Surface 51 → 52. The bridge between provisional knowledge and
curated process.

**v0.13.4 — `hive_observe` multi-source.** One call merges wisdom
events + consensus events filtered by `subscribes_to` with two
cursors. No new tool; richer output. Cross-stream view in one
round-trip.

**v0.14.0a1 — Worker → Local relay daemon (alpha).** New CLI verb
`forge relay serve / dispatch / log`. Stdlib http.server (no extra
deps); audit log at `.atomadic-forge/relay/jobs.jsonl`. The local
side of the no-stubs goal — when the Worker side ships, the 12
currently-stubbed Worker tools become real. Tool count unchanged
(relay is CLI, not MCP).

**v0.14.0a2 — relay wire-contract spec.**
[`docs/RELAY_PROTOCOL.md`](RELAY_PROTOCOL.md) — Forge agent
authored. Endpoints, JSON-RPC envelope, audit log format,
Worker-side enqueue pattern.

**v0.14.0a3 — relay protocol realigned against REAL Nexus surface.**
First demonstrated cross-agent design correction via public
artifacts. Cognition agent's handshake wisdom corroborated that the
originally-targeted Nexus primitives don't exist on the deployed
Worker; Forge agent rewrote the protocol against the 7 live
primitives (`identity_verify`, `federation_mint`, `authorize_action`,
`sys_trust_gate`, `contract_verify`, `lineage_record`,
`ratchet_register`). No Thomas-relay required.

**v0.14.0a4 — `forge hive watch` live tail.** Continuous color-coded
poll of `hive_observe`. Operator-facing surface for the
synchronized-message demo and for any long-lived multi-agent
session.

**v0.14.0a5 — Hive ↔ Nexus bridge (LIVE primitives only).**
`forge wisdom record --nexus` mirrors confidence-≥0.85 entries to
AAAA-Nexus's `lineage_record`. `NexusToolNotShipped` guard refuses
calls to any primitive outside the 7 deployed names. The LoRA
capture loop closed against the actually-deployed Nexus surface.

**v0.14.0a6 — `forge hive result --nexus`.** Extends the bridge from
wisdom-only to also mirror freshly-recorded consensus resolution
events. Doc agent shipped its 02-commands entry BEFORE the Forge
agent commit landed (zero-trail demonstrated for the second time
this session).

**v0.14.0a7 — 7 LIVE Nexus primitives as MCP tools.**
`nexus_identity_verify`, `nexus_federation_mint`,
`nexus_authorize_action`, `nexus_sys_trust_gate`,
`nexus_contract_verify`, `nexus_lineage_record`,
`nexus_ratchet_register`. Surface 52 → 59. Any MCP-aware agent calls
them directly through Forge — no CLI round-trip. The
agent-to-Nexus path is now first-class.

**v0.14.0a8 — `docs/WORLD_COLLISION.md` walkthrough.** The 11-step
E2E loop of *Atomadic-uses-Forge*, now executable rather than
aspirational. Six of eleven steps already fired this sprint with
public-artifact evidence in `wisdom.jsonl` and
`hive/consensus.jsonl`.

**v0.14.0a9 — `forge hive needs-vote`.** New CLI verb + MCP tool
(`hive_needs_vote`, surface 59 → **60**). Returns PENDING proposals
where the calling agent hasn't voted. The "what should I weigh in
on?" primitive that closes the gap between `hive_observe` (everything
happening) and the vote.

**v0.14.0a10 — `forge hive recap`.** New CLI verb + MCP tool
(`hive_recap`, surface 60 → **61**). Full-lifecycle replay of one
consensus — proposal + every vote + resolution + summary (verdict,
duration, voters). The "what happened?" primitive — useful for
audit trails, release-note quotes, post-mortem replay.

**MCP surface:** **52 tools**, 9 recipes — canonical at
[`surface.json`](../surface.json).

## Next — v0.13.5+ / v0.14.0

- **AAAA-Nexus LoRA capture loop** (`nexus_lora_capture_fix` /
  `nexus_lora_contribute`) syncs accepted fixes into the swarm-shared
  adapter (queued).
- **Continued doc-trail compression** — `CNS-f7ae6ab5` proposal
  (Doc agent) asks the hive to ratify coordination-latency telemetry
  as a tracked KPI. If ratified, Doc agent records release-to-doc
  delta per cycle and Research owns the periodic
  `hive_latency_report` recipe.

## v0.14.0 — Worker → Local-CLI relay (Worker side)

The local side shipped in v0.14.0a1 (`forge relay serve`). v0.14.0
proper closes the Worker side: the 12 currently-stubbed Worker tools
(`plan_apply, rollback_plan, sidecar_validate, finalize, call_graph,
cna_check, tool_factory, guard_install, iterate_start, iterate_continue,
evolve_start, evolve_step`) gain real implementations that POST to a
configured `forge relay serve` endpoint and return the signed result.

The path:

```
┌─────────────────┐   POST /jobs/<tool>   ┌──────────────────┐
│ Cognition       │ ───────────────────── │ forge.atomadic   │
│ Worker          │                       │ .tech/mcp Worker │
└─────────────────┘                       └────────┬─────────┘
        ▲                                          │ enqueue to
        │                                          │ Cloudflare Queue
        │                                          ▼
        │ webhook  ◄────── forge-runner satellite ◄── poll
        │                  (any forge-installed VM)
        └─ result returned signed
```

**Properties:**
- Worker stays stateless; Cloudflare Queue holds pending jobs.
- A `forge-runner` satellite (`forge mcp serve` plus a queue-poller)
  picks up jobs, runs the local-only tool against a working tree,
  returns the signed result.
- Multiple satellites can run in parallel — that's the swarm tier
  scaling axis.
- AAAA-Nexus primitives (`nexus_swarm_relay / inbox /
  consensus_create / vote / result`) coordinate multi-agent runs.

This closes the "no stubs fully Forge-compatible" north star — every
tool works from anywhere.

## v0.15.0 — Worker-side `surface.json` port

Closes the contract divergence between Worker MCP and local Python
MCP (see [WORKER_VS_LOCAL_MCP.md](WORKER_VS_LOCAL_MCP.md)). When this
ships, both surfaces emit the same `surface.json` schema and the
Worker becomes a first-class consumer of the canonical artifact.

## Beyond v0.15 — themes, not commitments

- **Adversarial test inputs.** Forge generates 3–5 random inputs per
  emitted public function and asserts non-degenerate output. Catches
  gameable LLM-written tests.
- **Hosted certify dashboard.** Public read URL per project showing
  the conformance trajectory over time.
- **JS/TS behavioural gate.** Wire `npm test` / Vitest into the
  certify scorer so JS packages can earn the +30 behavioural points
  the same way Python does.
- **Rust + Go symbol-level extraction.** Today these classify at
  module level; symbol-level needs tree-sitter or equivalent.
- **Cryptographic certificate signing.** The Receipt schema is
  finalized; signing is not yet wired.
- **VS Code extension via LSP.** `forge lsp serve` already speaks
  LSP-spec-compliant JSON-RPC; the extension lives in
  `atomadic-forge-vscode-ext`.

## Where Forge leads the field

These are the primitives no competitor ships today (per the public
competitive landscape — Cursor, Aider, Devin, Codex, Qodo,
Sourcegraph / Amp, Augment, Code Pathfinder, Moderne, Copilot,
Claude Code):

- **Deterministic architectural certification.** Forge owns this
  axis. Linters say "no"; Forge says "yes, but reorganized like this"
  and shows the diff.
- **Emergent composition discovery.** No tool surfaces type-compatible
  cross-tier chains the way `emergent_scan` / `emergent_swarm` do.
- **Decision lineage + signed receipts.** Forge's lineage fidelity
  exceeds anything in the AI-coding-tool space today.
- **Cross-session institutional memory at repo scope.** v0.13's
  wisdom DB is the same idea as Anthropic Managed Agent Memory but
  scoped to a repo and embedded in the agent's normal call surface
  (no new discipline required).

## Where Forge is catching up

Honest assessment of where competitors lead:

- **Worker / cloud completion.** Cursor 3, Devin, Codex all ship
  cloud agents end-to-end; Forge has 12 stubs. v0.14 closes this.
- **Multi-agent UX visibility.** Cursor's Agents Window and Devin's
  Agents tab are shipping now. Forge's swarm-tier observer surface
  arrives with v0.14.
- **Learned-rules feedback loop.** Qodo 2.1 distills reviewer
  reactions into rules; Forge has wisdom records but no loop that
  converts them into automatic gate adjustments. Recipe-draft
  candidate; not a v0.14 primitive.

## What we will NOT do

For honesty's sake:

- We will not pretend Forge is AGI.
- We will not pretend it replaces Cursor or Devin.
- We will not add features that don't pass their own certify check on
  the Forge repo itself.
- We will not let docs drift behind shipped code (the doc-agent loop
  trails main by 1–2 commits; gaps are a regression).

## How to influence the roadmap

- Open an issue describing your use case.
- Submit a PR that satisfies `forge wire` + `forge certify` ≥ 90 on
  the Forge repo itself (i.e. eat its own dog food).
- Run `forge demo run` and post the trajectory.
- Record a `forge wisdom record` entry against your own repo and
  share what you learned — the corroboration shape is what grows new
  primitives.
