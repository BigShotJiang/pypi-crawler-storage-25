# `tool_factory` — Forge eats Forge

> **What this is:** the meta-tool that scaffolds new MCP tools onto the Forge surface. Adding a tool by hand was ~80–150 lines of boilerplate across three files; `tool_factory` cuts that to a single call. This walkthrough shows the full add-a-tool loop from idea → live MCP call, so a contributing dev or agent can ship a new capability in one session.

**Audience:** anyone (dev, agent, or copilot) extending Forge's MCP surface.
**Time:** ~10 minutes for plan-mode → review → apply.
**Output:** a new tool live in MCP, with passing pinned test, ready to commit.

---

## 1. The four-piece scaffold

Every Forge MCP tool spans **four insertion points** across three files:

| File | Insert | Purpose |
|---|---|---|
| `a1_at_functions/mcp_protocol.py` | `_tool_<name>_unbound` stub | "not wired" placeholder; what callers hit before the a3 binding lands |
| `a1_at_functions/mcp_protocol.py` | `_<name>_handler` global + `register_<name>_handler` setter | late-binding seam; lets a3 inject the real implementation without a1 importing upward |
| `a1_at_functions/mcp_protocol.py` | `TOOLS["<name>"]` registry entry | name → schema + description, what `tools/list` returns |
| `a3_og_features/mcp_server.py` | `_bound_<name>` + `register_<name>_handler(_bound_<name>)` | the actual a3 → a1 wire-up at server boot |

Plus the test:

| File | Insert | Purpose |
|---|---|---|
| `tests/test_mcp_protocol.py` | pinned-tool assertion update + smoke test | catches accidental tool removal; smokes the unbound stub |

Optionally `a3_og_features/<name>_feature.py` if you tell `tool_factory` to scaffold the implementation file too.

`tool_factory` emits all five pieces from one spec. Two modes: **plan** (text only, you review) and **apply** (writes the four files + test, idempotent).

---

## 2. The minimum spec

```python
from atomadic_forge.a3_og_features.tool_factory import scaffold_tool

artifact = scaffold_tool(
    tool_name="my_thing",
    use_this_when="you want forge to do the thing",
    body_description="One-paragraph description of what the tool does.",
    input_schema={
        "type": "object",
        "properties": {
            "project_root": {"type": "string"},
            "depth": {"type": "integer", "default": 3},
        },
        "additionalProperties": False,
    },
    handler_module="atomadic_forge.a3_og_features.my_feature",
    handler_callable="run_my_thing",
    create_module=True,   # also emit a3 starter module
    apply=False,          # plan first
)
```

The artifact has five sections:

- `a1_inserts: dict[str, str]` — keyed by insertion point (e.g. `"unbound_stub"`, `"handler_setter"`, `"tools_dict_entry"`)
- `a3_inserts: dict[str, str]` — keyed similarly (e.g. `"bound_handler"`, `"register_call"`)
- `test_inserts: dict[str, str]` — pinned-tool delta + smoke test body
- `optional_module_text: str` — the a3 starter module if `create_module=True`
- `acceptance_checklist: list[str]` — what you need to verify before merging

Plus `notes: list[str]` for any caveats the scaffolder flagged.

---

## 3. Plan → review → apply

### 3a. Plan mode (`apply=False`)

```python
artifact = scaffold_tool(..., apply=False)
print(artifact.as_dict())  # five blocks of text
```

Read every block. The scaffolder is deterministic but not omniscient:

- Does the `tools_dict_entry` description make sense to a fresh agent?
- Is the `bound_handler` import path correct?
- Is the smoke test asserting the right invariant?

Tweak the spec until the printed text is right.

### 3b. Apply mode (`apply=True`)

```python
artifact = scaffold_tool(..., apply=True, project_root=Path("."))
```

What changes:

1. `mcp_protocol.py` gets the unbound stub, handler setter, and `TOOLS["<name>"]` entry inserted at their canonical sites (located via `forge_locate`).
2. `mcp_server.py` gets the bound handler import + `register_<name>_handler(...)` call appended to the registration block.
3. `tests/test_mcp_protocol.py` pinned-tool set is updated and a new smoke test is appended.
4. If `create_module=True`, `a3_og_features/<name>_feature.py` is written from the starter template.

The applier is **idempotent**: if `<name>` is already in `TOOLS`, it refuses to re-insert and returns `applied=False`. No file is half-modified.

Audit fields populated on apply:

- `applied: True`
- `files_modified: ["src/atomadic_forge/a1_at_functions/mcp_protocol.py", ...]`
- `insertion_points_filled: ["a1.unbound_stub", "a1.handler_setter", "a1.tools_dict_entry", "a3.bound_handler", "a3.register_call", "tests.pinned_set", "tests.smoke"]`

Commit those file paths and you're live.

---

## 4. The full loop, end to end

This is the "Forge eats Forge" demo arc — useful for an agent that just decided it needs a new capability and wants to ship it without touching boilerplate.

```text
┌─ idea ─────────────────────────────────────────────┐
│ "I want a tool that returns ROI estimates           │
│  per refactor candidate."                           │
└────────────────────────────────────────────────────┘
            │
            ▼
┌─ 1. plan ──────────────────────────────────────────┐
│ scaffold_tool(                                     │
│   tool_name="roi_estimate",                        │
│   use_this_when="you need ROI per refactor",       │
│   body_description="...",                          │
│   handler_module="atomadic_forge....roi_estimator",│
│   handler_callable="estimate_roi",                 │
│   create_module=True,                              │
│   apply=False,                                     │
│ )                                                  │
└────────────────────────────────────────────────────┘
            │
            ▼
┌─ 2. review ────────────────────────────────────────┐
│ Read artifact.a1_inserts, a3_inserts, test_inserts │
│ + acceptance_checklist. Tweak the spec if needed.  │
└────────────────────────────────────────────────────┘
            │
            ▼
┌─ 3. apply ─────────────────────────────────────────┐
│ scaffold_tool(..., apply=True, project_root=...)   │
│ → 3 files modified, 1 file created, idempotent.    │
└────────────────────────────────────────────────────┘
            │
            ▼
┌─ 4. implement ─────────────────────────────────────┐
│ Open the new a3 module. Replace the                │
│ NotImplementedError body with the real logic.      │
└────────────────────────────────────────────────────┘
            │
            ▼
┌─ 5. verify ────────────────────────────────────────┐
│ pytest tests/test_mcp_protocol.py -k roi_estimate  │
│ forge verify .                                     │
│ → verdict PASS, suggested_recipe: null             │
└────────────────────────────────────────────────────┘
            │
            ▼
┌─ 6. ship ──────────────────────────────────────────┐
│ git add -A && forge commit_compose --intent ...    │
│ → MCP host restart picks up the new tool           │
└────────────────────────────────────────────────────┘
```

Steps 1–3 are mechanical (`tool_factory`). Step 4 is where the actual thinking lives. Steps 5–6 are forge driving forge.

---

## 5. Idempotence + safety

`tool_factory` is **trust-gated by design**:

- **Plan mode is pure.** No filesystem writes. You can run it 100 times.
- **Apply mode is idempotent.** Running it twice with the same `tool_name` is a no-op the second time (returns `applied=False, notes=["tool already registered"]`).
- **No silent overwrites.** If a target file is missing or the insertion site can't be located by `forge_locate`, apply fails loud with the file path and the missing marker.
- **Schema-version drift caught at test time.** `tests/tools_snapshot.json` pins the full surface; the new tool either matches or the test fails. (If you regenerate the snapshot, do it explicitly — `pytest --snapshot-update`.)

---

## 6. When NOT to use `tool_factory`

- **Renames.** It only inserts; it doesn't migrate. Use the editor.
- **Tool deletions.** Same — manual edit + snapshot update.
- **Cross-tool refactors** (e.g. "merge `audit_list + why_did_this_change` into `lineage`" — what v0.10.0 did). `tool_factory` scaffolds new tools, not merger umbrellas. Hand-write the umbrella; let `tool_factory` handle anything new it spawns.

---

## 7. Worked example: the four CLI verbs added in v0.10.x

Today's session shipped four new CLI verbs (`emergent_swarm`, `recon_swarm`, `harvest`, `guard_install`) that were already MCP-only. `tool_factory` wasn't used because **the MCP side was already complete** — the missing surface was Typer wrappers, which live in `commands/<name>.py`. The pattern there is the symmetric one to `tool_factory`:

| Layer | Already has | Needs |
|---|---|---|
| MCP tool | `tool_factory` | — |
| CLI verb | hand-written `commands/<name>.py` + one tuple in `_register_specialty_apps` | a `cli_factory` that mirrors `tool_factory`'s shape |

If we ever build `cli_factory` (filed in `FORGE_FEEDBACK.md` as wishlist item: auto-generate Typer wrappers from the `TOOLS` dict), the two scaffolders together close the loop: every new capability becomes one spec → both surfaces live.

---

## 8. Reference: spec field cheat-sheet

| Field | Type | Required? | Notes |
|---|---|---|---|
| `tool_name` | `str` | yes | snake_case, validated against `[a-z][a-z0-9_]*[a-z0-9]` |
| `use_this_when` | `str` | yes | trigger sentence; "Use this when: " is prepended |
| `body_description` | `str` | yes | rest of the tool description |
| `input_schema` | `dict | None` | no | JSON Schema; defaults to permissive empty-object |
| `handler_module` | `str` | yes-ish | dotted path, e.g. `atomadic_forge.a3_og_features.my_feature` |
| `handler_callable` | `str` | yes-ish | callable name inside `handler_module` |
| `create_module` | `bool` | no | also emit a3 starter module — default `False` |
| `apply` | `bool` | no | plan vs apply — default `False` (plan) |
| `project_root` | `Path | str | None` | apply-only | required when `apply=True`; otherwise the applier doesn't know which repo to mutate |

Description length is soft-capped at 1500 chars (3-letter ellipsis applied if over). Schema versions are auto-generated as `atomadic-forge.<name>/v1`.

---

## 9. Where to look next

- **Source:** `src/atomadic_forge/a3_og_features/tool_factory.py`
- **MCP wrapper:** `_bound_tool_factory` in `mcp_server.py`
- **Schema:** `SCHEMA_VERSIONS["tool_factory"]` in `a0_qk_constants/schema_version_registry.py`
- **Recipe:** `add_cli_command` in `recipes.py` (CLI side); a parallel "add_mcp_tool" recipe is filed as wishlist
- **Tests:** `tests/test_tool_factory*.py`

If you're new and just want to feel the loop, run plan mode against a throwaway tool name and read the artifact. The text the scaffolder emits is the documentation.
