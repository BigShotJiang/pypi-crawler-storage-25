# `atomadic-forge harvest`

_Round-4: find symbols the target lacks but source repos have. Trust-gated by trust threshold._

- **Module**: `atomadic_forge.commands.harvest`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

