# `atomadic-forge wisdom`

_Record / query / list cross-session wisdom — the institutional knowledge layer between lineage events and curated recipes._

- **Module**: `atomadic_forge.commands.wisdom`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

