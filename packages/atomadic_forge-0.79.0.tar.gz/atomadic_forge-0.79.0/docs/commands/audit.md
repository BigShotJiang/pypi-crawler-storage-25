# `atomadic-forge audit`

_Surface the .atomadic-forge lineage log: list runs, inspect saved manifests, replay history._

- **Module**: `atomadic_forge.commands.audit`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

