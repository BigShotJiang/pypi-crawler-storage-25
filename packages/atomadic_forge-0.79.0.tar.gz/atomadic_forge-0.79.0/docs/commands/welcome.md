# `atomadic-forge welcome`

_First-call handshake — scout + certify + wire packaged into one response so the agent immediately knows the repo state, top strengths, top priorities, and the single most useful next call._

- **Module**: `atomadic_forge.commands.welcome`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

