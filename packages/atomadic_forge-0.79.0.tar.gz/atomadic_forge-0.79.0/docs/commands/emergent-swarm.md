# `atomadic-forge emergent-swarm`

_Round-5: cross-repo emergent composition discovery. Find chains visible only across the union of N repos._

- **Module**: `atomadic_forge.commands.emergent_swarm`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

## Scoring

Each candidate receives a `score_boosted` value. Candidates whose most
frequent constituent symbol appears in more than 3 chains across the
swarm receive a hub-node penalty: 10 points are deducted from
`score_boosted` per doubling of that symbol's cross-chain frequency
above the threshold (floor at 0). This prevents a single high-connectivity
connector from dominating all top-N slots. Penalised candidates carry
`hub_penalty` and `hub_max_symbol_freq` in their output.

