# `atomadic-forge metrics`

_Emit forge_metrics.json — canonical metrics for README/CHANGELOG/welcome/worker._

- **Module**: `atomadic_forge.commands.metrics`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

## Forge metrics

Use the top-level command when updating Forge's own public counters.

```bash
forge metrics
forge metrics --apply
forge metrics --json
```

`--apply` rewrites `forge_metrics.json`. This artifact is Forge-specific:
README badges, release automation, and Worker metadata read from it.

## Product repo metrics

Use the `repo` subcommand when updating any product repository's own public
surface.

```bash
forge metrics repo --project /path/to/product
forge metrics repo --project /path/to/product --apply
forge metrics repo --project /path/to/product --json
forge metrics repo --project /path/to/product --init-config --apply
forge metrics repo --project /path/to/product --apply --commit --push
```

The repo sync is intentionally separate from Forge metrics. It computes the
target repo's source files, source lines, test files, languages, name, and
version, then plans these bounded writes:

| File | Update |
|------|--------|
| `repo_metrics.json` | Canonical product metrics artifact |
| `README.md` | Metrics copy block between `<!-- forge:metrics:start -->` markers |
| `server.json` | MCP registry version and description, when present |

Dry-run is the default. Passing `--apply` writes the product surface and does
not mutate `forge_metrics.json`.

### Config and live external surfaces

Repos can opt into a custom metrics surface with
`.atomadic-forge/repo-metrics.config.json`:

```json
{
  "schema_version": "atomadic-forge.repo_metrics_config/v1",
  "artifact_path": "public/metrics.json",
  "document_globs": ["README.md", "docs/**/*.md", "website/**/*.mdx"],
  "readme_block": true,
  "sync_server_json": true,
  "extra_metrics": {
    "customer_count": 42
  },
  "aliases": {
    "customers": "customer_count"
  }
}
```

`artifact_path` is the JSON file your site or Worker can serve. For example,
set it to `public/metrics.json`, deploy that folder, and the website can fetch
the same live repo metrics as ordinary JSON.

Any configured document can contain inline metric markers:

```md
Source files: <!-- forge:metric key=source_file_count format=comma -->0<!-- /forge:metric -->
Customers: <!-- forge:metric customers -->0<!-- /forge:metric -->
Languages: <!-- forge:metric languages -->unknown<!-- /forge:metric -->
```

On `forge metrics repo --apply`, Forge scans the configured document globs,
updates every marker it finds, writes the metrics artifact, and leaves
unmarked prose alone. Supported marker formats are `plain`, `comma`,
`compact`, and `json`. Markers inside fenced code blocks are treated as
examples and are not updated.

For release automation, pass `--commit` to stage and commit only the files
Forge planned to write. Pass `--push` to commit if needed and push the current
branch after the metrics surface is refreshed.

