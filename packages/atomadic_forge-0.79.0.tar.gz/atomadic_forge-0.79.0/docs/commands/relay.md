# `atomadic-forge relay`

_Local relay daemon — receive signed job requests from the Worker MCP and dispatch them through the local CLI. v0.14.0-alpha._

- **Module**: `atomadic_forge.commands.relay`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

