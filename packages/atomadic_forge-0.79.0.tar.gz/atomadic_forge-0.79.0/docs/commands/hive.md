# `atomadic-forge hive`

_Hive sync pipeline — agent registry + observation + consensus. The 4-agent collaboration substrate._

- **Module**: `atomadic_forge.commands.hive`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

