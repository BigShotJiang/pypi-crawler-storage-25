# `atomadic-forge create`

_One-command pipeline: scan local seed repos for emergent compositions and materialize the top-N into a shippable package._

- **Module**: `atomadic_forge.commands.create`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

