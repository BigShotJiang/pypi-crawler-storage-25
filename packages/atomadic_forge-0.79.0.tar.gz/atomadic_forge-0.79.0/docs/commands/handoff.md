# `atomadic-forge handoff`

_Capture a structured session handoff so the next agent can pick up where this one left off. Writes JSON to .atomadic-forge/handoffs/<session_id>.json._

- **Module**: `atomadic_forge.commands.handoff`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

