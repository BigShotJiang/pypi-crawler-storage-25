# ASS-ADE Commands

Auto-generated index. One row per top-level CLI verb.

| Verb | Help | Source | Surface |
|------|------|--------|---------|
| `absorb` | Absorb any Python repo (crewAI, langgraph, autogen, babyagi, …) into a tier-organized Atomadic package. | `atomadic_forge_seed` | `typer_app` |
| `audit` | Surface the .atomadic-forge lineage log: list runs, inspect saved manifests, replay history. | `atomadic_forge_seed` | `typer_app` |
| `chat` | Chat with a Forge-aware AI copilot over optional repo context. | `atomadic_forge_seed` | `typer_app` |
| `commandsmith` | ``atomadic-forge commandsmith`` — manage the auto-wired CLI command registry. | `atomadic_forge_seed` | `typer_app` |
| `config` | Configure Atomadic Forge — setup wizard + config management. | `atomadic_forge_seed` | `typer_app` |
| `create` | One-command pipeline: scan local seed repos for emergent compositions and materialize the top-N into a shippable package. | `atomadic_forge_seed` | `typer_app` |
| `demo` | One-shot launch-video verb: preset evolve + DEMO.md artifact. | `atomadic_forge_seed` | `typer_app` |
| `emergent` | Synthesise new feature candidates from existing components. | `atomadic_forge_seed` | `typer_app` |
| `emergent-swarm` | Round-5: cross-repo emergent composition discovery. Find chains visible only across the union of N repos. | `atomadic_forge_seed` | `typer_app` |
| `emergent-then-synergy` | Run emergent to emit a JSON artifact, then feed it to synergy for the next phase. | `atomadic_forge_seed` | `typer_app` |
| `enhancement` | Submit / list / show / publish Forge enhancement proposals — the self-improvement loop. Trust-gated at submission, human-gated at publish. | `atomadic_forge_seed` | `typer_app` |
| `evolve` | Recursive self-improvement: run iterate N times, each round seeded by the previous round's growing catalog. | `atomadic_forge_seed` | `typer_app` |
| `evolve-then-iterate` | Run evolve to emit a JSON artifact, then feed it to iterate for the next phase. | `atomadic_forge_seed` | `typer_app` |
| `feature-then-emergent` | Run any feature, then fan its JSON output into emergent scan to surface novel compositions. | `atomadic_forge_seed` | `typer_app` |
| `guard-install` | Round-5: install the four-layer architectural guard (pre-commit, CI workflow, CONTRIBUTING note, .forge-guard.json). | `atomadic_forge_seed` | `typer_app` |
| `handoff` | Capture a structured session handoff so the next agent can pick up where this one left off. Writes JSON to .atomadic-forge/handoffs/<session_id>.json. | `atomadic_forge_seed` | `typer_app` |
| `harvest` | Round-4: find symbols the target lacks but source repos have. Trust-gated by trust threshold. | `atomadic_forge_seed` | `typer_app` |
| `hive` | Hive sync pipeline — agent registry + observation + consensus. The 4-agent collaboration substrate. | `atomadic_forge_seed` | `typer_app` |
| `iterate` | Architecturally-coherent code generation: LLM emits, Forge enforces, loop iterates until certify clears. | `atomadic_forge_seed` | `typer_app` |
| `materialize` | Turn emergent scan candidates into a shippable Python package (scaffold + features + certify). | `atomadic_forge_seed` | `typer_app` |
| `metrics` | Emit forge_metrics.json — canonical metrics for README/CHANGELOG/welcome/worker. | `atomadic_forge_seed` | `typer_app` |
| `recon-swarm` | Round-4: walk N repos, return a unified scout report with origin_repo annotations on every symbol. | `atomadic_forge_seed` | `typer_app` |
| `relay` | Local relay daemon — receive signed job requests from the Worker MCP and dispatch them through the local CLI. v0.14.0-alpha. | `atomadic_forge_seed` | `typer_app` |
| `surface` | Emit / check / diff the canonical Forge surface artifact (single source of truth for tools, recipes, schemas). | `atomadic_forge_seed` | `typer_app` |
| `synergy` | Find feature/CLI synergies (producer-consumer pairs that aren't wired together) and optionally implement adapters. | `atomadic_forge_seed` | `typer_app` |
| `synergy-then-emergent` | Run synergy to emit a JSON artifact, then feed it to emergent for the next phase. | `atomadic_forge_seed` | `typer_app` |
| `welcome` | First-call handshake — scout + certify + wire packaged into one response so the agent immediately knows the repo state, top strengths, top priorities, and the single most useful next call. | `atomadic_forge_seed` | `typer_app` |
| `wisdom` | Record / query / list cross-session wisdom — the institutional knowledge layer between lineage events and curated recipes. | `atomadic_forge_seed` | `typer_app` |
