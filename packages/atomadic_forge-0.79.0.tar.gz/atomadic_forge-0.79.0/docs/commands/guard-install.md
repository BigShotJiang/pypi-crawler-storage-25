# `atomadic-forge guard-install`

_Round-5: install the four-layer architectural guard (pre-commit, CI workflow, CONTRIBUTING note, .forge-guard.json)._

- **Module**: `atomadic_forge.commands.guard_install`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

