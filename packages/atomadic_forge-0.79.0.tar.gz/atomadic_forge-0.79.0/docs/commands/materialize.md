# `atomadic-forge materialize`

_Turn emergent scan candidates into a shippable Python package (scaffold + features + certify)._

- **Module**: `atomadic_forge.commands.materialize`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

