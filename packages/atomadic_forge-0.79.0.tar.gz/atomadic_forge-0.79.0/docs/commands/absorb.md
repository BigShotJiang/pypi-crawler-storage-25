# `atomadic-forge absorb`

_Absorb any Python repo (crewAI, langgraph, autogen, babyagi, …) into a tier-organized Atomadic package._

- **Module**: `atomadic_forge.commands.absorb`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

