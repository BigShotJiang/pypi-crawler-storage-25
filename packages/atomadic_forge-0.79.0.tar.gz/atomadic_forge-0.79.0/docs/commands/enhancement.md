# `atomadic-forge enhancement`

_Submit / list / show / publish Forge enhancement proposals — the self-improvement loop. Trust-gated at submission, human-gated at publish._

- **Module**: `atomadic_forge.commands.enhancement`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

