# `atomadic-forge surface`

_Emit / check / diff the canonical Forge surface artifact (single source of truth for tools, recipes, schemas)._

- **Module**: `atomadic_forge.commands.surface`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

