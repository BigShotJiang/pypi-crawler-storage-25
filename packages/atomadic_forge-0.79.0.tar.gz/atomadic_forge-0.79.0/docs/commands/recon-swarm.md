# `atomadic-forge recon-swarm`

_Round-4: walk N repos, return a unified scout report with origin_repo annotations on every symbol._

- **Module**: `atomadic_forge.commands.recon_swarm`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

