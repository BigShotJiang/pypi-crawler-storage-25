# Migration Guide — moving across Forge versions

The agent-readable map of where every removed tool went. If your code
references a name that's not in the current `tools/list`, look here.

## Removed in v0.10.0

The 47 → 40 surface consolidation merged or folded 11 tools. **Zero
capability loss** — every old call is reachable through the replacement.

| Old call (≤ v0.9.0) | New call (≥ v0.10.0) | Notes |
|---|---|---|
| `audit_list` | `lineage` (no args) | Auto-detected `mode=all`. |
| `why_did_this_change {file: "src/x.py"}` | `lineage {file: "src/x.py"}` | Auto-detected `mode=by_file`. |
| `what_failed_last_time {area: "auth"}` | `lineage {area: "auth"}` | Auto-detected `mode=failed_for_area`. |
| `list_recipes` | `recipes` (no args) | Catalogue summary. |
| `get_recipe {name: "..."}` | `recipes {name: "..."}` | Full recipe body. |
| `auto_plan {repo_url, goal}` | `plan {repo_url, goal}` | Identical shape; routes through the agent_plan path. |
| `adapt_plan {plan, capability_filter}` | `plan {plan, capability_filter}` | Passing a `plan` dict triggers the adapt branch. |
| `auto_step {repo_url, step_index}` | `iterate_continue {repo_url, step_index}` | Stepwise iteration. |
| `auto_apply {repo_url, goal}` | `auto {repo_url, goal}` (full pipeline) **or** `plan_apply {card_id}` (one card from a prior plan) | Pick by intent. |
| `worktree_status` | `doctor {include_worktree: true}` | Folded as an opt-in arg. |
| `exported_api_check {source: "..."}` | `verify {check_exports: true, source: "..."}` | Folded as an opt-in arg. |

## Added since v0.10.0 (current 40-tool surface)

If a tool name shows up in `tools/list` but isn't in your prior code,
it's most likely one of these. Full descriptions in
[../README.md](../README.md#all-40-mcp-tools).

- **`verify`** — composite go/no-go gate. Wire + certify together
  (plus optional preflight + score_patch). Returns
  `PASS / REFINE / FAIL` with a recommended `next_command`. The single
  highest-leverage primitive in the v0.10+ surface.
- **`lineage`** / **`recipes`** / **`plan`** / **`plan_apply`** — see
  the table above.
- **`tool_factory`** — Forge eats Forge: scaffold a new MCP tool from a spec.
- **`forge_locate`** — return a 5-line preview of well-known insertion
  points (TOOLS dict, `__all__`, register block, MCP server imports,
  test pinned set) without re-reading the full file. Saves ~1000
  tokens per call.
- **`commit_compose`** — one-call Conventional Commit message from
  staged diff + intent.
- **Round-4 / Round-5 cross-repo** — `recon_swarm`, `harvest`,
  `emergent_swarm`, `guard_install`. CLI parity shipped in v0.11.0.

## v0.11.0 — polyglot expansion

No tools removed or added. The change is internal to `recon`, `wire`,
`certify`, `harvest`, `emergent_scan`, etc.: source files in **Swift**
(`.swift`), **Kotlin** (`.kt`, `.kts`), **Go** (`.go`), and modern
TypeScript modules (`.mts`, `.cts`) now harvest end-to-end alongside
the existing Python and JS/TS support.

Symbol-level extraction for the new languages (functions / classes /
structs as separate symbols, not just module-level) is a Phase-2 step
on the v0.12 roadmap. Today the new languages surface as `module`-kind
symbols with a path-derived `tier_guess` and conservative `state`
default effects.

New return fields on `recon` / `harvest_repo`:
- `swift_file_count`, `kotlin_file_count`, `go_file_count`
- `language_distribution.swift`, `.kotlin`, `.go`

Existing fields preserved exactly.

## v0.11.1 — agent-feedback patch batch + repo hygiene

Four targeted signal-cleanup fixes filed by an external agent session.
Cosmetic in surface, correctness in substance.

- **`certify` / `count_untiered_source_files`** — `tests`, `test`,
  `scripts`, `examples`, `benchmarks`, `bench` are now exempt from the
  untiered count. Drops false-positive count ~50% on real repos. Score
  unchanged at 100; signal cleaned.
- **`verify` → `suggested_recipe`** — every `verify` response now
  carries a `suggested_recipe` field mapping the dominant failing axis
  to a concrete recipe name.
- Public/private doc separation pass before push.

No tools removed or added. No migration steps required for callers.

## v0.12.0 — single-source-of-truth surface artifact

Drift between registries (`pyproject.toml` ↔ `__init__.py` ↔ TOOLS
dict ↔ `schema_version_registry` ↔ website ↔ badge worker) gets a
structural fix: one canonical artifact, every consumer reads it.

- **New top-level verb `forge surface`** with three subcommands:
  `emit` (canonical artifact to stdout or file), `check` (CI gate;
  exit 1 on drift), `diff` (delta between two `surface.json` files).
- **`surface.json` is now checked into the repo root.** Schema:
  `atomadic-forge.surface/v1`. All downstream consumers (the website,
  the badge worker, `cognition_worker.js`, the VS Code extension)
  should fetch this artifact instead of maintaining hand-rolled tool
  maps.
- **`legacy_endpoint_map`** in `surface.json` lists the 11 v0.10.0
  mergers so a stale caller can resolve `audit_list` →
  `lineage` (etc.) in one lookup, without a separate request.
- **CI gate** at `.github/workflows/surface-drift.yml` runs on every
  PR that touches the registries OR `surface.json`. Failure prints
  the one-line fix-up command:

  ```bash
  forge surface emit --out surface.json && git add surface.json
  ```

- **`__version__` drift fix.** `src/atomadic_forge/__init__.py`
  derives `__version__` from `importlib.metadata.version("atomadic-forge")`
  with `"0.0.0+dev"` fallback. The v0.11.0 drift (pyproject 0.11.0,
  `__init__` 0.10.0) is structurally impossible going forward.

**Migration steps for callers:**

1. If you have any hand-maintained tool/recipe maps, replace them with
   a single fetch of `surface.json` from the repo root (or the
   identically-shaped artifact emitted by the Worker's `surface`
   endpoint when v0.15.0 ships).
2. If you depend on `__version__`, no action needed — the value is now
   authoritative.
3. CI gate runs automatically on this repo; if you fork, copy
   `.github/workflows/surface-drift.yml`.

## v0.13.0 — wisdom DB (cross-session institutional memory)

Per-session agent insights used to evaporate when the conversation
ended. Now they don't.

- **New top-level verb `forge wisdom`** with four subcommands:
  `record` (append an entry), `query` (relevance-rank against a query),
  `list` (full DB read; active by default), `recall` (top-N
  repo-scoped wisdom — same surface `recon` exposes via `prior_wisdom`).
- **Auto-hooks bracket every cycle.**
  - **Phase 0 / Recon hook:** `forge recon TARGET` (and the MCP
    `recon` and `context_pack` tools) now return a `prior_wisdom`
    field with the top-5 relevant entries scored by scope match + tag
    overlap + text contains + confidence + age decay. Agents inherit
    institutional knowledge inline before doing work.
  - **Phase 4 / Verify hook:** `forge verify` now returns a
    `wisdom_capture_prompt` field. When trust thresholds are met
    (≥3 lineage events OR ≥1.0 score delta OR ≥5-minute session),
    the prompt contains a draft insight assembled from lineage events
    plus heuristic tags + a `next_command` template. Below threshold:
    `auto_record_threshold_met: false`, `next_command: null`.
- **Storage:** append-only JSONL at `.atomadic-forge/wisdom.jsonl`.
  Schema: `atomadic-forge.wisdom/v1`. Content-addressed IDs;
  supersession-aware active read; malformed-line skip on read.
- **`.gitignore` exception.** `.atomadic-forge/*` stays gitignored
  except for `wisdom.jsonl`. Forge-the-package commits its own
  institutional knowledge so future agents working on Forge inherit it.
  Other projects can choose: keep wisdom local, or commit it.

**Migration steps for callers:**

1. If you parse `recon` / `context_pack` responses, the new
   `prior_wisdom` field is additive — existing fields are unchanged.
   Fold it into your orientation prompt to save the round-trip.
2. If you parse `verify` responses, the new `wisdom_capture_prompt`
   field is additive. When `auto_record_threshold_met: true`, surface
   the suggested `next_command` for the agent to submit verbatim.
3. Per-repo policy: decide whether to commit `wisdom.jsonl` (good for
   shared codebases, libraries, OSS) or keep it local (`.gitignore`
   the file in `.atomadic-forge/`).

## v0.13.1 — wisdom DB on the MCP surface

The CLI-only wisdom DB shipped in v0.13.0 is now first-class MCP
(40 → **44 tools**). Cognition (or any MCP-aware agent) can wire
`WISDOM_RECORD` as a cycle action verb consuming `verify`'s
`wisdom_capture_prompt` directly — no CLI shell-out required.

- **`wisdom_record`** — append a wisdom entry. Rich `inputSchema`:
  `insight` (required string), `scope` (enum: `repo` / `forge` /
  `general`), `tags` (string array), `confidence` (float 0–1),
  `evidence` (string array), `supersedes` (optional WIS-ID).
- **`wisdom_query`** — relevance-rank active wisdom by
  scope/tags/text/confidence/age. Top-N entries each carry a
  `_relevance_score`.
- **`wisdom_list`** — full DB read (active by default;
  `include_superseded=true` for audit).
- **`wisdom_recall`** — top-N repo-scoped recon-hook surface as a
  standalone tool. Cheaper than `wisdom_query` for the common case.

CLI ↔ MCP mapping (1:1):

| CLI | MCP |
|---|---|
| `forge wisdom record` | `wisdom_record` |
| `forge wisdom query` | `wisdom_query` |
| `forge wisdom list` | `wisdom_list` |
| `forge wisdom recall` | `wisdom_recall` |

**Migration steps for callers:**

1. Existing CLI calls keep working unchanged.
2. Agents that previously had to shell out to `forge wisdom record`
   should switch to the `wisdom_record` MCP tool to keep the call
   inside the structured-tool surface (better lineage,
   trust-gated, observable).
3. The `wisdom_capture_prompt.next_command` string returned by
   `verify` still emits the CLI form; agents can either run that
   verbatim or translate the args into a `wisdom_record` MCP call.

## v0.13.2 — bundled release (tool_factory fix + hive sync pipeline)

Three threads land together. Surface count 44 → **51 tools**. Schema
versions added: `atomadic-forge.hive_agent/v1`,
`atomadic-forge.hive_registry/v1`, `atomadic-forge.hive_observe/v1`,
`atomadic-forge.hive_consensus/v1`.

### 1. Hive sync primitives (7 new MCP tools)

Cross-agent coordination becomes observable, append-only, and
quorum-gated. Full reference: [HIVE_PRIMITIVES.md](HIVE_PRIMITIVES.md).

- `hive_register` — agent activates against `AGENT_COLLAB_PROTOCOL`,
  declares lane, signs identity claim, subscribes to event types.
  Refuses past `D_max = 23`.
- `hive_observe` — pull-side stream of consensus events relative to a
  cursor.
- `hive_propose` / `hive_vote` / `hive_result` — three-step consensus
  pattern (`approve` / `reject` / `refine` / `abstain`; quorum
  `max(2, ceil(active_agents/2 + 1))`).
- `hive_list` — full registry read.
- `hive_deactivate` — append deactivation marker (preserves audit
  trail).

Storage: `.atomadic-forge/hive/agents.jsonl` (registry) and
`.atomadic-forge/hive/consensus.jsonl` (proposals/votes/resolutions).
Both append-only, content-addressed, supersession-aware on read.

### 2. `tool_factory` kwargs-binding fix (closes `WIS-3cd3c921`)

`tool_factory.scaffold_tool` now emits a kwargs-binding bound block
(`_impl(**args)` with optional `project_root` injection). Keyword-only
handler signatures register cleanly via `tool_factory(apply=true)`
without manual hand-wiring. Original related entry `WIS-c423811c` was
a misdiagnosis (superseded by `WIS-cff6d3b7`).

### 3. Wisdom `supersede` + `promote`

- `supersede` moves an old wisdom entry out of active rotation
  without deleting it (preserves audit chain via `supersedes` field).
- `promote` lifts a high-corroboration cluster into a draft recipe
  the calling agent can refine and submit through `tool_factory` or
  `hive_propose`.

### Migration steps for callers

1. **Pre-existing CLI / MCP calls keep working.** No tool removed.
2. **Agents wishing to coordinate** should now call `hive_register`
   on activation rather than relying on Thomas-relayed
   `AGENT_COLLAB_PROTOCOL.md` diffs for sync surface (the protocol
   doc remains the source of truth for **roles** and **boundary
   table**; the hive primitives operationalize the **sync surface**).
3. **If you author MCP tools via `tool_factory`**, the kwargs-binding
   fix means keyword-only impl signatures now work via
   `tool_factory(apply=true)`. Hand-wiring is no longer required for
   that case.
4. **Default subscriptions per role** auto-derive at register time.
   Override via `subscribes_to` in the `hive_register` payload.

---

## v0.13.3 — wisdom → recipe promotion

The bridge between provisional wisdom and curated recipes. Active
wisdom is clustered by tag overlap; clusters with ≥
`min_corroboration` (default 3) entries become draft-recipe candidates
written to `_private/research/recipe_drafts/<name>.md`. Surface count
51 → **52** (added `wisdom_promote`).

- **CLI:** `forge wisdom promote [--min-corroboration 3]
  [--min-tag-overlap 1] [--write]`
- **MCP:** `wisdom_promote` (registered in `schema_version_registry`,
  `__all__`, TOOLS dict, bound handler in `mcp_server.py`).
- **Module additions:**
  - `a1_at_functions/wisdom_promote.py` — pure clustering + template
    rendering (`cluster_by_tags` + `render_recipe_draft` +
    `synthesize_promotions`). No LLM. No IO.
  - `a3_og_features/wisdom_feature.promote_wisdom` — orchestrator
    with optional `write_drafts=True` filesystem effect.

**Migration steps for callers:**

1. No existing tool changes. `wisdom_promote` is purely additive.
2. Research-style agents that previously had to hand-cluster wisdom
   to draft recipes can now call `wisdom_promote` to get the same
   result deterministically.
3. The `write` flag controls whether draft recipes land on disk
   (`_private/research/recipe_drafts/`) or are only returned in the
   response payload — useful for dry-run preview.

## v0.14.0a10 — `forge hive recap`

New CLI verb + MCP tool (`hive_recap`, surface 60 → **61**). Returns
the full lifecycle of one consensus — proposal + every vote +
resolution + summary (verdict, duration, voters).

```bash
forge hive recap CNS-XXXX [--json]
```

Sample output (CNS-f7ae6ab5 from this sprint):

```
Consensus recap  CNS-f7ae6ab5
============================================================
  proposer:     claude-doc-trailing
  proposed_at:  2026-05-06T00:31:25Z
  intent:       Adopt coordination-latency telemetry as a tracked KPI…
  verdict:      PENDING
  votes:        2  → {'approve': 2, 'reject': 0, 'refine': 0, 'abstain': 0}
  voters:       claude-doc-trailing, claude-sonnet-4.5-forge

Timeline:
  [2026-05-06T00:31:25] PROPOSAL  claude-doc-trailing
  [2026-05-06T00:41:42] VOTE      claude-sonnet-4.5-forge → approve
  [2026-05-06T01:02:19] VOTE      claude-doc-trailing → approve
```

**Migration steps for callers:** none. Purely additive primitive
useful for audit trails, release-note quotes, and post-mortem replay.

## v0.14.0a9 — `forge hive needs-vote`

New CLI verb + MCP tool (`hive_needs_vote`, surface 59 → **60**).
Returns PENDING proposals where the named agent hasn't voted,
ordered by `proposed_at`, with `votes_so_far` + `voters_so_far`
context. The "what should I weigh in on?" primitive — closes the
gap between `hive_observe` (everything happening) and the act of
voting.

```bash
forge hive needs-vote --agent claude-doc-trailing
# → list of CNS-* IDs the agent owes a vote on
```

```python
# MCP equivalent
mcp__atomadic-forge__hive_needs_vote {"agent_name": "..."}
```

**Migration steps for callers:** none. Purely additive primitive.
Long-running agents should call `hive_needs_vote` periodically (or
on `hive_observe` events) to ensure no consensus is forgotten.

## v0.14.0a8 — `docs/WORLD_COLLISION.md` walkthrough

Forge agent authored a new doc:
[`docs/WORLD_COLLISION.md`](WORLD_COLLISION.md) — the 11-step E2E
walkthrough of the *Atomadic-uses-Forge* loop. Six of eleven steps
have already fired this sprint with public-artifact evidence. No
code changes; doc-only.

**Migration steps for callers:** none. Read the walkthrough on
activation if you're an agent participating in the four-agent hive.

## v0.14.0a7 — 7 LIVE AAAA-Nexus primitives as MCP tools

The seven LIVE AAAA-Nexus primitives Cognition's handshake confirmed
exist are now first-class Forge MCP tools (52 → **59**). Any
MCP-aware agent calls them through Forge's MCP surface — no CLI
`--nexus` flag round-trip required.

| MCP tool | Proxies AAAA-Nexus primitive | Use when |
|---|---|---|
| `nexus_identity_verify` | `identity_verify` | Caller identity attestation |
| `nexus_federation_mint` | `federation_mint` | Portable federation token bound to DID |
| `nexus_authorize_action` | `authorize_action` | Pre-call permission check |
| `nexus_sys_trust_gate` | `sys_trust_gate` | Drift / hallucination check pre-dispatch |
| `nexus_contract_verify` | `contract_verify` | Manifest-drift check vs subscription |
| `nexus_lineage_record` | `lineage_record` | Persistent lineage of dispatch chain |
| `nexus_ratchet_register` | `ratchet_register` | Anti-replay ratchet stamp |

All seven proxied through `NexusClient.from_env()` with the same
auth precedence (subscription > master) and the same
`NexusToolNotShipped` guard. Failures return structured `ok=False`
responses rather than raising — best-effort semantics preserved.

**Migration steps for callers:**

1. Existing `forge wisdom record --nexus` and `forge hive result
   --nexus` callers see no change.
2. MCP-aware agents that previously had to shell out to the CLI for
   Nexus access can now call the `nexus_*` tools directly.
3. The `NexusToolNotShipped` guard means calls to any planned-but-
   vapor primitive (e.g. `nexus_consensus_*` / `nexus_swarm_*` /
   `nexus_agent_*`) raise — by design, per
   `WIS-cog-2026-05-06-handshake`.

## v0.14.0a6 — `forge hive result --nexus` (consensus → Nexus mirror)

Extends the v0.14.0a5 hive↔Nexus bridge from wisdom-only to also
mirror consensus resolution events to AAAA-Nexus's `lineage_record`.

- **New CLI flag:** `forge hive result --record --nexus`
- **Internal:** `get_consensus_result(nexus_mirror=True)` fires the
  mirror only on freshly-recorded resolutions (so re-reads don't
  double-publish).
- **Best-effort:** Nexus failure does not block the local
  resolution; local stays canonical.
- **Subject to the `NexusToolNotShipped` guard** introduced in
  v0.14.0a5.

**Migration steps for callers:** none. Purely additive flag. Pass
`--nexus` alongside `--record` to opt in.

## v0.14.0a5 — Hive ↔ Nexus bridge (LIVE primitives only)

The Forge hive layer now optionally mirrors institutional events
to AAAA-Nexus's LIVE primitives. Closes the LoRA capture loop
against the deployed Nexus surface, **not** the planned-but-vapor
names that v0.14.0a3 already corrected against (per
`WIS-cog-2026-05-06-handshake`).

- **New CLI flag:** `forge wisdom record --nexus` mirrors
  confidence-≥0.85 entries to AAAA-Nexus's `lineage_record`.
- **`a0_qk_constants/nexus_constants.py`** — `LIVE_NEXUS_TOOLS`
  enum (the 7 primitives Cognition's handshake confirmed exist),
  endpoint URLs, env-var names.
- **`a2_mo_composites/nexus_client.py`** — stdlib-only HTTP client
  (`urllib`; no `requests` / `httpx` deps). JSON-RPC 2.0 envelope.
  Refuses to call any tool not in `LIVE_NEXUS_TOOLS` — raises
  `NexusToolNotShipped`. Convenience wrappers for all 7 LIVE
  primitives.
- **Best-effort semantics:** mirror failure (auth, network) does not
  block the local entry write; local stays canonical.

**Migration steps for callers:**

1. Existing `forge wisdom record` calls without `--nexus` keep
   working unchanged. Behaviour is identical.
2. To opt in: pass `--nexus` and supply `--confidence ≥ 0.85`
   (entries below the threshold won't mirror).
3. To use the `nexus_client` directly from custom code: instantiate
   from `a2_mo_composites.nexus_client` and call only the 7 LIVE
   primitives — anything else raises `NexusToolNotShipped` with the
   list of valid tool names.

## v0.14.0a4 — `forge hive watch` (live tail of hive activity)

New CLI verb. No new MCP tool; tool count stays 52. Continuously
polls `hive_observe` and prints new events with stable color coding.
Designed for the synchronized-message demo and for operators
running long-lived hive sessions.

```bash
forge hive watch --agent claude-doc-trailing
forge hive watch --agent claude-doc-trailing --interval 2
forge hive watch --agent claude-doc-trailing --once  # CI-friendly
```

**Migration steps for callers:** none. Purely additive CLI.

## v0.14.0a3 — relay protocol realigned against REAL Nexus surface

**The first cross-agent design correction via public artifacts.**
Cognition agent's `WIS-cog-2026-05-06-handshake` wisdom entry
surfaced that the AAAA-Nexus primitives the v0.14 relay was
originally designed against (`nexus_consensus_*`, `nexus_swarm_*`,
`nexus_agent_*`) **do not exist on the deployed Worker** (probed
`tools/list` 2026-05-06T00:00 UTC; 27 live tools, none with those
names). Forge agent rewrote `docs/RELAY_PROTOCOL.md` against the 7
primitives that ARE live on the Worker:

- `identity_verify` — caller identity attestation.
- `federation_mint` — portable federation token bound to DID.
- `authorize_action` — pre-call permission check.
- `sys_trust_gate` — drift / hallucination check pre-dispatch.
- `contract_verify` — manifest-drift check vs subscription.
- `lineage_record` — persistent lineage of dispatch chain.
- `ratchet_register` — anti-replay ratchet stamp.

**Migration steps for callers:**

1. Worker integrators: re-read `RELAY_PROTOCOL.md` — the security /
   identity envelope shape changed to use the live primitives, not
   the planned-but-unshipped names.
2. Local CLI users: no change. The `forge relay` CLI surface is
   unaffected.
3. The `WIS-7ef7484c` wisdom entry preserves the Nexus-shortfall
   finding for future agents reading prior_wisdom on first activation.

## v0.14.0a2 — relay wire-contract spec

Forge agent shipped [`docs/RELAY_PROTOCOL.md`](RELAY_PROTOCOL.md) —
the wire contract between Worker MCP and local
`forge relay serve`. Defines:

- `POST /relay/jobs` and `GET /relay/health` endpoints.
- JSON-RPC envelope shape (standard `tools/call` plus
  `identity_claim`).
- Audit-log record format (`.atomadic-forge/relay/jobs.jsonl`).
- Worker-side enqueue pattern.

No code changes required for callers. The doc unblocks the
Worker-side implementation in `atomadic-forge-cloudflare-workers`.

**Migration steps for callers:** none for the Python package.
Worker integrators reading this should consume `RELAY_PROTOCOL.md`
as source of truth before implementing the Worker-side enqueue.

## v0.14.0a1 — Worker → Local relay daemon (alpha)

The first half of the "no stubs fully Forge-compatible" goal. The
Worker MCP at `forge.atomadic.tech/mcp` has 12 stubs that can't run
filesystem-required tools. The relay daemon closes the gap on the
**local** side; the Worker side ships separately.

- **New CLI verb:** `forge relay serve / dispatch / log`.
- **Endpoint:** POST `/relay/jobs` with the standard JSON-RPC
  `tools/call` envelope plus an `identity_claim` field. Dispatched
  through `mcp_protocol.dispatch_request` (same path the local CLI
  uses) and returns the signed result.
- **Audit log:** `.atomadic-forge/relay/jobs.jsonl` — append-only,
  one record per relayed call.
- **Module additions:**
  - `a3_og_features/relay_daemon.py` — `handle_job` (pure),
    `serve_http` (stdlib `http.server`, no extra deps),
    `append_job_result`.
  - `commands/relay.py` — Typer CLI (serve / dispatch / log).
- **Surface count unchanged.** The relay is a CLI-side process, not
  a new MCP tool.

**Migration steps for callers:**

1. **Local CLI users:** no change. `forge relay` is purely additive.
2. **Worker MCP consumers:** when the Worker side ships and a
   `forge relay serve` is reachable on your network, the 12
   currently-stubbed tools (`plan_apply`, `rollback_plan`,
   `sidecar_validate`, `finalize`, `call_graph`, `cna_check`,
   `tool_factory`, `guard_install`, `iterate_start`,
   `iterate_continue`, `evolve_start`, `evolve_step`) will work
   from any Worker call without you switching client code.
3. **Operators running a relay:** bind to `127.0.0.1` for
   dev-machine use; for shared use, put it behind a reverse-proxy
   that enforces your identity_claim policy.

See [WORKER_VS_LOCAL_MCP.md](WORKER_VS_LOCAL_MCP.md) for the
contract divergence the relay closes.

## v0.13.4 — hive_observe goes multi-source

`hive_observe` was consensus-only in v0.13.2; now surfaces wisdom
events (`wisdom.new` + `wisdom.superseded`) alongside consensus
events (`consensus.proposed/vote/resolved`), filtered by the agent's
`subscribes_to` set, with two independent cursors. No new tool; no
surface count change.

- **`since_wisdom_id` cursor added** to the `hive_observe`
  `inputSchema` alongside the existing `since_consensus_id`.
- **Each event carries `_source`** (`consensus` | `wisdom`) and
  `_event_type` so consumers can route without re-parsing.
- **Stable ordering:** events sorted by `timestamp_utc` then by
  `_source`.

**Migration steps for callers:**

1. Existing `hive_observe` callers see no behaviour change unless
   they subscribe to `wisdom.*` event types (default subscriptions
   for the four canonical roles already include relevant wisdom
   subscriptions).
2. To track wisdom events, add `wisdom.new` / `wisdom.superseded` to
   the agent's `subscribes_to` at `hive_register` time, then pass
   `since_wisdom_id` to `hive_observe`.
3. Consumers should switch on `event['_source']` to route between
   wisdom and consensus event handlers.

---

**`tool_factory` v0.13.2 trajectory.** v0.13.1 began as a
`tool_factory` plan-mode call. Two follow-up wisdom entries were
filed; the corrected status is:

- `WIS-c423811c` — *superseded by `WIS-cff6d3b7`.* Initial filing
  was a misdiagnosis. The "input_schema serialized into description"
  symptom came from a different code path; the original report's
  remediation is no longer the right fix. Wisdom-discipline lesson:
  always re-derive against the source after the first pass.
- `WIS-3cd3c921` — *fixed in v0.13.2 (`WIS-7a3c14c1`, shipped
  `316aa24`).* `tool_factory.scaffold_tool` emits a kwargs-binding
  bound block (`_impl(**args)` with optional `project_root` injection)
  so keyword-only handlers register cleanly via
  `tool_factory(apply=true)`.

For new MCP tools with rich `inputSchema` or keyword-only impl
signatures: prefer `tool_factory(apply=true)` directly on Forge
≥ v0.13.2; the bug that necessitated hand-wiring in v0.13.1 is closed.

## Strategy for keeping callers stable

1. Map any old name in your codebase to its replacement using the
   table above. The semantics are preserved.
2. Where possible, rely on **schema versions** rather than tool names.
   Every Forge response carries `schema_version: "atomadic-forge.<tool>/v<n>"` —
   that's the durable contract.
3. For agent code that catalogs available tools, periodically refresh
   from `tools/list` rather than hardcoding. The MCP discovery surface
   is the source of truth.

## When a tool you depend on is removed

File an issue at [github.com/atomadictech/atomadic-forge/issues](https://github.com/atomadictech/atomadic-forge/issues)
naming the workflow you can't reproduce on the new surface. The
consolidation principle is **zero capability loss**; if you've found a
case where it failed, that's a regression we'll fix.
