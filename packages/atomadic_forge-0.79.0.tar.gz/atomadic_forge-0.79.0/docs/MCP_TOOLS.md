# Forge MCP Tools Reference

Forge ships a Model Context Protocol server exposing **10 tools dispatching 116 registry-callable actions**. Counts are auto-synced from `forge_metrics.json` by `doc-update`.
The per-tool table below lists the primary dispatch actions; the headline total also includes compatibility routes that keep older callers working.
All legacy tool names redirect automatically — existing callers keep working.

- Local: `forge mcp serve --project /path/to/repo`
- Deployed Worker: [forge.atomadic.tech/mcp](https://forge.atomadic.tech/mcp)
- MCP Registry: [registry.modelcontextprotocol.io](https://registry.modelcontextprotocol.io/)

> **First call:** always call `welcome` at the start of a session to orient the agent and get a scored snapshot of the repo.

---

## Tool Summary

| Tool | Actions | Purpose |
|------|---------|---------|
| [`welcome`](#welcome) | — | Session onboarding: scan, score, narrative, capability tour |
| [`explore`](#explore) | 17 | Analyze and understand a codebase — recon, call graphs, smells, harvest, discovery |
| [`audit`](#audit) | 23 | Quality gates, change safety, trust verification |
| [`plan`](#plan) | 10 | Dev orientation and utilities — context packs, recipes, commit messages, steersman packs |
| [`transmute`](#transmute) | 3 | **FLAGSHIP** spaghetti-to-certified pipeline |
| [`loop`](#loop) | 4 | LLM iteration and self-improvement loops |
| [`hive`](#hive) | 13 | Multi-agent coordination — consensus, handoffs, enhancements |
| [`wisdom`](#wisdom) | 5 | Institutional memory — record and query cross-session knowledge |
| [`nexus`](#nexus) | 7 | AAAA-Nexus auth primitives (uses `op=` not `action=`) |
| [`create`](#create) | — | Intent + seed repos → shippable pip package |

---

## `welcome`

**RECOMMENDED FIRST CALL.** No `action` parameter — just call it.

Runs scout + certify + wire on the current repo and returns a single structured response:
real numbers (score, violations, symbol count), top 3 strengths, top 3 priorities, and the
single most-useful next call for the session.

```json
{ "tool": "welcome", "project_root": "/path/to/repo" }
```

---

## `explore`

**16 actions.** Use when you need to analyze, understand, or discover patterns in a codebase.
No LLM is invoked — all analysis is deterministic.

| Action | What it does |
|--------|-------------|
| `recon` | Tier map — classify every public symbol, tier/effect distributions |
| `explain` | Narrative orientation — humane operational summary of the repo |
| `call_graph` | Symbol-level dependency graph |
| `call_graph_summary` | Package-level portfolio graph (lighter than full call_graph) |
| `smell_scan` | Code smell detection (complexity, duplication, anti-patterns) |
| `churn` | Git file churn — surfaces hot files that change most often |
| `lineage` | Symbol-level provenance and surface history |
| `harvest` | Trust-gated cross-repo capability grafting |
| `synergy` | Feature-pair detection and adapter auto-generation |
| `scan` | Emergent composition scan — surfaces cross-domain patterns |
| `swarm` | Multi-repo portfolio emergent scan (N ≤ 23 repos) |
| `surface_gaps` | Capability gap finder across repos |
| `capability_scout` | Scout for specific capability presence |
| `dead_code` | Identify unreachable or unused symbols |
| `maintainability` | Maintainability index per file/module |
| `concept_bridge` | Cross-domain concept linkage detection |

> `explore` and `audit` share several actions: `dead_code`, `maintainability`, `concept_bridge`,
> and `surface_gaps` are accepted by both tools.

---

## `audit`

**23 actions.** Use when you need to check correctness, apply fixes, or gate a change.

| Action | What it does |
|--------|-------------|
| `certify` | 0-100 quality score (docs, tests, tier layout, import discipline). `emit_receipt=true` produces Forge Receipt v1. |
| `wire` | Find every upward-import violation. `suggest_repairs=true` adds fix hints. |
| `enforce` | Apply mechanical fixes for wire violations. `apply=false` is dry-run. |
| `validate` | Validate a `.forge` sidecar TOML — required fields and types. |
| `guard` | Install four enforcement layers: pre-commit hook, GHA workflow, pyproject contract, CONTRIBUTING block. |
| `composite` | Single go/no-go verdict — wire + certify always; score_patch + preflight when diff/intent supplied. Returns PASS/REFINE/FAIL. |
| `gate` | Deterministic hallucination detector for LLM responses — catches unresolved imports, stubs, false capability claims. |
| `health` | Repo health overview combining multiple signals. |
| `check` | Lightweight pre-edit guardrail — returns tier, forbidden imports, affected tests, scope warnings. |
| `score` | Patch risk scorer — rates a diff for structural risk. |
| `tests` | Test selection — returns the minimal test set impacted by a change. |
| `cna` | CNA (Compose-Not-Add) check — rejects new symbols that duplicate existing ones. |
| `rollback` | Generate a rollback plan for a proposed change. |
| `diff` | Structured diff analysis between two states. |
| `ast_scope` | Build multi-repo AST blueprints plus deterministic Nexus-attestable edit locks. |
| `surface_gaps` | Surface capability gaps in the current repo. |
| `wire_stubs` | Generate stub implementations to satisfy wire constraints. |
| `dead_code` | Identify unreachable or unused symbols. |
| `maintainability` | Maintainability index per file/module. |
| `concept_bridge` | Cross-domain concept linkage detection. |
| `auto_wire` | Deterministically wire generated surface stubs. |
| `doc_update` | Regenerate public docs from metrics. |
| `doc_drift` | Detect public-doc metric drift. |

---

## `plan`

**10 actions.** Dev utilities for orientation, workflow recipes, commit hygiene, and tiny-model routing.

| Action | What it does |
|--------|-------------|
| `context` | First-call context bundle — symbols, tier map, blockers, next action |
| `compose` | Match a goal keyword to a named workflow recipe |
| `policy` | Return the raw agent policy dict without full orientation |
| `recipes` | List the full recipe catalogue or fetch one named recipe |
| `generate` | Run scout + wire + certify and emit a ranked `agent_plan/v1` |
| `apply` | Execute a saved plan (`plan_id` required). `apply=false` dry-runs. |
| `locate` | Return insertion-point line range + preview (~1000-token saving) |
| `commit` | Assemble a structured commit message (~10k-token saving) |
| `scaffold` | Scaffold a new module or feature at the correct tier |
| `steersman` | Build AST-lock decision packs tiny enough for a 1B semantic router |

---

## `transmute`

**3 actions. FLAGSHIP pipeline.** Takes unstructured spaghetti and emits a tier-organized,
certify-100/100 package. No LLM required for the structural work.

| Action | What it does |
|--------|-------------|
| `auto` | Full pipeline: recon → cherry-pick → enforce → certify. The one-command refactor. |
| `cherry` | Cherry-pick the best candidates from a recon result for selective transmutation. |
| `finalize` | Apply the cherry-picked transmutation. `apply=false` dry-runs. |

Typical call sequence: `auto` (one-shot) or `cherry` → inspect → `finalize`.

---

## `loop`

**4 actions.** LLM-in-the-loop iteration and self-improvement.

| Action | What it does |
|--------|-------------|
| `iterate` | Start an LLM loop: intent → code → absorb → score → iterate |
| `resume` | Resume a paused iterate session by session ID |
| `evolve` | Recursive self-improvement over N rounds |
| `evolve_step` | Execute a single step of an evolve session |

---

## `hive`

**13 actions.** Multi-agent coordination — agent registry, consensus voting, handoffs, enhancement proposals.

| Action | What it does |
|--------|-------------|
| `register` | Register an agent in the hive |
| `list` | List active agents |
| `deactivate` | Deactivate an agent |
| `observe` | Record an observation from an agent |
| `propose` | Submit a consensus proposal |
| `vote` | Cast a vote on a proposal |
| `needs_vote` | Check whether a proposal needs more votes |
| `result` | Retrieve the consensus result |
| `recap` | Summarize recent hive activity |
| `handoff_create` | Create a structured session handoff artifact |
| `handoff_list` | List available handoffs |
| `enhance_propose` | Propose an enhancement to the codebase via hive consensus |
| `enhance_list` | List enhancement proposals |

---

## `wisdom`

**5 actions.** Institutional memory — record and query knowledge across sessions.

| Action | What it does |
|--------|-------------|
| `record` | Store a wisdom entry (insight, lesson, pattern) |
| `query` | Semantic search over stored wisdom |
| `list` | List all wisdom entries |
| `recall` | Retrieve a specific entry by ID |
| `promote` | Promote a wisdom entry to canonical guidance |

---

## `nexus`

**7 operations.** AAAA-Nexus auth and trust primitives.

> **Important:** `nexus` uses `op=` as its dispatch key instead of `action=`. This avoids
> collision with the `authorize_action` operation's own `action` parameter that passes
> through to the Nexus API.

| Op | What it does |
|----|-------------|
| `identity_verify` | Topological identity verification |
| `federation_mint` | Mint a cross-platform portable identity token |
| `authorize_action` | Pre-action authorization gateway with cryptographic token |
| `sys_trust_gate` | PASS/FAIL hallucination and drift screen for agent payloads |
| `contract_verify` | Verify agent policy claims against formal bounds |
| `lineage_record` | Tamper-proof decision trace capture with hash chain |
| `ratchet_register` | Register a 47-epoch RatchetGate session (MCP CVE-2025-6514 mitigation) |

---

## `create`

**No `action` parameter.** Intent + seed repos → shippable pip package.

Phase 1 pipeline: `emergent_swarm` + `materialize`. Supply a natural-language intent and
one or more seed repo paths; Forge emits a fully-structured, tier-organized package ready
for `pip install`.

```json
{ "tool": "create", "intent": "a fast CSV differ", "seed_repos": ["/path/to/repo"] }
```

---

## Dispatch Protocol

All tools except `nexus` and `welcome` use `action=<name>` for dispatch:

```json
{ "tool": "explore", "action": "recon", "project_root": "/path/to/repo" }
```

`nexus` uses `op=<name>`:

```json
{ "tool": "nexus", "op": "sys_trust_gate", "payload": "..." }
```

`welcome` and `create` take no dispatch key — pass parameters directly.

---

*Numbers sourced from `forge_metrics.json` (canonical, regenerated on every push).*
*Full CLI reference: [docs/02-commands.md](02-commands.md)*
