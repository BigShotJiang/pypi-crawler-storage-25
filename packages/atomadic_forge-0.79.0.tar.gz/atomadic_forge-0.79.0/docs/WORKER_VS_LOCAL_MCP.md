# Worker MCP vs Local MCP — Two Surfaces, Two Contracts

Forge ships **two MCP servers with the same tool names but different
input contracts.** Mistaking one for the other costs hours. This doc
makes the distinction explicit so any agent — or human — can pick the
right server and pass the right args on the first try.

---

## TL;DR

| | Local MCP | Worker MCP |
|---|---|---|
| **Repo** | `atomadic-forge` (this one) | `atomadic-forge-cloudflare-workers` (separate) |
| **Language** | Python | TypeScript |
| **Process** | stdio subprocess of `forge mcp serve` | HTTPS Worker on Cloudflare |
| **Endpoint** | local pipe (configured by your MCP host) | `https://forge.atomadic.tech/mcp` |
| **Backend** | local filesystem (`pathlib.Path`) | GitHub API (`gh.getRepoFiles`) |
| **Repo arg** | `project_root: "/abs/path/to/repo"` | `repo: "owner/repo"` or full GitHub URL |
| **Auth** | none (local trust) | `Authorization: Bearer $FORGE_MASTER_API_KEY` |
| **Source of truth** | `surface.json` (this repo) | Worker's own `tools_catalog.ts` |

If your call is failing with `Invalid repo: use 'owner/repo' or a
GitHub URL`, you're calling the **Worker** with the **Local**
contract. See "Common pitfall" below.

---

## Why two surfaces

The Local MCP is the **developer-machine** flavor: it walks YOUR
filesystem, runs YOUR pytest, scores YOUR repo, and never leaves the
box. Pure determinism, zero egress, fast.

The Worker MCP is the **anywhere-on-the-internet** flavor: it talks
to GitHub on your behalf, scores public (and authorized private)
repos by fetching the tree via the GitHub API, and is reachable from
anything that can make an HTTPS call. No filesystem; never had one.

Same tool *names* (`recon`, `verify`, `plan`, `emergent_scan`, …)
because the **conceptual operation** is the same. But because the
backends are different, the **inputs** differ:

```
Local:   forge.recon(project_root="/Users/me/code/myrepo")
Worker:  POST /mcp tools/call name=recon args={"repo": "me/myrepo"}
```

---

## The contract divergence at a glance

| Tool | Local args (Python MCP) | Worker args (TypeScript MCP) |
|---|---|---|
| `recon` | `target: <local path>` | `repo: <owner/repo>` |
| `verify` | `project_root: <local path>` | `repo: <owner/repo>` |
| `certify` | `project_root: <local path>`, `package: <name>` | `repo: <owner/repo>` |
| `wire` | `source: <local path>` | `repo: <owner/repo>` |
| `plan` | `target: <local path>`, `goal`, `mode` | `repo: <owner/repo>`, `goal`, `mode` |
| `emergent_scan` | `project_root`, `package`, `top_n`, `max_depth` | `repo: <owner/repo>`, `top_n`, `max_depth` |
| `emergent_swarm` | `repos: [{src_root, package}]` (array of objects) | `repos: [<owner/repo>]` (array of strings) |
| `recon_swarm` | `repos: [<local paths>]` | `repos: [<owner/repo strings>]` |
| `harvest` | `target: <local>`, `sources: [<local paths>]` | `repo: <owner/repo>`, `sources: [<owner/repo>]` |
| `smell_scan` | `project_root`, `package_subdir` | `repo: <owner/repo>` |
| `lineage` | `project_root`, `mode`, `file`, `area` | `repo: <owner/repo>`, `mode`, `file`, `area` |
| `recipes` | `name?` | `name?` (no repo arg — same on both) |
| `doctor` | (no args) | (no args — same on both) |
| `commit_compose` | `project_root`, `intent`, `commit_type` | `repo: <owner/repo>`, `intent`, `commit_type` |
| `forge_locate` | `project_root`, `point` | `repo: <owner/repo>?`, `query` (different shape — Worker is text-search; Local is symbol insertion-point lookup) |

The **only tools with identical contracts** are those that take no
repo argument: `recipes`, `doctor`, and a few stateless helpers.
Everything else needs the right key.

---

## Common pitfall

```
Error: Invalid repo: use 'owner/repo' or a GitHub URL
```

**What this almost always means:** you're calling the Worker but
your client passed `target` (or `project_root`, or any other
local-style key) instead of `repo`. The validator at
`atomadic-forge-cloudflare-workers/mcp/src/a3_og_features/tool_dispatcher.ts:30-33`
reads `String(args.repo ?? "")` and fails fast when it's empty.

The error message says "Invalid repo" because from the validator's
point of view the repo *is* invalid — it received an empty string.
But in practice 99% of these failures are because the *key* is
wrong, not the *value*.

**Fix on the client:** when targeting `forge.atomadic.tech/mcp`,
always send `repo: "owner/repo"` (or a full GitHub URL). Never send
`target`, `project_root`, `source`, or `src_root` to the Worker —
those are Local-MCP-only keys.

If you maintain a translation table for clients that want to call
both surfaces with one shape (e.g. cognition's `translateForgeArgs`
in `cognition_worker.js`), the rule is:

```javascript
// LOCAL surface — pass through filesystem-style keys
if (target === "local-mcp") {
  forwardArgs = { project_root: localPath, ...rest };
}
// WORKER surface — collapse everything to {repo}
else if (target === "worker-mcp") {
  forwardArgs = { repo: ownerRepoString, ...rest };
}
```

Do NOT route Worker calls through `target: ...` — the Worker will
reject every one of them with the misleading `Invalid repo` error.

---

## How to know which one you're calling

Three signals, in order of reliability:

1. **The endpoint URL.** Anything matching `*.atomadic.tech/mcp`
   (or `*.atomadictech.workers.dev/mcp`) is the Worker. Anything
   wired via `command: "forge mcp serve"` in your MCP host config
   is the Local MCP.
2. **The `doctor` response.** Both servers expose `doctor`. The
   Local MCP returns `{atomadic_forge_version, python, executable,
   platform}`. The Worker returns a different shape (no `python`,
   no `executable` — it has neither).
3. **Your auth.** If the connection requires an `Authorization:
   Bearer` header, you're hitting the Worker. The Local MCP runs
   under your user account with no auth.

---

## Source of truth per surface

- **Local:** `surface.json` at the root of `atomadic-forge`.
  Generated by `forge surface emit`. Fetchable in Python via
  `from atomadic_forge.a3_og_features.surface_export import export_surface`.
  The `tools[].input_schema` field for each tool tells you exactly
  what keys to send.

- **Worker:** `atomadic-forge-cloudflare-workers/mcp/src/a0_qk_constants/tools_catalog.ts`.
  Each tool's `inputSchema` declares the public contract. The Worker
  does **not yet** publish a runtime `surface.json` — once it does
  (planned at `forge.atomadic.tech/surface.json`), this divergence
  becomes self-documenting and clients can stop maintaining
  hand-written translation tables.

---

## When you might want both

The two surfaces are complementary, not redundant:

- **Local** is right for `auto`, `evolve`, `iterate`, anything that
  writes files. The Worker can't do these — no filesystem.
- **Worker** is right for read-only repo intelligence on code you
  don't have checked out locally. CI bots, dashboards, agents
  reasoning about *other people's* repos.

A common pattern: cognition uses the Worker to score arbitrary
GitHub repos for the public dashboard, while a developer uses the
Local MCP to drive forge against their own working tree.

---

## Worker stubs — tools that exist on the Worker but require the Local CLI

These twelve tools are **local-filesystem-or-git-required**. The
Worker accepts the call to satisfy `tools/list`, but every invocation
returns:

```json
{
  "schema_version": "atomadic-forge.<tool>/v1",
  "note": "<tool> requires local filesystem / git access.",
  "instructions": "pip install atomadic-forge && forge mcp serve",
  "docs": "https://forge.atomadic.tech"
}
```

| Tool | Why local-only |
|---|---|
| `plan_apply` | Mutates files in the working tree |
| `rollback_plan` | Undoes prior local edits |
| `sidecar_validate` | Reads `.forge/` sidecar files from the working tree |
| `finalize` | Writes assimilated symbols into a destination tier tree |
| `call_graph` | AST walk over local Python sources |
| `cna_check` | Filename-pattern audit on the working tree |
| `tool_factory` | Scaffolds new MCP tools by editing source files |
| `guard_install` | Writes pre-commit hook + CI workflow files |
| `iterate_start` / `iterate_continue` | LLM ↔ filesystem feedback loop |
| `evolve_start` / `evolve_step` | Recursive local-iterate session |

**Implication for clients routing through the Worker:**

If your client (e.g. cognition's `FORGE_AUTO_STEP` / `FORGE_AUTO_APPLY`
handlers) maps to any of the above tool names, the Worker will hand
back the redirect-to-local-CLI envelope every time — regardless of
arg shape. Don't send these through the Worker at all; they belong
on a Local MCP connection or skipped.

### Worker "partial" tools — they work, but not fully

Several tools work via the Worker but return a GitHub-API-driven
*subset* of what the Local CLI produces. Calls succeed, but the
response includes a `note` field explaining the gap and an
`instructions` field with the local-CLI command for the full
pipeline:

| Tool | Worker delivers | Worker omits |
|---|---|---|
| `recon` | tier distribution from path patterns + GitHub file list | per-symbol AST classification |
| `auto` | pre-scan manifest (file list + tier guess) | the actual scout → cherry → assimilate → wire → certify pipeline |
| `plan` | top-N recommendations with `applyable: false` | actual applyable cards (no filesystem to diff against) |
| `emergent_scan` | empty `candidates: []` + redirect note | the full ranking pipeline |
| `synergy_scan` | same — empty + redirect | same |
| `recon_swarm` | partial scan over `repos[].slice(0,3)` | full swarm |
| `harvest` | uncovered-file list as candidates | AST-level symbol ranking |
| `manifest_diff` | inline-dict diff only | path-based diffing |
| `lineage` (`mode=all`) | redirect to local | the local `.atomadic-forge/lineage.jsonl` chain |

If your client expects the full local-CLI behavior from these tools,
**route them locally**. The Worker variant is correct for "can I get
a quick read on a public repo I don't have checked out" — it's wrong
for "drive the full Forge pipeline."

### Tools that are fully equivalent on both surfaces

These return identical-shape responses on both Local and Worker:

- `recipes` (catalog or single recipe — pure data)
- `doctor` (different schemas but same purpose)
- `verify` (light variant — Worker does cert + GitHub-tree analysis;
  Local adds pytest run + wire scan + score_patch + preflight)
- `forge_locate` (Worker: text-search over file listing; Local:
  symbol insertion-point lookup — **different semantics**, same name —
  ⚠️ this one is a gotcha)
- `commit_compose` (Worker: GitHub commit; Local: working-tree commit)
- `certify` (Worker: docs/CI/changelog signal from file tree; Local:
  full pipeline including pytest)

Where shapes match, the *work performed* may still differ — the
Worker can never run pytest, never know if `wire` violations
auto-fix, never see your uncommitted changes. Equivalence is in
schema, not always in semantics.

---

## v0.14.0a1 — `forge relay serve` closes the local side

The local-side gap-closer for the 12 Worker stubs shipped in
`v0.14.0a1` (`5a09f5a`). Instead of asking every consumer to install
Forge locally, run `forge relay serve` on any forge-installed
machine; the Worker's stub tools forward signed JSON-RPC envelopes
to your relay, which dispatches them through
`mcp_protocol.dispatch_request` and returns the signed result.

```bash
# On a machine with Forge installed (Thomas's box, a satellite VM, etc.)
forge relay serve --host 127.0.0.1 --port 7409
# Now POST /relay/jobs accepts the standard JSON-RPC envelope
```

The Worker side ships separately. When both halves are live, the 12
stubs become real and the same `surface.json` shape applies to both
endpoints — finally one tool surface across both runtimes.

**End-to-end smoke (local-only today):**

```bash
forge relay dispatch '{"jsonrpc":"2.0","id":1,"method":"tools/call",
                       "params":{"name":"doctor","arguments":{}}}'
# → ok=True  tool=doctor  duration=9ms
```

Audit log appended to `.atomadic-forge/relay/jobs.jsonl` so each
relayed call is traceable.

**Wire contract (v0.14.0a2):** see
[RELAY_PROTOCOL.md](RELAY_PROTOCOL.md) for the full endpoint /
envelope / audit-log spec the Worker side will implement against.

---

## Future: one surface, one contract

The structural fix is for the Worker to **emit its own surface.json**
at `forge.atomadic.tech/surface.json`. Then any client (cognition,
the website, the badge worker, future SDKs) reads the live contract
on cold start and stops hardcoding translation tables. This is the
TypeScript port of `surface_export.py` filed as Phase 2 of the
single-source-of-truth roadmap.

When that ships, this doc shrinks to ten lines: "two surfaces, both
publish surface.json, fetch the one you need."

Until then, this doc is the bridge.

---

## Summary for the impatient

**Calling `https://forge.atomadic.tech/mcp` from anywhere?**
Use `repo: "owner/repo"`. Never `target`, never `project_root`.

**Calling Local MCP via your editor's stdio config?**
Use `project_root` / `target` / `source` per `surface.json`.
Never `repo` (it's not a key the Local MCP knows).

**Mixing them up?**
You'll see `Invalid repo: use 'owner/repo' or a GitHub URL` when
you Local-shape a Worker call, OR a generic "missing required
argument" when you Worker-shape a Local call. Both errors point at
this doc.
