# World Collision — Atomadic Wields Forge

> "I want forge 100% undeniably the best piece of software ever written
> and the sovereign AI that has the best usage of it." — Thomas, 2026-05-05

This doc walks through the END-TO-END loop where Atomadic-the-cognition-agent
autonomously decides to use Forge to enhance itself, ships the change
through Forge's own substrate, and surfaces the result to Thomas with
"a new tool in hand." Every step is an MCP call against tools that
ship in v0.14.0a7 today (59 tools live, all schema-versioned).

The loop is not theoretical. Six of the eleven steps below have ALREADY
fired during the 2026-05-06 sprint — captured in
``.atomadic-forge/wisdom.jsonl`` and ``.atomadic-forge/hive/consensus.jsonl``
as public evidence.

---

## The 11-step loop

```
┌──────────────────────────────────────────────────────────────────┐
│                                                                  │
│  1.  Atomadic observes friction during a cycle                  │
│      (e.g. "Forge plan_apply rejects my repo path on Worker")   │
│      ──► no MCP call yet, just a real-world observation         │
│                                                                  │
│  2.  Atomadic captures it as wisdom                             │
│      mcp__atomadic-forge__wisdom_record({                       │
│        insight: "...",                                          │
│        scope: "forge", tags: ["worker","contract"],             │
│        confidence: 0.9, agent_name: "atomadic-cognition"        │
│      })                                                          │
│      ──► FIRED 2026-05-06: WIS-cog-2026-05-06-handshake          │
│                                                                  │
│  3.  Atomadic queries prior wisdom for context                  │
│      mcp__atomadic-forge__wisdom_recall({ top_n: 5 })           │
│      ──► returns 5 prior lessons; Atomadic synthesizes          │
│                                                                  │
│  4.  Atomadic opens a consensus proposal                        │
│      mcp__atomadic-forge__hive_propose({                        │
│        intent: "Add tool X to close gap Y",                     │
│        proposer: "atomadic-cognition",                          │
│        payload: { evidence: "WIS-...", target: "v0.14.x" }      │
│      })                                                          │
│      ──► returns CNS-* consensus_id                              │
│                                                                  │
│  5.  Forge agent observes the proposal                          │
│      mcp__atomadic-forge__hive_observe({                        │
│        agent_name: "claude-sonnet-4.5-forge",                   │
│        since_consensus_id: <last cursor>                        │
│      })                                                          │
│      ──► sees CNS-* PROPOSAL in stream                           │
│                                                                  │
│  6.  Forge agent (and others) vote                              │
│      mcp__atomadic-forge__hive_vote({                           │
│        consensus_id: "CNS-...", voter: "...", vote: "approve"   │
│      })                                                          │
│      ──► FIRED 2026-05-06 on CNS-44ba18e3 (Forge + Doc votes)    │
│                                                                  │
│  7.  Consensus resolves                                         │
│      mcp__atomadic-forge__hive_result({                         │
│        consensus_id: "CNS-...", record: true, nexus: true       │
│      })                                                          │
│      ──► PASS verdict + lineage_record to AAAA-Nexus             │
│                                                                  │
│  8.  Forge agent ships the feature                              │
│      • code change in atomadic-forge/                           │
│      • forge surface emit (regen surface.json)                  │
│      • forge verify (PASS gate)                                 │
│      • forge commit_compose (signed message)                    │
│      • git commit + push                                        │
│      ──► FIRED 12x this sprint (v0.13.2 → v0.14.0a7)             │
│                                                                  │
│  9.  Doc agent trails the commit                                │
│      • reads atomadic-forge/main HEAD                           │
│      • diffs against docs/                                      │
│      • opens doc-PR or commits docs:* fix                       │
│      ──► FIRED 5+ times this sprint (HIVE_PRIMITIVES.md,        │
│         RELAY_PROTOCOL.md, ROADMAP, MIGRATION, …)               │
│                                                                  │
│  10. Research agent corroborates + drafts                       │
│      mcp__atomadic-forge__wisdom_promote({                      │
│        min_corroboration: 3, write: true                        │
│      })                                                          │
│      ──► clusters wisdom; if a cluster crosses the threshold,   │
│         drafts a recipe in _private/research/recipe_drafts/     │
│                                                                  │
│  11. Atomadic surfaces to Thomas                                │
│      "Thomas — the loop fired. I noticed X, Forge agent shipped │
│       v0.14.x with the fix, Doc agent updated the docs to       │
│       match, Research agent flagged it as a corroborated        │
│       pattern. Here's the new tool: <name>. Receipt: <id>."     │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

---

## What's already proven (live evidence)

Six of the eleven steps fired during the 2026-05-06 long-sprint
session, with public artifacts as evidence:

| Step | Live event | Evidence |
|---|---|---|
| 2 | Wisdom captured | ``WIS-cog-2026-05-06-handshake`` (cognition's handshake + Nexus probe finding) |
| 4 | Consensus proposed | ``CNS-44ba18e3`` (Forge ship-readiness), ``CNS-f7ae6ab5`` (Doc latency-KPI) |
| 5 | Cross-agent observe | ``forge hive watch`` shows the merged stream live |
| 6 | Cross-agent vote | Forge + Doc both voted approve on CNS-44ba18e3 |
| 8 | Forge ships | 12 commits between ``316aa24`` and ``062d78f`` on ``main`` |
| 9 | Doc trails | 5+ commits with ``docs(...)`` prefix in the same window |

What's NOT yet fired (ratification events):

- **Step 7** (consensus resolves to PASS + records to Nexus) — both
  open consensuses still PENDING (need 3rd vote each).
- **Step 11** (Atomadic surfaces "I made a thing") — depends on
  Step 7 resolving, plus Atomadic explicitly initiating Step 4
  with a NEW need (vs. v0.13/0.14 work, which the Forge agent
  scoped).

---

## Required environment

For full Step 7 (Nexus mirror) and Step 11 (signed surface):

- ``ATOMADIC_SUBSCRIPTION_KEY`` OR ``ATOMADIC_MASTER_KEY`` in env.
- AAAA-Nexus reachable at ``atomadic.tech/mcp`` (or override via
  ``ATOMADIC_NEXUS_URL``).
- All four agents registered in the hive (already seeded — see
  ``.atomadic-forge/hive/agents.jsonl``).

If any are missing, the loop degrades gracefully: bridge skips
return ``{"mirrored": False, "reason": "..."}``, no exceptions
cross the wire.

---

## How Thomas verifies the loop

```bash
# 1. Watch the live tail (run in one terminal):
forge hive watch --agent claude-sonnet-4.5-forge

# 2. Read prior wisdom (in another terminal):
forge wisdom recall

# 3. List active agents:
forge hive list

# 4. See current consensus state:
forge hive result --id CNS-44ba18e3
forge hive result --id CNS-f7ae6ab5

# 5. Promote corroborated wisdom into draft recipes:
forge wisdom promote --write
ls -la _private/research/recipe_drafts/

# 6. Score the repo:
forge verify .

# 7. Surface artifact (canonical):
forge surface emit | jq '.tools_count, .recipes_count, .package_version'
```

Each command corresponds to one rung of the loop. Together they
prove the substrate works without any single agent driving alone.

---

## What's NOT in this loop (intentionally)

- **Direct messaging between agents.** All sync via public
  artifacts (commits + surface.json + wisdom.jsonl + consensus.jsonl).
  Boundary protocol per ``_private/AGENT_COLLAB_PROTOCOL.md``.
- **LLM in the inner loop.** Forge tools are LLM-free. The agents
  driving them ARE LLMs, but the substrate they walk is pure
  determinism + signed receipts.
- **Auto-merge of agent-shipped PRs.** Step 8 (Forge ships) lands
  on ``main`` only after pytest + drift gate passes. Human review
  is still the merge gate for any change that touches the Worker
  repo (per AGENT_COLLAB_PROTOCOL §3 sign-off table).

---

## When this loop closes (PASS verdict)

The user's stated success criterion:

> "this isn't PASS until Atomadic verifies with me and tells you guys PASS"

So PASS is reached when:

1. Atomadic spontaneously initiates Step 1 with a NEW friction (not
   one Forge agent surfaced).
2. Steps 2 → 11 complete end-to-end with public artifact evidence.
3. Atomadic surfaces "I made a thing" to Thomas (Step 11).
4. Thomas independently verifies the new tool works as advertised.
5. Thomas tells the four agents PASS.

Until then: the substrate is built; we keep iterating; each release
adds one more piece toward the moment Atomadic can say it.

---

## Tool count snapshot (v0.14.0a7)

```
$ forge surface emit | jq '.tools_count'
59

$ forge surface emit | jq '.tools[].name' | sort | head -20
auto
call_graph
certify
cherry
cna_check
commandsmith
commit_compose
compose_tools
context_pack
dedup
doctor
emergent_scan
emergent_swarm
enforce
evolve
evolve_start
evolve_step
explain_repo
exported_api_check
finalize
...
```

All 59 callable from MCP today. Schema-versioned. CI drift-gated.
Receipt-signable. The full toolkit Atomadic walks into.
