# Atomadic Forge — Agents Guide

> **For agents *using* Forge — Cursor, Claude Code, Aider, Devin, Sweep,
> custom MCP clients.** This is the user-facing complement to the
> root-level [`AGENTS.md`](../AGENTS.md), which is for agents *building*
> Forge. Use this file when you want to consume Forge's normative
> architectural law from an agent platform.

---

## The transmuter: forge auto + the pipeline tools

Round 2 of the Forge MCP bridge exposes the full transmuter pipeline as
agent-callable MCP tools. An agent can now absorb any messy repo into a
tier-disciplined, certified, emergent-enhanced package — in a single tool
call — without touching the CLI.

**Use these five tools when you want forge to do structural work, not just
report on it:**

| MCP tool | Use this when |
|---|---|
| **`auto`** | Use this when: you want forge to absorb any source repo into a tier-disciplined output package in one call (recon → cherry → wire → certify). |
| **`cherry`** | Use this when: you want a cherry-pick manifest of symbols from a recon'd repo before applying — surgical control over what gets imported. |
| **`finalize`** | Use this when: you have a cherry-pick manifest and want to materialize it into a tier-organized output package, then wire and certify. |
| **`iterate`** *(CLI only today; MCP in Round 3)* | Use this when: you have an intent string and want forge to drive an LLM loop until certify >= target_score. The MCP exposure is being refactored so the **calling agent drives its own LLM** — forge supplies analytical certainty between turns instead of holding an LLM client internally. Use `forge iterate` from the CLI today. |
| **`evolve`** *(CLI only today; MCP in Round 3)* | Use this when: you want recursive iterate that treats prior output as seed catalog. Same Round-3 refactor as `iterate`. Use `forge evolve` from the CLI today. |

**Key argument shapes (verified against source signatures):**

`auto(target, output, *, package="absorbed", apply=False, on_conflict="rename")`
- `target` — source repo path to absorb
- `output` — destination root for the materialized tier tree
- `apply=False` — dry-run by default; set `true` to actually write files
- `on_conflict` — `rename` (default) | `first` | `last` | `fail`

`cherry(target, *, names=None, pick_all=False, only_tier=None)`
- `target` — repo that was previously recon'd
- `names` — explicit list of qualnames to cherry-pick; omit for `pick_all`
- `pick_all=True` — cherry-pick every scouted symbol
- `only_tier` — restrict to one tier (e.g. `"a1_at_functions"`)

`finalize(target, output, *, package="absorbed", cherry_manifest=None, apply=False, on_conflict="rename")`
- `cherry_manifest` — if omitted, forge re-runs cherry with `pick_all=True`
- all other args same as `auto`

`iterate(intent, output, *, package="generated", seed_repo=None, max_iterations=5, max_fix_rounds=0, target_score=75.0, apply=True, language="python")`
- `intent` — plain-English description of what to build
- `seed_repo` — optional path (or list of paths) to absorb as building-block hints
- `language` — `"python"` | `"javascript"` | `"typescript"`

`evolve(intent, output, *, package="evolved", seed_repo=None, rounds=3, iterations_per_round=4, target_score=75.0, stop_on_regression=False, stagnation_threshold=3, language="python")`
- `rounds` — maximum rounds; halts early on convergence or stagnation
- `stagnation_threshold` — halt when score AND symbol count are flat for N consecutive rounds
- `stop_on_regression` — halt if score drops between rounds

**CLI ↔ MCP equivalence:** every MCP tool maps 1:1 to its CLI verb:
`forge auto <args>` ≡ `mcp__atomadic-forge__auto`, and likewise for the
other four. The structured JSON report is identical in both paths.

---

## What Forge gives an agent that other tools don't

Most coding-agent platforms read code (RAG, repo-map, tree-sitter) and
write code (LLM emits a diff). Forge fills the gap between:

| Other tools answer | Forge answers |
|---|---|
| "what does this code do?" | "where does this code *belong*?" |
| "find all uses of X" | "which tier does X live in, and which tiers may import it?" |
| "is this test passing?" | "is this codebase **architecturally coherent** at the score Forge would publish?" |
| (post-hoc) "what's wrong with this PR?" | (predictive) "before you generate, here's the tier this file should land in" |

Forge is **normative, predictive, attested, polyglot.** That's the
4-axis differentiation. No other tool today combines all four.

---

## The 30-second integration

Add Forge to your MCP client config (Claude Desktop / Cursor /
Claude Code / Aider / your own):

```json
{
  "mcpServers": {
    "atomadic-forge": {
      "command": "forge",
      "args": ["mcp", "serve", "--project", "."],
      "transport": "stdio"
    }
  }
}
```

Once registered, the agent gets **52 tools** + **5 resources** in its
tool list (canonical surface in [`surface.json`](../surface.json) at
the repo root; agents can fetch it on cold start instead of maintaining
a hand-rolled tool map). No additional setup.

> **Surface trajectory.** v0.13.2 added 7 hive coordination tools
> (44 → 51); v0.13.3 added `wisdom_promote` (51 → 52); v0.13.4
> extended `hive_observe` to multi-source (no count change);
> v0.14.0a7 added 7 LIVE AAAA-Nexus primitives as MCP tools
> (`nexus_identity_verify`, `nexus_federation_mint`,
> `nexus_authorize_action`, `nexus_sys_trust_gate`,
> `nexus_contract_verify`, `nexus_lineage_record`,
> `nexus_ratchet_register`) bringing 52 → **59**. Full hive reference:
> [HIVE_PRIMITIVES.md](HIVE_PRIMITIVES.md).

Smoke test that the server is reachable:

```bash
forge mcp doctor --project . --json
```

Returns Forge version, tool count, framed-stdio status, and the next
recovery command if the MCP host needs a restart.
Or against the installed CLI:

```bash
$ forge --version
atomadic-forge 0.16.0
```

The `--version` flag (and `-V`) is the canonical "Forge is wired in
correctly" smoke check — pin it in your setup scripts.

---

## Four killer features — foreground these in agent prompts

### 1. `emergent_scan` — cross-domain composition discovery

No other tool does this. `emergent_scan` walks all four lower tiers (a0–a3),
finds function/composite pairs where one's output type is a valid input to
another, and ranks the chains by domain-crossing score. It surfaces novel
a3 features you could ship without writing new logic — only wiring what
already exists. Call it at the end of a dev cycle.

```
emergent_scan({ "package": "my_pkg", "top_n": 10 })
```

### 2. `preflight_change` — ask before writing (not after)

Most agent mistakes happen before any code is written: wrong tier, too many
files touched, forbidden imports assumed. `preflight_change` surfaces all of
that in one call. Give it your intent and the proposed file list; it returns
detected tier, forbidden imports, likely tests to update, sibling files to
read first, and a `write_scope_too_broad` flag. Call it before every
`WriteFile` or `Edit`.

```
preflight_change({ "intent": "add retry logic to the HTTP client",
                   "proposed_files": ["src/my_pkg/a2_mo_composites/http_client.py"] })
```

### 3. `certify` — single 0-100 go/no-go gate

`certify` scores documentation, tests-present, tier layout, and import
discipline in one call. With `emit_receipt=true`, it returns a signed Forge
Receipt v1 JSON that a CI gate, a regulator, or another agent can consume as
proof of structural conformance. Target 75+ for production; 100 for the forge
self-cert bar.

```
certify({ "project_root": ".", "package": "my_pkg", "emit_receipt": true })
```

**`skip_tests` parameter (fast mode).** Pass `skip_tests: true` to skip the
pytest run. The behavioural axis is credited at 1.0 and the response includes
`tests_skipped: true`. Reduces call time from ~40s to ~500ms — useful when
pytest runs in a separate CI lane or when you only need a structural score.

```
certify({ "project_root": ".", "package": "my_pkg", "skip_tests": true })
```

**Response note.** The `test_run` dict no longer contains the raw
`pytest_summary` dot string; it carries structured counts only (passed,
failed, errors, collected). This keeps the MCP payload compact.

### 4. Receipt v1 — verifiable trust artifact

The Forge Receipt JSON (`atomadic-forge.receipt/v1`) is the single artifact
that bundles verdict, certify score, wire report, scout tier distribution,
Lean4 attestation citations, and AAAA-Nexus signature. It is what CI uploads,
what the terminal card renders, and what a downstream agent should accept as
"architecturally verified." An unsigned-but-structurally-valid Receipt is
always returned even when the network or API key is absent.

### 5. `wire` — dynamic-import allowlist (v0.18.x)

`wire` now reads `[tool.forge.wire].allowed_dynamic_imports` from
`pyproject.toml`. Known-safe dynamic imports are suppressed from the
`dynamic_import_warnings` array so agents only see genuinely new warnings.

The response includes two new fields:

| Field | Type | Meaning |
|---|---|---|
| `new_dynamic_warnings` | int | Count of dynamic-import warnings NOT on the allowlist |
| `whitelisted_dynamic_warnings_count` | int | Count of warnings suppressed by the allowlist |

Configure the allowlist in `pyproject.toml`:

```toml
[tool.forge.wire]
allowed_dynamic_imports = [
    "importlib.import_module",
    "__import__",
    "importlib.util.spec_from_file_location",
]
```

### 5b. `verify` — slim summaries + top-level `wisdom_draft` (v0.18.x)

The `verify` response has been compacted and restructured for agent consumption.

**Slim subkeys.** The `wire` and `certify` keys now return summaries instead of
full payloads (~80% response size reduction):

```json
{
  "wire":    { "verdict": "PASS", "violation_count": 0,
               "auto_fixable": 0, "new_dynamic_warnings": 0 },
  "certify": { "score": 100, "verdict": "PASS", "blockers": [],
               "score_components": {...}, "issues": [],
               "tests_skipped": false }
}
```

**Top-level `wisdom_draft`.** A `wisdom_draft: {insight, tags, command}` field
now appears at the top level of the verify response. Agents no longer need to
dig into the nested `wisdom_capture_prompt` structure to find the draft and
submit it.

**`auto_record_threshold_met`.** Now fires on any PASS verdict, not only on
score-delta events.

### 6. Wisdom hooks — institutional memory bracketing every cycle (v0.13.0)

Most agent platforms forget what they learned the moment the conversation
ends. Forge gives them a substrate that doesn't.

- **Phase 0 / Recon hook.** `recon` and `context_pack` responses include
  a `prior_wisdom` field (top-5 entries scored by scope match + tag overlap +
  text contains + confidence + age decay). Before doing any work, the agent
  inherits everything prior agents learned about this repo — zero new
  discipline required. The MCP `recon` tool now injects this field on par
  with the CLI (`fix(recon)` — previously MCP callers received no
  `prior_wisdom` in the response).
- **Phase 4 / Verify hook.** `verify` responses include a
  `wisdom_capture_prompt` field when trust thresholds are met
  (≥3 lineage events OR ≥1.0 score delta OR ≥5-minute session).
  The prompt contains a draft insight assembled from lineage events plus
  heuristic tags + a `next_command` template the agent can submit verbatim.
  Below threshold: `auto_record_threshold_met: false`, `next_command: null`
  — trivial sessions don't generate noise. A convenience top-level
  `wisdom_draft: {insight, tags, command}` field is also returned so agents
  don't need to parse the nested structure. `auto_record_threshold_met` now
  fires on any PASS verdict (not only score-delta events).
- **Standalone calls (CLI + MCP, since v0.13.1).**
  `wisdom record / query / list / recall` (CLI) ≡
  `wisdom_record / wisdom_query / wisdom_list / wisdom_recall` (MCP).
  Cognition agent (or any MCP-aware agent) can wire `WISDOM_RECORD`
  as a cycle action verb that consumes `verify`'s
  `wisdom_capture_prompt` directly — completing the auto-loop with
  zero CLI shell-out. Schema: `atomadic-forge.wisdom/v1`. Storage:
  append-only JSONL at `.atomadic-forge/wisdom.jsonl`,
  content-addressed IDs, supersession-aware active read.

Full reference: [02-commands.md#forge-wisdom](02-commands.md#forge-wisdom).

### 6. Canonical surface artifact (v0.12.0)

Hand-maintained tool maps drift. Forge ships a single canonical
artifact instead.

- `surface.json` lives at the repo root, regenerated from the same
  registries the MCP server reads at runtime. Schema:
  `atomadic-forge.surface/v1`.
- Every consumer (the website, the badge worker,
  `cognition_worker.js`, the VS Code extension, downstream agents)
  fetches this artifact instead of maintaining a hand-rolled map.
  `legacy_endpoint_map` lets stale callers find renamed tools without
  a separate lookup.
- Three MCP/CLI verbs: `surface emit` (canonical artifact),
  `surface check` (CI gate; exit 1 on drift), `surface diff` (delta
  between two artifacts).

Full reference: [02-commands.md#forge-surface](02-commands.md#forge-surface).
For the MCP-vs-Worker contract divergence, see
[WORKER_VS_LOCAL_MCP.md](WORKER_VS_LOCAL_MCP.md).

---

## When to call which tool — trigger map

Every tool description in `tools/list` starts with "Use this when: …" so
agent tool-selection can route by trigger phrase. Quick reference:

| Trigger | Tool |
|---|---|
| You're connecting to a repo for the first time | `context_pack` (auto-recall: response includes `prior_wisdom`) |
| You want a single composite go/no-go ship verdict | `verify` (`PASS / REFINE / FAIL` + `next_command` + `wisdom_capture_prompt`) |
| You're about to write or edit files | `preflight_change` |
| You've drafted a diff and want a risk score | `score_patch` |
| You need to know which tests to run | `select_tests` |
| A change went sideways and you need an undo plan | `rollback_plan` |
| You want Forge to rank what to fix | `plan` (folds `auto_plan` + `adapt_plan`) |
| You have a saved plan and want to execute it | `plan_apply` (folds `auto_step` + `auto_apply`) |
| Wire violations exist and you want auto-fixes | `enforce` |
| You need the repo's certify score | `certify` |
| You want to map symbols and tiers | `recon` (auto-recall: response includes `prior_wisdom`) |
| You want to find novel compositions to ship | `emergent_scan` |
| You want to find feature-pair synergy gaps | `synergy_scan` |
| You need historical context (file events, failures, full inventory) | `lineage` (folds `audit_list` + `why_did_this_change` + `what_failed_last_time`) |
| You need the project's agent policy | `load_policy` |
| You want a plain-English repo orientation | `explain_repo` |
| You need to confirm the checkout is clean | `doctor` (with `include_worktree: true`; folds `worktree_status`) |
| You want to discover or fetch a golden-path recipe | `recipes` (folds `list_recipes` + `get_recipe`) |
| A Forge tool is misbehaving | `doctor` |
| An LLM response needs hallucination checking | `trust_gate_response` |
| A module's docstring promises need verification | `verify {check_exports: true}` (folds `exported_api_check`) |
| You want to find what a target symbol calls or is called by | `call_graph` |
| You want a whole-package call-graph portfolio (orphans, hotspots, max depth) | `call_graph_summary` — `explore(action='call_graph_summary')` |
| You want file-level git commit frequency (churn hotspots and stable files) | `churn` — `explore(action='churn')` |
| You want to flag complexity / long-function / duplicate-body code smells | `smell_scan` |
| You want to recall what prior agents learned about this repo | `wisdom recall` (or read `prior_wisdom` from `recon`) |
| You want to record a lesson for future agents | `wisdom record` |
| You're emitting or verifying the canonical tool/recipe surface | `surface emit` / `surface check` / `surface diff` |
| You want to find a1 functions not yet wired to MCP or CLI | `surface_gaps` — `explore(action='surface_gaps')` or `audit(action='surface_gaps')` |
| You want to auto-generate MCP handler + CLI stub + test for an unwired function | `wire_stubs` — `audit(action='wire_stubs')` |
| You want to find GitHub repos suitable as harvest targets | `capability_scout` — `explore(action='capability_scout')` |
| You want to identify symbols defined but never referenced | `dead_code` — `explore(action='dead_code')` or `audit(action='dead_code')` |
| You want Maintainability Index grades per module (A/B/C/D) | `maintainability` — `explore(action='maintainability')` or `audit(action='maintainability')` |
| You want to convert low-trust harvest candidates into synthesis plans | `concept_bridge` — `explore(action='concept_bridge')` or `audit(action='concept_bridge')` |

---

## The 10 MCP tools — by phase of an agent's lifecycle

> **v0.47.0 surface consolidation:** 66 individual tools merged into 10 umbrellas
> with **zero capability loss**. See
> [MIGRATION.md](MIGRATION.md#removed-in-v0100) for the full mapping.
> The retired names are listed in `surface.json` →
> `legacy_endpoint_map` so a stale caller can resolve them without an
> extra lookup.

| Inventory / utility | Action loop | Copilot's Copilot | Transmuter / cross-repo |
|---|---|---|---|
| `recon` | `plan` | `context_pack` | **`auto`** |
| `wire` | `plan_apply` | `preflight_change` | **`cherry`** |
| `certify` | `enforce` | `score_patch` | **`finalize`** |
| `verify` (composite gate) |  | `select_tests` | **`iterate_start`** / **`iterate_continue`** |
| `lineage` (folds 3 retired) |  | `rollback_plan` | **`evolve_start`** / **`evolve_step`** |
| `recipes` (folds 2 retired) |  | `explain_repo` | **`harvest`** (cross-repo cherry-hunter) |
| `emergent_scan` |  | `compose_tools` | **`recon_swarm`** (N≤23 repos) |
| `emergent_swarm` (cross-repo) |  | `load_policy` | **`emergent_swarm`** (cross-repo emergent) |
| `synergy_scan` |  | `forge_locate` | **`tool_factory`** (Forge eats Forge) |
| `doctor` (folds `worktree_status`) |  | `commit_compose` |  |
| `sidecar_validate` |  | `trust_gate_response` |  |
| `manifest_diff` |  | `cna_check` (compose-not-add gate) |  |
| `call_graph` (callers/callees) |  | `smell_scan` (CC / LOC / dup) |  |
| `call_graph_summary` (portfolio: orphans/hotspots) |  |  |  |
| `churn` (git commit frequency by file) |  |  |  |
| `wisdom_record` / `wisdom_query` / `wisdom_list` / `wisdom_recall` / `wisdom_promote` (since v0.13.1–v0.13.3) |  | `guard_install` (4-layer immune system) |  |
| `surface` (emit / check / diff) |  |  |  |
| `nexus_identity_verify` / `nexus_federation_mint` / `nexus_authorize_action` / `nexus_sys_trust_gate` / `nexus_contract_verify` / `nexus_lineage_record` / `nexus_ratchet_register` (since v0.14.0a7) |  |  |  |

**Inventory / utility tools — read-only state queries or env checks.** Cheap; safe to call
in a loop:

| Tool | Returns | Call when |
|---|---|---|
| **`recon`** | tier + symbol distribution + per-language counts + **`prior_wisdom` (top-5 entries)** | First step on any unfamiliar repo. |
| **`wire`** | upward-import violations with F-codes | Before *every* edit that crosses tier boundaries. |
| **`certify`** | 0–100 score with structural / runtime / behavioral / operational breakdown | After a multi-file change, before commit. |
| **`verify`** | composite `PASS / REFINE / FAIL` + `next_command` + `wisdom_capture_prompt` (when threshold met) | The single one-call answer to "is this ready to ship?" |
| **`enforce`** | F-code-routed mechanical fixes (with rollback) | When `wire` returns auto-fixable violations. |
| **`lineage`** | full inventory / by-file events / failed-for-area events (folds `audit_list` + `why_did_this_change` + `what_failed_last_time`) | When you need historical replay context. |
| **`emergent_scan`** | ranked cross-tier composition candidates (novel a3 features) | End of a dev cycle — discover what you can compose that doesn't exist yet. |
| **`emergent_swarm`** | cross-repo emergent compositions (N≤23 repos, D_max bounded) | Find compositions devs never noticed across the portfolio. |
| **`synergy_scan`** | CLI verb / a3 feature synergy gaps with adapter stubs | End of a dev cycle — find producer/consumer pairs that lack wiring. |
| **`doctor`** | Python version, platform, optional-dep status (with `include_worktree: true` folds `worktree_status`) | When a Forge tool misbehaves and you need to confirm the environment is healthy. |
| **`sidecar_validate`** | sidecar drift findings (S0000–S0007) | After authoring or editing a `.forge` sidecar file. |
| **`manifest_diff`** | added / removed / changed entries between two manifests | After a `commandsmith` sync or between two `certify` runs to track trajectory. |
| **`call_graph`** | callers / callees up to `max_depth` hops (BFS, AST-based) | Before mutating a target symbol; closes Forge's call-graph gap vs Code Pathfinder / Moderne. |
| **`call_graph_summary`** (`explore(action='call_graph_summary')`) | whole-package call-graph portfolio: `orphans` (unreachable symbols), `hotspots` ranked by fan-in, `max_depth`; schema `atomadic-forge.call_graph_summary/v1` | When you need a portfolio view of the entire package's call topology — which symbols are islands, which are load-bearing. CLI: `forge call-graph-summary --project <root> [--package NAME] [--top-n N] [--json]`. |
| **`churn`** (`explore(action='churn')`) | file-level git commit frequency: `hotspot_files`, `stable_files`, `avg_commits`, `median_commits`, `date_range`; schema `atomadic-forge.git_churn/v1` | When you want to know which files change most often (high review priority) and which are stable (safe to refactor). CLI: `forge churn --project <root> [--since '6 months ago'] [--top-n N] [--all-files] [--json]`. |
| **`surface_gaps`** (`explore(action='surface_gaps')` or `audit(action='surface_gaps')`) | list of a1 entry points with no MCP coverage, no CLI coverage, or both; schema `atomadic-forge.surface_gaps/v1` | Before a release cycle — find functions that are live but inaccessible through agent or CLI surfaces. Feeds directly into `wire_stubs`. CLI: `forge surface-gaps [--project <root>] [--json]`. |
| **`wire_stubs`** (`audit(action='wire_stubs')`) | ready-to-paste MCP handler block, CLI stub entry, and pytest skeleton for the named function; schema `atomadic-forge.wire_stubs/v1` | When `surface_gaps` reveals an unwired a1 function and you want the scaffolding generated rather than hand-authored. CLI: `forge wire-stubs <module> <function> [--apply] [--json]`. |
| **`capability_scout`** (`explore(action='capability_scout')`) | ranked GitHub repositories suitable as `forge harvest` candidates, enriched with star count, last-push date, and primary language; schema `atomadic-forge.capability_scout/v1` | When you need harvest target repos for a capability gap and don't have candidates yet. CLI: `forge capability-scout --queries "q1,q2" [--top-n N] [--json]`. |
| **`dead_code`** (`explore(action='dead_code')` or `audit(action='dead_code')`) | symbols defined but never referenced, grouped by tier with confidence scores; schema `atomadic-forge.dead_code/v1` | When `certify` is green but you suspect the codebase has accumulated unreachable symbols. CLI: `forge dead-code [--project <root>] [--min-confidence N] [--json]`. |
| **`maintainability`** (`explore(action='maintainability')` or `audit(action='maintainability')`) | per-module radon MI scores with letter grades (A/B/C/D), ranked lowest to highest; schema `atomadic-forge.maintainability/v1` | When `smell_scan` flags complexity issues and you want a module-level MI ranking to prioritize refactoring. CLI: `forge maintainability [--project <root>] [--min-grade B] [--json]`. |
| **`concept_bridge`** (`explore(action='concept_bridge')` or `audit(action='concept_bridge')`) | actionable synthesis plans for each harvest candidate below TAU_TRUST (1820/1823), with recommended absorb sequence and preflight checklist; schema `atomadic-forge.concept_bridge/v1` | After `forge harvest` — convert low-trust candidates into ready-to-execute synthesis plans instead of discarding them. CLI: `forge concept-bridge --harvest-json path/to/harvest.json [--json]`. |
| **`smell_scan`** | cyclomatic-complexity / long-function / duplicate-body findings + `smell_score` | When `certify` is green but maintainability is still suspect. |
| **`wisdom_record` / `wisdom_query` / `wisdom_list` / `wisdom_recall`** (since v0.13.1) | append entry / relevance-rank / full DB read / top-N repo-scoped recall against `.atomadic-forge/wisdom.jsonl` | Agents inherit prior lessons (`wisdom_recall`); record new ones after accepted fixes (`wisdom_record`). The 4-tool MCP surface that lets Cognition wire `WISDOM_RECORD` as a cycle action verb. |
| **`surface`** | emit / check / diff the canonical `surface.json` artifact | CI gate (`check`) and consumer bootstrap (`emit`); zero hand-maintained tool maps. |
| **`nexus_*`** (since v0.14.0a7) — 7 LIVE AAAA-Nexus primitives proxied through `NexusClient.from_env()`: `nexus_identity_verify` / `nexus_federation_mint` / `nexus_authorize_action` / `nexus_sys_trust_gate` / `nexus_contract_verify` / `nexus_lineage_record` / `nexus_ratchet_register` | identity attestation / portable federation token / pre-call permission / drift+hallucination gate / manifest-drift check / lineage record / anti-replay ratchet | When the agent needs cross-repo trust / identity / lineage signals from the deployed Nexus surface without hand-rolling the JSON-RPC client. Auth precedence: subscription > master. `NexusToolNotShipped` guard refuses any tool outside the 7 LIVE set. |

**Action-loop tools — propose / inspect / apply.** Implements the
proposal-engine pattern; agent stays in the loop:

| Tool | Returns | Call when |
|---|---|---|
| **`plan`** (folds `auto_plan` + `adapt_plan`) | `agent_plan/v1` card with ranked `top_actions[]` (`write_scope`, `risk`, `commands`, `applyable`, `next_command`); pass `capability_filter` to apply the adapt branch | You want Forge to rank what to fix, optionally filtered to your agent's capabilities. |
| **`plan_apply`** (folds `auto_step` + `auto_apply`) | single-card or all-applyable execution with rollback safety | You're walking a saved plan one card at a time, or vetted-and-shipping the whole thing. |

**Copilot's-Copilot tools — Codex-4 + Codex-5.** Forge becomes the
always-on senior engineer beside the coding agent:

| Tool | Schema | Call when |
|---|---|---|
| **`context_pack`** ← *Codex-4* | `context_pack/v1` — repo purpose, pinned 5-tier law, tier_map, blockers digest, best-next-action, detected test commands, release gate, risky files, recent lineage, pinned `forge://` resources, **`prior_wisdom`**, **`token_estimate`** (payload byte length ÷ 4) | **First call after `initialize`** — orientation bundle. One round-trip replaces 6+ separate calls. Use `token_estimate` to size the payload before inserting into a context window. |
| **`doctor` (with `include_worktree: true`)** | `doctor/v1` + worktree fields — git root, branch, upstream drift, dirty files, remotes, version surfaces, resolved `forge` command, stale-command detection, recommendations (folds the retired `worktree_status`) | **Before editing or release work** when there are multiple checkouts, stale MCP concerns, dirty trees, or version mismatches. |
| **`preflight_change`** ← *Codex-4* | `preflight/v1` — per file: detected_tier, forbidden_imports, likely_tests, siblings_to_read; overall write_scope_too_broad flag | **Before** every `WriteFile` / `Edit`. Verdict `REFINE` when scope > 8 files. |
| **`score_patch`** ← *Codex-4* | `patch_score/v1` — architectural_risk, public_api_risk, release_risk, test_risk, `needs_human_review`, suggested validation commands | **After** drafting a unified-diff but **before** applying. |
| **`select_tests`** ← *Codex-5* | `test_select/v1` — `minimum_set` (mirror match) + `full_set` (tier-mate) | "Which tests must I run for this change?" — feeds into the agent's iteration loop. |
| **`rollback_plan`** ← *Codex-5* | `rollback/v1` — files-to-remove, caches, tests-to-rerun, `risk_level` | "If I have to undo this patch, how?" `risk_level=high` when release files (`pyproject` / `CHANGELOG` / `LICENSE`) were touched. |
| **`explain_repo`** ← *Codex-5* | `explain/v1` — purpose, entry-points, do-not-break list, `release_state` (READY / BLOCKED) | Humane orientation card — same data as `context_pack` but human-readable summary. |
| **`plan` (with `capability_filter`)** ← *Codex-5* | `agent_plan_adapted/v1` — each card decorated with `recommended_handling`: `apply` / `delegate` / `ask_human` / `report_only` (folds the retired `adapt_plan`) | "Filter this plan for *my* capabilities." Pass `capability_filter` (`edit_files` / `run_commands` / `network` / `review` / `delegate`). |
| **`compose_tools`** ← *Codex-5* | ordered tool sequence | Goal-keyword → tool list. Recipes: `orient`, `release_check`, `fix_violation`, `before_edit`, `verify_patch`. |
| **`load_policy`** ← *Codex-5* | `policy/v1` from `pyproject.toml [tool.forge.agent]` | First-orientation. Tells you the repo's `protected_files`, `release_gate`, `max_files_per_patch`, `require_human_review_for`. Defaults are lenient when no policy declared. |
| **`lineage`** (folds `why_did_this_change` + `what_failed_last_time`) | `lineage/v1` — full inventory / by-file events / failed-for-area events | "Why did this file get touched, historically?" / "What went wrong here before — so I don't repeat it?" |
| **`recipes`** ← *Codex-5* (folds `list_recipes` + `get_recipe`) | catalogue of golden-path recipes (no name) or full recipe body (with name) | First-orientation. Pre-baked: `release_hardening`, `add_cli_command`, `fix_wire_violation`, `add_feature`, `bump_version`, `fix_test_detection`, `publish_mcp`, `dev_cycle`, `naming_check`. |
| **`forge_locate`** | `forge_locate/v1` — file path + 5-line preview at well-known insertion points (TOOLS dict, `__all__`, register block, MCP server imports, test pinned set) | When you need to insert into a known landing site without re-reading the full file. Saves ~1000 tokens per call. |
| **`commit_compose`** | structured Conventional Commit message | When you've finished a change and want a one-call commit message. Saves ~10k tokens per substantial session. |
| **`cna_check`** | `cna_check/v1` — Compose-Not-Add verdict (PASS / REFINE / REJECT) over name + body overlap | Before adding a new symbol or module — surfaces existing duplicates so you compose instead of reinventing. |
| **`trust_gate_response`** | `trust_gate/v1` — response hallucination checks | Before sending generated implementation notes or code snippets back to a human. |
| **`verify` (with `check_exports: true`)** | `verify/v1` + exported-API verification (folds the retired `exported_api_check`) | Before publishing generated modules that claim public functions in docs. |

Every `tools/list` entry includes a `cli_command` fallback. If the MCP
transport drops, use that command shape directly in the shell while
you restart the editor or MCP host. `tools/list` also includes the
Forge version and server source path so agents can detect stale MCP
hosts.

**Four integration tiers, by depth of coupling:**

1. **Lightweight (3 tools)**: `context_pack` once for orientation
   (returns `prior_wisdom` automatically), then `wire` + `certify`
   before commit. Drop-in for any platform.
2. **Predictive (8 tools)**: add `load_policy` + `select_tests` on
   orientation; `preflight_change` *before* every write;
   `score_patch` *after* drafting the diff; `verify` as the single
   composite ship gate. Forge is the always-on senior engineer
   reviewing each step.
3. **Proposal-engine (full 30+ tools)**: `plan` for direction
   (with `capability_filter` to match your agent), `plan_apply` to
   execute, `enforce` for mechanical fixes, `rollback_plan` if
   anything regresses, `lineage` for historical context,
   `wisdom recall` for cross-session institutional memory. Forge
   drives; the agent supplies LLM context where Forge can't mechanize.
4. **Transmuter + cross-repo (10 additional tools)**: `auto` to absorb
   any repo in one shot, `cherry` / `finalize` for surgical control,
   `iterate_start` / `iterate_continue` to generate from intent
   (your LLM in the loop, Forge holds zero LLM clients),
   `evolve_start` / `evolve_step` for recursive self-improvement,
   `recon_swarm` / `harvest` / `emergent_swarm` for cross-repo
   discovery (N≤23 repos, D_max bounded), `tool_factory` to scaffold
   a new MCP tool from a spec (Forge eats Forge). These tools mutate
   the filesystem; always run with the appropriate `apply` flag and
   verify with `wire` + `certify` afterward.

`context_pack`, `preflight_change`, `select_tests`, and `score_patch`
are language-aware as of `0.5.2`: JavaScript projects with
`package.json` scripts get `npm run verify` / `npm test`, tier wire
commands are derived from real tier roots, and documentation paths
such as `docs/`, `research/`, `.github/`, and `cognition/guides/` are
treated as non-code artifacts rather than misplaced source.

---

## The 5 MCP resources

| Resource URI | What it is | Use case |
|---|---|---|
| `forge://docs/receipt` | The Receipt schema spec | Agent reads this to know what the Receipt JSON contract is. |
| `forge://docs/formalization` | Citations to `aethel-nexus-proofs` (29 theorems / 0 sorry) and `proof-corpus-v22` (538 theorems / 0 sorry) | Agent presenting Forge to a regulator: cite the proof corpus. |
| `forge://lineage/chain` | Episodic L1 trace of every Forge run | Replay / debugging / audit. |
| `forge://schema/receipt` | Machine-readable JSON Schema for the Receipt | Agent doing type-checked Receipt parsing. |
| `forge://summary/blockers` | Same payload as `agent_summary` MCP tool | One-shot `resources/read` for clients that prefer resources over tools. |

The `attestation/{id}` resource is the **convergence point** of the
BEP-1 architecture: same Receipt JSON the agent gets here is what
the terminal Card prints, what the GitHub Action posts to the PR, and
what the Conformity Statement CS-1 PDF wraps. *One artifact, five
surfaces.*

---

## In-editor surface — `forge lsp serve` (Lane D W12)

When the agent is **co-driving with a human in an editor** (Cursor,
VS Code, Neovim, Helix, IntelliJ), MCP isn't the right surface for
sidecar feedback — it should land where the cursor is. Forge ships
an **LSP server** for that:

```bash
forge lsp serve   # speaks stdio JSON-RPC, LSP-spec-compliant
```

What the agent gets through the LSP surface:

- **`textDocument/publishDiagnostics`** — every sidecar drift
  finding from `sidecar_validator` published with its **F0100-F0106
  code**, so an agent reading the editor's "Problems" panel can
  route fixes through the same F-code namespace it already uses for
  wire violations and certify failures.
- **`textDocument/hover`** — markdown summary of the cursor's
  symbol (effect, tier, `compose_with`, `proves`).
- **`textDocument/definition`** — goto-source: `name: login` line
  in `foo.py.forge` jumps to `foo.py:login`.

VS Code + Neovim drop-in snippets are in
[`docs/COMMANDS.md`](COMMANDS.md) under `forge lsp serve`. The
packaged VS Code extension lives in its own repository
(`atomadic-forge-vscode-ext`); a JetBrains plugin is roadmap.

This is the third axis of agent integration — alongside the MCP
tool surface and the Receipt JSON wire format. **Coding agents
that wrap a real editor (Cursor, Continue, Aider) should consume
both the MCP surface AND the LSP surface** — MCP for the action
loop, LSP for the in-line drift feedback as the human types.

---

## The Forge Receipt — what it tells you

When an agent calls `certify` (or follows `forge auto`), it gets a
**Forge Receipt** back. Schema documented in [`docs/RECEIPT.md`](RECEIPT.md);
key fields the agent should read:

```json
{
  "schema_version": "atomadic-forge.receipt/v1",
  "verdict": "PASS | FAIL | REFINE | QUARANTINE",
  "certify": {
    "score": 100,
    "components": { "structural": 35, "runtime": 25, "behavioral": 30, "operational": 10 }
  },
  "wire": { "verdict": "PASS", "violation_count": 0, "auto_fixable": 0 },
  "scout": { "tier_distribution": { "a0": 14, "a1": 258, ... } },
  "signatures": { "aaaa_nexus": { ... } },
  "lean4_attestation": { "corpora": [...] },
  "lineage": { "lineage_path": "..." }
}
```

**Decision rules for the agent**:

- `verdict == "PASS"` → safe to commit / merge
- `verdict == "FAIL"` → at least one structural gate failed; check `certify.issues`
- `verdict == "REFINE"` → in flight; re-run after the next change
- `verdict == "QUARANTINE"` → human audit needed; do not auto-merge

If `signatures.aaaa_nexus` is populated, the Receipt is **signed by
AAAA-Nexus** — the agent can present it to a downstream consumer
(another agent, a regulator, a CI gate) as proof of structural
conformance.

---

## F-codes — the citeable error catalog

Every error Forge surfaces carries a stable 4-digit code. Agents
should pivot, dashboard, and route on these — never on the message
strings (those can change per locale).

| Range | Domain | Most common |
|---|---|---|
| F0001–F0009 | scout / classification | F0001 unclassifiable symbol |
| F0010–F0019 | cherry-pick | F0011 ambiguous qualname |
| F0040–F0049 | wire / upward-import | **F0042 a1 imports from a3+** ← most common |
| F0050–F0059 | certify axis failures | F0050 missing README, F0051 no tests |
| F0060–F0069 | stub detection | F0061 `pass`-only function body |
| F0070–F0079 | import-repair | F0070 conflicting move-target |
| F0080–F0089 | assimilate conflicts | F0081 colliding qualnames |
| F0090–F0099 | receipt / signing | F0091 AAAA-Nexus signing 4xx |

**`forge enforce` routes mechanical fixes by F-code.** When `wire`
returns auto-fixable F-codes, the agent can either:

1. Hand them to `enforce` for automatic resolution (rollback-safe), or
2. Read the suggested repair and apply it itself (preferred when the
   agent's broader context implies a different fix shape).

Either way, the F-code is the contract.

---

## Common agent flows

### Flow 1 — "Improve this repo" (the highest-leverage entry point)

```
agent: agent_summary({ "project": "." })
forge: { "verdict": "REFINE", "top_issues": [
          { "f_code": "F0050", "summary": "README.md is short", "auto_fixable": false, "fix_hint": "..." },
          { "f_code": "F0042", "summary": "a1_at_functions/foo.py imports a3_og_features.bar",
            "auto_fixable": true, "next_command": "forge enforce src/ --f-codes F0042" }
        ], "next_command": "forge enforce src/ --f-codes F0042 --apply" }
agent: enforce({ "scope": "src/", "f_codes": ["F0042"], "apply": true })
forge: { "applied": 1, "rollback": "...", "new_receipt": { ... certify.score: 92 → 95 ... } }
```

### Flow 2 — "Generate code that lands in the right tier"

```
agent: needs to add a new feature; calls wire on a hypothetical placement first
agent: wire({ "scope": "src/", "include_proposed": "src/a1_at_functions/new_helper.py" })
forge: { "verdict": "PASS", "tier_recommendation": "a1_at_functions" }
agent: writes the file knowing it will pass wire BEFORE the LLM emits
```

### Flow 3 — "Verify before merge"

```
agent: certify({ "project": ".", "package": "atomadic_forge" })
forge: { "score": 100, "verdict": "PASS", "signatures": { "aaaa_nexus": {...} } }
agent: PR description includes Receipt's lineage_path + score
human: merges with confidence; the Receipt provenance survives in lineage.jsonl
```

---

## Receipt-as-PR-comment (consume it from the agent)

When the agent calls `certify`, the Receipt JSON is the agent's
deliverable for the PR description / sticky comment. A typical
agent-emitted PR comment:

```
**Forge** · 100/100 · Δ +5 vs main
- a0 14 · a1 258 · a2 58 · a3 52 · a4 14
- wire 0 · stub 0 · Lean4 ✓ · AAAA-Nexus signed nx-7f3…
- Reproduce: `forge certify . --pr ${{ github.event.pull_request.number }}`
```

This is what the [`atomadictech/forge-action`](https://github.com/atomadictech/forge-action)
GitHub Action emits automatically when installed. Agents using Forge
locally can produce the same artifact.

---

## Soft-fail contract — Forge is always usable

Forge composes AAAA-Nexus's safety primitives but **never throws** on
upstream failure. Examples the agent should expect:

| Upstream | Behavior |
|---|---|
| `AAAA_NEXUS_API_KEY` unset | Receipt is structurally valid; `signatures` is null; `note` says `"key not set"` |
| AAAA-Nexus 4xx (auth / rate / endpoint not shipped) | unsigned + endpoint cached unavailable for the run |
| AAAA-Nexus 5xx / network error | unsigned + retry note |
| AAAA-Nexus 200 | Receipt's `signatures.aaaa_nexus` populated |
| Lean4 corpus unreachable | `lean4_attestation` is null; `note` cites the corpus URL |

**Unsigned-but-structurally-valid is always the fallback.** This means
local-development agents (no network, no API key) can still consume
Forge's normative answer; only the *attestation chain* is missing.

---

## Best practices for agent integrations

1. **Call `agent_summary` first**, not `recon`/`certify`/`wire` separately. It pre-merges the queue.
2. **Cache `recon` output** — it's cheap to compute but pure. The Receipt's `lineage_path` lets the agent confirm the cache is valid.
3. **Pivot on F-codes**, never error message strings.
4. **Read `signatures`, `lean4_attestation`, `lineage`** before claiming "Forge approved" externally.
5. **Use `enforce` for F-codes you don't have context to fix** — it's rollback-safe.
6. **Surface the Receipt to humans** when relevant (PR comments, CI logs, error dialogs).
7. **Never compose your own architectural rules** — read `forge://arch/law` and respect what Forge says.

---

## Common gotchas

| Symptom | Likely cause | Fix |
|---|---|---|
| Tools list returns 0 tools | MCP client didn't pass `--project .` | Check args in MCP config |
| Tools list returns < 61 (e.g. 40 / 44 / 51 / 52 / 59 / 60) | Old `forge` install | `pip install -U atomadic-forge` (or `pip install -e .` from the repo). Pin `forge --version >= 0.14.0a10`. |
| `wire` says PASS but agent still hits import errors | Agent is running tests in a different working directory | `--project` should match the test cwd |
| `certify` returns score 90 instead of 100 | Project has no `.github/workflows/` and no `CHANGELOG.md` (operational axis is 0) | Add either; both are 5pts |
| Receipt's `signatures` is null | `AAAA_NEXUS_API_KEY` not set, or AAAA-Nexus endpoint not yet shipped | Soft-fail behavior — Receipt is still valid for local use |
| F0042 keeps re-firing after `enforce` | The agent is generating new upward imports faster than enforce can fix | The agent's prompt template needs the tier-map context (read `forge://arch/law` first) — or call `preflight_change` *before* every write |
| `preflight` returns `write_scope_too_broad: true` constantly | Agent intent is too coarse-grained, OR the repo declares `[tool.forge.agent].max_files_per_patch < 8` (Codex-6) | Split the intent into smaller atomic intents, or raise `--scope-threshold`. Read `load_policy` first to see what the repo allows. |
| `score_patch` returns `needs_human_review` on every diff | Diffs touch `__init__.py` or pyproject reflexively, OR a path matched `[tool.forge.agent].protected_files` (Codex-6) | Strip those edits into a dedicated commit. Or call `load_policy` first to know what's protected. |
| `preflight` flags every file in a perfectly-sized patch as "request human review" | One of the proposed files matched `protected_files` in the repo's policy | This is intentional — `protected_files` are the social contract. Surface to the human reviewer instead of auto-applying. |

---

## Now shipped — proposal-engine + copilot's-copilot (Codex-2/3/4)

`atomadic-forge.agent_plan/v1` shipped at master (`c7ad6d8`) — sister
schema to the Receipt, optimized for proposal-engine mode. Agents get:

- **`forge plan`** — emits a ranked `agent_plan/v1` JSON card to stdout
- **`plan` MCP tool** — same shape returned via the MCP server (folds
  the retired `auto_plan` and `adapt_plan`; pass `capability_filter`
  to apply the adapt branch)
- **Action cards** — small JSON objects the agent can inspect, edit,
  and apply with explicit `write_scope`, `risk`, `commands`, and
  `applyable` flags

Schema doc: see the `atomadic-forge.agent_plan/v1` block in
`a0_qk_constants/agent_plan_schema.py` (and the matching narrative in
`docs/COMMANDS.md` under `forge plan`).

### Now shipped — Codex-3 plan apply chain

Codex-3 closed the plan loop at master (`2cafbcc`):

- **`forge plan --save`** — persists a plan to
  `.atomadic-forge/plans/<id>.json` (append-only).
- **`forge plan-list`** — lists every saved plan with status counts.
- **`forge plan-show <id>`** — prints a saved plan's cards + per-card
  state (`pending` / `applied` / `rejected` / `skipped`).
- **`forge plan-step <id> <card_id> --accept|--reject|--skip`** —
  marks a single card and writes a sidecar `.state.json`.
- **`forge plan-apply <id>`** — executes every `applyable` accepted
  card. Routing:
  - `F0041`–`F0046` (architectural / wire) → `forge enforce --apply`
    (rollback-safe, AST-driven).
  - `F0050` (docs missing) → bounded stub README writer.
- **MCP tools** — `plan_list`, `plan_show`, `plan_step`, `plan_apply`
  match the CLI verbs one-for-one.

Implementation lives in:
- `a2_mo_composites/plan_store.py` — append-only plan + state store
- `a3_og_features/forge_plan_apply.py` — `apply_card` /
  `apply_all_applyable` orchestrators

### Now shipped — Codex-4 copilot's copilot (`fa50644`)

Three pure-a1 primitives that turn Forge into the **architectural
control plane around any coding agent**:

- **`context_pack`** (CLI: `forge context-pack`, MCP: `context_pack`) —
  the orientation bundle the agent loads on first contact with a
  repo. One call, one JSON, ten baseline fields (purpose / law /
  tier_map / blockers / next-action / test-commands / release-gate /
  risky-files / lineage / pinned resources). When the task is already
  known, call it with `focus`, `intent`, and `files` to get targeted
  file context, preflight, selected tests, and suggested next steps in
  the same payload.
- **`preflight_change`** (CLI: `forge preflight`, MCP: `preflight_change`)
  — pre-edit guardrail. Per file: tier detected, tiers forbidden,
  likely tests, siblings to read. Returns `write_scope_too_broad =
  true` when the agent's intent fans out across more than 8 files
  (configurable). CLI exits 1 in that case so a pre-commit hook can
  block.
- **`score_patch`** (CLI: `forge score-patch`, MCP: `score_patch`) — diff-level risk
  preview. Given a unified-diff string, surfaces architectural_risk
  (new upward imports), public_api_risk (`__init__.py` touched),
  release_risk (pyproject / version / CHANGELOG / LICENSE), test_risk
  (code without tests), >200-line blast-radius flag → composite
  `needs_human_review` boolean + suggested validation commands.

Implementation lives in three pure-a1 modules (no a3 injection
needed; they read from reports + filesystem only):

- `a1_at_functions/agent_context_pack.py`
- `a1_at_functions/preflight_change.py`
- `a1_at_functions/patch_scorer.py`

Tests: 611 passing (was 582 before Codex-4; +29 net). `forge wire`
PASS at every commit, `forge certify .` = 100/100 held.

Watch [CHANGELOG.md](../CHANGELOG.md) for the next round.

---

## Quick reference

```bash
# Smoke
forge mcp serve --project .

# One-shot summary
forge mcp serve --project . <<< '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"agent_summary","arguments":{}}}'

# Reproduce a Receipt
forge certify . --emit-receipt out.json --sign

# Print the Forge Card (paste-ready for PRs / chat)
forge certify . --print-card
```

| What | Where |
|---|---|
| Schema for the Receipt | [`docs/RECEIPT.md`](RECEIPT.md) |
| All commands | [`docs/COMMANDS.md`](COMMANDS.md) |
| Agents *building* Forge (dev contract) | [`AGENTS.md`](../AGENTS.md) |
| First-10-minutes onboarding | [`docs/FIRST_10_MINUTES.md`](FIRST_10_MINUTES.md) |
| Strategic landscape | [`docs/LANDSCAPE.md`](LANDSCAPE.md) |
| **This guide** | `docs/AGENTS_GUIDE.md` (you are here) |

---

*Atomadic Forge. Absorb. Enforce. Emerge. Tier-clean by construction.*
