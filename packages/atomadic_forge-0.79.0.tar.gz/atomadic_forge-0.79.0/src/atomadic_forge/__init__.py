"""Atomadic Forge — absorb, enforce, emerge.

A monadic-architecture engine for absorbing Python or JavaScript /
TypeScript repositories into a verified 5-tier layout, enforcing layered
import discipline, and surfacing emergent compositions across the
resulting catalog.

Public version surface only — every symbol lives in its tier package and
is re-exported lazily by the CLI.
"""

from __future__ import annotations

from pathlib import Path


def _parse_project_version(text: str) -> str | None:
    try:
        try:
            import tomllib
        except ModuleNotFoundError:  # pragma: no cover - Python 3.10
            import tomli as tomllib  # type: ignore[no-redef]
        data = tomllib.loads(text)
        project = data.get("project", {})
        if project.get("name") == "atomadic-forge":
            version = project.get("version")
            return version if isinstance(version, str) else None
    except Exception:
        return None
    return None


def _local_pyproject_version() -> str | None:
    for parent in Path(__file__).resolve().parents:
        pyproject = parent / "pyproject.toml"
        if not pyproject.exists():
            continue
        version = _parse_project_version(pyproject.read_text(encoding="utf-8"))
        if version:
            return version
    return None


def _installed_version() -> str | None:
    try:
        from importlib.metadata import PackageNotFoundError as _PNF
        from importlib.metadata import version as _pkg_version
        try:
            return _pkg_version("atomadic-forge")
        except _PNF:
            return None
    except ImportError:  # pragma: no cover - Python < 3.8 path
        return None


# Source checkouts prefer their own pyproject.toml; installed wheels fall
# back to package metadata because wheel installs do not ship pyproject.toml.
__version__ = _local_pyproject_version() or _installed_version() or "0.0.0+dev"
