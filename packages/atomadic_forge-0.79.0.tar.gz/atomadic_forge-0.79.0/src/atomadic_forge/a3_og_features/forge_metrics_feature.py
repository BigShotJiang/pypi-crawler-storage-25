"""Tier a3 — orchestrator: build the canonical ``forge_metrics.json``.

Composes the pure a1 ``compute_forge_metrics`` aggregator with live
forge surface introspection (TOOLS dict, CLI registry, certify run)
and writes the resulting artifact to ``<repo_root>/forge_metrics.json``.

Public surfaces (README, CHANGELOG, welcome handshake, the Cloudflare
Worker, shields.io badges) all read from that one file. Run via the
CLI verb ``forge metrics`` — apply mode regenerates and overwrites.
"""
from __future__ import annotations

import json
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as pkg_version
from pathlib import Path
from typing import Any

from ..a1_at_functions.forge_metrics import (
    compute_forge_metrics,
    write_forge_metrics,
)

# IP-protected proof corpus location is read from the FORGE_PROOF_CORPUS env
# var. Falls through gracefully when not set or not present — the
# metric simply reports ``lean_theorems.found = False``. We never hard-
# code public paths to the IP repo, and the public artifact never
# carries the path it was sourced from.
_FORGE_CORPUS_ENV = "FORGE_PROOF_CORPUS"


def _find_proof_corpus(start: Path) -> Path | None:
    """Resolve the IP-protected proof corpus repo via FORGE_PROOF_CORPUS env
    var, falling back to a sibling-directory probe.

    Returns the resolved path if a ``proofs/`` subtree is present;
    otherwise None. The path is intentionally NOT logged or returned in
    the public ``forge_metrics.json`` artifact.
    """
    import os
    env_path = os.environ.get(_FORGE_CORPUS_ENV)
    candidates: list[Path] = []
    if env_path:
        candidates.append(Path(env_path))
    # Sibling-directory probe — checks for a proof-corpus directory
    # adjacent to the forge repo. No public hardcoded absolute paths.
    candidates.extend([start / "../proof-corpus", start / "../../proof-corpus"])
    for c in candidates:
        try:
            r = c.resolve()
        except OSError:
            continue
        if (r / "proofs").is_dir():
            return r
    return None


def _safe_pkg_version(repo_root: Path) -> str:
    """Source-of-truth package version.

    Prefers ``pyproject.toml`` (canonical, authoritative for the repo
    state) over ``importlib.metadata`` (the installed version, which
    can lag behind source edits). Falls back to ``0.0.0+dev`` only when
    neither is available.
    """
    pyproject = Path(repo_root) / "pyproject.toml"
    if pyproject.is_file():
        try:
            text = pyproject.read_text(encoding="utf-8")
            import re
            # Match the FIRST top-level ``version = "X"`` after
            # ``[project]``. Falls through to importlib if not found.
            project_section = text.split("[project]", 1)
            if len(project_section) == 2:
                m = re.search(
                    r'^\s*version\s*=\s*"([^"]+)"',
                    project_section[1],
                    re.MULTILINE,
                )
                if m:
                    return m.group(1)
        except (OSError, UnicodeDecodeError):
            pass
    try:
        return pkg_version("atomadic-forge")
    except PackageNotFoundError:
        return "0.0.0+dev"


def _live_tools_count() -> tuple[int, int]:
    """(tools_count, actions_count) read from the live MCP TOOLS dict."""
    from ..a1_at_functions.mcp_protocol import TOOLS
    actions = 0
    for spec in TOOLS.values():
        enum = (spec.get("inputSchema", {})
                    .get("properties", {})
                    .get("action", {})
                    .get("enum", []))
        if enum:
            actions += len(enum)
        # nexus uses 'op' instead of 'action'
        op_enum = (spec.get("inputSchema", {})
                       .get("properties", {})
                       .get("op", {})
                       .get("enum", []))
        actions += len(op_enum)
    return len(TOOLS), actions


# Note: CLI verb count cannot be queried from a3 — that would be an
# upward import (a3 -> a4) and violate the monadic tier law. The CLI
# verb count is supplied by the caller (a4 commands/metrics.py reads
# it from the live Typer app and passes it as cli_verbs_count).


def _read_existing_metrics(repo_root: Path) -> dict[str, Any]:
    """Read the current ``forge_metrics.json`` if it exists; return {} on any error."""
    path = Path(repo_root) / "forge_metrics.json"
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return {}


def _prior_lean_from_existing(existing: dict[str, Any]) -> dict[str, Any] | None:
    """Return the prior Lean theorem block from flat or public metrics shapes."""
    flat = existing.get("lean_theorems")
    if isinstance(flat, dict):
        return flat
    nested = existing.get("metrics")
    if isinstance(nested, dict):
        count = int(nested.get("lean4_theorem_count") or 0)
        if count > 0:
            return {
                "count": count,
                "theorems": count,
                "lemmas": 0,
                "files": int(nested.get("lean4_file_count") or 0),
                "found": True,
            }
    return None


def _prior_tests_from_existing(existing: dict[str, Any]) -> int | None:
    """Return prior externally-counted pytest pass total from either schema."""
    value = existing.get("tests_passing")
    if isinstance(value, int) and value > 0:
        return value
    nested = existing.get("metrics")
    if isinstance(nested, dict):
        value = nested.get("test_count")
        if isinstance(value, int) and value > 0:
            return value
    return None


def _public_metrics_artifact(
    flat: dict[str, Any],
    *,
    existing: dict[str, Any],
) -> dict[str, Any]:
    """Project internal flat metrics to the public v0.75 metrics artifact.

    ``forge_metrics.json`` is consumed by README badges, the website worker,
    registry sync, and docs automation. The public shape is intentionally
    compact and stable; ``doc_auto_update._load_metrics`` still accepts both
    this nested shape and the older flat one.
    """
    nested_existing = existing.get("metrics") if isinstance(existing.get("metrics"), dict) else {}
    assert isinstance(nested_existing, dict)
    lean = flat.get("lean_theorems") or {}
    languages = list(nested_existing.get("languages") or [
        "Python",
        "JavaScript",
        "TypeScript",
        "Rust",
        "Go",
        "Swift",
        "Kotlin",
    ])
    public_actions = max(
        int(flat.get("mcp_actions") or 0),
        int(nested_existing.get("mcp_action_count") or 0),
    )
    return {
        "version": str(flat.get("package_version") or nested_existing.get("version") or "0.0.0+dev"),
        "generated_utc": str(flat.get("generated_at_utc") or ""),
        "metrics": {
            "test_count": int(flat.get("tests_passing") or flat.get("test_functions") or 0),
            "test_file_count": int(flat.get("test_files") or 0),
            "mcp_tool_count": int(flat.get("mcp_tools") or 0),
            "mcp_action_count": public_actions,
            "source_file_count": int(flat.get("source_files") or 0),
            "source_line_count": int(flat.get("source_lines") or 0),
            "cli_verb_count": int(flat.get("cli_verbs") or 0),
            "lean4_theorem_count": int(lean.get("count") or 0),
            "recipe_count": int(nested_existing.get("recipe_count") or 9),
            "language_count": len(languages),
            "languages": languages,
            "infra_cost": str(nested_existing.get("infra_cost") or "$5/mo"),
        },
    }


def _self_certify(repo_root: Path) -> dict[str, Any]:
    """Run a fast self-cert (skip_tests=True) — best-effort, never fatal."""
    try:
        pass  # type: ignore
    except Exception:
        try:
            from .welcome_feature import _certify  # type: ignore
        except Exception:
            return {}
        try:
            res = _certify(project_root=repo_root, skip_tests=True)
            return {
                "score": res.get("score"),
                "wire_violations": res.get("detail", {})
                                       .get("wire", {})
                                       .get("violation_count"),
            }
        except Exception:
            return {}
    return {}


def emit_forge_metrics(
    repo_root: Path,
    *,
    apply: bool = False,
    proof_corpus_root: Path | None = None,
    skip_self_cert: bool = True,
    cli_verbs_count: int | None = None,
    tests_passing: int | None = None,
) -> dict[str, Any]:
    """Compute live forge metrics; optionally write ``forge_metrics.json``.

    Args:
        repo_root: forge repo path. Used to locate ``src/``, ``tests/``,
            and the output ``forge_metrics.json``.
        apply: when True, overwrite ``<repo_root>/forge_metrics.json``
            with the freshly computed artifact. When False, the artifact
            is computed and returned but not written.
        proof_corpus_root: optional override; defaults to autodetected
            location via sibling-directory probe.
        skip_self_cert: when True (default) the certify call is skipped
            for speed. Set False to embed the latest certify score in
            the artifact (slower; runs the full pipeline).

    Returns:
        Dict with ``metrics`` (the artifact), ``written_to`` (None or
        absolute path), and ``proof_corpus_root_used``.
    """
    repo_root = Path(repo_root).resolve()
    if proof_corpus_root is None:
        proof_corpus_root = _find_proof_corpus(repo_root)
    # Read the existing artifact so we can preserve fields that cannot be
    # recomputed locally (lean_theorems when corpus is absent, tests_passing
    # when --tests-passing is not supplied by the caller).
    existing = _read_existing_metrics(repo_root)
    prior_lean: dict[str, Any] | None = _prior_lean_from_existing(existing)
    # Preserve prior tests_passing when the caller did not supply a fresh value.
    resolved_tests_passing = tests_passing
    if resolved_tests_passing is None:
        resolved_tests_passing = _prior_tests_from_existing(existing)
    tools_count, actions_count = _live_tools_count()
    cert = {} if skip_self_cert else _self_certify(repo_root)
    flat_metrics = compute_forge_metrics(
        repo_root,
        proof_corpus_root=proof_corpus_root,
        prior_lean_theorems=prior_lean,
        package_version=_safe_pkg_version(repo_root),
        tools_count=tools_count,
        actions_count=actions_count,
        cli_verbs_count=cli_verbs_count,
        self_certify_score=cert.get("score"),
        self_wire_violations=cert.get("wire_violations"),
        tests_passing=resolved_tests_passing,
    )
    metrics = _public_metrics_artifact(flat_metrics, existing=existing)
    written: str | None = None
    if apply:
        out = repo_root / "forge_metrics.json"
        written = str(write_forge_metrics(metrics, out))
    return {
        "metrics": metrics,
        "written_to": written,
        "proof_corpus_root_used": str(proof_corpus_root) if proof_corpus_root else None,
    }


__all__ = ["emit_forge_metrics"]
