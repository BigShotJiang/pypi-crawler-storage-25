"""Tier a3 — ``forge absorb``: ingest any Python repo into a tier-organized package.

Pipeline::

    source_repos (any layout)
        -> resolve each to (src_root, package_name) via harvest_absorb
        -> emergent_swarm(repos)          # cross-repo composition discovery
        -> materialize_from_report_path   # write tier-organized package
        -> certify (optional)
        -> return AbsorbReport dict
"""

from __future__ import annotations

import datetime as _dt
import json
from pathlib import Path
from typing import Any

from ..a1_at_functions.harvest_absorb import resolve_any_python_package
from .emergent_swarm import emergent_swarm
from .materialize_feature import materialize_from_report_path

SCHEMA_VERSION_ABSORB_V1 = "atomadic-forge.absorb/v1"


def absorb_repo(
    source_repos: list[Path],
    *,
    out_dir: Path,
    package: str | None = None,
    top_n: int = 10,
    run_certify: bool = True,
    swarm_max_depth: int = 3,
    require_pure: bool = False,
    domain_jump_required: bool = True,
    cross_repo_bonus: float = 15.0,
) -> dict[str, Any]:
    """Absorb one or more Python repos into a tier-organized Atomadic package.

    Args:
        source_repos: paths to repos to ingest. Any layout is accepted.
        out_dir: where to write the new package.
        package: importable name for the new package. Defaults to the
            primary source package name suffixed with ``_absorbed``.
        top_n: materialize the top-N emergent candidates.
        run_certify: run ``certify`` on the new package after materialization.
        swarm_max_depth / require_pure / domain_jump_required /
        cross_repo_bonus: forwarded to :func:`emergent_swarm`.

    Returns:
        Dict with ``schema_version``, ``source_repos``, ``out_dir``,
        ``package``, ``scan_summary``, ``materialize`` (full report),
        and ``scan_report_path``.
    """
    if not source_repos:
        raise ValueError("absorb_repo requires at least one source repo")

    resolved = [resolve_any_python_package(p) for p in source_repos]

    if package is None:
        package = resolved[0].package_name + "_absorbed"
    if not package.isidentifier():
        raise ValueError(f"package must be a valid Python identifier: {package!r}")

    swarm_repos = [(r.src_root, r.package_name) for r in resolved]
    swarm_report = emergent_swarm(
        repos=swarm_repos,
        top_n=max(top_n, 25),
        max_depth=swarm_max_depth,
        require_pure=require_pure,
        domain_jump_required=domain_jump_required,
        cross_repo_bonus=cross_repo_bonus,
    )

    out_dir = Path(out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    forge_dir = out_dir / ".atomadic-forge"
    forge_dir.mkdir(parents=True, exist_ok=True)
    scan_path = forge_dir / "absorb_scan.json"
    scan_path.write_text(json.dumps(swarm_report, indent=2, default=str), encoding="utf-8")

    source_pkg = (
        resolved[0].package_name
        if len(resolved) == 1
        else "+".join(r.package_name for r in resolved)
    )
    materialize_report = materialize_from_report_path(
        scan_path,
        out_dir=out_dir,
        package=package,
        top_n=top_n,
        run_certify=run_certify,
        source_package=source_pkg,
        intent=f"Absorbed from: {source_pkg}",
    )

    scan_summary = {
        "repo_count": swarm_report.get("repo_count"),
        "union_catalog_size": swarm_report.get("union_catalog_size"),
        "candidate_count": swarm_report.get("candidate_count"),
        "cross_repo_chain_count": swarm_report.get("cross_repo_chain_count"),
        "novel_composition_count": swarm_report.get("novel_composition_count"),
    }

    receipt: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION_ABSORB_V1,
        "generated_at_utc": _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "source_repos": [
            {
                "src_root": str(r.src_root),
                "package": r.package_name,
                "layout": r.layout,
                "repo_root": str(r.repo_root),
            }
            for r in resolved
        ],
        "out_dir": str(out_dir),
        "package": package,
        "top_n": top_n,
        "scan_report_path": str(scan_path),
        "scan_summary": scan_summary,
        "materialize": materialize_report,
    }
    (forge_dir / "absorb.json").write_text(
        json.dumps(receipt, indent=2, default=str), encoding="utf-8"
    )
    return receipt


__all__ = (
    "SCHEMA_VERSION_ABSORB_V1",
    "absorb_repo",
)
