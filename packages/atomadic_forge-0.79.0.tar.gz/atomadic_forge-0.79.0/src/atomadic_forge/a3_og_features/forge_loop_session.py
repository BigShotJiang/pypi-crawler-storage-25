"""Tier a3 — agent-driven iterate / evolve sessions.

The Round-3 substrate-boundary fix: forge stops holding an LLM client.
The calling agent (Cursor / Claude Code / Aider / Devin / a custom
orchestrator) drives its own LLM. Forge supplies analytical certainty
between turns: parse the agent's response into files, write them,
run wire + certify, fold the results back into the next prompt.

API shape::

    sess = iterate_start_session(intent, output, package, ...)
    # → {session_id, system_prompt, first_prompt}
    # agent calls its own LLM with system_prompt + first_prompt
    response = agent_llm.call(...)
    next = iterate_continue_session(session_id, response, project_root)
    # → either {done: True, halt_reason, score, files_written, ...}
    #    or {done: False, next_prompt, score, turn, ...}
    # agent loops until done.

This module composes a1 pure helpers (``pack_initial_intent``,
``parse_files_from_response``, ``pack_feedback``, ``scan_violations``,
``certify``) and the a2 ``IterateSessionStore`` for state. No LLM
client is constructed here — that's the whole point.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ..a0_qk_constants.gen_language import (
    Language,
    normalize_language,
    pkg_root_for,
)
from ..a1_at_functions.certify_checks import certify as _certify
from ..a1_at_functions.forge_feedback import (
    pack_feedback,
    pack_initial_intent,
    parse_files_from_response,
    system_prompt,
)
from ..a1_at_functions.scout_walk import harvest_repo
from ..a1_at_functions.wire_check import scan_violations
from ..a2_mo_composites.iterate_session_store import (
    IterateSessionStore,
)
from .forge_loop import _scaffold_package, _write_files

SCHEMA_VERSION_ITERATE_START_V1 = "atomadic-forge.iterate_start/v1"
SCHEMA_VERSION_ITERATE_CONTINUE_V1 = "atomadic-forge.iterate_continue/v1"


def iterate_start_session(
    intent: str,
    *,
    output: Path,
    project_root: Path,
    package: str = "generated",
    seed_repos: list[Path] | None = None,
    target_score: float = 75.0,
    max_iterations: int = 5,
    language: Language | str = "python",
) -> dict[str, Any]:
    """Open a new agent-driven iterate session.

    Returns the session_id, the system prompt the agent must put first,
    and the first user prompt. NO LLM call is made here — the agent
    issues the LLM call themselves and feeds the response back via
    ``iterate_continue_session``.
    """
    if not intent or not intent.strip():
        raise ValueError("intent must be a non-empty string")
    output = Path(output).resolve()
    project_root = Path(project_root).resolve()
    output.mkdir(parents=True, exist_ok=True)
    lang = normalize_language(language)

    # Scaffold the surrounding package so the agent's emitted files have
    # somewhere to land. Idempotent — a second start_session over the
    # same output won't clobber existing files unrelated to this run.
    _scaffold_package(output, package, intent=intent, language=lang)

    # Optional seed catalog — read scout symbols from supplied repos.
    seed_catalog: list[dict] = []
    seed_repo_strs: list[str] = []
    for sr in (seed_repos or []):
        sr_path = Path(sr)
        if not sr_path.exists():
            continue
        scout = harvest_repo(sr_path)
        seed_catalog.extend(scout.get("symbols", []))
        seed_repo_strs.append(str(sr_path.resolve()))

    sys_prompt = system_prompt(language=lang)
    first_prompt = pack_initial_intent(
        intent, package=package, seed_catalog=seed_catalog,
        language=lang,
    )

    store = IterateSessionStore(project_root)
    state = store.create(
        intent=intent, output=output, package=package, language=lang,
        target_score=target_score, max_iterations=max_iterations,
        seed_repos=seed_repo_strs,
    )
    state.transcript.append({
        "turn": 0, "phase": "initial",
        "first_prompt_chars": len(first_prompt),
    })
    store.save(state)

    return {
        "schema_version": SCHEMA_VERSION_ITERATE_START_V1,
        "session_id": state.session_id,
        "system_prompt": sys_prompt,
        "first_prompt": first_prompt,
        "package": package,
        "language": lang,
        "output": str(output),
        "target_score": target_score,
        "max_iterations": max_iterations,
        "seed_count": len(seed_catalog),
    }


def iterate_continue_session(
    session_id: str,
    response: str,
    *,
    project_root: Path,
) -> dict[str, Any]:
    """Process one round of an agent-driven iterate session.

    Steps performed (all deterministic, no LLM):
      1. Parse files from the agent's response (JSON-array shape).
      2. Write them to the session's output package.
      3. Run wire + certify on the resulting tree.
      4. Decide: converged (target met) / halt (max_iter) / continue.
      5. Build the next prompt using ``pack_feedback`` if continuing.
      6. Persist the turn into the session transcript.
    """
    project_root = Path(project_root).resolve()
    store = IterateSessionStore(project_root)
    state = store.load(session_id)
    if state is None:
        return {
            "schema_version": SCHEMA_VERSION_ITERATE_CONTINUE_V1,
            "error": f"unknown session_id {session_id!r}",
            "done": True, "halt_reason": "unknown_session",
        }
    if state.converged or state.halt_reason:
        return {
            "schema_version": SCHEMA_VERSION_ITERATE_CONTINUE_V1,
            "session_id": session_id,
            "done": True,
            "halt_reason": state.halt_reason or "already_converged",
            "score": state.last_score,
            "turn": state.turn,
            "note": "session already terminated",
        }

    output = Path(state.output)
    package = state.package
    language: Language = state.language  # type: ignore[assignment]
    pkg_root = output / pkg_root_for(language, package)

    files = parse_files_from_response(response or "")
    files_written: list[str] = []
    parse_error: str | None = None
    if not files:
        # Agent's response didn't yield any files — this is a real
        # signal worth surfacing, not a silent zero. The next turn's
        # prompt will request a clean retry.
        parse_error = (
            "Agent response did not parse as a JSON array of "
            "{path, content} objects. Re-emit as `[{...}, {...}]` only."
        )
    else:
        files_written = _write_files(output, files, language=language)

    # Run wire + certify on the resulting tree.
    wire_report = scan_violations(pkg_root) if pkg_root.exists() else {
        "verdict": "ERROR", "violation_count": 0, "violations": [],
        "note": "package directory missing",
    }
    try:
        cert = _certify(output, project=package, package=package)
    except Exception as exc:  # noqa: BLE001 — certify must not crash the loop
        cert = {
            "score": 0.0,
            "issues": [f"certify raised: {type(exc).__name__}: {exc}"],
            "schema_version": "atomadic-forge.certify/v1",
        }
    score = float(cert.get("score", 0.0))
    wire_pass = wire_report.get("verdict") == "PASS"

    # Update state.
    state.turn += 1
    state.last_wire = wire_report
    state.last_certify = cert
    state.last_score = score
    state.files_written_total += len(files_written)
    state.transcript.append({
        "turn": state.turn,
        "files_written": len(files_written),
        "wire_verdict": wire_report.get("verdict"),
        "score": score,
        "parse_error": parse_error,
    })

    # Termination decisions.
    converged = wire_pass and score >= state.target_score
    if converged:
        state.converged = True
        state.halt_reason = "converged"
        store.save(state)
        return {
            "schema_version": SCHEMA_VERSION_ITERATE_CONTINUE_V1,
            "session_id": session_id,
            "done": True,
            "halt_reason": "converged",
            "score": score,
            "wire_verdict": wire_report.get("verdict"),
            "turn": state.turn,
            "files_written_this_turn": files_written,
            "files_written_total": state.files_written_total,
            "parse_error": parse_error,
        }
    if state.turn >= state.max_iterations:
        state.halt_reason = "max_iterations"
        store.save(state)
        return {
            "schema_version": SCHEMA_VERSION_ITERATE_CONTINUE_V1,
            "session_id": session_id,
            "done": True,
            "halt_reason": "max_iterations",
            "score": score,
            "wire_verdict": wire_report.get("verdict"),
            "turn": state.turn,
            "files_written_this_turn": files_written,
            "files_written_total": state.files_written_total,
            "parse_error": parse_error,
        }

    # Continue — build the next-turn feedback prompt.
    next_prompt = pack_feedback(
        wire_report=wire_report,
        certify_report=cert,
        iteration=state.turn,
    )
    if parse_error:
        next_prompt = (
            "# Parse error from previous turn\n\n"
            + parse_error + "\n\n"
            + next_prompt
        )

    store.save(state)
    return {
        "schema_version": SCHEMA_VERSION_ITERATE_CONTINUE_V1,
        "session_id": session_id,
        "done": False,
        "next_prompt": next_prompt,
        "score": score,
        "wire_verdict": wire_report.get("verdict"),
        "turn": state.turn,
        "max_iterations": state.max_iterations,
        "files_written_this_turn": files_written,
        "files_written_total": state.files_written_total,
        "parse_error": parse_error,
    }
