"""Tier a3 — canonical surface artifact emitter.

The single-source-of-truth artifact for everything Forge exposes. One
function, one output shape; consumers (the website, the badge, the
CLI's own ``forge surface`` verb, the cognition worker) read this
instead of maintaining their own copy of the tool list.

Why this exists: every new tool used to require touching
``mcp_protocol.py`` (TOOLS dict), ``schema_version_registry.py``,
``cli.py`` (verb registration), ``docs/02-commands.md``, ``README.md``,
the website JSX, and the badge worker's hardcoded map. Drift was
inevitable — see the v0.11.0/v0.11.1 ``__init__.py`` lag for
exhibit A. Now there's one canonical artifact, and every consumer
projects from it.

The artifact is content-addressed: the same TOOLS / registry inputs
always produce byte-identical JSON when ``sort_keys=True`` is used at
serialization time. CI uses that property to fail PRs that change
``mcp_protocol.py`` without regenerating ``surface.json``.
"""
from __future__ import annotations

from datetime import datetime, timezone
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as pkg_version
from typing import Any

from ..a0_qk_constants.schema_version_registry import SCHEMA_VERSIONS
from ..a1_at_functions.mcp_protocol import TOOLS
from ..a1_at_functions.recipes import _RECIPES, list_recipes

SCHEMA_VERSION_SURFACE_V1 = "atomadic-forge.surface/v1"


# ── Legacy endpoint → tool mapping ───────────────────────────────────
# Surfaced for cognition_worker.js + any other consumer that holds a
# hardcoded ``FORGE_LEGACY_ENDPOINT_TO_MCP`` map. Add entries here when
# a tool is renamed or merged so downstream consumers can derive the
# redirect from the surface artifact instead of their own constants.
LEGACY_ENDPOINT_MAP: dict[str, str] = {
    # v0.10.0 surface mergers — old name → new tool that handles it.
    # v0.36.0: lineage absorbed into explore(action='lineage')
    "audit_list":            "explore",
    "why_did_this_change":   "explore",
    "what_failed_last_time": "explore",
    # list_recipes+get_recipe → workflow → context_pack(v0.37.0) → plan(v0.43.0)
    "list_recipes":          "plan",
    "get_recipe":            "plan",
    "auto_plan":             "plan",
    "adapt_plan":            "plan",
    "auto_step":             "plan",
    "auto_apply":            "plan",
    "plan_apply":            "plan",
    # worktree_status+exported_api_check → verify → audit(v0.40.0)
    "worktree_status":       "audit",
    "exported_api_check":    "audit",
    # v0.30.0 mergers (call_graph/smell_scan → code_intel → explore v0.36.0)
    "call_graph":            "explore",
    "smell_scan":            "explore",
    "preflight_change":      "audit",
    "score_patch":           "audit",
    # forge_locate+commit_compose → forge_util → plan(v0.37.0)
    "forge_locate":          "plan",
    "commit_compose":        "plan",
    # v0.31.0 mergers (change_review chain: rollback_plan+manifest_diff → change_review → preflight → audit v0.42.0)
    "rollback_plan":         "audit",
    "manifest_diff":         "audit",
    # sidecar_validate+guard_install → maintain → audit v0.36.0
    "sidecar_validate":      "audit",
    "guard_install":         "audit",
    # compose_tools+load_policy → workflow → context_pack(v0.37.0) → plan(v0.43.0)
    "compose_tools":         "plan",
    "load_policy":           "plan",
    # harvest→discover→explore(v0.41.0)
    "harvest":               "explore",
    "synergy_scan":          "explore",
    # v0.32.0 mergers
    "recon":                 "explore",
    "explain_repo":          "explore",
    "certify":               "audit",
    "wire":                  "audit",
    "select_tests":          "audit",
    # v0.33.0 mergers
    "hive_agent":            "hive",
    "hive_consensus":        "hive",
    # iterate+evolve → loop → plan(v0.39.0) → loop(v0.48.0 restored standalone)
    "iterate":               "loop",
    "evolve":                "loop",
    # handoff+enhancement → session → hive(v0.38.0)
    "handoff":               "hive",
    "enhancement":           "hive",
    "cna_check":             "audit",
    # v0.34.0 mergers
    # recipes → workflow → context_pack(v0.37.0) → plan(v0.43.0)
    "recipes":               "plan",
    # trust_gate_response+doctor → verify → audit(v0.40.0)
    "trust_gate_response":   "audit",
    # v0.35.0 mergers
    "enforce":               "audit",
    "doctor":                "audit",
    "change_review":         "audit",
    # v0.36.0 mergers
    "code_intel":            "explore",
    "lineage":               "explore",
    "emergent":              "explore",
    "emergent_scan":         "explore",
    "emergent_swarm":        "explore",
    "maintain":              "audit",
    # v0.37.0 mergers
    "forge_util":            "plan",
    "workflow":              "plan",
    # v0.38.0 mergers
    "session":               "hive",
    # v0.39.0 mergers; v0.48.0: transmute/loop split back out of plan
    # ('transmute' and 'loop' are NOT redirect entries — they're live
    # standalone tools again. Identity entries would violate the
    # "legacy keys must not collide with live tools" invariant.)
    "auto":                  "transmute",
    "cherry":                "transmute",
    "finalize":              "transmute",
    # v0.40.0 mergers
    "verify":                "audit",
    # v0.41.0 mergers
    "discover":              "explore",
    "synergy":               "explore",
    "tool_factory":          "plan",
    # v0.42.0 mergers
    "preflight":             "audit",
    # v0.43.0 mergers
    "context_pack":          "plan",
    # v0.44.0 mergers (wisdom restored standalone v0.46.0)
    # v0.45.0 mergers (nexus restored standalone v0.46.0)
}


def _safe_pkg_version() -> str:
    """Return the installed package version, or a dev-tag if not installed."""
    try:
        return pkg_version("atomadic-forge")
    except PackageNotFoundError:
        return "0.0.0+dev"


def _render_tool_entry(name: str, info: dict[str, Any]) -> dict[str, Any]:
    """Project one TOOLS dict entry into the surface artifact shape."""
    schema = SCHEMA_VERSIONS.get(name)
    return {
        "name": name,
        "schema_version": schema,
        "description": info.get("description", ""),
        "input_schema": info.get("inputSchema", {}),
        # Handler reference is captured by qualname so the surface stays
        # JSON-serializable. Consumers don't import it; they just need
        # to know which Python symbol lives behind the tool.
        "handler_qualname": _qualname_of(info.get("handler")),
    }


def _qualname_of(handler: Any) -> str | None:
    """Best-effort qualname for an MCP handler callable."""
    if handler is None:
        return None
    mod = getattr(handler, "__module__", "")
    qual = getattr(handler, "__qualname__", "")
    if mod and qual:
        return f"{mod}.{qual}"
    return None


def _render_recipe_entry(name: str) -> dict[str, Any]:
    """Project one recipe into the surface artifact shape."""
    body = _RECIPES.get(name) or {}
    return {
        "name": name,
        "schema_version": body.get("schema_version", SCHEMA_VERSIONS.get("recipes")),
        "description": body.get("description", ""),
        "checklist_steps": len(body.get("checklist", [])),
        "validation_gate_steps": len(body.get("validation_gate", [])),
    }


def export_surface() -> dict[str, Any]:
    """Emit the canonical Forge surface artifact.

    Returns:
        Dict with ``schema_version``, ``package_version``,
        ``generated_at``, ``tools``, ``tools_count``, ``recipes``,
        ``recipes_count``, ``legacy_endpoint_map``,
        ``redaction_hooks`` (reserved for Phase 3 suggest endpoint).
    """
    tool_names = sorted(TOOLS.keys())
    recipe_names = sorted(list_recipes())

    return {
        "schema_version": SCHEMA_VERSION_SURFACE_V1,
        "package_version": _safe_pkg_version(),
        "generated_at_utc": datetime.now(timezone.utc)
            .replace(microsecond=0).isoformat(),
        "tools_count": len(tool_names),
        "recipes_count": len(recipe_names),
        "tools": [_render_tool_entry(n, TOOLS[n]) for n in tool_names],
        "recipes": [_render_recipe_entry(n) for n in recipe_names],
        # Cognition / website / badge worker can derive their redirect
        # tables from this instead of hardcoding constants.
        "legacy_endpoint_map": dict(sorted(LEGACY_ENDPOINT_MAP.items())),
        # Reserved slot for Phase 3 (suggest endpoint). Empty list now;
        # populated when ip_boundary_guard's findForbiddenTerms-style
        # redactors are formalized.
        "redaction_hooks": [],
        # Schema-version registry as a flat map — agents reading the
        # artifact can answer "what's the canonical schema_version for
        # tool X?" without a separate fetch.
        "schema_version_registry": dict(sorted(SCHEMA_VERSIONS.items())),
    }


def diff_surfaces(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    """Compute the public delta between two surface artifacts.

    Used by the auto-CHANGELOG generator and by the
    ``forge.atomadic.tech/surface/diff?from=&to=`` Worker endpoint.
    """
    before_tools = {t["name"]: t for t in before.get("tools", [])}
    after_tools = {t["name"]: t for t in after.get("tools", [])}
    added = sorted(set(after_tools) - set(before_tools))
    removed = sorted(set(before_tools) - set(after_tools))
    schema_changed = sorted(
        n for n in (set(after_tools) & set(before_tools))
        if before_tools[n].get("schema_version")
            != after_tools[n].get("schema_version")
    )
    return {
        "schema_version": "atomadic-forge.surface_diff/v1",
        "from_version": before.get("package_version"),
        "to_version":   after.get("package_version"),
        "tools_added":   added,
        "tools_removed": removed,
        "tools_with_schema_change": schema_changed,
        "recipes_added": sorted(
            {r["name"] for r in after.get("recipes", [])}
            - {r["name"] for r in before.get("recipes", [])}
        ),
        "recipes_removed": sorted(
            {r["name"] for r in before.get("recipes", [])}
            - {r["name"] for r in after.get("recipes", [])}
        ),
    }


__all__ = [
    "SCHEMA_VERSION_SURFACE_V1",
    "LEGACY_ENDPOINT_MAP",
    "export_surface",
    "diff_surfaces",
]
