"""Tier a3 - dedup engine. Walks research notes AND code modules,
groups duplicates, emits a ConsolidationReport that drives:

  * 'this research note restates known capability X' -> auto-archive
  * 'this code module is byte-stable equivalent of existing Y' -> reject
  * 'this proposal is novel' -> accept and route to synthesis

The "never reinvent the wheel" engine.  Composes existing primitives
exclusively:

  a1 intent_similarity         (token Jaccard + difflib ratio)
  a1 research_note_distiller   (extract title + thesis + identifiers)
  a1 code_signature            (AST semantic fingerprint)
  a2 cross_agent_intent_deduplicator  (sliding-window scorer)

Produces no new primitives; orchestrates the four above to cover
both research-note dedup and code-logic dedup with a single entry
point.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from ..a1_at_functions import intent_similarity
from ..a1_at_functions.code_signature import signature_of

SCHEMA: str = "atomadic-forge.dedup-engine/v1"


@dataclass(frozen=True)
class ResearchDupGroup:
    canonical: str        # path of the note kept as canonical
    duplicates: tuple[str, ...]
    reason: str           # similarity score + matched tokens


@dataclass(frozen=True)
class CodeDupGroup:
    module_hash: str
    canonical: str        # path of the module kept as canonical
    duplicates: tuple[str, ...]
    reason: str


@dataclass(frozen=True)
class NovelCandidate:
    path: str             # research note or code file
    kind: str             # "research" | "code"
    identifiers: tuple[str, ...]


@dataclass(frozen=True)
class ConsolidationReport:
    schema: str = SCHEMA
    research_groups: tuple[ResearchDupGroup, ...] = field(default_factory=tuple)
    code_groups: tuple[CodeDupGroup, ...] = field(default_factory=tuple)
    novel: tuple[NovelCandidate, ...] = field(default_factory=tuple)
    files_scanned: int = 0


# ────────────────────────── research dedup ─────────────────────────

def _read_md_dir(d: Path) -> list[tuple[Path, str]]:
    out: list[tuple[Path, str]] = []
    if not d.exists():
        return out
    for p in sorted(d.glob("*.md")):
        try:
            out.append((p, p.read_text(encoding="utf-8",
                                          errors="replace")))
        except OSError:
            continue
    return out


def dedup_research_notes(inbox: Path,
                           *, threshold: float = 0.72,
                           ) -> tuple[list[ResearchDupGroup], list[Path], int]:
    """Compose research_note_distiller + intent_similarity to group
    near-duplicate notes by (title + thesis) similarity. Returns
    ``(duplicate_groups, novel_paths, files_walked)``.

    The ``files_walked`` count was added so :func:`run_dedup` can avoid
    a second filesystem walk just to populate ``files_scanned``. On
    large corpora that double-walk doubled I/O AND silently ignored
    ``max_files`` truncation in :func:`dedup_code_tree`."""
    notes = _read_md_dir(inbox)
    # Build per-note canonical text using title + thesis if present.
    canonical_texts: list[str] = []
    for _, content in notes:
        # Use first H1 + first **Thesis:** line as the dedup key.
        title = ""
        thesis = ""
        for line in content.splitlines():
            line = line.strip()
            if not title and line.startswith("# "):
                title = line[2:].strip()
            if not thesis and line.lower().startswith("**thesis:**"):
                thesis = line.split(":", 1)[1].strip(" *")
            if title and thesis:
                break
        canonical_texts.append((title + " " + thesis).strip()
                                or content[:200])

    # Group: index i is a dup of j if similarity(canonical[i], canonical[j])
    # >= threshold and j < i. The first-seen wins canonical status.
    groups: dict[int, list[int]] = defaultdict(list)
    canonical_of: dict[int, int] = {}
    for i, text_i in enumerate(canonical_texts):
        merged = False
        for canon_i, members in groups.items():
            r = intent_similarity.similarity(text_i,
                                              canonical_texts[canon_i])
            if r.score >= threshold:
                members.append(i)
                canonical_of[i] = canon_i
                merged = True
                break
        if not merged:
            groups[i] = [i]
            canonical_of[i] = i

    dup_groups: list[ResearchDupGroup] = []
    novel_paths: list[Path] = []
    for canon_i, members in groups.items():
        canon_path, _ = notes[canon_i]
        if len(members) == 1:
            novel_paths.append(canon_path)
        else:
            dup_paths = [str(notes[m][0]) for m in members if m != canon_i]
            dup_groups.append(ResearchDupGroup(
                canonical=str(canon_path),
                duplicates=tuple(dup_paths),
                reason=f"sim>={threshold} on title+thesis",
            ))
    return dup_groups, novel_paths, len(notes)


# ────────────────────────── code dedup ─────────────────────────────

DEDUP_MAX_FILES = 5000
DEDUP_MAX_DUPLICATES_PER_GROUP = 64


def dedup_code_tree(root: Path,
                      *, skip_parts: tuple[str, ...] = ("foreign",
                                                          "__pycache__",
                                                          ".pytest_cache"),
                      max_files: int = DEDUP_MAX_FILES,
                      max_duplicates_per_group: int = DEDUP_MAX_DUPLICATES_PER_GROUP,
                      ) -> tuple[list[CodeDupGroup], list[Path], int]:
    """Compose code_signature over a Python source tree. Groups
    modules by module_hash; reports any group of size > 1 as a
    duplicate. Returns ``(duplicate_groups, novel_paths, files_walked)``.

    ``files_walked`` reflects what THIS function actually inspected
    (skip-parts filtered, ``__`` files filtered, capped at ``max_files``).
    :func:`run_dedup` uses this number directly so its ``files_scanned``
    field stays consistent with the truncation marker — the previous
    implementation double-walked via a fresh ``rglob`` and reported the
    full count even when the cap had fired.

    FORGE_DELUXE_EXPERIENCE.md §M-1: the worker-side dedup MCP tool
    crashed (``MCP error -32000: Connection closed``) on an 821-file
    cross-package corpus where many sibling files hashed to the same
    module_hash bucket. The most likely cause is JSON-RPC payload size
    and/or memory blow-up when ``duplicates`` tuples contain hundreds
    of paths.

    Two defensive caps to prevent the same failure on the Python
    implementation:

    - ``max_files`` (default 5000): bound the corpus walk. When a
      single tree has more than this many .py files, dedup stops
      reading at the cap and emits a CodeDupGroup with reason
      ``"max_files cap reached"`` so callers know to scope down.
    - ``max_duplicates_per_group`` (default 64): cap each group's
      ``duplicates`` tuple. Beyond this, the canonical + first N
      duplicates are returned and the reason is annotated with the
      true total count.

    Both caps are passable so callers running on small corpora can
    raise them; the defaults exist to keep MCP responses below
    Cloudflare Worker's 1 MB JSON-RPC ceiling.
    """
    by_hash: dict[str, list[Path]] = defaultdict(list)
    files_seen = 0
    truncated_at_cap = False
    for p in sorted(root.rglob("*.py")):
        if files_seen >= max_files:
            truncated_at_cap = True
            break
        if any(part in skip_parts for part in p.parts):
            continue
        if p.name.startswith("__"):
            continue
        try:
            sig = signature_of(p.read_text(encoding="utf-8",
                                             errors="replace"))
        except OSError:
            continue
        files_seen += 1
        if sig.parse_ok and (sig.functions or sig.classes):
            by_hash[sig.module_hash].append(p)

    dup_groups: list[CodeDupGroup] = []
    novel_paths: list[Path] = []
    for h, paths in by_hash.items():
        if len(paths) == 1:
            novel_paths.append(paths[0])
        else:
            canon = paths[0]
            full_total = len(paths) - 1  # exclude canonical
            keep = paths[1:1 + max_duplicates_per_group]
            dups = [str(p) for p in keep]
            reason = f"identical AST shape hash ({len(paths)} modules)"
            if full_total > len(keep):
                reason += f"; truncated to {len(keep)} of {full_total} duplicates per group cap"
            dup_groups.append(CodeDupGroup(
                module_hash=h,
                canonical=str(canon),
                duplicates=tuple(dups),
                reason=reason,
            ))
    if truncated_at_cap:
        dup_groups.append(CodeDupGroup(
            module_hash="__truncated__",
            canonical=str(root),
            duplicates=(),
            reason=f"max_files cap reached at {max_files} files; rerun with a narrower root or higher cap",
        ))
    return dup_groups, novel_paths, files_seen


# ────────────────────────── orchestrator ───────────────────────────

def run_dedup(*,
                research_inboxes: tuple[Path, ...] = (),
                code_roots: tuple[Path, ...] = (),
                research_threshold: float = 0.72,
                ) -> ConsolidationReport:
    """Top-level entry. Walks each research-inbox dir and code-tree
    root, returns one consolidated report."""
    all_research_groups: list[ResearchDupGroup] = []
    all_code_groups: list[CodeDupGroup] = []
    novel: list[NovelCandidate] = []
    files_scanned = 0

    for inbox in research_inboxes:
        groups, novels, walked = dedup_research_notes(
            inbox, threshold=research_threshold)
        all_research_groups.extend(groups)
        files_scanned += walked
        for p in novels:
            novel.append(NovelCandidate(
                path=str(p), kind="research", identifiers=()))

    for root in code_roots:
        groups, novels, walked = dedup_code_tree(root)
        all_code_groups.extend(groups)
        files_scanned += walked
        for p in novels:
            try:
                sig = signature_of(p.read_text(encoding="utf-8",
                                                 errors="replace"))
                idents = tuple(f.name for f in sig.functions[:8])
            except OSError:
                idents = ()
            novel.append(NovelCandidate(
                path=str(p), kind="code", identifiers=idents))

    return ConsolidationReport(
        research_groups=tuple(all_research_groups),
        code_groups=tuple(all_code_groups),
        novel=tuple(novel),
        files_scanned=files_scanned,
    )
