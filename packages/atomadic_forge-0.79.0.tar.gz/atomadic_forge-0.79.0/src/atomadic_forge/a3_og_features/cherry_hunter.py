"""Tier a3 — cross-repo cherry-hunter (Round 4).

The novel capability: given a target repo and N source repos, surface
features the target lacks but a source has, ranked by trust-gated
confidence. Plus surface emergent compositions visible only across the
union — the kind of finding the atomadic-lang stress test made vivid
(25 cross-domain pipelines top score 75/100 visible only when 5
repos were merged into one tree).

Architecture:

  * ``recon_swarm(repos)`` — walk N repos with the existing
    ``harvest_repo`` scout, return a unified scout report whose
    ``symbols`` field carries an ``origin_repo`` annotation per
    symbol so cross-repo provenance never gets lost.

  * ``harvest(target, sources)`` — diff target's symbol set
    against the union, propose graft candidates, rank by combined
    confidence, mark each as ``trust_gated_pass`` (≥ TAU_TRUST) or
    ``review_required`` (< TAU_TRUST).

Hard caps from system invariants:
  * Number of repos in a swarm walk is capped at ``D_MAX_DELEGATION = 23``.
    This is the system's maximum delegation depth; deeper recursion is
    refused, not silently truncated.
  * Confidence threshold for auto-applyable cherry picks is
    ``TAU_TRUST = trust threshold ≈ 0.99835``. Below it the candidate is
    flagged for human review.
  * Every report's `omega_residue` field is computed against
    ``OMEGA_0 = 0`` to surface unaccounted-for symbols (a non-zero
    residue means the swarm walk missed something).

This module composes existing a1 helpers (``harvest_repo``,
``classify_tier``) and a0 constants (``D_MAX_DELEGATION``,
``TAU_TRUST``, ``OMEGA_0``). No LLM is invoked — this is pure
analytical certainty between agent turns.
"""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Any

from ..a0_qk_constants.mhed_invariants import (
    D_MAX_DELEGATION,
    OMEGA_0,
    TAU_TRUST_FLOAT,
)
from ..a1_at_functions.scout_walk import harvest_repo
from ..a2_mo_composites.remote_seed_store import hydrate_seed_repos

SCHEMA_VERSION_RECON_SWARM_V1 = "atomadic-forge.recon_swarm/v1"
SCHEMA_VERSION_HARVEST_V1 = "atomadic-forge.harvest/v1"


def recon_swarm(
    repos: list[Path | str],
    *,
    hydrate: bool = True,
    cache_root: Path | None = None,
) -> dict[str, Any]:
    """Walk N repos, return a unified scout report with origin annotations.

    The ``D_MAX_DELEGATION`` cap (corpus: ``= 23``) hard-bounds
    the swarm size. Asking for more repos than this is refused — not
    silently truncated — because the corpus says no analytical
    operation should recurse beyond depth 23 and the swarm walk is
    exactly such a recursion.

    The returned ``omega_residue`` is the difference between the
    swarm's symbol count and the sum of per-repo symbol counts. By
    construction it should be zero (we just concatenate). A non-zero
    residue means a per-repo scout failed mid-walk — fail-loud.
    """
    if hydrate:
        repos, seed_hydration = hydrate_seed_repos(
            list(repos),
            cache_root=cache_root or Path.cwd() / ".atomadic-forge" / "seed_repos",
        )
    else:
        repos = [Path(r).resolve() for r in repos]
        seed_hydration = []
    if len(repos) > D_MAX_DELEGATION:
        raise ValueError(
            f"recon_swarm: requested {len(repos)} repos exceeds the system "
            f"delegation depth cap of {D_MAX_DELEGATION}. Recursion deeper "
            f"than {D_MAX_DELEGATION} is forbidden by a system invariant. "
            f"Split the swarm into multiple <={D_MAX_DELEGATION}-repo passes "
            "and combine the reports manually."
        )

    per_repo: list[dict[str, Any]] = []
    union_symbols: list[dict[str, Any]] = []
    union_tier_dist: dict[str, int] = defaultdict(int)
    total_symbol_count_summed = 0

    for repo in repos:
        if not repo.exists():
            per_repo.append({
                "repo": str(repo), "exists": False,
                "symbol_count": 0, "tier_distribution": {},
                "error": "path does not exist",
            })
            continue
        scout = harvest_repo(repo)
        repo_summary = {
            "repo": str(repo),
            "exists": True,
            "symbol_count": int(scout.get("symbol_count", 0)),
            "tier_distribution": dict(scout.get("tier_distribution", {})),
        }
        per_repo.append(repo_summary)
        total_symbol_count_summed += repo_summary["symbol_count"]
        for tier, count in repo_summary["tier_distribution"].items():
            union_tier_dist[tier] += count
        for sym in scout.get("symbols", []):
            sym_tagged = dict(sym)
            sym_tagged["origin_repo"] = str(repo)
            union_symbols.append(sym_tagged)

    union_count = len(union_symbols)
    omega_residue = union_count - total_symbol_count_summed
    # By construction this should be zero (we just concatenated). If
    # ever non-zero, surface it loudly — it means a per-repo walk
    # corrupted state.
    omega_invariant_holds = (omega_residue == 0)

    return {
        "schema_version": SCHEMA_VERSION_RECON_SWARM_V1,
        "repo_count": len(repos),
        "d_max_cap": D_MAX_DELEGATION,
        "per_repo": per_repo,
        "union_symbol_count": union_count,
        "union_tier_distribution": dict(union_tier_dist),
        "omega_residue": omega_residue,
        "omega_invariant_holds": omega_invariant_holds,
        "omega_anchor": OMEGA_0,  # 0 — the corpus no-noise-floor
        "seed_hydration": seed_hydration,
        "symbols": union_symbols,
    }


def harvest(target: Path | str, sources: list[Path | str]) -> dict[str, Any]:
    """Find capabilities the target lacks but sources have.

    Round-4 cross-repo cherry-hunter — renamed from ``cherry_hunt`` to
    ``harvest`` to avoid the public-SEO collision with Git's commit-
    cherry-pick (research breakthrough 2026-05-04). The internal
    module is still named ``cherry_hunter.py`` because that's what the
    operation conceptually IS; the public symbol just doesn't say
    "cherry" so it doesn't drown in Git's noise.

    Returns a list of ``HarvestCandidate`` records:

    * ``qualname`` — symbol the target doesn't have
    * ``source_repo`` — where it lives
    * ``target_tier`` — recommended destination tier in target
    * ``confidence`` — combined confidence (classification × overlap)
    * ``trust_gated`` — boolean: passes ``TAU_TRUST`` threshold?
    * ``rationale`` — short string explaining the proposal

    The verdict per candidate is binary on ``TAU_TRUST``:
    ≥ trust threshold → ``trust_gated=true`` (auto-applyable);
    < trust threshold → ``trust_gated=false`` (review required).

    Hard cap: ``len(sources) ≤ D_MAX_DELEGATION``.
    """
    target = Path(target).resolve()
    sources, seed_hydration = hydrate_seed_repos(
        list(sources),
        cache_root=target / ".atomadic-forge" / "seed_repos",
    )
    if len(sources) > D_MAX_DELEGATION:
        raise ValueError(
            f"harvest: {len(sources)} sources exceeds delegation depth cap "
            f"delegation cap of {D_MAX_DELEGATION}"
        )

    if not target.exists():
        return {
            "schema_version": SCHEMA_VERSION_HARVEST_V1,
            "target": str(target), "exists": False,
            "candidates": [], "trust_gated_count": 0,
            "review_required_count": 0,
            "tau_trust_threshold": TAU_TRUST_FLOAT,
            "error": "target path does not exist",
        }

    target_scout = harvest_repo(target)
    target_qualnames = {
        s.get("qualname", "") for s in target_scout.get("symbols", [])
    }

    # Walk sources via swarm so the delegation depth cap cap and OMEGA_0 invariant
    # check come for free.
    swarm = recon_swarm(sources, hydrate=False)

    # Group source-only symbols by qualname → first source repo seen.
    candidates: list[dict[str, Any]] = []
    seen_qualnames: set[str] = set()
    for sym in swarm.get("symbols", []):
        qual = sym.get("qualname", "")
        if not qual or qual in target_qualnames:
            continue  # target already has this
        if qual in seen_qualnames:
            continue  # we picked the first source for this symbol
        seen_qualnames.add(qual)

        # Confidence model — multiplicative, conservative:
        #   * tier-classification confidence (from the scout's tier_guess
        #     field, defaulting to 0.7 when unknown)
        #   * effects-purity bump: pure functions get +0.1 (lower
        #     side-effect risk in graft)
        #   * complexity penalty: high-complexity symbols are riskier
        base = 0.7
        if sym.get("tier_guess"):
            base = 0.75
        if sym.get("effects") == ["pure"]:
            base = min(0.99, base + 0.10)
        complexity = float(sym.get("complexity", 0))
        if complexity > 1500:
            base *= 0.85  # high-complexity penalty
        confidence = round(base, 4)
        trust_gated = confidence >= TAU_TRUST_FLOAT

        candidates.append({
            "qualname": qual,
            "source_repo": sym.get("origin_repo", ""),
            "target_tier": sym.get("tier_guess", "a3_og_features"),
            "confidence": confidence,
            "trust_gated": trust_gated,
            "effects": sym.get("effects", []),
            "complexity": complexity,
            "rationale": _rationale_for(sym, trust_gated),
        })

    # Sort: trust-gated first, then highest confidence, then qualname.
    candidates.sort(
        key=lambda c: (-int(c["trust_gated"]), -c["confidence"],
                        c["qualname"])
    )

    trust_gated_count = sum(1 for c in candidates if c["trust_gated"])
    review_required_count = len(candidates) - trust_gated_count

    # Surface per-source health so callers can see which sources actually
    # contributed symbols. Closes GAP-014: harvest used to silently return
    # 0 candidates when a source path was missing or had no scout-walkable
    # code, with no signal that anything was wrong. Now every source is
    # accounted for in `per_source` and the offenders are summarised in
    # `source_warnings` for fail-loud diagnostics.
    per_source: list[dict[str, Any]] = []
    source_warnings: list[str] = []
    for entry in swarm.get("per_repo", []):
        repo_path = entry.get("repo", "")
        exists = bool(entry.get("exists", True))
        sym_count = int(entry.get("symbol_count", 0))
        per_source.append({
            "repo": repo_path,
            "exists": exists,
            "symbol_count": sym_count,
            "tier_distribution": entry.get("tier_distribution", {}),
            "error": entry.get("error"),
        })
        if not exists:
            source_warnings.append(
                f"source not found on disk: {repo_path}"
            )
        elif sym_count == 0:
            source_warnings.append(
                f"source walked but produced 0 symbols (no src/<pkg>/ "
                f"layout or unsupported language?): {repo_path}"
            )

    return {
        "schema_version": SCHEMA_VERSION_HARVEST_V1,
        "target": str(target),
        "target_symbol_count": len(target_qualnames),
        "source_repos": [str(s) for s in sources],
        "seed_hydration": seed_hydration,
        "per_source": per_source,
        "source_warnings": source_warnings,
        "candidates": candidates,
        "candidate_count": len(candidates),
        "trust_gated_count": trust_gated_count,
        "review_required_count": review_required_count,
        "tau_trust_threshold": TAU_TRUST_FLOAT,
        "d_max_cap": D_MAX_DELEGATION,
        "omega_residue": swarm["omega_residue"],
        "omega_invariant_holds": swarm["omega_invariant_holds"],
    }


def _rationale_for(sym: dict[str, Any], trust_gated: bool) -> str:
    qual = sym.get("qualname", "?")
    tier = sym.get("tier_guess", "?")
    effects = sym.get("effects", [])
    if trust_gated:
        return (f"`{qual}` is a {tier} symbol with effects {effects} "
                f"that the target lacks; high-confidence graft.")
    return (f"`{qual}` ({tier}, effects {effects}) is missing from "
            "target but confidence is below TAU_TRUST — review the "
            "source implementation before grafting.")
