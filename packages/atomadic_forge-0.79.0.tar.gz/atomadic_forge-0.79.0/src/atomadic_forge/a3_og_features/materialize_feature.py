"""Tier a3 — Materialize: emergent candidates -> shippable Python package.

Closes the loop from ``forge emergent scan`` (which finds novel
compositions) to actual code on disk that pip can install.

Pipeline (entirely deterministic, no LLM):

  1. select N candidates from an EmergentScanReport
  2. scaffold a tier-organized package: src/<pkg>/{a0..a4}/__init__.py
  3. for each candidate, render render_emergent_feature(card) into
     ``src/<pkg>/a3_og_features/<slug>.py``
  4. write pyproject.toml, README.md, .gitignore, tests/conftest.py,
     tests/__init__.py, plus a tiny smoke test per candidate
  5. optionally run wire-check + certify against the new package and
     embed the verdict in the result

The orchestrator owns no logic of its own — every byte of generated
content comes from a1 pure renderers that are already covered by tests.
"""

from __future__ import annotations

import datetime as _dt
import json
from pathlib import Path

from ..a0_qk_constants.emergent_types import (
    EmergentCandidateCard,
    EmergentScanReport,
)
from ..a0_qk_constants.materialize_types import (
    MaterializedFileCard,
    MaterializeReport,
)
from ..a1_at_functions.emergent_synthesize import render_emergent_feature
from ..a1_at_functions.scaffold_pyproject import render_pyproject
from ..a1_at_functions.scaffold_starter import (
    render_changelog,
    render_ci_workflow,
    render_gitignore,
    render_readme,
    render_tests_conftest,
    render_tests_init,
)
from ..a1_at_functions.wire_check import scan_violations

_TIER_DIRS = (
    "a0_qk_constants",
    "a1_at_functions",
    "a2_mo_composites",
    "a3_og_features",
    "a4_sy_orchestration",
)


def _slug(name: str) -> str:
    """kebab-case → snake_case, safe for module names."""
    out = name.replace("-", "_").lower()
    return "".join(ch if (ch.isalnum() or ch == "_") else "_" for ch in out) or "feature"


def _candidate_slug(card: EmergentCandidateCard) -> str:
    """Slug that's unique across candidates by including the id tail."""
    base = _slug(card["name"])
    cid = card["candidate_id"]
    # Use the post-hyphen tail of the id (e.g. "emrg-abc12345" -> "abc12345")
    # so two candidates with the same `name` get distinct module files.
    tail = cid.rsplit("-", 1)[-1] if "-" in cid else cid
    tail = "".join(ch for ch in tail if ch.isalnum())[:8] or "x"
    return f"{base}_{tail}"


def _smoke_test(card: EmergentCandidateCard, pkg: str) -> str:
    """A trivial import-only test for the materialized feature."""
    slug = _candidate_slug(card)
    # The renderer derives its function name from card["name"] alone
    # (no id tail), so the import target uses `_candidate_slug` but the
    # exported symbol uses the bare name slug.
    ident = f"run_{_slug(card['name'])}"
    return (
        f'"""Smoke test for {card["name"]} (id={card["candidate_id"]})."""\n'
        "\n"
        f"def test_{slug}_module_loads():\n"
        f"    from {pkg}.a3_og_features import {slug}_emergent as m\n"
        f"    assert hasattr(m, \"{ident}\"), \"renderer should export {ident}\"\n"
    )


def _write(target: Path, body: str, *, role: str,
           candidate_id: str = "") -> MaterializedFileCard:
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(body, encoding="utf-8")
    return MaterializedFileCard(
        path=str(target.resolve()),
        role=role,
        candidate_id=candidate_id,
        bytes=len(body.encode("utf-8")),
    )


def _select_candidates(
    report: EmergentScanReport,
    *,
    top_n: int,
    candidate_ids: list[str] | None,
) -> list[EmergentCandidateCard]:
    if candidate_ids:
        wanted = set(candidate_ids)
        chosen = [c for c in report["candidates"] if c["candidate_id"] in wanted]
        missing = wanted - {c["candidate_id"] for c in chosen}
        if missing:
            raise KeyError(
                f"candidate_id(s) not in report: {sorted(missing)}"
            )
        return chosen
    if not report["candidates"]:
        return []
    return list(report["candidates"][: max(0, top_n)])


def _ensure_safe_out_dir(out_dir: Path) -> None:
    """Refuse to materialize on top of an existing non-empty, non-Forge dir.

    Generating into a populated unrelated tree is destructive. We allow
    the directory to exist if it's empty OR contains only files we
    previously wrote (detected by the schema marker). Otherwise raise.
    """
    if not out_dir.exists():
        return
    if not out_dir.is_dir():
        raise ValueError(f"out_dir must be a directory: {out_dir}")
    children = [c for c in out_dir.iterdir() if c.name != ".atomadic-forge"]
    if not children:
        return
    marker = out_dir / ".atomadic-forge" / "materialize.json"
    if marker.exists():
        return
    raise ValueError(
        f"out_dir {out_dir} is non-empty and was not previously materialized. "
        "Pick a fresh path or remove the directory."
    )


class Materializer:
    """Turn ranked emergent candidates into a shippable Python package."""

    def __init__(self, *, source_package: str = "atomadic_forge") -> None:
        self.source_package = source_package

    def materialize(
        self,
        report: EmergentScanReport,
        *,
        out_dir: Path,
        package: str,
        top_n: int = 5,
        candidate_ids: list[str] | None = None,
        run_certify: bool = True,
        intent: str = "",
        test_extra_src_roots: list[str] | None = None,
    ) -> MaterializeReport:
        out_dir = Path(out_dir).resolve()
        _ensure_safe_out_dir(out_dir)

        chosen = _select_candidates(
            report, top_n=top_n, candidate_ids=candidate_ids,
        )
        files: list[MaterializedFileCard] = []

        # 1. tier directories with __init__.py (every tier — empty tiers
        #    are still valid, and certify expects the layout).
        for tier in _TIER_DIRS:
            tier_dir = out_dir / "src" / package / tier
            init = tier_dir / "__init__.py"
            files.append(_write(
                init,
                f'"""Tier {tier.split("_")[0]} for {package}."""\n',
                role="init",
            ))
        files.append(_write(
            out_dir / "src" / package / "__init__.py",
            f'"""{package} — generated by atomadic-forge materialize."""\n'
            '__version__ = "0.1.0"\n',
            role="init",
        ))

        # 2. per-candidate emergent feature module + smoke test.
        for card in chosen:
            slug = _candidate_slug(card)
            feature_path = (
                out_dir / "src" / package / "a3_og_features" / f"{slug}_emergent.py"
            )
            files.append(_write(
                feature_path,
                render_emergent_feature(card),
                role="feature",
                candidate_id=card["candidate_id"],
            ))
            test_path = out_dir / "tests" / f"test_{slug}.py"
            files.append(_write(
                test_path,
                _smoke_test(card, package),
                role="test",
                candidate_id=card["candidate_id"],
            ))

        # 3. package scaffold.
        intent_text = intent or (
            f"Materialized from {len(chosen)} emergent candidate(s) "
            f"discovered in {self.source_package}."
        )
        files.append(_write(
            out_dir / "pyproject.toml",
            render_pyproject(
                package=package,
                description=f"Emergent compositions materialized from {self.source_package}",
            ),
            role="scaffold",
        ))
        files.append(_write(
            out_dir / "README.md",
            render_readme(package=package, intent=intent_text),
            role="scaffold",
        ))
        files.append(_write(
            out_dir / ".gitignore",
            render_gitignore(),
            role="scaffold",
        ))
        files.append(_write(
            out_dir / ".github" / "workflows" / "ci.yml",
            render_ci_workflow(package=package),
            role="scaffold",
        ))
        files.append(_write(
            out_dir / "CHANGELOG.md",
            render_changelog(package=package, intent=intent_text),
            role="scaffold",
        ))
        files.append(_write(
            out_dir / "tests" / "__init__.py",
            render_tests_init(),
            role="scaffold",
        ))
        files.append(_write(
            out_dir / "tests" / "conftest.py",
            render_tests_conftest(
                package=package,
                extra_src_roots=test_extra_src_roots or (),
            ),
            role="scaffold",
        ))

        # 4. wire check + certify (best-effort).
        wire_violations: int | None = None
        try:
            wire_result = scan_violations(out_dir / "src" / package)
            wire_violations = len(wire_result.get("violations", []))
        except Exception:  # pragma: no cover — diagnostic, never fatal
            wire_violations = None

        certify_score: float | None = None
        certify_grade: str | None = None
        if run_certify:
            try:
                from ..a1_at_functions.certify_checks import certify
                cert = certify(out_dir, project=package, package=package)
                certify_score = float(cert.get("score") or 0.0)
                certify_grade = (
                    cert.get("health_summary", {}).get("verdict")
                    or _grade_from_score(certify_score)
                )
            except Exception:  # pragma: no cover — diagnostic, never fatal
                certify_score = None
                certify_grade = None

        # 5. drop our marker so future runs can detect prior materialize.
        marker_dir = out_dir / ".atomadic-forge"
        marker_dir.mkdir(parents=True, exist_ok=True)

        report_obj = MaterializeReport(
            schema_version="atomadic-forge.materialize/v1",
            generated_at_utc=_dt.datetime.now(_dt.timezone.utc).strftime(
                "%Y-%m-%dT%H:%M:%SZ",
            ),
            out_dir=str(out_dir),
            package=package,
            candidates_selected=[c["candidate_id"] for c in chosen],
            files_written=files,
            certify_score=certify_score,
            certify_grade=certify_grade,
            wire_violations=wire_violations,
            summary_line=_summary_line(chosen, certify_score, wire_violations,
                                        package),
        )
        (marker_dir / "materialize.json").write_text(
            json.dumps(report_obj, indent=2), encoding="utf-8",
        )
        return report_obj


def _grade_from_score(score: float) -> str:
    if score >= 75:
        return "PASS"
    if score >= 50:
        return "REFINE"
    return "FAIL"


def _summary_line(
    chosen: list[EmergentCandidateCard],
    score: float | None,
    wire_violations: int | None,
    package: str,
) -> str:
    if not chosen:
        return f"materialize: 0 candidates selected — package {package!r} scaffolded empty"
    score_txt = f"{score:.0f}" if score is not None else "n/a"
    wire_txt = f"{wire_violations}" if wire_violations is not None else "n/a"
    return (
        f"materialize: {len(chosen)} candidate(s) -> {package} "
        f"(certify={score_txt}, wire_violations={wire_txt})"
    )


def materialize_from_report_path(
    report_path: Path,
    *,
    out_dir: Path,
    package: str,
    top_n: int = 5,
    candidate_ids: list[str] | None = None,
    run_certify: bool = True,
    source_package: str = "atomadic_forge",
    intent: str = "",
    test_extra_src_roots: list[str] | None = None,
) -> MaterializeReport:
    """Convenience wrapper for the CLI / MCP surface."""
    raw = json.loads(Path(report_path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or "candidates" not in raw:
        raise ValueError(
            f"{report_path} is not a valid emergent scan report"
            " (missing 'candidates' key)"
        )
    return Materializer(source_package=source_package).materialize(
        raw,  # type: ignore[arg-type]
        out_dir=out_dir,
        package=package,
        top_n=top_n,
        candidate_ids=candidate_ids,
        run_certify=run_certify,
        intent=intent,
        test_extra_src_roots=test_extra_src_roots,
    )


__all__ = (
    "Materializer",
    "materialize_from_report_path",
)
