"""Tier a3 — Recipe Replayer: deterministic execution of golden recipes.

Each ``GoldenRecipe`` carries a ``validation_gate`` list of shell
commands that an LLM agent would otherwise reason about and run one
at a time. The replayer just runs them — no LLM round-trip per step
— and reports per-step verdict + token savings.

Token savings basis: each command an LLM would have planned + dispatched
costs ~80 tokens of round-trip overhead (read prior result, decide next
step, emit tool call). Replaying N commands deterministically avoids
N × 80 tokens.
"""
from __future__ import annotations

import subprocess
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from ..a1_at_functions.lifetime_savings import append_savings
from ..a1_at_functions.recipes import get_recipe

SCHEMA_VERSION_REPLAY_V1 = "atomadic-forge.replay/v1"
TOKENS_PER_LLM_DISPATCH = 80


@dataclass
class StepResult:
    command: str
    exit_code: int
    duration_ms: int
    stdout_tail: str
    stderr_tail: str
    skipped: bool = False


@dataclass
class ReplayReport:
    schema_version: str
    recipe_name: str
    project_root: str
    steps: list[StepResult]
    verdict: str  # PASS | FAIL | PARTIAL
    pass_count: int
    fail_count: int
    skipped_count: int
    duration_ms: int
    tokens_saved_estimate: int

    def to_dict(self) -> dict[str, Any]:
        return {**asdict(self),
                 "steps": [asdict(s) for s in self.steps]}


def _tail(text: str, lines: int = 10) -> str:
    if not text:
        return ""
    return "\n".join(text.splitlines()[-lines:])


def replay_recipe(
    *,
    recipe_name: str,
    project_root: Path,
    stop_on_fail: bool = True,
    dry_run: bool = False,
) -> ReplayReport:
    """Replay a golden recipe's ``validation_gate`` deterministically.

    Args:
        recipe_name: name from :func:`recipes.list_recipes`.
        project_root: cwd for the subprocesses.
        stop_on_fail: when True, remaining steps are marked skipped on
            the first non-zero exit. When False, every step runs and
            failures accumulate.
        dry_run: print the plan, mark all steps skipped, don't shell out.

    Raises:
        KeyError: when ``recipe_name`` is not in the catalogue.
    """
    recipe = get_recipe(recipe_name)
    if recipe is None:
        raise KeyError(f"unknown recipe: {recipe_name!r}")

    commands = list(recipe.get("validation_gate") or [])
    project_root = Path(project_root).resolve()

    t0 = time.monotonic()
    steps: list[StepResult] = []
    failed = False
    for cmd in commands:
        if dry_run or (failed and stop_on_fail):
            steps.append(StepResult(
                command=cmd, exit_code=-1, duration_ms=0,
                stdout_tail="", stderr_tail="", skipped=True,
            ))
            continue
        s_t0 = time.monotonic()
        try:
            proc = subprocess.run(  # noqa: S602
                cmd, cwd=project_root, shell=True,
                capture_output=True, text=True, timeout=600,
            )
            steps.append(StepResult(
                command=cmd,
                exit_code=proc.returncode,
                duration_ms=int((time.monotonic() - s_t0) * 1000),
                stdout_tail=_tail(proc.stdout),
                stderr_tail=_tail(proc.stderr),
            ))
            if proc.returncode != 0:
                failed = True
        except (OSError, subprocess.TimeoutExpired) as exc:
            steps.append(StepResult(
                command=cmd, exit_code=-2,
                duration_ms=int((time.monotonic() - s_t0) * 1000),
                stdout_tail="", stderr_tail=str(exc),
            ))
            failed = True

    pass_count = sum(1 for s in steps
                      if not s.skipped and s.exit_code == 0)
    fail_count = sum(1 for s in steps
                      if not s.skipped and s.exit_code != 0)
    skipped_count = sum(1 for s in steps if s.skipped)

    if dry_run:
        verdict = "DRY_RUN"
    elif fail_count == 0 and pass_count > 0:
        verdict = "PASS"
    elif fail_count > 0 and pass_count > 0:
        verdict = "PARTIAL"
    else:
        verdict = "FAIL"

    # Token-savings: every non-skipped command avoided one LLM dispatch.
    tokens_saved = (pass_count + fail_count) * TOKENS_PER_LLM_DISPATCH

    if tokens_saved > 0 and not dry_run:
        append_savings(
            project_root=project_root,
            tool=f"replay/{recipe_name}",
            tokens_saved=tokens_saved,
        )

    return ReplayReport(
        schema_version=SCHEMA_VERSION_REPLAY_V1,
        recipe_name=recipe_name,
        project_root=str(project_root),
        steps=steps,
        verdict=verdict,
        pass_count=pass_count,
        fail_count=fail_count,
        skipped_count=skipped_count,
        duration_ms=int((time.monotonic() - t0) * 1000),
        tokens_saved_estimate=tokens_saved,
    )
