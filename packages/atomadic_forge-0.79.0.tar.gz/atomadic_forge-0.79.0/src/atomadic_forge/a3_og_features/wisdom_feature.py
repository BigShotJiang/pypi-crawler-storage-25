"""Tier a3 — wisdom DB orchestrator (record / query / list / recall).

Composes the a1 pure helpers (``wisdom_io``, ``wisdom_recall``,
``wisdom_capture``) into the public wisdom surface. CLI and MCP both
go through this module so behavior stays aligned across surfaces.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ..a0_qk_constants.wisdom_constants import (
    DEFAULT_RECALL_TOP_N,
    SCHEMA_VERSION_WISDOM_V1,
    WISDOM_SCOPE_REPO,
)
from ..a1_at_functions.wisdom_io import (
    active_wisdom,
    append_wisdom,
    load_wisdom,
    make_entry,
    wisdom_file_path,
)
from ..a1_at_functions.wisdom_promote import (
    DEFAULT_MIN_CORROBORATION,
    synthesize_promotions,
)
from ..a1_at_functions.wisdom_recall import rank_for_recall


def record_wisdom(
    *,
    project_root: Path,
    insight: str,
    scope: str = WISDOM_SCOPE_REPO,
    tags: list[str] | None = None,
    evidence: list[str] | None = None,
    confidence: float = 0.5,
    agent_name: str = "anonymous",
    session_id: str | None = None,
    supersedes: str | None = None,
    trust_signals: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Record one wisdom entry. Returns the stored entry + write path."""
    entry = make_entry(
        insight=insight,
        scope=scope,
        tags=tags,
        evidence=evidence,
        confidence=confidence,
        agent_name=agent_name,
        session_id=session_id,
        supersedes=supersedes,
        trust_signals=trust_signals,
    )
    path = append_wisdom(project_root, entry)
    return {
        "schema_version": SCHEMA_VERSION_WISDOM_V1,
        "recorded": True,
        "entry": entry,
        "wisdom_file": str(path),
    }


def query_wisdom(
    *,
    project_root: Path,
    scope: str | None = None,
    tags: list[str] | None = None,
    text: str | None = None,
    top_n: int = DEFAULT_RECALL_TOP_N,
) -> dict[str, Any]:
    """Relevance-rank active wisdom against a query. Used for CLI + recon hook."""
    entries = active_wisdom(project_root)
    return rank_for_recall(
        entries, scope=scope, tags=tags, text=text, top_n=top_n,
    )


def list_wisdom(
    *,
    project_root: Path,
    include_superseded: bool = False,
) -> dict[str, Any]:
    """Return all wisdom entries (active by default; optionally include superseded)."""
    if include_superseded:
        entries = load_wisdom(project_root)
    else:
        entries = active_wisdom(project_root)
    return {
        "schema_version": SCHEMA_VERSION_WISDOM_V1,
        "wisdom_file": str(wisdom_file_path(project_root)),
        "entry_count": len(entries),
        "entries": entries,
    }


def recall_for_recon(
    *,
    project_root: Path,
    top_n: int = DEFAULT_RECALL_TOP_N,
) -> dict[str, Any]:
    """The recon-hook entry point.

    Cheap, side-effect-free fetch of the top-N wisdom entries scoped to
    this repo. Returns a result even when the DB is empty — empty
    results are safe to inline in any recon caller.
    """
    return query_wisdom(
        project_root=project_root,
        scope=WISDOM_SCOPE_REPO,
        top_n=top_n,
    )


def promote_wisdom(
    *,
    project_root: Path,
    min_corroboration: int = DEFAULT_MIN_CORROBORATION,
    min_tag_overlap: int = 1,
    write_drafts: bool = False,
) -> dict[str, Any]:
    """Cluster active wisdom by tag overlap; render recipe drafts.

    With ``write_drafts=False`` (default) returns the synthesized
    drafts as in-memory dicts. With ``write_drafts=True`` also
    writes each draft to ``_private/research/recipe_drafts/<name>.md``
    so the Research agent can pick up where this leaves off.
    """
    entries = active_wisdom(project_root)
    out = synthesize_promotions(
        entries,
        min_corroboration=min_corroboration,
        min_tag_overlap=min_tag_overlap,
    )
    if write_drafts and out["drafts"]:
        drafts_dir = (
            Path(project_root) / "_private" / "research" / "recipe_drafts"
        )
        drafts_dir.mkdir(parents=True, exist_ok=True)
        written: list[str] = []
        for d in out["drafts"]:
            path = drafts_dir / f"{d['name']}.md"
            path.write_text(d["draft_markdown"], encoding="utf-8")
            written.append(str(path))
        out["written"] = written
        out["drafts_dir"] = str(drafts_dir)
    return out
