"""Tier a3 — forge welcome orchestrator.

Composes scout + certify + wire into one structured handshake response
the agent gets on its first call. This is the "I've got your back"
moment: the agent sees real numbers about the repo it's working in
and the single most useful next action, all derived from data the
scanner just produced.

Optional ``since_receipt`` path: if the caller passes the path to a
prior certify receipt, the response includes a ``diff`` block (score
delta, violations delta, symbol delta) so returning agents see what
changed.
"""
from __future__ import annotations

import itertools
import json
import time
from pathlib import Path
from typing import Any

from .. import __version__
from ..a0_qk_constants.welcome_constants import (
    SCHEMA_VERSION_WELCOME_V1,
    SCOPE_GUARD_DEFAULT_MAX_FILES,
)
from ..a1_at_functions.certify_checks import certify as _certify
from ..a1_at_functions.lifetime_savings import (
    append_savings as _append_savings,
)
from ..a1_at_functions.lifetime_savings import (
    read_savings_summary as _read_savings_summary,
)
from ..a1_at_functions.mcp_protocol import TOOLS as _TOOLS
from ..a1_at_functions.scout_walk import harvest_repo as _scout
from ..a1_at_functions.scout_walk import iter_source_files as _iter_source_files
from ..a1_at_functions.welcome_narrator import (
    build_agent_guidance,
    build_capability_showcase,
    build_narrative,
    detect_priorities,
    detect_strengths,
    health_label_for,
    safety_net_summary,
    suggest_next_call,
)
from ..a1_at_functions.wire_check import scan_violations as _wire


def _load_prior_receipt(path: Path | str | None) -> dict[str, Any] | None:
    if not path:
        return None
    p = Path(path)
    if not p.is_file():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


# Default well-known location agents drop a fresh certify into when
# they pass `--emit-receipt`. The welcome flow auto-discovers this so
# returning agents see a since-last-scan diff without any flag.
_DEFAULT_RECEIPT_RELS: tuple[str, ...] = (
    ".atomadic-forge/certify.json",
    ".atomadic-forge/last_certify.json",
)


def _auto_discover_receipt(project_root: Path) -> Path | None:
    """Find the freshest prior certify receipt at a well-known path.

    Returns None if nothing's there. The caller is expected to use
    this only when ``since_receipt`` was not explicitly passed —
    explicit always wins.
    """
    candidates: list[tuple[float, Path]] = []
    for rel in _DEFAULT_RECEIPT_RELS:
        p = project_root / rel
        if p.is_file():
            try:
                candidates.append((p.stat().st_mtime, p))
            except OSError:
                continue
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][1]


def _diff_against(
    *,
    current_certify: dict[str, Any],
    current_wire: dict[str, Any],
    current_scout: dict[str, Any],
    prior: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Build a since-last-scan diff block, or None if no prior."""
    if not prior:
        return None
    score_now = current_certify.get("score")
    score_prev = prior.get("score")
    return {
        "prior_timestamp": prior.get("timestamp"),
        "prior_score": score_prev,
        "current_score": score_now,
        "score_delta": (
            float(score_now) - float(score_prev)
            if isinstance(score_now, int | float)
            and isinstance(score_prev, int | float)
            else None
        ),
        "current_violations": current_wire.get("violation_count", 0),
        "current_symbol_count": current_scout.get("symbol_count", 0),
    }


def _count_source_files_capped(project_root: Path, *, cap: int) -> int:
    """Cheaply count source files, stopping after ``cap + 1`` matches.

    Pure: just consumes the existing ``iter_source_files`` iterator.
    Returns the count seen; if the count equals ``cap + 1`` the caller
    knows the tree is *at least* that big without walking the rest.
    """
    return sum(1 for _ in itertools.islice(_iter_source_files(project_root), cap + 1))


def welcome(
    *,
    project_root: Path,
    package: str | None = None,
    since_receipt: Path | str | None = None,
    skip_certify: bool = False,
    force: bool = False,
    max_files: int = SCOPE_GUARD_DEFAULT_MAX_FILES,
) -> dict[str, Any]:
    """Run the welcome handshake on ``project_root``.

    ``package`` (optional) — passed to certify for layout checks.
    ``since_receipt`` (optional) — path to a prior certify JSON for
    the diff block.
    ``skip_certify`` (test convenience) — when True, skip the
    expensive certify pass and emit a partial welcome (scout + wire
    only). Production callers should leave this False.
    ``force`` — bypass the scope guard. Use only when you know the
    tree is genuinely the right scope to scan.
    ``max_files`` — scope guard threshold. Default is
    ``SCOPE_GUARD_DEFAULT_MAX_FILES`` (5 000); pass a higher number
    on intentionally-large monorepos.
    """
    project_root = Path(project_root).resolve()
    repo_name = project_root.name

    t0 = time.monotonic()

    # Scope guard — refuse to walk monstrously large trees by accident.
    # Stops as soon as the cap is exceeded; a 38k-file workspace bails
    # in milliseconds instead of grinding through the AST walk.
    if not force:
        seen = _count_source_files_capped(project_root, cap=max_files)
        if seen > max_files:
            return {
                "schema_version": SCHEMA_VERSION_WELCOME_V1,
                "forge_version": __version__,
                "repo_name": repo_name,
                "repo_path": str(project_root),
                "duration_ms": int((time.monotonic() - t0) * 1000),
                "verdict": "REFUSE",
                "reason": "scope_guard",
                "source_file_count_at_least": seen,
                "scope_guard_max_files": max_files,
                "narrative": (
                    f"Scope guard tripped: {project_root} has at least "
                    f"{seen} source files (cap {max_files}). This usually "
                    "means welcome was run from a workspace root rather "
                    "than a single repo. Pass --project-root <narrower-path> "
                    "or --force to override."
                ),
                "available_tools": len(_TOOLS),
            }

    # scout / wire / (optional) certify in sequence — they share I/O
    # against the same tree; concurrency wouldn't help much here
    # because the bottleneck is filesystem walk, not CPU.
    scout_report = _scout(project_root)
    wire_root = project_root / "src"
    if not wire_root.is_dir():
        wire_root = project_root
    wire_report = _wire(wire_root)
    certify_report: dict[str, Any] | None = None
    if not skip_certify:
        try:
            certify_report = _certify(project_root, package=package)
        except Exception as exc:  # noqa: BLE001 — welcome must not crash
            certify_report = {
                "schema_version": "atomadic-forge.certify/v1",
                "score": None,
                "verdict": "ERROR",
                "error": f"{type(exc).__name__}: {exc}",
            }

    strengths = detect_strengths(
        scout=scout_report, certify=certify_report, wire=wire_report,
    )
    priorities = detect_priorities(
        scout=scout_report, certify=certify_report, wire=wire_report,
    )
    next_call = suggest_next_call(
        certify=certify_report, wire=wire_report,
    )

    # Returning-user magic: if no explicit since_receipt was passed,
    # auto-discover the freshest prior certify receipt at a well-known
    # path. Explicit always wins; only auto-discover when caller
    # didn't specify.
    receipt_path = since_receipt
    auto_discovered = False
    if not receipt_path:
        discovered = _auto_discover_receipt(project_root)
        if discovered is not None:
            receipt_path = discovered
            auto_discovered = True
    prior = _load_prior_receipt(receipt_path)
    diff = _diff_against(
        current_certify=certify_report or {},
        current_wire=wire_report,
        current_scout=scout_report,
        prior=prior,
    )
    if diff is not None:
        diff["auto_discovered"] = auto_discovered
        diff["receipt_path"] = str(receipt_path) if receipt_path else None

    # We log + read lifetime savings BEFORE narrative so the narrative
    # can include them.  Append first so this session counts in its own
    # narrative; lifetime then includes this run.
    session_savings_estimate = (
        ((scout_report.get("scope") or {}).get("tokens_saved_estimate", 0) or 0)
        + ((wire_report.get("scope") or {}).get("tokens_saved_estimate", 0) or 0)
        + (((certify_report or {}).get("scope") or {}).get("tokens_saved_estimate", 0) or 0)
    )
    _append_savings(
        project_root=project_root,
        tool="welcome",
        tokens_saved=int(session_savings_estimate),
    )
    lifetime_savings = _read_savings_summary(project_root=project_root)

    narrative = build_narrative(
        repo_name=repo_name,
        scout=scout_report,
        certify=certify_report,
        wire=wire_report,
        strengths=strengths,
        priorities=priorities,
        next_call=next_call,
        forge_version=__version__,
        tool_count=len(_TOOLS),
        diff=diff,
        lifetime_savings=lifetime_savings,
        session_savings=int(session_savings_estimate),
    )
    agent_guidance = build_agent_guidance(
        repo_name=repo_name,
        scout=scout_report,
        certify=certify_report,
        wire=wire_report,
        strengths=strengths,
        priorities=priorities,
    )
    duration_ms = int((time.monotonic() - t0) * 1000)

    return {
        "schema_version": SCHEMA_VERSION_WELCOME_V1,
        "forge_version": __version__,
        "repo_name": repo_name,
        "repo_path": str(project_root),
        "duration_ms": duration_ms,
        "scan": {
            "scout": {
                "primary_language": scout_report.get("primary_language"),
                "symbol_count": scout_report.get("symbol_count", 0),
                "tier_distribution": scout_report.get("tier_distribution") or {},
                "language_distribution": scout_report.get("language_distribution") or {},
            },
            "certify": {
                "score": (certify_report or {}).get("score"),
                # health_summary.verdict for normal runs; top-level verdict for error fallback.
                "verdict": (
                    (certify_report or {}).get("health_summary", {}).get("verdict")
                    or (certify_report or {}).get("verdict")
                ),
                "blockers": (certify_report or {}).get("health_summary", {}).get("blockers", 0),
            } if certify_report else None,
            "wire": {
                "verdict": wire_report.get("verdict"),
                "violation_count": wire_report.get("violation_count", 0),
                "type_only_imports": len(wire_report.get("type_only_imports") or []),
                "dynamic_import_warnings": len(wire_report.get("dynamic_import_warnings") or []),
                "star_import_warnings": len(wire_report.get("star_import_warnings") or []),
            },
        },
        "health_label": health_label_for((certify_report or {}).get("score")),
        "strengths": strengths,
        "priorities": priorities,
        "next_call": next_call,
        "available_tools": len(_TOOLS),
        "narrative": narrative,
        "agent_guidance": agent_guidance,
        "capability_showcase": build_capability_showcase(),
        "safety_net": safety_net_summary(),
        "since_last_scan": diff,
        "session_tokens_saved_estimate": int(session_savings_estimate),
        "lifetime_savings": lifetime_savings,
    }


__all__ = ["welcome"]
