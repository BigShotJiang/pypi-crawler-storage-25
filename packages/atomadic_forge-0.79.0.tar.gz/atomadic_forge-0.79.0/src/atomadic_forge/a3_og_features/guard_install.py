"""Tier a3 — standing guard against architectural regrowth.

The "spaghetti can never come back" tool. Once forge has shipped a
repo at 100/100 certify, agents (or low-quality LLMs, or careless
humans) will try to add code that erodes the architectural integrity.
``guard_install`` writes the four enforcement layers that make that
silently impossible:

  1. **Pre-commit hook** (``.git/hooks/pre-commit``) — runs
     ``forge wire`` + ``forge certify`` (configurable threshold)
     before every local commit. Below threshold → commit aborts
     with a structured error message.

  2. **GitHub Actions workflow** (``.github/workflows/forge-guard.yml``)
     — runs on every push and PR. Same gate as pre-commit, but
     server-side so it's enforceable across teams + can block PR
     merges (when branch protection is on).

  3. **pyproject [tool.forge.guard]** entry — declares the contract:
     ``min_certify_score``, ``max_cyclomatic``, ``protected_files``,
     ``strict_mode``. The other layers read this to know what to
     enforce. Single source of truth.

  4. **CONTRIBUTING.md guard section** — human-readable explanation
     of what the gates do and how to fix common failures.

This module is **CNA-pure**: it composes existing forge primitives
(``wire``, ``certify``, ``cna_check``, ``verify``) into a one-call
installation. The only net-new code is the four template strings +
the writer that drops them into the right paths.

Strategic positioning: with ``guard_install`` run, an MCP-aware agent
adding code through ``iterate_continue`` or ``evolve_step`` cannot
silently regress structural integrity. The pre-commit gate catches
it before the commit lands; the GitHub Action catches it before the
merge. Forge becomes the standing immune system, not just a
one-shot transmuter.
"""
from __future__ import annotations

import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

SCHEMA_VERSION_GUARD_INSTALL_V1 = "atomadic-forge.guard_install/v1"


_PRE_COMMIT_HOOK = """\
#!/usr/bin/env bash
# forge-guard pre-commit hook (installed by `forge guard_install`).
# Ensures the repo never silently regresses below the contracted
# architectural integrity. Composes forge primitives: wire + certify.
#
# To temporarily skip (NOT recommended): `git commit --no-verify`.

set -e

MIN_SCORE="${{FORGE_MIN_CERTIFY:-{min_score}}}"

echo "[forge-guard] running wire + certify..."

if ! python -m atomadic_forge.a4_sy_orchestration.cli wire src --fail-on-violations 2>&1; then
    echo "[forge-guard] WIRE FAIL: upward-import violations introduced." >&2
    echo "[forge-guard] run \\`forge enforce . --apply\\` to auto-fix." >&2
    exit 1
fi

if ! python -m atomadic_forge.a4_sy_orchestration.cli certify . --fail-under "$MIN_SCORE" 2>&1; then
    echo "[forge-guard] CERTIFY FAIL: score below ${{MIN_SCORE}}." >&2
    echo "[forge-guard] run \\`forge certify .\\` for the issue list." >&2
    exit 1
fi

echo "[forge-guard] PASS"
"""


_GITHUB_WORKFLOW = """\
# forge-guard CI workflow (installed by `forge guard_install`).
# Blocks any PR or push that would erode architectural integrity.
# Branch-protect main on this job to make the gate non-overridable.
name: forge-guard

on:
  push:
    branches: [main, master]
  pull_request:
    branches: [main, master]

jobs:
  forge-guard:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - name: Install forge
        run: pip install atomadic-forge
      - name: forge wire (no upward imports)
        run: forge wire src --fail-on-violations
      - name: forge certify (>= {min_score}/100)
        run: forge certify . --fail-under {min_score}
"""


_PYPROJECT_GUARD_BLOCK = """\
[tool.forge.guard]
# forge-guard contract — installed by `forge guard_install`.
# These are the binding architectural commitments for this repo.
# The pre-commit hook + GitHub Action read this to know what to enforce.
min_certify_score = {min_score}
max_cyclomatic = {cc}
protected_files = []     # files that require human review on touch
strict_mode = {strict}      # when true, ANY drop in certify score blocks the commit
"""


_CONTRIBUTING_BLOCK = """\

## Architectural guard (forge-guard)

This repo is guarded by forge-guard, installed via
`forge guard_install`. Two layers protect the architectural integrity:

1. **Pre-commit hook** runs `forge wire` and `forge certify` before
   every local commit. Below the contracted score → commit aborts.
2. **GitHub Actions workflow** runs the same checks on every push
   and PR. Required to merge to main.

The contract lives in `pyproject.toml` under `[tool.forge.guard]`:

- `min_certify_score` — minimum 0-100 score the repo must keep.
- `max_cyclomatic` — maximum cyclomatic complexity for any function.
- `protected_files` — paths that need human review on touch.
- `strict_mode` — when `true`, ANY decrease in certify score is blocked.

If a guard check fails, forge prints the next command to fix the
problem. The most common fix:

```bash
forge enforce . --apply  # auto-fix wire violations
forge certify .          # show the issue list
```

To temporarily bypass (NOT recommended): `git commit --no-verify`.
Bypass is logged and visible in CI; reviewers will see it.
"""


@dataclass
class GuardInstallReport:
    schema_version: str = SCHEMA_VERSION_GUARD_INSTALL_V1
    project_root: str = ""
    files_written: list[str] = field(default_factory=list)
    files_skipped: list[str] = field(default_factory=list)
    files_failed: list[dict[str, str]] = field(default_factory=list)
    contract: dict[str, Any] = field(default_factory=dict)
    next_command: str = ""

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def guard_install(
    *,
    project_root: Path,
    min_certify_score: int = 90,
    max_cyclomatic: int = 10,
    strict_mode: bool = False,
    apply: bool = False,
    overwrite: bool = False,
) -> GuardInstallReport:
    """Install the four-layer architectural guard.

    Args:
        project_root: repo to guard.
        min_certify_score: minimum certify score below which commits
            and PRs are blocked. Default 90 (forge's own bar).
        max_cyclomatic: maximum cyclomatic complexity per function.
            Default 10 (Sonar industry standard).
        strict_mode: when True, ANY drop in certify score (not just
            below threshold) blocks the commit. Default False.
        apply: when False (default), returns the planned writes
            without touching the filesystem. When True, writes the
            four files.
        overwrite: when False (default), skips files that already
            exist. When True, overwrites them.

    Returns:
        :class:`GuardInstallReport` listing files_written /
        files_skipped / files_failed + the binding contract.
    """
    project_root = Path(project_root).resolve()
    if not project_root.exists():
        return GuardInstallReport(
            project_root=str(project_root),
            files_failed=[{"path": str(project_root),
                            "reason": "project_root does not exist"}],
            next_command=("# verify project_root path before retry"),
        )

    contract = {
        "min_certify_score": int(min_certify_score),
        "max_cyclomatic": int(max_cyclomatic),
        "strict_mode": bool(strict_mode),
    }

    artifacts = [
        (
            project_root / ".git" / "hooks" / "pre-commit",
            _PRE_COMMIT_HOOK.format(min_score=min_certify_score),
            True,  # needs +x
        ),
        (
            project_root / ".github" / "workflows" / "forge-guard.yml",
            _GITHUB_WORKFLOW.format(min_score=min_certify_score),
            False,
        ),
        (
            project_root / "pyproject.guard.toml",
            _PYPROJECT_GUARD_BLOCK.format(
                min_score=min_certify_score,
                cc=max_cyclomatic,
                strict=str(bool(strict_mode)).lower(),
            ),
            False,
        ),
        (
            project_root / "CONTRIBUTING.guard.md",
            _CONTRIBUTING_BLOCK,
            False,
        ),
    ]

    files_written: list[str] = []
    files_skipped: list[str] = []
    files_failed: list[dict[str, str]] = []

    for path, content, executable in artifacts:
        rel = str(path.relative_to(project_root))
        if not apply:
            files_written.append(rel)  # planned
            continue
        if path.exists() and not overwrite:
            files_skipped.append(rel)
            continue
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            if executable:
                # 0o755 — owner rwx, group/world rx.
                try:
                    os.chmod(path, 0o755)
                except OSError:
                    pass  # Windows / non-POSIX — best effort.
            files_written.append(rel)
        except OSError as exc:
            files_failed.append({
                "path": rel,
                "reason": f"{type(exc).__name__}: {exc}",
            })

    if apply:
        next_command = (
            "merge the [tool.forge.guard] block from "
            "pyproject.guard.toml into pyproject.toml, then "
            "commit the .git/hooks/pre-commit + "
            ".github/workflows/forge-guard.yml + CONTRIBUTING.guard.md"
        )
    else:
        next_command = (
            "re-run with apply=true to write the four guard files"
        )

    return GuardInstallReport(
        project_root=str(project_root),
        files_written=files_written,
        files_skipped=files_skipped,
        files_failed=files_failed,
        contract=contract,
        next_command=next_command,
    )
