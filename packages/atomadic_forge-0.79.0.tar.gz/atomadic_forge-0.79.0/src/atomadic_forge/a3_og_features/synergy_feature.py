"""Tier a3 — Synergy Scan feature.

One pipeline that wires the a1 surface-extractor + detector + renderer:

    SynergyScan(repo).scan() → SynergyScanReport
    SynergyScan(repo).implement(candidate_id) → wrote commands/<name>.py
"""

from __future__ import annotations

import datetime as _dt
import json
from pathlib import Path

from ..a0_qk_constants.synergy_types import (
    SynergyScanReport,
)
from ..a1_at_functions.synergy_detect import detect_synergies
from ..a1_at_functions.synergy_render import render_synergy_adapter
from ..a1_at_functions.synergy_surface_extract import harvest_multilevel_surfaces


class SynergyScan:
    """Find feature-level synergies across an ASS-ADE-style package."""

    def __init__(self, *, src_root: Path, package: str = "atomadic_forge") -> None:
        self.src_root = Path(src_root)
        self.package = package
        self._features = None  # cached

    @property
    def features(self) -> list:
        if self._features is None:
            self._features = harvest_multilevel_surfaces(self.src_root, self.package)
        return self._features

    def scan(self, *, top_n: int = 25) -> SynergyScanReport:
        import time as _time
        _t0 = _time.monotonic()
        candidates = detect_synergies(self.features)[:top_n]
        base: SynergyScanReport = SynergyScanReport(
            schema_version="atomadic-forge.synergy.scan/v1",
            generated_at_utc=_dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            feature_count=len(self.features),
            candidate_count=len(candidates),
            candidates=candidates,
        )
        from ..a1_at_functions.response_enricher import (
            enrich_response as _enrich,
        )
        from ..a1_at_functions.response_enricher import (
            make_scope as _make_scope,
        )
        from ..a1_at_functions.response_enricher import (
            summarize_synergy as _summarize_synergy,
        )
        duration_ms = int((_time.monotonic() - _t0) * 1000)
        return _enrich(
            dict(base),
            scope=_make_scope(
                symbols_analyzed=len(self.features),
                tiers_traversed=5,
                scan_duration_ms=duration_ms,
                basis_kind="symbols",
            ),
            summary=_summarize_synergy(dict(base)),
            project_root=self.src_root,
            tool="synergy",
        )  # type: ignore[return-value]

    def implement(self, candidate_id: str, report: SynergyScanReport,
                  *, out_dir: Path | None = None) -> Path:
        match = next((c for c in report["candidates"]
                      if c["candidate_id"] == candidate_id), None)
        if match is None:
            raise KeyError(f"candidate {candidate_id} not in report")
        target_dir = out_dir or (self.src_root / self.package / "commands")
        target_dir.mkdir(parents=True, exist_ok=True)
        slug = match["proposed_adapter_name"].replace("-", "_") + ".py"
        target = target_dir / slug
        target.write_text(render_synergy_adapter(match), encoding="utf-8")
        return target

    @staticmethod
    def save_report(report: SynergyScanReport, target: Path) -> Path:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(report, indent=2, default=str),
                          encoding="utf-8")
        return target
