"""Tier a3 — enhancement-proposal orchestrator.

Composes the a1 builder with disk persistence + an OPTIONAL trust-gate
call against the AAAA-Nexus client. Trust-gate failures (auth, network,
unconfigured) degrade to ``OFFLINE`` — the proposal still records, just
without a remote trust score.

Publishing to GitHub is NOT done here. The ``publishable`` flag tells
the CLI / agent that the proposal cleared the trust threshold, but
the actual publish step (``forge enhancement publish <id>``) requires
a separate explicit human approval. This module never posts on its
own.
"""
from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

from ..a0_qk_constants.enhancement_proposal_constants import (
    DEFAULT_TRUST_THRESHOLD,
    PROPOSAL_DIR_REL,
    PROPOSAL_LOG_REL,
    SCHEMA_VERSION_ENHANCEMENT_PROPOSAL_V1,
    TRUST_VERDICT_FAIL,
    TRUST_VERDICT_OFFLINE,
    TRUST_VERDICT_PASS,
)
from ..a1_at_functions.enhancement_proposal_builder import make_proposal


def _proposal_dir(project_root: Path) -> Path:
    return Path(project_root) / PROPOSAL_DIR_REL


def _proposal_log(project_root: Path) -> Path:
    return Path(project_root) / PROPOSAL_LOG_REL


def _default_trust_gate(_payload: dict[str, Any]) -> dict[str, Any]:
    """Default trust-gate stub.

    Real callers can swap in a function that hits AAAA-Nexus
    ``nexus_sys_trust_gate``. The default returns OFFLINE so behavior
    stays predictable when no client is configured.
    """
    return {
        "verdict": TRUST_VERDICT_OFFLINE,
        "trust_score": None,
        "reason": "no trust-gate handler configured",
    }


def submit_proposal(
    *,
    project_root: Path,
    title: str,
    description: str,
    evidence: list[str] | None = None,
    proposer: str = "anonymous",
    trust_threshold: float = DEFAULT_TRUST_THRESHOLD,
    trust_gate: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Build a proposal, optionally gate it, persist it, return the result.

    The proposal is appended to
    ``.atomadic-forge/enhancement_proposals/forge_enhancement_proposals.jsonl``
    AND saved as a standalone ``<proposal_id>.json`` file in the same
    directory for individual lookup.

    The returned dict has:
        ``proposal``     — the proposal entry
        ``proposal_file`` — path to the standalone JSON
        ``log_file``      — path to the JSONL log
        ``submitted``     — True

    Per safety rules, this function does NOT publish anywhere.
    Use ``forge enhancement publish <id>`` (CLI) for publishing,
    which prompts for human approval.
    """
    gate = trust_gate or _default_trust_gate
    try:
        gate_result = gate({
            "kind": "enhancement_proposal",
            "title": title,
            "description": description,
            "evidence": list(evidence or []),
            "proposer": proposer,
        })
    except Exception as exc:  # noqa: BLE001 — trust-gate must not crash submission
        gate_result = {
            "verdict": TRUST_VERDICT_OFFLINE,
            "trust_score": None,
            "reason": f"trust-gate error: {type(exc).__name__}: {exc}",
        }

    verdict = str(gate_result.get("verdict", TRUST_VERDICT_OFFLINE)).upper()
    if verdict not in (TRUST_VERDICT_PASS, TRUST_VERDICT_FAIL, TRUST_VERDICT_OFFLINE):
        verdict = TRUST_VERDICT_OFFLINE
    score = gate_result.get("trust_score")
    if score is not None:
        try:
            score = float(score)
            if not 0.0 <= score <= 1.0:
                score = None
        except (TypeError, ValueError):
            score = None

    proposal = make_proposal(
        title=title,
        description=description,
        evidence=evidence,
        proposer=proposer,
        trust_score=score,
        trust_verdict=verdict,
        trust_threshold=trust_threshold,
    )
    # Carry the gate's reason string forward for the audit trail.
    proposal["trust_reason"] = str(gate_result.get("reason", ""))

    out_dir = _proposal_dir(project_root)
    out_dir.mkdir(parents=True, exist_ok=True)
    proposal_file = out_dir / f"{proposal['proposal_id']}.json"
    proposal_file.write_text(
        json.dumps(proposal, indent=2), encoding="utf-8",
    )

    log_file = _proposal_log(project_root)
    with log_file.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(proposal) + "\n")

    return {
        "schema_version": SCHEMA_VERSION_ENHANCEMENT_PROPOSAL_V1,
        "submitted": True,
        "proposal": proposal,
        "proposal_file": str(proposal_file),
        "log_file": str(log_file),
    }


def list_proposals(
    *,
    project_root: Path,
    limit: int = 50,
) -> dict[str, Any]:
    """Return the proposals currently in the JSONL log, newest first.

    Best-effort: malformed lines are reported under ``skipped`` rather
    than crashing the listing.
    """
    log_file = _proposal_log(project_root)
    entries: list[dict[str, Any]] = []
    skipped: list[int] = []
    if log_file.is_file():
        try:
            for n, line in enumerate(
                log_file.read_text(encoding="utf-8").splitlines(),
                start=1,
            ):
                if not line.strip():
                    continue
                try:
                    entries.append(json.loads(line))
                except ValueError:
                    skipped.append(n)
        except OSError:
            pass
    entries.sort(key=lambda e: e.get("timestamp", ""), reverse=True)
    return {
        "schema_version": SCHEMA_VERSION_ENHANCEMENT_PROPOSAL_V1,
        "log_file": str(log_file),
        "total_count": len(entries),
        "entries": entries[: max(0, int(limit))],
        "skipped_lines": skipped,
    }


def read_proposal(
    *,
    project_root: Path,
    proposal_id: str,
) -> dict[str, Any] | None:
    """Read a single proposal by id; None if not found."""
    out_dir = _proposal_dir(project_root)
    target = out_dir / f"{proposal_id}.json"
    if not target.is_file():
        return None
    try:
        return json.loads(target.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


__all__ = ["list_proposals", "read_proposal", "submit_proposal"]
