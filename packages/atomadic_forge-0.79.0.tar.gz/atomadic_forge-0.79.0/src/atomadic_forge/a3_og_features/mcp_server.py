"""Tier a3 — stdio JSON-RPC loop wrapping the pure MCP dispatcher.

Golden Path Lane C W4 deliverable, with the W5 subscription gate
layered on top. The pure dispatcher lives in
``a1_at_functions.mcp_protocol``; this module owns the I/O concerns:
read a line from stdin, parse it as JSON, hand to dispatch, write the
response to stdout. No SSE / HTTP transport today — that's a future
iteration; stdio is what every coding agent (Cursor, Claude Code,
Aider, Devin) uses on initial connect, so it's the right v0.

The server runs forever until stdin closes (the client disconnects)
or it receives a ``shutdown`` JSON-RPC method (per MCP spec). Errors
in JSON parsing or method dispatch never kill the loop — they're
surfaced as JSON-RPC error responses and the next request is
processed normally.

**Subscription requirement (Lane C W5).** Every ``tools/call`` is
gated behind a paid Forge subscription. The server reads the user's
Forge or Master API key (``fk_live_*`` or ``ak_master_*``) from the
``FORGE_API_KEY`` env variable, asks the remote verify endpoint at
``forge-auth.atomadic.tech`` whether the key is still active, and
caches the answer for 5 minutes.

  * No key / wrong shape / verified-bad     → JSON-RPC error -32001
    with ``message="Forge subscription required"`` and an upgrade URL.
  * Read-only metadata methods (``initialize``, ``ping``,
    ``tools/list``, ``resources/list``, ``notifications/initialized``,
    ``shutdown``) bypass the gate so MCP clients can complete the
    handshake even before the user has logged in. Actual ``tools/call``
    and ``resources/read`` traffic require the gate to be open.

Use ``forge login`` to capture and store a key. See
``a4_sy_orchestration/login_cmd.py`` and ``docs/04-llm-loops.md`` for
the activation flow.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from pathlib import Path as _Path
from typing import IO, Any

from ..a1_at_functions.forge_auth import (
    hash_project_path,
    read_api_key_from_credentials_file,
    read_api_key_from_env,
)
from ..a1_at_functions.mcp_protocol import (
    _json_default,
    dispatch_request,
    register_ast_scope_attest_handler,
    register_auto_apply_handler,
    register_auto_handler,
    register_auto_plan_handler,
    register_auto_step_handler,
    register_cherry_handler,
    register_cna_check_handler,
    register_commit_compose_handler,
    register_create_handler,
    register_emergent_scan_handler,
    register_emergent_swarm_handler,
    register_enforce_handler,
    register_enhancement_list_handler,
    register_enhancement_propose_handler,
    register_evolve_start_handler,
    register_evolve_step_handler,
    register_finalize_handler,
    register_guard_install_handler,
    register_handoff_create_handler,
    register_handoff_list_handler,
    register_harvest_handler,
    register_hive_deactivate_handler,
    register_hive_list_handler,
    register_hive_needs_vote_handler,
    register_hive_observe_handler,
    register_hive_propose_handler,
    register_hive_recap_handler,
    register_hive_register_handler,
    register_hive_result_handler,
    register_hive_vote_handler,
    register_iterate_continue_handler,
    register_iterate_start_handler,
    register_nexus_authorize_action_handler,
    register_nexus_contract_verify_handler,
    register_nexus_federation_mint_handler,
    register_nexus_identity_verify_handler,
    register_nexus_lineage_record_handler,
    register_nexus_ratchet_register_handler,
    register_nexus_sys_trust_gate_handler,
    register_recon_swarm_handler,
    register_steersman_run_handler,
    register_synergy_scan_handler,
    register_tool_factory_handler,
    register_verify_handler,
    register_welcome_handler,
    register_wisdom_list_handler,
    register_wisdom_promote_handler,
    register_wisdom_query_handler,
    register_wisdom_recall_handler,
    register_wisdom_record_handler,
)
from ..a2_mo_composites.forge_auth_client import ForgeAuthClient
from ..a2_mo_composites.plan_store import PlanStore as _PlanStore
from .cherry_hunter import (
    harvest as _harvest,
)
from .cherry_hunter import (
    recon_swarm as _recon_swarm,
)
from .cna_check import cna_check as _cna_check
from .commit_compose import compose_commit_message as _commit_compose
from .emergent_feature import EmergentScan as _EmergentScan
from .emergent_swarm import emergent_swarm as _emergent_swarm
from .forge_enforce import run_enforce as _run_enforce
from .forge_evolve_session import (
    evolve_start_session as _evolve_start_session,
)
from .forge_evolve_session import (
    evolve_step_session as _evolve_step_session,
)
from .forge_loop_session import (
    iterate_continue_session as _iterate_continue_session,
)
from .forge_loop_session import (
    iterate_start_session as _iterate_start_session,
)
from .forge_pipeline import (
    run_auto as _run_auto,
)
from .forge_pipeline import (
    run_auto_plan as _run_auto_plan,
)
from .forge_pipeline import (
    run_cherry as _run_cherry,
)
from .forge_pipeline import (
    run_finalize as _run_finalize,
)
from .forge_plan_apply import (
    apply_all_applyable as _apply_all_applyable,
)
from .forge_plan_apply import (
    apply_card as _apply_card,
)
from .guard_install import guard_install as _guard_install
from .hive_sync import (
    consensus_recap as _hive_consensus_recap,
)
from .hive_sync import (
    deactivate_agent as _hive_deactivate_agent,
)
from .hive_sync import (
    get_consensus_result as _hive_get_consensus_result,
)
from .hive_sync import (
    list_agents as _hive_list_agents,
)
from .hive_sync import (
    needs_vote_from as _hive_needs_vote_from,
)
from .hive_sync import (
    observe as _hive_observe,
)
from .hive_sync import (
    propose_consensus as _hive_propose_consensus,
)
from .hive_sync import (
    register_agent as _hive_register_agent,
)
from .hive_sync import (
    vote_consensus as _hive_vote_consensus,
)
from .synergy_feature import SynergyScan as _SynergyScan
from .tool_factory import scaffold_tool as _scaffold_tool
from .verify_umbrella import verify as _verify
from .wisdom_feature import (
    list_wisdom as _list_wisdom,
)
from .wisdom_feature import (
    promote_wisdom as _promote_wisdom,
)
from .wisdom_feature import (
    query_wisdom as _query_wisdom,
)
from .wisdom_feature import (
    recall_for_recon as _recall_for_recon,
)
from .wisdom_feature import (
    record_wisdom as _record_wisdom,
)


def _bound_enforce(project_root, args):
    """a3-side enforce handler — bound into the a1 dispatcher at
    module import time so the upward-import boundary stays clean."""
    src = _Path(args.get("source", project_root)).resolve()
    apply = bool(args.get("apply", False))
    return _run_enforce(src, apply=apply)


def _bound_auto_plan(project_root, args):
    """a3-side auto_plan handler — exposes the agent_plan/v1 emitter
    through the MCP dispatcher with the same a1↔a3 injection pattern
    used for enforce."""
    target = _Path(args.get("target", project_root)).resolve()
    plan = _run_auto_plan(
        target=target,
        goal=str(args.get("goal", "improve repo conformance")),
        mode=str(args.get("mode", "improve")),
        package=args.get("package"),
        top_n=int(args.get("top_n", 7)),
    )
    if bool(args.get("save", False)):
        plan_id = _PlanStore(target).save_plan(plan)
        plan["id"] = plan_id
    return plan


def _bound_auto_step(project_root, args):
    project = _Path(args.get("project", project_root)).resolve()
    plan_id = str(args["plan_id"])
    card_id = str(args["card_id"])
    apply = bool(args.get("apply", False))
    plan = _PlanStore(project).load_plan(plan_id)
    if plan is None:
        return {
            "schema_version": "atomadic-forge.plan_apply/v1",
            "plan_id": plan_id, "card_id": card_id, "apply": apply,
            "status": "failed",
            "detail": {"reason": f"plan id {plan_id!r} not found"},
        }
    return _apply_card(project, plan, card_id, apply=apply)


def _bound_auto_apply(project_root, args):
    project = _Path(args.get("project", project_root)).resolve()
    plan_id = str(args["plan_id"])
    apply = bool(args.get("apply", False))
    plan = _PlanStore(project).load_plan(plan_id)
    if plan is None:
        return {
            "schema_version": "atomadic-forge.plan_apply_all/v1",
            "plan_id": plan_id, "apply": apply,
            "results": [], "halted_on": "failed",
            "applied_count": 0, "skipped_count": 0,
            "detail": {"reason": f"plan id {plan_id!r} not found"},
        }
    return _apply_all_applyable(project, plan, apply=apply)


def _bound_emergent_scan(project_root, args):
    """a3-side emergent_scan handler — wired into the a1 dispatcher."""
    root = _Path(args.get("project_root", project_root)).resolve()
    package = str(args.get("package", "atomadic_forge"))
    top_n = int(args.get("top_n", 10))
    max_depth = int(args.get("max_depth", 3))
    include_chains = bool(args.get("include_chains", False))
    scan = _EmergentScan(src_root=root, package=package)
    report = scan.scan(top_n=top_n, max_depth=max_depth)
    result = dict(report)
    result["candidate_count"] = len(result.get("candidates", []))
    if not include_chains:
        slim = []
        for c in result.get("candidates", []):
            item = {k: v for k, v in c.items() if k not in ("chain", "score_breakdown")}
            item["chain_len"] = len(c.get("chain", []))
            slim.append(item)
        result["candidates"] = slim
        result["hint"] = "chain/score_breakdown omitted. Pass include_chains=true when implementing a candidate."
    return result


def _bound_synergy_scan(project_root, args):
    """a3-side synergy_scan handler — wired into the a1 dispatcher."""
    root = _Path(args.get("project_root", project_root)).resolve()
    package = str(args.get("package", "atomadic_forge"))
    top_n = int(args.get("top_n", 10))
    include_details = bool(args.get("include_details", False))
    # SynergyScan expects the src/ directory, not the project root.
    src_root = (root / "src") if (root / "src").is_dir() else root
    scan = _SynergyScan(src_root=src_root, package=package)
    report = scan.scan(top_n=top_n)
    result = dict(report)
    result["returned_count"] = len(result.get("candidates", []))
    if not include_details:
        slim = []
        for c in result.get("candidates", []):
            item = {k: v for k, v in c.items() if k != "score_breakdown"}
            slim.append(item)
        result["candidates"] = slim
        result["hint"] = "score_breakdown omitted. Pass include_details=true to retrieve."
    return result


def _bound_auto(project_root, args):
    """a3-side ``forge auto`` handler — runs the deterministic
    scout → cherry → assimilate → wire → certify pipeline.
    No LLM is invoked; the agent supplies its own reasoning and uses
    forge purely for analytical certainty."""
    target = _Path(args.get("target", project_root)).resolve()
    output = _Path(args["output"]).resolve()
    package = str(args.get("package", "absorbed"))
    apply = bool(args.get("apply", False))
    on_conflict = str(args.get("on_conflict", "rename"))
    if on_conflict not in {"rename", "first", "last", "fail"}:
        raise ValueError(
            f"on_conflict must be one of rename|first|last|fail, "
            f"got {on_conflict!r}"
        )
    return _run_auto(
        target=target, output=output, package=package,
        apply=apply, on_conflict=on_conflict,
    )


def _bound_cherry(project_root, args):
    """a3-side ``forge cherry`` handler — derives a cherry-pick
    manifest from the latest (or freshly-built) scout report."""
    target = _Path(args.get("target", project_root)).resolve()
    pick = args.get("pick")
    pick_all = bool(args.get("pick_all", False))
    if pick == ["all"]:
        pick_all = True
        pick = None
    only_tier = args.get("only_tier")
    return _run_cherry(
        target,
        names=pick if pick else None,
        pick_all=pick_all,
        only_tier=str(only_tier) if only_tier else None,
    )


def _bound_finalize(project_root, args):
    """a3-side ``forge finalize`` handler — assimilate cherry-picked
    symbols + wire + certify."""
    target = _Path(args.get("target", project_root)).resolve()
    output = _Path(args["output"]).resolve()
    package = str(args.get("package", "absorbed"))
    apply = bool(args.get("apply", False))
    on_conflict = str(args.get("on_conflict", "rename"))
    if on_conflict not in {"rename", "first", "last", "fail"}:
        raise ValueError(
            f"on_conflict must be one of rename|first|last|fail, "
            f"got {on_conflict!r}"
        )
    return _run_finalize(
        target=target, output=output, package=package,
        apply=apply, on_conflict=on_conflict,
    )


register_enforce_handler(_bound_enforce)
register_auto_plan_handler(_bound_auto_plan)
register_auto_step_handler(_bound_auto_step)
register_auto_apply_handler(_bound_auto_apply)
register_emergent_scan_handler(_bound_emergent_scan)
register_synergy_scan_handler(_bound_synergy_scan)
def _bound_iterate_start(project_root, args):
    """a3-side iterate_start handler — opens an agent-driven session.
    No LLM client is constructed; the calling agent supplies its own."""
    intent = str(args.get("intent", ""))
    output = _Path(args["output"]).resolve()
    package = str(args.get("package", "generated"))
    seed_repos_arg = args.get("seed_repos") or []
    seed_repos = [_Path(p) for p in seed_repos_arg if isinstance(p, str)]
    target_score = float(args.get("target_score", 75.0))
    max_iterations = int(args.get("max_iterations", 5))
    language = str(args.get("language", "python"))
    return _iterate_start_session(
        intent,
        output=output,
        project_root=_Path(project_root).resolve(),
        package=package, seed_repos=seed_repos,
        target_score=target_score, max_iterations=max_iterations,
        language=language,
    )


def _bound_iterate_continue(project_root, args):
    """a3-side iterate_continue handler — feeds the agent's LLM response
    back into the session, returns next prompt or final verdict."""
    session_id = str(args["session_id"])
    response = str(args.get("response", ""))
    return _iterate_continue_session(
        session_id, response,
        project_root=_Path(project_root).resolve(),
    )


register_auto_handler(_bound_auto)
register_cherry_handler(_bound_cherry)
register_finalize_handler(_bound_finalize)
def _bound_recon_swarm(project_root, args):
    """a3-side recon_swarm handler — D_max-bounded portfolio walk."""
    repos = [r for r in (args.get("repos") or []) if isinstance(r, str)]
    return _recon_swarm(
        repos,
        cache_root=_Path(project_root).resolve() / ".atomadic-forge" / "seed_repos",
    )


def _bound_harvest(project_root, args):
    """a3-side harvest handler — trust-gated cross-repo
    capability harvester (formerly cherry_hunt; renamed to avoid
    Git's commit-cherry-pick SEO collision)."""
    target = str(args["target"])
    sources = [s for s in (args.get("sources") or []) if isinstance(s, str)]
    return _harvest(target, sources)


def _bound_evolve_start(project_root, args):
    """a3-side evolve_start handler — recursive-iterate session opener.
    Holds NO LLM client; agent drives the LLM."""
    intent = str(args.get("intent", ""))
    output = _Path(args["output"]).resolve()
    package = str(args.get("package", "evolved"))
    seed_repos_arg = args.get("seed_repos") or []
    seed_repos = [_Path(p) for p in seed_repos_arg if isinstance(p, str)]
    target_score = float(args.get("target_score", 75.0))
    rounds = int(args.get("rounds", 3))
    iterations_per_round = int(args.get("iterations_per_round", 4))
    stop_on_regression = bool(args.get("stop_on_regression", False))
    stagnation_threshold = int(args.get("stagnation_threshold", 3))
    language = str(args.get("language", "python"))
    return _evolve_start_session(
        intent,
        output=output,
        project_root=_Path(project_root).resolve(),
        package=package, seed_repos=seed_repos,
        target_score=target_score,
        rounds=rounds,
        iterations_per_round=iterations_per_round,
        stop_on_regression=stop_on_regression,
        stagnation_threshold=stagnation_threshold,
        language=language,
    )


def _bound_evolve_step(project_root, args):
    """a3-side evolve_step handler — feeds LLM response into the
    active iterate child of an evolve session."""
    evolve_session_id = str(args["evolve_session_id"])
    response = str(args.get("response", ""))
    return _evolve_step_session(
        evolve_session_id, response,
        project_root=_Path(project_root).resolve(),
    )


register_iterate_start_handler(_bound_iterate_start)
register_iterate_continue_handler(_bound_iterate_continue)
register_recon_swarm_handler(_bound_recon_swarm)
register_harvest_handler(_bound_harvest)
def _bound_tool_factory(project_root, args):
    """a3-side tool_factory handler — emits MCP tool scaffold text.
    Pure: does NOT mutate files; returns the scaffold for the agent
    to review and apply."""
    artifact = _scaffold_tool(
        tool_name=str(args["tool_name"]),
        use_this_when=str(args["use_this_when"]),
        body_description=str(args["body_description"]),
        input_schema=args.get("input_schema"),
        handler_module=str(args.get("handler_module") or ""),
        handler_callable=str(args.get("handler_callable") or ""),
        create_module=bool(args.get("create_module", False)),
        apply=bool(args.get("apply", False)),
        project_root=args.get("project_root") or project_root,
    )
    return artifact.as_dict()


def _bound_verify(project_root, args):
    """a3-side verify handler — composite go/no-go gate.
    Pure orchestrator: composes wire + certify + score_patch +
    preflight_change. No new analytics, no LLM. CNA-compliant.

    v0.10.0: when ``check_exports=true`` and a ``source`` arg is
    supplied, also runs the docstring-vs-actual-exports drift check
    (formerly the standalone ``exported_api_check`` tool, now folded
    in here as a verify gate).
    """
    root = _Path(args.get("project_root", project_root)).resolve()
    package = args.get("package")
    proposed = args.get("proposed_files") or []
    result = _verify(
        project_root=root,
        package=str(package) if package else None,
        diff=args.get("diff") or None,
        intent=args.get("intent") or None,
        proposed_files=[str(f) for f in proposed] if proposed else None,
        fail_under=float(args.get("fail_under", 75.0)),
    )
    if args.get("check_exports") and args.get("source"):
        # Fold the absorbed exported_api_check gate.
        from ..a1_at_functions.exported_api_check import (
            check_exported_api as _check_exports,
        )
        try:
            export_check = _check_exports(
                str(args["source"]), path=str(args.get("path", "")),
            )
            result["exported_api_check"] = export_check
            if isinstance(export_check, dict) and export_check.get("missing"):
                result.setdefault("refine_reasons", []).append(
                    "exported_api_check: docstring claims symbols "
                    "that do not exist at top level"
                )
                if result.get("verdict") == "PASS":
                    result["verdict"] = "REFINE"
        except Exception as exc:  # noqa: BLE001 — gate must not crash
            result["exported_api_check"] = {
                "error": f"{type(exc).__name__}: {exc}",
            }
    return result


register_evolve_start_handler(_bound_evolve_start)
register_evolve_step_handler(_bound_evolve_step)
register_tool_factory_handler(_bound_tool_factory)
def _bound_cna_check(project_root, args):
    """a3-side cna_check handler — composes intent_similarity +
    code_signature + dedup_engine. Pure CNA orchestrator."""
    root = _Path(args.get("project_root", project_root)).resolve()
    return _cna_check(
        project_root=root,
        proposed_name=str(args["proposed_name"]),
        proposed_body=args.get("proposed_body") or None,
        package_subdir=args.get("package_subdir") or None,
        name_top_n=int(args.get("name_top_n", 10)),
    ).as_dict()


def _bound_emergent_swarm(project_root, args):
    """a3-side emergent_swarm handler — cross-repo emergent composition
    discovery. Pure CNA orchestrator: composes harvest_signatures +
    find_chains + rank_chains over a union catalog."""
    repos_arg = args.get("repos") or []
    repos: list[tuple[Path, str]] = []
    for r in repos_arg:
        if not isinstance(r, dict):
            continue
        src = r.get("src_root")
        pkg = r.get("package")
        if isinstance(src, str) and isinstance(pkg, str):
            repos.append((_Path(src), pkg))
    return _emergent_swarm(
        repos,
        top_n=int(args.get("top_n", 25)),
        max_depth=int(args.get("max_depth", 3)),
        max_chains=int(args.get("max_chains", 5000)),
        require_pure=bool(args.get("require_pure", False)),
        domain_jump_required=bool(args.get("domain_jump_required", True)),
        cross_repo_bonus=float(args.get("cross_repo_bonus", 15.0)),
        corroborate_with_call_graph=bool(
            args.get("corroborate_with_call_graph", True)
        ),
    )


register_verify_handler(_bound_verify)
register_cna_check_handler(_bound_cna_check)
def _bound_guard_install(project_root, args):
    """a3-side guard_install handler — installs the four-layer
    standing guard against architectural regrowth."""
    root = _Path(args.get("project_root", project_root)).resolve()
    return _guard_install(
        project_root=root,
        min_certify_score=int(args.get("min_certify_score", 90)),
        max_cyclomatic=int(args.get("max_cyclomatic", 10)),
        strict_mode=bool(args.get("strict_mode", False)),
        apply=bool(args.get("apply", False)),
        overwrite=bool(args.get("overwrite", False)),
    ).as_dict()


def _bound_commit_compose(project_root, args):
    """a3-side commit_compose handler — structured commit message
    composer. Pure: composes git diff + template. No LLM."""
    root = _Path(args.get("project_root", project_root)).resolve()
    return _commit_compose(
        project_root=root,
        intent=str(args["intent"]),
        commit_type=str(args.get("commit_type", "ship")),
        body=str(args.get("body", "")),
        include_coauthor=bool(args.get("include_coauthor", True)),
    ).as_dict()


register_emergent_swarm_handler(_bound_emergent_swarm)
register_guard_install_handler(_bound_guard_install)
register_commit_compose_handler(_bound_commit_compose)


# ---- v0.13.1: wisdom MCP tools ----------------------------------------
# Cross-session institutional memory exposed to MCP. The four bound
# handlers below adapt the args dict to the keyword-only signatures of
# the a3 wisdom_feature orchestrator (record/query/list/recall_for_recon).
# Hand-wired to avoid the tool_factory v0.13.0 bound-handler bug
# (WIS-3cd3c921) that would have called the impl with a single
# positional dict instead of unpacking kwargs.


def _bound_wisdom_record(project_root, args):
    """a3-side wisdom_record handler — records one wisdom entry."""
    pr = Path(args.get("project_root") or project_root).resolve()
    return _record_wisdom(
        project_root=pr,
        insight=str(args["insight"]),
        scope=str(args.get("scope", "repo")),
        tags=list(args.get("tags") or []),
        evidence=list(args.get("evidence") or []),
        confidence=float(args.get("confidence", 0.5)),
        agent_name=str(args.get("agent_name", "anonymous")),
        session_id=args.get("session_id"),
        supersedes=args.get("supersedes"),
        trust_signals=dict(args.get("trust_signals") or {}),
    )


def _bound_wisdom_query(project_root, args):
    """a3-side wisdom_query handler — relevance-ranks active wisdom."""
    pr = Path(args.get("project_root") or project_root).resolve()
    return _query_wisdom(
        project_root=pr,
        scope=args.get("scope"),
        tags=list(args.get("tags") or []),
        text=args.get("text"),
        top_n=int(args.get("top_n", 5)),
    )


def _bound_wisdom_list(project_root, args):
    """a3-side wisdom_list handler — full DB read with optional limit."""
    pr = Path(args.get("project_root") or project_root).resolve()
    limit = int(args.get("limit", 20))
    result = _list_wisdom(
        project_root=pr,
        include_superseded=bool(args.get("include_superseded", False)),
    )
    entries = result["entries"]
    total = len(entries)
    if limit > 0:
        entries = entries[:limit]
    result["entries"] = entries
    result["total_count"] = total
    result["returned_count"] = len(entries)
    if limit > 0 and total > limit:
        result["truncated"] = True
        result["hint"] = f"Showing {limit}/{total} entries. Pass limit=0 for all or limit=N for more."
    return result


def _bound_wisdom_recall(project_root, args):
    """a3-side wisdom_recall handler — top-N repo-scoped recon-hook surface."""
    pr = Path(args.get("project_root") or project_root).resolve()
    return _recall_for_recon(
        project_root=pr,
        top_n=int(args.get("top_n", 5)),
    )


def _bound_wisdom_promote(project_root, args):
    """a3-side wisdom_promote handler — graduate corroborated wisdom to drafts.

    By default strips draft_markdown bodies to keep response under ~3KB.
    Pass include_bodies=true to get full markdown (or write=true to persist).
    """
    pr = Path(args.get("project_root") or project_root).resolve()
    write = bool(args.get("write", False))
    result = _promote_wisdom(
        project_root=pr,
        min_corroboration=int(args.get("min_corroboration", 3)),
        min_tag_overlap=int(args.get("min_tag_overlap", 1)),
        write_drafts=write,
    )
    include_bodies = bool(args.get("include_bodies", False)) or write
    if not include_bodies and "drafts" in result:
        slim = []
        for d in result["drafts"]:
            item = {k: v for k, v in d.items() if k != "draft_markdown"}
            body = d.get("draft_markdown", "")
            item["body_chars"] = len(body)
            item["body_omitted"] = True
            slim.append(item)
        result["drafts"] = slim
        result["hint"] = "draft_markdown omitted by default. Pass include_bodies=true to retrieve."
    return result


register_wisdom_record_handler(_bound_wisdom_record)
register_wisdom_query_handler(_bound_wisdom_query)
register_wisdom_list_handler(_bound_wisdom_list)
register_wisdom_recall_handler(_bound_wisdom_recall)
register_wisdom_promote_handler(_bound_wisdom_promote)


# ---- v0.13.2: hive sync MCP tools -------------------------------------
# Agent registry + consensus + observe primitives. Bound handlers
# adapt args dict to the keyword-only impl signatures (same kwargs
# pattern as wisdom_*; tool_factory v0.13.2 fix would emit this same
# shape automatically going forward).


def _bound_hive_register(project_root, args):
    pr = Path(args.get("project_root") or project_root).resolve()
    return _hive_register_agent(
        project_root=pr,
        agent_name=str(args["agent_name"]),
        role=str(args["role"]),
        capabilities=list(args.get("capabilities") or []),
        subscribes_to=(list(args["subscribes_to"]) if args.get("subscribes_to") else None),
        write_lanes=list(args.get("write_lanes") or []),
        identity_claim=args.get("identity_claim"),
        notes=args.get("notes"),
    )


def _bound_hive_list(project_root, args):
    pr = Path(args.get("project_root") or project_root).resolve()
    return _hive_list_agents(
        project_root=pr,
        include_deactivated=bool(args.get("include_deactivated", False)),
    )


def _bound_hive_deactivate(project_root, args):
    pr = Path(args.get("project_root") or project_root).resolve()
    return _hive_deactivate_agent(
        project_root=pr,
        agent_name=str(args["agent_name"]),
    )


def _bound_hive_observe(project_root, args):
    pr = Path(args.get("project_root") or project_root).resolve()
    return _hive_observe(
        project_root=pr,
        agent_name=args.get("agent_name"),
        since_consensus_id=args.get("since_consensus_id"),
        since_wisdom_id=args.get("since_wisdom_id"),
        limit=int(args.get("limit", 50)),
    )


def _bound_hive_propose(project_root, args):
    pr = Path(args.get("project_root") or project_root).resolve()
    return _hive_propose_consensus(
        project_root=pr,
        intent=str(args["intent"]),
        proposer=str(args["proposer"]),
        payload=dict(args.get("payload") or {}),
    )


def _bound_hive_vote(project_root, args):
    pr = Path(args.get("project_root") or project_root).resolve()
    return _hive_vote_consensus(
        project_root=pr,
        consensus_id=str(args["consensus_id"]),
        voter=str(args["voter"]),
        vote=str(args["vote"]),
        rationale=args.get("rationale"),
    )


def _bound_hive_result(project_root, args):
    pr = Path(args.get("project_root") or project_root).resolve()
    return _hive_get_consensus_result(
        project_root=pr,
        consensus_id=str(args["consensus_id"]),
        record_resolution=bool(args.get("record", False)),
    )


def _bound_hive_needs_vote(project_root, args):
    pr = Path(args.get("project_root") or project_root).resolve()
    return _hive_needs_vote_from(
        project_root=pr,
        agent_name=str(args["agent_name"]),
    )


def _bound_hive_recap(project_root, args):
    pr = Path(args.get("project_root") or project_root).resolve()
    return _hive_consensus_recap(
        project_root=pr,
        consensus_id=str(args["consensus_id"]),
    )


register_hive_register_handler(_bound_hive_register)
register_hive_list_handler(_bound_hive_list)
register_hive_deactivate_handler(_bound_hive_deactivate)
register_hive_observe_handler(_bound_hive_observe)
register_hive_propose_handler(_bound_hive_propose)
register_hive_vote_handler(_bound_hive_vote)
register_hive_result_handler(_bound_hive_result)
register_hive_needs_vote_handler(_bound_hive_needs_vote)
register_hive_recap_handler(_bound_hive_recap)


# ---- v0.14.0a7: Nexus primitives as MCP tools -------------------------
# Each is a thin proxy through NexusClient.from_env(); failures
# surface as structured ok=False payloads (not exceptions across
# the wire). Refuses unshipped primitives at the client layer
# (NexusToolNotShipped guard).


def _nexus_call_envelope(tool_name: str, args: dict[str, Any]) -> dict[str, Any]:
    """Shared adapter: call NexusClient with structured failure surface."""
    from ..a0_qk_constants.nexus_constants import NEXUS_PREMIUM_HINT
    from ..a2_mo_composites.nexus_client import (
        NexusClient,
        NexusToolNotShipped,
        NexusUnavailable,
    )
    client = NexusClient.from_env()
    if not client.auth_token:
        return {
            "schema_version": "atomadic-forge.nexus_call/v1",
            "tool": tool_name, "ok": False,
            "error": (
                "no auth — set ATOMADIC_SUBSCRIPTION_KEY, ATOMADIC_MASTER_KEY, "
                "FORGE_API_KEY, FORGE_MASTER_API_KEY, or AAAA_NEXUS_API_KEY"
            ),
            "premium_hint": NEXUS_PREMIUM_HINT,
        }
    try:
        result = client.call(tool_name, args)
        return {**result, "ok": True}
    except (NexusUnavailable, NexusToolNotShipped) as exc:
        return {
            "schema_version": "atomadic-forge.nexus_call/v1",
            "tool": tool_name, "ok": False,
            "error": f"{type(exc).__name__}: {exc}",
        }


def _bound_nexus_identity_verify(project_root, args):
    return _nexus_call_envelope("identity_verify", args)
def _bound_nexus_federation_mint(project_root, args):
    return _nexus_call_envelope("federation_mint", args)
def _bound_nexus_authorize_action(project_root, args):
    return _nexus_call_envelope("authorize_action", args)
def _bound_nexus_sys_trust_gate(project_root, args):
    return _nexus_call_envelope("sys_trust_gate", args)
def _bound_nexus_contract_verify(project_root, args):
    return _nexus_call_envelope("contract_verify", args)
def _bound_nexus_lineage_record(project_root, args):
    return _nexus_call_envelope("lineage_record", args)
def _bound_nexus_ratchet_register(project_root, args):
    return _nexus_call_envelope("ratchet_register", args)


register_nexus_identity_verify_handler(_bound_nexus_identity_verify)
register_nexus_federation_mint_handler(_bound_nexus_federation_mint)
register_nexus_authorize_action_handler(_bound_nexus_authorize_action)
register_nexus_sys_trust_gate_handler(_bound_nexus_sys_trust_gate)
register_nexus_contract_verify_handler(_bound_nexus_contract_verify)
register_nexus_lineage_record_handler(_bound_nexus_lineage_record)
register_nexus_ratchet_register_handler(_bound_nexus_ratchet_register)


def _bound_ast_scope_attest(project_root, args):
    """a3-side AST scope attestation handler — graceful Nexus mirror."""
    from .nexus_bridge import mirror_ast_locks_to_lineage
    plan = dict(args.get("plan") or {})
    plan["nexus"] = mirror_ast_locks_to_lineage(
        ast_scope_plan=plan,
        intent=str(args.get("nexus_intent", "ast_scope_locks_minted")),
    )
    return plan


register_ast_scope_attest_handler(_bound_ast_scope_attest)


def _bound_steersman_run(project_root, args):
    """a3-side tiny-model runner — semantic choices only, no code output."""
    import os as _os

    from ..a1_at_functions.llm_client import OllamaClient
    from ..a1_at_functions.provider_resolver import resolve_provider
    from ..a1_at_functions.steersman_pack import finalize_steersman_pack

    pack = dict(args.get("pack") or {})
    provider = str(args.get("provider", "ollama"))
    model = str(args.get("model", "llama3.2:1b"))
    system = (
        "You are Forge Steersman. You do not write code. "
        "Return JSON choices only."
    )
    try:
        if provider == "ollama":
            client = OllamaClient(
                model=model,
                base_url=_os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434"),
                num_predict=int(args.get("num_predict", 256)),
            )
        else:
            client = resolve_provider(provider, project_root=_Path(project_root))
        response = client.call(
            str(pack.get("model_prompt", "")),
            system=system,
            max_tokens=int(args.get("max_tokens", 256)),
            temperature=float(args.get("temperature", 0.0)),
        )
        out = finalize_steersman_pack(pack=pack, model_response=response)
        out["model"] = {
            "ran": True,
            "provider": provider,
            "model": getattr(client, "model", model),
            "response_chars": len(response),
        }
        return out
    except Exception as exc:  # noqa: BLE001 — steersman degrades to deterministic defaults
        out = finalize_steersman_pack(pack=pack)
        out["model"] = {
            "ran": False,
            "provider": provider,
            "model": model,
            "reason": f"{type(exc).__name__}: {exc}",
            "fallback": "deterministic_default_decisions",
        }
        return out


register_steersman_run_handler(_bound_steersman_run)


# ---- v0.14.0a9 — handoff handlers ------------------------------------


def _bound_handoff_create(project_root, args):
    """a3-side handoff_create handler — wraps write_handoff."""
    from .handoff_feature import write_handoff as _write_handoff
    root = _Path(args.get("project_root", project_root)).resolve()
    return _write_handoff(
        project_root=root,
        agent_name=str(args.get("agent_name", "anonymous")),
        work_completed=list(args.get("work_completed") or []),
        files_modified=list(args.get("files_modified") or []),
        files_created=list(args.get("files_created") or []),
        test_results=args.get("test_results") or None,
        pending_tasks=list(args.get("pending_tasks") or []),
        key_context=str(args.get("key_context", "")),
        warnings=list(args.get("warnings") or []),
        axiom_guard_status=str(args.get("axiom_guard_status", "PASS")).upper(),
        session_id=args.get("session_id") or None,
    )


def _bound_handoff_list(project_root, args):
    """a3-side handoff_list handler — wraps list_handoffs."""
    from .handoff_feature import list_handoffs as _list_handoffs
    root = _Path(args.get("project_root", project_root)).resolve()
    return _list_handoffs(
        project_root=root,
        limit=int(args.get("limit", 20)),
    )


register_handoff_create_handler(_bound_handoff_create)
register_handoff_list_handler(_bound_handoff_list)


# ---- v0.14.0a11 — enhancement-proposal handlers ----------------------


def _bound_enhancement_propose(project_root, args):
    """a3-side enhancement_propose handler — wraps submit_proposal.

    Trust-gating in the MCP path is OFFLINE by default. A future bind
    can pass an AAAA-Nexus-backed callable for live verification.
    """
    from .enhancement_proposal_feature import submit_proposal as _submit
    root = _Path(args.get("project_root", project_root)).resolve()
    return _submit(
        project_root=root,
        title=str(args.get("title", "")),
        description=str(args.get("description", "")),
        evidence=list(args.get("evidence") or []),
        proposer=str(args.get("proposer", "anonymous")),
        trust_threshold=float(args.get("trust_threshold", 0.75)),
    )


def _bound_enhancement_list(project_root, args):
    """a3-side enhancement_list handler — wraps list_proposals."""
    from .enhancement_proposal_feature import list_proposals as _list
    root = _Path(args.get("project_root", project_root)).resolve()
    return _list(
        project_root=root,
        limit=int(args.get("limit", 50)),
    )


register_enhancement_propose_handler(_bound_enhancement_propose)
register_enhancement_list_handler(_bound_enhancement_list)


# ---- v0.14.0a12 — welcome handshake handler --------------------------


def _bound_welcome(project_root, args):
    """a3-side welcome handler — wraps the welcome orchestrator."""
    from .welcome_feature import welcome as _welcome
    root = _Path(args.get("project_root", project_root)).resolve()
    package = args.get("package")
    since = args.get("since_receipt")
    return _welcome(
        project_root=root,
        package=str(package) if package else None,
        since_receipt=str(since) if since else None,
        skip_certify=bool(args.get("skip_certify", False)),
    )


register_welcome_handler(_bound_welcome)


# ---- v0.47.0 — `forge create` exposed as MCP tool --------------------


def _bound_create(project_root, args):
    """a3-side create handler — wraps create_from_intent.

    Args from MCP `create` tool: intent, seed_repos (list[str]), out_dir,
    package, top_n, run_certify, swarm_max_depth, require_pure,
    domain_jump_required, cross_repo_bonus, corroborate_with_call_graph.
    """
    from .create_feature import create_from_intent
    seeds = [p for p in args.get("seed_repos") or [] if isinstance(p, str)]
    out = _Path(args["out_dir"]).resolve()
    return create_from_intent(
        intent=str(args["intent"]),
        seed_repos=seeds,
        out_dir=out,
        package=str(args["package"]),
        top_n=int(args.get("top_n", 5)),
        run_certify=bool(args.get("run_certify", True)),
        swarm_max_depth=int(args.get("swarm_max_depth", 3)),
        require_pure=bool(args.get("require_pure", False)),
        domain_jump_required=bool(args.get("domain_jump_required", True)),
        cross_repo_bonus=float(args.get("cross_repo_bonus", 15.0)),
        corroborate_with_call_graph=bool(args.get("corroborate_with_call_graph", True)),
    )


register_create_handler(_bound_create)


# ---- Lane C W5: subscription gate -------------------------------------

_AUTH_REQUIRED_METHODS = frozenset({"tools/call", "resources/read"})
"""JSON-RPC methods that require a paid subscription.

Everything else (``initialize``, ``ping``, ``tools/list``,
``resources/list``, ``notifications/initialized``, ``shutdown``) is
read-only metadata and stays open so MCP clients can finish their
handshake before the user has logged in.
"""

_AUTH_ERROR_CODE = -32001
_UPGRADE_URL = "https://atomadic.tech/forge"
_CREDENTIALS_PATH = Path("~/.atomadic-forge/credentials.toml").expanduser()
_LOGIN_HINT = (
    "Run `forge login` once to capture your subscription key into "
    "~/.atomadic-forge/credentials.toml, OR export FORGE_API_KEY=fk_live_... "
    "or FORGE_MASTER_API_KEY=ak_master_... "
    "in the env that launches the MCP. Get a key at "
    "https://atomadic.tech/forge#account."
)


def _auth_check(
    env: dict[str, str],
    *,
    client: ForgeAuthClient,
    credentials_path: Path | None = None,
) -> tuple[bool, str, str]:
    """Return (ok, reason, api_key).

    ``ok`` is True when the gate should let the call through. ``reason``
    is the human-readable explanation (used to populate the JSON-RPC
    error ``details`` field on rejection). ``api_key`` is the raw key
    when present (so the caller can fire usage-log telemetry); empty
    string when no key was configured.

    Resolution order:
      1. ``FORGE_API_KEY`` env var (CI / explicit override)
      2. ``~/.atomadic-forge/credentials.toml`` (written by ``forge login``)

    The credentials.toml fallback means a one-time ``forge login`` on
    a workstation is enough — every subsequent ``forge mcp serve``
    picks it up without needing the env var to be re-exported by
    every shell, IDE, or MCP host.
    """
    api_key = read_api_key_from_env(env)
    if not api_key:
        path = credentials_path or _CREDENTIALS_PATH
        api_key = read_api_key_from_credentials_file(path)
    if not api_key:
        return False, (
            "Forge subscription key not configured. " + _LOGIN_HINT
        ), ""
    result = client.verify(api_key)
    if result.get("ok"):
        return True, str(result.get("reason", "")), api_key
    return False, str(result.get("reason", "verify failed")), api_key


def _auth_error_response(
    msg_id: object, *, reason: str,
) -> dict[str, object]:
    """Build the canonical -32001 error response."""
    return {
        "jsonrpc": "2.0",
        "id": msg_id,
        "error": {
            "code": _AUTH_ERROR_CODE,
            "message": "Forge subscription required",
            "data": {
                "upgrade_url": _UPGRADE_URL,
                "details": reason,
                "env": "FORGE_API_KEY",
                "login_command": "forge login",
            },
        },
    }


def serve_stdio(
    *,
    project_root: Path,
    stdin: IO[str] | None = None,
    stdout: IO[str] | None = None,
    stderr: IO[str] | None = None,
    auth_client: ForgeAuthClient | None = None,
    env: dict[str, str] | None = None,
) -> int:
    """Run the MCP stdio loop until stdin closes.

    Returns the exit code: 0 for clean shutdown, 1 for unrecoverable
    setup error. Per-request errors NEVER raise — they're returned to
    the client as JSON-RPC error responses.
    """
    src_in = stdin if stdin is not None else sys.stdin.buffer
    src_out = stdout if stdout is not None else sys.stdout.buffer
    src_err = stderr or sys.stderr
    eff_env: dict[str, str] = dict(env if env is not None else os.environ)
    client = auth_client or ForgeAuthClient()
    project_hash = hash_project_path(project_root)

    project_root = Path(project_root).resolve()
    if not project_root.exists():
        src_err.write(f"forge mcp serve: project_root not found: "
                       f"{project_root}\n")
        return 1
    src_err.write(f"forge mcp serve: ready (project_root={project_root})\n")
    src_err.flush()

    while True:
        raw, framed = _read_message(src_in)
        if raw is None:
            break
        line = raw.strip()
        if not line:
            continue
        try:
            request = json.loads(line.decode("utf-8") if isinstance(line, bytes) else line)
        except json.JSONDecodeError as exc:
            response = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {
                    "code": -32700,
                    "message": f"Parse error: {exc}",
                },
            }
            _write(src_out, response, framed=framed)
            continue
        if isinstance(request, dict) and request.get("method") == "shutdown":
            _write(src_out, {"jsonrpc": "2.0",
                              "id": request.get("id"), "result": {}},
                   framed=framed)
            break
        # Lane C W5: subscription gate. Read-only metadata methods
        # bypass the check so initialize/tools/list still succeed
        # before login; tools/call and resources/read are gated.
        method = request.get("method") if isinstance(request, dict) else None
        if method in _AUTH_REQUIRED_METHODS:
            ok, reason, api_key = _auth_check(eff_env, client=client)
            if not ok:
                _write(src_out, _auth_error_response(
                    request.get("id") if isinstance(request, dict) else None,
                    reason=reason,
                ), framed=framed)
                continue
            # Fire-and-forget usage telemetry for tools/call only.
            if method == "tools/call" and api_key:
                params = request.get("params") or {}
                tool_name = (
                    params.get("name") if isinstance(params, dict) else None
                ) or "?"
                try:
                    client.log_usage(api_key, str(tool_name), project_hash)
                except Exception:  # noqa: BLE001 — telemetry MUST NOT block
                    pass
        response = dispatch_request(request, project_root=project_root)
        if response is not None:
            _write(src_out, response, framed=framed)
    return 0


def _read_message(stream: IO[Any]) -> tuple[str | bytes | None, bool]:
    """Read one MCP stdio message.

    Forge historically accepted newline-delimited JSON-RPC. Some MCP
    hosts use LSP-style ``Content-Length`` frames instead. Accept both
    shapes so existing shell smoke tests keep working and stricter MCP
    clients do not block waiting for a newline that will never arrive.
    """
    first = stream.readline()
    if not first:
        return None, False
    if isinstance(first, bytes):
        probe = first.decode("ascii", errors="ignore").strip()
    else:
        probe = str(first).strip()
    if probe.lower().startswith("content-length:"):
        headers = [probe]
        while True:
            line = stream.readline()
            if not line:
                return None, True
            text = (
                line.decode("ascii", errors="ignore").rstrip("\r\n")
                if isinstance(line, bytes)
                else str(line).rstrip("\r\n")
            )
            if text == "":
                break
            headers.append(text)
        length = 0
        for header in headers:
            key, _, value = header.partition(":")
            if key.strip().lower() == "content-length":
                try:
                    length = int(value.strip())
                except ValueError:
                    length = 0
                break
        if length <= 0:
            return b"" if isinstance(first, bytes) else "", True
        body = stream.read(length)
        return body, True
    return first, False


def _write(stream: IO[Any], payload: dict, *, framed: bool = False) -> None:
    body = json.dumps(payload, default=_json_default)
    if framed:
        encoded = body.encode("utf-8")
        header = f"Content-Length: {len(encoded)}\r\n\r\n".encode("ascii")
        try:
            stream.write(header)
            stream.write(encoded)
        except TypeError:
            stream.write(header.decode("ascii"))
            stream.write(encoded.decode("utf-8"))
        stream.flush()
        return
    try:
        stream.write(body + "\n")
    except TypeError:
        stream.write((body + "\n").encode("utf-8"))
    stream.flush()
