"""Tier a3 — handoff write/list orchestrator.

Composes the a1 builder with disk I/O. Handoff files live at
``.atomadic-forge/handoffs/<session_id>.json`` so an inbound agent can
do ``ls .atomadic-forge/handoffs/`` to find every prior session and
pick up where the last one left off.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..a0_qk_constants.handoff_constants import (
    AXIOM_GUARD_PASS,
    HANDOFF_DIR_REL,
    SCHEMA_VERSION_HANDOFF_V1,
)
from ..a1_at_functions.handoff_builder import make_handoff_entry


def _handoff_dir(project_root: Path) -> Path:
    return Path(project_root) / HANDOFF_DIR_REL


def write_handoff(
    *,
    project_root: Path,
    agent_name: str = "anonymous",
    work_completed: list[str] | None = None,
    files_modified: list[str] | None = None,
    files_created: list[str] | None = None,
    test_results: dict[str, int] | None = None,
    pending_tasks: list[str] | None = None,
    key_context: str = "",
    warnings: list[str] | None = None,
    axiom_guard_status: str = AXIOM_GUARD_PASS,
    session_id: str | None = None,
) -> dict[str, Any]:
    """Build a handoff entry, persist it to disk, return entry + path."""
    entry = make_handoff_entry(
        agent_name=agent_name,
        work_completed=work_completed,
        files_modified=files_modified,
        files_created=files_created,
        test_results=test_results,
        pending_tasks=pending_tasks,
        key_context=key_context,
        warnings=warnings,
        axiom_guard_status=axiom_guard_status,
        session_id=session_id,
    )

    out_dir = _handoff_dir(project_root)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{entry['session_id']}.json"
    out_path.write_text(json.dumps(entry, indent=2), encoding="utf-8")

    return {
        "schema_version": SCHEMA_VERSION_HANDOFF_V1,
        "wrote": True,
        "entry": entry,
        "handoff_file": str(out_path),
    }


def list_handoffs(
    *,
    project_root: Path,
    limit: int = 20,
) -> dict[str, Any]:
    """List handoff entries for a repo, newest first.

    Best-effort: malformed JSON files are reported in ``skipped`` rather
    than crashing the listing. Limit caps the returned slice; the count
    field reports the total found.
    """
    out_dir = _handoff_dir(project_root)
    entries: list[dict[str, Any]] = []
    skipped: list[str] = []
    if out_dir.is_dir():
        files = sorted(
            out_dir.glob("*.json"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        for f in files:
            try:
                entries.append(json.loads(f.read_text(encoding="utf-8")))
            except (OSError, ValueError):
                skipped.append(str(f.relative_to(project_root).as_posix()))
    return {
        "schema_version": SCHEMA_VERSION_HANDOFF_V1,
        "handoff_dir": str(out_dir),
        "total_count": len(entries),
        "entries": entries[: max(0, int(limit))],
        "skipped": skipped,
    }


def read_handoff(
    *,
    project_root: Path,
    session_id: str,
) -> dict[str, Any] | None:
    """Read one handoff by session_id. Returns None if not found."""
    out_dir = _handoff_dir(project_root)
    target = out_dir / f"{session_id}.json"
    if not target.is_file():
        return None
    try:
        return json.loads(target.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


__all__ = [
    "list_handoffs",
    "read_handoff",
    "write_handoff",
]
