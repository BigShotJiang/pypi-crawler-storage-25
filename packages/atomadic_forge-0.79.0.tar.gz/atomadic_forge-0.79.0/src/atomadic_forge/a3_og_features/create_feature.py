"""Tier a3 — ``forge create``: intent + seed repos -> shippable package.

Phase 1 of the one-command pipeline. Composes existing primitives —
``emergent_swarm`` (cross-repo composition discovery) and
``materialize_from_report_path`` (report -> package on disk) — into a
single deterministic call. No LLM, no network, no novel logic.

Pipeline::

    intent + seed_repos
        -> resolve each seed to (src_root, package_name)
        -> emergent_swarm(repos)              # discover candidates
        -> persist report to {out_dir}/.atomadic-forge/scan.json
        -> materialize_from_report_path       # write package, certify
        -> return combined CreateReport dict

Future phases (2: GitHub clone; 3: cross-framework merges) will plug in
ahead of step 1 without changing this module's contract.
"""

from __future__ import annotations

import datetime as _dt
import json
from pathlib import Path
from typing import Any

from ..a1_at_functions.harvest_absorb import resolve_any_python_package
from ..a2_mo_composites.remote_seed_store import hydrate_seed_repos
from .emergent_swarm import emergent_swarm
from .materialize_feature import materialize_from_report_path

SCHEMA_VERSION_CREATE_V1 = "atomadic-forge.create/v1"


def resolve_seed_repo(path: Path) -> tuple[Path, str]:
    """Resolve ``--seed-repo PATH`` to ``(src_root, package_name)``.

    Delegates to :func:`harvest_absorb.resolve_any_python_package` which
    handles all known layouts: Atomadic tier, src-layout, monorepo lib/,
    multi-lib libs/, flat package dirs, and unknown (deep scan).
    """
    r = resolve_any_python_package(Path(path))
    return r.src_root, r.package_name


def _import_roots_for_resolved(
    resolved: list[tuple[Path, str]],
    *,
    out_dir: Path,
) -> list[str]:
    roots: list[str] = []
    seen: set[str] = set()
    base = out_dir.resolve()
    for src_root, package_name in resolved:
        root = (
            src_root.parent
            if package_name and src_root.name == package_name
            else src_root
        )
        resolved_root = root.resolve()
        try:
            label = resolved_root.relative_to(base).as_posix()
        except ValueError:
            label = str(resolved_root)
        if label not in seen:
            roots.append(label)
            seen.add(label)
    return roots


def create_from_intent(
    intent: str,
    *,
    seed_repos: list[Path | str],
    out_dir: Path,
    package: str,
    top_n: int = 5,
    run_certify: bool = True,
    swarm_max_depth: int = 3,
    require_pure: bool = False,
    domain_jump_required: bool = True,
    cross_repo_bonus: float = 15.0,
    corroborate_with_call_graph: bool = True,
) -> dict[str, Any]:
    """Run the full Phase 1 pipeline and return a structured report.

    Args:
        intent: human description of the package to assemble. Stored in
            the generated README and the create receipt; not used to
            filter candidates in Phase 1.
        seed_repos: paths to repos to scan. Each is resolved via
            :func:`resolve_seed_repo`.
        out_dir: where to write the new package. Must be empty or a
            previously materialized directory (re-use is safe).
        package: importable name of the new package.
        top_n: materialize the top-N candidates from the scan.
        run_certify: run ``certify`` against the new package.
        swarm_max_depth / require_pure / domain_jump_required /
        cross_repo_bonus / corroborate_with_call_graph: forwarded to
            :func:`emergent_swarm`.

    Returns:
        Dict with ``schema_version``, ``intent``, ``seed_repos``,
        ``scan_summary``, ``materialize`` (the full materialize
        report), and ``scan_report_path`` so callers can re-run
        ``materialize`` with different selections.
    """
    if not seed_repos:
        raise ValueError("create_from_intent requires at least one seed repo")
    if not package.isidentifier():
        raise ValueError(f"package must be a valid Python identifier: {package!r}")

    out_dir = Path(out_dir).resolve()
    hydrated_seeds, seed_hydration = hydrate_seed_repos(
        list(seed_repos),
        cache_root=out_dir / ".atomadic-forge" / "seed_repos",
    )
    resolved: list[tuple[Path, str]] = [
        resolve_seed_repo(p) for p in hydrated_seeds
    ]

    swarm_report = emergent_swarm(
        repos=resolved,
        top_n=max(top_n, 25),
        max_depth=swarm_max_depth,
        require_pure=require_pure,
        domain_jump_required=domain_jump_required,
        cross_repo_bonus=cross_repo_bonus,
        corroborate_with_call_graph=corroborate_with_call_graph,
    )

    out_dir.mkdir(parents=True, exist_ok=True)
    forge_dir = out_dir / ".atomadic-forge"
    forge_dir.mkdir(parents=True, exist_ok=True)
    scan_path = forge_dir / "scan.json"
    scan_path.write_text(
        json.dumps(swarm_report, indent=2, default=str), encoding="utf-8",
    )

    source_pkg = (
        (resolved[0][1] or resolved[0][0].name)
        if len(resolved) == 1
        else "+".join((p or src.name) for src, p in resolved)
    )
    materialize_report = materialize_from_report_path(
        scan_path,
        out_dir=out_dir,
        package=package,
        top_n=top_n,
        run_certify=run_certify,
        source_package=source_pkg,
        intent=intent,
        test_extra_src_roots=_import_roots_for_resolved(
            resolved,
            out_dir=out_dir,
        ),
    )

    scan_summary = {
        "repo_count": swarm_report.get("repo_count"),
        "union_catalog_size": swarm_report.get("union_catalog_size"),
        "candidate_count": swarm_report.get("candidate_count"),
        "cross_repo_chain_count": swarm_report.get("cross_repo_chain_count"),
        "novel_composition_count": swarm_report.get("novel_composition_count"),
    }

    receipt = {
        "schema_version": SCHEMA_VERSION_CREATE_V1,
        "generated_at_utc": _dt.datetime.now(_dt.timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ",
        ),
        "intent": intent,
        "seed_repos": [
            {"src_root": str(src), "package": pkg}
            for src, pkg in resolved
        ],
        "seed_hydration": seed_hydration,
        "out_dir": str(out_dir),
        "package": package,
        "top_n": top_n,
        "scan_report_path": str(scan_path),
        "scan_summary": scan_summary,
        "materialize": materialize_report,
    }
    (forge_dir / "create.json").write_text(
        json.dumps(receipt, indent=2, default=str), encoding="utf-8",
    )
    return receipt


__all__ = (
    "SCHEMA_VERSION_CREATE_V1",
    "create_from_intent",
    "resolve_seed_repo",
)

