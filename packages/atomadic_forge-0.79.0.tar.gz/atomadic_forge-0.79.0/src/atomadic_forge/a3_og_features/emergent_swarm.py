"""Tier a3 — cross-repo emergent composition discovery.

The Round 5 capability the user named: feed ``recon_swarm``'s union of
N repos into ``emergent_scan`` and surface compositions visible ONLY
across the union — the kind of finding the atomadic-lang stress test
made vivid (25 cross-domain pipelines top score 75/100 invisible to
per-repo scans by definition).

Architecture (CNA-pure, composes existing primitives):

  * :func:`a1.emergent_signature_extract.harvest_signatures` — get
    catalog cards per repo (existing).
  * :func:`a1.emergent_compose.find_chains` — composition discovery
    over a catalog (existing).
  * :func:`a1.emergent_rank.rank_chains` — top-N ranking (existing).
  * :data:`a0.mhed_invariants.D_MAX_DELEGATION` — corpus delegation
    cap (existing).

What this module ADDS (net-new, not duplication):

  1. Concatenation of per-repo catalogs into a union with
     ``origin_repo`` annotation on every card.
  2. **Cross-repo boost** in ranking: chains whose members span ≥2
     origin repos get a +crosses_repos score bonus (the "find what
     no single repo expresses" signal that gives forge its
     cross-portfolio differentiation).
  3. SOTA-aligned **confidence-tiered annotations** on each chain
     (matches Codebase-Memory MCP / Repowise patterns from 2026
     research): every chain edge now carries an
     ``edge_confidence`` ∈ {static_typed, ast_inferred,
     text_matched} so consumers know how trustworthy the
     composition is without a separate query.

D_max = 23 enforced for portfolio scale (corpus sovereign invariant).
"""
from __future__ import annotations

import math
from collections import Counter
from pathlib import Path
from typing import Any

from ..a0_qk_constants.mhed_invariants import D_MAX_DELEGATION
from ..a1_at_functions.emergent_compose import find_chains
from ..a1_at_functions.emergent_rank import rank_chains
from ..a1_at_functions.emergent_signature_extract import harvest_signatures

SCHEMA_VERSION_EMERGENT_SWARM_V1 = "atomadic-forge.emergent_swarm/v1"


def emergent_swarm(
    repos: list[tuple[Path, str]],
    *,
    top_n: int = 25,
    max_depth: int = 3,
    max_chains: int = 5_000,
    require_pure: bool = False,
    domain_jump_required: bool = True,
    cross_repo_bonus: float = 15.0,
    corroborate_with_call_graph: bool = True,
) -> dict[str, Any]:
    """Run emergent composition discovery over N≤D_max repos.

    Args:
        repos: list of ``(src_root, package_name)`` tuples — one per
            repo to include in the swarm. ``src_root`` typically
            points at ``<repo>/src/<package>``.
        top_n: max candidates returned (default 25).
        max_depth: max chain length (default 3).
        max_chains: cap on chain enumeration (default 5000).
        require_pure: only consider pure chains (default False).
        domain_jump_required: only chains crossing ≥2 domains.
        cross_repo_bonus: score bonus per extra origin_repo a chain
            spans (default 15.0). Tunable so callers can favor or
            de-emphasize cross-repo findings.

    Returns:
        Dict with ``schema_version``, ``repo_count``, ``union_catalog_size``,
        ``candidates`` (with ``origin_repos`` + ``crosses_repos`` +
        ``edge_confidence`` annotations), plus repo-level summary.

    Raises:
        ValueError: if ``len(repos) > D_MAX_DELEGATION``. Codex-anchored
            cap; fail-loud not silent-truncate.
    """
    if len(repos) > D_MAX_DELEGATION:
        raise ValueError(
            f"emergent_swarm: requested {len(repos)} repos exceeds the "
            f"system delegation depth cap of {D_MAX_DELEGATION}. Analytical "
            f"recursion deeper than {D_MAX_DELEGATION} is forbidden by a "
            f"system invariant. Split the swarm into multiple "
            f"<={D_MAX_DELEGATION}-repo passes."
        )
    if not repos:
        return {
            "schema_version": SCHEMA_VERSION_EMERGENT_SWARM_V1,
            "repo_count": 0,
            "union_catalog_size": 0,
            "candidates": [],
            "per_repo": [],
            "d_max_cap": D_MAX_DELEGATION,
        }

    # ── 1. Concatenate per-repo catalogs with origin annotations ─────
    union_catalog: list[dict[str, Any]] = []
    per_repo_summary: list[dict[str, Any]] = []
    qualname_to_origin: dict[str, str] = {}

    for src_root, package in repos:
        src_root = Path(src_root).resolve()
        if not src_root.exists():
            per_repo_summary.append({
                "src_root": str(src_root), "package": package,
                "exists": False, "card_count": 0,
            })
            continue
        cards = harvest_signatures(src_root, package)
        per_repo_summary.append({
            "src_root": str(src_root), "package": package,
            "exists": True, "card_count": len(cards),
        })
        for card in cards:
            tagged = dict(card)
            tagged["origin_repo"] = package
            tagged["origin_src_root"] = str(src_root)
            union_catalog.append(tagged)
            qualname = tagged.get("qualname", "")
            if qualname and qualname not in qualname_to_origin:
                qualname_to_origin[qualname] = package

    # ── 2. Run composition discovery on the union ────────────────────
    chains = find_chains(
        union_catalog,
        max_depth=max_depth,
        max_chains=max_chains,
        require_pure=require_pure,
        domain_jump_required=domain_jump_required,
    )

    # ── 3. Rank with cross-repo boost ────────────────────────────────
    # The rank_chains helper takes catalog + a3_feature_stems (for
    # de-prioritizing already-implemented features). We don't have a
    # canonical a3 surface for the union, so we pass an empty list —
    # cross-repo by definition surfaces patterns no single repo wires.
    candidates = rank_chains(
        chains, catalog=union_catalog, top_n=top_n * 2,
        a3_feature_stems=[],
    )

    # ── Cycle 2 sharpening: cross-validation pre-pass ────────────────
    # SOTA pattern (LogicLens / SemanticForge three-phase
    # reconciliation): elevate confidence for chain edges that ALSO
    # appear as caller→callee edges in a static call-graph walk. v1
    # reported all edges as `ast_inferred`; v2 promotes corroborated
    # edges to `static_call_confirmed`. Run only when caller asks
    # (it's another N-file walk per repo) so single-repo runs that
    # don't need cross-validation stay snappy.
    call_graph_edges: dict[str, set[str]] = {}
    if corroborate_with_call_graph:
        from ..a1_at_functions.call_graph import _walk_package_edges
        for src_root, package in repos:
            sr = Path(src_root).resolve()
            if not sr.exists():
                continue
            try:
                edges = _walk_package_edges(sr, package=package)
            except Exception:  # noqa: BLE001 — corroboration is best-effort
                continue
            for caller, callees in edges.items():
                call_graph_edges.setdefault(caller, set()).update(callees)

    def _edge_corroborated(caller: str, callee: str) -> bool:
        return callee in call_graph_edges.get(caller, set())

    # Annotate each candidate with origin_repos + crosses_repos +
    # edge_confidence. Boost the score by `cross_repo_bonus` per extra
    # origin_repo — that's the "no single repo expresses this" signal.
    annotated: list[dict[str, Any]] = []
    for c in candidates:
        chain_members = c.get("chain", {}).get("chain", [])
        origins = [
            qualname_to_origin.get(m, "?") for m in chain_members
        ]
        unique_origins = sorted(set(origins) - {"?"})
        crosses_repos = max(0, len(unique_origins) - 1)
        boosted_score = float(c.get("score", 0)) + crosses_repos * cross_repo_bonus

        # Per-edge confidence tiers (SOTA Codebase-Memory MCP pattern).
        # An edge is `static_call_confirmed` when call_graph also sees
        # the call relationship; otherwise it stays `ast_inferred`
        # (the chain was suggested by type-flow analysis but no actual
        # call edge exists in the source — likely the "novel" case
        # emergent_scan is built to surface).
        per_edge_confidence: list[str] = []
        if len(chain_members) >= 2 and corroborate_with_call_graph:
            for i in range(len(chain_members) - 1):
                if _edge_corroborated(chain_members[i], chain_members[i + 1]):
                    per_edge_confidence.append("static_call_confirmed")
                else:
                    per_edge_confidence.append("ast_inferred")
        else:
            per_edge_confidence = ["ast_inferred"] * max(0, len(chain_members) - 1)
        # Aggregate: chain confidence = highest of its edges. A chain
        # with even one corroborated edge is more trustworthy than one
        # with zero.
        if "static_call_confirmed" in per_edge_confidence:
            edge_confidence = "static_call_confirmed"
        else:
            edge_confidence = "ast_inferred"

        # The novelty signal: chains whose edges are NOT call-graph
        # corroborated are the prime "no canonical code path wires
        # this" candidates — exactly what emergent_scan is designed
        # to find. Surface this as a separate boolean for filtering.
        novel_composition = (
            corroborate_with_call_graph
            and edge_confidence == "ast_inferred"
            and len(chain_members) >= 2
        )

        annotated.append({
            **c,
            "origin_repos": unique_origins,
            "crosses_repos": crosses_repos,
            "score_boosted": round(boosted_score, 1),
            "edge_confidence": edge_confidence,
            "per_edge_confidence": per_edge_confidence,
            "novel_composition": novel_composition,
        })

    # Hub-node penalty: a symbol present in many chains biases top-N toward
    # a single connector.  Penalise by PENALTY_PER_DOUBLING for each doubling
    # of cross-chain frequency above HUB_THRESHOLD.
    _HUB_THRESHOLD = 3
    _PENALTY_PER_DOUBLING = 15.0
    _sym_freq: Counter[str] = Counter()
    for _c in annotated:
        for _sym in set(_c.get("chain", {}).get("chain", [])):
            _sym_freq[_sym] += 1
    for _c in annotated:
        _chain_syms = _c.get("chain", {}).get("chain", [])
        if not _chain_syms:
            continue
        _max_freq = max(_sym_freq.get(_sym, 0) for _sym in _chain_syms)
        if _max_freq > _HUB_THRESHOLD:
            _penalty = (
                math.floor(math.log2(_max_freq / _HUB_THRESHOLD))
                * _PENALTY_PER_DOUBLING
            )
            _c["score_boosted"] = max(0.0, round(_c["score_boosted"] - _penalty, 1))
            _c["hub_penalty"] = round(_penalty, 1)
            _c["hub_max_symbol_freq"] = _max_freq

    annotated.sort(
        key=lambda c: (-c["score_boosted"], -c["crosses_repos"]),
    )

    # Chain-prefix deduplication: when multiple candidates share the same
    # first (N-1) symbols, keep only the highest-scoring one per prefix.
    # This prevents a single hub-connector generating top-N variations that
    # differ only in their final hop (e.g. 25x the same auth→github→* chain).
    _PREFIX_DEPTH = 2
    _seen_prefixes: set[tuple[str, ...]] = set()
    _deduped: list[dict] = []
    for _c in annotated:
        _syms = _c.get("chain", {}).get("chain", [])
        _prefix = tuple(_syms[:_PREFIX_DEPTH]) if len(_syms) >= _PREFIX_DEPTH else tuple(_syms)
        if _prefix not in _seen_prefixes:
            _seen_prefixes.add(_prefix)
            _deduped.append(_c)
    annotated = _deduped[:top_n]

    # ── 4. Domain inventory across the union ─────────────────────────
    domain_inv: Counter[str] = Counter(
        c.get("domain", "?") for c in union_catalog
    )
    tier_inv: Counter[str] = Counter(
        c.get("tier", "?") for c in union_catalog
    )

    return {
        "schema_version": SCHEMA_VERSION_EMERGENT_SWARM_V1,
        "repo_count": len(repos),
        "union_catalog_size": len(union_catalog),
        "chain_count_considered": len(chains),
        "candidates": annotated,
        "candidate_count": len(annotated),
        "per_repo": per_repo_summary,
        "domain_inventory": dict(domain_inv),
        "tier_inventory": dict(tier_inv),
        "cross_repo_chain_count": sum(
            1 for c in annotated if c["crosses_repos"] >= 1
        ),
        "novel_composition_count": sum(
            1 for c in annotated if c.get("novel_composition")
        ),
        "static_confirmed_count": sum(
            1 for c in annotated
            if c.get("edge_confidence") == "static_call_confirmed"
        ),
        "corroborate_with_call_graph": corroborate_with_call_graph,
        "d_max_cap": D_MAX_DELEGATION,
        "cross_repo_bonus": cross_repo_bonus,
    }
