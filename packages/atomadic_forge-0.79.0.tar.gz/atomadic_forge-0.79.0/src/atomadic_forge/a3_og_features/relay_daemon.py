"""Tier a3 — local relay daemon ("no-stubs fully forge-compatible" v0.14).

The Worker MCP at ``forge.atomadic.tech/mcp`` has 12 stubs that can't
run because they need filesystem / git access. The relay daemon
closes that gap: a thin HTTP service running on the user's machine
(or any machine with forge installed) that receives signed job
requests and dispatches them through the local CLI.

Architecture (v0.14.0-alpha — local side):

    Worker MCP                      forge-runner satellite (this)
    ├─ tool_call("plan_apply")  ──► POST /relay/jobs
    │                                ├─ verify identity claim
    │                                ├─ dispatch via existing
    │                                │   mcp_protocol.dispatch_request
    │                                ├─ append signed result to
    │                                │   .atomadic-forge/relay/jobs.jsonl
    │                                └─ POST result back (or KV poll)
    └─◄ result envelope        ─────┘

For v0.14.0-alpha this module ships:
* ``serve_http`` — thin stdlib HTTP server on a configurable port
* ``handle_job`` — pure dispatch over a parsed job dict
* ``append_job_result`` — IO for the job log

The Worker-side enqueue + signed-result-return is in the
atomadic-forge-cloudflare-workers repo (gated by Thomas sign-off
per AGENT_COLLAB_PROTOCOL §3).
"""
from __future__ import annotations

import json
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any

from ..a1_at_functions.mcp_protocol import dispatch_request

SCHEMA_VERSION_RELAY_JOB_V1 = "atomadic-forge.relay_job/v1"

RELAY_DIR_REL = ".atomadic-forge/relay"
RELAY_LOG_REL = ".atomadic-forge/relay/jobs.jsonl"


def relay_log_path(project_root: Path) -> Path:
    return Path(project_root) / RELAY_LOG_REL


def append_job_result(project_root: Path,
                       job_record: dict[str, Any]) -> Path:
    """Append one job execution record to the relay log."""
    path = relay_log_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(job_record, default=str, ensure_ascii=False))
        f.write("\n")
    return path


def handle_job(
    *,
    project_root: Path,
    job: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch one relay job. Returns the result + audit record.

    The job is shaped exactly like a JSON-RPC tools/call request
    so the relay reuses the dispatcher unchanged.

    Job envelope:
        {
            "jsonrpc": "2.0",
            "id": <int|str>,
            "method": "tools/call",
            "params": {"name": "<tool_name>", "arguments": {...}},
            "identity_claim": "<opaque token>",  # logged, not verified
        }
    """
    started = time.time()
    identity = job.get("identity_claim")
    rpc = {
        "jsonrpc": job.get("jsonrpc", "2.0"),
        "id": job.get("id", 1),
        "method": job.get("method", "tools/call"),
        "params": job.get("params", {}),
    }
    try:
        resp = dispatch_request(rpc, project_root=project_root)
        ok = True
        err = None
    except Exception as exc:  # noqa: BLE001 — relay swallows + logs
        resp = None
        ok = False
        err = f"{type(exc).__name__}: {exc}"

    record = {
        "schema_version": SCHEMA_VERSION_RELAY_JOB_V1,
        "started_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                          time.gmtime(started)),
        "duration_ms": int((time.time() - started) * 1000),
        "ok": ok,
        "identity_claim": identity,
        "method": rpc["method"],
        "tool_name": (rpc.get("params") or {}).get("name"),
        "response": resp,
        "error": err,
    }
    append_job_result(project_root, record)
    return record


# ── HTTP server (stdlib only — no extra deps) ──────────────────────


class _RelayHandler(BaseHTTPRequestHandler):
    project_root: Path = Path(".")

    def log_message(self, format: str, *args) -> None:  # noqa: A002
        # Quiet by default — we have our own log on disk.
        return

    def do_POST(self) -> None:  # noqa: N802 — stdlib API
        if self.path != "/relay/jobs":
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b'{"error":"unknown path"}')
            return
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length) if length else b"{}"
        try:
            job = json.loads(body or b"{}")
        except json.JSONDecodeError as exc:
            self.send_response(400)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"error": f"bad json: {exc}"}).encode("utf-8"))
            return
        record = handle_job(project_root=self.project_root, job=job)
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(record, default=str).encode("utf-8"))

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/relay/health":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({
                "schema_version": "atomadic-forge.relay_health/v1",
                "ok": True,
                "project_root": str(self.project_root),
            }).encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()


def serve_http(
    *,
    project_root: Path,
    host: str = "127.0.0.1",
    port: int = 7409,
) -> dict[str, Any]:
    """Run the relay HTTP server until interrupted (CLI-side blocking call).

    For agents wiring this programmatically, call ``handle_job``
    directly — the HTTP shell is a convenience for human operators.
    """
    handler_cls = type(
        "_BoundRelayHandler",
        (_RelayHandler,),
        {"project_root": Path(project_root).resolve()},
    )
    server = HTTPServer((host, port), handler_cls)
    print(f"forge relay listening on http://{host}:{port}/relay/jobs  "
           f"(project_root={server.RequestHandlerClass.project_root})")
    print(f"  health: GET  http://{host}:{port}/relay/health")
    print(f"  log:    {relay_log_path(server.RequestHandlerClass.project_root)}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()
    return {
        "schema_version": "atomadic-forge.relay_serve/v1",
        "stopped": True,
        "host": host, "port": port,
    }
