"""Tier a3 — Compose-Not-Add (CNA) compliance gate.

Hardwires the "never reinvent the wheel" principle into the pipeline.
Given a proposed change (new symbol name, optional source body), this
gate checks the existing codebase for:

  1. **Name overlap** — any existing symbol whose tokenized name has
     high Jaccard / difflib similarity to the proposed name.
     Composes :func:`a1.intent_similarity.similarity`.

  2. **Body overlap** — when source is supplied, AST-hashes the
     function and looks for any existing function with the same shape
     hash. Composes :func:`a1.code_signature.signature_of`.

  3. **Module-level overlap** — at module/feature granularity, calls
     the existing dedup engine and surfaces hits.
     Composes :func:`a3.dedup_engine.dedup_code_tree`.

Three findings buckets, one synthesized verdict:

  * **PASS**  — no overlaps above thresholds; safe to add.
  * **REFINE** — one or more overlaps in soft band; reviewer should
                 either reuse the existing symbol or justify the
                 divergence in the commit message.
  * **REJECT** — overlaps in hard band; do not add. Reuse the
                 existing primitive.

This file is itself a CNA exemplar: every detector composes an
existing a1/a3 primitive. The only new code here is the verdict-
synthesis state machine — and that's net-new behaviour, not
duplication.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from ..a1_at_functions import intent_similarity
from ..a1_at_functions.code_signature import signature_of
from ..a1_at_functions.scout_walk import harvest_repo
from .dedup_engine import dedup_code_tree

SCHEMA_VERSION_CNA_CHECK_V1 = "atomadic-forge.cna_check/v1"


@dataclass
class NameOverlapFinding:
    proposed_name: str
    existing_qualname: str
    similarity: float
    band: str  # "hard" | "soft"


@dataclass
class BodyOverlapFinding:
    proposed_name: str
    existing_qualname: str
    body_hash: str
    file: str


@dataclass
class ModuleOverlapFinding:
    canonical_module: str
    duplicates: list[str]
    reason: str


@dataclass
class CnaCheckReport:
    schema_version: str = SCHEMA_VERSION_CNA_CHECK_V1
    project_root: str = ""
    proposed_name: str = ""
    proposed_body_present: bool = False
    name_overlaps: list[NameOverlapFinding] = field(default_factory=list)
    body_overlaps: list[BodyOverlapFinding] = field(default_factory=list)
    module_overlaps: list[ModuleOverlapFinding] = field(default_factory=list)
    verdict: str = "PASS"
    next_command: str = ""
    summary: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "project_root": self.project_root,
            "proposed_name": self.proposed_name,
            "proposed_body_present": self.proposed_body_present,
            "name_overlaps": [asdict(f) for f in self.name_overlaps],
            "body_overlaps": [asdict(f) for f in self.body_overlaps],
            "module_overlaps": [asdict(f) for f in self.module_overlaps],
            "verdict": self.verdict,
            "next_command": self.next_command,
            "summary": self.summary,
        }


# Threshold bands for name similarity. Above hard → REJECT.
# Between soft and hard → REFINE. Below soft → PASS (this finding).
NAME_HARD_BAND: float = 0.85
NAME_SOFT_BAND: float = 0.65


def cna_check(
    *,
    project_root: Path,
    proposed_name: str,
    proposed_body: str | None = None,
    package_subdir: str | None = None,
    name_top_n: int = 10,
) -> CnaCheckReport:
    """Run the three-detector CNA gate.

    Args:
        project_root: repo root.
        proposed_name: bare or dotted name of the proposed new symbol.
        proposed_body: optional Python source string for the proposed
            function. When supplied, AST-hashes it for body overlap
            detection.
        package_subdir: optional subdir under project_root to search
            (e.g. ``"src/mypkg"``); when None, scans project_root.
        name_top_n: limit name-overlap findings to the top N by
            similarity score (default 10).

    Returns:
        :class:`CnaCheckReport` with three findings sections + a
        synthesized verdict + a recommended ``next_command``.
    """
    project_root = Path(project_root).resolve()
    walk_root = (project_root / package_subdir) if package_subdir else project_root
    if not walk_root.exists():
        return CnaCheckReport(
            project_root=str(project_root),
            proposed_name=proposed_name,
            verdict="REFINE",
            summary=(f"package_subdir {package_subdir!r} does not exist; "
                       "ran with no findings"),
            next_command=("# verify package_subdir before applying any "
                            "CNA finding"),
        )

    # --- Name-overlap detector (composes intent_similarity) ----------
    scout = harvest_repo(walk_root)
    bare_proposed = proposed_name.split(".")[-1]
    name_findings: list[NameOverlapFinding] = []
    for sym in scout.get("symbols", []):
        existing_qual = sym.get("qualname", "")
        existing_bare = existing_qual.split(".")[-1] if existing_qual else ""
        if not existing_bare or existing_bare == bare_proposed:
            # Exact match is the strongest signal; tag it hard.
            if existing_bare and existing_bare == bare_proposed:
                name_findings.append(NameOverlapFinding(
                    proposed_name=proposed_name,
                    existing_qualname=existing_qual,
                    similarity=1.0,
                    band="hard",
                ))
            continue
        result = intent_similarity.similarity(bare_proposed, existing_bare)
        score = float(result.score)
        if score >= NAME_HARD_BAND:
            name_findings.append(NameOverlapFinding(
                proposed_name=proposed_name,
                existing_qualname=existing_qual,
                similarity=round(score, 3),
                band="hard",
            ))
        elif score >= NAME_SOFT_BAND:
            name_findings.append(NameOverlapFinding(
                proposed_name=proposed_name,
                existing_qualname=existing_qual,
                similarity=round(score, 3),
                band="soft",
            ))
    name_findings.sort(key=lambda f: -f.similarity)
    name_findings = name_findings[:name_top_n]

    # --- Body-overlap detector (composes code_signature) -------------
    body_findings: list[BodyOverlapFinding] = []
    if proposed_body and proposed_body.strip():
        try:
            proposed_sig = signature_of(proposed_body)
        except Exception:  # noqa: BLE001
            proposed_sig = None
        if proposed_sig and proposed_sig.parse_ok:
            for f in walk_root.rglob("*.py"):
                if "__pycache__" in f.parts:
                    continue
                try:
                    text = f.read_text(encoding="utf-8", errors="replace")
                    sig = signature_of(text)
                except (OSError, ValueError):
                    continue
                if not sig.parse_ok:
                    continue
                if sig.module_hash == proposed_sig.module_hash:
                    body_findings.append(BodyOverlapFinding(
                        proposed_name=proposed_name,
                        existing_qualname=str(f.relative_to(walk_root).as_posix()),
                        body_hash=sig.module_hash,
                        file=str(f.relative_to(walk_root).as_posix()),
                    ))

    # --- Module-overlap detector (composes dedup_engine) -------------
    module_findings: list[ModuleOverlapFinding] = []
    try:
        dup_groups, _novel = dedup_code_tree(walk_root)
    except Exception:  # noqa: BLE001
        dup_groups = []
    for group in dup_groups:
        if group.module_hash == "__truncated__":
            continue
        canonical = str(group.canonical)
        # Surface the proposed-name hint when the module name shares a
        # token with the proposed name — most targeted first.
        bare = bare_proposed.lower()
        if bare and bare in canonical.lower():
            module_findings.append(ModuleOverlapFinding(
                canonical_module=canonical,
                duplicates=list(group.duplicates),
                reason=group.reason,
            ))

    # --- Verdict synthesis -------------------------------------------
    verdict = "PASS"
    if any(f.band == "hard" for f in name_findings) or body_findings:
        verdict = "REJECT"
    elif name_findings or module_findings:
        verdict = "REFINE"

    # Pick the single most actionable next_command.
    if verdict == "REJECT":
        if body_findings:
            f = body_findings[0]
            next_command = (
                f"# REJECT: identical body to {f.existing_qualname}. "
                "Reuse it instead of creating a new symbol."
            )
        else:
            f = next(x for x in name_findings if x.band == "hard")
            next_command = (
                f"# REJECT: name {proposed_name!r} collides with "
                f"existing {f.existing_qualname!r} (similarity "
                f"{f.similarity}). Reuse or pick a distinct name."
            )
    elif verdict == "REFINE":
        if name_findings:
            f = name_findings[0]
            next_command = (
                f"# REFINE: {proposed_name!r} resembles "
                f"{f.existing_qualname!r} (similarity {f.similarity}). "
                "Justify the divergence in the commit message OR reuse."
            )
        else:
            next_command = (
                "# REFINE: module-level overlap detected; review the "
                "dedup_engine findings."
            )
    else:
        next_command = "# PASS: no CNA overlaps found; safe to add."

    summary = (
        f"verdict={verdict}; "
        f"name_overlaps={len(name_findings)} "
        f"(hard={sum(1 for f in name_findings if f.band == 'hard')}); "
        f"body_overlaps={len(body_findings)}; "
        f"module_overlaps={len(module_findings)}"
    )

    return CnaCheckReport(
        project_root=str(project_root),
        proposed_name=proposed_name,
        proposed_body_present=bool(proposed_body and proposed_body.strip()),
        name_overlaps=name_findings,
        body_overlaps=body_findings,
        module_overlaps=module_findings,
        verdict=verdict,
        next_command=next_command,
        summary=summary,
    )
