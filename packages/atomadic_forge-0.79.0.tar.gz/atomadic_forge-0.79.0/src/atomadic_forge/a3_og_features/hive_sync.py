"""Tier a3 — hive sync pipeline orchestrator.

Composes a1 hive_io + hive_consensus_math + a0 hive_constants into the
public hive surface (CLI + MCP). The "perfect hive sync collaboration
pipeline into the Forge" Thomas named — register-and-discover for any
agent activating against the protocol.

Five public ops:
* ``register_agent``        — append agent registration
* ``list_agents``           — read the registry
* ``deactivate_agent``      — append a deactivation marker
* ``observe``               — return events relevant to an agent's
                              subscriptions (since a cursor)
* ``propose_consensus``     — open a consensus proposal
* ``vote_consensus``        — append a vote
* ``resolve_consensus``     — compute (and optionally record) a verdict
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ..a0_qk_constants.hive_constants import (
    D_MAX_AGENTS,
    DEFAULT_CONSENSUS_QUORUM_MIN,
    DEFAULT_CONSENSUS_TIMEOUT_SECS,
    SCHEMA_VERSION_HIVE_OBSERVE_V1,
    SCHEMA_VERSION_HIVE_REGISTRY_V1,
)
from ..a1_at_functions.hive_consensus_math import resolve_consensus as _resolve
from ..a1_at_functions.hive_io import (
    active_agents,
    append_agent,
    append_consensus,
    consensus_events_for,
    hive_agents_file,
    hive_consensus_file,
    iter_consensus,
    load_agents,
    make_agent_entry,
    make_consensus_event,
)

# ── Agent registry ───────────────────────────────────────────────────

def register_agent(
    *,
    project_root: Path,
    agent_name: str,
    role: str,
    capabilities: list[str] | None = None,
    subscribes_to: list[str] | None = None,
    write_lanes: list[str] | None = None,
    identity_claim: str | None = None,
    notes: str | None = None,
) -> dict[str, Any]:
    """Register an agent into the hive. Refuses past D_MAX_AGENTS."""
    current = active_agents(project_root)
    if len(current) >= D_MAX_AGENTS:
        raise ValueError(
            f"hive: registry full ({len(current)} agents). "
            f"D_max delegation cap = {D_MAX_AGENTS}. "
            f"Deactivate an existing agent before registering a new one."
        )
    entry = make_agent_entry(
        agent_name=agent_name, role=role,
        capabilities=capabilities, subscribes_to=subscribes_to,
        write_lanes=write_lanes, identity_claim=identity_claim, notes=notes,
    )
    path = append_agent(project_root, entry)
    return {
        "schema_version": SCHEMA_VERSION_HIVE_REGISTRY_V1,
        "registered": True,
        "entry": entry,
        "registry_file": str(path),
        "active_count": len(current) + 1,
        "d_max_cap": D_MAX_AGENTS,
    }


def list_agents(*, project_root: Path,
                include_deactivated: bool = False) -> dict[str, Any]:
    if include_deactivated:
        agents = load_agents(project_root)
    else:
        agents = active_agents(project_root)
    return {
        "schema_version": SCHEMA_VERSION_HIVE_REGISTRY_V1,
        "registry_file": str(hive_agents_file(project_root)),
        "agent_count": len(agents),
        "agents": agents,
    }


def deactivate_agent(*, project_root: Path,
                     agent_name: str) -> dict[str, Any]:
    """Mark an agent inactive (appends a new entry; old stays for audit)."""
    current = active_agents(project_root)
    match = next((a for a in current if a.get("agent_name") == agent_name), None)
    if not match:
        return {
            "schema_version": SCHEMA_VERSION_HIVE_REGISTRY_V1,
            "deactivated": False,
            "reason": f"no active agent named {agent_name!r}",
        }
    deact = make_agent_entry(
        agent_name=agent_name,
        role=match.get("role", "unknown"),
        capabilities=match.get("capabilities", []),
        subscribes_to=match.get("subscribes_to", []),
        write_lanes=match.get("write_lanes", []),
        identity_claim=match.get("identity_claim"),
        notes=f"deactivated; supersedes {match.get('id')}",
    )
    deact["active"] = False
    deact["supersedes"] = match.get("id")
    path = append_agent(project_root, deact)
    return {
        "schema_version": SCHEMA_VERSION_HIVE_REGISTRY_V1,
        "deactivated": True,
        "entry": deact,
        "registry_file": str(path),
    }


# ── Observe ──────────────────────────────────────────────────────────

def observe(
    *,
    project_root: Path,
    agent_name: str | None = None,
    since_consensus_id: str | None = None,
    since_wisdom_id: str | None = None,
    limit: int = 50,
) -> dict[str, Any]:
    """Return events relevant to an agent's subscriptions, paged.

    v0.13.4: extended from consensus-only to multi-source. Surfaces
    consensus events + new wisdom entries + superseded wisdom +
    (future) commit-to-main events, all filtered by the agent's
    declared ``subscribes_to`` set. Two cursors:

    * ``since_consensus_id`` — last consensus event seen (any kind)
    * ``since_wisdom_id`` — last wisdom entry seen

    An agent that subscribes to ``wisdom.new`` AND
    ``consensus.proposed`` gets both streams in one call, ordered
    deterministically by event timestamp.
    """
    from ..a0_qk_constants.hive_constants import (
        EVENT_CONSENSUS_PROPOSED,
        EVENT_CONSENSUS_RESOLVED,
        EVENT_NEW_WISDOM,
        EVENT_SUPERSEDED_WISDOM,
    )
    from .wisdom_feature import list_wisdom

    agents = active_agents(project_root)
    me = next((a for a in agents if a.get("agent_name") == agent_name), None)
    subs: set[str] = set(me.get("subscribes_to", []) if me else [])

    events: list[dict[str, Any]] = []

    # ── Consensus stream ────────────────────────────────────────────
    if (not subs) or any(s.startswith("consensus.") for s in subs):
        cursor_seen = since_consensus_id is None
        for ev in iter_consensus(project_root):
            if not cursor_seen:
                if ev.get("consensus_id") == since_consensus_id:
                    cursor_seen = True
                continue
            kind = ev.get("kind")
            if kind == "proposal" and EVENT_CONSENSUS_PROPOSED in subs:
                events.append({**ev, "_event_type": EVENT_CONSENSUS_PROPOSED,
                                "_source": "consensus"})
            elif kind == "vote":
                # Votes go to anyone subscribed to either proposed
                # OR resolved (they're part of the deliberation).
                if EVENT_CONSENSUS_PROPOSED in subs or EVENT_CONSENSUS_RESOLVED in subs:
                    events.append({**ev, "_event_type": "consensus.vote",
                                    "_source": "consensus"})
            elif kind == "resolution" and EVENT_CONSENSUS_RESOLVED in subs:
                events.append({**ev, "_event_type": EVENT_CONSENSUS_RESOLVED,
                                "_source": "consensus"})
            # Honor an empty subs set as "give me everything" for
            # backwards-compat with v0.13.2 callers.
            if not subs and kind:
                events[-1] = {**ev, "_event_type": f"consensus.{kind}",
                               "_source": "consensus"}

    # ── Wisdom stream ──────────────────────────────────────────────
    if (not subs) or EVENT_NEW_WISDOM in subs or EVENT_SUPERSEDED_WISDOM in subs:
        wis = list_wisdom(project_root=project_root, include_superseded=True)
        cursor_seen = since_wisdom_id is None
        for entry in wis.get("entries", []):
            if not cursor_seen:
                if entry.get("id") == since_wisdom_id:
                    cursor_seen = True
                continue
            ev_type = (
                EVENT_SUPERSEDED_WISDOM
                if entry.get("supersedes")
                else EVENT_NEW_WISDOM
            )
            if (not subs) or ev_type in subs:
                events.append({
                    "_event_type": ev_type,
                    "_source": "wisdom",
                    "id": entry.get("id"),
                    "timestamp_utc": entry.get("timestamp_utc"),
                    "agent_name": entry.get("agent_name"),
                    "scope": entry.get("scope"),
                    "tags": entry.get("tags"),
                    "insight": entry.get("insight"),
                    "supersedes": entry.get("supersedes"),
                })

    # Stable ordering: by timestamp, then by source.
    def _ts(ev: dict[str, Any]) -> str:
        return ev.get("timestamp_utc") or ""
    events.sort(key=lambda e: (_ts(e), e.get("_source", "")))
    events = events[:limit]

    return {
        "schema_version": SCHEMA_VERSION_HIVE_OBSERVE_V1,
        "agent_name": agent_name,
        "subscriptions": sorted(subs),
        "active_agent_count": len(agents),
        "event_count": len(events),
        "events": events,
        "consensus_log": str(hive_consensus_file(project_root)),
        "since_consensus_id": since_consensus_id,
        "since_wisdom_id": since_wisdom_id,
    }


# ── Consensus ────────────────────────────────────────────────────────

def propose_consensus(
    *,
    project_root: Path,
    intent: str,
    proposer: str,
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Open a consensus proposal. Returns the consensus_id."""
    if not intent or not proposer:
        raise ValueError("propose_consensus: intent + proposer required")
    ev = make_consensus_event(
        kind="proposal", intent=intent, proposer=proposer, payload=payload,
    )
    append_consensus(project_root, ev)
    return {
        "schema_version": ev["schema_version"],
        "proposed": True,
        "event": ev,
        "consensus_id": ev["consensus_id"],
    }


def vote_consensus(
    *,
    project_root: Path,
    consensus_id: str,
    voter: str,
    vote: str,
    rationale: str | None = None,
) -> dict[str, Any]:
    """Append a vote to an existing consensus."""
    if vote not in {"approve", "reject", "refine", "abstain"}:
        raise ValueError(f"vote must be approve|reject|refine|abstain, got {vote!r}")
    ev = make_consensus_event(
        kind="vote", consensus_id=consensus_id, voter=voter,
        vote=vote, rationale=rationale,
    )
    append_consensus(project_root, ev)
    return {
        "schema_version": ev["schema_version"],
        "voted": True,
        "event": ev,
    }


def consensus_recap(
    *,
    project_root: Path,
    consensus_id: str,
) -> dict[str, Any]:
    """Full lifecycle of one consensus — proposal + every vote +
    resolution if any — plus a summary block (verdict if known,
    seconds-to-resolve, vote-count, voter list).

    Pure read. The "show me everything that happened with CNS-X"
    primitive — pairs with ``hive watch`` (live-tail) and
    ``hive_result`` (just the verdict).
    """
    events = consensus_events_for(project_root, consensus_id)
    if not events:
        return {
            "schema_version": SCHEMA_VERSION_HIVE_OBSERVE_V1,
            "consensus_id": consensus_id,
            "found": False,
            "reason": "no events for this consensus_id",
        }
    proposal = next((e for e in events if e.get("kind") == "proposal"), None)
    votes = [e for e in events if e.get("kind") == "vote"]
    resolution = next((e for e in events if e.get("kind") == "resolution"), None)
    proposed_at = (proposal or {}).get("timestamp_utc")
    resolved_at = (resolution or {}).get("timestamp_utc")
    duration_secs: float | None = None
    if proposed_at and resolved_at:
        try:
            import time
            t0 = time.mktime(time.strptime(proposed_at, "%Y-%m-%dT%H:%M:%SZ"))
            t1 = time.mktime(time.strptime(resolved_at, "%Y-%m-%dT%H:%M:%SZ"))
            duration_secs = max(0.0, t1 - t0)
        except (ValueError, TypeError):
            duration_secs = None

    verdict = (resolution or {}).get("payload", {}).get("verdict")
    counts = {"approve": 0, "reject": 0, "refine": 0, "abstain": 0}
    latest_per_voter: dict[str, str] = {}
    for v in votes:
        voter = v.get("voter")
        if voter:
            latest_per_voter[voter] = (v.get("vote") or "abstain").lower()
    for value in latest_per_voter.values():
        if value in counts:
            counts[value] += 1
        else:
            counts["abstain"] += 1

    return {
        "schema_version": SCHEMA_VERSION_HIVE_OBSERVE_V1,
        "consensus_id": consensus_id,
        "found": True,
        "intent": (proposal or {}).get("intent"),
        "proposer": (proposal or {}).get("proposer"),
        "proposed_at": proposed_at,
        "resolved": resolution is not None,
        "resolved_at": resolved_at,
        "duration_secs": duration_secs,
        "verdict": verdict,
        "vote_count": len(latest_per_voter),
        "tally": counts,
        "voters": sorted(latest_per_voter.keys()),
        "events": events,
    }


def needs_vote_from(
    *,
    project_root: Path,
    agent_name: str,
) -> dict[str, Any]:
    """Return open consensuses where ``agent_name`` hasn't voted yet.

    Pure read: walks the consensus log, finds proposals without
    matching resolution, filters out those where this agent has
    already voted. The "what should I weigh in on" primitive — closes
    the gap between observe (what's happening) and the act of voting.
    """
    by_id: dict[str, list[dict[str, Any]]] = {}
    for ev in iter_consensus(project_root):
        cid = ev.get("consensus_id")
        if not cid:
            continue
        by_id.setdefault(cid, []).append(ev)
    pending: list[dict[str, Any]] = []
    for cid, events in by_id.items():
        proposal = next((e for e in events if e.get("kind") == "proposal"), None)
        if proposal is None:
            continue
        already_resolved = any(e.get("kind") == "resolution" for e in events)
        if already_resolved:
            continue
        already_voted = any(
            e.get("kind") == "vote" and e.get("voter") == agent_name
            for e in events
        )
        if already_voted:
            continue
        # Tally so far so the caller has context
        votes = [e for e in events if e.get("kind") == "vote"]
        pending.append({
            "consensus_id": cid,
            "intent": proposal.get("intent"),
            "proposer": proposal.get("proposer"),
            "proposed_at": proposal.get("timestamp_utc"),
            "votes_so_far": len(votes),
            "voters_so_far": [v.get("voter") for v in votes],
        })
    pending.sort(key=lambda p: p.get("proposed_at") or "")
    return {
        "schema_version": SCHEMA_VERSION_HIVE_OBSERVE_V1,
        "agent_name": agent_name,
        "pending_count": len(pending),
        "pending": pending,
    }


def get_consensus_result(
    *,
    project_root: Path,
    consensus_id: str,
    record_resolution: bool = False,
    nexus_mirror: bool = False,
    quorum_min: int = DEFAULT_CONSENSUS_QUORUM_MIN,
    timeout_secs: int = DEFAULT_CONSENSUS_TIMEOUT_SECS,
) -> dict[str, Any]:
    """Compute the verdict for a consensus; optionally record it.

    With ``nexus_mirror=True``, when the verdict resolves AND the
    resolution event is being newly appended, also POST a
    ``lineage_record`` to AAAA-Nexus via the bridge. Best-effort:
    failures degrade silently (the local resolution is canonical).
    """
    events = consensus_events_for(project_root, consensus_id)
    proposal = next((e for e in events if e.get("kind") == "proposal"), None)
    if proposal is None:
        return {
            "schema_version": SCHEMA_VERSION_HIVE_OBSERVE_V1,
            "consensus_id": consensus_id,
            "found": False,
            "reason": "no proposal event for this consensus_id",
        }
    agents = active_agents(project_root)
    res = _resolve(
        proposal=proposal, events=events,
        active_agent_count=len(agents),
        quorum_min=quorum_min, timeout_secs=timeout_secs,
    )
    out = {
        "schema_version": SCHEMA_VERSION_HIVE_OBSERVE_V1,
        "consensus_id": consensus_id,
        "found": True,
        "intent": proposal.get("intent"),
        "proposer": proposal.get("proposer"),
        "active_agent_count": len(agents),
        "quorum_min": quorum_min,
        **res,
    }
    if record_resolution and res.get("resolved") and not res.get("verdict") == "PENDING":
        # Append a resolution event so future calls return the same
        # verdict without recomputing.
        already_resolved = any(e.get("kind") == "resolution" for e in events)
        if not already_resolved:
            ev = make_consensus_event(
                kind="resolution", consensus_id=consensus_id,
                payload={"verdict": res.get("verdict"), "tally": res.get("tally")},
            )
            append_consensus(project_root, ev)
            out["resolution_event"] = ev
            # Optional Nexus mirror — fires only on freshly-recorded
            # resolutions so re-reads don't double-publish.
            if nexus_mirror:
                from .nexus_bridge import mirror_consensus_to_lineage
                out["nexus_mirror"] = mirror_consensus_to_lineage(
                    consensus_id=consensus_id,
                    intent=proposal.get("intent", ""),
                    proposer=proposal.get("proposer", ""),
                    verdict=res.get("verdict", "?"),
                    tally=res.get("tally", {}),
                )
    return out
