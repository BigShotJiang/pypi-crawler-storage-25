"""Tier a3 — bridge between Forge hive layer and AAAA-Nexus LIVE primitives.

Composes the a2 ``NexusClient`` into orchestrator-grade flows:

* ``mirror_wisdom_to_lineage`` — when a wisdom entry is recorded
  locally (and has high enough confidence / right tags), POST a
  ``lineage_record`` to Nexus so the institutional knowledge
  is attested upstream too.
* ``mirror_consensus_to_lineage`` — when a consensus resolves on
  the local hive, mirror the verdict to Nexus lineage (one event
  per consensus, not per vote — keeps Nexus quiet).

Best-effort: failures degrade silently to "local-only" with a
warning logged; the local wisdom / consensus state stays canonical.
Closing the production loop is a Worker-side commitment (v0.14.0).
"""
from __future__ import annotations

from typing import Any

from ..a0_qk_constants.nexus_constants import NEXUS_PREMIUM_HINT
from ..a2_mo_composites.nexus_client import (
    NexusClient,
    NexusToolNotShipped,
    NexusUnavailable,
)


def _get_client() -> NexusClient | None:
    """Build a NexusClient from env, or return None when not configured."""
    client = NexusClient.from_env()
    if not client.auth_token:
        # No auth → don't even try to connect. Caller treats as "skip".
        return None
    return client


def mirror_wisdom_to_lineage(
    *,
    wisdom_entry: dict[str, Any],
    min_confidence: float = 0.85,
) -> dict[str, Any]:
    """Mirror one wisdom entry to AAAA-Nexus lineage when eligible.

    Returns a status envelope:

    * ``{"mirrored": True, "result": <Nexus response>}`` — success
    * ``{"mirrored": False, "reason": "<why>"}`` — skipped or failed

    Skip reasons:
      * client not configured (no master/subscription key in env)
      * confidence below ``min_confidence``
      * Nexus unreachable / refused
      * tool not shipped (defensive — current LIVE list includes
        ``lineage_record`` so this branch is dormant)
    """
    confidence = float(wisdom_entry.get("confidence", 0.0))
    if confidence < min_confidence:
        return {"mirrored": False, "reason": f"confidence {confidence:.2f} < {min_confidence}"}
    client = _get_client()
    if client is None:
        return {
            "mirrored": False,
            "reason": "no auth token in env",
            "premium_hint": NEXUS_PREMIUM_HINT,
        }
    try:
        result = client.lineage_record(
            intent="wisdom_recorded",
            payload={
                "wisdom_id": wisdom_entry.get("id"),
                "scope": wisdom_entry.get("scope"),
                "tags": wisdom_entry.get("tags"),
                "agent_name": wisdom_entry.get("agent_name"),
                "confidence": confidence,
                "insight_excerpt": (wisdom_entry.get("insight") or "")[:400],
                "supersedes": wisdom_entry.get("supersedes"),
            },
        )
        return {"mirrored": True, "result": result}
    except (NexusUnavailable, NexusToolNotShipped) as exc:
        return {"mirrored": False, "reason": f"{type(exc).__name__}: {exc}"}


def mirror_consensus_to_lineage(
    *,
    consensus_id: str,
    intent: str,
    proposer: str,
    verdict: str,
    tally: dict[str, Any],
) -> dict[str, Any]:
    """Mirror a resolved consensus to AAAA-Nexus lineage. One event per consensus."""
    client = _get_client()
    if client is None:
        return {
            "mirrored": False,
            "reason": "no auth token in env",
            "premium_hint": NEXUS_PREMIUM_HINT,
        }
    try:
        result = client.lineage_record(
            intent="consensus_resolved",
            payload={
                "consensus_id": consensus_id,
                "consensus_intent": intent,
                "proposer": proposer,
                "verdict": verdict,
                "tally": tally,
            },
        )
        return {"mirrored": True, "result": result}
    except (NexusUnavailable, NexusToolNotShipped) as exc:
        return {"mirrored": False, "reason": f"{type(exc).__name__}: {exc}"}


def mirror_ast_locks_to_lineage(
    *,
    ast_scope_plan: dict[str, Any],
    intent: str = "ast_scope_locks_minted",
) -> dict[str, Any]:
    """Mirror deterministic local AST locks to AAAA-Nexus lineage.

    Uses today's live ``lineage_record`` primitive; does not depend on
    hypothetical ``mint_ast_lock`` / ``grant_ast_scope`` remote tools.
    """
    client = _get_client()
    if client is None:
        return {
            "mirrored": False,
            "reason": "no auth token in env",
            "premium_hint": NEXUS_PREMIUM_HINT,
        }
    locks = (ast_scope_plan.get("locks") or {}).get("locks") or []
    blueprint = ast_scope_plan.get("blueprint") or {}
    try:
        result = client.lineage_record(
            intent=intent,
            payload={
                "schema_version": ast_scope_plan.get("schema_version"),
                "blueprint_hash": (ast_scope_plan.get("locks") or {}).get("blueprint_hash"),
                "node_count": blueprint.get("node_count"),
                "lock_count": len(locks),
                "compressed_context": blueprint.get("compressed_context"),
                "locks": locks,
            },
        )
        return {"mirrored": True, "result": result}
    except (NexusUnavailable, NexusToolNotShipped) as exc:
        return {"mirrored": False, "reason": f"{type(exc).__name__}: {exc}"}


def is_nexus_configured() -> bool:
    """True iff the env has enough to attempt a Nexus call."""
    return _get_client() is not None


__all__ = [
    "is_nexus_configured",
    "mirror_ast_locks_to_lineage",
    "mirror_consensus_to_lineage",
    "mirror_wisdom_to_lineage",
]
