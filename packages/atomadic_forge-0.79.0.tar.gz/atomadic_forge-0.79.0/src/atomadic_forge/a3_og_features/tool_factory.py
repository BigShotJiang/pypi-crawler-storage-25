"""Tier a3 — MCP tool scaffolder + auto-applier.

A meta-tool that emits the boilerplate code needed to add a new MCP
tool to the forge surface. Two modes:

* **Plan mode** (``apply=False``, default) — emits the scaffold as
  text in a :class:`ToolFactoryArtifact`. The caller (agent) reviews,
  then either copies the inserts in by hand OR calls back with
  ``apply=True``.

* **Apply mode** (``apply=True``) — actually mutates ``mcp_protocol.py``,
  ``mcp_server.py``, and ``tests/test_mcp_protocol.py`` by inserting
  the scaffold pieces at the marked sites. Each file is written once
  with all four insertion points handled. Idempotent: refuses to
  re-apply when the tool name is already present in TOOLS.

The auto-applier is the dogfood loop closer. Adding a new MCP tool
went from ~80–150 lines of hand-coded boilerplate to a single
``scaffold_tool(..., apply=True)`` call. Estimated session-token
saving: ~600 tokens per new tool times 8 tools per substantial
session = ~5,000 tokens of pure boilerplate eliminated.

Spec input is unchanged from plan mode. Output dataclass adds
``files_modified`` + ``insertion_points_filled`` for audit.

Given a spec — name, description trigger, input schema, handler
import — it generates the four-piece scaffold:

  1. ``a1/mcp_protocol.py`` insertions:
     - ``_tool_<name>_unbound`` stub
     - ``_<name>_handler`` global + ``_tool_<name>`` proxy
     - ``register_<name>_handler`` setter
     - ``TOOLS["<name>"]`` registry entry
     - ``register_<name>_handler`` export in ``__all__``

  2. ``a3/mcp_server.py`` insertions:
     - ``_bound_<name>`` handler that calls into the implementation
     - ``register_<name>_handler(_bound_<name>)`` registration

  3. ``tests/test_mcp_protocol.py`` additions:
     - Pinned-tool assertion update
     - Smoke test for the new tool

  4. Optional: a stub ``a3/<name>_feature.py`` module if the spec
     declares ``create_module=True``

This tool **emits text** — it does NOT mutate files. The output is a
``ToolFactoryArtifact`` with five fields: ``a1_inserts``,
``a3_inserts``, ``test_inserts``, ``optional_module_text``, and
``acceptance_checklist``. The caller (an MCP-aware agent) reviews and
applies the inserts.

This keeps tool_factory itself trust-gated: forge does not
silently rewrite mcp_protocol.py; it proposes the change and a
human or higher-trust agent applies it.

Tier rationale: a3 — composes a0 constants and a1 emitter helpers,
no upward imports.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

SCHEMA_VERSION_TOOL_FACTORY_V1 = "atomadic-forge.tool_factory/v1"


_VALID_TOOL_NAME = re.compile(r"^[a-z][a-z0-9_]*[a-z0-9]$")


@dataclass
class ToolFactoryArtifact:
    schema_version: str = SCHEMA_VERSION_TOOL_FACTORY_V1
    tool_name: str = ""
    a1_inserts: dict[str, str] = field(default_factory=dict)
    a3_inserts: dict[str, str] = field(default_factory=dict)
    test_inserts: dict[str, str] = field(default_factory=dict)
    optional_module_text: str = ""
    acceptance_checklist: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    applied: bool = False
    files_modified: list[str] = field(default_factory=list)
    insertion_points_filled: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def scaffold_tool(
    *,
    tool_name: str,
    use_this_when: str,
    body_description: str,
    input_schema: dict[str, Any] | None = None,
    handler_module: str = "",
    handler_callable: str = "",
    create_module: bool = False,
    apply: bool = False,
    project_root: Path | str | None = None,
) -> ToolFactoryArtifact:
    """Emit the scaffold artifact for a new MCP tool.

    Args:
        tool_name: snake_case identifier (validated against ``[a-z][a-z0-9_]*[a-z0-9]``).
        use_this_when: trigger sentence; will be prepended to the description.
        body_description: the rest of the tool's description after the trigger.
        input_schema: JSON Schema dict for the inputSchema field. If None, a
            permissive empty-object schema is used.
        handler_module: dotted module path of the implementation function
            (e.g. ``"atomadic_forge.a3_og_features.my_feature"``). Used in the
            a3-side ``_bound_<name>`` import.
        handler_callable: name of the callable inside ``handler_module``.
        create_module: when True, emit a starter module template into
            ``optional_module_text``.

    Returns:
        :class:`ToolFactoryArtifact` with all five sections populated.
    """
    if not _VALID_TOOL_NAME.match(tool_name):
        raise ValueError(
            f"tool_name {tool_name!r} must match {_VALID_TOOL_NAME.pattern} "
            "(snake_case, letters / digits / underscores, no leading or "
            "trailing underscore)"
        )
    if not use_this_when or not use_this_when.strip():
        raise ValueError("use_this_when must be a non-empty trigger sentence")
    if not body_description or not body_description.strip():
        raise ValueError("body_description must be non-empty")

    if input_schema is None:
        input_schema = {
            "type": "object", "properties": {}, "additionalProperties": False,
        }

    description = (
        f"Use this when: {use_this_when.strip().rstrip('.')}. "
        f"{body_description.strip()}"
    )
    if len(description) > 1500:
        # Soft cap — descriptions stay agent-readable.
        description = description[:1497] + "..."

    a1_stub_block = f'''def _tool_{tool_name}_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {{
        "schema_version": "atomadic-forge.{tool_name}/v1",
        "wired": False,
        "note": "{tool_name} handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }}


_{tool_name}_handler: ToolHandler = _tool_{tool_name}_unbound


def _tool_{tool_name}(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return _{tool_name}_handler(project_root, args)


def register_{tool_name}_handler(handler: ToolHandler) -> None:
    """Bind the real ``{handler_callable or tool_name}``-backed handler from a3."""
    global _{tool_name}_handler
    _{tool_name}_handler = handler
'''

    a1_tools_entry = f'''    "{tool_name}": {{
        "name": "{tool_name}",
        "description": (
{_chunk_description_lines(description, indent=12)}
        ),
        "inputSchema": {input_schema!r},
        "handler": _tool_{tool_name},
    }},
'''

    a1_all_entry = f'    "register_{tool_name}_handler",\n'

    if handler_module and handler_callable:
        a3_import = (
            f"from {handler_module} import {handler_callable} as _{tool_name}_impl\n"
        )
        # v0.13.2 fix (WIS-3cd3c921): emit ``**args`` not ``args``.
        # Every a3 impl in this codebase is kwargs-only by convention
        # (e.g. ``record_wisdom(*, project_root, insight, ...)``).
        # Pre-fix this emitted ``_impl(args)`` and raised TypeError
        # on every keyword-only handler. The merge below adds
        # ``project_root`` from the dispatcher context when the
        # impl declares it but the caller didn't pass it.
        a3_bound_body = (
            f"    _kw = dict(args)\n"
            f"    _kw.setdefault('project_root', project_root)\n"
            f"    return _{tool_name}_impl(**_kw)"
        )
    else:
        a3_import = (
            f"# TODO: import the implementation: from <module> import "
            f"<callable> as _{tool_name}_impl\n"
        )
        a3_bound_body = (
            f"    raise NotImplementedError("
            f'"_{tool_name}_impl is not yet wired — '
            f"set handler_module + handler_callable in the spec"
            f'")'
        )

    a3_bound_block = f'''def _bound_{tool_name}(project_root, args):
    """a3-side {tool_name} handler — bound into the a1 dispatcher
    at module import time."""
{a3_bound_body}


register_{tool_name}_handler(_bound_{tool_name})
'''

    test_block = f'''def test_{tool_name}_description_carries_use_this_when():
    assert "{tool_name}" in TOOLS
    assert TOOLS["{tool_name}"]["description"].startswith("Use this when:")


def test_{tool_name}_unbound_stub_returns_wired_false(tmp_path):
    """Until a3 wires the real handler, calling the tool through the
    pure dispatcher should return a structured ``wired: False`` payload
    (not raise)."""
    from atomadic_forge.a1_at_functions.mcp_protocol import _tool_{tool_name}_unbound
    result = _tool_{tool_name}_unbound(tmp_path, {{}})
    assert result["schema_version"] == "atomadic-forge.{tool_name}/v1"
    assert result["wired"] is False
'''

    test_pinned_addition = f'        "{tool_name}",\n'

    optional_module = ""
    if create_module:
        optional_module = _starter_module(handler_callable or tool_name)

    checklist = [
        "Insert ``a1_stub_block`` into mcp_protocol.py just BEFORE the "
        "``TOOLS: dict[...]`` registry definition.",
        "Insert ``a1_tools_entry`` as a new key in the ``TOOLS`` dict "
        "(near tools of the same family for readability).",
        "Add ``a1_all_entry`` to the ``__all__`` export list, "
        "alphabetically.",
        "Add ``a3_import`` to the imports block of mcp_server.py.",
        "Insert ``a3_bound_block`` near the other ``_bound_*`` "
        "functions in mcp_server.py.",
        "Add ``test_pinned_addition`` to the pinned-tools set in "
        "``test_tools_list_pinned``.",
        "Append ``test_block`` to tests/test_mcp_protocol.py.",
        f"If ``create_module=True``: write ``optional_module_text`` to "
        f"``src/atomadic_forge/a3_og_features/{handler_callable or tool_name}.py``.",
        "Run ``python -m pytest`` and ``python -m ruff check src tests``.",
        "Run ``forge certify .`` and confirm 100/100 still holds.",
    ]

    notes: list[str] = []
    if not handler_module:
        notes.append(
            "No handler_module given — the a3 stub raises "
            "NotImplementedError until the implementation is wired."
        )
    if create_module and not handler_module.endswith(handler_callable or tool_name):
        notes.append(
            "create_module=True but handler_module does not match the "
            "module path the starter module would land at — verify "
            "before applying."
        )

    artifact = ToolFactoryArtifact(
        tool_name=tool_name,
        a1_inserts={
            "stub_block": a1_stub_block,
            "tools_entry": a1_tools_entry,
            "all_export_entry": a1_all_entry,
        },
        a3_inserts={
            "import_line": a3_import,
            "bound_block": a3_bound_block,
        },
        test_inserts={
            "pinned_addition": test_pinned_addition,
            "test_block": test_block,
        },
        optional_module_text=optional_module,
        acceptance_checklist=checklist,
        notes=notes,
    )
    if apply:
        from pathlib import Path as _P
        root = _P(project_root) if project_root else _P.cwd()
        _apply_scaffold(artifact, project_root=root,
                        handler_module=handler_module,
                        handler_callable=handler_callable,
                        create_module=create_module,
                        optional_module=optional_module)
    return artifact


def _apply_scaffold(
    artifact: ToolFactoryArtifact,
    *,
    project_root: Path,
    handler_module: str,
    handler_callable: str,
    create_module: bool,
    optional_module: str,
) -> None:
    """Apply the scaffold to the live source files. Mutates:

      * src/atomadic_forge/a1_at_functions/mcp_protocol.py
      * src/atomadic_forge/a3_og_features/mcp_server.py
      * tests/test_mcp_protocol.py
      * (optional) src/atomadic_forge/a3_og_features/<callable>.py

    Idempotent: refuses to re-apply when the tool name is already a
    key in the TOOLS dict in mcp_protocol.py.
    """
    tool_name = artifact.tool_name
    src = project_root / "src" / "atomadic_forge"
    proto = src / "a1_at_functions" / "mcp_protocol.py"
    server = src / "a3_og_features" / "mcp_server.py"
    test_file = project_root / "tests" / "test_mcp_protocol.py"

    if not (proto.exists() and server.exists() and test_file.exists()):
        artifact.notes.append(
            f"apply skipped: expected files not found under {project_root}"
        )
        return

    proto_text = proto.read_text(encoding="utf-8")
    if f'"{tool_name}":' in proto_text:
        artifact.notes.append(
            f"apply skipped: tool {tool_name!r} already present in TOOLS"
        )
        return

    # ── 1. mcp_protocol.py — three insertions ────────────────────────
    # 1a. Stub block: place just before the TOOLS dict definition.
    tools_marker = "TOOLS: dict[str, dict[str, Any]] = {"
    if tools_marker not in proto_text:
        artifact.notes.append("apply aborted: TOOLS marker not found")
        return
    proto_text = proto_text.replace(
        tools_marker,
        artifact.a1_inserts["stub_block"] + "\n\n" + tools_marker,
        1,
    )
    # 1b. TOOLS entry: append before the dict's closing brace.
    # Find the last `},` followed by `\n}` pattern (end of registry).
    # Simpler: locate `"recon_swarm": {` (always present) and inject
    # the new entry just before it. Falls back to the closing brace
    # if recon_swarm isn't found.
    anchor = '    "recon_swarm": {'
    if anchor in proto_text:
        proto_text = proto_text.replace(
            anchor, artifact.a1_inserts["tools_entry"] + anchor, 1,
        )
    else:
        # Fallback: insert before the closing `}` of the TOOLS dict.
        # Only handles the common shape; surfaces a note otherwise.
        artifact.notes.append(
            "apply: recon_swarm anchor missing; tools_entry NOT placed"
        )
    # 1c. __all__ export entry: insert in the alphabetical block.
    # Find `"register_synergy_scan_handler",` and insert before it
    # (alphabetical convention, stable for now).
    all_anchor = '    "register_synergy_scan_handler",'
    if all_anchor in proto_text:
        proto_text = proto_text.replace(
            all_anchor,
            artifact.a1_inserts["all_export_entry"] + all_anchor,
            1,
        )
    proto.write_text(proto_text, encoding="utf-8")
    artifact.files_modified.append(str(proto.relative_to(project_root)))

    # ── 2. mcp_server.py — two insertions ───────────────────────────
    server_text = server.read_text(encoding="utf-8")
    # 2a. Add `register_<name>_handler` import to the registers block.
    server_imports_anchor = "    register_synergy_scan_handler,"
    register_line = f"    register_{tool_name}_handler,\n"
    if (server_imports_anchor in server_text
            and register_line not in server_text):
        server_text = server_text.replace(
            server_imports_anchor,
            register_line + server_imports_anchor,
            1,
        )
    # 2b. Add the import line for the handler module (if specified).
    if handler_module and handler_callable:
        synergy_import = (
            "from .synergy_feature import SynergyScan as _SynergyScan"
        )
        if (synergy_import in server_text
                and artifact.a3_inserts["import_line"] not in server_text):
            server_text = server_text.replace(
                synergy_import,
                artifact.a3_inserts["import_line"] + synergy_import,
                1,
            )
    # 2c. Append the bound block + register call near the other
    # register calls (end of file is the simplest stable target).
    if artifact.a3_inserts["bound_block"] not in server_text:
        server_text = server_text.rstrip() + "\n\n\n" + artifact.a3_inserts["bound_block"] + "\n"
    server.write_text(server_text, encoding="utf-8")
    artifact.files_modified.append(str(server.relative_to(project_root)))

    # ── 3. test_mcp_protocol.py — two insertions ────────────────────
    test_text = test_file.read_text(encoding="utf-8")
    # 3a. Pinned-tools set: insert before the closing `}` of the set.
    # Anchor on the comment that prefixes our tool family additions.
    pinned_anchor = '        # tool_factory: meta-tool that scaffolds new MCP tools (forge eats forge):\n        "tool_factory",'
    if pinned_anchor in test_text:
        test_text = test_text.replace(
            pinned_anchor,
            pinned_anchor + "\n" + artifact.test_inserts["pinned_addition"].rstrip(),
            1,
        )
    # 3b. Append the test block near the end of the file.
    if artifact.test_inserts["test_block"].strip() not in test_text:
        test_text = test_text.rstrip() + "\n\n\n" + artifact.test_inserts["test_block"] + "\n"
    test_file.write_text(test_text, encoding="utf-8")
    artifact.files_modified.append(str(test_file.relative_to(project_root)))

    # ── 4. Optional starter module ──────────────────────────────────
    if create_module and handler_callable and optional_module:
        module_path = src / "a3_og_features" / f"{handler_callable}.py"
        if not module_path.exists():
            module_path.write_text(optional_module, encoding="utf-8")
            artifact.files_modified.append(
                str(module_path.relative_to(project_root))
            )

    artifact.applied = True
    artifact.insertion_points_filled = [
        "a1.stub_block",
        "a1.tools_entry",
        "a1.all_export_entry",
        "a3.import_line" if handler_module else "a3.import_line:skipped",
        "a3.bound_block",
        "test.pinned_addition",
        "test.test_block",
    ]


def _chunk_description_lines(text: str, *, indent: int) -> str:
    """Wrap a long description into Python-string-concatenation-friendly
    lines for the TOOLS registry entry. Keeps each line at < 80 chars
    after the indent."""
    pad = " " * indent
    target_width = 78 - indent
    words = text.split()
    lines: list[str] = []
    current = ""
    for w in words:
        if not current:
            current = w
        elif len(current) + 1 + len(w) <= target_width:
            current = f"{current} {w}"
        else:
            lines.append(current)
            current = w
    if current:
        lines.append(current)
    return "\n".join(f'{pad}"{line} "' for line in lines)


def _starter_module(handler_callable: str) -> str:
    """Emit a minimal a3 module template the caller can grow into."""
    return f'''"""Tier a3 — TODO: one-paragraph description of what this feature does.

Composes:
  * a0 constants (TODO: list them)
  * a1 helpers   (TODO: list them)
  * a2 stateful  (TODO: list them, if any)
"""
from __future__ import annotations

from typing import Any


SCHEMA_VERSION_V1 = "atomadic-forge.{handler_callable}/v1"


def {handler_callable}(args: dict[str, Any]) -> dict[str, Any]:
    """TODO: implement.

    Args:
        args: input arguments per the JSON Schema in mcp_protocol.

    Returns:
        Result dict with ``schema_version`` and the tool's payload.
    """
    return {{
        "schema_version": SCHEMA_VERSION_V1,
        "TODO": "implement {handler_callable}",
        "args_received": dict(args),
    }}
'''
