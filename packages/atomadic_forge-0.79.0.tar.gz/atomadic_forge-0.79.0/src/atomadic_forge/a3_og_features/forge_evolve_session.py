"""Tier a3 — agent-driven evolve sessions (Round 3.5).

Recursive iterate. Each round produces a generated package; that
package becomes the seed catalog for the next round. The agent drives
the LLM at every turn; forge sequences the rounds and runs verification
between them. NO LLM client is constructed inside forge.

API shape::

    sess = evolve_start_session(intent, output, package, ...)
    # → {evolve_session_id, iterate_session_id, system_prompt, first_prompt}
    # agent calls its own LLM
    response = agent_llm.call(...)
    next = evolve_step_session(evolve_session_id, response, project_root)
    # → either {round_complete: true, new_round_started: true,
    #            iterate_session_id: <new>, next_first_prompt}
    #    or    {round_complete: false, next_prompt}  # mid-round, just forward
    #    or    {evolve_complete: true, halt_reason, score_trajectory}
    # agent loops until evolve_complete.

Hard caps from system invariants:
  * ``rounds`` ≤ ``D_MAX_DELEGATION = 23`` (corpus). Asking for more
    is refused, not silently truncated.
  * ``iterations_per_round`` is forwarded as ``max_iterations`` to the
    inner iterate session.

The substrate guarantee remains unbroken: forge holds zero LLM
clients. The agent reasons; forge supplies analytical certainty +
round sequencing.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ..a0_qk_constants.gen_language import (
    Language,
    normalize_language,
    pkg_root_for,
)
from ..a0_qk_constants.mhed_invariants import D_MAX_DELEGATION
from ..a1_at_functions.scout_walk import harvest_repo
from ..a2_mo_composites.evolve_session_store import EvolveSessionStore
from .forge_loop_session import (
    iterate_continue_session,
    iterate_start_session,
)

SCHEMA_VERSION_EVOLVE_START_V1 = "atomadic-forge.evolve_start/v1"
SCHEMA_VERSION_EVOLVE_STEP_V1 = "atomadic-forge.evolve_step/v1"


def evolve_start_session(
    intent: str,
    *,
    output: Path,
    project_root: Path,
    package: str = "evolved",
    seed_repos: list[Path] | None = None,
    target_score: float = 75.0,
    rounds: int = 3,
    iterations_per_round: int = 4,
    stop_on_regression: bool = False,
    stagnation_threshold: int = 3,
    language: Language | str = "python",
) -> dict[str, Any]:
    """Open a new agent-driven evolve session.

    Creates the parent evolve session + spawns the round-0 iterate
    child. Returns the iterate child's first prompt so the agent can
    drive its LLM and call ``evolve_step_session`` with the response.

    Refuses ``rounds > D_MAX_DELEGATION`` (depth cap = 23).
    """
    if not intent or not intent.strip():
        raise ValueError("intent must be a non-empty string")
    if rounds > D_MAX_DELEGATION:
        raise ValueError(
            f"evolve_start: requested {rounds} rounds exceeds the system "
            f"delegation depth cap of {D_MAX_DELEGATION}. Analytical "
            f"recursion deeper than {D_MAX_DELEGATION} is forbidden by a "
            f"system invariant. Split the run into multiple "
            f"<={D_MAX_DELEGATION}-round passes."
        )

    output = Path(output).resolve()
    project_root = Path(project_root).resolve()
    output.mkdir(parents=True, exist_ok=True)
    lang = normalize_language(language)

    # Open parent evolve session.
    store = EvolveSessionStore(project_root)
    seed_repo_strs = [str(Path(s).resolve()) for s in (seed_repos or [])
                      if Path(s).exists()]
    evolve_state = store.create(
        intent=intent, output=output, package=package, language=lang,
        target_score=target_score, rounds=rounds,
        iterations_per_round=iterations_per_round,
        stop_on_regression=stop_on_regression,
        stagnation_threshold=stagnation_threshold,
        seed_repos=seed_repo_strs,
    )

    # Spawn round-0 iterate child session.
    iterate_payload = iterate_start_session(
        intent,
        output=output,
        project_root=project_root,
        package=package,
        seed_repos=[Path(s) for s in seed_repo_strs],
        target_score=target_score,
        max_iterations=iterations_per_round,
        language=lang,
    )
    evolve_state.current_iterate_id = iterate_payload["session_id"]
    evolve_state.current_round_idx = 0
    store.save(evolve_state)

    return {
        "schema_version": SCHEMA_VERSION_EVOLVE_START_V1,
        "evolve_session_id": evolve_state.session_id,
        "iterate_session_id": iterate_payload["session_id"],
        "round_idx": 0,
        "rounds_total": rounds,
        "system_prompt": iterate_payload["system_prompt"],
        "first_prompt": iterate_payload["first_prompt"],
        "package": package,
        "language": lang,
        "output": str(output),
        "target_score": target_score,
        "iterations_per_round": iterations_per_round,
        "d_max_cap": D_MAX_DELEGATION,
    }


def evolve_step_session(
    evolve_session_id: str,
    response: str,
    *,
    project_root: Path,
) -> dict[str, Any]:
    """Process one turn within the active iterate child session.

    Three possible outcomes:

    1. **Inner iterate not done** — forward iterate's ``next_prompt``
       transparently. ``round_complete: false``.

    2. **Inner iterate done, more rounds available** — close the
       round, update trajectory, decide halt vs. start-next-round
       (stagnation / regression / converged-with-no-delta checks).
       Either return ``evolve_complete: true`` with the final report,
       or spawn a new iterate child for the next round and return
       ``round_complete: true, new_round_started: true,
       next_first_prompt``.

    3. **All rounds exhausted or halt condition** — finalize evolve,
       emit ``score_trajectory`` + ``halt_reason``.
    """
    project_root = Path(project_root).resolve()
    store = EvolveSessionStore(project_root)
    evolve_state = store.load(evolve_session_id)
    if evolve_state is None:
        return {
            "schema_version": SCHEMA_VERSION_EVOLVE_STEP_V1,
            "error": f"unknown evolve_session_id {evolve_session_id!r}",
            "evolve_complete": True,
            "halt_reason": "unknown_session",
        }
    if evolve_state.completed:
        return _finalize_payload(evolve_state, already_done=True)

    if not evolve_state.current_iterate_id:
        return {
            "schema_version": SCHEMA_VERSION_EVOLVE_STEP_V1,
            "error": "evolve session has no active iterate child",
            "evolve_complete": True,
            "halt_reason": "internal_error",
        }

    # Forward the agent's response to the active iterate child.
    inner = iterate_continue_session(
        evolve_state.current_iterate_id, response,
        project_root=project_root,
    )

    if not inner.get("done"):
        # Mid-round — transparent passthrough.
        return {
            "schema_version": SCHEMA_VERSION_EVOLVE_STEP_V1,
            "evolve_session_id": evolve_session_id,
            "round_idx": evolve_state.current_round_idx,
            "rounds_total": evolve_state.rounds,
            "round_complete": False,
            "next_prompt": inner.get("next_prompt", ""),
            "score": inner.get("score", 0.0),
            "wire_verdict": inner.get("wire_verdict"),
            "turn": inner.get("turn", 0),
            "iterate_session_id": evolve_state.current_iterate_id,
        }

    # Inner iterate terminated — close the round.
    output = Path(evolve_state.output)
    pkg_root = output / pkg_root_for(
        evolve_state.language, evolve_state.package,  # type: ignore[arg-type]
    )
    catalog = (
        harvest_repo(pkg_root) if pkg_root.exists()
        else {"symbols": [], "symbol_count": 0}
    )
    symbol_count = int(catalog.get("symbol_count", 0))
    score = float(inner.get("score", 0.0))
    delta_symbols = symbol_count - evolve_state.last_symbol_count
    delta_score = round(score - evolve_state.last_score, 3)

    round_record = {
        "round": evolve_state.current_round_idx,
        "iterate_session_id": evolve_state.current_iterate_id,
        "halt_reason_inner": inner.get("halt_reason", ""),
        "score": score,
        "wire_verdict": inner.get("wire_verdict"),
        "symbol_count": symbol_count,
        "delta_symbols": delta_symbols,
        "delta_score": delta_score,
    }

    # Stagnation tracking — flat score AND flat catalog vs. previous round.
    if (evolve_state.current_round_idx > 0 and delta_symbols == 0
            and abs(delta_score) < 0.5):
        evolve_state.stagnant_streak += 1
    else:
        evolve_state.stagnant_streak = 0
    round_record["stagnant_streak"] = evolve_state.stagnant_streak

    evolve_state.rounds_log.append(round_record)

    # Halt-condition checks (ordered by priority).
    halt: str | None = None
    if (inner.get("halt_reason") == "converged"
            and delta_symbols == 0 and evolve_state.current_round_idx > 0):
        halt = "converged"
    elif (evolve_state.stop_on_regression
            and evolve_state.current_round_idx > 0 and delta_score < 0):
        halt = "score regression"
    elif (evolve_state.stagnation_threshold
            and evolve_state.stagnant_streak >= evolve_state.stagnation_threshold):
        halt = "stagnation"
    elif evolve_state.current_round_idx + 1 >= evolve_state.rounds:
        halt = "rounds_exhausted"

    if halt is not None:
        evolve_state.halt_reason = halt
        evolve_state.completed = True
        evolve_state.last_symbol_count = symbol_count
        evolve_state.last_score = score
        store.save(evolve_state)
        return _finalize_payload(evolve_state)

    # Continue — start the next round with the previous round's
    # output as the seed catalog.
    evolve_state.last_symbol_count = symbol_count
    evolve_state.last_score = score
    evolve_state.current_round_idx += 1
    next_seed = pkg_root if pkg_root.exists() else None
    next_iterate = iterate_start_session(
        evolve_state.intent,
        output=Path(evolve_state.output),
        project_root=project_root,
        package=evolve_state.package,
        seed_repos=[next_seed] if next_seed else None,
        target_score=evolve_state.target_score,
        max_iterations=evolve_state.iterations_per_round,
        language=evolve_state.language,  # type: ignore[arg-type]
    )
    evolve_state.current_iterate_id = next_iterate["session_id"]
    store.save(evolve_state)

    return {
        "schema_version": SCHEMA_VERSION_EVOLVE_STEP_V1,
        "evolve_session_id": evolve_session_id,
        "round_idx": evolve_state.current_round_idx,
        "rounds_total": evolve_state.rounds,
        "round_complete": True,
        "new_round_started": True,
        "iterate_session_id": next_iterate["session_id"],
        "next_first_prompt": next_iterate["first_prompt"],
        "system_prompt": next_iterate["system_prompt"],
        "previous_round_score": score,
        "previous_round_symbol_count": symbol_count,
    }


def _finalize_payload(state, *, already_done: bool = False) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION_EVOLVE_STEP_V1,
        "evolve_session_id": state.session_id,
        "evolve_complete": True,
        "halt_reason": state.halt_reason or "rounds_exhausted",
        "rounds_completed": len(state.rounds_log),
        "rounds_requested": state.rounds,
        "score_trajectory": [r["score"] for r in state.rounds_log],
        "symbol_trajectory": [r["symbol_count"] for r in state.rounds_log],
        "final_score": state.last_score,
        "final_symbol_count": state.last_symbol_count,
        "rounds_log": list(state.rounds_log),
        "note": "session already terminated" if already_done else None,
    }
