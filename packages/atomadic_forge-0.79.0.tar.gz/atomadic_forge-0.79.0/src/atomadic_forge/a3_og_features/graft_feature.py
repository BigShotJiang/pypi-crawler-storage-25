"""Tier a3 — `forge graft`: pull one symbol from a tier-organized source
into the target's tier directory and (optionally) auto-wire CLI + MCP.

This is the surgical complement to ``transmute auto``: instead of
absorbing a whole repository, ``graft`` extracts a single named
function or class, drops it into the matching tier of the target,
and lets ``auto-wire`` scaffold the CLI + MCP surface for it.

The graft itself is deterministic: the extracted source is the verbatim
slice from the source file, imports resolved from the source's own
import table. No LLM in the path. The wire-and-certify pass that
follows is the same gate every Forge release runs.

Pipeline::

    graft(source_file, symbol, target)
        -> extract slice + imports          (a1: graft_extract)
        -> render stand-alone module        (a1: graft_extract)
        -> write into target/aN_*/<file>.py
        -> wire-violations check            (a1: wire_check)
        -> [optional] auto-wire CLI + MCP   (a1: wire_stubs_gen)
        -> return GraftReport
"""
from __future__ import annotations

import shutil
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from ..a1_at_functions.graft_extract import (
    GraftExtract,
    extract_symbol,
    render_grafted_module,
)
from ..a1_at_functions.wire_check import scan_violations

SCHEMA_VERSION_GRAFT_V1 = "atomadic-forge.graft/v1"
DEFAULT_TARGET_PACKAGE = "atomadic_forge"

# Tier the graft lands in based on extracted symbol kind. Functions
# default to a1 (pure helpers); classes default to a2 (composites);
# the caller can override with --tier.
_DEFAULT_TIERS = {
    "function": "a1_at_functions",
    "async_function": "a1_at_functions",
    "class": "a2_mo_composites",
}


@dataclass
class GraftReport:
    """Outcome of a single ``forge graft`` invocation.

    Carries enough state for a subsequent ``--rollback`` to undo the
    graft cleanly: the destination path, the original source path,
    and the wire verdict at the moment of write.
    """
    schema_version: str
    target_root: str
    source_file: str
    symbol_name: str
    kind: str
    target_tier: str
    target_module: str
    target_path: str
    source_lines: list[int]
    imports_needed: list[str]
    bytes_written: int
    wire_verdict: str
    wire_violations: int
    backup_path: str | None
    written: bool

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _resolve_target_module(
    target_root: Path,
    package: str,
    tier: str,
    symbol_name: str,
) -> Path:
    """Compute the absolute path the grafted module will be written to.

    Files get a lower-cased symbol name with sanitized characters. We
    sit beside (not on top of) any pre-existing module of the same
    name; collisions are surfaced loudly by ``graft``'s caller.
    """
    safe = "".join(
        ch if ch.isalnum() or ch == "_" else "_"
        for ch in symbol_name
    ).lstrip("_").lower() or "grafted_symbol"
    return (
        target_root / "src" / package / tier / f"{safe}.py"
    )


def _rename_symbol_in_source(source: str, old_name: str, new_name: str) -> str:
    """Rewrite the def/class line of ``old_name`` to use ``new_name``.

    We do this textually on the extracted slice rather than via AST round-
    trip so the rendered module preserves the source's exact formatting.
    Only the binding name is rewritten; references inside the body are
    left untouched (which is correct: we're renaming the public surface,
    not refactoring callers).
    """
    if old_name == new_name:
        return source
    import re
    pattern = re.compile(
        rf"^(\s*(?:async\s+)?(?:def|class)\s+){re.escape(old_name)}\b",
        re.MULTILINE,
    )
    new_source, count = pattern.subn(lambda m: f"{m.group(1)}{new_name}", source, count=1)
    if count == 0:
        raise ValueError(
            f"could not locate def/class {old_name!r} to rename in extracted slice"
        )
    return new_source


def graft(
    *,
    source_file: Path | str,
    symbol_name: str,
    target_root: Path | str,
    package: str = DEFAULT_TARGET_PACKAGE,
    tier: str | None = None,
    rename_to: str | None = None,
    overwrite: bool = False,
    dry_run: bool = False,
) -> GraftReport:
    """Graft one top-level symbol from ``source_file`` into the target tree.

    Returns a :class:`GraftReport` whether or not the file was written
    (``dry_run=True`` returns the plan with ``written=False``). On
    successful write the wire-violations scan is run and its verdict
    embedded in the report so callers can decide whether to roll back
    or proceed to ``auto-wire``.

    Args:
        source_file: absolute path to the .py file holding ``symbol_name``.
        symbol_name: the bare top-level name to extract (e.g. ``cosine_similarity``).
        target_root: project root that contains ``src/<package>/``.
        package: importable package name under ``src/`` (default: atomadic_forge).
        tier: explicit tier override (``a1_at_functions`` etc.). When ``None``
              the default for the symbol's kind is used.
        overwrite: when False (default) and the destination already exists,
              raise ``FileExistsError`` instead of clobbering.
        dry_run: plan and report; do not write anything.
    """
    source_path = Path(source_file).resolve()
    target_path_root = Path(target_root).resolve()

    extract = extract_symbol(source_path, symbol_name)

    # Optional rename: rewrite the def/class binding in the extracted
    # slice. The destination filename and report identifier follow the
    # rename so auto-wire and surface-gaps see the public form.
    effective_name = rename_to or symbol_name
    if rename_to and rename_to != symbol_name:
        renamed_source = _rename_symbol_in_source(
            extract.source, symbol_name, rename_to,
        )
        extract = GraftExtract(
            symbol_name=rename_to,
            kind=extract.kind,
            source=renamed_source,
            imports_needed=extract.imports_needed,
            start_line=extract.start_line,
            end_line=extract.end_line,
        )

    chosen_tier = tier or _DEFAULT_TIERS.get(extract.kind, "a3_og_features")
    dest = _resolve_target_module(
        target_path_root, package, chosen_tier, effective_name,
    )
    rendered = render_grafted_module(
        extract, source_file=source_path,
    )

    backup_path: str | None = None
    written = False
    bytes_written = 0
    wire_verdict = "DRY_RUN"
    wire_violations = 0

    if not dry_run:
        if dest.exists() and not overwrite:
            raise FileExistsError(
                f"graft target already exists: {dest}. "
                "Pass overwrite=True if this is intentional."
            )
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            backup = dest.with_suffix(dest.suffix + ".bak")
            shutil.copyfile(dest, backup)
            backup_path = str(backup)
        dest.write_text(rendered, encoding="utf-8")
        bytes_written = len(rendered.encode("utf-8"))
        written = True

        # Run a focused wire scan on the package: a graft that introduces
        # an upward import is rejected on the spot. Caller can roll back
        # using backup_path if needed.
        try:
            wire_report = scan_violations(
                target_path_root / "src" / package,
            )
            wire_violations = int(wire_report.get("violation_count", 0))
            wire_verdict = wire_report.get("verdict", "UNKNOWN")
        except Exception:  # pragma: no cover - diagnostic only
            wire_verdict = "ERROR"
            wire_violations = -1

    return GraftReport(
        schema_version=SCHEMA_VERSION_GRAFT_V1,
        target_root=str(target_path_root),
        source_file=str(source_path),
        symbol_name=effective_name,
        kind=extract.kind,
        target_tier=chosen_tier,
        target_module=f"{package}.{chosen_tier}.{dest.stem}",
        target_path=str(dest),
        source_lines=[extract.start_line, extract.end_line],
        imports_needed=sorted(extract.imports_needed),
        bytes_written=bytes_written,
        wire_verdict=wire_verdict,
        wire_violations=wire_violations,
        backup_path=backup_path,
        written=written,
    )
