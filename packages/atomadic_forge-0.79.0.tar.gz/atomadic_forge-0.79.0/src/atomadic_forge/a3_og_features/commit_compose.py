"""Tier a3 — structured commit-message composer.

Closes friction F-5 from FRICTION_LOG.md: every commit was a 50-100
line narrative typed by hand. ~12,000 tokens per session of pure
prose. This module accepts a list of changed files + a one-line
intent and emits a structured commit body via a small template.

Pure: composes git diff parsing + a deterministic template. No LLM.
The template is intentionally bare — it captures the FACTS (files
changed, +/- lines, top-level intent) and lets the agent fill in the
narrative tail when it actually matters. Most commits only need the
facts.

Three sections:

  1. **Subject line** — `<type>: <intent>`
  2. **Files changed** — bulleted list with line deltas
  3. **Body** (optional) — agent's narrative if supplied

The agent's net token cost drops from ~1,500 tokens of hand-typed
narrative to ~150 tokens of structured spec.
"""
from __future__ import annotations

import re
import subprocess
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

SCHEMA_VERSION_COMMIT_COMPOSE_V1 = "atomadic-forge.commit_compose/v1"


@dataclass
class CommitComposeArtifact:
    schema_version: str = SCHEMA_VERSION_COMMIT_COMPOSE_V1
    subject: str = ""
    body: str = ""
    full_message: str = ""
    files_changed: list[dict[str, Any]] = field(default_factory=list)
    total_added: int = 0
    total_removed: int = 0
    notes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


_VALID_TYPES = {
    "feat", "fix", "docs", "ship", "harden", "expand", "expose",
    "refactor", "test", "chore", "research", "audit",
}


def compose_commit_message(
    *,
    project_root: Path,
    intent: str,
    commit_type: str = "ship",
    body: str = "",
    include_coauthor: bool = True,
) -> CommitComposeArtifact:
    """Emit a structured commit message from changed files + intent.

    Args:
        project_root: repo root.
        intent: one-line subject (will be slugified into the
            ``<type>: <intent>`` subject).
        commit_type: conventional-commit-style prefix. Default
            ``"ship"`` (matches the project's existing style).
        body: optional narrative tail. When empty, the artifact's
            ``full_message`` is just the subject + facts.
        include_coauthor: append the Claude co-author trailer.

    Returns:
        :class:`CommitComposeArtifact` with subject + body +
        full_message + a structured files-changed listing.
    """
    project_root = Path(project_root).resolve()
    if commit_type not in _VALID_TYPES:
        return CommitComposeArtifact(
            notes=[f"unknown commit_type {commit_type!r}; "
                    f"valid: {sorted(_VALID_TYPES)}"],
        )
    if not intent or not intent.strip():
        return CommitComposeArtifact(
            notes=["intent must be a non-empty subject line"],
        )

    # Get the staged + unstaged diff stats from git.
    files: list[dict[str, Any]] = []
    total_added = 0
    total_removed = 0
    notes: list[str] = []
    try:
        result = subprocess.run(
            ["git", "-C", str(project_root), "diff", "--numstat",
             "HEAD"],
            capture_output=True, text=True, timeout=10,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        notes.append(f"git diff failed: {exc}")
        result = None

    if result is not None and result.returncode == 0:
        for line in result.stdout.splitlines():
            parts = line.split("\t")
            if len(parts) != 3:
                continue
            added_str, removed_str, path = parts
            try:
                added = int(added_str) if added_str.isdigit() else 0
                removed = int(removed_str) if removed_str.isdigit() else 0
            except ValueError:
                added = removed = 0
            files.append({
                "path": path,
                "added": added,
                "removed": removed,
            })
            total_added += added
            total_removed += removed
    else:
        notes.append(
            "no git diff available — files_changed list will be empty"
        )

    # ── Subject ─────────────────────────────────────────────
    # Trim to 72 chars after the type prefix per Conventional-Commit
    # convention.
    intent_trimmed = re.sub(r"\s+", " ", intent.strip()).rstrip(".")
    # Strip leading conventional-commit prefix if caller already included one.
    intent_trimmed = re.sub(r"^[a-z]+(\([^)]+\))?:\s*", "", intent_trimmed)
    available = 72 - len(commit_type) - 2  # "<type>: "
    if len(intent_trimmed) > available:
        intent_trimmed = intent_trimmed[: available - 1].rstrip() + "…"
    subject = f"{commit_type}: {intent_trimmed}"

    # ── Body — facts block ──────────────────────────────────
    body_lines: list[str] = []
    if body and body.strip():
        body_lines.append(body.strip())
        body_lines.append("")

    if files:
        body_lines.append(
            f"== Files changed ({len(files)}) =="
        )
        body_lines.append("")
        for f in files[:25]:  # cap to keep messages readable
            sign = "+" if f["added"] >= f["removed"] else "-"
            body_lines.append(
                f"  {sign} {f['path']}  (+{f['added']} / -{f['removed']})"
            )
        if len(files) > 25:
            body_lines.append(f"  … and {len(files) - 25} more files")
        body_lines.append("")
        body_lines.append(
            f"Total: +{total_added} / -{total_removed} lines across "
            f"{len(files)} file(s)."
        )

    if include_coauthor:
        body_lines.append("")
        body_lines.append("Co-Authored-By: Claude Opus 4.7 "
                           "<noreply@anthropic.com>")

    body_text = "\n".join(body_lines).rstrip() + "\n"
    full_message = f"{subject}\n\n{body_text}" if body_lines else f"{subject}\n"

    return CommitComposeArtifact(
        subject=subject,
        body=body_text,
        full_message=full_message,
        files_changed=files,
        total_added=total_added,
        total_removed=total_removed,
        notes=notes,
    )
