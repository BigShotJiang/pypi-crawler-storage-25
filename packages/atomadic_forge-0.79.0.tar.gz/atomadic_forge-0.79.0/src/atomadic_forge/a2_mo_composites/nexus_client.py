"""Tier a2 — thin HTTP client for AAAA-Nexus LIVE primitives.

stdlib-only (no requests / httpx) so the package stays
zero-dependency. JSON-RPC 2.0 envelope per Nexus contract.

Usage:

    client = NexusClient.from_env()
    result = client.call("identity_verify",
                          {"identity": "did:atomadic:cognition-v0"})
    # → {"verified": True, "subject": "...", ...}

Env vars:
    ATOMADIC_NEXUS_URL          Override base URL (default
                                 https://atomadic.tech)
    ATOMADIC_MASTER_KEY         Master key (Bearer auth)
    ATOMADIC_SUBSCRIPTION_KEY   Per-agent key (Bearer auth, preferred
                                 if both are set — narrower scope)
    FORGE_MASTER_API_KEY        Accepted master-key alias
    FORGE_API_KEY               Accepted subscription-key alias
    AAAA_NEXUS_API_KEY          Accepted legacy Nexus key alias
    ATOMADIC_VAULT_ENV          Optional .env file containing any of
                                 the above keys

Refuses to call any tool not in
``a0_qk_constants.nexus_constants.LIVE_NEXUS_TOOLS`` so we don't
ship a bug that depends on unshipped Nexus primitives.
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

from ..a0_qk_constants.nexus_constants import (
    DEFAULT_NEXUS_BASE_URL,
    DEFAULT_NEXUS_MCP_PATH,
    DEFAULT_NEXUS_TIMEOUT_SECS,
    ENV_NEXUS_BASE_URL_ALIASES,
    ENV_NEXUS_MASTER_KEY_ALIASES,
    ENV_NEXUS_SUBSCRIPTION_KEY_ALIASES,
    ENV_NEXUS_VAULT_PATH,
    LIVE_NEXUS_TOOLS,
    SCHEMA_VERSION_NEXUS_CALL_V1,
)


class NexusUnavailable(RuntimeError):
    """Network / auth / endpoint failure. Caller decides retry vs degrade."""


class NexusToolNotShipped(ValueError):
    """Caller asked for a tool the deployed Worker doesn't expose.

    Raised when ``call(tool_name)`` is invoked with a name not in
    ``LIVE_NEXUS_TOOLS``. Prevents shipping a feature that depends
    on a hypothetical Nexus surface.
        """


def _strip_env_value(raw: str) -> str:
    value = raw.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        return value[1:-1].strip()
    return value


def _read_env_file(path: str | None) -> dict[str, str]:
    """Read a small KEY=value env file without exposing values."""
    if not path:
        return {}
    env_path = os.path.expanduser(path)
    if not os.path.isfile(env_path):
        return {}
    out: dict[str, str] = {}
    try:
        with open(env_path, encoding="utf-8") as handle:
            for line in handle:
                stripped = line.strip()
                if not stripped or stripped.startswith("#") or "=" not in stripped:
                    continue
                key, value = stripped.split("=", 1)
                key = key.strip()
                if key:
                    out[key] = _strip_env_value(value)
    except OSError:
        return {}
    return out


def _first_value(
    aliases: tuple[str, ...],
    *,
    env: dict[str, str],
    vault: dict[str, str],
) -> str | None:
    for name in aliases:
        value = env.get(name)
        if value and value.strip():
            return value.strip()
    for name in aliases:
        value = vault.get(name)
        if value and value.strip():
            return value.strip()
    return None


@dataclass
class NexusClient:
    base_url: str
    auth_token: str | None
    timeout_secs: float = DEFAULT_NEXUS_TIMEOUT_SECS

    @classmethod
    def from_env(cls, *, timeout_secs: float = DEFAULT_NEXUS_TIMEOUT_SECS) -> NexusClient:
        env = dict(os.environ)
        vault = _read_env_file(env.get(ENV_NEXUS_VAULT_PATH))
        base = (
            _first_value(ENV_NEXUS_BASE_URL_ALIASES, env=env, vault=vault)
            or DEFAULT_NEXUS_BASE_URL
        ).rstrip("/")
        # Subscription key is preferred — narrower scope than master.
        token = (
            _first_value(ENV_NEXUS_SUBSCRIPTION_KEY_ALIASES, env=env, vault=vault)
            or _first_value(ENV_NEXUS_MASTER_KEY_ALIASES, env=env, vault=vault)
        )
        return cls(base_url=base, auth_token=token, timeout_secs=timeout_secs)

    def call(
        self, tool_name: str, args: dict[str, Any], *,
        request_id: int | str = 1,
    ) -> dict[str, Any]:
        """Invoke one Nexus tool. Returns the parsed JSON-RPC result body."""
        if tool_name not in LIVE_NEXUS_TOOLS:
            raise NexusToolNotShipped(
                f"Nexus tool {tool_name!r} is not in LIVE_NEXUS_TOOLS. "
                f"This usually means a caller is depending on a "
                f"hypothetical primitive (e.g. nexus_consensus_*). "
                f"See WIS-cog-2026-05-06-handshake. Live tools: "
                f"{sorted(LIVE_NEXUS_TOOLS)}"
            )
        envelope = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": "tools/call",
            "params": {"name": tool_name, "arguments": args},
        }
        url = self.base_url + DEFAULT_NEXUS_MCP_PATH
        body = json.dumps(envelope).encode("utf-8")
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            "User-Agent": "atomadic-forge/0.14",
        }
        if self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"
        req = urllib.request.Request(url, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout_secs) as resp:
                raw = resp.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            raise NexusUnavailable(
                f"HTTP {exc.code} from {url}: {exc.read().decode('utf-8', 'replace')[:200]}"
            ) from exc
        except urllib.error.URLError as exc:
            raise NexusUnavailable(f"URL error to {url}: {exc.reason}") from exc
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise NexusUnavailable(f"non-JSON from {url}: {raw[:200]}") from exc
        if "error" in parsed:
            raise NexusUnavailable(
                f"JSON-RPC error from {tool_name}: {parsed['error']}"
            )
        return {
            "schema_version": SCHEMA_VERSION_NEXUS_CALL_V1,
            "tool": tool_name,
            "result": parsed.get("result"),
            "raw": parsed,
        }

    # ── Convenience wrappers for the LIVE primitives ──────────────

    def lineage_record(self, *, intent: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Append an event to AAAA-Nexus lineage.

        The Forge hive event-bus mirrors here for upstream attestation.
        ``payload`` is opaque to Nexus — we put structured JSON there
        (e.g. wisdom entry shape, consensus event shape).
        """
        return self.call("lineage_record",
                          {"intent": intent, "payload": payload})

    def identity_verify(self, *, identity: str) -> dict[str, Any]:
        return self.call("identity_verify", {"identity": identity})

    def federation_mint(self, *, did: str, scope: list[str] | None = None,
                         ttl_secs: int = 86400) -> dict[str, Any]:
        return self.call("federation_mint", {
            "did": did, "scope": list(scope or []), "ttl_secs": ttl_secs,
        })

    def authorize_action(self, *, action: str, subject: str,
                          resource: str | None = None) -> dict[str, Any]:
        args: dict[str, Any] = {"action": action, "subject": subject}
        if resource is not None:
            args["resource"] = resource
        return self.call("authorize_action", args)

    def sys_trust_gate(self, *, claim: dict[str, Any]) -> dict[str, Any]:
        return self.call("sys_trust_gate", {"claim": claim})


__all__ = ["NexusClient", "NexusUnavailable", "NexusToolNotShipped"]
