"""Tier a2 — repo public-surface sync planner.

Golden Path Lane C W6 follow-on deliverable. This composite performs the
filesystem reads for ``forge metrics repo`` and delegates deterministic
metric computation/rendering to ``a1_at_functions/repo_public_surface.py``.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from atomadic_forge.a1_at_functions.repo_public_surface import (
    DEFAULT_REPO_METRICS_CONFIG_PATH,
    compute_repo_public_metrics_from_records,
    infer_project_identity_from_metadata,
    normalize_repo_metrics_config,
    plan_repo_public_surface_from_inputs,
    render_repo_metrics_config_json,
    should_skip_public_metric_path,
)


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def _identity_for_root(root: Path) -> dict[str, str]:
    pyproject = root / "pyproject.toml"
    package_json = root / "package.json"
    return infer_project_identity_from_metadata(
        root.name,
        pyproject_text=_read_text(pyproject) if pyproject.exists() else None,
        package_json_text=_read_text(package_json) if package_json.exists() else None,
    )


def _safe_relative_path(path_text: str, fallback: str) -> str:
    path = Path(path_text)
    if path.is_absolute() or ".." in path.parts:
        return fallback
    return path.as_posix()


def load_repo_metrics_config(
    project_root: Path | str,
    config_path: Path | str | None = None,
) -> dict[str, Any]:
    """Load optional repo metrics config, falling back to defaults."""
    root = Path(project_root).resolve()
    path = Path(config_path) if config_path else root / DEFAULT_REPO_METRICS_CONFIG_PATH
    if not path.is_absolute():
        path = root / path
    raw: dict[str, Any] = {}
    if path.exists():
        try:
            loaded = json.loads(_read_text(path))
            if isinstance(loaded, dict):
                raw = loaded
        except json.JSONDecodeError:
            raw = {}
    config = normalize_repo_metrics_config(raw)
    config["artifact_path"] = _safe_relative_path(
        str(config.get("artifact_path") or "repo_metrics.json"),
        "repo_metrics.json",
    )
    return config


def compute_repo_public_metrics(project_root: Path | str) -> dict[str, Any]:
    """Compute product-facing metrics for any source repository."""
    root = Path(project_root).resolve()
    records: list[dict[str, str]] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        rel_path = path.relative_to(root)
        if should_skip_public_metric_path(tuple(rel_path.parts)):
            continue
        records.append({
            "path": rel_path.as_posix(),
            "suffix": path.suffix,
            "text": _read_text(path),
        })
    return compute_repo_public_metrics_from_records(_identity_for_root(root), records)


def _configured_documents(root: Path, config: dict[str, Any]) -> dict[str, str]:
    documents: dict[str, str] = {}
    for pattern in config.get("document_globs") or []:
        pattern_text = str(pattern)
        if not pattern_text or Path(pattern_text).is_absolute():
            continue
        for path in root.glob(pattern_text):
            if not path.is_file():
                continue
            rel_path = path.relative_to(root)
            if should_skip_public_metric_path(tuple(rel_path.parts)):
                continue
            if path.suffix.lower() not in {".md", ".mdx", ".html", ".htm"}:
                continue
            documents[rel_path.as_posix()] = _read_text(path)
    return documents


def plan_repo_public_surface_sync(
    project_root: Path | str,
    config_path: Path | str | None = None,
) -> dict[str, Any]:
    """Return planned public-surface writes for any product repo."""
    root = Path(project_root).resolve()
    config = load_repo_metrics_config(root, config_path=config_path)
    readme = root / "README.md"
    server = root / "server.json"
    return plan_repo_public_surface_from_inputs(
        project_root=str(root),
        metrics=compute_repo_public_metrics(root),
        readme_text=_read_text(readme) if readme.exists() else None,
        server_text=_read_text(server) if server.exists() else None,
        documents=_configured_documents(root, config),
        config=config,
    )


__all__ = [
    "compute_repo_public_metrics",
    "load_repo_metrics_config",
    "plan_repo_public_surface_sync",
    "render_repo_metrics_config_json",
]
