"""Tier a2 — file-backed session store for the agent-driven evolve loop.

An evolve session is a parent that spawns N successive iterate sessions
(one per round). The agent calls ``evolve_start`` to open the parent and
get the first prompt, then ``evolve_step`` repeatedly with the LLM's
responses. Forge handles the transitions: when an iterate child
terminates (converged or max_iterations), evolve decides whether to
stop or start the next round with the previous round's output as seed.

The substrate boundary stays clean: forge holds NO LLM client. The
agent drives the LLM at every turn; forge sequences the rounds and
runs verification between them.

D_max-bounded: ``rounds`` is capped at the corpus
``D_MAX_DELEGATION = 23`` because the corpus says no analytical
recursion deeper than 23. Asking for more is refused, not silently
truncated.

Storage: ``<project_root>/.atomadic-forge/evolve_sessions/<id>.json``.
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

SCHEMA_VERSION_EVOLVE_SESSION_V1 = "atomadic-forge.evolve_session/v1"


@dataclass
class EvolveSessionState:
    """Mutable parent-evolve-session state.

    Tracks the round trajectory, references the currently-active
    iterate child session, and remembers whether stagnation /
    regression have triggered halt conditions.
    """

    session_id: str
    schema_version: str = SCHEMA_VERSION_EVOLVE_SESSION_V1
    intent: str = ""
    output: str = ""
    package: str = "evolved"
    language: str = "python"
    seed_repos: list[str] = field(default_factory=list)
    target_score: float = 75.0
    rounds: int = 3                       # total rounds requested
    iterations_per_round: int = 4
    stop_on_regression: bool = False
    stagnation_threshold: int = 3

    current_round_idx: int = 0
    current_iterate_id: str | None = None
    rounds_log: list[dict[str, Any]] = field(default_factory=list)
    last_symbol_count: int = 0
    last_score: float = 0.0
    stagnant_streak: int = 0
    halt_reason: str = ""                 # set when terminal
    completed: bool = False
    created_ts: float = field(default_factory=time.time)
    updated_ts: float = field(default_factory=time.time)

    def as_dict(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "schema_version": self.schema_version,
            "intent": self.intent,
            "output": self.output,
            "package": self.package,
            "language": self.language,
            "seed_repos": list(self.seed_repos),
            "target_score": self.target_score,
            "rounds": self.rounds,
            "iterations_per_round": self.iterations_per_round,
            "stop_on_regression": self.stop_on_regression,
            "stagnation_threshold": self.stagnation_threshold,
            "current_round_idx": self.current_round_idx,
            "current_iterate_id": self.current_iterate_id,
            "rounds_log": list(self.rounds_log),
            "last_symbol_count": self.last_symbol_count,
            "last_score": self.last_score,
            "stagnant_streak": self.stagnant_streak,
            "halt_reason": self.halt_reason,
            "completed": self.completed,
            "created_ts": self.created_ts,
            "updated_ts": self.updated_ts,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> EvolveSessionState:
        return cls(
            session_id=raw["session_id"],
            schema_version=raw.get("schema_version",
                                     SCHEMA_VERSION_EVOLVE_SESSION_V1),
            intent=raw.get("intent", ""),
            output=raw.get("output", ""),
            package=raw.get("package", "evolved"),
            language=raw.get("language", "python"),
            seed_repos=list(raw.get("seed_repos", [])),
            target_score=float(raw.get("target_score", 75.0)),
            rounds=int(raw.get("rounds", 3)),
            iterations_per_round=int(raw.get("iterations_per_round", 4)),
            stop_on_regression=bool(raw.get("stop_on_regression", False)),
            stagnation_threshold=int(raw.get("stagnation_threshold", 3)),
            current_round_idx=int(raw.get("current_round_idx", 0)),
            current_iterate_id=raw.get("current_iterate_id"),
            rounds_log=list(raw.get("rounds_log", [])),
            last_symbol_count=int(raw.get("last_symbol_count", 0)),
            last_score=float(raw.get("last_score", 0.0)),
            stagnant_streak=int(raw.get("stagnant_streak", 0)),
            halt_reason=str(raw.get("halt_reason", "")),
            completed=bool(raw.get("completed", False)),
            created_ts=float(raw.get("created_ts", time.time())),
            updated_ts=float(raw.get("updated_ts", time.time())),
        )


class EvolveSessionStore:
    """File-backed CRUD over :class:`EvolveSessionState`."""

    SUBDIR = "evolve_sessions"

    def __init__(self, project_root: Path) -> None:
        self.project_root = Path(project_root).resolve()
        self.dir = self.project_root / ".atomadic-forge" / self.SUBDIR

    def _path(self, session_id: str) -> Path:
        return self.dir / f"{session_id}.json"

    def create(self, *, intent: str, output: Path, package: str,
                 language: str, target_score: float, rounds: int,
                 iterations_per_round: int,
                 stop_on_regression: bool = False,
                 stagnation_threshold: int = 3,
                 seed_repos: list[str] | None = None,
                 ) -> EvolveSessionState:
        self.dir.mkdir(parents=True, exist_ok=True)
        sid = "ev_" + uuid.uuid4().hex[:10]
        state = EvolveSessionState(
            session_id=sid,
            intent=intent,
            output=str(Path(output).resolve()),
            package=package,
            language=language,
            target_score=target_score,
            rounds=rounds,
            iterations_per_round=iterations_per_round,
            stop_on_regression=stop_on_regression,
            stagnation_threshold=stagnation_threshold,
            seed_repos=list(seed_repos or []),
        )
        self.save(state)
        return state

    def load(self, session_id: str) -> EvolveSessionState | None:
        p = self._path(session_id)
        if not p.exists():
            return None
        try:
            raw = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        return EvolveSessionState.from_dict(raw)

    def save(self, state: EvolveSessionState) -> None:
        state.updated_ts = time.time()
        self.dir.mkdir(parents=True, exist_ok=True)
        self._path(state.session_id).write_text(
            json.dumps(state.as_dict(), indent=2, default=str),
            encoding="utf-8",
        )

    def delete(self, session_id: str) -> bool:
        p = self._path(session_id)
        if not p.exists():
            return False
        try:
            p.unlink()
            return True
        except OSError:
            return False
