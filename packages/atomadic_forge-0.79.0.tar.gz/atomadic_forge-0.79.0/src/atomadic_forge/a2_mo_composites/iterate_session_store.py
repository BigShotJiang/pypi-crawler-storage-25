"""Tier a2 — file-backed session store for the agent-driven iterate /
evolve loop.

The Round-3 substrate boundary fix: forge no longer holds an LLM
client. The calling agent drives its own LLM and calls forge for
analytical certainty between turns. To make that work, forge must
persist the loop state across MCP calls — turn counter, transcript,
prior wire/certify results, target score, max iterations — so the
agent can call ``iterate_continue(session_id, response)`` without
having to ferry the whole state in JSON-RPC arguments.

Storage: one JSON file per session at
``<project_root>/.atomadic-forge/iterate_sessions/<session_id>.json``.
Pure file-based — no external service. Sessions are append-mostly
(turn log grows) but small enough that a full rewrite per turn is
fine.

Tier rationale: a2 (stateful composite) — owns disk I/O and a state
machine that tracks turn progression. Wraps the pure helpers in a1
(``forge_feedback``) and uses a0 dataclasses (``IterateSessionState``).
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

SCHEMA_VERSION_ITERATE_SESSION_V1 = "atomadic-forge.iterate_session/v1"


@dataclass
class IterateSessionState:
    """Mutable session state. The store reads/writes this as JSON.

    Naming convention matches forge's other manifests so consumers can
    rely on the schema_version field for routing.
    """

    session_id: str
    schema_version: str = SCHEMA_VERSION_ITERATE_SESSION_V1
    intent: str = ""
    output: str = ""                # absolute path
    package: str = "generated"
    language: str = "python"
    seed_repos: list[str] = field(default_factory=list)
    target_score: float = 75.0
    max_iterations: int = 5
    turn: int = 0                   # 0 = waiting for first response
    converged: bool = False
    halt_reason: str = ""           # set when done: "converged" / "max_iterations" / "regression"
    transcript: list[dict[str, Any]] = field(default_factory=list)
    last_wire: dict[str, Any] | None = None
    last_certify: dict[str, Any] | None = None
    last_score: float = 0.0
    files_written_total: int = 0
    created_ts: float = field(default_factory=time.time)
    updated_ts: float = field(default_factory=time.time)
    # Round-4-friendly: parent_session_id lets evolve sessions chain
    # iterate sessions across rounds without leaking the schema.
    parent_session_id: str | None = None
    round_idx: int = 0              # for evolve: which round this session represents

    def as_dict(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "schema_version": self.schema_version,
            "intent": self.intent,
            "output": self.output,
            "package": self.package,
            "language": self.language,
            "seed_repos": list(self.seed_repos),
            "target_score": self.target_score,
            "max_iterations": self.max_iterations,
            "turn": self.turn,
            "converged": self.converged,
            "halt_reason": self.halt_reason,
            "transcript": list(self.transcript),
            "last_wire": self.last_wire,
            "last_certify": self.last_certify,
            "last_score": self.last_score,
            "files_written_total": self.files_written_total,
            "created_ts": self.created_ts,
            "updated_ts": self.updated_ts,
            "parent_session_id": self.parent_session_id,
            "round_idx": self.round_idx,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> IterateSessionState:
        return cls(
            session_id=raw["session_id"],
            schema_version=raw.get("schema_version",
                                     SCHEMA_VERSION_ITERATE_SESSION_V1),
            intent=raw.get("intent", ""),
            output=raw.get("output", ""),
            package=raw.get("package", "generated"),
            language=raw.get("language", "python"),
            seed_repos=list(raw.get("seed_repos", [])),
            target_score=float(raw.get("target_score", 75.0)),
            max_iterations=int(raw.get("max_iterations", 5)),
            turn=int(raw.get("turn", 0)),
            converged=bool(raw.get("converged", False)),
            halt_reason=str(raw.get("halt_reason", "")),
            transcript=list(raw.get("transcript", [])),
            last_wire=raw.get("last_wire"),
            last_certify=raw.get("last_certify"),
            last_score=float(raw.get("last_score", 0.0)),
            files_written_total=int(raw.get("files_written_total", 0)),
            created_ts=float(raw.get("created_ts", time.time())),
            updated_ts=float(raw.get("updated_ts", time.time())),
            parent_session_id=raw.get("parent_session_id"),
            round_idx=int(raw.get("round_idx", 0)),
        )


class IterateSessionStore:
    """File-backed CRUD over ``IterateSessionState``.

    Storage path: ``<project_root>/.atomadic-forge/iterate_sessions/``.

    Every method is small and idempotent — the store is intended to be
    reconstructed from a project_root path on every MCP request, not
    held in memory.
    """

    SUBDIR = "iterate_sessions"

    def __init__(self, project_root: Path) -> None:
        self.project_root = Path(project_root).resolve()
        self.dir = self.project_root / ".atomadic-forge" / self.SUBDIR

    def _path(self, session_id: str) -> Path:
        return self.dir / f"{session_id}.json"

    def create(self, *, intent: str, output: Path, package: str,
                 language: str, target_score: float, max_iterations: int,
                 seed_repos: list[str] | None = None,
                 parent_session_id: str | None = None,
                 round_idx: int = 0) -> IterateSessionState:
        """Create + persist a new session, return the populated state."""
        self.dir.mkdir(parents=True, exist_ok=True)
        sid = uuid.uuid4().hex[:12]
        state = IterateSessionState(
            session_id=sid,
            intent=intent,
            output=str(Path(output).resolve()),
            package=package,
            language=language,
            target_score=target_score,
            max_iterations=max_iterations,
            seed_repos=list(seed_repos or []),
            parent_session_id=parent_session_id,
            round_idx=round_idx,
        )
        self.save(state)
        return state

    def load(self, session_id: str) -> IterateSessionState | None:
        p = self._path(session_id)
        if not p.exists():
            return None
        try:
            raw = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        return IterateSessionState.from_dict(raw)

    def save(self, state: IterateSessionState) -> None:
        state.updated_ts = time.time()
        self.dir.mkdir(parents=True, exist_ok=True)
        self._path(state.session_id).write_text(
            json.dumps(state.as_dict(), indent=2, default=str),
            encoding="utf-8",
        )

    def delete(self, session_id: str) -> bool:
        p = self._path(session_id)
        if not p.exists():
            return False
        try:
            p.unlink()
        except OSError:
            return False
        return True

    def list_active(self) -> list[str]:
        """Return session_ids whose state files exist on disk."""
        if not self.dir.exists():
            return []
        return sorted(p.stem for p in self.dir.glob("*.json"))
