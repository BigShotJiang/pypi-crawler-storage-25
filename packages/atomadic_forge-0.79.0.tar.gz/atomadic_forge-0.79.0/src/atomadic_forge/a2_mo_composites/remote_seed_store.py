"""Tier a2 — remote seed hydration cache for Forge harvest.

Golden Path Lane C W4 follow-on deliverable. ``a3_og_features`` calls
this stateful cache before ``harvest`` / ``create`` so remote
``capability_scout.clone_url`` values become local seed repos without
manual cloning; a1 scouting and emergent signature harvesters stay pure.
"""
from __future__ import annotations

import re
import subprocess
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

RunGit = Callable[[list[str]], subprocess.CompletedProcess[str]]


class RemoteSeedError(ValueError):
    """F-coded remote seed hydration failure."""


@dataclass(frozen=True)
class HydratedSeed:
    """Resolved seed repo path plus provenance metadata."""

    original: str
    path: Path
    remote_url: str | None
    status: str

    def as_dict(self) -> dict[str, str | None]:
        return {
            "original": self.original,
            "path": str(self.path),
            "remote_url": self.remote_url,
            "status": self.status,
        }


def normalize_remote_seed_url(seed: str | Path) -> str | None:
    """Return a canonical remote URL, or ``None`` for a local path."""
    raw = str(seed).strip()
    if not raw:
        return None
    value = raw.replace("\\", "/")
    if value.startswith("https:/") and not value.startswith("https://"):
        value = "https://" + value[len("https:/"):].lstrip("/")
    if value.startswith("http:/") and not value.startswith("http://"):
        value = "http://" + value[len("http:/"):].lstrip("/")
    if value.startswith("git@") and ":" in value:
        return value
    parsed = urlparse(value)
    if parsed.scheme in {"http", "https"} and parsed.netloc and parsed.path:
        return value
    if parsed.scheme in {"http", "https"}:
        raise RemoteSeedError(
            f"F0017 remote seed URL is incomplete: {raw!r}"
        )
    return None


def _default_run_git(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=180,
        check=False,
    )


def _slug_for_url(url: str) -> str:
    if url.startswith("git@"):
        tail = url.split(":", 1)[1]
        label = "git-" + tail
    else:
        parsed = urlparse(url)
        label = f"{parsed.netloc}-{parsed.path.lstrip('/')}"
    if label.endswith(".git"):
        label = label[:-4]
    slug = re.sub(r"[^A-Za-z0-9._-]+", "-", label).strip("-").lower()
    return slug or "remote-seed"


def _ensure_inside(path: Path, root: Path) -> None:
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise RemoteSeedError(
            f"F0018 remote seed cache path escaped cache root: {path}"
        ) from exc


def _run_checked(cmd: list[str], *, runner: RunGit, url: str) -> None:
    result = runner(cmd)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        raise RemoteSeedError(
            f"F0018 remote seed hydration failed for {url!r}: {detail}"
        )


def hydrate_seed_repo(
    seed: str | Path,
    *,
    cache_root: Path,
    runner: RunGit | None = None,
) -> HydratedSeed:
    """Resolve one local or remote seed into a local repo path.

    Remote seeds are cloned into ``cache_root`` on first use and
    refreshed with ``fetch`` + ``reset --hard FETCH_HEAD`` on later
    calls. The reset is scoped to Forge-owned cache directories only.
    """
    original = str(seed)
    remote_url = normalize_remote_seed_url(seed)
    if remote_url is None:
        return HydratedSeed(
            original=original,
            path=Path(seed).resolve(),
            remote_url=None,
            status="local",
        )

    run_git = runner or _default_run_git
    root = Path(cache_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    dest = (root / _slug_for_url(remote_url)).resolve()
    _ensure_inside(dest, root)

    if (dest / ".git").is_dir():
        _run_checked(["git", "-c", "core.longpaths=true", "-C", str(dest),
                      "fetch", "--depth=1", "origin"],
                     runner=run_git, url=remote_url)
        _run_checked(["git", "-c", "core.longpaths=true", "-C", str(dest),
                      "reset", "--hard", "FETCH_HEAD"],
                     runner=run_git, url=remote_url)
        status = "updated"
    else:
        if dest.exists():
            raise RemoteSeedError(
                f"F0018 remote seed cache destination exists but is not a git "
                f"repo: {dest}"
            )
        _run_checked(["git", "-c", "core.longpaths=true", "clone",
                      "--depth=1", remote_url, str(dest)],
                     runner=run_git, url=remote_url)
        status = "cloned"

    return HydratedSeed(
        original=original,
        path=dest,
        remote_url=remote_url,
        status=status,
    )


def hydrate_seed_repos(
    seeds: list[str | Path],
    *,
    cache_root: Path,
    runner: RunGit | None = None,
) -> tuple[list[Path], list[dict[str, str | None]]]:
    """Resolve a seed list and return paths plus provenance metadata."""
    hydrated = [
        hydrate_seed_repo(seed, cache_root=cache_root, runner=runner)
        for seed in seeds
    ]
    return [h.path for h in hydrated], [h.as_dict() for h in hydrated]


__all__ = (
    "HydratedSeed",
    "RemoteSeedError",
    "hydrate_seed_repo",
    "hydrate_seed_repos",
    "normalize_remote_seed_url",
)
