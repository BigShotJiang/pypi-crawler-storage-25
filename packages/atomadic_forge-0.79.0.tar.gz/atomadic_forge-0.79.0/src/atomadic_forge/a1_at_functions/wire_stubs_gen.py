"""Tier a1 — wire stub generator: auto-generate AND apply MCP/CLI stubs.

Eliminates the highest-friction step in the forge pipeline: manually editing
mcp_protocol.py and cli.py every time a new a1 function lands.

Two modes:
  generate  — returns stubs as strings (preview / dry-run)
  apply     — injects stubs directly into the right files, no copy-paste

Apply strategy (stable anchor strings, no regex needed):
  mcp_protocol.py:  handler injected before ``_tool_smell_scan``;
                    dispatch elif injected in _tool_explore (before lineage)
                    and _tool_audit (before Unknown action return);
                    enum lists updated via regex.
  cli.py:           command injected before ``@app.command("cna-check")``.
  tests/:           test file written only if it doesn't already exist.
"""
from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Any

SCHEMA_VERSION_WIRE_STUBS_V1 = "atomadic-forge.wire_stubs/v1"


def _parse_function(py_path: Path, fn_name: str) -> ast.FunctionDef | None:
    try:
        tree = ast.parse(py_path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError):
        return None
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == fn_name:
            return node
    return None


def _extract_args(node: ast.FunctionDef) -> list[tuple[str, str]]:
    """Return [(name, type_hint_str)] for all args except self/cls."""
    results = []
    annotations = {
        arg.arg: ast.unparse(arg.annotation)
        for arg in node.args.args
        if arg.annotation
    }
    for arg in node.args.args:
        if arg.arg in ("self", "cls"):
            continue
        hint = annotations.get(arg.arg, "Any")
        results.append((arg.arg, hint))
    return results


def _to_kebab(name: str) -> str:
    """convert_snake_case → convert-kebab-case."""
    return name.replace("_", "-")


def _action_name(fn_name: str) -> str:
    """build_call_graph_summary → call_graph_summary (strip leading verb)."""
    for prefix in ("build_", "compute_", "emit_", "scan_", "check_",
                   "detect_", "analyze_", "generate_", "extract_", "infer_",
                   "run_", "scout_"):
        if fn_name.startswith(prefix):
            return fn_name[len(prefix):]
    return fn_name


def _module_import_name(module_stem: str) -> str:
    return module_stem


def generate_mcp_handler(module_stem: str, fn_name: str, *,
                          fn_args: list[tuple[str, str]]) -> str:
    """Emit an ``_tool_X`` handler function string."""
    handler_name = f"_tool_{_action_name(fn_name)}"
    lines = [
        f"def {handler_name}(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:",
        f'    """Auto-generated MCP handler for {module_stem}.{fn_name}."""',
        f"    from .{module_stem} import {fn_name}",
    ]
    # Build call args
    call_parts = []
    for arg_name, arg_type in fn_args:
        if arg_name in ("project_root", "root", "repo_root"):
            call_parts.append(f"    {arg_name} = Path(args.get('project_root', project_root)).resolve()")
        elif "int" in arg_type.lower():
            call_parts.append(f"    {arg_name} = int(args.get('{arg_name}', 10))")
        elif "bool" in arg_type.lower():
            call_parts.append(f"    {arg_name} = bool(args.get('{arg_name}', False))")
        elif "str" in arg_type.lower():
            call_parts.append(f"    {arg_name} = str(args.get('{arg_name}', ''))")
        elif "list" in arg_type.lower():
            call_parts.append(f"    {arg_name} = list(args.get('{arg_name}', []))")
    lines.extend(call_parts)

    # Build the call
    positional = [a for a, _ in fn_args
                  if a in ("project_root", "root", "repo_root")]
    kw = [a for a, _ in fn_args if a not in ("project_root", "root", "repo_root")]
    pos_str = ", ".join(positional) if positional else ""
    kw_str = ", ".join(f"{a}={a}" for a in kw)
    call_args = ", ".join(filter(None, [pos_str, kw_str]))
    if not call_args:
        # Fall back to passing args dict
        call_args = "args"
    lines.append(f"    return {fn_name}({call_args})")

    return "\n".join(lines)


def generate_cli_command(module_stem: str, fn_name: str, *,
                         fn_args: list[tuple[str, str]]) -> str:
    """Emit a ``@app.command()`` stub string."""
    cmd_name = _to_kebab(_action_name(fn_name))
    cmd_fn = f"{_action_name(fn_name)}_cmd"
    lines = [
        f'@app.command("{cmd_name}")',
        f"def {cmd_fn}(",
        "    project_root: Annotated[Path, typer.Option(",
        '        "--project",',
        "        exists=True, file_okay=False, dir_okay=True, resolve_path=True,",
        '        help="Project root.")] = Path("."),',
    ]
    for arg_name, arg_type in fn_args:
        if arg_name in ("project_root", "root", "repo_root"):
            continue
        if "int" in arg_type.lower():
            lines.append(f"    {arg_name}: Annotated[int, typer.Option(\"--{_to_kebab(arg_name)}\")] = 10,")
        elif "bool" in arg_type.lower():
            lines.append(f"    {arg_name}: Annotated[bool, typer.Option(\"--{_to_kebab(arg_name)}\")] = False,")
        elif "list" in arg_type.lower():
            lines.append(f"    {arg_name}: Annotated[str, typer.Option(\"--{_to_kebab(arg_name)}\", help=\"Comma-separated list.\")] = \"\",")
        else:
            lines.append(f"    {arg_name}: Annotated[str, typer.Option(\"--{_to_kebab(arg_name)}\")] = \"\",")
    lines.append('    json_out: Annotated[bool, typer.Option("--json")] = False,')
    lines.append(") -> None:")
    lines.append(f'    """Auto-generated CLI stub for {module_stem}.{fn_name}."""')
    lines.append(f"    from ..a1_at_functions.{module_stem} import {fn_name}")

    # Build call
    call_kw_parts = []
    for arg_name, _arg_type in fn_args:
        if arg_name in ("project_root", "root", "repo_root"):
            call_kw_parts.append("project_root=project_root")
        else:
            call_kw_parts.append(f"{arg_name}={arg_name}")
    lines.append(f"    result = {fn_name}({', '.join(call_kw_parts)})")
    lines.append("    if json_out:")
    lines.append("        typer.echo(json.dumps(result, indent=2, default=str))")
    lines.append("        return")
    lines.append(f'    typer.echo(f"\\nForge {cmd_name}: {{project_root}}")')
    lines.append('    typer.echo("-" * 60)')
    lines.append("    for k, v in result.items():")
    lines.append('        if not isinstance(v, (list, dict)):')
    lines.append('            typer.echo(f"  {k}: {v}")')

    return "\n".join(lines)


def generate_test_skeleton(module_stem: str, fn_name: str, *,
                            fn_args: list[tuple[str, str]]) -> str:
    """Emit a pytest skeleton for fn_name."""
    action = _action_name(fn_name)
    schema_const = f"SCHEMA_VERSION_{action.upper()}_V1"
    has_project_root = any(a in ("project_root", "root", "repo_root")
                           for a, _ in fn_args)

    lines = [
        f'"""Auto-generated test skeleton for {module_stem}.{fn_name}."""',
        "import pytest",
        "from pathlib import Path",
        f"from atomadic_forge.a1_at_functions.{module_stem} import {fn_name}",
        "",
        "",
        f"def test_{action}_basic(tmp_path):",
        f'    """Smoke test: {fn_name} returns a schema-versioned dict."""',
    ]
    if has_project_root:
        lines.append(f"    result = {fn_name}(tmp_path)")
    else:
        lines.append(f"    result = {fn_name}([])")
    lines.extend([
        "    assert isinstance(result, dict)",
        f"    assert 'schema_version' in result  # or check '{schema_const}'",
        "",
        "",
        f"def test_{action}_returns_on_empty_input(tmp_path):",
        '    """Graceful degradation: no data → available=False or empty lists."""',
    ])
    if has_project_root:
        lines.append(f"    result = {fn_name}(tmp_path)")
    else:
        lines.append(f"    result = {fn_name}([])")
    lines.extend([
        "    # Either gracefully unavailable or returns empty results:",
        "    assert result.get('available', True) is not None",
    ])

    return "\n".join(lines)


def generate_wire_stubs(
    project_root: Path,
    *,
    module_stem: str,
    fn_name: str,
) -> dict[str, Any]:
    """Generate MCP handler, CLI stub, and test skeleton for an a1 function.

    Args:
        project_root: Repo root.
        module_stem: Module filename without .py (e.g. 'git_churn').
        fn_name: Public function name (e.g. 'compute_git_churn').

    Returns dict with ``mcp_handler``, ``cli_command``, ``test_skeleton``
    as ready-to-paste code strings.
    """
    root = Path(project_root).resolve()
    a1_dir = root / "src" / "atomadic_forge" / "a1_at_functions"
    py_path = a1_dir / f"{module_stem}.py"

    fn_node = _parse_function(py_path, fn_name)
    if fn_node is None:
        return {
            "schema_version": SCHEMA_VERSION_WIRE_STUBS_V1,
            "available": False,
            "reason": f"{fn_name} not found in {py_path}",
        }

    fn_args = _extract_args(fn_node)

    return {
        "schema_version": SCHEMA_VERSION_WIRE_STUBS_V1,
        "available": True,
        "module": module_stem,
        "function": fn_name,
        "action_name": _action_name(fn_name),
        "cli_command_name": _to_kebab(_action_name(fn_name)),
        "mcp_handler": generate_mcp_handler(module_stem, fn_name, fn_args=fn_args),
        "cli_command": generate_cli_command(module_stem, fn_name, fn_args=fn_args),
        "test_skeleton": generate_test_skeleton(module_stem, fn_name, fn_args=fn_args),
    }


# ── Apply mode — zero copy-paste ──────────────────────────────────────────────

# Stable anchor strings in mcp_protocol.py (update these if anchors ever move)
_MCP_HANDLER_ANCHOR = "\ndef _tool_smell_scan(project_root: Path"
_MCP_EXPLORE_ANCHOR = (
    '    elif action == "concept_bridge":\n'
    "        return _tool_concept_bridge(project_root, inner)\n"
    '    elif action == "lineage":'
)
_MCP_AUDIT_ANCHOR = (
    '    elif action == "concept_bridge":\n'
    "        return _tool_concept_bridge(project_root, inner)\n"
    "    return {\"error\": f\"Unknown action {action!r}\","
)
_CLI_ANCHOR = '\n@app.command("cna-check")'

# Regex patterns for the enum lists in TOOLS (explore and audit)
_EXPLORE_ENUM_RE = re.compile(
    r'("enum": \["recon".*?"swarm"\])',
    re.DOTALL,
)
_AUDIT_ENUM_RE = re.compile(
    r'("enum": \["certify".*?"concept_bridge"\])',
    re.DOTALL,
)


def _add_to_list_str(list_str: str, new_item: str) -> str:
    """Insert new_item before the closing ] of a Python list literal string."""
    stripped = list_str.rstrip()
    if new_item in stripped:
        return list_str  # already present
    # Find last quoted item before the closing bracket
    last_quote = stripped.rfind('"')
    if last_quote < 0:
        return list_str
    return stripped[: last_quote + 1] + f',\n                             "{new_item}"' + stripped[last_quote + 1 :]


def _find_pkg_paths(project_root: Path) -> tuple[Path, Path, Path, Path]:
    """Return (mcp_path, cli_path, a1_dir, tests_dir)."""
    root = Path(project_root).resolve()
    a1_dir = root / "src" / "atomadic_forge" / "a1_at_functions"
    mcp_path = a1_dir / "mcp_protocol.py"
    cli_path = root / "src" / "atomadic_forge" / "a4_sy_orchestration" / "cli.py"
    tests_dir = root / "tests"
    return mcp_path, cli_path, a1_dir, tests_dir


def apply_wire_stubs(
    project_root: Path,
    *,
    module_stem: str,
    fn_name: str,
    tools: tuple[str, ...] = ("explore", "audit"),
    write_test: bool = True,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Generate stubs and inject them directly into mcp_protocol.py, cli.py, and tests/.

    Args:
        project_root: Repo root.
        module_stem: a1 module filename stem (e.g. 'git_churn').
        fn_name: Public function name (e.g. 'compute_git_churn').
        tools: Which MCP tool dispatchers to wire into ('explore', 'audit', or both).
        write_test: Write test skeleton file if it doesn't already exist.
        dry_run: Return what would change without writing any files.

    Returns dict with ``applied``, ``files_modified``, and all stub strings.
    """
    stubs = generate_wire_stubs(project_root, module_stem=module_stem, fn_name=fn_name)
    if not stubs.get("available"):
        return stubs

    action = stubs["action_name"]
    mcp_path, cli_path, a1_dir, tests_dir = _find_pkg_paths(project_root)

    errors: list[str] = []
    files_modified: list[str] = []

    # ── 1. Inject MCP handler ──────────────────────────────────────────────
    mcp_text = mcp_path.read_text(encoding="utf-8")
    handler_block = f"\n\n{stubs['mcp_handler']}\n"

    if f"def _tool_{action}(" not in mcp_text:
        if _MCP_HANDLER_ANCHOR not in mcp_text:
            errors.append("mcp_protocol.py: handler anchor not found — insert manually")
        else:
            mcp_text = mcp_text.replace(
                _MCP_HANDLER_ANCHOR,
                handler_block + _MCP_HANDLER_ANCHOR,
            )

    # ── 2. Wire into _tool_explore dispatch ──────────────────────────────
    if "explore" in tools:
        new_elif = f'    elif action == "{action}":\n        return _tool_{action}(project_root, inner)\n'
        if f'action == "{action}"' not in mcp_text:
            if _MCP_EXPLORE_ANCHOR not in mcp_text:
                errors.append("mcp_protocol.py: explore dispatch anchor not found")
            else:
                mcp_text = mcp_text.replace(
                    _MCP_EXPLORE_ANCHOR,
                    new_elif + _MCP_EXPLORE_ANCHOR,
                )

    # ── 3. Wire into _tool_audit dispatch ────────────────────────────────
    if "audit" in tools:
        new_elif = f'    elif action == "{action}":\n        return _tool_{action}(project_root, inner)\n'
        if _MCP_AUDIT_ANCHOR in mcp_text:
            audit_fn_start = mcp_text.rfind("\ndef _tool_audit(", 0, mcp_text.find(_MCP_AUDIT_ANCHOR))
            audit_slice = mcp_text[audit_fn_start: mcp_text.find(_MCP_AUDIT_ANCHOR) + len(_MCP_AUDIT_ANCHOR)]
            if f'action == "{action}"' not in audit_slice:
                mcp_text = mcp_text.replace(
                    _MCP_AUDIT_ANCHOR,
                    new_elif + _MCP_AUDIT_ANCHOR,
                    1,  # only first occurrence = audit
                )
        else:
            errors.append("mcp_protocol.py: audit dispatch anchor not found")

    # ── 4. Update explore enum list ──────────────────────────────────────
    m = _EXPLORE_ENUM_RE.search(mcp_text)
    if m and action not in m.group(0):
        updated = _add_to_list_str(m.group(0), action)
        mcp_text = mcp_text[: m.start()] + updated + mcp_text[m.end():]

    # ── 5. Update audit enum list ─────────────────────────────────────────
    m2 = _AUDIT_ENUM_RE.search(mcp_text)
    if m2 and action not in m2.group(0):
        updated2 = _add_to_list_str(m2.group(0), action)
        mcp_text = mcp_text[: m2.start()] + updated2 + mcp_text[m2.end():]

    if not dry_run:
        mcp_path.write_text(mcp_text, encoding="utf-8")
        files_modified.append(str(mcp_path.relative_to(project_root)))

    # ── 6. Inject CLI command ─────────────────────────────────────────────
    cli_text = cli_path.read_text(encoding="utf-8")
    cmd_name = stubs["cli_command_name"]

    if f'@app.command("{cmd_name}")' not in cli_text:
        if _CLI_ANCHOR not in cli_text:
            errors.append("cli.py: cna-check anchor not found — insert manually")
        else:
            cli_block = f"\n\n{stubs['cli_command']}\n"
            cli_text = cli_text.replace(_CLI_ANCHOR, cli_block + _CLI_ANCHOR)
            if not dry_run:
                cli_path.write_text(cli_text, encoding="utf-8")
                files_modified.append(str(cli_path.relative_to(project_root)))

    # ── 7. Write test skeleton ─────────────────────────────────────────────
    test_path = tests_dir / f"test_{module_stem}.py"
    if write_test and not test_path.exists():
        if not dry_run:
            test_path.write_text(stubs["test_skeleton"], encoding="utf-8")
            files_modified.append(str(test_path.relative_to(project_root)))

    return {
        "schema_version": SCHEMA_VERSION_WIRE_STUBS_V1,
        "available": True,
        "applied": not dry_run,
        "dry_run": dry_run,
        "module": module_stem,
        "function": fn_name,
        "action_name": action,
        "cli_command_name": cmd_name,
        "files_modified": files_modified,
        "errors": errors,
        "mcp_handler": stubs["mcp_handler"],
        "cli_command": stubs["cli_command"],
        "test_skeleton": stubs["test_skeleton"],
    }
