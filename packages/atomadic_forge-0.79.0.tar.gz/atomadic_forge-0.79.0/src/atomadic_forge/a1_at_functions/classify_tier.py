"""Tier a1 — pure tier classification.

Word-boundary token matching (the substring-bug-fixed version) plus
AST-aware body signals from the body extractor. Classes with mutable
instance state get promoted to a2; frozen dataclasses, Protocol
classes, and all-staticmethod namespaces are downgraded toward a0/a1
so the classifier matches what the code actually does.

For callers that need confidence + reasoning (CLI verbose mode,
auto-fix tools that route low-confidence guesses to manual review),
``classify_tier_with_confidence`` returns the tier alongside a 0–1
score and the list of signals that fired.
"""

from __future__ import annotations

import re
from typing import Any

_WORD_RE = re.compile(r"[A-Za-z][A-Za-z0-9]*")

_CONTRACT = frozenset({"constant", "const", "schema", "manifest", "token",
                       "invariant", "proof"})
_ATOM = frozenset({"button", "textarea", "input", "validator", "validate",
                   "format", "parse", "atom"})
_COMPOSITE = frozenset({"engine", "service", "client", "manager", "store",
                        "hook", "calculator", "molecule"})
_FEATURE = frozenset({"registry", "gateway", "vault", "module", "feature",
                      "workflow", "page", "screen", "organism"})
_ORCHESTRATION = frozenset({"server", "router", "orchestrator", "bridge",
                            "runtime", "system", "main", "mcp", "cli"})


def word_tokens(text: str) -> set[str]:
    """Tokenize on word boundaries and split camelCase.

    ``"AgenticSwarm"`` → ``{"agentic", "swarm"}``; ``"atomadic-v2"`` →
    ``{"atomadic", "v2"}`` — no false-positive on ``"atom"``.
    """
    raw = _WORD_RE.findall(text)
    out: set[str] = set()
    for word in raw:
        for piece in re.findall(r"[A-Z]+(?=[A-Z][a-z])|[A-Z]?[a-z0-9]+|[A-Z]+", word):
            if piece:
                out.add(piece.lower())
        out.add(word.lower())
    return out


def _ast_class_decision(
    *, kind: str, body_signals: dict[str, Any],
) -> tuple[str | None, float, list[str]]:
    """Apply AST-driven overrides BEFORE name-based heuristics fire.

    Returns ``(tier_or_None, confidence, reasons)``. When ``tier_or_None``
    is None the caller falls back to the existing name-based classifier.

    Order of precedence inside this function reflects strength of
    evidence:
        1. Protocol class           → a0  (pure type, no impl)
        2. all-static class         → a1  (namespace of pure functions)
        3. frozen dataclass + no self-assign → a1  (immutable data carrier)
        4. has_cached_property      → a2  (instance state, even if lazy-pure)
        5. has_self_assign / mutable class collection → caller decides a2
    """
    if kind not in ("class", "type"):
        return None, 0.0, []

    if body_signals.get("is_protocol"):
        return "a0_qk_constants", 0.95, ["is_protocol"]

    # cached_property mutates instance __dict__ on first call — strong a2
    # signal. Check before the static-only path because a class can mix
    # cached_property and staticmethod.
    if body_signals.get("has_cached_property"):
        return "a2_mo_composites", 0.85, ["has_cached_property"]

    if body_signals.get("all_static_methods"):
        # Pure helpers grouped under a namespace class.
        return "a1_at_functions", 0.85, ["all_static_methods"]

    if body_signals.get("is_frozen_dataclass"):
        # Frozen dataclass = immutable data carrier. Even with helper
        # methods it's closer to a1 than a2 because its attributes
        # cannot be reassigned post-construction.
        if not body_signals.get("has_self_assign"):
            return "a1_at_functions", 0.90, ["is_frozen_dataclass"]
        # Self-assign in a frozen dataclass (likely the synthesized
        # __init__ or __post_init__) is a confused signal — let the
        # name-based path try.
        return None, 0.0, ["is_frozen_dataclass", "has_self_assign_conflict"]

    return None, 0.0, []


def classify_tier(*, name: str, kind: str, path: str = "",
                  body_signals: dict[str, Any] | None = None) -> str:
    """Return the canonical tier directory for a symbol.

    ``body_signals`` (optional) carries AST-derived flags from the body
    extractor:

      * ``has_self_assign`` — mutable instance state.
      * ``has_class_attr_collections`` — mutable class-level container.
      * ``is_protocol`` — ``Protocol`` base, pure type definition.
      * ``is_frozen_dataclass`` — ``@dataclass(frozen=True)``.
      * ``all_static_methods`` — every method is ``@staticmethod``.
      * ``has_cached_property`` — any ``@cached_property`` method.

    The AST signals win over name-based guesses where they fire, so
    the classifier matches what the code actually does, not what the
    file is *called*.
    """
    return classify_tier_with_confidence(
        name=name, kind=kind, path=path, body_signals=body_signals,
    )["tier"]


def classify_tier_with_confidence(
    *,
    name: str,
    kind: str,
    path: str = "",
    body_signals: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Return ``{"tier": "...", "confidence": 0.0-1.0, "reasons": [...]}``.

    Confidence rubric:
        0.95 — AST + structural rule (Protocol)
        0.90 — strong AST signal (frozen dataclass)
        0.85 — clear structural signal (all-static, cached_property)
        0.80 — name-based hit on a tier vocabulary
        0.60 — kind-only fallback (function → a1, class → a2)
        0.50 — no signal at all (default a1)

    The ``reasons`` list names the signals that fired so the caller
    (or the agent calling Forge) can audit the verdict.
    """
    signals = body_signals or {}
    tokens = word_tokens(f"{path} {name} {kind}")

    # AST overrides come first — they're the strongest evidence.
    ast_tier, ast_conf, ast_reasons = _ast_class_decision(
        kind=kind, body_signals=signals,
    )
    if ast_tier is not None:
        return {"tier": ast_tier, "confidence": ast_conf, "reasons": ast_reasons}

    stateful = bool(
        signals.get("has_self_assign")
        or signals.get("has_class_attr_collections")
    )

    if kind in ("class", "type") and stateful:
        reasons = [k for k in ("has_self_assign", "has_class_attr_collections")
                    if signals.get(k)]
        if tokens & _ORCHESTRATION:
            return {"tier": "a4_sy_orchestration", "confidence": 0.85,
                    "reasons": reasons + ["name_orchestration"]}
        if tokens & _FEATURE:
            return {"tier": "a3_og_features", "confidence": 0.85,
                    "reasons": reasons + ["name_feature"]}
        return {"tier": "a2_mo_composites", "confidence": 0.85,
                "reasons": reasons}

    if tokens & _CONTRACT:
        return {"tier": "a0_qk_constants", "confidence": 0.80,
                "reasons": ["name_contract"]}
    if tokens & _ATOM:
        return {"tier": "a1_at_functions", "confidence": 0.80,
                "reasons": ["name_atom"]}
    if tokens & _COMPOSITE:
        return {"tier": "a2_mo_composites", "confidence": 0.80,
                "reasons": ["name_composite"]}
    if tokens & _FEATURE:
        return {"tier": "a3_og_features", "confidence": 0.80,
                "reasons": ["name_feature"]}
    if tokens & _ORCHESTRATION:
        return {"tier": "a4_sy_orchestration", "confidence": 0.80,
                "reasons": ["name_orchestration"]}

    if kind == "function":
        return {"tier": "a1_at_functions", "confidence": 0.60,
                "reasons": ["kind_function"]}
    if kind in ("class", "type"):
        return {"tier": "a2_mo_composites", "confidence": 0.60,
                "reasons": ["kind_class_default"]}
    return {"tier": "a1_at_functions", "confidence": 0.50, "reasons": []}


_IO_ROOT_MODULES = frozenset({"urllib", "requests", "httpx", "socket",
                              "subprocess", "shutil", "os", "sqlite3",
                              "boto3", "smtplib"})
_IO_BUILTINS = frozenset({"open", "print", "input", "connect"})


def detect_effects(node: Any) -> list[str]:
    """Cheap effect inference on an ``ast.AST`` node body."""
    import ast

    effects: list[str] = []
    for child in ast.walk(node):
        if isinstance(child, ast.Call):
            f = child.func
            if isinstance(f, ast.Name) and f.id in _IO_BUILTINS:
                effects.append("io")
            elif isinstance(f, ast.Attribute):
                root = f
                while isinstance(root, ast.Attribute):
                    root = root.value
                if isinstance(root, ast.Name) and root.id in _IO_ROOT_MODULES:
                    effects.append("io")
                if f.attr in ("write", "send", "post", "put", "delete",
                               "execute", "commit"):
                    effects.append("state")
        if isinstance(child, ast.Global | ast.Nonlocal):
            effects.append("state")
    if not effects:
        return ["pure"]
    seen: list[str] = []
    for e in effects:
        if e not in seen:
            seen.append(e)
    return seen
