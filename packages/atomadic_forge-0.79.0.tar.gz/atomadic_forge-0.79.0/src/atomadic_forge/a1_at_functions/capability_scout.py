"""Tier a1 — capability scout: search GitHub for harvest-worthy repositories.

Bridges the gap between "I want a capability" and "here are repos to harvest."
Uses the GitHub Search API (no auth needed for basic search) plus heuristic
ranking on stars, freshness, and Python relevance.

Pure: no writes.  HTTP via urllib stdlib only.  Returns a graceful error dict
if the network is unavailable.
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

SCHEMA_VERSION_CAPABILITY_SCOUT_V1 = "atomadic-forge.capability_scout/v1"

_GITHUB_SEARCH = "https://api.github.com/search/repositories"
_USER_AGENT = "atomadic-forge-capability-scout/0.1"
_RATE_DELAY = 1.2  # seconds between GitHub API calls (unauthenticated: 10/min)


def _gh_search(query: str, per_page: int = 10) -> list[dict]:
    params = urllib.parse.urlencode({
        "q": query,
        "sort": "stars",
        "order": "desc",
        "per_page": per_page,
    })
    url = f"{_GITHUB_SEARCH}?{params}"
    req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT,
                                                "Accept": "application/vnd.github.v3+json"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            return data.get("items", [])
    except (urllib.error.URLError, urllib.error.HTTPError, OSError, json.JSONDecodeError):
        return []


def _score_item(item: dict, query: str) -> float:
    """Heuristic harvest-confidence score 0-100."""
    stars = item.get("stargazers_count", 0)
    lang = (item.get("language") or "").lower()
    description = (item.get("description") or "").lower()
    name = item.get("full_name", "").lower()
    topics = [t.lower() for t in item.get("topics", [])]
    pushed = item.get("pushed_at", "")

    score = 0.0

    # Stars: log scale, cap at 50 pts
    if stars > 0:
        import math
        score += min(math.log10(stars + 1) * 15, 50)

    # Python preference (forge is Python-first)
    if lang == "python":
        score += 20
    elif lang in ("rust", "typescript", "javascript"):
        score += 5

    # Query keyword match in name/description/topics
    query_words = set(query.lower().split())
    desc_words = set(description.split())
    name_words = set(name.replace("-", " ").replace("_", " ").split("/")[-1].split())
    topic_words = set(t for topic in topics for t in topic.split("-"))
    overlap = query_words & (desc_words | name_words | topic_words)
    score += len(overlap) * 4

    # Freshness: pushed within last 180 days
    if pushed:
        try:
            from datetime import datetime, timezone
            pushed_dt = datetime.fromisoformat(pushed.replace("Z", "+00:00"))
            days_old = (datetime.now(timezone.utc) - pushed_dt).days
            if days_old < 180:
                score += max(0, 10 - days_old // 18)
        except (ValueError, TypeError):
            pass

    return min(round(score, 1), 100.0)


def scout_capabilities(
    queries: list[str],
    *,
    per_query: int = 8,
    min_score: float = 30.0,
    dedupe: bool = True,
) -> dict[str, Any]:
    """Search GitHub for repos matching capability queries.

    Args:
        queries: List of search queries (e.g. ["dead code detection python"]).
        per_query: Max results per query (GitHub cap: 30 without auth).
        min_score: Minimum harvest-confidence score to include.
        dedupe: Skip repos already seen from a previous query.

    Returns structured dict with ``schema_version``, ``targets`` (ranked),
    ``query_count``, ``total_found``.  Degrades gracefully on network error.
    """
    seen_ids: set[int] = set()
    all_targets: list[dict] = []

    for i, query in enumerate(queries):
        if i > 0:
            time.sleep(_RATE_DELAY)
        items = _gh_search(f"{query} language:python", per_page=per_query)
        for item in items:
            rid = item.get("id", 0)
            if dedupe and rid in seen_ids:
                continue
            seen_ids.add(rid)
            score = _score_item(item, query)
            if score < min_score:
                continue
            all_targets.append({
                "repo": item.get("full_name", ""),
                "url": item.get("html_url", ""),
                "clone_url": item.get("clone_url", ""),
                "stars": item.get("stargazers_count", 0),
                "language": item.get("language", ""),
                "description": (item.get("description") or "")[:200],
                "topics": item.get("topics", [])[:8],
                "pushed_at": item.get("pushed_at", ""),
                "harvest_score": score,
                "matched_query": query,
            })

    # Sort by score desc
    all_targets.sort(key=lambda x: -x["harvest_score"])

    return {
        "schema_version": SCHEMA_VERSION_CAPABILITY_SCOUT_V1,
        "query_count": len(queries),
        "total_candidates": len(all_targets),
        "targets": all_targets,
    }
