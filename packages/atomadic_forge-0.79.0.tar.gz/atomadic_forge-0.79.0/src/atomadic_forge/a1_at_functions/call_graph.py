"""Tier a1 — pure call-graph builder.

Harvested from the Code Pathfinder / Moderne / Augment / Sourcegraph
competitive surface (see ``COMPETITIVE_AUDIT.md``). Closes the
call-graph gap forge had: agents driving refactors need to know
``callers(X)`` and ``callees(X)`` before mutating ``X``.

Pure deterministic AST walk:

  1. Walk every ``*.py`` under ``project_root / src / package`` (or the
     given root).
  2. For each function/method definition, extract:
     - its qualname (e.g. ``pkg.module.func`` or ``pkg.module.Class.method``)
     - the qualnames of every name it CALLS that resolves to a
       symbol in the same package
  3. From the bag of call-edges, return either ``callers(target)``
     (reverse) or ``callees(target)`` (forward) up to ``max_depth``.

No LLM is invoked. No type inference beyond name resolution — the
extractor is intentionally conservative: a call ``foo(x)`` where
``foo`` is locally bound resolves to the local-module qualname; calls
to imported names resolve only when the import is unambiguous.

This is the ~80% solution Code Pathfinder ships as its headline.
Forge gets the same surface for ~250 LOC because it's purely
analytical — no LSP server, no daemon, no embedding model.

**CNA audit (Compose-Not-Add):** the import-walker ``_collect_imports``
overlaps stylistically with helpers in ``wire_check``, ``enforce_planner``,
and ``exported_api_check`` — but each of those walks imports for a
different transform (violations / inbound-edge detection / top-level
exports). This module needs ``local_name → fully_qualified_name``,
which none of the others produce. A future refactor pass could lift
a shared ``a1.import_index`` primitive once a third or fourth caller
emerges. For now the duplication is localized and small.
"""
from __future__ import annotations

import ast
from collections import defaultdict, deque
from pathlib import Path
from typing import Any

SCHEMA_VERSION_CALL_GRAPH_V1 = "atomadic-forge.call_graph/v1"


# ── Step 1: walk a package, build the per-symbol call-edge map ────────


def _qualname(module_dotted: str, parts: tuple[str, ...]) -> str:
    return ".".join((module_dotted, *parts)) if module_dotted else ".".join(parts)


def _module_dotted(file_path: Path, package_root: Path, package: str) -> str:
    """Convert ``<package_root>/sub/foo.py`` → ``<package>.sub.foo``."""
    rel = file_path.relative_to(package_root).with_suffix("")
    parts = list(rel.parts)
    if parts[-1] == "__init__":
        parts = parts[:-1]
    if parts:
        return ".".join((package, *parts))
    return package


def _collect_imports(
    tree: ast.Module,
    *,
    module_dotted: str = "",
) -> dict[str, str]:
    """Return ``local_name → fully_qualified_name`` for the file.

    Handles both ``from x.y import z`` and ``import x.y as z``.
    Relative imports (``from . import x``, ``from ..a1 import y``) are
    resolved against ``module_dotted`` so callers in the same package
    produce fully-qualified edge targets instead of bare relative paths.
    Star imports are NOT resolved (we'd need the target module's
    public surface; out of scope for this pass).
    """
    out: dict[str, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            mod = node.module or ""
            if node.level and module_dotted:
                # Resolve relative import: strip ``level`` package segments.
                parts = module_dotted.split(".")
                base_parts = parts[:max(0, len(parts) - node.level)]
                abs_mod = ".".join(base_parts + ([mod] if mod else []))
            else:
                abs_mod = mod
            for alias in node.names:
                if alias.name == "*":
                    continue
                local = alias.asname or alias.name
                out[local] = f"{abs_mod}.{alias.name}" if abs_mod else alias.name
        elif isinstance(node, ast.Import):
            for alias in node.names:
                local = alias.asname or alias.name.split(".")[0]
                out[local] = alias.name
    return out


def _called_qualnames(
    func_body: ast.AST,
    *,
    module_dotted: str,
    imports: dict[str, str],
    locally_defined: set[str],
    package: str,
) -> set[str]:
    """Extract qualnames of calls inside a function body.

    Resolution rules (conservative):

    - ``foo()`` where ``foo`` is locally defined in this module
      → ``<module>.foo``
    - ``foo()`` where ``foo`` is imported (``imports[foo]`` exists)
      → the imported qualname (only kept if it starts with ``package``)
    - ``obj.method()`` where ``obj`` is in imports → ``<imports[obj]>.method``
    - Anything else (attributes on locals, dynamic dispatch, etc.) is
      NOT resolved — surface only confident edges, never invent.
    """
    out: set[str] = set()
    for node in ast.walk(func_body):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if isinstance(func, ast.Name):
            name = func.id
            if name in locally_defined:
                out.add(_qualname(module_dotted, (name,)))
            elif name in imports:
                resolved = imports[name]
                if resolved.startswith(package + ".") or resolved == package:
                    out.add(resolved)
        elif isinstance(func, ast.Attribute):
            # Walk the attribute chain to its leftmost Name.
            head: Any = func
            chain: list[str] = [head.attr]
            head = head.value
            while isinstance(head, ast.Attribute):
                chain.insert(0, head.attr)
                head = head.value
            if isinstance(head, ast.Name):
                root = head.id
                if root in imports:
                    resolved_root = imports[root]
                    full = ".".join((resolved_root, *chain))
                    if full.startswith(package + ".") or full == package:
                        out.add(full)
                elif root in locally_defined:
                    # local.method() — resolve under this module
                    out.add(_qualname(module_dotted, (root, *chain)))
    return out


def _collect_module_edges(
    file_path: Path,
    *,
    package_root: Path,
    package: str,
) -> dict[str, set[str]]:
    """Return ``{caller_qualname: {callee_qualname, ...}}`` for one file."""
    try:
        text = file_path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(text, filename=str(file_path))
    except (OSError, SyntaxError):
        return {}
    module_dotted = _module_dotted(file_path, package_root, package)
    imports = _collect_imports(tree, module_dotted=module_dotted)
    locally_defined: set[str] = set()
    for node in tree.body:
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef):
            locally_defined.add(node.name)

    edges: dict[str, set[str]] = defaultdict(set)
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            # Find the enclosing class (if any) by checking parents.
            # ast doesn't track parents by default; we approximate via
            # the module-body scan + simple class bag.
            caller = _qualname(module_dotted, (node.name,))
            callees = _called_qualnames(
                node, module_dotted=module_dotted,
                imports=imports, locally_defined=locally_defined,
                package=package,
            )
            edges[caller].update(callees)
        elif isinstance(node, ast.ClassDef):
            cls_name = node.name
            for child in node.body:
                if isinstance(child, ast.FunctionDef | ast.AsyncFunctionDef):
                    caller = _qualname(module_dotted, (cls_name, child.name))
                    callees = _called_qualnames(
                        child, module_dotted=module_dotted,
                        imports=imports, locally_defined=locally_defined,
                        package=package,
                    )
                    edges[caller].update(callees)
    return dict(edges)


def _walk_package_edges(
    package_root: Path,
    *,
    package: str,
) -> dict[str, set[str]]:
    edges: dict[str, set[str]] = defaultdict(set)
    for f in sorted(package_root.rglob("*.py")):
        if any(p.startswith("__") and p != "__init__.py" for p in f.parts):
            continue
        if "__pycache__" in f.parts:
            continue
        for caller, callees in _collect_module_edges(
            f, package_root=package_root, package=package,
        ).items():
            edges[caller].update(callees)
    return dict(edges)


def _build_reexport_aliases(
    package_root: Path,
    *,
    package: str,
) -> dict[str, str]:
    """Walk every ``__init__.py`` and return ``alias_qualname →
    canonical_qualname`` for explicit re-exports.

    Closes the call-graph false-negative class observed during
    Phase B dogfood: ``pkg/__init__.py`` does ``from .foo import bar``
    so callers writing ``pkg.bar`` resolve to ``pkg.bar`` while the
    real definition is ``pkg.foo.bar`` — call_graph missed the edge.
    Building an alias map lets BFS canonicalize either spelling.
    """
    aliases: dict[str, str] = {}
    for init in sorted(package_root.rglob("__init__.py")):
        if "__pycache__" in init.parts:
            continue
        try:
            text = init.read_text(encoding="utf-8", errors="replace")
            tree = ast.parse(text, filename=str(init))
        except (OSError, SyntaxError):
            continue
        # The dotted name corresponding to this __init__'s package.
        rel = init.relative_to(package_root).parent.as_posix()
        if rel in {"", "."}:
            owning = package
        else:
            owning = ".".join((package, *rel.split("/")))
        for node in ast.walk(tree):
            if not isinstance(node, ast.ImportFrom):
                continue
            mod = node.module or ""
            # Resolve relative imports to absolute.
            if node.level:
                # `from .foo import x` inside owning_pkg → owning_pkg.foo.x
                base = owning
                for _ in range(node.level - 1):
                    base = base.rsplit(".", 1)[0] if "." in base else base
                resolved_mod = f"{base}.{mod}" if mod else base
            else:
                resolved_mod = mod
            if not resolved_mod.startswith(package):
                continue
            for alias in node.names:
                if alias.name == "*":
                    continue
                exported_name = alias.asname or alias.name
                alias_q = f"{owning}.{exported_name}"
                canonical = f"{resolved_mod}.{alias.name}"
                aliases[alias_q] = canonical
    return aliases


def _canonicalize(qualname: str, aliases: dict[str, str]) -> str:
    """Resolve an alias chain to its canonical qualname (with cycle guard)."""
    seen: set[str] = set()
    current = qualname
    while current in aliases and current not in seen:
        seen.add(current)
        current = aliases[current]
    return current


# ── Step 2: traverse from a target ────────────────────────────────────


def _bfs_callees(
    edges: dict[str, set[str]],
    target: str,
    *,
    max_depth: int,
) -> list[dict[str, Any]]:
    """Forward graph: who does ``target`` call (transitively)?"""
    out: list[dict[str, Any]] = []
    seen: set[str] = {target}
    queue: deque[tuple[str, int]] = deque([(target, 0)])
    while queue:
        node, depth = queue.popleft()
        if depth >= max_depth:
            continue
        for callee in sorted(edges.get(node, ())):
            if callee in seen:
                continue
            seen.add(callee)
            out.append({"qualname": callee, "depth": depth + 1, "via": node})
            queue.append((callee, depth + 1))
    return out


def _bfs_callers(
    edges: dict[str, set[str]],
    target: str,
    *,
    max_depth: int,
) -> list[dict[str, Any]]:
    """Reverse graph: who calls ``target`` (transitively)?"""
    # Invert the edge map.
    reverse: dict[str, set[str]] = defaultdict(set)
    for caller, callees in edges.items():
        for callee in callees:
            reverse[callee].add(caller)
    return _bfs_callees(dict(reverse), target, max_depth=max_depth)


def _detect_package_name(project_root: Path) -> str:
    """Read the package name from pyproject.toml [project].name, falling back
    to the folder name.  Hyphens are NOT normalised here — callers do that."""
    pyproject = project_root / "pyproject.toml"
    if pyproject.exists():
        try:
            text = pyproject.read_text(encoding="utf-8", errors="replace")
            # Simple regex-free scan: look for `name = "..."` under [project].
            in_project = False
            for line in text.splitlines():
                stripped = line.strip()
                if stripped == "[project]":
                    in_project = True
                    continue
                if stripped.startswith("[") and stripped != "[project]":
                    in_project = False
                if in_project and stripped.startswith("name"):
                    parts = stripped.split("=", 1)
                    if len(parts) == 2:
                        return parts[1].strip().strip('"').strip("'")
        except OSError:
            pass
    return project_root.name


def build_call_graph(args: dict[str, Any]) -> dict[str, Any]:
    """The MCP-side entry. See module docstring for the contract.

    Args (from the dispatcher):
      * ``qualname`` (required): target symbol fully-qualified name.
      * ``project_root`` (default: cwd): repo root.
      * ``package`` (default: derived from project_root name): top-level
        package to walk under ``project_root / src / package``.
      * ``direction`` (default ``"both"``): ``"callers"`` | ``"callees"`` |
        ``"both"``.
      * ``max_depth`` (default 3): max hops.
    """
    qualname = str(args["qualname"])
    project_root = Path(args.get("project_root") or ".").resolve()
    direction = str(args.get("direction", "both"))
    max_depth = int(args.get("max_depth", 3))
    if max_depth < 1 or max_depth > 10:
        raise ValueError(
            f"max_depth must be in 1..10, got {max_depth}"
        )

    # Resolve the package name: explicit > pyproject.toml > folder-name fallback.
    # Normalise hyphens to underscores since Python identifiers never have them.
    _raw_package = args.get("package") or _detect_package_name(project_root)
    package = _raw_package.replace("-", "_")

    package_root = project_root / "src" / package
    if not package_root.exists():
        # Fallback: try project_root directly (some repos don't use src/).
        candidate = project_root / package
        package_root = candidate if candidate.exists() else project_root

    edges = _walk_package_edges(package_root, package=package)
    aliases = _build_reexport_aliases(package_root, package=package)

    # Canonicalize both sides of every edge so re-exports converge.
    if aliases:
        canonical_edges: dict[str, set[str]] = defaultdict(set)
        for caller, callees_set in edges.items():
            canonical_caller = _canonicalize(caller, aliases)
            for callee in callees_set:
                canonical_edges[canonical_caller].add(
                    _canonicalize(callee, aliases)
                )
        edges = dict(canonical_edges)

    canonical_target = _canonicalize(qualname, aliases) if aliases else qualname

    callers: list[dict[str, Any]] = []
    callees: list[dict[str, Any]] = []
    if direction in ("callers", "both"):
        callers = _bfs_callers(edges, canonical_target, max_depth=max_depth)
    if direction in ("callees", "both"):
        callees = _bfs_callees(edges, canonical_target, max_depth=max_depth)

    return {
        "schema_version": SCHEMA_VERSION_CALL_GRAPH_V1,
        "qualname": qualname,
        "canonical_qualname": canonical_target,
        "package": package,
        "package_root": str(package_root),
        "direction": direction,
        "max_depth": max_depth,
        "edge_count": sum(len(v) for v in edges.values()),
        "node_count": len(edges),
        "alias_count": len(aliases),
        "callers": callers,
        "callees": callees,
        "callers_count": len(callers),
        "callees_count": len(callees),
        "target_in_graph": canonical_target in edges,
    }


# ── Whole-package summary (pyan synthesis) ────────────────────────────

SCHEMA_VERSION_CALL_GRAPH_SUMMARY_V1 = "atomadic-forge.call_graph_summary/v1"


def _compute_fan_in(edges: dict[str, set[str]]) -> dict[str, int]:
    fan_in: dict[str, int] = defaultdict(int)
    for callees in edges.values():
        for callee in callees:
            fan_in[callee] += 1
    return dict(fan_in)


def _max_chain_depth(
    edges: dict[str, set[str]],
    starts: list[str],
    *,
    cap: int = 15,
) -> int:
    """BFS from each start node; return the longest path found (capped)."""
    best = 0
    for start in starts[:100]:
        visited: set[str] = {start}
        queue: deque[tuple[str, int]] = deque([(start, 0)])
        while queue:
            node, d = queue.popleft()
            if d >= cap:
                continue
            for callee in edges.get(node, ()):
                if callee not in visited:
                    visited.add(callee)
                    if d + 1 > best:
                        best = d + 1
                    queue.append((callee, d + 1))
    return best


def build_call_graph_summary(args: dict[str, Any]) -> dict[str, Any]:
    """Whole-package call-graph portfolio: orphans, hotspots, max depth.

    Synthesized from pyan (David Fraser) whole-graph analysis concepts.
    Unlike ``build_call_graph`` (per-symbol callers/callees), this gives
    a portfolio view of the entire package's call structure — useful for
    dead-code audits, refactor prioritization, and complexity estimation.

    Args (from the dispatcher):
      * ``project_root`` (default: cwd): repo root.
      * ``package`` (default: derived): top-level package name.
      * ``top_n`` (default 10): number of hotspot/orphan rows to return.
    """
    project_root = Path(args.get("project_root") or ".").resolve()
    top_n = min(int(args.get("top_n", 10)), 50)

    _raw_package = args.get("package") or _detect_package_name(project_root)
    package = _raw_package.replace("-", "_")

    package_root = project_root / "src" / package
    if not package_root.exists():
        candidate = project_root / package
        package_root = candidate if candidate.exists() else project_root

    edges = _walk_package_edges(package_root, package=package)
    aliases = _build_reexport_aliases(package_root, package=package)

    if aliases:
        canonical_edges: dict[str, set[str]] = defaultdict(set)
        for caller, callees_set in edges.items():
            canonical_caller = _canonicalize(caller, aliases)
            for callee in callees_set:
                canonical_edges[canonical_caller].add(
                    _canonicalize(callee, aliases)
                )
        edges = dict(canonical_edges)

    fan_in = _compute_fan_in(edges)

    # Defined = every function that appears as a caller (has ≥1 outgoing edge).
    defined: set[str] = {f for f in edges if f.startswith(package)}
    called: set[str] = {f for f in fan_in if f.startswith(package)}

    # Uncalled callers: defined but never called from within the package.
    # These may be entry-points (CLI/MCP handlers) or dead code.
    uncalled = sorted(defined - called)

    # Hotspots: package functions with the highest internal fan-in.
    hotspots = sorted(
        [{"qualname": q, "fan_in": c} for q, c in fan_in.items()
         if q.startswith(package)],
        key=lambda x: -x["fan_in"],
    )[:top_n]

    max_depth = _max_chain_depth(edges, uncalled)

    total_edges = sum(len(v) for v in edges.values())

    return {
        "schema_version": SCHEMA_VERSION_CALL_GRAPH_SUMMARY_V1,
        "package": package,
        "package_root": str(package_root),
        "total_callers": len(defined),
        "total_edges": total_edges,
        "uncalled_callers_count": len(uncalled),
        "uncalled_callers": uncalled[:top_n],
        "hotspot_count": len(hotspots),
        "hotspots": hotspots,
        "max_call_depth": max_depth,
        "alias_count": len(aliases),
    }
