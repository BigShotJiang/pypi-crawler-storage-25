"""Tier a1 — pure code-smell scanner.

Harvested from the Sonar / SonarQube competitive surface (see
``COMPETITIVE_AUDIT.md``). Closes the code-smell gap forge had: a
forge-certified repo with 100/100 structural integrity could still
have cyclomatic-complexity-30 monsters and duplicated logic blocks
that hurt long-term maintainability.

Three deterministic detectors, all AST-driven, no LLM:

  * **Cyclomatic complexity** — counts branch points (if/elif, while,
    for, try/except, and/or short-circuits, comprehensions with
    conditions). Functions with cc > ``cc_threshold`` are flagged.
  * **Long functions** — functions with body LOC > ``loc_threshold``
    are flagged. Single best signal that a function does too much.
  * **Duplicated function bodies** — uses the existing ``code_signature``
    AST hash at the function level (not the module level). Functions
    in different files that hash to the same shape are flagged as
    duplication candidates.

The output is a ``SmellReport`` with per-detector findings + a
single overall ``smell_score`` (0-100, higher = cleaner). Forge's
``certify`` is structural; ``smell_scan`` is maintainability.

Tier rationale: a1 (pure analytics over AST). No I/O outside source
reads. No state. Composes a1 ``code_signature``.
"""
from __future__ import annotations

import ast
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

SCHEMA_VERSION_SMELL_SCAN_V1 = "atomadic-forge.smell_scan/v1"


@dataclass
class ComplexityFinding:
    qualname: str
    file: str
    line: int
    complexity: int


@dataclass
class LongFunctionFinding:
    qualname: str
    file: str
    line: int
    loc: int


@dataclass
class DuplicationFinding:
    body_hash: str
    members: list[dict[str, str]]  # [{qualname, file, line}, ...]


@dataclass
class SmellReport:
    schema_version: str = SCHEMA_VERSION_SMELL_SCAN_V1
    project_root: str = ""
    function_count: int = 0
    complexity_findings: list[ComplexityFinding] = field(default_factory=list)
    long_function_findings: list[LongFunctionFinding] = field(default_factory=list)
    duplication_findings: list[DuplicationFinding] = field(default_factory=list)
    smell_score: float = 100.0
    cc_threshold: int = 10
    loc_threshold: int = 50
    # Transparency for the smell_score formula. Empty by default for
    # back-compat with callers that round-trip a SmellReport without
    # going through smell_scan().
    smell_score_components: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "project_root": self.project_root,
            "function_count": self.function_count,
            "complexity_findings": [asdict(f) for f in self.complexity_findings],
            "long_function_findings": [asdict(f) for f in self.long_function_findings],
            "duplication_findings": [asdict(f) for f in self.duplication_findings],
            "smell_score": self.smell_score,
            "cc_threshold": self.cc_threshold,
            "loc_threshold": self.loc_threshold,
            "smell_score_components": self.smell_score_components,
        }


# ── Cyclomatic complexity ──────────────────────────────────────────────
# Standard McCabe formulation: CC = 1 + branch points.
# Branches counted:
#   if / elif        — each branch
#   while / for      — loops
#   except handler   — each except clause
#   and / or         — short-circuit operators (each occurrence)
#   ternary (a if b else c) — counts as one branch
#   comprehension `if` clauses — each
#   match / case (Py3.10+) — each non-default case

def _cyclomatic_complexity(func_body: ast.AST) -> int:
    cc = 1
    for node in ast.walk(func_body):
        if isinstance(node, ast.If | ast.While | ast.For | ast.AsyncFor):
            cc += 1
        elif isinstance(node, ast.Try):
            cc += len(node.handlers)
        elif isinstance(node, ast.BoolOp):
            cc += max(0, len(node.values) - 1)
        elif isinstance(node, ast.IfExp):
            cc += 1
        elif isinstance(node, ast.comprehension):
            cc += len(node.ifs)
        elif hasattr(ast, "Match") and isinstance(node, ast.Match):
            non_default = [
                c for c in node.cases
                if not (isinstance(c.pattern, ast.MatchAs)
                         and c.pattern.pattern is None)
            ]
            cc += len(non_default)
    return cc


# ── Function LOC ───────────────────────────────────────────────────────


def _function_loc(func: ast.FunctionDef | ast.AsyncFunctionDef) -> int:
    if not func.body:
        return 0
    last = func.body[-1]
    end = getattr(last, "end_lineno", None) or last.lineno
    return max(1, end - func.lineno)


# ── Function body hash (for duplication detection) ────────────────────
#
# Reuse the existing a1.code_signature normalizer: it strips arg names
# and string-literal contents, then hashes the AST shape. Two functions
# with the same shape (different names) get the same hash → flagged.

def _function_body_hash(func: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    from .code_signature import _hash, _normalize_ast
    # Normalize the body only (not the def line) so name differences
    # don't affect the hash.
    body_node = ast.Module(body=func.body, type_ignores=[])
    return _hash(_normalize_ast(body_node))


# ── Walker ─────────────────────────────────────────────────────────────


_EXCLUDED_DIRS = frozenset({"__pycache__", "build", "dist", ".eggs", ".tox", "node_modules"})


def _walk_functions(root: Path):
    """Yield (qualname, file_path, lineno, func_node) for every function
    + method in every .py under root."""
    for f in sorted(root.rglob("*.py")):
        if any(part in _EXCLUDED_DIRS for part in f.parts):
            continue
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
            tree = ast.parse(text, filename=str(f))
        except (OSError, SyntaxError):
            continue
        rel = str(f.relative_to(root).as_posix())
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                # Try to find the enclosing class for qualname purposes.
                # ast doesn't track parents — we approximate by walking
                # the tree once with parent links.
                yield (node.name, rel, node.lineno, node)


def smell_scan(
    project_root: Path,
    *,
    cc_threshold: int = 10,
    loc_threshold: int = 50,
    package_subdir: str | None = None,
) -> SmellReport:
    """Run all three detectors over a Python tree.

    Args:
        project_root: repo root.
        cc_threshold: cyclomatic complexity flag-above (default 10).
        loc_threshold: function-body LOC flag-above (default 50).
        package_subdir: optional subdir under project_root to scan
            (e.g. ``"src/mypkg"``). When None, scans project_root.

    Returns:
        :class:`SmellReport` with findings + a synthesized smell_score
        (0-100; 100 = no smells).
    """
    project_root = Path(project_root).resolve()
    walk_root = (project_root / package_subdir) if package_subdir else project_root
    if not walk_root.exists():
        return SmellReport(
            project_root=str(project_root),
            cc_threshold=cc_threshold,
            loc_threshold=loc_threshold,
            smell_score=0.0,
        )

    function_count = 0
    complexity_findings: list[ComplexityFinding] = []
    long_findings: list[LongFunctionFinding] = []
    body_hashes: dict[str, list[dict[str, str]]] = defaultdict(list)

    for name, rel, lineno, node in _walk_functions(walk_root):
        function_count += 1
        cc = _cyclomatic_complexity(node)
        if cc > cc_threshold:
            complexity_findings.append(ComplexityFinding(
                qualname=name, file=rel, line=lineno, complexity=cc,
            ))
        loc = _function_loc(node)
        if loc > loc_threshold:
            long_findings.append(LongFunctionFinding(
                qualname=name, file=rel, line=lineno, loc=loc,
            ))
        if loc >= 5:
            # Skip trivial 1-4 line functions for dup detection — they
            # often share shape (e.g. simple getters) without being a
            # real smell.
            try:
                h = _function_body_hash(node)
            except Exception:  # noqa: BLE001
                continue
            body_hashes[h].append({
                "qualname": name, "file": rel, "line": str(lineno),
            })

    duplication_findings: list[DuplicationFinding] = [
        DuplicationFinding(body_hash=h, members=members)
        for h, members in body_hashes.items()
        if len(members) > 1
    ]

    # ── smell_score: density-based, interpretable, 0..100 ───────────────
    #
    # The previous formula was `100 - (2*cc + long + 3*dup)`, floored at
    # 0. Any moderately-sized Python tree blew past 100 weighted points
    # almost immediately and reported 0.0 — a useless headline number.
    #
    # New formula: weighted findings per function, scaled. A small floor
    # on the denominator prevents tiny repos from being punished for a
    # single hotspot, and the multiplier (50) is calibrated so a repo
    # with ~one weighted-finding-per-three-functions lands around 83 —
    # i.e. "mostly clean, with known hotspots."
    weighted_findings = (
        2 * len(complexity_findings)
        + 1 * len(long_findings)
        + 3 * len(duplication_findings)
    )
    denom = max(50, function_count)
    density = weighted_findings / denom if denom else 0.0
    smell_score = max(0.0, min(100.0, 100.0 - density * 50.0))

    return SmellReport(
        project_root=str(project_root),
        function_count=function_count,
        complexity_findings=complexity_findings,
        long_function_findings=long_findings,
        duplication_findings=duplication_findings,
        smell_score=round(smell_score, 1),
        cc_threshold=cc_threshold,
        loc_threshold=loc_threshold,
        smell_score_components={
            "weighted_findings": weighted_findings,
            "function_count":    function_count,
            "denom":              denom,
            "density":            round(density, 4),
            "formula":            "100 - density * 50, clamped [0,100]",
            "weights":            {"cc": 2, "long": 1, "dup_group": 3},
        },
    )
