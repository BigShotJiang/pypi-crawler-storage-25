"""Tier a1 — pure handoff entry construction + parsers.

Builds an ``atomadic-forge.handoff/v1`` dict from caller-supplied fields
and (optionally) a parsed pytest summary line. No I/O — the caller is
responsible for collecting git changes, running pytest, and writing the
result. Keeping it pure means the same builder powers the CLI, the MCP
tool, and any future driver.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import re
from typing import Any

from ..a0_qk_constants.handoff_constants import (
    AXIOM_GUARD_PASS,
    AXIOM_GUARD_VALUES,
    KEY_CONTEXT_MAX_CHARS,
    SCHEMA_VERSION_HANDOFF_V1,
)

# Matches the standard pytest tail line: "5 passed, 2 failed, 1 skipped in 0.42s".
# Case-insensitive; tolerates extra whitespace and ANSI control bytes the test
# runner may emit on Windows terminals.
_PYTEST_SUMMARY_RE = re.compile(
    r"(?P<n>\d+)\s+(?P<kind>passed|failed|skipped|errors?|xfailed|xpassed|deselected|warnings?)",
    re.IGNORECASE,
)


def parse_pytest_summary(summary_text: str) -> dict[str, int]:
    """Extract counts from a pytest tail summary string.

    Returns ``{"passed": N, "failed": N, "skipped": N}`` (always all three
    keys; missing kinds default to 0). Unknown kinds are ignored.
    """
    out = {"passed": 0, "failed": 0, "skipped": 0}
    if not summary_text:
        return out
    for match in _PYTEST_SUMMARY_RE.finditer(summary_text):
        n = int(match.group("n"))
        kind = match.group("kind").lower().rstrip("s")
        if kind == "error":
            kind = "failed"
        if kind in out:
            out[kind] = n
    return out


def _utc_now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _normalize_paths(paths: list[str] | None) -> list[str]:
    if not paths:
        return []
    seen: set[str] = set()
    out: list[str] = []
    for p in paths:
        if not isinstance(p, str):
            continue
        s = p.replace("\\", "/").strip()
        if s and s not in seen:
            seen.add(s)
            out.append(s)
    return out


def _normalize_strings(items: list[str] | None) -> list[str]:
    if not items:
        return []
    return [s for s in (str(i).strip() for i in items) if s]


def _truncate(text: str, *, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[: limit - 3] + "..."


def _session_id_for(*, agent_name: str, timestamp: str) -> str:
    h = hashlib.sha256(f"{agent_name}|{timestamp}".encode()).hexdigest()
    return f"HOFF-{h[:12]}"


def make_handoff_entry(
    *,
    agent_name: str = "anonymous",
    work_completed: list[str] | None = None,
    files_modified: list[str] | None = None,
    files_created: list[str] | None = None,
    test_results: dict[str, int] | None = None,
    pending_tasks: list[str] | None = None,
    key_context: str = "",
    warnings: list[str] | None = None,
    axiom_guard_status: str = AXIOM_GUARD_PASS,
    session_id: str | None = None,
    timestamp: str | None = None,
) -> dict[str, Any]:
    """Build the canonical v1 handoff dict.

    All inputs are normalized: paths use forward slashes + dedup, lists
    drop empty entries, ``key_context`` is truncated to
    ``KEY_CONTEXT_MAX_CHARS``. ``axiom_guard_status`` MUST be one of
    ``PASS``/``QUARANTINE`` — anything else raises ``ValueError`` so the
    caller can't silently emit a bad gate.
    """
    if axiom_guard_status not in AXIOM_GUARD_VALUES:
        raise ValueError(
            f"axiom_guard_status must be one of {sorted(AXIOM_GUARD_VALUES)}, "
            f"got {axiom_guard_status!r}"
        )

    ts = timestamp or _utc_now_iso()
    sid = session_id or _session_id_for(agent_name=agent_name, timestamp=ts)

    tr = test_results or {}
    test_block = {
        "passed": int(tr.get("passed", 0)),
        "failed": int(tr.get("failed", 0)),
        "skipped": int(tr.get("skipped", 0)),
    }

    return {
        "schema_version": SCHEMA_VERSION_HANDOFF_V1,
        "session_id": sid,
        "timestamp": ts,
        "agent_name": str(agent_name or "anonymous"),
        "work_completed": _normalize_strings(work_completed),
        "files_modified": _normalize_paths(files_modified),
        "files_created": _normalize_paths(files_created),
        "test_results": test_block,
        "pending_tasks": _normalize_strings(pending_tasks),
        "key_context": _truncate(key_context or "", limit=KEY_CONTEXT_MAX_CHARS),
        "warnings": _normalize_strings(warnings),
        "axiom_guard_status": axiom_guard_status,
    }


__all__ = [
    "make_handoff_entry",
    "parse_pytest_summary",
]
