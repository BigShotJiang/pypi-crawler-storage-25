"""Tier a1 — dead code checker: find defined-but-unreferenced symbols.

Synthesised from vulture (jendrikseipp/vulture) — MIT license.
Uses pure AST analysis to find names that are defined but never imported,
called, or accessed in the scanned package.  No dynamic analysis required.

Pure: read-only AST walks, no subprocess, no writes.  Degrades gracefully
on syntax errors by reporting the offending file and skipping it.
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Any

SCHEMA_VERSION_DEAD_CODE_V1 = "atomadic-forge.dead_code/v1"


def _collect_definitions(tree: ast.AST, module: str) -> dict[str, str]:
    """Collect all top-level name definitions: {qualname: kind}."""
    defs: dict[str, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            defs[f"{module}.{node.name}"] = "function"
        elif isinstance(node, ast.ClassDef):
            defs[f"{module}.{node.name}"] = "class"
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and not target.id.startswith("_"):
                    defs[f"{module}.{target.id}"] = "variable"
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                name = alias.asname or alias.name
                if not name.startswith("_"):
                    defs[f"{module}.{name}"] = "import"
    return defs


def _collect_usages(tree: ast.AST) -> set[str]:
    """Collect all name tokens used (called, accessed, passed) in a module."""
    usages: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            usages.add(node.id)
        elif isinstance(node, ast.Attribute):
            usages.add(node.attr)
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                usages.add(node.func.id)
            elif isinstance(node.func, ast.Attribute):
                usages.add(node.func.attr)
    return usages


def check_dead_code(
    project_root: Path,
    *,
    package: str | None = None,
    include_imports: bool = False,
    include_variables: bool = False,
    confidence_threshold: float = 60.0,
) -> dict[str, Any]:
    """Find defined-but-unreferenced symbols across a Python package.

    Args:
        project_root: Repository root.
        package: Package subdirectory to scan. Auto-detected if None.
        include_imports: Include unused imports in results (noisy).
        include_variables: Include unused module-level variables.
        confidence_threshold: Minimum confidence to report (60–100).

    Returns dict with ``schema_version``, ``dead_symbols``, counts, and
    per-module breakdowns.  ``confidence`` is higher when a symbol is
    never referenced in ANY file in the package (100) vs. only some (60–80).
    """
    root = Path(project_root).resolve()

    # Locate package
    src = root / "src"
    if package:
        pkg_dir = (src / package) if src.is_dir() else (root / package)
    else:
        pkg_dir = None
        for candidate in ([src] if src.is_dir() else [root]):
            for sub in sorted(candidate.iterdir()):
                if sub.is_dir() and (sub / "__init__.py").exists():
                    pkg_dir = sub
                    break
            if pkg_dir:
                break
    if pkg_dir is None or not pkg_dir.is_dir():
        return {
            "schema_version": SCHEMA_VERSION_DEAD_CODE_V1,
            "available": False,
            "reason": "package directory not found",
        }

    py_files = sorted(pkg_dir.rglob("*.py"))
    trees: list[tuple[str, ast.AST]] = []
    parse_errors: list[str] = []

    for py in py_files:
        rel = py.relative_to(pkg_dir)
        module = ".".join(rel.with_suffix("").parts).replace(".__init__", "")
        try:
            tree = ast.parse(py.read_text(encoding="utf-8", errors="replace"))
            trees.append((module, tree))
        except SyntaxError as e:
            parse_errors.append(f"{py}: {e}")

    # Gather all definitions
    all_defs: dict[str, str] = {}
    for module, tree in trees:
        all_defs.update(_collect_definitions(tree, module))

    # Gather all usages (unqualified names) across the whole package
    all_usages: set[str] = set()
    for _, tree in trees:
        all_usages.update(_collect_usages(tree))

    dead_symbols: list[dict] = []
    for qualname, kind in sorted(all_defs.items()):
        if kind == "import" and not include_imports:
            continue
        if kind == "variable" and not include_variables:
            continue
        # Extract the bare name (last segment)
        bare_name = qualname.rsplit(".", 1)[-1]
        if bare_name.startswith("_"):
            continue
        # __dunder__ methods are always used implicitly
        if bare_name.startswith("__") and bare_name.endswith("__"):
            continue
        if bare_name in all_usages:
            continue
        # Not found in any usage — dead
        confidence = 80 if kind in ("function", "class") else 60
        if confidence < confidence_threshold:
            continue
        module = qualname.rsplit(".", 1)[0] if "." in qualname else qualname
        dead_symbols.append({
            "qualname": qualname,
            "kind": kind,
            "confidence": confidence,
            "module": module,
        })

    return {
        "schema_version": SCHEMA_VERSION_DEAD_CODE_V1,
        "available": True,
        "package": pkg_dir.name,
        "files_scanned": len(trees),
        "parse_errors": parse_errors,
        "dead_symbol_count": len(dead_symbols),
        "dead_symbols": dead_symbols,
        "dead_by_kind": {
            k: sum(1 for s in dead_symbols if s["kind"] == k)
            for k in ("function", "class", "variable", "import")
        },
    }
