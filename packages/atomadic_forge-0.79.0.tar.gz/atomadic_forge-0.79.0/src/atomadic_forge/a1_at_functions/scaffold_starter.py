"""Tier a1 — pure renderers for the surrounding package starter files.

Forge scaffolds ``README.md``, ``.gitignore``, ``tests/__init__.py``, and
``tests/conftest.py`` once at iterate Round 0 so the generated package is
a complete, conventional Python project from the first turn.  The LLM
never has to remember to write these — it focuses on the actual code.
"""

from __future__ import annotations

from collections.abc import Iterable


def render_readme(
    *,
    package: str,
    intent: str,
    source_repos: list[str] | None = None,
    symbol_count: int | None = None,
    tier_distribution: dict[str, int] | None = None,
    file_count: int | None = None,
    digest: str | None = None,
) -> str:
    """Render a showcase README for an absorbed or materialized package.

    All harvest-metadata kwargs are optional for backward compatibility;
    when provided they enrich the README with provenance, stats, and a
    tier breakdown. Closes the doc-update enhancement directive: the
    output is a stand-alone showcase, never an overwrite of an existing
    file (callers must check existence before writing).
    """
    safe_intent = intent.strip().replace("`", "'")
    src_links: list[str] = []
    for repo in source_repos or []:
        s = repo.strip()
        if not s:
            continue
        if s.startswith("http://") or s.startswith("https://"):
            src_links.append(f"- [{s}]({s})")
        else:
            src_links.append(f"- `{s}`")

    parts: list[str] = []
    parts.append(f"# {package}")
    parts.append("")
    parts.append(
        "> Forged by [Atomadic Forge](https://atomadic.tech) — "
        "deterministic absorption of source code into the 5-tier "
        "monadic standard, with import-law guarantees and a self-"
        "verifying CI gate."
    )
    parts.append("")
    if symbol_count or tier_distribution or file_count or digest:
        parts.append("## At a glance")
        parts.append("")
        parts.append("| Signal | Value |")
        parts.append("|--------|-------|")
        if symbol_count is not None:
            parts.append(f"| Symbols absorbed | **{symbol_count:,}** |")
        if file_count is not None:
            parts.append(f"| Files emitted | **{file_count:,}** |")
        if tier_distribution:
            tier_total = sum(tier_distribution.values())
            parts.append(f"| Tiers populated | **{len(tier_distribution)}/5** "
                         f"({tier_total:,} symbols total) |")
        if digest:
            parts.append(f"| Manifest digest | `{digest}` |")
        parts.append("| Wire-law verdict | **PASS** (zero upward imports) |")
        parts.append("")
    parts.append("## Intent")
    parts.append("")
    parts.append(f"> {safe_intent}")
    parts.append("")
    if src_links:
        parts.append("## Source repositories")
        parts.append("")
        parts.extend(src_links)
        parts.append("")
        parts.append(
            "Forge ingested these repos through `forge transmute auto`, "
            "classified every public symbol into its 5-tier home, and "
            "emitted this package with the import law mechanically "
            "enforced. No LLM was in the absorption path."
        )
        parts.append("")
    parts.append("## Architecture — the 5-tier monadic standard")
    parts.append("")
    parts.append("Imports flow strictly downward — `aN` may import from "
                 "`a0..a(N-1)` only. The wire checker enforces this on "
                 "every commit; violations cannot ship.")
    parts.append("")
    parts.append("| Tier | Directory | Lives here |")
    parts.append("|------|-----------|------------|")
    parts.append(
        f"| a0 | `src/{package}/a0_qk_constants/` | constants, enums, TypedDicts |")
    parts.append(
        f"| a1 | `src/{package}/a1_at_functions/` | pure stateless functions |")
    parts.append(
        f"| a2 | `src/{package}/a2_mo_composites/` | stateful classes & clients |")
    parts.append(
        f"| a3 | `src/{package}/a3_og_features/` | feature orchestrators |")
    parts.append(
        f"| a4 | `src/{package}/a4_sy_orchestration/` | CLI / MCP entry points |")
    if tier_distribution:
        parts.append("")
        parts.append("**Symbol distribution after absorption:**")
        parts.append("")
        for tier in (
            "a0_qk_constants", "a1_at_functions", "a2_mo_composites",
            "a3_og_features", "a4_sy_orchestration",
        ):
            count = tier_distribution.get(tier, 0)
            if count:
                parts.append(f"- **{tier}** — {count:,} symbols")
    parts.append("")
    parts.append("## Quickstart")
    parts.append("")
    parts.append("```bash")
    parts.append("pip install -e .")
    parts.append("pytest tests/")
    parts.append("```")
    parts.append("")
    parts.append("## Verify with Forge")
    parts.append("")
    parts.append("Every absorbed package ships with a re-runnable verification gate:")
    parts.append("")
    parts.append("```bash")
    parts.append(f"forge wire src/{package}              # zero upward-import violations")
    parts.append(f"forge certify . --package {package}    # 0–100 quality score")
    parts.append("```")
    parts.append("")
    parts.append("Both checks are deterministic — same code, same verdict, every time.")
    parts.append("")
    parts.append("## Provenance")
    parts.append("")
    parts.append(
        "This package was generated by `forge transmute auto`, the same "
        "pipeline that absorbs spaghetti repositories into shippable, "
        "tier-organized Python packages. The generation manifest "
        "(scout report, cherry-pick selection, assimilation receipt) "
        "lives under `.atomadic-forge/` for full replay."
    )
    parts.append("")
    parts.append("## Built with")
    parts.append("")
    parts.append(
        "- **[Atomadic Forge](https://atomadic.tech)** — the deterministic "
        "absorption pipeline. No LLM in the verdict path; every score is "
        "reproducible."
    )
    parts.append("")
    parts.append("---")
    parts.append("")
    parts.append("_Forge eats its own cooking._")
    parts.append("")
    return "\n".join(parts)


def render_gitignore() -> str:
    return (
        "__pycache__/\n"
        "*.py[cod]\n"
        "*.egg-info/\n"
        "build/\n"
        "dist/\n"
        ".venv/\n"
        "venv/\n"
        ".pytest_cache/\n"
        ".ruff_cache/\n"
        ".mypy_cache/\n"
        ".coverage\n"
        ".atomadic-forge/\n"
        ".DS_Store\n"
        ".vscode/\n"
        ".idea/\n"
    )


def render_tests_conftest(
    *,
    package: str,
    extra_src_roots: Iterable[str] = (),
) -> str:
    extra_paths = [
        str(p).replace("\\", "\\\\").replace("'", "\\'")
        for p in extra_src_roots
        if str(p).strip()
    ]
    extra_block = ""
    if extra_paths:
        extra_block = (
            "\n"
            "# Optional harvested seed roots used by Forge materialize/create.\n"
            "for extra in [\n"
            + "".join(f"    '{p}',\n" for p in extra_paths)
            + "]:\n"
            "    extra_path = Path(extra)\n"
            "    if not extra_path.is_absolute():\n"
            "        extra_path = (ROOT / extra_path).resolve()\n"
            "    extra_text = str(extra_path)\n"
            "    if extra_path.exists() and extra_text not in sys.path:\n"
            "        sys.path.insert(0, extra_text)\n"
        )
    return (
        '"""Shared fixtures for ' + package + ' tests."""\n'
        "\n"
        "from __future__ import annotations\n"
        "\n"
        "import sys\n"
        "from pathlib import Path\n"
        "\n"
        "# Make the src/ layout importable when tests run before pip install.\n"
        "ROOT = Path(__file__).resolve().parent.parent\n"
        "SRC = ROOT / 'src'\n"
        "if SRC.exists() and str(SRC) not in sys.path:\n"
        "    sys.path.insert(0, str(SRC))\n"
        + extra_block
    )


def render_tests_init() -> str:
    return '"""Tests for the package."""\n'


def render_ci_workflow(*, package: str, fail_under: int = 75) -> str:
    return (
        "name: Forge CI\n"
        "\n"
        "on:\n"
        "  push:\n"
        "  pull_request:\n"
        "\n"
        "jobs:\n"
        "  certify:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        "      - uses: actions/checkout@v4\n"
        "      - uses: actions/setup-python@v5\n"
        "        with:\n"
        "          python-version: '3.12'\n"
        "      - name: Install package and Forge\n"
        "        run: python -m pip install -e . pytest atomadic-forge\n"
        "      - name: Test\n"
        "        run: python -m pytest tests/\n"
        "      - name: Wire\n"
        f"        run: forge wire src/{package} --fail-on-violations\n"
        "      - name: Certify\n"
        f"        run: forge certify . --package {package} --fail-under {fail_under}\n"
    )


def render_changelog(*, package: str, intent: str = "") -> str:
    safe_intent = (intent or "Materialized by Atomadic Forge.").strip()
    safe_intent = safe_intent.replace("\r", " ").replace("\n", " ")
    return (
        "# Changelog\n"
        "\n"
        "All notable changes to this project are documented here. This file is\n"
        "created by Atomadic Forge so generated packages start with release\n"
        "discipline instead of acquiring it after the first production scare.\n"
        "\n"
        "## 0.1.0 - Generated\n"
        "\n"
        f"- Created `{package}` from an emergent Forge materialization pipeline.\n"
        f"- Intent: {safe_intent}\n"
        "- Added a tier-organized package skeleton, smoke tests, and a Forge CI gate.\n"
        "- Preserved the generated scan receipt under `.atomadic-forge/` for replay.\n"
    )
