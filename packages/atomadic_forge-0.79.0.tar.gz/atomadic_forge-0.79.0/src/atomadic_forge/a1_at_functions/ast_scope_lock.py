"""Tier a1 — pure AST scope locks for multi-repo swarms.

Golden Path Lane C W6 follow-on deliverable. ``audit(action='ast_scope')``
uses this module to compress a proposed multi-repo mutation into exact
function/class node envelopes before any agent edits files. AAAA-Nexus can
attest the returned lock payload through existing lineage primitives, while
the math here stays local, deterministic, and dependency-free.
"""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
from typing import Any

SCHEMA_VERSION_AST_SCOPE_V1 = "atomadic-forge.ast_scope/v1"


def _tier_for_path(path: str) -> str:
    for part in Path(path).parts:
        if part.startswith("a") and part in {
            "a0_qk_constants",
            "a1_at_functions",
            "a2_mo_composites",
            "a3_og_features",
            "a4_sy_orchestration",
        }:
            return part
    return ""


def _sha(payload: Any, *, size: int = 16) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:size]


def _module_for(rel: str) -> str:
    p = Path(rel).with_suffix("")
    parts = [part for part in p.parts if part != "src"]
    if parts and parts[-1] == "__init__":
        parts.pop()
    return ".".join(parts)


def _node_source_digest(source_lines: list[str], start: int, end: int) -> str:
    text = "\n".join(source_lines[max(0, start - 1): max(start - 1, end)])
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def _collect_python_nodes(path: Path, *, project_root: Path) -> list[dict[str, Any]]:
    rel = path.relative_to(project_root).as_posix()
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(text, filename=str(path))
    except (OSError, SyntaxError):
        return []
    lines = text.splitlines()
    module = _module_for(rel)
    out: list[dict[str, Any]] = []

    def add_node(node: ast.AST, *, name: str, kind: str) -> None:
        start = int(getattr(node, "lineno", 1))
        end = int(getattr(node, "end_lineno", start))
        qualname = f"{module}.{name}" if module else name
        out.append({
            "node_id": "ast-" + _sha({"file": rel, "qualname": qualname, "start": start, "end": end}),
            "file": rel,
            "qualname": qualname,
            "kind": kind,
            "tier": _tier_for_path(rel),
            "start_line": start,
            "end_line": end,
            "line_span": max(1, end - start + 1),
            "source_digest": _node_source_digest(lines, start, end),
        })

    for node in tree.body:
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            add_node(node, name=node.name, kind="function")
        elif isinstance(node, ast.ClassDef):
            add_node(node, name=node.name, kind="class")
            for sub in node.body:
                if isinstance(sub, ast.FunctionDef | ast.AsyncFunctionDef):
                    add_node(sub, name=f"{node.name}.{sub.name}", kind="method")
    return out


def _target_matches(node: dict[str, Any], targets: set[str]) -> bool:
    if not targets:
        return True
    qual = str(node.get("qualname", ""))
    return qual in targets or any(qual.endswith("." + t) for t in targets)


def build_ast_scope_blueprint(
    *,
    project_roots: list[Path | str],
    targets: list[str] | None = None,
    max_nodes: int = 200,
) -> dict[str, Any]:
    """Return compressed AST node scope for one or more repos.

    ``targets`` may contain full qualnames or suffixes such as
    ``AuthClient.refresh``. When omitted, the blueprint inventories up to
    ``max_nodes`` nodes per portfolio pass.
    """
    target_set = {t for t in (targets or []) if t}
    repos: list[dict[str, Any]] = []
    all_nodes: list[dict[str, Any]] = []
    raw_py_file_count = 0
    raw_line_count = 0
    for root_raw in project_roots:
        root = Path(root_raw).resolve()
        repo_nodes: list[dict[str, Any]] = []
        repo_py_file_count = 0
        repo_line_count = 0
        if root.exists():
            for py_file in sorted(root.rglob("*.py")):
                rel_parts = py_file.relative_to(root).parts
                if any(part in {"__pycache__", ".venv", "venv", ".git"} for part in rel_parts):
                    continue
                repo_py_file_count += 1
                raw_py_file_count += 1
                try:
                    lines_here = py_file.read_text(
                        encoding="utf-8",
                        errors="replace",
                    ).count("\n") + 1
                except OSError:
                    lines_here = 0
                repo_line_count += lines_here
                raw_line_count += lines_here
                for node in _collect_python_nodes(py_file, project_root=root):
                    if _target_matches(node, target_set):
                        node = {**node, "repo_root": str(root)}
                        repo_nodes.append(node)
                        all_nodes.append(node)
                    if len(all_nodes) >= max_nodes:
                        break
                if len(all_nodes) >= max_nodes:
                    break
        repos.append({
            "repo_root": str(root),
            "exists": root.exists(),
            "node_count": len(repo_nodes),
            "python_file_count": repo_py_file_count,
            "python_line_count": repo_line_count,
        })
        if len(all_nodes) >= max_nodes:
            break
    scanned_lines = sum(int(n["line_span"]) for n in all_nodes)
    compressed_tokens = max(1, len(json.dumps(all_nodes, default=str)) // 4)
    raw_token_estimate = max(compressed_tokens, raw_line_count * 4)
    savings_pct = round(100.0 * (1.0 - (compressed_tokens / raw_token_estimate)), 1)
    return {
        "schema_version": SCHEMA_VERSION_AST_SCOPE_V1,
        "project_roots": [str(Path(p).resolve()) for p in project_roots],
        "targets": sorted(target_set),
        "repos": repos,
        "node_count": len(all_nodes),
        "nodes": all_nodes,
        "compressed_context": {
            "ast_lines_retained": scanned_lines,
            "raw_python_files": raw_py_file_count,
            "raw_python_lines": raw_line_count,
            "compressed_tokens_estimate": compressed_tokens,
            "raw_tokens_estimate": raw_token_estimate,
            "token_savings_pct": savings_pct,
        },
    }


def mint_ast_locks(
    blueprint: dict[str, Any],
    *,
    agent_ids: list[str] | None = None,
    ttl_secs: int = 3600,
) -> dict[str, Any]:
    """Mint deterministic local locks over blueprint nodes.

    These are not remote AAAA-Nexus tokens. They are scope payloads suitable
    for Nexus ``lineage_record`` attestation or ``authorize_action`` resource
    checks with today's live Nexus surface.
    """
    agents = agent_ids or ["agent-0"]
    locks: list[dict[str, Any]] = []
    nodes = list(blueprint.get("nodes") or [])
    for idx, node in enumerate(nodes):
        agent_id = agents[idx % len(agents)]
        resource = (
            f"{node.get('repo_root')}::{node.get('file')}:"
            f"{node.get('start_line')}-{node.get('end_line')}::{node.get('qualname')}"
        )
        payload = {
            "agent_id": agent_id,
            "node_id": node.get("node_id"),
            "resource": resource,
            "ttl_secs": ttl_secs,
            "source_digest": node.get("source_digest"),
        }
        locks.append({
            "lock_id": "lock-" + _sha(payload, size=20),
            **payload,
            "allowed_file": node.get("file"),
            "allowed_line_range": [node.get("start_line"), node.get("end_line")],
            "tier": node.get("tier"),
            "nexus_attestable": True,
            "nexus_live_op": "lineage_record",
        })
    return {
        "schema_version": "atomadic-forge.ast_locks/v1",
        "blueprint_hash": _sha(blueprint, size=20),
        "lock_count": len(locks),
        "locks": locks,
        "ttl_secs": ttl_secs,
    }


def ast_scope_plan(
    *,
    project_roots: list[Path | str],
    targets: list[str] | None = None,
    agent_ids: list[str] | None = None,
    ttl_secs: int = 3600,
    max_nodes: int = 200,
) -> dict[str, Any]:
    """Return blueprint + locks in one MCP-friendly envelope."""
    blueprint = build_ast_scope_blueprint(
        project_roots=project_roots,
        targets=targets,
        max_nodes=max_nodes,
    )
    locks = mint_ast_locks(blueprint, agent_ids=agent_ids, ttl_secs=ttl_secs)
    return {
        "schema_version": "atomadic-forge.ast_scope_plan/v1",
        "blueprint": blueprint,
        "locks": locks,
        "verdict": "PASS" if locks["lock_count"] else "REFINE",
        "summary": (
            f"{blueprint['node_count']} AST node(s), "
            f"{locks['lock_count']} lock(s), "
            f"{blueprint['compressed_context']['token_savings_pct']}% estimated token savings"
        ),
    }


__all__ = (
    "SCHEMA_VERSION_AST_SCOPE_V1",
    "ast_scope_plan",
    "build_ast_scope_blueprint",
    "mint_ast_locks",
)
