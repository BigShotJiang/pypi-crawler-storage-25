"""Tier a1 — pure stub-body detector.

When an LLM emits a file with ``pass``, ``raise NotImplementedError``, or
a ``# TODO`` / ``# Implement me!`` placeholder, the file *looks* like a
real symbol but won't run.  We must catch this so the certify score can't
be gamed by emitting empty shells.

The detector inspects function/class bodies via AST; placeholder comments
are matched via Python tokenization so docstrings and prompt text are not
mistaken for code stubs.  Returns one record per stub-shaped symbol with
the file path, qualname, and the specific stub kind detected.
"""

from __future__ import annotations

import ast
import io
import re
import tokenize
from collections.abc import Iterable
from pathlib import Path
from typing import Literal, TypedDict

StubKind = Literal["pass_only", "not_implemented", "comment_only",
                   "todo_marker"]


class StubFinding(TypedDict):
    file: str            # repo-relative
    qualname: str
    lineno: int
    kind: StubKind
    excerpt: str         # one line, for prompt feedback


_TODO_RE = re.compile(
    r"#\s*(TODO|FIXME|XXX|HACK|implement\s+me|implement\s+this|"
    r"add\s+actual|fill\s+this)\b",
    re.IGNORECASE,
)


def _is_abstract_method(fn: ast.AST) -> bool:
    """True when fn carries an abstractmethod-family decorator.

    Recognizes ``@abstractmethod``, ``@abc.abstractmethod``,
    ``@abstractclassmethod``, ``@abstractstaticmethod``, and
    ``@abstractproperty`` (and the ``abc.``-qualified variants).
    Abstract methods are *contracts*, not stubs — their bodies are
    placeholders by design and must not be flagged.
    """
    if not isinstance(fn, ast.FunctionDef | ast.AsyncFunctionDef):
        return False
    for deco in fn.decorator_list:
        target = deco.func if isinstance(deco, ast.Call) else deco
        name: str | None = None
        if isinstance(target, ast.Name):
            name = target.id
        elif isinstance(target, ast.Attribute):
            name = target.attr
        if name and name.startswith("abstract"):
            return True
    return False


def _function_body_is_pass_only(fn: ast.AST) -> bool:
    if not isinstance(fn, ast.FunctionDef | ast.AsyncFunctionDef):
        return False
    body = list(fn.body)
    # Strip docstring.
    if (body and isinstance(body[0], ast.Expr)
            and isinstance(body[0].value, ast.Constant)
            and isinstance(body[0].value.value, str)):
        body = body[1:]
    if not body:
        return True
    if len(body) == 1 and isinstance(body[0], ast.Pass):
        return True
    return False


def _function_body_raises_not_implemented(fn: ast.AST) -> bool:
    if not isinstance(fn, ast.FunctionDef | ast.AsyncFunctionDef):
        return False
    for node in ast.walk(fn):
        if isinstance(node, ast.Raise) and node.exc is not None:
            target = node.exc
            if isinstance(target, ast.Call):
                target = target.func
            if isinstance(target, ast.Name) and target.id == "NotImplementedError":
                return True
            if isinstance(target, ast.Attribute) and target.attr == "NotImplementedError":
                return True
    return False


def _todo_comment_lines(src: str) -> list[tuple[int, str]]:
    """Return placeholder comments only, excluding docstrings and strings."""
    out: list[tuple[int, str]] = []
    try:
        tokens = tokenize.generate_tokens(io.StringIO(src).readline)
        for tok in tokens:
            if tok.type == tokenize.COMMENT and _TODO_RE.search(tok.string):
                out.append((tok.start[0], tok.line.rstrip()))
    except tokenize.TokenError:
        return []
    return out


def detect_stubs_in_file(path: Path, *, repo_root: Path | None = None
                         ) -> list[StubFinding]:
    """Return a finding per stub-shaped function/class in ``path``.

    Only reports public callables (no leading underscore) so we don't flag
    private helpers that legitimately ``pass``.
    """
    try:
        src = path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(src, filename=str(path))
    except (SyntaxError, OSError):
        return []
    rel = (path.relative_to(repo_root).as_posix()
            if repo_root else path.as_posix())
    src_lines = src.splitlines()
    out: list[StubFinding] = []

    todo_lines = _todo_comment_lines(src)

    def add(qualname: str, lineno: int, kind: StubKind, excerpt: str) -> None:
        out.append(StubFinding(file=rel, qualname=qualname, lineno=lineno,
                                kind=kind, excerpt=excerpt[:120]))

    # Recognized "intentionally empty" parent classes from the stdlib /
    # well-known libraries. NullHandler.handle/emit are defined to be
    # no-ops by the logging contract; flagging them as stubs is wrong.
    # Closes GAP-009.
    _ALWAYS_EMPTY_CLASSES = {"NullHandler"}

    def _is_visitor_class(cls: ast.ClassDef) -> bool:
        """A class whose base name contains Visitor/Walker is by convention
        an AST/IR walker. Its ``visit_X`` / ``walk_X`` methods commonly
        ``pass`` for node types it doesn't care about — that's the
        pattern, not a stub. Closes GAP-013.
        """
        for base in cls.bases:
            target = base.attr if isinstance(base, ast.Attribute) else None
            if isinstance(base, ast.Name):
                target = base.id
            if target and ("Visitor" in target or "Walker" in target
                            or "NodeVisitor" in target):
                return True
        # The class itself may name-signal the pattern.
        return ("Visitor" in cls.name or "Walker" in cls.name)

    def _is_visitor_method(name: str) -> bool:
        return (name.startswith("visit_") or name.startswith("walk_")
                or name.startswith("process_"))

    def visit(node: ast.AST, prefix: str = "", in_private_class: bool = False,
               in_always_empty_class: bool = False,
               in_visitor_class: bool = False) -> None:
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            if node.name.startswith("_") and node.name != "__init__":
                return
            if in_private_class:
                # Methods on a private class (e.g. _MockProvider.load) are part
                # of the private API surface — not stubs the LLM forgot to
                # implement. Closes GAP-005.
                return
            if in_always_empty_class:
                return
            if (in_visitor_class and _is_visitor_method(node.name)
                    and _function_body_is_pass_only(node)):
                # Visitor base class methods that pass for ignored node
                # types are the documented pattern, not stubs. GAP-013.
                return
            if _is_abstract_method(node):
                return
            qual = f"{prefix}{node.name}" if prefix else node.name
            line = src_lines[node.lineno - 1] if 0 < node.lineno <= len(src_lines) else ""
            if _function_body_is_pass_only(node):
                add(qual, node.lineno, "pass_only", line)
            elif _function_body_raises_not_implemented(node):
                add(qual, node.lineno, "not_implemented", line)
            return
        if isinstance(node, ast.ClassDef):
            child_in_private = in_private_class or node.name.startswith("_")
            child_always_empty = (in_always_empty_class
                                    or node.name in _ALWAYS_EMPTY_CLASSES)
            child_in_visitor = in_visitor_class or _is_visitor_class(node)
            for sub in node.body:
                visit(sub, prefix=f"{node.name}.",
                      in_private_class=child_in_private,
                      in_always_empty_class=child_always_empty,
                      in_visitor_class=child_in_visitor)
            return

    for node in tree.body:
        visit(node)

    # File-level TODO/FIXME markers — surface even when the body otherwise looks fine.
    for ln, line in todo_lines:
        if not any(f["lineno"] == ln for f in out):
            kind: StubKind = "todo_marker"
            add(f"<line {ln}>", ln, kind, line.strip())

    return out


def detect_stubs(*, package_root: Path,
                 only_emitted: Iterable[Path] | None = None
                 ) -> list[StubFinding]:
    """Walk a tier package (or a specific list of files) and aggregate stubs."""
    package_root = Path(package_root)
    files: Iterable[Path]
    if only_emitted is not None:
        files = [Path(p) for p in only_emitted]
    else:
        files = package_root.rglob("*.py")
    out: list[StubFinding] = []
    for f in files:
        if not f.exists() or "__pycache__" in f.parts or f.name == "__init__.py":
            continue
        out.extend(detect_stubs_in_file(f, repo_root=package_root))
    return out


def stub_penalty(findings: list[StubFinding]) -> int:
    """Cap-aware penalty for the certify score, max 40.

    Penalty per unique finding depends on severity:
      * ``pass_only`` / ``not_implemented`` (real missing implementation):
        8 points each.
      * ``todo_marker`` (a ``# TODO`` / ``# FIXME`` comment in otherwise
        complete code): 1 point each, capped at 5 total. Closes GAP-010 —
        TODO comments are informational, not missing-code stubs, and
        previously dominated the cap (e.g. python-patch's 957 markers
        forced score → 60 even though every method had a real body).

    Findings are de-duplicated by ``qualname`` because materialization
    can copy a single underlying parent class into N subclass files;
    that's one quality issue, not N. Closes GAP-006.
    """
    unique_quals_real: set[str] = set()
    unique_quals_todo: set[str] = set()
    for finding in findings:
        qual = finding.get("qualname") or ""
        kind = finding.get("kind") or ""
        # ``<line N>`` qualnames are file-local; key by file to keep
        # them distinct, even though they all dedupe within a file.
        if qual.startswith("<line"):
            key = f"{finding.get('file', '')}:{qual}"
        else:
            key = qual
        if kind == "todo_marker":
            unique_quals_todo.add(key)
        else:
            unique_quals_real.add(key)

    real_penalty = 8 * len(unique_quals_real)
    todo_penalty = min(5, len(unique_quals_todo))
    return min(40, real_penalty + todo_penalty)
