"""Tier a1 — pure surface parsers for Rust, Go, Swift, Kotlin.

Lifts native-language ingest from the file-level fallback in
:mod:`scout_walk` to the same shape :mod:`js_parser` provides for
JS/TS: a uniform :class:`NativeSurface` dataclass that carries every
public symbol (functions, structs/classes, methods, constants), its
imports, and effect signals.

Forge isn't a compiler.  We use deterministic regex passes — comments
and string literals are stripped first so syntactic noise doesn't
register as a real symbol.  Each parser is forgiving: malformed source
returns an empty surface rather than raising.

Why this matters: cherry-pick, emergent compose, and certify all walk
``scout.symbols[]``.  When that list contains only ``module``-kind
records, polyglot users can't pick or compose individual functions —
which is the whole reason JS and Python have first-class support.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

# ── shared helpers ───────────────────────────────────────────────────

_BLOCK_COMMENT_RE = re.compile(r"/\*.*?\*/", re.DOTALL)
_LINE_COMMENT_RE = re.compile(r"//[^\n]*")
_STRING_RE = re.compile(
    r'"(?:\\.|[^"\\])*"' r"|'(?:\\.|[^'\\])*'", re.DOTALL,
)


def _strip_comments_and_strings(src: str) -> str:
    """Remove ``//``+``/* */`` comments and string literal contents.

    Keeps the surrounding quotes so token positions don't shift.
    Used by every native-language parser so a fake ``"fn foo"`` inside
    a string literal never registers.
    """
    no_block = _BLOCK_COMMENT_RE.sub(lambda _: "", src)
    no_line = _LINE_COMMENT_RE.sub("", no_block)
    return _STRING_RE.sub('""', no_line)


def _statement_count(cleaned: str) -> int:
    """Crude complexity proxy: non-blank lines after comment stripping."""
    return sum(1 for line in cleaned.splitlines() if line.strip())


# ── surface contract ────────────────────────────────────────────────


@dataclass
class NativeSurface:
    """Uniform surface shape for Rust, Go, Swift, Kotlin source.

    Mirrors :class:`js_parser.JsSurface` so downstream consumers
    (scout_walk, cherry, emergent) can treat every language identically.
    """

    language: str = ""
    imports: list[str] = field(default_factory=list)
    pub_functions: list[str] = field(default_factory=list)
    pub_classes: list[str] = field(default_factory=list)
    pub_methods: list[tuple[str, str]] = field(default_factory=list)  # (parent, name)
    pub_constants: list[str] = field(default_factory=list)
    has_state: bool = False
    has_io: bool = False
    has_main_entry: bool = False
    statement_count: int = 0

    @property
    def all_exports(self) -> list[str]:
        seen: list[str] = []
        for name in (
            self.pub_functions
            + self.pub_classes
            + self.pub_constants
            + [f"{p}.{m}" for p, m in self.pub_methods]
        ):
            if name and name not in seen:
                seen.append(name)
        return seen


# ── Rust ─────────────────────────────────────────────────────────────

_RUST_FN_RE = re.compile(
    r"\bpub\s+(?:async\s+|unsafe\s+|const\s+|extern\s+(?:\"\s*\"\s+)?)*"
    r"fn\s+([A-Za-z_][\w]*)\s*[(<]"
)
_RUST_STRUCT_RE = re.compile(r"\bpub\s+struct\s+([A-Za-z_][\w]*)")
_RUST_ENUM_RE = re.compile(r"\bpub\s+enum\s+([A-Za-z_][\w]*)")
_RUST_TRAIT_RE = re.compile(r"\bpub\s+trait\s+([A-Za-z_][\w]*)")
_RUST_TYPE_RE = re.compile(r"\bpub\s+type\s+([A-Za-z_][\w]*)")
_RUST_CONST_RE = re.compile(r"\bpub\s+(?:const|static)\s+([A-Z_][A-Z0-9_]*)\s*[:=]")
_RUST_IMPL_HEADER_RE = re.compile(
    r"\bimpl(?:<[^>]+>)?\s+(?:[A-Za-z_:][\w<>:'\s,]*?\s+for\s+)?([A-Za-z_][\w<>:]*)\s*(?:where\s+[^{]*)?\{",
)
_RUST_IMPL_FN_RE = re.compile(
    r"\bpub\s+(?:async\s+|unsafe\s+|const\s+)*fn\s+([A-Za-z_][\w]*)\s*[(<]",
)
_RUST_USE_FOR_IO = re.compile(
    r"\buse\s+(?:std::(?:io|fs|net|process|env|thread)|tokio::|reqwest::|hyper::|sqlx::|rusqlite::)",
)
_RUST_FN_MAIN_RE = re.compile(r"\bfn\s+main\s*\(")
_RUST_MUT_STRUCT_FIELD_RE = re.compile(r"\bpub\s+[A-Za-z_][\w]*\s*:\s*(?:Cell|RefCell|Mutex|RwLock|Vec|HashMap|HashSet)")


def _rust_balance_braces(src: str, open_idx: int) -> int:
    """Return the closing brace index for ``src[open_idx] == '{'``, or -1."""
    if open_idx >= len(src) or src[open_idx] != "{":
        return -1
    depth = 0
    i = open_idx
    n = len(src)
    while i < n:
        c = src[i]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def parse_rust_surface(src: str) -> NativeSurface:
    """Return the public surface of a Rust source file."""
    cleaned = _strip_comments_and_strings(src)
    surface = NativeSurface(language="rust")
    surface.statement_count = _statement_count(cleaned)

    surface.pub_functions = sorted({m.group(1) for m in _RUST_FN_RE.finditer(cleaned)})
    classes: set[str] = set()
    classes.update(m.group(1) for m in _RUST_STRUCT_RE.finditer(cleaned))
    classes.update(m.group(1) for m in _RUST_ENUM_RE.finditer(cleaned))
    classes.update(m.group(1) for m in _RUST_TRAIT_RE.finditer(cleaned))
    classes.update(m.group(1) for m in _RUST_TYPE_RE.finditer(cleaned))
    surface.pub_classes = sorted(classes)
    surface.pub_constants = sorted(
        {m.group(1) for m in _RUST_CONST_RE.finditer(cleaned)}
    )

    methods: list[tuple[str, str]] = []
    seen_methods: set[tuple[str, str]] = set()
    for impl_m in _RUST_IMPL_HEADER_RE.finditer(cleaned):
        parent = impl_m.group(1).split("<", 1)[0].split("::")[-1]
        open_idx = impl_m.end() - 1  # the '{'
        close_idx = _rust_balance_braces(cleaned, open_idx)
        if close_idx < 0:
            continue
        block = cleaned[open_idx + 1: close_idx]
        for fn in _RUST_IMPL_FN_RE.finditer(block):
            mname = fn.group(1)
            key = (parent, mname)
            if key not in seen_methods:
                seen_methods.add(key)
                methods.append(key)
    surface.pub_methods = methods

    surface.has_state = bool(classes) or bool(_RUST_MUT_STRUCT_FIELD_RE.search(cleaned))
    surface.has_io = bool(_RUST_USE_FOR_IO.search(cleaned))
    surface.has_main_entry = bool(_RUST_FN_MAIN_RE.search(cleaned))
    return surface


# ── Go ────────────────────────────────────────────────────────────────

# In Go, exported identifiers start with an uppercase letter.
_GO_FUNC_RE = re.compile(
    # Accept generic type-param brackets: ``func Identity[T any](x T)``.
    r"^\s*func\s+([A-Z][\w]*)\s*[\[(]",
    re.MULTILINE,
)
_GO_METHOD_RE = re.compile(
    r"^\s*func\s+\(\s*\w+\s+\*?([A-Z][\w]*)\s*\)\s+([A-Z][\w]*)\s*[\[(]",
    re.MULTILINE,
)
_GO_STRUCT_RE = re.compile(r"\btype\s+([A-Z][\w]*)\s+struct\b")
_GO_INTERFACE_RE = re.compile(r"\btype\s+([A-Z][\w]*)\s+interface\b")
_GO_TYPE_ALIAS_RE = re.compile(r"\btype\s+([A-Z][\w]*)\s+(?!struct|interface)\w")
_GO_CONST_RE = re.compile(r"^\s*const\s+([A-Z][\w]*)\s*=", re.MULTILINE)
_GO_VAR_RE = re.compile(r"^\s*var\s+([A-Z][\w]*)\s*[=\s]", re.MULTILINE)
_GO_IO_IMPORT_RE = re.compile(
    r'"\s*(?:os|io|bufio|net(?:/http)?|database/sql|os/exec|fmt\.Print|log)\s*"',
)
_GO_MAIN_RE = re.compile(r"^\s*func\s+main\s*\(", re.MULTILINE)


def parse_go_surface(src: str) -> NativeSurface:
    """Return the public (exported) surface of a Go source file."""
    cleaned = _strip_comments_and_strings(src)
    # I/O detection runs on the raw source because Go imports are
    # quoted strings — masking string literals would erase the signal.
    raw_for_io = _LINE_COMMENT_RE.sub("", _BLOCK_COMMENT_RE.sub("", src))
    surface = NativeSurface(language="go")
    surface.statement_count = _statement_count(cleaned)

    method_pairs = [(m.group(1), m.group(2)) for m in _GO_METHOD_RE.finditer(cleaned)]
    method_owner_set = {p for p, _ in method_pairs}
    method_name_set = {n for _, n in method_pairs}

    # Top-level functions: exclude method receivers (those have a '(' before name).
    fns = {m.group(1) for m in _GO_FUNC_RE.finditer(cleaned)} - method_name_set
    surface.pub_functions = sorted(fns)
    surface.pub_methods = method_pairs

    classes: set[str] = set()
    classes.update(m.group(1) for m in _GO_STRUCT_RE.finditer(cleaned))
    classes.update(m.group(1) for m in _GO_INTERFACE_RE.finditer(cleaned))
    classes.update(m.group(1) for m in _GO_TYPE_ALIAS_RE.finditer(cleaned))
    surface.pub_classes = sorted(classes | method_owner_set)

    consts: set[str] = set()
    consts.update(m.group(1) for m in _GO_CONST_RE.finditer(cleaned))
    consts.update(m.group(1) for m in _GO_VAR_RE.finditer(cleaned))
    surface.pub_constants = sorted(consts)

    surface.has_state = bool(classes)
    surface.has_io = bool(_GO_IO_IMPORT_RE.search(raw_for_io))
    surface.has_main_entry = bool(_GO_MAIN_RE.search(cleaned))
    return surface


# ── Swift ────────────────────────────────────────────────────────────

_SWIFT_FUNC_RE = re.compile(
    r"^\s*(?:public\s+|open\s+|internal\s+|fileprivate\s+|private\s+)?"
    r"(?:override\s+|static\s+|class\s+|final\s+|mutating\s+|nonmutating\s+|async\s+|throws\s+|@\w+\s+)*"
    r"func\s+([A-Za-z_][\w]*)\s*[<(]",
    re.MULTILINE,
)
_SWIFT_TYPE_RE = re.compile(
    r"^\s*(?:public\s+|open\s+|internal\s+|fileprivate\s+|private\s+|final\s+)*"
    r"(?:class|struct|enum|protocol|actor)\s+([A-Za-z_][\w]*)",
    re.MULTILINE,
)
_SWIFT_LET_VAR_RE = re.compile(
    r"^\s*(?:public\s+|open\s+|static\s+)*"
    r"(?:let|var)\s+([A-Z_][\w]*)\s*[:=]",
    re.MULTILINE,
)
_SWIFT_IO_IMPORT_RE = re.compile(
    r"\bimport\s+(?:Foundation|UIKit|AppKit|Combine|Network|CoreData|"
    r"SwiftData|FileHandle|URLSession|SQLite3)\b",
)
_SWIFT_MAIN_RE = re.compile(r"@main\b|@UIApplicationMain\b|@NSApplicationMain\b")


def parse_swift_surface(src: str) -> NativeSurface:
    """Return the public surface of a Swift source file.

    Swift's default access is "internal" — visible inside the same
    module — so we treat every top-level non-private declaration as
    part of the surface unless explicitly marked ``private`` /
    ``fileprivate``.  Methods inside types are recovered by an
    additional pass that scans inside type bodies.
    """
    cleaned = _strip_comments_and_strings(src)
    surface = NativeSurface(language="swift")
    surface.statement_count = _statement_count(cleaned)

    # All `func` matches — top-level + methods.  Distinguish by the
    # nesting level (top-level funcs sit at column 0..whitespace; method
    # funcs sit indented).  Cheap heuristic: look at the leading
    # whitespace of each match's line.
    fns: list[str] = []
    methods: list[tuple[str, str]] = []
    type_names = [m.group(1) for m in _SWIFT_TYPE_RE.finditer(cleaned)]
    surface.pub_classes = sorted(set(type_names))

    # Build a map line_no → enclosing type using a stack scan that tracks
    # ``class/struct/enum/protocol/actor X { ... }`` blocks.
    enclosing = _swift_enclosing_types(cleaned)
    for m in _SWIFT_FUNC_RE.finditer(cleaned):
        name = m.group(1)
        line_no = cleaned.count("\n", 0, m.start())
        owner = enclosing.get(line_no, "")
        if owner:
            methods.append((owner, name))
        else:
            fns.append(name)
    surface.pub_functions = sorted(set(fns))
    surface.pub_methods = methods

    surface.pub_constants = sorted(
        {m.group(1) for m in _SWIFT_LET_VAR_RE.finditer(cleaned)}
    )
    surface.has_state = bool(type_names)
    surface.has_io = bool(_SWIFT_IO_IMPORT_RE.search(cleaned))
    surface.has_main_entry = bool(_SWIFT_MAIN_RE.search(cleaned))
    return surface


def _swift_enclosing_types(cleaned: str) -> dict[int, str]:
    """Return ``{line_no: enclosing_type_name}`` for each line in a Swift source.

    Lines outside any type body map to ``""``.  Cheap brace-depth scan;
    no AST, no type-system understanding — sufficient to label which
    ``func`` definitions are methods vs top-level.
    """
    result: dict[int, str] = {}
    type_stack: list[tuple[str, int]] = []  # (name, brace_depth_at_open)
    depth = 0
    line_no = 0
    i = 0
    n = len(cleaned)
    type_re = re.compile(
        r"\b(?:class|struct|enum|protocol|actor|extension)\s+([A-Za-z_][\w]*)"
    )
    while i < n:
        c = cleaned[i]
        if c == "\n":
            result[line_no] = type_stack[-1][0] if type_stack else ""
            line_no += 1
        elif c == "{":
            # Look back to see if this brace opens a type body.
            preceding = cleaned[max(0, i - 200): i]
            tm = list(type_re.finditer(preceding))
            if tm and "{" not in preceding[tm[-1].end():]:
                type_stack.append((tm[-1].group(1), depth))
            depth += 1
        elif c == "}":
            depth -= 1
            if type_stack and type_stack[-1][1] == depth:
                type_stack.pop()
        i += 1
    result[line_no] = type_stack[-1][0] if type_stack else ""
    return result


# ── Kotlin ───────────────────────────────────────────────────────────

_KOTLIN_FUN_RE = re.compile(
    r"^\s*(?:public\s+|internal\s+|protected\s+|private\s+)?"
    r"(?:override\s+|open\s+|abstract\s+|final\s+|inline\s+|suspend\s+|@\w+\s+)*"
    r"fun\s+(?:<[^>]+>\s+)?(?:[A-Za-z_][\w]*\.)?([A-Za-z_][\w]*)\s*\(",
    re.MULTILINE,
)
_KOTLIN_CLASS_RE = re.compile(
    r"^\s*(?:public\s+|internal\s+|abstract\s+|open\s+|final\s+|sealed\s+|data\s+|enum\s+|@\w+\s+)*"
    r"class\s+([A-Za-z_][\w]*)",
    re.MULTILINE,
)
_KOTLIN_INTERFACE_RE = re.compile(
    r"^\s*(?:public\s+|internal\s+|abstract\s+|@\w+\s+)*"
    r"interface\s+([A-Za-z_][\w]*)",
    re.MULTILINE,
)
_KOTLIN_OBJECT_RE = re.compile(
    r"^\s*(?:public\s+|internal\s+|@\w+\s+)*object\s+([A-Za-z_][\w]*)",
    re.MULTILINE,
)
_KOTLIN_VAL_RE = re.compile(
    # Not anchored to line start: Kotlin allows ``object Foo { const val X = 1 }``
    # on a single line, so the const-val token sits mid-line.  ``\b`` is
    # enough since strings are masked before parsing.
    r"\b(?:public\s+|internal\s+|private\s+|protected\s+|const\s+)*(?:val|var)"
    r"\s+([A-Z_][\w]*)\s*[:=]",
)
_KOTLIN_IO_IMPORT_RE = re.compile(
    r"\bimport\s+(?:java\.io\.|java\.net\.|java\.nio\.|kotlinx\.coroutines\.|"
    r"okhttp3\.|retrofit2\.|androidx\.room\.|kotlin\.io\.|kotlin\.system\.)",
)
_KOTLIN_MAIN_RE = re.compile(
    r"^\s*(?:public\s+|internal\s+)?fun\s+main\s*\(", re.MULTILINE,
)


def parse_kotlin_surface(src: str) -> NativeSurface:
    """Return the public surface of a Kotlin source file.

    Kotlin's default access is ``public``; we treat every top-level
    declaration that isn't explicitly ``private`` / ``protected`` /
    ``internal``-only as part of the surface.
    """
    cleaned = _strip_comments_and_strings(src)
    surface = NativeSurface(language="kotlin")
    surface.statement_count = _statement_count(cleaned)

    classes = {m.group(1) for m in _KOTLIN_CLASS_RE.finditer(cleaned)}
    interfaces = {m.group(1) for m in _KOTLIN_INTERFACE_RE.finditer(cleaned)}
    objects = {m.group(1) for m in _KOTLIN_OBJECT_RE.finditer(cleaned)}
    surface.pub_classes = sorted(classes | interfaces | objects)

    # Kotlin doesn't enforce upper-camel-only for top-level vs nested fun;
    # we treat everything captured as "function" surface for Forge tier
    # purposes.  When body assignment matters, downstream ASTs can refine.
    surface.pub_functions = sorted({m.group(1) for m in _KOTLIN_FUN_RE.finditer(cleaned)})
    surface.pub_constants = sorted({m.group(1) for m in _KOTLIN_VAL_RE.finditer(cleaned)})
    surface.has_state = bool(classes | objects)
    surface.has_io = bool(_KOTLIN_IO_IMPORT_RE.search(cleaned))
    surface.has_main_entry = bool(_KOTLIN_MAIN_RE.search(cleaned))
    return surface


# ── language router ─────────────────────────────────────────────────


_PARSERS = {
    "rust": parse_rust_surface,
    "go": parse_go_surface,
    "swift": parse_swift_surface,
    "kotlin": parse_kotlin_surface,
}


def parse_surface_for_language(language: str, src: str) -> NativeSurface | None:
    """Dispatch to the right surface parser by canonical language label.

    Returns ``None`` for languages this module doesn't handle (Python
    has its own AST harvester, JS/TS uses :mod:`js_parser`).
    """
    parser = _PARSERS.get(language)
    return parser(src) if parser else None
