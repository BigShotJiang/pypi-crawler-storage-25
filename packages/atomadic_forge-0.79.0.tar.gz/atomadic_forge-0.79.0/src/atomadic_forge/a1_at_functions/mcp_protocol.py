"""Tier a1 — pure MCP JSON-RPC dispatch for `forge mcp serve`.

Golden Path Lane C W4 deliverable. The dispatcher is a pure function
``dispatch_request(req, ctx) -> response`` — no I/O, no global state.
The transport (stdio loop) lives in a3 ``mcp_server.py``.

Implements the slice of the MCP spec that coding agents actually
consume on first connect:

  * ``initialize``      — capability handshake; returns serverInfo +
                          supported protocol version + tool/resource
                          capability flags.
  * ``ping``            — liveness check (returns ``{}``).
  * ``tools/list``      — names + JSON Schemas for the 8 Forge tools.
  * ``tools/call``      — runs one of the named tools and returns
                          the result wrapped in MCP's ``content`` shape.
  * ``resources/list``  — Forge documentation + lineage URIs.
  * ``resources/read``  — read a Forge resource (docs, lineage, schema).

Tools (v0.47.0 — 8 tools, 64 actions + create):
  welcome  — first-call handshake (no action param)
  explore  — codebase analysis + discovery (action=recon|explain|call_graph|call_graph_summary|smell_scan|churn|lineage|harvest|synergy|scan|swarm)
  audit    — quality gates + change safety (action=certify|wire|enforce|validate|guard|composite|gate|health|check|score|tests|cna|rollback|diff|ast_scope)
  plan     — orient + plan + execute (action=context|compose|policy|recipes|generate|apply|locate|commit|iterate|resume|evolve|evolve_step|auto|cherry|finalize|scaffold)
  hive     — multi-agent coordination (action=register|list|deactivate|observe|propose|vote|needs_vote|result|recap|handoff_create|handoff_list|enhance_propose|enhance_list)
  wisdom   — institutional memory DB (action=record|query|list|recall|promote)
  nexus    — AAAA-Nexus auth primitives (op=identity_verify|federation_mint|authorize_action|sys_trust_gate|contract_verify|lineage_record|ratchet_register)
  create   — intent + seed repos -> shippable pip package (Phase 1 pipeline)

Resources:
  forge://docs/receipt           — docs/RECEIPT.md
  forge://docs/formalization     — docs/FORMALIZATION.md (citations)
  forge://lineage/chain          — local lineage chain JSONL
  forge://schema/receipt         — Receipt v1 JSON schema reference
  forge://summary/blockers       — one-call "what's blocking?" summary

The dispatcher returns proper JSON-RPC 2.0 responses, including
``-32601`` (method not found) and ``-32602`` (invalid params) error
codes when it can't honor a request. Pure function — exceptions raised
by tool handlers are caught and converted to ``-32000`` (server error)
responses; callers never see a Python traceback.
"""
from __future__ import annotations

import dataclasses
import json
import sys
from collections.abc import Callable
from pathlib import Path
from typing import Any

from .. import __version__
from ..a0_qk_constants.nexus_constants import NEXUS_PREMIUM_HINT
from ..a0_qk_constants.receipt_schema import SCHEMA_VERSION_V1
from .agent_context_pack import emit_context_pack
from .agent_memory import what_failed_last_time, why_did_this_change
from .agent_summary import summarize_blockers
from .ast_scope_lock import ast_scope_plan as _ast_scope_plan
from .certify_checks import certify
from .lineage_chain import canonical_receipt_hash, verify_chain_link
from .lineage_reader import list_artifacts, read_lineage
from .manifest_diff import diff_manifests as _diff_manifests
from .patch_scorer import score_patch as _score_patch
from .plan_adapter import adapt_plan as _adapt_plan
from .policy_loader import load_policy as _load_policy
from .preflight_change import preflight_change as _preflight_change
from .receipt_emitter import build_receipt
from .recipes import all_recipes, get_recipe, list_recipes
from .repo_explainer import explain_repo as _explain_repo
from .scout_walk import harvest_repo
from .sidecar_parser import find_sidecar_for as _find_sidecar_for
from .sidecar_parser import parse_sidecar_file as _parse_sidecar_file
from .sidecar_validator import validate_sidecar as _validate_sidecar
from .steersman_pack import (
    build_steersman_pack as _build_steersman_pack,
)
from .steersman_pack import (
    finalize_steersman_pack as _finalize_steersman_pack,
)
from .test_selector import select_tests as _select_tests
from .tool_composer import compose_tools as _compose_tools
from .wire_check import scan_violations

# Module-level TOML reader (mirrors policy_loader.py pattern) — used by
# _tool_wire to read [tool.forge.wire] without triggering a dynamic-import
# warning from its own wire scan.
if sys.version_info >= (3, 11):
    import tomllib as _toml_lib  # type: ignore[import-not-found]
else:
    try:
        import tomli as _toml_lib  # type: ignore[import-not-found]
    except ImportError:
        _toml_lib = None  # type: ignore[assignment]
from .worktree_status import worktree_status as _worktree_status

PROTOCOL_VERSION = "2024-11-05"   # MCP spec rev the server advertises
SERVER_NAME = "atomadic-forge"


def _json_default(obj: Any) -> Any:
    """Explicit ``json.dumps`` default that round-trips structured types
    instead of coercing them to opaque ``repr`` strings.

    Forge ships a pure-MCP wire (``mcp_server.py:_write`` and the
    ``_serialize_result`` helper below) that previously used
    ``default=str``. That worked for ``Path``/``datetime`` but silently
    corrupted ``set``/``frozenset`` (encoded as ``"{1, 2, 3}"`` instead
    of ``[1, 2, 3]``), ``bytes`` (encoded as ``"b'\\xff…'"`` instead of
    base64), and dataclasses (encoded as ``"Foo(x=5)"`` — clients lost
    field access). No tool emits these today; the explicit handler
    below is a forward-compat substrate guarantee so any future tool
    that returns structured Python types stays JSON-safe by
    construction.
    """
    if isinstance(obj, set | frozenset):
        return sorted(obj, key=repr)
    if isinstance(obj, bytes | bytearray):
        import base64
        return {"__bytes_b64__": base64.b64encode(bytes(obj)).decode("ascii")}
    if isinstance(obj, Path):
        return obj.as_posix()
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return dataclasses.asdict(obj)
    return str(obj)


_JSON_RPC_VERSION = "2.0"
_ERR_PARSE = -32700
_ERR_INVALID_REQUEST = -32600
_ERR_METHOD_NOT_FOUND = -32601
_ERR_INVALID_PARAMS = -32602
_ERR_INTERNAL = -32603
_ERR_SERVER = -32000


# --- Tool registry (pure: handlers receive a project_root path) ----------

ToolHandler = Callable[[Path, dict[str, Any]], dict[str, Any]]


def _tool_recon(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    target = Path(args.get("target", project_root)).resolve()
    verbose = bool(args.get("verbose", False))
    report = harvest_repo(target)
    if not verbose:
        report = {k: v for k, v in report.items() if k != "symbols"}
    # Mirror the CLI wisdom-recall hook (cli.py recon command, v0.13).
    # Agents calling recon via MCP should see prior lessons, same as CLI.
    report["prior_wisdom"] = _tool_wisdom_recall(target, {"project_root": str(target)})
    return report


def _tool_wire(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    src = Path(args.get("source", project_root)).resolve()
    result = scan_violations(
        src,
        suggest_repairs=bool(args.get("suggest_repairs", False)),
    )
    # Read [tool.forge.wire].allowed_dynamic_imports from pyproject.toml so
    # known-safe bootstrap patterns (e.g. _bootstrap_a3_handlers) are separated
    # from genuinely new warnings. Agents can then check new_dynamic_warnings==0
    # instead of iterating the full list every session.
    allowed: list[str] = []
    try:
        pp = (project_root / "pyproject.toml").resolve()
        if pp.exists() and _toml_lib is not None:
            data = _toml_lib.loads(pp.read_text(encoding="utf-8"))
            allowed = (
                (data.get("tool") or {})
                .get("forge", {})
                .get("wire", {})
                .get("allowed_dynamic_imports", [])
            )
    except Exception:  # noqa: BLE001 — whitelist read is best-effort
        pass
    raw_warnings: list[dict] = result.get("dynamic_import_warnings") or []
    if allowed:
        new_w = [w for w in raw_warnings
                 if not any(a in (w.get("module") or "") or a in (w.get("file") or "")
                            for a in allowed)]
        whitelisted_w = [w for w in raw_warnings if w not in new_w]
        result["dynamic_import_warnings"] = new_w
        result["whitelisted_dynamic_warnings"] = whitelisted_w
    result["new_dynamic_warnings"] = len(result.get("dynamic_import_warnings") or [])
    result["whitelisted_dynamic_warnings_count"] = len(result.get("whitelisted_dynamic_warnings") or [])
    return result


def _tool_certify(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    root = Path(args.get("project_root", project_root)).resolve()
    package = args.get("package")
    skip_tests = bool(args.get("skip_tests", False))
    cert = certify(root, project=root.name, package=package, skip_tests=skip_tests)
    if not args.get("emit_receipt"):
        return cert
    # When emit_receipt is requested, build a v1 Receipt around the
    # certify result and return both for the caller's convenience.
    wire = scan_violations(root)
    scout = harvest_repo(root)
    receipt = build_receipt(
        certify_result=cert,
        wire_report=wire,
        scout_report=scout,
        project_name=root.name,
        project_root=root,
        forge_version=__version__,
        package=package,
    )
    return {"certify": cert, "receipt": receipt}


# ── a3 lazy-bootstrap (a1↔a3 injection auto-trigger) ─────────────────
#
# The MCP protocol module is in tier a1 — the upward-only law forbids
# a static ``from ..a3_og_features import …``.  The substrate solves
# this with the ``register_*_handler`` injection pattern: a3 imports
# mcp_protocol and registers real handlers, and ``forge mcp serve``
# triggers that import on startup.  But a downstream consumer that
# imports ``mcp_protocol`` directly (a unit test, an embedded agent,
# a JSON-RPC harness) gets ``wired:false`` stubs unless they remember
# to import a3 themselves.
#
# Fix: every wrapper that delegates to a registered handler calls
# ``_bootstrap_a3_handlers()`` first.  The call is idempotent — on
# the second hit it's a single boolean check.  The actual import is
# dynamic (``importlib.import_module``) so the static import graph
# stays a3-free and ``forge wire`` doesn't flag a tier violation.

_A3_BOOTSTRAP_DONE = False


def _bootstrap_a3_handlers() -> None:
    """Import ``a3.mcp_server`` once to trigger handler registration.

    Idempotent.  Returns immediately on every call after the first.
    Safe to call from any wrapper at any time; failure (e.g. a3 not
    installed) is silent — callers fall back to the stub response
    that explains the situation.
    """
    global _A3_BOOTSTRAP_DONE
    if _A3_BOOTSTRAP_DONE:
        return
    _A3_BOOTSTRAP_DONE = True
    try:
        import importlib
        importlib.import_module("atomadic_forge.a3_og_features.mcp_server")
    except ImportError:
        # a3 isn't on the path (rare — packaging error or partial
        # install); leave handlers as their unbound stubs and let the
        # stub responses tell the caller.
        pass


def _tool_enforce_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Default enforce handler — a3 binds the real implementation at
    import time via ``register_enforce_handler``. Until a3 has loaded
    (e.g. when only a1 is imported in tests), this stub returns a
    structured 'unwired' response so callers can detect the state.
    """
    return {
        "schema_version": "atomadic-forge.enforce/v1",
        "wired": False,
        "note": (
            "forge enforce tool not yet wired — import "
            "atomadic_forge.a3_og_features.mcp_server (or any code "
            "under a3) to register the real handler."
        ),
    }


_enforce_handler: ToolHandler = _tool_enforce_unbound


def _tool_enforce(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _enforce_handler(project_root, args)


def register_enforce_handler(handler: ToolHandler) -> None:
    """Bind the real ``run_enforce``-backed handler from a3.

    Pure module-state replacement (a global within this a1 module).
    a3's mcp_server.py calls this at import time so when the CLI
    surface (a4) imports a3.mcp_server, the dispatcher's enforce
    handler is wired automatically — no upward import in a1.
    """
    global _enforce_handler
    _enforce_handler = handler


def _tool_audit_list(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    root = Path(args.get("project_root", project_root)).resolve()
    return {
        "schema_version": "atomadic-forge.audit.list/v1",
        "project": str(root),
        "artifacts": list_artifacts(root),
    }


def _tool_context_pack(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Codex 'Copilot's Copilot' #1 — first-call context pack."""
    root = Path(args.get("target", project_root)).resolve()
    focus = args.get("focus")
    intent = str(args.get("intent", ""))
    files = list(args.get("files") or args.get("target_files") or [])
    try:
        scout = harvest_repo(root)
    except (OSError, ValueError):
        scout = None
    try:
        wire = scan_violations(root)
    except (OSError, ValueError):
        wire = None
    try:
        cert = certify(root, project=root.name)
    except (OSError, RuntimeError, ValueError):
        cert = None
    return emit_context_pack(
        project_root=root,
        scout_report=scout, wire_report=wire, certify_report=cert,
        focus=str(focus) if focus is not None else None,
        intent=intent,
        files=[str(f) for f in files],
    )


def _tool_preflight_change(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Codex 'Copilot's Copilot' #2 — pre-edit guardrail."""
    root = Path(args.get("project_root", project_root)).resolve()
    intent = str(args.get("intent", ""))
    proposed = list(args.get("proposed_files") or [])
    threshold = int(args.get("scope_threshold", 8))
    if not intent:
        return {"schema_version": "atomadic-forge.preflight/v1",
                "error": "intent is required"}
    if not proposed:
        return {"schema_version": "atomadic-forge.preflight/v1",
                "error": "proposed_files must be non-empty"}
    return _preflight_change(
        intent=intent, proposed_files=proposed,
        project_root=root, scope_threshold=threshold,
    )


def _tool_ast_scope_attest_unbound(project_root: Path,
                                   args: dict[str, Any]) -> dict[str, Any]:
    plan = dict(args.get("plan") or {})
    plan["nexus"] = {
        "mirrored": False,
        "reason": (
            "ast_scope_attest handler not yet wired — import "
            "atomadic_forge.a3_og_features.mcp_server"
        ),
        "premium_hint": NEXUS_PREMIUM_HINT,
    }
    return plan


_ast_scope_attest_handler: ToolHandler = _tool_ast_scope_attest_unbound


def _tool_ast_scope(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Pure AST blueprint + lock plan for multi-repo scoped edits."""
    roots_raw = args.get("project_roots") or [args.get("project_root", project_root)]
    if isinstance(roots_raw, str):
        roots_raw = [roots_raw]
    targets_raw = args.get("targets") or []
    if isinstance(targets_raw, str):
        targets_raw = [targets_raw]
    agents_raw = args.get("agent_ids") or []
    if isinstance(agents_raw, str):
        agents_raw = [agents_raw]
    roots = [str(Path(str(root)).resolve()) for root in roots_raw]
    plan = _ast_scope_plan(
        project_roots=roots,
        targets=[str(target) for target in targets_raw],
        agent_ids=[str(agent) for agent in agents_raw],
        ttl_secs=int(args.get("ttl_secs", 3600)),
        max_nodes=int(args.get("max_nodes", 200)),
    )
    if bool(args.get("attest_nexus", False)):
        _bootstrap_a3_handlers()
        return _ast_scope_attest_handler(project_root, {**args, "plan": plan})
    plan["nexus"] = {
        "mirrored": False,
        "reason": "attest_nexus=false",
        "premium_hint": NEXUS_PREMIUM_HINT,
    }
    return plan


def register_ast_scope_attest_handler(handler: ToolHandler) -> None:
    global _ast_scope_attest_handler
    _ast_scope_attest_handler = handler


def _tool_steersman_run_unbound(project_root: Path,
                                args: dict[str, Any]) -> dict[str, Any]:
    pack = dict(args.get("pack") or {})
    out = _finalize_steersman_pack(pack=pack)
    out["model"] = {
        "ran": False,
        "reason": (
            "steersman runner not yet wired — import "
            "atomadic_forge.a3_og_features.mcp_server"
        ),
    }
    return out


_steersman_run_handler: ToolHandler = _tool_steersman_run_unbound


def _tool_steersman(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Build and optionally run a tiny-model semantic router pack."""
    if isinstance(args.get("ast_scope_plan"), dict):
        plan = args["ast_scope_plan"]
    else:
        scope_args = {
            "project_roots": args.get("project_roots") or [args.get("project_root", project_root)],
            "targets": args.get("targets") or [],
            "agent_ids": args.get("agent_ids") or ["steersman"],
            "ttl_secs": args.get("ttl_secs", 3600),
            "max_nodes": args.get("max_nodes", 200),
            "attest_nexus": args.get("attest_nexus", False),
        }
        plan = _tool_ast_scope(project_root, scope_args)
    pack = _build_steersman_pack(
        ast_scope_plan=plan,
        intent=str(args.get("intent", "transmute spaghetti into Atomadic Standard")),
        max_questions=int(args.get("max_questions", 24)),
    )
    if bool(args.get("run_model", False)):
        _bootstrap_a3_handlers()
        return _steersman_run_handler(project_root, {**args, "pack": pack})
    out = _finalize_steersman_pack(pack=pack)
    out["model"] = {"ran": False, "reason": "run_model=false"}
    return out


def register_steersman_run_handler(handler: ToolHandler) -> None:
    global _steersman_run_handler
    _steersman_run_handler = handler


def _tool_score_patch(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Codex 'Copilot's Copilot' #3 — pre-merge patch risk scorer."""
    diff = str(args.get("diff", ""))
    root = Path(args.get("project_root", project_root)).resolve()
    return _score_patch(diff, project_root=root)


def _tool_select_tests(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Codex #7 — minimum + full-confidence test set per intent."""
    root = Path(args.get("project_root", project_root)).resolve()
    return _select_tests(
        intent=str(args.get("intent", "")),
        changed_files=list(args.get("changed_files") or []),
        project_root=root,
    )


def _tool_rollback_plan(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Codex #11 — reversible-move guidance."""
    from .rollback_planner import rollback_plan as _rb
    root = Path(args.get("project_root", project_root)).resolve()
    return _rb(
        changed_files=list(args.get("changed_files") or []),
        project_root=root,
    )


def _tool_explain_repo(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Codex #6 — humane operational orientation."""
    root = Path(args.get("project_root", project_root)).resolve()
    try:
        scout = harvest_repo(root)
    except (OSError, ValueError):
        scout = None
    try:
        wire = scan_violations(root)
    except (OSError, ValueError):
        wire = None
    try:
        cert = certify(root, project=root.name)
    except (OSError, RuntimeError, ValueError):
        cert = None
    pack = emit_context_pack(project_root=root, scout_report=scout,
                              wire_report=wire, certify_report=cert)
    return _explain_repo(
        project_root=root,
        repo_purpose=pack.get("repo_purpose", ""),
        scout_report=scout, wire_report=wire, certify_report=cert,
        depth=str(args.get("depth", "agent")),
    )


def _tool_adapt_plan(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Codex #8 — capability-aware card filtering."""
    plan = args.get("plan") or {}
    if not isinstance(plan, dict):
        return {"error": "plan must be an agent_plan/v1 object"}
    return _adapt_plan(
        plan,
        agent_capabilities=list(args.get("agent_capabilities") or []),
    )


def _tool_compose_tools(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Codex #9 — tool-use planner."""
    return _compose_tools(goal=str(args.get("goal", "")))


def _tool_load_policy(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Codex #10 — read [tool.forge.agent] from pyproject.toml."""
    root = Path(args.get("project_root", project_root)).resolve()
    return _load_policy(root)


def _tool_why_did_this_change(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Codex #5 — agent memory: lineage + plan-event lookup."""
    root = Path(args.get("project_root", project_root)).resolve()
    return why_did_this_change(file=str(args.get("file", "")), project_root=root)


def _tool_what_failed_last_time(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Codex #5 — failed/rolled_back plan events for an area."""
    root = Path(args.get("project_root", project_root)).resolve()
    return what_failed_last_time(area=str(args.get("area", "")), project_root=root)


# ── v0.10.0 merged-tool dispatchers ───────────────────────────────────
# Each one is a tiny router into existing _tool_* implementations,
# selecting behavior by a `mode` / optional-arg pattern. Keeps the
# new agent-facing surface clean while reusing all underlying logic.


def _tool_lineage(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Unified lineage query (replaces audit_list +
    why_did_this_change + what_failed_last_time).

    Dispatches by ``mode``:

      * ``"all"`` (default) — full audit_list of every artifact under
        ``.atomadic-forge/lineage.jsonl``.
      * ``"by_file"`` — events that touched a specific file (requires
        ``file`` arg).
      * ``"failed_for_area"`` — failed/rolled-back events for an
        area substring (requires ``area`` arg).
    """
    # Auto-detect intent from args when mode is unset:
    #   file=...  → by_file (why_did_this_change)
    #   area=...  → failed_for_area (what_failed_last_time)
    if "mode" in args:
        mode = str(args["mode"])
    elif args.get("file"):
        mode = "by_file"
    elif args.get("area"):
        mode = "failed_for_area"
    else:
        mode = "all"
    if mode == "all":
        return _tool_audit_list(project_root, args)
    if mode == "by_file":
        return _tool_why_did_this_change(project_root, args)
    if mode == "failed_for_area":
        return _tool_what_failed_last_time(project_root, args)
    return {
        "schema_version": "atomadic-forge.lineage/v1",
        "error": f"unknown mode {mode!r}; "
                  "valid: 'all' | 'by_file' | 'failed_for_area'",
    }


def _tool_recipes(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Unified recipe access (replaces list_recipes + get_recipe).

    No ``name`` arg → list all recipes (summaries + catalogue).
    With ``name`` → return that recipe's full body.
    """
    name = args.get("name")
    if name:
        return _tool_get_recipe(project_root, args)
    return _tool_list_recipes(project_root, args)


def _tool_plan(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Unified plan generator (replaces auto_plan + adapt_plan).

    If ``plan`` is supplied as an arg (a pre-generated plan dict),
    routes directly to adapt_plan — the caller already has a plan
    and just wants it filtered against agent capabilities.

    Otherwise generates a fresh plan via auto_plan, optionally
    chained with adapt when ``capability_filter`` is provided.

    When the repo already passes at 100/100 (top_actions=[]), injects
    ``maintenance_hints`` — top CC hotspots from smell_scan so agents
    have actionable next steps even on a clean repo.
    """
    # Adapt-only path: caller already has a plan dict.
    if isinstance(args.get("plan"), dict):
        return _tool_adapt_plan(project_root, args)
    plan = _tool_auto_plan(project_root, args)
    cap_filter = args.get("capability_filter")
    if cap_filter and isinstance(cap_filter, dict):
        adapt_args = dict(args)
        adapt_args["plan"] = plan
        adapt_args.update(cap_filter)
        return _tool_adapt_plan(project_root, adapt_args)
    # When already PASS with no actions, surface smell hotspots as maintenance hints.
    if not plan.get("top_actions") and plan.get("score", 0) >= 100:
        try:
            from .smell_scan import smell_scan as _smell_scan
            root = Path(args.get("target", project_root)).resolve()
            report = _smell_scan(root)
            rd = report.as_dict()
            top_cc = sorted(
                rd.get("complexity_findings", []),
                key=lambda x: -x.get("complexity", 0),
            )[:5]
            if top_cc:
                plan["maintenance_hints"] = [
                    {
                        "type": "complexity",
                        "file": h.get("file", ""),
                        "name": h.get("name", h.get("qualname", "")),
                        "cc": h.get("complexity", 0),
                        "suggestion": f"Refactor to reduce CC from {h.get('complexity', 0)} → ≤10",
                    }
                    for h in top_cc
                ]
                plan["maintenance_hint_count"] = len(top_cc)
        except Exception:
            pass
    return plan


def _tool_plan_apply(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Unified plan applier (replaces auto_step + auto_apply).

    Single-card mode (``card_id`` arg present) → auto_step.
    All-applyable mode (no ``card_id``) → auto_apply.
    """
    if args.get("card_id"):
        return _tool_auto_step(project_root, args)
    return _tool_auto_apply(project_root, args)


def _tool_list_recipes(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Codex #12 — list golden-path recipes."""
    return {
        "schema_version": "atomadic-forge.recipe.list/v1",
        "recipes": list_recipes(),
        "recipe_count": len(list_recipes()),
        "catalogue": {n: r["description"] for n, r in all_recipes().items()},
    }


def _tool_get_recipe(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Codex #12 — fetch a named recipe."""
    name = str(args.get("name", ""))
    recipe = get_recipe(name)
    if recipe is None:
        return {"error": f"unknown recipe: {name!r}"}
    return recipe


def _tool_worktree_status(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Agent worktree orientation: git, remote, version, stale command."""
    root = Path(args.get("project_root", project_root)).resolve()
    return _worktree_status(
        project_root=root,
        max_files=int(args.get("max_files", 20)),
    )


def _tool_trust_gate_response(project_root: Path,
                                  args: dict[str, Any]) -> dict[str, Any]:
    """Backport from Forge Deluxe cycle 13. Run deterministic
    hallucination checks against an LLM response. No LLM in the
    loop; pure AST + regex over code blocks + URLs + claims."""
    from .trust_gate_response import gate_response
    response = str(args.get("response", ""))
    known = args.get("known_capabilities") or []
    local_prefix = str(args.get("local_pkg_prefix", ""))
    if not response:
        return {"error": "missing 'response' argument"}
    verdict = gate_response(
        response,
        known_capabilities=list(known) if known else None,
        local_pkg_prefix=local_prefix,
    )
    return {
        "schema": verdict.schema,
        "score": verdict.score,
        "safe_to_act": verdict.safe_to_act,
        "code_blocks_count": verdict.code_blocks_count,
        "citations_count": verdict.citations_count,
        "findings": [
            {"severity": f.severity, "category": f.category,
              "detail": f.detail, "evidence": f.evidence}
            for f in verdict.findings
        ],
    }


def _tool_exported_api_check(project_root: Path,
                                  args: dict[str, Any]) -> dict[str, Any]:
    """Backport from Forge Deluxe cycle 15. Verify a module's
    docstring claims actually resolve to top-level definitions.
    Catches the failure mode where a body-fill emit ships a
    docstring promising a public function that isn't there."""
    from .exported_api_check import check_exported_api
    source = args.get("source")
    if not source and args.get("path"):
        try:
            source = Path(args["path"]).read_text(encoding="utf-8")
        except OSError as e:
            return {"error": f"cannot read path: {e}"}
    if not source:
        return {"error": "missing 'source' or 'path' argument"}
    strict = bool(args.get("strict", False))
    result = check_exported_api(source, strict=strict)
    return {
        "schema": result.schema,
        "ok": result.ok,
        "detail": result.detail,
        "claims_found": [
            {"name": c.name, "source": c.source}
            for c in result.claims_found
        ],
        "resolved": list(result.resolved),
        "unresolved": list(result.unresolved),
    }


def _tool_auto_plan_unbound(project_root: Path,
                             args: dict[str, Any]) -> dict[str, Any]:
    """auto_plan stub — a3 binds the real ``run_auto_plan`` at import
    time via ``register_auto_plan_handler``. Same a1↔a3 injection
    pattern the enforce tool uses (see Lane C W4 commit msg).
    """
    return {
        "schema_version": "atomadic-forge.agent_plan/v1",
        "wired": False,
        "note": (
            "auto_plan tool not yet wired — import "
            "atomadic_forge.a3_og_features.mcp_server (or any code "
            "under a3) to register the real handler."
        ),
    }


_auto_plan_handler: ToolHandler = _tool_auto_plan_unbound


def _tool_auto_plan(project_root: Path,
                     args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _auto_plan_handler(project_root, args)


def register_auto_plan_handler(handler: ToolHandler) -> None:
    """Bind the real auto_plan handler from a3 (mirror of
    register_enforce_handler)."""
    global _auto_plan_handler
    _auto_plan_handler = handler


def _tool_auto_step_unbound(project_root, args):
    return {
        "schema_version": "atomadic-forge.plan_apply/v1",
        "wired": False,
        "note": "auto_step not wired — import a3.mcp_server.",
    }


def _tool_auto_apply_unbound(project_root, args):
    return {
        "schema_version": "atomadic-forge.plan_apply_all/v1",
        "wired": False,
        "note": "auto_apply not wired — import a3.mcp_server.",
    }


_auto_step_handler: ToolHandler = _tool_auto_step_unbound
_auto_apply_handler: ToolHandler = _tool_auto_apply_unbound


def _tool_auto_step(project_root, args):
    _bootstrap_a3_handlers()
    return _auto_step_handler(project_root, args)


def _tool_auto_apply(project_root, args):
    _bootstrap_a3_handlers()
    return _auto_apply_handler(project_root, args)


def register_auto_step_handler(handler: ToolHandler) -> None:
    global _auto_step_handler
    _auto_step_handler = handler


def register_auto_apply_handler(handler: ToolHandler) -> None:
    global _auto_apply_handler
    _auto_apply_handler = handler


def _tool_emergent_scan_unbound(project_root: Path,
                                 args: dict[str, Any]) -> dict[str, Any]:
    """emergent_scan stub — a3 binds the real EmergentScan at import time via
    ``register_emergent_scan_handler``.  Same a1↔a3 injection pattern used by
    enforce, auto_plan, auto_step, and auto_apply."""
    return {
        "schema_version": "atomadic-forge.emergent.scan/v1",
        "wired": False,
        "note": (
            "emergent_scan not yet wired — import "
            "atomadic_forge.a3_og_features.mcp_server (or any code "
            "under a3) to register the real handler."
        ),
    }


def _tool_synergy_scan_unbound(project_root: Path,
                                args: dict[str, Any]) -> dict[str, Any]:
    """synergy_scan stub — same pattern as emergent_scan."""
    return {
        "schema_version": "atomadic-forge.synergy.scan/v1",
        "wired": False,
        "note": (
            "synergy_scan not yet wired — import "
            "atomadic_forge.a3_og_features.mcp_server (or any code "
            "under a3) to register the real handler."
        ),
    }


_emergent_scan_handler: ToolHandler = _tool_emergent_scan_unbound
_synergy_scan_handler: ToolHandler = _tool_synergy_scan_unbound


def _tool_emergent_scan(project_root: Path,
                         args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _emergent_scan_handler(project_root, args)


def _tool_synergy_scan(project_root: Path,
                        args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _synergy_scan_handler(project_root, args)


def _tool_doctor(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Environment diagnostic — Forge version, Python info, optional deps.

    Same data the `forge doctor` CLI verb prints, returned as JSON. Useful
    as the first call after `initialize` to confirm the runtime is healthy
    and to discover which optional dependencies (`complexipy`,
    `cryptography`, `tomli`) are wired in.
    """
    import importlib

    def _check(dep: str) -> str:
        try:
            importlib.import_module(dep)
            return "ok"
        except ImportError:
            return "missing"

    out = {
        "schema_version": "atomadic-forge.doctor/v1",
        "atomadic_forge_version": __version__,
        "python": sys.version.split()[0],
        "executable": sys.executable,
        "platform": sys.platform,
        "stdout_encoding": getattr(sys.stdout, "encoding", "?"),
        "optional_deps": {
            "complexipy": _check("complexipy"),
            "cryptography": _check("cryptography"),
            "tomli": _check("tomli"),
        },
    }
    # v0.10.0: doctor now absorbs worktree_status when include_worktree=true
    if args.get("include_worktree"):
        out["worktree"] = _tool_worktree_status(project_root, args)
    return out


def _tool_sidecar_validate(project_root: Path,
                            args: dict[str, Any]) -> dict[str, Any]:
    """Cross-check a `.forge` sidecar against its source AST.

    Looks for ``<source>.forge`` next to the source file. Reports drift
    across S0000–S0007 finding classes. Pure: no exec, no LLM.
    """
    src_arg = args.get("source_file") or args.get("path")
    if not src_arg:
        return {"error": "missing 'source_file' argument"}
    src_path = Path(str(src_arg))
    if not src_path.is_absolute():
        src_path = (project_root / src_path).resolve()
    if not src_path.is_file():
        return {"error": f"source_file not found: {src_path}"}
    sidecar_path = _find_sidecar_for(src_path)
    parse = _parse_sidecar_file(sidecar_path)
    if parse["errors"]:
        return {
            "schema_version": "atomadic-forge.sidecar_validate/v1",
            "verdict": "FAIL",
            "sidecar_path": str(sidecar_path),
            "parse_errors": parse["errors"],
            "findings": [],
        }
    try:
        source_text = src_path.read_text(encoding="utf-8")
    except OSError as exc:
        return {"error": f"could not read {src_path}: {exc}"}
    rep = _validate_sidecar(
        parse["sidecar"], source_text=source_text, source_path=src_path,
    )
    return {
        "schema_version": "atomadic-forge.sidecar_validate/v1",
        "source_file": str(src_path),
        "sidecar_path": str(sidecar_path),
        **rep,
    }


def _tool_manifest_diff(project_root: Path,
                         args: dict[str, Any]) -> dict[str, Any]:
    """Schema-aware diff between two Forge manifests.

    Accepts either inline dicts (``left`` / ``right``) or filesystem paths
    (``left_path`` / ``right_path``) to JSON manifests. Reports added /
    removed / moved symbols, tier-distribution deltas, effect-distribution
    deltas, and certify-score deltas.
    """
    def _resolve(side: str) -> tuple[dict | None, str | None]:
        inline = args.get(side)
        if isinstance(inline, dict) and inline:
            return inline, None
        path_key = f"{side}_path"
        path_arg = args.get(path_key)
        if not path_arg:
            return None, f"missing '{side}' or '{path_key}'"
        p = Path(str(path_arg))
        if not p.is_absolute():
            p = (project_root / p).resolve()
        if not p.is_file():
            return None, f"{path_key} not found: {p}"
        try:
            return json.loads(p.read_text(encoding="utf-8")), None
        except (OSError, json.JSONDecodeError) as exc:
            return None, f"could not parse {p}: {exc}"

    left, lerr = _resolve("left")
    if lerr:
        return {"error": lerr}
    right, rerr = _resolve("right")
    if rerr:
        return {"error": rerr}
    try:
        delta = _diff_manifests(left, right)
    except ValueError as exc:
        return {"error": str(exc)}
    return {
        "schema_version": "atomadic-forge.manifest_diff/v1",
        **delta,
    }


def register_emergent_scan_handler(handler: ToolHandler) -> None:
    """Bind the real EmergentScan-backed handler from a3."""
    global _emergent_scan_handler
    _emergent_scan_handler = handler


def register_synergy_scan_handler(handler: ToolHandler) -> None:
    """Bind the real SynergyScan-backed handler from a3."""
    global _synergy_scan_handler
    _synergy_scan_handler = handler


# ── Round 2: the transmuter pipeline as MCP tools ───────────────────────
#
# ``forge auto`` / ``forge cherry`` / ``forge finalize`` already exist as
# CLI verbs in a4 (see :mod:`atomadic_forge.a4_sy_orchestration.cli`).
# They run a deterministic ``scout → cherry → assimilate → wire →
# certify`` pipeline against any source repo and emit a tier-disciplined,
# certified output package — the "transmuter" workflow that turns
# spaghetti into shippable architecture.
#
# These three MCP tools expose the EXACT same handlers to AI coding
# agents. No LLM is invoked inside forge — the agent does its own
# reasoning, and forge supplies analytical certainty (tier
# classification, wire violations, certify score, cherry manifest).
# That keeps the substrate boundary clean: agent = LLM, forge = tools.
#
# The unbound stubs return a structured ``wired: False`` response when
# only a1 is loaded (e.g. test isolation). The real handlers in
# ``a3_og_features.mcp_server`` register at module import time via
# ``register_*_handler``; importing any code under a3 wires them in.


def _tool_auto_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.auto/v1",
        "wired": False,
        "note": "forge auto handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server (or any "
                 "code under a3) to register the real handler.",
    }


_auto_handler: ToolHandler = _tool_auto_unbound


def _tool_auto(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _auto_handler(project_root, args)


def register_auto_handler(handler: ToolHandler) -> None:
    """Bind the real ``run_auto``-backed handler from a3."""
    global _auto_handler
    _auto_handler = handler


def _tool_cherry_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.cherry/v1",
        "wired": False,
        "note": "forge cherry handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_cherry_handler: ToolHandler = _tool_cherry_unbound


def _tool_cherry(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _cherry_handler(project_root, args)


def register_cherry_handler(handler: ToolHandler) -> None:
    """Bind the real ``run_cherry``-backed handler from a3."""
    global _cherry_handler
    _cherry_handler = handler


def _tool_finalize_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.assimilate/v1",
        "wired": False,
        "note": "forge finalize handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_finalize_handler: ToolHandler = _tool_finalize_unbound


def _tool_finalize(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _finalize_handler(project_root, args)


def register_finalize_handler(handler: ToolHandler) -> None:
    """Bind the real ``run_finalize``-backed handler from a3."""
    global _finalize_handler
    _finalize_handler = handler


# ── Round 3: agent-driven iterate (substrate-boundary fix) ──────────────
#
# ``iterate_start`` opens a new session and returns the first prompt the
# agent should send to ITS OWN LLM. ``iterate_continue`` accepts the
# LLM's response, parses files, runs wire+certify, and either signals
# convergence (done=true) or returns the next prompt.
#
# Forge holds NO LLM client. The agent drives reasoning; forge supplies
# certainty between turns. This is the architectural move that locks
# forge in as the substrate every AI coding tool wants to depend on.


def _tool_iterate_start_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.iterate_start/v1",
        "wired": False,
        "note": "forge iterate_start handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_iterate_start_handler: ToolHandler = _tool_iterate_start_unbound


def _tool_iterate_start(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _iterate_start_handler(project_root, args)


def register_iterate_start_handler(handler: ToolHandler) -> None:
    """Bind the real ``iterate_start_session``-backed handler from a3."""
    global _iterate_start_handler
    _iterate_start_handler = handler


def _tool_iterate_continue_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.iterate_continue/v1",
        "wired": False,
        "note": "forge iterate_continue handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_iterate_continue_handler: ToolHandler = _tool_iterate_continue_unbound


def _tool_iterate_continue(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _iterate_continue_handler(project_root, args)


def register_iterate_continue_handler(handler: ToolHandler) -> None:
    """Bind the real ``iterate_continue_session``-backed handler from a3."""
    global _iterate_continue_handler
    _iterate_continue_handler = handler


# ── Round 3.5: agent-driven evolve (recursive iterate) ──────────────────
#
# evolve_start opens a parent evolve session that spawns successive
# iterate children — one per round. evolve_step forwards the agent's
# LLM response into the active iterate child; when the child terminates
# forge decides halt vs. start-next-round (stagnation / regression /
# converged-with-no-delta) and either finalizes the evolve report or
# spawns the next round with the previous round's output as seed.
# Forge holds NO LLM client. Bounded by depth cap of 23 rounds.


def _tool_evolve_start_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.evolve_start/v1",
        "wired": False,
        "note": "evolve_start handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_evolve_start_handler: ToolHandler = _tool_evolve_start_unbound


def _tool_evolve_start(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _evolve_start_handler(project_root, args)


def register_evolve_start_handler(handler: ToolHandler) -> None:
    """Bind the real ``evolve_start_session``-backed handler from a3."""
    global _evolve_start_handler
    _evolve_start_handler = handler


def _tool_evolve_step_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.evolve_step/v1",
        "wired": False,
        "note": "evolve_step handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_evolve_step_handler: ToolHandler = _tool_evolve_step_unbound


def _tool_evolve_step(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _evolve_step_handler(project_root, args)


def register_evolve_step_handler(handler: ToolHandler) -> None:
    """Bind the real ``evolve_step_session``-backed handler from a3."""
    global _evolve_step_handler
    _evolve_step_handler = handler


# ── tool_factory: forge that scaffolds new forge tools ──────────────────
#
# A meta-tool. Given a spec (name, description trigger, input schema,
# handler import), emit the four-piece scaffold (a1 inserts, a3 inserts,
# test additions, optional starter module). Forge does NOT mutate
# mcp_protocol.py automatically — it proposes the change and a higher-
# trust agent applies it. This keeps the meta-loop trust-gated.


def _tool_tool_factory_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.tool_factory/v1",
        "wired": False,
        "note": "tool_factory handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_tool_factory_handler: ToolHandler = _tool_tool_factory_unbound


def _tool_tool_factory(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _tool_factory_handler(project_root, args)


def register_tool_factory_handler(handler: ToolHandler) -> None:
    """Bind the real ``scaffold_tool``-backed handler from a3."""
    global _tool_factory_handler
    _tool_factory_handler = handler


# call_graph is harvested from competitive audit (Code Pathfinder,
# Moderne, Augment, Sourcegraph all ship call-graph traversal).
# Pure deterministic AST walk — lives in a1, no a3 indirection needed
# but follows the same handler pattern for consistency.


def _tool_call_graph(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Build a call graph on demand. Pure: composes the a1
    ``build_call_graph`` walker. No LLM, no I/O outside source reads.
    """
    from .call_graph import build_call_graph
    merged_args = dict(args)
    if "project_root" not in merged_args:
        merged_args["project_root"] = str(project_root)
    return build_call_graph(merged_args)


def _tool_call_graph_summary(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Whole-package call-graph portfolio: orphans, hotspots, max depth.
    Synthesised from pyan whole-graph analysis concepts."""
    from .call_graph import build_call_graph_summary
    merged_args = dict(args)
    if "project_root" not in merged_args:
        merged_args["project_root"] = str(project_root)
    return build_call_graph_summary(merged_args)


def _tool_git_churn(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """File-level git churn metrics: hotspot files, stable files, commit
    frequency distribution. Synthesised from Repomix git-log concepts."""
    from .git_churn import compute_git_churn
    root = Path(args.get("project_root", project_root)).resolve()
    return compute_git_churn(
        root,
        top_n=int(args.get("top_n", 15)),
        since=str(args.get("since", "")),
        src_only=bool(args.get("src_only", True)),
    )


def _tool_surface_gaps(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Detect a1 entry points that lack MCP or CLI coverage — the wiring gap list."""
    from .surface_gap_check import check_surface_gaps
    root = Path(args.get("project_root", project_root)).resolve()
    result = check_surface_gaps(root)
    top_n = int(args.get("top_n", 20))
    # Trim lists to top_n to keep response token-efficient
    for key in ("mcp_gaps", "cli_gaps", "both_gaps"):
        if key in result:
            result[f"{key}_count"] = result.get(f"{key.replace('_gaps','_gap_count')}", len(result[key]))
            result[key] = result[key][:top_n]
    return result


def _tool_capability_scout(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Search GitHub for repos matching capability queries — harvest target finder."""
    from .capability_scout import scout_capabilities
    raw = args.get("queries", "")
    if isinstance(raw, str):
        queries = [q.strip() for q in raw.split(",") if q.strip()]
    else:
        queries = list(raw)
    if not queries:
        queries = ["code analysis python ast", "dead code detection python",
                   "refactoring suggestions python", "semantic code search python"]
    per_query = min(int(args.get("per_query", 8)), 30)
    min_score = float(args.get("min_score", 30.0))
    return scout_capabilities(queries, per_query=per_query, min_score=min_score)


def _tool_wire_stubs(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Generate or apply MCP handler + CLI stub + test skeleton for an unwired a1 function."""
    from .wire_stubs_gen import apply_wire_stubs, generate_wire_stubs
    module_stem = str(args.get("module", ""))
    fn_name = str(args.get("function", ""))
    if not module_stem or not fn_name:
        return {"error": "module and function are required"}
    root = Path(args.get("project_root", project_root)).resolve()
    apply = bool(args.get("apply", False))
    tools_raw = args.get("tools", "explore,audit")
    tool_set = tuple(t.strip() for t in str(tools_raw).split(",") if t.strip())
    dry_run = bool(args.get("dry_run", False))
    if apply or dry_run:
        return apply_wire_stubs(root, module_stem=module_stem, fn_name=fn_name,
                                tools=tool_set, dry_run=dry_run)
    return generate_wire_stubs(root, module_stem=module_stem, fn_name=fn_name)


def _tool_auto_wire(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-wire all unwired a1 entry points into MCP and CLI — no copy-paste."""
    from .surface_gap_check import check_surface_gaps
    from .wire_stubs_gen import apply_wire_stubs
    root = Path(args.get("project_root", project_root)).resolve()
    top_n = int(args.get("top_n", 10))
    dry_run = bool(args.get("dry_run", True))  # safe default: dry-run
    tools_raw = args.get("tools", "explore,audit")
    tool_set = tuple(t.strip() for t in str(tools_raw).split(",") if t.strip())

    gaps = check_surface_gaps(root)
    if not gaps.get("available"):
        return {"error": gaps.get("reason", "surface-gaps unavailable"), "available": False}

    targets = gaps.get("both_gaps", [])[:top_n]
    results = []
    for gap in targets:
        r = apply_wire_stubs(root, module_stem=gap["module"], fn_name=gap["function"],
                             tools=tool_set, dry_run=dry_run)
        results.append(r)

    wired = sum(1 for r in results if not r.get("errors"))
    return {
        "schema_version": "atomadic-forge.auto_wire/v1",
        "available": True,
        "dry_run": dry_run,
        "gaps_found": gaps.get("both_gap_count", 0),
        "targets_attempted": len(targets),
        "wired": wired,
        "skipped": len(targets) - wired,
        "results": results,
    }


def _tool_dead_code(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Find defined-but-unreferenced symbols — dead code detector (vulture synthesis)."""
    from .dead_code_check import check_dead_code
    root = Path(args.get("project_root", project_root)).resolve()
    return check_dead_code(
        root,
        package=args.get("package") or None,
        include_imports=bool(args.get("include_imports", False)),
        include_variables=bool(args.get("include_variables", False)),
        confidence_threshold=float(args.get("confidence_threshold", 60.0)),
    )


def _tool_maintainability(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Compute Maintainability Index per module — radon MI synthesis."""
    from .maintainability_index import compute_maintainability_index
    root = Path(args.get("project_root", project_root)).resolve()
    return compute_maintainability_index(
        root,
        package=args.get("package") or None,
        top_n=int(args.get("top_n", 15)),
    )


def _tool_concept_bridge(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Convert harvest candidates below TAU_TRUST into actionable synthesis plans."""
    from .harvest_concept_bridge import run_concept_bridge
    root = Path(args.get("project_root", project_root)).resolve()
    harvest_json = args.get("harvest_json_path") or None
    top_n = int(args.get("top_n", 10))
    candidates = args.get("candidates") or None
    return run_concept_bridge(root, harvest_json_path=harvest_json,
                              candidates=candidates, top_n=top_n)


def _tool_doc_update(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Regenerate bounded README and CHANGELOG sections from live metrics — zero LLM tokens."""
    from .doc_auto_update import run_doc_auto_update
    root = Path(args.get("project_root", project_root)).resolve()
    sections_raw = args.get("sections", "readme,changelog")
    sections = tuple(s.strip() for s in str(sections_raw).split(",") if s.strip())
    dry_run = bool(args.get("dry_run", False))
    return run_doc_auto_update(root, sections=sections, dry_run=dry_run)


def _tool_doc_drift(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Detect stale MCP tool/action/test counts across all key doc files."""
    from .doc_auto_update import detect_doc_drift
    root = Path(args.get("project_root", project_root)).resolve()
    return detect_doc_drift(root)



def _tool_agent_plan(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for agent_plan_emitter.emit_agent_plan."""
    from .agent_plan_emitter import emit_agent_plan
    return emit_agent_plan(args)


def _tool_ast_scope_blueprint(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for ast_scope_lock.build_ast_scope_blueprint."""
    from .ast_scope_lock import build_ast_scope_blueprint
    return build_ast_scope_blueprint(args)


def _tool_mint_ast_locks(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for ast_scope_lock.mint_ast_locks."""
    from .ast_scope_lock import mint_ast_locks
    blueprint = str(args.get('blueprint', ''))
    return mint_ast_locks(blueprint=blueprint)


def _tool_add_node(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for ast_scope_lock.add_node."""
    from .ast_scope_lock import add_node
    node = args.get('node')
    return add_node(node=node)


def _tool_class_signals(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for body_extractor.detect_class_signals."""
    from .body_extractor import detect_class_signals
    target = args.get('target')
    return detect_class_signals(target=target)


def _tool_body(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for body_extractor.extract_body."""
    from .body_extractor import extract_body
    source_path = str(args.get('source_path', ''))
    symbol_name = str(args.get('symbol_name', ''))
    language = str(args.get('language', ''))
    return extract_body(source_path=source_path, symbol_name=symbol_name, language=language)


def _tool_documentation(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for certify_checks.check_documentation."""
    from .certify_checks import check_documentation
    root = Path(args.get('project_root', project_root)).resolve()
    return check_documentation(root)


def _tool_tests_present(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for certify_checks.check_tests_present."""
    from .certify_checks import check_tests_present
    root = Path(args.get('project_root', project_root)).resolve()
    return check_tests_present(root)


def _tool_count_untiered_source_files(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for certify_checks.count_untiered_source_files."""
    from .certify_checks import count_untiered_source_files
    root = Path(args.get('project_root', project_root)).resolve()
    return count_untiered_source_files(root)


def _tool_tier_layout(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for certify_checks.check_tier_layout."""
    from .certify_checks import check_tier_layout
    root = Path(args.get('project_root', project_root)).resolve()
    package = str(args.get('package', ''))
    return check_tier_layout(root, package=package)


def _tool_no_upward_imports(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for certify_checks.check_no_upward_imports."""
    from .certify_checks import check_no_upward_imports
    root = Path(args.get('project_root', project_root)).resolve()
    package = str(args.get('package', ''))
    return check_no_upward_imports(root, package=package)


def _tool_ci_workflow(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for certify_checks.check_ci_workflow."""
    from .certify_checks import check_ci_workflow
    root = Path(args.get('project_root', project_root)).resolve()
    return check_ci_workflow(root)


def _tool_changelog(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for certify_checks.check_changelog."""
    from .certify_checks import check_changelog
    root = Path(args.get('project_root', project_root)).resolve()
    return check_changelog(root)


def _tool_chat_context(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for chat_context.build_chat_context."""
    from .chat_context import build_chat_context
    paths = list(args.get('paths', []))
    return build_chat_context(paths=paths)


def _tool_effects(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for classify_tier.detect_effects."""
    from .classify_tier import detect_effects
    node = args.get('node')
    return detect_effects(node=node)


def _tool_compliance(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for compliance_checker.check_compliance."""
    from .compliance_checker import check_compliance
    receipt = args.get('receipt')
    return check_compliance(receipt=receipt)


def _tool_compliance_framework(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for compliance_checker.check_compliance_framework."""
    from .compliance_checker import check_compliance_framework
    receipt = args.get('receipt')
    framework = str(args.get('framework', ''))
    return check_compliance_framework(receipt=receipt, framework=framework)


def _tool_cosine_similarity(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for cosine_similarity.cosine_similarity."""
    from .cosine_similarity import cosine_similarity
    a = list(args.get('a', []))
    b = list(args.get('b', []))
    return cosine_similarity(a=a, b=b)


def _tool_update_readme(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for doc_auto_update.update_readme."""
    from .doc_auto_update import update_readme
    project_root = Path(args.get('project_root', project_root)).resolve()
    return update_readme(project_root)


def _tool_update_extended_docs(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Auto-generated MCP handler for doc_auto_update.update_extended_docs."""
    from .doc_auto_update import update_extended_docs
    project_root = Path(args.get('project_root', project_root)).resolve()
    return update_extended_docs(project_root)

def _tool_smell_scan(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Run code-smell detection (cyclomatic complexity + long functions
    + duplicated bodies). Pure: composes the a1 ``smell_scan`` walker."""
    from .smell_scan import smell_scan
    root = Path(args.get("project_root", project_root)).resolve()
    cc_threshold = int(args.get("cc_threshold", 10))
    loc_threshold = int(args.get("loc_threshold", 50))
    top_n = int(args.get("top_n_findings", 20))
    package_subdir = args.get("package_subdir")
    report = smell_scan(
        root,
        cc_threshold=cc_threshold,
        loc_threshold=loc_threshold,
        package_subdir=str(package_subdir) if package_subdir else None,
    )
    d = report.as_dict()
    # Slim findings to top_n to keep MCP response token-efficient.
    # Full counts are preserved in *_count fields so agents can see the total.
    d["complexity_findings_count"] = len(d["complexity_findings"])
    d["long_function_findings_count"] = len(d["long_function_findings"])
    d["duplication_findings_count"] = len(d["duplication_findings"])
    if top_n > 0:
        d["complexity_findings"] = sorted(
            d["complexity_findings"], key=lambda x: -x["complexity"])[:top_n]
        d["long_function_findings"] = sorted(
            d["long_function_findings"], key=lambda x: -x["loc"])[:top_n]
        d["duplication_findings"] = d["duplication_findings"][:top_n]
        d["findings_capped_at"] = top_n
    return d


def _tool_verify_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.verify/v2",
        "wired": False,
        "note": "verify handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_verify_handler: ToolHandler = _tool_verify_unbound


def _tool_verify(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged quality gate: composite go/no-go verdict, LLM hallucination check, or env health."""
    action = str(args.get("action", "composite"))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "composite":
        _bootstrap_a3_handlers()
        return _verify_handler(project_root, inner)
    elif action == "gate":
        return _tool_trust_gate_response(project_root, inner)
    elif action == "health":
        return _tool_doctor(project_root, inner)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["composite", "gate", "health"]}


def register_verify_handler(handler: ToolHandler) -> None:
    """Bind the real ``verify``-backed handler from a3."""
    global _verify_handler
    _verify_handler = handler


# cna_check: hardwired Compose-Not-Add gate. Composes intent_similarity
# + code_signature + dedup_engine. The "stop creating what already
# exists" guardrail, agent-callable.


def _tool_cna_check_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.cna_check/v1",
        "wired": False,
        "note": "cna_check handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_cna_check_handler: ToolHandler = _tool_cna_check_unbound


def _tool_cna_check(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _cna_check_handler(project_root, args)


def register_cna_check_handler(handler: ToolHandler) -> None:
    """Bind the real ``cna_check``-backed handler from a3."""
    global _cna_check_handler
    _cna_check_handler = handler


# emergent_swarm: Round 5. Cross-repo emergent composition discovery.
# Composes recon_swarm + emergent_scan over a union catalog with
# cross-repo score boost. Closes the "compositions visible only across
# the portfolio" gap surfaced in the lang stress test.


def _tool_emergent_swarm_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.emergent_swarm/v1",
        "wired": False,
        "note": "emergent_swarm handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_emergent_swarm_handler: ToolHandler = _tool_emergent_swarm_unbound


def _tool_emergent_swarm(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _emergent_swarm_handler(project_root, args)


def register_emergent_swarm_handler(handler: ToolHandler) -> None:
    """Bind the real ``emergent_swarm``-backed handler from a3."""
    global _emergent_swarm_handler
    _emergent_swarm_handler = handler


# guard_install: standing-guard against architectural regrowth. After
# forge ships a clean repo, install pre-commit hook + GitHub Action +
# pyproject contract + CONTRIBUTING block in one MCP call. Spaghetti
# can never silently come back.


def _tool_guard_install_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.guard_install/v1",
        "wired": False,
        "note": "guard_install handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_guard_install_handler: ToolHandler = _tool_guard_install_unbound


def _tool_guard_install(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _guard_install_handler(project_root, args)


def register_guard_install_handler(handler: ToolHandler) -> None:
    """Bind the real ``guard_install``-backed handler from a3."""
    global _guard_install_handler
    _guard_install_handler = handler


# v0.9.x token-reduction sprint: forge_locate + commit_compose.
# Both pure analytical, no LLM. Together they save ~24k tokens per
# substantial session (per FRICTION_LOG.md F-2 + F-5).


def _tool_forge_locate(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Pure: returns line range of a known forge insertion point."""
    from .forge_locate import forge_locate
    point = str(args["point"])
    root = Path(args.get("project_root", project_root)).resolve()
    return forge_locate(point, project_root=root).as_dict()


def _tool_commit_compose_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.commit_compose/v1",
        "wired": False,
        "note": "commit_compose handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_commit_compose_handler: ToolHandler = _tool_commit_compose_unbound


def _tool_commit_compose(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _commit_compose_handler(project_root, args)


def register_commit_compose_handler(handler: ToolHandler) -> None:
    """Bind the real ``compose_commit_message``-backed handler from a3."""
    global _commit_compose_handler
    _commit_compose_handler = handler


# ── Round 4: cross-repo cherry-hunter (MHED-trust-gated) ─────────────────
#
# ``recon_swarm`` walks N ≤ D_max repos and returns a unified scout
# report. ``harvest`` diffs target's symbols against the union and
# proposes graft candidates ranked by trust-gated confidence. The
# novel capability: surface compositions visible only across the
# portfolio (the 25 cross-domain pipelines the lang stress test made
# vivid). No LLM is invoked — analytical certainty between agent turns.


def _tool_recon_swarm_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.recon_swarm/v1",
        "wired": False,
        "note": "recon_swarm handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_recon_swarm_handler: ToolHandler = _tool_recon_swarm_unbound


def _tool_recon_swarm(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _recon_swarm_handler(project_root, args)


def register_recon_swarm_handler(handler: ToolHandler) -> None:
    """Bind the real ``recon_swarm``-backed handler from a3."""
    global _recon_swarm_handler
    _recon_swarm_handler = handler


def _tool_harvest_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.harvest/v1",
        "wired": False,
        "note": "harvest handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_harvest_handler: ToolHandler = _tool_harvest_unbound


def _tool_harvest(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _harvest_handler(project_root, args)


def register_harvest_handler(handler: ToolHandler) -> None:
    """Bind the real ``harvest``-backed handler from a3."""
    global _harvest_handler
    _harvest_handler = handler


# ── v0.13.1 — wisdom MCP tools ──────────────────────────────────────
# Cross-session institutional memory exposed to MCP. The Local CLI side
# shipped in v0.13.0 (commands/wisdom.py + wisdom_feature.py); these
# four tools surface the same operations to any MCP-aware agent.
# Hand-wired (not via tool_factory) because tool_factory v0.13.0 has
# two known bugs: inputSchema serialization + bound-handler kwargs.
# See WIS-c423811c and WIS-3cd3c921 for v0.13.2 fix targets.


def _tool_wisdom_record_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.wisdom/v1",
        "wired": False,
        "note": "wisdom_record handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_wisdom_record_handler: ToolHandler = _tool_wisdom_record_unbound


def _tool_wisdom_record(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _wisdom_record_handler(project_root, args)


def register_wisdom_record_handler(handler: ToolHandler) -> None:
    """Bind the real ``record_wisdom``-backed handler from a3."""
    global _wisdom_record_handler
    _wisdom_record_handler = handler


def _tool_wisdom_query_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.wisdom_recall/v1",
        "wired": False,
        "note": "wisdom_query handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_wisdom_query_handler: ToolHandler = _tool_wisdom_query_unbound


def _tool_wisdom_query(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _wisdom_query_handler(project_root, args)


def register_wisdom_query_handler(handler: ToolHandler) -> None:
    """Bind the real ``query_wisdom``-backed handler from a3."""
    global _wisdom_query_handler
    _wisdom_query_handler = handler


def _tool_wisdom_list_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.wisdom/v1",
        "wired": False,
        "note": "wisdom_list handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_wisdom_list_handler: ToolHandler = _tool_wisdom_list_unbound


def _tool_wisdom_list(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _wisdom_list_handler(project_root, args)


def register_wisdom_list_handler(handler: ToolHandler) -> None:
    """Bind the real ``list_wisdom``-backed handler from a3."""
    global _wisdom_list_handler
    _wisdom_list_handler = handler


def _tool_wisdom_recall_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.wisdom_recall/v1",
        "wired": False,
        "note": "wisdom_recall handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_wisdom_recall_handler: ToolHandler = _tool_wisdom_recall_unbound


def _tool_wisdom_recall(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _wisdom_recall_handler(project_root, args)


def register_wisdom_recall_handler(handler: ToolHandler) -> None:
    """Bind the real ``recall_for_recon``-backed handler from a3."""
    global _wisdom_recall_handler
    _wisdom_recall_handler = handler


# ── v0.13.3 — wisdom_promote ────────────────────────────────────────


def _tool_wisdom_promote_unbound(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.wisdom_promote/v1",
        "wired": False,
        "note": "wisdom_promote handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_wisdom_promote_handler: ToolHandler = _tool_wisdom_promote_unbound


def _tool_wisdom_promote(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _wisdom_promote_handler(project_root, args)


def register_wisdom_promote_handler(handler: ToolHandler) -> None:
    """Bind the real ``promote_wisdom``-backed handler from a3."""
    global _wisdom_promote_handler
    _wisdom_promote_handler = handler


# ── v0.13.2 — hive sync MCP tools ───────────────────────────────────
# Agent registry + consensus + observe primitives. The "perfect hive
# sync collaboration pipeline into the Forge" — register-and-discover
# for any agent activating against AGENT_COLLAB_PROTOCOL.md.


def _make_hive_unbound(name: str, schema: str):
    def _stub(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
        return {
            "schema_version": schema,
            "wired": False,
            "note": f"{name} handler not yet wired — import "
                     f"atomadic_forge.a3_og_features.mcp_server.",
        }
    return _stub


_tool_hive_register_unbound = _make_hive_unbound(
    "hive_register", "atomadic-forge.hive_registry/v1")
_hive_register_handler: ToolHandler = _tool_hive_register_unbound
def _tool_hive_register(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _hive_register_handler(project_root, args)
def register_hive_register_handler(handler: ToolHandler) -> None:
    global _hive_register_handler
    _hive_register_handler = handler


_tool_hive_list_unbound = _make_hive_unbound(
    "hive_list", "atomadic-forge.hive_registry/v1")
_hive_list_handler: ToolHandler = _tool_hive_list_unbound
def _tool_hive_list(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _hive_list_handler(project_root, args)
def register_hive_list_handler(handler: ToolHandler) -> None:
    global _hive_list_handler
    _hive_list_handler = handler


_tool_hive_deactivate_unbound = _make_hive_unbound(
    "hive_deactivate", "atomadic-forge.hive_registry/v1")
_hive_deactivate_handler: ToolHandler = _tool_hive_deactivate_unbound
def _tool_hive_deactivate(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _hive_deactivate_handler(project_root, args)
def register_hive_deactivate_handler(handler: ToolHandler) -> None:
    global _hive_deactivate_handler
    _hive_deactivate_handler = handler


_tool_hive_observe_unbound = _make_hive_unbound(
    "hive_observe", "atomadic-forge.hive_observe/v1")
_hive_observe_handler: ToolHandler = _tool_hive_observe_unbound
def _tool_hive_observe(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _hive_observe_handler(project_root, args)
def register_hive_observe_handler(handler: ToolHandler) -> None:
    global _hive_observe_handler
    _hive_observe_handler = handler


_tool_hive_propose_unbound = _make_hive_unbound(
    "hive_propose", "atomadic-forge.hive_consensus/v1")
_hive_propose_handler: ToolHandler = _tool_hive_propose_unbound
def _tool_hive_propose(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _hive_propose_handler(project_root, args)
def register_hive_propose_handler(handler: ToolHandler) -> None:
    global _hive_propose_handler
    _hive_propose_handler = handler


_tool_hive_vote_unbound = _make_hive_unbound(
    "hive_vote", "atomadic-forge.hive_consensus/v1")
_hive_vote_handler: ToolHandler = _tool_hive_vote_unbound
def _tool_hive_vote(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _hive_vote_handler(project_root, args)
def register_hive_vote_handler(handler: ToolHandler) -> None:
    global _hive_vote_handler
    _hive_vote_handler = handler


_tool_hive_result_unbound = _make_hive_unbound(
    "hive_result", "atomadic-forge.hive_consensus/v1")
_hive_result_handler: ToolHandler = _tool_hive_result_unbound
def _tool_hive_result(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _hive_result_handler(project_root, args)
def register_hive_result_handler(handler: ToolHandler) -> None:
    global _hive_result_handler
    _hive_result_handler = handler


_tool_hive_needs_vote_unbound = _make_hive_unbound(
    "hive_needs_vote", "atomadic-forge.hive_observe/v1")
_hive_needs_vote_handler: ToolHandler = _tool_hive_needs_vote_unbound
def _tool_hive_needs_vote(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _hive_needs_vote_handler(project_root, args)
def register_hive_needs_vote_handler(handler: ToolHandler) -> None:
    global _hive_needs_vote_handler
    _hive_needs_vote_handler = handler


_tool_hive_recap_unbound = _make_hive_unbound(
    "hive_recap", "atomadic-forge.hive_observe/v1")
_hive_recap_handler: ToolHandler = _tool_hive_recap_unbound
def _tool_hive_recap(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _hive_recap_handler(project_root, args)
def register_hive_recap_handler(handler: ToolHandler) -> None:
    global _hive_recap_handler
    _hive_recap_handler = handler


# ── v0.14.0a7 — Nexus primitives as MCP tools ──────────────────────
# Each of the 7 LIVE primitives is exposed so MCP-aware agents can
# call them directly. Generic factory keeps the boilerplate tight.


def _make_nexus_unbound(name: str, schema: str):
    def _stub(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
        return {
            "schema_version": schema,
            "wired": False,
            "note": f"{name} handler not yet wired — import "
                     f"atomadic_forge.a3_og_features.mcp_server.",
        }
    return _stub


_NEXUS_SCHEMA = "atomadic-forge.nexus_call/v1"

# All 7 follow the same shape: stub + handler global + proxy + register.
_tool_nexus_identity_verify_unbound = _make_nexus_unbound(
    "nexus_identity_verify", _NEXUS_SCHEMA)
_nexus_identity_verify_handler: ToolHandler = _tool_nexus_identity_verify_unbound
def _tool_nexus_identity_verify(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _nexus_identity_verify_handler(project_root, args)
def register_nexus_identity_verify_handler(handler: ToolHandler) -> None:
    global _nexus_identity_verify_handler
    _nexus_identity_verify_handler = handler


_tool_nexus_federation_mint_unbound = _make_nexus_unbound(
    "nexus_federation_mint", _NEXUS_SCHEMA)
_nexus_federation_mint_handler: ToolHandler = _tool_nexus_federation_mint_unbound
def _tool_nexus_federation_mint(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _nexus_federation_mint_handler(project_root, args)
def register_nexus_federation_mint_handler(handler: ToolHandler) -> None:
    global _nexus_federation_mint_handler
    _nexus_federation_mint_handler = handler


_tool_nexus_authorize_action_unbound = _make_nexus_unbound(
    "nexus_authorize_action", _NEXUS_SCHEMA)
_nexus_authorize_action_handler: ToolHandler = _tool_nexus_authorize_action_unbound
def _tool_nexus_authorize_action(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _nexus_authorize_action_handler(project_root, args)
def register_nexus_authorize_action_handler(handler: ToolHandler) -> None:
    global _nexus_authorize_action_handler
    _nexus_authorize_action_handler = handler


_tool_nexus_sys_trust_gate_unbound = _make_nexus_unbound(
    "nexus_sys_trust_gate", _NEXUS_SCHEMA)
_nexus_sys_trust_gate_handler: ToolHandler = _tool_nexus_sys_trust_gate_unbound
def _tool_nexus_sys_trust_gate(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _nexus_sys_trust_gate_handler(project_root, args)
def register_nexus_sys_trust_gate_handler(handler: ToolHandler) -> None:
    global _nexus_sys_trust_gate_handler
    _nexus_sys_trust_gate_handler = handler


_tool_nexus_contract_verify_unbound = _make_nexus_unbound(
    "nexus_contract_verify", _NEXUS_SCHEMA)
_nexus_contract_verify_handler: ToolHandler = _tool_nexus_contract_verify_unbound
def _tool_nexus_contract_verify(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _nexus_contract_verify_handler(project_root, args)
def register_nexus_contract_verify_handler(handler: ToolHandler) -> None:
    global _nexus_contract_verify_handler
    _nexus_contract_verify_handler = handler


_tool_nexus_lineage_record_unbound = _make_nexus_unbound(
    "nexus_lineage_record", _NEXUS_SCHEMA)
_nexus_lineage_record_handler: ToolHandler = _tool_nexus_lineage_record_unbound
def _tool_nexus_lineage_record(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _nexus_lineage_record_handler(project_root, args)
def register_nexus_lineage_record_handler(handler: ToolHandler) -> None:
    global _nexus_lineage_record_handler
    _nexus_lineage_record_handler = handler


_tool_nexus_ratchet_register_unbound = _make_nexus_unbound(
    "nexus_ratchet_register", _NEXUS_SCHEMA)
_nexus_ratchet_register_handler: ToolHandler = _tool_nexus_ratchet_register_unbound
def _tool_nexus_ratchet_register(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _nexus_ratchet_register_handler(project_root, args)
def register_nexus_ratchet_register_handler(handler: ToolHandler) -> None:
    global _nexus_ratchet_register_handler
    _nexus_ratchet_register_handler = handler


# ── v0.14.0a11 — enhancement proposals (trust-gated, human-published) ──


def _tool_enhancement_propose_unbound(project_root: Path,
                                       args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.enhancement_proposal/v1",
        "wired": False,
        "note": "enhancement_propose handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_enhancement_propose_handler: ToolHandler = _tool_enhancement_propose_unbound


def _tool_enhancement_propose(project_root: Path,
                                args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _enhancement_propose_handler(project_root, args)


def register_enhancement_propose_handler(handler: ToolHandler) -> None:
    """Bind the real ``submit_proposal``-backed handler from a3."""
    global _enhancement_propose_handler
    _enhancement_propose_handler = handler


def _tool_enhancement_list_unbound(project_root: Path,
                                     args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.enhancement_proposal/v1",
        "wired": False,
        "note": "enhancement_list handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_enhancement_list_handler: ToolHandler = _tool_enhancement_list_unbound


def _tool_enhancement_list(project_root: Path,
                             args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _enhancement_list_handler(project_root, args)


def register_enhancement_list_handler(handler: ToolHandler) -> None:
    """Bind the real ``list_proposals``-backed handler from a3."""
    global _enhancement_list_handler
    _enhancement_list_handler = handler


# ── v0.14.0a12 — welcome: first-call handshake ──


def _tool_welcome_unbound(project_root: Path,
                            args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.welcome/v1",
        "wired": False,
        "note": "welcome handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_welcome_handler: ToolHandler = _tool_welcome_unbound


def _tool_welcome(project_root: Path,
                    args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _welcome_handler(project_root, args)


def register_welcome_handler(handler: ToolHandler) -> None:
    """Bind the real ``welcome``-backed handler from a3."""
    global _welcome_handler
    _welcome_handler = handler


# ---- v0.47.0 — `forge create` exposed as MCP tool --------------------


def _tool_create_unbound(project_root: Path,
                          args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.create/v1",
        "wired": False,
        "note": "create handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_create_handler: ToolHandler = _tool_create_unbound


def _tool_create(project_root: Path,
                  args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _create_handler(project_root, args)


def register_create_handler(handler: ToolHandler) -> None:
    """Bind the real ``create``-backed handler from a3."""
    global _create_handler
    _create_handler = handler


# ── v0.14.0a9 — handoff: structured agent-to-agent session transfer ──


def _tool_handoff_create_unbound(project_root: Path,
                                  args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.handoff/v1",
        "wired": False,
        "note": "handoff_create handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_handoff_create_handler: ToolHandler = _tool_handoff_create_unbound


def _tool_handoff_create(project_root: Path,
                          args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _handoff_create_handler(project_root, args)


def register_handoff_create_handler(handler: ToolHandler) -> None:
    """Bind the real ``write_handoff``-backed handler from a3."""
    global _handoff_create_handler
    _handoff_create_handler = handler


def _tool_handoff_list_unbound(project_root: Path,
                                args: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "atomadic-forge.handoff/v1",
        "wired": False,
        "note": "handoff_list handler not yet wired — import "
                 "atomadic_forge.a3_og_features.mcp_server.",
    }


_handoff_list_handler: ToolHandler = _tool_handoff_list_unbound


def _tool_handoff_list(project_root: Path,
                        args: dict[str, Any]) -> dict[str, Any]:
    _bootstrap_a3_handlers()
    return _handoff_list_handler(project_root, args)


def register_handoff_list_handler(handler: ToolHandler) -> None:
    """Bind the real ``list_handoffs``-backed handler from a3."""
    global _handoff_list_handler
    _handoff_list_handler = handler


def _tool_iterate(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged iterate: action='start' opens a session, action='continue' advances it."""
    action = str(args.get("action", ""))
    if action == "start":
        _bootstrap_a3_handlers()
        return _iterate_start_handler(project_root, args)
    elif action == "continue":
        _bootstrap_a3_handlers()
        return _iterate_continue_handler(project_root, args)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["start", "continue"]}


def _tool_evolve(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged evolve: action='start' opens a session, action='step' advances it."""
    action = str(args.get("action", ""))
    if action == "start":
        _bootstrap_a3_handlers()
        return _evolve_start_handler(project_root, args)
    elif action == "step":
        _bootstrap_a3_handlers()
        return _evolve_step_handler(project_root, args)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["start", "step"]}


def _tool_transmute(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged transmuter pipeline: auto/cherry/finalize."""
    action = str(args.get("action", ""))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "auto":
        return _tool_auto(project_root, inner)
    elif action == "cherry":
        return _tool_cherry(project_root, inner)
    elif action == "finalize":
        return _tool_finalize(project_root, inner)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["auto", "cherry", "finalize"]}


def _tool_emergent(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged emergent analysis: scan (single-repo) / swarm (multi-repo)."""
    action = str(args.get("action", ""))
    inner = {k: v for k, v in args.items() if k != "action"}
    _bootstrap_a3_handlers()
    if action == "scan":
        return _tool_emergent_scan(project_root, inner)
    elif action == "swarm":
        return _tool_emergent_swarm(project_root, inner)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["scan", "swarm"]}


def _tool_recon_merged(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged recon: scan (single-repo) / swarm (multi-repo)."""
    action = str(args.get("action", "scan"))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "scan":
        return _tool_recon(project_root, inner)
    elif action == "swarm":
        return _tool_recon_swarm(project_root, inner)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["scan", "swarm"]}


def _tool_wisdom(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged wisdom DB: record/query/list/recall/promote."""
    action = str(args.get("action", ""))
    _bootstrap_a3_handlers()
    if action == "record":
        return _wisdom_record_handler(project_root, args)
    elif action == "query":
        return _wisdom_query_handler(project_root, args)
    elif action == "list":
        return _wisdom_list_handler(project_root, args)
    elif action == "recall":
        return _wisdom_recall_handler(project_root, args)
    elif action == "promote":
        return _wisdom_promote_handler(project_root, args)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["record", "query", "list", "recall", "promote"]}


def _tool_nexus(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged Nexus LIVE primitives: identity_verify/federation_mint/authorize_action/
    sys_trust_gate/contract_verify/lineage_record/ratchet_register."""
    op = str(args.get("op", ""))
    inner = {k: v for k, v in args.items() if k != "op"}
    _bootstrap_a3_handlers()
    if op == "identity_verify":
        return _nexus_identity_verify_handler(project_root, inner)
    elif op == "federation_mint":
        return _nexus_federation_mint_handler(project_root, inner)
    elif op == "authorize_action":
        return _nexus_authorize_action_handler(project_root, inner)
    elif op == "sys_trust_gate":
        return _nexus_sys_trust_gate_handler(project_root, inner)
    elif op == "contract_verify":
        return _nexus_contract_verify_handler(project_root, inner)
    elif op == "lineage_record":
        return _nexus_lineage_record_handler(project_root, inner)
    elif op == "ratchet_register":
        return _nexus_ratchet_register_handler(project_root, inner)
    return {
        "error": f"Unknown op {op!r}",
        "valid_ops": [
            "identity_verify", "federation_mint", "authorize_action",
            "sys_trust_gate", "contract_verify", "lineage_record", "ratchet_register",
        ],
    }


def _tool_plan_merged(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged plan + forge dev utilities + context_pack + tool_factory:
    generate/apply/locate/commit/scaffold/context/compose/policy/recipes.

    v0.48.0: transmute (auto/cherry/finalize) split out as standalone tool;
    LLM loops (iterate/resume/evolve/evolve_step) split out as `loop` tool.
    Legacy callers pass through via LEGACY_ENDPOINT_MAP."""
    action = str(args.get("action", "generate"))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "generate":
        return _tool_plan(project_root, inner)
    elif action == "apply":
        return _tool_plan_apply(project_root, inner)
    elif action == "locate":
        return _tool_forge_locate(project_root, inner)
    elif action == "commit":
        return _tool_commit_compose(project_root, inner)
    # tool_factory action
    elif action == "scaffold":
        return _tool_tool_factory(project_root, inner)
    # context_pack actions
    elif action == "context":
        return _tool_context_pack(project_root, inner)
    elif action == "compose":
        return _tool_compose_tools(project_root, inner)
    elif action == "policy":
        return _tool_load_policy(project_root, inner)
    elif action == "recipes":
        return _tool_recipes(project_root, inner)
    elif action == "steersman":
        return _tool_steersman(project_root, inner)
    return {"error": f"Unknown action {action!r}",
            "valid_actions": ["generate", "apply", "locate", "commit",
                              "scaffold", "context", "compose", "policy", "recipes",
                              "steersman"],
            "hint": "v0.48.0: auto/cherry/finalize moved to `transmute` tool; "
                    "iterate/resume/evolve/evolve_step moved to `loop` tool."}


def _tool_code_intel(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged code intelligence: call_graph/call_graph_summary/smell_scan."""
    action = str(args.get("action", ""))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "call_graph":
        return _tool_call_graph(project_root, inner)
    elif action == "call_graph_summary":
        return _tool_call_graph_summary(project_root, inner)
    elif action == "smell_scan":
        return _tool_smell_scan(project_root, inner)
    return {"error": f"Unknown action {action!r}",
            "valid_actions": ["call_graph", "call_graph_summary", "smell_scan"]}


def _tool_preflight_merged(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged pre-change review: check (preflight_change) / score (score_patch)."""
    action = str(args.get("action", ""))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "check":
        return _tool_preflight_change(project_root, inner)
    elif action == "score":
        return _tool_score_patch(project_root, inner)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["check", "score"]}


def _tool_forge_util(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged forge dev utilities: locate (forge_locate) / commit (commit_compose)."""
    action = str(args.get("action", ""))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "locate":
        return _tool_forge_locate(project_root, inner)
    elif action == "commit":
        return _tool_commit_compose(project_root, inner)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["locate", "commit"]}


def _tool_change_review(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged change management: rollback (rollback_plan) / diff (manifest_diff)."""
    action = str(args.get("action", ""))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "rollback":
        return _tool_rollback_plan(project_root, inner)
    elif action == "diff":
        return _tool_manifest_diff(project_root, inner)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["rollback", "diff"]}


def _tool_maintain(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged maintenance: validate (sidecar_validate) / guard (guard_install)."""
    action = str(args.get("action", ""))
    inner = {k: v for k, v in args.items() if k != "action"}
    _bootstrap_a3_handlers()
    if action == "validate":
        return _tool_sidecar_validate(project_root, inner)
    elif action == "guard":
        return _tool_guard_install(project_root, inner)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["validate", "guard"]}


def _tool_workflow(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged workflow config: compose / policy / recipes."""
    action = str(args.get("action", ""))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "compose":
        return _tool_compose_tools(project_root, inner)
    elif action == "policy":
        return _tool_load_policy(project_root, inner)
    elif action == "recipes":
        return _tool_recipes(project_root, inner)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["compose", "policy", "recipes"]}


def _tool_context_pack_full(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged context + workflow: context bundle / compose / policy / recipes."""
    action = args.get("action")
    inner = {k: v for k, v in args.items() if k != "action"}
    if action is None:
        # No action = default context_pack bundle (backwards-compatible)
        return _tool_context_pack(project_root, inner)
    action = str(action)
    if action == "compose":
        return _tool_compose_tools(project_root, inner)
    elif action == "policy":
        return _tool_load_policy(project_root, inner)
    elif action == "recipes":
        return _tool_recipes(project_root, inner)
    return {"error": f"Unknown action {action!r}",
            "valid_actions": ["compose", "policy", "recipes"]}


def _tool_discover(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged discovery: harvest / synergy / scan (emergent single-repo) / swarm (emergent multi-repo)."""
    action = str(args.get("action", ""))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "harvest":
        _bootstrap_a3_handlers()
        return _tool_harvest(project_root, inner)
    elif action == "synergy":
        _bootstrap_a3_handlers()
        return _tool_synergy_scan(project_root, inner)
    elif action in ("scan", "swarm"):
        inner["action"] = action
        return _tool_emergent(project_root, inner)
    return {"error": f"Unknown action {action!r}",
            "valid_actions": ["harvest", "synergy", "scan", "swarm"]}


def _tool_explore(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged exploration + discovery:
    recon/explain/call_graph/call_graph_summary/smell_scan/churn/lineage/harvest/synergy/scan/swarm."""
    action = str(args.get("action", "recon"))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "recon":
        # Route to swarm when repos list provided, otherwise single-repo scan.
        inner.setdefault("action", "swarm" if "repos" in inner else "scan")
        return _tool_recon_merged(project_root, inner)
    elif action == "explain":
        return _tool_explain_repo(project_root, inner)
    elif action == "call_graph":
        return _tool_call_graph(project_root, inner)
    elif action == "call_graph_summary":
        return _tool_call_graph_summary(project_root, inner)
    elif action == "smell_scan":
        return _tool_smell_scan(project_root, inner)
    elif action == "churn":
        return _tool_git_churn(project_root, inner)
    elif action == "surface_gaps":
        return _tool_surface_gaps(project_root, inner)
    elif action == "capability_scout":
        return _tool_capability_scout(project_root, inner)
    elif action == "dead_code":
        return _tool_dead_code(project_root, inner)
    elif action == "maintainability":
        return _tool_maintainability(project_root, inner)
    elif action == "agent_plan":
        return _tool_agent_plan(project_root, inner)
    elif action == "ast_scope_blueprint":
        return _tool_ast_scope_blueprint(project_root, inner)
    elif action == "mint_ast_locks":
        return _tool_mint_ast_locks(project_root, inner)
    elif action == "add_node":
        return _tool_add_node(project_root, inner)
    elif action == "class_signals":
        return _tool_class_signals(project_root, inner)
    elif action == "body":
        return _tool_body(project_root, inner)
    elif action == "documentation":
        return _tool_documentation(project_root, inner)
    elif action == "tests_present":
        return _tool_tests_present(project_root, inner)
    elif action == "count_untiered_source_files":
        return _tool_count_untiered_source_files(project_root, inner)
    elif action == "tier_layout":
        return _tool_tier_layout(project_root, inner)
    elif action == "no_upward_imports":
        return _tool_no_upward_imports(project_root, inner)
    elif action == "ci_workflow":
        return _tool_ci_workflow(project_root, inner)
    elif action == "changelog":
        return _tool_changelog(project_root, inner)
    elif action == "chat_context":
        return _tool_chat_context(project_root, inner)
    elif action == "effects":
        return _tool_effects(project_root, inner)
    elif action == "compliance":
        return _tool_compliance(project_root, inner)
    elif action == "compliance_framework":
        return _tool_compliance_framework(project_root, inner)
    elif action == "cosine_similarity":
        return _tool_cosine_similarity(project_root, inner)
    elif action == "update_readme":
        return _tool_update_readme(project_root, inner)
    elif action == "update_extended_docs":
        return _tool_update_extended_docs(project_root, inner)
    elif action == "concept_bridge":
        return _tool_concept_bridge(project_root, inner)
    elif action == "lineage":
        return _tool_lineage(project_root, inner)
    # discover actions
    elif action == "harvest":
        _bootstrap_a3_handlers()
        return _tool_harvest(project_root, inner)
    elif action == "synergy":
        _bootstrap_a3_handlers()
        return _tool_synergy_scan(project_root, inner)
    elif action in ("scan", "swarm"):
        inner["action"] = action
        return _tool_emergent(project_root, inner)
    return {"error": f"Unknown action {action!r}",
            "valid_actions": ["recon", "explain", "call_graph", "call_graph_summary",
                              "smell_scan", "churn", "lineage",
                              "harvest", "synergy", "scan", "swarm"]}


def _tool_audit(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged quality + verification + change safety:
    certify/wire/enforce/validate/guard/composite/gate/health/check/score/tests/cna/rollback/diff."""
    action = str(args.get("action", ""))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "certify":
        return _tool_certify(project_root, inner)
    elif action == "wire":
        return _tool_wire(project_root, inner)
    elif action == "enforce":
        return _tool_enforce(project_root, inner)
    elif action == "validate":
        _bootstrap_a3_handlers()
        return _tool_sidecar_validate(project_root, inner)
    elif action == "guard":
        _bootstrap_a3_handlers()
        return _tool_guard_install(project_root, inner)
    elif action == "composite":
        _bootstrap_a3_handlers()
        return _verify_handler(project_root, inner)
    elif action == "gate":
        return _tool_trust_gate_response(project_root, inner)
    elif action == "health":
        return _tool_doctor(project_root, inner)
    # preflight actions
    elif action == "check":
        return _tool_preflight_change(project_root, inner)
    elif action == "score":
        return _tool_score_patch(project_root, inner)
    elif action == "tests":
        return _tool_select_tests(project_root, inner)
    elif action == "cna":
        return _tool_cna_check(project_root, inner)
    elif action == "rollback":
        return _tool_rollback_plan(project_root, inner)
    elif action == "diff":
        return _tool_manifest_diff(project_root, inner)
    elif action == "ast_scope":
        return _tool_ast_scope(project_root, inner)
    elif action == "surface_gaps":
        return _tool_surface_gaps(project_root, inner)
    elif action == "wire_stubs":
        return _tool_wire_stubs(project_root, inner)
    elif action == "dead_code":
        return _tool_dead_code(project_root, inner)
    elif action == "maintainability":
        return _tool_maintainability(project_root, inner)
    elif action == "concept_bridge":
        return _tool_concept_bridge(project_root, inner)
    elif action == "auto_wire":
        return _tool_auto_wire(project_root, inner)
    elif action == "doc_update":
        return _tool_doc_update(project_root, inner)
    elif action == "doc_drift":
        return _tool_doc_drift(project_root, inner)
    return {"error": f"Unknown action {action!r}",
            "valid_actions": ["certify", "wire", "enforce", "validate", "guard",
                              "composite", "gate", "health",
                              "check", "score", "tests", "cna", "rollback", "diff",
                              "ast_scope", "surface_gaps", "wire_stubs", "dead_code",
                              "maintainability", "concept_bridge", "auto_wire",
                              "doc_update", "doc_drift"]}


def _tool_preflight_full(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged change safety: check / score / tests / cna / rollback / diff."""
    action = str(args.get("action", ""))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "check":
        return _tool_preflight_change(project_root, inner)
    elif action == "score":
        return _tool_score_patch(project_root, inner)
    elif action == "tests":
        return _tool_select_tests(project_root, inner)
    elif action == "cna":
        return _tool_cna_check(project_root, inner)
    elif action == "rollback":
        return _tool_rollback_plan(project_root, inner)
    elif action == "diff":
        return _tool_manifest_diff(project_root, inner)
    elif action == "ast_scope":
        return _tool_ast_scope(project_root, inner)
    return {"error": f"Unknown action {action!r}",
            "valid_actions": ["check", "score", "tests", "cna", "rollback", "diff",
                              "ast_scope"]}


def _tool_hive(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged hive + session: lifecycle, consensus, handoffs, and enhancements."""
    action = str(args.get("action", ""))
    _bootstrap_a3_handlers()
    # lifecycle
    if action == "register":
        return _hive_register_handler(project_root, args)
    elif action == "list":
        return _hive_list_handler(project_root, args)
    elif action == "deactivate":
        return _hive_deactivate_handler(project_root, args)
    elif action == "observe":
        return _hive_observe_handler(project_root, args)
    # consensus
    elif action == "propose":
        return _hive_propose_handler(project_root, args)
    elif action == "vote":
        return _hive_vote_handler(project_root, args)
    elif action == "needs_vote":
        return _hive_needs_vote_handler(project_root, args)
    elif action == "result":
        return _hive_result_handler(project_root, args)
    elif action == "recap":
        return _hive_recap_handler(project_root, args)
    # session (handoff + enhancement)
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "handoff_create":
        inner["action"] = "create"
        return _tool_handoff(project_root, inner)
    elif action == "handoff_list":
        inner["action"] = "list"
        return _tool_handoff(project_root, inner)
    elif action == "enhance_propose":
        inner["action"] = "propose"
        return _tool_enhancement(project_root, inner)
    elif action == "enhance_list":
        inner["action"] = "list"
        return _tool_enhancement(project_root, inner)
    return {"error": f"Unknown action {action!r}",
            "valid_actions": ["register", "list", "deactivate", "observe",
                              "propose", "vote", "needs_vote", "result", "recap",
                              "handoff_create", "handoff_list",
                              "enhance_propose", "enhance_list"]}


def _tool_loop(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged LLM loop driver: iterate (single-round) and evolve (recursive)."""
    action = str(args.get("action", ""))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "iterate":
        inner["action"] = "start"
        return _tool_iterate(project_root, inner)
    elif action == "resume":
        inner["action"] = "continue"
        return _tool_iterate(project_root, inner)
    elif action == "evolve":
        inner["action"] = "start"
        return _tool_evolve(project_root, inner)
    elif action == "evolve_step":
        inner["action"] = "step"
        return _tool_evolve(project_root, inner)
    return {"error": f"Unknown action {action!r}",
            "valid_actions": ["iterate", "resume", "evolve", "evolve_step"]}


def _tool_session(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged session meta: handoff transfer + enhancement proposals."""
    action = str(args.get("action", ""))
    inner = {k: v for k, v in args.items() if k != "action"}
    if action == "handoff_create":
        inner["action"] = "create"
        return _tool_handoff(project_root, inner)
    elif action == "handoff_list":
        inner["action"] = "list"
        return _tool_handoff(project_root, inner)
    elif action == "enhance_propose":
        inner["action"] = "propose"
        return _tool_enhancement(project_root, inner)
    elif action == "enhance_list":
        inner["action"] = "list"
        return _tool_enhancement(project_root, inner)
    return {"error": f"Unknown action {action!r}",
            "valid_actions": ["handoff_create", "handoff_list", "enhance_propose", "enhance_list"]}


def _tool_hive_agent(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged hive agent management: register/list/deactivate/observe."""
    action = str(args.get("action", ""))
    _bootstrap_a3_handlers()
    if action == "register":
        return _hive_register_handler(project_root, args)
    elif action == "list":
        return _hive_list_handler(project_root, args)
    elif action == "deactivate":
        return _hive_deactivate_handler(project_root, args)
    elif action == "observe":
        return _hive_observe_handler(project_root, args)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["register", "list", "deactivate", "observe"]}


def _tool_hive_consensus(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged hive consensus: propose/vote/needs_vote/result/recap."""
    action = str(args.get("action", ""))
    _bootstrap_a3_handlers()
    if action == "propose":
        return _hive_propose_handler(project_root, args)
    elif action == "vote":
        return _hive_vote_handler(project_root, args)
    elif action == "needs_vote":
        return _hive_needs_vote_handler(project_root, args)
    elif action == "result":
        return _hive_result_handler(project_root, args)
    elif action == "recap":
        return _hive_recap_handler(project_root, args)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["propose", "vote", "needs_vote", "result", "recap"]}


def _tool_handoff(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged handoff: action='create' writes a handoff, action='list' reads them."""
    action = str(args.get("action", ""))
    if action == "create":
        _bootstrap_a3_handlers()
        return _handoff_create_handler(project_root, args)
    elif action == "list":
        _bootstrap_a3_handlers()
        return _handoff_list_handler(project_root, args)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["create", "list"]}


def _tool_enhancement(project_root: Path, args: dict[str, Any]) -> dict[str, Any]:
    """Merged enhancement: action='propose' submits, action='list' reads."""
    action = str(args.get("action", ""))
    if action == "propose":
        _bootstrap_a3_handlers()
        return _enhancement_propose_handler(project_root, args)
    elif action == "list":
        _bootstrap_a3_handlers()
        return _enhancement_list_handler(project_root, args)
    return {"error": f"Unknown action {action!r}", "valid_actions": ["propose", "list"]}


TOOLS: dict[str, dict[str, Any]] = {
    "explore": {
        "name": "explore",
        "description": (
            "Use this when: you need to understand, analyze, or discover patterns in a repo. "
            "action='recon' (default): maps every public symbol into the 5 monadic tiers. "
            "action='explain': plain-English orientation — one-liner, core flow, do_not_break. "
            "action='call_graph': AST BFS walk — callers/callees of a target symbol. "
            "action='call_graph_summary': whole-package portfolio — orphans, hotspots, max depth. "
            "action='smell_scan': CC monsters, long functions, dup bodies (smell_score 0-100). "
            "action='churn': file-level git churn — hotspot/stable files, avg/median commits. "
            "action='surface_gaps': find a1 entry points missing MCP or CLI wiring (the gap punch-list). "
            "action='capability_scout': search GitHub for repos matching capability queries. "
            "action='dead_code': find defined-but-unreferenced symbols (vulture synthesis). "
            "action='maintainability': compute Maintainability Index per module (radon MI). "
            "action='concept_bridge': convert harvest candidates below TAU_TRUST into synthesis plans. "
            "action='lineage': query the .atomadic-forge lineage log (mode=all/by_file/failed_for_area). "
            "action='harvest': cross-repo cherry-hunter — diffs target vs source repos, "
            "ranks graft candidates by trust-gated confidence (max-depth 23, no LLM). "
            "action='synergy': intra-repo scanner — finds CLI verbs / a3 features that compose well. "
            "action='scan': single-repo emergent compositions (top_n, include_chains). "
            "action='swarm': multi-repo portfolio emergent scan (N≤23) — cross-repo bonus. "
            "All actions: no LLM invoked."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["recon", "explain", "call_graph", "call_graph_summary",
                             "smell_scan", "churn", "surface_gaps", "capability_scout",
                             "dead_code", "maintainability", "concept_bridge",
                             "lineage", "harvest", "synergy", "scan", "swarm",
                             "agent_plan"],
                    "default": "recon",
                    "description": (
                        "'recon' — tier map; 'explain' — narrative; "
                        "'call_graph' — symbol graph; 'call_graph_summary' — package portfolio; "
                        "'smell_scan' — code smell; 'churn' — git file churn; "
                        "'surface_gaps' — wiring gap list; 'capability_scout' — find harvest targets; "
                        "'dead_code' — unreferenced symbols; 'maintainability' — MI per module; "
                        "'concept_bridge' — synthesis plans from harvest candidates; "
                        "'lineage' — audit log; 'harvest' — cross-repo grafts; "
                        "'synergy' — composition patterns; "
                        "'scan' — single-repo emergent; 'swarm' — multi-repo emergent."
                    ),
                },
                # recon + harvest/discover params
                "target": {"type": "string",
                            "description": "[recon/harvest] Repo path."},
                "repos": {
                    "type": "array",
                    "description": "[recon] list of repo paths (max 23); [swarm] list of {src_root, package} objects.",
                    "minItems": 1, "maxItems": 23,
                },
                "sources": {"type": "array", "items": {"type": "string"},
                             "description": "[harvest] Source repos. Max 23.",
                             "minItems": 1, "maxItems": 23},
                # explain params
                "depth": {"type": "string", "default": "agent"},
                # call_graph params
                "qualname": {"type": "string",
                              "description": "[call_graph] Target symbol qualname."},
                "package": {"type": "string",
                             "description": "[call_graph/smell_scan/synergy/scan] Package name."},
                "direction": {"type": "string", "enum": ["callers", "callees", "both"],
                               "default": "both", "description": "[call_graph] Walk direction."},
                "max_depth": {"type": "integer", "default": 3, "minimum": 1, "maximum": 10,
                               "description": "[call_graph] BFS depth cap; [scan/swarm] chain depth cap."},
                # smell_scan params
                "cc_threshold": {"type": "integer", "default": 10,
                                  "description": "[smell_scan] Flag functions with CC > this."},
                "loc_threshold": {"type": "integer", "default": 50,
                                   "description": "[smell_scan] Flag functions with body LOC > this."},
                "package_subdir": {"type": "string",
                                    "description": "[smell_scan] Optional subdir under project_root."},
                "top_n_findings": {"type": "integer", "default": 20,
                                    "description": "[smell_scan] Cap findings per category (0=unlimited)."},
                # churn params
                "since": {"type": "string", "default": "",
                           "description": "[churn] Git date filter (e.g. '6 months ago'). Empty = all time."},
                "src_only": {"type": "boolean", "default": True,
                              "description": "[churn/call_graph_summary] Restrict to src/ files only."},
                # capability_scout params
                "queries": {
                    "type": ["string", "array"],
                    "description": "[capability_scout] Comma-separated or list of capability search queries.",
                },
                "per_query": {"type": "integer", "default": 8,
                               "description": "[capability_scout] Max GitHub results per query (≤30)."},
                "min_score": {"type": "number", "default": 30.0,
                               "description": "[capability_scout] Min harvest-confidence score to include."},
                # lineage params
                "mode": {"type": "string", "enum": ["all", "by_file", "failed_for_area"],
                          "default": "all", "description": "[lineage] Query mode."},
                "file": {"type": "string",
                          "description": "[lineage] Required when mode='by_file'."},
                "area": {"type": "string",
                          "description": "[lineage] Required when mode='failed_for_area'."},
                # synergy + scan + swarm params
                "include_details": {"type": "boolean", "default": False,
                                     "description": "[synergy] Include full detail blocks."},
                "top_n": {"type": "integer", "default": 10,
                           "description": "[synergy/scan/swarm] Max candidates returned."},
                "include_chains": {"type": "boolean", "default": False,
                                    "description": "[scan] Include full chain + score_breakdown."},
                "max_chains": {"type": "integer", "default": 5000,
                                "description": "[swarm] Max chains to evaluate."},
                "require_pure": {"type": "boolean", "default": False,
                                  "description": "[swarm] Require all symbols to be pure."},
                "domain_jump_required": {"type": "boolean", "default": True,
                                          "description": "[swarm] Require domain jump."},
                "cross_repo_bonus": {"type": "number", "default": 15.0,
                                      "description": "[swarm] Score bonus per extra origin_repo."},
                "corroborate_with_call_graph": {"type": "boolean", "default": True,
                                                 "description": "[swarm] Cross-validate edges against call_graph."},
                # shared
                "project_root": {"type": "string"},
            },
            "additionalProperties": False,
        },
        "handler": _tool_explore,
    },
    "audit": {
        "name": "audit",
        "description": (
            "Use this when: you need to check, fix, verify, or safely change a repo. "
            "action='certify': 0-100 quality score (docs, tests, tier layout, import discipline). "
            "emit_receipt=true produces Forge Receipt v1 JSON. skip_tests=true for fast mode (~500ms). "
            "action='wire': finds every upward-import violation. suggest_repairs=true adds fix hints. "
            "action='enforce': apply mechanical fixes for wire violations (apply=false=dry-run). "
            "action='validate': validates a .forge sidecar TOML — required fields + types. "
            "action='guard': installs four enforcement layers (pre-commit hook, GHA workflow, "
            "pyproject contract, CONTRIBUTING block). apply=false returns planned writes. "
            "action='composite': single go/no-go verdict — wire+certify always, "
            "score_patch+preflight_change when diff/intent supplied; returns PASS/REFINE/FAIL. "
            "action='gate': deterministic hallucination detector for LLM responses — "
            "catches unresolved imports, syntax errors, stubs, false capability claims. "
            "action='health': Forge env diagnostic — version, Python, platform, optional deps. "
            "action='check': pre-edit guardrail — given intent + proposed_files, "
            "returns each file's tier, forbidden imports, affected tests, scope verdict. "
            "action='score': patch risk scorer — submit a unified diff, get "
            "architecture/test/public_API/release risk scores and needs_human_review. "
            "action='tests': minimum + full-confidence test set selection per intent. "
            "action='cna': Compose-Not-Add check — verify a proposed symbol is not duplicating "
            "an existing one (name + body-hash similarity). Returns PASS/REFINE/REJECT. "
            "action='rollback': structured undo plan — files to remove, caches to clean, "
            "docs to restore, tests to rerun, risk level. "
            "action='diff': compares two Forge manifests side-by-side. "
            "action='ast_scope': multi-repo AST blueprint + deterministic edit locks; "
            "attest_nexus=true mirrors locks to AAAA-Nexus lineage when a key is present, "
            "and otherwise returns a premium/x402 hint without failing. "
            "action='surface_gaps': find a1 entry points missing MCP or CLI coverage. "
            "action='wire_stubs': generate MCP handler + CLI stub + test skeleton for an unwired a1 function. "
            "action='dead_code': find defined-but-unreferenced symbols. "
            "action='maintainability': Maintainability Index per module (A/B/C/D). "
            "action='concept_bridge': synthesis plans from harvest candidates below TAU_TRUST. "
            "action='doc_update': regenerate README/CHANGELOG and extended docs "
            "(IDE_INTEGRATION.md, WHITEPAPER.md, AGENTS_GUIDE.md) from forge_metrics.json — "
            "zero LLM tokens. sections param: comma-separated readme,changelog,extended_docs. "
            "action='doc_drift': detect stale MCP tool/action/test counts across all key doc "
            "files before running doc_update. Returns drift_items list with file+line+found/expected."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["certify", "wire", "enforce", "validate", "guard",
                             "composite", "gate", "health",
                             "check", "score", "tests", "cna", "rollback", "diff",
                             "ast_scope", "surface_gaps", "wire_stubs", "dead_code",
                             "maintainability", "concept_bridge", "auto_wire",
                             "doc_update", "doc_drift"],
                    "description": (
                        "'certify' — quality score; "
                        "'wire' — import violations; "
                        "'enforce' — fix wire violations; "
                        "'validate' — check sidecar TOML; "
                        "'guard' — install enforcement layers; "
                        "'composite' — go/no-go verdict; "
                        "'gate' — LLM hallucination check; "
                        "'health' — env diagnostic; "
                        "'check' — pre-edit guardrail; "
                        "'score' — patch risk scoring; "
                        "'tests' — select affected tests; "
                        "'cna' — Compose-Not-Add dedup check; "
                        "'rollback' — undo plan; "
                        "'diff' — compare two manifests; "
                        "'ast_scope' — AST blueprint + local locks + optional Nexus attestation; "
                        "'dead_code' — unreferenced symbols; "
                        "'maintainability' — MI per module; "
                        "'concept_bridge' — synthesis plans; "
                        "'surface_gaps' — find unwired a1 functions; "
                        "'wire_stubs' — generate MCP+CLI+test stubs; "
                        "'doc_update' — regenerate README/CHANGELOG/extended docs from metrics; "
                        "'doc_drift' — detect stale MCP/test counts across all doc files."
                    ),
                },
                # certify params
                "project_root": {"type": "string"},
                "package": {"type": ["string", "null"]},
                "emit_receipt": {"type": "boolean", "default": False},
                "skip_tests": {"type": "boolean", "default": False,
                                "description": "[certify] Fast structural-only mode."},
                # wire + enforce params
                "source": {"type": "string"},
                "suggest_repairs": {"type": "boolean", "default": False},
                # enforce params
                "apply": {"type": "boolean", "default": False,
                           "description": "[enforce/guard] false=dry-run, true=write."},
                # guard params
                "min_certify_score": {"type": "integer", "default": 90,
                                       "minimum": 0, "maximum": 100,
                                       "description": "[guard] Min certify score threshold."},
                "max_cyclomatic": {"type": "integer", "default": 10, "minimum": 1,
                                    "description": "[guard] Max cyclomatic complexity."},
                "strict_mode": {"type": "boolean", "default": False,
                                 "description": "[guard] Block on ANY score drop."},
                "overwrite": {"type": "boolean", "default": False,
                               "description": "[guard] Overwrite existing guard files."},
                # validate params
                "source_file": {"type": "string",
                                 "description": "[validate] Source file whose sidecar to validate."},
                # composite/score params
                "diff": {"type": "string",
                          "description": "[composite/score] Unified diff (git diff format)."},
                # composite/check/tests params
                "intent": {"type": "string",
                            "description": "[composite/check/tests] Change intent."},
                "proposed_files": {"type": "array", "items": {"type": "string"},
                                    "description": "[composite/check] Files to change."},
                "fail_under": {"type": "number", "default": 75.0,
                                "description": "[composite] Certify score below this → FAIL."},
                # gate params
                "response": {"type": "string",
                              "description": "[gate] LLM response text to check."},
                "known_capabilities": {"type": "array", "items": {"type": "string"},
                                        "description": "[gate] Capability ids the project ships."},
                "local_pkg_prefix": {"type": "string",
                                      "description": "[gate] Dotted prefix for local packages."},
                # check params
                "scope_threshold": {"type": "integer", "default": 8,
                                     "description": "[check] Max files before scope warning."},
                # tests + rollback params
                "changed_files": {"type": "array", "items": {"type": "string"},
                                   "description": "[tests/rollback] Files that were changed."},
                # cna params
                "proposed_name": {"type": "string",
                                   "description": "[cna] Bare or dotted name of the proposed symbol."},
                "proposed_body": {"type": "string",
                                   "description": "[cna] Optional Python source for body-hash overlap."},
                "package_subdir": {"type": "string", "description": "[cna] Package subdirectory."},
                "name_top_n": {"type": "integer", "default": 10,
                                "description": "[cna] Top-N name matches."},
                # diff params
                "left":       {"type": "string",
                                "description": "[diff] First manifest as JSON string."},
                "left_path":  {"type": "string",
                                "description": "[diff] Path to first manifest file."},
                "right":      {"type": "string",
                                "description": "[diff] Second manifest as JSON string."},
                "right_path": {"type": "string",
                                "description": "[diff] Path to second manifest file."},
                # ast_scope params
                "project_roots": {"type": "array", "items": {"type": "string"},
                                  "description": "[ast_scope] One or more repo roots."},
                "targets": {"type": "array", "items": {"type": "string"},
                            "description": "[ast_scope] Full qualnames or suffixes to lock."},
                "agent_ids": {"type": "array", "items": {"type": "string"},
                              "description": "[ast_scope] Agent ids for round-robin locks."},
                "ttl_secs": {"type": "integer", "default": 3600,
                             "description": "[ast_scope] Lock TTL in seconds."},
                "max_nodes": {"type": "integer", "default": 200,
                              "description": "[ast_scope] Maximum AST nodes to include."},
                "attest_nexus": {"type": "boolean", "default": False,
                                 "description": "[ast_scope] Mirror locks to Nexus lineage if configured."},
                "nexus_intent": {"type": "string",
                                 "description": "[ast_scope] Nexus lineage intent."},
                # surface_gaps + wire_stubs params
                "module": {"type": "string",
                            "description": "[wire_stubs] a1 module stem (e.g. 'git_churn')."},
                "function": {"type": "string",
                              "description": "[wire_stubs] Public function name (e.g. 'compute_git_churn')."},
            },
            "required": ["action"],
            "additionalProperties": False,
        },
        "handler": _tool_audit,
    },
    "plan": {
        "name": "plan",
        "description": (
            "Use this when: you need to orient, plan, scaffold, or assemble a commit on a repo. "
            "action='context': first-call context bundle — repo purpose, architecture law, "
            "tier map, blockers, best next action, test commands, policy, workflow_recipe. "
            "action='compose': match a goal keyword to a named workflow recipe. "
            "action='policy': return the raw agent policy dict without full orientation. "
            "action='recipes': list the full recipe catalogue or fetch one named recipe. "
            "action='generate' (default): runs scout+wire+certify, emits ranked agent_plan/v1. "
            "action='apply': executes a saved plan (plan_id required). apply=False dry-runs. "
            "action='locate': returns insertion-point line range + preview (~1000-token saving). "
            "action='commit': assembles structured commit message (~10k-token saving). "
            "action='scaffold': generate a four-piece MCP tool scaffold (a1+a3 inserts, test block) "
            "without mutating files — forge eats forge. "
            "action='steersman': AST-lock decision pack tiny enough for a 1B semantic router. "
            "No LLM client inside forge for scaffold/compose/policy/recipes. "
            "v0.48.0: transmute pipeline (auto/cherry/finalize) moved to `transmute` tool; "
            "LLM loops (iterate/resume/evolve/evolve_step) moved to `loop` tool."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["context", "compose", "policy", "recipes",
                             "generate", "apply", "locate", "commit", "scaffold",
                             "steersman"],
                    "default": "generate",
                    "description": (
                        "'context' — first-call orientation bundle; "
                        "'compose' — workflow recipe for goal; "
                        "'policy' — raw agent policy dict; "
                        "'recipes' — recipe catalogue or named recipe; "
                        "'generate' — create refactor plan; "
                        "'apply' — execute saved plan; "
                        "'locate' — find forge insertion point; "
                        "'commit' — compose commit message; "
                        "'scaffold' — generate MCP tool boilerplate; "
                        "'steersman' — 1B semantic-router decision pack."
                    ),
                },
                # context params
                "focus": {
                    "type": "string",
                    "enum": ["orientation", "change", "release", "debug"],
                    "description": (
                        "[context] Optional mode. 'change' adds file-targeted "
                        "audit/test context; 'release' emphasizes the gate; "
                        "'debug' emphasizes lineage."
                    ),
                },
                "files": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "[context] Target or changed files for focused context.",
                },
                # recipes param
                "name": {
                    "type": "string",
                    "description": (
                        "[recipes] Optional recipe name — omit to list all, "
                        "provide to fetch a single recipe's full body."
                    ),
                },
                # generate params
                "target":   {"type": "string",
                              "description": "[generate/auto/cherry/finalize] Repo path; "
                                             "[context] project path (defaults to project_root)."},
                "goal":     {"type": "string", "default": "improve repo conformance",
                              "description": "[generate] Improvement goal; [compose] recipe matching keyword."},
                "mode":     {"type": "string", "enum": ["improve", "absorb"], "default": "improve"},
                "top_n":    {"type": "integer", "default": 7},
                "save":     {"type": "boolean", "default": False,
                              "description": "[generate] Persist the plan."},
                "capability_filter": {
                    "type": "object",
                    "description": "[generate] Optional adapt_plan filter.",
                },
                # apply params
                "project":  {"type": "string"},
                "plan_id":  {"type": "string", "description": "[apply] Required. Plan to execute."},
                "card_id":  {"type": "string", "description": "[apply] Single-card; omit for all-applyable."},
                # locate params
                "point": {
                    "type": "string",
                    "enum": ["tools_dict", "all_export",
                             "register_block", "mcp_server_imports",
                             "test_pinned_set"],
                    "description": "[locate] Named insertion point.",
                },
                # commit params
                "commit_type": {"type": "string", "default": "ship",
                                 "description": "[commit] Conventional-commit prefix."},
                "body": {"type": "string", "description": "[commit] Optional narrative tail."},
                "include_coauthor": {"type": "boolean", "default": True,
                                      "description": "[commit] Include Co-Authored-By line."},
                # shared planning params
                "intent": {"type": "string",
                            "description": "[context/commit/generate] Intent string."},
                "package": {"type": ["string", "null"],
                             "description": "[generate] Package name."},
                "apply":    {"type": "boolean", "default": False,
                              "description": "[apply] false=dry-run, true=write."},
                # steersman params
                "project_roots": {"type": "array", "items": {"type": "string"},
                                  "description": "[steersman] One or more repo roots."},
                "targets": {"type": "array", "items": {"type": "string"},
                            "description": "[steersman] AST qualnames or suffix targets."},
                "agent_ids": {"type": "array", "items": {"type": "string"},
                              "description": "[steersman] AST lock owners."},
                "max_nodes": {"type": "integer", "default": 200,
                              "description": "[steersman] Max AST nodes in generated scope."},
                "max_questions": {"type": "integer", "default": 24,
                                  "description": "[steersman] Max questions for the 1B router."},
                "run_model": {"type": "boolean", "default": False,
                              "description": "[steersman] Ask provider/model for choices."},
                "provider": {"type": "string", "default": "ollama",
                             "description": "[steersman] Provider used when run_model=true."},
                "model": {"type": "string", "default": "llama3.2:1b",
                          "description": "[steersman] Tiny local model name."},
                "attest_nexus": {"type": "boolean", "default": False,
                                 "description": "[steersman] Mirror AST locks to Nexus if configured."},
                # scaffold (tool_factory) params
                "tool_name": {"type": "string",
                               "description": "[scaffold] snake_case tool name."},
                "use_this_when": {"type": "string",
                                   "description": "[scaffold] One-sentence trigger."},
                "body_description": {"type": "string",
                                      "description": "[scaffold] Tool description body."},
                "input_schema": {"type": "object",
                                  "description": "[scaffold] JSON Schema for new tool."},
                "handler_module": {"type": "string",
                                    "description": "[scaffold] Dotted module path of impl."},
                "handler_callable": {"type": "string",
                                      "description": "[scaffold] Callable name inside handler_module."},
                "create_module": {"type": "boolean", "default": False,
                                   "description": "[scaffold] Emit a starter module template."},
                # shared
                "project_root": {"type": "string"},
            },
            "additionalProperties": False,
        },
        "handler": _tool_plan_merged,
    },
    # context_pack absorbed into plan(context|compose|policy|recipes) in v0.43.0
    # preflight absorbed into audit(check|score|tests|cna|rollback|diff) in v0.42.0
    "wisdom": {
        "name": "wisdom",
        "description": (
            "Use this when: interacting with the repo's institutional wisdom DB "
            "(.atomadic-forge/wisdom.jsonl). "
            "action='record' — append one lesson (insight, scope, tags, evidence, confidence). "
            "action='query' — relevance-rank entries by scope/tags/text; "
            "returns top_n with scores. "
            "action='list' — paginated dump of active entries (limit=20 by default; "
            "limit=0 for full; include_superseded=true for audit). "
            "action='recall' — top-N repo-scoped entries for a new agent (cheapest read path). "
            "action='promote' — cluster corroborated wisdom into draft recipe candidates. "
            "All actions are pure: no LLM."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["record", "query", "list", "recall", "promote"],
                    "description": "record | query | list | recall | promote",
                },
                "insight": {"type": "string",
                             "description": "record: the lesson learned (specific and concrete)"},
                "scope": {"type": "string", "enum": ["repo", "forge", "general"], "default": "repo",
                           "description": "record/query: scope filter"},
                "tags": {"type": "array", "items": {"type": "string"},
                          "description": "record: tag list; query: filter by tags"},
                "evidence": {"type": "array", "items": {"type": "string"},
                              "description": "record: evidence paths (file:line refs)"},
                "confidence": {"type": "number", "minimum": 0, "maximum": 1, "default": 0.5,
                                "description": "record: confidence 0-1"},
                "agent_name": {"type": "string", "default": "anonymous",
                                "description": "record: recording agent name"},
                "session_id": {"type": ["string", "null"], "description": "record: session id"},
                "supersedes": {"type": ["string", "null"],
                                "description": "record: WIS-* id this supersedes"},
                "text": {"type": ["string", "null"],
                          "description": "query: free-text substring match (case-insensitive)"},
                "top_n": {"type": "integer", "default": 5, "minimum": 1, "maximum": 50,
                           "description": "query/recall: max entries to return"},
                "include_superseded": {"type": "boolean", "default": False,
                                        "description": "list: include superseded entries"},
                "limit": {"type": "integer", "default": 20,
                           "description": "list: max entries (0 = all)"},
                "min_corroboration": {"type": "integer", "default": 3, "minimum": 2,
                                       "description": "promote: min entries per cluster"},
                "min_tag_overlap": {"type": "integer", "default": 1, "minimum": 1,
                                     "description": "promote: min tag overlap per cluster"},
                "write": {"type": "boolean", "default": False,
                           "description": "promote: persist draft recipes to disk"},
                "include_bodies": {"type": "boolean", "default": False,
                                    "description": "promote: include full markdown bodies"},
                "project_root": {"type": "string"},
            },
            "required": ["action"],
            "additionalProperties": False,
        },
        "handler": _tool_wisdom,
    },
    "hive": {
        "name": "hive",
        "description": (
            "Use this when: managing the multi-agent hive, coordinating consensus, "
            "or recording agent handoffs and enhancement proposals. "
            "Lifecycle: action='register' — declare an agent's lane (role, capabilities, "
            "write_lanes, subscribes_to), max-depth 23. action='list' — see all agents. "
            "action='deactivate' — graceful shutdown. action='observe' — pull events since cursors. "
            "Consensus: action='propose' — open a cross-agent proposal (returns consensus_id). "
            "action='vote' — cast a vote (approve|reject|refine|abstain). "
            "action='needs_vote' — proposals awaiting your vote. "
            "action='result' — current verdict; record=true freezes it. "
            "action='recap' — full lifecycle of one consensus. "
            "Session: action='handoff_create' — write a structured agent-to-agent transfer; "
            "axiom_guard_status must be PASS|QUARANTINE. action='handoff_list' — recent handoffs. "
            "action='enhance_propose' — record a tool/feature proposal for human review. "
            "action='enhance_list' — read prior proposals. All actions are pure: no LLM."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["register", "list", "deactivate", "observe",
                              "propose", "vote", "needs_vote", "result", "recap",
                              "handoff_create", "handoff_list",
                              "enhance_propose", "enhance_list"],
                    "description": (
                        "Lifecycle: register|list|deactivate|observe. "
                        "Consensus: propose|vote|needs_vote|result|recap. "
                        "Session: handoff_create|handoff_list|enhance_propose|enhance_list."
                    ),
                },
                # lifecycle params
                "agent_name": {"type": "string",
                               "description": "[register/deactivate/observe/needs_vote/handoff] Agent name."},
                "role": {"type": "string",
                         "description": "[register] forge|cognition|doc|research|<custom>"},
                "capabilities": {"type": "array", "items": {"type": "string"}},
                "subscribes_to": {"type": "array", "items": {"type": "string"}},
                "write_lanes": {"type": "array", "items": {"type": "string"}},
                "identity_claim": {"type": ["string", "null"]},
                "notes": {"type": ["string", "null"]},
                "include_deactivated": {"type": "boolean", "default": False},
                "since_consensus_id": {"type": ["string", "null"]},
                "since_wisdom_id": {"type": ["string", "null"]},
                # consensus params
                "intent": {"type": "string", "description": "[propose/enhance_propose] Intent."},
                "proposer": {"type": "string", "description": "[propose] Proposing agent name."},
                "payload": {"type": "object", "description": "[propose] Optional payload."},
                "consensus_id": {"type": "string",
                                  "description": "[vote/result/recap] Target consensus id."},
                "voter": {"type": "string", "description": "[vote] Voting agent name."},
                "vote": {"type": "string", "enum": ["approve", "reject", "refine", "abstain"],
                          "description": "[vote] Vote value."},
                "rationale": {"type": ["string", "null"], "description": "[vote] Optional rationale."},
                "record": {"type": "boolean", "default": False,
                            "description": "[result] Freeze the verdict when true."},
                # handoff params
                "work_completed": {"type": "array", "items": {"type": "string"}},
                "files_modified": {"type": "array", "items": {"type": "string"}},
                "files_created": {"type": "array", "items": {"type": "string"}},
                "test_results": {
                    "type": "object",
                    "properties": {
                        "passed": {"type": "integer", "minimum": 0},
                        "failed": {"type": "integer", "minimum": 0},
                        "skipped": {"type": "integer", "minimum": 0},
                    },
                    "additionalProperties": False,
                },
                "pending_tasks": {"type": "array", "items": {"type": "string"}},
                "key_context": {"type": "string"},
                "warnings": {"type": "array", "items": {"type": "string"}},
                "axiom_guard_status": {
                    "type": "string",
                    "enum": ["PASS", "QUARANTINE"],
                    "default": "PASS",
                },
                "session_id": {"type": ["string", "null"]},
                # enhancement params
                "title": {"type": "string", "description": "[enhance_propose] Proposal title."},
                "description": {"type": "string", "description": "[enhance_propose] Description."},
                "evidence": {"type": "array", "items": {"type": "string"}},
                "trust_threshold": {
                    "type": "number", "minimum": 0.0, "maximum": 1.0, "default": 0.75,
                },
                # shared
                "limit": {"type": "integer", "default": 50, "minimum": 1, "maximum": 500},
                "project_root": {"type": "string"},
            },
            "required": ["action"],
            "additionalProperties": False,
        },
        "handler": _tool_hive,
    },
    "nexus": {
        "name": "nexus",
        "description": (
            "Use this when: calling LIVE AAAA-Nexus primitives. "
            "Requires ATOMADIC_MASTER_KEY or ATOMADIC_SUBSCRIPTION_KEY in env. "
            "op='identity_verify' — verify a DID/identity claim against Nexus. "
            "op='federation_mint' — mint a portable federation token (did, scope, ttl_secs). "
            "op='authorize_action' — gate whether subject can invoke action against resource. "
            "op='sys_trust_gate' — drift/hallucination check on a claim; returns PASS/FAIL. "
            "op='contract_verify' — verify a manifest hasn't drifted since subscription. "
            "op='lineage_record' — attest an intent+payload event to Nexus lineage. "
            "op='ratchet_register' — register a monotonic anti-replay stamp."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "op": {
                    "type": "string",
                    "enum": [
                        "identity_verify", "federation_mint", "authorize_action",
                        "sys_trust_gate", "contract_verify", "lineage_record",
                        "ratchet_register",
                    ],
                    "description": "Nexus primitive to call",
                },
                "identity": {"type": "string",
                              "description": "identity_verify: DID or identity string"},
                "did": {"type": "string",
                         "description": "federation_mint: DID to bind"},
                "scope": {"type": "array", "items": {"type": "string"},
                           "description": "federation_mint: scope list"},
                "ttl_secs": {"type": "integer", "default": 86400, "minimum": 60,
                              "description": "federation_mint: token TTL"},
                "action": {"type": "string",
                            "description": "authorize_action: the Nexus action being authorized"},
                "subject": {"type": "string",
                             "description": "authorize_action/contract_verify/ratchet_register: subject"},
                "resource": {"type": ["string", "null"],
                              "description": "authorize_action: target resource"},
                "claim": {"type": "object",
                           "description": "sys_trust_gate: claim object to evaluate"},
                "manifest_hash": {"type": "string",
                                   "description": "contract_verify: expected manifest hash"},
                "intent": {"type": "string",
                            "description": "lineage_record: intent statement"},
                "payload": {"type": "object",
                             "description": "lineage_record: payload object"},
                "ratchet_id": {"type": "string",
                                "description": "ratchet_register: ratchet identifier"},
                "stamp": {"type": "string",
                           "description": "ratchet_register: monotonic stamp value"},
            },
            "required": ["op"],
            "additionalProperties": False,
        },
        "handler": _tool_nexus,
    },

    # v0.48.0 — flagship transmuter pipeline restored as standalone tool
    "transmute": {
        "name": "transmute",
        "description": (
            "Use this when: absorbing a repo into a tier-organized package or "
            "running the full spaghetti→certified pipeline. This is the FLAGSHIP. "
            "action='auto' (default): single-shot pipeline — scout→cherry→assimilate→"
            "wire→certify→receipt. apply=False is a dry-run that returns the planned "
            "writes; apply=True actually materializes the package. "
            "action='cherry': produces a surgical cherry-pick manifest (cherry.json) "
            "before assimilation — pick=['all'] to take everything, or pass explicit "
            "qualnames to take a subset. "
            "action='finalize': materializes an existing cherry.json into a "
            "tier-organized package; lets you re-run with different selections "
            "without re-scanning. No LLM invoked for any action — pure deterministic "
            "absorption."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["auto", "cherry", "finalize"],
                    "default": "auto",
                    "description": (
                        "'auto' — full pipeline scout→cherry→assimilate→wire→certify; "
                        "'cherry' — produce cherry.json manifest only; "
                        "'finalize' — materialize existing cherry.json into package."
                    ),
                },
                "target": {"type": "string",
                            "description": "Source repo path to absorb from."},
                "output": {"type": "string",
                            "description": "[auto/finalize] Output directory for the new package."},
                "package": {"type": ["string", "null"],
                             "description": "[auto/finalize] Importable package name."},
                "apply": {"type": "boolean", "default": False,
                           "description": "[auto/finalize] false=dry-run, true=write."},
                "on_conflict": {
                    "type": "string",
                    "enum": ["rename", "first", "last", "fail"],
                    "default": "rename",
                    "description": "[auto/finalize] Symbol collision resolution.",
                },
                "pick": {"type": "array", "items": {"type": "string"},
                          "description": "[cherry] Qualnames to pick; ['all']=everything."},
                "pick_all": {"type": "boolean", "default": False,
                              "description": "[cherry] Shortcut for pick=['all']."},
                "only_tier": {"type": "string",
                               "description": "[cherry] Restrict to one tier."},
                "project_root": {"type": "string"},
            },
            "additionalProperties": False,
        },
        "handler": _tool_transmute,
    },

    # v0.48.0 — LLM iteration loops restored as standalone tool
    "loop": {
        "name": "loop",
        "description": (
            "Use this when: driving an LLM-guided iteration session against the repo. "
            "Forge has no embedded LLM — these actions return prompts you feed to your "
            "own LLM, then the response comes back here for the next round. "
            "action='iterate': scaffold a package and emit the first LLM prompt; "
            "returns session_id for resume. "
            "action='resume': feed the LLM's response back; advances the session and "
            "returns either the next prompt or the final result. "
            "action='evolve': start a recursive multi-round session "
            "(rounds, max-depth 23 system cap, stop_on_regression). "
            "action='evolve_step': advance the active evolve round."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["iterate", "resume", "evolve", "evolve_step"],
                    "default": "iterate",
                    "description": (
                        "'iterate' — start a single-round iterate session; "
                        "'resume' — continue with LLM response; "
                        "'evolve' — start a recursive multi-round session; "
                        "'evolve_step' — advance an evolve round."
                    ),
                },
                "intent": {"type": "string",
                            "description": "[iterate/evolve] What you want the LLM to do."},
                "output": {"type": "string",
                            "description": "[iterate/evolve] Output directory."},
                "package": {"type": ["string", "null"],
                             "description": "[iterate/evolve] Package name."},
                "seed_repos": {"type": "array", "items": {"type": "string"},
                                "description": "[iterate/evolve] Seed repo paths."},
                "target_score": {"type": "number", "default": 75.0,
                                  "description": "[iterate/evolve] Target certify score."},
                "max_iterations": {"type": "integer", "default": 5,
                                    "description": "[iterate] Hard cap on resume calls."},
                "language": {
                    "type": "string",
                    "enum": ["python", "javascript", "typescript"],
                    "default": "python",
                    "description": "[iterate/evolve] Target language.",
                },
                "session_id": {"type": "string",
                                "description": "[resume] Session id from iterate call."},
                "response": {"type": "string",
                              "description": "[resume] Raw LLM response text."},
                "rounds": {"type": "integer", "default": 3, "minimum": 1, "maximum": 23,
                            "description": "[evolve] Max rounds; D_max cap=23."},
                "iterations_per_round": {"type": "integer", "default": 4, "minimum": 1,
                                          "description": "[evolve] Iterations per round."},
                "stop_on_regression": {"type": "boolean", "default": False,
                                        "description": "[evolve] Halt if score drops."},
                "stagnation_threshold": {"type": "integer", "default": 3,
                                          "description": "[evolve] Halt after N flat rounds."},
                "evolve_session_id": {"type": "string",
                                       "description": "[evolve_step] Session id from evolve call."},
                "project_root": {"type": "string"},
            },
            "additionalProperties": False,
        },
        "handler": _tool_loop,
    },

    "create": {
        "name": "create",
        "description": (
            "Use this when: you have an INTENT (one-line description of a new "
            "package) plus one or more SEED REPOS to harvest from, and want a "
            "shippable pip-installable package as output. Runs the full Phase 1 "
            "pipeline: emergent_swarm cross-repo composition discovery -> "
            "materialize top-N candidates into a tier-organized package -> "
            "optional certify run on the new package. Returns the create receipt "
            "(intent, seed_repos, scan_summary, materialize report, "
            "scan_report_path). The scan_report_path lets callers re-run "
            "materialize with different selections without re-scanning."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "intent": {"type": "string",
                            "description": "One-line description of the package to assemble."},
                "seed_repos": {"type": "array",
                                "items": {"type": "string"},
                                "description": "Paths to repos to scan as composition sources."},
                "out_dir": {"type": "string",
                             "description": "Where to write the new package (created if missing)."},
                "package": {"type": "string",
                             "description": "Importable name of the new package (Python identifier)."},
                "top_n": {"type": "integer", "default": 5, "minimum": 1, "maximum": 50,
                           "description": "Materialize the top-N candidates (default 5)."},
                "run_certify": {"type": "boolean", "default": True,
                                 "description": "Run certify on the new package after materialize."},
                "swarm_max_depth": {"type": "integer", "default": 3, "minimum": 1, "maximum": 23,
                                     "description": "emergent_swarm max composition depth (cap=23)."},
                "require_pure": {"type": "boolean", "default": False,
                                  "description": "Require pure functions only (no I/O)."},
                "domain_jump_required": {"type": "boolean", "default": True,
                                          "description": "Require cross-domain composition (default true)."},
                "cross_repo_bonus": {"type": "number", "default": 15.0,
                                      "description": "Score bonus for cross-repo compositions."},
                "corroborate_with_call_graph": {"type": "boolean", "default": True,
                                                 "description": "Corroborate candidates via AST call graph."},
                "project_root": {"type": "string"},
            },
            "required": ["intent", "seed_repos", "out_dir", "package"],
            "additionalProperties": False,
        },
        "handler": _tool_create,
    },

    "welcome": {
        "name": "welcome",
        "description": (
            "RECOMMENDED FIRST CALL when an agent connects to Forge in "
            "a new session. Runs scout + certify + wire on the current "
            "repo and returns one structured response: real numbers "
            "(score, violations, symbol count), top 3 strengths, top "
            "3 priorities, the single most-useful next call, a "
            "rendered narrative, an agent_guidance block (briefing for "
            "talking to the human user in the agent's own voice), a "
            "capability_showcase (12 headline tools grouped by job), "
            "and a safety_net (concrete Forge guarantees). Optional "
            "since_receipt path emits a since-last-scan diff (score "
            "delta, violation delta) so returning agents see what "
            "changed. Also useful any time you want a one-shot "
            "situation report mid-session."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "package": {"type": ["string", "null"]},
                "since_receipt": {"type": ["string", "null"]},
                "skip_certify": {"type": "boolean", "default": False},
                "project_root": {"type": "string"},
            },
            "additionalProperties": False,
        },
        "handler": _tool_welcome,
        "recommended_first_call": True,
    },
}

_CLI_FALLBACKS: dict[str, str] = {
    "explore": (
        "forge recon <repo> --json (action=recon) | "
        "forge explain-repo <project-root> (action=explain) | "
        "forge call-graph <qualname> --project-root <repo> --json (action=call_graph) | "
        "forge call-graph-summary --project <repo> --json (action=call_graph_summary) | "
        "forge churn --project <repo> --json (action=churn) | "
        "forge smell-scan --project-root <repo> --json (action=smell_scan) | "
        "forge surface list/show/log (action=lineage)"
    ),
    "audit": (
        "forge certify <project-root> --json (action=certify) | "
        "forge wire <tier-root> --json (action=wire) | "
        "forge enforce <tier-root> [--apply] (action=enforce) | "
        "forge sidecar validate <source-file> --json (action=validate) | "
        "forge guard-install [--min-certify N] [--apply] (action=guard)"
    ),
    # legacy names — kept for _CLI_FALLBACKS consumers that haven't updated
    "recon": "forge recon <repo> --json (action=scan) | forge recon-swarm <repo1> <repo2> --json (action=swarm)",
    "wire": "forge wire <tier-root> --json",
    "certify": "forge certify <project-root> --json",
    "audit_list": "forge audit list --json",
    "plan": (
        "forge plan <repo> --json (action=generate) | "
        "forge plan-apply <plan-id> --project <repo> [--card-id <id>] (action=apply) | "
        "forge locate <point> [--project-root <repo>] (action=locate) | "
        "forge commit-compose --intent '...' --json (action=commit) | "
        "forge iterate run --intent '...' --output <dir> (action=iterate) | "
        "MCP-only: plan(action=resume) | "
        "forge evolve run --intent '...' --output <dir> (action=evolve) | "
        "MCP-only: plan(action=evolve_step) | "
        "forge auto <output> --apply (action=auto) | "
        "forge cherry [--pick ...] (action=cherry) | "
        "forge finalize <output> --apply (action=finalize)"
    ),
    "auto_plan": "forge plan <repo> --json",
    "auto_step": "forge plan-step <plan-id> <card-id> --project <repo>",
    "auto_apply": "forge plan-apply <plan-id> --project <repo>",
    # legacy names — context_pack absorbed into plan in v0.43.0
    "context_pack": (
        "forge context-pack <project-root> [--focus change --intent <intent> --file <path>] --json "
        "— use plan(action=context) via MCP | "
        "forge compose-tools <goal> — use plan(action=compose) via MCP | "
        "forge load-policy <project-root> — use plan(action=policy) via MCP | "
        "forge recipes [<name>] --json — use plan(action=recipes) via MCP"
    ),
    # legacy names — preflight absorbed into audit in v0.42.0
    "preflight": (
        "forge preflight <intent> <file...> --project <repo> --json — use audit(action=check) via MCP | "
        "git diff | forge score-patch --project-root <repo> — use audit(action=score) via MCP | "
        "forge select-tests --file <path> --project-root <repo> <intent> — use audit(action=tests) via MCP | "
        "forge rollback-plan --file <path> --project-root <repo> — use audit(action=rollback) via MCP | "
        "forge diff <left.json> <right.json> --json — use audit(action=diff) via MCP"
    ),
    "change_review": (
        "forge rollback-plan --file <path> --project-root <repo> (action=rollback) | "
        "forge diff <left.json> <right.json> --json (action=diff) — "
        "use preflight(action=rollback|diff) via MCP"
    ),
    "adapt_plan": "forge adapt-plan --file <plan.json>",
    "workflow": (
        "forge compose-tools <goal> — use plan(action=compose) via MCP | "
        "forge load-policy <project-root> — use plan(action=policy) via MCP | "
        "forge recipes [<name>] --json — use plan(action=recipes) via MCP"
    ),
    "why_did_this_change": "forge why-did-this-change <file> --project-root <repo>",
    "what_failed_last_time": "forge what-failed-last-time <area> --project-root <repo>",
    "list_recipes": "forge recipes --json",
    "get_recipe": "forge recipes <name> --json",
    # legacy names — verify absorbed into audit in v0.40.0
    "verify": (
        "forge verify <project-root> --json — use audit(action=composite) via MCP | "
        "forge trust-gate [--file <response.txt>] [--json] — use audit(action=gate) via MCP | "
        "forge doctor --json — use audit(action=health) via MCP"
    ),
    "recipes": "forge recipes [<name>] --json — use workflow(action=recipes) via MCP",
    "doctor": "forge doctor --json — use audit(action=health) via MCP",
    "enforce": "forge enforce <tier-root> [--apply] — use audit(action=enforce) via MCP",
    "worktree_status": "forge worktree status <project-root> --json",
    "trust_gate_response": "forge trust-gate [--file <response.txt>] [--json] — use audit(action=gate) via MCP",
    "exported_api_check": "MCP-only: exported_api_check",
    "emergent": (
        "forge emergent scan <repo> --json — use explore(action=scan) via MCP | "
        "forge emergent swarm --json — use explore(action=swarm) via MCP"
    ),
    "code_intel": (
        "forge call-graph <qualname> --project-root <repo> --json — use explore(action=call_graph) via MCP | "
        "forge call-graph-summary --project <repo> --json — use explore(action=call_graph_summary) via MCP | "
        "forge churn --project <repo> --json — use explore(action=churn) via MCP | "
        "forge smell-scan --project-root <repo> --json — use explore(action=smell_scan) via MCP"
    ),
    "forge_util": (
        "forge locate <point> [--project-root <repo>] — use plan(action=locate) via MCP | "
        "forge commit-compose --intent '...' --json — use plan(action=commit) via MCP"
    ),
    # legacy names — discover absorbed into explore in v0.41.0
    "discover": (
        "forge harvest --target <repo> --source <repo> [--only-gated] --json — use explore(action=harvest) via MCP | "
        "forge synergy scan <repo> --json — use explore(action=synergy) via MCP | "
        "forge emergent scan <repo> --json — use explore(action=scan) via MCP | "
        "forge emergent swarm --json — use explore(action=swarm) via MCP"
    ),
    # legacy names — kept for consumers that haven't updated
    "maintain": (
        "forge sidecar validate <source-file> --json — use audit(action=validate) via MCP | "
        "forge guard-install [--min-certify N] [--apply] — use audit(action=guard) via MCP"
    ),
    # legacy names — tool_factory absorbed into plan(action=scaffold) in v0.41.0
    "tool_factory": "MCP-only: tool_factory — use plan(action=scaffold) via MCP",
    "lineage": "forge surface list/show/log — use explore(action=lineage) via MCP",
    "hive": (
        "forge hive register --agent-name <name> --role <role> --json (action=register) | "
        "forge hive list --json (action=list) | "
        "forge hive deactivate --agent-name <name> --json (action=deactivate) | "
        "forge hive observe --agent-name <name> --json (action=observe) | "
        "forge hive propose --proposer <name> --intent '...' --json (action=propose) | "
        "forge hive vote --consensus-id <id> --voter <name> --vote approve --json (action=vote) | "
        "forge hive needs-vote --agent-name <name> --json (action=needs_vote) | "
        "forge hive result --consensus-id <id> [--record] --json (action=result) | "
        "forge hive recap --consensus-id <id> --json (action=recap) | "
        "forge handoff create [...] --json (action=handoff_create) | "
        "forge handoff list [--limit N] --json (action=handoff_list) | "
        "forge enhancement propose --title '...' --description '...' --json (action=enhance_propose) | "
        "forge enhancement list [--limit N] --json (action=enhance_list)"
    ),
    # legacy names — session absorbed into hive in v0.38.0
    "session": (
        "forge handoff create [...] --json — use hive(action=handoff_create) via MCP | "
        "forge enhancement propose [...] --json — use hive(action=enhance_propose) via MCP"
    ),
    # legacy names — kept for consumers that haven't updated
    "iterate": (
        "forge iterate run --intent '...' --output <dir> (action=start, CLI drives own LLM) | "
        "MCP-only: loop(action=resume)"
    ),
    "evolve": (
        "forge evolve run --intent '...' --output <dir> (action=start) | "
        "MCP-only: loop(action=evolve_step)"
    ),
    "hive_agent": (
        "forge hive register --agent-name <name> --role <role> --json  "
        "| forge hive list --json  "
        "| forge hive deactivate --agent-name <name> --json  "
        "| forge hive observe --agent-name <name> --json"
    ),
    "hive_consensus": (
        "forge hive propose --proposer <name> --intent '...' --json  "
        "| forge hive vote --consensus-id <id> --voter <name> --vote approve --json  "
        "| forge hive needs-vote --agent-name <name> --json  "
        "| forge hive result --consensus-id <id> [--record] --json  "
        "| forge hive recap --consensus-id <id> --json"
    ),
    "handoff": (
        "forge handoff create [...] --json (action=handoff_create) | "
        "forge handoff list [--limit N] --json (action=handoff_list)"
    ),
    "enhancement": (
        "forge enhancement propose --title '...' --description '...' --json (action=enhance_propose) | "
        "forge enhancement list [--limit N] --json (action=enhance_list)"
    ),
    "create": (
        "forge create --intent <intent> --seed-repo <path> [--seed-repo <path>] "
        "--out-dir <path> --package <name> [--top-n N] [--no-certify]"
    ),
    "transmute": (
        "forge auto --target <repo> --output <dir> --package <name> [--apply] (action=auto) | "
        "forge cherry --target <repo> --output <dir> --package <name> [--pick all] (action=cherry) | "
        "forge finalize --output <dir> --package <name> [--apply] (action=finalize)"
    ),
    "loop": (
        "forge iterate --intent <intent> --package <name> [--language python|javascript|typescript] (action=iterate) | "
        "forge iterate --session-id <id> --response <text> (action=resume) | "
        "forge evolve --intent <intent> --rounds N (action=evolve) | "
        "forge evolve --evolve-session-id <id> (action=evolve_step)"
    ),
    "wisdom": (
        "forge wisdom record --insight '...' [--scope repo] --json (action=record) | "
        "forge wisdom query [--text '...'] [--tags t1 t2] --json (action=query) | "
        "forge wisdom list [--limit N] --json (action=list) | "
        "forge wisdom recall [--top-n N] --json (action=recall) | "
        "forge wisdom promote [--write] --json (action=promote)"
    ),
    "nexus": "MCP-only: nexus(op=identity_verify|federation_mint|authorize_action|sys_trust_gate|contract_verify|lineage_record|ratchet_register)",
}


# --- Resource registry ---------------------------------------------------

ResourceLoader = Callable[[Path], str]


def _resource_doc_receipt(project_root: Path) -> str:
    return _read_repo_doc(project_root, "docs/RECEIPT.md")


def _resource_doc_formalization(project_root: Path) -> str:
    return _read_repo_doc(project_root, "docs/FORMALIZATION.md")


def _resource_lineage(project_root: Path) -> str:
    entries = read_lineage(project_root)
    return json.dumps({
        "schema_version": "atomadic-forge.audit.log/v1",
        "project": str(project_root),
        "entry_count": len(entries),
        "entries": entries,
    }, indent=2)


def _resource_schema(project_root: Path) -> str:
    return json.dumps({
        "schema_version": SCHEMA_VERSION_V1,
        "doc": "see forge://docs/receipt for the full v1 schema",
        "valid_verdicts": ["PASS", "FAIL", "REFINE", "QUARANTINE"],
    }, indent=2)


def _resource_summary_blockers(project_root: Path) -> str:
    """Single-call 'what's blocking release?' — runs wire + certify
    and returns the compact summary. Codex feedback: this is the
    resource agents should hit FIRST on every connect."""
    try:
        wire = scan_violations(project_root)
    except (OSError, ValueError):
        wire = None
    try:
        cert = certify(project_root, project=project_root.name)
    except (OSError, ValueError, RuntimeError):
        cert = None
    s = summarize_blockers(
        wire_report=wire, certify_report=cert,
        package_root=project_root.name,
    )
    return json.dumps(s, indent=2, default=str)


def _read_repo_doc(project_root: Path, rel: str) -> str:
    """Read a doc that lives in this Forge install's repo, not the
    consuming project. Falls back to '(not available)' when missing."""
    candidate = Path(__file__).resolve().parents[3] / rel
    if not candidate.exists():
        candidate = Path(project_root) / rel
    try:
        return candidate.read_text(encoding="utf-8")
    except OSError:
        return f"(resource {rel!r} not available in this install)"


RESOURCES: dict[str, dict[str, Any]] = {
    "forge://docs/receipt": {
        "uri": "forge://docs/receipt",
        "name": "Forge Receipt v1 wire-format docs",
        "mimeType": "text/markdown",
        "loader": _resource_doc_receipt,
    },
    "forge://docs/formalization": {
        "uri": "forge://docs/formalization",
        "name": "AAM v1.0 + BEP v1.0 theorem citations for Forge gates",
        "mimeType": "text/markdown",
        "loader": _resource_doc_formalization,
    },
    "forge://lineage/chain": {
        "uri": "forge://lineage/chain",
        "name": "Local Vanguard lineage chain (chronological JSONL)",
        "mimeType": "application/json",
        "loader": _resource_lineage,
    },
    "forge://schema/receipt": {
        "uri": "forge://schema/receipt",
        "name": "Receipt v1 schema sketch (verdicts + version constants)",
        "mimeType": "application/json",
        "loader": _resource_schema,
    },
    "forge://summary/blockers": {
        "uri": "forge://summary/blockers",
        "name": "Top-5 blockers (Codex feedback): wire + certify in one call",
        "mimeType": "application/json",
        "loader": _resource_summary_blockers,
    },
}


# --- Dispatch ------------------------------------------------------------

def _ok(msg_id: Any, result: Any) -> dict[str, Any]:
    return {"jsonrpc": _JSON_RPC_VERSION, "id": msg_id, "result": result}


def _err(msg_id: Any, code: int, message: str,
          data: Any | None = None) -> dict[str, Any]:
    error: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        error["data"] = data
    return {"jsonrpc": _JSON_RPC_VERSION, "id": msg_id, "error": error}


def _summary_for_tool(name: str, result: Any) -> dict[str, Any] | None:
    """Compute the agent-native summary for a tool result, when applicable.

    Codex feedback: agents thrive on 'here are the 2 things blocking
    release' more than huge manifests. We compute a top-5 summary
    inline so MCP clients can branch on a 4-line response instead of
    parsing kilobytes of JSON.
    """
    if not isinstance(result, dict):
        return None
    schema = result.get("schema_version", "")
    if schema == "atomadic-forge.wire/v1":
        return summarize_blockers(wire_report=result)
    if schema == "atomadic-forge.certify/v1":
        return summarize_blockers(certify_report=result)
    if name == "certify" and isinstance(result.get("receipt"), dict):
        # The certify-with-emit_receipt path returns a wrapped dict.
        return summarize_blockers(certify_report=result.get("certify"))
    if schema == "atomadic-forge.context_pack/v1":
        # Re-surface the embedded blockers_summary.
        return result.get("blockers_summary")
    if schema == "atomadic-forge.preflight/v1":
        too_broad = result.get("write_scope_too_broad", False)
        n = result.get("write_scope_size", 0)
        return {
            "schema_version": "atomadic-forge.summary/v1",
            "verdict": "REFINE" if too_broad else "PASS",
            "score": None,
            "blocker_count": len(result.get("overall_notes") or []),
            "auto_fixable_count": 0,
            "blockers": [],
            "next_command": (
                f"# write_scope size {n} > threshold; split the change"
                if too_broad
                else "# preflight clean; proceed with bounded edit"
            ),
        }
    if schema == "atomadic-forge.patch_score/v1":
        return {
            "schema_version": "atomadic-forge.summary/v1",
            "verdict": "REFINE" if result.get("needs_human_review") else "PASS",
            "score": None,
            "blocker_count": (
                int(result.get("architectural_risk", False))
                + int(result.get("test_risk", False))
                + int(result.get("public_api_risk", False))
                + int(result.get("release_risk", False))
            ),
            "auto_fixable_count": 0,
            "blockers": [],
            "next_command": (
                "# needs_human_review=True — block auto-merge"
                if result.get("needs_human_review")
                else "# score_patch clean; proceed with merge"
            ),
        }
    if schema == "atomadic-forge.agent_plan/v1":
        # Plans already ARE summary-shaped — surface a tiny digest
        # so MCP clients can branch without re-parsing the full plan.
        # Codex feedback (round 3): the plan now carries a 'score'
        # field; inherit it so MCP _summary matches forge://summary/blockers.
        return {
            "schema_version": "atomadic-forge.summary/v1",
            "verdict": result.get("verdict", "?"),
            "score": result.get("score"),
            "blocker_count": result.get("action_count", 0),
            "auto_fixable_count": result.get("applyable_count", 0),
            "blockers": [],
            "next_command": result.get("next_command", ""),
        }
    return None


def _serialize_result(value: Any, *, name: str = "") -> dict[str, Any]:
    """Wrap a tool result in MCP's ``content`` envelope so coding-agent
    clients see a uniform shape (text + parsed JSON).

    When we can derive an agent-native summary, prepend it as a SECOND
    text block so a sloppy client reading only ``content[0]`` still
    gets the full payload (back-compat) while a smart client can read
    ``content[1]`` for the compact form. Both are valid MCP shapes.
    """
    full = json.dumps(value, indent=2, default=_json_default)
    blocks: list[dict[str, Any]] = [{"type": "text", "text": full}]
    summary = _summary_for_tool(name, value) if name else None
    if summary is not None:
        blocks.append({
            "type": "text",
            "text": "_summary:\n" + json.dumps(summary, indent=2, default=_json_default),
        })
    return {"content": blocks, "_summary": summary}


def _list_tools() -> dict[str, Any]:
    server_source_path = str(Path(__file__).resolve())
    # Surface the single tool the server recommends as the first call
    # in any new session. MCP clients that read this hint can prompt
    # their agent to start there.
    first_call = next(
        (t["name"] for t in TOOLS.values()
         if t.get("recommended_first_call")),
        None,
    )
    return {
        "serverInfo": {
            "name": SERVER_NAME,
            "version": __version__,
            "source_path": server_source_path,
            "python_executable": sys.executable,
            "recommended_first_call": first_call,
        },
        "tools": [
            {"name": t["name"],
             "description": t["description"],
             "inputSchema": t["inputSchema"],
             "cli_command": _CLI_FALLBACKS.get(t["name"], ""),
             "forge_version": __version__,
             "server_source_path": server_source_path,
             "recommended_first_call": bool(t.get("recommended_first_call", False))}
            for t in TOOLS.values()
        ],
    }


def _list_resources() -> dict[str, Any]:
    return {
        "resources": [
            {"uri": r["uri"], "name": r["name"], "mimeType": r["mimeType"]}
            for r in RESOURCES.values()
        ],
    }


def _initialize_response() -> dict[str, Any]:
    return {
        "protocolVersion": PROTOCOL_VERSION,
        "serverInfo": {
            "name": SERVER_NAME,
            "version": __version__,
        },
        "capabilities": {
            "tools": {"listChanged": False},
            "resources": {"subscribe": False, "listChanged": False},
        },
    }


def dispatch_request(
    request: dict[str, Any],
    *,
    project_root: Path,
) -> dict[str, Any] | None:
    """Route one JSON-RPC request to its handler and return the response.

    Returns ``None`` for valid notifications (no ``id`` field) — the
    transport must NOT write a response in that case.
    """
    if not isinstance(request, dict):
        return _err(None, _ERR_INVALID_REQUEST, "request must be a JSON object")
    method = request.get("method")
    if not isinstance(method, str):
        return _err(request.get("id"), _ERR_INVALID_REQUEST,
                     "request missing string `method`")
    msg_id = request.get("id")
    is_notification = "id" not in request
    params = request.get("params") or {}

    if method == "initialize":
        return _ok(msg_id, _initialize_response())
    if method == "ping":
        return _ok(msg_id, {})
    if method in {"notifications/initialized", "initialized"}:
        return None  # client → server; server replies nothing
    if method == "tools/list":
        return _ok(msg_id, _list_tools())
    if method == "resources/list":
        return _ok(msg_id, _list_resources())
    if method == "tools/call":
        if is_notification:
            return None
        name = params.get("name")
        args = params.get("arguments") or {}
        if not isinstance(name, str) or name not in TOOLS:
            return _err(msg_id, _ERR_METHOD_NOT_FOUND,
                         f"unknown tool: {name!r}")
        try:
            result = TOOLS[name]["handler"](project_root, args)
        except Exception as exc:  # noqa: BLE001 — substrate must not crash on per-request errors
            # Per the module docstring contract: errors in tool dispatch
            # are surfaced as JSON-RPC error responses, never as
            # transport-level failures. Catching the broad ``Exception``
            # here is intentional — a narrow tuple (ValueError/OSError/
            # RuntimeError) used to leak ``TypeError`` and friends from
            # signature drift, killing the stdio loop with the dreaded
            # ``-32000 Connection closed`` error class.
            return _err(msg_id, _ERR_SERVER,
                         f"{type(exc).__name__}: {exc}")
        return _ok(msg_id, _serialize_result(result, name=name))
    if method == "resources/read":
        if is_notification:
            return None
        uri = params.get("uri")
        if uri not in RESOURCES:
            return _err(msg_id, _ERR_INVALID_PARAMS,
                         f"unknown resource: {uri!r}")
        loader = RESOURCES[uri]["loader"]
        try:
            text = loader(project_root)
        except OSError as exc:
            return _err(msg_id, _ERR_SERVER,
                         f"could not read resource: {exc}")
        return _ok(msg_id, {
            "contents": [{
                "uri": uri,
                "mimeType": RESOURCES[uri]["mimeType"],
                "text": text,
            }],
        })

    return _err(msg_id, _ERR_METHOD_NOT_FOUND,
                 f"unknown method: {method!r}")


__all__ = [
    "PROTOCOL_VERSION",
    "RESOURCES",
    "SERVER_NAME",
    "TOOLS",
    "_json_default",
    "dispatch_request",
    "register_auto_handler",
    "register_ast_scope_attest_handler",
    "register_cherry_handler",
    "register_harvest_handler",
    "register_emergent_scan_handler",
    "register_evolve_start_handler",
    "register_evolve_step_handler",
    "register_finalize_handler",
    "register_iterate_continue_handler",
    "register_iterate_start_handler",
    "register_recon_swarm_handler",
    "register_cna_check_handler",
    "register_commit_compose_handler",
    "register_emergent_swarm_handler",
    "register_guard_install_handler",
    "register_synergy_scan_handler",
    "register_tool_factory_handler",
    "register_verify_handler",
    "register_wisdom_list_handler",
    "register_wisdom_promote_handler",
    "register_wisdom_query_handler",
    "register_wisdom_recall_handler",
    "register_wisdom_record_handler",
    "register_hive_register_handler",
    "register_hive_list_handler",
    "register_hive_deactivate_handler",
    "register_hive_observe_handler",
    "register_hive_propose_handler",
    "register_hive_vote_handler",
    "register_hive_result_handler",
    "register_hive_needs_vote_handler",
    "register_hive_recap_handler",
    "register_nexus_identity_verify_handler",
    "register_nexus_federation_mint_handler",
    "register_nexus_authorize_action_handler",
    "register_nexus_sys_trust_gate_handler",
    "register_nexus_contract_verify_handler",
    "register_nexus_lineage_record_handler",
    "register_nexus_ratchet_register_handler",
    "register_steersman_run_handler",
    "register_handoff_create_handler",
    "register_handoff_list_handler",
    "register_enhancement_propose_handler",
    "register_enhancement_list_handler",
    "register_welcome_handler",
    # Lane B Studio's Topology Map renders against these helpers.
    "canonical_receipt_hash",
    "verify_chain_link",
]
