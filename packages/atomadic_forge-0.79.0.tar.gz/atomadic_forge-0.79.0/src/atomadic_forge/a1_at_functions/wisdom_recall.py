"""Tier a1 — relevance ranking for wisdom recall.

Pure scoring. Given a set of active wisdom entries and a query
(scope + tags + free-text), return the top-N by relevance. No LLM —
deterministic, fast, explainable.

The scoring formula is intentionally simple and tunable in one
place. If it ever needs to be smarter, swap this module — every
caller goes through ``rank_for_recall``.
"""
from __future__ import annotations

from typing import Any

from ..a0_qk_constants.wisdom_constants import (
    DEFAULT_RECALL_TOP_N,
    SCHEMA_VERSION_WISDOM_RECALL_V1,
)

# ── Relevance scoring weights ─────────────────────────────────────
# Higher = more weight in the final ranking. Adjust here, not at
# call sites. Calibrated so a perfect-tag-match wisdom entry on a
# scoped recall always outranks a generic high-confidence entry.
W_SCOPE_MATCH = 30.0       # scope == query.scope
W_REPO_SCOPE = 20.0        # entry.scope == "repo" matches when query is repo-specific
W_TAG_OVERLAP_PER = 8.0    # per matching tag
W_TEXT_CONTAINS = 15.0     # query free-text appears in insight (case-insensitive)
W_CONFIDENCE = 20.0        # multiplied by entry.confidence (so 0.9 conf → 18 pts)
W_RECENT_PER_DAY = -0.05   # per day of age (gentle decay, not a cliff)


def _score_entry(
    entry: dict[str, Any],
    *,
    query_scope: str | None,
    query_tags: list[str],
    query_text: str | None,
    age_days: float,
) -> float:
    """Pure: compute a relevance score for one entry against a query."""
    score = 0.0
    e_scope = entry.get("scope", "")
    e_tags = set(entry.get("tags", []))

    if query_scope and e_scope == query_scope:
        score += W_SCOPE_MATCH
    if query_scope == "repo" and e_scope == "repo":
        score += W_REPO_SCOPE

    if query_tags:
        overlap = e_tags & set(query_tags)
        score += W_TAG_OVERLAP_PER * len(overlap)

    if query_text:
        haystack = (entry.get("insight", "") or "").lower()
        if query_text.lower() in haystack:
            score += W_TEXT_CONTAINS

    score += W_CONFIDENCE * float(entry.get("confidence", 0.0))
    score += W_RECENT_PER_DAY * age_days

    return round(score, 3)


def _age_days(timestamp: str) -> float:
    """Best-effort age in days for a UTC ISO timestamp; defaults to 0."""
    from datetime import datetime, timezone
    try:
        ts = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%SZ").replace(
            tzinfo=timezone.utc
        )
        delta = datetime.now(timezone.utc) - ts
        return max(0.0, delta.total_seconds() / 86400.0)
    except (ValueError, TypeError):
        return 0.0


def rank_for_recall(
    entries: list[dict[str, Any]],
    *,
    scope: str | None = None,
    tags: list[str] | None = None,
    text: str | None = None,
    top_n: int = DEFAULT_RECALL_TOP_N,
) -> dict[str, Any]:
    """Rank wisdom entries by relevance to a query.

    Returns a recall report (schema_versioned) with the top-N
    entries plus a brief query summary.
    """
    scored = []
    for e in entries:
        s = _score_entry(
            e,
            query_scope=scope,
            query_tags=tags or [],
            query_text=text,
            age_days=_age_days(e.get("timestamp_utc", "")),
        )
        scored.append((s, e))
    scored.sort(key=lambda pair: -pair[0])
    selected = [
        {**e, "_relevance_score": s}
        for s, e in scored[:top_n]
    ]
    return {
        "schema_version": SCHEMA_VERSION_WISDOM_RECALL_V1,
        "query": {"scope": scope, "tags": tags or [], "text": text},
        "total_entries_considered": len(entries),
        "results_returned": len(selected),
        "top_entries": selected,
    }
