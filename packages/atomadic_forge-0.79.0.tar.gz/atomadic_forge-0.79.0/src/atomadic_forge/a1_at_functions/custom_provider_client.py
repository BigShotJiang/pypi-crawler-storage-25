"""Tier a1 — generic OpenAI-compatible LLM client + per-provider presets.

Most modern LLM providers (OpenAI, OpenRouter, DeepSeek, Groq, Together,
Fireworks, xAI Grok, Mistral La Plateforme, Cohere via /v1, Perplexity,
Cerebras, SambaNova, Hyperbolic, etc.) speak OpenAI's chat-completions
schema.  One generic client + a base-URL + an env-var name covers all of
them.

This module exists so users can wire ANY OpenAI-compatible provider to
Forge without writing Python — they just declare it in ``config.json``::

    {
      "provider": "deepseek",
      "custom_providers": [
        {
          "name": "deepseek",
          "base_url": "https://api.deepseek.com/v1",
          "model": "deepseek-chat",
          "api_key_env": "DEEPSEEK_API_KEY",
          "format": "openai"
        }
      ]
    }

The :class:`CustomProviderClient` honours the same ``LLMClient`` Protocol
(``call(prompt, system, max_tokens, temperature) -> str``) as the
hardcoded clients in :mod:`llm_client`, so resolver code, the iterate
loop, and tests treat it identically.

The ``format`` field controls which wire format the request body uses.
Today: ``"openai"`` (the default — chat-completions schema).  Adding
``"anthropic"`` / ``"gemini"`` / ``"ollama"`` is a matter of adding
another branch in :meth:`CustomProviderClient.call`.

Pure: no I/O at construction time; the network call only fires inside
``call()``.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Final

# ── built-in presets for popular providers ──────────────────────────
#
# Drop one of these names into ``custom_providers[].preset`` and the
# remaining fields fill in.  Users override anything they need.
#
# Format is always "openai" for these — they all speak chat/completions.
# Add a new provider by adding one line.

PRESETS: Final[dict[str, dict[str, str]]] = {
    "openai": {
        "base_url": "https://api.openai.com/v1",
        "model": "gpt-4o-mini",
        "api_key_env": "OPENAI_API_KEY",
    },
    "openrouter": {
        "base_url": "https://openrouter.ai/api/v1",
        "model": "openai/gpt-4o-mini",
        "api_key_env": "OPENROUTER_API_KEY",
    },
    "deepseek": {
        "base_url": "https://api.deepseek.com/v1",
        "model": "deepseek-chat",
        "api_key_env": "DEEPSEEK_API_KEY",
    },
    "groq": {
        "base_url": "https://api.groq.com/openai/v1",
        "model": "llama-3.3-70b-versatile",
        "api_key_env": "GROQ_API_KEY",
    },
    "together": {
        "base_url": "https://api.together.xyz/v1",
        "model": "meta-llama/Llama-3.3-70B-Instruct-Turbo",
        "api_key_env": "TOGETHER_API_KEY",
    },
    "fireworks": {
        "base_url": "https://api.fireworks.ai/inference/v1",
        "model": "accounts/fireworks/models/llama-v3p3-70b-instruct",
        "api_key_env": "FIREWORKS_API_KEY",
    },
    "xai": {
        "base_url": "https://api.x.ai/v1",
        "model": "grok-2-latest",
        "api_key_env": "XAI_API_KEY",
    },
    "mistral": {
        "base_url": "https://api.mistral.ai/v1",
        "model": "mistral-large-latest",
        "api_key_env": "MISTRAL_API_KEY",
    },
    "perplexity": {
        "base_url": "https://api.perplexity.ai",
        "model": "sonar-pro",
        "api_key_env": "PERPLEXITY_API_KEY",
    },
    "cerebras": {
        "base_url": "https://api.cerebras.ai/v1",
        "model": "llama3.3-70b",
        "api_key_env": "CEREBRAS_API_KEY",
    },
    "hyperbolic": {
        "base_url": "https://api.hyperbolic.xyz/v1",
        "model": "meta-llama/Llama-3.3-70B-Instruct",
        "api_key_env": "HYPERBOLIC_API_KEY",
    },
}


def list_presets() -> list[str]:
    """Return preset names sorted alphabetically."""
    return sorted(PRESETS)


def resolve_preset(name: str) -> dict[str, str] | None:
    """Return preset dict for a provider name, or None if unknown."""
    return PRESETS.get(name.lower())


# ── generic client ──────────────────────────────────────────────────


class CustomProviderClient:
    """Generic OpenAI-compatible client driven by config-supplied URL/model/key.

    Honours the same ``call(prompt, system, max_tokens, temperature) -> str``
    contract as :class:`OpenAIClient` etc.  The ``format`` argument
    controls which wire format the request body uses; today only
    ``"openai"`` (chat/completions) is implemented — extending to
    Anthropic Messages or Gemini generateContent is a small diff.

    Construction is cheap (no network); the API call only fires inside
    :meth:`call`.

    Optional ``extra_headers`` lets the user attach provider-specific
    headers (e.g. OpenRouter wants ``HTTP-Referer`` + ``X-Title``).

    The ``api_key_env`` is resolved at call time, not at construction —
    so ``forge config provider add`` writes the env-var name, and the
    user can rotate the key by setting the env var without re-saving
    config.
    """

    def __init__(self, *, name: str, base_url: str, model: str,
                 api_key_env: str,
                 fmt: str = "openai",
                 extra_headers: dict[str, str] | None = None,
                 timeout_s: float = 120.0):
        self.name = name
        self.base_url = base_url.rstrip("/")
        self.model = model
        self._api_key_env = api_key_env
        self.fmt = fmt.lower()
        self.extra_headers = dict(extra_headers or {})
        self.timeout_s = timeout_s
        if self.fmt not in {"openai"}:
            # Forward-compat: accept the field, raise only when called so
            # config-time errors don't trip on a future format name.
            pass

    def call(self, prompt: str, *, system: str = "",
             max_tokens: int = 4096, temperature: float = 0.2) -> str:
        api_key = os.environ.get(self._api_key_env, "")
        if not api_key:
            raise RuntimeError(
                f"{self._api_key_env} not set — cannot call {self.name!r}. "
                f"Run `forge config provider list` to see configured "
                f"providers, or `export {self._api_key_env}=…`."
            )
        if self.fmt != "openai":
            raise RuntimeError(
                f"format={self.fmt!r} not yet supported by "
                "CustomProviderClient — only 'openai' (chat/completions) "
                "is implemented today."
            )
        endpoint = f"{self.base_url}/chat/completions"
        messages: list[dict[str, str]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        body = json.dumps({
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": messages,
        }).encode("utf-8")
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        headers.update(self.extra_headers)
        req = urllib.request.Request(
            endpoint, data=body, headers=headers, method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout_s) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")[:500]
            raise RuntimeError(
                f"{self.name} API error {exc.code}: {detail}"
            ) from exc
        choices = data.get("choices") or []
        if not choices:
            return ""
        return choices[0].get("message", {}).get("content", "") or ""


def from_config(entry: dict) -> CustomProviderClient:
    """Build a :class:`CustomProviderClient` from a ``custom_providers`` entry.

    Accepts shape::

        {
          "name": "deepseek",
          "preset": "deepseek",       # optional — fills missing fields
          "base_url": "...",          # required (or via preset)
          "model": "...",             # required (or via preset)
          "api_key_env": "...",       # required (or via preset)
          "format": "openai",         # default openai
          "extra_headers": {...},     # optional
          "timeout_s": 120            # optional
        }

    Raises ``ValueError`` if required fields are missing after merging
    the preset.
    """
    cfg = dict(entry)
    preset_name = cfg.pop("preset", None)
    if preset_name:
        preset = resolve_preset(preset_name)
        if preset is None:
            raise ValueError(
                f"unknown preset {preset_name!r} — known presets: "
                f"{list_presets()}"
            )
        # User-supplied fields win over preset defaults.
        for k, v in preset.items():
            cfg.setdefault(k, v)
    name = cfg.get("name") or preset_name or "custom"
    for required in ("base_url", "model", "api_key_env"):
        if not cfg.get(required):
            raise ValueError(
                f"custom provider {name!r}: required field {required!r} "
                "missing (and not provided by preset)"
            )
    return CustomProviderClient(
        name=name,
        base_url=cfg["base_url"],
        model=cfg["model"],
        api_key_env=cfg["api_key_env"],
        fmt=cfg.get("format", "openai"),
        extra_headers=cfg.get("extra_headers"),
        timeout_s=float(cfg.get("timeout_s", 120.0)),
    )
