"""Tier a1 — git churn analysis: file-level commit frequency from git log.

Synthesized from Repomix's ``calculateGitLogMetrics`` concept.  Forge's
recon already captures static structure (symbol counts, complexity).
Git churn adds a **temporal quality axis**: which files change most
often, how recently, and how stable the codebase is over time.

Pure in the Forge sense: read-only subprocess calls to ``git log``,
no writes, no state mutation.  Returns ``None`` if the repo has no git
history or git is unavailable — callers degrade gracefully.
"""
from __future__ import annotations

import subprocess
from collections import defaultdict
from pathlib import Path
from typing import Any

SCHEMA_VERSION_GIT_CHURN_V1 = "atomadic-forge.git_churn/v1"

_GIT_TIMEOUT = 10  # seconds


def _run_git(args: list[str], cwd: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=_GIT_TIMEOUT,
        )
        return result.stdout if result.returncode == 0 else None
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None


def _commit_count_per_file(repo_root: Path, *, since: str = "") -> dict[str, int]:
    """Return {relative_path: commit_count} for every tracked file."""
    args = ["log", "--name-only", "--pretty=format:"]
    if since:
        args += ["--since", since]
    out = _run_git(args, repo_root)
    if out is None:
        return {}
    counts: dict[str, int] = defaultdict(int)
    for line in out.splitlines():
        line = line.strip()
        if line:
            counts[line] += 1
    return dict(counts)


def _first_and_last_commit_date(repo_root: Path) -> tuple[str, str]:
    first = _run_git(["log", "--reverse", "--pretty=format:%ci", "--diff-filter=A", "--", "."], repo_root)
    last = _run_git(["log", "-1", "--pretty=format:%ci"], repo_root)
    first_date = (first or "").splitlines()[0][:10] if first else ""
    last_date = (last or "").strip()[:10] if last else ""
    return first_date, last_date


def _total_commits(repo_root: Path) -> int:
    out = _run_git(["rev-list", "--count", "HEAD"], repo_root)
    try:
        return int((out or "0").strip())
    except ValueError:
        return 0


def compute_git_churn(
    project_root: Path,
    *,
    top_n: int = 15,
    since: str = "",
    src_only: bool = True,
) -> dict[str, Any]:
    """Compute file-level git churn metrics for a repository.

    Args:
        project_root: repository root.
        top_n: number of highest-churn files to surface.
        since: optional git date filter (e.g. ``"6 months ago"``).
        src_only: when True, restrict results to files under ``src/``.

    Returns a structured dict with ``schema_version``, ``hotspot_files``,
    ``stable_files``, ``total_commits``, ``churn_period``, plus aggregate
    stats.  Returns a minimal error dict if git is unavailable.
    """
    root = Path(project_root).resolve()
    if not (root / ".git").exists():
        return {
            "schema_version": SCHEMA_VERSION_GIT_CHURN_V1,
            "available": False,
            "reason": "not a git repository root",
        }
    counts = _commit_count_per_file(root, since=since)
    if not counts:
        return {
            "schema_version": SCHEMA_VERSION_GIT_CHURN_V1,
            "available": False,
            "reason": "no git history or git not available",
        }

    if src_only:
        counts = {p: c for p, c in counts.items() if p.startswith("src/")}

    total = _total_commits(root)
    first_date, last_date = _first_and_last_commit_date(root)

    sorted_files = sorted(counts.items(), key=lambda x: -x[1])
    hotspots = [
        {"path": p, "commits": c} for p, c in sorted_files[:top_n]
    ]
    stable = [
        {"path": p, "commits": c}
        for p, c in sorted_files[::-1][:top_n]
        if c <= 2
    ]

    avg_churn = sum(counts.values()) / len(counts) if counts else 0.0
    median_churn = sorted(counts.values())[len(counts) // 2] if counts else 0

    return {
        "schema_version": SCHEMA_VERSION_GIT_CHURN_V1,
        "available": True,
        "total_commits": total,
        "files_tracked": len(counts),
        "churn_period": since or "all time",
        "first_commit_date": first_date,
        "last_commit_date": last_date,
        "avg_commits_per_file": round(avg_churn, 2),
        "median_commits_per_file": median_churn,
        "hotspot_files": hotspots,
        "stable_files": stable[:top_n],
    }
