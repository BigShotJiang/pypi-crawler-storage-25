"""Tier a1 — pure enhancement-proposal builder.

Constructs an ``atomadic-forge.enhancement_proposal/v1`` dict from
caller-supplied fields. No I/O — the a3 feature owns persistence.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
from typing import Any

from ..a0_qk_constants.enhancement_proposal_constants import (
    DEFAULT_TRUST_THRESHOLD,
    SCHEMA_VERSION_ENHANCEMENT_PROPOSAL_V1,
    TRUST_VERDICT_OFFLINE,
    TRUST_VERDICT_VALUES,
)


def _utc_now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _proposal_id_for(*, title: str, timestamp: str) -> str:
    h = hashlib.sha256(f"{title}|{timestamp}".encode()).hexdigest()
    return f"FEP-{h[:12]}"


def _normalize_evidence(evidence: list[str] | None) -> list[str]:
    if not evidence:
        return []
    return [e for e in (str(x).strip() for x in evidence) if e]


def make_proposal(
    *,
    title: str,
    description: str,
    evidence: list[str] | None = None,
    proposer: str = "anonymous",
    trust_score: float | None = None,
    trust_verdict: str = TRUST_VERDICT_OFFLINE,
    trust_threshold: float = DEFAULT_TRUST_THRESHOLD,
    proposal_id: str | None = None,
    timestamp: str | None = None,
) -> dict[str, Any]:
    """Build a v1 enhancement proposal dict.

    ``trust_verdict`` MUST be one of PASS / FAIL / OFFLINE. ``trust_score``
    may be None (offline path); when present it MUST be in [0.0, 1.0].
    Anything else raises ``ValueError`` so callers can't quietly emit
    a malformed gate result.

    ``approved`` always starts False — publishing requires an explicit
    human approval through the CLI / MCP surface.
    """
    if not title or not title.strip():
        raise ValueError("title is required and must not be empty")
    if not description or not description.strip():
        raise ValueError("description is required and must not be empty")
    if trust_verdict not in TRUST_VERDICT_VALUES:
        raise ValueError(
            f"trust_verdict must be one of {sorted(TRUST_VERDICT_VALUES)}, "
            f"got {trust_verdict!r}"
        )
    if trust_score is not None:
        if not isinstance(trust_score, int | float):
            raise ValueError("trust_score must be a number or None")
        if not 0.0 <= float(trust_score) <= 1.0:
            raise ValueError("trust_score must be in [0.0, 1.0]")

    ts = timestamp or _utc_now_iso()
    pid = proposal_id or _proposal_id_for(title=title.strip(), timestamp=ts)

    return {
        "schema_version": SCHEMA_VERSION_ENHANCEMENT_PROPOSAL_V1,
        "proposal_id": pid,
        "timestamp": ts,
        "proposer": str(proposer or "anonymous"),
        "title": title.strip(),
        "description": description.strip(),
        "evidence": _normalize_evidence(evidence),
        "trust_score": float(trust_score) if trust_score is not None else None,
        "trust_verdict": trust_verdict,
        "trust_threshold": float(trust_threshold),
        "publishable": (
            trust_verdict == "PASS"
            and trust_score is not None
            and float(trust_score) >= float(trust_threshold)
        ),
        "approved": False,
    }


__all__ = ["make_proposal"]
