"""Tier a1 — pure public-surface metrics renderers.

Golden Path Lane C W6 follow-on deliverable. ``forge metrics repo`` uses
these pure functions to compute and render a target product's own public
metrics without touching Forge's own ``forge_metrics.json``. Filesystem
walking lives in ``a2_mo_composites/repo_public_surface_sync.py``.
"""
from __future__ import annotations

import json
import re
from typing import Any

SCHEMA_VERSION_REPO_METRICS_V1 = "atomadic-forge.repo_metrics/v1"
SCHEMA_VERSION_REPO_METRICS_CONFIG_V1 = "atomadic-forge.repo_metrics_config/v1"
DEFAULT_REPO_METRICS_CONFIG_PATH = ".atomadic-forge/repo-metrics.config.json"

_SOURCE_EXTS = {
    ".py": "Python",
    ".js": "JavaScript",
    ".jsx": "JavaScript",
    ".ts": "TypeScript",
    ".tsx": "TypeScript",
    ".rs": "Rust",
    ".go": "Go",
    ".swift": "Swift",
    ".kt": "Kotlin",
    ".kts": "Kotlin",
}
_SKIP_PARTS = {
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".claude",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "build",
    "dist",
    ".atomadic-forge",
}
_TEST_NAME_RE = re.compile(r"(^test_|_test\.|\.test\.|\.spec\.)")
_PYPROJECT_VERSION_RE = re.compile(r'(?m)^version\s*=\s*"([^"]+)"')
_PYPROJECT_NAME_RE = re.compile(r'(?m)^name\s*=\s*"([^"]+)"')
_METRIC_MARKER_RE = re.compile(
    r"(?P<open><!--\s*forge:metric(?P<attrs>[^>]*)-->)"
    r"(?P<body>.*?)"
    r"(?P<close><!--\s*/forge:metric\s*-->)",
    re.DOTALL,
)
_FENCED_CODE_RE = re.compile(r"(```.*?```)", re.DOTALL)
_ATTR_RE = re.compile(r"\b(?P<key>[a-zA-Z_][a-zA-Z0-9_-]*)\s*=\s*"
                      r"(?P<quote>['\"]?)(?P<value>[^'\"\s]+)(?P=quote)")

DEFAULT_REPO_METRICS_CONFIG: dict[str, Any] = {
    "schema_version": SCHEMA_VERSION_REPO_METRICS_CONFIG_V1,
    "artifact_path": "repo_metrics.json",
    "document_globs": [
        "README.md",
        "docs/**/*.md",
        "site/**/*.md",
        "website/**/*.md",
        "app/**/*.mdx",
        "src/**/*.mdx",
    ],
    "readme_block": True,
    "sync_server_json": True,
    "extra_metrics": {},
    "aliases": {},
}


def should_skip_public_metric_path(path_parts: tuple[str, ...]) -> bool:
    """Return true when a repo path belongs to generated/vendor state."""
    return any(part in _SKIP_PARTS for part in path_parts)


def infer_project_identity_from_metadata(
    root_name: str,
    *,
    pyproject_text: str | None = None,
    package_json_text: str | None = None,
) -> dict[str, str]:
    """Infer project name/version from supplied metadata text."""
    if pyproject_text:
        name_match = _PYPROJECT_NAME_RE.search(pyproject_text)
        version_match = _PYPROJECT_VERSION_RE.search(pyproject_text)
        return {
            "name": name_match.group(1) if name_match else root_name,
            "version": version_match.group(1) if version_match else "0.0.0",
        }
    if package_json_text:
        try:
            data = json.loads(package_json_text)
            return {
                "name": str(data.get("name") or root_name),
                "version": str(data.get("version") or "0.0.0"),
            }
        except json.JSONDecodeError:
            pass
    return {"name": root_name, "version": "0.0.0"}


def compute_repo_public_metrics_from_records(
    identity: dict[str, str],
    records: list[dict[str, str]],
) -> dict[str, Any]:
    """Compute product-facing metrics from text records.

    Each record has ``path``, ``suffix``, and ``text`` keys. The caller owns
    filesystem reads; this function is deterministic over supplied data.
    """
    source_files = 0
    source_lines = 0
    test_files = 0
    languages: set[str] = set()
    for record in records:
        rel = record.get("path", "")
        parts = tuple(part for part in rel.replace("\\", "/").split("/") if part)
        if should_skip_public_metric_path(parts):
            continue
        lang = _SOURCE_EXTS.get(record.get("suffix", "").lower())
        if lang is None:
            continue
        source_files += 1
        languages.add(lang)
        text = record.get("text", "")
        source_lines += sum(1 for line in text.splitlines() if line.strip())
        filename = rel.replace("\\", "/").rsplit("/", 1)[-1]
        if "tests/" in rel or "test/" in rel or _TEST_NAME_RE.search(filename):
            test_files += 1
    return {
        "schema_version": SCHEMA_VERSION_REPO_METRICS_V1,
        "project": identity["name"],
        "version": identity["version"],
        "source_file_count": source_files,
        "source_line_count": source_lines,
        "test_file_count": test_files,
        "language_count": len(languages),
        "languages": sorted(languages),
    }


def normalize_repo_metrics_config(raw: dict[str, Any] | None = None) -> dict[str, Any]:
    """Return a forward-compatible repo metrics config."""
    config = dict(DEFAULT_REPO_METRICS_CONFIG)
    incoming = raw or {}
    for key, value in incoming.items():
        if key in {"document_globs"} and isinstance(value, list):
            config[key] = [str(item) for item in value if str(item).strip()]
        elif key in {"readme_block", "sync_server_json"}:
            config[key] = bool(value)
        elif key in {"extra_metrics", "aliases"} and isinstance(value, dict):
            config[key] = dict(value)
        elif key == "artifact_path" and str(value).strip():
            config[key] = str(value)
        elif key == "schema_version":
            config[key] = str(value)
    if not config["document_globs"]:
        config["document_globs"] = list(DEFAULT_REPO_METRICS_CONFIG["document_globs"])
    return config


def render_repo_metrics_config_json(config: dict[str, Any] | None = None) -> str:
    """Stable starter config for any repo using ``forge metrics repo``."""
    return json.dumps(normalize_repo_metrics_config(config), indent=2, sort_keys=True) + "\n"


def metrics_with_config(metrics: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    """Overlay configured customer metrics onto computed repo metrics."""
    combined = dict(metrics)
    extra = config.get("extra_metrics", {})
    if isinstance(extra, dict):
        combined.update(extra)
    return combined


def render_repo_metrics_json(metrics: dict[str, Any]) -> str:
    """Stable JSON for ``repo_metrics.json``."""
    return json.dumps(metrics, indent=2, sort_keys=True) + "\n"


def render_readme_metrics_block(metrics: dict[str, Any]) -> str:
    """Render a bounded README metrics block for product copy."""
    languages = ", ".join(metrics.get("languages") or ["unknown"])
    return "\n".join([
        "<!-- forge:metrics:start -->",
        "## By the Numbers",
        "",
        "| Metric | Value |",
        "|--------|-------|",
        f"| Version | **{metrics.get('version', '0.0.0')}** |",
        f"| Source files | **{metrics.get('source_file_count', 0)}** |",
        f"| Source lines | **{metrics.get('source_line_count', 0)}** |",
        f"| Tests | **{metrics.get('test_file_count', 0)} test files** |",
        f"| Languages | **{languages}** |",
        "",
        "_Synced by `forge metrics repo --apply`._",
        "<!-- forge:metrics:end -->",
        "",
    ])


def render_readme_with_metrics(readme_text: str, metrics: dict[str, Any]) -> str:
    """Replace or append the Forge-managed README metrics block."""
    block = render_readme_metrics_block(metrics)
    pattern = re.compile(
        r"<!-- forge:metrics:start -->.*?<!-- forge:metrics:end -->\s*",
        re.DOTALL,
    )
    if pattern.search(readme_text):
        return pattern.sub(block, readme_text)
    heading = re.compile(
        r"(?ms)^## By the Numbers\s*\n.*?(?=^---\s*$|^##\s|\Z)",
    )
    if heading.search(readme_text):
        return heading.sub(block.rstrip() + "\n", readme_text)
    return readme_text.rstrip() + "\n\n" + block


def _parse_marker_attrs(attrs: str) -> dict[str, str]:
    parsed = {m.group("key"): m.group("value") for m in _ATTR_RE.finditer(attrs)}
    if "key" not in parsed:
        for token in attrs.strip().split():
            if "=" not in token:
                parsed["key"] = token.strip()
                break
    return parsed


def _resolve_metric_value(metrics: dict[str, Any], aliases: dict[str, Any], key: str) -> Any:
    target = aliases.get(key, key)
    current: Any = metrics
    for part in str(target).split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def format_metric_value(value: Any, fmt: str = "plain") -> str:
    """Render a metric value for inline docs/site markers."""
    if fmt == "json":
        return json.dumps(value, sort_keys=True)
    if isinstance(value, list):
        value = ", ".join(str(item) for item in value)
    if fmt == "comma" and isinstance(value, int):
        return f"{value:,}"
    if fmt == "compact" and isinstance(value, int):
        if abs(value) >= 1_000_000:
            return f"{value / 1_000_000:.1f}M".replace(".0M", "M")
        if abs(value) >= 1_000:
            return f"{value / 1_000:.0f}K"
    return str(value)


def render_text_with_metric_markers(
    text: str,
    metrics: dict[str, Any],
    config: dict[str, Any] | None = None,
) -> str:
    """Refresh inline ``forge:metric`` markers in arbitrary text."""
    normalized = normalize_repo_metrics_config(config)
    aliases = normalized.get("aliases", {})
    if not isinstance(aliases, dict):
        aliases = {}

    def replace(match: re.Match[str]) -> str:
        attrs = _parse_marker_attrs(match.group("attrs"))
        key = attrs.get("key")
        if not key:
            return match.group(0)
        value = _resolve_metric_value(metrics, aliases, key)
        if value is None:
            return match.group(0)
        rendered = format_metric_value(value, attrs.get("format", "plain"))
        return f"{match.group('open')}{rendered}{match.group('close')}"

    parts = _FENCED_CODE_RE.split(text)
    for idx, part in enumerate(parts):
        if idx % 2 == 0:
            parts[idx] = _METRIC_MARKER_RE.sub(replace, part)
    return "".join(parts)


def render_server_json_with_metrics(server_text: str, metrics: dict[str, Any]) -> str:
    """Update MCP registry/server metadata from repo metrics."""
    data = json.loads(server_text)
    version = str(metrics.get("version") or data.get("version") or "0.0.0")
    data["version"] = version
    if isinstance(data.get("packages"), list) and data["packages"]:
        first = data["packages"][0]
        if isinstance(first, dict):
            first["version"] = version
    data["description"] = (
        f"{metrics.get('project', 'Project')} public surface. "
        f"{metrics.get('source_file_count', 0)} source files, "
        f"{metrics.get('test_file_count', 0)} test files, "
        f"{metrics.get('language_count', 0)} languages."
    )
    return json.dumps(data, indent=2, sort_keys=False) + "\n"


def plan_repo_public_surface_from_inputs(
    *,
    project_root: str,
    metrics: dict[str, Any],
    readme_text: str | None = None,
    server_text: str | None = None,
    documents: dict[str, str] | None = None,
    config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Return planned public-surface writes from already-loaded inputs."""
    normalized = normalize_repo_metrics_config(config)
    rendered_metrics = metrics_with_config(metrics, normalized)
    writes: list[dict[str, str]] = [{
        "path": str(normalized.get("artifact_path") or "repo_metrics.json"),
        "reason": "canonical product metrics",
        "content": render_repo_metrics_json(rendered_metrics),
    }]
    document_texts = dict(documents or {})
    if readme_text is not None and "README.md" not in document_texts:
        document_texts["README.md"] = readme_text
    for path, text in sorted(document_texts.items()):
        if path == "README.md" and normalized.get("readme_block", True):
            continue
        updated = render_text_with_metric_markers(text, rendered_metrics, normalized)
        if updated != text:
            writes.append({
                "path": path,
                "reason": "Forge metric markers",
                "content": updated,
            })
    if readme_text is not None and normalized.get("readme_block", True):
        marked_readme = render_text_with_metric_markers(
            readme_text, rendered_metrics, normalized
        )
        writes.append({
            "path": "README.md",
            "reason": "Forge-managed public metrics copy block",
            "content": render_readme_with_metrics(marked_readme, rendered_metrics),
        })
    if server_text is not None and normalized.get("sync_server_json", True):
        try:
            writes.append({
                "path": "server.json",
                "reason": "MCP registry metadata version/description sync",
                "content": render_server_json_with_metrics(server_text, rendered_metrics),
            })
        except json.JSONDecodeError:
            pass
    return {
        "schema_version": "atomadic-forge.repo_public_surface_plan/v1",
        "project_root": project_root,
        "config": normalized,
        "metrics": rendered_metrics,
        "writes": writes,
        "write_count": len(writes),
    }


__all__ = [
    "SCHEMA_VERSION_REPO_METRICS_V1",
    "SCHEMA_VERSION_REPO_METRICS_CONFIG_V1",
    "DEFAULT_REPO_METRICS_CONFIG_PATH",
    "compute_repo_public_metrics_from_records",
    "format_metric_value",
    "infer_project_identity_from_metadata",
    "metrics_with_config",
    "normalize_repo_metrics_config",
    "plan_repo_public_surface_from_inputs",
    "render_readme_metrics_block",
    "render_readme_with_metrics",
    "render_repo_metrics_config_json",
    "render_repo_metrics_json",
    "render_server_json_with_metrics",
    "render_text_with_metric_markers",
    "should_skip_public_metric_path",
]
