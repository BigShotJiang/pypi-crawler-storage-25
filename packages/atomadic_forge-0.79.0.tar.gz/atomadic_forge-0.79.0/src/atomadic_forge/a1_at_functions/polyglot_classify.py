"""Tier a1 — pure tier classification + effect detection for native langs.

Mirrors the contract of :func:`classify_tier` (Python) and
:func:`classify_js_tier` (JS/TS) for Rust, Go, Swift, Kotlin: takes a
relative path + parsed :class:`NativeSurface` and returns the canonical
tier name (one of ``a0_qk_constants`` … ``a4_sy_orchestration``).

The classification cascade — first matching rule wins — is:

  1. **Path is canonical.** If the file lives under ``aN_<tier>/`` then
     respect that placement; the directory is the source of truth.
  2. **Has an entry-point.** ``fn main`` (Rust/Go), ``@main`` (Swift),
     ``fun main`` (Kotlin) → ``a4_sy_orchestration``.
  3. **Surface is dominated by I/O imports.** stdlib io / fs / net /
     db / http imports → ``a4_sy_orchestration`` (boundary code).
  4. **Has stateful types.** structs / classes (excluding pure
     data-carrier patterns) → ``a2_mo_composites``.
  5. **Functions only, no types.** → ``a1_at_functions``.
  6. **Constants / enums only, no functions.** → ``a0_qk_constants``.
  7. **Default.** → ``a3_og_features`` (orchestrator-shaped fallback).

Effect detection uses :class:`NativeSurface.has_io` / ``has_state``
plus the function/class population to pick from the canonical
``{"pure", "state", "io"}`` lattice that Python's ``detect_effects``
produces.

Pure: no I/O, no AST.
"""

from __future__ import annotations

from .polyglot_surface import NativeSurface

CANONICAL_TIERS = (
    "a0_qk_constants",
    "a1_at_functions",
    "a2_mo_composites",
    "a3_og_features",
    "a4_sy_orchestration",
)


def _path_segments(rel: str) -> list[str]:
    return [seg.lower() for seg in rel.replace("\\", "/").split("/")]


def _path_tier(rel: str) -> str | None:
    """If the file lives under a canonical aN_*/ directory, return that tier."""
    for seg in _path_segments(rel):
        if seg in CANONICAL_TIERS:
            return seg
    return None


def classify_native_tier(*, path: str, surface: NativeSurface) -> str:
    """Return the canonical tier for a Rust/Go/Swift/Kotlin source file.

    See module docstring for the cascade order.
    """
    pt = _path_tier(path)
    if pt:
        return pt

    if surface.has_main_entry:
        return "a4_sy_orchestration"

    has_fns = bool(surface.pub_functions)
    has_classes = bool(surface.pub_classes)
    has_consts = bool(surface.pub_constants)

    # I/O surfaces — even if classes/functions exist, an I/O-heavy file
    # belongs at the boundary.  But only if we don't already know it's
    # in a tier directory (rule 1 wins).
    if surface.has_io and not has_fns and not has_classes:
        return "a4_sy_orchestration"
    if surface.has_io:
        # io+class typically means a service / driver — a3 unless it's
        # very state-heavy (then a2).  Default to a3 for clarity.
        return "a3_og_features"

    if has_classes and surface.has_state:
        return "a2_mo_composites"

    if has_fns and not has_classes:
        return "a1_at_functions"

    if has_consts and not has_fns and not has_classes:
        return "a0_qk_constants"

    return "a3_og_features"


def detect_native_effects(surface: NativeSurface) -> list[str]:
    """Return a list of canonical effect labels for a parsed surface.

    Same lattice Python's :func:`detect_effects` uses:
        ``"pure"``  — no state, no I/O
        ``"state"`` — has classes / structs / mutable types
        ``"io"``    — imports filesystem / network / db modules

    Multiple labels can fire on the same file (a service that
    encapsulates state AND talks to the network is ``["state", "io"]``).
    """
    effects: list[str] = []
    if surface.has_state:
        effects.append("state")
    if surface.has_io:
        effects.append("io")
    if not effects:
        effects.append("pure")
    return effects
