"""Tier a1 — harvest concept bridge: below-TAU-TRUST candidates → synthesis plan.

The harvest pipeline stops when confidence < TAU_TRUST because direct
grafting would risk breaking the target's architecture.  This tool is the
bridge: it takes harvest candidates, extracts the *concept* (name, purpose,
signature, docstring), and generates an implementation plan that can be
synthesised as a new a1 function without copying source code verbatim.

Output is a structured synthesis plan — not runnable code, but enough
information to implement the capability from scratch in forge style.

Pure: read-only.  No writes, no subprocess, no LLM calls.
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Any

SCHEMA_VERSION_CONCEPT_BRIDGE_V1 = "atomadic-forge.concept_bridge/v1"

# Candidate dict keys from harvest JSON
_CANDIDATE_KEYS = ("qualname", "source_repo", "target_tier", "confidence",
                   "effects", "complexity")


def _parse_source_function(source_repo: Path, qualname: str) -> dict[str, Any] | None:
    """Try to locate and parse the source function in the source repo."""
    parts = qualname.split(".")
    if len(parts) < 2:
        return None
    # Try various path guesses
    for i in range(1, len(parts)):
        module_parts = parts[:i]
        fn_name = parts[i] if i < len(parts) else parts[-1]
        py_path = source_repo / Path(*module_parts).with_suffix(".py")
        if not py_path.exists():
            # Try src/ prefix
            py_path = source_repo / "src" / Path(*module_parts).with_suffix(".py")
        if not py_path.exists():
            continue
        try:
            tree = ast.parse(py_path.read_text(encoding="utf-8", errors="replace"))
        except (OSError, SyntaxError):
            continue
        for node in ast.walk(tree):
            if (isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef)
                    and node.name == fn_name):
                docstring = ast.get_docstring(node) or ""
                args = []
                if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                    for arg in node.args.args:
                        hint = ast.unparse(arg.annotation) if arg.annotation else "Any"
                        args.append({"name": arg.arg, "type": hint})
                return_hint = ""
                if (isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef)
                        and node.returns):
                    return_hint = ast.unparse(node.returns)
                return {
                    "kind": type(node).__name__,
                    "name": fn_name,
                    "docstring": docstring[:500],
                    "args": args,
                    "return_type": return_hint,
                    "body_lines": node.end_lineno - node.lineno + 1 if hasattr(node, "end_lineno") else 0,
                }
    return None


def _infer_concept(candidate: dict, source_info: dict | None) -> str:
    """Infer a one-line concept description from harvest candidate metadata."""
    qualname = candidate.get("qualname", "")

    parts = []
    if source_info and source_info.get("docstring"):
        # First sentence of docstring
        first_sentence = source_info["docstring"].split(".")[0].strip()
        if first_sentence:
            return first_sentence

    # Infer from qualname
    name = qualname.rsplit(".", 1)[-1]
    if "dead" in name.lower() or "vulture" in name.lower() or "reachab" in name.lower():
        parts.append("dead code / reachability analysis")
    elif "cc" in name.lower() or "complexity" in name.lower() or "cyclo" in name.lower():
        parts.append("cyclomatic complexity measurement")
    elif "mi" in name.lower() or "maintain" in name.lower():
        parts.append("maintainability index computation")
    elif "commit" in name.lower() or "evolution" in name.lower():
        parts.append("commit-level code evolution tracking")
    elif "type" in name.lower() or "annot" in name.lower():
        parts.append("type inference or annotation checking")
    elif "contract" in name.lower() or "pre" in name.lower() or "post" in name.lower():
        parts.append("design-by-contract pre/postcondition verification")
    elif "similar" in name.lower() or "clone" in name.lower():
        parts.append("code similarity or clone detection")
    elif "refactor" in name.lower() or "transform" in name.lower():
        parts.append("automated refactoring or code transformation")
    else:
        parts.append(f"'{name}' utility")

    return ", ".join(parts) if parts else name


def extract_synthesis_plan(
    candidates: list[dict],
    *,
    source_repo: Path | None = None,
    top_n: int = 10,
    min_confidence: float = 0.5,
) -> dict[str, Any]:
    """Convert harvest candidates into actionable synthesis plans.

    Args:
        candidates: List of candidate dicts from forge harvest output.
        source_repo: Path to the source repo (for deeper docstring extraction).
        top_n: Max synthesis plans to generate.
        min_confidence: Minimum harvest confidence to include.

    Returns dict with ``schema_version``, ``synthesis_plans`` (ordered by
    priority), ``gap_summary``, and ``recommended_actions``.
    """
    # Filter and sort
    filtered = [c for c in candidates
                if c.get("confidence", 0) >= min_confidence
                and c.get("target_tier") in ("a1_at_functions", "a1")]
    filtered.sort(key=lambda c: -c.get("confidence", 0))
    filtered = filtered[:top_n]

    plans: list[dict] = []
    for candidate in filtered:
        qualname = candidate.get("qualname", "")
        effects = candidate.get("effects", [])
        confidence = candidate.get("confidence", 0)
        src_repo = Path(candidate.get("source_repo", source_repo or "."))

        source_info = None
        if src_repo.is_dir():
            source_info = _parse_source_function(src_repo, qualname)

        concept = _infer_concept(candidate, source_info)
        bare_name = qualname.rsplit(".", 1)[-1]
        module_slug = bare_name.lower().replace("-", "_")

        # Forge-style function name suggestion
        fn_name = f"compute_{module_slug}" if "pure" in effects else f"check_{module_slug}"
        if any(bare_name.lower().startswith(p) for p in ("get", "build", "make", "create")):
            fn_name = f"build_{module_slug}"
        if any(bare_name.lower().startswith(p) for p in ("scan", "find", "detect", "search")):
            fn_name = f"detect_{module_slug}"

        args_hint = []
        if source_info:
            for arg in source_info.get("args", []):
                if arg["name"] not in ("self", "cls"):
                    args_hint.append(f"{arg['name']}: {arg['type']}")

        plan = {
            "priority": round(confidence * 100),
            "source_qualname": qualname,
            "concept": concept,
            "suggested_module": f"{module_slug}_impl",
            "suggested_function": fn_name,
            "suggested_args": args_hint or ["project_root: Path"],
            "suggested_return": "dict[str, Any]",
            "schema_constant": f"SCHEMA_VERSION_{module_slug.upper()}_V1",
            "target_tier": "a1_at_functions",
            "source_complexity": candidate.get("complexity", 0),
            "effects": effects,
            "wire_stubs_cmd": f"forge wire-stubs {module_slug}_impl {fn_name}",
            "source_docstring": (source_info or {}).get("docstring", ""),
        }
        plans.append(plan)

    return {
        "schema_version": SCHEMA_VERSION_CONCEPT_BRIDGE_V1,
        "total_candidates_analyzed": len(candidates),
        "synthesis_plan_count": len(plans),
        "synthesis_plans": plans,
        "gap_summary": (
            f"{len(candidates)} harvest candidates found, "
            f"none auto-graftable (below TAU_TRUST). "
            f"{len(plans)} synthesis plans generated for manual implementation."
        ),
        "recommended_actions": [
            f"forge wire-stubs {p['suggested_module']} {p['suggested_function']}"
            for p in plans[:3]
        ],
    }


def run_concept_bridge(
    project_root: Path,
    *,
    harvest_json_path: str | None = None,
    candidates: list[dict] | None = None,
    top_n: int = 10,
) -> dict[str, Any]:
    """Entry point: run harvest then bridge to synthesis plans.

    If ``harvest_json_path`` is provided, reads candidates from it.
    Otherwise expects ``candidates`` list (from forge harvest --json output).
    """
    import json as _json
    if harvest_json_path:
        try:
            with open(harvest_json_path, encoding="utf-8") as f:
                harvest = _json.load(f)
            candidates = harvest.get("candidates", [])
        except (OSError, ValueError) as e:
            return {
                "schema_version": SCHEMA_VERSION_CONCEPT_BRIDGE_V1,
                "available": False,
                "reason": str(e),
            }
    if not candidates:
        return {
            "schema_version": SCHEMA_VERSION_CONCEPT_BRIDGE_V1,
            "available": False,
            "reason": "no candidates provided",
        }
    return extract_synthesis_plan(candidates, top_n=top_n)
