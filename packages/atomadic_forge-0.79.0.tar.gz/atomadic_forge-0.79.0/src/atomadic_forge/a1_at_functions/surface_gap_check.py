"""Tier a1 — surface gap checker: find a1 functions missing MCP/CLI coverage.

The forge's highest-churn files are mcp_protocol.py and cli.py because
every new a1 capability requires manual surgery to both.  This tool makes
that gap visible so ``forge surface-gaps`` can report exactly what needs
wiring — turning a hidden debt into an actionable punch-list.

Pure: read-only AST walks.  No writes.  Returns ``None``-safe results.
"""
from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Any

SCHEMA_VERSION_SURFACE_GAP_V1 = "atomadic-forge.surface_gap/v1"

# Functions whose names match these patterns are considered public entry points
# worth surfacing through MCP/CLI.
_ENTRY_PREFIXES = (
    "build_", "compute_", "emit_", "scan_", "check_", "detect_",
    "analyze_", "generate_", "extract_", "infer_", "run_",
)
_ENTRY_EXACT = {"smell_scan", "recon", "harvest"}

# Modules that ARE the MCP/CLI surface — skip them.
_SKIP_MODULES = {
    "mcp_protocol", "mcp_server", "mcp_shared",
}


def _is_entry_point(name: str, node: ast.FunctionDef) -> bool:
    """Heuristic: public function likely intended as a top-level entry point."""
    if name.startswith("_"):
        return False
    if name in _ENTRY_EXACT:
        return True
    if any(name.startswith(p) for p in _ENTRY_PREFIXES):
        return True
    # Also match if the function has a project_root-like first arg
    args = node.args
    if args.args and args.args[0].arg in ("project_root", "root", "repo_root", "args"):
        return True
    return False


def _has_schema_version_constant(module_path: Path) -> bool:
    """True if module exports a SCHEMA_VERSION_* constant (structured output contract)."""
    try:
        src = module_path.read_text(encoding="utf-8")
        return bool(re.search(r"^SCHEMA_VERSION_\w+\s*=", src, re.MULTILINE))
    except OSError:
        return False


def _walk_a1_entry_points(a1_dir: Path) -> list[dict[str, str]]:
    """Return {module, function, file} for all entry-point candidates."""
    results = []
    for py in sorted(a1_dir.glob("*.py")):
        if py.name.startswith("_"):
            continue
        stem = py.stem
        if stem in _SKIP_MODULES:
            continue
        has_schema = _has_schema_version_constant(py)
        try:
            tree = ast.parse(py.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.FunctionDef):
                continue
            if node.name.startswith("_"):
                continue
            if _is_entry_point(node.name, node) or has_schema:
                results.append({
                    "module": stem,
                    "function": node.name,
                    "qualname": f"{stem}.{node.name}",
                    "file": str(py),
                })
    return results


def _surface_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _find_pkg_root(root: Path) -> Path | None:
    """Find the main Python package root under src/."""
    src = root / "src"
    if not src.is_dir():
        return None
    # Return first subdirectory of src/ that contains a1_at_functions
    for candidate in sorted(src.iterdir()):
        if not candidate.is_dir():
            continue
        if (candidate / "a1_at_functions").is_dir():
            return candidate
    # Fall back: first package in src/ with an __init__.py
    for candidate in sorted(src.iterdir()):
        if candidate.is_dir() and (candidate / "__init__.py").exists():
            return candidate
    return None


def check_surface_gaps(project_root: Path) -> dict[str, Any]:
    """Detect a1 entry points that lack MCP dispatcher or CLI coverage.

    Args:
        project_root: Repository root (any Python project with src/<pkg>/a1_at_functions).

    Returns a dict with ``schema_version``, ``mcp_gaps``, ``cli_gaps``,
    ``both_gaps`` (missing from both), and summary counts.
    """
    root = Path(project_root).resolve()
    pkg_root = _find_pkg_root(root)
    if pkg_root is None:
        return {
            "schema_version": SCHEMA_VERSION_SURFACE_GAP_V1,
            "available": False,
            "reason": f"No src/<pkg>/a1_at_functions found under {root}",
        }
    a1_dir = pkg_root / "a1_at_functions"
    if not a1_dir.is_dir():
        return {
            "schema_version": SCHEMA_VERSION_SURFACE_GAP_V1,
            "available": False,
            "reason": f"a1_at_functions not found at {a1_dir}",
        }

    entry_points = _walk_a1_entry_points(a1_dir)

    mcp_text = _surface_text(a1_dir / "mcp_protocol.py")
    # Try standard a4 path, then any cli.py anywhere in the package
    cli_path = pkg_root / "a4_sy_orchestration" / "cli.py"
    if not cli_path.exists():
        cli_candidates = list(pkg_root.rglob("cli.py"))
        cli_path = cli_candidates[0] if cli_candidates else cli_path
    cli_text = _surface_text(cli_path)

    mcp_gaps: list[dict] = []
    cli_gaps: list[dict] = []
    both_gaps: list[dict] = []

    for ep in entry_points:
        fn = ep["function"]
        mod = ep["module"]
        in_mcp = fn in mcp_text or mod in mcp_text.split(".")
        in_cli = fn in cli_text or mod in cli_text.split(".")
        if not in_mcp:
            mcp_gaps.append(ep)
        if not in_cli:
            cli_gaps.append(ep)
        if not in_mcp and not in_cli:
            both_gaps.append(ep)

    # De-duplicate by qualname
    def _dedup(lst: list[dict]) -> list[dict]:
        seen: set[str] = set()
        out = []
        for item in lst:
            if item["qualname"] not in seen:
                seen.add(item["qualname"])
                out.append(item)
        return out

    mcp_gaps = _dedup(mcp_gaps)
    cli_gaps = _dedup(cli_gaps)
    both_gaps = _dedup(both_gaps)

    return {
        "schema_version": SCHEMA_VERSION_SURFACE_GAP_V1,
        "available": True,
        "total_entry_points_scanned": len(set(ep["qualname"] for ep in entry_points)),
        "mcp_gap_count": len(mcp_gaps),
        "cli_gap_count": len(cli_gaps),
        "both_gap_count": len(both_gaps),
        "mcp_gaps": mcp_gaps,
        "cli_gaps": cli_gaps,
        "both_gaps": both_gaps,
    }
