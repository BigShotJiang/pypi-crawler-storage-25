"""Tier a1 — pure insertion-point locator.

Closes friction F-2 from FRICTION_LOG.md: the agent kept re-reading
``mcp_protocol.py`` (~2,200 lines) and ``mcp_server.py`` (~600 lines)
to find where to insert new tool boilerplate. Each re-read cost
~1,000+ tokens; this happened 12+ times per substantial session.

This module returns just the file path + line range for any of a
handful of well-known forge insertion points. ~50 tokens per
response instead of 1,000+. Pure analytical: regex over file
content, no LLM, no I/O outside the project tree.

Supported insertion points (the ones the agent hits repeatedly):

* ``tools_dict``        — the ``TOOLS: dict[...]`` registry definition
* ``all_export``        — the ``__all__`` export list
* ``register_block``    — the import block in mcp_server.py listing
                            the ``register_*_handler`` imports
* ``mcp_server_imports``— the from-imports block at the top of
                            mcp_server.py
* ``test_pinned_set``   — the pinned-tools assertion block in
                            test_mcp_protocol.py

Each returns a ``LocateResult`` with ``file``, ``line_start``,
``line_end``, and a tiny ``preview`` (5 lines around the anchor).
The agent gets enough to navigate without re-reading the whole file.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

SCHEMA_VERSION_FORGE_LOCATE_V1 = "atomadic-forge.forge_locate/v1"


@dataclass
class LocateResult:
    schema_version: str
    point: str
    found: bool
    file: str = ""
    line_start: int = 0
    line_end: int = 0
    preview: str = ""
    note: str = ""

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


# Anchors — regex per insertion point. Each maps to a tuple of
# (relative_file_path, anchor_pattern, end_pattern_or_None_for_eof).
_ANCHORS: dict[str, tuple[str, str, str | None]] = {
    "tools_dict": (
        "src/atomadic_forge/a1_at_functions/mcp_protocol.py",
        r"^TOOLS:\s*dict\[str,\s*dict\[str,\s*Any\]\]\s*=\s*\{",
        r"^\}",
    ),
    "all_export": (
        "src/atomadic_forge/a1_at_functions/mcp_protocol.py",
        r"^__all__\s*=\s*\[",
        r"^\]",
    ),
    "register_block": (
        "src/atomadic_forge/a3_og_features/mcp_server.py",
        r"^from \.\.a1_at_functions\.mcp_protocol import \(",
        r"^\)",
    ),
    "mcp_server_imports": (
        "src/atomadic_forge/a3_og_features/mcp_server.py",
        r"^from \.\.a1_at_functions\.forge_auth import \(",
        # End at the last register-call near top-of-file body.
        r"^def _bound_enforce\b",
    ),
    "test_pinned_set": (
        "tests/test_mcp_protocol.py",
        r"^\s+pinned\s*=\s*\{",
        r"^\s+\}",
    ),
}


def forge_locate(point: str, *, project_root: Path) -> LocateResult:
    """Return the line range of a known forge insertion point.

    Args:
        point: one of the keys in :data:`_ANCHORS`.
        project_root: repo root.

    Returns:
        :class:`LocateResult` with the file + line range + a 5-line
        preview around the anchor.
    """
    if point not in _ANCHORS:
        return LocateResult(
            schema_version=SCHEMA_VERSION_FORGE_LOCATE_V1,
            point=point,
            found=False,
            note=(
                f"unknown insertion point {point!r}; "
                f"known: {sorted(_ANCHORS.keys())}"
            ),
        )

    rel, anchor, end_pat = _ANCHORS[point]
    file_path = Path(project_root).resolve() / rel
    if not file_path.exists():
        return LocateResult(
            schema_version=SCHEMA_VERSION_FORGE_LOCATE_V1,
            point=point,
            found=False,
            file=str(file_path),
            note=f"file not found: {rel}",
        )

    try:
        text = file_path.read_text(encoding="utf-8")
    except OSError as exc:
        return LocateResult(
            schema_version=SCHEMA_VERSION_FORGE_LOCATE_V1,
            point=point, found=False, file=str(file_path),
            note=f"OSError reading file: {exc}",
        )

    lines = text.splitlines()
    anchor_re = re.compile(anchor, re.MULTILINE)
    end_re = re.compile(end_pat, re.MULTILINE) if end_pat else None

    # Find anchor line.
    line_start = 0
    for i, line in enumerate(lines, start=1):
        if anchor_re.match(line):
            line_start = i
            break
    if not line_start:
        return LocateResult(
            schema_version=SCHEMA_VERSION_FORGE_LOCATE_V1,
            point=point, found=False, file=str(file_path),
            note=f"anchor pattern not found: {anchor!r}",
        )

    # Find end line (start scanning AFTER anchor).
    line_end = line_start
    if end_re is not None:
        for i in range(line_start, len(lines)):
            if end_re.match(lines[i]):
                line_end = i + 1
                break
        else:
            line_end = len(lines)
    else:
        line_end = len(lines)

    # Preview: 2 lines before + anchor + 2 lines after.
    pv_start = max(0, line_start - 3)
    pv_end = min(len(lines), line_start + 2)
    preview = "\n".join(
        f"{n + 1:5d} | {lines[n]}"
        for n in range(pv_start, pv_end)
    )

    return LocateResult(
        schema_version=SCHEMA_VERSION_FORGE_LOCATE_V1,
        point=point,
        found=True,
        file=str(file_path.relative_to(Path(project_root).resolve())
                  if file_path.is_relative_to(Path(project_root).resolve())
                  else file_path),
        line_start=line_start,
        line_end=line_end,
        preview=preview,
    )


def list_known_points() -> list[str]:
    """Return all anchor names supported by :func:`forge_locate`."""
    return sorted(_ANCHORS.keys())
