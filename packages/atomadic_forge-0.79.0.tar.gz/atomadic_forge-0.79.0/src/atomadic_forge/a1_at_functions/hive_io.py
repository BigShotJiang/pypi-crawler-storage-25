"""Tier a1 — JSONL IO for the hive registry + consensus log.

Append-only, content-addressed, malformed-line tolerant — same shape
as wisdom_io.py. Two stores:

* ``.atomadic-forge/hive/agents.jsonl`` — agent registrations
* ``.atomadic-forge/hive/consensus.jsonl`` — proposal / vote / resolution events

No LLM. Pure stdlib.
"""
from __future__ import annotations

import hashlib
import json
import time
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from ..a0_qk_constants.hive_constants import (
    DEFAULT_SUBSCRIPTIONS,
    HIVE_AGENTS_FILE_REL,
    HIVE_CONSENSUS_FILE_REL,
    SCHEMA_VERSION_HIVE_AGENT_V1,
    SCHEMA_VERSION_HIVE_CONSENSUS_V1,
)


def hive_agents_file(project_root: Path) -> Path:
    return Path(project_root) / HIVE_AGENTS_FILE_REL


def hive_consensus_file(project_root: Path) -> Path:
    return Path(project_root) / HIVE_CONSENSUS_FILE_REL


def _iso_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _agent_id(agent_name: str, role: str, ts: str) -> str:
    """Stable short id for an agent registration — content-addressed.

    Uses ``time.time_ns()`` in addition to the human-readable ts so
    two registrations within the same second never collide (e.g.
    register-then-deactivate in a fast test).
    """
    digest = hashlib.sha256(
        f"{agent_name}|{role}|{ts}|{time.time_ns()}".encode(),
    ).hexdigest()
    return f"AGT-{digest[:8]}"


def _consensus_id(intent: str, proposer: str, ts: str) -> str:
    digest = hashlib.sha256(
        f"{intent}|{proposer}|{ts}|{time.time_ns()}".encode(),
    ).hexdigest()
    return f"CNS-{digest[:8]}"


# ── Agent registry IO ────────────────────────────────────────────────

def make_agent_entry(
    *,
    agent_name: str,
    role: str,
    capabilities: list[str] | None = None,
    subscribes_to: list[str] | None = None,
    write_lanes: list[str] | None = None,
    identity_claim: str | None = None,
    notes: str | None = None,
) -> dict[str, Any]:
    """Build an agent registration dict ready to append.

    ``identity_claim`` is an opaque token the agent provides (e.g. a
    session id, a signed JWT, or a public-key fingerprint). The hive
    registry doesn't verify it cryptographically — that's an upstream
    AAAA-Nexus job — but recording it lets future audits trace
    every commit / wisdom entry / consensus vote back to the agent
    that filed it.
    """
    if not agent_name or not agent_name.strip():
        raise ValueError("hive: agent_name must be non-empty")
    if not role or not role.strip():
        raise ValueError("hive: role must be non-empty")
    ts = _iso_now()
    subs = subscribes_to
    if subs is None:
        subs = sorted(DEFAULT_SUBSCRIPTIONS.get(role, frozenset()))
    return {
        "schema_version": SCHEMA_VERSION_HIVE_AGENT_V1,
        "id": _agent_id(agent_name, role, ts),
        "registered_at_utc": ts,
        "agent_name": agent_name.strip(),
        "role": role.strip(),
        "capabilities": sorted({*(capabilities or [])}),
        "subscribes_to": sorted({*subs}),
        "write_lanes": sorted({*(write_lanes or [])}),
        "identity_claim": identity_claim,
        "notes": notes,
        "active": True,
    }


def append_agent(project_root: Path, entry: dict[str, Any]) -> Path:
    """Append one agent registration entry. Idempotent on duplicate id."""
    path = hive_agents_file(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        existing_ids = {e.get("id") for e in iter_agents(project_root)}
        if entry.get("id") in existing_ids:
            return path
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, default=str, ensure_ascii=False))
        f.write("\n")
    return path


def iter_agents(project_root: Path) -> Iterable[dict[str, Any]]:
    path = hive_agents_file(project_root)
    if not path.exists():
        return
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                continue


def load_agents(project_root: Path) -> list[dict[str, Any]]:
    return list(iter_agents(project_root))


def active_agents(project_root: Path) -> list[dict[str, Any]]:
    """Return agents with ``active: true`` (post-deactivation filter).

    The agents log is append-only; deactivation appends a new entry
    with ``active: false`` and ``supersedes: <old_id>``. Active
    filter projects the live state.
    """
    by_name: dict[str, dict[str, Any]] = {}
    for e in load_agents(project_root):
        name = e.get("agent_name", "")
        # Latest registration per agent_name wins.
        by_name[name] = e
    return [e for e in by_name.values() if e.get("active", True)]


# ── Consensus IO ─────────────────────────────────────────────────────

def make_consensus_event(
    *,
    kind: str,
    consensus_id: str | None = None,
    intent: str | None = None,
    proposer: str | None = None,
    voter: str | None = None,
    vote: str | None = None,
    rationale: str | None = None,
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a consensus-event dict (proposal | vote | resolution)."""
    if kind not in {"proposal", "vote", "resolution"}:
        raise ValueError(f"consensus kind must be proposal|vote|resolution, got {kind!r}")
    ts = _iso_now()
    if kind == "proposal":
        if not intent or not proposer:
            raise ValueError("proposal requires intent + proposer")
        cid = _consensus_id(intent, proposer, ts)
    else:
        if not consensus_id:
            raise ValueError(f"{kind} requires consensus_id")
        cid = consensus_id
    return {
        "schema_version": SCHEMA_VERSION_HIVE_CONSENSUS_V1,
        "consensus_id": cid,
        "kind": kind,
        "timestamp_utc": ts,
        "intent": intent,
        "proposer": proposer,
        "voter": voter,
        "vote": vote,
        "rationale": rationale,
        "payload": payload or {},
    }


def append_consensus(project_root: Path, event: dict[str, Any]) -> Path:
    path = hive_consensus_file(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, default=str, ensure_ascii=False))
        f.write("\n")
    return path


def iter_consensus(project_root: Path) -> Iterable[dict[str, Any]]:
    path = hive_consensus_file(project_root)
    if not path.exists():
        return
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                continue


def load_consensus(project_root: Path) -> list[dict[str, Any]]:
    return list(iter_consensus(project_root))


def consensus_events_for(
    project_root: Path, consensus_id: str,
) -> list[dict[str, Any]]:
    """All events (proposal + votes + resolution) for one consensus_id."""
    return [
        e for e in iter_consensus(project_root)
        if e.get("consensus_id") == consensus_id
    ]
