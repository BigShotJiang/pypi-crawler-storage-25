"""Tier a1 — pure JSONL read/write for the wisdom DB.

Append-only, never rewrites past entries. Supersession is a forward
operation (new entry with ``supersedes: <id>``); the old entry stays
in the log for lineage. Reading is just a streaming parse of the
file with optional filters.

No LLM. No external deps beyond stdlib.
"""
from __future__ import annotations

import hashlib
import json
import time
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from ..a0_qk_constants.wisdom_constants import (
    SCHEMA_VERSION_WISDOM_V1,
    WISDOM_FILE_REL,
)


def wisdom_file_path(project_root: Path) -> Path:
    """Return the on-disk path to the wisdom DB for a repo."""
    return Path(project_root) / WISDOM_FILE_REL


def _new_id(insight: str, ts: str) -> str:
    """Stable short id for a wisdom entry — content-addressed."""
    digest = hashlib.sha256(f"{insight}|{ts}".encode()).hexdigest()
    return f"WIS-{digest[:8]}"


def make_entry(
    *,
    insight: str,
    scope: str,
    tags: list[str] | None = None,
    evidence: list[str] | None = None,
    confidence: float = 0.5,
    agent_name: str = "anonymous",
    session_id: str | None = None,
    supersedes: str | None = None,
    trust_signals: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a wisdom entry dict ready to append.

    Pure: deterministic given inputs except for the timestamp. The
    ``id`` is derived from ``insight + timestamp`` so two entries
    with the same insight from different sessions get distinct ids.
    """
    if not insight or not insight.strip():
        raise ValueError("wisdom: insight must be a non-empty string")
    ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    return {
        "schema_version": SCHEMA_VERSION_WISDOM_V1,
        "id": _new_id(insight, ts),
        "timestamp_utc": ts,
        "agent_name": agent_name,
        "session_id": session_id,
        "insight": insight.strip(),
        "scope": scope,
        "tags": sorted({*(tags or [])}),
        "evidence": list(evidence or []),
        "confidence": float(max(0.0, min(1.0, confidence))),
        "supersedes": supersedes,
        "trust_signals": dict(trust_signals or {}),
    }


def append_wisdom(project_root: Path, entry: dict[str, Any]) -> Path:
    """Append one wisdom entry to ``.atomadic-forge/wisdom.jsonl``.

    Creates the parent directory if missing. Returns the path written.
    Idempotent on duplicate ids — refuses to write a second entry
    with the same id (returns the path without writing).
    """
    path = wisdom_file_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        existing_ids = {e.get("id") for e in iter_wisdom(project_root)}
        if entry.get("id") in existing_ids:
            return path
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, default=str, ensure_ascii=False))
        f.write("\n")
    return path


def iter_wisdom(project_root: Path) -> Iterable[dict[str, Any]]:
    """Stream all wisdom entries for a repo, oldest-first.

    Returns an empty iterator if the wisdom file doesn't exist —
    new repos behave the same as repos that just have no recorded
    wisdom yet.
    """
    path = wisdom_file_path(project_root)
    if not path.exists():
        return
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                # Malformed line — skip rather than blow up the stream.
                # Lineage tools can flag the file separately.
                continue


def load_wisdom(project_root: Path) -> list[dict[str, Any]]:
    """Read all wisdom entries into a list. Convenience wrapper."""
    return list(iter_wisdom(project_root))


def superseded_ids(entries: list[dict[str, Any]]) -> set[str]:
    """Return the set of ids that have been superseded by later entries."""
    return {
        e["supersedes"] for e in entries
        if e.get("supersedes")
    }


def active_wisdom(project_root: Path) -> list[dict[str, Any]]:
    """Return wisdom entries that have NOT been superseded.

    The wisdom log is append-only; this is a read-side filter, not a
    rewrite. Old entries stay in the file for audit; consumers ranking
    by relevance want only the live ones.
    """
    entries = load_wisdom(project_root)
    dead = superseded_ids(entries)
    return [e for e in entries if e.get("id") not in dead]
