"""Tier a1 — pure upward-import scanner + auto-fix proposer.

Walks a tier-organized package and reports every import statement that
violates the upward-only law (lower tier importing from a higher tier).
Handles both Python (``from <pkg>.aN_… import …``) AND JavaScript / TypeScript
(``import "../aN_…/foo"`` or ``require("../aN_…/foo")``).

Lane D2 of the post-audit plan added the optional ``suggest_repairs``
mode: when enabled, every violation gets a concrete ``proposed_fix``
string and ``auto_fixable`` counts the suggestions whose minimum-edit
fix is mechanically obvious (move the violating file UP to the tier of
the symbol it imports). Heuristic, not a guarantee — the user still
decides whether the file should move or whether the import should
instead be inverted. Pure: no file writes, no exec.

v0.14.0a9 enhancements:
    * ``if TYPE_CHECKING:`` guarded imports are NOT runtime — they're
      excluded from violations and surfaced as ``type_only_imports``
      so reviewers can see them without acting on them.
    * ``importlib.import_module("...aN_...")`` calls are detected and
      surfaced as ``dynamic_import_warnings`` (the static law cannot
      prove direction; flagged for human review, not auto-failed).
    * ``from .X import *`` is always reported in ``star_import_warnings``
      regardless of tier — wildcard imports defeat the import contract.
    * ``strict_cycles=True`` enables a same-tier-cycle detector that
      reports any pair of files at the same tier importing from each
      other. Off by default because non-trivial intra-tier graphs may
      have benign cycles (mutual delegation through stable interfaces).
"""

from __future__ import annotations

import ast
import re
from collections import defaultdict
from pathlib import Path

from ..a0_qk_constants.error_codes import fcode_for_tier_violation
from ..a0_qk_constants.lang_extensions import (
    GO_EXTS,
    JAVASCRIPT_EXTS,
    KOTLIN_EXTS,
    PYTHON_EXTS,
    RUST_EXTS,
    SWIFT_EXTS,
    TYPESCRIPT_EXTS,
    path_parts_contain_ignored_dir,
)
from ..a0_qk_constants.tier_names import TIER_NAMES, can_import
from .js_parser import parse_imports
from .polyglot_imports import (
    parse_go_imports,
    parse_kotlin_imports,
    parse_rust_imports,
    parse_swift_imports,
)

_TIER_PATH_RE = re.compile(r"\.(?P<tier>a\d_[a-z_]+)\.")
_TIER_SLASH_RE = re.compile(r"(?P<tier>a\d_[a-z_]+)(?:/|$)")


# ── TYPE_CHECKING / dynamic-import / star-import detection ───────────


def _is_type_checking_test(test: ast.AST) -> bool:
    """True iff the ``if`` test is ``TYPE_CHECKING``-shaped.

    Recognizes:
        ``if TYPE_CHECKING:``
        ``if typing.TYPE_CHECKING:``
        ``if t.TYPE_CHECKING:`` (any attribute leaf named TYPE_CHECKING)
    """
    if isinstance(test, ast.Name):
        return test.id == "TYPE_CHECKING"
    if isinstance(test, ast.Attribute):
        return test.attr == "TYPE_CHECKING"
    return False


def _collect_type_checking_imports(tree: ast.Module) -> set[int]:
    """Return the set of ``ast.ImportFrom.lineno`` values that live inside
    an ``if TYPE_CHECKING:`` block (or its ``else`` branch).

    Only top-level guards count — a nested ``if TYPE_CHECKING:`` inside a
    function body would already be unreachable at runtime due to scoping,
    but we cover both for completeness.
    """
    guarded: set[int] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.If):
            continue
        if not _is_type_checking_test(node.test):
            continue
        # Only the THEN branch is type-only at runtime; the ELSE branch
        # IS reachable when TYPE_CHECKING is False (it always is at
        # runtime), so we must NOT skip imports there.
        for child in node.body:
            for sub in ast.walk(child):
                if isinstance(sub, ast.ImportFrom):
                    guarded.add(sub.lineno)
    return guarded


def _collect_dynamic_imports(tree: ast.Module) -> list[dict]:
    """Find ``importlib.import_module("...")`` calls.

    Returns a list of ``{lineno, module}`` dicts. Modules that are
    string literals are reported with their resolved value; non-literal
    arguments (e.g. variable, f-string) are reported with module=``"<dynamic>"``.
    """
    out: list[dict] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        # Match importlib.import_module(...) or import_module(...) (when
        # the function was imported by name).
        is_import_module = False
        if (isinstance(func, ast.Attribute)
                and func.attr == "import_module"):
            is_import_module = True
        elif isinstance(func, ast.Name) and func.id == "import_module":
            is_import_module = True
        if not is_import_module:
            continue
        if node.args and isinstance(node.args[0], ast.Constant) \
                and isinstance(node.args[0].value, str):
            mod = node.args[0].value
        else:
            mod = "<dynamic>"
        out.append({"lineno": node.lineno, "module": mod})
    return out


def _collect_star_imports(tree: ast.Module) -> list[dict]:
    """Find ``from X import *`` lines (always a contract violation)."""
    out: list[dict] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.ImportFrom):
            continue
        for alias in node.names:
            if alias.name == "*":
                out.append({
                    "lineno": node.lineno,
                    "module": node.module or "",
                })
    return out


def _tier_of_module(module: str) -> str | None:
    m = _TIER_PATH_RE.search(f".{module}.")
    if m:
        tier = m.group("tier")
        if tier in TIER_NAMES:
            return tier
    return None


def _tier_of_specifier(spec: str) -> str | None:
    """Pull a tier name out of a polyglot module specifier.

    Handles every supported language's separator by normalising:
        ``::``  (Rust)        → ``/``
        ``.``   (Kotlin/Swift) → ``/``
        ``\\``  (Windows path) → ``/``

    Examples:
        ``"../a3_og_features/feature"``           → ``"a3_og_features"``
        ``"crate::a2_mo_composites::Foo"``        → ``"a2_mo_composites"``
        ``"com.example.a1_at_functions.helper"`` → ``"a1_at_functions"``
    """
    if not spec:
        return None
    normalised = (
        spec.replace("\\", "/")
            .replace("::", "/")
            .replace(".", "/")
    )
    m = _TIER_SLASH_RE.search(normalised)
    if m:
        tier = m.group("tier")
        if tier in TIER_NAMES:
            return tier
    return None


def _tier_of_file(path: Path, package_root: Path) -> str | None:
    parts = path.relative_to(package_root).parts
    for p in parts:
        if p in TIER_NAMES:
            return p
    return None


def _scan_python_file(
    py: Path, package_root: Path,
    from_tier: str, violations: list[dict],
    *,
    type_only_imports: list[dict] | None = None,
    dynamic_import_warnings: list[dict] | None = None,
    star_import_warnings: list[dict] | None = None,
    same_tier_edges: dict[str, set[str]] | None = None,
    strict_cycles: bool = False,
) -> None:
    """Scan one Python file for tier-violation imports (and v0.14.0a9 warnings).

    Mutates the lists/dicts the caller passes in. Returns nothing.
    """
    try:
        text = py.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(text, filename=str(py))
    except (SyntaxError, OSError):
        return

    rel = str(py.relative_to(package_root).as_posix())
    type_check_lines = _collect_type_checking_imports(tree)

    # v0.14.0a9 — surface dynamic and star imports to the caller for
    # human review. They never become hard violations.
    if dynamic_import_warnings is not None:
        for dyn in _collect_dynamic_imports(tree):
            dynamic_import_warnings.append({
                "file": rel,
                "lineno": dyn["lineno"],
                "module": dyn["module"],
            })
    if star_import_warnings is not None:
        for star in _collect_star_imports(tree):
            star_import_warnings.append({
                "file": rel,
                "lineno": star["lineno"],
                "module": star["module"],
            })

    for node in ast.walk(tree):
        if not isinstance(node, ast.ImportFrom):
            continue
        mod = node.module or ""
        to_tier = _tier_of_module(mod)

        # v0.14.0a9 — record same-tier edges for optional cycle scan.
        # Relative imports (level >= 1, no tier in module path) resolve
        # to the same tier by definition — record them too.
        if strict_cycles and same_tier_edges is not None:
            is_same_tier = to_tier == from_tier or (
                to_tier is None
                and getattr(node, "level", 0) == 1
                and mod
            )
            if is_same_tier:
                same_tier_edges[rel].add(mod)

        if to_tier is None:
            continue

        if can_import(from_tier, to_tier):
            continue

        # TYPE_CHECKING-guarded imports are NOT runtime — surface them
        # but don't count them as upward-import violations.
        if node.lineno in type_check_lines:
            if type_only_imports is not None:
                for alias in node.names:
                    type_only_imports.append({
                        "file": rel,
                        "from_tier": from_tier,
                        "to_tier": to_tier,
                        "imported": alias.name,
                        "lineno": node.lineno,
                    })
            continue

        for alias in node.names:
            violations.append({
                "file": rel,
                "from_tier": from_tier,
                "to_tier": to_tier,
                "imported": alias.name,
                "language": "python",
                "f_code": fcode_for_tier_violation(from_tier, to_tier),
                "proposed_fix": "",
            })


def _scan_js_file(js: Path, package_root: Path,
                   from_tier: str, language: str,
                   violations: list[dict]) -> None:
    try:
        text = js.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return
    for spec in parse_imports(text):
        to_tier = _tier_of_specifier(spec)
        if to_tier is None:
            continue
        if can_import(from_tier, to_tier):
            continue
        violations.append({
            "file": str(js.relative_to(package_root).as_posix()),
            "from_tier": from_tier,
            "to_tier": to_tier,
            "imported": spec,
            "language": language,
            "f_code": fcode_for_tier_violation(from_tier, to_tier),
            "proposed_fix": "",
        })


# ── polyglot scan dispatcher (Rust, Go, Swift, Kotlin) ────────────────


def _scan_polyglot_file(path: Path, package_root: Path,
                         from_tier: str, language: str,
                         parser, violations: list[dict]) -> None:
    """Generic file scanner for languages whose imports parse to flat strings.

    ``parser`` is one of ``parse_rust_imports`` / ``parse_go_imports`` /
    ``parse_swift_imports`` / ``parse_kotlin_imports`` — each accepts a
    source string and returns a deduplicated ``list[str]`` of import
    specifiers.  Each specifier is matched against ``_tier_of_specifier``
    (regex search for ``aN_…``); imports that don't reference a tier are
    silently ignored (external crates, stdlib modules, etc.).

    Pure dispatch — the language-specific work all happens in the parser.
    """
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return
    for spec in parser(text):
        to_tier = _tier_of_specifier(spec)
        if to_tier is None:
            continue
        if can_import(from_tier, to_tier):
            continue
        violations.append({
            "file": str(path.relative_to(package_root).as_posix()),
            "from_tier": from_tier,
            "to_tier": to_tier,
            "imported": spec,
            "language": language,
            "f_code": fcode_for_tier_violation(from_tier, to_tier),
            "proposed_fix": "",
        })


def suggest_fix_for_violation(violation: dict) -> dict:
    """Return the violation augmented with a concrete repair proposal.

    Heuristic: when tier T imports tier U upward (T < U), the safest
    *mechanical* fix is to move the importing file from T to U — the
    file is doing higher-tier work (consuming state / orchestrating)
    and was misclassified. The alternative (push the imported symbol
    down to T) requires semantic judgement we don't have here.

    The returned dict has the original violation fields plus:
        proposed_action      — one of "move_file_up" | "review_manually"
        proposed_destination — target tier directory (e.g. "a2_mo_composites")
        fix_command          — single shell command sketch the user can adapt
        auto_fixable         — bool: is this a clean mechanical move?

    Pure: no I/O. Heuristic — for review, not auto-apply.
    """
    file = violation["file"]
    from_tier = violation["from_tier"]
    to_tier = violation["to_tier"]
    language = violation.get("language", "python")
    imported = violation.get("imported", "")

    auto_fixable = (
        from_tier in TIER_NAMES
        and to_tier in TIER_NAMES
        and from_tier != to_tier
        and language in (
            "python", "javascript", "typescript",
            "rust", "go", "swift", "kotlin",
        )
    )

    if auto_fixable:
        proposed_action = "move_file_up"
        proposed_destination = to_tier
        # File path under the package: the user's package root prefix
        # is unknown to this pure function, so the command is a sketch.
        fix_command = (
            f"mv <package_root>/{file} <package_root>/{to_tier}/"
            f"{Path(file).name}  "
            f"# then update imports referencing the old path"
        )
        reasoning = (
            f"{file} is at tier {from_tier} but imports from "
            f"tier {to_tier} (symbol: {imported!r}). The safest "
            f"mechanical fix is to relocate the file up to {to_tier}; "
            f"if the file is genuinely a {from_tier} citizen, the "
            f"imported symbol probably belongs at {from_tier} or "
            f"lower instead."
        )
    else:
        proposed_action = "review_manually"
        proposed_destination = ""
        fix_command = ""
        reasoning = (
            f"Could not auto-classify a destination for {file} "
            f"(from_tier={from_tier!r}, to_tier={to_tier!r}, "
            f"language={language!r}). Review manually."
        )

    return {
        **violation,
        "proposed_action": proposed_action,
        "proposed_destination": proposed_destination,
        "fix_command": fix_command,
        "reasoning": reasoning,
        "auto_fixable": auto_fixable,
    }


def _detect_same_tier_cycles(edges: dict[str, set[str]]) -> list[dict]:
    """Find file-pair cycles within the same tier.

    Reports the deduplicated set of ``(a, b)`` pairs where file ``a``
    imports a module that resolves to file ``b`` AND ``b`` imports
    something that resolves to ``a``. Module-name resolution here is
    structural (we treat any import whose tier matches as a candidate
    edge); this catches the common case where ``a2/foo.py`` imports
    ``a2.bar`` and ``a2/bar.py`` imports ``a2.foo``.
    """
    cycles: list[dict] = []
    seen: set[tuple[str, str]] = set()
    for src, mods in edges.items():
        for mod in mods:
            mod_leaf = mod.rsplit(".", 1)[-1]
            for tgt in edges:
                if tgt == src:
                    continue
                if Path(tgt).stem != mod_leaf:
                    continue
                # tgt imports src?
                src_leaf_qualifiers = {Path(src).stem}
                if any(m.rsplit(".", 1)[-1] in src_leaf_qualifiers
                       for m in edges[tgt]):
                    pair = tuple(sorted([src, tgt]))
                    if pair in seen:
                        continue
                    seen.add(pair)
                    cycles.append({
                        "files": list(pair),
                        "tier": src.split("/")[0] if "/" in src else "",
                    })
    return cycles


def scan_violations(
    package_root: Path,
    *,
    suggest_repairs: bool = False,
    strict_cycles: bool = False,
) -> dict:
    """Return a wire report dict keyed by ``schema_version``.

    Polyglot: scans Python ``.py`` AND JavaScript / TypeScript files. Each
    violation includes a ``language`` field so reports can group by source.

    ``suggest_repairs`` (Lane D2): when True, every violation is enriched
    with a ``proposed_fix`` string, the top-level ``auto_fixable`` count
    is the number of violations with a clean mechanical move, and the
    response includes a ``repair_suggestions`` summary (one entry per
    file, deduplicated). Default False keeps the v1 schema unchanged.

    ``strict_cycles`` (v0.14.0a9): when True, the report also includes
    ``same_tier_cycles`` — pairs of files within the same tier that
    import from each other. Off by default because not every intra-tier
    cycle is a smell; teams can opt in via CLI flag.
    """
    import time as _time
    _t0 = _time.monotonic()
    package_root = Path(package_root).resolve()
    violations: list[dict] = []
    type_only_imports: list[dict] = []
    dynamic_import_warnings: list[dict] = []
    star_import_warnings: list[dict] = []
    same_tier_edges: dict[str, set[str]] = defaultdict(set)
    auto_fixable = 0
    _files_scanned = 0
    _tiers_seen: set[str] = set()

    for f in package_root.rglob("*"):
        if not f.is_file():
            continue
        rel_parts = f.relative_to(package_root).parts
        if path_parts_contain_ignored_dir(rel_parts):
            continue
        from_tier = _tier_of_file(f, package_root)
        if from_tier is None:
            continue
        _tiers_seen.add(from_tier)
        suffix = f.suffix.lower()
        if suffix in PYTHON_EXTS:
            _files_scanned += 1
            _scan_python_file(
                f, package_root, from_tier, violations,
                type_only_imports=type_only_imports,
                dynamic_import_warnings=dynamic_import_warnings,
                star_import_warnings=star_import_warnings,
                same_tier_edges=same_tier_edges,
                strict_cycles=strict_cycles,
            )
        elif suffix in JAVASCRIPT_EXTS:
            _files_scanned += 1
            _scan_js_file(f, package_root, from_tier, "javascript", violations)
        elif suffix in TYPESCRIPT_EXTS:
            _files_scanned += 1
            _scan_js_file(f, package_root, from_tier, "typescript", violations)
        elif suffix in RUST_EXTS:
            _files_scanned += 1
            _scan_polyglot_file(
                f, package_root, from_tier, "rust",
                parse_rust_imports, violations,
            )
        elif suffix in GO_EXTS:
            _files_scanned += 1
            _scan_polyglot_file(
                f, package_root, from_tier, "go",
                parse_go_imports, violations,
            )
        elif suffix in SWIFT_EXTS:
            _files_scanned += 1
            _scan_polyglot_file(
                f, package_root, from_tier, "swift",
                parse_swift_imports, violations,
            )
        elif suffix in KOTLIN_EXTS:
            _files_scanned += 1
            _scan_polyglot_file(
                f, package_root, from_tier, "kotlin",
                parse_kotlin_imports, violations,
            )

    repair_suggestions: list[dict] = []
    if suggest_repairs:
        for v in violations:
            enriched = suggest_fix_for_violation(v)
            v["proposed_fix"] = enriched["fix_command"] or enriched["reasoning"]
            v["proposed_action"] = enriched["proposed_action"]
            v["proposed_destination"] = enriched["proposed_destination"]
            if enriched["auto_fixable"]:
                auto_fixable += 1
        # One summary entry per (file, proposed_destination) pair.
        seen: set[tuple[str, str]] = set()
        for v in violations:
            key = (v["file"], v.get("proposed_destination", ""))
            if key in seen:
                continue
            seen.add(key)
            repair_suggestions.append({
                "file": v["file"],
                "from_tier": v["from_tier"],
                "proposed_action": v.get("proposed_action", "review_manually"),
                "proposed_destination": v.get("proposed_destination", ""),
                "violation_count": sum(1 for w in violations if w["file"] == v["file"]),
            })

    same_tier_cycles: list[dict] = []
    if strict_cycles:
        same_tier_cycles = _detect_same_tier_cycles(same_tier_edges)

    report: dict = {
        "schema_version": "atomadic-forge.wire/v1",
        "source_dir": str(package_root),
        "violation_count": len(violations),
        "auto_fixable": auto_fixable,
        "violations": violations,
        "type_only_imports": type_only_imports,
        "dynamic_import_warnings": dynamic_import_warnings,
        "star_import_warnings": star_import_warnings,
        "verdict": "PASS" if not violations else "FAIL",
    }
    if suggest_repairs:
        report["repair_suggestions"] = repair_suggestions
    if strict_cycles:
        report["same_tier_cycles"] = same_tier_cycles
    from .response_enricher import (
        enrich_response as _enrich,
    )
    from .response_enricher import (
        make_scope as _make_scope,
    )
    from .response_enricher import (
        summarize_wire as _summarize_wire,
    )
    _duration_ms = int((_time.monotonic() - _t0) * 1000)
    return _enrich(
        report,
        scope=_make_scope(
            files_scanned=_files_scanned,
            tiers_traversed=len(_tiers_seen),
            scan_duration_ms=_duration_ms,
            basis_kind="files",
        ),
        summary=_summarize_wire(report),
        project_root=package_root,
        tool="wire",
    )
