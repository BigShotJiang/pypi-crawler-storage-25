"""Tier a1 — pure helpers for the Forge subscription gate.

Golden Path Lane C W5 deliverable. Stateless helpers that read from
inputs and return values — no I/O, no env access of their own, no
filesystem touches. The HTTP round trips and the in-memory cache live
in ``a2_mo_composites/forge_auth_client.py``; the MCP gate that calls
both lives in ``a3_og_features/mcp_server.py``.

The split mirrors the a1↔a2 contract used by the receipt signer: a1
shapes the request body and parses the response into a ``VerifyResult``
TypedDict; a2 owns the network call, the cache, and the offline-grace
clock. That way the parser is trivially unit-testable without monkey-
patching urllib.

What lives here:
  * ``read_api_key_from_env``   — pull FORGE_API_KEY out of an env dict
                                   (passed in, not read from os.environ)
    * ``is_valid_api_key_shape``  — cheap Forge/Master prefix check
  * ``build_verify_request``    — body for the verify POST
  * ``parse_verify_response``   — JSON dict → VerifyResult, strict
  * ``build_usage_log_request`` — body for the usage-log POST
  * ``hash_project_path``       — SHA-256 of resolved abspath, so the
                                   telemetry stream sees ``a3f81b...``
                                   instead of ``C:/Users/<name>/...``
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from ..a0_qk_constants.auth_constants import (
    API_KEY_ENV,
    API_KEY_PREFIXES,
    MASTER_API_KEY_ENV,
    VerifyResult,
)


def _has_supported_key_prefix(value: str) -> bool:
    return any(
        value.startswith(prefix) and len(value) > len(prefix)
        for prefix in API_KEY_PREFIXES
    )


def read_api_key_from_env(env: dict[str, str]) -> str | None:
    """Return the configured Forge key from ``env`` if it's plausibly real.

    Pure: takes an env dict (caller passes ``os.environ`` or a test
    fixture), strips whitespace, and returns the key only when it
    starts with a supported Forge prefix. Missing or wrong-shape keys
    return ``None`` — so the caller can distinguish "no key configured"
    from "key was set to a non-empty but invalid string". Both cases
    fail the gate, but the caller may want to print different hints.
    """
    for env_name in (API_KEY_ENV, MASTER_API_KEY_ENV):
        raw = env.get(env_name)
        if raw is None:
            continue
        stripped = raw.strip()
        if not stripped:
            continue
        if not _has_supported_key_prefix(stripped):
            continue
        return stripped
    return None


def read_api_key_from_credentials_file(path: Path | str) -> str | None:
    """Return the api_key from a Forge credentials.toml when shape-valid.

    Pure: takes a path (caller passes ``Path("~/.atomadic-forge/credentials.toml")``
    expanded, or a test fixture path), reads the file, parses it as TOML, and
    returns the ``[forge_auth].api_key`` value only when it has a supported
    Forge prefix. Missing file, missing section, missing key, malformed TOML,
    or wrong-shape key all return ``None`` so the caller never sees a
    half-loaded credential.

    Pairs with ``read_api_key_from_env``: the MCP gate tries env first (for
    CI / explicit overrides), then falls back to this so ``forge login`` once
    is enough — every subsequent ``forge mcp serve`` picks the key up.
    """
    p = Path(path)
    if not p.is_file():
        return None
    try:
        body = p.read_text(encoding="utf-8")
    except OSError:
        return None
    try:
        # Python 3.11+ — Forge already requires 3.10+ but tomllib lands at
        # 3.11. Fall back to a tiny line parser when tomllib is missing so
        # we don't add a runtime dependency on tomli for 3.10.
        import tomllib  # noqa: PLC0415
        try:
            data = tomllib.loads(body)
        except tomllib.TOMLDecodeError:
            return None
        section = data.get("forge_auth") if isinstance(data, dict) else None
        raw = section.get("api_key") if isinstance(section, dict) else None
    except ImportError:  # pragma: no cover — Python <3.11 fallback
        raw = None
        in_section = False
        for line in body.splitlines():
            stripped = line.strip()
            if stripped.startswith("#") or not stripped:
                continue
            if stripped == "[forge_auth]":
                in_section = True
                continue
            if stripped.startswith("[") and stripped.endswith("]"):
                in_section = False
                continue
            if in_section and "=" in stripped:
                k, _, v = stripped.partition("=")
                if k.strip() == "api_key":
                    raw = v.strip().strip('"').strip("'")
                    break
    if not isinstance(raw, str):
        return None
    stripped = raw.strip()
    if not stripped or not _has_supported_key_prefix(stripped):
        return None
    return stripped


def is_valid_api_key_shape(key: str) -> bool:
    """Return True when ``key`` looks like a real Forge or Master key.

    Validates a supported Forge prefix AND requires at least one
    character after it (so a bare prefix is rejected). This is the
    cheap pre-check the a2 client runs before the network round trip;
    the verify endpoint owns the authoritative decision.
    """
    if not isinstance(key, str):
        return False
    stripped = key.strip()
    return _has_supported_key_prefix(stripped)


def build_verify_request(api_key: str) -> dict[str, str]:
    """Return the JSON body for a verify POST.

    Pure: just shapes the dict. Encoding to bytes happens in a2 right
    before the urllib call, which lets a2 control content-type headers.
    """
    return {"api_key": api_key}


def parse_verify_response(body: dict[str, Any]) -> VerifyResult:
    """Convert the verify endpoint's JSON body into a strict VerifyResult.

    The remote shape we accept (Lane C W5 v1):

        {
          "ok": true,
          "email": "user@example.com",
          "plan": "pro",
          "reason": ""
        }

    Anything missing falls back to safe defaults (ok=False, empty
    strings). ``cached`` and ``degraded`` are NOT set here — those are
    a2's concern (the client knows whether it's serving a cached or
    degraded result; the parser doesn't).
    """
    if not isinstance(body, dict):
        return VerifyResult(  # type: ignore[typeddict-item]
            ok=False, email="", plan="",
            reason="non-object response from verify endpoint",
        )
    ok_raw = body.get("ok", False)
    ok = bool(ok_raw) if isinstance(ok_raw, bool | int) else False
    email = body.get("email") or ""
    plan = body.get("plan") or ""
    reason = body.get("reason") or ("" if ok else "verify endpoint returned ok=False")
    out: VerifyResult = {  # type: ignore[typeddict-item]
        "ok": ok,
        "email": str(email),
        "plan": str(plan),
        "reason": str(reason),
    }
    return out


def build_usage_log_request(
    api_key: str, tool: str, project_hash: str,
) -> dict[str, str]:
    """Return the JSON body for one usage-log POST.

    The body intentionally never includes the raw project path — the
    caller is expected to pass ``hash_project_path(...)`` so the
    telemetry stream stores opaque hashes, not local FS layouts.
    """
    return {
        "api_key": api_key,
        "tool": tool,
        "project_hash": project_hash,
    }


def hash_project_path(path: str | Path) -> str:
    """Return the SHA-256 hex digest of the resolved absolute path.

    Stable across runs on the same machine, but reveals nothing about
    the user's directory layout to the telemetry endpoint. Unicode
    paths are encoded as UTF-8 before hashing.
    """
    resolved = str(Path(path).resolve())
    return hashlib.sha256(resolved.encode("utf-8")).hexdigest()


__all__ = [
    "build_usage_log_request",
    "build_verify_request",
    "hash_project_path",
    "is_valid_api_key_shape",
    "parse_verify_response",
    "read_api_key_from_credentials_file",
    "read_api_key_from_env",
]
