"""Tier a1 — pure source-extraction helpers for ``forge graft``.

Given a Python source file and a top-level symbol name (function or class),
return the exact source slice for that symbol — with its docstring,
decorators, and trailing whitespace preserved. No imports, no deps,
no I/O beyond the input read. AST-based: deterministic and reproducible.

This is the read-only half of the graft pipeline. The write half lives
in a3 (``graft_feature``) so this module stays a pure-tier-1 helper.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class GraftExtract:
    """One extracted symbol slice ready to drop into a target file.

    * ``symbol_name`` — the bare top-level name (no qualifier dotting).
    * ``kind`` — ``"function"`` (def) | ``"async_function"`` (async def) |
      ``"class"`` (class).
    * ``source`` — the verbatim source slice, INCLUDING any preceding
      decorators and the body. Ends with a trailing newline.
    * ``imports_needed`` — the set of bare module names the symbol's body
      references. Caller resolves these against the source file's import
      table to build the new module's import block.
    * ``start_line`` / ``end_line`` — 1-based line numbers in the source
      file (for diagnostics and lineage).
    """
    symbol_name: str
    kind: str
    source: str
    imports_needed: frozenset[str]
    start_line: int
    end_line: int


def _walk_imports_used(node: ast.AST) -> set[str]:
    """Return the set of bare module names that the AST subtree references.

    Recognizes ``ast.Name`` references (e.g. ``math.sqrt`` → ``math``) and
    ``ast.Attribute`` chains (e.g. ``math.pi`` → ``math``). The result is
    a superset of "names that look like modules" — the caller is
    responsible for filtering against the source file's actual imports.
    """
    used: set[str] = set()
    for sub in ast.walk(node):
        if isinstance(sub, ast.Name):
            used.add(sub.id)
        elif isinstance(sub, ast.Attribute):
            # Walk to the leftmost Name in the attribute chain.
            cur: ast.AST = sub
            while isinstance(cur, ast.Attribute):
                cur = cur.value
            if isinstance(cur, ast.Name):
                used.add(cur.id)
    return used


def _import_table(tree: ast.Module) -> dict[str, str]:
    """Build a mapping from bound name → "import statement source".

    Records every ``import X`` and ``from Y import Z [as W]`` at module
    level. The bound name is what shows up in code; the source is the
    one-liner we'd emit verbatim into the new module. Aliased imports
    (``import numpy as np``) bind ``np``, not ``numpy``.
    """
    table: dict[str, str] = {}
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                bound = alias.asname or alias.name.split(".")[0]
                if alias.asname:
                    table[bound] = f"import {alias.name} as {alias.asname}"
                else:
                    table[bound] = f"import {alias.name}"
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            level = node.level or 0
            prefix = "." * level + module if level or module else ""
            for alias in node.names:
                bound = alias.asname or alias.name
                if alias.asname:
                    table[bound] = (
                        f"from {prefix} import {alias.name} as {alias.asname}"
                    )
                else:
                    table[bound] = f"from {prefix} import {alias.name}"
    return table


def extract_symbol(source_file: Path, symbol_name: str) -> GraftExtract:
    """Extract a top-level function or class slice from ``source_file``.

    Returns a :class:`GraftExtract` carrying the verbatim source plus the
    set of stdlib/third-party imports the symbol's body references that
    are bound at module scope in ``source_file``.

    Raises:
        FileNotFoundError: ``source_file`` does not exist.
        KeyError:          no top-level symbol named ``symbol_name`` was
                           found in the AST. Mismatched casing or nested
                           definitions are not silently substituted.
        SyntaxError:       ``source_file`` does not parse as Python.
    """
    src_path = Path(source_file)
    if not src_path.is_file():
        raise FileNotFoundError(f"graft source not found: {src_path}")
    text = src_path.read_text(encoding="utf-8")
    tree = ast.parse(text, filename=str(src_path))
    lines = text.splitlines(keepends=True)

    target = None
    for node in tree.body:
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef):
            if node.name == symbol_name:
                target = node
                break

    if target is None:
        raise KeyError(
            f"no top-level symbol named {symbol_name!r} in {src_path.name}"
        )

    # AST start_lineno points at the `def`/`class` line. Decorators are
    # stored separately; their source precedes the def by one line each.
    if getattr(target, "decorator_list", None):
        start = min(d.lineno for d in target.decorator_list)
    else:
        start = target.lineno
    end = getattr(target, "end_lineno", start)
    slice_lines = lines[start - 1 : end]
    source = "".join(slice_lines)
    if not source.endswith("\n"):
        source = source + "\n"

    # Resolve imports: walk the symbol body for names used, intersect with
    # the source file's import table. Stdlib refs like ``math.sqrt`` come
    # back as needing ``import math``.
    used = _walk_imports_used(target)
    table = _import_table(tree)
    imports_needed = frozenset(name for name in used if name in table)

    if isinstance(target, ast.AsyncFunctionDef):
        kind = "async_function"
    elif isinstance(target, ast.FunctionDef):
        kind = "function"
    else:
        kind = "class"

    return GraftExtract(
        symbol_name=symbol_name,
        kind=kind,
        source=source,
        imports_needed=imports_needed,
        start_line=start,
        end_line=end,
    )


def render_grafted_module(
    extract: GraftExtract,
    *,
    source_file: Path,
    import_table: dict[str, str] | None = None,
    docstring_prefix: str = "",
) -> str:
    """Render a stand-alone Python module that wraps the extracted symbol.

    The output module:
      * starts with a triple-quoted docstring describing the graft origin;
      * imports only what the symbol body actually uses (resolved via
        ``import_table`` or a fresh scan of ``source_file``);
      * embeds the extracted source slice verbatim.

    The resulting text is ready to write to disk and pass through
    ``forge wire`` / ``forge certify`` without manual edits.
    """
    if import_table is None:
        text = Path(source_file).read_text(encoding="utf-8")
        tree = ast.parse(text)
        import_table = _import_table(tree)

    needed_imports = sorted(
        import_table[name]
        for name in extract.imports_needed
        if name in import_table
    )
    # Skip relative imports — they don't resolve in the new module.
    needed_imports = [imp for imp in needed_imports
                      if not imp.startswith("from .")]

    parts: list[str] = []
    docstring_body = (
        f'"""{docstring_prefix}Grafted from '
        f'{Path(source_file).name} (lines '
        f'{extract.start_line}–{extract.end_line}) by `forge graft`."""'
    )
    parts.append(docstring_body)
    parts.append("from __future__ import annotations")
    parts.append("")
    if needed_imports:
        parts.extend(needed_imports)
        parts.append("")
    # Surface-gap-discoverable: emit a SCHEMA_VERSION_GRAFT_<NAME>
    # constant so the existing entry-point walker recognizes the grafted
    # symbol as a wireable a1 function. Without this, auto-wire skips
    # the graft because the heuristic only inspects modules carrying
    # a structured-output contract marker.
    upper_name = extract.symbol_name.upper().lstrip("_")
    parts.append(
        f'SCHEMA_VERSION_GRAFT_{upper_name} = '
        f'"atomadic-forge.graft.{extract.symbol_name}/v1"'
    )
    parts.append("")
    parts.append(extract.source.rstrip())
    parts.append("")  # trailing newline
    return "\n".join(parts) + "\n"
