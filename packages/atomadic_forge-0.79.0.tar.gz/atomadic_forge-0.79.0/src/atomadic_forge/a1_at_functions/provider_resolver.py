"""Tier a1 — shared LLM provider resolver.

Resolves a user-facing provider name (CLI flag, env var, or
``config.json:provider`` key) to a concrete ``LLMClient`` instance.

Resolution order when ``name`` is a custom provider:
  1. ``config.json:custom_providers[]`` entry whose ``name`` matches
  2. Built-in preset (groq, deepseek, together, fireworks, xai, mistral,
     perplexity, cerebras, hyperbolic, …)  — see
     :mod:`custom_provider_client.PRESETS`
  3. Hardcoded clients (anthropic, openai, gemini, openrouter,
     aaaa-nexus, ollama, stub) for backward compatibility
  4. Raise ``ValueError`` listing every known provider

Custom-provider lookups need a project root for the local config; the
``project_root`` argument lets callers pass it through.  ``None``
falls back to ``Path.cwd()`` so the resolver works in tests and
ad-hoc CLI invocations.
"""

from __future__ import annotations

import os
from pathlib import Path

from .config_io import load_config
from .custom_provider_client import (
    PRESETS,
    CustomProviderClient,
    from_config,
    list_presets,
)
from .llm_client import (
    AAAANexusClient,
    AnthropicClient,
    GeminiClient,
    LLMClient,
    OllamaClient,
    OpenAIClient,
    OpenRouterClient,
    StubLLMClient,
    resolve_default_client,
)

PROVIDER_HELP = (
    "auto | nexus | aaaa-nexus | gemini | anthropic | openai | "
    "openrouter | ling | ollama | stub | <preset> | <custom-name>"
)


def _custom_provider_entry(name: str, project_root: Path | None) -> dict | None:
    """Look up a config-defined custom provider by name."""
    root = project_root or Path.cwd()
    cfg = load_config(root)
    for entry in cfg.get("custom_providers", []) or []:
        if entry.get("name", "").lower() == name.lower():
            return entry
    return None


def _from_preset(preset_name: str) -> CustomProviderClient | None:
    """Build a CustomProviderClient from a built-in preset name."""
    preset = PRESETS.get(preset_name.lower())
    if preset is None:
        return None
    return CustomProviderClient(
        name=preset_name.lower(),
        base_url=preset["base_url"],
        model=preset["model"],
        api_key_env=preset["api_key_env"],
        fmt="openai",
    )


def resolve_provider(name: str = "auto",
                      *,
                      project_root: Path | None = None) -> LLMClient:
    """Resolve a user-facing provider name to an ``LLMClient`` instance.

    Lookup precedence (first match wins):
      1. Hardcoded backward-compat names (auto, anthropic, gemini, openai,
         openrouter, ling, aaaa-nexus, ollama, stub)
      2. ``config.json:custom_providers[]`` entry whose ``name`` matches
      3. Built-in preset (groq, deepseek, together, fireworks, xai,
         mistral, perplexity, cerebras, hyperbolic, …)
      4. ``ValueError`` with the full list of known providers

    Most overrides happen via env var:
      * ``FORGE_<PROVIDER_UPPER>_MODEL`` — e.g. ``FORGE_GROQ_MODEL=…``
      * ``<API_KEY_ENV>``               — e.g. ``GROQ_API_KEY=…``
    """
    provider = (name or "auto").strip().lower()

    # ---- 1. hardcoded backward-compat names -------------------------------
    if provider == "stub":
        return StubLLMClient()
    if provider in ("nexus", "aaaa-nexus", "aaaa_nexus", "helix"):
        return AAAANexusClient()
    if provider in ("anthropic", "claude"):
        return AnthropicClient(model=os.environ.get("FORGE_ANTHROPIC_MODEL",
                                                     "claude-sonnet-4-6"))
    if provider in ("gemini", "google"):
        return GeminiClient(model=os.environ.get("FORGE_GEMINI_MODEL",
                                                  "gemini-2.5-flash"))
    if provider in ("openai", "gpt"):
        return OpenAIClient(model=os.environ.get("FORGE_OPENAI_MODEL",
                                                  "gpt-4o-mini"))
    if provider in ("openrouter", "router"):
        return OpenRouterClient()
    if provider == "ling":
        return OpenRouterClient(model="inclusionai/ling-2.6-1t:free")
    if provider == "ollama":
        return OllamaClient(
            model=os.environ.get("FORGE_OLLAMA_MODEL", "qwen2.5-coder:7b"),
            base_url=os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434"),
        )
    if provider == "auto":
        return resolve_default_client()

    # ---- 2. config-defined custom provider --------------------------------
    entry = _custom_provider_entry(provider, project_root)
    if entry is not None:
        return from_config(entry)

    # ---- 3. built-in preset by name ---------------------------------------
    preset_client = _from_preset(provider)
    if preset_client is not None:
        # Allow env-var override of the preset's default model:
        # FORGE_<PROVIDER>_MODEL.  Lets users keep one preset row but try
        # different models without rewriting config.
        env_model = os.environ.get(f"FORGE_{provider.upper()}_MODEL")
        if env_model:
            preset_client.model = env_model
        return preset_client

    # ---- 4. unknown ----------------------------------------------------
    raise ValueError(
        f"unknown provider: {name!r}; expected one of "
        f"{PROVIDER_HELP}, plus presets {list_presets()}, "
        "or a custom_providers[] entry from config.json"
    )
