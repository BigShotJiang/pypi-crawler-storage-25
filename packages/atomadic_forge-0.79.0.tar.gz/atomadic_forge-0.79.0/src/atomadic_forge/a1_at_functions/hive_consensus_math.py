"""Tier a1 — pure consensus math for the hive sync pipeline.

Vote tallying + quorum check + resolution. No state, no IO; the
orchestrator (a3) feeds events in, this module returns verdicts.

Two-stage:

1. ``tally_votes`` — turn a list of vote events into per-vote counts.
2. ``resolve_consensus`` — given proposal + tally + active-agent
   count, return PASS / REFINE / REJECT / TIMEOUT / PENDING.
"""
from __future__ import annotations

import time
from typing import Any


def tally_votes(events: list[dict[str, Any]]) -> dict[str, Any]:
    """Pure: count votes by voter (latest vote per voter wins).

    A voter who changes their mind has only their latest event count.
    Same voter voting twice with the same value is idempotent.
    """
    latest: dict[str, dict[str, Any]] = {}
    for ev in events:
        if ev.get("kind") != "vote":
            continue
        voter = ev.get("voter")
        if not voter:
            continue
        # Append-only log; later events override earlier.
        latest[voter] = ev
    counts = {"approve": 0, "reject": 0, "refine": 0, "abstain": 0}
    for ev in latest.values():
        v = (ev.get("vote") or "").lower().strip()
        if v in counts:
            counts[v] += 1
        else:
            counts["abstain"] += 1
    return {
        "vote_count": len(latest),
        "counts": counts,
        "voters": sorted(latest.keys()),
    }


def resolve_consensus(
    *,
    proposal: dict[str, Any],
    events: list[dict[str, Any]],
    active_agent_count: int,
    quorum_min: int = 2,
    timeout_secs: int = 3600,
    now_epoch: float | None = None,
) -> dict[str, Any]:
    """Compute the current verdict for a consensus.

    Verdicts:

    * ``PASS`` — quorum met, approves > rejects + refines
    * ``REFINE`` — quorum met, refines > approves and refines > rejects
    * ``REJECT`` — quorum met, rejects > approves
    * ``TIMEOUT`` — past timeout, no quorum
    * ``PENDING`` — within timeout, not enough votes yet
    """
    now_epoch = now_epoch if now_epoch is not None else time.time()
    proposal_ts = proposal.get("timestamp_utc")
    proposal_epoch = _iso_to_epoch(proposal_ts) if proposal_ts else now_epoch

    # Already-resolved? Look for a resolution event in the log.
    for ev in events:
        if ev.get("kind") == "resolution":
            return {
                "verdict": ev.get("payload", {}).get("verdict", "RESOLVED"),
                "resolved_at": ev.get("timestamp_utc"),
                "resolved": True,
                "tally": tally_votes(events),
            }

    tally = tally_votes(events)
    # Quorum: at least quorum_min OR a majority of active agents,
    # whichever is greater (but never higher than active count).
    needed = max(quorum_min, (active_agent_count // 2) + 1)
    needed = min(needed, max(active_agent_count, quorum_min))
    if tally["vote_count"] < needed:
        # No quorum yet. Timed out?
        if (now_epoch - proposal_epoch) > timeout_secs:
            return {
                "verdict": "TIMEOUT",
                "resolved": True,
                "tally": tally,
                "needed": needed,
                "timeout_at_secs": timeout_secs,
            }
        return {
            "verdict": "PENDING",
            "resolved": False,
            "tally": tally,
            "needed": needed,
            "remaining_secs": max(0, timeout_secs - int(now_epoch - proposal_epoch)),
        }

    counts = tally["counts"]
    approve = counts["approve"]
    reject = counts["reject"]
    refine = counts["refine"]
    if approve > (reject + refine):
        verdict = "PASS"
    elif refine > approve and refine >= reject:
        verdict = "REFINE"
    elif reject > approve:
        verdict = "REJECT"
    else:
        # Tie: default to REFINE (defer to deeper review).
        verdict = "REFINE"

    return {
        "verdict": verdict,
        "resolved": True,
        "tally": tally,
        "needed": needed,
    }


def _iso_to_epoch(iso: str) -> float:
    """Best-effort UTC ISO → epoch seconds; returns now() on failure."""
    try:
        return time.mktime(time.strptime(iso, "%Y-%m-%dT%H:%M:%SZ"))
    except (ValueError, TypeError):
        return time.time()
