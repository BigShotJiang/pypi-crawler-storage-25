"""Tier a1 — assemble a wisdom capture draft from session signals.

Pure: given lineage events + trust signals from a verify run, produce
a draft insight + tag suggestions + the auto_record_threshold_met
flag. Caller (verify_umbrella) decides whether to attach this to the
verify response.

No LLM — deterministic templating. The agent reading the prompt
edits the draft into a real insight before calling ``wisdom record``.
"""
from __future__ import annotations

from typing import Any

from ..a0_qk_constants.wisdom_constants import (
    DEFAULT_MIN_LINEAGE_EVENTS,
    DEFAULT_MIN_SCORE_DELTA,
    DEFAULT_MIN_SESSION_SECS,
    SCHEMA_VERSION_WISDOM_CAPTURE_V1,
)


def threshold_met(
    *,
    lineage_event_count: int,
    score_delta: float,
    session_secs: float,
) -> bool:
    """Return True iff trust thresholds for prompting capture are met.

    All three signals are inclusive-OR with floors — meaningful work
    on any one axis crosses the bar. A 30-second doc tweak with
    score_delta=0 and 0 lineage events does NOT prompt; a 6-minute
    code change with 5 lineage events DOES.
    """
    return (
        lineage_event_count >= DEFAULT_MIN_LINEAGE_EVENTS
        or abs(score_delta) >= DEFAULT_MIN_SCORE_DELTA
        or session_secs >= DEFAULT_MIN_SESSION_SECS
    )


def _heuristic_tags(events: list[str]) -> list[str]:
    """Lift candidate tags from common event patterns."""
    tags: set[str] = set()
    for ev in events:
        low = ev.lower()
        if "test" in low:
            tags.add("tests")
        if "wire" in low:
            tags.add("wire")
        if "certify" in low:
            tags.add("certify")
        if "smell" in low:
            tags.add("smell")
        if "verify" in low:
            tags.add("verify")
        if "schema" in low:
            tags.add("schema")
        if "docs/" in low or "doc " in low:
            tags.add("docs")
        if "fix" in low or "bug" in low:
            tags.add("fix")
        if "added" in low:
            tags.add("added")
        if "removed" in low:
            tags.add("removed")
    return sorted(tags)


def _draft_insight(
    *,
    project_name: str,
    score_before: float,
    score_after: float,
    event_count: int,
    sample_events: list[str],
) -> str:
    """Build a one-paragraph draft insight to seed agent capture."""
    delta = score_after - score_before
    if delta > 0:
        direction = f"score moved {score_before:.1f} → {score_after:.1f} (+{delta:.1f})"
    elif delta < 0:
        direction = f"score moved {score_before:.1f} → {score_after:.1f} ({delta:.1f})"
    else:
        direction = f"score held at {score_after:.1f}"
    head = sample_events[:3]
    head_text = "; ".join(head) if head else "no event detail captured"
    return (
        f"In {project_name}: {direction} over {event_count} lineage event(s). "
        f"Notable: {head_text}. "
        f"[Agent: edit this draft with the actual lesson learned, then call "
        f"`forge wisdom record`.]"
    )


def assemble_capture_prompt(
    *,
    project_name: str,
    score_before: float,
    score_after: float,
    lineage_events: list[str],
    session_secs: float,
    trust_signals: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the wisdom_capture_prompt dict that verify can inline.

    Returns a schema-versioned envelope. Always returns a payload
    (never None) — the caller checks ``auto_record_threshold_met``
    to decide whether to surface it.
    """
    score_delta = score_after - score_before
    met = threshold_met(
        lineage_event_count=len(lineage_events),
        score_delta=score_delta,
        session_secs=session_secs,
    )
    return {
        "schema_version": SCHEMA_VERSION_WISDOM_CAPTURE_V1,
        "auto_record_threshold_met": met,
        "suggested_insight": _draft_insight(
            project_name=project_name,
            score_before=score_before,
            score_after=score_after,
            event_count=len(lineage_events),
            sample_events=lineage_events,
        ),
        "draft_tags": _heuristic_tags(lineage_events),
        "lineage_events": lineage_events[:25],
        "score_before": round(float(score_before), 2),
        "score_after": round(float(score_after), 2),
        "score_delta": round(score_delta, 2),
        "session_secs": int(session_secs),
        "trust_signals": dict(trust_signals or {}),
        "next_command": (
            "forge wisdom record --insight \"<edit the suggested draft>\" "
            "--scope repo --tags " + ",".join(_heuristic_tags(lineage_events)[:3])
        ) if met else None,
    }
