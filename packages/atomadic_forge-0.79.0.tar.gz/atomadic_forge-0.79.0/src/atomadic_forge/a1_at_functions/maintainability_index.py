"""Tier a1 — maintainability index: composite per-module quality metric.

Synthesised from radon (rubik/radon) — MIT license.
The Maintainability Index (MI) combines cyclomatic complexity, Halstead
volume, and SLOC into a single score:

    MI = 171 - 5.2 * ln(V) - 0.23 * CC - 16.2 * ln(LOC)

Scores:
  ≥ 65 — high maintainability (green)
  20–64 — medium maintainability (yellow)
  < 20  — low maintainability, technical debt (red)

Pure: read-only AST walks.  No LLM, no I/O beyond source reads.
"""
from __future__ import annotations

import ast
import math
from pathlib import Path
from typing import Any

SCHEMA_VERSION_MAINTAINABILITY_V1 = "atomadic-forge.maintainability/v1"

# Halstead operators for Python
_OPERATORS = frozenset({
    "Add", "Sub", "Mult", "Div", "FloorDiv", "Mod", "Pow", "BitAnd",
    "BitOr", "BitXor", "LShift", "RShift", "And", "Or", "Not", "Invert",
    "UAdd", "USub", "Eq", "NotEq", "Lt", "LtE", "Gt", "GtE",
    "Is", "IsNot", "In", "NotIn", "If", "IfExp",
})


def _cyclomatic_complexity(tree: ast.AST) -> int:
    """McCabe complexity — count branching nodes."""
    cc = 1  # base path
    for node in ast.walk(tree):
        if isinstance(node, ast.If | ast.While | ast.For | ast.ExceptHandler
                             | ast.With | ast.Assert | ast.comprehension):
            cc += 1
        elif isinstance(node, ast.BoolOp):
            cc += len(node.values) - 1
    return cc


def _halstead_volume(tree: ast.AST) -> float:
    """Approximate Halstead volume V = N * log2(n) where N=total, n=unique."""
    operators: list[str] = []
    operands: list[str] = []
    for node in ast.walk(tree):
        t = type(node).__name__
        if t in _OPERATORS:
            operators.append(t)
        elif isinstance(node, ast.Name):
            operands.append(node.id)
        elif isinstance(node, ast.Constant):
            operands.append(str(node.value)[:20])
        elif isinstance(node, ast.FunctionDef):
            operators.append("def")
            operands.append(node.name)
        elif isinstance(node, ast.ClassDef):
            operators.append("class")
            operands.append(node.name)
    N = len(operators) + len(operands)
    n = len(set(operators)) + len(set(operands))
    if N == 0 or n < 2:
        return 0.0
    return N * math.log2(n)


def _sloc(source: str) -> int:
    """Source lines of code (non-blank, non-comment)."""
    count = 0
    for line in source.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            count += 1
    return max(count, 1)


def _mi_score(volume: float, cc: int, loc: int) -> float:
    """Maintainability Index formula (Microsoft variant, clamped 0-100)."""
    if volume <= 0 or loc <= 0:
        return 100.0
    raw = 171 - 5.2 * math.log(volume) - 0.23 * cc - 16.2 * math.log(loc)
    return max(0.0, min(100.0, raw * 100 / 171))


def _mi_rank(score: float) -> str:
    if score >= 65:
        return "A"
    elif score >= 40:
        return "B"
    elif score >= 20:
        return "C"
    return "D"


def compute_maintainability_index(
    project_root: Path,
    *,
    package: str | None = None,
    top_n: int = 15,
) -> dict[str, Any]:
    """Compute the Maintainability Index per Python module.

    Args:
        project_root: Repository root.
        package: Package subdirectory to scan. Auto-detected if None.
        top_n: Number of worst-ranked modules to surface.

    Returns dict with ``schema_version``, ``modules`` list (worst first),
    ``avg_mi``, ``median_mi``, and count breakdowns by rank (A/B/C/D).
    """
    root = Path(project_root).resolve()
    src = root / "src"
    if package:
        pkg_dir = (src / package) if src.is_dir() else (root / package)
    else:
        pkg_dir = None
        for candidate in ([src] if src.is_dir() else [root]):
            for sub in sorted(candidate.iterdir()):
                if sub.is_dir() and (sub / "__init__.py").exists():
                    pkg_dir = sub
                    break
            if pkg_dir:
                break
    if pkg_dir is None or not pkg_dir.is_dir():
        return {
            "schema_version": SCHEMA_VERSION_MAINTAINABILITY_V1,
            "available": False,
            "reason": "package directory not found",
        }

    modules: list[dict] = []
    for py in sorted(pkg_dir.rglob("*.py")):
        if py.name.startswith("_") and py.name != "__init__.py":
            continue
        try:
            source = py.read_text(encoding="utf-8", errors="replace")
            tree = ast.parse(source)
        except (OSError, SyntaxError):
            continue
        volume = _halstead_volume(tree)
        cc = _cyclomatic_complexity(tree)
        loc = _sloc(source)
        mi = _mi_score(volume, cc, loc)
        rel = str(py.relative_to(root))
        modules.append({
            "path": rel,
            "mi_score": round(mi, 1),
            "rank": _mi_rank(mi),
            "cc": cc,
            "sloc": loc,
            "halstead_volume": round(volume, 1),
        })

    if not modules:
        return {
            "schema_version": SCHEMA_VERSION_MAINTAINABILITY_V1,
            "available": False,
            "reason": "no Python modules found",
        }

    modules.sort(key=lambda m: m["mi_score"])
    scores = [m["mi_score"] for m in modules]
    avg_mi = round(sum(scores) / len(scores), 1)
    median_mi = sorted(scores)[len(scores) // 2]
    ranks = {r: sum(1 for m in modules if m["rank"] == r) for r in "ABCD"}

    return {
        "schema_version": SCHEMA_VERSION_MAINTAINABILITY_V1,
        "available": True,
        "package": pkg_dir.name,
        "modules_scanned": len(modules),
        "avg_mi": avg_mi,
        "median_mi": median_mi,
        "rank_distribution": ranks,
        "worst_modules": modules[:top_n],
        "best_modules": list(reversed(modules))[:top_n],
    }
