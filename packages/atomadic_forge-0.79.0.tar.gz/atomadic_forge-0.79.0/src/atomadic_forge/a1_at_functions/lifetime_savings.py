"""Tier a1 — lifetime token-savings ledger I/O.

Best-effort by design: a missing or malformed ledger never crashes
the caller; it returns a zero total. The append path swallows OSError
so an unwriteable .atomadic-forge/ never breaks a tool response.
"""
from __future__ import annotations

import datetime as _dt
import json
from pathlib import Path
from typing import Any

from ..a0_qk_constants.lifetime_savings_constants import (
    LIFETIME_LEDGER_REL,
    SCHEMA_VERSION_LIFETIME_SAVINGS_V1,
)


def _ledger_path(project_root: Path) -> Path:
    return Path(project_root) / LIFETIME_LEDGER_REL


def append_savings(
    *,
    project_root: Path,
    tool: str,
    tokens_saved: int,
    timestamp: str | None = None,
) -> bool:
    """Append one entry to the ledger. Returns True on success.

    Best-effort: any OSError (read-only fs, missing parent we can't
    create, etc.) returns False without raising — the caller's tool
    response must not depend on this side effect.
    """
    if tokens_saved <= 0 or not tool:
        return False
    ts = timestamp or _dt.datetime.now(_dt.timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%SZ",
    )
    entry = {
        "schema_version": SCHEMA_VERSION_LIFETIME_SAVINGS_V1,
        "timestamp": ts,
        "tool": str(tool),
        "tokens_saved": int(tokens_saved),
    }
    path = _ledger_path(project_root)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry) + "\n")
        return True
    except OSError:
        return False


def read_savings_summary(
    *,
    project_root: Path,
) -> dict[str, Any]:
    """Sum the ledger and return a summary block.

    Returns ``{ledger_present, entry_count, tokens_saved_lifetime,
    by_tool, first_seen_at, last_seen_at}``. Malformed lines are
    silently skipped.
    """
    path = _ledger_path(project_root)
    out = {
        "schema_version": SCHEMA_VERSION_LIFETIME_SAVINGS_V1,
        "ledger_present": False,
        "entry_count": 0,
        "tokens_saved_lifetime": 0,
        "by_tool": {},
        "first_seen_at": None,
        "last_seen_at": None,
        "ledger_file": str(path),
    }
    if not path.is_file():
        return out
    out["ledger_present"] = True
    by_tool: dict[str, int] = {}
    total = 0
    count = 0
    first_ts: str | None = None
    last_ts: str | None = None
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                entry = json.loads(line)
            except ValueError:
                continue
            n = entry.get("tokens_saved", 0)
            if not isinstance(n, int | float) or n <= 0:
                continue
            tool = str(entry.get("tool", "?"))
            ts = entry.get("timestamp")
            n = int(n)
            total += n
            count += 1
            by_tool[tool] = by_tool.get(tool, 0) + n
            if isinstance(ts, str):
                if first_ts is None or ts < first_ts:
                    first_ts = ts
                if last_ts is None or ts > last_ts:
                    last_ts = ts
    except OSError:
        return out
    out["entry_count"] = count
    out["tokens_saved_lifetime"] = total
    out["by_tool"] = by_tool
    out["first_seen_at"] = first_ts
    out["last_seen_at"] = last_ts
    return out


__all__ = ["append_savings", "read_savings_summary"]
