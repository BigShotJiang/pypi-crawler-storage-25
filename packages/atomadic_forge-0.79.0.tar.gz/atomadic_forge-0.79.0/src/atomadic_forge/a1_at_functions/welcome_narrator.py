"""Tier a1 — pure welcome narrator.

Takes the structured outputs of scout + certify + wire and builds the
welcome response: a strengths list, a priorities list, a one-line
health label, a "next call" suggestion, and a multi-line narrative
text block. Pure: no I/O, no LLM. Every claim it emits is derived
from a number that came in via the inputs.
"""
from __future__ import annotations

from typing import Any

from ..a0_qk_constants.welcome_constants import (
    HEALTH_LABEL_THRESHOLDS,
    TOP_N_PRIORITIES,
    TOP_N_STRENGTHS,
)


def health_label_for(score: float | int | None) -> str:
    """Return the one-word health label for a certify score."""
    if score is None:
        return "unknown"
    s = float(score)
    for threshold, label in HEALTH_LABEL_THRESHOLDS:
        if s >= threshold:
            return label
    return "early"


def detect_strengths(
    *,
    scout: dict[str, Any] | None,
    certify: dict[str, Any] | None,
    wire: dict[str, Any] | None,
) -> list[str]:
    """Surface up to TOP_N_STRENGTHS specific things the repo does well.

    Each strength is a complete factual sentence with a number from
    the actual scan. Used to anchor the agent's confidence on
    something real before the priorities list lands.
    """
    out: list[str] = []
    cert = certify or {}
    sc = scout or {}
    wr = wire or {}

    score = cert.get("score")
    if isinstance(score, int | float) and score >= 95:
        out.append(
            f"Certify score {score:g}/100 — architecture passes every "
            f"axis at production-ready threshold."
        )
    if wr.get("verdict") == "PASS" and wr.get("violation_count", 0) == 0:
        sym = sc.get("symbol_count", 0)
        out.append(
            f"Zero upward-import violations across {sym} symbols — "
            f"the 5-tier law holds end-to-end."
        )
    dist = sc.get("tier_distribution") or {}
    a1 = dist.get("a1_at_functions", 0)
    total = sum(dist.values()) or 1
    a1_pct = a1 / total
    if a1_pct >= 0.40:
        out.append(
            f"a1_at_functions holds {a1_pct:.0%} of symbols ({a1}) — "
            f"strong pure-function foundation."
        )
    eff = sc.get("effect_distribution") or {}
    pure = eff.get("pure", 0)
    eff_total = sum(eff.values()) or 1
    if pure / eff_total >= 0.85:
        out.append(
            f"{pure / eff_total:.0%} of symbols classified pure — "
            f"the side-effect surface is small and contained."
        )
    if cert.get("ci_workflow_present") is True:
        out.append(
            "CI workflow present — every push is gated by Forge "
            "self-certify."
        )
    if cert.get("changelog_present") is True:
        out.append(
            "CHANGELOG present and current — release lineage is intact."
        )
    return out[:TOP_N_STRENGTHS]


def detect_priorities(
    *,
    scout: dict[str, Any] | None,
    certify: dict[str, Any] | None,
    wire: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    """Surface up to TOP_N_PRIORITIES actionable next steps.

    Each priority is a dict with ``what`` (the issue) and ``why``
    (the reason it matters), so the agent can pick one and act.
    """
    out: list[dict[str, Any]] = []
    cert = certify or {}
    wr = wire or {}

    n_violations = wr.get("violation_count", 0)
    if n_violations:
        first = (wr.get("violations") or [{}])[0]
        out.append({
            "what": (
                f"Resolve {n_violations} upward-import violation(s); "
                f"first: {first.get('file', '?')} ({first.get('from_tier', '?')}) "
                f"-> {first.get('to_tier', '?')}.{first.get('imported', '?')}"
            ),
            "why": (
                "Upward imports break the tier law and prevent any "
                "lower tier from being independently importable."
            ),
            "next_call": "forge wire <repo> --suggest-repairs",
        })

    recs = cert.get("recommendations") or []
    for rec in recs[: max(0, TOP_N_PRIORITIES - len(out))]:
        line = str(rec).split("\n")[0][:160]
        out.append({
            "what": line,
            "why": (
                "Lifts the certify score component this hint targets; "
                "see `forge certify --json` for the axis breakdown."
            ),
            "next_call": "forge certify <repo> --json",
        })

    star = wr.get("star_import_warnings") or []
    if star and len(out) < TOP_N_PRIORITIES:
        out.append({
            "what": (
                f"Replace {len(star)} `from .X import *` with explicit "
                f"name lists to keep the import contract enumerable."
            ),
            "why": (
                "Wildcard imports defeat static dependency analysis "
                "and hide breakage when an exported name disappears."
            ),
            "next_call": "forge wire <repo> --strict-cycles",
        })

    return out[:TOP_N_PRIORITIES]


def suggest_next_call(
    *,
    certify: dict[str, Any] | None,
    wire: dict[str, Any] | None,
) -> str:
    """Pick the single most useful next command for the agent."""
    wr = wire or {}
    cert = certify or {}
    if wr.get("violation_count", 0):
        return "forge wire . --suggest-repairs --json"
    score = cert.get("score")
    if isinstance(score, int | float) and score < 85:
        return "forge certify . --json"
    return "forge emergent scan --src-root src --package <pkg> --json"


def build_narrative(
    *,
    repo_name: str,
    scout: dict[str, Any] | None,
    certify: dict[str, Any] | None,
    wire: dict[str, Any] | None,
    strengths: list[str],
    priorities: list[dict[str, Any]],
    next_call: str,
    forge_version: str,
    tool_count: int,
    diff: dict[str, Any] | None = None,
    lifetime_savings: dict[str, Any] | None = None,
    session_savings: int = 0,
) -> str:
    """Build the multi-line text block.

    The voice is intentionally even — observed numbers, no
    enthusiasm padding, no marketing claims. Every line ends in a
    fact the caller can verify against the scan.
    """
    sc = scout or {}
    cert = certify or {}
    wr = wire or {}
    primary = sc.get("primary_language", "unknown")
    sym = sc.get("symbol_count", 0)
    score = cert.get("score")
    label = health_label_for(score)
    verdict = wr.get("verdict", "?")
    n_violations = wr.get("violation_count", 0)

    lines: list[str] = []
    lines.append(f"Atomadic Forge v{forge_version} — armed and ready.")
    lines.append("")
    lines.append(
        f"Repo: {repo_name} ({primary} primary, {sym} symbols, "
        f"{len(sc.get('tier_distribution') or {})} tiers)."
    )
    if score is not None:
        lines.append(
            f"Health: {score:g}/100 ({label}). "
            f"Wire: {verdict}, {n_violations} violations."
        )
    # Returning-user welcome — surface the diff if a prior scan exists.
    if diff:
        delta = diff.get("score_delta")
        if isinstance(delta, int | float):
            sign = "+" if delta >= 0 else ""
            arrow = "↑" if delta > 0 else ("↓" if delta < 0 else "→")
            tag = " (auto-discovered)" if diff.get("auto_discovered") else ""
            lines.append("")
            lines.append(
                f"Welcome back. Since last scan{tag}: "
                f"score {sign}{delta:g} {arrow} "
                f"({diff.get('prior_score')} → {diff.get('current_score')})."
            )
    if strengths:
        lines.append("")
        lines.append("What's working:")
        for s in strengths:
            lines.append(f"  - {s}")
    elif score is not None and score < 95:
        # No automatic strengths fired — say so honestly, anchor the
        # reader on what Forge CAN see rather than leaving silence.
        lines.append("")
        lines.append(
            "What's working: nothing crossed the auto-strength threshold "
            "this scan. That's a signal to look at the priorities below — "
            "Forge is showing you the highest-leverage moves first."
        )
    if priorities:
        lines.append("")
        lines.append(
            "Priorities (highest leverage first — each comes with a "
            "concrete next call you can run yourself):"
        )
        for p in priorities:
            lines.append(f"  - {p['what']}")
            lines.append(f"    Why: {p['why']}")
            if p.get("next_call"):
                lines.append(f"    Try: {p['next_call']}")
    elif score is not None and score < 95:
        lines.append("")
        lines.append(
            "Priorities: no specific blockers surfaced — the score is "
            f"capped at {score:g}/100 by the axes already shown above."
        )
    lines.append("")
    lines.append(
        f"Available now: {tool_count} MCP tools, organized by job:"
    )
    lines.append("  - Map the repo:        recon, context_pack, explain_repo")
    lines.append("  - Get a verdict:       certify, wire, verify")
    lines.append("  - Fix things safely:   preflight_change, auto, rollback_plan")
    lines.append("  - Discover patterns:   emergent_scan, synergy_scan")
    lines.append("  - Coordinate agents:   wisdom_*, hive_*, handoff_create")
    lines.append("")
    lines.append("Safety net (every call honors these):")
    lines.append(
        "  - Read-only by default. Nothing writes without --apply."
    )
    lines.append(
        "  - Deterministic — same repo, same verdict, every time."
    )
    lines.append(
        "  - Every write emits a signed receipt; rollback_plan inverts it."
    )
    lines.append("")
    lines.append(f"Suggested next call: {next_call}")
    # Lifetime savings — only surface if there's at least 2 sessions of
    # data, so first-time users don't see a near-zero number that would
    # undersell the feature.
    if (lifetime_savings
            and lifetime_savings.get("entry_count", 0) >= 2
            and lifetime_savings.get("tokens_saved_lifetime", 0) > 0):
        total = lifetime_savings["tokens_saved_lifetime"]
        sessions = lifetime_savings["entry_count"]
        lines.append("")
        lines.append(
            f"Lifetime savings (this repo): ~{total:,} tokens across "
            f"{sessions} Forge sessions. (Heuristic — see "
            f"`scope.tokens_saved_basis` in any tool response.)"
        )
    lines.append("")
    lines.append(
        "The repo is in good hands. Explore freely — Forge is the "
        "safety net under every move."
    )
    return "\n".join(lines)


def build_capability_showcase() -> dict[str, list[dict[str, str]]]:
    """Curated tour of Forge's most powerful surfaces, grouped by job.

    Every entry is a (name, when_to_use) pair, NOT a full tool list —
    a first-time agent shouldn't drown in 66 tools, it should see
    "here are the 12 you'll reach for first." Each ``next_call`` is
    a copy-pasteable command.
    """
    return {
        "map_the_repo": [
            {
                "name": "recon",
                "what": "Walk the repo, classify every public symbol "
                         "into its 5-tier home, return a structured "
                         "scout report.",
                "when": "First time you're meeting a codebase.",
                "next_call": "forge recon . --json",
            },
            {
                "name": "context_pack",
                "what": "First-call repo bundle — score, blockers, "
                         "risky files, best next action.",
                "when": "You want one bounded context blob to anchor "
                         "your next 5 turns.",
                "next_call": "forge context-pack . --focus orient",
            },
            {
                "name": "explain_repo",
                "what": "Plain-language summary of what the repo does "
                         "and how it's organized.",
                "when": "The user asks 'what is this codebase?'",
                "next_call": "forge mcp serve  # then call explain_repo",
            },
        ],
        "get_a_verdict": [
            {
                "name": "certify",
                "what": "Score the repo 0–100 across documentation, "
                         "tests, layout, imports, importability, CI, "
                         "and changelog. Deterministic — re-runs are "
                         "reproducible.",
                "when": "Before any non-trivial commit; after any "
                         "non-trivial change.",
                "next_call": "forge certify . --fail-under 75",
            },
            {
                "name": "wire",
                "what": "Scan for upward-import violations of the "
                         "5-tier law. Polyglot (Python + JS + TS).",
                "when": "Anything below ai-generated code touched the "
                         "repo; before merging.",
                "next_call": "forge wire src/<pkg> --suggest-repairs",
            },
            {
                "name": "verify",
                "what": "Composite go/no-go gate: wire + certify + "
                         "score_patch + preflight + optional "
                         "exported-API drift check.",
                "when": "The 'should this ship?' moment.",
                "next_call": "forge verify --fail-under 75",
            },
        ],
        "fix_things_safely": [
            {
                "name": "preflight_change",
                "what": "Score a diff BEFORE you apply it. Tells you "
                         "whether the change will lift or drop the "
                         "certify score, with axis-level breakdown.",
                "when": "You're about to apply a patch and want a "
                         "no-regret confidence check.",
                "next_call": "forge preflight <repo> --diff /tmp/x.diff",
            },
            {
                "name": "auto",
                "what": "End-to-end pipeline: scout → cherry → "
                         "assimilate → wire → certify. Outputs a "
                         "tier-organized package.",
                "when": "You inherited a messy repo and want a "
                         "structured rewrite to compose against.",
                "next_call": "forge auto --target <messy> --output <clean> "
                              "--package my_pkg --apply",
            },
            {
                "name": "rollback_plan",
                "what": "Every Forge action records a receipt; "
                         "rollback emits the inverse plan.",
                "when": "Something looks off; you want to back out "
                         "before you commit.",
                "next_call": "forge mcp serve  # then call rollback_plan",
            },
        ],
        "discover_patterns": [
            {
                "name": "emergent_scan",
                "what": "Surface compositions that already exist in "
                         "the catalog but haven't been named as a "
                         "feature yet. Top-N ranked.",
                "when": "You want to find the next abstraction the "
                         "code is asking for.",
                "next_call": "forge emergent scan --src-root src "
                              "--package <pkg>",
            },
            {
                "name": "synergy_scan",
                "what": "Pair-detection: feature/CLI surfaces that "
                         "should be wired together but aren't.",
                "when": "You suspect there's a gap between two "
                         "subsystems that talk past each other.",
                "next_call": "forge synergy scan --src-root src",
            },
        ],
        "coordinate_with_others": [
            {
                "name": "wisdom_record / wisdom_query",
                "what": "Cross-session institutional memory — append "
                         "lessons learned, query later from any agent.",
                "when": "You learned something the next agent needs "
                         "to know without re-deriving.",
                "next_call": "forge wisdom record -i 'lesson here' "
                              "--scope repo --tags drift,worker",
            },
            {
                "name": "hive_propose / hive_vote / hive_result",
                "what": "Multi-agent consensus over append-only "
                         "public artifacts. No direct messaging.",
                "when": "You're one of N agents and a decision needs "
                         "structured deliberation.",
                "next_call": "forge hive propose --intent 'X' "
                              "--proposer <agent>",
            },
            {
                "name": "handoff_create",
                "what": "Structured agent-to-agent session transfer. "
                         "Writes JSON the next agent reads on first "
                         "turn.",
                "when": "You're ending a session with non-trivial "
                         "work in flight.",
                "next_call": "forge handoff create --agent <id> "
                              "--work 'a;b' --pending 'c'",
            },
        ],
    }


def safety_net_summary() -> list[str]:
    """The reassurance bullets every first-time user / agent should see.

    Each line is a real Forge guarantee, not aspirational. If
    anything here becomes inaccurate, fix the bullet, don't soften.
    """
    return [
        "Every Forge analysis is deterministic — same repo, same "
        "verdict every time. No LLM in the certify path.",
        "Forge never writes to your repo unless you pass --apply. "
        "Plans, scouts, and certify are read-only by default.",
        "Every action that does write emits a signed receipt; "
        "rollback_plan can synthesize the inverse.",
        "Tier violations and stub bodies are caught BEFORE they "
        "merge — preflight_change scores any diff in milliseconds.",
        "Forge holds zero LLM clients itself. Your agent drives the "
        "model; Forge supplies the certainty layer.",
    ]


def build_agent_guidance(
    *,
    repo_name: str,
    scout: dict[str, Any] | None,
    certify: dict[str, Any] | None,
    wire: dict[str, Any] | None,
    strengths: list[str],
    priorities: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build the user-facing reassurance guidance the AGENT will use.

    The welcome response goes to the agent. The agent then talks to
    the human developer. This block is "what to say to your user,
    grounded in the scan you just got, in your own voice."

    Voice contract: confident, specific, never sycophantic. Every
    bullet must cite a number from the actual scan or name a
    Forge guarantee. No marketing claims, no promises Forge can't
    keep, no "OMFG" framing.
    """
    cert = certify or {}
    sc = scout or {}
    wr = wire or {}

    score = cert.get("score")
    n_violations = wr.get("violation_count", 0)
    sym = sc.get("symbol_count", 0)
    primary = sc.get("primary_language", "this codebase")

    # Lead — the single most reassuring true sentence about the repo.
    if isinstance(score, int | float) and score >= 95 and n_violations == 0:
        lead = (
            f"Open with: their {primary} codebase scored {score:g}/100 "
            f"on every architectural axis, with zero upward-import "
            f"violations across {sym} symbols. That's a deterministic "
            f"verdict from Forge's checker — not a vibe."
        )
    elif isinstance(score, int | float) and score >= 75:
        lead = (
            f"Open with: their {primary} codebase scored {score:g}/100. "
            f"The structure is sound; the {n_violations} flagged "
            f"item(s) are concrete and fixable, not architectural debt."
        )
    elif isinstance(score, int | float):
        lead = (
            f"Open honestly: their codebase scored {score:g}/100. "
            f"Don't sugar-coat it — but frame Forge as the tool that "
            f"will close the gap measurably, axis by axis."
        )
    else:
        lead = (
            "Open with: Forge has just mapped the repo end-to-end. "
            "Use the strengths list as the reassurance anchor and "
            "the priorities list as the joint plan."
        )

    # Tone — what the agent should keep in mind across the whole turn.
    tone = (
        "Confident, grounded in the numbers. The user is paying "
        "attention. Cite specifics, not generalities. Treat Forge's "
        "verdict as something you stand behind because it's "
        "deterministic and reproducible — every check can be re-run "
        "on demand."
    )

    # Reassurance points — bullets the agent can quote verbatim or
    # reframe in its own voice.
    reassurance: list[str] = []
    if isinstance(score, int | float) and score >= 95:
        reassurance.append(
            f"Forge's score of {score:g}/100 is reproducible — re-run "
            f"`forge certify .` and the user gets the same number."
        )
    if wr.get("verdict") == "PASS":
        reassurance.append(
            f"The 5-tier import law holds across {sym} symbols. No "
            f"hidden upward dependencies, no circular surprises."
        )
    if cert.get("ci_workflow_present") is True:
        reassurance.append(
            "Forge re-certifies on every CI push, so this verdict "
            "stays current automatically."
        )
    reassurance.append(
        "Forge ran this scan in milliseconds; the user can re-verify "
        "any claim in real time without waiting on an LLM."
    )

    # How to handle priorities, framed as opportunities not problems.
    if priorities:
        priority_framing = (
            f"Mention the {len(priorities)} priority item(s) as "
            f"specific, scoped work — not as 'things wrong with the "
            f"codebase'. Each one has a concrete next call the user "
            f"can run themselves."
        )
    else:
        priority_framing = (
            "Nothing urgent surfaced. If the user asks 'what's next?', "
            "the natural answer is `forge emergent scan` to look for "
            "compositional patterns worth synthesizing."
        )

    return {
        "lead": lead,
        "tone": tone,
        "reassurance_points": reassurance,
        "priority_framing": priority_framing,
        "voice_contract": (
            "Use the agent's own voice. Don't read this block "
            "verbatim — it's the briefing, not the script."
        ),
    }


__all__ = [
    "build_agent_guidance",
    "build_capability_showcase",
    "build_narrative",
    "detect_priorities",
    "detect_strengths",
    "health_label_for",
    "safety_net_summary",
    "suggest_next_call",
]
