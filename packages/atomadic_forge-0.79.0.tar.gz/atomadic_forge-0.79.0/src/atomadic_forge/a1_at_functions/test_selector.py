"""Tier a1 — select_tests: per-intent test selection (Codex #7).

Codex's prescription:

  > Agents over-run tests or under-run them. Add select_tests({
  >   changed_files, intent }). Returns minimum test set, full-
  >   confidence test set, commands, why those tests matter.

Pure: takes paths + intent, walks tests/ to match by name + path
heuristics. The 'minimum' set is the mirror-style direct match
(tests/test_<stem>.py); the 'full' set adds tier-mate tests + any
tests under the proposed file's tier.
"""
from __future__ import annotations

from pathlib import Path
from typing import TypedDict

from .validation_commands import (
    command_for_selected_tests,
    has_javascript_tests,
    is_non_code_artifact,
    preferred_full_test_command,
)

SCHEMA_VERSION_TEST_SELECT_V1 = "atomadic-forge.test_select/v1"

_TIER_NAMES = (
    "a0_qk_constants", "a1_at_functions", "a2_mo_composites",
    "a3_og_features", "a4_sy_orchestration",
)


class TestSelection(TypedDict, total=False):
    schema_version: str
    intent: str
    changed_files: list[str]
    minimum_tests: list[str]
    full_tests: list[str]
    minimum_command: str
    full_command: str
    rationale: list[str]


def _detect_tier(path: str) -> str | None:
    for part in path.split("/"):
        if part in _TIER_NAMES:
            return part
    return None


def _list_tests(project_root: Path) -> list[str]:
    candidates: list[str] = []
    for sub in ("tests", "test"):
        d = project_root / sub
        if not d.is_dir():
            continue
        for f in sorted(d.rglob("test_*.py")):
            candidates.append(str(f.relative_to(project_root).as_posix()))
        for f in sorted(d.rglob("*_test.py")):
            candidates.append(str(f.relative_to(project_root).as_posix()))
        for pattern in ("*.test.js", "*.spec.js", "*.test.mjs", "*.spec.mjs",
                        "*.test.cjs", "*.spec.cjs", "*.test.ts", "*.spec.ts",
                        "*.test.tsx", "*.spec.tsx", "*.test.jsx", "*.spec.jsx"):
            for f in sorted(d.rglob(pattern)):
                candidates.append(str(f.relative_to(project_root).as_posix()))
    return sorted(set(candidates))


def select_tests(
    *,
    intent: str,
    changed_files: list[str],
    project_root: Path,
) -> TestSelection:
    """Compute minimum + full test sets for a proposed change."""
    project_root = Path(project_root).resolve()
    all_tests = _list_tests(project_root)
    minimum: set[str] = set()
    full: set[str] = set()
    rationale: list[str] = []
    saw_code_file = False

    for path in changed_files:
        if is_non_code_artifact(path):
            rationale.append(
                f"{path} is a non-code artifact; no mirror test is required."
            )
            continue
        saw_code_file = True
        stem = Path(path).stem
        tier = _detect_tier(path)
        # Direct mirror match
        for t in all_tests:
            tname = Path(t).stem
            if tname in (f"test_{stem}", f"{stem}_test"):
                minimum.add(t)
                full.add(t)
        # Tier-mate matches
        if tier:
            for t in all_tests:
                if f"/{tier}/" in t or t.endswith(f"/{tier}"):
                    full.add(t)
        # Any test mentioning the full stem gets into full.
        for t in all_tests:
            if stem and stem in Path(t).stem and stem != Path(t).stem:
                full.add(t)
        # Stem-component matches: significant tokens from underscore-compound
        # stems catch test files like test_certify_operational_axis for
        # certify_checks.py. Only tokens ≥6 chars to skip noise ("mcp", "at").
        stem_tokens = [tok for tok in stem.split("_") if len(tok) >= 6]
        for t in all_tests:
            tname = Path(t).stem
            if any(tok in tname for tok in stem_tokens):
                full.add(t)
    if not minimum and all_tests and saw_code_file:
        # No mirror match — the safe minimum is full + a clear note.
        rationale.append(
            "no mirror-name test match for any changed file; "
            "minimum_tests promoted to the full set so coverage is "
            "preserved."
        )
        minimum = set(full or all_tests)
    if not full and saw_code_file:
        full = set(all_tests)
        rationale.append(
            "no tier-mate matches found; full_tests defaulted to the "
            "complete tests/ tree."
        )
    elif not full and all_tests:
        full = set(all_tests)
    rationale.append(
        f"intent: {intent[:200]}" if intent
        else "no intent provided — selection is path-based only."
    )

    minimum_list = sorted(minimum)
    full_list = sorted(full)
    return TestSelection(
        schema_version=SCHEMA_VERSION_TEST_SELECT_V1,
        intent=intent,
        changed_files=list(changed_files),
        minimum_tests=minimum_list,
        full_tests=full_list,
        minimum_command=(
            command_for_selected_tests(project_root, minimum_list)
            if minimum_list else preferred_full_test_command(project_root)
        ),
        full_command=(
            preferred_full_test_command(project_root)
            if has_javascript_tests(project_root)
            else command_for_selected_tests(project_root, full_list)
        ),
        rationale=rationale,
    )
