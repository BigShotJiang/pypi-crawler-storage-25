"""Tier a1 — pure helpers for the absorb-any-repo pipeline."""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path

from ..a0_qk_constants.lang_extensions import ALL_SOURCE_EXTS

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - py3.10 fallback
    tomllib = None  # type: ignore[assignment]

_TIER_DIR_NAMES = (
    "a0_qk_constants",
    "a1_at_functions",
    "a2_mo_composites",
    "a3_og_features",
    "a4_sy_orchestration",
)
_SKIP_DIRS = frozenset({
    ".git", ".github", ".venv", "venv", "env", ".env",
    "__pycache__", ".pytest_cache", ".ruff_cache", ".mypy_cache",
    "node_modules", "dist", "build", ".tox", "htmlcov",
    ".atomadic-forge", "eggs", ".eggs",
    "tests", "test", "testing", "benchmarks",
    "examples", "scripts", "tools", "fixtures", "conftest",
})


class RepoLayout(str):
    ATOMADIC_TIER = "atomadic_tier"
    SRC_LAYOUT = "src_layout"
    MONOREPO_LIB = "monorepo_lib"
    MULTI_LIB = "multi_lib"
    FLAT = "flat"
    FLAT_MODULES = "flat_modules"
    NODE_PACKAGE = "node_package"
    GO_MODULE = "go_module"
    RUST_CRATE = "rust_crate"
    POLYGLOT_SOURCE = "polyglot_source"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class ResolvedRepo:
    src_root: Path
    package_name: str
    layout: str
    repo_root: Path


def _has_tier_folders(p: Path) -> bool:
    return any((p / n).is_dir() for n in _TIER_DIR_NAMES)


def _is_python_package(p: Path) -> bool:
    return p.is_dir() and (p / "__init__.py").is_file()


def _find_packages_under(root: Path, max_depth: int = 3) -> list[Path]:
    results: list[Path] = []

    def _walk(p: Path, depth: int) -> None:
        if depth > max_depth or p.name in _SKIP_DIRS:
            return
        if _is_python_package(p):
            results.append(p)
            return
        for c in sorted(p.iterdir()):
            if c.is_dir() and c.name not in _SKIP_DIRS:
                _walk(c, depth + 1)

    _walk(root, 0)
    return results


def _rank_packages(pkgs: list[Path]) -> list[Path]:
    def _score(p: Path) -> tuple[int, int]:
        n = p.name.lower()
        pen = n.endswith(("_cli", "_test", "_tests", "_bench", "_example"))
        return (0 if pen else 1, len(list(p.rglob("*.py"))))

    return sorted(pkgs, key=_score, reverse=True)


def _pyproject_flat_modules(root: Path) -> list[str]:
    if tomllib is None:
        return []
    pyproject = root / "pyproject.toml"
    if not pyproject.is_file():
        return []
    try:
        data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    except Exception:
        return []
    raw = (
        ((data.get("tool") or {}).get("setuptools") or {}).get("py-modules")
        or []
    )
    if not isinstance(raw, list):
        return []
    modules = [
        str(name)
        for name in raw
        if isinstance(name, str)
        and re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", name)
        and (root / f"{name}.py").is_file()
    ]
    return modules


def _safe_package_label(name: str, fallback: str) -> str:
    value = (name or fallback).strip()
    if "/" in value:
        value = value.rsplit("/", 1)[-1]
    value = value.replace("-", "_").replace(".", "_")
    value = re.sub(r"[^A-Za-z0-9_]+", "_", value).strip("_")
    if not value or value[0].isdigit():
        value = f"pkg_{value or fallback.replace('-', '_')}"
    return value


def _node_package_name(root: Path) -> str | None:
    pkg = root / "package.json"
    if not pkg.is_file():
        return None
    try:
        raw = json.loads(pkg.read_text(encoding="utf-8"))
    except Exception:
        return None
    name = raw.get("name") if isinstance(raw, dict) else ""
    return _safe_package_label(str(name), root.name)


def _go_module_name(root: Path) -> str | None:
    go_mod = root / "go.mod"
    if not go_mod.is_file():
        return None
    try:
        for line in go_mod.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("module "):
                return _safe_package_label(line.split(None, 1)[1], root.name)
    except OSError:
        return None
    return _safe_package_label(root.name, root.name)


def _rust_crate_name(root: Path) -> str | None:
    cargo = root / "Cargo.toml"
    if not cargo.is_file():
        return None
    try:
        text = cargo.read_text(encoding="utf-8")
    except OSError:
        return None
    in_package = False
    for line in text.splitlines():
        stripped = line.strip()
        if stripped == "[package]":
            in_package = True
            continue
        if stripped.startswith("[") and stripped.endswith("]"):
            in_package = False
        if in_package and stripped.startswith("name"):
            _key, _eq, value = stripped.partition("=")
            return _safe_package_label(value.strip().strip('"').strip("'"), root.name)
    return _safe_package_label(root.name, root.name)


def _has_polyglot_source(root: Path) -> bool:
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() not in ALL_SOURCE_EXTS:
            continue
        try:
            rel_parts = p.relative_to(root).parts
        except ValueError:
            rel_parts = p.parts
        if any(part in _SKIP_DIRS for part in rel_parts):
            continue
        return True
    return False


def classify_repo_layout(repo_root: Path | str) -> str:
    p = Path(repo_root).resolve()
    if _has_tier_folders(p):
        return RepoLayout.ATOMADIC_TIER
    src = p / "src"
    if src.is_dir() and _find_packages_under(src, 1):
        return RepoLayout.SRC_LAYOUT
    lib = p / "lib"
    if lib.is_dir() and _find_packages_under(lib, 3):
        return RepoLayout.MONOREPO_LIB
    libs = p / "libs"
    if libs.is_dir() and _find_packages_under(libs, 2):
        return RepoLayout.MULTI_LIB
    if any(_is_python_package(c) for c in p.iterdir()):
        return RepoLayout.FLAT
    if _pyproject_flat_modules(p):
        return RepoLayout.FLAT_MODULES
    if _node_package_name(p):
        return RepoLayout.NODE_PACKAGE
    if _go_module_name(p):
        return RepoLayout.GO_MODULE
    if _rust_crate_name(p):
        return RepoLayout.RUST_CRATE
    if _has_polyglot_source(p):
        return RepoLayout.POLYGLOT_SOURCE
    return RepoLayout.UNKNOWN


def resolve_any_python_package(repo_root: Path | str) -> ResolvedRepo:
    p = Path(repo_root).resolve()
    if not p.exists():
        raise ValueError(f"repo does not exist: {p}")
    layout = classify_repo_layout(p)
    if layout == RepoLayout.ATOMADIC_TIER:
        return ResolvedRepo(src_root=p, package_name=p.name, layout=layout, repo_root=p)
    if layout == RepoLayout.SRC_LAYOUT:
        pkgs = _find_packages_under(p / "src", 1)
        if pkgs:
            return ResolvedRepo(
                src_root=pkgs[0], package_name=pkgs[0].name, layout=layout, repo_root=p
            )
    if layout == RepoLayout.MONOREPO_LIB:
        pkgs = _find_packages_under(p / "lib", 4)
        if pkgs:
            best = _rank_packages(pkgs)[0]
            return ResolvedRepo(
                src_root=best, package_name=best.name, layout=layout, repo_root=p
            )
    if layout == RepoLayout.MULTI_LIB:
        pkgs = _find_packages_under(p / "libs", 3)
        if pkgs:
            best = _rank_packages(pkgs)[0]
            return ResolvedRepo(
                src_root=best, package_name=best.name, layout=layout, repo_root=p
            )
    if layout == RepoLayout.FLAT:
        pkgs = [c for c in p.iterdir() if _is_python_package(c) and c.name not in _SKIP_DIRS]
        if pkgs:
            best = max(pkgs, key=lambda x: len(list(x.rglob("*.py"))))
            return ResolvedRepo(
                src_root=best, package_name=best.name, layout=layout, repo_root=p
            )
    if layout == RepoLayout.FLAT_MODULES:
        modules = _pyproject_flat_modules(p)
        if modules:
            return ResolvedRepo(
                src_root=p, package_name=modules[0], layout=layout, repo_root=p
            )
    if layout == RepoLayout.NODE_PACKAGE:
        return ResolvedRepo(
            src_root=p,
            package_name=_node_package_name(p) or _safe_package_label(p.name, p.name),
            layout=layout,
            repo_root=p,
        )
    if layout == RepoLayout.GO_MODULE:
        return ResolvedRepo(
            src_root=p,
            package_name=_go_module_name(p) or _safe_package_label(p.name, p.name),
            layout=layout,
            repo_root=p,
        )
    if layout == RepoLayout.RUST_CRATE:
        return ResolvedRepo(
            src_root=p,
            package_name=_rust_crate_name(p) or _safe_package_label(p.name, p.name),
            layout=layout,
            repo_root=p,
        )
    if layout == RepoLayout.POLYGLOT_SOURCE:
        return ResolvedRepo(
            src_root=p,
            package_name=_safe_package_label(p.name, p.name),
            layout=layout,
            repo_root=p,
        )
    all_pkgs = _find_packages_under(p, 5)
    if all_pkgs:
        best = _rank_packages(all_pkgs)[0]
        return ResolvedRepo(
            src_root=best, package_name=best.name, layout=RepoLayout.UNKNOWN, repo_root=p
        )
    raise ValueError(
        f"could not resolve a Python package under {p} (layout={layout}). "
        "Ensure the repo contains at least one directory with __init__.py."
    )


def build_swarm_repo_specs(repo_paths: list[Path | str]) -> list[dict]:
    specs = []
    for path in repo_paths:
        try:
            r = resolve_any_python_package(path)
            specs.append({
                "src_root": str(r.src_root),
                "package": r.package_name,
                "layout": r.layout,
                "repo_root": str(r.repo_root),
            })
        except ValueError as e:
            specs.append({
                "src_root": str(path),
                "package": Path(path).name,
                "layout": RepoLayout.UNKNOWN,
                "repo_root": str(path),
                "error": str(e),
            })
    return specs


def fingerprint_repo(repo_root: Path | str) -> str:
    p = Path(repo_root).resolve()
    parts: list[str] = []
    for f in sorted(p.rglob("*.py")):
        try:
            parts.append(f"{f.relative_to(p)}:{f.stat().st_size}")
        except OSError:
            continue
    return hashlib.sha256("\n".join(parts[:500]).encode()).hexdigest()[:12]
