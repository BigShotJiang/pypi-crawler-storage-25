"""Tier a1 — pure metrics aggregator: compute_forge_metrics().

Single source of truth for every public number Forge claims about itself.
Public surfaces (README, CHANGELOG, the welcome handshake, the Cloudflare
Worker, shields.io badges) all derive from the same canonical artifact —
``forge_metrics.json`` — produced by this function. No string lives in two
places; any drift is a CI-detectable bug.

The function is pure: given the same repo + (optional) proof corpus path,
it returns the same dict. Every field carries a ``_basis`` description
so consumers can trace a number back to its source.

Why a separate a1 module rather than a3 feature: the metric counters are
deterministic walks (no I/O outside ``read_text``, no network, no
side-effects). They belong in a1 with the other pure analysers.
"""
from __future__ import annotations

import datetime as _dt
import json
import re
from pathlib import Path
from typing import Any

SCHEMA_VERSION_FORGE_METRICS_V1 = "atomadic-forge.metrics/v1"

# ── Lean theorem detection ────────────────────────────────────────────

# Captures: ``theorem foo``, ``lemma bar``, ``private theorem``,
# ``protected theorem``, ``noncomputable theorem``. Indented matches
# (theorems inside namespaces) are accepted; the leading whitespace is
# the only thing before the keyword.
_LEAN_THEOREM_RE = re.compile(
    r"^\s*(?:private\s+|protected\s+|noncomputable\s+)*"
    r"(?P<kind>theorem|lemma)\s+\w",
    re.MULTILINE,
)


def count_lean_theorems(proof_corpus_root: Path) -> dict[str, Any]:
    """Return the certified Lean theorem count for the IP-protected proof corpus.

    The proof corpus repository is IP-protected — this function only
    surfaces aggregate counts to the public artifact. Source paths and
    file names are NEVER returned. Callers must not log the input path.

    Prefer a build attestation when present: that file is the certified
    proof-tree boundary produced by ``lake build``. A raw ``proofs/`` scan
    is only a fallback for local working trees that have not produced an
    attestation yet; it can overcount scratch or archived Lean files.

    Args:
        proof_corpus_root: directory containing a ``proofs/`` subtree of
            ``.lean`` files. If the directory does not exist or contains
            no proofs, returns ``{count: 0, files: 0, found: False}``.

    Returns:
        Dict with public-safe fields only: ``count`` (theorems+lemmas
        combined), ``theorems``, ``lemmas``, ``files``, ``found``.
        No paths. Counts are always int; never raises on missing path.
    """
    attested = _count_lean_theorems_from_attestation(Path(proof_corpus_root))
    if attested is not None:
        return attested

    proofs_dir = Path(proof_corpus_root) / "proofs"
    if not proofs_dir.is_dir():
        return {
            "count": 0, "theorems": 0, "lemmas": 0,
            "files": 0, "found": False,
        }
    files = sorted(proofs_dir.rglob("*.lean"))
    theorems = lemmas = 0
    for f in files:
        try:
            text = f.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for m in _LEAN_THEOREM_RE.finditer(text):
            if m.group("kind") == "theorem":
                theorems += 1
            else:
                lemmas += 1
    return {
        "count": theorems + lemmas,
        "theorems": theorems,
        "lemmas": lemmas,
        "files": len(files),
        "found": True,
        "basis": "raw_proofs_scan",
    }


def _count_lean_theorems_from_attestation(
    proof_corpus_root: Path,
) -> dict[str, Any] | None:
    """Read the newest build attestation if one exists.

    Returns only aggregate fields safe for ``forge_metrics.json``. The
    per-module hashes; those are deliberately not copied into Forge's public
    metrics surface. The aggregate proof-tree hash is public-safe and lets
    downstream agents verify the exact attested boundary.
    """
    dist_dir = Path(proof_corpus_root) / "dist"
    if not dist_dir.is_dir():
        return None
    attestations = sorted(dist_dir.glob("BUILD_ATTESTATION_*.json"))
    if not attestations:
        return None
    try:
        data = json.loads(attestations[-1].read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return None
    totals = data.get("totals")
    if not isinstance(totals, dict):
        return None
    try:
        count = int(totals["theorems_and_lemmas"])
        sorry = int(totals.get("sorry", 0))
        admit = int(totals.get("admit", 0))
        modules = int(totals.get("modules", 0))
        agent_rule_axioms = int(totals.get("agent_rule_axioms", 0))
        free_parameters = int(totals.get("free_parameters_fit_to_data", 0))
    except (KeyError, TypeError, ValueError):
        return None
    proof_tree = data.get("proof_tree")
    proof_hash = ""
    if isinstance(proof_tree, dict):
        proof_hash = str(proof_tree.get("sha256_of_sorted_module_hashes", ""))
    return {
        "count": count,
        "theorems": count,
        "lemmas": 0,
        "files": modules,
        "modules": modules,
        "sorry": sorry,
        "admit": admit,
        "agent_rule_axioms": agent_rule_axioms,
        "free_parameters_fit_to_data": free_parameters,
        "found": True,
        "basis": "build_attestation",
        "attestation_issued_at": str(data.get("issued_at", "")),
        "proof_tree_hash": proof_hash,
        "lake_build_status": str(data.get("lake_build_status", "")),
    }


# ── Forge surface counters ────────────────────────────────────────────


def count_source_files(repo_root: Path) -> int:
    """Count Python source files under ``src/`` (excludes tests & cache)."""
    src = Path(repo_root) / "src"
    if not src.is_dir():
        return 0
    return sum(1 for p in src.rglob("*.py") if "__pycache__" not in p.parts)


def count_test_files(repo_root: Path) -> int:
    """Count Python test files under ``tests/`` (test_*.py + *_test.py)."""
    tests = Path(repo_root) / "tests"
    if not tests.is_dir():
        return 0
    return sum(
        1 for p in tests.rglob("*.py")
        if (p.name.startswith("test_") or p.name.endswith("_test.py"))
        and "__pycache__" not in p.parts
    )


# ``def test_*`` and ``async def test_*`` (excludes inner helpers and
# fixtures). Multiline patterns within decorators don't matter — we only
# match the function definition line itself.
_TEST_FN_RE = re.compile(r"^\s*(?:async\s+)?def\s+test_\w+\s*\(", re.MULTILINE)


def count_test_functions(repo_root: Path) -> int:
    """Count ``def test_*`` (and ``async def test_*``) functions across
    all test modules.

    Approximates pytest collection without invoking pytest. Doesn't
    expand parametrize cases (each parametrized test counts as one
    function); use the live pytest collector for the parametrized count.
    """
    tests = Path(repo_root) / "tests"
    if not tests.is_dir():
        return 0
    total = 0
    for p in tests.rglob("*.py"):
        if "__pycache__" in p.parts:
            continue
        if not (p.name.startswith("test_") or p.name.endswith("_test.py")):
            continue
        try:
            text = p.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        total += len(_TEST_FN_RE.findall(text))
    return total


def count_lines_of_code(repo_root: Path) -> int:
    """Sum non-blank lines across ``src/`` Python files."""
    src = Path(repo_root) / "src"
    if not src.is_dir():
        return 0
    total = 0
    for p in src.rglob("*.py"):
        if "__pycache__" in p.parts:
            continue
        try:
            for line in p.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    total += 1
        except (OSError, UnicodeDecodeError):
            continue
    return total


# ── Top-level aggregator ──────────────────────────────────────────────


def compute_forge_metrics(
    repo_root: Path,
    *,
    proof_corpus_root: Path | None = None,
    prior_lean_theorems: dict[str, Any] | None = None,
    package_version: str | None = None,
    tools_count: int | None = None,
    actions_count: int | None = None,
    cli_verbs_count: int | None = None,
    self_certify_score: float | None = None,
    self_wire_violations: int | None = None,
    tests_passing: int | None = None,
) -> dict[str, Any]:
    """Compute the canonical ``forge_metrics`` artifact.

    Anything the caller can compute cheaply (tools_count from the live
    TOOLS dict, package_version from ``importlib.metadata``) should be
    passed in. Anything that requires walking the filesystem or reading
    Lean files is computed here.

    Args:
        repo_root: forge repo path (where ``src/`` and ``tests/`` live).
        proof_corpus_root: optional path to IP-protected proof corpus. When given,
            ``lean_theorems`` block is populated; when None, that block
            is zeroed and ``lean_theorems.found=False`` unless
            ``prior_lean_theorems`` carries a real count.
        prior_lean_theorems: optional previously-stored lean block from
            ``forge_metrics.json``. When ``proof_corpus_root`` is None and
            this dict has ``count > 0``, the prior value is preserved
            instead of being zeroed. Ignored when the corpus is available.
        package_version: optional string. If None, the field is omitted.
        tools_count, actions_count, cli_verbs_count: caller-supplied
            so the metrics function stays stateless w.r.t. live MCP /
            CLI registries.
        self_certify_score, self_wire_violations, tests_passing:
            from the latest ``forge certify`` / ``forge wire`` runs.

    Returns:
        Dict serializable to JSON. All keys are stable (consumers may
        rely on them). New fields may be added; never removed without
        a schema_version bump.
    """
    repo_root = Path(repo_root)
    metrics: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION_FORGE_METRICS_V1,
        "generated_at_utc": _dt.datetime.now(_dt.timezone.utc)
            .strftime("%Y-%m-%dT%H:%M:%SZ"),
        # Architecture invariants
        "monadic_tiers": 5,
        "monadic_tiers_basis": "atomadic 5-tier law: a0..a4",
        # Source-tree counters (computed)
        "source_files": count_source_files(repo_root),
        "source_lines": count_lines_of_code(repo_root),
        "test_files": count_test_files(repo_root),
        "test_functions": count_test_functions(repo_root),
    }
    if package_version is not None:
        metrics["package_version"] = package_version
    if tools_count is not None:
        metrics["mcp_tools"] = tools_count
    if actions_count is not None:
        metrics["mcp_actions"] = actions_count
    if cli_verbs_count is not None:
        metrics["cli_verbs"] = cli_verbs_count
    if self_certify_score is not None:
        metrics["self_certify_score"] = self_certify_score
    if self_wire_violations is not None:
        metrics["self_wire_violations"] = self_wire_violations
    if tests_passing is not None:
        metrics["tests_passing"] = tests_passing
    # Lean theorem block — always present, populated only when found.
    # Public artifact carries counts only — never paths or file names.
    if proof_corpus_root is not None:
        lean = count_lean_theorems(Path(proof_corpus_root))
    elif (
        isinstance(prior_lean_theorems, dict)
        and prior_lean_theorems.get("count", 0) > 0
    ):
        # Corpus unavailable locally; preserve the previously-stored count
        # so a local ``forge metrics --apply`` run does not destroy the
        # attested value. The caller is responsible for sourcing this from
        # the existing ``forge_metrics.json``.
        lean = prior_lean_theorems
    else:
        lean = {"count": 0, "theorems": 0, "lemmas": 0,
                "files": 0, "found": False}
    metrics["lean_theorems"] = lean
    return metrics


def write_forge_metrics(metrics: dict[str, Any], path: Path) -> Path:
    """Serialize ``metrics`` to ``path`` deterministically (sort_keys, indent=2).

    Returns the absolute path written. Caller is responsible for any
    git add / commit; this function only writes the file.
    """
    path = Path(path)
    path.write_text(
        json.dumps(metrics, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return path.resolve()


__all__ = [
    "SCHEMA_VERSION_FORGE_METRICS_V1",
    "count_lean_theorems",
    "count_source_files",
    "count_test_files",
    "count_test_functions",
    "count_lines_of_code",
    "compute_forge_metrics",
    "write_forge_metrics",
]
