"""Tier a1 — pure clustering + recipe-draft synthesis from wisdom.

Cluster wisdom entries by tag overlap; corroborated clusters (≥
``min_corroboration`` entries) become draft-recipe candidates.
Pure: deterministic clustering + template rendering. No LLM.

Used by ``forge wisdom promote`` (CLI) and ``wisdom_promote`` (MCP)
to graduate provisional wisdom into the curated recipes layer at
``_private/research/recipe_drafts/``.
"""
from __future__ import annotations

from typing import Any

SCHEMA_VERSION_WISDOM_PROMOTE_V1 = "atomadic-forge.wisdom_promote/v1"

# Default corroboration threshold: 3 wisdom entries on the same tag
# cluster qualify for a recipe draft. Lower = more drafts, more
# noise. Higher = fewer drafts, more signal.
DEFAULT_MIN_CORROBORATION = 3


def _normalize_tag_set(entry: dict[str, Any]) -> frozenset[str]:
    return frozenset(t.strip().lower() for t in entry.get("tags", []) if t.strip())


def cluster_by_tags(
    entries: list[dict[str, Any]],
    *,
    min_corroboration: int = DEFAULT_MIN_CORROBORATION,
    min_tag_overlap: int = 1,
) -> list[dict[str, Any]]:
    """Cluster wisdom by tag overlap.

    Greedy single-pass clustering: each entry joins the first
    existing cluster whose tag-set overlaps by ≥ min_tag_overlap;
    otherwise opens a new cluster. Deterministic ordering ensures
    same input → same clusters.

    Returns clusters sorted by (size desc, tag_count desc).
    """
    sorted_entries = sorted(entries, key=lambda e: e.get("timestamp_utc", ""))
    clusters: list[dict[str, Any]] = []
    for entry in sorted_entries:
        tags = _normalize_tag_set(entry)
        if not tags:
            continue
        joined = False
        for c in clusters:
            if len(c["tags"] & tags) >= min_tag_overlap:
                c["entries"].append(entry)
                c["tags"] = c["tags"] | tags  # accumulate union
                joined = True
                break
        if not joined:
            clusters.append({
                "tags": set(tags), "entries": [entry],
            })
    # Filter to corroborated clusters and stable-sort.
    qualified = [
        {
            "tags": sorted(c["tags"]),
            "tag_count": len(c["tags"]),
            "entry_count": len(c["entries"]),
            "entry_ids": [e.get("id") for e in c["entries"]],
            "entries": c["entries"],
        }
        for c in clusters
        if len(c["entries"]) >= min_corroboration
    ]
    qualified.sort(
        key=lambda c: (-c["entry_count"], -c["tag_count"]),
    )
    return qualified


def cluster_signature(cluster: dict[str, Any]) -> str:
    """Stable short identifier for a cluster — 'recipe-<top-3-tags>'."""
    top = sorted(cluster["tags"])[:3]
    return "recipe-" + "-".join(t.replace(" ", "_") for t in top)


def render_recipe_draft(cluster: dict[str, Any]) -> str:
    """Render a cluster into a draft-recipe markdown block.

    Same shape as the curated ``_RECIPES`` entries in
    ``a1_at_functions/recipes.py`` so a human-reviewer's job is just
    "polish + paste."
    """
    name = cluster_signature(cluster)
    description_lines = [
        f"# Recipe draft: {name}",
        "",
        f"**Status:** auto-drafted from {cluster['entry_count']} corroborating "
        f"wisdom entries.",
        f"**Tags:** {', '.join(cluster['tags'])}",
        f"**Source wisdom IDs:** {', '.join(cluster['entry_ids'])}",
        "",
        "## Description",
        "",
        "Cluster theme (synthesize):",
        "",
    ]
    for e in cluster["entries"]:
        insight = (e.get("insight", "") or "").strip()
        confidence = e.get("confidence", 0)
        agent = e.get("agent_name", "unknown")
        description_lines.append(
            f"- **{e.get('id', '?')}** "
            f"(conf {confidence:.2f}, by `{agent}`)\n"
            f"  > {insight}"
        )
    description_lines.extend([
        "",
        "## Checklist (fill in)",
        "",
        "- [ ] (synthesize concrete steps from the corroborating wisdom)",
        "",
        "## File scope hints",
        "",
        "- (paths from the source-wisdom evidence fields)",
        "",
        "## Validation gate",
        "",
        "- python -m pytest",
        "- forge verify .",
        "- forge surface check",
        "",
        "## Notes",
        "",
        "- Auto-drafted — review carefully before merging into "
        "`a1_at_functions/recipes.py`.",
        "- Source wisdom can be queried via `forge wisdom query --tags "
        + ",".join(cluster['tags'][:3]) + "`.",
    ])
    return "\n".join(description_lines) + "\n"


def synthesize_promotions(
    entries: list[dict[str, Any]],
    *,
    min_corroboration: int = DEFAULT_MIN_CORROBORATION,
    min_tag_overlap: int = 1,
) -> dict[str, Any]:
    """Top-level entry: cluster + render all qualified drafts."""
    clusters = cluster_by_tags(
        entries,
        min_corroboration=min_corroboration,
        min_tag_overlap=min_tag_overlap,
    )
    drafts = [
        {
            "name": cluster_signature(c),
            "tags": c["tags"],
            "entry_count": c["entry_count"],
            "entry_ids": c["entry_ids"],
            "draft_markdown": render_recipe_draft(c),
        }
        for c in clusters
    ]
    return {
        "schema_version": SCHEMA_VERSION_WISDOM_PROMOTE_V1,
        "entries_considered": len(entries),
        "min_corroboration": min_corroboration,
        "qualified_clusters": len(drafts),
        "drafts": drafts,
    }
