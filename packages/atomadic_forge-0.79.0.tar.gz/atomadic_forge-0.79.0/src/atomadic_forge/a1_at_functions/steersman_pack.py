"""Tier a1 — tiny-model decision packs over AST locks.

Golden Path Lane C W6 follow-on deliverable. ``plan(action='steersman')``
turns an AST scope plan into tiny A/B routing questions so a 1B local model
can steer deterministic Forge claws without ever writing code.
"""
from __future__ import annotations

import json
from typing import Any

SCHEMA_VERSION_STEERSMAN_PACK_V1 = "atomadic-forge.steersman_pack/v1"


def _find_lock(locks: list[dict[str, Any]], node_id: str) -> dict[str, Any]:
    for lock in locks:
        if lock.get("node_id") == node_id:
            return lock
    return {}


def _default_tier(node: dict[str, Any]) -> str:
    tier = str(node.get("tier") or "")
    if tier:
        return tier
    kind = str(node.get("kind") or "")
    if kind == "class":
        return "a2_mo_composites"
    if kind in {"function", "method"}:
        return "a1_at_functions"
    return "a3_og_features"


def _choices_for(node: dict[str, Any]) -> list[dict[str, str]]:
    default = _default_tier(node)
    return [
        {"id": default, "label": f"Route to {default}"},
        {"id": "keep", "label": "Keep current location"},
    ]


def _question_for(node: dict[str, Any], lock: dict[str, Any], intent: str) -> dict[str, Any]:
    qualname = str(node.get("qualname") or node.get("node_id") or "node")
    default = _default_tier(node)
    return {
        "question_id": f"q-{node.get('node_id')}",
        "node_id": node.get("node_id"),
        "lock_id": lock.get("lock_id"),
        "qualname": qualname,
        "kind": node.get("kind"),
        "file": node.get("file"),
        "line_range": [node.get("start_line"), node.get("end_line")],
        "prompt": (
            f"For intent {intent!r}, should {qualname} be routed to "
            f"{default} or kept where it is?"
        ),
        "choices": _choices_for(node),
        "default_choice": default,
    }


def build_steersman_pack(
    *,
    ast_scope_plan: dict[str, Any],
    intent: str = "transmute spaghetti into Atomadic Standard",
    max_questions: int = 24,
) -> dict[str, Any]:
    """Build a compact decision surface from an AST scope plan."""
    blueprint = ast_scope_plan.get("blueprint") or {}
    nodes = list(blueprint.get("nodes") or [])[:max_questions]
    locks = list((ast_scope_plan.get("locks") or {}).get("locks") or [])
    questions = [
        _question_for(node, _find_lock(locks, str(node.get("node_id"))), intent)
        for node in nodes
    ]
    decisions = [
        {
            "question_id": q["question_id"],
            "node_id": q["node_id"],
            "lock_id": q["lock_id"],
            "choice": q["default_choice"],
            "source": "deterministic_default",
        }
        for q in questions
    ]
    prompt_payload = {
        "task": "Choose one choice id for each question. Return JSON only.",
        "intent": intent,
        "questions": [
            {
                "id": q["question_id"],
                "qualname": q["qualname"],
                "kind": q["kind"],
                "choices": [choice["id"] for choice in q["choices"]],
            }
            for q in questions
        ],
    }
    prompt = json.dumps(prompt_payload, separators=(",", ":"), sort_keys=True)
    return {
        "schema_version": SCHEMA_VERSION_STEERSMAN_PACK_V1,
        "intent": intent,
        "model_role": "semantic_router_only",
        "model_contract": {
            "may_write_code": False,
            "allowed_output": "JSON choices only",
            "recommended_local_models": ["llama3.2:1b", "qwen2.5:1.5b"],
        },
        "question_count": len(questions),
        "questions": questions,
        "deterministic_decisions": decisions,
        "model_prompt": prompt,
        "compressed_context": {
            "prompt_chars": len(prompt),
            "prompt_tokens_estimate": max(1, len(prompt) // 4),
            "raw_tokens_estimate": (
                (blueprint.get("compressed_context") or {}).get("raw_tokens_estimate")
                or max(1, len(prompt) // 4)
            ),
        },
    }


def parse_steersman_choices(
    *,
    response: str,
    questions: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Parse tiny-model choices, falling back per question."""
    try:
        payload = json.loads(response)
    except json.JSONDecodeError:
        payload = {}
    raw_choices = payload.get("choices") if isinstance(payload, dict) else None
    if isinstance(raw_choices, list):
        by_id = {
            str(item.get("question_id") or item.get("id")): str(item.get("choice"))
            for item in raw_choices
            if isinstance(item, dict)
        }
    elif isinstance(payload, dict):
        by_id = {str(k): str(v) for k, v in payload.items()}
    else:
        by_id = {}
    decisions: list[dict[str, Any]] = []
    for q in questions:
        allowed = {choice["id"] for choice in q.get("choices", [])}
        selected = by_id.get(str(q.get("question_id")))
        if selected not in allowed:
            selected = str(q.get("default_choice"))
            source = "deterministic_default"
        else:
            source = "model"
        decisions.append({
            "question_id": q.get("question_id"),
            "node_id": q.get("node_id"),
            "lock_id": q.get("lock_id"),
            "choice": selected,
            "source": source,
        })
    return decisions


def finalize_steersman_pack(
    *,
    pack: dict[str, Any],
    model_response: str | None = None,
) -> dict[str, Any]:
    """Attach final decisions and savings estimate."""
    if model_response:
        decisions = parse_steersman_choices(
            response=model_response,
            questions=list(pack.get("questions") or []),
        )
    else:
        decisions = list(pack.get("deterministic_decisions") or [])
    compressed = dict(pack.get("compressed_context") or {})
    raw = max(1, int(compressed.get("raw_tokens_estimate") or 1))
    used = max(1, int(compressed.get("prompt_tokens_estimate") or 1))
    compressed["token_savings_pct"] = round(100.0 * (1.0 - (used / raw)), 1)
    return {
        **pack,
        "compressed_context": compressed,
        "decisions": decisions,
        "verdict": "PASS" if decisions else "REFINE",
        "summary": (
            f"{len(decisions)} tiny-model decision(s), "
            f"{compressed['token_savings_pct']}% estimated token savings"
        ),
    }


__all__ = [
    "SCHEMA_VERSION_STEERSMAN_PACK_V1",
    "build_steersman_pack",
    "finalize_steersman_pack",
    "parse_steersman_choices",
]
