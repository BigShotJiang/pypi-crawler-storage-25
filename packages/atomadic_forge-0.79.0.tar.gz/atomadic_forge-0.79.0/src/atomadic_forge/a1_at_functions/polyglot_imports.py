"""Tier a1 — pure regex import parsers for Rust, Go, Swift, Kotlin.

Forge isn't a compiler for any of these languages.  For wire-check
purposes we only need to extract every import-like specifier so the
upward-import scanner can map ``aN_…`` segments to tiers.

Each parser:
  * strips ``//`` line comments and ``/* */`` block comments first,
  * scans for the language's import syntax,
  * returns a deduplicated list[str] of specifier strings in source order.

The parsers are intentionally *forgiving* — malformed source produces
an empty list rather than raising.  That matches the JS/TS parser
contract in :mod:`js_parser` and keeps Forge resilient when scanning
half-broken trees.

Pure: no I/O, no AST, no external dependencies.
"""

from __future__ import annotations

import re

# ── shared comment stripping ────────────────────────────────────────

_BLOCK_COMMENT_RE = re.compile(r"/\*.*?\*/", re.DOTALL)
_LINE_COMMENT_RE = re.compile(r"//[^\n]*")


def _strip_c_style_comments(src: str) -> str:
    """Remove C-style ``//`` and ``/* */`` comments. Pure."""
    src = _BLOCK_COMMENT_RE.sub("", src)
    src = _LINE_COMMENT_RE.sub("", src)
    return src


# ── Rust ─────────────────────────────────────────────────────────────
#
# Forms we capture:
#     use crate::a3_og_features::Foo;
#     use crate::a3_og_features::{Foo, Bar};
#     use super::a2_mo_composites::Foo;
#     use self::a1_at_functions::helper;
#     pub use crate::a4_sy_orchestration::handler;
#     mod a3_og_features;
#
# We do NOT try to canonicalise the path; downstream wire-check just
# searches the captured string for an ``aN_…`` segment.  Imports of
# external crates (``use serde::Deserialize``) emit a specifier, but
# downstream tier scan finds no match and silently ignores them.

_RUST_USE_RE = re.compile(
    r"\b(?:pub\s+)?use\s+([A-Za-z_:][\w:]*)",
)
_RUST_MOD_RE = re.compile(
    r"\b(?:pub\s+)?mod\s+([A-Za-z_][\w]*)\s*;",
)


def parse_rust_imports(src: str) -> list[str]:
    """Return every ``use ::path`` and ``mod name;`` token in source order.

    Each ``use crate::a3_og_features::Foo`` returns the full path string
    so :func:`wire_check._tier_of_specifier` can match the tier segment.
    Each ``mod a3_og_features;`` returns the bare module name.

    Trailing ``::`` is trimmed so ``use crate::a2_mo_composites::{Bar, Baz};``
    yields ``"crate::a2_mo_composites"`` rather than the dangling-colon form.
    """
    cleaned = _strip_c_style_comments(src)
    seen: list[str] = []
    for m in _RUST_USE_RE.finditer(cleaned):
        spec = m.group(1).rstrip(":")
        if spec and spec not in seen:
            seen.append(spec)
    for m in _RUST_MOD_RE.finditer(cleaned):
        spec = m.group(1)
        if spec and spec not in seen:
            seen.append(spec)
    return seen


# ── Go ────────────────────────────────────────────────────────────────
#
# Forms we capture:
#     import "example.com/proj/a3_og_features"
#     import (
#         "example.com/proj/a2_mo_composites"
#         alias "example.com/proj/a1_at_functions"
#     )
#
# Block-form ``import (...)`` uses a different regex than single-line
# ``import "x"``.

_GO_SINGLE_IMPORT_RE = re.compile(
    r'\bimport\s+(?:[A-Za-z_][\w]*\s+)?"([^"]+)"',
)
_GO_BLOCK_IMPORT_RE = re.compile(
    r'\bimport\s*\(\s*([^)]*)\)', re.DOTALL,
)
_GO_BLOCK_LINE_RE = re.compile(
    r'(?:[A-Za-z_][\w]*\s+)?"([^"]+)"',
)


def parse_go_imports(src: str) -> list[str]:
    """Return every Go import path in source order, deduplicated."""
    cleaned = _strip_c_style_comments(src)
    seen: list[str] = []
    for m in _GO_SINGLE_IMPORT_RE.finditer(cleaned):
        spec = m.group(1)
        if spec and spec not in seen:
            seen.append(spec)
    for block in _GO_BLOCK_IMPORT_RE.finditer(cleaned):
        body = block.group(1)
        for line in _GO_BLOCK_LINE_RE.finditer(body):
            spec = line.group(1)
            if spec and spec not in seen:
                seen.append(spec)
    return seen


# ── Swift ────────────────────────────────────────────────────────────
#
# Swift imports are module-level: ``import Foundation``, ``import a3_og_features``.
# Submodule imports use a dot: ``import UIKit.UIView``.  For tier-law
# purposes we only need the module name token; downstream wire-check
# matches against ``aN_…`` segments anywhere in the specifier.
#
# Forms we capture:
#     import Foundation
#     import struct Foundation.URL
#     import enum a3_og_features.Routes
#     import a2_mo_composites
#     @testable import a4_sy_orchestration

_SWIFT_IMPORT_RE = re.compile(
    r"\b(?:@testable\s+)?import\s+"
    r"(?:struct\s+|class\s+|enum\s+|protocol\s+|typealias\s+|func\s+|var\s+|let\s+)?"
    r"([A-Za-z_][\w.]*)",
)


def parse_swift_imports(src: str) -> list[str]:
    """Return every ``import`` specifier in source order, deduplicated."""
    cleaned = _strip_c_style_comments(src)
    seen: list[str] = []
    for m in _SWIFT_IMPORT_RE.finditer(cleaned):
        spec = m.group(1)
        if spec and spec not in seen:
            seen.append(spec)
    return seen


# ── Kotlin ───────────────────────────────────────────────────────────
#
# Forms we capture:
#     package com.example.a3_og_features
#     import com.example.a2_mo_composites.Foo
#     import com.example.a1_at_functions.*
#
# Kotlin's ``package`` declaration matters too — it tells us where a
# file logically lives even when there's no explicit import.  We
# return both as specifier strings and let the wire scanner classify
# tier segments.

_KOTLIN_IMPORT_RE = re.compile(
    r"\bimport\s+([A-Za-z_][\w.]*?(?:\.\*)?)\s*(?:;|$)",
    re.MULTILINE,
)
_KOTLIN_PACKAGE_RE = re.compile(
    r"\bpackage\s+([A-Za-z_][\w.]*)",
)


def parse_kotlin_imports(src: str) -> list[str]:
    """Return every ``import x.y.z`` plus the file's ``package`` declaration."""
    cleaned = _strip_c_style_comments(src)
    seen: list[str] = []
    for m in _KOTLIN_IMPORT_RE.finditer(cleaned):
        spec = m.group(1)
        if spec and spec not in seen:
            seen.append(spec)
    for m in _KOTLIN_PACKAGE_RE.finditer(cleaned):
        spec = m.group(1)
        if spec and spec not in seen:
            seen.append(spec)
    return seen


# ── language router ──────────────────────────────────────────────────


def parse_imports_for_language(language: str, src: str) -> list[str]:
    """Dispatch to the right parser by canonical language label.

    Returns ``[]`` for languages this module doesn't handle (Python and
    JS/TS have their own dedicated parsers).
    """
    if language == "rust":
        return parse_rust_imports(src)
    if language == "go":
        return parse_go_imports(src)
    if language == "swift":
        return parse_swift_imports(src)
    if language == "kotlin":
        return parse_kotlin_imports(src)
    return []
