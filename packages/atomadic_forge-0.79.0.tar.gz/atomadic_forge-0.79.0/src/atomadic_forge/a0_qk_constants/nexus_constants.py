"""Tier a0 — AAAA-Nexus integration constants.

The AAAA-Nexus service exposes a known set of LIVE primitives at
``atomadic.tech/mcp`` — verified by Cognition agent's
``WIS-cog-2026-05-06-handshake`` probe on 2026-05-06: 27 tools,
the seven below being the ones we depend on.

DO NOT add ``nexus_consensus_*`` / ``nexus_swarm_*`` / ``nexus_agent_*``
to this list — they don't exist on the deployed worker yet (per
WIS-cog-2026-05-06-handshake + WIS-7ef7484c). The Forge hive layer
(``hive_propose`` / ``hive_vote`` / ``hive_result`` / ``hive_observe``)
stands in for those at the local level.
"""
from __future__ import annotations

from typing import Final

SCHEMA_VERSION_NEXUS_CALL_V1: Final[str] = "atomadic-forge.nexus_call/v1"

# Default endpoint. Callers can override via env var.
DEFAULT_NEXUS_BASE_URL: Final[str] = "https://atomadic.tech"
DEFAULT_NEXUS_MCP_PATH: Final[str] = "/mcp"

# Auth: caller supplies ATOMADIC_MASTER_KEY (or per-agent subscription
# key once the auth-worker side ships per-agent scoping). Forge's
# public/auth gateway keys are accepted as aliases so paid users can
# run Forge and Nexus from the same master key. The bridge never embeds
# keys in source.
ENV_NEXUS_BASE_URL: Final[str] = "ATOMADIC_NEXUS_URL"
ENV_NEXUS_MASTER_KEY: Final[str] = "ATOMADIC_MASTER_KEY"
ENV_NEXUS_SUBSCRIPTION_KEY: Final[str] = "ATOMADIC_SUBSCRIPTION_KEY"
ENV_NEXUS_BASE_URL_ALIASES: Final[tuple[str, ...]] = (
    "ATOMADIC_NEXUS_URL",
    "AAAA_NEXUS_URL",
)
ENV_NEXUS_MASTER_KEY_ALIASES: Final[tuple[str, ...]] = (
    "ATOMADIC_MASTER_KEY",
    "FORGE_MASTER_API_KEY",
    "AAAA_NEXUS_API_KEY",
)
ENV_NEXUS_SUBSCRIPTION_KEY_ALIASES: Final[tuple[str, ...]] = (
    "ATOMADIC_SUBSCRIPTION_KEY",
    "FORGE_API_KEY",
)
ENV_NEXUS_VAULT_PATH: Final[str] = "ATOMADIC_VAULT_ENV"
NEXUS_PREMIUM_HINT: Final[str] = (
    "Nexus attestation skipped. Purchase or configure a Nexus key, reuse "
    "FORGE_MASTER_API_KEY as a master key, or wire x402 payments for "
    "metered access."
)

# ── LIVE primitives we wire against (verified 2026-05-06) ────────────
# Each is a tools/call name on the Nexus MCP. The bridge exposes
# Python wrappers that POST the JSON-RPC envelope and return the
# parsed result. Anti-replay + signing happens server-side.
NEXUS_TOOL_IDENTITY_VERIFY: Final[str] = "identity_verify"
NEXUS_TOOL_FEDERATION_MINT: Final[str] = "federation_mint"
NEXUS_TOOL_AUTHORIZE_ACTION: Final[str] = "authorize_action"
NEXUS_TOOL_SYS_TRUST_GATE: Final[str] = "sys_trust_gate"
NEXUS_TOOL_CONTRACT_VERIFY: Final[str] = "contract_verify"
NEXUS_TOOL_LINEAGE_RECORD: Final[str] = "lineage_record"
NEXUS_TOOL_RATCHET_REGISTER: Final[str] = "ratchet_register"

LIVE_NEXUS_TOOLS: Final[frozenset[str]] = frozenset({
    NEXUS_TOOL_IDENTITY_VERIFY,
    NEXUS_TOOL_FEDERATION_MINT,
    NEXUS_TOOL_AUTHORIZE_ACTION,
    NEXUS_TOOL_SYS_TRUST_GATE,
    NEXUS_TOOL_CONTRACT_VERIFY,
    NEXUS_TOOL_LINEAGE_RECORD,
    NEXUS_TOOL_RATCHET_REGISTER,
})

# Reasonable connect/read timeouts in seconds.
DEFAULT_NEXUS_TIMEOUT_SECS: Final[float] = 10.0

__all__ = [
    "SCHEMA_VERSION_NEXUS_CALL_V1",
    "DEFAULT_NEXUS_BASE_URL", "DEFAULT_NEXUS_MCP_PATH",
    "ENV_NEXUS_BASE_URL", "ENV_NEXUS_MASTER_KEY", "ENV_NEXUS_SUBSCRIPTION_KEY",
    "ENV_NEXUS_BASE_URL_ALIASES",
    "ENV_NEXUS_MASTER_KEY_ALIASES",
    "ENV_NEXUS_SUBSCRIPTION_KEY_ALIASES",
    "ENV_NEXUS_VAULT_PATH",
    "NEXUS_PREMIUM_HINT",
    "NEXUS_TOOL_IDENTITY_VERIFY", "NEXUS_TOOL_FEDERATION_MINT",
    "NEXUS_TOOL_AUTHORIZE_ACTION", "NEXUS_TOOL_SYS_TRUST_GATE",
    "NEXUS_TOOL_CONTRACT_VERIFY", "NEXUS_TOOL_LINEAGE_RECORD",
    "NEXUS_TOOL_RATCHET_REGISTER",
    "LIVE_NEXUS_TOOLS",
    "DEFAULT_NEXUS_TIMEOUT_SECS",
]
