"""Tier a0 — hive sync pipeline constants.

The 4-agent collaboration pipeline (Forge / Cognition / Doc /
Research / future swarm members ≤ D_max) needs a register-and-discover
primitive: any new agent activates against the protocol, declares its
lane, signs an identity claim, subscribes to relevant artifact-change
events, and starts contributing. All cross-agent state lives in
public artifacts (wisdom.jsonl, commits, a registry file at
``.atomadic-forge/hive/agents.jsonl``); no direct messaging.

Critical for the Atomadic-as-sovereign-AI-with-claws endpoint.
"""
from __future__ import annotations

from typing import Final

SCHEMA_VERSION_HIVE_AGENT_V1: Final[str] = "atomadic-forge.hive_agent/v1"
SCHEMA_VERSION_HIVE_REGISTRY_V1: Final[str] = "atomadic-forge.hive_registry/v1"
SCHEMA_VERSION_HIVE_OBSERVE_V1: Final[str] = "atomadic-forge.hive_observe/v1"
SCHEMA_VERSION_HIVE_CONSENSUS_V1: Final[str] = "atomadic-forge.hive_consensus/v1"

HIVE_DIR_REL: Final[str] = ".atomadic-forge/hive"
HIVE_AGENTS_FILE_REL: Final[str] = ".atomadic-forge/hive/agents.jsonl"
HIVE_CONSENSUS_FILE_REL: Final[str] = ".atomadic-forge/hive/consensus.jsonl"

# ── Canonical agent roles ────────────────────────────────────────────
# Open-set in the schema (any string is allowed) but these four are
# the canonical lanes referenced in AGENT_COLLAB_PROTOCOL.md. Adding
# new roles is fine; rename only with team consensus.
ROLE_FORGE: Final[str] = "forge"          # substrate builder
ROLE_COGNITION: Final[str] = "cognition"  # substrate consumer (sovereign-side)
ROLE_DOC: Final[str] = "doc"              # substrate cartographer
ROLE_RESEARCH: Final[str] = "research"    # substrate observer

CANONICAL_ROLES: Final[frozenset[str]] = frozenset({
    ROLE_FORGE, ROLE_COGNITION, ROLE_DOC, ROLE_RESEARCH,
})

# ── Subscription event types ─────────────────────────────────────────
# Each agent declares which artifact-change events it cares about.
# An "observe" call returns the cross-section of pending events that
# match the caller's subscriptions.
EVENT_COMMIT_TO_MAIN: Final[str] = "commit.main"
EVENT_NEW_WISDOM: Final[str] = "wisdom.new"
EVENT_SUPERSEDED_WISDOM: Final[str] = "wisdom.superseded"
EVENT_NEW_RECIPE: Final[str] = "recipe.new"
EVENT_VERIFY_PASS: Final[str] = "verify.pass"
EVENT_VERIFY_FAIL: Final[str] = "verify.fail"
EVENT_SCHEMA_DRIFT: Final[str] = "surface.drift"
EVENT_CONSENSUS_PROPOSED: Final[str] = "consensus.proposed"
EVENT_CONSENSUS_RESOLVED: Final[str] = "consensus.resolved"

ALL_EVENT_TYPES: Final[frozenset[str]] = frozenset({
    EVENT_COMMIT_TO_MAIN, EVENT_NEW_WISDOM, EVENT_SUPERSEDED_WISDOM,
    EVENT_NEW_RECIPE, EVENT_VERIFY_PASS, EVENT_VERIFY_FAIL,
    EVENT_SCHEMA_DRIFT, EVENT_CONSENSUS_PROPOSED, EVENT_CONSENSUS_RESOLVED,
})

# Default subscriptions per canonical role. Agents can override by
# passing custom ``subscribes_to`` at register time.
DEFAULT_SUBSCRIPTIONS: Final[dict[str, frozenset[str]]] = {
    ROLE_FORGE: frozenset({
        EVENT_NEW_WISDOM, EVENT_VERIFY_FAIL, EVENT_SCHEMA_DRIFT,
        EVENT_CONSENSUS_PROPOSED,
    }),
    ROLE_COGNITION: frozenset({
        EVENT_COMMIT_TO_MAIN, EVENT_NEW_WISDOM, EVENT_NEW_RECIPE,
        EVENT_CONSENSUS_PROPOSED, EVENT_CONSENSUS_RESOLVED,
    }),
    ROLE_DOC: frozenset({
        EVENT_COMMIT_TO_MAIN, EVENT_NEW_RECIPE, EVENT_SCHEMA_DRIFT,
    }),
    ROLE_RESEARCH: frozenset({
        EVENT_NEW_WISDOM, EVENT_SUPERSEDED_WISDOM, EVENT_NEW_RECIPE,
        EVENT_VERIFY_PASS,
    }),
}

# ── Consensus quorum defaults ────────────────────────────────────────
# Pre-swarm primitive — lets 2-N agents vote on cross-cutting
# decisions before the full v0.14 swarm tier ships. Quorum is the
# minimum vote count required for a consensus to resolve. Default
# is "majority of registered agents" with a floor of 2.
DEFAULT_CONSENSUS_QUORUM_MIN: Final[int] = 2
DEFAULT_CONSENSUS_TIMEOUT_SECS: Final[int] = 3600  # 1h

# D_max delegation cap (corpus-anchored system invariant: 23).
# The hive registry refuses to grow beyond this. Re-export from
# mhed_invariants for ergonomic single-import on the hive surface.
from .mhed_invariants import D_MAX_DELEGATION  # noqa: E402

D_MAX_AGENTS: Final[int] = D_MAX_DELEGATION  # alias for clarity

__all__ = [
    "SCHEMA_VERSION_HIVE_AGENT_V1",
    "SCHEMA_VERSION_HIVE_REGISTRY_V1",
    "SCHEMA_VERSION_HIVE_OBSERVE_V1",
    "SCHEMA_VERSION_HIVE_CONSENSUS_V1",
    "HIVE_DIR_REL", "HIVE_AGENTS_FILE_REL", "HIVE_CONSENSUS_FILE_REL",
    "ROLE_FORGE", "ROLE_COGNITION", "ROLE_DOC", "ROLE_RESEARCH",
    "CANONICAL_ROLES",
    "EVENT_COMMIT_TO_MAIN", "EVENT_NEW_WISDOM", "EVENT_SUPERSEDED_WISDOM",
    "EVENT_NEW_RECIPE", "EVENT_VERIFY_PASS", "EVENT_VERIFY_FAIL",
    "EVENT_SCHEMA_DRIFT", "EVENT_CONSENSUS_PROPOSED",
    "EVENT_CONSENSUS_RESOLVED", "ALL_EVENT_TYPES", "DEFAULT_SUBSCRIPTIONS",
    "DEFAULT_CONSENSUS_QUORUM_MIN", "DEFAULT_CONSENSUS_TIMEOUT_SECS",
    "D_MAX_AGENTS",
]
