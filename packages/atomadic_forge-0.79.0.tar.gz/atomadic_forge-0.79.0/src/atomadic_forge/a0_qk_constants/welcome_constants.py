"""Tier a0 — forge welcome constants.

The welcome flow is the first call an agent makes after connecting to
Forge. It runs a focused recon (scout + certify + wire) and packages
the result so the agent immediately knows three things:

  1. What state the repo is actually in (numbers, not vibes)
  2. What Forge can do for it from here (capability surface)
  3. The single most useful next call

Voice for the narrative is "senior architect reporting from a scan" —
specific, grounded, confident. No marketing copy, no sycophancy.
"""
from __future__ import annotations

from typing import Final

SCHEMA_VERSION_WELCOME_V1: Final[str] = "atomadic-forge.welcome/v1"

# Score thresholds map to one-word health labels in the narrative.
HEALTH_LABEL_THRESHOLDS: Final[tuple[tuple[float, str], ...]] = (
    (95.0, "production-ready"),
    (85.0, "ship-ready"),
    (70.0, "improving"),
    (50.0, "needs work"),
    (0.0, "early"),
)

# Cap suggestions / strengths so the response stays scannable.
TOP_N_STRENGTHS: Final[int] = 3
TOP_N_PRIORITIES: Final[int] = 3

# Scope guard — refuse to walk monstrously large trees by accident.
# A welcome run scoped at a workspace root rather than a single repo
# (e.g. ``cd C:\!!AtomadicStandard && forge welcome``) was the actual
# cause of the v0.16.1 "welcome hangs" report: 38 972 .py files.
# Boris-demo lesson — prevent it at the substrate.
SCOPE_GUARD_DEFAULT_MAX_FILES: Final[int] = 5000

__all__ = [
    "HEALTH_LABEL_THRESHOLDS",
    "SCHEMA_VERSION_WELCOME_V1",
    "SCOPE_GUARD_DEFAULT_MAX_FILES",
    "TOP_N_PRIORITIES",
    "TOP_N_STRENGTHS",
]
