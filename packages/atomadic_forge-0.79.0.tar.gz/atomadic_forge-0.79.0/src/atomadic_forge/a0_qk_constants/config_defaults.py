"""Tier a0 — config defaults and file-location constants for Atomadic Forge.

The ``custom_providers`` field (added 2026-05-07 in v0.18.0) lets users
declare ANY OpenAI-compatible LLM provider by writing one entry — base
URL, model, env-var name — without writing Python.  See
:mod:`atomadic_forge.a1_at_functions.custom_provider_client` for the
full schema and the bundled provider presets.
"""

from __future__ import annotations

from typing import TypedDict


class CustomProviderEntry(TypedDict, total=False):
    """One row in ``ForgeConfig.custom_providers``."""
    name: str            # required — what user passes to ``--provider``
    preset: str          # optional — bundled preset (openai/groq/deepseek/…)
    base_url: str        # required (unless preset supplies it)
    model: str           # required (unless preset supplies it)
    api_key_env: str     # required (unless preset supplies it)
    format: str          # default "openai" (chat/completions)
    extra_headers: dict[str, str]
    timeout_s: float


class ForgeConfig(TypedDict, total=False):
    provider: str
    ollama_url: str
    ollama_model: str
    # Hardcoded provider keys — kept for backward compatibility.
    gemini_key: str | None
    anthropic_key: str | None
    openai_key: str | None
    # NEW v0.18.0: declare any LLM provider in one place.
    custom_providers: list[CustomProviderEntry]
    default_target_score: float
    auto_apply: bool
    output_dir: str
    sources_dir: str
    package_prefix: str


DEFAULT_CONFIG: ForgeConfig = {
    "provider": "auto",
    "ollama_url": "http://localhost:11434",
    "ollama_model": "mistral:7b-instruct",
    "gemini_key": None,
    "anthropic_key": None,
    "openai_key": None,
    "custom_providers": [],
    "default_target_score": 75.0,
    "auto_apply": False,
    "output_dir": "./forged",
    "sources_dir": "./sources",
    "package_prefix": "forged",
}

CONFIG_FILE_NAME = "config.json"
GLOBAL_CONFIG_DIR = "~/.atomadic-forge"
LOCAL_CONFIG_DIR = ".atomadic-forge"
