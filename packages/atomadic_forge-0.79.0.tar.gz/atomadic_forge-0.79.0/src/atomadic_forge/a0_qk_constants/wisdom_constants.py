"""Tier a0 — wisdom DB constants.

The wisdom layer sits between raw lineage events (what happened) and
curated recipes (what works). It captures cross-session, agent-recorded
insights that future agents/devs can recall during recon and have
prompted-for-capture during verify.

Schema-versioned, append-only JSONL at ``.atomadic-forge/wisdom.jsonl``.
Mirrors the lineage storage pattern; same trust gates apply.
"""
from __future__ import annotations

from typing import Final

SCHEMA_VERSION_WISDOM_V1: Final[str] = "atomadic-forge.wisdom/v1"
SCHEMA_VERSION_WISDOM_RECALL_V1: Final[str] = "atomadic-forge.wisdom_recall/v1"
SCHEMA_VERSION_WISDOM_CAPTURE_V1: Final[str] = "atomadic-forge.wisdom_capture/v1"

WISDOM_FILE_REL: Final[str] = ".atomadic-forge/wisdom.jsonl"

# ── Trust thresholds for the verify-side capture prompt ──────────────
# Below ALL of these, verify does NOT emit a wisdom_capture_prompt.
# Stops alert fatigue on trivial sessions (read-only, doc-only, etc.)
# while ensuring meaningful change always offers a capture path.
DEFAULT_MIN_LINEAGE_EVENTS: Final[int] = 3
DEFAULT_MIN_SCORE_DELTA: Final[float] = 1.0  # certify score movement
DEFAULT_MIN_SESSION_SECS: Final[int] = 300   # 5 minutes

# ── Scope tags ───────────────────────────────────────────────────────
# Used for relevance-ranking on recall. Free-form strings encouraged
# for fine-grained tagging; these are the canonical categories.
WISDOM_SCOPE_REPO: Final[str] = "repo"          # specific to one repo
WISDOM_SCOPE_FORGE: Final[str] = "forge"        # forge-toolchain-wide
WISDOM_SCOPE_GENERAL: Final[str] = "general"    # cross-repo lessons

# ── Confidence ladder ────────────────────────────────────────────────
# Used both for ranking on recall (high-confidence first) and for
# auto-promotion gates (only confidence >= PROMOTE_THRESHOLD ever
# graduates to a draft recipe).
CONFIDENCE_LOW: Final[float] = 0.50      # provisional, single observation
CONFIDENCE_MEDIUM: Final[float] = 0.75   # corroborated by 2+ entries or by lineage
CONFIDENCE_HIGH: Final[float] = 0.90     # corroborated by 3+ + clean trust signals
PROMOTE_THRESHOLD: Final[float] = 0.90   # at-or-above → draft recipe candidate

# ── Recall defaults ──────────────────────────────────────────────────
DEFAULT_RECALL_TOP_N: Final[int] = 5
DEFAULT_RECALL_MAX_AGE_DAYS: Final[int] = 365
