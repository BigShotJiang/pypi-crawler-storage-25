"""Tier a0 — single source of truth for forge MCP tool schema versions.

Closes friction F-6 from FRICTION_LOG.md: schema-version strings were
hardcoded in 2-3 places per tool (the implementation module, the wired
stub in mcp_protocol.py, sometimes the tests). When a tool's response
shape changed, drift between these copies caused stale schemas in the
wire.

This module is the canonical mapping ``tool_name → schema_version``.
Every tool's implementation module references THIS dict; the
``tool_factory`` template can also pull from it. One write, one
truth.

The registry IS data, not behaviour — pure a0 constants. Touching it
is a structured change (add a key, bump the version), reviewable in
isolation.
"""
from __future__ import annotations

SCHEMA_VERSIONS: dict[str, str] = {
    # v0.32.0 mergers
    # recon + explain_repo → explore; +call_graph+smell_scan+lineage(v0.36.0); +discover(v0.41.0)
    # +wisdom(v0.44.0, reverted v0.46.0 — wisdom restored as standalone)
    "explore": "atomadic-forge.explore/v5",
    # certify + wire → audit; +enforce(v0.35.0), +validate+guard(v0.36.0); +composite+gate+health(v0.40.0)
    # +check+score+tests+cna+rollback+diff(preflight absorbed v0.42.0)
    "audit": "atomadic-forge.audit/v4",

    # v0.33.0 mergers
    # hive_agent + hive_consensus → hive; session(handoff+enhancement) absorbed in v0.38.0
    # +nexus(v0.45.0, reverted v0.46.0 — nexus restored as standalone)
    "hive": "atomadic-forge.hive/v4",
    # iterate + evolve → loop → plan(iterate|resume|evolve|evolve_step) in v0.39.0
    # handoff + enhancement → session → hive(v0.38.0)
    # cna_check absorbed into preflight as action='cna' (preflight stays /v2)

    # enforce absorbed into audit(action='enforce') in v0.35.0
    # lineage absorbed into explore(action='lineage') in v0.36.0
    # v0.10.0 mergers — these supersede the older split tools.
    # recipes merged into workflow(action='recipes') in v0.34.0
    "plan": "atomadic-forge.agent_plan/v5",  # ← auto_plan+adapt_plan+plan_apply(v0.30.0); +locate+commit(v0.37.0); +loop+transmute(v0.39.0); +scaffold(v0.41.0); +context_pack(v0.43.0)
    # (worktree_status folded into doctor; exported_api_check folded into verify)

    # Codex-original tools
    # context_pack absorbs workflow(compose|policy|recipes) in v0.37.0 → /v2
    # v0.43.0: context_pack absorbed into plan(context|compose|policy|recipes)
    # v0.30.0: preflight_change+score_patch → preflight
    # v0.32.0: select_tests absorbed as action='tests'
    # v0.33.0: cna_check absorbed as action='cna'
    # v0.42.0: preflight absorbed into audit(check|score|tests|cna|rollback|diff)
    # trust_gate_response merged into verify(action='gate') in v0.34.0
    # emergent absorbed into discover(action='scan'|'swarm') in v0.36.0
    # doctor absorbed into verify(action='health') in v0.35.0

    # v0.29.0 — transmuter merged (auto + cherry + finalize → transmute)
    # transmute absorbed into plan(auto|cherry|finalize) in v0.39.0

    # v0.31.0 mergers
    # rollback_plan + manifest_diff → change_review → preflight(rollback|diff) in v0.35.0
    # sidecar_validate + guard_install → maintain → audit(validate|guard) in v0.36.0
    # compose_tools + load_policy → workflow → context_pack(compose|policy|recipes) in v0.37.0
    # harvest + synergy_scan → discover → explore(harvest|synergy|scan|swarm) in v0.41.0

    # v0.34.0 — verify dispatches composite+gate+health; verify absorbed into audit(v0.40.0)

    # code_intel absorbed into explore(action='call_graph'|'smell_scan') in v0.36.0
    # lineage absorbed into explore(action='lineage') in v0.36.0; maintain absorbed into audit in v0.36.0
    # forge_util(locate+commit) absorbed into plan in v0.37.0; workflow(compose|policy|recipes) → context_pack

    # Meta and infrastructure
    # tool_factory absorbed into plan(action=scaffold) in v0.41.0

    # v0.27.0 — wisdom tools merged (5→1); v0.44.0 absorbed into explore, v0.46.0 restored standalone
    "wisdom": "atomadic-forge.wisdom/v2",

    # v0.14.0a7 — AAAA-Nexus LIVE primitives exposed as MCP tools
    # v0.28.0 — nexus primitives merged (7→1); v0.45.0 absorbed into hive, v0.46.0 restored standalone
    "nexus": "atomadic-forge.nexus_call/v2",

    # v0.14.0a12 — welcome: first-call handshake
    "welcome": "atomadic-forge.welcome/v1",

    # v0.47.0 — `forge create` exposed as MCP tool
    # (intent + seed_repos -> shippable pip package via emergent_swarm + materialize)
    "create": "atomadic-forge.create/v1",

    # v0.48.0 — flagship transmuter pipeline restored as standalone (auto/cherry/finalize)
    # plan v0.39.0: transmute absorbed; v0.48.0: split out — `auto` flagship discoverable again
    "transmute": "atomadic-forge.transmute/v2",

    # v0.48.0 — LLM iteration loops restored as standalone (iterate/resume/evolve/evolve_step)
    # plan v0.39.0: loop absorbed; v0.48.0: split out — clearer that `loop` requires LLM client
    "loop": "atomadic-forge.loop/v2",
}


def schema_version_for(tool_name: str) -> str:
    """Return the canonical schema version for a tool name.

    Args:
        tool_name: snake_case tool identifier (e.g. "harvest").

    Returns:
        The full schema_version string ``"atomadic-forge.<n>/v1"``.

    Raises:
        KeyError: if ``tool_name`` is not registered. Adding a new
            tool requires adding it to ``SCHEMA_VERSIONS`` first;
            this fail-loud is intentional.
    """
    return SCHEMA_VERSIONS[tool_name]


__all__ = ["SCHEMA_VERSIONS", "schema_version_for"]
