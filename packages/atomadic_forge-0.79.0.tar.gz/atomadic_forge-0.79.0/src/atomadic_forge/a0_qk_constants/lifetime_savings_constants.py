"""Tier a0 — lifetime token-savings ledger constants.

Every time a Forge welcome (or any opt-in tool) runs, it appends a
single JSONL line to the ledger with {timestamp, tool, tokens_saved}.
The welcome flow reads + sums to surface a lifetime cumulative total
so users see savings add up across sessions.
"""
from __future__ import annotations

from typing import Final

LIFETIME_LEDGER_REL: Final[str] = ".atomadic-forge/tokens_saved.jsonl"

SCHEMA_VERSION_LIFETIME_SAVINGS_V1: Final[str] = (
    "atomadic-forge.lifetime_savings/v1"
)

__all__ = [
    "LIFETIME_LEDGER_REL",
    "SCHEMA_VERSION_LIFETIME_SAVINGS_V1",
]
