"""Tier a0 — types for the Materialize pipeline.

Materialize takes ranked emergent candidates and writes a fresh,
pip-installable Python package containing one a3 feature module per
selected candidate, plus a tier-organized scaffold (pyproject, README,
tests, tier __init__.py files).
"""

from __future__ import annotations

from typing import TypedDict


class MaterializedFileCard(TypedDict):
    """One file written during materialize."""

    path: str            # absolute path on disk
    role: str            # "feature" | "scaffold" | "test" | "init"
    candidate_id: str    # "" if not feature-derived
    bytes: int


class MaterializeReport(TypedDict):
    """Top-level result of `forge materialize`."""

    schema_version: str           # "atomadic-forge.materialize/v1"
    generated_at_utc: str
    out_dir: str
    package: str
    candidates_selected: list[str]   # candidate_ids in order
    files_written: list[MaterializedFileCard]
    certify_score: float | None      # null if --no-certify
    certify_grade: str | None        # "PASS" | "REFINE" | "FAIL" | None
    wire_violations: int | None      # null if not run
    summary_line: str
