"""Tier a0 — system invariants used across forge.

These constants are derived from a private formal corpus
(IP-protected; formally verified). The values below are public-safe —
the derivations that produce them are not. Treat the numbers as
load-bearing axioms for trust-gated and delegation-bounded operations.

* :data:`D_MAX_DELEGATION` — hard cap on swarm/sub-agent fanout depth.
  Value: 23. Round-4 cherry-hunter refuses to recurse deeper than
  this, full stop.

* :data:`TAU_TRUST` — minimum-confidence threshold for trust-gating.
  Value: ≈ 0.99835. The minimum confidence required for a cherry-pick
  proposal to be marked ``trust_gated_pass`` rather than
  ``review_required``.

* :data:`TAU_TRUST_RATIO` — alternative trust ratio with the same
  numeric magnitude as :data:`TAU_TRUST` but a distinct provenance —
  kept as a separate constant for traceability when invariant-checking
  emergent scans.

* :data:`OMEGA_0` — Zero Unmapped Noise Floor. Any analyzer that
  claims to "have fully accounted for" a corpus must produce a shape
  invariant whose residue zeroes against this — the "no hallucination"
  anchor.

These are integer / rational where the source corpus says so, and
float only where a numerical evaluation is provided. No magic values:
every constant is corpus-anchored.

Tier rationale: a0 (constants only). Imported by a1+ as needed.
"""
from __future__ import annotations

from fractions import Fraction

# ── System invariants (corpus-anchored; values public, derivations not) ──

#: Maximum delegation depth.
#:
#: Forge uses this as the maximum ``rounds`` in evolve sessions and
#: the maximum repo count in ``recon_swarm`` / ``harvest``. Deeper
#: recursion is refused, not silently truncated.
D_MAX_DELEGATION: int = 23

#: TAU_TRUST — Prime-Protected Systemic Integrity threshold.
#:
#: Used by Round-4 cherry-hunter to gate "trust-pass" cherry-pick
#: proposals: a candidate's combined confidence (recon classification
#: confidence × structural-similarity score × wire-cleanliness) must
#: meet or exceed this to be auto-applyable; below it the candidate
#: is marked ``review_required`` instead.
#:
#: Stored as :class:`Fraction` so the integer numerator/denominator
#: stay exact (the float view is provided as :data:`TAU_TRUST_FLOAT`).
TAU_TRUST: Fraction = Fraction(1820, 1823)

#: Float view of :data:`TAU_TRUST` ≈ 0.998354361...
TAU_TRUST_FLOAT: float = 1820 / 1823

#: TAU_TRUST_RATIO — alternative trust ratio.
#:
#: Numerically near-identical to :data:`TAU_TRUST` (≈ 0.99835) but
#: arises from a different construction. Kept separate so cross-checks
#: can distinguish "trust threshold" from this ratio.
TAU_TRUST_RATIO: Fraction = Fraction(196560, 196884)

#: OMEGA_0 — Zero Unmapped Noise Floor.
#:
#: Used as a self-check anchor: any forge analyzer that claims to
#: have fully accounted for a corpus produces a shape invariant
#: whose residue zeroes against this. Non-zero residue ⇒
#: unaccounted-for symbols.
OMEGA_0: int = 196884 - 196560 - 324  # corpus-anchored; ≡ 0 (verified below)

#: PHI_ANCHOR — integer anchor (corpus-anchored constant).
#:
#: Not load-bearing for forge today; included for completeness and
#: forward-compat with future trust-gating tiers.
PHI_ANCHOR: int = 137

#: Triality hierarchy factor.
#: ≈ 1.0698. Used by lang's tokenizer; kept here so forge can
#: reference the same constant by name when integrating with lang's
#: overfit/compression metrics.
PHI_TRI: Fraction = Fraction(46, 43)

PHI_TRI_FLOAT: float = 46 / 43


# ── Self-check assertions (executed at import) ──────────────────────────
# OMEGA_0 must literally equal zero. If anyone ever changes one of the
# three numbers above, this raises at import time — fail-fast.

assert OMEGA_0 == 0, (
    f"OMEGA_0 anchor broken: residue = {OMEGA_0}, expected 0. "
    "One of the corpus-anchored numbers has drifted; do NOT mask this — "
    "find the source-of-truth conflict and fix."
)
assert D_MAX_DELEGATION == 23, "D_MAX_DELEGATION drift"
assert TAU_TRUST.numerator == 1820 and TAU_TRUST.denominator == 1823, \
    "TAU_TRUST drift from corpus value"


__all__ = [
    "D_MAX_DELEGATION",
    "OMEGA_0",
    "PHI_ANCHOR",
    "PHI_TRI",
    "PHI_TRI_FLOAT",
    "TAU_TRUST",
    "TAU_TRUST_FLOAT",
    "TAU_TRUST_RATIO",
]
