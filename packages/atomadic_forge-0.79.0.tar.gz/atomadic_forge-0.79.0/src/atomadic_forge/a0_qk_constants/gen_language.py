"""Tier a0 — generation language constants for forge iterate / evolve.

Forge's generator loop (``forge iterate``, ``forge evolve``) emits source
code in a target language.  As of 2026-05-06 Forge supports a full polyglot
matrix: **python, javascript, typescript, rust, go, swift, kotlin**.  Each
language has a tier-organised scaffold renderer in a1 and an emit branch
in a3 ``forge_loop._scaffold_package``.

Pure data.  Determines:
  * ``PKG_ROOT_TEMPLATE`` — where Forge writes the generated package
    (Python uses ``output/src/<pkg>/`` for pip-install compatibility;
    JS/TS/Swift/Kotlin use ``output/<pkg>/``; Rust + Go use a single
    crate/module rooted at the output directly).
  * ``ALLOWED_FILE_EXTS`` — what file suffixes ``_safe_path`` accepts.
    Forge rejects any other suffix to prevent the LLM from emitting
    polyglot junk into a single-language tree.
  * ``MAIN_EXT`` — the canonical primary extension used in scaffolded
    tier file names.
  * ``EMITS_INIT_FILES`` — whether Forge generates ``__init__.py``-style
    package indices (Python only).
  * ``EMITS_PYPROJECT`` — whether Forge writes ``pyproject.toml`` (Python).
  * ``EMITS_CARGO_TOML`` — whether Forge writes ``Cargo.toml`` (Rust).
  * ``EMITS_GO_MOD``      — whether Forge writes ``go.mod`` (Go).
  * ``EMITS_PACKAGE_SWIFT`` — whether Forge writes ``Package.swift`` (Swift).
  * ``EMITS_BUILD_GRADLE`` — whether Forge writes ``build.gradle.kts`` (Kotlin).

Per-tier file-naming for the new languages:
  * Rust   uses ``mod.rs`` per tier directory + a top-level ``src/lib.rs``.
  * Go     uses ``<tier>.go`` with ``package <last_segment>`` declarations.
  * Swift  uses ``<tier>.swift`` under ``Sources/<crate>/<tier>/``.
  * Kotlin uses ``<tier>.kt`` under ``src/main/kotlin/<package>/<tier>/``.

This is intentionally small.  More language-specific knobs (e.g. tsconfig
generation, vitest vs node:test) belong in scaffold helpers, not here.
"""

from __future__ import annotations

from typing import Final, Literal

Language = Literal[
    "python", "javascript", "typescript", "rust", "go", "swift", "kotlin",
]

LANGUAGES: Final[tuple[Language, ...]] = (
    "python", "javascript", "typescript", "rust", "go", "swift", "kotlin",
)

DEFAULT_LANGUAGE: Final[Language] = "python"


# Package-root templates.  The keys are language names; values are
# format strings with a single ``{package}`` substitution that gets
# joined to the user's ``output`` directory.
PKG_ROOT_TEMPLATE: Final[dict[Language, str]] = {
    "python":     "src/{package}",
    "javascript": "{package}",
    "typescript": "{package}",
    # Rust:   crate root holds Cargo.toml; sources live under src/.
    # The package _root_ Forge points other tools at is the crate src/.
    "rust":       "src",
    # Go:     module declared at the output root via go.mod; tier dirs
    # are top-level packages so `import "<module>/<tier>"` resolves.
    "go":         "{package}",
    # Swift:  SwiftPM expects Sources/<TargetName>/.
    "swift":      "Sources/{package}",
    # Kotlin: Gradle/JVM convention — src/main/kotlin/<package>/.
    "kotlin":     "src/main/kotlin/{package}",
}


# File suffixes Forge will accept from an LLM emit, per language.  Every
# other suffix is silently dropped by ``_safe_path``.  Note all languages
# allow ``.md`` (READMEs / per-file documentation) and the relevant config
# file (``.toml`` for Python+Rust, ``.json`` for JS/TS, etc.).
ALLOWED_FILE_EXTS: Final[dict[Language, frozenset[str]]] = {
    "python":     frozenset({".py", ".md", ".toml"}),
    "javascript": frozenset({".js", ".mjs", ".cjs", ".jsx",
                              ".json", ".md"}),
    "typescript": frozenset({".ts", ".tsx", ".js", ".mjs",
                              ".json", ".md"}),
    "rust":       frozenset({".rs", ".toml", ".md"}),
    "go":         frozenset({".go", ".mod", ".sum", ".md"}),
    "swift":      frozenset({".swift", ".md"}),
    "kotlin":     frozenset({".kt", ".kts", ".md"}),
}


# Canonical primary extension used when Forge scaffolds tier files.
MAIN_EXT: Final[dict[Language, str]] = {
    "python":     ".py",
    "javascript": ".js",
    "typescript": ".ts",
    "rust":       ".rs",
    "go":         ".go",
    "swift":      ".swift",
    "kotlin":     ".kt",
}


# Whether Forge emits Python-style package indices (``__init__.py``).
# JS/TS use ES module exports directly — no per-directory index file
# is required for imports to resolve.  Rust uses ``mod.rs``; Go/Swift/
# Kotlin do not need a per-directory index file.
EMITS_INIT_FILES: Final[dict[Language, bool]] = {
    "python":     True,
    "javascript": False,
    "typescript": False,
    "rust":       False,
    "go":         False,
    "swift":      False,
    "kotlin":     False,
}


# Whether Forge writes a ``pyproject.toml`` at the output root.
EMITS_PYPROJECT: Final[dict[Language, bool]] = {
    "python":     True,
    "javascript": False,
    "typescript": False,
    "rust":       False,
    "go":         False,
    "swift":      False,
    "kotlin":     False,
}


# Per-language build-config file emit flags.  Each maps to a different
# scaffolder helper in ``a1.scaffold_polyglot``.
EMITS_CARGO_TOML: Final[dict[Language, bool]] = {
    "python": False, "javascript": False, "typescript": False,
    "rust": True,    "go": False,         "swift": False, "kotlin": False,
}
EMITS_GO_MOD: Final[dict[Language, bool]] = {
    "python": False, "javascript": False, "typescript": False,
    "rust": False,   "go": True,          "swift": False, "kotlin": False,
}
EMITS_PACKAGE_SWIFT: Final[dict[Language, bool]] = {
    "python": False, "javascript": False, "typescript": False,
    "rust": False,   "go": False,         "swift": True,  "kotlin": False,
}
EMITS_BUILD_GRADLE: Final[dict[Language, bool]] = {
    "python": False, "javascript": False, "typescript": False,
    "rust": False,   "go": False,         "swift": False, "kotlin": True,
}


# Whether the per-tier directory needs a `mod.rs`-style index file for
# imports to resolve.  Rust does (declares submodules); the others don't.
EMITS_TIER_MOD_RS: Final[dict[Language, bool]] = {
    "python": False, "javascript": False, "typescript": False,
    "rust": True,    "go": False,         "swift": False, "kotlin": False,
}


def normalize_language(value: str | None) -> Language:
    """Coerce a user-supplied language string into the canonical Language.

    Accepts the canonical names plus common aliases.  Returns the canonical
    Language literal.  Raises ``ValueError`` if the input is not recognised.

    ``None`` returns the default language (``"python"``) so callers can
    pass through optional CLI flags without branching.
    """
    if value is None:
        return DEFAULT_LANGUAGE
    v = value.strip().lower()
    if v in ("python", "py"):
        return "python"
    if v in ("javascript", "js", "node"):
        return "javascript"
    if v in ("typescript", "ts"):
        return "typescript"
    if v in ("rust", "rs"):
        return "rust"
    if v in ("go", "golang"):
        return "go"
    if v in ("swift",):
        return "swift"
    if v in ("kotlin", "kt"):
        return "kotlin"
    raise ValueError(
        f"unknown language: {value!r} — expected one of {list(LANGUAGES)}"
    )


def pkg_root_for(language: Language, package: str) -> str:
    """Return the package-root path *relative to the output directory*.

    Pure: no I/O.  Caller joins this against their output ``Path``.
    """
    return PKG_ROOT_TEMPLATE[language].format(package=package)
