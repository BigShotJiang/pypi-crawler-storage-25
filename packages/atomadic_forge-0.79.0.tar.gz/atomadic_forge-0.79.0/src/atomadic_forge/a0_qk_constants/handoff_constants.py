"""Tier a0 — handoff artifact constants.

A handoff is a structured JSON snapshot of one agent session — what was
done, what's pending, what the next agent needs to know. Designed for
agent-to-agent context transfer when a session ends without finishing.
"""
from __future__ import annotations

from typing import Final

SCHEMA_VERSION_HANDOFF_V1: Final[str] = "atomadic-forge.handoff/v1"

HANDOFF_DIR_REL: Final[str] = ".atomadic-forge/handoffs"

# Free-text key_context is capped to keep handoff files reviewable; the
# full transcript belongs in the agent's own logs, not here.
KEY_CONTEXT_MAX_CHARS: Final[int] = 8000

AXIOM_GUARD_PASS: Final[str] = "PASS"
AXIOM_GUARD_QUARANTINE: Final[str] = "QUARANTINE"
AXIOM_GUARD_VALUES: Final[frozenset[str]] = frozenset({
    AXIOM_GUARD_PASS, AXIOM_GUARD_QUARANTINE,
})

__all__ = [
    "SCHEMA_VERSION_HANDOFF_V1",
    "HANDOFF_DIR_REL",
    "KEY_CONTEXT_MAX_CHARS",
    "AXIOM_GUARD_PASS",
    "AXIOM_GUARD_QUARANTINE",
    "AXIOM_GUARD_VALUES",
]
