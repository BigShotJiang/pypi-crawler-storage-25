"""Tier a0 — enhancement-proposal constants.

When Forge (or an agent driving Forge) discovers a pattern strong
enough to become a new tool / feature, it can submit an enhancement
proposal. Proposals are logged as JSONL; an optional AAAA-Nexus
trust-gate call gives the proposal a trust score; publishing to
GitHub stays human-gated (never auto-posted).
"""
from __future__ import annotations

from typing import Final

SCHEMA_VERSION_ENHANCEMENT_PROPOSAL_V1: Final[str] = (
    "atomadic-forge.enhancement_proposal/v1"
)

PROPOSAL_DIR_REL: Final[str] = ".atomadic-forge/enhancement_proposals"
PROPOSAL_LOG_REL: Final[str] = (
    ".atomadic-forge/enhancement_proposals/forge_enhancement_proposals.jsonl"
)

# Trust threshold below which a proposal is logged-only (never published).
# Above this, the proposal becomes eligible for `forge enhancement publish`
# (which still requires an explicit human approval).
DEFAULT_TRUST_THRESHOLD: Final[float] = 0.75

# Trust verdicts accepted from the trust-gate response.
TRUST_VERDICT_PASS: Final[str] = "PASS"
TRUST_VERDICT_FAIL: Final[str] = "FAIL"
TRUST_VERDICT_OFFLINE: Final[str] = "OFFLINE"
TRUST_VERDICT_VALUES: Final[frozenset[str]] = frozenset({
    TRUST_VERDICT_PASS, TRUST_VERDICT_FAIL, TRUST_VERDICT_OFFLINE,
})

__all__ = [
    "DEFAULT_TRUST_THRESHOLD",
    "PROPOSAL_DIR_REL",
    "PROPOSAL_LOG_REL",
    "SCHEMA_VERSION_ENHANCEMENT_PROPOSAL_V1",
    "TRUST_VERDICT_FAIL",
    "TRUST_VERDICT_OFFLINE",
    "TRUST_VERDICT_PASS",
    "TRUST_VERDICT_VALUES",
]
