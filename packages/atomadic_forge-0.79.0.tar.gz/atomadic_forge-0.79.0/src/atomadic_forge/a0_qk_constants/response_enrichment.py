"""Tier a0 — response-enrichment constants.

The ``scope`` block surfaces real measurements the tool already produced
(files scanned, symbols analyzed, traversal depth, wall-clock time)
alongside a transparent token-savings ESTIMATE. Every estimate ships
with its formula in ``tokens_saved_basis`` so a reader can audit the
math instead of trusting the number.

Defaults are conservative middle-ground heuristics. They will land in
the wrong neighborhood for any specific agent/model/prompt combo;
``tokens_saved_basis`` is always present so callers can see exactly
how the number was derived and recompute if they want a different
baseline.
"""
from __future__ import annotations

from typing import Final

SCHEMA_VERSION_SCOPE_V1: Final[str] = "atomadic-forge.scope/v1"

# Per-file token cost a human/agent would pay to manually open + scan
# one source file end-to-end. 40 tok ≈ ~150 chars ≈ a small Python
# module's signatures + dependencies (NOT full body). This is the
# lower-bound "bare review" cost; full reading + reasoning is much
# higher. We pick the lower bound deliberately so the estimate cannot
# be accused of inflating ROI.
TOKENS_PER_FILE_REVIEW: Final[int] = 40

# Per-symbol cost for traversal-style operations (emergent_scan,
# call_graph). One symbol ≈ ~12 tok of read cost when an agent is
# building a mental graph of a codebase.
TOKENS_PER_SYMBOL_TRAVERSAL: Final[int] = 12

__all__ = [
    "SCHEMA_VERSION_SCOPE_V1",
    "TOKENS_PER_FILE_REVIEW",
    "TOKENS_PER_SYMBOL_TRAVERSAL",
]
