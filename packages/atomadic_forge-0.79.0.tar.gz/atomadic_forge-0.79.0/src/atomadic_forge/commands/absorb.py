"""CLI surface for ``forge absorb``."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

COMMAND_NAME = "absorb"
COMMAND_HELP = (
    "Absorb any Python repo (crewAI, langgraph, autogen, babyagi, …) "
    "into a tier-organized Atomadic package."
)

app = typer.Typer(no_args_is_help=False, help=COMMAND_HELP, invoke_without_command=True)


@app.callback()
def run(
    source: Annotated[
        list[Path] | None,
        typer.Option("--source", "-s", help="Source repo path(s). Repeat for multi-repo absorb."),
    ] = None,
    out_dir: Annotated[
        Path | None,
        typer.Option("--out-dir", "-o", help="Output directory for the new package."),
    ] = None,
    package: Annotated[
        str | None,
        typer.Option("--package", "-p", help="Importable name for the new package."),
    ] = None,
    top_n: Annotated[
        int,
        typer.Option("--top-n", help="Materialize the top-N emergent candidates."),
    ] = 10,
    swarm_depth: Annotated[
        int,
        typer.Option("--swarm-depth", help="Max depth for emergent_swarm chain discovery."),
    ] = 3,
    require_pure: Annotated[
        bool,
        typer.Option("--require-pure/--no-require-pure"),
    ] = False,
    no_domain_jump: Annotated[
        bool,
        typer.Option("--no-domain-jump/--domain-jump"),
    ] = False,
    no_certify: Annotated[
        bool,
        typer.Option("--no-certify/--certify"),
    ] = False,
    json_out: Annotated[
        bool,
        typer.Option("--json", help="Emit machine-readable JSON receipt."),
    ] = False,
) -> None:
    if not source:
        typer.echo("Error: at least one --source/-s is required.", err=True)
        raise typer.Exit(code=2)
    if out_dir is None:
        typer.echo("Error: --out-dir/-o is required.", err=True)
        raise typer.Exit(code=2)

    from atomadic_forge.a3_og_features.absorb_feature import absorb_repo

    try:
        receipt = absorb_repo(
            source_repos=list(source),
            out_dir=out_dir,
            package=package,
            top_n=top_n,
            run_certify=not no_certify,
            swarm_max_depth=swarm_depth,
            require_pure=require_pure,
            domain_jump_required=not no_domain_jump,
        )
    except ValueError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(code=1) from exc

    if json_out:
        typer.echo(json.dumps(receipt, indent=2, default=str))
        return

    sm = receipt.get("scan_summary", {})
    mat = receipt.get("materialize", {})
    typer.echo(
        f"absorb: {sm.get('repo_count', '?')} repo(s) → {receipt['package']} "
        f"(candidates={sm.get('candidate_count', '?')}, "
        f"cross_repo={sm.get('cross_repo_chain_count', '?')}, "
        f"wire_violations={mat.get('wire_violations', '?')})"
    )
    typer.echo(f"  out_dir:  {receipt['out_dir']}")
    typer.echo(f"  receipt:  {receipt['out_dir']}\\.atomadic-forge\\absorb.json")
