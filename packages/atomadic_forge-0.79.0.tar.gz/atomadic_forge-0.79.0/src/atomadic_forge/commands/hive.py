"""``forge hive`` — agent registry + consensus + observation pipeline.

The 4-agent collaboration substrate. Lets any agent activate against
AGENT_COLLAB_PROTOCOL.md, declare its lane, subscribe to events, and
participate in cross-agent consensus.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a3_og_features.hive_sync import (
    consensus_recap,
    deactivate_agent,
    get_consensus_result,
    list_agents,
    needs_vote_from,
    observe,
    propose_consensus,
    register_agent,
    vote_consensus,
)

COMMAND_NAME = "hive"
COMMAND_HELP = (
    "Hive sync pipeline — agent registry + observation + consensus. "
    "The 4-agent collaboration substrate."
)

app = typer.Typer(no_args_is_help=True, help=COMMAND_HELP)


@app.command("register")
def register_cmd(
    agent_name: Annotated[str, typer.Option("--agent", "-a",
        help="Stable agent identifier (e.g. claude-sonnet-4.5-forge).")],
    role: Annotated[str, typer.Option("--role", "-r",
        help="forge | cognition | doc | research | <custom>")],
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    capabilities: Annotated[str, typer.Option("--capabilities",
        help="Comma-separated capabilities (e.g. edit_files,delegate).")] = "",
    subscribes_to: Annotated[str, typer.Option("--subscribes-to",
        help="Comma-separated event types; empty = role default.")] = "",
    write_lanes: Annotated[str, typer.Option("--write-lanes",
        help="Comma-separated paths the agent writes to.")] = "",
    identity_claim: Annotated[str, typer.Option("--identity",
        help="Opaque identity token (session id, JWT, or fingerprint).")] = "",
    notes: Annotated[str, typer.Option("--notes",
        help="Free-form context.")] = "",
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Register an agent into the hive."""
    out = register_agent(
        project_root=project_root,
        agent_name=agent_name, role=role,
        capabilities=[c.strip() for c in capabilities.split(",") if c.strip()],
        subscribes_to=[s.strip() for s in subscribes_to.split(",") if s.strip()] or None,
        write_lanes=[w.strip() for w in write_lanes.split(",") if w.strip()],
        identity_claim=(identity_claim or None),
        notes=(notes or None),
    )
    if json_out:
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    e = out["entry"]
    typer.secho(f"Registered {e['id']}  ({e['role']})", fg="green")
    typer.echo(f"  agent_name:   {e['agent_name']}")
    typer.echo(f"  role:         {e['role']}")
    typer.echo(f"  subscribes:   {', '.join(e['subscribes_to']) or '(none)'}")
    typer.echo(f"  write_lanes:  {', '.join(e['write_lanes']) or '(none)'}")
    typer.echo(f"  registry:     {out['registry_file']}")
    typer.echo(f"  hive size:    {out['active_count']} / {out['d_max_cap']}")


@app.command("list")
def list_cmd(
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    include_deactivated: Annotated[bool, typer.Option("--include-deactivated")] = False,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """List all registered agents."""
    out = list_agents(project_root=project_root,
                       include_deactivated=include_deactivated)
    if json_out:
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    typer.echo("")
    typer.echo(f"Hive registry  ({out['agent_count']} agents"
               + (", incl. deactivated" if include_deactivated else "")
               + f")  {out['registry_file']}")
    typer.echo("=" * 60)
    if not out["agents"]:
        typer.echo("  (no agents registered)")
        typer.echo("  forge hive register --agent <name> --role <role>")
        return
    for a in out["agents"]:
        active = "·" if a.get("active", True) else "✗"
        typer.echo(f"  {active} {a.get('id', '?'):<14} {a.get('role', '?'):<10} "
                   f"{a.get('agent_name', '?')}")
        if a.get("write_lanes"):
            typer.echo(f"      writes: {', '.join(a['write_lanes'])}")
        if a.get("subscribes_to"):
            typer.echo(f"      subs:   {', '.join(a['subscribes_to'])}")


@app.command("deactivate")
def deactivate_cmd(
    agent_name: Annotated[str, typer.Argument()],
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
) -> None:
    """Mark an agent inactive (auditable)."""
    out = deactivate_agent(project_root=project_root, agent_name=agent_name)
    if out.get("deactivated"):
        typer.secho(f"deactivated {agent_name}", fg="yellow")
    else:
        typer.secho(f"NOT deactivated: {out.get('reason')}", fg="red")


@app.command("observe")
def observe_cmd(
    agent_name: Annotated[str, typer.Option("--agent", "-a")] = "",
    since: Annotated[str, typer.Option("--since",
        help="Cursor consensus_id; events AFTER this are returned.")] = "",
    since_wisdom: Annotated[str, typer.Option("--since-wisdom",
        help="Cursor wisdom id (WIS-*); wisdom events AFTER this are returned.")] = "",
    limit: Annotated[int, typer.Option("--limit")] = 50,
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Pull pending hive events for an agent (consensus + wisdom).

    v0.13.4: multi-source. Surfaces consensus events (proposal /
    vote / resolution) AND wisdom events (new / superseded) filtered
    by the agent's subscribes_to set. Two cursors track each
    stream independently.
    """
    out = observe(
        project_root=project_root,
        agent_name=(agent_name or None),
        since_consensus_id=(since or None),
        since_wisdom_id=(since_wisdom or None),
        limit=limit,
    )
    if json_out:
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    typer.echo(f"\nHive observe  agent={out.get('agent_name') or '(any)'}  "
               f"events={out['event_count']}")
    typer.echo("-" * 60)
    for ev in out["events"]:
        source = ev.get("_source", "?")
        ts = (ev.get("timestamp_utc") or "?")[:19]
        if source == "consensus":
            kind = ev.get("kind", "?")
            cid = ev.get("consensus_id", "?")
            if kind == "proposal":
                typer.echo(f"  [{ts}] PROPOSAL  {cid}  {ev.get('proposer')}: "
                           f"{ev.get('intent', '')[:60]}")
            elif kind == "vote":
                typer.echo(f"  [{ts}] VOTE      {cid}  {ev.get('voter')} → "
                           f"{ev.get('vote')}")
            elif kind == "resolution":
                typer.echo(f"  [{ts}] RESOLVED  {cid}  → "
                           f"{ev.get('payload', {}).get('verdict')}")
        elif source == "wisdom":
            wid = ev.get("id", "?")
            scope = ev.get("scope", "?")
            insight = (ev.get("insight") or "")[:70]
            mark = "↺" if ev.get("supersedes") else "✦"
            typer.echo(f"  [{ts}] {mark} WISDOM   {wid}  ({scope}) "
                       f"{ev.get('agent_name', '?')}: {insight}")
    if not out["events"]:
        typer.echo("  (no events match subscriptions / cursors)")


@app.command("watch")
def watch_cmd(
    agent_name: Annotated[str, typer.Option("--agent", "-a")] = "",
    interval_secs: Annotated[int, typer.Option("--interval",
        help="Seconds between polls.")] = 5,
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    once: Annotated[bool, typer.Option("--once",
        help="Print one batch and exit (for tests / one-off pulls).")] = False,
) -> None:
    """Live-tail hive activity (consensus + wisdom) — runs until Ctrl-C.

    The synchronized-message demo Thomas asked for. Pulls events
    matching the agent's subscriptions every ``interval_secs``,
    prints anything new since the last cursor. Stable cursors keep
    the stream tight — no duplicates after the first poll.
    """
    import time

    last_cns: str | None = None
    last_wis: str | None = None
    typer.secho(f"forge hive watch — agent={agent_name or '(any)'}  "
                 f"interval={interval_secs}s  (Ctrl-C to stop)",
                 fg="cyan")
    typer.echo("=" * 60)
    while True:
        out = observe(
            project_root=project_root,
            agent_name=(agent_name or None),
            since_consensus_id=last_cns,
            since_wisdom_id=last_wis,
            limit=200,
        )
        events = out.get("events", [])
        for ev in events:
            ts = (ev.get("timestamp_utc") or "?")[:19]
            source = ev.get("_source", "?")
            if source == "consensus":
                kind = ev.get("kind")
                cid = ev.get("consensus_id", "?")
                if kind == "proposal":
                    typer.secho(f"  [{ts}] PROPOSAL  {cid}  "
                                 f"{ev.get('proposer')}: "
                                 f"{(ev.get('intent') or '')[:55]}",
                                 fg="cyan")
                elif kind == "vote":
                    color = ("green" if ev.get('vote') == "approve"
                             else "yellow" if ev.get('vote') == "refine"
                             else "red")
                    typer.secho(f"  [{ts}] VOTE      {cid}  "
                                 f"{ev.get('voter')} → {ev.get('vote')}",
                                 fg=color)
                elif kind == "resolution":
                    typer.secho(f"  [{ts}] RESOLVED  {cid}  → "
                                 f"{ev.get('payload', {}).get('verdict')}",
                                 fg="bright_green", bold=True)
                last_cns = ev.get("consensus_id") or last_cns
            elif source == "wisdom":
                wid = ev.get("id", "?")
                scope = ev.get("scope", "?")
                insight = (ev.get("insight") or "")[:60]
                mark = "↺" if ev.get("supersedes") else "✦"
                typer.secho(f"  [{ts}] {mark} WISDOM   {wid}  ({scope}) "
                             f"{ev.get('agent_name', '?')}: {insight}",
                             fg="bright_yellow")
                last_wis = wid
        if once:
            return
        try:
            time.sleep(interval_secs)
        except KeyboardInterrupt:
            typer.echo("\nstopped.")
            return


@app.command("needs-vote")
def needs_vote_cmd(
    agent_name: Annotated[str, typer.Option("--agent", "-a",
        help="Agent identifier whose pending votes to surface.")],
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Surface open consensuses where this agent hasn't voted yet.

    The 'what should I weigh in on' primitive — closes the gap
    between observe (everything happening) and the act of voting.
    """
    out = needs_vote_from(
        project_root=project_root,
        agent_name=agent_name,
    )
    if json_out:
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    typer.echo("")
    typer.echo(f"Pending votes for {agent_name}  ({out['pending_count']})")
    typer.echo("=" * 60)
    if not out["pending"]:
        typer.secho("  (caught up — no consensuses awaiting your vote)",
                     fg="green")
        return
    for p in out["pending"]:
        typer.echo(f"  {p['consensus_id']}  proposer={p['proposer']}  "
                   f"votes={p['votes_so_far']}")
        typer.echo(f"    intent: {(p.get('intent') or '')[:80]}")
        if p["voters_so_far"]:
            typer.echo(f"    voters: {', '.join(p['voters_so_far'])}")
        typer.echo("")
    typer.echo(f"Vote with:  forge hive vote --id <CNS-*> --voter "
                f"{agent_name} --vote approve|reject|refine|abstain")


@app.command("recap")
def recap_cmd(
    consensus_id: Annotated[str, typer.Argument(help="CNS-* id to recap.")],
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Full lifecycle of one consensus — proposal + every vote +
    resolution + summary (verdict, duration, voters)."""
    out = consensus_recap(project_root=project_root, consensus_id=consensus_id)
    if json_out:
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    if not out.get("found"):
        typer.secho(out.get("reason", "not found"), fg="red")
        return
    typer.echo("")
    typer.echo(f"Consensus recap  {consensus_id}")
    typer.echo("=" * 60)
    typer.echo(f"  proposer:     {out.get('proposer')}")
    typer.echo(f"  proposed_at:  {out.get('proposed_at')}")
    typer.echo(f"  intent:       {(out.get('intent') or '')[:80]}")
    if out.get("resolved"):
        typer.echo(f"  resolved_at:  {out.get('resolved_at')}")
        typer.secho(f"  verdict:      {out.get('verdict')}",
                     fg="bright_green", bold=True)
        if out.get("duration_secs") is not None:
            typer.echo(f"  duration:     {int(out['duration_secs'])}s")
    else:
        typer.secho("  verdict:      PENDING", fg="yellow")
    typer.echo(f"  votes:        {out.get('vote_count')}  → {out.get('tally')}")
    if out.get("voters"):
        typer.echo(f"  voters:       {', '.join(out['voters'])}")
    typer.echo("")
    typer.echo("Timeline:")
    for ev in out.get("events", []):
        ts = (ev.get("timestamp_utc") or "?")[:19]
        kind = ev.get("kind", "?")
        if kind == "proposal":
            typer.secho(f"  [{ts}] PROPOSAL  {ev.get('proposer')}",
                         fg="cyan")
        elif kind == "vote":
            color = ("green" if ev.get('vote') == "approve"
                     else "yellow" if ev.get('vote') == "refine"
                     else "red" if ev.get('vote') == "reject" else "white")
            typer.secho(f"  [{ts}] VOTE      {ev.get('voter')} → {ev.get('vote')}",
                         fg=color)
            if ev.get("rationale"):
                typer.echo(f"           rationale: {ev['rationale'][:80]}")
        elif kind == "resolution":
            typer.secho(f"  [{ts}] RESOLVED  → {ev.get('payload', {}).get('verdict')}",
                         fg="bright_green", bold=True)


@app.command("propose")
def propose_cmd(
    intent: Annotated[str, typer.Option("--intent", "-i")],
    proposer: Annotated[str, typer.Option("--proposer", "-p")],
    project_root: Annotated[Path, typer.Option("--project-root",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    payload_json: Annotated[str, typer.Option("--payload",
        help="JSON-encoded payload dict.")] = "",
) -> None:
    """Open a consensus proposal."""
    payload = json.loads(payload_json) if payload_json else None
    out = propose_consensus(
        project_root=project_root,
        intent=intent, proposer=proposer, payload=payload,
    )
    typer.secho(f"PROPOSED  {out['consensus_id']}", fg="cyan")
    typer.echo(f"  intent:   {intent}")
    typer.echo(f"  proposer: {proposer}")
    typer.echo(f"\nVote with:  forge hive vote --id {out['consensus_id']} "
               f"--voter <name> --vote approve|reject|refine|abstain")


@app.command("vote")
def vote_cmd(
    consensus_id: Annotated[str, typer.Option("--id")],
    voter: Annotated[str, typer.Option("--voter", "-v")],
    vote: Annotated[str, typer.Option("--vote",
        help="approve | reject | refine | abstain")],
    rationale: Annotated[str, typer.Option("--rationale", "-r")] = "",
    project_root: Annotated[Path, typer.Option("--project-root",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
) -> None:
    """Cast a vote on a consensus."""
    vote_consensus(
        project_root=project_root,
        consensus_id=consensus_id, voter=voter,
        vote=vote, rationale=(rationale or None),
    )
    typer.secho(f"voted {vote}  ({voter})", fg="green")
    typer.echo(f"  consensus: {consensus_id}")


@app.command("result")
def result_cmd(
    consensus_id: Annotated[str, typer.Option("--id")],
    record: Annotated[bool, typer.Option("--record",
        help="Append a resolution event when verdict is final.")] = False,
    nexus: Annotated[bool, typer.Option("--nexus",
        help="When --record fires, also mirror to AAAA-Nexus lineage_record.")] = False,
    project_root: Annotated[Path, typer.Option("--project-root",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Compute (and optionally record + mirror) a consensus verdict."""
    out = get_consensus_result(
        project_root=project_root,
        consensus_id=consensus_id,
        record_resolution=record,
        nexus_mirror=nexus,
    )
    if json_out:
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    if not out.get("found"):
        typer.secho(out.get("reason", "not found"), fg="red")
        return
    typer.echo(f"\nConsensus  {consensus_id}")
    typer.echo("-" * 60)
    typer.echo(f"  verdict:    {out.get('verdict')}")
    typer.echo(f"  resolved:   {out.get('resolved')}")
    typer.echo(f"  intent:     {out.get('intent')}")
    typer.echo(f"  proposer:   {out.get('proposer')}")
    typer.echo(f"  agents:     {out.get('active_agent_count')}")
    tally = out.get("tally", {})
    typer.echo(f"  tally:      {tally.get('counts')}")
    typer.echo(f"  needed:     {out.get('needed', '?')}")
    if out.get("remaining_secs") is not None:
        typer.echo(f"  remaining:  {out['remaining_secs']}s")
