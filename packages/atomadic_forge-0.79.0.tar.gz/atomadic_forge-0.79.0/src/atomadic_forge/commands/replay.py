"""Tier a4 — `forge replay` CLI surface.

Run a golden recipe's validation_gate deterministically — no LLM in
the loop. Each command an LLM would otherwise plan + dispatch costs
real round-trip tokens; replaying skips that overhead entirely.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a1_at_functions.recipes import list_recipes
from atomadic_forge.a3_og_features.recipe_replay import replay_recipe

COMMAND_NAME = "replay"
COMMAND_HELP = (
    "Replay a golden recipe's validation_gate deterministically — zero "
    "LLM round-trips. Use `--list` to see available recipes."
)

app = typer.Typer(no_args_is_help=False, help=COMMAND_HELP)


@app.callback(invoke_without_command=True)
def run(
    recipe: Annotated[str, typer.Argument(
        help="Recipe name (use --list to see all).")] = "",
    project: Annotated[Path, typer.Option(
        "--project", "-p",
        help="Project root used as cwd for each step.",
        exists=True, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    list_all: Annotated[bool, typer.Option(
        "--list", help="List available recipes and exit.")] = False,
    dry_run: Annotated[bool, typer.Option(
        "--dry-run", help="Print the plan without running.")] = False,
    keep_going: Annotated[bool, typer.Option(
        "--keep-going",
        help="Run every step even if one fails (default: stop on first fail).",
    )] = False,
    json_out: Annotated[bool, typer.Option(
        "--json", help="Emit machine-readable JSON.")] = False,
) -> None:
    """Replay a recipe's validation_gate."""
    if list_all:
        names = list_recipes()
        if json_out:
            typer.echo(json.dumps({"recipes": names}, indent=2))
            return
        typer.echo("Available recipes:")
        for n in names:
            typer.echo(f"  • {n}")
        return

    if not recipe:
        typer.secho("forge replay: pass a recipe name or --list", fg="red", err=True)
        raise typer.Exit(2)

    try:
        report = replay_recipe(
            recipe_name=recipe,
            project_root=project,
            stop_on_fail=not keep_going,
            dry_run=dry_run,
        )
    except KeyError as exc:
        typer.secho(f"forge replay: {exc}", fg="red", err=True)
        raise typer.Exit(2) from exc

    if json_out:
        typer.echo(json.dumps(report.to_dict(), indent=2, default=str))
        if report.verdict in ("FAIL", "PARTIAL"):
            raise typer.Exit(1)
        return

    typer.echo("")
    typer.echo(f"Replay — {recipe}")
    typer.echo("-" * 60)
    for i, step in enumerate(report.steps, 1):
        if step.skipped:
            mark = typer.style("SKIP", fg="yellow")
        elif step.exit_code == 0:
            mark = typer.style("PASS", fg="green")
        else:
            mark = typer.style("FAIL", fg="red")
        typer.echo(f"  [{i}] {mark}  {step.command}")
        if step.exit_code not in (0, -1) and step.stderr_tail:
            for line in step.stderr_tail.splitlines()[:3]:
                typer.echo(f"        {line}")
    typer.echo("-" * 60)
    typer.echo(f"  verdict:        {report.verdict}")
    typer.echo(f"  pass / fail:    {report.pass_count} / {report.fail_count}"
               + (f"  ({report.skipped_count} skipped)"
                   if report.skipped_count else ""))
    typer.echo(f"  duration:       {report.duration_ms} ms")
    typer.echo(f"  tokens saved:   ~{report.tokens_saved_estimate:,}")
    if report.verdict in ("FAIL", "PARTIAL"):
        raise typer.Exit(1)
