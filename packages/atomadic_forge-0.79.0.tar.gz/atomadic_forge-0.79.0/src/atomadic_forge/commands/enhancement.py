"""``forge enhancement`` — submit / list / show / publish enhancement proposals.

When Forge (or an agent driving Forge) finds a pattern strong enough
to become a new tool, it can record it here. Trust-gating happens at
submission time; publishing to GitHub is a separate, human-gated step.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a0_qk_constants.enhancement_proposal_constants import (
    DEFAULT_TRUST_THRESHOLD,
)
from atomadic_forge.a3_og_features.enhancement_proposal_feature import (
    list_proposals,
    read_proposal,
    submit_proposal,
)

COMMAND_NAME = "enhancement"
COMMAND_HELP = (
    "Submit / list / show / publish Forge enhancement proposals — the "
    "self-improvement loop. Trust-gated at submission, human-gated at "
    "publish."
)

app = typer.Typer(no_args_is_help=True, help=COMMAND_HELP)


def _split_lines(raw: str) -> list[str]:
    if not raw:
        return []
    out: list[str] = []
    for line in raw.split("\n"):
        for tok in line.split(";"):
            tok = tok.strip()
            if tok:
                out.append(tok)
    return out


@app.command("propose")
def propose_cmd(
    title: Annotated[str, typer.Option("--title", "-t",
        help="Short title for the proposal.")],
    description: Annotated[str, typer.Option("--description", "-d",
        help="What the enhancement does and why.")],
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        help="Repo to log the proposal under.",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    evidence: Annotated[str, typer.Option("--evidence", "-e",
        help="Evidence references; `;`/newline separated.")] = "",
    proposer: Annotated[str, typer.Option("--proposer",
        help="Identifier of the proposing agent.")] = "anonymous",
    trust_threshold: Annotated[float, typer.Option("--trust-threshold",
        help="Trust score floor for `publishable`.",
        min=0.0, max=1.0)] = DEFAULT_TRUST_THRESHOLD,
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
) -> None:
    """Submit a new enhancement proposal.

    Trust-gating is OFFLINE by default — wire a real
    AAAA-Nexus client through the MCP surface or programmatic
    ``submit_proposal(trust_gate=...)`` for live verification.
    Publishing always requires `forge enhancement publish <id>`.
    """
    out = submit_proposal(
        project_root=project_root,
        title=title,
        description=description,
        evidence=_split_lines(evidence),
        proposer=proposer,
        trust_threshold=trust_threshold,
    )
    if json_out:
        typer.echo(json.dumps(out, indent=2))
        return
    p = out["proposal"]
    typer.echo(f"proposal_id:   {p['proposal_id']}")
    typer.echo(f"title:         {p['title']}")
    typer.echo(f"timestamp:     {p['timestamp']}")
    typer.echo(f"trust_verdict: {p['trust_verdict']}  "
                f"(score={p['trust_score']}, "
                f"threshold={p['trust_threshold']})")
    typer.echo(f"publishable:   {p['publishable']}")
    typer.echo(f"approved:      {p['approved']}")
    typer.echo(f"saved to:      {out['proposal_file']}")
    typer.echo(f"appended to:   {out['log_file']}")


@app.command("list")
def list_cmd(
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        help="Repo to read from.",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    limit: Annotated[int, typer.Option("--limit", "-n",
        help="Cap returned entries.")] = 50,
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
) -> None:
    """List proposals for this repo, newest first."""
    out = list_proposals(project_root=project_root, limit=limit)
    if json_out:
        typer.echo(json.dumps(out, indent=2))
        return
    typer.echo(f"log_file:    {out['log_file']}")
    typer.echo(f"total:       {out['total_count']}")
    if out["skipped_lines"]:
        typer.echo(f"skipped:     {len(out['skipped_lines'])} lines (malformed)")
    if not out["entries"]:
        typer.echo("(no proposals yet — run `forge enhancement propose`)")
        return
    typer.echo("")
    for e in out["entries"]:
        typer.echo(
            f"  {e.get('proposal_id','?')}  "
            f"{e.get('timestamp','?')}  "
            f"trust={e.get('trust_verdict','?')}/{e.get('trust_score','-')}  "
            f"publishable={e.get('publishable',False)}  "
            f"approved={e.get('approved',False)}  "
            f"{e.get('title','?')[:60]}"
        )


@app.command("show")
def show_cmd(
    proposal_id: Annotated[str, typer.Argument(help="FEP-* id to read.")],
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
) -> None:
    """Print one proposal as JSON."""
    entry = read_proposal(project_root=project_root, proposal_id=proposal_id)
    if entry is None:
        typer.secho(f"no proposal found: {proposal_id!r}", fg="yellow", err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(entry, indent=2))


@app.command("publish")
def publish_cmd(
    proposal_id: Annotated[str, typer.Argument(help="FEP-* id to publish.")],
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    yes: Annotated[bool, typer.Option("--yes",
        help="Skip the interactive confirmation prompt.")] = False,
) -> None:
    """Render the GitHub Issue body for a proposal.

    This command DOES NOT post anywhere on its own. It prints the
    Issue title + body to stdout (and an explicit `gh issue create`
    invocation sketch) so a human can review and execute the publish
    themselves. Per safety policy, public-content actions require
    explicit human confirmation per action — `--yes` only acknowledges
    that you have reviewed the rendered body.
    """
    entry = read_proposal(project_root=project_root, proposal_id=proposal_id)
    if entry is None:
        typer.secho(f"no proposal found: {proposal_id!r}", fg="yellow", err=True)
        raise typer.Exit(1)
    if not entry.get("publishable"):
        typer.secho(
            f"proposal not publishable (trust_verdict="
            f"{entry.get('trust_verdict')}, "
            f"score={entry.get('trust_score')}, "
            f"threshold={entry.get('trust_threshold')})",
            fg="yellow", err=True,
        )
        raise typer.Exit(2)
    title = f"[Forge enhancement] {entry['title']}"
    body_lines = [
        entry["description"],
        "",
        "---",
        "",
        f"**Proposal id:** `{entry['proposal_id']}`",
        f"**Proposer:** `{entry['proposer']}`",
        f"**Trust verdict:** `{entry['trust_verdict']}` "
        f"(score `{entry['trust_score']}`, "
        f"threshold `{entry['trust_threshold']}`)",
    ]
    if entry.get("evidence"):
        body_lines.append("")
        body_lines.append("**Evidence:**")
        for e in entry["evidence"]:
            body_lines.append(f"- {e}")
    body = "\n".join(body_lines)

    typer.echo(f"--- proposed Issue title ---\n{title}\n")
    typer.echo(f"--- proposed Issue body ---\n{body}\n")
    typer.echo("--- to actually publish, run: ---")
    typer.echo(
        "  gh issue create --title \"" + title.replace("\"", "\\\"") + "\" \\\n"
        "                  --body-file -  <<'EOF'\n"
        + body
        + "\nEOF"
    )
    if not yes:
        typer.echo(
            "\n(Re-run with --yes after reviewing the body to acknowledge.)",
        )
