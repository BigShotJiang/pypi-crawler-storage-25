"""``atomadic-forge create`` — one-command pipeline: intent + seeds -> package.

Phase 1 of the create pipeline. Scans local seed repos with
``emergent_swarm``, persists the scan report, then materializes the
top-N candidates into a fresh, certify-able Python package.

Examples
--------
    # Single seed:
    forge create "ICP scoring tool" \\
        --seed-repo C:/!!AtomadicStandard/atomadic-forge \\
        --out-dir   ./out/icp \\
        --package   icp_tool

    # Multiple seeds (cross-repo emergent compositions):
    forge create "logging-aware retry layer" \\
        -s C:/!!AtomadicStandard/atomadic-forge \\
        -s C:/!!AtomadicStandard/atomadic/cognition/atomadic_cognition \\
        --out-dir ./out/retry \\
        --package retry_layer

The intent string is recorded in the receipt and the generated README;
Phase 1 does not yet use it to filter candidates (that arrives in
Phase 3 with the trust-gated cross-framework merger).
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a3_og_features.create_feature import create_from_intent

COMMAND_NAME = "create"
COMMAND_HELP = (
    "One-command pipeline: scan local seed repos for emergent "
    "compositions and materialize the top-N into a shippable package."
)

app = typer.Typer(
    no_args_is_help=False, help=COMMAND_HELP, invoke_without_command=True,
)


@app.callback()
def run(
    intent: Annotated[str | None, typer.Option("--intent", "-i",
        help="Plain-English description of the package to assemble.")] = None,
    seed_repo: Annotated[list[str] | None, typer.Option(
        "--seed-repo", "-s",
        help="Local repo path or remote clone URL to scan (repeatable, max 23). "
             "Auto-detects either a 'src/<pkg>/' layout or a tier-bearing "
             "package dir after hydration.")] = None,
    out_dir: Annotated[Path | None, typer.Option("--out-dir",
        help="Where to write the new package. Must be empty or a "
             "previously-materialized directory.",
        file_okay=False, dir_okay=True, resolve_path=True)] = None,
    package: Annotated[str | None, typer.Option("--package",
        help="Importable name of the new package.")] = None,
    top_n: Annotated[int, typer.Option("--top-n",
        help="Materialize the top-N candidates from the scan.")] = 5,
    swarm_depth: Annotated[int, typer.Option("--swarm-depth",
        help="Max chain length for emergent_swarm.")] = 3,
    require_pure: Annotated[bool, typer.Option("--require-pure",
        help="Restrict to chains where every step is heuristically pure.")] = False,
    no_domain_jump: Annotated[bool, typer.Option("--no-domain-jump",
        help="Allow same-domain chains.")] = False,
    no_certify: Annotated[bool, typer.Option("--no-certify",
        help="Skip the certify pass on the new package.")] = False,
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
) -> None:
    """Run the full intent -> package pipeline."""
    if intent is None or not seed_repo or out_dir is None or package is None:
        typer.secho(
            "create: intent + at least one --seed-repo + --out-dir + --package are required",
            fg="red", err=True,
        )
        typer.echo("Try: atomadic-forge create --help")
        raise typer.Exit(2)

    try:
        receipt = create_from_intent(
            intent,
            seed_repos=list(seed_repo),
            out_dir=out_dir,
            package=package,
            top_n=top_n,
            run_certify=not no_certify,
            swarm_max_depth=swarm_depth,
            require_pure=require_pure,
            domain_jump_required=not no_domain_jump,
        )
    except ValueError as exc:
        typer.secho(f"create: {exc}", fg="red", err=True)
        raise typer.Exit(1) from exc

    if json_out:
        typer.echo(json.dumps(receipt, indent=2, default=str))
        return

    materialize = receipt["materialize"]
    scan = receipt["scan_summary"]

    typer.echo("")
    typer.echo(f"Create -> {receipt['out_dir']}")
    typer.echo("-" * 60)
    typer.echo(f"  intent:             {receipt['intent']!r}")
    typer.echo(f"  seed repos:         {len(receipt['seed_repos'])}")
    for s in receipt["seed_repos"]:
        typer.echo(f"    - {s['package']}  ({s['src_root']})")
    typer.echo("")
    typer.echo("Scan:")
    typer.echo(f"  union catalog:      {scan['union_catalog_size']}")
    typer.echo(f"  candidates:         {scan['candidate_count']}")
    typer.echo(f"  cross-repo chains:  {scan['cross_repo_chain_count']}")
    typer.echo(f"  novel compositions: {scan['novel_composition_count']}")
    typer.echo("")
    typer.echo("Materialize:")
    typer.echo(f"  package:            {materialize['package']}")
    typer.echo(f"  candidates picked:  {len(materialize['candidates_selected'])}")
    typer.echo(f"  files written:      {len(materialize['files_written'])}")
    if materialize["wire_violations"] is not None:
        typer.echo(f"  wire violations:    {materialize['wire_violations']}")
    if materialize["certify_score"] is not None:
        typer.echo(
            f"  certify:            {materialize['certify_score']:.0f}  "
            f"({materialize['certify_grade']})",
        )
    typer.echo("")
    typer.echo(f"  {materialize['summary_line']}")
    typer.echo("")
    typer.echo("Next:")
    typer.echo(f"  cd {receipt['out_dir']}")
    typer.echo("  pip install -e .")
    typer.echo("  pytest tests/")
    typer.echo("")
    typer.echo(f"  scan report: {receipt['scan_report_path']}")
    typer.echo(f"  receipt:     {Path(receipt['out_dir']) / '.atomadic-forge' / 'create.json'}")
    typer.echo("")
