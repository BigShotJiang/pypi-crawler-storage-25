"""``forge relay`` — local relay daemon for the no-stubs goal.

The Worker MCP can't run filesystem-required tools. The relay
daemon receives signed job requests on a local HTTP port and
dispatches them through the local CLI. Pair with the Cloudflare
Worker enqueue path (atomadic-forge-cloudflare-workers, separate
repo, gated by Thomas sign-off) to close the no-stubs gap end-to-end.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a3_og_features.relay_daemon import (
    handle_job,
    relay_log_path,
    serve_http,
)

COMMAND_NAME = "relay"
COMMAND_HELP = (
    "Local relay daemon — receive signed job requests from the "
    "Worker MCP and dispatch them through the local CLI. v0.14.0-alpha."
)

app = typer.Typer(no_args_is_help=True, help=COMMAND_HELP)


@app.command("serve")
def serve_cmd(
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    host: Annotated[str, typer.Option("--host")] = "127.0.0.1",
    port: Annotated[int, typer.Option("--port")] = 7409,
) -> None:
    """Run the relay HTTP server (blocks until Ctrl-C)."""
    serve_http(project_root=project_root, host=host, port=port)


@app.command("dispatch")
def dispatch_cmd(
    job_json: Annotated[str, typer.Argument(
        help="JSON-encoded job envelope (jsonrpc / id / method / params).")],
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Dispatch one job synchronously (no HTTP server). Useful for testing.

    Equivalent to POST /relay/jobs with the same body, but skips the
    server stack — direct call into handle_job.
    """
    try:
        job = json.loads(job_json)
    except json.JSONDecodeError as exc:
        typer.secho(f"bad json: {exc}", fg="red", err=True)
        raise typer.Exit(1) from exc
    record = handle_job(project_root=project_root, job=job)
    if json_out:
        typer.echo(json.dumps(record, indent=2, default=str))
        return
    typer.echo(f"\nRelay dispatch  ok={record['ok']}  "
               f"tool={record.get('tool_name')}  "
               f"duration={record['duration_ms']}ms")
    typer.echo("-" * 60)
    if record.get("error"):
        typer.secho(f"  error: {record['error']}", fg="red")
    else:
        resp = record.get("response") or {}
        if "result" in resp:
            typer.echo(f"  result keys: {list(resp['result'].keys())}")
        elif "error" in resp:
            typer.secho(f"  rpc error: {resp['error']}", fg="yellow")


@app.command("log")
def log_cmd(
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    tail: Annotated[int, typer.Option("--tail", "-n",
        help="Show only the last N records.")] = 25,
) -> None:
    """Show the relay job log (.atomadic-forge/relay/jobs.jsonl)."""
    path = relay_log_path(project_root)
    if not path.exists():
        typer.echo(f"no relay log yet at {path}")
        return
    with path.open("r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]
    typer.echo(f"\nRelay log  ({len(lines)} records)  {path}")
    typer.echo("-" * 60)
    for ln in lines[-tail:]:
        try:
            r = json.loads(ln)
            ok = "✓" if r.get("ok") else "✗"
            ts = (r.get("started_at_utc") or "?")[:19]
            typer.echo(f"  {ok} [{ts}] {r.get('tool_name', '?'):<24} "
                       f"{r.get('duration_ms', 0)}ms"
                       + (f"  err: {r['error']}" if r.get("error") else ""))
        except json.JSONDecodeError:
            continue
