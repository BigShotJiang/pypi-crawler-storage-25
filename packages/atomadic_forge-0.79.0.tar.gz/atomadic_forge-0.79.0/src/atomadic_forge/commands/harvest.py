"""Tier a4 — ``forge harvest`` CLI surface.

Round-4 cross-repo cherry-hunter: find capabilities the target lacks
but sources have. Wraps the a3 ``harvest`` function.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a3_og_features.cherry_hunter import harvest

COMMAND_NAME = "harvest"
COMMAND_HELP = (
    "Round-4: find symbols the target lacks but source repos have. "
    "Trust-gated by trust threshold."
)

app = typer.Typer(no_args_is_help=True, help=COMMAND_HELP)


@app.callback(invoke_without_command=True)
def run(
    target: Annotated[Path, typer.Option("--target", "-t",
        help="Target repo to harvest INTO.",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)],
    source: Annotated[list[Path], typer.Option("--source", "-s",
        help="Source repo to harvest FROM. Pass once per source (≤23).",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = None,  # type: ignore[assignment]
    only_gated: Annotated[bool, typer.Option("--only-gated",
        help="Show only candidates passing trust threshold.")] = False,
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
    save: Annotated[Path | None, typer.Option("--save",
        help="Persist the report at this path.",
        file_okay=True, dir_okay=False, resolve_path=True)] = None,
) -> None:
    """Find capabilities the target lacks but source repos have."""
    if not source:
        typer.secho("harvest: at least one --source is required",
                     fg="red", err=True)
        raise typer.Exit(2)

    try:
        report = harvest(target=target, sources=list(source))
    except ValueError as exc:
        typer.secho(str(exc), fg="red", err=True)
        raise typer.Exit(1) from exc

    # Fail-loud: print per-source warnings to stderr so a silent zero-
    # candidate run can never look like a successful empty harvest.
    # Closes GAP-014.
    warnings = report.get("source_warnings", [])
    for w in warnings:
        typer.secho(f"warning: {w}", fg="yellow", err=True)
    # If every source was bad, exit non-zero so CI / scripts notice.
    per_source = report.get("per_source", [])
    if per_source and all(
        (not entry.get("exists")) or entry.get("symbol_count", 0) == 0
        for entry in per_source
    ):
        typer.secho(
            "harvest: every source was missing or yielded 0 symbols — "
            "nothing to harvest. Pass absolute paths to absorbed packages "
            "(forge-lab/absorbed/<pkg>) or other tier-organized repos.",
            fg="red", err=True,
        )
        if json_out:
            typer.echo(json.dumps(report, indent=2, default=str))
        raise typer.Exit(3)

    if save:
        save.write_text(json.dumps(report, indent=2, default=str),
                        encoding="utf-8")

    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return

    typer.echo("")
    typer.echo("Harvest — cross-repo capability gap finder")
    typer.echo("-" * 60)
    typer.echo(f"  target:               {report.get('target', '?')}")
    typer.echo(f"  trust threshold threshold:    {report.get('tau_trust_threshold', '?')}")
    typer.echo(f"  trust-gated:          {report.get('trust_gated_count', 0)}")
    typer.echo(f"  review-required:      {report.get('review_required_count', 0)}")
    if "error" in report:
        typer.secho(f"  error: {report['error']}", fg="yellow")
        return
    typer.echo("")

    candidates = report.get("candidates", [])
    if only_gated:
        candidates = [c for c in candidates if c.get("trust_gated")]

    for i, c in enumerate(candidates[:25], 1):
        gate = "✓" if c.get("trust_gated") else "·"
        typer.echo(f"  {gate} #{i:2d}  conf={c.get('confidence', 0):.2f}  "
                   f"{c.get('qualname', '?')}")
        typer.echo(f"        from:    {c.get('source_repo', '?')}")
        typer.echo(f"        tier:    {c.get('target_tier', '?')}")
        if c.get("rationale"):
            typer.echo(f"        why:     {c['rationale']}")
        typer.echo("")
    if len(candidates) > 25:
        typer.echo(f"  … {len(candidates) - 25} more  (use --json for full list)\n")
