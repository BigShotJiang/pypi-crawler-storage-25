"""Tier a4 — ``forge emergent_swarm`` CLI surface.

Round-5 cross-repo emergent composition discovery. Wraps the a3
``emergent_swarm`` function with a Typer CLI so the same capability
the MCP exposes is also reachable from the shell.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a3_og_features.emergent_swarm import emergent_swarm

COMMAND_NAME = "emergent_swarm"
COMMAND_HELP = (
    "Round-5: cross-repo emergent composition discovery. "
    "Find chains visible only across the union of N repos."
)

app = typer.Typer(no_args_is_help=True, help=COMMAND_HELP)


def _split_repo_arg(spec: str) -> tuple[Path, str]:
    """Parse a ``--repo`` value into ``(src_root, package_name)``.

    Accepted forms:

    * ``path``                  — package name = leaf dir of path
    * ``path:package``          — explicit package name
    * ``path::package``         — alt separator (Windows-friendly)
    """
    if "::" in spec:
        path_part, package = spec.split("::", 1)
    elif ":" in spec and not (len(spec) > 1 and spec[1] == ":"):
        path_part, package = spec.split(":", 1)
    else:
        path_part = spec
        package = Path(spec).name
    return Path(path_part), package


@app.callback(invoke_without_command=True)
def run(
    repo: Annotated[list[str], typer.Option("--repo", "-r",
        help="Repo to include — ``path`` (package = leaf dir) or "
             "``path::package``. Pass once per repo (≤23).")] = None,  # type: ignore[assignment]
    top_n: Annotated[int, typer.Option("--top-n",
        help="Maximum candidates returned.")] = 25,
    max_depth: Annotated[int, typer.Option("--max-depth",
        help="Maximum chain length.")] = 3,
    cross_repo_bonus: Annotated[float, typer.Option("--cross-repo-bonus",
        help="Score boost per extra origin_repo a chain spans.")] = 15.0,
    require_pure: Annotated[bool, typer.Option("--require-pure",
        help="Restrict to chains where every step is heuristically pure.")] = False,
    no_domain_jump: Annotated[bool, typer.Option("--no-domain-jump",
        help="Allow same-domain chains (default: require ≥2 domains).")] = False,
    no_corroborate: Annotated[bool, typer.Option("--no-corroborate",
        help="Skip the static-call-graph corroboration pre-pass.")] = False,
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
    save: Annotated[Path | None, typer.Option("--save",
        help="Persist the report at this path.",
        file_okay=True, dir_okay=False, resolve_path=True)] = None,
) -> None:
    """Run emergent composition discovery over the union of N repos.

    Surfaces compositions only visible across two or more repos —
    the ``crosses_repos`` signal — which per-repo scans miss by
    construction.
    """
    if not repo:
        typer.secho(
            "emergent_swarm: at least one --repo is required",
            fg="red", err=True,
        )
        raise typer.Exit(2)

    parsed = [_split_repo_arg(r) for r in repo]

    try:
        report = emergent_swarm(
            repos=parsed,
            top_n=top_n,
            max_depth=max_depth,
            cross_repo_bonus=cross_repo_bonus,
            require_pure=require_pure,
            domain_jump_required=not no_domain_jump,
            corroborate_with_call_graph=not no_corroborate,
        )
    except ValueError as exc:
        typer.secho(str(exc), fg="red", err=True)
        raise typer.Exit(1) from exc

    if save:
        save.write_text(json.dumps(report, indent=2, default=str),
                        encoding="utf-8")

    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return

    typer.echo("")
    typer.echo("Emergent swarm — cross-repo composition discovery")
    typer.echo("-" * 60)
    typer.echo(f"  repos:                   {report['repo_count']}")
    typer.echo(f"  union catalog size:      {report['union_catalog_size']}")
    typer.echo(f"  chains considered:       {report['chain_count_considered']}")
    typer.echo(f"  candidates:              {report['candidate_count']}")
    typer.echo(f"  cross-repo chains:       {report['cross_repo_chain_count']}")
    typer.echo(f"  novel compositions:      {report['novel_composition_count']}")
    typer.echo(f"  static-confirmed edges:  {report['static_confirmed_count']}")
    typer.echo(f"  D_max cap:               {report['d_max_cap']}")
    typer.echo("")

    typer.echo("Per-repo summary:")
    for r in report["per_repo"]:
        status = "ok" if r.get("exists") else "MISSING"
        typer.echo(f"  - {r['package']:<24} {r['card_count']:>5} cards  ({status})")
    typer.echo("")

    for i, c in enumerate(report["candidates"][:10], 1):
        score = c.get("score_boosted", c.get("score", 0))
        typer.echo(f"  #{i:2d}  score={score:>6.1f}  "
                   f"crosses={c.get('crosses_repos', 0)}  "
                   f"conf={c.get('edge_confidence', '?')}")
        typer.echo(f"        name:    {c.get('name', '?')}")
        typer.echo(f"        origins: {', '.join(c.get('origin_repos', []))}")
        chain = c.get("chain", {}).get("domains") or c.get("chain", {}).get("chain", [])
        typer.echo(f"        chain:   {' → '.join(map(str, chain))}")
        if c.get("novel_composition"):
            typer.echo("        novel:   yes (no static call edge)")
        typer.echo("")

    if report["candidate_count"] > 10:
        typer.echo(f"  … {report['candidate_count'] - 10} more candidates "
                   f"(use --json or --save to see all)\n")
