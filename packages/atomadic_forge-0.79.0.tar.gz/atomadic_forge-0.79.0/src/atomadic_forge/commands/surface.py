"""``forge surface`` — emit / inspect / diff the canonical Forge surface.

The single-source-of-truth CLI verb. Three subcommands:

* ``forge surface emit``  — print or write the current ``surface.json``
* ``forge surface check`` — fail with diff if surface.json on disk
                            doesn't match the canonical regeneration
                            (CI gate against silent surface drift)
* ``forge surface diff``  — public delta between two surface.json files
                            (used for auto-CHANGELOG + Worker endpoint)
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a3_og_features.surface_export import (
    diff_surfaces,
    export_surface,
)

COMMAND_NAME = "surface"
COMMAND_HELP = (
    "Emit / check / diff the canonical Forge surface artifact "
    "(single source of truth for tools, recipes, schemas)."
)

app = typer.Typer(no_args_is_help=True, help=COMMAND_HELP)


def _serialize(surface: dict) -> str:
    """Stable, byte-identical JSON for content-addressed comparison."""
    return json.dumps(surface, indent=2, sort_keys=True, default=str) + "\n"


def _content_only(surface: dict) -> dict:
    """Strip non-content fields (timestamps) for drift comparison."""
    out = dict(surface)
    out.pop("generated_at_utc", None)
    return out


@app.command("emit")
def emit_cmd(
    out: Annotated[Path | None, typer.Option("--out", "-o",
        help="Write to this path. Omit to print to stdout.",
        file_okay=True, dir_okay=False, resolve_path=True)] = None,
) -> None:
    """Emit the current canonical surface artifact."""
    surface = export_surface()
    payload = _serialize(surface)
    if out:
        out.write_text(payload, encoding="utf-8")
        typer.echo(f"wrote {out}  ({surface['tools_count']} tools, "
                   f"{surface['recipes_count']} recipes, "
                   f"{len(surface['legacy_endpoint_map'])} legacy entries)")
    else:
        typer.echo(payload, nl=False)


@app.command("check")
def check_cmd(
    path: Annotated[Path, typer.Option("--path", "-p",
        help="Path to the on-disk surface.json to validate.",
        exists=False, file_okay=True, dir_okay=False,
        resolve_path=True)] = Path("surface.json"),
) -> None:
    """CI gate: exit 1 if on-disk surface.json drifts from canonical.

    Use this in pre-commit hooks and GitHub Actions to prevent silent
    drift between TOOLS / SCHEMA_VERSIONS / recipes and surface.json.
    """
    canonical = export_surface()
    if not path.exists():
        typer.secho(f"surface.json missing at {path}", fg="red", err=True)
        typer.echo("Run:  forge surface emit --out surface.json", err=True)
        raise typer.Exit(1)
    on_disk_obj = json.loads(path.read_text(encoding="utf-8"))
    # Drift comparison ignores ``generated_at_utc`` so re-emitting on
    # the same content doesn't trip the gate. Tools / recipes / schema
    # / legacy_endpoint_map are content-addressed.
    if _content_only(on_disk_obj) == _content_only(canonical):
        typer.secho("surface.json matches canonical regeneration", fg="green")
        raise typer.Exit(0)
    # Drift — show a compact summary, not the whole diff.
    diff = diff_surfaces(on_disk_obj, canonical)
    typer.secho("surface.json is OUT OF SYNC with the canonical regeneration",
                 fg="red", err=True)
    if diff["tools_added"]:
        typer.echo(f"  tools_added:   {diff['tools_added']}", err=True)
    if diff["tools_removed"]:
        typer.echo(f"  tools_removed: {diff['tools_removed']}", err=True)
    if diff["tools_with_schema_change"]:
        typer.echo(f"  schema_change: {diff['tools_with_schema_change']}",
                   err=True)
    if diff["recipes_added"]:
        typer.echo(f"  recipes_added:   {diff['recipes_added']}", err=True)
    if diff["recipes_removed"]:
        typer.echo(f"  recipes_removed: {diff['recipes_removed']}", err=True)
    typer.echo("\nFix:  forge surface emit --out surface.json && git add surface.json",
               err=True)
    raise typer.Exit(1)


@app.command("diff")
def diff_cmd(
    before: Annotated[Path, typer.Argument(
        help="Earlier surface.json.",
        exists=True, file_okay=True, dir_okay=False, resolve_path=True)],
    after: Annotated[Path, typer.Argument(
        help="Later surface.json.",
        exists=True, file_okay=True, dir_okay=False, resolve_path=True)],
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
) -> None:
    """Public delta between two surface.json files."""
    a = json.loads(before.read_text(encoding="utf-8"))
    b = json.loads(after.read_text(encoding="utf-8"))
    delta = diff_surfaces(a, b)
    if json_out:
        typer.echo(json.dumps(delta, indent=2, default=str))
        return
    typer.echo("")
    typer.echo(f"Surface diff   {delta['from_version']} → {delta['to_version']}")
    typer.echo("-" * 60)
    if delta["tools_added"]:
        typer.echo(f"  + tools_added   ({len(delta['tools_added'])}):")
        for n in delta["tools_added"]:
            typer.echo(f"      + {n}")
    if delta["tools_removed"]:
        typer.echo(f"  - tools_removed ({len(delta['tools_removed'])}):")
        for n in delta["tools_removed"]:
            typer.echo(f"      - {n}")
    if delta["tools_with_schema_change"]:
        typer.echo(f"  ~ schema_change ({len(delta['tools_with_schema_change'])}):")
        for n in delta["tools_with_schema_change"]:
            typer.echo(f"      ~ {n}")
    if delta["recipes_added"] or delta["recipes_removed"]:
        typer.echo("")
        typer.echo("Recipes:")
        for n in delta["recipes_added"]:
            typer.echo(f"  + {n}")
        for n in delta["recipes_removed"]:
            typer.echo(f"  - {n}")
    if not (delta["tools_added"] or delta["tools_removed"]
            or delta["tools_with_schema_change"]
            or delta["recipes_added"] or delta["recipes_removed"]):
        typer.echo("  (no public surface changes)")
