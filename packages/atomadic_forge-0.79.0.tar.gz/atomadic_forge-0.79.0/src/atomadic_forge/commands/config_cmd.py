"""Tier a4 — config management CLI commands (show, set, test, wizard)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a0_qk_constants.config_defaults import (
    CONFIG_FILE_NAME,
    GLOBAL_CONFIG_DIR,
    LOCAL_CONFIG_DIR,
)
from atomadic_forge.a1_at_functions.config_io import (
    load_config,
    read_config_file,
    save_config,
    validate_config,
)
from atomadic_forge.a1_at_functions.provider_detect import test_provider

COMMAND_NAME = "config"
COMMAND_HELP = "Configure Atomadic Forge — setup wizard + config management."

app = typer.Typer(no_args_is_help=True, help=COMMAND_HELP)

_CWD = Path(".")


@app.command("wizard")
def wizard_cmd(
    project_dir: Annotated[
        Path,
        typer.Option("--project", file_okay=False, dir_okay=True, resolve_path=True,
                     help="Project directory (default: cwd)."),
    ] = _CWD,
) -> None:
    """Interactive setup wizard — configure LLM, defaults, and workspace."""
    from atomadic_forge.a3_og_features.setup_wizard import run_wizard
    run_wizard(project_dir.resolve())


@app.command("show")
def show_cmd(
    project_dir: Annotated[
        Path,
        typer.Option("--project", file_okay=False, dir_okay=True, resolve_path=True,
                     help="Project directory (default: cwd)."),
    ] = _CWD,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Print the current merged config (local → global → defaults)."""
    config = load_config(project_dir.resolve())
    issues = validate_config(config)

    if json_out:
        typer.echo(json.dumps({"config": config, "issues": issues}, indent=2))
        return

    typer.echo("\nAtomadic Forge — config")
    typer.echo("-" * 44)
    for k, v in config.items():
        if "key" in k and v:
            s = str(v)
            display = s[:8] + "..." + s[-4:] if len(s) > 12 else "***"
        else:
            display = str(v) if v is not None else "(not set)"
        typer.echo(f"  {k:28s} {display}")

    if issues:
        typer.echo("\nValidation issues:")
        for issue in issues:
            typer.secho(f"  - {issue}", fg="yellow")
    else:
        typer.secho("\n  Config is valid.", fg="green")


@app.command("set")
def set_cmd(
    key: Annotated[str, typer.Argument(help="Config key to set.")],
    value: Annotated[str, typer.Argument(help="Value to assign.")],
    project_dir: Annotated[
        Path,
        typer.Option("--project", file_okay=False, dir_okay=True, resolve_path=True,
                     help="Project directory (default: cwd)."),
    ] = _CWD,
    global_: Annotated[
        bool,
        typer.Option("--global", help="Write to global config (~/.atomadic-forge/config.json)."),
    ] = False,
) -> None:
    """Set a single config key in the local (or --global) config file."""
    if global_:
        config_path = Path(GLOBAL_CONFIG_DIR).expanduser() / CONFIG_FILE_NAME
    else:
        config_path = project_dir.resolve() / LOCAL_CONFIG_DIR / CONFIG_FILE_NAME

    current = read_config_file(config_path)

    # Coerce obvious types so booleans and numbers round-trip cleanly.
    coerced: object = value
    if value.lower() in ("true", "false"):
        coerced = value.lower() == "true"
    else:
        try:
            coerced = float(value) if "." in value else int(value)
        except ValueError:
            pass

    current[key] = coerced
    save_config(current, config_path)
    typer.echo(f"  Set {key!r} = {coerced!r}  →  {config_path}")


@app.command("test")
def test_cmd(
    project_dir: Annotated[
        Path,
        typer.Option("--project", file_okay=False, dir_okay=True, resolve_path=True,
                     help="Project directory (default: cwd)."),
    ] = _CWD,
    provider: Annotated[
        str | None,
        typer.Option("--provider", help="Override provider to test."),
    ] = None,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Test the configured LLM provider connection."""
    config = load_config(project_dir.resolve())
    p = provider or config.get("provider", "auto")
    result = test_provider(p, config)

    if json_out:
        typer.echo(json.dumps(result, indent=2))
        return

    color = "green" if result["ok"] else "red"
    typer.secho(f"\nProvider test — {p}", bold=True)
    typer.secho(f"  Status:    {'OK' if result['ok'] else 'FAIL'}", fg=color)
    typer.echo(f"  Model:     {result['model']}")
    typer.echo(f"  Latency:   {result['latency_ms']}ms")
    if result["error"]:
        typer.secho(f"  Error:     {result['error']}", fg="yellow")


# ─────────────────────────────────────────────────────────────────────
# `forge config provider …` — manage custom LLM providers
# ─────────────────────────────────────────────────────────────────────

provider_app = typer.Typer(
    no_args_is_help=True,
    help="Manage custom LLM providers (add / list / remove / presets).",
)
app.add_typer(provider_app, name="provider")


@provider_app.command("list")
def provider_list_cmd(
    project_dir: Annotated[
        Path,
        typer.Option("--project", file_okay=False, dir_okay=True, resolve_path=True,
                     help="Project directory (default: cwd)."),
    ] = _CWD,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """List configured custom providers + bundled presets."""
    from atomadic_forge.a1_at_functions.custom_provider_client import PRESETS
    config = load_config(project_dir.resolve())
    custom = config.get("custom_providers", []) or []

    if json_out:
        typer.echo(json.dumps({
            "custom_providers": custom,
            "available_presets": sorted(PRESETS.keys()),
        }, indent=2))
        return

    typer.secho("\nCustom providers (config.json:custom_providers):", bold=True)
    if not custom:
        typer.echo("  (none configured)")
    for entry in custom:
        name = entry.get("name", "?")
        url = entry.get("base_url", "(via preset)")
        model = entry.get("model", "(via preset)")
        env = entry.get("api_key_env", "(via preset)")
        preset = entry.get("preset", "")
        suffix = f"  ← preset:{preset}" if preset else ""
        typer.echo(f"  {name:18s} {model:40s} key={env}{suffix}")
        if url != "(via preset)":
            typer.echo(f"    {'':18s} {url}")

    typer.secho("\nBundled presets (use with `--preset NAME`):", bold=True)
    for name in sorted(PRESETS):
        cfg = PRESETS[name]
        typer.echo(f"  {name:18s} {cfg['model']:40s} key={cfg['api_key_env']}")


@provider_app.command("add")
def provider_add_cmd(
    name: Annotated[str, typer.Argument(
        help="Name to use with `--provider`."),
    ],
    base_url: Annotated[str | None, typer.Option(
        "--base-url", help="API base URL (e.g. https://api.deepseek.com/v1)."),
    ] = None,
    model: Annotated[str | None, typer.Option(
        "--model", help="Model id to call by default."),
    ] = None,
    api_key_env: Annotated[str | None, typer.Option(
        "--api-key-env", help="Environment variable holding the API key."),
    ] = None,
    preset: Annotated[str | None, typer.Option(
        "--preset", help="Use a bundled preset (groq/deepseek/together/…) "
                          "to fill defaults; user flags override."),
    ] = None,
    fmt: Annotated[str, typer.Option(
        "--format", help="Wire format: openai (default).")
    ] = "openai",
    project_dir: Annotated[
        Path,
        typer.Option("--project", file_okay=False, dir_okay=True, resolve_path=True),
    ] = _CWD,
    global_: Annotated[
        bool,
        typer.Option("--global", help="Save to ~/.atomadic-forge/config.json."),
    ] = False,
) -> None:
    """Add a custom LLM provider to config.

    Three usage shapes:

      forge config provider add deepseek --preset deepseek
      forge config provider add my-llm --base-url https://… \\
            --model my-model --api-key-env MY_KEY
      forge config provider add groq --preset groq --model llama-3.3-70b
    """
    from atomadic_forge.a1_at_functions.custom_provider_client import (
        from_config,
    )

    if global_:
        config_path = Path(GLOBAL_CONFIG_DIR).expanduser() / CONFIG_FILE_NAME
    else:
        config_path = project_dir.resolve() / LOCAL_CONFIG_DIR / CONFIG_FILE_NAME
    current = read_config_file(config_path)
    custom = list(current.get("custom_providers", []) or [])

    entry: dict = {"name": name, "format": fmt}
    if preset:
        entry["preset"] = preset
    if base_url:
        entry["base_url"] = base_url
    if model:
        entry["model"] = model
    if api_key_env:
        entry["api_key_env"] = api_key_env

    # Validate by trying to construct it.
    try:
        from_config(entry)
    except ValueError as exc:
        typer.secho(f"  Invalid provider entry: {exc}", fg="red")
        raise typer.Exit(2) from exc

    # Replace any existing entry of the same name; otherwise append.
    custom = [e for e in custom if e.get("name", "").lower() != name.lower()]
    custom.append(entry)
    current["custom_providers"] = custom
    save_config(current, config_path)
    typer.echo(f"  Added provider {name!r} → {config_path}")
    typer.echo(f"  Now usable with: forge --provider {name} …")


@provider_app.command("remove")
def provider_remove_cmd(
    name: Annotated[str, typer.Argument(help="Provider name to remove.")],
    project_dir: Annotated[
        Path,
        typer.Option("--project", file_okay=False, dir_okay=True, resolve_path=True),
    ] = _CWD,
    global_: Annotated[
        bool, typer.Option("--global"),
    ] = False,
) -> None:
    """Remove a custom provider entry from config."""
    if global_:
        config_path = Path(GLOBAL_CONFIG_DIR).expanduser() / CONFIG_FILE_NAME
    else:
        config_path = project_dir.resolve() / LOCAL_CONFIG_DIR / CONFIG_FILE_NAME
    current = read_config_file(config_path)
    before = len(current.get("custom_providers", []) or [])
    current["custom_providers"] = [
        e for e in (current.get("custom_providers", []) or [])
        if e.get("name", "").lower() != name.lower()
    ]
    after = len(current["custom_providers"])
    save_config(current, config_path)
    if before == after:
        typer.echo(f"  No provider named {name!r} in {config_path}")
    else:
        typer.echo(f"  Removed {name!r} ({before - after} entry/entries) "
                   f"from {config_path}")


@provider_app.command("presets")
def provider_presets_cmd(
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Print the bundled provider presets (groq, deepseek, together, …)."""
    from atomadic_forge.a1_at_functions.custom_provider_client import PRESETS
    if json_out:
        typer.echo(json.dumps(PRESETS, indent=2))
        return
    typer.secho("\nBundled LLM provider presets:", bold=True)
    typer.echo("  Use one of these as `--preset` when adding a provider:\n")
    for name in sorted(PRESETS):
        cfg = PRESETS[name]
        typer.echo(f"  {name:14s} → {cfg['base_url']}")
        typer.echo(f"  {'':14s}   model={cfg['model']}, key={cfg['api_key_env']}")
        typer.echo("")
