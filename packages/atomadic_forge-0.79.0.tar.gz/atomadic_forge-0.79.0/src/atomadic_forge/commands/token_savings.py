"""Tier a4 — `forge token-savings` CLI surface.

Display the lifetime token-savings ledger for a project. Every Forge
verb that reports a ``scope.tokens_saved_estimate`` automatically
appends to this ledger via ``response_enricher.enrich_response``, so
the running total is the cumulative LLM round-trip cost the Forge has
spared the caller — boastable, verifiable, file-backed.

The ledger lives at ``<project>/.atomadic-forge/lifetime_savings.jsonl``.
One JSON object per line, append-only. Read it directly to audit.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a1_at_functions.lifetime_savings import (
    read_savings_summary,
)

COMMAND_NAME = "token-savings"
COMMAND_HELP = (
    "Show the project's lifetime token-savings ledger — the cumulative "
    "LLM round-trips the Forge has spared, broken down by tool."
)

app = typer.Typer(no_args_is_help=False, help=COMMAND_HELP)


@app.callback(invoke_without_command=True)
def run(
    project: Annotated[Path, typer.Option(
        "--project", "-p",
        help="Project root (must contain .atomadic-forge/).",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True)] = (
        Path(".")),
    json_out: Annotated[bool, typer.Option(
        "--json", help="Emit machine-readable JSON.")] = False,
) -> None:
    """Show lifetime token-savings for the project."""
    summary = read_savings_summary(project_root=project)

    if json_out:
        typer.echo(json.dumps(summary, indent=2, default=str))
        return

    typer.echo("")
    typer.echo("Forge — lifetime token-savings ledger")
    typer.echo("-" * 60)
    typer.echo(f"  project:        {project}")
    typer.echo(f"  ledger:         {summary['ledger_file']}")
    if not summary["ledger_present"]:
        typer.secho("  (no ledger yet — run any verb to start logging)",
                     fg="yellow")
        return
    total = int(summary["tokens_saved_lifetime"])
    typer.echo(f"  entries:        {summary['entry_count']}")
    typer.echo(f"  tokens saved:   {total:,}")
    typer.echo(f"  first seen:     {summary['first_seen_at']}")
    typer.echo(f"  last seen:      {summary['last_seen_at']}")
    by_tool = summary.get("by_tool") or {}
    if by_tool:
        typer.echo("")
        typer.echo("  by tool:")
        for tool, n in sorted(by_tool.items(), key=lambda kv: -kv[1]):
            pct = (100.0 * n / total) if total else 0.0
            typer.echo(f"    {tool:<14} {n:>10,}  ({pct:5.1f}%)")
