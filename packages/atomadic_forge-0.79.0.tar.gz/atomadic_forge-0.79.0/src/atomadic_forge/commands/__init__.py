"""Commandsmith-discoverable command modules."""
