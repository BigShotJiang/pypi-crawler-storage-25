"""Tier a4 — ``forge recon_swarm`` CLI surface.

Round-4 multi-repo scout. Wraps the a3 ``recon_swarm`` function so
the unified scout report is reachable from the shell.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a3_og_features.cherry_hunter import recon_swarm

COMMAND_NAME = "recon_swarm"
COMMAND_HELP = (
    "Round-4: walk N repos, return a unified scout report with "
    "origin_repo annotations on every symbol."
)

app = typer.Typer(no_args_is_help=True, help=COMMAND_HELP)


@app.callback(invoke_without_command=True)
def run(
    repo: Annotated[list[Path], typer.Option("--repo", "-r",
        help="Repo path to include in the swarm. Pass once per repo (≤23).",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = None,  # type: ignore[assignment]
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
    save: Annotated[Path | None, typer.Option("--save",
        help="Persist the report at this path.",
        file_okay=True, dir_okay=False, resolve_path=True)] = None,
) -> None:
    """Walk N repos and return a unified scout report."""
    if not repo:
        typer.secho("recon_swarm: at least one --repo is required",
                     fg="red", err=True)
        raise typer.Exit(2)

    try:
        report = recon_swarm(repos=list(repo))
    except ValueError as exc:
        typer.secho(str(exc), fg="red", err=True)
        raise typer.Exit(1) from exc

    if save:
        save.write_text(json.dumps(report, indent=2, default=str),
                        encoding="utf-8")

    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return

    typer.echo("")
    typer.echo("Recon swarm — multi-repo scout")
    typer.echo("-" * 60)
    typer.echo(f"  repos:                {report['repo_count']}")
    typer.echo(f"  union symbols:        {report['union_symbol_count']}")
    typer.echo(f"  Ω residue:            {report['omega_residue']}  "
               f"(invariant holds: {report['omega_invariant_holds']})")
    typer.echo(f"  D_max cap:            {report['d_max_cap']}")
    typer.echo("")

    typer.echo("Tier distribution (union):")
    for tier, count in sorted(report["union_tier_distribution"].items()):
        typer.echo(f"  {tier:<6} {count}")
    typer.echo("")

    typer.echo("Per-repo:")
    for r in report["per_repo"]:
        status = "ok" if r.get("exists") else r.get("error", "missing")
        typer.echo(f"  - {Path(r['repo']).name:<32} "
                   f"{r['symbol_count']:>6} symbols  ({status})")
