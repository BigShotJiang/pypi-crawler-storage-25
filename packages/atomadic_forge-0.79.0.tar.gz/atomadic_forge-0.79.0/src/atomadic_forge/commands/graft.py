"""Tier a4 — `forge graft` CLI surface.

Pull one named symbol from a tier-organized source into the target's
correct tier and (optionally) auto-wire CLI + MCP coverage so the new
capability lights up without any manual wiring step.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a3_og_features.graft_feature import graft

COMMAND_NAME = "graft"
COMMAND_HELP = (
    "Pull a single function/class from a source file into the target's "
    "5-tier surface. Optionally calls auto-wire to surface CLI + MCP."
)

app = typer.Typer(no_args_is_help=True, help=COMMAND_HELP)


@app.callback(invoke_without_command=True)
def run(
    source_file: Annotated[Path, typer.Option(
        "--source-file", "-s",
        help="Path to a .py file containing the symbol to graft.",
        exists=True, file_okay=True, dir_okay=False, resolve_path=True)],
    symbol: Annotated[str, typer.Option(
        "--symbol", "-S",
        help="Bare name of the top-level function or class to extract.")],
    target: Annotated[Path, typer.Option(
        "--target", "-t",
        help="Project root that contains src/<package>/.",
        exists=True, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    package: Annotated[str, typer.Option(
        "--package", "-p",
        help="Importable package under src/ (default: atomadic_forge).")] = (
        "atomadic_forge"),
    tier: Annotated[str | None, typer.Option(
        "--tier",
        help="Override the destination tier "
             "(e.g. a1_at_functions, a2_mo_composites). "
             "Default: function->a1, class->a2.")] = None,
    rename: Annotated[str | None, typer.Option(
        "--rename",
        help="Rename the grafted symbol on the way in. Use this to drop "
             "a leading underscore (private->public) so auto-wire can "
             "surface the new capability via CLI + MCP.")] = None,
    overwrite: Annotated[bool, typer.Option(
        "--overwrite",
        help="Overwrite an existing destination file.")] = False,
    dry_run: Annotated[bool, typer.Option(
        "--dry-run",
        help="Plan the graft and print the report without writing.")] = False,
    auto_wire: Annotated[bool, typer.Option(
        "--auto-wire/--no-auto-wire",
        help="After a successful graft, call `forge auto-wire` so the new "
             "a1 entry point is surfaced in MCP + CLI without a manual "
             "wire-stubs invocation.")] = True,
    json_out: Annotated[bool, typer.Option(
        "--json", help="Emit machine-readable JSON.")] = False,
) -> None:
    """Graft one symbol from a source file into the target."""
    try:
        report = graft(
            source_file=source_file,
            symbol_name=symbol,
            target_root=target,
            package=package,
            tier=tier,
            rename_to=rename,
            overwrite=overwrite,
            dry_run=dry_run,
        )
    except (FileNotFoundError, KeyError, FileExistsError) as exc:
        typer.secho(f"graft: {exc}", fg="red", err=True)
        raise typer.Exit(2) from exc

    payload = report.to_dict()

    # If the graft introduced a wire violation, refuse to proceed and
    # advise the rollback path. The caller can re-run --overwrite=False
    # after fixing the source.
    if report.written and report.wire_violations > 0:
        typer.secho(
            f"graft: wire violations introduced ({report.wire_violations}) — "
            f"rolling back to backup at {report.backup_path}.",
            fg="red", err=True,
        )
        if report.backup_path:
            Path(report.target_path).write_text(
                Path(report.backup_path).read_text(encoding="utf-8"),
                encoding="utf-8",
            )
        else:
            Path(report.target_path).unlink(missing_ok=True)
        if json_out:
            typer.echo(json.dumps(payload, indent=2, default=str))
        raise typer.Exit(3)

    if report.written and auto_wire and report.kind in ("function", "async_function"):
        # Tier a1 functions are the only kind auto-wire surfaces today.
        # Run it as a subprocess so its own typer/runtime errors don't
        # crash the graft report.
        result = subprocess.run(
            [sys.executable, "-m", "atomadic_forge.a4_sy_orchestration.cli",
             "auto-wire", "--project", str(target)],
            cwd=target, check=False,
        )
        payload["auto_wire_exit_code"] = result.returncode

    if json_out:
        typer.echo(json.dumps(payload, indent=2, default=str))
        return

    typer.echo("")
    typer.echo("Graft — single-symbol cross-repo capability transfer")
    typer.echo("-" * 60)
    typer.echo(f"  source:        {report.source_file}")
    typer.echo(f"  symbol:        {report.symbol_name}  ({report.kind})")
    typer.echo(f"  target tier:   {report.target_tier}")
    typer.echo(f"  written to:    {report.target_path}")
    typer.echo(f"  bytes:         {report.bytes_written}")
    typer.echo(f"  source lines:  {report.source_lines[0]}–{report.source_lines[1]}")
    if report.imports_needed:
        typer.echo(f"  imports kept:  {', '.join(report.imports_needed)}")
    typer.echo(f"  wire verdict:  {report.wire_verdict}  "
               f"(violations: {report.wire_violations})")
    if not report.written:
        typer.secho("  dry run — nothing was written", fg="yellow")
    if "auto_wire_exit_code" in payload:
        typer.echo(f"  auto-wire:     exit {payload['auto_wire_exit_code']}")
