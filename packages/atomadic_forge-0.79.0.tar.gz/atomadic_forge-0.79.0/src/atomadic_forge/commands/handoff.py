"""``forge handoff`` — capture / list / show structured session handoffs.

Lets one agent leave a JSON breadcrumb the next agent can read at the
start of its turn. Stored at ``.atomadic-forge/handoffs/<id>.json``.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a0_qk_constants.handoff_constants import (
    AXIOM_GUARD_PASS,
    AXIOM_GUARD_VALUES,
)
from atomadic_forge.a1_at_functions.handoff_builder import parse_pytest_summary
from atomadic_forge.a3_og_features.handoff_feature import (
    list_handoffs,
    read_handoff,
    write_handoff,
)

COMMAND_NAME = "handoff"
COMMAND_HELP = (
    "Capture a structured session handoff so the next agent can pick "
    "up where this one left off. Writes JSON to "
    ".atomadic-forge/handoffs/<session_id>.json."
)

app = typer.Typer(no_args_is_help=True, help=COMMAND_HELP)


def _split_csv(raw: str) -> list[str]:
    return [s.strip() for s in (raw or "").split(",") if s.strip()]


def _split_lines(raw: str) -> list[str]:
    """Split a multi-item field on newlines OR semicolons.

    Comma alone is unsafe — task strings often contain commas. Caller
    can use ``;`` between tasks or ``\\n`` if shell quoting allows.
    """
    if not raw:
        return []
    tokens: list[str] = []
    for line in raw.split("\n"):
        for tok in line.split(";"):
            tok = tok.strip()
            if tok:
                tokens.append(tok)
    return tokens


@app.command("create")
def create_cmd(
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        help="Repo to write the handoff under.",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    agent: Annotated[str, typer.Option("--agent",
        help="Identifier of the recording agent.")] = "anonymous",
    work: Annotated[str, typer.Option("--work",
        help="Work completed; separate items with `;` or newline.")] = "",
    pending: Annotated[str, typer.Option("--pending",
        help="Pending tasks; separate items with `;` or newline.")] = "",
    files_modified: Annotated[str, typer.Option("--files-modified",
        help="Comma-separated paths modified this session.")] = "",
    files_created: Annotated[str, typer.Option("--files-created",
        help="Comma-separated paths created this session.")] = "",
    pytest_summary: Annotated[str, typer.Option("--pytest-summary",
        help='Raw pytest tail line, e.g. "1133 passed, 0 failed in 12.3s".')] = "",
    key_context: Annotated[str, typer.Option("--key-context",
        help="Free-text summary for the next agent. Capped at 8000 chars.")] = "",
    warnings: Annotated[str, typer.Option("--warnings",
        help="Things the next agent should know; `;`/newline separated.")] = "",
    axiom_guard_status: Annotated[str, typer.Option("--axiom-guard",
        help="PASS or QUARANTINE — overall trust verdict for this session.",
        case_sensitive=False)] = AXIOM_GUARD_PASS,
    session_id: Annotated[str, typer.Option("--session-id",
        help="Override the auto-generated HOFF-* id.")] = "",
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON to stdout.")] = False,
) -> None:
    """Write one handoff entry for this session."""
    guard = (axiom_guard_status or AXIOM_GUARD_PASS).upper()
    if guard not in AXIOM_GUARD_VALUES:
        typer.secho(
            f"axiom-guard must be one of {sorted(AXIOM_GUARD_VALUES)}, "
            f"got {axiom_guard_status!r}",
            fg="red", err=True,
        )
        raise typer.Exit(2)

    test_results = parse_pytest_summary(pytest_summary) if pytest_summary else None

    out = write_handoff(
        project_root=project_root,
        agent_name=agent,
        work_completed=_split_lines(work),
        files_modified=_split_csv(files_modified),
        files_created=_split_csv(files_created),
        test_results=test_results,
        pending_tasks=_split_lines(pending),
        key_context=key_context,
        warnings=_split_lines(warnings),
        axiom_guard_status=guard,
        session_id=session_id or None,
    )
    if json_out:
        typer.echo(json.dumps(out, indent=2))
        return
    entry = out["entry"]
    typer.echo(f"handoff:    {entry['session_id']}")
    typer.echo(f"timestamp:  {entry['timestamp']}")
    typer.echo(f"agent:      {entry['agent_name']}")
    typer.echo(f"axiom:      {entry['axiom_guard_status']}")
    typer.echo(f"work:       {len(entry['work_completed'])} items")
    typer.echo(f"pending:    {len(entry['pending_tasks'])} items")
    typer.echo(f"file_diff:  +{len(entry['files_created'])} created, "
                f"~{len(entry['files_modified'])} modified")
    tr = entry["test_results"]
    typer.echo(f"tests:      {tr['passed']} passed, {tr['failed']} failed, "
                f"{tr['skipped']} skipped")
    typer.echo(f"saved to:   {out['handoff_file']}")


@app.command("list")
def list_cmd(
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        help="Repo to list handoffs from.",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    limit: Annotated[int, typer.Option("--limit", "-n",
        help="Cap the number of returned entries (default 20).")] = 20,
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
) -> None:
    """List handoffs for this repo, newest first."""
    out = list_handoffs(project_root=project_root, limit=limit)
    if json_out:
        typer.echo(json.dumps(out, indent=2))
        return
    typer.echo(f"handoff_dir: {out['handoff_dir']}")
    typer.echo(f"total:       {out['total_count']}")
    if out["skipped"]:
        typer.echo(f"skipped:     {len(out['skipped'])} (malformed)")
    if not out["entries"]:
        typer.echo("(no handoffs yet — run `forge handoff create`)")
        return
    typer.echo("")
    for e in out["entries"]:
        tr = e.get("test_results", {}) or {}
        typer.echo(
            f"  {e.get('session_id','?')}  "
            f"{e.get('timestamp','?')}  "
            f"agent={e.get('agent_name','?')}  "
            f"axiom={e.get('axiom_guard_status','?')}  "
            f"tests={tr.get('passed',0)}/{tr.get('failed',0)}/{tr.get('skipped',0)}"
        )


@app.command("show")
def show_cmd(
    session_id: Annotated[str, typer.Argument(help="HOFF-* id to read.")],
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        help="Repo to read from.",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
) -> None:
    """Print one handoff entry as JSON."""
    entry = read_handoff(project_root=project_root, session_id=session_id)
    if entry is None:
        typer.secho(f"no handoff found: {session_id!r}", fg="yellow", err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(entry, indent=2))
