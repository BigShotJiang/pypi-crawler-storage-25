"""``atomadic-forge materialize`` — emergent candidates -> shippable package.

Closes the pipeline: ``forge emergent scan --save report.json`` discovers
novel compositions; ``forge materialize`` writes a real, certify-able
Python package containing one a3 feature module per selected candidate.

Examples
--------
    # Top-5 from a saved report:
    forge emergent scan --save scan.json --top-n 25
    forge materialize scan.json ./out --package emergent_demo

    # Pick specific candidate ids:
    forge materialize scan.json ./out --package my_pkg \\
        --id emrg-abc12345 --id emrg-def67890

    # Skip certify (faster):
    forge materialize scan.json ./out --package my_pkg --no-certify
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a3_og_features.materialize_feature import (
    materialize_from_report_path,
)

COMMAND_NAME = "materialize"
COMMAND_HELP = (
    "Turn emergent scan candidates into a shippable Python package "
    "(scaffold + features + certify)."
)


app = typer.Typer(no_args_is_help=True, help=COMMAND_HELP)


@app.command("run")
def run_cmd(
    report_path: Annotated[Path, typer.Argument(
        help="Saved emergent scan report (from `forge emergent scan --save`).",
        exists=True, file_okay=True, dir_okay=False, resolve_path=True)],
    out_dir: Annotated[Path, typer.Argument(
        help="Where to write the new package (must be empty or fresh).",
        file_okay=False, dir_okay=True, resolve_path=True)],
    package: Annotated[str, typer.Option("--package",
        help="Importable name of the new package.")] = "emergent_pkg",
    top_n: Annotated[int, typer.Option("--top-n",
        help="Materialize the top-N candidates from the report.")] = 5,
    candidate_id: Annotated[list[str] | None, typer.Option("--id",
        help="Specific candidate id to include (repeat to add more). "
             "Overrides --top-n when given.")] = None,
    source_package: Annotated[str, typer.Option("--source-package",
        help="Package the report was generated from (used for docs).")] = "atomadic_forge",
    intent: Annotated[str, typer.Option("--intent",
        help="One-line description of why these were materialized.")] = "",
    no_certify: Annotated[bool, typer.Option("--no-certify",
        help="Skip the certify pass on the new package.")] = False,
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
) -> None:
    """Materialize the report into a fresh, pip-installable package."""
    report = materialize_from_report_path(
        report_path,
        out_dir=out_dir,
        package=package,
        top_n=top_n,
        candidate_ids=candidate_id or None,
        run_certify=not no_certify,
        source_package=source_package,
        intent=intent,
    )

    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return

    typer.echo("")
    typer.echo(f"Materialize -> {report['out_dir']}")
    typer.echo("-" * 60)
    typer.echo(f"  package:            {report['package']}")
    typer.echo(f"  candidates:         {len(report['candidates_selected'])}")
    typer.echo(f"  files written:      {len(report['files_written'])}")
    if report["wire_violations"] is not None:
        typer.echo(f"  wire violations:    {report['wire_violations']}")
    if report["certify_score"] is not None:
        typer.echo(
            f"  certify:            {report['certify_score']:.0f}  "
            f"({report['certify_grade']})",
        )
    typer.echo("")
    typer.echo(f"  {report['summary_line']}")
    typer.echo("")
    typer.echo("Next:")
    typer.echo(f"  cd {report['out_dir']}")
    typer.echo("  pip install -e .")
    typer.echo("  pytest tests/")
    typer.echo("")
