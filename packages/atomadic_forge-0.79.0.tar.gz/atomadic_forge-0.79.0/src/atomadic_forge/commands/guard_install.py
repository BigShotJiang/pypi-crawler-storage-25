"""Tier a4 — ``forge guard_install`` CLI surface.

Round-5 four-layer architectural guard installer. Wraps the a3
``guard_install`` function.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a3_og_features.guard_install import guard_install

COMMAND_NAME = "guard_install"
COMMAND_HELP = (
    "Round-5: install the four-layer architectural guard "
    "(pre-commit, CI workflow, CONTRIBUTING note, .forge-guard.json)."
)

app = typer.Typer(no_args_is_help=True, help=COMMAND_HELP)


@app.callback(invoke_without_command=True)
def run(
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        help="Repo to install the guard into.",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    min_certify: Annotated[int, typer.Option("--min-certify",
        help="Minimum certify score below which commits are blocked.")] = 90,
    max_cyclomatic: Annotated[int, typer.Option("--max-cyclomatic",
        help="Maximum cyclomatic complexity per function.")] = 10,
    strict: Annotated[bool, typer.Option("--strict",
        help="Block ANY drop in certify score, not just below threshold.")] = False,
    apply: Annotated[bool, typer.Option("--apply",
        help="Actually write the four files. Default is dry-run.")] = False,
    overwrite: Annotated[bool, typer.Option("--overwrite",
        help="Overwrite existing files (default: skip).")] = False,
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
) -> None:
    """Install the four-layer architectural guard into a repo."""
    report = guard_install(
        project_root=project_root,
        min_certify_score=min_certify,
        max_cyclomatic=max_cyclomatic,
        strict_mode=strict,
        apply=apply,
        overwrite=overwrite,
    )
    data = report.as_dict()

    if json_out:
        typer.echo(json.dumps(data, indent=2, default=str))
        return

    typer.echo("")
    typer.echo("Guard install" + ("" if apply else " — DRY RUN"))
    typer.echo("-" * 60)
    typer.echo(f"  project_root:       {data.get('project_root', '?')}")
    contract = data.get("contract", {})
    if contract:
        typer.echo(f"  min_certify_score:  {contract.get('min_certify_score', '?')}")
        typer.echo(f"  max_cyclomatic:     {contract.get('max_cyclomatic', '?')}")
        typer.echo(f"  strict_mode:        {contract.get('strict_mode', '?')}")
    typer.echo("")

    written = data.get("files_written", [])
    skipped = data.get("files_skipped", [])
    failed = data.get("files_failed", [])

    if written:
        typer.echo(f"  written ({len(written)}):")
        for f in written:
            typer.echo(f"    + {f}")
    if skipped:
        typer.echo(f"  skipped ({len(skipped)}):")
        for f in skipped:
            typer.echo(f"    · {f}")
    if failed:
        typer.secho(f"  failed ({len(failed)}):", fg="yellow")
        for f in failed:
            typer.echo(f"    ! {f}")

    if not apply:
        typer.echo("")
        typer.echo("Re-run with --apply to actually write the files.")

    if data.get("next_command"):
        typer.echo("")
        typer.echo(f"Next: {data['next_command']}")
