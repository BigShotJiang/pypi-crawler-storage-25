"""``forge wisdom`` — record / query / list / recall the wisdom DB.

Cross-session institutional knowledge layer. Sits between raw lineage
(what happened) and curated recipes (what works). Designed so future
agents/devs can see prior lessons during recon and have prompted
capture during verify.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a0_qk_constants.wisdom_constants import (
    CONFIDENCE_LOW,
    DEFAULT_RECALL_TOP_N,
    WISDOM_SCOPE_REPO,
)
from atomadic_forge.a3_og_features.nexus_bridge import (
    mirror_wisdom_to_lineage,
)
from atomadic_forge.a3_og_features.wisdom_feature import (
    list_wisdom,
    promote_wisdom,
    query_wisdom,
    record_wisdom,
)

COMMAND_NAME = "wisdom"
COMMAND_HELP = (
    "Record / query / list cross-session wisdom — the institutional "
    "knowledge layer between lineage events and curated recipes."
)

app = typer.Typer(no_args_is_help=True, help=COMMAND_HELP)


@app.command("record")
def record_cmd(
    insight: Annotated[str, typer.Option("--insight", "-i",
        help="The lesson learned. Be specific and concrete.")],
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        help="Repo to record wisdom for.",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    scope: Annotated[str, typer.Option("--scope", "-s",
        help="repo | forge | general")] = WISDOM_SCOPE_REPO,
    tags: Annotated[str, typer.Option("--tags", "-t",
        help="Comma-separated tags (e.g. drift,worker,contract).")] = "",
    evidence: Annotated[str, typer.Option("--evidence", "-e",
        help="Comma-separated evidence paths (file:line refs).")] = "",
    confidence: Annotated[float, typer.Option("--confidence", "-c",
        help="0.0-1.0 confidence in the insight.")] = CONFIDENCE_LOW,
    agent_name: Annotated[str, typer.Option("--agent",
        help="Identifier of the recording agent.")] = "anonymous",
    supersedes: Annotated[str, typer.Option("--supersedes",
        help="WIS-* id this entry supersedes (drops the older from "
             "active_wisdom; old entry stays in load_wisdom for audit).")] = "",
    session_id: Annotated[str, typer.Option("--session-id",
        help="Optional session id for attribution.")] = "",
    nexus: Annotated[bool, typer.Option("--nexus",
        help="Mirror to AAAA-Nexus lineage_record on success "
             "(requires ATOMADIC_MASTER_KEY or _SUBSCRIPTION_KEY in env).")] = False,
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
) -> None:
    """Record one wisdom entry to .atomadic-forge/wisdom.jsonl.

    With ``--nexus``, also mirrors high-confidence (≥0.85) entries
    to AAAA-Nexus ``lineage_record`` for upstream attestation.
    Best-effort: degrades silently to local-only on auth/network
    failure (the local entry is canonical).
    """
    tag_list = [t.strip() for t in tags.split(",") if t.strip()]
    ev_list = [e.strip() for e in evidence.split(",") if e.strip()]
    out = record_wisdom(
        project_root=project_root,
        insight=insight,
        scope=scope,
        tags=tag_list,
        evidence=ev_list,
        confidence=confidence,
        agent_name=agent_name,
        supersedes=(supersedes or None),
        session_id=(session_id or None),
    )
    if nexus:
        nexus_result = mirror_wisdom_to_lineage(wisdom_entry=out["entry"])
        out["nexus_mirror"] = nexus_result
    if json_out:
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    entry = out["entry"]
    typer.secho(f"Recorded {entry['id']}  ({entry['scope']}, conf={entry['confidence']:.2f})",
                 fg="green")
    typer.echo(f"  insight: {entry['insight']}")
    if entry["tags"]:
        typer.echo(f"  tags:    {', '.join(entry['tags'])}")
    typer.echo(f"  file:    {out['wisdom_file']}")
    if "nexus_mirror" in out:
        nm = out["nexus_mirror"]
        if nm.get("mirrored"):
            typer.secho("  nexus:   mirrored to lineage_record", fg="cyan")
        else:
            typer.secho(f"  nexus:   skipped — {nm.get('reason')}", fg="yellow")


@app.command("query")
def query_cmd(
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    scope: Annotated[str | None, typer.Option("--scope", "-s",
        help="Filter by scope (repo / forge / general).")] = None,
    tags: Annotated[str, typer.Option("--tags", "-t",
        help="Comma-separated tags to match.")] = "",
    text: Annotated[str | None, typer.Option("--text",
        help="Free-text substring match against insights.")] = None,
    top_n: Annotated[int, typer.Option("--top-n",
        help="Max entries to return.")] = DEFAULT_RECALL_TOP_N,
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
) -> None:
    """Relevance-rank wisdom against scope / tags / text query."""
    tag_list = [t.strip() for t in tags.split(",") if t.strip()]
    out = query_wisdom(
        project_root=project_root, scope=scope,
        tags=tag_list, text=text, top_n=top_n,
    )
    if json_out:
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    typer.echo("")
    typer.echo(f"Wisdom recall  ({out['results_returned']} of "
               f"{out['total_entries_considered']} active entries)")
    typer.echo("-" * 60)
    if not out["top_entries"]:
        typer.echo("  (no matches; record some with `forge wisdom record`)")
        return
    for i, e in enumerate(out["top_entries"], 1):
        typer.echo(f"  #{i}  {e.get('id', '?'):<14}  "
                   f"score={e.get('_relevance_score', 0):>6.1f}  "
                   f"conf={e.get('confidence', 0):.2f}")
        typer.echo(f"        {e.get('insight', '')}")
        if e.get("tags"):
            typer.echo(f"        tags: {', '.join(e['tags'])}")
        typer.echo("")


@app.command("list")
def list_cmd(
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    include_superseded: Annotated[bool, typer.Option("--include-superseded",
        help="Show superseded entries (default: hide).")] = False,
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
) -> None:
    """List every wisdom entry (active by default)."""
    out = list_wisdom(
        project_root=project_root,
        include_superseded=include_superseded,
    )
    if json_out:
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    typer.echo("")
    typer.echo(f"Wisdom DB  ({out['entry_count']} entries"
               + (", incl. superseded" if include_superseded else "")
               + f")  {out['wisdom_file']}")
    typer.echo("-" * 60)
    for e in out["entries"]:
        typer.echo(f"  {e.get('id', '?'):<14}  {e.get('timestamp_utc', '')[:10]}  "
                   f"{e.get('scope', '?'):<8}  conf={e.get('confidence', 0):.2f}")
        typer.echo(f"      {e.get('insight', '')[:100]}"
                   + ("..." if len(e.get('insight', '')) > 100 else ""))
        if e.get("tags"):
            typer.echo(f"      tags: {', '.join(e['tags'])}")
        typer.echo("")


@app.command("recall")
def recall_cmd(
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    top_n: Annotated[int, typer.Option("--top-n",
        help="Max entries to return.")] = DEFAULT_RECALL_TOP_N,
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
) -> None:
    """Top-N repo-scoped wisdom (the recon-hook surface).

    Cheap fetch of what other agents learned about this repo. Use
    before any non-trivial change so you don't rediscover known issues.
    """
    out = query_wisdom(
        project_root=project_root,
        scope=WISDOM_SCOPE_REPO,
        top_n=top_n,
    )
    if json_out:
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    if not out["top_entries"]:
        typer.echo("No prior repo wisdom recorded. Start the institutional memory:")
        typer.echo("  forge wisdom record --insight \"<lesson>\" --scope repo --tags ...")
        return
    typer.echo("")
    typer.echo(f"Prior wisdom for this repo  ({out['results_returned']} entries)")
    typer.echo("=" * 60)
    for i, e in enumerate(out["top_entries"], 1):
        typer.echo(f"  {i}. {e.get('insight', '')}")
        meta_bits = []
        if e.get("tags"):
            meta_bits.append("tags: " + ", ".join(e["tags"]))
        if e.get("confidence") is not None:
            meta_bits.append(f"conf {e['confidence']:.2f}")
        if e.get("agent_name"):
            meta_bits.append(f"by {e['agent_name']}")
        if meta_bits:
            typer.echo(f"     ({' · '.join(meta_bits)})")
        typer.echo("")


@app.command("promote")
def promote_cmd(
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    min_corroboration: Annotated[int, typer.Option("--min-corroboration",
        help="Minimum wisdom entries per cluster to qualify as a draft.")] = 3,
    min_tag_overlap: Annotated[int, typer.Option("--min-tag-overlap",
        help="Minimum overlapping tags to join an existing cluster.")] = 1,
    write: Annotated[bool, typer.Option("--write",
        help="Write each draft to _private/research/recipe_drafts/.")] = False,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Cluster wisdom and synthesize draft recipes from corroborated themes.

    Pure clustering by tag overlap — no LLM. With ``--write``, persists
    each draft to ``_private/research/recipe_drafts/<name>.md`` so the
    Research agent (and humans) can pick up where this leaves off.
    """
    out = promote_wisdom(
        project_root=project_root,
        min_corroboration=min_corroboration,
        min_tag_overlap=min_tag_overlap,
        write_drafts=write,
    )
    if json_out:
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    typer.echo("")
    typer.echo(f"Wisdom → recipe promote  "
               f"(considered {out['entries_considered']}; "
               f"qualified clusters {out['qualified_clusters']})")
    typer.echo("=" * 60)
    if not out["drafts"]:
        typer.echo("  (no clusters reached --min-corroboration). Tag more "
                   "wisdom entries with shared themes, or lower the threshold.")
        return
    for i, d in enumerate(out["drafts"], 1):
        typer.echo(f"  {i}. {d['name']}  "
                   f"({d['entry_count']} entries: {', '.join(d['entry_ids'][:5])}"
                   + ("..." if len(d['entry_ids']) > 5 else "") + ")")
        typer.echo(f"     tags: {', '.join(d['tags'])}")
        typer.echo("")
    if out.get("written"):
        typer.secho(f"Wrote {len(out['written'])} draft(s) to "
                    f"{out.get('drafts_dir')}", fg="green")
