"""``forge welcome`` — first-call handshake for any agent.

Runs scout + certify + wire on the current repo and emits a single
structured response: real numbers, top strengths, top priorities,
the most-useful next call, and a multi-line narrative.

Example:
  forge welcome                            # text rendering
  forge welcome --json                     # JSON for MCP / piping
  forge welcome --since .atomadic-forge/certify.json   # diff vs prior scan
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a3_og_features.welcome_feature import welcome

COMMAND_NAME = "welcome"
COMMAND_HELP = (
    "First-call handshake — scout + certify + wire packaged into one "
    "response so the agent immediately knows the repo state, top "
    "strengths, top priorities, and the single most useful next call."
)

app = typer.Typer(no_args_is_help=False, help=COMMAND_HELP, invoke_without_command=True)


@app.callback()
def welcome_cmd(
    project_root: Annotated[Path, typer.Option("--project-root", "-p",
        help="Repo to scan.",
        exists=False, file_okay=False, dir_okay=True,
        resolve_path=True)] = Path("."),
    package: Annotated[str, typer.Option("--package",
        help="Package name for layout / certify checks.")] = "",
    since: Annotated[Path, typer.Option("--since",
        help="Path to a prior certify JSON for the since-last-scan diff.",
        exists=False, file_okay=True, dir_okay=False,
        resolve_path=True)] = None,  # type: ignore[assignment]
    skip_certify: Annotated[bool, typer.Option("--skip-certify",
        help="Skip the certify pass for a faster (partial) handshake.")] = False,
    force: Annotated[bool, typer.Option("--force",
        help="Bypass the scope guard (allow walking trees >max-files).")] = False,
    max_files: Annotated[int, typer.Option("--max-files",
        help="Scope guard threshold (default 5000).")] = 5000,
    json_out: Annotated[bool, typer.Option("--json",
        help="Emit machine-readable JSON.")] = False,
) -> None:
    """Run the welcome handshake."""
    out = welcome(
        project_root=project_root,
        package=package or None,
        since_receipt=since,
        skip_certify=skip_certify,
        force=force,
        max_files=max_files,
    )
    if out.get("verdict") == "REFUSE":
        bar = "=" * 64
        typer.echo(bar, err=True)
        typer.echo(out["narrative"], err=True)
        typer.echo(bar, err=True)
        if json_out:
            typer.echo(json.dumps(out, indent=2, default=str))
        raise typer.Exit(code=2)
    if json_out:
        typer.echo(json.dumps(out, indent=2, default=str))
        return
    # Text rendering — the narrative carries the message; we just
    # frame it with a separator so it's visually distinct in a
    # terminal log.
    bar = "=" * 64
    typer.echo(bar)
    typer.echo(out["narrative"])
    typer.echo(bar)
    if out.get("since_last_scan"):
        diff = out["since_last_scan"]
        delta = diff.get("score_delta")
        if delta is not None:
            sign = "+" if delta >= 0 else ""
            typer.echo(
                f"Since last scan: score {sign}{delta:g} "
                f"({diff.get('prior_score')} -> {diff.get('current_score')}); "
                f"violations now {diff.get('current_violations')}."
            )
