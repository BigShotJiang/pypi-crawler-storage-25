import time
import numpy as np
from p4p.nt import NTScalar
from p4p.nt import NTNDArray
from p4p.server import Server
from p4p.server.thread import SharedPV

# 1. Create PV with initial empty 2D array
#pv = SharedPV(nt=NTNDArray(), initial=np.zeros((10, 20), dtype='float32'))# that fails
pv = SharedPV(nt=NTNDArray())
pv.open(np.zeros((10, 20), dtype='float32'))

# 3. Simulate updating data
with Server(providers=[{'my:multidim:array': pv}]):
    while True:
        new_data = np.random.randint(0, 255, (10, 30), dtype='uint8')
        pv.post(new_data)
        print("Posted new 10x30 array")
        time.sleep(1)
