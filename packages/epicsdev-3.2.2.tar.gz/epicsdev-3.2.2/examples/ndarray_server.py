# that fails with RuntimeError: Only 1-d array can be assigned
import time
import numpy as np
from p4p.nt import NTScalar
from p4p.server import Server
from p4p.server.thread import SharedPV

# 1. Create a multidimensional NumPy array
# Example: a 3x3 matrix of zeros
initial_data = np.zeros((3, 3))

# 2. Initialize the SharedPV
# Use 'ad' for an array of doubles
pv = SharedPV(
    nt=NTScalar('ad'), 
    #initial=initial_data.flatten()# that works
    #initial=initial_data# that does not work
)
pv.open(initial_data)

# 4. Start the server
# The provider map links the EPICS PV name to the SharedPV object
with Server(providers=[{'my:multidim:array': pv}]):
    while True:
        time.sleep(1)
        new_data = np.random.randint(0, 255, (10, 30), dtype='uint8')
        pv.post(new_data)
