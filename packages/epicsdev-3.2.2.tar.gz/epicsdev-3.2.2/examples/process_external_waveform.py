import time
import numpy as np
from p4p.server.thread import SharedPV
from p4p.server import Server
from p4p.nt import NTScalar
from p4p.client.thread import Context
ctxt = Context('pva')

# create output PVs, if needed
pv = SharedPV(nt=NTScalar('ah'), initial=[0])# int16 array

# callback function to double the input array
def callback(V):
	ar = np.array(V)
	pv.post(np.array(V)*2)

callback = ctxt.monitor('epicsDev0:c01Waveform', callback)
with Server(providers=[{'my:array': pv}]):
	while True:
		# do something else or sleep.
		time.sleep(1)
