"""
Geode-Explicit Python binding for BRep
"""
from __future__ import annotations
import collections.abc
import geode_explicit.lib64.geode_explicit_py_common
import opengeode.lib64.opengeode_py_mesh
import opengeode.lib64.opengeode_py_model
import typing
__all__: list[str] = ['BRepExplicitModeler', 'BRepExplicitModelerErrorHandlingMode', 'BRepExplicitModelerParameters', 'BRepVolumicInserter', 'ExplicitBRepLibrary']
class BRepExplicitModeler:
    def __init__(self, arg0: opengeode.lib64.opengeode_py_model.BRep, arg1: BRepExplicitModelerParameters) -> None:
        ...
    def add_curve(self, arg0: opengeode.lib64.opengeode_py_mesh.EdgedCurve3D) -> None:
        ...
    def add_point_set(self, arg0: opengeode.lib64.opengeode_py_mesh.PointSet3D) -> None:
        ...
    def add_triangulated_surface(self, arg0: opengeode.lib64.opengeode_py_mesh.TriangulatedSurface3D) -> None:
        ...
    def process(self) -> geode_explicit.lib64.geode_explicit_py_common.MeshElements:
        ...
class BRepExplicitModelerErrorHandlingMode:
    """
    Members:
    
      strict
    
      best_effort
    """
    __members__: typing.ClassVar[dict[str, BRepExplicitModelerErrorHandlingMode]]  # value = {'strict': <BRepExplicitModelerErrorHandlingMode.strict: 0>, 'best_effort': <BRepExplicitModelerErrorHandlingMode.best_effort: 1>}
    best_effort: typing.ClassVar[BRepExplicitModelerErrorHandlingMode]  # value = <BRepExplicitModelerErrorHandlingMode.best_effort: 1>
    strict: typing.ClassVar[BRepExplicitModelerErrorHandlingMode]  # value = <BRepExplicitModelerErrorHandlingMode.strict: 0>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class BRepExplicitModelerParameters:
    build_mode: BRepExplicitModelerErrorHandlingMode
    connectivity_parallelization: bool
    geometrical_parallelization: bool
    remove_outside_block_elements: bool
    def __init__(self) -> None:
        ...
class BRepVolumicInserter:
    def __init__(self, arg0: opengeode.lib64.opengeode_py_model.BRep) -> None:
        ...
    def add_scalar_isovalues(self, arg0: str, arg1: collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex]) -> None:
        ...
    def build(self) -> None:
        ...
class ExplicitBRepLibrary:
    @staticmethod
    def initialize() -> None:
        ...
