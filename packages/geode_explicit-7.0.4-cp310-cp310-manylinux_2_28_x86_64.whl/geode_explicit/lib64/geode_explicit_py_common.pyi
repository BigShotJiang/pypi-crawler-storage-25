"""
Geode-Explicit Python binding for Common
"""
from __future__ import annotations
import opengeode.lib64.opengeode_py_basic
import typing
__all__: list[str] = ['ExplicitCommonLibrary', 'MeshElements', 'TypedMeshElements']
class ExplicitCommonLibrary:
    @staticmethod
    def initialize() -> None:
        ...
class MeshElements:
    def __init__(self) -> None:
        ...
    def contains_edge(self, arg0: opengeode.lib64.opengeode_py_basic.uuid, arg1: typing.SupportsInt | typing.SupportsIndex) -> bool:
        ...
    def contains_point(self, arg0: opengeode.lib64.opengeode_py_basic.uuid, arg1: typing.SupportsInt | typing.SupportsIndex) -> bool:
        ...
    def contains_polygon(self, arg0: opengeode.lib64.opengeode_py_basic.uuid, arg1: typing.SupportsInt | typing.SupportsIndex) -> bool:
        ...
    def empty(self) -> bool:
        ...
    def size(self) -> int:
        ...
class TypedMeshElements:
    pass
