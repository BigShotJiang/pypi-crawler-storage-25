"""Tests for bonsai_core Projector (UMAP dimensionality reduction).

These tests are self-contained and require no external services or API keys.
They exercise the Projector class for 2D and 3D projection, caching,
edge cases (small/empty/single-point datasets), and error handling.
"""

import numpy as np
import pytest

from bonsai_core.projection import Projector


class TestProjectorFit2D:
    """Tests for fit_2d: fitting a UMAP model for 2D projection."""

    def test_output_shape(self, sample_embeddings, tmp_cache_path):
        """fit_2d returns an array of shape (n, 2)."""
        proj = Projector(cache_path=tmp_cache_path)
        coords = proj.fit_2d(sample_embeddings)
        assert coords.shape == (sample_embeddings.shape[0], 2)

    def test_output_is_finite(self, sample_embeddings, tmp_cache_path):
        """fit_2d output contains no NaN or infinite values."""
        proj = Projector(cache_path=tmp_cache_path)
        coords = proj.fit_2d(sample_embeddings)
        assert np.all(np.isfinite(coords))

    def test_custom_parameters(self, sample_embeddings, tmp_cache_path):
        """fit_2d accepts custom n_neighbors and min_dist."""
        proj = Projector(cache_path=tmp_cache_path)
        coords = proj.fit_2d(sample_embeddings, n_neighbors=5, min_dist=0.5)
        assert coords.shape == (sample_embeddings.shape[0], 2)

    def test_stores_model(self, sample_embeddings, tmp_cache_path):
        """After fit_2d, the internal model_2d attribute is set."""
        proj = Projector(cache_path=tmp_cache_path)
        proj.fit_2d(sample_embeddings)
        assert proj.model_2d is not None


class TestProjectorFit3D:
    """Tests for fit_3d: fitting a UMAP model for 3D projection."""

    def test_output_shape(self, sample_embeddings, tmp_cache_path):
        """fit_3d returns an array of shape (n, 3)."""
        proj = Projector(cache_path=tmp_cache_path)
        coords = proj.fit_3d(sample_embeddings)
        assert coords.shape == (sample_embeddings.shape[0], 3)

    def test_output_is_finite(self, sample_embeddings, tmp_cache_path):
        """fit_3d output contains no NaN or infinite values."""
        proj = Projector(cache_path=tmp_cache_path)
        coords = proj.fit_3d(sample_embeddings)
        assert np.all(np.isfinite(coords))

    def test_stores_model(self, sample_embeddings, tmp_cache_path):
        """After fit_3d, the internal model_3d attribute is set."""
        proj = Projector(cache_path=tmp_cache_path)
        proj.fit_3d(sample_embeddings)
        assert proj.model_3d is not None


class TestProjectorTransform:
    """Tests for transform_2d: projecting new points with a fitted model."""

    def test_transform_subset(self, sample_embeddings, tmp_cache_path):
        """transform_2d projects a subset using the fitted model."""
        proj = Projector(cache_path=tmp_cache_path)
        proj.fit_2d(sample_embeddings)

        new_points = sample_embeddings[:5]
        coords = proj.transform_2d(new_points)
        assert coords.shape == (5, 2)

    def test_transform_single_point(self, sample_embeddings, tmp_cache_path):
        """transform_2d can project a single point."""
        proj = Projector(cache_path=tmp_cache_path)
        proj.fit_2d(sample_embeddings)

        single = sample_embeddings[:1]
        coords = proj.transform_2d(single)
        assert coords.shape == (1, 2)

    def test_transform_output_is_finite(self, sample_embeddings, tmp_cache_path):
        """transform_2d output contains no NaN or infinite values."""
        proj = Projector(cache_path=tmp_cache_path)
        proj.fit_2d(sample_embeddings)

        coords = proj.transform_2d(sample_embeddings[:10])
        assert np.all(np.isfinite(coords))


class TestProjectorCache:
    """Tests for UMAP model persistence (save/load from disk)."""

    def test_cache_persistence(self, sample_embeddings, tmp_cache_path):
        """Fitted model saves to disk and a new Projector can load it."""
        proj1 = Projector(cache_path=tmp_cache_path)
        proj1.fit_2d(sample_embeddings)

        # A new Projector instance should load the cached model
        proj2 = Projector(cache_path=tmp_cache_path)
        coords = proj2.transform_2d(sample_embeddings[:5])
        assert coords.shape == (5, 2)

    def test_cache_file_created(self, sample_embeddings, tmp_cache_path):
        """fit_2d creates a cache file on disk."""
        from pathlib import Path

        proj = Projector(cache_path=tmp_cache_path)
        proj.fit_2d(sample_embeddings)

        cache_file = Path(tmp_cache_path) / "umap_2d.pkl"
        assert cache_file.exists()

    def test_3d_cache_file_created(self, sample_embeddings, tmp_cache_path):
        """fit_3d creates a separate cache file on disk."""
        from pathlib import Path

        proj = Projector(cache_path=tmp_cache_path)
        proj.fit_3d(sample_embeddings)

        cache_file = Path(tmp_cache_path) / "umap_3d.pkl"
        assert cache_file.exists()

    def test_no_cached_model_raises(self, tmp_cache_path):
        """transform_2d raises FileNotFoundError if no model is cached."""
        proj = Projector(cache_path=tmp_cache_path + "_nocache")
        with pytest.raises(FileNotFoundError):
            proj.transform_2d(np.random.randn(5, 384).astype(np.float32))

    def test_no_cached_3d_model_raises(self, tmp_cache_path):
        """transform_3d raises FileNotFoundError if no model is cached."""
        proj = Projector(cache_path=tmp_cache_path + "_nocache3d")
        with pytest.raises(FileNotFoundError):
            proj.transform_3d(np.random.randn(5, 384).astype(np.float32))


class TestProjectorEdgeCases:
    """Tests for edge cases: small, single-point, and empty datasets."""

    def test_small_dataset(self, tmp_cache_path):
        """Handles datasets smaller than default n_neighbors (15)."""
        proj = Projector(cache_path=tmp_cache_path)
        small = np.random.randn(3, 384).astype(np.float32)
        coords = proj.fit_2d(small)
        assert coords.shape == (3, 2)

    def test_single_point(self, tmp_cache_path):
        """Handles single point gracefully (returns finite coordinates)."""
        proj = Projector(cache_path=tmp_cache_path)
        single = np.random.randn(1, 384).astype(np.float32)
        coords = proj.fit_2d(single)
        assert coords.shape == (1, 2)
        assert np.all(np.isfinite(coords))

    def test_empty_dataset(self, tmp_cache_path):
        """Handles empty dataset (returns empty array with correct shape)."""
        proj = Projector(cache_path=tmp_cache_path)
        empty = np.empty((0, 384), dtype=np.float32)
        coords = proj.fit_2d(empty)
        assert coords.shape == (0, 2)

    def test_single_point_3d(self, tmp_cache_path):
        """Single point in 3D returns finite coordinates."""
        proj = Projector(cache_path=tmp_cache_path)
        single = np.random.randn(1, 384).astype(np.float32)
        coords = proj.fit_3d(single)
        assert coords.shape == (1, 3)
        assert np.all(np.isfinite(coords))

    def test_empty_dataset_3d(self, tmp_cache_path):
        """Empty dataset in 3D returns empty array with correct shape."""
        proj = Projector(cache_path=tmp_cache_path)
        empty = np.empty((0, 384), dtype=np.float32)
        coords = proj.fit_3d(empty)
        assert coords.shape == (0, 3)

    def test_two_points(self, tmp_cache_path):
        """Two-point dataset can be projected (minimum for UMAP)."""
        proj = Projector(cache_path=tmp_cache_path)
        two = np.random.randn(2, 384).astype(np.float32)
        coords = proj.fit_2d(two)
        assert coords.shape == (2, 2)

    def test_cache_directory_created(self, tmp_path):
        """Projector creates the cache directory if it does not exist."""
        from pathlib import Path

        new_path = str(tmp_path / "deep" / "nested" / "cache")
        proj = Projector(cache_path=new_path)
        assert Path(new_path).exists()
