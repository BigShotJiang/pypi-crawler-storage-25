from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from types import SimpleNamespace

from bonsai_core.conflicts import ConflictPair, UpdateTypeResult
from bonsai_core.memory import MemoryStore
from bonsai_core.models import Memory


class _FakeAdapter:
    def __init__(self, existing: Memory) -> None:
        self.existing = existing
        self._memories: dict[str, Memory] = {existing.id: existing}
        self.updated: list[tuple[str, dict]] = []

    def search_with_distances(self, query: str, limit: int = 5):
        return [(self.existing, 0.2)]

    def add(self, memory: Memory) -> str:
        self._memories[memory.id] = memory
        return memory.id

    def get(self, memory_id: str) -> Memory:
        return self._memories[memory_id]

    def update(self, memory_id: str, fact: str | None = None, metadata: dict | None = None, **_: object) -> None:
        if fact is not None and memory_id in self._memories:
            mem = self._memories[memory_id]
            self._memories[memory_id] = mem.model_copy(update={"fact": fact})
        if metadata and memory_id in self._memories:
            mem = self._memories[memory_id]
            updates = {}
            for key, value in metadata.items():
                if hasattr(mem, key):
                    updates[key] = value
            if updates:
                self._memories[memory_id] = mem.model_copy(update=updates)
        self.updated.append((memory_id, metadata or {}))


def _make_store(tmp_path: Path, existing: Memory) -> MemoryStore:
    store = MemoryStore.__new__(MemoryStore)
    store.path = str(tmp_path)
    store.collection_name = "memories"
    store.adapter = _FakeAdapter(existing)
    store._conflicts_file = tmp_path / "pending_conflicts.json"
    store._pending_conflicts = {}
    store._conflict_decisions_file = tmp_path / "conflict_decisions.json"
    store._conflict_decisions = {}
    store._events_file = tmp_path / "memory_events.jsonl"
    return store


def _patch_extraction(monkeypatch):
    extracted = SimpleNamespace(
        facts=[
            SimpleNamespace(
                fact="Jon joined OpenAI as Head of Infrastructure",
                source_span="Jon joined OpenAI as Head of Infrastructure",
                importance=8,
            )
        ]
    )
    monkeypatch.setattr("bonsai_core.memory.extract_facts", lambda _: extracted)
    monkeypatch.setattr("bonsai_core.memory.locate_span", lambda *_: (0, 10))


def test_auto_applies_high_confidence_update_supersede(monkeypatch, tmp_path):
    """When classify_update_type returns supersede, old memory gets rewritten."""
    existing = Memory(
        fact="Jon works at Google",
        user_id="default",
        created_at=datetime.now(UTC),
        last_accessed_at=datetime.now(UTC),
    )
    store = _make_store(tmp_path, existing)
    _patch_extraction(monkeypatch)

    def _batch(pairs, cache=None, model=None):
        return [
            ConflictPair(
                new_fact_id=pairs[0].new_fact_id,
                existing_fact_id=existing.id,
                label="update",
                confidence=0.95,
                reason="Same person, job change",
            )
        ]

    monkeypatch.setattr("bonsai_core.memory.batch_conflict_detection", _batch)
    monkeypatch.setattr(
        "bonsai_core.memory.classify_update_type",
        lambda *_a, **_kw: UpdateTypeResult(
            update_type="supersede", confidence=0.9, reason="job change"
        ),
    )
    monkeypatch.setattr(
        "bonsai_core.memory.rewrite_to_past_tense",
        lambda text, **_kw: f"[Past] {text}",
    )
    result = store.add("Episode text", user_id="default")

    assert result["pending_count"] == 0
    assert result["added_count"] == 1
    assert any(mid == existing.id for mid, _ in store.adapter.updated)
    events = store.list_memory_events()
    assert any(e["type"] == "memory.supersede_rewrite_applied" for e in events)


def test_auto_applies_high_confidence_update_inline(monkeypatch, tmp_path):
    """When classify_update_type returns inline, memory is updated in place."""
    existing = Memory(
        fact="Jon has 1000 followers",
        user_id="default",
        created_at=datetime.now(UTC),
        last_accessed_at=datetime.now(UTC),
    )
    store = _make_store(tmp_path, existing)

    extracted = SimpleNamespace(
        facts=[
            SimpleNamespace(
                fact="Jon has 5000 followers",
                source_span="Jon has 5000 followers",
                importance=5,
            )
        ]
    )
    monkeypatch.setattr("bonsai_core.memory.extract_facts", lambda _: extracted)
    monkeypatch.setattr("bonsai_core.memory.locate_span", lambda *_: (0, 10))

    def _batch(pairs, cache=None, model=None):
        return [
            ConflictPair(
                new_fact_id=pairs[0].new_fact_id,
                existing_fact_id=existing.id,
                label="update",
                confidence=0.95,
                reason="Same metric, updated value",
            )
        ]

    monkeypatch.setattr("bonsai_core.memory.batch_conflict_detection", _batch)
    monkeypatch.setattr(
        "bonsai_core.memory.classify_update_type",
        lambda *_a, **_kw: UpdateTypeResult(
            update_type="inline", confidence=0.95, reason="same fact updated value"
        ),
    )
    result = store.add("Episode text", user_id="default")

    assert result["pending_count"] == 0
    assert result["added_count"] == 1
    # The existing memory should have been updated in place
    assert any(mid == existing.id for mid, _ in store.adapter.updated)
    events = store.list_memory_events()
    assert any(e["type"] == "memory.inline_update_applied" for e in events)


def test_routes_contradiction_to_pending(monkeypatch, tmp_path):
    existing = Memory(
        fact="Jon works at Google",
        user_id="default",
        created_at=datetime.now(UTC),
        last_accessed_at=datetime.now(UTC),
    )
    store = _make_store(tmp_path, existing)
    _patch_extraction(monkeypatch)

    def _batch(pairs, cache=None, model=None):
        return [
            ConflictPair(
                new_fact_id=pairs[0].new_fact_id,
                existing_fact_id=existing.id,
                label="contradiction",
                confidence=0.9,
                reason="Incompatible current-employer claims",
            )
        ]

    monkeypatch.setattr("bonsai_core.memory.batch_conflict_detection", _batch)
    result = store.add("Episode text", user_id="default")

    assert result["pending_count"] == 1
    assert result["added_count"] == 0
    conflict = result["pending_conflicts"][0]
    assert conflict["label"] == "contradiction"
    events = store.list_memory_events(event_types=["memory.conflict_created"])
    assert len(events) == 1
