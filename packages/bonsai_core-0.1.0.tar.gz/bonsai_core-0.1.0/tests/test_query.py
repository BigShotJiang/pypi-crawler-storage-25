"""Tests for bonsai_core NL Query Engine.

Validates Pydantic models, filter builders, comparison logic, helper
extractors, local filter extraction, and cross-encoder re-ranking pipeline.
"""

import pytest

from bonsai_core.query import MetadataFilter, ParsedQuery, QueryEngine


# ── Pure-logic tests (no API key needed) ───────────────────────────


class TestParsedQuery:
    """Tests for the ParsedQuery model."""

    def test_defaults(self):
        """ParsedQuery has sensible defaults for all optional fields."""
        pq = ParsedQuery()
        assert pq.semantic_query is None
        assert pq.metadata_filters == []
        assert pq.document_contains is None
        assert pq.limit == 50

    def test_custom_values(self):
        """ParsedQuery accepts custom values for every field."""
        filters = [MetadataFilter(field="source", operator="$eq", value="linkedin")]
        pq = ParsedQuery(
            semantic_query="Google engineer",
            metadata_filters=filters,
            document_contains="infrastructure",
            limit=10,
        )
        assert pq.semantic_query == "Google engineer"
        assert len(pq.metadata_filters) == 1
        assert pq.metadata_filters[0].field == "source"
        assert pq.document_contains == "infrastructure"
        assert pq.limit == 10

    def test_limit_below_minimum_raises(self):
        """Limit below 1 raises a validation error."""
        with pytest.raises(Exception):
            ParsedQuery(limit=0)

    def test_limit_above_maximum_raises(self):
        """Limit above 200 raises a validation error."""
        with pytest.raises(Exception):
            ParsedQuery(limit=201)

    def test_serialization_roundtrip(self):
        """ParsedQuery serializes to dict and deserializes back."""
        filters = [
            MetadataFilter(field="importance", operator="$gte", value=0.7),
        ]
        pq = ParsedQuery(
            semantic_query="ML memories",
            metadata_filters=filters,
            document_contains="neural",
            limit=25,
        )
        d = pq.model_dump()
        restored = ParsedQuery.model_validate(d)
        assert restored.semantic_query == pq.semantic_query
        assert len(restored.metadata_filters) == 1
        assert restored.metadata_filters[0].field == "importance"
        assert restored.metadata_filters[0].operator == "$gte"
        assert restored.metadata_filters[0].value == 0.7
        assert restored.document_contains == pq.document_contains
        assert restored.limit == pq.limit


class TestMetadataFilter:
    """Tests for the MetadataFilter model."""

    def test_creation_with_operators(self):
        """MetadataFilter can be created with all supported operators."""
        operators = ["$eq", "$ne", "$gt", "$gte", "$lt", "$lte", "$in", "$nin"]
        for op in operators:
            mf = MetadataFilter(field="importance", operator=op, value=0.5)
            assert mf.operator == op
            assert mf.field == "importance"
            assert mf.value == 0.5

    def test_serialization_roundtrip(self):
        """MetadataFilter serializes to dict and deserializes back."""
        mf = MetadataFilter(field="source", operator="$eq", value="linkedin")
        d = mf.model_dump()
        restored = MetadataFilter.model_validate(d)
        assert restored.field == mf.field
        assert restored.operator == mf.operator
        assert restored.value == mf.value


class TestQueryEngineFilterLogic:
    """Tests for QueryEngine filter builders, comparisons, and extractors.

    These tests exercise static/class methods and instance methods that do not
    use ``self``, so no store or reranker is required.
    """

    # -- helper: create an uninitialised engine for instance method tests --

    @staticmethod
    def _make_engine():
        """Create an uninitialised QueryEngine (skips __init__)."""
        return object.__new__(QueryEngine)

    # -- _build_where ---------------------------------------------------

    def test_build_where_no_filters(self):
        """_build_where returns None when there are no metadata filters."""
        engine = self._make_engine()
        parsed = ParsedQuery(metadata_filters=[])
        assert engine._build_where(parsed) is None

    def test_build_where_single_filter(self):
        """_build_where returns a single condition dict for one filter."""
        engine = self._make_engine()
        parsed = ParsedQuery(
            metadata_filters=[
                MetadataFilter(field="source", operator="$eq", value="linkedin"),
            ]
        )
        result = engine._build_where(parsed)
        assert result == {"source": {"$eq": "linkedin"}}

    def test_build_where_multiple_filters(self):
        """_build_where wraps multiple conditions under $and."""
        engine = self._make_engine()
        parsed = ParsedQuery(
            metadata_filters=[
                MetadataFilter(field="source", operator="$eq", value="linkedin"),
                MetadataFilter(field="importance", operator="$gte", value=0.7),
            ]
        )
        result = engine._build_where(parsed)
        assert "$and" in result
        assert len(result["$and"]) == 2
        assert result["$and"][0] == {"source": {"$eq": "linkedin"}}
        assert result["$and"][1] == {"importance": {"$gte": 0.7}}

    # -- _build_where_document ------------------------------------------

    def test_build_where_document_none(self):
        """_build_where_document returns None when document_contains is None."""
        engine = self._make_engine()
        parsed = ParsedQuery(document_contains=None)
        assert engine._build_where_document(parsed) is None

    def test_build_where_document_with_substring(self):
        """_build_where_document returns a $contains clause for a substring."""
        engine = self._make_engine()
        parsed = ParsedQuery(document_contains="infrastructure")
        result = engine._build_where_document(parsed)
        assert result == {"$contains": "infrastructure"}

    # -- _compare -------------------------------------------------------

    def test_compare_all_operators(self):
        """_compare evaluates all eight operators correctly."""
        cmp = QueryEngine._compare

        # $eq
        assert cmp(5, "$eq", 5) is True
        assert cmp(5, "$eq", 6) is False

        # $ne
        assert cmp(5, "$ne", 6) is True
        assert cmp(5, "$ne", 5) is False

        # $gt
        assert cmp(10, "$gt", 5) is True
        assert cmp(5, "$gt", 10) is False
        assert cmp(5, "$gt", 5) is False

        # $gte
        assert cmp(5, "$gte", 5) is True
        assert cmp(6, "$gte", 5) is True
        assert cmp(4, "$gte", 5) is False

        # $lt
        assert cmp(3, "$lt", 5) is True
        assert cmp(5, "$lt", 5) is False
        assert cmp(7, "$lt", 5) is False

        # $lte
        assert cmp(5, "$lte", 5) is True
        assert cmp(4, "$lte", 5) is True
        assert cmp(6, "$lte", 5) is False

        # $in (scalar in list)
        assert cmp("a", "$in", ["a", "b", "c"]) is True
        assert cmp("d", "$in", ["a", "b", "c"]) is False

        # $nin (scalar not in list)
        assert cmp("d", "$nin", ["a", "b", "c"]) is True
        assert cmp("a", "$nin", ["a", "b", "c"]) is False

    def test_compare_in_with_list_actual(self):
        """_compare handles $in/$nin when actual is a list (set intersection)."""
        cmp = QueryEngine._compare

        # actual is a list, target is a list: any overlap = True for $in
        assert cmp(["a", "b"], "$in", ["b", "c"]) is True
        assert cmp(["a", "b"], "$in", ["c", "d"]) is False

        # $nin: no overlap = True
        assert cmp(["a", "b"], "$nin", ["c", "d"]) is True
        assert cmp(["a", "b"], "$nin", ["b", "c"]) is False

    def test_compare_none_actual(self):
        """_compare with None actual satisfies only $ne and $nin."""
        cmp = QueryEngine._compare

        assert cmp(None, "$eq", 5) is False
        assert cmp(None, "$ne", 5) is True
        assert cmp(None, "$gt", 5) is False
        assert cmp(None, "$gte", 5) is False
        assert cmp(None, "$lt", 5) is False
        assert cmp(None, "$lte", 5) is False
        assert cmp(None, "$in", [5]) is False
        assert cmp(None, "$nin", [5]) is True

    def test_compare_unknown_operator_returns_false(self):
        """_compare returns False for an unrecognised operator."""
        assert QueryEngine._compare(5, "$unknown", 5) is False

    # -- _matches_where -------------------------------------------------

    def test_matches_where_single_condition(self):
        """_matches_where matches a single {field: {op: value}} condition."""
        memory = {"metadata": {"source": "linkedin", "importance": 0.9}}

        where = {"source": {"$eq": "linkedin"}}
        assert QueryEngine._matches_where(memory, where) is True

        where = {"source": {"$eq": "twitter"}}
        assert QueryEngine._matches_where(memory, where) is False

    def test_matches_where_and_combinator(self):
        """_matches_where handles $and — all conditions must match."""
        memory = {"metadata": {"source": "linkedin", "importance": 0.9}}

        where = {
            "$and": [
                {"source": {"$eq": "linkedin"}},
                {"importance": {"$gte": 0.5}},
            ]
        }
        assert QueryEngine._matches_where(memory, where) is True

        where_fail = {
            "$and": [
                {"source": {"$eq": "linkedin"}},
                {"importance": {"$gte": 0.95}},
            ]
        }
        assert QueryEngine._matches_where(memory, where_fail) is False

    def test_matches_where_or_combinator(self):
        """_matches_where handles $or — at least one condition must match."""
        memory = {"metadata": {"source": "linkedin", "importance": 0.3}}

        where = {
            "$or": [
                {"source": {"$eq": "twitter"}},
                {"source": {"$eq": "linkedin"}},
            ]
        }
        assert QueryEngine._matches_where(memory, where) is True

        where_fail = {
            "$or": [
                {"source": {"$eq": "twitter"}},
                {"source": {"$eq": "facebook"}},
            ]
        }
        assert QueryEngine._matches_where(memory, where_fail) is False

    def test_matches_where_shorthand_equality(self):
        """_matches_where treats {field: value} as shorthand for $eq."""
        memory = {"metadata": {"source": "linkedin"}}

        assert QueryEngine._matches_where(memory, {"source": "linkedin"}) is True
        assert QueryEngine._matches_where(memory, {"source": "twitter"}) is False

    # -- _apply_where_filter -------------------------------------------

    def test_apply_where_filter(self):
        """_apply_where_filter keeps only matching memories."""
        results = [
            {"metadata": {"source": "linkedin", "importance": 0.9}},
            {"metadata": {"source": "twitter", "importance": 0.4}},
            {"metadata": {"source": "linkedin", "importance": 0.6}},
        ]
        where = {"source": {"$eq": "linkedin"}}
        filtered = QueryEngine._apply_where_filter(results, where)
        assert len(filtered) == 2
        assert all(
            r["metadata"]["source"] == "linkedin" for r in filtered
        )

    # -- _extract_id ----------------------------------------------------

    def test_extract_id_from_id_key(self):
        """_extract_id returns value of 'id' key when present."""
        assert QueryEngine._extract_id({"id": "abc-123"}) == "abc-123"

    def test_extract_id_from_memory_id_key(self):
        """_extract_id falls back to 'memory_id' when 'id' is absent."""
        assert QueryEngine._extract_id({"memory_id": "def-456"}) == "def-456"

    def test_extract_id_missing_returns_empty(self):
        """_extract_id returns empty string when neither key is present."""
        assert QueryEngine._extract_id({"data": "something"}) == ""

    # -- _extract_text --------------------------------------------------

    def test_extract_text_memory_key(self):
        """_extract_text returns value of 'memory' key when present."""
        assert QueryEngine._extract_text({"memory": "hello"}) == "hello"

    def test_extract_text_text_key(self):
        """_extract_text falls back to 'text' key."""
        assert QueryEngine._extract_text({"text": "world"}) == "world"

    def test_extract_text_data_key(self):
        """_extract_text falls back to 'data' key."""
        assert QueryEngine._extract_text({"data": "content"}) == "content"

    def test_extract_text_missing_returns_empty(self):
        """_extract_text returns empty string when no recognised key is present."""
        assert QueryEngine._extract_text({"id": "abc"}) == ""

    # -- _extract_metadata ----------------------------------------------

    def test_extract_metadata_nested(self):
        """_extract_metadata returns the nested 'metadata' dict."""
        memory = {"id": "1", "metadata": {"source": "linkedin"}}
        assert QueryEngine._extract_metadata(memory) == {"source": "linkedin"}

    def test_extract_metadata_top_level(self):
        """_extract_metadata returns the top-level dict when no nested metadata."""
        memory = {"source": "linkedin", "importance": 0.5}
        result = QueryEngine._extract_metadata(memory)
        assert result is memory


# ── Local filter extraction tests ──────────────────────────────────


class TestExtractFilters:
    """Tests for the regex-based local filter extraction."""

    def test_plain_query(self):
        """A plain query without special patterns becomes semantic_query."""
        parsed = QueryEngine._extract_filters("memories about Google")
        assert parsed.semantic_query == "memories about Google"
        assert parsed.metadata_filters == []
        assert parsed.document_contains is None
        assert parsed.limit == 50

    def test_from_source(self):
        """'from <source>' extracts a source metadata filter."""
        parsed = QueryEngine._extract_filters("memories from linkedin about ML")
        assert len(parsed.metadata_filters) == 1
        assert parsed.metadata_filters[0].field == "source"
        assert parsed.metadata_filters[0].operator == "$eq"
        assert parsed.metadata_filters[0].value == "linkedin"
        # "from linkedin" removed from semantic query
        assert "from" not in (parsed.semantic_query or "").lower().split()

    def test_importance(self):
        """'important' extracts an importance >= 0.7 filter."""
        parsed = QueryEngine._extract_filters("important memories about marketing")
        assert any(
            f.field == "importance" and f.operator == "$gte" and f.value == 0.7
            for f in parsed.metadata_filters
        )

    def test_quoted_substring(self):
        """Quoted phrase extracts document_contains."""
        parsed = QueryEngine._extract_filters('memories containing "neural network"')
        assert parsed.document_contains == "neural network"

    def test_tag_filter(self):
        """'tag:<tag>' extracts a tags filter."""
        parsed = QueryEngine._extract_filters("tag:engineering contacts")
        assert any(
            f.field == "tags" and f.operator == "$in" and "engineering" in f.value
            for f in parsed.metadata_filters
        )

    def test_limit(self):
        """'top N' extracts a custom limit."""
        parsed = QueryEngine._extract_filters("top 10 memories about AI")
        assert parsed.limit == 10

    def test_combined(self):
        """Multiple patterns in one query are all extracted."""
        parsed = QueryEngine._extract_filters(
            'important memories from linkedin "Google" top 5'
        )
        fields = {f.field for f in parsed.metadata_filters}
        assert "source" in fields
        assert "importance" in fields
        assert parsed.document_contains == "Google"
        assert parsed.limit == 5


# ── Similarity cutoff tests ───────────────────────────────────────


class TestRelevanceCutoff:
    """Tests for the similarity floor + gap detection in NativeChromaAdapter."""

    def test_similarity_floor_filters_low_scores(self):
        """Results below the similarity floor are dropped."""
        from bonsai_core.storage.native import _apply_relevance_cutoff

        # Mock pairs: (item, cosine_distance)
        pairs = [("a", 0.2), ("b", 0.5), ("c", 0.8), ("d", 0.95)]
        # floor=0.5 means max_distance=0.5
        result = _apply_relevance_cutoff(pairs, similarity_floor=0.5, gap_threshold=1.0)
        assert len(result) == 2
        assert result[0][0] == "a"
        assert result[1][0] == "b"

    def test_gap_detection_truncates(self):
        """Results are cut at the largest score gap."""
        from bonsai_core.storage.native import _apply_relevance_cutoff

        # Tight cluster at 0.1-0.2, then big gap to 0.6-0.65
        pairs = [("a", 0.1), ("b", 0.15), ("c", 0.2), ("d", 0.6), ("e", 0.65)]
        result = _apply_relevance_cutoff(pairs, similarity_floor=0.0, gap_threshold=0.1)
        # Should cut after "c" (gap 0.4 > threshold 0.1)
        assert len(result) == 3
        assert [r[0] for r in result] == ["a", "b", "c"]

    def test_no_gap_above_threshold_keeps_all(self):
        """When no gap exceeds the threshold, all results are kept."""
        from bonsai_core.storage.native import _apply_relevance_cutoff

        pairs = [("a", 0.1), ("b", 0.12), ("c", 0.14), ("d", 0.16)]
        result = _apply_relevance_cutoff(pairs, similarity_floor=0.0, gap_threshold=0.1)
        assert len(result) == 4

    def test_fewer_than_three_skips_gap_detection(self):
        """Gap detection is skipped with fewer than 3 results."""
        from bonsai_core.storage.native import _apply_relevance_cutoff

        pairs = [("a", 0.1), ("b", 0.9)]
        result = _apply_relevance_cutoff(pairs, similarity_floor=0.0, gap_threshold=0.05)
        assert len(result) == 2
