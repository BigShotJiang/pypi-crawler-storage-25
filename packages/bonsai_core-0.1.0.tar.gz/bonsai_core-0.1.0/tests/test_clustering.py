"""Tests for bonsai_core Clusterer (HDBSCAN clustering on 2D coordinates).

These tests are self-contained and require no external services or API keys.
They exercise the Clusterer class for fitting, cluster info extraction,
noise detection, and edge cases (small/empty datasets).
"""

import numpy as np
import pytest

from bonsai_core.clustering import Clusterer
from bonsai_core.models import ClusterInfo


class TestClustererFit:
    """Tests for Clusterer.fit: density-based clustering."""

    def test_returns_labels_array(self, sample_coords_2d):
        """fit returns an integer labels array of the correct shape."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        assert labels.shape == (sample_coords_2d.shape[0],)
        assert labels.dtype in [np.int32, np.int64, np.intp]

    def test_finds_clusters(self, sample_coords_2d):
        """Finds at least 2 clusters in well-separated data."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        unique_labels = set(labels.tolist()) - {-1}
        # 3 well-separated clusters; HDBSCAN should find at least 2
        assert len(unique_labels) >= 2

    def test_stores_labels(self, sample_coords_2d):
        """fit stores labels on the Clusterer instance."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        assert clusterer.labels_ is not None
        np.testing.assert_array_equal(clusterer.labels_, labels)

    def test_labels_contain_noise(self, sample_coords_2d):
        """Some of the scattered noise points should be labelled -1."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        # The fixture has 5 scattered noise points, at least some should be noise
        assert -1 in labels.tolist()

    def test_custom_min_cluster_size(self, sample_coords_2d):
        """Changing min_cluster_size affects the number of clusters found."""
        c_small = Clusterer(min_cluster_size=3)
        labels_small = c_small.fit(sample_coords_2d)
        unique_small = set(labels_small.tolist()) - {-1}

        c_large = Clusterer(min_cluster_size=15)
        labels_large = c_large.fit(sample_coords_2d)
        unique_large = set(labels_large.tolist()) - {-1}

        # With a larger min_cluster_size, we should get fewer (or equal) clusters
        assert len(unique_large) <= len(unique_small)


class TestClustererGetClusterInfo:
    """Tests for Clusterer.get_cluster_info: extracting cluster metadata."""

    def test_returns_cluster_info_list(self, sample_coords_2d):
        """get_cluster_info returns a list of ClusterInfo objects."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        info = clusterer.get_cluster_info(sample_coords_2d, labels)
        assert isinstance(info, list)
        assert all(isinstance(c, ClusterInfo) for c in info)

    def test_cluster_info_fields(self, sample_coords_2d):
        """Each ClusterInfo has correct size, centroid, and member_indices."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        info = clusterer.get_cluster_info(sample_coords_2d, labels)

        for cluster in info:
            assert cluster.size > 0
            assert len(cluster.centroid) == 2
            assert len(cluster.member_indices) == cluster.size

    def test_member_indices_are_valid(self, sample_coords_2d):
        """member_indices are valid indices into the original array."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        info = clusterer.get_cluster_info(sample_coords_2d, labels)

        n = sample_coords_2d.shape[0]
        for cluster in info:
            for idx in cluster.member_indices:
                assert 0 <= idx < n

    def test_member_indices_match_labels(self, sample_coords_2d):
        """member_indices for cluster i all have label i."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        info = clusterer.get_cluster_info(sample_coords_2d, labels)

        for cluster in info:
            for idx in cluster.member_indices:
                assert labels[idx] == cluster.id

    def test_cluster_info_centroids_in_data_range(self, sample_coords_2d):
        """Cluster centroids lie within the range of the data."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        info = clusterer.get_cluster_info(sample_coords_2d, labels)

        data_min = sample_coords_2d.min(axis=0)
        data_max = sample_coords_2d.max(axis=0)

        for cluster in info:
            centroid = np.array(cluster.centroid)
            # Centroid should be within data bounds (with small tolerance)
            assert np.all(centroid >= data_min - 1)
            assert np.all(centroid <= data_max + 1)

    def test_total_members_plus_noise_equals_n(self, sample_coords_2d):
        """Sum of cluster members + noise points equals total data points."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        info = clusterer.get_cluster_info(sample_coords_2d, labels)
        noise = clusterer.get_noise_indices(labels)

        total_clustered = sum(c.size for c in info)
        assert total_clustered + len(noise) == sample_coords_2d.shape[0]

    def test_no_duplicate_indices(self, sample_coords_2d):
        """No index appears in multiple clusters."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        info = clusterer.get_cluster_info(sample_coords_2d, labels)

        all_indices = []
        for cluster in info:
            all_indices.extend(cluster.member_indices)
        assert len(all_indices) == len(set(all_indices))


class TestClustererGetNoiseIndices:
    """Tests for Clusterer.get_noise_indices: identifying noise points."""

    def test_noise_indices_have_label_minus_one(self, sample_coords_2d):
        """All noise indices have label -1."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        noise = clusterer.get_noise_indices(labels)
        assert all(labels[i] == -1 for i in noise)

    def test_noise_indices_are_valid(self, sample_coords_2d):
        """Noise indices are valid indices into the data array."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        noise = clusterer.get_noise_indices(labels)

        n = sample_coords_2d.shape[0]
        for idx in noise:
            assert 0 <= idx < n

    def test_all_minus_one_labels_are_in_noise(self, sample_coords_2d):
        """get_noise_indices returns ALL indices with label -1."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = clusterer.fit(sample_coords_2d)
        noise = set(clusterer.get_noise_indices(labels))

        expected = set(np.where(labels == -1)[0].tolist())
        assert noise == expected

    def test_no_noise_when_all_clustered(self):
        """If all points are clustered, noise indices are empty."""
        labels = np.array([0, 0, 0, 1, 1, 1])
        clusterer = Clusterer()
        noise = clusterer.get_noise_indices(labels)
        assert noise == []


class TestClustererEdgeCases:
    """Tests for edge cases: small and empty datasets."""

    def test_small_dataset_all_noise(self):
        """Dataset smaller than min_cluster_size produces all noise."""
        clusterer = Clusterer(min_cluster_size=5)
        small = np.random.randn(3, 2).astype(np.float32)
        labels = clusterer.fit(small)
        assert labels.shape == (3,)
        assert all(l == -1 for l in labels)

    def test_empty_dataset(self):
        """Empty dataset produces empty labels array."""
        clusterer = Clusterer(min_cluster_size=5)
        empty = np.empty((0, 2), dtype=np.float32)
        labels = clusterer.fit(empty)
        assert labels.shape == (0,)

    def test_empty_dataset_cluster_info(self):
        """get_cluster_info on empty data returns empty list."""
        clusterer = Clusterer(min_cluster_size=5)
        empty = np.empty((0, 2), dtype=np.float32)
        labels = clusterer.fit(empty)
        info = clusterer.get_cluster_info(empty, labels)
        assert info == []

    def test_empty_dataset_noise_indices(self):
        """get_noise_indices on empty data returns empty list."""
        clusterer = Clusterer(min_cluster_size=5)
        labels = np.array([], dtype=np.int64)
        noise = clusterer.get_noise_indices(labels)
        assert noise == []

    def test_single_point(self):
        """Single point is classified as noise."""
        clusterer = Clusterer(min_cluster_size=5)
        single = np.array([[1.0, 2.0]], dtype=np.float32)
        labels = clusterer.fit(single)
        assert labels.shape == (1,)
        assert labels[0] == -1

    def test_exactly_min_cluster_size(self):
        """Dataset of exactly min_cluster_size points can be clustered."""
        clusterer = Clusterer(min_cluster_size=5)
        # 5 tightly grouped points
        tight = np.random.randn(5, 2).astype(np.float32) * 0.01
        labels = clusterer.fit(tight)
        assert labels.shape == (5,)
        # With 5 tight points at min_cluster_size=5, HDBSCAN may or may not
        # form a cluster, but the operation should complete without error
