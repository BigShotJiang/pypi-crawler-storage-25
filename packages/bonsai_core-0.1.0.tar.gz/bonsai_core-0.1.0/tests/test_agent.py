"""Tests for bonsai_core Curator Agent.

Validates CuratorDeps dataclass, agent factory, and tool registration.
API-dependent tests are skipped when OPENAI_API_KEY is not set.
"""

import os

import pytest
from pydantic_ai import Agent
from pydantic_ai.tools import DeferredToolRequests

from bonsai_core.agent import CuratorDeps, create_curator_agent


# ------------------------------------------------------------------ #
# Stub helpers
# ------------------------------------------------------------------ #


class _StubStore:
    """Minimal stand-in for MemoryStore in unit tests."""

    def search(self, *a, **kw):
        return []

    def get(self, *a, **kw):
        return {}

    def get_all(self, *a, **kw):
        return []

    def update(self, *a, **kw):
        return {}

    def delete(self, *a, **kw):
        return {}

    def add(self, *a, **kw):
        return {}


# ------------------------------------------------------------------ #
# Pure logic tests (always run)
# ------------------------------------------------------------------ #


class TestCuratorDeps:
    """Tests for the CuratorDeps dataclass."""

    def test_creation_with_defaults(self):
        """CuratorDeps can be created with a store and uses 'default' user_id."""
        store = _StubStore()
        deps = CuratorDeps(store=store)
        assert deps.store is store
        assert deps.user_id == "default"

    def test_custom_user_id(self):
        """CuratorDeps accepts a custom user_id."""
        store = _StubStore()
        deps = CuratorDeps(store=store, user_id="alice")
        assert deps.user_id == "alice"
        assert deps.store is store


class TestCreateCuratorAgent:
    """Tests for the create_curator_agent factory function.

    Uses ``"test"`` model to avoid requiring an API key at import time.
    pydantic-ai's test model does not contact external services.
    """

    def test_returns_agent_instance(self):
        """create_curator_agent returns a pydantic-ai Agent."""
        agent = create_curator_agent(model="test")
        assert isinstance(agent, Agent)

    def test_agent_has_expected_tools(self):
        """Agent registers the expected Curator tool set."""
        agent = create_curator_agent(model="test")
        tool_names = set(agent._function_toolset.tools.keys())
        expected = {
            "search_memories",
            "get_memory_detail",
            "summarize_memories",
            "tag_memories",
            "find_duplicates",
            "suggest_curation_actions",
            "propose_memory_update",
            "delete_memories",
            "merge_memories",
        }
        assert expected == tool_names

    def test_system_prompt_contains_key_phrases(self):
        """System prompt includes core capability descriptions."""
        agent = create_curator_agent(model="test")
        # The system prompt is stored on the agent; extract it for inspection.
        # pydantic-ai stores system prompts as a list of strings or callables.
        prompts = agent._system_prompts
        # Concatenate all static string prompts.
        full_prompt = " ".join(p for p in prompts if isinstance(p, str))

        assert "BonsAI Memory Curator" in full_prompt
        assert "approval" in full_prompt


# ------------------------------------------------------------------ #
# API-dependent integration tests
# ------------------------------------------------------------------ #


@pytest.mark.skipif(
    not os.environ.get("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set",
)
class TestCuratorAgentIntegration:
    """Integration tests that require a live LLM API call."""

    @pytest.fixture
    def agent(self):
        """Create a curator agent wired to the default model."""
        return create_curator_agent()

    @pytest.fixture
    def deps(self):
        """CuratorDeps backed by a stub store."""
        return CuratorDeps(store=_StubStore(), user_id="test-user")

    @pytest.mark.asyncio
    async def test_simple_search_query(self, agent, deps):
        """Agent can handle a simple search query and return a string result."""
        result = await agent.run(
            "Search for memories about machine learning.",
            deps=deps,
        )
        # The result data may be plain text, a draft action, or a deferred
        # approval request depending on the model's choice.
        assert isinstance(result.output, (str, DeferredToolRequests, DeferredToolRequests))

    @pytest.mark.asyncio
    async def test_non_destructive_tool_invoked(self, agent, deps):
        """Agent invokes a non-destructive tool when asked to search."""
        result = await agent.run(
            "Find any memories related to Python programming.",
            deps=deps,
        )
        # With an empty stub store, the search will return no results.
        # The agent should still produce a valid text response.
        assert isinstance(result.output, (str, DeferredToolRequests))
        assert len(str(result.output)) > 0

    @pytest.mark.asyncio
    async def test_destructive_action_returns_deferred(self, agent, deps):
        """Requesting deletion triggers DeferredToolRequests for approval."""
        result = await agent.run(
            "Delete all memories with id 'mem-001'. Reason: outdated info.",
            deps=deps,
        )
        # The agent may return a plain explanation, a structured draft, or a
        # DeferredToolRequests if it directly invoked delete_memories.
        assert isinstance(result.output, (str, DeferredToolRequests, DeferredToolRequests))
