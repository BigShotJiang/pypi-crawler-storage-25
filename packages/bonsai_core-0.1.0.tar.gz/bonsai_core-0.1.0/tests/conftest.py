"""Shared fixtures for bonsai-core tests."""

import pytest
import numpy as np


@pytest.fixture
def tmp_storage_path(tmp_path):
    """Temporary directory for ChromaDB/Mem0 storage."""
    return str(tmp_path / "bonsai_test_memories")


@pytest.fixture
def tmp_cache_path(tmp_path):
    """Temporary directory for UMAP cache."""
    return str(tmp_path / "umap_cache")


@pytest.fixture
def sample_embeddings():
    """Generate sample embeddings for testing projection/clustering.

    Creates 50 points in 384 dimensions with 3 natural clusters.
    """
    rng = np.random.RandomState(42)
    # 3 clusters of 15 points each + 5 noise points
    cluster1 = rng.randn(15, 384) + np.array([1.0] * 384)
    cluster2 = rng.randn(15, 384) + np.array([-1.0] * 384)
    cluster3 = rng.randn(15, 384) + np.array([0.5] * 384)
    noise = rng.randn(5, 384) * 3  # scattered
    return np.vstack([cluster1, cluster2, cluster3, noise]).astype(np.float32)


@pytest.fixture
def small_embeddings():
    """Very small dataset for edge case testing."""
    rng = np.random.RandomState(42)
    return rng.randn(3, 384).astype(np.float32)


@pytest.fixture
def sample_coords_2d():
    """Pre-computed 2D coordinates for clustering tests."""
    rng = np.random.RandomState(42)
    # 3 well-separated clusters
    c1 = rng.randn(20, 2) + np.array([10, 10])
    c2 = rng.randn(20, 2) + np.array([-10, -10])
    c3 = rng.randn(20, 2) + np.array([10, -10])
    noise = rng.randn(5, 2) * 5
    return np.vstack([c1, c2, c3, noise]).astype(np.float32)


@pytest.fixture
def sample_memories_text():
    """Sample memory texts for MemoryStore tests."""
    return [
        "Jon Smith is a Senior Engineer at Google, specializing in ML infrastructure",
        "Maria Garcia is a Product Manager at Apple, focused on privacy features",
        "Met David Chen at PyCon 2024, he works on vector databases",
        "Sarah Johnson is CTO at a fintech startup, expert in distributed systems",
        "Alex Kim is a data scientist at Netflix, works on recommendation systems",
    ]
