"""Tests for bonsai_core MemoryStore.

MemoryStore uses Mem0 which requires an LLM API key (typically OpenAI)
for its ADD/UPDATE/DELETE/NETWORK (AUDN) extraction logic. All tests in
this module are skipped when OPENAI_API_KEY is not set in the environment.
"""

import os

import pytest

from bonsai_core.memory import MemoryStore

# Skip all tests in this module if no API key is available.
# Mem0 requires an LLM for its AUDN cycle.
pytestmark = pytest.mark.skipif(
    not os.environ.get("OPENAI_API_KEY"),
    reason="Mem0 requires OPENAI_API_KEY for memory extraction",
)


class TestMemoryStoreInit:
    """Tests for MemoryStore initialization."""

    def test_creates_store(self, tmp_storage_path):
        """MemoryStore can be instantiated with a path."""
        store = MemoryStore(path=tmp_storage_path)
        assert store.path == tmp_storage_path
        assert store.collection_name == "memories"

    def test_custom_collection_name(self, tmp_storage_path):
        """MemoryStore accepts a custom collection name."""
        store = MemoryStore(path=tmp_storage_path, collection_name="custom")
        assert store.collection_name == "custom"


class TestMemoryStoreAdd:
    """Tests for adding memories."""

    @pytest.fixture
    def store(self, tmp_storage_path):
        return MemoryStore(path=tmp_storage_path)

    def test_add_returns_dict(self, store):
        """add() returns a dict result."""
        result = store.add(
            "Jon is a software engineer at Google", user_id="test"
        )
        assert isinstance(result, dict)

    def test_add_and_get_all(self, store):
        """Can add a memory and retrieve it."""
        store.add(
            "Jon is a software engineer at Google", user_id="test"
        )
        memories = store.get_all(user_id="test")
        assert len(memories) > 0


class TestMemoryStoreSearch:
    """Tests for searching memories."""

    @pytest.fixture
    def store(self, tmp_storage_path):
        store = MemoryStore(path=tmp_storage_path)
        store.add("Jon works at Google on ML infrastructure", user_id="test")
        store.add("Maria is a product manager at Apple", user_id="test")
        return store

    def test_search_returns_results(self, store):
        """Can search for memories semantically."""
        results = store.search("Google engineer", user_id="test", limit=5)
        assert len(results) > 0

    def test_search_respects_limit(self, store):
        """Search limit parameter is respected."""
        results = store.search("engineer", user_id="test", limit=1)
        assert len(results) <= 1


class TestMemoryStoreEmbeddings:
    """Tests for get_all_with_embeddings (direct ChromaDB access)."""

    @pytest.fixture
    def store(self, tmp_storage_path):
        store = MemoryStore(path=tmp_storage_path)
        store.add("Test memory for embeddings", user_id="test")
        return store

    def test_returns_tuple(self, store):
        """get_all_with_embeddings returns a tuple of (list, ndarray)."""
        memories, embeddings = store.get_all_with_embeddings()
        assert isinstance(memories, list)

    def test_memories_have_embeddings(self, store):
        """Returned embeddings are a 2D numpy array matching memory count."""
        memories, embeddings = store.get_all_with_embeddings()
        assert len(memories) > 0
        assert embeddings.ndim == 2
        assert embeddings.shape[0] == len(memories)

    def test_memory_dict_structure(self, store):
        """Each memory dict has id, text, and metadata keys."""
        memories, _ = store.get_all_with_embeddings()
        for mem in memories:
            assert "id" in mem
            assert "text" in mem
            assert "metadata" in mem


class TestMemoryStoreCuration:
    """Tests for delete and update operations."""

    @pytest.fixture
    def store(self, tmp_storage_path):
        store = MemoryStore(path=tmp_storage_path)
        store.add("Memory to be modified", user_id="test")
        return store

    def test_delete(self, store):
        """Can delete a memory."""
        memories = store.get_all(user_id="test")
        assert len(memories) > 0
        memory_id = memories[0]["id"]
        store.delete(memory_id)
        remaining = store.get_all(user_id="test")
        assert len(remaining) < len(memories)

    def test_update(self, store):
        """Can update a memory."""
        memories = store.get_all(user_id="test")
        memory_id = memories[0]["id"]
        store.update(memory_id, "Updated content about Jon at Microsoft")
        updated = store.get(memory_id)
        assert updated is not None

    def test_get_specific_memory(self, store):
        """Can get a specific memory by ID."""
        memories = store.get_all(user_id="test")
        memory_id = memories[0]["id"]
        result = store.get(memory_id)
        assert result is not None


class TestMemoryStoreEmpty:
    """Tests for empty store behaviour."""

    def test_empty_store_get_all(self, tmp_storage_path):
        """Empty store returns empty results for get_all."""
        store = MemoryStore(path=tmp_storage_path + "_empty")
        memories = store.get_all(user_id="test")
        assert len(memories) == 0

    def test_empty_store_get_all_with_embeddings(self, tmp_storage_path):
        """get_all_with_embeddings on empty store returns empty structures."""
        store = MemoryStore(path=tmp_storage_path + "_empty2")
        memories, embeddings = store.get_all_with_embeddings()
        assert len(memories) == 0

    def test_empty_store_search(self, tmp_storage_path):
        """Search on empty store returns empty results."""
        store = MemoryStore(path=tmp_storage_path + "_empty3")
        results = store.search("anything", user_id="test")
        assert len(results) == 0
