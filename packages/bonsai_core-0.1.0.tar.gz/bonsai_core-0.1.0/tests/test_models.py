"""Tests for bonsai_core Pydantic models.

Validates model creation, default values, field validation, and serialization.
These tests are self-contained and require no external services or API keys.
"""

import uuid
from datetime import datetime

import pytest

from bonsai_core.models import (
    AddResult,
    ClusterInfo,
    Memory,
    MemoryMetadata,
    SearchResult,
)


class TestMemoryMetadata:
    """Tests for the MemoryMetadata model."""

    def test_defaults(self):
        """MemoryMetadata has sensible defaults."""
        meta = MemoryMetadata()
        assert meta.source is None
        assert meta.tags == []
        assert meta.importance == 0.5
        assert meta.is_deleted is False
        assert meta.deleted_at is None
        assert meta.created_at is not None
        assert meta.updated_at is not None

    def test_created_at_is_datetime(self):
        """created_at and updated_at are datetime instances."""
        meta = MemoryMetadata()
        assert isinstance(meta.created_at, datetime)
        assert isinstance(meta.updated_at, datetime)

    def test_custom_fields(self):
        """MemoryMetadata accepts custom values for all fields."""
        now = datetime.utcnow()
        meta = MemoryMetadata(
            created_at=now,
            updated_at=now,
            source="linkedin",
            tags=["professional", "engineer"],
            importance=0.9,
            is_deleted=True,
            deleted_at=now,
        )
        assert meta.source == "linkedin"
        assert meta.tags == ["professional", "engineer"]
        assert meta.importance == 0.9
        assert meta.is_deleted is True
        assert meta.deleted_at == now

    def test_importance_at_lower_bound(self):
        """Importance of 0.0 is valid."""
        meta = MemoryMetadata(importance=0.0)
        assert meta.importance == 0.0

    def test_importance_at_upper_bound(self):
        """Importance of 1.0 is valid."""
        meta = MemoryMetadata(importance=1.0)
        assert meta.importance == 1.0

    def test_importance_above_upper_bound_raises(self):
        """Importance > 1.0 raises a validation error."""
        with pytest.raises(Exception):
            MemoryMetadata(importance=1.5)

    def test_importance_below_lower_bound_raises(self):
        """Importance < 0.0 raises a validation error."""
        with pytest.raises(Exception):
            MemoryMetadata(importance=-0.1)

    def test_tags_default_is_independent(self):
        """Each MemoryMetadata instance gets its own tags list (no shared default)."""
        meta1 = MemoryMetadata()
        meta2 = MemoryMetadata()
        meta1.tags.append("test")
        assert "test" not in meta2.tags

    def test_serialization_roundtrip(self):
        """MemoryMetadata serializes to dict and deserializes back."""
        meta = MemoryMetadata(source="test", tags=["a", "b"], importance=0.7)
        d = meta.model_dump()
        restored = MemoryMetadata.model_validate(d)
        assert restored.source == meta.source
        assert restored.tags == meta.tags
        assert restored.importance == meta.importance


class TestMemory:
    """Tests for the Memory model."""

    def test_creation_with_text(self):
        """Memory can be created with just a text field."""
        m = Memory(text="Test memory")
        assert m.text == "Test memory"
        assert m.id is not None
        assert m.embedding is None

    def test_auto_generated_uuid(self):
        """Memory auto-generates a valid UUID string as id."""
        m = Memory(text="Test")
        # Should be a valid UUID
        parsed = uuid.UUID(m.id)
        assert str(parsed) == m.id

    def test_unique_ids(self):
        """Each Memory gets a unique id."""
        m1 = Memory(text="First")
        m2 = Memory(text="Second")
        assert m1.id != m2.id

    def test_with_embedding(self):
        """Memory can store embeddings as a list of floats."""
        m = Memory(text="Test", embedding=[0.1, 0.2, 0.3])
        assert m.embedding == [0.1, 0.2, 0.3]

    def test_default_metadata(self):
        """Memory gets default MemoryMetadata when none is provided."""
        m = Memory(text="Test")
        assert isinstance(m.metadata, MemoryMetadata)
        assert m.metadata.importance == 0.5

    def test_custom_metadata(self):
        """Memory accepts custom MemoryMetadata."""
        meta = MemoryMetadata(source="test", importance=0.9)
        m = Memory(text="Test", metadata=meta)
        assert m.metadata.source == "test"
        assert m.metadata.importance == 0.9

    def test_explicit_id(self):
        """Memory accepts an explicit id."""
        m = Memory(id="custom-id", text="Test")
        assert m.id == "custom-id"

    def test_serialization_roundtrip(self):
        """Memory serializes to dict and back without data loss."""
        m = Memory(text="Test memory", embedding=[0.1, 0.2])
        d = m.model_dump()
        m2 = Memory.model_validate(d)
        assert m2.text == m.text
        assert m2.id == m.id
        assert m2.embedding == m.embedding

    def test_text_is_required(self):
        """Memory requires text field."""
        with pytest.raises(Exception):
            Memory()  # type: ignore[call-arg]


class TestClusterInfo:
    """Tests for the ClusterInfo model."""

    def test_creation(self):
        """ClusterInfo can be created with required fields."""
        info = ClusterInfo(
            id=0, centroid=[1.0, 2.0], size=10, member_indices=[0, 1, 2]
        )
        assert info.id == 0
        assert info.centroid == [1.0, 2.0]
        assert info.size == 10
        assert info.member_indices == [0, 1, 2]

    def test_label_default_is_none(self):
        """ClusterInfo.label defaults to None."""
        info = ClusterInfo(id=0, centroid=[0.0, 0.0], size=5, member_indices=[0])
        assert info.label is None

    def test_with_label(self):
        """ClusterInfo accepts an optional label."""
        info = ClusterInfo(
            id=1,
            centroid=[0.0, 0.0],
            size=5,
            member_indices=[0, 1, 2, 3, 4],
            label="Tech Professionals",
        )
        assert info.label == "Tech Professionals"

    def test_3d_centroid(self):
        """ClusterInfo can hold 3D centroids."""
        info = ClusterInfo(
            id=0, centroid=[1.0, 2.0, 3.0], size=1, member_indices=[0]
        )
        assert len(info.centroid) == 3

    def test_serialization_roundtrip(self):
        """ClusterInfo serializes and deserializes correctly."""
        info = ClusterInfo(
            id=2, centroid=[1.5, -2.5], size=7, member_indices=[3, 4, 5, 6, 7, 8, 9]
        )
        d = info.model_dump()
        restored = ClusterInfo.model_validate(d)
        assert restored.id == info.id
        assert restored.centroid == info.centroid
        assert restored.size == info.size
        assert restored.member_indices == info.member_indices


class TestAddResult:
    """Tests for the AddResult model."""

    def test_added_status(self):
        """AddResult can represent a successful add."""
        result = AddResult(status="added", id="abc123")
        assert result.status == "added"
        assert result.id == "abc123"

    def test_duplicate_found_status(self):
        """AddResult can represent a duplicate detection."""
        result = AddResult(status="duplicate_found", message="Similar memory exists")
        assert result.status == "duplicate_found"
        assert result.message == "Similar memory exists"

    def test_duplicates_default_empty(self):
        """AddResult.duplicates defaults to empty list."""
        result = AddResult(status="duplicate_found", message="Similar memory exists")
        assert result.duplicates == []

    def test_with_duplicate_memories(self):
        """AddResult can contain a list of duplicate Memory objects."""
        dup = Memory(text="Existing memory")
        result = AddResult(status="duplicate_found", duplicates=[dup])
        assert len(result.duplicates) == 1
        assert result.duplicates[0].text == "Existing memory"

    def test_id_default_is_none(self):
        """AddResult.id defaults to None."""
        result = AddResult(status="added")
        assert result.id is None

    def test_message_default_is_none(self):
        """AddResult.message defaults to None."""
        result = AddResult(status="added", id="xyz")
        assert result.message is None


class TestSearchResult:
    """Tests for the SearchResult model."""

    def test_empty_result(self):
        """SearchResult can represent an empty result set."""
        result = SearchResult(memories=[], total=0)
        assert len(result.memories) == 0
        assert result.total == 0

    def test_with_memories(self):
        """SearchResult can contain Memory objects."""
        m1 = Memory(text="First result")
        m2 = Memory(text="Second result")
        result = SearchResult(memories=[m1, m2], total=2)
        assert len(result.memories) == 2
        assert result.memories[0].text == "First result"
        assert result.memories[1].text == "Second result"

    def test_total_can_exceed_memories(self):
        """total can be larger than len(memories) for paginated results."""
        m = Memory(text="Only result in this page")
        result = SearchResult(memories=[m], total=100)
        assert len(result.memories) == 1
        assert result.total == 100

    def test_serialization_roundtrip(self):
        """SearchResult serializes and deserializes correctly."""
        m = Memory(text="Test")
        result = SearchResult(memories=[m], total=1)
        d = result.model_dump()
        restored = SearchResult.model_validate(d)
        assert restored.total == result.total
        assert len(restored.memories) == len(result.memories)
        assert restored.memories[0].text == "Test"
