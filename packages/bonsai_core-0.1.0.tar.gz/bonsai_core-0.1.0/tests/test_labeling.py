"""Tests for bonsai_core cluster label generation.

Validates the generate_cluster_label function signature and basic
behaviour.  API-dependent tests are skipped when OPENAI_API_KEY is
not set.
"""

import os

import pytest

from bonsai_core.labeling import generate_cluster_label


# ── Pure-logic tests (no API key needed) ───────────────────────────


class TestGenerateClusterLabel:
    """Tests for generate_cluster_label that don't require an API key."""

    def test_is_importable(self):
        """generate_cluster_label can be imported from bonsai_core.labeling."""
        assert callable(generate_cluster_label)

    def test_accepts_memories_and_model(self):
        """Function accepts memories list and optional model string."""
        import inspect

        sig = inspect.signature(generate_cluster_label)
        params = list(sig.parameters.keys())
        assert "memories" in params
        assert "model" in params
        # model has a default value
        assert sig.parameters["model"].default == "gpt-4o-mini"

    def test_empty_memories_returns_empty_string(self):
        """Passing an empty list returns an empty string without calling the API."""
        result = generate_cluster_label([])
        assert result == ""


# ── API-dependent tests ─────────────────────────────────────────────


@pytest.mark.skipif(
    not os.environ.get("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set — skipping integration tests",
)
class TestGenerateClusterLabelIntegration:
    """Integration tests that require a live OpenAI API key."""

    def test_five_memories_returns_label(self):
        """Five sample memory texts produce a non-empty label string."""
        memories = [
            "Jon Smith is a Senior Engineer at Google, specializing in ML infrastructure",
            "Maria Garcia is a Product Manager at Apple, focused on privacy features",
            "Met David Chen at PyCon 2024, he works on vector databases",
            "Sarah Johnson is CTO at a fintech startup, expert in distributed systems",
            "Alex Kim is a data scientist at Netflix, works on recommendation systems",
        ]
        label = generate_cluster_label(memories)
        assert isinstance(label, str)
        assert len(label) > 0

    def test_single_memory_returns_label(self):
        """A single memory text still produces a non-empty label."""
        label = generate_cluster_label(["Alex works on recommendation systems at Netflix"])
        assert isinstance(label, str)
        assert len(label) > 0
