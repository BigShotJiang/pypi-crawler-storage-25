from __future__ import annotations

from typing import Protocol

import numpy as np

from bonsai_core.models import Memory


class MemoryAdapter(Protocol):
    """Storage interface for memory backends."""

    def get_all_with_embeddings(self) -> tuple[list[Memory], np.ndarray]:
        """Get all memories with embeddings for visualization."""
        ...

    def get(self, id: str) -> Memory:
        """Get a single memory by ID."""
        ...

    def add(self, memory: Memory) -> str:
        """Add memory and return its ID."""
        ...

    def update(self, id: str, fact: str | None = None, metadata: dict | None = None) -> None:
        """Update memory content or metadata."""
        ...

    def delete(self, id: str, soft: bool = True) -> None:
        """Delete memory (soft delete by default)."""
        ...

    def search(self, query: str, limit: int = 10) -> list[Memory]:
        """Semantic search."""
        ...
