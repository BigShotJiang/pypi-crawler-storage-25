from __future__ import annotations

import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import chromadb
import numpy as np
from fastembed import TextEmbedding

from bonsai_core.models import Memory


def _to_iso(value: datetime | None) -> str | None:
    return value.isoformat() if value else None


def _from_iso(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value))
    except ValueError:
        return None


# Relevance cutoff defaults for search
SEARCH_SIMILARITY_FLOOR = 0.45  # cosine similarity; drop anything below
SEARCH_GAP_THRESHOLD = 0.07  # cosine distance gap to detect relevance boundary


def _apply_relevance_cutoff(
    pairs: list[tuple[Any, float]],
    similarity_floor: float,
    gap_threshold: float,
) -> list[tuple[Any, float]]:
    """Filter search results by similarity floor and gap detection.

    1. Remove results below the similarity floor.
    2. Walk the sorted distance list and cut at the largest gap that exceeds
       the gap threshold — this naturally separates the "relevant cluster"
       from noise.
    """
    if not pairs:
        return pairs

    # Step 1: hard floor (distance = 1 - similarity)
    max_distance = 1.0 - similarity_floor
    filtered = [(m, d) for m, d in pairs if d <= max_distance]

    if len(filtered) < 3:
        return filtered

    # Step 2: gap detection on sorted distances
    best_gap = 0.0
    cut_index = len(filtered)
    for i in range(1, len(filtered)):
        gap = filtered[i][1] - filtered[i - 1][1]
        if gap > best_gap:
            best_gap = gap
            cut_index = i

    if best_gap >= gap_threshold:
        filtered = filtered[:cut_index]

    return filtered


class NativeChromaAdapter:
    """Native ChromaDB adapter (no Mem0 intelligence layer)."""

    def __init__(
        self,
        path: str = "./bonsai_memories",
        collection_name: str = "memories",
        embedding_model: str = "BAAI/bge-small-en-v1.5",
    ) -> None:
        Path(path).mkdir(parents=True, exist_ok=True)
        self.client = chromadb.PersistentClient(path=path)
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        self.embedder = TextEmbedding(embedding_model)

    def _embed(self, text: str) -> list[float]:
        vectors = list(self.embedder.embed([text]))
        if not vectors:
            return []
        return vectors[0].tolist()

    def _serialize_metadata(self, memory: Memory) -> dict[str, Any]:
        return {
            "source_episode_id": memory.source_episode_id,
            "source_text": memory.source_text,
            "source_context": memory.source_context,
            "source_char_start": memory.source_char_start,
            "source_char_end": memory.source_char_end,
            "importance": float(memory.importance),
            "last_accessed_at": _to_iso(memory.last_accessed_at),
            "created_at": _to_iso(memory.created_at),
            "valid_from": _to_iso(memory.valid_from),
            "valid_until": _to_iso(memory.valid_until),
            "is_deleted": bool(memory.is_deleted),
            "deleted_at": _to_iso(memory.deleted_at),
            "tags": ",".join(memory.tags),
            "source": memory.source or "",
            "user_id": memory.user_id,
            "version": memory.version,
            "supersedes_id": memory.supersedes_id or "",
            "triggered_by_id": memory.triggered_by_id or "",
            "triggered_update_of_ids": ",".join(memory.triggered_update_of_ids),
        }

    def _memory_from_row(
        self,
        id_: str,
        doc: str,
        metadata: dict[str, Any] | None,
        embedding: list[float] | None,
    ) -> Memory:
        m = metadata or {}
        tags_raw = m.get("tags", "")
        tags = [t for t in str(tags_raw).split(",") if t] if tags_raw else []
        return Memory(
            id=id_,
            fact=doc or "",
            source_episode_id=str(m.get("source_episode_id", "")),
            source_text=str(m.get("source_text", "")),
            source_context=str(m.get("source_context", "")),
            source_char_start=int(m.get("source_char_start", 0) or 0),
            source_char_end=int(m.get("source_char_end", 0) or 0),
            importance=float(m.get("importance", 0.5) or 0.5),
            last_accessed_at=_from_iso(m.get("last_accessed_at")) or datetime.now(UTC),
            created_at=_from_iso(m.get("created_at")) or datetime.now(UTC),
            valid_from=_from_iso(m.get("valid_from")),
            valid_until=_from_iso(m.get("valid_until")),
            is_deleted=bool(m.get("is_deleted", False)),
            deleted_at=_from_iso(m.get("deleted_at")),
            tags=tags,
            source=str(m.get("source", "")) or None,
            user_id=str(m.get("user_id", "default")),
            version=int(m.get("version", 1) or 1),
            supersedes_id=m.get("supersedes_id") or None,
            triggered_by_id=m.get("triggered_by_id") or None,
            triggered_update_of_ids=[
                t for t in str(m.get("triggered_update_of_ids", "")).split(",") if t
            ] if m.get("triggered_update_of_ids") else [],
            embedding=embedding,
        )

    def get_all_with_embeddings(self) -> tuple[list[Memory], np.ndarray]:
        result = self.collection.get(include=["documents", "metadatas", "embeddings"])
        ids = result.get("ids", [])
        docs = result.get("documents") or []
        metas = result.get("metadatas") or []
        embeddings = result.get("embeddings")

        memories: list[Memory] = []
        for i, id_ in enumerate(ids):
            doc = docs[i] if i < len(docs) else ""
            meta = metas[i] if i < len(metas) else {}
            emb = embeddings[i] if embeddings is not None and i < len(embeddings) else None
            memories.append(self._memory_from_row(id_, doc, meta, emb))

        embedding_array = np.array(embeddings) if embeddings is not None and len(embeddings) > 0 else np.empty((0, 0))
        return memories, embedding_array

    def get(self, id: str) -> Memory:
        result = self.collection.get(
            ids=[id],
            include=["documents", "metadatas", "embeddings"],
        )
        ids = result.get("ids", [])
        if not ids:
            raise KeyError(f"Memory '{id}' not found")
        doc = (result.get("documents") or [""])[0]
        meta = (result.get("metadatas") or [{}])[0]
        raw_embs = result.get("embeddings")
        embs = raw_embs if raw_embs is not None and len(raw_embs) > 0 else [None]
        return self._memory_from_row(ids[0], doc, meta, embs[0])

    def add(self, memory: Memory) -> str:
        id_ = memory.id or str(uuid.uuid4())
        embedding = memory.embedding or self._embed(memory.fact)
        self.collection.upsert(
            ids=[id_],
            documents=[memory.fact],
            embeddings=[embedding],
            metadatas=[self._serialize_metadata(memory)],
        )
        return id_

    def update(self, id: str, fact: str | None = None, metadata: dict | None = None) -> None:
        current = self.get(id)
        if fact is not None:
            current.fact = fact
            current.embedding = self._embed(fact)

        now = datetime.now(UTC)
        current.last_accessed_at = now
        if metadata:
            for key, value in metadata.items():
                if hasattr(current, key):
                    setattr(current, key, value)

        self.collection.upsert(
            ids=[id],
            documents=[current.fact],
            embeddings=[current.embedding or self._embed(current.fact)],
            metadatas=[self._serialize_metadata(current)],
        )

    def delete(self, id: str, soft: bool = True) -> None:
        if not soft:
            self.collection.delete(ids=[id])
            return
        now = datetime.now(UTC)
        self.update(id, metadata={"is_deleted": True, "deleted_at": now})

    def search(self, query: str, limit: int = 10) -> list[Memory]:
        results = self.search_with_distances(query, limit=limit)
        return [mem for mem, _ in results]

    def search_with_distances(
        self,
        query: str,
        limit: int = 10,
        *,
        similarity_floor: float | None = None,
        gap_threshold: float | None = None,
    ) -> list[tuple[Memory, float]]:
        """Semantic search returning (memory, cosine_distance) pairs.

        Cosine distance: 0 = identical, 2 = opposite.
        Cosine similarity = 1 - distance.

        When *similarity_floor* or *gap_threshold* is not ``None`` (or
        defaults are used), results are pruned to only include relevant
        matches.  Pass ``similarity_floor=0.0`` to disable the floor.
        """
        # Over-fetch so that gap detection has enough data to work with
        fetch_limit = min(limit * 3, max(limit, 50))
        query_embedding = self._embed(query)
        result = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=fetch_limit,
            include=["documents", "metadatas", "embeddings", "distances"],
        )
        ids = result.get("ids", [[]])[0]
        docs = result.get("documents", [[]])[0]
        metas = result.get("metadatas", [[]])[0]
        embs = result.get("embeddings", [[]])[0] if result.get("embeddings") else []
        distances = result.get("distances", [[]])[0]

        pairs: list[tuple[Memory, float]] = []
        for i, id_ in enumerate(ids):
            doc = docs[i] if i < len(docs) else ""
            meta = metas[i] if i < len(metas) else {}
            emb = embs[i] if i < len(embs) else None
            dist = distances[i] if i < len(distances) else 2.0
            pairs.append((self._memory_from_row(id_, doc, meta, emb), float(dist)))

        # Apply relevance cutoff
        floor = similarity_floor if similarity_floor is not None else SEARCH_SIMILARITY_FLOOR
        gap = gap_threshold if gap_threshold is not None else SEARCH_GAP_THRESHOLD
        pairs = _apply_relevance_cutoff(pairs, floor, gap)

        return pairs[:limit]
