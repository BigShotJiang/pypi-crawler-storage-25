"""Pydantic-AI integration for BonsAI.

Provides ready-made tools that give any pydantic-ai agent the ability to
read and write BonsAI memories.

Usage::

    from pydantic_ai import Agent
    from bonsai_core.memory import MemoryStore
    from bonsai_core.integrations.pydantic_ai import create_bonsai_tools

    store = MemoryStore()
    tools = create_bonsai_tools(store)

    agent = Agent("openai:gpt-4o", tools=tools)
    result = await agent.run("Remember that I prefer Python over Java.")
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pydantic_ai import RunContext

from bonsai_core.memory import MemoryStore


@dataclass
class BonsAIDeps:
    """Dependencies for BonsAI tools. Attach to your agent's deps."""

    store: MemoryStore
    user_id: str = "default"


def create_bonsai_tools(
    store: MemoryStore | None = None,
    user_id: str = "default",
) -> list:
    """Create pydantic-ai tool functions for memory read/write.

    Parameters
    ----------
    store:
        A :class:`MemoryStore` instance. If ``None``, a default store is
        created.
    user_id:
        Default user ID for memory operations.

    Returns
    -------
    list
        A list of async tool functions ready to pass to ``Agent(tools=...)``.

    Example
    -------
    ::

        from pydantic_ai import Agent
        from bonsai_core.memory import MemoryStore
        from bonsai_core.integrations.pydantic_ai import create_bonsai_tools

        store = MemoryStore()
        tools = create_bonsai_tools(store)
        agent = Agent("openai:gpt-4o", tools=tools)

    The agent will have access to ``remember``, ``recall``, ``recall_all``,
    and ``forget`` tools.
    """
    _store = store or MemoryStore()
    _user_id = user_id

    async def remember(ctx: RunContext[Any], fact: str) -> str:
        """Save a fact to long-term memory.

        Use this when the user shares personal information, preferences,
        or important context that should be remembered across conversations.
        """
        result = _store.add(content=fact, user_id=_user_id)
        count = result.get("added_count", 0) if isinstance(result, dict) else 0
        return f"Remembered ({count} fact{'s' if count != 1 else ''} extracted)."

    async def recall(ctx: RunContext[Any], query: str, limit: int = 5) -> str:
        """Search long-term memory for relevant information.

        Use this before answering questions that might depend on previously
        stored knowledge about the user or their context.
        """
        results = _store.search(query, user_id=_user_id, limit=limit)
        if not results:
            return "No relevant memories found."
        lines = []
        for r in results:
            text = r.get("text") or r.get("memory") or ""
            lines.append(f"- {text}")
        return f"Found {len(results)} memories:\n" + "\n".join(lines)

    async def recall_all(ctx: RunContext[Any]) -> str:
        """Retrieve all stored memories for the current user.

        Use this when you need a complete picture of everything known
        about the user.
        """
        memories = _store.get_all(user_id=_user_id)
        if not memories:
            return "No memories stored."
        lines = []
        for m in memories[:50]:  # cap to avoid token overflow
            text = m.get("text") or m.get("memory") or ""
            lines.append(f"- {text}")
        suffix = f"\n... and {len(memories) - 50} more" if len(memories) > 50 else ""
        return f"{len(memories)} memories:\n" + "\n".join(lines) + suffix

    async def forget(ctx: RunContext[Any], memory_id: str) -> str:
        """Delete a specific memory by its ID.

        Only use this when the user explicitly asks to forget something.
        """
        try:
            _store.delete(memory_id)
            return f"Deleted memory {memory_id}."
        except Exception as e:
            return f"Failed to delete: {e}"

    return [remember, recall, recall_all, forget]
