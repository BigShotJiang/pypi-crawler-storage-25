"""Native memory store implementation (custom thesis stack, no Mem0)."""

from __future__ import annotations

import json
import os
import re
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import numpy as np

from bonsai_core.conflicts import (
    HIGH_IMPORTANCE_THRESHOLD,
    SIMILARITY_FLOOR,
    CandidatePair,
    batch_conflict_detection,
    classify_update_type,
    rewrite_to_past_tense,
    suggest_merge,
)
from bonsai_core.extraction import extract_facts, locate_span
from bonsai_core.models import Memory
from bonsai_core.storage.native import NativeChromaAdapter

UPDATE_AUTO_CONFIDENCE = float(os.environ.get("BONSAI_UPDATE_AUTO_CONFIDENCE", "0.9"))


class MemoryStore:
    """Compatibility wrapper over the native Chroma adapter.

    The current server/frontend paths still use dict-shaped responses and methods
    like ``add(content=...)``. This class preserves that contract while storing
    thesis-native ``Memory`` objects under the hood.
    """

    def __init__(
        self,
        path: str = "./bonsai_memories",
        collection_name: str = "memories",
    ) -> None:
        self.path = path
        self.collection_name = collection_name
        self.adapter = NativeChromaAdapter(path=path, collection_name=collection_name)
        self._conflicts_file = Path(path) / "pending_conflicts.json"
        self._pending_conflicts: dict[str, dict[str, Any]] = self._load_conflicts()
        self._conflict_decisions_file = Path(path) / "conflict_decisions.json"
        self._conflict_decisions: dict[str, dict[str, Any]] = self._load_conflict_decisions()
        self._events_file = Path(path) / "memory_events.jsonl"

    @property
    def collection(self):
        """Expose underlying Chroma collection for direct access."""
        return self.adapter.collection

    def _to_legacy_dict(self, memory: Memory) -> dict[str, Any]:
        return {
            "id": memory.id,
            "text": memory.fact,
            "memory": memory.fact,
            "created_at": memory.created_at.isoformat(),
            "updated_at": memory.last_accessed_at.isoformat(),
            "metadata": {
                "created_at": memory.created_at.isoformat(),
                "updated_at": memory.last_accessed_at.isoformat(),
                "source": memory.source,
                "tags": memory.tags,
                "importance": memory.importance,
                "is_deleted": memory.is_deleted,
                "deleted_at": memory.deleted_at.isoformat() if memory.deleted_at else None,
                "source_episode_id": memory.source_episode_id,
                "source_text": memory.source_text,
                "source_context": memory.source_context,
                "source_char_start": memory.source_char_start,
                "source_char_end": memory.source_char_end,
                "valid_from": memory.valid_from.isoformat() if memory.valid_from else None,
                "valid_until": memory.valid_until.isoformat() if memory.valid_until else None,
                "user_id": memory.user_id,
                "version": memory.version,
                "supersedes_id": memory.supersedes_id,
                "triggered_by_id": memory.triggered_by_id,
                "triggered_update_of_ids": memory.triggered_update_of_ids,
            },
        }

    @staticmethod
    def _extract_source_context(content: str, start: int, end: int, target_words: int = 36) -> str:
        """Return sentence-aware context around the extracted span.

        Strategy:
        1. Find the sentence containing the span midpoint.
        2. Expand with neighboring sentences until target word budget is reached.
        3. Fall back to compact char window when sentence parsing is unavailable.
        """
        if not content:
            return ""
        start = max(0, min(start, len(content)))
        end = max(start, min(end, len(content)))
        midpoint = start if start < end else min(len(content), start)

        # Sentence spans with offsets.
        sentence_spans: list[tuple[int, int]] = [
            (m.start(), m.end())
            for m in re.finditer(r"[^.!?\n]+(?:[.!?]+|$)", content)
            if m.group(0).strip()
        ]
        if not sentence_spans:
            left = max(0, midpoint - 140)
            right = min(len(content), midpoint + 140)
            return content[left:right].strip()

        # Locate sentence containing midpoint (or closest sentence).
        center_idx = 0
        best_dist = float("inf")
        for i, (s, e) in enumerate(sentence_spans):
            if s <= midpoint <= e:
                center_idx = i
                best_dist = 0
                break
            dist = min(abs(midpoint - s), abs(midpoint - e))
            if dist < best_dist:
                best_dist = dist
                center_idx = i

        left_idx = center_idx
        right_idx = center_idx

        def _words_for_range(li: int, ri: int) -> int:
            lo = sentence_spans[li][0]
            hi = sentence_spans[ri][1]
            return len(content[lo:hi].split())

        # Expand symmetrically by neighboring sentences until target word count.
        while _words_for_range(left_idx, right_idx) < target_words:
            can_left = left_idx > 0
            can_right = right_idx < len(sentence_spans) - 1
            if not can_left and not can_right:
                break
            if can_left:
                left_idx -= 1
            if _words_for_range(left_idx, right_idx) >= target_words:
                break
            if can_right:
                right_idx += 1

        lo = sentence_spans[left_idx][0]
        hi = sentence_spans[right_idx][1]
        snippet = content[lo:hi].strip()
        if len(snippet) > 420:
            snippet = snippet[:420].rsplit(" ", 1)[0] + "..."
        return snippet

    def _load_conflicts(self) -> dict[str, dict[str, Any]]:
        if not self._conflicts_file.exists():
            return {}
        try:
            raw = json.loads(self._conflicts_file.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                return raw
            return {}
        except Exception:
            return {}

    def _load_conflict_decisions(self) -> dict[str, dict[str, Any]]:
        if not self._conflict_decisions_file.exists():
            return {}
        try:
            raw = json.loads(self._conflict_decisions_file.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                return raw
            return {}
        except Exception:
            return {}

    def _save_conflicts(self) -> None:
        self._conflicts_file.parent.mkdir(parents=True, exist_ok=True)
        self._conflicts_file.write_text(
            json.dumps(self._pending_conflicts, indent=2),
            encoding="utf-8",
        )

    def _save_conflict_decisions(self) -> None:
        self._conflict_decisions_file.parent.mkdir(parents=True, exist_ok=True)
        self._conflict_decisions_file.write_text(
            json.dumps(self._conflict_decisions, indent=2),
            encoding="utf-8",
        )

    def _to_conflict_record(
        self,
        new_memory: Memory,
        existing_memory: Memory,
        contradiction_score: float,
        label: str = "contradiction",
        decision_source: str = "model",
        reason: str | None = None,
    ) -> dict[str, Any]:
        conflict_id = str(uuid.uuid4())
        return {
            "id": conflict_id,
            "new_fact": self._to_legacy_dict(new_memory),
            "existing_fact": self._to_legacy_dict(existing_memory),
            "contradiction_score": contradiction_score,
            "label": label,
            "decision_source": decision_source,
            "reason": reason or "",
            "created_at": datetime.now(UTC).isoformat(),
            "status": "pending",
            "resolution": None,
            "resolved_at": None,
        }

    def _append_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> None:
        self._events_file.parent.mkdir(parents=True, exist_ok=True)
        row = {
            "id": str(uuid.uuid4()),
            "type": event_type,
            "timestamp": datetime.now(UTC).isoformat(),
            "payload": payload,
        }
        with self._events_file.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row) + "\n")

    @staticmethod
    def _coerce_ts(raw: str) -> datetime:
        try:
            return datetime.fromisoformat(raw.replace("Z", "+00:00"))
        except Exception:
            return datetime.min.replace(tzinfo=UTC)

    def _walk_lineage(self, memory_id: str) -> set[str]:
        """Walk the supersedes_id chain to collect all ancestor IDs."""
        ids = {memory_id}
        current_id = memory_id
        seen = set()
        while current_id and current_id not in seen:
            seen.add(current_id)
            try:
                mem = self.adapter.get(current_id)
            except KeyError:
                break
            if mem.supersedes_id:
                ids.add(mem.supersedes_id)
                current_id = mem.supersedes_id
            else:
                break
        return ids

    def list_memory_events(
        self,
        event_types: list[str] | None = None,
        limit: int = 200,
        memory_id: str | None = None,
    ) -> list[dict[str, Any]]:
        if not self._events_file.exists():
            return []
        selected = set(event_types or [])
        lineage_ids: set[str] | None = None
        if memory_id:
            lineage_ids = self._walk_lineage(memory_id)
        rows: list[dict[str, Any]] = []
        for line in self._events_file.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except Exception:
                continue
            if selected and row.get("type") not in selected:
                continue
            if lineage_ids is not None:
                payload = row.get("payload") or {}
                relevant_ids = {
                    str(payload.get("memory_id", "")),
                    str(payload.get("existing_memory_id", "")),
                    str(payload.get("new_memory_id", "")),
                }
                if not relevant_ids & lineage_ids:
                    continue
            rows.append(row)
        rows.sort(key=lambda r: self._coerce_ts(str(r.get("timestamp", ""))), reverse=True)
        return rows[:max(1, limit)]

    def _supersede_existing_and_add_new(
        self,
        existing: Memory,
        new_memory: Memory,
    ) -> dict[str, Any]:
        now = datetime.now(UTC)
        self.adapter.update(existing.id, metadata={"valid_until": now})
        new_memory.version = existing.version + 1
        new_memory.supersedes_id = existing.id
        memory_id = self.adapter.add(new_memory)
        return self._to_legacy_dict(self.adapter.get(memory_id))

    def _apply_inline_update(
        self,
        existing: Memory,
        new_fact_text: str,
    ) -> dict[str, Any]:
        """Update the same memory in place with new text, bumping version."""
        new_version = existing.version + 1
        self.adapter.update(
            existing.id,
            fact=new_fact_text,
            metadata={"version": new_version},
        )
        self._append_event(
            "memory.inline_update_applied",
            {
                "memory_id": existing.id,
                "before_text": existing.fact,
                "after_text": new_fact_text,
                "version": new_version,
                "actor": "auto",
            },
        )
        return self._to_legacy_dict(self.adapter.get(existing.id))

    def _apply_supersede_update(
        self,
        existing: Memory,
        new_memory: Memory,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Create new independent fact and rewrite old to past tense."""
        now = datetime.now(UTC)
        as_of_date = now.strftime("%b %Y")

        # 1. Add the new memory as independent v1
        new_id = self.adapter.add(new_memory)
        self._append_event(
            "memory.added",
            {
                "memory_id": new_id,
                "after_text": new_memory.fact,
                "label": "added",
                "actor": "auto",
                "source": "supersede_ingestion",
            },
        )

        # 2. Rewrite old fact to past tense
        rewritten = rewrite_to_past_tense(existing.fact, as_of_date=as_of_date)

        # 3. Update old memory with rewritten text + provenance
        old_new_version = existing.version + 1
        self.adapter.update(
            existing.id,
            fact=rewritten,
            metadata={
                "version": old_new_version,
                "valid_until": now,
                "triggered_by_id": new_id,
            },
        )
        self._append_event(
            "memory.supersede_rewrite_applied",
            {
                "memory_id": existing.id,
                "before_text": existing.fact,
                "after_text": rewritten,
                "version": old_new_version,
                "triggered_by_id": new_id,
                "actor": "auto",
            },
        )

        # 4. Update new memory with back-link
        self.adapter.update(
            new_id,
            metadata={"triggered_update_of_ids": [existing.id]},
        )

        old_result = self._to_legacy_dict(self.adapter.get(existing.id))
        new_result = self._to_legacy_dict(self.adapter.get(new_id))
        return new_result, old_result

    def revert_memory(
        self,
        memory_id: str,
        target_version: int,
    ) -> dict[str, Any]:
        """Revert a memory to a previous version by replaying event log.

        If reverting a supersede rewrite, creates a pending conflict.
        """
        current = self.adapter.get(memory_id)
        if target_version >= current.version:
            raise ValueError(
                f"target_version ({target_version}) must be less than "
                f"current version ({current.version})"
            )

        # Walk event log to find the text at target_version
        events = self.list_memory_events(memory_id=memory_id)
        # Events are sorted newest-first; find the event that created target_version
        target_text: str | None = None
        reverted_event_type: str | None = None
        for evt in events:
            payload = evt.get("payload", {})
            evt_version = payload.get("version")
            evt_memory_id = str(payload.get("memory_id", ""))
            if evt_memory_id != memory_id:
                continue
            # The event that bumped TO target_version+1 has before_text = target_version text
            if evt_version == target_version + 1:
                target_text = str(payload.get("before_text", ""))
                reverted_event_type = evt.get("type")
                break
            # The event that created v1 has after_text
            if target_version == 1 and evt.get("type") == "memory.added":
                target_text = str(payload.get("after_text", ""))
                reverted_event_type = evt.get("type")
                break

        if target_text is None:
            raise ValueError(
                f"Could not reconstruct text for version {target_version} "
                f"from event log"
            )

        # Apply revert
        new_version = current.version + 1
        self.adapter.update(
            memory_id,
            fact=target_text,
            metadata={"version": new_version},
        )
        self._append_event(
            "memory.reverted",
            {
                "memory_id": memory_id,
                "before_text": current.fact,
                "after_text": target_text,
                "version": new_version,
                "reverted_to_version": target_version,
                "actor": "human",
            },
        )

        # If reverting a supersede rewrite, create a pending conflict
        if reverted_event_type == "memory.supersede_rewrite_applied":
            reverted_mem = self.adapter.get(memory_id)
            # Build a conflict record so a human can review
            conflict = self._to_conflict_record(
                new_memory=reverted_mem,
                existing_memory=current,
                contradiction_score=1.0,
                label="revert_conflict",
                decision_source="human",
                reason=(
                    f"Human reverted auto-rewrite of memory {memory_id} "
                    f"from v{current.version} back to v{target_version}"
                ),
            )
            self._pending_conflicts[conflict["id"]] = conflict
            self._save_conflicts()

        return self._to_legacy_dict(self.adapter.get(memory_id))

    @staticmethod
    def _conflict_severity(conflict: dict[str, Any]) -> float:
        score = float(conflict.get("contradiction_score", 0.0) or 0.0)
        new_imp = float(
            ((conflict.get("new_fact") or {}).get("metadata") or {}).get("importance", 0.5)
        )
        old_imp = float(
            ((conflict.get("existing_fact") or {}).get("metadata") or {}).get("importance", 0.5)
        )
        return max(0.0, min(1.0, score * max(new_imp, old_imp)))

    def add(
        self,
        content: str,
        user_id: str = "default",
        metadata: dict[str, Any] | None = None,
        *,
        event_actor: str = "auto",
        event_source: str = "ingestion",
        event_reason: str | None = None,
    ) -> dict[str, Any]:
        """Extract facts, detect conflicts, and add non-conflicting memories."""
        md = metadata or {}
        extracted = extract_facts(content)
        added: list[dict[str, Any]] = []
        pending: list[dict[str, Any]] = []
        new_memories: list[Memory] = []
        candidates_map: dict[str, list[tuple[Memory, float]]] = {}

        # Build new memory objects first.
        for fact in extracted.facts:
            start, end = locate_span(content, fact.source_span)
            memory = Memory(
                fact=fact.fact,
                source=str(md.get("source")) if md.get("source") is not None else None,
                tags=list(md.get("tags", [])),
                importance=max(0.0, min(1.0, float(fact.importance) / 10.0)),
                source_episode_id=str(md.get("source_episode_id", "")),
                source_text=fact.source_span or content[start:end],
                source_context=self._extract_source_context(content, start, end),
                source_char_start=start,
                source_char_end=end,
                user_id=user_id,
                created_at=datetime.now(UTC),
                last_accessed_at=datetime.now(UTC),
            )
            new_memories.append(memory)

        # Gather vector-search candidates (fast/local, no LLM).
        candidate_pairs: list[CandidatePair] = []
        for memory in new_memories:
            similar_with_dist = self.adapter.search_with_distances(memory.fact, limit=5)
            selected: list[tuple[Memory, float]] = []
            for existing, cosine_dist in similar_with_dist:
                if existing.user_id != user_id or existing.is_deleted:
                    continue
                cosine_similarity = 1.0 - cosine_dist
                if cosine_similarity < SIMILARITY_FLOOR:
                    continue
                selected.append((existing, cosine_similarity))
                candidate_pairs.append(
                    CandidatePair(
                        new_fact_id=memory.id,
                        existing_fact_id=existing.id,
                        new_fact=memory.fact,
                        existing_fact=existing.fact,
                        similarity=cosine_similarity,
                    )
                )
            candidates_map[memory.id] = selected

        # Batched conflict detection (single/few LLM calls with chunking).
        classified = batch_conflict_detection(
            pairs=candidate_pairs,
            cache=self._conflict_decisions,
        )
        by_new_id: dict[str, list[tuple[Memory, str, float, str, str]]] = {}
        for c in classified:
            for existing, sim in candidates_map.get(c.new_fact_id, []):
                if existing.id == c.existing_fact_id:
                    by_new_id.setdefault(c.new_fact_id, []).append(
                        (existing, c.label, c.confidence, c.reason, c.decision_source)
                    )
                    break

        # Apply decisions.
        # Track existing IDs already superseded/updated in this batch to avoid
        # multiple rewrites of the same memory from different extracted facts.
        already_updated_existing_ids: set[str] = set()
        for memory in new_memories:
            decisions_for_new = by_new_id.get(memory.id, [])
            if not decisions_for_new:
                memory_id = self.adapter.add(memory)
                added_mem = self.adapter.get(memory_id)
                added_legacy = self._to_legacy_dict(added_mem)
                added.append(added_legacy)
                self._append_event(
                    "memory.added",
                    {
                        "memory_id": added_legacy["id"],
                        "after_text": added_legacy["text"],
                        "label": "added",
                        "actor": event_actor,
                        "source": event_source,
                        **({"reason": event_reason} if event_reason else {}),
                    },
                )
                continue

            # Choose strongest classified candidate.
            decisions_for_new.sort(key=lambda item: item[2], reverse=True)
            conflicting_existing, label, score, reason, decision_source = decisions_for_new[0]

            # Updates can auto-apply if classifier is confident enough.
            if label == "update" and score >= UPDATE_AUTO_CONFIDENCE:
                # Skip if this existing memory was already updated in this batch
                if conflicting_existing.id in already_updated_existing_ids:
                    memory_id = self.adapter.add(memory)
                    added_mem = self._to_legacy_dict(self.adapter.get(memory_id))
                    added.append(added_mem)
                    self._append_event(
                        "memory.added",
                        {
                            "memory_id": memory_id,
                            "after_text": memory.fact,
                            "label": "added",
                            "actor": event_actor,
                            "source": event_source,
                            **({"reason": event_reason} if event_reason else {}),
                        },
                    )
                    continue
                update_type = classify_update_type(
                    conflicting_existing.fact, memory.fact,
                )
                # Re-fetch existing to get fresh state
                try:
                    conflicting_existing = self.adapter.get(conflicting_existing.id)
                except KeyError:
                    pass
                if update_type.update_type == "inline":
                    added_mem = self._apply_inline_update(
                        conflicting_existing, memory.fact,
                    )
                    added.append(added_mem)
                else:
                    new_result, _old_result = self._apply_supersede_update(
                        conflicting_existing, memory,
                    )
                    added.append(new_result)
                already_updated_existing_ids.add(conflicting_existing.id)
                continue

            # Contradictions or uncertain updates require HITL (or high-importance policy).
            needs_hitl = label == "contradiction" or score < UPDATE_AUTO_CONFIDENCE
            if needs_hitl or max(memory.importance, conflicting_existing.importance) >= HIGH_IMPORTANCE_THRESHOLD:
                conflict = self._to_conflict_record(
                    memory,
                    conflicting_existing,
                    score,
                    label=label,
                    decision_source=decision_source,
                    reason=reason,
                )
                self._pending_conflicts[conflict["id"]] = conflict
                pending.append(conflict)
                self._append_event(
                    "memory.conflict_created",
                    {
                        "conflict_id": conflict["id"],
                        "new_memory_id": memory.id,
                        "existing_memory_id": conflicting_existing.id,
                        "before_text": conflicting_existing.fact,
                        "after_text": memory.fact,
                        "label": label,
                        "confidence": score,
                        "decision_source": decision_source,
                        "reason": reason,
                        "actor": "auto",
                    },
                )
                continue

            # Safety fallback: classify and apply for low-importance residuals.
            if conflicting_existing.id in already_updated_existing_ids:
                memory_id = self.adapter.add(memory)
                added_mem = self._to_legacy_dict(self.adapter.get(memory_id))
                added.append(added_mem)
                self._append_event(
                    "memory.added",
                    {
                        "memory_id": memory_id,
                        "after_text": memory.fact,
                        "label": "added",
                        "actor": "auto",
                        "source": "ingestion",
                    },
                )
                continue
            update_type = classify_update_type(
                conflicting_existing.fact, memory.fact,
            )
            try:
                conflicting_existing = self.adapter.get(conflicting_existing.id)
            except KeyError:
                pass
            if update_type.update_type == "inline":
                added_mem = self._apply_inline_update(
                    conflicting_existing, memory.fact,
                )
                added.append(added_mem)
            else:
                new_result, _old_result = self._apply_supersede_update(
                    conflicting_existing, memory,
                )
                added.append(new_result)
            already_updated_existing_ids.add(conflicting_existing.id)

        if pending:
            self._save_conflicts()
        if candidate_pairs:
            self._save_conflict_decisions()

        primary_id = added[0]["id"] if added else ""
        return {
            "id": primary_id,
            "added": added,
            "pending_conflicts": pending,
            "added_count": len(added),
            "pending_count": len(pending),
        }

    def add_memory(self, memory: Memory) -> str:
        """Add a fully specified thesis Memory model."""
        return self.adapter.add(memory)

    def search(
        self,
        query: str,
        user_id: str = "default",
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """Semantic search over native storage."""
        results = self.adapter.search(query, limit=limit)
        filtered = [m for m in results if m.user_id == user_id and not m.is_deleted]
        for m in filtered:
            m.last_accessed_at = datetime.now(UTC)
            self.adapter.update(m.id, metadata={"last_accessed_at": m.last_accessed_at})
        return [self._to_legacy_dict(m) for m in filtered]

    def get_all(self, user_id: str = "default") -> list[dict[str, Any]]:
        """Get all non-deleted memories for a user."""
        memories, _ = self.adapter.get_all_with_embeddings()
        return [
            self._to_legacy_dict(m)
            for m in memories
            if m.user_id == user_id and not m.is_deleted
        ]

    def get_all_with_embeddings(self) -> tuple[list[dict[str, Any]], np.ndarray]:
        """Get all memories and embeddings for projection."""
        memories, embedding_array = self.adapter.get_all_with_embeddings()
        active = [m for m in memories if not m.is_deleted]
        if active and embedding_array.shape[0] == len(memories):
            active_ids = {m.id for m in active}
            filtered_rows = [
                idx for idx, m in enumerate(memories) if m.id in active_ids
            ]
            embedding_array = embedding_array[filtered_rows]
        return [self._to_legacy_dict(m) for m in active], embedding_array

    def delete(
        self,
        memory_id: str,
        *,
        actor: str = "human",
        source: str = "manual_curation",
        reason: str | None = None,
    ) -> dict[str, Any]:
        """Soft delete a memory."""
        current = self.adapter.get(memory_id)
        self.adapter.delete(memory_id, soft=True)
        self._append_event(
            "memory.deleted",
            {
                "memory_id": memory_id,
                "before_text": current.fact,
                "actor": actor,
                "source": source,
                **({"reason": reason} if reason else {}),
            },
        )
        return {"id": memory_id, "deleted": True}

    def update(
        self,
        memory_id: str,
        content: str,
        *,
        actor: str = "human",
        source: str = "manual_curation",
        reason: str | None = None,
    ) -> dict[str, Any]:
        """Update memory fact text."""
        current = self.adapter.get(memory_id)
        new_version = current.version + 1
        self._append_event(
            "memory.updated",
            {
                "memory_id": memory_id,
                "before_text": current.fact,
                "after_text": content,
                "version": new_version,
                "actor": actor,
                "source": source,
                **({"reason": reason} if reason else {}),
            },
        )
        self.adapter.update(memory_id, fact=content, metadata={"version": new_version})
        updated = self.adapter.get(memory_id)
        return self._to_legacy_dict(updated)

    def get(self, memory_id: str) -> dict[str, Any]:
        """Get a specific memory by ID."""
        return self._to_legacy_dict(self.adapter.get(memory_id))

    def tag(self, memory_id: str, tags: list[str]) -> dict[str, Any]:
        """Set tags on a memory (replaces existing tags)."""
        current = self.adapter.get(memory_id)
        merged_tags = list(dict.fromkeys(current.tags + tags))
        self.adapter.update(memory_id, metadata={"tags": merged_tags})
        updated = self.adapter.get(memory_id)
        return self._to_legacy_dict(updated)

    def merge(
        self,
        memory_ids: list[str],
        merged_text: str,
        user_id: str = "default",
        *,
        actor: str = "agent",
        source: str = "curator_agent",
        reason: str | None = None,
    ) -> dict[str, Any]:
        """Merge multiple memories into one without fact extraction.

        Soft-deletes the originals, creates a single merged memory, and
        records one ``memory.merge_applied`` event with full provenance.
        Returns the legacy dict for the new merged memory.
        """
        # Collect original texts before deleting
        originals: list[dict[str, str]] = []
        for mid in memory_ids:
            try:
                current = self.adapter.get(mid)
                originals.append({"id": mid, "text": current.fact})
                self.adapter.delete(mid, soft=True)
            except Exception:
                originals.append({"id": mid, "text": "(unavailable)"})

        # Add merged memory directly — bypass fact extraction
        merged_memory = Memory(
            fact=merged_text,
            user_id=user_id,
            source=source,
            tags=["merged"],
            importance=0.7,
        )
        new_id = self.adapter.add(merged_memory)

        # Record a single merge event
        self._append_event(
            "memory.merge_applied",
            {
                "memory_id": new_id,
                "new_memory_id": new_id,
                "merged_memory_ids": memory_ids,
                "merged_texts": [o["text"] for o in originals],
                "after_text": merged_text,
                "resolution": "merge",
                "actor": actor,
                "source": source,
                **({"reason": reason} if reason else {}),
            },
        )

        created = self.adapter.get(new_id)
        return self._to_legacy_dict(created)

    def list_pending_conflicts(self, status: str = "pending") -> list[dict[str, Any]]:
        """List pending or resolved conflicts."""
        if status == "all":
            return list(self._pending_conflicts.values())
        return [
            c for c in self._pending_conflicts.values()
            if c.get("status") == status
        ]

    def get_conflict_severity_by_memory_id(self) -> dict[str, float]:
        """Map memory ID -> max conflict severity for visualization coloring."""
        severity: dict[str, float] = {}
        for conflict in self._pending_conflicts.values():
            if conflict.get("status") != "pending":
                continue
            existing = (conflict.get("existing_fact") or {}).get("id")
            if not existing:
                continue
            current = severity.get(existing, 0.0)
            sev = self._conflict_severity(conflict)
            if sev > current:
                severity[existing] = sev
        return severity

    def resolve_conflict(
        self,
        conflict_id: str,
        resolution: str,
        merged_text: str | None = None,
    ) -> dict[str, Any]:
        """Apply human conflict decision and persist resolved state."""
        if conflict_id not in self._pending_conflicts:
            raise KeyError(f"Conflict '{conflict_id}' not found")

        conflict = self._pending_conflicts[conflict_id]
        if conflict.get("status") == "resolved":
            return conflict

        new_fact = conflict["new_fact"]
        existing_fact = conflict["existing_fact"]
        now_iso = datetime.now(UTC).isoformat()

        def _memory_from_legacy(raw: dict[str, Any]) -> Memory:
            meta = raw.get("metadata") or {}
            return Memory(
                fact=raw.get("text", ""),
                source=meta.get("source"),
                tags=list(meta.get("tags", [])),
                importance=float(meta.get("importance", 0.5)),
                source_episode_id=str(meta.get("source_episode_id", "")),
                source_text=str(meta.get("source_text", raw.get("text", ""))),
                source_context=str(meta.get("source_context", raw.get("text", ""))),
                source_char_start=int(meta.get("source_char_start", 0) or 0),
                source_char_end=int(meta.get("source_char_end", len(raw.get("text", ""))) or len(raw.get("text", ""))),
                user_id=str(meta.get("user_id", "default")),
                created_at=datetime.now(UTC),
                last_accessed_at=datetime.now(UTC),
            )

        # Normalize legacy alias
        if resolution == "supersede_old":
            resolution = "keep_new"

        if resolution == "keep_new":
            self.adapter.update(existing_fact["id"], metadata={"valid_until": datetime.now(UTC)})
            existing_mem = _memory_from_legacy(existing_fact)
            try:
                existing_stored = self.adapter.get(existing_fact["id"])
                existing_version = existing_stored.version
            except KeyError:
                existing_version = 1
            new_mem = _memory_from_legacy(new_fact)
            new_mem.version = existing_version + 1
            new_mem.supersedes_id = existing_fact["id"]
            created_id = self.adapter.add(new_mem)
            self._append_event(
                "memory.conflict_resolved",
                {
                    "conflict_id": conflict_id,
                    "resolution": resolution,
                    "existing_memory_id": existing_fact["id"],
                    "new_memory_id": created_id,
                    "before_text": existing_fact.get("text", ""),
                    "after_text": new_fact.get("text", ""),
                    "label": conflict.get("label", "contradiction"),
                    "reason": conflict.get("reason", ""),
                    "decision_source": conflict.get("decision_source", "model"),
                    "actor": "human",
                },
            )
        elif resolution == "keep_existing":
            self._append_event(
                "memory.conflict_resolved",
                {
                    "conflict_id": conflict_id,
                    "resolution": resolution,
                    "existing_memory_id": existing_fact["id"],
                    "new_memory_id": new_fact["id"],
                    "before_text": existing_fact.get("text", ""),
                    "after_text": existing_fact.get("text", ""),
                    "label": conflict.get("label", "contradiction"),
                    "reason": conflict.get("reason", ""),
                    "decision_source": conflict.get("decision_source", "model"),
                    "actor": "human",
                },
            )
        elif resolution == "keep_both":
            created_id = self.adapter.add(_memory_from_legacy(new_fact))
            self._append_event(
                "memory.conflict_resolved",
                {
                    "conflict_id": conflict_id,
                    "resolution": resolution,
                    "existing_memory_id": existing_fact["id"],
                    "new_memory_id": created_id,
                    "before_text": existing_fact.get("text", ""),
                    "after_text": new_fact.get("text", ""),
                    "label": conflict.get("label", "contradiction"),
                    "reason": conflict.get("reason", ""),
                    "decision_source": conflict.get("decision_source", "model"),
                    "actor": "human",
                },
            )
        elif resolution == "merge":
            merged = (merged_text or "").strip()
            if not merged:
                raise ValueError("merged_text is required for merge resolution")
            self.adapter.update(existing_fact["id"], metadata={"valid_until": datetime.now(UTC)})
            try:
                existing_stored = self.adapter.get(existing_fact["id"])
                existing_version = existing_stored.version
            except KeyError:
                existing_version = 1
            created_id = self.adapter.add(
                Memory(
                    fact=merged,
                    source=((new_fact.get("metadata") or {}).get("source")),
                    importance=max(
                        float((existing_fact.get("metadata") or {}).get("importance", 0.5)),
                        float((new_fact.get("metadata") or {}).get("importance", 0.5)),
                    ),
                    tags=list({
                        *(((existing_fact.get("metadata") or {}).get("tags")) or []),
                        *(((new_fact.get("metadata") or {}).get("tags")) or []),
                    }),
                    source_episode_id=str((new_fact.get("metadata") or {}).get("source_episode_id", "")),
                    source_text=f"{(existing_fact.get('metadata') or {}).get('source_text', '')} + {(new_fact.get('metadata') or {}).get('source_text', '')}",
                    source_context=f"{(existing_fact.get('metadata') or {}).get('source_context', '')} {(new_fact.get('metadata') or {}).get('source_context', '')}".strip(),
                    source_char_start=0,
                    source_char_end=0,
                    user_id=str((new_fact.get("metadata") or {}).get("user_id", "default")),
                    created_at=datetime.now(UTC),
                    last_accessed_at=datetime.now(UTC),
                    version=existing_version + 1,
                    supersedes_id=existing_fact["id"],
                )
            )
            self._append_event(
                "memory.merge_applied",
                {
                    "conflict_id": conflict_id,
                    "existing_memory_id": existing_fact["id"],
                    "new_memory_id": created_id,
                    "resolution": resolution,
                    "before_text": existing_fact.get("text", ""),
                    "incoming_text": new_fact.get("text", ""),
                    "after_text": merged,
                    "label": conflict.get("label", "contradiction"),
                    "reason": conflict.get("reason", ""),
                    "decision_source": conflict.get("decision_source", "model"),
                    "actor": "human",
                },
            )
        else:
            raise ValueError(
                "resolution must be one of keep_new|keep_existing|keep_both|merge"
            )

        conflict["status"] = "resolved"
        conflict["resolution"] = resolution
        conflict["resolved_at"] = now_iso
        self._save_conflicts()
        return conflict

    def suggest_merge_text(self, conflict_id: str) -> str:
        """Look up a conflict and return an LLM-suggested merge of both texts."""
        if conflict_id not in self._pending_conflicts:
            raise KeyError(f"Conflict '{conflict_id}' not found")
        conflict = self._pending_conflicts[conflict_id]
        existing_text = (conflict.get("existing_fact") or {}).get("text", "")
        new_text = (conflict.get("new_fact") or {}).get("text", "")
        reason = conflict.get("reason", "")
        return suggest_merge(existing_text, new_text, reason=reason)
