from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Literal

import instructor
from openai import OpenAI
from pydantic import BaseModel, Field

from bonsai_core.models import Memory

CONFLICT_THRESHOLD = 0.7
HIGH_IMPORTANCE_THRESHOLD = 0.7
SIMILARITY_FLOOR = 0.75  # cosine similarity floor (1 - distance)
MAX_CONFLICT_PAIRS_PER_CALL = 150
PROMPT_VERSION = "v2_strict_subject_incompatibility"


class ConflictPair(BaseModel):
    """Detected relationship between a new fact and an existing candidate."""

    new_fact_id: str
    existing_fact_id: str
    label: str = Field(description="One of: contradiction, update, compatible")
    confidence: float = Field(ge=0.0, le=1.0)
    reason: str
    decision_source: str = Field(default="model", description="model or cache")


class ConflictCheckResult(BaseModel):
    """Structured output for batched conflict checks."""

    conflicts: list[ConflictPair] = Field(default_factory=list)


@dataclass
class CandidatePair:
    """Candidate pair for LLM conflict classification."""

    new_fact_id: str
    existing_fact_id: str
    new_fact: str
    existing_fact: str
    similarity: float


def _normalize_fact_text(text: str) -> str:
    return " ".join(text.lower().split())


def build_decision_cache_key(
    new_fact: str,
    existing_fact: str,
    model: str,
) -> str:
    """Order-insensitive cache key for conflict decisions."""
    a = _normalize_fact_text(new_fact)
    b = _normalize_fact_text(existing_fact)
    left, right = sorted([a, b])
    return f"{model}|{PROMPT_VERSION}|{left}|{right}"


def _iter_chunks(items: list[CandidatePair], chunk_size: int) -> list[list[CandidatePair]]:
    return [items[i : i + chunk_size] for i in range(0, len(items), chunk_size)]


def _classify_chunk(
    chunk: list[CandidatePair],
    model: str,
) -> list[ConflictPair]:
    if not chunk:
        return []

    groq_key = os.environ.get("GROQ_API_KEY")
    use_groq = bool(groq_key and model.startswith("meta-llama/"))
    raw_client = OpenAI(
        base_url="https://api.groq.com/openai/v1",
        api_key=groq_key,
    ) if use_groq else OpenAI()
    client = instructor.from_openai(raw_client)
    pairs_text = "\n".join(
        f"- pair_id={i}: new_id={p.new_fact_id}, existing_id={p.existing_fact_id}\n"
        f"  NEW: {p.new_fact}\n"
        f"  EXISTING: {p.existing_fact}"
        for i, p in enumerate(chunk, start=1)
    )

    result = client.chat.completions.create(
        model=model,
        response_model=ConflictCheckResult,
        messages=[
            {
                "role": "system",
                "content": (
                    "You classify whether pairs of memory facts conflict.\n\n"
                    "Labels:\n"
                    "- update: the new fact is a clear temporal progression that replaces the old "
                    "(job change, promotion, relocation, plan change). Auto-applied.\n"
                    "- contradiction: the facts disagree and it's unclear which is correct. "
                    "Requires human review.\n"
                    "- compatible: the facts can both be true. Most pairs are this.\n\n"
                    "Examples:\n"
                    "- 'X is at Google' vs 'X left Google' → update\n"
                    "- 'X is an Engineer' vs 'X was promoted to VP' → update\n"
                    "- 'X is joining Anthropic' vs 'X decided not to join Anthropic' → update\n"
                    "- 'X works on model serving' vs 'X joined OpenAI' → compatible (could do that at OpenAI)\n"
                    "- 'X does Kubernetes' vs 'Y does Kubernetes' → compatible (different people)\n"
                    "- 'X is at Company A' vs 'X is at Company B' (no indication of change) → contradiction\n\n"
                    "When in doubt, choose compatible."
                ),
            },
            {
                "role": "user",
                "content": f"Classify these pairs:\n\n{pairs_text}",
            },
        ],
    )
    return result.conflicts


def detect_conflict(new_fact: str, existing_fact: str) -> tuple[str, float]:
    """Compatibility helper for single-pair conflict checks.

    Internally delegates to batched logic with a single candidate.
    """
    model = os.environ.get("BONSAI_CONFLICT_MODEL", "gpt-5-nano")
    try:
        classified = _classify_chunk(
            [
                CandidatePair(
                    new_fact_id="new",
                    existing_fact_id="existing",
                    new_fact=new_fact,
                    existing_fact=existing_fact,
                    similarity=1.0,
                )
            ],
            model=model,
        )
        if not classified:
            return "compatible", 0.0
        return classified[0].label, classified[0].confidence
    except Exception:
        # Lightweight fallback when LLM is unavailable
        return "compatible", 0.0


def batch_conflict_detection(
    pairs: list[CandidatePair],
    cache: dict[str, dict] | None = None,
    model: str | None = None,
) -> list[ConflictPair]:
    """Classify candidate pairs via chunked batched LLM calls.

    Only returns positive labels (contradiction/update). Compatible pairs are
    still cached but omitted from the returned list to reduce downstream work.
    """
    chosen_model = model or os.environ.get("BONSAI_CONFLICT_MODEL", "gpt-5-nano")
    decision_cache = cache if cache is not None else {}
    positives: list[ConflictPair] = []
    to_classify: list[CandidatePair] = []

    for pair in pairs:
        key = build_decision_cache_key(pair.new_fact, pair.existing_fact, chosen_model)
        cached = decision_cache.get(key)
        if cached is not None:
            label = str(cached.get("label", "compatible"))
            conf = float(cached.get("confidence", 0.0))
            reason = str(cached.get("reason", "cached decision"))
            if label in {"contradiction", "update"}:
                positives.append(
                    ConflictPair(
                        new_fact_id=pair.new_fact_id,
                        existing_fact_id=pair.existing_fact_id,
                        label=label,
                        confidence=conf,
                        reason=reason,
                        decision_source="cache",
                    )
                )
            continue
        to_classify.append(pair)

    for chunk in _iter_chunks(to_classify, MAX_CONFLICT_PAIRS_PER_CALL):
        try:
            classified = _classify_chunk(chunk, model=chosen_model)
            # Index by pair ids for deterministic cache updates.
            by_ids = {
                (c.new_fact_id, c.existing_fact_id): c
                for c in classified
            }
            for pair in chunk:
                c = by_ids.get((pair.new_fact_id, pair.existing_fact_id))
                if c is None:
                    c = ConflictPair(
                        new_fact_id=pair.new_fact_id,
                        existing_fact_id=pair.existing_fact_id,
                        label="compatible",
                        confidence=0.0,
                        reason="model omitted pair; treated as compatible",
                        decision_source="model",
                    )
                key = build_decision_cache_key(pair.new_fact, pair.existing_fact, chosen_model)
                decision_cache[key] = {
                    "label": c.label,
                    "confidence": c.confidence,
                    "reason": c.reason,
                }
                if c.label in {"contradiction", "update"}:
                    positives.append(c)
        except Exception:
            # Conservative fallback: mark all failed chunk pairs as compatible.
            for pair in chunk:
                key = build_decision_cache_key(pair.new_fact, pair.existing_fact, chosen_model)
                decision_cache[key] = {
                    "label": "compatible",
                    "confidence": 0.0,
                    "reason": "batch conflict detection failed",
                }

    return positives


class MergeSuggestion(BaseModel):
    """Structured output for LLM merge suggestion."""

    merged_text: str = Field(description="A single concise merged fact")


def suggest_merge(
    existing_text: str,
    new_text: str,
    reason: str = "",
    model: str | None = None,
) -> str:
    """Use an LLM to suggest merged text from two conflicting facts.

    Returns the suggested merged text string.
    """
    chosen_model = model or os.environ.get("BONSAI_LLM_MODEL", "gpt-4o-mini")

    groq_key = os.environ.get("GROQ_API_KEY")
    use_groq = bool(groq_key and chosen_model.startswith("meta-llama/"))
    raw_client = OpenAI(
        base_url="https://api.groq.com/openai/v1",
        api_key=groq_key,
    ) if use_groq else OpenAI()
    client = instructor.from_openai(raw_client)

    reason_clause = f"\nReason for conflict: {reason}" if reason else ""

    result = client.chat.completions.create(
        model=chosen_model,
        response_model=MergeSuggestion,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are merging two memory facts about the same person or subject "
                    "into a single, coherent fact.\n\n"
                    "Rules:\n"
                    "- Write ONE natural sentence (two short sentences at most) that "
                    "captures the key information from both facts.\n"
                    "- If the facts describe different events or roles, weave them into "
                    "a single coherent narrative (e.g. timeline, career moves).\n"
                    "- If the facts directly contradict, prefer the newer information "
                    "but note the context if relevant.\n"
                    "- NEVER just put the two facts side by side separated by slashes, "
                    "semicolons, 'and', or any delimiter. Synthesize, don't concatenate.\n"
                    "- Do NOT add information that isn't in either fact.\n\n"
                    "Example:\n"
                    "  Existing: 'Rachel Adams is joining Anthropic in Q1 2025'\n"
                    "  New: 'Rachel Adams will start her position at UC Berkeley in Fall 2025'\n"
                    "  Good: 'Rachel Adams is joining Anthropic in Q1 2025 and will later "
                    "transition to a position at UC Berkeley starting Fall 2025.'\n"
                    "  Bad: 'Rachel Adams is joining Anthropic in Q1 2025 / Rachel Adams "
                    "will start her position at UC Berkeley in Fall 2025'"
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Existing fact: {existing_text}\n"
                    f"New fact: {new_text}"
                    f"{reason_clause}"
                ),
            },
        ],
    )
    return result.merged_text


def is_high_importance_conflict(
    new_memory: Memory,
    existing_memory: Memory,
    score: float,
) -> bool:
    """Whether this contradiction should be escalated to HITL resolution."""
    if score < CONFLICT_THRESHOLD:
        return False
    return (
        new_memory.importance >= HIGH_IMPORTANCE_THRESHOLD
        or existing_memory.importance >= HIGH_IMPORTANCE_THRESHOLD
    )


# ── Temporal-aware update classification ────────────────────────────────────


class UpdateTypeResult(BaseModel):
    """Structured output for update type classification."""

    update_type: Literal["inline", "supersede"] = Field(
        description="inline = same fact with updated value; supersede = new fact that historicizes old"
    )
    confidence: float = Field(ge=0.0, le=1.0)
    reason: str


class PastTenseRewrite(BaseModel):
    """Structured output for past-tense rewriting."""

    rewritten_fact: str = Field(description="The fact rewritten to past tense")


def classify_update_type(
    existing_fact: str,
    new_fact: str,
    model: str | None = None,
) -> UpdateTypeResult:
    """Classify whether an update should be inline (edit in place) or supersede.

    - **inline**: same assertion with an updated value (e.g. follower count change).
    - **supersede**: a life event/transition that historicizes the old fact
      (e.g. job change, relocation).
    """
    chosen_model = model or os.environ.get("BONSAI_CONFLICT_MODEL", "gpt-5-nano")

    groq_key = os.environ.get("GROQ_API_KEY")
    use_groq = bool(groq_key and chosen_model.startswith("meta-llama/"))
    raw_client = OpenAI(
        base_url="https://api.groq.com/openai/v1",
        api_key=groq_key,
    ) if use_groq else OpenAI()
    client = instructor.from_openai(raw_client)

    try:
        result = client.chat.completions.create(
            model=chosen_model,
            response_model=UpdateTypeResult,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You classify whether a memory update should be applied inline "
                        "or as a supersede.\n\n"
                        "inline: The new fact is the same assertion with an updated value. "
                        "The old fact can simply be replaced with the new one. Examples:\n"
                        "- '1000 followers' → '5000 followers'\n"
                        "- 'salary is $100k' → 'salary is $120k'\n"
                        "- 'team size is 5' → 'team size is 8'\n\n"
                        "supersede: The new fact describes a life event, transition, or "
                        "change that makes the old fact historical. The old fact should "
                        "be rewritten to past tense and kept for history. Examples:\n"
                        "- 'works at Google' + 'joined OpenAI' → supersede\n"
                        "- 'lives in SF' + 'relocated to NYC' → supersede\n"
                        "- 'is an engineer' + 'was promoted to VP' → supersede\n\n"
                        "When in doubt, choose supersede (safer to preserve history)."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Existing fact: {existing_fact}\n"
                        f"New fact: {new_fact}"
                    ),
                },
            ],
        )
        return result
    except Exception:
        # Conservative fallback: treat as supersede
        return UpdateTypeResult(
            update_type="supersede",
            confidence=0.0,
            reason="classification failed; defaulting to supersede",
        )


def _simple_past_tense(text: str, as_of_date: str | None = None) -> str:
    """Regex-based fallback for common present→past tense verbs."""
    import re as _re

    replacements = [
        (r'\bis\b', 'was'),
        (r'\bare\b', 'were'),
        (r'\bworks\b', 'worked'),
        (r'\bleads\b', 'led'),
        (r'\bruns\b', 'ran'),
        (r'\bmanages\b', 'managed'),
        (r'\bheads\b', 'headed'),
        (r'\bfocuses\b', 'focused'),
        (r'\bbuilds\b', 'built'),
        (r'\bdevelops\b', 'developed'),
        (r'\bserves\b', 'served'),
        (r'\bhas\b', 'had'),
        (r'\bspecializes\b', 'specialized'),
        (r'\boversees\b', 'oversaw'),
    ]
    result = text
    for pattern, replacement in replacements:
        result = _re.sub(pattern, replacement, result, count=1, flags=_re.IGNORECASE)
        if result != text:
            break  # One verb change is enough

    suffix = f" (until {as_of_date})" if as_of_date else ""
    if result == text:
        # No verb found to change — prefix as last resort
        return f"{text} [no longer current]{suffix}"
    return f"{result}{suffix}"


def rewrite_to_past_tense(
    fact_text: str,
    as_of_date: str | None = None,
    model: str | None = None,
) -> str:
    """Rewrite a present-tense fact to past tense using an LLM.

    Optionally includes an "until {date}" clause.
    """
    chosen_model = model or os.environ.get("BONSAI_CONFLICT_MODEL", "gpt-5-nano")

    groq_key = os.environ.get("GROQ_API_KEY")
    use_groq = bool(groq_key and chosen_model.startswith("meta-llama/"))
    raw_client = OpenAI(
        base_url="https://api.groq.com/openai/v1",
        api_key=groq_key,
    ) if use_groq else OpenAI()
    client = instructor.from_openai(raw_client)

    date_clause = f" Include '(until {as_of_date})' at the end." if as_of_date else ""

    try:
        result = client.chat.completions.create(
            model=chosen_model,
            response_model=PastTenseRewrite,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Rewrite the given fact to past tense. Keep it concise and "
                        "factual. Do not add information that isn't in the original.\n\n"
                        "Examples:\n"
                        "- 'Jon Smith is a Senior ML Engineer at Google' → "
                        "'Jon Smith was a Senior ML Engineer at Google'\n"
                        "- 'Yuki Tanaka is a Managing Director at Goldman Sachs' → "
                        "'Yuki Tanaka was a Managing Director at Goldman Sachs'\n"
                        "- 'She leads the digital assets division' → "
                        "'She led the digital assets division'\n\n"
                        "IMPORTANT: The output MUST be different from the input. "
                        "Change present-tense verbs (is, are, works, leads, runs) "
                        "to past tense (was, were, worked, led, ran)."
                        f"{date_clause}"
                    ),
                },
                {
                    "role": "user",
                    "content": fact_text,
                },
            ],
        )
        rewritten = result.rewritten_fact
        # If LLM returned the same text, use regex-based fallback
        if _normalize_fact_text(rewritten) == _normalize_fact_text(fact_text):
            return _simple_past_tense(fact_text, as_of_date)
        # Append date suffix if the LLM didn't include it
        if as_of_date and as_of_date.lower() not in rewritten.lower():
            rewritten = f"{rewritten.rstrip('.')} (until {as_of_date})"
        return rewritten
    except Exception:
        return _simple_past_tense(fact_text, as_of_date)
