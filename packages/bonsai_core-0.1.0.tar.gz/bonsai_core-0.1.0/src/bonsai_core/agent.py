"""Curator Agent for BonsAI.

Uses pydantic-ai to define an LLM agent with tools for memory curation.
Read-only operations (search, inspect, summarize, suggest cleanup, tag,
find duplicates) execute automatically. Meaning-changing operations
(update, delete, merge) require human approval via pydantic-ai's native
``DeferredToolRequests`` / ``requires_approval=True`` mechanism.
"""

from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
import re
from typing import Any

from pydantic_ai import Agent, RunContext
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.tools import DeferredToolRequests
from pydantic_ai.providers.openai import OpenAIProvider

from bonsai_core.memory import MemoryStore

logger = logging.getLogger("bonsai_core.agent")


@dataclass
class CuratorDeps:
    """Runtime dependencies injected into every tool call."""

    store: MemoryStore
    user_id: str = "default"
    event_bus: Any = field(default=None, repr=False)


DEFAULT_CURATOR_MODEL = "openai:gpt-4o-mini"
DEFAULT_OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
_STOPWORDS = {
    "about",
    "after",
    "again",
    "agent",
    "agents",
    "been",
    "being",
    "between",
    "from",
    "have",
    "into",
    "just",
    "memory",
    "memories",
    "more",
    "most",
    "only",
    "over",
    "same",
    "some",
    "such",
    "than",
    "that",
    "their",
    "them",
    "then",
    "there",
    "these",
    "they",
    "this",
    "those",
    "through",
    "very",
    "were",
    "what",
    "when",
    "where",
    "which",
    "with",
    "would",
}


def _memory_text(memory: dict[str, Any]) -> str:
    return str(memory.get("memory") or memory.get("text") or "").strip()


def _memory_metadata(memory: dict[str, Any]) -> dict[str, Any]:
    metadata = memory.get("metadata")
    return metadata if isinstance(metadata, dict) else {}


def _parse_datetime(value: Any) -> datetime | None:
    if not value or not isinstance(value, str):
        return None
    try:
        normalized = value.replace("Z", "+00:00")
        dt = datetime.fromisoformat(normalized)
        return dt if dt.tzinfo else dt.replace(tzinfo=UTC)
    except ValueError:
        return None


def _extract_top_terms(texts: list[str], limit: int = 6) -> list[str]:
    terms: list[str] = []
    for text in texts:
        for token in re.findall(r"[A-Za-z][A-Za-z0-9_-]{3,}", text.lower()):
            if token not in _STOPWORDS:
                terms.append(token)
    return [term for term, _ in Counter(terms).most_common(limit)]


def _summarize_memory_set(memories: list[dict[str, Any]]) -> str:
    if not memories:
        return "No memories available for summarization."

    texts = [_memory_text(memory) for memory in memories if _memory_text(memory)]
    tag_counts: Counter[str] = Counter()
    source_counts: Counter[str] = Counter()
    importances: list[float] = []
    created_dates: list[datetime] = []

    for memory in memories:
        metadata = _memory_metadata(memory)
        for tag in metadata.get("tags", []) or []:
            if isinstance(tag, str) and tag.strip():
                tag_counts[tag.strip()] += 1
        source = metadata.get("source")
        if isinstance(source, str) and source.strip():
            source_counts[source.strip()] += 1
        importance = metadata.get("importance")
        if isinstance(importance, (int, float)):
            importances.append(float(importance))
        created = _parse_datetime(metadata.get("created_at"))
        if created is not None:
            created_dates.append(created)

    lines = [f"Summary for {len(memories)} memories:"]
    if texts:
        lines.append(
            f"- Representative themes: {', '.join(_extract_top_terms(texts)) or 'No strong repeated terms'}"
        )
    if tag_counts:
        top_tags = ", ".join(f"{tag} ({count})" for tag, count in tag_counts.most_common(5))
        lines.append(f"- Common tags: {top_tags}")
    if source_counts:
        top_sources = ", ".join(
            f"{source} ({count})" for source, count in source_counts.most_common(3)
        )
        lines.append(f"- Sources: {top_sources}")
    if importances:
        lines.append(f"- Average importance: {sum(importances) / len(importances):.2f}")
    if created_dates:
        lines.append(
            f"- Time span: {min(created_dates).date().isoformat()} to {max(created_dates).date().isoformat()}"
        )
    lines.append("- Representative memories:")
    for memory in memories[:3]:
        lines.append(f"  - [{memory.get('id', 'unknown')}] {_memory_text(memory)[:160]}")
    return "\n".join(lines)


def _find_duplicate_groups(store: MemoryStore, user_id: str, threshold: int) -> list[set[str]]:
    all_memories = store.get_all(user_id=user_id)
    if not all_memories:
        return []

    id_to_text: dict[str, str] = {}
    for memory in all_memories:
        memory_id = memory.get("id", "")
        text = _memory_text(memory)
        if memory_id and text:
            id_to_text[memory_id] = text

    groups: list[set[str]] = []
    seen_pairs: set[tuple[str, str]] = set()
    for memory_id, text in id_to_text.items():
        results = store.search(text, user_id=user_id, limit=threshold)
        for result in results:
            result_id = result.get("id", "")
            if not result_id or result_id == memory_id:
                continue
            pair = tuple(sorted((memory_id, result_id)))
            if pair in seen_pairs:
                continue
            seen_pairs.add(pair)
            merged = False
            for group in groups:
                if memory_id in group or result_id in group:
                    group.update({memory_id, result_id})
                    merged = True
                    break
            if not merged:
                groups.append({memory_id, result_id})
    return groups


def _resolve_curator_model(
    model: str | None,
    base_url: str | None,
    api_key: str | None,
) -> str | OpenAIChatModel:
    model_name = model or DEFAULT_CURATOR_MODEL
    if base_url or api_key:
        provider = OpenAIProvider(base_url=base_url, api_key=api_key)
        bare_model_name = model_name.split(":", 1)[1] if ":" in model_name else model_name
        return OpenAIChatModel(bare_model_name, provider=provider)
    return model_name


SYSTEM_PROMPT = """\
You are the BonsAI Memory Curator, an intelligent assistant that helps \
humans understand and manage the long-term memories of AI agents.

You have a persistent conversation — you remember everything the user and \
you have discussed in this session. When the user refers to something from \
an earlier message (e.g. "yes, do it", "proceed", "merge those"), use the \
conversation history to understand what they mean.

Your capabilities:
- **Search** memories by semantic similarity.
- **Inspect** individual memories in detail.
- **Summarize** groups of memories so users understand what a result set is about.
- **Tag** memories with additional labels for organisation.
- **Find duplicates** among stored memories.
- **Suggest cleanup actions** for duplicate, stale, low-value, or poorly organised memories.
- **Delete** memories that are outdated, irrelevant, or incorrect.
- **Merge** related memories into a single, consolidated memory.
- **Propose updates** to improve memory wording while preserving meaning.

Important rules:
1. Destructive operations (update, delete, merge) will be paused for human \
approval before they execute. You should call the tool when the user asks \
you to proceed — the system handles the approval step automatically.
2. Always explain *why* you recommend a destructive or meaning-changing action.
3. When the user confirms a previously discussed action (e.g. "yes", \
"proceed", "go ahead", "do it"), call the appropriate tool with the \
IDs and text from the earlier conversation. Do NOT just describe the \
action in prose — you must invoke the tool so the approval flow triggers.
4. Preserve important context — never silently discard information during a merge or rewrite.
"""


def create_curator_agent(
    model: str = DEFAULT_CURATOR_MODEL,
    *,
    base_url: str | None = None,
    api_key: str | None = None,
) -> Agent:
    """Create and return a fully-configured Curator Agent."""

    agent: Agent[CuratorDeps, str | DeferredToolRequests] = Agent(
        _resolve_curator_model(model, base_url, api_key),
        deps_type=CuratorDeps,
        output_type=[str, DeferredToolRequests],  # type: ignore[arg-type]
        system_prompt=SYSTEM_PROMPT,
    )

    @agent.tool
    async def search_memories(
        ctx: RunContext[CuratorDeps],
        query: str,
        limit: int = 20,
    ) -> str:
        results: list[dict[str, Any]] = ctx.deps.store.search(
            query,
            user_id=ctx.deps.user_id,
            limit=limit,
        )
        if not results:
            return "No memories matched your query."

        lines: list[str] = []
        for i, mem in enumerate(results, 1):
            mem_id = mem.get("id", "unknown")
            text = _memory_text(mem)
            score = mem.get("score", "")
            score_str = f" (score: {score:.4f})" if isinstance(score, float) else ""
            lines.append(f"{i}. [{mem_id}]{score_str}\n   {text}")
        return f"Found {len(results)} memories:\n\n" + "\n\n".join(lines)

    @agent.tool
    async def get_memory_detail(
        ctx: RunContext[CuratorDeps],
        memory_id: str,
    ) -> str:
        mem: dict[str, Any] = ctx.deps.store.get(memory_id)
        if not mem:
            return f"Memory '{memory_id}' not found."

        metadata = _memory_metadata(mem)
        parts = [f"Memory ID: {mem.get('id', memory_id)}", f"Text: {_memory_text(mem)}"]
        if metadata:
            parts.append("Metadata:")
            for key, value in metadata.items():
                parts.append(f"  {key}: {value}")
        return "\n".join(parts)

    @agent.tool
    async def summarize_memories(
        ctx: RunContext[CuratorDeps],
        memory_ids: list[str] | None = None,
        query: str | None = None,
        limit: int = 10,
    ) -> str:
        selected: list[dict[str, Any]] = []
        if memory_ids:
            for memory_id in memory_ids:
                try:
                    selected.append(ctx.deps.store.get(memory_id))
                except Exception:
                    continue
        elif query:
            selected = ctx.deps.store.search(query, user_id=ctx.deps.user_id, limit=limit)
        else:
            selected = ctx.deps.store.get_all(user_id=ctx.deps.user_id)[:limit]
        selected = [memory for memory in selected if _memory_text(memory)]
        return _summarize_memory_set(selected)

    @agent.tool
    async def tag_memories(
        ctx: RunContext[CuratorDeps],
        memory_ids: list[str],
        tags: list[str],
    ) -> str:
        """Add tags to memories (merges with existing tags)."""
        updated: list[str] = []
        for memory_id in memory_ids:
            try:
                ctx.deps.store.tag(memory_id, tags)
                updated.append(memory_id)
            except Exception:
                continue
        if not updated:
            return "No memories were found with the given IDs."
        return (
            f"Successfully tagged {len(updated)} memor{'y' if len(updated) == 1 else 'ies'} "
            f"with: {', '.join(tags)}."
        )

    @agent.tool
    async def find_duplicates(
        ctx: RunContext[CuratorDeps],
        threshold: int = 5,
    ) -> str:
        all_memories = ctx.deps.store.get_all(user_id=ctx.deps.user_id)
        if not all_memories:
            return "No memories in the store."

        id_to_text: dict[str, str] = {}
        for memory in all_memories:
            memory_id = memory.get("id", "")
            if memory_id:
                id_to_text[memory_id] = _memory_text(memory)

        groups = _find_duplicate_groups(ctx.deps.store, ctx.deps.user_id, threshold)
        if not groups:
            return "No potential duplicates found."

        lines: list[str] = []
        for i, members in enumerate(groups, 1):
            lines.append(f"Group {i}:")
            for member in sorted(members):
                lines.append(f"  - [{member}] {id_to_text.get(member, '(text unavailable)')}")
        return f"Found {len(groups)} potential duplicate group(s):\n\n" + "\n\n".join(lines)

    @agent.tool
    async def suggest_curation_actions(
        ctx: RunContext[CuratorDeps],
        limit: int = 5,
        stale_days: int = 180,
        low_importance_threshold: float = 0.35,
    ) -> str:
        memories = ctx.deps.store.get_all(user_id=ctx.deps.user_id)
        if not memories:
            return "No memories available for cleanup suggestions."

        now = datetime.now(UTC)
        duplicate_groups = _find_duplicate_groups(ctx.deps.store, ctx.deps.user_id, threshold=5)
        stale_candidates: list[tuple[str, int, str]] = []
        low_importance_candidates: list[tuple[str, float, str]] = []
        untagged_candidates: list[tuple[str, str]] = []

        for memory in memories:
            memory_id = str(memory.get("id", "unknown"))
            text = _memory_text(memory)
            metadata = _memory_metadata(memory)
            reference_dt = _parse_datetime(metadata.get("updated_at")) or _parse_datetime(
                metadata.get("created_at")
            )
            if reference_dt is not None:
                age_days = max((now - reference_dt).days, 0)
                if age_days >= stale_days:
                    stale_candidates.append((memory_id, age_days, text))

            importance = metadata.get("importance")
            if isinstance(importance, (int, float)) and float(importance) <= low_importance_threshold:
                low_importance_candidates.append((memory_id, float(importance), text))

            tags = metadata.get("tags", []) or []
            if not tags:
                untagged_candidates.append((memory_id, text))

        lines = ["Suggested curator actions:"]
        if duplicate_groups:
            lines.append("- Merge review candidates:")
            for group in duplicate_groups[:limit]:
                lines.append(f"  - Potential duplicate set: {', '.join(sorted(group))}")
        if stale_candidates:
            lines.append("- Stale memories to review:")
            for memory_id, age_days, text in sorted(
                stale_candidates, key=lambda item: item[1], reverse=True
            )[:limit]:
                lines.append(f"  - [{memory_id}] {age_days} days old: {text[:120]}")
        if low_importance_candidates:
            lines.append("- Low-importance memories to consider archiving or deleting:")
            for memory_id, importance, text in sorted(
                low_importance_candidates, key=lambda item: item[1]
            )[:limit]:
                lines.append(f"  - [{memory_id}] importance {importance:.2f}: {text[:120]}")
        if untagged_candidates:
            lines.append("- Untagged memories that may benefit from organisation:")
            for memory_id, text in untagged_candidates[:limit]:
                lines.append(f"  - [{memory_id}] {text[:120]}")
        return "\n".join(lines) if len(lines) > 1 else "No obvious cleanup suggestions right now."

    @agent.tool(requires_approval=True)
    async def propose_memory_update(
        ctx: RunContext[CuratorDeps],
        memory_id: str,
        updated_text: str,
        reason: str,
    ) -> str:
        """Update the text of a single memory. Requires human approval."""
        updated = ctx.deps.store.update(
            memory_id,
            updated_text,
            actor="agent",
            source="curator_agent",
            reason=reason or "Updated via Curator Agent",
        )
        version = (updated.get("metadata") or {}).get("version", 1)
        if ctx.deps.event_bus is not None:
            ctx.deps.event_bus.emit("memory.updated", memory_id, {
                "content": updated_text,
                "before_text": "",
                "version": version,
                "actor": "agent",
                "source": "curator_agent",
                "reason": reason,
            })
        return f"Updated memory {memory_id} (now version {version})."

    @agent.tool(requires_approval=True)
    async def delete_memories(
        ctx: RunContext[CuratorDeps],
        memory_ids: list[str],
        reason: str,
    ) -> str:
        """Delete one or more memories. Requires human approval."""
        deleted: list[str] = []
        for mid in memory_ids:
            try:
                ctx.deps.store.delete(
                    mid,
                    actor="agent",
                    source="curator_agent",
                    reason=reason or "Deleted via Curator Agent",
                )
                deleted.append(mid)
                if ctx.deps.event_bus is not None:
                    ctx.deps.event_bus.emit("memory.deleted", mid, {
                        "actor": "agent",
                        "source": "curator_agent",
                        "reason": reason,
                    })
            except Exception:
                logger.warning("Failed to delete memory %s", mid, exc_info=True)
        return f"Deleted {len(deleted)} of {len(memory_ids)} memories."

    @agent.tool(requires_approval=True)
    async def merge_memories(
        ctx: RunContext[CuratorDeps],
        memory_ids: list[str],
        merged_text: str,
    ) -> str:
        """Merge multiple memories into a single new one. Requires human approval.

        Deletes the originals and creates a consolidated replacement.
        Uses store.merge() to bypass fact extraction and record a single
        ``memory.merge_applied`` event.
        """
        result = ctx.deps.store.merge(
            memory_ids,
            merged_text,
            user_id=ctx.deps.user_id,
            actor="agent",
            source="curator_agent",
            reason="Merged via Curator Agent",
        )
        new_id = result.get("id", "")
        if ctx.deps.event_bus is not None:
            ctx.deps.event_bus.emit("memory.merge_applied", new_id, {
                "merged_memory_ids": memory_ids,
                "after_text": merged_text,
                "actor": "agent",
                "source": "curator_agent",
            })
        return f"Merged {len(memory_ids)} memories into new memory {new_id}."

    return agent
