"""HDBSCAN clustering on 2D projected coordinates.

Clusters are computed on the UMAP-projected 2D space (not the original
high-dimensional embeddings) so that the visual groupings in the
Embedding Atlas overview correspond directly to cluster assignments.
"""

from __future__ import annotations

import math

import numpy as np
from sklearn.cluster import HDBSCAN

from .models import ClusterInfo

_MIN_CLUSTERS = 3  # Minimum clusters for a useful visualization


class Clusterer:
    """Density-based clustering via HDBSCAN."""

    def __init__(self, min_cluster_size: int = 5) -> None:
        self.min_cluster_size = min_cluster_size
        self.min_samples: int | None = None
        self.labels_: np.ndarray | None = None

    def fit(self, coords_2d: np.ndarray) -> np.ndarray:
        """Cluster 2D projected coordinates.

        Parameters
        ----------
        coords_2d : np.ndarray
            Array of shape ``(n_samples, 2)`` from :pyclass:`Projector.fit_2d`.

        Returns
        -------
        np.ndarray
            Integer label for each point.  ``-1`` denotes noise (unassigned).
        """
        if coords_2d.shape[0] < self.min_cluster_size:
            # Not enough data to form any cluster
            self.labels_ = np.full(coords_2d.shape[0], -1)
            return self.labels_

        kwargs: dict = {
            "min_cluster_size": self.min_cluster_size,
            "metric": "euclidean",
            "cluster_selection_method": "eom",
        }
        if self.min_samples is not None:
            kwargs["min_samples"] = self.min_samples

        model = HDBSCAN(**kwargs)
        self.labels_ = model.fit_predict(coords_2d)
        return self.labels_

    def auto_tune(self, coords_2d: np.ndarray) -> np.ndarray:
        """Run a grid search over HDBSCAN hyperparameters and pick the best.

        Searches over ``min_cluster_size`` and ``min_samples`` combinations,
        scoring each with DBCV (Density-Based Clustering Validation) via the
        standalone ``hdbscan`` package.  DBCV is purpose-built for density-based
        clustering and naturally resists over-fragmentation — unlike silhouette
        or Calinski-Harabasz which can favour many tiny clusters.

        Configurations producing fewer than ``_MIN_CLUSTERS`` clusters are
        excluded to ensure the visualization remains useful.

        Parameters
        ----------
        coords_2d : np.ndarray
            Array of shape ``(n_samples, 2)``.

        Returns
        -------
        np.ndarray
            Cluster labels from the best parameter combination.
        """
        import hdbscan as hdbscan_lib

        # Dynamic floor: max(5, log2(n)) — scales gently with dataset size
        n = coords_2d.shape[0]
        floor = max(5, int(math.log2(n))) if n > 1 else 5

        # Build grid starting from floor
        min_cluster_sizes = sorted(set(
            v for v in [floor, floor + 1, floor + 2, floor + 4, floor * 2, floor * 3]
            if v <= n
        ))
        min_samples_options = [2, 3, 5, 7]

        best_score = -1.0
        best_labels: np.ndarray | None = None
        best_mcs = 5
        best_ms: int | None = None

        for mcs in min_cluster_sizes:
            if mcs > coords_2d.shape[0]:
                continue
            for ms in min_samples_options:
                if ms > mcs:
                    continue
                try:
                    model = hdbscan_lib.HDBSCAN(
                        min_cluster_size=mcs,
                        min_samples=ms,
                        metric="euclidean",
                        cluster_selection_method="eom",
                        gen_min_span_tree=True,
                    )
                    labels = model.fit_predict(coords_2d)

                    # Require at least _MIN_CLUSTERS clusters for a useful viz
                    unique_labels = set(labels.tolist()) - {-1}
                    if len(unique_labels) < _MIN_CLUSTERS:
                        continue

                    # DBCV score (higher = better density-based separation)
                    score = float(model.relative_validity_)

                    if score > best_score:
                        best_score = score
                        best_labels = labels
                        best_mcs = mcs
                        best_ms = ms
                except Exception:
                    continue

        # Store winning params
        self.min_cluster_size = best_mcs
        self.min_samples = best_ms

        if best_labels is not None:
            self.labels_ = best_labels
            return self.labels_

        # Fallback: use floor
        self.min_cluster_size = floor
        self.min_samples = None
        return self.fit(coords_2d)

    def assign_to_nearest_cluster(
        self,
        new_coords_2d: np.ndarray,
        existing_coords_2d: np.ndarray,
        existing_labels: np.ndarray,
    ) -> np.ndarray:
        """Assign new points to the nearest existing cluster.

        For each new point, finds the nearest cluster centroid and assigns
        it to that cluster if the distance is within that cluster's maximum
        radius (farthest member from centroid). Otherwise marks as noise (-1).

        Parameters
        ----------
        new_coords_2d : np.ndarray
            Array of shape ``(n_new, 2)``.
        existing_coords_2d : np.ndarray
            Array of shape ``(n_existing, 2)`` of already-clustered points.
        existing_labels : np.ndarray
            Labels for the existing points.

        Returns
        -------
        np.ndarray
            Labels for the new points.
        """
        if new_coords_2d.shape[0] == 0:
            return np.array([], dtype=np.int64)

        unique_labels = sorted(set(existing_labels.tolist()) - {-1})
        if not unique_labels:
            return np.full(new_coords_2d.shape[0], -1, dtype=np.int64)

        # Compute centroids and max radii
        centroids = []
        max_radii = []
        for label in unique_labels:
            mask = existing_labels == label
            members = existing_coords_2d[mask]
            centroid = members.mean(axis=0)
            centroids.append(centroid)
            distances = np.linalg.norm(members - centroid, axis=1)
            max_radii.append(float(distances.max()))

        centroids_arr = np.array(centroids)  # (n_clusters, 2)
        max_radii_arr = np.array(max_radii)  # (n_clusters,)

        # For each new point, find nearest centroid
        new_labels = np.full(new_coords_2d.shape[0], -1, dtype=np.int64)
        for i, point in enumerate(new_coords_2d):
            dists = np.linalg.norm(centroids_arr - point, axis=1)
            nearest_idx = int(np.argmin(dists))
            if dists[nearest_idx] <= max_radii_arr[nearest_idx]:
                new_labels[i] = unique_labels[nearest_idx]

        return new_labels

    def get_cluster_info(
        self,
        coords_2d: np.ndarray,
        labels: np.ndarray,
    ) -> list[ClusterInfo]:
        """Compute centroid, size, and member indices for each cluster.

        Parameters
        ----------
        coords_2d : np.ndarray
            The same 2D coordinates passed to :pymeth:`fit`.
        labels : np.ndarray
            Cluster labels returned by :pymeth:`fit`.

        Returns
        -------
        list[ClusterInfo]
            One entry per cluster (noise points with label ``-1`` are excluded).
        """
        clusters: list[ClusterInfo] = []
        unique_labels = set(labels.tolist()) - {-1}

        for label in sorted(unique_labels):
            mask = labels == label
            centroid = coords_2d[mask].mean(axis=0)
            clusters.append(
                ClusterInfo(
                    id=int(label),
                    centroid=centroid.tolist(),
                    size=int(mask.sum()),
                    member_indices=np.where(mask)[0].tolist(),
                )
            )

        return clusters

    def get_noise_indices(self, labels: np.ndarray) -> list[int]:
        """Get indices of noise points (label == -1).

        Parameters
        ----------
        labels : np.ndarray
            Cluster labels returned by :pymeth:`fit`.

        Returns
        -------
        list[int]
            Indices into the original coordinate array.
        """
        return np.where(labels == -1)[0].tolist()
