from __future__ import annotations

import math
from datetime import datetime

from bonsai_core.models import Memory


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Cosine similarity in range [0, 1] for non-negative embedding spaces."""
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if not norm_a or not norm_b:
        return 0.0
    sim = dot / (norm_a * norm_b)
    return max(0.0, min(1.0, sim))


def compute_retrieval_score(
    memory: Memory,
    query_embedding: list[float],
    now: datetime,
) -> float:
    """Park et al. formula: recency × importance × relevance."""
    if not memory.embedding:
        return 0.0

    hours = (now - memory.last_accessed_at).total_seconds() / 3600.0
    recency = math.exp(-0.995 * hours)
    importance = max(0.0, min(1.0, memory.importance))
    relevance = cosine_similarity(memory.embedding, query_embedding)
    return recency * importance * relevance
