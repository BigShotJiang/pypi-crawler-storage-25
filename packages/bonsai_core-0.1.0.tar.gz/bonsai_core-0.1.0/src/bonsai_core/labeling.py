"""Cluster label generation for BonsAI.

Uses an OpenAI model to generate short, descriptive labels for clusters
of related memories.
"""

from __future__ import annotations

import logging

import numpy as np
from openai import OpenAI

logger = logging.getLogger(__name__)

_MAX_MEMORIES = 5


def select_diverse_samples(
    texts: list[str],
    embeddings: np.ndarray,
    k: int = 5,
) -> list[str]:
    """Select k diverse samples using greedy farthest-point sampling.

    Picks the most diverse points from the embeddings to ensure the
    selected texts are representative of the full cluster.

    Parameters
    ----------
    texts : list[str]
        All texts in the cluster.
    embeddings : np.ndarray
        Embedding vectors corresponding to the texts.
    k : int
        Number of samples to select.

    Returns
    -------
    list[str]
        The selected diverse texts.
    """
    if k >= len(texts) or embeddings is None or len(embeddings) == 0:
        return texts[:k]

    if embeddings.shape[0] != len(texts):
        return texts[:k]

    n = len(texts)
    k = min(k, n)

    # Start with the first point
    selected_indices = [0]
    # Track minimum distance from each point to the selected set
    min_dists = np.full(n, np.inf)

    for _ in range(k - 1):
        # Update min distances with the last selected point
        last = embeddings[selected_indices[-1]]
        dists = np.linalg.norm(embeddings - last, axis=1)
        min_dists = np.minimum(min_dists, dists)
        # Zero out already-selected points
        for idx in selected_indices:
            min_dists[idx] = -1.0
        # Pick the farthest point
        next_idx = int(np.argmax(min_dists))
        selected_indices.append(next_idx)

    return [texts[i] for i in selected_indices]


def generate_cluster_label(
    memories: list[str],
    model: str = "gpt-4o-mini",
    embeddings: np.ndarray | None = None,
) -> str:
    """Generate a short label for a cluster of related memories.

    Sends up to 5 representative memory texts to an OpenAI model and asks
    for a concise 2--5 word label that captures the common theme.  On any
    failure (network error, missing API key, malformed response, etc.) the
    function returns an empty string instead of raising.

    Parameters
    ----------
    memories : list[str]
        Text content of the memories in the cluster.  At most 5 are sent
        to the model to keep the prompt compact.
    model : str
        OpenAI model identifier (default ``"gpt-4o-mini"``).
    embeddings : np.ndarray | None
        Optional embedding vectors for the memories. When provided,
        diverse sampling is used to select representative texts.

    Returns
    -------
    str
        A 2--5 word descriptive label, or ``""`` if generation fails.
    """
    if not memories:
        return ""

    try:
        if embeddings is not None:
            sample = select_diverse_samples(memories, embeddings, k=_MAX_MEMORIES)
        else:
            sample = memories[:_MAX_MEMORIES]

        numbered = "\n".join(
            f"{i}. {text}" for i, text in enumerate(sample, start=1)
        )

        client = OpenAI()
        response = client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Given these related memory snippets, generate a "
                        "short descriptive label (2-5 words) that captures "
                        "the common theme. Return only the label, nothing "
                        "else."
                    ),
                },
                {"role": "user", "content": numbered},
            ],
            max_tokens=30,
        )

        label: str = response.choices[0].message.content or ""
        return label.strip()

    except Exception:
        logger.debug("Cluster label generation failed", exc_info=True)
        return fallback_cluster_label(memories)


def fallback_cluster_label(memories: list[str]) -> str:
    """Generate a simple label without LLM by extracting frequent keywords."""
    if not memories:
        return ""

    stop = {
        "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
        "has", "have", "had", "do", "does", "did", "will", "would", "could",
        "should", "may", "might", "shall", "can", "to", "of", "in", "for",
        "on", "with", "at", "by", "from", "as", "into", "through", "during",
        "before", "after", "and", "but", "or", "nor", "not", "so", "yet",
        "both", "either", "neither", "each", "every", "all", "any", "few",
        "more", "most", "other", "some", "such", "no", "only", "own", "same",
        "than", "too", "very", "just", "about", "it", "its", "he", "she",
        "they", "them", "their", "his", "her", "we", "our", "you", "your",
        "i", "me", "my", "this", "that", "these", "those", "who", "whom",
        "which", "what", "where", "when", "how", "if", "then", "also",
        "name", "works", "worked",
    }

    from collections import Counter

    words: Counter[str] = Counter()
    for text in memories[:_MAX_MEMORIES]:
        for w in text.lower().split():
            cleaned = w.strip(".,;:!?\"'()-")
            if cleaned and len(cleaned) > 2 and cleaned not in stop:
                words[cleaned] += 1

    top = [w for w, _ in words.most_common(3)]
    if not top:
        return ""
    return " ".join(w.capitalize() for w in top)
