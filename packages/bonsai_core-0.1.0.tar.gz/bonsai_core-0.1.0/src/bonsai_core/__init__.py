"""BonsAI Core: memory operations, projection, clustering, query, and curation."""

from bonsai_core.agent import CuratorDeps, create_curator_agent
from bonsai_core.clustering import Clusterer
from bonsai_core.conflicts import (
    CONFLICT_THRESHOLD,
    HIGH_IMPORTANCE_THRESHOLD,
    detect_conflict,
    is_high_importance_conflict,
)
from bonsai_core.extraction import (
    ExtractedFact,
    ExtractionResult,
    extract_facts,
    locate_span,
)
from bonsai_core.labeling import generate_cluster_label
from bonsai_core.memory import MemoryStore
from bonsai_core.models import (
    AddResult,
    ClusterInfo,
    Episode,
    Memory,
    PendingConflict,
    SearchResult,
)
from bonsai_core.projection import Projector
from bonsai_core.query import ParsedQuery, QueryEngine
from bonsai_core.scoring import compute_retrieval_score, cosine_similarity
from bonsai_core.storage import MemoryAdapter, NativeChromaAdapter

__all__ = [
    "AddResult",
    "ClusterInfo",
    "Clusterer",
    "CONFLICT_THRESHOLD",
    "CuratorDeps",
    "Episode",
    "ExtractedFact",
    "ExtractionResult",
    "HIGH_IMPORTANCE_THRESHOLD",
    "Memory",
    "MemoryAdapter",
    "MemoryStore",
    "NativeChromaAdapter",
    "PendingConflict",
    "ParsedQuery",
    "Projector",
    "QueryEngine",
    "SearchResult",
    "compute_retrieval_score",
    "create_curator_agent",
    "cosine_similarity",
    "detect_conflict",
    "extract_facts",
    "generate_cluster_label",
    "is_high_importance_conflict",
    "locate_span",
]
