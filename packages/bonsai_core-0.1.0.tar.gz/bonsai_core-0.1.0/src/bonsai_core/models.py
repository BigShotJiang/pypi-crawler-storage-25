"""Pydantic models for the BonsAI thesis memory system."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Literal

from pydantic import BaseModel, Field


def _utcnow() -> datetime:
    return datetime.now(UTC)


class Episode(BaseModel):
    """Original source content from which facts are extracted."""

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    content: str
    source_type: str
    created_at: datetime = Field(default_factory=_utcnow)

class Memory(BaseModel):
    """An extracted atomic fact plus provenance and scoring metadata."""

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    fact: str

    # Source provenance
    source_episode_id: str = ""
    source_text: str = ""
    source_context: str = ""
    source_char_start: int = 0
    source_char_end: int = 0

    # Scoring
    importance: float = Field(default=0.5, ge=0.0, le=1.0)
    last_accessed_at: datetime = Field(default_factory=_utcnow)

    # Temporal
    created_at: datetime = Field(default_factory=_utcnow)
    valid_from: datetime | None = None
    valid_until: datetime | None = None

    # Soft delete
    is_deleted: bool = False
    deleted_at: datetime | None = None

    # Organization
    tags: list[str] = Field(default_factory=list)

    # Version tracking
    version: int = 1
    supersedes_id: str | None = None

    # Bidirectional provenance (temporal-aware updates)
    triggered_by_id: str | None = None
    triggered_update_of_ids: list[str] = Field(default_factory=list)

    # Compatibility with existing API surface
    source: str | None = None
    user_id: str = "default"

    # Embedding (optional payload for visualization)
    embedding: list[float] | None = None


class ClusterInfo(BaseModel):
    """Information about a single cluster produced by HDBSCAN."""

    id: int
    centroid: list[float]
    size: int
    member_indices: list[int]
    label: str | None = None


class AddResult(BaseModel):
    """Result of an add operation, indicating success or duplicate detection."""

    status: str  # "added" | "duplicate_found"
    id: str | None = None
    duplicates: list[Memory] = Field(default_factory=list)
    message: str | None = None


class SearchResult(BaseModel):
    """Paginated search result container."""

    memories: list[Memory]
    total: int


class PendingConflict(BaseModel):
    """A conflict awaiting human resolution."""

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    new_fact: Memory
    existing_fact: Memory
    contradiction_score: float
    created_at: datetime = Field(default_factory=_utcnow)
    status: Literal["pending", "resolved"] = "pending"
    resolution: Literal["keep_new", "keep_existing", "keep_both", "merge"] | None = None
    resolved_at: datetime | None = None
