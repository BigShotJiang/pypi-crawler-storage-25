from __future__ import annotations

import difflib
import os

import instructor
from openai import OpenAI
from pydantic import BaseModel, Field


class ExtractedFact(BaseModel):
    """A single extracted fact with provenance span and importance."""

    fact: str
    source_span: str
    importance: int = Field(ge=1, le=10)


class ExtractionResult(BaseModel):
    facts: list[ExtractedFact] = Field(default_factory=list)


def extract_facts(content: str, model: str | None = None) -> ExtractionResult:
    """Extract self-contained facts using instructor + OpenAI.

    Returns a safe single-fact fallback when extraction fails.
    """
    chosen_model = model or os.environ.get(
        "BONSAI_EXTRACTION_MODEL",
        "meta-llama/llama-4-scout-17b-16e-instruct",
    )
    groq_key = os.environ.get("GROQ_API_KEY")
    use_groq = bool(groq_key and chosen_model.startswith("meta-llama/"))
    raw_client = OpenAI(
        base_url="https://api.groq.com/openai/v1",
        api_key=groq_key,
    ) if use_groq else OpenAI()
    client = instructor.from_openai(raw_client)
    try:
        return client.chat.completions.create(
            model=chosen_model,
            response_model=ExtractionResult,
            messages=[{
                "role": "user",
                "content": (
                    "Extract atomic, self-contained facts from this content.\n\n"
                    "Rules:\n"
                    "1. Each fact MUST name the subject explicitly — never use pronouns.\n"
                    "2. Each fact MUST include qualifying context (company, role, institution) "
                    "when mentioned in the source text.\n"
                    "   BAD:  'He works on model serving infrastructure'\n"
                    "   GOOD: 'Jon Smith works on large-scale model serving infrastructure at Google'\n"
                    "3. source_span: the verbatim substring from the original text that supports this fact.\n"
                    "4. importance: 1-10 (1=trivial detail, 5=noteworthy, 8+=career-defining).\n\n"
                    f"Content:\n{content}"
                ),
            }],
        )
    except Exception:
        return ExtractionResult(
            facts=[
                ExtractedFact(
                    fact=content,
                    source_span=content,
                    importance=5,
                )
            ]
        )


def locate_span(content: str, span: str) -> tuple[int, int]:
    """Locate source span in content with exact then fuzzy fallback."""
    start = content.find(span)
    if start >= 0:
        return start, start + len(span)

    # Fuzzy fallback: choose the highest-similarity local window.
    target = span.strip()
    if not target:
        return 0, 0

    best_ratio = 0.0
    best_start = 0
    width = max(1, min(len(target), len(content)))
    for i in range(0, max(1, len(content) - width + 1)):
        window = content[i : i + width]
        ratio = difflib.SequenceMatcher(None, window.lower(), target.lower()).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_start = i
    return best_start, best_start + width
