"""UMAP dimensionality reduction with model caching.

Provides 2D projections (for Embedding Atlas overview) and 3D projections
(for React Three Fiber detail view) from high-dimensional embedding vectors.
Fitted UMAP models are persisted to disk so that new embeddings can be
projected without refitting.
"""

from __future__ import annotations

import pickle
from pathlib import Path

import numpy as np
import umap
from sklearn.manifold import trustworthiness


class Projector:
    """Fit and cache UMAP models for 2D / 3D projection."""

    def __init__(self, cache_path: str = ".bonsai_umap_cache") -> None:
        self.cache_path = Path(cache_path)
        self.cache_path.mkdir(parents=True, exist_ok=True)
        self.model_2d: umap.UMAP | None = None
        self.model_3d: umap.UMAP | None = None
        # 2D projection state
        self.cached_coords_2d: np.ndarray | None = None
        self.cached_ids_2d: list[str] | None = None  # memory IDs aligned with cached_coords_2d
        self.fitted_count_2d: int = 0
        self.baseline_trustworthiness_2d: float | None = None

    # ------------------------------------------------------------------ #
    # 2D (Embedding Atlas overview)
    # ------------------------------------------------------------------ #

    def fit_2d(
        self,
        embeddings: np.ndarray,
        n_neighbors: int = 5,
        min_dist: float = 0.1,
    ) -> np.ndarray:
        """Fit a UMAP model for 2D projection.

        Parameters
        ----------
        embeddings : np.ndarray
            Array of shape ``(n_samples, dim)``.
        n_neighbors : int
            Number of neighbours for the UMAP graph.
        min_dist : float
            Minimum distance between embedded points.

        Returns
        -------
        np.ndarray
            Coordinates of shape ``(n_samples, 2)``.
        """
        n_samples = embeddings.shape[0]
        if n_samples < 4:
            # UMAP needs at least 4 points for reliable spectral embedding.
            # For tiny datasets, return random 2D positions.
            rng = np.random.default_rng(42)
            coords = rng.standard_normal((n_samples, 2)).astype(np.float32) if n_samples > 0 else np.zeros((0, 2))
            self.cached_coords_2d = coords
            self.fitted_count_2d = n_samples
            self.baseline_trustworthiness_2d = None
            return coords

        # Adjust n_neighbors if dataset is too small
        effective_neighbors = min(n_neighbors, n_samples - 1)

        self.model_2d = umap.UMAP(
            n_components=2,
            n_neighbors=effective_neighbors,
            min_dist=min_dist,
            metric="cosine",
            random_state=42,
        )
        coords: np.ndarray = self.model_2d.fit_transform(embeddings)

        # Compute and store baseline trustworthiness
        n_tw = min(5, n_samples - 1)
        if n_tw >= 1:
            self.baseline_trustworthiness_2d = float(
                trustworthiness(embeddings, coords, n_neighbors=n_tw, metric="cosine")
            )
        else:
            self.baseline_trustworthiness_2d = None

        self.cached_coords_2d = coords
        self.fitted_count_2d = n_samples
        self._save_model("2d")
        return coords

    def transform_2d(self, embeddings: np.ndarray) -> np.ndarray:
        """Project new embeddings using the fitted 2D model.

        Parameters
        ----------
        embeddings : np.ndarray
            Array of shape ``(n_new, dim)``.

        Returns
        -------
        np.ndarray
            Coordinates of shape ``(n_new, 2)``.

        Raises
        ------
        FileNotFoundError
            If no fitted model exists on disk and none is loaded in memory.
        """
        if self.model_2d is None:
            self._load_model("2d")
        assert self.model_2d is not None  # for type-checker
        return self.model_2d.transform(embeddings)

    def sync_2d(
        self,
        current_ids: list[str],
        embeddings: np.ndarray,
    ) -> np.ndarray | None:
        """Sync cached 2D coords with the current memory set.

        Handles removals (drop rows) and additions (transform new points)
        without a full UMAP refit.  Returns the synced coords, or ``None``
        if the cache can't be synced (caller should fall through to fit/transform).
        """
        if self.cached_coords_2d is None or self.cached_ids_2d is None:
            return None

        cached_id_to_idx = {mid: i for i, mid in enumerate(self.cached_ids_2d)}
        current_id_set = set(current_ids)

        # Build coords array in the same order as current_ids
        coords_rows: list[np.ndarray] = []
        new_indices: list[int] = []  # indices into current_ids/embeddings for new points

        for i, mid in enumerate(current_ids):
            cached_idx = cached_id_to_idx.get(mid)
            if cached_idx is not None:
                coords_rows.append(self.cached_coords_2d[cached_idx])
            else:
                new_indices.append(i)
                coords_rows.append(np.zeros(2))  # placeholder

        # Transform new embeddings
        if new_indices:
            if self.model_2d is None:
                return None  # can't transform without a model
            new_embs = embeddings[new_indices]
            new_coords = self.model_2d.transform(new_embs)
            for j, idx in enumerate(new_indices):
                coords_rows[idx] = new_coords[j]

        coords = np.array(coords_rows, dtype=np.float32)
        self.cached_coords_2d = coords
        self.cached_ids_2d = list(current_ids)
        return coords

    def needs_refit_2d(self, total_count: int) -> bool:
        """Check if a refit is needed based on staleness.

        Parameters
        ----------
        total_count : int
            Total number of embeddings currently available.

        Returns
        -------
        bool
            True if a full refit should be performed.
        """
        if self.model_2d is None or self.fitted_count_2d == 0:
            return True
        # Staleness: >25% new points (compared to last full fit)
        new_count = total_count - self.fitted_count_2d
        if new_count > 0 and new_count / total_count > 0.25:
            return True
        return False

    def check_trustworthiness_2d(
        self, embeddings: np.ndarray, coords_2d: np.ndarray
    ) -> bool:
        """Check if trustworthiness is still acceptable after transform.

        Parameters
        ----------
        embeddings : np.ndarray
            All embeddings (fitted + new).
        coords_2d : np.ndarray
            All 2D coordinates (fitted + transformed).

        Returns
        -------
        bool
            True if trustworthiness is still >= 95% of baseline.
        """
        if self.baseline_trustworthiness_2d is None:
            return True
        n_neighbors = min(5, len(embeddings) - 1)
        if n_neighbors < 1:
            return True
        current = trustworthiness(
            embeddings, coords_2d, n_neighbors=n_neighbors, metric="cosine"
        )
        return current >= self.baseline_trustworthiness_2d * 0.95

    # ------------------------------------------------------------------ #
    # 3D (React Three Fiber detail view)
    # ------------------------------------------------------------------ #

    def fit_3d(
        self,
        embeddings: np.ndarray,
        n_neighbors: int = 5,
        min_dist: float = 0.1,
    ) -> np.ndarray:
        """Fit a UMAP model for 3D projection.

        Parameters
        ----------
        embeddings : np.ndarray
            Array of shape ``(n_samples, dim)``.
        n_neighbors : int
            Number of neighbours for the UMAP graph.
        min_dist : float
            Minimum distance between embedded points.

        Returns
        -------
        np.ndarray
            Coordinates of shape ``(n_samples, 3)``.
        """
        n_samples = embeddings.shape[0]
        if n_samples < 4:
            # UMAP needs at least 4 points for reliable spectral embedding.
            rng = np.random.default_rng(42)
            return rng.standard_normal((n_samples, 3)).astype(np.float32) if n_samples > 0 else np.zeros((0, 3))

        effective_neighbors = min(n_neighbors, n_samples - 1)

        self.model_3d = umap.UMAP(
            n_components=3,
            n_neighbors=effective_neighbors,
            min_dist=min_dist,
            metric="cosine",
            random_state=42,
        )
        coords: np.ndarray = self.model_3d.fit_transform(embeddings)
        self._save_model("3d")
        return coords

    def transform_3d(self, embeddings: np.ndarray) -> np.ndarray:
        """Project new embeddings using the fitted 3D model.

        Parameters
        ----------
        embeddings : np.ndarray
            Array of shape ``(n_new, dim)``.

        Returns
        -------
        np.ndarray
            Coordinates of shape ``(n_new, 3)``.

        Raises
        ------
        FileNotFoundError
            If no fitted model exists on disk and none is loaded in memory.
        """
        if self.model_3d is None:
            self._load_model("3d")
        assert self.model_3d is not None  # for type-checker
        return self.model_3d.transform(embeddings)

    # ------------------------------------------------------------------ #
    # Persistence helpers
    # ------------------------------------------------------------------ #

    def _save_model(self, dim: str) -> None:
        model = self.model_2d if dim == "2d" else self.model_3d
        state = {"model": model}
        if dim == "2d":
            state["cached_coords_2d"] = self.cached_coords_2d
            state["cached_ids_2d"] = self.cached_ids_2d
            state["fitted_count_2d"] = self.fitted_count_2d
            state["baseline_trustworthiness_2d"] = self.baseline_trustworthiness_2d
        with open(self.cache_path / f"umap_{dim}.pkl", "wb") as f:
            pickle.dump(state, f)

    def _load_model(self, dim: str) -> None:
        path = self.cache_path / f"umap_{dim}.pkl"
        if not path.exists():
            raise FileNotFoundError(
                f"No cached UMAP {dim} model found at {path}"
            )
        with open(path, "rb") as f:
            data = pickle.load(f)  # noqa: S301

        # Support both old format (bare model) and new format (dict with state)
        if isinstance(data, dict):
            if dim == "2d":
                self.model_2d = data["model"]
                self.cached_coords_2d = data.get("cached_coords_2d")
                self.cached_ids_2d = data.get("cached_ids_2d")
                self.fitted_count_2d = data.get("fitted_count_2d", 0)
                self.baseline_trustworthiness_2d = data.get(
                    "baseline_trustworthiness_2d"
                )
            else:
                self.model_3d = data["model"]
        else:
            # Legacy format: bare model object
            if dim == "2d":
                self.model_2d = data
            else:
                self.model_3d = data
