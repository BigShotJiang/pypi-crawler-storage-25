"""NL Query Engine for BonsAI.

Uses cross-encoder re-ranking for precise semantic search instead of
LLM-based query parsing.  Simple regex patterns extract metadata filters
(source, importance, tags, quoted substrings) from the query text.

The key design principle is **highlight, not filter**: queries return matching
memory IDs so the visualization layer can highlight them in-place rather than
hiding non-matching memories.

Example
-------
>>> engine = QueryEngine(store)
>>> ids = engine.get_highlight_ids("important memories about Google from LinkedIn")
>>> print(ids)  # {"abc-123", "def-456", ...}
"""

from __future__ import annotations

import re
from typing import Any, Literal

from pydantic import BaseModel, Field

from bonsai_core.memory import MemoryStore

# Maximum number of results to return after ranking.
MAX_RESULTS = 10

# RRF constant — controls how much lower-ranked results are discounted.
# Standard value from the original RRF paper (Cormack et al., 2009).
RRF_K = 60


# ------------------------------------------------------------------ #
# Structured query models (kept for backward compat of NLQueryResponse)
# ------------------------------------------------------------------ #


class MetadataFilter(BaseModel):
    """A single metadata filter condition for a ChromaDB ``where`` clause.

    Attributes
    ----------
    field : str
        The metadata field to filter on (e.g. ``"importance"``, ``"source"``,
        ``"tags"``).
    operator : str
        A ChromaDB comparison operator such as ``"$eq"``, ``"$gt"``, etc.
    value : Any
        The value to compare against.  Must be compatible with the operator
        and the field type stored in ChromaDB.
    """

    field: str
    operator: Literal["$eq", "$ne", "$gt", "$gte", "$lt", "$lte", "$in", "$nin"]
    value: Any


class ParsedQuery(BaseModel):
    """The structured representation of a natural language memory query.

    Attributes
    ----------
    semantic_query : str | None
        Core search text used for embedding-based similarity search.  When
        ``None``, the query targets only metadata or document content.
    metadata_filters : list[MetadataFilter]
        Zero or more metadata filter conditions that map to a ChromaDB
        ``where`` clause.
    document_contains : str | None
        A substring that must appear in the memory text.  Maps to ChromaDB's
        ``where_document`` with a ``$contains`` operator.
    limit : int
        Maximum number of results to return (1--200, default 50).
    """

    semantic_query: str | None = None
    metadata_filters: list[MetadataFilter] = []
    document_contains: str | None = None
    limit: int = Field(default=50, ge=1, le=200)


# ------------------------------------------------------------------ #
# Query engine
# ------------------------------------------------------------------ #


class QueryEngine:
    """Semantic search with cross-encoder re-ranking and local filter extraction.

    Replaces the previous LLM-based (instructor + gpt-4o-mini) query parser
    with a fully local pipeline:

    1. Extract metadata filters via regex (source, importance, tags, quoted
       substrings, explicit limits).
    2. Run bi-encoder semantic search via ChromaDB (with similarity floor +
       gap detection from :class:`NativeChromaAdapter`).
    3. Re-rank candidates with a cross-encoder for higher precision.
    4. Apply metadata and substring filters post-hoc.

    Parameters
    ----------
    store : MemoryStore
        The memory store to search against.
    rerank_model : str
        ONNX cross-encoder model for re-ranking (default
        ``"Xenova/ms-marco-MiniLM-L-6-v2"``).
    """

    def __init__(
        self,
        store: MemoryStore,
        rerank_model: str = "Xenova/ms-marco-MiniLM-L-6-v2",
    ) -> None:
        self.store = store
        from fastembed.rerank.cross_encoder import TextCrossEncoder

        self.reranker = TextCrossEncoder(rerank_model)

    # ------------------------------------------------------------------ #
    # Local filter extraction (replaces LLM parse)
    # ------------------------------------------------------------------ #

    @staticmethod
    def _extract_filters(query: str) -> ParsedQuery:
        """Extract structured filters from a query string using regex.

        Recognised patterns
        -------------------
        * ``from <source>`` — source equals
        * ``important`` / ``high importance`` — importance >= 0.7
        * ``tag:<tag>`` or ``tagged <tag>`` — tag filter
        * ``"<phrase>"`` — document_contains
        * ``limit <N>`` or ``top <N>`` — result limit
        """
        filters: list[MetadataFilter] = []
        document_contains: str | None = None
        limit = 50
        remaining = query

        # Quoted substring → document_contains
        quoted = re.search(r'"([^"]+)"', remaining)
        if quoted:
            document_contains = quoted.group(1)
            remaining = remaining[: quoted.start()] + remaining[quoted.end() :]

        # from <source>
        source_match = re.search(r"\bfrom\s+(\w+)", remaining, re.IGNORECASE)
        if source_match:
            filters.append(
                MetadataFilter(
                    field="source",
                    operator="$eq",
                    value=source_match.group(1).lower(),
                )
            )
            remaining = remaining[: source_match.start()] + remaining[source_match.end() :]

        # important / high importance
        imp_match = re.search(r"\b(important|high\s+importance)\b", remaining, re.IGNORECASE)
        if imp_match:
            filters.append(
                MetadataFilter(field="importance", operator="$gte", value=0.7)
            )
            remaining = remaining[: imp_match.start()] + remaining[imp_match.end() :]

        # tag:<tag> or tagged <tag>
        tag_match = re.search(r"\b(?:tag:|tagged\s+)(\w+)", remaining, re.IGNORECASE)
        if tag_match:
            filters.append(
                MetadataFilter(
                    field="tags",
                    operator="$in",
                    value=[tag_match.group(1).lower()],
                )
            )
            remaining = remaining[: tag_match.start()] + remaining[tag_match.end() :]

        # limit N / top N
        limit_match = re.search(r"\b(?:limit|top)\s+(\d+)\b", remaining, re.IGNORECASE)
        if limit_match:
            limit = max(1, min(200, int(limit_match.group(1))))
            remaining = remaining[: limit_match.start()] + remaining[limit_match.end() :]

        # Whatever is left becomes the semantic query
        semantic = remaining.strip()
        semantic = re.sub(r"\s+", " ", semantic)  # collapse whitespace

        return ParsedQuery(
            semantic_query=semantic or None,
            metadata_filters=filters,
            document_contains=document_contains,
            limit=limit,
        )

    # ------------------------------------------------------------------ #
    # Filter builders
    # ------------------------------------------------------------------ #

    def _build_where(self, parsed: ParsedQuery) -> dict[str, Any] | None:
        """Convert :attr:`ParsedQuery.metadata_filters` to a ChromaDB ``where`` clause."""
        if not parsed.metadata_filters:
            return None

        conditions: list[dict[str, Any]] = []
        for mf in parsed.metadata_filters:
            conditions.append({mf.field: {mf.operator: mf.value}})

        if len(conditions) == 1:
            return conditions[0]

        return {"$and": conditions}

    def _build_where_document(self, parsed: ParsedQuery) -> dict[str, Any] | None:
        """Convert :attr:`ParsedQuery.document_contains` to a ChromaDB ``where_document`` clause."""
        if not parsed.document_contains:
            return None
        return {"$contains": parsed.document_contains}

    # ------------------------------------------------------------------ #
    # Execution
    # ------------------------------------------------------------------ #

    def search(self, query: str, user_id: str = "default") -> list[dict[str, Any]]:
        """Search memories using bi-encoder retrieval + cross-encoder re-ranking.

        Parameters
        ----------
        query : str
            The free-form user query.
        user_id : str
            The user whose memories to search (default ``"default"``).

        Returns
        -------
        list[dict]
            A list of matching memory dictionaries, ordered by relevance.
        """
        parsed = self._extract_filters(query)
        where = self._build_where(parsed)
        where_document = self._build_where_document(parsed)

        # Use the full original query for semantic search (richer signal
        # than the stripped semantic_query).
        search_text = parsed.semantic_query or query

        if search_text:
            # Bi-encoder retrieval with over-fetch for re-ranking.
            # The adapter already applies similarity floor + gap detection.
            candidates = self.store.adapter.search_with_distances(
                search_text,
                limit=min(parsed.limit * 3, 200),
            )
            # Filter by user_id and soft-delete
            candidates = [
                (m, d) for m, d in candidates
                if m.user_id == user_id and not m.is_deleted
            ]
        else:
            # No semantic component — retrieve all and rely on metadata filters
            all_memories = self.store.adapter.get_all_with_embeddings()[0]
            candidates = [
                (m, 0.0) for m in all_memories
                if m.user_id == user_id and not m.is_deleted
            ]

        if not candidates:
            return []

        # Hybrid scoring: Reciprocal Rank Fusion of cosine + cross-encoder
        documents = [m.fact for m, _ in candidates]
        rerank_scores = list(self.reranker.rerank(query, documents))

        # Build rank orderings
        # Cosine rank: candidates are already sorted by distance (ascending)
        cosine_rank = {candidates[i][0].id: i for i in range(len(candidates))}

        # Reranker rank: sort by score descending
        rerank_order = sorted(range(len(candidates)), key=lambda i: rerank_scores[i], reverse=True)
        reranker_rank = {candidates[idx][0].id: rank for rank, idx in enumerate(rerank_order)}

        # Compute RRF score for each candidate
        rrf_scored = []
        for i, (pair, _) in enumerate(zip(candidates, rerank_scores)):
            mem = pair[0]
            rrf = 1.0 / (RRF_K + cosine_rank[mem.id]) + 1.0 / (RRF_K + reranker_rank[mem.id])
            rrf_scored.append((pair, rrf))

        # Sort by RRF score descending and cap
        rrf_scored.sort(key=lambda x: x[1], reverse=True)
        scored = rrf_scored[:MAX_RESULTS]

        # Convert to legacy dicts
        results = [self.store._to_legacy_dict(pair[0]) for pair, _ in scored]

        # Apply metadata filters
        if where is not None:
            results = self._apply_where_filter(results, where)

        # Apply document substring filter
        if where_document is not None:
            substring = where_document["$contains"]
            results = [
                r
                for r in results
                if substring.lower() in self._extract_text(r).lower()
            ]

        return results[: parsed.limit]

    def get_highlight_ids(self, query: str, user_id: str = "default") -> set[str]:
        """Return the set of memory IDs matching a natural language query.

        This is the primary interface for the visualization layer: given a
        query, determine *which* memories should be highlighted on the map.

        Parameters
        ----------
        query : str
            The free-form user query.
        user_id : str
            The user whose memories to search (default ``"default"``).

        Returns
        -------
        set[str]
            IDs of all matching memories.
        """
        results = self.search(query, user_id=user_id)
        return {self._extract_id(r) for r in results}

    # ------------------------------------------------------------------ #
    # Private helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def _extract_id(memory: dict[str, Any]) -> str:
        """Extract the memory ID from a result dictionary."""
        return str(memory.get("id") or memory.get("memory_id", ""))

    @staticmethod
    def _extract_text(memory: dict[str, Any]) -> str:
        """Extract the text content from a result dictionary."""
        return str(
            memory.get("memory")
            or memory.get("text")
            or memory.get("data")
            or ""
        )

    @staticmethod
    def _extract_metadata(memory: dict[str, Any]) -> dict[str, Any]:
        """Extract the metadata dictionary from a result."""
        if "metadata" in memory and isinstance(memory["metadata"], dict):
            return memory["metadata"]
        return memory

    @classmethod
    def _apply_where_filter(
        cls,
        results: list[dict[str, Any]],
        where: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Apply a ChromaDB-style ``where`` filter to a list of result dicts."""
        return [r for r in results if cls._matches_where(r, where)]

    @classmethod
    def _matches_where(cls, memory: dict[str, Any], where: dict[str, Any]) -> bool:
        """Check whether a single memory matches a ``where`` clause."""
        if "$and" in where:
            return all(cls._matches_where(memory, cond) for cond in where["$and"])
        if "$or" in where:
            return any(cls._matches_where(memory, cond) for cond in where["$or"])

        metadata = cls._extract_metadata(memory)
        for field, condition in where.items():
            if not isinstance(condition, dict):
                if metadata.get(field) != condition:
                    return False
                continue
            for operator, target in condition.items():
                actual = metadata.get(field)
                if not cls._compare(actual, operator, target):
                    return False
        return True

    @staticmethod
    def _compare(actual: Any, operator: str, target: Any) -> bool:
        """Evaluate a single comparison operator."""
        if actual is None:
            return operator in ("$ne", "$nin")

        if operator == "$eq":
            return actual == target
        if operator == "$ne":
            return actual != target
        if operator == "$gt":
            return actual > target
        if operator == "$gte":
            return actual >= target
        if operator == "$lt":
            return actual < target
        if operator == "$lte":
            return actual <= target
        if operator == "$in":
            if isinstance(actual, list):
                return bool(set(actual) & set(target))
            return actual in target
        if operator == "$nin":
            if isinstance(actual, list):
                return not bool(set(actual) & set(target))
            return actual not in target

        return False
