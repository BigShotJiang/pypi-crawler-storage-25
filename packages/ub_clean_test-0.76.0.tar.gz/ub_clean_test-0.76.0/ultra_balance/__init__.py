__version__ = "0.76.0"
__author__ = "pengyeqin"
__email__ = "xxbj433@qq.com"

# ========== 原有推理模块（v0.75.0） ==========
from .reasoning.logical import LogicalReasoning
from .reasoning.common_sense import CommonSense
from .reasoning.decision import DecisionReasoning
from .reasoning.metacognition import MetaCognition
from .reasoning.active_learning import ActiveLearning
from .reasoning.error_reflection import ErrorReflection
from .reasoning.knowledge_update import KnowledgeUpdate
from .reasoning.transfer_learning import TransferLearning
from .reasoning.dialogue import DialogueManager
from .reasoning.swarm import SwarmIntelligence
from .reasoning.human_robot import HumanRobotCollaboration
from .reasoning.strategy import StrategyGeneration
from .reasoning.universal import UniversalReasoning

# ========== v0.76.0 新增：轨迹规划 ==========
from .planning.quintic_trajectory import (
    QuinticTrajectory,
    MultiSegmentTrajectory,
    TrajectoryPoint,
    quintic_trajectory,
    multi_waypoint_trajectory
)

# ========== v0.76.0 新增：监控模块 ==========
from .monitoring.thermal_monitor import (
    ThermalMonitor,
    MultiJointThermalMonitor,
    ThermalConfig
)

from .monitoring.power_monitor import (
    PowerMonitor,
    BatteryConfig
)

from .monitoring.heartbeat import (
    HeartbeatMonitor,
    MultiHeartbeatMonitor,
    HeartbeatConfig
)

from .monitoring.stall_detector import (
    StallDetector,
    MultiStallDetector,
    StallConfig
)

from .monitoring.safety_guard import (
    SafetyGuard,
    SafetyLevel,
    SafetyTrigger,
    SafetyConfig
)


def hello():
    print("Hello from 湘西紫 (Xiangxi Purple)!")


# ========== 导出列表 ==========
__all__ = [
    # 原有推理模块
    'LogicalReasoning',
    'CommonSense',
    'DecisionReasoning',
    'MetaCognition',
    'ActiveLearning',
    'ErrorReflection',
    'KnowledgeUpdate',
    'TransferLearning',
    'DialogueManager',
    'SwarmIntelligence',
    'HumanRobotCollaboration',
    'StrategyGeneration',
    'UniversalReasoning',
    
    # v0.76.0 轨迹规划
    'QuinticTrajectory',
    'MultiSegmentTrajectory',
    'TrajectoryPoint',
    'quintic_trajectory',
    'multi_waypoint_trajectory',
    
    # v0.76.0 热监控
    'ThermalMonitor',
    'MultiJointThermalMonitor',
    'ThermalConfig',
    
    # v0.76.0 电量监控
    'PowerMonitor',
    'BatteryConfig',
    
    # v0.76.0 心跳监控
    'HeartbeatMonitor',
    'MultiHeartbeatMonitor',
    'HeartbeatConfig',
    
    # v0.76.0 堵转检测
    'StallDetector',
    'MultiStallDetector',
    'StallConfig',
    
    # v0.76.0 安全守护
    'SafetyGuard',
    'SafetyLevel',
    'SafetyTrigger',
    'SafetyConfig',
    
    # 工具函数
    'hello',
]
