from typing import Dict, List, Any, Optional, Union
from .phi3 import Phi3Client
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json
import uuid
import time


class TaskType(Enum):
    PERCEPTION = "perception"
    REASONING = "reasoning"
    DECISION = "decision"
    LEARNING = "learning"
    DIALOGUE = "dialogue"
    COLLABORATION = "collaboration"
    PLANNING = "planning"
    MEMORY = "memory"
    CREATIVITY = "creativity"
    VALUE = "value"


class Confidence(Enum):
    CERTAIN = 1.0
    LIKELY = 0.8
    POSSIBLE = 0.6
    UNCERTAIN = 0.4
    GUESS = 0.2


@dataclass
class UnifiedRequest:
    task_type: TaskType
    input: Any
    context: Dict[str, Any] = field(default_factory=dict)
    user_id: Optional[str] = None
    priority: int = 5


@dataclass
class UnifiedResponse:
    success: bool
    result: Any
    confidence: float
    explanation: str
    task_type: TaskType
    processing_time: float
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class UniversalReasoning:
    
    def __init__(self):
        self.version = "0.74.1"
        self.request_history: List[UnifiedResponse] = []
        self._modules = {}
        
        try:
            from ultra_balance.knowledge.load_experiences import UnitreeExperiences
            self.unitree_exp = UnitreeExperiences()
        except Exception as e:
            print(f"?? 宇树经验加载失败: {e}")
            self.unitree_exp = None
        
        self._init_modules()
        
        try:
            from .phi3 import Phi3Client
            self.phi3 = Phi3Client()
            if self.phi3.available:
                print("? phi3:mini 已加载")
            else:
                print("?? phi3:mini 不可用")
        except Exception as e:
            self.phi3 = None
            print(f"?? phi3:mini 加载失败: {e}")
    
    def _init_modules(self):
        try:
            from ultra_balance.reasoning.logical import LogicalReasoning
            self._modules["logical"] = LogicalReasoning()
        except:
            self._modules["logical"] = None
        
        try:
            from ultra_balance.reasoning.common_sense import CommonSense
            self._modules["common_sense"] = CommonSense()
        except:
            self._modules["common_sense"] = None
        
        try:
            from ultra_balance.reasoning.decision import DecisionReasoning
            self._modules["decision"] = DecisionReasoning()
        except:
            self._modules["decision"] = None
        
        try:
            from ultra_balance.reasoning.dialogue import DialogueManager
            self._modules["dialogue"] = DialogueManager()
        except:
            self._modules["dialogue"] = None
        
        try:
            from ultra_balance.reasoning.strategy import StrategyGeneration
            self._modules["strategy"] = StrategyGeneration()
        except:
            self._modules["strategy"] = None
    
    def reason(self, request: UnifiedRequest) -> UnifiedResponse:
        start_time = time.time()
        
        try:
            result = self._route(request)
            confidence = 0.8
            explanation = f"处理了{request.task_type.value}任务"
            success = True
        except Exception as e:
            result = {"error": str(e)}
            confidence = 0.0
            explanation = f"处理出错: {str(e)}"
            success = False
        
        processing_time = time.time() - start_time
        
        response = UnifiedResponse(
            success=success,
            result=result,
            confidence=confidence,
            explanation=explanation,
            task_type=request.task_type,
            processing_time=processing_time
        )
        
        self.request_history.append(response)
        return response
    
    def _route(self, request: UnifiedRequest) -> Any:
        if request.task_type == TaskType.REASONING:
            return self._handle_reasoning(request)
        elif request.task_type == TaskType.DECISION:
            return self._handle_decision(request)
        elif request.task_type == TaskType.DIALOGUE:
            return self._handle_dialogue(request)
        elif request.task_type == TaskType.PLANNING:
            return self._handle_planning(request)
        else:
            return {"message": f"处理{request.task_type.value}任务", "input": request.input}
    
    def _handle_reasoning(self, request: UnifiedRequest) -> Dict:
        input_data = request.input
        input_str = str(input_data).lower()
        
        if hasattr(self, 'phi3') and self.phi3 and self.phi3.available:
            if any(k in input_str for k in ["翻译", "代码", "写", "计算", "什么意思", "英文", "中文", "等于", "多少", "加", "减", "乘", "除", "=", "+", "-", "*", "/"]):
                result = self.phi3.chat(str(input_data))
                if result:
                    return {"type": "phi3", "result": result, "source": "phi3:mini"}
        
        if hasattr(self, 'unitree_exp') and self.unitree_exp:
            if any(k in input_str for k in ["捡", "pickup", "枕头", "堆", "积木", "block", "stack", "擦", "桌子", "wipe", "table", "叠", "毛巾", "fold", "towel", "倒", "药水", "pour", "medicine"]):
                result = self.unitree_exp.query(input_str)
                if result.get("found"):
                    return result
        
        if self._modules.get("logical") and isinstance(input_data, dict):
            if "major" in input_data:
                result = self._modules["logical"].syllogism(
                    input_data.get("major", ""),
                    input_data.get("minor", ""),
                    input_data.get("conclusion", "")
                )
                return result
        
        if self._modules.get("common_sense") and isinstance(input_data, str):
            result = self._modules["common_sense"].daily(input_data)
            return result
        
        return {"type": "reasoning_result", "input": input_data, "conclusion": f"推理: {input_data}"}
    
    def _handle_decision(self, request: UnifiedRequest) -> Dict:
        input_data = request.input
        
        if self._modules.get("decision") and isinstance(input_data, dict):
            if "options" in input_data:
                result = self._modules["decision"].compare_options(input_data["options"])
                return result
        
        return {"type": "decision_result", "input": input_data, "decision": "已做出决策"}
    
    def _handle_dialogue(self, request: UnifiedRequest) -> Dict:
        input_data = request.input
        
        if self._modules.get("dialogue") and isinstance(input_data, str):
            result = self._modules["dialogue"].generate_response(input_data)
            return result
        
        return {"type": "dialogue_result", "response": f"收到: {input_data}"}
    
    def _handle_planning(self, request: UnifiedRequest) -> Dict:
        input_data = request.input
        
        if self._modules.get("strategy") and isinstance(input_data, str):
            strategies = self._modules["strategy"].generate_strategy(input_data)
            if strategies:
                return {"strategies": [s.name for s in strategies], "best": strategies[0].name}
        
        return {"type": "planning_result", "plan": f"规划: {input_data}", "steps": ["分析", "执行", "验证"]}
    
    def reason_text(self, text: str, task_type: str = "reasoning") -> UnifiedResponse:
        task_map = {
            "reasoning": TaskType.REASONING,
            "decision": TaskType.DECISION,
            "dialogue": TaskType.DIALOGUE,
            "planning": TaskType.PLANNING,
            "learning": TaskType.LEARNING,
            "collaboration": TaskType.COLLABORATION,
        }
        ttype = task_map.get(task_type, TaskType.REASONING)
        
        request = UnifiedRequest(task_type=ttype, input=text)
        return self.reason(request)
    
    def reason_dict(self, data: Dict, task_type: str = "reasoning") -> UnifiedResponse:
        task_map = {
            "reasoning": TaskType.REASONING,
            "decision": TaskType.DECISION,
            "dialogue": TaskType.DIALOGUE,
            "planning": TaskType.PLANNING,
        }
        ttype = task_map.get(task_type, TaskType.REASONING)
        
        request = UnifiedRequest(task_type=ttype, input=data)
        return self.reason(request)
    
    def get_statistics(self) -> Dict:
        success_count = sum(1 for r in self.request_history if r.success)
        
        return {
            "version": self.version,
            "total_requests": len(self.request_history),
            "success_rate": success_count / len(self.request_history) if self.request_history else 1.0,
            "avg_confidence": sum(r.confidence for r in self.request_history) / len(self.request_history) if self.request_history else 0,
        }