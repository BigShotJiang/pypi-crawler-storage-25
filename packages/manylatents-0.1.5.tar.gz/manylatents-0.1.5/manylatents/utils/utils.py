import json
import logging
import os
import pickle
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import rich
import rich.logging
import torch
from omegaconf import DictConfig, OmegaConf

logger = logging.getLogger(__name__)


def should_disable_wandb(cfg: DictConfig) -> bool:
    """Determine if WandB should be disabled based on configuration.

    WandB is disabled when:
    1. logger is explicitly set to None (orchestrated by parent)
    2. debug mode is True (fast testing/CI)
    3. WANDB_MODE environment variable is set to 'disabled'
    """
    if cfg.logger is None:
        logger.info("WandB disabled: logger=None (orchestrated by parent)")
        return True
    if cfg.debug:
        logger.info("WandB disabled: debug=True")
        return True
    if os.environ.get('WANDB_MODE', '').lower() == 'disabled':
        logger.info("WandB disabled: WANDB_MODE=disabled")
        return True
    return False


class NumpyEncoder(json.JSONEncoder):
    """JSON encoder that handles numpy types."""

    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, (np.bool_,)):
            return bool(obj)
        return super().default(obj)


def save_pickle(obj, path):
    with open(path, 'wb') as f:
        pickle.dump(obj, f)

def load_pickle(path):
    with open(path, 'rb') as f:
        return pickle.load(f)
    
def check_or_make_dirs(directory: str):
    if not os.path.exists(directory):
        os.makedirs(directory)
 
def create_directory(dir_path, condition=True):
    """
    Create a directory if the condition is True.

    Args:
        dir_path (str or Path): Path to the directory.
        condition (bool): Whether to create the directory.
    """
    if condition:
        os.makedirs(dir_path, exist_ok=True)


def prepare_directories(cfg):
    """
    Prepare directories based on the configuration.

    Args:
        cfg (DictConfig): Configuration object.
    """
    # Hydra's working directory is set to the run's output folder for specific outputs
    ## TODO: leverage specific hydra outputs
    run_dir = Path.cwd()

    create_directory(cfg.paths.ckpt_dir)

    if cfg.project.plotting:
        plot_dir = run_dir / "plots"
        create_directory(plot_dir)

    # General cache directory outside Hydra run-specific folders
    cache_dir = Path(cfg.paths.cache_dir)
    geodesic_dir = cache_dir / "geodesic"
    laplacian_dir = cache_dir / "laplacian"

    if cfg.project.caching:
        create_directory(cache_dir)
        create_directory(geodesic_dir)
        create_directory(laplacian_dir)        
        
# Convert results to DataFrame
def create_results_dataframe(results):
    # Get all possible keys
    all_keys = set(key for result in results for key in result.keys())

    # Ensure all dictionaries have the same keys
    normalized_results = [
        {key: result.get(key, np.nan) for key in all_keys} for result in results
    ]

    # Convert to DataFrame
    return pd.DataFrame(normalized_results)

def save_embeddings(embeddings, path, format='npy', metadata=None):
    """
    Saves embeddings in the specified format.

    Args:
        embeddings (np.ndarray): The computed embeddings.
        path (str): File path for saving.
        format (str): One of ['npy', 'csv', 'pt', 'h5'].
        metadata (dict, optional): Extra metadata (e.g., labels).
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)

    if isinstance(embeddings, torch.Tensor):
        embeddings = embeddings.cpu().numpy()

    if format == 'npy':
        np.save(path, embeddings)
    elif format == 'csv':
        df = pd.DataFrame(embeddings, columns=[f"Component_{i+1}" for i in range(embeddings.shape[1])])
        if metadata is not None and metadata.get("labels") is not None:
            df["label"] = metadata["labels"]
        df.to_csv(path, index=False)
    elif format == 'pt':
        torch.save(embeddings, path)
    elif format == 'h5':
        import h5py
        with h5py.File(path, 'w') as f:
            f.create_dataset('embeddings', data=embeddings)
    else:
        raise ValueError(f"Unsupported format: {format}")
    
def setup_logging(debug: bool = False, log_level: str = "warning") -> None:
    """
    Set up rich-formatted console logging on the ``manylatents`` logger only.

    The root logger is left untouched so downstream consumers (shop.harness,
    etc.) are not flooded with internal noise.

    Args:
        debug: If True, override *log_level* to DEBUG.
        log_level: One of "debug", "info", "warning", "error", "critical".
                   Default is "warning" — verbose output only when requested.
    """
    if debug:
        level = logging.DEBUG
    else:
        level = getattr(logging, log_level.upper(), logging.WARNING)

    ml_logger = logging.getLogger("manylatents")
    # Avoid stacking duplicate handlers on repeated calls
    ml_logger.handlers.clear()
    ml_logger.setLevel(level)
    ml_logger.propagate = False  # Don't bubble up to root

    console = rich.logging.RichHandler(
        markup=True,
        rich_tracebacks=True,
        tracebacks_width=100,
        tracebacks_show_locals=False,
    )
    console.setLevel(level)
    ml_logger.addHandler(console)

def is_numeric(value: str) -> bool:
    try:
        float(value)
        return True
    except ValueError:
        return False

def load_precomputed_embeddings(cfg) -> Optional[dict]:
    """
    Loads precomputed embeddings from a file specified in the config.

    Returns None if no precomputed path is configured (defensive behavior).

    This function supports:
      - .npy files: loaded using numpy.load
      - .csv files: loaded by checking if there's a header. If a header is detected
        (i.e. non-numeric values in the first row), the file is loaded with np.genfromtxt
        and the header row is skipped. Otherwise, np.loadtxt is used.
      - .pt or .pth files: loaded using torch.load. If the loaded object is a tensor, it is converted to a numpy array.
        If it's a dictionary, it looks for an 'embeddings' key.

    Returns:
        dict: A dictionary with keys "embeddings", "label", "scores", and "metadata",
              or None if no precomputed path is configured.
    """
    # Defensive: use getattr to avoid ConfigAttributeError on missing key
    precomputed_path = getattr(cfg.data, 'precomputed_path', None)

    # Also check for 'path' as fallback (PrecomputedDataModule uses this)
    if not precomputed_path:
        precomputed_path = getattr(cfg.data, 'path', None)

    if not precomputed_path:
        return None  # No precomputed embeddings configured

    ext = os.path.splitext(precomputed_path)[-1].lower()
    embeddings = None

    if ext == ".npy":
        embeddings = np.load(precomputed_path)
    elif ext == ".csv":
        delimiter = ","
        # Read the first line to check for headers
        with open(precomputed_path, "r") as f:
            first_line = f.readline().strip()
        first_line_fields = first_line.split(delimiter)
        # If any field in the first line is non-numeric, assume a header exists.
        if any(not is_numeric(field) for field in first_line_fields):
            embeddings = np.genfromtxt(precomputed_path, delimiter=delimiter, skip_header=1)
        else:
            embeddings = np.loadtxt(precomputed_path, delimiter=delimiter)
    elif ext in [".pt", ".pth"]:
        loaded = torch.load(precomputed_path, map_location="cpu")
        if isinstance(loaded, torch.Tensor):
            embeddings = loaded.numpy()
        elif isinstance(loaded, dict):
            # If the checkpoint is a dict, assume embeddings are stored under the key "embeddings"
            if "embeddings" in loaded:
                emb = loaded["embeddings"]
                embeddings = emb.numpy() if hasattr(emb, "numpy") else np.array(emb)
            else:
                raise ValueError("Pretrained checkpoint dictionary does not contain 'embeddings' key.")
        else:
            raise ValueError(f"Unsupported type loaded from {precomputed_path}: {type(loaded)}")
    else:
        raise ValueError(f"Unsupported precomputed embedding file extension: {ext}")

    return {
        "embeddings": embeddings,
        "label": None,
        "metadata": None,
        "scores": None,
    }


def convert_null_strings_to_none(cfg: DictConfig) -> None:
    """
    Post-process Hydra config to convert string "_null_" to actual None.

    Hydra's override parser can't handle "key=null" (tries to look up config files).
    As a workaround, users can specify "key=_null_" and this function converts
    the string "_null_" to Python None after config composition.

    This allows users to use normal key=value syntax while still disabling configs.

    Args:
        cfg: Hydra configuration to modify in-place

    Example:
        # Command line:
        python -m manylatents.main experiment=single_algorithm metrics=_null_

        # After conversion, cfg.metrics will be None
    """
    def _recursive_convert(node):
        if isinstance(node, DictConfig):
            for key in list(node.keys()):
                value = node[key]
                if isinstance(value, str) and value == "_null_":
                    # Convert special marker to None
                    OmegaConf.set_struct(node, False)
                    node[key] = None
                elif isinstance(value, (DictConfig, list)):
                    _recursive_convert(value)
        elif isinstance(node, list):
            for item in node:
                if isinstance(item, (DictConfig, dict)):
                    _recursive_convert(item)

    OmegaConf.set_struct(cfg, False)
    _recursive_convert(cfg)
