"""
Diffusion Map dimensionality reduction.

Note: This file contains both the core algorithm implementation (DiffusionMap class)
and the PyTorch Lightning wrapper (DiffusionMapModule). Ideally, these should be 
separate with the core implementation imported from a shared library, but they are
combined here for convenience.
"""

import graphtools
import numpy as np
import scipy
import torch
from torch import Tensor
from typing import Optional, Union
import logging

from .latent_module_base import LatentModule, _to_numpy, _to_output

logger = logging.getLogger(__name__)


def _svd_symmetric(S: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """SVD of symmetric matrix with tiered backend: CUDA GPU > CPU torch > scipy.

    Args:
        S: (N, N) symmetric matrix (numpy).

    Returns:
        (evecs, svals) — both numpy arrays.
    """
    try:
        S_t = torch.from_numpy(S).to(dtype=torch.float64)
        if torch.cuda.is_available():
            S_t = S_t.cuda()
            backend = "torch-gpu"
        else:
            backend = "torch-cpu"
        U, svals_t, _ = torch.linalg.svd(S_t)
        evecs = U.cpu().numpy()
        svals = svals_t.cpu().numpy()
        logger.info(f"_svd_symmetric: {backend}, N={S.shape[0]}")
        return evecs, svals
    except Exception as e:
        logger.warning(f"torch SVD failed ({type(e).__name__}: {e}), falling back to scipy")
        evecs, svals, _ = scipy.linalg.svd(S)
        logger.info(f"_svd_symmetric: scipy, N={S.shape[0]}")
        return evecs, svals


def compute_dm(K, alpha=0., verbose=0):
    # Using setup and notation from: https://www.stats.ox.ac.uk/~cucuring/CDT_08_Nonlinear_Dim_Red_b__Diffusion_Maps_FoDS.pdf
    # alpha=0 Graph Laplacian
    # alpha=0.5 Fokker-Plank operator
    # alpha=1 Laplace-Beltrami operator

    #d_noalpha = K.sum(1).flatten()
    d_noalpha = K.sum(axis=1)

    # Check for degenerate kernel (zero or near-zero row sums)
    if np.any(np.abs(d_noalpha) < 1e-10):
        n = K.shape[0]
        evecs_right = np.full((n, n), np.nan)
        evals = np.full(n, np.nan)
        L = np.full((n, n), np.nan)
        S = np.full((n, n), np.nan)
        return evecs_right, evals, L, d_noalpha, S

    # weighted graph Laplacian normalization
    d = d_noalpha**alpha
    D = np.diag(d)
    D_inv = np.diag(1/d)

    # Normalize K according to α
    K_alpha = D_inv@K@D_inv

    #d_alpha = K_alpha.sum(1).flatten()
    d_alpha = K_alpha.sum(axis=1)
    D_alpha = np.diag(d_alpha)
    D_inv_alpha = np.diag(1/d_alpha)

    L = D_inv_alpha@K_alpha # anisotropic transition kernel (AKA diffusion operator)

    # Build symmetric diffusion operator (conjugate to L)
    # S and L are similar matrices: S = D_sqrt_inv_alpha @ L @ D_sqrt_alpha
    # They share the same eigenvalues but S is symmetric and has orthogonal eigenvectors
    D_sqrt_inv_alpha = np.diag(1/np.sqrt(d_alpha))
    D_sqrt_alpha = np.diag(np.sqrt(d_alpha))
    S = D_sqrt_inv_alpha@K_alpha@D_sqrt_inv_alpha

    # spectral decomposition of S (symmetric version)
    # IMPORTANT NOTE:
    # In theory you could run np.linalg.eig(L),
    # BUT this returns non-orthogonal eigenvectors!
    # So would have to correct for that
    # Using SVD since more numerically stable
    # Tiered backend: torch GPU > torch CPU > scipy
    evecs, svals = _svd_symmetric(S)

    # Retrieve sign!
    test_product = S@evecs
    expected_product = evecs@np.diag(svals)
    signs = np.isclose(expected_product, test_product).mean(0)
    signs[~np.isclose(signs, 1)] = -1
    evals = svals*signs

    # convert right eigenvectors of S to those of L
    evecs_right = D_sqrt_inv_alpha@evecs
    evecs_left = D_sqrt_alpha@evecs

    # make sure ordered by eigenvalue
    order = np.argsort(evals)[::-1]
    evals = evals[order]
    #evecs = evecs[:, order]
    evecs_left = evecs_left[:, order]
    evecs_right = evecs_right[:, order]

    # Scaling factor for eigenvectors
    #scaling_factor = 1/d_noalpha.sum()
    #scaling_factor = evecs_right[0, 0]
    scaling_factor = 1/np.sqrt(d_alpha.sum())
    if np.isclose(evecs_right[:,0]/scaling_factor, -1).any():
        scaling_factor *= -1

    # Apply scaling
    evecs_right /= scaling_factor

    # Adjust left eigenvectors to maintain eigendecomposition
    # Assuming evecs_right[0,0] is non-zero for all practical cases
    evecs_left *= scaling_factor

    # Safety Checks!
    # First left eigenvector is stationary distribution
    if verbose > 0:
        neg_evals = evals < 0
        if neg_evals.sum() > 0:
            logger.warning("%d eigenvalues are negative: min=%s", len(evals[neg_evals]),
                           evals[neg_evals].min())
        one_evals = np.isclose(evals, 1).sum()
        if one_evals > 1:
            logger.warning("%d eigenvalues are 1", one_evals)
        if not np.allclose(evecs_left[:,0]/evecs_left.sum(), d_alpha/d_alpha.sum()):
            logger.warning("left evec not exactly stationary dist. Proceed with caution!")
        # First right eigenvector is all 1s
        if not  np.allclose(evecs_right[:,0], 1):
            logger.warning("right evec not trivial (1s)! Proceed with caution!")
        # Decomposition is correct
        if not np.allclose(L, evecs_right@np.diag(evals)@evecs_left.T):
            logger.warning("evals/evecs dont exactly match with diffusion operator. Proceed with caution!")

    #diffusion_coords = evecs_right@np.diag(evals)

    # Return eigenvectors and eigenvalues instead so that we can compute DMs for different t's
    # Also return S (symmetric diffusion operator) for affinity spectrum analysis
    # Note: S and L are similar matrices (conjugates). S = D_sqrt_inv_alpha @ L @ D_sqrt_alpha
    # They share the same eigenvalues, but S is symmetric with orthogonal eigenvectors
    return evecs_right, evals, L, d_noalpha, S


def matrix_is_equivalent(ref, new):
    return ref.shape[1] == new.shape[1]


class DiffusionMap():
    """Implementation of Diffusion Maps

    Parameters
    ----------

    n_components : int, optional, default: 2
        number of dimensions in which the data will be embedded

    t : int, optional, default: 'auto'
        power to which the diffusion operator is powered.
        This sets the level of diffusion. If 'auto', t is selected
        according to the knee point in the Von Neumann Entropy of
        the diffusion operator

    knn : int, optional, default: 5
        number of nearest neighbors on which to build kernel

    decay : int, optional, default: 40
        sets decay rate of kernel tails.
        If None, alpha decaying kernel is not used

    n_landmark : int, optional, default: 2000
        number of landmarks to use in fast PHATE

    n_pca : int, optional, default: 100
        Number of principal components to use for calculating
        neighborhoods. For extremely large datasets, using
        n_pca < 20 allows neighborhoods to be calculated in
        roughly log(n_samples) time.

    knn_dist : string, optional, default: 'euclidean'
        recommended values: 'euclidean', 'cosine', 'precomputed'
        Any metric from `scipy.spatial.distance` can be used
        distance metric for building kNN graph. Custom distance
        functions of form `f(x, y) = d` are also accepted. If 'precomputed',
        `data` should be an n_samples x n_samples distance or
        affinity matrix. Distance matrices are assumed to have zeros
        down the diagonal, while affinity matrices are assumed to have
        non-zero values down the diagonal. This is detected automatically
        using `data[0,0]`. You can override this detection with
        `knn_dist='precomputed_distance'` or `knn_dist='precomputed_affinity'`.

    knn_max : int, optional, default: None
        Maximum number of neighbors for which alpha decaying kernel
        is computed for each point. For very large datasets, setting `knn_max`
        to a small multiple of `knn` can speed up computation significantly.

    n_jobs : integer, optional, default: 1
        The number of jobs to use for the computation.
        If -1 all CPUs are used. If 1 is given, no parallel computing code
        is used at all, which is useful for debugging.
        For n_jobs below -1, (n_cpus + 1 + n_jobs) are used. Thus for
        n_jobs = -2, all CPUs but one are used

    random_state : integer or numpy.RandomState, optional, default: None
        The generator used to initialize SMACOF (metric, nonmetric) MDS
        If an integer is given, it fixes the seed
        Defaults to the global `numpy` random number generator

    verbose : `int` or `boolean`, optional (default: 1)
        If `True` or `> 0`, print status messages

    Returns
    -------
    self
    """
    def __init__(self, 
                 n_components=2, 
                 t=1, 
                 n_pca=None, 
                 n_landmark=None,
                 knn=5,
                 knn_max=100,
                 knn_dist='euclidean',
                 decay=40,
                 n_jobs=8,
                 verbose=0,
                 random_state=42):
        self.n_components = n_components
        self.n_landmark = n_landmark
        self.t = t
        self.n_pca = n_pca
        self.knn=knn
        self.knn_max=knn_max
        self.knn_dist = knn_dist
        self.decay=decay
        self.n_jobs=n_jobs
        self.verbose=verbose
        self.random_state=random_state
        self.X = None
        self.G = None

    def fit(self, X):

        if self.n_landmark is None or X.shape[0] <= self.n_landmark:
            n_landmark = None
        else:
            n_landmark = self.n_landmark

        if self.G is None:
            self.G = graphtools.Graph(X, 
                                      n_pca=self.n_pca, 
                                      n_landmark=self.n_landmark,
                                      distance=self.knn_dist,
                                      knn=self.knn,
                                      knn_max=self.knn_max,
                                      decay=self.decay,
                                      thresh=1e-4,
                                      n_jobs=self.n_jobs,
                                      verbose=self.verbose,
                                      random_state=self.random_state)

        K = self.G.kernel
        K = np.array(K.todense())
        self.evecs_right, self.evals, self.L, self.d_noalpha, self.S = compute_dm(K, 1)
        self.X = X
        
        
    
    @property
    def embedding(self):
        if not hasattr(self, "evecs_right") or not hasattr(self, "evals"):
            raise ValueError("Model has not been fitted yet. Call `.fit()` first.")
        return self.evecs_right @ np.diag(self.evals**self.t)[:, 1:(self.n_components+1)]

    def transform(self, X=None):
        if self.embedding is None:
            raise Exception("Need to fit model first!")
        if X is None:
            return self.embedding
        # process case where X different from fitted X
        if matrix_is_equivalent(X, self.X):
            transitions = self.G.extend_to_data(X)
            return self.G.interpolate(self.embedding, transitions)
        else:
            raise Exception("Trying to transform data of different dimension from what was fitted!")

    def set_params(self, **params):
        """Set the parameters on this estimator.

        Any parameters not given as named arguments will be left at their
        current value.

        Parameters
        ----------

        n_components : int, optional, default: 2
            number of dimensions in which the data will be embedded

        knn : int, optional, default: 5
            number of nearest neighbors on which to build kernel

        decay : int, optional, default: 40
            sets decay rate of kernel tails.
            If None, alpha decaying kernel is not used

        n_landmark : int, optional, default: 2000
            number of landmarks to use in fast PHATE

        t : int, optional, default: 'auto'
            power to which the diffusion operator is powered.
            This sets the level of diffusion. If 'auto', t is selected
            according to the knee point in the Von Neumann Entropy of
            the diffusion operator

        n_pca : int, optional, default: 100
            Number of principal components to use for calculating
            neighborhoods. For extremely large datasets, using
            n_pca < 20 allows neighborhoods to be calculated in
            roughly log(n_samples) time.

        knn_dist : string, optional, default: 'euclidean'
            recommended values: 'euclidean', 'cosine', 'precomputed'
            Any metric from `scipy.spatial.distance` can be used
            distance metric for building kNN graph. Custom distance
            functions of form `f(x, y) = d` are also accepted. If 'precomputed',
            `data` should be an n_samples x n_samples distance or
            affinity matrix. Distance matrices are assumed to have zeros
            down the diagonal, while affinity matrices are assumed to have
            non-zero values down the diagonal. This is detected automatically
            using `data[0,0]`. You can override this detection with
            `knn_dist='precomputed_distance'` or `knn_dist='precomputed_affinity'`.

        knn_max : int, optional, default: None
            Maximum number of neighbors for which alpha decaying kernel
            is computed for each point. For very large datasets, setting `knn_max`
            to a small multiple of `knn` can speed up computation significantly.

        n_jobs : integer, optional, default: 1
            The number of jobs to use for the computation.
            If -1 all CPUs are used. If 1 is given, no parallel computing code
            is used at all, which is useful for debugging.
            For n_jobs below -1, (n_cpus + 1 + n_jobs) are used. Thus for
            n_jobs = -2, all CPUs but one are used

        random_state : integer or numpy.RandomState, optional, default: None
            The generator used to initialize SMACOF (metric, nonmetric) MDS
            If an integer is given, it fixes the seed
            Defaults to the global `numpy` random number generator

        verbose : `int` or `boolean`, optional (default: 1)
            If `True` or `> 0`, print status messages

        Returns
        -------
        self
        """
        reset_kernel = False
        reset_embedding = False

        # embedding parameters
        if "n_components" in params and params["n_components"] != self.n_components:
            self.n_components = params["n_components"]
            del params["n_components"]
            
        if "t" in params and params["t"] != self.t:
            self.t = params["t"]
            del params["t"]

        # kernel parameters
        if "knn" in params and params["knn"] != self.knn:
            self.knn = params["knn"]
            reset_kernel = True
            del params["knn"]
        if "knn_max" in params and params["knn_max"] != self.knn_max:
            self.knn_max = params["knn_max"]
            reset_kernel = True
            del params["knn_max"]
        if "decay" in params and params["decay"] != self.decay:
            self.decay = params["decay"]
            reset_kernel = True
            del params["decay"]
        if "n_pca" in params:
            if self.X is not None and params["n_pca"] >= np.min(self.X.shape):
                params["n_pca"] = None
            if params["n_pca"] != self.n_pca:
                self.n_pca = params["n_pca"]
                reset_kernel = True
                del params["n_pca"]
        if "knn_dist" in params and params["knn_dist"] != self.knn_dist:
            self.knn_dist = params["knn_dist"]
            reset_kernel = True
            del params["knn_dist"]
        if "n_landmark" in params and params["n_landmark"] != self.n_landmark:
            if self.n_landmark is None or params["n_landmark"] is None:
                # need a different type of graph, reset entirely
                self._reset_graph()
            else:
                self._set_graph_params(n_landmark=params["n_landmark"])
            self.n_landmark = params["n_landmark"]
            del params["n_landmark"]

        # parameters that don't change the embedding
        if "n_jobs" in params:
            self.n_jobs = params["n_jobs"]
            self._set_graph_params(n_jobs=params["n_jobs"])
            del params["n_jobs"]
        if "random_state" in params:
            self.random_state = params["random_state"]
            self._set_graph_params(random_state=params["random_state"])
            del params["random_state"]
        if "verbose" in params:
            self.verbose = params["verbose"]
            logger.set_level(self.verbose)
            self._set_graph_params(verbose=params["verbose"])
            del params["verbose"]
            
        if reset_kernel or reset_embedding:
            self._reset_graph()

        self._set_graph_params(**params)


    def _set_graph_params(self, **params):
        try:
            self.G.set_params(**params)
        except AttributeError:
            # graph not defined
            pass
    
    def _reset_graph(self):
        self.G = None


# PyTorch Lightning Module wrapper

class DiffusionMapModule(LatentModule):
    """Diffusion map dimensionality reduction with dual-backend support.

    Constructs a diffusion operator from an adaptive-bandwidth kernel on
    the kNN graph, then embeds via the leading eigenvectors scaled by
    eigenvalues raised to diffusion time t.

    Two backends are available:

    - **graphtools (default, backend=None)**: Uses graphtools' alpha-decay
      kernel with Laplace-Beltrami normalization. Eigendecomposition is
      GPU-accelerated via ``_svd_symmetric`` when CUDA is available.
      This is the reference implementation and should be used for all
      published results.

    - **torchdr (backend="torchdr")**: Experimental GPU-native path using
      a simplified alpha-decay kernel via ``torch.cdist``. Produces
      qualitatively similar but not numerically identical embeddings
      (pairwise distance correlation ~0.4 vs graphtools on swiss roll).
      Useful for rapid prototyping on large datasets but not recommended
      for results that must match prior graphtools-based runs.
    """

    def __init__(
        self,
        n_components: int = 2,
        random_state: Optional[int] = 42,
        knn: Optional[int] = 5,
        t: Union[int, str] = 15, # Can be an integer or 'auto'
        decay: Optional[int] = 40,
        n_pca: Optional[int] = None,
        n_landmark: Optional[int] = 2000,
        n_jobs: Optional[int] = -1,
        verbose = False,
        fit_fraction: float = 1.0,  # Fraction of data used for fitting
        neighborhood_size: Optional[int] = None,
        mode: str = "embed",
        n_clusters: Union[int, str] = "auto",
        backend: str | None = None,
        device: str | None = None,
        **kwargs
    ):
        super().__init__(n_components=n_components, init_seed=random_state,
                         backend=backend, device=device,
                         neighborhood_size=neighborhood_size, **kwargs)
        if mode not in ("embed", "cluster"):
            raise ValueError(f"mode must be 'embed' or 'cluster', got '{mode}'")
        self.mode = mode
        self.n_clusters = n_clusters
        self.fit_fraction = fit_fraction
        self._labels = None
        self._n_clusters_detected = None
        self.t = t
        self.random_state = random_state
        resolved_knn = neighborhood_size if neighborhood_size is not None else knn

        from ...utils.backend import resolve_backend
        self._resolved_backend = resolve_backend(backend)

        if self._resolved_backend == "torchdr":
            self._knn = resolved_knn
            self._torchdr_evals = None
            self._torchdr_evecs = None
            self._torchdr_affinity = None
            self.model = None  # no graphtools model in torchdr path
        else:
            self.model = DiffusionMap(n_components=n_components,
                                      random_state=random_state,
                                      knn=resolved_knn,
                                      t=t,
                                      decay=decay,
                                      n_pca=n_pca,
                                      n_landmark=n_landmark,
                                      n_jobs=n_jobs,
                                      verbose=verbose)

    def _detect_n_clusters(self, evals: np.ndarray) -> int:
        """Detect number of clusters from the eigenvalue gap.

        Counts eigenvalues close to 1.0 (within a relative threshold),
        then verifies there is a clear gap to the next eigenvalue.
        The number of eigenvalues near 1.0 equals the number of
        connected components / clusters in the graph.
        """
        evals_abs = np.abs(evals)
        # Count eigenvalues within 5% of 1.0
        near_one = evals_abs > 0.95
        k = int(np.sum(near_one))
        # Must have at least 1 cluster
        return max(k, 1)

    def fit(self, x, y=None) -> None:
        """Fits DiffusionMap on a subset of data."""
        x_np = _to_numpy(x)
        n_samples = x_np.shape[0]
        n_fit = max(1, int(self.fit_fraction * n_samples))

        if self._resolved_backend == "torchdr":
            self._fit_torchdr(x_np[:n_fit])
        else:
            self.model.fit(x_np[:n_fit])
        self._is_fitted = True

        if self.mode == "cluster":
            self._fit_clusters()

    def _fit_torchdr(self, x_np: np.ndarray) -> None:
        """Fit diffusion map using TorchDR alpha-decay kernel + torch eigendecomposition.

        Uses MAGICAffinity (alpha-decay kernel, same as graphtools) with
        Laplace-Beltrami (alpha=1) normalization, matching compute_dm().
        """
        from torchdr import MAGICAffinity
        from ...utils.backend import resolve_device

        dev = resolve_device(self.device)
        x_t = torch.from_numpy(x_np).float()
        if dev == "cuda":
            x_t = x_t.cuda()

        # Alpha-decay kernel (same as graphtools): exp(-d/sigma_i)
        # MAGICAffinity symmetrizes and row-normalizes internally,
        # but we need the raw kernel before normalization for alpha-norm.
        # So we build the kernel manually using the same formula.
        C = torch.cdist(x_t, x_t, p=2.0) ** 2  # squared Euclidean
        topk = torch.topk(C, k=self._knn + 1, dim=1, largest=False)
        sigma = topk.values[:, -1]  # kth-neighbor distance (squared)
        sigma = sigma.clamp(min=1e-10)

        # Alpha-decay kernel: exp(-d_sq / sigma_i)
        K = torch.exp(-C / sigma.unsqueeze(1))
        # Symmetrize
        K = (K + K.T) / 2

        # Laplace-Beltrami normalization (alpha=1), matching compute_dm(K, alpha=1)
        d = K.sum(dim=1)
        D_inv = torch.diag(1.0 / d.clamp(min=1e-10))
        K_alpha = D_inv @ K @ D_inv
        d_alpha = K_alpha.sum(dim=1)

        # Symmetric diffusion operator: S = D_alpha^{-1/2} K_alpha D_alpha^{-1/2}
        d_alpha_inv_sqrt = torch.diag(1.0 / d_alpha.sqrt().clamp(min=1e-10))
        S = d_alpha_inv_sqrt @ K_alpha @ d_alpha_inv_sqrt

        # Eigendecomposition on GPU
        evals, evecs = torch.linalg.eigh(S)

        # Sort descending (eigh returns ascending)
        order = torch.argsort(evals, descending=True)
        evals = evals[order]
        evecs = evecs[:, order]

        # Convert right eigenvectors of S to those of the diffusion operator
        d_alpha_inv_sqrt_np = d_alpha_inv_sqrt.cpu().numpy()
        evecs_right = d_alpha_inv_sqrt_np @ evecs.cpu().numpy()

        # Normalize: first right eigenvector should be all 1s
        d_alpha_np = d_alpha.cpu().numpy()
        scaling = 1.0 / np.sqrt(d_alpha_np.sum())
        if np.isclose(evecs_right[:, 0] / scaling, -1).any():
            scaling *= -1
        evecs_right /= scaling

        self._torchdr_evals = evals.cpu().numpy()
        self._torchdr_evecs = evecs_right
        self._torchdr_affinity = K.cpu().numpy()
        self._torchdr_d_noalpha = d.cpu().numpy()

        logger.info(
            f"DiffusionMap(torchdr): N={x_np.shape[0]}, "
            f"device={dev}, top evals={self._torchdr_evals[:5]}"
        )

    def _fit_clusters(self) -> None:
        """Run k-means on unscaled eigenvectors to produce cluster labels."""
        from sklearn.cluster import KMeans

        if self._resolved_backend == "torchdr":
            evals = self._torchdr_evals
            evecs = self._torchdr_evecs
        else:
            evals = self.model.evals
            evecs = self.model.evecs_right

        if isinstance(self.n_clusters, str) and self.n_clusters == "auto":
            k = self._detect_n_clusters(evals)
        else:
            k = int(self.n_clusters)

        self._n_clusters_detected = k

        # Use eigenvectors 1..k (skip trivial eigenvector 0)
        # No eigenvalue scaling — pure spectral clustering
        features = evecs[:, 1:k + 1]

        rs = self.random_state if self._resolved_backend == "torchdr" else self.model.random_state
        km = KMeans(n_clusters=k, random_state=rs, n_init=10)
        self._labels = km.fit_predict(features)

    def transform(self, x):
        """Transforms data using the fitted DiffusionMap model."""
        if not self._is_fitted:
            raise RuntimeError("DiffusionMap model is not fitted yet. Call `fit` first.")

        if self.mode == "cluster":
            labels_np = self._labels.reshape(-1, 1).astype(np.float32)
            return _to_output(labels_np, x)

        if self._resolved_backend == "torchdr":
            evals = self._torchdr_evals
            evecs = self._torchdr_evecs
            t = self.t if isinstance(self.t, int) else 5
            embedding_np = evecs @ np.diag(evals ** t)[:, 1:(self.n_components + 1)]
        else:
            x_np = _to_numpy(x)
            embedding_np = self.model.transform(x_np)
        return _to_output(embedding_np, x)

    def predict_labels(self) -> np.ndarray:
        """Return integer cluster assignments.

        Only available when mode='cluster'. Call fit() first.
        """
        if self.mode != "cluster":
            raise RuntimeError("predict_labels() is only available in mode='cluster'")
        if self._labels is None:
            raise RuntimeError("Model is not fitted. Call fit() first.")
        return self._labels.copy()

    def affinity(self, ignore_diagonal: bool = False, use_symmetric: bool = False) -> np.ndarray:
        """
        Returns diffusion operator.

        The diffusion operator is computed during fit and represents the
        transition matrix of the diffusion process.

        Args:
            ignore_diagonal: If True, set diagonal entries to zero. Default False.
            use_symmetric: If True, return symmetric diffusion operator (matrix S).
                          Default False returns row-stochastic diffusion operator.

        Returns:
            N×N diffusion operator matrix (row-stochastic if use_symmetric=False,
            symmetric if use_symmetric=True).
        """
        if not self._is_fitted:
            raise RuntimeError("DiffusionMap model is not fitted yet. Call `fit` first.")

        if self._resolved_backend == "torchdr":
            K = self._torchdr_affinity
            # Build symmetric form
            d = K.sum(axis=1)
            d_inv_sqrt = np.diag(1.0 / np.sqrt(np.maximum(d, 1e-10)))
            sym_diff_op = d_inv_sqrt @ K @ d_inv_sqrt
            # Row-stochastic form
            row_sums = K.sum(axis=1, keepdims=True)
            row_sums[row_sums == 0] = 1
            diff_op = K / row_sums
        else:
            diff_op = self.model.L
            sym_diff_op = self.model.S

        if use_symmetric:
            result = sym_diff_op
        else:
            result = diff_op

        if ignore_diagonal:
            result = result - np.diag(np.diag(result))

        return result

    def kernel(self, ignore_diagonal: bool = False) -> np.ndarray:
        """
        Returns kernel matrix used to build diffusion operator.

        Args:
            ignore_diagonal: If True, set diagonal entries to zero. Default False.

        Returns:
            N×N kernel matrix.
        """
        if not self._is_fitted:
            raise RuntimeError("DiffusionMap model is not fitted yet. Call `fit` first.")

        if self._resolved_backend == "torchdr":
            K = self._torchdr_affinity
        else:
            K = np.asarray(self.model.G.kernel.todense())
        if ignore_diagonal:
            K = K - np.diag(np.diag(K))
        return K