# Tests for latent algorithms
