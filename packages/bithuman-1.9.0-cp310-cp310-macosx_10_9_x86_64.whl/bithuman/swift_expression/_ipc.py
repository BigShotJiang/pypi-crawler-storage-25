"""Async wire-protocol helpers for the Expression daemon.

The daemon is ``bithuman-expression-daemon`` from the
:code:`bithuman-expression-swift` repository. Every message is:

.. code-block:: text

    [u32 BE header_len][UTF-8 JSON header][u32 BE payload_len][raw payload]

Headers are always JSON so the wire is readable when tee'd through
``tee`` or a log sink; payloads carry raw bytes (pixel data, audio
samples) in their native layout. A message with no payload has
``payload_len == 0`` and zero body bytes.

This module only defines the byte-level layer — the Python runtime
lives in :mod:`bithuman.swift_expression.runtime`. Keeping the two
separate means the IPC tests can be exercised with pure ``asyncio``
streams (no subprocess), and the runtime can swap in mock transports
without touching parsing logic.

Length caps mirror the Swift side (1 MiB header, 64 MiB payload) so
a corrupted or adversarial stream can't balloon memory.
"""

from __future__ import annotations

import asyncio
import json
import struct
from typing import Any, Dict, Tuple

HEADER_MAX_BYTES = 1 << 20       # 1 MiB
PAYLOAD_MAX_BYTES = 64 << 20     # 64 MiB


class IPCError(Exception):
    """Raised on a malformed or truncated message."""


async def read_frame(
    reader: asyncio.StreamReader,
) -> Tuple[Dict[str, Any], bytes]:
    """Read one framed message. Returns ``(header_dict, payload_bytes)``.

    Raises ``IPCError`` on truncation, JSON parse failure, or over-cap
    lengths. An ``asyncio.IncompleteReadError`` at the start of a
    frame is propagated as-is so callers can detect a clean EOF
    (daemon exited) vs. a corrupted stream.
    """
    header_len_bytes = await reader.readexactly(4)
    header_len = struct.unpack(">I", header_len_bytes)[0]
    if header_len > HEADER_MAX_BYTES:
        raise IPCError(
            f"header_len {header_len} exceeds max {HEADER_MAX_BYTES}"
        )
    header_raw = await reader.readexactly(header_len)
    try:
        header = json.loads(header_raw.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        raise IPCError(f"malformed header JSON: {e}") from e
    if not isinstance(header, dict):
        raise IPCError(f"header is not a JSON object: {header!r}")

    payload_len_bytes = await reader.readexactly(4)
    payload_len = struct.unpack(">I", payload_len_bytes)[0]
    if payload_len > PAYLOAD_MAX_BYTES:
        raise IPCError(
            f"payload_len {payload_len} exceeds max {PAYLOAD_MAX_BYTES}"
        )
    payload = await reader.readexactly(payload_len) if payload_len > 0 else b""
    return header, payload


def encode_frame(header: Dict[str, Any], payload: bytes = b"") -> bytes:
    """Build a framed message ready to write to the daemon's stdin.

    Consumers typically want atomic writes — construct the bytes
    here and hand them to a single ``StreamWriter.write`` call rather
    than writing the header and payload separately (which would let
    two concurrent :func:`encode_frame` callers interleave their
    bytes mid-frame and desync the daemon).
    """
    header_bytes = json.dumps(
        header, separators=(",", ":"), sort_keys=True
    ).encode("utf-8")
    return (
        struct.pack(">I", len(header_bytes))
        + header_bytes
        + struct.pack(">I", len(payload))
        + payload
    )
