"""Locate the ``bithuman-expression-daemon`` binary.

Three lookup strategies, in order of precedence:

1. ``BITHUMAN_EXPRESSION_DAEMON`` environment variable — absolute
   path. Used in development when building the daemon locally
   (``swift build -c release -Xswiftc …`` produces a binary under
   ``.build/release/``). CI also sets this in tests that exercise
   a freshly-built binary.

2. A bundled binary inside :mod:`bithuman._daemon_bin` — shipped in
   the macOS arm64 wheel by the release workflow. Accessed via
   :mod:`importlib.resources` so it works both on disk and inside a
   zipimport / installer cache.

3. ``PATH`` fallback — a system-wide install via Homebrew or a
   manual drop-in to ``/usr/local/bin``.

If none of the three yield an executable, return ``None`` so the
caller can surface :class:`ExpressionModelNotSupported` with a
helpful install hint.
"""

from __future__ import annotations

import importlib.resources as pkg_resources
import os
import platform
import shutil
from pathlib import Path
from typing import Optional

DAEMON_NAME = "bithuman-expression-daemon"
ENV_OVERRIDE = "BITHUMAN_EXPRESSION_DAEMON"


def find_daemon_binary() -> Optional[Path]:
    """Return an absolute path to the daemon binary, or ``None``.

    Does not validate the Apple-Silicon + M3 requirement — that's the
    runtime's job. Callers on Linux / Windows / Intel Macs should
    refuse up-front even if a stale binary is discoverable, because
    the Expression pipeline will fail at load time on those hosts.
    """
    override = os.environ.get(ENV_OVERRIDE)
    if override:
        p = Path(override).expanduser()
        if _is_executable(p):
            return p

    bundled = _bundled_binary()
    if bundled is not None:
        return bundled

    onpath = shutil.which(DAEMON_NAME)
    if onpath:
        return Path(onpath)
    return None


def is_supported_platform() -> bool:
    """Expression runtime requires macOS on Apple Silicon.

    The Expression pipeline links against Apple-only ML runtimes
    (Metal + the Neural Engine via CoreML) and assumes the memory
    bandwidth profile of the M3-or-newer chips. This helper is
    intentionally conservative — if the host is ambiguous, return
    False and surface a clear error.
    """
    if platform.system() != "Darwin":
        return False
    if platform.machine().lower() not in {"arm64", "aarch64"}:
        return False
    return True


def _is_executable(path: Path) -> bool:
    return path.is_file() and os.access(path, os.X_OK)


def _bundled_binary() -> Optional[Path]:
    try:
        base = pkg_resources.files("bithuman._daemon_bin")
    except (ModuleNotFoundError, FileNotFoundError):
        return None
    candidate = base / DAEMON_NAME
    # ``importlib.resources.files`` may return a ``MultiplexedPath``
    # when the package only has a ``.gitkeep`` placeholder (no real
    # binary bundled). Guard with a filesystem materialization.
    try:
        real = Path(str(candidate))
    except TypeError:
        return None
    if _is_executable(real):
        return real
    return None
