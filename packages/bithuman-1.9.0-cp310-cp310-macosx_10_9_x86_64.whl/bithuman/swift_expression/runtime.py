"""Out-of-process Expression runtime for Python.

``SwiftExpressionRuntime`` mirrors the :class:`AsyncBithuman`
contract (``create``, ``push_audio``, ``flush``, ``interrupt``,
``run``, ``shutdown``) so Python consumers that already target
Essence models can swap in an Expression model on macOS + Apple
Silicon without rewriting their audio/video pipeline.

Internally it spawns ``bithuman-expression-daemon`` from the
:code:`bithuman-expression-swift` repository, streams framed
messages over stdin/stdout, and surfaces frames as
:class:`bithuman.api.VideoFrame` objects.

See ``bithuman.swift_expression._ipc`` for the byte-level protocol.

This class is not a drop-in subclass of :class:`AsyncBithuman` —
the internals of the Essence path (token refresh, model-hash
validation, generator C extension) don't apply. The two classes
share a public vocabulary by convention, and
:meth:`AsyncBithuman.create` dispatches to this class for
:code:`model_type == "expression"` containers.
"""

from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from typing import AsyncIterator, Optional

import numpy as np

from ..api import AudioChunk, VideoFrame
from ..exceptions import (
    AccountStatusError,
    ExpressionModelNotSupported,
    ModelLoadError,
)
from ._binary import ENV_OVERRIDE, find_daemon_binary, is_supported_platform
from ._ipc import IPCError, encode_frame, read_frame

logger = logging.getLogger(__name__)


_INSTALL_HINT = (
    "Expression runtime requires the `bithuman-expression-daemon` binary. "
    "The macOS arm64 wheel ships it pre-built; if you installed from source "
    "or on an unsupported platform, build it yourself from "
    "https://github.com/bithuman-product/bithuman-expression-swift with "
    "`swift build -c release --product bithuman-expression-daemon` and "
    f"point ${ENV_OVERRIDE} at the resulting binary."
)


class SwiftExpressionRuntime:
    """Async client of ``bithuman-expression-daemon``.

    Lifecycle::

        runtime = await SwiftExpressionRuntime.create(
            model_path="path/to/expression.imx",
            api_secret=os.environ["BITHUMAN_API_SECRET"],
        )
        await runtime.push_audio(pcm_bytes, sample_rate=24_000)
        await runtime.flush()
        async for frame in runtime.run():
            ...                     # frame.bgr_image / frame.audio_chunk
        await runtime.shutdown()

    The out-of-process daemon owns the animation + rendering work;
    this class only manages the async I/O and data-format boundaries.
    """

    def __init__(
        self,
        *,
        process: asyncio.subprocess.Process,
        frame_queue: "asyncio.Queue[VideoFrame | None]",
        reader_task: "asyncio.Task[None]",
        frame_width: int,
        frame_height: int,
    ) -> None:
        self._process = process
        self._frame_queue = frame_queue
        self._reader_task = reader_task
        self._frame_width = frame_width
        self._frame_height = frame_height
        self._billing_error: Optional[AccountStatusError] = None
        self._closed = False

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    async def create(
        cls,
        *,
        model_path: str,
        api_secret: Optional[str] = None,
        daemon_path: Optional[str] = None,
        frame_queue_maxsize: int = 32,
        quality: str = "medium",
    ) -> "SwiftExpressionRuntime":
        """Spawn the daemon and load ``model_path``.

        Blocks until the daemon emits its ``ready`` event. Raises
        :class:`ExpressionModelNotSupported` if the platform is
        unsupported or the binary is missing; :class:`ModelLoadError`
        if the daemon fails to open the container (bad path, wrong
        ``model_type``, missing weights); :class:`AccountStatusError`
        if the ``api_secret`` is rejected.

        ``quality`` selects a render preset:

          - ``"medium"`` (default) — realtime-safe. ~1.8× realtime at
            384×384, ~1.1× at 512×512 on an M5. Use for live streaming.
          - ``"high"`` — offline video quality. ~2× slower than medium
            but visibly crisper. Recommended for pre-recorded video
            generation. Sub-realtime at 512×512 on an M5.

        """
        if quality not in ("medium", "high"):
            raise ValueError(f"quality must be 'medium' or 'high', got {quality!r}")
        if not is_supported_platform():
            raise ExpressionModelNotSupported(
                "Expression runtime is only supported on macOS with Apple "
                "Silicon (M3 or later). " + _INSTALL_HINT
            )

        exe = Path(daemon_path) if daemon_path else find_daemon_binary()
        if exe is None or not exe.is_file():
            raise ExpressionModelNotSupported(
                "bithuman-expression-daemon binary not found. " + _INSTALL_HINT
            )

        process = await asyncio.create_subprocess_exec(
            str(exe),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=None,  # inherit so daemon logs stream to the caller
        )
        assert process.stdin is not None and process.stdout is not None

        # Tell the daemon to load the model. A single `load` op
        # yields either a `ready` event or an `error` / `billing_error`
        # event; we read exactly one response frame here so startup
        # failures surface synchronously.
        load_header = {
            "op": "load",
            "model_path": os.fspath(model_path),
            "quality": quality,
        }
        if api_secret:
            load_header["api_secret"] = api_secret
        process.stdin.write(encode_frame(load_header))
        await process.stdin.drain()

        try:
            header, _ = await read_frame(process.stdout)
        except (IPCError, asyncio.IncompleteReadError) as e:
            process.terminate()
            await process.wait()
            raise ModelLoadError(
                f"Daemon exited without a ready event: {e}"
            ) from e

        event_type = header.get("type")
        if event_type == "billing_error":
            process.terminate()
            await process.wait()
            raise AccountStatusError(
                f"HTTP {header.get('code')}: {header.get('message')}"
            )
        if event_type == "error":
            process.terminate()
            await process.wait()
            raise ModelLoadError(header.get("message") or "daemon error")
        if event_type != "ready":
            process.terminate()
            await process.wait()
            raise ModelLoadError(
                f"Unexpected event at startup: {header!r}"
            )

        frame_queue: "asyncio.Queue[VideoFrame | None]" = asyncio.Queue(
            maxsize=frame_queue_maxsize
        )
        frame_w = int(header.get("frame_width", 512))
        frame_h = int(header.get("frame_height", 512))

        # Reader task: drains the daemon's stdout into the frame
        # queue. Lives for the runtime's lifetime; exits on clean
        # EOF (daemon shut down) or any IPC error.
        rt: "SwiftExpressionRuntime"
        reader_task: "asyncio.Task[None]"
        loop = asyncio.get_running_loop()
        reader_task = loop.create_task(
            cls._reader_loop(process, frame_queue, frame_w, frame_h)
        )
        # The reader task pokes the billing-error slot on the runtime
        # instance, so we construct the runtime first.
        rt = cls(
            process=process,
            frame_queue=frame_queue,
            reader_task=reader_task,
            frame_width=frame_w,
            frame_height=frame_h,
        )
        # Attach the billing-error sink so the reader can signal fatal
        # billing states back to push_audio callers.
        reader_task.add_done_callback(rt._on_reader_done)
        return rt

    # ------------------------------------------------------------------
    # API surface (mirrors AsyncBithuman)
    # ------------------------------------------------------------------

    def get_frame_size(self) -> "tuple[int, int]":
        return self._frame_width, self._frame_height

    async def push_audio(
        self,
        data: "bytes | np.ndarray",
        sample_rate: int,
        last_chunk: bool = True,
    ) -> None:
        """Enqueue audio for the daemon to render against.

        Input format:
          - ``bytes``: int16 little-endian PCM (to match the Essence
            `AsyncBithuman.push_audio` contract).
          - ``np.ndarray``: float32 or int16, mono.

        Automatically converts to the daemon's Float32 LE wire
        format. ``last_chunk=True`` does not flush — call
        :meth:`flush` explicitly when an utterance ends so the SDK's
        tail-flush path runs.
        """
        self._raise_if_billing_failed()
        if self._closed:
            raise RuntimeError("runtime closed")
        float_bytes = _coerce_to_float32_le(data)
        assert self._process.stdin is not None
        self._process.stdin.write(
            encode_frame(
                {"op": "push_audio", "sample_rate": int(sample_rate)},
                float_bytes,
            )
        )
        await self._process.stdin.drain()

    async def flush(self) -> None:
        assert self._process.stdin is not None
        self._process.stdin.write(encode_frame({"op": "flush"}))
        await self._process.stdin.drain()

    async def interrupt(self) -> None:
        assert self._process.stdin is not None
        self._process.stdin.write(encode_frame({"op": "interrupt"}))
        await self._process.stdin.drain()

    async def run(self) -> AsyncIterator[VideoFrame]:
        """Async iterator yielding rendered frames.

        Terminates when the daemon exits or the runtime is shut down.
        The iterator is single-consumer — spawning two concurrent
        ``run()`` calls will deliver frames to whichever happens to
        call ``queue.get()`` first and is not supported.
        """
        while True:
            item = await self._frame_queue.get()
            if item is None:
                return
            yield item

    async def shutdown(self) -> None:
        if self._closed:
            return
        self._closed = True
        assert self._process.stdin is not None
        try:
            self._process.stdin.write(encode_frame({"op": "shutdown"}))
            await self._process.stdin.drain()
            self._process.stdin.close()
        except (BrokenPipeError, ConnectionResetError):
            pass
        try:
            await asyncio.wait_for(self._process.wait(), timeout=5.0)
        except asyncio.TimeoutError:
            logger.warning("daemon did not exit in 5s — terminating")
            self._process.terminate()
            try:
                await asyncio.wait_for(self._process.wait(), timeout=2.0)
            except asyncio.TimeoutError:
                self._process.kill()
                await self._process.wait()
        # Reader task exits naturally when stdout EOFs.
        if not self._reader_task.done():
            try:
                await asyncio.wait_for(self._reader_task, timeout=2.0)
            except asyncio.TimeoutError:
                self._reader_task.cancel()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _raise_if_billing_failed(self) -> None:
        if self._billing_error is not None:
            raise self._billing_error

    def _on_reader_done(self, task: "asyncio.Task[None]") -> None:
        # When the reader task exits, also signal the iterator to
        # terminate — push None sentinel if nothing else has yet.
        try:
            exc = task.exception()
        except asyncio.CancelledError:
            exc = None
        if exc is not None:
            logger.error("reader task exited with exception: %s", exc)
        # Best-effort sentinel — may fail on a full queue, which is
        # fine; the consumer will hit EOF via the None already in
        # flight.
        try:
            self._frame_queue.put_nowait(None)
        except asyncio.QueueFull:
            pass

    @staticmethod
    async def _reader_loop(
        process: asyncio.subprocess.Process,
        queue: "asyncio.Queue[VideoFrame | None]",
        frame_width: int,
        frame_height: int,
    ) -> None:
        """Drain the daemon's stdout. Converts each `chunk` event into
        per-frame :class:`VideoFrame` objects, populates the queue.
        """
        assert process.stdout is not None
        try:
            while True:
                try:
                    header, payload = await read_frame(process.stdout)
                except asyncio.IncompleteReadError:
                    # Clean EOF — daemon exited.
                    break

                event_type = header.get("type")
                if event_type == "chunk":
                    frames = _unpack_chunk(
                        header, payload, frame_width, frame_height
                    )
                    for f in frames:
                        await queue.put(f)
                elif event_type == "end_of_stream":
                    eos = VideoFrame(
                        bgr_image=None,
                        audio_chunk=None,
                        end_of_speech=True,
                    )
                    await queue.put(eos)
                elif event_type == "billing_error":
                    # Signal via an exception attached to the queue;
                    # callers discover it via the next push_audio.
                    err = AccountStatusError(
                        f"HTTP {header.get('code')}: {header.get('message')}"
                    )
                    logger.error("daemon billing error: %s", err)
                elif event_type == "error":
                    logger.error(
                        "daemon error: %s", header.get("message", "(no message)")
                    )
                elif event_type == "shutdown_ack":
                    break
                else:
                    logger.debug("daemon event ignored: %s", header)
        finally:
            await queue.put(None)


# ------------------------------------------------------------------
# Byte helpers
# ------------------------------------------------------------------


def _coerce_to_float32_le(data: "bytes | np.ndarray") -> bytes:
    """Convert caller audio into Float32 LE bytes for the daemon.

    Accepts raw int16 bytes (the Essence API contract),
    :class:`np.ndarray` of int16, int32, float32, or float64.
    """
    if isinstance(data, (bytes, bytearray, memoryview)):
        # Assume int16 LE — matches AsyncBithuman.push_audio.
        arr = np.frombuffer(data, dtype=np.int16).astype(np.float32)
        arr /= 32768.0
    else:
        arr = np.asarray(data)
        if arr.dtype == np.int16:
            arr = arr.astype(np.float32) / 32768.0
        elif arr.dtype == np.int32:
            arr = arr.astype(np.float32) / 2147483648.0
        elif arr.dtype == np.float64:
            arr = arr.astype(np.float32)
        elif arr.dtype != np.float32:
            raise TypeError(f"unsupported audio dtype: {arr.dtype}")
    # Guarantee contiguous little-endian byte order. On all
    # platforms we ship to, numpy's default is native-LE on arm64 +
    # x86_64 — but an explicit tobytes() after .astype(np.float32)
    # produces LE regardless of the source buffer's stride.
    return arr.astype("<f4", copy=False).tobytes()


def _unpack_chunk(
    header: dict,
    payload: bytes,
    frame_width: int,
    frame_height: int,
) -> "list[VideoFrame]":
    """Split a ``chunk`` payload into individual :class:`VideoFrame`.

    Payload layout (from the Swift daemon's ``writeChunk``):
    ``[frame_0 RGB bytes][frame_1 RGB bytes]…[frame_N-1 RGB bytes]
    [24 kHz Float32 LE audio samples]``.

    Each frame is ``H × W × 3`` bytes. The audio is partitioned
    evenly across frames so each :class:`VideoFrame` carries a
    matching :class:`AudioChunk` slice.
    """
    frame_count = int(header.get("frame_count", 0))
    # Chunk header carries the actual per-frame dims (may differ from
    # the ready event's frame_size if the decoder output resolution
    # is lower than the SDK's declared frameSize).
    frame_height = int(header.get("frame_height", frame_height))
    frame_width = int(header.get("frame_width", frame_width))
    bytes_per_frame = int(header.get("bytes_per_frame", frame_height * frame_width * 3))
    audio_samples = int(header.get("audio_samples", 0))
    audio_sr = int(header.get("audio_sample_rate", 24_000))

    if frame_count == 0:
        return []

    frames_bytes = frame_count * bytes_per_frame
    if len(payload) < frames_bytes:
        logger.warning(
            "short chunk payload: frames_bytes=%d got=%d", frames_bytes, len(payload)
        )
        return []

    # Zero-copy view over the payload bytes. Each frame becomes a
    # (H, W, 3) slice into the same underlying buffer. We reverse
    # the channel axis once (`[..., ::-1]`) for the RGB→BGR swap;
    # the result is a non-contiguous view, but that's fine — cv2,
    # PIL, and numpy all handle strided arrays. Consumers that need
    # contiguous bytes call `.copy()` themselves at read time.
    #
    # `payload` is a `bytes` object (immutable), so the views we
    # hand out via VideoFrame inherit that immutability. If a
    # consumer mutates through a writable view it'll raise a
    # ValueError, which is the intended contract.
    frame_buf = np.frombuffer(
        payload, dtype=np.uint8, count=frames_bytes
    ).reshape(frame_count, frame_height, frame_width, 3)
    bgr = frame_buf[..., ::-1]  # RGB → BGR (strided view, zero-copy)

    audio = np.frombuffer(
        payload, dtype="<f4", count=audio_samples, offset=frames_bytes
    ) if audio_samples > 0 else np.zeros(0, dtype=np.float32)

    samples_per_frame = (audio_samples // frame_count) if frame_count > 0 else 0
    out: "list[VideoFrame]" = []
    for i in range(frame_count):
        start = i * samples_per_frame
        end = start + samples_per_frame
        audio_chunk: Optional[AudioChunk] = None
        if samples_per_frame > 0:
            # AudioChunk expects int16 PCM. Small (usually 960
            # samples / 40 ms) so the allocation is trivial.
            int16 = np.clip(
                audio[start:end] * 32767.0, -32768, 32767
            ).astype(np.int16)
            audio_chunk = AudioChunk(
                data=int16, sample_rate=audio_sr, last_chunk=False
            )
        out.append(
            VideoFrame(
                bgr_image=bgr[i],
                audio_chunk=audio_chunk,
                frame_index=i,
            )
        )
    return out
