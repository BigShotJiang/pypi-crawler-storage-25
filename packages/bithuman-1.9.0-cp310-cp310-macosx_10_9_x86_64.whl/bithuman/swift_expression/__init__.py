"""Out-of-process Expression runtime binding.

Load an Expression ``.imx`` model from Python by spawning the
``bithuman-expression-daemon`` binary from the
:code:`bithuman-expression-swift` SDK. Mirrors the
:class:`bithuman.AsyncBithuman` vocabulary so callers that already
drive Essence models can switch in-place.

.. code-block:: python

    from bithuman.swift_expression import SwiftExpressionRuntime

    runtime = await SwiftExpressionRuntime.create(
        model_path="expression.imx",
        api_secret=os.environ["BITHUMAN_API_SECRET"],
    )
    await runtime.push_audio(pcm_bytes, sample_rate=24_000)
    await runtime.flush()
    async for frame in runtime.run():
        display(frame.bgr_image)
    await runtime.shutdown()

Requires **macOS with Apple Silicon (M3 or later)**. Linux, Windows,
and Intel Macs raise :class:`bithuman.ExpressionModelNotSupported`.
"""

from ._binary import find_daemon_binary, is_supported_platform
from .runtime import SwiftExpressionRuntime

__all__ = [
    "SwiftExpressionRuntime",
    "find_daemon_binary",
    "is_supported_platform",
]
