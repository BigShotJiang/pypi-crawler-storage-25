"""Package holding the ``bithuman-expression-daemon`` binary.

Empty by default. On macOS arm64 wheels the release workflow drops
the compiled daemon here before :mod:`cibuildwheel` runs; the
binary is then discoverable via :mod:`importlib.resources`. On
other platforms the directory contains only this ``__init__`` and
``.gitkeep`` — the runtime falls back to raising
:class:`bithuman.ExpressionModelNotSupported` with install guidance.
"""
