"""Top-level Click group for ``tfy download`` (e.g. ``download skill``)."""

from pathlib import Path
from typing import Optional

import rich_click as click

from truefoundry.cli.console import console
from truefoundry.cli.const import COMMAND_CLS, GROUP_CLS
from truefoundry.cli.util import handle_exception_wrapper
from truefoundry.ml._autogen.client.exceptions import ApiException, NotFoundException
from truefoundry.ml.agent_skill import run_skill_download


@click.group(
    name="download",
    cls=GROUP_CLS,
    help="Download resources like agent skills from TrueFoundry",
)
def download_cli(): ...


@click.command(
    name="skill",
    cls=COMMAND_CLS,
    short_help="Download an agent skill version by FQN",
)
@click.option(
    "--fqn",
    required=True,
    type=str,
    help=(
        "FQN of the agent skill version, e.g. "
        "'agent-skill:truefoundry/my-skills/my-skill:1'"
    ),
)
@click.option(
    "--dir",
    "-d",
    "directory",
    type=click.Path(file_okay=False, writable=True),
    default=".",
    show_default=True,
    help="Directory where skill files will be downloaded (created if missing)",
)
@click.option(
    "--overwrite",
    is_flag=True,
    default=False,
    help="Overwrite existing files in the destination directory",
)
@click.option(
    "--progress/--no-progress",
    is_flag=True,
    show_default=True,
    default=None,
    help="Whether to show a progress bar while downloading",
)
@handle_exception_wrapper
def download_skill(
    fqn: str,
    directory: str,
    overwrite: bool,
    progress: Optional[bool] = None,
):
    """Download an agent skill version by FQN"""
    dest = Path(directory).expanduser().resolve()
    try:
        download_path = run_skill_download(
            fqn,
            dest,
            overwrite=overwrite,
            progress=progress,
        )
    except NotFoundException:
        raise click.ClickException(
            f"No agent skill version found for FQN {fqn!r}. "
            "Please ensure the FQN is correct and your user has access to the skill"
        ) from None
    except ApiException as exc:
        raise click.ClickException(
            f"{exc.reason or 'Request failed'} (HTTP {exc.status})"
        ) from None
    except OSError as exc:
        raise click.ClickException(
            f"Failed to write to destination {dest!r}: {exc}"
        ) from None
    console.print(f"Downloaded skill files to {download_path}")


def get_download_command():
    """Return the Click group bound to the ``download`` command name."""
    download_cli.add_command(download_skill)
    return download_cli
