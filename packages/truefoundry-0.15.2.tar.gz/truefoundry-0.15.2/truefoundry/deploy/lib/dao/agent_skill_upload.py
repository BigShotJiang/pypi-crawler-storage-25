"""Programmatic skill upload: build an ``agent-skill`` resource and run deploy apply."""

from pathlib import Path

from truefoundry_sdk import AgentSkillManifest, AgentSkillSourceLocal

from truefoundry.deploy.lib.clients.servicefoundry_client import (
    ServiceFoundryServiceClient,
)
from truefoundry.deploy.lib.dao import apply as apply_lib
from truefoundry.deploy.lib.dao.agent_skill import AGENT_SKILL_MANIFEST_TYPE
from truefoundry.deploy.lib.dao.agent_skill_validation import (
    validate_and_read_local_agent_skill,
)
from truefoundry.deploy.lib.model.entity import ManifestLike, Resource


def upload_agent_skill(repository: str, skill_dir: Path) -> None:
    """Resolve one local agent-skill manifest through apply."""
    root = skill_dir.expanduser().resolve()
    skill_md = validate_and_read_local_agent_skill(root)
    name = skill_md.name
    skill_manifest = AgentSkillManifest(
        name=name,
        ml_repo=repository,
        metadata={},
        source=AgentSkillSourceLocal(type="local", skill_dir=str(root)),
    )
    manifest = ManifestLike.parse_obj(skill_manifest.dict(exclude_none=True))
    resource = Resource(
        type=AGENT_SKILL_MANIFEST_TYPE,
        name=name,
        manifest=manifest,
        file_path=str(root),
        dependencies=[],
    )
    client = ServiceFoundryServiceClient()
    results = apply_lib.apply_manifest_resources(
        [resource], client, dry_run=False, show_diff=False
    )
    if not results:
        raise RuntimeError("Agent skill upload failed: nothing was uploaded.")
    if not results[0].success:
        raise RuntimeError(f"Agent skill upload failed: {results[0].message}")
