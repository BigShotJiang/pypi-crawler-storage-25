"""Local ``agent_skill`` source: pack, stage, upload.

Pipeline: :mod:`agent_skill_validation` (paths + ``SKILL.md``) → stage → tar + pairs →
``log_artifacts`` → apply manifest dict.
"""

import os
import tarfile
import tempfile
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from truefoundry_sdk import (
    AgentSkillManifest,
    AgentSkillSourceBlobStorage,
    AgentSkillSourceInline,
    AgentSkillSourceLocal,
)

from truefoundry import client as tfy_client
from truefoundry.common.session import Session
from truefoundry.deploy.lib.dao.agent_skill_validation import (
    AGENT_SKILL_MD_FILENAME,
    validate_and_read_local_agent_skill,
)
from truefoundry.deploy.lib.model.entity import ManifestLike, Resource
from truefoundry.ml.artifact.truefoundry_artifact_repo import (
    ArtifactIdentifier,
    MlFoundryArtifactsRepository,
)
from truefoundry.ml.log_types.artifacts.utils import (
    _copy_additional_files,
    _get_src_dest_pairs,
)
from truefoundry.ml.session import MLFoundryServerApiClient
from truefoundry.pydantic_v1 import ValidationError

# Wire/API manifest type is ``agent-skill`` (YAML + SDK); must match ``Resource.type``.
AGENT_SKILL_MANIFEST_TYPE: str = "agent-skill"

_AGENT_SKILL_TARBALL_ARTIFACT_PATH = ".truefoundry/skill.tar"
_SUPPORTING_FILES_KEY = "supporting_files"


def agent_skill_supporting_files_from_dir(skill_dir: Path) -> bool:
    """Whether any file exists under ``skill_dir`` other than the root ``SKILL.md``."""
    root = Path(skill_dir).resolve()
    # Match ``_copy_tree`` in ``ml.log_types.artifacts.utils`` (``os.path.isdir`` follows
    # symlinks to directories) so ``supporting_files`` matches upload behavior.
    for dirpath, _, names in os.walk(skill_dir, followlinks=True):
        here = Path(dirpath).resolve()
        for name in names:
            p = Path(dirpath) / name
            if not p.is_file():
                continue
            if here == root and name == AGENT_SKILL_MD_FILENAME:
                continue
            return True
    return False


def _agent_skill_metadata_with_supporting_files(
    metadata: Dict[str, Any], skill_dir: Path
) -> Dict[str, Any]:
    """Return ``metadata`` with ``supporting_files`` set from ``skill_dir``."""
    merged: Dict[str, Any] = dict(metadata or {})
    merged[_SUPPORTING_FILES_KEY] = agent_skill_supporting_files_from_dir(skill_dir)
    return merged


def _stage_local_agent_skill_inline(
    manifest: AgentSkillManifest,
    metadata: Dict[str, Any],
    skill_md_text: str,
) -> Any:
    """``artifact_versions.stage`` with inline source; user manifest is copied then patched."""
    staging_manifest = manifest.copy(deep=True)
    staging_manifest.metadata = metadata
    staging_manifest.source = AgentSkillSourceInline(skill_md=skill_md_text)
    return tfy_client.artifact_versions.stage(manifest=staging_manifest)


def _upload_local_agent_skill_artifacts(
    version_id: str, session: Session, src_dest_pairs: List[Tuple[str, str]]
) -> None:
    """``log_artifacts`` for the staged artifact version."""
    api_client = MLFoundryServerApiClient.from_session(session)
    artifacts_repo = MlFoundryArtifactsRepository(
        artifact_identifier=ArtifactIdentifier(
            artifact_version_id=uuid.UUID(version_id)
        ),
        api_client=api_client,
    )
    artifacts_repo.log_artifacts(src_dest_pairs=src_dest_pairs)


def _write_agent_skill_tarball(
    src_arcname_pairs: List[Tuple[str, str]], tarball_path: str
) -> None:
    """Write tar at ``tarball_path`` using the provided ``(src, arcname)`` pairs."""
    with tarfile.open(tarball_path, mode="w") as tf:
        for src, arcname in src_arcname_pairs:
            tf.add(os.path.realpath(src), arcname=arcname)


def _upload_local_agent_skill(
    agent_skill_manifest: AgentSkillManifest,
    skill_dir: Path,
    skill_md_text: str,
    description: str,
    session: Session,
) -> Dict[str, Any]:
    """Run stage → prepare → upload; return the apply-time blob manifest dict."""
    skill_name = agent_skill_manifest.name
    metadata = _agent_skill_metadata_with_supporting_files(
        agent_skill_manifest.metadata or {}, skill_dir
    )

    stage_response = _stage_local_agent_skill_inline(
        agent_skill_manifest, metadata, skill_md_text
    )
    version_id: str = stage_response.id
    try:
        # Staging dir must live until log_artifacts runs (paths point at copied files).
        with tempfile.TemporaryDirectory(
            prefix="truefoundry-agent-skill-"
        ) as staging_root:
            # Same pipeline as model/dataset: copy tree, then stable (src, relpath) pairs.
            dest_to_src = _copy_additional_files(
                root_dir=staging_root,
                files_dir="",
                model_dir=None,
                additional_files=[(str(skill_dir.resolve()), skill_name)],
                ignore_model_dir_dest_conflict=True,
            )
            # Remote layout (consumed by log_artifacts): paths relative to staging_root,
            # so they already start with <skill_name>/.
            src_dest_pairs: List[Tuple[str, str]] = list(
                _get_src_dest_pairs(root_dir=staging_root, dest_to_src_map=dest_to_src)
            )
            skill_staging_dir = os.path.join(staging_root, skill_name)
            src_arcname_pairs: List[Tuple[str, str]] = list(
                _get_src_dest_pairs(
                    root_dir=skill_staging_dir, dest_to_src_map=dest_to_src
                )
            )
            tarball_path: Optional[str] = None
            try:
                # Write tar to a temp file (streamed) so we never hold a full in-memory
                # copy; log_artifacts still needs a filesystem path to the file.
                tarball_tmp = tempfile.NamedTemporaryFile(
                    suffix=".tar", prefix="skill_", delete=False
                )
                tarball_path = tarball_tmp.name
                tarball_tmp.close()
                _write_agent_skill_tarball(src_arcname_pairs, tarball_path)
                src_dest_pairs.append(
                    (tarball_path, _AGENT_SKILL_TARBALL_ARTIFACT_PATH)
                )
                _upload_local_agent_skill_artifacts(version_id, session, src_dest_pairs)
            finally:
                if tarball_path is not None:
                    try:
                        os.unlink(tarball_path)
                    except OSError:
                        pass
        apply_manifest = agent_skill_manifest.copy(deep=True)
        apply_manifest.metadata = metadata
        apply_manifest.source = AgentSkillSourceBlobStorage(
            description=description, uri=stage_response.storage_root
        )
        return apply_manifest.dict(exclude_none=True)
    except Exception as upload_ex:
        try:
            tfy_client.artifact_versions.mark_stage_failure(id=version_id)
        except Exception:
            pass
        raise upload_ex


def handle_agent_skill_local_source(resource: Resource, dry_run: bool) -> Resource:
    """Local ``agent_skill`` with ``source: local``: upload to blob, or error, dry-run, or no-op."""
    if resource.error_message or resource.skipped_message:
        return resource
    if resource.type != AGENT_SKILL_MANIFEST_TYPE:
        return resource

    try:
        agent_skill_manifest = AgentSkillManifest.parse_obj(resource.manifest.dict())
    except Exception as ex:
        return Resource(
            type=resource.type,
            name=resource.name,
            manifest=resource.manifest,
            file_path=resource.file_path,
            dependencies=resource.dependencies,
            error_message=str(ex),
        )

    source = agent_skill_manifest.source
    if not isinstance(source, AgentSkillSourceLocal):
        return resource

    skill_dir = Path(os.path.expanduser(source.skill_dir)).resolve()

    try:
        skill_md = validate_and_read_local_agent_skill(
            skill_dir, agent_skill_manifest.name
        )
    except ValueError as ex:
        return Resource(
            type=resource.type,
            name=resource.name,
            manifest=resource.manifest,
            file_path=resource.file_path,
            dependencies=resource.dependencies,
            error_message=str(ex),
        )

    if dry_run:
        return Resource(
            type=resource.type,
            name=resource.name,
            manifest=resource.manifest,
            file_path=resource.file_path,
            dependencies=resource.dependencies,
            skipped_message=(
                f"[Dry Run] Successfully configured manifest {resource.name} of type "
                f"{resource.type}. (No changes were applied)"
            ),
        )

    try:
        session = Session.new()
        prepared = _upload_local_agent_skill(
            agent_skill_manifest,
            skill_dir,
            skill_md.skill_md_text,
            skill_md.description,
            session=session,
        )
        parsed = ManifestLike.parse_obj(prepared)
    except Exception as ex:
        err_msg = (
            f"Failed to parse prepared agent_skill manifest: {ex}"
            if isinstance(ex, ValidationError)
            else f"Failed to prepare manifest {resource.name} of type {resource.type}. Error: {ex}."
        )
        return Resource(
            type=resource.type,
            name=resource.name,
            manifest=resource.manifest,
            file_path=resource.file_path,
            dependencies=resource.dependencies,
            error_message=err_msg,
        )
    return Resource(
        type=resource.type,
        name=resource.name,
        manifest=parsed,
        file_path=resource.file_path,
        dependencies=resource.dependencies,
    )
