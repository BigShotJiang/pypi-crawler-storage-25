"""MeteoSwiss Weather Data Package"""

__version__ = "0.1.4"
