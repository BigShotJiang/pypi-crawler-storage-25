# SPDX-FileCopyrightText: © 2026 Suho Kang
# SPDX-License-Identifier: MIT
"""Dependency graph construction and topological sort.

Implements dependency resolution for binding evaluation order:
self-reference collection, bare identifier collection, and
Kahn's algorithm for topological sorting with cycle detection.
"""

from __future__ import annotations

from typing import Any

from ..ast_nodes import (
    AreBinding, Binding, FunctionExpr,
    Identifier, Node,
)

class DependencyMixin:
    """Dependency graph and topological sort methods mixed into the Evaluator."""

    @staticmethod
    def _references_own_name(b: Binding | AreBinding, name: str) -> bool:
        """Check if a binding's value AST references <name> as a bare identifier."""
        nodes: list[Any] = []
        if isinstance(b, Binding):
            nodes.append(b.value)
        else:
            nodes.extend(b.elements)
        while nodes:
            node = nodes.pop()
            if node is None:
                continue
            if isinstance(node, Identifier) and node.name == name:
                return True
            for attr in vars(node).values():
                if isinstance(attr, list):
                    nodes.extend(v for v in attr if hasattr(v, '__dict__'))
                elif hasattr(attr, '__dict__') and attr is not node:
                    nodes.append(attr)
        return False

    # ── dependency graph ──────────────────────────────────────────────

    def _build_dependencies(
        self,
        bindings: list[Binding | AreBinding],
    ) -> dict[str, set[str]]:
        """Build dependency graph for topological sort."""
        names = {b.name for b in bindings}
        deps: dict[str, set[str]] = {}
        for b in bindings:
            refs: set[str] = set()
            if isinstance(b, AreBinding):
                for elem in b.elements:
                    self._collect_bare_refs(elem, refs)
            else:
                self._collect_bare_refs(b.value, refs)
            deps[b.name] = (refs & names) - {b.name}
        return deps

    def _collect_bare_refs(self, node: Node, refs: set[str]) -> None:
        """Collect bare Identifier references, including inside function bodies."""
        if isinstance(node, Identifier):
            refs.add(node.name)
            return
        if isinstance(node, FunctionExpr):
            # Collect references from default parameter values
            for param in node.params:
                if param.default is not None:
                    self._collect_bare_refs(param.default, refs)
            # Collect references from function body for mutual recursion detection
            for binding in node.body_bindings:
                self._collect_bare_refs(binding.value, refs)
            self._collect_bare_refs(node.body_expr, refs)
            return
        for attr in vars(node).values():
            if isinstance(attr, list):
                for item in attr:
                    if isinstance(item, Node):
                        self._collect_bare_refs(item, refs)
            elif isinstance(attr, Node):
                self._collect_bare_refs(attr, refs)

    @staticmethod
    def _find_ref_location(node: Node, names: set[str]) -> tuple[int, int] | None:
        """Find the source location of the first reference to any name in *names*."""
        if isinstance(node, Identifier) and node.name in names:
            return (node.line, node.col)
        if isinstance(node, FunctionExpr):
            for param in node.params:
                if param.default is not None:
                    loc = DependencyMixin._find_ref_location(param.default, names)
                    if loc:
                        return loc
            for binding in node.body_bindings:
                loc = DependencyMixin._find_ref_location(binding.value, names)
                if loc:
                    return loc
            return DependencyMixin._find_ref_location(node.body_expr, names)
        for attr in vars(node).values():
            if isinstance(attr, list):
                for item in attr:
                    if isinstance(item, Node):
                        loc = DependencyMixin._find_ref_location(item, names)
                        if loc:
                            return loc
            elif isinstance(attr, Node):
                loc = DependencyMixin._find_ref_location(attr, names)
                if loc:
                    return loc
        return None

    # ── topological sort ──────────────────────────────────────────────

    def _topological_sort(
        self,
        bindings: list[Binding | AreBinding],
        deps: dict[str, set[str]],
    ) -> tuple[list[Binding | AreBinding], list[list[str]]]:
        """Kahn's algorithm. Returns (order, cycle_groups).

        ``order`` contains non-cycle bindings in evaluation order.
        ``cycle_groups`` is a list of connected components among cycle
        participants (empty when there are no cycles).
        """
        by_name: dict[str, Binding | AreBinding] = {b.name: b for b in bindings}
        in_degree: dict[str, int] = {b.name: len(deps.get(b.name, set())) for b in bindings}

        reverse: dict[str, list[str]] = {b.name: [] for b in bindings}
        for name, dep_set in deps.items():
            for d in dep_set:
                if d in reverse:
                    reverse[d].append(name)

        queue = [name for name, deg in in_degree.items() if deg == 0]
        order: list[str] = []

        while queue:
            name = queue.pop(0)
            order.append(name)
            for dependent in reverse.get(name, []):
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)

        cycle_groups: list[list[str]] = []
        if len(order) != len(bindings):
            remaining = [b.name for b in bindings if b.name not in set(order)]
            cycle_groups = self._find_cycle_groups(remaining, deps)

        return [by_name[name] for name in order], cycle_groups

    @staticmethod
    def _find_cycle_groups(
        remaining: list[str], deps: dict[str, set[str]]
    ) -> list[list[str]]:
        """Find connected components among remaining (cyclic) nodes."""
        remaining_set = set(remaining)
        adj: dict[str, set[str]] = {n: set() for n in remaining}
        for n in remaining:
            for dep in deps.get(n, set()):
                if dep in remaining_set:
                    adj[n].add(dep)
                    adj[dep].add(n)

        visited: set[str] = set()
        components: list[list[str]] = []
        for name in remaining:
            if name in visited:
                continue
            component: list[str] = []
            stack = [name]
            while stack:
                node = stack.pop()
                if node in visited:
                    continue
                visited.add(node)
                component.append(node)
                for neighbor in adj[node]:
                    if neighbor not in visited:
                        stack.append(neighbor)
            components.append(component)
        return components
