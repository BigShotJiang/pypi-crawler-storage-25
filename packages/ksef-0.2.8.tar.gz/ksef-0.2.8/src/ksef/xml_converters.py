"""XML converters used to convert library models into KSEF-compliant XML files."""
from datetime import datetime, timezone
from typing import Optional, cast
from xml.etree import ElementTree

from ksef.models.invoice import (
    EuVatIdentification,
    ForeignIdentification,
    Invoice,
    NipIdentification,
    NoIdentification,
)

# FA(3) schema namespace
FA3_NAMESPACE = "http://crd.gov.pl/wzor/2025/06/25/13775/"


def _build_header(
    root: ElementTree.Element,
    invoicing_software_name: str,
    creation_datetime: Optional[datetime] = None,
) -> None:
    header = ElementTree.SubElement(root, "Naglowek")
    form_code = ElementTree.SubElement(
        header,
        "KodFormularza",
        attrib={"kodSystemowy": "FA (3)", "wersjaSchemy": "1-0E"},
    )
    form_variant = ElementTree.SubElement(header, "WariantFormularza")
    creation_date = ElementTree.SubElement(header, "DataWytworzeniaFa")
    system_info = ElementTree.SubElement(header, "SystemInfo")

    form_code.text = "FA"
    form_variant.text = "3"
    # Use provided datetime or current time
    dt = creation_datetime or datetime.now(tz=timezone.utc)
    creation_date.text = dt.strftime("%Y-%m-%dT%H:%M:%S")
    system_info.text = invoicing_software_name


def _build_issuer(root: ElementTree.Element, invoice: Invoice) -> None:
    issuer = ElementTree.SubElement(root, "Podmiot1")

    issuer_id_data = ElementTree.SubElement(issuer, "DaneIdentyfikacyjne")
    issuer_nip = ElementTree.SubElement(issuer_id_data, "NIP")
    issuer_nip.text = invoice.issuer.identification_data.nip
    issuer_full_name = ElementTree.SubElement(issuer_id_data, "Nazwa")
    issuer_full_name.text = invoice.issuer.identification_data.full_name

    issuer_address = ElementTree.SubElement(issuer, "Adres")
    issuer_country_code = ElementTree.SubElement(issuer_address, "KodKraju")
    issuer_country_code.text = invoice.issuer.address.country_code

    # AdresL1: street + house number (+ apartment number)
    addr = invoice.issuer.address
    address_l1 = f"{addr.street} {addr.house_number}"
    if addr.apartment_number is not None:
        address_l1 += f"/{addr.apartment_number}"
    issuer_address_l1 = ElementTree.SubElement(issuer_address, "AdresL1")
    issuer_address_l1.text = address_l1

    # AdresL2: postal code + city
    issuer_address_l2 = ElementTree.SubElement(issuer_address, "AdresL2")
    issuer_address_l2.text = f"{addr.postal_code} {addr.city}"


def _build_receiver(root: ElementTree.Element, invoice: Invoice) -> None:
    receiver = ElementTree.SubElement(root, "Podmiot2")
    receiver_id_data = ElementTree.SubElement(receiver, "DaneIdentyfikacyjne")

    id_data = invoice.recipient.identification_data
    if isinstance(id_data, NipIdentification):
        nip_el = ElementTree.SubElement(receiver_id_data, "NIP")
        nip_el.text = id_data.nip
    elif isinstance(id_data, EuVatIdentification):
        kod_ue = ElementTree.SubElement(receiver_id_data, "KodUE")
        kod_ue.text = id_data.eu_country_code
        nr_vat = ElementTree.SubElement(receiver_id_data, "NrVatUE")
        nr_vat.text = id_data.eu_vat_number
    elif isinstance(id_data, ForeignIdentification):
        if id_data.country_code is not None:
            kod_kraju = ElementTree.SubElement(receiver_id_data, "KodKraju")
            kod_kraju.text = id_data.country_code
        nr_id = ElementTree.SubElement(receiver_id_data, "NrID")
        nr_id.text = id_data.tax_id
    elif isinstance(id_data, NoIdentification):
        brak_id = ElementTree.SubElement(receiver_id_data, "BrakID")
        brak_id.text = "1"

    if invoice.recipient.name is not None:
        nazwa = ElementTree.SubElement(receiver_id_data, "Nazwa")
        nazwa.text = invoice.recipient.name

    if invoice.recipient.address is not None:
        addr = invoice.recipient.address
        receiver_address = ElementTree.SubElement(receiver, "Adres")
        receiver_country_code = ElementTree.SubElement(receiver_address, "KodKraju")
        receiver_country_code.text = addr.country_code

        address_l1 = f"{addr.street} {addr.house_number}"
        if addr.apartment_number is not None:
            address_l1 += f"/{addr.apartment_number}"
        receiver_address_l1 = ElementTree.SubElement(receiver_address, "AdresL1")
        receiver_address_l1.text = address_l1

        receiver_address_l2 = ElementTree.SubElement(receiver_address, "AdresL2")
        receiver_address_l2.text = f"{addr.postal_code} {addr.city}"

    receiver_jst = ElementTree.SubElement(receiver, "JST")
    receiver_jst.text = str(invoice.recipient.jst)
    receiver_gv = ElementTree.SubElement(receiver, "GV")
    receiver_gv.text = str(invoice.recipient.gv)


def _build_additional_recipients(root: ElementTree.Element, invoice: Invoice) -> None:
    """Build Podmiot3 elements for additional recipients."""
    for recipient in invoice.additional_recipients:
        podmiot3 = ElementTree.SubElement(root, "Podmiot3")

        # DaneIdentyfikacyjne
        id_data = ElementTree.SubElement(podmiot3, "DaneIdentyfikacyjne")
        rd = recipient.identification_data

        if isinstance(rd, NipIdentification):
            ElementTree.SubElement(id_data, "NIP").text = rd.nip
        elif isinstance(rd, EuVatIdentification):
            ElementTree.SubElement(id_data, "KodUE").text = rd.eu_country_code
            ElementTree.SubElement(id_data, "NrVatUE").text = rd.eu_vat_number
        elif isinstance(rd, ForeignIdentification):
            if rd.country_code is not None:
                ElementTree.SubElement(id_data, "KodKraju").text = rd.country_code
            ElementTree.SubElement(id_data, "NrID").text = rd.tax_id
        elif isinstance(rd, NoIdentification):
            ElementTree.SubElement(id_data, "BrakID").text = "1"

        if recipient.name is not None:
            ElementTree.SubElement(id_data, "Nazwa").text = recipient.name

        # Adres
        if recipient.address is not None:
            addr = recipient.address
            addr_el = ElementTree.SubElement(podmiot3, "Adres")
            ElementTree.SubElement(addr_el, "KodKraju").text = addr.country_code
            address_l1 = f"{addr.street} {addr.house_number}"
            if addr.apartment_number is not None:
                address_l1 += f"/{addr.apartment_number}"
            ElementTree.SubElement(addr_el, "AdresL1").text = address_l1
            ElementTree.SubElement(addr_el, "AdresL2").text = f"{addr.postal_code} {addr.city}"

        # Rola
        ElementTree.SubElement(podmiot3, "Rola").text = str(recipient.role)


def _build_invoice_data_annotations(invoice_data: ElementTree.Element, invoice: Invoice) -> None:
    annotations = ElementTree.SubElement(invoice_data, "Adnotacje")
    data = invoice.invoice_data.invoice_annotations

    # P_16 - metoda kasowa
    p16 = ElementTree.SubElement(annotations, "P_16")
    p16.text = data.tax_settlement_on_payment.value

    # P_17 - samofakturowanie
    p17 = ElementTree.SubElement(annotations, "P_17")
    p17.text = data.self_invoice.value

    # P_18 - odwrotne obciążenie
    p18 = ElementTree.SubElement(annotations, "P_18")
    p18.text = data.reverse_charge.value

    # P_18A - mechanizm podzielonej płatności
    p18a = ElementTree.SubElement(annotations, "P_18A")
    p18a.text = data.split_payment.value

    # Zwolnienie - wrapper for P_19/P_19N
    zwolnienie = ElementTree.SubElement(annotations, "Zwolnienie")
    if data.free_from_vat.value == "1":
        p19 = ElementTree.SubElement(zwolnienie, "P_19")
        p19.text = "1"
    else:
        p19n = ElementTree.SubElement(zwolnienie, "P_19N")
        p19n.text = "1"

    # NoweSrodkiTransportu - wrapper for P_22/P_22N
    nst = ElementTree.SubElement(annotations, "NoweSrodkiTransportu")
    if data.intra_community_supply_of_new_transport_methods.value == "1":
        p22 = ElementTree.SubElement(nst, "P_22")
        p22.text = "1"
        p42_5 = ElementTree.SubElement(nst, "P_42_5")
        p42_5.text = "2"
    else:
        p22n = ElementTree.SubElement(nst, "P_22N")
        p22n.text = "1"

    # P_23 - procedura uproszczona
    p23 = ElementTree.SubElement(annotations, "P_23")
    p23.text = data.simplified_procedure_by_second_tax_payer.value

    # PMarzy - wrapper for P_PMarzy/P_PMarzyN
    pmarzy = ElementTree.SubElement(annotations, "PMarzy")
    if data.margin_procedure.value == "1":
        p_pm = ElementTree.SubElement(pmarzy, "P_PMarzy")
        p_pm.text = "1"
    else:
        p_pmn = ElementTree.SubElement(pmarzy, "P_PMarzyN")
        p_pmn.text = "1"


def _build_tax_summary(parent: ElementTree.Element, invoice: Invoice) -> None:
    """Emit P_13_*/P_14_* tax summary fields. Must be called before P_15."""
    ts = invoice.invoice_data.tax_summary
    if ts is None:
        return

    paired_fields = [
        (ts.net_standard, "P_13_1", ts.vat_standard, "P_14_1", ts.vat_standard_pln, "P_14_1W"),
        (ts.net_reduced_1, "P_13_2", ts.vat_reduced_1, "P_14_2", ts.vat_reduced_1_pln, "P_14_2W"),
        (ts.net_reduced_2, "P_13_3", ts.vat_reduced_2, "P_14_3", ts.vat_reduced_2_pln, "P_14_3W"),
        (ts.net_flat_rate, "P_13_4", ts.vat_flat_rate, "P_14_4", None, None),
        (ts.net_oss, "P_13_5", ts.vat_oss, "P_14_5", None, None),
    ]
    for net_val, net_tag, vat_val, vat_tag, vat_pln_val, vat_pln_tag in paired_fields:
        if net_val is not None:
            ElementTree.SubElement(parent, net_tag).text = str(net_val)
        if vat_val is not None:
            ElementTree.SubElement(parent, vat_tag).text = str(vat_val)
        if vat_pln_val is not None and vat_pln_tag is not None:
            ElementTree.SubElement(parent, vat_pln_tag).text = str(vat_pln_val)

    net_only_fields = [
        (ts.net_zero_domestic, "P_13_6_1"),
        (ts.net_zero_wdt, "P_13_6_2"),
        (ts.net_zero_export, "P_13_6_3"),
        (ts.net_exempt, "P_13_7"),
        (ts.net_not_subject, "P_13_8"),
        (ts.net_not_subject_art100, "P_13_9"),
        (ts.net_reverse_charge, "P_13_10"),
    ]
    for val, tag in net_only_fields:
        if val is not None:
            ElementTree.SubElement(parent, tag).text = str(val)


def _build_additional_descriptions(parent: ElementTree.Element, invoice: Invoice) -> None:
    """Emit DodatkowyOpis elements for additional key-value notes."""
    for desc in invoice.invoice_data.additional_descriptions:
        dodatkowy_opis = ElementTree.SubElement(parent, "DodatkowyOpis")
        if desc.row_number is not None:
            ElementTree.SubElement(dodatkowy_opis, "NrWiersza").text = str(desc.row_number)
        ElementTree.SubElement(dodatkowy_opis, "Klucz").text = desc.key
        ElementTree.SubElement(dodatkowy_opis, "Wartosc").text = desc.value


def _build_invoice_rows(parent: ElementTree.Element, invoice: Invoice) -> None:
    """Emit FaWiersz elements for each invoice row."""
    for index, row in enumerate(invoice.invoice_data.invoice_rows.rows, start=1):
        fa_wiersz = ElementTree.SubElement(parent, "FaWiersz")

        ElementTree.SubElement(fa_wiersz, "NrWierszaFa").text = str(index)

        if row.delivery_date is not None:
            ElementTree.SubElement(fa_wiersz, "P_6A").text = row.delivery_date.strftime("%Y-%m-%d")

        ElementTree.SubElement(fa_wiersz, "P_7").text = row.name

        if row.unit_of_measure is not None:
            ElementTree.SubElement(fa_wiersz, "P_8A").text = row.unit_of_measure
        if row.quantity is not None:
            ElementTree.SubElement(fa_wiersz, "P_8B").text = str(row.quantity)
        if row.unit_net_price is not None:
            ElementTree.SubElement(fa_wiersz, "P_9A").text = str(row.unit_net_price)
        if row.net_value is not None:
            ElementTree.SubElement(fa_wiersz, "P_11").text = str(row.net_value)

        if row.tax_oss is not None:
            ElementTree.SubElement(fa_wiersz, "P_12_XII").text = str(row.tax_oss)
        elif row.tax is not None:
            ElementTree.SubElement(fa_wiersz, "P_12").text = str(row.tax)

        if row.exchange_rate is not None:
            ElementTree.SubElement(fa_wiersz, "KursWaluty").text = str(row.exchange_rate)


def _build_invoice_data(root: ElementTree.Element, invoice: Invoice) -> None:
    invoice_data = ElementTree.SubElement(root, "Fa")

    ElementTree.SubElement(invoice_data, "KodWaluty").text = invoice.invoice_data.currency_code
    ElementTree.SubElement(invoice_data, "P_1").text = invoice.invoice_data.issue_date.strftime(
        "%Y-%m-%d"
    )
    ElementTree.SubElement(invoice_data, "P_2").text = invoice.invoice_data.issue_number
    ElementTree.SubElement(invoice_data, "P_6").text = invoice.invoice_data.sell_date.strftime(
        "%Y-%m-%d"
    )

    _build_tax_summary(invoice_data, invoice)

    ElementTree.SubElement(invoice_data, "P_15").text = str(invoice.invoice_data.total_amount)

    _build_invoice_data_annotations(invoice_data, invoice)

    ElementTree.SubElement(
        invoice_data, "RodzajFaktury"
    ).text = invoice.invoice_data.invoice_type.value

    _build_additional_descriptions(invoice_data, invoice)
    _build_invoice_rows(invoice_data, invoice)


def convert_invoice_to_xml(invoice: Invoice, invoicing_software_name: str = "python-ksef") -> bytes:
    """Convert an invoice model instance to XML document representing this invoice.

    Uses FA(3) schema format (http://crd.gov.pl/wzor/2025/06/25/13775/).
    """
    root = ElementTree.Element(
        "Faktura",
        attrib={
            "xmlns:etd": "http://crd.gov.pl/xml/schematy/dziedzinowe/mf/2022/01/05/eD/DefinicjeTypy/",
            "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
            "xmlns:xsd": "http://www.w3.org/2001/XMLSchema",
            "xmlns": FA3_NAMESPACE,
        },
    )

    _build_header(root, invoicing_software_name, invoice.creation_datetime)
    _build_issuer(root, invoice)
    _build_receiver(root, invoice)
    _build_additional_recipients(root, invoice)
    _build_invoice_data(root, invoice)

    return cast(bytes, ElementTree.tostring(root, encoding="utf-8", xml_declaration=True))
