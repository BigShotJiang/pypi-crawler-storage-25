"""Models and entities."""
