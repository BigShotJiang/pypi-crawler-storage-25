"""Tests for authorization implementations."""
