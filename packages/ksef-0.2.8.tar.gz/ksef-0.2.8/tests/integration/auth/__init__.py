"""Integration tests for authentication."""
