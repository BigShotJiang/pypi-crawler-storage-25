"""MCP server that exposes ITSM tools for ServiceNow."""

import asyncio
import json
import logging
import os
from base64 import b64encode

import httpx
from dotenv import load_dotenv
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

load_dotenv(os.getenv("DOTENV_PATH", ".env"))

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
logger = logging.getLogger("servicenow-mcp")

INSTANCE_URL = os.getenv("SERVICENOW_INSTANCE_URL", "").rstrip("/")
USERNAME = os.getenv("SERVICENOW_USERNAME", "")
PASSWORD = os.getenv("SERVICENOW_PASSWORD", "")


def _auth_header() -> dict[str, str]:
    """Build Basic Auth and JSON headers for ServiceNow API requests."""
    token = b64encode(f"{USERNAME}:{PASSWORD}".encode()).decode()
    return {
        "Authorization": f"Basic {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def _check_credentials() -> list[TextContent] | None:
    """Return an error TextContent list if credentials are missing, else None."""
    if not INSTANCE_URL or not USERNAME:
        return [
            TextContent(
                type="text",
                text=(
                    "ERROR: ServiceNow credentials are not configured. "
                    "Set SERVICENOW_INSTANCE_URL, SERVICENOW_USERNAME, and "
                    "SERVICENOW_PASSWORD in your .env file."
                ),
            )
        ]
    return None


async def _get_sys_id(table: str, number: str) -> str | None:
    """Query ServiceNow for a record by number and return its sys_id.

    Args:
        table: The ServiceNow table name (e.g. 'incident', 'change_request').
        number: The record number (e.g. INC0010054, CHG0000001).

    Returns:
        The sys_id string if found, or None if not found or on error.
    """
    url = (
        f"{INSTANCE_URL}/api/now/table/{table}"
        f"?sysparm_query=number={number}&sysparm_limit=1"
    )
    logger.info("GET (sys_id lookup) %s", url)
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(url, headers=_auth_header())
    if resp.status_code == 200:
        results = resp.json().get("result", [])
        if results:
            return results[0].get("sys_id")
    return None


def _val(record: dict, field: str) -> str:
    """Extract display_value or value from a field, handling dicts and plain strings."""
    v = record.get(field, "")
    if isinstance(v, dict):
        return v.get("display_value", v.get("value", ""))
    return str(v) if v else ""


# -- Incident Tool definitions -----------------------------------------------

CREATE_INCIDENT_TOOL = Tool(
    name="create_incident",
    description=(
        "Create a new incident in ServiceNow. "
        "Extracts a short summary, detailed description, impact, urgency, "
        "category, and optional assignment group from the user's request."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "short_description": {
                "type": "string",
                "description": "One-line summary of the incident (max 160 chars)",
            },
            "description": {
                "type": "string",
                "description": "Detailed description including symptoms, affected systems, and any error messages",
            },
            "impact": {
                "type": "string",
                "enum": ["1", "2", "3"],
                "description": "1 = High (widespread), 2 = Medium (limited), 3 = Low (single user)",
            },
            "urgency": {
                "type": "string",
                "enum": ["1", "2", "3"],
                "description": "1 = High (business-critical), 2 = Medium (degraded), 3 = Low (workaround exists)",
            },
            "category": {
                "type": "string",
                "enum": [
                    "Software",
                    "Hardware",
                    "Network",
                    "Database",
                    "Security",
                    "Service",
                ],
                "description": "Incident category",
            },
            "assignment_group": {
                "type": "string",
                "description": "Name of the ServiceNow assignment group (e.g. 'Service Desk', 'Network Support'). Leave empty if unknown.",
            },
        },
        "required": ["short_description", "description", "impact", "urgency", "category"],
    },
)

GET_INCIDENT_TOOL = Tool(
    name="get_incident",
    description=(
        "Look up a single ServiceNow incident by its number (e.g. INC0010054) "
        "and return key fields such as state, priority, description, and resolution info."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "number": {
                "type": "string",
                "description": "The incident number to look up (e.g. INC0010054)",
            },
        },
        "required": ["number"],
    },
)

SEARCH_INCIDENTS_TOOL = Tool(
    name="search_incidents",
    description=(
        "Search ServiceNow incidents using an encoded query string. "
        "Useful for finding incidents by state, impact, category, assignment group, etc. "
        "Example query: 'state=1^impact=1^category=Software'."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": (
                    "ServiceNow encoded query string. "
                    "Examples: 'state=1^impact=1', 'category=Software^active=true', "
                    "'assigned_to=john.doe^state=2'"
                ),
            },
            "limit": {
                "type": "string",
                "description": "Maximum number of results to return (default 10)",
            },
        },
        "required": ["query"],
    },
)

UPDATE_INCIDENT_TOOL = Tool(
    name="update_incident",
    description=(
        "Update one or more fields on an existing ServiceNow incident. "
        "Common fields: short_description, description, impact, urgency, "
        "category, assignment_group, state."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "number": {
                "type": "string",
                "description": "The incident number to update (e.g. INC0010054)",
            },
            "fields": {
                "type": "object",
                "description": (
                    "Dictionary of field names to new values. "
                    "Example: {\"impact\": \"1\", \"urgency\": \"1\", \"assignment_group\": \"Network Support\"}"
                ),
            },
        },
        "required": ["number", "fields"],
    },
)

ADD_COMMENT_TOOL = Tool(
    name="add_comment",
    description=(
        "Add a comment (visible to customer) or a work note (internal only) "
        "to an existing ServiceNow incident."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "number": {
                "type": "string",
                "description": "The incident number (e.g. INC0010054)",
            },
            "text": {
                "type": "string",
                "description": "The comment or work note text to add",
            },
            "type": {
                "type": "string",
                "enum": ["comment", "work_note"],
                "description": "'comment' for customer-visible, 'work_note' for internal only",
            },
        },
        "required": ["number", "text", "type"],
    },
)

RESOLVE_INCIDENT_TOOL = Tool(
    name="resolve_incident",
    description=(
        "Resolve an existing ServiceNow incident by setting its state to Resolved, "
        "along with a close code and resolution notes."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "number": {
                "type": "string",
                "description": "The incident number to resolve (e.g. INC0010054)",
            },
            "close_code": {
                "type": "string",
                "enum": [
                    "Solution provided",
                    "Workaround provided",
                    "Resolved by change",
                    "Resolved by problem",
                    "Resolved by request",
                    "Resolved by caller",
                    "Duplicate",
                    "Known error",
                    "User error",
                    "No resolution provided",
                ],
                "description": "The resolution code describing how the incident was resolved",
            },
            "close_notes": {
                "type": "string",
                "description": "Resolution notes describing what was done to resolve the incident",
            },
        },
        "required": ["number", "close_code", "close_notes"],
    },
)

# -- Knowledge Base Tool definitions ------------------------------------------

SEARCH_KB_TOOL = Tool(
    name="search_knowledge_base",
    description=(
        "Search ServiceNow Knowledge Base articles by keyword. "
        "Use this BEFORE creating an incident to check if a known solution exists. "
        "Returns matching articles with their number, title, and body text."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Search keywords (e.g. 'VPN connection failed', 'password reset')",
            },
            "limit": {
                "type": "string",
                "description": "Maximum number of articles to return (default 5)",
            },
        },
        "required": ["query"],
    },
)

GET_KB_ARTICLE_TOOL = Tool(
    name="get_kb_article",
    description=(
        "Retrieve a single Knowledge Base article by its number (e.g. KB0000001). "
        "Returns the full article text, category, and workflow state."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "number": {
                "type": "string",
                "description": "The KB article number (e.g. KB0000001)",
            },
        },
        "required": ["number"],
    },
)

# -- Change Request Tool definitions ------------------------------------------

CREATE_CHANGE_REQUEST_TOOL = Tool(
    name="create_change_request",
    description=(
        "Create a new Change Request in ServiceNow. "
        "Use when a planned change to infrastructure, software, or configuration is needed. "
        "Standard changes follow a pre-approved process; Normal changes require CAB approval."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "short_description": {
                "type": "string",
                "description": "One-line summary of the change (max 160 chars)",
            },
            "description": {
                "type": "string",
                "description": "Detailed description of the change, including what will be modified and why",
            },
            "type": {
                "type": "string",
                "enum": ["Standard", "Normal", "Emergency"],
                "description": "Standard = pre-approved, Normal = needs CAB approval, Emergency = urgent bypass",
            },
            "risk": {
                "type": "string",
                "enum": ["High", "Moderate", "Low"],
                "description": "Risk level of the change",
            },
            "impact": {
                "type": "string",
                "enum": ["1", "2", "3"],
                "description": "1 = High (widespread), 2 = Medium (limited), 3 = Low (minimal)",
            },
            "assignment_group": {
                "type": "string",
                "description": "Name of the group responsible for implementing the change",
            },
        },
        "required": ["short_description", "description", "type", "risk", "impact"],
    },
)

GET_CHANGE_REQUEST_TOOL = Tool(
    name="get_change_request",
    description=(
        "Look up a single Change Request by its number (e.g. CHG0000001) "
        "and return key fields such as state, type, risk, approval status, and schedule."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "number": {
                "type": "string",
                "description": "The change request number (e.g. CHG0000001)",
            },
        },
        "required": ["number"],
    },
)

SEARCH_CHANGE_REQUESTS_TOOL = Tool(
    name="search_change_requests",
    description=(
        "Search Change Requests using a ServiceNow encoded query string. "
        "Useful for finding changes by state, type, risk, assignment group, etc. "
        "Example query: 'type=Normal^risk=High^state=-5' (state -5 = New)."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": (
                    "ServiceNow encoded query string for change_request table. "
                    "Examples: 'type=Normal^risk=High', 'state=-5^assignment_group=Network Support'"
                ),
            },
            "limit": {
                "type": "string",
                "description": "Maximum number of results to return (default 10)",
            },
        },
        "required": ["query"],
    },
)

UPDATE_CHANGE_REQUEST_TOOL = Tool(
    name="update_change_request",
    description=(
        "Update fields on an existing Change Request. "
        "Common fields: short_description, description, risk, impact, "
        "assignment_group, state, start_date, end_date."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "number": {
                "type": "string",
                "description": "The change request number (e.g. CHG0000001)",
            },
            "fields": {
                "type": "object",
                "description": (
                    "Dictionary of field names to new values. "
                    "Example: {\"risk\": \"High\", \"state\": \"-1\"}"
                ),
            },
        },
        "required": ["number", "fields"],
    },
)

# -- MCP Server -------------------------------------------------------------

server = Server("servicenow-itsm")


@server.list_tools()
async def handle_list_tools() -> list[Tool]:
    """Return all tools registered with this MCP server."""
    return [
        CREATE_INCIDENT_TOOL,
        GET_INCIDENT_TOOL,
        SEARCH_INCIDENTS_TOOL,
        UPDATE_INCIDENT_TOOL,
        ADD_COMMENT_TOOL,
        RESOLVE_INCIDENT_TOOL,
        SEARCH_KB_TOOL,
        GET_KB_ARTICLE_TOOL,
        CREATE_CHANGE_REQUEST_TOOL,
        GET_CHANGE_REQUEST_TOOL,
        SEARCH_CHANGE_REQUESTS_TOOL,
        UPDATE_CHANGE_REQUEST_TOOL,
    ]


@server.call_tool()
async def handle_call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Route an incoming tool call to the appropriate handler."""
    handlers = {
        "create_incident": _create_incident,
        "get_incident": _get_incident,
        "search_incidents": _search_incidents,
        "update_incident": _update_incident,
        "add_comment": _add_comment,
        "resolve_incident": _resolve_incident,
        "search_knowledge_base": _search_knowledge_base,
        "get_kb_article": _get_kb_article,
        "create_change_request": _create_change_request,
        "get_change_request": _get_change_request,
        "search_change_requests": _search_change_requests,
        "update_change_request": _update_change_request,
    }
    handler = handlers.get(name)
    if not handler:
        raise ValueError(f"Unknown tool: {name}")
    return await handler(arguments)


# -- Incident handlers -------------------------------------------------------

async def _create_incident(args: dict) -> list[TextContent]:
    cred_error = _check_credentials()
    if cred_error:
        return cred_error

    payload = {
        "short_description": args["short_description"],
        "description": args["description"],
        "impact": args["impact"],
        "urgency": args["urgency"],
        "category": args["category"],
    }
    if args.get("assignment_group"):
        payload["assignment_group"] = args["assignment_group"]

    url = f"{INSTANCE_URL}/api/now/table/incident"
    logger.info("POST %s", url)
    logger.info("Payload: %s", json.dumps(payload, indent=2))

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(url, headers=_auth_header(), json=payload)

    if resp.status_code in (200, 201):
        result = resp.json().get("result", {})
        number = result.get("number", "N/A")
        sys_id = result.get("sys_id", "N/A")
        priority = result.get("priority", "N/A")
        state = result.get("state", "N/A")

        text = (
            f"Incident created successfully!\n"
            f"  Number:            {number}\n"
            f"  Sys ID:            {sys_id}\n"
            f"  Short Description: {payload['short_description']}\n"
            f"  Category:          {payload['category']}\n"
            f"  Impact:            {payload['impact']}\n"
            f"  Urgency:           {payload['urgency']}\n"
            f"  Priority:          {priority}\n"
            f"  State:             {state}\n"
        )
        if payload.get("assignment_group"):
            text += f"  Assignment Group:  {payload['assignment_group']}\n"

        logger.info("Created incident %s", number)
        return [TextContent(type="text", text=text)]
    else:
        error_text = (
            f"ServiceNow API error (HTTP {resp.status_code}):\n{resp.text}"
        )
        logger.error(error_text)
        return [TextContent(type="text", text=error_text)]


async def _get_incident(args: dict) -> list[TextContent]:
    cred_error = _check_credentials()
    if cred_error:
        return cred_error

    number = args["number"]
    url = (
        f"{INSTANCE_URL}/api/now/table/incident"
        f"?sysparm_query=number={number}&sysparm_limit=1"
    )
    logger.info("GET %s", url)

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(url, headers=_auth_header())

    if resp.status_code != 200:
        error_text = (
            f"ServiceNow API error (HTTP {resp.status_code}):\n{resp.text}"
        )
        logger.error(error_text)
        return [TextContent(type="text", text=error_text)]

    results = resp.json().get("result", [])
    if not results:
        return [TextContent(type="text", text=f"No incident found with number {number}")]

    inc = results[0]
    text = (
        f"Incident {number}\n"
        f"  Short Description: {_val(inc, 'short_description')}\n"
        f"  Description:       {_val(inc, 'description')}\n"
        f"  State:             {_val(inc, 'state')}\n"
        f"  Impact:            {_val(inc, 'impact')}\n"
        f"  Urgency:           {_val(inc, 'urgency')}\n"
        f"  Priority:          {_val(inc, 'priority')}\n"
        f"  Category:          {_val(inc, 'category')}\n"
        f"  Assignment Group:  {_val(inc, 'assignment_group')}\n"
        f"  Assigned To:       {_val(inc, 'assigned_to')}\n"
        f"  Created On:        {_val(inc, 'sys_created_on')}\n"
        f"  Updated On:        {_val(inc, 'sys_updated_on')}\n"
        f"  Resolved By:       {_val(inc, 'resolved_by')}\n"
        f"  Resolution Notes:  {_val(inc, 'resolution_notes')}\n"
        f"  Close Code:        {_val(inc, 'close_code')}\n"
    )

    logger.info("Retrieved incident %s", number)
    return [TextContent(type="text", text=text)]


async def _search_incidents(args: dict) -> list[TextContent]:
    cred_error = _check_credentials()
    if cred_error:
        return cred_error

    query = args["query"]
    limit = args.get("limit", "10")
    url = (
        f"{INSTANCE_URL}/api/now/table/incident"
        f"?sysparm_query={query}&sysparm_limit={limit}"
    )
    logger.info("GET %s", url)

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(url, headers=_auth_header())

    if resp.status_code != 200:
        error_text = (
            f"ServiceNow API error (HTTP {resp.status_code}):\n{resp.text}"
        )
        logger.error(error_text)
        return [TextContent(type="text", text=error_text)]

    results = resp.json().get("result", [])
    if not results:
        return [TextContent(type="text", text=f"No incidents found for query: {query}")]

    lines = [f"Found {len(results)} incident(s):\n"]
    for inc in results:
        lines.append(
            f"  [{_val(inc, 'number')}] {_val(inc, 'short_description')}\n"
            f"    State: {_val(inc, 'state')} | Priority: {_val(inc, 'priority')} | "
            f"Category: {_val(inc, 'category')} | Assigned To: {_val(inc, 'assigned_to')}\n"
        )

    text = "\n".join(lines)
    logger.info("Search returned %d incident(s)", len(results))
    return [TextContent(type="text", text=text)]


async def _update_incident(args: dict) -> list[TextContent]:
    cred_error = _check_credentials()
    if cred_error:
        return cred_error

    number = args["number"]
    fields = args["fields"]

    sys_id = await _get_sys_id("incident", number)
    if not sys_id:
        return [TextContent(type="text", text=f"Incident {number} not found.")]

    url = f"{INSTANCE_URL}/api/now/table/incident/{sys_id}"
    logger.info("PATCH %s", url)
    logger.info("Fields: %s", json.dumps(fields, indent=2))

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.patch(url, headers=_auth_header(), json=fields)

    if resp.status_code == 200:
        result = resp.json().get("result", {})
        text = (
            f"Incident {number} updated successfully!\n"
            f"  Short Description: {_val(result, 'short_description')}\n"
            f"  State:             {_val(result, 'state')}\n"
            f"  Impact:            {_val(result, 'impact')}\n"
            f"  Urgency:           {_val(result, 'urgency')}\n"
            f"  Priority:          {_val(result, 'priority')}\n"
            f"  Category:          {_val(result, 'category')}\n"
            f"  Assignment Group:  {_val(result, 'assignment_group')}\n"
            f"  Assigned To:       {_val(result, 'assigned_to')}\n"
        )
        logger.info("Updated incident %s", number)
        return [TextContent(type="text", text=text)]
    else:
        error_text = (
            f"ServiceNow API error (HTTP {resp.status_code}):\n{resp.text}"
        )
        logger.error(error_text)
        return [TextContent(type="text", text=error_text)]


async def _add_comment(args: dict) -> list[TextContent]:
    cred_error = _check_credentials()
    if cred_error:
        return cred_error

    number = args["number"]
    comment_text = args["text"]
    comment_type = args["type"]

    sys_id = await _get_sys_id("incident", number)
    if not sys_id:
        return [TextContent(type="text", text=f"Incident {number} not found.")]

    field_name = "comments" if comment_type == "comment" else "work_notes"
    payload = {field_name: comment_text}

    url = f"{INSTANCE_URL}/api/now/table/incident/{sys_id}"
    logger.info("PATCH %s (add %s)", url, comment_type)

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.patch(url, headers=_auth_header(), json=payload)

    if resp.status_code == 200:
        type_label = "Comment" if comment_type == "comment" else "Work note"
        text = (
            f"{type_label} added to incident {number} successfully!\n"
            f"  Type: {type_label}\n"
            f"  Text: {comment_text}\n"
        )
        logger.info("Added %s to incident %s", comment_type, number)
        return [TextContent(type="text", text=text)]
    else:
        error_text = (
            f"ServiceNow API error (HTTP {resp.status_code}):\n{resp.text}"
        )
        logger.error(error_text)
        return [TextContent(type="text", text=error_text)]


async def _resolve_incident(args: dict) -> list[TextContent]:
    cred_error = _check_credentials()
    if cred_error:
        return cred_error

    number = args["number"]
    close_code = args["close_code"]
    close_notes = args["close_notes"]

    sys_id = await _get_sys_id("incident", number)
    if not sys_id:
        return [TextContent(type="text", text=f"Incident {number} not found.")]

    payload = {
        "state": "6",
        "close_code": close_code,
        "close_notes": close_notes,
    }

    url = f"{INSTANCE_URL}/api/now/table/incident/{sys_id}"
    logger.info("PATCH %s (resolve)", url)
    logger.info("Payload: %s", json.dumps(payload, indent=2))

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.patch(url, headers=_auth_header(), json=payload)

    if resp.status_code == 200:
        text = (
            f"Incident {number} resolved successfully!\n"
            f"  State:        Resolved (6)\n"
            f"  Close Code:   {close_code}\n"
            f"  Close Notes:  {close_notes}\n"
        )
        logger.info("Resolved incident %s", number)
        return [TextContent(type="text", text=text)]
    else:
        error_text = (
            f"ServiceNow API error (HTTP {resp.status_code}):\n{resp.text}"
        )
        logger.error(error_text)
        return [TextContent(type="text", text=error_text)]


# -- Knowledge Base handlers -------------------------------------------------

async def _search_knowledge_base(args: dict) -> list[TextContent]:
    cred_error = _check_credentials()
    if cred_error:
        return cred_error

    query = args["query"]
    limit = args.get("limit", "5")
    words = query.split()
    keyword_clauses = "^OR".join(
        f"short_descriptionLIKE{w}^ORtextLIKE{w}" for w in words
    )
    url = (
        f"{INSTANCE_URL}/api/now/table/kb_knowledge"
        f"?sysparm_query={keyword_clauses}"
        f"^workflow_stateINdraft,published&sysparm_limit={limit}"
        f"&sysparm_fields=number,short_description,text,kb_category,workflow_state"
    )
    logger.info("GET %s", url)

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(url, headers=_auth_header())

    if resp.status_code != 200:
        error_text = (
            f"ServiceNow API error (HTTP {resp.status_code}):\n{resp.text}"
        )
        logger.error(error_text)
        return [TextContent(type="text", text=error_text)]

    results = resp.json().get("result", [])
    if not results:
        return [TextContent(type="text", text=f"No Knowledge Base articles found for: {query}")]

    lines = [f"Found {len(results)} KB article(s):\n"]
    for article in results:
        body = _val(article, "text")
        preview = body[:200] + "..." if len(body) > 200 else body
        lines.append(
            f"  [{_val(article, 'number')}] {_val(article, 'short_description')}\n"
            f"    Category: {_val(article, 'kb_category')}\n"
            f"    Preview:  {preview}\n"
        )

    text = "\n".join(lines)
    logger.info("KB search returned %d article(s)", len(results))
    return [TextContent(type="text", text=text)]


async def _get_kb_article(args: dict) -> list[TextContent]:
    cred_error = _check_credentials()
    if cred_error:
        return cred_error

    number = args["number"]
    url = (
        f"{INSTANCE_URL}/api/now/table/kb_knowledge"
        f"?sysparm_query=number={number}&sysparm_limit=1"
    )
    logger.info("GET %s", url)

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(url, headers=_auth_header())

    if resp.status_code != 200:
        error_text = (
            f"ServiceNow API error (HTTP {resp.status_code}):\n{resp.text}"
        )
        logger.error(error_text)
        return [TextContent(type="text", text=error_text)]

    results = resp.json().get("result", [])
    if not results:
        return [TextContent(type="text", text=f"No KB article found with number {number}")]

    article = results[0]
    text = (
        f"KB Article {number}\n"
        f"  Title:    {_val(article, 'short_description')}\n"
        f"  Category: {_val(article, 'kb_category')}\n"
        f"  State:    {_val(article, 'workflow_state')}\n"
        f"  Body:\n{_val(article, 'text')}\n"
    )

    logger.info("Retrieved KB article %s", number)
    return [TextContent(type="text", text=text)]


# -- Change Request handlers -------------------------------------------------

async def _create_change_request(args: dict) -> list[TextContent]:
    cred_error = _check_credentials()
    if cred_error:
        return cred_error

    payload = {
        "short_description": args["short_description"],
        "description": args["description"],
        "type": args["type"],
        "risk": args["risk"],
        "impact": args["impact"],
    }
    if args.get("assignment_group"):
        payload["assignment_group"] = args["assignment_group"]

    url = f"{INSTANCE_URL}/api/now/table/change_request"
    logger.info("POST %s", url)
    logger.info("Payload: %s", json.dumps(payload, indent=2))

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(url, headers=_auth_header(), json=payload)

    if resp.status_code in (200, 201):
        result = resp.json().get("result", {})
        number = result.get("number", "N/A")
        state = _val(result, "state")

        text = (
            f"Change Request created successfully!\n"
            f"  Number:            {number}\n"
            f"  Short Description: {payload['short_description']}\n"
            f"  Type:              {payload['type']}\n"
            f"  Risk:              {payload['risk']}\n"
            f"  Impact:            {payload['impact']}\n"
            f"  State:             {state}\n"
        )
        if payload.get("assignment_group"):
            text += f"  Assignment Group:  {payload['assignment_group']}\n"

        logger.info("Created change request %s", number)
        return [TextContent(type="text", text=text)]
    else:
        error_text = (
            f"ServiceNow API error (HTTP {resp.status_code}):\n{resp.text}"
        )
        logger.error(error_text)
        return [TextContent(type="text", text=error_text)]


async def _get_change_request(args: dict) -> list[TextContent]:
    cred_error = _check_credentials()
    if cred_error:
        return cred_error

    number = args["number"]
    url = (
        f"{INSTANCE_URL}/api/now/table/change_request"
        f"?sysparm_query=number={number}&sysparm_limit=1"
    )
    logger.info("GET %s", url)

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(url, headers=_auth_header())

    if resp.status_code != 200:
        error_text = (
            f"ServiceNow API error (HTTP {resp.status_code}):\n{resp.text}"
        )
        logger.error(error_text)
        return [TextContent(type="text", text=error_text)]

    results = resp.json().get("result", [])
    if not results:
        return [TextContent(type="text", text=f"No change request found with number {number}")]

    chg = results[0]
    text = (
        f"Change Request {number}\n"
        f"  Short Description: {_val(chg, 'short_description')}\n"
        f"  Description:       {_val(chg, 'description')}\n"
        f"  Type:              {_val(chg, 'type')}\n"
        f"  State:             {_val(chg, 'state')}\n"
        f"  Risk:              {_val(chg, 'risk')}\n"
        f"  Impact:            {_val(chg, 'impact')}\n"
        f"  Priority:          {_val(chg, 'priority')}\n"
        f"  Assignment Group:  {_val(chg, 'assignment_group')}\n"
        f"  Assigned To:       {_val(chg, 'assigned_to')}\n"
        f"  Approval:          {_val(chg, 'approval')}\n"
        f"  Start Date:        {_val(chg, 'start_date')}\n"
        f"  End Date:          {_val(chg, 'end_date')}\n"
        f"  Created On:        {_val(chg, 'sys_created_on')}\n"
    )

    logger.info("Retrieved change request %s", number)
    return [TextContent(type="text", text=text)]


async def _search_change_requests(args: dict) -> list[TextContent]:
    cred_error = _check_credentials()
    if cred_error:
        return cred_error

    query = args["query"]
    limit = args.get("limit", "10")
    url = (
        f"{INSTANCE_URL}/api/now/table/change_request"
        f"?sysparm_query={query}&sysparm_limit={limit}"
    )
    logger.info("GET %s", url)

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(url, headers=_auth_header())

    if resp.status_code != 200:
        error_text = (
            f"ServiceNow API error (HTTP {resp.status_code}):\n{resp.text}"
        )
        logger.error(error_text)
        return [TextContent(type="text", text=error_text)]

    results = resp.json().get("result", [])
    if not results:
        return [TextContent(type="text", text=f"No change requests found for query: {query}")]

    lines = [f"Found {len(results)} change request(s):\n"]
    for chg in results:
        lines.append(
            f"  [{_val(chg, 'number')}] {_val(chg, 'short_description')}\n"
            f"    Type: {_val(chg, 'type')} | State: {_val(chg, 'state')} | "
            f"Risk: {_val(chg, 'risk')} | Approval: {_val(chg, 'approval')}\n"
        )

    text = "\n".join(lines)
    logger.info("Change request search returned %d result(s)", len(results))
    return [TextContent(type="text", text=text)]


async def _update_change_request(args: dict) -> list[TextContent]:
    cred_error = _check_credentials()
    if cred_error:
        return cred_error

    number = args["number"]
    fields = args["fields"]

    sys_id = await _get_sys_id("change_request", number)
    if not sys_id:
        return [TextContent(type="text", text=f"Change request {number} not found.")]

    url = f"{INSTANCE_URL}/api/now/table/change_request/{sys_id}"
    logger.info("PATCH %s", url)
    logger.info("Fields: %s", json.dumps(fields, indent=2))

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.patch(url, headers=_auth_header(), json=fields)

    if resp.status_code == 200:
        result = resp.json().get("result", {})
        text = (
            f"Change Request {number} updated successfully!\n"
            f"  Short Description: {_val(result, 'short_description')}\n"
            f"  Type:              {_val(result, 'type')}\n"
            f"  State:             {_val(result, 'state')}\n"
            f"  Risk:              {_val(result, 'risk')}\n"
            f"  Impact:            {_val(result, 'impact')}\n"
            f"  Priority:          {_val(result, 'priority')}\n"
            f"  Assignment Group:  {_val(result, 'assignment_group')}\n"
            f"  Approval:          {_val(result, 'approval')}\n"
        )
        logger.info("Updated change request %s", number)
        return [TextContent(type="text", text=text)]
    else:
        error_text = (
            f"ServiceNow API error (HTTP {resp.status_code}):\n{resp.text}"
        )
        logger.error(error_text)
        return [TextContent(type="text", text=error_text)]


# -- Entrypoint --------------------------------------------------------------

async def main():
    """Start the MCP server over stdio."""
    async with stdio_server() as (read_stream, write_stream):
        logger.info("ServiceNow MCP server started (stdio)")
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main_cli():
    """CLI entry point for the MCP server."""
    asyncio.run(main())


if __name__ == "__main__":
    main_cli()
