"""ServiceNow MCP Agent -- manage ServiceNow incidents via Claude and MCP."""

__version__ = "0.2.2"
