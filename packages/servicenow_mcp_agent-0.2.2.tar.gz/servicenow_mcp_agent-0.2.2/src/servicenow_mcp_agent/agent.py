"""Claude agent that manages ServiceNow incidents via an MCP tool server."""

import asyncio
import io
import json
import os
import sys
from contextlib import AsyncExitStack
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

from dotenv import load_dotenv
from anthropic import AnthropicBedrock
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

load_dotenv()

BEDROCK_REGION = os.getenv("AWS_REGION", "us-east-2")
BEDROCK_PROFILE = os.getenv("AWS_PROFILE", "default")
MODEL_ID = "us.anthropic.claude-opus-4-6-v1"

SYSTEM_PROMPT = """You are an IT Service Management assistant that manages ServiceNow.

You have the following tools available:

INCIDENT MANAGEMENT:

1. create_incident - Create a new incident in ServiceNow.
   Use when the user describes a new problem or asks to open/create a ticket.
   Extract: short_description, description, impact, urgency, category, and
   optionally assignment_group from the user's message.

2. get_incident - Look up a single incident by its number (e.g. INC0010054).
   Use when the user asks about a specific incident, wants its status, or
   needs details on a known ticket.

3. search_incidents - Search for incidents using ServiceNow encoded query strings.
   Use when the user wants to find incidents by criteria such as state, impact,
   category, assignment group, or assigned user. Build the encoded query from
   the user's filters (e.g. "state=1^impact=1^category=Software").

4. update_incident - Update fields on an existing incident.
   Use when the user wants to change details like impact, urgency, category,
   assignment_group, description, or state on an existing ticket.

5. add_comment - Add a customer-visible comment or internal work note to an incident.
   Use when the user wants to post an update, note, or message on a ticket.
   Choose type "comment" for customer-visible or "work_note" for internal.

6. resolve_incident - Resolve an incident with a close code and resolution notes.
   Use when the user indicates a problem is fixed and the ticket should be resolved.
   The close_code must be one of the standard ServiceNow resolution codes.

KNOWLEDGE BASE:

7. search_knowledge_base - Search KB articles by keyword.
   IMPORTANT: Use this BEFORE creating an incident when the user reports a problem.
   If a KB article matches, present the solution first and ask if the issue is resolved
   before opening a ticket. This avoids unnecessary incident creation.

8. get_kb_article - Retrieve a full KB article by its number (e.g. KB0000001).
   Use when the user asks for a specific article or wants more detail on a search result.

CHANGE MANAGEMENT:

9. create_change_request - Create a new Change Request.
   Use when a planned change to infrastructure, software, or configuration is needed.
   Types: Standard (pre-approved), Normal (needs CAB approval), Emergency (urgent).

10. get_change_request - Look up a Change Request by number (e.g. CHG0000001).
    Use when the user asks about a specific change, its approval status, or schedule.

11. search_change_requests - Search Change Requests by criteria.
    Use when the user wants to find changes by state, type, risk, or assignment group.

12. update_change_request - Update fields on an existing Change Request.
    Use to modify risk, impact, assignment, schedule, or state.

Incident state values:
  1 = New, 2 = In Progress, 3 = On Hold, 6 = Resolved, 7 = Closed

Change Request state values:
  -5 = New, -4 = Assess, -3 = Authorize, -2 = Scheduled, -1 = Implement,
  0 = Review, 3 = Closed, 4 = Cancelled

Change Request risk values (use numeric values when searching):
  1 = Very High, 2 = High, 3 = Moderate, 4 = Low

Change Request type values (use lowercase when searching):
  normal, standard, emergency

Field guidelines for create_incident:
- impact: 1 (High - widespread), 2 (Medium - limited), 3 (Low - single user)
- urgency: 1 (High - business-critical), 2 (Medium - degraded), 3 (Low - workaround available)
- category: one of Software, Hardware, Network, Database, Security, Service

General behavior:
- When a user reports a problem, FIRST search the Knowledge Base for a matching article.
  If a solution exists, present it and ask if the problem is resolved before creating an incident.
- Use your judgment to infer impact, urgency, and category from context when creating incidents.
- If the user mentions a team or group, set the assignment_group accordingly.
- Before calling a create or update tool, briefly summarize what you are about to do.
- After any tool call, present the key results clearly to the user.
- When searching, help the user build the right query from their natural language request.
- When resolving, confirm the close code and notes with the user before proceeding."""


def _server_script_path() -> str:
    """Return the absolute path to the MCP server script within this package."""
    return str(Path(__file__).parent / "server.py")


class ServiceNowAgent:
    """Agentic loop that connects Claude (via Bedrock) to the ServiceNow MCP server."""

    def __init__(self):
        self.session: ClientSession | None = None
        self.exit_stack = AsyncExitStack()
        self.client = AnthropicBedrock(
            aws_region=BEDROCK_REGION,
            aws_profile=BEDROCK_PROFILE,
        )

    async def connect(self, server_script: str):
        """Spawn the MCP server as a subprocess and establish a session."""
        env = os.environ.copy()
        env["DOTENV_PATH"] = str(Path.cwd() / ".env")
        server_params = StdioServerParameters(
            command=sys.executable,
            args=[server_script],
            env=env,
        )
        stdio_transport = await self.exit_stack.enter_async_context(
            stdio_client(server_params)
        )
        read_stream, write_stream = stdio_transport
        self.session = await self.exit_stack.enter_async_context(
            ClientSession(read_stream, write_stream)
        )
        await self.session.initialize()

        tools_resp = await self.session.list_tools()
        tool_names = [t.name for t in tools_resp.tools]
        print(f"Connected to MCP server -- available tools: {tool_names}")

    async def _get_tools(self) -> list[dict]:
        """Fetch available tools from the MCP server in Anthropic API format."""
        resp = await self.session.list_tools()
        return [
            {
                "name": t.name,
                "description": t.description,
                "input_schema": t.inputSchema,
            }
            for t in resp.tools
        ]

    async def run(self, user_message: str) -> str:
        """Send a user message through Claude, executing any tool calls until done."""
        print(f"\n{'-'*60}")
        print(f"User: {user_message}")
        print(f"{'-'*60}")

        tools = await self._get_tools()
        messages = [{"role": "user", "content": user_message}]

        while True:
            response = self.client.messages.create(
                model=MODEL_ID,
                max_tokens=2048,
                system=SYSTEM_PROMPT,
                messages=messages,
                tools=tools,
            )

            assistant_content = response.content
            messages.append({"role": "assistant", "content": assistant_content})

            tool_results = []
            has_tool_use = False

            for block in assistant_content:
                if block.type == "text":
                    print(f"\nAssistant: {block.text}")

                elif block.type == "tool_use":
                    has_tool_use = True
                    print(f"\n>> Calling tool: {block.name}")
                    print(f"   Arguments: {json.dumps(block.input, indent=2)}")

                    result = await self.session.call_tool(block.name, block.input)
                    result_text = result.content[0].text if result.content else "No result"

                    print(f"\n<< Tool result:\n{result_text}")

                    tool_results.append(
                        {
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": result_text,
                        }
                    )

            if not has_tool_use:
                break

            messages.append({"role": "user", "content": tool_results})

        final_texts = [b.text for b in assistant_content if b.type == "text"]
        return "\n".join(final_texts)

    async def chat(self):
        """Run an interactive multi-turn chat loop in the terminal."""
        print("\n" + "=" * 60)
        print("  ServiceNow ITSM Agent  (Bedrock / Opus 4.6)")
        print("=" * 60)
        print("I can manage incidents, search the Knowledge Base, and")
        print("handle Change Requests. Type 'quit' to exit.\n")

        while True:
            try:
                user_input = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nGoodbye!")
                break

            if not user_input:
                continue
            if user_input.lower() in ("quit", "exit"):
                print("Goodbye!")
                break

            await self.run(user_input)

    async def close(self):
        """Shut down the MCP server subprocess and release resources."""
        await self.exit_stack.aclose()


async def main():
    server_script = _server_script_path()

    agent = ServiceNowAgent()
    try:
        await agent.connect(server_script)
        await agent.chat()
    finally:
        await agent.close()


def main_cli():
    """CLI entry point for the agent."""
    asyncio.run(main())


if __name__ == "__main__":
    main_cli()
