"""ptm-mcp: MCP stdio server for the Prompt Test Manager API."""

__version__ = "0.12.1"

__all__ = ["__version__"]
