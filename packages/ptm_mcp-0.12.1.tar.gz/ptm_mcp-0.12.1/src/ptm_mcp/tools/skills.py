"""Skill Library tools (v0.9.0 + load_skill).

Nine tools cover the agent-facing surface of the Skill Library and prompt execution:

- ``list_skills``    - read, cacheable; browse the catalog.
- ``get_skill``      - read, cacheable; fetch one skill by UUID or qualified name.
- ``install_skill``  - WRITE; download and atomically install a skill bundle.
  Installs to ~/.claude/skills/{skill_name}/ (slug-named, works as slash command).
- ``load_skill``     - WRITE; install (if absent) + return full bundle content so
  the agent can immediately execute bash/Claude Code skills with given parameters.
- ``publish_skill``  - WRITE; publish a PTM prompt as a skill catalog entry.
- ``update_skill``   - WRITE; patch metadata, identified by qualified name.
- ``deprecate_skill`` - WRITE; mark deprecated, identified by qualified name.
- ``run_skill``      - WRITE; execute an LLM skill via PTM eval pipeline.
- ``run_prompt``     - WRITE; execute a PTM prompt directly via PTM eval pipeline.
"""

from __future__ import annotations

import os
import uuid
from pathlib import Path
from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient, PTMNotFoundError

from ..config import Settings
from ._helpers import call_client_safely, require_str
from ._writes import ensure_writes_allowed


def _skills_root() -> Path:
    env = os.environ.get("PTM_SKILLS_DIR")
    return Path(env).expanduser() if env else Path.home() / ".claude" / "skills"


def specs(settings: Settings) -> list[tuple[Tool, Any]]:
    return [
        (_list_skills_schema(), _list_skills_handler),
        (_search_skills_schema(), _search_skills_handler),
        (_get_skill_schema(), _make_get_handler(settings)),
        (_get_skill_contents_schema(), _make_get_skill_contents_handler(settings)),
        (_install_skill_schema(), _make_install_handler(settings)),
        (_load_skill_schema(), _make_load_skill_handler(settings)),
        (_publish_skill_schema(), _make_publish_handler(settings)),
        (_update_skill_schema(), _make_update_handler(settings)),
        (_deprecate_skill_schema(), _make_deprecate_handler(settings)),
        (_run_skill_schema(), _make_run_skill_handler(settings)),
        (_run_prompt_schema(), _make_run_prompt_handler(settings)),
    ]


def _is_qualified_name(value: str) -> bool:
    """True when value looks like an explicit qualified name or UUID the caller already resolved."""
    return value.startswith("@") or _is_uuid_check(value)


def _is_uuid_check(value: str) -> bool:
    try:
        import uuid as _uuid

        _uuid.UUID(value)
        return True
    except ValueError:
        return False


async def _resolve_skill(client: PTMClient, value: str) -> tuple[dict | None, list[dict]]:
    """Resolve a possibly-ambiguous skill name to a single catalog row.

    Returns ``(skill, [])`` when exactly one match found.
    Returns ``(None, candidates)`` when zero or multiple matches found.
    The caller must surface candidates to the user for disambiguation.
    """
    if _is_qualified_name(value):
        if _is_uuid_check(value):
            skill = await call_client_safely(client.get_skill, value)
        else:
            skill = await call_client_safely(client.get_skill_by_name, value)
        return skill, []

    # Bare slug (no @ prefix, not a UUID): try exact public-namespace lookup
    # first. get_skill_by_name("slug") matches skill_name exactly in the public
    # namespace - which is correct for bare public slugs. Fuzzy search only
    # checks display_name/description so it misses skills whose display_name
    # does not contain the slug.
    try:
        skill = client.get_skill_by_name(value)
        if skill:
            return skill, []
    except PTMNotFoundError:
        # Exact name lookup can legitimately miss; fall back to catalog search below.
        pass

    result = await call_client_safely(client.list_skills, search=value, page_size=10)
    items = result.get("items", []) if isinstance(result, dict) else []

    if len(items) == 1:
        return items[0], []
    return None, items


def _disambiguation_response(value: str, candidates: list[dict]) -> dict:
    """Build a structured response when skill name is ambiguous."""
    if not candidates:
        return {
            "resolved": False,
            "query": value,
            "error": (
                f"No skill found matching '{value}'. "
                "Use list_skills or search_skills to browse available skills."
            ),
            "candidates": [],
        }
    return {
        "resolved": False,
        "query": value,
        "error": (
            f"'{value}' matches {len(candidates)} skills. "
            "Confirm the qualified_name with the user before proceeding."
        ),
        "candidates": [
            {
                "qualified_name": s.get("qualified_name"),
                "display_name": s.get("display_name"),
                "description": s.get("description"),
                "namespace": s.get("namespace"),
                "tags": s.get("tags", []),
            }
            for s in candidates
        ],
    }


# ----------------------------------------------------------------------
# search_skills
# ----------------------------------------------------------------------


def _search_skills_schema() -> Tool:
    return Tool(
        name="search_skills",
        description=(
            "Search the PTM skill catalog by keyword, display name, or description. "
            "Use this BEFORE calling load_skill, run_skill, or install_skill when the "
            "user provides a bare word or ambiguous name (e.g. 'caveman', 'weather', "
            "'pr review') instead of a fully-qualified name like @scope/slug. "
            "Returns matching skills with their qualified names so you can confirm "
            "the right skill with the user before acting. "
            "If search returns exactly 1 result, you may proceed directly. "
            "If 0 or 2+ results, show candidates and ask the user to confirm."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": (
                        "Search term: partial name, display name, keyword, or description. "
                        "E.g. 'caveman', 'pr review', 'slides', 'git commit', 'approve tmux'"
                    ),
                },
                "namespace": {
                    "type": "string",
                    "enum": ["personal", "team", "public"],
                    "description": "Restrict to a namespace (optional).",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter by tags (AND semantics, optional).",
                },
            },
            "required": ["query"],
            "additionalProperties": False,
        },
    )


async def _search_skills_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    query = require_str(arguments, "query")
    namespace = arguments.get("namespace")
    tags = arguments.get("tags")
    result = await call_client_safely(
        client.list_skills,
        search=query,
        namespace=namespace,
        tags=tags,
        page_size=20,
    )
    items = result.get("items", []) if isinstance(result, dict) else []
    if not items:
        return {
            "query": query,
            "count": 0,
            "message": (
                f"No skills found matching '{query}'. "
                "Try a different search term or use list_skills to browse all."
            ),
            "candidates": [],
        }
    return {
        "query": query,
        "count": len(items),
        "message": (
            f"Found {len(items)} skill(s). "
            + (
                "Exactly 1 match - safe to proceed with qualified_name below."
                if len(items) == 1
                else "Multiple matches - confirm qualified_name with user before calling load_skill/run_skill/install_skill."  # noqa: E501
            )
        ),
        "candidates": [
            {
                "qualified_name": s.get("qualified_name"),
                "display_name": s.get("display_name"),
                "description": s.get("description"),
                "namespace": s.get("namespace"),
                "tags": s.get("tags", []),
            }
            for s in items
        ],
    }


def _is_uuid(value: str) -> bool:
    try:
        uuid.UUID(value)
        return True
    except ValueError:
        return False


# ----------------------------------------------------------------------
# list_skills
# ----------------------------------------------------------------------


def _list_skills_schema() -> Tool:
    return Tool(
        name="list_skills",
        description=(
            "List published skills in the PTM catalog. All filters are "
            "optional; pass only the ones you want to apply. Returns a "
            "paginated payload with items, total, page, page_size."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {
                    "type": "string",
                    "enum": ["personal", "team", "public"],
                    "description": "Restrict to a single namespace.",
                },
                "search": {"type": "string", "description": "Free-text search."},
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "AND-matched tag list.",
                },
                "include_deprecated": {
                    "type": "boolean",
                    "description": "Include deprecated catalog rows.",
                },
                "page": {"type": "integer", "minimum": 1},
                "page_size": {"type": "integer", "minimum": 1, "maximum": 200},
            },
            "additionalProperties": False,
        },
    )


async def _list_skills_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    return await call_client_safely(
        client.list_skills,
        namespace=arguments.get("namespace"),
        search=arguments.get("search"),
        tags=arguments.get("tags"),
        include_deprecated=bool(arguments.get("include_deprecated") or False),
        page=int(arguments.get("page") or 1),
        page_size=int(arguments.get("page_size") or 50),
    )


# ----------------------------------------------------------------------
# get_skill
# ----------------------------------------------------------------------


def _get_skill_schema() -> Tool:
    return Tool(
        name="get_skill",
        description=(
            "Fetch a skill catalog row by UUID or qualified name. "
            "Qualified name format: @username/slug (personal), "
            "@group/slug (team), or bare slug (public)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "skill_id_or_name": {
                    "type": "string",
                    "description": "UUID or qualified name of the skill.",
                },
            },
            "required": ["skill_id_or_name"],
            "additionalProperties": False,
        },
    )


def _make_get_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        value = require_str(arguments, "skill_id_or_name")
        if _is_uuid(value):
            return await call_client_safely(client.get_skill, value)
        return await call_client_safely(client.get_skill_by_name, value)

    return _handler


# ----------------------------------------------------------------------
# get_skill_contents (read - Phase 18.8)
# ----------------------------------------------------------------------


def _get_skill_contents_schema() -> Tool:
    return Tool(
        name="get_skill_contents",
        description=(
            "Fetch a skill's bundle contents in JSON form (no install, no LLM call). "
            "Returns prompt_md, manifest, and the full bundle file map so the agent "
            "can run the prompt on its OWN model in the current Claude session "
            "instead of routing through PTM's eval pipeline. "
            "Use this when you only need the prompt text + tests + tool definitions "
            "and you already plan to execute it inline. "
            "For a full PTM eval (records to history, computes a score), use run_skill. "
            "Accepts UUID, qualified_name (@scope/slug), or bare slug for public skills."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "skill_id_or_name": {
                    "type": "string",
                    "description": "UUID, qualified name, or bare slug (public).",
                },
            },
            "required": ["skill_id_or_name"],
            "additionalProperties": False,
        },
    )


def _make_get_skill_contents_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        # Read tool: no ensure_writes_allowed - the endpoint never creates
        # a runs row and never invokes an LLM, so a read-only token must
        # still be able to call this.
        value = require_str(arguments, "skill_id_or_name")

        skill, candidates = await _resolve_skill(client, value)
        if skill is None:
            return _disambiguation_response(value, candidates)

        skill_id = str(skill["id"])
        return await call_client_safely(client.get_skill_contents, skill_id)

    return _handler


# ----------------------------------------------------------------------
# install_skill (write)
# ----------------------------------------------------------------------


def _install_skill_schema() -> Tool:
    return Tool(
        name="install_skill",
        description=(
            "Download a skill bundle and install it into the local Claude "
            "Code skills directory (default ``~/.claude/skills``). Accepts "
            "UUID or qualified name (@scope/slug or bare slug for public). "
            "The install is atomic on POSIX (extract to a temp dir, then "
            "``os.replace`` the staged directory into place)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "skill_id_or_name": {
                    "type": "string",
                    "description": "UUID or qualified name of the skill to install.",
                },
                "target_dir": {
                    "type": "string",
                    "description": (
                        "Override the install root. Defaults to "
                        "$PTM_SKILLS_DIR or ~/.claude/skills."
                    ),
                },
            },
            "required": ["skill_id_or_name"],
            "additionalProperties": False,
        },
    )


def _make_install_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        value = require_str(arguments, "skill_id_or_name")
        target_dir = arguments.get("target_dir")

        skill, candidates = await _resolve_skill(client, value)
        if skill is None:
            return _disambiguation_response(value, candidates)

        skill_id = str(skill["id"])
        skill_name = skill.get("skill_name") or skill_id

        installed_path = await call_client_safely(
            client.install_skill_for_claude_code,
            skill_id,
            target_dir=target_dir,
            install_name=skill_name,
        )
        return {
            "skill_id": skill_id,
            "skill_name": skill_name,
            "qualified_name": skill.get("qualified_name"),
            "installed_path": str(installed_path),
        }

    return _handler


# ----------------------------------------------------------------------
# load_skill (write - installs if absent, returns bundle content)
# ----------------------------------------------------------------------

_READABLE_SUFFIXES = frozenset({".md", ".json", ".yaml", ".yml", ".txt", ".sh", ""})


def _load_skill_schema() -> Tool:
    return Tool(
        name="load_skill",
        description=(
            "Install a skill from PTM and return its full bundle content for immediate "
            "inline execution. Installs to ~/.claude/skills/{skill_name}/. Returns skill "
            "metadata, installed path, and all bundle files (prompt.md, manifest.json, etc.). "
            "IMPORTANT: skill_id_or_name must be a qualified name (@scope/slug), UUID, or "
            "bare slug for public skills. If the user gives a bare word or partial name "
            "(e.g. 'caveman', 'weather', 'pr review'), call search_skills FIRST to resolve "
            "the correct qualified_name, then confirm with user before calling this tool. "
            "Never guess the qualified_name - search first."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "skill_id_or_name": {
                    "type": "string",
                    "description": (
                        "MUST be a qualified name (@scope/slug), UUID, or bare public slug. "
                        "If user gave an ambiguous name, call search_skills first."
                    ),
                },
                "force_reinstall": {
                    "type": "boolean",
                    "description": "Re-download even if already installed locally. Default false.",
                },
                "target_dir": {
                    "type": "string",
                    "description": (
                        "Override install root. Defaults to $PTM_SKILLS_DIR or ~/.claude/skills."
                    ),
                },
            },
            "required": ["skill_id_or_name"],
            "additionalProperties": False,
        },
    )


def _make_load_skill_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        value = require_str(arguments, "skill_id_or_name")
        force_reinstall = bool(arguments.get("force_reinstall", False))
        target_dir_arg = arguments.get("target_dir")

        skill, candidates = await _resolve_skill(client, value)
        if skill is None:
            return _disambiguation_response(value, candidates)

        skill_id = str(skill["id"])
        skill_name = skill.get("skill_name") or skill_id

        root = Path(target_dir_arg).expanduser() if target_dir_arg else _skills_root()
        install_path = root / skill_name

        is_fresh = False
        if not install_path.exists() or force_reinstall:
            await call_client_safely(
                client.install_skill_for_claude_code,
                skill_id,
                target_dir=str(root),
                install_name=skill_name,
            )
            is_fresh = True

        bundle_files: dict[str, str] = {}
        if install_path.is_dir():
            for f in sorted(install_path.iterdir()):
                if f.is_file() and f.suffix.lower() in _READABLE_SUFFIXES:
                    try:
                        bundle_files[f.name] = f.read_text(errors="replace")
                    except OSError:
                        # Best-effort: skip files that become unreadable between directory
                        # listing and read (e.g. permission denied, file removed mid-scan).
                        pass

        return {
            "skill_id": skill_id,
            "skill_name": skill_name,
            "qualified_name": skill.get("qualified_name"),
            "display_name": skill.get("display_name"),
            "description": skill.get("description"),
            "consumer_summary": skill.get("consumer_summary"),
            "installed_path": str(install_path),
            "is_fresh": is_fresh,
            "bundle_files": bundle_files,
        }

    return _handler


# ----------------------------------------------------------------------
# publish_skill (write)
# ----------------------------------------------------------------------


def _publish_skill_schema() -> Tool:
    return Tool(
        name="publish_skill",
        description=(
            "Publish an existing PTM prompt as a distributable skill. "
            "Creates or refreshes the catalog entry and generates the bundle. "
            "skill_name becomes the slug (defaults to prompt_id). "
            "Qualified name will be @username/skill_name (personal), "
            "@group/skill_name (team), or skill_name (public)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_id": {"type": "string", "description": "PTM prompt_id to publish."},
                "display_name": {"type": "string", "description": "Consumer-facing skill name."},
                "description": {"type": "string", "description": "Short description."},
                "consumer_summary": {
                    "type": "string",
                    "description": "One-paragraph install guide for consumers.",
                },
                "skill_name": {
                    "type": "string",
                    "description": "URL-safe slug (a-z0-9-). Defaults to prompt_id.",
                },
                "namespace": {
                    "type": "string",
                    "enum": ["personal", "team", "public"],
                    "default": "personal",
                    "description": "Who can see this skill.",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Discovery tags.",
                },
                "team_group_id": {
                    "type": "string",
                    "description": "Required when namespace='team'. Group UUID.",
                },
            },
            "required": ["prompt_id", "display_name", "description", "consumer_summary"],
            "additionalProperties": False,
        },
    )


def _make_publish_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = require_str(arguments, "prompt_id")
        display_name = require_str(arguments, "display_name")
        description = require_str(arguments, "description")
        consumer_summary = require_str(arguments, "consumer_summary")
        return await call_client_safely(
            client.publish_skill,
            prompt_id,
            display_name=display_name,
            description=description,
            consumer_summary=consumer_summary,
            skill_name=arguments.get("skill_name"),
            namespace=arguments.get("namespace") or "personal",
            tags=arguments.get("tags") or [],
            team_group_id=arguments.get("team_group_id"),
        )

    return _handler


# ----------------------------------------------------------------------
# update_skill (write)
# ----------------------------------------------------------------------


def _update_skill_schema() -> Tool:
    return Tool(
        name="update_skill",
        description=(
            "Update metadata or sharing scope on a skill. Identify by qualified name. "
            "Use namespace + team_group_id to share a personal skill to a team group, "
            "or namespace='public' (requires manage_skill_catalog) to make it org-wide."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "qualified_name": {
                    "type": "string",
                    "description": "@scope/slug or bare slug for public.",
                },
                "display_name": {"type": "string"},
                "description": {"type": "string"},
                "consumer_summary": {"type": "string"},
                "tags": {"type": "array", "items": {"type": "string"}},
                "namespace": {
                    "type": "string",
                    "enum": ["personal", "team", "public"],
                    "description": (
                        "Promote or demote the skill's visibility scope. "
                        "'team' requires team_group_id. 'public' requires manage_skill_catalog."
                    ),
                },
                "team_group_id": {
                    "type": "string",
                    "description": "Group UUID (required when namespace='team'). Use list_groups.",
                },
            },
            "required": ["qualified_name"],
            "additionalProperties": False,
        },
    )


def _make_update_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        qualified_name = require_str(arguments, "qualified_name")
        skill = await call_client_safely(client.get_skill_by_name, qualified_name)
        skill_id = skill["id"]

        update_fields: dict[str, Any] = {}
        for field in (
            "display_name",
            "description",
            "consumer_summary",
            "tags",
            "namespace",
            "team_group_id",
        ):
            if field in arguments:
                update_fields[field] = arguments[field]

        return await call_client_safely(client.update_skill, skill_id, **update_fields)

    return _handler


# ----------------------------------------------------------------------
# deprecate_skill (write)
# ----------------------------------------------------------------------


def _deprecate_skill_schema() -> Tool:
    return Tool(
        name="deprecate_skill",
        description="Mark a skill as deprecated by qualified name.",
        inputSchema={
            "type": "object",
            "properties": {
                "qualified_name": {
                    "type": "string",
                    "description": "@scope/slug or bare slug for public.",
                },
                "deprecation_message": {
                    "type": "string",
                    "description": "Optional reason / migration instructions.",
                },
            },
            "required": ["qualified_name"],
            "additionalProperties": False,
        },
    )


def _make_deprecate_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        qualified_name = require_str(arguments, "qualified_name")
        skill = await call_client_safely(client.get_skill_by_name, qualified_name)
        skill_id = skill["id"]

        update_kwargs: dict[str, Any] = {"deprecated": True}
        deprecation_message = arguments.get("deprecation_message")
        if deprecation_message is not None:
            update_kwargs["deprecation_message"] = deprecation_message

        return await call_client_safely(client.update_skill, skill_id, **update_kwargs)

    return _handler


# ----------------------------------------------------------------------
# run_skill (write)
# ----------------------------------------------------------------------


def _run_skill_schema() -> Tool:
    return Tool(
        name="run_skill",
        description=(
            "FULL PTM EVAL: Runs the skill's stored test suite through the Promptfoo + "
            "DeepEval pipeline, scores the output, and records a run row in PTM history "
            "(linked to the real skill_id and prompt_id). The provided ``inputs`` are "
            "merged into each stored test's ``vars`` per-key (default mode replaces "
            "overlapping keys, ``amend=true`` keeps the stored value on conflict). "
            "If you only want the prompt content to execute on YOUR LLM in this Claude "
            "session - no PTM eval, no run history - use get_skill_contents instead. "
            "Accepts UUID, qualified_name, or bare slug (public)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "qualified_name": {
                    "type": "string",
                    "description": (
                        "Skill to run. Use @scope/name for personal/team, "
                        "bare name for public. E.g. 'monitor' or '@alice/monitor'."
                    ),
                },
                "inputs": {
                    "type": "object",
                    "description": (
                        "Key-value map injected into each stored test's ``vars``. "
                        "Default mode overwrites overlapping keys per test; with "
                        "``amend=true`` the stored value wins on conflict."
                    ),
                    "additionalProperties": True,
                },
                "provider_profile": {
                    "type": "string",
                    "description": "Provider profile from list_providers.",
                },
                "judge_profile": {
                    "type": ["string", "null"],
                    "description": "DeepEval judge profile for output scoring.",
                },
                "timeout_seconds": {
                    "type": "integer",
                    "minimum": 10,
                    "maximum": 300,
                    "description": "Max wait time. Default 60.",
                },
                "amend": {
                    "type": "boolean",
                    "description": (
                        "When true, ``inputs`` only fills keys missing from each "
                        "stored test (existing test value wins on conflict). "
                        "Default false: every overlapping key is overwritten."
                    ),
                },
            },
            "required": ["qualified_name", "inputs", "provider_profile"],
            "additionalProperties": False,
        },
    )


def _make_run_skill_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        qualified_name = require_str(arguments, "qualified_name")
        inputs = arguments.get("inputs") or {}
        provider_profile = require_str(arguments, "provider_profile")
        judge_profile = arguments.get("judge_profile")
        timeout_seconds = int(arguments.get("timeout_seconds") or 60)
        amend = bool(arguments.get("amend") or False)

        # Disambiguate before invoking - prevents running the wrong skill.
        if not _is_qualified_name(qualified_name):
            skill, candidates = await _resolve_skill(client, qualified_name)
            if skill is None:
                return _disambiguation_response(qualified_name, candidates)
            qualified_name = skill.get("qualified_name") or qualified_name

        if _is_uuid(qualified_name):
            return await call_client_safely(
                client.invoke_skill,
                qualified_name,
                inputs,
                provider_profile,
                judge_profile=judge_profile,
                timeout_seconds=timeout_seconds,
                amend=amend,
            )
        return await call_client_safely(
            client.invoke_skill_by_name,
            qualified_name,
            inputs,
            provider_profile,
            judge_profile=judge_profile,
            timeout_seconds=timeout_seconds,
            amend=amend,
        )

    return _handler


# ----------------------------------------------------------------------
# run_prompt (write)
# ----------------------------------------------------------------------


def _run_prompt_schema() -> Tool:
    return Tool(
        name="run_prompt",
        description=(
            "FULL PTM EVAL: Runs the prompt's stored test suite through the Promptfoo + "
            "DeepEval pipeline, scores the output, and records a run row in PTM history "
            "(linked to the real prompt_id). The provided ``inputs`` are merged into "
            "each stored test's ``vars`` per-key (default mode replaces overlapping "
            "keys, ``amend=true`` keeps the stored value on conflict). "
            "If you only want the prompt content to execute on YOUR LLM in this Claude "
            "session - no PTM eval, no run history - use get_prompt_contents (or "
            "load_prompt for the rendered text) instead. "
            "Use run_skill when the prompt is published as a skill catalog entry."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_id": {
                    "type": "string",
                    "description": "PTM prompt_id to execute (e.g. 'devops.release_notes').",
                },
                "inputs": {
                    "type": "object",
                    "description": (
                        "Key-value map injected into each stored test's ``vars``. "
                        "Default mode overwrites overlapping keys per test; with "
                        "``amend=true`` the stored value wins on conflict."
                    ),
                    "additionalProperties": True,
                },
                "provider_profile": {
                    "type": "string",
                    "description": "Provider profile from list_providers.",
                },
                "judge_profile": {
                    "type": ["string", "null"],
                    "description": "DeepEval judge profile for output scoring.",
                },
                "timeout_seconds": {
                    "type": "integer",
                    "minimum": 10,
                    "maximum": 300,
                    "description": "Max wait time. Default 60.",
                },
                "amend": {
                    "type": "boolean",
                    "description": (
                        "When true, ``inputs`` only fills keys missing from each "
                        "stored test (existing test value wins on conflict). "
                        "Default false: every overlapping key is overwritten."
                    ),
                },
            },
            "required": ["prompt_id", "inputs", "provider_profile"],
            "additionalProperties": False,
        },
    )


def _make_run_prompt_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = require_str(arguments, "prompt_id")
        inputs = arguments.get("inputs") or {}
        provider_profile = require_str(arguments, "provider_profile")
        judge_profile = arguments.get("judge_profile")
        timeout_seconds = int(arguments.get("timeout_seconds") or 60)
        amend = bool(arguments.get("amend") or False)

        return await call_client_safely(
            client.invoke_prompt,
            prompt_id,
            inputs,
            provider_profile,
            judge_profile=judge_profile,
            timeout_seconds=timeout_seconds,
            amend=amend,
        )

    return _handler
