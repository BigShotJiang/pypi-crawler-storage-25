"""Tool registry for ptm-mcp.

The ``mcp`` SDK wires tools through a single ``@server.list_tools()`` +
``@server.call_tool()`` decorator pair per ``Server`` instance. This
registry centralizes the dispatch so every tool file can stay focused on
schema + argument handling.

Commit 3 additions:
- Write-tool files (``evals``, ``optimization_writes``) export a
  ``specs(settings)`` function so handlers can close over the
  ``Settings.read_only`` flag for the gate check.
- Module-level ``TOOL_SPECS`` is built eagerly with a default
  ``read_only=True`` settings so CI smoke checks (``len(TOOL_SPECS)``)
  do not require any env vars to import the module.
- ``register_tools(server, client, settings=None)`` accepts an explicit
  ``Settings`` at server bootstrap; the server.run() call threads the
  real settings through from ``load_settings``.

Adding a tool:
  1. Drop a new module under ``tools/`` with a ``specs()`` (read) or
     ``specs(settings)`` (write) function returning
     ``list[tuple[Tool, async handler]]``.
  2. Add the module's call to ``_build_tool_specs`` below.
"""

from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from typing import Any

from mcp.server import Server
from mcp.types import TextContent, Tool
from ptm_client import PTMClient

from ..config import Settings
from . import (
    evals,
    optimization,
    optimization_writes,
    prompts,
    prompts_write,
    providers,
    registry,
    runs,
    runs_write,
    skills,
    triage,
    versions,
)
from ._cache import TTLCache

ToolHandler = Callable[[PTMClient, dict[str, Any]], Awaitable[Any]]


# Phase 5 / A6 - 60-second TTL cache on the read tools that get hit
# multiple times in a single agent turn. ``cachetools`` would add a
# dep for one TTL bucket; the homegrown TTLCache stays dependency-
# free (see ``_cache.py``).
_CACHE_TTL_SECONDS = 60
_cache = TTLCache(ttl_seconds=_CACHE_TTL_SECONDS)

# Tool names whose results are cacheable. Keep this list narrow:
# anything paginated or per-user (``list_runs``, ``list_triage``)
# stays uncached because the listing changes constantly.
_CACHEABLE_READ_TOOLS: frozenset[str] = frozenset(
    {"list_prompts", "list_tools", "list_providers", "list_skills", "get_skill", "search_skills"}
)

# Tool names that mutate server state. After every successful call,
# the cache is fully invalidated so a ``create_prompt`` immediately
# followed by ``list_prompts`` always sees the new entry. Cheaper
# than a precise dependency graph and correct on its face.
_INVALIDATING_WRITE_TOOLS: frozenset[str] = frozenset(
    {
        # Library mutations (prompts_write)
        "create_prompt",
        "update_prompt",
        "activate_prompt_version",
        "share_prompt",
        "unshare_prompt",
        "add_prompt_to_group",
        "remove_prompt_from_group",
        "transfer_prompt_ownership",
        "update_prompt_sampling",
        # Tool registry writes (registry write tools)
        "create_tool",
        "update_tool",
        "deprecate_tool",
        "delete_mock_profile",
        # Run mutations (runs_write)
        "submit_run_feedback",
        # Triage (triage)
        "promote_run_to_golden",
        "resolve_triage_item",
        "reopen_triage_item",
        "bulk_resolve_triage",
        # Eval / optimization writes
        "run_prompt_eval",
        "run_manual_eval",
        "submit_optimization",
        "cancel_optimization",
        # Skill Library writes and invocation
        "install_skill",
        "load_skill",
        "publish_skill",
        "update_skill",
        "deprecate_skill",
        "run_skill",
        "run_prompt",
    }
)


def _cache_key(name: str, arguments: dict[str, Any]) -> str:
    """Stable cache key for a (tool, args) pair.

    Sorted JSON guarantees ``{"a":1,"b":2}`` and ``{"b":2,"a":1}``
    map to the same key. ``default=str`` handles datetimes / UUIDs /
    Path objects without raising during cache key derivation.
    """
    return f"{name}:{json.dumps(arguments or {}, sort_keys=True, default=str)}"


def _build_tool_specs(settings: Settings) -> list[tuple[Tool, ToolHandler]]:
    """Eager aggregation of every tool spec. Write modules get ``settings``."""
    return [
        *providers.specs(),
        *prompts.specs(),
        *versions.specs(),
        *runs.specs(),
        *optimization.specs(),
        *registry.specs(settings),
        *evals.specs(settings),
        *optimization_writes.specs(settings),
        *prompts_write.specs(settings),
        *runs_write.specs(settings),
        *triage.specs(settings),
        *skills.specs(settings),
    ]


# Module-level registry built with a default ``read_only=True`` Settings
# so import-time smoke checks do not require PTM_API_BASE_URL/TOKEN to
# count tools. The server-bootstrap path in server.py passes the real
# ``Settings`` through ``register_tools`` and rebuilds the registry there.
_DEFAULT_SETTINGS = Settings(
    ptm_api_base_url="http://smoke.invalid",
    ptm_api_token="smoke",
    read_only=True,
)
TOOL_SPECS: list[tuple[Tool, ToolHandler]] = _build_tool_specs(_DEFAULT_SETTINGS)


def _render_result(result: Any) -> str:
    """Pass strings through verbatim (reports, diffs); JSON-encode everything else."""
    if isinstance(result, str):
        return result
    return json.dumps(result, indent=2, default=str)


def register_tools(
    server: Server,
    client: PTMClient,
    settings: Settings | None = None,
) -> None:
    """Register all ptm-mcp tools on the given server.

    ``settings`` is required for the write-tool read-only gate. When omitted
    (older call sites / tests), the module-level default is used.
    """
    effective_settings = settings or _DEFAULT_SETTINGS
    specs = _build_tool_specs(effective_settings)
    schemas = [spec for spec, _ in specs]
    handlers: dict[str, ToolHandler] = {spec.name: handler for spec, handler in specs}

    @server.list_tools()
    async def _list_tools() -> list[Tool]:
        return schemas

    @server.call_tool()
    async def _call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        handler = handlers.get(name)
        if handler is None:
            raise ValueError(f"Unknown tool: {name}")
        args = arguments or {}
        # Cache read tools by (name, sorted_args). A second call with
        # identical args inside the TTL window skips the HTTP round
        # trip and returns the cached result. Errors are NOT cached
        # (the handler raises before we hit the ``cache.set``).
        if name in _CACHEABLE_READ_TOOLS:
            ck = _cache_key(name, args)
            cached = _cache.get(ck)
            if cached is not None:
                return [TextContent(type="text", text=_render_result(cached))]
            result = await handler(client, args)
            _cache.set(ck, result)
            return [TextContent(type="text", text=_render_result(result))]

        result = await handler(client, args)
        # Successful write -> nuke every cached read so the next list
        # call rebuilds from the live DB. Failed writes never reach
        # this line because ``handler`` raised first.
        if name in _INVALIDATING_WRITE_TOOLS:
            _cache.invalidate_all()
        return [TextContent(type="text", text=_render_result(result))]


__all__ = [
    "TOOL_SPECS",
    "ToolHandler",
    "register_tools",
    # Exposed for tests + admin doctor commands; should not be poked
    # at runtime from regular code paths.
    "_cache",
    "_CACHEABLE_READ_TOOLS",
    "_INVALIDATING_WRITE_TOOLS",
]
