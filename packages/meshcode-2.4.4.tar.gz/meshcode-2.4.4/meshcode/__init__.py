"""MeshCode — Real-time communication between AI agents."""
__version__ = "2.4.4"
