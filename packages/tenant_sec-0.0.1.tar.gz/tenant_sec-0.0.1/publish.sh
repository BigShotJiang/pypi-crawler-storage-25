#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

echo "=== Installing build tools ==="
pip install --upgrade build twine

echo ""
echo "=== Building package ==="
rm -rf dist/
python -m build

echo ""
echo "=== Package contents ==="
twine check dist/*

echo ""
echo "========================================="
echo "  Step 1: Upload to TestPyPI"
echo "========================================="
echo ""
read -p "Upload to TestPyPI? [y/N] " confirm_test
if [[ "$confirm_test" =~ ^[Yy]$ ]]; then
    twine upload --repository testpypi dist/*
    echo ""
    echo "Check it at: https://test.pypi.org/project/tenant-sec/"
    echo ""
    read -p "Does TestPyPI look good? Proceed to real PyPI? [y/N] " confirm_prod
else
    read -p "Skip TestPyPI and go straight to PyPI? [y/N] " confirm_prod
fi

echo ""
if [[ "$confirm_prod" =~ ^[Yy]$ ]]; then
    echo "========================================="
    echo "  Step 2: Upload to PyPI (production)"
    echo "========================================="
    twine upload dist/*
    echo ""
    echo "Done! Check it at: https://pypi.org/project/tenant-sec/"
else
    echo "Skipped PyPI upload."
fi
