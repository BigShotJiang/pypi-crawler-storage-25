# tenant-sec

An open-source framework for evaluating cloud provider security capabilities at the **tenant level** — the controls and capabilities a cloud customer can actually use, configure, and rely on.

## Status

This is a placeholder release to reserve the package name. The first functional release is coming soon.

## Links

- **Source:** https://github.com/CloudSEC/TenantSec
- **License:** Apache-2.0
