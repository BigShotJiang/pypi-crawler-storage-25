"""tenant-sec: Cloud provider security capability assessment framework."""

__version__ = "0.0.1"
