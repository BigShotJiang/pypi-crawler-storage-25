import tkinter as tk
import re
import __main__

# Dicionário global para guardar os estilos processados
global_styles = {}


def parse_css_internal(css_text):
    """Lógica para transformar o texto CSS num dicionário Python"""
    styles = {}
    blocks = re.findall(r'(\w+)\s*{(.*?)}', css_text, re.DOTALL)
    for name, content in blocks:
        props = {}
        lines = re.findall(r'([\w-]+)\s*:\s*(.*?);', content)
        for key, value in lines:
            props[key.strip()] = value.strip()
        styles[name.strip()] = props
    return styles


def load_styles_now():
    """Procura a variável 'style' no ficheiro writehere.py e carrega-a (sempre recarrega)."""
    global global_styles
    if hasattr(__main__, 'style'):
        global_styles = parse_css_internal(__main__.style)


def _get_style_bg(style_dict):
    """Lê a cor de fundo; suporta 'background-color' e 'backgroundcolor' (sem hífen)."""
    return style_dict.get('background-color') or style_dict.get('backgroundcolor')


def _get_style_fg(style_dict):
    """Lê a cor do texto."""
    return style_dict.get('color')

def _get_style_pressed_color(style_dict):
    """Lê a cor de fundo ao pressionar o botão."""
    return style_dict.get('pressed-color')

def _get_style_border_color(style_dict):
    """Lê a cor da borda, ou 'none'."""
    val = style_dict.get('border-color')
    if val and val.lower() == 'none':
        return ""
    return val

def _get_style_focus_border_color(style_dict):
    val = style_dict.get('focus-border-color') or style_dict.get('focus-color')
    if val and val.lower() == 'none':
        return ""
    return val

def _parse_radius(style_dict):
    """Extrai o valor numérico de border-radius (ex: '15px' -> 15)."""
    raw = style_dict.get('border-radius', '0')
    cleaned = re.sub(r'[^0-9.]', '', str(raw))
    try:
        return int(float(cleaned))
    except (ValueError, TypeError):
        return 0

def _parse_border_width(style_dict):
    """Extrai a largura da borda (ex: '2px' -> 2)."""
    raw = style_dict.get('border-width', '0')
    cleaned = re.sub(r'[^0-9.]', '', str(raw))
    try:
        return int(float(cleaned))
    except (ValueError, TypeError):
        return 0

def _create_rounded_rect(canvas, x1, y1, x2, y2, r, **kwargs):
    """Desenha retângulo com cantos arredondados no Canvas."""
    r = max(0, min(r, (x2 - x1) // 2, (y2 - y1) // 2))
    points = [
        x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
        x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r,
        x1, y1 + r, x1, y1, x1 + r, y1,
    ]
    return canvas.create_polygon(points, smooth=True, **kwargs)


# ─── ComponentDef ─────────────────────────────────────────────────────────────

class ComponentDef:
    """
    Representa um componente de forma declarativa (antes de ser renderizado).
    Ao chamar button(..., screen=x) ou inputs(..., screen=x), é devolvido um
    ComponentDef que podes passar ao on_click_navigate().
    """
    def __init__(self, comp_type, **kwargs):
        self.comp_type = comp_type   # 'button' | 'inputs' | 'label'
        self.kwargs = kwargs         # Inclui 'comp_id' para resolver estilos no render
        self.widget = None           # widget Tkinter (preenchido ao renderizar)
        self.nav_target = None       # Screen de destino (definido por on_click_navigate)


# ─── Screen ───────────────────────────────────────────────────────────────────

class Screen:
    """
    Container que agrupa componentes num ecrã.
    Cada Screen gera uma Activity separada no Android.

    Exemplo:
        login = Screen(id="login")
        label("Bem-vindo", screen=login)
        btn = button("Entrar", screen=login)
        login.on_click_navigate(button=btn, to=dashboard)
        run(start_screen=login)
    """

    def __init__(self, id, background_image=None):
        self.id = id
        self.background_image = background_image
        self.components = []   # lista de ComponentDef

    def _add(self, comp_def):
        self.components.append(comp_def)
        return comp_def

    def on_click_navigate(self, button, to):
        """
        Define que ao clicar em 'button' neste ecrã, a app navega para 'to'.
        - No Android: gera um Intent Java.
        - No preview Tkinter: troca os componentes visíveis.
        """
        button.nav_target = to


# ─── AppPreview ───────────────────────────────────────────────────────────────

class AppPreview:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("APKPy Preview - Windows")
        self.root.geometry("360x640")

        # Frame principal que simula o ecrã do telemóvel
        self.layout = tk.Frame(self.root)
        self.layout.pack(fill="both", expand=True, padx=20, pady=20)

    # ── Multi-Screen ──────────────────────────────────────────────────────────

    def clear(self):
        """Remove todos os widgets do frame principal."""
        for widget in self.layout.winfo_children():
            widget.destroy()

    def render_screen(self, screen):
        """Limpa o ecrã e renderiza todos os componentes de um Screen."""
        self.clear()
        for comp in screen.components:
            if comp.comp_type == 'button':
                self._render_button(comp)
            elif comp.comp_type == 'inputs':
                self._render_input(comp)
            elif comp.comp_type == 'label':
                self._render_label(comp)

    def _render_label(self, comp):
        text      = comp.kwargs.get('text', '')
        comp_id   = comp.kwargs.get('comp_id')
        style     = global_styles.get(comp_id, {}) if comp_id else {}
        fg        = _get_style_fg(style) or 'black'
        lbl = tk.Label(
            self.layout,
            text=text,
            font=("Arial", 13),
            fg=fg,
            bg=self.layout.cget("bg"),
            anchor="w"
        )
        lbl.pack(pady=4, fill="x")
        comp.widget = lbl

    def _draw_rounded_button(self, text, bg, fg, radius, command, nav_target, comp=None, border_color=None, border_width=0, pressed_color=None):
        fill_color  = bg  if bg  else "#d9d9d9"
        p_color     = pressed_color if pressed_color else fill_color
        text_color  = fg  if fg  else "black"
        outline_c   = border_color if border_color else ""
        outline_w   = border_width if border_width > 0 else (1 if outline_c else 0)
        
        frame = tk.Frame(self.layout, bg=self.layout.cget("bg"))
        frame.pack(pady=10, fill="x")

        canvas = tk.Canvas(
            frame, height=42, bg=self.layout.cget("bg"),
            highlightthickness=0, bd=0, cursor="hand2"
        )
        canvas.pack(fill="x", expand=True)

        def _redraw(event, c=canvas, t=text, fc=fill_color, tc=text_color, r=radius, ol=outline_c, ow=outline_w):
            c.delete("all")
            w, h = c.winfo_width(), c.winfo_height()
            if w <= 1: w, h = event.width, event.height
            _create_rounded_rect(c, 2, 2, w - 2, h - 2, r, fill=fc, outline=ol, width=ow)
            c.create_text(w // 2, h // 2, text=t, fill=tc, font=("Arial", 12, "bold"))

        def _on_press(event, c=canvas, t=text, fc=p_color, tc=text_color, r=radius, ol=outline_c, ow=outline_w):
            _redraw(event, c, t, fc, tc, r, ol, ow)

        def _on_release(event, c=canvas, t=text, fc=fill_color, tc=text_color, r=radius, ol=outline_c, ow=outline_w):
            _redraw(event, c, t, fc, tc, r, ol, ow)
            if command: command()
            if nav_target: self.render_screen(nav_target)

        canvas.bind("<Configure>", _redraw)
        canvas.bind("<ButtonPress-1>", _on_press)
        canvas.bind("<ButtonRelease-1>", _on_release)

        if comp is not None: comp.widget = canvas
        return canvas

    def _render_button(self, comp):
        text      = comp.kwargs.get('text', '')
        comp_id   = comp.kwargs.get('comp_id')
        style     = global_styles.get(comp_id, {}) if comp_id else {}
        bg        = _get_style_bg(style)
        fg        = _get_style_fg(style)
        pressed_bg = _get_style_pressed_color(style)
        radius    = _parse_radius(style)
        bc        = _get_style_border_color(style)
        bw        = _parse_border_width(style)
        user_cmd  = comp.kwargs.get('command')
        nav_target = comp.nav_target

        if radius > 0:
            self._draw_rounded_button(text, bg, fg, radius, user_cmd, nav_target, comp, bc, bw, pressed_color=pressed_bg)
            return

        tk_bg = bg if bg else "SystemButtonFace"
        tk_fg = fg if fg else "black"
        tk_abg = pressed_bg if pressed_bg else "SystemButtonHighlight"

        def on_click(nt=nav_target, uc=user_cmd):
            if uc: uc()
            if nt: self.render_screen(nt)

        btn = tk.Button(
            self.layout, text=text, font=("Arial", 12), command=on_click,
            bg=tk_bg, fg=tk_fg, activebackground=tk_abg, relief="raised", pady=5
        )
        btn.pack(pady=10, fill="x")
        comp.widget = btn

    def _render_input(self, comp):
        """Resolve estilos no momento do render e delega ao add_input."""
        comp_id = comp.kwargs.get('comp_id')
        style   = global_styles.get(comp_id, {}) if comp_id else {}
        self.add_input(
            placeholder=comp.kwargs.get('placeholder', ''),
            input_type=comp.kwargs.get('input_type', 'text'),
            bg=_get_style_bg(style),
            fg=_get_style_fg(style),
            radius=_parse_radius(style),
            border_color=_get_style_border_color(style),
            border_width=_parse_border_width(style),
            focus_border_color=_get_style_focus_border_color(style)
        )

    # ── Legacy (sem Screen) ───────────────────────────────────────────────────

    def add_label(self, text, fg=None):
        lbl = tk.Label(
            self.layout,
            text=text,
            font=("Arial", 13),
            fg=fg if fg else "black",
            bg=self.layout.cget("bg"),
            anchor="w"
        )
        lbl.pack(pady=4, fill="x")

    def add_button(self, text, command=None, bg=None, fg=None, radius=0, border_color=None, border_width=0, pressed_color=None):
        if radius > 0:
            self._draw_rounded_button(text, bg, fg, radius, command, None, border_color=border_color, border_width=border_width, pressed_color=pressed_color)
            return
        tk_bg = bg if bg else "SystemButtonFace"
        tk_fg = fg if fg else "black"
        tk_abg = pressed_color if pressed_color else "SystemButtonHighlight"
        btn = tk.Button(
            self.layout, text=text, font=("Arial", 12), command=command,
            bg=tk_bg, fg=tk_fg, activebackground=tk_abg, relief="raised", pady=5
        )
        if border_color and border_color != "":
            btn.config(highlightbackground=border_color, highlightthickness=border_width if border_width > 0 else 1)
        btn.pack(pady=10, fill="x")

    def add_input(self, placeholder="", input_type="text", bg=None, fg=None, radius=0, border_color=None, border_width=0, focus_border_color=None):
        """Adiciona um campo de input consoante o tipo pedido."""

        # ── TEXT / PASSWORD / SEARCH ──────────────────────────────────────────
        if input_type in ("text", "password", "search"):
            frame = tk.Frame(self.layout, bg=self.layout.cget("bg"))
            frame.pack(pady=6, fill="x")

            fill_color = bg if bg else "white"
            text_color = fg if fg else "grey"
            show_char = "*" if input_type == "password" else ""
            
            ol_color = border_color if border_color is not None else "grey"
            ol_width = border_width if border_width > 0 else 1 if ol_color else 0

            if radius > 0:
                canvas = tk.Canvas(
                    frame, height=36, bg=self.layout.cget("bg"),
                    highlightthickness=0, bd=0
                )
                canvas.pack(side="left", fill="x", expand=True)

                def _redraw(event=None, c=canvas, fc=fill_color, r=radius, ol=ol_color, ow=ol_width):
                    c.delete("bg_shape")
                    if event and getattr(event, 'width', 0) > 1:
                        w, h = event.width, event.height
                    else:
                        w, h = c.winfo_width(), c.winfo_height()
                    _create_rounded_rect(c, 2, 2, w-2, h-2, r, fill=fc, outline=ol, width=ow, tags="bg_shape")
                canvas.bind("<Configure>", _redraw)

                entry = tk.Entry(
                    canvas, font=("Arial", 12), show=show_char,
                    bg=fill_color, fg=text_color, relief="flat", bd=0, highlightthickness=0
                )
                entry.place(relx=0.03, rely=0.5, relwidth=0.94, anchor="w")
            else:
                entry = tk.Entry(
                    frame, font=("Arial", 12), show=show_char,
                    bg=fill_color, fg=text_color, relief="flat", bd=1,
                    highlightbackground=ol_color if ol_color else "grey", 
                    highlightthickness=ol_width
                )
                entry.pack(side="left", fill="x", expand=True, ipady=5)

            entry.insert(0, placeholder)

            def on_focus_in(e, ent=entry, ph=placeholder):
                if focus_border_color:
                    if radius > 0:
                        _redraw(c=canvas, ol=focus_border_color)
                    else:
                        ent.config(highlightbackground=focus_border_color)
                if ent.get() == ph:
                    ent.delete(0, tk.END)
                    ent.config(fg="black")

            def on_focus_out(e, ent=entry, ph=placeholder):
                if focus_border_color:
                    if radius > 0:
                        _redraw(c=canvas, ol=ol_color)
                    else:
                        ent.config(highlightbackground=ol_color if ol_color else "grey")
                if ent.get() == "":
                    ent.insert(0, ph)
                    ent.config(fg="grey")

            entry.bind("<FocusIn>",  on_focus_in)
            entry.bind("<FocusOut>", on_focus_out)

            if input_type == "search":
                def clear_entry(ent=entry, ph=placeholder):
                    ent.delete(0, tk.END)
                    ent.insert(0, ph)
                    ent.config(fg="grey")

                clear_btn = tk.Button(
                    frame,
                    text="✕",
                    font=("Arial", 10),
                    command=clear_entry,
                    relief="flat",
                    bg="white",
                    fg="grey",
                    cursor="hand2"
                )
                clear_btn.pack(side="left", padx=(2, 0))

        # ── CHECKBOX ──────────────────────────────────────────────────────────
        elif input_type == "checkbox":
            var = tk.BooleanVar()
            cb = tk.Checkbutton(
                self.layout,
                text=placeholder,
                variable=var,
                font=("Arial", 12),
                bg=self.layout.cget("bg"),
                fg=fg if fg else "black",
                activebackground=self.layout.cget("bg"),
                anchor="w"
            )
            cb.pack(pady=6, fill="x")

        # ── RANGE (slider) ────────────────────────────────────────────────────
        elif input_type == "range":
            frame = tk.Frame(self.layout)
            frame.pack(pady=6, fill="x")

            lbl = tk.Label(
                frame,
                text=placeholder if placeholder else "Range",
                font=("Arial", 11),
                bg=self.layout.cget("bg"),
                fg=fg if fg else "black"
            )
            lbl.pack(anchor="w")

            slider = tk.Scale(
                frame,
                from_=0,
                to=100,
                orient="horizontal",
                font=("Arial", 10),
                bg=self.layout.cget("bg"),
                fg=fg if fg else "black",
                highlightthickness=0
            )
            slider.pack(fill="x")

        # ── RADIO ─────────────────────────────────────────────────────────────
        elif input_type == "radio":
            options = [o.strip() for o in placeholder.split("|")] if placeholder else ["Opção 1", "Opção 2"]
            var = tk.StringVar(value=options[0])
            frame = tk.Frame(self.layout)
            frame.pack(pady=6, fill="x")
            for opt in options:
                rb = tk.Radiobutton(
                    frame,
                    text=opt,
                    variable=var,
                    value=opt,
                    font=("Arial", 12),
                    bg=self.layout.cget("bg"),
                    fg=fg if fg else "black",
                    activebackground=self.layout.cget("bg"),
                    anchor="w"
                )
                rb.pack(fill="x")

    def run(self):
        self.root.mainloop()


# Instância única da interface
_app = AppPreview()


# ─── Public API ───────────────────────────────────────────────────────────────

def label(text, id=None, screen=None):
    """
    Adiciona um texto/título à interface.

    Args:
        text:   O texto a mostrar.
        id:     ID para aplicar estilos CSS (ex: style = \"\"\"meu_label { color: red; }\"\"\").
        screen: Screen ao qual pertence (modo multi-ecrã).
    """
    if screen is not None:
        # Estilos resolvidos no render (dentro de run()), não aqui
        comp = ComponentDef('label', text=text, comp_id=id)
        return screen._add(comp)
    else:
        # Modo legado: resolve estilos imediatamente
        load_styles_now()
        style = global_styles.get(id, {})
        fg = _get_style_fg(style)
        _app.add_label(text, fg=fg)
        return None


def button(text, id=None, command=None, screen=None):
    """
    Adiciona um botão à interface.

    Args:
        text:    O texto do botão.
        id:      ID para aplicar estilos CSS.
                 ex: style = \"\"\"meu_botao { background-color: blue; color: white; }\"\"\"
        command: Função a chamar ao clicar (modo legado sem Screen).
        screen:  Screen ao qual pertence (modo multi-ecrã).

    Returns:
        ComponentDef se screen for definido — usa-o em on_click_navigate().
    """
    if screen is not None:
        # Estilos resolvidos no render (dentro de run()), não aqui
        comp = ComponentDef('button', text=text, command=command, comp_id=id)
        return screen._add(comp)
    else:
        # Modo legado: resolve estilos imediatamente
        load_styles_now()
        style = global_styles.get(id, {})
        bg = _get_style_bg(style)
        fg = _get_style_fg(style)
        pressed_bg = _get_style_pressed_color(style)
        radius = _parse_radius(style)
        bc = _get_style_border_color(style)
        bw = _parse_border_width(style)
        _app.add_button(text, command, bg, fg, radius=radius, border_color=bc, border_width=bw, pressed_color=pressed_bg)
        return None


def inputs(placeholder="", id=None, type="text", screen=None):
    """
    Adiciona um campo de input à interface.

    Tipos suportados:
      - "text"      → caixa de texto normal
      - "password"  → texto escondido com ●●●
      - "search"    → caixa de texto com botão ✕ para limpar
      - "checkbox"  → caixinha com visto (✓)
      - "range"     → slider/barra deslizante (0-100)
      - "radio"     → botões de escolha; separa opções com | no placeholder
                      ex: inputs("Sim|Não|Talvez", type="radio")

    Args:
        id:     ID para aplicar estilos CSS.
                Suporta 'background-color' e 'backgroundcolor' (sem hífen).
        screen: Screen ao qual pertence (modo multi-ecrã).
    """
    if screen is not None:
        # Estilos resolvidos no render (dentro de run()), não aqui
        comp = ComponentDef('inputs', placeholder=placeholder, input_type=type, comp_id=id)
        return screen._add(comp)
    else:
        # Modo legado: resolve estilos imediatamente
        load_styles_now()
        style = global_styles.get(id, {})
        bg = _get_style_bg(style)
        fg = _get_style_fg(style)
        radius = _parse_radius(style)
        bc = _get_style_border_color(style)
        bw = _parse_border_width(style)
        fc = _get_style_focus_border_color(style)
        _app.add_input(placeholder=placeholder, input_type=type, bg=bg, fg=fg, radius=radius, border_color=bc, border_width=bw, focus_border_color=fc)
        return None


# Alias para quem preferir este nome
input_field = inputs


def run(start_screen=None):
    """
    Inicia a janela de preview.

    Args:
        start_screen: Screen inicial a mostrar (modo multi-ecrã).
                      Se None, mostra os componentes adicionados diretamente
                      (modo legado compatível).
    """
    load_styles_now()
    if start_screen is not None:
        _app.render_screen(start_screen)
    _app.run()

def toast(message):
    """Exibe uma mensagem flutuante temporária na interface."""
    lbl = tk.Label(
        _app.root, text=message, bg="#333333", fg="white",
        font=("Arial", 11), padx=15, pady=8
    )
    lbl.place(relx=0.5, rely=0.85, anchor="s")
    _app.root.after(2000, lbl.destroy)