import os
import asyncio
from nixagent.logger import logger
from nixagent import Agent
from nixagent.profiles import AgentFactory

try:
    from telegram import Update
    from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters
    HAS_TELEGRAM = True
except ImportError:
    HAS_TELEGRAM = False

async def _start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("NixAgent Telegram Bot Ready! Just send me a message and I'll process it.")

async def _handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message_text = update.message.text
    if not message_text:
        return
        
    await update.message.reply_text("Thinking...")
    
    agent = Agent("Primary", system_prompt="You are a capable Telegram assistant.")
    try:
        # Run synchronous nixagent.run via thread executor naturally
        loop = asyncio.get_event_loop()
        reply = await loop.run_in_executor(None, agent.run, message_text)
        await update.message.reply_text(str(reply))
    except Exception as e:
        await update.message.reply_text(f"Error: {e}")

def run_telegram_bot() -> None:
    if not HAS_TELEGRAM:
        print("python-telegram-bot not installed")
        return
        
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token or token == "your_bot_token":
        print("TELEGRAM_BOT_TOKEN not configured in .env")
        return
        
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("start", _start_command))
    app.add_handler(CommandHandler("help", _start_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, _handle_message))
    
    logger.info("Telegram Bot Started")
    print("NixAgent Telegram bot running. Press Ctrl+C to stop.")
    app.run_polling()
