from nixagent import Agent

class AgentFactory:
    PROFILES = {
        "CodeGenerator": "You are a senior software engineer. Write, refactor, and generate robust code.",
        "Analyzer": "You are an analytical agent. Analyze code, data, and logic flows to provide deep insights.",
        "Researcher": "You are a research agent. Gather information and synthesize complex findings.",
        "SystemAdmin": "You are a system administrator. Design stable, secure, and performant infrastructure.",
        "Debugger": "You are a debugger. Investigate issues, trace stacks, and fix bugs systematically.",
        "General": "You are a general-purpose highly capable AI."
    }

    @classmethod
    def create_agent(cls, profile_name: str) -> Agent:
        """Create a specialized Agent from a profile name."""
        prompt = cls.PROFILES.get(profile_name)
        if not prompt:
            return None
        return Agent(name=profile_name, system_prompt=prompt)
