from fastapi import FastAPI, BackgroundTasks, HTTPException
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Any, Optional, List
import uuid
import uvicorn
from nixagent import Agent
from nixagent.profiles import AgentFactory
from nixagent.logger import logger
from nixagent.storage import storage_db

app = FastAPI(title="NixAgent REST API")

class TaskSubmitRequest(BaseModel):
    task: str = Field(..., description="Task description")
    priority: str = Field(default="normal", description="Priority: high, normal, low")
    callback_url: Optional[str] = Field(default=None, description="Webhook URL for completion callback")
    agent_profiles: List[str] = Field(default_factory=list, description="Specific agent profiles to use")

class TaskStatusResponse(BaseModel):
    id: str
    status: str
    started_at: Optional[datetime] = None
    result: Any = None
    error: Optional[str] = None

# Global dict to store tasks as a lightweight DB until Phase 3 Storage migration
TASKS_DB = {}

def execute_agent_task(task_id: str, request: TaskSubmitRequest):
    logger.info(f"Background task {task_id} started")
    TASKS_DB[task_id]["status"] = "running"
    TASKS_DB[task_id]["started_at"] = datetime.utcnow()
    storage_db.update_task(task_id, status="running")
    
    try:
        profiles = request.agent_profiles
        if profiles:
            coordinator = Agent("Coordinator", system_prompt="Coordinate the task efficiently.")
            for p in profiles:
                sub = AgentFactory.create_agent(p)
                if sub: coordinator.register_collaborator(sub)
            reply = coordinator.run(request.task)
        else:
            agent = Agent("Primary", system_prompt="You are a highly capable general assistant.")
            reply = agent.run(request.task)
            
        TASKS_DB[task_id]["status"] = "completed"
        TASKS_DB[task_id]["result"] = reply
        storage_db.update_task(task_id, status="completed", result=reply)
        
        # Optionally hit the webhook callback here
        if request.callback_url:
            import requests
            try:
                requests.post(request.callback_url, json={"task_id": task_id, "status": "completed", "result": reply})
            except Exception as e:
                logger.error(f"Callback webhook failed: {e}")
                
    except Exception as e:
        TASKS_DB[task_id]["status"] = "failed"
        TASKS_DB[task_id]["error"] = str(e)
        storage_db.update_task(task_id, status="failed", error=str(e))
        logger.error(f"Task {task_id} failed: {e}")

@app.post("/api/v1/tasks")
async def submit_task(request: TaskSubmitRequest, background_tasks: BackgroundTasks):
    task_id = str(uuid.uuid4())
    TASKS_DB[task_id] = {
        "id": task_id,
        "status": "pending",
        "started_at": None,
        "result": None,
        "error": None
    }
    
    background_tasks.add_task(execute_agent_task, task_id, request)
    storage_db.save_task(task_id, request.task, request.priority)
    return {"task_id": task_id, "status": "pending", "message": "Task submitted for background execution."}

@app.get("/api/v1/tasks/{task_id}", response_model=TaskStatusResponse)
async def get_task_status(task_id: str):
    info = TASKS_DB.get(task_id)
    if not info:
        raise HTTPException(status_code=404, detail=f"Task not found: {task_id}")
    return info

@app.get("/api/v1/tasks")
async def list_tasks():
    return list(TASKS_DB.values())

@app.get("/api/v1/health")
async def health_check():
    return {"status": "ok", "agent": "NixAgent Orchestrator", "tasks": len(TASKS_DB)}

def serve_api(host: str = "0.0.0.0", port: int = 8000):
    logger.info(f"Starting NixAgent API on {host}:{port}")
    uvicorn.run("nixagent.api:app", host=host, port=port, reload=False)
