import os
from datetime import datetime
from sqlalchemy import create_engine, Column, String, DateTime, Text, JSON
from sqlalchemy.orm import declarative_base, sessionmaker

Base = declarative_base()

class TaskRun(Base):
    __tablename__ = 'tasks'
    id = Column(String, primary_key=True)
    status = Column(String, default="pending")
    priority = Column(String, default="normal")
    task_description = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    result = Column(JSON, nullable=True)
    error = Column(Text, nullable=True)

class Storage:
    def __init__(self, db_path="nixagent.db"):
        self.engine = create_engine(f"sqlite:///{db_path}", connect_args={"check_same_thread": False})
        Base.metadata.create_all(self.engine)
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)

    def save_task(self, task_id, task_description, priority="normal"):
        db = self.SessionLocal()
        task = TaskRun(id=task_id, task_description=task_description, priority=priority)
        db.add(task)
        db.commit()
        db.close()

    def update_task(self, task_id, status=None, result=None, error=None):
        db = self.SessionLocal()
        task = db.query(TaskRun).filter(TaskRun.id == task_id).first()
        if task:
            if status: task.status = status
            if result is not None: task.result = result
            if error is not None: task.error = error
            if status in ["completed", "failed"]: task.completed_at = datetime.utcnow()
            db.commit()
        db.close()
        
storage_db = Storage()
