import time
import os
import re
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
import random
import json
import shutil
import stackapi
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont
from stackapi import StackAPI
from moviepy import VideoFileClip, AudioFileClip, ImageClip, CompositeVideoClip, video, concatenate_videoclips, clips_array, TextClip

class free_youtube_uploader:

    @staticmethod
    def ai_chat(prompt):
        model = GPT4All("Meta-Llama-3-8B-Instruct.Q4_0.gguf") # downloads / loads a 4.66GB LLM
        with model.chat_session():
            text = model.generate(prompt, max_tokens=1024)
        
        return text

    @staticmethod
    def stackapi():
        #Retrieve The Text From Stack Overflow:
        SITE = StackAPI('stackoverflow')
        SITE.max_pages=1
        SITE.page_size=100
        
        #Create Anwsers
        time1 = random.randrange(1262304000, 1696118400)
        time2 = random.randrange(time1, 1696118400)
        question = SITE.fetch('questions', Key='4qArFpyh*TIw4)Man)R)7Q((', client_id=29098, fromdate=time1, todate=time2, max=1, pagesize=1, max_pages=1, sort='votes', filter='!9YdnSIN*P') #filter='quota_max'
        
        return question

    @staticmethod
    def text_to_video(text, t, clip_path, font_path, duration, font_size):
        
        clip = VideoFileClip(clip_path, audio=False).with_duration(duration)
        txt_clip = TextClip(font_path, text, size=(1920, 1080), text_align='center', font_size=font_size, method="caption")
        txt_clip = txt_clip.with_position('center').with_duration(duration)
        video = CompositeVideoClip([clip, txt_clip])
        
        #Calculate Timestamp
        t += duration

        a = [video, t]
        return a

    @staticmethod
    def txt_to_img(t, i, img_folder, font_path):
    
        im = Image.new("RGB", (1920, 1080), "#fff")
        box = ((0, 0, 1920, 1080))
        draw = ImageDraw.Draw(im)
        #draw.rectangle(box, outline="#000")

        text = t
        font_size = 100
        size = None
        while (size is None or size[0] > box[2] - box[0] or size[1] > box[3] - box[1]) and font_size > 0:
            font = ImageFont.truetype(font_path, font_size)
            #size = font.getsize_multiline(text)
            dummy_img = Image.new("RGB", (1, 1))
            draw = ImageDraw.Draw(dummy_img)
            bbox = draw.multiline_textbbox((0, 0), text, font=font)
            size = (bbox[2] - bbox[0], bbox[3] - bbox[1])
            font_size -= 1
        draw.multiline_text((box[0], box[1]), text, "#000", font)
        path = img_folder + str(i) + ".png"
        im.save(path)

    @staticmethod
    def trend_script():
        # GET TREND #
        pytrend = TrendReq(hl='en-US', tz=360)
        trends = pytrend.trending_searches()

        rand1=random.Random()
        num = rand1.randint(0, len(trends[0]))

        return trends[0][num]

    @staticmethod
    def decide_topic():
        #Decide Topic Randomly:
        topics = ["programming", "python", "web Development", "html", "Computers", "Viruses", "Hacking", "Gamming"]
        rand1=random.Random()
        num = rand1.randint(0, len(topics))
        topic = topics[num - 1]

        return topic

    @staticmethod
    def upload_quiz(driver, question, a1, a2, a3, a4, n):
        #   UPLOAD   #
        driver.get("https://www.youtube.com/@TheKnowledgeBase69/community")
        sleep(5)
            
        #quiz:    
        driver.find_element(By.CSS_SELECTOR, "span.style-scope:nth-child(4) > ytd-button-renderer:nth-child(1) > yt-button-shape:nth-child(1) > button:nth-child(1)").click()
        
        #Question:
        driver.find_element(By.ID, "contenteditable-root").send_keys(question)

        #Add Anwsers:
        driver.find_element(By.CSS_SELECTOR, "#quiz-attachment > div.button-container.style-scope.ytd-backstage-quiz-editor-renderer > yt-button-renderer > yt-button-shape > button").click()
        driver.find_element(By.CSS_SELECTOR, "#quiz-attachment > div.button-container.style-scope.ytd-backstage-quiz-editor-renderer > yt-button-renderer > yt-button-shape > button").click()

        #anwser 1:
        driver.find_element(By.XPATH, "/html/body/ytd-app/div[1]/ytd-page-manager/ytd-browse/ytd-two-column-browse-results-renderer/div[1]/ytd-section-list-renderer/div[2]/ytd-backstage-items/ytd-item-section-renderer/div[1]/ytd-comments-header-renderer/div[7]/ytd-backstage-post-dialog-renderer/div[2]/ytd-commentbox/div[2]/div/ytd-backstage-quiz-editor-renderer/div[1]/div[1]/div[1]/tp-yt-paper-input-container/div[2]/div/tp-yt-iron-autogrow-textarea/div[2]/textarea").send_keys(a1)

        #anwser 2:
        driver.find_element(By.XPATH, "/html/body/ytd-app/div[1]/ytd-page-manager/ytd-browse/ytd-two-column-browse-results-renderer/div[1]/ytd-section-list-renderer/div[2]/ytd-backstage-items/ytd-item-section-renderer/div[1]/ytd-comments-header-renderer/div[7]/ytd-backstage-post-dialog-renderer/div[2]/ytd-commentbox/div[2]/div/ytd-backstage-quiz-editor-renderer/div[1]/div[2]/div[1]/tp-yt-paper-input-container/div[2]/div/tp-yt-iron-autogrow-textarea/div[2]/textarea").send_keys(a2)

        #anwser 3:
        driver.find_element(By.XPATH, "/html/body/ytd-app/div[1]/ytd-page-manager/ytd-browse/ytd-two-column-browse-results-renderer/div[1]/ytd-section-list-renderer/div[2]/ytd-backstage-items/ytd-item-section-renderer/div[1]/ytd-comments-header-renderer/div[7]/ytd-backstage-post-dialog-renderer/div[2]/ytd-commentbox/div[2]/div/ytd-backstage-quiz-editor-renderer/div[1]/div[3]/div[1]/tp-yt-paper-input-container/div[2]/div/tp-yt-iron-autogrow-textarea/div[2]/textarea").send_keys(a3)

        #anwser 4:
        driver.find_element(By.XPATH, "/html/body/ytd-app/div[1]/ytd-page-manager/ytd-browse/ytd-two-column-browse-results-renderer/div[1]/ytd-section-list-renderer/div[2]/ytd-backstage-items/ytd-item-section-renderer/div[1]/ytd-comments-header-renderer/div[7]/ytd-backstage-post-dialog-renderer/div[2]/ytd-commentbox/div[2]/div/ytd-backstage-quiz-editor-renderer/div[1]/div[4]/div[1]/tp-yt-paper-input-container/div[2]/div/tp-yt-iron-autogrow-textarea/div[2]/textarea").send_keys(a4)

        #Select Correct Anwser:
        if n == 1:
            driver.find_element(By.CSS_SELECTOR, "div.quiz-option:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > yt-icon-button:nth-child(1) > button:nth-child(1)").click()
        elif n == 2:
            driver.find_element(By.CSS_SELECTOR, "div.quiz-option:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > yt-icon-button:nth-child(1) > button:nth-child(1)").click()
        elif n == 3:
            driver.find_element(By.CSS_SELECTOR, "div.quiz-option:nth-child(3) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > yt-icon-button:nth-child(1) > button:nth-child(1)").click()
        elif n == 4:
            driver.find_element(By.CSS_SELECTOR, "div.quiz-option:nth-child(4) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > yt-icon-button:nth-child(1) > button:nth-child(1)").click()
        
        #Publish:
        WebDriverWait(driver, 100).until(EC.element_to_be_clickable((By.XPATH, "//*[@id='submit-button']/yt-button-shape/button"))).click()
            
        sleep(5)
        
    @staticmethod
    def upload_img(driver, path):
        driver.get("https://www.youtube.com/@TheKnowledgeBase69/community")
        try:
            #Image:
            WebDriverWait(driver, 100).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "span.ytd-backstage-post-dialog-renderer:nth-child(1) > ytd-button-renderer:nth-child(1) > yt-button-shape:nth-child(1) > button:nth-child(1)"))).click()

            sleep(1)
            
            #DRag'n'drop:
            elem = driver.find_element(By.XPATH, "/html/body/ytd-app/div[1]/ytd-page-manager/ytd-browse/ytd-two-column-browse-results-renderer/div[1]/ytd-section-list-renderer/div[2]/ytd-backstage-items/ytd-item-section-renderer/div[1]/ytd-comments-header-renderer/div[7]/ytd-backstage-post-dialog-renderer/div[2]/ytd-commentbox/div[2]/div/div[2]/tp-yt-paper-input-container/div[2]/div/div[3]/ytd-backstage-multi-image-select-renderer/div[1]/input")
            driver.execute_script("arguments[0].scrollIntoView();", elem)
            elem.send_keys(path)
            
            sleep(1)

            #Publish:                                                                          
            WebDriverWait(driver, 100).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#submit-button > yt-button-shape:nth-child(1) > button:nth-child(1)"))).click()
            
            sleep(5)
        except:
            pass

    @staticmethod
    def create_video_trend(script, audio_path, video_clip_path, trend_video_path):
        #Text to Speech:
        language = 'en' 
        myobjAnwser = gTTS(text=script, lang=language, slow=False)
        myobjAnwser.save(audio_path)
            
        clip = VideoFileClip(video_clip_path)
        audioclip = AudioFileClip(audio_path)
        duration = audioclip.duration
        videoclip = clip.subclipped(0, duration)

        new_audioclip = CompositeAudioClip([audioclip])
        videoclip.audio = new_audioclip
        videoclip.write_videofile(trend_video_path, threads=4, logger=None, ffmpeg_params=['-crf','18', '-aspect', '9:16'])

    @staticmethod
    def create_youtube_quiz(driver):
            topic = free_youtube_uploader.decide_topic()

            text = free_youtube_uploader.ai_chat("short quiz about " + topic + " with 3 fake anwsers and one real one. Include 1 question and 4 answers (for a total of FIVE senteces) seperated by the symbol |, have the question be first and the real anwser be second, include only the question and anwers and nothing else")

            words = text.split()
            t2 = text.split("|")
            
            #Seperate Question and Anwsers:
            question = t2[0]
            real = t2[1]
            fake1 = t2[2]
            fake2 = t2[3]
            fake3 = t2[4]
            
            #Decide order of anwsers randomly
            a1 = ""
            a2 = ""
            a3 = ""
            a4 = ""
            rand=random.Random()
            n = rand.randint(1, 4)
            
            if n == 1:
                a1 = real
                a2 = fake1
                a3 = fake2
                a4 = fake3
            if n == 2:
                a1 = fake1
                a2 = real
                a3 = fake2
                a4 = fake3
            if n == 3:
                a1 = fake1
                a2 = fake2
                a3 = real
                a4 = fake3
            if n == 4:
                a1 = fake1
                a2 = fake2
                a3 = fake3
                a4 = real
            
            free_youtube_uploader.upload_quiz(driver, question, a1, a2, a3, a4, n)

    @staticmethod
    def create_youtube_meme(driver, img_path):
            text = free_youtube_uploader.ai_chat("Random short caption for a meme about Programming that you never told before, include only the caption and nothing else")

            #Divide Caption to Fit Image
            i = 0
            t = ""
            words = text.split()
            for word in words:
                t += word + " "
                i += 1
                if i == 4:
                    i = 0
                    t += "\n"

            #Decide Wich Image to Use Randomy
            n = random.randrange(1,10)
             
            #Delete Previous meme:
            try:
                os.remove(img_path) 
            except:
                pass
            
            # Open an Image
            path = img_path + ".jpg"
             
            # Call draw Method to add 2D graphics in an image
            I1 = ImageDraw.Draw(img)

            # Add Text to an image
            font = ImageFont.truetype("impact.ttf", 125)
            I1.text((1500, 1500), t, (255, 255, 255), font, None, 5, "left")
             
            # Save the edited image
            img.save(img_path)
            
            free_youtube_uploader.upload_img(driver, img_path)

    @staticmethod
    def create_youtube_trend(driver):
            trend1 = free_youtube_uploader.trend_script()

            script = free_youtube_uploader.ai_chat(trend1)

            free_youtube_uploader.create_video_trend(script)
            
            free_youtube_uploader.upload_video(driver, trend1, script)
    
    @staticmethod
    def create_info_video(driver, video_path, img_folder, clip1_path, img, clip2_path, font_path, out_folder, out_video_path):    
        
        t = 0
        
        #Delete Previous Folder:
        if os.path.exists(video_path):
            shutil.rmtree(video_path) 
            
        #Retrieve The Text From Stack Overflow:
        s = 0
        k = 0
        while s == 0 and k < 10:
            try:
                SITE = StackAPI('stackoverflow')
                s = 1
            except:
                k += 1
                
        SITE.max_pages=1
        SITE.page_size=100
        
        #Create Anwsers
        time1 = random.randrange(1262304000, 1696118400)
        time2 = random.randrange(time1, 1696118400)
        question = SITE.fetch('questions', Key='4qArFpyh*TIw4)Man)R)7Q((', client_id=29098, fromdate=time1, todate=time2, max=1, pagesize=1, max_pages=1, sort='votes', filter='!9YdnSIN*P')
        
        #Only proceed if the question has at least one anwser
        quest = []
        cont = 0
        for n in question['items']:
            quest = n
            if quest["is_answered"] == False:
                cont = 1
            
        if cont == 1:
            exit
            
        #Make Sure Title Isn't to long for youtube
        titleQuest = quest['title']
        titleQuest = titleQuest[0:100]
            
        #Get Question Text and anwsers
        question = quest['body']
        question_id = quest['question_id']
        top_answer = SITE.fetch('questions/' + str(question_id) + '/answers', order = 'desc', sort='votes', filter='withbody')
        
        #Format the Question Title:
        titleQuest2 = re.sub(r'\<a.+>', '', titleQuest)
        titleQuest2 = titleQuest2.replace('`', '"')
        question2 = re.sub(r'\<a.+>', '', question)
        question2 = question2.replace('`', '"')
        
        txt_clips = []
        
        # ADD QUESTION TITLE TO VIDEO #
        a = free_youtube_uploader.text_to_video(titleQuest2, t, clip2_path, font_path, 2, 100)
        txt_clips.append(a[0])
        t = a[1]
        
        # ADD QUESTION TEXT TO VIDEO #
        a = free_youtube_uploader.text_to_video(question, t, clip1_path, font_path, 30, 35)
        txt_clips.append(a[0])
        t = a[1]
         
        # ADD ANWSERS TO VIDEO #
            
        for r, an in zip(range(10), top_answer['items']):
            
            #Get Anwser Text
            AnwserText = an['body']
            
            #Format Answer Text
            AnwserText = re.sub(r'\<a.+>', '', AnwserText)
            AnwserText = AnwserText.replace('`', '"')
            anwserText1 = AnwserText
            
            #Create Anwser Title
            titleAnwser = "Anwser " + str(r + 1) + ": "

            # ADD ANSWER TITLE TO VIDEO #
            a = free_youtube_uploader.text_to_video(titleAnwser, t, clip2_path, font_path, 2, 100)
            txt_clips.append(a[0])
            t = a[1]
            
            # ADD ANSWER TEXT TO VIDEO #
            a = free_youtube_uploader.text_to_video(AnwserText, t, clip1_path, font_path, 30, 35)
            txt_clips.append(a[0])
            t = a[1]
         
        #Put all clips together
        final_video = concatenate_videoclips(txt_clips)
        final_video.write_videofile(out_video_path, fps=24)
            
        #Format Video Title
        titleQuest2 = titleQuest2.replace('&quot;', '"')
        titleQuest2 = titleQuest2.replace('&#vide39;', '"')

        #   UPLOAD   #
        free_youtube_uploader.upload_video(driver, titleQuest2, out_video_path)

    @staticmethod
    def create_rot_short(driver, rot_video_path):
            
            k = 0
            script = free_youtube_uploader.ai_chat("Random Interesting Reddid Post With around 120 words, include only the reddit post text nothing else inclunding quotation marks", k)
            title = free_youtube_uploader.ai_chat("title for this script: " + script + ", include only the title nothing else", k)
            
            dur_final = 0
            clips, dur_final = free_youtube_uploader.create_video_Text(script)
            
            vid = concatenate_videoclips(clips)
            
            vid.duration = dur_final
            vid.write_videofile(rot_video_path, threads=4, ffmpeg_params=['-crf','18', '-aspect', '9:16'])
            
            title = script[0:90]
            
            free_youtube_uploader.upload_video(driver, title, script)

    @staticmethod
    def upload_video(driver, title, path):
        
        try:
            
            #Open Youtube Page
            driver.get("https://www.youtube.com/upload")
            
            #Upload Video
            time.sleep(5)
            driver.find_element(By.XPATH, "//input[@type='file']").send_keys(r"" + path + "")
            
            time.sleep(2)

            #Add Title
            element = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "textbox")))
            element.click()
            element.send_keys(Keys.CONTROL + "a")
            element.send_keys(Keys.BACKSPACE)
            element.send_keys(title)
        
            try: #Not Made For Kids Button
                driver.find_element(By.CSS_SELECTOR , "tp-yt-paper-radio-button.ytkc-made-for-kids-select:nth-child(2) > div:nth-child(1)").click()
            except:
                pass    
            
            #Next Button
            WebDriverWait(driver, 2).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='next-button']/ytcp-button-shape/button"))).click()
            WebDriverWait(driver, 2).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='next-button']/ytcp-button-shape/button"))).click()
            WebDriverWait(driver, 2).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='next-button']/ytcp-button-shape/button"))).click()  
            time.sleep(5)
            
            try:
                WebDriverWait(driver, 2).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/ytcp-uploads-dialog/tp-yt-paper-dialog/div/ytcp-animatable[2]/div/div[2]/ytcp-button[3]/ytcp-button-shape/button"))).click()
            except:
                pass
            
            #Publish Button
            try:
                WebDriverWait(driver, 2).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='next-button']/ytcp-button-shape/button"))).click()
            except:
                pass
                time.sleep(1)
            try: #Publish Anyway
                WebDriverWait(driver, 2).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/ytcp-prechecks-warning-dialog/ytcp-dialog/tp-yt-paper-dialog/div[3]/div/ytcp-button[1]/ytcp-button-shape/button"))).click()
            except:
                pass
                
            #Wait for Video to load
            time.sleep(100)

            #Click Close Window Button
            WebDriverWait(driver, 2).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/ytcp-uploads-still-processing-dialog/ytcp-dialog/tp-yt-paper-dialog/div[3]/ytcp-button/ytcp-button-shape/button"))).click()
            time.sleep(3)
        except:
            pass
