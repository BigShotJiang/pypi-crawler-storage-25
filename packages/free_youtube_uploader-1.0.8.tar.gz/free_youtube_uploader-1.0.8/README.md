Automated YouTube content creation and upload system built in Python. The script generates videos, quizzes, memes, and trend-based content using APIs and AI-generated text. It retrieves data from Stack Overflow, converts text into video using MoviePy, and creates images with PIL. Selenium is used to automate YouTube uploads and community posts, including quizzes and image posts. The system is designed for scalable, hands-free content production with randomized topics and formats.

Installation:

pip install free_youtube_uploader

1 - Install required Python libraries: pip install selenium moviepy pillow stackapi gtts pytrends
2 - (Optional) Install FFmpeg (required by MoviePy): https://ffmpeg.org/download.html, Add to PATH
3 - Import: from free_youtube_uploader.free_youtube_uploader import free_youtube_uploader

create_info_video(driver, video_path, img_folder, clip1_path, img, clip2_path, font_path, out_folder, out_video_path)
Generates a full video from a Stack Overflow question and uploads it.

bot.create_info_video(driver,
    "temp/video/",
    "temp/images/",
    "clips/background1.mp4",
    None,
    "clips/background2.mp4",
    "fonts/arial.ttf",
    "output/",
    "output/final.mp4"
)

create_youtube_quiz(driver)
Generates and posts a quiz automatically.

create_youtube_meme(driver, img_path)
Creates and uploads a meme.

create_youtube_trend(driver)
Generates and uploads a trending video.

create_rot_short(driver, rot_video_path)
Creates a Reddit-style short and uploads it.

upload_video(driver, title, path)
Uploads a video manually.

bot.upload_video(driver, "My Video Title", "output/video.mp4")

upload_img(driver, path)
Uploads an image post.

upload_quiz(driver, question, a1, a2, a3, a4, n)
Uploads a custom quiz.

bot.upload_quiz(driver,
    "What is Python?",
    "A programming language",
    "A snake",
    "A car brand",
    "A game",
    1
)

create_video_trend(script, audio_path, video_clip_path, trend_video_path)
Creates a video from a script.

bot.create_video_trend(
    "This is a trending topic explanation",
    "audio.mp3",
    "clips/bg.mp4",
    "output/trend.mp4"
)