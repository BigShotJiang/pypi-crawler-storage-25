from yta_editor_frame.frame.resource.abstract import FrameResourceABC
from yta_editor_frame.frame.resource.types import FrameResourceType


class GPUTextureFrameResource(
    FrameResourceABC
):
    """
    A frame resource based on a texture.

    The `.frame` attribute is a `moderngl.Texture`.
    """
    
    @property
    def width(
        self
    ) -> int:
        return self.frame.width
    
    @property
    def height(
        self
    ) -> int:
        return self.frame.height
    
    @property
    def format(
        self
    ) -> str:
        return self.frame.dtype
    
    @property
    def type(
        self
    ) -> FrameResourceType:
        return FrameResourceType.GPU

    def __init__(
        self,
        frame: 'moderngl.Texture'
    ):
        self.frame: 'moderngl.Texture' = frame
        """
        The `frame` itself, as a `moderngl.Texture`.
        """

    def release(
        self,
        render_context: 'RenderContext'
    ):
        render_context.gpu.texture.release(self.frame)

    # TODO: Untested
    def copy(
        self,
        # TODO: Maybe 'render_context' instead (?)
        opengl_context: 'moderngl.Context'
    ) -> 'GPUTextureFrameResource':
        """
        Get a copy of this frame resource.
        """
        copy = opengl_context.texture(
            size = self.frame.size,
            components = self.frame.components,
            dtype = self.frame.dtype,
        )
        opengl_context.copy_texture(self.frame, copy)

        return GPUTextureFrameResource(copy)
        