"""Native DashScope STT service integration for Pipecat."""

from __future__ import annotations

import asyncio
import os
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from dashscope.audio.asr import Recognition
from loguru import logger

from pipecat.frames.frames import ErrorFrame, Frame, TranscriptionFrame
from pipecat.services.settings import NOT_GIVEN, STTSettings, _NotGiven, is_given
from pipecat.services.stt_service import SegmentedSTTService
from pipecat.transcriptions.language import Language, resolve_language
from pipecat.utils.time import time_now_iso8601
from pipecat.utils.tracing.service_decorators import traced_stt

DEFAULT_DASHSCOPE_STT_MODEL = "paraformer-realtime-v1"


def language_to_dashscope_stt_language(language: Language) -> str | None:
    language_map = {
        Language.ZH: "zh",
        Language.ZH_CN: "zh",
        Language.EN: "en",
        Language.EN_US: "en",
        Language.EN_GB: "en",
        Language.JA: "ja",
        Language.KO: "ko",
        Language.DE: "de",
        Language.FR: "fr",
        Language.RU: "ru",
        Language.ES: "es",
    }
    return resolve_language(language, language_map, use_base_code=True)


@dataclass
class DashScopeSTTSettings(STTSettings):
    phrase_id: str | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    disfluency_removal_enabled: bool | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    diarization_enabled: bool | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    speaker_count: int | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    timestamp_alignment_enabled: bool | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    special_word_filter: str | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    audio_event_detection_enabled: bool | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)


class DashScopeSTTService(SegmentedSTTService):
    """Segmented STT service backed by DashScope's native ASR Recognition API."""

    Settings = DashScopeSTTSettings
    _settings: Settings

    def __init__(
        self,
        *,
        api_key: str | None = None,
        model: str | None = None,
        sample_rate: int | None = None,
        settings: Settings | None = None,
        **kwargs,
    ) -> None:
        default_settings = self.Settings(
            model=DEFAULT_DASHSCOPE_STT_MODEL,
            language=None,
            phrase_id=None,
            disfluency_removal_enabled=None,
            diarization_enabled=None,
            speaker_count=None,
            timestamp_alignment_enabled=None,
            special_word_filter=None,
            audio_event_detection_enabled=None,
        )
        if model is not None:
            default_settings.model = model
        if settings is not None:
            default_settings.apply_update(settings)

        super().__init__(sample_rate=sample_rate, settings=default_settings, **kwargs)

        self._api_key = api_key or os.getenv("DASHSCOPE_API_KEY")
        if not self._api_key:
            raise ValueError(
                "DashScope API key is required. Pass api_key=... or set DASHSCOPE_API_KEY."
            )

    def language_to_service_language(self, language: Language) -> str | None:
        return language_to_dashscope_stt_language(language)

    @traced_stt
    async def _handle_transcription(self, transcript: str, is_final: bool):
        return None

    async def run_stt(self, audio: bytes):
        tmp_path: Path | None = None
        try:
            await self.start_processing_metrics()
            tmp_path = await self._write_temp_wav(audio)
            result = await asyncio.to_thread(self._transcribe_file, tmp_path)
            await self.stop_processing_metrics()

            text = self._extract_text(result).strip()
            if not text:
                logger.warning(f"{self}: received empty transcription from DashScope")
                return

            await self._handle_transcription(text, True)
            yield TranscriptionFrame(text, self._user_id, time_now_iso8601(), result=result)
        except Exception as e:
            yield ErrorFrame(error=f"Unknown error occurred: {e}")
        finally:
            if tmp_path is not None:
                tmp_path.unlink(missing_ok=True)

    async def _write_temp_wav(self, audio: bytes) -> Path:
        def _write() -> Path:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as handle:
                handle.write(audio)
                return Path(handle.name)

        return await asyncio.to_thread(_write)

    def _transcribe_file(self, path: Path):
        effective_sample_rate = self.sample_rate or self._init_sample_rate
        recognition = Recognition(
            model=self._settings.model,
            callback=None,
            format="wav",
            sample_rate=effective_sample_rate,
            api_key=self._api_key,
        )

        kwargs = {}
        for key in (
            "phrase_id",
            "disfluency_removal_enabled",
            "diarization_enabled",
            "speaker_count",
            "timestamp_alignment_enabled",
            "special_word_filter",
            "audio_event_detection_enabled",
        ):
            value = getattr(self._settings, key)
            if is_given(value) and value is not None:
                kwargs[key] = value

        return recognition.call(str(path), **kwargs)

    @staticmethod
    def _extract_text(result) -> str:
        sentence = result.get_sentence()
        if isinstance(sentence, dict):
            return sentence.get("text", "")
        if isinstance(sentence, list):
            return " ".join(item.get("text", "") for item in sentence if item.get("text"))
        return ""
