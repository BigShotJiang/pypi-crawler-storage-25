from __future__ import annotations

import asyncio
import base64
import os
import threading
from dataclasses import dataclass, field
from typing import Any

import dashscope
import httpx
from dashscope import MultiModalConversation
from dashscope.audio.qwen_tts_realtime import (
    AudioFormat as QwenRealtimeAudioFormat,
)
from dashscope.audio.qwen_tts_realtime import (
    QwenTtsRealtime,
    QwenTtsRealtimeCallback,
)
from dashscope.audio.tts_v2 import AudioFormat as TTSV2AudioFormat
from dashscope.audio.tts_v2 import SpeechSynthesizer
from loguru import logger

from pipecat.frames.frames import ErrorFrame, TTSAudioRawFrame
from pipecat.services.settings import NOT_GIVEN, TTSSettings, _NotGiven, is_given
from pipecat.services.tts_service import TTSService
from pipecat.utils.tracing.service_decorators import traced_tts


def _resolve_api_key(api_key: str | None) -> str:
    resolved = api_key or os.getenv("DASHSCOPE_API_KEY")
    if not resolved:
        raise ValueError("DashScope API key is required. Pass api_key=... or set DASHSCOPE_API_KEY.")
    return resolved


def _decode_base64_audio(data: str | None) -> bytes:
    if not data:
        return b""
    return base64.b64decode(data)


def _extract_url_audio(url: str | None) -> bytes:
    if not url:
        return b""
    with httpx.Client(follow_redirects=True, timeout=30.0) as client:
        response = client.get(url)
        response.raise_for_status()
        return response.content


def _require_text_setting(settings: TTSSettings, *, field_name: str, service_name: str) -> str:
    value = getattr(settings, field_name, NOT_GIVEN)
    if not is_given(value) or value is None:
        raise ValueError(f"{service_name} requires explicit settings.{field_name}.")
    if isinstance(value, str) and not value.strip():
        raise ValueError(f"{service_name} settings.{field_name} must not be empty.")
    return value


def _raise_for_dashscope_error(response: Any, *, operation: str) -> None:
    status_code = getattr(response, "status_code", 200)
    try:
        status_code_int = int(status_code)
    except (TypeError, ValueError):
        status_code_int = None

    if status_code_int == 200:
        return

    message = getattr(response, "message", "Unknown DashScope error")
    code = getattr(response, "code", "")
    request_id = getattr(response, "request_id", "")
    request_id_suffix = f", request_id={request_id}" if request_id else ""
    error = f"DashScope {operation} failed ({status_code} {code}): {message}{request_id_suffix}"
    logger.error(error)
    raise RuntimeError(error)


class _BaseDashScopeTTSService(TTSService):
    def __init__(
        self,
        *,
        api_key: str | None = None,
        sample_rate: int,
        settings: TTSSettings,
        **kwargs,
    ) -> None:
        super().__init__(
            sample_rate=sample_rate,
            push_start_frame=True,
            push_stop_frames=True,
            settings=settings,
            **kwargs,
        )
        self._api_key = _resolve_api_key(api_key)

    @property
    def _effective_sample_rate(self) -> int:
        return self.sample_rate or self._init_sample_rate

    def can_generate_metrics(self) -> bool:
        return True

    async def _audio_frames_from_bytes(self, audio: bytes, context_id: str):
        if audio:
            yield TTSAudioRawFrame(
                audio=audio,
                sample_rate=self._effective_sample_rate,
                num_channels=1,
                context_id=context_id,
            )


@dataclass
class DashScopeTTSV2Settings(TTSSettings):
    model: str | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    volume: int | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    speech_rate: float | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    pitch_rate: float | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    seed: int | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    instruction: str | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    language_hints: list[str] | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    additional_params: dict[str, Any] | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)


class DashScopeTTSV2Service(_BaseDashScopeTTSService):
    """TTS service backed by DashScope ``audio.tts_v2.SpeechSynthesizer``."""

    Settings = DashScopeTTSV2Settings
    _settings: Settings

    def __init__(
        self,
        *,
        api_key: str | None = None,
        sample_rate: int | None = None,
        settings: Settings | None = None,
        **kwargs,
    ) -> None:
        default_settings = self.Settings(
            model=NOT_GIVEN,
            voice=NOT_GIVEN,
            language=None,
            volume=50,
            speech_rate=1.0,
            pitch_rate=1.0,
            seed=0,
            instruction=None,
            language_hints=None,
            additional_params=None,
        )
        if settings is not None:
            default_settings.apply_update(settings)
        default_settings.model = _require_text_setting(
            default_settings,
            field_name="model",
            service_name=self.__class__.__name__,
        )
        default_settings.voice = _require_text_setting(
            default_settings,
            field_name="voice",
            service_name=self.__class__.__name__,
        )

        super().__init__(
            api_key=api_key,
            sample_rate=sample_rate or 16000,
            settings=default_settings,
            **kwargs,
        )

    @traced_tts
    async def run_tts(self, text: str, context_id: str):
        try:
            await self.start_processing_metrics()
            audio = await asyncio.to_thread(self._synthesize, text)
            await self.stop_processing_metrics()
            async for frame in self._audio_frames_from_bytes(audio, context_id):
                yield frame
        except Exception as e:
            yield ErrorFrame(error=f"Error generating DashScope TTS v2 audio: {e}")

    def _synthesize(self, text: str) -> bytes:
        dashscope.api_key = self._api_key
        synthesizer = SpeechSynthesizer(
            model=self._settings.model,
            voice=self._settings.voice,
            format=self._dashscope_audio_format(self._effective_sample_rate),
            volume=self._settings.volume if is_given(self._settings.volume) else 50,
            speech_rate=self._settings.speech_rate if is_given(self._settings.speech_rate) else 1.0,
            pitch_rate=self._settings.pitch_rate if is_given(self._settings.pitch_rate) else 1.0,
            seed=self._settings.seed if is_given(self._settings.seed) else 0,
            instruction=self._settings.instruction if is_given(self._settings.instruction) else None,
            language_hints=(self._settings.language_hints if is_given(self._settings.language_hints) else None),
            additional_params=(self._settings.additional_params if is_given(self._settings.additional_params) else None),
        )
        audio = synthesizer.call(text)
        return bytes(audio or b"")

    @staticmethod
    def _dashscope_audio_format(sample_rate: int) -> TTSV2AudioFormat:
        mapping = {
            8000: TTSV2AudioFormat.PCM_8000HZ_MONO_16BIT,
            16000: TTSV2AudioFormat.PCM_16000HZ_MONO_16BIT,
            22050: TTSV2AudioFormat.PCM_22050HZ_MONO_16BIT,
            24000: TTSV2AudioFormat.PCM_24000HZ_MONO_16BIT,
            44100: TTSV2AudioFormat.PCM_44100HZ_MONO_16BIT,
            48000: TTSV2AudioFormat.PCM_48000HZ_MONO_16BIT,
        }
        try:
            return mapping[sample_rate]
        except KeyError as e:
            raise ValueError(f"DashScope TTS v2 PCM output does not support sample_rate={sample_rate}") from e


@dataclass
class DashScopeQwenRealtimeTTSSettings(TTSSettings):
    volume: int | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    speech_rate: float | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    pitch_rate: float | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    language_type: str | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    audio_format: str | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    bit_rate: int | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    enable_tn: bool | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    instructions: str | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    optimize_instructions: bool | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    mode: str | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    extra: dict[str, Any] = field(default_factory=dict)


class _QwenRealtimeCollector(QwenTtsRealtimeCallback):
    def __init__(self):
        self.audio_chunks: list[bytes] = []
        self.done = threading.Event()
        self.error: Exception | None = None

    def on_close(self, close_status_code, close_msg) -> None:
        self.done.set()

    def on_event(self, message: dict[str, Any]) -> None:
        try:
            if message.get("type") == "response.audio.delta":
                audio = (
                    message.get("delta")
                    or message.get("audio")
                    or message.get("data")
                    or message.get("response", {}).get("audio", {}).get("delta")
                    or message.get("response", {}).get("audio", {}).get("data")
                )
                chunk = _decode_base64_audio(audio)
                if chunk:
                    self.audio_chunks.append(chunk)
            elif message.get("type") in {"response.done", "session.finished"}:
                self.done.set()
        except Exception as e:  # pragma: no cover - defensive callback path
            self.error = e
            self.done.set()


class DashScopeQwenRealtimeTTSService(_BaseDashScopeTTSService):
    """TTS service backed by DashScope ``audio.qwen_tts_realtime``."""

    Settings = DashScopeQwenRealtimeTTSSettings
    _settings: Settings

    def __init__(
        self,
        *,
        api_key: str | None = None,
        model: str | None = None,
        voice: str | None = None,
        sample_rate: int | None = None,
        settings: Settings | None = None,
        **kwargs,
    ) -> None:
        default_settings = self.Settings(
            model=NOT_GIVEN,
            voice=NOT_GIVEN,
            language=None,
            volume=50,
            speech_rate=1.0,
            pitch_rate=1.0,
            language_type=None,
            audio_format="pcm",
            bit_rate=None,
            enable_tn=None,
            instructions=None,
            optimize_instructions=None,
            mode="server_commit",
            extra={},
        )
        if model is not None:
            default_settings.model = model
        if voice is not None:
            default_settings.voice = voice
        if settings is not None:
            default_settings.apply_update(settings)
        default_settings.model = _require_text_setting(
            default_settings,
            field_name="model",
            service_name=self.__class__.__name__,
        )
        default_settings.voice = _require_text_setting(
            default_settings,
            field_name="voice",
            service_name=self.__class__.__name__,
        )

        super().__init__(
            api_key=api_key,
            sample_rate=sample_rate or 24000,
            settings=default_settings,
            **kwargs,
        )

    @traced_tts
    async def run_tts(self, text: str, context_id: str):
        try:
            await self.start_processing_metrics()
            audio = await asyncio.to_thread(self._synthesize, text)
            await self.stop_processing_metrics()
            async for frame in self._audio_frames_from_bytes(audio, context_id):
                yield frame
        except Exception as e:
            yield ErrorFrame(error=f"Error generating DashScope Qwen realtime audio: {e}")

    def _synthesize(self, text: str) -> bytes:
        dashscope.api_key = self._api_key
        collector = _QwenRealtimeCollector()
        realtime = QwenTtsRealtime(model=self._settings.model, callback=collector)

        try:
            realtime.connect()
            kwargs: dict[str, Any] = {}
            for field_name in (
                "volume",
                "speech_rate",
                "pitch_rate",
                "language_type",
                "audio_format",
                "bit_rate",
                "enable_tn",
                "instructions",
                "optimize_instructions",
                "mode",
            ):
                value = getattr(self._settings, field_name)
                if is_given(value) and value is not None:
                    kwargs[field_name] = value

            kwargs.update(self._settings.extra)
            realtime.update_session(
                voice=self._settings.voice,
                response_format=QwenRealtimeAudioFormat.PCM_24000HZ_MONO_16BIT,
                sample_rate=self._effective_sample_rate,
                **kwargs,
            )
            realtime.append_text(text)
            realtime.finish()
            if not collector.done.wait(timeout=30.0):
                raise TimeoutError("Timed out waiting for DashScope Qwen realtime TTS response")
            if collector.error:
                raise collector.error
            return b"".join(collector.audio_chunks)
        finally:
            try:
                realtime.close()
            except Exception:
                pass


@dataclass
class DashScopeMultiModalTTSSettings(TTSSettings):
    language_type: str | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    stream: bool | None | _NotGiven = field(default_factory=lambda: True)
    extra: dict[str, Any] = field(default_factory=dict)


class DashScopeMultiModalTTSService(_BaseDashScopeTTSService):
    """TTS service backed by DashScope ``MultiModalConversation``."""

    Settings = DashScopeMultiModalTTSSettings
    _settings: Settings

    def __init__(
        self,
        *,
        api_key: str | None = None,
        model: str | None = None,
        voice: str | None = None,
        sample_rate: int | None = None,
        settings: Settings | None = None,
        **kwargs,
    ) -> None:
        default_settings = self.Settings(
            model=NOT_GIVEN,
            voice=NOT_GIVEN,
            language=None,
            language_type=None,
            stream=True,
            extra={},
        )
        if model is not None:
            default_settings.model = model
        if voice is not None:
            default_settings.voice = voice
        if settings is not None:
            default_settings.apply_update(settings)
        default_settings.model = _require_text_setting(
            default_settings,
            field_name="model",
            service_name=self.__class__.__name__,
        )
        default_settings.voice = _require_text_setting(
            default_settings,
            field_name="voice",
            service_name=self.__class__.__name__,
        )

        super().__init__(
            api_key=api_key,
            sample_rate=sample_rate or 24000,
            settings=default_settings,
            **kwargs,
        )

    @traced_tts
    async def run_tts(self, text: str, context_id: str):
        try:
            await self.start_processing_metrics()
            stream = self._settings.stream if is_given(self._settings.stream) else True
            if stream:
                chunks = await asyncio.to_thread(self._stream_synthesize, text)
                await self.stop_processing_metrics()
                for chunk in chunks:
                    yield TTSAudioRawFrame(
                        audio=chunk,
                        sample_rate=self._effective_sample_rate,
                        num_channels=1,
                        context_id=context_id,
                    )
            else:
                audio = await asyncio.to_thread(self._nonstream_synthesize, text)
                await self.stop_processing_metrics()
                async for frame in self._audio_frames_from_bytes(audio, context_id):
                    yield frame
        except Exception as e:
            yield ErrorFrame(error=f"Error generating DashScope multimodal TTS audio: {e}")

    def _base_call_kwargs(self, text: str) -> dict[str, Any]:
        kwargs = {
            "api_key": self._api_key,
            "model": self._settings.model,
            "text": text,
            "voice": self._settings.voice,
        }
        if is_given(self._settings.language_type) and self._settings.language_type is not None:
            kwargs["language_type"] = self._settings.language_type
        kwargs.update(self._settings.extra)
        return kwargs

    def _stream_synthesize(self, text: str) -> list[bytes]:
        response = MultiModalConversation.call(
            **self._base_call_kwargs(text),
            stream=True,
        )
        chunks: list[bytes] = []
        for chunk in response:
            _raise_for_dashscope_error(chunk, operation="multimodal TTS streaming")
            output = getattr(chunk, "output", None)
            if not output:
                continue
            audio = output.get("audio") if isinstance(output, dict) else getattr(output, "audio", None)
            if not audio:
                continue
            data = audio.get("data") if isinstance(audio, dict) else getattr(audio, "data", None)
            decoded = _decode_base64_audio(data)
            if decoded:
                chunks.append(decoded)
        return chunks

    def _nonstream_synthesize(self, text: str) -> bytes:
        response = MultiModalConversation.call(
            **self._base_call_kwargs(text),
            stream=False,
        )
        _raise_for_dashscope_error(response, operation="multimodal TTS")
        output = getattr(response, "output", None)
        if not output:
            return b""
        audio = output.get("audio") if isinstance(output, dict) else getattr(output, "audio", None)
        if not audio:
            return b""
        data = audio.get("data") if isinstance(audio, dict) else getattr(audio, "data", None)
        if data:
            return _decode_base64_audio(data)
        url = audio.get("url") if isinstance(audio, dict) else getattr(audio, "url", None)
        return _extract_url_audio(url)
