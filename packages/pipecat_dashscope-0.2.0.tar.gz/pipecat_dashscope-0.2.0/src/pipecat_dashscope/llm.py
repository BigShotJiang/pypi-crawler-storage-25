"""Native DashScope LLM service integration for Pipecat."""

from __future__ import annotations

import asyncio
import json
import os
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any

import dashscope
from dashscope import AioMultiModalConversation
from dashscope.aigc import AioGeneration
from loguru import logger

from pipecat.frames.frames import (
    ErrorFrame,
    Frame,
    LLMContextFrame,
    LLMFullResponseEndFrame,
    LLMFullResponseStartFrame,
)
from pipecat.metrics.metrics import LLMTokenUsage
from pipecat.processors.aggregators.llm_context import LLMContext
from pipecat.processors.frame_processor import FrameDirection
from pipecat.services.llm_service import FunctionCallFromLLM, LLMService
from pipecat.services.settings import NOT_GIVEN, LLMSettings, _NotGiven, is_given

DEFAULT_DASHSCOPE_API_BASE = "https://dashscope.aliyuncs.com/api/v1"
DEFAULT_DASHSCOPE_MODEL = "qwen-plus"
_DROP = object()


@dataclass
class DashScopeLLMSettings(LLMSettings):
    """Runtime settings for ``DashScopeGenerationLLMService``."""

    enable_search: bool | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    enable_thinking: bool | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    repetition_penalty: float | None | _NotGiven = field(default_factory=lambda: NOT_GIVEN)
    result_format: str | None | _NotGiven = field(default_factory=lambda: "message")
    incremental_output: bool | None | _NotGiven = field(default_factory=lambda: True)
    extra: dict[str, Any] = field(default_factory=dict)


class DashScopeGenerationLLMService(LLMService):
    """Pipecat LLM service backed by DashScope's native Generation API."""

    supports_developer_role = False
    Settings = DashScopeLLMSettings
    _settings: Settings

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        settings: Settings | None = None,
        **kwargs: Any,
    ) -> None:
        default_settings = self.Settings(
            model=DEFAULT_DASHSCOPE_MODEL,
            system_instruction=None,
            temperature=None,
            max_tokens=None,
            top_p=None,
            top_k=None,
            frequency_penalty=None,
            presence_penalty=None,
            seed=None,
            filter_incomplete_user_turns=False,
            user_turn_completion_config=None,
            enable_search=False,
            enable_thinking=False,
            repetition_penalty=None,
            result_format="message",
            incremental_output=True,
            extra={},
        )
        if settings is not None:
            default_settings.apply_update(settings)

        super().__init__(settings=default_settings, **kwargs)

        self._api_key = api_key or os.getenv("DASHSCOPE_API_KEY")
        self._base_url = base_url or os.getenv("DASHSCOPE_BASE_URL") or DEFAULT_DASHSCOPE_API_BASE
        if not self._api_key:
            raise ValueError("DashScope API key is required. Pass api_key=... or set DASHSCOPE_API_KEY.")

    async def run_inference(
        self,
        context: LLMContext,
        max_tokens: int | None = None,
        system_instruction: str | None = None,
    ) -> str | None:
        response = await self._call_model(
            context,
            stream=False,
            system_instruction=system_instruction,
            max_tokens=max_tokens,
        )
        self._record_usage(response)
        return self._extract_message_text(self._extract_message(response))

    async def _process_context(self, context: LLMContext):
        functions_list: list[str] = []
        arguments_list: list[str] = []
        tool_id_list: list[str] = []
        func_idx = 0
        function_name = ""
        arguments = ""
        tool_call_id = ""

        await self.start_ttfb_metrics()
        responses = await self._call_model(context, stream=True)
        async for chunk in responses:
            self._raise_for_error(chunk)
            self._record_usage(chunk)

            message = self._extract_message(chunk)
            if not message:
                continue

            await self.stop_ttfb_metrics()

            tool_calls = message.get("tool_calls") or []
            if tool_calls:
                tool_call = tool_calls[0]
                tool_index = tool_call.get("index", 0)
                if tool_index != func_idx:
                    functions_list.append(function_name)
                    arguments_list.append(arguments or "{}")
                    tool_id_list.append(tool_call_id)
                    function_name = ""
                    arguments = ""
                    tool_call_id = ""
                    func_idx += 1

                function = tool_call.get("function") or {}
                if function.get("name"):
                    function_name += function["name"]
                    tool_call_id = tool_call.get("id", tool_call_id)
                if function.get("arguments"):
                    arguments += function["arguments"]
                continue

            content = self._extract_message_text(message)
            if content:
                await self._push_llm_text(content)

        if function_name:
            functions_list.append(function_name)
            arguments_list.append(arguments or "{}")
            tool_id_list.append(tool_call_id)

        if functions_list:
            function_calls: list[FunctionCallFromLLM] = []
            for function_name, arguments, tool_id in zip(functions_list, arguments_list, tool_id_list, strict=False):
                try:
                    parsed_arguments = json.loads(arguments)
                except json.JSONDecodeError:
                    logger.warning(f"{self}: failed to parse function call arguments: {arguments}")
                    continue

                function_calls.append(
                    FunctionCallFromLLM(
                        context=context,
                        tool_call_id=tool_id,
                        function_name=function_name,
                        arguments=parsed_arguments,
                    )
                )

            if function_calls:
                await self.run_function_calls(function_calls)

    async def _call_model(
        self,
        context: LLMContext,
        *,
        stream: bool,
        system_instruction: str | None = None,
        max_tokens: int | None = None,
    ) -> Any:
        params = self._build_generation_params(context, stream=stream, system_instruction=system_instruction)
        if max_tokens is not None:
            params["max_tokens"] = max_tokens
        return await AioGeneration.call(self._settings.model, **params)

    async def process_frame(self, frame: Frame, direction: FrameDirection):
        await super().process_frame(frame, direction)

        if isinstance(frame, LLMContextFrame):
            try:
                await self.push_frame(LLMFullResponseStartFrame())
                await self.start_processing_metrics()
                await self._process_context(frame.context)
            except Exception as e:
                await self.push_frame(ErrorFrame(error=f"Error during completion: {e}"))
            finally:
                await self.stop_processing_metrics()
                await self.push_frame(LLMFullResponseEndFrame())
        else:
            await self.push_frame(frame, direction)

    def _build_generation_params(
        self,
        context: LLMContext,
        *,
        stream: bool,
        system_instruction: str | None = None,
    ) -> dict[str, Any]:
        adapter = self.get_llm_adapter()
        params_from_context = adapter.get_llm_invocation_params(
            context,
            system_instruction=system_instruction or self._settings.system_instruction,
            convert_developer_to_user=True,
        )

        params: dict[str, Any] = {
            "api_key": self._api_key,
            "messages": self._sanitize_for_dashscope(params_from_context["messages"]),
            "stream": stream,
            "result_format": self._settings.result_format,
            "incremental_output": self._settings.incremental_output,
        }

        optional_params = {
            "temperature": self._settings.temperature,
            "top_p": self._settings.top_p,
            "top_k": self._settings.top_k,
            "max_tokens": self._settings.max_tokens,
            "seed": self._settings.seed,
            "enable_search": self._settings.enable_search,
            "enable_thinking": self._settings.enable_thinking,
            "repetition_penalty": self._settings.repetition_penalty,
        }
        for key, value in optional_params.items():
            if is_given(value) and value is not None:
                params[key] = value

        tools = params_from_context.get("tools", NOT_GIVEN)
        if is_given(tools):
            sanitized_tools = self._sanitize_for_dashscope(tools)
            if sanitized_tools is not _DROP:
                params["tools"] = sanitized_tools

        tool_choice = params_from_context.get("tool_choice", NOT_GIVEN)
        if is_given(tool_choice):
            sanitized_tool_choice = self._sanitize_for_dashscope(tool_choice)
            if sanitized_tool_choice is not _DROP:
                params["tool_choice"] = sanitized_tool_choice

        if self._settings.extra:
            sanitized_extra = self._sanitize_for_dashscope(self._settings.extra)
            if isinstance(sanitized_extra, dict):
                params.update(sanitized_extra)

        dashscope.base_http_api_url = self._base_url
        return params

    def _record_usage(self, response: Any) -> None:
        usage = getattr(response, "usage", None)
        if not usage:
            return

        prompt_tokens = usage.get("input_tokens")
        completion_tokens = usage.get("output_tokens")
        total_tokens = usage.get("total_tokens")
        if total_tokens is None and prompt_tokens is not None and completion_tokens is not None:
            total_tokens = prompt_tokens + completion_tokens

        if prompt_tokens is None or completion_tokens is None or total_tokens is None:
            return

        metrics = LLMTokenUsage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
        )
        asyncio.create_task(self.start_llm_usage_metrics(metrics))

    @staticmethod
    def _extract_message(response: Any) -> dict[str, Any] | None:
        output = getattr(response, "output", None)
        if not output:
            return None

        choices = output.get("choices") or []
        if not choices:
            return None

        message = choices[0].get("message")
        return dict(message) if message else None

    @staticmethod
    def _extract_message_text(message: dict[str, Any] | None) -> str:
        if not message:
            return ""

        content = message.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for item in content:
                if isinstance(item, dict) and item.get("text"):
                    parts.append(item["text"])
            return "".join(parts)
        return ""

    @staticmethod
    def _raise_for_error(response: Any) -> None:
        status_code = getattr(response, "status_code", 200)
        if status_code == 200:
            return

        message = getattr(response, "message", "Unknown DashScope error")
        code = getattr(response, "code", "")
        logger.error(f"DashScope request failed ({status_code} {code}): {message}")
        raise RuntimeError(f"DashScope request failed ({status_code} {code}): {message}")

    @classmethod
    def _sanitize_for_dashscope(cls, value: Any) -> Any:
        if not is_given(value):
            return _DROP
        if type(value).__name__ == "NotGiven":
            return _DROP
        if isinstance(value, Mapping):
            sanitized = {}
            for key, item in value.items():
                cleaned = cls._sanitize_for_dashscope(item)
                if cleaned is not _DROP:
                    sanitized[key] = cleaned
            return sanitized
        if isinstance(value, list):
            return [cleaned for item in value if (cleaned := cls._sanitize_for_dashscope(item)) is not _DROP]
        if isinstance(value, tuple):
            return tuple(cleaned for item in value if (cleaned := cls._sanitize_for_dashscope(item)) is not _DROP)
        return value


class DashScopeMultiModalLLMService(DashScopeGenerationLLMService):
    """Pipecat LLM service backed by DashScope ``AioMultiModalConversation``."""

    async def _call_model(
        self,
        context: LLMContext,
        *,
        stream: bool,
        system_instruction: str | None = None,
        max_tokens: int | None = None,
    ) -> Any:
        params = self._build_generation_params(context, stream=stream, system_instruction=system_instruction)
        if max_tokens is not None:
            params["max_tokens"] = max_tokens
        return await AioMultiModalConversation.call(self._settings.model, **params)
