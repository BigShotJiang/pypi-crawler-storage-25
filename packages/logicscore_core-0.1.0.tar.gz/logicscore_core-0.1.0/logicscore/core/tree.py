"""Tree structures for LSP evaluation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .suitability import SuitabilityCurve


@dataclass
class TreeNode:
    """Node in an LSP evaluation tree."""

    id: str
    name: str
    weight: float = 1.0
    operator: float = 0.5
    score: float | None = None
    children: list[TreeNode] = field(default_factory=list)
    curve: SuitabilityCurve | None = None
    domain_unit: str | None = None
    role: str | None = None
    stale_after: float | None = None

    @property
    def is_leaf(self) -> bool:
        """Return True when node has no children."""
        return len(self.children) == 0

