"""Tree traversal helpers."""

from __future__ import annotations

from .tree import TreeNode


def get_all_leaves(node: TreeNode) -> list[TreeNode]:
    """Return all leaf nodes in depth-first order."""
    if node.is_leaf:
        return [node]
    leaves: list[TreeNode] = []
    for child in node.children:
        leaves.extend(get_all_leaves(child))
    return leaves


def get_all_nodes(node: TreeNode) -> list[TreeNode]:
    """Return all nodes in depth-first order."""
    nodes = [node]
    for child in node.children:
        nodes.extend(get_all_nodes(child))
    return nodes

