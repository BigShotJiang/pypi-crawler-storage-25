"""Tree validation logic."""

from __future__ import annotations

from dataclasses import dataclass

from .tree import TreeNode


@dataclass
class ValidationResult:
    """Validation output."""

    valid: bool
    errors: list[str]
    warnings: list[str]
    effective_weights: dict[str, float]


_CANONICAL_OPERATORS = {0.0, 0.25, 0.5, 0.75, 1.0}


def _walk(
    node: TreeNode,
    ancestors: set[int],
    seen_ids: set[str],
    errors: list[str],
    warnings: list[str],
    effective_weights: dict[str, float],
) -> None:
    object_id = id(node)
    if object_id in ancestors:
        errors.append(f"circular reference detected at node '{node.id}'")
        return

    if node.id in seen_ids:
        errors.append(f"duplicate node id '{node.id}'")
    else:
        seen_ids.add(node.id)

    if node.weight <= 0.0:
        errors.append(f"node '{node.id}' has non-positive weight")

    if node.operator < 0.0 or node.operator > 1.0:
        errors.append(f"node '{node.id}' has operator outside [0.0, 1.0]")
    elif node.operator not in _CANONICAL_OPERATORS:
        warnings.append(f"node '{node.id}' uses non-canonical operator {node.operator}")

    if node.role is not None:
        warnings.append(
            f"node '{node.id}' has role set to '{node.role}' "
            "(PA operators not implemented)"
        )

    if node.is_leaf:
        if node.score is None:
            warnings.append(f"leaf '{node.id}' has score=None")
        elif node.score < 0.0 or node.score > 1.0:
            warnings.append(f"leaf '{node.id}' has score outside [0.0, 1.0]")
        return

    if len(node.children) == 1:
        warnings.append(f"node '{node.id}' has exactly one child")

    child_weight_total = sum(child.weight for child in node.children)
    for child in node.children:
        if child_weight_total > 0.0:
            effective_weights[child.id] = (child.weight / child_weight_total) * 100.0
        else:
            effective_weights[child.id] = 0.0

    next_ancestors = set(ancestors)
    next_ancestors.add(object_id)
    for child in node.children:
        _walk(child, next_ancestors, seen_ids, errors, warnings, effective_weights)


def validate_tree(node: TreeNode) -> ValidationResult:
    """Validate an LSP tree."""
    errors: list[str] = []
    warnings: list[str] = []
    effective_weights: dict[str, float] = {node.id: 100.0}
    _walk(node, set(), set(), errors, warnings, effective_weights)
    return ValidationResult(
        valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
        effective_weights=effective_weights,
    )

