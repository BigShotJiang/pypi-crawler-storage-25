"""Core aggregation operators."""

from __future__ import annotations

import math

ALPHA_THETA = 0.75
FLOOR = 0.001
_BOUNDARY_EPS = 0.02
_ENDPOINT_EPS = 1e-12
_HUGE_R = 1e20

_COEFFICIENTS: dict[int, dict[str, tuple[float, float, float, float]]] = {
    2: {
        "ge": (1.62481, 1.26214, 0.144343, -0.144343),
        "lt": (1.65811, 2.15388, 8.2844, 6.16764),
    },
    3: {
        "ge": (1.85971, 1.9532, -0.17274, 0.0213069),
        "lt": (1.95419, 3.69032, 10.7073, 9.46921),
    },
    4: {
        "ge": (2.06781, 1.83246, 1.99365, -2.30786),
        "lt": (2.11034, 4.4749, 11.4962, 10.5552),
    },
    5: {
        "ge": (2.09567, 3.04673, -0.388745, 0.0110307),
        "lt": (2.21868, 5.0574, 12.0866, 11.2383),
    },
}


def r_wpm(alpha: float, n: int) -> float:
    """Compute WPM exponent from andness and number of inputs."""
    if n < 2:
        raise ValueError("n must be >= 2")
    if alpha < _BOUNDARY_EPS:
        return _HUGE_R
    if alpha > 1.0 - _BOUNDARY_EPS:
        return -_HUGE_R

    n_eff = min(n, 5)
    branch = "ge" if alpha >= 0.5 else "lt"
    a_n, b_n, c_n, d_n = _COEFFICIENTS[n_eff][branch]
    delta = 0.5 - alpha
    numerator = (
        0.25
        + a_n * delta
        + b_n * (delta**2)
        + c_n * (delta**3)
        + d_n * (delta**4)
    )
    denominator = alpha * (1.0 - alpha)
    return numerator / denominator


def _weighted_mean(scores: list[float], norm_weights: list[float]) -> float:
    return sum(
        weight * score for score, weight in zip(scores, norm_weights, strict=True)
    )


def _weighted_power_mean(
    scores: list[float],
    norm_weights: list[float],
    exponent: float,
) -> float:
    if exponent <= -1e6:
        return min(scores)
    if exponent >= 1e6:
        return max(scores)
    if any(score == 0.0 for score in scores):
        if exponent < 0.0:
            return 0.0
        total = sum(
            weight * (score**exponent)
            for score, weight in zip(scores, norm_weights, strict=True)
        )
        return float(total ** (1.0 / exponent))

    logs = [math.log(score) for score in scores]
    scaled = [exponent * log_score for log_score in logs]
    max_scaled = max(scaled)
    total = sum(
        weight * math.exp(value - max_scaled)
        for value, weight in zip(scaled, norm_weights, strict=True)
    )
    log_total = math.log(total) + max_scaled
    return math.exp(log_total / exponent)


def ugcd_aggregate(
    scores: list[float | None],
    weights: list[float],
    alpha: float,
) -> float | None:
    """Aggregate scores using UGCD."""
    if not scores or len(scores) != len(weights):
        return None
    if any(score is None for score in scores):
        return None

    resolved_scores = [score for score in scores if score is not None]
    weight_sum = sum(weights)
    if weight_sum <= 0.0:
        return None

    n = len(resolved_scores)
    if n == 1:
        return resolved_scores[0]

    norm_weights = [weight / weight_sum for weight in weights]
    floored_scores = [max(score, FLOOR) for score in resolved_scores]
    return _ugcd_from_floored(floored_scores, norm_weights, alpha)


def _ugcd_from_floored(
    scores: list[float],
    norm_weights: list[float],
    alpha: float,
) -> float:
    n = len(scores)

    if alpha >= 1.0 - _ENDPOINT_EPS:
        return min(scores)
    if alpha <= _ENDPOINT_EPS:
        return max(scores)
    if alpha == 0.5:
        return _weighted_mean(scores, norm_weights)

    if alpha >= ALPHA_THETA:
        return _weighted_power_mean(scores, norm_weights, r_wpm(alpha, n))
    if alpha > 0.5:
        arithmetic = _weighted_mean(scores, norm_weights)
        r_at_threshold = r_wpm(ALPHA_THETA, n)
        hard_conjunctive = _weighted_power_mean(scores, norm_weights, r_at_threshold)
        weight_arithmetic = (ALPHA_THETA - alpha) / (ALPHA_THETA - 0.5)
        weight_power = (alpha - 0.5) / (ALPHA_THETA - 0.5)
        return weight_arithmetic * arithmetic + weight_power * hard_conjunctive

    dual_scores = [1.0 - score for score in scores]
    dual = _ugcd_from_floored(dual_scores, norm_weights, 1.0 - alpha)
    return 1.0 - dual

