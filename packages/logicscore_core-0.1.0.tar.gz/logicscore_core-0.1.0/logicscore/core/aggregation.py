"""Tree aggregation entrypoints."""

from __future__ import annotations

from .operators import ugcd_aggregate
from .tree import TreeNode


def compute_tree(node: TreeNode) -> float | None:
    """Compute tree scores recursively."""
    if node.is_leaf:
        return node.score

    child_scores = [compute_tree(child) for child in node.children]
    child_weights = [child.weight for child in node.children]

    if node.operator < 0.5:
        kept_pairs = [
            (score, weight)
            for score, weight in zip(child_scores, child_weights, strict=True)
            if score is not None
        ]
        if not kept_pairs:
            node.score = None
            return None
        child_scores = [score for score, _ in kept_pairs]
        child_weights = [weight for _, weight in kept_pairs]

    aggregated = ugcd_aggregate(child_scores, child_weights, node.operator)
    node.score = aggregated
    return aggregated

