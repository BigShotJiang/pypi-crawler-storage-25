"""Suitability curve models."""

from __future__ import annotations

import math


class SuitabilityCurve:
    """Piecewise linear suitability mapping."""

    def __init__(self, control_points: list[tuple[float, float]]) -> None:
        """Initialize a suitability curve from control points."""
        if len(control_points) < 2:
            raise ValueError("at least 2 control points are required")

        for index, point in enumerate(control_points):
            _, y_val = point
            if y_val < 0.0 or y_val > 1.0:
                raise ValueError("control point y values must be in [0.0, 1.0]")
            if index > 0 and point[0] < control_points[index - 1][0]:
                raise ValueError("control points must be sorted by x ascending")

        self.control_points = list(control_points)

    def __call__(self, raw: float) -> float:
        """Map a raw value into suitability space."""
        first_x, first_y = self.control_points[0]
        last_x, last_y = self.control_points[-1]

        if raw <= first_x:
            return first_y
        if raw >= last_x:
            return last_y

        for index in range(1, len(self.control_points)):
            x1, y1 = self.control_points[index - 1]
            x2, y2 = self.control_points[index]
            if x1 <= raw <= x2:
                span = x2 - x1
                fraction = (raw - x1) / span
                interpolated = y1 + fraction * (y2 - y1)
                return max(0.0, min(1.0, interpolated))

        return last_y

    @classmethod
    def linear(
        cls,
        domain: tuple[float, float],
        low_suitability: float = 0.0,
        high_suitability: float = 1.0,
    ) -> SuitabilityCurve:
        """Build a linear suitability curve."""
        low_x, high_x = domain
        return cls([(low_x, low_suitability), (high_x, high_suitability)])

    @classmethod
    def step(
        cls,
        threshold: float,
        below: float = 1.0,
        above: float = 0.0,
    ) -> SuitabilityCurve:
        """Build a step suitability curve."""
        epsilon = 1e-9
        return cls([(threshold - epsilon, below), (threshold, above)])

    @classmethod
    def inverted_u(
        cls,
        peak: float,
        width: float,
        peak_suitability: float = 1.0,
        base_suitability: float = 0.0,
    ) -> SuitabilityCurve:
        """Build an inverted-U suitability curve."""
        if width <= 0.0:
            raise ValueError("width must be positive")
        half_width = width / 2.0
        return cls(
            [
                (peak - half_width, base_suitability),
                (peak, peak_suitability),
                (peak + half_width, base_suitability),
            ],
        )

    @classmethod
    def s_curve(
        cls,
        midpoint: float,
        steepness: float = 10.0,
        n_points: int = 20,
    ) -> SuitabilityCurve:
        """Build an S-curve suitability mapping."""
        if steepness <= 0.0:
            raise ValueError("steepness must be positive")
        if n_points < 2:
            raise ValueError("n_points must be >= 2")

        low_x = midpoint - 3.0 / steepness
        high_x = midpoint + 3.0 / steepness
        step = (high_x - low_x) / (n_points - 1)

        points: list[tuple[float, float]] = []
        for index in range(n_points):
            x_val = low_x + step * index
            y_val = 1.0 / (1.0 + math.exp(-steepness * (x_val - midpoint)))
            points.append((x_val, max(0.0, min(1.0, y_val))))
        return cls(points)

