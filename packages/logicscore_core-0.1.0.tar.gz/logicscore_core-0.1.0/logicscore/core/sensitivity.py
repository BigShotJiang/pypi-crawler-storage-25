"""Sensitivity calculations."""

from __future__ import annotations

import copy

from .aggregation import compute_tree
from .tree import TreeNode


def _find_leaf(node: TreeNode, leaf_id: str) -> TreeNode | None:
    if node.id == leaf_id and node.is_leaf:
        return node
    for child in node.children:
        maybe_leaf = _find_leaf(child, leaf_id)
        if maybe_leaf is not None:
            return maybe_leaf
    return None


def compute_sensitivity(
    tree: TreeNode,
    leaf_id: str,
    delta: float = 0.05,
) -> float:
    """Compute finite-difference sensitivity for a leaf."""
    if delta <= 0.0:
        raise ValueError("delta must be positive")

    base_tree = copy.deepcopy(tree)
    perturbed_tree = copy.deepcopy(tree)

    base_score = compute_tree(base_tree)
    base_leaf = _find_leaf(base_tree, leaf_id)
    perturbed_leaf = _find_leaf(perturbed_tree, leaf_id)

    if (
        base_score is None
        or base_leaf is None
        or perturbed_leaf is None
        or base_leaf.score is None
        or perturbed_leaf.score is None
    ):
        return 0.0

    perturbed_leaf.score = min(perturbed_leaf.score + delta, 1.0)
    new_score = compute_tree(perturbed_tree)
    if new_score is None:
        return 0.0
    return (new_score - base_score) / delta

