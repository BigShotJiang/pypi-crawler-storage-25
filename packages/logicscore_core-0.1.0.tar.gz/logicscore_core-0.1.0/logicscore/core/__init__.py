"""Public exports for logicscore.core."""

from .aggregation import compute_tree
from .sensitivity import compute_sensitivity
from .suitability import SuitabilityCurve
from .traversal import get_all_leaves, get_all_nodes
from .tree import TreeNode
from .validation import ValidationResult, validate_tree

__all__ = [
    "TreeNode",
    "compute_tree",
    "compute_sensitivity",
    "get_all_leaves",
    "get_all_nodes",
    "validate_tree",
    "ValidationResult",
    "SuitabilityCurve",
]

