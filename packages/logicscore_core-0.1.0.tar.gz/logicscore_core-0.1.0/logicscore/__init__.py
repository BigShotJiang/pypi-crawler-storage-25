"""Top-level package for LogicScore Core."""
