from __future__ import annotations

import pytest

from logicscore.core.suitability import SuitabilityCurve


def test_interpolation_and_clamping() -> None:
    curve = SuitabilityCurve([(0.0, 1.0), (0.1, 0.0)])
    assert curve(0.0) == 1.0
    assert curve(0.1) == 0.0
    assert abs(curve(0.05) - 0.5) < 1e-9
    assert curve(-1.0) == 1.0
    assert curve(1.0) == 0.0


def test_step_inverted_u_and_linear_factories() -> None:
    step = SuitabilityCurve.step(threshold=0.5, below=1.0, above=0.0)
    assert step(0.4) == 1.0
    assert step(0.6) == 0.0

    inverted = SuitabilityCurve.inverted_u(peak=10.0, width=4.0)
    assert inverted(10.0) == 1.0
    assert inverted(8.0) == 0.0
    assert inverted(12.0) == 0.0
    assert inverted(5.0) == 0.0

    linear = SuitabilityCurve.linear(domain=(0.0, 100.0))
    assert linear(0.0) == 0.0
    assert linear(100.0) == 1.0
    assert abs(linear(50.0) - 0.5) < 1e-9


def test_s_curve_factory_and_validation_errors() -> None:
    s_curve = SuitabilityCurve.s_curve(midpoint=2.0, steepness=10.0, n_points=20)
    assert len(s_curve.control_points) == 20
    low_x, low_y = s_curve.control_points[0]
    high_x, high_y = s_curve.control_points[-1]
    assert low_x < 2.0 < high_x
    assert 0.0 <= low_y < 0.5 < high_y <= 1.0
    assert abs(s_curve(2.0) - 0.5) < 0.1

    with pytest.raises(ValueError):
        SuitabilityCurve([(0.0, 1.0)])
    with pytest.raises(ValueError):
        SuitabilityCurve([(0.5, 1.0), (0.1, 0.0)])
    with pytest.raises(ValueError):
        SuitabilityCurve([(0.0, 1.5), (1.0, 0.0)])
    with pytest.raises(ValueError):
        SuitabilityCurve.inverted_u(peak=10.0, width=0.0)
    with pytest.raises(ValueError):
        SuitabilityCurve.s_curve(midpoint=0.0, steepness=0.0, n_points=20)
    with pytest.raises(ValueError):
        SuitabilityCurve.s_curve(midpoint=0.0, steepness=10.0, n_points=1)


def test_nan_input_falls_back_to_last_y() -> None:
    curve = SuitabilityCurve([(0.0, 0.1), (1.0, 0.9)])
    assert curve(float("nan")) == 0.9
