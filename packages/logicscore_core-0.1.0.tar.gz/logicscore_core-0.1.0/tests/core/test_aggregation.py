from __future__ import annotations

import json
from pathlib import Path
from typing import TypedDict

import pytest
from hypothesis import example, given
from hypothesis import strategies as st

from logicscore import core
from logicscore.core import operators
from logicscore.core.aggregation import compute_tree
from logicscore.core.operators import r_wpm, ugcd_aggregate
from logicscore.core.tree import TreeNode


class FixtureCase(TypedDict, total=False):
    desc: str
    scores: list[float | None]
    weights: list[float]
    alpha: float
    expected: float | None
    tol: float
    assert_lt: float
    n_override: int


def _load_fixture_cases() -> list[FixtureCase]:
    fixture_path = Path("fixtures/ugcd_cases.json")
    content = json.loads(fixture_path.read_text(encoding="utf-8"))
    return content


def test_public_exports() -> None:
    assert core.TreeNode is TreeNode
    assert callable(core.compute_tree)
    assert callable(core.compute_sensitivity)
    assert callable(core.get_all_leaves)
    assert callable(core.get_all_nodes)
    assert callable(core.validate_tree)
    assert callable(core.SuitabilityCurve)


def test_r_wpm_guards_and_n_dependence() -> None:
    with pytest.raises(ValueError):
        r_wpm(0.5, 1)
    assert r_wpm(0.0, 2) == 1e20
    assert r_wpm(1.0, 2) == -1e20

    # For n >= 6, coefficients for n=5 are used.
    assert r_wpm(0.75, 6) == r_wpm(0.75, 5)
    # n-dependence: same alpha, different n => different exponent.
    assert r_wpm(0.75, 2) != r_wpm(0.75, 3)


def test_ugcd_invalid_shape_returns_none() -> None:
    assert ugcd_aggregate([0.1, 0.2], [1.0], 0.5) is None


def test_weighted_power_mean_extreme_exponents() -> None:
    scores = [0.2, 0.8]
    weights = [0.5, 0.5]
    assert operators._weighted_power_mean(scores, weights, 1e6) == 0.8
    assert operators._weighted_power_mean(scores, weights, -1e6) == 0.2
    # Zero-handling branch: negative exponent with zero collapses to 0.
    assert operators._weighted_power_mean([0.0, 0.5], weights, -2.0) == 0.0
    # Zero-handling branch: positive exponent computes directly without logs.
    positive = operators._weighted_power_mean([0.0, 0.5], weights, 2.0)
    assert abs(positive - (0.125**0.5)) < 1e-12


def test_ugcd_dual_symmetry_branch() -> None:
    scores = [0.2, 0.8, 0.5]
    weights = [1.0, 3.0, 2.0]
    alpha = 0.25
    lhs = ugcd_aggregate(scores, weights, alpha)
    rhs = 1.0 - ugcd_aggregate([1.0 - x for x in scores], weights, 1.0 - alpha)
    assert lhs is not None
    assert rhs is not None
    assert abs(lhs - rhs) < 1e-12


def test_ugcd_fixtures() -> None:
    cases = _load_fixture_cases()
    for case in cases:
        if "n_override" in case:
            # The public API is defined without n override.
            continue
        result = ugcd_aggregate(case["scores"], case["weights"], case["alpha"])
        expected = case.get("expected")
        if expected is None:
            assert result is None, case["desc"]
            continue
        assert result is not None, case["desc"]
        tolerance = case.get("tol", 1e-9)
        assert abs(result - expected) <= tolerance, case["desc"]
        if "assert_lt" in case:
            assert result < case["assert_lt"], case["desc"]


def test_compute_tree_cases() -> None:
    leaf = TreeNode(id="a", name="A", score=0.7)
    assert compute_tree(leaf) == 0.7

    parent = TreeNode(
        id="root",
        name="Root",
        operator=0.5,
        children=[
            TreeNode(id="a", name="A", score=0.6, weight=1),
            TreeNode(id="b", name="B", score=0.8, weight=1),
        ],
    )
    assert abs(compute_tree(parent) - 0.7) < 1e-9

    parent2 = TreeNode(
        id="root",
        name="Root",
        operator=0.5,
        children=[
            TreeNode(id="a", name="A", score=0.6, weight=1),
            TreeNode(id="b", name="B", score=None, weight=1),
        ],
    )
    assert compute_tree(parent2) is None

    parent3 = TreeNode(
        id="root",
        name="Root",
        operator=0.75,
        children=[
            TreeNode(id="a", name="A", score=1.0, weight=1),
            TreeNode(id="b", name="B", score=1.0, weight=1),
            TreeNode(id="c", name="C", score=0.0, weight=1),
        ],
    )
    result = compute_tree(parent3)
    assert result is not None
    assert result < 0.02

    node = TreeNode(
        id="root",
        name="Root",
        operator=0.5,
        children=[TreeNode(id="a", name="A", score=0.5, weight=1)],
    )
    compute_tree(node)
    assert node.score == 0.5


def test_compute_tree_disjunctive_none_dropped() -> None:
    node = TreeNode(
        id="root",
        name="Root",
        operator=0.25,
        children=[
            TreeNode(id="a", name="A", score=0.9, weight=1.0),
            TreeNode(id="b", name="B", score=None, weight=9.0),
        ],
    )
    result = compute_tree(node)
    assert result is not None
    assert abs(result - 0.9) < 1e-12


def test_compute_tree_disjunctive_all_none_returns_none() -> None:
    node = TreeNode(
        id="root",
        name="Root",
        operator=0.25,
        children=[
            TreeNode(id="a", name="A", score=None, weight=1.0),
            TreeNode(id="b", name="B", score=None, weight=2.0),
        ],
    )
    assert compute_tree(node) is None


def test_compute_tree_conjunctive_none_blocks() -> None:
    node = TreeNode(
        id="root",
        name="Root",
        operator=0.5,
        children=[
            TreeNode(id="a", name="A", score=0.7, weight=1.0),
            TreeNode(id="b", name="B", score=None, weight=1.0),
        ],
    )
    assert compute_tree(node) is None


@given(
    scores=st.lists(
        st.floats(0.0, 1.0, allow_nan=False, allow_infinity=False),
        min_size=1,
        max_size=8,
    ),
    weights=st.lists(
        st.floats(0.001, 10.0, allow_nan=False, allow_infinity=False),
        min_size=1,
        max_size=8,
    ),
    alpha=st.floats(0.0, 1.0, allow_nan=False, allow_infinity=False),
)
def test_output_bounds(scores: list[float], weights: list[float], alpha: float) -> None:
    if len(scores) != len(weights):
        return
    result = ugcd_aggregate(scores, weights, alpha)
    if result is not None:
        assert 0.0 <= result <= 1.0


@given(
    scores=st.lists(
        st.floats(0.001, 1.0, allow_nan=False, allow_infinity=False),
        min_size=2,
        max_size=6,
    ),
    weights=st.lists(
        st.floats(0.001, 10.0, allow_nan=False, allow_infinity=False),
        min_size=2,
        max_size=6,
    ),
    k=st.floats(0.001, 1000.0, allow_nan=False, allow_infinity=False),
    alpha=st.floats(0.0, 1.0, allow_nan=False, allow_infinity=False),
)
def test_weight_scale_invariance(
    scores: list[float],
    weights: list[float],
    k: float,
    alpha: float,
) -> None:
    if len(scores) != len(weights):
        return
    r1 = ugcd_aggregate(scores, weights, alpha)
    r2 = ugcd_aggregate(scores, [weight * k for weight in weights], alpha)
    if r1 is not None and r2 is not None:
        assert abs(r1 - r2) < 1e-9


@given(
    scores=st.lists(
        st.floats(0.001, 1.0, allow_nan=False, allow_infinity=False),
        min_size=2,
        max_size=6,
    ),
    weights=st.lists(
        st.floats(0.001, 10.0, allow_nan=False, allow_infinity=False),
        min_size=2,
        max_size=6,
    ),
    a1=st.floats(0.0, 1.0, allow_nan=False, allow_infinity=False),
    a2=st.floats(0.0, 1.0, allow_nan=False, allow_infinity=False),
)
@example(
    scores=[1.0, 1.0, 1.0, 1.0, 0.5],
    weights=[1.0, 1.0, 1.0, 1.0, 1.0],
    a1=0.00390625,
    a2=0.5,
)
def test_monotonicity(
    scores: list[float],
    weights: list[float],
    a1: float,
    a2: float,
) -> None:
    if len(scores) != len(weights):
        return
    r1 = ugcd_aggregate(scores, weights, a1)
    r2 = ugcd_aggregate(scores, weights, a2)
    if r1 is not None and r2 is not None and a1 < a2:
        assert r1 >= r2 - 1e-6
