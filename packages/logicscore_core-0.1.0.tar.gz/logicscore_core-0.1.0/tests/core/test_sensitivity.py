from __future__ import annotations

import copy

import pytest

import logicscore.core.sensitivity as sensitivity_mod
from logicscore.core.sensitivity import compute_sensitivity
from logicscore.core.traversal import get_all_leaves, get_all_nodes
from logicscore.core.tree import TreeNode


def test_compute_sensitivity_basic_behaviors() -> None:
    tree = TreeNode(
        id="root",
        name="Root",
        operator=0.5,
        children=[
            TreeNode(id="a", name="A", score=0.5, weight=3),
            TreeNode(id="b", name="B", score=0.5, weight=1),
        ],
    )
    assert compute_sensitivity(tree, "a") > compute_sensitivity(tree, "b")

    tree2 = TreeNode(
        id="root",
        name="Root",
        operator=0.5,
        children=[
            TreeNode(id="a", name="A", score=1.0, weight=1),
            TreeNode(id="b", name="B", score=0.5, weight=1),
        ],
    )
    assert compute_sensitivity(tree2, "a") < 0.01


def test_compute_sensitivity_non_mutating_and_fallbacks() -> None:
    tree = TreeNode(
        id="root",
        name="Root",
        operator=0.5,
        children=[TreeNode(id="a", name="A", score=0.5, weight=1)],
    )
    before = copy.deepcopy(tree)
    compute_sensitivity(tree, "a")
    assert tree == before

    assert compute_sensitivity(tree, "missing") == 0.0

    tree_none_leaf = TreeNode(
        id="root",
        name="Root",
        operator=0.5,
        children=[
            TreeNode(id="a", name="A", score=None, weight=1),
            TreeNode(id="b", name="B", score=0.5, weight=1),
        ],
    )
    assert compute_sensitivity(tree_none_leaf, "a") == 0.0

    with pytest.raises(ValueError):
        compute_sensitivity(tree, "a", delta=0.0)


def test_traversal_helpers() -> None:
    tree = TreeNode(
        id="root",
        name="Root",
        children=[
            TreeNode(id="a", name="A", score=0.2),
            TreeNode(
                id="b",
                name="B",
                children=[TreeNode(id="c", name="C", score=0.3)],
            ),
        ],
    )
    leaves = get_all_leaves(tree)
    nodes = get_all_nodes(tree)
    assert [node.id for node in leaves] == ["a", "c"]
    assert [node.id for node in nodes] == ["root", "a", "b", "c"]


def test_compute_sensitivity_handles_none_new_score(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    tree = TreeNode(
        id="root",
        name="Root",
        operator=0.5,
        children=[TreeNode(id="a", name="A", score=0.5, weight=1.0)],
    )
    state = {"calls": 0}

    def fake_compute_tree(_node: TreeNode) -> float | None:
        state["calls"] += 1
        if state["calls"] == 1:
            return 0.5
        return None

    monkeypatch.setattr(sensitivity_mod, "compute_tree", fake_compute_tree)
    assert compute_sensitivity(tree, "a") == 0.0
