from __future__ import annotations

from logicscore.core.tree import TreeNode
from logicscore.core.validation import validate_tree


def test_validate_tree_happy_path() -> None:
    tree = TreeNode(
        id="root",
        name="Root",
        operator=0.5,
        children=[
            TreeNode(id="a", name="A", score=0.6, weight=3),
            TreeNode(id="b", name="B", score=0.4, weight=1),
        ],
    )
    result = validate_tree(tree)
    assert result.valid is True
    assert result.errors == []
    assert result.warnings == []
    assert result.effective_weights["root"] == 100.0
    assert abs(result.effective_weights["a"] - 75.0) < 1e-9
    assert abs(result.effective_weights["b"] - 25.0) < 1e-9


def test_validate_tree_errors_and_warnings() -> None:
    shared = TreeNode(id="dup", name="Dup", score=0.5, weight=1.0)
    root = TreeNode(
        id="root",
        name="Root",
        operator=1.3,
        children=[
            TreeNode(id="x", name="X", score=1.2, weight=-1.0, operator=0.33),
            shared,
            shared,
            TreeNode(
                id="single",
                name="Single",
                operator=0.5,
                children=[
                    TreeNode(id="leafnone", name="LeafNone", score=None, weight=0.0)
                ],
            ),
            TreeNode(id="customop", name="CustomOp", score=0.1, operator=0.63),
        ],
    )
    result = validate_tree(root)
    assert result.valid is False
    assert any("operator outside [0.0, 1.0]" in msg for msg in result.errors)
    assert any("non-positive weight" in msg for msg in result.errors)
    assert any("duplicate node id 'dup'" in msg for msg in result.errors)
    assert any("score outside [0.0, 1.0]" in msg for msg in result.warnings)
    assert any("score=None" in msg for msg in result.warnings)
    assert any("exactly one child" in msg for msg in result.warnings)
    assert any("non-canonical operator" in msg for msg in result.warnings)


def test_validate_tree_circular_reference_and_zero_total_siblings() -> None:
    root = TreeNode(id="root", name="Root")
    child = TreeNode(id="child", name="Child", weight=1.0)
    neg = TreeNode(id="neg", name="Neg", weight=-1.0, score=0.5)
    root.children = [child, neg]
    child.children = [root]

    result = validate_tree(root)
    assert result.valid is False
    assert any("circular reference" in msg for msg in result.errors)
    # Sibling weights 1 + (-1) = 0 => effective set to zero.
    assert result.effective_weights["child"] == 0.0
    assert result.effective_weights["neg"] == 0.0


def test_validate_tree_warns_on_role_usage() -> None:
    tree = TreeNode(
        id="root",
        name="Root",
        operator=0.5,
        children=[
            TreeNode(id="a", name="A", score=0.7, role="main"),
            TreeNode(id="b", name="B", score=0.4),
        ],
    )
    result = validate_tree(tree)
    assert result.valid is True
    assert any("has role set" in msg for msg in result.warnings)
