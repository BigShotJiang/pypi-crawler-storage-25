# LogicScore Core vs Runtime Boundary

If it requires a clock, a label, or a policy decision, it belongs in runtime.

## What Lives in Core

- `TreeNode` (including data-carrying fields like `curve`, `role`, `stale_after`)
- `compute_tree`
- `SuitabilityCurve`
- `compute_sensitivity`
- `get_all_leaves`, `get_all_nodes`
- `validate_tree`, `ValidationResult`
- `ugcd_aggregate` and `r_wpm` (internal math)

## What Lives in Runtime

- `evaluate(...)` orchestration over raw inputs
- decision labels and mapping for domain actions/classes
- threshold policy and score-to-action (or score-to-class) rules
- staleness/freshness enforcement and timestamp handling
- domain policy orchestration and stateful adapters

Core is domain-agnostic. Any domain language (finance, healthcare, etc.) belongs in runtime adapters.
