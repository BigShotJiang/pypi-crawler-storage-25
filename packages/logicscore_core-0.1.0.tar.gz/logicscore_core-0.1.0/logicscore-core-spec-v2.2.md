# LogicScore Core — Math Module Specification
**Version:** 2.2.0
**Status:** Authoritative
**Supersedes:** LSP Core Math Module Specification v1.x

This document specifies the complete behavior of the `logicscore-core` Python module.
It is the ground truth for implementation and testing. All other modules import
from `logicscore-core` and must not reimplement any function defined here.

The JavaScript prototype in `lsp-codebase-eval.jsx` is an early reference prototype
and is informative only. The Python implementation follows this specification,
not the JS prototype. The JS prototype should be patched to match this spec.

### Attribution

This library implements the Logic Scoring of Preference (LSP) decision method
developed by Prof. Jozo Dujmović. The UGCD aggregation operator uses polynomial
coefficients derived from Dujmović's numerical approximation of the WPM andness
function:

> Dujmović, J. (2018). *Soft Computing Evaluation Logic: The LSP Decision Method
> and Its Applications.* Wiley-IEEE Press.

---

## 1. Project Setup

### 1.1 Package Manager

This project uses [uv](https://github.com/astral-sh/uv) for package management.

```toml
# pyproject.toml
[project]
name = "logicscore-core"
version = "0.1.0"
requires-python = ">=3.11"
license = { text = "MIT" }
description = "Logic Scoring of Preference — interpretable multi-criteria aggregation"
dependencies = []

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-cov>=5.0",
    "hypothesis>=6.100",
    "mypy>=1.9",
    "ruff>=0.4",
]

[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = "--cov=logicscore --cov-report=term-missing --cov-fail-under=100"

[tool.mypy]
strict = true
files = ["logicscore/"]

[tool.ruff.lint]
select = ["E", "F", "I", "UP", "ANN"]
```

**Setup:**
```bash
uv venv && uv sync --extra dev
```

### 1.2 File Structure

```
logicscore/
└── core/
    ├── __init__.py        ← public exports
    ├── operators.py       ← r_wpm, ugcd_aggregate (internal math)
    ├── tree.py            ← TreeNode dataclass
    ├── aggregation.py     ← compute_tree
    ├── sensitivity.py     ← compute_sensitivity
    ├── traversal.py       ← get_all_leaves, get_all_nodes
    ├── validation.py      ← validate_tree, ValidationResult
    └── suitability.py     ← SuitabilityCurve + presets
tests/
└── core/
    ├── test_aggregation.py
    ├── test_sensitivity.py
    ├── test_validation.py
    └── test_suitability.py
fixtures/
└── ugcd_cases.json        ← numerical ground truth (see Section 9)
```

### 1.3 Verification Pipeline

The following gates must all pass before any commit is merged:

```
ruff check logicscore/          # linting
mypy logicscore/                # strict type checking
pytest                   # unit tests + property tests + fixture verification
                         # coverage gate: 100% line coverage on logicscore/core/
```

**Four verification layers:**

1. **Unit tests** — explicit cases covering every function, every edge case, every error
   condition. Located in `tests/core/`. 100% line coverage enforced.

2. **Property tests (Hypothesis)** — mathematical invariants that must hold for any
   valid input. Integrated into the same test files. Key properties:
   - Monotonicity: increasing α produces equal or lower output for any fixed inputs
   - Weight scale invariance: multiplying all weights by k > 0 changes nothing
   - Output bounds: result always in [0.001, 1.0] for valid non-null inputs
   - Boundary agreement: α=0.5 matches weighted arithmetic mean exactly
   - Single-child passthrough: result equals the one child score exactly

3. **Fixture verification** — `fixtures/ugcd_cases.json` contains 46 pre-computed
   (scores, weights, α) → expected output cases. The test suite loads and runs all
   fixtures with tolerance 1e-9. See Section 9.

4. **Type checking** — `mypy --strict` on all of `logicscore/core/`. No `Any`, no missing
   annotations, no implicit returns.

---

## 2. Operator System

### 2.1 Representation

Operators are stored and passed as **α (andness)**, a float in [0.0, 1.0].

- α = 1.0 → Full Conjunction (min function)
- α = 0.75 → Hard Partial Conjunction
- α = 0.5 → Neutrality (weighted arithmetic mean)
- α = 0.25 → Hard Partial Disjunction
- α = 0.0 → Full Disjunction (max function)

**The internal WPM exponent r is never exposed in any public API.** It is computed
at aggregation time inside `ugcd_aggregate` and is not stored on `TreeNode` or
returned by any public function.

`logicscore-core` exports no named operator constants. Named constants (e.g. `HARD_CONJ = 0.75`)
are defined in the runtime layer (`logicscore-runtime`) and passed as α floats to `logicscore-core`.

### 2.2 n-Dependence (Important)

The aggregation behavior at a given α depends on the number of children n. This is
correct and intentional per Dujmović: α expresses the **logical character** of the
aggregation (andness), not the expected output magnitude. A 4-child node at α=0.75
gets a harder internal r than a 2-child node at α=0.75 — precisely so that the
andness semantics remain consistent across node sizes.

Concretely: `HARD_CONJ` (α=0.75) always means "75% conjunctive" regardless of n,
but the raw output will be lower for nodes with more children because more inputs
create more statistical exposure to low scores. This is expected behavior.

---

## 3. ugcd_aggregate

### 3.1 Signature

```python
def ugcd_aggregate(
    scores: list[float | None],
    weights: list[float],
    alpha: float,
) -> float | None:
    """
    Aggregate scores using the Uniform GCD (UGCD) operator.

    Implements the full Dujmovic UGCD formula with alpha_theta = 0.75.
    The WPM exponent r is computed internally from alpha and len(scores)
    using the r_wpm polynomial (Dujmovic 2018, Fig 2.4.16, Table 2.3.7).
    This function is the single source of numerical truth for all aggregation.

    Args:
        scores:  Child suitability scores in [0.0, 1.0]. None propagates.
        weights: Non-negative relative weights. Normalized internally.
        alpha:   Andness in [0.0, 1.0]. 1.0 = full conjunction, 0.0 = full disjunction.

    Returns:
        Aggregated score in [0.001, 1.0], or None if any score is None,
        scores is empty, or weights sum to zero.

    Note on the 0.001 floor:
        Before computing powers or logarithms, each score is clamped to
        max(score, 0.001). This means true zero output is unreachable from
        ugcd_aggregate. A score of 0.0 and a score of 0.001 are treated
        identically. If hard veto behavior is required (true zero output),
        model it at the suitability mapping layer using a step-function
        SuitabilityCurve, not at the aggregation layer.
    """
```

### 3.2 UGCD Formula

Let n = len(scores), ŵᵢ = wᵢ / Σⱼ wⱼ, x̃ᵢ = max(xᵢ, 0.001).

**α = 1.0 (Full Conjunction):**
$$F = \min(x_1, \ldots, x_n)$$

**α = 0.0 (Full Disjunction):**
$$F = \max(x_1, \ldots, x_n)$$

**α = 0.5 (Neutrality):**
$$F = \sum_{i=1}^{n} \hat{w}_i x_i$$

**0.75 ≤ α < 1.0 (Hard Partial Conjunction):**
$$F = \left(\sum_{i=1}^n \hat{w}_i 	ilde{x}_i^r
ight)^{1/r}, \quad r = r_{\mathrm{wpm}}(lpha, n)$$

**0.5 < α < 0.75 (Soft Partial Conjunction):**
$$F = rac{lpha_	heta - lpha}{lpha_	heta - 	frac{1}{2}} \sum_{i=1}^n \hat{w}_i x_i + rac{lpha - 	frac{1}{2}}{lpha_	heta - 	frac{1}{2}} \left(\sum_{i=1}^n \hat{w}_i 	ilde{x}_i^R
ight)^{1/R}$$

where $R = r_{\mathrm{wpm}}(lpha_	heta, n) = r_{\mathrm{wpm}}(0.75, n)$ is fixed at the threshold.

**α < 0.5 (Disjunctive side — dual symmetry):**
$$F(\mathbf{x}; \mathbf{W}, lpha) = 1 - F(1 - \mathbf{x}; \mathbf{W}, 1 - lpha)$$

where $1 - \mathbf{x} = (1 - x_1, \ldots, 1 - x_n)$.

### 3.3 r_wpm Internal Function

```python
def r_wpm(alpha: float, n: int) -> float:
    """
    Compute WPM exponent r from andness alpha and number of inputs n.

    Internal function. Not exported from logicscore.core. Not part of the public API.
    Polynomial approximation of the WPM andness function.
    Dujmović (2018), Soft Computing Evaluation Logic, Wiley-IEEE Press.
    For n > 5, uses n=5 coefficients (maximum approximation error < 0.09%).

    Args:
        alpha: Andness in (0.0, 1.0). Values at or near 0.0/1.0 return ±1e20.
        n:     Number of inputs. Must be >= 2.

    Returns:
        WPM exponent r. Negative = conjunctive, positive = disjunctive.
        Returns -1e20 for alpha near 1.0, +1e20 for alpha near 0.0.
    """
```

**Coefficients (Dujmović 2018, K=20):**

The polynomial is:
$$r = \frac{0.25 + a_n(\tfrac{1}{2}-\alpha) + b_n(\tfrac{1}{2}-\alpha)^2 + c_n(\tfrac{1}{2}-\alpha)^3 + d_n(\tfrac{1}{2}-\alpha)^4}{\alpha(1-\alpha)}$$

Two coefficient sets per n — select by whether α ≥ 0.5 or α < 0.5:

| n | α range | aₙ | bₙ | cₙ | dₙ | max err % |
|---|---|---|---|---|---|---|
| 2 | α ≥ 0.5 | 1.62481 | 1.26214 | 0.144343 | −0.144343 | 0.00302 |
| 2 | α < 0.5 | 1.65811 | 2.15388 | 8.2844 | 6.16764 | 0.02545 |
| 3 | α ≥ 0.5 | 1.85971 | 1.9532 | −0.17274 | 0.0213069 | 0.00038 |
| 3 | α < 0.5 | 1.95419 | 3.69032 | 10.7073 | 9.46921 | 0.06132 |
| 4 | α ≥ 0.5 | 2.06781 | 1.83246 | 1.99365 | −2.30786 | 0.0505 |
| 4 | α < 0.5 | 2.11034 | 4.4749 | 11.4962 | 10.5552 | 0.0803 |
| 5 | α ≥ 0.5 | 2.09567 | 3.04673 | −0.388745 | 0.0110307 | 0.00255 |
| 5 | α < 0.5 | 2.21868 | 5.0574 | 12.0866 | 11.2383 | 0.08606 |

For n ≥ 6: use n=5 coefficients.

**Boundary guards:** if α < 0.02, return +1e20. If α > 0.98, return −1e20.

Boundary note: Dujmović's original implementation (Fig 2.4.16) uses eps=1e-5.
The n=5 polynomial produces sign-inverted (positive) exponents for α > ~0.989,
making near-boundary hard conjunction behave as disjunction. We widen the guard
to eps=0.02. The practical difference between α=0.98 and α=1.0 is negligible -
both produce near-min() behavior.

### 3.4 Return Value Table

| Condition | Returns |
|---|---|
| scores is empty | None |
| weights sum to zero | None |
| any score is None | None |
| n = 1 | scores[0] directly (no aggregation) |
| α = 1.0 | min(scores) |
| α = 0.0 | max(scores) |
| α = 0.5 | weighted arithmetic mean |
| 0.75 ≤ α < 1.0 | WPM with r_wpm(α, n) |
| 0.5 < α < 0.75 | blend of arithmetic mean and WPM(R=r_wpm(0.75, n)) |
| α < 0.5 | dual of above |

### 3.5 Test Cases

```python
# Null propagation
assert ugcd_aggregate([0.5, None], [1, 1], 0.75) is None

# Empty
assert ugcd_aggregate([], [], 0.5) is None

# Zero weight sum
assert ugcd_aggregate([0.5, 0.5], [0, 0], 0.5) is None

# Pure conjunction: min
assert ugcd_aggregate([0.9, 0.4, 0.7], [1, 1, 1], 1.0) == 0.4

# Pure disjunction: max
assert ugcd_aggregate([0.2, 0.9, 0.4], [1, 1, 1], 0.0) == 0.9

# Neutrality: arithmetic mean
assert abs(ugcd_aggregate([0.3, 0.7], [1, 1], 0.5) - 0.5) < 1e-9

# Single child passthrough
assert ugcd_aggregate([0.7], [1], 0.75) == 0.7

# Weight scale invariance
r1 = ugcd_aggregate([0.6, 0.8], [1, 1], 0.75)
r2 = ugcd_aggregate([0.6, 0.8], [100, 100], 0.75)
assert abs(r1 - r2) < 1e-9

# Hard AND: low score dominates
result = ugcd_aggregate([1.0, 1.0, 0.0], [1, 1, 1], 0.75)
assert result < 0.02  # near-zero due to 0.001 floor, not exactly zero

# 0.001 floor: score=0.0 and score=0.001 are identical
r_zero  = ugcd_aggregate([1.0, 1.0, 0.0],   [1, 1, 1], 0.75)
r_floor = ugcd_aggregate([1.0, 1.0, 0.001], [1, 1, 1], 0.75)
assert abs(r_zero - r_floor) < 1e-12

# Monotonicity: output decreases as alpha increases (more conjunctive)
scores = [0.9, 0.4, 0.7]
results = [ugcd_aggregate(scores, [1,1,1], a) for a in [0.0, 0.25, 0.5, 0.75, 1.0]]
assert all(results[i] >= results[i+1] for i in range(len(results)-1))
```

**Property tests (Hypothesis):**

```python
from hypothesis import given, strategies as st

@given(
    scores=st.lists(st.floats(0.0, 1.0), min_size=1, max_size=8),
    weights=st.lists(st.floats(0.001, 10.0), min_size=1, max_size=8),
    alpha=st.floats(0.0, 1.0),
)
def test_output_bounds(scores, weights, alpha):
    if len(scores) != len(weights):
        return
    result = ugcd_aggregate(scores, weights, alpha)
    if result is not None:
        assert 0.0 <= result <= 1.0

@given(
    scores=st.lists(st.floats(0.001, 1.0), min_size=2, max_size=6),
    weights=st.lists(st.floats(0.001, 10.0), min_size=2, max_size=6),
    k=st.floats(0.001, 1000.0),
    alpha=st.floats(0.0, 1.0),
)
def test_weight_scale_invariance(scores, weights, k, alpha):
    if len(scores) != len(weights):
        return
    r1 = ugcd_aggregate(scores, weights, alpha)
    r2 = ugcd_aggregate(scores, [w * k for w in weights], alpha)
    if r1 is not None and r2 is not None:
        assert abs(r1 - r2) < 1e-9

@given(
    scores=st.lists(st.floats(0.001, 1.0), min_size=2, max_size=6),
    weights=st.lists(st.floats(0.001, 10.0), min_size=2, max_size=6),
    a1=st.floats(0.0, 1.0),
    a2=st.floats(0.0, 1.0),
)
def test_monotonicity(scores, weights, a1, a2):
    if len(scores) != len(weights):
        return
    r1 = ugcd_aggregate(scores, weights, a1)
    r2 = ugcd_aggregate(scores, weights, a2)
    if r1 is not None and r2 is not None and a1 < a2:
        assert r1 >= r2 - 1e-9  # higher alpha = more conjunctive = lower or equal output
```

---

## 4. TreeNode

```python
from dataclasses import dataclass, field
from typing import Optional

@dataclass
class TreeNode:
    """
    A node in an LSP evaluation tree.

    Leaf nodes (children=[]) hold an externally assigned score in [0.0, 1.0].
    Internal nodes hold an operator (alpha) and are scored by compute_tree.
    The operator is stored as alpha (andness in [0.0, 1.0]), not as the
    internal WPM exponent r. r is computed at aggregation time from alpha
    and the number of children.

    The role field is a forward-compatibility stub for Partial Absorption (PA)
    operators (CPA/DPA), planned for v1.1. UGCD ignores this field entirely.
    When PA is implemented, role distinguishes the main input (x, has annihilator)
    from the auxiliary input (y, no annihilator). validate_tree warns if role is
    set on a node whose parent does not use a PA operator.

    The stale_after field overrides the default staleness threshold set on evaluate().
    Set to None to inherit the default. Has no effect when using compute_tree directly.
    """
    id:          str
    name:        str
    weight:      float                        = 1.0
    operator:    float                        = 0.5   # alpha: 0.0=disjunction, 1.0=conjunction
    score:       Optional[float]              = None
    children:    list["TreeNode"]             = field(default_factory=list)
    curve:       Optional["SuitabilityCurve"] = None
    domain_unit: Optional[str]                = None
    role:        Optional[str]                = None  # "main" | "auxiliary" | None — PA stub, ignored by UGCD
    stale_after: Optional[float]              = None  # seconds before score is treated as None; overrides default

    @property
    def is_leaf(self) -> bool:
        """True if this node has no children."""
        return len(self.children) == 0
```

---

## 5. compute_tree

### 5.1 Signature

```python
def compute_tree(node: TreeNode) -> float | None:
    """
    Recursively compute and assign scores for an LSP tree.

    For leaf nodes: returns node.score unchanged.
    For internal nodes: recursively computes all children, then aggregates
    using the node's alpha and children weights, assigns the result to
    node.score, and returns it.

    Side effect: mutates node.score on every internal node in the tree.
    The original leaf scores are not mutated.

    Args:
        node: Root of the tree (or any subtree) to evaluate.

    Returns:
        The computed score for this node, or None if aggregation cannot proceed.

    None propagation rules:
        Conjunctive nodes (alpha >= 0.5): all child scores (including any None)
        are passed directly to ugcd_aggregate. Because ugcd_aggregate returns
        None if any score is None, any None child causes the node to return None.
        Missing mandatory input blocks the aggregation.

        Disjunctive nodes (alpha < 0.5): before calling ugcd_aggregate, filter
        out any children whose computed score is None and collect the weights of
        the surviving children. Call ugcd_aggregate with only the surviving
        (score, weight) pairs — ugcd_aggregate normalizes weights internally, so
        passing the raw surviving weights is correct. If no children survive
        (all scores are None), return None without calling ugcd_aggregate.
    """
```

### 5.2 Test Cases

```python
# Leaf passthrough
leaf = TreeNode(id="a", name="A", score=0.7)
assert compute_tree(leaf) == 0.7

# Arithmetic mean of two equal-weight children
parent = TreeNode(id="root", name="Root", operator=0.5, children=[
    TreeNode(id="a", name="A", score=0.6, weight=1),
    TreeNode(id="b", name="B", score=0.8, weight=1),
])
assert abs(compute_tree(parent) - 0.7) < 1e-9

# Null child propagates to root
parent2 = TreeNode(id="root", name="Root", operator=0.5, children=[
    TreeNode(id="a", name="A", score=0.6, weight=1),
    TreeNode(id="b", name="B", score=None, weight=1),
])
assert compute_tree(parent2) is None

# Hard AND: one zero kills node
parent3 = TreeNode(id="root", name="Root", operator=0.75, children=[
    TreeNode(id="a", name="A", score=1.0, weight=1),
    TreeNode(id="b", name="B", score=1.0, weight=1),
    TreeNode(id="c", name="C", score=0.0, weight=1),
])
assert compute_tree(parent3) < 0.02

# Score mutated in place on internal node
node = TreeNode(id="root", name="Root", operator=0.5, children=[
    TreeNode(id="a", name="A", score=0.5, weight=1),
])
compute_tree(node)
assert node.score == 0.5

# Leaf scores not mutated
leaf_a = TreeNode(id="a", name="A", score=0.6, weight=1)
leaf_b = TreeNode(id="b", name="B", score=0.8, weight=1)
parent4 = TreeNode(id="root", name="Root", operator=0.5, children=[leaf_a, leaf_b])
compute_tree(parent4)
assert leaf_a.score == 0.6
assert leaf_b.score == 0.8

# Disjunctive node: one None child dropped, surviving child renormalized
disjunctive_mixed = TreeNode(id="root", name="Root", operator=0.25, children=[
    TreeNode(id="a", name="A", score=0.8, weight=1),
    TreeNode(id="b", name="B", score=None, weight=1),
])
result_disj = compute_tree(disjunctive_mixed)
assert result_disj is not None
# Only "a" survives; weight renormalizes to 1.0/1.0; result equals ugcd_aggregate([0.8], [1], 0.25)
assert abs(result_disj - 0.8) < 1e-9  # single-child passthrough after filtering

# Disjunctive node: all None children → None
disjunctive_all_none = TreeNode(id="root", name="Root", operator=0.25, children=[
    TreeNode(id="a", name="A", score=None, weight=1),
    TreeNode(id="b", name="B", score=None, weight=1),
])
assert compute_tree(disjunctive_all_none) is None
```

---

## 6. compute_sensitivity

### 6.1 Signature

```python
def compute_sensitivity(
    tree: TreeNode,
    leaf_id: str,
    delta: float = 0.05,
) -> float:
    """
    Compute the sensitivity of the root score to a small increase in a leaf score.

    Sensitivity is the finite-difference derivative:
        delta_i = (score(x + delta * e_i) - score(x)) / delta

    Uses two independent deep copies of the tree. The original tree is never mutated.

    Args:
        tree:    Root of the tree to evaluate. Not mutated.
        leaf_id: ID of the leaf node to perturb.
        delta:   Perturbation size. Default 0.05. Must be positive.

    Returns:
        The sensitivity as a float. Returns 0.0 if:
        - The leaf with leaf_id is not found in the tree
        - The leaf's current score is None
        - The base root score is None
        High sensitivity means this leaf is the primary bottleneck.
    """
```

### 6.2 Behavior

1. Deep-copy tree twice (`copy.deepcopy`) — both from the original
2. Compute base root score on copy 1 via `compute_tree`
3. If base score is None or leaf score is None → return 0.0
4. Find leaf in copy 2, set its score to `min(leaf.score + delta, 1.0)`
5. Compute new root score on copy 2 via `compute_tree`
6. Return `(new_score - base_score) / delta`

### 6.3 Test Cases

```python
# Higher weight → higher sensitivity
tree = TreeNode(id="root", name="Root", operator=0.5, children=[
    TreeNode(id="a", name="A", score=0.5, weight=3),
    TreeNode(id="b", name="B", score=0.5, weight=1),
])
assert compute_sensitivity(tree, "a") > compute_sensitivity(tree, "b")

# Leaf at ceiling → near-zero sensitivity
tree2 = TreeNode(id="root", name="Root", operator=0.5, children=[
    TreeNode(id="a", name="A", score=1.0, weight=1),
    TreeNode(id="b", name="B", score=0.5, weight=1),
])
assert compute_sensitivity(tree2, "a") < 0.01

# Does not mutate original tree
tree3 = TreeNode(id="root", name="Root", operator=0.5, children=[
    TreeNode(id="a", name="A", score=0.5, weight=1),
])
compute_sensitivity(tree3, "a")
assert tree3.children[0].score == 0.5

# Missing leaf → 0.0
assert compute_sensitivity(tree, "nonexistent") == 0.0

# None leaf score → 0.0
tree4 = TreeNode(id="root", name="Root", operator=0.5, children=[
    TreeNode(id="a", name="A", score=None, weight=1),
    TreeNode(id="b", name="B", score=0.5, weight=1),
])
assert compute_sensitivity(tree4, "a") == 0.0
```

---

## 7. get_all_leaves and get_all_nodes

```python
def get_all_leaves(node: TreeNode) -> list[TreeNode]:
    """
    Return all leaf nodes in depth-first order. Non-mutating.

    A leaf is any node with no children (node.is_leaf == True).
    """

def get_all_nodes(node: TreeNode) -> list[TreeNode]:
    """
    Return all nodes (leaf and internal) in depth-first order. Non-mutating.
    """
```

Both functions are non-mutating and operate recursively.

---

## 8. validate_tree

### 8.1 Types

```python
@dataclass
class ValidationResult:
    """
    Result of validate_tree. Always produced — never raises.

    Attributes:
        valid:             False if any error-level issue was found.
        errors:            Blocking issues. Tree must not be executed if non-empty.
        warnings:          Non-blocking issues worth logging.
        effective_weights: node_id → weight as percentage of its sibling total.
    """
    valid:             bool
    errors:            list[str]
    warnings:          list[str]
    effective_weights: dict[str, float]

def validate_tree(node: TreeNode) -> ValidationResult:
    """
    Validate the structure and configuration of an LSP tree.

    Checks are divided into errors (block execution) and warnings (log, allow).
    effective_weights is always computed regardless of validity.

    Args:
        node: Root of the tree to validate.

    Returns:
        ValidationResult with all findings.
    """
```

### 8.2 Checks

**Errors (block execution):**
- Any `weight <= 0` anywhere in the tree
- Internal node with zero children
- Duplicate `node.id` anywhere in the tree
- Circular reference (node is its own ancestor)
- `operator` outside [0.0, 1.0]

**Warnings (log, allow):**
- Leaf `score` outside [0.0, 1.0]
- Leaf `score` is None at evaluation time
- Any subtree node with exactly one child
- `operator` not one of {0.0, 0.25, 0.5, 0.75, 1.0} (custom fine-tuning)
- `role` is set on any node (PA not yet implemented — role is ignored by UGCD)

**Always computed:**
- `effective_weights`: each node's weight as a percentage of its siblings' total weight

---

## 9. SuitabilityCurve

```python
class SuitabilityCurve:
    """
    Piecewise linear suitability mapping from raw input domain to [0.0, 1.0].

    Stores a list of (x, y) control points. Evaluates via linear interpolation.
    Values outside the declared x domain are clamped to the nearest endpoint y value.
    All control point y values must be in [0.0, 1.0].
    Control points must be sorted by x ascending.
    At least 2 control points required.

    Factory methods return a SuitabilityCurve with pre-populated control points
    that can be inspected and edited via the .control_points attribute.
    This makes them suitable as starting points for an interactive curve editor.
    """

    def __init__(self, control_points: list[tuple[float, float]]) -> None:
        """
        Args:
            control_points: List of (x, y) pairs. At least 2. Sorted by x ascending.
                            y values must be in [0.0, 1.0].
        Raises:
            ValueError: If fewer than 2 points, unsorted x, or y outside [0.0, 1.0].
        """

    def __call__(self, raw: float) -> float:
        """
        Apply the curve to a raw input value.

        Uses linear interpolation between control points.
        Clamps output to [0.0, 1.0].
        Values below the first x are clamped to the first y.
        Values above the last x are clamped to the last y.
        """

    @classmethod
    def linear(
        cls,
        domain: tuple[float, float],
        low_suitability: float = 0.0,
        high_suitability: float = 1.0,
    ) -> "SuitabilityCurve":
        """
        Monotone linear mapping. Two control points: (domain[0], low) and (domain[1], high).
        """

    @classmethod
    def step(
        cls,
        threshold: float,
        below: float = 1.0,
        above: float = 0.0,
    ) -> "SuitabilityCurve":
        """
        Step function. Two adjacent control points at threshold with values below and above.
        Implemented as [(threshold - epsilon, below), (threshold, above)].
        """

    @classmethod
    def inverted_u(
        cls,
        peak: float,
        width: float,
        peak_suitability: float = 1.0,
        base_suitability: float = 0.0,
    ) -> "SuitabilityCurve":
        """
        Inverted-U (tent) shape. Optimal value at peak, falling to base at peak ± width/2.
        Three control points: (peak - width/2, base), (peak, peak_suitability), (peak + width/2, base).
        """

    @classmethod
    def s_curve(
        cls,
        midpoint: float,
        steepness: float = 10.0,
        n_points: int = 20,
    ) -> "SuitabilityCurve":
        """
        S-curve (sigmoid approximation). Slow ramp, steep middle climb, levels off.
        Samples the logistic function 1/(1+exp(-steepness*(x-midpoint))) at n_points
        evenly spaced across [midpoint - 3/steepness, midpoint + 3/steepness],
        producing a piecewise linear approximation. Clamped to [0.0, 1.0].
        """
```

### 9.1 Test Cases

```python
# Interpolation
c = SuitabilityCurve([(0.0, 1.0), (0.1, 0.0)])
assert c(0.0) == 1.0
assert c(0.1) == 0.0
assert abs(c(0.05) - 0.5) < 1e-6

# Clamping below domain
assert c(-1.0) == 1.0

# Clamping above domain
assert c(1.0) == 0.0

# Step function
s = SuitabilityCurve.step(threshold=0.5, below=1.0, above=0.0)
assert s(0.4) == 1.0
assert s(0.6) == 0.0

# Inverted-U
u = SuitabilityCurve.inverted_u(peak=10.0, width=4.0)
assert u(10.0) == 1.0
assert u(8.0) == 0.0    # peak - width/2 = 8.0
assert u(12.0) == 0.0   # peak + width/2 = 12.0
assert u(5.0) == 0.0    # clamped below domain

# Linear preset
l = SuitabilityCurve.linear(domain=(0.0, 100.0))
assert l(0.0) == 0.0
assert l(100.0) == 1.0
assert abs(l(50.0) - 0.5) < 1e-6

# Validation: too few points
try:
    SuitabilityCurve([(0.0, 1.0)])
    assert False, "should raise"
except ValueError:
    pass

# Validation: unsorted x
try:
    SuitabilityCurve([(0.5, 1.0), (0.1, 0.0)])
    assert False, "should raise"
except ValueError:
    pass

# Validation: y out of range
try:
    SuitabilityCurve([(0.0, 1.5), (1.0, 0.0)])
    assert False, "should raise"
except ValueError:
    pass

# Factory outputs are editable control points
u2 = SuitabilityCurve.inverted_u(peak=10.0, width=4.0)
assert isinstance(u2.control_points, list)
assert len(u2.control_points) == 3
```

---

## 10. Module Exports

```python
# logicscore/core/__init__.py

from .tree        import TreeNode
from .aggregation import compute_tree
from .sensitivity import compute_sensitivity
from .traversal   import get_all_leaves, get_all_nodes
from .validation  import validate_tree, ValidationResult
from .suitability import SuitabilityCurve
```

**Not exported (internal only):** `r_wpm`, `ugcd_aggregate`, `r_to_alpha`.

These are internal implementation details. External callers use `compute_tree`
and `ugcd_aggregate` is not called directly.

---

## 11. Numerical Precision

- All computation uses Python `float` (IEEE 754 double precision)
- Must match fixture file `fixtures/ugcd_cases.json` within tolerance 1e-9
- The 0.001 floor in `ugcd_aggregate` is fixed and not configurable
- `copy.deepcopy` is the correct mechanism for `compute_sensitivity`
- No external numerical libraries required — `math` stdlib only

---

## 12. Numerical Fixtures

The file `fixtures/ugcd_cases.json` contains 46 pre-computed test cases.
The full test suite loads this file and asserts all cases within their stated tolerance.
Cases with `"expected": null` assert the return value is `None`.
Cases with `"assert_lt"` additionally assert the result is less than that value.

Generated from the verified Python implementation of `ugcd_corrected` in this spec.
The fixture file is the numerical ground truth for cross-language implementations.

Key fixture groups:
- Null / empty / zero-weight cases (3 cases)
- Pure conjunction / disjunction boundary (2 cases)
- Neutrality / arithmetic mean (1 case)
- Single child passthrough (1 case)
- Weight scale invariance (12 cases)
- Hard AND dominance (3 cases)
- Monotonicity series (10 cases)
- n-dependence (4 cases)
- 0.001 floor equivalence (2 cases)
- Blend region boundary continuity (8 cases)
