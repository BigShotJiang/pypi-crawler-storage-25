# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.1.0] - 2026-04-02

### Added

- Initial release of LogicScore Core.
- UGCD aggregation and recursive tree evaluation.
- Suitability curves, validation, sensitivity analysis, and traversal utilities.
- Strict test suite with a 100% coverage gate.

### Fixed

- Monotonicity edge case for constant inputs by aligning endpoint handling and idempotent aggregation behavior across operator branches.
