import json
import uuid
from typing import List, Optional

from fastmcp import FastMCP
from pydantic import BaseModel, Field

from WdtClient import WdtClient
import os

mcp = FastMCP("ErpApiService")


def get_client():
    appkey = os.getenv("WDT_APPKEY")
    secret = os.getenv("WDT_APPSECRET")
    sid = os.getenv("WDT_SID")

    if not all([appkey, secret, sid]):
        raise ValueError("Missing WDT environment variables")

    return WdtClient(
        appkey,
        secret,
        sid,
        os.getenv("WDT_BASE_URL", "https://api.wangdian.cn/openapi2/")
    )


@mcp.tool()
def get_erp_warehouse(warehouse_no: str = Field("", description="仓库编号"),
                      page_size: str = Field("100", description="分页大小,默认为100"),
                      page_no: str = Field("0", description="页号，默认从0页开始")):
    """用于获取旺店通内所有仓库信息"""
    t = get_client()
    params = {}
    params.update({"warehouse_no": warehouse_no})
    params.update({"page_size": page_size})
    params.update({"page_no": page_no})
    response = t.execute("warehouse_query.php", params)
    data = json.loads(response)
    return data


@mcp.tool()
def get_erp_purchase_provider(provider_no: str = Field("", description="供应商编号"),
                              provider_name: str = Field("", description="供应商名称"),
                              page_size: str = Field("100", description="分页大小,默认为100"),
                              page_no: str = Field("0", description="页号，默认从0页开始")):
    """用于获取旺店通内供货商信息"""
    t = get_client()
    params = {}
    params.update({"column": "provider_no,provider_name"})
    params.update({"provider_no": provider_no})
    params.update({"provider_name": provider_name})
    params.update({"page_size": page_size})
    params.update({"page_no": page_no})
    response = t.execute("purchase_provider_query.php", params)
    data = json.loads(response)
    return data


@mcp.tool()
def get_erp_stock(warehouse_no: str = Field(..., description="仓库编号"),
                  barcode: str = Field(..., description="条形码")):
    """根据仓库编号和条形码获取erp内指定商品数据"""
    t = get_client()
    params = {
        "warehouse_no": warehouse_no,
        "barcode": barcode,
    }
    response = t.execute("stock_query_detail.php", params)
    data = json.loads(response)
    return data


class PurchaseOrderDetail(BaseModel):
    spec_no: str = Field(..., description="商品规格编号")
    num: str = Field(..., description="数量")
    price: float = Field(..., description="单价")


@mcp.tool()
def erp_purchase_order_push(
        provider_no: str = Field(..., description="供应商编号，例如 '001'。"),
        warehouse_no: str = Field(..., description="仓库编号，例如 'aiyi2test'。"),
        details_list: List[PurchaseOrderDetail] = Field(..., description="采购明细列表，包含具体商品信息"),
        purchase_name: Optional[str] = Field(None, description="采购人名称，可选"),
        remark: Optional[str] = Field(None, description="备注，可选")
):
    """
    用于创建采购入库单，包含供应商、仓库、采购单名称、备注及商品明细列表。
    注意：
    - details_list 中每项必须包含 spec_no、num、price
    """
    t = get_client()
    compact_id = uuid.uuid4().hex
    purchase_info = {
        "outer_no": compact_id,
        "provider_no": provider_no,
        "warehouse_no": warehouse_no,
        "purchase_name": purchase_name or "",
        "remark": remark or "",
        "details_list": [item.model_dump() for item in details_list]
    }

    jsonArr = json.dumps(purchase_info, ensure_ascii=False)
    print(jsonArr)

    params = {
        "purchase_info": jsonArr
    }
    response = t.execute("purchase_order_push.php", params)
    return f"采购单开单完成，接口返回：{response}"


def main():
    mcp.run(transport="http", port=8000)

if __name__ == "__main__":
    main()
