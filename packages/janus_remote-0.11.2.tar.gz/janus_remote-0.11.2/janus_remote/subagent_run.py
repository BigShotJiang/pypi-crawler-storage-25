#!/usr/bin/env python3
"""
Subagent runner for janus-remote.

Used by Janus app's SshTransport (Phase 2.8) to dispatch a non-interactive
claude sub-agent on a remote machine over SSH. The local Janus reverse-tunnels
its WebSocket bridge port (9473) into the remote so this script can dial back
to the user's local janusapp for approvals and status.

Flow:
  Local janusapp                                  Remote box
  ──────────────                                  ──────────
  ssh -R <port>:localhost:9473 user@host          janus-remote subagent-run
    janus-remote subagent-run \\                    --bridge-port <port>
      --bridge-port <port> \\                       --janus-title subagent-X
      --janus-title subagent-X \\                   --dep-path /path
      --janus-session-id <uuid> \\                  -- -p --output-format=stream-json
      --dep-path /path \\                              [--resume <sid>] '<query>'
      -- -p --output-format=stream-json '<query>'
                                                     │
                                                     ├─ WS dial → ws://localhost:<port>
                                                     │  (reverse-tunneled to local janusapp)
                                                     │
                                                     └─ spawns claude in --dep-path
                                                        stdout (stream-json) ──ssh──► local
                                                        approval hook → .req.json
                                                        watcher forwards via WS
                                                        local approves → .res.json → unblock

Outputs claude's stream-json on stdout (the SSH stdout, which janusapp parses).
All janus-remote logging goes to stderr to avoid corrupting the JSON stream.
"""

import sys
import os
import time
import shutil
import argparse
import subprocess
import signal


def _find_claude():
    """Find the claude binary location on the remote machine."""
    p = shutil.which('claude')
    if p:
        return p
    for candidate in [
        '/usr/local/bin/claude',
        '/opt/homebrew/bin/claude',
        os.path.expanduser('~/.local/bin/claude'),
        os.path.expanduser('~/bin/claude'),
        '/usr/bin/claude',
        os.path.expanduser('~/.npm-global/bin/claude'),
    ]:
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _stderr(msg):
    """Logging that doesn't corrupt the stream-json on stdout."""
    sys.stderr.write(f"[subagent-run] {msg}\n")
    sys.stderr.flush()


def main(argv=None):
    """Entry point for `janus-remote subagent-run`.

    `argv` is the list of args AFTER the `subagent-run` token. The cli.py
    dispatcher strips that token and hands us the remainder.
    """
    if argv is None:
        argv = sys.argv[1:]

    parser = argparse.ArgumentParser(
        prog='janus-remote subagent-run',
        description='Non-interactive claude sub-agent runner for SSH-dispatched Janus deps.',
    )
    parser.add_argument('--bridge-port', type=int, required=True,
                        help='Local TCP port (reverse-tunneled) to dial for the WS bridge.')
    parser.add_argument('--janus-title', required=True,
                        help='JANUS_TITLE for the spawned claude (must start with subagent-).')
    parser.add_argument('--janus-session-id', required=True,
                        help='JANUS_SESSION_ID for routing approvals back to this sub-agent.')
    parser.add_argument('--janus-subagent-dep-id', default='',
                        help='JANUS_SUBAGENT_DEP_ID — read by the hook to load sub-agent profile/memory.')
    parser.add_argument('--dep-path', required=True,
                        help='Working directory on the remote (the dep path).')
    parser.add_argument('claude_args', nargs=argparse.REMAINDER,
                        help='Args after `--` are forwarded verbatim to claude.')
    args = parser.parse_args(argv)

    # argparse.REMAINDER includes the leading `--` token if present; drop it.
    claude_args = args.claude_args
    if claude_args and claude_args[0] == '--':
        claude_args = claude_args[1:]

    cwd = os.path.expanduser(args.dep_path)
    if not os.path.isdir(cwd):
        _stderr(f"dep path missing or not a directory: {args.dep_path}")
        sys.exit(2)

    claude_path = _find_claude()
    if not claude_path:
        _stderr("claude binary not found in PATH or common locations")
        sys.exit(127)

    # Set Janus env BEFORE importing pty_capture — it captures JANUS_TITLE at
    # module-load time for title-filter behavior (harmless here, but consistent).
    os.environ['JANUS_TITLE'] = args.janus_title
    os.environ['JANUS_SESSION_ID'] = args.janus_session_id
    if args.janus_subagent_dep_id:
        os.environ['JANUS_SUBAGENT_DEP_ID'] = args.janus_subagent_dep_id

    # Import lazily so the `--help` path doesn't require websocket-client.
    try:
        from .pty_capture import RemotePasteClient, HookApprovalWatcher
    except ImportError as e:
        _stderr(f"failed to import janus-remote internals: {e}")
        sys.exit(3)

    # Sub-agent variant: no TTY → no keystroke injection. The .res.json file
    # written by RemotePasteClient._handle_message (queue-dir flow) is what
    # actually unblocks the hook; the inject is a no-op in this context.
    class SubagentApprovalClient(RemotePasteClient):
        def _inject_approval_response(self, action):
            self.pending_approval = None

        def _inject_text(self, text):
            return  # no TTY to paste into

    client = SubagentApprovalClient(master_fd=None, port=args.bridge_port)
    client.start()

    watcher = HookApprovalWatcher(client)
    watcher.start()

    # Wait for the WS bridge to register before spawning claude — otherwise a
    # tool-use that fires immediately would miss the approval forwarding window
    # and time out at the hook's 5-minute deny default. ~10s ceiling handles
    # cold SSH connections / slow networks; happy path returns in ~50ms.
    deadline = time.time() + 10
    while not client.connected and time.time() < deadline:
        time.sleep(0.05)
    if not client.connected:
        _stderr("warning: WS bridge not connected after 10s; approvals may time out")

    proc = subprocess.Popen(
        [claude_path] + list(claude_args),
        cwd=cwd,
        env=os.environ.copy(),
        stdin=subprocess.DEVNULL,
        # stdout/stderr inherited from this process → flow up SSH to janusapp.
    )

    def _forward_signal(signum, _frame):
        try:
            proc.send_signal(signum)
        except Exception:
            pass

    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        try:
            signal.signal(sig, _forward_signal)
        except Exception:
            pass

    try:
        rc = proc.wait()
    except KeyboardInterrupt:
        try:
            proc.terminate()
            rc = proc.wait(timeout=5)
        except Exception:
            rc = 130
    finally:
        watcher.stop()
        client.running = False
        try:
            if client.ws:
                client.ws.close()
        except Exception:
            pass

    sys.exit(rc)


if __name__ == '__main__':
    main()
