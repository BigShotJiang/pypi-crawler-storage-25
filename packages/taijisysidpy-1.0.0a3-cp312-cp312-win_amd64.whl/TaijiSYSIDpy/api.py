import traceback
from TaijiSYSIDpy.api_data_model import IdentInput, TestDesignInput, TestDesignOutput 
from TaijiSYSIDpy.onlineident import onlineident
from TaijiSYSIDpy.estdelayon_multi import estdelayon
from TaijiSYSIDpy.testdesign import testdesign


def mlfOnlineident(inp: IdentInput) -> tuple[str, str | None]:
    try:
        Message, token = onlineident(**inp.model_dump())
    except Exception as e:
        error_msg = traceback.format_exc()
        print(f"Error in onlineident:\n{error_msg}")
        Message = error_msg 
        token = None
    return Message, token


def mlfEstdelayon(inp: IdentInput) -> tuple[str, IdentInput]:
    try:
        required_fields = {
            'MVdata', 'MVname', 'CVdata', 'CVname', 
            'CVslice', 'CV_INT', 'Tfactor', 'Expect', 'use_expect', 'export_file'
        }
        params = inp.model_dump(include=required_fields)
        Message, Delay = estdelayon(**params)
        new_inp = inp.model_copy(update={"Delay": Delay})
        return Message, new_inp

    except Exception:
        error_msg = traceback.format_exc()
        print(f"Error in estdelayon:\n{error_msg}")
        new_inp = inp.model_copy(update={"Delay": None})
        return error_msg, new_inp   
    

def mlfTestdesign(inp:TestDesignInput) -> tuple[str, TestDesignOutput]:
    try:
        required_fields = {
            'n_signal', 'T2ST'
        }
        params = inp.model_dump(include=required_fields)
        Message, TestSig, R, Ntest = testdesign(**params)
        output = TestDesignOutput(
            TestSig=TestSig,
            R=R,
            Ntest=Ntest
        )
        return Message, output

    except Exception:
        error_msg = traceback.format_exc()
        print(f"Error in testdesign:\n{error_msg}")
        output = TestDesignOutput(
            TestSig=None,
            R=None,
            Ntest=0
        )
        return error_msg, output




