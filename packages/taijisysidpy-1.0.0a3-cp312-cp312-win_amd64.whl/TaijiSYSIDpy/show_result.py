import matplotlib.pyplot as plt
from matplotlib import gridspec 
import matplotlib as mpl

from TaijiSYSIDpy.api_data_model import IdentInput, IdentOutput

def set_plot_style():
    mpl.rcParams.update({
        'figure.facecolor': 'w',
        'axes.grid': True,
        'axes.labelsize': 12,
        'axes.titlesize': 13,
        'legend.fontsize': 11,
        'xtick.labelsize': 10,
        'ytick.labelsize': 10,
        'lines.linewidth': 1.3
    })

def plot_stp(output: IdentOutput, stp_len = 300):    
    nu = output.B.shape[1]
    ny = output.C.shape[0]

    fig = plt.figure(figsize=(min(15, nu*3), min(12, ny*2.5)), 
                     tight_layout=True) 
    gs = gridspec.GridSpec(ny, nu) 
    for cv_i in range(ny):
        for mv_j in range(nu):
            fig_number = cv_i * nu + mv_j
            ax = plt.subplot(gs[fig_number])
            if cv_i == 0:
                ax.set_title(f'MV{mv_j+1}({output.MVname[mv_j]})')
            if mv_j == 0:
                ax.set_ylabel(f'CV{cv_i+1}({output.CVname[cv_i]})')
                
            stp = output.STP[0:stp_len, fig_number]
            grade = output.Grade[cv_i, mv_j].strip()
            gain = output.Gain[cv_i, mv_j]
            delay = output.Delay[cv_i, mv_j]
            if not grade:
                continue
            ax.plot(stp)
            ax.text(0.5, 0.5, 
                    f'Gain: {gain:.3f}\nDelay: {delay}\nGrade: {grade}', 
                    transform=ax.transAxes, 
                    fontsize=12, 
                    ha='center', 
                    va='center', 
                    color='black', 
                    alpha=1.0)
            
def plot_frq(output: IdentOutput):    
    nu = output.B.shape[1]
    ny = output.C.shape[0]

    fig = plt.figure(figsize=(min(15, nu*3), min(12, ny*2.5)), 
                     tight_layout=True) 
    gs = gridspec.GridSpec(ny, nu) 
    legend_flag = False
    for cv_i in range(ny):
        for mv_j in range(nu):
            fig_number = cv_i * nu + mv_j
            ax = plt.subplot(gs[fig_number])
            if cv_i == 0:
                ax.set_title(f'MV{mv_j+1}({output.MVname[mv_j]})')
            if mv_j == 0:
                ax.set_ylabel(f'CV{cv_i+1}({output.CVname[cv_i]})')
                
            frq = output.FRQ[:, fig_number]
            bnd = output.BND[:, fig_number]
            
            grade = output.Grade[cv_i, mv_j].strip()
            gain = output.Gain[cv_i, mv_j]
            delay = output.Delay[cv_i, mv_j]
            
            if grade:
                ax.semilogx(output.w[101:], frq[101:], label='FRQ')
                ax.semilogx(output.w[101:], bnd[101:], label='BND')
                ax.text(0.5, 0.5, 
                        f'Gain: {gain:.3f}\nDelay: {delay}\nGrade: {grade}', 
                        transform=ax.transAxes, 
                        fontsize=12, 
                        ha='center', 
                        va='center', 
                        color='black', 
                        alpha=1.0)
                if not legend_flag:
                    ax.legend(loc='upper right')
                    legend_flag = True
                    
def plot_cvsim(output: IdentOutput, input: IdentInput):    

    ny = output.C.shape[0]

    fig = plt.figure(figsize=(15, min(12, ny*2.5)), 
                     tight_layout=True) 
    gs = gridspec.GridSpec(ny, 1) 
    legend_flag = False
    for cv_i in range(ny):
        fig_number = cv_i
        ax = plt.subplot(gs[fig_number])


        
        cv_curve = input.CVdata[:, cv_i]    
        cv_sim = output.CVsim[:, cv_i]
        cv_error = output.CVError[cv_i]
        cv_slice = input.CVslice[cv_i]
        cv_name = input.CVname[cv_i]
        
        ax.plot(cv_curve, label='Measured CV')
        ax.plot(cv_sim, label='Simulated CV')
        ax.set_title(f'CV{cv_i+1}({cv_name}) SimError: {cv_error:.2f}%')
        
        
        for s1, s2 in cv_slice:
            if s1 < 0 or s2 < 0:
                continue
            ax.axvspan(s1, s2, color='gray', alpha=0.7)

        if not legend_flag:
            ax.legend(loc='upper right')
            legend_flag = True