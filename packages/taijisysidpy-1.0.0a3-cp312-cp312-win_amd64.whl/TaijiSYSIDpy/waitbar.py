
def waitbar(progress: float):
    if 0 <= progress <= 100:
        print(f"Progress: {progress:.2f}%")
        
        
def waitbar_delta(delta_progress: float):
    """辅助函数，用于 joblib 并行中的进度报告。"""
    print(f"[callback] delta_progress: {delta_progress:.2f}%")
        
