from typing import Annotated, Any, Callable
import numpy as np
from pydantic import BaseModel, Field, ConfigDict, model_validator, BeforeValidator
import io
import traceback
import base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

def create_matrix_validator(target_dtype: np.dtype, check_finite: bool = False) -> Callable[[Any], np.ndarray | None]:
    """
    工厂函数：生成一个针对特定 dtype 的矩阵标准化验证函数。
    
    Args:
        target_dtype: 目标 Numpy 类型 (如 np.float64, np.int32)
        check_finite: 是否检查 NaN/Inf (通常用于浮点数)
    """
    
    def validator(v: Any) -> np.ndarray | None:
        if v is None:
            return None

        # --- 1. 类型转换 ---
        try:
            arr = np.array(v, dtype=target_dtype)
        except (ValueError, TypeError):
            # 获取类型名称用于报错信息 (如 'float64', 'int32')
            dtype_name = np.dtype(target_dtype).name 
            raise ValueError(f"输入数据无法转换为 {dtype_name} 矩阵。")

        # --- 2. 维度标准化 ---
        if arr.ndim == 0:
            arr = arr.reshape(1, 1)
        elif arr.ndim == 1:
            arr = arr.reshape(-1, 1)
        elif arr.ndim > 2:
            raise ValueError(f"不支持 3D+ 数组，当前维度: {arr.ndim}")

        # --- 3. 内存连续化 ---
        if not arr.flags['C_CONTIGUOUS']:
            arr = np.ascontiguousarray(arr)

        # --- 4. (可选) 数值健康检查 ---
        # 仅当 check_finite=True 时执行
        if check_finite:
            if not np.isfinite(arr).all():
                 raise ValueError("输入矩阵包含 NaN (空值) 或 Inf (无穷大)，请先清洗数据。")

        return arr

    return validator

# --- 定义类型 ---

# 1. 浮点2D矩阵：float64 + 开启 NaN 检查
floatMatrix = Annotated[
    np.ndarray, 
    BeforeValidator(create_matrix_validator(np.float64, check_finite=True)), 
]

# 2. 整数2D矩阵：int32 + 关闭 NaN 检查
intMatrix = Annotated[
    np.ndarray,
    BeforeValidator(create_matrix_validator(np.int32, check_finite=False)),
]

# 3. 字符串2D矩阵：str 类型 + 关闭 NaN 检查
strMatrix = Annotated[
    np.ndarray, 
    BeforeValidator(create_matrix_validator(np.str_, check_finite=False)), 
]

# --- 辨识/时延函数输入模型 ---
class IdentInput(BaseModel):

    model_config = ConfigDict(arbitrary_types_allowed=True)

    # 数据部分
    MVdata: floatMatrix = Field(..., description="MV data matrix at current time")
    CVdata: floatMatrix = Field(..., description="CV data matrix at current time")
    MVname: list[str] | None = Field(None, description="MV tagnames, string matrix, names in rows")
    CVname: list[str] | None = Field(None, description="CV tagnames, string matrix, names in rows")
    MVsize: floatMatrix | None = Field(None, description="Step sizes of each MVs at each sampling time")
    CV_INT: list[int] | None = Field(None, description="Vector indicating an integral CV. 1 = integral, 0 = not. Most are zeros")
    CV_MVVALV: list[int] | None = Field(None, description="Vector indicating a CV is an MV Valv. 1 = MV Valve, 0 = not. Most are zeros")
    CVslice: list[list[list[int]]] | None = Field(None, description="Matrix of CV slice indexes")
    Ntest: int | None = Field(None, description="Planned test length in samples")
    Tident: int | None = Field(None, description="Model sampling time")
    Tunit: str | None = Field(None, description="Time unit")
    Delay: intMatrix | None = Field(None, description="Matrix of io-delays (in samples)")
    Expect: intMatrix | None = Field(None, description="Expectation matrix")
    Tfactor: int | None = Field(None, description="Down sampling factor")
    use_expect: bool | None = Field(None, description="Whether to use Expectation matrix")
    export_file: bool | None = Field(None, description="Whether to export file for debuging")
   
    @model_validator(mode='after')
    def check_dimensions(self) -> 'IdentInput':  
        n_samples_mv, n_mv = self.MVdata.shape
        n_samples_cv, n_cv = self.CVdata.shape
        if n_samples_cv != n_samples_mv:
            raise ValueError(
                f"MVdata 和 CVdata 的样本数必须相同，"
                f"但 MVdata 有 {n_samples_mv} 行，"
                f"CVdata 有 {n_samples_cv} 行。"
            )
        N = n_samples_mv  # 总样本数
        if N < 400:
            raise ValueError(f"样本数过少，至少需要 400 个样本，当前只有 {N} 个样本。")

        if self.MVname is None:
            self.MVname = [f"MV_{i+1}" for i in range(n_mv)]
        
        if len(self.MVname) != n_mv:
            raise ValueError(
                f"MV维度冲突: MVdata 有 {n_mv} 列, "
                f"但 MVname 指定了 {len(self.MVname)} 个变量。"
            )
        
        if self.CVname is None:
            self.CVname = [f"CV_{i+1}" for i in range(n_cv)]
            
        if len(self.CVname) != n_cv:
            raise ValueError(
                f"CV维度冲突: CVdata 有 {n_cv} 列, "
                f"但 CVname 指定了 {len(self.CVname)} 个变量。"
            )
            
        if self.MVsize is None:
            self.MVsize = np.ones_like(self.MVdata, dtype=float)
            
        if self.MVsize.shape[1] != n_mv:
            raise ValueError(f"MVsize 列数 ({self.MVsize.shape[1]}) 与 MV 数量 ({n_mv}) 不符。")
        
        if self.CV_INT is None:
            self.CV_INT = [0] * n_cv
            
        if len(self.CV_INT) != n_cv:
            raise ValueError(f"CV_INT 长度 ({len(self.CV_INT)}) 与 CVname 数量 ({n_cv}) 不一致。")
            
        if self.CV_MVVALV is None:
            self.CV_MVVALV = [0] * n_cv
            
        if len(self.CV_MVVALV) != n_cv:
            raise ValueError(f"CV_MVVALV 长度 ({len(self.CV_MVVALV)}) 与 CVname 数量 ({n_cv}) 不一致。")
            
        if self.Delay is None:
            self.Delay = np.ones((n_cv, n_mv), dtype=np.int32)
            
        if self.Delay.shape != (n_cv, n_mv):
            raise ValueError(f"Delay 矩阵尺寸应为 ({n_cv}, {n_mv})，但实际为 {self.Delay.shape}。")

        if self.Expect is None:
            self.Expect = np.ones((n_cv, n_mv), dtype=np.int32)
            
        if self.Expect.shape != (n_cv, n_mv):
            raise ValueError(f"Expect 矩阵尺寸应为 ({n_cv}, {n_mv})，但实际为 {self.Expect.shape}。")

        if self.Tfactor is None:
            self.Tfactor = 1
        
        if self.Tfactor < 1:
            raise ValueError("Tfactor must be at least 1")

        if self.use_expect is None:
            self.use_expect = False
            
        if self.export_file is None:
            self.export_file = False
            
        if self.CVslice is None:
            self.CVslice = [[[ -1, -1 ]] for _ in range(n_cv)]
            

        if len(self.CVslice) != n_cv:
            raise ValueError(f"CVslice 长度 ({len(self.CVslice)}) 与 CV 数量 ({n_cv}) 不一致。")
        
        for cv_slice in self.CVslice:
            if not isinstance(cv_slice, list):
                raise ValueError("CVslice 的每个元素必须是一个列表。")
            for sl in cv_slice:
                if not (isinstance(sl, list) and len(sl) == 2):
                    raise ValueError("CVslice 中的每个切片必须是一个包含两个整数的列表。")  

        if self.Tident is None or self.Tident <= 0:
            self.Tident = 1
            
        if self.Tunit is None or self.Tunit.strip() == "":
            self.Tunit = "min"
            
        if self.Ntest is None or self.Ntest <= 0:
            self.Ntest = min(2000, N // 2)
            
        return self
    
# --- 辨识函数输出模型 ---
class IdentOutput(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    # --- 所有的输出字段定义 ---
    # 使用 Any 或 np.ndarray，根据你的具体需求。
    # 如果确定全是矩阵，也可以用之前定义的 DataMatrix
    A: floatMatrix | None = None
    B: floatMatrix | None = None
    C: floatMatrix | None = None
    D: floatMatrix | None = None
    ORDS: np.ndarray | None = None
    
    # 统计数据
    MeanU: np.ndarray | None = None
    MeanY: np.ndarray | None = None
    STDu: np.ndarray | None = None
    STDy: np.ndarray | None = None
    
    # 辨识结果详情
    NewMVsize: np.ndarray | None = None
    STP: floatMatrix | None = None
    FRQ: floatMatrix | None = None
    BND: floatMatrix | None = None
    BNDF: floatMatrix | None = None
    w: np.ndarray | None = None
    
    # 评分与增益
    Gain: floatMatrix | None = None
    Gain_n: floatMatrix | None = None
    Grade: strMatrix | None = None
    GradeF: strMatrix | None = None
    
    # 仿真与误差
    CVsim: floatMatrix | None = None
    CVError: np.ndarray | None = None
    CVLGTH: np.ndarray | None = None
    LGTHmax: float | None = None
    MVname: list[str] | None = None
    CVname: list[str] | None = None
    
    # 其他参数
    MVname: list[str] | None = None
    CVname: list[str] | None = None
    CV_INT: list[int] | None = None
    CV_MVVALV: list[int] | None = None
    Delay: intMatrix | None = None
    Expect: intMatrix | None = None
    Tfactor: int | None = None
    use_expect: bool | None = None
    Tident: int | None = None
    Tunit: str | None = None
    
    # --- 核心封装逻辑 ---
    @classmethod
    def from_token(cls, token: str, key: str) -> "IdentOutput":
        """
        工厂方法：接收加密 token 和 cipher 对象，自动解密并返回 IdentOutput 实例
        """
        if not token:
            print("Warning: Empty token provided.")
            return cls()

        try:
            # 1. 解密
            encrypted_bytes = base64.b64decode(token)
            iv = encrypted_bytes[:16]
            ciphertext = encrypted_bytes[16:]
            cipher = AES.new(key.encode('utf-8'), AES.MODE_CBC, iv)
            decrypted_padded = cipher.decrypt(ciphertext)
            npz_bytes = unpad(decrypted_padded, AES.block_size)

            # 2. 加载 Numpy 数据
            # 使用 io.BytesIO 将内存中的 bytes 伪装成文件对象
            with io.BytesIO(npz_bytes) as f:
                # allow_pickle=True 根据你的数据安全性决定，通常传矩阵 False 即可，
                # 但如果有字符串或特殊对象，需要 True
                npz_data = np.load(f, allow_pickle=True)
                
                # 3. 将 NpzFile 对象转为字典，并过滤掉不在 Model 里的字段
                # (np.load 返回的是类似字典的对象，使用 dict() 展开)
                data_dict = {}
                for k, v in npz_data.items():
                    if k in cls.model_fields:
                        if v.ndim == 0:
                            # 标量展开
                            data_dict[k] = v.item()
                        else:
                            # 矩阵直接赋值
                            data_dict[k] = v
                
                # 4. 实例化模型
                return cls(**data_dict)

        except Exception:
            # 捕获所有解密或加载异常，打印堆栈，并返回一个全 None 的空对象
            # 这样不会导致主程序崩溃
            print(f"解密或加载 IdentOutput 失败:\n{traceback.format_exc()}")
            return cls()

# --- 测试函数输入模型 ---
class TestDesignInput(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    n_signal: int = Field(..., description="Number of test signals")
    T2ST: int = Field(..., description="Process time to steady state (in samples)")

# --- 测试函数输出模型 ---
class TestDesignOutput(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    TestSig: floatMatrix = Field(..., description="Generated test signals matrix, column wise")
    R: floatMatrix = Field(..., description="Correlation matrix of test signals")
    Ntest: int = Field(..., description="Planned test time in Test Program (sampling interval)")
    
    
