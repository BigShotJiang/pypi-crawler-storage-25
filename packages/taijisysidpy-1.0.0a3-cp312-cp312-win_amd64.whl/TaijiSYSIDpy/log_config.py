import os
import sys
from configparser import ConfigParser
from loguru import logger

# --- 辅助函数 (保持不变) ---
def _is_absolute_path(p: str) -> bool:
    return os.path.isabs(p)

def _resolve_log_dir(raw_dir: str) -> str:
    """相对路径：拼接 cwd/log/<raw_dir>；绝对路径：原样返回。"""
    if _is_absolute_path(raw_dir):
        # 注意：这里假设 os.getcwd() 已经可以访问，这在 loguru 的 enqueue 模式下是安全的
        return raw_dir
    return os.path.join(os.getcwd(), raw_dir)
# ---

_LOGGING_READY = False

def setup_loguru_from_ini_simplified(ini_path: str = "config.ini", section: str = "TaijiSYSIDpyLogging"):
    global _LOGGING_READY
    if _LOGGING_READY:
        return logger

    cfg = ConfigParser()
    read_ok = cfg.read(ini_path, encoding="utf-8")
    if not read_ok:
        print(f"无法读取配置文件：{ini_path}，使用默认日志配置。")

    # 读取配置
    raw_log_dir = cfg.get(section, "log_dir", fallback="log")
    log_dir = _resolve_log_dir(raw_log_dir)

    prefix = cfg.get(section, "prefix", fallback="default")
    level = cfg.get(section, "level", fallback="INFO").upper()
    max_bytes_mb = cfg.getfloat(section, "max_bytes_mb", fallback=2.0)
    retention_days = cfg.getint(section, "retention_days", fallback=7)
    console = cfg.getboolean(section, "console", fallback=True)

    # Loguru rotation/retention 接受字符串格式
    rotation = f"{max_bytes_mb} MB"  # 例如 "2.0 MB"
    retention = f"{retention_days} days" # 例如 "7 days"
    
    # 确保日志目录存在
    os.makedirs(log_dir, exist_ok=True)

    # 1. 清空默认 handler
    logger.remove()

    # 2. 文件输出 (使用 Loguru 内置功能)
    # 文件路径使用占位符，Loguru 会自动处理文件命名和轮转
    file_path = os.path.join(log_dir, f"{prefix}_log.log") 
    # Loguru 自动命名：file_path 会在每次轮转时，在文件名中插入日期/时间或序号

    logger.add(
        file_path,
        level=level,
        enqueue=True, # **核心：确保多进程安全写入**
        rotation=rotation,   # 当文件达到 max_bytes_mb 时，进行滚动
        retention=retention, # 保留 retention_days 的日志文件
        backtrace=False,
        diagnose=False,
        # Loguru 默认使用时间或序号进行文件名命名，不再需要你自定义的 {prefix}-{MM}-{DD}.{seq:03d}.log 格式
        format="{time:YYYY-MM-DD HH:mm:ss} - {name} - {level} - {message}",
    )

    # 3. 控制台输出（可选）
    if console:
        logger.add(
            sys.stderr,
            level=level,
            enqueue=False,
            backtrace=False,
            diagnose=False,
            format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> - <cyan>{name}</cyan> - <level>{level}</level> - {message}",
        )

    _LOGGING_READY = True
    
    return logger

# --- 测试用例 (可选) ---
if __name__ == "__main__":
    # 假设 config.ini 存在并包含配置
    log = setup_loguru_from_ini_simplified("config.ini")
    log.info("新的简化配置测试")