__version__ = "1.0.0.alpha3"

from TaijiSYSIDpy.log_config import setup_loguru_from_ini_simplified
setup_loguru_from_ini_simplified('config.ini','TaijiSYSIDpyLogging')