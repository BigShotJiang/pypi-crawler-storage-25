"""Main Conjure runtime: invoke() orchestration loop."""

import logging
import os
import time
from pathlib import Path

from conjure.core.spec_parser import SpecModel, parse_spec
from conjure.core.prompt_builder import build_prompt, build_feedback_prompt, extract_function
from conjure.core.code_cache import ConjureCache
from conjure.verify.ast_checker import check_ast
from conjure.verify.example_tester import run_examples
from conjure.verify.sandbox import execute_function

logger = logging.getLogger("conjure.runtime")

# Default spec search paths
_SPEC_DIRS = [
    Path(__file__).parent.parent.parent / "specs" / "stdlib",
    Path("specs/stdlib"),
]

RETRY_SEEDS = [42, 43, 44]


class ConjureRuntime:
    """Orchestrates spec loading, code generation, verification, and caching."""

    def __init__(
        self,
        model_id: str | None = None,
        spec_dirs: list[str | Path] | None = None,
        cache_path: str | None = None,
        verbose: bool = False,
    ):
        from conjure.llm.engine import DEFAULT_MODEL

        self.model_id = model_id or DEFAULT_MODEL
        self.spec_dirs = [Path(d) for d in spec_dirs] if spec_dirs else list(_SPEC_DIRS)
        self.cache = ConjureCache(cache_path)
        self.verbose = verbose
        self._engine = None
        self._spec_cache: dict[str, tuple[SpecModel, str]] = {}  # fn_name → (spec, yaml_text)

    def _get_engine(self):
        if self._engine is None:
            from conjure.llm.engine import ConjureEngine
            self._engine = ConjureEngine(self.model_id)
        return self._engine

    def _find_spec(self, fn_name: str) -> tuple[SpecModel, str] | None:
        """Find a spec by function name. Returns (spec, raw_yaml) or None."""
        if fn_name in self._spec_cache:
            return self._spec_cache[fn_name]

        for spec_dir in self.spec_dirs:
            if not spec_dir.exists():
                continue
            for yaml_file in spec_dir.glob("*.yaml"):
                try:
                    raw = yaml_file.read_text()
                    spec = parse_spec(yaml_file)
                    if spec.function_name == fn_name:
                        self._spec_cache[fn_name] = (spec, raw)
                        return spec, raw
                except Exception:
                    continue
        return None

    def _generate_and_verify(
        self, spec: SpecModel, spec_yaml: str
    ) -> tuple[str | None, dict]:
        """Generate code and verify it. Returns (code, report) or (None, report)."""
        engine = self._get_engine()
        report = {"function_name": spec.function_name, "attempts": []}

        for attempt_idx, seed in enumerate(RETRY_SEEDS):
            attempt_report = {"seed": seed, "attempt": attempt_idx + 1}

            # Check cache for this seed
            cached = self.cache.get(spec_yaml, self.model_id, seed)
            if cached:
                attempt_report["cached"] = True
                report["attempts"].append(attempt_report)
                return cached, report

            # Generate
            if attempt_idx == 0 or attempt_idx == 1:
                prompt = build_prompt(spec)
            else:
                # Third attempt: include error feedback from last failure
                last_attempt = report["attempts"][-1]
                error_msg = last_attempt.get("error", "Unknown error")
                last_code = last_attempt.get("code", "")
                prompt = build_feedback_prompt(spec, last_code, error_msg)

            t0 = time.time()
            # Qwen3.5 recommended: 0.6 for coding, increase on retry
            raw_output = engine.generate(prompt, temperature=0.6 if attempt_idx < 2 else 0.8)
            gen_time = time.time() - t0
            attempt_report["generation_time"] = gen_time

            if self.verbose:
                logger.info("Attempt %d: generated in %.2fs", attempt_idx + 1, gen_time)

            # Extract function
            code = extract_function(raw_output, spec.function_name)
            if code is None:
                # Try raw output as-is (model might output just the function body)
                # Reconstruct with signature
                params = []
                for p in spec.params:
                    if p.default is not None:
                        params.append(f"{p.name}={p.default}")
                    else:
                        params.append(p.name)
                sig = f"def {spec.function_name}({', '.join(params)}):"
                candidate = sig + "\n" + raw_output
                code = extract_function(candidate, spec.function_name)

            if code is None:
                attempt_report["error"] = "Could not extract function from output"
                attempt_report["raw_output"] = raw_output[:500]
                report["attempts"].append(attempt_report)
                continue

            attempt_report["code"] = code

            # AST check
            ast_result = check_ast(code, spec.constraints, spec.function_name)
            if not ast_result.passed:
                attempt_report["error"] = f"AST violations: {'; '.join(ast_result.violations)}"
                report["attempts"].append(attempt_report)
                if self.verbose:
                    logger.info("AST check failed: %s", ast_result.violations)
                continue

            attempt_report["ast_passed"] = True

            # Example tests
            test_result = run_examples(code, spec)
            if not test_result.all_passed:
                failures_str = "; ".join(
                    f"Example {f.index}: expected {f.expected!r}, got {f.actual!r}"
                    + (f" ({f.error})" if f.error else "")
                    for f in test_result.failures
                )
                attempt_report["error"] = f"Example tests failed: {failures_str}"
                attempt_report["examples_passed"] = test_result.passed
                attempt_report["examples_total"] = test_result.total
                report["attempts"].append(attempt_report)
                if self.verbose:
                    logger.info(
                        "Examples: %d/%d passed", test_result.passed, test_result.total
                    )
                continue

            attempt_report["examples_passed"] = test_result.passed
            attempt_report["examples_total"] = test_result.total
            attempt_report["verified"] = True
            report["attempts"].append(attempt_report)

            # Cache the verified code
            self.cache.put(spec_yaml, self.model_id, seed, code, report)

            if self.verbose:
                logger.info("Verified and cached on attempt %d", attempt_idx + 1)

            return code, report

        return None, report

    def invoke(self, fn_name: str, **kwargs):
        """Invoke a Conjure function.

        1. Find spec by function name
        2. Cache lookup → return on hit
        3. Generate → verify → cache → execute
        """
        result = self._find_spec(fn_name)
        if result is None:
            raise ValueError(f"No spec found for function '{fn_name}'")
        spec, spec_yaml = result

        # Try to find cached code directly
        for seed in RETRY_SEEDS:
            cached = self.cache.get(spec_yaml, self.model_id, seed)
            if cached:
                result, error = execute_function(
                    cached, fn_name, kwargs,
                    allowed_builtins=spec.constraints.allowed_builtins,
                )
                if error:
                    raise RuntimeError(f"Cached code execution failed: {error}")
                return result

        # Generate new code
        code, report = self._generate_and_verify(spec, spec_yaml)
        if code is None:
            raise RuntimeError(
                f"Failed to generate valid code for '{fn_name}' after "
                f"{len(report['attempts'])} attempts. "
                f"Last error: {report['attempts'][-1].get('error', 'unknown')}"
            )

        # Execute
        result, error = execute_function(
            code, fn_name, kwargs,
            allowed_builtins=spec.constraints.allowed_builtins,
        )
        if error:
            raise RuntimeError(f"Generated code execution failed: {error}")
        return result

    def build(self, spec_dir: str | None = None):
        """Pre-generate and cache all specs in a directory."""
        dirs = [Path(spec_dir)] if spec_dir else self.spec_dirs
        results = {}

        for d in dirs:
            if not d.exists():
                continue
            for yaml_file in sorted(d.glob("*.yaml")):
                try:
                    raw = yaml_file.read_text()
                    spec = parse_spec(yaml_file)
                    code, report = self._generate_and_verify(spec, raw)
                    results[spec.function_name] = {
                        "success": code is not None,
                        "attempts": len(report["attempts"]),
                        "spec_file": str(yaml_file),
                    }
                except Exception as e:
                    results[yaml_file.stem] = {
                        "success": False,
                        "error": str(e),
                        "spec_file": str(yaml_file),
                    }

        return results
