"""Content-addressed SQLite code cache."""

import hashlib
import json
import os
import sqlite3
from pathlib import Path


class ConjureCache:
    """Cache generated code keyed by spec content + model + seed.

    Key = SHA256(spec_yaml + model_id + seed)
    Same spec + same model = same code always (reproducible builds).
    Change the spec = cache invalidates.
    Upgrade the model = all caches invalidate.
    """

    def __init__(self, db_path: str | None = None):
        if db_path is None:
            db_path = os.path.join(".conjure", "cache.db")
        db_dir = os.path.dirname(db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)
        self.db = sqlite3.connect(db_path)
        self._init_schema()

    def _init_schema(self):
        self.db.execute("""
            CREATE TABLE IF NOT EXISTS cache (
                key TEXT PRIMARY KEY,
                code TEXT NOT NULL,
                spec_hash TEXT NOT NULL,
                model_id TEXT NOT NULL,
                seed INTEGER NOT NULL,
                verification_report TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        self.db.commit()

    @staticmethod
    def _cache_key(spec_content: str, model_id: str, seed: int) -> str:
        payload = json.dumps(
            {"spec": spec_content, "model": model_id, "seed": seed},
            sort_keys=True,
        )
        return hashlib.sha256(payload.encode()).hexdigest()

    def get(self, spec_content: str, model_id: str, seed: int) -> str | None:
        """Look up cached code. Returns None on miss."""
        key = self._cache_key(spec_content, model_id, seed)
        row = self.db.execute(
            "SELECT code FROM cache WHERE key = ?", (key,)
        ).fetchone()
        return row[0] if row else None

    def put(
        self,
        spec_content: str,
        model_id: str,
        seed: int,
        code: str,
        verification_report: dict | None = None,
    ):
        """Store generated code in cache."""
        key = self._cache_key(spec_content, model_id, seed)
        spec_hash = hashlib.sha256(spec_content.encode()).hexdigest()
        self.db.execute(
            "INSERT OR REPLACE INTO cache (key, code, spec_hash, model_id, seed, verification_report) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (key, code, spec_hash, model_id, seed,
             json.dumps(verification_report) if verification_report else None),
        )
        self.db.commit()

    def get_by_function(self, function_name: str) -> str | None:
        """Look up cached code by searching verification reports for function name."""
        rows = self.db.execute(
            "SELECT code, verification_report FROM cache ORDER BY created_at DESC"
        ).fetchall()
        for code, report in rows:
            if report:
                try:
                    r = json.loads(report)
                    if r.get("function_name") == function_name:
                        return code
                except (json.JSONDecodeError, KeyError):
                    pass
            if f"def {function_name}" in code:
                return code
        return None

    def clear(self):
        """Clear all cached entries."""
        self.db.execute("DELETE FROM cache")
        self.db.commit()
