"""Parse YAML spec files into SpecModel dataclasses."""

from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass
class ParamDef:
    name: str
    type: str
    default: str | None = None


@dataclass
class ExampleDef:
    input: dict
    output: object


@dataclass
class ConstraintsDef:
    no_imports: bool = True
    max_lines: int = 100
    allowed_builtins: list[str] = field(default_factory=lambda: [
        "len", "range", "str", "int", "float", "bool", "list", "dict",
        "tuple", "set", "enumerate", "zip", "sorted", "reversed", "min",
        "max", "sum", "abs", "isinstance", "type", "ord", "chr", "hex",
        "bin", "oct", "bytes", "bytearray", "memoryview", "map", "filter",
        "any", "all", "round", "divmod", "pow", "hash", "repr",
    ])
    no_eval: bool = True
    no_exec: bool = True


@dataclass
class SpecModel:
    name: str
    version: str
    description: str
    function_name: str
    params: list[ParamDef]
    return_type: str
    properties: list[str]
    examples: list[ExampleDef]
    constraints: ConstraintsDef


def _parse_params(input_section: dict) -> list[ParamDef]:
    """Parse the input section into a list of ParamDef."""
    params = []
    if not input_section:
        return params
    for name, type_or_spec in input_section.items():
        if isinstance(type_or_spec, str):
            # Check for default value: "str = utf-8"
            if " = " in type_or_spec:
                typ, default = type_or_spec.split(" = ", 1)
                params.append(ParamDef(name=name, type=typ.strip(), default=default.strip()))
            else:
                params.append(ParamDef(name=name, type=type_or_spec, default=None))
        elif isinstance(type_or_spec, dict):
            params.append(ParamDef(name=name, type=str(type_or_spec), default=None))
        else:
            # bool, int, float defaults
            params.append(ParamDef(name=name, type=type(type_or_spec).__name__, default=str(type_or_spec)))
    return params


def _parse_constraints(raw: dict | None) -> ConstraintsDef:
    """Parse the constraints section."""
    if not raw:
        return ConstraintsDef()
    return ConstraintsDef(
        no_imports=raw.get("no_imports", True),
        max_lines=raw.get("max_lines", 100),
        allowed_builtins=raw.get("allowed_builtins", ConstraintsDef().allowed_builtins),
        no_eval=raw.get("no_eval", True),
        no_exec=raw.get("no_exec", True),
    )


def _parse_examples(raw: list | None) -> list[ExampleDef]:
    """Parse examples section."""
    if not raw:
        return []
    examples = []
    for ex in raw:
        examples.append(ExampleDef(
            input=ex.get("input", {}),
            output=ex.get("output"),
        ))
    return examples


def parse_spec(path: str | Path) -> SpecModel:
    """Parse a YAML spec file into a SpecModel."""
    path = Path(path)
    with open(path) as f:
        data = yaml.safe_load(f)
    return _parse_raw(data)


def parse_spec_string(text: str) -> SpecModel:
    """Parse a YAML spec string into a SpecModel."""
    data = yaml.safe_load(text)
    return _parse_raw(data)


def _parse_raw(data: dict) -> SpecModel:
    """Parse a raw dict into a SpecModel."""
    return SpecModel(
        name=data.get("spec", ""),
        version=str(data.get("version", "1.0.0")),
        description=data.get("description", ""),
        function_name=data.get("function", ""),
        params=_parse_params(data.get("input", {})),
        return_type=str(data.get("output", "any")),
        properties=data.get("properties", []),
        examples=_parse_examples(data.get("examples")),
        constraints=_parse_constraints(data.get("constraints")),
    )
