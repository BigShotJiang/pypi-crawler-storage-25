"""Convert SpecModel into LLM prompts and extract generated functions."""

import re

from conjure.core.spec_parser import SpecModel


def build_prompt(spec: SpecModel) -> str:
    """Build an LLM prompt from a spec model."""
    # Build function signature
    params = []
    for p in spec.params:
        if p.default is not None:
            params.append(f"{p.name}: {p.type} = {p.default}")
        else:
            params.append(f"{p.name}: {p.type}")
    signature = f"def {spec.function_name}({', '.join(params)}) -> {spec.return_type}:"

    # Build examples text
    examples_text = ""
    for i, ex in enumerate(spec.examples):
        args = ", ".join(f"{k}={repr(v)}" for k, v in ex.input.items())
        examples_text += f"    # Example {i+1}: {spec.function_name}({args}) == {repr(ex.output)}\n"

    # Build properties text
    props_text = ""
    for prop in spec.properties:
        props_text += f"    # Property: {prop}\n"

    # Build constraints text
    constraints_parts = []
    if spec.constraints.no_imports:
        constraints_parts.append("NO imports allowed")
    if spec.constraints.no_eval:
        constraints_parts.append("NO eval()")
    if spec.constraints.no_exec:
        constraints_parts.append("NO exec()")
    constraints_parts.append(f"Maximum {spec.constraints.max_lines} lines")
    if spec.constraints.allowed_builtins:
        constraints_parts.append(f"Allowed builtins: {', '.join(spec.constraints.allowed_builtins)}")

    prompt = f"""Write a complete, self-contained Python function. Do NOT use import statements. Do NOT call any external function. Implement the algorithm from scratch.

{signature}
    \"\"\"{spec.description.strip()}\"\"\"

{props_text}{examples_text}
Constraints: {'; '.join(constraints_parts)}

Think step by step inside <think></think> tags, then write ONLY the final function inside a python code block.

```python
{signature}"""
    return prompt


def build_feedback_prompt(spec: SpecModel, code: str, error: str) -> str:
    """Build a retry prompt with error feedback."""
    base = build_prompt(spec)
    feedback = f"""

The previous implementation had an error:

Previous code:
```python
{code}
```

Error: {error}

Fix the implementation. Remember: NO imports, NO eval/exec, pure Python only.

Write the corrected function:

```python
def {spec.function_name}("""
    return base + "\n" + feedback


def extract_function(raw_output: str, fn_name: str) -> str | None:
    """Extract the function definition from LLM output.

    Handles markdown code blocks, <think> reasoning blocks, extra text, etc.
    """
    text = raw_output

    # Strip <think>...</think> blocks (Qwen3.5 reasoning mode)
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()
    # Also strip unclosed <think> block (model may not close it)
    text = re.sub(r"<think>.*", "", text, flags=re.DOTALL).strip()

    # Try to find function in code blocks first (greedy and non-greedy)
    code_blocks = re.findall(r"```(?:python)?\s*\n(.*?)```", text, re.DOTALL)
    if code_blocks:
        # Prefer the longest block containing the function
        for block in sorted(code_blocks, key=len, reverse=True):
            if f"def {fn_name}" in block:
                return _clean_function(block, fn_name)

    # Try unclosed code blocks (model may have been cut off)
    unclosed = re.findall(r"```(?:python)?\s*\n(.*)", text, re.DOTALL)
    if unclosed:
        for block in unclosed:
            if f"def {fn_name}" in block:
                return _clean_function(block, fn_name)

    # No code blocks - try to find the function directly in the text
    if f"def {fn_name}" in text:
        return _clean_function(text, fn_name)

    return None


def _clean_function(text: str, fn_name: str) -> str | None:
    """Extract just the function definition from a block of text."""
    lines = text.split("\n")
    result_lines = []
    in_function = False
    indent_level = None

    for line in lines:
        stripped = line.rstrip()

        if not in_function:
            if stripped.lstrip().startswith(f"def {fn_name}"):
                in_function = True
                indent_level = len(line) - len(line.lstrip())
                result_lines.append(line[indent_level:] if indent_level > 0 else line)
        else:
            if stripped == "":
                result_lines.append("")
            elif indent_level is not None:
                current_indent = len(line) - len(line.lstrip())
                if current_indent <= indent_level and stripped and not stripped.startswith("#"):
                    # Hit another top-level definition or statement
                    if stripped.startswith("def ") or stripped.startswith("class "):
                        break
                    # Could be a continuation like a decorator or module-level code
                    break
                result_lines.append(line[indent_level:] if indent_level > 0 else line)
            else:
                result_lines.append(line)

    if not result_lines:
        return None

    # Strip trailing blank lines
    while result_lines and result_lines[-1].strip() == "":
        result_lines.pop()

    code = "\n".join(result_lines)
    if f"def {fn_name}" not in code:
        return None

    return code
