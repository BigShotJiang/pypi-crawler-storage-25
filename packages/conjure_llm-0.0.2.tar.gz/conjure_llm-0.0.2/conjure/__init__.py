"""Conjure: Zero-dependency programming via embedded LLM code generation."""

from conjure.core.runtime import ConjureRuntime

_default_runtime = None


def _get_runtime() -> ConjureRuntime:
    global _default_runtime
    if _default_runtime is None:
        _default_runtime = ConjureRuntime()
    return _default_runtime


def invoke(fn_name: str, **kwargs):
    """Invoke a Conjure function by spec name."""
    return _get_runtime().invoke(fn_name, **kwargs)


def build(spec_dir: str | None = None):
    """Pre-generate and cache all specs in a directory."""
    return _get_runtime().build(spec_dir)
