"""Conjure CLI — zero-dependency code generation from YAML specs."""

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="conjure",
        description="Zero-dependency programming via LLM-generated, verified code",
    )
    subparsers = parser.add_subparsers(dest="command")

    # conjure invoke
    invoke_parser = subparsers.add_parser("invoke", help="Invoke a function by spec name")
    invoke_parser.add_argument("function", help="Function name (e.g., base64_encode)")
    invoke_parser.add_argument("--kwargs", "-k", nargs="*", help="Arguments as key=value pairs")
    invoke_parser.add_argument("--spec-dir", help="Directory containing .yaml spec files")

    # conjure build
    build_parser = subparsers.add_parser("build", help="Pre-generate and cache all specs")
    build_parser.add_argument("--spec-dir", help="Directory containing .yaml spec files")

    # conjure eval
    eval_parser = subparsers.add_parser("eval", help="Evaluate specs")
    eval_parser.add_argument("--spec-dir", required=True, help="Spec directory")
    eval_parser.add_argument("--output", default="eval_results.md", help="Output file")
    eval_parser.add_argument("--model", default=None, help="Model ID")

    # conjure translate
    translate_parser = subparsers.add_parser("translate", help="Analyze a project for Conjure translation")
    translate_parser.add_argument("project_dir", help="Python project directory")
    translate_parser.add_argument("--output", "-o", help="Output directory for generated specs")

    # conjure audit
    audit_parser = subparsers.add_parser("audit", help="Compare dependency attack surface")
    audit_parser.add_argument("--packages", required=True, help="Comma-separated package names")
    audit_parser.add_argument("--specs", default="specs/stdlib", help="Spec directory")
    audit_parser.add_argument("--output", default=None, help="Output markdown file")

    args = parser.parse_args()

    if args.command == "invoke":
        from conjure.core.runtime import ConjureRuntime
        kwargs = {}
        if args.kwargs:
            for kv in args.kwargs:
                k, v = kv.split("=", 1)
                kwargs[k] = v
        rt = ConjureRuntime(spec_dirs=[args.spec_dir] if args.spec_dir else None, verbose=True)
        result = rt.invoke(args.function, **kwargs)
        print(result)

    elif args.command == "build":
        from conjure.core.runtime import ConjureRuntime
        rt = ConjureRuntime(spec_dirs=[args.spec_dir] if args.spec_dir else None, verbose=True)
        results = rt.build(args.spec_dir)
        passed = sum(1 for r in results.values() if r.get("success"))
        print(f"Built {passed}/{len(results)} specs")

    elif args.command == "eval":
        from conjure.eval.eval_runner import run_full_eval
        run_full_eval(args.model or "mlx-community/Qwen3.5-9B-OptiQ-4bit", args.spec_dir, args.output)

    elif args.command == "translate":
        from conjure.translate.spec_generator import analyze_and_report
        analyze_and_report(args.project_dir, args.output)

    elif args.command == "audit":
        from conjure.eval.attack_surface_metrics import run_analysis
        run_analysis(args.packages.split(","), args.specs, args.output)

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
