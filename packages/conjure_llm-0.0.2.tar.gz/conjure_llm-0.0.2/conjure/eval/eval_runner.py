"""Evaluation runner for measuring Conjure spec pass rates."""

import os
import sys
import time
import glob
import json
from datetime import datetime

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from conjure.llm.engine import ConjureEngine
from conjure.core.spec_parser import parse_spec
from conjure.core.prompt_builder import build_prompt, build_feedback_prompt, extract_function
from conjure.verify.ast_checker import check_ast
from conjure.verify.example_tester import run_examples


def _log(msg: str):
    """Print with flush for unbuffered output."""
    print(msg, flush=True)


def _try_generate_and_verify(engine, spec, temperature=0.6, max_tokens=4096,
                              feedback_code=None, feedback_error=None):
    """Single generation + verification attempt.

    Returns (passed: bool, code: str|None, error: str|None).
    """
    # Build prompt
    if feedback_code and feedback_error:
        prompt = build_feedback_prompt(spec, feedback_code, feedback_error)
    else:
        prompt = build_prompt(spec)

    # Generate
    try:
        raw_output = engine.generate(prompt, max_tokens=max_tokens, temperature=temperature)
    except Exception as e:
        return False, None, f"Generation error: {type(e).__name__}: {e}"

    # Extract function
    code = extract_function(raw_output, spec.function_name)
    if code is None:
        return False, None, "Could not extract function from LLM output"

    # AST check
    ast_result = check_ast(code, spec.constraints, spec.function_name)
    if not ast_result.passed:
        error = f"AST violations: {'; '.join(ast_result.violations)}"
        return False, code, error

    # Example tests
    test_result = run_examples(code, spec)
    if not test_result.all_passed:
        failure_strs = []
        for f in test_result.failures:
            s = f"Example {f.index}: expected {f.expected!r}, got {f.actual!r}"
            if f.error:
                s += f" ({f.error})"
            failure_strs.append(s)
        error = f"Example failures: {'; '.join(failure_strs)}"
        return False, code, error

    return True, code, None


def eval_spec_pass_at_1(engine, spec, temp=0.6):
    """Single attempt, return (passed: bool, code_or_none, error_or_none)."""
    return _try_generate_and_verify(engine, spec, temperature=temp)


def eval_spec_pass_at_3(engine, spec, temps=(0.6, 0.6, 0.6)):
    """Three independent attempts, return (any_passed: bool, best_code, attempts_detail).

    Each attempt is independent (no feedback between them).
    """
    attempts = []
    best_code = None

    for i, temp in enumerate(temps):
        passed, code, error = _try_generate_and_verify(engine, spec, temperature=temp)
        attempts.append({
            "attempt": i + 1,
            "temperature": temp,
            "passed": passed,
            "error": error,
        })
        if passed:
            best_code = code
            # Could stop early, but we record all attempts for stats
            break

    any_passed = any(a["passed"] for a in attempts)
    return any_passed, best_code, attempts


def eval_spec_pass_at_1_feedback(engine, spec):
    """Up to 3 attempts with error feedback, return (passed: bool, code, attempts_detail).

    First attempt at temp=0.6 with no feedback.
    Subsequent attempts include the error from the previous attempt.
    Final attempt uses temp=0.8 for diversity.
    """
    attempts = []
    last_code = None
    last_error = None

    temps = [0.6, 0.6, 0.8]

    for i, temp in enumerate(temps):
        if i == 0:
            passed, code, error = _try_generate_and_verify(
                engine, spec, temperature=temp
            )
        else:
            passed, code, error = _try_generate_and_verify(
                engine, spec, temperature=temp,
                feedback_code=last_code, feedback_error=last_error,
            )

        attempts.append({
            "attempt": i + 1,
            "temperature": temp,
            "passed": passed,
            "error": error,
            "used_feedback": i > 0,
        })

        if passed:
            return True, code, attempts

        # Save for feedback on next attempt
        last_code = code
        last_error = error or "Unknown error"

    return False, last_code, attempts


def _categorize_error(error: str) -> str:
    """Categorize an error into a short label."""
    if error is None:
        return "success"
    e = error.lower()
    if "could not extract" in e:
        return "extraction"
    if "ast violation" in e:
        return "ast"
    if "syntax error" in e:
        return "syntax"
    if "example failure" in e or "example test" in e:
        return "wrong_output"
    if "runtime error" in e:
        return "runtime"
    if "timed out" in e or "timeout" in e:
        return "timeout"
    if "generation error" in e:
        return "generation"
    return "other"


def run_full_eval(model_id: str, spec_dir: str, output_path: str = None, adapter_path: str = None):
    """Run full evaluation on all specs and output results.

    For each spec, measures pass@1, pass@3, and pass@1+feedback.
    Prints results line by line and writes a markdown summary.
    """
    # Discover specs
    spec_files = sorted(glob.glob(os.path.join(spec_dir, "*.yaml")))
    if not spec_files:
        _log(f"No spec files found in {spec_dir}")
        return

    _log(f"Conjure Evaluation Runner")
    _log(f"Model: {model_id}")
    _log(f"Specs: {len(spec_files)} files in {spec_dir}")
    _log(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    _log("=" * 70)

    # Load engine
    _log("Loading model...")
    if adapter_path:
        _log(f"Adapter: {adapter_path}")
    engine = ConjureEngine(model_id=model_id, adapter_path=adapter_path)

    results = []

    for spec_file in spec_files:
        spec_name = os.path.splitext(os.path.basename(spec_file))[0]
        _log(f"\n--- {spec_name} ---")

        try:
            spec = parse_spec(spec_file)
        except Exception as e:
            _log(f"  SKIP: Failed to parse spec: {e}")
            results.append({
                "spec": spec_name,
                "category": "parse_error",
                "pass_at_1": False,
                "pass_at_3": False,
                "pass_at_1_fb": False,
                "error": str(e),
            })
            continue

        # pass@1
        _log(f"  pass@1 ...", )
        t0 = time.time()
        p1_passed, p1_code, p1_error = eval_spec_pass_at_1(engine, spec)
        t1 = time.time()
        _log(f"  pass@1: {'PASS' if p1_passed else 'FAIL'} ({t1 - t0:.1f}s)"
             + (f" [{_categorize_error(p1_error)}]" if not p1_passed else ""))

        # pass@3
        _log(f"  pass@3 ...")
        t0 = time.time()
        p3_passed, p3_code, p3_attempts = eval_spec_pass_at_3(engine, spec)
        t3 = time.time()
        n_attempts = len(p3_attempts)
        _log(f"  pass@3: {'PASS' if p3_passed else 'FAIL'} ({t3 - t0:.1f}s, {n_attempts} attempts)")

        # pass@1+feedback
        _log(f"  pass@1+fb ...")
        t0 = time.time()
        pfb_passed, pfb_code, pfb_attempts = eval_spec_pass_at_1_feedback(engine, spec)
        tfb = time.time()
        n_fb_attempts = len(pfb_attempts)
        _log(f"  pass@1+fb: {'PASS' if pfb_passed else 'FAIL'} ({tfb - t0:.1f}s, {n_fb_attempts} attempts)")

        # Determine error category from the last failing attempt
        last_error = None
        if not pfb_passed and pfb_attempts:
            last_error = pfb_attempts[-1].get("error")
        elif not p1_passed:
            last_error = p1_error

        results.append({
            "spec": spec_name,
            "function": spec.function_name,
            "category": _categorize_error(last_error) if not (p1_passed or p3_passed or pfb_passed) else "success",
            "pass_at_1": p1_passed,
            "pass_at_3": p3_passed,
            "pass_at_1_fb": pfb_passed,
            "error": last_error,
        })

    # Print summary
    _log("\n" + "=" * 70)
    _log("SUMMARY")
    _log("=" * 70)

    total = len(results)
    p1_total = sum(1 for r in results if r["pass_at_1"])
    p3_total = sum(1 for r in results if r["pass_at_3"])
    pfb_total = sum(1 for r in results if r["pass_at_1_fb"])

    _log(f"  pass@1:         {p1_total}/{total} ({100 * p1_total / total:.1f}%)" if total else "  No specs")
    _log(f"  pass@3:         {p3_total}/{total} ({100 * p3_total / total:.1f}%)" if total else "")
    _log(f"  pass@1+feedback: {pfb_total}/{total} ({100 * pfb_total / total:.1f}%)" if total else "")

    # Write markdown output
    if output_path:
        _write_markdown_report(model_id, results, output_path)
        _log(f"\nResults written to {output_path}")


def _write_markdown_report(model_id: str, results: list[dict], output_path: str):
    """Write evaluation results as a markdown report."""
    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)

    total = len(results)
    p1_total = sum(1 for r in results if r["pass_at_1"])
    p3_total = sum(1 for r in results if r["pass_at_3"])
    pfb_total = sum(1 for r in results if r["pass_at_1_fb"])

    lines = []
    lines.append(f"# Conjure Evaluation Results")
    lines.append("")
    lines.append(f"- **Model**: `{model_id}`")
    lines.append(f"- **Date**: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append(f"- **Specs evaluated**: {total}")
    lines.append("")

    # Summary
    lines.append("## Summary")
    lines.append("")
    lines.append("| Metric | Passed | Total | Rate |")
    lines.append("|--------|--------|-------|------|")
    if total > 0:
        lines.append(f"| pass@1 | {p1_total} | {total} | {100 * p1_total / total:.1f}% |")
        lines.append(f"| pass@3 | {p3_total} | {total} | {100 * p3_total / total:.1f}% |")
        lines.append(f"| pass@1+feedback | {pfb_total} | {total} | {100 * pfb_total / total:.1f}% |")
    lines.append("")

    # Per-spec table
    lines.append("## Per-Spec Results")
    lines.append("")
    lines.append("| Spec | pass@1 | pass@3 | pass@1+fb | Category |")
    lines.append("|------|--------|--------|-----------|----------|")
    for r in results:
        p1 = "PASS" if r["pass_at_1"] else "FAIL"
        p3 = "PASS" if r["pass_at_3"] else "FAIL"
        pfb = "PASS" if r["pass_at_1_fb"] else "FAIL"
        cat = r.get("category", "")
        lines.append(f"| {r['spec']} | {p1} | {p3} | {pfb} | {cat} |")
    lines.append("")

    # Failing specs
    failing = [r for r in results if not r["pass_at_1"] and not r["pass_at_3"] and not r["pass_at_1_fb"]]
    if failing:
        lines.append("## Failing Specs")
        lines.append("")
        lines.append("| Spec | Error Category | Error |")
        lines.append("|------|----------------|-------|")
        for r in failing:
            error_str = (r.get("error") or "unknown")[:120].replace("|", "\\|")
            lines.append(f"| {r['spec']} | {r.get('category', '')} | {error_str} |")
        lines.append("")

    with open(output_path, "w") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Conjure evaluation runner")
    parser.add_argument("--model", default="mlx-community/Qwen3.5-9B-OptiQ-4bit",
                        help="Model ID for mlx-lm")
    parser.add_argument("--spec-dir", default=None,
                        help="Directory containing .yaml spec files")
    parser.add_argument("--output", default="eval/baseline_results.md",
                        help="Output markdown file path")
    parser.add_argument("--adapter", default=None,
                        help="Path to LoRA adapter directory")
    args = parser.parse_args()

    # Project root is three levels up from conjure/eval/eval_runner.py
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    spec_dir = args.spec_dir or os.path.join(project_root, "specs", "stdlib")
    run_full_eval(args.model, spec_dir, args.output, adapter_path=args.adapter)
