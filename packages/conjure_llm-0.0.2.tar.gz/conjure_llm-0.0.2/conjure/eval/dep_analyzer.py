"""Analyze dependency attack surface of Python projects."""

import json
import os
import subprocess
import sys


def analyze_packages(package_names: list[str]) -> dict:
    """Analyze a list of packages and their transitive dependencies.

    Uses pip install --dry-run --report to get the full dependency tree.
    """
    result = {"direct_deps": package_names, "direct_count": len(package_names)}

    try:
        proc = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--dry-run", "--report", "-",
             "--quiet"] + package_names,
            capture_output=True, text=True, timeout=120,
        )
        if proc.returncode == 0:
            report = json.loads(proc.stdout)
            all_pkgs = report.get("install", [])
            trans = []
            for pkg in all_pkgs:
                meta = pkg.get("metadata", {})
                trans.append({
                    "name": meta.get("name", "?"),
                    "version": meta.get("version", "?"),
                })
            result["transitive_deps"] = trans
            result["transitive_count"] = len(trans)
        else:
            result["transitive_deps"] = []
            result["transitive_count"] = len(package_names)
            result["error"] = proc.stderr[:200]
    except Exception as e:
        result["transitive_deps"] = []
        result["transitive_count"] = len(package_names)
        result["error"] = str(e)

    # Estimate LOC (average Python package: ~1200 LOC)
    result["estimated_loc"] = result["transitive_count"] * 1200

    # Estimate unique maintainers (~2 per package)
    result["estimated_maintainers"] = result["transitive_count"] * 2

    # Run pip-audit if available
    result["cves"] = audit_packages(package_names)

    return result


def audit_packages(package_names: list[str]) -> list[dict]:
    """Run pip-audit on packages. Returns list of CVEs found."""
    try:
        input_text = "\n".join(package_names)
        proc = subprocess.run(
            [sys.executable, "-m", "pip_audit", "--desc", "-r", "/dev/stdin"],
            input=input_text, capture_output=True, text=True, timeout=120,
        )
        cves = []
        for line in proc.stdout.split("\n"):
            if "VULN" in line or "CVE" in line:
                cves.append({"raw": line.strip()})
        return cves
    except Exception:
        return []


def analyze_requirements(req_file: str) -> dict:
    """Analyze a requirements.txt file."""
    packages = []
    with open(req_file) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                pkg = line.split("==")[0].split(">=")[0].split("<=")[0].strip()
                if pkg:
                    packages.append(pkg)
    return analyze_packages(packages)


def generate_report(analysis: dict, output_path: str):
    """Write analysis to JSON file."""
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(analysis, f, indent=2)
    print(f"Report written to {output_path}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Analyze Python dependency attack surface")
    parser.add_argument("--packages", help="Comma-separated package names")
    parser.add_argument("--requirements", help="Path to requirements.txt")
    parser.add_argument("--output", default="dep_analysis.json")
    args = parser.parse_args()

    if args.requirements:
        result = analyze_requirements(args.requirements)
    elif args.packages:
        result = analyze_packages(args.packages.split(","))
    else:
        parser.error("Provide --packages or --requirements")

    generate_report(result, args.output)
