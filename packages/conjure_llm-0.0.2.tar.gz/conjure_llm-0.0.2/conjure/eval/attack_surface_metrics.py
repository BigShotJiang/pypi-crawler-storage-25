"""Compare attack surface: traditional dependencies vs Conjure specs."""

import glob
import json
import os
import sys


def count_conjure_surface(spec_dir: str) -> dict:
    """Measure Conjure's attack surface."""
    spec_files = glob.glob(os.path.join(spec_dir, "*.yaml"))
    spec_loc = sum(len(open(f).readlines()) for f in spec_files)

    return {
        "spec_count": len(spec_files),
        "spec_loc": spec_loc,
        "model_size_gb": 5.0,  # Qwen3.5-9B-OptiQ-4bit
        "trust_chain": 1,
        "cve_count": 0,
        "transitive_deps": 0,
    }


def compare_surfaces(traditional: dict, conjure: dict) -> dict:
    """Compute comparison metrics."""
    trad_loc = traditional.get("estimated_loc", 0)
    conj_loc = conjure.get("spec_loc", 1)

    return {
        "traditional": {
            "direct_deps": traditional.get("direct_count", 0),
            "transitive_deps": traditional.get("transitive_count", 0),
            "estimated_loc": trad_loc,
            "estimated_maintainers": traditional.get("estimated_maintainers", 0),
            "cve_count": len(traditional.get("cves", [])),
        },
        "conjure": {
            "spec_count": conjure["spec_count"],
            "spec_loc": conj_loc,
            "transitive_deps": 0,
            "maintainers": 0,
            "cve_count": 0,
        },
        "reduction": {
            "deps_eliminated": traditional.get("transitive_count", 0),
            "loc_reduction_ratio": round(trad_loc / max(conj_loc, 1), 1),
            "maintainer_reduction": traditional.get("estimated_maintainers", 0),
            "audit_time": {
                "traditional": "days",
                "conjure": "hours",
            },
        },
    }


def format_comparison_table(comparison: dict) -> str:
    """Format as markdown."""
    t = comparison["traditional"]
    c = comparison["conjure"]
    r = comparison["reduction"]

    lines = [
        "| Metric | Traditional | Conjure |",
        "|--------|:----------:|:-------:|",
        f"| Direct dependencies | {t['direct_deps']} | **0** |",
        f"| Transitive dependencies | {t['transitive_deps']} | **0** |",
        f"| Estimated LOC | ~{t['estimated_loc']:,} | **~{c['spec_loc']:,}** (specs) |",
        f"| Unique maintainers | ~{t['estimated_maintainers']} | **0** |",
        f"| Known CVEs | {t['cve_count']} | **0** |",
        f"| LOC reduction | — | **{r['loc_reduction_ratio']}x** |",
        f"| Supply chain vectors | {t['transitive_deps']} packages | **1 model binary** |",
        f"| Human audit time | {r['audit_time']['traditional']} | **{r['audit_time']['conjure']}** |",
    ]
    return "\n".join(lines)


def run_analysis(packages: list[str], spec_dir: str, output_path: str):
    """Full analysis pipeline."""
    from conjure.eval.dep_analyzer import analyze_packages

    print(f"Analyzing packages: {packages}")
    traditional = analyze_packages(packages)
    print(f"  Transitive deps: {traditional['transitive_count']}")

    print(f"Counting Conjure surface: {spec_dir}")
    conjure = count_conjure_surface(spec_dir)
    print(f"  Specs: {conjure['spec_count']}, LOC: {conjure['spec_loc']}")

    comparison = compare_surfaces(traditional, conjure)
    table = format_comparison_table(comparison)

    print(f"\n{table}")

    if output_path:
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w") as f:
            f.write(f"# Attack Surface Comparison\n\n")
            f.write(f"**Packages**: {', '.join(packages)}\n\n")
            f.write(table + "\n")
            f.write(f"\n## Raw Data\n\n```json\n{json.dumps(comparison, indent=2)}\n```\n")
        print(f"\nWritten to {output_path}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--packages", required=True, help="Comma-separated packages")
    parser.add_argument("--specs", default="specs/stdlib", help="Spec directory")
    parser.add_argument("--output", default="eval/attack_surface.md")
    args = parser.parse_args()

    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    run_analysis(args.packages.split(","), args.specs, args.output)
