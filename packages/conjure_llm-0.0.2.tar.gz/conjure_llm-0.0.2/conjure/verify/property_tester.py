"""Lightweight property-based tester for generated code (no Hypothesis dependency)."""

import random
import string
from dataclasses import dataclass, field

from conjure.core.spec_parser import SpecModel
from conjure.verify.sandbox import execute_function


@dataclass
class PropertyTestResult:
    passed: int
    total: int
    failures: list[dict] = field(default_factory=list)

    @property
    def all_passed(self) -> bool:
        return self.passed == self.total


def generate_random_input(param_type: str) -> object:
    """Generate a random value for a given type string.

    Handles: str, int, float, bool, list, dict, and common variations.
    """
    # Normalize the type string
    t = param_type.strip().lower()

    if t == "str" or t == "string":
        length = random.randint(0, 20)
        return "".join(random.choices(string.ascii_letters + string.digits + " ", k=length))

    if t == "int" or t == "integer":
        return random.randint(-1000, 1000)

    if t == "float" or t == "number":
        return round(random.uniform(-1000.0, 1000.0), 6)

    if t == "bool" or t == "boolean":
        return random.choice([True, False])

    if t == "list" or t.startswith("list["):
        # Generate a list of random ints (safe default)
        length = random.randint(0, 10)
        # Try to parse inner type from list[X]
        if t.startswith("list[") and t.endswith("]"):
            inner = t[5:-1]
            return [generate_random_input(inner) for _ in range(length)]
        return [random.randint(-100, 100) for _ in range(length)]

    if t == "dict" or t.startswith("dict["):
        # Generate a small dict with string keys and int values
        length = random.randint(0, 5)
        keys = random.sample(string.ascii_lowercase, min(length, 26))
        return {k: random.randint(-100, 100) for k in keys}

    if t == "tuple" or t.startswith("tuple["):
        length = random.randint(0, 5)
        return tuple(random.randint(-100, 100) for _ in range(length))

    if t == "set" or t.startswith("set["):
        length = random.randint(0, 5)
        return set(random.randint(-100, 100) for _ in range(length))

    if t == "bytes":
        length = random.randint(0, 20)
        return bytes(random.randint(0, 255) for _ in range(length))

    if t == "any" or t == "object":
        # Pick a random simple type
        choice = random.choice(["str", "int", "float", "bool", "list"])
        return generate_random_input(choice)

    # Fallback: try int
    return random.randint(-100, 100)


def _generate_kwargs(spec: SpecModel) -> dict:
    """Generate a random kwargs dict matching the spec's parameters."""
    kwargs = {}
    for param in spec.params:
        if param.default is not None and random.random() < 0.3:
            # Sometimes use the default value (skip this param)
            continue
        kwargs[param.name] = generate_random_input(param.type)
    return kwargs


def _check_return_type(value: object, return_type: str) -> bool:
    """Check if a return value matches the declared return type."""
    t = return_type.strip().lower()

    type_map = {
        "str": str, "string": str,
        "int": int, "integer": int,
        "float": (int, float), "number": (int, float),
        "bool": bool, "boolean": bool,
        "list": list, "dict": dict,
        "tuple": tuple, "set": set,
        "bytes": bytes,
        "none": type(None),
    }

    # Handle list[X], dict[X, Y], etc. by checking the outer type
    if t.startswith("list["):
        return isinstance(value, list)
    if t.startswith("dict["):
        return isinstance(value, dict)
    if t.startswith("tuple["):
        return isinstance(value, tuple)
    if t.startswith("set["):
        return isinstance(value, set)
    if t == "any" or t == "object":
        return True

    expected = type_map.get(t)
    if expected is None:
        return True  # Unknown type, skip check
    return isinstance(value, expected)


def run_property_tests(
    code: str, spec: SpecModel, n_tests: int = 20
) -> PropertyTestResult:
    """Run random input tests on generated code.

    Checks the following properties:
    1. Function does not crash on random valid inputs
    2. Output is not None (unless spec return_type is 'none')
    3. Output type matches spec return_type (if specified)
    4. Determinism: same input produces same output twice
    """
    passed = 0
    total = 0
    failures = []

    allows_none = spec.return_type.strip().lower() in ("none", "any", "object")

    for i in range(n_tests):
        kwargs = _generate_kwargs(spec)

        # --- Test 1: no crash ---
        total += 1
        result1, error1 = execute_function(
            code, spec.function_name, kwargs,
            allowed_builtins=spec.constraints.allowed_builtins,
            timeout=5.0,
        )

        if error1:
            failures.append({
                "test": i,
                "property": "no_crash",
                "input": _safe_repr(kwargs),
                "error": error1,
            })
            continue
        passed += 1

        # --- Test 2: not None ---
        if not allows_none:
            total += 1
            if result1 is None:
                failures.append({
                    "test": i,
                    "property": "not_none",
                    "input": _safe_repr(kwargs),
                    "error": "Function returned None",
                })
            else:
                passed += 1

        # --- Test 3: return type ---
        if result1 is not None:
            total += 1
            if _check_return_type(result1, spec.return_type):
                passed += 1
            else:
                failures.append({
                    "test": i,
                    "property": "return_type",
                    "input": _safe_repr(kwargs),
                    "error": (
                        f"Expected return type '{spec.return_type}', "
                        f"got {type(result1).__name__}: {_safe_repr(result1)}"
                    ),
                })

        # --- Test 4: determinism (same input, same output) ---
        total += 1
        result2, error2 = execute_function(
            code, spec.function_name, kwargs,
            allowed_builtins=spec.constraints.allowed_builtins,
            timeout=5.0,
        )

        if error2:
            failures.append({
                "test": i,
                "property": "determinism",
                "input": _safe_repr(kwargs),
                "error": f"Second call failed: {error2}",
            })
        elif result1 != result2:
            failures.append({
                "test": i,
                "property": "determinism",
                "input": _safe_repr(kwargs),
                "error": (
                    f"Non-deterministic: first={_safe_repr(result1)}, "
                    f"second={_safe_repr(result2)}"
                ),
            })
        else:
            passed += 1

    return PropertyTestResult(passed=passed, total=total, failures=failures)


def _safe_repr(obj: object, max_len: int = 200) -> str:
    """Safe repr that truncates long outputs."""
    try:
        r = repr(obj)
        if len(r) > max_len:
            return r[:max_len] + "..."
        return r
    except Exception:
        return "<repr failed>"
