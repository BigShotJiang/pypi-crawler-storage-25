"""AST constraint enforcement for generated code."""

import ast
from dataclasses import dataclass, field

from conjure.core.spec_parser import ConstraintsDef


@dataclass
class ASTCheckResult:
    passed: bool
    violations: list[str] = field(default_factory=list)


class ConstraintChecker(ast.NodeVisitor):
    """Walk AST and check for constraint violations."""

    def __init__(self, constraints: ConstraintsDef, function_name: str):
        self.constraints = constraints
        self.function_name = function_name
        self.violations: list[str] = []
        self.found_function = False

    def visit_Import(self, node: ast.Import):
        if self.constraints.no_imports:
            names = ", ".join(a.name for a in node.names)
            self.violations.append(f"Import not allowed: import {names}")
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom):
        if self.constraints.no_imports:
            self.violations.append(f"Import not allowed: from {node.module} import ...")
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        if isinstance(node.func, ast.Name):
            name = node.func.id
            if name == "eval" and self.constraints.no_eval:
                self.violations.append("eval() not allowed")
            elif name == "exec" and self.constraints.no_exec:
                self.violations.append("exec() not allowed")
            elif name == "__import__":
                self.violations.append("__import__() not allowed")
            elif name == "compile":
                self.violations.append("compile() not allowed")
            elif name == "open":
                self.violations.append("open() not allowed")
            elif name == "getattr":
                pass  # Allow getattr for now
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef):
        if node.name == self.function_name:
            self.found_function = True
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute):
        # Block os.system, subprocess, etc via attribute access
        if isinstance(node.value, ast.Name):
            if node.value.id in ("os", "sys", "subprocess", "shutil"):
                self.violations.append(f"Access to {node.value.id}.{node.attr} not allowed")
        self.generic_visit(node)


def check_ast(code: str, constraints: ConstraintsDef, function_name: str) -> ASTCheckResult:
    """Check generated code against spec constraints.

    Returns ASTCheckResult with passed=True if all checks pass.
    """
    violations = []

    # Parse
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return ASTCheckResult(passed=False, violations=[f"Syntax error: {e}"])

    # Line count
    line_count = len([l for l in code.strip().split("\n") if l.strip()])
    if line_count > constraints.max_lines:
        violations.append(f"Too many lines: {line_count} > {constraints.max_lines}")

    # Walk AST
    checker = ConstraintChecker(constraints, function_name)
    checker.visit(tree)
    violations.extend(checker.violations)

    # Function must exist
    if not checker.found_function:
        violations.append(f"Required function '{function_name}' not found")

    return ASTCheckResult(passed=len(violations) == 0, violations=violations)
