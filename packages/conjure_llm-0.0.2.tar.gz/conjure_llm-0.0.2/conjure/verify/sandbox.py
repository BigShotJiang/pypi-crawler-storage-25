"""Restricted execution environment for generated code."""

import threading
from typing import Any

# Safe subset of builtins
SAFE_BUILTINS = {
    "len": len, "range": range, "str": str, "int": int, "float": float,
    "bool": bool, "list": list, "dict": dict, "tuple": tuple, "set": set,
    "enumerate": enumerate, "zip": zip, "sorted": sorted, "reversed": reversed,
    "min": min, "max": max, "sum": sum, "abs": abs, "isinstance": isinstance,
    "type": type, "ord": ord, "chr": chr, "hex": hex, "bin": bin, "oct": oct,
    "bytes": bytes, "bytearray": bytearray, "memoryview": memoryview,
    "map": map, "filter": filter, "any": any, "all": all, "round": round,
    "divmod": divmod, "pow": pow, "hash": hash, "repr": repr,
    "True": True, "False": False, "None": None,
    "ValueError": ValueError, "TypeError": TypeError, "KeyError": KeyError,
    "IndexError": IndexError, "RuntimeError": RuntimeError,
    "StopIteration": StopIteration, "ZeroDivisionError": ZeroDivisionError,
    "Exception": Exception,
}


def _make_builtins(allowed: list[str] | None = None) -> dict:
    """Build a restricted builtins dict.

    Always includes core types (needed for type annotations in generated code),
    constants, and common exceptions regardless of allowed list.
    """
    if allowed is None:
        return dict(SAFE_BUILTINS)
    # Always-available: types for annotations, constants, exceptions
    builtins = {
        "True": True, "False": False, "None": None,
        "str": str, "int": int, "float": float, "bool": bool,
        "list": list, "dict": dict, "tuple": tuple, "set": set,
        "bytes": bytes, "bytearray": bytearray, "type": type,
        "object": object,
        "ValueError": ValueError, "TypeError": TypeError,
        "KeyError": KeyError, "IndexError": IndexError,
        "RuntimeError": RuntimeError, "Exception": Exception,
        "StopIteration": StopIteration, "ZeroDivisionError": ZeroDivisionError,
        "OverflowError": OverflowError, "AttributeError": AttributeError,
    }
    for name in allowed:
        if name in SAFE_BUILTINS:
            builtins[name] = SAFE_BUILTINS[name]
    return builtins


def execute_function(
    code: str,
    fn_name: str,
    kwargs: dict,
    allowed_builtins: list[str] | None = None,
    timeout: float = 5.0,
) -> tuple[Any, str | None]:
    """Execute a generated function in a restricted environment.

    Returns (result, error). If error is None, execution succeeded.
    """
    builtins = _make_builtins(allowed_builtins)
    namespace: dict = {"__builtins__": builtins}

    # Compile and exec the code to define the function
    try:
        compiled = compile(code, "<conjure>", "exec")
        exec(compiled, namespace)  # noqa: S102
    except Exception as e:
        return None, f"Code definition error: {type(e).__name__}: {e}"

    # Get the function
    fn = namespace.get(fn_name)
    if fn is None:
        return None, f"Function '{fn_name}' not defined"
    if not callable(fn):
        return None, f"'{fn_name}' is not callable"

    # Execute with timeout
    result = None
    error = None

    def _run():
        nonlocal result, error
        try:
            result = fn(**kwargs)
        except Exception as e:
            error = f"Runtime error: {type(e).__name__}: {e}"

    thread = threading.Thread(target=_run)
    thread.start()
    thread.join(timeout=timeout)

    if thread.is_alive():
        return None, f"Execution timed out after {timeout}s"

    return result, error
