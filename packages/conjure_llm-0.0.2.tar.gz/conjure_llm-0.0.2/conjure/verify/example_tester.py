"""Run spec examples against generated code."""

from dataclasses import dataclass, field

from conjure.core.spec_parser import SpecModel
from conjure.verify.sandbox import execute_function


@dataclass
class FailureDetail:
    index: int
    input: dict
    expected: object
    actual: object
    error: str | None = None


@dataclass
class ExampleTestResult:
    passed: int
    total: int
    failed: int
    failures: list[FailureDetail] = field(default_factory=list)

    @property
    def all_passed(self) -> bool:
        return self.failed == 0


def _values_equal(expected, actual) -> bool:
    """Compare expected and actual values with tolerance for floats."""
    if isinstance(expected, float) and isinstance(actual, float):
        return abs(expected - actual) < 1e-9
    if isinstance(expected, list) and isinstance(actual, list):
        if len(expected) != len(actual):
            return False
        return all(_values_equal(e, a) for e, a in zip(expected, actual))
    if isinstance(expected, dict) and isinstance(actual, dict):
        if set(expected.keys()) != set(actual.keys()):
            return False
        return all(_values_equal(expected[k], actual[k]) for k in expected)
    return expected == actual


def run_examples(code: str, spec: SpecModel) -> ExampleTestResult:
    """Run all spec examples against the generated code.

    Returns ExampleTestResult with pass/fail counts and failure details.
    """
    passed = 0
    failures = []
    total = len(spec.examples)

    for i, example in enumerate(spec.examples):
        result, error = execute_function(
            code,
            spec.function_name,
            example.input,
            allowed_builtins=spec.constraints.allowed_builtins,
            timeout=5.0,
        )

        if error:
            failures.append(FailureDetail(
                index=i, input=example.input,
                expected=example.output, actual=None, error=error,
            ))
        elif not _values_equal(example.output, result):
            failures.append(FailureDetail(
                index=i, input=example.input,
                expected=example.output, actual=result,
            ))
        else:
            passed += 1

    return ExampleTestResult(
        passed=passed, total=total, failed=len(failures), failures=failures,
    )
