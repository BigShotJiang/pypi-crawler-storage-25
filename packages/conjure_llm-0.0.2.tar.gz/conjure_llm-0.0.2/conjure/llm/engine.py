"""MLX inference engine for Conjure code generation."""

import logging

logger = logging.getLogger("conjure.engine")

DEFAULT_MODEL = "mlx-community/Qwen3.5-9B-OptiQ-4bit"


class ConjureEngine:
    """Generate code from specs using a local LLM via MLX."""

    def __init__(self, model_id: str = DEFAULT_MODEL, adapter_path: str | None = None):
        self.model_id = model_id
        self.adapter_path = adapter_path
        self._model = None
        self._tokenizer = None

    def _ensure_loaded(self):
        """Lazy-load the model on first use."""
        if self._model is not None:
            return
        from mlx_lm import load
        logger.info("Loading model: %s", self.model_id)
        if self.adapter_path:
            logger.info("Loading adapter: %s", self.adapter_path)
            self._model, self._tokenizer = load(
                self.model_id, adapter_path=self.adapter_path
            )
        else:
            self._model, self._tokenizer = load(self.model_id)
        logger.info("Model loaded successfully")

    def generate(self, prompt: str, max_tokens: int = 2048, temperature: float = 0.6) -> str:
        """Generate code from a prompt.

        Uses Qwen3.5 recommended settings:
        - Instruct mode (enable_thinking=False) to skip reasoning tokens
        - temp=0.6, top_p=0.95, top_k=20 for coding tasks

        Args:
            prompt: The full prompt text.
            max_tokens: Maximum tokens to generate.
            temperature: Sampling temperature.

        Returns:
            Generated text string.
        """
        self._ensure_loaded()
        from mlx_lm import generate
        from mlx_lm.sample_utils import make_sampler

        # Build chat messages with thinking disabled (instruct mode)
        messages = [{"role": "user", "content": prompt}]
        try:
            text = self._tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True,
                enable_thinking=False,
            )
        except TypeError:
            # Older tokenizer may not support enable_thinking kwarg
            text = self._tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True,
            )

        # Qwen3.5 recommended: temp=0.6, top_p=0.95, top_k=20 for coding
        sampler = make_sampler(temp=temperature, top_p=0.95)

        response = generate(
            self._model,
            self._tokenizer,
            prompt=text,
            max_tokens=max_tokens,
            sampler=sampler,
            verbose=False,
        )

        return response
