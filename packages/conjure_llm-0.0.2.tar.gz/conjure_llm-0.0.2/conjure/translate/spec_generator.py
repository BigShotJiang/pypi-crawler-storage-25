"""Auto-generate Conjure specs from Python import usage patterns.

Analyzes a Python project's source code to find library function calls,
then generates YAML spec files that could replace those imports.

Process:
1. Scan .py files for import statements
2. Track which functions/methods are actually called
3. For each usage pattern, generate a .conjure spec with:
   - Function signature inferred from call sites
   - Examples inferred from test files or common usage
   - Constraints (no_imports, etc.)
"""

import ast
import os
import sys
import json
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ImportUsage:
    """Tracks how an imported name is used."""
    module: str
    name: str  # function/class name
    alias: str | None = None
    call_count: int = 0
    call_examples: list = field(default_factory=list)  # (args, kwargs) seen
    file_locations: list = field(default_factory=list)


class UsageExtractor(ast.NodeVisitor):
    """AST visitor that extracts import statements and their usage."""

    def __init__(self):
        self.imports: dict[str, ImportUsage] = {}  # alias/name → ImportUsage
        self.current_file = ""

    def visit_Import(self, node):
        for alias in node.names:
            name = alias.asname or alias.name
            self.imports[name] = ImportUsage(
                module=alias.name, name=alias.name,
                alias=alias.asname, file_locations=[self.current_file],
            )
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        if node.module is None:
            return
        for alias in node.names:
            name = alias.asname or alias.name
            self.imports[name] = ImportUsage(
                module=node.module, name=alias.name,
                alias=alias.asname, file_locations=[self.current_file],
            )
        self.generic_visit(node)

    def visit_Call(self, node):
        # Track calls to imported names
        name = self._get_call_name(node)
        if name and name in self.imports:
            self.imports[name].call_count += 1
            # Try to extract argument info
            args_info = self._extract_args(node)
            if args_info:
                self.imports[name].call_examples.append(args_info)
        self.generic_visit(node)

    def _get_call_name(self, node):
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            if isinstance(node.func.value, ast.Name):
                return f"{node.func.value.id}.{node.func.attr}"
        return None

    def _extract_args(self, node):
        """Extract argument types from a call."""
        args = []
        for arg in node.args:
            if isinstance(arg, ast.Constant):
                args.append({"type": type(arg.value).__name__, "value": repr(arg.value)})
            elif isinstance(arg, ast.Name):
                args.append({"type": "variable", "name": arg.id})
            else:
                args.append({"type": "expression"})
        kwargs = {}
        for kw in node.keywords:
            if kw.arg and isinstance(kw.value, ast.Constant):
                kwargs[kw.arg] = {"type": type(kw.value).__name__, "value": repr(kw.value)}
        return {"args": args, "kwargs": kwargs} if args or kwargs else None


# Standard library modules that Conjure CAN replace
REPLACEABLE_STDLIB = {
    "base64": ["b64encode", "b64decode", "b32encode", "b32decode"],
    "hashlib": ["sha256", "sha1", "md5"],
    "json": ["loads", "dumps"],
    "csv": ["reader", "DictReader", "writer"],
    "statistics": ["mean", "median", "mode", "stdev", "variance"],
    "urllib.parse": ["urlparse", "urlencode", "quote", "unquote"],
    "collections": ["Counter", "defaultdict", "OrderedDict"],
    "itertools": ["chain", "groupby", "combinations", "permutations"],
    "textwrap": ["wrap", "fill", "dedent"],
    "string": ["Template"],
    "html": ["escape", "unescape"],
    "math": ["sqrt", "ceil", "floor", "gcd", "factorial"],
    "re": ["match", "search", "findall", "sub", "split"],
}

# Third-party packages that Conjure CAN replace (pure logic parts)
REPLACEABLE_THIRDPARTY = {
    "requests": ["get", "post"],  # Simple HTTP only
    "slugify": ["slugify"],
    "python-Levenshtein": ["distance", "ratio"],
    "dateutil": ["parse"],
    "pydantic": [],  # Validation patterns
    "click": [],  # CLI patterns
}

# Modules that Conjure CANNOT replace (need FFI, network, OS access)
UNREPLACEABLE = {
    "os", "sys", "subprocess", "socket", "ssl", "sqlite3",
    "threading", "multiprocessing", "asyncio",
    "PIL", "numpy", "pandas", "torch", "tensorflow",
    "flask", "fastapi", "django", "sqlalchemy",
}


def scan_project(project_dir: str) -> dict:
    """Scan a Python project and extract all import usage."""
    extractor = UsageExtractor()

    py_files = list(Path(project_dir).rglob("*.py"))
    for py_file in py_files:
        try:
            source = py_file.read_text()
            tree = ast.parse(source)
            extractor.current_file = str(py_file.relative_to(project_dir))
            extractor.visit(tree)
        except (SyntaxError, UnicodeDecodeError):
            continue

    return {
        "project_dir": project_dir,
        "files_scanned": len(py_files),
        "imports": {
            name: {
                "module": u.module,
                "name": u.name,
                "call_count": u.call_count,
                "files": u.file_locations,
                "examples": u.call_examples[:3],
            }
            for name, u in extractor.imports.items()
        },
    }


def classify_imports(scan_result: dict) -> dict:
    """Classify imports as replaceable, unreplaceable, or partial."""
    replaceable = []
    unreplaceable = []
    partial = []

    for name, info in scan_result["imports"].items():
        module = info["module"].split(".")[0]

        if module in UNREPLACEABLE:
            unreplaceable.append({**info, "alias": name, "reason": "Needs OS/FFI/network access"})
        elif module in REPLACEABLE_STDLIB:
            replaceable.append({**info, "alias": name, "source": "stdlib"})
        elif module in REPLACEABLE_THIRDPARTY:
            replaceable.append({**info, "alias": name, "source": "thirdparty"})
        else:
            partial.append({**info, "alias": name, "reason": "Unknown — needs manual review"})

    return {
        "replaceable": replaceable,
        "unreplaceable": unreplaceable,
        "partial": partial,
        "summary": {
            "total_imports": len(scan_result["imports"]),
            "replaceable_count": len(replaceable),
            "unreplaceable_count": len(unreplaceable),
            "partial_count": len(partial),
            "replacement_rate": f"{100 * len(replaceable) / max(len(scan_result['imports']), 1):.0f}%",
        },
    }


def generate_spec(name: str, module: str, call_examples: list) -> str:
    """Generate a YAML spec for a replaceable import."""
    # Infer function signature from usage
    params = []
    if call_examples:
        ex = call_examples[0]
        for i, arg in enumerate(ex.get("args", [])):
            param_name = f"arg{i}" if arg["type"] == "expression" else arg.get("name", f"arg{i}")
            param_type = arg.get("type", "any")
            if param_type == "str":
                params.append(f"  {param_name}: str")
            elif param_type == "int":
                params.append(f"  {param_name}: int")
            elif param_type == "float":
                params.append(f"  {param_name}: float")
            else:
                params.append(f"  {param_name}: any")

    if not params:
        params = ["  data: any"]

    fn_name = name.replace(".", "_").lower()

    spec = f"""spec: {fn_name}
version: 1.0.0
description: |
  Replacement for {module}.{name}.
  Auto-generated from project usage analysis.

function: {fn_name}
input:
{chr(10).join(params)}
output: any

properties:
  - same behavior as {module}.{name}
  - no imports allowed

examples:
  - input: {{}}
    output: null

constraints:
  no_imports: true
  max_lines: 400
"""
    return spec


def generate_specs(classification: dict, output_dir: str) -> dict:
    """Generate spec files for all replaceable imports."""
    os.makedirs(output_dir, exist_ok=True)
    generated = []

    for imp in classification["replaceable"]:
        fn_name = imp["name"].replace(".", "_").lower()
        spec = generate_spec(imp["name"], imp["module"], imp.get("examples", []))

        spec_path = os.path.join(output_dir, f"{fn_name}.yaml")
        with open(spec_path, "w") as f:
            f.write(spec)
        generated.append({"name": fn_name, "path": spec_path, "module": imp["module"]})

    return {
        "generated": generated,
        "count": len(generated),
        "output_dir": output_dir,
    }


def analyze_and_report(project_dir: str, output_dir: str = None) -> dict:
    """Full analysis pipeline: scan → classify → generate specs → report."""
    print(f"Scanning project: {project_dir}")
    scan = scan_project(project_dir)
    print(f"  Files scanned: {scan['files_scanned']}")
    print(f"  Imports found: {len(scan['imports'])}")

    print(f"\nClassifying imports...")
    classification = classify_imports(scan)
    s = classification["summary"]
    print(f"  Replaceable:   {s['replaceable_count']}")
    print(f"  Unreplaceable: {s['unreplaceable_count']}")
    print(f"  Needs review:  {s['partial_count']}")
    print(f"  Replacement rate: {s['replacement_rate']}")

    if output_dir:
        print(f"\nGenerating specs → {output_dir}")
        gen = generate_specs(classification, output_dir)
        print(f"  Generated: {gen['count']} spec files")
    else:
        gen = None

    # Print replaceable imports
    if classification["replaceable"]:
        print(f"\n--- Replaceable imports ---")
        for imp in classification["replaceable"]:
            print(f"  {imp['module']}.{imp['name']} (used {imp['call_count']}x) [{imp['source']}]")

    if classification["unreplaceable"]:
        print(f"\n--- Unreplaceable imports ---")
        for imp in classification["unreplaceable"]:
            print(f"  {imp['module']}.{imp['name']}: {imp['reason']}")

    return {
        "scan": scan,
        "classification": classification,
        "generated": gen,
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Generate Conjure specs from Python project")
    parser.add_argument("project_dir", help="Path to Python project")
    parser.add_argument("--output", "-o", help="Output directory for generated specs")
    parser.add_argument("--json", help="Output JSON report")
    args = parser.parse_args()

    result = analyze_and_report(args.project_dir, args.output)

    if args.json:
        with open(args.json, "w") as f:
            json.dump(result, f, indent=2, default=str)
        print(f"\nJSON report: {args.json}")
