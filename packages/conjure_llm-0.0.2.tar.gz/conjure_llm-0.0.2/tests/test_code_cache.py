"""Tests for code_cache.py."""

import os
import tempfile

import pytest
from conjure.core.code_cache import ConjureCache


@pytest.fixture
def cache():
    """Create a temporary cache for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test_cache.db")
        yield ConjureCache(db_path)


def test_put_and_get(cache):
    spec = "spec: test\nversion: 1.0.0"
    model = "test-model"
    code = "def foo(): return 42"
    cache.put(spec, model, 42, code)
    assert cache.get(spec, model, 42) == code


def test_cache_miss(cache):
    assert cache.get("nonexistent", "model", 42) is None


def test_different_seeds(cache):
    spec = "spec: test"
    model = "model"
    cache.put(spec, model, 42, "def foo(): return 42")
    cache.put(spec, model, 43, "def foo(): return 43")
    assert cache.get(spec, model, 42) == "def foo(): return 42"
    assert cache.get(spec, model, 43) == "def foo(): return 43"


def test_different_models(cache):
    spec = "spec: test"
    cache.put(spec, "model-a", 42, "code-a")
    cache.put(spec, "model-b", 42, "code-b")
    assert cache.get(spec, "model-a", 42) == "code-a"
    assert cache.get(spec, "model-b", 42) == "code-b"


def test_overwrite(cache):
    spec = "spec: test"
    model = "model"
    cache.put(spec, model, 42, "old_code")
    cache.put(spec, model, 42, "new_code")
    assert cache.get(spec, model, 42) == "new_code"


def test_verification_report(cache):
    spec = "spec: test"
    model = "model"
    report = {"passed": True, "function_name": "foo"}
    cache.put(spec, model, 42, "def foo(): return 42", report)
    assert cache.get(spec, model, 42) == "def foo(): return 42"


def test_get_by_function(cache):
    spec = "spec: test"
    model = "model"
    report = {"function_name": "my_func"}
    cache.put(spec, model, 42, "def my_func(): return 1", report)
    assert cache.get_by_function("my_func") == "def my_func(): return 1"


def test_get_by_function_miss(cache):
    assert cache.get_by_function("nonexistent") is None


def test_clear(cache):
    cache.put("spec1", "model", 42, "code1")
    cache.put("spec2", "model", 42, "code2")
    cache.clear()
    assert cache.get("spec1", "model", 42) is None
    assert cache.get("spec2", "model", 42) is None
