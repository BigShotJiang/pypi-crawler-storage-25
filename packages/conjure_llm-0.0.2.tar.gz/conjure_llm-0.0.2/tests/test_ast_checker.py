"""Tests for ast_checker.py."""

import pytest
from conjure.verify.ast_checker import check_ast
from conjure.core.spec_parser import ConstraintsDef


def default_constraints(**overrides):
    c = ConstraintsDef()
    for k, v in overrides.items():
        setattr(c, k, v)
    return c


def test_clean_code_passes():
    code = """
def add(a, b):
    return a + b
"""
    result = check_ast(code, default_constraints(), "add")
    assert result.passed
    assert result.violations == []


def test_import_detected():
    code = """
import hashlib

def sha256_hex(data):
    return hashlib.sha256(data.encode()).hexdigest()
"""
    result = check_ast(code, default_constraints(), "sha256_hex")
    assert not result.passed
    assert any("Import" in v for v in result.violations)


def test_from_import_detected():
    code = """
from os import path

def get_path(x):
    return path.join(x, "test")
"""
    result = check_ast(code, default_constraints(), "get_path")
    assert not result.passed
    assert any("Import" in v for v in result.violations)


def test_eval_detected():
    code = """
def compute(expr):
    return eval(expr)
"""
    result = check_ast(code, default_constraints(), "compute")
    assert not result.passed
    assert any("eval" in v for v in result.violations)


def test_exec_detected():
    code = """
def run(code):
    exec(code)
"""
    result = check_ast(code, default_constraints(), "run")
    assert not result.passed
    assert any("exec" in v for v in result.violations)


def test_missing_function():
    code = """
def wrong_name(x):
    return x
"""
    result = check_ast(code, default_constraints(), "expected_name")
    assert not result.passed
    assert any("expected_name" in v for v in result.violations)


def test_max_lines_exceeded():
    lines = ["def foo(x):"] + ["    x = x + 1"] * 200
    code = "\n".join(lines)
    result = check_ast(code, default_constraints(max_lines=100), "foo")
    assert not result.passed
    assert any("lines" in v.lower() for v in result.violations)


def test_max_lines_ok():
    code = """
def foo(x):
    return x + 1
"""
    result = check_ast(code, default_constraints(max_lines=10), "foo")
    assert result.passed


def test_syntax_error():
    code = "def foo(x:\n"
    result = check_ast(code, default_constraints(), "foo")
    assert not result.passed
    assert any("Syntax" in v for v in result.violations)


def test_dunder_import_detected():
    code = """
def sneaky():
    m = __import__("os")
    return m.getcwd()
"""
    result = check_ast(code, default_constraints(), "sneaky")
    assert not result.passed
    assert any("__import__" in v for v in result.violations)


def test_open_detected():
    code = """
def read_file(path):
    return open(path).read()
"""
    result = check_ast(code, default_constraints(), "read_file")
    assert not result.passed
    assert any("open" in v for v in result.violations)
