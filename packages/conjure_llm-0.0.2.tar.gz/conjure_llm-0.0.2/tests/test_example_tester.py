"""Tests for example_tester.py."""

import pytest
from conjure.verify.example_tester import run_examples
from conjure.core.spec_parser import parse_spec_string


def test_all_examples_pass():
    spec = parse_spec_string("""
spec: test
version: 1.0.0
description: add two numbers
function: add
input:
  a: int
  b: int
output: int
examples:
  - input: { a: 1, b: 2 }
    output: 3
  - input: { a: 0, b: 0 }
    output: 0
""")
    code = "def add(a, b):\n    return a + b\n"
    result = run_examples(code, spec)
    assert result.all_passed
    assert result.passed == 2
    assert result.total == 2


def test_example_failure():
    spec = parse_spec_string("""
spec: test
version: 1.0.0
description: add two numbers
function: add
input:
  a: int
  b: int
output: int
examples:
  - input: { a: 1, b: 2 }
    output: 3
  - input: { a: 0, b: 0 }
    output: 1
""")
    code = "def add(a, b):\n    return a + b\n"
    result = run_examples(code, spec)
    assert not result.all_passed
    assert result.passed == 1
    assert result.failed == 1
    assert result.failures[0].index == 1
    assert result.failures[0].expected == 1
    assert result.failures[0].actual == 0


def test_runtime_error():
    spec = parse_spec_string("""
spec: test
version: 1.0.0
description: divide
function: divide
input:
  a: int
  b: int
output: float
examples:
  - input: { a: 1, b: 0 }
    output: 0
""")
    code = "def divide(a, b):\n    return a / b\n"
    result = run_examples(code, spec)
    assert not result.all_passed
    assert result.failures[0].error is not None
    assert "ZeroDivision" in result.failures[0].error


def test_string_examples():
    spec = parse_spec_string("""
spec: test
version: 1.0.0
description: greet
function: greet
input:
  name: str
output: str
examples:
  - input: { name: "world" }
    output: "hello, world"
""")
    code = 'def greet(name):\n    return "hello, " + name\n'
    result = run_examples(code, spec)
    assert result.all_passed


def test_list_examples():
    spec = parse_spec_string("""
spec: test
version: 1.0.0
description: double list
function: double_list
input:
  nums: list
output: list
examples:
  - input: { nums: [1, 2, 3] }
    output: [2, 4, 6]
""")
    code = "def double_list(nums):\n    return [x * 2 for x in nums]\n"
    result = run_examples(code, spec)
    assert result.all_passed


def test_dict_examples():
    spec = parse_spec_string("""
spec: test
version: 1.0.0
description: group by
function: group_by
input:
  items: list
  key: str
output: dict
examples:
  - input:
      items: [{"k": "a", "v": 1}, {"k": "b", "v": 2}, {"k": "a", "v": 3}]
      key: "k"
    output:
      a: [{"k": "a", "v": 1}, {"k": "a", "v": 3}]
      b: [{"k": "b", "v": 2}]
""")
    code = """
def group_by(items, key):
    result = {}
    for item in items:
        k = item[key]
        if k not in result:
            result[k] = []
        result[k].append(item)
    return result
"""
    result = run_examples(code, spec)
    assert result.all_passed
