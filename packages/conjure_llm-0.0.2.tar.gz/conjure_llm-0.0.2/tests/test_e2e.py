"""End-to-end tests that don't require the LLM.

These tests verify the pipeline with pre-written code injected into the cache.
"""

import os
import tempfile

import pytest
from conjure.core.runtime import ConjureRuntime
from conjure.core.code_cache import ConjureCache
from conjure.core.spec_parser import parse_spec


SPEC_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "specs", "stdlib")


# Pre-written implementations for testing without LLM
IMPLEMENTATIONS = {
    "base64_encode": '''
def base64_encode(data):
    chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    if not data:
        return ""
    raw = []
    for c in data:
        raw.append(ord(c))
    result = []
    i = 0
    while i < len(raw):
        b0 = raw[i]
        b1 = raw[i + 1] if i + 1 < len(raw) else 0
        b2 = raw[i + 2] if i + 2 < len(raw) else 0
        remaining = len(raw) - i
        result.append(chars[b0 >> 2])
        result.append(chars[((b0 & 3) << 4) | (b1 >> 4)])
        if remaining >= 2:
            result.append(chars[((b1 & 15) << 2) | (b2 >> 6)])
        else:
            result.append("=")
        if remaining >= 3:
            result.append(chars[b2 & 63])
        else:
            result.append("=")
        i += 3
    return "".join(result)
''',

    "levenshtein": '''
def levenshtein(s1, s2):
    m, n = len(s1), len(s2)
    dp = list(range(n + 1))
    for i in range(1, m + 1):
        prev = dp[0]
        dp[0] = i
        for j in range(1, n + 1):
            temp = dp[j]
            if s1[i - 1] == s2[j - 1]:
                dp[j] = prev
            else:
                dp[j] = 1 + min(prev, dp[j], dp[j - 1])
            prev = temp
    return dp[n]
''',

    "slugify": '''
def slugify(text):
    result = []
    for c in text.lower():
        if (ord(c) >= ord("a") and ord(c) <= ord("z")) or (ord(c) >= ord("0") and ord(c) <= ord("9")):
            result.append(c)
        else:
            if result and result[-1] != "-":
                result.append("-")
    slug = "".join(result)
    while slug.startswith("-"):
        slug = slug[1:]
    while slug.endswith("-"):
        slug = slug[:-1]
    return slug
''',

    "group_by": '''
def group_by(items, key):
    result = {}
    for item in items:
        k = item[key]
        if k not in result:
            result[k] = []
        result[k].append(item)
    return result
''',

    "statistics": '''
def statistics(numbers):
    n = len(numbers)
    mean = sum(numbers) / n
    s = sorted(numbers)
    if n % 2 == 1:
        median = s[n // 2]
    else:
        median = (s[n // 2 - 1] + s[n // 2]) / 2
    freq = {}
    for x in numbers:
        freq[x] = freq.get(x, 0) + 1
    mode = max(freq, key=lambda x: freq[x])
    if n < 2:
        stdev = 0.0
    else:
        variance = sum((x - mean) ** 2 for x in numbers) / n
        stdev = variance ** 0.5
    return {"mean": mean, "median": median, "mode": mode, "stdev": stdev}
''',
}


class MockEngine:
    """Mock engine that returns pre-written implementations."""

    def __init__(self):
        self.model_id = "mock-model"

    def generate(self, prompt, max_tokens=2048, temperature=0.0):
        for fn_name, code in IMPLEMENTATIONS.items():
            if fn_name in prompt:
                return f"```python\n{code}\n```"
        return "def unknown(): pass"


@pytest.fixture
def runtime():
    """Create a runtime with mock engine and temp cache."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cache_path = os.path.join(tmpdir, "cache.db")
        rt = ConjureRuntime(
            model_id="mock-model",
            spec_dirs=[SPEC_DIR],
            cache_path=cache_path,
            verbose=True,
        )
        rt._engine = MockEngine()
        yield rt


class TestE2EWithMock:
    """End-to-end tests using mock engine with pre-written code."""

    def test_base64_encode(self, runtime):
        result = runtime.invoke("base64_encode", data="hello")
        assert result == "aGVsbG8="

    def test_base64_encode_empty(self, runtime):
        result = runtime.invoke("base64_encode", data="")
        assert result == ""

    def test_levenshtein(self, runtime):
        result = runtime.invoke("levenshtein", s1="kitten", s2="sitting")
        assert result == 3

    def test_levenshtein_same(self, runtime):
        result = runtime.invoke("levenshtein", s1="hello", s2="hello")
        assert result == 0

    def test_slugify(self, runtime):
        result = runtime.invoke("slugify", text="Hello World")
        assert result == "hello-world"

    def test_group_by(self, runtime):
        items = [
            {"name": "alice", "dept": "eng"},
            {"name": "bob", "dept": "sales"},
            {"name": "charlie", "dept": "eng"},
        ]
        result = runtime.invoke("group_by", items=items, key="dept")
        assert len(result["eng"]) == 2
        assert len(result["sales"]) == 1

    def test_cache_hit(self, runtime):
        """Second call should use cached code."""
        runtime.invoke("base64_encode", data="test")
        # Clear the engine to prove cache is used
        runtime._engine = None
        result = runtime.invoke("base64_encode", data="test")
        assert result is not None

    def test_unknown_spec_raises(self, runtime):
        with pytest.raises(ValueError, match="No spec found"):
            runtime.invoke("nonexistent_function")

    def test_statistics(self, runtime):
        result = runtime.invoke("statistics", numbers=[1, 2, 3, 4, 5])
        assert abs(result["mean"] - 3.0) < 1e-9
        assert result["median"] == 3


class TestSpecsLoadable:
    """Verify all stdlib specs can be parsed."""

    def test_all_specs_parse(self):
        spec_files = [
            f for f in os.listdir(SPEC_DIR) if f.endswith(".yaml")
        ]
        assert len(spec_files) >= 10, f"Expected >=10 specs, found {len(spec_files)}"

        for spec_file in spec_files:
            path = os.path.join(SPEC_DIR, spec_file)
            spec = parse_spec(path)
            assert spec.name, f"{spec_file}: missing name"
            assert spec.function_name, f"{spec_file}: missing function name"
            assert spec.version, f"{spec_file}: missing version"
            assert len(spec.examples) > 0, f"{spec_file}: no examples"
