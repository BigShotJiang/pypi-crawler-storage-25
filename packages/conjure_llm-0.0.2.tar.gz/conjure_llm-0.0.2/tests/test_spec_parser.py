"""Tests for spec_parser.py."""

import pytest
from conjure.core.spec_parser import parse_spec_string, SpecModel


SAMPLE_SPEC = """
spec: test_func
version: 1.0.0
description: |
  A test function that adds two numbers.

function: add_numbers
input:
  a: int
  b: int
output:
  int

properties:
  - add_numbers(0, x) == x for any x
  - add_numbers(a, b) == add_numbers(b, a) (commutative)

examples:
  - input: { a: 1, b: 2 }
    output: 3
  - input: { a: 0, b: 0 }
    output: 0
  - input: { a: -1, b: 1 }
    output: 0

constraints:
  no_imports: true
  max_lines: 10
  allowed_builtins: [int]
"""


def test_parse_basic_spec():
    spec = parse_spec_string(SAMPLE_SPEC)
    assert isinstance(spec, SpecModel)
    assert spec.name == "test_func"
    assert spec.version == "1.0.0"
    assert spec.function_name == "add_numbers"


def test_parse_params():
    spec = parse_spec_string(SAMPLE_SPEC)
    assert len(spec.params) == 2
    assert spec.params[0].name == "a"
    assert spec.params[0].type == "int"
    assert spec.params[0].default is None
    assert spec.params[1].name == "b"


def test_parse_return_type():
    spec = parse_spec_string(SAMPLE_SPEC)
    assert spec.return_type == "int"


def test_parse_properties():
    spec = parse_spec_string(SAMPLE_SPEC)
    assert len(spec.properties) == 2
    assert "commutative" in spec.properties[1]


def test_parse_examples():
    spec = parse_spec_string(SAMPLE_SPEC)
    assert len(spec.examples) == 3
    assert spec.examples[0].input == {"a": 1, "b": 2}
    assert spec.examples[0].output == 3


def test_parse_constraints():
    spec = parse_spec_string(SAMPLE_SPEC)
    assert spec.constraints.no_imports is True
    assert spec.constraints.max_lines == 10
    assert spec.constraints.allowed_builtins == ["int"]


def test_parse_description():
    spec = parse_spec_string(SAMPLE_SPEC)
    assert "test function" in spec.description


def test_parse_default_params():
    yaml_text = """
spec: test
version: 1.0.0
description: test
function: foo
input:
  name: str
  separator: str = "-"
output: str
examples:
  - input: { name: "hello" }
    output: "hello"
"""
    spec = parse_spec_string(yaml_text)
    assert spec.params[1].default == '"-"'


def test_parse_no_constraints():
    yaml_text = """
spec: minimal
version: 1.0.0
description: minimal spec
function: noop
input:
  x: int
output: int
examples:
  - input: { x: 1 }
    output: 1
"""
    spec = parse_spec_string(yaml_text)
    assert spec.constraints.no_imports is True  # Default
    assert spec.constraints.max_lines == 100  # Default
