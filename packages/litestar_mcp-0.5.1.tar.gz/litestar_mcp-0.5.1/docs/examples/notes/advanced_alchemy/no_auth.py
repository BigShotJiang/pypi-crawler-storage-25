"""No-auth Advanced Alchemy reference notes example."""

# /// script
# requires-python = ">=3.10"
# dependencies = [
#   "litestar[standard]>=2.0",
#   "litestar-mcp",
#   "advanced-alchemy[litestar]>=1.0",
#   "aiosqlite",
#   "uvicorn",
# ]
# ///

from pathlib import Path
from typing import Any
from uuid import UUID

import msgspec
from advanced_alchemy.extensions.litestar import (
    AsyncSessionConfig,
    SQLAlchemyAsyncConfig,
    SQLAlchemyPlugin,
    providers,
)
from advanced_alchemy.service import OffsetPagination
from litestar import Controller, Litestar, delete, get, post
from litestar.status_codes import HTTP_200_OK

from docs.examples.notes.advanced_alchemy.common import NoteService
from docs.examples.notes.shared.contracts import (
    APP_INFO_RESOURCE_NAME,
    CREATE_NOTE_TOOL_NAME,
    DELETE_NOTE_TOOL_NAME,
    LIST_NOTES_TOOL_NAME,
    NOTES_SCHEMA_RESOURCE_NAME,
    AppInfo,
    CreateNoteInput,
    DeleteNoteResult,
    Note,
    NotesSchema,
)
from litestar_mcp import LitestarMCP, MCPConfig


def create_app(database_path: str | None = None) -> Litestar:
    """Create the Advanced Alchemy reference notes app (no auth).

    Args:
        database_path: Optional SQLite file path. When omitted, a
            ``.reference-notes-aa.sqlite`` file in the current working
            directory is used.
    """
    sqlite_path = Path(database_path or Path.cwd() / ".reference-notes-aa.sqlite")
    alchemy_config = SQLAlchemyAsyncConfig(
        connection_string=f"sqlite+aiosqlite:///{sqlite_path}",
        create_all=True,
        before_send_handler="autocommit",
        session_config=AsyncSessionConfig(expire_on_commit=False),
    )

    class NoteController(Controller):
        path = "/notes"
        dependencies = providers.create_service_dependencies(NoteService, "note_service", config=alchemy_config)

        @get("/", mcp_tool=LIST_NOTES_TOOL_NAME)
        async def list_notes(self, note_service: NoteService) -> OffsetPagination[Note]:
            notes = await note_service.list()
            return note_service.to_schema(notes, schema_type=Note)

        @post("/", mcp_tool=CREATE_NOTE_TOOL_NAME)
        async def create_note(self, data: dict[str, Any], note_service: NoteService) -> Note:
            payload = msgspec.convert(data, CreateNoteInput)
            note = await note_service.create({"title": payload.title, "body": payload.body}, auto_commit=True)
            return note_service.to_schema(note, schema_type=Note)

        @delete("/{note_id:str}", status_code=HTTP_200_OK, mcp_tool=DELETE_NOTE_TOOL_NAME)
        async def delete_note(self, note_id: str, note_service: NoteService) -> DeleteNoteResult:
            await note_service.delete(UUID(note_id), auto_commit=True)
            return DeleteNoteResult(deleted=True, note_id=note_id)

    @get("/notes/schema", mcp_resource=NOTES_SCHEMA_RESOURCE_NAME, sync_to_thread=False)
    def notes_schema() -> NotesSchema:
        return NotesSchema()

    @get("/app/info", mcp_resource=APP_INFO_RESOURCE_NAME, sync_to_thread=False)
    def get_api_info() -> AppInfo:
        return AppInfo(
            name="Reference Notes",
            backend="advanced_alchemy",
            auth_mode="none",
            supports_dishka=False,
        )

    return Litestar(
        route_handlers=[NoteController, notes_schema, get_api_info],
        plugins=[SQLAlchemyPlugin(config=alchemy_config), LitestarMCP(MCPConfig())],
    )
