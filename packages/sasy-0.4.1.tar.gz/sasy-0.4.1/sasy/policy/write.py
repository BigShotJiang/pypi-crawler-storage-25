"""
Write policy from English — compile via the sasy-write service.

Submits an English policy description to the sasy-write
REST API, polls for completion, and returns a rich result
with verification artifacts.
"""

import logging
import re
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable, Optional

import httpx
from pydantic import BaseModel

from sasy.config import get_config

logger = logging.getLogger(__name__)


# ── Response models (customer-facing) ───────────────


class TruthTableSummary(BaseModel):
    """Scenario coverage from the truth table."""

    rows: int
    allow: int
    deny: int
    guard_deny: int


class AssertionSummary(BaseModel):
    """Assertion results: policy vs scenario decisions."""

    total: int
    passed: int
    mismatches: int


class VerificationSummary(BaseModel):
    """Curated verification metrics."""

    truth_table: TruthTableSummary
    assertions: AssertionSummary
    independent_checks_passed: int
    independent_checks_total: int
    round_trip_audit: str  # "PASS" | "FAIL"


class WritePolicyResult(BaseModel):
    """Result of compiling an English policy to Datalog.

    Contains the generated Datalog, structured spec
    clauses, truth table, and verification metrics.
    Use ``print_summary()`` for a human-readable
    confidence report.
    """

    status: str  # "success" | "failure"
    datalog: Optional[str] = None
    structured_spec: Optional[str] = None
    truth_table_tsv: Optional[str] = None
    verification: Optional[VerificationSummary] = None
    errors: list[str] = []
    request_id: str = ""
    duration_seconds: Optional[float] = None

    def save_datalog(self, path: str | Path) -> Path:
        """Save the generated Datalog policy to a file.

        Args:
            path: Destination file path.

        Returns:
            The resolved Path written to.

        Raises:
            ValueError: If no Datalog was generated.
        """
        if not self.datalog:
            raise ValueError(
                "No Datalog policy available"
                " (compilation may have failed)"
            )
        p = Path(path)
        p.write_text(self.datalog)
        return p

    def save_truth_table(self, path: str | Path) -> Path:
        """Save the truth table TSV to a file.

        Args:
            path: Destination file path.

        Returns:
            The resolved Path written to.

        Raises:
            ValueError: If no truth table is available.
        """
        if not self.truth_table_tsv:
            raise ValueError("No truth table available")
        p = Path(path)
        p.write_text(self.truth_table_tsv)
        return p

    def print_summary(self) -> None:
        """Print a human-readable confidence report."""
        dur = (
            f" ({self.duration_seconds:.0f}s)"
            if self.duration_seconds
            else ""
        )
        lines = [
            "Policy Compilation Result",
            "=" * 40,
            f"Status:       {self.status.upper()}{dur}",
        ]

        if self.structured_spec:
            clauses = re.findall(
                r"^(C\d+):", self.structured_spec, re.M
            )
            if clauses:
                first, last = clauses[0], clauses[-1]
                lines.append("")
                lines.append("Structured Spec")
                lines.append(
                    f"  {len(clauses)} clauses"
                    f" ({first}-{last})"
                )

        v = self.verification
        if v:
            tt = v.truth_table
            a = v.assertions
            lines.append("")
            lines.append("Verification")
            lines.append(
                f"  Truth table:        "
                f"{tt.rows} scenarios"
            )
            lines.append(
                f"    {tt.allow} ALLOW"
                f" | {tt.deny} DENY"
                f" | {tt.guard_deny} GUARD_DENY"
            )
            lines.append(
                f"  Assertions:         "
                f"{a.passed}/{a.total} passed"
            )
            lines.append(
                f"  Independent checks: "
                f"{v.independent_checks_passed}"
                f"/{v.independent_checks_total}"
                f" passed"
            )
            lines.append(
                f"  Round-trip audit:   "
                f"{v.round_trip_audit}"
            )

        if self.errors:
            lines.append("")
            lines.append("Errors")
            for e in self.errors:
                lines.append(f"  - {e}")

        print("\n".join(lines))


# ── Main SDK function ───────────────────────────────


ProgressCallback = Callable[[str, float], None]


def _parse_verification(
    raw: Optional[dict],  # type: ignore[type-arg]
) -> VerificationSummary | None:
    """Parse the server's verification dict."""
    if not raw:
        return None
    tt = raw.get("truth_table") or {}
    da = raw.get("datalog_assertions") or {}
    return VerificationSummary(
        truth_table=TruthTableSummary(
            rows=tt.get("rows", 0),
            allow=tt.get("allow", 0),
            deny=tt.get("deny", 0),
            guard_deny=tt.get("guard_deny", 0),
        ),
        assertions=AssertionSummary(
            total=da.get("total", 0),
            passed=da.get("passed", 0),
            mismatches=da.get("mismatches", 0),
        ),
        independent_checks_passed=raw.get(
            "independent_checks_passed", 0
        ),
        independent_checks_total=raw.get(
            "independent_checks_total", 0
        ),
        round_trip_audit=raw.get(
            "round_trip_audit", "UNKNOWN"
        ),
    )


def write_policy(
    english: str,
    *,
    model: Optional[str] = None,
    poll_interval: float = 10.0,
    timeout: float = 900.0,
    on_progress: Optional[ProgressCallback] = None,
) -> WritePolicyResult:
    """Compile an English policy into verified Datalog.

    Submits the English text to the sasy-write service,
    polls until the compilation job finishes, and returns
    a rich result with the generated Datalog and
    verification artifacts.

    Args:
        english: Natural-language policy description.
        model: Model override (e.g. ``"haiku"``,
            ``"sonnet"``, ``"opus"``). Server default
            if omitted.
        poll_interval: Seconds between status polls.
        timeout: Maximum seconds to wait before raising.
        on_progress: Optional callback invoked on each
            poll with ``(stage, elapsed_seconds)``.

    Returns:
        WritePolicyResult with Datalog, structured spec,
        truth table, and verification metrics.

    Raises:
        TimeoutError: If the job doesn't finish within
            *timeout* seconds.
        httpx.HTTPStatusError: On unexpected HTTP errors.
    """
    cfg = get_config()
    base = cfg.write_url.rstrip("/")

    # Pass API key from the auth hook metadata.
    headers: dict[str, str] = {}
    for k, v in cfg.get_metadata():
        if k.lower() == "x-api-key":
            headers["x-api-key"] = v

    with httpx.Client(timeout=30.0) as client:
        # ── Submit job ──────────────────────────
        resp = client.post(
            f"{base}/v1/policy/write",
            headers=headers,
            json={
                "english": english,
                **({"model": model} if model else {}),
            },
        )
        resp.raise_for_status()
        job = resp.json()
        job_id = job["job_id"]
        logger.info("Submitted job %s", job_id)

        # ── Poll until done ─────────────────────
        deadline = time.monotonic() + timeout
        while True:
            time.sleep(poll_interval)

            if time.monotonic() > deadline:
                raise TimeoutError(
                    f"Job {job_id} did not complete"
                    f" within {timeout}s"
                )

            resp = client.get(
                f"{base}/v1/policy/write"
                f"/status/{job_id}",
            )
            resp.raise_for_status()
            status = resp.json()

            stage = status.get("stage", "unknown")
            elapsed = status.get("elapsed_seconds", 0.0)

            if on_progress:
                on_progress(stage, elapsed)

            if status["status"] == "running":
                logger.debug(
                    "Job %s: %s (%.0fs)",
                    job_id,
                    stage,
                    elapsed,
                )
                continue

            # ── Job finished ────────────────────
            result_data = status.get("result") or {}
            verification = _parse_verification(
                result_data.get("verification")
            )

            return WritePolicyResult(
                status=result_data.get(
                    "status", status["status"]
                ),
                datalog=result_data.get("datalog"),
                structured_spec=result_data.get(
                    "structured_spec"
                ),
                truth_table_tsv=result_data.get(
                    "truth_table_tsv"
                ),
                verification=verification,
                errors=result_data.get("errors", []),
                request_id=job_id,
                duration_seconds=result_data.get(
                    "duration_seconds", elapsed
                ),
            )


def write_policies(
    english_texts: list[str],
    *,
    model: Optional[str] = None,
    poll_interval: float = 10.0,
    timeout: float = 900.0,
    on_progress: Optional[ProgressCallback] = None,
) -> list[WritePolicyResult]:
    """Compile multiple English policies concurrently.

    Submits all policies in parallel and polls each
    until completion. Useful for testing whether
    different phrasings produce equivalent Datalog.

    Args:
        english_texts: List of English policy texts.
        model: Model override. Server default if omitted.
        poll_interval: Seconds between status polls.
        timeout: Maximum seconds to wait per job.
        on_progress: Optional callback invoked with
            ``(stage, elapsed_seconds)`` on each poll.
            Called from multiple threads.

    Returns:
        List of WritePolicyResult in the same order
        as the input texts.

    Raises:
        TimeoutError: If any job exceeds *timeout*.
        httpx.HTTPStatusError: On unexpected HTTP errors.
    """

    def _run(english: str) -> WritePolicyResult:
        return write_policy(
            english,
            model=model,
            poll_interval=poll_interval,
            timeout=timeout,
            on_progress=on_progress,
        )

    with ThreadPoolExecutor(
        max_workers=len(english_texts),
    ) as pool:
        return list(pool.map(_run, english_texts))
