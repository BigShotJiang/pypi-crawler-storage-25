#!/usr/bin/env python3
"""janus-remote employee MCP — the remote "darcy" memory bridge.

Runs on the REMOTE box, attached to a hat-scoped sub-agent claude via
`--mcp-config`. Exposes one tool, `save_employee_memory`, which pushes a memory
note back to the LOCAL machine over the Janus WS bridge (reverse-tunneled to the
user's local janusapp on JANUS_BRIDGE_PORT). The hat's memory lives canonically
on the local box; this is how a hat working on a remote box writes home.

We do NOT change how claude itself works — this is just an extra tool. Darcy is
still one Darcy in a hat; this only routes the hat's memory to the right place.

Protocol: newline-delimited JSON-RPC 2.0 over stdin/stdout (Claude Code's MCP
stdio transport, same framing janus's darcy-mcp-server.js uses). All logging
goes to stderr so it never corrupts the protocol stream.

Env (set by subagent_run.py): JANUS_BRIDGE_PORT, JANUS_PROFILE_ID, JANUS_EMPLOYEE.
"""
import sys
import os
import json


def _log(msg):
    sys.stderr.write(f"[employee-mcp] {msg}\n")
    sys.stderr.flush()


def _send(obj):
    sys.stdout.write(json.dumps(obj) + "\n")
    sys.stdout.flush()


TOOL = {
    "name": "save_employee_memory",
    "description": (
        "Save a memory note for the hat you're wearing. It syncs back to your "
        "memory on the local machine (your memory lives there, not on this remote "
        "box). Call this when you learn something durable about this domain you'd "
        "want next time you wear this hat. Standard auto-memory markdown format "
        "(frontmatter name/description/type, then body)."
    ),
    "inputSchema": {
        "type": "object",
        "properties": {
            "filename": {
                "type": "string",
                "description": "Memory filename, kebab-case, ending in .md (e.g. 'sip-retry-logic.md').",
            },
            "content": {
                "type": "string",
                "description": "The full markdown content of the memory note.",
            },
        },
        "required": ["filename", "content"],
    },
}


def _push_memory(filename, content):
    port = os.environ.get("JANUS_BRIDGE_PORT")
    profile = os.environ.get("JANUS_PROFILE_ID", "")
    emp = os.environ.get("JANUS_EMPLOYEE", "")
    if not port:
        return False, "JANUS_BRIDGE_PORT not set — no bridge to sync to"
    try:
        from websocket import create_connection  # websocket-client (janus-remote dep)
    except Exception as e:
        return False, f"websocket-client unavailable: {e}"
    try:
        ws = create_connection(f"ws://localhost:{port}", timeout=10)
        ws.send(json.dumps({
            "type": "employee-memory-sync",
            "profileId": profile,
            "employeeId": emp,
            "filename": filename,
            "content": content,
        }))
        try:
            ws.settimeout(5)
            ws.recv()  # best-effort ack
        except Exception:
            pass
        ws.close()
        return True, "synced to local memory"
    except Exception as e:
        return False, f"bridge send failed: {e}"


def _handle(req):
    method = req.get("method")
    rid = req.get("id")
    if method == "initialize":
        _send({"jsonrpc": "2.0", "id": rid, "result": {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "darcy_employee", "version": "0.1.0"},
        }})
    elif method == "notifications/initialized":
        pass  # notification — no response
    elif method == "tools/list":
        _send({"jsonrpc": "2.0", "id": rid, "result": {"tools": [TOOL]}})
    elif method == "tools/call":
        params = req.get("params") or {}
        name = params.get("name")
        args = params.get("arguments") or {}
        if name != "save_employee_memory":
            _send({"jsonrpc": "2.0", "id": rid, "result": {
                "content": [{"type": "text", "text": f"unknown tool: {name}"}], "isError": True}})
            return
        filename = str(args.get("filename") or "").strip()
        content = args.get("content")
        if not filename.endswith(".md") or not isinstance(content, str) or not content.strip():
            _send({"jsonrpc": "2.0", "id": rid, "result": {
                "content": [{"type": "text", "text": "filename (.md) and non-empty content required"}], "isError": True}})
            return
        ok, detail = _push_memory(filename, content)
        _send({"jsonrpc": "2.0", "id": rid, "result": {
            "content": [{"type": "text", "text": ("Saved — " if ok else "Save FAILED — ") + detail}],
            "isError": (not ok)}})
    elif rid is not None:
        _send({"jsonrpc": "2.0", "id": rid, "error": {"code": -32601, "message": f"method not found: {method}"}})


def _apply_cli_overrides(argv):
    # Prefer explicit CLI args over env — some Claude Code builds don't forward
    # the mcp-config `env` block to the MCP process, so we also accept the same
    # values as flags and let them win.
    import argparse
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument('--bridge-port', default=None)
    p.add_argument('--profile', default=None)
    p.add_argument('--employee', default=None)
    try:
        a, _ = p.parse_known_args(argv)
    except SystemExit:
        return
    if a.bridge_port:
        os.environ['JANUS_BRIDGE_PORT'] = str(a.bridge_port)
    if a.profile:
        os.environ['JANUS_PROFILE_ID'] = a.profile
    if a.employee:
        os.environ['JANUS_EMPLOYEE'] = a.employee


def main():
    _apply_cli_overrides(sys.argv[1:])
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except Exception:
            continue
        try:
            _handle(req)
        except Exception as e:
            _log(f"handler error: {e}")


if __name__ == "__main__":
    main()
