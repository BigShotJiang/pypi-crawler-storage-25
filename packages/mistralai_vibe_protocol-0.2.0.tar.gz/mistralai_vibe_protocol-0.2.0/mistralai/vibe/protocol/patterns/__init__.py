"""Task pattern implementations (AgentTask, ToolTask)."""
