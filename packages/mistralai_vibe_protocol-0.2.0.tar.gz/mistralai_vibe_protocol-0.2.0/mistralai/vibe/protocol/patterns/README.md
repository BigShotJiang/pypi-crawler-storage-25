# patterns/

Task implementations built on the protocol and modules layers.

Each pattern implements the `Task` protocol and provides a specific execution strategy. Patterns compose generic engine components from `modules/` into working tasks.

## Modules

- **agent.py** — `AgentTask` and `AgentModule`: LLM-driven task pattern and reference implementation for creating new task types (see [modules/ recipe](../modules/README.md#creating-a-new-task-pattern)). `AgentModule` is a `StateModule` subclass that combines a master reducer (routing to sub-reducers) with standalone effect handlers registered via `EffectRegistry`. Composes `sub_task_reducer` from `modules/sub_task.py` via delegation. `AgentTask.run()` wraps the module in an `ExecutionLoop` backed by `_QueueBackedDownstream` and returns a `LocalChannel`.

- **tool.py** — `ToolTask`: Simplest task pattern. Wraps a sync/async function. No reducer, no dispatch loop. Calls `fn(state.input)`, emits `CompletedOutput`, done.

- **completion/** — LLM completion domain:
  - `port.py` — `CompletionModel` protocol (async iterator of `CompletionChunk`).
  - `types.py` — `CompletionRequest`, `CompletionChunk`, `ToolCallDelta`.
  - `messages.py` — `Message`, `ToolCall`, `FunctionCall` (OpenAI/Mistral format).
  - `bridge.py` — `stream_to_mutations()` (LLM streaming bridge) and `build_completion_request_from_state()` (request builder).
  - `adapters/mistral.py` — `MistralAdapter` for the Mistral API.

## Usage

```python
from vibe_sdk.patterns.agent import AgentTask
from vibe_sdk.patterns.tool import ToolTask

# Wrap a function as a tool
tool = ToolTask(fn=my_function, name="my_tool", description="Does something")

# Create an LLM-driven agent with tools
agent = AgentTask(
    completion=my_llm_adapter,
    tasks={"my_tool": tool},
    system_prompt="You are helpful.",
)

# Run and stream results
channel = await agent.run(initial_state)
async for message in channel:
    print(message)
```

## Dependencies

Depends on `protocol/` (types, channel, task protocol), `modules/` (dispatch, sub_task, produce, json_patch, network), and `completion/` (types, port, messages).

## See Also

- [modules/](../modules/) — Generic engine components (ExecutionLoop, StateModule ABC, Downstream protocol, sub-task building blocks)
- [protocol/](../protocol/) — Pure types and contracts
- [ARCHITECTURE.md](../../../ARCHITECTURE.md) — System design overview
