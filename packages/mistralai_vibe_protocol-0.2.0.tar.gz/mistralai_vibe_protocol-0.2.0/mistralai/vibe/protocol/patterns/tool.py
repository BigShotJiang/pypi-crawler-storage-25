"""ToolTask — wraps a plain function as a Task.

Backed by ToolModule (a trivial one-step StateModule):

    Initialize → [CallFunction effect] → FunctionComplete → CompletedOutput

Handles sync and async functions. On exception, produces FailedOutput.
Inherits execute()/run() from ModuleTask[ToolTaskConfig].
"""

import importlib
import inspect
import json
from collections.abc import Callable
from functools import reduce
from typing import Any, Literal

import structlog
from pydantic import BaseModel

from mistralai.vibe.protocol.modules.execution import EffectRegistry, StateModule, StateSink
from mistralai.vibe.protocol.modules.task import ModuleTask, TaskConfigBase
from mistralai.vibe.protocol.types.state import CompletedOutput, FailedOutput, TaskState

logger = structlog.get_logger()


def _import_dotted_path(dotted_path: str) -> Any:
    """Import a callable from a dotted path like ``json.JSONEncoder.encode``.

    Tries progressively shorter module paths until one imports, then
    walks the remaining segments via getattr. Handles class methods,
    nested classes, and other non-top-level callables that
    ``rsplit('.', 1)`` cannot resolve.
    """
    parts = dotted_path.split(".")
    # Try longest module path first, shorten until import succeeds
    for i in range(len(parts), 0, -1):
        module_path = ".".join(parts[:i])
        try:
            mod = importlib.import_module(module_path)
        except (ImportError, ModuleNotFoundError):
            continue
        if i == len(parts):
            return mod
        return reduce(getattr, parts[i:], mod)
    msg = f"Cannot import '{dotted_path}': no importable module prefix found"
    raise ImportError(msg)


# ---------------------------------------------------------------------------
# Serializable task config
# ---------------------------------------------------------------------------


class ToolTaskConfig(TaskConfigBase):
    """Config for reconstructing a ToolTask from a dotted import path."""

    type: Literal["tool"] = "tool"
    fn_path: str  # e.g. "myapp.tools.web_search"
    name: str
    description: str = ""
    input_schema: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# Actions and effects
# ---------------------------------------------------------------------------


class ToolInitialize(BaseModel):
    """Seed action for ToolModule."""


class CallFunction(BaseModel):
    """Effect: call the wrapped function.

    Carries state for argument extraction and fn_path for
    reconstruction on the activity path.
    """

    state: TaskState
    fn_path: str | None = None


class FunctionComplete(BaseModel):
    """Action: function completed. Carries the output state."""

    output_state: TaskState


# ---------------------------------------------------------------------------
# Effect handler registry
# ---------------------------------------------------------------------------

_tool_registry = EffectRegistry()


@_tool_registry.handles(CallFunction)
async def _handle_call_function(
    effect: CallFunction,
    sink: StateSink,
    fn: Callable[..., Any] | None = None,
) -> list[FunctionComplete]:
    """Call the wrapped function, return FunctionComplete.

    On the local path, the module injects ``fn`` directly.
    On the workflow activity path, ``fn`` is None and the handler
    imports the function from ``effect.fn_path``.
    """
    if fn is None:
        if effect.fn_path is None:
            msg = "No fn and no fn_path on CallFunction effect"
            raise ValueError(msg)
        fn = _import_dotted_path(effect.fn_path)

    assert fn is not None
    state = effect.state
    try:
        args = state.input
        if isinstance(args, dict):
            result = fn(**args)
        elif args is not None:
            result = fn(args)
        else:
            result = fn()

        if inspect.isawaitable(result):
            result = await result

        if isinstance(result, str):
            output_value = result
        else:
            try:
                output_value = json.loads(json.dumps(result, default=str))
            except (TypeError, ValueError):
                output_value = str(result)

        new_state = state.model_copy(update={"output": CompletedOutput(value=output_value)})
    except Exception as e:
        logger.exception("tool.execution_failed")
        new_state = state.model_copy(update={"output": FailedOutput(error=str(e))})

    return [FunctionComplete(output_state=new_state)]


# ---------------------------------------------------------------------------
# ToolModule — trivial one-step StateModule
# ---------------------------------------------------------------------------


class ToolModule(StateModule):
    """StateModule for a function-wrapping tool task.

    One-step lifecycle: Initialize → CallFunction → FunctionComplete → done.
    """

    effect_handlers = _tool_registry
    initial_action_type = ToolInitialize

    def __init__(self, fn: Callable[..., Any] | None, fn_path: str | None = None) -> None:
        self._fn = fn
        self._fn_path = fn_path

    def reduce(self, state: TaskState, action: Any) -> tuple[TaskState, list[Any]]:
        match action:
            case ToolInitialize():
                return (state, [CallFunction(state=state, fn_path=self._fn_path)])
            case FunctionComplete(output_state=output_state):
                return (output_state, [])
        return (state, [])

    async def handle_effect(self, effect: Any, sink: StateSink) -> list[Any]:
        handler = self.effect_handlers.get(type(effect))
        if handler is None:
            return []
        if isinstance(effect, CallFunction):
            result: list[Any] = await handler(effect, sink, fn=self._fn)
            return result
        result = await handler(effect, sink)
        return result


# ---------------------------------------------------------------------------
# ToolTask — ModuleTask wrapping a plain function
# ---------------------------------------------------------------------------


class ToolTask(ModuleTask[ToolTaskConfig]):
    """Wraps a plain function as a Task backed by ToolModule.

    The simplest task pattern. Given a function, it calls fn(state.input)
    and produces CompletedOutput or FailedOutput. Handles both sync and
    async functions.

    Inherits execute(), run(), and card metadata from ModuleTask.
    """

    def __init__(
        self,
        fn: Callable[..., Any] | None,
        name: str = "",
        description: str = "",
        input_schema: dict[str, Any] | None = None,
        output_schema: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            input_schema=input_schema,
            output_schema=output_schema,
        )
        self.fn = fn
        if fn is not None:
            self.fn_path = f"{fn.__module__}.{fn.__qualname__}"
        else:
            self.fn_path = ""

    def create_module(self) -> ToolModule:
        return ToolModule(fn=self.fn, fn_path=self.fn_path)

    @classmethod
    def from_config(cls, config: Any, **kwargs: Any) -> "ToolTask":
        if not isinstance(config, ToolTaskConfig):
            config = ToolTaskConfig.model_validate(config)
        fn = _import_dotted_path(config.fn_path)
        return cls(
            fn=fn,
            name=config.name,
            description=config.description,
            input_schema=config.input_schema,
        )

    @classmethod
    def from_config_for_workflow(cls, config: Any, **kwargs: Any) -> "ToolTask":
        if not isinstance(config, ToolTaskConfig):
            config = ToolTaskConfig.model_validate(config)
        task = cls(
            fn=None,
            name=config.name,
            description=config.description,
            input_schema=config.input_schema,
        )
        task.fn_path = config.fn_path
        return task
