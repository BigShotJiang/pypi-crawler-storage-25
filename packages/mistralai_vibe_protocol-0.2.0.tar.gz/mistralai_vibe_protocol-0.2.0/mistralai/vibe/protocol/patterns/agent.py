"""Agent pattern — LLM-driven task with tool calling and subtask orchestration.

AgentTask drives a conversation loop: call LLM → execute tool calls → repeat,
using ExecutionLoop for action processing and sub_task_reducer for child tasks.
"""

import json
from typing import Any, Literal

from pydantic import BaseModel, SerializeAsAny

from mistralai.vibe.protocol.modules.execution import (
    CallbackBridge,
    DownstreamWriter,
    EffectRegistry,
    ExecutionLoop,
    LocalCallbackBridge,
    StateModule,
    StateSink,
)
from mistralai.vibe.protocol.modules.json_patch import apply_patches, reroute_patches
from mistralai.vibe.protocol.modules.produce import diff
from mistralai.vibe.protocol.modules.sub_task import (
    CallbackResultReceived,
    CallCallback,
    SpawnSubTask,
    SubTaskCallRequest,
    SubTaskCompleted,
    _update_result_entry,
    resolve_callback_request,
    sub_task_reducer,
)
from mistralai.vibe.protocol.modules.task import ModuleTask, TaskConfigBase
from mistralai.vibe.protocol.patterns.completion.bridge import (
    build_completion_request_from_state,
    stream_states,
)
from mistralai.vibe.protocol.patterns.completion.port import CompletionModel
from mistralai.vibe.protocol.types.events import (
    CallbackCallEvent,
    CallbackCallPayload,
    TaskResultEvent,
    TaskStateUpdateEvent,
)
from mistralai.vibe.protocol.types.state import (
    CompletedOutput,
    MessageEntry,
    MessageEntryPayload,
    TaskCallEntry,
    TaskResultEntry,
    TaskState,
    content_blocks,
    content_text,
)
from mistralai.vibe.protocol.types.task import TaskCallback

# ---------------------------------------------------------------------------
# Serializable task config
# ---------------------------------------------------------------------------


class AgentTaskConfig(TaskConfigBase):
    """Config for reconstructing an AgentTask."""

    type: Literal["agent"] = "agent"
    model: str
    name: str = ""
    description: str = ""
    input_schema: dict[str, Any] | None = None
    system_prompt: str | None = None
    max_iterations: int | None = None
    tasks: dict[str, SerializeAsAny["TaskConfigBase"]] = {}
    callback_implems: dict[str, SerializeAsAny["TaskConfigBase"]] = {}
    direct_callbacks: list[TaskCallback] = []


# ---------------------------------------------------------------------------
# AgentTask internal actions (reducer inputs) — Pydantic for activity return boundary
# ---------------------------------------------------------------------------


class Initialize(BaseModel):
    """Dispatched once at startup to kick off the first LLM call."""


class LLMTurnComplete(BaseModel):
    """Dispatched when the LLM finishes a turn.

    `response` carries the complete assistant MessageEntry (with
    generation_status="complete"). The reducer appends it to history
    authoritatively, since streaming goes through the sink and never
    touches the reducer's state.
    """

    response: MessageEntry | None = None
    tool_calls: list[TaskCallEntry] = []


# Full action union for the agent's StateModule
AgentAction = (
    Initialize | LLMTurnComplete | SubTaskCallRequest | SubTaskCompleted | CallbackResultReceived
)


# ---------------------------------------------------------------------------
# AgentTask internal effects — Pydantic for Temporal serialization
# ---------------------------------------------------------------------------


class CallLLM(BaseModel):
    """Effect: call the LLM with current state.

    Self-contained — carries all state needed for execution so the handler
    does not need to read from the execution loop.
    """

    state: TaskState  # parent state — handler builds completion request from this
    model: str  # e.g. "mistral-large-latest"
    tools: dict[str, Any]  # llm-visible tool schemas (serializable)
    task_id: str  # for sink construction (workflow path)


AgentEffect = CallLLM | SpawnSubTask | CallCallback


# ---------------------------------------------------------------------------
# Effect handler registry
# ---------------------------------------------------------------------------

_registry = EffectRegistry()


# ---------------------------------------------------------------------------
# AgentModule — StateModule subclass for agent lifecycle
# ---------------------------------------------------------------------------

# :TODO:agent [A3] Extract llm_turn_reducer as composable building blocks
# (like sub_task_reducer). Deferred — wait for second LLM-driving StateModule.


class AgentModule(StateModule):
    """StateModule for an LLM-driven agent.

    Combines the master reducer (routing to sub-reducers by action type)
    and effect handlers (LLM calls, subtask spawning, callbacks).
    """

    effect_handlers = _registry
    initial_action_type = Initialize

    def __init__(
        self,
        completion: CompletionModel | None,
        model_name: str,
        tasks: dict[str, Any],
        max_iterations: int | None,
        system_prompt: str | None = None,
        callback_implems: dict[str, Any] | None = None,
        callback_schemas: dict[str, TaskCallback] | None = None,
        task_configs: dict[str, Any] | None = None,
    ) -> None:
        """Initialize the agent module.

        Args:
            completion: LLM backend implementing the CompletionModel protocol.
            model_name: Model identifier string (e.g. "mistral-large-latest").
                Stored on CallLLM effects for serialization across the activity
                boundary. On the workflow path, the activity handler constructs
                a new CompletionModel from this string.
            tasks: Subtask implementations visible to the LLM. Used for
                spawning subtasks and presented as tool definitions.
            max_iterations: Maximum number of LLM calls before the loop is
                forcibly completed. None means unlimited.
            system_prompt: Optional system message. When provided and history
                is empty, the Initialize reducer injects it as the first
                history entry (along with the user input).
            callback_implems: Callback implementations NOT visible to the LLM.
                Resolve children's callback requests locally. Merged with
                tasks into the internal resolution table.
            callback_schemas: Callback schemas keyed by name. When a call
                targets a callback name (not in the resolution table), the
                request is emitted downstream for the parent to resolve.
                Also presented to the LLM as callable tools.
            task_configs: Serializable task configs keyed by name. Stored on
                SpawnSubTask effects so the activity handler can reconstruct
                tasks without a global registry. None on the local path
                (handler uses resolvable_tasks directly).
        """
        self._completion = completion
        self._model_name = model_name
        self._system_prompt = system_prompt
        self._tasks = tasks
        self._callback_implems = callback_implems or {}
        self._max_iterations = max_iterations
        self._callback_schemas = callback_schemas or {}
        self._task_configs = task_configs or {}
        self._all_resolvable: dict[str, Any] = {**self._tasks, **self._callback_implems}
        self._exec_loop: ExecutionLoop | None = None  # set via bind_exec_loop()
        self._downstream: DownstreamWriter | None = None

        # Pre-compute serializable tool definitions for CallLLM effects.
        # Merges tasks + callback_schemas into a dict of {name: {description, input_schema}}.
        tools_serialized: dict[str, Any] = {}
        for name, task in self._tasks.items():
            tools_serialized[name] = {
                "description": getattr(task, "description", "") or "",
                "input_schema": getattr(task, "input_schema", None) or {},
            }
        for name, cb in self._callback_schemas.items():
            tools_serialized[name] = {
                "description": cb.card.description or "",
                "input_schema": cb.card.input_schema or {},
            }
        self._tools_serialized = tools_serialized

    def bind_exec_loop(
        self,
        loop: ExecutionLoop,
        downstream: "DownstreamWriter | None" = None,
    ) -> None:
        self._exec_loop = loop
        self._downstream = downstream

    def _inject_initial_messages(self, state: TaskState) -> tuple[TaskState, list[Any]]:
        """Inject system prompt and input-as-user-message into empty history.

        Returns (new_state, patches). No-op if history is non-empty.
        """
        initial_entries: list[MessageEntry] = []
        if self._system_prompt:
            initial_entries.append(
                MessageEntry(
                    payload=MessageEntryPayload(
                        role="system", content=content_blocks(self._system_prompt)
                    ),
                )
            )
        if state.input is not None:
            content = json.dumps(state.input) if not isinstance(state.input, str) else state.input
            initial_entries.append(
                MessageEntry(
                    payload=MessageEntryPayload(role="user", content=content_blocks(content)),
                )
            )
        if not initial_entries:
            return (state, [])
        new_state = state.model_copy(update={"history": initial_entries})
        return (new_state, list(diff(state, new_state)))

    def _make_call_llm(self, state: TaskState) -> CallLLM:
        """Create a fully-populated CallLLM effect."""
        return CallLLM(
            state=state,
            model=self._model_name,
            tools=self._tools_serialized,
            task_id=state.id,
        )

    def _count_assistant_messages(self, state: TaskState) -> int:
        """Count assistant messages in history (for max_iterations check)."""
        return sum(
            1
            for e in state.history
            if isinstance(e, MessageEntry) and e.payload.role == "assistant"
        )

    def _max_iterations_reached(self, state: TaskState) -> bool:
        """Check if max iterations limit has been reached."""
        return (
            self._max_iterations is not None
            and self._count_assistant_messages(state) >= self._max_iterations
        )

    def reduce(self, state: TaskState, action: Any) -> tuple[TaskState, list[Any]]:
        """Master reducer. Routes to sub-reducers by action type.

        Max iterations check lives here (not in handle_effect) so it works
        identically on both local and workflow paths.

        Returns:
            ``(new_state, effects)``. Transport patches are computed by the
            execution loop, not by reducers.
        """
        match action:
            case Initialize():
                # Inject system prompt + user input if history is empty.
                if not state.history:
                    state, _ = self._inject_initial_messages(state)
                if self._max_iterations_reached(state):
                    final = state.model_copy(
                        update={"output": CompletedOutput(value={"response": ""})}
                    )
                    return (final, [])
                return (state, [self._make_call_llm(state)])

            case LLMTurnComplete(response=response, tool_calls=tool_calls):
                all_effects: list[Any] = []

                if response is not None:
                    current_state = state.model_copy(update={"history": [*state.history, response]})

                    if not tool_calls:
                        content = content_text(response.payload.content)
                        final = current_state.model_copy(
                            update={"output": CompletedOutput(value={"response": content})}
                        )
                        return (final, all_effects)
                else:
                    current_state = state
                    if not tool_calls:
                        return (current_state, all_effects)

                for tc in tool_calls:
                    current_state, effects = sub_task_reducer(
                        current_state,
                        SubTaskCallRequest(call=tc),
                        self._all_resolvable,
                        callback_schemas=self._callback_schemas,
                    )
                    all_effects.extend(effects)

                # Set parent state and task_config on all SpawnSubTask effects.
                # Parent state is the final state (after all call/result entries
                # are appended) to ensure concurrent handlers reroute to
                # non-overlapping paths. task_config enables reconstruction on
                # the activity path.
                for i, effect in enumerate(all_effects):
                    if isinstance(effect, SpawnSubTask):
                        updates: dict[str, Any] = {"state": current_state}
                        task_name = effect.call.payload.name
                        if task_name in self._task_configs:
                            updates["task_config"] = self._task_configs[task_name]
                        all_effects[i] = effect.model_copy(update=updates)

                return (current_state, all_effects)

            case SubTaskCompleted(call_id=call_id, final_state=final_state):
                new_state = _update_result_entry(state, call_id, final_state) or state

                # Check if all pending tool calls are resolved
                all_resolved = not any(
                    isinstance(e, TaskResultEntry) and e.generation_status == "generating"
                    for e in new_state.history
                )
                continuation_effects: list[Any] = []
                if all_resolved:
                    if self._max_iterations_reached(new_state):
                        final = new_state.model_copy(
                            update={"output": CompletedOutput(value={"response": ""})}
                        )
                        return (final, [])
                    continuation_effects.append(self._make_call_llm(new_state))
                return (new_state, continuation_effects)

            case CallbackResultReceived():
                new_state, sub_effects = sub_task_reducer(
                    state, action, self._all_resolvable, callback_schemas=self._callback_schemas
                )
                # Check if all pending tool calls are resolved
                all_resolved = not any(
                    isinstance(e, TaskResultEntry) and e.generation_status == "generating"
                    for e in new_state.history
                )
                cb_effects: list[Any] = list(sub_effects)
                if all_resolved:
                    if self._max_iterations_reached(new_state):
                        final = new_state.model_copy(
                            update={"output": CompletedOutput(value={"response": ""})}
                        )
                        return (final, [])
                    cb_effects.append(self._make_call_llm(new_state))
                return (new_state, cb_effects)

            case SubTaskCallRequest():
                return sub_task_reducer(
                    state, action, self._all_resolvable, callback_schemas=self._callback_schemas
                )

            case _:
                return (state, [])

    def _get_callback_bridge(self) -> CallbackBridge | None:
        """Build a LocalCallbackBridge if downstream and loop are available."""
        if self._downstream is not None and self._exec_loop is not None:
            return LocalCallbackBridge(self._downstream, self._exec_loop)
        return None

    async def handle_effect(self, effect: Any, sink: StateSink) -> list[Any]:
        """Effect handler for ExecutionLoop path.

        Dispatches to standalone handler functions via the effect_handlers
        registry. Injects module-level context (completion, resolvable_tasks,
        callback_bridge) as additional kwargs where needed.

        CallCallback is a signal effect (DL-50) and is NOT in the registry.
        It is handled as an explicit fallback using the CallbackBridge.
        """
        handler = self.effect_handlers.get(type(effect))
        if handler is None:
            # Fallback for effects not in the registry (e.g. CallCallback)
            if isinstance(effect, CallCallback):
                return await _handle_call_callback(
                    effect=effect,
                    callback_bridge=self._get_callback_bridge(),
                )
            return []

        if isinstance(effect, CallLLM):
            result: list[Any] = await handler(effect, sink, completion=self._completion)
            return result

        if isinstance(effect, SpawnSubTask):
            result = await handler(
                effect,
                sink,
                resolvable_tasks=self._all_resolvable,
                callback_schemas=self._callback_schemas,
                callback_bridge=self._get_callback_bridge(),
            )
            return result

        result = await handler(effect, sink)
        return result


# ---------------------------------------------------------------------------
# AgentTask — the LLM-driven task (inherits from ModuleTask)
# ---------------------------------------------------------------------------


class AgentTask(ModuleTask[AgentTaskConfig]):
    """LLM-driven task backed by AgentModule.

    The most common task pattern. Given a CompletionModel (LLM) and a set
    of task implementations (subtasks the agent can call), it drives a
    conversation loop:

        call LLM -> execute tool calls -> call LLM again -> ...

    until the task completes (LLM returns without tool calls and output is
    set to CompletedOutput) or max_iterations is reached.

    Inherits execute(), run(), and card metadata from ModuleTask.
    Implements create_module() and from_config().
    """

    def __init__(
        self,
        completion: CompletionModel | None,
        tasks: dict[str, Any] | None = None,
        direct_callbacks: list[TaskCallback] | None = None,
        callback_implems: dict[str, Any] | None = None,
        system_prompt: str | None = None,
        max_iterations: int | None = None,
        model_name: str = "",
        name: str = "",
        description: str = "",
        input_schema: dict[str, Any] | None = None,
        output_schema: dict[str, Any] | None = None,
        task_configs: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            input_schema=input_schema,
            output_schema=output_schema,
        )

        self.completion = completion
        self.tasks = tasks or {}
        self._direct_callbacks = direct_callbacks or []
        self._callback_implems = callback_implems or {}
        self._task_configs = task_configs or {}
        self.system_prompt = system_prompt
        self.max_iterations = max_iterations
        self.model_name = model_name or getattr(completion, "model", "")

        # Fail fast: callback_implems must not themselves require callbacks.
        # Nested callbacks are not supported — the resolver only consumes
        # TaskStateUpdateEvent, so any CallbackCallEvent from an impl would hang.
        for impl_name, impl_task in self._callback_implems.items():
            impl_cbs: list[Any] = getattr(impl_task, "callbacks", [])
            if impl_cbs:
                cb_names = [cb.card.name for cb in impl_cbs]
                msg = (
                    f"Callback implementation '{impl_name}' declares unresolved "
                    f"callbacks {cb_names}. Nested callbacks are not supported — "
                    f"the implementation would hang waiting for a resolver."
                )
                raise ValueError(msg)

        # Auto-compute self.callbacks:
        # (children's unresolved callbacks) + (direct_callbacks) - (callback_implems keys)
        children_unresolved: dict[str, TaskCallback] = {}
        for task in self.tasks.values():
            for cb in getattr(task, "callbacks", []):
                if cb.card.name not in self._callback_implems:
                    children_unresolved[cb.card.name] = cb
        all_cbs = {**children_unresolved}
        for cb in self._direct_callbacks:
            all_cbs[cb.card.name] = cb  # direct wins on name collision
        self.callbacks: list[TaskCallback] = list(all_cbs.values())

        # Callback resolution: names this task can resolve locally
        self._resolvable_names = frozenset(self.tasks.keys()) | frozenset(
            self._callback_implems.keys()
        )

    @classmethod
    def from_config(cls, config: Any, **kwargs: Any) -> "AgentTask":
        """Construct from serializable config (workflow/activity path).

        Accepts an AgentTaskConfig (or dict). Reconstructs live task objects
        from TaskConfig and creates a MistralCompletion from the model name.

        Nested children are reconstructed via ``default_registry`` — the
        worker process must install matching extensions globally.
        """
        from mistralai.vibe.protocol.modules.task import task_from_config
        from mistralai.vibe.protocol.patterns.completion.adapters.mistral import MistralCompletion

        if not isinstance(config, AgentTaskConfig):
            config = AgentTaskConfig.model_validate(config)

        tasks = kwargs.get("tasks") or {
            name: task_from_config(cfg) for name, cfg in config.tasks.items()
        }
        cb_implems = {name: task_from_config(cfg) for name, cfg in config.callback_implems.items()}
        completion = MistralCompletion.from_env(model=config.model)
        task_configs_dict = {name: cfg.model_dump() for name, cfg in config.tasks.items()}
        return cls(
            completion=completion,
            model_name=config.model,
            name=config.name,
            description=config.description,
            input_schema=config.input_schema,
            system_prompt=config.system_prompt,
            max_iterations=config.max_iterations,
            tasks=tasks,
            callback_implems=cb_implems,
            direct_callbacks=config.direct_callbacks,
            task_configs=task_configs_dict,
        )

    @classmethod
    def from_config_for_workflow(cls, config: Any, **kwargs: Any) -> "AgentTask":
        """Construct a workflow-safe AgentTask without live client creation."""
        from mistralai.vibe.protocol.modules.task import task_from_config

        if not isinstance(config, AgentTaskConfig):
            config = AgentTaskConfig.model_validate(config)

        tasks = kwargs.get("tasks") or {
            name: task_from_config(cfg, for_workflow=True) for name, cfg in config.tasks.items()
        }
        cb_implems = {
            name: task_from_config(cfg, for_workflow=True)
            for name, cfg in config.callback_implems.items()
        }
        task_configs_dict = {name: cfg.model_dump() for name, cfg in config.tasks.items()}
        return cls(
            completion=None,
            model_name=config.model,
            name=config.name,
            description=config.description,
            input_schema=config.input_schema,
            system_prompt=config.system_prompt,
            max_iterations=config.max_iterations,
            tasks=tasks,
            callback_implems=cb_implems,
            direct_callbacks=config.direct_callbacks,
            task_configs=task_configs_dict,
        )

    def create_module(self) -> AgentModule:
        """Create a fully configured AgentModule."""
        callback_schemas = {cb.card.name: cb for cb in self.callbacks}
        return AgentModule(
            completion=self.completion,
            model_name=self.model_name,
            tasks=self.tasks,
            max_iterations=self.max_iterations,
            system_prompt=self.system_prompt,
            callback_implems=self._callback_implems,
            callback_schemas=callback_schemas,
            task_configs=self._task_configs,
        )


# ---------------------------------------------------------------------------
# Standalone effect handlers for ExecutionLoop
# ---------------------------------------------------------------------------


@_registry.handles(CallLLM)
async def _handle_call_llm(
    effect: CallLLM,
    sink: StateSink,
    completion: CompletionModel | None = None,
) -> list[LLMTurnComplete]:
    """Call the LLM, stream state updates via sink, return LLMTurnComplete.

    Streams intermediate state updates (text deltas, assistant entry creation)
    through the StateSink so the consumer sees tokens as they arrive.
    The reducer never sees these streaming events. At the end, returns
    a single LLMTurnComplete action containing the complete assistant
    MessageEntry and extracted tool calls.

    On the local path, the module injects the user-provided CompletionModel.
    On the workflow activity path, completion is None and MistralCompletion is
    constructed from effect.model.

    Args:
        effect: CallLLM effect carrying state, model, tools, task_id.
        sink: StateSink for streaming state updates downstream.
        completion: Optional CompletionModel. If None, constructs
            MistralCompletion from effect.model (workflow activity path).

    Returns:
        A list containing one LLMTurnComplete action.
    """
    if completion is None:
        import os

        from mistralai.vibe.protocol.patterns.completion.adapters.mistral import MistralCompletion

        api_key = os.environ.get("MISTRAL_CLIENT_API_KEY") or os.environ["MISTRAL_API_KEY"]
        completion = MistralCompletion(api_key=api_key, model=effect.model)

    request = build_completion_request_from_state(effect.state, effect.tools)
    stream = completion.complete(request)

    current_state = effect.state
    tool_calls: list[TaskCallEntry] = []
    async with sink:
        async for new_state, streamed_tool_calls in stream_states(current_state, stream):
            await sink.update(new_state)
            current_state = new_state
            if streamed_tool_calls is not None:
                tool_calls = streamed_tool_calls

    # Extract the final assistant message and tool calls
    response: MessageEntry | None = None

    for entry in reversed(current_state.history):
        if isinstance(entry, MessageEntry) and entry.payload.role == "assistant":
            response = entry
            break

    return [LLMTurnComplete(response=response, tool_calls=tool_calls)]


@_registry.handles(SpawnSubTask)
async def _handle_spawn_subtask(
    effect: SpawnSubTask,
    sink: StateSink,
    resolvable_tasks: dict[str, Any] | None = None,
    callback_schemas: dict[str, TaskCallback] | None = None,
    callback_bridge: CallbackBridge | None = None,
) -> list[SubTaskCompleted]:
    """Run a child task, relay patches via sink, return SubTaskCompleted.

    Iterates the child channel, rerouting child patches into the parent scope
    and calling sink.update(parent_state) so the consumer sees child progress
    as part of the parent's state evolution.

    Also handles child callback requests (CallbackCallEvent) via the shared
    resolve_callback_request function. The callback_bridge is used for
    bubbling unresolved callbacks upstream.

    On the local path, the module injects resolvable_tasks, callback_schemas,
    and callback_bridge. On the workflow activity path, resolvable_tasks is
    None and the task is reconstructed from task_config.

    Args:
        effect: SpawnSubTask effect with parent state, call info, and child state.
        sink: StateSink for streaming rerouted parent state updates.
        resolvable_tasks: Tasks that can resolve child callbacks locally.
        callback_schemas: Callback schemas for bubbling upstream.
        callback_bridge: CallbackBridge for bubbling unresolved callbacks.

    Returns:
        A list containing one SubTaskCompleted action with the final child state.
    """
    if resolvable_tasks is None:
        if effect.task_config is None:
            msg = f"No resolvable_tasks and no task_config for {effect.call.payload.name}"
            raise ValueError(msg)
        from mistralai.vibe.protocol.modules.task import task_from_config

        task = task_from_config(effect.task_config)
    else:
        task = resolvable_tasks[effect.call.payload.name]
    channel = await task.run(effect.child_state)
    prefix = f"/history/{effect.result_index}/payload/state"

    local_tasks = resolvable_tasks or {}
    local_schemas = callback_schemas or {}

    parent_state = effect.state
    child_state = effect.child_state
    async for message in channel:
        if isinstance(message, TaskStateUpdateEvent):
            child_state = apply_patches(child_state, message.payload.patches)
            rerouted = reroute_patches(message.payload.patches, prefix)
            parent_state = apply_patches(parent_state, rerouted)
            await sink.update(parent_state)

        elif isinstance(message, TaskResultEvent):
            child_state = message.payload.result
        elif isinstance(message, CallbackCallEvent):
            await resolve_callback_request(
                request=message,
                child_path_segment=effect.call.payload.id,
                send_result_to_child=channel.send,
                task_implementations=local_tasks,
                callback_schemas=local_schemas,
                bubble_upstream=callback_bridge,
            )

    return [SubTaskCompleted(call_id=effect.call.payload.id, final_state=child_state)]


async def _handle_call_callback(
    effect: CallCallback,
    callback_bridge: CallbackBridge | None = None,
) -> list[Any]:
    """Emit CallbackCallEvent via CallbackBridge, await result, return action.

    Sends a CallbackCallEvent through the CallbackBridge so the parent can
    resolve the callback. Then waits for a CallbackResultEvent via
    bridge.receive_result(). Returns a CallbackResultReceived action.

    On the local path, callback_bridge is a LocalCallbackBridge.
    On the workflow path, it is a WorkflowCallbackBridge (signal-based).

    Args:
        effect: CallCallback effect with call info.
        callback_bridge: Transport-abstracted bridge for callback exchange.

    Returns:
        A list containing one CallbackResultReceived action.
    """
    if callback_bridge is None:
        msg = "callback_bridge required for callback handling"
        raise RuntimeError(msg)

    call_event = CallbackCallEvent(
        payload=CallbackCallPayload(
            id=effect.call.payload.id,
            name=effect.call.payload.name,
            input=effect.call.payload.input,
            path=[],
        )
    )
    await callback_bridge.send_request(call_event)
    result = await callback_bridge.receive_result(effect.call.payload.id)

    return [
        CallbackResultReceived(
            call_id=effect.call.payload.id,
            result_state=result.payload.state,
        )
    ]
