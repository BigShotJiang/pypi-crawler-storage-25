"""Bridge between protocol types and completion types.

Converts TaskState history into CompletionRequest messages (for the LLM),
and converts streaming CompletionChunk responses back into TaskState mutations
(for the reducer/dispatch loop).

The flow:
  reducer → completion effect → build_completion_request_from_state()
  → CompletionModel.complete() → stream_to_mutations() → patches → reducer
"""

import json
import uuid
from collections.abc import AsyncIterator
from typing import Any

from mistralai.vibe.protocol.modules.produce import produce
from mistralai.vibe.protocol.patterns.completion.messages import FunctionCall, Message, ToolCall
from mistralai.vibe.protocol.patterns.completion.types import (
    CompletionChunk,
    CompletionRequest,
    FunctionSpec,
    ToolDefinition,
)
from mistralai.vibe.protocol.types.state import (
    CompletedOutput,
    FailedOutput,
    MessageEntry,
    MessageEntryPayload,
    TaskCallEntry,
    TaskCallEntryPayload,
    TaskResultEntry,
    TaskState,
    TextContentBlock,
    content_text,
)

# Type alias for produce() output
_MutationResult = tuple[TaskState, list[Any], list[TaskCallEntry] | None]
_PROVIDER_ID_PREFIX = "llm:"


def encode_tool_call_id(provider_id: str | None) -> str:
    """Encode a provider-local tool-call id into the protocol id field."""
    sdk_id = uuid.uuid4().hex
    if not provider_id:
        return sdk_id
    provider_blob = json.dumps(provider_id)
    return f"{_PROVIDER_ID_PREFIX}{provider_blob}:{sdk_id}"


def tool_call_provider_id(call_id: str) -> str:
    """Extract the provider-local id embedded by encode_tool_call_id()."""
    if not call_id.startswith(_PROVIDER_ID_PREFIX):
        return call_id

    remainder = call_id.removeprefix(_PROVIDER_ID_PREFIX)
    decoder = json.JSONDecoder()
    try:
        provider_id, _end = decoder.raw_decode(remainder)
    except json.JSONDecodeError:
        return call_id
    return provider_id if isinstance(provider_id, str) else call_id


# ---------------------------------------------------------------------------
# stream_to_mutations — streaming LLM bridge
# ---------------------------------------------------------------------------


async def stream_to_mutations(
    state: TaskState,
    chunks: AsyncIterator[CompletionChunk],
) -> AsyncIterator[_MutationResult]:
    """Yields ``(new_state, patches, tool_calls)`` for each meaningful chunk.

    Uses produce() for recording — AppendOp emitted for content growth.

    Manages the lifecycle of a single LLM turn:
    1. First text chunk: append MessageEntry(role="assistant", ...)
       with generation_status="generating" to history
    2. Subsequent text deltas: append to the assistant entry's content
       (draft detects string growth -> AppendOp)
    3. Tool call deltas: accumulate id/name/arguments across chunks
    4. Finalization (finish_reason received):
       a. Set generation_status="complete" on the assistant entry
       b. Preserve accumulated tool calls out-of-band for the reducer
       c. If no tool calls: set output to CompletedOutput with response text

    Args:
        state: Current TaskState before this LLM turn.
        chunks: Async iterator of CompletionChunk from the LLM backend.

    Yields:
        ``(new_state, patches, tool_calls)`` tuples — one per meaningful
        chunk (text delta, finalization). Tool call deltas are accumulated
        silently and surfaced only on the finalization yield.
    """
    current_state = state
    tool_call_accumulators: dict[int, dict[str, str]] = {}
    has_assistant_entry = False

    async for chunk in chunks:
        # Handle text content deltas
        if chunk.content_delta:
            delta = chunk.content_delta

            if not has_assistant_entry:
                # First text chunk: create the assistant entry
                def create_recipe(draft: Any, *, _delta: str = delta) -> None:
                    draft.history.append(
                        MessageEntry(
                            payload=MessageEntryPayload(
                                role="assistant",
                                content=[TextContentBlock(text=_delta)],
                            ),
                            generation_status="generating",
                        )
                    )

                new_state, patches = produce(current_state, create_recipe)
                has_assistant_entry = True
            else:
                # Subsequent chunks: append to existing content
                def append_recipe(draft: Any, *, _delta: str = delta) -> None:
                    idx = len(draft.history) - 1
                    content = draft.history[idx].payload.content
                    if content and content[-1].type == "text":
                        content[-1].text += _delta
                        return
                    content.append(TextContentBlock(text=_delta))

                new_state, patches = produce(current_state, append_recipe)

            current_state = new_state
            yield (new_state, patches, None)

        # Handle tool call deltas (accumulate, no yield)
        if chunk.tool_call_deltas:
            for tc_delta in chunk.tool_call_deltas:
                acc = tool_call_accumulators.setdefault(
                    tc_delta.index, {"id": "", "name": "", "arguments": ""}
                )
                if tc_delta.id:
                    acc["id"] = tc_delta.id
                if tc_delta.function_name:
                    acc["name"] = tc_delta.function_name
                if tc_delta.arguments_delta:
                    acc["arguments"] += tc_delta.arguments_delta

        # Handle finalization
        if chunk.finish_reason:
            # Build tool calls list
            tool_calls_list: list[TaskCallEntry] = []
            if tool_call_accumulators:
                for _idx, acc in sorted(tool_call_accumulators.items()):
                    try:
                        parsed_args = json.loads(acc["arguments"]) if acc["arguments"] else {}
                    except json.JSONDecodeError:
                        parsed_args = {"raw_arguments": acc["arguments"]}
                    tc = TaskCallEntry(
                        payload=TaskCallEntryPayload(
                            id=encode_tool_call_id(acc["id"]),
                            name=acc["name"],
                            input=parsed_args,
                        ),
                    )
                    tool_calls_list.append(tc)

            tcs = tool_calls_list

            def finalize_recipe(
                draft: Any,
                *,
                _tcs: list[TaskCallEntry] = tcs,
                _has_entry: bool = has_assistant_entry,
            ) -> None:
                if not _has_entry:
                    # No content was streamed — create empty assistant entry
                    draft.history.append(
                        MessageEntry(
                            payload=MessageEntryPayload(
                                role="assistant",
                                content=[],
                            ),
                            generation_status="complete",
                        )
                    )
                else:
                    idx = len(draft.history) - 1
                    draft.history[idx].generation_status = "complete"

                if not _tcs:
                    # No tool calls: task completes with the response text
                    content = ""
                    for entry in draft.history:
                        if isinstance(entry, MessageEntry) and entry.payload.role == "assistant":
                            content = content_text(entry.payload.content)
                    draft.output = CompletedOutput(value={"response": content})

            new_state, patches = produce(current_state, finalize_recipe)
            current_state = new_state
            yield (new_state, patches, tcs)


# ---------------------------------------------------------------------------
# stream_states — state-only iterator (no patch computation)
# ---------------------------------------------------------------------------


async def stream_states(
    state: TaskState,
    chunks: AsyncIterator[CompletionChunk],
) -> AsyncIterator[tuple[TaskState, list[TaskCallEntry] | None]]:
    """Yield ``(TaskState, tool_calls)`` while discarding low-level patches.

    Wraps stream_to_mutations but discards the patch output, avoiding
    redundant diff computation when the caller only needs the state (e.g.,
    the workflow execution path where patches are handled by the Workflows
    API task() CM instead of the local in-process queue).

    Args:
        state: Current TaskState before this LLM turn.
        chunks: Async iterator of CompletionChunk from the LLM backend.

    Yields:
        ``(TaskState, tool_calls)`` after each meaningful chunk is applied.
    """
    async for new_state, _, tool_calls in stream_to_mutations(state, chunks):
        yield (new_state, tool_calls)


# ---------------------------------------------------------------------------
# build_completion_request_from_state — request builder
# ---------------------------------------------------------------------------


def build_completion_request_from_state(
    state: TaskState,
    task_implementations: dict[str, Any],
) -> CompletionRequest:
    """Build a CompletionRequest from TaskState history.

    Converts history entries to Message objects:
    - MessageEntry(role="system") -> Message(role="system", content=...)
    - MessageEntry(role="user") -> Message(role="user", content=...)
    - MessageEntry(role="assistant") -> Message(role="assistant", content=..., tool_calls=...)
    - TaskResultEntry -> Message(role="tool", content=result, tool_call_id=...)
    - TaskCallEntry -> skipped (handled via MessageEntry.payload.tool_calls)

    Converts task_implementations to ToolDefinition objects for the LLM.

    Args:
        state: TaskState whose history is converted to messages.
        task_implementations: Available subtasks, converted to tool
            definitions so the LLM knows what it can call.

    Returns:
        A CompletionRequest ready to pass to CompletionModel.complete().
    """
    messages: list[Message] = []

    history = state.history
    for index, entry in enumerate(history):
        if isinstance(entry, MessageEntry):
            role = entry.payload.role
            content = content_text(entry.payload.content)

            if role == "system":
                messages.append(Message(role="system", content=content))
            elif role == "user":
                messages.append(Message(role="user", content=content))
            elif role == "assistant":
                msg = Message(role="assistant", content=content or None)
                tool_calls = _collect_assistant_tool_calls(history, index)
                if tool_calls:
                    msg.tool_calls = [
                        ToolCall(
                            id=tool_call_provider_id(tc.payload.id),
                            function=FunctionCall(
                                name=tc.payload.name,
                                arguments=json.dumps(tc.payload.input),
                            ),
                        )
                        for tc in tool_calls
                    ]
                messages.append(msg)

        elif isinstance(entry, TaskResultEntry):
            call_id = tool_call_provider_id(entry.payload.id)
            child_state = entry.payload.state
            if child_state and isinstance(child_state.output, CompletedOutput):
                result_content = json.dumps(child_state.output.value)
            elif child_state and isinstance(child_state.output, FailedOutput):
                result_content = f"Error: {child_state.output.error}"
            else:
                result_content = "Pending..."
            messages.append(
                Message(
                    role="tool",
                    content=result_content,
                    tool_call_id=call_id,
                )
            )

        elif isinstance(entry, TaskCallEntry):
            # Skipped: reconstructed onto the preceding assistant message.
            pass

    # Convert task implementations to tool definitions
    tools = _implementations_to_tools(task_implementations)

    return CompletionRequest(messages=messages, tools=tools or None)


def _collect_assistant_tool_calls(
    history: list[Any],
    assistant_index: int,
) -> list[TaskCallEntry]:
    """Collect tool calls associated with one assistant turn.

    The current reducer records tool calls and tool results as siblings
    following the assistant message. We therefore scan forward until the
    next message entry and gather every TaskCallEntry in that span.
    """
    tool_calls: list[TaskCallEntry] = []
    for entry in history[assistant_index + 1 :]:
        if isinstance(entry, MessageEntry):
            break
        if isinstance(entry, TaskCallEntry):
            tool_calls.append(entry)
    return tool_calls


def _implementations_to_tools(
    impls: dict[str, Any],
) -> list[ToolDefinition]:
    """Convert task implementations to ToolDefinition for the LLM.

    Accepts both task-like objects (with .description, .input_schema attrs)
    and plain dicts (with "description", "input_schema" keys) for the
    serialized tool format used by self-contained effects.
    """
    tools = []
    for name, task in impls.items():
        if isinstance(task, dict):
            desc = task.get("description", "") or name
            params = task.get("input_schema", {}) or {}
        else:
            desc = getattr(task, "description", "") or name
            params = getattr(task, "input_schema", {}) or {}
        spec = FunctionSpec(
            name=name,
            description=desc,
            parameters=params,
        )
        tools.append(ToolDefinition(function=spec))
    return tools
