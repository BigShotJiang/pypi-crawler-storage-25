"""Completion domain — LLM completion port, adapters, bridge, and types.

This package contains everything related to communicating with LLM providers:
- types: Standardized request/response types (CompletionRequest, CompletionChunk)
- messages: LLM API message format (Message, ToolCall, FunctionCall)
- port: CompletionModel protocol that adapters implement
- bridge: Functions bridging protocol types and completion types
- adapters/: Concrete adapter implementations (Mistral, etc.)
"""

from mistralai.vibe.protocol.patterns.completion.adapters.mistral import MistralCompletion
from mistralai.vibe.protocol.patterns.completion.messages import FunctionCall, Message, ToolCall
from mistralai.vibe.protocol.patterns.completion.port import CompletionModel
from mistralai.vibe.protocol.patterns.completion.types import (
    CompletionChunk,
    CompletionRequest,
    FunctionSpec,
    ToolCallDelta,
    ToolDefinition,
)

__all__ = [
    # Types
    "CompletionRequest",
    "CompletionChunk",
    "ToolCallDelta",
    "FunctionSpec",
    "ToolDefinition",
    # Messages
    "Message",
    "ToolCall",
    "FunctionCall",
    # Port
    "CompletionModel",
    # Adapters
    "MistralCompletion",
]
