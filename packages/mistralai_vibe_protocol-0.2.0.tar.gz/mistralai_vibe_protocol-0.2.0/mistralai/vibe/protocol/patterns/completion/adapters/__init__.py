"""Completion adapters — concrete implementations of CompletionModel."""

from mistralai.vibe.protocol.patterns.completion.adapters.mistral import MistralCompletion

__all__ = [
    "MistralCompletion",
]
