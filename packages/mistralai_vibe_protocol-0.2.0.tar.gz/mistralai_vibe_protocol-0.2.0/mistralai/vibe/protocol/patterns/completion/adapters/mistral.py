"""Mistral completion adapter — CompletionModel implementation.

Thin wrapper that maps CompletionRequest to Mistral SDK types,
calls the streaming API, and maps chunks to CompletionChunk.
"""

import os
from collections.abc import AsyncIterator
from typing import Any

import httpx
import structlog
from tenacity import (
    AsyncRetrying,
    RetryCallState,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential,
)

from mistralai.vibe.protocol.patterns.completion.port import CompletionModel
from mistralai.vibe.protocol.patterns.completion.types import (
    CompletionChunk,
    CompletionRequest,
    ToolCallDelta,
)

logger = structlog.get_logger()
_RETRYABLE_STATUS_CODES = frozenset({408, 429, 502, 503, 504})


def _get_mistral_status_code(exc: BaseException) -> int | None:
    """Return the HTTP status code for a Mistral SDK error, if present."""
    try:
        from mistralai.client.errors.sdkerror import SDKError
    except Exception:
        return None

    if not isinstance(exc, SDKError):
        return None

    return exc.raw_response.status_code


def _is_retryable_mistral_exception(exc: BaseException) -> bool:
    """Return whether an LLM call failure looks transient and safe to retry."""
    if isinstance(
        exc,
        (
            httpx.ConnectError,
            httpx.ConnectTimeout,
            httpx.ReadTimeout,
            httpx.RemoteProtocolError,
        ),
    ):
        return True

    if (status_code := _get_mistral_status_code(exc)) is None:
        return False

    return status_code in _RETRYABLE_STATUS_CODES


def _log_stream_retry(retry_state: RetryCallState) -> None:
    """Emit a structured log before retrying stream acquisition."""
    if retry_state.outcome is None:
        return

    exc = retry_state.outcome.exception()
    if exc is None:
        return

    logger.warning(
        "mistral_stream_retry",
        attempt=retry_state.attempt_number,
        sleep_seconds=retry_state.next_action.sleep if retry_state.next_action else None,
        exception_type=type(exc).__name__,
        status_code=_get_mistral_status_code(exc),
        retryable=_is_retryable_mistral_exception(exc),
    )


def _build_stream_open_retrying() -> AsyncRetrying:
    """Build the retry policy for initial stream acquisition.

    This only wraps the initial request that opens the streaming response.
    Once bytes have started flowing, retrying would risk duplicating already
    emitted downstream chunks.
    """
    return AsyncRetrying(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=0.5, max=4),
        retry=retry_if_exception(_is_retryable_mistral_exception),
        before_sleep=_log_stream_retry,
        reraise=True,
    )


def _extract_content_delta(content: object) -> str | None:
    """Extract text from a Mistral delta content field.

    The Mistral SDK's DeltaMessage.content can be:
    - str: plain text delta (common in streaming)
    - list[ContentChunk]: list of typed chunks (TextChunk, ThinkChunk, etc.)

    We extract text from both formats.
    """
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for chunk in content:
            # ContentChunk is a union; TextChunk has a .text attribute
            if hasattr(chunk, "text") and isinstance(chunk.text, str):
                parts.append(chunk.text)
        return "".join(parts) if parts else None
    return None


class MistralCompletion(CompletionModel):
    """Mistral API adapter implementing CompletionModel.

    Thin wrapper that maps CompletionRequest to Mistral SDK types,
    calls the streaming API, and maps chunks to CompletionChunk.
    """

    def __init__(self, api_key: str, model: str = "mistral-small-latest") -> None:
        """Initialize the adapter.

        Client construction is deferred to first use to avoid blocking
        the Temporal workflow deterministic thread with SSL context loading
        during task reconstruction.

        Args:
            api_key: Mistral API key.
            model: Model name to use.
        """
        self._api_key = api_key
        self._client: Any = None
        self.model = model

    @property
    def client(self) -> Any:
        """Lazy-initialize the Mistral client on first access."""
        if self._client is None:
            from mistralai.client import Mistral

            self._client = Mistral(api_key=self._api_key)
        return self._client

    @classmethod
    def from_env(cls, model: str = "mistral-small-latest") -> "MistralCompletion":
        """Construct from environment variables.

        Uses MISTRAL_CLIENT_API_KEY if set (needed when MISTRAL_API_KEY is the
        Workflows API stack key), otherwise falls back to MISTRAL_API_KEY.
        """
        api_key = os.environ.get("MISTRAL_CLIENT_API_KEY") or os.environ["MISTRAL_API_KEY"]
        return cls(api_key=api_key, model=model)

    async def _open_stream(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
    ) -> Any:
        """Open the Mistral streaming response with bounded retry."""
        async for attempt in _build_stream_open_retrying():
            with attempt:
                return await self.client.chat.stream_async(
                    model=self.model,
                    messages=messages,  # type: ignore[arg-type]
                    tools=tools if tools else None,  # type: ignore[arg-type]
                    parallel_tool_calls=True if tools else None,
                )

        msg = "stream retry loop exited without returning or raising"
        raise RuntimeError(msg)

    async def complete(self, request: CompletionRequest) -> AsyncIterator[CompletionChunk]:
        """Stream the completion using Mistral API."""
        messages = [msg.model_dump(exclude_none=True) for msg in request.messages]
        tools = [tool.model_dump() for tool in request.tools] if request.tools else None

        logger.debug("mistral_stream_start", model=self.model, n_messages=len(messages))

        stream = await self._open_stream(messages=messages, tools=tools)

        chunk_count = 0
        content_chunk_count = 0
        tool_chunk_count = 0

        async for event in stream:
            chunk_data = event.data
            if not chunk_data.choices:
                continue
            choice = chunk_data.choices[0]
            delta = choice.delta
            chunk_count += 1

            content_delta = None
            tool_call_deltas = None

            if delta.content:
                content_delta = _extract_content_delta(delta.content)
                content_chunk_count += 1
                logger.debug(
                    "mistral_content_delta",
                    chunk_n=chunk_count,
                    content_type=type(delta.content).__name__,
                    delta_len=len(content_delta) if content_delta else 0,
                    delta_preview=content_delta[:40] if content_delta else None,
                )

            if delta.tool_calls:
                tool_chunk_count += 1
                tool_call_deltas = []
                for tc in delta.tool_calls:
                    tool_call_deltas.append(
                        ToolCallDelta(
                            index=tc.index or 0,
                            id=tc.id if tc.id and tc.id != "null" else None,
                            function_name=(
                                tc.function.name if tc.function and tc.function.name else None
                            ),
                            arguments_delta=(
                                tc.function.arguments
                                if tc.function
                                and tc.function.arguments
                                and isinstance(tc.function.arguments, str)
                                else None
                            ),
                        )
                    )

            yield CompletionChunk(
                content_delta=content_delta,
                tool_call_deltas=tool_call_deltas,
                finish_reason=choice.finish_reason,
            )

        logger.debug(
            "mistral_stream_end",
            total_chunks=chunk_count,
            content_chunks=content_chunk_count,
            tool_chunks=tool_chunk_count,
        )
