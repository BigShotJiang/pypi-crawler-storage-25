"""Completion domain: types and converters.

Handles the standardized interface for LLM completion calls.
Types only — no capability imports. Bridge functions live in patterns/completion/bridge.py.
"""

from typing import Any

from pydantic import BaseModel

from mistralai.vibe.protocol.patterns.completion.messages import Message

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


class FunctionSpec(BaseModel):
    """Function specification within a tool definition."""

    name: str
    description: str
    parameters: dict[str, Any]


class ToolDefinition(BaseModel):
    """A tool definition in OpenAI/Mistral standard format."""

    type: str = "function"
    function: FunctionSpec


class CompletionRequest(BaseModel):
    """Standardized completion request.

    Contains everything needed to call any LLM API.
    The adapter maps this to its specific SDK types.
    """

    messages: list[Message]
    tools: list[ToolDefinition] | None = None


# ---------------------------------------------------------------------------
# Streaming chunk types
# ---------------------------------------------------------------------------


class ToolCallDelta(BaseModel):
    """A delta for a single tool call within a streaming chunk.

    Tool calls arrive incrementally: the first delta for a given index
    carries id and function_name; subsequent deltas carry argument fragments.
    The consumer accumulates arguments_delta strings and JSON-parses at the end.
    """

    index: int
    id: str | None = None
    function_name: str | None = None
    arguments_delta: str | None = None


class CompletionChunk(BaseModel):
    """Standardized streaming chunk from an LLM completion.

    Provider-independent: adapters for Mistral, OpenAI, and Anthropic
    all convert their native streaming format into this type.
    See documentation/streaming_api_comparison.md for the mapping.
    """

    content_delta: str | None = None
    tool_call_deltas: list[ToolCallDelta] | None = None
    finish_reason: str | None = None
