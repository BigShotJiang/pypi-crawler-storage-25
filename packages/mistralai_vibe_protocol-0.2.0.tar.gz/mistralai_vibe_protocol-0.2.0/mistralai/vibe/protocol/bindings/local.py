"""In-process channel implementation.

LocalChannel is the concrete Channel adapter for same-process
communication, backed by asyncio queues.
"""

from __future__ import annotations

import asyncio
import contextlib
from collections.abc import AsyncIterator

from mistralai.vibe.protocol.types.channel import Channel
from mistralai.vibe.protocol.types.events import DownstreamMessage, UpstreamMessage


class LocalChannel(Channel):
    """In-process Channel backed by asyncio queues.

    The task's background coroutine puts DownstreamMessages onto
    the downstream queue. None signals completion. The parent reads
    via __aiter__ and sends via send().
    """

    def __init__(
        self,
        downstream: asyncio.Queue[DownstreamMessage | None],
        upstream: asyncio.Queue[UpstreamMessage],
        background_task: asyncio.Task[None],
    ) -> None:
        """Initialize a local channel.

        Args:
            downstream: Queue for task -> consumer messages. None signals
                stream end.
            upstream: Queue for consumer -> task messages.
            background_task: The asyncio task running the task's main loop.
                Checked for exceptions when the channel closes.
        """
        self._downstream = downstream
        self._upstream = upstream
        self._bg = background_task

    async def __aiter__(self) -> AsyncIterator[DownstreamMessage]:
        """Yield downstream messages until the None sentinel.

        Propagates any exception from the background task after the
        stream ends.
        """
        while True:
            msg = await self._downstream.get()
            if msg is None:
                break
            yield msg
        # Propagate any exception from the background task
        if self._bg.done():
            exc = self._bg.exception()
            if exc is not None:
                raise exc

    async def send(self, message: UpstreamMessage) -> None:
        """Send a message upstream to the running task.

        Puts the message on the upstream queue where the ExecutionLoop's
        receive_upstream() can read it.
        """
        await self._upstream.put(message)

    async def close(self) -> None:
        """Cancel the background task and wait for it to finish."""
        self._bg.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await self._bg
