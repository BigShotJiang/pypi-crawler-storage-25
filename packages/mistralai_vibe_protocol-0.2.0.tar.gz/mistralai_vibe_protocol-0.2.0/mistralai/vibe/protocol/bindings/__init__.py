"""Bindings — channel implementations and transport integrations.

- LocalChannel: in-process, backed by asyncio queues.
"""

from mistralai.vibe.protocol.bindings.local import LocalChannel

__all__ = [
    "LocalChannel",
]
