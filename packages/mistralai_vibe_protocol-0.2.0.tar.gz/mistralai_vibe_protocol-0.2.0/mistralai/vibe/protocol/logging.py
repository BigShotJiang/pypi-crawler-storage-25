"""Structured logging configuration for vibe_sdk.

Environment variables (also read from .env in project root):
    VIBE_LOG_LEVEL  — "DEBUG", "INFO", "WARNING" (default), "ERROR"
    VIBE_LOG_OUTPUT — "stdout" (default) or a file path (e.g. "logs/vibe.log")

Usage:
    from mistralai.vibe.protocol.logging import configure_logging
    configure_logging()  # reads .env + env vars, idempotent

All vibe_sdk modules use ``structlog.get_logger()`` — no manual config needed
inside library code. Call ``configure_logging()`` in entry points (CLI, worker,
demo scripts) to wire up processors and output.
"""

import logging
import os
import sys
from pathlib import Path

import structlog


def _load_dotenv() -> None:
    """Load .env file from the nearest parent directory that contains one.

    Walks up from CWD looking for a .env file. Sets variables in os.environ
    only if they are not already set (env vars take precedence over .env).
    """
    path = Path.cwd()
    for parent in [path, *path.parents]:
        env_file = parent / ".env"
        if env_file.is_file():
            for line in env_file.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip()
                if key and key not in os.environ:
                    os.environ[key] = value
            break


def configure_logging(
    level: str | None = None,
    output: str | None = None,
) -> None:
    """Configure structlog for vibe_sdk.

    Loads .env from the project root first (existing env vars take precedence).

    Args:
        level: Log level override. Falls back to VIBE_LOG_LEVEL env var,
               then "WARNING".
        output: Output target override. "stdout" or a file path.
                Falls back to VIBE_LOG_OUTPUT env var, then "stdout".
    """
    _load_dotenv()

    level = level or os.environ.get("VIBE_LOG_LEVEL", "WARNING")
    output = output or os.environ.get("VIBE_LOG_OUTPUT", "stdout")

    log_level = getattr(logging, level.upper(), logging.WARNING)

    # Standard library root logger — captures structlog's stdlib integration.
    handler: logging.Handler
    if output == "stdout":
        handler = logging.StreamHandler(sys.stdout)
    else:
        handler = logging.FileHandler(output, mode="a")

    handler.setLevel(log_level)

    logging.basicConfig(
        format="%(message)s",
        handlers=[handler],
        level=log_level,
        force=True,
    )

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.dev.ConsoleRenderer()
            if output == "stdout"
            else structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )
