# protocol/types/

Pure types and contracts for the Task Protocol (Phase 1).

This package contains the protocol-level primitives that are independent of any specific task implementation. Everything here is reusable across different task types. No I/O, no engine logic.

## Modules

- **state.py** — Core data types: `TaskState`, `TaskOutput` (discriminated union), `HistoryEntry` (union of `MessageEntry`, `TaskCallEntry`, `TaskResultEntry`), and their payloads. All types are Pydantic v2 BaseModel.

- **events.py** — `TaskStateUpdateEvent` (wraps patches for transport), `TaskCallEvent`, `TaskResultEvent`, `TaskResultStateUpdateEvent`, `TaskCancellationEvent`, and `DownstreamMessage`/`UpstreamMessage` type aliases.

- **channel.py** — `Channel` protocol (bidirectional session: `__aiter__` for downstream, `send` for upstream, `close`).

- **task.py** — `Task` protocol (`@runtime_checkable` structural subtyping) and `TaskCallback` / `TaskDefinition` (dataclasses).

- **patch.py** — RFC 6902 JSON Patch ops (`AddOp`, `ReplaceOp`, `RemoveOp`, etc.) plus `AppendOp` extension.

## Dependencies

Depends on nothing (pure types). `patch.py` sits alongside the other type modules as a shared primitive.

## See Also

- [modules/](../modules/) — Generic engine components (ExecutionLoop, StateModule, sub-task building blocks)
- [ARCHITECTURE.md](../../../ARCHITECTURE.md) — System design overview
