"""Task protocol — the contract for any task implementation.

Any class implementing ``card`` and ``run()`` is a valid task. The Task
protocol defines schema metadata (for LLM tool definitions and discovery)
and the run() method (for execution).

``Card`` bundles the static metadata (everything except ``run()``)
for introspection and auto-discovery over HTTP.

Serializable task configs (AgentTaskConfig, ToolTaskConfig, etc.) live
in their pattern modules (patterns/agent.py, patterns/tool.py).
"""

from typing import Any, Literal, Protocol, runtime_checkable

from pydantic import BaseModel, Field

from mistralai.vibe.protocol.types.channel import Channel
from mistralai.vibe.protocol.types.state import TaskState


class Card(BaseModel):
    """Serializable metadata shared by tasks and callbacks."""

    name: str
    description: str = ""
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None
    callbacks: list["TaskCallback"] = Field(default_factory=list)


class TaskCallback(BaseModel):
    """Declaration of a callback that a task expects its parent to handle.

    Phase 2 concept — declared here for protocol completeness.
    """

    type: Literal["task_callback"] = "task_callback"
    card: Card


@runtime_checkable
class Task(Protocol):
    """Protocol for a task.

    Any class implementing ``card`` and run() with this signature is a
    valid task. Structural subtyping — no inheritance required.
    """

    @property
    def card(self) -> Card: ...

    async def run(self, state: TaskState) -> Channel: ...


Card.model_rebuild()
TaskCallback.model_rebuild()
