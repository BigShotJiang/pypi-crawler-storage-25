"""Channel protocol — the bidirectional session between parent and child.

The Channel is the contract for communication between a parent and a
running child task. Downstream: the child sends TaskStateUpdateEvent
messages. Upstream: the parent sends control messages (Phase 2).
"""

from collections.abc import AsyncIterator
from typing import Protocol, runtime_checkable

from mistralai.vibe.protocol.types.events import DownstreamMessage, UpstreamMessage


@runtime_checkable
class Channel(Protocol):
    """The parent's handle to a running task.

    Calling task.run() creates a Channel. The parent reads
    downstream messages via async iteration and sends upstream
    messages via send().
    """

    def __aiter__(self) -> AsyncIterator[DownstreamMessage]: ...
    async def send(self, message: UpstreamMessage) -> None: ...
    async def close(self) -> None: ...
