"""Protocol layer — pure types and contracts.

This package defines the core protocol types and interfaces:
- state: TaskOutput, HistoryEntry types, TaskState
- events: TaskStateUpdateEvent, TaskCancellationEvent, DownstreamMessage, UpstreamMessage
- channel: Channel protocol
- task: Task protocol, TaskCallback
"""

from mistralai.vibe.protocol.types.channel import Channel
from mistralai.vibe.protocol.types.events import (
    CallbackCallEvent,
    CallbackCallPayload,
    CallbackResultEvent,
    CallbackResultPayload,
    CallbackStateUpdateEvent,
    CallbackStateUpdatePayload,
    DownstreamMessage,
    TaskCancellationEvent,
    TaskResultEvent,
    TaskResultPayload,
    TaskStateUpdateEvent,
    TaskStateUpdatePayload,
    UpstreamMessage,
)
from mistralai.vibe.protocol.types.patch import (
    AddOp,
    AppendOp,
    CopyOp,
    JsonTestOp,
    MoveOp,
    Op,
    Patch,
    RemoveOp,
    ReplaceOp,
)
from mistralai.vibe.protocol.types.state import (
    BaseEntry,
    CanceledOutput,
    CompletedOutput,
    ContentBlock,
    FailedOutput,
    HistoryEntry,
    MessageEntry,
    MessageEntryPayload,
    PendingOutput,
    StateEntry,
    TaskCallEntry,
    TaskCallEntryPayload,
    TaskOutput,
    TaskResultEntry,
    TaskResultEntryPayload,
    TaskState,
    TextContentBlock,
    ThinkingContentBlock,
    content_blocks,
    content_text,
)
from mistralai.vibe.protocol.types.task import Card, Task, TaskCallback

__all__ = [
    # State & entries
    "BaseEntry",
    "ContentBlock",
    "HistoryEntry",
    "MessageEntry",
    "MessageEntryPayload",
    "StateEntry",
    "TextContentBlock",
    "ThinkingContentBlock",
    "TaskCallEntry",
    "TaskCallEntryPayload",
    "TaskResultEntry",
    "TaskResultEntryPayload",
    "TaskState",
    "TaskOutput",
    "PendingOutput",
    "CompletedOutput",
    "FailedOutput",
    "CanceledOutput",
    "content_blocks",
    "content_text",
    # Patch
    "AddOp",
    "AppendOp",
    "CopyOp",
    "JsonTestOp",
    "MoveOp",
    "Op",
    "Patch",
    "RemoveOp",
    "ReplaceOp",
    # Events
    "TaskStateUpdateEvent",
    "TaskStateUpdatePayload",
    "TaskResultEvent",
    "TaskResultPayload",
    "CallbackCallEvent",
    "CallbackCallPayload",
    "CallbackStateUpdateEvent",
    "CallbackStateUpdatePayload",
    "CallbackResultEvent",
    "CallbackResultPayload",
    "TaskCancellationEvent",
    "DownstreamMessage",
    "UpstreamMessage",
    # Channel
    "Channel",
    # Task metadata
    "Card",
    "TaskCallback",
    "Task",
]
