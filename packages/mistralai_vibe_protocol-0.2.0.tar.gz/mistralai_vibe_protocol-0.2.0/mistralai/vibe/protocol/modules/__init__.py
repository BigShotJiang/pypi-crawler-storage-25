"""Generic engine components for task execution.

This package contains the reusable machinery that drives any task type:
- execution: ExecutionLoop and StateModule (event → reducer → diff → effects engine)
- sub_task: Subtask lifecycle reducer (call request handling, result tracking)
- produce: Immer-like produce() and diff() for mutation tracking
- json_patch: Apply JSON Patch (RFC 6902) operations to TaskState models
- network: Channel implementations (LocalChannel for in-process communication)
"""
