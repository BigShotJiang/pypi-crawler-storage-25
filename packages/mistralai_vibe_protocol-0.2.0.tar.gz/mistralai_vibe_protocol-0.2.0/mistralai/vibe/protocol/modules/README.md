# modules/

Generic engine components for the Task Protocol runtime.

This layer provides the reusable machinery that any task type can compose. It depends only on `protocol/` (pure types) and `patch.py` (RFC 6902 ops). It knows nothing about LLMs, specific tools, or concrete task implementations.

## Modules

- **execution.py** — `ExecutionLoop`, `StateModule` ABC, `EffectRegistry`, and `Downstream` protocol.
  - `StateModule` is the abstract base class for composable state machines. Subclasses implement exactly two methods: `reduce(state, event) -> (new_state, patches, effects)` and `handle_effect(effect, sink) -> list[Any]`.
  - `EffectRegistry` maps effect types to standalone handler functions. Handlers are registered at module scope via `@registry.handles(EffectType)` and assigned to `StateModule.effect_handlers`.
  - `ExecutionLoop` is a sequential two-phase loop: drain actions through the reducer, then gather effects concurrently via `asyncio.gather`. Maintains `_view_state` for deduplication — `diff(_view_state, new_state)` eliminates streaming duplicates at drain time. Effect handlers return actions instead of calling `dispatch()`. This maps to Temporal's workflow/activity model.
  - `Downstream` protocol (`send_patches(patches)` + `send(message)`) is the unified write-side interface for emitting patches and protocol messages to the consumer.

- **sub_task.py** — Sub-task building blocks: `sub_task_reducer()` and event/effect types.
  - `sub_task_reducer(state, event, task_impls)` handles `SubTaskCallRequest` (3-way resolution: local impl → `SpawnSubTask`, callback schema → `CallCallback`, unknown → `FailedOutput`), `SubTaskCompleted` (update result entry, set `generation_status="complete"`), and `CallbackResultReceived` (update pending result with upstream-resolved state).
  - Child streaming patches are relayed by `_handle_spawn_subtask` via `emit()` directly — they bypass the reducer entirely.
  - These are **composable building blocks**, not a `StateModule` subclass. Any `StateModule` that needs subtask support delegates to them.

- **produce.py** — Immer-like mutation tracking: `produce()`, `diff()`, `@immer_reducer`, and draft proxy classes (`ModelDraft`, `ListDraft`, `DictDraft`).
  - `produce(base, recipe)` creates draft proxies, lets the recipe mutate them, records `Op` objects, and builds new state with structural sharing.
  - `diff(old, new)` computes structural diffs using reference equality to skip unchanged subtrees.
  - `@immer_reducer` wraps a `recipe_with_effects` function in `produce()`, returning the 3-tuple `(new_state, patches, effects)`.

- **json_patch.py** — Patch application and rerouting.
  - `apply_patches(state, patches)` applies `Op` objects to a `TaskState` by path navigation.
  - `reroute_patches(patches, prefix)` prepends a path prefix to each patch, enabling O(1) child-to-parent patch propagation.

- **network/** — Channel implementations for different transports.
  - `local.py` — `LocalChannel`: in-process `Channel` backed by `asyncio.Queue`. Constructed directly with `LocalChannel(downstream_queue, upstream_queue, bg_task)`. `AgentTask` creates the queue via `_QueueBackedDownstream`, then passes `sink.queue` to `LocalChannel`.
  - `streamable_http.py` — HTTP/SSE transport for cross-process communication.

## Composition Pattern

```
┌──────────────────────────────────────────────┐
│              StateModule (ABC)               │
│  reduce(state, event) -> 3-tuple             │
│  handle_effect(effect, emit) -> actions      │
└───────────────────┬──────────────────────────┘
                    │ subclassed by
                    v
┌──────────────────────────────────────────────┐
│         AgentModule (in patterns/)           │
│  delegates to sub_task_reducer for subtasks  │
│  standalone handlers for effects             │
└───────────────────┬──────────────────────────┘
                    │ driven by
                    v
┌──────────────────────────────────────────────┐
│             ExecutionLoop                    │
│  Phase 1: drain actions → reduce → emit     │
│  Phase 2: gather effects → handle_effect     │
│  Repeat until terminal                       │
└──────────────────────────────────────────────┘
```

## Creating a New Task Pattern

To add a new task type (like `AgentTask`), you need four pieces:

### 1. Action and Effect types (Pydantic models)

Actions are events fed into the reducer (e.g. `Initialize`, `LLMTurnComplete`).
Effects are side-effect requests emitted by the reducer (e.g. `CallLLM`, `SpawnSubTask`).
Effects must be Pydantic `BaseModel`s with self-contained state for Temporal serialization.

```python
class Initialize(BaseModel): ...

class MyTurnComplete(BaseModel):
    result: str

class CallExternalService(BaseModel):
    state: TaskState  # self-contained for activity boundary
    endpoint: str
```

### 2. EffectRegistry + standalone handler functions

Handlers are standalone async functions registered via `@registry.handles(EffectType)`.
They receive the effect and an `UpdateStreamSink` for streaming, and return a list of actions.

```python
from vibe_sdk.modules.execution import EffectRegistry

registry = EffectRegistry()

@registry.handles(CallExternalService)
async def _handle_call_service(
    effect: CallExternalService, sink: UpdateStreamSink
) -> list[MyTurnComplete]:
    result = await call_service(effect.endpoint, effect.state)
    return [MyTurnComplete(result=result)]
```

### 3. StateModule subclass

Implements `reduce()` and `handle_effect()`, sets `effect_handlers` and `initial_action_type`.

```python
class MyModule(StateModule):
    effect_handlers = registry
    initial_action_type = Initialize

    def reduce(self, state, action):
        match action:
            case Initialize(): ...
            case MyTurnComplete(): ...

    async def handle_effect(self, effect, sink):
        handler = self.effect_handlers.get(type(effect))
        return await handler(effect, sink, **module_context)
```

### 4. ModuleTask subclass

The user-facing entry point. Implements `create_module()` and optionally `from_config()` for the workflow path.

```python
class MyTask(ModuleTask[MyTaskConfig]):
    def create_module(self) -> MyModule:
        return MyModule(...)

    @classmethod
    def from_config(cls, config, **kwargs) -> "MyTask":
        ...  # reconstruct from serializable config
```

See `patterns/agent.py` for the full reference implementation.

## Dependencies

Depends on `protocol/` (TaskState, events, Channel protocol) and `patch.py` (Op types).

## See Also

- [protocol/](../protocol/) — Pure types and contracts
- [patterns/](../patterns/) — Concrete task implementations that compose these modules
- [ARCHITECTURE.md](../../../ARCHITECTURE.md) — System design overview
