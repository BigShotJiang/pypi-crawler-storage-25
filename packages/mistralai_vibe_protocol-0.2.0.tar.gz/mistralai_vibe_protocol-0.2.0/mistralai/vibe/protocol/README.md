# vibe_protocol

SDK for the Task protocol — composable, observable, durable agentic orchestration.

## Overview

vibe_protocol is built around **the Task**, a single abstraction that unifies tools, agents, and workflows under one protocol. Every Task shares the same interface: input, output, streaming state updates, and recursive subtask composition.

- **One interface for everything**: Tools, LLM agents, workflows, and sandboxed code are all Tasks
- **Recursive composability**: Tasks compose into observable trees at any depth
- **Streaming observability**: Full execution state available in real-time via JSON patches
- **Port/adapter design**: Pluggable LLM backends via the CompletionModel protocol
- **Durability-ready**: TaskState is the complete checkpoint — serialize, store, resume

## Installation

```bash
uv sync
```

For development dependencies:

```bash
uv sync --all-extras
```

## Quick Start

```bash
MISTRAL_API_KEY=<your-key> uv run python examples/demo_simple.py
```

### Simple Agent with Tools

```python
from mistralai.vibe.protocol import AgentTask, ToolTask, TaskState, PendingOutput, MessageEntry, MessageEntryPayload
from mistralai.vibe.protocol.patterns.completion.adapters.mistral import MistralAdapter

def add_numbers(a: float, b: float) -> str:
    return str(a + b)

completion = MistralAdapter(api_key=api_key)
add_tool = ToolTask(fn=add_numbers, name="add_numbers", description="Add two numbers")

agent = AgentTask(
    completion=completion,
    tasks={"add_numbers": add_tool},
    system_prompt="You are a helpful assistant.",
)

state = TaskState(
    id="demo",
    output=PendingOutput(),
    history=[MessageEntry(payload=MessageEntryPayload(role="user", content="What is 3 + 4?"))],
)

channel = await agent.run(state)
async for message in channel:
    # TaskStateUpdateEvent with patches for real-time streaming
    print(message)
```

### Nested Agents (Subtask Delegation)

```python
researcher = AgentTask(
    completion=completion,
    tasks={"search_web": search_tool},
    name="researcher",
    description="Research a topic using web search",
    system_prompt="Research the given topic, then summarize findings.",
    input_schema={"type": "object", "properties": {"topic": {"type": "string"}}},
)

orchestrator = AgentTask(
    completion=completion,
    tasks={"researcher": researcher},
    system_prompt="Delegate research to the 'researcher' tool, then synthesize.",
)

channel = await orchestrator.run(state)
async for message in channel:
    print(message)
```

The orchestrator LLM sees `researcher` as a tool. When it calls `researcher(topic="quantum computing")`, the runtime spawns a nested agent loop with its own LLM and tools. The parent receives structured output as a tool result.

## Documentation

- [ARCHITECTURE.md](./ARCHITECTURE.md) — System design, module structure, and data flow
- [documentation/INDEX.md](./documentation/INDEX.md) — Index of design docs, RFCs, and protocol specs

## Development

```bash
# Type checking
uv run --with pyright pyright mistralai/

# Linting
uv run ruff check mistralai/

# Tests
uv run pytest tests/
```

## Project Structure

```
mistralai/vibe/protocol/
  __init__.py              # Package exports
  logging.py               # Structured logging configuration

  types/                   # Pure types and contracts
    state.py               # TaskState, HistoryEntry, TaskOutput
    events.py              # TaskStateUpdateEvent, messages
    channel.py             # Channel protocol
    task.py                # Task protocol (@runtime_checkable)
    patch.py               # RFC 6902 JSON Patch ops + AppendOp extension

  modules/                 # Generic engine components
    execution.py           # ExecutionLoop, StateModule ABC, Downstream protocol
    sub_task.py            # sub_task_reducer, subtask event/effect types
    produce.py             # Immer-like produce() + diff()
    json_patch.py          # apply_patches(), reroute_patches()
    task.py                # ModuleTask base class, TaskConfigBase

  bindings/                # Transport integrations
    local.py               # LocalChannel (in-process, asyncio.Queue)

tests/
  conftest.py              # Shared test factories and mocks
  test_protocol_types.py   # Protocol type tests
  test_produce.py          # produce() / diff() tests
  test_execution_loop.py   # ExecutionLoop tests
  test_sub_task.py         # sub_task_reducer tests
  test_json_patch.py       # JSON patch tests
  test_patch_serialization.py # Patch serialization tests
```
