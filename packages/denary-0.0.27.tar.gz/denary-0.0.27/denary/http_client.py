import asyncio
import io
import socket
import ssl
import tempfile
import zlib
from enum import Enum
from types import TracebackType
from typing import IO, Any, Iterator, Literal, Optional, Protocol, Self


class HttpVerbs(Enum):
    GET = b"GET"
    POST = b"POST"
    PUT = b"PUT"
    PATCH = b"PATCH"
    DELETE = b"DELETE"


class SupportsDecompress(Protocol):
    def decompress(self, data: bytes) -> bytes: ...
    def flush(self) -> bytes: ...


class HttpResponse:
    def __init__(
        self,
        status: int,
        headers: dict,
        body_file: IO[bytes],
        spool_max_size: int = 1024 * 1024,
    ) -> None:
        self.status = status
        self.headers = headers
        self._body_file = body_file
        self._spool_max_size = spool_max_size
        self._body_cache: bytes | None = None

    def __repr__(self) -> str:
        try:
            pos = self._body_file.tell()
            self._body_file.seek(0, io.SEEK_END)
            size = self._body_file.tell()
            self._body_file.seek(pos)
        except Exception:
            size = -1
        return f"<HttpResponse {self.status} {size} bytes>"

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None = None,
        exc: BaseException | None = None,
        tb: TracebackType | None = None,
    ) -> Literal[False]:
        self.close()
        return False

    def __iter__(self) -> Iterator[bytes]:
        return self.iter_bytes()

    @property
    def body(self) -> bytes:
        """
        Lazily materialize the whole body as bytes.
        """
        if self._body_cache is None:
            current = self._body_file.tell()
            self._body_file.seek(0)
            self._body_cache = self._body_file.read()
            self._body_file.seek(current)

        assert self._body_cache is not None

        return self._body_cache

    def read(self, size: int = -1) -> bytes:
        """
        Read from the internal spooled file from its current position.
        """
        return self._body_file.read(size)

    def seek(self, offset: int, whence: int = io.SEEK_SET):
        return self._body_file.seek(offset, whence)

    def tell(self) -> int:
        return self._body_file.tell()

    def iter_bytes(self, chunk_size: int = 8192):
        """
        Iterate over the response body in chunks from the start.
        Restores the original file position afterwards.
        """
        if chunk_size <= 0:
            raise ValueError("chunk_size must be > 0")

        current = self._body_file.tell()
        self._body_file.seek(0)

        try:
            while True:
                chunk = self._body_file.read(chunk_size)
                if not chunk:
                    break
                yield chunk
        finally:
            self._body_file.seek(current)

    def text(self, encoding: str | None = None, errors: str = "replace") -> str:
        """
        Decode the body to text.
        If encoding is not specified, tries to extract charset from Content-Type.
        """
        if encoding is None:
            encoding = self._detect_encoding_from_headers() or "utf-8"
        return self.body.decode(encoding, errors=errors)

    def close(self) -> None:
        self._body_file.close()

    def _detect_encoding_from_headers(self) -> str | None:
        content_type = self.headers.get("content-type", "")
        if not content_type:
            return None

        parts = [p.strip() for p in content_type.split(";")]
        for part in parts[1:]:
            if "=" in part:
                name, value = part.split("=", 1)
                if name.strip().lower() == "charset":
                    return value.strip().strip('"')
        return None


def parse_headers(header_list: list[str]) -> dict[str, str]:
    headers = {}
    if header_list:
        for item in header_list:
            if ":" not in item:
                raise ValueError(f"Invalid header format: {item}. Use name:value")
            name, value = item.split(":", 1)
            headers[name.strip()] = value.strip()
    return headers


def parse_host_url(url: str) -> tuple[str, int, str, bool]:
    is_https = url.startswith("https://")
    url = url.replace("https://", "").replace("http://", "")

    if "/" in url:
        host_port, uri = url.split("/", 1)
        uri = "/" + uri
    else:
        host_port, uri = url, "/"

    if ":" in host_port:
        host, _port = host_port.split(":")
        port = int(_port)
    else:
        host = host_port
        port = 443 if is_https else 80

    return host, port, uri, is_https


def resolve_redirect_url(base_url: str, new_url: str) -> str:
    """Support absolute & relative redirects."""
    if new_url.startswith("http://") or new_url.startswith("https://"):
        return new_url

    host, _, _, is_https = parse_host_url(base_url)
    scheme = "https" if is_https else "http"

    if new_url.startswith("/"):
        return f"{scheme}://{host}{new_url}"

    _, _, base_uri, _ = parse_host_url(base_url)
    if "/" in base_uri:
        parent = base_uri.rsplit("/", 1)[0]
        if not parent:
            parent = "/"
    else:
        parent = "/"

    if not parent.endswith("/"):
        parent += "/"

    return f"{scheme}://{host}{parent}{new_url}"


class BodyWriter:
    """
    Streams decoded response body into a SpooledTemporaryFile.

    Handles incremental decompression for:
    - gzip
    - deflate
    - br (if brotli installed)
    """

    def __init__(self, headers: dict, spool_max_size: int = 1024 * 1024) -> None:
        self.headers = headers
        self.file = tempfile.SpooledTemporaryFile(max_size=spool_max_size, mode="w+b")
        self._encoding = headers.get("content-encoding", "").lower()
        self._decoder = self._create_decoder(self._encoding)

    def write(self, data: bytes) -> None:
        if not data:
            return

        if self._decoder is None:
            self.file.write(data)
            return

        out = self._decoder.decompress(data)
        if out:
            self.file.write(out)

    def finalize(self) -> IO[bytes]:
        if self._decoder is not None:
            flushed = self._flush_decoder()
            if flushed:
                self.file.write(flushed)
        self.file.seek(0)
        return self.file

    def _create_decoder(self, encoding: str) -> SupportsDecompress | None:
        if encoding == "gzip":
            return zlib.decompressobj(16 + zlib.MAX_WBITS)

        if encoding == "deflate":
            # First try zlib wrapper. If it fails during decompression,
            # we'll retry raw deflate lazily in a wrapper.
            return DeflateDecoder()

        if encoding == "br":
            try:
                import brotli  # type: ignore[import-not-found]

                return BrotliDecoder(brotli)
            except ImportError:
                return None

        return None

    def _flush_decoder(self) -> bytes:
        if self._decoder is not None and hasattr(self._decoder, "flush"):
            return self._decoder.flush()
        return b""


class DeflateDecoder:
    """
    Handles both zlib-wrapped deflate and raw deflate.
    """

    def __init__(self) -> None:
        self._tried_raw = False
        self._buffered = bytearray()
        self._obj = zlib.decompressobj()

    def decompress(self, data: bytes) -> bytes:
        self._buffered.extend(data)
        try:
            return self._obj.decompress(data)
        except zlib.error:
            if self._tried_raw:
                raise
            self._tried_raw = True
            self._obj = zlib.decompressobj(-zlib.MAX_WBITS)
            return self._obj.decompress(bytes(self._buffered))

    def flush(self) -> bytes:
        return self._obj.flush()


class BrotliDecoder:
    def __init__(self, brotli_module: Any) -> None:
        self._brotli = brotli_module
        self._obj = brotli_module.Decompressor()

    def decompress(self, data: bytes) -> bytes:
        if hasattr(self._obj, "process"):
            return self._obj.process(data)
        if hasattr(self._obj, "decompress"):
            return self._obj.decompress(data)
        return self._brotli.decompress(data)

    def flush(self) -> bytes:
        return b""


class IncrementalHttpResponseParser:
    """
    Incremental HTTP/1.1 response parser.

    Supports:
    - header parsing as bytes arrive
    - Content-Length bodies
    - chunked transfer encoding
    - connection-close bodies

    Streams body into a BodyWriter instead of accumulating in memory.
    """

    def __init__(self, spool_max_size: int = 1024 * 1024) -> None:
        self._buffer = bytearray()

        self.headers_complete = False
        self.message_complete = False

        self.status: int | None = None
        self.headers: dict[str, str] = {}
        self._body_writer: BodyWriter | None = None
        self._spool_max_size = spool_max_size

        self._is_chunked = False
        self._content_length: int | None = None
        self._read_until_close = False
        self._received_body_bytes = 0

        self._chunk_state = "size"
        self._current_chunk_size: int | None = None

    def feed(self, data: bytes) -> None:
        if self.message_complete:
            return

        self._buffer.extend(data)

        if not self.headers_complete:
            self._try_parse_headers()

        if self.headers_complete and not self.message_complete:
            self._parse_body()

    def feed_eof(self) -> None:
        """
        Notify parser that connection closed.
        """
        if self.message_complete:
            return

        if self.headers_complete and self._read_until_close:
            if self._buffer:
                self._write_body(bytes(self._buffer))
                self._buffer.clear()
            self.message_complete = True

    def build_response(self) -> HttpResponse:
        if self.status is None or self._body_writer is None:
            raise RuntimeError("Response is incomplete or invalid")

        body_file = self._body_writer.finalize()

        return HttpResponse(
            status=self.status,
            headers=self.headers,
            body_file=body_file,
            spool_max_size=self._spool_max_size,
        )

    def _try_parse_headers(self) -> None:
        marker = self._buffer.find(b"\r\n\r\n")
        if marker == -1:
            return

        header_block = bytes(self._buffer[:marker])
        del self._buffer[: marker + 4]

        lines = header_block.split(b"\r\n")
        if not lines:
            raise ValueError("Invalid HTTP response: empty header block")

        status_line = lines[0].decode("latin1")
        parts = status_line.split(" ", 2)
        if len(parts) < 2:
            raise ValueError(f"Invalid HTTP status line: {status_line}")

        self.status = int(parts[1])

        parsed_headers = {}
        for line in lines[1:]:
            decoded = line.decode("latin1")
            if ":" in decoded:
                name, value = decoded.split(":", 1)
                parsed_headers[name.strip().lower()] = value.strip()

        self.headers = parsed_headers
        self.headers_complete = True
        self._body_writer = BodyWriter(self.headers, self._spool_max_size)

        transfer_encoding = self.headers.get("transfer-encoding", "").lower()
        content_length = self.headers.get("content-length")

        self._is_chunked = "chunked" in transfer_encoding

        if self._is_chunked:
            self._content_length = None
            self._read_until_close = False
        elif content_length is not None:
            self._content_length = int(content_length)
            self._read_until_close = False
        else:
            self._content_length = None
            self._read_until_close = True

    def _parse_body(self) -> None:
        if self._is_chunked:
            self._parse_chunked_body()
        elif self._content_length is not None:
            self._parse_content_length_body()
        else:
            # wait for EOF, then feed_eof() finalizes it
            pass

    def _parse_content_length_body(self) -> None:
        if self._content_length is None:
            return

        remaining = self._content_length - self._received_body_bytes
        if remaining <= 0:
            self.message_complete = True
            return

        if not self._buffer:
            return

        take = min(remaining, len(self._buffer))
        chunk = bytes(self._buffer[:take])
        del self._buffer[:take]

        self._write_body(chunk)
        self._received_body_bytes += take

        if self._received_body_bytes >= self._content_length:
            self.message_complete = True

    def _parse_chunked_body(self) -> None:
        while True:
            if self._chunk_state == "size":
                pos = self._buffer.find(b"\r\n")
                if pos == -1:
                    return

                size_line = bytes(self._buffer[:pos]).decode("latin1").strip()
                del self._buffer[: pos + 2]

                size_hex = size_line.split(";", 1)[0]
                try:
                    self._current_chunk_size = int(size_hex, 16)
                except ValueError as e:
                    raise ValueError(f"Invalid chunk size: {size_line}") from e

                if self._current_chunk_size == 0:
                    # trailers may follow; simplest valid ending often just CRLF
                    if self._buffer.startswith(b"\r\n"):
                        del self._buffer[:2]
                        self.message_complete = True
                        return

                    trailer_end = self._buffer.find(b"\r\n\r\n")
                    if trailer_end != -1:
                        del self._buffer[: trailer_end + 4]
                        self.message_complete = True
                        return

                    return

                self._chunk_state = "data"

            elif self._chunk_state == "data":
                if self._current_chunk_size is None:
                    return

                needed = self._current_chunk_size + 2
                if len(self._buffer) < needed:
                    return

                chunk = bytes(self._buffer[: self._current_chunk_size])
                crlf = bytes(
                    self._buffer[
                        self._current_chunk_size : self._current_chunk_size + 2
                    ]
                )
                if crlf != b"\r\n":
                    raise ValueError("Invalid chunk terminator")

                self._write_body(chunk)
                del self._buffer[:needed]

                self._current_chunk_size = None
                self._chunk_state = "size"

    def _write_body(self, data: bytes) -> None:
        assert self._body_writer is not None
        self._body_writer.write(data)


def build_request(
    host: str,
    uri: str,
    verb: HttpVerbs,
    headers: dict | None,
    body: str,
) -> bytes:
    body_bytes = body.encode() if body else b""

    request_headers = {
        "Host": host,
        "Connection": "close",
        "Accept-Encoding": "gzip, deflate, br",
    }

    if headers:
        request_headers.update(headers)

    if body_bytes:
        request_headers.setdefault("Content-Length", str(len(body_bytes)))
    elif verb in {HttpVerbs.POST, HttpVerbs.PUT, HttpVerbs.PATCH}:
        request_headers.setdefault("Content-Length", "0")

    request_lines = [f"{verb.value.decode()} {uri} HTTP/1.1"]
    request_lines += [f"{k}: {v}" for k, v in request_headers.items()]
    request_message = "\r\n".join(request_lines) + "\r\n\r\n"

    return request_message.encode() + body_bytes


def http_client(
    url: str,
    verb: HttpVerbs = HttpVerbs.GET,
    body: str = "",
    headers: Optional[dict[str, str]] = None,
    redirect_limit: int | None = None,
    spool_max_size: int = 1024 * 1024,
) -> HttpResponse:

    if redirect_limit is not None and redirect_limit < 0:
        raise RuntimeError("Too many redirects")

    host, port, uri, is_https = parse_host_url(url)

    raw_socket = socket.create_connection((host, port))

    client: Optional[socket.socket | ssl.SSLSocket] = None
    if is_https:
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        client = context.wrap_socket(raw_socket, server_hostname=host)
    else:
        client = raw_socket

    assert client is not None

    try:
        request_bytes = build_request(host, uri, verb, headers, body)
        client.sendall(request_bytes)

        parser = IncrementalHttpResponseParser(spool_max_size=spool_max_size)

        while not parser.message_complete:
            data = client.recv(4096)
            if not data:
                parser.feed_eof()
                break
            parser.feed(data)

        response = parser.build_response()

    finally:
        try:
            client.close()
        finally:
            raw_socket.close()

    if (
        redirect_limit is not None
        and response.status in (301, 302, 303, 307, 308)
        and "location" in response.headers
    ):
        new_url = resolve_redirect_url(url, response.headers["location"])
        print(f"Redirect → {response.status} → {new_url}")
        response.close()

        next_verb = verb
        next_body = body

        if response.status == 303:
            next_verb = HttpVerbs.GET
            next_body = ""

        return http_client(
            new_url,
            verb=next_verb,
            body=next_body,
            headers=headers,
            redirect_limit=redirect_limit - 1,
            spool_max_size=spool_max_size,
        )

    return response


async def ahttp_client(
    url: str,
    verb: HttpVerbs = HttpVerbs.GET,
    body: str = "",
    headers: Optional[dict[str, str]] = None,
    redirect_limit: int | None = None,
    spool_max_size: int = 1024 * 1024,
) -> HttpResponse:

    if redirect_limit is not None and redirect_limit <= 0:
        raise RuntimeError("Too many redirects")

    host, port, uri, is_https = parse_host_url(url)

    ssl_context = None
    if is_https:
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE

    reader, writer = await asyncio.open_connection(host, port, ssl=ssl_context)

    try:
        request_bytes = build_request(host, uri, verb, headers, body)
        writer.write(request_bytes)
        await writer.drain()

        parser = IncrementalHttpResponseParser(spool_max_size=spool_max_size)

        while not parser.message_complete:
            chunk = await reader.read(4096)
            if not chunk:
                parser.feed_eof()
                break
            parser.feed(chunk)

        response = parser.build_response()

    finally:
        writer.close()
        await writer.wait_closed()

    if (
        redirect_limit is not None
        and response.status in (301, 302, 303, 307, 308)
        and "location" in response.headers
    ):
        new_url = resolve_redirect_url(url, response.headers["location"])
        print(f"[ASYNC] Redirect → {response.status} → {new_url}")
        response.close()

        next_verb = verb
        next_body = body

        if response.status == 303:
            next_verb = HttpVerbs.GET
            next_body = ""

        return await ahttp_client(
            new_url,
            verb=next_verb,
            body=next_body,
            headers=headers,
            redirect_limit=redirect_limit - 1,
            spool_max_size=spool_max_size,
        )

    return response
