import asyncio
import json
import re
import time
import uuid
from typing import Any, Optional

from denary import config, events, http_client


def get_code_from_markdown(response: str) -> str:
    pattern = r"```(?:\w+)?\n(.*?)```"
    match = re.search(pattern, response, re.DOTALL)

    if not match:
        return ""

    return match.group(1).strip()


def format_elapsed(seconds: float) -> str:
    seconds = int(seconds)

    if seconds < 60:
        unit = "second" if seconds == 1 else "seconds"
        return f"{seconds} {unit} ago"

    minutes = seconds // 60
    if minutes < 60:
        unit = "minute" if minutes == 1 else "minutes"
        return f"{minutes} {unit} ago"

    hours = minutes // 60
    unit = "hour" if hours == 1 else "hours"
    return f"{hours} {unit} ago"


async def ollama_tool(
    prompt: str, message: Optional[str] = None, options: Optional[dict] = None
) -> str:
    if message is None:
        message = ""

    model = config.STATIC_CONFIG.get("model", None)

    if model is None:
        raise ValueError("No model configured in STATIC_CONFIG.")

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": message},
            {"role": "user", "content": prompt},
        ],
        "stream": False,
    }

    if options is not None:
        payload["options"] = options

    response = await http_client.ahttp_client(
        url="http://localhost:11434/v1/chat/completions",
        verb=http_client.HttpVerbs.POST,
        headers={"Content-Type": "application/json"},
        body=json.dumps(payload),
    )

    if response.status != 200:
        raise Exception(f"Ollama returned {response.status}: " f"{response.text()}")

    data = json.loads(response.text())

    response.close()

    return data["choices"][0]["message"]["content"]


def get_available_models() -> list[str]:
    with http_client.http_client(
        url="http://localhost:11434/api/tags",
        verb=http_client.HttpVerbs.GET,
        headers={"Content-Type": "application/json"},
        body="",
    ) as response:

        if response.status != 200:
            raise Exception(f"Ollama returned {response.status}: " f"{response.text()}")

        data = json.loads(response.text())

        return [model["name"] for model in data.get("models", [])]


class CompletionManager:
    def __init__(self) -> None:
        self.queue: asyncio.Queue[tuple[str, str]] = asyncio.Queue()
        self.jobs: dict[str, dict[str, Any]] = {}
        self.worker: asyncio.Task | None = None
        # self.notifications: deque[str] = deque()

    def submit(self, prompt: str, prompt_type: int = 1) -> str:
        job_id = uuid.uuid4().hex

        self.jobs[job_id] = {
            "type": prompt_type,
            "status": "PENDING",
            "created_at": time.time(),
            "cancel": False,
            "result": None,
        }

        self.queue.put_nowait((job_id, prompt))

        self.start()

        return job_id

    def start(self) -> None:
        if self.worker is None:
            self.worker = asyncio.create_task(self._worker_loop())

    async def _worker_loop(self) -> None:
        try:
            while True:
                job_id, prompt = await self.queue.get()

                if self.jobs[job_id]["cancel"]:
                    self.jobs[job_id]["status"] = "CANCELLED"
                    await events.EVENT_QUEUE.put(
                        events.Event(type=events.EventType.AI_COMPLETION, data=job_id)
                    )
                    continue

                self.jobs[job_id]["status"] = "RUNNING"
                await events.EVENT_QUEUE.put(
                    events.Event(type=events.EventType.AI_COMPLETION, data=job_id)
                )

                prompt_type = self.jobs[job_id]["type"]

                time_start = time.time()

                try:
                    match prompt_type:
                        case 1:
                            result = await ollama_tool(
                                prompt=prompt,
                                options={
                                    "temperature": 0.4,
                                    "top_p": 0.95,
                                    "repeat_penalty": 1.1,
                                    "num_predict": 1000,
                                },
                            )
                        case 2:
                            result = await ollama_tool(
                                prompt=prompt,
                                message="You are a helpful coding assistant.",
                            )
                        case 3:
                            result = await ollama_tool(
                                prompt=prompt,
                                message="You are a senior software engineer performing a strict code review.",
                            )
                        case 4:
                            result = await ollama_tool(
                                prompt=prompt,
                                message="You generate concise Git commit messages in conventional commit format.",
                                options={
                                    "temperature": 0.4,
                                    "top_p": 0.9,
                                    "repeat_penalty": 1.05,
                                    "num_predict": 600,
                                },
                            )
                        case _:
                            result = await ollama_tool(
                                prompt=prompt,
                                message="You are a helpful coding assistant.",
                            )

                    if self.jobs[job_id]["cancel"]:
                        self.jobs[job_id]["status"] = "CANCELLED"

                    else:
                        self.jobs[job_id]["status"] = "COMPLETED"
                        self.jobs[job_id]["result"] = result

                        job_type = self.jobs[job_id]["type"]
                        total_time = format_elapsed(time_start - time.time())

                        message = f"{total_time=}, {job_type=}, {job_id=}  completed."

                        await events.EVENT_QUEUE.put(
                            events.Event(
                                type=events.EventType.NOTIFICATION, data=(message, 1000)
                            )
                        )

                    await events.EVENT_QUEUE.put(
                        events.Event(type=events.EventType.AI_COMPLETION, data=job_id)
                    )

                except asyncio.CancelledError:
                    break

                except Exception as e:
                    self.jobs[job_id]["status"] = "ERROR"
                    self.jobs[job_id]["result"] = str(e)

                    job_type = self.jobs[job_id]["type"]
                    total_time = format_elapsed(time_start - time.time())

                    message = f"{total_time=}, {job_type=}, {job_id=}  failed."

                    await events.EVENT_QUEUE.put(
                        events.Event(
                            type=events.EventType.NOTIFICATION, data=(message, 1000)
                        )
                    )

                self.queue.task_done()

        except asyncio.CancelledError:
            pass

    def get_status(self, job_id: str) -> str | None:
        job = self.jobs.get(job_id)
        return str(job["status"]) if job else None

    def get_result(self, job_id: str) -> str | None:
        job = self.jobs.get(job_id)
        return str(job["result"]) if job else None

    def get_job(self, job_id: str) -> dict[str, Any] | None:
        if job := self.jobs.get(job_id):
            return job.copy()

        return None

    def cancel(self, job_id: str) -> None:
        if job_id in self.jobs:
            self.jobs[job_id]["cancel"] = True

    # async def shutdown(self) -> None:
    #     if self.worker is not None:
    #         self.worker.cancel()

    async def shutdown(self) -> None:
        if self.worker is not None:
            self.worker.cancel()
            try:
                await self.worker
            except asyncio.CancelledError:
                pass
