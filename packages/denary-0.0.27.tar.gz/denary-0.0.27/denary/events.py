import asyncio
import enum
from dataclasses import dataclass
from typing import Any, Optional


class EventType(enum.Enum):
    TICK = enum.auto()
    KEY = enum.auto()
    FILE_CHANGED_ON_DISK = enum.auto()
    NOTIFICATION = enum.auto()
    GIT_BRANCH_UPDATED = enum.auto()

    LOAD_LSP = enum.auto()

    LSP_REQUEST_STARTED = enum.auto()
    LSP_REQUEST_COMPLETED = enum.auto()
    LSP_REQUEST_FAILED = enum.auto()
    LSP_DIAGNOSTICS_UPDATED = enum.auto()

    SUBPROCESS_STARTED = enum.auto()
    SUBPROCESS_COMPLETED = enum.auto()
    SUBPROCESS_CANCELLED = enum.auto()

    HTTP_REQUEST_STARTED = enum.auto()
    HTTP_REQUEST_COMPLETED = enum.auto()
    HTTP_REQUEST_CANCELLED = enum.auto()

    AI_COMPLETION = enum.auto()

    MOUSE = enum.auto()

    QUIT = enum.auto()


class LSPEventType(enum.Enum):
    TEXT_DOCUMENT_DID_OPEN = enum.auto()
    TEXT_DOCUMENT_DID_CHANGE = enum.auto()
    TEXT_DOCUMENT_DID_SAVE = enum.auto()
    TEXT_DOCUMENT_DID_CLOSE = enum.auto()

    TEXT_DOCUMENT_HOVER = enum.auto()
    TEXT_DOCUMENT_COMPLETION = enum.auto()
    TEXT_DOCUMENT_CODE_ACTION = enum.auto()
    TEXT_DOCUMENT_DEFINITION = enum.auto()
    TEXT_DOCUMENT_REFERENCES = enum.auto()
    TEXT_DOCUMENT_DOCUMENT_SYMBOL = enum.auto()
    TEXT_DOCUMENT_FORMATTING = enum.auto()
    TEXT_DOCUMENT_RENAME = enum.auto()


@dataclass(slots=True, frozen=True)
class Event:
    type: EventType | LSPEventType
    data: Optional[Any] = None


EVENT_QUEUE: asyncio.Queue[Event] = asyncio.Queue(maxsize=1000)
