from __future__ import annotations

import json
import os
import shutil
import textwrap
import traceback
import uuid
from dataclasses import dataclass
from datetime import datetime
from io import StringIO
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Optional

from pygments.lexers import DiffLexer, MarkdownLexer

from denary import (
    buf_actions,
    config,
    diagnostics,
    external_tui,
    file_explorer,
    git_utils,
    http_request,
    session,
    subprocess_task,
)
from denary.buf import Buffer
from denary.help_text import HELP_TEXT

if TYPE_CHECKING:
    from denary.editor import SimpleEditor

type CommandHandler = Callable[[SimpleEditor, str | None, str | None], None]


@dataclass(slots=True)
class Command:
    name: str
    handler: CommandHandler
    description: str = ""
    aliases: tuple[str, ...] = ()


COMMANDS: dict[str, Command] = {}


def register_command(
    name: str,
    *,
    aliases: tuple[str, ...] = (),
    description: str = "",
):
    def decorator(func: CommandHandler) -> CommandHandler:
        cmd = Command(name=name, handler=func, description=description, aliases=aliases)

        if name in COMMANDS:
            raise ValueError(f"Duplicate command: {name}")

        COMMANDS[name] = cmd

        for alias in aliases:
            if alias in COMMANDS:
                raise ValueError(f"Duplicate alias: {alias}")
            COMMANDS[alias] = cmd

        return func

    return decorator


def command_mode_mappings(editor: SimpleEditor, command: Optional[str] = None) -> None:
    if not editor.disable_search:
        editor.disable_search = True

    arg = None

    if command is not None:
        res = command
        editor.send_notification(f"Running last command: ({command})")
    else:
        res = editor.send_prompt("cmd: ", editor.command_history)

    if not res:
        return None

    if res.startswith("!"):
        arg = res
        res = "!"
    else:
        res, *args = res.split(" ")
        arg = " ".join(args)

    cmd = COMMANDS.get(res)

    if not cmd:
        editor.send_notification(f"Unknown command: {res}")
        return None

    cmd.handler(editor, arg, res)
    return None


@register_command(name="help", aliases=("h",), description="Show help documentation")
def show_help_text(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    help_buffer_name = "__help__"
    editor.open_aux_buffer(HELP_TEXT, help_buffer_name, lexer=MarkdownLexer())


@register_command(name="version", description="Get current version of the editor.")
def show_vesrion(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    from denary.editor import get_version

    editor.send_notification(get_version(), 0)


@register_command(name="q", description="Close the current buffer")
def close_buffer(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.close_buffer()


@register_command(name="w", description="Save Current Buffer")
def save_buffer(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.save_file()


@register_command("qa", aliases=("exit",), description="exits the editor")
def close_editor(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.confirm_quit()


@register_command(
    "open", description="open a new buffer or switches to it if its already opened"
)
def open_buffer(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.end_selection()
    editor.open_buffer_prompt()


@register_command(
    "ls",
    description="List all existing buffers and tells you which one still has unsaved changes.",
)
def list_buffers(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    message = "Choose Buffer:\n" + "\n".join(
        f"#{i + 1} - {"*" if b.modified else " "}{b.file_name}{" <-" if i == editor.get_current_buffer_index_window() else ""}"
        for i, b in enumerate(editor.buffers)
    )

    res = editor.send_multiline_prompt(message, "Choose buffer or press enter:")

    if res and res.isdigit():
        res_int = int(res) - 1

        if 0 <= res_int < len(editor.buffers):
            # editor.current_buffer = res_int
            editor.set_current_buffer(res_int)
            editor.send_notification(
                f"Switched to buffer #{editor.get_current_buffer_index_window() + 1}",
                200,
            )


@register_command(
    "cancel_tasks",
    aliases=("ctasks",),
    description="Cancels tasks that are running or are pending.",
)
def cancel_running_or_pending_tasks(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    message = "Tasks Pending:\n" + "\n".join(
        f"#{i + 1} - {task["task_id"]}: {task["command"]}"
        for i, task in enumerate(editor.task_running)
    )

    res = editor.send_multiline_prompt(
        message, "Choose the task to cancel or press enter:"
    )

    if res and res.isdigit():
        res_int = int(res) - 1

        if 0 <= res_int < len(editor.task_running):
            task = editor.task_running[res_int]

            try:
                task["task"].cancel()

                editor.send_notification(
                    f"Task {task["task_id"]} cancelled successfully.", 200
                )

            except Exception as e:
                editor.send_notification(
                    f"Could not cancel the task ({task["task_id"]}): {e}\n{traceback.format_exc}"
                )


@register_command(
    "newbuf", aliases=("bufnew",), description="Creates a new untitled buffer."
)
def create_new_untitled_buffer(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.new_buffer_count += 1
    editor.buffers.append(
        Buffer(
            f"Untitled-{editor.new_buffer_count}",
            new_buffer_untitled=True,
            temp_dir=editor.temp_dir,
        )
    )
    # editor.current_buffer = len(editor.buffers) - 1
    editor.set_current_buffer(len(editor.buffers) - 1)
    editor.send_notification("New buffer created")


@register_command(
    name="nextbuf", aliases=("nbuf", "next", "n"), description="Go to next buffer"
)
def next_buffer(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.go_next_buffer()
    editor.send_notification(
        f"Switched to buffer #{editor.get_current_buffer_index_window() + 1}", 10
    )


@register_command(
    name="prevbuf", aliases=("pbuf", "prev", "p"), description="Go to previous buffer"
)
def prev_buffer(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.go_prev_buffer()
    editor.send_notification(
        f"Switched to buffer #{editor.get_current_buffer_index_window() + 1}", 10
    )


@register_command(
    name="delbuf",
    aliases=("deletebuf", "del", "d"),
    description="Delete current buffer",
)
def delete_buffer(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.close_buffer()
    editor.send_notification("Buffer deleted")


@register_command("ff", description="Fuzzy file picker")
def fuzzy_file(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.show_file_picker()


@register_command("ffr", description="Refresh and Fuzzy file picker")
def fuzzy_file_recursive(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.fuzzy_changed = True
    editor.show_file_picker()


@register_command("fb", description="Fuzzy buffer picker")
def fuzzy_buffer(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.show_buffer_picker()


@register_command(name="themes", aliases=("th",), description="Change theme")
def themes(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.show_theme_picker()


@register_command("ex", description="Open file explorer")
def explorer(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    explorer = file_explorer.ExplorerWindow(
        manager=editor.window_manager,
        editor=editor,
    )

    editor.window_manager.push_overlay(explorer)


@register_command("commands", description="Show command picker")
def show_commands(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.show_command_picker()


@register_command(name="change_ai_model", description="Change AI model")
def change_ai_model(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.show_ai_model_picker()
    config.save_static_config()


@register_command("ln", description="Toggle line numbers")
@register_command("gch", description="Toggle git changes")
def toggle_line_numbers(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    if res is not None:
        editor.toggle_line_number(option=res)
        config.save_static_config()


@register_command("brkm", description="Toggle bracket match")
def toggle_bracket(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.toggle_bracket_match()
    config.save_static_config()


@register_command("scrolloff", description="Set scrolloff value")
def scrolloff(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    try:
        if args:
            value = int(args)
        else:
            value = int(editor.send_prompt("Scrolloff: "))
    except Exception:
        value = 0

    config.STATIC_CONFIG["scrolloff"] = value
    config.save_static_config()


@register_command(name="marker", aliases=("m",), description="Set marker")
def set_marker(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.set_marker()


@register_command(name="pickmarker", aliases=("pm",), description="Pick marker")
def pick_marker(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.end_selection()
    editor.pick_markers()


@register_command("dm", description="Delete markers in current buffer")
def delete_markers(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    buffer = editor.get_current_buffer()
    buffer.markers.clear()


@register_command("dgm", description="Delete global markers")
def delete_global_markers(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.global_markers.clear()


@register_command("dpm", description="Delete specific marker")
def delete_prompt_marker(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    buffer = editor.get_current_buffer()

    marker = args or editor.send_prompt("Marker to delete: ")
    if not marker:
        return

    marker_found = False

    if marker in editor.global_markers:
        editor.global_markers.pop(marker)
        marker_found = True
    elif marker in buffer.markers:
        buffer.markers.pop(marker)
        marker_found = True

    if marker_found:
        editor.send_notification("Marker deleted.")
    else:
        editor.send_notification("Marker not found.")


@register_command("dam", description="Delete all markers")
def delete_all_markers(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    for buffer in editor.buffers:
        buffer.markers.clear()

    editor.global_markers.clear()


@register_command("lexing_info", description="Show lexing debug info")
def lexing_info(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    buffer = editor.get_current_buffer()
    line = buffer.lines[window.cursor_y]

    info = json.dumps(
        {
            "text": line,
            "state": line.state,
            "tokens": line.tokens,
            "_width_cache": line._width_cache,
            "_bracket_cache": line._bracket_cache,
        },
        indent=4,
    )

    editor.open_file_in_less_mode(file_handle=StringIO(info))


@register_command(
    name="jump_list", aliases=("jl",), description="Show jump list picker"
)
def jump_list(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.show_jump_picker()


@register_command(name="clear_registers", description="Clear all registers")
def clear_registers(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.registers.clear()


@register_command(name="replace", description="Interactive replace in buffer")
def replace(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.end_selection()
    editor.interactive_replace_in_buffer()
    editor.end_selection()


@register_command(name="comment", description="Toggle comment on selection")
def comment(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    if args is None:
        res = editor.send_prompt("Comment prefix (enter for default): ")
    else:
        res = args

    prefix = res if res else None
    editor.toggle_comment_selection(prefix=prefix)


@register_command(name="filetype", description="Change filetype / lexer")
def filetype(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.change_lexer(args)


@register_command(name="filepath", description="Get file path (relative or absolute)")
def filepath(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:

    buffer = editor.get_current_buffer()
    abs_path = editor.send_prompt_confirm("Get absolute path? y/n")

    if (action := buf_actions.get_filepath(buffer, abs_path)) is not None:
        editor.apply_action_to_buffer(action)


@register_command("datetime", description="Insert current datetime")
def insert_datetime(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:

    for ch in str(datetime.now()):
        editor.insert_char(ch, disable_autocomplete=True)


@register_command("date", description="Insert current date")
def insert_date(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:

    for ch in str(datetime.now().date()):
        editor.insert_char(ch, disable_autocomplete=True)


@register_command("uuid", description="Insert UUID")
def insert_uuid(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:

    for ch in str(uuid.uuid4()):
        editor.insert_char(ch, disable_autocomplete=True)


@register_command(name="record_macro", description="Start/stop macro recording")
def record_macro(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.record_macro()


@register_command(name="exec_macro", description="Execute recorded macro")
def exec_macro(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.exec_macro()


@register_command(
    name="req", description="Execute HTTP request blocks from selection or buffer"
)
def http_requests(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:

    def action_function(text: str) -> None:
        if editor.tg is None:
            return None

        for block in http_request.split_requests(text):
            try:
                method, url, headers, body = http_request.parse_request_block(block)

                task_id = str(uuid.uuid4())

                task = editor.tg.create_task(
                    http_request.make_request_with_cancel_async(
                        method, url, headers, body, task_id
                    )
                )

                editor.task_running.append(
                    {
                        "task": task,
                        "type": "HTTP",
                        "task_id": task_id,
                        "method": method,
                        "url": url,
                        "headers": headers,
                        "body": body,
                    }
                )

            except Exception as e:
                editor.send_multiline_notification(
                    f"Request failed: {e}\n{traceback.format_exc()}",
                    0,
                )

    editor.apply_action_on_selection_or_file(
        action_function=action_function,
        action_title="HTTP Requests",
    )


@register_command(name="json_format", description="Format JSON (default indent=2)")
def json_format(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    try:
        indent = int(args) if args is not None else 2
    except Exception:
        indent = 2

    editor.apply_action_on_selection_or_file(
        action_function=lambda text: buf_actions.json_format(
            editor.get_current_buffer(),
            text,
            indent,
        ),
        action_title="JSON format",
    )


@register_command(
    name="rejoin", description="Rejoin lines using custom split and join separators"
)
def rejoin(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    split_by = editor.send_prompt("split by (default: newline):")
    if not split_by:
        split_by = "\n"

    join_by = buf_actions.parse_basic_escapes(
        editor.send_prompt("join by (default: newline):")
    )
    if not join_by:
        join_by = "\n"

    editor.apply_action_on_selection_or_file(
        action_function=lambda text: buf_actions.rejoin(
            editor.get_current_buffer(),
            text,
            split_by,
            join_by,
        ),
        action_title="Rejoin",
    )


@register_command(name="align", description="Align text by separator")
def align(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    separator = editor.send_prompt("align by (default: =):")
    if not separator:
        separator = "="

    add_spaces = editor.send_prompt("Add spaces around separator? (y/n, default: y):")

    _add_spaces = False if add_spaces and add_spaces.lower().startswith("n") else True

    editor.apply_action_on_selection_or_file(
        action_function=lambda text: buf_actions.align(
            editor.get_current_buffer(),
            text,
            separator,
            _add_spaces,
        ),
        action_title="Align Columns",
    )


@register_command(
    name="unique_lines", aliases=("dedup",), description="Remove duplicate lines"
)
def unique_lines(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.apply_action_on_selection_or_file(
        action_function=lambda text: buf_actions.unique_lines(
            editor.get_current_buffer(),
            text,
        ),
        action_title="Remove Duplicate Lines",
    )


@register_command(name="reverse_lines", description="Reverse lines order")
def reverse_lines(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.apply_action_on_selection_or_file(
        action_function=lambda text: buf_actions.reverse_lines(
            editor.get_current_buffer(),
            text,
        ),
        action_title="Reverse Lines",
    )


@register_command(
    name="trim",
    aliases=("trim_l", "trim_r"),
    description="Trim lines (left/right/both)",
)
def trim(editor: SimpleEditor, args: str | None = None, res: str | None = None) -> None:
    mode = res if res else "trim"

    editor.apply_action_on_selection_or_file(
        action_function=lambda text: buf_actions.trim_lines(
            editor.get_current_buffer(),
            text,
            mode,
        ),
        action_title=f"Trim ({mode})",
    )


@register_command(name="number_lines", description="Number lines with advanced options")
def number_lines(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    _start = editor.send_prompt("start from (default 1):")
    start = int(_start) if _start and _start.isdigit() else 1

    separator = editor.send_prompt("separator (default '.'):")
    if not separator:
        separator = "."

    _pad = editor.send_prompt("zero pad width (optional):")
    pad = int(_pad) if _pad and _pad.isdigit() else 0

    skip_empty = editor.send_prompt("skip empty lines? (y/N):").lower() == "y"

    editor.apply_action_on_selection_or_file(
        action_function=lambda text: buf_actions.number_lines(
            editor.get_current_buffer(),
            text,
            start,
            separator,
            pad,
            skip_empty,
        ),
        action_title="Number Lines (Advanced)",
    )


@register_command(name="remove_empty_lines", description="Remove empty lines")
def remove_empty_lines(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.apply_action_on_selection_or_file(
        action_function=lambda text: buf_actions.remove_empty_lines(
            editor.get_current_buffer(),
            text,
        ),
        action_title="Remove Empty Lines",
    )


@register_command(name="wrap", description="Wrap lines")
def wrap(editor: SimpleEditor, args: str | None = None, res: str | None = None) -> None:
    width_input = editor.send_prompt("wrap width (default 80):")
    width = int(width_input) if width_input and width_input.isdigit() else 80

    break_long_words = editor.send_prompt("break long words? (y/N):").lower() == "y"

    editor.apply_action_on_selection_or_file(
        action_function=lambda text: buf_actions.wrap(
            editor.get_current_buffer(),
            text,
            width,
            break_long_words,
        ),
        action_title="Wrap Lines (Advanced)",
    )


@register_command(name="shuffle_lines", description="Shuffle lines randomly")
def shuffle_lines(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.apply_action_on_selection_or_file(
        action_function=lambda text: buf_actions.shuffle_lines(
            editor.get_current_buffer(),
            text,
        ),
        action_title="Shuffle Lines",
    )


@register_command(name="slugify", description="Slugify text")
def slugify(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:

    editor.apply_action_on_selection_or_file(
        action_function=lambda text: buf_actions.slugify(
            editor.get_current_buffer(),
            text,
        ),
        action_title="Slugify",
    )


@register_command(
    name="column_edit",
    description="Column edit on selected lines (insert/replace/delete)",
)
def column_edit(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:

    if editor.selection_start is None:
        editor.send_notification("Column edit requires a selection.")
        return None

    _selection_start = editor.selection_start

    mode = (
        (
            editor.send_prompt("mode: insert / replace / delete (default insert):")
            or "insert"
        )
        .strip()
        .lower()
    )

    if mode not in ("insert", "replace", "delete"):
        mode = "insert"

    start_col = end_col = 0

    if mode == "insert":
        start_col = buf_actions._to_int(editor.send_prompt("column:"), 0)

    elif mode in ("replace", "delete"):
        start_col = buf_actions._to_int(editor.send_prompt("start column:"), 0)
        end_col = buf_actions._to_int(editor.send_prompt("end column:"), start_col)

    insert_text = ""

    if mode != "delete":
        insert_text = editor.send_prompt("text to insert:") or ""

    editor.apply_action_on_selection_or_file(
        action_function=lambda text: buf_actions.column_edit(
            editor.get_current_buffer(),
            text,
            mode,
            start_col,
            end_col,
            insert_text,
            _selection_start,
        ),
        action_title="Column Edit (Per Line)",
    )


@register_command(
    name="sort", aliases=("sort_r",), description="Sort lines (use sort_r for reverse)"
)
def sort_lines(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:

    reverse = False

    # If user invoked via alias "sort_r"
    if res == "sort_r":
        reverse = True

    # Or if your dispatcher passes the command name
    # you may instead inspect editor.last_command if you track it.

    editor.apply_action_on_selection_or_file(
        action_function=lambda text: buf_actions.sort_lines(
            editor.get_current_buffer(),
            text,
            reverse,
        ),
        action_title="Sort",
    )


@register_command(name="ai", description="Send instruction to AI")
def ai_instruction(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    try:
        prompt = editor.send_prompt("AI instruction:")
        if not prompt:
            return None

        buffer = editor.get_current_buffer()

        if editor.selection_start is not None:
            code_example = "\n".join(editor.get_selected_text())[:12000]

            prompt = (
                f"{prompt}\n\n"
                f"Here is the related code:\n"
                f"```\n{code_example}\n```"
            )

            editor.end_selection()

        job_id = editor.ai_completion_manager.submit(
            prompt=prompt,
            prompt_type=2,
        )

        y, x = window.get_cursor_position()

        buffer.ai_completions.append(
            diagnostics.Diagnostic(
                line=y,
                char=x,
                code=job_id,
                message="PENDING",
                severity=4,
            )
        )

    except Exception as e:
        editor.send_multiline_notification(
            f"AI request failed: {e}\n{traceback.format_exc()}",
            0,
        )


@register_command(name="ai_gen", description="Inline AI code completion")
def ai_generate(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    try:
        buffer = editor.get_current_buffer()

        MAX_TOTAL_LINES = 10000
        cursor_y = window.cursor_y
        cursor_x = window.cursor_x
        total_lines = len(buffer.lines)

        half_window = MAX_TOTAL_LINES // 2
        start_line = max(0, cursor_y - half_window)
        end_line = min(total_lines, start_line + MAX_TOTAL_LINES)
        start_line = max(0, end_line - MAX_TOTAL_LINES)

        visible_lines = buffer.lines[start_line:end_line]
        relative_cursor_y = cursor_y - start_line

        current_line = visible_lines[relative_cursor_y]
        before_cursor_line = current_line[:cursor_x]
        after_cursor_line = current_line[cursor_x:]

        before_lines = visible_lines[:relative_cursor_y]
        after_lines = visible_lines[relative_cursor_y + 1 :]

        before_cursor = "\n".join(before_lines + [before_cursor_line])
        after_cursor = "\n".join([after_cursor_line] + after_lines)

        prompt = textwrap.dedent(f"""\
        Complete the code at the marker.

        Return ONLY the missing code.
        No explanations.
        No repetition.

        {before_cursor}
        {before_cursor_line}>>> COMPLETE HERE <<<{after_cursor_line}
        {after_cursor}
        """)

        job_id = editor.ai_completion_manager.submit(
            prompt=prompt,
            prompt_type=1,
        )

        buffer.ai_completions.append(
            diagnostics.Diagnostic(
                line=window.cursor_y,
                char=window.cursor_x,
                code=job_id,
                message="PENDING",
                severity=4,
            )
        )

    except Exception as e:
        editor.send_multiline_notification(
            f"Completion failed: {e}\n{traceback.format_exc()}",
            0,
        )


@register_command(name="ai_review", description="AI review git diff")
def ai_review(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    try:
        buffer = editor.get_current_buffer()

        diff_branch = editor.send_prompt_confirm("diff branch?")
        diff_commited = False
        branch: str | None = None

        if diff_branch:
            branch = editor.send_multiline_prompt(
                multiline_message=str(git_utils.git_branches()),
                prompt_message="choose branch: ",
            )
            if not branch:
                editor.send_notification("No branch selected.")
                return None
        else:
            diff_commited = editor.send_prompt_confirm("diff commited?")
            branch = None

        lexer_name = (buffer.lexer.name if buffer.lexer else "Text").lower()

        if lexer_name == "mcs":
            exclude_patterns = ["*Designer.cs", "bin/*", "obj/*"]
        else:
            exclude_patterns = []

        if branch:
            diff_text = git_utils.get_diff(
                compare_branch=branch,
                exclude_patterns=exclude_patterns,
            )
        else:
            diff_text = git_utils.get_diff(
                staged=diff_commited,
                exclude_patterns=exclude_patterns,
            )

        if not diff_text:
            editor.send_notification("No diff output.")
            return None

        prompt = textwrap.dedent(f"""\
        You are an automated code review engine.
        Review ONLY the provided git diff.
        Output STRICT JSON only.
        Return only JSON.

        Diff:
        {diff_text}
        """)

        job_id = editor.ai_completion_manager.submit(
            prompt=prompt,
            prompt_type=3,
        )

        buffer.ai_completions.append(
            diagnostics.Diagnostic(
                line=window.cursor_y,
                char=window.cursor_x,
                code=job_id,
                message="PENDING",
                severity=4,
            )
        )

    except Exception as e:
        editor.send_multiline_notification(
            f"Review failed: {e}\n{traceback.format_exc()}",
            0,
        )


@register_command(name="ai_commit_message", description="Generate commit message")
def ai_commit_message(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    try:
        buffer = editor.get_current_buffer()

        diff_branch = editor.send_prompt_confirm("diff branch?")
        diff_commited = False
        branch: str | None = None

        if diff_branch:
            branch = editor.send_multiline_prompt(
                multiline_message=str(git_utils.git_branches()),
                prompt_message="choose branch: ",
            )
            if not branch:
                editor.send_notification("No branch selected.")
                return None
        else:
            diff_commited = editor.send_prompt_confirm("diff commited?")
            branch = None

        lexer_name = (buffer.lexer.name if buffer.lexer else "Text").lower()

        if lexer_name == "mcs":
            exclude_patterns = ["*Designer.cs", "bin/*", "obj/*"]
        else:
            exclude_patterns = []

        if branch:
            diff_text = git_utils.get_diff(
                compare_branch=branch,
                exclude_patterns=exclude_patterns,
            )
        else:
            diff_text = git_utils.get_diff(
                staged=diff_commited,
                exclude_patterns=exclude_patterns,
            )

        if not diff_text:
            editor.send_notification("No diff output.")
            return None

        prompt = textwrap.dedent(f"""\
        Write a detailed Git commit message based on the following diff.

        Diff:
        {diff_text}
        """)

        job_id = editor.ai_completion_manager.submit(
            prompt=prompt,
            prompt_type=4,
        )

        buffer.ai_completions.append(
            diagnostics.Diagnostic(
                line=window.cursor_y,
                char=window.cursor_x,
                code=job_id,
                message="PENDING",
                severity=4,
            )
        )

    except Exception as e:
        editor.send_multiline_notification(
            f"Commit message failed: {e}\n{traceback.format_exc()}",
            0,
        )


@register_command(name="ai_get", description="Get AI completion result")
def ai_get(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    try:
        buffer = editor.get_current_buffer()
        codes_consumed = []

        for i, c in enumerate(buffer.ai_completions):
            if c.line == window.cursor_y and c.message == "COMPLETED":
                output = editor.ai_completion_manager.get_result(c.code)

                if output:
                    output = output.strip("\n")

                    editor.open_file_in_less_mode(
                        file_handle=StringIO(output),
                    )

            elif c.message == "CANCELED":
                codes_consumed.append(i)

        for i in sorted(codes_consumed, reverse=True):
            buffer.ai_completions.pop(i)

    except Exception as e:
        editor.send_multiline_notification(
            f"Completion failed: {e}\n{traceback.format_exc()}",
            0,
        )


@register_command(name="ai_show", description="Show AI completion picker")
def ai_show(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    try:
        editor.show_ai_completion_picker()
    except Exception as e:
        editor.send_multiline_notification(
            f"Completion failed: {e}\n{traceback.format_exc()}",
            0,
        )


@register_command(name="ai_remove", description="Cancel AI completions at cursor")
def ai_remove(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    try:
        buffer = editor.get_current_buffer()
        codes_consumed = []

        for i, c in enumerate(buffer.ai_completions):
            if c.line == window.cursor_y:
                editor.ai_completion_manager.cancel(c.code)
                codes_consumed.append(i)

        for i in sorted(codes_consumed, reverse=True):
            buffer.ai_completions.pop(i)

    except Exception as e:
        editor.send_multiline_notification(
            f"Completion failed: {e}\n{traceback.format_exc()}",
            0,
        )


@register_command(name="lazygit", aliases=("gg",), description="Open lazygit TUI")
def cmd_lazygit(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:

    if shutil.which("lazygit"):
        buffer = editor.get_current_buffer()

        external_tui.run_external_tui(
            editor=editor,
            command=["lazygit"],
        )

        # Refresh git changes if configured
        if config.STATIC_CONFIG.get("gch", False) and buffer.file_name:
            buffer.git_changes = git_utils.get_file_changes(buffer.file_name)
    else:
        editor.send_notification("Could not find lazygit executable.")


@register_command(name="fzf", description="Search files using fzf")
def cmd_fzf(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:

    selected = editor.fzf_tui_search()

    if not selected:
        return None

    root = os.getcwd()
    full_path = os.path.abspath(os.path.join(root, selected))
    cwd = os.getcwd()
    rel = os.path.relpath(full_path, cwd)

    # Try switching to already-open buffer
    for buffer_index, buf in enumerate(editor.buffers):
        if buf.file_name and buf.file_name == rel:
            editor.set_current_buffer(buffer_index)
            editor.send_notification(f"Switched to buffer: {selected}")
            break
    else:
        editor.open_buffer(rel)
        editor.send_notification(f"Opened file: {selected}")


@register_command(
    name="eval", description="Evaluate Python code from selection or prompt"
)
def cmd_eval(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    try:
        if editor.selection_start is not None:
            code = "\n".join(editor.get_selected_text())
        else:
            code = editor.send_prompt(
                "code:",
                history=editor.eval_history,
            )

        editor.end_selection()

        if not code:
            return None

        editor.eval_history.append(code)

        _output = editor.run_code_with_eval(code)
        if _output is None:
            return None

        result, stdout = _output

        output = "\n" + "\n".join(str(i) for i in _output) + "\n"

        editor.open_file_in_less_mode(
            file_handle=StringIO(output),
        )

    except Exception as e:
        editor.send_multiline_notification(
            f"Eval failed: {e}\n{traceback.format_exc()}",
            0,
        )


@register_command(name="paste_sys", description="Paste from system clipboard")
def cmd_paste_sys(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.paste_from_system_clipboard()


@register_command(name="lsp_hover", description="Show LSP hover information")
def cmd_lsp_hover(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.lsp_hover()


@register_command(name="lsp_definition", description="Go to definition")
def cmd_lsp_definition(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.lsp_definition()


@register_command(name="lsp_diagnostics", description="Show all LSP diagnostics")
def cmd_lsp_diagnostics(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    buffer = editor.get_current_buffer()
    diags = getattr(buffer, "diagnostics", [])

    if not diags:
        editor.send_notification("No diagnostics.")
        return None

    editor.show_all_lsp_diagnostics()


@register_command(name="lsp_refresh", description="Refresh LSP diagnostics")
def cmd_lsp_refresh(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.lsp_refresh()


@register_command(name="lsp_references", description="Find references")
def cmd_lsp_references(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.lsp_references()


@register_command(name="lsp_code_action", description="Show available code actions")
def cmd_lsp_code_action(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.lsp_code_action()


@register_command(
    name="lsp_line_diagnostics", description="Show diagnostics for current line"
)
def cmd_lsp_line_diagnostics(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    editor.show_line_diagnostics()


@register_command(name="lsp_clear_diagnostics", description="Clear all LSP diagnostics")
def cmd_lsp_clear_diagnostics(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    buffer = editor.get_current_buffer()
    buffer.diagnostics.clear()


@register_command(
    name="lsp_clear_line_diag",
    aliases=("clrld",),
    description="Clear diagnostics for current line",
)
def cmd_lsp_clear_line_diag(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    buffer = editor.get_current_buffer()

    buffer.diagnostics = [d for d in buffer.diagnostics if d.line != window.cursor_y]


def _ensure_git_repo(editor: SimpleEditor) -> bool:
    if not git_utils.is_inside_git_repo():
        editor.send_notification("Not inside a Git repository.")
        return False
    return True


@register_command(name="git_status", description="Show git status")
def cmd_git_status(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    if not _ensure_git_repo(editor):
        return None

    status = git_utils.get_status()
    if status:
        editor.open_file_in_less_mode(
            file_handle=StringIO(status),
        )


@register_command(name="git_diff", description="Show git diff for file")
def cmd_git_diff(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    if not _ensure_git_repo(editor):
        return None

    buffer = editor.get_current_buffer()

    file_path = args

    if not file_path:
        if not buffer.file_name and not buffer.is_aux_buffer:
            editor.send_notification("No file to show diff for.")
            return None
        file_path = buffer.file_name

    diff = git_utils.get_diff(file_path)

    if diff:
        editor.open_aux_buffer(diff, "__git_diff__", lexer=DiffLexer())
    else:
        editor.send_notification("No changes to show.")


@register_command(name="git_commit_all", description="Commit all staged changes")
def cmd_git_commit_all(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    if not _ensure_git_repo(editor):
        return None

    buffer = editor.get_current_buffer()
    message = editor.send_prompt("Commit message: ")

    if not message:
        editor.send_notification("Commit aborted.")
        return None

    try:
        git_utils.commit_all(message)

        if config.STATIC_CONFIG.get("gch", False) and buffer.file_name:
            buffer.git_changes = git_utils.get_file_changes(buffer.file_name)

        editor.send_notification("Changes committed successfully.")

    except Exception as e:
        editor.send_notification(f"Error committing changes: {e}")


@register_command(name="git_blame", description="Show blame for current line")
def cmd_git_blame(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    if not _ensure_git_repo(editor):
        return None

    buffer = editor.get_current_buffer()

    if not buffer.file_name and not buffer.is_aux_buffer:
        editor.send_notification("No file to show blame for.")
        return None

    try:
        blame = git_utils.get_blame_line(
            buffer.file_name,
            window.cursor_y + 1,
        )

        if blame:
            editor.send_notification(f"Blame: {blame}", 0)

    except Exception as e:
        editor.send_notification(f"Error getting blame: {e}")


@register_command(name="git_hunk", description="Show git hunk for current line")
def cmd_git_hunk(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    if not _ensure_git_repo(editor):
        return None

    buffer = editor.get_current_buffer()

    if not buffer.file_name and not buffer.is_aux_buffer:
        editor.send_notification("No file to show hunk for.")
        return None

    try:
        if buffer.file_name and (
            hunk := git_utils.find_previous_hunk_for_line(
                buffer.file_name,
                window.cursor_y + 1,
            )
        ):
            lines = "\n".join(hunk["lines"])

            editor.open_file_in_less_mode(
                file_handle=StringIO(f"Hunk at line {window.cursor_y + 1}:\n{lines}"),
            )
        else:
            editor.send_notification("No hunk found at this line.")

    except Exception as e:
        editor.send_notification(f"Error getting hunk: {e}")


@register_command(name="git_log", description="Show git log")
def cmd_git_log(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    if not _ensure_git_repo(editor):
        return None

    try:
        log = git_utils.get_log()

        editor.open_file_in_less_mode(
            file_handle=StringIO(log),
        )

    except Exception as e:
        editor.send_notification(f"Error getting log: {e}")


@register_command(
    name="git_refresh", description="Refresh git changes for current buffer"
)
def cmd_git_refresh(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    if not _ensure_git_repo(editor):
        return None

    buffer = editor.get_current_buffer()

    if not buffer.file_name and not buffer.is_aux_buffer:
        editor.send_notification("No file to refresh.")
        return None

    try:
        if config.STATIC_CONFIG.get("gch", False) and buffer.file_name:
            buffer.git_changes = git_utils.get_file_changes(buffer.file_name)

        editor.send_notification("Buffer refreshed with Git changes.")

    except Exception as e:
        editor.send_notification(f"Error refreshing buffer: {e}")


@register_command(
    name="upper",
    aliases=("lower", "capitalize"),
    description="Change selection case (upper/lower/capitalize)",
)
def cmd_change_case(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    """
    Changes case of current selection.
    The invoked command name determines the mode.
    """

    # If your dispatcher passes the resolved command name,
    # use that instead of args.
    mode = res if res in ("upper", "lower", "capitalize") else None

    if mode is None:
        # Fallback if dispatcher does not pass alias name
        editor.send_notification("Invalid case mode.")
        return None

    editor.change_selection_case(mode=mode)


@register_command(name="!", description="Excecutes a command as a subprocess task.")
def excecute_subprocess_task(
    editor: SimpleEditor, args: str | None = None, res: str | None = None
) -> None:
    if args is None:
        return None

    res = args

    buffer = editor.get_current_buffer()

    if res in editor.command_history:
        editor.command_history.remove(res)

    editor.command_history.append(res)

    command = res[1:].strip()
    CEP = False
    if command:
        try:
            original_command = command
            if "$CEP" in command:
                CEP = True
                command = command.replace("$CEP", "").strip()

            if "$SEL" in command:
                selected_text = ""

                if editor.selection_start is not None:
                    selected_text = "\n".join(editor.get_selected_text())

                command = command.replace("$SEL", selected_text)

            if "$SBUF" in command:
                if editor.selection_start is not None:
                    selected_text = "\n".join(editor.get_selected_text())

                    command = command.replace("$SBUF", selected_text)
                else:
                    command = command.replace("$SBUF", "\n".join(buffer.get_lines()))

            command = command.replace("$PWD", str(Path(".").absolute()))
            command = command.replace("$HOME", str(Path.home()))
            command = command.replace("$BUF", "\n".join(buffer.get_lines()))

            if buffer.file_name:
                command = command.replace("%f", buffer.file_name)
                command = command.replace("%F", str(Path(buffer.file_name).absolute()))

            if editor.tg is not None:
                task_id = str(uuid.uuid4())
                _task = editor.tg.create_task(
                    subprocess_task.run_with_cancel_async(
                        command=command, task_id=task_id
                    )
                )
                editor.task_running.append(
                    {
                        "task": _task,
                        "type": "SUBPROCESS",
                        "command": command,
                        "cep": CEP,
                        "task_id": task_id,
                        "status": "PENDING",
                    }
                )

        except Exception as e:
            editor.send_multiline_notification(
                f"Command failed: {e} \n{traceback.format_exc()}", 0
            )

            with open("errors.pytb", "a") as f:
                f.write(f"\n\n{e}\n{traceback.format_exc()}\n")

    else:
        editor.send_notification("No command provided.")

    editor.end_selection()

    return None


def _parse_split_percentage(
    editor: SimpleEditor,
    args: str | None,
    command_name: str,
) -> int | None:
    """
    Parse optional split percentage.

    Usage:
        :vsplit
        :vsplit 50
        :vsplit 30
    """

    if not args or not args.strip():
        return 50

    raw = args.strip()

    try:
        percentage = int(raw)
    except ValueError:
        editor.send_notification(f"{command_name}: percentage must be a number.")
        return None

    if percentage <= 0 or percentage >= 100:
        editor.send_notification(
            f"{command_name}: percentage must be between 1 and 99."
        )
        return None

    return percentage


def _get_window_manager(editor: SimpleEditor):
    manager = getattr(editor, "window_manager", None)

    if manager is None:
        editor.send_notification("No window manager available.")
        return None

    return manager


@register_command(
    name="vsplit",
    aliases=("vs",),
    description="Split current editor window vertically into left/right panes.",
)
def split_window_vertical(
    editor: SimpleEditor,
    args: str | None = None,
    res: str | None = None,
) -> None:
    manager = _get_window_manager(editor)

    if manager is None:
        return None

    percentage = _parse_split_percentage(editor, args, "vsplit")

    if percentage is None:
        return None

    new_window = manager.split_active_vertical(percentage)

    if new_window is None:
        editor.send_notification("Could not split current window vertically.")
        return None


@register_command(
    name="hsplit",
    aliases=("sp", "split"),
    description="Split current editor window horizontally into top/bottom panes.",
)
def split_window_horizontal(
    editor: SimpleEditor,
    args: str | None = None,
    res: str | None = None,
) -> None:
    manager = _get_window_manager(editor)

    if manager is None:
        return None

    percentage = _parse_split_percentage(editor, args, "hsplit")

    if percentage is None:
        return None

    new_window = manager.split_active_horizontal(percentage)

    if new_window is None:
        editor.send_notification("Could not split current window horizontally.")
        return None


@register_command(
    name="wincycle",
    aliases=("wn", "winnext"),
    description="Move focus to the next editor window.",
)
def window_focus_next(
    editor: SimpleEditor,
    args: str | None = None,
    res: str | None = None,
) -> None:
    manager = _get_window_manager(editor)

    if manager is None:
        return None

    manager.focus_next_base()


@register_command(
    name="winprev",
    aliases=("wp",),
    description="Move focus to the previous editor window.",
)
def window_focus_previous(
    editor: SimpleEditor,
    args: str | None = None,
    res: str | None = None,
) -> None:
    manager = _get_window_manager(editor)

    if manager is None:
        return None

    manager.focus_previous_base()


@register_command(
    name="winclose",
    aliases=("wc",),
    description="Close the focused editor window.",
)
def window_close(
    editor: SimpleEditor,
    args: str | None = None,
    res: str | None = None,
) -> None:
    manager = _get_window_manager(editor)

    if manager is None:
        return None

    # focused = getattr(manager, "focused", None)
    focused = manager.last_base_focused

    if focused is None:
        editor.send_notification("No focused window.")
        return None

    base_windows = getattr(manager, "base_windows", [])

    if focused not in base_windows:
        editor.send_notification("Focused window is not an editor window.")
        return None

    if len(base_windows) <= 1:
        editor.send_notification("Cannot close the last editor window.")
        return None

    manager.remove_window(focused)


@register_command(
    name="serialize_layout",
    description="help fuction that serializes the current window manager layout",
)
def serialize_layout(
    editor: SimpleEditor,
    args: str | None = None,
    res: str | None = None,
) -> None:
    manager = _get_window_manager(editor)

    if manager is None:
        return None

    editor.open_untitled_buffer(json.dumps(session.serialize_layout(manager.layout)))


def _parse_resize_amount(
    editor: SimpleEditor,
    args: str | None,
    command_name: str,
    default: int = 5,
) -> int | None:
    """
    Parse resize amount.

    Usage:
        :wingrow
            prompts for amount

        :wingrow 10
            uses 10 directly

        :winshrink
            prompts for amount

        :winshrink 3
            uses 3 directly
    """

    if args and args.strip():
        raw = args.strip()
    else:
        raw = editor.send_prompt(f"{command_name} amount (default {default}): ")

        if not raw or not raw.strip():
            return default

        raw = raw.strip()

    try:
        amount = int(raw)
    except ValueError:
        editor.send_notification(f"{command_name}: amount must be a number.")
        return None

    if amount <= 0:
        editor.send_notification(f"{command_name}: amount must be greater than 0.")
        return None

    return amount


@register_command(
    name="wingrow",
    aliases=("wg", "resizegrow"),
    description="Grow the last focused editor window split.",
)
def window_grow(
    editor: SimpleEditor,
    args: str | None = None,
    res: str | None = None,
) -> None:
    manager = _get_window_manager(editor)

    if manager is None:
        return None

    amount = _parse_resize_amount(editor, args, "wingrow")

    if amount is None:
        return None

    if not manager.grow_last_base_window(amount):
        editor.send_notification("Could not grow current window.")


@register_command(
    name="winshrink",
    aliases=("ws", "resizeshrink"),
    description="Shrink the last focused editor window split.",
)
def window_shrink(
    editor: SimpleEditor,
    args: str | None = None,
    res: str | None = None,
) -> None:
    manager = _get_window_manager(editor)

    if manager is None:
        return None

    amount = _parse_resize_amount(editor, args, "winshrink")

    if amount is None:
        return None

    if not manager.shrink_last_base_window(amount):
        editor.send_notification("Could not shrink current window.")
