from __future__ import annotations

import curses
import os
import traceback
from io import BytesIO, StringIO
from typing import IO, TYPE_CHECKING, AnyStr, Iterator, Optional

from denary import events
from denary.buf import CursorPosition
from denary.prompts import send_prompt
from denary.windows import Rect, WindowManager

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


class LessWindow:
    rect: Rect

    def __init__(
        self,
        manager: WindowManager,
        parent_window: curses.window,
        file_handle: StringIO | BytesIO,
        *,
        editor: Optional[SimpleEditor] = None,
        cursor_pos: Optional[CursorPosition] = None,
        show_paste_menu: bool = True,
    ):
        self.manager = manager
        self.parent_window = parent_window
        self.rect = Rect(0, 0, 0, 0)

        if isinstance(file_handle, StringIO):
            self.file_handle = BytesIO(file_handle.getvalue().encode("utf-8"))
        else:
            self.file_handle = file_handle

        self.editor = editor
        self.cursor_pos = cursor_pos
        self.show_paste_menu = show_paste_menu

        # ==========================================================
        # Macro shortcut
        # ==========================================================

        if (
            self.editor is not None
            and self.editor.current_macro_playing_index is not None
            and self.editor.current_macro_playing_name is not None
        ):
            self.editor.current_macro_playing_index += 1
            self._cancelled = True
            return

        self._cancelled = False

        # ==========================================================
        # Geometry
        # ==========================================================

        height, width = self.parent_window.getmaxyx()

        if self.cursor_pos is None:
            cursor_y, cursor_x = self.parent_window.getyx()
        else:
            cursor_y, cursor_x = self.cursor_pos

        self.height = height
        self.width = width

        self.WINDOW_SIZE = max(height * 3, 2000)

        # ==========================================================
        # File state
        # ==========================================================

        self.file_offsets: list[int] = []
        self.line_count = 0
        self.eof = False
        self.stream_pos = self.file_handle.tell()

        self._window: list[str] = []
        self.window_start = 0

        self.scroll_line = 0
        self.h_scroll = 0

        # ==========================================================
        # Search
        # ==========================================================

        self.last_search: str | None = None
        self.last_search_lower: str | None = None
        self.last_search_results: list[tuple[int, int]] = []
        self.last_search_index = 0

        # ==========================================================
        # Style
        # ==========================================================

        self.highlight_attr = curses.A_REVERSE | curses.A_BOLD
        self.normal_attr = curses.A_NORMAL

        # ==========================================================
        # Initial content
        # ==========================================================

        self.ensure_window_for(0)

        max_line_len = max((len(line) for line in self._window), default=1)

        self.win_height = min(height - 2, len(self._window) + 2)
        self.win_width = min(width - 1, max_line_len + 2)

        start_y = cursor_y + 1
        start_x = cursor_x

        if start_y + self.win_height > height:
            start_y = max(0, cursor_y - self.win_height)

        if start_x + self.win_width > width:
            start_x = max(0, width - self.win_width)

        self.start_y = start_y
        self.start_x = start_x

        self.max_visible = self.win_height - 2

        self.win: Optional[curses.window] = None

    # ==========================================================
    # Lifecycle
    # ==========================================================

    def set_rect(self, rect: Rect) -> None:
        pass

    def on_mount(self) -> None:
        if self._cancelled:
            self.close()
            return

        self.win = curses.newwin(
            self.win_height,
            self.win_width,
            self.start_y,
            self.start_x,
        )

        self.win.keypad(True)
        self.win.nodelay(True)

        curses.curs_set(0)

    def on_unmount(self) -> None:
        curses.flushinp()

        if self.win:
            self.win.clear()
            self.win.refresh()

        # if self.editor is not None:
        #     self.editor.draw()

    def on_focus(self) -> None:
        pass

    def on_blur(self) -> None:
        pass

    def close(self) -> None:
        try:
            if self.editor is None or not self.show_paste_menu:
                return None

            output = None

            size = self.file_handle.seek(0, os.SEEK_END)

            self.file_handle.seek(0)

            if size >= 500_000:
                if not self.editor.send_prompt_confirm(
                    f"Output is very large ({size:,} bytes). continue?",
                    color_p=15,
                ):
                    return None

            if self.editor.send_prompt_confirm(
                f"Do you want to open the output ({size} bytes) in a new buffer?"
            ):
                output = self.file_handle.read().decode("utf-8", "replace").strip()
                self.editor.open_untitled_buffer(output)

            elif self.editor.send_prompt_confirm(
                f"Do you want to paste the output ({size} bytes) into the current buffer?"
            ):
                if not output:
                    output = (
                        "\n"
                        + self.file_handle.read().decode("utf-8", "replace").strip()
                        + "\n"
                    )
                    output = output.replace("\r\n", "\n").replace("\r", "\n")
                    output = output.expandtabs()
                    output = output.replace("\x00", "�")

                self.editor.insert_char(output, disable_autocomplete=True)

        except Exception:
            if self.editor is not None:
                self.editor.send_notification(traceback.format_exc())

        finally:
            self.file_handle.close()
            self.manager.remove_window(self)

    # ==========================================================
    # File helpers
    # ==========================================================

    def safe_decode(self, line):
        if isinstance(line, str):
            return line.replace("\x00", "�")

        for enc in ("utf-8", "latin1"):
            try:
                return line.decode(enc).replace("\x00", "�")
            except Exception:
                pass

        return line.decode("utf-8", errors="replace").replace("\x00", "�")

    def read_next_line(self) -> bool:
        if self.eof:
            return False

        self.file_handle.seek(self.stream_pos)

        offset = self.stream_pos
        raw = self.file_handle.readline()

        if not raw:
            self.eof = True
            return False

        text = self.safe_decode(raw).rstrip("\n")

        self.file_offsets.append(offset)
        self.line_count += 1
        self.stream_pos = self.file_handle.tell()

        return True

    def ensure_lines_up_to(self, target_line: int):
        if target_line < 0:
            return

        while not self.eof and self.line_count <= target_line:
            if not self.read_next_line():
                break

    def ensure_window_for(self, top_line: int):
        if self.line_count == 0 and not self.eof:
            self.read_next_line()

        self.ensure_lines_up_to(top_line + self.height)

        if self.line_count == 0:
            self._window = []
            self.window_start = 0
            self.scroll_line = 0
            return

        max_scroll = max(0, self.line_count - 1)

        if top_line > max_scroll:
            top_line = max_scroll

        if self._window and self.window_start <= top_line < self.window_start + len(
            self._window
        ):
            end_needed = top_line + (self.height - 2)

            if end_needed <= self.window_start + len(self._window):
                self.scroll_line = top_line
                return

        self._window = []
        self.window_start = top_line

        saved = self.file_handle.tell()

        self.file_handle.seek(self.file_offsets[top_line])

        limit = min(
            self.line_count,
            top_line + self.WINDOW_SIZE,
        )

        for _line_idx in range(top_line, limit):
            raw = self.file_handle.readline()

            if not raw:
                break

            text = self.safe_decode(raw).rstrip("\n")
            self._window.append(text)

        self.file_handle.seek(saved)

        self.scroll_line = top_line

    def get_line(self, idx: int) -> str:
        if idx < 0 or idx >= self.line_count:
            return ""

        if self.window_start <= idx < self.window_start + len(self._window):
            return self._window[idx - self.window_start]

        saved = self.file_handle.tell()

        self.file_handle.seek(self.file_offsets[idx])

        raw = self.file_handle.readline()

        self.file_handle.seek(saved)

        return self.safe_decode(raw).rstrip("\n") if raw else ""

    # ==========================================================
    # Search
    # ==========================================================

    def compute_max_hscroll(self) -> int:
        if not self._window:
            return 0

        m = max((len(l) for l in self._window), default=0)

        return max(0, m - (self.win_width - 2))

    def center_horizontally_on_match(self, hit):
        max_h = self.compute_max_hscroll()

        if max_h <= 0:
            self.h_scroll = 0
            return

        ideal = hit - (self.win_width // 2)

        ideal = max(0, min(ideal, max_h))

        self.h_scroll = ideal

    def perform_search(
        self,
        pattern: str,
    ) -> list[tuple[int, int]]:
        self.last_search = pattern
        self.last_search_lower = pattern.lower()

        res: list[tuple[int, int]] = []

        if self.line_count > 0:
            saved = self.file_handle.tell()

            for idx in range(self.line_count):
                self.file_handle.seek(self.file_offsets[idx])

                raw = self.file_handle.readline()

                if not raw:
                    break

                text = self.safe_decode(raw).rstrip("\n")
                lo = text.lower()

                start = 0

                while True:
                    hit = lo.find(self.last_search_lower, start)

                    if hit == -1:
                        break

                    res.append((idx, hit))

                    start = hit + 1

            self.file_handle.seek(saved)

        if not self.eof:
            while not self.eof:
                if not self.read_next_line():
                    break

                idx = self.line_count - 1

                text = self.get_line(idx)
                lo = text.lower()

                start = 0

                while True:
                    hit = lo.find(self.last_search_lower, start)

                    if hit == -1:
                        break

                    res.append((idx, hit))

                    start = hit + 1

        return res

    def jump_to_search_index(self, i):
        if not self.last_search_results:
            return

        i = i % len(self.last_search_results)

        target_line, target_col = self.last_search_results[i]

        self.ensure_window_for(target_line)

        self.scroll_line = target_line

        self.center_horizontally_on_match(target_col)

    # ==========================================================
    # Event handling
    # ==========================================================

    def handle_event(self, event: events.Event) -> bool:
        if self.win is None:
            # self._finish(None)
            self.close()
            return False

        if event.type != events.EventType.KEY:
            return False

        key = event.data

        max_scroll = max(0, self.line_count - 1)

        # Close
        if key in ("Enter", 10, 13, "Ctrl+J", "Ctrl+M", "ESC", 27, "q"):
            self.close()

        # Down
        elif key in ("Down", "j"):
            if self.scroll_line < max_scroll or not self.eof:
                self.scroll_line += 1

        # Up
        elif key in ("Up", "k"):
            if self.scroll_line > 0:
                self.scroll_line -= 1

        # Page down
        elif key in ("PageDown", " ", "Ctrl+F"):
            self.scroll_line += self.max_visible
            self.ensure_lines_up_to(self.scroll_line + self.max_visible)

        # Page up
        elif key in ("PageUp", "b", "Ctrl+B"):
            self.scroll_line = max(
                self.scroll_line - self.max_visible,
                0,
            )

        # Right scroll
        elif key in ("Right", "l"):
            self.h_scroll += 4

        # Go line start (horizontal)
        elif key == "0":
            self.h_scroll = 0

        # Go line end (horizontal)
        elif key == "$":
            self.h_scroll = self.compute_max_hscroll()

        # Left scroll
        elif key in ("Left", "h"):
            self.h_scroll -= 4

        # Go to file start
        elif key == "g":
            self.scroll_line = 0

        # Go to file end
        elif key == "G":
            while not self.eof:
                self.read_next_line()

            self.scroll_line = max(0, self.line_count - 1)

        # Search
        elif key == "/":
            if self.editor is not None:
                pat = self.editor.send_prompt(prompt_message="/")

                if pat:
                    self.last_search_results = self.perform_search(pat)
                    self.last_search_index = 0

                    if self.last_search_results:
                        self.jump_to_search_index(0)

        # Next search
        elif key == "n":
            if self.last_search_results:
                self.last_search_index += 1
                self.jump_to_search_index(self.last_search_index)

        # Previous search
        elif key == "N":
            if self.last_search_results:
                self.last_search_index -= 1
                self.jump_to_search_index(self.last_search_index)

        return True

    # ==========================================================
    # Rendering
    # ==========================================================

    def render(self) -> None:
        if self.win is None:
            return

        self.ensure_window_for(self.scroll_line)

        self.win.erase()
        self.win.box()

        max_scroll = max(0, self.line_count - 1)

        if self.scroll_line < 0:
            self.scroll_line = 0
        elif self.scroll_line > max_scroll:
            self.scroll_line = max_scroll

        max_h = self.compute_max_hscroll()

        if self.h_scroll < 0:
            self.h_scroll = 0
        elif self.h_scroll > max_h:
            self.h_scroll = max_h

        pat = self.last_search_lower
        plen = len(pat) if pat else 0

        for row in range(self.max_visible):
            idx = self.scroll_line + row

            if idx >= self.line_count:
                break

            text = self.get_line(idx)

            segment = text[self.h_scroll : self.h_scroll + (self.win_width - 2)]

            if pat and plen > 0:
                lo = text.lower()

                seg_lower = lo[self.h_scroll : self.h_scroll + (self.win_width - 2)]

                col = 1
                i = 0

                while i < len(seg_lower):
                    hit = seg_lower.find(pat, i)

                    if hit == -1:
                        try:
                            self.win.addstr(
                                row + 1,
                                col + i,
                                segment[i:],
                                self.normal_attr,
                            )
                        except curses.error:
                            pass

                        break

                    if hit > i:
                        pre = segment[i:hit]

                        try:
                            self.win.addstr(
                                row + 1,
                                col + i,
                                pre,
                                self.normal_attr,
                            )
                        except curses.error:
                            pass

                    hit_end = hit + plen

                    highlight = segment[hit:hit_end]

                    try:
                        self.win.addstr(
                            row + 1,
                            col + hit,
                            highlight,
                            self.highlight_attr,
                        )
                    except curses.error:
                        pass

                    i = hit_end

            else:
                try:
                    self.win.addstr(
                        row + 1,
                        1,
                        segment,
                        self.normal_attr,
                    )
                except curses.error:
                    pass

        border_y = self.win_height - 1

        if self.scroll_line == 0:
            marker = "[TOP]"
        elif self.eof and self.scroll_line >= max_scroll:
            marker = "[END]"
        else:
            marker = "[More]"

        search_tag = " (search)" if self.last_search else ""

        status = f"{marker} q to quit{search_tag}"

        msg = f" {status} "
        msg = msg[: self.win_width - 2]

        try:
            self.win.addstr(border_y, 1, msg)
        except curses.error:
            pass

        self.win.noutrefresh()
