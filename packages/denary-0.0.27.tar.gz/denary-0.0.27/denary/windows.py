from __future__ import annotations

import curses
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol, Sequence, runtime_checkable

from denary import config, git_utils
from denary.buf import Buffer, CursorPosition, RichString, get_lsp, get_uri_from_name
from denary.events import Event, EventType
from denary.renderer import draw

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


# ==========================================================
# Geometry
# ==========================================================


@dataclass(slots=True, frozen=True)
class Rect:
    x: int
    y: int
    width: int
    height: int

    @property
    def right(self) -> int:
        return self.x + self.width

    @property
    def bottom(self) -> int:
        return self.y + self.height

    @property
    def is_empty(self) -> bool:
        return self.width <= 0 or self.height <= 0

    def clamped(self) -> "Rect":
        return Rect(
            x=max(0, self.x),
            y=max(0, self.y),
            width=max(0, self.width),
            height=max(0, self.height),
        )


# ==========================================================
# Window Protocol
# ==========================================================


@runtime_checkable
class Window(Protocol):
    manager: "WindowManager"
    rect: Rect

    def on_mount(self) -> None: ...
    def on_unmount(self) -> None: ...
    def on_focus(self) -> None: ...
    def on_blur(self) -> None: ...

    def set_rect(self, rect: Rect) -> None: ...

    def handle_event(self, event: Any) -> bool:
        """
        Return True if handled.
        Return False to allow bubbling.
        """
        ...

    def render(self) -> None: ...
    def close(self) -> None: ...


# ==========================================================
# Split Layout API
# ==========================================================


class LayoutNode(Protocol):
    def apply(self, rect: Rect) -> None: ...
    def windows(self) -> list[Window]: ...
    def resize_window(self, target_window: Window, delta: int) -> bool: ...


class WindowNode:
    """
    Leaf node in the layout tree.
    Wraps a real window.
    """

    def __init__(self, window: Window):
        self.window = window

    def apply(self, rect: Rect) -> None:
        self.window.set_rect(rect.clamped())

    def windows(self) -> list[Window]:
        return [self.window]

    def resize_window(self, target_window: Window, delta: int) -> bool:
        # A leaf cannot resize itself. The parent split owns the percentage.
        return False


class HorizontalSplit:
    """
    Splits the available area into LEFT / RIGHT panes.

    percentage = percentage of width used by the LEFT pane.

    Example:
        HorizontalSplit(30, WindowNode(left), WindowNode(right))

    Result:
        left  = 30%
        right = 70%
    """

    def __init__(
        self,
        percentage: int,
        left: LayoutNode,
        right: LayoutNode,
        min_left_width: int = 1,
        min_right_width: int = 1,
    ):
        if percentage <= 0 or percentage >= 100:
            raise ValueError("percentage must be between 1 and 99")

        self.percentage = percentage
        self.left = left
        self.right = right
        self.min_left_width = max(0, min_left_width)
        self.min_right_width = max(0, min_right_width)

    def apply(self, rect: Rect) -> None:
        rect = rect.clamped()

        if rect.is_empty:
            self.left.apply(Rect(rect.x, rect.y, 0, 0))
            self.right.apply(Rect(rect.x, rect.y, 0, 0))
            return

        left_width = rect.width * self.percentage // 100
        right_width = rect.width - left_width

        total_min = self.min_left_width + self.min_right_width

        if rect.width >= total_min:
            if left_width < self.min_left_width:
                left_width = self.min_left_width
                right_width = rect.width - left_width

            if right_width < self.min_right_width:
                right_width = self.min_right_width
                left_width = rect.width - right_width
        else:
            left_width = max(0, min(rect.width, left_width))
            right_width = max(0, rect.width - left_width)

        left_width = max(0, min(left_width, rect.width))
        right_width = max(0, rect.width - left_width)

        left_rect = Rect(
            x=rect.x,
            y=rect.y,
            width=left_width,
            height=rect.height,
        )

        right_rect = Rect(
            x=rect.x + left_width,
            y=rect.y,
            width=right_width,
            height=rect.height,
        )

        self.left.apply(left_rect)
        self.right.apply(right_rect)

    def windows(self) -> list[Window]:
        return self.left.windows() + self.right.windows()

    def resize_window(self, target_window: Window, delta: int) -> bool:
        """
        Resize the nearest split around target_window.

        Positive delta means: make target_window bigger.
        Negative delta means: make target_window smaller.

        This is child-first, so nested splits resize before outer splits.
        """

        if self.left.resize_window(target_window, delta):
            return True

        if self.right.resize_window(target_window, delta):
            return True

        if target_window in self.left.windows():
            self.percentage = max(1, min(99, self.percentage + delta))
            return True

        if target_window in self.right.windows():
            self.percentage = max(1, min(99, self.percentage - delta))
            return True

        return False


class VerticalSplit:
    """
    Splits the available area into TOP / BOTTOM panes.

    percentage = percentage of height used by the TOP pane.

    Example:
        VerticalSplit(70, WindowNode(top), WindowNode(bottom))

    Result:
        top    = 70%
        bottom = 30%
    """

    def __init__(
        self,
        percentage: int,
        top: LayoutNode,
        bottom: LayoutNode,
        min_top_height: int = 1,
        min_bottom_height: int = 1,
    ):
        if percentage <= 0 or percentage >= 100:
            raise ValueError("percentage must be between 1 and 99")

        self.percentage = percentage
        self.top = top
        self.bottom = bottom
        self.min_top_height = max(0, min_top_height)
        self.min_bottom_height = max(0, min_bottom_height)

    def apply(self, rect: Rect) -> None:
        rect = rect.clamped()

        if rect.is_empty:
            self.top.apply(Rect(rect.x, rect.y, 0, 0))
            self.bottom.apply(Rect(rect.x, rect.y, 0, 0))
            return

        top_height = rect.height * self.percentage // 100
        bottom_height = rect.height - top_height

        total_min = self.min_top_height + self.min_bottom_height

        if rect.height >= total_min:
            if top_height < self.min_top_height:
                top_height = self.min_top_height
                bottom_height = rect.height - top_height

            if bottom_height < self.min_bottom_height:
                bottom_height = self.min_bottom_height
                top_height = rect.height - bottom_height
        else:
            top_height = max(0, min(rect.height, top_height))
            bottom_height = max(0, rect.height - top_height)

        top_height = max(0, min(top_height, rect.height))
        bottom_height = max(0, rect.height - top_height)

        top_rect = Rect(
            x=rect.x,
            y=rect.y,
            width=rect.width,
            height=top_height,
        )

        bottom_rect = Rect(
            x=rect.x,
            y=rect.y + top_height,
            width=rect.width,
            height=bottom_height,
        )

        self.top.apply(top_rect)
        self.bottom.apply(bottom_rect)

    def windows(self) -> list[Window]:
        return self.top.windows() + self.bottom.windows()

    def resize_window(self, target_window: Window, delta: int) -> bool:
        """
        Resize the nearest split around target_window.

        Positive delta means: make target_window bigger.
        Negative delta means: make target_window smaller.

        This is child-first, so nested splits resize before outer splits.
        """

        if self.top.resize_window(target_window, delta):
            return True

        if self.bottom.resize_window(target_window, delta):
            return True

        if target_window in self.top.windows():
            self.percentage = max(1, min(99, self.percentage + delta))
            return True

        if target_window in self.bottom.windows():
            self.percentage = max(1, min(99, self.percentage - delta))
            return True

        return False


# ==========================================================
# Layout Tree Helpers
# ==========================================================


def replace_window_node(
    node: LayoutNode,
    target_window: Window,
    replacement: LayoutNode,
) -> tuple[LayoutNode, bool]:
    """
    Replace the WindowNode that wraps target_window with replacement.

    Returns:
        (new_node, replaced)
    """

    if isinstance(node, WindowNode):
        if node.window is target_window:
            return replacement, True

        return node, False

    if isinstance(node, HorizontalSplit):
        new_left, replaced = replace_window_node(
            node.left,
            target_window,
            replacement,
        )

        if replaced:
            node.left = new_left
            return node, True

        new_right, replaced = replace_window_node(
            node.right,
            target_window,
            replacement,
        )

        if replaced:
            node.right = new_right
            return node, True

        return node, False

    if isinstance(node, VerticalSplit):
        new_top, replaced = replace_window_node(
            node.top,
            target_window,
            replacement,
        )

        if replaced:
            node.top = new_top
            return node, True

        new_bottom, replaced = replace_window_node(
            node.bottom,
            target_window,
            replacement,
        )

        if replaced:
            node.bottom = new_bottom
            return node, True

        return node, False

    return node, False


def remove_window_node(
    node: LayoutNode,
    target_window: Window,
) -> tuple[LayoutNode | None, bool]:
    """
    Remove target_window from a layout tree.

    If removing one side of a split, the other side replaces the split.
    """

    if isinstance(node, WindowNode):
        if node.window is target_window:
            return None, True

        return node, False

    if isinstance(node, HorizontalSplit):
        new_left, removed_left = remove_window_node(node.left, target_window)
        new_right, removed_right = remove_window_node(node.right, target_window)

        if not removed_left and not removed_right:
            return node, False

        if new_left is None and new_right is None:
            return None, True

        if new_left is None:
            return new_right, True

        if new_right is None:
            return new_left, True

        node.left = new_left
        node.right = new_right
        return node, True

    if isinstance(node, VerticalSplit):
        new_top, removed_top = remove_window_node(node.top, target_window)
        new_bottom, removed_bottom = remove_window_node(node.bottom, target_window)

        if not removed_top and not removed_bottom:
            return node, False

        if new_top is None and new_bottom is None:
            return None, True

        if new_top is None:
            return new_bottom, True

        if new_bottom is None:
            return new_top, True

        node.top = new_top
        node.bottom = new_bottom
        return node, True

    return node, False


# ==========================================================
# Buffer Window
# ==========================================================


class BufferWindow:

    def __init__(
        self,
        manager: "WindowManager",
        editor: SimpleEditor,
        buffer_index: int = 0,
    ):
        self.manager = manager
        self.editor = editor

        self.rect = Rect(0, 0, 0, 0)
        self.win: curses.window | None = None

        self.focused = False
        self.mounted = False

        # ======================================================
        # Window-local render/context state
        # ======================================================
        self.render_window: curses.window | None = None

        self.viewport_x = 0
        self.viewport_y = 0
        self.viewport_width = 0
        self.viewport_height = 0

        # Window-local cursor / viewport state
        self._cursor_x = 0
        self._cursor_y = 0
        self._last_cursor_x = 0

        self._scroll = 0
        self._h_scroll = 0

        self._current_buffer = 0

        self.current_gutter_width = 0

        if 0 <= buffer_index < len(editor.buffers):
            self.current_buffer = buffer_index
        else:
            self.current_buffer = 0

        self.selection_start: tuple[int, int] | None = None

        self.active_window_rect = self.rect
        self.active_buffer_index = self.current_buffer

    @property
    def current_buffer(self) -> int:
        return self._current_buffer

    @current_buffer.setter
    def current_buffer(self, value: int) -> None:
        self._current_buffer = value

        buffer = self.buffer

        if buffer.first:
            buffer.load()

            if config.STATIC_CONFIG.get("gch", False):
                buffer.git_changes = git_utils.get_file_changes(buffer.file_name)

            if buffer.suffix:
                lsp_client = get_lsp(buffer.suffix)

                if lsp_client:
                    lsp_client.did_open(
                        get_uri_from_name(buffer.file_name),
                        "\n".join(buffer.get_lines()),
                    )

            self.last_cursor_x = self.cursor_x
            buffer.first = False

        num_lines = len(self.lines) - 1

        self.cursor_y = max(0, min(buffer._cursor_y, len(buffer.lines) - 1))
        self.cursor_x = max(
            0, min(buffer._cursor_x, len(buffer.lines[buffer._cursor_y]))
        )

        self.last_cursor_x = max(
            0, min(buffer._last_cursor_x, len(buffer.lines[buffer._cursor_y]))
        )

        max_scroll = max(0, len(buffer.lines) - 1)
        self.scroll = max(0, min(buffer._scroll, max_scroll))

        self.h_scroll = max(0, buffer._h_scroll)

        self.selection_start = None  # (row, col) of selection origin

        self.adjust_cursor_position()

    @property
    def buffer(self) -> Buffer:
        buffer = self.editor.buffers[self.current_buffer]
        return buffer

    @property
    def lines(self) -> Sequence[RichString]:
        return self.buffer.lines

    @property
    def scroll(self) -> int:
        return self._scroll

    @scroll.setter
    def scroll(self, value: int) -> None:
        self._scroll = value
        self.buffer._scroll = value

    @property
    def h_scroll(self) -> int:
        return self._h_scroll

    @h_scroll.setter
    def h_scroll(self, value: int) -> None:
        self._h_scroll = value
        self.buffer._h_scroll = value

    @property
    def cursor_x(self) -> int:
        return self._cursor_x

    @cursor_x.setter
    def cursor_x(self, value: int) -> None:
        self._cursor_x = value
        self.buffer._cursor_x = value

    @property
    def cursor_y(self) -> int:
        return self._cursor_y

    @cursor_y.setter
    def cursor_y(self, value: int) -> None:
        self._cursor_y = value
        self.buffer._cursor_y = value

    @property
    def last_cursor_x(self) -> int:
        return self._last_cursor_x

    @last_cursor_x.setter
    def last_cursor_x(self, value: int) -> None:
        self._last_cursor_x = value
        self.buffer._last_cursor_x = value

    # cursor movement
    def move_cursor(self, key: str, screen_height: int, screen_width: int):

        if key == "Left":
            if self.cursor_x > 0:
                self.cursor_x -= 1

            self.last_cursor_x = self.cursor_x

        elif key == "Right" and self.cursor_x < len(self.lines[self.cursor_y]):
            self.cursor_x += 1
            self.last_cursor_x = self.cursor_x

        elif key == "Up" and self.cursor_y > 0:
            self.cursor_y -= 1
            self.cursor_x = min(self.last_cursor_x, len(self.lines[self.cursor_y]))

        elif key == "Down" and self.cursor_y < len(self.lines) - 1:
            self.cursor_y += 1
            self.cursor_x = min(self.last_cursor_x, len(self.lines[self.cursor_y]))

        if self.cursor_x < self.h_scroll:
            self.h_scroll = self.cursor_x
        elif self.cursor_x >= self.h_scroll + screen_width:
            self.h_scroll = self.cursor_x - screen_width + 1

        content_height = screen_height - 1
        half = content_height // 2
        max_scroll = max(0, len(self.lines) - content_height)

        if self.cursor_y < self.scroll:
            self.scroll = max(0, self.cursor_y - half)

        elif self.cursor_y > self.scroll + content_height - 1:
            self.scroll = min(max_scroll, self.cursor_y - half)

        self.scroll = max(0, min(self.scroll, max_scroll))

    def move_cursor_end_of_line(self):

        position = self.get_cursor_position()

        new_position = CursorPosition(y=position.y, x=len(self.lines[position.y]))

        self.set_cursor_position(new_position)

    def move_cursor_start_of_line(self):

        position = self.get_cursor_position()

        new_position = CursorPosition(y=position.y, x=0)

        self.set_cursor_position(new_position)

    def move_cursor_by_word(self, direction):
        """Ctrl+Arrow word-wise navigation."""

        line = self.lines[self.cursor_y]
        pos = self.cursor_x

        if direction == "right":
            # Skip over non-space then spaces
            while pos < len(line) and not line[pos].isspace():
                pos += 1
            while pos < len(line) and line[pos].isspace():
                pos += 1
        else:
            while pos > 0 and line[pos - 1].isspace():
                pos -= 1
            while pos > 0 and not line[pos - 1].isspace():
                pos -= 1

        self.cursor_x = pos
        self.last_cursor_x = pos

    def move_cursor_by_punctuation(self, direction):
        """VSCode-like Ctrl+Arrow navigation: stop at word/punctuation boundaries."""
        line = self.lines[self.cursor_y]
        pos = self.cursor_x
        length = len(line)

        def classify(ch):
            if ch.isspace():
                return "whitespace"
            elif ch.isalnum() or ch == "_":
                return "word"
            else:
                return "punct"

        if direction == "right":
            if pos >= length:
                return  # Already at end

            current_type = classify(line[pos])

            # Step over this group
            while pos < length and classify(line[pos]) == current_type:
                pos += 1

            # Step over any whitespace
            while pos < length and line[pos].isspace():
                pos += 1

        elif direction == "left":
            if pos == 0:
                return  # Already at start

            # Look at char before the cursor
            current_type = classify(line[pos - 1])

            # Step back over this group
            while pos > 0 and classify(line[pos - 1]) == current_type:
                pos -= 1

        self.cursor_x = pos
        self.last_cursor_x = pos

    def move_cursor_by_empty_line(self, direction: int, height: int):
        """
        Fast VSCode-style paragraph movement: jump to the next/previous blank line
        *before* a non-blank line, then center that line in the viewport and preserve column.
        """
        lines = self.lines
        n = len(lines)

        is_blank = [not line.strip() for line in lines]

        start = self.cursor_y + direction
        target = None

        y = start
        while 0 <= y < n:
            if is_blank[y]:
                if (direction > 0 and y + 1 < n and not is_blank[y + 1]) or (
                    direction < 0 and y - 1 >= 0 and not is_blank[y - 1]
                ):
                    target = y
                    break
            y += direction

        if target is None:
            target = (n - 1) if direction > 0 else 0

        self.cursor_y = target
        self.cursor_x = min(self.cursor_x, len(lines[target]))

        max_scroll = max(0, n - height)
        ideal_top = target - (height // 2)
        self.scroll = max(0, min(ideal_top, max_scroll))

    def find_char(self, target_char: str, forward: bool = True):
        """
        Implements:
            f{char}  -> forward
            F{char}  -> backward
            ;        -> repeat same direction
            ,        -> repeat opposite direction
        """
        line = self.lines[self.cursor_y]
        pos = self.cursor_x

        if forward:
            idx = line.find(target_char, pos + 1)
            if idx != -1:
                self.cursor_x = idx

        else:
            idx = line.rfind(target_char, 0, pos)
            if idx != -1:
                self.cursor_x = idx

        self.last_cursor_x = self.cursor_x

    def ensure_cursor_visible(self):
        """
        Adjust self.scroll_offset so that cursor_y is within the visible window.
        You'll need to know your window height (e.g. self.num_rows).
        """

        self.set_cursor_position(self.get_cursor_position())

        top = self.scroll
        bottom = top + len(self.lines) - 1

        if self.cursor_y < top:
            self.scroll = self.cursor_y
        elif self.cursor_y > bottom:
            self.scroll = self.cursor_y - (len(self.lines) - 1)

    def move_scroll(self, direction: int, height: int, move_cursor: bool = True):
        """
        Scroll buffer by `direction`, but only move the cursor if scrolling
        would put it OUTSIDE the scrolloff=8 safe region.

        This fully respects adjust_scroll() freeze zones.
        """

        SCROLLOFF = config.STATIC_CONFIG.get("scrolloff", 0)

        n_lines = len(self.lines)

        content_height = height - 1
        max_scroll = max(0, n_lines - content_height)

        old_scroll = self.scroll

        self.scroll = max(0, min(self.scroll + direction, max_scroll))

        if not move_cursor:
            return

        if self.scroll == old_scroll:
            return

        top = self.scroll
        bottom = top + content_height - 1

        safe_top = top + SCROLLOFF
        safe_bottom = bottom - SCROLLOFF

        y = self.cursor_y

        if y < safe_top:
            self.cursor_y = safe_top
        elif y > safe_bottom:
            self.cursor_y = safe_bottom

        self.cursor_y = max(0, min(self.cursor_y, n_lines - 1))

        self.cursor_x = min(self.cursor_x, len(self.lines[self.cursor_y]))

    def page_up(self, height: int):
        """
        Scroll up one page (height-2 lines), moving the cursor up the same amount,
        and never above line 0.
        """
        page = height - 2

        self.cursor_y = max(0, self.cursor_y - page)
        self.cursor_x = max(
            0, min(self.last_cursor_x, len(self.lines[self.cursor_y]) - 1)
        )
        self.scroll = max(0, self.scroll - page)

        self.ensure_cursor_visible()

    def page_down(self, height: int):
        """
        Scroll down one page (height-2 lines), moving the cursor down the same amount,
        and never past the last line.
        """
        page = height - 2
        last_line = len(self.lines) - 1
        max_scroll = max(0, len(self.lines) - height + 2)

        self.cursor_y = min(last_line, self.cursor_y + page)
        self.cursor_x = max(
            0, min(self.last_cursor_x, len(self.lines[self.cursor_y]) - 1)
        )
        self.scroll = min(max_scroll, self.scroll + page)

        self.ensure_cursor_visible()

    def go_to_file_start(self):
        """
        Jump to line 0, column 0 and scroll it into view.
        """
        self.cursor_y = 0
        self.cursor_x = 0
        self.last_cursor_x = 0

    def go_to_file_end(self):
        """
        Jump to the last line at its last column and scroll it into view.
        """
        self.cursor_y = len(self.lines) - 1
        self.cursor_x = len(self.lines[self.cursor_y])
        self.last_cursor_x = self.cursor_x

    def get_cursor_position(self) -> CursorPosition:
        return CursorPosition(y=self.cursor_y, x=self.cursor_x)

    def get_cursor_position_display(self) -> CursorPosition:
        return CursorPosition(
            y=self.rect.y + (self.cursor_y - self.scroll) + 1,
            x=self.rect.x + (self.cursor_x - self.h_scroll) + self.current_gutter_width,
        )

    def set_cursor_position(self, position: CursorPosition):
        self.cursor_y = max(0, min(position.y, len(self.lines) - 1))
        self.cursor_x = max(0, min(position.x, len(self.lines[self.cursor_y])))
        self.last_cursor_x = self.cursor_x

    def adjust_cursor_position(self):
        self.cursor_y = max(0, min(self.cursor_y, len(self.lines) - 1))
        self.cursor_x = max(0, min(self.cursor_x, len(self.lines[self.cursor_y])))
        self.last_cursor_x = self.cursor_x

    # ==========================================================
    # Layout
    # ==========================================================

    def set_rect(self, rect: Rect) -> None:
        """
        Assign this pane's rectangle.

        Important:
        Do not recreate the curses sub-window if the rectangle did not change.
        Recreating derwin() every render causes flickering.
        """

        rect = rect.clamped()

        if self.rect == rect and self.win is not None:
            self._sync_window_context()
            return

        self.rect = rect

        if rect.is_empty:
            self.win = None
            self._sync_window_context()
            return

        try:
            self.win = self.manager.stdscr.derwin(
                rect.height,
                rect.width,
                rect.y,
                rect.x,
            )

            self.win.keypad(True)

            # Non-focused panes should not own the physical cursor.
            self.win.leaveok(not self.focused)

        except curses.error:
            self.win = None

        self._sync_window_context()

    # ==========================================================
    # Lifecycle
    # ==========================================================

    def on_mount(self) -> None:
        self.mounted = True
        self._sync_window_context()

    def on_unmount(self) -> None:
        self.mounted = False
        self.win = None
        self._sync_window_context()

    def on_focus(self) -> None:
        self.focused = True

        if self.win is not None:
            # Focused window is allowed to control cursor position.
            self.win.leaveok(False)

        self._sync_window_context()

    def on_blur(self) -> None:
        self.focused = False

        if self.win is not None:
            # Non-focused windows should not move the physical cursor.
            self.win.leaveok(True)

        self._sync_window_context()

    # ==========================================================
    # Window Context
    # ==========================================================

    def _sync_window_context(self) -> None:
        """
        Store the render context inside this BufferWindow.

        The editor should not own window-specific state.
        Each BufferWindow owns:
            - its curses window
            - its viewport
            - its rect
            - its current buffer
        """

        self.render_window = self.win

        self.viewport_x = self.rect.x
        self.viewport_y = self.rect.y
        self.viewport_width = self.rect.width
        self.viewport_height = self.rect.height

        self.active_window_rect = self.rect
        self.active_buffer_index = self.current_buffer

    # ==========================================================
    # Events
    # ==========================================================

    def handle_event(self, event: Event) -> bool:
        """
        Delegate to editor input system.

        current_buffer remains local to this BufferWindow.
        The editor does not need editor.current_buffer.
        """

        if event.type != EventType.KEY:
            return False

        if self.win is None:
            return False

        self._sync_window_context()

        self.editor.process_key(event.data)

        return True

    # ==========================================================
    # Rendering
    # ==========================================================

    def render(self) -> None:
        if self.win is None:
            return

        try:
            self._sync_window_context()

            draw(
                self.editor,
                self,
            )

            self.win.noutrefresh()

        except curses.error:
            pass

    # ==========================================================
    # Closing
    # ==========================================================

    def close(self) -> None:
        self.manager.remove_window(self)


# ==========================================================
# Window Manager
# ==========================================================


class WindowManager:
    def __init__(self, stdscr: curses.window):
        self.stdscr = stdscr

        self.layout: LayoutNode | None = None

        self.base_windows: list[BufferWindow] = []
        self.overlays: list[Window] = []

        self.focused: Window | None = None
        self.last_base_focused: BufferWindow | None = None

        self.last_screen_size: tuple[int, int] | None = None

        try:
            self.stdscr.keypad(True)
            self.stdscr.leaveok(True)
        except curses.error:
            pass

    # ==========================================================
    # Layout
    # ==========================================================

    def _screen_rect(self) -> Rect:
        height, width = self.stdscr.getmaxyx()

        return Rect(
            x=0,
            y=0,
            width=max(0, width),
            height=max(0, height),
        )

    def _refresh_base_windows_from_layout(self) -> None:
        if self.layout is None:
            return

        self.base_windows = [
            win for win in self.layout.windows() if isinstance(win, BufferWindow)
        ]

    def set_layout(self, layout: LayoutNode) -> None:
        """
        Replace the current base layout.
        """

        old_windows = set(self.base_windows)

        self.layout = layout
        self._refresh_base_windows_from_layout()

        new_windows = set(self.base_windows)

        for window in self.base_windows:
            window.manager = self

            if window not in old_windows:
                window.on_mount()

        for window in old_windows:
            if window not in new_windows:
                window.on_unmount()

        if self.focused not in self.base_windows and self.focused not in self.overlays:
            if self.base_windows:
                self.set_focus(self.base_windows[0])
            else:
                self.set_focus(None)

        self.force_apply_layout()

    def force_apply_layout(self) -> None:
        """
        Force recalculation of the layout.
        """

        rect = self._screen_rect()
        self.last_screen_size = (rect.height, rect.width)

        if self.layout is not None:
            self.layout.apply(rect)
            return

        for window in self.base_windows:
            window.set_rect(rect)

    def apply_layout_if_needed(self) -> None:
        """
        Recalculate the layout only if terminal size changed.
        """

        rect = self._screen_rect()
        size = (rect.height, rect.width)

        if self.last_screen_size == size:
            return

        self.last_screen_size = size

        if self.layout is not None:
            self.layout.apply(rect)
            return

        for window in self.base_windows:
            window.set_rect(rect)

    def clear_layout(self) -> None:
        for window in self.base_windows:
            window.on_unmount()

        self.layout = None
        self.base_windows.clear()
        self.last_screen_size = None

        if self.focused not in self.overlays:
            self.set_focus(None)

    # ==========================================================
    # Base Windows
    # ==========================================================

    def add_base_window(self, window: BufferWindow) -> None:
        """
        Compatibility method.

        For splits, prefer set_layout(...).
        """

        if self.layout is not None:
            raise RuntimeError(
                "Cannot use add_base_window() while a split layout is active. "
                "Use set_layout(...) or split_active_*() instead."
            )

        window.manager = self
        self.base_windows.append(window)
        window.on_mount()

        self.force_apply_layout()

        if self.focused is None:
            self.set_focus(window)

    def _ensure_layout_for_existing_windows(self) -> None:
        """
        If old mode is being used with base_windows but no layout,
        build a simple layout around the first base window.
        """

        if self.layout is not None:
            return

        if not self.base_windows:
            return

        self.layout = WindowNode(self.base_windows[0])

    def create_buffer_window_like(
        self,
        source: BufferWindow,
        buffer_index: int | None = None,
    ) -> BufferWindow:
        """
        Create a new BufferWindow using the same editor as source.
        """

        if buffer_index is None:
            buffer_index = source.current_buffer

        return BufferWindow(
            manager=self,
            editor=source.editor,
            buffer_index=buffer_index,
        )

    def split_active_vertical(
        self,
        percentage: int = 50,
        new_window: BufferWindow | None = None,
    ) -> BufferWindow | None:
        """
        Split the active base window into LEFT / RIGHT panes.

        Existing focused pane stays on the left.
        New pane is placed on the right and receives focus.
        """

        active = self.last_base_focused

        if active not in self.base_windows:
            return None

        self._ensure_layout_for_existing_windows()

        if self.layout is None:
            return None

        if new_window is None:
            new_window = self.create_buffer_window_like(active)

        new_window.manager = self

        replacement = HorizontalSplit(
            percentage,
            WindowNode(active),
            WindowNode(new_window),
        )

        self.layout, replaced = replace_window_node(
            self.layout,
            active,
            replacement,
        )

        if not replaced:
            return None

        self.set_layout(self.layout)
        self.set_focus(new_window)

        return new_window

    def split_active_horizontal(
        self,
        percentage: int = 50,
        new_window: BufferWindow | None = None,
    ) -> BufferWindow | None:
        """
        Split the active base window into TOP / BOTTOM panes.

        Existing focused pane stays on top.
        New pane is placed on bottom and receives focus.
        """

        active = self.last_base_focused

        if active not in self.base_windows:
            return None

        self._ensure_layout_for_existing_windows()

        if self.layout is None:
            return None

        if new_window is None:
            new_window = self.create_buffer_window_like(active)

        new_window.manager = self

        replacement = VerticalSplit(
            percentage,
            WindowNode(active),
            WindowNode(new_window),
        )

        self.layout, replaced = replace_window_node(
            self.layout,
            active,
            replacement,
        )

        if not replaced:
            return None

        self.set_layout(self.layout)
        self.set_focus(new_window)

        return new_window

    def vsplit(self, percentage: int = 50) -> BufferWindow | None:
        return self.split_active_vertical(percentage)

    def hsplit(self, percentage: int = 50) -> BufferWindow | None:
        return self.split_active_horizontal(percentage)

    # ==========================================================
    # Resize Splits
    # ==========================================================

    def resize_last_base_window(self, delta: int) -> bool:
        """
        Resize the split that contains last_base_focused.

        Positive delta makes last_base_focused bigger.
        Negative delta makes last_base_focused smaller.

        This intentionally uses last_base_focused instead of focused because
        focused may be an overlay/modal window.
        """

        active = self.last_base_focused

        if active is None:
            return False

        if active not in self.base_windows:
            return False

        if self.layout is None:
            return False

        resized = self.layout.resize_window(active, delta)

        if resized:
            self.force_apply_layout()

        return resized

    def grow_last_base_window(self, amount: int = 5) -> bool:
        return self.resize_last_base_window(amount)

    def shrink_last_base_window(self, amount: int = 5) -> bool:
        return self.resize_last_base_window(-amount)

    # ==========================================================
    # Focus
    # ==========================================================

    def set_focus(self, window: Window | None) -> None:
        if self.focused is window:
            return

        old_focused = self.focused

        if old_focused is not None:
            old_focused.on_blur()

        if isinstance(window, BufferWindow):
            self.last_base_focused = window

        self.focused = window

        if self.focused is not None:
            self.focused.on_focus()

    def focus_next_base(self) -> None:
        if not self.base_windows:
            return

        if self.last_base_focused not in self.base_windows:
            self.set_focus(self.base_windows[0])
            return

        index = self.base_windows.index(self.last_base_focused)
        next_index = (index + 1) % len(self.base_windows)

        self.set_focus(self.base_windows[next_index])

    def focus_previous_base(self) -> None:
        if not self.base_windows:
            return

        if self.last_base_focused not in self.base_windows:
            self.set_focus(self.base_windows[-1])
            return

        index = self.base_windows.index(self.last_base_focused)
        previous_index = (index - 1) % len(self.base_windows)

        self.set_focus(self.base_windows[previous_index])

    # ==========================================================
    # Overlays / Modal Windows
    # ==========================================================

    def push_overlay(self, window: Window) -> None:
        window.manager = self

        rect = self._screen_rect()

        overlay_width = max(20, rect.width // 2)
        overlay_height = max(8, rect.height - 1)

        overlay_width = min(overlay_width, rect.width)
        overlay_height = min(overlay_height, rect.height)

        x = max(0, (rect.width - overlay_width) // 2)
        y = max(0, (rect.height - overlay_height) // 2)

        window.set_rect(
            Rect(
                x=x,
                y=y,
                width=overlay_width,
                height=overlay_height,
            )
        )

        window.on_mount()

        self.overlays.append(window)
        self.set_focus(window)

    def pop_overlay(self) -> None:
        if not self.overlays:
            return

        top = self.overlays.pop()
        top.on_unmount()

        if self.overlays:
            self.set_focus(self.overlays[-1])
        elif self.last_base_focused in self.base_windows:
            self.set_focus(self.last_base_focused)
        elif self.base_windows:
            self.set_focus(self.base_windows[0])
        else:
            self.set_focus(None)

    def remove_window(self, window: Window) -> None:
        if window in self.overlays:
            self.overlays.remove(window)
            window.on_unmount()

            if self.focused is window:
                if self.overlays:
                    self.set_focus(self.overlays[-1])
                elif self.last_base_focused in self.base_windows:
                    self.set_focus(self.last_base_focused)
                elif self.base_windows:
                    self.set_focus(self.base_windows[0])
                else:
                    self.set_focus(None)

            return

        if window in self.base_windows:
            window.on_unmount()

            if self.layout is not None:
                new_layout, removed = remove_window_node(self.layout, window)

                if removed:
                    self.layout = new_layout
                    self._refresh_base_windows_from_layout()
                else:
                    self.base_windows.remove(window)
            else:
                self.base_windows.remove(window)

            if self.focused is window:
                if self.last_base_focused in self.base_windows:
                    self.set_focus(self.last_base_focused)
                elif self.base_windows:
                    self.set_focus(self.base_windows[0])
                else:
                    self.set_focus(None)

            if not self.base_windows:
                self.layout = None
                self.last_base_focused = None

            self.force_apply_layout()

    def window_at(self, x: int, y: int) -> Window | None:
        # Overlays first
        for win in reversed(self.overlays):
            r = win.rect
            if r.x <= x < r.right and r.y <= y < r.bottom:
                return win

        # Base windows
        for win in reversed(self.base_windows):
            r = win.rect
            if r.x <= x < r.right and r.y <= y < r.bottom:
                return win

        return None

    # ==========================================================
    # Event Dispatch
    # ==========================================================

    def dispatch(self, event: Event) -> None:
        # Focused window gets first chance.
        if self.focused is not None and self.focused.handle_event(event):
            return

        # Overlays get priority over base windows.
        for win in reversed(self.overlays):
            if win is not self.focused and win.handle_event(event):
                return

        # Bubble to base windows.
        for win in reversed(self.base_windows):
            if win is not self.focused and win.handle_event(event):
                return

    # ==========================================================
    # Rendering
    # ==========================================================

    def render(self) -> None:
        """
        Render all windows.

        Important:
        - Do not call stdscr.erase() here.
        - Do not force layout recalculation every frame.
        - Render focused base window last so its cursor position wins.
        """
        curses.curs_set(0)
        self.apply_layout_if_needed()

        focused = self.focused

        # Render non-focused base panes first.
        for win in self.base_windows:
            if win is not focused:
                win.render()

        # Render focused base pane last.
        if isinstance(focused, BufferWindow) and focused in self.base_windows:
            focused.render()

        # Render non-focused overlays first.
        for owin in self.overlays:
            if owin is not focused:
                owin.render()

        # Render focused overlay last.
        if focused in self.overlays:
            focused.render()

        curses.doupdate()
        curses.curs_set(1)
