from __future__ import annotations

import json
import os
from typing import TYPE_CHECKING, NotRequired, TypedDict

from denary import windows

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


type Markers = dict[str, tuple[int, int]]
type GlobalMarkers = dict[str, tuple[int, int, str]]


class BufferSession(TypedDict):
    """
    Represents a buffer session with buffer metadata.
    """

    file_name: str
    cursor_x: int
    cursor_y: int
    scroll: int
    h_scroll: int
    markers: Markers


class LayoutNodeSession(TypedDict, total=False):
    type: str  # "window" | "horizontal" | "vertical"
    file_name: str
    ratio: NotRequired[int]
    children: NotRequired[list[LayoutNodeSession]]


class Session(TypedDict):
    """
    Represents a session with a list of buffers and the index of the current buffer.
    """

    buffers: list[BufferSession]
    layout: LayoutNodeSession | None
    current_buffer_name: str | None
    # Store global markers by name
    global_markers: GlobalMarkers
    fuzzy_search: list[str]  # Store fuzzy search results
    working_dir_mtime: float
    command_history: list[str]
    search_history: list[str]
    eval_history: list[str]


def serialize_layout(node):
    """
    Convert runtime layout tree into session dict.
    """
    if node is None:
        return None

    # Leaf window
    # if hasattr(node, "buffer"):
    if node.__class__.__name__ == "WindowNode":
        return LayoutNodeSession(
            **{
                "type": "window",
                "file_name": node.window.buffer.file_name,
            }
        )

    # Horizontal split
    if node.__class__.__name__ == "HorizontalSplit":
        return LayoutNodeSession(
            **{
                "type": "horizontal",
                "ratio": getattr(node, "ratio", 50),
                "children": [
                    serialize_layout(node.left),
                    serialize_layout(node.right),
                ],
            }
        )

    # Vertical split
    if node.__class__.__name__ == "VerticalSplit":
        return {
            "type": "vertical",
            "ratio": getattr(node, "ratio", 50),
            "children": [
                serialize_layout(node.top),
                serialize_layout(node.bottom),
            ],
        }

    raise ValueError(f"Unknown layout node type: {type(node)}")


def deserialize_layout(
    layout_dict: LayoutNodeSession,
    editor: SimpleEditor,
    manager: windows.WindowManager,
) -> None:
    """
    Reconstruct layout using ONLY WindowManager public API.
    Must match serialize_layout() structure.
    """

    manager.clear_layout()

    def build_into(
        existing_window: windows.BufferWindow, node_dict: LayoutNodeSession
    ) -> None:
        node_type = node_dict["type"]

        # --------------------------
        # Leaf window
        # --------------------------
        if node_type == "window":
            file_name = node_dict["file_name"]
            buffer_index = editor.get_buffer_by_file_name(file_name)
            existing_window.current_buffer = buffer_index
            return

        # --------------------------
        # Horizontal split (LEFT / RIGHT)
        # --------------------------
        if node_type == "horizontal":
            ratio = node_dict.get("ratio", 50)
            left_dict, right_dict = node_dict["children"]

            manager.set_focus(existing_window)

            new_window = manager.split_active_vertical(ratio)

            if new_window is None:
                return

            # existing_window becomes LEFT
            # new_window becomes RIGHT

            # Rebuild left into existing
            build_into(existing_window, left_dict)

            # Rebuild right into new window
            manager.set_focus(new_window)
            build_into(new_window, right_dict)

            return

        # --------------------------
        # Vertical split (TOP / BOTTOM)
        # --------------------------
        if node_type == "vertical":
            ratio = node_dict.get("ratio", 50)
            top_dict, bottom_dict = node_dict["children"]

            manager.set_focus(existing_window)

            new_window = manager.split_active_horizontal(ratio)
            if new_window is None:
                return None
            # existing_window becomes TOP
            # new_window becomes BOTTOM

            build_into(existing_window, top_dict)

            manager.set_focus(new_window)
            build_into(new_window, bottom_dict)

            return

        raise ValueError(f"Unknown layout node type: {node_type}")

    # ---------------------------------
    # Root handling
    # ---------------------------------

    # Root must start with a single window
    if layout_dict["type"] == "window":
        file_name = layout_dict["file_name"]
        buffer_index = editor.get_buffer_by_file_name(file_name)

        root = windows.BufferWindow(manager, editor, buffer_index)
        manager.add_base_window(root)
        manager.set_focus(root)

    else:
        # Create initial empty window
        root = windows.BufferWindow(manager, editor, 0)
        manager.add_base_window(root)
        manager.set_focus(root)

        build_into(root, layout_dict)

    manager.force_apply_layout()


def save_editor_session(editor: SimpleEditor) -> None:
    """
    Save the current session state to a file.
    This includes the list of buffers and their content.
    """
    if any(b.file_name is not None for b in editor.buffers):
        session_file = "editor_session.json"
        session = Session(
            current_buffer_name=editor.buffers[
                editor.get_current_buffer_index_window()
            ].file_name,
            global_markers=editor.global_markers,
            command_history=editor.command_history,
            search_history=editor.search_history,
            eval_history=editor.eval_history,
            working_dir_mtime=editor.working_dir_mtime,
            buffers=[
                BufferSession(
                    file_name=b.file_name,
                    cursor_x=b._cursor_x if b._cursor_x >= 0 else 0,
                    cursor_y=b._cursor_y if b._cursor_y >= 0 else 0,
                    scroll=b._scroll if b._scroll >= 0 else 0,
                    h_scroll=b._h_scroll if b._h_scroll >= 0 else 0,
                    markers=b.markers,
                )
                for b in editor.buffers
                if b.file_name and not b.is_aux_buffer
            ],
            layout=serialize_layout(editor.window_manager.layout),
            fuzzy_search=editor.fuzzy_search if editor.fuzzy_search else [],
        )

        with open(session_file, "w") as f:
            json.dump(session, f, indent=4)

    elif os.path.exists("editor_session.json"):
        os.remove("editor_session.json")
