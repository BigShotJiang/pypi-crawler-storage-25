import os
from typing import Optional

from pathspec import PathSpec


def load_gitignore_patterns(root: str) -> Optional[PathSpec]:
    gitignore_path = os.path.join(root, ".gitignore")
    if os.path.exists(gitignore_path):
        with open(gitignore_path, "r", encoding="utf-8") as f:
            patterns = f.read().splitlines()
        return PathSpec.from_lines("gitignore", patterns)
    return None


def collect_files_with_gitignore(
    root: str, cached_files=None, changed=True
) -> list[str]:
    spec = load_gitignore_patterns(root)

    if not cached_files or changed:
        all_files = []
        for dirpath, _, filenames in os.walk(root):
            for fn in filenames:
                rel = os.path.relpath(os.path.join(dirpath, fn), root)

                if rel.startswith(".") or "/." in rel:
                    continue

                if spec and spec.match_file(rel):
                    continue

                all_files.append(rel)

        all_files.sort()
        return all_files
    else:
        return cached_files
