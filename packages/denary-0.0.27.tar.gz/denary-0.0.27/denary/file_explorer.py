from __future__ import annotations

import curses
import os
import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from denary.events import Event, EventType
from denary.key_mappings import get_key_mapping
from denary.notifications import send_notification
from denary.prompts import send_prompt, send_prompt_confirm
from denary.windows import Rect, WindowManager

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


class ExplorerWindow:
    """
    Vim-style :Ex file explorer as a WindowManager window.

    Based directly on the original show_explorer(editor) function.

    Keys:
      Up/k       move up
      Down/j     move down
      Enter      open/descend
      a          new file/dir, dir ends with '/'
      d          delete
      r          rename
      m          move
      c          copy
      /          search, empty query clears search
      n          next match, wraps
      N          previous match, wraps
      g          top
      G          bottom
      q / Esc    close
    """

    def __init__(
        self,
        manager: WindowManager,
        editor: SimpleEditor,
        start_dir: Optional[str] = None,
    ):
        self.manager = manager
        self.editor = editor

        self.rect = Rect(0, 0, 0, 0)
        self.win: curses.window | None = None

        self.focused = False
        self.mounted = False

        buffer = editor.get_current_buffer()

        file_path = (
            buffer.file_path.parent
            if getattr(buffer, "file_name", None) and getattr(buffer, "file_path", None)
            else os.getcwd()
        )

        self.cwd = Path(start_dir or file_path).resolve()
        self.base = Path(start_dir or os.getcwd()).resolve()

        self.cursor = 0
        self.scroll = 0
        self.search_query = ""

        self.entries_full: list[str] = self.list_entries_full()
        self.display_entries: list[str] = self.apply_search(
            self.entries_full,
            self.search_query,
        )

        self.select_current_buffer_file()

    # ==========================================================
    # Overlay sizing
    # ==========================================================

    def preferred_overlay_rect(self, screen_rect: Rect) -> Rect:
        """
        Use all available terminal space.

        This makes the ExplorerWindow visually behave like the original
        show_explorer(), which drew directly on the whole stdscr.
        """

        return Rect(
            x=0,
            y=0,
            width=screen_rect.width,
            height=screen_rect.height,
        )

    # ==========================================================
    # Lifecycle
    # ==========================================================

    def on_mount(self) -> None:
        self.mounted = True

        # Same intent as original:
        # when the explorer is opened by a macro, consume the macro key that opened it.
        if (
            self.editor.current_macro_playing_index is not None
            and self.editor.current_macro_playing_name is not None
        ):
            self.editor.current_macro_playing_index += 1

    def on_unmount(self) -> None:
        self.mounted = False
        self.win = None

    def on_focus(self) -> None:
        self.focused = True

        if self.win is not None:
            self.win.leaveok(False)

    def on_blur(self) -> None:
        self.focused = False

        if self.win is not None:
            self.win.leaveok(True)

    # ==========================================================
    # Layout
    # ==========================================================

    def set_rect(self, rect: Rect) -> None:
        rect = rect.clamped()

        if self.rect == rect and self.win is not None:
            return

        self.rect = rect

        if rect.is_empty:
            self.win = None
            return

        try:
            self.win = self.manager.stdscr.derwin(
                rect.height,
                rect.width,
                rect.y,
                rect.x,
            )
            self.win.keypad(True)
            self.win.leaveok(not self.focused)

        except curses.error:
            self.win = None

    # ==========================================================
    # Safe filesystem helpers
    # ==========================================================

    def _is_relative_to(self, p: Path, base: Path) -> bool:
        try:
            p.relative_to(base)
            return True
        except Exception:
            return False

    def _safe_join(self, base: Path, child_name: str) -> Path:
        clean = child_name[:-1] if child_name.endswith("/") else child_name
        target = (base / clean).resolve()

        return target if self._is_relative_to(target, self.base) else base

    def _safe_is_dir(self, p: Path) -> bool:
        try:
            return p.is_dir()
        except (PermissionError, FileNotFoundError, OSError):
            return False

    def _exists_safe(self, p: Path) -> bool:
        try:
            return p.exists()
        except Exception:
            return False

    def _has_access_dir(self, p: Path) -> bool:
        try:
            return os.access(p, os.R_OK | os.X_OK)
        except Exception:
            return False

    def _has_access_file(self, p: Path) -> bool:
        try:
            return os.access(p, os.R_OK)
        except Exception:
            return False

    # ==========================================================
    # Entry list / search
    # ==========================================================

    def list_entries_full(self) -> list[str]:
        """
        Return the full, safe entry list for cwd.

        Same as original:
        - '../' appears when cwd != base
        - directories get trailing '/'
        - directories sort before files
        """

        items: list[str] = []

        if self.cwd != self.base:
            items.append("../")

        try:
            with os.scandir(self.cwd) as it:
                bucket = []

                for entry in it:
                    try:
                        is_dir = entry.is_dir(follow_symlinks=False)
                    except (PermissionError, FileNotFoundError, OSError):
                        continue

                    name = entry.name + ("/" if is_dir else "")
                    bucket.append((not is_dir, entry.name.lower(), name))

            items.extend(name for _, __, name in sorted(bucket))

        except PermissionError:
            pass

        return items

    def apply_search(self, all_items: list[str], q: str) -> list[str]:
        """
        Filter by case-insensitive substring.

        Same as original:
        - empty query clears search
        - '../' is always kept
        """

        if not q:
            return list(all_items)

        ql = q.lower()
        out: list[str] = []

        for name in all_items:
            if name == "../":
                out.append(name)
                continue

            if ql in name.lower():
                out.append(name)

        return out

    def reload_entries(self) -> None:
        self.entries_full = self.list_entries_full()
        self.display_entries = self.apply_search(
            self.entries_full,
            self.search_query,
        )
        self.clamp_cursor_scroll()

    def jump_to_first_match(self) -> None:
        """
        Same logic as original jump_to_first_match(display_items, q).
        """

        if not self.search_query:
            return

        ql = self.search_query.lower()

        for i, name in enumerate(self.display_entries):
            if name != "../" and ql in name.lower():
                self.cursor = i

                if self.cursor < self.scroll or self.cursor >= self.scroll + self.win_h:
                    self.scroll = max(
                        0,
                        min(
                            self.cursor,
                            max(0, len(self.display_entries) - self.win_h),
                        ),
                    )

                return

    def next_match(self, backwards: bool = False) -> None:
        """
        Same logic as original next_match(display_items, q, backwards).
        """

        if not self.search_query or not self.display_entries:
            return

        ql = self.search_query.lower()
        n = len(self.display_entries)

        if n <= 1:
            return

        step = -1 if backwards else 1
        i = self.cursor

        for _ in range(n - 1):
            i = (i + step) % n
            name = self.display_entries[i]

            if name != "../" and ql in name.lower():
                self.cursor = i

                if self.cursor < self.scroll:
                    self.scroll = self.cursor
                elif self.cursor >= self.scroll + self.win_h:
                    self.scroll = self.cursor - self.win_h + 1

                self.clamp_cursor_scroll()
                return

    def select_current_buffer_file(self) -> None:
        """
        Same as original:
        when explorer opens, select current buffer path if found.
        """

        current_buffer_path = None

        try:
            current_buffer_path = self.editor.get_current_buffer().file_path.resolve()
        except Exception:
            pass

        if not current_buffer_path:
            return

        for index, entry in enumerate(self.display_entries):
            if entry == "../":
                continue

            entry_path = self._safe_join(self.cwd, entry).resolve()

            if entry_path == current_buffer_path:
                self.cursor = index

                if self.cursor < self.scroll:
                    self.scroll = self.cursor
                elif self.cursor >= self.scroll + self.win_h:
                    self.scroll = max(0, self.cursor - self.win_h + 1)

                break

    # ==========================================================
    # Size helpers: mirrors original win_h / win_w / win_x / win_y
    # ==========================================================

    @property
    def win_h(self) -> int:
        # Original: win_h = h - 3
        return max(1, self.rect.height - 3)

    @property
    def win_w(self) -> int:
        # Original: win_w = w - 4
        return max(1, self.rect.width - 4)

    @property
    def win_y(self) -> int:
        # Original: win_y = 1
        return 1

    @property
    def win_x(self) -> int:
        # Original: win_x = 2
        return 2

    @property
    def max_scroll(self) -> int:
        return max(0, len(self.display_entries) - self.win_h)

    def clamp_cursor_scroll(self) -> None:
        self.scroll = min(self.scroll, self.max_scroll)
        self.scroll = max(0, self.scroll)

        self.cursor = max(
            0,
            min(self.cursor, max(0, len(self.display_entries) - 1)),
        )

    # ==========================================================
    # Key helpers
    # ==========================================================

    def is_enter_key(self, key) -> bool:
        return key in (
            "Enter",
            "\n",
            "\r",
            10,
            13,
            343,
            "Ctrl+J",
            "Ctrl+M",
            curses.KEY_ENTER,
        )

    def is_escape_key(self, key) -> bool:
        return key in (
            27,
            "ESC",
            "Esc",
            "Escape",
        )

    # ==========================================================
    # Rendering
    # ==========================================================

    def render(self) -> None:
        if self.win is None:
            return

        try:
            self.clamp_cursor_scroll()

            self.win.erase()
            self.win.border()

            h = self.rect.height
            w = self.rect.width

            if h <= 2 or w <= 2:
                self.win.noutrefresh()
                return

            title = f" Current Path:  {self.cwd} "
            self.win.addnstr(0, 2, title, max(1, w - 4), curses.A_REVERSE)

            for idx in range(self.scroll, self.scroll + self.win_h):
                if idx >= len(self.display_entries):
                    break

                y = self.win_y + idx - self.scroll
                name = self.display_entries[idx]

                self.draw_row(
                    y=y,
                    name=name,
                    selected=(idx == self.cursor),
                )

            if self.search_query:
                status = (
                    f"[/] Search: {self.search_query}   "
                    "[n] Next  [N] Prev [a] New [d] Delete [r] Rename "
                    "[m] Move  [c] Copy  [q] Quit"
                )
            else:
                status = (
                    "[/] Search  [n] Next  [N] Prev  [a] New  [d] Delete  "
                    "[r] Rename  [m] Move  [c] Copy  [q] Quit"
                )

            self.win.addnstr(
                h - 2,
                2,
                status.ljust(self.win_w),
                self.win_w,
                curses.A_REVERSE,
            )

            self.win.noutrefresh()

        except curses.error:
            pass

    def draw_row(self, y: int, name: str, selected: bool) -> None:
        """
        Same as original draw_row().
        """

        if self.win is None:
            return

        attr_normal = curses.A_NORMAL
        attr_sel = curses.A_REVERSE
        attr_match = curses.A_BOLD

        attr = attr_sel if selected else attr_normal

        if not self.search_query or name == "../":
            self.win.addnstr(
                y,
                self.win_x,
                name.ljust(self.win_w),
                self.win_w,
                attr,
            )
            return

        low = name.lower()
        ql = self.search_query.lower()
        k = low.find(ql)

        if k < 0:
            self.win.addnstr(
                y,
                self.win_x,
                name.ljust(self.win_w),
                self.win_w,
                attr,
            )
            return

        left = name[:k]
        mid = name[k : k + len(ql)]
        right = name[k + len(ql) :]

        x = self.win_x

        seg = left[: max(0, self.win_w)]
        self.win.addnstr(y, x, seg, self.win_w, attr)
        x += len(seg)

        if x < self.win_x + self.win_w:
            seg = mid[: (self.win_x + self.win_w - x)]
            self.win.addnstr(y, x, seg, len(seg), attr | attr_match)
            x += len(seg)

        if x < self.win_x + self.win_w:
            seg = right[: (self.win_x + self.win_w - x)]
            self.win.addnstr(y, x, seg, len(seg), attr)
            x += len(seg)

        if x < self.win_x + self.win_w:
            self.win.addnstr(
                y,
                x,
                " " * (self.win_x + self.win_w - x),
                self.win_x + self.win_w - x,
                attr,
            )

    # ==========================================================
    # Event handling
    # ==========================================================

    def handle_event(self, event: Event) -> bool:
        """
        Handle one key event.

        Original:
            if macro playing:
                key = next macro key
            else:
                key = editor.stdscr.get_wch()
                key = get_key_mapping(editor.stdscr, key)
                if recording:
                    macros[current].append(key)

        Window version:
            if macro playing:
                key = next macro key
            else:
                raw key comes from event.data
                key = get_key_mapping(self.manager.stdscr, event.data)
                if recording:
                    macros[current].append(key)

        Important:
            This method does NOT call get_wch().
            The WindowManager/editor loop should read the key and dispatch the event.
        """

        if event.type != EventType.KEY:
            return False

        editor = self.editor

        if (
            editor.current_macro_playing_index is not None
            and editor.current_macro_playing_name is not None
        ):
            macro = editor.macros.get(editor.current_macro_playing_name, [])

            if editor.current_macro_playing_index >= len(macro):
                key = None
            else:
                key = macro[editor.current_macro_playing_index]
                editor.current_macro_playing_index += 1

        else:
            key = event.data

            if (
                editor.recording_macro
                and editor.current_macro_recording is not None
                and key is not None
            ):
                editor.macros[editor.current_macro_recording].append(key)

        try:
            curses.flushinp()
        except curses.error:
            pass

        if key is None:
            return True

        if key in ("Up", "k"):
            self.cursor -= 1

            if self.cursor < self.scroll:
                self.scroll = max(0, self.scroll - 1)

        elif key in ("Down", "j"):
            self.cursor += 1

            if self.cursor >= self.scroll + self.win_h:
                self.scroll = min(self.max_scroll, self.scroll + 1)

        elif key == "g":
            self.cursor = 0
            self.scroll = 0

        elif key == "G":
            # Original:
            # cursor = len(entries_full)
            # scroll = max_scroll
            # then cursor is clamped on the next loop.
            self.cursor = len(self.entries_full)
            self.scroll = self.max_scroll

        elif self.is_enter_key(key):
            self.open_selected()

        elif key == "/":
            self.search()

        elif key == "n":
            self.next_match(backwards=False)

        elif key == "N":
            self.next_match(backwards=True)

        elif key == "a":
            self.create_entry()

        elif key == "d":
            self.delete_entry()

        elif key == "r":
            self.rename_entry()

        elif key == "c":
            self.copy_entry()

        elif key == "m":
            self.move_entry()

        elif key == "q" or key == "Ctrl+C" or self.is_escape_key(key):
            self.close()

        self.clamp_cursor_scroll()
        return True

    # ==========================================================
    # Actions
    # ==========================================================

    def selected_name(self) -> str | None:
        if not self.display_entries:
            return None

        if self.cursor < 0 or self.cursor >= len(self.display_entries):
            return None

        return self.display_entries[self.cursor]

    def open_selected(self) -> None:
        if not self.display_entries:
            return

        choice = self.selected_name()

        if not choice:
            return

        if choice == "../":
            parent = self.cwd.parent
            self.cwd = parent if self._is_relative_to(parent, self.base) else self.base

            self.entries_full = self.list_entries_full()
            self.display_entries = self.apply_search(
                self.entries_full,
                self.search_query,
            )
            self.cursor = 0
            self.scroll = 0
            return

        target = self._safe_join(self.cwd, choice)

        # Original only used choice.endswith("/").
        # The _safe_is_dir(target) fallback fixes cases where a directory is detected
        # without the trailing slash being preserved.
        if choice.endswith("/") or self._safe_is_dir(target):
            if self._safe_is_dir(target) and self._has_access_dir(target):
                self.cwd = target

                self.entries_full = self.list_entries_full()
                self.display_entries = self.apply_search(
                    self.entries_full,
                    self.search_query,
                )
                self.cursor = 0
                self.scroll = 0
            else:
                self.notify(
                    message=f"Permission denied: {choice}",
                    duration=2000,
                )

            return

        if not self._has_access_file(target):
            self.notify(
                message=f"Permission denied: {choice}",
                duration=2000,
            )
            return

        try:
            rel = str(target.relative_to(self.base))
        except Exception:
            rel = str(target)

        for b_i, buf in enumerate(self.editor.buffers):
            try:
                if buf.file_name and (
                    buf.file_name == rel or Path(buf.file_name).resolve() == target
                ):
                    self.editor.set_current_buffer(b_i)

                    self.notify(
                        message=f"Switched to buffer: {choice}",
                    )

                    self.close()
                    return

            except Exception:
                continue

        try:
            self.editor.open_buffer(rel)

            self.notify(
                message=f"Opened file: {choice}",
            )

            self.close()

        except Exception as e:
            self.notify(
                message=f"Open failed: {e}",
                duration=0,
            )

    def search(self) -> None:
        prompt = "Search (empty to clear): "

        q_in = send_prompt(
            window=self.manager.stdscr,
            prompt_message=prompt,
            editor=self.editor,
        )

        self.search_query = q_in or ""
        self.display_entries = self.apply_search(
            self.entries_full,
            self.search_query,
        )

        self.jump_to_first_match()

        self.scroll = min(self.scroll, self.max_scroll)
        self.clamp_cursor_scroll()

    def create_entry(self) -> None:
        prompt = "New name (file or dir/): "

        name = send_prompt(
            window=self.manager.stdscr,
            prompt_message=prompt,
            editor=self.editor,
        )

        if name:
            new_path = self._safe_join(self.cwd, name)

            try:
                if name.endswith("/"):
                    new_path.mkdir(parents=True, exist_ok=True)
                else:
                    new_path.parent.mkdir(parents=True, exist_ok=True)

                    if not self._exists_safe(new_path):
                        new_path.touch(exist_ok=False)
                    else:
                        self.notify(
                            message="File already exists.",
                            duration=1200,
                        )

            except FileExistsError:
                self.notify(
                    message="File already exists.",
                    duration=1200,
                )

            except Exception as e:
                self.notify(
                    message=f"Create failed: {e}",
                    duration=2000,
                )

            self.entries_full = self.list_entries_full()
            self.display_entries = self.apply_search(
                self.entries_full,
                self.search_query,
            )

        self.editor.fuzzy_changed = True
        self.clamp_cursor_scroll()

    def delete_entry(self) -> None:
        if not self.display_entries:
            return

        choice = self.selected_name()

        if not choice or choice in ("../",):
            return

        target = self._safe_join(self.cwd, choice)

        if not self._exists_safe(target):
            self.notify(
                message="Target does not exist.",
                duration=1500,
            )
            return

        prompt = f"Delete '{choice}'?"

        if send_prompt_confirm(
            window=self.manager.stdscr,
            prompt_message=prompt,
            color_p=15,
            editor=self.editor,
        ):
            try:
                if self._safe_is_dir(target):
                    shutil.rmtree(target)
                else:
                    target.unlink()

            except Exception as e:
                self.notify(
                    message=f"Delete failed: {e}",
                    duration=2000,
                )

        self.entries_full = self.list_entries_full()
        self.display_entries = self.apply_search(
            self.entries_full,
            self.search_query,
        )
        self.cursor = min(self.cursor, max(0, len(self.display_entries) - 1))
        self.editor.fuzzy_changed = True
        self.clamp_cursor_scroll()

    def rename_entry(self) -> None:
        if not self.display_entries:
            return

        choice = self.selected_name()

        if not choice or choice in ("../",):
            return

        target = self._safe_join(self.cwd, choice)

        if not self._exists_safe(target):
            self.notify(
                message="Target does not exist.",
                duration=1500,
            )
            return

        clean_choice = choice[:-1] if choice.endswith("/") else choice

        new_name = send_prompt(
            window=self.manager.stdscr,
            prompt_message="Rename: ",
            current_value=clean_choice,
            editor=self.editor,
        )

        if new_name:
            dest = self._safe_join(target.parent, new_name)

            if not self._is_relative_to(dest, self.base):
                self.notify(
                    message="Operation blocked outside base dir.",
                    duration=2000,
                )
            else:
                try:
                    target.rename(dest)

                    for buf in self.editor.buffers:
                        try:
                            if (
                                buf.file_name
                                and Path(buf.file_name).resolve() == target
                            ):
                                try:
                                    buf.file_name = str(dest.relative_to(self.base))
                                except Exception:
                                    buf.file_name = str(dest)

                                break

                        except Exception:
                            continue

                except Exception as e:
                    self.notify(
                        message=f"Rename failed: {e}",
                        duration=2000,
                    )

            self.entries_full = self.list_entries_full()
            self.display_entries = self.apply_search(
                self.entries_full,
                self.search_query,
            )

        self.editor.fuzzy_changed = True
        self.clamp_cursor_scroll()

    def copy_entry(self) -> None:
        if not self.display_entries:
            return

        choice = self.selected_name()

        if not choice or choice in ("../",):
            return

        source = self._safe_join(self.cwd, choice)

        if not self._exists_safe(source):
            self.notify(
                message="Source does not exist.",
                duration=1500,
            )
            return

        prompt = f"Copy '{choice}' to (path): "

        dest_in = send_prompt(
            window=self.manager.stdscr,
            prompt_message=prompt,
            editor=self.editor,
        )

        if not dest_in:
            return

        dest_path_typed = Path(dest_in)

        dest = (
            self._safe_join(self.cwd, dest_in).resolve()
            if not dest_path_typed.is_absolute()
            else dest_path_typed.resolve()
        )

        if source.is_dir():
            dest = dest / source.name

        if not self._is_relative_to(dest, self.base):
            self.notify(
                message="Operation blocked outside base dir.",
                duration=2000,
            )
            return

        try:
            if dest.exists():
                prompt = f"'{dest.name}' exists. Overwrite?"

                if not send_prompt_confirm(
                    window=self.manager.stdscr,
                    prompt_message=prompt,
                    editor=self.editor,
                ):
                    self.notify(
                        message="Copy cancelled.",
                        duration=1500,
                    )
                    return

                if dest.is_dir():
                    shutil.rmtree(dest)
                else:
                    dest.unlink()

            if source.is_dir():
                shutil.copytree(source, dest)
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, dest)

            self.notify(
                message=f"Copied to {dest}",
                duration=1800,
            )

        except Exception as e:
            self.notify(
                message=f"Copy failed: {e}",
                duration=2500,
            )

        self.entries_full = self.list_entries_full()
        self.display_entries = self.apply_search(
            self.entries_full,
            self.search_query,
        )
        self.cursor = min(self.cursor, max(0, len(self.display_entries) - 1))
        self.editor.fuzzy_changed = True
        self.clamp_cursor_scroll()

    def move_entry(self) -> None:
        if not self.display_entries:
            return

        choice = self.selected_name()

        if not choice or choice in ("../",):
            return

        target = self._safe_join(self.cwd, choice)

        if not self._exists_safe(target):
            self.notify(
                message="Target does not exist.",
                duration=1500,
            )
            return

        prompt = f"Move '{choice}' to (path): "

        dest_in = send_prompt(
            window=self.manager.stdscr,
            prompt_message=prompt,
            editor=self.editor,
        )

        if not dest_in:
            return

        def _abs(p: str | Path) -> Path:
            p = Path(p)

            if p.is_absolute():
                return p.resolve()

            return (Path(self.editor.working_dir) / p).resolve()

        def _rel_to_base(p: Path) -> str:
            base = Path(self.editor.working_dir).resolve()

            try:
                return str(p.resolve().relative_to(base))
            except Exception:
                return str(p.resolve())

        def rel_smart(p: Path) -> str:
            p = p.resolve()

            work = Path(self.editor.working_dir).resolve()
            cwd_base = Path(self.cwd).resolve()

            try:
                return str(p.relative_to(work))
            except ValueError:
                pass

            try:
                return str(p.relative_to(cwd_base))
            except ValueError:
                pass

            return str(p)

        def rebase_path(path: Path, old_root: Path, new_root: Path) -> Path:
            path = path.resolve()
            old_root = old_root.resolve()
            new_root = new_root.resolve()

            try:
                sub = path.relative_to(old_root)
            except ValueError:
                return path

            return (new_root / sub).resolve()

        def remap_after_move(path: Path, old: Path, new: Path) -> Path:
            path = path.resolve()
            old = old.resolve()
            new = new.resolve()

            if old.is_dir():
                return rebase_path(path, old, new)

            return new if path == old else path

        dest_path_typed = Path(dest_in)

        dest = (
            self._safe_join(self.cwd, dest_in).resolve()
            if not dest_path_typed.is_absolute()
            else dest_path_typed.resolve()
        )

        if target.is_dir():
            dest = dest / target.name

        if not self._is_relative_to(dest, self.base):
            self.notify(
                message="Operation blocked outside base dir.",
                duration=2000,
            )
        else:
            try:
                dest.parent.mkdir(parents=True, exist_ok=True)

                old_abs = target.resolve()
                new_abs = dest.resolve()

                if old_abs.is_dir():
                    for buf in self.editor.buffers:
                        fn = getattr(buf, "file_name", None)

                        if not fn:
                            continue

                        buf_abs = _abs(fn)

                        try:
                            buf_abs.relative_to(old_abs)
                        except ValueError:
                            continue

                        new_buf_abs = remap_after_move(buf_abs, old_abs, new_abs)
                        buf.file_path = new_buf_abs
                        buf.file_name = _rel_to_base(new_buf_abs)

                else:
                    if dest.exists() and dest.is_dir():
                        dest = dest / target.name

                    old_abs = target.resolve()
                    new_abs = dest.resolve()

                    for buf in self.editor.buffers:
                        fn = getattr(buf, "file_name", None)

                        if not fn:
                            continue

                        buf_abs = _abs(fn)

                        if buf_abs == old_abs:
                            buf.file_path = new_abs
                            buf.file_name = rel_smart(new_abs)
                            break

                shutil.move(str(old_abs), str(new_abs))

            except Exception as e:
                self.notify(
                    message=f"Move failed: {e}",
                    duration=2000,
                )

        self.entries_full = self.list_entries_full()
        self.display_entries = self.apply_search(
            self.entries_full,
            self.search_query,
        )
        self.cursor = min(self.cursor, max(0, len(self.display_entries) - 1))
        self.editor.fuzzy_changed = True
        self.clamp_cursor_scroll()

    # ==========================================================
    # Utility
    # ==========================================================

    def notify(self, message: str, duration: int = 1200) -> None:
        send_notification(
            window=self.manager.stdscr,
            message=message,
            duration=duration,
            editor=self.editor,
        )

    def close(self) -> None:
        self.manager.remove_window(self)
        self.editor.adjust_scroll()
