from __future__ import annotations

import curses
import string
from typing import Any, Optional

FUNC_KEYS: dict[int | str, str] = {
    265: "F1",
    266: "F2",
    267: "F3",
    268: "F4",
    269: "F5",
    270: "F6",
    271: "F7",
    272: "F8",
    273: "F9",
    274: "F10",
    275: "F11",
    276: "F12",
}

SPECIAL_KEYS: dict[int | str, str] = {
    **FUNC_KEYS,
    339: "PageUp",
    338: "PageDown",
    262: "Home",
    360: "End",
    330: "Delete",
    263: "Backspace",
    343: "Enter",
}

MOUSE_BUTTONS: dict[int | str, str] = {}

CTRL_KEYS: dict[int | str, str] = {
    **{chr(i): f"Ctrl+{chr(i + 64)}" for i in range(1, 27)},  # Ctrl+A–Z
}

ARROW_KEYS: dict[int | str, str] = {
    259: "Up",
    258: "Down",
    260: "Left",
    261: "Right",
}

CTRL_ARROW_KEYS: dict[int | str, str] = {
    "[1;5D": "Ctrl+Left",
    "[1;5C": "Ctrl+Right",
    "[1;5A": "Ctrl+Up",
    "[1;5B": "Ctrl+Down",
    546: "Ctrl+Left",
    561: "Ctrl+Right",
    567: "Ctrl+Up",
    526: "Ctrl+Down",
}

ALT_ARROW_KEYS: dict[int | str, str] = {
    "[1;3D": "Alt+Left",
    "[1;3C": "Alt+Right",
    "[1;3A": "Alt+Up",
    "[1;3B": "Alt+Down",
    544: "Alt+Left",
    559: "Alt+Right",
    565: "Alt+Up",
    524: "Alt+Down",
}

SHIFT_ARROW_KEYS: dict[int | str, str] = {
    "[1;2D": "Shift+Left",
    "[1;2C": "Shift+Right",
    "[1;2A": "Shift+Up",
    "[1;2B": "Shift+Down",
    # with numbers
    393: "Shift+Left",
    402: "Shift+Right",
    337: "Shift+Up",
    336: "Shift+Down",
}

CTRL_SHIFT_ARROW_KEYS: dict[int | str, str] = {
    "[1;6A": "Ctrl+Shift+Up",
    "[1;6B": "Ctrl+Shift+Down",
    "[1;6C": "Ctrl+Shift+Right",
    "[1;6D": "Ctrl+Shift+Left",
    547: "Ctrl+Shift+Left",
    562: "Ctrl+Shift+Right",
}

CTRL_ALT_ARROW_KEYS: dict[int | str, str] = {
    "[1;7A": "Ctrl+Alt+Up",
    "[1;7B": "Ctrl+Alt+Down",
    "[1;7C": "Ctrl+Alt+Right",
    "[1;7D": "Ctrl+Alt+Left",
    548: "Ctrl+Alt+Left",
    563: "Ctrl+Alt+Right",
    569: "Ctrl+Alt+Up",
    528: "Ctrl+Alt+Down",
}

ARROW_KEYS_MAPPING: dict[int | str, str] = {
    **ARROW_KEYS,
    **CTRL_ARROW_KEYS,
    **ALT_ARROW_KEYS,
    **SHIFT_ARROW_KEYS,
    **CTRL_SHIFT_ARROW_KEYS,
    **CTRL_ALT_ARROW_KEYS,
}

ALT_KEYS: dict[str, str] = {
    **{chr(i): f"Alt+{chr(i)}" for i in range(ord("a"), ord("z") + 1)},
    **{chr(i): f"Alt+{chr(i)}" for i in range(ord("A"), ord("Z") + 1)},
    **{str(i): f"Alt+{i}" for i in range(10)},  # Alt+0–9
    **{c: f"Alt+{c}" for c in "-=,./;'[]\\`"},  # Common punctuation
}

TAB_KEY_FUNC = lambda key: key in (9, "\t", "Ctrl+I", "Tab")
SHIFT_TAB_KEY = 353

PAIRS = {"(": ")", "[": "]", "{": "}", "'": "'", '"': '"'}

BRACKETS = set("()[]{}")
BRACKET_PAIRS = {"(": ")", "[": "]", "{": "}"}
REVERSE_BRACKET_PAIRS = {v: k for k, v in BRACKET_PAIRS.items()}


def get_key_mapping(window: curses.window, key: int | str | None) -> int | str | None:
    if key is None:
        return key

    if isinstance(key, str) and key in CTRL_KEYS:
        key = CTRL_KEYS[key]

    elif key == "\x1b":  # ESC
        _seq = [""]

        window.timeout(0)  # make getch() non-blocking

        try:
            for _ in range(5):
                ch = window.get_wch()
                if isinstance(ch, str):
                    _seq.append(ch)
                else:
                    break

        except Exception:
            pass

        finally:
            # window.nodelay(False)
            seq = "".join(_seq)

        if len(seq) == 1 and seq in ALT_KEYS:
            key = ALT_KEYS[seq]

        elif seq in ARROW_KEYS_MAPPING:
            key = ARROW_KEYS_MAPPING[seq]

        else:
            key = "ESC"

    elif isinstance(key, int):
        if key in ARROW_KEYS_MAPPING:
            key = ARROW_KEYS_MAPPING[key]

        elif key in SPECIAL_KEYS:
            key = SPECIAL_KEYS[key]

    return key
