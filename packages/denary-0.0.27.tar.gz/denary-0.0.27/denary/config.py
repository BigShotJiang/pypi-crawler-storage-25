import importlib.util
import json
import os
import sys
from pathlib import Path
from typing import Any, TypedDict

from platformdirs import user_config_dir

from denary.lsp.client import LSPClient

EDITOR_NAME = "denary"


class LSPConfig(TypedDict):
    cmd: list[str]
    settings: dict[str, Any]


LSP_CONFIG: dict[str, LSPConfig] = {}
EXT_TO_LANG: dict[str, str] = {}

LOADING_LSPS: set[str] = set()
LOADED_LSPS: dict[str, LSPClient] = {}

STATIC_CONFIG: dict[str, Any] = {}
CURRENT_PLATFORM = sys.platform.lower()

MAX_UNDO = 2_000

MAX_LINE_LIMIT = 500
MAX_SCAN_LINES = 5_000

WORKING_DIR = Path(".")


def get_config_path() -> str:
    config_dir = user_config_dir(EDITOR_NAME)
    return os.path.join(config_dir, "init.py")


def get_config_dir() -> Path:
    config_dir = user_config_dir(EDITOR_NAME)
    if not os.path.exists(config_dir):
        os.makedirs(config_dir, exist_ok=True)
    return Path(config_dir)


CONFIG_PATH = get_config_path()
STATIC_CONFIG_PATH = get_config_dir() / "static_config.json"


def load_user_lsp_config(
    config_path: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    global LSP_CONFIG, EXT_TO_LANG

    if config_path is None:
        config_path = CONFIG_PATH

    if not os.path.exists(config_path):
        return {}, {}

    spec = importlib.util.spec_from_file_location("user_lspconfig", config_path)

    if spec is not None and spec.loader is not None:
        mod = importlib.util.module_from_spec(spec)

        if mod is not None:
            spec.loader.exec_module(mod)

            LSP_CONFIG, EXT_TO_LANG = getattr(mod, "LSP_CONFIG", {}), getattr(
                mod, "EXT_TO_LANG", {}
            )

    return LSP_CONFIG, EXT_TO_LANG


def save_static_config() -> None:
    global STATIC_CONFIG

    with STATIC_CONFIG_PATH.open("w") as f:
        f.write(json.dumps(STATIC_CONFIG))


def load_static_config() -> None:
    global STATIC_CONFIG

    if STATIC_CONFIG_PATH.exists():
        with STATIC_CONFIG_PATH.open() as f:
            STATIC_CONFIG = json.loads(f.read())


if __name__ == "__main__":
    # Example: find config path (use platformdirs or fallback as above)
    user_lsp_config, user_ext_to_lang = load_user_lsp_config(CONFIG_PATH)
    print(CONFIG_PATH)
    print(os.path.exists(CONFIG_PATH))
    print(user_lsp_config)
    print(user_ext_to_lang)
