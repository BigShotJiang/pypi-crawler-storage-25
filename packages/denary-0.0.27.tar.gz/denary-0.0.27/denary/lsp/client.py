import asyncio
import json
import os
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any, Optional, Protocol

from denary import events
from denary.events import Event, EventType, LSPEventType


class LSPClienteProtocol(Protocol):
    def did_open(self, uri: str, text: str): ...

    def did_close(self, uri: str): ...

    def did_change(self, uri: str, text: str): ...

    def did_change_diffs(self, uri: str, changes: list[dict[str, Any]]): ...

    def did_save(self, uri: str, text: Optional[str] = None): ...

    def hover(self, uri, line, character): ...

    def completion(self, uri, line, character, trigger_character=None): ...

    def code_action(self, uri, line, character, diagnostics=None, only=None): ...

    def definition(self, uri, line, character): ...

    def references(self, uri, line, character, include_declaration=True): ...

    def document_symbols(self, uri): ...

    def formatting(self, uri, options=None): ...

    def rename(self, uri, line, character, new_name): ...


class LSPNotReady(Exception):
    pass


class LSPClientClosed(Exception):
    pass


@dataclass(slots=True)
class DocumentState:
    opened: bool = False
    initial_text: Optional[str] = None
    pending: deque[tuple[str, dict[str, Any]]] = field(default_factory=deque)


class LSPClient(LSPClienteProtocol):
    def __init__(
        self,
        server_cmd: list[str],
        root_uri: str,
        language_id: str = "plaintext",
        initialize_settings: Any = None,
        debug: bool = False,
    ) -> None:
        self.server_cmd = server_cmd
        self.root_uri = root_uri if root_uri.endswith("/") else root_uri + "/"
        self.language_id = language_id
        self.initialize_settings = initialize_settings or {}
        self.debug = debug

        self.proc: Optional[asyncio.subprocess.Process] = None
        self._stdin: Optional[asyncio.StreamWriter] = None
        self._stdout: Optional[asyncio.StreamReader] = None
        self._stderr: Optional[asyncio.StreamReader] = None

        self._next_id = 1
        self._pending: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._buffer = b""
        self._write_lock: Optional[asyncio.Lock] = None

        self._ready = False
        self._init_started = False
        self._dead = False
        self._closed = False

        self._ready_event: Optional[asyncio.Event] = None
        self._stdout_task: Optional[asyncio.Task[None]] = None
        self._stderr_task: Optional[asyncio.Task[None]] = None
        self._initializing_task: Optional[asyncio.Task[None]] = None
        self._command_task: Optional[asyncio.Task[None]] = None

        self.server_caps: dict[str, Any] = {}
        self.textDocumentSync = 2
        self.triggerCharacters: set[str] = set()

        self._open_versions: dict[str, int] = {}
        self._uri_state: defaultdict[str, DocumentState] = defaultdict(DocumentState)
        self.diagnostics: dict[str, list[Any]] = {}

        self.command_queue: asyncio.Queue[Event] = asyncio.Queue(maxsize=1000)

    @classmethod
    async def create(
        cls,
        server_cmd: list[str],
        root_uri: str,
        language_id: str = "plaintext",
        initialize_settings: Any = None,
        debug: bool = False,
    ) -> "LSPClient":
        self = cls(
            server_cmd=server_cmd,
            root_uri=root_uri,
            language_id=language_id,
            initialize_settings=initialize_settings,
            debug=debug,
        )

        self._write_lock = asyncio.Lock()
        self._ready_event = asyncio.Event()

        await self._async_start()

        self._initializing_task = asyncio.create_task(self._ensure_initialized_async())
        self._command_task = asyncio.create_task(self._command_loop())

        return self

    async def send_event(self, event: Event) -> None:
        await self.command_queue.put(event)

    def send_event_nowait(self, event: Event) -> None:
        self.command_queue.put_nowait(event)

    def is_ready(self) -> bool:
        return self._ready and not self._dead and not self._closed

    def is_dead(self) -> bool:
        return self._dead or self._closed

    async def wait_until_ready(self, timeout: Optional[float] = None) -> None:
        if self._dead:
            raise RuntimeError("LSP client is dead")

        if self._ready:
            return

        if self._ready_event is None:
            raise RuntimeError("Client not initialized correctly")

        if timeout is None:
            await self._ready_event.wait()
        else:
            await asyncio.wait_for(self._ready_event.wait(), timeout=timeout)

        if self._dead:
            raise RuntimeError("LSP client died during initialization")

    async def _emit_to_global_queue(
        self,
        event_type: EventType,
        data: Any = None,
    ) -> None:
        try:
            events.EVENT_QUEUE.put_nowait(Event(type=event_type, data=data))
        except asyncio.QueueFull:
            if self.debug:
                print(f"[GLOBAL EVENT DROPPED] {event_type.name}")

    async def _async_start(self) -> None:
        self.proc = await asyncio.create_subprocess_exec(
            *self.server_cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        self._stdin = self.proc.stdin
        self._stdout = self.proc.stdout
        self._stderr = self.proc.stderr

        if self._stdin is None or self._stdout is None or self._stderr is None:
            raise RuntimeError("Failed to open LSP pipes")

        self._stdout_task = asyncio.create_task(self._stdout_reader())
        self._stderr_task = asyncio.create_task(self._stderr_reader())

    async def _send_async(
        self,
        method: str,
        params: Optional[dict[str, Any]] = None,
        *,
        is_request: bool = True,
    ) -> Optional[int]:
        if self._dead or self._closed:
            return None

        if self._stdin is None or self._write_lock is None:
            raise RuntimeError("LSP client is not started")

        msg: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        msg_id: Optional[int] = None

        if is_request:
            msg_id = self._next_id
            self._next_id += 1
            msg["id"] = msg_id

        if params is not None:
            msg["params"] = params

        raw = json.dumps(msg, ensure_ascii=False).encode("utf-8")
        header = f"Content-Length: {len(raw)}\r\n\r\n".encode("utf-8")

        if is_request and msg_id is not None:
            self._pending[msg_id] = asyncio.get_running_loop().create_future()

        async with self._write_lock:
            self._stdin.write(header + raw)
            await self._stdin.drain()

        if self.debug:
            print(">>>", msg)

        return msg_id

    async def _wait_async(
        self,
        msg_id: int,
        timeout: float = 30,
    ) -> dict[str, Any]:
        fut = self._pending.get(msg_id)
        if fut is None:
            raise RuntimeError(f"No pending future for request id {msg_id}")

        try:
            return await asyncio.wait_for(fut, timeout=timeout)
        finally:
            self._pending.pop(msg_id, None)

    async def _send_response_async(self, msg_id: int, result: Any) -> None:
        if self._dead or self._closed:
            return

        if self._stdin is None or self._write_lock is None:
            raise RuntimeError("LSP client is not started")

        resp = {"jsonrpc": "2.0", "id": msg_id, "result": result}
        raw = json.dumps(resp, ensure_ascii=False).encode("utf-8")
        header = f"Content-Length: {len(raw)}\r\n\r\n".encode("utf-8")

        async with self._write_lock:
            self._stdin.write(header + raw)
            await self._stdin.drain()

        if self.debug:
            print(">>>", resp)

    async def _stderr_reader(self) -> None:
        if self._stderr is None:
            return

        try:
            while not self._dead and not self._closed:
                line = await self._stderr.readline()
                if not line:
                    return

                if self.debug:
                    print("[LSP STDERR]", line.decode(errors="replace").rstrip())

        except asyncio.CancelledError:
            raise
        except Exception:
            self._dead = True

    async def _stdout_reader(self) -> None:
        if self._stdout is None:
            return

        try:
            while not self._dead and not self._closed:
                chunk = await self._stdout.read(4096)
                if not chunk:
                    self._dead = True
                    return

                self._buffer += chunk

                while True:
                    sep = self._buffer.find(b"\r\n\r\n")
                    if sep < 0:
                        break

                    header = self._buffer[:sep].decode(errors="replace")
                    length: Optional[int] = None

                    for line in header.split("\r\n"):
                        if line.lower().startswith("content-length:"):
                            length = int(line.split(":", 1)[1].strip())
                            break

                    if length is None:
                        self._buffer = self._buffer[sep + 4 :]
                        continue

                    total = sep + 4 + length
                    if len(self._buffer) < total:
                        break

                    body = self._buffer[sep + 4 : total]
                    self._buffer = self._buffer[total:]

                    msg = json.loads(body.decode("utf-8"))
                    if self.debug:
                        print("<<<", msg)

                    await self._dispatch_async(msg)

        except asyncio.CancelledError:
            raise
        except Exception:
            self._dead = True

    async def _dispatch_async(self, msg: Any) -> None:
        if not isinstance(msg, dict):
            return

        if "id" in msg and "method" not in msg:
            fut = self._pending.get(msg["id"])
            if fut is not None and not fut.done():
                fut.set_result(msg)
            return

        method = msg.get("method")
        params = msg.get("params", {})

        if method == "textDocument/publishDiagnostics":
            uri = params.get("uri")
            if uri:
                diagnostics = params.get("diagnostics", [])
                self.diagnostics[uri] = diagnostics
                await self._emit_to_global_queue(
                    EventType.LSP_DIAGNOSTICS_UPDATED,
                    {"uri": uri, "diagnostics": diagnostics},
                )
            return

        if method and "id" in msg:
            await self._handle_request_async(method, params, msg["id"])

    async def _handle_request_async(
        self,
        method: str,
        params: dict[str, Any],
        msg_id: int,
    ) -> None:
        if method == "workspace/configuration":
            items = params.get("items", []) if params else []
            await self._send_response_async(
                msg_id,
                [self.initialize_settings for _ in items],
            )
        else:
            await self._send_response_async(msg_id, None)

    async def _ensure_initialized_async(self) -> None:
        if self._ready or self._dead or self._closed or self._init_started:
            return

        self._init_started = True

        client_caps = {
            "textDocument": {
                "synchronization": {"didSave": True, "dynamicRegistration": False},
                "textDocumentSync": 2,
                "publishDiagnostics": {
                    "relatedInformation": True,
                    "versionSupport": True,
                },
                "hover": {"contentFormat": ["markdown", "plaintext"]},
                "completion": {"dynamicRegistration": False},
                "definition": {"dynamicRegistration": False},
                "references": {"dynamicRegistration": False},
                "documentSymbol": {"dynamicRegistration": False},
                "formatting": {"dynamicRegistration": False},
                "rename": {"dynamicRegistration": False},
                "codeAction": {"dynamicRegistration": False},
            },
            "workspace": {
                "configuration": True,
                "workspaceFolders": True,
            },
        }

        init_id = await self._send_async(
            "initialize",
            {
                "processId": os.getpid(),
                "rootUri": self.root_uri,
                "capabilities": client_caps,
                "initializationOptions": self.initialize_settings,
                "workspaceFolders": [{"uri": self.root_uri, "name": "workspace"}],
                "clientInfo": {"name": "TinyPyLSPClient", "version": "0.6"},
            },
            is_request=True,
        )

        if init_id is None:
            self._dead = True
            if self._ready_event is not None:
                self._ready_event.set()
            raise RuntimeError("Failed to send initialize request")

        resp = await self._wait_async(init_id, timeout=120)

        self.server_caps = resp.get("result", {}).get("capabilities", {}) or {}

        self.triggerCharacters = set(
            self.server_caps.get("completionProvider", {}).get("triggerCharacters", [])
        )

        sync = self.server_caps.get("textDocumentSync", 2)
        if isinstance(sync, dict):
            self.textDocumentSync = int(sync.get("change", 2) or 2)
        else:
            self.textDocumentSync = int(sync or 2)

        await self._send_async("initialized", {}, is_request=False)

        if self.initialize_settings:
            await self._send_async(
                "workspace/didChangeConfiguration",
                {"settings": self.initialize_settings},
                is_request=False,
            )

        self._ready = True
        if self._ready_event is not None:
            self._ready_event.set()

        await self._flush_queued_async()

    async def _flush_queued_async(self) -> None:
        for uri, st in list(self._uri_state.items()):
            if not st.opened and st.initial_text is not None:
                await self._did_open_async(uri, st.initial_text)

            while st.pending:
                method, params = st.pending.popleft()

                if method == "textDocument/didChange":
                    ver = self._open_versions.get(uri, 1) + 1
                    self._open_versions[uri] = ver
                    params["textDocument"]["version"] = ver

                await self._send_async(method, params, is_request=False)

    async def _did_open_async(self, uri: str, text: str) -> None:
        st = self._uri_state[uri]

        if st.initial_text is None:
            st.initial_text = text

        if not self._ready or st.opened:
            return

        ver = self._open_versions.get(uri, 0) + 1
        self._open_versions[uri] = ver

        await self._send_async(
            "textDocument/didOpen",
            {
                "textDocument": {
                    "uri": uri,
                    "languageId": self.language_id,
                    "version": ver,
                    "text": text,
                }
            },
            is_request=False,
        )
        st.opened = True

    async def _did_change_async(self, uri: str, text: str) -> None:
        st = self._uri_state[uri]

        if st.initial_text is None:
            st.initial_text = text

        params: dict[str, Any] = {
            "textDocument": {"uri": uri},
            "contentChanges": [{"text": text}],
        }

        if self._ready and st.opened:
            ver = self._open_versions.get(uri, 1) + 1
            self._open_versions[uri] = ver
            params["textDocument"]["version"] = ver
            await self._send_async("textDocument/didChange", params, is_request=False)
        else:
            st.pending.append(("textDocument/didChange", params))

    async def _did_change_diffs_async(
        self,
        uri: str,
        changes: list[dict[str, Any]],
    ) -> None:
        st = self._uri_state[uri]

        params: dict[str, Any] = {
            "textDocument": {"uri": uri},
            "contentChanges": changes,
        }

        if self._ready and st.opened:
            ver = self._open_versions.get(uri, 1) + 1
            self._open_versions[uri] = ver
            params["textDocument"]["version"] = ver
            await self._send_async("textDocument/didChange", params, is_request=False)
        else:
            st.pending.append(("textDocument/didChange", params))

    async def _did_save_async(self, uri: str, text: Optional[str] = None) -> None:
        self.diagnostics[uri] = []

        params: dict[str, Any] = {"textDocument": {"uri": uri}}
        if text is not None:
            params["text"] = text

        if self._ready:
            await self._send_async("textDocument/didSave", params, is_request=False)
        else:
            self._uri_state[uri].pending.append(("textDocument/didSave", params))

    async def _did_close_async(self, uri: str) -> None:
        if self._ready:
            await self._send_async(
                "textDocument/didClose",
                {"textDocument": {"uri": uri}},
                is_request=False,
            )

        self._open_versions.pop(uri, None)
        self._uri_state.pop(uri, None)
        self.diagnostics.pop(uri, None)

    async def _request_async(
        self,
        method: str,
        params: dict[str, Any],
        timeout: float = 30,
    ) -> dict[str, Any]:
        if not self._ready:
            raise LSPNotReady("LSP server is not ready yet")

        if self._dead or self._closed:
            raise LSPClientClosed("LSP client is closed")

        msg_id = await self._send_async(method, params, is_request=True)
        if msg_id is None:
            raise LSPClientClosed("Failed to send request because client is closed")

        return await self._wait_async(msg_id, timeout)

    async def _command_loop(self) -> None:
        try:
            while not self._closed and not self._dead:
                event = await self.command_queue.get()

                try:
                    await self._handle_command_event(event)
                except Exception as ex:
                    await self._emit_to_global_queue(
                        EventType.LSP_REQUEST_FAILED,
                        {
                            "request_type": event.type.name,
                            "request_data": event.data,
                            "error": repr(ex),
                        },
                    )
                finally:
                    self.command_queue.task_done()

        except asyncio.CancelledError:
            raise

    async def _handle_command_event(self, event: Event) -> None:
        data = event.data or {}

        await self._emit_to_global_queue(
            EventType.LSP_REQUEST_STARTED,
            {
                "request_type": event.type.name,
                "request_data": data,
            },
        )

        result: Any = None

        match event.type:
            case LSPEventType.TEXT_DOCUMENT_DID_OPEN:
                await self._did_open_async(data["uri"], data["text"])
                result = {"ok": True}

            case LSPEventType.TEXT_DOCUMENT_DID_CHANGE:
                if data.get("use_diffs"):
                    await self._did_change_diffs_async(data["uri"], data["changes"])
                else:
                    await self._did_change_async(data["uri"], data["text"])
                result = {"ok": True}

            case LSPEventType.TEXT_DOCUMENT_DID_SAVE:
                await self._did_save_async(data["uri"], data.get("text"))
                result = {"ok": True}

            case LSPEventType.TEXT_DOCUMENT_DID_CLOSE:
                await self._did_close_async(data["uri"])
                result = {"ok": True}

            case LSPEventType.TEXT_DOCUMENT_HOVER:
                result = await self._request_async(
                    "textDocument/hover",
                    {
                        "textDocument": {"uri": data["uri"]},
                        "position": {
                            "line": data["line"],
                            "character": data["character"],
                        },
                    },
                )

            case LSPEventType.TEXT_DOCUMENT_COMPLETION:
                trigger_character = data.get("trigger_character")
                ctx: dict[str, Any] = {"triggerKind": 1}
                if trigger_character is not None:
                    ctx = {"triggerKind": 2, "triggerCharacter": trigger_character}

                result = await self._request_async(
                    "textDocument/completion",
                    {
                        "textDocument": {"uri": data["uri"]},
                        "position": {
                            "line": data["line"],
                            "character": data["character"],
                        },
                        "context": ctx,
                    },
                )

            case LSPEventType.TEXT_DOCUMENT_DEFINITION:
                result = await self._request_async(
                    "textDocument/definition",
                    {
                        "textDocument": {"uri": data["uri"]},
                        "position": {
                            "line": data["line"],
                            "character": data["character"],
                        },
                    },
                )

            case LSPEventType.TEXT_DOCUMENT_REFERENCES:
                result = await self._request_async(
                    "textDocument/references",
                    {
                        "textDocument": {"uri": data["uri"]},
                        "position": {
                            "line": data["line"],
                            "character": data["character"],
                        },
                        "context": {
                            "includeDeclaration": data.get("include_declaration", True),
                        },
                    },
                )

            case LSPEventType.TEXT_DOCUMENT_DOCUMENT_SYMBOL:
                result = await self._request_async(
                    "textDocument/documentSymbol",
                    {
                        "textDocument": {"uri": data["uri"]},
                    },
                )

            case LSPEventType.TEXT_DOCUMENT_FORMATTING:
                result = await self._request_async(
                    "textDocument/formatting",
                    {
                        "textDocument": {"uri": data["uri"]},
                        "options": data.get(
                            "options",
                            {"tabSize": 4, "insertSpaces": True},
                        ),
                    },
                )

            case LSPEventType.TEXT_DOCUMENT_RENAME:
                result = await self._request_async(
                    "textDocument/rename",
                    {
                        "textDocument": {"uri": data["uri"]},
                        "position": {
                            "line": data["line"],
                            "character": data["character"],
                        },
                        "newName": data["new_name"],
                    },
                )

            case LSPEventType.TEXT_DOCUMENT_CODE_ACTION:
                rng = {
                    "start": {
                        "line": data["line"],
                        "character": data["character"],
                    },
                    "end": {
                        "line": data["line"],
                        "character": data["character"],
                    },
                }
                ctx = {"diagnostics": data.get("diagnostics", [])}
                if data.get("only"):
                    ctx["only"] = data["only"]

                result = await self._request_async(
                    "textDocument/codeAction",
                    {
                        "textDocument": {"uri": data["uri"]},
                        "range": rng,
                        "context": ctx,
                    },
                )

            case _:
                raise RuntimeError(f"Unsupported LSP event: {event.type.name}")

        await self._emit_to_global_queue(
            EventType.LSP_REQUEST_COMPLETED,
            {
                "request_type": event.type,
                "request_data": data,
                "result": result,
            },
        )

    def did_open(self, uri: str, text: str) -> None:
        self.send_event_nowait(
            Event(
                LSPEventType.TEXT_DOCUMENT_DID_OPEN,
                {
                    "uri": uri,
                    "text": text,
                },
            )
        )

    def did_close(self, uri: str) -> None:
        self.send_event_nowait(
            Event(
                LSPEventType.TEXT_DOCUMENT_DID_CLOSE,
                {
                    "uri": uri,
                },
            )
        )

    def did_change(self, uri: str, text: str) -> None:
        self.send_event_nowait(
            Event(
                LSPEventType.TEXT_DOCUMENT_DID_CHANGE,
                {
                    "uri": uri,
                    "text": text,
                },
            )
        )

    def did_change_diffs(self, uri: str, changes: list[dict[str, Any]]) -> None:
        self.send_event_nowait(
            Event(
                LSPEventType.TEXT_DOCUMENT_DID_CHANGE,
                {
                    "uri": uri,
                    "changes": changes,
                    "use_diffs": True,
                },
            )
        )

    def did_save(self, uri: str, text: Optional[str] = None) -> None:
        self.send_event_nowait(
            Event(
                LSPEventType.TEXT_DOCUMENT_DID_SAVE,
                {
                    "uri": uri,
                    "text": text,
                },
            )
        )

    def hover(self, uri: str, line: int, character: int) -> None:
        self.send_event_nowait(
            Event(
                LSPEventType.TEXT_DOCUMENT_HOVER,
                {
                    "uri": uri,
                    "line": line,
                    "character": character,
                },
            )
        )

    def completion(
        self,
        uri: str,
        line: int,
        character: int,
        trigger_character: Optional[str] = None,
    ) -> None:
        self.send_event_nowait(
            Event(
                LSPEventType.TEXT_DOCUMENT_COMPLETION,
                {
                    "uri": uri,
                    "line": line,
                    "character": character,
                    "trigger_character": trigger_character,
                },
            )
        )

    def code_action(
        self,
        uri: str,
        line: int,
        character: int,
        diagnostics: Optional[list[dict[str, Any]]] = None,
        only: Optional[list[str]] = None,
    ) -> None:
        self.send_event_nowait(
            Event(
                LSPEventType.TEXT_DOCUMENT_CODE_ACTION,
                {
                    "uri": uri,
                    "line": line,
                    "character": character,
                    "diagnostics": diagnostics,
                    "only": only,
                },
            )
        )

    def definition(self, uri: str, line: int, character: int) -> None:
        self.send_event_nowait(
            Event(
                LSPEventType.TEXT_DOCUMENT_DEFINITION,
                {
                    "uri": uri,
                    "line": line,
                    "character": character,
                },
            )
        )

    def references(
        self,
        uri: str,
        line: int,
        character: int,
        include_declaration: bool = True,
    ) -> None:
        self.send_event_nowait(
            Event(
                LSPEventType.TEXT_DOCUMENT_REFERENCES,
                {
                    "uri": uri,
                    "line": line,
                    "character": character,
                    "include_declaration": include_declaration,
                },
            )
        )

    def document_symbols(self, uri: str) -> None:
        self.send_event_nowait(
            Event(
                LSPEventType.TEXT_DOCUMENT_DOCUMENT_SYMBOL,
                {
                    "uri": uri,
                },
            )
        )

    def formatting(self, uri: str, options: Optional[dict[str, Any]] = None) -> None:
        self.send_event_nowait(
            Event(
                LSPEventType.TEXT_DOCUMENT_FORMATTING,
                {
                    "uri": uri,
                    "options": options,
                },
            )
        )

    def rename(self, uri: str, line: int, character: int, new_name: str) -> None:
        self.send_event_nowait(
            Event(
                LSPEventType.TEXT_DOCUMENT_RENAME,
                {
                    "uri": uri,
                    "line": line,
                    "character": character,
                    "new_name": new_name,
                },
            )
        )

    async def shutdown_async(self) -> None:
        if self._dead or self._closed:
            return

        try:
            if self.proc is not None and self.proc.returncode is None:
                try:
                    if self._ready:
                        msg_id = await self._send_async("shutdown", {})
                        if msg_id is not None:
                            await self._wait_async(msg_id, 20)
                except Exception:
                    pass

                try:
                    await self._send_async("exit", None, is_request=False)
                except Exception:
                    pass

                try:
                    self.proc.terminate()
                except ProcessLookupError:
                    pass

                try:
                    await asyncio.wait_for(self.proc.wait(), timeout=3)
                except Exception:
                    pass

        finally:
            self._closed = True
            self._dead = True

            if self._stdout_task is not None:
                self._stdout_task.cancel()
            if self._stderr_task is not None:
                self._stderr_task.cancel()
            if self._initializing_task is not None:
                self._initializing_task.cancel()
            if self._command_task is not None:
                self._command_task.cancel()

            for fut in self._pending.values():
                if not fut.done():
                    fut.set_exception(RuntimeError("LSP client shut down"))
            self._pending.clear()

            if self._ready_event is not None and not self._ready_event.is_set():
                self._ready_event.set()
