from __future__ import annotations

import json
from io import StringIO
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from denary.buf import Buffer
from denary.events import Event, LSPEventType

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


def handle_lsp_event(editor: SimpleEditor, event: Event) -> None:
    _data = cast(dict[str, Any], event.data)

    request_type = _data["request_type"]

    match request_type:
        case LSPEventType.TEXT_DOCUMENT_HOVER:
            _handle_hover_event(editor, event)

        case LSPEventType.TEXT_DOCUMENT_DEFINITION:
            _handle_definition_event(editor, event)

        case LSPEventType.TEXT_DOCUMENT_REFERENCES:
            _handle_references_event(editor, event)

        case LSPEventType.TEXT_DOCUMENT_COMPLETION:
            _handle_completions_event(editor, event)


def _handle_hover_event(editor: SimpleEditor, event: Event) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    _data = cast(dict[str, Any], event.data)

    _result = _data["result"]

    if _result:
        match _result:
            case {"result": {"contents": {"value": value}}}:
                editor.open_file_in_less_mode(
                    # window=editor.stdscr,
                    file_handle=StringIO(value),
                    # editor=editor,
                    show_paste_menu=False,
                    position=window.get_cursor_position_display(),
                )
            case _:
                editor.send_notification("Hover information not available.")
    else:
        editor.send_notification("No hover information available.")


def _handle_definition_event(editor: SimpleEditor, event: Event) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    _data = cast(dict[str, Any], event.data)

    _result = _data["result"]

    match _result:
        case {"result": results} if isinstance(results, list):
            for result in results:
                match result:
                    case {
                        "uri": uri,
                        "range": {
                            "start": {
                                "line": start_line,
                                "character": start_char,
                            },
                            "end": _,
                        },
                    }:

                        file_path = editor.get_path_from_uri(uri)

                        if file_path is None:
                            return

                        file_name = file_path.relative_to(Path.cwd())

                        buf_index = editor.get_buffer_by_file_name(str(file_name))

                        if buf_index == -1:
                            new_buffer = Buffer(
                                file_name=str(file_name),
                                temp_dir=editor.temp_dir,
                            )
                            editor.buffers.append(new_buffer)
                            # editor.current_buffer = len(editor.buffers) - 1
                            editor.set_current_buffer(len(editor.buffers) - 1)
                        else:
                            # editor.current_buffer = buf_index
                            editor.set_current_buffer(buf_index)

                        buffer = editor.get_current_buffer()

                        window.cursor_y = start_line
                        window.cursor_x = start_char
                    case _:
                        editor.send_notification(
                            "Error: Invalid definition result format."
                        )
        case {
            "result": {
                "uri": uri,
                "range": {
                    "start": {
                        "line": start_line,
                        "character": start_char,
                    },
                    "end": _,
                },
            }
        }:

            file_path = editor.get_path_from_uri(uri)

            if file_path is None:
                return

            file_name = file_path.relative_to(Path.cwd())
            buf_index = editor.get_buffer_by_file_name(str(file_name))

            if buf_index == -1:
                new_buffer = Buffer(
                    file_name=str(file_name),
                    temp_dir=editor.temp_dir,
                )
                editor.buffers.append(new_buffer)
                # editor.current_buffer = len(editor.buffers) - 1
                editor.set_current_buffer(len(editor.buffers) - 1)
            else:
                # editor.current_buffer = buf_index
                editor.set_current_buffer(buf_index)

            buffer = editor.get_current_buffer()

            window.cursor_y = start_line
            window.cursor_x = start_char

        case _:
            editor.send_notification("Definition result is not a list." + str(_result))


def _handle_references_event(editor: SimpleEditor, event: Event) -> None:
    _data = cast(dict[str, Any], event.data)

    _result = _data["result"]

    if _result:
        match _result:
            case {"result": references, **rest} if isinstance(references, list):
                editor.show_references_picker(references)

            case {"error": {"message": msg, **error_rest}, **rest}:
                editor.send_notification(f"References not avilable {msg}.")

            case _:
                editor.open_aux_buffer(json.dumps(_result, indent=4))
    else:
        editor.send_notification("References not avilable.")


def _handle_completions_event(editor: SimpleEditor, event: Event) -> None:
    _data = cast(dict[str, Any], event.data)

    _result = _data["result"]

    if _result:

        lsp_matches = set()

        match _result:
            case {"result": {"items": items}} if isinstance(items, list):
                for item in items:
                    label = item.get("insertText") or item.get("label")
                    if label:
                        lsp_matches.add(label)

            case {"result": items} if isinstance(items, list):
                for item in items:
                    label = item.get("insertText") or item.get("label")
                    if label:
                        lsp_matches.add(label)

            case {"error": {"message": _message}} if isinstance(_message, str):
                editor.send_notification("Error: " + _message)
                return

            case _:
                editor.open_aux_buffer(str(_result))
                return

        editor.show_suggestions(lsp_matches)
