import curses
from typing import Optional

from denary.buf import Buffer


def render_line_numbers(
    stdscr: curses.window,
    screen_row: int,
    line_no: int,
    buffer: Buffer,
    num_lines: Optional[int] = None,
) -> int:
    if num_lines is None:
        num_lines = len(str(len(buffer.lines)))

    cp = curses.color_pair
    ln = line_no + 1

    number_str = f"{ln:{num_lines}} "
    number_color = cp(2)

    stdscr.addstr(screen_row, 1, number_str, number_color)

    return 1 + len(number_str)


def render_git_gutter(
    stdscr: curses.window,
    screen_row: int,
    line_no: int,
    buffer: Buffer,
    num_lines: Optional[int] = None,
) -> int:
    cp = curses.color_pair
    ln = line_no + 1

    change_type = buffer.buffer_changes.get(ln)
    if change_type is None:
        change_type = buffer.git_changes.get(ln)

    if change_type == "added":
        mark = "+"
        mark_color = cp(40)
    elif change_type == "deleted":
        mark = "-"
        mark_color = cp(41)
    elif change_type == "modified":
        mark = "~"
        mark_color = cp(42)
    else:
        mark = " "
        mark_color = cp(0)

    stdscr.addstr(screen_row, 0, mark, mark_color)

    return 1


def render_line_numbers_and_git(
    stdscr: curses.window,
    screen_row: int,
    line_no: int,
    buffer: Buffer,
    num_lines: Optional[int] = None,
) -> int:
    if num_lines is None:
        num_lines = len(str(len(buffer.lines)))

    cp = curses.color_pair
    ln = line_no + 1

    change_type = buffer.buffer_changes.get(ln)
    if change_type is None:
        change_type = buffer.git_changes.get(ln)

    if change_type == "added":
        mark = "+"
        mark_color = cp(40)
    elif change_type == "deleted":
        mark = "-"
        mark_color = cp(41)
    elif change_type == "modified":
        mark = "~"
        mark_color = cp(42)
    else:
        mark = " "
        mark_color = cp(0)

    number_str = f"{ln:{num_lines}} "
    number_color = cp(2)

    stdscr.addstr(screen_row, 0, mark, mark_color)
    stdscr.addstr(screen_row, 1, number_str, number_color)

    return 1 + len(number_str)
