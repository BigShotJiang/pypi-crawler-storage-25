from __future__ import annotations

import json
from typing import TYPE_CHECKING, NamedTuple

if TYPE_CHECKING:
    from denary.buf import Buffer
    from denary.editor import SimpleEditor


class Diagnostic(NamedTuple):
    """
    Represents a diagnostic message for a line in the editor.
    Contains the line number, column index, and the message text.
    """

    line: int  # line number (0-based)
    char: int  # column index (0-based)
    code: str  # diagnostic code (e.g., "E123", "W456")
    message: str  # diagnostic message text
    severity: int  # severity level (e.g., "error", "warning", "info")


def process_ai_completions(editor: SimpleEditor, buffer: Buffer, job_id: str) -> None:
    status = editor.ai_completion_manager.get_status(job_id)

    if status is None:
        return None

    for i in range(len(buffer.ai_completions)):
        if buffer.ai_completions[i].code != job_id:
            continue

        c = buffer.ai_completions.pop(i)

        severity = 2

        if status == "RUNNING":
            severity = 3

        elif status == "ERROR" or status == "CANCELED":
            severity = 1

        elif status == "COMPLETED":
            severity = 4

        buffer.ai_completions.append(
            Diagnostic(
                line=min(c.line, len(buffer.lines) - 1),
                char=c.char,
                code=c.code,
                message=status,
                severity=severity,
            )
        )


def process_diagnostics(
    editor: SimpleEditor, buffer: Buffer, diagnostics: list[dict]
) -> None:
    """
    Process diagnostics from LSP and update buffer lines.
    """
    if not buffer or buffer.first:
        return

    buffer.diagnostics.clear()

    if not diagnostics:
        return

    buf_lines = len(buffer.lines)
    for diag in diagnostics:
        match diag:
            case {
                "source": _,
                "range": {"start": {"line": line, "character": char}, "end": _},
                "code": code,
                "message": message,
                "severity": severity,
            }:
                if buf_lines > line:
                    buffer.diagnostics.append(
                        Diagnostic(
                            line=line,
                            char=char,
                            code=code,
                            message=message,
                            severity=severity,
                        )
                    )

            case {
                "source": _,
                "range": {"start": {"line": line, "character": char}, "end": _},
                "message": message,
                "severity": severity,
            }:
                if buf_lines > line:
                    buffer.diagnostics.append(
                        Diagnostic(
                            line=line,
                            char=char,
                            code="",
                            message=message,
                            severity=severity,
                        )
                    )

            case {
                "message": message,
                "range": {"start": {"line": line, "character": char}, "end": _},
                "severity": severity,
            }:
                if buf_lines > line:
                    buffer.diagnostics.append(
                        Diagnostic(
                            line=line,
                            char=char,
                            code="",
                            message=message,
                            severity=severity,
                        )
                    )

            case _:
                editor.open_aux_buffer(json.dumps(diag, indent=4))
                break
