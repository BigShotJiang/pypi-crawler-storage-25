import hashlib
import hmac
import json
import time


class WebhookEventType:
    """
    All webhook event types emitted by the ZyndPay API.

    Your endpoint receives a POST with body:
    ``{"event": str, "data": dict, "createdAt": "ISO-8601"}``

    Verify the ``X-ZyndPay-Signature`` header before trusting the payload.

    All payin events include these base fields in ``data``:
        - ``transactionId`` — the payin transaction ID
        - ``status`` — current status (e.g. "CONFIRMED", "EXPIRED")
        - ``currency`` — e.g. "USDT_TRC20"
        - ``chain`` — e.g. "TRON"
        - ``externalRef`` — your order/reference ID (or None)

    Payin events (incoming payment state changes):
        - ``PAYIN_CREATED``    — payin created, deposit address generated. Extra: amount, address.
        - ``PAYIN_CONFIRMING`` — funds received, waiting for confirmations. Extra: txHash, confirmations.
        - ``PAYIN_CONFIRMED``  — amount within ±0.5% of requested. Extra: amount, amountRequested, txHash, confirmedAt.
        - ``PAYIN_EXPIRED``    — expired with no payment. Base fields only.
        - ``PAYIN_FAILED``     — failed due to processing error.
        - ``PAYIN_OVERPAID``   — payer sent more than requested. Extra: amount, amountRequested, txHash, confirmedAt.
        - ``PAYIN_UNDERPAID``  — payer sent less than requested. Extra: amount, amountRequested, txHash, confirmedAt.

    Deposit events (wallet deposit state changes, no fee deducted):
        - ``DEPOSIT_CONFIRMED`` / ``DEPOSIT_OVERPAID`` / ``DEPOSIT_UNDERPAID``

    Payout events (outgoing payment state changes):
        - ``PAYOUT_BROADCAST``  — transaction submitted to TRON network.
        - ``PAYOUT_CONFIRMED``  — 20+ block confirmations. Funds delivered.
        - ``PAYOUT_FAILED``     — broadcast or confirmation failed.

    Withdrawal events (merchant withdrawal state changes):
        - ``WITHDRAWAL_REQUESTED`` — withdrawal created by the merchant.
        - ``WITHDRAWAL_APPROVED``  — approved by ZyndPay admin.
        - ``WITHDRAWAL_BROADCAST`` — transaction submitted to TRON network.
        - ``WITHDRAWAL_CONFIRMED`` — 20+ block confirmations received.
        - ``WITHDRAWAL_FAILED``    — broadcast or confirmation failed.

    Conversion events (USDT ↔ XOF wallet conversions):
        - ``CONVERSION_CONFIRMED`` / ``CONVERSION_FAILED``

    Subscription events (paylink-driven recurring billing):
        - ``SUBSCRIPTION_CREATED`` / ``SUBSCRIPTION_RENEWED`` / ``SUBSCRIPTION_RENEWAL_INITIATED``
        - ``SUBSCRIPTION_FAILED`` / ``SUBSCRIPTION_CANCELLED``
        - ``SUBSCRIPTION_PAUSED`` / ``SUBSCRIPTION_RESUMED`` / ``SUBSCRIPTION_UPDATED``

    Refund events (refund lifecycle):
        - ``REFUND_CREATED`` / ``REFUND_APPROVED`` / ``REFUND_REJECTED``
        - ``REFUND_COMPLETED`` / ``REFUND_FAILED``

    Dispute events (dispute / chargeback lifecycle):
        - ``DISPUTE_OPENED`` / ``DISPUTE_RESOLVED`` / ``DISPUTE_REJECTED`` / ``DISPUTE_ESCALATED``

    AML events (compliance flags):
        - ``AML_FLAGGED``

    Marketplace events (split payments):
        - ``SPLITPAYMENT_CREATED``
    """

    PAYIN_CREATED = "payin.created"
    PAYIN_CONFIRMING = "payin.confirming"
    PAYIN_CONFIRMED = "payin.confirmed"
    PAYIN_EXPIRED = "payin.expired"
    PAYIN_FAILED = "payin.failed"
    PAYIN_OVERPAID = "payin.overpaid"
    PAYIN_UNDERPAID = "payin.underpaid"

    DEPOSIT_CONFIRMED = "deposit.confirmed"
    DEPOSIT_FAILED = "deposit.failed"
    DEPOSIT_OVERPAID = "deposit.overpaid"
    DEPOSIT_UNDERPAID = "deposit.underpaid"

    PAYOUT_BROADCAST = "payout.broadcast"
    PAYOUT_CONFIRMED = "payout.confirmed"
    PAYOUT_FAILED = "payout.failed"

    WITHDRAWAL_REQUESTED = "withdrawal.requested"
    WITHDRAWAL_APPROVED = "withdrawal.approved"
    WITHDRAWAL_BROADCAST = "withdrawal.broadcast"
    WITHDRAWAL_CONFIRMED = "withdrawal.confirmed"
    WITHDRAWAL_FAILED = "withdrawal.failed"

    CONVERSION_CONFIRMED = "conversion.confirmed"
    CONVERSION_FAILED = "conversion.failed"

    SUBSCRIPTION_CREATED = "subscription.created"
    SUBSCRIPTION_RENEWED = "subscription.renewed"
    SUBSCRIPTION_RENEWAL_INITIATED = "subscription.renewal_initiated"
    SUBSCRIPTION_FAILED = "subscription.failed"
    SUBSCRIPTION_CANCELLED = "subscription.cancelled"
    SUBSCRIPTION_PAUSED = "subscription.paused"
    SUBSCRIPTION_RESUMED = "subscription.resumed"
    SUBSCRIPTION_UPDATED = "subscription.updated"

    REFUND_CREATED = "refund.created"
    REFUND_APPROVED = "refund.approved"
    REFUND_REJECTED = "refund.rejected"
    REFUND_COMPLETED = "refund.completed"
    REFUND_FAILED = "refund.failed"

    DISPUTE_OPENED = "dispute.opened"
    DISPUTE_RESOLVED = "dispute.resolved"
    DISPUTE_REJECTED = "dispute.rejected"
    DISPUTE_ESCALATED = "dispute.escalated"

    AML_FLAGGED = "aml.flagged"

    SPLITPAYMENT_CREATED = "splitpayment.created"


ALL_EVENTS = (
    WebhookEventType.PAYIN_CREATED,
    WebhookEventType.PAYIN_CONFIRMING,
    WebhookEventType.PAYIN_CONFIRMED,
    WebhookEventType.PAYIN_EXPIRED,
    WebhookEventType.PAYIN_FAILED,
    WebhookEventType.PAYIN_OVERPAID,
    WebhookEventType.PAYIN_UNDERPAID,
    WebhookEventType.DEPOSIT_CONFIRMED,
    WebhookEventType.DEPOSIT_FAILED,
    WebhookEventType.DEPOSIT_OVERPAID,
    WebhookEventType.DEPOSIT_UNDERPAID,
    WebhookEventType.PAYOUT_BROADCAST,
    WebhookEventType.PAYOUT_CONFIRMED,
    WebhookEventType.PAYOUT_FAILED,
    WebhookEventType.WITHDRAWAL_REQUESTED,
    WebhookEventType.WITHDRAWAL_APPROVED,
    WebhookEventType.WITHDRAWAL_BROADCAST,
    WebhookEventType.WITHDRAWAL_CONFIRMED,
    WebhookEventType.WITHDRAWAL_FAILED,
    WebhookEventType.CONVERSION_CONFIRMED,
    WebhookEventType.CONVERSION_FAILED,
    WebhookEventType.SUBSCRIPTION_CREATED,
    WebhookEventType.SUBSCRIPTION_RENEWED,
    WebhookEventType.SUBSCRIPTION_RENEWAL_INITIATED,
    WebhookEventType.SUBSCRIPTION_FAILED,
    WebhookEventType.SUBSCRIPTION_CANCELLED,
    WebhookEventType.SUBSCRIPTION_PAUSED,
    WebhookEventType.SUBSCRIPTION_RESUMED,
    WebhookEventType.SUBSCRIPTION_UPDATED,
    WebhookEventType.REFUND_CREATED,
    WebhookEventType.REFUND_APPROVED,
    WebhookEventType.REFUND_REJECTED,
    WebhookEventType.REFUND_COMPLETED,
    WebhookEventType.REFUND_FAILED,
    WebhookEventType.DISPUTE_OPENED,
    WebhookEventType.DISPUTE_RESOLVED,
    WebhookEventType.DISPUTE_REJECTED,
    WebhookEventType.DISPUTE_ESCALATED,
    WebhookEventType.AML_FLAGGED,
    WebhookEventType.SPLITPAYMENT_CREATED,
)


class WebhookVerifier:
    """Verify ZyndPay webhook signatures."""

    HEADER_NAME = "x-zyndpay-signature"

    def __init__(self, signing_secret: str):
        self._secret = signing_secret

    def verify(self, payload: str, signature: str, tolerance_seconds: int = 300) -> dict:
        """
        Verify a webhook signature and parse the event payload.

        Args:
            payload: The raw request body (string)
            signature: The value of the X-ZyndPay-Signature header
            tolerance_seconds: Max age of the event in seconds (default: 300)

        Returns:
            Parsed webhook event dict: ``{"event": str, "data": dict, "createdAt": str}``.

        Raises:
            ValueError: If the signature is invalid or the event is too old.

        Example::

            verifier = zyndpay.webhooks
            event = verifier.verify(request.data, request.headers["X-ZyndPay-Signature"])
            print(event["event"])  # "payin.confirmed"
        """
        if not signature:
            raise ValueError("Missing webhook signature header")

        parts = signature.split(",")
        t_part = next((p for p in parts if p.startswith("t=")), None)
        v1_part = next((p for p in parts if p.startswith("v1=")), None)

        if not t_part or not v1_part:
            raise ValueError('Invalid webhook signature format — expected "t=<timestamp>,v1=<hmac>"')

        timestamp = int(t_part.replace("t=", ""))
        received_hmac = v1_part.replace("v1=", "")

        now = int(time.time())
        if abs(now - timestamp) > tolerance_seconds:
            raise ValueError(
                f"Webhook timestamp too old ({abs(now - timestamp)}s > {tolerance_seconds}s tolerance)"
            )

        signed_payload = f"{timestamp}.{payload}"
        expected_hmac = hmac.new(
            self._secret.encode("utf-8"),
            signed_payload.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

        if not hmac.compare_digest(expected_hmac, received_hmac):
            raise ValueError("Webhook signature verification failed")

        return json.loads(payload)
