from typing import Any, Dict, List, Optional


class FiatDestinations:
    """Manage fiat withdrawal destinations (mobile money and bank accounts)."""

    def __init__(self, client):
        self._client = client

    def list(self) -> List[dict]:
        res = self._client.get("/merchants/fiat-destinations")
        return res["data"]

    def create(
        self,
        kind: str,
        label: str,
        is_primary: bool = False,
        momo_operator: Optional[str] = None,
        momo_phone: Optional[str] = None,
        bank_name: Optional[str] = None,
        bank_account_name: Optional[str] = None,
        bank_iban: Optional[str] = None,
        bank_account_number: Optional[str] = None,
        bank_code: Optional[str] = None,
    ) -> dict:
        body: Dict[str, Any] = {"kind": kind, "label": label, "isPrimary": is_primary}
        if momo_operator:
            body["momoOperator"] = momo_operator
        if momo_phone:
            body["momoPhone"] = momo_phone
        if bank_name:
            body["bankName"] = bank_name
        if bank_account_name:
            body["bankAccountName"] = bank_account_name
        if bank_iban:
            body["bankIban"] = bank_iban
        if bank_account_number:
            body["bankAccountNumber"] = bank_account_number
        if bank_code:
            body["bankCode"] = bank_code
        res = self._client.post("/merchants/fiat-destinations", json=body)
        return res["data"]

    def update(
        self,
        destination_id: str,
        label: Optional[str] = None,
        is_primary: Optional[bool] = None,
    ) -> dict:
        body: Dict[str, Any] = {}
        if label is not None:
            body["label"] = label
        if is_primary is not None:
            body["isPrimary"] = is_primary
        res = self._client.patch(f"/merchants/fiat-destinations/{destination_id}", json=body)
        return res["data"]

    def delete(self, destination_id: str) -> None:
        self._client.delete(f"/merchants/fiat-destinations/{destination_id}")
