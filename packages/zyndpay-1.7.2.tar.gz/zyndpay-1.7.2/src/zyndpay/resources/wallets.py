from typing import List, Optional


class Wallets:
    """
    List merchant wallets and manage the address whitelist (the set of TRON
    addresses authorized to receive withdrawals or payouts).

    Whitelist methods require an API key with the ``wallets_write`` scope
    (mutations) or ``wallets_read`` (listing). A 24-hour security cooldown
    applies to every newly added address.
    """

    def __init__(self, client):
        self._client = client

    def list(self) -> List[dict]:
        """List all merchant wallets."""
        res = self._client.get("/merchants/wallets")
        return res["data"]

    # ── Address whitelist ──────────────────────────────────────────────

    def list_whitelist(self, context: Optional[str] = None) -> List[dict]:
        """
        List whitelisted TRON addresses.

        :param context: Optional filter — ``WITHDRAWAL`` or ``PAYOUT``.
        """
        params = {"context": context} if context else None
        res = self._client.get("/wallets/whitelist", params=params)
        return res["data"]

    def add_to_whitelist(
        self,
        *,
        address: str,
        currency: str = "USDT_TRC20",
        chain: str = "TRON",
        label: Optional[str] = None,
        usage_contexts: Optional[List[str]] = None,
        totp_code: Optional[str] = None,
    ) -> dict:
        """
        Add a single TRON address to the whitelist.

        :param usage_contexts: Defaults to ``['WITHDRAWAL']``. Pass
            ``['WITHDRAWAL', 'PAYOUT']`` to enable both at create time.
        """
        body = {"currency": currency, "chain": chain, "address": address}
        if label is not None:
            body["label"] = label
        if usage_contexts is not None:
            body["usageContexts"] = usage_contexts
        if totp_code is not None:
            body["totpCode"] = totp_code
        res = self._client.post("/wallets/whitelist", json=body)
        return res["data"]

    def bulk_add_to_whitelist(
        self,
        addresses: List[dict],
        *,
        usage_contexts: Optional[List[str]] = None,
        totp_code: Optional[str] = None,
    ) -> dict:
        """
        Add up to 500 addresses in one call.

        :param addresses: List of ``{"address": "T...", "label": "..."}`` dicts.
        :param usage_contexts: Applied to every address in the batch.
        """
        body = {"addresses": addresses}
        if usage_contexts is not None:
            body["usageContexts"] = usage_contexts
        if totp_code is not None:
            body["totpCode"] = totp_code
        res = self._client.post("/wallets/whitelist/bulk", json=body)
        return res["data"]

    def update_whitelist_contexts(self, entry_id: str, usage_contexts: List[str]) -> dict:
        """
        Replace the ``usageContexts`` on an existing whitelist entry without
        restarting the 24-hour cooldown.
        """
        res = self._client.patch(
            f"/wallets/whitelist/{entry_id}/contexts",
            json={"usageContexts": usage_contexts},
        )
        return res["data"]

    def remove_from_whitelist(self, entry_id: str) -> None:
        """Remove an address from the whitelist."""
        self._client.delete(f"/wallets/whitelist/{entry_id}")
