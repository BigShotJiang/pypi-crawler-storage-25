from typing import Any, Dict, List, Optional


class Conversions:
    """Convert between merchant wallets at the live rate."""

    def __init__(self, client):
        self._client = client

    def convert_between_wallets(
        self,
        from_wallet_id: str,
        to_wallet_id: str,
        from_amount: str,
        idempotency_key: Optional[str] = None,
    ) -> dict:
        body: Dict[str, Any] = {
            "fromWalletId": from_wallet_id,
            "toWalletId": to_wallet_id,
            "fromAmount": from_amount,
        }
        res = self._client.post("/conversions/wallet", json=body, idempotency_key=idempotency_key)
        return res["data"]

    def get(self, conversion_id: str) -> dict:
        res = self._client.get(f"/conversions/{conversion_id}")
        return res["data"]

    def list(
        self,
        status: Optional[str] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> dict:
        params: Dict[str, Any] = {}
        if status:
            params["status"] = status
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        res = self._client.get("/conversions", params=params)
        return res["data"]
