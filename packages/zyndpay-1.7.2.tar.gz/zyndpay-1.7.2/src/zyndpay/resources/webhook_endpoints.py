from typing import List, Optional


class WebhookEndpoints:
    """
    CRUD for webhook endpoints registered against the merchant account.

    Note: ``zyndpay.webhooks`` is the *signature verifier* used to validate
    incoming deliveries. This resource (``zyndpay.webhook_endpoints``) is the
    *management* surface — same split Stripe uses.

    Requires ``webhooks_read`` scope for read methods, ``webhooks_write`` for
    mutations.
    """

    def __init__(self, client):
        self._client = client

    def create(
        self,
        *,
        url: str,
        events: List[str],
        max_retries: Optional[int] = None,
        retry_backoff: Optional[str] = None,
        retry_interval_seconds: Optional[int] = None,
        idempotency_key: Optional[str] = None,
    ) -> dict:
        """
        Create a new webhook endpoint.

        The response includes a one-time ``secret`` field — store it; you will
        need it to verify incoming deliveries via ``zyndpay.webhooks.verify(...)``.
        The secret is never returned again.
        """
        body = {"url": url, "events": events}
        if max_retries is not None:
            body["maxRetries"] = max_retries
        if retry_backoff is not None:
            body["retryBackoff"] = retry_backoff
        if retry_interval_seconds is not None:
            body["retryIntervalSeconds"] = retry_interval_seconds
        headers = {"Idempotency-Key": idempotency_key} if idempotency_key else None
        res = self._client.post("/webhooks/endpoints", json=body, headers=headers)
        return res["data"]

    def list(self) -> List[dict]:
        """List all webhook endpoints."""
        res = self._client.get("/webhooks/endpoints")
        return res["data"]

    def get(self, endpoint_id: str) -> dict:
        """Get a single endpoint by id."""
        res = self._client.get(f"/webhooks/endpoints/{endpoint_id}")
        return res["data"]

    def update(
        self,
        endpoint_id: str,
        *,
        url: Optional[str] = None,
        events: Optional[List[str]] = None,
        is_enabled: Optional[bool] = None,
        max_retries: Optional[int] = None,
        retry_backoff: Optional[str] = None,
        retry_interval_seconds: Optional[int] = None,
    ) -> dict:
        """Update url, event subscriptions, retry config, or enabled flag."""
        body = {}
        if url is not None:
            body["url"] = url
        if events is not None:
            body["events"] = events
        if is_enabled is not None:
            body["isEnabled"] = is_enabled
        if max_retries is not None:
            body["maxRetries"] = max_retries
        if retry_backoff is not None:
            body["retryBackoff"] = retry_backoff
        if retry_interval_seconds is not None:
            body["retryIntervalSeconds"] = retry_interval_seconds
        res = self._client.patch(f"/webhooks/endpoints/{endpoint_id}", json=body)
        return res["data"]

    def delete(self, endpoint_id: str) -> None:
        """Delete a webhook endpoint."""
        self._client.delete(f"/webhooks/endpoints/{endpoint_id}")

    def rotate_secret(self, endpoint_id: str) -> dict:
        """
        Rotate the signing secret for an endpoint. The response contains a
        new one-time ``secret`` value — update your verifier configuration
        before the next delivery arrives.
        """
        res = self._client.patch(f"/webhooks/endpoints/{endpoint_id}/rotate-secret", json={})
        return res["data"]

    def reactivate(self, endpoint_id: str) -> dict:
        """
        Reactivate an endpoint that was auto-suspended after 3 consecutive
        delivery failures. Resets the failure counter to zero.
        """
        res = self._client.patch(f"/webhooks/endpoints/{endpoint_id}/reactivate", json={})
        return res["data"]

    def send_test_event(self, *, endpoint_id: str, event_type: str) -> dict:
        """
        Send a synthetic test event. The body carries
        ``data: {"test": True, ...}`` so your handler can short-circuit it.
        """
        res = self._client.post(
            "/webhooks/test",
            json={"endpointId": endpoint_id, "eventType": event_type},
        )
        return res["data"]
