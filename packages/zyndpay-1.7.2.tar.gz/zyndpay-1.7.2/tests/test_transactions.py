"""Tests for the Python SDK Transactions resource."""

import json
import pytest
import responses as resp_mock
from zyndpay import ZyndPay

API_KEY = "zyp_test_sk_test123"
BASE_URL = "https://api.zyndpay.io/v1"


@pytest.fixture
def client():
    return ZyndPay(api_key=API_KEY)


def api_response(data):
    return json.dumps({"success": True, "data": data})


TRANSACTION = {
    "id": "tx_abc",
    "type": "PAYIN",
    "status": "COMPLETED",
    "amount": "25.00",
    "currency": "USDT_TRC20",
    "createdAt": "2026-04-29T10:00:00.000Z",
}


@resp_mock.activate
def test_get_fetches_transaction_by_id(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/transactions/tx_abc",
        body=api_response(TRANSACTION), content_type="application/json")
    result = client.transactions.get("tx_abc")
    req = resp_mock.calls[0].request
    assert req.method == "GET"
    assert req.url == f"{BASE_URL}/transactions/tx_abc"
    assert req.headers["X-Api-Key"] == API_KEY
    assert result["id"] == "tx_abc"


@resp_mock.activate
def test_list_gets_transactions(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/transactions",
        body=api_response({"items": [TRANSACTION], "total": 1, "page": 1, "limit": 20}),
        content_type="application/json")
    result = client.transactions.list()
    req = resp_mock.calls[0].request
    assert req.method == "GET"
    assert req.url.startswith(f"{BASE_URL}/transactions")
    assert result["total"] == 1


@resp_mock.activate
def test_list_sends_type_filter(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/transactions",
        body=api_response({"items": [], "total": 0}), content_type="application/json")
    client.transactions.list(type="PAYIN")
    assert "type=PAYIN" in resp_mock.calls[0].request.url


@resp_mock.activate
def test_list_sends_status_filter(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/transactions",
        body=api_response({"items": [], "total": 0}), content_type="application/json")
    client.transactions.list(status="COMPLETED")
    assert "status=COMPLETED" in resp_mock.calls[0].request.url


@resp_mock.activate
def test_list_sends_pagination(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/transactions",
        body=api_response({"items": [], "total": 0}), content_type="application/json")
    client.transactions.list(page=2, limit=10)
    url = resp_mock.calls[0].request.url
    assert "page=2" in url
    assert "limit=10" in url


@resp_mock.activate
def test_list_sends_date_filters(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/transactions",
        body=api_response({"items": [], "total": 0}), content_type="application/json")
    client.transactions.list(from_date="2026-01-01", to_date="2026-12-31")
    url = resp_mock.calls[0].request.url
    assert "from=2026-01-01" in url
    assert "to=2026-12-31" in url


@resp_mock.activate
def test_list_sends_currency_filter(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/transactions",
        body=api_response({"items": [], "total": 0}), content_type="application/json")
    client.transactions.list(currency="USDT_TRC20")
    assert "currency=USDT_TRC20" in resp_mock.calls[0].request.url


def test_client_exposes_transactions_property(client):
    from zyndpay.resources.transactions import Transactions
    assert hasattr(client, "transactions")
    assert isinstance(client.transactions, Transactions)
