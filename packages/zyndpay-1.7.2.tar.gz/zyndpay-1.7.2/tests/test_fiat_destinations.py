"""Tests for the Python SDK FiatDestinations resource."""
import json
import pytest
import responses as resp_mock
from zyndpay import ZyndPay

API_KEY = "zyp_test_sk_test123"
BASE_URL = "https://api.zyndpay.io/v1"

@pytest.fixture
def client():
    return ZyndPay(api_key=API_KEY)

def api_response(data):
    return json.dumps({"success": True, "data": data})

MOMO_DEST = {"id": "fd_momo_abc", "kind": "MOMO", "label": "Orange Money BF",
             "momoOperator": "ORANGE_BF", "momoPhone": "+22670123456", "isPrimary": True, "status": "ACTIVE"}
BANK_DEST = {"id": "fd_bank_xyz", "kind": "BANK", "label": "My Bank Account",
             "bankName": "Coris Bank", "bankAccountName": "Kofi Mensah", "isPrimary": False, "status": "ACTIVE"}

@resp_mock.activate
def test_list_calls_merchants_fiat_destinations(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/merchants/fiat-destinations",
        body=api_response([MOMO_DEST]), content_type="application/json")
    result = client.fiat_destinations.list()
    req = resp_mock.calls[0].request
    assert req.url == f"{BASE_URL}/merchants/fiat-destinations"
    assert req.method == "GET"

@resp_mock.activate
def test_create_momo_destination(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/merchants/fiat-destinations",
        body=api_response(MOMO_DEST), content_type="application/json")
    result = client.fiat_destinations.create(
        kind="MOMO", label="Orange Money BF",
        momo_operator="ORANGE_BF", momo_phone="+22670123456", is_primary=True)
    req = resp_mock.calls[0].request
    body = json.loads(req.body)
    assert body["kind"] == "MOMO"
    assert body["momoOperator"] == "ORANGE_BF"
    assert result["id"] == "fd_momo_abc"

@resp_mock.activate
def test_create_bank_destination(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/merchants/fiat-destinations",
        body=api_response(BANK_DEST), content_type="application/json")
    result = client.fiat_destinations.create(
        kind="BANK", label="My Bank Account",
        bank_name="Coris Bank", bank_account_name="Kofi Mensah")
    body = json.loads(resp_mock.calls[0].request.body)
    assert body["kind"] == "BANK"
    assert body["bankName"] == "Coris Bank"

@resp_mock.activate
def test_update_destination(client):
    resp_mock.add(resp_mock.PATCH, f"{BASE_URL}/merchants/fiat-destinations/fd_momo_abc",
        body=api_response({**MOMO_DEST, "label": "Updated"}), content_type="application/json")
    result = client.fiat_destinations.update("fd_momo_abc", label="Updated")
    req = resp_mock.calls[0].request
    assert req.method == "PATCH"
    body = json.loads(req.body)
    assert body["label"] == "Updated"

@resp_mock.activate
def test_delete_destination(client):
    resp_mock.add(resp_mock.DELETE, f"{BASE_URL}/merchants/fiat-destinations/fd_momo_abc",
        body=json.dumps({"success": True}), content_type="application/json")
    client.fiat_destinations.delete("fd_momo_abc")
    assert resp_mock.calls[0].request.method == "DELETE"

def test_client_exposes_fiat_destinations_property(client):
    from zyndpay.resources.fiat_destinations import FiatDestinations
    assert hasattr(client, "fiat_destinations")
    assert isinstance(client.fiat_destinations, FiatDestinations)
