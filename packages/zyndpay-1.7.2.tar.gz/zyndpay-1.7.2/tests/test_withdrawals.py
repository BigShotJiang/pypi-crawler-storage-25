"""Tests for the Python SDK Withdrawals resource."""

import json
import pytest
import responses as resp_mock
from zyndpay import ZyndPay

API_KEY = "zyp_test_sk_test123"
BASE_URL = "https://api.zyndpay.io/v1"


@pytest.fixture
def client():
    return ZyndPay(api_key=API_KEY)


def api_response(data):
    return json.dumps({"success": True, "data": data})


WITHDRAWAL = {"id": "wd_abc", "amount": "100.00", "currency": "USDT_TRC20",
              "status": "PENDING_REVIEW", "createdAt": "2026-04-29T10:00:00.000Z"}


@resp_mock.activate
def test_create_posts_to_withdrawals(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/withdrawals",
        body=api_response(WITHDRAWAL), content_type="application/json")
    result = client.withdrawals.create(amount="100.00")
    req = resp_mock.calls[0].request
    assert req.method == "POST"
    assert req.url == f"{BASE_URL}/withdrawals"
    body = json.loads(req.body)
    assert body["amount"] == "100.00"
    assert result["id"] == "wd_abc"


@resp_mock.activate
def test_create_sends_idempotency_key(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/withdrawals",
        body=api_response(WITHDRAWAL), content_type="application/json")
    client.withdrawals.create(amount="100.00", idempotency_key="idem_wd_001")
    assert resp_mock.calls[0].request.headers.get("Idempotency-Key") == "idem_wd_001"


@resp_mock.activate
def test_create_sends_whitelist_address_id(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/withdrawals",
        body=api_response(WITHDRAWAL), content_type="application/json")
    client.withdrawals.create(amount="100.00", whitelist_address_id="wl_123")
    body = json.loads(resp_mock.calls[0].request.body)
    assert body["whitelistAddressId"] == "wl_123"


@resp_mock.activate
def test_get_fetches_withdrawal_by_id(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/withdrawals/wd_abc",
        body=api_response(WITHDRAWAL), content_type="application/json")
    result = client.withdrawals.get("wd_abc")
    assert resp_mock.calls[0].request.url == f"{BASE_URL}/withdrawals/wd_abc"
    assert result["id"] == "wd_abc"


@resp_mock.activate
def test_list_gets_withdrawals(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/withdrawals",
        body=api_response({"items": [WITHDRAWAL], "total": 1}), content_type="application/json")
    result = client.withdrawals.list()
    assert resp_mock.calls[0].request.method == "GET"
    assert result["total"] == 1


@resp_mock.activate
def test_list_sends_status_filter(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/withdrawals",
        body=api_response({"items": [], "total": 0}), content_type="application/json")
    client.withdrawals.list(status="PENDING_REVIEW", page=1, limit=10)
    url = resp_mock.calls[0].request.url
    assert "status=PENDING_REVIEW" in url
    assert "page=1" in url
    assert "limit=10" in url


@resp_mock.activate
def test_cancel_sends_delete_request(client):
    resp_mock.add(resp_mock.DELETE, f"{BASE_URL}/withdrawals/wd_abc",
        body=json.dumps({"success": True}), content_type="application/json")
    client.withdrawals.cancel("wd_abc")
    assert resp_mock.calls[0].request.method == "DELETE"
    assert "/withdrawals/wd_abc" in resp_mock.calls[0].request.url


def test_client_exposes_withdrawals_property(client):
    from zyndpay.resources.withdrawals import Withdrawals
    assert hasattr(client, "withdrawals")
    assert isinstance(client.withdrawals, Withdrawals)
