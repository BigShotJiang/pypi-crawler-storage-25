"""Regression tests — payins resource must call /payments, not /payin."""

import json
import pytest
import responses as resp_mock
from zyndpay import ZyndPay

API_KEY = "zyp_test_sk_test123"
BASE_URL = "https://api.zyndpay.io/v1"

@pytest.fixture
def client():
    return ZyndPay(api_key=API_KEY)

def api_response(data):
    return json.dumps({"success": True, "data": data})

@resp_mock.activate
def test_create_posts_to_payments_not_payin(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/payments",
        body=api_response({"transactionId": "pay_1", "status": "AWAITING_PAYMENT"}),
        content_type="application/json")
    client.payins.create(amount="100")
    assert resp_mock.calls[0].request.url == f"{BASE_URL}/payments"

@resp_mock.activate
def test_create_does_not_call_payin_path(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/payments",
        body=api_response({"transactionId": "pay_2"}), content_type="application/json")
    client.payins.create(amount="50")
    assert "/payin" not in resp_mock.calls[0].request.url

@resp_mock.activate
def test_get_calls_payments_id(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/payments/pay_abc",
        body=api_response({"id": "pay_abc", "status": "CONFIRMED"}),
        content_type="application/json")
    result = client.payins.get("pay_abc")
    assert resp_mock.calls[0].request.url == f"{BASE_URL}/payments/pay_abc"
    assert result["id"] == "pay_abc"

@resp_mock.activate
def test_list_calls_payments(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/payments",
        body=api_response([]), content_type="application/json")
    client.payins.list()
    assert resp_mock.calls[0].request.url.startswith(f"{BASE_URL}/payments")

@resp_mock.activate
def test_simulate_calls_sandbox_payments(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/sandbox/payments/pay_xyz/simulate",
        body=api_response({"transactionId": "pay_xyz", "status": "CONFIRMED"}),
        content_type="application/json")
    client.payins.simulate("pay_xyz")
    assert "/sandbox/payments/" in resp_mock.calls[0].request.url
    assert "/sandbox/payin/" not in resp_mock.calls[0].request.url


@resp_mock.activate
def test_submit_otp_uses_payins_prefix_not_payments(client):
    # submit_otp hits /payins/{id}/submit-otp (not /payments/{id}/submit-otp).
    # The API controller is @Controller('payins') + @Post(':id/submit-otp'),
    # making the canonical path /v1/payins/{id}/submit-otp.
    # This test documents the intent and prevents accidental "fix" to /payments.
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/payins/pay_abc/submit-otp",
        body=api_response({"transactionId": "pay_abc", "status": "AWAITING_PAYMENT"}),
        content_type="application/json")
    client.payins.submit_otp("pay_abc", otp="123456")
    req = resp_mock.calls[0].request
    assert "/payins/" in req.url
    assert "/payments/" not in req.url
    assert "submit-otp" in req.url
