"""
Cross-SDK webhook contract tests for the Python SDK.

Validates that every fixture in fixtures/webhook-payloads.json:
1. Passes through WebhookVerifier.verify() with a test signature
2. Uses the `event` field (not `type`)
3. Contains all required base fields in `data`
4. Contains event-specific fields based on event type
"""

import hashlib
import hmac
import json
import os
import time

import pytest

from zyndpay import WebhookVerifier

FIXTURES_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "..", "fixtures", "webhook-payloads.json"
)
SECRET = "whsec_contract_test_secret"

BASE_FIELDS = ["transactionId", "status", "currency", "chain", "externalRef"]

EVENT_SPECIFIC_FIELDS = {
    "payin.created": ["amount", "address"],
    "payin.confirming": ["txHash", "confirmations"],
    "payin.confirmed": ["amount", "amountRequested", "txHash", "confirmedAt"],
    "payin.overpaid": ["amount", "amountRequested", "txHash", "confirmedAt"],
    "payin.underpaid": ["amount", "amountRequested", "txHash", "confirmedAt"],
}


def _build_signature(body: str, secret: str) -> str:
    ts = int(time.time())
    signed_payload = f"{ts}.{body}"
    digest = hmac.new(
        secret.encode("utf-8"),
        signed_payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return f"t={ts},v1={digest}"


def _load_fixtures():
    if not os.path.exists(FIXTURES_PATH):
        return []
    with open(FIXTURES_PATH, "r") as f:
        parsed = json.load(f)
        return parsed if isinstance(parsed, list) else parsed.get("payloads", [])


FIXTURES = _load_fixtures()


@pytest.fixture
def fixtures():
    return FIXTURES


# ─── Tests ────────────────────────────────────────────────────────────────────


def test_fixtures_loaded():
    """Fixtures file should exist and contain at least one payload."""
    if not os.path.exists(FIXTURES_PATH):
        pytest.skip("Fixtures file not found — skipping contract tests")
    assert len(FIXTURES) > 0, "Expected at least one fixture payload"


def test_every_fixture_passes_through_verifier(fixtures):
    """Every fixture payload should pass WebhookVerifier.verify()."""
    if not fixtures:
        pytest.skip("No fixtures loaded")

    verifier = WebhookVerifier(SECRET)

    for fixture in fixtures:
        body = json.dumps(fixture)
        sig = _build_signature(body, SECRET)
        parsed = verifier.verify(body, sig)

        # Must use `event` field, not `type`
        assert "event" in parsed, f"Missing 'event' field in {fixture['event']}"
        assert "type" not in parsed, f"Found 'type' field instead of 'event' in {fixture['event']}"
        assert parsed["event"] == fixture["event"]


def test_every_fixture_has_base_fields(fixtures):
    """Every fixture data must contain all base fields."""
    if not fixtures:
        pytest.skip("No fixtures loaded")

    for fixture in fixtures:
        data = fixture["data"]
        for field in BASE_FIELDS:
            assert field in data, (
                f"Missing base field '{field}' in {fixture['event']} data"
            )


def test_every_fixture_has_event_specific_fields(fixtures):
    """Fixtures with known event types must contain their event-specific fields."""
    if not fixtures:
        pytest.skip("No fixtures loaded")

    for fixture in fixtures:
        event_type = fixture["event"]
        extra_fields = EVENT_SPECIFIC_FIELDS.get(event_type)
        if not extra_fields:
            continue

        data = fixture["data"]
        for field in extra_fields:
            assert field in data, (
                f"Missing event-specific field '{field}' in {event_type} data"
            )


def test_every_fixture_has_created_at(fixtures):
    """Every fixture must have a createdAt ISO-8601 timestamp."""
    if not fixtures:
        pytest.skip("No fixtures loaded")

    for fixture in fixtures:
        assert "createdAt" in fixture, f"Missing 'createdAt' in {fixture['event']}"
        assert isinstance(fixture["createdAt"], str)


# ─── Negative verification tests ─────────────────────────────────────────────


SAMPLE_PAYLOAD = {
    "event": "payin.confirmed",
    "data": {
        "transactionId": "txn_neg_001",
        "status": "CONFIRMED",
        "currency": "USDT_TRC20",
        "chain": "TRON",
        "externalRef": "order-neg",
    },
    "createdAt": "2025-03-15T12:00:00.000Z",
}
SAMPLE_BODY = json.dumps(SAMPLE_PAYLOAD)


def test_reject_invalid_signature():
    """Verifier should reject a payload with a wrong HMAC."""
    verifier = WebhookVerifier(SECRET)
    ts = int(time.time())
    bad_sig = f"t={ts},v1={'0' * 64}"

    with pytest.raises(ValueError):
        verifier.verify(SAMPLE_BODY, bad_sig)


def test_reject_expired_timestamp():
    """Verifier should reject a payload with an expired timestamp."""
    verifier = WebhookVerifier(SECRET)
    old_ts = int(time.time()) - 400
    signed_payload = f"{old_ts}.{SAMPLE_BODY}"
    digest = hmac.new(
        SECRET.encode("utf-8"),
        signed_payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    sig = f"t={old_ts},v1={digest}"

    with pytest.raises(ValueError):
        verifier.verify(SAMPLE_BODY, sig)


def test_reject_tampered_payload():
    """Verifier should reject a payload that was modified after signing."""
    verifier = WebhookVerifier(SECRET)
    sig = _build_signature(SAMPLE_BODY, SECRET)
    tampered = json.dumps({**SAMPLE_PAYLOAD, "event": "payin.expired"})

    with pytest.raises(ValueError):
        verifier.verify(tampered, sig)


def test_reject_missing_event_field():
    """Verifier should still verify signature, but parsed result has no 'event'."""
    verifier = WebhookVerifier(SECRET)
    no_event = {"data": SAMPLE_PAYLOAD["data"], "createdAt": SAMPLE_PAYLOAD["createdAt"]}
    no_event_body = json.dumps(no_event)
    sig = _build_signature(no_event_body, SECRET)
    # Signature is valid but parsed payload has no "event" field
    parsed = verifier.verify(no_event_body, sig)
    assert "event" not in parsed


def test_reject_wrong_hmac_algorithm():
    """Verifier should reject a signature computed with a different secret."""
    verifier = WebhookVerifier(SECRET)
    wrong_secret = "whsec_completely_wrong_secret"
    ts = int(time.time())
    signed_payload = f"{ts}.{SAMPLE_BODY}"
    digest = hmac.new(
        wrong_secret.encode("utf-8"),
        signed_payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    sig = f"t={ts},v1={digest}"

    with pytest.raises(ValueError):
        verifier.verify(SAMPLE_BODY, sig)
