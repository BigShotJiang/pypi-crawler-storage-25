"""Tests for the Python SDK BulkPayments resource."""

import json
import pytest
import responses as resp_mock
from zyndpay import ZyndPay

API_KEY = "zyp_test_sk_test123"
BASE_URL = "https://api.zyndpay.io/v1"


@pytest.fixture
def client():
    return ZyndPay(api_key=API_KEY)


def api_response(data):
    return json.dumps({"success": True, "data": data})


BATCH = {"id": "batch_abc", "status": "DRAFT", "label": "Test batch", "itemCount": 0}
VALIDATED_BATCH = {**BATCH, "status": "VALIDATED", "totalFee": "1.50", "totalAmount": "100.00"}


@resp_mock.activate
def test_create_posts_to_bulk_payments(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/bulk-payments",
        body=api_response(BATCH), content_type="application/json")
    result = client.bulk_payments.create(label="Test batch")
    req = resp_mock.calls[0].request
    assert req.method == "POST"
    assert req.url == f"{BASE_URL}/bulk-payments"
    assert result["id"] == "batch_abc"


@resp_mock.activate
def test_create_sends_label(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/bulk-payments",
        body=api_response(BATCH), content_type="application/json")
    client.bulk_payments.create(label="Test batch")
    body = json.loads(resp_mock.calls[0].request.body)
    assert body["label"] == "Test batch"


@resp_mock.activate
def test_create_sends_idempotency_key(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/bulk-payments",
        body=api_response(BATCH), content_type="application/json")
    client.bulk_payments.create(label="Test", idempotency_key="idem_batch_001")
    assert resp_mock.calls[0].request.headers.get("Idempotency-Key") == "idem_batch_001"


@resp_mock.activate
def test_add_items_posts_to_items_path(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/bulk-payments/batch_abc/items",
        body=api_response({**BATCH, "itemCount": 2}), content_type="application/json")
    items = [
        {"walletAddress": "TXyz1", "amount": "50.00", "recipientName": "Vendor A"},
        {"walletAddress": "TXyz2", "amount": "50.00", "recipientName": "Vendor B"},
    ]
    result = client.bulk_payments.add_items("batch_abc", items)
    req = resp_mock.calls[0].request
    assert req.method == "POST"
    assert "/bulk-payments/batch_abc/items" in req.url
    body = json.loads(req.body)
    assert body["items"] == items
    assert result["itemCount"] == 2


@resp_mock.activate
def test_validate_posts_to_validate_path(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/bulk-payments/batch_abc/validate",
        body=api_response(VALIDATED_BATCH), content_type="application/json")
    result = client.bulk_payments.validate("batch_abc")
    assert resp_mock.calls[0].request.method == "POST"
    assert "/validate" in resp_mock.calls[0].request.url
    assert result["status"] == "VALIDATED"


@resp_mock.activate
def test_execute_posts_to_execute_path(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/bulk-payments/batch_abc/execute",
        body=api_response({**BATCH, "status": "PROCESSING"}), content_type="application/json")
    result = client.bulk_payments.execute("batch_abc")
    assert "/execute" in resp_mock.calls[0].request.url
    assert result["status"] == "PROCESSING"


@resp_mock.activate
def test_retry_posts_to_retry_path(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/bulk-payments/batch_abc/retry",
        body=api_response({**BATCH, "status": "PROCESSING"}), content_type="application/json")
    client.bulk_payments.retry("batch_abc")
    assert "/retry" in resp_mock.calls[0].request.url
    assert resp_mock.calls[0].request.method == "POST"


@resp_mock.activate
def test_cancel_posts_to_cancel_path(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/bulk-payments/batch_abc/cancel",
        body=api_response({**BATCH, "status": "CANCELLED"}), content_type="application/json")
    client.bulk_payments.cancel("batch_abc")
    assert "/cancel" in resp_mock.calls[0].request.url


@resp_mock.activate
def test_list_gets_bulk_payments(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/bulk-payments",
        body=api_response({"items": [BATCH], "total": 1}), content_type="application/json")
    result = client.bulk_payments.list()
    req = resp_mock.calls[0].request
    assert req.method == "GET"
    assert req.url.startswith(f"{BASE_URL}/bulk-payments")
    assert result["total"] == 1


@resp_mock.activate
def test_list_sends_filters(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/bulk-payments",
        body=api_response({"items": [], "total": 0}), content_type="application/json")
    client.bulk_payments.list(page=2, limit=10, status="DRAFT")
    url = resp_mock.calls[0].request.url
    assert "page=2" in url
    assert "limit=10" in url
    assert "status=DRAFT" in url


@resp_mock.activate
def test_get_fetches_batch_by_id(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/bulk-payments/batch_abc",
        body=api_response({**BATCH, "items": []}), content_type="application/json")
    result = client.bulk_payments.get("batch_abc")
    req = resp_mock.calls[0].request
    assert req.url == f"{BASE_URL}/bulk-payments/batch_abc"
    assert result["id"] == "batch_abc"
