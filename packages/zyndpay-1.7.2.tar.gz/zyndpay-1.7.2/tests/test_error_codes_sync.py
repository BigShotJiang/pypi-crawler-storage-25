"""
Ensure the Python ErrorCodes catalog stays in sync with the TS source of truth
at packages/types/src/error-codes.ts.
"""
from __future__ import annotations

import re
from pathlib import Path

from zyndpay import ErrorCodes


def _ts_catalog_path() -> Path:
    # packages/sdk-python/tests/ → repo root
    return Path(__file__).resolve().parents[3] / "packages" / "types" / "src" / "error-codes.ts"


def _parse_ts_codes() -> set[str]:
    ts = _ts_catalog_path().read_text(encoding="utf-8")
    # Only parse the ErrorCodes const block (stop at `} as const;`)
    match = re.search(
        r"export const ErrorCodes\s*=\s*\{(.*?)\}\s*as const;", ts, re.DOTALL
    )
    assert match, "Could not locate ErrorCodes const in TS catalog"
    body = match.group(1)
    return set(re.findall(r"^\s*([A-Z][A-Z0-9_]+)\s*:", body, re.MULTILINE))


def _py_codes() -> set[str]:
    return {
        name
        for name in vars(ErrorCodes)
        if name.isupper() and not name.startswith("_")
    }


def test_python_catalog_matches_typescript() -> None:
    ts_codes = _parse_ts_codes()
    py_codes = _py_codes()

    missing_in_python = ts_codes - py_codes
    extra_in_python = py_codes - ts_codes

    assert not missing_in_python, (
        f"TS codes missing from Python catalog: {sorted(missing_in_python)}"
    )
    assert not extra_in_python, (
        f"Python codes not in TS catalog: {sorted(extra_in_python)}"
    )


def test_every_code_value_equals_its_name() -> None:
    for name in _py_codes():
        assert getattr(ErrorCodes, name) == name, (
            f"ErrorCodes.{name} value does not match its name"
        )
