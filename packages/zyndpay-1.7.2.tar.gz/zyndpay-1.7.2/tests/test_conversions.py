"""Tests for the Python SDK Conversions resource."""
import json
import pytest
import responses as resp_mock
from zyndpay import ZyndPay

API_KEY = "zyp_test_sk_test123"
BASE_URL = "https://api.zyndpay.io/v1"

@pytest.fixture
def client():
    return ZyndPay(api_key=API_KEY)

def api_response(data):
    return json.dumps({"success": True, "data": data})

CONVERSION = {"id": "conv_abc123", "status": "COMPLETED",
              "fromWalletId": "wlt_xof_def", "toWalletId": "wlt_usdt_abc",
              "fromAmount": "50000", "toAmount": "85.23", "rate": "587.75",
              "createdAt": "2026-04-29T10:00:00.000Z"}

@resp_mock.activate
def test_convert_between_wallets_posts_correct(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/conversions/wallet",
        body=api_response(CONVERSION), content_type="application/json")
    result = client.conversions.convert_between_wallets(
        from_wallet_id="wlt_xof_def", to_wallet_id="wlt_usdt_abc", from_amount="50000")
    req = resp_mock.calls[0].request
    assert req.url == f"{BASE_URL}/conversions/wallet"
    assert req.method == "POST"
    body = json.loads(req.body)
    assert body["fromWalletId"] == "wlt_xof_def"
    assert body["toWalletId"] == "wlt_usdt_abc"
    assert body["fromAmount"] == "50000"
    assert result["id"] == "conv_abc123"

@resp_mock.activate
def test_get_fetches_conversion_by_id(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/conversions/conv_abc123",
        body=api_response(CONVERSION), content_type="application/json")
    result = client.conversions.get("conv_abc123")
    assert resp_mock.calls[0].request.url == f"{BASE_URL}/conversions/conv_abc123"
    assert result["id"] == "conv_abc123"

@resp_mock.activate
def test_list_calls_conversions(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/conversions",
        body=api_response([CONVERSION]), content_type="application/json")
    client.conversions.list()
    assert resp_mock.calls[0].request.url.startswith(f"{BASE_URL}/conversions")

@resp_mock.activate
def test_list_sends_filters(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/conversions",
        body=api_response([]), content_type="application/json")
    client.conversions.list(status="COMPLETED", page=2, limit=10)
    url = resp_mock.calls[0].request.url
    assert "status=COMPLETED" in url
    assert "page=2" in url
    assert "limit=10" in url

@resp_mock.activate
def test_convert_sends_idempotency_key_header(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/conversions/wallet",
        body=api_response(CONVERSION), content_type="application/json")
    client.conversions.convert_between_wallets(
        from_wallet_id="wlt_xof_def", to_wallet_id="wlt_usdt_abc",
        from_amount="50000", idempotency_key="idem_conv_001")
    req = resp_mock.calls[0].request
    assert req.headers.get("Idempotency-Key") == "idem_conv_001"


def test_client_exposes_conversions_property(client):
    from zyndpay.resources.conversions import Conversions
    assert hasattr(client, "conversions")
    assert isinstance(client.conversions, Conversions)
