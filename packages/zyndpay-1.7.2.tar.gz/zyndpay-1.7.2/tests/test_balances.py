"""Tests for the Python SDK Balances resource."""

import json
import pytest
import responses as resp_mock
from zyndpay import ZyndPay

API_KEY = "zyp_test_sk_test123"
BASE_URL = "https://api.zyndpay.io/v1"


@pytest.fixture
def client():
    return ZyndPay(api_key=API_KEY)


def api_response(data):
    return json.dumps({"success": True, "data": data})


USDT_BALANCE = {"currency": "USDT_TRC20", "balance": "245.50", "pending": "10.00"}
ALL_BALANCES = {"USDT_TRC20": "245.50", "XOF": "150000"}


@resp_mock.activate
def test_get_calls_usdt_balance_endpoint(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/merchant/balances/USDT_TRC20",
        body=api_response(USDT_BALANCE), content_type="application/json")
    result = client.balances.get()
    req = resp_mock.calls[0].request
    assert req.method == "GET"
    assert req.url == f"{BASE_URL}/merchant/balances/USDT_TRC20"
    assert req.headers["X-Api-Key"] == API_KEY
    assert result["currency"] == "USDT_TRC20"


@resp_mock.activate
def test_get_returns_data_field(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/merchant/balances/USDT_TRC20",
        body=api_response(USDT_BALANCE), content_type="application/json")
    result = client.balances.get()
    assert result == USDT_BALANCE


@resp_mock.activate
def test_get_all_calls_balances_endpoint(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/merchant/balances",
        body=api_response(ALL_BALANCES), content_type="application/json")
    result = client.balances.get_all()
    req = resp_mock.calls[0].request
    assert req.url == f"{BASE_URL}/merchant/balances"
    assert req.method == "GET"
    assert result == ALL_BALANCES


@resp_mock.activate
def test_get_by_currency_calls_correct_path(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/merchant/balances/XOF",
        body=api_response({"currency": "XOF", "balance": "150000"}),
        content_type="application/json")
    result = client.balances.get_by_currency("XOF")
    req = resp_mock.calls[0].request
    assert req.url == f"{BASE_URL}/merchant/balances/XOF"
    assert result["currency"] == "XOF"


def test_get_by_currency_rejects_invalid_format(client):
    with pytest.raises((ValueError, Exception)):
        client.balances.get_by_currency("INVALID CURRENCY!")


def test_client_exposes_balances_property(client):
    from zyndpay.resources.balances import Balances
    assert hasattr(client, "balances")
    assert isinstance(client.balances, Balances)
