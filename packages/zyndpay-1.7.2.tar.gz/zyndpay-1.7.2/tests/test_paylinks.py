"""Tests for the Python SDK Paylinks resource."""

import json
import pytest
import responses as resp_mock
from zyndpay import ZyndPay

API_KEY = "zyp_test_sk_test123"
BASE_URL = "https://api.zyndpay.io/v1"


@pytest.fixture
def client():
    return ZyndPay(api_key=API_KEY)


def api_response(data):
    return json.dumps({"success": True, "data": data})


PAYLINK = {"id": "pl_abc", "slug": "test-link", "status": "ACTIVE",
           "paymentUrl": "https://pay.zyndpay.io/pl_abc"}
PROMO = {"id": "pc_1", "code": "SAVE10", "discountType": "PERCENTAGE",
         "discountValue": "10", "isActive": True}
TEMPLATE = {"id": "tmpl_1", "name": "My Template"}
SUBSCRIPTION = {"id": "sub_1", "status": "ACTIVE", "customerEmail": "test@example.com"}


@resp_mock.activate
def test_create_posts_to_paylinks(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/paylinks",
        body=api_response(PAYLINK), content_type="application/json")
    result = client.paylinks.create(products=[{"name": "Product", "price": "10.00"}])
    req = resp_mock.calls[0].request
    assert req.method == "POST"
    assert req.url == f"{BASE_URL}/paylinks"
    assert result["id"] == "pl_abc"


@resp_mock.activate
def test_create_sends_products_in_body(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/paylinks",
        body=api_response(PAYLINK), content_type="application/json")
    client.paylinks.create(products=[{"name": "Product", "price": "10.00"}])
    body = json.loads(resp_mock.calls[0].request.body)
    assert "products" in body
    assert body["products"][0]["name"] == "Product"


@resp_mock.activate
def test_get_fetches_by_id(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/paylinks/pl_abc",
        body=api_response(PAYLINK), content_type="application/json")
    result = client.paylinks.get("pl_abc")
    assert resp_mock.calls[0].request.url == f"{BASE_URL}/paylinks/pl_abc"
    assert result["id"] == "pl_abc"


@resp_mock.activate
def test_list_gets_paylinks(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/paylinks",
        body=api_response({"items": [PAYLINK], "total": 1}), content_type="application/json")
    result = client.paylinks.list()
    assert resp_mock.calls[0].request.method == "GET"
    assert result["total"] == 1


@resp_mock.activate
def test_update_patches_paylink(client):
    resp_mock.add(resp_mock.PATCH, f"{BASE_URL}/paylinks/pl_abc",
        body=api_response({**PAYLINK, "status": "PAUSED"}), content_type="application/json")
    result = client.paylinks.update("pl_abc", status="PAUSED")
    req = resp_mock.calls[0].request
    assert req.method == "PATCH"
    assert "/paylinks/pl_abc" in req.url
    body = json.loads(req.body)
    assert body["status"] == "PAUSED"


@resp_mock.activate
def test_delete_sends_delete_request(client):
    resp_mock.add(resp_mock.DELETE, f"{BASE_URL}/paylinks/pl_abc",
        body=json.dumps({"success": True}), content_type="application/json")
    client.paylinks.delete("pl_abc")
    assert resp_mock.calls[0].request.method == "DELETE"
    assert "/paylinks/pl_abc" in resp_mock.calls[0].request.url


@resp_mock.activate
def test_get_stats_calls_stats_endpoint(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/paylinks/pl_abc/stats",
        body=api_response({"orders": 10, "revenue": "100.00", "conversionRate": "0.5"}),
        content_type="application/json")
    result = client.paylinks.get_stats("pl_abc")
    assert "/paylinks/pl_abc/stats" in resp_mock.calls[0].request.url
    assert result["orders"] == 10


@resp_mock.activate
def test_list_orders_calls_orders_endpoint(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/paylinks/pl_abc/orders",
        body=api_response({"items": [], "total": 0}), content_type="application/json")
    client.paylinks.list_orders("pl_abc")
    assert "/paylinks/pl_abc/orders" in resp_mock.calls[0].request.url


@resp_mock.activate
def test_create_promo_code_posts(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/paylinks/pl_abc/promo-codes",
        body=api_response(PROMO), content_type="application/json")
    result = client.paylinks.create_promo_code(
        "pl_abc",
        code="SAVE10",
        discount_type="PERCENTAGE",
        discount_value="10",
    )
    req = resp_mock.calls[0].request
    assert req.method == "POST"
    assert "/paylinks/pl_abc/promo-codes" in req.url
    assert result["code"] == "SAVE10"


@resp_mock.activate
def test_list_promo_codes_gets(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/paylinks/pl_abc/promo-codes",
        body=api_response([PROMO]), content_type="application/json")
    result = client.paylinks.list_promo_codes("pl_abc")
    assert isinstance(result, list)
    assert result[0]["code"] == "SAVE10"


@resp_mock.activate
def test_toggle_promo_code_patches(client):
    resp_mock.add(resp_mock.PATCH, f"{BASE_URL}/paylinks/pl_abc/promo-codes/pc_1",
        body=api_response({**PROMO, "isActive": False}), content_type="application/json")
    result = client.paylinks.toggle_promo_code("pl_abc", "pc_1", False)
    req = resp_mock.calls[0].request
    assert req.method == "PATCH"
    assert "/promo-codes/pc_1" in req.url
    body = json.loads(req.body)
    assert body["isActive"] is False


@resp_mock.activate
def test_delete_promo_code_deletes(client):
    resp_mock.add(resp_mock.DELETE, f"{BASE_URL}/paylinks/pl_abc/promo-codes/pc_1",
        body=json.dumps({"success": True}), content_type="application/json")
    client.paylinks.delete_promo_code("pl_abc", "pc_1")
    assert resp_mock.calls[0].request.method == "DELETE"


@resp_mock.activate
def test_create_template_posts(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/paylinks/templates",
        body=api_response(TEMPLATE), content_type="application/json")
    result = client.paylinks.create_template("My Template", {"products": []})
    assert "/paylinks/templates" in resp_mock.calls[0].request.url
    assert resp_mock.calls[0].request.method == "POST"
    assert result["name"] == "My Template"


@resp_mock.activate
def test_list_templates_gets(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/paylinks/templates",
        body=api_response([TEMPLATE]), content_type="application/json")
    result = client.paylinks.list_templates()
    assert isinstance(result, list)


@resp_mock.activate
def test_delete_template_deletes(client):
    resp_mock.add(resp_mock.DELETE, f"{BASE_URL}/paylinks/templates/tmpl_1",
        body=json.dumps({"success": True}), content_type="application/json")
    client.paylinks.delete_template("tmpl_1")
    assert resp_mock.calls[0].request.method == "DELETE"
    assert "/paylinks/templates/tmpl_1" in resp_mock.calls[0].request.url


@resp_mock.activate
def test_save_as_template_posts(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/paylinks/pl_abc/save-as-template",
        body=api_response(TEMPLATE), content_type="application/json")
    result = client.paylinks.save_as_template("pl_abc", "My Template")
    req = resp_mock.calls[0].request
    assert "/save-as-template" in req.url
    body = json.loads(req.body)
    assert body["name"] == "My Template"


@resp_mock.activate
def test_list_subscriptions_gets(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/paylinks/pl_abc/subscriptions",
        body=api_response([SUBSCRIPTION]), content_type="application/json")
    result = client.paylinks.list_subscriptions("pl_abc")
    assert "/subscriptions" in resp_mock.calls[0].request.url
    assert isinstance(result, list)


@resp_mock.activate
def test_cancel_subscription_posts(client):
    resp_mock.add(resp_mock.POST, f"{BASE_URL}/paylinks/pl_abc/subscriptions/sub_1/cancel",
        body=api_response({"status": "CANCELLED"}), content_type="application/json")
    client.paylinks.cancel_subscription("pl_abc", "sub_1")
    assert "/subscriptions/sub_1/cancel" in resp_mock.calls[0].request.url
    assert resp_mock.calls[0].request.method == "POST"
