"""Tests for the Python SDK Wallets resource."""
import json
import pytest
import responses as resp_mock
from zyndpay import ZyndPay

API_KEY = "zyp_test_sk_test123"
BASE_URL = "https://api.zyndpay.io/v1"

@pytest.fixture
def client():
    return ZyndPay(api_key=API_KEY)

def api_response(data):
    return json.dumps({"success": True, "data": data})

WALLET_USDT = {"id": "wlt_usdt_abc", "currency": "USDT_TRC20", "rail": "TRC20",
               "status": "ACTIVE", "withdrawEnabled": True, "balance": "245.50"}
WALLET_XOF = {"id": "wlt_xof_def", "currency": "XOF", "rail": "MOMO",
              "status": "ACTIVE", "withdrawEnabled": True, "balance": "150000"}

@resp_mock.activate
def test_list_calls_merchants_wallets(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/merchants/wallets",
        body=api_response([WALLET_USDT, WALLET_XOF]), content_type="application/json")
    client.wallets.list()
    req = resp_mock.calls[0].request
    assert req.url == f"{BASE_URL}/merchants/wallets"
    assert req.method == "GET"
    assert req.headers["X-Api-Key"] == API_KEY

@resp_mock.activate
def test_list_returns_wallet_array(client):
    resp_mock.add(resp_mock.GET, f"{BASE_URL}/merchants/wallets",
        body=api_response([WALLET_USDT, WALLET_XOF]), content_type="application/json")
    result = client.wallets.list()
    assert isinstance(result, list)
    assert len(result) == 2
    assert result[0]["currency"] == "USDT_TRC20"

def test_client_exposes_wallets_property(client):
    from zyndpay.resources.wallets import Wallets
    assert hasattr(client, "wallets")
    assert isinstance(client.wallets, Wallets)
