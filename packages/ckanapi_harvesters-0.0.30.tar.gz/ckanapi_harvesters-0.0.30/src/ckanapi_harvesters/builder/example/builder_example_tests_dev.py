#!python3
# -*- coding: utf-8 -*-
"""
Tests to perform after the example package was uploaded
"""
import os
import json

import pandas as pd

from ckanapi_harvesters.auxiliary import CkanMap
from ckanapi_harvesters.builder.builder_package import BuilderPackage
from ckanapi_harvesters.ckan_api import CkanApi

from ckanapi_harvesters.builder.example import example_package_xls, example_package_resources_dir


def traces_chunks_generator(chunksize:int):
    traces_file = os.path.join(example_package_resources_dir, "traces", "trace_000.csv")
    return pd.read_csv(traces_file, chunksize=chunksize)


def run(ckan:CkanApi = None):
    BuilderPackage.unlock_external_code_execution()  # comment to test if the safety feature is enabled

    mdl = BuilderPackage.from_excel(example_package_xls)
    ckan = mdl.init_ckan(ckan)
    ckan.initialize_from_cli_args()
    ckan.input_missing_info(input_args_if_necessary=True, input_owner_org=True)
    ckan.set_verbosity(True)

    # Tests on get_resource_id: map package of a given resource
    resource_id = mdl.get_or_query_resource_id(ckan, resource_name="traces.csv")
    is_datastore = ckan.resource_is_datastore(resource_id)
    ckan.map.purge()
    resource_info = ckan.get_resource_info_or_request(resource_id)
    package_info_None = ckan.map.get_package_info(resource_info.package_id, error_not_mapped=False)
    resource_info = ckan.get_resource_info_or_request(resource_id, map_package=True)
    package_info = ckan.map.get_package_info(resource_info.package_id)
    resource_page_url = ckan.get_resource_page_url(resource_id)
    resource_download_url = ckan.get_resource_download_url(resource_id)
    resource_dump_url = ckan.get_datastore_search_url(resource_id, search_method=False)
    resource_search_url = ckan.get_datastore_search_url(resource_id, search_method=True)
    package_info = ckan.package_show(resource_info.package_id, cancel_if_exists=False)
    ckan.map.purge()
    res = ckan.package_search_all(filter={"id": package_info.id})
    ckan.map.purge()
    ckan.map_resources(resource_info.package_id)

    # Test sending the traces in a generator mode
    with traces_chunks_generator(chunksize=6) as records_generator:
        counters = ckan.datastore_upsert(records_generator, resource_id=resource_id, request_threshold=15, offset=12)
    with (traces_chunks_generator(chunksize=6) as records_generator):
        counters_total_limit = ckan.datastore_upsert(records_generator, resource_id=resource_id, request_threshold=15, offset=12, total_limit=21)

    # test full requests datastore_search
    df_10 = ckan.datastore_search(resource_id, limit_per_request=10, search_all=False)
    df_20 = ckan.datastore_search(resource_id, limit_per_request=10, total_limit=15, search_all=True)
    responses_20 = ckan.datastore_search(resource_id, limit_per_request=10, total_limit=15, search_all=True, return_df=False)
    # test page generators
    page_20 = ckan.datastore_search_page_generator(resource_id, limit_per_request=10, total_limit=15, search_all=True)
    count_page_20 = 0
    for df in page_20:
        count_page_20 += len(df)
    # test cursors
    cursor_20 = ckan.datastore_search_cursor(resource_id, limit_per_request=10, total_limit=15, search_all=True)
    count_cursor_20 = 0
    for document in cursor_20:
        count_cursor_20 += 1
    assert(len(df_20) == 15 and len(responses_20) == 15 and count_page_20 == 15 and count_cursor_20 == 15)

    # test full requests datastore_search_sql
    if ckan.test_sql_capabilities():
        query = f'SELECT * FROM "{resource_id}"'
        df_10 = ckan.datastore_search_sql(query, limit_per_request=10, search_all=False)
        df_20 = ckan.datastore_search_sql(query, limit_per_request=10, total_limit=15, search_all=True)
        responses_20 = ckan.datastore_search_sql(query, limit_per_request=10, total_limit=15, search_all=True, return_df=False)
        # test page generators
        page_20 = ckan.datastore_search_sql_page_generator(query, limit_per_request=10, total_limit=15, search_all=True)
        count_page_20 = 0
        for df in page_20:
            count_page_20 += len(df)
        # test cursors
        cursor_20 = ckan.datastore_search_sql_cursor(query, limit_per_request=10, total_limit=15, search_all=True)
        count_cursor_20 = 0
        for document in cursor_20:
            count_cursor_20 += 1
        assert(len(df_20) == 15 and len(responses_20) == 15 and count_page_20 == 15 and count_cursor_20 == 15)

    # Test re-encoding the Excel file from the loaded model
    example_package_xls_reencoded = os.path.abspath("builder_package_example-reencoded.xlsx")
    mdl.to_excel(example_package_xls_reencoded)

    # map package
    ckan.map_resources(mdl.package_name, datastore_info=True, license_list=True)
    map_init = ckan.map.copy()
    ckan.purge(purge_map=True)

    # Test using the model to update CKAN map (update_ckan_map)
    mdl.info_request_full(ckan)
    map_queried = ckan.map.copy()
    ckan.purge(purge_map=True)
    mdl.update_ckan_map(ckan)  # use known resource ids to fill ckan.map (at your own risks)
    map_from_mdl = ckan.map.copy()

    # Test saving the map to a dictionary
    dict_map_queried = map_queried.to_dict()
    map_queried_from_dict = CkanMap.from_dict(dict_map_queried)

    dict_map_from_mdl = map_from_mdl.to_dict()
    map_from_mdl_from_dict = CkanMap.from_dict(dict_map_from_mdl)

    # test the function that recreates the Excel file from the online information
    ckan.purge(purge_map=True)
    mdl_api = BuilderPackage.from_ckan(ckan, mdl.package_name)
    example_package_xls_from_api = os.path.abspath("builder_package_example-from-api.xlsx")
    mdl_api.to_excel(example_package_xls_from_api)

    # export mdl to dict and re-import
    base_dir = os.path.abspath(".")
    mdl_dict = mdl.to_dict(base_dir=base_dir)
    mdl_from_dict = BuilderPackage.from_dict(mdl_dict, base_dir=base_dir)
    mdl_dict_bis = mdl_from_dict.to_dict(base_dir=base_dir)
    assert(mdl_dict == mdl_dict_bis)

    # test json serialization
    example_package_json_reencoded = os.path.abspath("builder_package_example-reencoded.json")
    with open(example_package_json_reencoded, "w") as json_file:
        json.dump(mdl_dict, json_file, indent=4)
        json_file.close()

    # test copy constructors
    ckan_copy = ckan.copy()
    mdl_copy = mdl.copy()
    mdl_copy_dict = mdl_copy.to_dict(base_dir=base_dir)
    assert(mdl_dict == mdl_copy_dict)

    print("Tests done.")


if __name__ == '__main__':
    ckan = CkanApi(None)
    ckan.initialize_from_cli_args()
    run(ckan)

