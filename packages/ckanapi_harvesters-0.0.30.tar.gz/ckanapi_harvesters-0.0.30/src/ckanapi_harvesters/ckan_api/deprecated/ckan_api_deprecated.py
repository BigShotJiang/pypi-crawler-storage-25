#!python3
# -*- coding: utf-8 -*-
"""

"""
from typing import List, Union, Any, Generator, Tuple, Iterable
import copy
from warnings import warn

import pandas as pd

from ckanapi_harvesters.auxiliary.ckan_model import CkanPackageInfo, CkanResourceInfo, CkanViewInfo
from ckanapi_harvesters.auxiliary.ckan_model import UpsertChoice
from ckanapi_harvesters.auxiliary.ckan_auxiliary import RequestType, assert_or_raise, LinesRequestCounter
from ckanapi_harvesters.auxiliary.ckan_action import CkanActionNotFoundError, CkanActionResponse
from ckanapi_harvesters.auxiliary.ckan_errors import ReadOnlyError
from ckanapi_harvesters.auxiliary.list_records import ListRecords, GeneralDataFrame
from ckanapi_harvesters.auxiliary.ckan_progress_callbacks_abc import CkanProgressCallbackABC
from ckanapi_harvesters.harvesters.data_cleaner.data_cleaner_abc import CkanDataCleanerABC
from ckanapi_harvesters.ckan_api.ckan_api_0_base import use_ckan_owner_org_for_requests

from ckanapi_harvesters.ckan_api.ckan_api_5_manage import CkanApiManage



class CkanApiDeprecated(CkanApiManage):
    """
    CKAN Database API interface to CKAN server with helper functions using pandas DataFrames.
    This class implements API calls which are not recommended to use.
    """

    def copy(self, new_identifier: str = None, *, dest=None):
        if dest is None:
            dest = CkanApiDeprecated()
        super().copy(new_identifier=new_identifier, dest=dest)
        return dest

    ## Not working read functions ------------------
    def datastore_search_sql_row_count(self, sql:str, *, params:dict=None) -> int:
        raise NotImplementedError("API does not return total number of rows")
        df_row = self.datastore_search_sql_find_one(sql, offset=0, params=params, return_df=True)
        return df_row.attrs["total"]

    ## Not recommended read functions ------------------
    def datastore_dump(self, resource_id:str, *, filters:dict=None, q:str=None, fields:List[str]=None,
                       distinct:bool=None, sort:str=None, limit_per_request:int=None, offset:int=0,
                       total_limit:int=None, requests_limit:int=None, progress_callback:CkanProgressCallbackABC=None,
                       params:dict=None, search_all:bool=True, search_method:bool=True, format:str=None,
                       return_df:bool=True, limit:int=None) \
            -> Union[pd.DataFrame, ListRecords, Any, List[CkanActionResponse]]:
        """
        Alias of datastore_search with search_all=True by default.
        Uses the API datastore_search

        :see: datastore_search()
        :param resource_id: resource id.
        :param filters: The base argument to filter values in a table (optional)
        :param q: Full text query (optional)
        :param fields: The base argument to filter columns (optional)
        :param distinct: return only distinct rows (optional, default: false) e.g. to return distinct ids: fields="id", distinct=True
        :param sort: Argument to sort results e.g. sort="index, quantity desc"  or  sort="index asc"
        :param limit_per_request: Limit the number of records per request
        :param offset: Offset in the returned records
        :param total_limit: Strictly limit the number of records to return, counting from the initial offset
        :param requests_limit: Limit the number of requests
        :param progress_callback: Progress callback function
        :param params: Additional parameters such as filters, q, sort and fields can be given. See DataStore API documentation.
        :param search_all: Option to renew the request until there are no more records.
        :param search_method: API method selection (True=datastore_search, False=datastore_dump)
        :param return_df: Return pandas DataFrame (True) or dict (False)
        :return:
        """
        msg = "datastore_dump is deprecated. Use datastore_search() instead. To enforce usage of API datastore/dump, use option search_method=False"
        warn(msg, DeprecationWarning)
        return self.datastore_search(resource_id, filters=filters, q=q, fields=fields,
                                     distinct=distinct, sort=sort, limit_per_request=limit_per_request, offset=offset,
                                     total_limit=total_limit, requests_limit=requests_limit, limit=limit,
                                     progress_callback=progress_callback, params=params, search_all=search_all,
                                     search_method=search_method, format=format,
                                     return_df=return_df)

    def datastore_dump_page_generator(self, resource_id:str, *, filters:dict=None, q:str=None, fields:List[str]=None,
                                      distinct:bool=None, sort:str=None, limit_per_request:int=None, offset:int=0,
                                      total_limit:int=None, requests_limit:int=None, progress_callback:CkanProgressCallbackABC=None, params:dict=None,
                                      search_all:bool=True, search_method:bool=True, format:str=None, bom:bool=None, return_df:bool=True, limit:int=None) \
            -> Union[Generator[pd.DataFrame, Any, None], Generator[CkanActionResponse, Any, None]]:
        """
        Function alias to datastore_search_generator with search_all=True by default.
        Uses the API datastore_search

        :see: datastore_search_generator
        :param resource_id: resource id.
        :param filters: The base argument to filter values in a table (optional)
        :param q: Full text query (optional)
        :param fields: The base argument to filter columns (optional)
        :param distinct: return only distinct rows (optional, default: false) e.g. to return distinct ids: fields="id", distinct=True
        :param sort: Argument to sort results e.g. sort="index, quantity desc"  or  sort="index asc"
        :param limit_per_request: Limit the number of records per request
        :param total_limit: Strictly limit the number of records to return, counting from the initial offset
        :param requests_limit: Limit the number of requests
        :param progress_callback: Progress callback function
        :param offset: Offset in the returned records
        :param params: Additional parameters such as filters, q, sort and fields can be given. See DataStore API documentation.
        :param search_all: Option to renew the request until there are no more records.
        :param search_method: API method selection (True=datastore_search, False=datastore_dump)
        :return:
        """
        msg = "datastore_dump is deprecated. Use datastore_search() instead. To enforce usage of API datastore/dump, use option search_method=False"
        warn(msg, DeprecationWarning)
        return self.datastore_search_page_generator(resource_id, filters=filters, q=q, fields=fields,
                                                    distinct=distinct, sort=sort, limit_per_request=limit_per_request, offset=offset,
                                                    total_limit=total_limit, requests_limit=requests_limit, progress_callback=progress_callback, params=params,
                                                    search_all=search_all, search_method=search_method, format=format, bom=bom, return_df=return_df, limit=limit)

    ## Not recommended write functions ------------------
    def datastore_insert(self, records_generator:Union[pd.DataFrame, List[dict], Iterable[GeneralDataFrame]], resource_id:str, *,
                         dry_run:bool=False, limit_per_request:int=None, offset:int=0,
                         total_limit:int=None, requests_limit:int=None, force:bool=None,
                         apply_last_condition:bool=True, always_last_condition:bool=None, return_df:bool=None,
                         data_cleaner:CkanDataCleanerABC=None, progress_callback:CkanProgressCallbackABC=None,
                         params:dict=None, records:Union[pd.DataFrame, List[dict]]=None,
                         return_documents:bool=True, return_counters:bool=False, limit:int=None) \
            -> Union[Union[pd.DataFrame, List[dict]], Tuple[Union[pd.DataFrame, List[dict]], LinesRequestCounter], LinesRequestCounter, None]:
        """
        Alias function to insert data in a DataStore using datastore_upsert.

        :see: datastore_upsert()
        :param records: generator of records, e.g. chunks from a CSV file generated with pandas.read_csv(.., chunksize=1000)
        :param resource_id: destination resource id
        :param force: set to True to edit a read-only resource. If not provided, this is overridden by self.default_force
        :param limit_per_request: number of records per transaction
        :param offset: number of records to skip - use to restart the transfer
        :param total_limit: maximum number of lines to transmit, counting from the initial offset
        :param requests_limit: maximum number of requests
        :param params: additional parameters
        :param dry_run: set to True to abort transaction instead of committing, e.g. to check for validation or type errors
        :param apply_last_condition: if True, the last upsert request applies the last insert operations (calculate_record_count and force_indexing).
        :param always_last_condition: if True, each request applies the last insert operations - default is False
        :param return_df: if True, return a pandas DataFrame or else, a list of dictionaries.
        :param data_cleaner: data cleaner instance. A data cleaner detects and changes invalid values before upload.
        :param progress_callback: progress callback function
        :return: the inserted records as a pandas DataFrame, from the server response
        """
        msg = "datastore_insert is deprecated, use datastore_upsert with argument `method=UpsertChoice.Insert` instead"
        warn(msg, DeprecationWarning)
        return self.datastore_upsert(records_generator, resource_id, dry_run=dry_run, limit_per_request=limit_per_request, offset=offset,
                                     total_limit=total_limit, requests_limit=requests_limit,
                                     method=UpsertChoice.Insert, apply_last_condition=apply_last_condition, return_df=return_df,
                                     return_documents=return_documents, return_counters=return_counters,
                                     always_last_condition=always_last_condition, data_cleaner=data_cleaner,
                                     progress_callback=progress_callback,
                                     force=force, params=params, limit=limit, records=records)

    def datastore_update(self, records_generator:Union[pd.DataFrame, List[dict], Iterable[GeneralDataFrame]], resource_id:str, *,
                         dry_run:bool=False, limit_per_request:int=None, offset:int=0,
                         total_limit:int=None, requests_limit:int=None, force:bool=None,
                         apply_last_condition:bool=True, always_last_condition:bool=None, return_df:bool=None,
                         data_cleaner:CkanDataCleanerABC=None, progress_callback:CkanProgressCallbackABC=None,
                         params:dict=None, records:Union[pd.DataFrame, List[dict]]=None,
                         return_documents:bool=True, return_counters:bool=False, limit:int=None) \
            -> Union[Union[pd.DataFrame, List[dict]], Tuple[Union[pd.DataFrame, List[dict]], LinesRequestCounter], LinesRequestCounter, None]:
        """
        Alias function to update data in a DataStore using datastore_upsert.
        The update is performed based on the DataStore primary keys

        :see: datastore_upsert()
        :param records: generator of records, e.g. chunks from a CSV file generated with pandas.read_csv(.., chunksize=1000)
        :param resource_id: destination resource id
        :param force: set to True to edit a read-only resource. If not provided, this is overridden by self.default_force
        :param limit_per_request: number of records per transaction
        :param offset: number of records to skip - use to restart the transfer
        :param total_limit: maximum number of lines to transmit, counting from the initial offset
        :param requests_limit: maximum number of requests
        :param params: additional parameters
        :param dry_run: set to True to abort transaction instead of committing, e.g. to check for validation or type errors
        :param apply_last_condition: if True, the last upsert request applies the last insert operations (calculate_record_count and force_indexing).
        :param always_last_condition: if True, each request applies the last insert operations - default is False
        :param return_df: if True, return a pandas DataFrame or else, a list of dictionaries.
        :param data_cleaner: data cleaner instance. A data cleaner detects and changes invalid values before upload.
        :param progress_callback: progress callback function
        :return: the inserted records as a pandas DataFrame, from the server response
        """
        msg = "datastore_update is deprecated, use datastore_upsert with argument `method=UpsertChoice.Update` instead"
        warn(msg, DeprecationWarning)
        return self.datastore_upsert(records_generator, resource_id, dry_run=dry_run, limit_per_request=limit_per_request, offset=offset,
                                     total_limit=total_limit, requests_limit=requests_limit,
                                     method=UpsertChoice.Update, apply_last_condition=apply_last_condition, return_df=return_df,
                                     return_documents=return_documents, return_counters=return_counters,
                                     always_last_condition=always_last_condition, data_cleaner=data_cleaner,
                                     progress_callback=progress_callback,
                                     force=force, params=params, limit=limit, records=records)

    ## Not recommended manage functions ------------------
    def resource_move(self, resource_id: str, package_name: str, dest_package_name:str, params:dict=None):
        """
        Move resource from one dataset to another using resource_patch API.
        Does not work.

        :param resource_id:
        :param package_name:
        :param dest_package_name:
        :param params:
        :return:
        """
        msg = "resource_move does not work"
        warn(msg, DeprecationWarning)
        if params is None:
            params = {}
        resource_info = self.get_resource_info_or_request(resource_id, package_name=package_name)
        self.check_package_name_arg(package_name=package_name, package_id=resource_info.package_id)
        dest_package_info = self.get_package_info_or_request(dest_package_name)
        params.update({"package_id": dest_package_info.id})
        self.resource_patch(resource_id, params=params)

    ## Not recommended mapping functions ------------------
    def _api_package_list(self, *, params:dict=None, owner_org:str=None, limit_per_request:int=None, offset:int=None) -> List[str]:
        """
        __Not recommended__
        API call to package_list.
        :param params: typically, the request can be limited to an organization with the owner_org parameter
        :return:
        """
        msg = "Prefer using package_search rather than package_list because this API does not list private packages"
        warn(msg, DeprecationWarning)
        if params is None: params = {}
        if limit_per_request is None: limit_per_request = self.params.default_limit_list_per_request
        if limit_per_request is not None:
            params["limit"] = limit_per_request
        if offset is not None:
            params["offset"] = offset
        if owner_org is None and use_ckan_owner_org_for_requests:
            owner_org = self.owner_org
        if owner_org is not None:
            params["owner_org"] = owner_org
        response = self._api_action_request("package_list", method=RequestType.Get, params=params)
        if response.success:
            return response.result
        else:
            raise response.default_error(self)

    def _api_package_list_all(self, *, params:dict=None, owner_org:str=None, limit_per_request:int=None, offset:int=None) -> List[str]:
        """
        __Not recommended__
        API call to package_list until an empty list is received.
        :see: api_package_list()
        :param params:
        :return:
        """
        msg = "Prefer using package_search rather than package_list because this API does not list private packages"
        warn(msg, DeprecationWarning)
        if params is None: params = {}
        responses = self._request_all_results_list(self._api_package_list, params=params, owner_org=owner_org, limit_per_request=limit_per_request, offset=offset)
        return sum(responses, [])

    package_list_all = _api_package_list_all  # function alias


    def _api_resource_search(self, query:str=None, *, order_by:str=None, limit_per_request:int=None, offset:int=None,
                             resource_name:str=None,
                             datastore_info:bool=None, resource_view_list:bool=None,
                             params:dict=None) -> List[CkanResourceInfo]:
        """
        __Not recommended__
        API call to resource_search. It is more recommended to use the package_show API because it is not possible to
        filter the resources by package name here. Moreover, it does not return information on private resources.
        :see: map_resources()
        :param query: (string or list of strings of the form {field}:{term1}) – The search criteria. See above for description.
        :param order_by: A field on the Resource model that orders the results.
        :param limit_per_request:
        :param offset:
        :param resource_name: a shortcut to add the filter "name:{resource_name}"
        :param datastore_info: an option to query the datastore info for all the resources found.
        If not provided, the last value for this option used with map_resources will be used.
        :param resource_view_list: an option to query the resource views list for all the resources found.
        If not provided, the last value for this option used with map_resources will be used.
        :param params: additional parameters to pass to resource_search
        :return:
        """
        msg = "Prefer using package_search rather than resource_search because resource_search cannot filter per package"
        warn(msg, DeprecationWarning)
        if datastore_info is None:
            datastore_info = self.map._mapping_query_datastore_info
        if resource_view_list is None:
            resource_view_list = self.map._mapping_query_resource_view_list
        if params is None: params = {}
        if limit_per_request is None: limit_per_request = self.params.default_limit_list_per_request
        if limit_per_request is not None:
            params["limit"] = limit_per_request
        if offset is not None:
            params["offset"] = offset
        if query is None:
            query = []
        elif isinstance(query, str):
            query = [query]
        if resource_name is not None:
            query.append(f"name:{resource_name}")
        if query is not None:
            params["query"] = query
        if order_by is not None:
            params["order_by"] = order_by
        response = self._api_action_request("resource_search", method=RequestType.Get, params=params)
        if response.success:
            resource_info_list = [CkanResourceInfo(e) for e in response.result["results"]]
            for resource_info in resource_info_list:
                self._enrich_resource_info(resource_info, datastore_info=datastore_info,
                                           resource_view_list=resource_view_list)
            self.map._update_resource_info(resource_info_list)
            return copy.deepcopy(resource_info_list)
        else:
            raise response.default_error(self)

    def _api_resource_search_all(self, query: str = None, *, order_by: str = None, limit_per_request: int = None, offset: int = None,
                                 resource_name: str = None,
                                 datastore_info: bool = None, resource_view_list: bool = None,
                                 params: dict = None) -> List[CkanResourceInfo]:
        """
        __Not recommended__
        API call to resource_search until an empty list is received. It is more recommended to use the package_show API because it is not possible to
        filter the resources by package name here. Moreover, it does not return information on private resources.
        :see: map_resources()
        :see: _api_resource_search()
        :param query: (string or list of strings of the form {field}:{term1}) – The search criteria. See above for description.
        :param order_by: A field on the Resource model that orders the results.
        :param limit_per_request: maximum number of results to return.
        :param offset: the offset in the complete result for where the set of returned datasets should begin.
        :param resource_name: a shortcut to add the filter "name:{resource_name}"
        :param datastore_info: an option to query the datastore info for all the resources found.
        If not provided, the last value for this option used with map_resources will be used.
        :param resource_view_list: an option to query the resource views list for all the resources found.
        If not provided, the last value for this option used with map_resources will be used.
        :param params: additional parameters to pass to resource_search
        :return:
        """
        msg = "Prefer using package_search rather than resource_search because resource_search cannot filter per package"
        warn(msg, DeprecationWarning)
        if params is None: params = {}
        responses = self._request_all_results_list(self._api_resource_search, params=params, limit_per_request=limit_per_request, offset=offset,
                                                   query=query, order_by=order_by,
                                                   resource_name=resource_name,
                                                   datastore_info=datastore_info, resource_view_list=resource_view_list)
        return sum(responses, [])

    resource_search_all = _api_resource_search_all  # function alias


    def _api_group_package_show(self, group_name: str, *, params:dict=None, owner_org:str=None,
                                include_private:bool=True, include_drafts:bool=False, sort:str=None,
                                limit_per_request:int=None, offset:int=None) -> List[CkanPackageInfo]:
        """
        __Not recommended__
        API call to group_package_show. Return the datasets (packages) of a group.
        :param group_name: group name or id
        :param owner_org: ability to filter packages by owner_org
        :param include_private: if True, private datasets will be included in the results. Only private datasets from the user’s organizations will be returned and sysadmins will be returned all private datasets. Optional, the default is False in the API
        :param include_drafts:  if True, draft datasets will be included in the results. A user will only be returned their own draft datasets, and a sysadmin will be returned all draft datasets. Optional, the default is False.
        :param sort: sorting of the search results. Optional. Default: 'score desc, metadata_modified desc'. As per the solr documentation, this is a comma-separated string of field names and sort-orderings.
        :param limit_per_request: maximum number of results to return. Translatees to the API rows argument.
        :param offset: the offset in the complete result for where the set of returned datasets should begin. Translatees to the API start argument.
        :param params: other parameters to pass to package_search
        :return:
        """
        msg = "Prefer using package_search rather than group_package_show knowing the name of the package because this API does not list private packages"
        warn(msg, DeprecationWarning)
        if params is None: params = {}
        params["id"] = group_name
        if limit_per_request is None: limit_per_request = self.params.default_limit_list_per_request
        if limit_per_request is not None:
            params["limit"] = limit_per_request
        if offset is not None:
            params["offset"] = offset
        if owner_org is None and use_ckan_owner_org_for_requests:
            owner_org = self.owner_org
        if owner_org is not None:
            owner_org_info = self.get_organization_info_or_request(owner_org)
            owner_org = owner_org_info.id
            params["owner_org"] = owner_org
        if sort is not None:
            params["sort"] = sort
        if include_private is not None:
            params["include_private"] = include_private
        if include_drafts is not None:
            params["include_drafts"] = include_drafts
        response = self._api_action_request("group_package_show", method=RequestType.Get, params=params)
        if response.success:
            package_info_list = [CkanPackageInfo(e) for e in response.result]
            self.map._update_package_info(package_info_list)
            return package_info_list
        elif response.status_code == 404 and response.success_json_loads and response.error_message["__type"] == "Not Found Error":
            raise CkanActionNotFoundError(self, "Group", response)
        else:
            raise response.default_error(self)

    def _api_group_package_show_all(self, group_name: str, *, params:dict=None, owner_org:str=None,
                                    include_private:bool=True, include_drafts:bool=False, sort:str=None,
                                    limit_per_request:int=None, offset:int=None) -> List[CkanPackageInfo]:
        """
        __Not recommended__
        API call to group_package_show until an empty list is received.
        :see: _api_group_package_show()
        :param group_name: group name or id
        :param owner_org: ability to filter packages by owner_org
        :param include_private: if True, private datasets will be included in the results. Only private datasets from the user’s organizations will be returned and sysadmins will be returned all private datasets. Optional, the default is False in the API
        :param include_drafts:  if True, draft datasets will be included in the results. A user will only be returned their own draft datasets, and a sysadmin will be returned all draft datasets. Optional, the default is False.
        :param sort: sorting of the search results. Optional. Default: 'score desc, metadata_modified desc'. As per the solr documentation, this is a comma-separated string of field names and sort-orderings.
        :param limit_per_request: maximum number of results to return. Translatees to the API rows argument.
        :param offset: the offset in the complete result for where the set of returned datasets should begin. Translatees to the API start argument.
        :param params: other parameters to pass to API
        :return:
        """
        msg = "Prefer using package_search rather than group_package_show knowing the name of the package because this API does not list private packages"
        warn(msg, DeprecationWarning)
        if params is None: params = {}
        responses = self._request_all_results_list(self._api_group_package_show, params=params, limit_per_request=limit_per_request, offset=offset,
                                                   group_name=group_name, owner_org=owner_org,
                                                   include_private=include_private, include_drafts=include_drafts)
        return sum(responses, [])

    group_package_show_all = _api_group_package_show_all  # function alias

    ## resource view
    def _api_resource_create_default_resource_views(self, resource_id:str, *, create_datastore_views:bool=None,
                                                    params:dict=None) -> List[CkanViewInfo]:
        """
        API call to resource_create_default_resource_views
        :param resource_id: resource id
        :param create_datastore_views: whether to create views that rely on data being on the DataStore (optional, API defaults to False)
        :param params:
        :return:
        """
        msg = "Prefer using resource_view_create rather than resource_create_default_resource_views"
        warn(msg, DeprecationWarning)
        assert_or_raise(not self.params.read_only, ReadOnlyError())
        if params is None: params = {}
        resource_info = self.resource_show(resource_id)
        resource_dict = resource_info.details
        if create_datastore_views is None:
            create_datastore_views = self.resource_is_datastore(resource_id)
        params["resource"] = resource_dict
        params["create_datastore_views"] = create_datastore_views
        response = self._api_action_request(f"resource_create_default_resource_views", method=RequestType.Post, json=params)
        if response.success:
            view_info_list = [CkanViewInfo(view_dict) for view_dict in response.result]
            self.map._update_view_info(view_info_list)
            return copy.deepcopy(view_info_list)
        else:
            raise response.default_error(self)

    resource_create_default_resource_views = _api_resource_create_default_resource_views  # function alias


