from collections.abc import AsyncIterable, Iterable, Mapping
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import httpx

from soar_sdk.abstract import JSONType, SOARClient, SOARClientAuth, SummaryType
from soar_sdk.apis.artifact import Artifact
from soar_sdk.apis.container import Container
from soar_sdk.apis.vault import Vault
from soar_sdk.shims.phantom.install_info import is_onprem_broker_install

if TYPE_CHECKING:
    pass


@dataclass
class BasicAuth:
    """Basic authentication credentials for the SOAR API."""

    username: str
    password: str


class AppClient(SOARClient[SummaryType]):
    """An adapter between apps built with the SDK, and the APIs exposed by the BaseConnector class.

    Enables apps to access SOAR platform features, without having to import the closed-source "phantom" library directly. In the future, it should be replaced by another class that uses the API to interact with SOAR, instead of BaseConnector.
    """

    def __init__(self) -> None:
        # Call the BaseConnectors init first
        super().__init__()

        self._client = httpx.Client(
            base_url=self.get_soar_base_url(),
            verify=False,  # noqa: S501
        )
        self.csrf_token: str = ""

        self._artifacts_api = Artifact(soar_client=self)
        self._containers_api = Container(soar_client=self)
        self._vault_api = Vault(soar_client=self)
        self.basic_auth: BasicAuth | None = None

        self._summary: SummaryType | None = None
        self._message: str = ""
        self.__container_id: int = 0
        self.__asset_id: str = ""

        self._user_hash_key: str = ""
        self._broker_ph_auth_token: str = ""

    @property
    def client(self) -> httpx.Client:
        """The HTTP client used for making requests to the SOAR API."""
        return self._client

    @property
    def artifact(self) -> Artifact:
        """The SOAR Artifacts API."""
        return self._artifacts_api

    @property
    def container(self) -> Container:
        """The SOAR Containers API."""
        return self._containers_api

    @property
    def vault(self) -> Vault:
        """The SOAR Vault API."""
        return self._vault_api

    def get_executing_container_id(self) -> int:
        """Return the current Container ID passed in the Connector Run Action JSON."""
        return self.__container_id

    def get_asset_id(self) -> str:
        """Return the current Asset ID passed in the Connector Run Action JSON."""
        return self.__asset_id

    def update_client(
        self, soar_auth: SOARClientAuth, asset_id: str = "", container_id: int = 0
    ) -> None:
        """Update the SOAR client with the given authentication and asset ID."""
        self.authenticate_soar_client(soar_auth)
        self._containers_api.set_executing_asset(asset_id)
        self.__container_id = container_id
        self.__asset_id = asset_id

    def authenticate_soar_client(self, soar_auth: SOARClientAuth) -> None:
        """Authenticate the SOAR client with the given authentication credentials."""
        self._user_hash_key = soar_auth.user_hash_key
        self._broker_ph_auth_token = soar_auth.broker_ph_auth_token

        session_id = soar_auth.user_session_token
        self._client = httpx.Client(
            base_url=soar_auth.base_url,
            verify=False,  # noqa: S501
        )

        if is_onprem_broker_install() and self._broker_ph_auth_token:
            return

        if session_id:
            self._client.cookies.set("sessionid", session_id)
            self.__login()
        else:
            if soar_auth.username:
                self.__login()
                self.__basic_auth = BasicAuth(soar_auth.username, soar_auth.password)
                session_id = self.get_session_id()

        if session_id:
            current_cookies = self._client.headers.get("Cookie", "")
            update_cookies = f"sessionid={session_id};{current_cookies}"
            self._client.headers.update({"Cookie": update_cookies})

    def __login(self) -> None:
        response = self._client.get("/login", follow_redirects=True)
        response.raise_for_status()
        self.csrf_token = response.cookies.get("csrftoken") or ""
        self._client.cookies.update(response.cookies)
        self._client.headers.update({"X-CSRFToken": self.csrf_token})
        cookies = f"csrftoken={self.csrf_token}"
        self._client.headers.update({"Cookie": cookies})

    def get_session_id(self) -> str:
        """Get the session ID for the authenticated user."""
        self._client.post(
            "/login",
            data={
                "username": self.__basic_auth.username,
                "password": self.__basic_auth.password,
                "csrfmiddlewaretoken": self.csrf_token,
            },
            headers={"Referer": f"{self._client.base_url}/login"},
        )
        session_id = self._client.cookies.get("sessionid")
        return session_id or ""

    def _prepare_broker_request(
        self, endpoint: str, headers: dict[str, str] | None
    ) -> tuple[str, dict[str, str]]:
        """Prepare endpoint and headers for broker api_proxy routing.

        On automation broker, routes requests through /rest/broker/api_proxy/*
        and adds the required authentication headers.
        """
        headers = headers or {}

        if not is_onprem_broker_install() or not self._broker_ph_auth_token:
            return endpoint, headers

        # Ensure endpoint starts with /
        if not endpoint.startswith("/"):
            endpoint = f"/{endpoint}"

        # Route through broker api_proxy
        endpoint = f"/rest/broker/api_proxy{endpoint}"

        # Add broker authentication headers
        headers["ph-auth-token"] = self._broker_ph_auth_token
        headers["PsaasImpersonationToken"] = self._user_hash_key

        return endpoint, headers

    def get(
        self,
        endpoint: str,
        *,
        params: dict[str, Any] | httpx.QueryParams | None = None,
        headers: dict[str, str] | None = None,
        cookies: dict[str, str] | None = None,
        timeout: httpx.Timeout | None = None,
        auth: httpx.Auth | tuple[str, str] | None = None,
        follow_redirects: bool = False,
        extensions: Mapping[str, Any] | None = None,
    ) -> httpx.Response:
        """Perform a GET request to the specific endpoint using the SOAR client."""
        endpoint, headers = self._prepare_broker_request(endpoint, headers)
        response = self._client.get(
            endpoint,
            params=params,
            headers=headers,
            cookies=cookies,
            timeout=timeout,
            auth=auth or httpx.USE_CLIENT_DEFAULT,
            follow_redirects=follow_redirects,
            extensions=extensions,
        )
        response.raise_for_status()
        return response

    def post(
        self,
        endpoint: str,
        *,
        content: str | bytes | Iterable[bytes] | AsyncIterable[bytes] | None = None,
        data: Mapping[str, Any] | None = None,
        files: dict[str, Any] | None = None,
        json: JSONType | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        cookies: dict[str, str] | None = None,
        auth: httpx.Auth | tuple[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
        follow_redirects: bool = True,
        extensions: Mapping[str, Any] | None = None,
    ) -> httpx.Response:
        """Perform a POST request to the specific endpoint using the SOAR client."""
        endpoint, headers = self._prepare_broker_request(endpoint, headers)
        headers.update({"Referer": f"{self._client.base_url}/{endpoint}"})
        response = self._client.post(
            endpoint,
            headers=headers,
            content=content,
            data=data,
            files=files,
            json=json,
            params=params,
            cookies=cookies,
            auth=auth or httpx.USE_CLIENT_DEFAULT,
            timeout=timeout,
            follow_redirects=follow_redirects,
            extensions=extensions,
        )
        response.raise_for_status()
        return response

    def put(
        self,
        endpoint: str,
        *,
        content: str | bytes | Iterable[bytes] | AsyncIterable[bytes] | None = None,
        data: Mapping[str, Any] | None = None,
        files: dict[str, Any] | None = None,
        json: JSONType | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        cookies: dict[str, str] | None = None,
        auth: httpx.Auth | tuple[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
        follow_redirects: bool = True,
        extensions: Mapping[str, Any] | None = None,
    ) -> httpx.Response:
        """Perform a PUT request to the specific endpoint using the SOAR client."""
        endpoint, headers = self._prepare_broker_request(endpoint, headers)
        headers.update({"Referer": f"{self._client.base_url}/{endpoint}"})
        response = self._client.put(
            endpoint,
            headers=headers,
            content=content,
            data=data,
            files=files,
            json=json,
            params=params,
            cookies=cookies,
            auth=auth or httpx.USE_CLIENT_DEFAULT,
            timeout=timeout,
            follow_redirects=follow_redirects,
            extensions=extensions,
        )
        response.raise_for_status()
        return response

    def delete(
        self,
        endpoint: str,
        *,
        params: dict[str, Any] | httpx.QueryParams | None = None,
        headers: dict[str, str] | None = None,
        cookies: dict[str, str] | None = None,
        auth: httpx.Auth | tuple[str, str] | None = None,
        timeout: httpx.Timeout | None = None,
        follow_redirects: bool = False,
        extensions: Mapping[str, Any] | None = None,
    ) -> httpx.Response:
        """Perform a DELETE request to the specific endpoint using the SOAR client."""
        endpoint, headers = self._prepare_broker_request(endpoint, headers)
        headers.update({"Referer": f"{self._client.base_url}/{endpoint}"})
        response = self._client.delete(
            endpoint,
            params=params,
            headers=headers,
            cookies=cookies,
            auth=auth
            or httpx.BasicAuth(self.__basic_auth.username, self.__basic_auth.password)
            if self.basic_auth
            else None,  # type: ignore[arg-type]
            timeout=timeout,
            follow_redirects=follow_redirects,
            extensions=extensions,
        )
        response.raise_for_status()
        return response

    def set_summary(self, summary: SummaryType) -> None:
        """Set the summary for the action result."""
        self._summary = summary

    def set_message(self, message: str) -> None:
        """Set the message for the action result."""
        self._message = message

    def get_summary(self) -> SummaryType | None:
        """Get the summary for the action result."""
        return self._summary

    def get_message(self) -> str:
        """Get the message for the action result."""
        return self._message
