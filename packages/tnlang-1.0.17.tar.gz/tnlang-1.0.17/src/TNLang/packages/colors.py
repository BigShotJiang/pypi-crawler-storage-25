class Echo:
    RED = '\033[91m'
    GREEN = '\033[92m'
    BLUE = '\033[94m'
    YELLOW = '\033[93m'
    CYAN = '\033[96m'
    MAGENTA = '\033[95m'
    WHITE = '\033[97m'
    RESET = '\033[0m'

    def _color(self, color_code: str, text: str) -> str:
        return f"{color_code}{text}{self.RESET}"

    def red(self, text: str) -> None:
        print(self._color(self.RED, text))

    def green(self, text: str) -> None:
        print(self._color(self.GREEN, text))

    def blue(self, text: str) -> None:
        print(self._color(self.BLUE, text))

    def yellow(self, text: str) -> None:
        print(self._color(self.YELLOW, text))

    def cyan(self, text: str) -> None:
        print(self._color(self.CYAN, text))

    def magenta(self, text: str) -> None:
        print(self._color(self.MAGENTA, text))

    def white(self, text: str) -> None:
        print(self._color(self.WHITE, text))