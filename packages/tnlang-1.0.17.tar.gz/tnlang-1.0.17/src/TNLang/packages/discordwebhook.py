import requests


class DiscordWebHook:
    def webhook(self, url: str, message: str) -> None:
        message = message.replace("\\n", "\n")
        data = {"content": message}
        requests.post(url, json=data)