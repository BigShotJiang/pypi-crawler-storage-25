import os
import sys
import re
import time

_launched = False
_packages = {}


def validate_line(line: str, line_num: int) -> None:
    line = line.strip()
    if not line or line.startswith('#'):
        return
    
    if line.startswith('importPackage '):
        return
    
    if re.match(r'^echo\("(.+)"\)$', line):
        return
    
    echo_method_match = re.match(r'^echo\.(\w+)\("(.+)"\)$', line)
    if echo_method_match:
        method_name = echo_method_match.group(1)
        if not _packages:
            raise SyntaxError(f"Error: echo.{method_name}() not found. Did you forget to import the package?")
        for pkg_name, pkg in _packages.items():
            if 'echo' not in pkg:
                continue
            echo_pkg = pkg['echo']
            if hasattr(echo_pkg, method_name):
                return
        raise SyntaxError(f"Error: echo.{method_name}() not found. Did you forget to import the package?")
    
    if re.match(r'^wait\((\d+)\)$', line):
        return
    
    discord_match = re.match(r'^discord\.webhook\("(.+)", "(.+)"\)$', line)
    if discord_match:
        return
    
    loop_match = re.match(r'^loop\.(\d+)\((.+)\)$', line)
    if loop_match:
        cmd = loop_match.group(2)
        if re.match(r'^echo\("(.+)"\)$', cmd):
            return
        echo_method_match = re.match(r'^echo\.(\w+)\("(.+)"\)$', cmd)
        if echo_method_match:
            method_name = echo_method_match.group(1)
            if not _packages:
                raise SyntaxError(f"Error: echo.{method_name}() not found. Did you forget to import the package?")
        for pkg_name, pkg in _packages.items():
            if 'echo' not in pkg:
                continue
            echo_pkg = pkg['echo']
            if hasattr(echo_pkg, method_name):
                return
        raise SyntaxError(f"Unknown command inside loop on line {line_num}: {cmd}")
    
    discord_match = re.match(r'^discord\.webhook\("(.+)", "(.+)"\)$', line)
    if discord_match:
        return
    
    raise SyntaxError(f"Unknown command on line {line_num}: {line}")


def execute_line(line: str, line_num: int) -> None:
    line = line.strip()
    if not line or line.startswith('#'):
        return
    
    if line.startswith('importPackage '):
        return
    
    match = re.match(r'^echo\("(.+)"\)$', line)
    if match:
        print(match.group(1))
        return
    
    echo_method_match = re.match(r'^echo\.(\w+)\("(.+)"\)$', line)
    if echo_method_match:
        method_name = echo_method_match.group(1)
        text = echo_method_match.group(2)
        for pkg_name, pkg in _packages.items():
            if 'echo' not in pkg:
                continue
            echo_pkg = pkg['echo']
            if hasattr(echo_pkg, method_name):
                getattr(echo_pkg, method_name)(text)
                return
        return
    
    match = re.match(r'^wait\((\d+)\)$', line)
    if match:
        time.sleep(int(match.group(1)))
        return
    
    discord_match = re.match(r'^discord\.webhook\("(.+)", "(.+)"\)$', line)
    if discord_match:
        url = discord_match.group(1)
        message = discord_match.group(2)
        for pkg_name, pkg in _packages.items():
            if 'discord' in pkg:
                pkg['discord'].webhook(url, message)
                return
        return
    
    match = re.match(r'^loop\.(\d+)\((.+)\)$', line)
    if match:
        count = int(match.group(1))
        cmd = match.group(2)
        for _ in range(count):
            echo_match = re.match(r'^echo\("(.+)"\)$', cmd)
            if echo_match:
                print(echo_match.group(1))
                continue
            echo_method_match = re.match(r'^echo\.(\w+)\("(.+)"\)$', cmd)
            if echo_method_match:
                method_name = echo_method_match.group(1)
                text = echo_method_match.group(2)
            for pkg_name, pkg in _packages.items():
                if 'echo' not in pkg:
                    continue
                echo_pkg = pkg['echo']
                if hasattr(echo_pkg, method_name):
                    getattr(echo_pkg, method_name)(text)
                    break


def print_error(message: str, file_path: str, line_num: int) -> None:
    red = '\033[91m'
    reset = '\033[0m'
    print(f"{red}Error: {message}{reset}")
    print(f"File: {file_path}")
    print(f"Line: {line_num}")


def launch(file_path: str) -> None:
    global _launched, _packages
    if _launched:
        raise RuntimeError("TNLang.launch() can only be called once per process")
    if not isinstance(file_path, str):
        raise TypeError("file_path must be a string")
    if len(sys.argv) > 1:
        raise ValueError("TNLang.launch() expects exactly one file argument")
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        code = f.read()
    
    lines = code.splitlines()
    
    _packages = {}
    available_packages = {'colors', 'discordwebhook'}
    
    for line in lines:
        line = line.strip()
        if line.startswith('importPackage '):
            pkg_name = line.split()[1].strip().lower()
            if pkg_name not in available_packages:
                os.system('cls' if os.name == 'nt' else 'clear')
                print_error(f"Package '{pkg_name}' not found", file_path, 1)
                return
            if pkg_name == 'colors':
                from .packages import colors
                _packages['colors'] = {'echo': colors.Echo()}
            elif pkg_name == 'discordwebhook':
                from .packages import discordwebhook
                _packages['discordwebhook'] = {'discord': discordwebhook.DiscordWebHook()}
    
    for line_num, line in enumerate(lines, 1):
        try:
            validate_line(line, line_num)
        except SyntaxError as e:
            os.system('cls' if os.name == 'nt' else 'clear')
            print_error(str(e), file_path, line_num)
            return
    
    os.system('cls' if os.name == 'nt' else 'clear')
    
    for line in lines:
        execute_line(line, 1)
    
    _launched = True