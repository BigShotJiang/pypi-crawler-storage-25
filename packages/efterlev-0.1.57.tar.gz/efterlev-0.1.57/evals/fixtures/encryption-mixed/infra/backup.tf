# AWS Backup orchestration parallel to govnotes-v1 rev 4.
# Lifts KSI-RPL-ARP off ELI by exercising `rpl_backup_configured`.
# Backs up the audit-logs-archive bucket (the lowest-loss-tolerance
# resource on this fixture) plus the customer-uploads bucket.
#
# Note: encryption-mixed has no RDS to back up; the selection covers
# S3 ARNs, which AWS Backup supports.

resource "aws_backup_vault" "primary_vault" {
  name        = "encryption-mixed-primary-vault"
  kms_key_arn = aws_kms_key.audit.arn
}

resource "aws_backup_plan" "daily_with_dr" {
  name = "encryption-mixed-daily-with-dr"

  rule {
    rule_name         = "daily-prod"
    target_vault_name = aws_backup_vault.primary_vault.name
    schedule          = "cron(0 5 * * ? *)"

    lifecycle {
      delete_after = 35
    }

    copy_action {
      destination_vault_arn = "arn:aws:backup:us-west-2:123456789012:backup-vault:encryption-mixed-dr-vault"
      lifecycle {
        delete_after = 35
      }
    }
  }
}

resource "aws_backup_selection" "primary_resources" {
  iam_role_arn = "arn:aws:iam::123456789012:role/encryption-mixed-backup-role"
  name         = "primary-resources"
  plan_id      = aws_backup_plan.daily_with_dr.id

  resources = [
    aws_s3_bucket.audit_logs_archive.arn,
    aws_s3_bucket.customer_uploads.arn,
  ]
}
