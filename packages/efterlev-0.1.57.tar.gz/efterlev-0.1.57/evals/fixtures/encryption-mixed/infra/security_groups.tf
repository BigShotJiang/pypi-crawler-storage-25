# Mixed security-group posture parallel to govnotes-v1 rev 4.
# Lifts KSI-CNA-MAT/CNA-RNT off the ELI alternation by giving the
# `security_group_open_ingress` detector evidence to attach.
#
#   - app_lb         — HTTPS-only from a corporate VPN CIDR (compliant)
#   - bastion_open   — SSH open to 0.0.0.0/0 (the gap)

resource "aws_security_group" "app_lb" {
  name        = "app-lb"
  description = "Application LB — HTTPS-only from corporate VPN CIDR"
  vpc_id      = "vpc-0abc456"

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]
  }
}

resource "aws_security_group" "bastion_open" {
  name        = "bastion-open"
  description = "Legacy bastion — SSH open to the internet (the gap)"
  vpc_id      = "vpc-0abc456"

  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
