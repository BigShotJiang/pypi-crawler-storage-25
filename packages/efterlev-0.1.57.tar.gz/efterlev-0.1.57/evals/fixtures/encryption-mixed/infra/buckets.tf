# 6 S3 buckets with deliberately mixed encryption posture.
# Designed to exercise the bucket-by-bucket variance metric the
# v0.1.8 shakedowns flagged: per F1, the agent classified
# KSI-SVC-VRI / KSI-CNA-MAT as `partial` (correct verdict) but never
# named individual buckets in the rationale, leaving reviewers
# unable to tell which buckets were non-compliant.
#
# Buckets:
#   1. app_uploads        — KMS CMK + AES256, fully compliant
#   2. quarterly_reports  — AES256 only, partially compliant
#   3. legacy_export      — no encryption block at all (gap)
#   4. temp_data_pipeline — explicitly empty SSE config (worst gap)
#   5. audit_logs_archive — KMS CMK, fully compliant
#   6. customer_uploads   — AES256, partially compliant
#
# Public-access-block coverage (separately):
#   - app_uploads, audit_logs_archive, customer_uploads: all four flags true
#   - quarterly_reports, legacy_export, temp_data_pipeline: NO PAB at all

resource "aws_kms_key" "uploads" {
  description         = "Customer-uploads encryption key"
  enable_key_rotation = true
}

resource "aws_kms_key" "audit" {
  description         = "Audit-logs-archive encryption key"
  enable_key_rotation = true
}

# 1. Fully compliant: KMS CMK + PAB
resource "aws_s3_bucket" "app_uploads" {
  bucket = "app-uploads"
}

resource "aws_s3_bucket_server_side_encryption_configuration" "app_uploads" {
  bucket = aws_s3_bucket.app_uploads.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.uploads.arn
    }
  }
}

resource "aws_s3_bucket_public_access_block" "app_uploads" {
  bucket                  = aws_s3_bucket.app_uploads.id
  block_public_acls       = true
  ignore_public_acls      = true
  block_public_policy     = true
  restrict_public_buckets = true
}

# 2. Partially compliant: AES256 only, no PAB
resource "aws_s3_bucket" "quarterly_reports" {
  bucket = "quarterly-reports"
}

resource "aws_s3_bucket_server_side_encryption_configuration" "quarterly_reports" {
  bucket = aws_s3_bucket.quarterly_reports.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# 3. Gap: no encryption at all + no PAB
resource "aws_s3_bucket" "legacy_export" {
  bucket = "legacy-export"
}

# 4. Worst gap: explicitly empty SSE config (no rule block)
resource "aws_s3_bucket" "temp_data_pipeline" {
  bucket = "temp-data-pipeline"
}

# 5. Fully compliant: KMS CMK + PAB
resource "aws_s3_bucket" "audit_logs_archive" {
  bucket = "audit-logs-archive"
}

resource "aws_s3_bucket_server_side_encryption_configuration" "audit_logs_archive" {
  bucket = aws_s3_bucket.audit_logs_archive.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.audit.arn
    }
  }
}

resource "aws_s3_bucket_public_access_block" "audit_logs_archive" {
  bucket                  = aws_s3_bucket.audit_logs_archive.id
  block_public_acls       = true
  ignore_public_acls      = true
  block_public_policy     = true
  restrict_public_buckets = true
}

# 6. Partially compliant: AES256 + PAB
resource "aws_s3_bucket" "customer_uploads" {
  bucket = "customer-uploads"
}

resource "aws_s3_bucket_server_side_encryption_configuration" "customer_uploads" {
  bucket = aws_s3_bucket.customer_uploads.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "customer_uploads" {
  bucket                  = aws_s3_bucket.customer_uploads.id
  block_public_acls       = true
  ignore_public_acls      = true
  block_public_policy     = true
  restrict_public_buckets = true
}
