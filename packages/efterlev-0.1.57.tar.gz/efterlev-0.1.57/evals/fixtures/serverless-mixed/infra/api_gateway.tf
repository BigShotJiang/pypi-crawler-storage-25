# Mixed API Gateway posture, expanded across revisions to exercise
# the Tier 2 #1, #2, and #3 APIGW-side detectors.
#
#   Tier 2 #1: aws.api_gateway_tls_min_version (custom-domain TLS floor)
#   Tier 2 #2: aws.api_gateway_access_logging (per-stage access_log_settings)
#   Tier 2 #3: aws.api_gateway_auth_required (per-route auth mode),
#              aws.api_gateway_waf_attached (per-stage WAF assoc)
#
# Custom domains (TLS-floor posture):
#   - public_api_v1     -- REST v1 custom domain on TLS_1_2 (positive)
#   - legacy_api_v1     -- REST v1 custom domain with security_policy
#                          omitted; AWS provider defaults to TLS_1_0
#                          (negative -- the legacy gap).
#   - public_api_v2     -- HTTP v2 custom domain (positive: v2 only
#                          supports TLS_1_2).
#
# Stages (access-logging + WAF posture):
#   - public_api_v1_prod_stage      -- WITH access_log_settings AND
#                                      WAF association (positive on
#                                      both stage-level detectors).
#   - public_api_v1_staging_stage   -- WITHOUT access_log_settings AND
#                                      WITHOUT WAF (negative on both).
#   - public_api_v2_default_stage   -- WITH access_log_settings; no
#                                      WAF (mixed: positive on logging,
#                                      negative on WAF).
#
# Routes (rev 3 -- auth_required posture):
#   - get_users    -- REST v1 method, authorization = "AWS_IAM" (positive)
#   - get_health   -- REST v1 method, authorization = "NONE" (negative)
#   - post_orders  -- HTTP v2 route, authorization_type = "JWT" (positive)

resource "aws_api_gateway_domain_name" "public_api_v1" {
  domain_name              = "api.serverless-mixed.example.com"
  regional_certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/api-cert"
  security_policy          = "TLS_1_2"

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}

resource "aws_api_gateway_domain_name" "legacy_api_v1" {
  domain_name              = "legacy.serverless-mixed.example.com"
  regional_certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/legacy-cert"
  # security_policy omitted; AWS provider defaults to TLS_1_0 -- the gap.

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}

resource "aws_apigatewayv2_domain_name" "public_api_v2" {
  domain_name = "v2.serverless-mixed.example.com"

  domain_name_configuration {
    certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/v2-cert"
    endpoint_type   = "REGIONAL"
    security_policy = "TLS_1_2"
  }
}

# --- Stages (access-logging from rev 2) ---

resource "aws_cloudwatch_log_group" "api_access_logs" {
  name              = "/aws/apigateway/serverless-mixed"
  retention_in_days = 365
}

resource "aws_api_gateway_stage" "public_api_v1_prod_stage" {
  rest_api_id   = "rest-api-public-id-placeholder"
  deployment_id = "deployment-prod-id-placeholder"
  stage_name    = "prod"

  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_access_logs.arn
    format          = "$context.requestId $context.identity.sourceIp $context.httpMethod $context.resourcePath $context.status $context.responseLength"
  }
}

resource "aws_api_gateway_stage" "public_api_v1_staging_stage" {
  rest_api_id   = "rest-api-public-id-placeholder"
  deployment_id = "deployment-staging-id-placeholder"
  stage_name    = "staging"
  # No access_log_settings block -- the request-path audit trail gap.
  # Also no WAF association in rev 3.
}

resource "aws_apigatewayv2_stage" "public_api_v2_default_stage" {
  api_id      = "v2-api-id-placeholder"
  name        = "$default"
  auto_deploy = true

  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_access_logs.arn
    format          = "$context.requestId $context.identity.sourceIp $context.httpMethod $context.routeKey $context.status"
  }
}

# --- Routes (rev 3 -- auth_required posture) ---

resource "aws_api_gateway_method" "get_users" {
  rest_api_id   = "rest-api-public-id-placeholder"
  resource_id   = "users-resource-id-placeholder"
  http_method   = "GET"
  authorization = "AWS_IAM"
}

resource "aws_api_gateway_method" "get_health" {
  rest_api_id   = "rest-api-public-id-placeholder"
  resource_id   = "health-resource-id-placeholder"
  http_method   = "GET"
  authorization = "NONE"
  # Public health endpoint -- the auth gap. May be intentional;
  # the Gap Agent reasons from broader prompt context.
}

resource "aws_apigatewayv2_route" "post_orders" {
  api_id             = "v2-api-id-placeholder"
  route_key          = "POST /orders"
  authorization_type = "JWT"
  authorizer_id      = "jwt-authorizer-id-placeholder"
}

# --- WAF (rev 5 -- L7 protection posture, exercises Tier 3 #1 + #3 batches) ---
#
# api_protection is the FULL posture Web ACL. As of rev 5 it exercises
# positive emission for ALL FIVE Tier 3 #1 + #3 detectors:
#   - waf_rule_count             -> rules_present (4 rule blocks)
#   - waf_managed_rule_groups    -> managed_groups_present (CommonRuleSet)
#   - waf_rate_limiting          -> rate_limiting_present (limit=2000, IP)
#   - waf_action_types           -> mixed (3 enforcing rules + 1 count rule;
#                                   rev-5 added the count-action rule to
#                                   exercise the new mixed-state path)
#   - waf_ip_set_blocking        -> ip_set_blocking_present (rev-5 added
#                                   the ip_set_reference_statement rule)
# The Gap Agent should reason about all five present-states for this
# resource on KSI-CNA-RVP.
#
# legacy_unprotected_waf is the BARE-WAF posture: no rules at all.
# Exercises negative emission for waf_rule_count, waf_managed_rule_groups,
# waf_rate_limiting, and waf_ip_set_blocking. (waf_action_types emits
# vacuously enforcing on the empty rule set per its DECISIONS Decision
# #3 -- the rules-absent gap is already flagged by waf_rule_count.)
# The Gap Agent should name this resource as the gap-driver across
# four of the five WAF dimensions.
#
# bad_actors_blocklist is the rev-5 IP-set the api_protection Web ACL
# references via ip_set_reference_statement. Exists at top level so
# the cross-resource ARN reference resolves.
#
# protect_prod associates api_protection with the prod stage (positive
# on waf_attached). public_api_v1_staging_stage and
# public_api_v2_default_stage stay deliberately unassociated (negative
# on waf_attached, mixed posture across the WAF detector family).

resource "aws_wafv2_web_acl" "api_protection" {
  name  = "serverless-mixed-api-waf"
  scope = "REGIONAL"

  default_action {
    allow {}
  }

  rule {
    name     = "managed-common-rules"
    priority = 1
    override_action {
      none {}
    }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesCommonRuleSet"
        vendor_name = "AWS"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "managed-common-rules"
      sampled_requests_enabled   = true
    }
  }

  rule {
    name     = "rate-limit-ip"
    priority = 2
    action {
      block {}
    }
    statement {
      rate_based_statement {
        limit              = 2000
        aggregate_key_type = "IP"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "rate-limit-ip"
      sampled_requests_enabled   = true
    }
  }

  # Rev 5: count-action managed-group rule. Exercises waf_action_types
  # `mixed` state (combined with the two enforcing rules above and the
  # ip_set rule below). Realistic shape -- managed-group dry-run during
  # rollout, but stuck in count mode and forgotten.
  rule {
    name     = "managed-known-bad-inputs-in-count"
    priority = 3
    override_action {
      count {}
    }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesKnownBadInputsRuleSet"
        vendor_name = "AWS"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "managed-known-bad-inputs-in-count"
      sampled_requests_enabled   = true
    }
  }

  # Rev 5: IP-set blocklist reference. Exercises waf_ip_set_blocking
  # `ip_set_blocking_present`. Pointed at the bad_actors_blocklist
  # IP set declared at top level below.
  rule {
    name     = "block-bad-actor-ips"
    priority = 4
    action {
      block {}
    }
    statement {
      ip_set_reference_statement {
        arn = aws_wafv2_ip_set.bad_actors_blocklist.arn
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "block-bad-actor-ips"
      sampled_requests_enabled   = true
    }
  }

  # Rev 6: geo_match_statement blocking embargoed countries.
  # Exercises waf_geo_blocking `geo_blocking_present`. Canonical
  # embargoed-country posture for a US-federal workload (KP, IR,
  # CU, SY -- the standard sanctioned set; some boundaries also
  # include sanctioned subsets of RU).
  rule {
    name     = "block-embargoed-countries"
    priority = 5
    action {
      block {}
    }
    statement {
      geo_match_statement {
        country_codes = ["KP", "IR", "CU", "SY"]
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "block-embargoed-countries"
      sampled_requests_enabled   = true
    }
  }

  # Rev 7: customer-defined rule_group reference. Exercises
  # waf_custom_rule_groups `custom_rule_groups_present`.
  # Pulls in the api_specific_rules group declared at top level
  # below -- workload-specific signatures the AWS-managed rule
  # groups don't cover.
  rule {
    name     = "apply-api-specific-rules"
    priority = 6
    override_action {
      none {}
    }
    statement {
      rule_group_reference_statement {
        arn = aws_wafv2_rule_group.api_specific_rules.arn
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "apply-api-specific-rules"
      sampled_requests_enabled   = true
    }
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "serverless-mixed-api-waf"
    sampled_requests_enabled   = true
  }
}

# Rev 7: customer-curated rule group referenced by api_protection's
# apply-api-specific-rules rule. Realistic shape -- workload-specific
# signatures (deprecated API path, known-bad user-agent) that don't
# fit the AWS-managed rule groups' broader OWASP coverage.
resource "aws_wafv2_rule_group" "api_specific_rules" {
  name     = "serverless-mixed-api-specific-rules"
  scope    = "REGIONAL"
  capacity = 10

  rule {
    name     = "block-deprecated-api-version"
    priority = 1
    action {
      block {}
    }
    statement {
      byte_match_statement {
        positional_constraint = "STARTS_WITH"
        search_string         = "/api/v1/"
        field_to_match {
          uri_path {}
        }
        text_transformation {
          priority = 0
          type     = "NONE"
        }
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "block-deprecated-api"
      sampled_requests_enabled   = true
    }
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "api-specific-rules"
    sampled_requests_enabled   = true
  }
}

# Rev 5: IP set referenced by api_protection's block-bad-actor-ips
# rule. Synthetic threat-intel feed addresses; realistic shape would
# be a pipeline that periodically updates the addresses list from a
# customer-managed source.
resource "aws_wafv2_ip_set" "bad_actors_blocklist" {
  name               = "serverless-mixed-bad-actors-blocklist"
  scope              = "REGIONAL"
  ip_address_version = "IPV4"
  addresses = [
    "192.0.2.0/24",
    "198.51.100.0/24",
  ]
}

# Bare Web ACL: not associated to any stage, exists only to exercise
# the negative-evidence path of waf_rule_count, waf_managed_rule_groups,
# waf_rate_limiting, and waf_ip_set_blocking in the same fixture.
# Realistic shape -- a Web ACL provisioned during a half-finished
# migration that never got its rules ported.
resource "aws_wafv2_web_acl" "legacy_unprotected_waf" {
  name  = "serverless-mixed-legacy-bare-waf"
  scope = "REGIONAL"

  default_action {
    allow {}
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "serverless-mixed-legacy-bare-waf"
    sampled_requests_enabled   = true
  }
}

resource "aws_wafv2_web_acl_association" "protect_prod" {
  resource_arn = aws_api_gateway_stage.public_api_v1_prod_stage.arn
  web_acl_arn  = aws_wafv2_web_acl.api_protection.arn
}

# Deliberately NO association for public_api_v1_staging_stage (negative
# on waf_attached) and NO association for public_api_v2_default_stage
# (mixed: positive on access_logging, negative on waf_attached).
