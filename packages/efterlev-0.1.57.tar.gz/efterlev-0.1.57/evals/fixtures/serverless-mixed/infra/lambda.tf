# Mixed Lambda posture, expanded across revisions to exercise the
# Tier 2 #1, #2, and #3 Lambda-side detectors.
#
#   Tier 2 #1: aws.lambda_logging_configured (per-function log group)
#   Tier 2 #2: aws.lambda_env_kms_encryption (env-var CMK)
#   Tier 2 #3: aws.lambda_vpc_isolation (vpc_config block)
#
#   - api_handler         -- function WITH a matching aws_cloudwatch_log_group
#                            AND env-vars + explicit kms_key_arn AND vpc_config
#                            (positive on ALL THREE Lambda-side detectors).
#   - background_worker   -- function WITHOUT a matching log group AND
#                            env-vars but NO kms_key_arn AND no vpc_config
#                            (negative on ALL THREE -- the canonical gap shape).

resource "aws_iam_role" "lambda_exec" {
  name = "serverless-mixed-lambda-exec"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_kms_key" "lambda_env_secrets" {
  description         = "CMK for Lambda env-var secret encryption"
  enable_key_rotation = true
}

resource "aws_lambda_function" "api_handler" {
  function_name = "api-handler"
  role          = aws_iam_role.lambda_exec.arn
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "api_handler.zip"
  kms_key_arn   = aws_kms_key.lambda_env_secrets.arn

  environment {
    variables = {
      DATABASE_URL = "postgres://..."
      API_TOKEN    = "..."
    }
  }

  # rev 3: VPC isolation. Literal subnet + SG IDs (the fixture has
  # no aws_vpc resource by design; the detector treats interpolation
  # as `unverifiable`, so literal IDs keep this firmly in the
  # `vpc_isolated` positive-evidence path).
  vpc_config {
    subnet_ids         = ["subnet-private-a", "subnet-private-b"]
    security_group_ids = ["sg-lambda-egress"]
  }
}

resource "aws_cloudwatch_log_group" "api_handler_logs" {
  name              = "/aws/lambda/api-handler"
  retention_in_days = 90
}

resource "aws_lambda_function" "background_worker" {
  function_name = "background-worker"
  role          = aws_iam_role.lambda_exec.arn
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "background_worker.zip"
  # No matching aws_cloudwatch_log_group declared (logging gap),
  # env-vars without kms_key_arn (KMS gap), AND no vpc_config
  # (internet_facing gap on the rev-3 detector).

  environment {
    variables = {
      LOG_LEVEL = "INFO"
    }
  }
}
