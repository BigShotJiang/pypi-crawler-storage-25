# Fixture: aws_iam_policy_document data sources used as the policy
# argument to aws_iam_policy. Exercises the IaC-evidence-resolution
# the v0.1.7 fixes added — the agent must follow the data-source
# reference to evaluate the actual policy shape, not just see
# `data.aws_iam_policy_document.scoped.json` and bail.
#
# Three policies, three postures:
#   1. scoped_admin (admin_with_mfa) — includes MFA condition; principle
#      of least privilege applied via Resource scoping.
#   2. wildcard_admin (admin_no_mfa) — wildcard Action, wildcard
#      Resource, no condition. The clear gap.
#   3. read_only_audit — narrow Action list, narrow Resource pattern,
#      no MFA gate but also no write privileges.

data "aws_iam_policy_document" "scoped_admin" {
  statement {
    sid    = "AdminWithMFA"
    effect = "Allow"

    actions = [
      "s3:*",
      "iam:GetRole",
      "iam:ListRoles",
    ]

    resources = [
      "arn:aws:s3:::audit-logs-bucket",
      "arn:aws:s3:::audit-logs-bucket/*",
    ]

    condition {
      test     = "Bool"
      variable = "aws:MultiFactorAuthPresent"
      values   = ["true"]
    }
  }
}

resource "aws_iam_policy" "scoped_admin" {
  name   = "scoped-admin"
  policy = data.aws_iam_policy_document.scoped_admin.json
}

data "aws_iam_policy_document" "wildcard_admin" {
  statement {
    sid       = "FullAdmin"
    effect    = "Allow"
    actions   = ["*"]
    resources = ["*"]
  }
}

resource "aws_iam_policy" "wildcard_admin" {
  name   = "wildcard-admin"
  policy = data.aws_iam_policy_document.wildcard_admin.json
}

data "aws_iam_policy_document" "read_only_audit" {
  statement {
    sid    = "AuditReadOnly"
    effect = "Allow"

    actions = [
      "cloudtrail:LookupEvents",
      "cloudtrail:GetTrailStatus",
      "config:Describe*",
      "config:Get*",
    ]

    resources = ["*"]
  }
}

resource "aws_iam_policy" "read_only_audit" {
  name   = "read-only-audit"
  policy = data.aws_iam_policy_document.read_only_audit.json
}
