resource "aws_backup_vault" "primary_vault" {
  name        = "govnotes-primary-vault"
  kms_key_arn = aws_kms_key.app_data.arn
}

resource "aws_backup_plan" "daily_with_dr" {
  name = "govnotes-daily-with-dr"

  rule {
    rule_name         = "daily-prod"
    target_vault_name = aws_backup_vault.primary_vault.name
    schedule          = "cron(0 5 * * ? *)"

    lifecycle {
      delete_after = 35
    }

    copy_action {
      destination_vault_arn = "arn:aws:backup:us-west-2:123456789012:backup-vault:govnotes-dr-vault"
      lifecycle {
        delete_after = 35
      }
    }
  }
}

resource "aws_backup_selection" "primary_resources" {
  iam_role_arn = "arn:aws:iam::123456789012:role/govnotes-backup-role"
  name         = "primary-resources"
  plan_id      = aws_backup_plan.daily_with_dr.id

  resources = [
    aws_db_instance.primary.arn,
  ]
}
