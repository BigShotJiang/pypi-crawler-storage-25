resource "aws_security_group" "app_lb" {
  name        = "app-lb"
  description = "Application LB — HTTPS-only from corporate VPN CIDR"
  vpc_id      = "vpc-0abc123"

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]
  }
}

resource "aws_security_group" "bastion_open" {
  name        = "bastion-open"
  description = "Legacy bastion — SSH open to the internet (the gap)"
  vpc_id      = "vpc-0abc123"

  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
