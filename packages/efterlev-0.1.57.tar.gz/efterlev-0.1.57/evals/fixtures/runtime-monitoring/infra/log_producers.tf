# CloudTrail + CloudWatch log group as log PRODUCERS, but no
# aggregator (no Kinesis Firehose / OpenSearch / log-subscription-filter).
# Exercises aws.centralized_log_aggregation detector — should fire
# the `producers_only` / `aggregator_count = 0` finding (KSI-MLA-OSM
# gap on the centralization slice).

resource "aws_cloudtrail" "primary" {
  name                          = "primary-trail"
  s3_bucket_name                = aws_s3_bucket.cloudtrail_destination.bucket
  is_multi_region_trail         = true
  enable_log_file_validation    = true
  include_global_service_events = true
}

resource "aws_s3_bucket" "cloudtrail_destination" {
  bucket = "runtime-monitoring-cloudtrail-logs"
}

resource "aws_cloudwatch_log_group" "app_logs" {
  name              = "/runtime-monitoring/app"
  retention_in_days = 90
}

# Note: NO aws_kinesis_firehose_delivery_stream, NO
# aws_cloudwatch_log_subscription_filter, NO aws_opensearch_domain.
# This is the deliberate gap — log producers exist, no centralized
# aggregator. The `centralized_log_aggregation` detector should report
# `aggregation_state = producers_only`.
