# Two critical CloudWatch metric alarms — root account use and
# CloudTrail config changes. Exercises aws.cloudwatch_alarms_critical
# detector (KSI-MLA-OSM + KSI-MLA-LET).

resource "aws_sns_topic" "security_alerts" {
  name = "runtime-monitoring-security-alerts"
}

resource "aws_cloudwatch_metric_alarm" "root_account_used" {
  alarm_name          = "root-account-used"
  alarm_description   = "Root account login or API call detected"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 1
  metric_name         = "RootAccountUsageCount"
  namespace           = "CloudTrailMetrics"
  period              = 300
  statistic           = "Sum"
  threshold           = 1
  alarm_actions       = [aws_sns_topic.security_alerts.arn]
}

resource "aws_cloudwatch_metric_alarm" "cloudtrail_config_changes" {
  alarm_name          = "cloudtrail-config-changes"
  alarm_description   = "CloudTrail configuration was modified"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 1
  metric_name         = "CloudTrailEventCount"
  namespace           = "CloudTrailMetrics"
  period              = 300
  statistic           = "Sum"
  threshold           = 1
  alarm_actions       = [aws_sns_topic.security_alerts.arn]
}
