# AWS Config enabled with both recorder and delivery channel.
# Exercises aws.config_enabled detector
# (KSI-MLA-EVC + KSI-SVC-ACM).

resource "aws_iam_role" "config_role" {
  name = "aws-config-recorder-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Service = "config.amazonaws.com"
      }
      Action = "sts:AssumeRole"
    }]
  })
}

resource "aws_config_configuration_recorder" "primary" {
  name     = "primary-recorder"
  role_arn = aws_iam_role.config_role.arn

  recording_group {
    all_supported                 = true
    include_global_resource_types = true
  }
}

resource "aws_s3_bucket" "config_destination" {
  bucket = "runtime-monitoring-config-destination"
}

resource "aws_config_delivery_channel" "primary" {
  name           = "primary-channel"
  s3_bucket_name = aws_s3_bucket.config_destination.bucket

  snapshot_delivery_properties {
    delivery_frequency = "Six_Hours"
  }
}
