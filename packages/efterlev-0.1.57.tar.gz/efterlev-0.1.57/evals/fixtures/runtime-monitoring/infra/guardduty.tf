# AWS GuardDuty enabled. Exercises aws.guardduty_enabled detector
# (KSI-MLA-OSM: SIEM-class continuous threat detection).

resource "aws_guardduty_detector" "primary" {
  enable                       = true
  finding_publishing_frequency = "FIFTEEN_MINUTES"

  datasources {
    s3_logs {
      enable = true
    }
    kubernetes {
      audit_logs {
        enable = false
      }
    }
  }
}
