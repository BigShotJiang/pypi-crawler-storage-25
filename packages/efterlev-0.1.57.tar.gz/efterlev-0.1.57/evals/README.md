# Efterlev agent-quality eval harness (Phase 1)

Measures agent classification quality + narrative quality against
human-labeled ground-truth fixtures. Catches the agent-quality
regression class that unit tests + `pytest -m deep` + the E2E smoke
together can't see.

**v0.2 Phase 1 status (2026-05-08):** harness + 5 metrics + 3
synthetic fixtures + delta-vs-prior reporter. Phase 2 (sanitized
real fixtures, multi-model coverage) and Phase 3 (pre-merge eval
gate as required check) wait until baseline trend data is in. See
DECISIONS 2026-05-08 "v0.2 agent-quality eval harness: lock Phase 1
scope" for the full design.

## Quick start

```bash
# One-shot run against the canonical fixture (~5 min, ~$0.04 LLM):
python -m evals run --fixture evals/fixtures/govnotes-v1

# Same against the bucket-by-bucket variance fixture:
python -m evals run --fixture evals/fixtures/encryption-mixed

# Same against the dynamic-IAM-policy fixture:
python -m evals run --fixture evals/fixtures/iam-dynamic-policy
```

Each run lays down a fresh workspace under
`evals/results/<fixture_id>/<timestamp>/workspace/`, executes
`efterlev init -> scan -> agent gap -> agent document -> poam`,
parses the emitted reports, computes the 5 metrics, and writes a
`metrics.json` next to the workspace for trend tracking.

The CLI also prints a delta-vs-prior block at the end (compares
against the most-recent prior run on the same fixture). Drops
greater than the 5% noise-floor get a `!` indicator.

## When to run

- **Before merging an agent-prompt-touching PR.** Anything in
  `src/efterlev/agents/*.py` or the `*_prompt.md` files. The whole
  point of the harness is to catch the silent quality regression
  class prompt edits introduce.
- **Locally during prompt iteration.** ~$0.04/fixture on Haiku-
  Bedrock; the cost of *not* running it is shipping a regression
  no test catches.
- **Manually before tagging a release** that includes any agent-
  layer change (rare in v0.1.x; expected to be more common in v0.2+).

You don't need to run it for changes that only touch detectors,
docs, or the deterministic CLI surface — those are deep-smoke
territory.

## What the metrics measure

| Metric | What it catches |
|---|---|
| **M1 status_precision** | The agent over-claimed: said `implemented` when ground-truth accepts only `partial`. Inflates customer-facing coverage claims. |
| **M2 status_recall** | The agent under-claimed: said `not_implemented` when ground-truth accepts `partial`. Reproduces the v0.1.7 → v0.1.8 KSI-SVC-PRR drift class. |
| **M3 resource_naming_rate** | Rationales that cite evidence by `sha256:abc12345...` instead of the human-readable `resource_name`. Reproduces the v0.1.5–0.1.9 narrative-quality regression class. |
| **M4 manifest_quoting_accuracy** | Documentation narratives that cross-wire manifest content between KSIs (the v0.1.8 F5 bug shape — KSI-AFR-FSI quoted PagerDuty when only KSI-INR-RIR's manifest contained it). |
| **M5 poam_scope_discipline** | Two checks: (a) no out-of-boundary resource name leaks into POAM body, (b) excluded-out-of-boundary count falls within fixture's expected range. Catches boundary-leak regressions and "boundary check disappeared" regressions. |

All scores are 0–1. Per the DECISIONS Phase 1 discipline, we
yellow-flag (PR comment) on a > 5% regression but don't hard-block
the run. Hard-blocking lands in Phase 3 once 4+ weeks of trend data
calibrates the real noise floor.

## Configuration

The harness defaults to **Haiku 4.5 on Bedrock** per the project's
test-LLM policy (DECISIONS 2026-05-08 "test-LLM default"). Two
overrides for maintainer-specific use:

```bash
# Use the maintainer's pinned account-scoped ARN (set in shell rc):
export EFTERLEV_TEST_BEDROCK_MODEL="arn:aws:bedrock:us-east-1:.../profile/..."
python -m evals run --fixture evals/fixtures/govnotes-v1

# Or pass a different model explicitly:
python -m evals run --fixture evals/fixtures/govnotes-v1 \
  --llm-model us.anthropic.claude-sonnet-4-6

# Or fall back to Anthropic API (e.g. when AWS creds aren't loaded):
python -m evals run --fixture evals/fixtures/govnotes-v1 \
  --llm-backend anthropic --llm-model claude-sonnet-4-6
```

`--llm-region` defaults to `us-east-1` for Bedrock. `--results-root`
defaults to `evals/results/<fixture_id>/`.

### Multi-run aggregates (`--runs N`)

Single-run metrics are noisy on small denominators — a one-call
swing on a 4-denominator metric is a 0.25 swing. When evaluating
a prompt or fixture change, run with `--runs 3` or `--runs 5` to
get above the per-metric noise floor:

```bash
python -m evals run --fixture evals/fixtures/govnotes-v1 --runs 5
```

Each run still writes its own `<timestamp>/metrics.json`; the
aggregate (per-metric mean / stddev / min / max) is appended to
the summary and saved to `<last-timestamp>/aggregate.json` so
future runs can compare aggregates against it.

The DECISIONS log records noise floors (M1 ~0.20, M2 ~0.10,
M3 ~0.20, M4 ~0.05, M5 ~0.05 on Haiku 4.5 against the Phase 1
fixtures); a prompt-iteration delta inside those bounds is noise.

## Adding a fixture

A fixture is a directory under `evals/fixtures/<id>/` with:

```
<fixture-dir>/
  infra/                       # required: at least one .tf file
  .github/workflows/           # optional: for github-source detectors
  .efterlev/manifests/         # optional: per-KSI Evidence Manifests
  GROUND_TRUTH.yaml            # required: see GROUND_TRUTH_FORMAT.md
```

Authoring discipline:

1. **Start small.** A fixture with ~10 .tf files exercises plenty.
2. **Label conservatively.** Only put a KSI in
   `expected_classifications` when the verdict is unambiguous from
   the fixture's evidence. Unlabeled KSIs are SKIPPED in metric
   calculation, not penalized — partial labeling is fine.
3. **Use `<status1>|<status2>` alternation** when more than one
   verdict is defensible. Procedural-only KSIs without manifests
   typically use `evidence_layer_inapplicable|not_applicable`.
4. **Author the fixture and labels in the same commit.** Drift
   between Terraform and ground-truth is the worst kind of bug —
   silent, slow-to-discover.

See `GROUND_TRUTH_FORMAT.md` for the full schema reference.

## Layout

```
evals/
  __init__.py
  __main__.py             # python -m evals entry
  cli.py                  # argparse + report assembly
  ground_truth.py         # Pydantic schema + YAML loader
  metrics.py              # M1-M5 implementations
  diff.py                 # delta-vs-prior reporter
  harness.py              # pipeline driver (subprocess to efterlev)
  fixtures/
    govnotes-v1/          # canonical synthetic; ports quickstart's FIXTURE
    encryption-mixed/     # 6 buckets, mixed SSE + PAB; bucket-variance
    iam-dynamic-policy/   # aws_iam_policy_document data sources
  results/                # gitignored — local run artifacts
    <fixture-id>/<timestamp>/
      workspace/          # .efterlev/ + infra/ + reports/
      metrics.json        # per-run scores; consumed by the diff reporter

tests/
  test_evals_ground_truth.py
  test_evals_metrics.py
  test_evals_diff.py
```

## Cross-references

- `docs/v0.2-eval-harness-plan.md` — the 2026-05-05 design sketch.
- DECISIONS 2026-05-08 "v0.2 agent-quality eval harness: lock Phase 1
  scope" — what this PR series locks vs the sketch.
- DECISIONS 2026-05-08 "test-LLM default" + project memory
  `project_efterlev_test_llm_default.md` — the Haiku-on-Bedrock
  policy this harness's default model selection follows.
- CLAUDE.md "Testing tiers" — where the eval harness fits relative
  to the unit / deep-smoke / e2e tiers.
- `scripts/e2e_smoke.py` — the pipeline driver this harness
  generalizes.
