# GROUND_TRUTH.yaml schema reference

Every eval fixture under `evals/fixtures/<id>/` carries a
`GROUND_TRUTH.yaml` that names the human-labeled expected outputs
the harness measures agent runs against. This file documents the
schema; the canonical implementation is
`evals/ground_truth.py::GroundTruth` (Pydantic model).

## Required metadata fields

```yaml
fixture_id: govnotes-v1                 # Must match the directory name.
description: |                          # Free-form; surfaced in run output.
  One-paragraph description of what
  this fixture exercises.
authored_by: maintainer@example.com     # Email; used for accountability.
authored_at: 2026-05-08                 # ISO date. Date-coerced if unquoted.
revision: 1                             # Bump when ground-truth changes.
frmr_version: 0.9.43-beta               # Pinned. Loader fail-closes on
                                        # mismatch (Phase 1 contract).
```

**Why `frmr_version` is pinned:** FRMR catalog updates can rename
KSIs, redefine statuses, or reshuffle controls. A ground-truth
labeled against an older catalog will silently mis-measure agents
against a newer one. The loader rejects mismatched versions; a
migration tool ships in Phase 2.

## Optional: expected_classifications (drives M1 + M2)

Maps KSI-id → expected status string. Acceptable status values:
`implemented`, `partial`, `not_implemented`,
`evidence_layer_inapplicable`, `not_applicable`.

```yaml
expected_classifications:
  KSI-IAM-MFA: partial                  # Single acceptable status
  KSI-CMT-RVP: evidence_layer_inapplicable|not_applicable
                                        # Two acceptable statuses (alternation)
  KSI-SVC-VRI: partial
```

**Status alternation (`a|b`).** A KSI labeled `partial|not_implemented`
accepts EITHER status as a hit. Use this when more than one verdict
is defensible — typically procedural-only KSIs without manifests
(where `evidence_layer_inapplicable` and `not_applicable` are both
honest), or fixtures with mixed posture where the agent could
reasonably weight the gaps to land at either `partial` or
`not_implemented`. Don't use it to dodge labeling discipline; if you
can't decide, leave the KSI unlabeled (the metrics skip unlabeled
KSIs rather than penalize them).

## Optional: expected_rationale_resources (drives M3)

Maps KSI-id → list of resource-name substrings that MUST appear in
the gap-agent's rationale for that KSI. The metric scores 1.0 for
the KSI when at least ONE listed substring appears (exact match).

```yaml
expected_rationale_resources:
  KSI-SVC-VRI:
    - app_uploads          # the fully-compliant resource
    - legacy_export        # the gap to call out
  KSI-CNA-MAT:
    - reports
    - public_assets
```

**Authoring discipline:** list 2-4 resource names per KSI, mixing
positive and negative cases when the fixture has both. Catching
the v0.1.5-0.1.9 narrative bug class (rationales citing
`sha256:abc12345...` instead of resource names) requires the
expected names to be unique enough that an sha-citation is the
only way to fail — generic words like "bucket" or "policy" don't
work.

## Optional: expected_manifest_quoting (drives M4)

Maps KSI-id → list of substrings that MUST appear in the
documentation-agent's narrative for that KSI. Typically, these are
specific phrases from the KSI's Evidence Manifest's `statement:`
field.

```yaml
expected_manifest_quoting:
  KSI-AFR-FSI:
    - "security@example.com"
    - "PagerDuty"
    - "15-minute"
```

**Why this exists:** the v0.1.8 F5 bug had KSI-AFR-FSI's narrative
quoting PagerDuty (which belongs to KSI-INR-RIR's manifest) and
KSI-INR-RIR not quoting PagerDuty even though it's its own. M4
catches that cross-wiring class.

## Optional: expected_poam (drives M5)

POAM scope discipline. Two checks:

```yaml
expected_poam:
  excluded_count_min: 0                 # Inclusive lower bound.
  excluded_count_max: 6                 # Inclusive upper bound.
  must_not_mention:                     # Substrings that must NOT
    - dev_scratch                       #   appear in POAM body.
    - internal_qa_bucket
```

- **`excluded_count_min` / `excluded_count_max`** — the
  out-of-boundary excluded count reported in the POAM header bullet
  must fall in this range. Pick values that match what the fixture's
  `boundary set` would produce. A fixture with no out-of-boundary
  resources can leave both at 0.
- **`must_not_mention`** — list of substrings (typically
  out-of-boundary resource names from the fixture) that MUST NOT
  appear anywhere in the POAM body. Catches boundary leaks where
  OOB content slips into in-boundary narrative.

If you don't care about POAM scope for this fixture, just leave
`expected_poam` out — the loader applies the default
(min=0, max=60, no leak constraints), which always passes.

## Authoring workflow

1. Create the fixture directory with `infra/` (and optionally
   `.github/workflows/` and `.efterlev/manifests/`).
2. Run `python -m evals run --fixture evals/fixtures/<id>` to
   produce the first agent output. The run will fail M1 (no
   ground-truth labels yet) but writes the gap report you'll
   reference for labeling.
3. Read the gap report's `ksi_classifications` and the documentation
   report's `attestations`. Pick the high-confidence KSIs to label.
4. Write `GROUND_TRUTH.yaml` with conservative labels. Use
   alternation when defensible; leave undecided KSIs unlabeled.
5. Re-run the harness. Iterate until the metrics produce a useful
   baseline.
6. Commit the fixture + GROUND_TRUTH.yaml in the same PR.

## Validation

The loader (`evals.ground_truth.load_ground_truth`) validates:

- `frmr_version` is in the supported set.
- Every status in `expected_classifications` is a recognized enum
  value (after splitting on `|`).
- `expected_poam.excluded_count_max >= excluded_count_min`.
- Top-level YAML is a mapping (not a list / scalar / null).

Validation failures raise `ValueError` with a descriptive message;
the CLI prints it cleanly and exits 1.
