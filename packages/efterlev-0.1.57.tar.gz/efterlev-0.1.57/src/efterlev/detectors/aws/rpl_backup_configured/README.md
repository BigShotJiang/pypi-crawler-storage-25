# aws.rpl_backup_configured

Detects whether IaC-declared recovery-plan primitives are configured.
Evidences KSI-RPL-ARP "Aligning Recovery Plan" at the configured-state
half of its `partial` classification — the procedural review cadence
("persistently review the alignment with defined recovery objectives")
is Evidence Manifest territory.

This detector is intentionally distinct from `aws.backup_retention_configured`,
which covers KSI-RPL-ABO + CP-9 (RDS retention + S3 versioning). This
one covers the **orchestration + alternate-site** half of the recovery
plan — AWS Backup service primitives and RDS cross-region replication.

## What it detects

| Resource | Pattern | Detail |
|---|---|---|
| `aws_backup_plan` | `backup_plan` | `rules=N` (rule count) + `copy_actions=M` (cross-region copy count) |
| `aws_backup_vault` | `backup_vault` | `cmk=true` if `kms_key_arn` set |
| `aws_backup_selection` | `backup_selection` | (none) |
| `aws_db_instance_automated_backups_replication` | `rds_cross_region_replication` | `source=<arn>` |

Positive-only emission. The absence of AWS Backup resources isn't a
gap per se — many small workspaces use only RDS native backups
(covered by `aws.backup_retention_configured`) and don't need the
multi-resource AWS Backup orchestration layer. The Gap Agent reasons
about scale-justified gaps; this detector emits configuration facts.

## What it proves

- **KSI-RPL-ARP (Aligning Recovery Plan).** Configured AWS Backup
  orchestration + cross-region replication primitives.
- **CP-7 (Alternate Processing Site).** Cross-region backup copies +
  RDS automated-backups replication = configured alternate-site
  capability.
- **CP-10 (System Recovery and Reconstitution).** AWS Backup plans
  orchestrate the recovery primitives.

## What it does NOT prove

- **Alignment with stated RTO / RPO.** KSI-RPL-ARP's "alignment"
  half is procedural — manifest territory.
- **Whether backup-restore actually succeeds.** That's
  `aws.backup_restore_testing`'s concern (KSI-RPL-TRC + CP-4).
- **Whether the cross-region copy targets a region geographically
  separated enough.** "Different region" is a static signal; whether
  a customer's risk model accepts us-east-1 → us-west-2 vs.
  us-east-1 → eu-west-1 requires human judgment.
- **Vault lock policies / object-lock guarantees.** Future detector
  candidate; current scope is plan + vault + selection inventory.

## KSI mapping

`KSI-RPL-ARP` → `CP-7`, `CP-10`. Per DECISIONS 2026-05-07 "Tier 1 #4
design", KSI-RPL-ARP classified `partial` — the IaC layer covers the
configured-state half (this detector); the manifest covers the
alignment-review half.

## Fixtures

- `fixtures/should_match/` — `.tf` files producing positive evidence
  for each pattern.
- `fixtures/should_not_match/` — workspaces with no AWS Backup +
  no cross-region replication resources (no evidence emitted).
