resource "aws_backup_plan" "daily_with_dr" {
  name = "daily-with-dr-copy"

  rule {
    rule_name         = "daily-prod"
    target_vault_name = "prod-backup-vault"
    schedule          = "cron(0 5 * * ? *)"

    lifecycle {
      delete_after = 35
    }

    copy_action {
      destination_vault_arn = "arn:aws:backup:us-west-2:123456789012:backup-vault:dr-backup-vault"
      lifecycle {
        delete_after = 35
      }
    }
  }

  rule {
    rule_name         = "weekly-archive"
    target_vault_name = "prod-backup-vault"
    schedule          = "cron(0 6 ? * SUN *)"

    lifecycle {
      cold_storage_after = 30
      delete_after       = 365
    }
  }
}
