resource "aws_backup_vault" "prod_vault" {
  name        = "prod-backup-vault"
  kms_key_arn = "arn:aws:kms:us-east-1:123456789012:key/backup-vault-cmk"
}
