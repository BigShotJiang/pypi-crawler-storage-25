# Workspace with only an RDS instance + S3 bucket (covered by the
# existing `aws.backup_retention_configured` detector, NOT this one).
resource "aws_db_instance" "app" {
  identifier              = "app-prod"
  engine                  = "postgres"
  instance_class          = "db.t3.medium"
  allocated_storage       = 20
  backup_retention_period = 14
}

resource "aws_s3_bucket" "data" {
  bucket = "app-data-prod"
}
