resource "aws_db_instance_automated_backups_replication" "dr" {
  source_db_instance_arn = "arn:aws:rds:us-east-1:123456789012:db:app-prod"
  retention_period       = 35
}
