resource "aws_backup_selection" "prod_resources" {
  iam_role_arn = "arn:aws:iam::123456789012:role/backup-role"
  name         = "prod-resources"
  plan_id      = "abc-123-plan"

  resources = [
    "arn:aws:rds:us-east-1:123456789012:db:app-prod",
    "arn:aws:dynamodb:us-east-1:123456789012:table/audit-events",
  ]
}
