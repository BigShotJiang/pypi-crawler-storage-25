resource "aws_lambda_function" "isolated_handler" {
  function_name = "isolated-handler"
  role          = "arn:aws:iam::123456789012:role/lambda-role"
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "isolated.zip"

  vpc_config {
    subnet_ids         = ["subnet-abc123", "subnet-def456"]
    security_group_ids = ["sg-789xyz"]
  }
}
