resource "aws_lambda_function" "webhook_handler" {
  function_name = "webhook-handler"
  role          = "arn:aws:iam::123456789012:role/lambda-role"
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "webhook.zip"
  # No vpc_config -- function executes in AWS-managed default pool
  # with internet egress. May be intentional (webhook receiver) or
  # a gap; the Gap Agent reasons from broader context.
}
