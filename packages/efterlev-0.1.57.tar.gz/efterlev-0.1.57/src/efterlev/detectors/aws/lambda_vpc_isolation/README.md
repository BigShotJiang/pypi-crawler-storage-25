# aws.lambda_vpc_isolation

Detects whether each `aws_lambda_function` declares a `vpc_config`
block (network-isolated execution) or runs in the AWS-managed default
VPC pool (internet-facing). Compliance reviewers consistently ask
about VPC isolation posture for serverless boundaries — this detector
is the IaC-layer evidence source for KSI-CNA-MAT on the Lambda
dimension.

Per DECISIONS 2026-05-10 "Tier 2 #3 design: VPC isolation, route auth,
WAF attachment", this is the first detector of the Tier 2 #3 batch.
The fundamental design call: the detector emits per-resource posture
and the Gap Agent reasons about intentionality. Internet-facing
Lambdas are sometimes legitimate (webhook handlers, public health
endpoints); the detector does not try to distinguish them via
heuristics, annotations, or exemption lists.

## What it proves

- **KSI-CNA-MAT (Minimizing Attack Surface).** Each Lambda function
  in scope has a declared VPC isolation posture. Coverage is
  `partial` — the IaC layer evidences the configuration; runtime
  traffic routing and security-group egress correctness are out of
  scope.
- **SC-7 (Boundary Protection) + SC-7(3) (Access Points).** The
  IaC-layer half of declaring a network boundary on the Lambda
  surface.

## What it does NOT prove

- **Runtime traffic actually routes through the VPC.** A `vpc_config`
  declaration plus the right execution-role permissions configure
  the boundary; the detector doesn't verify behavior at invocation.
- **Security groups allow only intended egress.** The detector
  reports the SG count for visibility but does not inspect rules.
  `aws.security_group_open_ingress` covers SG ingress separately;
  egress evidence would be a Tier 3 candidate.
- **Subnets are themselves private.** The detector reports the
  subnet count but doesn't dereference each subnet to inspect
  `map_public_ip_on_launch` or routing-table associations.
- **The intentional-internet-Lambda case is not a gap.** Per the
  DECISIONS entry, the detector emits the gap unconditionally; the
  Gap Agent has the broader prompt context (function purpose,
  adjacent APIGW resources, manifest evidence) to reason about
  whether `internet_facing` is by design.

## Patterns recognized

| Lambda's `vpc_config` | Subnet/SG IDs | `isolation_state` |
|---|---|---|
| Block declared | All literal | `vpc_isolated` |
| Block declared | Any interpolated (`module.vpc.private_subnets`, etc.) | `unverifiable` |
| Block absent | (n/a) | `internet_facing` (gap) |

## KSI mapping

| KSI | Coverage | Notes |
|---|---|---|
| KSI-CNA-MAT | partial | Per-Lambda VPC isolation posture |

## 800-53 controls

| Control | Evidence type | Coverage |
|---|---|---|
| SC-7 | infrastructure | partial |
| SC-7(3) | infrastructure | partial |

## Example

Input:

```hcl
resource "aws_lambda_function" "isolated_handler" {
  function_name = "isolated-handler"
  role          = "arn:aws:iam::123456789012:role/lambda-role"
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "isolated.zip"

  vpc_config {
    subnet_ids         = ["subnet-abc123", "subnet-def456"]
    security_group_ids = ["sg-789xyz"]
  }
}

resource "aws_lambda_function" "webhook_handler" {
  function_name = "webhook-handler"
  role          = "arn:aws:iam::123456789012:role/lambda-role"
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "webhook.zip"
  # No vpc_config -- intentionally internet-facing for receiving
  # GitHub webhooks. Detector will flag; Gap Agent should accept.
}
```

Output (two Evidence records):

```json
[
  {
    "content": {
      "resource_type": "aws_lambda_function",
      "resource_name": "isolated_handler",
      "function_name": "isolated-handler",
      "isolation_state": "vpc_isolated",
      "pattern": "lambda_vpc_isolation",
      "subnet_count": 2,
      "security_group_count": 1,
      "detail": "function_name=isolated-handler; vpc_config declared with 2 subnet(s) and 1 security group(s)"
    }
  },
  {
    "content": {
      "resource_type": "aws_lambda_function",
      "resource_name": "webhook_handler",
      "function_name": "webhook-handler",
      "isolation_state": "internet_facing",
      "pattern": "lambda_vpc_isolation",
      "gap": "aws_lambda_function 'webhook-handler' has no vpc_config block; the function executes in the AWS-managed default VPC pool with internet egress. Compliance reviewers consistently ask about VPC isolation posture for serverless boundaries. If this Lambda is intentionally internet-facing (webhook handler, public health endpoint), the reviewer should annotate the gap as accepted."
    }
  }
]
```

## Fixtures

- `fixtures/should_match/lambda_with_vpc_config.tf` — Lambda with
  literal subnet + SG IDs (positive: `vpc_isolated`).
- `fixtures/should_not_match/lambda_no_vpc_config.tf` — Lambda
  without `vpc_config` (negative: `internet_facing` gap).
