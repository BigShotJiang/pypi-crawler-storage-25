resource "aws_api_gateway_domain_name" "implicit_legacy" {
  domain_name              = "implicit-legacy.example.com"
  regional_certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/jkl-012"
  # security_policy omitted; AWS provider defaults to TLS_1_0 -- the gap.

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}
