# aws.api_gateway_tls_min_version

Detects the configured TLS-policy floor on AWS API Gateway custom
domains. Reads `aws_api_gateway_domain_name` (REST API v1) and
`aws_apigatewayv2_domain_name` (HTTP/WebSocket API v2) resources and
emits one Evidence record per custom domain describing whether the
`security_policy` enforces TLS 1.2 or higher.

Per DECISIONS 2026-05-09 "Tier 2 #1 design: Lambda + API Gateway
detector batch v0", this is the second of two v0 serverless detectors.
Pairs with `aws.lambda_logging_configured` for the most common
serverless edge (Lambda behind API Gateway).

## What it proves

- **KSI-SVC-SNT (Securing Network Traffic).** Each API Gateway custom
  domain in scope enforces a TLS 1.2-or-higher floor on inbound
  client connections. Coverage is `partial` — the IaC layer proves
  the configured floor; runtime cipher negotiation outcomes and
  edge-infrastructure adherence are out of scope.
- **SC-8 / SC-13 / SC-23.** Transmission integrity, cryptographic
  protection, and session authenticity at the policy-floor layer.

## What it does NOT prove

- **Runtime cipher negotiation outcomes.** A configured `TLS_1_2`
  floor restricts what the negotiator can pick; it doesn't prove
  any specific cipher suite is actually used.
- **The underlying CloudFront / edge infrastructure honors the
  configured policy.** API Gateway custom domains terminate at
  CloudFront edges in many regions — the IaC layer doesn't see the
  edge's runtime TLS configuration.
- **Certificate rotation, validity, or correct hostname binding.**
  Adjacent runtime concerns.
- **Backend-integration TLS posture.** Whether API Gateway → Lambda
  / VPC link / HTTP integration uses TLS is a separate dimension
  not covered here.
- **Default-domain TLS posture** (`<api-id>.execute-api.<region>.amazonaws.com`).
  AWS-managed; not configurable from IaC.
- **Auth on routes, throttling, WAF attachment.** Each its own
  potential detector per the deferred items in DECISIONS 2026-05-09.

## Patterns recognized

| Resource type | Where `security_policy` lives | `tls_min_state` |
|---|---|---|
| `aws_api_gateway_domain_name` (v1) | top-level attribute | `configured` if `TLS_1_2` / `TLS_1_3`; `absent` if `TLS_1_0` or omitted (default) |
| `aws_apigatewayv2_domain_name` (v2) | nested in `domain_name_configuration` block | `configured` if `TLS_1_2` / `TLS_1_3` or omitted (v2 default); `absent` if explicitly weaker |
| Either | value uses Terraform interpolation | `unverifiable` |
| `aws_apigatewayv2_domain_name` with no `domain_name_configuration` block | (malformed — block is required) | (no evidence emitted) |

The v1 default-`TLS_1_0` behavior is the canonical legacy gap that
the detector exists to surface — REST API v1 custom domains created
without an explicit `security_policy` accept TLS 1.0 connections,
which is below the FedRAMP TLS 1.2+ floor.

## KSI mapping

| KSI | Coverage | Notes |
|---|---|---|
| KSI-SVC-SNT | partial | IaC-declared TLS-policy floor on the custom domain |

## 800-53 controls

| Control | Evidence type | Coverage |
|---|---|---|
| SC-8 | infrastructure | partial |
| SC-13 | infrastructure | partial |
| SC-23 | infrastructure | partial |

## Example

Input:

```hcl
resource "aws_api_gateway_domain_name" "compliant" {
  domain_name              = "api.example.com"
  regional_certificate_arn = "arn:aws:acm:us-east-1:123:certificate/abc"
  security_policy          = "TLS_1_2"

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}

resource "aws_api_gateway_domain_name" "legacy_gap" {
  domain_name              = "legacy-api.example.com"
  regional_certificate_arn = "arn:aws:acm:us-east-1:123:certificate/def"
  # security_policy omitted → defaults to TLS_1_0

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}
```

Output (two Evidence records — one per custom domain):

```json
[
  {
    "content": {
      "resource_type": "aws_api_gateway_domain_name",
      "resource_name": "compliant",
      "tls_min_state": "configured",
      "pattern": "rest_api_v1_custom_domain",
      "security_policy": "TLS_1_2",
      "detail": "security_policy=TLS_1_2"
    }
  },
  {
    "content": {
      "resource_type": "aws_api_gateway_domain_name",
      "resource_name": "legacy_gap",
      "tls_min_state": "absent",
      "pattern": "rest_api_v1_custom_domain",
      "security_policy": "TLS_1_0",
      "gap": "aws_api_gateway_domain_name 'legacy_gap' uses security_policy='TLS_1_0' (provider default when the attribute is omitted); traffic terminating at this custom domain is permitted to negotiate down to TLS 1.0, below FedRAMP's TLS 1.2+ floor"
    }
  }
]
```

## Fixtures

- `fixtures/should_match/v1_tls_1_2.tf` — REST v1 custom domain with
  explicit `security_policy = "TLS_1_2"`.
- `fixtures/should_match/v2_default.tf` — HTTP v2 custom domain
  without an explicit policy (resolves to `TLS_1_2` per AWS service
  default).
- `fixtures/should_not_match/v1_tls_1_0.tf` — REST v1 custom domain
  with explicit `security_policy = "TLS_1_0"` (the gap).
- `fixtures/should_not_match/v1_default.tf` — REST v1 custom domain
  with no `security_policy` (defaults to `TLS_1_0`, the gap).
