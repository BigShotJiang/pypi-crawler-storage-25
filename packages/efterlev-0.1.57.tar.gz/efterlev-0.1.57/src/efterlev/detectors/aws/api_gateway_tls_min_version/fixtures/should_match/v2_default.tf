resource "aws_apigatewayv2_domain_name" "v2_compliant" {
  domain_name = "v2-api.example.com"

  domain_name_configuration {
    certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/def-456"
    endpoint_type   = "REGIONAL"
    # security_policy omitted; v2 defaults to TLS_1_2 (the only supported value)
  }
}
