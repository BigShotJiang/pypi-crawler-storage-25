resource "aws_api_gateway_domain_name" "compliant" {
  domain_name              = "api.example.com"
  regional_certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/abc-123"
  security_policy          = "TLS_1_2"

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}
