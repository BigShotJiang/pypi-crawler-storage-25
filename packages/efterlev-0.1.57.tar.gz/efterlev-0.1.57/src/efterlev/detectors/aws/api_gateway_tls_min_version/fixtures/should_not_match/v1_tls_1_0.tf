resource "aws_api_gateway_domain_name" "explicit_legacy" {
  domain_name              = "legacy.example.com"
  regional_certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/ghi-789"
  security_policy          = "TLS_1_0"

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}
