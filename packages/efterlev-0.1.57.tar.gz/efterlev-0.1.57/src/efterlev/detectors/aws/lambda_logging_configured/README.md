# aws.lambda_logging_configured

Detects whether each `aws_lambda_function` declared in Terraform has a
corresponding `aws_cloudwatch_log_group` (matched by the canonical
`/aws/lambda/<function_name>` naming convention). Emits one Evidence
record per function describing one of three states: `configured`,
`absent`, or `unverifiable` (when `function_name` uses Terraform
interpolation that can't be resolved at scan time).

Per DECISIONS 2026-05-09 "Tier 2 #1 design: Lambda + API Gateway
detector batch v0", this is the first of two v0 serverless detectors.
Pairs with `aws.api_gateway_tls_min_version` for the most common
serverless edge (Lambda behind API Gateway).

## What it proves

- **KSI-MLA-LET (Logging Event Types).** Each Lambda function in scope
  has a managed CloudWatch log group declared in IaC. This gates the
  ability to set retention, KMS encryption, and access policies on the
  log destination — properties that AWS-auto-created log groups don't
  carry by default.
- **AU-2 (Event Logging) + AU-12 (Audit Record Generation).** The
  IaC-layer half of the audit-record-generation requirement: a log
  destination exists per function and is managed via Terraform.

## What it does NOT prove

- **Log retention adheres to FedRAMP requirements.** The detector
  doesn't read `retention_in_days` on the log group resource; that's
  an adjacent dimension worth its own detector.
- **The log group is KMS-encrypted.** Auto-created groups are
  unencrypted by default; the existence of the resource declaration
  gates this property but doesn't verify it. Future enhancement.
- **Logs are actually flowing at runtime.** A declared log group with
  no permissions on the Lambda execution role still produces no logs.
- **Log access control is restrictive.** The CloudWatch Logs resource
  policy + IAM principals with `logs:GetLogEvents` permission are
  not visible from the function/log-group declarations alone.
- **Logs are shipped to a SIEM.** That's the
  `aws.centralized_log_aggregation` detector's territory.

## Patterns recognized

| Lambda's `function_name` | Matching `aws_cloudwatch_log_group` exists? | `logging_state` |
|---|---|---|
| Literal string (e.g. `"my-handler"`) | Yes (`name = "/aws/lambda/my-handler"`) | `configured` |
| Literal string | No | `absent` |
| Terraform interpolation (`${var.x}`) | (cannot resolve) | `unverifiable` |
| Missing or non-string | (schema-malformed) | (no evidence emitted) |

The detector matches log groups by literal `name` only. Log groups whose
`name` itself uses interpolation are skipped — the function-side and
group-side names would need to resolve to the same resolved string for
a runtime match, but the IaC layer can't prove that.

## KSI mapping

| KSI | Coverage | Notes |
|---|---|---|
| KSI-MLA-LET | partial | IaC-declared log destination per function |

## 800-53 controls

| Control | Evidence type | Coverage |
|---|---|---|
| AU-2 | infrastructure | partial |
| AU-12 | infrastructure | partial |

## Example

Input:

```hcl
resource "aws_lambda_function" "compliant" {
  function_name = "my-handler"
  role          = aws_iam_role.lambda.arn
  handler       = "index.handler"
  runtime       = "python3.12"
}

resource "aws_cloudwatch_log_group" "compliant_logs" {
  name              = "/aws/lambda/my-handler"
  retention_in_days = 90
}

resource "aws_lambda_function" "missing_logs" {
  function_name = "auto-logs-only"
  role          = aws_iam_role.lambda.arn
  handler       = "index.handler"
  runtime       = "python3.12"
}
```

Output (two Evidence records — one per function):

```json
[
  {
    "content": {
      "resource_type": "aws_lambda_function",
      "resource_name": "compliant",
      "logging_state": "configured",
      "pattern": "log_group_per_function",
      "detail": "function_name=my-handler; log_group=/aws/lambda/my-handler"
    }
  },
  {
    "content": {
      "resource_type": "aws_lambda_function",
      "resource_name": "missing_logs",
      "logging_state": "absent",
      "pattern": "log_group_per_function",
      "gap": "aws_lambda_function 'auto-logs-only' has no matching aws_cloudwatch_log_group '/aws/lambda/auto-logs-only'; auto-created log groups have no retention or KMS-encryption configuration"
    }
  }
]
```

## Fixtures

- `fixtures/should_match/lambda_with_log_group.tf` — Lambda + matching
  `aws_cloudwatch_log_group` (positive case).
- `fixtures/should_not_match/lambda_without_log_group.tf` — Lambda with
  no corresponding log group (negative-evidence case).
