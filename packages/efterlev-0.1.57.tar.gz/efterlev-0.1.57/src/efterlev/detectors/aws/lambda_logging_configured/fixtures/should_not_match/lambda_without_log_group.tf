resource "aws_lambda_function" "auto_logs_only" {
  function_name = "auto-logs-only"
  role          = "arn:aws:iam::123456789012:role/lambda-role"
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "handler.zip"
}
