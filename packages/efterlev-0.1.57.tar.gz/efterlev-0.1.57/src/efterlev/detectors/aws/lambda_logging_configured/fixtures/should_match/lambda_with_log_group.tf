resource "aws_lambda_function" "handler" {
  function_name = "my-handler"
  role          = "arn:aws:iam::123456789012:role/lambda-role"
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "handler.zip"
}

resource "aws_cloudwatch_log_group" "handler_logs" {
  name              = "/aws/lambda/my-handler"
  retention_in_days = 90
}
