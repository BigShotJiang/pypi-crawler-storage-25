# aws.api_gateway_waf_attached

Detects whether each `aws_api_gateway_stage` (REST API v1) and
`aws_apigatewayv2_stage` (HTTP/WebSocket API v2) has an
`aws_wafv2_web_acl_association` referencing it. Customers without
ANY Web ACL on a public APIGW are visibly exposed; this detector is
the early-warning signal that a stage has zero L7 protection.

Per DECISIONS 2026-05-10 "Tier 2 #3 design: VPC isolation, route auth,
WAF attachment", this is detector δ of the Tier 2 #3 batch. Two
design calls govern this detector:

- **Decision #2:** ship as a single WAF-attachment detector now;
  defer the broader `aws.waf_*` family (rule coverage, rate
  limiting, geo-blocking, managed rule groups) to Tier 3.
- **Decision #3:** **NO `unverifiable` state.** WAF attachment is
  detected via cross-resource search; `resource_arn` references
  on `aws_wafv2_web_acl_association` are almost always Terraform
  interpolations (`${aws_apigatewayv2_stage.x.arn}`). Treating
  interpolation as `unverifiable` would force every real-world
  pairing into an unhelpful state. Detection is by name-substring
  match on the resolved-or-interpolated `resource_arn`.

## What it proves

- **KSI-CNA-RVP (Reviewing Protections).** Each API Gateway stage
  in scope has a declared L7 WAF attachment. Coverage is `partial`
  — the attachment declaration is the prerequisite; rule coverage
  (the actual protection capability) is the future `aws.waf_*`
  family's territory.
- **SI-3 (Malicious Code Protection) + SC-5 (Denial of Service
  Protection).** The IaC-layer half of declaring WAF protection at
  the L7 boundary.

Joins `aws.cna_dos_protection` on KSI-CNA-RVP — that detector covers
Shield-side DOS protection; this one covers the WAF side.

## What it does NOT prove

- **The Web ACL has any rules.** A Web ACL with zero rules is
  technically attached but does nothing. Future `aws.waf_*` family
  detectors will close this.
- **The rules are appropriate.** Rule selection (managed groups vs
  custom rules) is a separate dimension.
- **Rate limiting is configured.** Rate-based rules are a key WAF
  capability; not detected here.
- **Geo-blocking is configured.** Geo-match rules are another
  dimension.
- **The intentionally-private case is not a gap.** Per the DECISIONS
  entry, the detector emits `waf_absent` unconditionally; the Gap
  Agent reasons about whether the stage is intentionally private
  (internal API not exposed publicly).

## Patterns recognized

| Stage type | `aws_wafv2_web_acl_association` references stage? | `waf_state` |
|---|---|---|
| `aws_api_gateway_stage` (v1) | yes (by Terraform name match in `resource_arn`) | `waf_attached` |
| `aws_api_gateway_stage` (v1) | no | `waf_absent` (gap) |
| `aws_apigatewayv2_stage` (v2) | yes | `waf_attached` |
| `aws_apigatewayv2_stage` (v2) | no | `waf_absent` (gap) |

The detector matches `aws_wafv2_web_acl_association.resource_arn`
strings against `<stage_resource_type>.<stage_resource_name>` as a
substring. This works for both literal ARNs and interpolation
strings (`${aws_apigatewayv2_stage.prod.arn}`).

## KSI mapping

| KSI | Coverage | Notes |
|---|---|---|
| KSI-CNA-RVP | partial | Per-stage WAF-attachment posture |

## 800-53 controls

| Control | Evidence type | Coverage |
|---|---|---|
| SI-3 | infrastructure | partial |
| SC-5 | infrastructure | partial |

## Example

Input:

```hcl
resource "aws_apigatewayv2_stage" "protected_stage" {
  api_id      = "api-id-placeholder"
  name        = "prod"
  auto_deploy = true
}

resource "aws_wafv2_web_acl" "api_protection" {
  name  = "api-waf"
  scope = "REGIONAL"
  default_action {
    allow {}
  }
  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "api-waf"
    sampled_requests_enabled   = true
  }
}

resource "aws_wafv2_web_acl_association" "protect_protected_stage" {
  resource_arn = aws_apigatewayv2_stage.protected_stage.arn
  web_acl_arn  = aws_wafv2_web_acl.api_protection.arn
}

resource "aws_apigatewayv2_stage" "unprotected_stage" {
  api_id      = "api-id-placeholder"
  name        = "internal"
  auto_deploy = true
  # No matching aws_wafv2_web_acl_association.
}
```

Output (two Evidence records):

```json
[
  {
    "content": {
      "resource_type": "aws_apigatewayv2_stage",
      "resource_name": "protected_stage",
      "stage_name": "prod",
      "waf_state": "waf_attached",
      "pattern": "http_api_v2_stage_waf",
      "association_resource_name": "protect_protected_stage",
      "web_acl_arn": "${aws_wafv2_web_acl.api_protection.arn}",
      "detail": "stage_name=prod; aws_wafv2_web_acl_association 'protect_protected_stage' references this stage"
    }
  },
  {
    "content": {
      "resource_type": "aws_apigatewayv2_stage",
      "resource_name": "unprotected_stage",
      "stage_name": "internal",
      "waf_state": "waf_absent",
      "pattern": "http_api_v2_stage_waf",
      "gap": "aws_apigatewayv2_stage 'internal' has no aws_wafv2_web_acl_association referencing it; the stage receives no WAF protection at the L7 boundary. If this stage is intentionally private (internal API not exposed publicly), the reviewer should annotate the gap as accepted."
    }
  }
]
```

## Fixtures

- `fixtures/should_match/v1_stage_with_waf.tf` — REST v1 stage +
  matching `aws_wafv2_web_acl_association`.
- `fixtures/should_match/v2_stage_with_waf.tf` — HTTP v2 stage +
  matching association.
- `fixtures/should_not_match/v1_stage_without_waf.tf` — REST v1
  stage with no association (the gap).
