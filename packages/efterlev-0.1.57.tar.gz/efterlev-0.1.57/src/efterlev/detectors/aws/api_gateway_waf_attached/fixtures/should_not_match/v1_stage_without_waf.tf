resource "aws_api_gateway_stage" "internal_v1" {
  rest_api_id   = "rest-api-id-placeholder"
  deployment_id = "deployment-id-placeholder"
  stage_name    = "internal"
  # No matching aws_wafv2_web_acl_association -- the gap. Stage may
  # be intentionally private or genuinely unprotected; the Gap
  # Agent reasons from broader prompt context.
}
