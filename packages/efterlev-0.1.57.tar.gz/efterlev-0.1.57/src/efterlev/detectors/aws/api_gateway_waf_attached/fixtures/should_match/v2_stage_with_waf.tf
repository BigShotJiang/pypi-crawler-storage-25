resource "aws_apigatewayv2_stage" "protected_v2" {
  api_id      = "v2-api-id-placeholder"
  name        = "prod"
  auto_deploy = true
}

resource "aws_wafv2_web_acl" "v2_protection" {
  name  = "v2-api-waf"
  scope = "REGIONAL"

  default_action {
    allow {}
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "v2-api-waf"
    sampled_requests_enabled   = true
  }
}

resource "aws_wafv2_web_acl_association" "protect_protected_v2" {
  resource_arn = aws_apigatewayv2_stage.protected_v2.arn
  web_acl_arn  = aws_wafv2_web_acl.v2_protection.arn
}
