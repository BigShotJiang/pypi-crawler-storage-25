resource "aws_api_gateway_stage" "prod_v1" {
  rest_api_id   = "rest-api-id-placeholder"
  deployment_id = "deployment-id-placeholder"
  stage_name    = "prod"
}

resource "aws_wafv2_web_acl" "api_protection" {
  name  = "api-waf"
  scope = "REGIONAL"

  default_action {
    allow {}
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "api-waf"
    sampled_requests_enabled   = true
  }
}

resource "aws_wafv2_web_acl_association" "protect_prod_v1" {
  resource_arn = aws_api_gateway_stage.prod_v1.arn
  web_acl_arn  = aws_wafv2_web_acl.api_protection.arn
}
