resource "aws_lambda_function" "secrets_handler" {
  function_name = "secrets-handler"
  role          = "arn:aws:iam::123456789012:role/lambda-role"
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "secrets_handler.zip"
  kms_key_arn   = "arn:aws:kms:us-east-1:123456789012:key/abc-123"

  environment {
    variables = {
      DATABASE_URL = "postgres://..."
      API_TOKEN    = "..."
    }
  }
}
