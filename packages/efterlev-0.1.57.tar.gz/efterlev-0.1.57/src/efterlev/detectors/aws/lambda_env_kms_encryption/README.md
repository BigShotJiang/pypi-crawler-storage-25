# aws.lambda_env_kms_encryption

Detects whether each `aws_lambda_function` with non-empty environment
variables uses an explicit `kms_key_arn` (customer-managed-key
encryption-at-rest of env-var values). Lambda env vars are encrypted
at rest by AWS-managed keys by default; this detector surfaces the
explicit-CMK gap that compliance audits typically ask about.

Per DECISIONS 2026-05-10 "Tier 2 #2 design: Lambda env-var KMS +
APIGW access logging", this is detector β of the Tier 2 #2 batch —
the 8th detector evidencing KSI-AFR-UCM and the library's first
`aws_lambda_function`-side UCM evidence.

## What it proves

- **KSI-AFR-UCM (Using Cryptographic Modules).** Each Lambda function
  in scope that holds env-var secrets uses an explicit customer-
  managed key for encrypting them at rest. Coverage is `partial` —
  the IaC layer proves the CMK declaration; runtime key validity
  and FIPS posture are out of scope.
- **SC-28 (Protection of Information at Rest) + SC-28(1) (Cryptographic
  Protection).** The IaC-layer half of the env-var-encryption
  requirement: a customer-controlled key is configured, not just the
  AWS default.

## What it does NOT prove

- **Key validity at runtime.** A `kms_key_arn` declaration doesn't
  prove the key exists in AWS, the Lambda has `kms:Decrypt` permission
  on it, or that decryption succeeds at invocation time.
- **FIPS-approval status of the cryptographic module.** SC-13 evidence
  for a FIPS module is a separate dimension — KMS keys can be backed
  by HSM in some configurations but the IaC layer doesn't see that.
- **Key rotation cadence.** Already evidenced by `aws.kms_key_rotation`
  on the `aws_kms_key` resource the ARN points to.
- **Whether the env-var values should live in Secrets Manager
  instead.** Some compliance frameworks prefer Secrets Manager over
  Lambda env vars for high-sensitivity secrets; this is a design
  question, not an IaC-layer detection.
- **Functions with no env vars.** Skipped — no secrets to protect.
  Emitting noisy "no env vars to protect" evidence would dilute M3
  signal.

## Patterns recognized

| Lambda's env vars | `kms_key_arn` | `kms_state` |
|---|---|---|
| Empty or absent | (any) | (no evidence emitted — skipped) |
| Non-empty | Literal string ARN | `configured` |
| Non-empty | Absent | `absent` (gap: AWS-managed-key default) |
| Non-empty | Terraform interpolation (`${var.x}`) | `unverifiable` |

## KSI mapping

| KSI | Coverage | Notes |
|---|---|---|
| KSI-AFR-UCM | partial | IaC-declared CMK on Lambda env-var encryption |

## 800-53 controls

| Control | Evidence type | Coverage |
|---|---|---|
| SC-28 | infrastructure | partial |
| SC-28(1) | infrastructure | partial |

## Example

Input:

```hcl
resource "aws_lambda_function" "with_cmk" {
  function_name = "secrets-handler"
  role          = "arn:aws:iam::123456789012:role/lambda-role"
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "secrets_handler.zip"
  kms_key_arn   = "arn:aws:kms:us-east-1:123456789012:key/abc-123"

  environment {
    variables = {
      DATABASE_URL  = "postgres://..."
      API_TOKEN     = "..."
    }
  }
}

resource "aws_lambda_function" "default_kms" {
  function_name = "default-kms-handler"
  role          = "arn:aws:iam::123456789012:role/lambda-role"
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "default_handler.zip"
  # No kms_key_arn — AWS-managed-key encryption (the gap).

  environment {
    variables = {
      LOG_LEVEL = "INFO"
    }
  }
}

resource "aws_lambda_function" "no_env_vars" {
  function_name = "no-env-vars-handler"
  role          = "arn:aws:iam::123456789012:role/lambda-role"
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "stateless.zip"
  # No environment block — skipped by this detector.
}
```

Output (two Evidence records — `no_env_vars` is skipped):

```json
[
  {
    "content": {
      "resource_type": "aws_lambda_function",
      "resource_name": "with_cmk",
      "function_name": "secrets-handler",
      "kms_state": "configured",
      "pattern": "lambda_env_var_cmk",
      "kms_key_arn": "arn:aws:kms:us-east-1:123456789012:key/abc-123",
      "detail": "function_name=secrets-handler; kms_key_arn declared"
    }
  },
  {
    "content": {
      "resource_type": "aws_lambda_function",
      "resource_name": "default_kms",
      "function_name": "default-kms-handler",
      "kms_state": "absent",
      "pattern": "lambda_env_var_cmk",
      "gap": "aws_lambda_function 'default-kms-handler' declares environment variables but no kms_key_arn; env-var values are encrypted with AWS-managed keys, not a customer-managed key. The declared-CMK posture compliance frameworks ask about requires an explicit kms_key_arn"
    }
  }
]
```

## Fixtures

- `fixtures/should_match/lambda_with_cmk.tf` — function with non-empty
  env vars + explicit `kms_key_arn` (positive).
- `fixtures/should_not_match/lambda_default_kms.tf` — function with
  non-empty env vars + no `kms_key_arn` (negative-evidence case).
