resource "aws_lambda_function" "default_kms_handler" {
  function_name = "default-kms-handler"
  role          = "arn:aws:iam::123456789012:role/lambda-role"
  handler       = "index.handler"
  runtime       = "python3.12"
  filename      = "default_handler.zip"
  # No kms_key_arn set -- AWS-managed-key encryption (the gap).

  environment {
    variables = {
      LOG_LEVEL = "INFO"
    }
  }
}
