# aws.waf_action_types

Detects whether each `aws_wafv2_web_acl`'s rules enforce or merely
observe. Each rule has either a custom `action { block | allow |
captcha | count {} }` or a managed-group `override_action { none |
count {} }`. A `count` action means "log this rule's matches but do
not block them" — observability without enforcement. The canonical
gap: a managed-group rule with `override_action { count {} }` looks
like protection in the AWS console but blocks nothing.

Per DECISIONS 2026-05-10 "Tier 3 #3 design: aws.waf_* family v1 —
action types + IP-set blocking", this is detector β of the Tier 3 #3
batch. **6th detector evidencing KSI-CNA-RVP** (joining
`aws.cna_dos_protection`, `aws.api_gateway_waf_attached`,
`aws.waf_rule_count`, `aws.waf_managed_rule_groups`,
`aws.waf_rate_limiting`).

## What it proves

- **KSI-CNA-RVP (Reviewing Protections).** Each Web ACL in scope is
  classified by the enforcement posture of its rules. Coverage is
  `partial` — action-type presence is the prerequisite; per-rule
  appropriateness, ramp-up intent, and rule-priority interactions
  are future detectors.
- **SI-3.** L7 malicious-code protection — a `count` action defeats
  the SI-3 evidence the rule's presence would otherwise contribute.
- **SC-5.** Denial of Service Protection — a rate-based statement
  set to `count` action is the canonical "rate limiting in dry-run
  mode" gap.

## What it does NOT prove

- **Action choices are appropriate per rule.** A `block` action on
  an over-broad managed group might cause false positives a
  `captcha` action would avoid. Future per-managed-group action-fit
  detectors are candidates.
- **Count actions are intentional ramp-up vs forgotten dry-run.**
  Both shapes look identical at the IaC layer; the Gap Agent
  reasons about freshness from the rule's `priority` and the
  surrounding code's other signals.
- **Rule priorities don't short-circuit.** A high-priority `allow`
  rule above a low-priority `block` rule defeats the block; this
  detector classifies each rule independently, not their interaction.
- **Per-Web-ACL emission, not per-rule.** Per-rule would explode
  evidence-record count without adding signal the Gap Agent needs.

## Patterns recognized

| Web ACL state | `rule_state` |
|---|---|
| All declared rules enforce (action.block / action.allow / action.captcha / override_action.none / no action block at all) | `enforcing` |
| At least one rule declared AND every rule is count-action | `observing_only` (gap) |
| Both enforcing and count rules present | `mixed` (informational, NOT a gap) |

A Web ACL with **zero rules** emits `enforcing` with `rule_count=0`
— vacuous; no gap to flag, since `aws.waf_rule_count` already
flags the rules-absent gap. Per Decision #6 of the DECISIONS entry,
rules without either `action` or `override_action` block default to
enforcing (the AWS-side default for missing `override_action` on a
managed-group rule is `none`).

## KSI mapping

| KSI | Coverage | Notes |
|---|---|---|
| KSI-CNA-RVP | partial | Per-Web-ACL action-type posture |

## 800-53 controls

| Control | Evidence type | Coverage |
|---|---|---|
| SI-3 | infrastructure | partial |
| SC-5 | infrastructure | partial |

## Example

Input:

```hcl
resource "aws_wafv2_web_acl" "enforcing_one" {
  name  = "enforcing-waf"
  scope = "REGIONAL"

  default_action {
    allow {}
  }

  rule {
    name     = "block-bad-host"
    priority = 1
    action {
      block {}
    }
    statement {
      byte_match_statement {
        positional_constraint = "CONTAINS"
        search_string         = "evil.example.com"
        field_to_match { single_header { name = "host" } }
        text_transformation {
          priority = 0
          type     = "NONE"
        }
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "block-bad-host"
      sampled_requests_enabled   = true
    }
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "enforcing-waf"
    sampled_requests_enabled   = true
  }
}

resource "aws_wafv2_web_acl" "observing_only" {
  name  = "observing-only-waf"
  scope = "REGIONAL"

  default_action {
    allow {}
  }

  rule {
    name     = "common-rules-in-count"
    priority = 1
    override_action {
      count {}                 # the gap: managed group set to count
    }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesCommonRuleSet"
        vendor_name = "AWS"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "common-rules-in-count"
      sampled_requests_enabled   = true
    }
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "observing-only-waf"
    sampled_requests_enabled   = true
  }
}
```

Output (two Evidence records):

```json
[
  {
    "content": {
      "resource_name": "enforcing_one",
      "rule_state": "enforcing",
      "rule_count": 1,
      "enforcing_rule_count": 1,
      "observing_rule_count": 0,
      "enforcing_rule_names": ["block-bad-host"],
      "observing_rule_names": []
    }
  },
  {
    "content": {
      "resource_name": "observing_only",
      "rule_state": "observing_only",
      "rule_count": 1,
      "enforcing_rule_count": 0,
      "observing_rule_count": 1,
      "enforcing_rule_names": [],
      "observing_rule_names": ["common-rules-in-count"],
      "gap": "aws_wafv2_web_acl 'observing-only-waf' has 1 rule(s), all of which use count actions..."
    }
  }
]
```

## Fixtures

- `fixtures/should_match/web_acl_enforcing.tf` — Web ACL with one
  `action { block {} }` rule (positive: `enforcing`).
- `fixtures/should_not_match/web_acl_observing_only.tf` — Web ACL
  with one rule using `override_action { count {} }` on a managed
  group (negative-evidence case: `observing_only`).
