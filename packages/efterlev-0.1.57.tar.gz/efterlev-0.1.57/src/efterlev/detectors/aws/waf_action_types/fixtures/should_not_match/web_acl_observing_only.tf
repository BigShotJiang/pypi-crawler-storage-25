resource "aws_wafv2_web_acl" "observing_only" {
  name  = "observing-only-waf"
  scope = "REGIONAL"

  default_action {
    allow {}
  }

  # The canonical "managed group set to count" gap. The rule appears
  # as protection in the Web ACL listing but blocks nothing -- it
  # only logs matches. Frequently a forgotten dry-run from initial
  # rollout.
  rule {
    name     = "common-rules-in-count"
    priority = 1
    override_action {
      count {}
    }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesCommonRuleSet"
        vendor_name = "AWS"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "common-rules-in-count"
      sampled_requests_enabled   = true
    }
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "observing-only-waf"
    sampled_requests_enabled   = true
  }
}
