# aws.cna_dos_protection

Detects whether IaC-declared DoS-protection primitives are configured.
Evidences KSI-CNA-RVP "Reviewing Protections" at the configured-state
half of its `partial` classification — the procedural review cadence
("persistently review the effectiveness") is manifest territory.

Resources scanned (positive evidence):

- **`aws_wafv2_web_acl`** — modern WAF web ACL. Detector counts
  rate-based-rule statements in the ACL's `rule` blocks (a strong
  DoS-mitigation signal beyond plain managed-rule-group inclusion).
- **`aws_wafv2_web_acl_association`** — modern WAF attached to an ALB,
  CloudFront, API Gateway, or App Runner. Presence proves the WAF is
  not just declared but actually attached to traffic.
- **`aws_waf_web_acl`** — classic (v1) WAF web ACL. Legacy but still
  in use; flagged as `waf_classic_acl` so downstream agents can note
  the deprecated surface.
- **`aws_shield_protection`** — AWS Shield Advanced subscription on a
  specific resource. The premium Shield tier; the free tier is
  always-on for AWS-edge resources and isn't directly visible in IaC.

## What it proves

- **KSI-CNA-RVP (Reviewing Protections).** Configured DoS-protection
  primitives are present in the workspace.
- **SC-5 (Denial of Service Protection).** WAF + Shield are the
  AWS-native SC-5 surface at the application + edge layer.
- **SI-8 (Spam Protection).** WAF managed rule groups for anonymous-IP
  lists, bot control, etc., contribute.

## What it does NOT prove

- **The procedural review of effectiveness.** KSI-CNA-RVP's
  "persistently review" half is manifest territory — the detector
  evidences configuration, not the review cadence.
- **Rule-content correctness.** Detector counts rate-based-rule blocks
  but does not validate thresholds, scope-down statements, or rule
  ordering. Static rule-shape audit is downstream-agent work.
- **DoS protection at non-edge layers.** Shield Standard is always-on
  for ALB / CloudFront / Route 53 — the free tier is invisible in IaC.
  The detector emits only when explicit `aws_shield_protection`
  (Shield Advanced) is declared.
- **Whether the WAF is attached to anything.** The detector emits
  separate `waf_acl` (declared) and `waf_attached` (associated) evidence
  so consumers can spot dangling ACLs.

## Patterns recognized

| Resource type | Pattern | Detail field |
|---|---|---|
| `aws_wafv2_web_acl` | `waf_acl` | `rate_based_rules=N` (count of rate-based statements in the ACL's `rule` blocks) |
| `aws_wafv2_web_acl_association` | `waf_attached` | `target_arn=<arn>` (the protected resource) |
| `aws_waf_web_acl` | `waf_classic_acl` | (none) |
| `aws_shield_protection` | `shield_protection` | `target=<resource_arn or name>` |

No negative evidence is emitted. The absence of WAF/Shield isn't a gap
per se — many workspaces serve no public traffic, or use third-party
edge protection (Cloudflare, Akamai). The Gap Agent reasons about
whether the workspace's exposure justifies absent protections.

## KSI mapping

`KSI-CNA-RVP`. Mapped 800-53 controls per FRMR 0.9.43-beta:
SC-5, SI-8, SI-8(2). The detector evidences SC-5 + SI-8 at the
infrastructure layer.

## Fixtures

- `fixtures/should_match/` — `.tf` files producing positive evidence
  for each pattern.
- `fixtures/should_not_match/` — `.tf` files with no relevant
  resources (no evidence emitted).
