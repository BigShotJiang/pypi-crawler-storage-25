resource "aws_shield_protection" "alb" {
  name         = "edge-alb-shield"
  resource_arn = "arn:aws:elasticloadbalancing:us-east-1:123456789012:loadbalancer/app/edge-alb/abc123"
}
