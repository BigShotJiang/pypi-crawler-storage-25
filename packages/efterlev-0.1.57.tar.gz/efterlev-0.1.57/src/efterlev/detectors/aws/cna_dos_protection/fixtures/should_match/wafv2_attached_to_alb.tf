resource "aws_wafv2_web_acl_association" "alb_protection" {
  resource_arn = "arn:aws:elasticloadbalancing:us-east-1:123456789012:loadbalancer/app/edge-alb/abc123"
  web_acl_arn  = "arn:aws:wafv2:us-east-1:123456789012:regional/webacl/edge-acl/def456"
}
