resource "aws_waf_web_acl" "legacy" {
  name        = "legacy-acl"
  metric_name = "legacyAcl"

  default_action {
    type = "ALLOW"
  }
}
