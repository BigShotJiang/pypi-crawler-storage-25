resource "aws_api_gateway_method" "get_users_authed" {
  rest_api_id   = "api-id-placeholder"
  resource_id   = "resource-id-placeholder"
  http_method   = "GET"
  authorization = "AWS_IAM"
}
