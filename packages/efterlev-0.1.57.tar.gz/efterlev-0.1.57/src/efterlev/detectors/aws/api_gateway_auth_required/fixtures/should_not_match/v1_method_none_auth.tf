resource "aws_api_gateway_method" "get_health_public" {
  rest_api_id   = "api-id-placeholder"
  resource_id   = "resource-id-placeholder"
  http_method   = "GET"
  authorization = "NONE"
  # Public route. May be intentional (health endpoint) or a gap;
  # the Gap Agent reasons from broader prompt context.
}
