resource "aws_apigatewayv2_route" "get_orders_jwt" {
  api_id             = "v2-api-id-placeholder"
  route_key          = "GET /orders"
  authorization_type = "JWT"
  authorizer_id      = "jwt-authorizer-id-placeholder"
}
