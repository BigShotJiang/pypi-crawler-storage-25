resource "aws_rds_cluster" "aurora_prod" {
  cluster_identifier = "aurora-prod"
  engine             = "aurora-postgresql"
  storage_encrypted  = true
  kms_key_id         = "arn:aws:kms:us-east-1:123456789012:key/aurora-key"
  master_username    = "admin"
  master_password    = "PLACEHOLDER_USE_SECRETS_MANAGER"
}
