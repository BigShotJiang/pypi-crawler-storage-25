resource "aws_elasticache_replication_group" "redis" {
  replication_group_id       = "redis-prod"
  description                = "Redis prod"
  node_type                  = "cache.r6g.large"
  num_cache_clusters         = 2
  at_rest_encryption_enabled = true
  transit_encryption_enabled = true
}
