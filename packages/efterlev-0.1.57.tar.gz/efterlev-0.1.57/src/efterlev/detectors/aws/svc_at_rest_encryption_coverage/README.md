# aws.svc_at_rest_encryption_coverage

Detects whether IaC-declared encryption-at-rest is configured on data
stores **not covered by the existing per-service encryption detectors**.
The existing detectors (`aws.encryption_s3_at_rest`,
`aws.encryption_ebs`, `aws.rds_encryption_at_rest`,
`aws.sns_topic_encryption`, `aws.sqs_queue_encryption`) cover the most
common cases. This detector closes the cross-cutting gap by adding:

- **`aws_dynamodb_table`** — `server_side_encryption.enabled = true`
- **`aws_efs_file_system`** — `encrypted = true`
- **`aws_elasticache_cluster`** — `at_rest_encryption_enabled = true`
- **`aws_elasticache_replication_group`** — `at_rest_encryption_enabled = true`
- **`aws_rds_cluster`** (Aurora) — `storage_encrypted = true`
  (note: `aws.rds_encryption_at_rest` covers `aws_db_instance`; this
  detector covers the Aurora cluster shape, which uses a different
  resource type)
- **`aws_neptune_cluster`** — `storage_encrypted = true`
- **`aws_docdb_cluster`** (DocumentDB) — `storage_encrypted = true`

Emits one Evidence record per resource: positive (`configured`) or
negative (`absent` with a gap message).

## What it proves

- **KSI-SVC-PRR (Preventing Residual Risk).** Configured encryption-at-
  rest on data stores prevents residual data exposure when underlying
  storage is reused — the canonical SC-4 mechanism. Coverage is
  `partial` per the FRMR mapping: the procedural review half is
  Evidence Manifest territory.
- **SC-4 (Information in Shared System Resources).** Encryption is the
  scoped mitigation for shared-tenant block storage / managed datastore
  residual exposure.

## What it does NOT prove

- **Key management practices.** Whether the customer-managed KMS key
  has rotation enabled, BYOK isolation per workload, etc. — those
  belong to `aws.kms_key_rotation` + `aws.kms_customer_managed_keys`.
- **In-transit encryption.** TLS termination, encryption between nodes,
  internode-replication encryption — separate concerns covered by other
  detectors.
- **Whether existing data was encrypted at the time of resource
  creation.** Some services (RDS, EBS) require encryption at creation
  time; the detector evidences the declared configuration, not whether
  it was honored on the live deployment.

## Patterns recognized

| Resource | Positive condition | Detail |
|---|---|---|
| `aws_dynamodb_table` | `server_side_encryption.enabled = true` | `cmk=true` if `kms_key_arn` set |
| `aws_efs_file_system` | `encrypted = true` | `cmk=true` if `kms_key_id` set |
| `aws_elasticache_cluster` | `at_rest_encryption_enabled = true` | (none) |
| `aws_elasticache_replication_group` | `at_rest_encryption_enabled = true` | (none) |
| `aws_rds_cluster` (Aurora) | `storage_encrypted = true` | `cmk=true` if `kms_key_id` set |
| `aws_neptune_cluster` | `storage_encrypted = true` | `cmk=true` if `kms_key_arn` set |
| `aws_docdb_cluster` | `storage_encrypted = true` | `cmk=true` if `kms_key_id` set |

Negative evidence is emitted for each resource whose encryption flag
is missing or explicitly false.

## KSI mapping

`KSI-SVC-PRR` → `SC-4`. Per DECISIONS 2026-05-07 "Tier 1 #4 design",
KSI-SVC-PRR is classified `partial` — the IaC layer covers the
configured-state half (this detector); the manifest covers the
procedural review half ("persistently review … after making changes").

## Fixtures

- `fixtures/should_match/` — `.tf` files producing positive
  (`configured`) evidence for each resource type.
- `fixtures/should_not_match/` — `.tf` files producing negative
  (`absent`) evidence or no evidence (no relevant resources).
