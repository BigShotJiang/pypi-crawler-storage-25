resource "aws_efs_file_system" "scratch" {
  creation_token = "scratch-fs"
  encrypted      = false
}
