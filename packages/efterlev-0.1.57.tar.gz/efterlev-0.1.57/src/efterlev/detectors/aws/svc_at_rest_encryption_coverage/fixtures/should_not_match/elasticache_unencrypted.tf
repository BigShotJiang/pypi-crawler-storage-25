resource "aws_elasticache_cluster" "memcached" {
  cluster_id      = "memcached-cache"
  engine          = "memcached"
  node_type       = "cache.t3.small"
  num_cache_nodes = 1
  # at_rest_encryption_enabled NOT set — anti-pattern.
}
