resource "aws_iam_role" "lambda_exec" {
  name = "lambda-exec"
  assume_role_policy = "{\"Version\":\"2012-10-17\",\"Statement\":[]}"
}

resource "aws_s3_bucket" "static" {
  bucket = "static-assets-prod"
}
