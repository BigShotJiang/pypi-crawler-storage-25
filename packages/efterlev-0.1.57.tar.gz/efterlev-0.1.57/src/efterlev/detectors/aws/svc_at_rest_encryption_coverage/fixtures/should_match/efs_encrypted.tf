resource "aws_efs_file_system" "shared" {
  creation_token = "shared-fs"
  encrypted      = true
  kms_key_id     = "arn:aws:kms:us-east-1:123456789012:key/efs-key"
}
