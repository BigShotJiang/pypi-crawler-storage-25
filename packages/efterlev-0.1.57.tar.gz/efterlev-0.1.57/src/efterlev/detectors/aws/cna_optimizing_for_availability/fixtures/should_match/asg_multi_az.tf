resource "aws_autoscaling_group" "web" {
  name                = "web-asg"
  min_size            = 2
  max_size            = 10
  desired_capacity    = 2
  vpc_zone_identifier = ["subnet-aaa1111", "subnet-bbb2222", "subnet-ccc3333"]
}
