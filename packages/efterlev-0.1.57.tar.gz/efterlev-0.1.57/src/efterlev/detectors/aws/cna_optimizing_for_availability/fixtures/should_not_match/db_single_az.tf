resource "aws_db_instance" "lonely" {
  identifier        = "lonely-db"
  engine            = "postgres"
  instance_class    = "db.t3.small"
  allocated_storage = 20
  multi_az          = false
}
