resource "aws_db_instance" "primary" {
  identifier              = "app-prod"
  engine                  = "postgres"
  engine_version          = "16.4"
  instance_class          = "db.r6g.large"
  allocated_storage       = 100
  multi_az                = true
  backup_retention_period = 14
  storage_encrypted       = true
}
