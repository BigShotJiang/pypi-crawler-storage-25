resource "aws_db_instance" "replica" {
  identifier          = "app-prod-replica"
  instance_class      = "db.r6g.large"
  replicate_source_db = "app-prod"
}
