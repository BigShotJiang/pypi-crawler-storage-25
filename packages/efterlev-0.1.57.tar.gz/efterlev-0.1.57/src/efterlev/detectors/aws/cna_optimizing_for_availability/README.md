# aws.cna_optimizing_for_availability

Detects whether infrastructure declared in Terraform implements common
availability primitives — multi-AZ databases, multi-AZ autoscaling, read
replicas, S3 cross-region replication, ECS service spreading — that
contribute to KSI-CNA-OFA's "high availability and rapid recovery" outcome.

Emits one `Evidence` record per matching resource, plus negative-evidence
records for resources that ship with availability options the customer
did not enable (e.g. an `aws_db_instance` without `multi_az = true`).

## What it proves

- **KSI-CNA-OFA (Optimizing for Availability).** IaC-declared availability
  primitives are configured for the named resources. Coverage is reported
  as `partial` — this is the configured-state signal; the procedural
  half (runtime failover validation + RTO/RPO measurement + DR exercise
  cadence) is captured by the customer's Evidence Manifest.

## What it does NOT prove

- **Runtime failover behavior.** The detector reads source; it cannot
  confirm a multi-AZ database actually fails over within RTO when an AZ
  goes dark.
- **Recovery-time / recovery-point objectives.** Those are stated in a
  recovery-plan manifest (KSI-RPL-RRO / KSI-RPL-ARP), not in IaC.
- **Backup-restore validation cadence.** Adjacent KSI; covered by the
  existing `aws.backup_restore_testing` detector.
- **Cross-region disaster-recovery readiness end-to-end.** S3 cross-region
  replication is one signal; full multi-region SaaS posture requires
  more (Route53 health-checked failover, DynamoDB Global Tables, etc.).
  Future detectors can add those signals; v1 covers the common cases.

## Patterns recognized

| Resource type | Positive condition | Pattern label |
|---|---|---|
| `aws_db_instance` | `multi_az = true` | `multi_az` |
| `aws_db_instance` (replica) | `replicate_source_db` set | `read_replica` |
| `aws_rds_cluster` | `db_cluster_instance_class` + multi-AZ replicas | `multi_az` |
| `aws_autoscaling_group` | `vpc_zone_identifier` references ≥2 subnets | `asg_multi_az` |
| `aws_s3_bucket_replication_configuration` | `rule.destination` on a different region | `s3_replication` |
| `aws_ecs_service` | `placement_constraints.type = "spread"` with `expression = "attribute:ecs.availability-zone"` | `ecs_service_spread` |

A negative-evidence record is emitted for `aws_db_instance` resources
without `multi_az = true` (the most common availability-config gap on
the reference dogfood target).

## KSI mapping

`KSI-CNA-OFA` only. `KSI-CNA-OFA` has no mapped 800-53 controls in FRMR
0.9.43-beta; this detector therefore declares `controls=[]` and reports
solely at the KSI level. (The KSI's `requirement` text is the
authoritative outcome statement.)

## Example

Input:

```hcl
resource "aws_db_instance" "primary" {
  identifier     = "app-prod"
  engine         = "postgres"
  multi_az       = true
  instance_class = "db.r6g.large"
}
```

Output (one Evidence record):

```json
{
  "detector_id": "aws.cna_optimizing_for_availability",
  "ksis_evidenced": ["KSI-CNA-OFA"],
  "controls_evidenced": [],
  "source_ref": {"file": "main.tf", "line_start": 1, "line_end": 6},
  "content": {
    "resource_type": "aws_db_instance",
    "resource_name": "primary",
    "availability_state": "configured",
    "pattern": "multi_az"
  }
}
```

## Fixtures

- `fixtures/should_match/` — `.tf` files expected to produce at least one
  Evidence record with `availability_state="configured"`.
- `fixtures/should_not_match/` — `.tf` files expected to produce only
  negative-evidence records or no relevant resources.
