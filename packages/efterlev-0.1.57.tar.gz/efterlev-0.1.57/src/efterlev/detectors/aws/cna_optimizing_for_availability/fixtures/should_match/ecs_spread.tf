resource "aws_ecs_service" "api" {
  name            = "api"
  cluster         = "prod-cluster"
  task_definition = "api:42"
  desired_count   = 6

  placement_constraints {
    type       = "spread"
    expression = "attribute:ecs.availability-zone"
  }
}
