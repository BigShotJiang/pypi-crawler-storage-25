resource "aws_s3_bucket_replication_configuration" "audit_logs_replication" {
  role   = "arn:aws:iam::123456789012:role/replication-role"
  bucket = "audit-logs-prod"

  rule {
    id     = "replicate-all"
    status = "Enabled"
    destination {
      bucket        = "arn:aws:s3:::audit-logs-prod-replica-eu"
      storage_class = "STANDARD_IA"
    }
  }
}
