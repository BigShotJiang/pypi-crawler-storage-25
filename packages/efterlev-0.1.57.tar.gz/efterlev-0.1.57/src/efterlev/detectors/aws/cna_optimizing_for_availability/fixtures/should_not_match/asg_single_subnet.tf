resource "aws_autoscaling_group" "single_az" {
  name                = "single-az-asg"
  min_size            = 1
  max_size            = 3
  desired_capacity    = 1
  vpc_zone_identifier = ["subnet-only-one"]
}
