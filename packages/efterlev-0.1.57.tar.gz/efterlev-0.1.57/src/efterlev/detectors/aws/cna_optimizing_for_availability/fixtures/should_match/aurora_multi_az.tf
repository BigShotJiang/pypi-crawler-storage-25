resource "aws_rds_cluster" "aurora" {
  cluster_identifier  = "aurora-prod"
  engine              = "aurora-postgresql"
  availability_zones  = ["us-east-1a", "us-east-1b", "us-east-1c"]
  master_username     = "admin"
  master_password     = "PLACEHOLDER_USE_SECRETS_MANAGER"
}
