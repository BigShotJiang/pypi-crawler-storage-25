# aws.waf_custom_rule_groups

Cross-resource detector: walks both `aws_wafv2_web_acl` AND
`aws_wafv2_rule_group` resources. For each Web ACL, walks rules
looking for `statement.rule_group_reference_statement.arn`
references; emits per Web ACL whether any references exist.

Custom rule groups are the customer-curated complement to managed
groups — in mature WAF deployments customers ship workload-specific
rule sets that managed groups don't cover (application-specific
malicious-pattern rules, per-tenant access controls, etc.).

The `defined_rule_groups` inventory in the evidence content lists
the `aws_wafv2_rule_group` resource names found in the same
plan/repo, regardless of whether the Web ACL references them. This
lets the Gap Agent flag the **"defined but unreferenced"
anti-pattern** from the absent state — a customer with rule_group
resources defined but no Web ACL referencing them is paying for
the rule-group plumbing without the protection.

Per DECISIONS 2026-05-10 "Tier 3 #5 design", this is detector β of
the Tier 3 #5 batch — **the FINAL detector closing the WAF family
v0/v1 arc that started in v0.1.46.** **9th detector evidencing
KSI-CNA-RVP**, the most cross-resource-type-evidenced KSI in the
library by a wide margin.

## What it proves

- **KSI-CNA-RVP (Reviewing Protections).** Each Web ACL in scope
  is classified by custom-rule-group-reference presence. Coverage
  is `partial` — reference presence doesn't prove the rule group's
  rules are appropriate.
- **SI-3 (Malicious Code Protection).** Custom rule groups are the
  customer-curated complement to managed groups; both are evidenced
  on SI-3.
- **SC-7 (Boundary Protection).** Custom rule groups can encode
  workload-specific perimeter rules; widens the SC-7 evidence base
  across the WAF family to its full 3-dimensional perimeter
  coverage (geo / IP / custom).

## What it does NOT prove

- **The referenced rule group's rules are appropriate.** An empty
  rule group provides no protection; a stale legacy rule group
  provides only token coverage.
- **The rule_group_reference_statement.arn resolves to an extant
  aws_wafv2_rule_group.** Per DECISIONS Decision #3 carry-forward
  from Tier 3 #1, the detector emits literal ARN strings (typically
  Terraform interpolations like `aws_wafv2_rule_group.foo.arn`)
  and the Gap Agent handles cross-reference resolution.
- **Defined-but-unreferenced groups are intentional.** The
  inventory is surfaced via `defined_rule_groups` for the Gap
  Agent to reason about.
- **Per-Web-ACL emission, not per-rule.** Per-rule would explode
  evidence-record count.

## Patterns recognized

| Web ACL state | `rule_state` |
|---|---|
| ≥ 1 rule has `statement.rule_group_reference_statement` | `custom_rule_groups_present` |
| 0 rule_group references across all rules | `custom_rule_groups_absent` (gap surfaces `defined_rule_groups` inventory) |

The `defined_rule_groups` field is populated in BOTH states from
the global `aws_wafv2_rule_group` walk -- present so the Gap Agent
can verify the referenced ARNs match defined groups, absent so the
Gap Agent can flag "defined but unreferenced."

## KSI mapping

| KSI | Coverage | Notes |
|---|---|---|
| KSI-CNA-RVP | partial | Per-Web-ACL custom-rule-group-reference presence |

## 800-53 controls

| Control | Evidence type | Coverage |
|---|---|---|
| SI-3 | infrastructure | partial |
| SC-7 | infrastructure | partial |

## Example

Input:

```hcl
resource "aws_wafv2_rule_group" "api_specific_rules" {
  name     = "api-specific-rules"
  scope    = "REGIONAL"
  capacity = 10

  rule {
    name     = "block-deprecated-api-version"
    priority = 1
    action {
      block {}
    }
    statement {
      byte_match_statement {
        positional_constraint = "STARTS_WITH"
        search_string         = "/api/v1/"
        field_to_match { uri_path {} }
        text_transformation {
          priority = 0
          type     = "NONE"
        }
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "block-deprecated-api"
      sampled_requests_enabled   = true
    }
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "api-specific-rules"
    sampled_requests_enabled   = true
  }
}

resource "aws_wafv2_web_acl" "protected" {
  name  = "api-waf"
  scope = "REGIONAL"

  default_action { allow {} }

  rule {
    name     = "apply-custom-group"
    priority = 1
    override_action { none {} }
    statement {
      rule_group_reference_statement {
        arn = aws_wafv2_rule_group.api_specific_rules.arn
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "apply-custom-group"
      sampled_requests_enabled   = true
    }
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "api-waf"
    sampled_requests_enabled   = true
  }
}
```

Output (one Evidence record):

```json
[
  {
    "content": {
      "resource_name": "protected",
      "rule_state": "custom_rule_groups_present",
      "referenced_arn_count": 1,
      "referenced_arns": ["${aws_wafv2_rule_group.api_specific_rules.arn}"],
      "defined_rule_groups": ["api_specific_rules"]
    }
  }
]
```

## Fixtures

- `fixtures/should_match/web_acl_with_custom_group.tf` — Web ACL
  with one rule referencing an `aws_wafv2_rule_group` (positive:
  `custom_rule_groups_present`).
- `fixtures/should_not_match/web_acl_unreferenced_group.tf` — Web
  ACL with no `rule_group_reference_statement` BUT an
  `aws_wafv2_rule_group` defined in the same file. Exercises the
  "defined but unreferenced" anti-pattern that the Gap Agent
  should flag from the `defined_rule_groups` inventory.
