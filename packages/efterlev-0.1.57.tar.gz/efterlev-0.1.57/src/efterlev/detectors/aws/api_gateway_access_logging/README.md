# aws.api_gateway_access_logging

Detects whether each `aws_api_gateway_stage` (REST API v1) and
`aws_apigatewayv2_stage` (HTTP/WebSocket API v2) declares an
`access_log_settings` block. Stage-shaped evidence: one record per
stage. A single API can have multiple stages with different logging
postures (e.g., `prod` with logging enabled, `staging` without), so
per-stage granularity is what compliance audits typically ask about.

Per DECISIONS 2026-05-10 "Tier 2 #2 design: Lambda env-var KMS +
APIGW access logging", this is the second detector of the Tier 2 #2
batch — the 5th detector evidencing KSI-MLA-LET. After this batch,
KSI-MLA-LET is the most cross-resource-type-evidenced KSI in the
library, materially strengthening 3PAO conversations about
audit-record generation.

## What it proves

- **KSI-MLA-LET (Logging Event Types).** Each API Gateway stage in
  scope has a declared access-log destination. Coverage is `partial`:
  the IaC layer proves the block is configured; runtime log flow,
  destination retention, and access control on the destination are
  out of scope.
- **AU-2 (Event Logging) + AU-3 (Content of Audit Records).** The
  IaC-layer half of audit-record generation for the API Gateway
  request path. AU-3 specifically: the detector notes whether the
  `format` string is set; it does not validate the string's
  coverage of compliance-required fields (separate dimension).

## What it does NOT prove

- **Logs are actually flowing at runtime.** A declared
  `access_log_settings` block + `destination_arn` requires the API
  Gateway service-role to have permissions on the destination.
- **The destination's retention is configured per FedRAMP
  requirements.** The detector follows `destination_arn` to a string
  but doesn't dereference it to inspect the underlying
  `aws_cloudwatch_log_group` retention.
- **Access control on the destination is restrictive.** Adjacent
  dimension; covered by `aws.mla_log_access_least_privilege` for
  CloudWatch Logs destinations.
- **The format string captures compliance-required fields.**
  `$context.requestId` alone is minimally useful; full request /
  response capture requires more `$context` fields. Detector reports
  format-presence (boolean) but doesn't parse the string.
- **API-level posture.** The detector emits per-stage; an
  `aws_api_gateway_rest_api` resource alone with no stages is invisible
  here. That's by design — stages are where logging actually attaches.

## Patterns recognized

| Resource type | `access_log_settings` block | `logging_state` |
|---|---|---|
| `aws_api_gateway_stage` (v1) | present | `configured` |
| `aws_api_gateway_stage` (v1) | absent | `absent` (gap) |
| `aws_apigatewayv2_stage` (v2) | present | `configured` |
| `aws_apigatewayv2_stage` (v2) | absent | `absent` (gap) |

The detector does NOT inspect `destination_arn` for validity at scan
time. `destination_arn` is almost always a Terraform reference like
`aws_cloudwatch_log_group.x.arn`; treating that as `unverifiable`
would force every real-world resource into an unhelpful state.
Block-presence is the binary signal.

## KSI mapping

| KSI | Coverage | Notes |
|---|---|---|
| KSI-MLA-LET | partial | IaC-declared per-stage access-log destination |

## 800-53 controls

| Control | Evidence type | Coverage |
|---|---|---|
| AU-2 | infrastructure | partial |
| AU-3 | infrastructure | partial |

## Example

Input:

```hcl
resource "aws_api_gateway_stage" "prod" {
  rest_api_id   = aws_api_gateway_rest_api.public.id
  deployment_id = aws_api_gateway_deployment.prod.id
  stage_name    = "prod"

  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_logs.arn
    format          = "$context.requestId $context.identity.sourceIp $context.httpMethod $context.resourcePath"
  }
}

resource "aws_api_gateway_stage" "staging" {
  rest_api_id   = aws_api_gateway_rest_api.public.id
  deployment_id = aws_api_gateway_deployment.staging.id
  stage_name    = "staging"
  # No access_log_settings — the gap.
}
```

Output (two Evidence records):

```json
[
  {
    "content": {
      "resource_type": "aws_api_gateway_stage",
      "resource_name": "prod",
      "stage_name": "prod",
      "logging_state": "configured",
      "pattern": "rest_api_v1_stage_access_logs",
      "destination_arn": "${aws_cloudwatch_log_group.api_logs.arn}",
      "format_present": true,
      "detail": "stage_name=prod; access_log_settings declared"
    }
  },
  {
    "content": {
      "resource_type": "aws_api_gateway_stage",
      "resource_name": "staging",
      "stage_name": "staging",
      "logging_state": "absent",
      "pattern": "rest_api_v1_stage_access_logs",
      "gap": "aws_api_gateway_stage 'staging' has no access_log_settings block; the request-path audit trail at this stage is blind unless the backend (typically Lambda) logs request metadata itself"
    }
  }
]
```

## Fixtures

- `fixtures/should_match/v1_stage_with_logs.tf` — REST v1 stage with
  `access_log_settings` block (positive).
- `fixtures/should_match/v2_stage_with_logs.tf` — HTTP v2 stage with
  `access_log_settings` block (positive).
- `fixtures/should_not_match/v1_stage_without_logs.tf` — REST v1
  stage with no `access_log_settings` (negative-evidence case).
