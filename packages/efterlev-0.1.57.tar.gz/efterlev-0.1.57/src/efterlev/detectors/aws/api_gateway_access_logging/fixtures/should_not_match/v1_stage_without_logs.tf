resource "aws_api_gateway_stage" "staging" {
  rest_api_id   = "api-id-placeholder"
  deployment_id = "deployment-id-placeholder"
  stage_name    = "staging"
  # No access_log_settings block -- the gap.
}
