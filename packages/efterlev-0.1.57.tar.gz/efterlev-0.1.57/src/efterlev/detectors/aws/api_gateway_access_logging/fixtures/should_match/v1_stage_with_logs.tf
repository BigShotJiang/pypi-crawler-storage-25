resource "aws_api_gateway_stage" "prod" {
  rest_api_id   = "api-id-placeholder"
  deployment_id = "deployment-id-placeholder"
  stage_name    = "prod"

  access_log_settings {
    destination_arn = "arn:aws:logs:us-east-1:123456789012:log-group:/aws/apigateway/prod"
    format          = "$context.requestId $context.identity.sourceIp $context.httpMethod $context.resourcePath $context.status $context.responseLength"
  }
}
