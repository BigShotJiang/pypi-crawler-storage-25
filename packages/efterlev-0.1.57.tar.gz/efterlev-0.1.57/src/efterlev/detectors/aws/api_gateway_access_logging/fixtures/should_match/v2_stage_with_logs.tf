resource "aws_apigatewayv2_stage" "prod_v2" {
  api_id      = "v2-api-id-placeholder"
  name        = "prod"
  auto_deploy = true

  access_log_settings {
    destination_arn = "arn:aws:logs:us-east-1:123456789012:log-group:/aws/apigateway/prod-v2"
    format          = "$context.requestId $context.identity.sourceIp $context.httpMethod $context.routeKey $context.status"
  }
}
