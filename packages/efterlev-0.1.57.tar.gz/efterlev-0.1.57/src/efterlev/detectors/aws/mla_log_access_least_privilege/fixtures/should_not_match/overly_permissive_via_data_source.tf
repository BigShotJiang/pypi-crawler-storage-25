data "aws_iam_policy_document" "log_admin_doc" {
  statement {
    effect    = "Allow"
    actions   = ["logs:*"]
    resources = ["*"]
  }
}

resource "aws_iam_policy" "log_admin_via_doc" {
  name   = "log-admin-via-doc"
  policy = data.aws_iam_policy_document.log_admin_doc.json
}
