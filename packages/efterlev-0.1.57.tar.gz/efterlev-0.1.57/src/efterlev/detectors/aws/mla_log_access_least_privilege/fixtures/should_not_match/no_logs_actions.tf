resource "aws_iam_policy" "s3_only" {
  name = "s3-only"
  policy = <<-EOT
    {
      "Version": "2012-10-17",
      "Statement": [
        {
          "Effect": "Allow",
          "Action": ["s3:GetObject", "s3:ListBucket"],
          "Resource": "arn:aws:s3:::my-bucket/*"
        }
      ]
    }
  EOT
}

resource "aws_iam_role" "lambda_exec" {
  name = "lambda-exec"
  assume_role_policy = <<-EOT
    {
      "Version": "2012-10-17",
      "Statement": [
        {
          "Effect": "Allow",
          "Principal": {"Service": "lambda.amazonaws.com"},
          "Action": "sts:AssumeRole"
        }
      ]
    }
  EOT
}
