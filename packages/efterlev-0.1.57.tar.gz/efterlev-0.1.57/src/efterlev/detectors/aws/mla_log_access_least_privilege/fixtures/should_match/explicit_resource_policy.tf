resource "aws_cloudwatch_log_resource_policy" "audit_logs_writer" {
  policy_name = "audit-logs-writer"
  policy_document = <<-EOT
    {
      "Version": "2012-10-17",
      "Statement": [
        {
          "Sid": "AllowAuditWrite",
          "Effect": "Allow",
          "Principal": {"Service": "audit.example.com"},
          "Action": [
            "logs:CreateLogStream",
            "logs:PutLogEvents"
          ],
          "Resource": "arn:aws:logs:us-east-1:123456789012:log-group:audit/*"
        }
      ]
    }
  EOT
}
