resource "aws_iam_policy" "log_admin" {
  name        = "log-admin"
  description = "Anti-pattern: wildcard logs access on all resources."
  policy = <<-EOT
    {
      "Version": "2012-10-17",
      "Statement": [
        {
          "Effect": "Allow",
          "Action": "logs:*",
          "Resource": "*"
        }
      ]
    }
  EOT
}
