data "aws_iam_policy_document" "log_reader_doc" {
  statement {
    effect    = "Allow"
    actions   = ["logs:GetLogEvents", "logs:FilterLogEvents"]
    resources = ["arn:aws:logs:us-east-1:123456789012:log-group:app-prod"]
  }
}

resource "aws_iam_policy" "log_reader" {
  name   = "log-reader"
  policy = data.aws_iam_policy_document.log_reader_doc.json
}
