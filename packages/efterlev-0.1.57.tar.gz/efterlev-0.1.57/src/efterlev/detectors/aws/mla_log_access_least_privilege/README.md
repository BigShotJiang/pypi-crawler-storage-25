# aws.mla_log_access_least_privilege

Detects whether IaC-declared access to log data follows least-privilege
patterns. Looks at two surfaces:

1. **Resource policies on CloudWatch Logs** —
   `aws_cloudwatch_log_resource_policy` resources declare who can write
   to (and read from) specific log groups. Their existence is positive
   signal: an admin has explicitly governed log-data access.
2. **IAM policies that include `logs:*` actions** — `aws_iam_policy`,
   `aws_iam_role_policy`, `aws_iam_user_policy`, `aws_iam_group_policy`
   resources whose policy document contains any action starting with
   `logs:`. The detector classifies each such policy as:
   - `scoped` — the `Resource` field is a specific log group / log
     stream ARN, not a wildcard.
   - `overly_permissive` — `Resource: "*"` paired with a wildcard
     `logs:*` action grants unrestricted log access.
   - `unparseable` — the policy is composed via `jsonencode(...)` or a
     non-resolvable `data.aws_iam_policy_document.*.json` reference,
     so static analysis can't determine the scope.

## What it proves

- **KSI-MLA-ALA (Authorizing Log Access).** Configured least-privilege
  boundary on log access (positive); or the absence thereof (negative).
- **AC-3 (Access Enforcement)** — IAM policy grants govern access to
  log data.
- **AC-6 (Least Privilege)** — overly-permissive `logs:*` with
  `Resource: "*"` is an anti-pattern.

## What it does NOT prove

- **Runtime authorization decisions.** The detector reads source; it
  cannot confirm a deployed principal actually exercises the policy
  within the declared scope.
- **Just-in-time cadence.** KSI-MLA-ALA mentions "just-in-time access
  authorization model" — that's a procedural review covered by the
  Evidence Manifest for this KSI.
- **Attribute-based access** beyond what the static `Condition` block
  expresses. ABAC tags resolved at runtime (e.g., session tags) aren't
  visible in IaC.
- **Whether the log-receiving destination is appropriately scoped.**
  This detector looks at access GRANTS; it doesn't audit the destination
  resources themselves (CloudWatch Log Group retention is the
  `centralized_log_aggregation` detector's territory).

## Patterns recognized

| Resource type | Positive condition | Pattern |
|---|---|---|
| `aws_cloudwatch_log_resource_policy` | resource exists | `explicit_resource_policy` |
| `aws_iam_policy` (and inline variants) | policy doc has `logs:` action with specific Resource ARN | `iam_policy_with_logs_actions` (`scoped`) |
| `aws_iam_policy` (and inline variants) | policy doc has `logs:*` with `Resource: "*"` | `iam_policy_with_logs_actions` (`overly_permissive`) |

IAM policies with no `logs:` actions are ignored — they're not relevant
to this KSI.

## KSI mapping

`KSI-MLA-ALA`. Mapped 800-53 controls: AC-3 (Access Enforcement) and
AC-6 (Least Privilege). FRMR 0.9.43-beta lists `si-11` for KSI-MLA-ALA;
SI-11 is "Error Handling" which is loosely related (error-message
exposure to non-privileged users) but the detector evidences AC-3 +
AC-6 directly because those are what the configured policy mechanism
implements. Honest mapping per DECISIONS 2026-04-21 (design call #1).

## Example

Input (overly-permissive case):

```hcl
resource "aws_iam_policy" "log_admin" {
  name = "log-admin"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "logs:*"
      Resource = "*"
    }]
  })
}
```

Output:

```json
{
  "detector_id": "aws.mla_log_access_least_privilege",
  "ksis_evidenced": ["KSI-MLA-ALA"],
  "controls_evidenced": ["AC-3", "AC-6"],
  "content": {
    "resource_type": "aws_iam_policy",
    "resource_name": "log_admin",
    "log_access_state": "overly_permissive",
    "pattern": "iam_policy_with_logs_actions",
    "gap": "policy grants `logs:*` on Resource: '*' (no scoping)"
  }
}
```

## Fixtures

- `fixtures/should_match/` — `.tf` files producing positive (`configured`
  or `scoped`) evidence.
- `fixtures/should_not_match/` — `.tf` files producing `overly_permissive`
  evidence or no evidence (no log-touching IAM policies + no resource
  policies).
