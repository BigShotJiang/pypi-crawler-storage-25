resource "aws_iam_policy" "audit_log_reader" {
  name        = "audit-log-reader"
  description = "Read access to audit log group only."
  policy = <<-EOT
    {
      "Version": "2012-10-17",
      "Statement": [
        {
          "Effect": "Allow",
          "Action": [
            "logs:GetLogEvents",
            "logs:FilterLogEvents",
            "logs:DescribeLogStreams"
          ],
          "Resource": "arn:aws:logs:us-east-1:123456789012:log-group:audit/*"
        }
      ]
    }
  EOT
}
