# Repo-scoped slash commands

Repo-scoped slash commands for Efterlev's recurring multi-file
workflows. Each is a prompt template that compresses a known ritual
into one invocation.

These were added per DECISIONS 2026-05-07 "Process improvements
from v0.1.22-v0.1.27 cascade" follow-up + the Anthropic internal
"How teams use Claude Code" report (Security Engineering's
50%-of-monorepo-slash-commands pattern).

## Available commands

| Command | When to use |
|---|---|
| `/ship-detector <slug> <KSI-ID>` | Ship a new detector PR end-to-end (folder scaffold → tests → register → bump counts → version → docs → CHANGELOG → commit → push → PR). Compresses the 15-file ritual we did 6 times across v0.1.28–v0.1.34. |
| `/release-housekeeping <new-version>` | Bump `__version__` + sweep all version refs across CLAUDE.md / README.md / LIMITATIONS.md / docs / scripts. For hotfix patches and follow-on releases that DON'T add a detector. **Stops at PR open** — chain into `/release-finalize` for the rest. |
| `/release-finalize <pr-number>` | Take over from `/release-housekeeping` after the PR is open: watch CI → squash-merge → sign tag → push tag → verify auto-triage T1-T6. Handles transient release-container reruns (Docker Hub OAuth flakes). Codifies the v0.1.37/38/39 release-cycle ritual. |
| `/validation-prompt <version>` | Generate a paste-ready tester-validation prompt for the given version. Reads the CHANGELOG block, maps each Fixed/Added entry to a PASS/FAIL scenario, emits S0 baseline + per-fix scenarios + structured report format. Narrow re-validation (~10 min, ~$0); not a substitute for the full deep-test session. **Use when the tester is on a different machine OR when fresh-eyes human judgment matters.** |
| `/validate-locally <version>` | Same scenario shapes as `/validation-prompt`, but executes them via a general-purpose subagent on THIS machine and returns the PASS/FAIL table inline (no clipboard handoff). **Default for patch-release re-validation** when the dev box has the relevant credentials. ~5 min round-trip, ~$0.10–0.30 of LLM cost. Falls back to `/validation-prompt` for major-version cuts where human judgment catches surprises a checklist would miss. |
| `/check-state` | Quick repo-state snapshot — version, tests, detector count, KSI coverage, recent releases, latest auto-triage status. Useful at session start. |
| `/decisions-entry <title>` | Draft a DECISIONS.md entry in Efterlev's standard shape. Surfaces the entry as its own PR per the working agreement (design surfaces BEFORE implementation). |

## Scope notes

- These are **repo-scoped** (`.claude/commands/`), not user-scoped
  (`~/.claude/commands/`), so contributors get them automatically
  on `git clone`. No per-developer install required.
- Each command's prompt explicitly references CLAUDE.md sections
  + the working agreement so a future Claude Code session uses the
  same conventions even if the agent hasn't loaded the full
  context yet.
- They are **templates, not automation** — every step is a real
  human decision the agent walks through. The compression is in
  the recipe knowledge, not in skipping verification gates.

## When to add a new command

Add one when:
1. You've done the same multi-step workflow ≥3 times.
2. The recipe has stable shape across invocations (only a few
   parameters change).
3. The cost of forgetting a step is high (e.g. silent doc drift,
   broken release matrix).

Don't add one when:
1. The work is exploratory (every invocation needs different shape).
2. The work is a single-file edit (no compression value).
3. There's already a script for it (e.g. `scripts/triage.sh`).

## Conventions

- File name = command name (e.g. `ship-detector.md` → `/ship-detector`).
- Frontmatter `description:` shows in the slash-command picker.
- `$ARGUMENTS` placeholder receives the user-typed args.
- Reference CLAUDE.md sections by header so contributors can
  navigate to the canonical text.
