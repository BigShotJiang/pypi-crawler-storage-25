---
description: Finalize a release after the PR is open — watch CI, squash-merge when green, tag, push tag, verify auto-triage T1-T6, handle transient-flake reruns. Composes with `/release-housekeeping` (which opens the PR); this command takes over from there.
---

You are finalizing a release for Efterlev. The user invoked
`/release-finalize $ARGUMENTS` where `$ARGUMENTS` is the PR number
(e.g. `173`). If `$ARGUMENTS` is empty, infer it from the current
branch with `gh pr view --json number --jq .number`.

This command is the post-PR half of the release cycle.
`/release-housekeeping` covers branch → version bump → drift sweep →
CHANGELOG → commit → push → PR. This command covers what comes after:
watch CI → merge → tag → verify auto-triage. The split exists so the
user can review the PR diff between the two phases.

## Working agreement (non-negotiable, from CLAUDE.md)

- **GHA minutes are constrained** (90% of cap as of 2026-04-28). Don't
  rerun workflows speculatively. Rerun only when CI fails on a
  documented transient-flake class (Docker Hub OAuth resets, slow Mac
  runner timeouts).
- **Never push to main directly.** Strict ruleset blocks it; merge via
  `gh pr merge --squash`.
- **Sign every tag.** `git tag -s` is mandatory for the release-verify
  cosign chain.

## The 7-step ritual

### 1. Resolve PR + version

```bash
PR=${ARGUMENTS:-$(gh pr view --json number --jq .number)}
VERSION=$(grep '^__version__' src/efterlev/__init__.py | sed -E 's/.*"([^"]+)".*/\1/')
echo "PR #$PR → v$VERSION"
```

Confirm the PR's branch matches the version you're tagging — a
mismatch means `/release-housekeeping` was run on the wrong branch.

### 2. Watch CI until green (or fail loudly)

```bash
gh pr checks $PR
```

If anything is `pending` or `in_progress`, schedule a wakeup at
1200s (20 min — past CI's typical settle time, single cache miss is
acceptable). Don't poll faster than 270s — see CLAUDE.md's "Don't
pick 300s" rule on cache TTL.

If anything is `failure`, STOP. Triage the failure:
- Transient infra (Docker Hub OAuth, npm registry timeout, slow runner
  timeout): re-run with `gh run rerun <run-id> --failed`. ONE retry
  only — if it fails twice it's not transient.
- Real bug: comment on the PR, do not auto-resolve. The user investigates.

### 3. Squash-merge with branch deletion

```bash
gh pr merge $PR --squash --delete-branch
git checkout main
git pull --ff-only
git log --oneline -3   # verify the squash commit landed at HEAD
```

The squash title becomes the release commit message — should already
be set correctly by `/release-housekeeping` (the PR title becomes the
default squash title in `gh pr merge --squash` mode).

### 4. Sign + push the tag

```bash
git tag -s "v$VERSION" -m "v$VERSION: <one-line summary from CHANGELOG>"
git push origin "v$VERSION"
```

Pull the one-line summary from the top of CHANGELOG.md's v$VERSION
block. Don't invent one.

### 5. Verify the release workflows fire

The tag push triggers `release-pypi.yml`, `release-container.yml`, and
`release-smoke.yml`. Confirm all three started:

```bash
sleep 5  # let GH register the trigger
gh run list --branch "v$VERSION" --limit 6
```

Expected: `release-pypi` + `release-container` `in_progress`,
`release-smoke` `queued`. If any didn't fire, check the workflow
trigger config — most commonly a missing `tags: ['v*']` on the
workflow file.

### 6. Wait for the auto-triage report

`scripts/triage.sh` runs via `.github/workflows/post-release-triage.yml`
on `workflow_run` after release-pypi / release-container settle (~6 min
for both). T1–T7 land in the GH Release notes body.

```bash
# Schedule a wakeup at 1800s (30 min — covers release-pypi ~5min +
# release-container ~8min + release-smoke matrix ~12min + triage ~5min).
# When you wake, fetch and inspect:
gh release view "v$VERSION" --json body --jq '.body' | head -25
```

Expected on a clean release: T1–T6 ✅, T7 ⏳ pending (release-smoke
matrix waits on slow Mac runners). T7 is non-blocking — it flips
green when the runner queue catches up; the release itself is
shipped.

### 7. Handle transient release-container failures

The release-container workflow occasionally fails on Docker Hub OAuth
flakes (`failed to fetch oauth token: ... connection reset by peer`).
This is pure infrastructure noise, not a code issue — observed on
v0.1.39 (2026-05-08). One rerun is acceptable:

```bash
# If release-container failed:
RUN_ID=$(gh run list --workflow=release-container.yml --branch "v$VERSION" \
  --json databaseId --jq '.[0].databaseId')
gh run view $RUN_ID --log-failed | tail -30   # confirm Docker Hub OAuth flake
gh run rerun $RUN_ID --failed
```

After the rerun completes, the post-release-triage workflow auto-fires
again and updates the Release notes body. T1–T6 should flip to PASS.

## Failure modes to watch for

- **PyPI propagation delay vs triage timing.** post-release-triage may
  fire before PyPI's CDN propagates the new version. Manifests as
  T1 FAIL with "No matching distribution found." Wait 5 min, then
  trigger a triage rerun: `gh workflow run post-release-triage.yml`.
- **release-smoke matrix hung > 1 hour.** Slow Mac runners (Intel
  macos-13 especially) sometimes queue for 30+ min. Non-blocking. T7
  will eventually flip; don't gate the rest of the release on it.
- **Tag signing fails.** Most commonly a GPG passphrase prompt issue.
  `git config --global commit.gpgsign true` may be set but the agent
  is locked. Run `gpg --sign /tmp/test` to wake the agent, then retry.

## When NOT to use this command

- **PR not yet open.** Run `/release-housekeeping <version>` first to
  create the branch, bump, and open the PR.
- **Detector PR.** `/ship-detector` already orchestrates the full
  release cycle including post-PR steps. Don't run this on top of it.

## Reminders

- DCO required on every commit (already enforced by `/release-housekeeping`).
- Tag MUST be signed (`-s`).
- Don't rerun workflows more than once. If two reruns fail, it's a
  real bug.
- The release is "shipped" when T1–T6 PASS in the auto-triage report.
  T7 (release-smoke matrix) being pending is expected — don't block on it.
