---
description: Ship a new detector PR end-to-end (folder scaffold → tests → register → bump counts → version → docs → CHANGELOG → commit → push → PR).
---

You are shipping a new detector for Efterlev. The user invoked
`/ship-detector $ARGUMENTS` where `$ARGUMENTS` is typically the
detector slug + KSI ID (e.g. `aws.cna_ipv6_egress KSI-CNA-EIS`) or a
loose description if they want to discuss before scaffolding.

## Working agreement (non-negotiable, from CLAUDE.md)

1. **DECISIONS entry first.** If the new detector isn't already
   covered by an existing DECISIONS entry (e.g. it wasn't on the
   Tier 1 #4 backlog), STOP and surface a DECISIONS-entry-only PR
   for review BEFORE implementation. Per the working agreement
   (DECISIONS 2026-05-06): "each Tier X item lands as its own PR
   with its own DECISIONS entry surfaced for review *before*
   implementation starts."
2. **Branch from main.** Always `git fetch origin main && git
   checkout main && git pull --ff-only` first, then
   `git checkout -b detector/<slug>`.
3. **DCO required.** Every commit ends with `--signoff`.
4. **Per-fix regression-test discipline.** Tests must fail without
   the detector and pass with it.

## The 15-step ritual

Walk through these in order. Don't skip anything; every step
matters and each is a real PR you've shipped before (v0.1.28-v0.1.34).

### 1. Confirm scope

- Detector slug (e.g. `aws.cna_ipv6_egress` or `github.foo_bar`)
- Source category (`terraform` for `aws.*`, `github-workflows` for `github.*`)
- KSI ID being evidenced (must exist in `catalogs/frmr/FRMR.documentation.json`)
- 800-53 controls list (check FRMR `controls` field for the KSI; if
  empty, use `controls=[]` per DECISIONS 2026-04-21 / 2026-05-07
  precedent — the decorator allows ksis non-empty + controls empty)
- Resources to scan
- Coverage classification: `evidenceable-via-iac` vs `partial`

If any of these are unclear, ASK before scaffolding.

### 2. Branch off main

```bash
git fetch origin main && git checkout main && git pull --ff-only
git checkout -b detector/<slug-with-hyphens>
mkdir -p src/efterlev/detectors/<cloud>/<slug>/fixtures/should_match
mkdir -p src/efterlev/detectors/<cloud>/<slug>/fixtures/should_not_match
```

### 3. Scaffold the 5-file folder

Reference an existing detector that's structurally similar
(e.g. `src/efterlev/detectors/aws/cna_optimizing_for_availability/`
for an IaC detector with positive + negative emission, or
`src/efterlev/detectors/github/piy_sdlc_security_gates/` for a
github-workflows detector). Files to create:

- `__init__.py` — one-line package marker that imports `detector`
  to register via the `@detector` decorator.
- `mapping.yaml` — KSI + controls + per-mapping coverage notes.
- `evidence.yaml` — declared evidence_shape (resource_type,
  resource_name, state enum, pattern enum, optional detail/gap).
- `README.md` — what it proves / what it does NOT prove / patterns
  table / KSI mapping / fixtures section.
- `detector.py` — the `@detector(...)`-decorated function.

### 4. Write the detector

Pattern: a top-level `detect(resources)` for terraform detectors or
`detect(workflows)` for github-workflows detectors. One Evidence
record per matching resource. Use `Evidence.create(...)` with
`detector_id`, `ksis_evidenced`, `controls_evidenced`,
`source_ref=r.source_ref`, `content={...}`, `timestamp=now`.

Decide upfront: positive-only (like `aws.cna_dos_protection` or
`aws.rpl_backup_configured`) vs positive+negative (like
`aws.cna_optimizing_for_availability`). Document the decision in
the docstring + lock it with a contract test.

### 5. Write fixtures

- `fixtures/should_match/*.tf` (or `*.yml` for github) — files
  expected to produce positive evidence
- `fixtures/should_not_match/*.tf` — files producing negative
  evidence OR no evidence

For Terraform fixtures, prefer **heredoc** (`<<-EOT ... EOT`) for any
JSON-in-string content. Backslash-escaped quotes inside HCL strings
break python-hcl2 parsing — the v0.1.30 detector hit this; fixtures
were rewritten as heredocs.

### 6. Write the test file

`tests/detectors/test_<source>_<slug>.py`. Pattern: one test per
fixture + 2-3 contract pin tests:

- `test_detector_declares_expected_mappings` — pins ksis + controls
- `test_detector_emits_only_documented_states` — locks the state enum
- `test_detector_emits_only_documented_patterns` — locks the pattern enum

Look at `tests/detectors/test_aws_cna_optimizing_for_availability.py`
for the canonical shape.

### 7. Register in detectors/__init__.py

Add the import line in alphabetical position. The whole module is
imported at scan time; missing the registration silently leaves the
detector out.

### 8. uv pip install -e . + run new tests

```bash
uv pip install -e . --reinstall --quiet
uv run pytest tests/detectors/test_<source>_<slug>.py -v
```

All new tests should pass. If any fail, iterate the detector +
fixtures until green.

### 9. Bump EXPECTED_DETECTORS in scripts/triage.sh

The v0.1.29 source-level pin
(`tests/test_triage_constant_alignment.py`) will fire if you don't.
Bump to current count (= prior count + 1).

### 10. Bump count assertions in tests/test_cli.py

`test_detectors_list_lists_all_thirty_detectors` has hardcoded
`total: N detectors` and `M KSI-mapped`. Bump both. Update the
inline comment to name the new detector + version.

### 11. Bump __version__ in src/efterlev/__init__.py

Patch bump (e.g. 0.1.34 → 0.1.35).

### 12. Run check-docs.py + fix all drift

```bash
uv run python scripts/check-docs.py
```

Will surface ~6-8 drift items: README.md test count, source file
count, detector count, plus version refs in CLAUDE.md, README.md,
LIMITATIONS.md, docs/index.md, scripts/verify-release.sh,
docs/quickstart.md. Fix every one.

The "Status:" paragraph in README.md and the CLAUDE.md Coverage
block also need narrative updates if KSI coverage moved.

### 13. Write CHANGELOG entry

Top of CHANGELOG.md, above the previous version. Use the
v0.1.28-v0.1.34 entries as templates. Sections to include:
- Added (the detector + fixture/test count)
- Changed (test_cli.py + triage.sh count bumps; cite the v0.1.29
  pin if it caught the drift)
- Internal (test count delta, detector count delta, KSI coverage
  delta, source files delta)
- Cross-references (DECISIONS entry that authorized this detector;
  remaining-backlog count if we're in a tracked sequence)

### 14. Final gates (all must be clean)

```bash
uv run python scripts/check-docs.py 2>&1 | tail -3
uv run pytest -m "not e2e" -q 2>&1 | tail -3
uv run ruff check src tests scripts 2>&1 | tail -2
uv run ruff format src tests scripts 2>&1 | tail -2
uv run mypy 2>&1 | tail -2
```

Expected output:
- check-docs: `RESULT: clean. No doc-vs-code drift.`
- pytest: all pass (count = prior count + new tests added)
- ruff: `All checks passed!`
- ruff format: existing files only
- mypy: `Success: no issues found in N source files`

If `tests/test_smoke.py::test_in_source_version_matches_package_metadata`
fails, run `uv pip install -e . --reinstall --quiet` to refresh the
installed package metadata after the version bump.

### 15. Commit + push + open PR

```bash
git add -A
git commit --signoff -m "$(cat <<'EOF'
v0.1.NN: <detector.slug> (Tier X #Y detector #Z)

<one-paragraph what + why>

<bullet on positive-only or positive+negative emission>

<bullet on no-overlap with existing detectors if relevant>

N fixtures + M unit tests covering ... + contract pins.

Counts: tests A → B, detectors C → D, KSI-mapped E → F,
KSIs covered G → H, source files I → J.

The v0.1.29 source-level pin caught the EXPECTED_DETECTORS
drift at PR time (... release in a row).

K detectors remain on the [tracked backlog if any].

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
git push -u origin detector/<slug>
gh pr create --title "v0.1.NN: <detector.slug> (Tier X #Y detector #Z)" --body "..."
```

PR body uses the same template structure. Include:
- Summary
- What it detects (table)
- Coverage progression table
- Test plan checklist
- Cross-references

After PR opens, watch CI. E2E typically takes 5-7 min. If it fails
on Anthropic 529, retry per the established pattern.

## When NOT to use this command

- If the detector requires a NEW design discussion (not already
  covered by DECISIONS) — stop and write the DECISIONS entry first.
- If the detector adds a new source category beyond `terraform` and
  `github-workflows` — needs primitive-layer + scan-flow changes
  outside this slash command's scope.
- If the detector requires a new shared parser (e.g. third
  IAM-policy-content reader — refactor `efterlev.iam.policy_doc`
  helper before continuing).

## Important reminders

- **Never commit** files containing secrets (`.env`, credentials).
- **Never push to main** — every release goes through a PR.
- **Don't bypass the EXPECTED_DETECTORS lock** — if it fires, that's
  the v0.1.29 pin doing its job.
- **Watch for ruff + format clean** — PLW1514 enforces explicit
  encoding= on every file open (v0.1.27+).
- **Surface design questions before implementing** — if you're
  uncertain about the KSI mapping or controls, ASK.
