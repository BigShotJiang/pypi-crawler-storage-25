---
description: Draft a DECISIONS.md entry in Efterlev's standard shape (Context / Decision / Rationale / Alternatives / Cross-references). Surfaces the entry as its own PR per the working agreement (design surfaces BEFORE implementation).
---

You are drafting a DECISIONS.md entry. The user invoked
`/decisions-entry $ARGUMENTS` where `$ARGUMENTS` is the entry title
(e.g. `Tier 2 #1 design: cross-platform PR-time CI gate`).

## Working agreement (non-negotiable, from CLAUDE.md)

Per DECISIONS 2026-05-06: "each Tier X item lands as its own PR
with its own DECISIONS entry surfaced for review *before*
implementation starts." This command's output is a DECISIONS-only
PR. NO implementation should ride along — that's a separate PR
after this one is reviewed and merged.

## Standard entry shape

Read the latest few entries (e.g. `tail -200 DECISIONS.md`) to
match the established voice and structure. The standard sections:

```markdown
## YYYY-MM-DD — <title> `[tag1]` `[tag2]`

**Context:**

<2-4 paragraphs setting up the problem. Include:
- What surfaced this question (a release, a finding, a design gap)
- What's already been tried or assumed
- Why this needs a written-down decision now>

**Decision:**

<The actual decision, as concretely as possible. If multi-part, use
numbered sub-decisions. Lock specifics — file paths, config keys,
test names — so a contributor can implement against this entry
without re-deriving everything.>

**Rationale:**

<Bullet list. Each bullet starts with the "because" half of the
decision; the "what" is in the Decision section above. Cross-
reference relevant CLAUDE.md sections, prior DECISIONS entries,
or external standards (FedRAMP 20x, FRMR, NIST 800-53).>

- ...
- ...

**Alternatives considered:**

<Bullet list. Each alternative starts with the alternative shape +
the verb-led reason it was rejected. Be specific — "rejected because
foo" not "considered but not chosen".>

- **<Alt 1>** — <why rejected>.
- **<Alt 2>** — <why rejected>.
- **<Alt 3>** — <why rejected>.

**Scope of <release version> (what ships):**  [optional — for design entries that translate to a code PR]

- File or test name — short description of the change.

**Cross-references:**

- Link to prior DECISIONS entries this depends on.
- Link to CLAUDE.md sections that codify the decision pattern.
- External docs (FedRAMP RFC, FRMR catalog version, NIST control IDs).
- GitHub Actions runs / release pages if this is a follow-on of an
  observed failure.
```

## Tag conventions

Tags go in backticks at the title line. Common tags from the
existing entries:

- `[scope]` — what's in vs out
- `[architecture]` — structural / design
- `[positioning]` — product positioning / market
- `[content]` — manifest templates, KSI catalog work
- `[infrastructure]` — CI, release pipeline, repo plumbing
- `[observability]` — logging, monitoring, telemetry
- `[testing]` — test discipline, regression policy
- `[process]` — workflow, working agreement
- `[security]` — supply chain, signing, secrets
- `[ux]` — CLI ergonomics, output shaping
- `[product-bug]` — runtime/install behavior fixes
- `[detectors]` — detector contracts + behavior

Pick 2-3 tags that genuinely apply.

## The 5-step ritual

### 1. Confirm scope with the user

Before drafting, confirm:
- Title (maybe refine `$ARGUMENTS`)
- Which Tier this belongs to (Tier 1 / Tier 2 / Tier 3 / unscheduled)
- Whether there's a parent DECISIONS entry this depends on
- Roughly how many alternatives the user has been weighing

If the user hasn't said, ASK before drafting. The DECISIONS entry
is supposed to capture a decision the user has converged on — not
proposing options for them to pick from.

### 2. Branch off main

```bash
git fetch origin main && git checkout main && git pull --ff-only
git checkout -b design/<short-slug>
```

### 3. Draft the entry

Append to DECISIONS.md, just above the trailing
`## YYYY-MM-DD — Short decision summary` template line. Use today's
date in the title.

The Edit tool's preferred approach: insert the new entry between
the prior `## ...` block and the trailing template. The template
line at the end of DECISIONS.md is a placeholder — leave it
untouched (it's the canonical shape for future entries).

### 4. Run check-docs to confirm clean

```bash
uv run python scripts/check-docs.py 2>&1 | tail -3
```

DECISIONS additions don't move test counts or version refs, so this
should be a no-op pass. Confirm and move on.

### 5. Commit + push + open PR

```bash
git add DECISIONS.md
git commit --signoff -m "$(cat <<'EOF'
design: DECISIONS entry for <short title>

<paragraph summarizing the decision + why this lands as a
DECISIONS-only PR ahead of implementation>

Surfacing this DECISIONS entry as its own PR for review BEFORE the
implementation PR(s) land, per the working agreement
(DECISIONS 2026-05-06).

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
git push -u origin design/<short-slug>
gh pr create --title "design: DECISIONS entry for <short title>" --body "$(cat <<'EOF'
## Summary

<one-paragraph framing>

## Decision (full text in DECISIONS.md)

<bullet summary; the full text + alternatives + cross-references
are in the DECISIONS.md addition>

## Test plan

- [x] check-docs.py clean (DECISIONS-only addition; no version moves)
- [x] DECISIONS.md syntax valid
- [ ] CI green
- [ ] Review + approval BEFORE implementation PR(s) land

## Cross-references

- Parent DECISIONS entries this depends on
- CLAUDE.md sections that codify the working pattern
- External docs (FedRAMP, FRMR, etc.)

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

## When NOT to use this command

- **Implementation PRs** — those carry their own brief DECISIONS
  reference but don't need a new entry unless they change something
  the original entry didn't cover.
- **Doc refreshes / housekeeping** — those don't need DECISIONS
  entries; just commit with a `docs: ...` prefix.
- **Trivial bug fixes** — DECISIONS.md is for non-trivial decisions
  per CLAUDE.md "Quality bar" rule. A one-line typo fix doesn't
  warrant an entry.

## Reminders

- **Append, don't overwrite** — DECISIONS.md is append-only; if a
  decision is reversed, add a new dated entry that supersedes the
  old one (don't edit the old one).
- **Be specific about alternatives** — "considered an MCP server
  but rejected because <X>" beats "considered alternatives, picked
  this one".
- **Date-stamp consistently** — `YYYY-MM-DD`.
- **DCO required** on the commit.
