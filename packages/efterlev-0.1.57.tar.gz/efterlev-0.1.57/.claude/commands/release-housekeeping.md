---
description: Bump __version__ + sweep all version refs in CLAUDE.md / README.md / LIMITATIONS.md / docs / scripts. Use for hotfix patches and follow-on releases that don't add a detector. (For detector PRs, use /ship-detector instead — it does this and more.)
---

You are doing a release-housekeeping bump for Efterlev. The user
invoked `/release-housekeeping $ARGUMENTS` where `$ARGUMENTS` is the
target version string (e.g. `0.1.35` or `v0.1.35` — strip leading `v`).

This is for releases that DON'T add a detector — e.g. CI hotfixes,
workflow tweaks, doc-only updates, dependency bumps, manifest-only
changes. For detector PRs use `/ship-detector` instead.

## The 7-step ritual

### 1. Confirm we're on a fresh release branch

If the user is on `main`, branch off:

```bash
git fetch origin main && git checkout main && git pull --ff-only
git checkout -b release/v$ARGUMENTS
```

If they're already on a feature branch, that's fine — just run the
bump there.

### 2. Bump __version__ in src/efterlev/__init__.py

Single-line edit: `__version__ = "<new>"`. Hatch reads it on build.

### 3. Run check-docs.py to enumerate drift

```bash
uv run python scripts/check-docs.py
```

Will surface drift items including version-claim references in:
- `LIMITATIONS.md` (line ~135 — "PyPI release + pipx install" bullet)
- `CLAUDE.md` (line ~21 — Current state opening sentence)
- `README.md` (lines ~125, ~179, ~194 — Coverage heading,
  CHANGELOG link, Status paragraph)
- `docs/index.md` (line ~77 — Status block)
- `scripts/verify-release.sh` (example version in usage strings)

Plus any test-count or source-file-count drift the new code
introduced. Fix every line.

### 4. Update Nth-patch narratives

The "Thirty-N patch releases since v0.1.0" sentences appear in:
- README.md Status paragraph
- CLAUDE.md Current state opening
- LIMITATIONS.md "PyPI release" bullet
- docs/index.md Status block

Bump the ordinal (e.g. "Thirty-five" → "Thirty-six").

### 5. Write CHANGELOG entry

Top of CHANGELOG.md, above the previous version block. Sections to
include depending on what shipped:

```markdown
## [0.1.NN] — YYYY-MM-DD

<one-paragraph what + why this release exists — usually
"hotfix for v0.1.MM's auto-triage T_X FAIL" or "follow-on after
v0.1.MM's design surface" etc.>

### Fixed
- <file> — <what changed and why>

### Added (if anything)
- <new file/test/etc.>

### Changed (if anything)
- <existing-file change>

### Internal (count deltas)
- Test count: A → B (+N).
- Detector count: unchanged at N. (or whatever moved)

### Cross-references
- DECISIONS YYYY-MM-DD "<title>" — design rationale if this is
  a follow-on of a design entry
- v0.1.MM's release page that exposed the bug, if applicable
```

### 6. Run all gates

```bash
uv pip install -e . --reinstall --quiet
uv run python scripts/check-docs.py 2>&1 | tail -3
uv run pytest -m "not e2e" -q 2>&1 | tail -3
uv run ruff check src tests scripts 2>&1 | tail -2
uv run ruff format src tests scripts 2>&1 | tail -2
uv run mypy 2>&1 | tail -2
```

Expected: all clean. If `test_in_source_version_matches_package_metadata`
fails, the reinstall above should have fixed it; re-run pytest.

### 7. Commit + push + open PR

```bash
git add -A
git commit --signoff -m "$(cat <<'EOF'
v0.1.NN: <one-line summary>

<paragraph explaining what + why>

<bullet on the structural lock that caught any drift, if applicable>

<bullet on which DECISIONS entry / prior release this follows>

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
git push -u origin release/v$ARGUMENTS  # or current branch name
gh pr create --title "v0.1.NN: <title>" --body "<body>"
```

## When NOT to use this command

- **Adding a detector** — use `/ship-detector` instead (it does
  release-housekeeping AS PART of the detector PR, but also handles
  the EXPECTED_DETECTORS bump + count assertions in test_cli.py +
  the 5-file detector folder + tests).
- **Cutting a major design release** — the design entry is its own
  PR per the working agreement; this command is for the
  implementation PR that follows. Use `/decisions-entry` to draft
  the design entry first.

## Reminders

- **DCO required** — every commit ends with `--signoff`.
- **Never push to main** — even hotfixes go through PRs (the strict
  ruleset blocks direct pushes; admin merge of the PR is fine).
- **CHANGELOG order** — newest at top, above the previous version.
- **Date format** — `YYYY-MM-DD` (today's date in the entry header).
