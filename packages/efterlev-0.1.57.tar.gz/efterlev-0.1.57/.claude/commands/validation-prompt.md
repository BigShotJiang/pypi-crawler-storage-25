---
description: Generate a tester-validation prompt for the given Efterlev version. Reads the CHANGELOG entry for that version, extracts each Fixed/Added item, and emits a paste-ready markdown prompt covering S0 baseline + per-fix PASS/FAIL scenarios + a structured report format.
---

You are generating a tester-validation prompt for Efterlev. The user
invoked `/validation-prompt $ARGUMENTS` where `$ARGUMENTS` is the
version to validate (e.g. `0.1.39` or `v0.1.39` — strip leading `v`).
If `$ARGUMENTS` is empty, default to the current `__version__` from
`src/efterlev/__init__.py`.

This command produces a self-contained markdown block the user pastes
into a fresh Claude Code session (or hands to a human tester) to
narrowly verify that the fixes in version `N` actually hold. NOT a
full deep-test — that's `scripts/deep-test.sh` for the deterministic
tier or the full session prompt for LLM-judgment tier. This is the
narrow re-validation step that confirms fixes survived the round-trip
to PyPI / container.

## Working agreement

- **Narrow scope.** Only validate the fixes from THIS version. Don't
  re-run the full deep-test prompt — that takes 30 min and ~$3.
- **PASS/FAIL criteria must be unambiguous.** A scenario where "looks
  fine" is the answer is a useless test. Each scenario needs a
  specific stdout/stderr substring or exit code that the tester
  asserts.
- **The tester needs to run on a CLEAN install.** S0 baseline check
  catches the install-shadowing class of bug we hit on v0.1.38
  (uv-tool symlink shadowed pipx, snippet imported old parser). It
  is mandatory and goes first.

## What you do

### 1. Resolve version + read CHANGELOG block

```bash
VERSION=${ARGUMENTS:-$(grep '^__version__' src/efterlev/__init__.py | sed -E 's/.*"([^"]+)".*/\1/')}
VERSION=${VERSION#v}
# Pull the CHANGELOG section for this version. Format is:
#   ## [0.1.NN] — YYYY-MM-DD
#   <body until the next "## [" header>
awk -v v="$VERSION" '/^## \[/{p = ($0 ~ "\\["v"\\]")} p' CHANGELOG.md
```

Read the block. Note each `### Fixed` and `### Added` entry. Each
fix becomes one validation scenario in the output prompt.

### 2. Map each fix to a validation scenario

For each fix, pick the right scenario shape based on what changed:

| Fix shape | Scenario shape | Example |
|---|---|---|
| Friendly error wrapper | Set the env that triggers the error, run the CLI verb, assert message + no traceback | v0.1.38 invalid API key |
| Probe / auto-pick logic | Run the probe end-to-end against real account, assert the picked value | v0.1.39 Bedrock probe |
| CLI flag / output shape | Run the verb with the flag, assert stdout/stderr substring | v0.1.38 --version shadow warn |
| Workflow / behavior change | Construct the precondition, run the verb, assert the new behavior | v0.1.37 retry visibility |
| Init / scan / agent flow | Multi-step sequence, assert no traceback + final exit 0 | v0.1.39 init manifests-only |

If the fix is for a Bedrock-only behavior, mark the scenario
"skip if no Bedrock access" and include both options.

### 3. Emit the prompt

Output a self-contained markdown block (don't write to disk, just
print it for the user to copy) with this structure. Replace
`<placeholders>` with values from CHANGELOG / version:

````markdown
# Efterlev v<VERSION> regression validation

You are validating that <N> shipped fixes from the v<PRIOR-VERSION>
deep-test session actually hold in v<VERSION>. This is NOT a full
deep-test — it's a narrow regression check (~10 min wall, ~$0 cost
unless a Bedrock scenario is selected). Do not run the full
quickstart pipeline unless a step explicitly asks for it.

## Setup

```bash
# Use whatever your normal install path is — pipx, uv tool, brew.
pipx upgrade efterlev    # or: uv tool upgrade efterlev
efterlev --version
```

**S0 baseline check:** confirm the version line says `efterlev <VERSION>`.
If it shows anything older, S1-class shadowing is confounding the
test — STOP and report the version mismatch BEFORE running anything
else.

## Per-fix checks

<FOR EACH fix from the CHANGELOG: emit a section like this:>

### S<N> — <one-line fix summary>

**What was fixed (v<VERSION>):** <pull the explanation from the
CHANGELOG entry — what was broken, what changed.>

```bash
<the literal commands the tester runs>
```

**Expected (PASS):**
- <specific stdout/stderr substring or exit code that proves the fix>
- <secondary assertion if applicable>

**FAIL conditions:**
- <what they'd see if the fix regressed>
- <do NOT include vague things like "looks wrong">

<END FOR>

## Report format

Report back a table — keep it short:

| Finding | Status | Notes |
|---|---|---|
| S0 baseline | PASS / FAIL | which version landed; install method used |
<FOR EACH scenario:>
| S<N> <one-word> | PASS / FAIL [/ N/A / SKIPPED] | <one short note> |
<END FOR>

Plus: if you noticed anything *new* (not on this list) that surprised
you during the validation, add it as a one-line note. We are not
asking for a full deep-test, but real surprises are worth flagging.
````

## Output discipline

- **Print the prompt to stdout.** Don't write to a file. The user
  copies it to clipboard.
- **Don't add scenarios for fixes already covered by `pytest -m deep`
  if the validation environment is the local repo.** The deep-test
  suite IS the regression coverage for those scenarios. The
  validation prompt is for the narrow class where local CI tests
  can't reproduce: real Bedrock account state, real install-shadow
  detection, real-world LLM endpoint behavior.
- **One scenario per fix entry.** Don't bundle. Each gets its own
  PASS/FAIL row in the report.
- **Bedrock scenarios get the "skip if no access" option.** The
  tester may not have Bedrock credentials handy.
- **Use `set -o pipefail` or `${PIPESTATUS[0]}` whenever a tee is
  involved.** The naive `efterlev <verb> 2>&1 | tee /tmp/log; $?`
  pattern captures `tee`'s exit (always 0), masking the real failure.
  The v0.1.39 deep-test session burned a round on this — first report
  said S2 PASSed, real exit was 1. Either prefix the scenario block
  with `set -o pipefail`, or replace `; $?` with `; ${PIPESTATUS[0]}`,
  or split into separate redirects (`> /tmp/log 2>&1`). Pick whichever
  is least intrusive for the scenario shape.
- **Bedrock model ID naming is INCONSISTENT across families.** For
  newer Anthropic profiles (`opus-4-7`, `sonnet-4-6`, `haiku-4-5`),
  the real ID is the bare shape WITHOUT a `-v1:0` suffix:
  `us.anthropic.claude-sonnet-4-6` (NOT `…sonnet-4-6-v1:0`). For
  dated variants (`opus-4-1-20250805`, `sonnet-4-5-20251101`,
  `opus-4-20250514`), the `-v1:0` suffix IS present. The v0.1.40
  deep-test S3 finding was wasted because the runbook's Sonnet ID
  used the wrong shape and AWS rejected it as invalid. When you
  generate explicit-override scenarios, look at the user's account
  state (or use the bare-shape default for `4-6` and `4-7` families).

## Cross-references

- `scripts/deep-test.sh` — deterministic tier (S1/S3/S6/S7-shape
  scenarios run automatically with no LLM cost; this command's
  output complements it for the env-state-dependent class).
- `scripts/triage.sh` — post-tag automated validation (T1–T7);
  fires on every release tag. Different scope: validates the
  PUBLISHED artifact end-to-end. This command validates that
  fixes WORK; triage validates that the artifact installs.
- DECISIONS 2026-05-07 process-improvements entry — codifies the
  testing-tier system.

## When NOT to use this command

- **For a release with no user-facing fixes** (e.g. a CI-only patch
  or a doc-drift sweep). The CHANGELOG won't have meaningful Fixed
  entries to validate.
- **For full release acceptance.** Use the deep-test session prompt
  (the LLM-judgment tier) every few releases. This command is for
  the narrow re-validation that fits between deep-tests.

## Reminders

- The output goes to stdout. Don't write `validation-prompt.md`
  files. The point is rapid copy-paste.
- Make every PASS criterion specific (substring, exit code, file
  presence). "Looks right" is not a criterion.
- If a fix can ONLY be validated against a real LLM endpoint, say so
  in the scenario — don't pretend it's testable on a dev laptop.
