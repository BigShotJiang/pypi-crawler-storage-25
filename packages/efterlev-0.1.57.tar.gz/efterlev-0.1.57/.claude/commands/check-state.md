---
description: Quick repo-state snapshot — current version, latest tag, detector count, KSI coverage, recent releases, latest auto-triage status. Useful at session start.
---

You are giving the user a quick repo-state snapshot for Efterlev.
Run the following queries in parallel (one Bash call with multiple
commands chained via `&&` would serialize unnecessarily — use
multiple parallel Bash tool calls when independent).

Format the output as a tight summary, NOT raw command output.

## What to gather

### Version + git state

```bash
grep '^__version__' src/efterlev/__init__.py
git rev-parse --abbrev-ref HEAD
git log --oneline -5
git fetch origin main 2>&1 | tail -1 && git status -uno
```

### Registry + coverage

```bash
uv run python -c "
import json
from efterlev.detectors import *
from efterlev.detectors.base import get_registry

reg = get_registry()
print(f'detectors: {len(reg)}')
ksi_mapped = [s for s in reg.values() if s.ksis]
print(f'  KSI-mapped: {len(ksi_mapped)}')
print(f'  800-53-only: {len(reg) - len(ksi_mapped)}')

frmr = json.load(open('catalogs/frmr/FRMR.documentation.json'))
all_ksis = set()
for theme in frmr['KSI'].values():
    all_ksis.update(theme.get('indicators', {}).keys())
covered = set()
for s in ksi_mapped:
    covered.update(s.ksis)
print(f'KSI coverage: {len(covered)}/{len(all_ksis)}')
"
```

### Latest release pipeline state

```bash
gh release list --limit 1
gh release view "$(gh release list --limit 1 | awk '{print $1}')" 2>&1 | grep -E "T[1-7]|Result" | head -10
```

### Open PRs + recent runs

```bash
gh pr list --state open --limit 5
gh run list --limit 5 --json name,headBranch,status,conclusion --jq '.[] | "\(.name) on \(.headBranch): \(.status) \(.conclusion // "")"'
```

### Tier 1 progress (from CLAUDE.md)

```bash
grep -A1 "^### Tier 1 — shipped\|^### Tier 1 #4 — detector" CLAUDE.md | head -30
```

### Pending follow-ups + Tier 2 candidates

```bash
grep -A2 "^### Small follow-ups\|^### Tier 2" CLAUDE.md | head -15
```

## Output shape

After running the queries, summarize as:

```
**Version:** v0.1.NN  (branch: <branch>; <N> ahead/behind main)
**Tests:** <N> passing  |  **Detectors:** <N> (<X> KSI-mapped + <Y> 800-53-only)  |  **KSI coverage:** <N>/60

**Latest release:** v0.1.NN — <T1-T7 status from triage>

**Open PRs:** <count> — <one-line per PR>
**Active workflows:** <pending/queued only>

**Tier 1 progress:** <e.g. "5/5 originally-planned items shipped">
**Pending follow-ups:** <list from CLAUDE.md>
**Next Tier 2 candidate:** <first item>
```

Keep it dense. The user is using this to orient at session start —
they want to know "where are we" in 10 seconds.

## When NOT to use this command

- Mid-task — this is for orientation, not status updates during
  active work. Use specific `gh pr checks` / `gh run view` calls
  instead.
- After a fresh release — the auto-triage will repopulate the
  release page over ~10 min; calling `check-state` immediately
  after a tag push gives stale T7 PENDING.
