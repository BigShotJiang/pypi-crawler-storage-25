---
description: Run the v$ARGUMENTS validation scenarios via a general-purpose subagent on THIS machine (not via human-tester handoff). Composes with `/validation-prompt` (which generates the scenarios); this command also executes them and returns the structured report inline. Default for patch-release re-validation when the dev box has the relevant credentials (Anthropic API key, AWS Bedrock).
---

You are running v$ARGUMENTS validation locally for Efterlev. The user
invoked `/validate-locally $ARGUMENTS` where `$ARGUMENTS` is the
version to validate (e.g. `0.1.41` or `v0.1.41` — strip leading `v`).
If `$ARGUMENTS` is empty, default to the current `__version__` from
`src/efterlev/__init__.py`.

## When to use this vs `/validation-prompt`

| Scenario | Tool |
|---|---|
| Patch-release re-validation on dev box (your laptop / build machine) | **`/validate-locally`** (this command) |
| First validation of a major release / new architecture | `/validation-prompt` (human-tester handoff for fresh-eyes pass) |
| Tester is on a DIFFERENT machine (different account state, different OS) | `/validation-prompt` (paste-into-fresh-session) |
| You want to inspect "feels weird" non-checklist observations | `/validation-prompt` (human judgment) |

Default for patch releases: `/validate-locally`. Cheaper feedback
loop, no clipboard handoff, ~5 min round-trip.

## Working agreement (non-negotiable, from CLAUDE.md)

- **Pre-existing AWS / Anthropic credentials.** This command assumes
  the dev box has AWS credentials configured for Bedrock in
  `us-east-1` (the project memory "Efterlev test-LLM default" pins
  the Haiku-on-Bedrock ARN as the test default). It does NOT prompt
  for or rotate credentials — if missing, the subagent reports the
  credential gap as the failure.
- **Test-LLM default = Haiku 4.5 on Bedrock.** Whenever a scenario
  invokes `efterlev agent <verb>`, `efterlev quickstart`, or
  `efterlev report run`, the model ID must come from the maintainer's
  environment, NOT be hardcoded in this skill (account-scoped ARNs
  belong to the maintainer's personal AWS account and don't ship
  publicly). Resolution order in scenarios:
  1. If `$EFTERLEV_TEST_BEDROCK_MODEL` is set in the environment,
     pass `--llm-model "$EFTERLEV_TEST_BEDROCK_MODEL"` on `efterlev init`.
  2. Otherwise, pass `--llm-backend bedrock --llm-region us-east-1`
     and let efterlev's v0.1.39+ probe + v0.1.41 test-call closure
     pick whichever public `us.*` Haiku profile is invokable in the
     target account. The probe surfaces a clear actionable error if
     none is invokable.

  Future Claude Code sessions running on the maintainer's dev box
  may know the specific account-scoped ARN from local memory — that's
  fine; it stays in local memory, not in this skill file.
- **Cost is real.** Even with Haiku, a scenario that exercises agent
  gap costs ~$0.05-0.15 of Bedrock tokens. Don't invoke speculatively.
- **Subagent isolation.** The subagent runs in its own context; its
  raw stdout doesn't pollute the main conversation. The subagent
  returns a structured PASS/FAIL table; you relay it to the user.

## The 4-step ritual

### 1. Resolve version + read CHANGELOG block

Same as `/validation-prompt`:

```bash
VERSION=${ARGUMENTS:-$(grep '^__version__' src/efterlev/__init__.py | sed -E 's/.*"([^"]+)".*/\1/')}
VERSION=${VERSION#v}
awk -v v="$VERSION" '/^## \[/{p = ($0 ~ "\\["v"\\]")} p' CHANGELOG.md
```

Extract the Fixed/Added entries — each becomes one validation
scenario for the subagent.

### 2. Build the scenario list using the same shapes as `/validation-prompt`

Use the same `(setup, run, expected, fail-conditions)` shape per
fix. The mandatory S0 baseline check goes first (catches
install-shadow). The mapping table from `/validation-prompt`'s
"What you do" section applies unchanged.

### 3. Hand the scenarios to a general-purpose subagent

Invoke the Agent tool with `subagent_type: "general-purpose"`. The
subagent's prompt should:

- Be self-contained (subagent doesn't see this conversation's history).
- Brief the subagent on the validation context (what version, what
  fixes, what to test, what credentials are expected available).
- Tell it explicitly: don't write to disk; print the PASS/FAIL table
  to its final response; include exit codes + key stderr substrings
  for failures.
- Include the `set -o pipefail` discipline in any scenario using
  `tee` (the v0.1.39 lesson — naive pipes mask real exit codes).
- Tell the subagent to clean up its workspace under `/tmp/` after
  the run, so subsequent invocations don't see stale state.

A good subagent prompt template:

```
You are validating Efterlev v<VERSION> on this dev box. The fixes
you're testing are:

  <bulleted list pulled from CHANGELOG>

Pre-conditions (assume true; report failure if not):
  - efterlev v<VERSION> installed (verify with `efterlev --version`).
  - <ANTHROPIC_API_KEY set | AWS Bedrock credentials configured>
    (only the credential class actually needed by the scenarios below).

Run each scenario below in a fresh `/tmp/efterlev-validate-vX-sN/`
directory. Use `set -o pipefail` in every shell block. Report results
as a PASS/FAIL table at the end of your response.

Scenarios:
  S0 baseline: <command, expected, fail-conditions>
  S1 ...: <command, expected, fail-conditions>
  S2 ...: <command, expected, fail-conditions>
  ...

After running, clean up `/tmp/efterlev-validate-v<VERSION>-*` dirs.
Do NOT leave stale state behind.

Final response format (markdown table only):

| Finding | Status | Notes |
|---|---|---|
| S0 baseline | PASS / FAIL | <brief> |
| ... |
```

### 4. Relay the subagent's report to the user

The subagent's final message IS the validation report. Quote its
PASS/FAIL table verbatim in your response to the user, plus any
"surprises" the subagent flagged (subagents can notice things
that aren't in the checklist — relay those even if vague).

If the subagent reports any FAIL, summarize for the user:
- Which scenarios failed
- What the subagent observed in stderr
- Whether the failure looks like a regression of a previous fix or
  a new failure mode
- Recommended next step (rerun for transient flake, or scope a
  fix-PR if it's a real regression)

## Output discipline

- **The subagent does the running.** Don't run the scenarios in
  your own Bash tool unless the subagent invocation itself fails.
- **Relay verbatim, don't editorialize.** The subagent's PASS/FAIL
  judgment is the result. Your job is to summarize for the user
  and recommend next steps.
- **One subagent call per validation cycle.** Don't fan out across
  multiple subagents for one validation — defeats the isolation
  benefit and triples LLM cost.
- **Cleanup is mandatory.** Subagent must delete `/tmp/efterlev-validate-*`
  after the run. Otherwise stale fixtures accumulate and a later
  validation can pick them up by accident.

## Cross-references

- `/validation-prompt` — sibling skill for the human-tester handoff
  case. Same scenario shapes, different invocation.
- `scripts/deep-test.sh` — deterministic tier (no LLM). Run BEFORE
  validating; catches anything a CI deep-smoke would catch.
- DECISIONS 2026-05-08 (TBD): the testing-tier system codification.

## When NOT to use this command

- **No relevant credentials on dev box.** If neither `ANTHROPIC_API_KEY`
  nor AWS Bedrock creds are configured, the subagent has nothing to
  call. Use `/validation-prompt` and hand to a tester who has them.
- **Validating against a different account state.** If the bug is
  account-state-specific and your dev box's account differs from the
  reporter's, the subagent can't reproduce. Use `/validation-prompt`
  + send the prompt to the reporter.
- **First-of-its-kind validation for a major release.** Human eyes
  catch surprises a checklist misses. Use `/validation-prompt` for
  major-version cuts; `/validate-locally` for the patch-release
  re-runs after.

## Reminders

- Subagent invocation costs LLM tokens — keep the prompt tight,
  scenarios scoped, no exploratory branches.
- Cleanup `/tmp/efterlev-validate-*` after every run.
- Real PASS/FAIL criteria, not "looks right." Pull them from the
  CHANGELOG block (each Fixed entry implies a specific assertion).
