# CLAUDE.md — Efterlev

This file is your persistent context for working on Efterlev. Read it at the start of every session.

---

## What we're building

**Efterlev** is a repo-native, agent-first compliance scanner for FedRAMP 20x. It runs locally in the developer's codebase and CI pipeline — not in a SaaS dashboard — and produces code-level evidence, FRMR-compatible attestation drafts, and code-level remediation diffs. The internal abstraction is the **Key Security Indicator (KSI)** — the outcome-based unit FedRAMP 20x is built around. Detectors evidence KSIs; KSIs reference 800-53 controls; the user-facing surface speaks KSIs.

The name is a shortening of the Swedish *efterlevnad* (compliance). Pronounce it "EF-ter-lev."

**Primary user (the ICP lens for every product decision):** a SaaS company (50–200 engineers) pursuing its first FedRAMP Moderate authorization, with a committed federal deal on the line. Full ICP at `docs/icp.md` — read it before proposing features, because the ICP is how we decide what Efterlev does and doesn't do.

License: Apache 2.0. No commercial tier, no managed SaaS, no paid layer. Pure OSS, throughout. Competitive positioning lives in `COMPETITIVE_LANDSCAPE.md`.

---

## Current state

**v0.1.57 is current** (shipped 2026-05-11). Public on GitHub at `efterlev/efterlev`, on PyPI as `efterlev`, on `ghcr.io/efterlev/efterlev` (multi-arch, cosign-signed + cosign-verifiable SLSA build provenance from v0.1.13; wheel + sdist CycloneDX SBOMs attached to every GitHub Release from v0.1.57). Fifty-nine patch releases since v0.1.0 (2026-04-29).

The v0.1.x patch arc closed real-CI bugs surfaced by deep-dive shakedowns against the canonical dogfood target (govnotes-demo) and external real-Terraform shakedowns (terraform-aws-vpc, fully-private-cluster). Each release fixed cross-component bugs unit tests had missed: max_tokens truncation, doc-agent dual-emit on multi-gap-run workspaces, boundary-state propagation on stale evidence, IAM `aws_iam_policy_document` data-source resolution, and many more. The release-blocker rate converged to 0 by v0.1.7 and stayed there. **v0.1.11 was the first release driven by an external 3PAO blinded review** rather than dogfood shakedown — five rendering / display / persistence findings, all closed at the artifact layer with no scanner-output behavior change. **v0.1.12 closed four findings from a deterministic, zero-LLM post-release validation of v0.1.11** — verify-release.sh wired to PEP 740 (PyPI side), subdir-scan ancestor warning, unparseable-evidence plan-JSON hint, doc drift in ai-quickstart-prompt.md. **v0.1.13 fixed a missing `attestations: write` permission on `release-container.yml`** that prevented v0.1.12's new SLSA-attestation step from firing — verify-release.sh check 3 starts passing on v0.1.13 container artifacts. **v0.1.16 codified the post-release-triage methodology** as `scripts/triage.sh` + `.github/workflows/post-release-triage.yml` — auto-runs on every tag push, posts a verifiable-quality report to the GitHub Release notes body. See `CHANGELOG.md` for per-release detail.

**v0.1.18–v0.1.21: Tier 1 #1–#3 delivery.** Shipped the activation/audit/manifest half of the Tier 1 sequence locked in DECISIONS 2026-05-06: `efterlev quickstart` (one-command activation demo, v0.1.18); end-of-run cost summary on agent commands (v0.1.19); `--dry-run` / `--dump-prompt` on agent commands (v0.1.20); 24-template Evidence Manifest starter pack with `efterlev manifests init --starter-pack` (v0.1.21).

**v0.1.22–v0.1.27: matrix-visibility cascade.** A single discovery — that `release-smoke` had been silently red across every cell on v0.1.20 + v0.1.21 because the workflow_run row in `gh run list` collapses matrix state to one column — turned into a six-release cascade. Each fix surfaced the next layer of platform-specific bug that the silent matrix had been masking: assertion script (v0.1.22) → workflow env + trigger gate + Windows fcntl + docker-ghcr ?mode=ro (v0.1.23) → WAL-mode &immutable=1 (v0.1.24) → Windows charmap on read (v0.1.25) → Windows msvcrt.locking O_APPEND (v0.1.26) → Windows charmap on write (v0.1.27). v0.1.27's matrix lands green across pipx + docker-ghcr × mac/win/linux/arm. Auto-triage T7 surfaces matrix conclusion on the GH Release page so silent regressions cannot recur. See six DECISIONS 2026-05-07 entries for the full cascade.

**v0.1.28–v0.1.34: Tier 1 #4 detector backlog.** Per DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis", classified all 30 currently-uncovered KSIs as `evidenceable-via-iac` / `partial` / `procedural-only`, then shipped 6 detectors closing the IaC-evidenceable gaps: `aws.cna_optimizing_for_availability` (KSI-CNA-OFA, v0.1.28); `aws.mla_log_access_least_privilege` (KSI-MLA-ALA, v0.1.30); `aws.cna_dos_protection` (KSI-CNA-RVP, v0.1.31); `aws.svc_at_rest_encryption_coverage` (KSI-SVC-PRR, v0.1.32); `aws.rpl_backup_configured` (KSI-RPL-ARP, v0.1.33); `github.piy_sdlc_security_gates` (KSI-PIY-RSD, v0.1.34). Coverage moved from 30/60 to 36/60 KSIs — exactly matching the design entry's projected outcome. v0.1.29 was a CI hotfix that introduced `tests/test_triage_constant_alignment.py` — a source-level pin against `EXPECTED_DETECTORS` drift in `scripts/triage.sh`; the lock then caught drift at PR time on every detector PR (5/5). All four originally-planned Tier 1 items now shipped (#1 quickstart, #2a/2b cost+dry-run, #3 starter pack, #4 detector gap analysis).

**v0.1.10 added the CI E2E smoke required check.** Every PR runs the full Efterlev pipeline (init → scan → agent gap → agent document → poam) against a synthetic fixture using a real Anthropic API call. ~$0.05–0.10/PR on Haiku 4.5 (the v0.1.43+ default; switched from Sonnet 4.6 after observing ~50% PR-flake rate); ~5 min wall. This is what closed the manual-shakedown-per-patch loop.

**v0.1.43: agent-quality maturity sprint.** Gap/doc/remediation prompts rewritten against the 2026 Anthropic prompting best-practices guide (XML structure, few-shot examples, manifest-quoting + resource-naming codified, anti-overengineering for remediation diffs). v0.2 eval-harness Phase 1 shipped (5 metrics: M1 status_precision through M5 poam_scope_discipline; 4 fixtures; `--runs N` aggregator for noise-floor calibration). M1 status_precision lifted 0.818 → 1.000 on the most-exercised eval-harness fixture. Gap-stage retry helper (DECISIONS 2026-05-09) handles the ~21% Haiku stochastic-rejection rate transparently in both the eval harness and the CI smoke entry point.

**v0.1.44 + v0.1.45: Tier 2 serverless detector batches.** Three DECISIONS-then-implementation cycles (#1 + #2 + #3) shipped 7 detectors closing the original 5-detector Lambda + API Gateway deferred backlog from PR #196 — `aws.lambda_logging_configured`, `aws.api_gateway_tls_min_version`, `aws.lambda_env_kms_encryption`, `aws.api_gateway_access_logging`, `aws.lambda_vpc_isolation`, `aws.api_gateway_auth_required`, `aws.api_gateway_waf_attached`. Plus a new `serverless-mixed` eval-harness fixture (5th in the corpus). KSI count unchanged at 37 — the new detectors widen the resource-type evidence base for already-covered KSIs (CNA family especially) rather than adding first-time coverage. KSI-mapped detector count rose 47 → 54.

**v0.1.46: Tier 3 #1 `aws.waf_*` detector family v0.** Three new detectors closing the WAF-posture-quality dimension that the Tier 2 #3 `aws.api_gateway_waf_attached` left unaddressed — `aws.waf_rule_count`, `aws.waf_managed_rule_groups`, `aws.waf_rate_limiting`. Per-Web-ACL emission, binary states (no `unverifiable`), all map to KSI-CNA-RVP (already covered) — these widen KSI-CNA-RVP detector cross-coverage 2 → 5 spans without adding first-time KSI coverage. `serverless-mixed` fixture extends to rev 4 to exercise both posture extremes (api_protection with managed group + rate cap; legacy_unprotected_waf bare). KSI-mapped detector count rose 54 → 57.

**v0.1.47: Tier 3 #2 streaming refactor + cap lift.** AnthropicClient._one_call switched from non-streaming `messages.create()` to `messages.stream()` (unconditional, not max_tokens-conditional); Gap Agent default_anthropic max_tokens lifted 20480 → 32768 (matches Bedrock). Removed the deterministic Anthropic-direct ceiling that was about to bite as fixtures grew. Public agent-layer API unchanged; retry helper, telemetry, and Bedrock client all untouched. PR #217 stochastic flake on rev-4 fixture was the immediate motivating evidence; the v0.1.x post-release-validation methodology working as designed.

**v0.1.48: Tier 3 #3 `aws.waf_*` family v1.** Two new detectors closing the action-type + IP-set-blocking dimensions deferred from Tier 3 #1 Decision #7: `aws.waf_action_types` (3-state: enforcing / observing_only / mixed; catches the canonical "managed group set to count" gap) and `aws.waf_ip_set_blocking` (first WAF-family detector to evidence AC-3 Access Enforcement at the IaC layer). `serverless-mixed` extends to rev 5 to exercise both new dimensions on `api_protection` (count-action managed-group rule + IP-set blocking rule) plus a new top-level `aws_wafv2_ip_set` resource. Detector count rises 61 → 63; KSI-mapped 57 → 59. KSI-CNA-RVP cross-coverage rises 5 → 7 (most cross-resource-type-evidenced KSI in the library by a wide margin).

**v0.1.49: Tier 3 #4 `aws.waf_geo_blocking`.** Single detector closing the geo-blocking dimension deferred from Tier 3 #1 Decision #7. **First WAF-family detector to evidence SC-7 (Boundary Protection) at the IaC layer** -- geo-blocking IS the canonical perimeter-side boundary control at the country level; the existing SC-7 evidence base is heavily VPC-internal, this widens it to the public-internet perimeter. Two-state binary detector with intentional-absence handling in the gap message ("may be intentional for global-customer workloads"). `serverless-mixed` extends to rev 6 to exercise the new dimension on `api_protection` (canonical embargoed-country block: KP, IR, CU, SY). Detector count rises 63 → 64; KSI-mapped 59 → 60. KSI-CNA-RVP cross-coverage rises 7 → 8. WAF family now at 6 of 7 v0/v1 dimensions shipped (only `custom_rule_groups` remains deferred for Tier 3 #5).

**v0.1.50: Tier 3 #5 closes the WAF family at 7/7.** `aws.waf_custom_rule_groups` -- cross-resource detector that walks both aws_wafv2_web_acl AND aws_wafv2_rule_group resources; emits per Web ACL whether any rule references a customer-defined rule group via statement.rule_group_reference_statement. The defined_rule_groups inventory in the evidence content lets the Gap Agent flag the canonical "defined but unreferenced" anti-pattern. `serverless-mixed` extends to rev 7. Detector count rises 64 → 65; KSI-mapped 60 → 61. KSI-CNA-RVP cross-coverage rises 8 → 9. **The aws.waf_* family v0/v1 arc spanning 5 batches across 5 releases (v0.1.46–v0.1.50) is now complete** — 7 detectors covering rule_count, managed_rule_groups, rate_limiting, action_types, ip_set_blocking, geo_blocking, custom_rule_groups; KSI-CNA-RVP went from 2 detectors at v0.1.45 to 9 at v0.1.50. The 3-dimension SC-7 evidence base + 2-dimension AC-3 evidence base + bulk SI-3 coverage make WAF the most cross-control-evidenced detector family.

**v0.1.51: Tier 4 #1 ships ConMon Lite v0.** First non-detector strategic batch since the Tier 3 WAF arc closure. PR-delta scan comparison: every PR now gets a sticky comment listing newly-introduced gaps relative to the base branch. New `efterlev scan-diff <prior> <current>` CLI command + `.efterlev/reports/scan-<ts>.json` sidecar emission on `efterlev scan` + extended pr-compliance-scan.yml workflow that scans the base branch via `git worktree add`, runs the diff, and posts a sticky comment with the `<!-- efterlev-conmon-lite -->` marker (distinct from the existing posture-comment marker so the two coexist). Per-detector gap-emission abstraction at v0 — deterministic + free; KSI-verdict diffs deferred to ConMon Lite v1 once a verdict-stability mechanism is in place.

**v0.1.52: Tier 4 #2 ships ConMon Lite v1.** Closes the verdict-stability deferral from Tier 4 #1 with 2-of-3 majority voting. New `--runs N` flag on `efterlev agent gap` + new `multi_run.py` aggregator (per-KSI majority via `Counter` + `ceil(N/2)` threshold, tie-break to most-conservative verdict, KSIs whose top vote count is below threshold marked `flickering`) + new gap-report JSON sidecar fields (`runs_aggregated`, `per_run_verdicts`, `flickering_ksis`) + `--print-markdown` + `--base-branch` flags on `efterlev report diff` + `render_gap_diff_markdown` function + extended pr-compliance-scan.yml workflow gated on `EFTERLEV_CONMON_LITE_V1` repo variable. v0 + v1 sticky comments coexist on the same PR with distinct markers (`<!-- efterlev-conmon-lite -->` vs `<!-- efterlev-conmon-lite-v1 -->`); different audiences (code reviewers vs compliance reviewers). Default OFF; per-PR cost ~$0.90 on Sonnet 4.6.

**v0.1.53: contributor scaffolder.** New `efterlev detectors new <detector_id>` CLI command. Generates the canonical 5-file detector folder skeleton (`__init__.py` + `detector.py` + `mapping.yaml` + `evidence.yaml` + `README.md`) plus `fixtures/should_match/` and `fixtures/should_not_match/` directories. Stub `detector.py` is registration-ready (decorator + empty `detect`); `mapping.yaml` / `evidence.yaml` / `README.md` carry TODO placeholders keyed off the requested KSIs + controls. OSS-friction reducer held in `LIMITATIONS.md` "Future ideas" since v0.1.18+; small focused single-PR feature after the multi-batch ConMon Lite arc closed.

**v0.1.54: boundary --interactive helper.** New `--interactive` / `-i` flag on `efterlev boundary set`. Walks the user through include + exclude glob entry instead of requiring them to remember the `--include`/`--exclude` flag syntax. Bail-fast if no globs entered; mutually exclusive with `--include`/`--exclude`. Second small focused single-PR feature in the post-Tier-4 cadence; closes the second of the v0.1.18+ "Future ideas" deferrals.

**v0.1.55: github.branch_protection detector.** New per-`github_branch_protection`-resource Terraform-source detector under `detectors/github/` — inaugural Terraform reader in that namespace, which previously read only `.github/workflows/*.yml`. Joins `github.piy_sdlc_security_gates` on KSI-PIY-RSD: workflow gates run on PRs; branch protection enforces that PRs require those gates to pass before merge. Two binary states (`protections_present` / `protections_absent`); the absent state catches the canonical "branch protection rule declared but enforces nothing" gap. Bonus: friendly_errors now surfaces the Anthropic 400 body (was hidden behind a canned "code-level bug" hint) and pattern-matches the account-spend-cap 400 body (`"API usage limit"` / `"regain access"`) to a quota classification — caught the v0.1.55-cut-day spend-cap incident inside CI logs in <30 min.

**v0.1.56: efterlev detectors show <id>.** New CLI command — read/inspect counterpart that completes the detectors-CLI symmetry: `list` (registry summary, existing) + `new` (write/scaffold, v0.1.53) + `show` (read/inspect, v0.1.56). Surfaces what `detectors list` elides: mapping.yaml KSI/control coverage notes, evidence.yaml shape (per-record `content` keys), README lead paragraph, and fixture file counts. Each section degrades gracefully when a detector folder is missing the corresponding file. Unknown id exits 1 with substring-overlap + cloud-prefix-fallback suggestions.

**v0.1.57: wheel + sdist SBOMs attached to GitHub Releases.** Closes the parallel gap to the container's already-embedded SBOM (`buildx sbom: true` from v0.1.10+). `release-pypi.yml` runs `anchore/sbom-action@v0` after `publish-pypi` to generate CycloneDX SBOMs for both PyPI artifacts and attaches them as `efterlev-<VERSION>-wheel-sbom.cdx.json` + `efterlev-<VERSION>-sdist-sbom.cdx.json`. Race-tolerant against `post-release-triage.yml` (creates the Release if triage hasn't yet; triage's `gh release edit --notes-file` correctly handles the Release-exists-replace-notes case). Final tags only — rc tags don't get a public Release page. Held in `docs/followups.md` v0.1.x bucket since the v0.1.0 launch security review.

**Coverage at v0.1.57:**
- 66 detectors total (62 KSI-mapped + 4 supplementary 800-53-only)
- 37 of 60 thematic KSIs covered, across 10 of 11 themes (CMT, CNA, IAM, MLA, PIY, RPL, SCR, SVC, plus partial PIY via the v0.1.34 github workflow detector now widened by v0.1.55's branch-protection detector to the merge-enforcement layer, plus partial AFR-UCM via the v0.1.42 cryptographic-module mapping audit). The remaining KSIs (most of CED, INR, AFR) are covered by Evidence Manifests, not detectors. KSI-CNA-RVP is the most cross-resource-type-evidenced KSI in the library by a wide margin (9 detectors after v0.1.50). KSI-PIY-RSD now has 2-detector cross-coverage (workflow + branch-protection layers).
- 26 hand-authored Evidence Manifest templates for the procedural KSIs (`efterlev manifests init --starter-pack`, v0.1.21+; expanded from 24 in v0.1.36 with KSI-MLA-RVL + KSI-SVC-EIS to close the Tier 1 #4 design entry's projected manifest follow-ups)
- 3 agents: Gap (Opus 4.7), Documentation (Sonnet 4.6), Remediation (Opus 4.7) — all with system prompts rewritten v0.1.43 against the current Anthropic best-practices guide
- Two LLM backends: direct Anthropic (default) + AWS Bedrock (`[bedrock]` extra, GovCloud)
- 1500 tests passing; mypy strict + ruff check + ruff format clean across 222 source files; 30 CLI commands; full E2E pipeline smoke runs on every PR; ConMon Lite v0 (scanner-only) sticky comments on every PR (Tier 4 #1, v0.1.51); ConMon Lite v1 (KSI-verdict regressions, opt-in via EFTERLEV_CONMON_LITE_V1) (Tier 4 #2, v0.1.52); `efterlev detectors new <id>` contributor scaffolder (v0.1.53); `efterlev boundary set --interactive` helper (v0.1.54); `github.branch_protection` detector (v0.1.55); `efterlev detectors show <id>` read/inspect command (v0.1.56); wheel + sdist CycloneDX SBOMs on every GitHub Release (v0.1.57)
- 5 eval-harness fixtures (govnotes-v1, encryption-mixed, iam-dynamic-policy, runtime-monitoring, serverless-mixed at rev 7) — each at 1.000 mean / 0.000 stddev across 5-run aggregates on the post-v0.1.43 prompts
- Cross-platform install matrix green across mac (13 + 14) / Windows (2022) / Linux (Ubuntu 22.04 + 24.04 ARM) × pipx + docker-ghcr methods, validated on every tag via `release-smoke.yml` and surfaced on the GH Release page via T7 in `scripts/triage.sh` (v0.1.22+)
- Token usage telemetry on Claim records + `receipts.log` (per-run cost auditing without CloudWatch); end-of-run cost summary on every agent command (v0.1.19+); `--dry-run` / `--dump-prompt` for prompt audit (v0.1.20+)
- Documentation report JSON sidecar schema v1.1 (`controls_mapped` + aggregate `boundary_state` per attestation; v0.1.11)
- Cosign-verifiable SLSA build provenance attached to every container release via `actions/attest-build-provenance` (v0.1.13+)
- `PLW1514` (unspecified-encoding) enforced at lint time + `EXPECTED_DETECTORS` source-level pin in `tests/test_triage_constant_alignment.py` (v0.1.29) — both caught real drift at PR time across the v0.1.28–v0.1.34 detector backlog

**Authoritative sources for "what's in":**
- `CHANGELOG.md` — release-by-release record. Don't restate it here.
- `git log` — commit-level history
- `DECISIONS.md` — append-only architectural decision log; every non-trivial choice is here
- `docs/followups.md` — tracker for v0.1.x and v0.2.0+ deferred work

**Canonical dogfood target:** `lhassa8/govnotes-demo`. 24 documented "deliberate gaps" spanning 16 KSIs across 8 themes, plus 3 Evidence Manifests for procedural AFR/CED/INR theme KSIs. Synthetic FedRAMP boundary built specifically for compliance-scanning evaluation. Re-running the full pipeline against it costs ~$2.60 in Anthropic API and is the reference test for any non-trivial Efterlev change. The repo's own `efterlev-scan.yml` workflow runs the full pipeline on every push touching infra/workflows/manifests.

**What's deferred** (not in v0.1.x): OSCAL-shaped SSP/AR/POA&M JSON generators (v1.5+, gated on customer pull); non-Terraform input sources (CloudFormation, CDK, Pulumi, Kubernetes — v1.5+); CMMC 2.0 overlay (v1.5+); runtime cloud API scanning (different threat model — v1.5+). The streaming refactor of the Anthropic client previously listed here as v0.2.0 work shipped in v0.1.47 (DECISIONS PR #219, implementation PRs #220 + #221).

---

## Path forward (v0.1.57+)

The v0.1.12–v0.1.16 arc closed the post-release-validation feedback loop:
findings F1–H1 + the v0.1.16 first-of-kind auto-triage findings all landed
through the same shape — ship → triage → fix in next release. The
methodology is now codified as `scripts/triage.sh` + `.github/workflows/post-release-triage.yml`,
which auto-runs on every tag push and posts the report as the GitHub
Release notes body, with T7 surfacing matrix conclusion (v0.1.22+).

**Tier 1 fully complete.** All four originally-planned Tier 1 items
shipped: #1 quickstart (v0.1.18), #2a cost summary (v0.1.19), #2b
`--dry-run`/`--dump-prompt` (v0.1.20), #3 manifest starter pack (v0.1.21),
#4 detector gap analysis + 6-detector backlog (v0.1.28–v0.1.34). KSI
coverage moved from 30/60 to 36/60 across the #4 sequence — exactly
matching the DECISIONS 2026-05-07 design entry's projected outcome.

### Tier 1 — shipped (per DECISIONS 2026-05-06 sequencing)

- ~~#1 `efterlev quickstart`~~ **shipped at v0.1.18.** One-command
  activation demo for ICP A's day-one experience. Bundled FIXTURE +
  `python -m efterlev` entry point.
- ~~#2a end-of-run cost summary~~ **shipped at v0.1.19.** Token usage
  surfaced at agent-command stdout (model, tokens in/out, $ estimate).
- ~~#2b `--dry-run` / `--dump-prompt`~~ **shipped at v0.1.20.** Prints
  the assembled, scrubbed prompt and exits without calling Claude.
  3PAO-grade audit primitive.
- ~~#3 Manifest starter pack~~ **shipped at v0.1.21 (24 templates); expanded
  to 26 at v0.1.36** with KSI-MLA-RVL + KSI-SVC-EIS, closing the
  Tier 1 #4 design entry's projected manifest follow-ups. Hand-authored
  Evidence Manifest templates (10 AFR + 4 CED + 3 INR + 4 PIY + 1 each
  CMT-RVP / RPL-RRO / SVC-PRR / MLA-RVL / SVC-EIS).
  `efterlev manifests init --starter-pack` copies them into
  `.efterlev/manifests/starter-pack/` (subdir, outside the loader's
  pickup glob — safe by default; `--force` to overwrite).
- ~~#4 Detector gap analysis + prioritized adds~~ **shipped at v0.1.28–v0.1.34
  (6/6 detectors per DECISIONS 2026-05-07 backlog).** `aws.cna_optimizing_for_availability`
  (v0.1.28); `aws.mla_log_access_least_privilege` (v0.1.30);
  `aws.cna_dos_protection` (v0.1.31); `aws.svc_at_rest_encryption_coverage`
  (v0.1.32); `aws.rpl_backup_configured` (v0.1.33);
  `github.piy_sdlc_security_gates` (v0.1.34). All six classified
  `evidenceable-via-iac` or `partial` per the design; the 24
  `procedural-only` KSIs identified in the same analysis are covered
  by the v0.1.21 starter pack (with two follow-up templates pending —
  KSI-MLA-RVL + KSI-SVC-EIS).

### Small follow-ups (when convenient)

- **2 Evidence Manifest templates** for the procedural-only KSIs the
  v0.1.21 starter pack didn't cover: `KSI-MLA-RVL` (log review) and
  `KSI-SVC-EIS` (security improvement review). Single small PR.

### Tier 2 — serverless detector batches (shipped)

- **Tier 2 #1** — `aws.lambda_logging_configured`,
  `aws.api_gateway_tls_min_version` + `serverless-mixed` fixture
  (DECISIONS 2026-05-09 PR #196; v0.1.44).
- **Tier 2 #2** — `aws.lambda_env_kms_encryption`,
  `aws.api_gateway_access_logging` + serverless-mixed rev 2
  (DECISIONS 2026-05-10 PR #200; v0.1.44).
- **Tier 2 #3** — `aws.lambda_vpc_isolation`,
  `aws.api_gateway_auth_required`, `aws.api_gateway_waf_attached` +
  serverless-mixed rev 3 (DECISIONS 2026-05-10 PR #205; v0.1.45).
  Closes the original 5-detector deferred backlog from PR #196.
- **Tier 3 #1** — `aws.waf_rule_count`, `aws.waf_managed_rule_groups`,
  `aws.waf_rate_limiting` + serverless-mixed rev 4 (DECISIONS 2026-05-10
  PR #213; v0.1.46). Closes the WAF posture-quality dimension that
  the Tier 2 #3 attachment-only detector left unaddressed.
- **Tier 3 #2** — Anthropic-client streaming refactor + Gap Agent
  max_tokens cap lift 20480 → 32768 (DECISIONS 2026-05-10 PR #219;
  implementation PRs #220 + #221; v0.1.47). Removes the deterministic
  Anthropic-direct ceiling that PR #217 surfaced as a recurring flake;
  unblocks fixture growth and customer-codebase scans previously
  gated by the cap.
- **Tier 3 #3** — `aws.waf_action_types` + `aws.waf_ip_set_blocking`
  + serverless-mixed rev 5 (DECISIONS 2026-05-10 PR #223;
  implementation PRs #224 + #225 + #226; v0.1.48). Closes the
  action-type + IP-set-blocking dimensions deferred from Tier 3 #1
  Decision #7. `waf_ip_set_blocking` is the first WAF detector to
  evidence AC-3 (Access Enforcement) at the IaC layer.
- **Tier 3 #4** — `aws.waf_geo_blocking` + serverless-mixed rev 6
  (DECISIONS 2026-05-10 PR #229; implementation PRs #230 + #231;
  v0.1.49). Closes the geo-blocking dimension deferred from Tier 3
  #1 Decision #7. First WAF-family detector to evidence SC-7
  (Boundary Protection) at the IaC layer.
- **Tier 3 #5** — `aws.waf_custom_rule_groups` + serverless-mixed
  rev 7 (DECISIONS 2026-05-10 PR #233; implementation PRs #234 +
  #235; v0.1.50). Cross-resource detector closing the WAF family
  at 7/7 v0/v1 dimensions. The `defined_rule_groups` inventory
  surfaces the "defined but unreferenced" anti-pattern for the
  Gap Agent. The 5-batch WAF arc spanning v0.1.46–v0.1.50 is now
  complete.
- **Tier 4 #1** — ConMon Lite v0 (DECISIONS 2026-05-11 PR #237;
  implementation PRs #238 + #239; v0.1.51). PR-delta scan
  comparison with sticky comments. Scanner-only (deterministic +
  free).
- **Tier 4 #2** — ConMon Lite v1 (DECISIONS 2026-05-11 PR #241;
  implementation PRs #242 + #243; v0.1.52). Gap-Agent KSI-verdict
  regression diff with 2-of-3 majority voting. Closes the
  verdict-stability deferral from Tier 4 #1. Opt-in via
  `EFTERLEV_CONMON_LITE_V1` repo variable (default OFF; per-PR
  cost ~$0.90 on Sonnet 4.6).

### Tier 2 — held; each gets its own DECISIONS entry when promoted

- **ConMon Lite v2 candidates** — configurable severity thresholds,
  gating policy (block-on-regress with skip label), drift detection
  over time (not just PR-delta), suppression annotations
  (`# efterlev-ignore: KSI-X`).
- **`aws.waf_*` further extensions** beyond v0/v1 (version pinning,
  scope-down breadth, custom-aggregation keys, action-type
  appropriateness per managed-group). Tier 4 candidates; each
  warrants its own scoping pass when there's customer pull or
  specific findings.
- **Cross-platform CI gate on every PR** (Tier 2 candidate from
  DECISIONS 2026-05-07 v0.1.25 entry — would catch Windows-cascade-style
  bugs at PR time, not only at tag time). Tradeoff: doubles CI minutes
  per PR; held until Actions minutes negotiation.
- CloudFormation/CDK source support (ICP doc names this v1 month 1–2).
- Boundary-scoping interactive helper.
- Detector scaffolder for OSS-contribution friction reduction.
- Branch-protection-rule detection (Tier 1 #4 design called this out
  as a follow-up to `github.piy_sdlc_security_gates` — needs the
  GitHub Terraform provider + `github_branch_protection` reader).

### Out of scope this cycle (decline if proposed)

No web UI. No SaaS / multi-tenancy. No runtime cloud API scanning. No CMMC
overlay. No additional frameworks (SOC 2, ISO 27001, HIPAA, etc.). No
Pulumi or Kubernetes support yet. If you find yourself proposing any of
these, stop and ask before continuing.

### Working agreement (carries forward unchanged)

- Each Tier 1 item lands as its own PR with its own DECISIONS entry surfaced
  for review *before* implementation starts.
- LIMITATIONS.md and the relevant docs update in the *same PR* as the
  feature — never deferred to a follow-up. The check-docs path-shape +
  current-version-claim rules (v0.1.12 + v0.1.14) and the auto-triage T6
  phase enforce this on every release.
- Per-fix regression test discipline (CLAUDE.md "Per-fix regression test
  discipline (v0.1.10+)") applies to every patch in this sequence.
- **Source-level pin tests** for platform-specific fixes (the v0.1.23–v0.1.27
  pattern). When a fix is platform-gated, add a test that reads the source
  and asserts the platform check + fix shape are present. A/B-verify before
  commit (revert fix → test fails with prod's exact error). This catches
  regressions on every dev platform without needing the failing platform's
  CI runner.

---

## Known gotchas (v0.1.x lessons)

These have all surfaced in real CI, so they're not theoretical:

- **Anthropic non-streaming threshold.** `client.messages.create()` rejects requests whose `max_tokens` could plausibly take >10 minutes ("Streaming is required for operations that may take longer than 10 minutes"). Empirically, `max_tokens > ~24000` for Opus 4.7 trips this on real workloads. v0.1.2 holds the Gap Agent at 20480 — enough headroom over the v0.1.0 truncation site (~16384 was too small for a full-baseline classification with substantive rationales). Pushing the cap past ~24K means switching to `client.messages.stream()`. Don't bump the cap blindly.

- **`.efterlev/manifests/` committed; everything else gitignored.** This is the canonical Evidence-Manifest pattern. A fresh clone has the workspace dir present (because manifests are checked in) but the FRMR cache, provenance store, etc. missing. `report run` and `init` both check for the FRMR cache file (`.efterlev/cache/frmr_document.json`), not just the dir, to distinguish "fully initialized" from "half-initialized." If you change the init-detection logic, preserve this distinction.

- **`__version__` lives in `src/efterlev/__init__.py` only.** `pyproject.toml` reads it via `[tool.hatch.version] path = "src/efterlev/__init__.py"`. There's a CI-time regression test (`test_in_source_version_matches_package_metadata`) that asserts `efterlev.__version__ == importlib.metadata.version("efterlev")`. Bumping the version means editing `__init__.py` only and rebuilding (uv sync handles this on dev; hatch handles it on the wheel build).

- **`# nosemgrep:` annotations need the full registry-resolved rule_id, not the short name.** Bare `# nosemgrep` (suppress all on the line) works; `# nosemgrep: dangerous-subprocess-use-audit` does NOT, because semgrep matches against `python.lang.security.audit.dangerous-subprocess-use-audit.dangerous-subprocess-use-audit` (the full path from the registry pack). Caused every push-event ci-security run on main to fail silently from v0.1.0 launch through v0.1.1.

- **`python-hcl2` doesn't resolve `${...}` interpolations.** Detectors matching string literals (e.g., `policy_arn == "arn:aws:iam::aws:policy/AdministratorAccess"`) miss when the source uses `arn:${local.partition}:iam::aws:...`. For test targets, hardcode `arn:aws:`. For real-world detection robustness, use plan-JSON mode (`efterlev scan --plan plan.json`) which gives Terraform-resolved values.

- **GitHub-source detectors fire only when the scan target sees `.github/workflows/`.** `efterlev scan --target infra/terraform/` skips them. For mixed-content repos, scan from repo root (`--target .`) — `.tf` files are still found via rglob.

- **Bedrock client needs `read_timeout=600` + boto retries disabled, AND a tight OUR-retry loop on top (v0.1.42).** boto3 defaults to `read_timeout=60` + 3 retries. Gap Agent prompts (60 KSIs × evidence) routinely exceed 60s; the 3 retries triple wasted cost before our retry loop fires. v0.1.3's `bedrock_client._client()` sets `Config(read_timeout=600, connect_timeout=10, retries={"max_attempts": 1})`. Don't remove that config — it's load-bearing for any first-run on Opus 4.7. **v0.1.42 added the OUR-side retry-loop tightening:** ReadTimeoutError caps at `_MAX_READ_TIMEOUT_RETRIES=1` (each ReadTimeout burns 600s — 3 retries = 30 min of silent wedge), `_MAX_TOTAL_WALL_SECONDS=1200` hard ceiling on the entire `complete()` call, and `_emit_progress()` writes `[bedrock] …` lines to stderr (with flush) so the user sees retry attempts even with logging unconfigured. Surfaced by the v0.1.35 deep-test session where `report run` wedged for 24 minutes at 0% CPU on a single agent call. Don't loosen the ReadTimeout cap or the wall-clock ceiling without re-thinking the silent-wedge failure mode.

- **LLMs occasionally wrap structured output in ` ```json ` fences** despite explicit system-prompt instructions to return raw JSON (Opus 4.6 on Bedrock especially). v0.1.3's `agents.base._strip_code_fences` strips them defensively before `json.loads`. Raw JSON passes through unchanged. Test coverage in `tests/test_agents.py::test_strip_code_fences_*`.

- **Bedrock model defaults go stale across model releases.** `init --llm-backend=bedrock` probes `bedrock.list_inference_profiles(typeEquals="SYSTEM_DEFINED")` and picks the latest available Anthropic Opus when `--llm-model` is unset. The hardcoded `DEFAULT_BEDROCK_MODEL` is the fallback when probing fails. **Probe semantics (v0.1.36+):** filters to `us.*` cross-region inference profiles ONLY (excludes `eu.*`/`apac.*`/`global.*` — `global.*` forfeits the US-region geographic guarantee some FedRAMP boundary documentation depends on). Sorts by parsed `(major, minor, date_int, rev)` tuple — NOT lexically. v0.1.0–v0.1.36 used a lexical sort that picked Opus 4.0 over Opus 4.1 (`4-2…date` outranked `4-1…` lexically because `2`>`1` at position 14). The parser handles both modern (`claude-opus-4-7-v1:0`, `claude-opus-4-1-20250805-v1:0`) and legacy (`claude-3-opus-…`, `claude-3-5-sonnet-…`, `claude-3-7-sonnet-…`) ID shapes. The helper supports `opus`/`sonnet`/`haiku` families; today only Opus is wired to the init probe — per-agent Sonnet/Haiku Bedrock defaults are a Tier 2 candidate. Tests in `tests/test_bedrock_probe.py` lock the contract.

- **`gh run list` collapses workflow_run state to one column.** A matrix workflow can have every cell failing while the row shows "queued" or "in_progress" — the workflow_run row only flips to "failure" once ALL cells have a definite outcome, and matrix cells that never get scheduled keep the workflow in queued state indefinitely. v0.1.20–v0.1.21 shipped with `release-smoke` red across every cell because nobody noticed via the collapsed view. v0.1.22 added T7 to `scripts/triage.sh` to surface matrix conclusion on the GH Release page so this can't recur. Always check `gh run view <id>` per-cell when a matrix workflow looks "still running" for an unusually long time.

- **Windows / `efterlev` cross-platform pitfalls (v0.1.23–v0.1.27 cascade).** Five distinct categories the silent matrix masked, all now fixed + locked with source-level pin tests. Avoid re-introducing:
  - **`fcntl` is POSIX-only.** Use the platform-gated `_flock_exclusive` / `_flock_release` helpers in `efterlev.provenance.receipts` (fcntl on POSIX, msvcrt on Windows). `tests/test_receipts_locking.py::test_no_unconditional_fcntl_import_in_receipts` fails the suite if a top-level `import fcntl` reappears.
  - **`Path.open()` defaults to OS-default encoding** (cp1252 on Windows). For any file containing non-ASCII (FRMR catalog, manifests, source files), pass `encoding="utf-8"` explicitly. **Enforced at lint time by ruff `PLW1514`** since v0.1.27+ — every new `Path.open()` / `read_text()` / `write_text()` / text-mode `tempfile.NamedTemporaryFile` call must pass `encoding=`. `tests/test_frmr_loader.py::test_loader_source_explicitly_passes_utf8_to_open` adds a targeted source-level pin on the FRMR loader.
  - **`sqlite3.connect()` defaults to read-write.** When the SQLite store may be on read-only media or root-owned (docker-ghcr scenario), use URI mode: `sqlite3.connect(f"file:{path}?mode=ro&immutable=1", uri=True)`. The `immutable=1` flag is required if the store uses `PRAGMA journal_mode=WAL` (ours does) — `mode=ro` alone fails because WAL still needs a writable journal-file open in the dir.
  - **`msvcrt.locking()` is byte-range based** (unlike POSIX `fcntl.flock` which locks the whole file). With `O_APPEND`, file position advances after each write, so unlock targets a different byte range than lock. Always `os.lseek(fd, 0, os.SEEK_SET)` before both lock and unlock so they target the same byte range. `tests/test_receipts_locking.py::test_windows_lock_helpers_lseek_to_byte_zero_before_lock_and_unlock` pins this.
  - **Windows console default encoding is cp1252.** `cli/main.py` reconfigures `sys.stdout` and `sys.stderr` to UTF-8 at import time on Windows so non-Latin-1 chars in CLI output (⚠ etc.) don't crash with `UnicodeEncodeError`. `tests/test_cli_windows_stdio.py` pins this.

---

## Non-negotiable principles

These override local convenience. If you feel tempted to violate one, stop and ask.

1. **Evidence before claims.** Deterministic scanner output is primary, high-trust, citable. LLM-generated content (narratives, classifications, mappings, remediation proposals) is secondary, carries confidence levels, and is explicitly marked "DRAFT — requires human review" in output. The two classes are visible in the data model, the FRMR output, and every rendered report.
2. **Provenance or it didn't happen.** Every generated claim — finding, narrative, classification, remediation — emits a provenance record linking it to its upstream sources (detector output, evidence records, LLM calls). No exceptions, not for speed, not for demo polish.
3. **FRMR primary, OSCAL secondary.** The user-facing layer is KSIs and Themes; 800-53 Controls remain first-class because KSIs reference them, but they're the underlying layer. FRMR-compatible JSON is what the Documentation Agent produces. OSCAL-shaped output generators are v1.5+ for users transitioning Rev5 submissions. The internal data model is our own Pydantic types; FRMR and OSCAL are produced at the output boundary, not used as internal representations.
4. **Detectors are the moat; primitives are the interface.** The detection library is a community-contributable asset. Each detector is a self-contained folder a contributor can add without touching the rest of the codebase. Primitives are the stable, MCP-exposed surface over which agents reason.
5. **Agent-first, pragmatically.** Every primitive is exposed via the MCP server. External agents (other Claude Code sessions, third-party tools) can discover and call every primitive. Our own agents prefer the MCP interface because it proves the architecture, but direct Python imports are acceptable when they materially improve performance or reliability.
6. **Drafts, not authorizations.** Efterlev never claims to produce an ATO, a pass, or a guarantee of compliance. It produces drafts that accelerate the human/3PAO process. This is not hedging; it's the truth, and it's the only claim that survives serious scrutiny.
7. **Honesty over polish.** If a detector can't prove a KSI, say so in the docstring's "does NOT prove" section. If a feature exists in docs but not in code, fix the docs, not the code (unless the code should exist). Overclaiming is the failure mode 3PAOs reject tools for.

---

## Tech stack

- **Language:** Python 3.12
- **Dependency management:** `uv`
- **Typing:** Pydantic v2 for all primitive I/O. No untyped dicts crossing a primitive boundary.
- **FRMR:** `FRMR.documentation.json` vendored from `FedRAMP/docs` into `catalogs/frmr/`. Single authoritative JSON file (`info`, `FRD`, `FRR`, `KSI`). On load, validated against `FedRAMP.schema.json` (JSON Schema draft 2020-12). On output, attestation artifacts use Pydantic structural validation (`extra="forbid"` + strict literals) — FedRAMP has not published an attestation-output schema, so the catalog schema doesn't apply to our output.
- **OSCAL (input only at v0.1.0):** `compliance-trestle` 4.x for loading the vendored NIST SP 800-53 Rev 5 catalog. OSCAL *output* generation is v1.5+.
- **MCP:** Official Anthropic Python SDK. Stdio transport.
- **LLM backends:** `LLMClient` protocol with `AnthropicClient` (direct API) and `AnthropicBedrockClient` (Converse API). Default model `claude-opus-4-7` for Gap and Remediation; `claude-sonnet-4-6` for Documentation. Centralize client instantiation in `src/efterlev/llm/__init__.py` — do not scatter `anthropic.Anthropic()` calls across agent files.
- **Storage:** SQLite for the provenance index. Content-addressed blob store on disk under `.efterlev/store/` (SHA-256 filenames). Append-only.
- **CLI:** Typer. Single entry point: `efterlev`.
- **IaC parsing:** `python-hcl2` for `.tf` files. `terraform show -json` plan output normalizes through `efterlev.terraform.parse_plan_json` into the same `TerraformResource` shape detectors consume.
- **Testing:** `pytest`. Every primitive and detector has ≥1 happy-path and ≥1 error-path test. No coverage targets — we optimize for confidence, not numbers.
- **Formatting:** `ruff` for lint + format (`PLW1514` opt-in via `preview = true` + `explicit-preview-rules = true` enforces explicit `encoding=` on every text-mode file open). `mypy --strict` on `src/efterlev/{primitives,detectors,oscal,manifests}.*`.
- **Docs:** MkDocs Material at `efterlev.com`.

---

## Repository layout

```
efterlev/
├── CLAUDE.md                          # this file
├── README.md                          # user-facing
├── CHANGELOG.md                       # release history (Keep a Changelog)
├── CONTRIBUTING.md, CODE_OF_CONDUCT.md, GOVERNANCE.md
├── DECISIONS.md                       # running log of non-trivial choices — APPEND-ONLY
├── LIMITATIONS.md                     # honest scope: what the tool does and doesn't do
├── THREAT_MODEL.md                    # security posture
├── COMPETITIVE_LANDSCAPE.md           # honest positioning
├── SECURITY.md                        # coordinated disclosure
├── LICENSE                            # Apache 2.0
├── docs/
│   ├── architecture.md, faq.md, quickstart.md, deployment-modes.md
│   ├── ai-quickstart-prompt.md        # canonical AI-assistant-driven runbook
│   ├── aws-coexistence.md             # how Efterlev fits next to AWS Config / Security Hub
│   ├── csx-mapping.md                 # how Efterlev's outputs map to CSX-SUM/MAS/ORD
│   ├── ci-integration.md              # GitHub Action setup
│   ├── deploy-govcloud-ec2.md         # GovCloud EC2 + Bedrock walkthrough
│   ├── detector-mapping-audit.md      # KSI-mapping audit trail
│   ├── dual_horizon_plan.md           # roadmap beyond v0.1.x
│   ├── followups.md                   # v0.1.x and v0.2.0+ deferred work; Done section
│   ├── icp.md                         # Ideal Customer Profile
│   ├── manual-verification-runbook.md
│   ├── RELEASE.md                     # release process + verify-release.sh contract
│   ├── security-review-2026-04.md     # pre-launch security review (signed)
│   ├── v0.2-eval-harness-plan.md      # design sketch for v0.2 agent-quality harness
│   ├── concepts/, tutorials/, comparisons/, reference/   # public docs site
│   └── specs/                          # internal SPEC documents
├── src/efterlev/
│   ├── models/                        # Pydantic types (Indicator, Control, Evidence, Claim, ...)
│   ├── frmr/                          # FRMR loader + validator + generator
│   ├── oscal/                          # 800-53 catalog loader; OSCAL output generator (v1.5+)
│   ├── detectors/
│   │   ├── aws/<capability>/          # one folder per detector
│   │   └── github/<capability>/       # github-workflows detectors
│   ├── primitives/{scan,map,evidence,generate,validate}/
│   ├── manifests/                     # Evidence Manifest loader + types
│   ├── terraform/                     # HCL + plan-JSON parsing
│   ├── github_workflows/              # workflow YAML parsing
│   ├── llm/                           # LLMClient protocol + scrubber + retry/fallback
│   ├── mcp_server/
│   ├── agents/                        # gap.py + gap_prompt.md, etc.
│   ├── provenance/                    # store + walker
│   ├── reports/                       # HTML renderers
│   └── cli/
├── catalogs/{frmr,nist}/              # vendored reference data
├── demo/govnotes/                     # sample target app
├── scripts/                           # e2e_smoke.py, ci_pr_summary.py, verify-release.sh, ...
└── tests/
```

When adding new detectors, match the source/capability folder. When adding primitives, match the capability verb (`scan`, `map`, `evidence`, `generate`, `validate`). If it doesn't fit, propose a new subfolder before creating it.

---

## The detector contract

A detector is a self-contained artifact. One folder per detector. A contributor can add a new detector without reading the rest of the codebase. This is the #1 design commitment for long-term project health.

Each detector folder contains:

- **`detector.py`** — pure function, typed input/output. Reads source material (Terraform resources, GitHub workflow YAML), emits `Evidence` records.
- **`mapping.yaml`** — which KSI(s) this detector evidences, plus the underlying 800-53 control(s). Multi-target mappings are fine.
- **`evidence.yaml`** — template describing the shape and semantics of evidence this detector produces. Internal schema, not FRMR or OSCAL.
- **`fixtures/`** — `should_match/` and `should_not_match/` samples the test harness runs against.
- **`README.md`** — what this detector checks, what it proves, what it does NOT prove, known limitations. The "does NOT prove" section is required.

Detector IDs are capability-shaped (what the detector checks), not control-shaped. KSIs think in capabilities; IDs like `encryption_s3_at_rest` age better than `sc_28_s3_encryption` as the KSI ↔ control mapping evolves.

**Two mapping disciplines applied across the catalog:**

1. **`ksis=[]` is honest when no KSI maps the control.** SC-28 (encryption at rest) is the largest example: 5 of the 7 supplementary 800-53-only detectors carry `ksis=[]` because FRMR 0.9.43-beta does not list SC-28 in any KSI's `controls` array. Their evidence surfaces in the gap report's "Unmapped findings" section. Tracked as an upstream FRMR issue, not an Efterlev mapping mistake.
2. **Control membership in a KSI's `controls` array is necessary but not sufficient for claiming the KSI.** The detector must also evidence what the KSI's *statement* commits to. Example: IA-5 appears in KSI-IAM-MFA's controls, but `aws.iam_password_policy` does NOT claim KSI-IAM-MFA — password policy doesn't evidence phishing-resistant MFA.

See `docs/detector-mapping-audit.md` for the full per-detector audit.

---

## The primitive contract

Primitives are the MCP-exposed agent interface. Small and stable.

**Two classes of primitives, different contracts:**

**Deterministic primitives** — scan, map, validate, parse, hash, serialize. Pure where possible. Side-effecting primitives (write files, open PRs) are flagged.

```python
@primitive(capability="scan", side_effects=False, version="0.1.0", deterministic=True)
def scan_terraform(input: ScanTerraformInput) -> ScanTerraformOutput:
    """Run all applicable detectors against a Terraform source tree."""
```

**Generative primitives** — narrative synthesis, classification, remediation. LLM-backed. Output carries confidence levels and a `requires_review: Literal[True]` flag.

**Shared rules:**
- Verb-noun snake_case name
- One Pydantic input model, one Pydantic output model
- Docstring states intent, side effects, deterministic/generative, external dependencies
- Emits a provenance record via decorator machinery — you do not write provenance code inside the function body
- Auto-registered with the MCP server by the decorator
- No `print`; use the standard logger
- Raises typed exceptions from `efterlev.errors`, never bare `Exception`

---

## The agent contract

Every agent:

- Subclasses `efterlev.agents.base.Agent`
- Has its system prompt in a sibling `.md` file (`gap.py` → `gap_prompt.md`). **Prompts are product code — do not inline them as Python strings.**
- Consumes primitives via the MCP tool interface by default. Direct imports from `efterlev.primitives.*` are allowed when MCP round-tripping adds no value; flag the choice in the agent's docstring.
- Produces a typed output artifact on our internal model (e.g. `GapReport`, `AttestationDraft`, `RemediationProposal`). FRMR and OSCAL serialization are separate generator steps, not the agent's job.
- Logs every tool call, model response, and final artifact to the provenance store
- Is invokable standalone from the CLI: `efterlev agent <name> [options]`

**When you write or revise an agent's system prompt, surface the full diff in chat for review before committing.** Agent prompts are the product's brain; they deserve human sign-off even when code doesn't.

**Hallucination defenses are structural, not advisory:**
- Every agent prompt wraps evidence in `<evidence_NONCE id="sha256:...">...</evidence_NONCE>` XML fences, with a per-run nonce (`secrets.token_hex(4)`) that prevents content-injected forged fences.
- A post-generation validator rejects any output that cites evidence IDs not present as fences in the prompt the model actually saw.
- `ProvenanceStore.write_record` validates every Claim's `derived_from` at write time — unresolvable IDs raise `ProvenanceError` before insertion.
- Every Claim carries `requires_review: Literal[True]` at the type level — not a string, not a flag.

**Secret redaction is unconditional:** every LLM prompt is scrubbed for 7 secret families (AWS, GCP, GitHub, Slack, Stripe, PEM, JWT) before egress. The scrubber lives in `src/efterlev/llm/scrubber.py`; it's called by `format_evidence_for_prompt` and `format_source_files_for_prompt` in `agents/base.py` with no opt-out path. Each redaction writes to `.efterlev/redactions/<scan_id>.jsonl` (mode `0o600`); `efterlev redaction review` renders the log.

**LLM calls degrade predictably:** transient Anthropic errors retry with exponential backoff + full jitter (3 attempts on primary). Primary-model exhaustion falls back once to a configured secondary (Opus 4.7 → Sonnet 4.6 by default) before surfacing.

---

## Evidence vs. claims: the data model

Two distinct types, treated differently throughout the system. See `src/efterlev/models/evidence.py` and `claim.py` for the canonical definitions.

- **`Evidence`** — deterministic, scanner-derived, content-addressed by SHA-256. Fields: `evidence_id`, `detector_id`, `ksis_evidenced`, `controls_evidenced`, `source_ref` (file + line + commit), `content`, `timestamp`.
- **`Claim`** — LLM-reasoned, content-addressed. Fields: `claim_id`, `claim_type` (narrative / classification / remediation / mapping), `content`, `confidence`, `requires_review: Literal[True]`, `derived_from`, `model`, `prompt_hash`, `timestamp`.

Every rendered output — HTML report, FRMR artifact, terminal summary — visually distinguishes Evidence (green left border) from Claims (amber, with the DRAFT banner). Manifest-sourced citations carry an additional "attestation" pill to distinguish human-signed from scanner-derived evidence.

---

## Provenance model

Every claim is a node in a directed graph. Edges point from derived claims to upstream sources.

```python
class ProvenanceRecord(BaseModel):
    record_id: str                      # sha256 of canonical content
    record_type: Literal["evidence", "claim", "finding", "mapping", "remediation"]
    content_ref: str                    # path in blob store
    derived_from: list[str]             # upstream record_ids (evidence or claim)
    primitive: str | None               # "scan_terraform@0.1.0"
    agent: str | None                   # "gap_agent" if agent-mediated
    model: str | None                   # "claude-opus-4-7" if LLM-involved
    prompt_hash: str | None             # hash of system prompt if LLM-involved
    timestamp: datetime
    metadata: dict
```

Rules:
- A record with `derived_from=[]` is raw evidence or a primitive input. Any reasoning step must carry its inputs forward.
- Records are immutable and append-only. New evidence for a KSI creates a new record; it does not overwrite the old one.
- `efterlev provenance show <record_id>` walks the chain to source-file line ranges.

When you implement a primitive or agent that generates records, **write the provenance walk test first**. If the chain doesn't resolve end-to-end, the feature isn't done.

---

## Quality bar

- **Every detector:** typed I/O, docstring with "proves / does NOT prove," fixtures for should-match and should-not-match, passing tests, plan-JSON equivalence test.
- **Every primitive:** typed I/O, docstring, ≥1 happy test, ≥1 error test, FRMR validation on output where applicable, provenance record emitted.
- **Every agent:** system prompt in its own file, provenance-emitting, CLI-invokable, end-to-end test against the demo repo.
- **Every commit:** `ruff check` clean (incl. `PLW1514` unspecified-encoding), `ruff format --check` clean, `mypy --strict` clean on core paths, tests passing.
- **Every non-trivial decision:** appended to `DECISIONS.md` with date, decision, rationale, alternatives considered.

## Per-fix regression test discipline (v0.1.10+)

**Every bug-fix patch ships with a test that would have caught the bug.** No exceptions for "obviously correct" fixes — those are the patches that historically introduced new bugs (the v0.1.7 doc dual-emit was an "obviously correct" v0.1.4 deterministic-template path). Pick the right test layer for the bug class:

| Bug class | Test layer | Examples from v0.1.5–0.1.9 |
|---|---|---|
| Single function / pure logic | unit (`tests/test_*.py` near the function) | prefix-resolve scope, KSI dedup logic, manifest-in-boundary special case |
| Cross-component (model→store→render) | integration in `tests/test_<feature>_*.py` | doc dual-emit dedup, boundary state propagation |
| Real environment / install / CLI | E2E smoke (`scripts/e2e_smoke.py`) | uv-vs-pipx hint, max_tokens default, terraform-init backend block |
| Doc drift | check-docs CI job | README test count, KSI naming in DELIBERATE_GAPS |
| Detector registry | detector fixture under `src/efterlev/detectors/<name>/fixtures/` | sbom-action recognition, govulncheck CVE scanner |

The test should fail without the fix and pass with it — verify both directions during the patch cycle. The PR body should reference the regression test by name.

### A/B verification for hard-to-reproduce fixes (v0.1.24+)

For platform-specific fixes (Windows, docker-ghcr, AWS Bedrock, anything where the failure mode is gated on environment), the regression test must be **A/B-verified before commit**: revert the fix, run the test, confirm it FAILS with the same error message that prod produced. Then restore the fix.

This isn't paranoia — it's the lesson from the v0.1.23 → v0.1.24 cycle. v0.1.23 shipped with a test (`test_assert_passes_against_readonly_db`) that PASSED locally because the fixture (chmod-on-file, non-WAL) didn't match the prod failure mode (chmod-on-directory + WAL). The fix didn't actually work in prod, but the test couldn't tell. v0.1.24 strengthened the test to reproduce prod exactly (chmod on directory + WAL fixture) and A/B-verified it before commit. The cost was ~10 minutes; the benefit was avoiding one more round of "ship → fail in matrix → debug → repatch."

A/B-verification is especially valuable for:
- **Platform-gated bugs** (POSIX-only / Windows-only / docker-only) where the dev laptop can't reproduce by default. Source-level pin tests (read the source, assert the fix shape is present) plus an A/B-verified behavioral fixture is the v0.1.23–v0.1.27 pattern.
- **Filesystem-state bugs** (read-only files, root-owned dirs, exotic permissions) where the failure mode is `[Errno N]` and the test fixture must match exactly.
- **Encoding bugs** where the dev-laptop default (utf-8 on macOS / Linux) differs from CI (cp1252 on Windows). Without A/B verification, the test passes on POSIX even if the fix doesn't actually work.

The `tests/test_smoke_assert.py::test_assert_passes_against_wal_mode_readonly_dir` and `tests/test_receipts_locking.py::test_windows_lock_helpers_lseek_to_byte_zero_before_lock_and_unlock` tests are reference examples — both A/B-verified, both catch their specific prod failure mode on every platform.

### Encoding hygiene as a lint-time gate (v0.1.27+)

`PLW1514` ("unspecified-encoding") is enabled in `pyproject.toml`'s ruff config. It catches `Path.open()`, `read_text()`, `write_text()`, and `tempfile.NamedTemporaryFile(mode="w")` calls without an explicit `encoding=`. Enforced at lint time on every PR — don't rely on the OS-default encoding even on POSIX (where it happens to be utf-8 today). Pass `encoding="utf-8"` explicitly or, for binary blobs, use binary mode (`"rb"` / `"wb"` / `read_bytes()` / `write_bytes()`).

**Why this matters:** v0.1.25 + v0.1.27 in the cascade were both Windows-only encoding bugs that would have been caught by PLW1514 at PR review instead of after-tag matrix run. The enforcement closes that category of bug at lint time.

**Why this matters (the original case):** v0.1.5–0.1.9 each surfaced 3 new bugs in manual shakedowns. ~75% would have been caught by tests we could have written before shipping. The E2E smoke CI gate (v0.1.10) closes the cross-component gap automatically; this discipline closes the unit/integration gap.

### Testing tiers — pick by cost (post-v0.1.42)

Three opt-in tiers above the always-on unit suite. Pick by what the bug class needs and by what's worth burning at this point in the cycle:

| Tier | Marker | Cost | Wall | When to run |
|---|---|---|---|---|
| Unit | (default) | $0 | ~20s | Every save. Default `pytest -m "not e2e"` cycle. |
| Deep-smoke | `pytest -m deep` (`scripts/deep-test.sh`) | $0 | ~25s | Before tagging. Catches user-flow regressions that span CLI primitives — friendly-error paths, init/scan/manifest sequences, broken-HCL handling, etc. Replaces the deterministic-tier portion of the old human deep-test prompt. |
| Eval harness | `python -m evals run --fixture <path>` (`evals/`) | ~$0.04/fixture/run on Haiku-Bedrock; ~$0.12 corpus pass | ~3-5min/fixture | Before merging prompt-touching PRs. Catches the agent-quality regressions deep-smoke can't (status-classification drift, narrative quality, POAM scope discipline). 5 metrics, 3 synthetic fixtures, delta-vs-prior reporter. v0.2 Phase 1 (DECISIONS 2026-05-08); see `evals/README.md` for the operator walkthrough. |
| E2E smoke | `pytest -m e2e` | ~$0.30/run | ~7min | Required CI check on every PR (real Anthropic API call against synthetic fixture). Locks the Anthropic-backend pipeline shape. |
| Bedrock E2E | `pytest -m e2e tests/test_e2e_smoke_bedrock.py` | ~$0.30/run | ~7min | Manual; opt-in for Bedrock-specific shake-downs. |

**Why deep-smoke exists:** before v0.1.42 the way to catch user-flow bugs was to hand a fresh Claude Code session a 150-line markdown deep-test prompt and have it walk through install + init + quickstart + agent + manifests + edge cases. That session cost ~$3 and ~30 min. About 80% of the prompt was deterministic shell sequences — running them through an LLM tester was the wrong abstraction. `tests/test_deep_smoke.py` captures the deterministic 80% as 14 pytest-driven scenarios that run in ~25s with $0 cost. The remaining 20% (judgment-requiring agent-output assessments) is the eval-harness tier above.

**Why the eval harness exists:** unit tests + deep-smoke + E2E together still don't catch agent-quality regressions — the verdict-vs-ground-truth and rationale-vs-reviewability dimensions. v0.1.5–0.1.9's KSI-SVC-PRR drift, KSI-SCR-MIT "mixed" reasoning bug, and F5 manifest cross-wiring were all this class. The eval harness measures both dimensions on every prompt-touching PR via 5 metrics (M1 status precision, M2 status recall, M3 resource-naming, M4 manifest-quoting, M5 POAM scope) against ground-truth-labeled fixtures. Yellow-flag (PR comment) on > 5% regression at Phase 1; hard-blocking is Phase 3 work after noise-floor calibration. See DECISIONS 2026-05-08 "v0.2 agent-quality eval harness" for the design.

**The discipline:** when a finding from a real shakedown surfaces a bug that a unit test wouldn't have caught (because it spans CLI primitives, or the bug is in the friendly-error wrapper, or it's about subprocess behavior), the regression test goes into `test_deep_smoke.py`, not into a new unit test. Deep-smoke scenarios accumulate one user-flow lock per finding. v0.1.37 (Bedrock silent-wedge), v0.1.38 (friendly handler chain-walk + --version shadow), and v0.1.42 (init manifests-only + lifecycle-aware probe) all have unit tests AND deep-smoke scenarios — the unit tests pin the function-level behavior, the deep-smoke scenarios pin the user-flow shape.

---

## How we work together

- **Surface architectural questions immediately.** If you see a fork in the road, stop and ask. Do not silently pick and refactor later.
- **Prefer small PRs.** If a change touches more than three files outside of pure additions, flag it.
- **GitHub Actions minutes are constrained** (~90% of monthly cap as of 2026-04-28). Batch related changes into one PR; run gates locally before pushing; avoid fixup-push churn.
- **Maintain `DECISIONS.md`.** Every non-obvious choice belongs there. Append-only — historical entries stay even when the decision is later reversed; add the reversal as a new dated entry.
- **Prompts are product.** Surface system-prompt diffs in chat before committing.
- **Use the repo-scoped slash commands when they fit.** `.claude/commands/` ships six commands that compress recurring multi-file workflows. Each is a recipe template — every step is still a real human decision, but the agent doesn't have to re-derive the ritual. See `.claude/commands/README.md` for the full table; the canonical chains are:
  - **Cut a release (no detector):** `/release-housekeeping <version>` → review the PR diff → `/release-finalize <pr-number>`. The split lets you inspect the bump+drift-sweep+CHANGELOG diff before kicking off the merge+tag+verify cycle. Together they encode the v0.1.37/38/39 ritual we ran three times on 2026-05-07/08.
  - **Cut a release (new detector):** `/ship-detector <slug> <KSI-ID>` does the full release including detector folder scaffold + EXPECTED_DETECTORS bump. Don't chain this with `/release-housekeeping`; ship-detector covers the same ground.
  - **Validate a shipped release in the wild:** `/validation-prompt <version>` reads the CHANGELOG block, maps each Fixed/Added entry to a PASS/FAIL scenario, emits paste-ready markdown for the tester. Mandatory S0 baseline check catches install-shadow confusion (the v0.1.38 footgun).
  - **Surface a design decision before implementing:** `/decisions-entry <title>` drafts the DECISIONS.md entry as its own PR, per the working agreement (design lands BEFORE implementation).
  - **Snapshot the repo state at session start:** `/check-state` is the orientation read.

---

## Never do

- Never commit real secrets, API keys, or production data. The demo repo is synthetic.
- Never return FRMR (or, in v1.5+, OSCAL) output that hasn't passed Pydantic structural validation.
- Never generate a Claim without citing the Evidence records it derives from.
- Never claim the tool produces an ATO, a pass, or a guarantee of compliance. Drafts and findings only.
- Never add a dependency without a line in `DECISIONS.md` explaining why.
- Never mix Evidence and Claims in a way that loses their distinction — in the data model, in the UI, or in FRMR/OSCAL output.
- Never claim a detector proves more than it actually does. The "does NOT prove" section of the detector README is as important as the "does prove" section.
- Never invent a KSI ID that does not appear in the vendored FRMR. If coverage is genuinely missing, surface the gap and file an upstream issue; do not paper over it.
- Never bypass the secret scrubber or the fence-citation validator. Both are unconditional by design.

---

## References

- `CHANGELOG.md` — release-by-release record
- `DECISIONS.md` — append-only architectural decision log
- `LIMITATIONS.md` — honest scope of what the tool does and doesn't do
- `THREAT_MODEL.md` — security posture for the tool itself
- `COMPETITIVE_LANDSCAPE.md` — positioning against Comp AI, Vanta/Drata, RegScale OSCAL Hub, and others
- `docs/architecture.md` — deeper architectural detail
- `docs/icp.md` — the Ideal Customer Profile; lens for every product decision
- `docs/dual_horizon_plan.md` — roadmap beyond v0.1.0
- `docs/followups.md` — v0.1.x and v0.2.0+ deferred work

When any of those conflict with this file on a current-state question, this file wins and we update the others. Where this file conflicts with the actual code, the code wins and we update this file.
