﻿braindecode.datasets.BaseConcatDataset
======================================

.. currentmodule:: braindecode.datasets

.. autoclass:: BaseConcatDataset
   
   
   
   
      
   
      
   
      
         
      
   
      
   
      
   
      
         
      
   
      
         
      
   
      
         
      
   
      
         
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: get_metadata

   
   .. automethod:: save

   
   .. automethod:: set_description

   
   .. automethod:: split

   
   .. automethod:: to_epochs_dataset

   
   
   

.. include:: braindecode.datasets.BaseConcatDataset.examples

.. raw:: html

    <div style='clear:both'></div>