﻿braindecode.preprocessing.Preprocessor
======================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: Preprocessor
   
   
   
   
      
   
      
         
      
   
      
         
      
   
      
         
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: apply

   
   .. automethod:: deserialize

   
   .. automethod:: serialize

   
   
   

.. include:: braindecode.preprocessing.Preprocessor.examples

.. raw:: html

    <div style='clear:both'></div>