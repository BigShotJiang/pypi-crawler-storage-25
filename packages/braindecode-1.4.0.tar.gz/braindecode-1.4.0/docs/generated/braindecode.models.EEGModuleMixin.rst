﻿braindecode.models.EEGModuleMixin
=================================

.. currentmodule:: braindecode.models

.. autoclass:: EEGModuleMixin
   
   
   
   
      
   
      
         
      
   
      
   
      
   
      
         
      
   
      
         
      
   
      
         
      
   
      
         
      
   
      
   
      
         
      
   
      
   
      
         
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: from_config

   
   .. automethod:: get_config

   
   .. automethod:: get_output_shape

   
   .. automethod:: get_torchinfo_statistics

   
   .. automethod:: load_state_dict

   
   .. automethod:: reset_head

   
   .. automethod:: to_dense_prediction_model

   
   
   

.. include:: braindecode.models.EEGModuleMixin.examples

.. raw:: html

    <div style='clear:both'></div>