:html_theme.sidebar_secondary.remove: true

.. currentmodule:: braindecode.models

.. _models_attention:

###############################################
 |attention-icon| Attention/Transformer models
###############################################

.. |attention-icon| image:: ../../_static/model_cat/attention.png
    :alt: Attention/Transformer icon
    :height: 56px
    :class: heading-icon no-scaled-link

:bdg-info:`Attention/Transformer`

.. figure:: ../../_static/model_connection/litmap_attention.png
    :width: 100%
    :align: center

    Figure: `LitMap
    <https://app.litmaps.com/shared/43fcc2cf-9b67-48be-8c83-5e7b3764aaab>`__ **with
    attention/transformer core components for EEG architectures, last updated
    26/08/2025.** Each node is a paper; rightward means more recently published, upward
    more cited, and links show amount of citation with logaritm scale.

.. include:: ../../links.inc

.. raw:: html

    <style>
      /* nudge the icon so it sits nicely on the baseline */
      img.heading-icon { vertical-align: -0.2em; margin-right: .45rem; }
    </style>
