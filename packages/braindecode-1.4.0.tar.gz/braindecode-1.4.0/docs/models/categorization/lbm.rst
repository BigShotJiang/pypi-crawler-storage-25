:html_theme.sidebar_secondary.remove: true

.. currentmodule:: braindecode.models

.. _models_lbm:

##############################
 |lbm-icon| Foundation Models
##############################

.. |lbm-icon| image:: ../../_static/model_cat/lbm.png
    :alt: Foundation Models icon
    :height: 56px
    :class: heading-icon no-scaled-link

:bdg-danger:`Foundation Model`

.. figure:: ../../_static/model_connection/litmap_lbm.png
    :width: 100%
    :align: center

    Figure: `LitMap
    <https://app.litmaps.com/shared/e33fb41d-bc98-407f-9372-437f2b59a140>`__ **with
    foundation model layers, last updated 26/08/2025.** Each node is a paper; rightward
    means more recently published, upward more cited, and links show amount of citation
    with logaritm scale.

.. include:: ../../links.inc

.. raw:: html

    <style>
      /* nudge the icon so it sits nicely on the baseline */
      img.heading-icon { vertical-align: -0.2em; margin-right: .45rem; }
    </style>
