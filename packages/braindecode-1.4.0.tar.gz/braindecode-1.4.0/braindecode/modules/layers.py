# Authors: Robin Schirrmeister <robintibor@gmail.com>
#
# License: BSD (3-clause)
from __future__ import annotations

import torch
from einops.layers.torch import Rearrange
from torch import nn

from braindecode.functional import drop_path


class Ensure4d(nn.Module):
    """Ensure the input tensor has 4 dimensions.

    This is a small utility layer that repeatedly adds a singleton dimension at
    the end until the input has shape ``(batch, channels, time, 1)``.

    Examples
    --------
    >>> import torch
    >>> from braindecode.modules import Ensure4d
    >>> module = Ensure4d()
    >>> outputs = module(torch.randn(2, 3, 10))
    >>> outputs.shape
    torch.Size([2, 3, 10, 1])
    """

    def forward(self, x):
        while len(x.shape) < 4:
            x = x.unsqueeze(-1)
        return x


class Chomp1d(nn.Module):
    """Remove samples from the end of a sequence.

    Examples
    --------
    >>> import torch
    >>> from braindecode.modules import Chomp1d
    >>> module = Chomp1d(chomp_size=5)
    >>> inputs = torch.randn(2, 3, 20)
    >>> outputs = module(inputs)
    >>> outputs.shape
    torch.Size([2, 3, 15])
    """

    def __init__(self, chomp_size):
        super().__init__()
        self.chomp_size = chomp_size

    def extra_repr(self):
        return "chomp_size={}".format(self.chomp_size)

    def forward(self, x):
        return x[:, :, : -self.chomp_size].contiguous()


class TimeDistributed(nn.Module):
    """Apply module on multiple windows.

    Apply the provided module on a sequence of windows and return their
    concatenation.
    Useful with sequence-to-prediction models (e.g. sleep stager which must map
    a sequence of consecutive windows to the label of the middle window in the
    sequence).

    Parameters
    ----------
    module : nn.Module
        Module to be applied to the input windows. Must accept an input of
        shape (batch_size, n_channels, n_times).

    Examples
    --------
    >>> import torch
    >>> from torch import nn
    >>> from braindecode.modules import TimeDistributed
    >>> module = TimeDistributed(nn.Conv1d(3, 4, kernel_size=3, padding=1))
    >>> inputs = torch.randn(2, 5, 3, 20)
    >>> outputs = module(inputs)
    >>> outputs.shape
    torch.Size([2, 5, 4])
    """

    def __init__(self, module):
        super().__init__()
        self.module = module

    def forward(self, x):
        """
        Parameters
        ----------
        x : torch.Tensor
            Sequence of windows, of shape (batch_size, seq_len, n_channels,
            n_times).

        Returns
        -------
        torch.Tensor
            Shape (batch_size, seq_len, output_size).
        """
        b, s, c, t = x.shape
        out = self.module(x.view(b * s, c, t))
        return out.view(b, s, -1)


class DropPath(nn.Module):
    """Drop paths, also known as Stochastic Depth, per sample.

    When applied in main path of residual blocks.

    Parameters
    ----------
    drop_prob: float (default=None)
        Drop path probability (should be in range 0-1).

    Notes
    -----
    Code copied and modified from VISSL facebookresearch:
    https://github.com/facebookresearch/vissl/blob/0b5d6a94437bc00baed112ca90c9d78c6ccfbafb/vissl/models/model_helpers.py#L676

    All rights reserved.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.

    Examples
    --------
    >>> import torch
    >>> from braindecode.modules import DropPath
    >>> module = DropPath(drop_prob=0.2)
    >>> module.train()
    >>> inputs = torch.randn(2, 3, 10)
    >>> outputs = module(inputs)
    >>> outputs.shape
    torch.Size([2, 3, 10])
    """

    def __init__(self, drop_prob=None):
        super(DropPath, self).__init__()
        self.drop_prob = drop_prob

    def forward(self, x):
        return drop_path(x, self.drop_prob, self.training)

    # Utility function to print DropPath module
    def extra_repr(self) -> str:
        return f"p={self.drop_prob}"


class SqueezeFinalOutput(nn.Module):
    """

    Removes empty dimension at end and potentially removes empty time
    dimension. It does not just use squeeze as we never want to remove
    first dimension.

    Returns
    -------
    x: torch.Tensor
        squeezed tensor
    """

    def __init__(self):
        super().__init__()

        self.squeeze = Rearrange("b c t 1 -> b c t")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # 1) drop feature dim
        x = self.squeeze(x)
        # 2) drop time dim if singleton
        if x.shape[-1] == 1:
            x = x.squeeze(-1)
        return x


class SubjectLayers(nn.Module):
    """Per-subject linear transformation layer.

    Applies subject-specific linear transformations to the input. Each subject
    owns an independent weight matrix, enabling personalized feature
    processing.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        n_subjects: int,
        init_id: bool = False,
    ):
        super().__init__()
        self.weights = nn.Parameter(torch.randn(n_subjects, in_channels, out_channels))
        if init_id:
            if in_channels != out_channels:
                raise AssertionError("init_id requires in_channels == out_channels")
            self.weights.data[:] = torch.eye(in_channels)[None]
        self.weights.data *= 1 / (in_channels**0.5)

    def forward(self, x: torch.Tensor, subjects: torch.Tensor) -> torch.Tensor:
        """Apply the subject-specific linear transforms."""
        _, C, D = self.weights.shape
        weights = self.weights.gather(0, subjects.view(-1, 1, 1).expand(-1, C, D))
        return torch.einsum("bct,bcd->bdt", x, weights)

    def __repr__(self) -> str:
        S, C, D = self.weights.shape
        return f"SubjectLayers({C}, {D}, {S})"
