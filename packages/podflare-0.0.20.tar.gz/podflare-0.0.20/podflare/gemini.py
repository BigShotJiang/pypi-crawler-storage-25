"""Google Gemini integration — function-calling adapter for Podflare.

Gemini's tool-calling API uses ``Tool(function_declarations=[...])`` with
JSON-Schema-like ``parameters`` objects. This module gives you the exact
declaration shape Gemini expects, plus a one-call ``run_in_sandbox()``
helper that takes a Gemini ``FunctionCall`` and returns a
``FunctionResponse``-compatible dict.

Usage:

    from google import genai
    from google.genai import types
    from podflare import Sandbox
    from podflare.gemini import (
        podflare_function_declaration,
        run_function_call,
    )

    client = genai.Client()
    with Sandbox() as sandbox:
        contents = [
            types.Content(role="user", parts=[
                types.Part.from_text("What's the 100th prime number?")
            ]),
        ]
        while True:
            resp = client.models.generate_content(
                model="gemini-2.5-pro",
                contents=contents,
                config=types.GenerateContentConfig(
                    tools=[types.Tool(function_declarations=[
                        podflare_function_declaration()
                    ])],
                ),
            )
            contents.append(resp.candidates[0].content)

            calls = [
                p.function_call for p in resp.candidates[0].content.parts
                if p.function_call
            ]
            if not calls:
                # Final answer
                print(resp.text)
                break

            # Forward each function_call into Podflare and append the response
            response_parts = [
                types.Part.from_function_response(
                    name=c.name,
                    response=run_function_call(c, sandbox),
                )
                for c in calls
            ]
            contents.append(types.Content(role="user", parts=response_parts))

Requires: ``pip install podflare google-genai``.
"""
from __future__ import annotations

from typing import Any

from podflare.sandbox import Sandbox


def podflare_function_declaration() -> dict[str, Any]:
    """Return Gemini ``FunctionDeclaration`` JSON for the Podflare run_code tool.

    Pass into ``types.Tool(function_declarations=[podflare_function_declaration()])``
    when building your ``GenerateContentConfig``.

    Gemini's parameters schema follows OpenAPI 3.0 — slight superset of
    JSON-Schema with a ``type`` enum that uses the OpenAPI capitalized
    names (``STRING``, ``OBJECT``, ...). The google-genai SDK accepts
    either lowercase or uppercase, but we use lowercase here for
    compatibility with hand-built dict configs.
    """
    return {
        "name": "run_code",
        "description": (
            "Execute code in an isolated Firecracker-backed cloud sandbox. "
            "Supports python (default) and bash. Returns stdout, stderr, "
            "and exit_code. Filesystem and Python REPL state persist "
            "across calls within the same agent session."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "Code to execute. Single program or REPL fragment.",
                },
                "language": {
                    "type": "string",
                    "enum": ["python", "bash"],
                    "description": "Runtime: 'python' (default) or 'bash'.",
                },
            },
            "required": ["code"],
        },
    }


def run_function_call(
    function_call: Any,
    sandbox: Sandbox,
) -> dict[str, Any]:
    """Execute a Gemini ``FunctionCall`` against a Podflare sandbox.

    ``function_call`` can be a google-genai ``FunctionCall`` object, a plain
    dict shaped like ``{"name": ..., "args": {...}}``, or any object exposing
    ``.name`` and ``.args``. Returns a dict suitable for
    ``types.Part.from_function_response(name=..., response=<this>)``.
    """
    name = _get(function_call, "name") or ""
    args = _get(function_call, "args") or {}
    if not isinstance(args, dict):
        # google-genai sometimes wraps args in a Struct-like object —
        # the dict() coercion picks up its items().
        args = dict(args)

    if name != "run_code":
        # Defensive: caller may have passed in a different tool's call.
        # Return a structured error instead of raising so the model can
        # see what happened and recover.
        return {
            "error": f"podflare.gemini got unexpected function name {name!r}; "
                     f"expected 'run_code'."
        }

    code = args.get("code", "")
    language = args.get("language", "python")
    r = sandbox.run_code(code, language=language)
    return {
        "stdout": r.stdout,
        "stderr": r.stderr,
        "exit_code": r.exit_code,
    }


def _get(obj: Any, key: str) -> Any:
    """Tolerant attribute / key accessor — handles both objects and dicts."""
    if isinstance(obj, dict):
        return obj.get(key)
    return getattr(obj, key, None)
