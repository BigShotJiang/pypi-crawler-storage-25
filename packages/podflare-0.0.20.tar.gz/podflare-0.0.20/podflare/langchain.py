"""LangChain integration — a `BaseTool` that runs code in a Podflare sandbox.

Why this is high-leverage: LangChain abstracts over every major model
provider (OpenAI, Anthropic, Gemini, Mistral, Groq, Bedrock, Ollama, ...).
Wrapping Podflare as a single LangChain tool means it works with all of
them, no per-provider plumbing.

Usage:

    from langchain_openai import ChatOpenAI       # or any other LangChain chat model
    from langgraph.prebuilt import create_react_agent
    from podflare.langchain import PodflareTool

    tool = PodflareTool()                          # one sandbox, lazily created
    agent = create_react_agent(
        model=ChatOpenAI(model="gpt-5.1"),
        tools=[tool],
    )
    out = agent.invoke({"messages": [("user", "What's the 100th prime?")]})
    print(out["messages"][-1].content)

    tool.close()                                   # destroy the sandbox

The tool maintains a single sandbox across calls so REPL state (variables,
imports, files) survives between tool invocations — which is exactly what
agent loops want. Pass `persistent_sandbox=False` to force a fresh
sandbox per call instead.

Requires: `pip install podflare langchain-core` (langchain-core is small;
the broader langchain framework is optional).
"""
from __future__ import annotations

from typing import Optional

try:
    # langchain-core is a small, stable dep — only the BaseTool surface we need.
    from langchain_core.tools import BaseTool  # type: ignore[import-not-found]
    from pydantic import BaseModel, Field  # type: ignore[import-not-found]
except ImportError as e:  # pragma: no cover - runtime hint
    raise ImportError(
        "podflare.langchain requires langchain-core and pydantic. "
        "Install with: pip install langchain-core pydantic"
    ) from e

from podflare.sandbox import Sandbox


class _RunCodeInput(BaseModel):
    """Args schema. LangChain renders this as the JSON-Schema sent to the model."""

    code: str = Field(
        ...,
        description="Code to execute. Single program or REPL fragment.",
    )
    language: str = Field(
        default="python",
        description="Runtime: 'python' (default) or 'bash'.",
    )


class PodflareTool(BaseTool):
    """LangChain tool that executes code in a Podflare sandbox.

    The sandbox is lazily created on the first call and reused across all
    subsequent calls within this tool's lifetime — REPL state (variables,
    imports, open files) carries between invocations. Call ``close()``
    when your agent run finishes to destroy the sandbox.

    Set ``persistent_sandbox=False`` on construction to spin up a fresh
    sandbox per invocation (useful for adversarial / untrusted code where
    you don't want side effects to leak between calls).

    Construction args (all optional):
        host:                 Override the API base URL (default: SDK auto-detect).
        api_key:              Override PODFLARE_API_KEY env.
        template:             Sandbox template name. Default uses the standard image.
        region:               'us-west' | 'us-east' | 'us-central' | 'eu' | 'sg' | None.
        persistent_sandbox:   Reuse one sandbox across calls (default True).
    """

    name: str = "run_code"
    description: str = (
        "Execute code in an isolated Firecracker-backed cloud sandbox. "
        "Supports python (default) and bash. Returns stdout, stderr, and "
        "exit_code. Filesystem and Python REPL state persist across calls "
        "within the same agent session — variables and imports survive."
    )
    args_schema: type[BaseModel] = _RunCodeInput

    # Configuration (private — pydantic on BaseTool would normally manage these,
    # but we keep them as instance attrs to avoid leaking into the model schema).
    _host: Optional[str] = None
    _api_key: Optional[str] = None
    _template: Optional[str] = None
    _region: Optional[str] = None
    _persistent_sandbox: bool = True
    _sandbox: Optional[Sandbox] = None

    def __init__(
        self,
        *,
        host: Optional[str] = None,
        api_key: Optional[str] = None,
        template: Optional[str] = None,
        region: Optional[str] = None,
        persistent_sandbox: bool = True,
        **kwargs: object,
    ) -> None:
        super().__init__(**kwargs)
        # We bypass pydantic's setattr by using object.__setattr__ here —
        # BaseTool is a pydantic model and setting non-declared attrs on it
        # otherwise raises ValidationError. The leading underscore signals
        # they're internal config, not LangChain tool metadata.
        object.__setattr__(self, "_host", host)
        object.__setattr__(self, "_api_key", api_key)
        object.__setattr__(self, "_template", template)
        object.__setattr__(self, "_region", region)
        object.__setattr__(self, "_persistent_sandbox", persistent_sandbox)
        object.__setattr__(self, "_sandbox", None)

    def _ensure_sandbox(self) -> Sandbox:
        if self._sandbox is None or not self._persistent_sandbox:
            object.__setattr__(
                self,
                "_sandbox",
                Sandbox(
                    host=self._host,
                    api_key=self._api_key,
                    template=self._template,
                    region=self._region,
                ),
            )
        assert self._sandbox is not None
        return self._sandbox

    def _run(self, code: str, language: str = "python") -> str:
        sb = self._ensure_sandbox()
        try:
            r = sb.run_code(code, language=language)
        finally:
            if not self._persistent_sandbox:
                self.close()
        return (
            f"stdout:\n{r.stdout}\n"
            f"stderr:\n{r.stderr}\n"
            f"exit_code: {r.exit_code}"
        )

    def close(self) -> None:
        """Destroy the underlying sandbox if one was created."""
        if self._sandbox is not None:
            try:
                self._sandbox.close()
            finally:
                object.__setattr__(self, "_sandbox", None)

    def __del__(self) -> None:  # pragma: no cover - GC hook
        # Best-effort cleanup if the user forgot to close. LangChain tools
        # often outlive a single invoke() call so this matters in long
        # interactive sessions.
        try:
            self.close()
        except Exception:
            pass
