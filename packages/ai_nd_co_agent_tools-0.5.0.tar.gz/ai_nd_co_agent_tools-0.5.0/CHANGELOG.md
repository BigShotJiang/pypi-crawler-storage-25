## [0.5.0](https://github.com/ai-nd-co/agent-tools/compare/py-v0.4.0...py-v0.5.0) (2026-04-16)

### Features

* add claude code integration and transform controls ([a748070](https://github.com/ai-nd-co/agent-tools/commit/a748070dfe4b467c644ae4dbd18701807f34160e))

### Bug Fixes

* allow agent-tools to work with any available backend ([18b2f83](https://github.com/ai-nd-co/agent-tools/commit/18b2f835842dd0390c138c8713635ebcfc8e86a7))
* pass ci type checks for backend fallback ([299feb8](https://github.com/ai-nd-co/agent-tools/commit/299feb84548db8be91b28dd8c48f5ea31b65ac36))
* repair pytorch stack installation for Python 3.11 ([cb712ee](https://github.com/ai-nd-co/agent-tools/commit/cb712ee61d0d63a5bd3be0884b4b1309165268e7))

## [0.4.0](https://github.com/ai-nd-co/agent-tools/compare/py-v0.3.0...py-v0.4.0) (2026-04-15)

### Features

* refine TTS time guidance ([3834ae8](https://github.com/ai-nd-co/agent-tools/commit/3834ae86e08f4b5083b4fdecd585b9aa7c299a47))

## [0.3.0](https://github.com/ai-nd-co/agent-tools/compare/py-v0.2.0...py-v0.3.0) (2026-04-15)

### Features

* add codex notify playback integration ([3ac3d8b](https://github.com/ai-nd-co/agent-tools/commit/3ac3d8b1b4f25499aeb1b2d5e747478c1b18091b))
* improve tts rewrite guidance ([a2a8e34](https://github.com/ai-nd-co/agent-tools/commit/a2a8e3445896565664d61197c163395a747709a0))

### Bug Fixes

* ignore torch imports in mypy ([c2c0894](https://github.com/ai-nd-co/agent-tools/commit/c2c0894f6c33ae4e8329866a8c53121c59c6b568))
* improve queue navigation and tts speed controls ([6974098](https://github.com/ai-nd-co/agent-tools/commit/6974098ec5bd2d705e0f09b1d33a3abb6b1a0239))

## [0.2.0](https://github.com/ai-nd-co/agent-tools/compare/py-v0.1.3...py-v0.2.0) (2026-04-14)

### Features

* add ttsify playback queue and desktop controller ([31dd029](https://github.com/ai-nd-co/agent-tools/commit/31dd02953ed6c4ae6cec9e63cd6639731ac4c96a))

## [0.1.3](https://github.com/ai-nd-co/agent-tools/compare/py-v0.1.2...py-v0.1.3) (2026-04-14)

### Bug Fixes

* clarify semantic-release publish handoff ([175cbed](https://github.com/ai-nd-co/agent-tools/commit/175cbeda189ba83c09af4b1387dab12886d6fb65))

## [0.1.2](https://github.com/ai-nd-co/agent-tools/compare/py-v0.1.1...py-v0.1.2) (2026-04-14)

### Bug Fixes

* clarify automated release note in readme ([af9d06a](https://github.com/ai-nd-co/agent-tools/commit/af9d06a1b2b668c03385441c56a370432c932a1a))

# Changelog

All notable changes to this project will be documented in this file.

The automated semantic-release flow starts from the `py-v*` tag namespace.
Older `v0.1.x` tags predate that automation and are kept only as historical artifacts.
