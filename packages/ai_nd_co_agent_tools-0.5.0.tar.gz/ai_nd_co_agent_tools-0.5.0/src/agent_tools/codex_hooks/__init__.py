"""Packaged Codex hook templates."""

