"""admesh3D — placeholder.

This is a name-reservation placeholder for a possible future
3D-element extension of admesh2D
(https://github.com/domattioli/ADMESH). The 2D project ships as
``admesh2D`` on PyPI; this package reserves ``admesh3D`` against
the case where a 3D-element extension is built. There is no
functionality here yet.

If you arrived here looking for ADMESH itself, install
``admesh2D`` instead.
"""

__version__ = "0.0.1"
