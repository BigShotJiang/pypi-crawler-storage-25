# admesh3D — placeholder

This is a **name-reservation placeholder** on PyPI. There is no
functionality yet.

## What this is for

The 2D mesh generator [ADMESH](https://github.com/domattioli/ADMESH)
ships on PyPI as [`admesh2D`](https://pypi.org/project/admesh2D/)
(the bare `admesh` name is taken by an unrelated STL-bindings
package). A future 3D-element extension of ADMESH is a possibility
the project wants to leave room for. This package reserves the
`admesh3D` name against that case.

## What this is not

- Not a working library — `import admesh3d` returns a module with
  only a `__version__` and a docstring.
- Not a fork of, or substitute for,
  [`admesh2D`](https://pypi.org/project/admesh2D/).

## What to install instead

If you want the ADMESH mesh generator:

```bash
pip install admesh2D
```

## Status

If real 3D-element work begins, this package will be replaced with
a functioning release. Until then, the version stays at `0.0.x`.

## License

Apache-2.0. See [LICENSE](LICENSE).
