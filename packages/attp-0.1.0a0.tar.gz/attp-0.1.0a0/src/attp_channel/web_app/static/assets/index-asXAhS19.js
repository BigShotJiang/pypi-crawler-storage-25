(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))n(r);new MutationObserver(r=>{for(const o of r)if(o.type==="childList")for(const f of o.addedNodes)f.tagName==="LINK"&&f.rel==="modulepreload"&&n(f)}).observe(document,{childList:!0,subtree:!0});function i(r){const o={};return r.integrity&&(o.integrity=r.integrity),r.referrerPolicy&&(o.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?o.credentials="include":r.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function n(r){if(r.ep)return;r.ep=!0;const o=i(r);fetch(r.href,o)}})();let ee=!1;function oe(){ee||!window.marked||(ee=!0,window.marked.setOptions({gfm:!0,breaks:!0,highlight:(s,e)=>window.hljs&&e&&window.hljs.getLanguage(e)?window.hljs.highlight(s,{language:e}).value:window.hljs?window.hljs.highlightAuto(s).value:s}))}function te(s){if(oe(),!window.marked){const i=document.createElement("div");return i.textContent=s,i.innerHTML.replace(/\n/g,"<br>")}const e=window.marked.parse(s);return window.DOMPurify?window.DOMPurify.sanitize(e,{ALLOWED_TAGS:["h1","h2","h3","h4","h5","h6","p","br","hr","strong","em","del","a","img","ul","ol","li","blockquote","pre","code","table","thead","tbody","tr","th","td","span","div"],ALLOWED_ATTR:["href","target","rel","class"]}):e}function de(){const s=document.getElementById("home-chat-input"),e=document.getElementById("home-send-btn"),i=document.querySelector("#home-messages-container"),n=document.getElementById("home-new-session-btn");if(!s||!e||!i)return;const r=document.getElementById("home-agent-status-badge"),o=a=>{r&&(a==="active"?(r.className="px-2 py-0.5 rounded-md text-[10px] font-medium text-emerald-600 bg-emerald-50 border border-emerald-100 flex items-center gap-1.5",r.innerHTML='<i data-lucide="activity" class="w-3 h-3"></i> Active'):a==="offline"?(r.className="px-2 py-0.5 rounded-md text-[10px] font-medium text-amber-600 bg-amber-50 border border-amber-100 flex items-center gap-1.5",r.innerHTML='<i data-lucide="activity" class="w-3 h-3"></i> Offline'):(r.className="px-2 py-0.5 rounded-md text-[10px] font-medium text-gray-400 bg-gray-50 border border-gray-200 flex items-center gap-1.5",r.innerHTML='<i data-lucide="loader-2" class="w-3 h-3 animate-spin"></i> Connecting...'),window.lucide&&window.lucide.createIcons())};let f=!1;fetch("/api/status").then(a=>a.json()).then(a=>{f||(a.status==="active"?o("connecting"):o("offline"))}).catch(()=>{f||o("offline")});let p=JSON.parse(localStorage.getItem("nanobot_sessions")||"[]"),d=null,L=!1,x=new Set;const I=()=>{localStorage.setItem("nanobot_sessions",JSON.stringify(p)),T()},A=a=>{const t={id:"sess_"+Date.now().toString(),title:a,messages:[],rtLogs:[],nodeHistories:{},updatedAt:Date.now()};return p.unshift(t),d=t.id,window.currentSessionId=d,window.currentSessionId=d,I(),P(),t},E=()=>p.find(a=>a.id===d);window.getCurrentSession=E;const h=a=>{const t=new Date(a);return`${t.getFullYear()}-${t.getMonth()}-${t.getDate()}`},M=a=>{const t=new Date(a),u=new Date,y=new Date(u.getFullYear(),u.getMonth(),u.getDate()),m=new Date(t.getFullYear(),t.getMonth(),t.getDate()),v=Math.round((y.getTime()-m.getTime())/864e5),k=["周日","周一","周二","周三","周四","周五","周六"];return v===0?"Today":v===1?"Yesterday":`${t.getMonth()+1}月${t.getDate()}日 ${k[t.getDay()]}`},_=a=>`
    <div class="flex items-center justify-center my-4">
        <span class="px-3 py-1 bg-white border border-gray-100 rounded-full text-[11px] font-medium text-gray-400 shadow-sm">${M(a)}</span>
    </div>
  `,P=()=>{var m;i.innerHTML="";const a=E();if(!a)return;let t="";a.messages.forEach(v=>{if(v.timestamp){const k=h(v.timestamp);k!==t&&(i.insertAdjacentHTML("beforeend",_(v.timestamp)),t=k)}i.insertAdjacentHTML("beforeend",C(v))}),$();const u=document.getElementById("rt-log-container");u&&(u.innerHTML="",a.rtLogs&&(a.rtLogs.forEach(v=>{const k=document.createElement("div");k.className="text-xs text-gray-600 mb-1",k.innerHTML=`<span class="font-semibold text-gray-700">[${v.senderName}]</span> ${v.text}`,u.appendChild(k)}),u.scrollTop=u.scrollHeight));const y=document.getElementById("node-messages-container");if(y){y.innerHTML="";const v=(((m=document.getElementById("node-header-did"))==null?void 0:m.innerText)||"").trim();v&&a.nodeHistories&&a.nodeHistories[v]&&(a.nodeHistories[v].forEach(k=>{const b=document.createElement("div");b.innerHTML=window.renderNodeMessageHtml(k.role,k.text,k.timeStr);const H=b.firstElementChild;H&&y.appendChild(H)}),window.lucide&&window.lucide.createIcons(),y.parentElement.scrollTop=y.parentElement.scrollHeight)}},D=a=>{try{const t=new Date(a);return`${String(t.getHours()).padStart(2,"0")}:${String(t.getMinutes()).padStart(2,"0")}`}catch{return""}},C=a=>{const t=a.timestamp?D(a.timestamp):"";return a.role==="user"?`
          <div class="flex justify-end group fade-in">
              <div class="max-w-[80%] flex flex-col items-end">
                  <div class="flex items-center space-x-2 mb-1.5 px-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <span class="text-[11px] font-medium text-gray-500">You (Admin)</span>
                      ${t?`<span class="text-[11px] text-gray-400">${t}</span>`:""}
                  </div>
                  <div class="bg-gray-800 text-white rounded-2xl rounded-tr-sm p-4 w-full shadow-md text-[14px]">
                      ${a.content}
                  </div>
              </div>
          </div>
        `:`
        <div class="flex justify-start group fade-in">
            <div class="max-w-[80%] flex flex-col items-start">
                <div class="flex items-center gap-2 mb-1.5 px-1">
                    <div class="w-5 h-5 rounded-full bg-gray-100 flex items-center justify-center border border-gray-200">
                        <i data-lucide="bot" class="w-3 h-3 text-gray-600"></i>
                    </div>
                    <span class="text-[11px] font-medium text-gray-600">${a.senderOverride||"Local Agent"}</span>
                    ${t?`<span class="text-[11px] text-gray-400">${t}</span>`:""}
                </div>
                <div class="bg-white border border-gray-100 rounded-2xl rounded-tl-sm p-4 w-full shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)] text-gray-700 text-[14px] leading-relaxed markdown-body">
                    ${te(a.content)}
                </div>
            </div>
        </div>
      `},$=()=>{const a=document.querySelector("#view-home .overflow-y-auto");a&&(a.scrollTop=a.scrollHeight),window.lucide&&window.lucide.createIcons()},S=(a,t,u,y)=>{let m=p.find(k=>k.id===a);if(!m)if(t==="agent"){const k=y||"Remote Agent",b={id:a,title:`Message from ${k}`,messages:[],rtLogs:[],nodeHistories:{},updatedAt:Date.now(),isUnread:!1,unreadCount:0,senderName:k};p.unshift(b),m=b}else m=A(u.slice(0,20)+"...");m&&!m.senderName&&y&&y!=="Local Agent"&&(m.senderName=y),m.messages.length===0&&t==="user"&&(m.title=u.length>20?u.slice(0,20)+"...":u),t==="agent"&&d!==a?(m.isUnread||(m.isUnread=!0),m.unreadCount=(m.unreadCount||0)+1):d===a&&t==="agent"&&(m.isUnread=!1,m.unreadCount=0);const v=new Date().toISOString();if(m.messages.push({role:t,content:u,senderOverride:y,timestamp:v}),m.updatedAt=Date.now(),I(),d===a){const k=m.messages.length>1?m.messages[m.messages.length-2]:null;(!k||!k.timestamp||h(v)!==h(k.timestamp))&&i.insertAdjacentHTML("beforeend",_(v)),i.insertAdjacentHTML("beforeend",C({role:t,content:u,senderOverride:y,timestamp:v})),$()}B()};p.length>0?(d=p[0].id,window.currentSessionId=d,window.currentSessionId=d):A("New Chat"),P(),n&&n.addEventListener("click",()=>{A("New Chat")}),window.loadSession=a=>{const t=p.find(y=>y.id===a);t&&(t.isUnread||t.unreadCount)&&(t.isUnread=!1,t.unreadCount=0,I(),B()),d=a,window.currentSessionId=d,window.currentSessionId=d,P();const u=document.getElementById("nav-home");u&&u.click()},window.pinSessionRecord=(a,t)=>{a.stopPropagation();const u=p.find(y=>y.id===t);u&&(u.isPinned=!u.isPinned,I())},window.deleteSessionRecord=(a,t)=>{a.stopPropagation(),p=p.filter(u=>u.id!==t),d===t&&(d=p.length>0?p[0].id:null,d?P():A("New Chat")),I()};const g=()=>{const a=document.getElementById("batch-toolbar"),t=document.getElementById("batch-mode-btn"),u=document.getElementById("batch-selected-count"),y=document.getElementById("select-all-checkbox");if(!(!a||!t)){if(L?(a.classList.remove("hidden"),t.innerHTML='<i data-lucide="x" class="w-4 h-4"></i><span>取消管理</span>',t.className="px-3 py-2 text-[13px] font-medium text-gray-800 bg-gray-200 border border-gray-300 rounded-xl hover:bg-gray-300 transition-colors flex items-center gap-1.5"):(a.classList.add("hidden"),t.innerHTML='<i data-lucide="list-checks" class="w-4 h-4"></i><span>管理</span>',t.className="px-3 py-2 text-[13px] font-medium text-gray-600 bg-gray-50 border border-gray-200 rounded-xl hover:bg-gray-100 hover:border-gray-300 transition-colors flex items-center gap-1.5"),u&&(u.textContent=`已选 ${x.size} 项`),y){const m=p.map(v=>v.id);y.checked=m.length>0&&m.every(v=>x.has(v))}window.lucide&&window.lucide.createIcons()}};window.toggleBatchMode=()=>{var a,t;L=!L,L||x.clear(),T(((t=(a=document.getElementById("session-search"))==null?void 0:a.value)==null?void 0:t.toLowerCase())||""),g()},window.toggleSessionSelect=(a,t)=>{a.stopPropagation(),x.has(t)?x.delete(t):x.add(t);const u=a.target.querySelector("input[type=checkbox]")||a.target;u&&u.type==="checkbox"&&(u.checked=x.has(t)),g()},window.toggleSelectAll=a=>{a?p.forEach(t=>x.add(t.id)):x.clear(),document.querySelectorAll(".session-checkbox").forEach(t=>{t.checked=a}),g()},window.batchDeleteSessions=()=>{if(x.size===0)return;const a=x.size;p=p.filter(t=>!x.has(t.id)),x.has(d||"")&&(d=p.length>0?p[0].id:null,window.currentSessionId=d,d?P():A("New Chat")),x.clear(),L=!1,I(),g(),console.log(`Deleted ${a} sessions`)},window.batchPinSessions=()=>{if(x.size===0)return;let a=0;p.forEach(t=>{x.has(t.id)&&!t.isPinned&&(t.isPinned=!0,a++)}),x.clear(),L=!1,I(),g(),console.log(`Pinned ${a} sessions`)},window.batchUnpinSessions=()=>{if(x.size===0)return;let a=0;p.forEach(t=>{x.has(t.id)&&t.isPinned&&(t.isPinned=!1,a++)}),x.clear(),L=!1,I(),g(),console.log(`Unpinned ${a} sessions`)};const B=()=>{const t=p.filter(m=>m.isUnread&&m.unreadCount&&m.unreadCount>0).reduce((m,v)=>m+(v.unreadCount||0),0),u=document.getElementById("nav-sessions");if(!u)return;const y=u.querySelector(".sessions-unread-badge");if(y&&y.remove(),t>0){u.classList.add("relative");const m=document.createElement("span");m.className="sessions-unread-badge absolute -top-1 -right-1 min-w-5 h-5 px-1 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-medium",m.textContent=t>99?"99+":t.toString(),u.appendChild(m)}};window.filterSessions=a=>{const t=a.target.value.toLowerCase();T(t)};const T=(a="")=>{const t=document.getElementById("recent-list"),u=document.getElementById("pinned-list"),y=document.getElementById("pinned-section"),m=document.getElementById("session-count");if(m&&(m.innerText=`${p.length} Total`),!t||!u||!y)return;t.innerHTML="",u.innerHTML="";const v=p.filter(b=>b.title.toLowerCase().includes(a));let k=!1;v.forEach(b=>{const H=new Date(b.updatedAt),w=`${H.toLocaleDateString()} - ${H.toLocaleTimeString()}`,O=b.isPinned?"取消置顶":"置顶",W=b.isPinned?"text-brand-600":"text-gray-600",Z=x.has(b.id),ae=L?`onclick="window.toggleSessionSelect(event, '${b.id}')"`:`onclick="window.loadSession('${b.id}')"`,ie=L&&Z?"border-gray-400 ring-1 ring-gray-300":"border-gray-200",re=L?`
        <div class="flex items-center pl-1 pr-2" onclick="event.stopPropagation(); window.toggleSessionSelect(event, '${b.id}')">
            <input type="checkbox" class="session-checkbox w-4 h-4 rounded border-gray-300 accent-gray-800 cursor-pointer" ${Z?"checked":""} onclick="event.stopPropagation(); window.toggleSessionSelect(event, '${b.id}')">
        </div>`:"",ne=L?"":`
            <div class="relative">
                <button onclick="window.toggleMenu(event, 'menu-${b.id}')" class="p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-xl transition-colors">
                    <i data-lucide="more-horizontal" class="w-5 h-5 pointer-events-none"></i>
                </button>
                <div id="menu-${b.id}" class="dropdown-menu hidden absolute right-0 mt-1 w-44 bg-white border border-gray-100 rounded-xl shadow-[0_10px_30px_-10px_rgba(0,0,0,0.1)] py-1 z-50">
                    <button onclick="window.pinSessionRecord(event, '${b.id}')" class="w-full text-left px-3 py-2 text-[13px] ${W} hover:bg-gray-50 hover:text-gray-900 flex items-center gap-2 transition-colors">
                        <i data-lucide="pin" class="w-3.5 h-3.5"></i> ${O}
                    </button>
                    <button onclick="event.stopPropagation(); window.closeAllDropdowns(); window.showTraceTimeline('${b.id}')" class="w-full text-left px-3 py-2 text-[13px] text-gray-600 hover:bg-gray-50 hover:text-gray-900 flex items-center gap-2 transition-colors">
                        <i data-lucide="network" class="w-3.5 h-3.5"></i> 查看通讯日志
                      </button>
                    <button onclick="event.stopPropagation()" class="w-full text-left px-3 py-2 text-[13px] text-gray-600 hover:bg-gray-50 hover:text-gray-900 flex items-center gap-2 transition-colors">
                        <i data-lucide="download" class="w-3.5 h-3.5"></i> 导出溯源报告
                      </button>
                    <div class="h-px bg-gray-100 my-1"></div>
                    <button onclick="window.deleteSessionRecord(event, '${b.id}')" class="w-full text-left px-3 py-2 text-[13px] text-brand-600 hover:bg-brand-50 flex items-center gap-2 transition-colors group">
                        <i data-lucide="trash-2" class="w-3.5 h-3.5 group-hover:scale-110 transition-transform"></i> 删除
                      </button>
                </div>
            </div>`,X=`
        <div ${ae} class="session-item group relative flex items-center justify-between p-4 bg-white ${ie} rounded-2xl hover:border-gray-300 hover:shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)] transition-all mb-3 cursor-pointer">
            ${re}
            <div class="flex items-center gap-4 flex-1">
                <div class="w-10 h-10 rounded-full bg-gray-50 border border-gray-200 text-gray-600 flex items-center justify-center shrink-0 relative">
                    <i data-lucide="message-square" class="w-5 h-5"></i>
                    ${b.unreadCount&&b.unreadCount>0?`<span class="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-medium">${b.unreadCount>9?"9+":b.unreadCount}</span>`:""}
                </div>
                <div>
                    <h3 class="text-[14px] font-medium text-gray-900 mb-0.5 ${b.isUnread?"font-semibold":""}">${b.title||"Empty chat"}</h3>
                    <div class="flex items-center gap-2 text-[12px] text-gray-500">
                        <span>${b.senderName||"Local Agent"}</span>
                        <span class="w-1 h-1 rounded-full bg-gray-300"></span>
                        <span>${w}</span>
                    </div>
                </div>
            </div>
            ${ne}
        </div>
      `;b.isPinned?(k=!0,u.insertAdjacentHTML("beforeend",X)):t.insertAdjacentHTML("beforeend",X)}),k?y.classList.remove("hidden"):y.classList.add("hidden"),window.lucide&&window.lucide.createIcons()};T();const l=location.protocol==="https:"?"wss:":"ws:",c=new WebSocket(`${l}//${location.host}/ws`);c.onopen=()=>{f=!0,console.log("Connected to Local Agent over WebSocket"),o("active")},c.onclose=()=>{console.log("WebSocket disconnected"),o("offline")},c.onerror=()=>{o("offline")},c.onmessage=a=>{try{const t=JSON.parse(a.data);if(t.type==="chat"&&t.content){const u=t.metadata&&t.metadata.is_node_message,y=document.getElementById("rt-latency"),m=document.getElementById("rt-log-container");y&&t.metadata&&t.metadata.latency&&(y.innerText=t.metadata.latency+" ms");let v="Local Agent",k="Local Agent";if(t.metadata&&t.metadata.is_node_message){let H=t.metadata.other_did||"Node";if(H!=="Node"){const w=H.split(":");H=w[w.length-1]||H}v=H,t.metadata.direction==="in"?k=`${H} -> Local Agent`:k=`Local Agent -> ${H}`}let b=d;if(t.metadata&&t.metadata.Session_ID?b=t.metadata.Session_ID:(t.Session_ID||t.session_id)&&(b=t.Session_ID||t.session_id),m&&t.content){const H=t.content.slice(0,50).replace(/\n/g," ");if(b){let w=p.find(O=>O.id===b);w||(w={id:b,title:`Message from ${v}`,messages:[],rtLogs:[],nodeHistories:{},updatedAt:Date.now(),isUnread:!1,unreadCount:0,senderName:v},p.unshift(w),B()),!w.senderName&&v&&v!=="Local Agent"&&(w.senderName=v),w.rtLogs||(w.rtLogs=[]),w.rtLogs.push({senderName:k,text:H}),I()}if(b===d){const w=document.createElement("div");w.className="text-xs text-gray-600 mb-1",w.innerHTML=`<span class="font-semibold text-gray-700">[${k}]</span> ${H}`,m.appendChild(w),m.scrollTop=m.scrollHeight}}if(u){const H=document.getElementById("trace-modal");H&&!H.classList.contains("hidden")&&typeof window.showTraceTimeline=="function"&&window.showTraceTimeline(d);let w=t.metadata.other_did||t.session_id;w.startsWith("LocalBroker:")&&(w=w.substring(12));const W=(t.metadata?t.metadata.direction:"in")==="out"?"user":"agent";se(b||"",w,W,t.content)}else b&&S(b,"agent",t.content,v)}}catch(t){console.error("WS Error:",t)}};const N=()=>{const a=s.value.trim();!a||!d||(S(d,"user",a),c.readyState===WebSocket.OPEN?c.send(JSON.stringify({type:"chat",content:a,session_id:d})):console.warn("WebSocket not open"),s.value="",s.style.height="auto")};e.addEventListener("click",N),s.addEventListener("keydown",a=>{a.key==="Enter"&&!a.shiftKey&&(a.preventDefault(),N())});const U=document.getElementById("node-chat-input"),Y=document.getElementById("node-send-btn"),K=document.getElementById("node-messages-container");window.nodeHistories=window.nodeHistories||{},window.renderNodeMessageHtml=(a,t,u)=>`
          <div class="${a==="user"?"flex items-start justify-end gap-4":"flex items-start gap-4"}">
              ${a==="agent"?'<div class="w-8 h-8 rounded-full bg-emerald-50 border border-emerald-100 flex items-center justify-center shrink-0 shadow-sm mt-1"><i data-lucide="shield-check" class="w-4 h-4 text-emerald-600"></i></div>':""}
              <div class="flex flex-col gap-1 ${a==="user"?"items-end":""}">
                  <div class="flex items-center gap-2 px-1">
                      <span class="text-[11px] font-medium text-gray-500 uppercase tracking-wide">${a==="user"?"Local Agent Request":"Node Trace"}</span>
                      <span class="text-[10px] text-gray-400 font-mono">${u}</span>
                  </div>
                  <div class="text-[14px] leading-relaxed relative group ${a==="user"?"bg-gray-900 text-white rounded-2xl rounded-tr-sm px-5 py-3.5 shadow-sm ml-12":"bg-white border border-gray-100/80 shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)] text-gray-800 rounded-2xl rounded-tl-sm px-5 py-3.5 mr-12"} markdown-body">
                      ${a==="agent"?te(t):t.replace(/\n/g,"<br>")}
                  </div>
              </div>
              ${a==="user"?'<div class="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-100 flex items-center justify-center shrink-0 shadow-sm mt-1"><i data-lucide="blocks" class="w-4 h-4 text-indigo-600"></i></div>':""}
          </div>
      `;const se=(a,t,u,y)=>{var H;const m=new Date().toLocaleTimeString();if(a&&t){let w=p.find(O=>O.id===a);w||(w={id:a,title:`Message from ${t}`,messages:[],rtLogs:[],nodeHistories:{},updatedAt:Date.now(),isUnread:!1,unreadCount:0,senderName:t},p.unshift(w),B()),w.senderName||(w.senderName=t),w.nodeHistories||(w.nodeHistories={}),w.nodeHistories[t]||(w.nodeHistories[t]=[]),w.nodeHistories[t].push({role:u,text:y,timeStr:m}),d!==a?(w.isUnread=!0,w.unreadCount=(w.unreadCount||0)+1):(w.isUnread=!1,w.unreadCount=0),I(),B()}if(a!==d)return;const v=(((H=document.getElementById("node-header-did"))==null?void 0:H.innerText)||"").trim();if(t&&v&&t!==v)return;const k=document.createElement("div");k.innerHTML=window.renderNodeMessageHtml(u,y,m);const b=k.firstElementChild;b&&(K.appendChild(b),window.lucide&&window.lucide.createIcons(),K.parentElement.scrollTop=K.parentElement.scrollHeight)},Q=()=>{var m;const a=U.value.trim(),t=(((m=document.getElementById("node-header-did"))==null?void 0:m.innerText)||"").trim();if(!a||!t||!d)return;const u=`请使用 send_message_tool 将以下内容发送给节点 ${t}:

${a}`;S(d,"user",u),c.readyState===WebSocket.OPEN?c.send(JSON.stringify({type:"chat",content:u,session_id:d})):console.warn("WebSocket not open"),U.value="",U.style.height="auto";const y=document.getElementById("view-node-sec");y&&y.classList.add("opacity-0","transition-opacity","duration-200"),setTimeout(()=>{window.switchPage("view-home","nav-home"),y&&y.classList.remove("opacity-0")},200)};Y&&U&&(Y.addEventListener("click",Q),U.addEventListener("keydown",a=>{a.key==="Enter"&&!a.shiftKey&&(a.preventDefault(),Q())}))}function le(){return`
<aside class="w-[260px] bg-white border-r border-gray-100 flex flex-col shrink-0">
        
        <!-- 用户/系统信息 -->
        <div class="h-16 flex items-center px-5 mb-2">
            <div class="w-7 h-7 rounded-lg bg-gray-100 border border-gray-200 flex items-center justify-center mr-3">
                <i data-lucide="bot" class="w-4 h-4 text-gray-600"></i>
            </div>
            <div class="flex flex-col">
                <span class="text-sm font-semibold text-gray-800">Nanobot Local</span>
                <span class="text-[11px] text-gray-400">Safe Agent</span>
            </div>
        </div>

        <!-- 导航菜单 -->
        <nav class="flex-1 overflow-y-auto px-3 space-y-6">
            
            <!-- 分组 1: MAIN -->
            <div>
                <div class="px-2 text-[11px] font-medium text-gray-400 mb-1.5 flex items-center justify-between">
                    <span>Main</span>
                    <i data-lucide="minus" class="w-3 h-3 opacity-50"></i>
                </div>
                <button id="nav-home" onclick="window.switchPage('view-home', 'nav-home')" class="nav-btn w-full flex items-center px-2.5 py-2 text-sm text-gray-500 hover:bg-gray-50 hover:text-gray-800 rounded-lg transition-colors">
                    <i data-lucide="message-square" class="w-4 h-4 mr-3 opacity-70"></i>
                    <span>Home (Local Agent)</span>
                </button>
            </div>

            <!-- 分组 2: NETWORK (折叠展开 Nodes) -->
            <div>
                <div class="px-2 text-[11px] font-medium text-gray-400 mb-1.5 flex items-center justify-between">
                    <span>Network</span>
                    <i data-lucide="minus" class="w-3 h-3 opacity-50"></i>
                </div>
                <!-- 父级分类 (可折叠) -->
                <button onclick="window.toggleNodes()" class="w-full flex items-center justify-between px-2.5 py-2 text-sm text-gray-800 font-medium hover:bg-gray-50 rounded-lg transition-colors group">
                    <div class="flex items-center">
                        <i data-lucide="network" class="w-4 h-4 mr-3 opacity-70 text-gray-500"></i>
                        <span>Nodes</span>
                    </div>
                    <i data-lucide="chevron-down" id="nodes-chevron" class="w-4 h-4 text-gray-400 transition-transform duration-300"></i>
                </button>
                
                <!-- 子节点列表 (缩进排列)，添加动画容器 -->
                <div id="nodes-list" class="pl-7 pr-2 mt-1 space-y-0.5 overflow-hidden transition-all duration-300" style="max-height: 200px;"></div>
            </div>

            <!-- 分组 3: AGENT -->
            <div>
                <div class="px-2 text-[11px] font-medium text-gray-400 mb-1.5 flex items-center justify-between">
                    <span>Agent</span>
                    <i data-lucide="minus" class="w-3 h-3 opacity-50"></i>
                </div>
                <button class="w-full flex items-center px-2.5 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg transition-colors">
                    <i data-lucide="zap" class="w-4 h-4 mr-3 opacity-70"></i>
                    <span>Skills</span>
                </button>
                <button id="nav-sessions" onclick="window.switchPage('view-sessions', 'nav-sessions')" class="nav-btn relative w-full flex items-center px-2.5 py-2 text-sm text-gray-500 hover:bg-gray-50 hover:text-gray-800 rounded-lg transition-colors">
                    <i data-lucide="history" class="w-4 h-4 mr-3 opacity-70"></i>
                    <span>Sessions</span>
                </button>
            </div>
            
        </nav>

        <!-- 底部设置 -->
        <div class="p-4 mt-auto">
            <button id="nav-settings" onclick="window.switchPage('view-settings', 'nav-settings'); window.loadSettingsConfig();" class="nav-btn w-full flex items-center px-2.5 py-2 text-sm text-gray-500 hover:bg-gray-50 hover:text-gray-800 rounded-lg transition-colors">
                <i data-lucide="settings" class="w-4 h-4 mr-3 opacity-70"></i>
                <span>Settings</span>
            </button>
        </div>
    </aside>
  `}function ce(){return`
    <!-- ================= Trace Timeline Modal ================= -->
    <div id="trace-modal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/40 backdrop-blur-sm opacity-0 transition-opacity duration-300" onclick="window.closeTraceTimeline()">
        <!-- 溯源时间轴面板 -->
        <div class="timeline-content bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden scale-95 translate-y-4 transition-all duration-300" onclick="event.stopPropagation()">
            <!-- Header -->
            <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
                <div class="flex items-center gap-2">
                    <div class="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center">
                        <i data-lucide="git-merge" class="w-4 h-4 text-indigo-600"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-semibold text-gray-900">Message Trace</h3>
                        <p id="trace-session-id-label" class="text-[11px] text-gray-500 font-mono">ID: msg_79f8a2b1</p>
                    </div>
                </div>
                <button onclick="window.closeTraceTimeline()" class="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <!-- Timeline Content -->
            <div class="p-6 overflow-hidden relative min-h-[300px]" id="trace-timeline-wrapper">
                <div class="relative transition-all duration-300" id="trace-timeline-container">
                    <!-- 动态注入时间轴内容 -->
                </div>
            </div>
            
            <!-- Pagination Controls -->
            <div id="trace-pagination" class="px-6 py-2 border-t border-gray-100 flex items-center justify-between bg-white hidden">
                <button id="trace-prev-btn" class="p-1.5 text-gray-500 hover:text-gray-900 bg-gray-50 hover:bg-gray-100 rounded disabled:opacity-50 disabled:cursor-not-allowed transition-all">
                    <i data-lucide="chevron-left" class="w-4 h-4"></i>
                </button>
                <div id="trace-page-info" class="text-[12px] text-gray-500">Page 1 / 1</div>
                <button id="trace-next-btn" class="p-1.5 text-gray-500 hover:text-gray-900 bg-gray-50 hover:bg-gray-100 rounded disabled:opacity-50 disabled:cursor-not-allowed transition-all">
                    <i data-lucide="chevron-right" class="w-4 h-4"></i>
                </button>
            </div>

            <div class="bg-gray-50 border-t border-gray-100 px-6 py-3 flex items-center justify-between">
                <span class="text-[11px] text-gray-500 font-mono flex items-center gap-1.5">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Validated Chain
                </span>
                <span id="trace-latency-value" class="text-[11px] font-medium text-gray-400">Total Latency: --ms</span>
            </div>
        </div>
    </div>

    <!-- ================= Flow Diagram Modal ================= -->
    <div id="flow-modal" class="fixed inset-0 z-[60] hidden items-center justify-center bg-black/40 backdrop-blur-sm opacity-0 transition-opacity duration-300" onclick="window.closeFlowDiagram()">
        <div class="flow-content bg-white w-[95%] max-w-5xl rounded-2xl shadow-2xl overflow-hidden scale-95 translate-y-4 transition-all duration-300 flex flex-col max-h-[90vh]" onclick="event.stopPropagation()">
            <!-- Header -->
            <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50/50 shrink-0">
                <div class="flex items-center gap-2">
                    <div class="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center">
                        <i data-lucide="network" class="w-4 h-4 text-indigo-600"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-semibold text-gray-900">Message Flow Traces</h3>
                        <p class="text-[11px] text-gray-500 font-mono">End-to-end communication mapping</p>
                    </div>
                </div>
                <div class="flex items-center gap-4">
                    <button onclick="window.closeFlowDiagram()" class="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition">
                        <i data-lucide="x" class="w-5 h-5"></i>
                    </button>
                </div>
            </div>

            <!-- Flow Content (Scrollable List of Traces) -->
            <div class="p-6 overflow-y-auto w-full bg-gray-50/50 flex-1 space-y-6">
                
                <!-- ====== Trace 1 ====== -->
                <div class="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm overflow-x-auto">
                    <div class="text-[11px] font-bold text-gray-500 mb-6 flex justify-between items-center min-w-max">
                        <span class="text-gray-700 bg-gray-100 px-2 py-1 rounded">Trace #1: User Request "Deep Scan"</span>
                        <span class="text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2 py-1 rounded border border-emerald-100"><i data-lucide="check-circle" class="w-3.5 h-3.5"></i> Success (124ms)</span>
                    </div>
                    
                    <div class="relative min-w-max">
                        <!-- Forward path (Emerald dashed) -->
                        <div class="flex items-center relative z-10 shrink-0">
                            <!-- 1. User -->
                            <div class="flex flex-col items-center w-24 relative">
                                <div class="w-10 h-10 rounded-full bg-blue-50 border border-blue-200 flex items-center justify-center shadow-sm mb-2">
                                    <i data-lucide="user" class="w-4 h-4 text-blue-600"></i>
                                </div>
                                <span class="text-[11px] font-bold text-gray-800">User</span>
                                <span class="text-[10px] text-gray-500">Input</span>
                            </div>

                            <!-- Line -->
                            <div class="flex-1 border-t border-emerald-300 border-dashed relative min-w-[70px]">
                                <div class="absolute top-0 left-1/2 -translate-y-1/2 -translate-x-1/2 px-2 bg-white text-[10px] text-emerald-600 border border-emerald-100 rounded shadow-sm font-mono whitespace-nowrap">UI</div>
                                <i data-lucide="chevron-right" class="w-4 h-4 text-emerald-500 absolute right-0 top-0 -translate-y-1/2 translate-x-1/2 bg-white"></i>
                            </div>

                            <!-- 2. Local Agent -->
                            <div class="flex flex-col items-center w-24 relative">
                                <div class="w-10 h-10 rounded-full bg-gray-50 border border-gray-200 flex items-center justify-center shadow-sm mb-2">
                                    <i data-lucide="bot" class="w-4 h-4 text-gray-600"></i>
                                </div>
                                <span class="text-[11px] font-bold text-gray-800">Local Agent</span>
                                <span class="text-[10px] text-gray-500">Router</span>
                            </div>

                            <!-- Line -->
                            <div class="flex-1 border-t border-emerald-300 border-dashed relative min-w-[70px]">
                                <div class="absolute top-0 left-1/2 -translate-y-1/2 -translate-x-1/2 px-2 bg-white text-[10px] text-emerald-600 border border-emerald-100 rounded shadow-sm font-mono whitespace-nowrap">ATTP</div>
                                <i data-lucide="chevron-right" class="w-4 h-4 text-emerald-500 absolute right-0 top-0 -translate-y-1/2 translate-x-1/2 bg-white"></i>
                            </div>

                            <!-- 3. Broker -->
                            <div class="flex flex-col items-center w-24 relative">
                                <div class="w-10 h-10 rounded-full bg-indigo-50 border border-indigo-200 flex items-center justify-center shadow-sm mb-2">
                                    <i data-lucide="arrow-right-left" class="w-4 h-4 text-indigo-600"></i>
                                </div>
                                <span class="text-[11px] font-bold text-gray-800 text-center leading-tight">MQTT<br>Broker</span>
                            </div>

                            <!-- Line -->
                            <div class="flex-1 border-t border-emerald-300 border-dashed relative min-w-[70px]">
                                <div class="absolute top-0 left-1/2 -translate-y-1/2 -translate-x-1/2 px-2 bg-white text-[10px] text-emerald-600 border border-emerald-100 rounded shadow-sm font-mono whitespace-nowrap">TCP</div>
                                <i data-lucide="chevron-right" class="w-4 h-4 text-emerald-500 absolute right-0 top-0 -translate-y-1/2 translate-x-1/2 bg-white"></i>
                            </div>

                            <!-- 4. Gateway -->
                            <div class="flex flex-col items-center w-24 relative">
                                <div class="w-10 h-10 rounded-full bg-purple-50 border border-purple-200 flex items-center justify-center shadow-sm mb-2">
                                    <i data-lucide="server" class="w-4 h-4 text-purple-600"></i>
                                </div>
                                <span class="text-[11px] font-bold text-gray-800">Gateway</span>
                                <span class="text-[10px] text-gray-500">Auth</span>
                            </div>

                            <!-- Line -->
                            <div class="flex-1 border-t border-emerald-300 border-dashed relative min-w-[70px]">
                                <div class="absolute top-0 left-1/2 -translate-y-1/2 -translate-x-1/2 px-2 bg-white text-[10px] text-emerald-600 border border-emerald-100 rounded shadow-sm font-mono whitespace-nowrap">Local</div>
                                <i data-lucide="chevron-right" class="w-4 h-4 text-emerald-500 absolute right-0 top-0 -translate-y-1/2 translate-x-1/2 bg-white"></i>
                            </div>

                            <!-- 5. Target -->
                            <div class="flex flex-col items-center w-24 relative">
                                <div class="w-10 h-10 rounded-full bg-orange-50 border border-orange-200 flex items-center justify-center shadow-sm mb-2">
                                    <i data-lucide="shield-check" class="w-4 h-4 text-orange-600"></i>
                                </div>
                                <span class="text-[11px] font-bold text-gray-800 text-center leading-tight">Target<br>Node</span>
                            </div>
                        </div>

                        <!-- Return path (Gray solid) tightly packed -->
                        <div class="relative mt-3 h-4 w-full shrink-0">
                            <div class="absolute top-1/2 left-[48px] right-[48px] h-px bg-gray-300">
                                <i data-lucide="chevron-left" class="w-4 h-4 text-gray-400 absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 bg-white"></i>
                                <div class="absolute top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2 px-3 py-0.5 bg-gray-50 border border-gray-200 rounded-full text-[10px] text-gray-600 font-medium shadow-sm whitespace-nowrap">
                                    Return Result to User
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ====== Trace 2 ====== -->
                <div class="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm overflow-x-auto">
                    <div class="text-[11px] font-bold text-gray-500 mb-6 flex justify-between items-center min-w-max">
                        <span class="text-gray-700 bg-gray-100 px-2 py-1 rounded">Trace #2: Get System Status</span>
                        <span class="text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2 py-1 rounded border border-emerald-100"><i data-lucide="check-circle" class="w-3.5 h-3.5"></i> Success (45ms)</span>
                    </div>
                    
                    <div class="relative min-w-max">
                        <div class="flex items-center relative z-10 shrink-0">
                            <!-- 1. User -->
                            <div class="flex flex-col items-center w-24 relative">
                                <div class="w-10 h-10 rounded-full bg-blue-50 border border-blue-200 flex items-center justify-center shadow-sm mb-2">
                                    <i data-lucide="user" class="w-4 h-4 text-blue-600"></i>
                                </div>
                                <span class="text-[11px] font-bold text-gray-800">User</span>
                            </div>

                            <!-- Line -->
                            <div class="flex-1 border-t border-emerald-300 border-dashed relative min-w-[70px]">
                                <div class="absolute top-0 left-1/2 -translate-y-1/2 -translate-x-1/2 px-2 bg-white text-[10px] text-emerald-600 border border-emerald-100 rounded shadow-sm font-mono whitespace-nowrap">UI</div>
                                <i data-lucide="chevron-right" class="w-4 h-4 text-emerald-500 absolute right-0 top-0 -translate-y-1/2 translate-x-1/2 bg-white"></i>
                            </div>

                            <!-- 2. Local Agent -->
                            <div class="flex flex-col items-center w-24 relative">
                                <div class="w-10 h-10 rounded-full bg-gray-50 border border-gray-200 flex items-center justify-center shadow-sm mb-2">
                                    <i data-lucide="bot" class="w-4 h-4 text-gray-600"></i>
                                </div>
                                <span class="text-[11px] font-bold text-gray-800">Local Agent</span>
                            </div>

                            <!-- Line -->
                            <div class="flex-1 border-t border-emerald-300 border-dashed relative min-w-[70px]">
                                <div class="absolute top-0 left-1/2 -translate-y-1/2 -translate-x-1/2 px-2 bg-white text-[10px] text-emerald-600 border border-emerald-100 rounded shadow-sm font-mono whitespace-nowrap">Local</div>
                                <i data-lucide="chevron-right" class="w-4 h-4 text-emerald-500 absolute right-0 top-0 -translate-y-1/2 translate-x-1/2 bg-white"></i>
                            </div>

                            <!-- 3. Gateway -->
                            <div class="flex flex-col items-center w-24 relative">
                                <div class="w-10 h-10 rounded-full bg-purple-50 border border-purple-200 flex items-center justify-center shadow-sm mb-2">
                                    <i data-lucide="server" class="w-4 h-4 text-purple-600"></i>
                                </div>
                                <span class="text-[11px] font-bold text-gray-800">Gateway</span>
                            </div>
                        </div>

                        <!-- Return path tightly packed -->
                        <div class="relative mt-3 h-4 w-full shrink-0">
                            <div class="absolute top-1/2 left-[48px] right-[48px] h-px bg-gray-300">
                                <i data-lucide="chevron-left" class="w-4 h-4 text-gray-400 absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 bg-white"></i>
                                <div class="absolute top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2 px-3 py-0.5 bg-gray-50 border border-gray-200 rounded-full text-[10px] text-gray-600 font-medium shadow-sm whitespace-nowrap">
                                    Return Result to User
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ====== Trace 3 ====== -->
                <div class="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm overflow-x-auto opacity-70">
                    <div class="text-[11px] font-bold text-gray-500 mb-6 flex justify-between items-center min-w-max">
                        <span class="text-gray-700 bg-gray-100 px-2 py-1 rounded">Trace #3: Keep-Alive Ping</span>
                        <span class="text-blue-500 flex items-center gap-1 bg-blue-50 px-2 py-1 rounded border border-blue-100"><i data-lucide="info" class="w-3.5 h-3.5"></i> Info (8ms)</span>
                    </div>
                    
                    <div class="relative min-w-max">
                        <div class="flex items-center relative z-10 shrink-0">
                            <!-- 1. Local Agent -->
                            <div class="flex flex-col items-center w-24 relative">
                                <div class="w-10 h-10 rounded-full bg-gray-50 border border-gray-200 flex items-center justify-center shadow-sm mb-2">
                                    <i data-lucide="bot" class="w-4 h-4 text-gray-600"></i>
                                </div>
                                <span class="text-[11px] font-bold text-gray-800">Local Agent</span>
                            </div>

                            <!-- Line -->
                            <div class="flex-1 border-t border-emerald-300 border-dashed relative min-w-[120px]">
                                <div class="absolute top-0 left-1/2 -translate-y-1/2 -translate-x-1/2 px-2 bg-white text-[10px] text-emerald-600 border border-emerald-100 rounded shadow-sm font-mono whitespace-nowrap">Ping MQTT</div>
                                <i data-lucide="chevron-right" class="w-4 h-4 text-emerald-500 absolute right-0 top-0 -translate-y-1/2 translate-x-1/2 bg-white"></i>
                            </div>

                            <!-- 2. Broker -->
                            <div class="flex flex-col items-center w-24 relative">
                                <div class="w-10 h-10 rounded-full bg-indigo-50 border border-indigo-200 flex items-center justify-center shadow-sm mb-2">
                                    <i data-lucide="arrow-right-left" class="w-4 h-4 text-indigo-600"></i>
                                </div>
                                <span class="text-[11px] font-bold text-gray-800 text-center leading-tight">MQTT<br>Broker</span>
                            </div>
                        </div>

                        <!-- Return path tightly packed -->
                        <div class="relative mt-3 h-4 w-full shrink-0">
                            <div class="absolute top-1/2 left-[48px] right-[48px] h-px bg-gray-300">
                                <i data-lucide="chevron-left" class="w-4 h-4 text-gray-400 absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 bg-white"></i>
                                <div class="absolute top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2 px-3 py-0.5 bg-gray-50 border border-gray-200 rounded-full text-[10px] text-gray-600 font-medium shadow-sm whitespace-nowrap">
                                    ACK
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Footer Pagination -->
            <div class="px-6 py-4 border-t border-gray-100 bg-white flex items-center justify-between shrink-0">
                <span class="text-[12px] text-gray-500 font-medium">Showing 1-3 of 12 Traces</span>
                <div class="flex items-center gap-1">
                    <button class="px-3 py-1.5 border border-gray-200 text-gray-400 rounded-lg text-[12px] cursor-not-allowed">Previous</button>
                    <button class="px-3 py-1.5 bg-indigo-50 text-indigo-700 rounded-lg text-[12px] font-semibold border border-indigo-100">1</button>
                    <button class="px-3 py-1.5 hover:bg-gray-50 text-gray-600 rounded-lg text-[12px] transition">2</button>
                    <button class="px-3 py-1.5 hover:bg-gray-50 text-gray-600 rounded-lg text-[12px] transition">3</button>
                    <span class="px-2 text-gray-400 text-[12px]">...</span>
                    <button class="px-3 py-1.5 border border-gray-200 text-gray-600 rounded-lg text-[12px] hover:bg-gray-50 transition shadow-sm">Next</button>
                </div>
            </div>

  `}function pe(){return`
<div id="view-home" class="page-view flex flex-col h-full hidden fade-in">
            <!-- 头部 Profile -->
            <header class="bg-white border-b border-gray-100 shrink-0 px-8 py-6 shadow-[0_4px_20px_-15px_rgba(0,0,0,0.05)] z-10">
                <div class="max-w-4xl mx-auto">
                    <div class="flex items-start justify-between">
                        <div class="flex items-center gap-4">
                            <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-gray-50 to-gray-100 border border-gray-200 flex items-center justify-center shadow-sm">
                                <i data-lucide="bot" class="w-6 h-6 text-gray-600"></i>
                            </div>
                            <div>
                                <div class="flex items-center gap-2.5 mb-1">
                                    <h2 class="text-xl font-semibold text-gray-900 tracking-tight">Local Manager Agent</h2>
                                    <span id="home-agent-status-badge" class="px-2 py-0.5 rounded-md text-[10px] font-medium text-gray-400 bg-gray-50 border border-gray-200 flex items-center gap-1.5">
                                        <i data-lucide="loader-2" class="w-3 h-3 animate-spin"></i> Connecting...
                                    </span>
                                </div>
                                <p class="text-sm text-gray-500">你本机的主控 Agent，负责调度全网节点、分配任务及执行本地脚本。</p>
                            </div>
                        </div>
                        
                        <!-- NEW: 新建会话按钮 -->
                        <button id="home-new-session-btn" class="p-2 bg-gray-50 text-gray-600 hover:bg-gray-100 hover:text-gray-900 rounded-lg transition-colors border border-gray-200 shadow-sm flex items-center gap-2 text-sm font-medium">
                            <i data-lucide="plus" class="w-4 h-4"></i>
                            New Chat
                        </button>
                    </div>
                </div>
            </header>
<div class="flex flex-1 overflow-hidden">
<div class="flex-1 flex flex-col relative">


            <!-- 聊天记录区 -->
            <div class="flex-1 overflow-y-auto p-8 relative">
                <div id="home-messages-container" class="max-w-4xl mx-auto space-y-8 pb-4">
                </div>
            </div>

            <!-- 输入框 -->
            <div class="p-5 bg-surface border-t border-gray-100 shrink-0">
                <div class="max-w-4xl mx-auto relative flex items-end bg-white border border-gray-200 focus-within:border-gray-300 focus-within:shadow-[0_0_0_4px_rgba(0,0,0,0.02)] rounded-2xl p-2 transition-all duration-200">
                    <button class="p-2.5 text-gray-400 hover:text-gray-600 rounded-xl hover:bg-gray-50 transition-colors shrink-0">
                        <i data-lucide="paperclip" class="w-5 h-5"></i>
                    </button>
                    <textarea id="home-chat-input" rows="1" class="w-full bg-transparent border-none focus:ring-0 text-[14px] text-gray-800 placeholder-gray-400 resize-none py-3 px-2 mx-1 max-h-32" style="outline: none;" placeholder="Command Local Agent..."></textarea>
                    <button id="home-send-btn" class="p-2.5 bg-gray-900 text-white rounded-xl hover:bg-gray-800 transition-colors shadow-sm shrink-0">
                        <i data-lucide="arrow-up" class="w-5 h-5"></i>
                    </button>
                </div>
            </div>
        
</div>

        <div id="home-right-panel" class="w-80 border-l border-gray-100 bg-gray-50 flex flex-col h-full hidden lg:flex">
             <div class="p-6 border-b border-gray-100 bg-white">
                 <h3 class="text-sm font-semibold text-gray-900">Real-time Network</h3>
             </div>
             <div class="flex-1 overflow-y-auto p-6 space-y-4">
                 
                 <div class="bg-white p-4 rounded-xl border border-gray-100">
                     <div class="text-[11px] font-medium text-gray-400 uppercase mb-3">Logs</div>
                     <div id="rt-log-container" class="space-y-3"></div>
                 </div>
             </div>
        </div>
        </div>
        </div>
  `}function ge(){return`
<div id="view-node-sec" class="page-view flex flex-col h-full hidden fade-in">
    <header class="bg-white border-b border-gray-100 shrink-0 px-8 py-6 shadow-[0_4px_20px_-15px_rgba(0,0,0,0.05)] z-10">
        <div class="max-w-4xl mx-auto">
            <div class="flex items-start justify-between">
                <div class="flex items-center gap-4">
                    <!-- 头像 -->
                    <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-50 to-emerald-100 border border-emerald-200 flex items-center justify-center shadow-sm">
                        <div id="node-header-icon"><i data-lucide="shield-check" class="w-6 h-6 text-emerald-600"></i></div>
                    </div>
                    <!-- 核心信息 -->
                    <div>
                        <div class="flex items-center gap-2.5 mb-1">
                            <h2 id="node-header-name" class="text-xl font-semibold text-gray-900 tracking-tight">Home Security Agent</h2>
                            <span id="node-header-status-badge" class="px-2 py-0.5 rounded-md text-[10px] font-medium text-emerald-600 bg-emerald-50 border border-emerald-100 flex items-center gap-1.5">
                                <span class="w-1 h-1 rounded-full bg-emerald-500"></span> Online
                            </span>
                        </div>
                        <p id="node-header-desc" class="text-sm text-gray-500">负责监控家庭内网 IOT 设备行为，执行本地安全策略拦截异常请求。</p>
                    </div>
                </div>
                
                <!-- 快捷操作按钮 -->
                <div class="flex items-center gap-2">
                    <button class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-50 rounded-lg transition border border-transparent hover:border-gray-200">
                        <i data-lucide="more-horizontal" class="w-4 h-4"></i>
                    </button>
                </div>
            </div>

            <!-- 详细参数区 -->
            <div class="mt-5 flex items-center flex-wrap gap-x-6 gap-y-3">
                <div class="flex items-center gap-2 text-sm">
                    <span class="text-gray-400 font-medium text-[11px] uppercase tracking-wide">DID</span>
                    <code id="node-header-did" class="text-[13px] text-gray-600 bg-gray-50 border border-gray-100 px-2 py-0.5 rounded-md font-mono">did:wba:home.local:sec-01</code>
                </div>
                <div class="flex items-center gap-2 text-sm">
                    <span class="text-gray-400 font-medium text-[11px] uppercase tracking-wide">Endpoint</span>
                    <span id="node-header-endpoint" class="text-[13px] text-gray-600 flex items-center gap-1"><i data-lucide="link-2" class="w-3 h-3 text-gray-400"></i>http://192.168.1.100:8081/attp</span>
                </div>
                <div class="flex items-center gap-2 text-sm">
                    <span class="text-gray-400 font-medium text-[11px] uppercase tracking-wide">Skills</span>
                    <div id="node-header-skills" class="flex items-center gap-1.5"><span class="text-[11px] px-2 py-0.5 rounded-md bg-gray-50 text-gray-500 border border-gray-100 font-mono">security_check</span></div>
                </div>
            </div>
        </div>
    </header>

    <div class="flex-1 overflow-y-auto p-8 relative">
        <div class="max-w-4xl mx-auto space-y-8 pb-4" id="node-messages-container">
            <div class="flex items-center justify-center my-4">
               <span class="px-3 py-1 bg-white border border-gray-100 rounded-full text-[11px] font-medium cursor-pointer text-gray-400 hover:text-gray-600 hover:bg-gray-50 shadow-sm transition" onclick="if(window.currentSessionId) (window as any).showTraceTimeline(window.currentSessionId)">🕹️ View Trace Logs</span>
            </div>
        </div>
    </div>
    
    <div class="p-5 bg-surface border-t border-gray-100 shrink-0">
        <div class="max-w-4xl mx-auto relative flex items-end bg-white border border-gray-200 focus-within:border-gray-300 focus-within:shadow-[0_0_0_4px_rgba(0,0,0,0.02)] rounded-2xl p-2 transition-all duration-200">
            <!-- 附件按钮 -->
            <button class="p-2.5 text-gray-400 hover:text-gray-600 rounded-xl hover:bg-gray-50 transition-colors shrink-0">
                <i data-lucide="paperclip" class="w-5 h-5"></i>
            </button>
            
            <!-- 文本输入框 -->
            <textarea 
                id="node-chat-input"
                rows="1" 
                class="w-full bg-transparent border-none focus:ring-0 text-[14px] text-gray-800 placeholder-gray-400 resize-none py-3 px-2 mx-1 max-h-32" 
                placeholder="Message Selected Agent Node..."
                style="outline: none;"
            ></textarea>
            
            <!-- 发送按钮 -->
            <button id="node-send-btn" class="p-2.5 bg-gray-900 text-white rounded-xl hover:bg-gray-800 transition-colors shadow-sm shrink-0">
                <i data-lucide="arrow-up" class="w-5 h-5"></i>
            </button>
        </div>
        <div class="max-w-4xl mx-auto mt-2 text-center">
            <span class="text-[10px] text-gray-400">Local Agent will send this request via ATTP protocol. Press <kbd class="font-sans px-1 rounded bg-gray-100 border border-gray-200">Enter</kbd> to send.</span>
        </div>
    </div>
</div>
  `}function ue(){return`
<div id="view-sessions" class="page-view flex flex-col h-full hidden fade-in">
    <!-- Header -->
    <header class="bg-white border-b border-gray-100 shrink-0 px-8 py-6 shadow-[0_4px_20px_-15px_rgba(0,0,0,0.05)] z-10">
        <div class="max-w-4xl mx-auto flex items-end justify-between">
            <div>
                <div class="flex items-center gap-2.5 mb-1.5">
                    <h2 class="text-xl font-semibold text-gray-900 tracking-tight">Sessions</h2>
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-medium text-gray-500 bg-gray-100 border border-gray-200" id="session-count">0 Total</span>
                </div>
                <p class="text-sm text-gray-500">查看、置顶或删除你与各个 Agent 节点产生的历史交互会话记录。</p>
            </div>
            <div class="flex items-center gap-3">
                <!-- 搜索框辅助 -->
                <div class="relative w-64 hidden md:block">
                    <i data-lucide="search" class="w-4 h-4 text-gray-400 absolute left-3 top-2.5"></i>
                    <input type="text" id="session-search" placeholder="Search sessions..." onkeyup="window.filterSessions(event)" class="w-full pl-9 pr-3 py-2 text-sm bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-400">
                </div>
                <!-- 批量管理按钮 -->
                <button id="batch-mode-btn" onclick="window.toggleBatchMode()" class="px-3 py-2 text-[13px] font-medium text-gray-600 bg-gray-50 border border-gray-200 rounded-xl hover:bg-gray-100 hover:border-gray-300 transition-colors flex items-center gap-1.5">
                    <i data-lucide="list-checks" class="w-4 h-4"></i>
                    <span>管理</span>
                </button>
            </div>
        </div>
    </header>

    <!-- 会话列表主体 -->
    <div class="flex-1 overflow-y-auto p-8 relative" id="sessions-scroll-area">
        <div class="max-w-4xl mx-auto space-y-8 pb-4">
            <!-- 分区 1：置顶会话 (Pinned) -->
            <div id="pinned-section" class="hidden">
                <div class="flex items-center gap-2 text-[11px] font-semibold text-gray-400 tracking-wider uppercase mb-3 px-1">
                    <i data-lucide="pin" class="w-3.5 h-3.5"></i>
                    <span>Pinned Sessions</span>
                </div>
                <div id="pinned-list"></div>
            </div>

            <!-- 分区 2：最近会话 (Recent) -->
            <div id="recent-section">
                <div class="flex items-center gap-2 text-[11px] font-semibold text-gray-400 tracking-wider uppercase mb-3 px-1">
                    <i data-lucide="clock" class="w-3.5 h-3.5"></i>
                    <span>Recent History</span>
                </div>
                <div id="recent-list"></div>
            </div>
        </div>
    </div>

    <!-- 批量操作底部工具栏 -->
    <div id="batch-toolbar" class="hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-[0_-4px_20px_-10px_rgba(0,0,0,0.1)] z-30 transition-all">
        <div class="max-w-4xl mx-auto px-8 py-3 flex items-center justify-between">
            <div class="flex items-center gap-4">
                <label class="flex items-center gap-2 cursor-pointer text-[13px] text-gray-600 hover:text-gray-800 select-none">
                    <input type="checkbox" id="select-all-checkbox" onchange="window.toggleSelectAll(this.checked)" class="w-4 h-4 rounded border-gray-300 text-gray-800 focus:ring-gray-400 cursor-pointer accent-gray-800">
                    <span>全选</span>
                </label>
                <span id="batch-selected-count" class="text-[13px] text-gray-400">已选 0 项</span>
            </div>
            <div class="flex items-center gap-2">
                <button onclick="window.batchPinSessions()" class="px-3 py-1.5 text-[13px] font-medium text-gray-600 bg-gray-50 border border-gray-200 rounded-lg hover:bg-gray-100 transition-colors flex items-center gap-1.5">
                    <i data-lucide="pin" class="w-3.5 h-3.5"></i>
                    置顶
                </button>
                <button onclick="window.batchUnpinSessions()" class="px-3 py-1.5 text-[13px] font-medium text-gray-600 bg-gray-50 border border-gray-200 rounded-lg hover:bg-gray-100 transition-colors flex items-center gap-1.5">
                    <i data-lucide="pin-off" class="w-3.5 h-3.5"></i>
                    取消置顶
                </button>
                <button onclick="window.batchDeleteSessions()" class="px-3 py-1.5 text-[13px] font-medium text-red-600 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100 transition-colors flex items-center gap-1.5">
                    <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                    删除
                </button>
                <div class="w-px h-6 bg-gray-200 mx-1"></div>
                <button onclick="window.toggleBatchMode()" class="px-3 py-1.5 text-[13px] font-medium text-gray-500 hover:text-gray-700 transition-colors">
                    取消
                </button>
            </div>
        </div>
    </div>
</div>
  `}function me(){return`
<div id="view-settings" class="page-view flex flex-col h-full hidden fade-in">
    <!-- Header -->
    <header class="bg-white border-b border-gray-100 shrink-0 px-8 py-6 shadow-[0_4px_20px_-15px_rgba(0,0,0,0.05)] z-10">
        <div class="max-w-4xl mx-auto">
            <div class="flex items-center gap-2.5 mb-1.5">
                <h2 class="text-xl font-semibold text-gray-900 tracking-tight">Settings</h2>
                <span id="settings-attp-badge" class="px-2 py-0.5 rounded-md text-[10px] font-medium text-gray-400 bg-gray-50 border border-gray-200">
                    Loading...
                </span>
            </div>
            <p class="text-sm text-gray-500">管理 ATTP 网络配置，包括 DID 身份、客户端连接、服务器设置及其他服务配置。</p>
        </div>
    </header>

    <!-- 配置内容区 -->
    <div class="flex-1 overflow-y-auto p-8 relative">
        <div class="max-w-4xl mx-auto space-y-6 pb-4">

            <!-- 加载状态 -->
            <div id="settings-loading" class="flex items-center justify-center py-16">
                <div class="flex items-center gap-3 text-gray-400">
                    <i data-lucide="loader-2" class="w-5 h-5 animate-spin"></i>
                    <span class="text-sm">Loading configuration...</span>
                </div>
            </div>

            <!-- ATTP 未启用提示 -->
            <div id="settings-disabled" class="hidden">
                <div class="bg-amber-50 border border-amber-100 rounded-xl p-6 text-center">
                    <div class="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center mx-auto mb-3">
                        <i data-lucide="alert-triangle" class="w-6 h-6 text-amber-500"></i>
                    </div>
                    <h3 class="text-sm font-semibold text-amber-800 mb-1">ATTP Not Enabled</h3>
                    <p class="text-xs text-amber-600">请在 ~/.nanobot/config.json 中启用 ATTP 并运行 agent 以使用配置管理功能。</p>
                </div>
            </div>

            <!-- 配置表单 -->
            <div id="settings-form-container" class="hidden space-y-6">

                <!-- 分组 1: DID Identity -->
                <div>
                    <div class="flex items-center gap-2 text-[11px] font-semibold text-gray-400 tracking-wider uppercase mb-3 px-1">
                        <i data-lucide="fingerprint" class="w-3.5 h-3.5"></i>
                        <span>DID Identity</span>
                    </div>
                    <div class="bg-white p-5 rounded-xl border border-gray-100 space-y-4">
                        <div>
                            <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">DID</label>
                            <input type="text" id="cfg-did" placeholder="did:wba:..." class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                        </div>
                    </div>
                </div>

                <!-- 分组 2: ATTP Client -->
                <div>
                    <div class="flex items-center gap-2 text-[11px] font-semibold text-gray-400 tracking-wider uppercase mb-3 px-1">
                        <i data-lucide="radio" class="w-3.5 h-3.5"></i>
                        <span>ATTP Client</span>
                    </div>
                    <div class="bg-white p-5 rounded-xl border border-gray-100 space-y-4">
                        <div>
                            <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">DID Doc Path</label>
                            <input type="text" id="cfg-did-doc-path" placeholder="~/.nanobot/attp/did.json" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                        </div>
                        <div>
                            <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">DID Key Path</label>
                            <input type="text" id="cfg-did-key-path" placeholder="~/.nanobot/attp/key-1_private.pem" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                        </div>
                        <div>
                            <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Node ADs</label>
                            <div id="cfg-node-ads-list" class="space-y-2"></div>
                            <button onclick="window.addNodeAd()" class="mt-2 flex items-center gap-1.5 text-xs text-gray-400 hover:text-gray-600 transition-colors">
                                <i data-lucide="plus" class="w-3.5 h-3.5"></i>
                                <span>Add Node AD</span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- 分组 3: ATTP Server -->
                <div>
                    <div class="flex items-center gap-2 text-[11px] font-semibold text-gray-400 tracking-wider uppercase mb-3 px-1">
                        <i data-lucide="server" class="w-3.5 h-3.5"></i>
                        <span>ATTP Server</span>
                    </div>
                    <div class="bg-white p-5 rounded-xl border border-gray-100 space-y-4">
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Name</label>
                                <input type="text" id="cfg-server-name" placeholder="My Agent" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300">
                            </div>
                            <div>
                                <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Prefix</label>
                                <input type="text" id="cfg-server-prefix" placeholder="/agent" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                            </div>
                        </div>
                        <div>
                            <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Description</label>
                            <input type="text" id="cfg-server-desc" placeholder="Agent description" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300">
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Server Host</label>
                                <input type="text" id="cfg-server-host" placeholder="127.0.0.1" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                            </div>
                            <div>
                                <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Server Port</label>
                                <input type="number" id="cfg-server-port" placeholder="8000" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                            </div>
                        </div>
                        <div>
                            <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Private Key Path</label>
                            <input type="text" id="cfg-server-private-key" placeholder="~/.nanobot/attp/server_private.pem" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                        </div>
                        <div>
                            <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Public Key Path</label>
                            <input type="text" id="cfg-server-public-key" placeholder="~/.nanobot/attp/server_public.pem" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                        </div>
                    </div>
                </div>

                <!-- 分组 4: Web App -->
                <div>
                    <div class="flex items-center gap-2 text-[11px] font-semibold text-gray-400 tracking-wider uppercase mb-3 px-1">
                        <i data-lucide="globe" class="w-3.5 h-3.5"></i>
                        <span>Web App</span>
                    </div>
                    <div class="bg-white p-5 rounded-xl border border-gray-100 space-y-4">
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Host</label>
                                <input type="text" id="cfg-webapp-host" placeholder="127.0.0.1" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                            </div>
                            <div>
                                <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Port</label>
                                <input type="number" id="cfg-webapp-port" placeholder="8001" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 分组 5: Tool -->
                <div>
                    <div class="flex items-center gap-2 text-[11px] font-semibold text-gray-400 tracking-wider uppercase mb-3 px-1">
                        <i data-lucide="wrench" class="w-3.5 h-3.5"></i>
                        <span>Tool</span>
                    </div>
                    <div class="bg-white p-5 rounded-xl border border-gray-100 space-y-4">
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Host</label>
                                <input type="text" id="cfg-tool-host" placeholder="127.0.0.1" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                            </div>
                            <div>
                                <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Port</label>
                                <input type="number" id="cfg-tool-port" placeholder="8002" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 分组 6: Heartbeat -->
                <div>
                    <div class="flex items-center gap-2 text-[11px] font-semibold text-gray-400 tracking-wider uppercase mb-3 px-1">
                        <i data-lucide="heart-pulse" class="w-3.5 h-3.5"></i>
                        <span>Heartbeat</span>
                    </div>
                    <div class="bg-white p-5 rounded-xl border border-gray-100 space-y-4">
                        <div class="grid grid-cols-3 gap-4">
                            <div>
                                <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Interval (s)</label>
                                <input type="number" id="cfg-heartbeat-interval" placeholder="30" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                            </div>
                            <div>
                                <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Timeout (s)</label>
                                <input type="number" id="cfg-heartbeat-timeout" placeholder="90" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                            </div>
                            <div>
                                <label class="block text-[11px] font-medium text-gray-400 uppercase mb-1.5">Max Fail</label>
                                <input type="number" id="cfg-heartbeat-max-fail" placeholder="3" class="w-full text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 操作按钮 -->
                <div class="flex items-center justify-between pt-2">
                    <div class="space-y-0.5">
                        <p class="text-[11px] text-gray-400">配置将保存至 ~/.nanobot/attp/attp_config.json</p>
                        <p class="text-[10px] text-gray-300"><strong>Refresh</strong> 从磁盘重读 · <strong>Save</strong> 仅保存 · <strong>Reload</strong> 保存并应用</p>
                    </div>
                    <div class="flex items-center gap-3">
                        <button onclick="window.refreshSettingsConfig()" class="px-4 py-2 text-sm text-gray-500 bg-gray-50 border border-gray-200 rounded-xl hover:bg-gray-100 hover:text-gray-700 transition-colors" title="从磁盘重新读取配置文件">
                            <span class="flex items-center gap-1.5"><i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i> Refresh</span>
                        </button>
                        <button onclick="window.saveSettingsConfig()" id="settings-save-btn" class="px-5 py-2 text-sm font-medium text-white bg-gray-900 rounded-xl hover:bg-gray-800 transition-colors shadow-sm" title="保存配置到文件（不立即生效）">
                            <span class="flex items-center gap-1.5"><i data-lucide="check" class="w-3.5 h-3.5"></i> Save Changes</span>
                        </button>
                        <button onclick="window.reloadSettingsConfig()" id="settings-reload-btn" class="px-4 py-2 text-sm font-medium text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 transition-colors shadow-sm" title="重新读取配置并应用（hot-reload）">
                            <span class="flex items-center gap-1.5"><i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i> Reload</span>
                        </button>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- Toast 提示 -->
    <div id="settings-toast" class="fixed top-6 right-6 z-50 opacity-0 translate-x-10 pointer-events-none transition-all duration-300">
        <div class="flex items-center gap-2.5 px-4 py-3 rounded-xl border shadow-lg text-sm" id="settings-toast-inner">
            <i id="settings-toast-icon" data-lucide="check-circle" class="w-4 h-4"></i>
            <span id="settings-toast-text">Saved</span>
        </div>
    </div>
</div>
  `}let z=[],j=0;const F=2;function G(s=!1){const e=document.getElementById("trace-timeline-container"),i=document.getElementById("trace-pagination"),n=document.getElementById("trace-page-info"),r=document.getElementById("trace-prev-btn"),o=document.getElementById("trace-next-btn");if(!e||!i)return;const f=Math.ceil(z.length/F);f<=1?i.classList.add("hidden"):(i.classList.remove("hidden"),n&&(n.innerText=`Page ${j+1} / ${f}`),r&&(r.disabled=j===0),o&&(o.disabled=j>=f-1));const p=()=>{e.innerHTML='<div class="absolute left-4 top-2 bottom-2 w-px bg-gray-200 border-l border-dashed border-gray-300 z-0"></div>';const d=j*F,L=Math.min(d+F,z.length),x=z.slice(d,L);x.forEach((I,A)=>{const E=d+A,h=I.Log;let M=h.Timestamp;try{M=new Date(h.Timestamp).toISOString().split("T")[1].replace("Z","")}catch{}let _="Transmission";h.Content_Snapshot&&typeof h.Content_Snapshot=="object"?h.Content_Snapshot.Action&&(_=`Action: <code class="text-indigo-600">${h.Content_Snapshot.Action}</code>`):typeof h.Content_Snapshot=="string"&&(_=h.Content_Snapshot);let P=`
                <div class="mt-2 space-y-1 bg-white border border-gray-100 rounded p-2 text-[10px] font-mono shadow-sm">
                    <div class="flex"><span class="text-gray-400 w-20 shrink-0">Hash: </span><span class="text-gray-600 truncate" title="${h.Entry_Hash||h.Genesis_Hash}">${h.Entry_Hash||h.Genesis_Hash}</span></div>
                    <div class="flex"><span class="text-gray-400 w-20 shrink-0">Prev: </span><span class="text-gray-600 truncate" title="${h.Prev_Hash}">${h.Prev_Hash}</span></div>
                    <div class="flex"><span class="text-gray-400 w-20 shrink-0">Sig: </span><span class="text-gray-600 truncate" title="${h.Signature}">${h.Signature}</span></div>
                </div>
            `,C=h.node_did.split(":").pop()||"Unknown",$="Target";const S=E===z.length-1,g=h.Entry_Hash||h.Genesis_Hash,B=z.find((c,N)=>N!==E&&c.Log.Prev_Hash===g);if(B)$=B.Log.node_did.split(":").pop()||"Unknown";else if(S&&h.target_did)$=h.target_did.split(":").pop()||"Unknown";else{const c=h.Prev_Hash;if(c&&c!=="Genesis"){const N=z.find(U=>U.Log.Entry_Hash===c||U.Log.Genesis_Hash===c);N&&($=N.Log.node_did.split(":").pop()||"Unknown")}}const T=`[ ${C} -> ${$} ]`,l=`
                  <div class="relative flex gap-4 mb-6 z-10 opacity-0 translate-y-2 transition-all duration-300" style="transition-delay: ${A*50}ms" id="trace-item-${E}">
                      <div class="w-8 h-8 rounded-full bg-white border border-gray-200 mt-1 flex items-center justify-center shrink-0 shadow-sm relative z-10">
                          <i data-lucide="${E===0?"bot":"arrow-right-left"}" class="w-3.5 h-3.5 ${E===0?"text-gray-600":"text-blue-500"}"></i>
                      </div>
                      <div class="flex-1 min-w-0 overflow-hidden">
                          <div class="flex items-center justify-between mb-1">
                              <span class="text-[13px] font-semibold text-gray-800 truncate" title="${h.node_did}">${T}</span>
                              <span class="text-[11px] text-gray-400 shrink-0">${M}</span>
                          </div>
                          <div class="text-[12px] text-gray-500 bg-gray-50 px-3 py-2 rounded-lg border border-gray-100">
                              ${_}
                          </div>
                          ${P}
                      </div>
                  </div>
            `;e.insertAdjacentHTML("beforeend",l)}),window.lucide&&window.lucide.createIcons(),requestAnimationFrame(()=>{x.forEach((I,A)=>{const E=document.getElementById(`trace-item-${d+A}`);E&&(E.classList.remove("opacity-0","translate-y-2"),E.classList.add("opacity-100","translate-y-0"))})})};s?(e.querySelectorAll(".z-10").forEach((L,x)=>{L.style.transitionDelay=`${x*30}ms`,L.classList.remove("opacity-100","translate-y-0"),L.classList.add("opacity-0","-translate-y-2")}),setTimeout(p,200)):p()}document.addEventListener("DOMContentLoaded",()=>{});window.toggleNodes=function(){const s=document.getElementById("nodes-list"),e=document.getElementById("nodes-chevron");!s||!e||(s.style.maxHeight==="0px"||s.style.maxHeight===""?(s.style.maxHeight="200px",s.style.opacity="1",e.style.transform="rotate(0deg)"):(s.style.maxHeight="0px",s.style.opacity="0",e.style.transform="rotate(-90deg)"))};window.showTraceTimeline=async function(s){var r;const e=document.getElementById("trace-modal");if(!e)return;e.classList.remove("hidden"),e.classList.add("flex");const i=document.getElementById("trace-session-id-label");i&&(i.innerText="ID: "+s.substring(0,12)+"...");const n=document.getElementById("trace-timeline-container");n&&(n.innerHTML='<div class="text-center text-sm py-4 text-gray-400">Loading trace via ATTP...</div>'),setTimeout(()=>{e.classList.remove("opacity-0");const o=e.querySelector(".timeline-content");o&&(o.classList.remove("scale-95","translate-y-4"),o.classList.add("scale-100","translate-y-0"))},10);try{const f=await(await fetch(`/api/traces/${s}`)).json();if(n){if(!f.Path||f.Path.length===0){n.innerHTML='<div class="text-center text-sm py-4 text-gray-400">No traces available for this session.</div>',(r=document.getElementById("trace-pagination"))==null||r.classList.add("hidden");return}z=f.Path,j=0,G(!1);const p=document.getElementById("trace-latency-value");if(p&&f.Path.length>0){const d=new Date(f.Path[0].Log.Timestamp).getTime()||Date.now(),L=new Date(f.Path[f.Path.length-1].Log.Timestamp).getTime()||Date.now(),x=Math.max(15,Math.abs(L-d));p.innerText=`Total Latency: ${x}ms`}else p&&(p.innerText="Total Latency: --ms")}}catch{n&&(n.innerHTML='<div class="text-center text-sm py-4 text-red-400">Failed to load trace.</div>')}};window.closeTraceTimeline=function(){const s=document.getElementById("trace-modal");if(!s)return;s.classList.add("opacity-0");const e=s.querySelector(".timeline-content");e&&(e.classList.remove("scale-100","translate-y-0"),e.classList.add("scale-95","translate-y-4")),setTimeout(()=>{s.classList.add("hidden"),s.classList.remove("flex")},300)};window.switchPage=function(s,e){document.querySelectorAll(".page-view").forEach(r=>{r.classList.add("hidden")});const i=document.getElementById(s);i&&i.classList.remove("hidden"),window.lucide&&window.lucide.createIcons(),document.querySelectorAll(".nav-btn").forEach(r=>{r.classList.remove("bg-brand-50","text-brand-600"),r.classList.add("text-gray-500","hover:bg-gray-50","hover:text-gray-800");const o=r.querySelector("i");o&&(o.classList.remove("opacity-90"),o.classList.add("opacity-70"))});const n=document.getElementById(e);if(n){n.classList.remove("text-gray-500","hover:bg-gray-50","hover:text-gray-800"),n.classList.add("bg-brand-50","text-brand-600");const r=n.querySelector("i");r&&(r.classList.remove("opacity-70"),r.classList.add("opacity-90"))}};window.closeAllDropdowns=function(){document.querySelectorAll(".dropdown-menu").forEach(e=>{e.classList.add("hidden"),e.classList.remove("dropdown-open")})};window.toggleMenu=function(s,e){s.stopPropagation(),document.querySelectorAll(".session-item").forEach(r=>{r.style.zIndex="1"});const i=document.getElementById(e);if(!i)return;const n=i.classList.contains("hidden");if(window.closeAllDropdowns(),n){const r=i.closest(".session-item");r&&(r.style.zIndex="40"),i.classList.remove("hidden"),i.classList.add("dropdown-open")}};window.showFlowDiagram=function(s){s.stopPropagation(),window.closeAllDropdowns();const e=document.getElementById("flow-modal");e&&(e.classList.remove("hidden"),e.classList.add("flex"),setTimeout(()=>{e.classList.remove("opacity-0");const i=e.querySelector(".flow-content");i&&(i.classList.remove("scale-95","translate-y-4"),i.classList.add("scale-100","translate-y-0"))},10))};window.closeFlowDiagram=function(){const s=document.getElementById("flow-modal");if(!s)return;s.classList.add("opacity-0");const e=s.querySelector(".flow-content");e&&(e.classList.remove("scale-100","translate-y-0"),e.classList.add("scale-95","translate-y-4")),setTimeout(()=>{s.classList.add("hidden"),s.classList.remove("flex")},300)};window.exportTraceReport=function(s){s.stopPropagation(),window.closeAllDropdowns();const e=document.getElementById("export-toast");e&&(e.classList.remove("opacity-0","translate-x-10","pointer-events-none"),e.classList.add("opacity-100","translate-x-0"),setTimeout(()=>{e.classList.remove("opacity-100","translate-x-0"),e.classList.add("opacity-0","translate-x-10","pointer-events-none")},3e3))};window.deleteSession=function(s,e){s.stopPropagation();const i=e.closest(".session-item");i&&(i.style.opacity="0",i.style.transform="scale(0.95)",setTimeout(()=>{i.remove()},200))};window.unpinSession=function(s,e){s.stopPropagation(),window.closeAllDropdowns();const i=e.closest(".session-item"),n=document.getElementById("recent-list");i&&n&&(i.style.transition="all 0.3s ease",i.style.opacity="0",i.style.transform="scale(0.95)",setTimeout(()=>{e.innerHTML='<i data-lucide="pin" class="w-3.5 h-3.5"></i> 置顶',e.setAttribute("onclick","pinSession(event, this)"),n.prepend(i),window.lucide&&window.lucide.createIcons(),setTimeout(()=>{i.style.opacity="1",i.style.transform="scale(1)"},10)},300))};window.pinSession=function(s,e){s.stopPropagation(),window.closeAllDropdowns();const i=e.closest(".session-item"),n=document.getElementById("pinned-list");i&&n&&(i.style.transition="all 0.3s ease",i.style.opacity="0",i.style.transform="scale(0.95)",setTimeout(()=>{e.innerHTML='<i data-lucide="pin-off" class="w-3.5 h-3.5"></i> 取消置顶',e.setAttribute("onclick","unpinSession(event, this)"),n.prepend(i),window.lucide&&window.lucide.createIcons(),setTimeout(()=>{i.style.opacity="1",i.style.transform="scale(1)"},10)},300))};function fe(){const s=document.getElementById("trace-prev-btn"),e=document.getElementById("trace-next-btn");s&&s.addEventListener("click",()=>{j>0&&(j--,G(!0))}),e&&e.addEventListener("click",()=>{const r=Math.ceil(z.length/F);j<r-1&&(j++,G(!0))}),window.lucide&&window.lucide.createIcons(),document.querySelectorAll(".page-view").forEach(r=>{r.classList.add("hidden")});const i=document.getElementById("view-home");i&&i.classList.remove("hidden");const n=document.getElementById("nav-home");if(n){n.classList.add("bg-brand-50","text-brand-600","font-medium"),n.classList.remove("text-gray-500","hover:bg-gray-50","hover:text-gray-900","hover:text-gray-800");const r=n.querySelector("i");r&&(r.classList.remove("opacity-70"),r.classList.add("opacity-90","text-brand-600"))}}window.filterSessions=function(s){const e=s.target.value.toLowerCase();document.querySelectorAll(".session-item").forEach(n=>{var f;const r=n,o=((f=r.getAttribute("data-title"))==null?void 0:f.toLowerCase())||"";r.style.transition||(r.style.transition="all 0.3s ease"),o.includes(e)?(r.style.display="flex",setTimeout(()=>{r.style.opacity="1",r.style.transform="scale(1)"},10)):(r.style.opacity="0",r.style.transform="scale(0.95)",setTimeout(()=>{r.style.display="none"},300))})};window.renderDynamicNodes=async function(){try{const e=await(await fetch("/api/nodes")).json(),i=document.getElementById("nodes-list");if(!i)return;i.innerHTML="",window.agentNodes=e.agents||[],window.agentNodes.forEach((r,o)=>{const f=`nav-node-${o}`,p=r.capabilities.includes("data_storage")?"database":r.capabilities.includes("security_check")?"shield-check":"server",d=r.online?"bg-emerald-400":"bg-amber-400",L=r.online?"Online":"Offline";i.insertAdjacentHTML("beforeend",`
                <button id="${f}" onclick="window.openNodeView(${o}, '${f}')" class="nav-btn w-full flex items-center px-2.5 py-2 text-[13px] text-gray-500 hover:bg-gray-50 hover:text-gray-800 rounded-lg transition-colors">
                    <i data-lucide="${p}" class="w-4 h-4 mr-2.5 opacity-70"></i>
                    <span class="flex-1 text-left truncate">${r.name}</span>
                    <span class="w-1.5 h-1.5 rounded-full ${d}" title="${L}"></span>
                </button>
            `)}),window.lucide&&window.lucide.createIcons();const n=document.getElementById("trace-latency-value");if(n&&e.Path.length>0){const r=new Date(e.Path[0].Log.Timestamp).getTime()||Date.now(),o=new Date(e.Path[e.Path.length-1].Log.Timestamp).getTime()||Date.now(),f=Math.max(15,Math.abs(o-r));n.innerText=`Total Latency: ${f}ms`}else n&&(n.innerText="Total Latency: --ms")}catch(s){console.error("Failed to load nodes:",s)}};window.openNodeView=function(s,e){var p;const i=window.agentNodes[s];if(!i)return;const n=document.getElementById("node-messages-container");if(n){n.innerHTML="";const d=typeof window.getCurrentSession=="function"?window.getCurrentSession():null,L=((p=d==null?void 0:d.nodeHistories)==null?void 0:p[i.did])||[];if(L.length>0&&typeof window.renderNodeMessageHtml=="function"){let x="";L.forEach(I=>{x+=window.renderNodeMessageHtml(I.role,I.text,I.timeStr)}),n.innerHTML=x}requestAnimationFrame(()=>{n.parentElement&&(n.parentElement.scrollTop=n.parentElement.scrollHeight)})}const r=i.capabilities.includes("data_storage")?"database":i.capabilities.includes("security_check")?"shield-check":"server";document.getElementById("node-header-icon").innerHTML=`<i data-lucide="${r}" class="w-6 h-6 text-emerald-600"></i>`,document.getElementById("node-header-name").innerText=i.name,document.getElementById("node-header-desc").innerText=i.description||"",document.getElementById("node-header-did").innerText=i.did,document.getElementById("node-header-endpoint").innerHTML=`<i data-lucide="link-2" class="w-3 h-3 text-gray-400"></i> ${i.ad_url}`;let o="";i.capabilities.forEach(d=>{o+=`<span class="text-[11px] px-2 py-0.5 rounded-md bg-gray-50 text-gray-500 border border-gray-100 font-mono">${d}</span>`}),document.getElementById("node-header-skills").innerHTML=o;const f=document.getElementById("node-header-status-badge");f&&(i.online===!0?(f.className="px-2 py-0.5 rounded-md text-[10px] font-medium text-emerald-600 bg-emerald-50 border border-emerald-100 flex items-center gap-1.5",f.innerHTML='<span class="w-1 h-1 rounded-full bg-emerald-500"></span> Online'):(f.className="px-2 py-0.5 rounded-md text-[10px] font-medium text-amber-600 bg-amber-50 border border-amber-100 flex items-center gap-1.5",f.innerHTML='<span class="w-1 h-1 rounded-full bg-amber-500"></span> Offline')),window.lucide&&window.lucide.createIcons(),window.switchPage("view-node-sec",e)};setTimeout(()=>{window.renderDynamicNodes&&window.renderDynamicNodes()},500);let R=null;function q(s,e,i=3e3){const n=document.getElementById("settings-toast"),r=document.getElementById("settings-toast-inner"),o=document.getElementById("settings-toast-icon"),f=document.getElementById("settings-toast-text");!n||!r||!o||!f||(f.innerText=s,e?(r.className="flex items-center gap-2.5 px-4 py-3 rounded-xl border shadow-lg text-sm bg-emerald-50 border-emerald-100 text-emerald-700",o.setAttribute("data-lucide","check-circle")):(r.className="flex items-center gap-2.5 px-4 py-3 rounded-xl border shadow-lg text-sm bg-red-50 border-red-100 text-red-700",o.setAttribute("data-lucide","x-circle")),window.lucide&&window.lucide.createIcons(),n.classList.remove("opacity-0","translate-x-10","pointer-events-none"),n.classList.add("opacity-100","translate-x-0"),setTimeout(()=>{n.classList.remove("opacity-100","translate-x-0"),n.classList.add("opacity-0","translate-x-10","pointer-events-none")},i))}function xe(s){const e=document.getElementById("settings-toast"),i=document.getElementById("settings-toast-inner"),n=document.getElementById("settings-toast-icon"),r=document.getElementById("settings-toast-text");!e||!i||!n||!r||(r.innerText=s,i.className="flex items-center gap-2.5 px-4 py-3 rounded-xl border shadow-lg text-sm bg-amber-50 border-amber-100 text-amber-700",n.setAttribute("data-lucide","alert-circle"),window.lucide&&window.lucide.createIcons(),e.classList.remove("opacity-0","translate-x-10","pointer-events-none"),e.classList.add("opacity-100","translate-x-0"),setTimeout(()=>{e.classList.remove("opacity-100","translate-x-0"),e.classList.add("opacity-0","translate-x-10","pointer-events-none")},5e3))}function V(s){const e=document.getElementById("cfg-node-ads-list");e&&(e.innerHTML="",s.forEach((i,n)=>{e.insertAdjacentHTML("beforeend",`
            <div class="flex items-center gap-2 node-ad-item" data-index="${n}">
                <input type="text" value="${i.replace(/"/g,'"')}" placeholder="http://host:port/agent/ad.json"
                    class="node-ad-input flex-1 text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
                <button onclick="window.removeNodeAd(${n})" class="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors shrink-0">
                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                </button>
            </div>
        `)}),window.lucide&&window.lucide.createIcons())}window.addNodeAd=function(){const s=document.getElementById("cfg-node-ads-list");if(!s)return;const e=s.querySelectorAll(".node-ad-item").length;s.insertAdjacentHTML("beforeend",`
        <div class="flex items-center gap-2 node-ad-item" data-index="${e}">
            <input type="text" value="" placeholder="http://host:port/agent/ad.json"
                class="node-ad-input flex-1 text-sm bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-gray-300 focus:bg-white transition-colors placeholder:text-gray-300 font-mono">
            <button onclick="window.removeNodeAd(${e})" class="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors shrink-0">
                <i data-lucide="trash-2" class="w-4 h-4"></i>
            </button>
        </div>
    `),window.lucide&&window.lucide.createIcons();const i=s.querySelectorAll(".node-ad-input");i.length>0&&i[i.length-1].focus()};window.removeNodeAd=function(s){const e=document.getElementById("cfg-node-ads-list");if(!e)return;const i=e.querySelectorAll(".node-ad-item");i[s]&&(i[s].style.opacity="0",i[s].style.transform="scale(0.95)",setTimeout(()=>{i[s].remove(),e.querySelectorAll(".node-ad-item").forEach((n,r)=>{n.setAttribute("data-index",String(r));const o=n.querySelector("button");o&&o.setAttribute("onclick",`window.removeNodeAd(${r})`)})},150))};function be(){const s=document.getElementById("cfg-node-ads-list");if(!s)return[];const e=[];return s.querySelectorAll(".node-ad-input").forEach(i=>{const n=i.value.trim();n&&e.push(n)}),e}window.loadSettingsConfig=async function(){var r,o,f,p,d,L,x,I,A,E,h,M,_,P,D,C,$,S,g;const s=document.getElementById("settings-loading"),e=document.getElementById("settings-disabled"),i=document.getElementById("settings-form-container"),n=document.getElementById("settings-attp-badge");if(!(!s||!e||!i||!n)){s.classList.remove("hidden"),e.classList.add("hidden"),i.classList.add("hidden");try{const T=await(await fetch("/api/config")).json();if(T.error||!T.config){s.classList.add("hidden"),e.classList.remove("hidden"),n.className="px-2 py-0.5 rounded-md text-[10px] font-medium text-amber-600 bg-amber-50 border border-amber-100",n.innerText="Disabled",window.lucide&&window.lucide.createIcons();return}const l=T.config,c=N=>document.getElementById(N);c("cfg-did")&&(c("cfg-did").value=l.did||""),c("cfg-did-doc-path")&&(c("cfg-did-doc-path").value=((r=l.attpClient)==null?void 0:r.didDocPath)||""),c("cfg-did-key-path")&&(c("cfg-did-key-path").value=((o=l.attpClient)==null?void 0:o.didKeyPath)||""),c("cfg-server-name")&&(c("cfg-server-name").value=((f=l.attpServer)==null?void 0:f.name)||""),c("cfg-server-prefix")&&(c("cfg-server-prefix").value=((p=l.attpServer)==null?void 0:p.prefix)||""),c("cfg-server-desc")&&(c("cfg-server-desc").value=((d=l.attpServer)==null?void 0:d.description)||""),c("cfg-server-host")&&(c("cfg-server-host").value=((L=l.attpServer)==null?void 0:L.serverHost)||""),c("cfg-server-port")&&(c("cfg-server-port").value=String(((x=l.attpServer)==null?void 0:x.serverPort)||"")),c("cfg-server-private-key")&&(c("cfg-server-private-key").value=((I=l.attpServer)==null?void 0:I.privateKeyPath)||""),c("cfg-server-public-key")&&(c("cfg-server-public-key").value=((A=l.attpServer)==null?void 0:A.publicKeyPath)||""),c("cfg-webapp-host")&&(c("cfg-webapp-host").value=((E=l.webApp)==null?void 0:E.host)||""),c("cfg-webapp-port")&&(c("cfg-webapp-port").value=String(((h=l.webApp)==null?void 0:h.port)||"")),R={host:((M=l.webApp)==null?void 0:M.host)||"",port:((_=l.webApp)==null?void 0:_.port)||0},c("cfg-tool-host")&&(c("cfg-tool-host").value=((P=l.tool)==null?void 0:P.host)||""),c("cfg-tool-port")&&(c("cfg-tool-port").value=String(((D=l.tool)==null?void 0:D.port)||"")),c("cfg-heartbeat-interval")&&(c("cfg-heartbeat-interval").value=String(((C=l.heartbeat)==null?void 0:C.interval)||"")),c("cfg-heartbeat-timeout")&&(c("cfg-heartbeat-timeout").value=String((($=l.heartbeat)==null?void 0:$.timeout)||"")),c("cfg-heartbeat-max-fail")&&(c("cfg-heartbeat-max-fail").value=String(((S=l.heartbeat)==null?void 0:S.maxFail)||"")),V(((g=l.attpClient)==null?void 0:g.nodeAds)||[]),s.classList.add("hidden"),i.classList.remove("hidden"),n.className="px-2 py-0.5 rounded-md text-[10px] font-medium text-emerald-600 bg-emerald-50 border border-emerald-100",n.innerText="Active",window.lucide&&window.lucide.createIcons()}catch{s.classList.add("hidden"),e.classList.remove("hidden"),n.className="px-2 py-0.5 rounded-md text-[10px] font-medium text-red-500 bg-red-50 border border-red-100",n.innerText="Error",window.lucide&&window.lucide.createIcons()}}};window.refreshSettingsConfig=async function(){var s,e,i,n,r,o,f,p,d,L,x,I,A,E,h,M,_,P,D;try{const $=await(await fetch("/api/config?refresh=true")).json();if($.error){q("Failed to refresh configuration",!1);return}const S=$.config,g=B=>document.getElementById(B);g("cfg-did")&&(g("cfg-did").value=S.did||""),g("cfg-did-doc-path")&&(g("cfg-did-doc-path").value=((s=S.attpClient)==null?void 0:s.didDocPath)||""),g("cfg-did-key-path")&&(g("cfg-did-key-path").value=((e=S.attpClient)==null?void 0:e.didKeyPath)||""),g("cfg-server-name")&&(g("cfg-server-name").value=((i=S.attpServer)==null?void 0:i.name)||""),g("cfg-server-prefix")&&(g("cfg-server-prefix").value=((n=S.attpServer)==null?void 0:n.prefix)||""),g("cfg-server-desc")&&(g("cfg-server-desc").value=((r=S.attpServer)==null?void 0:r.description)||""),g("cfg-server-host")&&(g("cfg-server-host").value=((o=S.attpServer)==null?void 0:o.serverHost)||""),g("cfg-server-port")&&(g("cfg-server-port").value=String(((f=S.attpServer)==null?void 0:f.serverPort)||"")),g("cfg-server-private-key")&&(g("cfg-server-private-key").value=((p=S.attpServer)==null?void 0:p.privateKeyPath)||""),g("cfg-server-public-key")&&(g("cfg-server-public-key").value=((d=S.attpServer)==null?void 0:d.publicKeyPath)||""),g("cfg-webapp-host")&&(g("cfg-webapp-host").value=((L=S.webApp)==null?void 0:L.host)||""),g("cfg-webapp-port")&&(g("cfg-webapp-port").value=String(((x=S.webApp)==null?void 0:x.port)||"")),g("cfg-tool-host")&&(g("cfg-tool-host").value=((I=S.tool)==null?void 0:I.host)||""),g("cfg-tool-port")&&(g("cfg-tool-port").value=String(((A=S.tool)==null?void 0:A.port)||"")),g("cfg-heartbeat-interval")&&(g("cfg-heartbeat-interval").value=String(((E=S.heartbeat)==null?void 0:E.interval)||"")),g("cfg-heartbeat-timeout")&&(g("cfg-heartbeat-timeout").value=String(((h=S.heartbeat)==null?void 0:h.timeout)||"")),g("cfg-heartbeat-max-fail")&&(g("cfg-heartbeat-max-fail").value=String(((M=S.heartbeat)==null?void 0:M.maxFail)||"")),R={host:((_=S.webApp)==null?void 0:_.host)||"",port:((P=S.webApp)==null?void 0:P.port)||0},V(((D=S.attpClient)==null?void 0:D.nodeAds)||[]),q("Configuration refreshed from disk",!0)}catch{q("Network error: failed to refresh",!1)}};window.saveSettingsConfig=async function(){var o,f,p,d,L,x,I,A,E,h,M,_,P,D,C,$,S;const s=document.getElementById("settings-save-btn");if(!s)return;const e=g=>document.getElementById(g),i=be(),n={did:((o=e("cfg-did"))==null?void 0:o.value)||"",attpClient:{didDocPath:((f=e("cfg-did-doc-path"))==null?void 0:f.value)||"",didKeyPath:((p=e("cfg-did-key-path"))==null?void 0:p.value)||"",nodeAds:i},attpServer:{name:((d=e("cfg-server-name"))==null?void 0:d.value)||"",prefix:((L=e("cfg-server-prefix"))==null?void 0:L.value)||"",description:((x=e("cfg-server-desc"))==null?void 0:x.value)||"",serverHost:((I=e("cfg-server-host"))==null?void 0:I.value)||"",serverPort:parseInt(((A=e("cfg-server-port"))==null?void 0:A.value)||"0",10),privateKeyPath:((E=e("cfg-server-private-key"))==null?void 0:E.value)||"",publicKeyPath:((h=e("cfg-server-public-key"))==null?void 0:h.value)||""},webApp:{host:((M=e("cfg-webapp-host"))==null?void 0:M.value)||"",port:parseInt(((_=e("cfg-webapp-port"))==null?void 0:_.value)||"0",10)},tool:{host:((P=e("cfg-tool-host"))==null?void 0:P.value)||"",port:parseInt(((D=e("cfg-tool-port"))==null?void 0:D.value)||"0",10)},heartbeat:{interval:parseInt(((C=e("cfg-heartbeat-interval"))==null?void 0:C.value)||"0",10),timeout:parseInt((($=e("cfg-heartbeat-timeout"))==null?void 0:$.value)||"0",10),maxFail:parseInt(((S=e("cfg-heartbeat-max-fail"))==null?void 0:S.value)||"0",10)}};s.disabled=!0,s.classList.add("opacity-70");const r=s.innerHTML;s.innerHTML='<span class="flex items-center gap-1.5"><i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i> Saving...</span>',window.lucide&&window.lucide.createIcons();try{const B=await(await fetch("/api/config",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(n)})).json();B.success?(R={host:n.webApp.host,port:n.webApp.port},q("Configuration saved (not yet applied)",!0)):q(B.error||"Failed to save configuration",!1)}catch{q("Network error: failed to save",!1)}finally{s.disabled=!1,s.classList.remove("opacity-70"),s.innerHTML=r,window.lucide&&window.lucide.createIcons()}};window.reloadSettingsConfig=async function(){var n,r,o,f,p,d,L,x,I,A,E,h,M,_,P,D,C,$,S;const s=document.getElementById("settings-reload-btn");if(!s)return;const e=R?{...R}:null;s.disabled=!0,s.classList.add("opacity-70");const i=s.innerHTML;s.innerHTML='<span class="flex items-center gap-1.5"><i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i> Reloading...</span>',window.lucide&&window.lucide.createIcons();try{const B=await(await fetch("/api/config/reload",{method:"POST"})).json();if(B.success){const T=B.config,l=N=>document.getElementById(N);l("cfg-did")&&(l("cfg-did").value=T.did||""),l("cfg-did-doc-path")&&(l("cfg-did-doc-path").value=((n=T.attpClient)==null?void 0:n.didDocPath)||""),l("cfg-did-key-path")&&(l("cfg-did-key-path").value=((r=T.attpClient)==null?void 0:r.didKeyPath)||""),l("cfg-server-name")&&(l("cfg-server-name").value=((o=T.attpServer)==null?void 0:o.name)||""),l("cfg-server-prefix")&&(l("cfg-server-prefix").value=((f=T.attpServer)==null?void 0:f.prefix)||""),l("cfg-server-desc")&&(l("cfg-server-desc").value=((p=T.attpServer)==null?void 0:p.description)||""),l("cfg-server-host")&&(l("cfg-server-host").value=((d=T.attpServer)==null?void 0:d.serverHost)||""),l("cfg-server-port")&&(l("cfg-server-port").value=String(((L=T.attpServer)==null?void 0:L.serverPort)||"")),l("cfg-server-private-key")&&(l("cfg-server-private-key").value=((x=T.attpServer)==null?void 0:x.privateKeyPath)||""),l("cfg-server-public-key")&&(l("cfg-server-public-key").value=((I=T.attpServer)==null?void 0:I.publicKeyPath)||""),l("cfg-webapp-host")&&(l("cfg-webapp-host").value=((A=T.webApp)==null?void 0:A.host)||""),l("cfg-webapp-port")&&(l("cfg-webapp-port").value=String(((E=T.webApp)==null?void 0:E.port)||"")),l("cfg-tool-host")&&(l("cfg-tool-host").value=((h=T.tool)==null?void 0:h.host)||""),l("cfg-tool-port")&&(l("cfg-tool-port").value=String(((M=T.tool)==null?void 0:M.port)||"")),l("cfg-heartbeat-interval")&&(l("cfg-heartbeat-interval").value=String(((_=T.heartbeat)==null?void 0:_.interval)||"")),l("cfg-heartbeat-timeout")&&(l("cfg-heartbeat-timeout").value=String(((P=T.heartbeat)==null?void 0:P.timeout)||"")),l("cfg-heartbeat-max-fail")&&(l("cfg-heartbeat-max-fail").value=String(((D=T.heartbeat)==null?void 0:D.maxFail)||"")),V(((C=T.attpClient)==null?void 0:C.nodeAds)||[]);const c={host:(($=T.webApp)==null?void 0:$.host)||"",port:((S=T.webApp)==null?void 0:S.port)||0};e&&(e.host!==c.host||e.port!==c.port)&&setTimeout(()=>{xe("Web App host/port 已变更，需要手动重启 agent 使其完全生效")},500),R=c,q("Configuration reloaded and applied",!0)}else q(B.error||"Failed to reload configuration",!1)}catch{q("Network error: failed to reload",!1)}finally{s.disabled=!1,s.classList.remove("opacity-70"),s.innerHTML=i,window.lucide&&window.lucide.createIcons()}};const ye=document.querySelector("#app");ye.innerHTML=`
  ${le()}
  
  <main class="flex-1 flex flex-col relative h-full bg-surface" id="main-content">
    ${pe()}
    ${ge()}
    ${ue()}
    ${me()}
  </main>
  
  ${ce()}
`;fe();de();const J=document.createElement("script");J.src="https://unpkg.com/lucide@latest";J.onload=()=>{window.lucide&&window.lucide.createIcons()};document.head.appendChild(J);
