from pathlib import Path

import pandas as pd



def save_dataframe_file(df: pd.DataFrame, output_file: str) -> None:
    """Save a pandas DataFrame to file based on extension.

    Supported formats: csv, tsv, jsonl, json, xlsx.

    Args:
        df: The pandas DataFrame to save.
        output_file: Path to the output file. Extension determines the format.

    Raises:
        ValueError: If the file extension is not supported.
    """
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    suffix = Path(output_file).suffix.lower()
    handlers = {
        ".csv": lambda: df.to_csv(output_file, index=False),
        ".tsv": lambda: df.to_csv(output_file, sep="\t", index=False),
        ".jsonl": lambda: df.to_json(output_file, orient="records", lines=True, force_ascii=False),
        ".json": lambda: df.to_json(output_file, orient="records", force_ascii=False),
        ".xlsx": lambda: df.to_excel(output_file, index=False),
    }

    handler = handlers.get(suffix)
    if handler is None:
        raise ValueError(
            f"Unsupported file extension '{suffix}' in '{output_file}'. "
            f"Supported: {', '.join(handlers.keys())}"
        )
    handler()
