import pandas as pd
from pathlib import Path


def load_file_dataframe(input_file: str, names: list[str] | None = None) -> pd.DataFrame | None:
    """Load a file into a pandas DataFrame based on file extension.

    Supported formats: csv, tsv, xlsx, jsonl, json.

    Args:
        input_file: Path to the input file.
        names: Optional column names for CSV/TSV files.

    Returns:
        A pandas DataFrame if the file format is supported, otherwise None.
    """
    suffix = Path(input_file).suffix.lower()
    loaders = {
        '.csv': lambda: pd.read_csv(input_file, names=names),
        '.tsv': lambda: pd.read_csv(input_file, sep='\t', names=names),
        '.xlsx': lambda: pd.read_excel(input_file),
        '.jsonl': lambda: pd.read_json(input_file, lines=True),
        '.json': lambda: pd.read_json(input_file),
    }
    loader = loaders.get(suffix)
    if loader:
        return loader()
    print(f"File: {input_file}, doesn't contain a supported suffix [csv, tsv, jsonl, json, xlsx]")
    return None
