"""Weighted Quick-Union with Path-Compression Union-Find data structure.

Maintains disjoint sets (connected components) with efficient merge
and connectivity operations.

Example::

    >>> uf = UnionFind(['a', 'b', 'c', 'd'])
    >>> uf.union('a', 'b')
    >>> uf.union('c', 'd')
    >>> uf.connected('a', 'b')
    True
    >>> uf.connected('a', 'c')
    False
    >>> uf.union('b', 'c')
    >>> uf.connected('a', 'c')
    True
    >>> uf.components()
    [{'a', 'b', 'c', 'd'}]
"""

class UnionFind:
    """Weighted quick-union with path compression.

    Operations:
    - ``add``: add a new element as a singleton component.
    - ``union``: merge two components (amortized nearly O(1)).
    - ``find``: return the root of an element's component.
    - ``connected``: check if two elements share the same root.
    - ``components``: return all connected components.
    """

    def __init__(self, elements: list | None = None):
        self.num_elements = 0
        self.num_components = 0
        self._next = 0
        self._elements: list = []
        self._indx: dict = {}
        self._parent: list[int] = []
        self._size: list[int] = []

        if elements:
            for elem in elements:
                self.add(elem)

    def __repr__(self):
        return (
            f"<UnionFind: elements={self._elements!r}, size={self._size!r}, "
            f"parent={self._parent!r}, num_elements={self.num_elements}, "
            f"num_components={self.num_components}>"
        )

    def __len__(self):
        return self.num_elements

    def __contains__(self, x):
        return x in self._indx

    def __getitem__(self, index: int):
        if index < 0 or index >= self._next:
            raise IndexError(f"index {index} is out of bound")
        return self._elements[index]

    def __setitem__(self, index: int, x):
        if index < 0 or index >= self._next:
            raise IndexError(f"index {index} is out of bound")
        self._elements[index] = x

    def add(self, elem) -> None:
        """Add a single disjoint element as a new component."""
        if elem in self:
            return
        self._elements.append(elem)
        self._indx[elem] = self._next
        self._parent.append(self._next)
        self._size.append(1)
        self._next += 1
        self.num_elements += 1
        self.num_components += 1

    def find(self, elem) -> int:
        """Find the root of the disjoint set containing *elem*.

        Raises:
            ValueError: If *elem* is not in the structure.
        """
        if elem not in self._indx:
            raise ValueError(f"{elem!r} is not an element")

        p = self._indx[elem]
        while p != self._parent[p]:
            q = self._parent[p]
            self._parent[p] = self._parent[q]
            p = q
        return p

    def connected(self, x, y) -> bool:
        """Return whether *x* and *y* belong to the same component."""
        return self.find(x) == self.find(y)

    def union(self, x, y) -> None:
        """Merge the components containing *x* and *y* into one.

        Elements not yet in the structure are auto-added.
        """
        for elt in (x, y):
            if elt not in self:
                self.add(elt)

        xroot = self.find(x)
        yroot = self.find(y)
        if xroot == yroot:
            return
        if self._size[xroot] < self._size[yroot]:
            self._parent[xroot] = yroot
            self._size[yroot] += self._size[xroot]
        else:
            self._parent[yroot] = xroot
            self._size[xroot] += self._size[yroot]
        self.num_components -= 1

    def _roots(self) -> list[int]:
        """Return a list of unique root indices (component representatives)."""
        return [i for i in range(self._next) if self._parent[i] == i]

    def component(self, x) -> set:
        """Return the connected component containing *x*.

        Raises:
            ValueError: If *x* is not in the structure.
        """
        if x not in self:
            raise ValueError(f"{x!r} is not an element")
        target = self.find(x)
        return {elt for elt in self._elements if self.find(elt) == target}

    def components(self) -> list[set]:
        """Return the list of all connected components."""
        mapping: dict[int, set] = {}
        for elt in self._elements:
            root = self.find(elt)
            mapping.setdefault(root, set()).add(elt)
        return list(mapping.values())

    def component_mapping(self) -> dict:
        """Return a dict mapping each element to its connected component set.

        Example::

            >>> uf = UnionFind(['a', 'b', 'c'])
            >>> uf.union('a', 'b')
            >>> m = uf.component_mapping()
            >>> m['a'] is m['b']  # same set object
            True
        """
        mapping: dict[int, set] = {}
        result: dict = {}
        for elt in self._elements:
            root = self.find(elt)
            component = mapping.setdefault(root, set())
            component.add(elt)
            result[elt] = component
        return result
