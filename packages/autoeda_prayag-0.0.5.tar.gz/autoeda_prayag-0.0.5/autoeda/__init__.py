from .analyzer import analyze
from .insights import target_analysis

def run(df, target=None):
    analyze(df)
    
    if target:
        target_analysis(df, target)