import pandas as pd
import argparse
from .analyzer import analyze


def main():
    parser = argparse.ArgumentParser(
        description="AutoEDA: Automated Exploratory Data Analysis Tool"
    )

    parser.add_argument(
        "file",
        help="Path to input CSV file"
    )

    parser.add_argument(
        "--target",
        type=str,
        default=None,
        help="Target column for analysis (optional)"
    )

    parser.add_argument(
        "--no-clean",
        action="store_true",
        help="Disable automatic cleaning"
    )

    args = parser.parse_args()

    try:
        df = pd.read_csv(args.file)
    except Exception as e:
        print(f" Error reading file: {e}")
        return

    print("\n Running AutoEDA...\n")

    analyze(
        df,
        target=args.target,
        clean=not args.no_clean
    )

    print("\n Analysis complete!")