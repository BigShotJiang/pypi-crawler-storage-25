import seaborn as sns
import matplotlib.pyplot as plt


def generate_insights(df):
    print("\n ===== INSIGHTS =====")

    total_missing = df.isnull().sum().sum()
    total_duplicates = df.duplicated().sum()

    # Missing values
    if total_missing > 0:
        print(f"- Missing values detected: {total_missing}")
    else:
        print("- No missing values detected")

    # Duplicates
    if total_duplicates > 0:
        print(f"- Duplicate rows found: {total_duplicates}")
    else:
        print("- No duplicate rows found")

    # Feature count
    if len(df.columns) > 15:
        print(f"- High number of features ({len(df.columns)}). Feature selection may help.")

    # Numeric analysis
    numeric = df.select_dtypes(include="number")

    if not numeric.empty:
        variance = numeric.var().mean()
        if variance < 1:
            print("- Low variance detected. Scaling recommended.")

        skewness = numeric.skew()
        high_skew = skewness[abs(skewness) > 1]

        if not high_skew.empty:
            print("\n Highly skewed features:")
            print(high_skew)

    # High correlation detection
    corr = df.corr(numeric_only=True)
    high_corr = corr[(corr > 0.8) & (corr < 1)]

    if high_corr.any().any():
        print("\n🔗 High correlations detected between features")


def target_analysis(df, target):
    print("\n🎯 ===== TARGET ANALYSIS =====")

    if target not in df.columns:
        print(f" Column '{target}' not found in dataset")
        return

    counts = df[target].value_counts()

    print("\n Distribution:")
    print(counts)

    print("\n Percentage:")
    print((counts / len(df)) * 100)

    plt.figure(figsize=(6, 4))
    sns.countplot(x=df[target])
    plt.title(f"Distribution of {target}")
    plt.tight_layout()
    plt.show()