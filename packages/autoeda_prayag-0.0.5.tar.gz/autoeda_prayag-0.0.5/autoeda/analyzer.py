import pandas as pd
from .visualizer import plot_missing, plot_corr, plot_high_corr
from .insights import generate_insights


def analyze(df: pd.DataFrame, target=None, clean=True):
    """
    Perform automated EDA on a DataFrame.
    
    Parameters:
    - df: pandas DataFrame
    - target: optional target column for analysis
    - clean: whether to auto-clean basic issues
    """

   
    if clean:
        
        df = df.loc[:, ~df.columns.str.contains("^Unnamed")]

    print("\n ===== BASIC INFO =====")
    print(df.info())

    print("\n ===== SUMMARY STATS =====")
    print(df.describe())

    print("\n ===== MISSING VALUES =====")
    missing = df.isnull().sum()
    print(missing[missing > 0] if missing.sum() > 0 else "No missing values")

    print("\n ===== DUPLICATES =====")
    duplicates = df.duplicated().sum()
    print(duplicates)

   
    if missing.sum() > 0:
        plot_missing(df)
    else:
        print("✅ No missing values to visualize")

  
    plot_corr(df)


    plot_high_corr(df)


    generate_insights(df)

    if target and target in df.columns:
        print(f"\n🎯 ===== TARGET: {target} =====")
        print(df[target].value_counts())

    return df  