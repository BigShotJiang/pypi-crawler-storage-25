import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Optional: global style
sns.set(style="whitegrid")


def plot_missing(df):
    """
    Plot missing values as a bar chart.
    Shows only columns with missing values.
    """
    missing = df.isnull().sum()

    if missing.sum() == 0:
        print(" No missing values to visualize")
        return

    # Filter only columns with missing values
    missing = missing[missing > 0].sort_values(ascending=False)

    plt.figure(figsize=(10, 5))
    missing.plot(kind='bar', color='red')

    plt.title("Missing Values Count per Column")
    plt.ylabel("Count")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()


def plot_corr(df):
    """
    Plot correlation heatmap (lower triangle only for clarity).
    """
    corr = df.corr(numeric_only=True)

    if corr.empty:
        print("⚠️ No numeric data for correlation")
        return

    plt.figure(figsize=(12, 10))

    # Mask upper triangle
    mask = np.triu(np.ones_like(corr, dtype=bool))

    sns.heatmap(
        corr,
        mask=mask,
        cmap="coolwarm",
        annot=False,
        linewidths=0.5
    )

    plt.title("Correlation Matrix (Lower Triangle)")
    plt.tight_layout()
    plt.show()


def plot_high_corr(df, threshold=0.8):
    """
    Print highly correlated feature pairs.
    """
    corr = df.corr(numeric_only=True)

    high_corr = corr[(corr > threshold) & (corr < 1)]

    if not high_corr.any().any():
        print(" No high correlations found")
        return

    print("\n🔗 High Correlations:")
    print(high_corr.dropna(how="all").dropna(axis=1, how="all"))