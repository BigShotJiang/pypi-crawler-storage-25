"""Short alias package for ``neuralnode``."""

from neuralnode import *  # noqa: F401,F403

from neuralnode import __version__

