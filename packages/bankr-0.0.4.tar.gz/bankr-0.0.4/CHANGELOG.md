Bankr - Changelog
=================

v0.0.4 (04/2026)
----------------

- Remove Pandas dot notation from function "condition_book"
- Separate columns in book-v1.yaml in mandatory and optional parameters
- Implement book-v2.yaml, which adds column tag to book-v1.yaml. Use function "book_v1_to_v2" in iPython to upgrade.
- Upgrade data.sample to book-v2.yaml


v0.0.3 (02/2025)
----------------

- Corrections of i18n
- "source" in book-v1.yaml switched to string to simplify the edit of transactions
- Improvement of the Dashboards, but still preliminary
- Some TODOs removed, others are left
- Fragments of command "app" added


v0.0.2 (01/2025)
----------------

- Improved documentation (p0.0.2)
- Sample data added


v0.0.1 (01/2025)
----------------

Initial release
