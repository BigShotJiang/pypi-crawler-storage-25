"""*Bankr* - Utils for development"""

from pathlib import Path


def debugger() -> None:
    import debugpy

    debugpy.listen(5678)
    print("Waiting for debugger...")
    debugpy.wait_for_client()
    print("Debugger attached.")


def book_v1_to_v2(path: Path) -> None:
    # Very simple function to update to book-v2.pickle = add column "tag"
    # Create Posix Path, e.g., path = Path("my/path").resolve()
    # Attention: No error treatment, meant to be used in ipython.
    import pandas as pd
    import bankr.files as bf

    # Read book-v1.pickle in path, and create book-v2.pickle in path
    book = pd.read_pickle(path / "book-v1.pickle")
    book_format = bf.read_bankr_yaml(path / "book-v2.yaml")
    book["tag"] = "none"
    book["tag"] = book["tag"].astype("category")
    book = book[[*book_format]]
    book.to_pickle(path / "book-v2.pickle")
