---
name: install-prefect
description: >
  Install, update, and verify the Prefect CLI and configure server connection.
  Use when the user says /install-prefect, 'install prefect', 'setup prefect',
  'configurer prefect', or needs the prefect CLI configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install, verify, and update the Prefect CLI, then configure the server connection.

## Step 1 — Check current state

```bash
pysae-ai-tools install prefect check --json
```

Returns JSON with `binary`, `latest` (from PyPI), `profile`, `api_url`, `needs_install`, `needs_update`.

| `needs_install` | `needs_update` | `api_url` | Action |
|---|---|---|---|
| `true` | — | — | Step 2 (install) → Step 3 (configure) |
| `false` | `true` | — | Step 2 (update) → verify config |
| `false` | `false` | empty | Step 3 (configure) |
| `false` | `false` | set | **Done** — tell the user everything is OK |

## Step 2 — Install or update

```bash
pysae-ai-tools install prefect install --json
```

The script installs via `uv tool` (isolated venv, manages Python automatically). Cross-platform: works on Linux, macOS, Windows.

> Prerequisite: Python 3.11+ available. On Windows install Python from https://www.python.org or the Microsoft Store.

## Step 3 — Configure server connection

Ask the user which Prefect server they use:

> Quel serveur Prefect ?
> 1. **Prefect Cloud** — `! prefect cloud login` (interactive)
> 2. **Self-hosted** — `prefect config set PREFECT_API_URL="<server-url>/api"`

`prefect cloud login` opens a browser and MUST be run interactively (suggest `! <command>`), never via the Bash tool.

## Step 4 — Final verification

```bash
pysae-ai-tools install prefect check --json
```

Confirm `binary.installed` is true and `api_url` is set.

## Gotchas

- **`uv tool` isolates Prefect from system Python.** Recommended for clean upgrades.
- **Version pinning.** Some Pysae deployments require a specific Prefect version to match the server. Check the server version first, then run `uv tool install prefect==<version>` if a downgrade is needed.
- **Cloud login is interactive.** `prefect cloud login` opens a browser — never invoke via the Bash tool.
- **Windows works the same.** `uv` behaves identically on all platforms. No extra steps.

## Notes

- Pysae runs Prefect workers on EKS in the `prefect` namespace — see `/infra` for cluster operations.
- Profile/API URL changes persist in `~/.prefect/profiles.toml`.

$ARGUMENTS
