---
name: install-mongodb-atlas-mcp
description: >
  Install and configure the MongoDB Atlas MCP servers (dev + prod) for Claude Code.
  Use when the user says /install-mongodb-atlas-mcp, 'install atlas mcp', 'install mongodb atlas mcp',
  'setup atlas mcp', 'configurer atlas mcp', or needs the MongoDB Atlas MCP servers configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
  - Skill
---

Install and configure two MongoDB Atlas MCP servers: **mongodb-atlas-mcp-dev** and **mongodb-atlas-mcp-prod**.

## Step 1 — Check current state

```bash
pysae-ai-tools install mongodb-atlas-mcp check --json
```

Returns JSON for both servers with `configured`, `has_public_key`, `has_private_key`. Plus a top-level `needs_install`.

| `needs_install` | Action |
|---|---|
| `true` | Step 2 (prerequisites) → Step 3 (install) |
| `false` | **Done** — tell the user everything is OK |

## Step 2 — Prerequisites

- AWS CLI authenticated (`/install-aws-cli`) — keys live in AWS Secrets Manager
- `npx` available (Node.js installed)

```bash
which aws && which npx
```

## Step 3 — Install

```bash
pysae-ai-tools install mongodb-atlas-mcp install --json
```

The script:
1. Reads `pysae/mongodb-atlas/dev` and `pysae/mongodb-atlas/prod` from AWS Secrets Manager (each is JSON `{"public_key": "...", "private_key": "..."}`).
2. Upserts `mongodb-atlas-mcp-dev` and `mongodb-atlas-mcp-prod` into `~/.claude.json`.
3. Returns per-server `{"changed": true|false}`.

If AWS Secrets Manager is unavailable, fall back to manual env vars:

```bash
ATLAS_DEV_PUBLIC_KEY=... ATLAS_DEV_PRIVATE_KEY=... \
  ATLAS_PROD_PUBLIC_KEY=... ATLAS_PROD_PRIVATE_KEY=... \
  pysae-ai-tools install mongodb-atlas-mcp install --json --skip-aws
```

## Step 4 — Verify

> Redémarre Claude Code puis essaie : « liste les projets Atlas en dev ».

## Gotchas

- **AWS prerequisite.** Without a valid AWS session, the install fails with a clear error. Run `/install-aws-cli` (and `aws sso login` if needed) first.
- **Atlas API keys are credentials.** Never log or display them. The script never echoes them — only writes them to `~/.claude.json`.
- **Two distinct keypairs.** dev and prod use SEPARATE Atlas API keys. Don't reuse one for both.
- **Restart Claude Code after install.** MCP servers are loaded at startup.
- **`--skip-aws` is a fallback only.** Prefer the AWS Secrets Manager path so secrets don't leak through shell history.

## Notes

- Package: `mcp-mongodb-atlas` from npm (official MongoDB Atlas package).
- Capabilities: list/create projects, clusters, users; manage network access.

$ARGUMENTS
