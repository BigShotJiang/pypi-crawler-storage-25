---
name: install-postman-mcp
description: >
  Install and configure the Postman MCP server for Claude Code.
  Use when the user says /install-postman-mcp, 'install postman mcp',
  'setup postman', 'configurer postman mcp', or needs the Postman MCP
  server configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install and configure the Postman MCP server so Claude Code can manage Postman collections, environments, and workspaces.

## Step 1 — Check current state

```bash
pysae-ai-tools install postman-mcp check --json
```

Returns JSON with `configured`, `env` (POSTMAN_API_KEY presence), `needs_install`.

| `needs_install` | Action |
|---|---|
| `true` | Step 2 (key + install) |
| `false` | **Done** — tell the user everything is OK |

## Step 2 — Get the Postman API key

> Crée une clé API Postman sur https://go.postman.co/settings/me/api-keys et donne-moi la valeur.

## Step 3 — Install

```bash
POSTMAN_API_KEY=<key> pysae-ai-tools install postman-mcp install --json
```

Upserts the `postman` MCP server into `~/.claude.json` with `--minimal` mode (faster, essential tools). To use `--full` (100+ tools): `POSTMAN_MCP_MODE=--full ...`.

## Step 4 — Verify

> Redémarre Claude Code puis essaie : « liste mes workspaces Postman ».

## Gotchas

- **Restart Claude Code after install.** MCP servers are loaded at startup.
- **`--minimal` vs `--full`.** Default is `--minimal` (collection/env/workspace tools only). Switch to `--full` only when the user needs less common APIs (audit log, mocks, monitors).
- **API key scope.** The key inherits the user's Postman permissions — to access team workspaces, the user needs team membership, not extra scopes.
- **`npx` required.** Node.js must be installed and on `PATH`.

$ARGUMENTS
