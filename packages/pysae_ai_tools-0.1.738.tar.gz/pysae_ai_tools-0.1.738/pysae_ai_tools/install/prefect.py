"""Install or update the Prefect CLI via uv tool."""

import json
import shutil
import subprocess
from dataclasses import dataclass
from typing import Annotated

import httpx
import typer

from .common import binary

BINARY_NAME = "prefect"
PYPI_URL = "https://pypi.org/pypi/prefect/json"


def latest_version(timeout: float = 5.0) -> str:
    r = httpx.get(PYPI_URL, timeout=timeout, follow_redirects=True)
    r.raise_for_status()
    data = r.json()
    v = data.get("info", {}).get("version", "")
    return v if isinstance(v, str) else ""


def current_profile() -> str:
    if not binary.which(BINARY_NAME):
        return ""
    r = subprocess.run([BINARY_NAME, "profile", "ls"], capture_output=True, text=True, check=False, timeout=5)
    for line in r.stdout.splitlines():
        if line.strip().startswith("*"):
            # `* default` style
            return line.replace("*", "").strip()
    return ""


def api_url() -> str:
    if not binary.which(BINARY_NAME):
        return ""
    r = subprocess.run([BINARY_NAME, "config", "view"], capture_output=True, text=True, check=False, timeout=5)
    for line in r.stdout.splitlines():
        if "PREFECT_API_URL" in line:
            return line.split("=", 1)[-1].strip().strip("'\"")
    return ""


@dataclass
class State:
    binary: binary.BinaryStatus
    latest: str
    profile: str
    api_url: str

    def to_dict(self) -> dict[str, object]:
        return {
            "binary": self.binary.to_dict(),
            "latest": self.latest,
            "profile": self.profile,
            "api_url": self.api_url,
            "needs_install": not self.binary.installed,
            "needs_update": self.binary.installed and binary.needs_update(self.binary.version, self.latest),
        }


def get_state() -> State:
    bin_status = binary.status(BINARY_NAME, version_arg="version")
    try:
        latest = latest_version()
    except Exception:  # noqa: BLE001
        latest = ""
    return State(binary=bin_status, latest=latest, profile=current_profile(), api_url=api_url())


@dataclass
class InstallReport:
    action: str
    version: str = ""
    method: str = ""
    error: str = ""

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"action": self.action}
        for f in ("version", "method", "error"):
            v = getattr(self, f)
            if v:
                out[f] = v
        return out


def _try_uv() -> InstallReport | None:
    """Try installing via uv tool (fastest, isolated venv)."""
    if not shutil.which("uv"):
        return None
    r = subprocess.run(
        ["uv", "tool", "install", "--force", "--reinstall", "prefect"],
        capture_output=True,
        text=True,
        check=False,
    )
    if r.returncode == 0:
        return InstallReport(
            action="install",
            version=binary.get_version(BINARY_NAME, version_arg="version"),
            method="uv tool",
        )
    return InstallReport(action="install", error=f"uv tool failed: {r.stderr.strip() or r.stdout.strip()}")


def do_install() -> InstallReport:
    """Install via uv tool."""
    report = _try_uv()
    if report is None:
        return InstallReport(action="install", error="uv not found — install uv first: https://docs.astral.sh/uv/")
    return report


cli = typer.Typer(no_args_is_help=True, help="Install/update the Prefect CLI and configure server connection")


@cli.command()
def check(json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False) -> None:
    state = get_state()
    if json_output:
        typer.echo(json.dumps(state.to_dict()))
    else:
        b = state.binary
        typer.echo(f"prefect: {b.version or 'n/a'} (latest {state.latest or 'n/a'})")
        typer.echo(f"  profile: {state.profile or 'n/a'}")
        typer.echo(f"  api_url: {state.api_url or 'not set'}")


@cli.command()
def install(json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False) -> None:
    report = do_install()
    if json_output:
        typer.echo(json.dumps(report.to_dict()))
    elif report.error:
        typer.echo(f"FAILED: {report.error}", err=True)
    else:
        typer.echo(f"installed prefect {report.version} via {report.method}")


if __name__ == "__main__":
    cli()
