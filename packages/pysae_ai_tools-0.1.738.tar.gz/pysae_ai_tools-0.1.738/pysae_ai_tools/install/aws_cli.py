"""Install or update AWS CLI v2.

The AWS CLI v2 is distributed as a platform-specific installer (zip+install on
Linux, .pkg on macOS, .msi on Windows). Each platform has its own install path.
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated

import httpx
import typer

from .common import binary, platform
from .common.download import download, extract

BINARY_NAME = "aws"
TAGS_API = "https://api.github.com/repos/aws/aws-cli/tags?per_page=1"


def latest_v2_tag(timeout: float = 5.0) -> str:
    r = httpx.get(TAGS_API, timeout=timeout, follow_redirects=True)
    r.raise_for_status()
    data = r.json()
    if isinstance(data, list) and data:
        name = data[0].get("name", "")
        if isinstance(name, str):
            return name
    return ""


def auth_status() -> tuple[bool, str]:
    if not binary.which(BINARY_NAME):
        return False, "aws not installed"
    r = subprocess.run(
        [BINARY_NAME, "sts", "get-caller-identity"],
        capture_output=True,
        text=True,
        check=False,
        timeout=10,
    )
    return r.returncode == 0, (r.stdout + r.stderr).strip()


def list_profiles() -> list[str]:
    if not binary.which(BINARY_NAME):
        return []
    r = subprocess.run(
        [BINARY_NAME, "configure", "list-profiles"],
        capture_output=True,
        text=True,
        check=False,
        timeout=5,
    )
    return [line.strip() for line in r.stdout.splitlines() if line.strip()]


@dataclass
class State:
    binary: binary.BinaryStatus
    latest: str
    auth_ok: bool
    auth_message: str
    profiles: list[str]

    def to_dict(self) -> dict[str, object]:
        return {
            "binary": self.binary.to_dict(),
            "latest": self.latest,
            "auth_ok": self.auth_ok,
            "auth_message": self.auth_message,
            "profiles": self.profiles,
            "needs_install": not self.binary.installed,
            "needs_update": self.binary.installed and binary.needs_update(self.binary.version, self.latest),
        }


def get_state() -> State:
    bin_status = binary.status(BINARY_NAME, version_arg="--version")
    try:
        latest = latest_v2_tag().lstrip("v")
    except Exception:  # noqa: BLE001
        latest = ""
    ok, message = auth_status()
    return State(binary=bin_status, latest=latest, auth_ok=ok, auth_message=message, profiles=list_profiles())


@dataclass
class InstallReport:
    action: str
    version: str = ""
    path: str = ""
    error: str = ""

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"action": self.action}
        for f in ("version", "path", "error"):
            v = getattr(self, f)
            if v:
                out[f] = v
        return out


def _install_linux(arch: str, tmp: Path) -> tuple[str, str]:
    """Returns (path, error) — non-empty error on failure."""
    arch_token = "x86_64" if arch == "x86_64" else "aarch64"
    url = f"https://awscli.amazonaws.com/awscli-exe-linux-{arch_token}.zip"
    archive = tmp / "awscliv2.zip"
    download(url, archive)
    extract(archive, tmp / "awscli")
    installer = tmp / "awscli" / "aws" / "install"
    installer.chmod(0o755)
    # Try update first; fallback to fresh install
    cmd_update = ["sudo", str(installer), "--update"]
    r = subprocess.run(cmd_update, capture_output=True, text=True, check=False)
    if r.returncode != 0:
        r = subprocess.run(["sudo", str(installer)], capture_output=True, text=True, check=False)
    if r.returncode != 0:
        return "", r.stderr.strip() or r.stdout.strip()
    return binary.which(BINARY_NAME) or "/usr/local/bin/aws", ""


def _install_macos(tmp: Path) -> tuple[str, str]:
    url = "https://awscli.amazonaws.com/AWSCLIV2.pkg"
    pkg = tmp / "AWSCLIV2.pkg"
    download(url, pkg)
    r = subprocess.run(
        ["sudo", "installer", "-pkg", str(pkg), "-target", "/"],
        capture_output=True,
        text=True,
        check=False,
    )
    if r.returncode != 0:
        return "", r.stderr.strip() or r.stdout.strip()
    return binary.which(BINARY_NAME) or "/usr/local/bin/aws", ""


def _install_windows(tmp: Path) -> tuple[str, str]:
    url = "https://awscli.amazonaws.com/AWSCLIV2.msi"
    msi = tmp / "AWSCLIV2.msi"
    download(url, msi)
    # /qn = silent, /norestart for unattended install
    r = subprocess.run(
        ["msiexec", "/i", str(msi), "/qn", "/norestart"],
        capture_output=True,
        text=True,
        check=False,
    )
    if r.returncode != 0:
        return "", f"msiexec exited {r.returncode}: {r.stderr.strip() or r.stdout.strip()}"
    # Default install location
    default = Path(os.environ.get("ProgramFiles", r"C:\\Program Files")) / "Amazon" / "AWSCLIV2" / "aws.exe"
    return binary.which(BINARY_NAME) or str(default), ""


def do_install() -> InstallReport:
    try:
        plat = platform.detect()
    except ValueError as exc:
        return InstallReport(action="install", error=str(exc))

    with tempfile.TemporaryDirectory(prefix="pysae-aws-") as tmp_dir:
        tmp = Path(tmp_dir)
        try:
            if plat.is_linux:
                path, err = _install_linux(plat.arch.value, tmp)
            elif plat.is_macos:
                path, err = _install_macos(tmp)
            elif plat.is_windows:
                path, err = _install_windows(tmp)
            else:
                return InstallReport(action="install", error=f"unsupported OS: {plat.os}")
        except Exception as exc:  # noqa: BLE001
            return InstallReport(action="install", error=f"install failed: {exc}")

    if err:
        return InstallReport(action="install", error=err)

    # Force rehash on Linux/macOS so `which` finds the new binary
    if sys.platform != "win32":
        shutil.which(BINARY_NAME)
    installed_v = binary.get_version(BINARY_NAME, version_arg="--version")
    return InstallReport(action="install", version=installed_v, path=path)


cli = typer.Typer(no_args_is_help=True, help="Install/update the AWS CLI and configure SSO profiles")


@cli.command()
def check(json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False) -> None:
    state = get_state()
    if json_output:
        typer.echo(json.dumps(state.to_dict()))
    else:
        b = state.binary
        typer.echo(f"aws: {b.version or 'n/a'} (latest {state.latest or 'n/a'})")
        typer.echo(f"  auth: {'OK' if state.auth_ok else 'NOT authenticated'}")
        typer.echo(f"  profiles: {', '.join(state.profiles) or 'none'}")


@cli.command()
def install(json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False) -> None:
    report = do_install()
    if json_output:
        typer.echo(json.dumps(report.to_dict()))
    elif report.error:
        typer.echo(f"FAILED: {report.error}", err=True)
    else:
        typer.echo(f"installed aws-cli {report.version} at {report.path}")


if __name__ == "__main__":
    cli()
