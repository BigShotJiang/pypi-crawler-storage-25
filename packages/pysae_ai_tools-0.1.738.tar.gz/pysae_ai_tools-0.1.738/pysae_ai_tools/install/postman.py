"""Install Postman desktop application.

- Linux: download tarball from dl.pstmn.io, extract to /opt/Postman, symlink to /usr/local/bin.
- macOS: prefer Homebrew (cask), else download zip and extract to /Applications.
- Windows: report manual install steps (GUI installer cannot be silenced reliably).
"""

import json
import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated

import typer

from .common import platform
from .common.download import download, extract


def detect_status() -> dict[str, object]:
    """Cross-platform Postman detection."""
    if shutil.which("postman"):
        return {"installed": True, "path": shutil.which("postman")}
    candidates = [
        Path("/opt/Postman/Postman"),
        Path("/Applications/Postman.app"),
        Path(os.environ.get("LOCALAPPDATA", "")) / "Postman" / "Postman.exe",
    ]
    for c in candidates:
        if c.exists():
            return {"installed": True, "path": str(c)}
    return {"installed": False, "path": ""}


def _detect_version(path: str) -> str:
    """Read Postman version from its embedded package.json (no UI launch)."""
    if not path:
        return ""
    resolved = Path(path).resolve()
    base = resolved.parent if resolved.name in ("Postman", "Postman.exe") else resolved
    candidates = [
        base / "app" / "resources" / "app" / "package.json",  # Linux /opt/Postman/
        base / "resources" / "app" / "package.json",  # Linux /opt/Postman/app/
        base / "Contents" / "Resources" / "app" / "package.json",  # macOS .app
    ]
    for c in candidates:
        if c.exists():
            try:
                import json as _json

                data = _json.loads(c.read_text(encoding="utf-8"))
                return str(data.get("version", ""))
            except Exception:  # noqa: BLE001
                pass
    return ""


@dataclass
class State:
    installed: bool
    path: str
    version: str

    def to_dict(self) -> dict[str, object]:
        return {
            "installed": self.installed,
            "path": self.path,
            "version": self.version,
            "needs_install": not self.installed,
        }


def get_state() -> State:
    status = detect_status()
    path = str(status.get("path", ""))
    return State(
        installed=bool(status.get("installed")),
        path=path,
        version=_detect_version(path),
    )


@dataclass
class InstallReport:
    action: str
    method: str = ""
    path: str = ""
    error: str = ""
    manual: str = ""

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"action": self.action}
        for f in ("method", "path", "error", "manual"):
            v = getattr(self, f)
            if v:
                out[f] = v
        return out


def _install_linux(arch: str) -> InstallReport:
    arch_token = "linux_64" if arch == "x86_64" else "linux_arm64"
    url = f"https://dl.pstmn.io/download/latest/{arch_token}"
    with tempfile.TemporaryDirectory(prefix="pysae-postman-") as tmp_dir:
        tmp = Path(tmp_dir)
        archive = tmp / "postman.tar.gz"
        try:
            download(url, archive)
        except Exception as exc:  # noqa: BLE001
            return InstallReport(action="install", error=f"download failed: {exc}")

        # Extract to /opt/Postman via sudo
        try:
            subprocess.run(["sudo", "rm", "-rf", "/opt/Postman"], check=True, capture_output=True)
            subprocess.run(["sudo", "tar", "-xzf", str(archive), "-C", "/opt/"], check=True, capture_output=True)
            subprocess.run(
                ["sudo", "ln", "-sf", "/opt/Postman/Postman", "/usr/local/bin/postman"],
                check=True,
                capture_output=True,
            )
        except subprocess.CalledProcessError as exc:
            err = exc.stderr.decode() if exc.stderr else str(exc)
            return InstallReport(action="install", error=f"install failed: {err}")

    # Desktop entry
    apps_dir = Path.home() / ".local" / "share" / "applications"
    apps_dir.mkdir(parents=True, exist_ok=True)
    (apps_dir / "postman.desktop").write_text(
        "[Desktop Entry]\n"
        "Type=Application\n"
        "Name=Postman\n"
        "Icon=/opt/Postman/app/resources/app/assets/icon.png\n"
        "Exec=/opt/Postman/Postman\n"
        "Categories=Development;\n"
        "Terminal=false\n"
    )
    return InstallReport(action="install", method="tarball", path="/opt/Postman/Postman")


def _install_macos(arch: str) -> InstallReport:
    if shutil.which("brew"):
        r = subprocess.run(["brew", "install", "--cask", "postman"], capture_output=True, text=True, check=False)
        if r.returncode == 0:
            return InstallReport(action="install", method="brew", path="/Applications/Postman.app")
        # Brew may refuse to overwrite an existing install — fall through to manual zip
    arch_token = "osx_arm64" if arch == "arm64" else "osx_64"
    url = f"https://dl.pstmn.io/download/latest/{arch_token}"
    with tempfile.TemporaryDirectory(prefix="pysae-postman-") as tmp_dir:
        tmp = Path(tmp_dir)
        archive = tmp / "Postman.zip"
        try:
            download(url, archive)
            extract(archive, Path("/Applications"))
        except Exception as exc:  # noqa: BLE001
            return InstallReport(action="install", error=f"install failed: {exc}")
    return InstallReport(action="install", method="zip", path="/Applications/Postman.app")


def _install_windows() -> InstallReport:
    return InstallReport(
        action="install",
        manual=(
            "Postman on Windows requires the GUI installer. Download from "
            "https://www.postman.com/downloads/ or run `winget install Postman.Postman`."
        ),
    )


def do_install() -> InstallReport:
    try:
        plat = platform.detect()
    except ValueError as exc:
        return InstallReport(action="install", error=str(exc))
    if plat.is_linux:
        return _install_linux(plat.arch.value)
    if plat.is_macos:
        return _install_macos(plat.arch.value)
    if plat.is_windows:
        return _install_windows()
    return InstallReport(action="install", error=f"unsupported OS: {plat.os}")


cli = typer.Typer(no_args_is_help=True, help="Install the Postman desktop application")


@cli.command()
def check(json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False) -> None:
    state = get_state()
    if json_output:
        typer.echo(json.dumps(state.to_dict()))
    elif state.installed:
        version_str = f" {state.version}" if state.version else ""
        typer.echo(f"postman:{version_str} installed at {state.path}")
    else:
        typer.echo("postman: NOT installed")


@cli.command()
def install(json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False) -> None:
    report = do_install()
    if json_output:
        typer.echo(json.dumps(report.to_dict()))
    elif report.error:
        typer.echo(f"FAILED: {report.error}", err=True)
    elif report.manual:
        typer.echo(report.manual)
    else:
        typer.echo(f"installed postman via {report.method} at {report.path}")


if __name__ == "__main__":
    cli()
