"""Install or update kubectl from dl.k8s.io (raw binary, no archive)."""

import json
import subprocess
from dataclasses import dataclass
from typing import Annotated

import httpx
import typer

from .common import binary, platform
from .common.download import download_and_install_binary

BINARY_NAME = "kubectl"
STABLE_URL = "https://dl.k8s.io/release/stable.txt"


def latest_stable(timeout: float = 5.0) -> str:
    r = httpx.get(STABLE_URL, timeout=timeout, follow_redirects=True)
    r.raise_for_status()
    return r.text.strip()


def _arch_token(plat: platform.Platform) -> str:
    return "amd64" if plat.arch.value == "x86_64" else plat.arch.value


def binary_url(version: str, plat: platform.Platform) -> str:
    ver = version if version.startswith("v") else f"v{version}"
    arch = _arch_token(plat)
    suffix = ".exe" if plat.is_windows else ""
    return f"https://dl.k8s.io/release/{ver}/bin/{plat.os.value}/{arch}/kubectl{suffix}"


@dataclass
class State:
    binary: binary.BinaryStatus
    latest: str
    contexts: list[str]
    cluster_ok: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "binary": self.binary.to_dict(),
            "latest": self.latest,
            "contexts": self.contexts,
            "cluster_ok": self.cluster_ok,
            "needs_install": not self.binary.installed,
            "needs_update": self.binary.installed and binary.needs_update(self.binary.version, self.latest),
        }


def list_contexts() -> list[str]:
    if not binary.which(BINARY_NAME):
        return []
    r = subprocess.run(
        [BINARY_NAME, "config", "get-contexts", "-o", "name"],
        capture_output=True,
        text=True,
        check=False,
        timeout=5,
    )
    return [line.strip() for line in r.stdout.splitlines() if line.strip()]


def cluster_reachable() -> bool:
    if not binary.which(BINARY_NAME):
        return False
    r = subprocess.run(
        [BINARY_NAME, "cluster-info"],
        capture_output=True,
        text=True,
        check=False,
        timeout=5,
    )
    return r.returncode == 0


def get_state() -> State:
    bin_status = binary.status(BINARY_NAME, version_arg="version")
    try:
        latest = latest_stable().lstrip("v")
    except Exception:  # noqa: BLE001
        latest = ""
    return State(binary=bin_status, latest=latest, contexts=list_contexts(), cluster_ok=cluster_reachable())


@dataclass
class InstallReport:
    action: str
    version: str = ""
    path: str = ""
    error: str = ""

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"action": self.action}
        for f in ("version", "path", "error"):
            v = getattr(self, f)
            if v:
                out[f] = v
        return out


def do_install() -> InstallReport:
    try:
        plat = platform.detect()
    except ValueError as exc:
        return InstallReport(action="install", error=str(exc))
    try:
        version = latest_stable()
    except Exception as exc:  # noqa: BLE001
        return InstallReport(action="install", error=f"could not fetch stable version: {exc}")
    url = binary_url(version, plat)
    try:
        path = download_and_install_binary(url, BINARY_NAME)
    except Exception as exc:  # noqa: BLE001
        return InstallReport(action="install", error=f"download/install failed: {exc}")
    installed_v = binary.get_version(BINARY_NAME, version_arg="version")
    return InstallReport(action="install", version=installed_v or version.lstrip("v"), path=str(path))


cli = typer.Typer(no_args_is_help=True, help="Install/update kubectl and configure EKS contexts (dev/prod)")


@cli.command()
def check(json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False) -> None:
    state = get_state()
    if json_output:
        typer.echo(json.dumps(state.to_dict()))
    else:
        b = state.binary
        typer.echo(f"kubectl: {b.version or 'n/a'} (latest {state.latest or 'n/a'})")
        typer.echo(f"  contexts: {', '.join(state.contexts) or 'none'}")
        typer.echo(f"  cluster: {'reachable' if state.cluster_ok else 'unreachable'}")


@cli.command()
def install(json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False) -> None:
    report = do_install()
    if json_output:
        typer.echo(json.dumps(report.to_dict()))
    elif report.error:
        typer.echo(f"FAILED: {report.error}", err=True)
    else:
        typer.echo(f"installed kubectl {report.version} at {report.path}")


if __name__ == "__main__":
    cli()
