"""Reusable typer CLI scaffold for `install-*-mcp` skills.

Each MCP install skill is a thin wrapper that:
1. Defines a server name and a config dict (with placeholders for env vars).
2. Calls `make_cli(name, build_config)` to get a ready-to-use typer app.

The shared CLI provides `check` (report current config) and `install` (upsert).
"""

import json
from collections.abc import Callable
from dataclasses import dataclass
from typing import Annotated, Any

import typer

from . import mcp


@dataclass
class State:
    """get_state()-compatible wrapper around status_dict (works with install_all)."""

    payload: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return self.payload


def status_dict(name: str, env_keys: tuple[str, ...] = ()) -> dict[str, Any]:
    """Return a JSON-serializable status dict for a given MCP server."""
    server = mcp.get_server(name)
    if server is None:
        return {"name": name, "configured": False, "needs_install": True}
    env = server.get("env", {}) if isinstance(server.get("env", {}), dict) else {}
    env_status = {key: bool(env.get(key)) for key in env_keys}
    missing = [k for k, present in env_status.items() if not present]
    return {
        "name": name,
        "configured": True,
        "command": f"{server.get('command', '')} {' '.join(server.get('args', []))}".strip(),
        "env": env_status,
        "missing_env": missing,
        "needs_install": bool(missing),
    }


def state_for(name: str, env_keys: tuple[str, ...] = ()) -> State:
    """Return a State wrapper for a given MCP server (for install_all integration)."""
    return State(payload=status_dict(name, env_keys=env_keys))


def make_cli(
    server_name: str,
    build_config: Callable[[], dict[str, Any]],
    *,
    env_keys: tuple[str, ...] = (),
) -> typer.Typer:
    """Build a typer.Typer with `check` and `install` commands for an MCP server.

    Args:
        server_name: Key used in `mcpServers` in `~/.claude.json`.
        build_config: Callable producing the full config dict for this server.
            Called only by `install`. May raise to abort the install with an error.
        env_keys: Names of env vars the server requires; reported by `check`.
    """
    cli = typer.Typer(no_args_is_help=True, help=f"Install/check the {server_name} MCP server")

    @cli.command()
    def check(json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False) -> None:
        status = status_dict(server_name, env_keys=env_keys)
        if json_output:
            typer.echo(json.dumps(status))
        elif status.get("configured"):
            missing = status.get("missing_env") or []
            label = "OK" if not missing else f"missing env: {', '.join(missing)}"
            typer.echo(f"{server_name}: configured ({label})")
        else:
            typer.echo(f"{server_name}: NOT configured")

    @cli.command()
    def install(json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False) -> None:
        try:
            config = build_config()
        except Exception as exc:  # noqa: BLE001
            err_payload: dict[str, Any] = {"action": "install", "name": server_name, "error": str(exc)}
            if json_output:
                typer.echo(json.dumps(err_payload))
            else:
                typer.echo(f"FAILED: {exc}", err=True)
            raise typer.Exit(code=1) from exc

        changed = mcp.upsert_server(server_name, config)
        payload: dict[str, Any] = {
            "action": "install",
            "name": server_name,
            "changed": changed,
            "settings_path": str(mcp.settings_path()),
        }
        if json_output:
            typer.echo(json.dumps(payload))
        elif changed:
            typer.echo(f"{server_name}: updated in {mcp.settings_path()}")
        else:
            typer.echo(f"{server_name}: already up to date")

    return cli
