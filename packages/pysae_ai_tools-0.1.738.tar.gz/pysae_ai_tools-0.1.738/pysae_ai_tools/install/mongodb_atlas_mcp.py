"""Install the MongoDB Atlas MCP servers (dev + prod).

Atlas API keys are fetched from AWS Secrets Manager: pysae/mongodb-atlas/<env>.
Each secret contains a JSON object with `public_key` and `private_key`.
"""

import json
import os
import subprocess
from dataclasses import dataclass
from typing import Annotated, Any

import typer

from .common import binary, mcp

DEV_NAME = "mongodb-atlas-mcp-dev"
PROD_NAME = "mongodb-atlas-mcp-prod"


def fetch_keys(env: str) -> tuple[str, str]:
    """Fetch (public_key, private_key) from AWS Secrets Manager for the given env."""
    if not binary.which("aws"):
        raise RuntimeError("aws CLI not installed (run /install-aws-cli first)")
    secret_id = f"pysae/mongodb-atlas/{env}"
    r = subprocess.run(
        [
            "aws",
            "secretsmanager",
            "get-secret-value",
            "--secret-id",
            secret_id,
            "--query",
            "SecretString",
            "--output",
            "text",
        ],
        capture_output=True,
        text=True,
        check=False,
        timeout=15,
    )
    if r.returncode != 0:
        raise RuntimeError(f"failed to read {secret_id}: {r.stderr.strip() or r.stdout.strip()}")
    try:
        data = json.loads(r.stdout.strip())
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"{secret_id}: invalid JSON ({exc})") from exc
    pub = data.get("public_key", "")
    priv = data.get("private_key", "")
    if not pub or not priv:
        raise RuntimeError(f"{secret_id}: missing public_key/private_key fields")
    return pub, priv


def _build(public_key: str, private_key: str) -> dict[str, Any]:
    return {
        "command": "npx",
        "args": ["mcp-mongodb-atlas"],
        "env": {"ATLAS_PUBLIC_KEY": public_key, "ATLAS_PRIVATE_KEY": private_key},
    }


@dataclass
class Status:
    name: str
    configured: bool
    has_pub: bool
    has_priv: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "configured": self.configured,
            "has_public_key": self.has_pub,
            "has_private_key": self.has_priv,
        }


def status_for(name: str) -> Status:
    server = mcp.get_server(name)
    if server is None:
        return Status(name=name, configured=False, has_pub=False, has_priv=False)
    env = server.get("env", {}) if isinstance(server.get("env", {}), dict) else {}
    return Status(
        name=name,
        configured=True,
        has_pub=bool(env.get("ATLAS_PUBLIC_KEY")),
        has_priv=bool(env.get("ATLAS_PRIVATE_KEY")),
    )


@dataclass
class State:
    """install_all-compatible aggregate state for both servers."""

    dev: Status
    prod: Status

    def to_dict(self) -> dict[str, Any]:
        needs = not (
            self.dev.configured
            and self.dev.has_pub
            and self.dev.has_priv
            and self.prod.configured
            and self.prod.has_pub
            and self.prod.has_priv
        )
        return {DEV_NAME: self.dev.to_dict(), PROD_NAME: self.prod.to_dict(), "needs_install": needs}


def get_state() -> State:
    return State(dev=status_for(DEV_NAME), prod=status_for(PROD_NAME))


def do_install() -> dict[str, Any]:
    """install_all entry point — uses AWS Secrets Manager, falls back to env."""
    try:
        if os.environ.get("ATLAS_DEV_PUBLIC_KEY") and os.environ.get("ATLAS_PROD_PUBLIC_KEY"):
            dev_pub = os.environ["ATLAS_DEV_PUBLIC_KEY"]
            dev_priv = os.environ["ATLAS_DEV_PRIVATE_KEY"]
            prod_pub = os.environ["ATLAS_PROD_PUBLIC_KEY"]
            prod_priv = os.environ["ATLAS_PROD_PRIVATE_KEY"]
        else:
            dev_pub, dev_priv = fetch_keys("dev")
            prod_pub, prod_priv = fetch_keys("prod")
    except (KeyError, RuntimeError) as exc:
        msg = str(exc) if isinstance(exc, RuntimeError) else f"missing env var: {exc}"
        return {"action": "install", "error": msg}
    dev_changed = mcp.upsert_server(DEV_NAME, _build(dev_pub, dev_priv))
    prod_changed = mcp.upsert_server(PROD_NAME, _build(prod_pub, prod_priv))
    return {"action": "install", DEV_NAME: {"changed": dev_changed}, PROD_NAME: {"changed": prod_changed}}


cli = typer.Typer(no_args_is_help=True, help="Install/configure the MongoDB Atlas MCP servers")


@cli.command()
def check(json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False) -> None:
    dev = status_for(DEV_NAME)
    prod = status_for(PROD_NAME)
    payload = {
        DEV_NAME: dev.to_dict(),
        PROD_NAME: prod.to_dict(),
        "needs_install": not (
            dev.configured and dev.has_pub and dev.has_priv and prod.configured and prod.has_pub and prod.has_priv
        ),
    }
    if json_output:
        typer.echo(json.dumps(payload))
    else:
        for s in (dev, prod):
            label = "OK" if s.has_pub and s.has_priv else "missing keys"
            typer.echo(f"{s.name}: {'configured' if s.configured else 'missing'} ({label})")


@cli.command()
def install(
    skip_aws: Annotated[
        bool, typer.Option("--skip-aws", help="Use ATLAS_DEV_* / ATLAS_PROD_* env vars instead of AWS")
    ] = False,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    try:
        if skip_aws:
            dev_pub = os.environ["ATLAS_DEV_PUBLIC_KEY"]
            dev_priv = os.environ["ATLAS_DEV_PRIVATE_KEY"]
            prod_pub = os.environ["ATLAS_PROD_PUBLIC_KEY"]
            prod_priv = os.environ["ATLAS_PROD_PRIVATE_KEY"]
        else:
            dev_pub, dev_priv = fetch_keys("dev")
            prod_pub, prod_priv = fetch_keys("prod")
    except (KeyError, RuntimeError) as exc:
        msg = str(exc) if isinstance(exc, RuntimeError) else f"missing env var: {exc}"
        if json_output:
            typer.echo(json.dumps({"action": "install", "error": msg}))
        else:
            typer.echo(f"FAILED: {msg}", err=True)
        raise typer.Exit(code=1) from exc

    dev_changed = mcp.upsert_server(DEV_NAME, _build(dev_pub, dev_priv))
    prod_changed = mcp.upsert_server(PROD_NAME, _build(prod_pub, prod_priv))
    payload = {
        "action": "install",
        DEV_NAME: {"changed": dev_changed},
        PROD_NAME: {"changed": prod_changed},
        "settings_path": str(mcp.settings_path()),
    }
    if json_output:
        typer.echo(json.dumps(payload))
    else:
        typer.echo(f"{DEV_NAME}: {'updated' if dev_changed else 'unchanged'}")
        typer.echo(f"{PROD_NAME}: {'updated' if prod_changed else 'unchanged'}")


if __name__ == "__main__":
    cli()
