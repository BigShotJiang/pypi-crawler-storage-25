"""Message sending and document upload endpoints."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from langgraph.errors import GraphInterrupt

from orchid_ai.core.mcp import MCPTokenStore
from orchid_ai.core.state import AuthContext
from orchid_ai.persistence.base import ChatStorage
from orchid_ai.runtime import OrchidRuntime

from ..auth import get_auth_context
from ..context import get_chat_repo, get_graph, get_mcp_token_store_optional, get_runtime
from ..models import ChatResponse, InterruptResponse
from ..settings import Settings, get_settings
from ._helpers import (
    auto_title_if_first_message,
    build_interrupt_response,
    prepare_graph_state,
    verify_chat_ownership,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/chats", tags=["messages"])


@router.post("/{chat_id}/messages", response_model=ChatResponse | InterruptResponse)
async def send_chat_message(
    chat_id: str,
    message: str = Form(...),
    files: list[UploadFile] = File(default=[]),
    auth: AuthContext = Depends(get_auth_context),
    settings: Settings = Depends(get_settings),
    chat_repo: ChatStorage = Depends(get_chat_repo),
    runtime: OrchidRuntime = Depends(get_runtime),
    graph: Any = Depends(get_graph),
    mcp_token_store: MCPTokenStore | None = Depends(get_mcp_token_store_optional),
):
    """
    Send a message in a chat — optionally with attached files (non-streaming).

    Returns ``ChatResponse`` on normal completion, or ``InterruptResponse``
    when the graph pauses for human-in-the-loop tool approval.
    """
    prepared = await prepare_graph_state(
        chat_id,
        message,
        files,
        auth,
        settings,
        chat_repo=chat_repo,
        runtime=runtime,
        mcp_token_store=mcp_token_store,
    )

    # Run the agent graph (blocking — returns full response)
    graph_config = {"configurable": {"thread_id": chat_id}}
    try:
        result = await graph.ainvoke(prepared.initial_state, config=graph_config)
    except GraphInterrupt as exc:
        # HITL: graph paused for tool approval — don't persist messages yet
        return build_interrupt_response(exc, chat_id, auth.tenant_key)

    response_text = result.get("final_response", "No response generated.")
    agents_used = result.get("active_agents", [])

    # Persist the original user message (not augmented) + assistant response
    await chat_repo.add_message(chat_id, "user", prepared.message)
    await chat_repo.add_message(chat_id, "assistant", response_text, agents_used=agents_used)

    await auto_title_if_first_message(chat_id, prepared.message, prepared.history_rows, chat_repo)

    auth_required = [name for name, ok in prepared.mcp_auth_status.items() if not ok]
    return ChatResponse(
        response=response_text,
        chat_id=chat_id,
        tenant_id=auth.tenant_key,
        agents_used=agents_used,
        auth_required=auth_required,
    )


# ── Document Upload ──────────────────────────────────────────


@router.post("/{chat_id}/upload")
async def upload_documents(
    chat_id: str,
    files: list[UploadFile],
    auth: AuthContext = Depends(get_auth_context),
    settings: Settings = Depends(get_settings),
    chat_repo: ChatStorage = Depends(get_chat_repo),
    runtime: OrchidRuntime = Depends(get_runtime),
):
    """Upload documents for chat-scoped RAG."""
    from orchid_ai.core.repository import VectorWriter
    from orchid_ai.documents.chunker import ChunkConfig
    from orchid_ai.documents.pipeline import ingest_document
    from orchid_ai.rag.scopes import RAGScope

    reader = runtime.get_reader()

    if not isinstance(reader, VectorWriter):
        raise HTTPException(status_code=503, detail="Vector store does not support writing")

    await verify_chat_ownership(chat_id, auth, chat_repo)

    scope = RAGScope(
        tenant_id=auth.tenant_key,
        user_id=auth.user_id,
        chat_id=chat_id,
    )
    chunk_config = ChunkConfig(
        chunk_size=settings.chunk_size,
        chunk_overlap=settings.chunk_overlap,
    )

    results = []
    for file in files:
        if not file.filename:
            continue

        file_bytes = await file.read()
        max_bytes = settings.upload_max_size_mb * 1024 * 1024
        if len(file_bytes) > max_bytes:
            results.append(
                {"filename": file.filename, "error": f"File too large (max {settings.upload_max_size_mb}MB)"}
            )
            continue

        try:
            chunks = await ingest_document(
                file_bytes=file_bytes,
                filename=file.filename,
                scope=scope,
                namespace=settings.upload_namespace,
                writer=reader,
                chunk_config=chunk_config,
                vision_model=settings.vision_model or settings.litellm_model,
            )
            results.append({"filename": file.filename, "chunks_indexed": chunks})

            await chat_repo.add_message(
                chat_id,
                "system",
                f"Uploaded {file.filename} ({chunks} chunks indexed)",
            )
        except ValueError as exc:
            results.append({"filename": file.filename, "error": str(exc)})
        except Exception as exc:
            logger.error("[Upload] Failed to process %s: %s", file.filename, exc)
            results.append({"filename": file.filename, "error": "Processing failed"})

    return {"status": "ok", "files": results}
