import base64
import datetime
import os
from io import BytesIO
from typing import Any, Literal, overload
from xml.etree import ElementTree as ET

from PIL import Image

from pantoqa_bridge.lib.adb import ADB
from pantoqa_bridge.logger import logger
from pantoqa_bridge.utils.service_manager import get_adb_service


class BridgeDriverV2:

  def __init__(
    self,
    serial: str | None = None,
  ):
    self.adb = ADB(device_serial=serial)
    self._connected = False
    self.window_size: dict[str, int] | None = None

  def __enter__(self):
    return self

  def __exit__(self, exc_type, exc, tb):
    return False

  @overload
  async def _run_adb(
    self,
    *args: str,
    check: bool = True,
    decode: Literal[True] = True,
  ) -> str:
    ...

  @overload
  async def _run_adb(
    self,
    *args: str,
    check: bool = True,
    decode: Literal[False],
  ) -> bytes:
    ...

  async def _run_adb(
    self,
    *args: str,
    check: bool = True,
    decode: bool = True,
  ) -> str | bytes:
    cmd = list(args)
    process = await self.adb.exec_p(cmd)
    stdout, stderr = await process.communicate()

    if check and process.returncode != 0:
      stderr_text = stderr.decode(errors="replace").strip()
      raise RuntimeError(
        f"ADB command failed ({process.returncode}): {' '.join(cmd)}\n{stderr_text}")

    if decode:
      return stdout.decode(errors="replace")
    return stdout

  async def connect(self) -> None:
    if self._connected:
      return

    await self._run_adb("start-server")
    self.window_size = await self._get_window_size()
    self._connected = True

  async def ensure_connected(self) -> None:
    if not self._connected:
      await self.connect()

  async def _get_window_size(self) -> dict[str, int]:
    output = await self._run_adb("shell", "wm", "size")
    for line in output.splitlines():
      if ":" not in line:
        continue
      size_text = line.split(":", 1)[1].strip()
      if "x" not in size_text:
        continue
      width_text, height_text = size_text.split("x", 1)
      return {
        "width": int(width_text.strip()),
        "height": int(height_text.strip()),
      }
    raise RuntimeError(f"Unable to determine device window size from: {output!r}")

  async def _shell(self, command: str) -> str:
    await self.ensure_connected()
    return await self._run_adb("shell", command)

  async def _get_current_activity(self) -> str | None:
    dumpsys_output = await self._run_adb("shell", "dumpsys", "window")
    for line in dumpsys_output.splitlines():
      if "mCurrentFocus" not in line and "mFocusedApp" not in line:
        continue
      marker = " u0 "
      if marker not in line:
        continue
      activity = line.split(marker, 1)[1].strip().split()[0]
      return activity.rstrip("}")
    return None

  async def _get_current_package(self) -> str | None:
    activity = await self._get_current_activity()
    if not activity or "/" not in activity:
      return None
    return activity.split("/", 1)[0]

  async def _is_keyboard_shown(self) -> bool:
    dumpsys_output = await self._run_adb("shell", "dumpsys", "input_method")
    return "mInputShown=true" in dumpsys_output or "isInputViewShown=true" in dumpsys_output

  async def tap(self, x: int, y: int) -> None:
    await self.ensure_connected()
    await self._run_adb("shell", "input", "tap", str(x), str(y))

  async def swipe(
    self,
    x1: int,
    y1: int,
    x2: int,
    y2: int,
    duration_ms: float | None = None,
  ) -> None:
    await self.ensure_connected()
    duration_ms = duration_ms or 1000
    await self._run_adb(
      "shell",
      "input",
      "swipe",
      str(x1),
      str(y1),
      str(x2),
      str(y2),
      str(int(duration_ms)),
    )

  async def input_text(self, text: str, clear: bool = False) -> bool:
    await self.ensure_connected()
    if clear:
      await self._run_adb("shell", "input", "keycombination", "113", "29")
      await self._run_adb("shell", "input", "keyevent", "67")

    await self._run_adb("shell", "input", "text", _adb_encode(text))
    return True

  async def press_key(self, keycode: int) -> None:
    await self.ensure_connected()
    await self._run_adb("shell", "input", "keyevent", str(keycode))

  async def drag_and_drop(
    self,
    x1: int,
    y1: int,
    x2: int,
    y2: int,
    duration_ms: float = 300.0,
  ) -> None:
    # await self.swipe(x1, y1, x2, y2, duration_ms=duration * 1000)
    await self._run_adb("shell", "input", "draganddrop", str(x1), str(y1), str(x2), str(y2),
                        f"{duration_ms}")

  async def start_app(self, package: str, activity: str | None = None) -> str:
    try:
      await self.ensure_connected()
      logger.info(f"Starting app {package} with activity {activity}")

      if not activity:
        resolve_output = await self._run_adb(
          "shell",
          "cmd",
          "package",
          "resolve-activity",
          "--brief",
          package,
        )
        for line in resolve_output.splitlines():
          if line.startswith(f"{package}/"):
            activity = line.split("/", 1)[1]
            break

      if not activity:
        raise RuntimeError(f"Unable to resolve launchable activity for {package}")

      await self._run_adb("shell", "am", "start", "-n", f"{package}/{activity}")
      logger.info(f"App started: {package} with activity {activity}")
      return f"App started: {package} with activity {activity}"
    except Exception as exc:
      return f"Failed to start app {package}: {exc}"

  async def install_app(self, path: str, **kwargs: Any) -> str:
    await self.ensure_connected()
    if not os.path.exists(path):
      return f"Failed to install app: APK file not found at {path}"

    reinstall = kwargs.get("reinstall", False)
    grant_permissions = kwargs.get("grant_permissions", True)

    cmd = ["install"]
    if reinstall:
      cmd.append("-r")
    if grant_permissions:
      cmd.append("-g")
    cmd.append(path)

    logger.info(f"Installing app: {path} with reinstall: {reinstall} "
                f"and grant_permissions: {grant_permissions}")
    result = await self._run_adb(*cmd)
    logger.info(f"Installed app: {path} with result: {result}")
    return result

  async def get_apps(self, include_system: bool = True) -> list[dict[str, str]]:
    cmd = "pm list packages" if include_system else "pm list packages -3"
    result = await self._shell(cmd)
    packages = [
      line.replace("package:", "") for line in result.splitlines() if line.startswith("package:")
    ]
    return [{"package": package, "label": package} for package in packages]

  async def list_packages(self, include_system: bool = False) -> list[str]:
    cmd = "pm list packages" if include_system else "pm list packages -3"
    result = await self._shell(cmd)
    return [
      line.replace("package:", "") for line in result.splitlines() if line.startswith("package:")
    ]

  async def screenshot(self, hide_overlay: bool = True) -> str:
    await self.ensure_connected()
    output = await self._run_adb("exec-out", "screencap", "-p", decode=False)

    image = Image.open(BytesIO(output))

    buf = BytesIO()
    image.save(buf, format="PNG")

    return base64.b64encode(buf.getvalue()).decode("utf-8")

  async def scaled_screenshot(self, scale_factor: int) -> str:
    await self.ensure_connected()
    output = await self._run_adb("exec-out", "screencap", "-p", decode=False)

    image = Image.open(BytesIO(output))
    img_downscale = _downscale_image(img=image, scale_factor=scale_factor)

    buf = BytesIO()
    img_downscale.save(buf, format="PNG")

    return base64.b64encode(buf.getvalue()).decode("utf-8")

  async def _get_ui_dump(self) -> ET.Element:
    await self.ensure_connected()
    xml_dump_output = await self._run_adb("exec-out", "uiautomator", "dump", "/dev/tty")
    xml_dump = xml_dump_output.replace("UI hierchary dumped to: /dev/tty", "", 1).strip().encode()
    try:
      if "android.webkit.WebView" in xml_dump.decode():
        raise ValueError("WebView detected in UI dump, likely incomplete dump from adb exec-out")
      root = ET.fromstring(xml_dump)
      logger.info("Successfully got UI dump using adb exec-out")
    except Exception as ex:
      if isinstance(ex, ValueError):
        logger.warning(f"{ex}, falling back to uiautomator2 for UI dump")
      else:
        logger.warning("Failed to parse UI dump from adb exec-out, falling back to uiautomator2")
      srv = get_adb_service(self.adb.device_serial).srv
      xml = srv.get_ui_dump_from_uiautomator()
      root = ET.fromstring(xml.encode())
      logger.info("Successfully got UI dump using uiautomator2 fallback")

    return root

  async def get_ui_tree(self) -> dict[str, Any]:
    await self.ensure_connected()
    root = await self._get_ui_dump()
    a11y_tree = get_full_tree(root)
    focused_element = get_focused_input_element_from_xml(root)
    current_activity = await self._get_current_activity()
    current_package = await self._get_current_package()
    is_keyboard_shown = await self._is_keyboard_shown()
    if self.window_size is None:
      self.window_size = await self._get_window_size()

    phone_state = {
      "currentApp": current_activity,
      "packageName": current_package,
      "activityName": current_activity,
      "keyboardVisible": is_keyboard_shown,
      "isEditable": is_keyboard_shown,
      "focusedElement": {
        "text": focused_element.get("text") if focused_element else None,
        "className": focused_element.get("className") if focused_element else None,
        "resourceId": focused_element.get("resourceId") if focused_element else None,
      },
    }
    device_context = {
      "screen_bounds": {
        "width": self.window_size["width"],
        "height": self.window_size["height"],
      },
      "filtering_params": {
        "min_element_size": 5,
        "overlay_offset": 0,
      },
    }
    return {
      "a11y_tree": a11y_tree,
      "phone_state": phone_state,
      "device_context": device_context,
    }

  async def clear_app_cache(self, pkg: str) -> None:
    await self.ensure_connected()
    await self._run_adb("shell", "pm", "clear", pkg)

  async def get_date(self) -> str:
    try:
      return (await self._run_adb("shell", "date", "+%Y-%m-%dT%H:%M:%S%z")).strip()
    except Exception:
      return datetime.datetime.now(datetime.UTC).isoformat()

  async def get_device_resolution(self) -> dict[str, int]:
    if self.window_size:
      return self.window_size
    self.window_size = await self._get_window_size()
    return self.window_size


def _adb_encode(text: str) -> str:
  escape_map = {
    "%": r"\%",
    " ": "%s",
    "'": r"\'",
    '"': r'\"',
    "&": r"\&",
    "(": r"\(",
    ")": r"\)",
    ";": r"\;",
    "<": r"\<",
    ">": r"\>",
    "\\": r"\\",
    '#': r'\#',
    '|': r'\|',
    '`': r'\`',
    '*': r'\*',
    '?': r'\?'
  }
  return "".join(escape_map.get(ch, ch) for ch in text)


def get_full_tree(root: ET.Element) -> dict[str, Any] | None:
  if root.tag != "hierarchy":
    raise ValueError("Expected root tag to be 'hierarchy'")
  children = list(root)
  tree = build_a11y_tree_from_xml(children[0] if len(children) == 1 else root)
  return tree


def get_focused_input_element_from_xml(root: ET.Element) -> dict[str, Any] | None:
  focused_nodes = [node for node in root.iter() if node.attrib.get("focused") == "true"]

  if not focused_nodes:
    return None

  priority_classes = [
    "android.widget.EditText",
    "android.widget.AutoCompleteTextView",
    "android.widget.MultiAutoCompleteTextView",
    "android.widget.TextView",
  ]

  def is_preferred(node: ET.Element) -> bool:
    class_name = node.attrib.get("class", "")
    return any(cls in class_name for cls in priority_classes)

  preferred = [node for node in focused_nodes if is_preferred(node)]
  node = preferred[0] if preferred else focused_nodes[0]

  return {
    "text": node.attrib.get("text"),
    "className": node.attrib.get("class"),
    "resourceId": node.attrib.get("resource-id"),
  }


def build_a11y_tree_from_xml(node: ET.Element) -> dict[str, Any] | None:
  children = []

  def parse_bounds(bounds_str: str | None) -> dict[str, int] | None:
    if not bounds_str:
      return None

    bounds_str = bounds_str.replace("[", "").replace("]", ",")
    parts = bounds_str.split(",")

    if len(parts) < 4:
      return None

    left, top, right, bottom = map(int, parts[:4])
    return {
      "left": left,
      "top": top,
      "right": right,
      "bottom": bottom,
    }

  def parse_bool(xml_node: ET.Element, key: str) -> bool:
    return xml_node.attrib.get(key, "false") == "true"

  def parse_int(xml_node: ET.Element, key: str) -> int:
    try:
      return int(xml_node.attrib.get(key, "0"))
    except ValueError:
      return 0

  def parse_actions(actions_str: str | None) -> list[dict[str, Any]]:
    if not actions_str:
      return []

    action_map = {
      "ACTION_CLICK": 16,
      "ACTION_LONG_CLICK": 32,
      "ACTION_SCROLL_FORWARD": 4096,
      "ACTION_SCROLL_BACKWARD": 8192,
      "ACTION_FOCUS": 1,
      "ACTION_CLEAR_FOCUS": 2,
      "ACTION_SELECT": 4,
      "ACTION_CLEAR_SELECTION": 8,
      "ACTION_SET_TEXT": 2097152,
      "ACTION_COPY": 16384,
      "ACTION_PASTE": 32768,
      "ACTION_CUT": 65536,
    }

    actions = []
    for name in actions_str.split(","):
      name = name.strip()
      if not name:
        continue
      actions.append({
        "id": action_map.get(name),
        "label": "",
        "name": name,
      })
    return actions

  def parse_extras(extras_str: str | None) -> dict[str, str] | None:
    if not extras_str:
      return None

    extras: dict[str, str] = {}
    for item in extras_str.split(";"):
      if "=" not in item:
        continue
      key, value = item.split("=", 1)
      extras[key.strip()] = value.strip()
    return extras if extras else None

  for child in list(node):
    child_json = build_a11y_tree_from_xml(child)
    if child_json:
      children.append(child_json)

  bounds = parse_bounds(node.attrib.get("bounds"))
  actions = parse_actions(node.attrib.get("actions"))
  extras = parse_extras(node.attrib.get("extras"))
  class_name = node.attrib.get("class", "")
  input_type = parse_int(node, "input-type")

  return {
    "resourceId": node.attrib.get("resource-id", ""),
    "className": class_name,
    "packageName": node.attrib.get("package", ""),
    "text": node.attrib.get("text", ""),
    "contentDescription": node.attrib.get("content-desc", ""),
    "hint": node.attrib.get("hint", ""),
    "stateDescription": None,
    "tooltipText": node.attrib.get("tooltip-text", ""),
    "paneTitle": node.attrib.get("pane-title", ""),
    "error": node.attrib.get("error", ""),
    "boundsInScreen": bounds or {},
    "boundsInParent": None,
    "isClickable": parse_bool(node, "clickable"),
    "isLongClickable": parse_bool(node, "long-clickable"),
    "isContextClickable": parse_bool(node, "context-clickable"),
    "isFocusable": parse_bool(node, "focusable"),
    "isFocused": parse_bool(node, "focused"),
    "isAccessibilityFocused": parse_bool(node, "a11y-focused"),
    "isSelected": parse_bool(node, "selected"),
    "isCheckable": parse_bool(node, "checkable"),
    "isChecked": parse_bool(node, "checked"),
    "isEnabled": parse_bool(node, "enabled"),
    "isVisibleToUser": parse_bool(node, "displayed"),
    "isEditable": class_name.endswith("EditText") or input_type != 0,
    "isPassword": parse_bool(node, "password"),
    "isShowingHintText": parse_bool(node, "showing-hint"),
    "isScrollable": parse_bool(node, "scrollable"),
    "isDismissable": parse_bool(node, "dismissable"),
    "isMultiLine": parse_bool(node, "multiline"),
    "isImportantForAccessibility": parse_bool(node, "a11y-important"),
    "isScreenReaderFocusable": parse_bool(node, "screen-reader-focusable"),
    "isHeading": parse_bool(node, "heading"),
    "isTextSelectable": None,
    "textSelectionStart": parse_int(node, "selection-start"),
    "textSelectionEnd": parse_int(node, "selection-end"),
    "inputType": input_type,
    "liveRegion": parse_int(node, "live-region"),
    "windowId": parse_int(node, "window-id"),
    "drawingOrder": parse_int(node, "drawing-order"),
    "maxTextLength": parse_int(node, "max-text-length"),
    "movementGranularities": None,
    "childCount": len(children),
    "actionCount": len(actions),
    "actionList": actions,
    "rangeInfo": None,
    "collectionInfo": None,
    "collectionItemInfo": None,
    "touchDelegateInfo": None,
    "extras": extras,
    "hasLabelFor": False,
    "hasLabeledBy": False,
    "hasTraversalBefore": False,
    "hasTraversalAfter": False,
    "uniqueId": None,
    "containerTitle": None,
    "children": children,
  }


def _downscale_image(
  img: Image.Image,
  scale_factor: float,
) -> Image.Image:
  original_width, original_height = img.size

  if scale_factor <= 0:
    raise ValueError("scale_factor must be > 0")

  new_width = max(1, int(original_width / scale_factor))
  new_height = max(1, int(original_height / scale_factor))

  return img.resize((new_width, new_height), resample=Image.Resampling.LANCZOS)
