import os
from typing import Any

from fastapi import APIRouter, File, UploadFile
from pydantic import BaseModel

from pantoqa_bridge.logger import logger
from pantoqa_bridge.models.misc import Action
from pantoqa_bridge.service.driver_driver_v2 import BridgeDriverV2
from pantoqa_bridge.utils.service_manager import get_adb_service

router = APIRouter()


class ActionRequestModel(BaseModel):
  id: str
  action: Action
  device_serial_no: str | None = None


class ActionResponseModel(BaseModel):
  id: str
  type: str
  data: Any | None = None
  error: str | None = None


@router.post('/perform-action', response_model=ActionResponseModel)
async def perform_action(request: ActionRequestModel):
  try:
    srv = get_adb_service(request.device_serial_no)
    result = srv.process(request.action)

    return ActionResponseModel(
      id=request.id,
      type="driver_action_response",
      data=result,
    )
  except Exception as exc:
    logger.exception(f"Error while executing bridge_action [{request.id}]: {exc}")
    return ActionResponseModel(
      id=request.id,
      type="driver_action_response",
      data=None,
      error=str(exc),
    )


@router.post('/v2/perform-action', response_model=ActionResponseModel)
async def perform_action_v2(request: ActionRequestModel):
  try:
    with BridgeDriverV2(serial=request.device_serial_no) as driver:
      result = await _start_action_v2(driver, request)
      return ActionResponseModel(
        id=request.id,
        type="driver_action_response",
        data=result,
      )
  except Exception as exc:
    logger.exception(f"Error while executing bridge_action [{request.id}]: {exc}")
    return ActionResponseModel(
      id=request.id,
      type="driver_action_response",
      data=None,
      error=str(exc),
    )


@router.post('/install-apk')
async def install_apk(device_serial_no: str, apk_file: UploadFile = File(...)):
  os.makedirs("/tmp", exist_ok=True)
  apk_path = f"/tmp/{apk_file.filename}"
  with open(apk_path, "wb") as f:
    f.write(await apk_file.read())
  srv = get_adb_service(device_serial_no)
  srv.srv.install_app(apk_path)
  os.remove(apk_path)
  return {"message": "APK installed successfully on device."}


async def _start_action_v2(driver: BridgeDriverV2, request: ActionRequestModel):
  action = request.action.action_type
  params = request.action.params or {}

  if action == "tap":
    assert 'x' in params and 'y' in params, "Tap action requires 'x' and 'y' parameters"
    await driver.tap(params['x'], params['y'])
    return None
  elif action == "swipe":
    assert all(k in params
               for k in ['x1', 'y1', 'x2', 'y2'
                         ]), "Swipe action requires 'x1', 'y1', 'x2', and 'y2' parameters"
    await driver.swipe(
      params["x1"],
      params["y1"],
      params["x2"],
      params["y2"],
      duration_ms=params.get("duration_ms") or params.get('duration'),
    )
    return None
  elif action == "input_text":
    assert 'text' in params, "Input text action requires 'text' parameter"
    return await driver.input_text(text=params["text"], clear=params.get("clear", False))
  elif action == "press_key":
    assert 'keycode' in params, "Press key action requires 'keycode' parameter"
    await driver.press_key(params["keycode"])
    return None
  elif action == "drag" or action == "drag_and_drop":
    assert all(k in params
               for k in ['x1', 'y1', 'x2', 'y2'
                         ]), "Drag action requires 'x1', 'y1', 'x2', and 'y2' parameters"
    await driver.drag_and_drop(params["x1"], params["y1"], params["x2"], params["y2"],
                               params.get("duration_ms") or params.get("duration", 300.0))
    return None
  elif action == "start_app":
    assert 'package' in params, "Start app action requires 'package' parameter"
    return await driver.start_app(package=params["package"], activity=params.get("activity"))
  elif action == "install_app":
    assert 'path' in params, "Install app action requires 'path' parameter"
    return await driver.install_app(path=params["path"])
  elif action == "get_apps":
    return await driver.get_apps(include_system=params.get("include_system", True))
  elif action == "list_packages":
    return await driver.list_packages(params.get("include_system", False))
  elif action == "screenshot":
    return await driver.screenshot(params.get("hide_overlay", True))
  elif action == "get_ui_tree":
    return await driver.get_ui_tree()
  elif action == "clear_app_cache":
    assert 'pkg' in params, "Clear app cache action requires 'pkg' parameter"
    await driver.clear_app_cache(params["pkg"])
    return None
  elif action == "get_date":
    return await driver.get_date()
  elif action == "get_device_resolution":
    return await driver.get_device_resolution()
  elif action == "scaled_screenshot":
    assert 'scale_factor' in params, "Scaled screenshot action requires 'scale_factor' parameter"
    return await driver.scaled_screenshot(params["scale_factor"])
  else:
    raise ValueError(f"Unsupported action type: {action}")
