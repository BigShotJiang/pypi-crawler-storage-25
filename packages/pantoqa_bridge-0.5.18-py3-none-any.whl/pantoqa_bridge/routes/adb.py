from adbutils import adb  # type:ignore
from fastapi import APIRouter
from pydantic import BaseModel


class ADBDeviceList(BaseModel):
  serial_no: str
  name: str | None = None


router = APIRouter()


@router.post("/get-devices", response_model=list[ADBDeviceList])
async def get_available_devices():
  return await _get_available_devices()


async def _get_available_devices():
  devices = adb.device_list()
  result: list[ADBDeviceList] = []
  for d in devices:
    try:
      name = d.prop.model
    except Exception:
      name = None
    result.append(ADBDeviceList(serial_no=d.serial, name=name))
  return result
