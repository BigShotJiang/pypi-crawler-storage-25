import asyncio
import json
import os
import sys
import tempfile
from collections.abc import AsyncIterator, Awaitable, Callable
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from pantoqa_bridge.config import PKG_NAME
from pantoqa_bridge.logger import logger
from pantoqa_bridge.models.code_execute import CodeFile
from pantoqa_bridge.service.prompt_executor import PromptExecutor
from pantoqa_bridge.utils.process import (create_stream_pipe, kill_process_gracefully,
                                          stream_process)
from pantoqa_bridge.utils.service_manager import remove_all_services

route = APIRouter()


class ExecutionRequest(BaseModel):
  files: list[CodeFile]
  framework: Literal['APPIUM', 'MAESTRO', 'TXT']
  driver_type: Literal['BRIDGE', 'BRIDGE_V2'] = "BRIDGE"
  device_serial: str | None = None
  context_id: str | None = None
  env_id: str | None = None
  env_vars: dict[str, str] | None = None
  system_env_vars: dict[str, str] | None = None


class ExecutionResult(BaseModel):
  status: str
  exit_code: int | None = None
  message: str | None = None


@route.post("/execute")
async def execute(rawrequest: Request) -> StreamingResponse:
  request_json = await rawrequest.json()
  request = ExecutionRequest.model_validate(request_json)
  if not request.files:
    raise HTTPException(status_code=400, detail="At least one file is required")

  stream, push_to_stream, done = create_stream_pipe()

  async def emit(event: str, data: str) -> None:
    logger.info(f"[SSE]:{event}, data: {data}")
    await push_to_stream(_format_sse(event, data))

  async def task():
    try:
      await _execute_qacode(request, emit, dict(rawrequest.headers))
    finally:
      done.set()

  bg_task = asyncio.create_task(task())

  async def cancellable_stream(source: AsyncIterator[str]) -> AsyncIterator[str]:
    try:
      async for chunk in source:
        yield chunk
    finally:
      if not bg_task.done():
        bg_task.cancel()

  return StreamingResponse(cancellable_stream(stream), media_type="text/event-stream")


@route.delete("/stop-test/{process_id}")
async def stop_test(process_id: str):
  # TXT prompt tasks are named "txt_task_{id}" — find and cancel by name.
  if process_id.startswith("txt_task_"):
    for task in asyncio.all_tasks():
      if task.get_name() == process_id:
        task.cancel()
        return
  # Otherwise fall back to killing a subprocess by PID.
  kill_process_gracefully(int(process_id))


def _format_sse(event: str, data: str) -> str:
  json_dict = {
    "event": event,
    "data": data,
  }
  json_str = json.dumps(json_dict)
  return f"data: {json_str}\n\n"


async def _execute_txt(
  request: ExecutionRequest,
  on_data: Callable[[str, str], Awaitable[None]],
  headers: dict[str, str],
) -> int:
  system_env = request.system_env_vars or {}

  txt_contents = [
    f.content.strip() for f in request.files if Path(f.path).suffix.lower() == ".txt"
  ]
  prompt = "\n\n".join([p for p in txt_contents if p])
  if not prompt:
    raise RuntimeError("No non-empty .txt prompt file found for TXT framework.")

  prompt_executor = PromptExecutor(
    system_env_vars=system_env,
    headers=headers,
    device_serial=request.device_serial,
    context_id=request.context_id,
    env_id=request.env_id,
    on_data=on_data,
    driver_type=request.driver_type,
    blind_mode=True,
  )

  current_task = asyncio.current_task()
  assert current_task is not None, "No current asyncio task found."
  task_name = f"txt_task_{id(current_task)}"
  current_task.set_name(task_name)
  await on_data("pid", task_name)
  return await prompt_executor.execute(prompt)


async def _execute_qacode(
  request: ExecutionRequest,
  on_data: Callable[[str, str], Awaitable[None]],
  headers: dict[str, str],
):
  logger.info(f"Executing QA code with framework: {request.framework}")
  remove_all_services()  # kill all the LocalBridge instance and automator connection.

  if request.framework.upper() == "TXT":
    try:
      exit_code = await _execute_txt(request, on_data, headers)
      await on_data("stop", f"Execution completed with exit code: {exit_code}")
    except Exception as e:
      await on_data("exception", f"Execution failed: {str(e)}")
      await on_data("error", f"Execution failed: {str(e)}")
      logger.exception(f"Execution failed: {str(e)}")
      exit_code = -1

    await on_data("status", f"Execution completed with exit code: {exit_code}")
    logger.info(f"Execution completed with exit code: {exit_code}")
    return exit_code

  # Handle APPIUM and MAESTRO frameworks via local CLI
  copiedfiles: list[str] = []
  index = 0
  with tempfile.TemporaryDirectory(prefix="pantoqa-qa-run-") as tmpdir:
    workdir = Path(tmpdir)
    for code_file in request.files:
      if Path(code_file.path).name == 'org_utils.py':
        target = workdir / "org_utils.py"
        target.write_text(code_file.content, encoding="utf-8")
        continue

      ext = Path(code_file.path).suffix
      filepathwithoutExt = Path(code_file.path).with_suffix('')
      target = workdir / (f"{filepathwithoutExt}_{index}{ext}")
      target.parent.mkdir(parents=True, exist_ok=True)
      target.write_text(code_file.content, encoding="utf-8")
      copiedfiles.append(str(target))
      index += 1
      print(f"Written file to {target}")

    await on_data("status", "Starting testing...")

    process: asyncio.subprocess.Process | None = None
    try:
      cmd = [
        sys.executable,
        "-u",  # unbuffered output
        "-m",
        PKG_NAME,
        "--skip-autoupgrade",
        "execute",
        "--framework",
        request.framework.lower(),
      ]
      if request.device_serial:
        cmd.extend(["--device", request.device_serial])
      if request.env_vars:
        env_vars_file = workdir / "env_vars.json"
        env_vars_file.write_text(json.dumps(request.env_vars), encoding="utf-8")
        cmd.extend(["--env-vars", str(env_vars_file)])
      cmd.extend(copiedfiles)
      env = {
        **(request.system_env_vars or {}),
        **os.environ,
        "PYTHONUNBUFFERED": "1",
      }
      process = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=workdir,
        start_new_session=True,
        env=env,
      )
      logger.info(f"Started execution process with PID: {process.pid}")
      await on_data("pid", str(process.pid))
      await stream_process(process, on_data)
      exit_code = process.returncode or -1
    except asyncio.CancelledError:
      if process and process.returncode is None:
        process.kill()
      await on_data("stop", "Execution cancelled.")
      await on_data("status", "Execution cancelled.")
      raise
    except Exception as e:
      if process and process.returncode is None:
        process.kill()
      exit_code = (process.returncode or -1) if process else -1
      await on_data("exception", f"Execution failed: {str(e)}")
      await on_data("error", f"Execution failed: {str(e)}")
      logger.exception(f"Execution failed: {str(e)}")

    await on_data("stop", f"Execution completed with exit code: {exit_code}")
    await on_data("status", f"Execution completed with exit code: {exit_code}")
    logger.info(f"Execution completed with exit code: {exit_code}")
    return exit_code
