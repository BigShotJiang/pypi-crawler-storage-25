import asyncio
import json
import uuid

import aiohttp
import websockets

from pantoqa_bridge.config import PUBLIC_PROXY_BASE_URL, SERVER_BASE_URL
from pantoqa_bridge.logger import logger
from pantoqa_bridge.routes.screen_mirror import ScreenMirrorOverWS


class ProxyWSConnection:

  def __init__(self):
    self.unique_id = str(uuid.uuid4())

  async def handle(self, ws: websockets.ClientConnection):
    async for msg in ws:
      data = json.loads(msg)
      data_type = data.get("type")
      if data_type == "ping":
        await ws.send(json.dumps({"type": "pong"}))
        continue

      if data_type == "request":
        req_id = data["request_id"]
        payload = data["payload"]

        if payload.get("op") == "http_forward":
          await self.handle_http_forward(ws, req_id, payload)
          continue

        if payload.get("op") == "proxy_screen":
          await self.handle_proxy_screen(ws, req_id, payload)
          continue

        await ws.send(
          json.dumps({
            "type": "response",
            "request_id": req_id,
            "payload": {
              "error": "Unknown operation"
            }
          }))
        continue

      await ws.send(json.dumps({"type": "error", "payload": {"error": "Unknown message type"}}))

  async def handle_proxy_screen(self, ws: websockets.ClientConnection, req_id: str, payload: dict):
    mirror_task = self._proxy_screen_mirror(
      payload['session_id'],
      payload.get("max_size"),
      payload.get('device_serial'),
    )
    asyncio.create_task(mirror_task)
    resp = {"status": 200, "body": "streaming started"}
    await ws.send(json.dumps({"type": "response", "request_id": req_id, "payload": resp}))

  async def handle_http_forward(self, ws: websockets.ClientConnection, req_id: str, payload: dict):
    url = f"{SERVER_BASE_URL}{payload.get('path')}"
    method = payload.get("method", "GET")
    headers = payload.get("headers", {})
    body = payload.get("body")

    try:
      async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as session:
        async with session.request(
            method=method,
            url=url,
            headers=headers,
            data=body,
        ) as r:
          try:
            response_body = await r.json()
          except Exception:
            response_body = await r.text()
          resp = {"status": r.status, "body": response_body}
    except Exception as e:
      resp = {"error": str(e)}
    await ws.send(json.dumps({"type": "response", "request_id": req_id, "payload": resp}))

  async def start_tunnel(self):
    logger.info(f"Tunneling to:{PUBLIC_PROXY_BASE_URL}/{self.unique_id}")
    while True:
      try:
        ws_base_url = PUBLIC_PROXY_BASE_URL.replace("http", "ws")
        tunnel_url = f"{ws_base_url}/ws?ws_uuid={self.unique_id}"
        async with websockets.connect(tunnel_url, ping_interval=20, ping_timeout=120) as ws:
          await self.handle(ws)
      except Exception as e:
        logger.info(f"Websocket error : {e}")
        await asyncio.sleep(3)

  async def _proxy_screen_mirror(self, session_id: str, max_size: int | None,
                                 device_serial: str | None):
    ws_base_url = PUBLIC_PROXY_BASE_URL.replace("http", "ws")
    mirror_url = f"{ws_base_url}/ws/connect-mirror-upstream"
    url = f"{mirror_url}/{session_id}"
    async with websockets.connect(url, ping_interval=20) as ws_conn:
      ws_adapter = WSAdapter(ws_conn)
      streaming = ScreenMirrorOverWS(ws_adapter, max_size, device_serial)  # type: ignore
      await streaming.stream()

  async def teardown(self):
    pass


class WSAdapter:

  def __init__(self, ws_conn: websockets.ClientConnection):
    self.ws_conn = ws_conn

  async def send_bytes(self, data: bytes):
    await self.ws_conn.send(data)

  async def receive_bytes(self):
    return await self.ws_conn.recv()

  async def close(self):
    await self.ws_conn.close()
