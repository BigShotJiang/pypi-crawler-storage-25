# 06 — Generate

**Роль ИИ:** сгенерировать код по `development-plan.xml`, фаза за фазой. С разметкой, logs, тестами.

---

## Выбор оркестрации

**Одиночный агент (sequential):**
- 1–3 модуля в плане,
- либо IDE не поддерживает sub-agents (Continue, Cline базово),
- либо пользователь явно предпочитает sequential.

**Multiagent (parallel waves):**
- есть многомодульные фазы (> 2 параллельных модулей),
- IDE поддерживает sub-agents (Claude Code, Cursor background agents).
- Conventions для ExecutionPacket / GraphDelta / FailurePacket — в `docs/operational-packets.xml` целевого репо.

При multiagent выбери **профиль автономии** (`safe` / `balanced` / `fast`) по таблице:

| Ситуация | Профиль |
|---|---|
| первый день на методологии + новый код | `safe` |
| стандартный старт проекта | `balanced` (default) |
| mature codebase + strong verification (редко для new-project) | `fast` |

(Глубина артефактов в doubled-graph не масштабируется, всегда максимум; см. `methodology/auto-scaling.md`.)

**Approval gate (план исполнения):**

Покажи:

1. Предложенный выбор с однострочным объяснением:
   - `single` — sequential, approval перед execute очереди;
   - `multiagent: safe` — параллельно, **approval перед каждой волной**;
   - `multiagent: balanced` (default) — параллельно, **один approval up-front**, per-module review;
   - `multiagent: fast` — **approval только один раз на весь run**, без per-wave gates (для mature codebase с полным verification).
2. План исполнения: фазы → модули → зависимости.
3. **⚠ Особое внимание**: критические модули; модули с `impact` HIGH/CRITICAL; при `fast` — список verification-активов, покрывающих риск.
4. **Чек-лист**:
   - [ ] профиль соответствует зрелости проекта;
   - [ ] для `fast` — verification покрывает критические пути;
   - [ ] порядок исполнения не нарушает зависимости;
   - [ ] risk-level каждого шага < CRITICAL или явно принят.
5. Вопрос:

   > Выбор оркестрации: <профиль>. Подтвердите по чек-листу. Для `fast` — отдельная фраза: «да, fast, понимаю что per-wave approval не будет».

**Особый случай `fast`:** на «да»/«ок» переспроси явно — «`fast` отключает per-wave approval. Подтвердите отдельной фразой.» Не начинай execute на `fast` без явной фразы.

---

## Выполнение фазы N

**Для каждой фазы** из `development-plan.xml`:

**Шаг 1** — выбор модулей фазы. Показываешь пользователю, какие M-* будут сделаны в этой волне.

**Шаг 2** — worker(s) генерируют код. Каждый worker:

1. `doubled-graph.context(<module-id>)` — получает 360-view на модуль (declared + computed состояние, зависимости, экспорты).
2. Читает `development-plan.xml �� Contract` своего M-*.
3. Читает `technology.xml` — использует указанные библиотеки.
4. Читает `methodology/language-adapters/<язык>.md` — учитывает language-specific правила.
5. Пишет:
   - файл с MODULE_CONTRACT и MODULE_MAP в header;
   - функции с CONTRACT: блоками;
   - блоки BLOCK_* для секций > 20–30 строк;
   - структурированные logs с `anchor`, `module`, `requirement` полями;
   - CHANGE_SUMMARY в конце файла.

**Шаг 3** — реализация тестов. Для каждого `V-M-*` из `verification-plan.xml`:

- тест с правильной командой запуска;
- покрывает сценарий из `<scenario-*>`;
- порождает log-событие с соответствующим `<marker-*>` из `<required-log-markers>`.

**Шаг 4** — worker после кодогенерации:
- `doubled-graph.analyze(mode="incremental", paths=[<новые-файлы>])` — обновляет computed graph;
- возвращает GraphDelta: новые/изменённые файлы, экспорты, CrossLinks.

**Шаг 5** — reviewer (в `safe`/`balanced`):
- `doubled-graph.lint()` — валидация якорей и ссылок;
- `doubled-graph.detect_changes(scope="compare")` — drift между declared и computed;
- проверяет соответствие контракту;
- проверяет наличие разметки;
- проверяет, что тесты запускаются и проходят.

**Шаг 6** — после волны:
- `doubled-graph.analyze(mode="incremental", paths=[<новые-файлы>])`;
- `Edit` `docs/knowledge-graph.xml` и `docs/development-plan.xml` под реальное состояние кода (если что-то разошлось — см. skill `doubled-graph-after-edit` шаг 2).

---

## Правила качества кода

- **Следуй `technology.xml`.** Не добавляй библиотеки, которых там нет, без возврата на approval.
- **Следуй `methodology/language-adapters/<язык>.md`.** Язык-специфичные правила важнее общих.
- **Pre/post/invariants** — как runtime-проверки **только** для `criticality ∈ {critical, standard}` модулей и только по рекомендации language-adapter'а.
- **Logs на русском или английском** — последовательно в рамках проекта (обычно английский для машиночитаемости полей).
- **Не смешивай языки в одной строке лога.** «event: 'user_login', msg: 'пользователь вошёл'» — ок; «event: 'пользователь_вошёл'» — нет (ломает downstream).

---

## Approval между фазами

**Профиль `safe`:** approval перед каждой фазой (вы уже выбрали это).
**Профиль `balanced`:** approval был один раз up-front. Между фазами — только если были явные блокеры.
**Профиль `fast`:** без approval, только в конце фазы — scoped reviewer.

---

## Переход

После завершения всех фаз — прочитай `prompts/new-project/07-post-init-sync.md` через Read tool и следуй его инструкциям.
