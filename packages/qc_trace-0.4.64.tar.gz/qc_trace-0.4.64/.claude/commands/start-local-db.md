Start the local development PostgreSQL database (qctrace-local on port 25432).

Steps:
1. Check if the `qctrace-local` container exists: `docker ps -a --filter name=qctrace-local --format '{{.Status}}'`
2. If it exists but is stopped, start it: `docker start qctrace-local`
3. If it doesn't exist, create it:
   ```
   docker run -d --name qctrace-local -p 25432:5432 -e POSTGRES_USER=localdev -e POSTGRES_PASSWORD=localdev -e POSTGRES_DB=qc_trace postgres:16-alpine
   ```
4. Wait for it to accept connections: `docker exec qctrace-local pg_isready -U localdev -d qc_trace --timeout=30`
5. Print confirmation: "Local DB ready at localhost:25432 (user: localdev, db: qc_trace)"
