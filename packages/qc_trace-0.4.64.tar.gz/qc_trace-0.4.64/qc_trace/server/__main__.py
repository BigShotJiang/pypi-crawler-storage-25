"""Allow running the server with `python -m qc_trace.server`."""

from qc_trace.server.app import run_server

if __name__ == "__main__":
    run_server()
