"""CLI tools for quickcall."""
