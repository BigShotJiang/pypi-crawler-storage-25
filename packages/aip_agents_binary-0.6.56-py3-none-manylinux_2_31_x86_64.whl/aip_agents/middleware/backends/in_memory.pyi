from aip_agents.middleware.backends.protocol import BackendProtocol, EditResult, FileInfo, GrepMatch, WriteResult
from typing import Any

__all__ = ['InMemoryBackend']

class InMemoryBackend(BackendProtocol):
    '''In-memory filesystem backend.

    Explicitly implements BackendProtocol with thread-isolated storage.
    Stores files in memory per thread_id, making it suitable for
    agent conversations where each thread needs isolated file storage.

    Thread Safety:
        All operations are protected by threading.RLock to ensure
        thread-safe access to the shared storage.

    Attributes:
        _storage: Dictionary mapping thread_id to {path: FileData}.
        _storage_lock: RLock protecting concurrent access to _storage.

    Example:
        >>> backend = InMemoryBackend()
        >>> files = {"/test.txt": {"content": ["Hello"], "created_at": "2024-01-01", "modified_at": "2024-01-01"}}
        >>> backend.set_files(files, thread_id="thread-1")
        >>> retrieved = backend.get_files(thread_id="thread-1")
        >>> "/test.txt" in retrieved
        True
    '''
    def __init__(self) -> None:
        """Initialize with empty storage."""
    def set_files(self, files: dict[str, Any], thread_id: str = 'default') -> None:
        '''Load files from state for a specific thread.

        Called by FilesystemMiddleware.before_model to restore files
        from checkpointed state into the backend.

        Args:
            files: Dictionary mapping file paths to FileData.
            thread_id: Thread identifier for isolation. Defaults to "default".

        Note:
            Makes a copy of the files dict to prevent external modifications
            affecting internal storage.
        '''
    def get_files(self, thread_id: str = 'default') -> dict[str, Any]:
        '''Get files for a specific thread.

        Called by FilesystemMiddleware.after_model to save files
        from backend into state for checkpointing.

        Args:
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            Dictionary mapping file paths to FileData, or empty dict
            if no files for this thread.

        Note:
            Returns a copy to prevent external modifications affecting
            internal storage.
        '''
    def write(self, file_path: str, content: str | list[str], thread_id: str = 'default') -> WriteResult:
        '''Write content to a file.

        Args:
            file_path: Path where to write the file.
            content: Content to write (string or list of strings).
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            WriteResult indicating success.
        '''
    def read(self, file_path: str, line_offset: int = 0, limit: int = 2000, *, offset: int | None = None, thread_id: str = 'default') -> str:
        '''Read a file\'s contents with line numbers.

        Args:
            file_path: Path to the file.
            line_offset: Line number to start reading from (0-indexed).
            limit: Maximum number of lines to read.
            thread_id: Thread identifier for isolation. Defaults to "default".
            offset: Deprecated alias for ``line_offset``.

        Returns:
            File content formatted with line numbers.

        Raises:
            FileNotFoundError: If file does not exist.
        '''
    def read_bytes(self, file_path: str, thread_id: str = 'default') -> bytes:
        '''Read a file\'s contents as raw bytes.

        Args:
            file_path: Path to the file.
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            File content as raw bytes (no formatting, no line numbers).

        Raises:
            FileNotFoundError: If file does not exist.
            IsADirectoryError: If path is a directory (not supported in memory backend).
        '''
    def read_chars(self, file_path: str, char_offset: int = 0, max_chars: int = 20000, thread_id: str = 'default') -> str:
        '''Read a file\'s contents by character position.

        Provides character-based pagination for reading large files
        that may have very long single lines.

        Args:
            file_path: Path to the file.
            char_offset: Character position to start from (0-indexed).
            max_chars: Maximum number of characters to read.
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            File content without line numbers (raw characters).

        Raises:
            FileNotFoundError: If file does not exist.
        '''
    def ls_info(self, path: str, thread_id: str = 'default') -> list[FileInfo]:
        '''List files in a directory.

        Args:
            path: Directory path to list.
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            List of FileInfo objects.

        Raises:
            FileNotFoundError: If directory does not exist (treats root as always existing).
        '''
    def grep(self, pattern: str, path: str | None = None, thread_id: str = 'default') -> list[GrepMatch]:
        '''Search for text pattern across files.

        Args:
            pattern: Text pattern to search for (literal string, not regex).
            path: Directory to search in. Defaults to None (search all).
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            List of GrepMatch objects.

        Raises:
            FileNotFoundError: If path is specified but directory does not exist.
        '''
    grep_raw = grep
    def edit(self, file_path: str, old_string: str, new_string: str, replace_all: bool = False, thread_id: str = 'default') -> EditResult:
        '''Edit a file by replacing old_string with new_string.

        Args:
            file_path: Path to the file to edit.
            old_string: String to find and replace.
            new_string: String to replace with.
            replace_all: If True, replace all occurrences. If False,
                old_string must appear exactly once. Defaults to False.
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            EditResult with number of replacements.

        Notes:
            Returns errors via EditResult.error to match deepagents-style tool flow.
        '''
    def glob_info(self, pattern: str, path: str = '/', thread_id: str = 'default') -> list[FileInfo]:
        '''Find files matching a glob pattern.

        Args:
            pattern: Glob pattern to match (e.g., "**/*.py").
            path: Base directory to search from. Defaults to "/".
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            List of FileInfo objects for matching files.
        '''
