from aip_agents.middleware.backends.utils import ensure_absolute_path as ensure_absolute_path, truncate_if_too_long as truncate_if_too_long
from langchain_core.tools import BaseTool
from pydantic import BaseModel, SkipValidation as SkipValidation
from typing import Annotated, Any

LIST_FILES_TOOL_DESCRIPTION: str

class LsInput(BaseModel):
    """Input schema for ls tool."""
    path: str

class LsTool(BaseTool):
    """Tool for listing directory contents.

    Returns a Python list representation (as string) of absolute paths for files and directories.
    Large results are automatically truncated with guidance.
    """
    name: str
    description: str
    args_schema: type[BaseModel]
    backend: Annotated[Any, None]
