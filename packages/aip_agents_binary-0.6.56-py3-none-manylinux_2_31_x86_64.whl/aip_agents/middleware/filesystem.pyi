from _typeshed import Incomplete
from abc import abstractmethod
from aip_agents.middleware.backends.protocol import BackendProtocol
from aip_agents.middleware.base import AgentMiddleware, ModelRequest
from langchain_core.tools import BaseTool
from pathlib import Path
from pydantic import BaseModel
from typing import Any

__all__ = ['FilesystemConfig', 'InMemoryConfig', 'LocalDiskConfig', 'FilesystemMiddleware', 'FILESYSTEM_SYSTEM_PROMPT', 'EXECUTION_SYSTEM_PROMPT', '_backend_supports_execution', '_is_execution_enabled', '_execute_accepts_timeout']

EXECUTION_SYSTEM_PROMPT: str

def _backend_supports_execution(backend: BackendProtocol) -> bool:
    """Check if backend supports command execution.

    Handles both direct backends and CompositeBackend which may wrap
    a sandbox backend as its default.

    Args:
        backend: The backend to check.

    Returns:
        True if the backend supports execution, False otherwise.
    """
def _is_execution_enabled(backend: BackendProtocol) -> bool:
    """Check if execution is enabled for this backend.

    Even if a backend supports execution (has execute method),
    it may be disabled via allow_execute flag.

    Args:
        backend: The backend to check.

    Returns:
        True if execution is enabled, False otherwise.
    """
def _execute_accepts_timeout(backend_class: type) -> bool:
    """Check whether a backend class's `execute` accepts a `timeout` kwarg.

    Args:
        backend_class: The backend class to inspect.

    Returns:
        True if the execute method accepts a timeout parameter, False otherwise.
    """

class FilesystemConfig(BaseModel):
    '''Abstract base class for filesystem backend configurations.

    Subclasses implement create_backend() to instantiate specific backends.
    This allows users to configure filesystem storage with custom settings.

    Example:
        >>> config = InMemoryConfig()
        >>> backend = config.create_backend()
        >>> middleware = FilesystemMiddleware(backend=backend)

        >>> config = LocalDiskConfig(base_directory="/tmp/agent_files")
        >>> backend = config.create_backend()
        >>> middleware = FilesystemMiddleware(backend=backend)
    '''
    @abstractmethod
    def create_backend(self) -> BackendProtocol:
        """Create and return a backend instance based on this configuration.

        Returns:
            BackendProtocol: Configured backend instance ready for use.
        """

class InMemoryConfig(FilesystemConfig):
    '''Configuration for in-memory filesystem backend.

    Stores all files in memory. Files are lost when the process exits.
    Best for temporary storage and testing scenarios.

    Example:
        >>> config = InMemoryConfig()
        >>> agent = LangGraphReactAgent(
        ...     name="test_agent",
        ...     instruction="Test",
        ...     filesystem=config
        ... )
    '''
    def create_backend(self) -> BackendProtocol:
        """Create an in-memory backend.

        Returns:
            BackendProtocol: InMemoryBackend instance.
        """
    model_config: Incomplete

class LocalDiskConfig(FilesystemConfig):
    '''Configuration for local disk filesystem backend.

    Stores files on the local filesystem at the specified base path.
    Files persist between process restarts.
    Best for production use cases requiring file persistence.


    Args:
        base_directory: Root directory for file storage.

    Example:
        >>> import tempfile
        >>> with tempfile.TemporaryDirectory() as tmpdir:
        ...     config = LocalDiskConfig(base_directory=tmpdir)
        ...     agent = LangGraphReactAgent(
        ...         name="file_agent",
        ...         instruction="Process files",
        ...         filesystem=config
        ...     )
    '''
    base_directory: str | Path
    def create_backend(self) -> BackendProtocol:
        """Create a local disk backend.

        Returns:
            BackendProtocol: LocalDiskBackend instance configured with base_path.
        """
    model_config: Incomplete

FILESYSTEM_SYSTEM_PROMPT: str

class FilesystemMiddleware(AgentMiddleware):
    """Middleware providing filesystem capabilities for agents.

    Manages file storage and retrieval for agents using a pluggable backend.
    Provides hooks for lifecycle management and system prompt enhancement
    with file context information.

    Thread Safety:
        Uses the underlying backend's thread safety mechanisms.
        Each thread_id has isolated storage.

    Attributes:
        tools: List of file operation tools (empty in PR 001, populated in 002-004).
        system_prompt_additions: System prompt text explaining file access.
        backend: Storage backend for file operations.
    """
    backend: Incomplete
    tools: list[BaseTool]
    system_prompt_additions: Incomplete
    tool_token_limit_before_evict: Incomplete
    def __init__(self, backend: BackendProtocol | None = None, tool_token_limit_before_evict: int | None = ..., max_execute_timeout: int = 300) -> None:
        """Initialize filesystem tools and tool-output eviction policy.

        Args:
            backend: Filesystem backend implementation.
                If ``None``, ``InMemoryBackend`` is used.
            tool_token_limit_before_evict: Token threshold used to
                decide when tool output should be evicted to
                ``/tool_outputs/<tool_call_id>.txt``. The middleware uses
                ``NUM_CHARS_PER_TOKEN`` as an approximation.
                Set to ``None`` to disable eviction.
            max_execute_timeout: Maximum timeout in seconds for execute commands.
                Defaults to 300. Only used if backend supports execution.

        Notes:
            Eviction is skipped for tools listed in
            ``TOOLS_EXCLUDED_FROM_EVICTION``.
        """
    def replace_backend(self, backend: BackendProtocol, max_execute_timeout: int = 300) -> None:
        """Replace the backend and rebuild all tools to point to it.

        Called by the coordinator during sub-agent registration to inject a
        shared backend. After this call, all tools will operate on the new
        backend.

        Args:
            backend: The new backend instance to use. Must implement BackendProtocol.
            max_execute_timeout: Maximum timeout in seconds for execute commands.
                Defaults to 300. Only used if backend supports execution.
        """
    def before_model(self, state: dict[str, Any]) -> dict[str, Any]:
        '''Hook executed before model invocation.

        Loads files from state into the backend storage for the current thread.
        This restores the filesystem state from checkpointed data.

        Args:
            state: Current agent state containing messages and other context.
                Expected keys:
                - "files": Dictionary mapping file paths to file data (optional).
                - "configurable": Dict containing "thread_id" for isolation.

        Returns:
            Empty dict (no state updates needed from this hook).
        '''
    def after_model(self, state: dict[str, Any]) -> dict[str, Any]:
        '''Hook executed after model invocation.

        Persists files to backend for checkpointing. Note: message eviction
        is handled in modify_model_request hook before LLM invocation.

        Args:
            state: Current agent state after model invocation.

        Returns:
            Dict with "files" key if files exist, or empty dict if no updates needed.
        '''
    def modify_model_request(self, request: ModelRequest, state: dict[str, Any]) -> ModelRequest:
        """Modify the model request before invocation."""
    async def abefore_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async version of before_model.

        Args:
            state: Current agent state containing messages and other context.

        Returns:
            Dict of state updates to merge into the agent state. Return empty dict
            if no updates are needed.
        """
    async def aafter_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async version of after_model.

        Args:
            state: Current agent state after model invocation.

        Returns:
            Dict of state updates to merge into the agent state. Return empty dict
            if no updates are needed.
        """
