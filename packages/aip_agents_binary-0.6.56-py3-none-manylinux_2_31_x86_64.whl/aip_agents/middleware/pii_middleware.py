"""PII awareness middleware for LangGraph agents.

This middleware injects a PII-awareness guidance block into the agent's system prompt
when PII handling is enabled (`enable_pii=True`). The block instructs the LLM to treat
anonymized PII placeholders (e.g., <PERSON_1>) as opaque tokens and reference them exactly
as provided, without attempting to reverse-engineer or expose the real values.

The middleware provides a clean, composable alternative to direct prompt injection,
consistent with other middleware patterns in the codebase (TodoListMiddleware, etc.).

Authors:
    Fachriza Adhiatma (fachriza.d.adhiatma@gdplabs.id)
"""

from typing import Any

from aip_agents.middleware.base import ModelRequest
from aip_agents.utils.pii import get_pii_agent_prompt


class PIIMiddleware:
    """Middleware for injecting PII awareness guidance into agent system prompts.

    This middleware contributes a system prompt addition that instructs the LLM about
    anonymized PII handling. It is automatically configured when `enable_pii=True`
    in the agent initialization.

    The prompt block is computed once at middleware instantiation time and remains
    constant throughout the agent's lifetime.

    Attributes:
        tools: Empty list (no tools provided by this middleware).
        system_prompt_additions: The PII guidance block to append to the system prompt,
            or None if PII is not enabled.
    """

    def __init__(self) -> None:
        """Initialize PII prompt middleware with the guidance block."""
        self.tools = []
        self.system_prompt_additions = self._build_pii_prompt()

    def _build_pii_prompt(self) -> str | None:
        """Build PII awareness guidance block for the system prompt.

        Reads the PII_AGENT_PROMPT environment variable. If set and non-empty,
        its value is used as the guidance block. Otherwise, falls back to the
        hardcoded default.

        Returns:
            A short instruction block informing the LLM that PII has been
            anonymized and must not be reverse-engineered or exposed,
            or None if no custom prompt is available.
        """
        custom_prompt = get_pii_agent_prompt()
        if custom_prompt:
            return custom_prompt

        # Hardcoded default guidance block
        return (
            "<PII_HANDLING>\n"
            "Sensitive data in this conversation has been anonymized using placeholder tags "
            "(e.g. <PERSON_1>, <EMAIL_1>).\n"
            "- Process all data exactly as provided without modifying, expanding, or altering "
            "any content, especially masked placeholders.\n"
            "- Do NOT attempt to reverse, guess, or expose the real values behind these tags.\n"
            "- When referencing anonymized data, use the placeholder tag exactly as provided.\n"
            "</PII_HANDLING>"
        )

    def before_model(self, _state: dict[str, Any]) -> dict[str, Any]:
        """Hook executed before each model invocation.

        This middleware does not modify state before model calls since the PII
        guidance is already provided via system_prompt_additions.

        Args:
            _state: Current agent state containing messages and other context.

        Returns:
            Empty dict (no state updates).
        """
        return {}

    async def abefore_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async hook executed before model invocation (no-op for this middleware)."""
        return self.before_model(state)  # pragma: no cover

    def modify_model_request(self, request: ModelRequest, _state: dict[str, Any]) -> ModelRequest:
        """Hook to modify model request before invocation.

        This middleware does not modify the model request since the PII guidance
        is already provided via system_prompt_additions.

        Args:
            request: The model request that will be sent to the LLM.
            _state: Current agent state for context.

        Returns:
            Unmodified ModelRequest.
        """
        return request

    def after_model(self, _state: dict[str, Any]) -> dict[str, Any]:
        """Hook executed after each model invocation.

        This middleware does not perform any post-processing after model calls.

        Args:
            _state: Current agent state after model invocation.

        Returns:
            Empty dict (no state updates).
        """
        return {}

    async def aafter_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async hook executed after model invocation (no-op for this middleware)."""
        return self.after_model(state)  # pragma: no cover

    def before_run(self, _state: dict[str, Any], _config: dict[str, Any] | None) -> dict[str, Any]:
        """Hook executed before each agent run.

        This middleware does not perform run-level setup since the PII guidance
        is already provided via system_prompt_additions.

        Args:
            _state: Initial agent state.
            _config: Optional run configuration.

        Returns:
            Empty dict (no state updates).
        """
        return {}

    async def abefore_run(self, state: dict[str, Any], config: dict[str, Any] | None) -> dict[str, Any]:
        """Async hook executed before agent run (no-op for this middleware)."""
        return self.before_run(state, config)  # pragma: no cover

    def after_run(
        self,
        *,
        _final_state: dict[str, Any],
        _output: str | None,
        _config: dict[str, Any] | None,
        _error: Exception | None,
    ) -> None | dict[str, Any]:
        """Hook executed after each agent run.

        This middleware does not perform run-level cleanup or persistence.

        Args:
            _final_state: Final state after agent run completion.
            _output: Agent's final output string, or None if run ended with error.
            _config: Run configuration used for this execution.
            _error: Exception raised during run, or None if run succeeded.

        Returns:
            None (no updates or cleanup needed).
        """
        return None

    async def aafter_run(
        self,
        *,
        final_state: dict[str, Any],
        output: str | None,
        config: dict[str, Any] | None,
        error: Exception | None,
    ) -> None | dict[str, Any]:
        """Async hook executed after agent run (no-op for this middleware)."""
        return self.after_run(  # pragma: no cover
            _final_state=final_state, _output=output, _config=config, _error=error
        )

    def on_final_response(self, _content: str, _context: dict[str, Any]) -> None:
        """Hook executed when streaming final response is captured.

        This middleware does not process the final response content.

        Args:
            _content: Final response text from the agent.
            _context: Context dict containing metadata about the response.

        Returns:
            None.
        """
        return None
