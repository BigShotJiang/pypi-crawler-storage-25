"""Public HITL contracts for cross-package integrations.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from aip_agents.agent.hitl.manager import ApprovalManager
    from aip_agents.agent.hitl.prompt import BasePromptHandler
    from aip_agents.schema.hitl import ApprovalDecision, ApprovalDecisionType, ApprovalRequest


class PromptHandlerProtocol(Protocol):
    """Minimal HITL prompt contract used by SDK-side prompt handlers."""

    def attach_manager(self, manager: ApprovalManager) -> None:
        """Attach the approval manager coordinating the prompt handler."""
        raise NotImplementedError  # pragma: no cover

    async def prompt_for_decision(
        self,
        request: ApprovalRequest,
        timeout_seconds: int,
        context_keys: list[str] | None = None,
    ) -> ApprovalDecision:
        """Return an approval decision for a pending HITL request."""
        raise NotImplementedError  # pragma: no cover


_SCHEMA_HITL_MODULE = "aip_agents.schema.hitl"
_HITL_MANAGER_MODULE = "aip_agents.agent.hitl.manager"
_HITL_PROMPT_MODULE = "aip_agents.agent.hitl.prompt"

_IMPORT_MAP = {
    "ApprovalDecision": _SCHEMA_HITL_MODULE,
    "ApprovalDecisionType": _SCHEMA_HITL_MODULE,
    "ApprovalManager": _HITL_MANAGER_MODULE,
    "ApprovalRequest": _SCHEMA_HITL_MODULE,
    "BasePromptHandler": _HITL_PROMPT_MODULE,
}

__all__ = [
    "ApprovalDecision",
    "ApprovalDecisionType",
    "ApprovalManager",
    "ApprovalRequest",
    "BasePromptHandler",
    "PromptHandlerProtocol",
]


def __getattr__(name: str) -> Any:
    """Lazy-load public HITL contracts."""
    module_name = _IMPORT_MAP.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module = importlib.import_module(module_name)
    value = getattr(module, name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    """Return module attributes for dir()."""
    return sorted(__all__)
