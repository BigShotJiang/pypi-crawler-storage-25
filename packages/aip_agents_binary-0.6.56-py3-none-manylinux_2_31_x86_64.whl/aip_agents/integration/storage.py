"""Public tool-output storage contracts for cross-package integrations.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from aip_agents.storage import (
        InMemoryStorageProvider,
        MinioConfig,
        MinioObjectStorage,
        ObjectStorageProvider,
    )
    from aip_agents.utils.langgraph.tool_output_management import (
        StoreOutputParams,
        ToolOutputConfig,
        ToolOutputManager,
    )


class ToolOutputManagerProtocol(Protocol):
    """Minimal tool-output manager contract used by local-mode integrations."""

    def store_output(self, params: StoreOutputParams) -> None:
        """Persist a tool output entry."""
        ...

    def has_outputs(self, thread_id: str | None = None) -> bool:
        """Return whether any outputs are available."""
        ...

    def get_latest_reference(self, thread_id: str) -> str | None:
        """Return the latest reference token for a thread."""
        ...


_STORAGE_MODULE = "aip_agents.storage"
_TOOL_OUTPUT_MODULE = "aip_agents.utils.langgraph.tool_output_management"

_IMPORT_MAP = {
    "InMemoryStorageProvider": _STORAGE_MODULE,
    "MinioConfig": _STORAGE_MODULE,
    "MinioObjectStorage": _STORAGE_MODULE,
    "ObjectStorageProvider": _STORAGE_MODULE,
    "StoreOutputParams": _TOOL_OUTPUT_MODULE,
    "ToolOutputConfig": _TOOL_OUTPUT_MODULE,
    "ToolOutputManager": _TOOL_OUTPUT_MODULE,
}

__all__ = [
    "InMemoryStorageProvider",
    "MinioConfig",
    "MinioObjectStorage",
    "ObjectStorageProvider",
    "StoreOutputParams",
    "ToolOutputConfig",
    "ToolOutputManager",
    "ToolOutputManagerProtocol",
]


def __getattr__(name: str) -> Any:
    """Lazy-load public storage contracts."""
    module_name = _IMPORT_MAP.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module = importlib.import_module(module_name)
    value = getattr(module, name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    """Return module attributes for dir()."""
    return sorted(__all__)
