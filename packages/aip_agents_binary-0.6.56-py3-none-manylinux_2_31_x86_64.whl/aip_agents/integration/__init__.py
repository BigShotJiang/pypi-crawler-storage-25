"""Public cross-package integration facade for `glaip-sdk` consumers.

Only the `aip_agents.integration` namespace is part of the boundary contract for
cross-package local-runtime integrations. Deep module paths remain implementation
details and non-contract surfaces, even when the facade re-exports types sourced
from those modules.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from aip_agents.integration import agent, guardrails, hitl, ptc, skills, storage
from aip_agents.integration.version import (
    AUTO_MODE_FALLBACK_ENABLED,
    CONTRACT_EXPORTS,
    CONTRACT_MODULES,
    CONTRACT_NAMESPACE,
    IMPORT_MODE_ENV_VAR,
    INTEGRATION_FACADE_MODULES,
    INTEGRATION_MODE_STRICT,
    NON_CONTRACT_SURFACE_PATTERNS,
    integration_contract_version,
)

__all__ = [
    "AUTO_MODE_FALLBACK_ENABLED",
    "agent",
    "guardrails",
    "hitl",
    "ptc",
    "skills",
    "storage",
    "CONTRACT_EXPORTS",
    "CONTRACT_MODULES",
    "CONTRACT_NAMESPACE",
    "INTEGRATION_FACADE_MODULES",
    "INTEGRATION_MODE_STRICT",
    "IMPORT_MODE_ENV_VAR",
    "NON_CONTRACT_SURFACE_PATTERNS",
    "integration_contract_version",
]
