from _typeshed import Incomplete
from aip_agents.ptc import PTCCustomToolConfig as PTCCustomToolConfig
from aip_agents.ptc.custom_tools import PTCToolDef as PTCToolDef, enrich_tool_def_with_metadata as enrich_tool_def_with_metadata
from aip_agents.ptc.naming import sanitize_function_name as sanitize_function_name

logger: Incomplete

def build_tool_lookup(tools: list[object]) -> dict[str, object]:
    '''Build a lookup map from tool objects for name-based matching.

    Creates entries for both original and sanitized names to support
    fuzzy matching (e.g., "web-search" matches "web_search").

    Args:
        tools: List of tool objects with `name` attribute.

    Returns:
        Dict mapping tool names (and sanitized names) to tool objects.

    Example:
        >>> tools = [TimeTool(), WebSearchTool()]  # names: "time_tool", "web-search"
        >>> lookup = build_tool_lookup(tools)
        >>> lookup.keys()
        dict_keys([\'time_tool\', \'web-search\', \'web_search\'])
    '''
def match_tool_by_name(tool_def: PTCToolDef, tool_lookup: dict[str, object]) -> tuple[object | None, str | None]:
    '''Find a matching tool object for a tool definition.

    Tries exact name match first, then falls back to sanitized name.

    Args:
        tool_def: Tool definition dict with "name" key.
        tool_lookup: Lookup map from build_tool_lookup().

    Returns:
        Tuple of (matching_tool, canonical_name) or (None, None) if no match.
        canonical_name is the tool object\'s actual name (may differ from tool_def name).
    '''
def enrich_custom_tools_from_agent(custom_tools_config: PTCCustomToolConfig, agent_tools: list[object], agent_name: str = '') -> int:
    '''Enrich custom tool definitions with metadata from agent\'s tool objects.

    Matches custom tool definitions with actual tool objects by name (including
    sanitized name matching) and enriches them with description and input_schema.

    Note: This function modifies custom_tools_config.tools in-place.

    Args:
        custom_tools_config: The PTCCustomToolConfig to enrich.
        agent_tools: List of tool objects from the agent.
        agent_name: Agent name for logging context.

    Returns:
        Number of tools that were enriched.

    Example:
        >>> config = PTCCustomToolConfig(enabled=True, tools=[{"name": "multiply", ...}])
        >>> count = enrich_custom_tools_from_agent(config, [MultiplyTool()], "my_agent")
        >>> count
        1
    '''
