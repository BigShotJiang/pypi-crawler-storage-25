from _typeshed import Incomplete
from aip_agents.mcp.client.base_mcp_client import BaseMCPClient as BaseMCPClient
from aip_agents.ptc.custom_tools import PTCCustomToolConfig as PTCCustomToolConfig
from aip_agents.ptc.exceptions import PTCToolError as PTCToolError
from aip_agents.ptc.payload import SandboxPayload as SandboxPayload
from aip_agents.ptc.prompt_builder import PromptConfig as PromptConfig
from aip_agents.ptc.sandbox_bridge import build_sandbox_payload as build_sandbox_payload, wrap_ptc_code as wrap_ptc_code
from aip_agents.sandbox.defaults import DEFAULT_PTC_PACKAGES as DEFAULT_PTC_PACKAGES, DEFAULT_PTC_TEMPLATE as DEFAULT_PTC_TEMPLATE
from aip_agents.sandbox.e2b_runtime import E2BSandboxRuntime as E2BSandboxRuntime
from aip_agents.sandbox.types import SandboxExecutionResult as SandboxExecutionResult
from aip_agents.utils.logger import get_logger as get_logger
from dataclasses import dataclass, field

logger: Incomplete

@dataclass
class PTCSandboxConfig:
    """Configuration for PTC sandbox executor.

    Attributes:
        enabled: Whether PTC is enabled. When False, PTC is disabled.
        default_tool_timeout: Default timeout per tool call in seconds.
        sandbox_template: Optional E2B sandbox template ID.
        sandbox_timeout: Sandbox execution timeout in seconds (hard cap/TTL).
        package_install_timeout: Timeout in seconds for sandbox package installation.
            When None, the runtime default applies.
        auto_build_template: Whether to automatically build the sandbox template if it's missing.
        ptc_packages: List of packages to install in sandbox. Defaults to DEFAULT_PTC_PACKAGES.
        prompt: Prompt configuration for PTC usage guidance.
        custom_tools: Configuration for custom LangChain tools in sandbox.
    """
    enabled: bool = ...
    default_tool_timeout: float = ...
    sandbox_template: str | None = ...
    sandbox_timeout: float = ...
    package_install_timeout: float | None = ...
    auto_build_template: bool = ...
    ptc_packages: list[str] | None = field(default_factory=Incomplete)
    prompt: PromptConfig = field(default_factory=PromptConfig)
    custom_tools: PTCCustomToolConfig = field(default_factory=PTCCustomToolConfig)

class PTCSandboxExecutor:
    '''Executes PTC code inside an E2B sandbox.

    This executor is used for LLM-generated code that requires sandboxing.
    It builds a sandbox payload (MCP server config + generated tool modules)
    and executes the code using the E2B runtime.

    Static bundle caching:
        The executor tracks whether the static bundle (wrappers, registry, sources)
        has been uploaded. On the first run, it uploads the full payload. On subsequent
        runs, it only uploads per-run files (e.g., tools/custom_defaults.json) to
        reduce upload overhead.

        If the sandbox is destroyed/recreated, call reset_static_bundle() to force
        a full re-upload on the next execution.

    Thread-safety:
        The static bundle upload is guarded by an asyncio.Lock. Concurrent calls will
        serialize while the initial upload completes. Per-run diff/execute/cache-update
        is guarded by an executor-local asyncio.Lock to keep dedupe state consistent.

    Example:
        runtime = E2BSandboxRuntime()
        executor = PTCSandboxExecutor(mcp_client, runtime)
        result = await executor.execute_code("from tools.yfinance import get_stock\\\\nprint(get_stock(\'AAPL\'))")
    '''
    def __init__(self, mcp_client: BaseMCPClient | None, runtime: E2BSandboxRuntime, config: PTCSandboxConfig | None = None) -> None:
        """Initialize PTCSandboxExecutor.

        Args:
            mcp_client: The MCP client with configured servers. Can be None for custom-only configs.
            runtime: The E2B sandbox runtime instance.
            config: Optional sandbox executor configuration.

        Raises:
            ImportError: If sandbox dependencies are not available.
        """
    async def execute_code(self, code: str, tool_configs: dict[str, dict] | None = None) -> SandboxExecutionResult:
        """Execute code inside the sandbox with MCP access.

        This method:
        1. Builds the sandbox payload (MCP config + generated tool modules + custom tools)
        2. Wraps the user code with necessary imports and setup
        3. Executes the code in the E2B sandbox
        4. Returns the execution result (stdout/stderr/exit_code)

        Args:
            code: Python code to execute in the sandbox.
            tool_configs: Optional per-tool config values for custom LangChain tools.
                These are merged with agent defaults and written to custom_defaults.json.

        Returns:
            SandboxExecutionResult with stdout, stderr, and exit_code.

        Raises:
            PTCToolError: If sandbox execution fails.
        """
    def reset_static_bundle(self) -> None:
        """Reset the static bundle upload state.

        Call this method when the sandbox is destroyed/recreated to force
        a full re-upload of the static bundle on the next execution.
        """
