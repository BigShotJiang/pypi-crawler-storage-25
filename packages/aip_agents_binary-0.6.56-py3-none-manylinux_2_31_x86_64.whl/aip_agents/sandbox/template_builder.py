"""Template builder for sandbox templates.

This module provides utilities for creating and managing E2B sandbox templates
for programmatic tool calling (PTC) environments.

Authors:
    Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)
"""

from pathlib import Path

from e2b import Template, default_build_logger

from aip_agents.sandbox.validation import validate_package_names
from aip_agents.utils.logger import get_logger

logger = get_logger(__name__)

DEFAULT_SANDBOX_DOCKERFILE_RELATIVE_PATH = Path("dockerfiles/aip-agents-sandbox-v2.Dockerfile")


def get_default_sandbox_dockerfile_path() -> Path:
    """Return the absolute path to the packaged default sandbox Dockerfile."""
    return Path(__file__).resolve().parent / DEFAULT_SANDBOX_DOCKERFILE_RELATIVE_PATH


def create_sandbox_template(
    base_template: str,
    packages: list[str] | None,
    *,
    dockerfile: str | Path | None = None,
) -> Template:
    """Create a sandbox template definition based on a base template.

    Args:
        base_template: Base template alias to build from (e.g., "code-interpreter-v1").
        packages: List of packages to install in the template.
            If None or empty, skips pip install step.
        dockerfile: Optional Dockerfile path. If provided, builds template from
            Dockerfile via ``Template().from_dockerfile(...)`` instead of
            ``from_template(...)``.

    Returns:
        Template: A configured template ready to be built.
    """
    if dockerfile:
        dockerfile_path = Path(dockerfile)
        logger.info(f"Creating template from Dockerfile: {dockerfile_path}")
        template = Template(file_context_path=str(dockerfile_path.parent)).from_dockerfile(str(dockerfile_path))
    else:
        logger.info(f"Creating template from base: {base_template}")
        template = Template().from_template(base_template)

    if packages:
        # Validate all packages before constructing command
        validate_package_names(packages)

        # Note: packages_str is safe because packages is a controlled list from
        # configuration, not user input. Template.run_cmd() only accepts str.
        packages_str = " ".join(packages)
        logger.info(f"Installing packages: {packages_str}")
        template.run_cmd(f"pip install -q {packages_str}")

    return template


def _template_exists(template_id: str) -> bool:
    """Check if a template alias exists.

    Args:
        template_id: The template alias to check.

    Returns:
        bool: True if alias exists, False otherwise.
    """
    try:
        exists_fn = getattr(Template, "exists", None)
        if not callable(exists_fn):
            return False
        return bool(exists_fn(template_id))
    except Exception:
        logger.warning(f"Template exists check failed for: {template_id}")
        return False


def _build_template(template: Template, template_id: str) -> bool:
    """Build a template with the given alias.

    Args:
        template: The template to build.
        template_id: The alias to assign to the built template.

    Returns:
        bool: True if build succeeded, False otherwise.
    """
    try:
        logger.info(f"Building template: {template_id}")
        Template.build(
            template,
            alias=template_id,
            on_build_logs=default_build_logger(),
        )
        logger.info(f"Template built successfully: {template_id}")
        return True
    except Exception as e:
        logger.warning(f"Template build failed for {template_id}: {e}")
        return False


def ensure_sandbox_template(
    template_id: str,
    base_template: str,
    packages: list[str] | None,
    force_rebuild: bool = False,
    dockerfile: str | Path | None = None,
) -> str | None:
    """Ensure a sandbox template exists, creating it if necessary.

    This is an explicit helper that apps can call at startup to ensure the
    template exists. It is never run implicitly by the SDK.

    Args:
        template_id: Unique alias for the template (e.g., "aip-agents-sandbox-v2").
        base_template: Base template alias to build from
            (e.g., "code-interpreter-v1").
        packages: List of packages to install in the template.
            If None or empty, skips pip install step.
        force_rebuild: If True, rebuild even if alias exists.
        dockerfile: Optional Dockerfile path used to create template via
            ``from_dockerfile``.

    Returns:
        The template_id on success, None if creation failed.
        Never raises exceptions.
    """
    # Fast path: template already exists and we're not forcing rebuild
    if not force_rebuild and _template_exists(template_id):
        logger.info(f"Template already exists: {template_id}")
        return template_id

    # Create and build the template
    try:
        template = create_sandbox_template(base_template, packages, dockerfile=dockerfile)
    except Exception as e:
        logger.warning(f"Template creation failed for {template_id}: {e}")
        return None

    # Build the template
    is_success = _build_template(template, template_id)
    if is_success:
        return template_id

    # Build failed. Check if template exists anyway (race condition: another
    # process may have built it while we were trying)
    if _template_exists(template_id):
        logger.info(f"Template already exists after failed build: {template_id}")
        return template_id

    return None


def create_ptc_template(
    base_template: str,
    ptc_packages: list[str] | None,
) -> Template:
    """Deprecated: Use create_sandbox_template instead."""
    return create_sandbox_template(base_template, ptc_packages)


def ensure_ptc_template(
    template_id: str,
    base_template: str,
    ptc_packages: list[str] | None,
    force_rebuild: bool = False,
) -> str | None:
    """Deprecated: Use ensure_sandbox_template instead."""
    return ensure_sandbox_template(template_id, base_template, ptc_packages, force_rebuild)
