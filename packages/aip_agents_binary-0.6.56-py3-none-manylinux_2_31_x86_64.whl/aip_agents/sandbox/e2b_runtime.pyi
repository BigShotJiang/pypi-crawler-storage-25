from _typeshed import Incomplete
from aip_agents.sandbox.defaults import DEFAULT_SANDBOX_PACKAGES as DEFAULT_SANDBOX_PACKAGES, DEFAULT_SANDBOX_TEMPLATE as DEFAULT_SANDBOX_TEMPLATE
from aip_agents.sandbox.types import SandboxExecutionResult as SandboxExecutionResult
from aip_agents.sandbox.validation import validate_package_names as validate_package_names
from aip_agents.utils.logger import get_logger as get_logger
from collections.abc import Callable

PackageSelector = Callable[[str | None], list[str] | None]
logger: Incomplete
SANDBOX_NOT_INITIALIZED_ERROR: str
DEFAULT_PACKAGE_INSTALL_TIMEOUT_SECONDS: float

class E2BSandboxRuntime:
    '''E2B Sandbox runtime for executing code in isolated environments.

    This runtime manages per-run sandbox lifecycle:
    - Create sandbox on first execute
    - Reuse sandbox for subsequent executes
    - Destroy sandbox on cleanup

    Example:
        runtime = E2BSandboxRuntime()
        result = await runtime.execute(
            code="print(\'Hello\')",
            timeout=60.0,
            files={"tools/mcp.py": "# MCP client code"},
        )
        await runtime.cleanup()
    '''
    def __init__(self, template: str | None = None, packages: list[str] | None = None, package_selector: PackageSelector | None = None, sandbox_timeout: int = 300, package_install_timeout: float | None = None, auto_build_template: bool = False, build_base_template: str = 'code-interpreter-v1', ptc_packages: list[str] | None = None) -> None:
        '''Initialize E2B sandbox runtime.

        Args:
            template: Optional E2B template ID for custom sandbox environments.
            packages: Packages to install in sandbox. If None or empty, skip install.
                Overwritten by package_selector if provided.
            package_selector: Optional callback to select packages after sandbox creation.
                Called with actual template (None if template failed) to enable smart
                package selection based on whether template was successfully created.
            sandbox_timeout: Timeout in seconds for the sandbox session. Defaults to 300.
                This prevents "port is not open" errors by keeping the sandbox alive.
            package_install_timeout: Timeout in seconds for package installation.
                When None, uses the runtime default. Values <= 0 disable the E2B
                command timeout for package installation.
            auto_build_template: If True and the requested template returns 404, attempt
                to build it automatically before falling back to the default sandbox.
                Building can take several minutes. Defaults to False.
            build_base_template: Base E2B template to build from when auto-building.
                Defaults to ``"code-interpreter-v1"``.
            ptc_packages: Deprecated. Use `packages` instead.
        '''
    async def execute(self, code: str, *, timeout: float = 300, files: dict[str, str] | None = None, env: dict[str, str] | None = None, template: str | None = None) -> SandboxExecutionResult:
        """Execute code inside the sandbox.

        Args:
            code: Python code to execute.
            timeout: Execution timeout in seconds.
            files: Files to upload to the sandbox (path -> content).
            env: Environment variables to set.
            template: Optional template override for this execution.

        Returns:
            SandboxExecutionResult with stdout, stderr, and exit_code.
        """
    async def execute_command(self, command: str, *, timeout: float = 30, env: dict[str, str] | None = None) -> SandboxExecutionResult:
        """Execute a shell command in the sandbox.

        Args:
            command: Shell command to execute.
            timeout: Command timeout in seconds.
            env: Optional environment variables.

        Returns:
            SandboxExecutionResult containing stdout, stderr, and exit_code.

        Notes:
            Preferred path uses ``commands.run``. If unavailable, it falls back to
            ``run_code(language='bash')``.
        """
    async def cleanup(self) -> None:
        """Destroy the sandbox and release resources."""
    @property
    def is_active(self) -> bool:
        """Check if a sandbox is currently active."""
