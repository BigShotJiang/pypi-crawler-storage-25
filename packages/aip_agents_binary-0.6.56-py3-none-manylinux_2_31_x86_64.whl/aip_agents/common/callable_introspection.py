"""Helpers for lightweight callable signature checks."""

from __future__ import annotations

import inspect
from typing import Any


def callable_accepts_keyword(target: Any, keyword: str) -> bool:
    """Return whether ``target`` accepts ``keyword`` in its signature."""
    if not callable(target):
        return False
    try:
        signature = inspect.signature(target)
    except (TypeError, ValueError):
        return False
    return keyword in signature.parameters
