from _typeshed import Incomplete
from aip_agents.resilience.base import BaseResilienceExecutor as BaseResilienceExecutor, ResilienceRequest as ResilienceRequest
from dataclasses import dataclass
from langchain_core.tools import BaseTool
from pybreaker import CircuitBreaker
from typing import Any

DEFAULT_TOOL_TIMEOUT_SECONDS: float
DEFAULT_RETRY_ENABLED: bool
DEFAULT_RETRY_MAX_ATTEMPTS: int
DEFAULT_RETRY_BACKOFF_MIN_SECONDS: float
DEFAULT_RETRY_BACKOFF_MAX_SECONDS: float
DEFAULT_RETRYABLE_ERROR_KINDS: Incomplete
DEFAULT_CIRCUIT_BREAKER_ENABLED: bool
DEFAULT_CIRCUIT_FAIL_MAX: int
DEFAULT_CIRCUIT_RESET_TIMEOUT_SECONDS: float
DEFAULT_CIRCUIT_HALF_OPEN_MAX_CALLS: int
TOOL_TIMEOUT_SECONDS_KEY: str
TOOL_SOURCE_KEY: str
RESILIENCE_KEY: str
TIMEOUT_SECONDS_KEY: str
RETRY_KEY: str
RETRY_ENABLED_KEY: str
RETRY_MAX_ATTEMPTS_KEY: str
RETRY_BACKOFF_MIN_SECONDS_KEY: str
RETRY_BACKOFF_MAX_SECONDS_KEY: str
RETRYABLE_ERROR_KINDS_KEY: str
CIRCUIT_BREAKER_KEY: str
CIRCUIT_BREAKER_ENABLED_KEY: str
CIRCUIT_BREAKER_FAIL_MAX_KEY: str
CIRCUIT_BREAKER_RESET_TIMEOUT_SECONDS_KEY: str
CIRCUIT_BREAKER_HALF_OPEN_MAX_CALLS_KEY: str
CATEGORY_TIMEOUT: str
CATEGORY_INVALID_TIMEOUT_CONFIG: str
CATEGORY_INVALID_RETRY_CONFIG: str
CATEGORY_INVALID_CIRCUIT_CONFIG: str
CATEGORY_UNAUTHORIZED: str
CATEGORY_FORBIDDEN: str
CATEGORY_RATE_LIMITED: str
CATEGORY_ENDPOINT_UNREACHABLE: str
CATEGORY_UPSTREAM_FAILURE: str
CATEGORY_RETRY_EXHAUSTED: str
CATEGORY_CIRCUIT_OPEN: str
KIND_TIMEOUT: str
KIND_CONNECTION_ERROR: str
KIND_ENDPOINT_UNREACHABLE: str
KIND_UPSTREAM_5XX: str
KIND_RATE_LIMITED: str
KIND_UNAUTHORIZED: str
KIND_FORBIDDEN: str
KIND_UPSTREAM_FAILURE: str
KIND_CIRCUIT_OPEN: str

@dataclass(frozen=True)
class RetryPolicy:
    """Resolved retry policy for one tool invocation."""
    enabled: bool
    max_attempts: int
    backoff_min_seconds: float
    backoff_max_seconds: float
    retryable_error_kinds: tuple[str, ...]

@dataclass(frozen=True)
class CircuitBreakerPolicy:
    """Resolved circuit-breaker policy for one tool invocation."""
    enabled: bool
    fail_max: int
    reset_timeout_seconds: float
    half_open_max_calls: int

@dataclass(frozen=True)
class CircuitBreakerLease:
    """Lease returned by circuit registry before one tool attempt."""
    tool_key: str
    policy: CircuitBreakerPolicy
    state: str
    allowed: bool
    half_open_acquired: bool
    last_error_kind: str | None

@dataclass(frozen=True)
class CircuitBreakerTransition:
    """Circuit breaker transition/result snapshot for metadata emission."""
    tool_key: str
    state: str
    previous_state: str
    transitioned: bool
    consecutive_failures: int
    inflight_half_open_calls: int
    opened_at_unix_seconds: float | None
    last_error_kind: str | None

@dataclass(frozen=True)
class ToolFailureDetail:
    """Classified tool failure detail used for retry and output mapping."""
    category: str
    kind: str
    message: str
    code: str
    http_status: int | None
    is_retryable_default: bool

class ToolResilienceExecutor(BaseResilienceExecutor):
    """Resilience executor for tool invocations.

    This executor keeps timeout validation and timeout-error shaping outside the
    LangGraph agent implementation, so the agent only needs to provide the
    invocation callback.
    """
    def __init__(self, *, circuit_breakers: ToolCircuitBreakerRegistry | None = None) -> None:
        """Initialize executor with optional shared circuit-breaker registry.

        Args:
            circuit_breakers: Optional shared registry instance for circuit state.

        Returns:
            None.
        """
    async def execute(self, request: ResilienceRequest) -> Any:
        """Execute one tool request with timeout and retry handling.

        Args:
            request: Tool resilience request with metadata and invocation callback.

        Returns:
            Tool output or structured resilience error payload.
        """

@dataclass
class _CircuitState:
    """Mutable state container for one circuit key."""
    breaker: CircuitBreaker
    policy: CircuitBreakerPolicy
    inflight_half_open_calls: int = ...
    opened_at_unix_seconds: float | None = ...
    last_error_kind: str | None = ...

@dataclass(frozen=True)
class _TenacityWaitState:
    """Minimal wait state used by tenacity wait strategies."""
    attempt_number: int

class ToolCircuitBreakerRegistry:
    """In-memory registry for per-tool circuit breaker transitions.

    Uses ``pybreaker`` to drive circuit state transitions while preserving
    per-tool metadata snapshots for observability.
    """
    def __init__(self) -> None:
        """Initialize an empty registry.

        Args:
            None.

        Returns:
            None.
        """
    async def acquire(self, *, tool_key: str, policy: CircuitBreakerPolicy) -> CircuitBreakerLease:
        '''Attempt to acquire permission for one tool attempt.

        Args:
            tool_key: Stable circuit identity (for example ``"custom:search"``).
            policy: Resolved per-tool circuit breaker policy.

        Returns:
            CircuitBreakerLease with allow/deny decision and acquisition metadata.
        '''
    async def record_success(self, lease: CircuitBreakerLease) -> CircuitBreakerTransition:
        """Record successful attempt and update breaker state.

        Args:
            lease: Lease returned by ``acquire`` for the completed attempt.

        Returns:
            CircuitBreakerTransition snapshot after state mutation.
        """
    async def record_failure(self, lease: CircuitBreakerLease, *, error_kind: str) -> CircuitBreakerTransition:
        """Record failed attempt and update breaker state.

        Args:
            lease: Lease returned by ``acquire`` for the completed attempt.
            error_kind: Classified failure kind for observability metadata.

        Returns:
            CircuitBreakerTransition snapshot after state mutation.
        """

def resolve_tool_timeout_seconds(metadata: dict[str, Any] | None, *, default_timeout_seconds: float = ...) -> float:
    '''Resolve effective timeout for a tool invocation.

    Args:
        metadata: Optional operation metadata containing resilience overrides.
        default_timeout_seconds: Fallback timeout when metadata has no override.

    Returns:
        Effective timeout in seconds.

    Metadata precedence:
    1) ``metadata["resilience"]["timeout_seconds"]``
    2) ``metadata["timeout_seconds"]``
    3) ``metadata["tool_timeout_seconds"]``
    4) provided default
    '''
def resolve_retry_policy(metadata: dict[str, Any] | None) -> RetryPolicy:
    """Resolve retry policy from tool metadata with defaults and validation.

    Args:
        metadata: Optional operation metadata containing retry configuration.

    Returns:
        Normalized retry policy for the current tool invocation.
    """
def resolve_circuit_breaker_policy(metadata: dict[str, Any] | None) -> CircuitBreakerPolicy:
    """Resolve circuit-breaker policy from tool metadata.

    Args:
        metadata: Optional tool metadata dictionary.

    Returns:
        CircuitBreakerPolicy with validated values and defaults applied.

    Raises:
        ValueError: If the configured policy contains invalid values.
    """
def infer_tool_source(tool: BaseTool | None, metadata: dict[str, Any] | None) -> str:
    """Infer tool source label for diagnostics and metadata.

    Args:
        tool: Tool instance used to infer source from module namespace.
        metadata: Optional metadata that can override source classification.

    Returns:
        Normalized source label (``gl_connector``, ``mcp``, ``custom``, ``unknown``).
    """
def build_timeout_error_output(*, tool_name: str, timeout_seconds: float, tool_source: str) -> dict[str, Any]:
    """Build a structured timeout output for tool execution.

    Args:
        tool_name: Name of the tool that timed out.
        timeout_seconds: Effective timeout budget used by this invocation.
        tool_source: Source classification for the tool.

    Returns:
        Structured timeout payload containing user-facing text and metadata.
    """
def build_invalid_timeout_config_output(*, tool_name: str, tool_source: str, error: str) -> dict[str, Any]:
    """Build a structured invalid-timeout-config output.

    Args:
        tool_name: Name of the tool with invalid timeout config.
        tool_source: Source classification for the tool.
        error: Validation error message describing the invalid value.

    Returns:
        Structured payload describing invalid timeout configuration.
    """
def build_invalid_retry_config_output(*, tool_name: str, tool_source: str, error: str) -> dict[str, Any]:
    """Build a structured invalid-retry-config output.

    Args:
        tool_name: Name of the tool with invalid retry config.
        tool_source: Source classification for the tool.
        error: Validation error message describing the invalid value.

    Returns:
        Structured payload describing invalid retry configuration.
    """
def build_invalid_circuit_breaker_config_output(*, tool_name: str, tool_source: str, error: str) -> dict[str, Any]:
    """Build structured output for invalid circuit-breaker configuration.

    Args:
        tool_name: Tool name from the active tool call.
        tool_source: Source label for the tool.
        error: Validation error message.

    Returns:
        Tool output payload with categorized metadata.
    """
def build_circuit_open_error_output(*, tool_name: str, tool_source: str, reset_timeout_seconds: float, circuit_state: str, failure_kind: str | None) -> dict[str, Any]:
    """Build structured output for circuit-open fail-fast behavior.

    Args:
        tool_name: Tool name from the active tool call.
        tool_source: Source label for the tool.
        reset_timeout_seconds: Cooldown duration before half-open probe.
        circuit_state: Current circuit state label.
        failure_kind: Last known failure kind, when available.

    Returns:
        Tool output payload with circuit-open metadata.
    """
def build_retry_exhausted_error_output(*, tool_name: str, tool_source: str, timeout_seconds: float, attempts_used: int, max_attempts: int, last_failure: ToolFailureDetail, retry_budget_exhausted: bool) -> dict[str, Any]:
    """Build a terminal retry-exhausted output with attempt summary metadata.

    Args:
        tool_name: Name of the tool that exhausted retries.
        tool_source: Source classification for the tool.
        timeout_seconds: Timeout budget enforced for this execution.
        attempts_used: Total attempts consumed.
        max_attempts: Maximum attempts allowed by policy.
        last_failure: Classified failure detail from the final attempt.
        retry_budget_exhausted: Whether timeout budget prevented additional retry.

    Returns:
        Structured payload describing retry exhaustion.
    """
def build_classified_error_output(*, tool_name: str, tool_source: str, attempts_used: int, max_attempts: int, failure: ToolFailureDetail) -> dict[str, Any]:
    """Build structured classified error output for non-retried failures.

    Args:
        tool_name: Name of the tool that failed.
        tool_source: Source classification for the tool.
        attempts_used: Attempts consumed before terminal failure.
        max_attempts: Maximum attempts allowed by policy.
        failure: Classified failure detail to encode in response metadata.

    Returns:
        Structured payload describing the classified terminal failure.
    """
def add_retry_attempt_metadata(tool_output: dict[str, Any], *, attempts_used: int, max_attempts: int, retry_budget_exhausted: bool) -> dict[str, Any]:
    """Attach retry attempt summary to existing tool metadata.

    Args:
        tool_output: Structured tool output dictionary to enrich.
        attempts_used: Total attempts consumed.
        max_attempts: Maximum attempts allowed by policy.
        retry_budget_exhausted: Whether timeout budget prevented additional retry.

    Returns:
        The same tool output dictionary with retry attempt metadata attached.
    """
def add_circuit_breaker_metadata(tool_output: dict[str, Any], *, transition: CircuitBreakerTransition) -> dict[str, Any]:
    """Attach circuit-breaker transition metadata to tool output.

    Args:
        tool_output: Existing tool output payload.
        transition: Circuit transition snapshot for this attempt.

    Returns:
        Tool output payload with merged circuit metadata.
    """
def classify_tool_exception(error: Exception) -> ToolFailureDetail:
    """Classify tool exception into descriptive category and retry metadata.

    Args:
        error: Raised exception from tool execution.

    Returns:
        Classified failure detail used by retry and output mapping logic.
    """
def should_retry_failure(failure: ToolFailureDetail, retry_policy: RetryPolicy) -> bool:
    """Return True when failure is retryable under policy rules.

    Args:
        failure: Classified failure detail for the attempt.
        retry_policy: Resolved retry policy for current invocation.

    Returns:
        ``True`` when the failure should be retried, otherwise ``False``.
    """
def compute_retry_backoff_seconds(attempt_number: int, retry_policy: RetryPolicy) -> float:
    """Compute bounded exponential backoff for the next retry attempt.

    Uses ``tenacity.wait_exponential`` so retry timing logic stays aligned with
    the same strategy used by runtime retry orchestration.

    Args:
        attempt_number: 1-based retry attempt number.
        retry_policy: Resolved retry policy.

    Returns:
        Delay in seconds for the next retry attempt.
    """
