from aip_agents.tools.gl_connector import GLConnectorTool as GLConnectorTool

def main(argv: list[str] | None = None) -> int:
    """Run the smoke test for GL Connectors integration.

    Args:
        argv: Command line arguments. If None, uses sys.argv.

    Returns:
        Exit code (0 for success, non-zero for error).
    """
