from aip_agents.agent import LangGraphReactAgent as LangGraphReactAgent
from aip_agents.schema.agent import A2AClientConfig as A2AClientConfig

async def main() -> None:
    """Demonstrate multi-agent tool output management."""
