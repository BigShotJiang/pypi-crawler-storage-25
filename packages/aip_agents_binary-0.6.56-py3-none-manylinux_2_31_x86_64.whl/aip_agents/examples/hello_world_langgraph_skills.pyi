from aip_agents.agent import LangGraphReactAgent as LangGraphReactAgent

async def langgraph_example() -> None:
    """Demonstrate LangGraphReactAgent with prompt-only skills (Milestone 1)."""
