"""Enrichment modules for supplementing session data from external APIs."""
