"""Cache backend abstraction for day-based API response caching.

Provides a protocol for cache backends and a filesystem implementation
that wraps the original caching logic from cursor_api.py.
"""

from __future__ import annotations

import gzip
import hashlib
import json
import logging
import os
from typing import Protocol, runtime_checkable

logger = logging.getLogger(__name__)


def _jittered_ttl(base_seconds: int, jitter_seconds: int, seed: str) -> int:
    """Return base_seconds with deterministic jitter based on seed.

    Jitter is +-jitter_seconds, derived from a hash of the seed so the same
    key always gets the same offset (re-writes don't shift expiry).
    """
    if jitter_seconds <= 0:
        return base_seconds
    h = hashlib.md5(seed.encode()).hexdigest()
    # Map hash to float in [-1, 1]
    offset_frac = (int(h[:8], 16) / 0xFFFFFFFF) * 2 - 1
    return base_seconds + int(offset_frac * jitter_seconds)


@runtime_checkable
class CacheBackend(Protocol):
    """Protocol for day-based cache backends."""

    def read(self, key: str) -> list[dict] | None:
        """Read cached data for a key.

        Args:
            key: Cache key (e.g. "ab12cd34_2025-01-15")

        Returns:
            Cached list of dicts, or None on miss/error.
        """
        ...

    def write(self, key: str, value: list[dict], ttl_seconds: int = 0) -> None:
        """Write data to cache.

        Args:
            key: Cache key
            value: Data to cache
            ttl_seconds: Time-to-live in seconds (0 = no expiry, backend-dependent)
        """
        ...

    def size_bytes(self) -> int:
        """Return approximate total size of cached data in bytes."""
        ...


class FileCache:
    """Filesystem-based cache backend.

    Stores cached data as gzip-compressed JSON files. Reads both compressed
    (.json.gz) and uncompressed (.json) for backward compatibility.
    TTL is not enforced (files persist until manually cleaned up).
    """

    def __init__(self, cache_dir: str) -> None:
        self._cache_dir = cache_dir
        os.makedirs(self._cache_dir, exist_ok=True)

    def read(self, key: str) -> list[dict] | None:
        # Try compressed first, fall back to uncompressed
        gz_path = os.path.join(self._cache_dir, f"{key}.json.gz")
        if os.path.exists(gz_path):
            try:
                with gzip.open(gz_path, "rt", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError):
                return None

        plain_path = os.path.join(self._cache_dir, f"{key}.json")
        if os.path.exists(plain_path):
            try:
                with open(plain_path) as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError):
                return None

        return None

    def write(self, key: str, value: list[dict], ttl_seconds: int = 0) -> None:
        gz_path = os.path.join(self._cache_dir, f"{key}.json.gz")
        try:
            with gzip.open(gz_path, "wt", encoding="utf-8") as f:
                json.dump(value, f)
        except OSError:
            pass

    def clear(self) -> int:
        """Remove all cache files (.json and .json.gz). Returns count deleted."""
        count = 0
        try:
            for entry in os.scandir(self._cache_dir):
                if entry.is_file() and (
                    entry.name.endswith(".json") or entry.name.endswith(".json.gz")
                ):
                    os.remove(entry.path)
                    count += 1
        except OSError:
            pass
        return count

    def size_bytes(self) -> int:
        """Sum file sizes in the cache directory."""
        total = 0
        try:
            for entry in os.scandir(self._cache_dir):
                if entry.is_file() and (
                    entry.name.endswith(".json") or entry.name.endswith(".json.gz")
                ):
                    total += entry.stat().st_size
        except OSError:
            pass
        return total


def make_cache_key(api_key: str, date_str: str) -> str:
    """Build a cache key from an API key and date string.

    Args:
        api_key: API key (hashed for privacy)
        date_str: ISO date string (e.g. "2025-01-15")

    Returns:
        Cache key like "ab12cd34_2025-01-15"
    """
    key_hash = hashlib.sha256(api_key.encode()).hexdigest()[:8]
    return f"{key_hash}_{date_str}"
