"""Session discovery and source entry reading for agent session files.

This module provides functions to discover session files from various AI coding
agents (Claude, Codex, Cursor, Gemini) and read their raw source entries.

The discovery logic scans well-known paths for each agent type and returns
session metadata including path, format, ID, and modification time.

Example usage:
    from agentstream.discovery import discover_all_sessions, read_source_entries

    # Discover sessions in a project directory
    sessions = discover_all_sessions(Path.cwd())

    # Read source entries from a session
    for session in sessions:
        entries = read_source_entries(session)
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import platform
import re
import sqlite3
from datetime import UTC, datetime
from pathlib import Path

from agentstream.adapters import get_adapter
from agentstream.adapters.base import Session

logger = logging.getLogger(__name__)

# Max entries to read when extracting model
MAX_ENTRIES_FOR_MODEL = 50


def discover_all_sessions(search_path: Path, since_ts: float | None = None) -> list[dict]:
    """Discover all agent sessions from all supported formats.

    Scans well-known paths for Claude, Codex, Cursor, Gemini, and OpenCode session files.
    Sessions are filtered by search_path - only sessions whose working directory
    matches or is a parent/child of search_path are returned.

    Args:
        search_path: Root directory to search for sessions. Use Path.home() to
            find all sessions regardless of project.
        since_ts: Optional Unix timestamp. Only return sessions modified after
            this time.

    Returns:
        List of session dicts with keys:
        - 'path': Path to session file
        - 'format': Agent type ('claude', 'codex', 'cursor', 'gemini', 'opencode')
        - 'id': Session identifier
        - 'modified_at': Unix timestamp of last modification
        - 'metadata': Dict with agent-specific metadata (cwd, model, etc.)
    """
    sessions = []

    # Discover Claude sessions
    sessions.extend(_discover_claude_sessions(search_path))

    # Discover Codex sessions
    sessions.extend(_discover_codex_sessions(search_path))

    # Discover Cursor sessions
    sessions.extend(_discover_cursor_sessions(search_path))

    # Discover Gemini sessions
    sessions.extend(_discover_gemini_sessions(search_path))

    # Discover OpenCode sessions
    sessions.extend(_discover_opencode_sessions(search_path))

    # Filter by timestamp
    if since_ts is not None:
        sessions = [s for s in sessions if s["modified_at"] >= since_ts]

    # Sort by modification time (newest first)
    sessions.sort(key=lambda s: s["modified_at"], reverse=True)

    return sessions


def _session_dict_to_obj(session: dict) -> Session:
    """Convert a session dict to a Session object for adapter methods."""
    return Session(
        id=session["id"],
        path=session["path"],
        format=session["format"],
        modified_at=session["modified_at"],
        metadata=session.get("metadata"),
    )


def read_source_entries(session: dict) -> list[dict]:
    """Read raw source entries from a session file.

    Reads the session file and returns individual entries in a normalized format
    suitable for server-side processing.

    Args:
        session: Session dict from discover_all_sessions() with 'path', 'format',
            'id' keys.

    Returns:
        List of source entry dicts with keys:
        - 'entry_index': Integer index of this entry
        - 'entry_content': Raw JSON string of the entry
        - 'entry_timestamp_ms': Unix timestamp in milliseconds
    """
    session_format = session["format"]

    adapter = get_adapter(session_format)
    if not adapter:
        logger.warning(f"No adapter registered for format: {session_format}")
        return []

    session_obj = _session_dict_to_obj(session)
    return adapter.read_entries(session_obj)


# ---------------------------------------------------------------------------
# Session discovery functions
# ---------------------------------------------------------------------------


def _discover_claude_sessions(search_path: Path) -> list[dict]:
    """Discover Claude sessions from ~/.claude/projects/."""
    sessions = []
    claude_base = Path.home() / ".claude" / "projects"

    if not claude_base.exists():
        logger.debug(f"Claude projects directory does not exist: {claude_base}")
        return sessions

    # If searching from home, get all sessions
    # Otherwise, only get sessions from the specific project
    search_resolved = search_path.resolve()
    is_home_search = search_resolved == Path.home()

    logger.debug(
        f"Searching Claude sessions for path: {search_resolved} (is_home_search={is_home_search})"
    )

    project_count = 0
    for project_dir in claude_base.iterdir():
        if not project_dir.is_dir():
            continue

        project_count += 1

        # Convert Claude's project dir name back to path
        # e.g., -Users-vanpelt-Development-foo -> /Users/vanpelt/Development/foo
        # Note: Can't replace all "-" with "/" because dir names may contain dashes!
        #
        # Strategy: Read JSONL files to get the actual cwd
        # Some files may only have file-history-snapshot or summary entries, so try
        # multiple files and scan first 20 lines of each
        project_path = None
        jsonl_files = list(project_dir.glob("*.jsonl"))
        if not jsonl_files:
            logger.debug(f"No JSONL files found in {project_dir.name}")
            continue

        for jsonl_file in jsonl_files[:5]:  # Try up to 5 files
            if not jsonl_file.is_file():
                continue
            try:
                with open(jsonl_file, encoding="utf-8", errors="replace") as f:
                    for _ in range(20):  # Scan first 20 lines
                        line = f.readline()
                        if not line:
                            break
                        try:
                            entry = json.loads(line)
                            cwd = entry.get("cwd")
                            if cwd:
                                project_path = Path(cwd)
                                break
                        except json.JSONDecodeError:
                            continue
                if project_path:
                    break
            except OSError:
                continue

        if project_path is None:
            # Fallback: try naive replacement (may fail for paths with dashes)
            logger.debug(f"No cwd found in {project_dir.name}, using fallback")
            project_path_str = project_dir.name.replace("-", "/")
            if not project_path_str.startswith("/"):
                project_path_str = "/" + project_path_str
            project_path = Path(project_path_str)

        # Check if this project matches our search path
        if not is_home_search:
            # Skip if this project doesn't match our search path
            try:
                matches = (
                    project_path == search_resolved
                    or search_resolved in project_path.parents
                    or project_path in search_resolved.parents
                )
                if not matches:
                    logger.debug(
                        f"Skipping Claude project {project_dir.name}: path mismatch "
                        f"({project_path} vs {search_resolved})"
                    )
                    continue
                else:
                    logger.debug(f"Matched Claude project {project_dir.name}: {project_path}")
            except (ValueError, OSError) as e:
                logger.debug(f"Skipping Claude project {project_dir.name}: {e}")
                continue

        # Delegate file discovery to the Claude adapter (handles flat +
        # nested sub-agent files in a single place).
        adapter = get_adapter("claude")
        discovered = adapter.discover_sessions(project_path) if adapter else []
        logger.debug(f"Found {len(discovered)} session files in {project_dir.name}")

        for s in discovered:
            model = _extract_model_from_jsonl(s.path, "claude")
            sessions.append(
                {
                    "path": s.path,
                    "format": "claude",
                    "id": s.id,
                    "modified_at": s.modified_at,
                    "metadata": {
                        "cwd": str(project_path),
                        "model": model,
                        **(s.metadata or {}),
                    },
                }
            )

    logger.debug(
        f"Scanned {project_count} Claude project directories, found {len(sessions)} sessions"
    )
    return sessions


def _discover_codex_sessions(search_path: Path) -> list[dict]:
    """Discover Codex sessions from ~/.codex/sessions/."""
    sessions = []
    codex_base = Path.home() / ".codex" / "sessions"

    if not codex_base.exists():
        return sessions

    search_resolved = search_path.resolve()
    is_home_search = search_resolved == Path.home()

    # Walk all JSONL files in the sessions directory
    for session_file in codex_base.rglob("*.jsonl"):
        if not session_file.is_file():
            continue

        # Read first line to get session metadata
        try:
            with open(session_file) as f:
                first_line = f.readline()
                if not first_line:
                    continue

                data = json.loads(first_line)
                if data.get("type") != "session_meta":
                    continue

                # Codex stores cwd in payload
                payload = data.get("payload", {})
                cwd = payload.get("cwd", "")
                if not cwd:
                    continue

                # Check if this session is in our search path (skip for global search)
                if not is_home_search:
                    session_cwd = Path(cwd)
                    try:
                        if not (
                            session_cwd == search_resolved
                            or search_resolved in session_cwd.parents
                            or session_cwd in search_resolved.parents
                        ):
                            continue
                    except (ValueError, OSError):
                        continue

                # Extract model from session file
                model = _extract_model_from_codex_jsonl(session_file)

                sessions.append(
                    {
                        "path": session_file,
                        "format": "codex",
                        "id": payload.get("id") or session_file.stem,
                        "modified_at": session_file.stat().st_mtime,
                        "metadata": {
                            "cwd": cwd,  # Store cwd from session_meta
                            "model": model,
                        },
                    }
                )

        except (json.JSONDecodeError, OSError) as e:
            logger.debug(f"Skipping codex session {session_file}: {e}")
            continue

    return sessions


def _discover_cursor_sessions(search_path: Path) -> list[dict]:
    """Discover Cursor composer sessions from workspace storage.

    Each composer session within a workspace is returned as a separate session.
    """

    sessions = []
    cursor_user = _get_cursor_user_dir()
    workspace_storage = cursor_user / "workspaceStorage"

    if not workspace_storage.exists():
        return sessions

    search_resolved = search_path.resolve()
    is_home_search = search_resolved == Path.home()

    # Scan all workspace directories
    for workspace_dir in workspace_storage.iterdir():
        if not workspace_dir.is_dir():
            continue

        # Check workspace.json to see if it matches our search path
        workspace_json = workspace_dir / "workspace.json"
        if not workspace_json.is_file():
            continue

        try:
            with open(workspace_json) as f:
                workspace_data = json.load(f)
                folder = workspace_data.get("folder")
                if not folder:
                    continue

                # Parse folder URI (e.g., "file:///Users/foo/bar")
                if folder.startswith("file://"):
                    folder_path = Path(folder[7:])
                else:
                    continue

                # Check if this workspace matches our search path (skip for global search)
                if not is_home_search and not (
                    folder_path == search_resolved
                    or search_resolved in folder_path.parents
                    or folder_path in search_resolved.parents
                ):
                    continue

        except (json.JSONDecodeError, OSError, ValueError) as e:
            logger.debug(f"Skipping cursor workspace {workspace_dir.name}: {e}")
            continue

        # Extract composer sessions from workspace
        state_db = workspace_dir / "state.vscdb"
        if state_db.is_file():
            try:
                conn = sqlite3.connect(f"file:{state_db}?mode=ro", uri=True, timeout=10)
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()

                # Query for composer.composerData from ItemTable
                cursor.execute(
                    "SELECT value FROM ItemTable WHERE key = ?",
                    ("composer.composerData",),
                )
                row = cursor.fetchone()
                conn.close()

                if not row:
                    continue

                # Parse composer data
                try:
                    # Handle both string and bytes from SQLite
                    value = row["value"]
                    if isinstance(value, bytes):
                        value = value.decode("utf-8", errors="replace")
                    composer_data = json.loads(value)
                except (json.JSONDecodeError, UnicodeDecodeError) as e:
                    logger.debug(f"Failed to parse composer data: {e}")
                    continue

                if isinstance(composer_data, dict):
                    composer_data = composer_data.get("allComposers", [])
                if not isinstance(composer_data, list):
                    continue

                # Each composer is a separate session
                for composer in composer_data:
                    if not isinstance(composer, dict):
                        continue

                    composer_id = composer.get("composerId")
                    if not composer_id:
                        continue

                    # Get modification time
                    modified_at = composer.get("lastUpdatedAt") or composer.get("createdAt", 0)
                    # Cursor stores timestamps in milliseconds
                    if isinstance(modified_at, (int, float)) and modified_at > 1e12:
                        modified_at = modified_at / 1000.0
                    elif not isinstance(modified_at, (int, float)):
                        modified_at = state_db.stat().st_mtime

                    # Extract model from composer data (defaultModel or model field)
                    model = composer.get("defaultModel") or composer.get("model")

                    sessions.append(
                        {
                            "path": state_db,
                            "format": "cursor",
                            "id": composer_id,
                            "modified_at": float(modified_at),
                            "metadata": {
                                "composerId": composer_id,
                                "workspace_dir": str(workspace_dir),
                                "cursor_user": str(cursor_user),
                                "folder_path": str(folder_path),
                                "model": model,  # Store model from composer
                            },
                        }
                    )

            except (sqlite3.Error, json.JSONDecodeError, OSError) as e:
                logger.debug(f"Error reading cursor state.vscdb in {workspace_dir.name}: {e}")
                continue

    return sessions


def _build_gemini_dir_to_path_map() -> dict[str, str]:
    """Build a mapping from Gemini tmp directory names to real project paths.

    Reads ~/.gemini/projects.json which maps real paths to project names.
    Gemini uses two directory naming schemes:
    - Named directories: the project name value (e.g., "agentstream-py")
    - Hash directories: SHA256 of the real path (64-char hex string)

    Returns:
        Dict mapping directory name -> real path string.
        Empty dict if projects.json is missing or invalid.
    """
    projects_json = Path.home() / ".gemini" / "projects.json"
    if not projects_json.is_file():
        return {}

    try:
        with open(projects_json) as f:
            data = json.load(f)
        projects = data.get("projects", {})
        if not isinstance(projects, dict):
            return {}
        result: dict[str, str] = {}
        for path, name in projects.items():
            # Map both the project name and SHA256 hash to the real path
            if name:
                result[name] = path
            result[hashlib.sha256(path.encode()).hexdigest()] = path
        return result
    except (json.JSONDecodeError, OSError) as e:
        logger.debug(f"Failed to read Gemini projects.json: {e}")
        return {}


def _discover_gemini_sessions(search_path: Path) -> list[dict]:
    """Discover Gemini sessions from ~/.gemini/tmp/."""
    sessions = []
    gemini_base = Path.home() / ".gemini" / "tmp"

    if not gemini_base.exists():
        return sessions

    search_resolved = search_path.resolve()
    is_home_search = search_resolved == Path.home()

    def _collect_from_chats_dir(chats_dir: Path, project_path: str) -> None:
        """Helper to collect sessions from a chats directory."""
        for chat_file in chats_dir.glob("*.json"):
            if chat_file.is_file():
                # Extract model from Gemini JSON
                model = _extract_model_from_gemini_json(chat_file)

                sessions.append(
                    {
                        "path": chat_file,
                        "format": "gemini",
                        "id": chat_file.stem,
                        "modified_at": chat_file.stat().st_mtime,
                        "metadata": {
                            "cwd": project_path,  # Store the project path
                            "model": model,
                        },
                    }
                )

    if is_home_search:
        # Global mode: scan all project hash directories
        # Use projects.json to resolve dir names (both named and hash) to real paths
        dir_to_path = _build_gemini_dir_to_path_map()
        for project_dir in gemini_base.iterdir():
            if not project_dir.is_dir():
                continue
            chats_dir = project_dir / "chats"
            if chats_dir.exists():
                real_path = dir_to_path.get(project_dir.name)
                cwd = real_path if real_path else f"[hash:{project_dir.name[:8]}...]"
                _collect_from_chats_dir(chats_dir, cwd)
    else:
        # Project-specific mode: check both hash directory and named directory
        project_hash = hashlib.sha256(str(search_resolved).encode()).hexdigest()
        chats_dir = gemini_base / project_hash / "chats"
        if chats_dir.exists():
            _collect_from_chats_dir(chats_dir, str(search_resolved))

        # Also check named directory (Gemini may use project name from projects.json)
        projects_json = Path.home() / ".gemini" / "projects.json"
        if projects_json.is_file():
            try:
                with open(projects_json) as f:
                    projects = json.load(f).get("projects", {})
                project_name = projects.get(str(search_resolved))
                if project_name:
                    named_chats = gemini_base / project_name / "chats"
                    if named_chats.exists() and named_chats != chats_dir:
                        _collect_from_chats_dir(named_chats, str(search_resolved))
            except (json.JSONDecodeError, OSError):
                pass

    return sessions


def _discover_opencode_sessions(search_path: Path) -> list[dict]:
    """Discover OpenCode sessions from XDG data directory.

    Checks SQLite DB first (opencode.db), falls back to file-based storage.
    """

    sessions: list[dict] = []

    # Get OpenCode data directory based on platform
    system = platform.system()
    if system == "Windows":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))

    data_dir = base / "opencode"
    db_path = data_dir / "opencode.db"

    # Try SQLite first
    if db_path.exists():
        sessions = _discover_opencode_sessions_sqlite(db_path, search_path)
        if sessions:
            return sessions

    storage_dir = data_dir / "storage"
    session_dir = storage_dir / "session"
    project_dir = storage_dir / "project"

    if not session_dir.exists():
        logger.debug(f"OpenCode session directory does not exist: {session_dir}")
        return sessions

    search_resolved = search_path.resolve()
    is_home_search = search_resolved == Path.home()

    # Build mapping of project IDs to their worktrees
    project_worktrees: dict[str, Path] = {}
    if project_dir.exists():
        for proj_file in project_dir.glob("*.json"):
            try:
                with open(proj_file) as f:
                    proj_data = json.load(f)
                    if "worktree" in proj_data:
                        proj_id = proj_data.get("id", proj_file.stem)
                        project_worktrees[proj_id] = Path(proj_data["worktree"])
            except (json.JSONDecodeError, OSError):
                continue

    # Scan all project directories in sessions
    for proj_subdir in session_dir.iterdir():
        if not proj_subdir.is_dir():
            continue

        project_id = proj_subdir.name
        worktree = project_worktrees.get(project_id)

        # Skip if searching a specific project and this doesn't match
        if not is_home_search and worktree:
            try:
                worktree_resolved = worktree.resolve()
                matches = (
                    worktree_resolved == search_resolved
                    or search_resolved in worktree_resolved.parents
                    or worktree_resolved in search_resolved.parents
                )
                if not matches:
                    logger.debug(
                        f"Skipping OpenCode project {project_id}: path mismatch "
                        f"({worktree} vs {search_resolved})"
                    )
                    continue
            except (ValueError, OSError) as e:
                logger.debug(f"Skipping OpenCode project {project_id}: {e}")
                continue

        # Find all session files in this project
        for session_file in proj_subdir.glob("*.json"):
            try:
                with open(session_file) as f:
                    session_data = json.load(f)
            except (json.JSONDecodeError, OSError):
                continue

            session_id = session_data.get("id", session_file.stem)

            # Get modification time
            time_data = session_data.get("time", {})
            modified_at = time_data.get("updated") or time_data.get("created", 0)
            # OpenCode timestamps are in milliseconds
            if isinstance(modified_at, int) and modified_at > 1e12:
                modified_at = modified_at / 1000.0
            elif not isinstance(modified_at, (int, float)) or modified_at == 0:
                modified_at = session_file.stat().st_mtime

            # Extract model from message entries
            model = _extract_model_from_opencode_session(storage_dir, session_id)

            # Determine cwd
            cwd = str(worktree) if worktree else session_data.get("directory")

            sessions.append(
                {
                    "path": session_file,
                    "format": "opencode",
                    "id": session_id,
                    "modified_at": float(modified_at),
                    "metadata": {
                        "cwd": cwd,
                        "projectID": project_id,
                        "title": session_data.get("title"),
                        "version": session_data.get("version"),
                        "model": model,
                    },
                }
            )

    logger.debug(f"Found {len(sessions)} OpenCode sessions")
    return sessions


def _discover_opencode_sessions_sqlite(db_path: Path, search_path: Path) -> list[dict]:
    """Discover OpenCode sessions from SQLite database."""

    sessions: list[dict] = []
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=10)
        conn.row_factory = sqlite3.Row
    except sqlite3.Error:
        return sessions

    try:
        search_resolved = search_path.resolve()
        is_home_search = search_resolved == Path.home()

        rows = conn.execute(
            "SELECT s.id, s.project_id, s.directory, s.title, s.version, "
            "s.time_created, s.time_updated, p.worktree "
            "FROM session s LEFT JOIN project p ON s.project_id = p.id "
            "ORDER BY s.time_updated DESC"
        ).fetchall()

        for row in rows:
            worktree = Path(row["worktree"]) if row["worktree"] else None

            # Filter by search_path
            if not is_home_search and worktree:
                try:
                    wt_resolved = worktree.resolve()
                    matches = (
                        wt_resolved == search_resolved
                        or search_resolved in wt_resolved.parents
                        or wt_resolved in search_resolved.parents
                    )
                    if not matches:
                        continue
                except (ValueError, OSError):
                    continue

            session_id = row["id"]
            modified_at = row["time_updated"] or row["time_created"] or 0
            if isinstance(modified_at, int) and modified_at > 1e12:
                modified_at = modified_at / 1000.0
            elif not isinstance(modified_at, (int, float)) or modified_at == 0:
                modified_at = db_path.stat().st_mtime

            model = _extract_model_from_opencode_sqlite(conn, session_id)
            cwd = str(worktree) if worktree else row["directory"]

            sessions.append(
                {
                    "path": db_path,
                    "format": "opencode",
                    "id": session_id,
                    "modified_at": float(modified_at),
                    "metadata": {
                        "cwd": cwd,
                        "projectID": row["project_id"],
                        "title": row["title"],
                        "version": row["version"],
                        "model": model,
                    },
                }
            )
    except sqlite3.Error:
        pass
    finally:
        conn.close()

    logger.debug(f"Found {len(sessions)} OpenCode sessions from SQLite")
    return sessions


def _extract_model_from_opencode_sqlite(conn, session_id: str) -> str | None:
    """Extract model from OpenCode SQLite message data."""
    try:
        rows = conn.execute(
            "SELECT data FROM message WHERE session_id = ? ORDER BY time_created LIMIT ?",
            (session_id, MAX_ENTRIES_FOR_MODEL),
        ).fetchall()
    except Exception:
        return None

    for row in rows:
        try:
            import json as _json  # noqa: PLC0415

            msg_data = _json.loads(row["data"]) if isinstance(row["data"], str) else row["data"]
            if not isinstance(msg_data, dict):
                continue

            if msg_data.get("role") == "assistant":
                model_id = msg_data.get("modelID")
                provider_id = msg_data.get("providerID")
                if model_id:
                    return f"{provider_id}/{model_id}" if provider_id else model_id

            if msg_data.get("role") == "user":
                model_info = msg_data.get("model", {})
                if model_info:
                    model_id = model_info.get("modelID", "")
                    provider_id = model_info.get("providerID", "")
                    if model_id:
                        return f"{provider_id}/{model_id}" if provider_id else model_id
        except (json.JSONDecodeError, TypeError):
            continue

    return None


def _extract_model_from_opencode_session(storage_dir: Path, session_id: str) -> str | None:
    """Extract model from OpenCode session messages.

    Args:
        storage_dir: Path to OpenCode storage directory
        session_id: Session ID to look up messages for

    Returns:
        Model string (provider/model) if found, None otherwise
    """
    messages_dir = storage_dir / "message" / session_id
    if not messages_dir.exists():
        return None

    # Look through message files for model info
    for msg_file in sorted(messages_dir.glob("*.json"))[:MAX_ENTRIES_FOR_MODEL]:
        try:
            with open(msg_file) as f:
                msg_data = json.load(f)

            # Assistant messages have modelID and providerID
            if msg_data.get("role") == "assistant":
                model_id = msg_data.get("modelID")
                provider_id = msg_data.get("providerID")
                if model_id:
                    if provider_id:
                        return f"{provider_id}/{model_id}"
                    return model_id

            # User messages may have model info
            if msg_data.get("role") == "user":
                model_info = msg_data.get("model", {})
                if model_info:
                    provider_id = model_info.get("providerID", "")
                    model_id = model_info.get("modelID", "")
                    if model_id:
                        if provider_id:
                            return f"{provider_id}/{model_id}"
                        return model_id

        except (json.JSONDecodeError, OSError):
            continue

    return None


def _get_cursor_user_dir() -> Path:
    """Get Cursor user directory based on platform."""

    system = platform.system()

    if system == "Darwin":  # macOS
        return Path.home() / "Library" / "Application Support" / "Cursor" / "User"
    elif system == "Linux":
        return Path.home() / ".config" / "Cursor" / "User"
    elif system == "Windows":
        return Path.home() / "AppData" / "Roaming" / "Cursor" / "User"
    else:
        return Path.home() / ".cursor"


# ---------------------------------------------------------------------------
# Source entry reading functions
# ---------------------------------------------------------------------------


def _read_claude_entries(session_path: Path) -> list[dict]:
    """Read Claude JSONL entries.

    Strips 'normalizedMessages' from progress events to reduce payload size.
    Progress events can embed the full conversation history (800KB+ each),
    which is redundant since we reconstruct from actual message events.
    """
    entries = []

    with open(session_path) as f:
        for i, line in enumerate(f):
            try:
                # Parse to extract timestamp and optionally strip bloat
                entry = json.loads(line)
                timestamp_ms = _extract_timestamp_claude(entry)

                # Strip normalizedMessages from progress events (saves ~98% of payload size)
                # These embed full conversation history redundantly in every progress update
                modified = False
                if entry.get("type") == "progress" and "data" in entry:
                    data = entry["data"]
                    if isinstance(data, dict) and "normalizedMessages" in data:
                        del data["normalizedMessages"]
                        modified = True

                # Use modified JSON if we stripped data, otherwise use raw line
                content = (
                    json.dumps(entry, separators=(",", ":")) if modified else line.rstrip("\n")
                )

                entries.append(
                    {
                        "entry_index": i,
                        "entry_content": content,
                        "entry_timestamp_ms": timestamp_ms,
                    }
                )
            except json.JSONDecodeError:
                # Skip invalid lines
                continue

    return entries


def _read_codex_entries(session_path: Path) -> list[dict]:
    """Read Codex JSONL entries."""
    entries = []

    with open(session_path) as f:
        for i, line in enumerate(f):
            try:
                # Parse to extract timestamp
                entry = json.loads(line)
                timestamp_ms = _extract_timestamp_codex(entry)

                entries.append(
                    {
                        "entry_index": i,
                        "entry_content": line.rstrip("\n"),  # Raw JSON string
                        "entry_timestamp_ms": timestamp_ms,
                    }
                )
            except json.JSONDecodeError:
                # Skip invalid lines
                continue

    return entries


def _read_cursor_entries(session: dict) -> list[dict]:
    """Read individual bubble entries from Cursor composer session.

    Queries the global state database for bubbles belonging to this composer.
    Each bubble is returned as a separate source entry.
    """

    entries = []

    # Get composer ID and cursor_user from session metadata
    metadata = session.get("metadata", {})
    composer_id = metadata.get("composerId")
    cursor_user_str = metadata.get("cursor_user")

    if not composer_id or not cursor_user_str:
        logger.warning(f"Missing composerId or cursor_user in session metadata: {session}")
        return entries

    # Get global state database
    cursor_user = Path(cursor_user_str)
    global_state_db = cursor_user / "globalStorage" / "state.vscdb"

    if not global_state_db.exists():
        logger.warning(f"Global state database not found: {global_state_db}")
        return entries

    try:
        conn = sqlite3.connect(f"file:{global_state_db}?mode=ro", uri=True, timeout=10)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        # Query for bubbleId entries matching this composer
        # Keys are like: bubbleId:<composerId>:<bubbleId>
        prefix = f"bubbleId:{composer_id}:"
        cursor.execute(
            "SELECT key, value FROM cursorDiskKV WHERE key LIKE ?",
            (f"{prefix}%",),
        )

        bubbles = []
        for row in cursor.fetchall():
            try:
                bubble_data = json.loads(row["value"])
                if isinstance(bubble_data, dict):
                    bubbles.append(bubble_data)
            except json.JSONDecodeError:
                continue

        conn.close()

        # Sort bubbles by createdAt for chronological ordering
        # (bubbleId is random UUID, would break incremental sync)
        bubbles.sort(key=lambda b: b.get("createdAt", "") or "")

        # Convert each bubble to a source entry
        for i, bubble in enumerate(bubbles):
            # Extract timestamp from bubble
            timestamp_ms = _extract_timestamp_cursor(bubble)

            entries.append(
                {
                    "entry_index": i,
                    "entry_content": json.dumps(bubble),
                    "entry_timestamp_ms": timestamp_ms,
                }
            )

    except (sqlite3.Error, OSError) as e:
        logger.error(f"Error reading Cursor bubbles: {e}")

    return entries


def _read_gemini_entries(session: dict) -> list[dict]:
    """Read individual message entries from Gemini JSON file.

    Parses the JSON file and extracts individual messages.
    Each message is returned as a separate source entry.
    """
    entries = []
    session_path = session["path"]

    try:
        with open(session_path) as f:
            data = json.load(f)

        # Get messages array from session
        messages = data.get("messages", [])
        if not isinstance(messages, list):
            logger.warning(f"No messages array in Gemini session: {session_path}")
            return entries

        # Convert each message to a source entry
        for i, message in enumerate(messages):
            if not isinstance(message, dict):
                continue

            # Extract timestamp from message
            timestamp_ms = _extract_timestamp_gemini(message)

            entries.append(
                {
                    "entry_index": i,
                    "entry_content": json.dumps(message),
                    "entry_timestamp_ms": timestamp_ms,
                }
            )

    except (json.JSONDecodeError, OSError) as e:
        logger.error(f"Error reading Gemini messages from {session_path}: {e}")

    return entries


# ---------------------------------------------------------------------------
# Model extraction functions
# ---------------------------------------------------------------------------


def _extract_model_from_jsonl(
    session_path: Path,
    agent_type: str,
) -> str | None:
    """Extract model from JSONL source entries (Claude).

    Reads up to MAX_ENTRIES_FOR_MODEL entries looking for model information.

    Args:
        session_path: Path to JSONL file
        agent_type: "claude"

    Returns:
        Model string if found, None otherwise
    """
    try:
        with open(session_path) as f:
            for i, line in enumerate(f):
                if i >= MAX_ENTRIES_FOR_MODEL:
                    break
                try:
                    entry = json.loads(line)

                    # Claude: assistant messages have message.model
                    if agent_type == "claude" and entry.get("type") == "assistant":
                        model = entry.get("message", {}).get("model")
                        if model:
                            return model

                except json.JSONDecodeError:
                    continue
    except OSError as e:
        logger.debug(f"Failed to read model from {session_path}: {e}")

    return None


def _extract_model_from_gemini_json(session_path: Path) -> str | None:
    """Extract model from Gemini JSON session file.

    Args:
        session_path: Path to Gemini JSON file

    Returns:
        Model string if found, None otherwise
    """
    try:
        with open(session_path) as f:
            data = json.load(f)

        messages = data.get("messages", [])
        for message in messages[:MAX_ENTRIES_FOR_MODEL]:
            if not isinstance(message, dict):
                continue
            # Gemini: gemini type entries have model at top level
            if message.get("type") == "gemini":
                model = message.get("model")
                if model:
                    return model
    except (json.JSONDecodeError, OSError) as e:
        logger.debug(f"Failed to read model from Gemini file {session_path}: {e}")

    return None


def _extract_model_from_codex_jsonl(session_path: Path) -> str | None:
    """Extract model from Codex JSONL session file.

    Codex stores model in the session_meta entry's payload.
    Falls back to model_provider if model is not set.

    Args:
        session_path: Path to Codex JSONL file

    Returns:
        Model string if found, None otherwise
    """
    try:
        with open(session_path) as f:
            for i, line in enumerate(f):
                if i >= MAX_ENTRIES_FOR_MODEL:
                    break
                try:
                    entry = json.loads(line)

                    # Codex: session_meta has payload.model or payload.model_provider
                    if entry.get("type") == "session_meta":
                        payload = entry.get("payload", {})
                        model = payload.get("model")
                        if model:
                            return model
                        # Fall back to model_provider (e.g., "openai", "anthropic")
                        model_provider = payload.get("model_provider")
                        if model_provider:
                            return model_provider

                except json.JSONDecodeError:
                    continue
    except OSError as e:
        logger.debug(f"Failed to read model from Codex file {session_path}: {e}")

    return None


def extract_model(session_path: Path, agent_type: str) -> str | None:
    """Extract model from a session file.

    Public API for model extraction that handles all agent types.
    Used by the daemon to extract model before syncing.

    Args:
        session_path: Path to session file
        agent_type: Agent type ('claude', 'codex', 'cursor', 'gemini')

    Returns:
        Model string if found, None otherwise
    """
    if agent_type == "claude":
        return _extract_model_from_jsonl(session_path, agent_type)
    elif agent_type == "codex":
        return _extract_model_from_codex_jsonl(session_path)
    elif agent_type == "gemini":
        return _extract_model_from_gemini_json(session_path)
    elif agent_type == "cursor":
        # Cursor doesn't have model in session files - it's in the API response
        return None
    else:
        return None


# ---------------------------------------------------------------------------
# Timestamp extraction functions
# ---------------------------------------------------------------------------


def _extract_timestamp_claude(entry: dict) -> int:
    """Extract timestamp from Claude log entry."""
    # Claude logs have 'timestamp' field in ISO format
    ts_str = entry.get("timestamp")
    if ts_str:
        try:
            dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
            return int(dt.timestamp() * 1000)
        except (ValueError, AttributeError):
            pass

    # Fallback to current time
    return int(datetime.now(UTC).timestamp() * 1000)


def _extract_timestamp_codex(entry: dict) -> int:
    """Extract timestamp from Codex log entry."""
    # Codex logs have 'timestamp' field in ISO format
    ts_str = entry.get("timestamp")
    if ts_str:
        try:
            dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
            return int(dt.timestamp() * 1000)
        except (ValueError, AttributeError):
            pass

    # Fallback to current time
    return int(datetime.now(UTC).timestamp() * 1000)


def _extract_timestamp_cursor(entry: dict) -> int:
    """Extract timestamp from Cursor bubble entry."""
    # Try different timestamp fields
    for field in ["timestamp", "createdAt", "lastUpdatedAt"]:
        ts = entry.get(field)
        if ts:
            # Handle ISO 8601 strings (e.g., "2026-01-11T19:49:31.405Z")
            if isinstance(ts, str):
                try:
                    dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                    return int(dt.timestamp() * 1000)
                except (ValueError, TypeError):
                    pass
                # Try parsing as numeric string
                try:
                    ts = float(ts)
                except (ValueError, TypeError):
                    continue

            # Handle numeric timestamps
            if isinstance(ts, (int, float)):
                ts_int = int(ts)
                # Sanity check: if it looks like seconds (< 1e12), convert to ms
                if ts_int < 1e12:
                    ts_int = ts_int * 1000
                return ts_int

    # Fallback to current time
    return int(datetime.now(UTC).timestamp() * 1000)


def _extract_timestamp_gemini(entry: dict) -> int:
    """Extract timestamp from Gemini message entry."""
    # Gemini messages have 'timestamp' field in ISO format
    ts_str = entry.get("timestamp")
    if ts_str:
        try:
            dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
            return int(dt.timestamp() * 1000)
        except (ValueError, AttributeError):
            pass

    # Fallback to current time
    return int(datetime.now(UTC).timestamp() * 1000)


# =============================================================================
# CWD Resolution Functions
# =============================================================================
#
# These functions resolve the working directory (cwd) for sessions after discovery.
# Discovery may set placeholder values (e.g., "[hash:abc...]" for Gemini global mode)
# that need to be resolved by reading actual file paths from session content.


def get_session_cwd(session: dict) -> Path | None:
    """Get working directory for a session.

    Resolves the cwd from session metadata, handling placeholder values like
    "[hash:abc...]" that are set during discovery for Gemini global mode.

    Args:
        session: Session dict with 'path', 'format', and 'metadata' keys
            (as returned by discover_all_sessions).

    Returns:
        Path to working directory, or None if not found.
    """
    session_path = session["path"]
    session_format = session["format"]

    # Check metadata first (populated during discovery)
    metadata = session.get("metadata", {})
    cwd_str = metadata.get("cwd")

    # For Gemini global mode, cwd may be a placeholder hash like "[hash:abc123...]"
    # In that case, extract cwd from the session file's tool call paths
    if cwd_str and cwd_str.startswith("[hash:"):
        extracted_cwd = extract_cwd_from_file(session_path, session_format)
        if extracted_cwd:
            return extracted_cwd
        # Fall through to return None if extraction fails

    elif cwd_str:
        return Path(cwd_str)

    # Fallback: format-specific parsing (for backwards compatibility)
    if session_format == "claude":
        # For Claude, read cwd from session file (directory name is not reversible
        # because "/" is replaced with "-" but paths may contain "-")
        extracted = extract_cwd_from_file(session_path, session_format)
        if extracted:
            return extracted
        # Last resort: naive replacement (may be wrong for paths with dashes)
        project_dir = session_path.parent.name
        cwd_str = project_dir.replace("-", "/")
        if not cwd_str.startswith("/"):
            cwd_str = "/" + cwd_str
        return Path(cwd_str)

    elif session_format == "codex":
        # For Codex, read cwd from first line (in payload)
        try:
            with open(session_path) as f:
                first_line = f.readline()
                if first_line:
                    data = json.loads(first_line)
                    if data.get("type") == "session_meta":
                        payload = data.get("payload", {})
                        cwd_str = payload.get("cwd")
                        if cwd_str:
                            return Path(cwd_str)
        except (json.JSONDecodeError, OSError) as e:
            logger.debug(f"Failed to read cwd from codex session: {e}")

    elif session_format == "cursor":
        # For Cursor, check folder_path in metadata
        folder_path = metadata.get("folder_path")
        if folder_path:
            return Path(folder_path)

        # Fallback: read from workspace.json
        workspace_dir_str = metadata.get("workspace_dir")
        if workspace_dir_str:
            workspace_dir = Path(workspace_dir_str)
            workspace_json = workspace_dir / "workspace.json"
            if workspace_json.is_file():
                try:
                    with open(workspace_json) as f:
                        workspace_data = json.load(f)
                        folder = workspace_data.get("folder")
                        if folder and folder.startswith("file://"):
                            return Path(folder[7:])
                except (json.JSONDecodeError, OSError) as e:
                    logger.debug(f"Failed to read cwd from cursor workspace.json: {e}")

    return None


def extract_cwd_from_file(file_path: Path, source_format: str) -> Path | None:
    """Extract working directory directly from a session file.

    This is used when we only have a file path (not a full session dict from
    discovery), or when discovery set a placeholder that needs resolution.

    For Claude sessions, scans the first N lines for a 'cwd' field since the
    first line may be a file-history-snapshot without cwd.

    For Gemini sessions, extracts cwd from the common prefix of file paths
    in tool calls (since Gemini doesn't store cwd explicitly).

    Args:
        file_path: Path to the session file.
        source_format: Agent type ('claude', 'codex', 'cursor', 'gemini').

    Returns:
        Path to working directory, or None if not found.
    """
    if source_format == "claude":
        # Claude: scan first 20 lines for cwd field (first lines may be snapshots/summaries)
        try:
            with open(file_path, encoding="utf-8", errors="replace") as f:
                for _ in range(20):
                    line = f.readline()
                    if not line:
                        break
                    try:
                        entry = json.loads(line)
                        cwd = entry.get("cwd")
                        if cwd:
                            return Path(cwd)
                    except json.JSONDecodeError:
                        continue
        except OSError as e:
            logger.debug(f"Failed to read cwd from claude session {file_path}: {e}")

    elif source_format == "codex":
        # Codex: read first line, cwd is in payload
        try:
            with open(file_path, encoding="utf-8", errors="replace") as f:
                first_line = f.readline()
                if first_line:
                    data = json.loads(first_line)
                    if data.get("type") == "session_meta":
                        payload = data.get("payload", {})
                        cwd_str = payload.get("cwd")
                        if cwd_str:
                            return Path(cwd_str)
        except (json.JSONDecodeError, OSError) as e:
            logger.debug(f"Failed to read cwd from codex session {file_path}: {e}")

    elif source_format == "gemini":
        # Gemini doesn't store cwd explicitly, but we can try to extract it from
        # file paths in tool calls. The common prefix of tool call paths gives us
        # a reasonable approximation of the working directory.
        try:
            data = json.loads(file_path.read_text(encoding="utf-8", errors="replace"))
            paths = _extract_gemini_file_paths(data)

            # Filter to only paths that:
            # 1. Are under the current user's home directory (not other users or system paths)
            # 2. Actually exist (or whose parent exists)
            # This eliminates synthetic/fake paths from message content
            home = str(Path.home())
            existing_paths = []
            for p in paths:
                # Only accept paths under current user's home
                if not p.startswith(home):
                    continue
                path_obj = Path(p)
                # Check if path exists, or its parent (for deleted files)
                if path_obj.exists() or path_obj.parent.exists():
                    existing_paths.append(p)

            if existing_paths:
                common = os.path.commonpath(existing_paths)
                # Verify it looks like a valid project root (has git, or is reasonable)
                common_path = Path(common)
                # Walk up to find git root or stop at a reasonable depth
                for _ in range(5):
                    if (common_path / ".git").exists():
                        return common_path
                    if common_path.parent == common_path:
                        break
                    common_path = common_path.parent
                # If no git root found, return the common prefix as-is
                return Path(common)
        except (json.JSONDecodeError, OSError, ValueError) as e:
            logger.debug(f"Failed to extract cwd from gemini session {file_path}: {e}")

    elif source_format == "opencode" and file_path.suffix == ".db" and file_path.exists():
        # OpenCode: cwd is the project worktree from SQLite DB
        try:
            conn = sqlite3.connect(f"file:{file_path}?mode=ro", uri=True, timeout=10)
            conn.row_factory = sqlite3.Row
            # Get first session's worktree/directory
            row = conn.execute(
                "SELECT s.directory, p.worktree FROM session s "
                "LEFT JOIN project p ON s.project_id = p.id "
                "LIMIT 1"
            ).fetchone()
            conn.close()
            if row:
                cwd_str = row["worktree"] or row["directory"]
                if cwd_str:
                    return Path(cwd_str)
        except (sqlite3.Error, OSError) as e:
            logger.debug(f"Failed to read cwd from OpenCode DB {file_path}: {e}")

    # Cursor is handled differently (workspace.json), not a JSONL file
    return None


def _extract_gemini_file_paths(data: dict) -> list[str]:
    """Extract absolute file paths from Gemini session data.

    Searches for absolute paths in:
    1. Tool call arguments (explicit path parameters)
    2. Tool call results (error messages, output containing expanded paths)
    3. Message content (assistant responses that mention file paths)

    Args:
        data: Parsed Gemini session JSON.

    Returns:
        List of absolute file paths found in the session.
    """

    paths = []
    messages = data.get("messages", [])

    # Regex to find absolute Unix paths in text
    # Matches paths like /Users/foo/bar/file.py or /home/user/project
    # Stops at common delimiters: quotes, spaces, newlines, backticks, etc.
    path_pattern = re.compile(r"(/(?:Users|home|tmp|var|opt|usr)[^\s'\"`<>|*?\n\r]+)")

    for msg in messages:
        # Search message content for paths (assistant responses often mention paths)
        content = msg.get("content")
        if isinstance(content, str):
            matches = path_pattern.findall(content)
            paths.extend(matches)

        # Search tool calls
        tool_calls = msg.get("toolCalls", [])
        for tc in tool_calls:
            # Check args for explicit path arguments
            args = tc.get("args", {})
            for key in ("file_path", "filePath", "path", "target_path", "targetPath"):
                val = args.get(key)
                if isinstance(val, str) and val.startswith("/"):
                    paths.append(val)

            # Also search tool results for absolute paths
            # Results often contain expanded paths in error messages or output
            results = tc.get("result", [])
            for result in results:
                if not isinstance(result, dict):
                    continue
                func_response = result.get("functionResponse", {})
                response = func_response.get("response", {})
                if isinstance(response, dict):
                    # Search error and output fields for paths
                    for field in ("error", "output"):
                        text = response.get(field)
                        if isinstance(text, str):
                            matches = path_pattern.findall(text)
                            paths.extend(matches)

    return paths
