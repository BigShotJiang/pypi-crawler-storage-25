"""Tests for agentstream.cost module."""

from agentstream.cost import _lookup_model, calculate_cost


class TestLookupModel:
    """Tests for model lookup logic."""

    def test_exact_match(self):
        """Known model should return pricing dict."""
        pricing = _lookup_model("claude-opus-4-6")
        assert pricing is not None
        assert "input_cost_per_token" in pricing

    def test_prefix_stripping(self):
        """Models with provider prefix should resolve after stripping."""
        pricing = _lookup_model("anthropic/claude-opus-4-6")
        assert pricing is not None
        assert "input_cost_per_token" in pricing

    def test_unknown_model_returns_default(self):
        """Unknown model should fall back to _default pricing."""
        pricing = _lookup_model("nonexistent-model-xyz")
        assert pricing is not None
        assert pricing["input_cost_per_token"] == 1.25e-06
        assert pricing["output_cost_per_token"] == 10.0e-06

    def test_empty_string(self):
        """Empty string should return None (no default)."""
        assert _lookup_model("") is None


class TestCalculateCost:
    """Tests for cost calculation."""

    def test_known_model_basic(self):
        """Basic cost calculation for a known model."""
        cost = calculate_cost(
            model="claude-opus-4-6",
            input_tokens=1000,
            output_tokens=500,
        )
        assert cost > 0
        # Claude Opus 4.6: $5/M input, $25/M output
        # 1000 * 5e-6 + 500 * 25e-6 = 0.005 + 0.0125 = 0.0175
        assert abs(cost - 0.0175) < 0.0001

    def test_cache_tokens(self):
        """Cache tokens should be included in cost."""
        cost_without_cache = calculate_cost(
            model="claude-opus-4-6",
            input_tokens=1000,
        )
        cost_with_cache = calculate_cost(
            model="claude-opus-4-6",
            input_tokens=1000,
            cache_read_tokens=5000,
            cache_creation_tokens=2000,
        )
        assert cost_with_cache > cost_without_cache

    def test_reasoning_tokens(self):
        """Reasoning tokens should use output cost when no specific rate."""
        # Claude doesn't have output_cost_per_reasoning_token, should fall back to output rate
        cost = calculate_cost(
            model="claude-opus-4-6",
            reasoning_tokens=1000,
        )
        # Should use output_cost_per_token as fallback: 1000 * 25e-6 = 0.025
        assert abs(cost - 0.025) < 0.0001

    def test_unknown_model_uses_default(self):
        """Unknown model should use default pricing ($1.25/$10 per M tokens)."""
        cost = calculate_cost(
            model="nonexistent-model",
            input_tokens=1_000_000,
            output_tokens=1_000_000,
        )
        # $1.25/M input + $10/M output = $11.25
        assert abs(cost - 11.25) < 0.01

    def test_empty_model_returns_zero(self):
        """Empty model string should return 0.0 (no default)."""
        cost = calculate_cost(model="", input_tokens=1000)
        assert cost == 0.0

    def test_zero_tokens(self):
        """Zero tokens should return zero cost."""
        cost = calculate_cost(model="claude-opus-4-6")
        assert cost == 0.0

    def test_prefix_stripped_model(self):
        """Models with provider prefix should work."""
        cost = calculate_cost(
            model="anthropic/claude-opus-4-6",
            input_tokens=1000,
        )
        assert cost > 0

    def test_sonnet_model(self):
        """Verify Sonnet pricing works."""
        cost = calculate_cost(
            model="claude-sonnet-4-5-20250929",
            input_tokens=1000,
            output_tokens=500,
        )
        # Sonnet: $3/M input, $15/M output
        # 1000 * 3e-6 + 500 * 15e-6 = 0.003 + 0.0075 = 0.0105
        assert abs(cost - 0.0105) < 0.0001
