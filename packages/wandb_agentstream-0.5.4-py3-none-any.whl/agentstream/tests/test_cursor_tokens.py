"""Tests for Cursor token estimation module."""

from agentstream.adapters.cursor_tokens import (
    CHARS_PER_TOKEN,
    CURSOR_CONTEXT_WINDOW,
    estimate_input_tokens,
    estimate_output_tokens,
    estimate_session_tokens,
)


class TestEstimateInputTokens:
    """Tests for estimate_input_tokens function."""

    def test_zero_percent_returns_zero(self):
        """Zero context usage should return zero tokens."""
        assert estimate_input_tokens(0.0) == 0

    def test_full_context_returns_full_window(self):
        """100% context usage should return full context window."""
        assert estimate_input_tokens(100.0) == CURSOR_CONTEXT_WINDOW

    def test_partial_context_usage(self):
        """Partial context usage should scale proportionally."""
        # 17.5% of 200,000 = 35,000
        assert estimate_input_tokens(17.5) == 35_000

    def test_half_context_usage(self):
        """50% context usage should return half the window."""
        assert estimate_input_tokens(50.0) == 100_000

    def test_small_percentage(self):
        """Small percentage should return proportional tokens."""
        # 1% of 200,000 = 2,000
        assert estimate_input_tokens(1.0) == 2_000

    def test_fractional_percentage(self):
        """Fractional percentages should work correctly."""
        # 0.5% of 200,000 = 1,000
        assert estimate_input_tokens(0.5) == 1_000

    def test_rounds_to_integer(self):
        """Result should be an integer."""
        result = estimate_input_tokens(17.1835)
        assert isinstance(result, int)
        # 17.1835% of 200,000 = 34,367
        assert result == 34_367

    def test_none_returns_zero(self):
        """None input should return zero."""
        assert estimate_input_tokens(None) == 0

    def test_negative_returns_zero(self):
        """Negative input should return zero."""
        assert estimate_input_tokens(-10.0) == 0

    def test_over_100_percent_clamped(self):
        """Values over 100% should be clamped to 100%."""
        assert estimate_input_tokens(150.0) == CURSOR_CONTEXT_WINDOW


class TestEstimateOutputTokens:
    """Tests for estimate_output_tokens function."""

    def test_empty_bubbles_returns_zero(self):
        """Empty bubble list should return zero."""
        assert estimate_output_tokens([]) == 0

    def test_none_bubbles_returns_zero(self):
        """None input should return zero."""
        assert estimate_output_tokens(None) == 0

    def test_user_bubbles_ignored(self):
        """User bubbles (type=1) should not be counted."""
        bubbles = [
            {"type": 1, "text": "This is a user message with some content"},
        ]
        assert estimate_output_tokens(bubbles) == 0

    def test_assistant_bubbles_counted(self):
        """Assistant bubbles (type=2) should be counted."""
        # "Hello!" = 6 chars / 4 = 1 token (integer division)
        bubbles = [
            {"type": 2, "text": "Hello!"},
        ]
        assert estimate_output_tokens(bubbles) == 1

    def test_longer_text(self):
        """Longer text should produce proportionally more tokens."""
        # 40 chars / 4 = 10 tokens
        bubbles = [
            {"type": 2, "text": "A" * 40},
        ]
        assert estimate_output_tokens(bubbles) == 10

    def test_multiple_assistant_bubbles(self):
        """Multiple assistant bubbles should sum their tokens."""
        bubbles = [
            {"type": 2, "text": "A" * 20},  # 5 tokens
            {"type": 2, "text": "B" * 20},  # 5 tokens
        ]
        assert estimate_output_tokens(bubbles) == 10

    def test_mixed_bubbles(self):
        """Only assistant bubbles should contribute to count."""
        bubbles = [
            {"type": 1, "text": "User message here"},  # ignored
            {"type": 2, "text": "A" * 20},  # 5 tokens
            {"type": 1, "text": "Another user message"},  # ignored
            {"type": 2, "text": "B" * 20},  # 5 tokens
        ]
        assert estimate_output_tokens(bubbles) == 10

    def test_tool_results_included(self):
        """Tool results should be included in count."""
        bubbles = [
            {
                "type": 2,
                "text": "A" * 20,  # 5 tokens from text
                "toolFormerData": {
                    "name": "read_file",
                    "result": "B" * 20,  # 5 tokens from result
                },
            },
        ]
        assert estimate_output_tokens(bubbles) == 10

    def test_missing_text_field(self):
        """Bubbles without text should not cause errors."""
        bubbles = [
            {"type": 2},  # no text field
            {"type": 2, "text": "A" * 20},  # 5 tokens
        ]
        assert estimate_output_tokens(bubbles) == 5

    def test_empty_text_field(self):
        """Empty text should contribute zero."""
        bubbles = [
            {"type": 2, "text": ""},
            {"type": 2, "text": "A" * 20},  # 5 tokens
        ]
        assert estimate_output_tokens(bubbles) == 5

    def test_tool_result_without_text(self):
        """Tool results should count even without bubble text."""
        bubbles = [
            {
                "type": 2,
                "toolFormerData": {
                    "name": "execute",
                    "result": "A" * 40,  # 10 tokens
                },
            },
        ]
        assert estimate_output_tokens(bubbles) == 10


class TestEstimateSessionTokens:
    """Tests for estimate_session_tokens function."""

    def test_basic_estimation(self):
        """Should combine input and output estimates."""
        metadata = {"contextUsagePercent": 10.0}  # 20,000 input tokens
        bubbles = [
            {"type": 2, "text": "A" * 40},  # 10 output tokens
        ]

        result = estimate_session_tokens(metadata, bubbles)

        assert result["input_tokens"] == 20_000
        assert result["output_tokens"] == 10
        assert result["tokens_estimated"] is True

    def test_tokens_estimated_always_true(self):
        """tokens_estimated flag should always be True."""
        result = estimate_session_tokens({}, [])
        assert result["tokens_estimated"] is True

    def test_estimation_method_included(self):
        """Should include description of estimation method."""
        metadata = {"contextUsagePercent": 25.0}
        bubbles = [{"type": 2, "text": "Hello"}]

        result = estimate_session_tokens(metadata, bubbles)

        assert "estimation_method" in result
        assert "contextUsagePercent" in result["estimation_method"]
        assert "25.0%" in result["estimation_method"]

    def test_missing_context_percent(self):
        """Should handle missing contextUsagePercent gracefully."""
        result = estimate_session_tokens({}, [{"type": 2, "text": "A" * 20}])

        assert result["input_tokens"] == 0
        assert result["output_tokens"] == 5
        assert "unavailable" in result["estimation_method"]

    def test_none_context_percent(self):
        """Should handle None contextUsagePercent gracefully."""
        result = estimate_session_tokens({"contextUsagePercent": None}, [])

        assert result["input_tokens"] == 0

    def test_empty_bubbles(self):
        """Should handle empty bubbles gracefully."""
        result = estimate_session_tokens({"contextUsagePercent": 10.0}, [])

        assert result["input_tokens"] == 20_000
        assert result["output_tokens"] == 0
        assert "no bubbles" in result["estimation_method"]

    def test_none_bubbles(self):
        """Should handle None bubbles gracefully."""
        result = estimate_session_tokens({"contextUsagePercent": 10.0}, None)

        assert result["input_tokens"] == 20_000
        assert result["output_tokens"] == 0

    def test_assistant_bubble_count_in_method(self):
        """Should include assistant bubble count in method description."""
        bubbles = [
            {"type": 1, "text": "user"},
            {"type": 2, "text": "assistant 1"},
            {"type": 2, "text": "assistant 2"},
            {"type": 1, "text": "user again"},
            {"type": 2, "text": "assistant 3"},
        ]

        result = estimate_session_tokens({}, bubbles)

        assert "3 assistant bubbles" in result["estimation_method"]

    def test_chars_per_token_in_method(self):
        """Should include chars per token ratio in method description."""
        result = estimate_session_tokens({}, [{"type": 2, "text": "Hi"}])

        assert f"{CHARS_PER_TOKEN} chars/token" in result["estimation_method"]

    def test_return_type_is_dict(self):
        """Should return a dictionary."""
        result = estimate_session_tokens({}, [])
        assert isinstance(result, dict)

    def test_all_expected_keys_present(self):
        """Should return all expected keys."""
        result = estimate_session_tokens({}, [])

        expected_keys = {"input_tokens", "output_tokens", "tokens_estimated", "estimation_method"}
        assert set(result.keys()) == expected_keys


class TestConstants:
    """Tests for module constants."""

    def test_context_window_size(self):
        """Context window should be 200k tokens."""
        assert CURSOR_CONTEXT_WINDOW == 200_000

    def test_chars_per_token(self):
        """Chars per token should be 4 (conservative estimate)."""
        assert CHARS_PER_TOKEN == 4
