"""Tests for the CacheBackend protocol and FileCache implementation."""

import gzip
import json
import os
import tempfile

from agentstream.enrichment.cache import FileCache, _jittered_ttl, make_cache_key


class TestFileCache:
    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()
        self.cache = FileCache(self.tmpdir)

    def test_read_miss(self):
        assert self.cache.read("nonexistent_key") is None

    def test_write_and_read(self):
        data = [{"id": 1, "event": "test"}]
        self.cache.write("my_key", data)
        result = self.cache.read("my_key")
        assert result == data

    def test_write_creates_gz_file(self):
        self.cache.write("day_key", [{"a": 1}])
        gz_path = os.path.join(self.tmpdir, "day_key.json.gz")
        assert os.path.exists(gz_path)
        with gzip.open(gz_path, "rt", encoding="utf-8") as f:
            assert json.load(f) == [{"a": 1}]

    def test_write_does_not_create_plain_json(self):
        self.cache.write("day_key", [{"a": 1}])
        plain_path = os.path.join(self.tmpdir, "day_key.json")
        assert not os.path.exists(plain_path)

    def test_read_uncompressed_backward_compat(self):
        """Old uncompressed .json files are still readable."""
        plain_path = os.path.join(self.tmpdir, "old_key.json")
        with open(plain_path, "w") as f:
            json.dump([{"legacy": True}], f)
        assert self.cache.read("old_key") == [{"legacy": True}]

    def test_gz_preferred_over_plain(self):
        """When both .json.gz and .json exist, compressed wins."""
        key = "both_key"
        # Write plain
        with open(os.path.join(self.tmpdir, f"{key}.json"), "w") as f:
            json.dump([{"source": "plain"}], f)
        # Write compressed
        with gzip.open(os.path.join(self.tmpdir, f"{key}.json.gz"), "wt", encoding="utf-8") as f:
            json.dump([{"source": "gz"}], f)
        assert self.cache.read(key) == [{"source": "gz"}]

    def test_read_corrupt_json(self):
        path = os.path.join(self.tmpdir, "bad_key.json")
        with open(path, "w") as f:
            f.write("{not valid json")
        assert self.cache.read("bad_key") is None

    def test_read_corrupt_gz(self):
        path = os.path.join(self.tmpdir, "bad_gz.json.gz")
        with open(path, "wb") as f:
            f.write(b"not gzip data")
        assert self.cache.read("bad_gz") is None

    def test_ttl_ignored(self):
        """FileCache ignores TTL (no expiry enforcement)."""
        self.cache.write("ttl_key", [{"x": 1}], ttl_seconds=1)
        assert self.cache.read("ttl_key") == [{"x": 1}]

    def test_overwrite(self):
        self.cache.write("key", [{"v": 1}])
        self.cache.write("key", [{"v": 2}])
        assert self.cache.read("key") == [{"v": 2}]

    def test_size_bytes_counts_both_extensions(self):
        self.cache.write("compressed", [{"a": 1}])
        # Also create a legacy plain file
        with open(os.path.join(self.tmpdir, "legacy.json"), "w") as f:
            json.dump([{"b": 2}], f)
        size = self.cache.size_bytes()
        assert size > 0

    def test_clear_removes_all_files(self):
        self.cache.write("key1", [{"a": 1}])
        self.cache.write("key2", [{"b": 2}])
        # Also a legacy plain file
        with open(os.path.join(self.tmpdir, "legacy.json"), "w") as f:
            json.dump([{"c": 3}], f)
        deleted = self.cache.clear()
        assert deleted == 3
        assert self.cache.read("key1") is None
        assert self.cache.read("key2") is None
        assert self.cache.read("legacy") is None

    def test_clear_empty_dir(self):
        assert self.cache.clear() == 0


class TestJitteredTtl:
    def test_no_jitter_when_zero(self):
        assert _jittered_ttl(3600, 0, "key") == 3600

    def test_deterministic(self):
        t1 = _jittered_ttl(86400 * 30, 86400, "same_key")
        t2 = _jittered_ttl(86400 * 30, 86400, "same_key")
        assert t1 == t2

    def test_different_keys_different_ttl(self):
        t1 = _jittered_ttl(86400 * 30, 86400, "key_a")
        t2 = _jittered_ttl(86400 * 30, 86400, "key_b")
        # Extremely unlikely to be exactly equal
        assert t1 != t2

    def test_within_range(self):
        base = 86400 * 30
        jitter = 86400
        for seed in ["a", "b", "c", "test_key_123", "xyz"]:
            ttl = _jittered_ttl(base, jitter, seed)
            assert base - jitter <= ttl <= base + jitter


class TestMakeCacheKey:
    def test_deterministic(self):
        k1 = make_cache_key("api_key_123", "2025-01-15")
        k2 = make_cache_key("api_key_123", "2025-01-15")
        assert k1 == k2

    def test_different_keys(self):
        k1 = make_cache_key("key_a", "2025-01-15")
        k2 = make_cache_key("key_b", "2025-01-15")
        assert k1 != k2

    def test_format(self):
        key = make_cache_key("mykey", "2025-01-15")
        assert key.endswith("_2025-01-15")
        assert len(key.split("_")[0]) == 8  # 8-char hash prefix
