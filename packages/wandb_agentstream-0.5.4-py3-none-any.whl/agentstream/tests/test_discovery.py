"""Tests for agentstream.discovery module.

Covers session discovery, model extraction, timestamp extraction,
CWD resolution, and source entry reading.
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import time
from pathlib import Path

from agentstream.discovery import (
    _discover_claude_sessions,
    _discover_codex_sessions,
    _discover_cursor_sessions,
    _discover_gemini_sessions,
    _discover_opencode_sessions,
    _extract_gemini_file_paths,
    _extract_model_from_codex_jsonl,
    _extract_model_from_gemini_json,
    _extract_model_from_jsonl,
    _extract_model_from_opencode_session,
    _extract_timestamp_claude,
    _extract_timestamp_codex,
    _extract_timestamp_cursor,
    _extract_timestamp_gemini,
    _get_cursor_user_dir,
    _read_claude_entries,
    _read_codex_entries,
    _read_cursor_entries,
    _read_gemini_entries,
    _session_dict_to_obj,
    discover_all_sessions,
    extract_cwd_from_file,
    extract_model,
    get_session_cwd,
    read_source_entries,
)

# =============================================================================
# Helper to write JSONL files
# =============================================================================


def write_jsonl(path: Path, entries: list[dict]) -> None:
    with open(path, "w") as f:
        for entry in entries:
            f.write(json.dumps(entry) + "\n")


# =============================================================================
# Timestamp extraction tests
# =============================================================================


class TestExtractTimestampClaude:
    def test_iso_timestamp(self):
        entry = {"timestamp": "2024-01-01T00:00:00Z"}
        ts = _extract_timestamp_claude(entry)
        assert ts == 1704067200000

    def test_iso_timestamp_with_offset(self):
        entry = {"timestamp": "2024-01-01T00:00:00+00:00"}
        ts = _extract_timestamp_claude(entry)
        assert ts == 1704067200000

    def test_missing_timestamp_returns_current_time(self):
        entry = {}
        ts = _extract_timestamp_claude(entry)
        assert ts > 0

    def test_invalid_timestamp_returns_current_time(self):
        entry = {"timestamp": "not-a-date"}
        ts = _extract_timestamp_claude(entry)
        assert ts > 0


class TestExtractTimestampCodex:
    def test_iso_timestamp(self):
        entry = {"timestamp": "2024-01-01T12:00:00Z"}
        ts = _extract_timestamp_codex(entry)
        assert ts == 1704110400000

    def test_missing_timestamp(self):
        ts = _extract_timestamp_codex({})
        assert ts > 0


class TestExtractTimestampCursor:
    def test_iso_string(self):
        entry = {"createdAt": "2024-01-01T00:00:00Z"}
        ts = _extract_timestamp_cursor(entry)
        assert ts == 1704067200000

    def test_millisecond_numeric(self):
        entry = {"timestamp": 1704067200000}
        ts = _extract_timestamp_cursor(entry)
        assert ts == 1704067200000

    def test_second_numeric(self):
        entry = {"timestamp": 1704067200}
        ts = _extract_timestamp_cursor(entry)
        assert ts == 1704067200000

    def test_numeric_string_ms(self):
        entry = {"timestamp": "1704067200000"}
        ts = _extract_timestamp_cursor(entry)
        assert ts == 1704067200000

    def test_fallback_fields(self):
        # Should try "timestamp" first, then "createdAt", then "lastUpdatedAt"
        entry = {"lastUpdatedAt": 1704067200000}
        ts = _extract_timestamp_cursor(entry)
        assert ts == 1704067200000

    def test_no_fields_returns_current(self):
        ts = _extract_timestamp_cursor({})
        assert ts > 0

    def test_invalid_string(self):
        entry = {"timestamp": "not-a-date", "createdAt": "also-bad"}
        ts = _extract_timestamp_cursor(entry)
        assert ts > 0


class TestExtractTimestampGemini:
    def test_iso_timestamp(self):
        entry = {"timestamp": "2024-06-15T10:30:00Z"}
        ts = _extract_timestamp_gemini(entry)
        assert ts > 0

    def test_missing_timestamp(self):
        ts = _extract_timestamp_gemini({})
        assert ts > 0


# =============================================================================
# Model extraction tests
# =============================================================================


class TestExtractModelFromJsonl:
    def test_claude_model_extraction(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(
            session_file,
            [
                {"type": "user", "message": {"content": "Hello"}},
                {
                    "type": "assistant",
                    "message": {"model": "claude-sonnet-4-5-20250929", "content": []},
                },
            ],
        )
        model = _extract_model_from_jsonl(session_file, "claude")
        assert model == "claude-sonnet-4-5-20250929"

    def test_no_model_found(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(session_file, [{"type": "user", "message": {"content": "Hello"}}])
        model = _extract_model_from_jsonl(session_file, "claude")
        assert model is None

    def test_nonexistent_file(self, tmp_path):
        model = _extract_model_from_jsonl(tmp_path / "nope.jsonl", "claude")
        assert model is None

    def test_invalid_json_lines(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        session_file.write_text("not json\n{bad json too\n")
        model = _extract_model_from_jsonl(session_file, "claude")
        assert model is None

    def test_non_claude_type_ignored(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(session_file, [{"type": "assistant", "message": {"model": "gpt-4"}}])
        # Only "claude" agent_type checks "assistant" type entries
        model = _extract_model_from_jsonl(session_file, "unknown")
        assert model is None

    def test_max_entries_limit(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        # Write 60 user entries, then an assistant entry
        entries = [{"type": "user", "message": {"content": f"msg-{i}"}} for i in range(60)]
        entries.append({"type": "assistant", "message": {"model": "hidden-model"}})
        write_jsonl(session_file, entries)
        model = _extract_model_from_jsonl(session_file, "claude")
        # Should not find model because it's beyond MAX_ENTRIES_FOR_MODEL (50)
        assert model is None


class TestExtractModelFromCodexJsonl:
    def test_model_in_session_meta(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(
            session_file,
            [{"type": "session_meta", "payload": {"cwd": "/project", "model": "o3"}}],
        )
        model = _extract_model_from_codex_jsonl(session_file)
        assert model == "o3"

    def test_model_provider_fallback(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(
            session_file,
            [
                {
                    "type": "session_meta",
                    "payload": {"cwd": "/project", "model_provider": "openai"},
                }
            ],
        )
        model = _extract_model_from_codex_jsonl(session_file)
        assert model == "openai"

    def test_no_model(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(session_file, [{"type": "session_meta", "payload": {"cwd": "/project"}}])
        model = _extract_model_from_codex_jsonl(session_file)
        assert model is None

    def test_nonexistent_file(self, tmp_path):
        model = _extract_model_from_codex_jsonl(tmp_path / "nope.jsonl")
        assert model is None


class TestExtractModelFromGeminiJson:
    def test_model_extraction(self, tmp_path):
        session_file = tmp_path / "session.json"
        session_file.write_text(
            json.dumps(
                {
                    "messages": [
                        {"type": "gemini", "model": "gemini-2.5-pro"},
                        {"type": "text", "content": "Hello"},
                    ]
                }
            )
        )
        model = _extract_model_from_gemini_json(session_file)
        assert model == "gemini-2.5-pro"

    def test_no_model(self, tmp_path):
        session_file = tmp_path / "session.json"
        session_file.write_text(json.dumps({"messages": [{"type": "text", "content": "Hello"}]}))
        model = _extract_model_from_gemini_json(session_file)
        assert model is None

    def test_nonexistent_file(self, tmp_path):
        model = _extract_model_from_gemini_json(tmp_path / "nope.json")
        assert model is None

    def test_non_dict_messages_skipped(self, tmp_path):
        session_file = tmp_path / "session.json"
        session_file.write_text(json.dumps({"messages": ["not a dict", 42]}))
        model = _extract_model_from_gemini_json(session_file)
        assert model is None


class TestExtractModelFromOpencodeSession:
    def test_assistant_message_model(self, tmp_path):
        storage_dir = tmp_path / "storage"
        messages_dir = storage_dir / "message" / "sess-1"
        messages_dir.mkdir(parents=True)

        msg_file = messages_dir / "msg-1.json"
        msg_file.write_text(
            json.dumps(
                {
                    "role": "assistant",
                    "modelID": "claude-sonnet-4-5-20250929",
                    "providerID": "anthropic",
                }
            )
        )

        model = _extract_model_from_opencode_session(storage_dir, "sess-1")
        assert model == "anthropic/claude-sonnet-4-5-20250929"

    def test_assistant_message_model_no_provider(self, tmp_path):
        storage_dir = tmp_path / "storage"
        messages_dir = storage_dir / "message" / "sess-1"
        messages_dir.mkdir(parents=True)

        msg_file = messages_dir / "msg-1.json"
        msg_file.write_text(
            json.dumps({"role": "assistant", "modelID": "claude-sonnet-4-5-20250929"})
        )

        model = _extract_model_from_opencode_session(storage_dir, "sess-1")
        assert model == "claude-sonnet-4-5-20250929"

    def test_user_message_model(self, tmp_path):
        storage_dir = tmp_path / "storage"
        messages_dir = storage_dir / "message" / "sess-1"
        messages_dir.mkdir(parents=True)

        msg_file = messages_dir / "msg-1.json"
        msg_file.write_text(
            json.dumps(
                {
                    "role": "user",
                    "model": {"providerID": "anthropic", "modelID": "claude-sonnet-4-5-20250929"},
                }
            )
        )

        model = _extract_model_from_opencode_session(storage_dir, "sess-1")
        assert model == "anthropic/claude-sonnet-4-5-20250929"

    def test_no_messages_dir(self, tmp_path):
        storage_dir = tmp_path / "storage"
        model = _extract_model_from_opencode_session(storage_dir, "sess-1")
        assert model is None

    def test_invalid_json(self, tmp_path):
        storage_dir = tmp_path / "storage"
        messages_dir = storage_dir / "message" / "sess-1"
        messages_dir.mkdir(parents=True)

        msg_file = messages_dir / "msg-1.json"
        msg_file.write_text("not json")

        model = _extract_model_from_opencode_session(storage_dir, "sess-1")
        assert model is None


class TestExtractModel:
    """Test the public extract_model API."""

    def test_claude(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(
            session_file,
            [{"type": "assistant", "message": {"model": "claude-opus-4-20250514"}}],
        )
        assert extract_model(session_file, "claude") == "claude-opus-4-20250514"

    def test_codex(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(
            session_file,
            [{"type": "session_meta", "payload": {"cwd": "/p", "model": "o3"}}],
        )
        assert extract_model(session_file, "codex") == "o3"

    def test_gemini(self, tmp_path):
        session_file = tmp_path / "session.json"
        session_file.write_text(
            json.dumps({"messages": [{"type": "gemini", "model": "gemini-2.5-pro"}]})
        )
        assert extract_model(session_file, "gemini") == "gemini-2.5-pro"

    def test_cursor_returns_none(self, tmp_path):
        assert extract_model(tmp_path / "state.vscdb", "cursor") is None

    def test_unknown_returns_none(self, tmp_path):
        assert extract_model(tmp_path / "file", "unknown") is None


# =============================================================================
# Session dict to object conversion
# =============================================================================


class TestSessionDictToObj:
    def test_basic_conversion(self):
        session_dict = {
            "id": "test-1",
            "path": Path("/tmp/test.jsonl"),
            "format": "claude",
            "modified_at": 1704067200.0,
        }
        obj = _session_dict_to_obj(session_dict)
        assert obj.id == "test-1"
        assert obj.path == Path("/tmp/test.jsonl")
        assert obj.format == "claude"
        assert obj.modified_at == 1704067200.0
        assert obj.metadata is None

    def test_with_metadata(self):
        session_dict = {
            "id": "test-1",
            "path": Path("/tmp/test.jsonl"),
            "format": "codex",
            "modified_at": 0.0,
            "metadata": {"cwd": "/project"},
        }
        obj = _session_dict_to_obj(session_dict)
        assert obj.metadata == {"cwd": "/project"}


# =============================================================================
# read_source_entries
# =============================================================================


class TestReadSourceEntries:
    def test_reads_via_adapter(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(
            session_file,
            [
                {
                    "type": "user",
                    "message": {"content": "Hello"},
                    "uuid": "u1",
                    "timestamp": "2024-01-01T00:00:00Z",
                    "cwd": "/project",
                },
            ],
        )
        session = {
            "id": "test-session",
            "path": session_file,
            "format": "claude",
            "modified_at": session_file.stat().st_mtime,
        }
        entries = read_source_entries(session)
        assert len(entries) == 1
        assert entries[0]["entry_index"] == 0
        assert "entry_content" in entries[0]
        assert "entry_timestamp_ms" in entries[0]

    def test_unknown_format_returns_empty(self, tmp_path):
        session = {
            "id": "test-session",
            "path": tmp_path / "file",
            "format": "nonexistent_format",
            "modified_at": 0.0,
        }
        entries = read_source_entries(session)
        assert entries == []


# =============================================================================
# Claude session discovery
# =============================================================================


class TestDiscoverClaudeSessions:
    def test_no_claude_dir(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        sessions = _discover_claude_sessions(tmp_path)
        assert sessions == []

    def test_discover_sessions_with_cwd(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        # Create a project directory at the real path
        project_path = tmp_path / "myproject"
        project_path.mkdir()

        # Claude encodes project path: /tmp/xxx/myproject -> -tmp-xxx-myproject
        encoded_name = str(project_path).replace("/", "-")
        claude_project_dir = tmp_path / ".claude" / "projects" / encoded_name
        claude_project_dir.mkdir(parents=True)

        # Session files must have UUID-like names
        session_file = claude_project_dir / "a1b2c3d4-e5f6-7890-abcd-ef1234567890.jsonl"
        write_jsonl(
            session_file,
            [
                {
                    "type": "user",
                    "message": {"content": "Hello"},
                    "uuid": "u1",
                    "cwd": str(project_path),
                    "timestamp": "2024-01-01T00:00:00Z",
                },
            ],
        )

        # Search from home to find all sessions
        sessions = _discover_claude_sessions(tmp_path)
        assert len(sessions) >= 1
        assert sessions[0]["format"] == "claude"

    def test_skips_non_directory(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        projects_dir = tmp_path / ".claude" / "projects"
        projects_dir.mkdir(parents=True)

        # Create a file (not a directory) in projects
        (projects_dir / "not-a-dir.txt").write_text("hello")

        sessions = _discover_claude_sessions(tmp_path)
        assert sessions == []

    def test_skips_dir_without_jsonl_files(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        project_dir = tmp_path / ".claude" / "projects" / "empty-project"
        project_dir.mkdir(parents=True)

        sessions = _discover_claude_sessions(tmp_path)
        assert sessions == []

    def test_path_mismatch_filtered(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        project_dir = tmp_path / ".claude" / "projects" / "other-project"
        project_dir.mkdir(parents=True)

        session_file = project_dir / "session.jsonl"
        write_jsonl(
            session_file,
            [{"type": "user", "cwd": "/some/other/path", "timestamp": "2024-01-01T00:00:00Z"}],
        )

        # Search in a different path
        search_path = tmp_path / "my-project"
        search_path.mkdir()
        sessions = _discover_claude_sessions(search_path)
        assert sessions == []

    def test_fallback_path_when_no_cwd_in_entries(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        project_dir = tmp_path / ".claude" / "projects" / "-tmp-project"
        project_dir.mkdir(parents=True)

        session_file = project_dir / "session.jsonl"
        # Write entries without cwd field
        write_jsonl(session_file, [{"type": "user", "timestamp": "2024-01-01T00:00:00Z"}])

        sessions = _discover_claude_sessions(tmp_path)
        # Should still discover, using fallback path
        # The fallback naive replacement produces /tmp/project which may or may not match
        # When searching from home it should include everything
        assert isinstance(sessions, list)


# =============================================================================
# Codex session discovery
# =============================================================================


class TestDiscoverCodexSessions:
    def test_no_codex_dir(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        sessions = _discover_codex_sessions(tmp_path)
        assert sessions == []

    def test_discover_sessions(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        codex_dir = tmp_path / ".codex" / "sessions"
        codex_dir.mkdir(parents=True)

        session_file = codex_dir / "session1.jsonl"
        write_jsonl(
            session_file,
            [
                {
                    "type": "session_meta",
                    "payload": {
                        "id": "019cab17-816e-7411-bada-746591464f51",
                        "cwd": str(tmp_path),
                        "model": "o3",
                    },
                    "timestamp": "2024-01-01T00:00:00Z",
                },
                {"type": "message", "payload": {"role": "user", "content": "Hi"}},
            ],
        )

        sessions = _discover_codex_sessions(tmp_path)
        assert len(sessions) == 1
        assert sessions[0]["format"] == "codex"
        assert sessions[0]["id"] == "019cab17-816e-7411-bada-746591464f51"
        assert sessions[0]["metadata"]["model"] == "o3"

    def test_discover_sessions_falls_back_to_filename_stem_when_payload_id_missing(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        codex_dir = tmp_path / ".codex" / "sessions"
        codex_dir.mkdir(parents=True)

        session_file = codex_dir / "session-stem.jsonl"
        write_jsonl(
            session_file,
            [
                {
                    "type": "session_meta",
                    "payload": {"cwd": str(tmp_path), "model": "o3"},
                    "timestamp": "2024-01-01T00:00:00Z",
                }
            ],
        )

        sessions = _discover_codex_sessions(tmp_path)
        assert len(sessions) == 1
        assert sessions[0]["id"] == "session-stem"

    def test_skips_non_session_meta_first_line(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        codex_dir = tmp_path / ".codex" / "sessions"
        codex_dir.mkdir(parents=True)

        session_file = codex_dir / "session1.jsonl"
        write_jsonl(session_file, [{"type": "message", "payload": {"content": "Hi"}}])

        sessions = _discover_codex_sessions(tmp_path)
        assert sessions == []

    def test_skips_empty_cwd(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        codex_dir = tmp_path / ".codex" / "sessions"
        codex_dir.mkdir(parents=True)

        session_file = codex_dir / "session1.jsonl"
        write_jsonl(session_file, [{"type": "session_meta", "payload": {"cwd": ""}}])

        sessions = _discover_codex_sessions(tmp_path)
        assert sessions == []

    def test_path_filtering(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        codex_dir = tmp_path / ".codex" / "sessions"
        codex_dir.mkdir(parents=True)

        session_file = codex_dir / "session1.jsonl"
        write_jsonl(
            session_file,
            [{"type": "session_meta", "payload": {"cwd": "/completely/different/path"}}],
        )

        search = tmp_path / "my-project"
        search.mkdir()
        sessions = _discover_codex_sessions(search)
        assert sessions == []

    def test_invalid_json_skipped(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        codex_dir = tmp_path / ".codex" / "sessions"
        codex_dir.mkdir(parents=True)

        session_file = codex_dir / "session1.jsonl"
        session_file.write_text("not json at all\n")

        sessions = _discover_codex_sessions(tmp_path)
        assert sessions == []

    def test_empty_file_skipped(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        codex_dir = tmp_path / ".codex" / "sessions"
        codex_dir.mkdir(parents=True)

        session_file = codex_dir / "session1.jsonl"
        session_file.write_text("")

        sessions = _discover_codex_sessions(tmp_path)
        assert sessions == []


# =============================================================================
# Cursor session discovery
# =============================================================================


class TestDiscoverCursorSessions:
    def _setup_cursor_workspace(
        self,
        tmp_path: Path,
        monkeypatch,
        *,
        folder_path: str | None = None,
        composers: list[dict] | None = None,
    ) -> Path:
        """Helper to create a mock Cursor workspace."""
        cursor_user = tmp_path / "CursorUser"
        workspace_storage = cursor_user / "workspaceStorage"
        workspace_dir = workspace_storage / "workspace-abc123"
        workspace_dir.mkdir(parents=True)

        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr("agentstream.discovery._get_cursor_user_dir", lambda: cursor_user)

        # Write workspace.json
        if folder_path is None:
            folder_path = f"file://{tmp_path}"
        workspace_json = workspace_dir / "workspace.json"
        workspace_json.write_text(json.dumps({"folder": folder_path}))

        # Write state.vscdb with composer data
        if composers is None:
            composers = [
                {
                    "composerId": "comp-1",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                    "defaultModel": "claude-sonnet-4-5-20250929",
                }
            ]

        state_db = workspace_dir / "state.vscdb"
        conn = sqlite3.connect(str(state_db))
        conn.execute("CREATE TABLE ItemTable (key TEXT PRIMARY KEY, value BLOB)")
        conn.execute(
            "INSERT INTO ItemTable (key, value) VALUES (?, ?)",
            (
                "composer.composerData",
                json.dumps({"allComposers": composers}),
            ),
        )
        conn.commit()
        conn.close()

        return workspace_dir

    def test_no_cursor_dir(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr(
            "agentstream.discovery._get_cursor_user_dir",
            lambda: tmp_path / "nonexistent",
        )
        sessions = _discover_cursor_sessions(tmp_path)
        assert sessions == []

    def test_discover_sessions(self, tmp_path, monkeypatch):
        self._setup_cursor_workspace(tmp_path, monkeypatch)

        sessions = _discover_cursor_sessions(tmp_path)
        assert len(sessions) == 1
        assert sessions[0]["format"] == "cursor"
        assert sessions[0]["id"] == "comp-1"
        assert sessions[0]["metadata"]["model"] == "claude-sonnet-4-5-20250929"

    def test_path_filtering(self, tmp_path, monkeypatch):
        self._setup_cursor_workspace(tmp_path, monkeypatch, folder_path="file:///other/project")

        search = tmp_path / "my-project"
        search.mkdir()
        sessions = _discover_cursor_sessions(search)
        assert sessions == []

    def test_global_search(self, tmp_path, monkeypatch):
        self._setup_cursor_workspace(tmp_path, monkeypatch, folder_path="file:///any/path")

        # Search from home = global search
        sessions = _discover_cursor_sessions(tmp_path)
        assert len(sessions) == 1

    def test_skips_workspace_without_json(self, tmp_path, monkeypatch):
        cursor_user = tmp_path / "CursorUser"
        workspace_dir = cursor_user / "workspaceStorage" / "ws1"
        workspace_dir.mkdir(parents=True)

        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr("agentstream.discovery._get_cursor_user_dir", lambda: cursor_user)

        sessions = _discover_cursor_sessions(tmp_path)
        assert sessions == []

    def test_skips_non_file_uri(self, tmp_path, monkeypatch):
        cursor_user = tmp_path / "CursorUser"
        workspace_dir = cursor_user / "workspaceStorage" / "ws1"
        workspace_dir.mkdir(parents=True)

        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr("agentstream.discovery._get_cursor_user_dir", lambda: cursor_user)

        workspace_json = workspace_dir / "workspace.json"
        workspace_json.write_text(json.dumps({"folder": "ssh://remote/path"}))

        sessions = _discover_cursor_sessions(tmp_path)
        assert sessions == []

    def test_no_composer_data_row(self, tmp_path, monkeypatch):
        cursor_user = tmp_path / "CursorUser"
        workspace_dir = cursor_user / "workspaceStorage" / "ws1"
        workspace_dir.mkdir(parents=True)

        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr("agentstream.discovery._get_cursor_user_dir", lambda: cursor_user)

        workspace_json = workspace_dir / "workspace.json"
        workspace_json.write_text(json.dumps({"folder": f"file://{tmp_path}"}))

        # Create state.vscdb without composer data
        state_db = workspace_dir / "state.vscdb"
        conn = sqlite3.connect(str(state_db))
        conn.execute("CREATE TABLE ItemTable (key TEXT PRIMARY KEY, value BLOB)")
        conn.commit()
        conn.close()

        sessions = _discover_cursor_sessions(tmp_path)
        assert sessions == []

    def test_composer_data_as_list(self, tmp_path, monkeypatch):
        """When composer data is a list (not dict with allComposers key)."""
        cursor_user = tmp_path / "CursorUser"
        workspace_dir = cursor_user / "workspaceStorage" / "ws1"
        workspace_dir.mkdir(parents=True)

        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr("agentstream.discovery._get_cursor_user_dir", lambda: cursor_user)

        workspace_json = workspace_dir / "workspace.json"
        workspace_json.write_text(json.dumps({"folder": f"file://{tmp_path}"}))

        # Composer data as a flat list (not wrapped in allComposers)
        state_db = workspace_dir / "state.vscdb"
        conn = sqlite3.connect(str(state_db))
        conn.execute("CREATE TABLE ItemTable (key TEXT PRIMARY KEY, value BLOB)")
        conn.execute(
            "INSERT INTO ItemTable (key, value) VALUES (?, ?)",
            (
                "composer.composerData",
                json.dumps([{"composerId": "comp-2", "createdAt": 1704067200000}]),
            ),
        )
        conn.commit()
        conn.close()

        sessions = _discover_cursor_sessions(tmp_path)
        assert len(sessions) == 1
        assert sessions[0]["id"] == "comp-2"

    def test_composer_without_id_skipped(self, tmp_path, monkeypatch):
        self._setup_cursor_workspace(
            tmp_path,
            monkeypatch,
            composers=[{"someField": "value"}],  # No composerId
        )
        sessions = _discover_cursor_sessions(tmp_path)
        assert sessions == []

    def test_timestamp_in_seconds(self, tmp_path, monkeypatch):
        """Timestamps < 1e12 are treated as seconds, converted to float directly."""
        self._setup_cursor_workspace(
            tmp_path,
            monkeypatch,
            composers=[{"composerId": "comp-1", "createdAt": 1704067200, "lastUpdatedAt": None}],
        )
        sessions = _discover_cursor_sessions(tmp_path)
        assert len(sessions) == 1
        assert sessions[0]["modified_at"] == 1704067200.0

    def test_non_numeric_timestamp_fallback(self, tmp_path, monkeypatch):
        """Non-numeric timestamps should fall back to file stat."""
        self._setup_cursor_workspace(
            tmp_path,
            monkeypatch,
            composers=[{"composerId": "comp-1", "createdAt": "not-a-number"}],
        )
        sessions = _discover_cursor_sessions(tmp_path)
        assert len(sessions) == 1
        assert sessions[0]["modified_at"] > 0


# =============================================================================
# Gemini session discovery
# =============================================================================


class TestDiscoverGeminiSessions:
    def test_no_gemini_dir(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        sessions = _discover_gemini_sessions(tmp_path)
        assert sessions == []

    def test_discover_project_sessions(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        project_hash = hashlib.sha256(str(tmp_path).encode()).hexdigest()
        chats_dir = tmp_path / ".gemini" / "tmp" / project_hash / "chats"
        chats_dir.mkdir(parents=True)

        chat_file = chats_dir / "chat1.json"
        chat_file.write_text(
            json.dumps({"messages": [{"type": "gemini", "model": "gemini-2.5-pro"}]})
        )

        sessions = _discover_gemini_sessions(tmp_path)
        assert len(sessions) == 1
        assert sessions[0]["format"] == "gemini"
        assert sessions[0]["id"] == "chat1"
        assert sessions[0]["metadata"]["model"] == "gemini-2.5-pro"

    def test_global_search(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        chats_dir = tmp_path / ".gemini" / "tmp" / "somehash" / "chats"
        chats_dir.mkdir(parents=True)

        chat_file = chats_dir / "chat1.json"
        chat_file.write_text(json.dumps({"messages": []}))

        sessions = _discover_gemini_sessions(tmp_path)
        assert len(sessions) == 1
        assert sessions[0]["metadata"]["cwd"].startswith("[hash:")

    def test_skips_non_dir(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        gemini_dir = tmp_path / ".gemini" / "tmp"
        gemini_dir.mkdir(parents=True)

        # Create a file (not directory) in tmp
        (gemini_dir / "not-a-dir").write_text("hi")

        sessions = _discover_gemini_sessions(tmp_path)
        assert sessions == []


# =============================================================================
# OpenCode session discovery
# =============================================================================


class TestDiscoverOpencodeSessions:
    def _setup_opencode(self, tmp_path, monkeypatch) -> Path:
        """Create mock OpenCode storage."""
        storage_dir = tmp_path / "opencode" / "storage"
        session_dir = storage_dir / "session" / "proj-1"
        session_dir.mkdir(parents=True)
        project_dir = storage_dir / "project"
        project_dir.mkdir(parents=True)

        monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path))

        # Write project file
        project_file = project_dir / "proj-1.json"
        project_file.write_text(
            json.dumps({"id": "proj-1", "worktree": str(tmp_path / "myproject")})
        )

        # Create the worktree directory
        (tmp_path / "myproject").mkdir()

        # Write session file
        session_file = session_dir / "sess-1.json"
        session_file.write_text(
            json.dumps(
                {
                    "id": "sess-1",
                    "title": "My Session",
                    "version": "0.1.0",
                    "directory": str(tmp_path / "myproject"),
                    "time": {"created": 1704067200000, "updated": 1704070800000},
                }
            )
        )

        return storage_dir

    def test_no_opencode_dir(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path))
        sessions = _discover_opencode_sessions(tmp_path)
        assert sessions == []

    def test_discover_sessions(self, tmp_path, monkeypatch):
        self._setup_opencode(tmp_path, monkeypatch)

        sessions = _discover_opencode_sessions(tmp_path / "myproject")
        assert len(sessions) == 1
        assert sessions[0]["format"] == "opencode"
        assert sessions[0]["id"] == "sess-1"
        assert sessions[0]["metadata"]["title"] == "My Session"
        assert sessions[0]["modified_at"] == 1704070800.0  # ms -> seconds

    def test_global_search(self, tmp_path, monkeypatch):
        self._setup_opencode(tmp_path, monkeypatch)

        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        sessions = _discover_opencode_sessions(tmp_path)
        assert len(sessions) == 1

    def test_path_mismatch_filtered(self, tmp_path, monkeypatch):
        self._setup_opencode(tmp_path, monkeypatch)

        other = tmp_path / "other-project"
        other.mkdir()
        sessions = _discover_opencode_sessions(other)
        assert sessions == []

    def test_session_without_time(self, tmp_path, monkeypatch):
        """Sessions without time data use file mtime."""
        storage_dir = tmp_path / "opencode" / "storage"
        session_dir = storage_dir / "session" / "proj-1"
        session_dir.mkdir(parents=True)

        monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        session_file = session_dir / "sess-1.json"
        session_file.write_text(json.dumps({"id": "sess-1"}))

        sessions = _discover_opencode_sessions(tmp_path)
        assert len(sessions) == 1
        assert sessions[0]["modified_at"] > 0

    def test_invalid_session_json_skipped(self, tmp_path, monkeypatch):
        storage_dir = tmp_path / "opencode" / "storage"
        session_dir = storage_dir / "session" / "proj-1"
        session_dir.mkdir(parents=True)

        monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        session_file = session_dir / "sess-1.json"
        session_file.write_text("not json")

        sessions = _discover_opencode_sessions(tmp_path)
        assert sessions == []

    def test_session_without_worktree(self, tmp_path, monkeypatch):
        """Session in a project with no worktree mapping uses directory field."""
        storage_dir = tmp_path / "opencode" / "storage"
        session_dir = storage_dir / "session" / "proj-unknown"
        session_dir.mkdir(parents=True)

        monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        session_file = session_dir / "sess-1.json"
        session_file.write_text(
            json.dumps(
                {
                    "id": "sess-1",
                    "directory": "/some/dir",
                    "time": {"created": 1704067200000},
                }
            )
        )

        sessions = _discover_opencode_sessions(tmp_path)
        assert len(sessions) == 1
        assert sessions[0]["metadata"]["cwd"] == "/some/dir"


# =============================================================================
# discover_all_sessions
# =============================================================================


class TestDiscoverAllSessions:
    def test_combines_all_formats(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr(
            "agentstream.discovery._get_cursor_user_dir",
            lambda: tmp_path / "nonexistent",
        )
        monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "nonexistent"))

        # Create only Codex sessions
        codex_dir = tmp_path / ".codex" / "sessions"
        codex_dir.mkdir(parents=True)

        session_file = codex_dir / "s1.jsonl"
        write_jsonl(
            session_file,
            [{"type": "session_meta", "payload": {"cwd": str(tmp_path), "model": "o3"}}],
        )

        sessions = discover_all_sessions(tmp_path)
        assert len(sessions) >= 1
        formats = {s["format"] for s in sessions}
        assert "codex" in formats

    def test_since_ts_filter(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr(
            "agentstream.discovery._get_cursor_user_dir",
            lambda: tmp_path / "nonexistent",
        )
        monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "nonexistent"))

        # Create a Codex session
        codex_dir = tmp_path / ".codex" / "sessions"
        codex_dir.mkdir(parents=True)

        session_file = codex_dir / "s1.jsonl"
        write_jsonl(
            session_file,
            [{"type": "session_meta", "payload": {"cwd": str(tmp_path), "model": "o3"}}],
        )

        # Filter by future timestamp - should return nothing

        sessions = discover_all_sessions(tmp_path, since_ts=time.time() + 10000)
        assert sessions == []

    def test_sorted_by_modification_time(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr(
            "agentstream.discovery._get_cursor_user_dir",
            lambda: tmp_path / "nonexistent",
        )
        monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "nonexistent"))

        codex_dir = tmp_path / ".codex" / "sessions"
        codex_dir.mkdir(parents=True)

        for i in range(3):
            session_file = codex_dir / f"s{i}.jsonl"
            write_jsonl(
                session_file,
                [{"type": "session_meta", "payload": {"cwd": str(tmp_path), "model": "o3"}}],
            )

        sessions = discover_all_sessions(tmp_path)
        # Should be sorted by modified_at, newest first
        for i in range(1, len(sessions)):
            assert sessions[i - 1]["modified_at"] >= sessions[i]["modified_at"]

    def test_since_ts_filters_all_agent_types(self, tmp_path, monkeypatch):
        """since_ts filtering works across Claude, Codex, Gemini, and OpenCode sessions."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr(
            "agentstream.discovery._get_cursor_user_dir",
            lambda: tmp_path / "nonexistent",
        )

        now = time.time()
        old_mtime = now - (180 * 86400)  # 180 days ago
        recent_mtime = now - (30 * 86400)  # 30 days ago
        cutoff = now - (90 * 86400)  # 90 days ago

        # --- Claude: old session ---
        project_path = tmp_path / "myproject"
        project_path.mkdir()
        encoded_name = str(project_path).replace("/", "-")
        claude_dir = tmp_path / ".claude" / "projects" / encoded_name
        claude_dir.mkdir(parents=True)
        claude_old = claude_dir / "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.jsonl"
        write_jsonl(
            claude_old,
            [
                {
                    "type": "user",
                    "message": {"content": "old"},
                    "uuid": "u1",
                    "cwd": str(project_path),
                    "timestamp": "2024-01-01T00:00:00Z",
                }
            ],
        )
        os.utime(claude_old, (old_mtime, old_mtime))

        # --- Claude: recent session ---
        claude_new = claude_dir / "11111111-2222-3333-4444-555555555555.jsonl"
        write_jsonl(
            claude_new,
            [
                {
                    "type": "user",
                    "message": {"content": "new"},
                    "uuid": "u2",
                    "cwd": str(project_path),
                    "timestamp": "2025-12-01T00:00:00Z",
                }
            ],
        )
        os.utime(claude_new, (recent_mtime, recent_mtime))

        # --- Codex: old session ---
        codex_dir = tmp_path / ".codex" / "sessions"
        codex_dir.mkdir(parents=True)
        codex_old = codex_dir / "old-codex.jsonl"
        write_jsonl(
            codex_old,
            [{"type": "session_meta", "payload": {"cwd": str(tmp_path), "model": "o3"}}],
        )
        os.utime(codex_old, (old_mtime, old_mtime))

        # --- Codex: recent session ---
        codex_new = codex_dir / "new-codex.jsonl"
        write_jsonl(
            codex_new,
            [{"type": "session_meta", "payload": {"cwd": str(tmp_path), "model": "o3"}}],
        )
        os.utime(codex_new, (recent_mtime, recent_mtime))

        # --- Gemini: old session ---
        gemini_hash = hashlib.sha256(str(tmp_path).encode()).hexdigest()
        chats_dir = tmp_path / ".gemini" / "tmp" / gemini_hash / "chats"
        chats_dir.mkdir(parents=True)
        gemini_old = chats_dir / "old-chat.json"
        gemini_old.write_text(json.dumps({"messages": []}))
        os.utime(gemini_old, (old_mtime, old_mtime))

        # --- Gemini: recent session ---
        gemini_new = chats_dir / "new-chat.json"
        gemini_new.write_text(json.dumps({"messages": []}))
        os.utime(gemini_new, (recent_mtime, recent_mtime))

        # --- OpenCode: old session ---
        storage_dir = tmp_path / "opencode" / "storage"
        oc_session_dir = storage_dir / "session" / "proj-1"
        oc_session_dir.mkdir(parents=True)
        oc_project_dir = storage_dir / "project"
        oc_project_dir.mkdir(parents=True)
        oc_project_dir_file = oc_project_dir / "proj-1.json"
        oc_project_dir_file.write_text(json.dumps({"id": "proj-1", "worktree": str(project_path)}))
        monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path))

        # Old OpenCode session (using ms timestamps in session data)
        old_ts_ms = int(old_mtime * 1000)
        oc_old = oc_session_dir / "oc-old.json"
        oc_old.write_text(
            json.dumps(
                {
                    "id": "oc-old",
                    "title": "Old",
                    "version": "0.1.0",
                    "directory": str(project_path),
                    "time": {"created": old_ts_ms, "updated": old_ts_ms},
                }
            )
        )

        # Recent OpenCode session
        recent_ts_ms = int(recent_mtime * 1000)
        oc_new = oc_session_dir / "oc-new.json"
        oc_new.write_text(
            json.dumps(
                {
                    "id": "oc-new",
                    "title": "New",
                    "version": "0.1.0",
                    "directory": str(project_path),
                    "time": {"created": recent_ts_ms, "updated": recent_ts_ms},
                }
            )
        )

        # Without filter: should find all sessions (8 total: 2 per agent type)
        all_sessions = discover_all_sessions(tmp_path, since_ts=None)
        all_formats = {s["format"] for s in all_sessions}
        assert "claude" in all_formats
        assert "codex" in all_formats
        assert "gemini" in all_formats
        assert "opencode" in all_formats
        assert len(all_sessions) == 8

        # With 90-day cutoff: should only find the 4 recent sessions
        filtered = discover_all_sessions(tmp_path, since_ts=cutoff)
        assert len(filtered) == 4
        filtered_formats = {s["format"] for s in filtered}
        assert filtered_formats == {"claude", "codex", "gemini", "opencode"}
        for s in filtered:
            assert s["modified_at"] >= cutoff, (
                f"{s['format']} session {s['id']} has modified_at={s['modified_at']}, "
                f"expected >= {cutoff}"
            )


# =============================================================================
# get_cursor_user_dir
# =============================================================================


class TestGetCursorUserDir:
    def test_darwin(self, monkeypatch):
        monkeypatch.setattr("platform.system", lambda: "Darwin")
        result = _get_cursor_user_dir()
        assert "Application Support" in str(result)
        assert "Cursor" in str(result)

    def test_linux(self, monkeypatch):
        monkeypatch.setattr("platform.system", lambda: "Linux")
        result = _get_cursor_user_dir()
        assert ".config" in str(result)

    def test_windows(self, monkeypatch):
        monkeypatch.setattr("platform.system", lambda: "Windows")
        result = _get_cursor_user_dir()
        assert "AppData" in str(result)

    def test_unknown(self, monkeypatch):
        monkeypatch.setattr("platform.system", lambda: "FreeBSD")
        result = _get_cursor_user_dir()
        assert ".cursor" in str(result)


# =============================================================================
# get_session_cwd
# =============================================================================


class TestGetSessionCwd:
    def test_cwd_from_metadata(self):
        session = {
            "path": Path("/tmp/session.jsonl"),
            "format": "claude",
            "metadata": {"cwd": "/home/user/project"},
        }
        result = get_session_cwd(session)
        assert result == Path("/home/user/project")

    def test_hash_placeholder_cwd(self, tmp_path):
        """Gemini global mode uses [hash:...] placeholder."""
        session_file = tmp_path / "session.json"
        session_file.write_text(json.dumps({"messages": []}))

        session = {
            "path": session_file,
            "format": "gemini",
            "metadata": {"cwd": "[hash:abc123...]"},
        }
        result = get_session_cwd(session)
        # No paths in the session, so extraction fails -> returns None
        assert result is None

    def test_no_metadata_cwd_claude_fallback(self, tmp_path):
        """Claude without cwd in metadata falls back to file parsing."""
        session_file = tmp_path / "session.jsonl"
        write_jsonl(
            session_file,
            [{"type": "user", "cwd": "/home/user/project", "timestamp": "2024-01-01T00:00:00Z"}],
        )

        session = {
            "path": session_file,
            "format": "claude",
            "metadata": {},
        }
        result = get_session_cwd(session)
        assert result == Path("/home/user/project")

    def test_codex_cwd_from_file(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(
            session_file,
            [{"type": "session_meta", "payload": {"cwd": "/home/user/project"}}],
        )

        session = {
            "path": session_file,
            "format": "codex",
            "metadata": {},
        }
        result = get_session_cwd(session)
        assert result == Path("/home/user/project")

    def test_cursor_folder_path(self):
        session = {
            "path": Path("/tmp/state.vscdb"),
            "format": "cursor",
            "metadata": {"folder_path": "/home/user/project"},
        }
        result = get_session_cwd(session)
        assert result == Path("/home/user/project")

    def test_cursor_workspace_json_fallback(self, tmp_path):
        workspace_dir = tmp_path / "workspace"
        workspace_dir.mkdir()
        workspace_json = workspace_dir / "workspace.json"
        workspace_json.write_text(json.dumps({"folder": "file:///home/user/project"}))

        session = {
            "path": tmp_path / "state.vscdb",
            "format": "cursor",
            "metadata": {"workspace_dir": str(workspace_dir)},
        }
        result = get_session_cwd(session)
        assert result == Path("/home/user/project")

    def test_unknown_format_returns_none(self):
        session = {
            "path": Path("/tmp/file"),
            "format": "unknown",
            "metadata": {},
        }
        result = get_session_cwd(session)
        assert result is None


# =============================================================================
# extract_cwd_from_file
# =============================================================================


class TestExtractCwdFromFile:
    def test_claude_cwd(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(session_file, [{"type": "user", "cwd": "/project"}])

        result = extract_cwd_from_file(session_file, "claude")
        assert result == Path("/project")

    def test_claude_no_cwd(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(session_file, [{"type": "user"}])

        result = extract_cwd_from_file(session_file, "claude")
        assert result is None

    def test_claude_nonexistent_file(self, tmp_path):
        result = extract_cwd_from_file(tmp_path / "nope.jsonl", "claude")
        assert result is None

    def test_codex_cwd(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(
            session_file,
            [{"type": "session_meta", "payload": {"cwd": "/project"}}],
        )

        result = extract_cwd_from_file(session_file, "codex")
        assert result == Path("/project")

    def test_codex_no_cwd(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(session_file, [{"type": "session_meta", "payload": {}}])

        result = extract_cwd_from_file(session_file, "codex")
        assert result is None

    def test_cursor_returns_none(self, tmp_path):
        result = extract_cwd_from_file(tmp_path / "state.vscdb", "cursor")
        assert result is None

    def test_unknown_format_returns_none(self, tmp_path):
        result = extract_cwd_from_file(tmp_path / "file", "unknown")
        assert result is None


# =============================================================================
# _extract_gemini_file_paths
# =============================================================================


class TestExtractGeminiFilePaths:
    def test_paths_from_content(self):
        data = {
            "messages": [
                {"content": "I'll read /Users/test/project/main.py for you"},
            ]
        }
        paths = _extract_gemini_file_paths(data)
        assert "/Users/test/project/main.py" in paths

    def test_paths_from_tool_args(self):
        data = {
            "messages": [
                {
                    "toolCalls": [
                        {"args": {"file_path": "/home/user/file.py"}},
                        {"args": {"path": "/home/user/other.py"}},
                    ]
                }
            ]
        }
        paths = _extract_gemini_file_paths(data)
        assert "/home/user/file.py" in paths
        assert "/home/user/other.py" in paths

    def test_paths_from_tool_results(self):
        data = {
            "messages": [
                {
                    "toolCalls": [
                        {
                            "args": {},
                            "result": [
                                {
                                    "functionResponse": {
                                        "response": {
                                            "error": "File not found: /Users/test/missing.py"
                                        }
                                    }
                                }
                            ],
                        }
                    ]
                }
            ]
        }
        paths = _extract_gemini_file_paths(data)
        assert "/Users/test/missing.py" in paths

    def test_empty_messages(self):
        paths = _extract_gemini_file_paths({"messages": []})
        assert paths == []

    def test_no_messages_key(self):
        paths = _extract_gemini_file_paths({})
        assert paths == []

    def test_non_absolute_paths_ignored(self):
        data = {"messages": [{"toolCalls": [{"args": {"path": "relative/path.py"}}]}]}
        paths = _extract_gemini_file_paths(data)
        assert paths == []

    def test_non_string_content_ignored(self):
        data = {"messages": [{"content": 42}]}
        paths = _extract_gemini_file_paths(data)
        assert paths == []

    def test_non_dict_results_skipped(self):
        data = {"messages": [{"toolCalls": [{"args": {}, "result": ["not a dict", 42]}]}]}
        paths = _extract_gemini_file_paths(data)
        assert paths == []


# =============================================================================
# _read_claude_entries
# =============================================================================


class TestReadClaudeEntries:
    def test_basic_entries(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(
            session_file,
            [
                {"type": "user", "timestamp": "2024-01-01T00:00:00Z"},
                {"type": "assistant", "timestamp": "2024-01-01T00:00:01Z"},
            ],
        )
        entries = _read_claude_entries(session_file)
        assert len(entries) == 2
        assert entries[0]["entry_index"] == 0
        assert entries[1]["entry_index"] == 1
        assert entries[0]["entry_timestamp_ms"] == 1704067200000

    def test_strips_normalized_messages(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(
            session_file,
            [
                {
                    "type": "progress",
                    "data": {
                        "normalizedMessages": [{"role": "user", "content": "big data"}],
                        "status": "running",
                    },
                    "timestamp": "2024-01-01T00:00:00Z",
                }
            ],
        )
        entries = _read_claude_entries(session_file)
        assert len(entries) == 1
        content = json.loads(entries[0]["entry_content"])
        assert "normalizedMessages" not in content["data"]
        assert content["data"]["status"] == "running"

    def test_preserves_non_progress_entries(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        original = {
            "type": "user",
            "message": {"content": "Hello"},
            "timestamp": "2024-01-01T00:00:00Z",
        }
        write_jsonl(session_file, [original])
        entries = _read_claude_entries(session_file)
        assert entries[0]["entry_content"] == json.dumps(original)

    def test_skips_invalid_json(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        session_file.write_text('{"valid":"json","timestamp":"2024-01-01T00:00:00Z"}\nnot json\n')
        entries = _read_claude_entries(session_file)
        assert len(entries) == 1

    def test_empty_file(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        session_file.write_text("")
        entries = _read_claude_entries(session_file)
        assert entries == []


# =============================================================================
# _read_codex_entries
# =============================================================================


class TestReadCodexEntries:
    def test_basic_entries(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(
            session_file,
            [
                {"type": "session_meta", "timestamp": "2024-01-01T00:00:00Z"},
                {"type": "message", "timestamp": "2024-01-01T00:00:01Z"},
            ],
        )
        entries = _read_codex_entries(session_file)
        assert len(entries) == 2
        assert entries[0]["entry_index"] == 0
        assert entries[1]["entry_index"] == 1

    def test_preserves_raw_content(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        original = {
            "type": "message",
            "payload": {"content": "Hi"},
            "timestamp": "2024-01-01T00:00:00Z",
        }
        write_jsonl(session_file, [original])
        entries = _read_codex_entries(session_file)
        assert json.loads(entries[0]["entry_content"]) == original

    def test_skips_invalid_json(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        session_file.write_text('{"valid":"entry","timestamp":"2024-01-01T00:00:00Z"}\nbad line\n')
        entries = _read_codex_entries(session_file)
        assert len(entries) == 1


# =============================================================================
# _read_cursor_entries
# =============================================================================


class TestReadCursorEntries:
    def test_reads_bubbles(self, tmp_path):
        cursor_user = tmp_path / "CursorUser"
        global_storage = cursor_user / "globalStorage"
        global_storage.mkdir(parents=True)

        global_db = global_storage / "state.vscdb"
        conn = sqlite3.connect(str(global_db))
        conn.execute("CREATE TABLE cursorDiskKV (key TEXT PRIMARY KEY, value BLOB)")
        conn.execute(
            "INSERT INTO cursorDiskKV (key, value) VALUES (?, ?)",
            (
                "bubbleId:comp-1:b1",
                json.dumps(
                    {
                        "bubbleId": "b1",
                        "type": 1,
                        "text": "Hello",
                        "createdAt": "2024-01-01T00:00:00Z",
                    }
                ),
            ),
        )
        conn.execute(
            "INSERT INTO cursorDiskKV (key, value) VALUES (?, ?)",
            (
                "bubbleId:comp-1:b2",
                json.dumps(
                    {
                        "bubbleId": "b2",
                        "type": 2,
                        "text": "Hi!",
                        "createdAt": "2024-01-01T00:00:01Z",
                    }
                ),
            ),
        )
        conn.commit()
        conn.close()

        session = {
            "path": tmp_path / "state.vscdb",
            "format": "cursor",
            "metadata": {"composerId": "comp-1", "cursor_user": str(cursor_user)},
        }
        entries = _read_cursor_entries(session)
        assert len(entries) == 2
        assert entries[0]["entry_index"] == 0
        assert entries[1]["entry_index"] == 1

    def test_missing_composer_id(self):
        session = {"path": Path("/tmp/db"), "format": "cursor", "metadata": {"cursor_user": "/tmp"}}
        entries = _read_cursor_entries(session)
        assert entries == []

    def test_missing_cursor_user(self):
        session = {"path": Path("/tmp/db"), "format": "cursor", "metadata": {"composerId": "c1"}}
        entries = _read_cursor_entries(session)
        assert entries == []

    def test_missing_global_db(self, tmp_path):
        session = {
            "path": tmp_path / "state.vscdb",
            "format": "cursor",
            "metadata": {"composerId": "c1", "cursor_user": str(tmp_path / "nonexistent")},
        }
        entries = _read_cursor_entries(session)
        assert entries == []

    def test_invalid_json_bubbles_skipped(self, tmp_path):
        cursor_user = tmp_path / "CursorUser"
        global_storage = cursor_user / "globalStorage"
        global_storage.mkdir(parents=True)

        global_db = global_storage / "state.vscdb"
        conn = sqlite3.connect(str(global_db))
        conn.execute("CREATE TABLE cursorDiskKV (key TEXT PRIMARY KEY, value BLOB)")
        conn.execute(
            "INSERT INTO cursorDiskKV (key, value) VALUES (?, ?)",
            ("bubbleId:comp-1:b1", "not json"),
        )
        conn.execute(
            "INSERT INTO cursorDiskKV (key, value) VALUES (?, ?)",
            (
                "bubbleId:comp-1:b2",
                json.dumps({"bubbleId": "b2", "createdAt": "2024-01-01T00:00:00Z"}),
            ),
        )
        conn.commit()
        conn.close()

        session = {
            "path": tmp_path / "state.vscdb",
            "format": "cursor",
            "metadata": {"composerId": "comp-1", "cursor_user": str(cursor_user)},
        }
        entries = _read_cursor_entries(session)
        assert len(entries) == 1


# =============================================================================
# _read_gemini_entries
# =============================================================================


class TestReadGeminiEntries:
    def test_reads_messages(self, tmp_path):
        session_file = tmp_path / "session.json"
        session_file.write_text(
            json.dumps(
                {
                    "messages": [
                        {"type": "user", "content": "Hello", "timestamp": "2024-01-01T00:00:00Z"},
                        {"type": "gemini", "content": "Hi!", "timestamp": "2024-01-01T00:00:01Z"},
                    ]
                }
            )
        )
        session = {"path": session_file, "format": "gemini"}
        entries = _read_gemini_entries(session)
        assert len(entries) == 2
        assert entries[0]["entry_index"] == 0

    def test_skips_non_dict_messages(self, tmp_path):
        session_file = tmp_path / "session.json"
        session_file.write_text(
            json.dumps(
                {
                    "messages": [
                        {"type": "user", "timestamp": "2024-01-01T00:00:00Z"},
                        "not a dict",
                        42,
                    ]
                }
            )
        )
        session = {"path": session_file, "format": "gemini"}
        entries = _read_gemini_entries(session)
        assert len(entries) == 1

    def test_non_list_messages(self, tmp_path):
        session_file = tmp_path / "session.json"
        session_file.write_text(json.dumps({"messages": "not a list"}))
        session = {"path": session_file, "format": "gemini"}
        entries = _read_gemini_entries(session)
        assert entries == []

    def test_invalid_json_file(self, tmp_path):
        session_file = tmp_path / "session.json"
        session_file.write_text("not json")
        session = {"path": session_file, "format": "gemini"}
        entries = _read_gemini_entries(session)
        assert entries == []

    def test_nonexistent_file(self, tmp_path):
        session = {"path": tmp_path / "nope.json", "format": "gemini"}
        entries = _read_gemini_entries(session)
        assert entries == []


# =============================================================================
# extract_cwd_from_file - Gemini path
# =============================================================================


class TestExtractCwdFromFileGemini:
    def test_gemini_cwd_from_tool_paths(self, tmp_path, monkeypatch):
        """Gemini extracts cwd from common prefix of file paths."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        # Create a project directory structure
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()
        (project_dir / ".git").mkdir()
        (project_dir / "src").mkdir()
        (project_dir / "src" / "main.py").write_text("")

        session_file = tmp_path / "session.json"
        session_file.write_text(
            json.dumps(
                {
                    "messages": [
                        {
                            "toolCalls": [
                                {"args": {"file_path": str(project_dir / "src" / "main.py")}},
                            ]
                        }
                    ]
                }
            )
        )
        result = extract_cwd_from_file(session_file, "gemini")
        assert result == project_dir

    def test_gemini_no_paths(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        session_file = tmp_path / "session.json"
        session_file.write_text(json.dumps({"messages": []}))
        result = extract_cwd_from_file(session_file, "gemini")
        assert result is None

    def test_gemini_invalid_json(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        session_file = tmp_path / "session.json"
        session_file.write_text("not json")
        result = extract_cwd_from_file(session_file, "gemini")
        assert result is None

    def test_codex_invalid_json(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        session_file.write_text("not json\n")
        result = extract_cwd_from_file(session_file, "codex")
        assert result is None

    def test_codex_non_session_meta(self, tmp_path):
        session_file = tmp_path / "session.jsonl"
        write_jsonl(session_file, [{"type": "message"}])
        result = extract_cwd_from_file(session_file, "codex")
        assert result is None
