"""Generic tests for adapter timestamp handling.

Verifies that all adapters:
1. Produce events with valid (non-zero) timestamps
2. Produce events in non-decreasing timestamp order
3. Handle missing timestamps gracefully
"""

from pathlib import Path

import pytest

from agentstream.adapters.base import Session
from agentstream.adapters.claude import ClaudeAdapter
from agentstream.adapters.codex import CodexAdapter
from agentstream.adapters.gemini import GeminiAdapter

# Path to test fixtures (project_root/tests/fixtures)
FIXTURES_DIR = Path(__file__).parent.parent.parent / "tests" / "fixtures"


class TestClaudeAdapterTimestamps:
    """Verify Claude adapter timestamp handling with realistic fixtures."""

    @pytest.fixture
    def adapter(self):
        return ClaudeAdapter()

    @pytest.mark.parametrize(
        "fixture_name",
        [
            "simple.jsonl",
            "with_thinking.jsonl",
            "with_tools.jsonl",
        ],
    )
    def test_all_events_have_valid_timestamps(self, adapter, fixture_name):
        """All events should have non-zero timestamps."""
        fixture_path = FIXTURES_DIR / "claude" / fixture_name
        if not fixture_path.exists():
            pytest.skip(f"Fixture not found: {fixture_path}")

        session = Session(
            id="test-session",
            path=fixture_path,
            format="claude",
            modified_at=fixture_path.stat().st_mtime,
        )
        events = list(adapter.read_events(session))

        for i, event in enumerate(events):
            assert event.timestamp_ms > 0, (
                f"Event {i} ({event.type}) has invalid timestamp: {event.timestamp_ms}"
            )

    @pytest.mark.parametrize(
        "fixture_name",
        [
            "simple.jsonl",
            "with_thinking.jsonl",
            "with_tools.jsonl",
        ],
    )
    def test_timestamps_non_decreasing(self, adapter, fixture_name):
        """Timestamps should be non-decreasing (monotonic)."""
        fixture_path = FIXTURES_DIR / "claude" / fixture_name
        if not fixture_path.exists():
            pytest.skip(f"Fixture not found: {fixture_path}")

        session = Session(
            id="test-session",
            path=fixture_path,
            format="claude",
            modified_at=fixture_path.stat().st_mtime,
        )
        events = list(adapter.read_events(session))

        prev_ts = 0
        for i, event in enumerate(events):
            assert event.timestamp_ms >= prev_ts, (
                f"Event {i} ({event.type}) has timestamp {event.timestamp_ms} < previous {prev_ts}"
            )
            prev_ts = event.timestamp_ms


class TestGeminiAdapterTimestamps:
    """Verify Gemini adapter timestamp handling with realistic fixtures."""

    @pytest.fixture
    def adapter(self):
        return GeminiAdapter()

    @pytest.mark.parametrize(
        "fixture_name",
        [
            "simple.json",
            "with_thoughts.json",
            "with_tool_calls.json",
        ],
    )
    def test_all_events_have_valid_timestamps(self, adapter, fixture_name):
        """All events should have non-zero timestamps."""
        fixture_path = FIXTURES_DIR / "gemini" / fixture_name
        if not fixture_path.exists():
            pytest.skip(f"Fixture not found: {fixture_path}")

        session = Session(
            id="test-session",
            path=fixture_path,
            format="gemini",
            modified_at=fixture_path.stat().st_mtime,
        )
        events = list(adapter.read_events(session))

        for i, event in enumerate(events):
            assert event.timestamp_ms > 0, (
                f"Event {i} ({event.type}) has invalid timestamp: {event.timestamp_ms}"
            )

    @pytest.mark.parametrize(
        "fixture_name",
        [
            "simple.json",
            "with_thoughts.json",
            "with_tool_calls.json",
        ],
    )
    def test_timestamps_non_decreasing(self, adapter, fixture_name):
        """Timestamps should be non-decreasing (monotonic)."""
        fixture_path = FIXTURES_DIR / "gemini" / fixture_name
        if not fixture_path.exists():
            pytest.skip(f"Fixture not found: {fixture_path}")

        session = Session(
            id="test-session",
            path=fixture_path,
            format="gemini",
            modified_at=fixture_path.stat().st_mtime,
        )
        events = list(adapter.read_events(session))

        prev_ts = 0
        for i, event in enumerate(events):
            assert event.timestamp_ms >= prev_ts, (
                f"Event {i} ({event.type}) has timestamp {event.timestamp_ms} < previous {prev_ts}"
            )
            prev_ts = event.timestamp_ms


class TestCodexAdapterTimestamps:
    """Verify Codex adapter timestamp handling with realistic fixtures."""

    @pytest.fixture
    def adapter(self):
        return CodexAdapter()

    @pytest.mark.parametrize(
        "fixture_name",
        [
            "simple.jsonl",
            "with_reasoning.jsonl",
            "with_function_calls.jsonl",
        ],
    )
    def test_all_events_have_valid_timestamps(self, adapter, fixture_name):
        """All events should have non-zero timestamps."""
        fixture_path = FIXTURES_DIR / "codex" / fixture_name
        if not fixture_path.exists():
            pytest.skip(f"Fixture not found: {fixture_path}")

        session = Session(
            id="test-session",
            path=fixture_path,
            format="codex",
            modified_at=fixture_path.stat().st_mtime,
        )
        events = list(adapter.read_events(session))

        for i, event in enumerate(events):
            assert event.timestamp_ms > 0, (
                f"Event {i} ({event.type}) has invalid timestamp: {event.timestamp_ms}"
            )

    @pytest.mark.parametrize(
        "fixture_name",
        [
            "simple.jsonl",
            "with_reasoning.jsonl",
            "with_function_calls.jsonl",
        ],
    )
    def test_timestamps_non_decreasing(self, adapter, fixture_name):
        """Timestamps should be non-decreasing (monotonic)."""
        fixture_path = FIXTURES_DIR / "codex" / fixture_name
        if not fixture_path.exists():
            pytest.skip(f"Fixture not found: {fixture_path}")

        session = Session(
            id="test-session",
            path=fixture_path,
            format="codex",
            modified_at=fixture_path.stat().st_mtime,
        )
        events = list(adapter.read_events(session))

        prev_ts = 0
        for i, event in enumerate(events):
            assert event.timestamp_ms >= prev_ts, (
                f"Event {i} ({event.type}) has timestamp {event.timestamp_ms} < previous {prev_ts}"
            )
            prev_ts = event.timestamp_ms
