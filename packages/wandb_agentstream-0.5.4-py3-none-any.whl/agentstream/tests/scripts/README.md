# Test Utility Scripts

This directory contains utility scripts for analyzing sessions and extracting test fixtures. These are **NOT tests** - they are tools for developers to run manually.

## Scripts

### `analyze_cursor_sessions.py`

Analyzes recent Cursor sessions to understand file editing tool call formats.

**Usage:**
```bash
python agentstream/tests/scripts/analyze_cursor_sessions.py
```

**Output:**
- `agentstream/tests/fixtures/cursor_session_analysis.json` - Full analysis (not committed)
- `agentstream/tests/fixtures/cursor_format_examples.json` - Example tool calls (committed)

**Purpose:** Understand distribution of tool formats in real sessions, extract example data for tests.

### `extract_cursor_events.py`

Extracts tool call events from the most recent Cursor session on your local machine.

**Usage:**
```bash
python agentstream/tests/scripts/extract_cursor_events.py
```

**Output:**
- `agentstream/tests/fixtures/cursor_edit_events.json` - Event data (committed)

**Purpose:** Create test fixtures from real Cursor sessions.

### `extract_cursor_session.py`

Extracts Cursor session data from ClickHouse database.

**Usage:**
```bash
python agentstream/tests/scripts/extract_cursor_session.py
```

**Requirements:**
- ClickHouse running on localhost:8123
- agentstream database with session data

**Output:**
- `agentstream/tests/fixtures/cursor_diff_events.json` - Event data (committed)

**Purpose:** Extract test fixtures from ingested session data.

## Adding New Scripts

When adding new analysis/extraction scripts:

1. **Add clear docstring** with "UTILITY SCRIPT - Not a test" marker
2. **Include usage instructions** in docstring
3. **Document output files** and whether they should be committed
4. **Update this README** with script description

## Generated Files

Files in `agentstream/tests/fixtures/`:

- **Committed** (test fixtures):
  - `cursor_format_examples.json` - Example tool calls for testing
  - `cursor_edit_events.json` - Real event data for tests
  - `cursor_diff_events.json` - Real diff events for tests
  - `codex_apply_patch_events.json` - Codex examples

- **Not committed** (analysis output):
  - `cursor_session_analysis.json` - Analysis metadata (add to .gitignore)

See `agentstream/tests/fixtures/README.md` for fixture documentation.
