#!/usr/bin/env python3
"""Extract tool call events from the latest Cursor session.

UTILITY SCRIPT - Not a test. Run manually to extract Cursor session data.

Usage:
    python agentstream/tests/scripts/extract_cursor_events.py

Output:
    - Prints tool call events from the most recent Cursor session
    - Saves to agentstream/tests/fixtures/cursor_edit_events.json
"""

import json
from pathlib import Path

from agentstream.adapters.cursor import CursorAdapter
from agentstream.events import ToolCallChunkEvent, ToolCallResultEvent


def main():
    adapter = CursorAdapter()
    project_dir = Path.cwd()
    sessions = adapter.discover_sessions(project_dir)

    if not sessions:
        print("No Cursor sessions found!")
        return

    # Get the most recent session
    latest_session = sessions[0]
    print(f"Processing session: {latest_session.id}")
    print(f"Name: {(latest_session.metadata or {}).get('name', 'N/A')}")
    print(f"Modified: {latest_session.modified_at}")
    print()

    # Extract events
    events = list(adapter.read_events(latest_session))
    print(f"Total events: {len(events)}")

    # Filter to tool calls and results
    tool_events = []
    for event in events:
        if isinstance(event, ToolCallChunkEvent):
            tool_events.append(
                {
                    "event_type": "tool_call",
                    "tool_call_id": event.tool_call_id,
                    "tool_name": event.tool_call_name,
                    "args": event.delta,
                    "timestamp_ms": event.timestamp_ms,
                }
            )
        elif isinstance(event, ToolCallResultEvent):
            tool_events.append(
                {
                    "event_type": "tool_result",
                    "tool_call_id": event.tool_call_id,
                    "result": event.result,
                    "timestamp_ms": event.timestamp_ms,
                }
            )

    print(f"Tool call events: {len(tool_events)}")
    print()

    # Show file operations
    file_ops = [
        e
        for e in tool_events
        if e["event_type"] == "tool_call"
        and e["tool_name"] in ["edit_file_v2", "write_file", "read_file_v2"]
    ]

    print(f"File operations: {len(file_ops)}")
    for i, op in enumerate(file_ops, 1):
        try:
            args = json.loads(op["args"])
            file_path = (
                args.get("relativeWorkspacePath")
                or args.get("targetFile")
                or args.get("filePath")
                or "unknown"
            )
            print(f"{i}. {op['tool_name']:20} | {file_path}")
        except (json.JSONDecodeError, KeyError):
            print(f"{i}. {op['tool_name']:20} | (parse error)")

    # Save all tool events to fixture
    output_dir = Path("agentstream/tests/fixtures")
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = output_dir / "cursor_edit_events.json"

    fixture_data = {
        "description": "Cursor edit events extracted from real session",
        "session_id": latest_session.id,
        "session_metadata": latest_session.metadata,
        "events": tool_events,
    }

    with open(output_file, "w") as f:
        json.dump(fixture_data, f, indent=2)

    print(f"\n✅ Saved {len(tool_events)} events to {output_file}")

    # Show a sample event
    if file_ops:
        print("\n📄 Sample file operation:")
        print(json.dumps(file_ops[0], indent=2)[:800])


if __name__ == "__main__":
    main()
