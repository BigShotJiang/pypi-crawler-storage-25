#!/usr/bin/env python3
"""Analyze recent Cursor sessions to understand file editing tool call formats.

UTILITY SCRIPT - Not a test. Run manually to analyze Cursor session data.

This script:
1. Discovers Cursor sessions from the last week
2. Reads all tool call events
3. Extracts and categorizes file editing tool formats
4. Saves raw data for further analysis

Usage:
    python agentstream/tests/scripts/analyze_cursor_sessions.py

Output:
    - agentstream/tests/fixtures/cursor_session_analysis.json - Full analysis
    - agentstream/tests/fixtures/cursor_format_examples.json - Example tool calls
"""

import json
import sys
from datetime import datetime
from pathlib import Path

# Add root to path to import agentstream
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from agentstream.adapters.cursor import CursorAdapter
from agentstream.events import ToolCallChunkEvent, ToolCallResultEvent


def analyze_cursor_sessions(project_dir: Path, days_back: int = 7):
    """Analyze Cursor sessions from the last N days.

    Args:
        project_dir: Project directory to search for sessions
        days_back: How many days back to analyze
    """
    adapter = CursorAdapter()

    # Discover all sessions
    print(f"Discovering Cursor sessions in {project_dir}...")
    sessions = adapter.discover_sessions(project_dir)

    if not sessions:
        print("No Cursor sessions found.")
        return

    print(f"Found {len(sessions)} total sessions")

    # Filter to sessions from last N days
    cutoff_time = datetime.now().timestamp() - (days_back * 24 * 60 * 60)
    recent_sessions = [s for s in sessions if s.modified_at >= cutoff_time]

    print(f"Found {len(recent_sessions)} sessions from last {days_back} days")

    # Collect all file editing tool calls
    file_edit_tools = {}
    all_tool_names = set()
    session_summaries = []

    for session in recent_sessions:
        session_info = {
            "id": session.id,
            "modified_at": datetime.fromtimestamp(session.modified_at).isoformat(),
            "name": session.metadata.get("name", "Unknown") if session.metadata else "Unknown",
            "tool_calls": [],
        }

        print(f"\nAnalyzing session: {session_info['name']}")
        print(f"  Modified: {session_info['modified_at']}")

        # Read events and extract tool calls
        tool_call_map = {}

        for event in adapter.read_events(session):
            if isinstance(event, ToolCallChunkEvent):
                all_tool_names.add(event.tool_call_name)

                # Parse args
                try:
                    args = json.loads(event.delta) if event.delta else {}
                except json.JSONDecodeError:
                    args = {"raw": event.delta}

                tool_call_map[event.tool_call_id] = {
                    "tool_name": event.tool_call_name,
                    "args": args,
                    "timestamp_ms": event.timestamp_ms,
                }

            elif isinstance(event, ToolCallResultEvent):
                if event.tool_call_id in tool_call_map:
                    # Parse result
                    try:
                        result = json.loads(event.result) if event.result else {}
                    except json.JSONDecodeError:
                        result = {"raw": event.result}

                    tool_call_map[event.tool_call_id]["result"] = result

        # Filter for file editing tools
        file_editing_tool_names = {
            "write",
            "write_file",
            "create_file",
            "save_file",
            "edit_file_v2",
            "edit_file",
            "apply_edit",
            "replace_in_file",
            "str_replace_editor",
            "search_replace",
        }

        for _tool_call_id, tool_data in tool_call_map.items():
            tool_name = tool_data["tool_name"]

            if tool_name in file_editing_tool_names:
                # Store this tool call for analysis
                if tool_name not in file_edit_tools:
                    file_edit_tools[tool_name] = []

                file_edit_tools[tool_name].append(
                    {
                        "session_id": session.id,
                        "session_name": session_info["name"],
                        **tool_data,
                    }
                )

                session_info["tool_calls"].append(
                    {
                        "tool_name": tool_name,
                        "has_result": "result" in tool_data,
                        "has_diff_chunks": (
                            "result" in tool_data
                            and isinstance(tool_data.get("result"), dict)
                            and "diff" in tool_data["result"]
                            and "chunks" in tool_data["result"].get("diff", {})
                        ),
                    }
                )

        if session_info["tool_calls"]:
            session_summaries.append(session_info)
            print(f"  Found {len(session_info['tool_calls'])} file editing tool calls")

    # Print summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)

    print(f"\nAll tool names seen across {len(recent_sessions)} sessions:")
    for tool_name in sorted(all_tool_names):
        print(f"  - {tool_name}")

    print("\nFile editing tools found:")
    for tool_name, calls in sorted(file_edit_tools.items()):
        print(f"\n  {tool_name}: {len(calls)} calls")

        # Analyze format
        has_diff_chunks = sum(
            1
            for call in calls
            if isinstance(call.get("result"), dict)
            and "diff" in call["result"]
            and "chunks" in call["result"].get("diff", {})
        )
        has_content_hashes = sum(
            1
            for call in calls
            if isinstance(call.get("result"), dict)
            and "beforeContentId" in call["result"]
            and "afterContentId" in call["result"]
        )
        has_no_result = sum(1 for call in calls if "result" not in call)

        print(f"    - With diff.chunks: {has_diff_chunks}")
        print(f"    - With content hashes: {has_content_hashes}")
        print(f"    - No result: {has_no_result}")

    # Save detailed data
    output_file = Path(__file__).parent.parent / "fixtures" / "cursor_session_analysis.json"
    output_data = {
        "analyzed_at": datetime.now().isoformat(),
        "days_back": days_back,
        "total_sessions": len(sessions),
        "recent_sessions": len(recent_sessions),
        "all_tool_names": sorted(all_tool_names),
        "file_edit_tools": file_edit_tools,
        "session_summaries": session_summaries,
    }

    with open(output_file, "w") as f:
        json.dump(output_data, f, indent=2)

    print(f"\nDetailed analysis saved to: {output_file}")

    # Save examples of each format
    examples_file = Path(__file__).parent.parent / "fixtures" / "cursor_format_examples.json"
    examples = {}

    for tool_name, calls in file_edit_tools.items():
        # Get first example of each format type
        examples[tool_name] = {}

        for call in calls:
            result = call.get("result", {})

            if isinstance(result, dict):
                if "diff" in result and "chunks" in result.get("diff", {}):
                    if "with_diff_chunks" not in examples[tool_name]:
                        examples[tool_name]["with_diff_chunks"] = call

                elif "beforeContentId" in result and "afterContentId" in result:
                    if "with_content_hashes" not in examples[tool_name]:
                        examples[tool_name]["with_content_hashes"] = call

                else:
                    if "other_format" not in examples[tool_name]:
                        examples[tool_name]["other_format"] = call

    with open(examples_file, "w") as f:
        json.dump(examples, f, indent=2)

    print(f"Format examples saved to: {examples_file}")


if __name__ == "__main__":
    project_dir = Path(__file__).parent.parent.parent
    analyze_cursor_sessions(project_dir, days_back=14)
