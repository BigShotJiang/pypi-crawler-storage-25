#!/usr/bin/env python3
"""Extract the latest Cursor session events for testing diff extraction.

UTILITY SCRIPT - Not a test. Run manually to extract session data from ClickHouse.

This script finds the most recent Cursor session and extracts relevant
tool call events for creating test fixtures.

Usage:
    python agentstream/tests/scripts/extract_cursor_session.py

Requirements:
    - ClickHouse running on localhost:8123
    - agentstream database with session data

Output:
    - Saves to agentstream/tests/fixtures/cursor_diff_events.json
"""

import json
from datetime import datetime
from pathlib import Path

import clickhouse_connect


def main():
    # Connect to local ClickHouse
    client = clickhouse_connect.get_client(host="localhost", port=8123, database="agentstream")

    print("=" * 80)
    print("EXTRACTING LATEST CURSOR SESSION")
    print("=" * 80)

    # Find the most recent Cursor session
    cursor_sessions = client.query(
        """
        SELECT session_id, user_id, git_repo, created_at
        FROM sessions
        WHERE agent_type = 'cursor'
        ORDER BY created_at DESC
        LIMIT 10
        """
    ).result_rows

    if not cursor_sessions:
        print("No Cursor sessions found!")
        return

    print("\n📊 RECENT CURSOR SESSIONS")
    print("-" * 80)
    for i, (session_id, _user_id, git_repo, created_at) in enumerate(cursor_sessions, 1):
        print(f"{i}. {session_id[:8]}... | {git_repo} | {created_at}")

    # Use the most recent session
    latest_session_id = cursor_sessions[0][0]
    print(f"\n✅ Using session: {latest_session_id}")

    # Get all events for this session
    events = client.query(
        """
        SELECT
            event_id,
            event_type,
            tool_name,
            timestamp_ms,
            event_data
        FROM events
        WHERE session_id = {session_id:String}
        AND tool_name != ''
        ORDER BY timestamp_ms ASC
        """,
        parameters={"session_id": latest_session_id},
    ).result_rows

    print(f"\n📝 Found {len(events)} tool call events")

    # Parse and filter relevant events
    relevant_events = []
    for event_id, event_type, tool_name, timestamp_ms, event_data in events:
        # Parse event data
        try:
            data = json.loads(event_data)
        except json.JSONDecodeError:
            continue

        # We're interested in file operations (edit_file_v2, write_file, read_file_v2)
        if tool_name in ["edit_file_v2", "write_file", "read_file_v2", "todo_write"]:
            event_obj = {
                "event_id": event_id,
                "event_type": event_type,
                "tool_name": tool_name,
                "timestamp_ms": timestamp_ms,
                "agent_type": "cursor",
                **data,
            }
            relevant_events.append(event_obj)

            # Print summary
            file_path = None
            if "params" in data:
                try:
                    params = (
                        json.loads(data["params"])
                        if isinstance(data["params"], str)
                        else data["params"]
                    )
                    file_path = (
                        params.get("relativeWorkspacePath")
                        or params.get("targetFile")
                        or params.get("filePath")
                    )
                except (json.JSONDecodeError, KeyError, TypeError):
                    pass

            print(f"\n  {tool_name:20} | {file_path or 'N/A'}")

    # Save to fixtures
    output_dir = Path("agentstream/tests/fixtures")
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = output_dir / "cursor_edit_events.json"

    fixture_data = {
        "description": "Cursor edit events extracted from real session data",
        "extraction_date": datetime.now().isoformat(),
        "session_id": latest_session_id,
        "session_info": {
            "user_id": cursor_sessions[0][1],
            "git_repo": cursor_sessions[0][2],
            "created_at": str(cursor_sessions[0][3]),
        },
        "events": relevant_events,
    }

    with open(output_file, "w") as f:
        json.dump(fixture_data, f, indent=2)

    print(f"\n✅ Saved {len(relevant_events)} events to {output_file}")

    # Show sample event structure
    if relevant_events:
        print("\n🔍 SAMPLE EVENT STRUCTURE:")
        print("-" * 80)
        sample = relevant_events[0]
        print(json.dumps(sample, indent=2)[:500] + "...")


if __name__ == "__main__":
    main()
