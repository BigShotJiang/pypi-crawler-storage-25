# tests/test_api.py
from pathlib import Path

from agentstream import discover_sessions, read_events, read_messages
from agentstream.grouper import MessageGroup


def _setup_claude_session(tmp_path, monkeypatch):
    """Helper to set up a mock Claude session with correct directory structure."""
    # Mock home directory
    mock_home = tmp_path / "home"
    mock_home.mkdir()
    monkeypatch.setattr(Path, "home", lambda: mock_home)

    # Create project directory
    project_dir = tmp_path / "project"
    project_dir.mkdir()

    # Claude hashes the path by replacing / with -
    project_hash = str(project_dir.resolve()).replace("/", "-")
    sessions_dir = mock_home / ".claude" / "projects" / project_hash
    sessions_dir.mkdir(parents=True)

    return project_dir, sessions_dir


class TestTopLevelAPI:
    def test_discover_sessions(self, tmp_path, monkeypatch):
        project_dir, sessions_dir = _setup_claude_session(tmp_path, monkeypatch)

        (sessions_dir / "12345678-1234-1234-1234-123456789012.jsonl").write_text(
            '{"type":"user","message":{"content":"Hi"},"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
        )

        sessions = discover_sessions(project_dir)
        assert len(sessions) == 1
        assert sessions[0].format == "claude"

    def test_read_events_returns_iterator(self, tmp_path, monkeypatch):
        project_dir, sessions_dir = _setup_claude_session(tmp_path, monkeypatch)

        (sessions_dir / "12345678-1234-1234-1234-123456789012.jsonl").write_text(
            '{"type":"user","message":{"content":"Hi"},"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
        )

        sessions = discover_sessions(project_dir)
        events = read_events(sessions[0])

        # Should be an iterator
        assert hasattr(events, "__iter__")
        event_list = list(events)
        assert len(event_list) > 0

    def test_read_messages_returns_grouped(self, tmp_path, monkeypatch):
        project_dir, sessions_dir = _setup_claude_session(tmp_path, monkeypatch)

        (sessions_dir / "12345678-1234-1234-1234-123456789012.jsonl").write_text(
            '{"type":"user","message":{"content":"Hello"},"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
            '{"type":"assistant","message":{"content":[{"type":"text","text":"Hi!"}]},"uuid":"a1","timestamp":"2024-01-01T00:00:01Z"}\n'
        )

        sessions = discover_sessions(project_dir)
        messages = list(read_messages(sessions[0]))

        assert len(messages) == 2
        assert all(isinstance(m, MessageGroup) for m in messages)
        assert messages[0].text == "Hello"
        assert messages[1].text == "Hi!"
