"""Tests for adapters."""
