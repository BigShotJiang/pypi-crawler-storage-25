"""Tests for Cursor token estimation utilities."""

from __future__ import annotations

from agentstream.adapters.cursor_tokens import (
    CHARS_PER_TOKEN,
    CURSOR_CONTEXT_WINDOW,
    estimate_input_tokens,
    estimate_output_tokens,
    estimate_session_tokens,
)


class TestEstimateInputTokens:
    def test_zero_percent(self) -> None:
        """0% context usage returns 0 tokens."""
        assert estimate_input_tokens(0) == 0

    def test_fifty_percent(self) -> None:
        """50% context usage returns half of context window."""
        result = estimate_input_tokens(50)
        assert result == CURSOR_CONTEXT_WINDOW // 2

    def test_hundred_percent(self) -> None:
        """100% context usage returns full context window."""
        result = estimate_input_tokens(100)
        assert result == CURSOR_CONTEXT_WINDOW

    def test_over_hundred_clamped(self) -> None:
        """Values over 100% are clamped to 100%."""
        result = estimate_input_tokens(150)
        assert result == CURSOR_CONTEXT_WINDOW

    def test_negative_returns_zero(self) -> None:
        """Negative values return 0."""
        assert estimate_input_tokens(-10) == 0

    def test_none_returns_zero(self) -> None:
        """None value returns 0."""
        assert estimate_input_tokens(None) == 0

    def test_fractional_percent(self) -> None:
        """Fractional percentages work correctly."""
        result = estimate_input_tokens(17.5)
        expected = int(0.175 * CURSOR_CONTEXT_WINDOW)
        assert result == expected


class TestEstimateOutputTokens:
    def test_empty_list(self) -> None:
        """Empty bubble list returns 0."""
        assert estimate_output_tokens([]) == 0

    def test_user_bubble_ignored(self) -> None:
        """User bubbles (type=1) are not counted."""
        bubbles = [{"type": 1, "text": "Hello world, this is user input"}]
        assert estimate_output_tokens(bubbles) == 0

    def test_assistant_bubble_counted(self) -> None:
        """Assistant bubbles (type=2) are counted."""
        # 12 characters / 4 chars per token = 3 tokens
        bubbles = [{"type": 2, "text": "Hello there!"}]
        result = estimate_output_tokens(bubbles)
        assert result == len("Hello there!") // CHARS_PER_TOKEN

    def test_multiple_assistant_bubbles(self) -> None:
        """Multiple assistant bubbles are summed."""
        bubbles = [
            {"type": 2, "text": "First response"},
            {"type": 2, "text": "Second response"},
        ]
        total_chars = len("First response") + len("Second response")
        expected = total_chars // CHARS_PER_TOKEN
        assert estimate_output_tokens(bubbles) == expected

    def test_mixed_bubbles(self) -> None:
        """Mixed user/assistant bubbles only count assistant."""
        bubbles = [
            {"type": 1, "text": "User question here"},
            {"type": 2, "text": "Assistant answer"},
            {"type": 1, "text": "Another user message"},
            {"type": 2, "text": "Another assistant answer"},
        ]
        total_chars = len("Assistant answer") + len("Another assistant answer")
        expected = total_chars // CHARS_PER_TOKEN
        assert estimate_output_tokens(bubbles) == expected

    def test_tool_result_counted(self) -> None:
        """Tool results in assistant bubbles are counted."""
        bubbles = [
            {
                "type": 2,
                "text": "Here's the result",
                "toolFormerData": {"result": "file contents here"},
            }
        ]
        total_chars = len("Here's the result") + len("file contents here")
        expected = total_chars // CHARS_PER_TOKEN
        assert estimate_output_tokens(bubbles) == expected

    def test_missing_text_handled(self) -> None:
        """Bubbles without text field are handled gracefully."""
        bubbles = [{"type": 2}]
        assert estimate_output_tokens(bubbles) == 0

    def test_empty_text_handled(self) -> None:
        """Empty text strings are handled."""
        bubbles = [{"type": 2, "text": ""}]
        assert estimate_output_tokens(bubbles) == 0

    def test_non_dict_tool_data_handled(self) -> None:
        """Non-dict toolFormerData is handled."""
        bubbles = [{"type": 2, "text": "Response", "toolFormerData": "invalid"}]
        # Should only count the text, not the invalid tool data
        expected = len("Response") // CHARS_PER_TOKEN
        assert estimate_output_tokens(bubbles) == expected


class TestEstimateSessionTokens:
    def test_basic_session(self) -> None:
        """Basic session with context usage and bubbles."""
        metadata = {"contextUsagePercent": 25.0}
        bubbles = [{"type": 2, "text": "Here is a response with some content."}]

        result = estimate_session_tokens(metadata, bubbles)

        assert result["input_tokens"] == int(0.25 * CURSOR_CONTEXT_WINDOW)
        assert result["output_tokens"] > 0
        assert result["tokens_estimated"] is True
        assert "estimation_method" in result

    def test_no_context_usage(self) -> None:
        """Session without contextUsagePercent."""
        metadata = {}
        bubbles = [{"type": 2, "text": "Response"}]

        result = estimate_session_tokens(metadata, bubbles)

        assert result["input_tokens"] == 0
        assert "contextUsagePercent missing" in result["estimation_method"]

    def test_no_bubbles(self) -> None:
        """Session without bubbles."""
        metadata = {"contextUsagePercent": 10.0}
        bubbles: list = []

        result = estimate_session_tokens(metadata, bubbles)

        assert result["output_tokens"] == 0
        assert "no bubbles" in result["estimation_method"]

    def test_none_context_usage(self) -> None:
        """None contextUsagePercent is handled."""
        metadata = {"contextUsagePercent": None}
        bubbles = [{"type": 2, "text": "Test"}]

        result = estimate_session_tokens(metadata, bubbles)

        assert result["input_tokens"] == 0

    def test_estimation_method_description(self) -> None:
        """Estimation method includes useful details."""
        metadata = {"contextUsagePercent": 15.5}
        bubbles = [
            {"type": 2, "text": "First"},
            {"type": 2, "text": "Second"},
        ]

        result = estimate_session_tokens(metadata, bubbles)

        method = result["estimation_method"]
        assert "15.5%" in method
        assert "2 assistant bubbles" in method
        assert str(CHARS_PER_TOKEN) in method

    def test_none_bubbles_handled(self) -> None:
        """None bubbles argument is handled."""
        metadata = {"contextUsagePercent": 10.0}

        result = estimate_session_tokens(metadata, None)

        assert result["output_tokens"] == 0


class TestConstants:
    def test_context_window_reasonable(self) -> None:
        """Context window constant is reasonable."""
        assert CURSOR_CONTEXT_WINDOW > 0
        assert CURSOR_CONTEXT_WINDOW == 200_000

    def test_chars_per_token_reasonable(self) -> None:
        """Chars per token constant is reasonable."""
        assert CHARS_PER_TOKEN > 0
        assert CHARS_PER_TOKEN == 4
