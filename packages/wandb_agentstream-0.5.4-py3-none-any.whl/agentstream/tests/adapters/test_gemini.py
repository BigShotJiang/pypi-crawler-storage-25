"""Tests for Gemini adapter."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from agentstream.adapters.base import Session
from agentstream.adapters.gemini import GeminiAdapter
from agentstream.events import (
    CustomEvent,
    EventType,
    ReasoningMessageChunkEvent,
    Role,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)


class TestGeminiAdapter:
    def test_name(self) -> None:
        adapter = GeminiAdapter()
        assert adapter.name == "gemini"

    def test_discover_sessions_finds_gemini_sessions(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        """Should find Gemini sessions by project hash."""
        # Mock home directory
        mock_home = tmp_path / "home"
        mock_home.mkdir()
        monkeypatch.setattr(Path, "home", lambda: mock_home)

        # Create project directory
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()

        # Gemini uses SHA256 hash of project path
        project_hash = hashlib.sha256(str(project_dir.resolve()).encode()).hexdigest()

        # Create Gemini sessions directory
        sessions_dir = mock_home / ".gemini" / "tmp" / project_hash / "chats"
        sessions_dir.mkdir(parents=True)

        # Create a session file
        session_file = sessions_dir / "session-2026-01-06T01-48-abc123.json"
        session_data = {
            "sessionId": "abc123",
            "projectHash": project_hash,
            "startTime": "2026-01-06T00:00:00Z",
            "lastUpdated": "2026-01-06T00:00:00Z",
            "messages": [],
        }
        session_file.write_text(json.dumps(session_data))

        adapter = GeminiAdapter()
        sessions = adapter.discover_sessions(project_dir)

        assert len(sessions) == 1
        assert sessions[0].id == "abc123"
        assert sessions[0].format == "gemini"
        assert sessions[0].path == session_file

    def test_discover_sessions_returns_empty_for_no_gemini(self, tmp_path: Path) -> None:
        """Should return empty list when no .gemini directory."""
        adapter = GeminiAdapter()
        sessions = adapter.discover_sessions(tmp_path)
        assert sessions == []


class TestGeminiReadEvents:
    def test_read_simple_session(self, tmp_path: Path) -> None:
        """Read events from a simple Gemini session."""
        session_file = tmp_path / "session.json"
        session_file.write_text(
            json.dumps(
                {
                    "sessionId": "test-123",
                    "projectHash": "abc",
                    "startTime": "2026-01-06T00:00:00Z",
                    "lastUpdated": "2026-01-06T00:01:00Z",
                    "messages": [
                        {
                            "id": "m1",
                            "timestamp": "2026-01-06T00:00:00Z",
                            "type": "user",
                            "content": "Hello",
                        },
                        {
                            "id": "m2",
                            "timestamp": "2026-01-06T00:00:01Z",
                            "type": "gemini",
                            "content": "Hi there!",
                        },
                    ],
                }
            )
        )

        session = Session(id="test", path=session_file, format="gemini", modified_at=0.0)
        adapter = GeminiAdapter()
        events = list(adapter.read_events(session))

        event_types = [e.type for e in events]
        assert EventType.RUN_STARTED in event_types
        assert EventType.TEXT_MESSAGE_CHUNK in event_types
        assert EventType.RUN_FINISHED in event_types

    def test_read_message_with_thoughts(self, tmp_path: Path) -> None:
        """Read reasoning events from Gemini thoughts."""
        session_file = tmp_path / "session.json"
        session_file.write_text("""{
            "sessionId": "test",
            "projectHash": "abc",
            "startTime": "2026-01-06T00:00:00Z",
            "lastUpdated": "2026-01-06T00:01:00Z",
            "messages": [{
                "id": "m1",
                "timestamp": "2026-01-06T00:00:00Z",
                "type": "gemini",
                "content": "Here is my answer",
                "thoughts": [{
                    "subject": "Thinking",
                    "description": "Let me consider this...",
                    "timestamp": "2026-01-06T00:00:00Z"
                }]
            }]
        }""")

        session = Session(id="test", path=session_file, format="gemini", modified_at=0.0)
        adapter = GeminiAdapter()
        events = list(adapter.read_events(session))

        reasoning_chunks = [e for e in events if isinstance(e, ReasoningMessageChunkEvent)]
        assert len(reasoning_chunks) == 1
        assert reasoning_chunks[0].delta is not None
        assert "**Thinking**" in reasoning_chunks[0].delta
        assert "Let me consider this..." in reasoning_chunks[0].delta

    def test_read_message_with_tool_calls(self, tmp_path: Path) -> None:
        """Read tool call events from Gemini."""
        session_file = tmp_path / "session.json"
        session_file.write_text("""{
            "sessionId": "test",
            "projectHash": "abc",
            "startTime": "2026-01-06T00:00:00Z",
            "lastUpdated": "2026-01-06T00:01:00Z",
            "messages": [{
                "id": "m1",
                "timestamp": "2026-01-06T00:00:00Z",
                "type": "gemini",
                "content": "",
                "toolCalls": [{
                    "id": "tc1",
                    "name": "read_file",
                    "args": {"file_path": "test.txt"},
                    "result": [{"functionResponse": {"response": {"output": "file content"}}}],
                    "status": "success",
                    "timestamp": "2026-01-06T00:00:01Z"
                }]
            }]
        }""")

        session = Session(id="test", path=session_file, format="gemini", modified_at=0.0)
        adapter = GeminiAdapter()
        events = list(adapter.read_events(session))

        tool_chunks = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_chunks) == 1
        assert tool_chunks[0].tool_call_name == "read_file"

        tool_results = [e for e in events if isinstance(e, ToolCallResultEvent)]
        assert len(tool_results) == 1
        assert tool_results[0].result == "file content"

    def test_read_info_message_as_custom_event(self, tmp_path: Path) -> None:
        """Info messages should become CustomEvents."""
        session_file = tmp_path / "session.json"
        session_file.write_text("""{
            "sessionId": "test",
            "projectHash": "abc",
            "startTime": "2026-01-06T00:00:00Z",
            "lastUpdated": "2026-01-06T00:01:00Z",
            "messages": [{
                "id": "info1",
                "timestamp": "2026-01-06T00:00:00Z",
                "type": "info",
                "content": "Update available!"
            }]
        }""")

        session = Session(id="test", path=session_file, format="gemini", modified_at=0.0)
        adapter = GeminiAdapter()
        events = list(adapter.read_events(session))

        # Filter for info events (not source_entry events)
        info_events = [e for e in events if isinstance(e, CustomEvent) and e.name == "info"]
        assert len(info_events) == 1
        assert info_events[0].value["content"] == "Update available!"

    def test_emits_usage_metadata(self, tmp_path: Path) -> None:
        session_file = tmp_path / "session.json"
        session_file.write_text("""{
            "sessionId": "test",
            "projectHash": "abc",
            "startTime": "2026-01-06T00:00:00Z",
            "lastUpdated": "2026-01-06T00:01:00Z",
            "messages": [{
                "id": "m1",
                "timestamp": "2026-01-06T00:00:01Z",
                "type": "gemini",
                "content": "Here is the answer",
                "model": "gemini-2.5-pro",
                "tokens": {
                    "input": 1200, "output": 345, "cached": 50,
                    "thoughts": 10, "tool": 0, "total": 1605
                }
            }]
        }""")

        session = Session(id="test", path=session_file, format="gemini", modified_at=0.0)
        adapter = GeminiAdapter()
        events = list(adapter.read_events(session))

        assistant_chunks = [
            e for e in events if isinstance(e, TextMessageChunkEvent) and e.role == Role.ASSISTANT
        ]
        assert len(assistant_chunks) == 1
        # Note: Token usage is now extracted via normalizers as TOKEN_USAGE custom events,
        # not via raw_event. See normalizer tests for usage extraction validation.

    def test_read_fixture(self) -> None:
        """Read the actual fixture file."""
        fixture_path = Path(__file__).parent.parent / "fixtures" / "gemini" / "gemini_simple.json"
        session = Session(id="test", path=fixture_path, format="gemini", modified_at=0.0)
        adapter = GeminiAdapter()
        events = list(adapter.read_events(session))

        # Should have run events (first semantic event after source_entry is RUN_STARTED)
        run_started = [e for e in events if e.type == EventType.RUN_STARTED]
        run_finished = [e for e in events if e.type == EventType.RUN_FINISHED]
        assert len(run_started) == 1
        assert len(run_finished) == 1

        # Should have user message chunk
        user_chunks = [
            e for e in events if isinstance(e, TextMessageChunkEvent) and e.role == Role.USER
        ]
        assert len(user_chunks) >= 1

        # Should have reasoning chunk from thoughts
        reasoning = [e for e in events if e.type == EventType.REASONING_MESSAGE_CHUNK]
        assert len(reasoning) >= 1

        # Should have tool call chunks
        tool_calls = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_calls) >= 1

        # Should have info message as custom event
        custom = [e for e in events if isinstance(e, CustomEvent) and e.name == "info"]
        assert len(custom) == 1

    def test_extracts_model_from_message(self, tmp_path: Path) -> None:
        """Extract the model from first message and add it to RunStartedEvent."""
        session_file = tmp_path / "session_with_model.json"
        session_file.write_text(
            json.dumps(
                {
                    "sessionId": "test-model-extraction",
                    "projectHash": "abc",
                    "startTime": "2026-01-06T00:00:00Z",
                    "lastUpdated": "2026-01-06T00:01:00Z",
                    "messages": [
                        {
                            "id": "m1",
                            "timestamp": "2026-01-06T00:00:00Z",
                            "type": "user",
                            "content": "Hello",
                        },
                        {
                            "id": "m2",
                            "timestamp": "2026-01-06T00:00:01Z",
                            "type": "gemini",
                            "content": "Hi there!",
                            "model": "gemini-pro",
                        },
                    ],
                }
            )
        )

        session = Session(id="test", path=session_file, format="gemini", modified_at=0.0)
        adapter = GeminiAdapter()
        events = list(adapter.read_events(session))

        run_started_events = [e for e in events if e.type == EventType.RUN_STARTED]
        assert len(run_started_events) == 1


class TestGeminiFileOperations:
    """Tests for file operation extraction in Gemini adapter."""

    def test_file_ops_extracted_from_tool_calls(self, tmp_path: Path) -> None:
        """File operations should be extracted from tool calls."""
        session_file = tmp_path / "session.json"
        session_file.write_text(
            json.dumps(
                {
                    "sessionId": "test",
                    "projectHash": "abc",
                    "cwd": str(tmp_path),
                    "startTime": "2026-01-06T00:00:00Z",
                    "lastUpdated": "2026-01-06T00:01:00Z",
                    "messages": [
                        {
                            "id": "m1",
                            "timestamp": "2026-01-06T00:00:00Z",
                            "type": "gemini",
                            "content": "",
                            "toolCalls": [
                                {
                                    "id": "tc1",
                                    "name": "read_file",
                                    "args": {"file_path": str(tmp_path / "test.txt")},
                                    "result": [
                                        {"functionResponse": {"response": {"output": "content"}}}
                                    ],
                                    "status": "success",
                                    "timestamp": "2026-01-06T00:00:01Z",
                                },
                                {
                                    "id": "tc2",
                                    "name": "write_file",
                                    "args": {"file_path": str(tmp_path / "output.txt")},
                                    "result": [
                                        {"functionResponse": {"response": {"output": "success"}}}
                                    ],
                                    "status": "success",
                                    "timestamp": "2026-01-06T00:00:02Z",
                                },
                            ],
                        }
                    ],
                }
            )
        )

        session = Session(id="test", path=session_file, format="gemini", modified_at=0.0)
        adapter = GeminiAdapter()
        events = list(adapter.read_events(session))

        # Find tool call events
        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_events) == 2

        # Check read operation
        read_event = tool_events[0]
        assert read_event.tool_call_name == "read_file"

        # Check write operation
        write_event = tool_events[1]
        assert write_event.tool_call_name == "write_file"

        # Note: File operation extraction is now handled via normalizers and stored
        # as UNIFIED_FILE_OPERATION custom events, not in raw_event.

    def test_paths_normalized_to_cwd_relative(self, tmp_path: Path) -> None:
        """File paths should be normalized relative to session cwd."""
        session_file = tmp_path / "session.json"
        session_file.write_text(
            json.dumps(
                {
                    "sessionId": "test",
                    "projectHash": "abc",
                    "cwd": str(tmp_path),
                    "startTime": "2026-01-06T00:00:00Z",
                    "lastUpdated": "2026-01-06T00:01:00Z",
                    "messages": [
                        {
                            "id": "m1",
                            "timestamp": "2026-01-06T00:00:00Z",
                            "type": "gemini",
                            "content": "",
                            "toolCalls": [
                                {
                                    "id": "tc1",
                                    "name": "read_file",
                                    "args": {"file_path": str(tmp_path / "subdir" / "file.txt")},
                                    "result": [
                                        {"functionResponse": {"response": {"output": "content"}}}
                                    ],
                                    "status": "success",
                                    "timestamp": "2026-01-06T00:00:01Z",
                                }
                            ],
                        }
                    ],
                }
            )
        )

        session = Session(id="test", path=session_file, format="gemini", modified_at=0.0)
        adapter = GeminiAdapter()
        events = list(adapter.read_events(session))

        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_events) == 1
        # Note: File path normalization is now tested via normalizer tests,
        # not via adapter raw_event extraction.

    def test_no_file_ops_for_text_only_messages(self, tmp_path: Path) -> None:
        """Messages without tool calls should not have file_ops."""
        session_file = tmp_path / "session.json"
        session_file.write_text(
            json.dumps(
                {
                    "sessionId": "test",
                    "projectHash": "abc",
                    "cwd": str(tmp_path),
                    "startTime": "2026-01-06T00:00:00Z",
                    "lastUpdated": "2026-01-06T00:01:00Z",
                    "messages": [
                        {
                            "id": "m1",
                            "timestamp": "2026-01-06T00:00:00Z",
                            "type": "user",
                            "content": "Hello",
                        },
                        {
                            "id": "m2",
                            "timestamp": "2026-01-06T00:00:01Z",
                            "type": "gemini",
                            "content": "Hi there!",
                        },
                    ],
                }
            )
        )

        session = Session(id="test", path=session_file, format="gemini", modified_at=0.0)
        adapter = GeminiAdapter()
        events = list(adapter.read_events(session))

        # Find assistant message events
        assistant_events = [
            e for e in events if isinstance(e, TextMessageChunkEvent) and e.role == Role.ASSISTANT
        ]

        assert len(assistant_events) == 1
