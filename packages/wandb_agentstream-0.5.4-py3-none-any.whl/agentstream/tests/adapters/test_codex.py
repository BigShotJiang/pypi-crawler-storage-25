"""Tests for Codex adapter."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agentstream.adapters.base import Session
from agentstream.adapters.codex import CodexAdapter
from agentstream.events import (
    CustomEvent,
    EventType,
    ReasoningMessageChunkEvent,
    Role,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)


class TestCodexAdapter:
    def test_name(self) -> None:
        adapter = CodexAdapter()
        assert adapter.name == "codex"

    def test_discover_sessions_finds_codex_sessions(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Should find Codex sessions matching project cwd."""
        # Mock home directory
        mock_home = tmp_path / "home"
        mock_home.mkdir()
        monkeypatch.setattr(Path, "home", lambda: mock_home)

        # Create project directory
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()

        # Create Codex sessions directory
        sessions_dir = mock_home / ".codex" / "sessions" / "2026" / "01" / "06"
        sessions_dir.mkdir(parents=True)

        # Create a session file with matching cwd
        session_file = sessions_dir / "rollout-2026-01-06T00-00-00-abc123.jsonl"
        session_meta = {
            "timestamp": "2026-01-06T00:00:00Z",
            "type": "session_meta",
            "payload": {
                "id": "abc123",
                "timestamp": "2026-01-06T00:00:00Z",
                "cwd": str(project_dir.resolve()),
                "originator": "codex_cli_rs",
                "cli_version": "0.77.0",
            },
        }
        session_file.write_text(json.dumps(session_meta) + "\n")

        adapter = CodexAdapter()
        sessions = adapter.discover_sessions(project_dir)

        assert len(sessions) == 1
        assert sessions[0].format == "codex"
        assert sessions[0].id == "abc123"

    def test_discover_sessions_returns_empty_for_no_codex(self, tmp_path: Path) -> None:
        adapter = CodexAdapter()
        sessions = adapter.discover_sessions(tmp_path)
        assert sessions == []

    def test_get_session_id_prefers_payload_id(self, tmp_path: Path) -> None:
        adapter = CodexAdapter()
        session_file = tmp_path / "session-stem.jsonl"
        session_file.write_text(
            json.dumps(
                {
                    "type": "session_meta",
                    "payload": {"id": "uuid-from-payload", "cwd": str(tmp_path)},
                }
            )
            + "\n"
        )
        assert adapter.get_session_id(session_file) == "uuid-from-payload"

    def test_get_session_id_falls_back_to_stem(self, tmp_path: Path) -> None:
        adapter = CodexAdapter()
        session_file = tmp_path / "session-stem.jsonl"
        session_file.write_text(
            json.dumps({"type": "session_meta", "payload": {"cwd": str(tmp_path)}})
        )
        assert adapter.get_session_id(session_file) == "session-stem"

    def test_discover_sessions_filters_by_cwd(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Should only return sessions where cwd matches project (or subdirectory)."""
        mock_home = tmp_path / "home"
        mock_home.mkdir()
        monkeypatch.setattr(Path, "home", lambda: mock_home)

        project_dir = tmp_path / "myproject"
        project_dir.mkdir()

        sessions_dir = mock_home / ".codex" / "sessions" / "2026" / "01" / "06"
        sessions_dir.mkdir(parents=True)

        # Session with matching cwd
        matching = sessions_dir / "rollout-match.jsonl"
        matching.write_text(
            json.dumps(
                {
                    "timestamp": "2026-01-06T00:00:00Z",
                    "type": "session_meta",
                    "payload": {
                        "id": "match",
                        "cwd": str(project_dir.resolve()),
                        "originator": "codex",
                        "cli_version": "1.0",
                        "timestamp": "2026-01-06T00:00:00Z",
                    },
                }
            )
            + "\n"
        )

        # Session with subdirectory cwd (should match)
        subdir = sessions_dir / "rollout-subdir.jsonl"
        (project_dir / "src").mkdir()
        subdir.write_text(
            json.dumps(
                {
                    "timestamp": "2026-01-06T00:00:00Z",
                    "type": "session_meta",
                    "payload": {
                        "id": "subdir",
                        "cwd": str(project_dir / "src"),
                        "originator": "codex",
                        "cli_version": "1.0",
                        "timestamp": "2026-01-06T00:00:00Z",
                    },
                }
            )
            + "\n"
        )

        # Session with different cwd (should not match)
        other = sessions_dir / "rollout-other.jsonl"
        other.write_text(
            json.dumps(
                {
                    "timestamp": "2026-01-06T00:00:00Z",
                    "type": "session_meta",
                    "payload": {
                        "id": "other",
                        "cwd": "/other/project",
                        "originator": "codex",
                        "cli_version": "1.0",
                        "timestamp": "2026-01-06T00:00:00Z",
                    },
                }
            )
            + "\n"
        )

        adapter = CodexAdapter()
        sessions = adapter.discover_sessions(project_dir)

        ids = {s.id for s in sessions}
        assert "match" in ids
        assert "subdir" in ids
        assert "other" not in ids


class TestCodexReadEvents:
    def test_read_simple_session(self, tmp_path: Path) -> None:
        """Read events from a simple Codex session."""
        session_file = tmp_path / "session.jsonl"
        lines = [
            {
                "timestamp": "2026-01-06T00:00:00Z",
                "type": "session_meta",
                "payload": {
                    "id": "test",
                    "cwd": "/test",
                    "originator": "codex",
                    "cli_version": "1.0",
                    "timestamp": "2026-01-06T00:00:00Z",
                },
            },
            {
                "timestamp": "2026-01-06T00:00:01Z",
                "type": "response_item",
                "payload": {
                    "type": "message",
                    "role": "user",
                    "content": [{"type": "input_text", "text": "Hello"}],
                },
            },
            {
                "timestamp": "2026-01-06T00:00:02Z",
                "type": "response_item",
                "payload": {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "Hi there!"}],
                },
            },
        ]
        session_file.write_text("\n".join(json.dumps(line) for line in lines) + "\n")

        session = Session(id="test", path=session_file, format="codex", modified_at=0.0)
        adapter = CodexAdapter()
        events = list(adapter.read_events(session))

        event_types = [e.type for e in events]
        assert EventType.RUN_STARTED in event_types
        assert EventType.TEXT_MESSAGE_CHUNK in event_types
        assert EventType.RUN_FINISHED in event_types

    def test_read_reasoning_events(self, tmp_path: Path) -> None:
        """Read reasoning events with encrypted content preserved."""
        session_file = tmp_path / "session.jsonl"
        lines = [
            {
                "timestamp": "2026-01-06T00:00:00Z",
                "type": "session_meta",
                "payload": {
                    "id": "test",
                    "cwd": "/test",
                    "originator": "codex",
                    "cli_version": "1.0",
                    "timestamp": "2026-01-06T00:00:00Z",
                },
            },
            {
                "timestamp": "2026-01-06T00:00:01Z",
                "type": "response_item",
                "payload": {
                    "type": "reasoning",
                    "summary": [{"type": "summary_text", "text": "**Thinking about this**"}],
                    "encrypted_content": "gAAAAA_encrypted",
                },
            },
        ]
        session_file.write_text("\n".join(json.dumps(line) for line in lines) + "\n")

        session = Session(id="test", path=session_file, format="codex", modified_at=0.0)
        adapter = CodexAdapter()
        events = list(adapter.read_events(session))

        reasoning = [e for e in events if isinstance(e, ReasoningMessageChunkEvent)]
        assert len(reasoning) == 1
        assert reasoning[0].delta == "**Thinking about this**"

    def test_read_tool_calls(self, tmp_path: Path) -> None:
        """Read tool call and result events."""
        session_file = tmp_path / "session.jsonl"
        lines = [
            {
                "timestamp": "2026-01-06T00:00:00Z",
                "type": "session_meta",
                "payload": {
                    "id": "test",
                    "cwd": "/test",
                    "originator": "codex",
                    "cli_version": "1.0",
                    "timestamp": "2026-01-06T00:00:00Z",
                },
            },
            {
                "timestamp": "2026-01-06T00:00:01Z",
                "type": "response_item",
                "payload": {
                    "type": "function_call",
                    "name": "exec_command",
                    "arguments": '{"cmd":"pwd"}',
                    "call_id": "call_123",
                },
            },
            {
                "timestamp": "2026-01-06T00:00:02Z",
                "type": "response_item",
                "payload": {
                    "type": "function_call_output",
                    "call_id": "call_123",
                    "output": "/home/user",
                },
            },
        ]
        session_file.write_text("\n".join(json.dumps(line) for line in lines) + "\n")

        session = Session(id="test", path=session_file, format="codex", modified_at=0.0)
        adapter = CodexAdapter()
        events = list(adapter.read_events(session))

        tool_chunks = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_chunks) == 1
        assert tool_chunks[0].tool_call_name == "exec_command"

        tool_results = [e for e in events if isinstance(e, ToolCallResultEvent)]
        assert len(tool_results) == 1
        assert tool_results[0].result == "/home/user"

    def test_token_count_usage(self, tmp_path: Path) -> None:
        """token_count events populate usage on assistant messages."""
        session_file = tmp_path / "session.jsonl"
        lines = [
            {
                "timestamp": "2026-01-06T00:00:00Z",
                "type": "session_meta",
                "payload": {
                    "id": "test",
                    "cwd": "/test",
                    "originator": "codex",
                    "cli_version": "1.0",
                    "timestamp": "2026-01-06T00:00:00Z",
                },
            },
            {
                "timestamp": "2026-01-06T00:00:01Z",
                "type": "turn_context",
                "payload": {"model": "gpt-5-codex"},
            },
            {
                "timestamp": "2026-01-06T00:00:02Z",
                "type": "event_msg",
                "payload": {
                    "type": "token_count",
                    "input_tokens": 123,
                    "output_tokens": 45,
                    "cached_input_tokens": 10,
                    "reasoning_output_tokens": 5,
                },
            },
            {
                "timestamp": "2026-01-06T00:00:03Z",
                "type": "response_item",
                "payload": {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "Done"}],
                },
            },
        ]
        session_file.write_text("\n".join(json.dumps(line) for line in lines) + "\n")

        session = Session(id="test", path=session_file, format="codex", modified_at=0.0)
        adapter = CodexAdapter()
        events = list(adapter.read_events(session))

        assistant_chunks = [
            e for e in events if isinstance(e, TextMessageChunkEvent) and e.role == Role.ASSISTANT
        ]
        assert len(assistant_chunks) == 1
        # Note: Token usage is now extracted via normalizers as TOKEN_USAGE custom events,
        # not via raw_event. See normalizer tests for usage extraction validation.

    def test_read_fixture(self) -> None:
        """Read the actual fixture file."""
        fixture_path = Path(__file__).parent.parent / "fixtures" / "codex" / "codex_simple.jsonl"
        session = Session(id="test", path=fixture_path, format="codex", modified_at=0.0)
        adapter = CodexAdapter()
        events = list(adapter.read_events(session))

        # Should have run events (source_entry events come first, then RUN_STARTED)
        run_started = [e for e in events if e.type == EventType.RUN_STARTED]
        run_finished = [e for e in events if e.type == EventType.RUN_FINISHED]
        assert len(run_started) == 1
        assert len(run_finished) == 1

        # Should have source_entry events for round-trip fidelity
        source_entries = [
            e for e in events if isinstance(e, CustomEvent) and e.name == "source_entry"
        ]
        assert len(source_entries) >= 1
        # First event should be source_entry
        assert events[0].type == EventType.CUSTOM
        assert isinstance(events[0], CustomEvent)
        assert events[0].name == "source_entry"
        assert events[0].value["format"] == "codex"
        assert events[0].value["index"] == 0

        # Should have user and assistant message chunks
        user_chunks = [
            e for e in events if isinstance(e, TextMessageChunkEvent) and e.role == Role.USER
        ]
        assistant_chunks = [
            e for e in events if isinstance(e, TextMessageChunkEvent) and e.role == Role.ASSISTANT
        ]
        assert len(user_chunks) >= 1
        assert len(assistant_chunks) >= 1

        # Should have reasoning chunks
        reasoning = [e for e in events if e.type == EventType.REASONING_MESSAGE_CHUNK]
        assert len(reasoning) >= 1

        # Should have tool call chunks
        tool_calls = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_calls) >= 1


class TestCodexCustomToolCall:
    """Tests for custom_tool_call handling (apply_patch)."""

    def test_custom_tool_call_emits_tool_call_chunk(self, tmp_path: Path) -> None:
        """custom_tool_call should emit ToolCallChunkEvent."""
        session_file = tmp_path / "session.jsonl"
        lines = [
            {
                "timestamp": "2026-01-06T00:00:00Z",
                "type": "session_meta",
                "payload": {
                    "id": "test",
                    "cwd": "/test",
                    "originator": "codex",
                    "cli_version": "1.0",
                    "timestamp": "2026-01-06T00:00:00Z",
                },
            },
            {
                "timestamp": "2026-01-06T00:00:01Z",
                "type": "response_item",
                "payload": {
                    "type": "custom_tool_call",
                    "status": "completed",
                    "call_id": "call_patch_1",
                    "name": "apply_patch",
                    "input": (
                        "*** Begin Patch\n"
                        "*** Update File: /test/file.go\n"
                        "@@\n-old line\n+new line\n@@\n"
                        "*** End Patch\n"
                    ),
                },
            },
        ]
        session_file.write_text("\n".join(json.dumps(line) for line in lines) + "\n")

        session = Session(id="test", path=session_file, format="codex", modified_at=0.0)
        adapter = CodexAdapter()
        events = list(adapter.read_events(session))

        tool_chunks = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_chunks) == 1
        assert tool_chunks[0].tool_call_name == "apply_patch"
        assert tool_chunks[0].tool_call_id == "call_patch_1"

        # Delta should be JSON with input field
        delta = json.loads(tool_chunks[0].delta)
        assert "*** Begin Patch" in delta["input"]

    def test_custom_tool_call_output_emits_result(self, tmp_path: Path) -> None:
        """custom_tool_call_output should emit ToolCallResultEvent."""
        session_file = tmp_path / "session.jsonl"
        lines = [
            {
                "timestamp": "2026-01-06T00:00:00Z",
                "type": "session_meta",
                "payload": {
                    "id": "test",
                    "cwd": "/test",
                    "originator": "codex",
                    "cli_version": "1.0",
                    "timestamp": "2026-01-06T00:00:00Z",
                },
            },
            {
                "timestamp": "2026-01-06T00:00:01Z",
                "type": "response_item",
                "payload": {
                    "type": "custom_tool_call",
                    "status": "completed",
                    "call_id": "call_patch_1",
                    "name": "apply_patch",
                    "input": (
                        "*** Begin Patch\n"
                        "*** Update File: /test/file.go\n"
                        "@@\n+new line\n@@\n"
                        "*** End Patch\n"
                    ),
                },
            },
            {
                "timestamp": "2026-01-06T00:00:02Z",
                "type": "response_item",
                "payload": {
                    "type": "custom_tool_call_output",
                    "call_id": "call_patch_1",
                    "output": (
                        '{"output":"Success. Updated the'
                        " following files:\\nM"
                        ' /test/file.go\\n","metadata":'
                        '{"exit_code":0}}'
                    ),
                },
            },
        ]
        session_file.write_text("\n".join(json.dumps(line) for line in lines) + "\n")

        session = Session(id="test", path=session_file, format="codex", modified_at=0.0)
        adapter = CodexAdapter()
        events = list(adapter.read_events(session))

        tool_results = [e for e in events if isinstance(e, ToolCallResultEvent)]
        assert len(tool_results) == 1
        assert tool_results[0].tool_call_id == "call_patch_1"
        assert "Success" in tool_results[0].result


class TestCodexFileOperations:
    """Tests for file operation extraction in Codex adapter."""

    def test_file_ops_extracted_from_function_calls(self, tmp_path: Path) -> None:
        """File operations should be extracted from function calls."""
        session_file = tmp_path / "session.jsonl"
        cwd = str(tmp_path)
        lines = [
            {
                "timestamp": "2026-01-06T00:00:00Z",
                "type": "session_meta",
                "payload": {
                    "id": "test",
                    "cwd": cwd,
                    "originator": "codex",
                    "cli_version": "1.0",
                    "timestamp": "2026-01-06T00:00:00Z",
                },
            },
            {
                "timestamp": "2026-01-06T00:00:01Z",
                "type": "response_item",
                "payload": {
                    "type": "function_call",
                    "name": "read_file",
                    "arguments": json.dumps({"path": str(tmp_path / "test.txt")}),
                    "call_id": "call_1",
                },
            },
            {
                "timestamp": "2026-01-06T00:00:02Z",
                "type": "response_item",
                "payload": {
                    "type": "function_call",
                    "name": "write_file",
                    "arguments": json.dumps({"path": str(tmp_path / "output.txt")}),
                    "call_id": "call_2",
                },
            },
        ]
        session_file.write_text("\n".join(json.dumps(line) for line in lines) + "\n")

        session = Session(id="test", path=session_file, format="codex", modified_at=0.0)
        adapter = CodexAdapter()
        events = list(adapter.read_events(session))

        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_events) == 2

        # Check read operation
        read_event = tool_events[0]
        assert read_event.tool_call_name == "read_file"

        # Check write operation
        write_event = tool_events[1]
        assert write_event.tool_call_name == "write_file"

        # Note: File operation extraction is now handled via normalizers and stored
        # as UNIFIED_FILE_OPERATION custom events, not in raw_event.

    def test_file_ops_extracted_from_shell_commands(self, tmp_path: Path) -> None:
        """File operations should be extracted from exec_command shell calls."""
        session_file = tmp_path / "session.jsonl"
        cwd = str(tmp_path)
        lines = [
            {
                "timestamp": "2026-01-06T00:00:00Z",
                "type": "session_meta",
                "payload": {
                    "id": "test",
                    "cwd": cwd,
                    "originator": "codex",
                    "cli_version": "1.0",
                    "timestamp": "2026-01-06T00:00:00Z",
                },
            },
            {
                "timestamp": "2026-01-06T00:00:01Z",
                "type": "response_item",
                "payload": {
                    "type": "function_call",
                    "name": "exec_command",
                    "arguments": json.dumps({"cmd": f"cat {tmp_path / 'readme.md'}"}),
                    "call_id": "call_1",
                },
            },
        ]
        session_file.write_text("\n".join(json.dumps(line) for line in lines) + "\n")

        session = Session(id="test", path=session_file, format="codex", modified_at=0.0)
        adapter = CodexAdapter()
        events = list(adapter.read_events(session))

        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_events) == 1

        # exec_command with cat should be detected as a read op
        # Note: File operation extraction is now handled via normalizers and stored
        # as UNIFIED_FILE_OPERATION custom events, not in raw_event.

    def test_paths_normalized_to_cwd_relative(self, tmp_path: Path) -> None:
        """File paths should be normalized relative to session cwd."""
        session_file = tmp_path / "session.jsonl"
        cwd = str(tmp_path)
        lines = [
            {
                "timestamp": "2026-01-06T00:00:00Z",
                "type": "session_meta",
                "payload": {
                    "id": "test",
                    "cwd": cwd,
                    "originator": "codex",
                    "cli_version": "1.0",
                    "timestamp": "2026-01-06T00:00:00Z",
                },
            },
            {
                "timestamp": "2026-01-06T00:00:01Z",
                "type": "response_item",
                "payload": {
                    "type": "function_call",
                    "name": "read_file",
                    "arguments": json.dumps({"path": str(tmp_path / "subdir" / "file.txt")}),
                    "call_id": "call_1",
                },
            },
        ]
        session_file.write_text("\n".join(json.dumps(line) for line in lines) + "\n")

        session = Session(id="test", path=session_file, format="codex", modified_at=0.0)
        adapter = CodexAdapter()
        events = list(adapter.read_events(session))

        tool_events = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_events) == 1
        # Note: File path normalization is now tested via normalizer tests,
        # not via adapter raw_event extraction.

    def test_no_file_ops_for_text_only_messages(self, tmp_path: Path) -> None:
        """Messages without function calls should not have file_ops."""
        session_file = tmp_path / "session.jsonl"
        lines = [
            {
                "timestamp": "2026-01-06T00:00:00Z",
                "type": "session_meta",
                "payload": {
                    "id": "test",
                    "cwd": "/test",
                    "originator": "codex",
                    "cli_version": "1.0",
                    "timestamp": "2026-01-06T00:00:00Z",
                },
            },
            {
                "timestamp": "2026-01-06T00:00:01Z",
                "type": "response_item",
                "payload": {
                    "type": "message",
                    "role": "user",
                    "content": [{"type": "input_text", "text": "Hello"}],
                },
            },
            {
                "timestamp": "2026-01-06T00:00:02Z",
                "type": "response_item",
                "payload": {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "Hi there!"}],
                },
            },
        ]
        session_file.write_text("\n".join(json.dumps(line) for line in lines) + "\n")

        session = Session(id="test", path=session_file, format="codex", modified_at=0.0)
        adapter = CodexAdapter()
        events = list(adapter.read_events(session))

        # Find assistant message events
        assistant_events = [
            e for e in events if isinstance(e, TextMessageChunkEvent) and e.role == Role.ASSISTANT
        ]

        assert len(assistant_events) == 1
