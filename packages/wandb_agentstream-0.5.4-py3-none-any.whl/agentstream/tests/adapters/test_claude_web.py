"""Tests for Claude Web adapter."""

from pathlib import Path

from agentstream.adapters.claude_web import ClaudeWebAdapter
from agentstream.events import (
    CustomEvent,
    ReasoningMessageChunkEvent,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)


class TestClaudeWebAdapter:
    """Tests for ClaudeWebAdapter."""

    def test_name(self):
        """Test adapter name."""
        adapter = ClaudeWebAdapter()
        assert adapter.name == "claude_web"

    def test_get_base_directories_empty(self):
        """Test get_base_directories returns empty list (no local files)."""
        adapter = ClaudeWebAdapter()
        assert adapter.get_base_directories() == []

    def test_matches_path_always_false(self):
        """Test matches_path always returns False (no local files)."""
        adapter = ClaudeWebAdapter()
        assert adapter.matches_path(Path("/some/path.jsonl")) is False
        assert adapter.matches_path(Path.home() / ".claude" / "test.jsonl") is False

    def test_discover_sessions_empty(self):
        """Test discover_sessions returns empty list (no local files)."""
        adapter = ClaudeWebAdapter()
        assert adapter.discover_sessions(Path.home()) == []

    def test_parse_user_message(self):
        """Test parsing a user message event."""
        adapter = ClaudeWebAdapter()

        entry = {
            "type": "user",
            "uuid": "test-uuid-1",
            "message": {"content": "Hello, world!", "role": "user"},
            "session_id": "test-session",
            "_timestamp_ms": 1738360800000,
        }

        events = adapter.parse_source_entry(entry, 0, "test-session")

        assert len(events) == 1
        assert isinstance(events[0], TextMessageChunkEvent)
        assert events[0].delta == "Hello, world!"
        assert events[0].role is not None
        assert events[0].role.value == "user"

    def test_parse_user_message_with_tool_result(self):
        """Test parsing a user message with tool result."""
        adapter = ClaudeWebAdapter()

        entry = {
            "type": "user",
            "uuid": "test-uuid-2",
            "message": {
                "content": [
                    {
                        "type": "tool_result",
                        "tool_use_id": "tool-123",
                        "content": "File contents here",
                        "is_error": False,
                    }
                ],
                "role": "user",
            },
            "_timestamp_ms": 1738360800000,
        }

        events = adapter.parse_source_entry(entry, 0, "test-session")

        assert len(events) == 1
        # Tool results are handled by ToolCallResultEvent

        assert isinstance(events[0], ToolCallResultEvent)
        assert events[0].tool_call_id == "tool-123"

    def test_parse_assistant_message_with_text(self):
        """Test parsing an assistant message with text."""
        adapter = ClaudeWebAdapter()

        entry = {
            "type": "assistant",
            "uuid": "test-uuid-3",
            "message": {
                "content": [{"type": "text", "text": "I will help you with that!"}],
                "role": "assistant",
            },
            "_timestamp_ms": 1738360800000,
        }

        events = adapter.parse_source_entry(entry, 0, "test-session")

        assert len(events) == 1
        assert isinstance(events[0], TextMessageChunkEvent)
        assert events[0].delta == "I will help you with that!"
        assert events[0].role is not None
        assert events[0].role.value == "assistant"

    def test_parse_assistant_message_with_tool_use(self):
        """Test parsing an assistant message with tool use."""
        adapter = ClaudeWebAdapter()

        entry = {
            "type": "assistant",
            "uuid": "test-uuid-4",
            "message": {
                "content": [
                    {"type": "text", "text": "Let me read that file."},
                    {
                        "type": "tool_use",
                        "id": "tool-456",
                        "name": "Read",
                        "input": {"file_path": "/test.py"},
                    },
                ],
                "role": "assistant",
            },
            "_timestamp_ms": 1738360800000,
        }

        events = adapter.parse_source_entry(entry, 0, "test-session")

        assert len(events) == 2
        assert isinstance(events[0], TextMessageChunkEvent)
        assert events[0].delta == "Let me read that file."
        assert isinstance(events[1], ToolCallChunkEvent)
        assert events[1].tool_call_name == "Read"
        assert events[1].tool_call_id == "tool-456"

    def test_parse_assistant_message_with_usage(self):
        """Test parsing an assistant message with token usage."""
        adapter = ClaudeWebAdapter()

        entry = {
            "type": "assistant",
            "uuid": "test-uuid-5",
            "message": {
                "content": [{"type": "text", "text": "Done!"}],
                "role": "assistant",
                "usage": {
                    "input_tokens": 100,
                    "output_tokens": 50,
                    "cache_creation_input_tokens": 1000,
                    "cache_read_input_tokens": 500,
                },
            },
            "_timestamp_ms": 1738360800000,
        }

        events = adapter.parse_source_entry(entry, 0, "test-session")

        # Should have text + token_usage custom event
        assert len(events) == 2
        assert isinstance(events[0], TextMessageChunkEvent)
        assert isinstance(events[1], CustomEvent)
        assert events[1].name == "token_usage"
        assert events[1].value["input_tokens"] == 100
        assert events[1].value["output_tokens"] == 50

    def test_parse_env_manager_log(self):
        """Test parsing an env_manager_log event."""
        adapter = ClaudeWebAdapter()

        entry = {
            "type": "env_manager_log",
            "uuid": "test-uuid-6",
            "data": {
                "category": "init",
                "content": "Initializing environment",
                "level": "info",
                "timestamp": "2026-01-31T12:00:00Z",
            },
        }

        events = adapter.parse_source_entry(entry, 0, "test-session")

        assert len(events) == 1
        assert isinstance(events[0], CustomEvent)
        assert events[0].name == "env_manager_log"
        assert events[0].value["category"] == "init"
        assert events[0].value["content"] == "Initializing environment"

    def test_parse_system_event(self):
        """Test parsing a system event."""
        adapter = ClaudeWebAdapter()

        entry = {
            "type": "system",
            "uuid": "test-uuid-7",
            "cwd": "/home/user/project",
            "model": "claude-opus-4-5-20251101",
            "claude_code_version": "2.1.19",
            "tools": ["Read", "Edit", "Write"],
            "agents": ["Bash", "Explore"],
            "_timestamp_ms": 1738360800000,
        }

        events = adapter.parse_source_entry(entry, 0, "test-session")

        assert len(events) == 1
        assert isinstance(events[0], CustomEvent)
        assert events[0].name == "session_init"
        assert events[0].value["cwd"] == "/home/user/project"
        assert events[0].value["model"] == "claude-opus-4-5-20251101"
        assert events[0].value["claude_code_version"] == "2.1.19"

    def test_parse_daemon_metadata_skipped(self):
        """Test that daemon_metadata entries are skipped."""
        adapter = ClaudeWebAdapter()

        entry = {
            "type": "daemon_metadata",
            "agent_type": "claude_web",
            "session_name": "Test Session",
        }

        events = adapter.parse_source_entry(entry, -1, "test-session")

        assert len(events) == 0

    def test_parse_thinking_blocks(self):
        """Test parsing an assistant message with thinking blocks."""
        adapter = ClaudeWebAdapter()

        entry = {
            "type": "assistant",
            "uuid": "test-uuid-8",
            "message": {
                "content": [
                    {
                        "type": "thinking",
                        "thinking": "Let me think about this...",
                        "signature": "encrypted-sig",
                    },
                    {"type": "text", "text": "Here's my answer."},
                ],
                "role": "assistant",
            },
            "_timestamp_ms": 1738360800000,
        }

        events = adapter.parse_source_entry(entry, 0, "test-session")

        # Should have reasoning + text
        assert len(events) == 2

        assert isinstance(events[0], ReasoningMessageChunkEvent)
        assert events[0].delta == "Let me think about this..."
        assert isinstance(events[1], TextMessageChunkEvent)
        assert events[1].delta == "Here's my answer."

    def test_timestamp_extraction_from_data(self):
        """Test timestamp extraction from nested data field."""
        adapter = ClaudeWebAdapter()

        entry = {
            "type": "env_manager_log",
            "uuid": "test-uuid-9",
            "data": {
                "category": "init",
                "content": "Test",
                "level": "info",
                "timestamp": "2026-01-31T12:00:00Z",
            },
        }

        events = adapter.parse_source_entry(entry, 0, "test-session")

        assert len(events) == 1
        # Timestamp should be parsed from data.timestamp
        assert events[0].timestamp_ms > 0

    def test_parse_result_event(self):
        """Test parsing a result/summary event."""
        adapter = ClaudeWebAdapter()

        entry = {
            "type": "result",
            "uuid": "test-uuid-result",
            "session_id": "test-session",
            "subtype": "success",
            "duration_ms": 303876,
            "duration_api_ms": 267013,
            "num_turns": 66,
            "total_cost_usd": 5.25,
            "is_error": False,
            "modelUsage": {
                "claude-opus-4-5-20251101": {
                    "inputTokens": 1000,
                    "outputTokens": 500,
                    "cacheCreationInputTokens": 5000,
                    "cacheReadInputTokens": 10000,
                    "costUSD": 5.0,
                }
            },
            "_timestamp_ms": 1738360800000,
        }

        events = adapter.parse_source_entry(entry, 0, "test-session")

        # Should have session_result + model_usage events
        assert len(events) == 2

        # Check session_result
        session_result = events[0]
        assert isinstance(session_result, CustomEvent)
        assert session_result.name == "session_result"
        assert session_result.value["duration_ms"] == 303876
        assert session_result.value["duration_api_ms"] == 267013
        assert session_result.value["num_turns"] == 66
        assert session_result.value["total_cost_usd"] == 5.25

        # Check model_usage
        model_usage = events[1]
        assert isinstance(model_usage, CustomEvent)
        assert model_usage.name == "model_usage"
        assert model_usage.value["model"] == "claude-opus-4-5-20251101"
        assert model_usage.value["input_tokens"] == 1000
        assert model_usage.value["output_tokens"] == 500
