# tests/adapters/test_claude.py
"""Tests for Claude Code adapter session discovery."""

from __future__ import annotations

import io
import json
import time
from pathlib import Path
from typing import Any

from agentstream.adapters.base import Session
from agentstream.adapters.claude import ClaudeAdapter
from agentstream.events import (
    EventType,
    ReasoningMessageChunkEvent,
    Role,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)


class TestClaudeAdapter:
    def test_name(self) -> None:
        adapter = ClaudeAdapter()
        assert adapter.name == "claude"

    def test_discover_sessions_from_fixtures(self, tmp_path: Path, monkeypatch: Any) -> None:
        # Mock home directory to use tmp_path
        mock_home = tmp_path / "home"
        mock_home.mkdir()
        monkeypatch.setattr(Path, "home", lambda: mock_home)

        # Create a mock project directory
        project_dir = tmp_path / "project"
        project_dir.mkdir()

        # Claude hashes the path by replacing / with -
        project_hash = str(project_dir.resolve()).replace("/", "-")
        sessions_dir = mock_home / ".claude" / "projects" / project_hash
        sessions_dir.mkdir(parents=True)

        # Create a session file with valid UUID name
        session_file = sessions_dir / "a1b2c3d4-e5f6-7890-abcd-ef1234567890.jsonl"
        session_file.write_text(
            '{"type":"user","message":{"content":"test"},'
            '"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
        )

        adapter = ClaudeAdapter()
        sessions = adapter.discover_sessions(project_dir)

        assert len(sessions) == 1
        assert sessions[0].format == "claude"
        assert sessions[0].path == session_file
        assert sessions[0].id == "a1b2c3d4-e5f6-7890-abcd-ef1234567890"

    def test_discover_sessions_returns_empty_for_no_claude(self, tmp_path: Path) -> None:
        adapter = ClaudeAdapter()
        sessions = adapter.discover_sessions(tmp_path)
        assert sessions == []

    def test_discover_sessions_returns_empty_for_no_projects_dir(self, tmp_path: Path) -> None:
        # Create .claude but not projects subdirectory
        (tmp_path / ".claude").mkdir()
        adapter = ClaudeAdapter()
        sessions = adapter.discover_sessions(tmp_path)
        assert sessions == []

    def test_discover_sessions_filters_non_uuid_files(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        """Session discovery should exclude files that aren't UUIDs or agent-XXXX."""
        # Mock home directory
        mock_home = tmp_path / "home"
        mock_home.mkdir()
        monkeypatch.setattr(Path, "home", lambda: mock_home)

        # Create project directory
        project_dir = tmp_path / "project"
        project_dir.mkdir()

        project_hash = str(project_dir.resolve()).replace("/", "-")
        sessions_dir = mock_home / ".claude" / "projects" / project_hash
        sessions_dir.mkdir(parents=True)

        # Create a valid UUID session file
        valid_session = sessions_dir / "a1b2c3d4-e5f6-7890-abcd-ef1234567890.jsonl"
        valid_session.write_text('{"type":"user"}\n')

        # Create non-UUID/non-agent files that should be excluded
        random_file = sessions_dir / "session-backup.jsonl"
        random_file.write_text('{"type":"backup"}\n')

        other_file = sessions_dir / "random.jsonl"
        other_file.write_text('{"type":"other"}\n')

        adapter = ClaudeAdapter()
        sessions = adapter.discover_sessions(project_dir)

        assert len(sessions) == 1
        assert sessions[0].id == "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
        assert sessions[0].path == valid_session

    def test_discover_sessions_includes_subagent_files(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        """Session discovery should include agent-XXXX subagent files."""
        # Mock home directory
        mock_home = tmp_path / "home"
        mock_home.mkdir()
        monkeypatch.setattr(Path, "home", lambda: mock_home)

        # Create project directory
        project_dir = tmp_path / "project"
        project_dir.mkdir()

        project_hash = str(project_dir.resolve()).replace("/", "-")
        sessions_dir = mock_home / ".claude" / "projects" / project_hash
        sessions_dir.mkdir(parents=True)

        # Create a valid UUID session file (parent)
        parent_session = sessions_dir / "a1b2c3d4-e5f6-7890-abcd-ef1234567890.jsonl"
        parent_session.write_text('{"type":"user"}\n')

        # Create agent-XXXX subagent file
        agent_file = sessions_dir / "agent-abc123f.jsonl"
        agent_file.write_text(
            '{"type":"user","sessionId":"a1b2c3d4-e5f6-7890-abcd-ef1234567890"}\n'
        )

        adapter = ClaudeAdapter()
        sessions = adapter.discover_sessions(project_dir)

        # Should find both parent and subagent
        assert len(sessions) == 2
        session_ids = {s.id for s in sessions}
        assert "a1b2c3d4-e5f6-7890-abcd-ef1234567890" in session_ids
        assert "agent-abc123f" in session_ids

    def test_discover_sessions_multiple_sorted_by_mtime(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        """Sessions should be sorted by modification time, newest first."""

        # Mock home directory
        mock_home = tmp_path / "home"
        mock_home.mkdir()
        monkeypatch.setattr(Path, "home", lambda: mock_home)

        # Create project directory
        project_dir = tmp_path / "project"
        project_dir.mkdir()

        project_hash = str(project_dir.resolve()).replace("/", "-")
        sessions_dir = mock_home / ".claude" / "projects" / project_hash
        sessions_dir.mkdir(parents=True)

        # Create older session
        older_session = sessions_dir / "11111111-1111-1111-1111-111111111111.jsonl"
        older_session.write_text('{"type":"user"}\n')

        # Small delay to ensure different mtime
        time.sleep(0.01)

        # Create newer session
        newer_session = sessions_dir / "22222222-2222-2222-2222-222222222222.jsonl"
        newer_session.write_text('{"type":"user"}\n')

        adapter = ClaudeAdapter()
        sessions = adapter.discover_sessions(project_dir)

        assert len(sessions) == 2
        # Newest should be first
        assert sessions[0].id == "22222222-2222-2222-2222-222222222222"
        assert sessions[1].id == "11111111-1111-1111-1111-111111111111"

    def test_read_events_empty_file(self, tmp_path: Path) -> None:
        """read_events should return empty list for empty file."""
        empty_file = tmp_path / "empty.jsonl"
        empty_file.write_text("")

        adapter = ClaudeAdapter()
        session = Session(
            id="test",
            path=empty_file,
            format="claude",
            modified_at=0.0,
        )

        events = list(adapter.read_events(session))
        assert events == []

    def test_write_events_empty(self) -> None:
        """write_events with no events should produce empty output."""

        adapter = ClaudeAdapter()
        dest = io.StringIO()

        adapter.write_events([], dest)
        assert dest.getvalue() == ""


class TestClaudeReadEvents:
    def test_read_simple_session(self, tmp_path: Path) -> None:
        # Create a simple session
        session_file = tmp_path / "session.jsonl"
        session_file.write_text(
            '{"type":"user","message":{"content":"Hello"},"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
            '{"type":"assistant","message":{"content":[{"type":"text","text":"Hi!"}]},"uuid":"a1","parentUuid":"u1","timestamp":"2024-01-01T00:00:01Z"}\n'
        )

        session = Session(
            id="test",
            path=session_file,
            format="claude",
            modified_at=0.0,
        )

        adapter = ClaudeAdapter()
        events = list(adapter.read_events(session))

        # Should have: RunStarted, User message chunk, Assistant message chunk, RunFinished
        event_types = [e.type for e in events]

        assert EventType.RUN_STARTED in event_types
        assert EventType.TEXT_MESSAGE_CHUNK in event_types
        assert EventType.RUN_FINISHED in event_types

    def test_user_message_events(self, tmp_path: Path) -> None:
        session_file = tmp_path / "session.jsonl"
        user_entry = (
            '{"type":"user","message":{"content":"Hello world"},'
            '"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
        )
        session_file.write_text(user_entry)

        session = Session(id="test", path=session_file, format="claude", modified_at=0.0)
        adapter = ClaudeAdapter()
        events = list(adapter.read_events(session))

        # Find the text message chunk events
        msg_events = [e for e in events if e.type == EventType.TEXT_MESSAGE_CHUNK]

        assert len(msg_events) == 1
        chunk = msg_events[0]
        assert isinstance(chunk, TextMessageChunkEvent)
        assert chunk.role == Role.USER
        assert chunk.delta == "Hello world"


class TestClaudeToolCalls:
    def test_tool_use_block(self, tmp_path: Path) -> None:
        session_file = tmp_path / "session.jsonl"
        session_file.write_text(
            '{"type":"assistant","message":{"content":[{"type":"tool_use","id":"tc1","name":"Read","input":{"file_path":"/tmp/test"}}]},"uuid":"a1","timestamp":"2024-01-01T00:00:00Z"}\n'
        )

        session = Session(id="test", path=session_file, format="claude", modified_at=0.0)
        adapter = ClaudeAdapter()
        events = list(adapter.read_events(session))

        tool_events = [e for e in events if e.type == EventType.TOOL_CALL_CHUNK]

        assert len(tool_events) == 1

        chunk = tool_events[0]
        assert isinstance(chunk, ToolCallChunkEvent)
        assert chunk.tool_call_name == "Read"
        assert chunk.tool_call_id == "tc1"
        assert chunk.delta is not None
        assert "file_path" in chunk.delta

    def test_tool_result_from_next_entry(self, tmp_path: Path) -> None:
        session_file = tmp_path / "session.jsonl"
        # fmt: off
        assistant_entry = (
            '{"type":"assistant","message":{"content":[{"type":"tool_use",'
            '"id":"tc1","name":"Read","input":{"file_path":"/tmp"}}]},'
            '"uuid":"a1","timestamp":"2024-01-01T00:00:00Z"}\n'
        )
        user_entry = (
            '{"type":"user","message":{"content":[{"type":"tool_result",'
            '"tool_use_id":"tc1","content":"file contents"}]},'
            '"uuid":"u1","timestamp":"2024-01-01T00:00:01Z"}\n'
        )
        # fmt: on
        session_file.write_text(assistant_entry + user_entry)

        session = Session(id="test", path=session_file, format="claude", modified_at=0.0)
        adapter = ClaudeAdapter()
        events = list(adapter.read_events(session))

        result_events = [e for e in events if e.type == EventType.TOOL_CALL_RESULT]
        assert len(result_events) == 1
        assert isinstance(result_events[0], ToolCallResultEvent)
        # Result is now JSON with content field for consistency with structured results
        result_data = json.loads(result_events[0].result)
        assert result_data["content"] == "file contents"
        assert result_events[0].tool_call_id == "tc1"

    def test_tool_result_error_with_string_tool_use_result(self, tmp_path: Path) -> None:
        session_file = tmp_path / "session.jsonl"
        # fmt: off
        assistant_entry = (
            '{"type":"assistant","message":{"content":[{"type":"tool_use",'
            '"id":"tc1","name":"Bash","input":{"command":"false"}}]},'
            '"uuid":"a1","timestamp":"2024-01-01T00:00:00Z"}\n'
        )
        user_entry = (
            '{"type":"user","message":{"content":[{"type":"tool_result",'
            '"tool_use_id":"tc1","content":"Exit code 1","is_error":true}]},'
            '"uuid":"u1","timestamp":"2024-01-01T00:00:01Z",'
            '"toolUseResult":"Error: Exit code 1"}\n'
        )
        # fmt: on
        session_file.write_text(assistant_entry + user_entry)

        session = Session(id="test", path=session_file, format="claude", modified_at=0.0)
        adapter = ClaudeAdapter()
        events = list(adapter.read_events(session))

        result_events = [e for e in events if e.type == EventType.TOOL_CALL_RESULT]
        assert len(result_events) == 1
        assert isinstance(result_events[0], ToolCallResultEvent)

        result_data = json.loads(result_events[0].result)
        assert result_data["content"] == "Exit code 1"
        assert result_events[0].tool_call_id == "tc1"
        assert result_events[0].is_error is True


class TestClaudeReasoning:
    def test_thinking_block(self, tmp_path: Path) -> None:
        session_file = tmp_path / "session.jsonl"
        # fmt: off
        session_file.write_text(
            '{"type":"assistant","message":{"content":'
            '[{"type":"thinking","thinking":"Let me think..."},'
            '{"type":"text","text":"Answer"}]},'
            '"uuid":"a1","timestamp":"2024-01-01T00:00:00Z"}\n'
        )
        # fmt: on

        session = Session(id="test", path=session_file, format="claude", modified_at=0.0)
        adapter = ClaudeAdapter()
        events = list(adapter.read_events(session))

        # Find reasoning chunk events
        reasoning_events = [e for e in events if e.type == EventType.REASONING_MESSAGE_CHUNK]

        assert len(reasoning_events) == 1  # One chunk event per thinking block

        chunk = reasoning_events[0]
        assert isinstance(chunk, ReasoningMessageChunkEvent)
        assert chunk.delta == "Let me think..."

    def test_read_fixture_with_thinking(self) -> None:
        """Test reading the actual fixture file."""
        fixture_path = (
            Path(__file__).parent.parent / "fixtures" / "claude" / "claude_with_thinking.jsonl"
        )

        session = Session(id="test", path=fixture_path, format="claude", modified_at=0.0)
        adapter = ClaudeAdapter()
        events = list(adapter.read_events(session))

        # Should have reasoning chunk events from thinking blocks
        reasoning_events = [e for e in events if e.type == EventType.REASONING_MESSAGE_CHUNK]
        assert len(reasoning_events) == 2  # Two thinking blocks in fixture

        # Check that we get the expected content
        assert isinstance(reasoning_events[0], ReasoningMessageChunkEvent)
        assert reasoning_events[0].delta is not None
        assert "geography" in reasoning_events[0].delta


class TestClaudeFileOperations:
    """Tests for file operation extraction in Claude adapter."""

    def test_file_ops_extracted_from_tool_use(self) -> None:
        """File operations should be present in tool calls."""
        fixture_path = (
            Path(__file__).parent.parent / "fixtures" / "claude" / "claude_with_files.jsonl"
        )
        session = Session(id="test", path=fixture_path, format="claude", modified_at=0.0)
        adapter = ClaudeAdapter()
        events = list(adapter.read_events(session))

        # Find tool call events
        tool_events = [e for e in events if e.type == EventType.TOOL_CALL_CHUNK]

        # Should have 2 tool calls: Write and Edit
        assert len(tool_events) == 2

        # Check Write operation
        write_event = tool_events[0]
        assert isinstance(write_event, ToolCallChunkEvent)
        assert write_event.tool_call_name == "Write"

        # Check Edit operation
        edit_event = tool_events[1]
        assert isinstance(edit_event, ToolCallChunkEvent)
        assert edit_event.tool_call_name == "Edit"

    def test_paths_normalized_to_cwd_relative(self) -> None:
        """Tool calls should be emitted for file operations."""
        fixture_path = (
            Path(__file__).parent.parent / "fixtures" / "claude" / "claude_with_files.jsonl"
        )
        session = Session(id="test", path=fixture_path, format="claude", modified_at=0.0)
        adapter = ClaudeAdapter()
        events = list(adapter.read_events(session))

        tool_events = [e for e in events if e.type == EventType.TOOL_CALL_CHUNK]

        # Should have tool call events
        assert len(tool_events) > 0
        for event in tool_events:
            assert isinstance(event, ToolCallChunkEvent)

    def test_no_file_ops_for_text_only_messages(self, tmp_path: Path) -> None:
        """Messages without tool use should be emitted correctly."""
        session_file = tmp_path / "session.jsonl"
        user_msg = '{"type":"user","message":{"content":"Hello"},'
        user_msg += '"uuid":"u1","timestamp":"2024-01-01T00:00:00Z","cwd":"/project"}\n'
        asst_msg = '{"type":"assistant","message":{"content":[{"type":"text","text":"Hi there!"}]},'
        asst_msg += '"uuid":"a1","timestamp":"2024-01-01T00:00:01Z"}\n'
        session_file.write_text(user_msg + asst_msg)

        session = Session(id="test", path=session_file, format="claude", modified_at=0.0)
        adapter = ClaudeAdapter()
        events = list(adapter.read_events(session))

        # Find assistant message events
        assistant_events = [
            e
            for e in events
            if e.type == EventType.TEXT_MESSAGE_CHUNK and getattr(e, "role", None) == Role.ASSISTANT
        ]

        assert len(assistant_events) == 1
        event = assistant_events[0]
        assert isinstance(event, TextMessageChunkEvent)
