# tests/adapters/test_base.py
from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import IO, Any

import pytest

from agentstream.adapters.base import Adapter, Session
from agentstream.events import Event


class TestSession:
    def test_session_dataclass(self) -> None:
        session = Session(
            id="session-1",
            path=Path("/home/user/.claude/sessions/abc.jsonl"),
            format="claude",
            modified_at=1704067200.0,
        )
        assert session.id == "session-1"
        assert session.format == "claude"

    def test_session_with_metadata(self) -> None:
        session = Session(
            id="s1",
            path=Path("/tmp/test"),
            format="codex",
            modified_at=0.0,
            metadata={"extra": "data"},
        )
        assert session.metadata == {"extra": "data"}


class TestAdapter:
    def test_adapter_is_abstract(self) -> None:
        with pytest.raises(TypeError):
            Adapter()

    def test_adapter_interface(self) -> None:
        """Verify the interface methods exist."""
        assert hasattr(Adapter, "name")
        assert hasattr(Adapter, "discover_sessions")
        assert hasattr(Adapter, "read_events")
        assert hasattr(Adapter, "read_messages")
        assert hasattr(Adapter, "write_events")

    def test_detect_uses_discover_sessions(self) -> None:
        """Default detect() returns True if any sessions found."""

        class MockAdapter(Adapter):
            @property
            def name(self) -> str:
                return "mock"

            def discover_sessions(self, project_dir: Path) -> list[Session]:
                return [Session("s1", Path("/tmp"), "mock", 0.0)]

            def read_events(self, session: Session) -> Iterator[Event]:
                yield from []

            def write_events(self, events: Any, dest: IO[str]) -> None:
                pass

            def parse_source_entry(
                self, entry: dict, entry_index: int, session_id: str
            ) -> list[Event]:
                return []

            def get_base_directories(self) -> list[Path]:
                return [Path("/tmp")]

            def matches_path(self, path: Path) -> bool:
                return True

            def read_entries(self, session: Session) -> list[dict]:
                return []

        adapter = MockAdapter()
        assert adapter.detect(Path("/tmp")) is True

    def test_detect_returns_false_when_no_sessions(self) -> None:
        class EmptyAdapter(Adapter):
            @property
            def name(self) -> str:
                return "empty"

            def discover_sessions(self, project_dir: Path) -> list[Session]:
                return []

            def read_events(self, session: Session) -> Iterator[Event]:
                yield from []

            def write_events(self, events: Any, dest: IO[str]) -> None:
                pass

            def parse_source_entry(
                self, entry: dict, entry_index: int, session_id: str
            ) -> list[Event]:
                return []

            def get_base_directories(self) -> list[Path]:
                return [Path("/tmp")]

            def matches_path(self, path: Path) -> bool:
                return True

            def read_entries(self, session: Session) -> list[dict]:
                return []

        adapter = EmptyAdapter()
        assert adapter.detect(Path("/tmp")) is False
