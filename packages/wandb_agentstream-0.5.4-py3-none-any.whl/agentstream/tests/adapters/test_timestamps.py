"""Tests for timestamp utilities."""

from agentstream.adapters.timestamps import (
    TimestampTracker,
    parse_timestamp_with_fallback,
)


class TestParseTimestampWithFallback:
    """Tests for parse_timestamp_with_fallback function."""

    def test_none_returns_fallback(self):
        """None timestamp should return the fallback value."""
        assert parse_timestamp_with_fallback(None, 1000) == 1000

    def test_valid_int_timestamp(self):
        """Valid integer timestamp should be returned as-is."""
        assert parse_timestamp_with_fallback(1704067200000, 999) == 1704067200000

    def test_zero_int_returns_fallback(self):
        """Zero timestamp should return the fallback value."""
        assert parse_timestamp_with_fallback(0, 1000) == 1000

    def test_negative_int_returns_fallback(self):
        """Negative timestamp should return the fallback value."""
        assert parse_timestamp_with_fallback(-1, 1000) == 1000

    def test_valid_iso_string(self):
        """Valid ISO timestamp string should be parsed correctly."""
        # 2024-01-01T00:00:00Z = 1704067200000ms
        result = parse_timestamp_with_fallback("2024-01-01T00:00:00Z", 999)
        assert result == 1704067200000

    def test_valid_iso_string_with_offset(self):
        """ISO timestamp with offset should be parsed correctly."""
        result = parse_timestamp_with_fallback("2024-01-01T05:00:00+05:00", 999)
        # +05:00 offset means 5:00 local = 00:00 UTC
        assert result == 1704067200000

    def test_invalid_string_returns_fallback(self):
        """Invalid timestamp string should return the fallback value."""
        assert parse_timestamp_with_fallback("not-a-timestamp", 1000) == 1000

    def test_empty_string_returns_fallback(self):
        """Empty string should return the fallback value."""
        assert parse_timestamp_with_fallback("", 1000) == 1000


class TestTimestampTracker:
    """Tests for TimestampTracker class."""

    def test_initialization(self):
        """Tracker should initialize with given fallback."""
        tracker = TimestampTracker(1000)
        assert tracker.last_valid == 1000

    def test_parse_valid_timestamp(self):
        """Valid timestamp should be parsed and tracked."""
        tracker = TimestampTracker(1000)
        result = tracker.parse("2024-01-01T00:00:00Z")
        assert result == 1704067200000
        assert tracker.last_valid == 1704067200000

    def test_parse_invalid_returns_last_valid(self):
        """Invalid timestamp should return last valid timestamp."""
        tracker = TimestampTracker(1000)
        # First parse a valid timestamp
        tracker.parse("2024-01-01T00:00:00Z")
        # Then parse an invalid one
        result = tracker.parse("invalid")
        assert result == 1704067200000  # Returns last valid, not initial fallback

    def test_parse_invalid_with_no_prior_valid(self):
        """Invalid timestamp with no prior valid should return initial fallback."""
        tracker = TimestampTracker(1000)
        result = tracker.parse("invalid")
        assert result == 1000

    def test_get_fallback_without_increment(self):
        """get_fallback should return last_valid when increment is 0."""
        tracker = TimestampTracker(1000, increment_ms=0)
        assert tracker.get_fallback() == 1000
        assert tracker.get_fallback() == 1000  # Same value

    def test_get_fallback_with_increment(self):
        """get_fallback should increment each call when increment_ms > 0."""
        tracker = TimestampTracker(1000, increment_ms=1)
        assert tracker.get_fallback() == 1000  # First call: 1000 + 0*1
        assert tracker.get_fallback() == 1001  # Second call: 1000 + 1*1
        assert tracker.get_fallback() == 1002  # Third call: 1000 + 2*1

    def test_update_with_newer_timestamp(self):
        """update should update last_valid when given newer timestamp."""
        tracker = TimestampTracker(1000, increment_ms=1)
        tracker.update(2000)
        assert tracker.last_valid == 2000

    def test_update_with_older_timestamp(self):
        """update should not change last_valid when given older timestamp."""
        tracker = TimestampTracker(1000)
        tracker.update(2000)
        tracker.update(1500)  # Older than 2000
        assert tracker.last_valid == 2000

    def test_update_resets_increment_counter(self):
        """update should reset the increment counter on valid timestamp."""
        tracker = TimestampTracker(1000, increment_ms=1)
        # Get a few fallbacks to increment counter
        tracker.get_fallback()  # counter = 1
        tracker.get_fallback()  # counter = 2
        # Update with new timestamp
        tracker.update(5000)
        # Next fallback should start from new base
        assert tracker.get_fallback() == 5000  # counter reset to 0, then incremented

    def test_preserves_event_ordering(self):
        """Tracker should preserve event ordering with increments."""
        tracker = TimestampTracker(1000, increment_ms=1)

        # Simulate processing entries with missing timestamps
        fallbacks = [tracker.get_fallback() for _ in range(5)]

        # All fallbacks should be unique and increasing
        assert fallbacks == sorted(fallbacks)
        assert len(set(fallbacks)) == len(fallbacks)


class TestTimestampTrackerIntegration:
    """Integration tests for timestamp tracking in processing."""

    def test_processing_loop_simulation(self):
        """Simulate the processing loop behavior."""
        # Initialize with first entry timestamp
        tracker = TimestampTracker(1704067200000, increment_ms=1)

        entries = [
            {"has_timestamp": True, "ts": 1704067201000},  # Valid timestamp
            {"has_timestamp": False},  # Missing timestamp
            {"has_timestamp": False},  # Missing timestamp
            {"has_timestamp": True, "ts": 1704067205000},  # Valid timestamp
            {"has_timestamp": False},  # Missing timestamp
        ]

        results = []
        for entry in entries:
            if entry["has_timestamp"]:
                ts = entry["ts"]
                tracker.update(ts)
            else:
                ts = tracker.get_fallback()
            results.append(ts)

        # Verify results are non-decreasing
        for i in range(1, len(results)):
            assert results[i] >= results[i - 1], f"Timestamp {i} decreased: {results}"

        # Verify timestamps with valid entries match
        assert results[0] == 1704067201000
        assert results[3] == 1704067205000
