# tests/adapters/test_claude_writer.py
import json
from io import StringIO
from pathlib import Path

from agentstream.adapters.base import Session
from agentstream.adapters.claude import ClaudeAdapter
from agentstream.events import (
    Event,
    Role,
    RunFinishedEvent,
    RunStartedEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    TextMessageStartEvent,
)
from agentstream.grouper import group_events


class TestClaudeWriter:
    def test_write_simple_conversation(self) -> None:
        events: list[Event] = [
            RunStartedEvent(timestamp_ms=1000, thread_id="t1", run_id="r1"),
            TextMessageStartEvent(timestamp_ms=1001, message_id="u1", role=Role.USER),
            TextMessageContentEvent(timestamp_ms=1002, message_id="u1", delta="Hello"),
            TextMessageEndEvent(timestamp_ms=1003, message_id="u1"),
            TextMessageStartEvent(timestamp_ms=2001, message_id="a1", role=Role.ASSISTANT),
            TextMessageContentEvent(timestamp_ms=2002, message_id="a1", delta="Hi there!"),
            TextMessageEndEvent(timestamp_ms=2003, message_id="a1"),
            RunFinishedEvent(timestamp_ms=3000, run_id="r1"),
        ]

        adapter = ClaudeAdapter()
        output = StringIO()
        adapter.write_events(events, output)

        lines = output.getvalue().strip().split("\n")
        assert len(lines) == 2  # User + Assistant entries

        user_entry = json.loads(lines[0])
        assert user_entry["type"] == "user"
        assert user_entry["message"]["content"] == "Hello"

        assistant_entry = json.loads(lines[1])
        assert assistant_entry["type"] == "assistant"
        assert assistant_entry["message"]["content"][0]["type"] == "text"
        assert assistant_entry["message"]["content"][0]["text"] == "Hi there!"


class TestClaudeRoundTrip:
    def test_read_write_read_produces_same_events(self, tmp_path: Path) -> None:
        """Read a session, write it back, read again - events should match."""
        # Create original session
        original = tmp_path / "original.jsonl"
        original.write_text(
            '{"type":"user","message":{"content":"Hello"},"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
            '{"type":"assistant","message":{"content":[{"type":"text","text":"Hi!"}]},"uuid":"a1","parent_uuid":"u1","timestamp":"2024-01-01T00:00:01Z"}\n'
        )

        adapter = ClaudeAdapter()
        session = Session(id="test", path=original, format="claude", modified_at=0.0)

        # Read original
        events1 = list(adapter.read_events(session))

        # Write to new file
        output = StringIO()
        adapter.write_events(events1, output)

        # Write to disk and read back
        roundtrip = tmp_path / "roundtrip.jsonl"
        roundtrip.write_text(output.getvalue())

        session2 = Session(id="test2", path=roundtrip, format="claude", modified_at=0.0)
        events2 = list(adapter.read_events(session2))

        # Compare event types and key content
        types1 = [e.type for e in events1]
        types2 = [e.type for e in events2]
        assert types1 == types2

        # Compare message content

        msgs1 = list(group_events(events1))
        msgs2 = list(group_events(events2))

        assert len(msgs1) == len(msgs2)
        for m1, m2 in zip(msgs1, msgs2, strict=True):
            assert m1.role == m2.role
            assert m1.text == m2.text


class TestClaudeMetadataRoundTrip:
    def test_preserves_parent_uuid(self, tmp_path: Path) -> None:
        """Parent UUID should survive round-trip."""
        original = tmp_path / "original.jsonl"
        # Use camelCase in input (matches Claude's actual format)
        original.write_text(
            '{"type":"user","message":{"content":"Hello"},"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
            '{"type":"assistant","message":{"content":[{"type":"text","text":"Hi!"}]},"uuid":"a1","parentUuid":"u1","timestamp":"2024-01-01T00:00:01Z"}\n'
        )

        adapter = ClaudeAdapter()
        session = Session(id="test", path=original, format="claude", modified_at=0.0)

        events = list(adapter.read_events(session))
        output = StringIO()
        adapter.write_events(events, output)

        lines = output.getvalue().strip().split("\n")
        assistant_entry = json.loads(lines[1])

        # Output uses camelCase
        assert assistant_entry.get("parentUuid") == "u1"

    def test_preserves_session_metadata(self, tmp_path: Path) -> None:
        """Session ID and cwd should survive round-trip."""
        original = tmp_path / "original.jsonl"
        # Use camelCase in input (matches Claude's actual format)
        original.write_text(
            '{"type":"user","message":{"content":"Hello"},"uuid":"u1","timestamp":"2024-01-01T00:00:00Z","sessionId":"sess-123","cwd":"/home/user/project"}\n'
        )

        adapter = ClaudeAdapter()
        session = Session(id="test", path=original, format="claude", modified_at=0.0)

        events = list(adapter.read_events(session))
        output = StringIO()
        adapter.write_events(events, output)

        lines = output.getvalue().strip().split("\n")
        entry = json.loads(lines[0])

        # Output uses camelCase
        assert entry.get("sessionId") == "sess-123"
        assert entry.get("cwd") == "/home/user/project"
