"""Tests for OpenCode adapter."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agentstream.adapters.base import Session
from agentstream.adapters.opencode import OpenCodeAdapter
from agentstream.events import (
    CustomEvent,
    EventType,
    ReasoningMessageChunkEvent,
    Role,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)


class TestOpenCodeAdapter:
    def test_name(self) -> None:
        adapter = OpenCodeAdapter()
        assert adapter.name == "opencode"

    def test_get_base_directories(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Should return XDG data directory for OpenCode."""
        # Mock XDG_DATA_HOME
        xdg_data = tmp_path / "data"
        xdg_data.mkdir()
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        adapter = OpenCodeAdapter()
        dirs = adapter.get_base_directories()

        assert len(dirs) == 1
        assert dirs[0] == xdg_data / "opencode" / "storage"

    def test_matches_path_session_file(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Should match OpenCode session files."""
        xdg_data = tmp_path / "data"
        storage = xdg_data / "opencode" / "storage" / "session" / "proj_123"
        storage.mkdir(parents=True)
        session_file = storage / "ses_abc.json"
        session_file.write_text("{}")
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        adapter = OpenCodeAdapter()
        assert adapter.matches_path(session_file) is True

    def test_matches_path_message_file(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Should match OpenCode message files."""
        xdg_data = tmp_path / "data"
        storage = xdg_data / "opencode" / "storage" / "message" / "ses_123"
        storage.mkdir(parents=True)
        msg_file = storage / "msg_abc.json"
        msg_file.write_text("{}")
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        adapter = OpenCodeAdapter()
        assert adapter.matches_path(msg_file) is True

    def test_matches_path_part_file(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Should match OpenCode part files."""
        xdg_data = tmp_path / "data"
        storage = xdg_data / "opencode" / "storage" / "part" / "msg_123"
        storage.mkdir(parents=True)
        part_file = storage / "part_abc.json"
        part_file.write_text("{}")
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        adapter = OpenCodeAdapter()
        assert adapter.matches_path(part_file) is True

    def test_matches_path_non_opencode(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Should not match non-OpenCode files."""
        xdg_data = tmp_path / "data"
        xdg_data.mkdir()
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        adapter = OpenCodeAdapter()
        other_file = tmp_path / "other.json"
        other_file.write_text("{}")
        assert adapter.matches_path(other_file) is False

    def test_discover_sessions_finds_opencode_sessions(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        """Should find OpenCode sessions matching project cwd."""
        xdg_data = tmp_path / "data"
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        # Create project directory
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()

        # Create OpenCode storage structure
        storage = xdg_data / "opencode" / "storage"
        session_dir = storage / "session" / "proj_abc"
        session_dir.mkdir(parents=True)
        project_file_dir = storage / "project"
        project_file_dir.mkdir(parents=True)

        # Create project file with worktree
        project_file = project_file_dir / "proj_abc.json"
        project_file.write_text(
            json.dumps(
                {
                    "id": "proj_abc",
                    "worktree": str(project_dir.resolve()),
                    "vcs": "git",
                }
            )
        )

        # Create session file
        session_file = session_dir / "ses_test123.json"
        session_file.write_text(
            json.dumps(
                {
                    "id": "ses_test123",
                    "projectID": "proj_abc",
                    "directory": str(project_dir.resolve()),
                    "time": {"created": 1704067200000, "updated": 1704067260000},
                }
            )
        )

        adapter = OpenCodeAdapter()
        sessions = adapter.discover_sessions(project_dir)

        assert len(sessions) == 1
        assert sessions[0].format == "opencode"
        assert sessions[0].id == "ses_test123"

    def test_discover_sessions_returns_empty_for_no_opencode(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        """Should return empty list when no OpenCode storage exists."""
        xdg_data = tmp_path / "data"
        xdg_data.mkdir()
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        adapter = OpenCodeAdapter()
        sessions = adapter.discover_sessions(tmp_path)
        assert sessions == []

    def test_discover_sessions_filters_by_worktree(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Should only return sessions where worktree matches project."""
        xdg_data = tmp_path / "data"
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        project_dir = tmp_path / "myproject"
        project_dir.mkdir()

        storage = xdg_data / "opencode" / "storage"
        project_file_dir = storage / "project"
        project_file_dir.mkdir(parents=True)

        # Matching project
        match_session_dir = storage / "session" / "proj_match"
        match_session_dir.mkdir(parents=True)
        (project_file_dir / "proj_match.json").write_text(
            json.dumps({"id": "proj_match", "worktree": str(project_dir.resolve())})
        )
        (match_session_dir / "ses_match.json").write_text(
            json.dumps(
                {
                    "id": "ses_match",
                    "projectID": "proj_match",
                    "directory": str(project_dir),
                    "time": {"created": 1704067200000},
                }
            )
        )

        # Non-matching project
        other_session_dir = storage / "session" / "proj_other"
        other_session_dir.mkdir(parents=True)
        (project_file_dir / "proj_other.json").write_text(
            json.dumps({"id": "proj_other", "worktree": "/other/project"})
        )
        (other_session_dir / "ses_other.json").write_text(
            json.dumps(
                {
                    "id": "ses_other",
                    "projectID": "proj_other",
                    "directory": "/other/project",
                    "time": {"created": 1704067200000},
                }
            )
        )

        adapter = OpenCodeAdapter()
        sessions = adapter.discover_sessions(project_dir)

        ids = {s.id for s in sessions}
        assert "ses_match" in ids
        assert "ses_other" not in ids


class TestOpenCodeReadEntries:
    """Test reading raw entries from OpenCode sessions."""

    def test_read_entries_session_only(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Should read session entry when no messages exist."""
        xdg_data = tmp_path / "data"
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        storage = xdg_data / "opencode" / "storage"
        session_dir = storage / "session" / "proj_abc"
        session_dir.mkdir(parents=True)

        session_data = {
            "id": "ses_test",
            "projectID": "proj_abc",
            "directory": "/home/user/project",
            "time": {"created": 1704067200000},
        }
        session_file = session_dir / "ses_test.json"
        session_file.write_text(json.dumps(session_data))

        session = Session(id="ses_test", path=session_file, format="opencode", modified_at=0.0)
        adapter = OpenCodeAdapter()
        entries = adapter.read_entries(session)

        assert len(entries) == 1
        assert entries[0]["entry_index"] == 0
        assert entries[0]["entry_type"] == "session"
        assert json.loads(entries[0]["entry_content"])["id"] == "ses_test"

    def test_read_entries_with_messages_and_parts(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Should read session, message, and part entries."""
        xdg_data = tmp_path / "data"
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        storage = xdg_data / "opencode" / "storage"

        # Create session
        session_dir = storage / "session" / "proj_abc"
        session_dir.mkdir(parents=True)
        session_file = session_dir / "ses_test.json"
        session_file.write_text(
            json.dumps(
                {
                    "id": "ses_test",
                    "projectID": "proj_abc",
                    "directory": "/home/user/project",
                    "time": {"created": 1704067200000},
                }
            )
        )

        # Create message
        msg_dir = storage / "message" / "ses_test"
        msg_dir.mkdir(parents=True)
        (msg_dir / "msg_1.json").write_text(
            json.dumps(
                {
                    "id": "msg_1",
                    "sessionID": "ses_test",
                    "role": "user",
                    "time": {"created": 1704067201000},
                }
            )
        )

        # Create part
        part_dir = storage / "part" / "msg_1"
        part_dir.mkdir(parents=True)
        (part_dir / "part_1.json").write_text(
            json.dumps(
                {
                    "id": "part_1",
                    "sessionID": "ses_test",
                    "messageID": "msg_1",
                    "type": "text",
                    "text": "Hello!",
                }
            )
        )

        session = Session(id="ses_test", path=session_file, format="opencode", modified_at=0.0)
        adapter = OpenCodeAdapter()
        entries = adapter.read_entries(session)

        assert len(entries) == 3
        assert entries[0]["entry_type"] == "session"
        assert entries[1]["entry_type"] == "message"
        assert entries[2]["entry_type"] == "part"


class TestOpenCodeReadEvents:
    """Test reading AG-UI events from OpenCode sessions."""

    def test_read_events_simple_session(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Read events from a simple OpenCode session."""
        xdg_data = tmp_path / "data"
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        storage = xdg_data / "opencode" / "storage"

        # Create session
        session_dir = storage / "session" / "proj_abc"
        session_dir.mkdir(parents=True)
        session_file = session_dir / "ses_test.json"
        session_file.write_text(
            json.dumps(
                {
                    "id": "ses_test",
                    "projectID": "proj_abc",
                    "directory": "/home/user/project",
                    "time": {"created": 1704067200000},
                }
            )
        )

        # Create user message
        msg_dir = storage / "message" / "ses_test"
        msg_dir.mkdir(parents=True)
        (msg_dir / "msg_user.json").write_text(
            json.dumps(
                {
                    "id": "msg_user",
                    "sessionID": "ses_test",
                    "role": "user",
                    "time": {"created": 1704067201000},
                }
            )
        )

        # Create user text part
        user_part_dir = storage / "part" / "msg_user"
        user_part_dir.mkdir(parents=True)
        (user_part_dir / "part_text.json").write_text(
            json.dumps(
                {
                    "id": "part_text",
                    "sessionID": "ses_test",
                    "messageID": "msg_user",
                    "type": "text",
                    "text": "Hello OpenCode!",
                }
            )
        )

        # Create assistant message
        (msg_dir / "msg_asst.json").write_text(
            json.dumps(
                {
                    "id": "msg_asst",
                    "sessionID": "ses_test",
                    "role": "assistant",
                    "time": {"created": 1704067202000},
                }
            )
        )

        # Create assistant text part
        asst_part_dir = storage / "part" / "msg_asst"
        asst_part_dir.mkdir(parents=True)
        (asst_part_dir / "part_text.json").write_text(
            json.dumps(
                {
                    "id": "part_text2",
                    "sessionID": "ses_test",
                    "messageID": "msg_asst",
                    "type": "text",
                    "text": "Hello! How can I help?",
                }
            )
        )

        session = Session(id="ses_test", path=session_file, format="opencode", modified_at=0.0)
        adapter = OpenCodeAdapter()
        events = list(adapter.read_events(session))

        event_types = [e.type for e in events]
        assert EventType.RUN_STARTED in event_types
        assert EventType.TEXT_MESSAGE_CHUNK in event_types
        assert EventType.RUN_FINISHED in event_types

    def test_read_events_with_reasoning(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Read reasoning events from OpenCode session."""
        xdg_data = tmp_path / "data"
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        storage = xdg_data / "opencode" / "storage"

        # Create session
        session_dir = storage / "session" / "proj_abc"
        session_dir.mkdir(parents=True)
        session_file = session_dir / "ses_test.json"
        session_file.write_text(
            json.dumps(
                {
                    "id": "ses_test",
                    "projectID": "proj_abc",
                    "directory": "/home/user/project",
                    "time": {"created": 1704067200000},
                }
            )
        )

        # Create assistant message
        msg_dir = storage / "message" / "ses_test"
        msg_dir.mkdir(parents=True)
        (msg_dir / "msg_asst.json").write_text(
            json.dumps(
                {
                    "id": "msg_asst",
                    "sessionID": "ses_test",
                    "role": "assistant",
                    "time": {"created": 1704067201000},
                }
            )
        )

        # Create reasoning part
        part_dir = storage / "part" / "msg_asst"
        part_dir.mkdir(parents=True)
        (part_dir / "part_reason.json").write_text(
            json.dumps(
                {
                    "id": "part_reason",
                    "sessionID": "ses_test",
                    "messageID": "msg_asst",
                    "type": "reasoning",
                    "text": "Let me think about this...",
                }
            )
        )

        session = Session(id="ses_test", path=session_file, format="opencode", modified_at=0.0)
        adapter = OpenCodeAdapter()
        events = list(adapter.read_events(session))

        reasoning = [e for e in events if isinstance(e, ReasoningMessageChunkEvent)]
        assert len(reasoning) == 1
        assert reasoning[0].delta == "Let me think about this..."

    def test_read_events_with_tool_calls(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Read tool call events from OpenCode session."""
        xdg_data = tmp_path / "data"
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        storage = xdg_data / "opencode" / "storage"

        # Create session
        session_dir = storage / "session" / "proj_abc"
        session_dir.mkdir(parents=True)
        session_file = session_dir / "ses_test.json"
        session_file.write_text(
            json.dumps(
                {
                    "id": "ses_test",
                    "projectID": "proj_abc",
                    "directory": "/home/user/project",
                    "time": {"created": 1704067200000},
                }
            )
        )

        # Create assistant message
        msg_dir = storage / "message" / "ses_test"
        msg_dir.mkdir(parents=True)
        (msg_dir / "msg_asst.json").write_text(
            json.dumps(
                {
                    "id": "msg_asst",
                    "sessionID": "ses_test",
                    "role": "assistant",
                    "time": {"created": 1704067201000},
                }
            )
        )

        # Create tool part
        part_dir = storage / "part" / "msg_asst"
        part_dir.mkdir(parents=True)
        (part_dir / "part_tool.json").write_text(
            json.dumps(
                {
                    "id": "part_tool",
                    "sessionID": "ses_test",
                    "messageID": "msg_asst",
                    "type": "tool",
                    "callID": "call_123",
                    "tool": "read",
                    "state": {
                        "status": "completed",
                        "input": {"filePath": "/home/user/project/README.md"},
                        "output": "# My Project",
                    },
                }
            )
        )

        session = Session(id="ses_test", path=session_file, format="opencode", modified_at=0.0)
        adapter = OpenCodeAdapter()
        events = list(adapter.read_events(session))

        tool_chunks = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_chunks) == 1
        assert tool_chunks[0].tool_call_name == "read"
        assert tool_chunks[0].tool_call_id == "call_123"

        tool_results = [e for e in events if isinstance(e, ToolCallResultEvent)]
        assert len(tool_results) == 1
        assert tool_results[0].result == "# My Project"

    def test_read_events_has_source_entries(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Source entry custom events should be emitted."""
        xdg_data = tmp_path / "data"
        monkeypatch.setenv("XDG_DATA_HOME", str(xdg_data))

        storage = xdg_data / "opencode" / "storage"

        # Create session
        session_dir = storage / "session" / "proj_abc"
        session_dir.mkdir(parents=True)
        session_file = session_dir / "ses_test.json"
        session_file.write_text(
            json.dumps(
                {
                    "id": "ses_test",
                    "projectID": "proj_abc",
                    "directory": "/home/user/project",
                    "time": {"created": 1704067200000},
                }
            )
        )

        session = Session(id="ses_test", path=session_file, format="opencode", modified_at=0.0)
        adapter = OpenCodeAdapter()
        events = list(adapter.read_events(session))

        source_entries = [
            e for e in events if isinstance(e, CustomEvent) and e.name == "source_entry"
        ]
        assert len(source_entries) >= 1
        assert source_entries[0].value["format"] == "opencode"
        assert source_entries[0].value["entry_type"] == "session"


class TestOpenCodeParseSourceEntry:
    """Test parsing individual source entries."""

    def test_parse_user_message_entry(self) -> None:
        """Parse a user message entry - should not emit events (content is in parts)."""
        adapter = OpenCodeAdapter()
        entry = {
            "id": "msg_user",
            "sessionID": "ses_test",
            "role": "user",
            "time": {"created": 1704067200000},
        }

        events = adapter.parse_source_entry(entry, 0, "ses_test")

        # User message entries don't emit events - content is in parts
        assert len(events) == 0

    def test_parse_user_text_part_entry(self) -> None:
        """Parse a text part entry for a user message."""
        adapter = OpenCodeAdapter()
        entry = {
            "id": "part_text",
            "sessionID": "ses_test",
            "messageID": "msg_user",
            "type": "text",
            "text": "Hello!",
            "_parent_role": "user",  # Injected by read_entries
            "time": {"created": 1704067200000},
        }

        events = adapter.parse_source_entry(entry, 1, "ses_test")

        text_events = [e for e in events if isinstance(e, TextMessageChunkEvent)]
        assert len(text_events) == 1
        assert text_events[0].role == Role.USER
        assert text_events[0].delta == "Hello!"

    def test_parse_text_part_entry(self) -> None:
        """Parse a text part entry for an assistant message."""
        adapter = OpenCodeAdapter()
        entry = {
            "id": "part_text",
            "sessionID": "ses_test",
            "messageID": "msg_asst",
            "type": "text",
            "text": "Here is my response.",
            "_parent_role": "assistant",  # Injected by read_entries
            "time": {"created": 1704067200000},
        }

        events = adapter.parse_source_entry(entry, 1, "ses_test")

        text_events = [e for e in events if isinstance(e, TextMessageChunkEvent)]
        assert len(text_events) == 1
        assert text_events[0].role == Role.ASSISTANT
        assert text_events[0].delta == "Here is my response."

    def test_parse_reasoning_part_entry(self) -> None:
        """Parse a reasoning part entry."""
        adapter = OpenCodeAdapter()
        entry = {
            "id": "part_reasoning",
            "sessionID": "ses_test",
            "messageID": "msg_asst",
            "type": "reasoning",
            "text": "Let me think...",
            "time": {"created": 1704067200000},
        }

        events = adapter.parse_source_entry(entry, 1, "ses_test")

        reasoning_events = [e for e in events if isinstance(e, ReasoningMessageChunkEvent)]
        assert len(reasoning_events) == 1
        assert reasoning_events[0].delta == "Let me think..."

    def test_parse_tool_part_entry(self) -> None:
        """Parse a tool part entry."""
        adapter = OpenCodeAdapter()
        entry = {
            "id": "part_tool",
            "sessionID": "ses_test",
            "messageID": "msg_asst",
            "type": "tool",
            "callID": "call_abc",
            "tool": "read",
            "state": {
                "status": "completed",
                "input": {"filePath": "/test/file.py"},
                "output": "file content",
            },
            "time": {"created": 1704067200000},
        }

        events = adapter.parse_source_entry(entry, 1, "ses_test")

        tool_chunks = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_chunks) == 1
        assert tool_chunks[0].tool_call_name == "read"

        tool_results = [e for e in events if isinstance(e, ToolCallResultEvent)]
        assert len(tool_results) == 1
        assert tool_results[0].result == "file content"

    def test_parse_tool_error_entry(self) -> None:
        """Parse a tool part entry with error status."""
        adapter = OpenCodeAdapter()
        entry = {
            "id": "part_tool",
            "sessionID": "ses_test",
            "messageID": "msg_asst",
            "type": "tool",
            "callID": "call_abc",
            "tool": "read",
            "state": {
                "status": "error",
                "input": {"filePath": "/nonexistent/file.py"},
                "error": "File not found",
            },
            "time": {"created": 1704067200000},
        }

        events = adapter.parse_source_entry(entry, 1, "ses_test")

        tool_results = [e for e in events if isinstance(e, ToolCallResultEvent)]
        assert len(tool_results) == 1
        assert tool_results[0].is_error is True
        assert tool_results[0].result == "File not found"


class TestOpenCodeTimestampFallback:
    """Tests for timestamp fallback behavior.

    These tests verify that the adapter correctly uses _timestamp_ms
    (injected by processing.py) as a fallback when entries have missing
    timestamps. This prevents incorrect duration calculations that can
    occur when ts=0 is used.
    """

    def test_parse_source_entry_uses_timestamp_ms_fallback(self) -> None:
        """Entry with no timestamps should use _timestamp_ms fallback."""
        adapter = OpenCodeAdapter()
        fallback_ts = 1704067200000  # Injected by processing.py

        entry = {
            "id": "part_text",
            "sessionID": "ses_test",
            "messageID": "msg_asst",
            "type": "text",
            "text": "Response text",
            "_parent_role": "assistant",
            # No time.created, no _parent_timestamp_ms, no state.time.start
            "_timestamp_ms": fallback_ts,
        }

        events = adapter.parse_source_entry(entry, 1, "ses_test")

        assert len(events) == 1
        assert events[0].timestamp_ms == fallback_ts

    def test_parse_source_entry_prefers_time_created_over_fallback(self) -> None:
        """Entry with time.created should use that over _timestamp_ms."""
        adapter = OpenCodeAdapter()
        expected_ts = 1704067260000  # time.created
        fallback_ts = 1704067200000  # _timestamp_ms

        entry = {
            "id": "part_text",
            "sessionID": "ses_test",
            "messageID": "msg_asst",
            "type": "text",
            "text": "Response text",
            "_parent_role": "assistant",
            "time": {"created": expected_ts},
            "_timestamp_ms": fallback_ts,
        }

        events = adapter.parse_source_entry(entry, 1, "ses_test")

        assert len(events) == 1
        assert events[0].timestamp_ms == expected_ts

    def test_parse_source_entry_prefers_parent_timestamp_over_fallback(self) -> None:
        """Entry with _parent_timestamp_ms should use that over _timestamp_ms."""
        adapter = OpenCodeAdapter()
        parent_ts = 1704067260000  # From parent message
        fallback_ts = 1704067200000  # _timestamp_ms

        entry = {
            "id": "part_text",
            "sessionID": "ses_test",
            "messageID": "msg_asst",
            "type": "text",
            "text": "Response text",
            "_parent_role": "assistant",
            "_parent_timestamp_ms": parent_ts,
            "_timestamp_ms": fallback_ts,
        }

        events = adapter.parse_source_entry(entry, 1, "ses_test")

        assert len(events) == 1
        assert events[0].timestamp_ms == parent_ts

    def test_parse_source_entry_tool_uses_state_time_start(self) -> None:
        """Tool entry with state.time.start should use that timestamp."""
        adapter = OpenCodeAdapter()
        state_ts = 1704067300000  # Tool execution start time
        fallback_ts = 1704067200000  # _timestamp_ms

        entry = {
            "id": "part_tool",
            "sessionID": "ses_test",
            "messageID": "msg_asst",
            "type": "tool",
            "callID": "call_abc",
            "tool": "read",
            "state": {
                "status": "completed",
                "input": {"filePath": "/test/file.py"},
                "output": "file content",
                "time": {"start": state_ts},
            },
            "_timestamp_ms": fallback_ts,
        }

        events = adapter.parse_source_entry(entry, 1, "ses_test")

        # Tool call chunk should use state.time.start
        tool_chunks = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_chunks) == 1
        assert tool_chunks[0].timestamp_ms == state_ts

    def test_parse_source_entry_zero_timestamp_uses_fallback(self) -> None:
        """Entry with time.created=0 should fall back to _timestamp_ms."""
        adapter = OpenCodeAdapter()
        fallback_ts = 1704067200000

        entry = {
            "id": "part_text",
            "sessionID": "ses_test",
            "messageID": "msg_asst",
            "type": "text",
            "text": "Response text",
            "_parent_role": "assistant",
            "time": {"created": 0},  # Invalid timestamp
            "_timestamp_ms": fallback_ts,
        }

        events = adapter.parse_source_entry(entry, 1, "ses_test")

        assert len(events) == 1
        assert events[0].timestamp_ms == fallback_ts
