"""Round-trip fidelity tests for AgentStream adapters.

These tests verify that reading a session file and writing it back produces
identical JSON output, proving lossless conversion through AG-UI events.
"""

import json
from io import StringIO
from pathlib import Path
from typing import Any

import pytest

from agentstream.adapters.base import Session
from agentstream.adapters.claude import ClaudeAdapter
from agentstream.adapters.codex import CodexAdapter
from agentstream.adapters.gemini import GeminiAdapter
from agentstream.events import CustomEvent

# =============================================================================
# Helper Functions
# =============================================================================


def deep_compare_json(original: Any, converted: Any, path: str = "") -> list[str]:
    """Recursively compare JSON structures, return list of differences with paths."""
    differences = []

    if type(original) is not type(converted):
        return [f"{path}: type {type(original).__name__} -> {type(converted).__name__}"]

    if isinstance(original, dict):
        for key in original.keys() - converted.keys():
            differences.append(f"{path}.{key}: MISSING (was: {repr(original[key])[:50]})")
        for key in converted.keys() - original.keys():
            differences.append(f"{path}.{key}: ADDED (now: {repr(converted[key])[:50]})")
        for key in original.keys() & converted.keys():
            differences.extend(
                deep_compare_json(original[key], converted[key], f"{path}.{key}" if path else key)
            )

    elif isinstance(original, list):
        if len(original) != len(converted):
            differences.append(f"{path}: length {len(original)} -> {len(converted)}")
        for i, (a, b) in enumerate(zip(original, converted, strict=False)):
            differences.extend(deep_compare_json(a, b, f"{path}[{i}]"))

    elif original != converted:
        differences.append(f"{path}: {repr(original)[:30]} -> {repr(converted)[:30]}")

    return differences


def format_differences(differences: list[str]) -> str:
    """Format difference list for assertion message."""
    return "JSON differences:\n" + "\n".join(f"  - {d}" for d in differences[:20])


def filter_source_entries(events: list) -> list:
    """Remove source_entry CustomEvents for cross-format comparison."""

    return [e for e in events if not (isinstance(e, CustomEvent) and e.name == "source_entry")]


def discover_fixtures(format_name: str) -> list[Path]:
    """Find all fixtures for a format (committed + local real sessions)."""
    base = Path(__file__).parent / "fixtures" / format_name
    fixtures = list(base.glob("*.json*"))

    real_dir = base / ".real"
    if real_dir.exists():
        fixtures.extend(real_dir.glob("*.json*"))

    # Exclude source_events.jsonl files - these are daemon-format fixtures,
    # not original agent format fixtures for roundtrip testing
    return [f for f in fixtures if f.is_file() and f.name != "source_events.jsonl"]


def read_jsonl_entries(source) -> list[dict]:
    """Read JSONL entries from a file path or StringIO."""
    if isinstance(source, str | Path):
        with open(source) as f:
            content = f.read()
    else:
        source.seek(0)
        content = source.read()

    return [json.loads(line) for line in content.strip().split("\n") if line.strip()]


def read_json_file(source) -> dict:
    """Read JSON from a file path or StringIO."""
    if isinstance(source, str | Path):
        with open(source) as f:
            return json.load(f)
    else:
        source.seek(0)
        return json.load(source)


# =============================================================================
# Test Classes
# =============================================================================


class TestSameFormatRoundTrip:
    """Proves: format A -> AG-UI -> format A is lossless (JSON deep equality)"""

    @pytest.mark.parametrize("fixture", discover_fixtures("claude"), ids=lambda p: p.name)
    def test_claude_lossless(self, fixture: Path):
        original = read_jsonl_entries(fixture)

        session = Session(id="test", path=fixture, format="claude", modified_at=0.0)
        events = list(ClaudeAdapter().read_events(session))

        buf = StringIO()
        ClaudeAdapter().write_events(events, buf)
        converted = read_jsonl_entries(buf)

        differences = deep_compare_json(original, converted)
        assert not differences, format_differences(differences)

    @pytest.mark.parametrize("fixture", discover_fixtures("codex"), ids=lambda p: p.name)
    def test_codex_lossless(self, fixture: Path):
        original = read_jsonl_entries(fixture)

        session = Session(id="test", path=fixture, format="codex", modified_at=0.0)
        events = list(CodexAdapter().read_events(session))

        buf = StringIO()
        CodexAdapter().write_events(events, buf)
        converted = read_jsonl_entries(buf)

        differences = deep_compare_json(original, converted)
        assert not differences, format_differences(differences)

    @pytest.mark.parametrize("fixture", discover_fixtures("gemini"), ids=lambda p: p.name)
    def test_gemini_lossless(self, fixture: Path):
        original = read_json_file(fixture)

        session = Session(id="test", path=fixture, format="gemini", modified_at=0.0)
        events = list(GeminiAdapter().read_events(session))

        buf = StringIO()
        GeminiAdapter().write_events(events, buf)
        converted = read_json_file(buf)

        differences = deep_compare_json(original, converted)
        assert not differences, format_differences(differences)
