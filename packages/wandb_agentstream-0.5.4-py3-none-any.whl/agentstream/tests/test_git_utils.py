"""Tests for git_utils module."""

from __future__ import annotations

import json
from pathlib import Path

from agentstream.git_utils import (
    _normalize_git_url,
    find_git_root,
    get_git_commit_sha,
    get_git_remote_url,
    resolve_git_repo,
    resolve_git_repo_from_claude_config,
)


class TestResolveGitRepoFromClaudeConfig:
    """Tests for resolve_git_repo_from_claude_config function."""

    def test_exact_match(self, tmp_path: Path) -> None:
        """Claude config with exact path match should return repo slug."""

        config_path = tmp_path / ".claude.json"
        config_path.write_text(
            json.dumps(
                {
                    "githubRepoPaths": {
                        "org/repo": "/Users/test/project",
                        "other/repo": "/Users/test/other",
                    }
                }
            )
        )

        result = resolve_git_repo_from_claude_config(
            cwd="/Users/test/project", config_path=config_path
        )
        assert result == "github.com/org/repo"

    def test_subdirectory_match(self, tmp_path: Path) -> None:
        """Claude config should match subdirectories of registered repos."""

        config_path = tmp_path / ".claude.json"
        config_path.write_text(
            json.dumps(
                {
                    "githubRepoPaths": {
                        "wandb/weave": "/Users/test/weave",
                    }
                }
            )
        )

        # Test various subdirectory patterns
        result = resolve_git_repo_from_claude_config(
            cwd="/Users/test/weave/src", config_path=config_path
        )
        assert result == "github.com/wandb/weave"

        result = resolve_git_repo_from_claude_config(
            cwd="/Users/test/weave/src/deep/nested/dir", config_path=config_path
        )
        assert result == "github.com/wandb/weave"

    def test_prefers_longest_matching_path(self, tmp_path: Path) -> None:
        """When multiple paths match, prefer the longest (most specific) one."""

        config_path = tmp_path / ".claude.json"
        config_path.write_text(
            json.dumps(
                {
                    "githubRepoPaths": {
                        "org/parent": "/Users/test/projects",
                        "org/nested": "/Users/test/projects/nested",
                    }
                }
            )
        )

        # cwd inside nested should match nested, not parent
        result = resolve_git_repo_from_claude_config(
            cwd="/Users/test/projects/nested/src", config_path=config_path
        )
        assert result == "github.com/org/nested"

        # cwd directly under projects should match parent
        result = resolve_git_repo_from_claude_config(
            cwd="/Users/test/projects/other", config_path=config_path
        )
        assert result == "github.com/org/parent"

    def test_no_match(self, tmp_path: Path) -> None:
        """Claude config with no matching paths should return None."""

        config_path = tmp_path / ".claude.json"
        config_path.write_text(
            json.dumps(
                {
                    "githubRepoPaths": {
                        "org/repo": "/Users/test/project",
                    }
                }
            )
        )

        result = resolve_git_repo_from_claude_config(
            cwd="/Users/other/unrelated", config_path=config_path
        )
        assert result is None

    def test_missing_config_file(self, tmp_path: Path) -> None:
        """Missing config file should return None."""

        nonexistent = tmp_path / "nonexistent" / ".claude.json"
        result = resolve_git_repo_from_claude_config(
            cwd="/Users/test/project", config_path=nonexistent
        )
        assert result is None

    def test_malformed_json(self, tmp_path: Path) -> None:
        """Malformed JSON should return None."""

        config_path = tmp_path / ".claude.json"
        config_path.write_text("{ invalid json }")

        result = resolve_git_repo_from_claude_config(
            cwd="/Users/test/project", config_path=config_path
        )
        assert result is None

    def test_missing_github_repo_paths_key(self, tmp_path: Path) -> None:
        """Config without githubRepoPaths key should return None."""

        config_path = tmp_path / ".claude.json"
        config_path.write_text(json.dumps({"otherKey": "value"}))

        result = resolve_git_repo_from_claude_config(
            cwd="/Users/test/project", config_path=config_path
        )
        assert result is None

    def test_empty_github_repo_paths(self, tmp_path: Path) -> None:
        """Empty githubRepoPaths dict should return None."""

        config_path = tmp_path / ".claude.json"
        config_path.write_text(json.dumps({"githubRepoPaths": {}}))

        result = resolve_git_repo_from_claude_config(
            cwd="/Users/test/project", config_path=config_path
        )
        assert result is None

    def test_nonexistent_cwd(self, tmp_path: Path) -> None:
        """Should handle nonexistent cwd gracefully (historic sessions)."""

        config_path = tmp_path / ".claude.json"
        config_path.write_text(
            json.dumps(
                {
                    "githubRepoPaths": {
                        "org/repo": "/Users/test/project",
                    }
                }
            )
        )

        # Nonexistent path that would have been under the project
        result = resolve_git_repo_from_claude_config(
            cwd="/Users/test/project/deleted/folder", config_path=config_path
        )
        assert result == "github.com/org/repo"

    def test_default_config_path(self, mock_home: Path) -> None:
        """Should use ~/.claude.json by default."""

        config_path = mock_home / ".claude.json"
        config_path.write_text(
            json.dumps(
                {
                    "githubRepoPaths": {
                        "org/repo": "/Users/test/project",
                    }
                }
            )
        )

        result = resolve_git_repo_from_claude_config(cwd="/Users/test/project")
        assert result == "github.com/org/repo"


class TestFindGitRoot:
    """Tests for find_git_root function."""

    def test_finds_git_root_in_current_dir(self, tmp_path: Path) -> None:
        """Should find .git directory in current directory."""

        git_dir = tmp_path / ".git"
        git_dir.mkdir()

        result = find_git_root(tmp_path)
        assert result == tmp_path

    def test_finds_git_root_in_parent(self, tmp_path: Path) -> None:
        """Should find .git directory in parent directories."""

        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        subdir = tmp_path / "src" / "deep" / "nested"
        subdir.mkdir(parents=True)

        result = find_git_root(subdir)
        assert result == tmp_path

    def test_no_git_root_found(self, tmp_path: Path) -> None:
        """Should return None if no .git directory found."""

        subdir = tmp_path / "project"
        subdir.mkdir()

        result = find_git_root(subdir)
        assert result is None

    def test_nonexistent_path(self) -> None:
        """Should handle nonexistent paths gracefully."""

        result = find_git_root(Path("/nonexistent/path/that/does/not/exist"))
        assert result is None


class TestGetGitRemoteUrl:
    """Tests for get_git_remote_url function."""

    def test_https_remote(self, tmp_path: Path) -> None:
        """Should extract remote URL from .git/config with HTTPS format."""

        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        config = git_dir / "config"
        config.write_text(
            """[core]
    repositoryformatversion = 0
[remote "origin"]
    url = https://github.com/wandb/weave.git
    fetch = +refs/heads/*:refs/remotes/origin/*
[branch "main"]
    remote = origin
    merge = refs/heads/main
"""
        )

        result = get_git_remote_url(tmp_path)
        assert result == "https://github.com/wandb/weave.git"

    def test_ssh_remote(self, tmp_path: Path) -> None:
        """Should extract remote URL from .git/config with SSH format."""

        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        config = git_dir / "config"
        config.write_text(
            """[core]
    repositoryformatversion = 0
[remote "origin"]
    url = git@github.com:wandb/weave.git
    fetch = +refs/heads/*:refs/remotes/origin/*
"""
        )

        result = get_git_remote_url(tmp_path)
        assert result == "git@github.com:wandb/weave.git"

    def test_no_remote_configured(self, tmp_path: Path) -> None:
        """Should return None if no remote is configured."""

        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        config = git_dir / "config"
        config.write_text(
            """[core]
    repositoryformatversion = 0
[branch "main"]
    merge = refs/heads/main
"""
        )

        result = get_git_remote_url(tmp_path)
        assert result is None

    def test_missing_git_config(self, tmp_path: Path) -> None:
        """Should return None if .git/config doesn't exist."""

        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        # No config file created

        result = get_git_remote_url(tmp_path)
        assert result is None

    def test_multiple_remotes_picks_origin(self, tmp_path: Path) -> None:
        """Should prefer origin remote when multiple remotes exist."""

        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        config = git_dir / "config"
        config.write_text(
            """[core]
    repositoryformatversion = 0
[remote "upstream"]
    url = https://github.com/original/repo.git
[remote "origin"]
    url = https://github.com/fork/repo.git
"""
        )

        result = get_git_remote_url(tmp_path)
        assert result == "https://github.com/fork/repo.git"

    def test_git_config_with_duplicate_options(self, tmp_path: Path) -> None:
        """Should handle git configs with duplicate options (multi-valued keys).

        Git allows duplicate option names in config files (e.g., multiple
        vscode-merge-base entries). Python's configparser rejects these by
        default, so we use strict=False to handle them.
        """

        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        config = git_dir / "config"
        # This config has duplicate 'vscode-merge-base' options which would
        # cause configparser.DuplicateOptionError with strict=True
        config.write_text(
            """[core]
    repositoryformatversion = 0
[remote "origin"]
    url = git@github.com:wandb/catnip.git
    fetch = +refs/heads/*:refs/remotes/origin/*
[branch "main"]
    remote = origin
    vscode-merge-base = origin/main
    merge = refs/heads/main
[branch "feature"]
    remote = origin
    vscode-merge-base = origin/main
    vscode-merge-base = origin/main
"""
        )

        result = get_git_remote_url(tmp_path)
        assert result == "git@github.com:wandb/catnip.git"


class TestNormalizeGitUrl:
    """Tests for _normalize_git_url function."""

    def test_https_url(self) -> None:
        """Should normalize HTTPS URL to github.com/org/repo format."""

        result = _normalize_git_url("https://github.com/wandb/weave.git")
        assert result == "github.com/wandb/weave"

    def test_https_url_without_git_suffix(self) -> None:
        """Should handle HTTPS URLs without .git suffix."""

        result = _normalize_git_url("https://github.com/wandb/weave")
        assert result == "github.com/wandb/weave"

    def test_ssh_url(self) -> None:
        """Should normalize SSH URL to github.com/org/repo format."""

        result = _normalize_git_url("git@github.com:wandb/weave.git")
        assert result == "github.com/wandb/weave"

    def test_ssh_url_without_git_suffix(self) -> None:
        """Should handle SSH URLs without .git suffix."""

        result = _normalize_git_url("git@github.com:wandb/weave")
        assert result == "github.com/wandb/weave"

    def test_gitlab_url(self) -> None:
        """Should normalize GitLab URLs similarly."""

        result = _normalize_git_url("git@gitlab.com:org/repo.git")
        assert result == "gitlab.com/org/repo"

    def test_unknown_format(self) -> None:
        """Should return None for unrecognized URL formats."""

        result = _normalize_git_url("some-random-string")
        assert result is None

    def test_empty_string(self) -> None:
        """Should return None for empty string."""

        result = _normalize_git_url("")
        assert result is None


class TestGetGitCommitSha:
    """Tests for get_git_commit_sha function."""

    def test_commit_from_ref(self, tmp_path: Path) -> None:
        """Should read commit SHA from .git/refs/heads/main."""

        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        refs_heads = git_dir / "refs" / "heads"
        refs_heads.mkdir(parents=True)
        (refs_heads / "main").write_text("abc123def456789012345678901234567890abcd\n")
        (git_dir / "HEAD").write_text("ref: refs/heads/main\n")

        result = get_git_commit_sha(tmp_path)
        assert result == "abc123def456789012345678901234567890abcd"

    def test_detached_head(self, tmp_path: Path) -> None:
        """Should read commit SHA directly from HEAD when detached."""

        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        (git_dir / "HEAD").write_text("def456789012345678901234567890abcdef1234\n")

        result = get_git_commit_sha(tmp_path)
        assert result == "def456789012345678901234567890abcdef1234"

    def test_packed_refs(self, tmp_path: Path) -> None:
        """Should read commit SHA from packed-refs when ref file doesn't exist."""

        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        (git_dir / "HEAD").write_text("ref: refs/heads/feature\n")
        # No refs/heads/feature file, but packed-refs exists
        (git_dir / "packed-refs").write_text(
            "# pack-refs with: peeled fully-peeled sorted\n"
            "abc123def456789012345678901234567890abcd refs/heads/feature\n"
            "other123456789012345678901234567890other refs/heads/main\n"
        )

        result = get_git_commit_sha(tmp_path)
        assert result == "abc123def456789012345678901234567890abcd"

    def test_missing_head_file(self, tmp_path: Path) -> None:
        """Should return None if HEAD file doesn't exist."""

        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        # No HEAD file

        result = get_git_commit_sha(tmp_path)
        assert result is None

    def test_missing_ref_and_packed_refs(self, tmp_path: Path) -> None:
        """Should return None if ref is not found anywhere."""

        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        (git_dir / "HEAD").write_text("ref: refs/heads/nonexistent\n")
        # No refs file and no packed-refs

        result = get_git_commit_sha(tmp_path)
        assert result is None


class TestResolveGitRepo:
    """Tests for resolve_git_repo function (combined strategy)."""

    def test_claude_config_priority(self, tmp_path: Path, mock_home: Path) -> None:
        """Claude config should take priority over filesystem lookup."""

        # Set up Claude config
        config_path = mock_home / ".claude.json"
        config_path.write_text(
            json.dumps(
                {
                    "githubRepoPaths": {
                        "claude/config-repo": str(tmp_path / "project"),
                    }
                }
            )
        )

        # Also set up a git repo with different remote
        project = tmp_path / "project"
        project.mkdir()
        git_dir = project / ".git"
        git_dir.mkdir()
        (git_dir / "config").write_text(
            """[remote "origin"]
    url = https://github.com/filesystem/repo.git
"""
        )

        # Claude config should win
        result = resolve_git_repo(str(project))
        assert result == "github.com/claude/config-repo"

    def test_filesystem_fallback(self, tmp_path: Path, mock_home: Path) -> None:
        """Should fall back to filesystem lookup if Claude config doesn't match."""

        # Set up Claude config with different path
        config_path = mock_home / ".claude.json"
        config_path.write_text(
            json.dumps(
                {
                    "githubRepoPaths": {
                        "other/repo": "/different/path",
                    }
                }
            )
        )

        # Set up a git repo
        project = tmp_path / "project"
        project.mkdir()
        git_dir = project / ".git"
        git_dir.mkdir()
        (git_dir / "config").write_text(
            """[remote "origin"]
    url = git@github.com:filesystem/repo.git
"""
        )

        # Filesystem should be used
        result = resolve_git_repo(str(project))
        assert result == "github.com/filesystem/repo"

    def test_no_repo_found(self, tmp_path: Path, mock_home: Path) -> None:
        """Should return None if no repo is found via either method."""

        # Empty Claude config
        config_path = mock_home / ".claude.json"
        config_path.write_text(json.dumps({}))

        # No git directory
        project = tmp_path / "project"
        project.mkdir()

        result = resolve_git_repo(str(project))
        assert result is None

    def test_nonexistent_path(self, mock_home: Path) -> None:
        """Should handle nonexistent paths gracefully."""

        # Empty Claude config
        config_path = mock_home / ".claude.json"
        config_path.write_text(json.dumps({}))

        result = resolve_git_repo("/nonexistent/historic/session/path")
        assert result is None

    def test_custom_config_path(self, tmp_path: Path) -> None:
        """Should accept custom Claude config path."""

        config_path = tmp_path / "custom-config.json"
        config_path.write_text(
            json.dumps(
                {
                    "githubRepoPaths": {
                        "custom/repo": str(tmp_path / "project"),
                    }
                }
            )
        )

        project = tmp_path / "project"
        project.mkdir()

        result = resolve_git_repo(str(project), claude_config_path=config_path)
        assert result == "github.com/custom/repo"


class TestGitFilesystemLookupHttps:
    """Tests for git filesystem lookup with HTTPS remotes."""

    def test_https_remote_with_full_setup(self, tmp_path: Path, mock_home: Path) -> None:
        """Full filesystem lookup should work with HTTPS remote."""

        # Empty Claude config
        config_path = mock_home / ".claude.json"
        config_path.write_text(json.dumps({}))

        # Set up git repo with HTTPS remote
        project = tmp_path / "project"
        project.mkdir()
        git_dir = project / ".git"
        git_dir.mkdir()
        (git_dir / "config").write_text(
            """[core]
    repositoryformatversion = 0
[remote "origin"]
    url = https://github.com/wandb/agentstream.git
    fetch = +refs/heads/*:refs/remotes/origin/*
"""
        )

        # Should resolve via filesystem
        result = resolve_git_repo(str(project))
        assert result == "github.com/wandb/agentstream"


class TestGitFilesystemLookupSsh:
    """Tests for git filesystem lookup with SSH remotes."""

    def test_ssh_remote_with_full_setup(self, tmp_path: Path, mock_home: Path) -> None:
        """Full filesystem lookup should work with SSH remote."""

        # Empty Claude config
        config_path = mock_home / ".claude.json"
        config_path.write_text(json.dumps({}))

        # Set up git repo with SSH remote
        project = tmp_path / "project"
        project.mkdir()
        git_dir = project / ".git"
        git_dir.mkdir()
        (git_dir / "config").write_text(
            """[core]
    repositoryformatversion = 0
[remote "origin"]
    url = git@github.com:anthropics/claude-code.git
    fetch = +refs/heads/*:refs/remotes/origin/*
"""
        )

        # Should resolve via filesystem
        result = resolve_git_repo(str(project))
        assert result == "github.com/anthropics/claude-code"
