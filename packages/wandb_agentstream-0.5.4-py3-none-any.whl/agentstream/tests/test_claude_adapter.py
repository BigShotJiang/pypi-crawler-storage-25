"""Tests for Claude adapter, particularly timestamp handling."""

import json
import tempfile
from pathlib import Path

import pytest

from agentstream.adapters.base import Session
from agentstream.adapters.claude import ClaudeAdapter
from agentstream.adapters.timestamps import parse_timestamp as _parse_timestamp
from agentstream.events import EventType


class TestParseTimestamp:
    """Tests for _parse_timestamp function."""

    def test_valid_iso_timestamp_with_z(self):
        """Should parse ISO 8601 timestamps with Z suffix."""
        ts = _parse_timestamp("2025-01-07T12:30:45.123Z")
        assert ts is not None
        assert ts > 0

    def test_valid_iso_with_utc_offset(self):
        """Should parse timestamps with +00:00 offset."""
        ts = _parse_timestamp("2025-01-07T12:30:45+00:00")
        assert ts is not None
        assert ts > 0

    def test_valid_iso_with_non_utc_offset(self):
        """Should correctly parse timestamps with non-UTC offsets."""
        # 12:30 at +05:00 = 07:30 UTC
        ts_plus5 = _parse_timestamp("2025-01-07T12:30:45+05:00")
        # 12:30 at UTC
        ts_utc = _parse_timestamp("2025-01-07T12:30:45Z")
        assert ts_plus5 is not None
        assert ts_utc is not None
        # The +05:00 timestamp should be 5 hours earlier in UTC
        diff_hours = (ts_utc - ts_plus5) / (1000 * 60 * 60)
        assert diff_hours == 5.0

    def test_naive_timestamp_treated_as_utc(self):
        """Naive timestamps (no timezone) should be treated as UTC."""
        ts_naive = _parse_timestamp("2025-01-07T12:30:45")
        ts_utc = _parse_timestamp("2025-01-07T12:30:45Z")
        assert ts_naive is not None
        assert ts_utc is not None
        # Should be equal since naive is assumed to be UTC
        assert ts_naive == ts_utc

    def test_z_suffix_equals_utc_offset(self):
        """Z suffix should be equivalent to +00:00."""
        ts_z = _parse_timestamp("2025-01-07T12:30:45Z")
        ts_offset = _parse_timestamp("2025-01-07T12:30:45+00:00")
        assert ts_z == ts_offset

    def test_empty_string_returns_none(self):
        """Should return None for empty string."""
        assert _parse_timestamp("") is None

    def test_invalid_format_returns_none(self):
        """Should return None for invalid timestamp format."""
        assert _parse_timestamp("not-a-timestamp") is None
        assert _parse_timestamp("2025-13-45") is None

    def test_none_like_values(self):
        """Should handle None-like string values."""
        assert _parse_timestamp("null") is None
        assert _parse_timestamp("undefined") is None


class TestClaudeAdapterTimestampFallback:
    """Tests for timestamp fallback behavior in read_events."""

    @pytest.fixture
    def adapter(self):
        return ClaudeAdapter()

    @pytest.fixture
    def temp_session_file(self):
        """Create a temporary session file for testing."""

        def _create(entries: list[dict]) -> tuple[Path, Session]:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False) as f:
                for entry in entries:
                    f.write(json.dumps(entry) + "\n")
                path = Path(f.name)

            session = Session(
                id="test-session",
                path=path,
                format="claude",
                modified_at=1704672000.0,  # 2024-01-08 00:00:00 UTC
            )
            return path, session

        return _create

    def test_all_entries_have_timestamps(self, adapter, temp_session_file):
        """When all entries have timestamps, should use them directly."""
        entries = [
            {
                "type": "user",
                "message": {"content": "Hello"},
                "uuid": "msg-1",
                "timestamp": "2025-01-07T10:00:00Z",
            },
            {
                "type": "assistant",
                "message": {"content": [{"type": "text", "text": "Hi there!"}]},
                "uuid": "msg-2",
                "timestamp": "2025-01-07T10:00:05Z",
            },
        ]
        path, session = temp_session_file(entries)
        try:
            events = list(adapter.read_events(session))
            # All events should have non-zero timestamps
            for event in events:
                assert event.timestamp_ms > 0
            # Check specific timestamps are preserved
            ts_10_00_00 = 1736244000000  # 2025-01-07T10:00:00Z
            # RunStarted should use first timestamp
            assert events[0].timestamp_ms == ts_10_00_00
            assert events[0].type == EventType.RUN_STARTED
        finally:
            path.unlink()

    def test_first_entry_missing_timestamp(self, adapter, temp_session_file):
        """When first entry has no timestamp, should use next valid timestamp."""
        entries = [
            {
                "type": "user",
                "message": {"content": "Hello"},
                "uuid": "msg-1",
                "timestamp": "",  # Missing timestamp
            },
            {
                "type": "assistant",
                "message": {"content": [{"type": "text", "text": "Hi there!"}]},
                "uuid": "msg-2",
                "timestamp": "2025-01-07T10:00:05Z",
            },
        ]
        path, session = temp_session_file(entries)
        try:
            events = list(adapter.read_events(session))
            # First entry should use second entry's timestamp as fallback
            ts_10_00_05 = 1736244005000
            # RunStarted should have the fallback timestamp
            assert events[0].timestamp_ms == ts_10_00_05
            assert events[0].type == EventType.RUN_STARTED
        finally:
            path.unlink()

    def test_middle_entry_missing_timestamp(self, adapter, temp_session_file):
        """When middle entry has no timestamp, should use last valid timestamp."""
        entries = [
            {
                "type": "user",
                "message": {"content": "Hello"},
                "uuid": "msg-1",
                "timestamp": "2025-01-07T10:00:00Z",
            },
            {
                "type": "assistant",
                "message": {"content": [{"type": "text", "text": "Hi!"}]},
                "uuid": "msg-2",
                "timestamp": "",  # Missing - should use previous
            },
            {
                "type": "user",
                "message": {"content": "Bye"},
                "uuid": "msg-3",
                "timestamp": "2025-01-07T10:00:10Z",
            },
        ]
        path, session = temp_session_file(entries)
        try:
            events = list(adapter.read_events(session))
            ts_10_00_00 = 1736244000000

            # Find the assistant message events (msg-2)
            assistant_events = [e for e in events if getattr(e, "message_id", None) == "msg-2"]
            # All should use the fallback from first entry
            for e in assistant_events:
                assert e.timestamp_ms == ts_10_00_00
        finally:
            path.unlink()

    def test_all_entries_missing_timestamps(self, adapter, temp_session_file):
        """When no entries have timestamps, should fall back to file mtime."""
        entries = [
            {
                "type": "user",
                "message": {"content": "Hello"},
                "uuid": "msg-1",
                "timestamp": "",
            },
            {
                "type": "assistant",
                "message": {"content": [{"type": "text", "text": "Hi!"}]},
                "uuid": "msg-2",
                "timestamp": "",
            },
        ]
        path, session = temp_session_file(entries)
        try:
            events = list(adapter.read_events(session))
            # All should use file mtime as fallback
            file_mtime_ms = int(session.modified_at * 1000)
            for event in events:
                assert event.timestamp_ms == file_mtime_ms
        finally:
            path.unlink()

    def test_unknown_entry_type_uses_timestamp(self, adapter, temp_session_file):
        """Unknown entry types should still get their timestamps parsed."""
        entries = [
            {
                "type": "user",
                "message": {"content": "Hello"},
                "uuid": "msg-1",
                "timestamp": "2025-01-07T10:00:00Z",
            },
            {
                "type": "some_new_type",  # Unknown type - will fail Pydantic
                "message": {"content": "whatever"},
                "uuid": "msg-2",
                "timestamp": "2025-01-07T10:00:05Z",
            },
        ]
        path, session = temp_session_file(entries)
        try:
            events = list(adapter.read_events(session))
            ts_10_00_05 = 1736244005000
            # Find the source_entry for the unknown type
            source_entries = [
                e
                for e in events
                if e.type == EventType.CUSTOM and getattr(e, "name", None) == "source_entry"
            ]
            # The second source_entry should have its own timestamp
            assert len(source_entries) == 2
            assert source_entries[1].timestamp_ms == ts_10_00_05
        finally:
            path.unlink()

    def test_run_finished_uses_last_valid_timestamp(self, adapter, temp_session_file):
        """RunFinished should use the last valid timestamp seen."""
        entries = [
            {
                "type": "user",
                "message": {"content": "Hello"},
                "uuid": "msg-1",
                "timestamp": "2025-01-07T10:00:00Z",
            },
            {
                "type": "assistant",
                "message": {"content": [{"type": "text", "text": "Hi!"}]},
                "uuid": "msg-2",
                "timestamp": "2025-01-07T10:00:10Z",
            },
        ]
        path, session = temp_session_file(entries)
        try:
            events = list(adapter.read_events(session))
            ts_10_00_10 = 1736244010000
            # Last event should be RunFinished
            assert events[-1].type == EventType.RUN_FINISHED
            assert events[-1].timestamp_ms == ts_10_00_10
        finally:
            path.unlink()
