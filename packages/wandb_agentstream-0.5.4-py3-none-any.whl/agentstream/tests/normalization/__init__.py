"""Tests for multi-agent normalization."""
