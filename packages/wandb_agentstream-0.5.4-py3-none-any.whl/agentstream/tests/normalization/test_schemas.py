from dataclasses import asdict
from datetime import datetime

from agentstream.normalization.schemas import (
    CompactionEvent,
    ErrorEvent,
    SessionMetadata,
    TokenUsage,
    UnifiedTodo,
)


def test_unified_todo_creation():
    todo = UnifiedTodo(
        content="Fix authentication bug",
        status="in_progress",
        id="todo-123",
        timestamp=datetime.now(),
        source_tool="TodoWrite",
        agent_type="claude",
    )
    assert todo.content == "Fix authentication bug"
    assert todo.status == "in_progress"


def test_unified_todo_without_id():
    """Codex/Gemini don't provide IDs"""
    todo = UnifiedTodo(
        content="Update dependencies",
        status="pending",
        id=None,
        timestamp=datetime.now(),
        source_tool="update_plan",
        agent_type="codex",
    )
    assert todo.id is None


def test_session_metadata_creation():
    """Test SessionMetadata schema instantiation and serialization"""
    metadata = SessionMetadata(
        cwd="/Users/test/project",
        agent_type="claude",
        agent_version="1.5.0",
        git_branch="feature/test",
        git_commit="abc123",
        git_repo="https://github.com/test/repo",
        primary_model="claude-sonnet-4.5",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )
    assert metadata.cwd == "/Users/test/project"
    assert metadata.agent_type == "claude"
    assert metadata.agent_version == "1.5.0"
    assert metadata.git_branch == "feature/test"
    assert metadata.git_commit == "abc123"
    assert metadata.git_repo == "https://github.com/test/repo"
    assert metadata.primary_model == "claude-sonnet-4.5"

    # Test serialization to dict
    data = asdict(metadata)
    assert data["cwd"] == "/Users/test/project"
    assert data["agent_type"] == "claude"
    assert data["primary_model"] == "claude-sonnet-4.5"


def test_session_metadata_with_nulls():
    """Test SessionMetadata with optional fields as None"""
    metadata = SessionMetadata(
        cwd=None,
        agent_type="codex",
        agent_version=None,
        git_branch=None,
        git_commit=None,
        git_repo=None,
        primary_model=None,
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )
    assert metadata.cwd is None
    assert metadata.agent_version is None
    assert metadata.git_branch is None

    # Ensure it can be serialized
    data = asdict(metadata)
    assert data["cwd"] is None
    assert data["agent_version"] is None


def test_token_usage_creation():
    """Test TokenUsage schema instantiation and serialization"""
    usage = TokenUsage(
        input_tokens=100,
        output_tokens=50,
        cache_read_tokens=25,
        cache_creation_tokens=10,
        reasoning_tokens=5,
        model="claude-sonnet-4.5",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
        is_cumulative=False,
    )
    assert usage.input_tokens == 100
    assert usage.output_tokens == 50
    assert usage.cache_read_tokens == 25
    assert usage.cache_creation_tokens == 10
    assert usage.reasoning_tokens == 5
    assert usage.model == "claude-sonnet-4.5"
    assert usage.is_cumulative is False

    # Test serialization
    data = asdict(usage)
    assert data["input_tokens"] == 100
    assert data["output_tokens"] == 50
    assert data["is_cumulative"] is False


def test_token_usage_cumulative():
    """Test TokenUsage with cumulative flag"""
    usage = TokenUsage(
        input_tokens=1000,
        output_tokens=500,
        model="gpt-4",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
        is_cumulative=True,
    )
    assert usage.is_cumulative is True
    assert usage.cache_read_tokens == 0  # Default value


def test_token_usage_defaults():
    """Test TokenUsage default values"""
    usage = TokenUsage(
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )
    assert usage.input_tokens == 0
    assert usage.output_tokens == 0
    assert usage.cache_read_tokens == 0
    assert usage.cache_creation_tokens == 0
    assert usage.reasoning_tokens == 0
    assert usage.model is None
    assert usage.is_cumulative is False


def test_error_event_tool_call_error():
    """Test ErrorEvent for tool call errors"""
    error = ErrorEvent(
        error_type="tool_call_error",
        message="Invalid file path",
        tool_name="Edit",
        tool_call_id="tool-123",
        details="File does not exist: /path/to/file.py",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )
    assert error.error_type == "tool_call_error"
    assert error.message == "Invalid file path"
    assert error.tool_name == "Edit"
    assert error.tool_call_id == "tool-123"

    # Test serialization
    data = asdict(error)
    assert data["error_type"] == "tool_call_error"
    assert data["tool_name"] == "Edit"


def test_error_event_interruption():
    """Test ErrorEvent for interruptions"""
    error = ErrorEvent(
        error_type="interruption",
        message="User interrupted execution",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )
    assert error.error_type == "interruption"
    assert error.tool_name is None
    assert error.tool_call_id is None
    assert error.details is None


def test_error_event_rate_limit():
    """Test ErrorEvent for rate limits"""
    error = ErrorEvent(
        error_type="rate_limit",
        message="Rate limit exceeded",
        details="Retry after 60 seconds",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )
    assert error.error_type == "rate_limit"
    data = asdict(error)
    assert data["details"] == "Retry after 60 seconds"


def test_compaction_event_auto_summarization():
    """Test CompactionEvent for auto summarization"""
    compaction = CompactionEvent(
        compaction_type="auto_summarization",
        messages_before=100,
        messages_after=20,
        tokens_saved=5000,
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )
    assert compaction.compaction_type == "auto_summarization"
    assert compaction.messages_before == 100
    assert compaction.messages_after == 20
    assert compaction.tokens_saved == 5000

    # Test serialization
    data = asdict(compaction)
    assert data["compaction_type"] == "auto_summarization"
    assert data["messages_before"] == 100


def test_compaction_event_with_message_id():
    """Test CompactionEvent with message_id for timeline linking"""
    compaction = CompactionEvent(
        compaction_type="auto_summarization",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
        message_id="ae87145e-a31d-4b1b-874c-52e0139aea6c",
    )
    assert compaction.message_id == "ae87145e-a31d-4b1b-874c-52e0139aea6c"

    # Test serialization includes message_id
    data = asdict(compaction)
    assert data["message_id"] == "ae87145e-a31d-4b1b-874c-52e0139aea6c"


def test_compaction_event_context_limit():
    """Test CompactionEvent for context limit compaction"""
    compaction = CompactionEvent(
        compaction_type="context_limit",
        messages_before=150,
        messages_after=50,
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )
    assert compaction.compaction_type == "context_limit"
    assert compaction.tokens_saved is None


def test_compaction_event_manual():
    """Test CompactionEvent for manual compaction"""
    compaction = CompactionEvent(
        compaction_type="manual",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )
    assert compaction.compaction_type == "manual"
    assert compaction.messages_before is None
    assert compaction.messages_after is None
    assert compaction.tokens_saved is None
