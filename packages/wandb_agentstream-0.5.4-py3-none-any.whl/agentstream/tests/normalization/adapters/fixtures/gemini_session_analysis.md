# Automated Session Summarization

This feature provides AI-Generated Summaries for coding sessions.

## Overview

The automated session summarization feature analyzes user prompts within a coding session and extracts meaningful insights about the work performed. This enables managers and team members to quickly understand session activity.

## Key Features

### AI-Generated Summaries

- **Topic Extraction**: Identifies the main topics discussed in each session
- **Sentiment Analysis**: Detects user sentiment (positive, neutral, frustrated)
- **Task Classification**: Categorizes work as bug fixes, features, refactoring
- **Confidence Scores**: Provides reliability metrics for each analysis

### Session Insights

- **Quick Overview**: See what happened in a session at a glance
- **Frustration Detection**: Identify sessions where developers had difficulties
- **Productivity Patterns**: Track task types across sessions and users

## API Endpoints

### Trigger Analysis

```http
POST /v1/sessions/{session_id}/analyze-summary
```

Triggers an asynchronous analysis of the session's user prompts.

### Get Analysis Results

```http
GET /v1/sessions/{session_id}/summary-analysis
```

Returns the analysis results once processing is complete.

#### Response Format

```json
{
  "analysis_id": "uuid",
  "session_id": "uuid",
  "status": "completed",
  "topics": ["API Integration", "Bug Fix"],
  "sentiments": ["neutral", "positive"],
  "task_types": ["feature", "bug_fix"],
  "overall_sentiment": "positive",
  "frustration_rate": 0.1
}
```

## Implementation Details

### Analysis Pipeline

1. Extract all user prompts from the session
2. Send prompts to Claude for analysis
3. Parse structured response
4. Store results in ClickHouse
5. Update session summary fields

### Storage Schema

The analysis results are stored in `session_summary_analyses`:

```sql
CREATE TABLE session_summary_analyses (
    analysis_id UUID,
    session_id UUID,
    user_id String,
    analyzed_at DateTime64(3),
    topics String,
    sentiments String,
    task_types String,
    overall_sentiment String,
    status String
)
```

## Usage Guidelines

### When to Use

- Review team productivity patterns
- Identify training opportunities
- Track feature development progress
- Detect developer friction points

### Best Practices

1. Review frustrated sessions promptly
2. Use task type breakdown for sprint planning
3. Compare sentiment trends over time
4. Export data for custom reporting

## Performance Considerations

- Analysis runs asynchronously to avoid blocking
- Results are indexed by session_id for fast lookups
- Batch processing available for historical analysis

## Security

- User prompts are processed securely
- Analysis results respect RBAC permissions
- Sensitive code is not included in analysis

## Future Enhancements

- Real-time sentiment tracking
- Automatic alert on frustration detection
- Integration with ticketing systems
- Custom analysis prompts

## Troubleshooting

### Common Issues

1. **Analysis stuck in pending**: Check worker queue status
2. **Empty results**: Verify session has user prompts
3. **Low confidence scores**: May indicate ambiguous prompts

### Debugging

Enable debug logging:

```bash
export LOG_LEVEL=debug
```

Check analysis status via API:

```http
GET /v1/sessions/{session_id}/summary-analysis
```
