# Repository Filtering

Repository filtering enables users to scope analytics and session views to specific GitHub repositories.

## Features

- **Repository dropdown**: Shows all repositories accessible to the user based on RBAC
- **Session counts**: Display number of sessions per repository
- **URL persistence**: Repository filter persists in URL parameters
- **RBAC enforcement**: Users only see repositories they have access to
- **Combined filters**: Works with user, team, and time range filters

## API

### Get Repositories

```http
GET /v1/repositories?user_id={userId}&team={team}
```

Returns list of repositories with session counts and last activity timestamp.

### Filter by Repository

All analytics endpoints accept optional `repository` query parameter:

```http
GET /v1/stats/activity-calendar?repository=github.com/org/repo&days=30
GET /v1/sessions?repository=github.com/org/repo&limit=50
```

## Implementation

- **Database**: Added bloom filter index on `sessions.git_repo` column
- **URL normalization**: Daemon normalizes all git URLs to HTTPS format
- **Display format**: UI shows `org/repo` slug, stores full `github.com/org/repo`

## Performance

The bloom filter index on `git_repo` provides O(1) lookup performance for repository filtering, suitable for repositories with millions of sessions.
