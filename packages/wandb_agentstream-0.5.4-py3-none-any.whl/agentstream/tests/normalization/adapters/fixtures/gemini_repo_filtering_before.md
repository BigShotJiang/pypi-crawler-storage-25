# Repository Filtering

Repository filtering is a powerful feature that enables users to scope analytics and session views to specific GitHub repositories.

## Overview

This feature allows development teams to focus their analytics on specific projects, making it easier to track productivity, identify patterns, and measure impact within individual repositories.

## Key Features

- **Repository dropdown**: Shows all repositories accessible to the user based on RBAC
- **Session counts**: Display number of sessions per repository
- **URL persistence**: Repository filter persists in URL parameters
- **RBAC enforcement**: Users only see repositories they have access to
- **Combined filters**: Works with user, team, and time range filters
- **Quick selection**: Click to filter, double-click to focus
- **Search functionality**: Type to filter long repository lists

## API

### Get Repositories

```http
GET /v1/repositories?user_id={userId}&team={team}
```

Returns list of repositories with session counts and last activity timestamp.

#### Response Format

```json
{
  "repositories": [
    {
      "name": "github.com/org/repo",
      "session_count": 42,
      "last_activity": "2025-01-15T10:30:00Z"
    }
  ]
}
```

### Filter by Repository

All analytics endpoints accept optional `repository` query parameter:

```http
GET /v1/stats/activity-calendar?repository=github.com/org/repo&days=30
GET /v1/sessions?repository=github.com/org/repo&limit=50
```

## Implementation

- **Database**: Added bloom filter index on `sessions.git_repo` column
- **URL normalization**: Daemon normalizes all git URLs to HTTPS format
- **Display format**: UI shows `org/repo` slug, stores full `github.com/org/repo`
- **Caching**: Repository list cached for 5 minutes to reduce database load

## Performance

The bloom filter index on `git_repo` provides O(1) lookup performance for repository filtering, suitable for repositories with millions of sessions.

## Best Practices

1. Use repository filtering to narrow down analytics to specific projects
2. Combine with time range filters for sprint-level analysis
3. Export filtered data for custom reporting
