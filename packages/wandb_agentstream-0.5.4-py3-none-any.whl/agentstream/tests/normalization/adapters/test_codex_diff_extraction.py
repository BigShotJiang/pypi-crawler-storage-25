"""Test Codex diff extraction using real session data."""

import json
from pathlib import Path

import pytest

from agentstream.normalization.adapters.codex_v1 import CodexV1Normalizer


@pytest.fixture
def codex_events():
    """Load real Codex apply_patch events from fixtures."""
    fixture_path = (
        Path(__file__).parent.parent.parent / "fixtures" / "codex_apply_patch_events.json"
    )
    with open(fixture_path) as f:
        data = json.load(f)
    return data["events"]


def test_extract_diff_from_apply_patch_repository_filtering_first_edit(codex_events):
    """Test extracting diff from the first major edit to repository-filtering.md."""
    normalizer = CodexV1Normalizer()

    # First event is the big rewrite of repository-filtering.md
    event = codex_events[0]
    assert event["tool_name"] == "apply_patch"
    assert "repository-filtering.md" in event["input"]

    diff = normalizer.extract_diff(event, session=None)

    assert diff is not None
    assert diff.format_source == "codex_apply_patch"
    assert diff.confidence == "high"
    assert len(diff.hunks) > 0

    # Check that we extracted hunks
    assert diff.hunks[0].lines is not None
    assert len(diff.hunks[0].lines) > 0

    # Should have additions (all the new content)
    assert len(diff.lines_added) > 0

    # Verify some of the specific changes in the patch
    all_lines = "".join(diff.hunks[0].lines)
    assert "Repository filtering lets users" in all_lines  # Changed from "enables"
    assert "## Capabilities" in all_lines  # Changed from "## Features"


def test_extract_diff_from_apply_patch_https_lowercase(codex_events):
    """Test extracting diff from the HTTPS -> https case change."""
    normalizer = CodexV1Normalizer()

    # Second event changes HTTPS to https
    event = codex_events[1]
    assert event["tool_name"] == "apply_patch"
    assert "repository-filtering.md" in event["input"]

    diff = normalizer.extract_diff(event, session=None)

    assert diff is not None
    assert diff.format_source == "codex_apply_patch"
    assert len(diff.hunks) == 2  # Two separate hunks for two replacements

    # Check the content
    all_lines = "\n".join(line for hunk in diff.hunks for line in hunk.lines)
    assert "https format" in all_lines
    assert "HTTPS" in all_lines  # Old version


def test_extract_diff_from_apply_patch_constellations_at_a_glance(codex_events):
    """Test extracting diff that adds 'At a Glance' section."""
    normalizer = CodexV1Normalizer()

    # Fifth event (index 4) adds the "At a Glance" section
    event = codex_events[4]
    assert event["tool_name"] == "apply_patch"
    assert "repository-constellations.md" in event["input"]

    diff = normalizer.extract_diff(event, session=None)

    assert diff is not None
    assert diff.format_source == "codex_apply_patch"

    # Should have additions for the new "At a Glance" section
    assert len(diff.lines_added) > 0

    # Check for specific content
    all_lines = "\n".join(line for hunk in diff.hunks for line in hunk.lines)
    assert "## At a Glance" in all_lines
    assert "[github.com/org/ops]" in all_lines  # Part of the ASCII graph
    assert "Nodes are repositories" in all_lines


def test_extract_diff_handles_file_creation_commands(codex_events):
    """Test that extract_diff returns diffs for file creation exec_command events."""
    normalizer = CodexV1Normalizer()

    # Third and fourth events are exec_command (cat > file)
    event = codex_events[2]
    assert event["tool_name"] == "exec_command"

    diff = normalizer.extract_diff(event, session=None)
    # File creation commands should now return diffs
    assert diff is not None
    assert diff.format_source == "shell_inferred"
    assert diff.confidence == "high"


def test_extract_diff_returns_none_for_non_file_operations():
    """Test that extract_diff returns None for non-file-operation exec_command events."""
    normalizer = CodexV1Normalizer()

    # Commands that don't involve file operations should return None
    test_events: list[dict] = [
        {"tool_name": "exec_command", "args": {"cmd": "ls -la"}, "timestamp_ms": 1000},
        {"tool_name": "exec_command", "args": {"cmd": "git status"}, "timestamp_ms": 1000},
        {"tool_name": "exec_command", "args": {"cmd": "rg --files"}, "timestamp_ms": 1000},
        {"tool_name": "exec_command", "args": {"cmd": "pwd"}, "timestamp_ms": 1000},
    ]

    for event in test_events:
        diff = normalizer.extract_diff(event, session=None)
        cmd: str = event["args"]["cmd"]
        assert diff is None, f"Expected None for command: {cmd}"


def test_extract_diff_handles_multiple_hunks(codex_events):
    """Test that we correctly handle patches with multiple hunks."""
    normalizer = CodexV1Normalizer()

    # Event with multiple @@...@@ sections
    event = codex_events[1]  # Has 2 hunks

    diff = normalizer.extract_diff(event, session=None)

    assert diff is not None
    assert len(diff.hunks) == 2

    # Each hunk should have content
    for hunk in diff.hunks:
        assert len(hunk.lines) > 0


def test_extract_diff_counts_additions_correctly(codex_events):
    """Test that line additions are counted correctly."""
    normalizer = CodexV1Normalizer()

    # Use an event with clear additions
    event = codex_events[4]  # Adds "At a Glance" section

    diff = normalizer.extract_diff(event, session=None)

    assert diff is not None

    # Count + lines in the hunks
    actual_additions = sum(1 for hunk in diff.hunks for line in hunk.lines if line.startswith("+"))

    # Should match the lines_added count
    assert len(diff.lines_added) == actual_additions


def test_real_session_demonstrates_proper_diff_extraction():
    """Integration test: Load fixture, extract diffs, verify they match git state.

    This test demonstrates that our extract_diff implementation can reconstruct
    the changes that Codex made to the repository.
    """
    normalizer = CodexV1Normalizer()

    # Load all events
    fixture_path = (
        Path(__file__).parent.parent.parent / "fixtures" / "codex_apply_patch_events.json"
    )
    with open(fixture_path) as f:
        data = json.load(f)

    apply_patch_events = [e for e in data["events"] if e["tool_name"] == "apply_patch"]

    # Extract diffs from all apply_patch events
    diffs = []
    for event in apply_patch_events:
        diff = normalizer.extract_diff(event, session=None)
        if diff:
            diffs.append({"event_id": event["event_id"], "diff": diff})

    # We should have extracted diffs for all apply_patch events
    assert len(diffs) == len(apply_patch_events)

    # All diffs should have high confidence (apply_patch is explicit)
    for item in diffs:
        assert item["diff"].confidence == "high"
        assert item["diff"].format_source == "codex_apply_patch"

    # Total lines added across all patches should be substantial
    total_additions = sum(len(item["diff"].lines_added) for item in diffs)
    assert total_additions > 50  # We added a lot of content

    print(f"\nExtracted {len(diffs)} diffs with {total_additions} total line additions")
    for item in diffs:
        hunks = len(item["diff"].hunks)
        additions = len(item["diff"].lines_added)
        print(f"  {item['event_id']}: {hunks} hunks, {additions} additions")
