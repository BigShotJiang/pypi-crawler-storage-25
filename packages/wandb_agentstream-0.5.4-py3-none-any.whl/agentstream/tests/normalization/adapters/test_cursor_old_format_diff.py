"""Test Cursor old format (edit_file_v2) diff extraction with FileSystemState."""

import pytest

from agentstream.normalization import FileSystemState
from agentstream.normalization.adapters import CursorV1Normalizer


def test_old_format_diff_with_file_state():
    """Test that old format (edit_file_v2) can extract diffs using FileSystemState."""
    normalizer = CursorV1Normalizer()
    state = FileSystemState()

    # Simulate a file read first (to populate state)
    read_event = {
        "event_id": "read-1",
        "tool_name": "read_file_v2",
        "args": {
            "targetFile": "/path/to/file.py",
        },
        "result": {
            "contents": "def hello():\n    print('hello')\n",
            "totalLinesInFile": 2,
        },
        "timestamp_ms": 1000,
    }

    # Process read (populates state, returns None)
    diff = normalizer.extract_diff(read_event, state)
    assert diff is None
    assert state.has_content("/path/to/file.py")

    # Now simulate an old-format edit (edit_file_v2)
    edit_event = {
        "event_id": "edit-1",
        "tool_name": "edit_file_v2",
        "args": {
            "relativeWorkspacePath": "/path/to/file.py",
            "streamingContent": "def hello():\n    print('hello world')\n",
            "noCodeblock": True,
        },
        "result": {
            "beforeContentId": "composer.content.abc123",
            "afterContentId": "composer.content.def456",
        },
        "timestamp_ms": 2000,
    }

    # Process edit (should compute diff from state)
    diff = normalizer.extract_diff(edit_event, state)

    assert diff is not None
    assert diff.format_source == "computed"
    assert diff.confidence == "medium"
    assert len(diff.hunks) == 1

    # Check that line 2 was added (the modified line)
    assert 2 in diff.lines_added


def test_old_format_without_prior_read():
    """Test that old format without prior read stores content but returns None."""
    normalizer = CursorV1Normalizer()
    state = FileSystemState()

    # Old-format edit without prior read
    edit_event = {
        "event_id": "edit-1",
        "tool_name": "edit_file_v2",
        "args": {
            "relativeWorkspacePath": "/path/to/newfile.py",
            "streamingContent": "def new_function():\n    pass\n",
            "noCodeblock": True,
        },
        "result": {
            "afterContentId": "composer.content.xyz789",
        },
        "timestamp_ms": 1000,
    }

    # Process edit (should store content but return None since no old content)
    diff = normalizer.extract_diff(edit_event, state)
    assert diff is None

    # But state should now have the content for future diffs
    assert state.has_content("/path/to/newfile.py")
    content = state.get_content("/path/to/newfile.py")
    assert content is not None
    assert "def new_function" in content


def test_old_format_multiple_edits():
    """Test that multiple old-format edits build up correct diffs."""
    normalizer = CursorV1Normalizer()
    state = FileSystemState()

    # First edit (no prior content)
    edit1 = {
        "tool_name": "edit_file_v2",
        "args": {
            "relativeWorkspacePath": "test.py",
            "streamingContent": "line 1\nline 2\n",
        },
        "result": {"afterContentId": "hash1"},
        "timestamp_ms": 1000,
    }

    diff1 = normalizer.extract_diff(edit1, state)
    assert diff1 is None  # No prior content
    assert state.get_content("test.py") == "line 1\nline 2\n"

    # Second edit (has prior content)
    edit2 = {
        "tool_name": "edit_file_v2",
        "args": {
            "relativeWorkspacePath": "test.py",
            "streamingContent": "line 1\nline 2 modified\nline 3\n",
        },
        "result": {"beforeContentId": "hash1", "afterContentId": "hash2"},
        "timestamp_ms": 2000,
    }

    diff2 = normalizer.extract_diff(edit2, state)
    assert diff2 is not None
    assert diff2.confidence == "medium"
    assert len(diff2.lines_added) >= 1  # At least line 2 (modified) and line 3 (new)


def test_new_format_still_works():
    """Test that new format (write/search_replace) still works as before."""
    normalizer = CursorV1Normalizer()
    state = FileSystemState()

    # New format with diff.chunks
    event = {
        "tool_name": "write",
        "args": {"relativeWorkspacePath": "file.py"},
        "result": {
            "diff": {
                "chunks": [
                    {
                        "diffString": " line 1\n-line 2\n+line 2 modified\n line 3",
                        "oldStart": 1,
                        "oldLines": 3,
                        "newStart": 1,
                        "newLines": 3,
                        "linesRemoved": 1,
                        "linesAdded": 1,
                    }
                ],
                "editor": "EDITOR_AI",
            },
            "contentsAfterEdit": "line 1\nline 2 modified\nline 3\n",
        },
        "timestamp_ms": 1000,
    }

    diff = normalizer.extract_diff(event, state)
    assert diff is not None
    assert diff.format_source == "cursor_diff_chunks"
    assert diff.confidence == "high"
    assert 2 in diff.lines_added  # Line 2 was modified (shown as addition)


def test_file_state_independence():
    """Test that FileSystemState properly isolates different files."""
    state = FileSystemState()

    state.set_content("file1.py", "content1")
    state.set_content("file2.py", "content2")

    assert state.get_content("file1.py") == "content1"
    assert state.get_content("file2.py") == "content2"
    assert state.get_content("file3.py") is None

    assert "file1.py" in state
    assert "file2.py" in state
    assert "file3.py" not in state

    assert len(state) == 2

    state.clear()
    assert len(state) == 0
    assert state.get_content("file1.py") is None


def test_real_cursor_old_format_example():
    """Test with real Cursor old format data from extracted sessions."""
    normalizer = CursorV1Normalizer()
    state = FileSystemState()

    # Simulate the .gitignore file read that would have happened earlier
    old_content = """# Python
__pycache__/
*.py[cod]
*$py.class

# Virtual environments
.venv/
venv/
ENV/

# Testing
.pytest_cache/
.coverage
"""

    state.set_content("/Users/vanpelt/Development/agentstream-py/.gitignore", old_content)

    # Real edit_file_v2 event from session (simplified)
    edit_event = {
        "tool_name": "edit_file_v2",
        "args": {
            "relativeWorkspacePath": "/Users/vanpelt/Development/agentstream-py/.gitignore",
            "streamingContent": """# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python

# Virtual environments
.venv/
venv/
ENV/

# Testing
.pytest_cache/
.coverage

# Plan files (working docs)
PLAN-*.md
UNDERSTANDING.md
""",
            "noCodeblock": True,
        },
        "result": {
            "beforeContentId": (
                "composer.content.32616514e835acb2266e3aea2e49753db9cd1f2e6f111d4e66ba22fcd2745cd3"
            ),
            "afterContentId": (
                "composer.content.a135a8d24f4385150ffc287528ff77e711288a88ce65c397bcecf329eae083a1"
            ),
        },
        "timestamp_ms": 1768456385333,
    }

    diff = normalizer.extract_diff(edit_event, state)

    assert diff is not None
    assert diff.confidence == "medium"
    assert diff.format_source == "computed"
    assert len(diff.hunks) > 0

    # Should have additions for the new lines (*.so, .Python, PLAN-*.md, UNDERSTANDING.md)
    assert len(diff.lines_added) >= 4


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
