"""Tests for Claude normalizer git commit extraction."""

import pytest

from agentstream.normalization.adapters.claude_v1 import ClaudeV1Normalizer


@pytest.fixture
def normalizer():
    return ClaudeV1Normalizer()


def _make_bash_event(command: str, result="", *, timestamp_ms: int = 1000000000000):
    """Build a normalizer-format event for Claude Bash tool."""
    event = {
        "tool_name": "Bash",
        "args": {"command": command},
        "timestamp_ms": timestamp_ms,
        "event_id": "evt_test",
    }
    if result:
        event["result"] = result
    return event


class TestClaudeGitCommitExtraction:
    def test_commit_with_output(self, normalizer):
        git_state = {"branch": None}
        event = _make_bash_event(
            'git commit -m "fix bug"',
            result="[main abc1234] fix bug\n 1 file changed, 2 insertions(+)",
        )
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "main"
        assert commit.commit_hash == "abc1234"
        assert commit.message == "fix bug"
        assert commit.agent_type == "claude"
        assert commit.source_tool == "Bash"

    def test_commit_uses_tracked_branch(self, normalizer):
        git_state = {"branch": None}

        # First: checkout
        checkout_event = _make_bash_event(
            "git checkout -b feature-x",
            result="Switched to a new branch 'feature-x'",
        )
        normalizer.extract_git_commit(checkout_event, git_state)
        assert git_state["branch"] == "feature-x"

        # Then: commit (output doesn't include branch info)
        commit_event = _make_bash_event(
            'git commit -m "add feature"',
            result="",
        )
        commit = normalizer.extract_git_commit(commit_event, git_state)
        assert commit is not None
        assert commit.branch == "feature-x"

    def test_commit_output_overrides_tracked_branch(self, normalizer):
        """If commit output shows branch, it should be used over tracked state."""
        git_state = {"branch": "stale-branch"}
        event = _make_bash_event(
            'git commit -m "fix"',
            result="[actual-branch def5678] fix",
        )
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "actual-branch"

    def test_checkout_updates_state_without_commit(self, normalizer):
        git_state = {"branch": None}
        event = _make_bash_event("git switch main")
        result = normalizer.extract_git_commit(event, git_state)
        assert result is None  # No commit
        assert git_state["branch"] == "main"

    def test_non_bash_tool_ignored(self, normalizer):
        git_state = {"branch": None}
        event = {
            "tool_name": "Read",
            "args": {"file_path": "/some/file"},
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        result = normalizer.extract_git_commit(event, git_state)
        assert result is None

    def test_non_git_command_ignored(self, normalizer):
        git_state = {"branch": None}
        event = _make_bash_event("npm test")
        result = normalizer.extract_git_commit(event, git_state)
        assert result is None

    def test_commit_with_no_branch_info(self, normalizer):
        """Commit with no output and no tracked branch falls back to 'unknown'."""
        git_state = {"branch": None}
        event = _make_bash_event('git commit -m "mystery"')
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "unknown"

    def test_branch_state_persists_across_events(self, normalizer):
        git_state = {"branch": None}

        # Checkout
        normalizer.extract_git_commit(_make_bash_event("git checkout develop"), git_state)
        assert git_state["branch"] == "develop"

        # Non-git command doesn't change state
        normalizer.extract_git_commit(_make_bash_event("npm install"), git_state)
        assert git_state["branch"] == "develop"

        # Commit uses persisted state
        commit = normalizer.extract_git_commit(_make_bash_event('git commit -m "done"'), git_state)
        assert commit is not None
        assert commit.branch == "develop"

    def test_result_as_dict(self, normalizer):
        """Claude result may be a dict with 'content' key."""
        git_state = {"branch": None}
        event = {
            "tool_name": "Bash",
            "args": {"command": 'git commit -m "test"'},
            "result": {"content": "[main 1234abc] test"},
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "main"

    def test_checkout_from_output_updates_state(self, normalizer):
        """Branch from output updates state when present."""
        git_state = {"branch": None}
        event = _make_bash_event(
            "git checkout develop",
            result="Switched to branch 'develop'",
        )
        normalizer.extract_git_commit(event, git_state)
        assert git_state["branch"] == "develop"
