"""Tests for Gemini normalizer git commit extraction."""

import pytest

from agentstream.normalization.adapters.gemini_v1 import GeminiV1Normalizer


@pytest.fixture
def normalizer():
    return GeminiV1Normalizer()


def _make_event(
    tool_name: str,
    command: str,
    result="",
    *,
    timestamp_ms: int = 1000000000000,
):
    event = {
        "tool_name": tool_name,
        "args": {"command": command},
        "timestamp_ms": timestamp_ms,
        "event_id": "evt_gemini",
    }
    if result != "":
        event["result"] = result
    return event


def test_extracts_commit_from_run_shell_command(normalizer):
    git_state = {"branch": None}
    event = _make_event(
        "run_shell_command",
        'git commit -m "gemini commit"',
        "[gem-main abc9999] gemini commit",
    )
    commit = normalizer.extract_git_commit(event, git_state)
    assert commit is not None
    assert commit.branch == "gem-main"
    assert commit.agent_type == "gemini"
    assert commit.source_tool == "run_shell_command"


def test_commit_uses_tracked_branch_from_state(normalizer):
    git_state = {"branch": "gem-feature"}
    event = _make_event("run_shell_command", 'git commit -m "ship"')
    commit = normalizer.extract_git_commit(event, git_state)
    assert commit is not None
    assert commit.branch == "gem-feature"


def test_fabricated_tool_names_rejected(normalizer):
    """Fabricated tool names like 'shell', 'bash', 'terminal' should be rejected."""
    git_state = {"branch": None}
    for tool_name in ("shell", "bash", "terminal", "run_command", "exec_command"):
        event = _make_event(
            tool_name,
            'git commit -m "test"',
            "[main abc1234] test",
        )
        assert normalizer.extract_git_commit(event, git_state) is None


def test_production_event_shape_string_result(normalizer):
    """Production structure with string result from run_shell_command."""
    git_state = {"branch": None}
    event = {
        "tool_name": "run_shell_command",
        "args": {"command": 'git commit -m "production shape"'},
        "result": "[main 7ca2f3d] production shape\n 1 file changed, 2 insertions(+)",
        "timestamp_ms": 1000000000000,
        "event_id": "evt_gemini_prod",
    }
    commit = normalizer.extract_git_commit(event, git_state)
    assert commit is not None
    assert commit.branch == "main"
    assert commit.commit_hash == "7ca2f3d"
    assert commit.message == "production shape"


def test_production_event_shape_nested_result(normalizer):
    """Production structure with nested functionResponse from run_shell_command."""
    git_state = {"branch": None}
    event = {
        "tool_name": "run_shell_command",
        "args": {"command": 'git commit -m "nested shape"'},
        "result": [
            {
                "functionResponse": {
                    "response": {"output": "[main 7ca2f3d] nested shape\n 1 file changed"}
                }
            }
        ],
        "timestamp_ms": 1000000000000,
        "event_id": "evt_gemini_prod",
    }
    commit = normalizer.extract_git_commit(event, git_state)
    assert commit is not None
    assert commit.branch == "main"
    assert commit.commit_hash == "7ca2f3d"
    assert commit.message == "nested shape"
