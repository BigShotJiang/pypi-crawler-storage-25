"""Tests for Cursor normalizer git commit extraction."""

import pytest

from agentstream.normalization.adapters.cursor_v1 import CursorV1Normalizer


@pytest.fixture
def normalizer():
    return CursorV1Normalizer()


def _make_event(
    tool_name: str,
    command: str,
    result="",
    *,
    timestamp_ms: int = 1000000000000,
):
    event = {
        "tool_name": tool_name,
        "args": {"command": command},
        "timestamp_ms": timestamp_ms,
        "event_id": "evt_cursor",
    }
    if result != "":
        event["result"] = result
    return event


def test_extracts_commit_from_run_terminal_cmd(normalizer):
    git_state = {"branch": None}
    event = _make_event(
        "run_terminal_cmd",
        'git commit -m "cursor commit"',
        {"stdout": "[cursor-main abc1234] cursor commit"},
    )
    commit = normalizer.extract_git_commit(event, git_state)
    assert commit is not None
    assert commit.branch == "cursor-main"
    assert commit.agent_type == "cursor"
    assert commit.source_tool == "run_terminal_cmd"


def test_extracts_commit_from_run_terminal_command_v2(normalizer):
    git_state = {"branch": None}
    event = _make_event(
        "run_terminal_command_v2",
        'git commit -m "v2 commit"',
        {"output": "[v2-branch def5678] v2 commit"},
    )
    commit = normalizer.extract_git_commit(event, git_state)
    assert commit is not None
    assert commit.branch == "v2-branch"
    assert commit.agent_type == "cursor"
    assert commit.source_tool == "run_terminal_command_v2"


def test_commit_uses_tracked_branch_from_checkout(normalizer):
    git_state = {"branch": None}
    checkout_event = _make_event(
        "run_terminal_cmd",
        "git checkout -b cursor-feature",
        "Switched to a new branch 'cursor-feature'",
    )
    assert normalizer.extract_git_commit(checkout_event, git_state) is None
    assert git_state["branch"] == "cursor-feature"

    commit_event = _make_event("run_terminal_cmd", 'git commit -m "done"')
    commit = normalizer.extract_git_commit(commit_event, git_state)
    assert commit is not None
    assert commit.branch == "cursor-feature"


def test_fabricated_tool_names_rejected(normalizer):
    """Fabricated tool names like 'shell', 'terminal', 'bash' should be rejected."""
    git_state = {"branch": None}
    for tool_name in ("shell", "terminal", "bash", "exec_command", "run_command"):
        event = _make_event(
            tool_name,
            'git commit -m "test"',
            {"stdout": "[main abc1234] test"},
        )
        assert normalizer.extract_git_commit(event, git_state) is None


def test_production_event_shape(normalizer):
    """Mirror exact production structure: run_terminal_cmd with params.command."""
    git_state = {"branch": None}
    event = {
        "tool_name": "run_terminal_cmd",
        "args": {"command": 'git commit -m "production shape"'},
        "result": {"output": "[main 7ca2f3d] production shape\n 1 file changed, 2 insertions(+)"},
        "timestamp_ms": 1000000000000,
        "event_id": "evt_cursor_prod",
    }
    commit = normalizer.extract_git_commit(event, git_state)
    assert commit is not None
    assert commit.branch == "main"
    assert commit.commit_hash == "7ca2f3d"
    assert commit.message == "production shape"
