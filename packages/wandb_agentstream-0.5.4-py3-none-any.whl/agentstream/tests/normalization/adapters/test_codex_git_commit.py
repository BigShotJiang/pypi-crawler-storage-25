"""Tests for Codex normalizer git commit extraction."""

import pytest

from agentstream.normalization.adapters.codex_v1 import CodexV1Normalizer


@pytest.fixture
def normalizer():
    return CodexV1Normalizer()


def _make_exec_event(
    cmd: str,
    output: str = "",
    *,
    tool_name: str = "exec_command",
    timestamp_ms: int = 1000000000000,
):
    """Build a normalizer-format event for Codex shell tool."""
    event = {
        "tool_name": tool_name,
        "args": {"cmd": cmd},
        "timestamp_ms": timestamp_ms,
        "event_id": "evt_test",
    }
    if output:
        event["result"] = {"output": output}
    return event


class TestCodexGitCommitExtraction:
    def test_commit_with_output(self, normalizer):
        git_state = {"branch": None}
        event = _make_exec_event(
            'git commit -m "fix bug"',
            output="[main abc1234] fix bug\n 1 file changed",
        )
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "main"
        assert commit.commit_hash == "abc1234"
        assert commit.message == "fix bug"
        assert commit.agent_type == "codex"
        assert commit.source_tool == "exec_command"

    def test_checkout_updates_state(self, normalizer):
        git_state = {"branch": None}
        event = _make_exec_event(
            "git checkout -b feature-y",
            output="Switched to a new branch 'feature-y'",
        )
        result = normalizer.extract_git_commit(event, git_state)
        assert result is None  # Not a commit
        assert git_state["branch"] == "feature-y"

    def test_commit_uses_tracked_branch(self, normalizer):
        git_state = {"branch": None}

        # Checkout first
        normalizer.extract_git_commit(
            _make_exec_event("git switch -c my-feature"),
            git_state,
        )
        assert git_state["branch"] == "my-feature"

        # Then commit
        commit = normalizer.extract_git_commit(
            _make_exec_event('git commit -m "work"'),
            git_state,
        )
        assert commit is not None
        assert commit.branch == "my-feature"

    def test_nested_output_json(self, normalizer):
        """Codex wraps output in {"output": "...", "metadata": {...}}."""
        git_state = {"branch": None}
        event = {
            "tool_name": "exec_command",
            "args": {"cmd": 'git commit -m "test"'},
            "result": {
                "output": "[main 1234abc] test",
                "metadata": {"exit_code": 0},
            },
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "main"

    def test_cmd_as_array(self, normalizer):
        """Codex cmd may be an array of strings."""
        git_state = {"branch": None}
        event = {
            "tool_name": "exec_command",
            "args": {"cmd": ["git", "commit", "-m", "array cmd"]},
            "result": {"output": "[main aaa1111] array cmd"},
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "main"

    def test_command_key_fallback(self, normalizer):
        """Codex may use 'command' key instead of 'cmd'."""
        git_state = {"branch": None}
        event = {
            "tool_name": "exec_command",
            "args": {"command": 'git commit -m "alt key"'},
            "result": {"output": "[alt bbb2222] alt key"},
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "alt"

    def test_non_shell_tool_ignored(self, normalizer):
        git_state = {"branch": None}
        event = {
            "tool_name": "update_plan",
            "args": {"plan": []},
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        result = normalizer.extract_git_commit(event, git_state)
        assert result is None

    def test_result_as_string(self, normalizer):
        """Result may be a plain string instead of dict."""
        git_state = {"branch": None}
        event = {
            "tool_name": "exec_command",
            "args": {"cmd": 'git commit -m "plain"'},
            "result": "[main ccc3333] plain",
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "main"

    def test_commit_with_no_branch_info(self, normalizer):
        """Falls back to 'unknown' with no output and no tracked state."""
        git_state = {"branch": None}
        event = _make_exec_event('git commit -m "mystery"')
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "unknown"

    def test_fabricated_tool_names_rejected(self, normalizer):
        """Fabricated tool names like 'shell', 'bash', 'run_command' should be rejected."""
        git_state = {"branch": None}
        for tool_name in ("shell", "shell_command", "bash", "run_command"):
            event = _make_exec_event(
                'git commit -m "test"',
                output="[main abc1234] test",
                tool_name=tool_name,
            )
            assert normalizer.extract_git_commit(event, git_state) is None

    def test_production_event_shape(self, normalizer):
        """Mirror exact production structure: exec_command with args.cmd, result as string."""
        git_state = {"branch": None}
        event = {
            "tool_name": "exec_command",
            "args": {"cmd": 'git commit -m "production shape"'},
            "result": (
                "Exit code: 0\nOutput:\n"
                "[main 7ca2f3d] production shape\n 1 file changed, 2 insertions(+)"
            ),
            "timestamp_ms": 1000000000000,
            "event_id": "evt_codex_prod",
        }
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "main"
        assert commit.commit_hash == "7ca2f3d"
        assert commit.message == "production shape"
