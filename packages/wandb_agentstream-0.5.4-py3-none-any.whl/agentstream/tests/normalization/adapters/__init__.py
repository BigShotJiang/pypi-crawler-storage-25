"""Tests for agent-specific normalizer adapters."""
