"""Tests for Cursor v1.x normalizer."""

from agentstream.normalization.adapters.cursor_v1 import CursorV1Normalizer
from agentstream.normalization.file_state import FileSystemState


def test_cursor_extract_todo_from_todo_write():
    """Extract todos from Cursor todo_write tool"""
    normalizer = CursorV1Normalizer()

    event = {
        "event_id": "evt-cursor-1",
        "tool_name": "todo_write",
        "timestamp_ms": 1704067200000,
        "agent_type": "cursor",
        "args": {
            "todos": [
                {
                    "content": "Implement API",
                    "status": "pending",
                    "activeForm": "Implementing API",
                    "id": "1",
                }
            ]
        },
        "result": {
            "initialTodos": [],
            "finalTodos": [
                {
                    "content": "Implement API",
                    "status": "pending",
                    "activeForm": "Implementing API",
                    "id": "1",
                }
            ],
        },
    }

    todos = normalizer.extract_todo(event)
    assert todos is not None
    assert len(todos) == 1
    assert todos[0].content == "Implement API"
    assert todos[0].id == "1"
    assert todos[0].source_tool == "todo_write"


def test_cursor_extract_file_operation_edit():
    """Extract edit from edit_file_v2"""
    normalizer = CursorV1Normalizer()

    event = {
        "event_id": "evt-cursor-2",
        "tool_name": "edit_file_v2",
        "timestamp_ms": 1704067200000,
        "agent_type": "cursor",
        "args": {"relativeWorkspacePath": "src/auth.ts"},
        "result": {
            "beforeContentId": "abc123",
            "afterContentId": "def456",
            "fileOps": {"modified": ["src/auth.ts"]},
        },
    }

    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.file_path == "src/auth.ts"
    assert file_op.operation == "edit"
    assert file_op.confidence == "medium"  # Need to compute diff


def test_cursor_extract_file_operation_edit_new_format():
    """Extract edit from edit_file (new format with diff.chunks)"""
    normalizer = CursorV1Normalizer()

    event = {
        "event_id": "evt-cursor-new-format",
        "tool_name": "edit_file",
        "timestamp_ms": 1704067200000,
        "agent_type": "cursor",
        "args": {"relativeWorkspacePath": "frontend/.stylelintrc.json"},
        "result": {
            "diff": {
                "chunks": [
                    {
                        "diffString": "-old line\n+new line",
                        "oldStart": 10,
                        "newStart": 10,
                        "oldLines": 1,
                        "newLines": 1,
                        "linesRemoved": 1,
                        "linesAdded": 1,
                    }
                ]
            },
            "isApplied": True,
            "numLinesInFile": 20,
        },
    }

    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.file_path == "frontend/.stylelintrc.json"
    assert file_op.operation == "edit"
    assert file_op.confidence == "high"  # Has diff.chunks


def test_cursor_extract_diff_file_creation_with_computed_diff():
    """Extract diff for file creation using daemon-enriched _computed_diff"""

    normalizer = CursorV1Normalizer()
    state = FileSystemState()  # Empty state - no prior content

    # File creation: daemon enrichment computes diff from empty -> new content
    # and adds _computed_diff to result (when no beforeContentId exists)
    event = {
        "event_id": "evt-cursor-create",
        "tool_name": "edit_file_v2",
        "timestamp_ms": 1704067200000,
        "agent_type": "cursor",
        "args": {
            "relativeWorkspacePath": "tmp/new_file.txt",
        },
        "result": {
            "afterContentId": "composer.content.abc123",
            "_computed_diff": {
                "hunks": [
                    {
                        "old_start": 0,
                        "old_count": 0,
                        "new_start": 1,
                        "new_count": 2,
                        "lines": ["+Hello World!", "+This is a new file."],
                    }
                ]
            },
        },
    }

    diff = normalizer.extract_diff(event, state)
    assert diff is not None
    assert diff.format_source == "computed"
    assert len(diff.hunks) == 1
    # All lines should be additions (file creation)
    hunk = diff.hunks[0]
    assert all(line.startswith("+") for line in hunk.lines)
    # Should have additions
    assert len(diff.lines_added) == 2


def test_cursor_extract_file_operation_read():
    """Extract read from read_file_v2"""
    normalizer = CursorV1Normalizer()

    event = {
        "event_id": "evt-cursor-3",
        "tool_name": "read_file_v2",
        "timestamp_ms": 1704067200000,
        "agent_type": "cursor",
        "args": {"targetFile": "src/config.ts"},
    }

    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.file_path == "src/config.ts"
    assert file_op.operation == "read"


def test_cursor_extract_skill_from_file_read():
    """Extract skill from SKILL.md file read"""
    normalizer = CursorV1Normalizer()

    event = {
        "event_id": "evt-cursor-skill",
        "tool_name": "read_file_v2",
        "timestamp_ms": 1704067200000,
        "agent_type": "cursor",
        "args": {"targetFile": "/project/.claude/skills/reviewer/SKILL.md"},
        "result": {
            "contents": (
                "---\nname: code-reviewer\ndescription: Review code\n---\n# Code Reviewer\n..."
            )
        },
    }

    skill = normalizer.extract_skill(event)
    assert skill is not None
    assert skill.name == "code-reviewer"
    assert skill.method == "file-read"
    assert skill.skill_type == "native-claude"
    assert skill.file_path == "/project/.claude/skills/reviewer/SKILL.md"


def test_cursor_extract_skill_marketplace():
    """Extract marketplace skill"""
    normalizer = CursorV1Normalizer()

    event = {
        "event_id": "evt-cursor-skill-2",
        "tool_name": "read_file_v2",
        "timestamp_ms": 1704067200000,
        "agent_type": "cursor",
        "args": {
            "targetFile": (
                "/home/.claude/plugins/cache/superpowers-marketplace/"
                "superpowers/4.0.3/skills/brainstorming/SKILL.md"
            )
        },
        "result": {"contents": "---\nname: superpowers:brainstorming\n---\n..."},
    }

    skill = normalizer.extract_skill(event)
    assert skill is not None
    assert skill.name == "superpowers:brainstorming"
    assert skill.skill_type == "marketplace"
