"""Test Cursor diff extraction using real session data."""

import json
from pathlib import Path

import pytest

from agentstream.normalization.adapters.cursor_v1 import CursorV1Normalizer


@pytest.fixture
def cursor_events():
    """Load real Cursor edit events from fixtures."""
    fixture_path = Path(__file__).parent.parent.parent / "fixtures" / "cursor_diff_events.json"
    with open(fixture_path) as f:
        data = json.load(f)
    return data["events"]


def test_extract_diff_from_write_repository_filtering_edit(cursor_events):
    """Test extracting diff from the repository-filtering.md rewrite."""
    normalizer = CursorV1Normalizer()

    # First event is the big rewrite of repository-filtering.md
    event = cursor_events[0]
    assert event["tool_name"] == "write"
    assert "repository-filtering.md" in event["args"]["relativeWorkspacePath"]

    diff = normalizer.extract_diff(event, session=None)

    assert diff is not None
    assert diff.format_source == "cursor_diff_chunks"
    assert diff.confidence == "high"
    assert len(diff.hunks) == 1  # Single large rewrite

    # Check hunk metadata
    hunk = diff.hunks[0]
    assert hunk.old_start == 1
    assert hunk.new_start == 1
    assert hunk.old_count == 41
    assert hunk.new_count == 231

    # Should have many additions (expanded documentation)
    assert len(diff.lines_added) > 200

    # Verify some specific content exists in the diff
    all_lines = "\n".join(hunk.lines)
    assert "+ Repository filtering enables users" in all_lines
    assert "+ ## Overview" in all_lines
    assert "+ ### Repository Dropdown" in all_lines


def test_extract_diff_from_write_agent_personality_profiles_creation(cursor_events):
    """Test extracting diff from agent-personality-profiles.md creation."""
    normalizer = CursorV1Normalizer()

    # Second event creates a new file
    event = cursor_events[1]
    assert event["tool_name"] == "write"
    assert "agent-personality-profiles.md" in event["args"]["relativeWorkspacePath"]

    diff = normalizer.extract_diff(event, session=None)

    assert diff is not None
    assert diff.format_source == "cursor_diff_chunks"
    assert diff.confidence == "high"
    assert len(diff.hunks) == 1

    # New file creation: 1 old line (empty), 481 new lines
    hunk = diff.hunks[0]
    assert hunk.old_count == 1
    assert hunk.new_count == 481
    assert len(diff.lines_added) == 481

    # Check for specific content
    all_lines = "\n".join(hunk.lines)
    assert "+ # Agent Personality Profiles" in all_lines
    assert "+ ## Overview" in all_lines
    assert "+ ### 1. Change Velocity" in all_lines


def test_extract_diff_from_search_replace_rbac_lowercase(cursor_events):
    """Test extracting diff from the RBAC -> rbac case change."""
    normalizer = CursorV1Normalizer()

    # Third event does a search/replace
    event = cursor_events[2]
    assert event["tool_name"] == "search_replace"
    assert "repository-filtering.md" in event["args"]["relativeWorkspacePath"]

    diff = normalizer.extract_diff(event, session=None)

    assert diff is not None
    assert diff.format_source == "cursor_diff_chunks"
    assert len(diff.hunks) >= 2  # Multiple replacements of RBAC -> rbac

    # Check the changes - should have RBAC -> rbac replacements
    all_lines = "\n".join(line for hunk in diff.hunks for line in hunk.lines)
    assert "RBAC" in all_lines  # Old text
    assert (
        "+ - **rbac-aware access**" in all_lines or "+ ### rbac Enforcement" in all_lines
    )  # New text


def test_extract_diff_handles_empty_diffstring():
    """Test that extract_diff handles events without diffString gracefully."""
    normalizer = CursorV1Normalizer()

    event = {
        "tool_name": "write",
        "args": {"relativeWorkspacePath": "test.md"},
        "result": {"diff": {"chunks": [{"diffString": ""}]}},
        "timestamp_ms": 1000,
    }

    diff = normalizer.extract_diff(event, session=None)
    # Empty diffString gets skipped, so we get a diff with no hunks
    # (but still returns a valid UnifiedDiff object because chunks array exists)
    assert diff is None or len(diff.hunks) == 0


def test_extract_diff_returns_none_for_no_diff():
    """Test that extract_diff returns None when result has no diff."""
    normalizer = CursorV1Normalizer()

    test_events: list[dict] = [
        {"tool_name": "write", "result": {}, "timestamp_ms": 1000},
        {"tool_name": "write", "result": {"diff": None}, "timestamp_ms": 1000},
        {"tool_name": "write", "result": {"diff": {}}, "timestamp_ms": 1000},
        {"tool_name": "write", "result": {"diff": {"chunks": []}}, "timestamp_ms": 1000},
    ]

    for event in test_events:
        diff = normalizer.extract_diff(event, session=None)
        assert diff is None


def test_extract_diff_counts_additions_correctly(cursor_events):
    """Test that line additions are counted correctly."""
    normalizer = CursorV1Normalizer()

    # Use the agent-personality-profiles creation event
    event = cursor_events[1]
    diff = normalizer.extract_diff(event, session=None)

    assert diff is not None

    # Count + lines in the hunks
    actual_additions = sum(1 for hunk in diff.hunks for line in hunk.lines if line.startswith("+"))

    # Should match the lines_added count
    assert len(diff.lines_added) == actual_additions
    assert actual_additions == 481  # New file with 481 lines


def test_extract_diff_parses_hunk_metadata(cursor_events):
    """Test that hunk metadata (oldStart, newStart, etc.) is preserved."""
    normalizer = CursorV1Normalizer()

    # Use the search_replace event which has specific line numbers
    event = cursor_events[2]
    diff = normalizer.extract_diff(event, session=None)

    assert diff is not None
    assert len(diff.hunks) >= 1

    # First hunk should have the metadata from Cursor
    hunk = diff.hunks[0]
    assert hunk.old_start == 8
    assert hunk.new_start == 8
    assert hunk.old_count == 5
    assert hunk.new_count == 5


def test_real_session_demonstrates_proper_diff_extraction(cursor_events):
    """Integration test: Verify all events extract diffs properly."""
    normalizer = CursorV1Normalizer()

    # Extract diffs from all events
    diffs = []
    for event in cursor_events:
        diff = normalizer.extract_diff(event, session=None)
        if diff:
            diffs.append(
                {"event_id": event["event_id"], "tool_name": event["tool_name"], "diff": diff}
            )

    # We should have extracted diffs for all 3 events
    assert len(diffs) == 3

    # All diffs should have high confidence (Cursor provides structured data)
    for item in diffs:
        assert item["diff"].confidence == "high"
        assert item["diff"].format_source == "cursor_diff_chunks"

    # Total lines added should match session metadata
    total_additions = sum(len(item["diff"].lines_added) for item in diffs)
    # Session reported 696 lines added total
    # Our fixture has: 215 (first write) + 481 (second write) + 2 (search_replace) = 698
    # Close enough (off by 2, likely due to how Cursor counts)
    assert total_additions >= 690

    print(f"\nExtracted {len(diffs)} diffs with {total_additions} total line additions")
    for item in diffs:
        hunks = len(item["diff"].hunks)
        additions = len(item["diff"].lines_added)
        tool = item["tool_name"]
        print(f"  {item['event_id'][:8]}... ({tool:15}): {hunks} hunks, {additions} additions")
