"""Tests for Codex v1 Phase 2 extraction methods."""

import json
from datetime import UTC, datetime

from agentstream.normalization.adapters.codex_v1 import CodexV1Normalizer


def test_codex_extract_session_metadata_from_first_entry():
    """Extract session metadata from first entry with all fields.

    Codex source entries contain full git info (branch, commit_hash, repository_url).
    The normalizer should extract these from source entries, not daemon_metadata.
    """
    normalizer = CodexV1Normalizer()

    # Codex format: first entry is session_meta with payload containing metadata
    # Real Codex sessions include git.commit_hash and git.repository_url
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "session_meta",
                    "timestamp": "2024-01-01T00:00:00.000Z",
                    "payload": {
                        "cwd": "/Users/test/project",
                        "cli_version": "0.84.0",
                        "git": {
                            "branch": "feature/test",
                            "commit_hash": "source123abc",
                            "repository_url": "git@github.com:user/source-repo.git",
                        },
                    },
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    # Daemon metadata should be used as FALLBACK only
    daemon_metadata = {
        "git_commit": "daemon456def",
        "git_repo": "https://github.com/user/daemon-repo.git",
        "git_branch": "daemon-branch",
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    assert metadata.cwd == "/Users/test/project"
    assert metadata.agent_type == "codex"
    assert metadata.agent_version == "0.84.0"
    # Source entries should be preferred over daemon_metadata
    assert metadata.git_branch == "feature/test"
    assert metadata.git_commit == "source123abc"
    assert metadata.git_repo == "git@github.com:user/source-repo.git"
    assert metadata.primary_model == ""  # No model found, returns empty string
    assert metadata.timestamp == datetime.fromtimestamp(1704067200000 / 1000, tz=UTC)


def test_codex_extract_session_metadata_falls_back_to_daemon_metadata():
    """Fall back to daemon_metadata when source entries lack git info.

    When source entries don't have git info (e.g., session started outside a repo,
    or older Codex version), the normalizer should fall back to daemon_metadata.
    """
    normalizer = CodexV1Normalizer()

    # Source entry without git info
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "session_meta",
                    "timestamp": "2024-01-01T00:00:00.000Z",
                    "payload": {
                        "cwd": "/Users/test/project",
                        "cli_version": "0.84.0",
                        # No git info in source entry
                    },
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    daemon_metadata = {
        "git_commit": "daemon456def",
        "git_repo": "https://github.com/user/daemon-repo.git",
        "git_branch": "daemon-branch",
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    # Should fall back to daemon_metadata
    assert metadata.git_branch == "daemon-branch"
    assert metadata.git_commit == "daemon456def"
    assert metadata.git_repo == "https://github.com/user/daemon-repo.git"


def test_codex_extract_session_metadata_with_missing_fields():
    """Extract session metadata with some missing optional fields."""
    normalizer = CodexV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "tool_name": "exec_command",
                    "args": {"cmd": "ls"},
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    metadata = normalizer.extract_session_metadata(source_entries, None)

    assert metadata is not None
    assert metadata.cwd is None
    assert metadata.git_branch is None
    assert metadata.agent_version is None
    assert metadata.git_commit is None


def test_codex_extract_session_metadata_outside_git_repo():
    """Extract session metadata for a session run outside any git repository.

    Sessions can be run in directories that aren't git repos. In this case,
    both source entries and daemon_metadata will have empty/None git fields.
    """
    normalizer = CodexV1Normalizer()

    # Session started in a non-git directory
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "session_meta",
                    "timestamp": "2024-01-01T00:00:00.000Z",
                    "payload": {
                        "cwd": "/tmp/scratch-project",
                        "cli_version": "0.84.0",
                        # No git field at all - not in a git repo
                    },
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    # Daemon also couldn't find git info (not a git repo)
    daemon_metadata = {
        "cwd": "/tmp/scratch-project",
        "git_commit": "",
        "git_repo": "",
        "git_branch": "",
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    assert metadata.cwd == "/tmp/scratch-project"
    assert metadata.agent_type == "codex"
    assert metadata.agent_version == "0.84.0"
    # All git fields should be empty/None
    assert metadata.git_branch == ""  # Daemon fallback is empty string
    assert metadata.git_commit == ""
    assert metadata.git_repo == ""


def test_codex_extract_session_metadata_empty_entries():
    """Return None when source_entries is empty."""
    normalizer = CodexV1Normalizer()

    metadata = normalizer.extract_session_metadata([], None)
    assert metadata is None


def test_codex_extract_session_metadata_with_model_provider_fallback():
    """Extract session metadata using model_provider when model is not present.

    Real Codex sessions often have model_provider (e.g., "openai") but no model field.
    The normalizer should fall back to model_provider for primary_model.
    """
    normalizer = CodexV1Normalizer()

    # Codex format: session_meta with model_provider but no model field
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "session_meta",
                    "timestamp": "2024-01-01T00:00:00.000Z",
                    "payload": {
                        "cwd": "/Users/test/codex-project",
                        "cli_version": "0.84.0",
                        "model_provider": "openai",  # Only model_provider, no model
                        "git": {
                            "branch": "main",
                        },
                    },
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    metadata = normalizer.extract_session_metadata(source_entries, None)

    assert metadata is not None
    assert metadata.cwd == "/Users/test/codex-project"
    assert metadata.agent_type == "codex"
    assert metadata.agent_version == "0.84.0"
    assert metadata.git_branch == "main"
    assert metadata.primary_model == "openai"  # Falls back to model_provider


def test_codex_extract_token_usage_from_token_count_event():
    """Extract token usage from event_msg with payload.type == token_count.

    Codex emits token_count events with total_token_usage (cumulative) and
    last_token_usage (per-API-call delta). We extract from last_token_usage.
    """
    normalizer = CodexV1Normalizer()

    source_entry = {
        "timestamp": "2026-02-15T05:54:28.301Z",
        "type": "event_msg",
        "payload": {
            "type": "token_count",
            "info": {
                "total_token_usage": {
                    "input_tokens": 16350,
                    "cached_input_tokens": 13696,
                    "output_tokens": 485,
                    "reasoning_output_tokens": 240,
                    "total_tokens": 16835,
                },
                "last_token_usage": {
                    "input_tokens": 8302,
                    "cached_input_tokens": 6784,
                    "output_tokens": 276,
                    "reasoning_output_tokens": 132,
                    "total_tokens": 8578,
                },
            },
        },
        "_timestamp_ms": 1704067200000,
    }

    usage_list = normalizer.extract_token_usage(source_entry)

    assert len(usage_list) == 1
    usage = usage_list[0]
    assert usage.input_tokens == 8302
    assert usage.output_tokens == 276
    assert usage.cache_read_tokens == 6784
    assert usage.cache_creation_tokens == 0
    assert usage.reasoning_tokens == 132
    assert usage.model is None
    assert usage.is_cumulative is False
    assert usage.timestamp == datetime.fromtimestamp(1704067200000 / 1000, tz=UTC)


def test_codex_extract_token_usage_no_info():
    """Return empty list when token_count event has no info (rate limit only)."""
    normalizer = CodexV1Normalizer()

    source_entry = {
        "type": "event_msg",
        "payload": {
            "type": "token_count",
            "info": None,
            "rate_limits": {"limit_id": "codex"},
        },
    }

    usage_list = normalizer.extract_token_usage(source_entry)
    assert usage_list == []


def test_codex_extract_token_usage_non_token_count_event():
    """Return empty list for non-token_count event_msg entries."""
    normalizer = CodexV1Normalizer()

    source_entry = {
        "type": "event_msg",
        "payload": {"type": "agent_reasoning", "text": "Thinking..."},
    }

    usage_list = normalizer.extract_token_usage(source_entry)
    assert usage_list == []


def test_codex_extract_token_usage_non_event_msg():
    """Return empty list for non-event_msg entries (response_item, etc.)."""
    normalizer = CodexV1Normalizer()

    source_entry = {
        "type": "response_item",
        "payload": {"type": "function_call", "name": "exec_command"},
    }

    usage_list = normalizer.extract_token_usage(source_entry)
    assert usage_list == []


def test_codex_token_usage_group_key_dedup():
    """Duplicate token_count events (same totals) should share a group key."""
    normalizer = CodexV1Normalizer()

    # Two events with identical total_token_usage (emitted pre/post tool execution)
    entry_a = {
        "type": "event_msg",
        "payload": {
            "type": "token_count",
            "info": {
                "total_token_usage": {"total_tokens": 16835},
                "last_token_usage": {"input_tokens": 8302, "output_tokens": 276},
            },
        },
    }
    entry_b = {
        "type": "event_msg",
        "payload": {
            "type": "token_count",
            "info": {
                "total_token_usage": {"total_tokens": 16835},
                "last_token_usage": {"input_tokens": 8302, "output_tokens": 276},
            },
        },
    }

    key_a = normalizer.get_token_usage_group_key(entry_a)
    key_b = normalizer.get_token_usage_group_key(entry_b)

    assert key_a is not None
    assert key_a == key_b  # Same totals -> same group -> deduped

    # Different totals should produce different keys
    entry_c = {
        "type": "event_msg",
        "payload": {
            "type": "token_count",
            "info": {
                "total_token_usage": {"total_tokens": 25000},
                "last_token_usage": {"input_tokens": 9000, "output_tokens": 300},
            },
        },
    }
    key_c = normalizer.get_token_usage_group_key(entry_c)
    assert key_c != key_a  # Different totals -> different group


def test_codex_extract_error_from_exec_command_failure():
    """Extract error from exec_command with non-zero exit code."""
    normalizer = CodexV1Normalizer()

    source_entry = {
        "tool_name": "exec_command",
        "args": {"cmd": "cat missing.txt"},
        "result": {
            "exit_code": 1,
            "error": "cat: missing.txt: No such file or directory",
            "output": "cat: missing.txt: No such file or directory",
        },
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)

    assert error is not None
    assert error.error_type == "tool_call_error"
    assert "No such file or directory" in error.message
    assert error.tool_name == "exec_command"
    assert error.timestamp == datetime.fromtimestamp(1704067200000 / 1000, tz=UTC)


def test_codex_extract_error_from_timeout():
    """Extract error from command timeout."""
    normalizer = CodexV1Normalizer()

    source_entry = {
        "tool_name": "exec_command",
        "args": {"cmd": "sleep 1000"},
        "result": {
            "timeout": True,
            "error": "Command timed out after 60 seconds",
        },
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)

    assert error is not None
    assert error.error_type == "timeout"
    assert "timed out" in error.message


def test_codex_extract_error_success_command():
    """Return None for successful command execution."""
    normalizer = CodexV1Normalizer()

    source_entry = {
        "tool_name": "exec_command",
        "args": {"cmd": "ls"},
        "result": {
            "exit_code": 0,
            "output": "file1.py file2.py",
        },
    }

    error = normalizer.extract_error(source_entry)
    assert error is None


def test_codex_extract_error_from_rate_limit():
    """Extract rate limit error."""
    normalizer = CodexV1Normalizer()

    source_entry = {
        "tool_name": "exec_command",
        "result": {
            "error": "Rate limit exceeded. Please wait and try again.",
            "rate_limit": True,
        },
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)

    assert error is not None
    assert error.error_type == "rate_limit"


def test_codex_extract_error_from_interruption():
    """Extract interruption error."""
    normalizer = CodexV1Normalizer()

    source_entry = {
        "tool_name": "exec_command",
        "result": {
            "interrupted": True,
            "error": "Command interrupted by user",
        },
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)

    assert error is not None
    assert error.error_type == "interruption"


def test_codex_extract_compaction_returns_empty_list():
    """extract_compaction returns empty list (not yet implemented for Codex)."""
    normalizer = CodexV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "tool_name": "exec_command",
                    "args": {"cmd": "ls"},
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    compactions = normalizer.extract_compaction(source_entries)
    assert compactions == []
