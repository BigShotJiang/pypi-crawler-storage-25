"""Tests for Claude v1 Phase 2 extraction methods."""

import json
from datetime import UTC, datetime

from agentstream.normalization.adapters.claude_v1 import ClaudeV1Normalizer


def test_claude_extract_session_metadata_from_first_entry():
    """Extract session metadata from first entry with all fields.

    Claude source entries contain cwd, gitBranch, and version.
    git_commit and git_repo must come from daemon_metadata (Claude doesn't provide these).
    """
    normalizer = ClaudeV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "user",
                    "cwd": "/Users/test/project",
                    "gitBranch": "main",
                    "version": "1.5.0",
                    "session_id": "sess-123",
                    "message": {"role": "user", "content": "Hello"},
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    daemon_metadata = {
        "git_commit": "abc123def456",
        "git_repo": "https://github.com/user/repo.git",
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    assert metadata.cwd == "/Users/test/project"
    assert metadata.agent_type == "claude"
    assert metadata.agent_version == "1.5.0"
    assert metadata.git_branch == "main"
    # git_commit and git_repo are NOT in Claude source entries, so they come from daemon_metadata
    assert metadata.git_commit == "abc123def456"
    assert metadata.git_repo == "https://github.com/user/repo.git"
    assert metadata.primary_model == ""  # User message has no model, returns empty string
    assert metadata.timestamp == datetime.fromtimestamp(1704067200000 / 1000, tz=UTC)


def test_claude_source_entries_preferred_over_daemon_metadata():
    """Source entry data should be preferred over daemon_metadata for cwd and gitBranch.

    When both source entries and daemon_metadata have conflicting values for cwd
    and gitBranch, the normalizer should prefer the source entry values since they
    represent the actual state when the session was created.
    """
    normalizer = ClaudeV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "user",
                    "cwd": "/Users/test/source-project",  # Source entry value
                    "gitBranch": "feature/source",  # Source entry value
                    "version": "1.5.0",
                    "message": {"role": "user", "content": "Hello"},
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    # Daemon might have outdated/different cwd and branch (e.g., from current state)
    daemon_metadata = {
        "cwd": "/Users/test/daemon-project",  # Different cwd
        "git_branch": "daemon-branch",  # Different branch
        "git_commit": "abc123",
        "git_repo": "https://github.com/user/repo.git",
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    # Source entries should be preferred for cwd and gitBranch
    assert metadata.cwd == "/Users/test/source-project"
    assert metadata.git_branch == "feature/source"
    # But git_commit and git_repo must come from daemon (Claude doesn't have these)
    assert metadata.git_commit == "abc123"
    assert metadata.git_repo == "https://github.com/user/repo.git"


def test_claude_extract_session_metadata_outside_git_repo():
    """Extract session metadata for a session run outside any git repository.

    Sessions can be run in directories that aren't git repos. In this case,
    source entries will have cwd but no gitBranch, and daemon_metadata will
    have empty git fields.
    """
    normalizer = ClaudeV1Normalizer()

    # Session in a non-git directory
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "user",
                    "cwd": "/tmp/scratch-project",
                    # Note: no gitBranch field - not in a git repo
                    "version": "2.1.0",
                    "message": {"role": "user", "content": "Hello"},
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    # Daemon also couldn't find git info
    daemon_metadata = {
        "cwd": "/tmp/scratch-project",
        "git_commit": "",
        "git_repo": "",
        "git_branch": "",
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    assert metadata.cwd == "/tmp/scratch-project"
    assert metadata.agent_type == "claude"
    assert metadata.agent_version == "2.1.0"
    # All git fields should be empty/None
    assert metadata.git_branch is None  # Not in source entries
    assert metadata.git_commit == ""  # Empty from daemon
    assert metadata.git_repo == ""


def test_claude_extract_session_metadata_first_entry_is_snapshot():
    """Extract session metadata when first entry is file-history-snapshot.

    Claude sessions can start with 'file-history-snapshot' or 'summary' entries
    that don't contain session metadata (cwd, gitBranch, version). The normalizer
    should scan through entries to find one with metadata.
    """
    normalizer = ClaudeV1Normalizer()

    source_entries = [
        # First entry is a file-history-snapshot without cwd/gitBranch
        {
            "entry_content": json.dumps(
                {
                    "type": "file-history-snapshot",
                    "messageId": "b8b1a47c-91a2-4aa9-ab65-6402d50703c8",
                    "snapshot": {
                        "messageId": "b8b1a47c-91a2-4aa9-ab65-6402d50703c8",
                        "trackedFileBackups": {},
                        "timestamp": "2026-01-19T04:12:44.201Z",
                    },
                    "isSnapshotUpdate": False,
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        },
        # Second entry is a user message with metadata
        {
            "entry_content": json.dumps(
                {
                    "type": "user",
                    "cwd": "/Users/test/my-project",
                    "gitBranch": "feature/important",
                    "version": "2.1.14",
                    "message": {"role": "user", "content": "Hello"},
                }
            ),
            "entry_timestamp_ms": 1704067201000,
            "entry_index": 1,
        },
    ]

    daemon_metadata = {
        "git_commit": "abc123",
        "git_repo": "github.com/user/repo",
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    # Should find metadata from the second entry, not the first
    assert metadata.cwd == "/Users/test/my-project"
    assert metadata.git_branch == "feature/important"
    assert metadata.agent_version == "2.1.14"
    assert metadata.git_commit == "abc123"
    assert metadata.git_repo == "github.com/user/repo"


def test_claude_extract_session_metadata_with_model_from_assistant():
    """Extract session metadata when first entry is assistant message."""
    normalizer = ClaudeV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "assistant",
                    "cwd": "/Users/test/project",
                    "gitBranch": "feature/test",
                    "version": "1.6.0",
                    "message": {
                        "role": "assistant",
                        "model": "claude-sonnet-4-5-20250929",
                        "content": [],
                    },
                }
            ),
            "entry_timestamp_ms": 1704153600000,
            "entry_index": 0,
        }
    ]

    metadata = normalizer.extract_session_metadata(source_entries, None)

    assert metadata is not None
    assert metadata.agent_version == "1.6.0"
    assert metadata.git_branch == "feature/test"
    assert metadata.primary_model == "claude-sonnet-4-5-20250929"
    assert metadata.git_commit is None  # No daemon metadata


def test_claude_extract_session_metadata_with_missing_fields():
    """Extract session metadata with some missing optional fields."""
    normalizer = ClaudeV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "user",
                    "message": {"role": "user", "content": "Test"},
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    metadata = normalizer.extract_session_metadata(source_entries, None)

    assert metadata is not None
    assert metadata.cwd is None
    assert metadata.git_branch is None
    assert metadata.agent_version is None
    assert metadata.git_commit is None


def test_claude_extract_session_metadata_empty_entries():
    """Return None when source_entries is empty."""
    normalizer = ClaudeV1Normalizer()

    metadata = normalizer.extract_session_metadata([], None)
    assert metadata is None


def test_claude_extract_token_usage_from_assistant():
    """Extract token usage from assistant message."""
    normalizer = ClaudeV1Normalizer()

    source_entry = json.loads(
        json.dumps(
            {
                "type": "assistant",
                "message": {
                    "model": "claude-sonnet-4-5-20250929",
                    "usage": {
                        "input_tokens": 1234,
                        "output_tokens": 567,
                        "cache_read_input_tokens": 890,
                        "cache_creation_input_tokens": 100,
                    },
                },
                "_timestamp_ms": 1704067200000,
            }
        )
    )

    usage_list = normalizer.extract_token_usage(source_entry)

    assert len(usage_list) == 1
    usage = usage_list[0]
    assert usage.input_tokens == 1234
    assert usage.output_tokens == 567
    assert usage.cache_read_tokens == 890
    assert usage.cache_creation_tokens == 100
    assert usage.reasoning_tokens == 0
    assert usage.model == "claude-sonnet-4-5-20250929"
    assert usage.is_cumulative is False
    assert usage.timestamp == datetime.fromtimestamp(1704067200000 / 1000, tz=UTC)


def test_claude_extract_token_usage_with_reasoning_tokens():
    """Extract token usage including reasoning tokens."""
    normalizer = ClaudeV1Normalizer()

    source_entry = {
        "type": "assistant",
        "message": {
            "model": "claude-3-7-sonnet-20250219",
            "usage": {
                "input_tokens": 500,
                "output_tokens": 200,
                "reasoning_tokens": 1500,
            },
        },
        "_timestamp_ms": 1704067200000,
    }

    usage_list = normalizer.extract_token_usage(source_entry)

    assert len(usage_list) == 1
    assert usage_list[0].reasoning_tokens == 1500


def test_claude_extract_token_usage_from_user_message():
    """Return empty list for user messages."""
    normalizer = ClaudeV1Normalizer()

    source_entry = {
        "type": "user",
        "message": {"role": "user", "content": "Hello"},
    }

    usage_list = normalizer.extract_token_usage(source_entry)
    assert usage_list == []


def test_claude_extract_token_usage_no_usage_field():
    """Return empty list when usage field is missing."""
    normalizer = ClaudeV1Normalizer()

    source_entry = {
        "type": "assistant",
        "message": {"model": "claude-sonnet-4-5", "content": []},
    }

    usage_list = normalizer.extract_token_usage(source_entry)
    assert usage_list == []


def test_claude_extract_token_usage_missing_fields():
    """Handle missing token fields gracefully."""
    normalizer = ClaudeV1Normalizer()

    source_entry = {
        "type": "assistant",
        "message": {
            "model": "claude-sonnet-4-5",
            "usage": {
                "input_tokens": 100,
                # output_tokens missing
            },
        },
        "_timestamp_ms": 1704067200000,
    }

    usage_list = normalizer.extract_token_usage(source_entry)
    assert len(usage_list) == 1
    assert usage_list[0].input_tokens == 100
    assert usage_list[0].output_tokens == 0  # Default to 0


def test_claude_extract_error_from_tool_result():
    """Extract error from tool_result with is_error=true."""
    normalizer = ClaudeV1Normalizer()

    source_entry = {
        "type": "assistant",
        "message": {
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "toolu_123",
                    "is_error": True,
                    "content": "FileNotFoundError: No such file or directory: 'missing.py'",
                }
            ],
        },
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)

    assert error is not None
    assert error.error_type == "tool_call_error"
    assert "FileNotFoundError" in error.message
    assert error.tool_call_id == "toolu_123"
    assert error.tool_name is None  # Not available in tool_result
    assert error.timestamp == datetime.fromtimestamp(1704067200000 / 1000, tz=UTC)


def test_claude_extract_error_from_user_message():
    """Return None for user messages."""
    normalizer = ClaudeV1Normalizer()

    source_entry = {
        "type": "user",
        "message": {"role": "user", "content": "Test"},
    }

    error = normalizer.extract_error(source_entry)
    assert error is None


def test_claude_extract_error_no_error_in_content():
    """Return None when no error in content blocks."""
    normalizer = ClaudeV1Normalizer()

    source_entry = {
        "type": "assistant",
        "message": {
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "toolu_456",
                    "is_error": False,
                    "content": "Success",
                }
            ],
        },
    }

    error = normalizer.extract_error(source_entry)
    assert error is None


def test_claude_extract_error_multiple_blocks_with_error():
    """Extract first error when multiple content blocks."""
    normalizer = ClaudeV1Normalizer()

    source_entry = {
        "type": "assistant",
        "message": {
            "content": [
                {
                    "type": "tool_use",
                    "id": "toolu_999",
                    "name": "Read",
                },
                {
                    "type": "tool_result",
                    "tool_use_id": "toolu_999",
                    "is_error": True,
                    "content": "Permission denied",
                },
            ],
        },
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)
    assert error is not None
    assert "Permission denied" in error.message


def test_claude_extract_error_empty_content():
    """Return None when content is empty."""
    normalizer = ClaudeV1Normalizer()

    source_entry = {
        "type": "assistant",
        "message": {"content": []},
    }

    error = normalizer.extract_error(source_entry)
    assert error is None


def test_claude_extract_compaction_no_compaction():
    """extract_compaction returns empty list when no compaction detected."""
    normalizer = ClaudeV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps({"type": "user", "message": {"content": "Test"}}),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    compactions = normalizer.extract_compaction(source_entries)
    assert compactions == []


def test_claude_extract_compaction_with_metadata_flag():
    """extract_compaction detects compaction via isCompactSummary metadata flag."""
    normalizer = ClaudeV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "user",
                    "message": {"role": "user", "content": "Some compaction summary text..."},
                    "isCompactSummary": True,
                    "isVisibleInTranscriptOnly": True,
                    "uuid": "ae87145e-a31d-4b1b-874c-52e0139aea6c",
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 309,
        }
    ]

    compactions = normalizer.extract_compaction(source_entries)
    assert len(compactions) == 1
    assert compactions[0].compaction_type == "auto_summarization"
    assert compactions[0].message_id == "ae87145e-a31d-4b1b-874c-52e0139aea6c"


def test_claude_extract_compaction_with_text_pattern():
    """extract_compaction detects compaction via text pattern fallback."""
    normalizer = ClaudeV1Normalizer()

    compaction_text = (
        "This session is being continued from a previous conversation that ran out of context. "
        "The summary below covers the earlier portion of the conversation."
    )

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "user",
                    "message": {"role": "user", "content": compaction_text},
                    "uuid": "test-uuid-123",
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 100,
        }
    ]

    compactions = normalizer.extract_compaction(source_entries)
    assert len(compactions) == 1
    assert compactions[0].compaction_type == "auto_summarization"
    assert compactions[0].message_id == "test-uuid-123"


def test_claude_extract_compaction_multiple():
    """extract_compaction detects multiple compactions in a session."""
    normalizer = ClaudeV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "user",
                    "message": {"content": "Normal message"},
                    "uuid": "normal-1",
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        },
        {
            "entry_content": json.dumps(
                {
                    "type": "user",
                    "message": {"content": "First compaction summary"},
                    "isCompactSummary": True,
                    "uuid": "compaction-1",
                }
            ),
            "entry_timestamp_ms": 1704067300000,
            "entry_index": 100,
        },
        {
            "entry_content": json.dumps(
                {
                    "type": "user",
                    "message": {"content": "Another normal message"},
                    "uuid": "normal-2",
                }
            ),
            "entry_timestamp_ms": 1704067400000,
            "entry_index": 200,
        },
        {
            "entry_content": json.dumps(
                {
                    "type": "user",
                    "message": {"content": "Second compaction summary"},
                    "isCompactSummary": True,
                    "uuid": "compaction-2",
                }
            ),
            "entry_timestamp_ms": 1704067500000,
            "entry_index": 300,
        },
    ]

    compactions = normalizer.extract_compaction(source_entries)
    assert len(compactions) == 2
    assert compactions[0].message_id == "compaction-1"
    assert compactions[1].message_id == "compaction-2"


def test_claude_extract_compaction_ignores_non_user_entries():
    """extract_compaction only checks user message entries."""
    normalizer = ClaudeV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "assistant",  # Not a user message
                    "message": {"content": "Some text"},
                    "isCompactSummary": True,  # Should be ignored
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    compactions = normalizer.extract_compaction(source_entries)
    assert compactions == []
