"""Tests for Claude Web v1 extraction methods.

Focuses on web-specific token usage handling where the API response
includes both cache_creation_input_tokens and a cache_creation breakdown.
"""

from datetime import UTC, datetime

from agentstream.normalization.adapters.claude_web_v1 import ClaudeWebV1Normalizer


def test_web_extract_token_usage_no_double_count_ephemeral():
    """Ephemeral cache tokens are a breakdown of cache_creation_input_tokens, not additive.

    The Claude API returns:
        cache_creation_input_tokens: N
        cache_creation.ephemeral_5m_input_tokens: X
        cache_creation.ephemeral_1h_input_tokens: Y
    where N == X + Y. We must NOT add ephemeral tokens on top of N.
    """
    normalizer = ClaudeWebV1Normalizer()

    source_entry = {
        "type": "assistant",
        "message": {
            "model": "claude-opus-4-5-20251101",
            "usage": {
                "input_tokens": 10,
                "output_tokens": 50,
                "cache_creation_input_tokens": 15239,
                "cache_read_input_tokens": 14327,
                "cache_creation": {
                    "ephemeral_5m_input_tokens": 15239,
                    "ephemeral_1h_input_tokens": 0,
                },
                "service_tier": "standard",
            },
        },
        "_timestamp_ms": 1704067200000,
    }

    usage_list = normalizer.extract_token_usage(source_entry)

    assert len(usage_list) == 1
    usage = usage_list[0]
    assert usage.input_tokens == 10
    assert usage.output_tokens == 50
    assert usage.cache_read_tokens == 14327
    # Must equal cache_creation_input_tokens exactly, not 2x
    assert usage.cache_creation_tokens == 15239
    assert usage.model == "claude-opus-4-5-20251101"
    assert usage.timestamp == datetime.fromtimestamp(1704067200000 / 1000, tz=UTC)


def test_web_extract_token_usage_mixed_ephemeral():
    """Both ephemeral durations present — still should not double-count."""
    normalizer = ClaudeWebV1Normalizer()

    source_entry = {
        "type": "assistant",
        "message": {
            "model": "claude-sonnet-4-5-20250929",
            "usage": {
                "input_tokens": 100,
                "output_tokens": 200,
                "cache_creation_input_tokens": 25000,
                "cache_read_input_tokens": 5000,
                "cache_creation": {
                    "ephemeral_5m_input_tokens": 15000,
                    "ephemeral_1h_input_tokens": 10000,
                },
            },
        },
        "_timestamp_ms": 1704067200000,
    }

    usage_list = normalizer.extract_token_usage(source_entry)

    assert len(usage_list) == 1
    assert usage_list[0].cache_creation_tokens == 25000


def test_web_extract_token_usage_no_cache_creation_object():
    """Handle entries without the nested cache_creation object."""
    normalizer = ClaudeWebV1Normalizer()

    source_entry = {
        "type": "assistant",
        "message": {
            "model": "claude-sonnet-4-5-20250929",
            "usage": {
                "input_tokens": 100,
                "output_tokens": 200,
                "cache_creation_input_tokens": 500,
                "cache_read_input_tokens": 300,
            },
        },
        "_timestamp_ms": 1704067200000,
    }

    usage_list = normalizer.extract_token_usage(source_entry)

    assert len(usage_list) == 1
    assert usage_list[0].cache_creation_tokens == 500
    assert usage_list[0].cache_read_tokens == 300


def test_web_extract_token_usage_user_message_ignored():
    """Return empty list for user messages."""
    normalizer = ClaudeWebV1Normalizer()

    source_entry = {
        "type": "user",
        "message": {"role": "user", "content": "Hello"},
    }

    assert normalizer.extract_token_usage(source_entry) == []


def test_web_extract_token_usage_no_usage_field():
    """Return empty list when usage field is missing."""
    normalizer = ClaudeWebV1Normalizer()

    source_entry = {
        "type": "assistant",
        "message": {"model": "claude-sonnet-4-5", "content": []},
    }

    assert normalizer.extract_token_usage(source_entry) == []
