"""Test Codex diff extraction for file creation via cat > commands."""

import json
from pathlib import Path

import pytest

from agentstream.normalization.adapters.codex_v1 import CodexV1Normalizer


@pytest.fixture
def codex_events():
    """Load real Codex events from fixtures."""
    fixture_path = (
        Path(__file__).parent.parent.parent / "fixtures" / "codex_apply_patch_events.json"
    )
    with open(fixture_path) as f:
        data = json.load(f)
    return data["events"]


def test_extract_diff_from_cat_redirect_file_creation(codex_events):
    """Test that we generate diffs for new files created via cat > redirect."""
    normalizer = CodexV1Normalizer()

    # Third event creates docs/plans/2026-01-15-repository-constellations-design.md
    event = codex_events[2]
    assert event["tool_name"] == "exec_command"
    assert "cat <<'EOF' >" in event["args"]["cmd"]
    assert "repository-constellations-design.md" in event["args"]["cmd"]

    diff = normalizer.extract_diff(event, session=None)

    # Currently this returns None, but it SHOULD return a diff!
    # When we create a new file, we should have:
    # - A single hunk starting at line 1
    # - All lines marked as additions (+)
    # - High confidence since we have the full content
    assert diff is not None, "Should generate diff for file creation via cat >"
    assert diff.format_source == "shell_inferred"
    assert diff.confidence == "high"  # We have the full content explicitly
    assert len(diff.hunks) == 1

    # All lines should be additions (no old file)
    hunk = diff.hunks[0]
    assert hunk.old_start == 0  # No old file
    assert hunk.old_count == 0
    assert hunk.new_start == 1
    assert hunk.new_count > 0  # We added lines

    # All lines should start with +
    assert all(line.startswith("+") for line in hunk.lines)

    # Should have tracked line numbers
    assert len(diff.lines_added) > 30  # The file has ~49 lines


def test_extract_diff_from_cat_redirect_shows_actual_content(codex_events):
    """Test that diff includes the actual file content."""
    normalizer = CodexV1Normalizer()

    # Fourth event creates docs/features/repository-constellations.md
    event = codex_events[3]
    assert event["tool_name"] == "exec_command"

    diff = normalizer.extract_diff(event, session=None)

    assert diff is not None
    assert len(diff.hunks) == 1

    # Check that we captured the actual content
    all_lines = "".join(diff.hunks[0].lines)
    assert "# Repository Constellations" in all_lines
    assert "github.com/org/repo" in all_lines  # Real content from the file


def test_file_operation_and_diff_both_work_for_cat_redirect(codex_events):
    """Test that both extract_file_operation and extract_diff work for cat > events."""
    normalizer = CodexV1Normalizer()

    event = codex_events[2]  # cat > design doc

    # extract_file_operation should work
    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.operation == "write"
    assert "repository-constellations-design.md" in file_op.file_path

    # extract_diff should also work
    diff = normalizer.extract_diff(event, session=None)
    assert diff is not None
    assert len(diff.lines_added) > 0


def test_diff_shows_full_file_as_additions_not_edits(codex_events):
    """Test that new files show as pure additions, not edits."""
    normalizer = CodexV1Normalizer()

    event = codex_events[2]
    diff = normalizer.extract_diff(event, session=None)

    assert diff is not None

    # For a new file:
    # - No modifications (nothing was changed)
    # - Only additions (everything is new)
    assert len(diff.lines_modified) == 0
    assert len(diff.lines_added) > 0

    # Old file didn't exist
    assert diff.hunks[0].old_count == 0
