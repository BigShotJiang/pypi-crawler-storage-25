"""Tests for Codex v1 normalizer."""

from agentstream.normalization.adapters.codex_v1 import CodexV1Normalizer


def test_codex_extract_todo_from_update_plan():
    """Extract todos from Codex update_plan tool"""
    normalizer = CodexV1Normalizer()

    event = {
        "event_id": "evt-codex-1",
        "tool_name": "update_plan",
        "timestamp_ms": 1704067200000,
        "agent_type": "codex",
        "args": {
            "plan": [
                {"step": "Set up database", "status": "completed"},
                {"step": "Write API tests", "status": "in_progress"},
            ]
        },
    }

    todos = normalizer.extract_todo(event)
    assert todos is not None
    assert len(todos) == 2
    assert todos[0].content == "Set up database"
    assert todos[0].status == "completed"
    assert todos[0].id is None  # Codex doesn't provide IDs
    assert todos[1].content == "Write API tests"


def test_codex_extract_file_operation_from_sed():
    """Extract edit from sed command"""
    normalizer = CodexV1Normalizer()

    event = {
        "event_id": "evt-codex-2",
        "tool_name": "exec_command",
        "timestamp_ms": 1704067200000,
        "agent_type": "codex",
        "args": {"cmd": "sed -i 's/old_func/new_func/g' src/utils.py"},
    }

    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.file_path == "src/utils.py"
    assert file_op.operation == "edit"
    assert file_op.confidence == "medium"


def test_codex_extract_file_operation_from_echo():
    """Extract write from echo redirect"""
    normalizer = CodexV1Normalizer()

    event = {
        "event_id": "evt-codex-3",
        "tool_name": "exec_command",
        "timestamp_ms": 1704067200000,
        "agent_type": "codex",
        "args": {"cmd": "echo \"console.log('hello');\" > src/index.js"},
    }

    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.file_path == "src/index.js"
    assert file_op.operation == "write"


def test_codex_extract_file_operation_from_cat():
    """Extract read from cat command"""
    normalizer = CodexV1Normalizer()

    event = {
        "event_id": "evt-codex-4",
        "tool_name": "exec_command",
        "timestamp_ms": 1704067200000,
        "agent_type": "codex",
        "args": {"cmd": "cat src/config.py"},
    }

    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.file_path == "src/config.py"
    assert file_op.operation == "read"


def test_codex_extract_file_operation_from_apply_patch():
    """Extract edit from apply_patch tool call."""
    normalizer = CodexV1Normalizer()

    event = {
        "event_id": "evt-codex-patch",
        "tool_name": "apply_patch",
        "timestamp_ms": 1704067200000,
        "agent_type": "codex",
        "args": {
            "input": (
                "*** Begin Patch\n"
                "*** Update File: services/api/handler.go\n"
                "@@\n"
                " import (\n"
                ' \t"context"\n'
                '+\t"fmt"\n'
                " )\n"
                "@@\n"
                "*** End Patch\n"
            )
        },
    }

    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.file_path == "services/api/handler.go"
    assert file_op.operation == "edit"
    assert file_op.confidence == "high"
    assert file_op.source_tool == "apply_patch"
    # Diff should already be attached
    assert file_op.diff is not None
    assert file_op.diff.format_source == "codex_apply_patch"
    assert len(file_op.diff.lines_added) == 1


def test_codex_extract_file_operations_multi_file():
    """Extract multiple file operations from a multi-file apply_patch."""
    normalizer = CodexV1Normalizer()

    event = {
        "event_id": "evt-codex-multi-patch",
        "tool_name": "apply_patch",
        "timestamp_ms": 1704067200000,
        "agent_type": "codex",
        "args": {
            "input": (
                "*** Begin Patch\n"
                "*** Update File: services/api/resolver/entity.go\n"
                "@@\n"
                " func TagOptions() {\n"
                '+\tlog.Debug("tag options called")\n'
                " \treturn nil\n"
                " }\n"
                "@@\n"
                "*** Update File: services/api/resolver/auth.go\n"
                "@@\n"
                " import (\n"
                '+\t"github.com/logging"\n'
                " )\n"
                "@@\n"
                "*** End Patch\n"
            )
        },
    }

    ops = normalizer.extract_file_operations(event)
    assert len(ops) == 2
    assert ops[0].file_path == "services/api/resolver/entity.go"
    assert ops[0].operation == "edit"
    assert ops[0].diff is not None
    assert len(ops[0].diff.hunks) == 1
    assert ops[1].file_path == "services/api/resolver/auth.go"
    assert ops[1].operation == "edit"
    assert ops[1].diff is not None
    assert len(ops[1].diff.hunks) == 1


def test_codex_extract_file_operations_add_file():
    """Extract file creation from apply_patch with *** Add File."""
    normalizer = CodexV1Normalizer()

    event = {
        "event_id": "evt-codex-add",
        "tool_name": "apply_patch",
        "timestamp_ms": 1704067200000,
        "agent_type": "codex",
        "args": {
            "input": (
                "*** Begin Patch\n"
                "*** Add File: services/new_module.go\n"
                "@@\n"
                "+package services\n"
                "+\n"
                '+import "fmt"\n'
                "+\n"
                "+func New() {\n"
                '+\tfmt.Println("hello")\n'
                "+}\n"
                "@@\n"
                "*** End Patch\n"
            )
        },
    }

    ops = normalizer.extract_file_operations(event)
    assert len(ops) == 1
    assert ops[0].file_path == "services/new_module.go"
    assert ops[0].operation == "write"
    assert ops[0].diff is not None
    assert len(ops[0].diff.lines_added) == 7


def test_codex_extract_file_operations_exec_command():
    """extract_file_operations should also handle exec_command."""
    normalizer = CodexV1Normalizer()

    event = {
        "event_id": "evt-codex-exec",
        "tool_name": "exec_command",
        "timestamp_ms": 1704067200000,
        "agent_type": "codex",
        "args": {"cmd": "sed -i 's/old/new/g' src/utils.py"},
    }

    ops = normalizer.extract_file_operations(event)
    assert len(ops) == 1
    assert ops[0].file_path == "src/utils.py"
    assert ops[0].operation == "edit"


def test_codex_extract_diff_from_args_input():
    """extract_diff should find input in args (adapter format)."""
    normalizer = CodexV1Normalizer()

    event = {
        "tool_name": "apply_patch",
        "timestamp_ms": 1704067200000,
        "args": {
            "input": (
                "*** Begin Patch\n*** Update File: test.go\n@@\n-old\n+new\n@@\n*** End Patch\n"
            )
        },
    }

    diff = normalizer.extract_diff(event, session=None)
    assert diff is not None
    assert diff.format_source == "codex_apply_patch"
    assert diff.confidence == "high"


def test_codex_extract_skill_from_file_read():
    """Extract skill from SKILL.md file read via sed"""
    normalizer = CodexV1Normalizer()

    event = {
        "event_id": "evt-codex-skill",
        "tool_name": "exec_command",
        "timestamp_ms": 1704067200000,
        "agent_type": "codex",
        "args": {"cmd": "sed -n '1,200p' /Users/name/.codex/skills/gh-address-comments/SKILL.md"},
        "result": {
            "Output": (
                "---\\nname: gh-address-comments\\ndescription: Handle PR comments\\n---\\n..."
            )
        },
    }

    skill = normalizer.extract_skill(event)
    assert skill is not None
    assert skill.name == "gh-address-comments"
    assert skill.method == "file-read"
    assert skill.skill_type == "native"


def test_codex_extract_skill_from_superpowers_wrapper():
    """Extract skill from superpowers wrapper command"""
    normalizer = CodexV1Normalizer()

    event = {
        "event_id": "evt-codex-skill-2",
        "tool_name": "exec_command",
        "timestamp_ms": 1704067200000,
        "agent_type": "codex",
        "args": {
            "cmd": (
                "~/.codex/superpowers/.codex/superpowers-codex use-skill superpowers:brainstorming"
            )
        },
    }

    skill = normalizer.extract_skill(event)
    assert skill is not None
    assert skill.name == "superpowers:brainstorming"
    assert skill.skill_type == "superpowers"
