"""Tests for Gemini v1 Phase 2 extraction methods."""

import json
from datetime import UTC, datetime

from agentstream.normalization.adapters.gemini_v1 import GeminiV1Normalizer


def test_gemini_extract_session_metadata_from_first_entry():
    """Extract session metadata from first entry with all fields.

    Note: Gemini doesn't store session metadata like cwd/git_branch in source entries.
    This metadata comes from daemon_metadata which is collected during import.
    """
    normalizer = GeminiV1Normalizer()

    # Gemini format: entries are messages - model can be extracted from gemini-type entries
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "gemini",
                    "model": "gemini-2.0-flash-exp",
                    "content": "Hello",
                    "timestamp": "2024-01-01T00:00:00.000Z",
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    # For Gemini, all metadata except model comes from daemon_metadata
    daemon_metadata = {
        "cwd": "/Users/test/gemini-project",
        "agent_version": "2.1.0",
        "git_branch": "develop",
        "git_commit": "xyz789abc012",
        "git_repo": "https://github.com/user/gemini-test.git",
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    assert metadata.cwd == "/Users/test/gemini-project"
    assert metadata.agent_type == "gemini"
    assert metadata.agent_version == "2.1.0"
    assert metadata.git_branch == "develop"
    assert metadata.git_commit == "xyz789abc012"
    assert metadata.git_repo == "https://github.com/user/gemini-test.git"
    assert metadata.primary_model == "gemini-2.0-flash-exp"
    assert metadata.timestamp == datetime.fromtimestamp(1704067200000 / 1000, tz=UTC)


def test_gemini_extract_session_metadata_with_missing_fields():
    """Extract session metadata with some missing optional fields."""
    normalizer = GeminiV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "tool_name": "write_file",
                    "args": {"file_path": "new.py", "content": "test"},
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    metadata = normalizer.extract_session_metadata(source_entries, None)

    assert metadata is not None
    assert metadata.cwd is None
    assert metadata.git_branch is None
    assert metadata.agent_version is None
    assert metadata.primary_model == ""  # No model found, returns empty string


def test_gemini_extract_session_metadata_empty_entries():
    """Return None when source_entries is empty."""
    normalizer = GeminiV1Normalizer()

    metadata = normalizer.extract_session_metadata([], None)
    assert metadata is None


def test_gemini_extract_token_usage_from_response():
    """Extract token usage from Gemini API response metadata."""
    normalizer = GeminiV1Normalizer()

    source_entry = {
        "tool_name": "write_file",
        "response_metadata": {
            "usage_metadata": {
                "prompt_token_count": 1500,
                "candidates_token_count": 800,
                "total_token_count": 2300,
            }
        },
        "model": "gemini-2.0-flash-exp",
        "_timestamp_ms": 1704067200000,
    }

    usage_list = normalizer.extract_token_usage(source_entry)

    assert len(usage_list) == 1
    usage = usage_list[0]
    assert usage.input_tokens == 1500
    assert usage.output_tokens == 800
    assert usage.cache_read_tokens == 0  # Gemini doesn't expose cache details
    assert usage.cache_creation_tokens == 0
    assert usage.reasoning_tokens == 0
    assert usage.model == "gemini-2.0-flash-exp"
    assert usage.is_cumulative is False
    assert usage.timestamp == datetime.fromtimestamp(1704067200000 / 1000, tz=UTC)


def test_gemini_extract_token_usage_no_usage_metadata():
    """Return empty list when no usage metadata."""
    normalizer = GeminiV1Normalizer()

    source_entry = {
        "tool_name": "read_file",
        "args": {"file_path": "test.py"},
    }

    usage_list = normalizer.extract_token_usage(source_entry)
    assert usage_list == []


def test_gemini_extract_token_usage_missing_fields():
    """Handle missing token fields gracefully."""
    normalizer = GeminiV1Normalizer()

    source_entry = {
        "response_metadata": {
            "usage_metadata": {
                "prompt_token_count": 100,
                # candidates_token_count missing
            }
        },
        "_timestamp_ms": 1704067200000,
    }

    usage_list = normalizer.extract_token_usage(source_entry)
    assert len(usage_list) == 1
    assert usage_list[0].input_tokens == 100
    assert usage_list[0].output_tokens == 0  # Default to 0


def test_gemini_extract_error_from_api_error():
    """Extract error from Gemini API error response."""
    normalizer = GeminiV1Normalizer()

    source_entry = {
        "tool_name": "write_file",
        "error": {
            "code": 429,
            "message": "Resource has been exhausted (e.g. check quota).",
            "status": "RESOURCE_EXHAUSTED",
        },
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)

    assert error is not None
    assert error.error_type == "rate_limit"
    assert "Resource has been exhausted" in error.message
    assert error.timestamp == datetime.fromtimestamp(1704067200000 / 1000, tz=UTC)


def test_gemini_extract_error_from_tool_failure():
    """Extract error from tool execution failure."""
    normalizer = GeminiV1Normalizer()

    source_entry = {
        "tool_name": "read_file",
        "args": {"file_path": "missing.txt"},
        "result": {
            "error": "File not found: missing.txt",
            "success": False,
        },
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)

    assert error is not None
    assert error.error_type == "tool_call_error"
    assert "File not found" in error.message
    assert error.tool_name == "read_file"


def test_gemini_extract_error_from_timeout():
    """Extract timeout error."""
    normalizer = GeminiV1Normalizer()

    source_entry = {
        "tool_name": "write_file",
        "error": {
            "code": 504,
            "message": "Deadline exceeded",
            "status": "DEADLINE_EXCEEDED",
        },
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)

    assert error is not None
    assert error.error_type == "timeout"


def test_gemini_extract_error_from_context_length():
    """Extract context length error."""
    normalizer = GeminiV1Normalizer()

    source_entry = {
        "tool_name": "read_file",
        "error": {
            "code": 400,
            "message": "Request payload size exceeds the limit",
            "status": "INVALID_ARGUMENT",
        },
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)

    assert error is not None
    assert error.error_type == "context_length"


def test_gemini_extract_error_success_response():
    """Return None for successful response."""
    normalizer = GeminiV1Normalizer()

    source_entry = {
        "tool_name": "write_file",
        "result": {"success": True},
    }

    error = normalizer.extract_error(source_entry)
    assert error is None


def test_gemini_extract_compaction_returns_empty_list():
    """extract_compaction returns empty list (not yet implemented for Gemini)."""
    normalizer = GeminiV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "tool_name": "write_file",
                    "args": {"file_path": "test.py"},
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    compactions = normalizer.extract_compaction(source_entries)
    assert compactions == []


def test_gemini_model_from_source_entries_preferred_over_daemon_metadata():
    """Model from source entries should be preferred over daemon_metadata.

    Gemini source entries contain model info in "gemini" type messages.
    This should take precedence over the model in daemon_metadata.
    """
    normalizer = GeminiV1Normalizer()

    # Source entry has model "gemini-2.0-flash-exp"
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "gemini",
                    "model": "gemini-2.0-flash-exp",
                    "content": "Hello from source entry",
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    # daemon_metadata has a different model
    daemon_metadata = {
        "cwd": "/Users/test/project",
        "model": "gemini-1.5-pro",  # Different model in daemon
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    # Source entry model should be preferred
    assert metadata.primary_model == "gemini-2.0-flash-exp"


def test_gemini_extract_session_metadata_outside_git_repo():
    """Extract session metadata for a session run outside any git repository.

    Gemini sessions don't store cwd/git info in source entries - all metadata
    comes from daemon_metadata. When run outside a git repo, git fields are empty.
    """
    normalizer = GeminiV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "gemini",
                    "model": "gemini-2.0-flash-exp",
                    "content": "Hello",
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    # Daemon metadata for a session outside a git repo
    daemon_metadata = {
        "cwd": "/tmp/scratch-project",
        "agent_version": "2.1.0",
        "git_branch": "",  # Not in a git repo
        "git_commit": "",
        "git_repo": "",
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    assert metadata.cwd == "/tmp/scratch-project"
    assert metadata.agent_type == "gemini"
    assert metadata.agent_version == "2.1.0"
    # All git fields should be empty
    assert metadata.git_branch == ""
    assert metadata.git_commit == ""
    assert metadata.git_repo == ""
    assert metadata.primary_model == "gemini-2.0-flash-exp"


def test_gemini_metadata_requires_daemon_metadata_for_cwd_and_git():
    """Gemini source entries don't contain cwd/git info - daemon_metadata is required.

    Unlike Claude/Codex, Gemini sessions don't store working directory or git
    information in the session data. This must come from daemon_metadata.
    """
    normalizer = GeminiV1Normalizer()

    # Source entries with model but no cwd/git info (Gemini never has these)
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": "gemini",
                    "model": "gemini-2.0-flash-exp",
                    "content": "Hello",
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    # Without daemon_metadata, cwd/git fields are None
    metadata = normalizer.extract_session_metadata(source_entries, None)

    assert metadata is not None
    assert metadata.cwd is None
    assert metadata.git_branch is None
    assert metadata.git_commit is None
    assert metadata.git_repo is None
    assert metadata.agent_version is None
    # Model CAN be extracted from source entries
    assert metadata.primary_model == "gemini-2.0-flash-exp"
