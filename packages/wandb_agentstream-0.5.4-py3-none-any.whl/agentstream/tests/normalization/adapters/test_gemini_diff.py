"""Test Gemini diff extraction with FileSystemState."""

from pathlib import Path

import pytest

from agentstream.normalization import FileSystemState
from agentstream.normalization.adapters import GeminiV1Normalizer

# Load test fixtures
FIXTURES_DIR = Path(__file__).parent / "fixtures"
REPO_FILTERING_ORIGINAL = (FIXTURES_DIR / "gemini_repo_filtering_original.md").read_text()
REPO_FILTERING_EDITED = (FIXTURES_DIR / "gemini_repo_filtering_before.md").read_text()
SESSION_ANALYSIS_CONTENT = (FIXTURES_DIR / "gemini_session_analysis.md").read_text()


def test_gemini_write_file_create():
    """Test that write_file for new file creates all-additions diff."""
    normalizer = GeminiV1Normalizer()
    state = FileSystemState()

    # Simulate creating a new file (docs/features/automated-session-analysis.md)
    event = {
        "tool_name": "write_file",
        "args": {
            "file_path": "docs/features/automated-session-analysis.md",
            "content": SESSION_ANALYSIS_CONTENT,
        },
        "result": {
            "output": (
                "Successfully created and wrote to new file: "
                "/Users/vanpelt/Development/agentstream-py/docs/features/automated-session-analysis.md."
            )
        },
        "timestamp_ms": 1768511657188,
    }

    diff = normalizer.extract_diff(event, state)

    assert diff is not None
    assert diff.confidence == "medium"
    assert diff.format_source == "computed"
    assert len(diff.hunks) > 0

    # All lines should be additions (140 lines in the file)
    assert len(diff.lines_added) == 140

    # State should now have the content
    assert state.has_content("docs/features/automated-session-analysis.md")
    assert (
        state.get_content("docs/features/automated-session-analysis.md") == SESSION_ANALYSIS_CONTENT
    )


def test_gemini_write_file_edit_with_state():
    """Test that write_file edit computes diff from state."""
    normalizer = GeminiV1Normalizer()
    state = FileSystemState()

    # First, populate state with original content (simulating a previous read)
    state.set_content("docs/features/repository-filtering.md", REPO_FILTERING_ORIGINAL)

    # Now simulate editing the file
    event = {
        "tool_name": "write_file",
        "args": {
            "file_path": "docs/features/repository-filtering.md",
            "content": REPO_FILTERING_EDITED,
        },
        "result": {
            "output": (
                "Successfully overwrote file: "
                "/Users/vanpelt/Development/agentstream-py/docs/features/repository-filtering.md."
            )
        },
        "timestamp_ms": 1768511597730,
    }

    diff = normalizer.extract_diff(event, state)

    assert diff is not None
    assert diff.confidence == "medium"
    assert diff.format_source == "computed"
    assert len(diff.hunks) > 0

    # Should have both additions and context
    # The file went from 40 lines to 62 lines (22 net additions)
    assert len(diff.lines_added) > 20

    # State should be updated with new content
    assert state.get_content("docs/features/repository-filtering.md") == REPO_FILTERING_EDITED


def test_gemini_write_file_edit_without_state():
    """Test that write_file edit without prior state stores content but returns None."""
    normalizer = GeminiV1Normalizer()
    state = FileSystemState()

    # Edit without prior state
    event = {
        "tool_name": "write_file",
        "args": {
            "file_path": "docs/features/repository-filtering.md",
            "content": REPO_FILTERING_EDITED,
        },
        "result": {
            "output": (
                "Successfully overwrote file: "
                "/Users/vanpelt/Development/agentstream-py/docs/features/repository-filtering.md."
            )
        },
        "timestamp_ms": 1768511597730,
    }

    diff = normalizer.extract_diff(event, state)

    # Should return None since we don't have old content
    assert diff is None

    # But state should now have the content for future diffs
    assert state.has_content("docs/features/repository-filtering.md")
    assert state.get_content("docs/features/repository-filtering.md") == REPO_FILTERING_EDITED


def test_gemini_read_file_populates_state():
    """Test that read_file would populate state (though Gemini usually has empty results)."""
    normalizer = GeminiV1Normalizer()
    state = FileSystemState()

    event = {
        "tool_name": "read_file",
        "args": {
            "file_path": "docs/features/repository-filtering.md",
        },
        "result": {},  # Gemini often has empty result
        "timestamp_ms": 1768511615244,
    }

    # Read operations should return None (no diff)
    diff = normalizer.extract_diff(event, state)
    assert diff is None


def test_gemini_multiple_edits_sequence():
    """Test multiple edits in sequence build correct diffs."""
    normalizer = GeminiV1Normalizer()
    state = FileSystemState()

    # Create a file
    create_event = {
        "tool_name": "write_file",
        "args": {
            "file_path": "test.md",
            "content": "# Title\n\nOriginal content.\n",
        },
        "result": {"output": "Successfully created and wrote to new file: test.md."},
        "timestamp_ms": 1000,
    }

    diff1 = normalizer.extract_diff(create_event, state)
    assert diff1 is not None
    assert len(diff1.lines_added) == 3  # 3 lines added

    # Edit the file
    edit_event = {
        "tool_name": "write_file",
        "args": {
            "file_path": "test.md",
            "content": "# Title\n\nOriginal content.\n\nNew section.\n",
        },
        "result": {"output": "Successfully overwrote file: test.md."},
        "timestamp_ms": 2000,
    }

    diff2 = normalizer.extract_diff(edit_event, state)
    assert diff2 is not None
    # Should have 2 new lines added (blank line + "New section.")
    assert len(diff2.lines_added) >= 2


def test_gemini_diff_hunk_structure():
    """Test that diff hunks are properly structured."""
    normalizer = GeminiV1Normalizer()
    state = FileSystemState()

    old_content = "line 1\nline 2\nline 3\n"
    new_content = "line 1\nline 2 modified\nline 3\nline 4\n"

    state.set_content("test.txt", old_content)

    event = {
        "tool_name": "write_file",
        "args": {
            "file_path": "test.txt",
            "content": new_content,
        },
        "result": {"output": "Successfully overwrote file: test.txt."},
        "timestamp_ms": 1000,
    }

    diff = normalizer.extract_diff(event, state)

    assert diff is not None
    assert len(diff.hunks) > 0

    # Check hunk structure
    hunk = diff.hunks[0]
    assert hunk.old_start > 0
    assert hunk.new_start > 0
    assert len(hunk.lines) > 0

    # Should have both additions and context lines
    has_addition = any(line.startswith("+") for line in hunk.lines)
    has_deletion = any(line.startswith("-") for line in hunk.lines)
    has_context = any(not line.startswith(("+", "-")) for line in hunk.lines)

    assert has_addition
    assert has_deletion or has_context  # Should have at least one


def test_gemini_file_state_independence():
    """Test that FileSystemState properly isolates different files."""
    normalizer = GeminiV1Normalizer()
    state = FileSystemState()

    # Create two different files
    event1 = {
        "tool_name": "write_file",
        "args": {"file_path": "file1.md", "content": "content 1\n"},
        "result": {"output": "Successfully created and wrote to new file: file1.md."},
        "timestamp_ms": 1000,
    }

    event2 = {
        "tool_name": "write_file",
        "args": {"file_path": "file2.md", "content": "content 2\n"},
        "result": {"output": "Successfully created and wrote to new file: file2.md."},
        "timestamp_ms": 2000,
    }

    normalizer.extract_diff(event1, state)
    normalizer.extract_diff(event2, state)

    assert state.get_content("file1.md") == "content 1\n"
    assert state.get_content("file2.md") == "content 2\n"
    assert "file1.md" in state
    assert "file2.md" in state
    assert len(state) == 2


def test_gemini_real_session_edit():
    """Test with real Gemini session data - repository-filtering.md edit."""
    normalizer = GeminiV1Normalizer()
    state = FileSystemState()

    # Simulate the real sequence from the Gemini session:
    # 1. File was edited (we simulate having the original in state)
    state.set_content("docs/features/repository-filtering.md", REPO_FILTERING_ORIGINAL)

    # 2. Gemini writes the edited version
    event = {
        "tool_name": "write_file",
        "args": {
            "file_path": "docs/features/repository-filtering.md",
            "content": REPO_FILTERING_EDITED,
        },
        "result": {
            "output": (
                "Successfully overwrote file: "
                "/Users/vanpelt/Development/agentstream-py/docs/features/repository-filtering.md."
            )
        },
        "timestamp_ms": 1768511597730,
    }

    diff = normalizer.extract_diff(event, state)

    assert diff is not None
    assert diff.confidence == "medium"
    assert diff.format_source == "computed"

    # The real edit added 22 net lines (40 -> 62)
    # But there were also modifications, so total additions is higher
    assert len(diff.lines_added) >= 22

    # Verify the diff contains expected changes
    all_lines = []
    for hunk in diff.hunks:
        all_lines.extend(hunk.lines)

    diff_text = "\n".join(all_lines)

    # Check for some key additions from the real edit
    assert "## Overview" in diff_text
    assert "powerful feature" in diff_text
    assert "## Key Features" in diff_text


def test_gemini_real_session_create():
    """Test with real Gemini session data - automated-session-analysis.md creation."""
    normalizer = GeminiV1Normalizer()
    state = FileSystemState()

    # Gemini creates a new file
    event = {
        "tool_name": "write_file",
        "args": {
            "file_path": "docs/features/automated-session-analysis.md",
            "content": SESSION_ANALYSIS_CONTENT,
        },
        "result": {
            "output": (
                "Successfully created and wrote to new file: "
                "/Users/vanpelt/Development/agentstream-py/docs/features/automated-session-analysis.md."
            )
        },
        "timestamp_ms": 1768511657188,
    }

    diff = normalizer.extract_diff(event, state)

    assert diff is not None
    assert diff.format_source == "computed"
    assert diff.confidence == "medium"

    # New file - all lines are additions
    assert len(diff.lines_added) == 140

    # Verify content
    all_lines = []
    for hunk in diff.hunks:
        all_lines.extend(hunk.lines)

    # All lines should start with '+' (additions)
    addition_lines = [line for line in all_lines if line.startswith("+")]
    assert len(addition_lines) == 140

    # Check for key content
    diff_text = "\n".join(all_lines)
    assert "Automated Session Summarization" in diff_text
    assert "AI-Generated Summaries" in diff_text


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
