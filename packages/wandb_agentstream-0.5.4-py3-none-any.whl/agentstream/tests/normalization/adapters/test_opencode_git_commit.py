"""Tests for OpenCode normalizer git commit and PR extraction."""

import pytest

from agentstream.normalization.adapters.opencode_v1 import OpenCodeV1Normalizer


@pytest.fixture
def normalizer():
    return OpenCodeV1Normalizer()


def _make_event(
    command: str,
    result="",
    *,
    timestamp_ms: int = 1000000000000,
):
    event = {
        "tool_name": "bash",
        "args": {"command": command},
        "timestamp_ms": timestamp_ms,
        "event_id": "evt_opencode",
    }
    if result != "":
        event["result"] = result
    return event


class TestOpenCodeGitCommitExtraction:
    def test_commit_with_output(self, normalizer):
        git_state = {"branch": None}
        event = _make_event(
            'git commit -m "instructions, pt 1"',
            "[main 7ca2f3d] instructions, pt 1\n 1 file changed, 2 insertions(+)",
        )
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "main"
        assert commit.commit_hash == "7ca2f3d"
        assert commit.message == "instructions, pt 1"
        assert commit.agent_type == "opencode"
        assert commit.source_tool == "bash"

    def test_commit_with_dict_result(self, normalizer):
        git_state = {"branch": None}
        event = _make_event(
            'git commit -m "dict output"',
            {"output": "[feature abc1234] dict output\n 1 file changed"},
        )
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "feature"
        assert commit.commit_hash == "abc1234"

    def test_checkout_updates_branch_state(self, normalizer):
        git_state = {"branch": None}
        event = _make_event(
            "git checkout -b oc-feature",
            "Switched to a new branch 'oc-feature'",
        )
        result = normalizer.extract_git_commit(event, git_state)
        assert result is None
        assert git_state["branch"] == "oc-feature"

    def test_commit_uses_tracked_branch(self, normalizer):
        git_state = {"branch": None}

        # Checkout first
        normalizer.extract_git_commit(
            _make_event("git checkout -b my-branch", "Switched to a new branch 'my-branch'"),
            git_state,
        )
        assert git_state["branch"] == "my-branch"

        # Then commit without branch in output
        commit = normalizer.extract_git_commit(
            _make_event('git commit -m "work"'),
            git_state,
        )
        assert commit is not None
        assert commit.branch == "my-branch"

    def test_non_git_bash_returns_none(self, normalizer):
        git_state = {"branch": None}
        event = _make_event("ls -la", "total 42\ndrwxr-xr-x ...")
        result = normalizer.extract_git_commit(event, git_state)
        assert result is None

    def test_commit_without_output(self, normalizer):
        """Falls back to 'unknown' with no output and no tracked state."""
        git_state = {"branch": None}
        event = _make_event('git commit -m "no output"')
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "unknown"
        assert commit.commit_hash is None

    def test_non_bash_tool_ignored(self, normalizer):
        git_state = {"branch": None}
        event = {
            "tool_name": "edit",
            "args": {"command": 'git commit -m "nope"'},
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        result = normalizer.extract_git_commit(event, git_state)
        assert result is None

    def test_production_event_shape(self, normalizer):
        """Mirror exact production structure: bash with command and output."""
        git_state = {"branch": None}
        event = {
            "tool_name": "bash",
            "args": {"command": 'git commit -m "production shape"'},
            "result": "[main 7ca2f3d] production shape\n 1 file changed, 2 insertions(+)",
            "timestamp_ms": 1000000000000,
            "event_id": "evt_opencode_prod",
        }
        commit = normalizer.extract_git_commit(event, git_state)
        assert commit is not None
        assert commit.branch == "main"
        assert commit.commit_hash == "7ca2f3d"
        assert commit.message == "production shape"


class TestOpenCodePRExtraction:
    def test_pr_creation(self, normalizer):
        git_state = {"branch": "my-feature"}
        event = _make_event(
            'gh pr create --title "My PR" --body "description"',
            "https://github.com/org/repo/pull/42",
        )
        pr = normalizer.extract_pr(event, git_state)
        assert pr is not None
        assert pr.url == "https://github.com/org/repo/pull/42"
        assert pr.branch == "my-feature"
        assert pr.number == 42
        assert pr.title == "My PR"
        assert pr.agent_type == "opencode"

    def test_pr_no_url_in_output(self, normalizer):
        git_state = {"branch": "main"}
        event = _make_event(
            'gh pr create --title "test"',
            "Creating pull request...",
        )
        pr = normalizer.extract_pr(event, git_state)
        assert pr is None

    def test_non_pr_command_ignored(self, normalizer):
        git_state = {"branch": "main"}
        event = _make_event("gh pr list", "No open pull requests")
        pr = normalizer.extract_pr(event, git_state)
        assert pr is None
