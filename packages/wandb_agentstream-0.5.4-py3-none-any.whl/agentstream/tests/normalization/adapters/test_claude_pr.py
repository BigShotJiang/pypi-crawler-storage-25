"""Tests for Claude normalizer PR extraction."""

import pytest

from agentstream.normalization.adapters.claude_v1 import ClaudeV1Normalizer


@pytest.fixture
def normalizer():
    return ClaudeV1Normalizer()


def _make_bash_event(command: str, result="", *, timestamp_ms: int = 1000000000000):
    """Build a normalizer-format event for Claude Bash tool."""
    event = {
        "tool_name": "Bash",
        "args": {"command": command},
        "timestamp_ms": timestamp_ms,
        "event_id": "evt_test",
    }
    if result:
        event["result"] = result
    return event


class TestClaudePrExtraction:
    def test_pr_create_with_url(self, normalizer):
        git_state = {"branch": "feature-branch"}
        event = _make_bash_event(
            'gh pr create --title "Add feature" --body "Details"',
            result="https://github.com/org/repo/pull/42\n",
        )
        pr = normalizer.extract_pr(event, git_state)
        assert pr is not None
        assert pr.url == "https://github.com/org/repo/pull/42"
        assert pr.branch == "feature-branch"
        assert pr.number == 42
        assert pr.title == "Add feature"
        assert pr.agent_type == "claude"
        assert pr.source_tool == "Bash"

    def test_pr_create_multiline_output(self, normalizer):
        git_state = {"branch": "fix/bug"}
        event = _make_bash_event(
            'gh pr create --title "Fix bug"',
            result=(
                "Creating pull request for fix/bug into main in org/repo\n\n"
                "https://github.com/org/repo/pull/99\n"
            ),
        )
        pr = normalizer.extract_pr(event, git_state)
        assert pr is not None
        assert pr.url == "https://github.com/org/repo/pull/99"
        assert pr.number == 99
        assert pr.title == "Fix bug"

    def test_pr_create_no_url_in_output(self, normalizer):
        git_state = {"branch": "main"}
        event = _make_bash_event(
            "gh pr create",
            result="Error: pull request create failed",
        )
        pr = normalizer.extract_pr(event, git_state)
        assert pr is None

    def test_pr_create_no_output(self, normalizer):
        git_state = {"branch": "main"}
        event = _make_bash_event("gh pr create")
        pr = normalizer.extract_pr(event, git_state)
        assert pr is None

    def test_non_pr_command_ignored(self, normalizer):
        git_state = {"branch": "main"}
        event = _make_bash_event("gh pr list")
        pr = normalizer.extract_pr(event, git_state)
        assert pr is None

    def test_git_push_ignored(self, normalizer):
        git_state = {"branch": "main"}
        event = _make_bash_event(
            "git push origin main",
            result="remote: Create a pull request: https://github.com/org/repo/pull/new/main",
        )
        pr = normalizer.extract_pr(event, git_state)
        assert pr is None

    def test_non_bash_tool_ignored(self, normalizer):
        git_state = {"branch": "main"}
        event = {
            "tool_name": "Read",
            "args": {"file_path": "/some/file"},
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        pr = normalizer.extract_pr(event, git_state)
        assert pr is None

    def test_branch_from_git_state(self, normalizer):
        git_state = {"branch": "feat/pr-extraction"}
        event = _make_bash_event(
            "gh pr create",
            result="https://github.com/org/repo/pull/7\n",
        )
        pr = normalizer.extract_pr(event, git_state)
        assert pr is not None
        assert pr.branch == "feat/pr-extraction"

    def test_unknown_branch_when_no_state(self, normalizer):
        git_state = {"branch": None}
        event = _make_bash_event(
            "gh pr create",
            result="https://github.com/org/repo/pull/1\n",
        )
        pr = normalizer.extract_pr(event, git_state)
        assert pr is not None
        assert pr.branch == "unknown"

    def test_no_title_flag(self, normalizer):
        git_state = {"branch": "main"}
        event = _make_bash_event(
            "gh pr create",
            result="https://github.com/org/repo/pull/5\n",
        )
        pr = normalizer.extract_pr(event, git_state)
        assert pr is not None
        assert pr.title is None

    def test_result_as_dict(self, normalizer):
        """Claude result may be a dict with 'content' key."""
        git_state = {"branch": "main"}
        event = {
            "tool_name": "Bash",
            "args": {"command": "gh pr create"},
            "result": {"content": "https://github.com/org/repo/pull/10\n"},
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        pr = normalizer.extract_pr(event, git_state)
        assert pr is not None
        assert pr.url == "https://github.com/org/repo/pull/10"

    def test_pr_create_with_heredoc_body(self, normalizer):
        git_state = {"branch": "feat/big-change"}
        cmd = """gh pr create --title "Big feature" --body "$(cat <<'EOF'
## Summary
- Added stuff

## Test plan
- [x] Unit tests
EOF
)"
"""
        event = _make_bash_event(
            cmd,
            result="https://github.com/org/repo/pull/200\n",
        )
        pr = normalizer.extract_pr(event, git_state)
        assert pr is not None
        assert pr.url == "https://github.com/org/repo/pull/200"
        assert pr.title == "Big feature"
        assert pr.number == 200
