"""Tests for shared git command parsing patterns."""

from agentstream.normalization.adapters.git_patterns import (
    is_git_commit_command,
    is_pr_create_command,
    parse_branch_from_command,
    parse_branch_from_output,
    parse_commit_output,
    parse_pr_number_from_url,
    parse_pr_title_from_command,
    parse_pr_url_from_output,
)


class TestParseBranchFromCommand:
    def test_checkout_branch(self):
        assert parse_branch_from_command("git checkout feature") == "feature"

    def test_checkout_new_branch(self):
        assert parse_branch_from_command("git checkout -b new-feature") == "new-feature"

    def test_checkout_B_flag(self):
        assert parse_branch_from_command("git checkout -B reset-branch") == "reset-branch"

    def test_switch_branch(self):
        assert parse_branch_from_command("git switch main") == "main"

    def test_switch_create_branch(self):
        assert parse_branch_from_command("git switch -c new-branch") == "new-branch"

    def test_worktree_add(self):
        assert parse_branch_from_command("git worktree add /tmp/wt feature") == "feature"

    def test_worktree_add_new_branch(self):
        assert parse_branch_from_command("git worktree add /tmp/wt -b new-branch") == "new-branch"

    def test_chained_commands(self):
        # Should pick up the first checkout in a chain
        assert parse_branch_from_command("git checkout main && git pull") == "main"

    def test_no_branch(self):
        assert parse_branch_from_command("git status") is None

    def test_non_git_command(self):
        assert parse_branch_from_command("echo hello") is None

    def test_checkout_file(self):
        # git checkout -- file.txt should NOT return "--" as a branch
        result = parse_branch_from_command("git checkout -- file.txt")
        assert result is None

    def test_checkout_with_extra_whitespace(self):
        assert parse_branch_from_command("git  checkout  feature") == "feature"


class TestParseBranchFromOutput:
    def test_switched_to_branch(self):
        assert parse_branch_from_output("Switched to branch 'main'") == "main"

    def test_switched_to_new_branch(self):
        assert parse_branch_from_output("Switched to a new branch 'feature-x'") == "feature-x"

    def test_no_switch_output(self):
        assert parse_branch_from_output("Already on 'main'") is None

    def test_with_ansi_codes(self):
        # ANSI codes around the message shouldn't match (branch in quotes is clean)
        output = "\x1b[0mSwitched to branch 'develop'\x1b[0m"
        assert parse_branch_from_output(output) == "develop"

    def test_multiline_output(self):
        output = "Some other text\nSwitched to branch 'release-1.0'\nMore text"
        assert parse_branch_from_output(output) == "release-1.0"


class TestIsGitCommitCommand:
    def test_simple_commit(self):
        assert is_git_commit_command("git commit -m 'fix bug'") is True

    def test_commit_amend(self):
        assert is_git_commit_command("git commit --amend") is True

    def test_commit_in_chain(self):
        assert is_git_commit_command("git add . && git commit -m 'done'") is True

    def test_not_commit(self):
        assert is_git_commit_command("git push origin main") is False

    def test_commit_substring(self):
        # "git committed" should NOT match (word boundary)
        assert is_git_commit_command("git committed") is False

    def test_no_git(self):
        assert is_git_commit_command("echo hello") is False


class TestParseCommitOutput:
    def test_standard_output(self):
        output = "[main abc1234] Fix the login bug"
        result = parse_commit_output(output)
        assert result == ("main", "abc1234", "Fix the login bug")

    def test_feature_branch(self):
        output = "[feature/auth 1a2b3c4] Add OAuth support"
        result = parse_commit_output(output)
        assert result == ("feature/auth", "1a2b3c4", "Add OAuth support")

    def test_multiline_output(self):
        output = "On branch main\n[main def5678] Update README\n 1 file changed"
        result = parse_commit_output(output)
        assert result == ("main", "def5678", "Update README")

    def test_no_commit_output(self):
        assert parse_commit_output("Aborting commit due to empty message.") is None

    def test_empty_output(self):
        assert parse_commit_output("") is None

    def test_root_commit(self):
        # First commit format: [(root-commit) abc1234] Initial commit
        # Regex matches (root-commit) as branch name, which is fine -
        # this edge case is handled by the normalizer ignoring unusual branch names
        output = "[(root-commit) abc1234] Initial commit"
        result = parse_commit_output(output)
        assert result == ("(root-commit)", "abc1234", "Initial commit")


class TestIsPrCreateCommand:
    def test_simple_pr_create(self):
        assert is_pr_create_command("gh pr create") is True

    def test_pr_create_with_flags(self):
        assert is_pr_create_command('gh pr create --title "Fix bug" --body "Details"') is True

    def test_pr_create_in_chain(self):
        assert is_pr_create_command('git push && gh pr create --title "test"') is True

    def test_pr_create_with_heredoc(self):
        cmd = """gh pr create --title "Big feature" --body "$(cat <<'EOF'
## Summary
- Added stuff
EOF
)"
"""
        assert is_pr_create_command(cmd) is True

    def test_not_pr_create(self):
        assert is_pr_create_command("gh pr list") is False

    def test_git_push_not_detected(self):
        assert is_pr_create_command("git push origin main") is False

    def test_pr_view_not_detected(self):
        assert is_pr_create_command("gh pr view 123") is False

    def test_no_gh_command(self):
        assert is_pr_create_command("echo hello") is False


class TestParsePrUrlFromOutput:
    def test_simple_url(self):
        output = "https://github.com/org/repo/pull/42"
        assert parse_pr_url_from_output(output) == "https://github.com/org/repo/pull/42"

    def test_url_in_multiline_output(self):
        output = """Creating pull request for feature-branch into main in org/repo

https://github.com/org/repo/pull/123
"""
        assert parse_pr_url_from_output(output) == "https://github.com/org/repo/pull/123"

    def test_url_with_status_lines(self):
        output = (
            "remote: \nremote: Create a pull request for 'feature' on GitHub by visiting:\n"
            "remote:   https://github.com/org/repo/pull/new/feature\n\n"
            "https://github.com/org/repo/pull/99\n"
        )
        assert parse_pr_url_from_output(output) == "https://github.com/org/repo/pull/99"

    def test_no_url(self):
        assert parse_pr_url_from_output("Error: could not create PR") is None

    def test_empty_output(self):
        assert parse_pr_url_from_output("") is None

    def test_non_github_url_not_matched(self):
        assert parse_pr_url_from_output("https://gitlab.com/org/repo/merge_requests/1") is None


class TestParsePrNumberFromUrl:
    def test_standard_url(self):
        assert parse_pr_number_from_url("https://github.com/org/repo/pull/42") == 42

    def test_large_number(self):
        assert parse_pr_number_from_url("https://github.com/org/repo/pull/9999") == 9999

    def test_invalid_url(self):
        assert parse_pr_number_from_url("https://github.com/org/repo") is None

    def test_empty_string(self):
        assert parse_pr_number_from_url("") is None


class TestParsePrTitleFromCommand:
    def test_double_quoted_title(self):
        cmd = 'gh pr create --title "Fix the login bug" --body "details"'
        assert parse_pr_title_from_command(cmd) == "Fix the login bug"

    def test_single_quoted_title(self):
        cmd = "gh pr create --title 'Add feature X'"
        assert parse_pr_title_from_command(cmd) == "Add feature X"

    def test_no_title_flag(self):
        cmd = "gh pr create"
        assert parse_pr_title_from_command(cmd) is None

    def test_title_with_special_chars(self):
        cmd = 'gh pr create --title "feat: add PR URL extraction (#87)"'
        assert parse_pr_title_from_command(cmd) == "feat: add PR URL extraction (#87)"
