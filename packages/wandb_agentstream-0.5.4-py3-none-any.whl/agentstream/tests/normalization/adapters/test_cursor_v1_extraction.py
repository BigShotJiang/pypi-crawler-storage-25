"""Tests for Cursor v1 Phase 2 extraction methods."""

import json
from datetime import UTC, datetime

from agentstream.normalization.adapters.cursor_v1 import CursorV1Normalizer


def test_cursor_extract_session_metadata_from_first_entry():
    """Extract session metadata from first entry with all fields.

    Note: Cursor doesn't store session metadata in source entries - it comes from
    daemon_metadata which is collected when the daemon imports the session.
    """
    normalizer = CursorV1Normalizer()

    # Cursor format: entries are tool calls - metadata comes from daemon
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "tool_name": "read_file_v2",
                    "args": {"targetFile": "src/main.ts"},
                    "timestamp_ms": 1704067200000,
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    # For Cursor, all metadata comes from daemon_metadata
    daemon_metadata = {
        "cwd": "/Users/test/cursor-workspace",
        "agent_version": "0.43.0",
        "git_branch": "main",
        "git_commit": "def456abc789",
        "git_repo": "https://github.com/user/cursor-workspace.git",
        "model": "claude-3-5-sonnet-20241022",
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    assert metadata.cwd == "/Users/test/cursor-workspace"
    assert metadata.agent_type == "cursor"
    assert metadata.agent_version == "0.43.0"
    assert metadata.git_branch == "main"
    assert metadata.git_commit == "def456abc789"
    assert metadata.git_repo == "https://github.com/user/cursor-workspace.git"
    assert metadata.primary_model == "claude-3-5-sonnet-20241022"
    assert metadata.timestamp == datetime.fromtimestamp(1704067200000 / 1000, tz=UTC)


def test_cursor_extract_session_metadata_with_missing_fields():
    """Extract session metadata with some missing optional fields.

    When no model can be detected from source entries or daemon_metadata,
    the normalizer falls back to "cursor" as the default model. This ensures
    sessions are still created even when model info is unavailable.
    """
    normalizer = CursorV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "tool_name": "write",
                    "args": {"relativeWorkspacePath": "test.ts"},
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    metadata = normalizer.extract_session_metadata(source_entries, None)

    assert metadata is not None
    assert metadata.cwd is None
    assert metadata.git_branch is None
    assert metadata.agent_version is None
    assert metadata.primary_model == "cursor"  # Falls back to "cursor" default


def test_cursor_extract_session_metadata_empty_entries():
    """Return None when source_entries is empty."""
    normalizer = CursorV1Normalizer()

    metadata = normalizer.extract_session_metadata([], None)
    assert metadata is None


def test_cursor_extract_token_usage_from_bubble():
    """Extract token usage from Cursor bubble metadata."""
    normalizer = CursorV1Normalizer()

    source_entry = {
        "tool_name": "write",
        "bubble_metadata": {
            "usage": {
                "input_tokens": 2000,
                "output_tokens": 1200,
                "cache_read_tokens": 500,
            }
        },
        "model": "claude-3-5-sonnet-20241022",
        "_timestamp_ms": 1704067200000,
    }

    usage_list = normalizer.extract_token_usage(source_entry)

    assert len(usage_list) == 1
    usage = usage_list[0]
    assert usage.input_tokens == 2000
    assert usage.output_tokens == 1200
    assert usage.cache_read_tokens == 500
    assert usage.cache_creation_tokens == 0
    assert usage.reasoning_tokens == 0
    assert usage.model == "claude-3-5-sonnet-20241022"
    assert usage.is_cumulative is False
    assert usage.timestamp == datetime.fromtimestamp(1704067200000 / 1000, tz=UTC)


def test_cursor_extract_token_usage_with_cache_creation():
    """Extract token usage including cache creation tokens."""
    normalizer = CursorV1Normalizer()

    source_entry = {
        "bubble_metadata": {
            "usage": {
                "input_tokens": 1000,
                "output_tokens": 500,
                "cache_creation_tokens": 800,
            }
        },
        "_timestamp_ms": 1704067200000,
    }

    usage_list = normalizer.extract_token_usage(source_entry)

    assert len(usage_list) == 1
    assert usage_list[0].cache_creation_tokens == 800


def test_cursor_extract_token_usage_no_usage_metadata():
    """Return empty list when no usage metadata."""
    normalizer = CursorV1Normalizer()

    source_entry = {
        "tool_name": "read_file_v2",
        "args": {"targetFile": "test.ts"},
    }

    usage_list = normalizer.extract_token_usage(source_entry)
    assert usage_list == []


def test_cursor_extract_token_usage_missing_fields():
    """Handle missing token fields gracefully."""
    normalizer = CursorV1Normalizer()

    source_entry = {
        "bubble_metadata": {
            "usage": {
                "input_tokens": 100,
                # output_tokens missing
            }
        },
        "_timestamp_ms": 1704067200000,
    }

    usage_list = normalizer.extract_token_usage(source_entry)
    assert len(usage_list) == 1
    assert usage_list[0].input_tokens == 100
    assert usage_list[0].output_tokens == 0


def test_cursor_extract_error_from_tool_failure():
    """Extract error from tool execution failure."""
    normalizer = CursorV1Normalizer()

    source_entry = {
        "tool_name": "read_file_v2",
        "args": {"targetFile": "missing.ts"},
        "error": "ENOENT: no such file or directory, open 'missing.ts'",
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)

    assert error is not None
    assert error.error_type == "tool_call_error"
    assert "ENOENT" in error.message
    assert error.tool_name == "read_file_v2"
    assert error.timestamp == datetime.fromtimestamp(1704067200000 / 1000, tz=UTC)


def test_cursor_extract_error_from_cancelled_operation():
    """Extract cancellation error."""
    normalizer = CursorV1Normalizer()

    source_entry = {
        "tool_name": "write",
        "bubble_metadata": {
            "cancelled": True,
        },
        "error": "Operation cancelled by user",
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)

    assert error is not None
    assert error.error_type == "cancellation"


def test_cursor_extract_error_from_rate_limit():
    """Extract rate limit error."""
    normalizer = CursorV1Normalizer()

    source_entry = {
        "tool_name": "search_replace",
        "error": "Rate limit exceeded. Please try again later.",
        "error_code": 429,
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)

    assert error is not None
    assert error.error_type == "rate_limit"


def test_cursor_extract_error_from_context_length():
    """Extract context length error."""
    normalizer = CursorV1Normalizer()

    source_entry = {
        "tool_name": "write",
        "error": "Context window exceeded: input too large",
        "_timestamp_ms": 1704067200000,
    }

    error = normalizer.extract_error(source_entry)

    assert error is not None
    assert error.error_type == "context_length"


def test_cursor_extract_error_success_response():
    """Return None for successful response."""
    normalizer = CursorV1Normalizer()

    source_entry = {
        "tool_name": "write",
        "result": {"success": True},
    }

    error = normalizer.extract_error(source_entry)
    assert error is None


def test_cursor_extract_compaction_returns_empty_list():
    """extract_compaction returns empty list (not yet implemented for Cursor)."""
    normalizer = CursorV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "tool_name": "write",
                    "args": {"relativeWorkspacePath": "test.ts"},
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    compactions = normalizer.extract_compaction(source_entries)
    assert compactions == []


def test_cursor_model_from_source_entries_preferred_over_daemon_metadata():
    """Model from source entries should be preferred over daemon_metadata.

    Cursor bubbles contain model info that should take precedence over
    the model in daemon_metadata (which comes from composer metadata).
    """
    normalizer = CursorV1Normalizer()

    # Source entry (bubble) has model "gpt-4o"
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "tool_name": "write",
                    "args": {"relativeWorkspacePath": "test.ts"},
                    "model": "gpt-4o",  # Model in bubble
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    # daemon_metadata has a different model
    daemon_metadata = {
        "cwd": "/Users/test/project",
        "model": "claude-3-5-sonnet-20241022",  # Different model in daemon
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    # Source entry model should be preferred
    assert metadata.primary_model == "gpt-4o"


def test_cursor_extract_session_metadata_outside_git_repo():
    """Extract session metadata for a session run outside any git repository.

    Cursor sessions don't store cwd/git info in source entries - all metadata
    comes from daemon_metadata. When run outside a git repo, git fields are empty.
    """
    normalizer = CursorV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "tool_name": "write",
                    "args": {"relativeWorkspacePath": "test.ts"},
                    "model": "gpt-4o",
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    # Daemon metadata for a session outside a git repo
    daemon_metadata = {
        "cwd": "/tmp/scratch-project",
        "agent_version": "0.43.0",
        "git_branch": "",  # Not in a git repo
        "git_commit": "",
        "git_repo": "",
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    assert metadata.cwd == "/tmp/scratch-project"
    assert metadata.agent_type == "cursor"
    assert metadata.agent_version == "0.43.0"
    # All git fields should be empty
    assert metadata.git_branch == ""
    assert metadata.git_commit == ""
    assert metadata.git_repo == ""
    # Model comes from source entry
    assert metadata.primary_model == "gpt-4o"


def test_cursor_metadata_requires_daemon_metadata_for_cwd_and_git():
    """Cursor source entries don't contain cwd/git info - daemon_metadata is required.

    Unlike Claude/Codex, Cursor sessions don't store working directory or git
    information in the bubble data. This must come from daemon_metadata.
    """
    normalizer = CursorV1Normalizer()

    # Source entries with model but no cwd/git info (Cursor never has these in bubbles)
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "tool_name": "write",
                    "args": {"relativeWorkspacePath": "test.ts"},
                    "model": "gpt-4o",
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    # Without daemon_metadata, cwd/git fields are None
    metadata = normalizer.extract_session_metadata(source_entries, None)

    assert metadata is not None
    assert metadata.cwd is None
    assert metadata.git_branch is None
    assert metadata.git_commit is None
    assert metadata.git_repo is None
    assert metadata.agent_version is None
    # Model CAN be extracted from source entries
    assert metadata.primary_model == "gpt-4o"


def test_cursor_falls_back_to_daemon_model_when_not_in_source():
    """Fall back to daemon_metadata model when source entries don't have it.

    If bubbles don't have a model field, use the model from daemon_metadata.
    """
    normalizer = CursorV1Normalizer()

    # Source entry without model field
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "tool_name": "read_file_v2",
                    "args": {"targetFile": "test.ts"},
                    # No model field
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    daemon_metadata = {
        "cwd": "/Users/test/project",
        "model": "claude-3-5-sonnet-20241022",
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    # Should fall back to daemon_metadata model
    assert metadata.primary_model == "claude-3-5-sonnet-20241022"


def test_cursor_extracts_model_from_nested_model_info():
    """Extract model from nested modelInfo.modelName structure.

    Current Cursor format stores model in bubbles as:
    {"modelInfo": {"modelName": "claude-4.5-sonnet-thinking"}}

    This is the format used by type 1/2 bubbles (user/assistant messages).
    """
    normalizer = CursorV1Normalizer()

    # Real Cursor bubble structure with nested modelInfo
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": 1,  # User message bubble
                    "bubbleId": "abc-123",
                    "text": "Help me fix this bug",
                    "modelInfo": {"modelName": "claude-4.5-sonnet-thinking"},
                    "isAgentic": True,
                    "createdAt": "2026-01-15T20:05:24.604Z",
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    daemon_metadata = {
        "cwd": "/Users/test/project",
        "model": "different-model",  # Should be overridden by modelInfo
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    # Should extract from nested modelInfo.modelName
    assert metadata.primary_model == "claude-4.5-sonnet-thinking"


def test_cursor_model_info_preferred_over_top_level_model():
    """Nested modelInfo.modelName takes precedence over top-level model.

    If both are present, prefer the nested structure as it's more specific.
    """
    normalizer = CursorV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": 2,  # Assistant message bubble
                    "bubbleId": "xyz-789",
                    "model": "old-format-model",  # Top-level (older format)
                    "modelInfo": {"modelName": "new-format-model"},  # Nested (current)
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    metadata = normalizer.extract_session_metadata(source_entries, None)

    assert metadata is not None
    # Nested modelInfo.modelName should take precedence
    assert metadata.primary_model == "new-format-model"


def test_cursor_handles_empty_model_info():
    """Handle edge case where modelInfo exists but is empty or malformed."""
    normalizer = CursorV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": 1,
                    "modelInfo": {},  # Empty modelInfo
                    "model": "fallback-model",  # Should use this
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    metadata = normalizer.extract_session_metadata(source_entries, None)

    assert metadata is not None
    # Should fall back to top-level model when modelInfo.modelName is missing
    assert metadata.primary_model == "fallback-model"


def test_cursor_handles_non_dict_model_info():
    """Handle edge case where modelInfo is not a dict (malformed data)."""
    normalizer = CursorV1Normalizer()

    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "type": 1,
                    "modelInfo": "not-a-dict",  # Malformed
                    "model": "fallback-model",
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]

    metadata = normalizer.extract_session_metadata(source_entries, None)

    assert metadata is not None
    # Should fall back to top-level model when modelInfo is malformed
    assert metadata.primary_model == "fallback-model"


def test_cursor_falls_back_to_cursor_default_when_no_model_anywhere():
    """Fall back to 'cursor' as default model when no model info exists anywhere.

    Many Cursor sessions (especially older ones or certain workflows) don't store
    model information in the source entries at all, and daemon_metadata may also
    lack a model field. In these cases, we fall back to "cursor" as a sensible
    default to ensure sessions are still created.

    This was identified as a root cause for ~767 Cursor sessions not being
    processed - they had no modelInfo in any entry and no daemon model.
    """
    normalizer = CursorV1Normalizer()

    # Real-world Cursor entry structure without any model info
    # Based on actual data from source_entries table
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "_v": 3,
                    "type": 2,
                    "bubbleId": "abc-123",
                    "approximateLintErrors": [],
                    "lints": [],
                    "attachedCodeChunks": [],
                    "toolResults": [],
                    "isAgentic": False,
                    "createdAt": "2025-05-15T10:30:00.000Z",
                    # Note: NO modelInfo, NO model field
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        },
        {
            "entry_content": json.dumps(
                {
                    "_v": 3,
                    "type": 2,
                    "bubbleId": "def-456",
                    "toolResults": [],
                    # Still no model info
                }
            ),
            "entry_timestamp_ms": 1704067201000,
            "entry_index": 1,
        },
    ]

    # daemon_metadata also has no model
    daemon_metadata = {
        "agent_type": "cursor",
        "cwd": "/Users/test/project",
        "user_id": "usr_abc123",
        # Note: NO model field
    }

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)

    assert metadata is not None
    assert metadata.agent_type == "cursor"
    assert metadata.cwd == "/Users/test/project"
    # Should fall back to "cursor" as the default model
    assert metadata.primary_model == "cursor"


def test_cursor_model_detection_priority_order():
    """Verify the priority order for model detection.

    Priority order:
    1. modelInfo.modelName in source entries (newest format)
    2. model field in source entries (older format)
    3. model in daemon_metadata
    4. "cursor" as final fallback
    """
    normalizer = CursorV1Normalizer()

    # Test case 1: All sources have model - modelInfo should win
    source_entries = [
        {
            "entry_content": json.dumps(
                {
                    "modelInfo": {"modelName": "priority-1-model"},
                    "model": "priority-2-model",
                }
            ),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]
    daemon_metadata = {"model": "priority-3-model"}

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)
    assert metadata is not None
    assert metadata.primary_model == "priority-1-model"

    # Test case 2: No modelInfo, but has top-level model
    source_entries = [
        {
            "entry_content": json.dumps({"model": "priority-2-model"}),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]
    daemon_metadata = {"model": "priority-3-model"}

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)
    assert metadata is not None
    assert metadata.primary_model == "priority-2-model"

    # Test case 3: No model in entries, use daemon_metadata
    source_entries = [
        {
            "entry_content": json.dumps({"type": 2, "bubbleId": "abc"}),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]
    daemon_metadata = {"model": "priority-3-model"}

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)
    assert metadata is not None
    assert metadata.primary_model == "priority-3-model"

    # Test case 4: No model anywhere - fall back to "cursor"
    source_entries = [
        {
            "entry_content": json.dumps({"type": 2, "bubbleId": "abc"}),
            "entry_timestamp_ms": 1704067200000,
            "entry_index": 0,
        }
    ]
    daemon_metadata = {"cwd": "/test"}  # No model

    metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)
    assert metadata is not None
    assert metadata.primary_model == "cursor"


def test_cursor_extract_compaction_detects_server_bubble_id():
    """Detects compaction via serverBubbleId field.

    When Cursor compacts, it creates NEW bubbles with:
    - New bubbleId
    - serverBubbleId pointing to the original bubble's ID
    """
    normalizer = CursorV1Normalizer()

    base_ts = 1704067200000  # 2024-01-01 00:00:00

    # Original bubbles (no serverBubbleId)
    original_bubbles = []
    for i in range(5):
        ts_ms = base_ts + (i * 300000)  # 5 minutes apart
        ts_iso = datetime.fromtimestamp(ts_ms / 1000, tz=UTC).isoformat().replace("+00:00", "Z")
        original_bubbles.append(
            {
                "entry_content": json.dumps(
                    {
                        "type": 1 if i % 2 == 0 else 2,
                        "bubbleId": f"original-{i}",
                        "text": f"Original message {i}",
                        "createdAt": ts_iso,
                        # No serverBubbleId - this is an original bubble
                    }
                ),
                "entry_timestamp_ms": ts_ms,
                "entry_index": i,
            }
        )

    # Compacted bubbles (have serverBubbleId pointing to originals)
    compaction_base_ts = base_ts + 2000000  # Later in time
    compacted_bubbles = []
    for i in range(5):
        ts_ms = compaction_base_ts + (i * 100)  # All within ~500ms
        ts_iso = datetime.fromtimestamp(ts_ms / 1000, tz=UTC).isoformat().replace("+00:00", "Z")
        compacted_bubbles.append(
            {
                "entry_content": json.dumps(
                    {
                        "type": 1 if i % 2 == 0 else 2,
                        "bubbleId": f"compacted-{i}",  # New ID
                        "serverBubbleId": f"original-{i}",  # Points to original
                        "text": f"Original message {i}",  # Same content
                        "createdAt": ts_iso,
                    }
                ),
                "entry_timestamp_ms": ts_ms,
                "entry_index": 5 + i,
            }
        )

    source_entries = original_bubbles + compacted_bubbles

    compactions = normalizer.extract_compaction(source_entries)

    assert len(compactions) == 1
    assert compactions[0].compaction_type == "auto_summarization"
    assert compactions[0].messages_before == 5  # Original bubbles
    assert compactions[0].messages_after == 5  # Compacted bubbles


def test_cursor_extract_compaction_no_server_bubble_id():
    """Returns empty list when no bubbles have serverBubbleId."""
    normalizer = CursorV1Normalizer()

    # Normal bubbles without serverBubbleId - no compaction
    base_ts = 1704067200000
    source_entries = []
    for i in range(10):
        ts_ms = base_ts + (i * 100)  # 100ms apart
        ts_iso = datetime.fromtimestamp(ts_ms / 1000, tz=UTC).isoformat().replace("+00:00", "Z")
        source_entries.append(
            {
                "entry_content": json.dumps(
                    {
                        "type": 1,
                        "bubbleId": f"bubble-{i}",
                        "createdAt": ts_iso,
                        # No serverBubbleId
                    }
                ),
                "entry_timestamp_ms": ts_ms,
                "entry_index": i,
            }
        )

    compactions = normalizer.extract_compaction(source_entries)

    assert len(compactions) == 0


def test_cursor_extract_compaction_empty_entries():
    """Returns empty list for empty source entries."""
    normalizer = CursorV1Normalizer()

    compactions = normalizer.extract_compaction([])

    assert len(compactions) == 0


def test_cursor_extract_compaction_ignores_duplicate_bubble_ids():
    """Does not count duplicate bubbleIds multiple times.

    When the same bubbleId is sent multiple times (due to sync bugs),
    we should deduplicate.
    """
    normalizer = CursorV1Normalizer()

    base_ts = 1704067200000

    # Original bubbles (duplicated)
    source_entries = []
    for i in range(3):
        for _ in range(4):  # Duplicate each bubble 4 times
            ts_ms = base_ts + (i * 100)
            ts_iso = datetime.fromtimestamp(ts_ms / 1000, tz=UTC).isoformat().replace("+00:00", "Z")
            source_entries.append(
                {
                    "entry_content": json.dumps(
                        {
                            "type": 1,
                            "bubbleId": f"original-{i}",  # Same ID for duplicates
                            "createdAt": ts_iso,
                        }
                    ),
                    "entry_timestamp_ms": ts_ms,
                    "entry_index": len(source_entries),
                }
            )

    # Add compacted bubbles (also duplicated)
    compaction_ts = base_ts + 1000000
    for i in range(3):
        for _ in range(4):  # Duplicate each compacted bubble
            ts_ms = compaction_ts + (i * 100)
            ts_iso = datetime.fromtimestamp(ts_ms / 1000, tz=UTC).isoformat().replace("+00:00", "Z")
            source_entries.append(
                {
                    "entry_content": json.dumps(
                        {
                            "type": 1,
                            "bubbleId": f"compacted-{i}",  # Same ID for duplicates
                            "serverBubbleId": f"original-{i}",
                            "createdAt": ts_iso,
                        }
                    ),
                    "entry_timestamp_ms": ts_ms,
                    "entry_index": len(source_entries),
                }
            )

    compactions = normalizer.extract_compaction(source_entries)

    # Should detect compaction with deduplicated counts
    assert len(compactions) == 1
    assert compactions[0].messages_before == 3  # 3 unique originals
    assert compactions[0].messages_after == 3  # 3 unique compacted
