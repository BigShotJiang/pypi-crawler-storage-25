"""Tests for Claude diff extraction from Write/Create/Read tools."""

from agentstream.normalization.adapters.claude_v1 import ClaudeV1Normalizer
from agentstream.normalization.file_state import FileSystemState
from agentstream.normalization.processor import EventProcessor


class TestWriteNewFileDiff:
    """Test diff extraction for new file creation via Write tool."""

    def test_write_new_file_produces_all_additions_diff(self):
        normalizer = ClaudeV1Normalizer()
        state = FileSystemState()
        event = {
            "tool_name": "Write",
            "args": {"file_path": "src/new.py", "content": "line1\nline2\nline3"},
            "result": {"file_path": "src/new.py"},
        }
        diff = normalizer.extract_diff(event, state)

        assert diff is not None
        assert diff.format_source == "computed"
        assert diff.confidence == "medium"
        assert len(diff.hunks) == 1
        assert diff.hunks[0].old_count == 0
        # All lines should be additions
        addition_lines = [ln for ln in diff.hunks[0].lines if ln.startswith("+")]
        assert len(addition_lines) == 3
        assert len(diff.lines_added) == 3
        # State should be updated
        assert state.get_content("src/new.py") == "line1\nline2\nline3"

    def test_create_tool_produces_diff(self):
        """Create tool is in FILE_WRITE_TOOLS and should also produce diffs."""
        normalizer = ClaudeV1Normalizer()
        state = FileSystemState()
        event = {
            "tool_name": "Create",
            "args": {"file_path": "new.txt", "content": "hello\nworld"},
            "result": {},
        }
        diff = normalizer.extract_diff(event, state)

        assert diff is not None
        assert len(diff.lines_added) == 2

    def test_write_large_file(self):
        """Verify large file creation produces correct line count."""
        normalizer = ClaudeV1Normalizer()
        state = FileSystemState()
        content = "\n".join(f"line {i}" for i in range(409))
        event = {
            "tool_name": "Write",
            "args": {"file_path": "FilterParser.swift", "content": content},
            "result": {"file_path": "FilterParser.swift"},
        }
        diff = normalizer.extract_diff(event, state)

        assert diff is not None
        assert len(diff.lines_added) == 409

    def test_write_with_list_content_blocks(self):
        """Write tool may receive content as list of blocks (API format)."""
        normalizer = ClaudeV1Normalizer()
        state = FileSystemState()
        event = {
            "tool_name": "Write",
            "args": {
                "file_path": "x.py",
                "content": [{"text": "block1"}, {"text": "block2"}],
            },
            "result": {},
        }
        diff = normalizer.extract_diff(event, state)

        assert diff is not None
        # "block1\nblock2" is two lines
        assert len(diff.lines_added) == 2


class TestWriteOverwriteDiff:
    """Test diff extraction when Write overwrites an existing file."""

    def test_overwrite_with_prior_read_computes_delta(self):
        normalizer = ClaudeV1Normalizer()
        state = FileSystemState()

        # Simulate prior Read populating state
        read_event = {
            "tool_name": "Read",
            "args": {"file_path": "src/app.py"},
            "result": {
                "content": "     1\u2192old line 1\n     2\u2192old line 2\n     3\u2192old line 3"
            },
        }
        normalizer.extract_diff(read_event, state)
        assert state.get_content("src/app.py") == "old line 1\nold line 2\nold line 3"

        # Now Write with changes
        write_event = {
            "tool_name": "Write",
            "args": {
                "file_path": "src/app.py",
                "content": "old line 1\nnew line 2\nold line 3",
            },
            "result": {"file_path": "src/app.py"},
        }
        diff = normalizer.extract_diff(write_event, state)

        assert diff is not None
        # Should have both additions and deletions (delta diff)
        all_lines = [ln for h in diff.hunks for ln in h.lines]
        has_additions = any(ln.startswith("+") for ln in all_lines)
        has_deletions = any(ln.startswith("-") for ln in all_lines)
        assert has_additions
        assert has_deletions
        # State should be updated to new content
        assert state.get_content("src/app.py") == "old line 1\nnew line 2\nold line 3"

    def test_overwrite_without_prior_read_produces_all_additions(self):
        """When no prior read, overwrite is treated as new file (best effort)."""
        normalizer = ClaudeV1Normalizer()
        state = FileSystemState()
        event = {
            "tool_name": "Write",
            "args": {"file_path": "app.py", "content": "line1\nline2"},
            "result": {},
        }
        diff = normalizer.extract_diff(event, state)

        assert diff is not None
        # All lines should be additions since we have no prior content
        assert len(diff.lines_added) == 2

    def test_consecutive_writes_track_state(self):
        """Second Write should diff against the first Write's content."""
        normalizer = ClaudeV1Normalizer()
        state = FileSystemState()

        # First write creates file
        event1 = {
            "tool_name": "Write",
            "args": {"file_path": "f.py", "content": "aaa\nbbb\nccc"},
            "result": {},
        }
        diff1 = normalizer.extract_diff(event1, state)
        assert diff1 is not None
        assert len(diff1.lines_added) == 3

        # Second write overwrites with slightly different content
        event2 = {
            "tool_name": "Write",
            "args": {"file_path": "f.py", "content": "aaa\nBBB\nccc"},
            "result": {},
        }
        diff2 = normalizer.extract_diff(event2, state)
        assert diff2 is not None
        # Should be a delta: -bbb +BBB
        all_lines = [ln for h in diff2.hunks for ln in h.lines]
        additions = [ln for ln in all_lines if ln.startswith("+")]
        deletions = [ln for ln in all_lines if ln.startswith("-")]
        assert len(additions) == 1  # +BBB
        assert len(deletions) == 1  # -bbb


class TestEditStructuredPatchRegression:
    """Ensure existing Edit tool diff extraction is unchanged."""

    def test_edit_with_structured_patch(self):
        normalizer = ClaudeV1Normalizer()
        state = FileSystemState()
        event = {
            "tool_name": "Edit",
            "args": {"file_path": "app.py", "old_string": "old", "new_string": "new"},
            "result": {
                "structured_patch": {
                    "hunks": [
                        {
                            "old_start": 1,
                            "old_count": 1,
                            "new_start": 1,
                            "new_count": 1,
                            "lines": ["-old line", "+new line"],
                        }
                    ]
                }
            },
        }
        diff = normalizer.extract_diff(event, state)

        assert diff is not None
        assert diff.format_source == "structured_patch"
        assert diff.confidence == "high"
        assert len(diff.hunks) == 1
        assert len(diff.lines_added) == 1

    def test_edit_without_structured_patch_returns_none(self):
        """Edit tools without structured_patch should return None (no regression)."""
        normalizer = ClaudeV1Normalizer()
        event = {
            "tool_name": "Edit",
            "args": {"file_path": "app.py"},
            "result": {},
        }
        diff = normalizer.extract_diff(event, FileSystemState())
        assert diff is None


class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_write_missing_content_returns_none(self):
        normalizer = ClaudeV1Normalizer()
        event = {
            "tool_name": "Write",
            "args": {"file_path": "x.py"},
            "result": {},
        }
        assert normalizer.extract_diff(event, FileSystemState()) is None

    def test_write_empty_string_clears_file_produces_deletions(self):
        """Writing content: '' to a file with prior state should produce deletion diff."""
        normalizer = ClaudeV1Normalizer()
        state = FileSystemState()
        state.set_content("x.py", "old line 1\nold line 2")

        event = {
            "tool_name": "Write",
            "args": {"file_path": "x.py", "content": ""},
            "result": {},
        }
        diff = normalizer.extract_diff(event, state)

        assert diff is not None
        all_lines = [ln for h in diff.hunks for ln in h.lines]
        deletions = [ln for ln in all_lines if ln.startswith("-")]
        additions = [ln for ln in all_lines if ln.startswith("+")]
        assert len(deletions) == 2
        assert len(additions) == 0
        # State should be updated to empty
        assert state.get_content("x.py") == ""

    def test_write_empty_string_no_prior_state_returns_none(self):
        """Writing content: '' with no prior state produces no diff."""
        normalizer = ClaudeV1Normalizer()
        state = FileSystemState()
        event = {
            "tool_name": "Write",
            "args": {"file_path": "x.py", "content": ""},
            "result": {},
        }
        assert normalizer.extract_diff(event, state) is None

    def test_write_empty_list_blocks_clears_file(self):
        """Writing empty list-of-blocks content should produce deletion diff."""
        normalizer = ClaudeV1Normalizer()
        state = FileSystemState()
        state.set_content("x.py", "old content")

        event = {
            "tool_name": "Write",
            "args": {"file_path": "x.py", "content": [{"text": ""}]},
            "result": {},
        }
        diff = normalizer.extract_diff(event, state)

        assert diff is not None
        all_lines = [ln for h in diff.hunks for ln in h.lines]
        deletions = [ln for ln in all_lines if ln.startswith("-")]
        assert len(deletions) == 1

    def test_write_no_file_path_returns_none(self):
        normalizer = ClaudeV1Normalizer()
        event = {
            "tool_name": "Write",
            "args": {"content": "hello"},
            "result": {},
        }
        assert normalizer.extract_diff(event, FileSystemState()) is None

    def test_write_with_none_session(self):
        """When session is None, should still produce diff (no state tracking)."""
        normalizer = ClaudeV1Normalizer()
        event = {
            "tool_name": "Write",
            "args": {"file_path": "x.py", "content": "hello"},
            "result": {},
        }
        diff = normalizer.extract_diff(event, session=None)
        assert diff is not None
        assert len(diff.lines_added) == 1

    def test_read_populates_state(self):
        """Read tool should populate FileSystemState."""
        normalizer = ClaudeV1Normalizer()
        state = FileSystemState()
        event = {
            "tool_name": "Read",
            "args": {"file_path": "src/app.py"},
            "result": {"content": "     1\u2192first\n     2\u2192second"},
        }
        result = normalizer.extract_diff(event, state)

        assert result is None  # Read never produces a diff
        assert state.get_content("src/app.py") == "first\nsecond"

    def test_read_with_non_filestate_session(self):
        """Read with non-FileSystemState session should not crash."""
        normalizer = ClaudeV1Normalizer()
        event = {
            "tool_name": "Read",
            "args": {"file_path": "app.py"},
            "result": {"content": "     1\u2192hello"},
        }
        result = normalizer.extract_diff(event, session=None)
        assert result is None

    def test_unknown_tool_returns_none(self):
        normalizer = ClaudeV1Normalizer()
        event = {
            "tool_name": "Bash",
            "args": {"command": "ls"},
            "result": {},
        }
        assert normalizer.extract_diff(event, FileSystemState()) is None

    def test_result_is_string(self):
        """Result may be a string in some cases."""
        normalizer = ClaudeV1Normalizer()
        event = {
            "tool_name": "Edit",
            "args": {"file_path": "app.py"},
            "result": "some string result",
        }
        assert normalizer.extract_diff(event, FileSystemState()) is None


class TestEventProcessorIntegration:
    """Test that EventProcessor correctly attaches diffs from Write operations."""

    def test_processor_attaches_diff_to_write_file_op(self):
        processor = EventProcessor("claude", "1.0")
        events = [
            {
                "event_id": "e1",
                "tool_name": "Write",
                "timestamp_ms": 1704067200000,
                "args": {"file_path": "f.py", "content": "line1\nline2\nline3"},
                "result": {"file_path": "f.py"},
            }
        ]
        results = processor.process_events(events)

        # Find the UNIFIED_FILE_OPERATION event
        file_op_events = [e for e in results if e.name == "UNIFIED_FILE_OPERATION"]
        assert len(file_op_events) == 1

        value = file_op_events[0].value
        assert value["operation"] == "write"
        assert value["file_path"] == "f.py"
        # Diff should be attached
        assert "diff" in value
        assert value["diff"]["format_source"] == "computed"
        assert len(value["diff"]["hunks"]) == 1
        # All 3 lines should be additions
        hunk = value["diff"]["hunks"][0]
        additions = [ln for ln in hunk["lines"] if ln.startswith("+")]
        assert len(additions) == 3

    def test_processor_read_then_write_produces_delta_diff(self):
        """Read followed by Write should produce a delta diff, not all-additions."""
        processor = EventProcessor("claude", "1.0")
        events = [
            {
                "event_id": "e1",
                "tool_name": "Read",
                "timestamp_ms": 1704067200000,
                "args": {"file_path": "f.py"},
                "result": {"content": "     1\u2192aaa\n     2\u2192bbb"},
            },
            {
                "event_id": "e2",
                "tool_name": "Write",
                "timestamp_ms": 1704067201000,
                "args": {"file_path": "f.py", "content": "aaa\nCCC"},
                "result": {"file_path": "f.py"},
            },
        ]
        results = processor.process_events(events)

        # Should have read (no diff) and write (with delta diff)
        file_op_events = [e for e in results if e.name == "UNIFIED_FILE_OPERATION"]
        assert len(file_op_events) == 2

        write_event = [e for e in file_op_events if e.value["operation"] == "write"][0]
        diff = write_event.value["diff"]
        assert diff is not None
        # Should show bbb -> CCC change, not all-additions
        all_lines = [ln for h in diff["hunks"] for ln in h["lines"]]
        additions = [ln for ln in all_lines if ln.startswith("+")]
        deletions = [ln for ln in all_lines if ln.startswith("-")]
        assert len(additions) == 1  # +CCC
        assert len(deletions) == 1  # -bbb
