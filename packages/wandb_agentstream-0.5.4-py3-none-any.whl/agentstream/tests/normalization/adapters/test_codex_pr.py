"""Tests for Codex normalizer PR extraction."""

import pytest

from agentstream.normalization.adapters.codex_v1 import CodexV1Normalizer


@pytest.fixture
def normalizer():
    return CodexV1Normalizer()


def _make_exec_event(
    cmd: str,
    output: str = "",
    *,
    tool_name: str = "exec_command",
    timestamp_ms: int = 1000000000000,
):
    """Build a normalizer-format event for Codex shell tool."""
    event = {
        "tool_name": tool_name,
        "args": {"cmd": cmd},
        "timestamp_ms": timestamp_ms,
        "event_id": "evt_test",
    }
    if output:
        event["result"] = {"output": output}
    return event


class TestCodexPrExtraction:
    def test_pr_create_with_url(self, normalizer):
        git_state = {"branch": "feature-branch"}
        event = _make_exec_event(
            'gh pr create --title "Add feature"',
            output="https://github.com/org/repo/pull/42\n",
        )
        pr = normalizer.extract_pr(event, git_state)
        assert pr is not None
        assert pr.url == "https://github.com/org/repo/pull/42"
        assert pr.branch == "feature-branch"
        assert pr.number == 42
        assert pr.title == "Add feature"
        assert pr.agent_type == "codex"
        assert pr.source_tool == "exec_command"

    def test_fabricated_tool_names_rejected(self, normalizer):
        """Fabricated tool names like 'shell', 'shell_command' should be rejected."""
        git_state = {"branch": "main"}
        for tool_name in ("shell", "shell_command", "bash", "run_command"):
            event = _make_exec_event(
                "gh pr create",
                output="https://github.com/org/repo/pull/5\n",
                tool_name=tool_name,
            )
            assert normalizer.extract_pr(event, git_state) is None

    def test_pr_create_no_url_in_output(self, normalizer):
        git_state = {"branch": "main"}
        event = _make_exec_event(
            "gh pr create",
            output="Error: pull request create failed",
        )
        pr = normalizer.extract_pr(event, git_state)
        assert pr is None

    def test_non_pr_command_ignored(self, normalizer):
        git_state = {"branch": "main"}
        event = _make_exec_event("gh pr list")
        pr = normalizer.extract_pr(event, git_state)
        assert pr is None

    def test_non_shell_tool_ignored(self, normalizer):
        git_state = {"branch": "main"}
        event = {
            "tool_name": "update_plan",
            "args": {"plan": []},
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        pr = normalizer.extract_pr(event, git_state)
        assert pr is None

    def test_cmd_as_array(self, normalizer):
        git_state = {"branch": "main"}
        event = {
            "tool_name": "exec_command",
            "args": {"cmd": ["gh", "pr", "create"]},
            "result": {"output": "https://github.com/org/repo/pull/3\n"},
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        pr = normalizer.extract_pr(event, git_state)
        assert pr is not None
        assert pr.url == "https://github.com/org/repo/pull/3"

    def test_command_key_fallback(self, normalizer):
        git_state = {"branch": "main"}
        event = {
            "tool_name": "exec_command",
            "args": {"command": "gh pr create"},
            "result": {"output": "https://github.com/org/repo/pull/4\n"},
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        pr = normalizer.extract_pr(event, git_state)
        assert pr is not None

    def test_result_as_string(self, normalizer):
        git_state = {"branch": "main"}
        event = {
            "tool_name": "exec_command",
            "args": {"cmd": "gh pr create"},
            "result": "https://github.com/org/repo/pull/8\n",
            "timestamp_ms": 1000000000000,
            "event_id": "evt_test",
        }
        pr = normalizer.extract_pr(event, git_state)
        assert pr is not None
        assert pr.url == "https://github.com/org/repo/pull/8"

    def test_unknown_branch_when_no_state(self, normalizer):
        git_state = {"branch": None}
        event = _make_exec_event(
            "gh pr create",
            output="https://github.com/org/repo/pull/1\n",
        )
        pr = normalizer.extract_pr(event, git_state)
        assert pr is not None
        assert pr.branch == "unknown"
