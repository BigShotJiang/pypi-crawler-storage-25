"""Tests for OpenCode v1 normalizer."""

import json

from agentstream.normalization.adapters.opencode_v1 import OpenCodeV1Normalizer


class TestOpenCodeExtractTodo:
    """Tests for todo extraction."""

    def test_extract_todo_from_todowrite(self) -> None:
        """Extract todos from OpenCode todowrite tool."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-opencode-1",
            "tool_name": "todowrite",
            "timestamp_ms": 1704067200000,
            "agent_type": "opencode",
            "args": {
                "todos": [
                    {"id": "todo_1", "content": "Read the codebase", "status": "completed"},
                    {"id": "todo_2", "content": "Implement feature", "status": "in_progress"},
                    {"id": "todo_3", "content": "Write tests", "status": "pending"},
                ]
            },
        }

        todos = normalizer.extract_todo(event)
        assert todos is not None
        assert len(todos) == 3
        assert todos[0].content == "Read the codebase"
        assert todos[0].status == "completed"
        assert todos[0].id == "todo_1"
        assert todos[1].content == "Implement feature"
        assert todos[1].status == "in_progress"
        assert todos[2].content == "Write tests"
        assert todos[2].status == "pending"

    def test_extract_todo_returns_none_for_other_tools(self) -> None:
        """Should return None for non-todowrite tools."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "read",
            "timestamp_ms": 1704067200000,
            "args": {"filePath": "/test/file.py"},
        }

        todos = normalizer.extract_todo(event)
        assert todos is None

    def test_extract_todo_returns_none_for_empty_todos(self) -> None:
        """Should return None when todos list is empty."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "todowrite",
            "timestamp_ms": 1704067200000,
            "args": {"todos": []},
        }

        todos = normalizer.extract_todo(event)
        assert todos is None


class TestOpenCodeExtractFileOperation:
    """Tests for file operation extraction."""

    def test_extract_file_operation_from_read(self) -> None:
        """Extract read operation from read tool."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "read",
            "timestamp_ms": 1704067200000,
            "args": {"filePath": "/home/user/project/src/main.py"},
            "result": {"content": "print('hello')"},
        }

        file_op = normalizer.extract_file_operation(event)
        assert file_op is not None
        assert file_op.file_path == "/home/user/project/src/main.py"
        assert file_op.operation == "read"
        assert file_op.confidence == "high"

    def test_extract_file_operation_from_edit(self) -> None:
        """Extract edit operation from edit tool."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "edit",
            "timestamp_ms": 1704067200000,
            "args": {
                "filePath": "/home/user/project/src/utils.py",
                "oldString": "old code",
                "newString": "new code",
            },
        }

        file_op = normalizer.extract_file_operation(event)
        assert file_op is not None
        assert file_op.file_path == "/home/user/project/src/utils.py"
        assert file_op.operation == "edit"

    def test_extract_file_operation_from_write(self) -> None:
        """Extract write operation from write tool."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "write",
            "timestamp_ms": 1704067200000,
            "args": {
                "filePath": "/home/user/project/new_file.py",
                "content": "# New file content",
            },
        }

        file_op = normalizer.extract_file_operation(event)
        assert file_op is not None
        assert file_op.file_path == "/home/user/project/new_file.py"
        assert file_op.operation == "write"

    def test_extract_file_operation_from_grep(self) -> None:
        """Extract search operation from grep tool."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "grep",
            "timestamp_ms": 1704067200000,
            "args": {"pattern": "TODO", "path": "/home/user/project"},
        }

        file_op = normalizer.extract_file_operation(event)
        assert file_op is not None
        assert file_op.operation == "search"

    def test_extract_file_operation_from_glob(self) -> None:
        """Extract list operation from glob tool."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "glob",
            "timestamp_ms": 1704067200000,
            "args": {"pattern": "**/*.py", "path": "/home/user/project"},
        }

        file_op = normalizer.extract_file_operation(event)
        assert file_op is not None
        assert file_op.operation == "list"

    def test_extract_file_operation_from_bash_cat(self) -> None:
        """Extract read from bash cat command."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "bash",
            "timestamp_ms": 1704067200000,
            "args": {"command": "cat /home/user/project/README.md"},
        }

        file_op = normalizer.extract_file_operation(event)
        assert file_op is not None
        assert file_op.file_path == "/home/user/project/README.md"
        assert file_op.operation == "read"
        assert file_op.confidence == "medium"

    def test_extract_file_operation_from_bash_grep(self) -> None:
        """Extract search from bash grep command."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "bash",
            "timestamp_ms": 1704067200000,
            "args": {"command": "grep -r 'TODO' src/"},
        }

        file_op = normalizer.extract_file_operation(event)
        assert file_op is not None
        assert file_op.operation == "search"

    def test_extract_file_operation_returns_none_for_unrelated(self) -> None:
        """Should return None for unrelated tools."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "todoread",
            "timestamp_ms": 1704067200000,
            "args": {},
        }

        file_op = normalizer.extract_file_operation(event)
        assert file_op is None


class TestOpenCodeExtractSkill:
    """Tests for skill extraction."""

    def test_extract_skill_from_skill_tool(self) -> None:
        """Extract skill from skill tool."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "skill",
            "timestamp_ms": 1704067200000,
            "args": {"name": "code-reviewer"},
        }

        skill = normalizer.extract_skill(event)
        assert skill is not None
        assert skill.name == "code-reviewer"
        assert skill.method == "tool"
        assert skill.skill_type == "tool"

    def test_extract_skill_returns_none_for_other_tools(self) -> None:
        """Should return None for non-skill tools."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "read",
            "timestamp_ms": 1704067200000,
            "args": {"filePath": "/test.py"},
        }

        skill = normalizer.extract_skill(event)
        assert skill is None


class TestOpenCodeExtractDiff:
    """Tests for diff extraction."""

    def test_extract_diff_from_edit_with_patch(self) -> None:
        """Extract diff from edit tool with patch metadata."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "edit",
            "timestamp_ms": 1704067200000,
            "args": {
                "filePath": "/home/user/project/src/main.py",
                "oldString": "print('hello')",
                "newString": "print('Hello, World!')",
            },
            "result": {
                "metadata": {
                    "patch": {
                        "hunks": [
                            {
                                "old_start": 1,
                                "old_count": 1,
                                "new_start": 1,
                                "new_count": 1,
                                "lines": [
                                    "-print('hello')",
                                    "+print('Hello, World!')",
                                ],
                            }
                        ]
                    }
                }
            },
        }

        diff = normalizer.extract_diff(event, None)
        assert diff is not None
        assert len(diff.hunks) == 1
        assert diff.confidence == "high"
        assert diff.format_source == "opencode_patch"

    def test_extract_diff_from_old_new_strings(self) -> None:
        """Extract diff computed from old/new strings."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "edit",
            "timestamp_ms": 1704067200000,
            "args": {
                "filePath": "/home/user/project/src/main.py",
                "oldString": "line1\nline2\nline3",
                "newString": "line1\nmodified\nline3",
            },
            "result": {},
        }

        diff = normalizer.extract_diff(event, None)
        assert diff is not None
        assert diff.confidence == "medium"
        assert diff.format_source == "computed"

    def test_extract_diff_returns_none_for_read(self) -> None:
        """Should return None for read operations."""
        normalizer = OpenCodeV1Normalizer()

        event = {
            "event_id": "evt-1",
            "tool_name": "read",
            "timestamp_ms": 1704067200000,
            "args": {"filePath": "/test.py"},
        }

        diff = normalizer.extract_diff(event, None)
        assert diff is None


class TestOpenCodeExtractSessionMetadata:
    """Tests for session metadata extraction."""

    def test_extract_session_metadata(self) -> None:
        """Extract session metadata from source entries."""
        normalizer = OpenCodeV1Normalizer()

        source_entries = [
            {
                "entry_content": json.dumps(
                    {
                        "id": "ses_test",
                        "projectID": "proj_abc",
                        "directory": "/home/user/myproject",
                        "version": "1.0.0",
                        "time": {"created": 1704067200000},
                    }
                ),
                "entry_timestamp_ms": 1704067200000,
            },
            {
                "entry_content": json.dumps(
                    {
                        "id": "msg_asst",
                        "sessionID": "ses_test",
                        "role": "assistant",
                        "modelID": "claude-sonnet-4-20250514",
                        "providerID": "anthropic",
                        "time": {"created": 1704067201000},
                    }
                ),
                "entry_timestamp_ms": 1704067201000,
            },
        ]

        metadata = normalizer.extract_session_metadata(source_entries)
        assert metadata is not None
        assert metadata.cwd == "/home/user/myproject"
        assert metadata.agent_type == "opencode"
        assert metadata.agent_version == "1.0.0"
        assert metadata.primary_model == "anthropic/claude-sonnet-4-20250514"

    def test_extract_session_metadata_with_daemon_metadata(self) -> None:
        """Extract session metadata with daemon metadata."""
        normalizer = OpenCodeV1Normalizer()

        source_entries = [
            {
                "entry_content": json.dumps(
                    {
                        "id": "ses_test",
                        "projectID": "proj_abc",
                        "directory": "/home/user/myproject",
                        "time": {"created": 1704067200000},
                    }
                ),
                "entry_timestamp_ms": 1704067200000,
            },
        ]

        daemon_metadata = {
            "git_branch": "main",
            "git_commit": "abc123",
            "git_repo": "github.com/user/repo",
            "model": "anthropic/claude-opus-4",
        }

        metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata)
        assert metadata is not None
        assert metadata.git_branch == "main"
        assert metadata.git_commit == "abc123"
        assert metadata.git_repo == "github.com/user/repo"
        # Falls back to daemon metadata model when not in source entries
        assert metadata.primary_model == "anthropic/claude-opus-4"

    def test_extract_session_metadata_returns_none_for_empty(self) -> None:
        """Should return None for empty source entries."""
        normalizer = OpenCodeV1Normalizer()
        metadata = normalizer.extract_session_metadata([])
        assert metadata is None


class TestOpenCodeExtractTokenUsage:
    """Tests for token usage extraction."""

    def test_extract_token_usage_from_assistant_message(self) -> None:
        """Extract token usage from assistant message entry."""
        normalizer = OpenCodeV1Normalizer()

        source_entry = {
            "id": "msg_asst",
            "sessionID": "ses_test",
            "role": "assistant",
            "modelID": "claude-sonnet-4-20250514",
            "providerID": "anthropic",
            "tokens": {
                "input": 100,
                "output": 50,
                "reasoning": 10,
                "cache": {"read": 20, "write": 5},
            },
            "_timestamp_ms": 1704067200000,
        }

        usage_list = normalizer.extract_token_usage(source_entry)
        assert len(usage_list) == 1
        usage = usage_list[0]
        assert usage.input_tokens == 100
        assert usage.output_tokens == 50
        assert usage.reasoning_tokens == 10
        assert usage.cache_read_tokens == 20
        assert usage.cache_creation_tokens == 5
        assert usage.model == "anthropic/claude-sonnet-4-20250514"

    def test_extract_token_usage_returns_empty_for_user(self) -> None:
        """Should return empty list for user messages."""
        normalizer = OpenCodeV1Normalizer()

        source_entry = {
            "id": "msg_user",
            "sessionID": "ses_test",
            "role": "user",
        }

        usage_list = normalizer.extract_token_usage(source_entry)
        assert usage_list == []

    def test_extract_token_usage_returns_empty_for_no_tokens(self) -> None:
        """Should return empty list when no tokens field."""
        normalizer = OpenCodeV1Normalizer()

        source_entry = {
            "id": "msg_asst",
            "sessionID": "ses_test",
            "role": "assistant",
        }

        usage_list = normalizer.extract_token_usage(source_entry)
        assert usage_list == []


class TestOpenCodeExtractError:
    """Tests for error extraction."""

    def test_extract_error_from_assistant_message(self) -> None:
        """Extract error from assistant message with error field."""
        normalizer = OpenCodeV1Normalizer()

        source_entry = {
            "id": "msg_asst",
            "sessionID": "ses_test",
            "role": "assistant",
            "error": {
                "name": "RateLimitError",
                "message": "Rate limit exceeded. Please try again later.",
            },
            "_timestamp_ms": 1704067200000,
        }

        error = normalizer.extract_error(source_entry)
        assert error is not None
        assert error.error_type == "rate_limit"
        assert "Rate limit" in error.message

    def test_extract_error_api_error(self) -> None:
        """Extract API error type."""
        normalizer = OpenCodeV1Normalizer()

        source_entry = {
            "id": "msg_asst",
            "sessionID": "ses_test",
            "role": "assistant",
            "error": {
                "name": "APIError",
                "message": "API request failed",
            },
            "_timestamp_ms": 1704067200000,
        }

        error = normalizer.extract_error(source_entry)
        assert error is not None
        assert error.error_type == "api_error"

    def test_extract_error_auth_error(self) -> None:
        """Extract authentication error type."""
        normalizer = OpenCodeV1Normalizer()

        source_entry = {
            "id": "msg_asst",
            "sessionID": "ses_test",
            "role": "assistant",
            "error": {
                "name": "AuthenticationError",
                "message": "Invalid API key",
            },
            "_timestamp_ms": 1704067200000,
        }

        error = normalizer.extract_error(source_entry)
        assert error is not None
        assert error.error_type == "authentication"

    def test_extract_error_returns_none_for_user(self) -> None:
        """Should return None for user messages."""
        normalizer = OpenCodeV1Normalizer()

        source_entry = {
            "id": "msg_user",
            "sessionID": "ses_test",
            "role": "user",
        }

        error = normalizer.extract_error(source_entry)
        assert error is None

    def test_extract_error_returns_none_for_no_error(self) -> None:
        """Should return None when no error field."""
        normalizer = OpenCodeV1Normalizer()

        source_entry = {
            "id": "msg_asst",
            "sessionID": "ses_test",
            "role": "assistant",
        }

        error = normalizer.extract_error(source_entry)
        assert error is None


class TestOpenCodeExtractCompaction:
    """Tests for compaction event extraction."""

    def test_extract_compaction_from_compaction_part(self) -> None:
        """Extract compaction from compaction type part."""
        normalizer = OpenCodeV1Normalizer()

        source_entries = [
            {
                "entry_content": json.dumps(
                    {
                        "id": "part_compact",
                        "sessionID": "ses_test",
                        "messageID": "msg_asst",
                        "type": "compaction",
                        "auto": True,
                    }
                ),
                "entry_timestamp_ms": 1704067200000,
            }
        ]

        compactions = normalizer.extract_compaction(source_entries)
        assert len(compactions) == 1
        assert compactions[0].compaction_type == "auto_summarization"
        assert compactions[0].message_id == "msg_asst"

    def test_extract_compaction_manual(self) -> None:
        """Extract manual compaction event."""
        normalizer = OpenCodeV1Normalizer()

        source_entries = [
            {
                "entry_content": json.dumps(
                    {
                        "id": "part_compact",
                        "sessionID": "ses_test",
                        "messageID": "msg_asst",
                        "type": "compaction",
                        "auto": False,
                    }
                ),
                "entry_timestamp_ms": 1704067200000,
            }
        ]

        compactions = normalizer.extract_compaction(source_entries)
        assert len(compactions) == 1
        assert compactions[0].compaction_type == "manual"

    def test_extract_compaction_returns_empty_for_no_compaction(self) -> None:
        """Should return empty list when no compaction entries."""
        normalizer = OpenCodeV1Normalizer()

        source_entries = [
            {
                "entry_content": json.dumps(
                    {
                        "id": "part_text",
                        "sessionID": "ses_test",
                        "messageID": "msg_asst",
                        "type": "text",
                        "text": "Hello",
                    }
                ),
                "entry_timestamp_ms": 1704067200000,
            }
        ]

        compactions = normalizer.extract_compaction(source_entries)
        assert compactions == []
