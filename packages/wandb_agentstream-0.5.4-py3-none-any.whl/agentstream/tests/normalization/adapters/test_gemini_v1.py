"""Tests for Gemini v1.x normalizer."""

from agentstream.normalization.adapters.gemini_v1 import GeminiV1Normalizer


def test_gemini_extract_todo_from_write_todos():
    """Extract todos from Gemini write_todos tool"""
    normalizer = GeminiV1Normalizer()

    event = {
        "event_id": "evt-gemini-1",
        "tool_name": "write_todos",
        "timestamp_ms": 1704067200000,
        "agent_type": "gemini",
        "args": {
            "todos": [
                {"description": "Create database schema", "status": "completed"},
                {"description": "Write migration", "status": "pending"},
            ]
        },
    }

    todos = normalizer.extract_todo(event)
    assert todos is not None
    assert len(todos) == 2
    assert todos[0].content == "Create database schema"
    assert todos[0].status == "completed"
    assert todos[0].id is None  # Gemini doesn't provide IDs
    assert todos[1].content == "Write migration"


def test_gemini_extract_file_operation_replace():
    """Extract edit from replace tool"""
    normalizer = GeminiV1Normalizer()

    event = {
        "event_id": "evt-gemini-2",
        "tool_name": "replace",
        "timestamp_ms": 1704067200000,
        "agent_type": "gemini",
        "args": {
            "file_path": "src/api.py",
            "old_string": "return None",
            "new_string": "return data",
        },
        "result": "(1 replacement)",
    }

    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.file_path == "src/api.py"
    assert file_op.operation == "edit"
    assert file_op.confidence == "low"  # Only replacement count


def test_gemini_extract_file_operation_write():
    """Extract write from write_file tool"""
    normalizer = GeminiV1Normalizer()

    event = {
        "event_id": "evt-gemini-3",
        "tool_name": "write_file",
        "timestamp_ms": 1704067200000,
        "agent_type": "gemini",
        "args": {"file_path": "src/new.py", "content": "# New file"},
    }

    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.file_path == "src/new.py"
    assert file_op.operation == "write"


def test_gemini_extract_file_operation_read():
    """Extract read from read_file tool"""
    normalizer = GeminiV1Normalizer()

    event = {
        "event_id": "evt-gemini-4",
        "tool_name": "read_file",
        "timestamp_ms": 1704067200000,
        "agent_type": "gemini",
        "args": {"file_path": "src/config.py"},
    }

    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.file_path == "src/config.py"
    assert file_op.operation == "read"


def test_gemini_extract_skill_from_activate_skill():
    """Extract skill from activate_skill tool"""
    normalizer = GeminiV1Normalizer()

    event = {
        "event_id": "evt-gemini-skill",
        "tool_name": "activate_skill",
        "timestamp_ms": 1704067200000,
        "agent_type": "gemini",
        "args": {"name": "code-reviewer"},
        "result": "<skill_content>...</skill_content>",
    }

    skill = normalizer.extract_skill(event)
    assert skill is not None
    assert skill.name == "code-reviewer"
    assert skill.method == "tool"
    assert skill.skill_type == "tool"


def test_gemini_extract_skill_returns_none_for_non_skill():
    """Returns None for non-skill events"""
    normalizer = GeminiV1Normalizer()

    event = {"tool_name": "replace", "args": {"file_path": "test.py"}}

    assert normalizer.extract_skill(event) is None
