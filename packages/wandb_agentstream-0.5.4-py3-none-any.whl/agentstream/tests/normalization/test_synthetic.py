from datetime import datetime

from agentstream.events import CustomEvent
from agentstream.normalization.schemas import (
    CompactionEvent,
    ErrorEvent,
    SessionMetadata,
    TokenUsage,
    UnifiedFileOperation,
    UnifiedTodo,
)
from agentstream.normalization.synthetic import (
    COMPACTION_EVENT,
    ERROR_EVENT,
    SESSION_METADATA,
    TOKEN_USAGE,
    UNIFIED_FILE_OPERATION,
    UNIFIED_TODO_UPDATE,
    create_compaction_event,
    create_error_event,
    create_file_operation_event,
    create_session_metadata_event,
    create_todo_event,
    create_token_usage_event,
)


def test_create_todo_event():
    """Create CustomEvent from UnifiedTodo"""
    todo = UnifiedTodo(
        content="Fix bug",
        status="in_progress",
        id="todo-123",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
        source_tool="TodoWrite",
        agent_type="claude",
    )

    source_event = {"event_id": "evt-456", "tool_name": "TodoWrite"}

    event = create_todo_event(todo, source_event)

    assert isinstance(event, CustomEvent)
    assert event.name == UNIFIED_TODO_UPDATE
    assert event.timestamp_ms == int(todo.timestamp.timestamp() * 1000)
    assert event.value["content"] == "Fix bug"
    assert event.value["status"] == "in_progress"
    assert event.value["_source"]["event_id"] == "evt-456"


def test_create_file_operation_event():
    """Create CustomEvent from UnifiedFileOperation"""
    file_op = UnifiedFileOperation(
        file_path="src/auth.py",
        operation="edit",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
        diff=None,
        confidence="high",
        agent_type="claude",
        source_tool="Edit",
        source_event_id="evt-789",
    )

    source_event = {"event_id": "evt-789", "tool_name": "Edit"}

    event = create_file_operation_event(file_op, source_event)

    assert isinstance(event, CustomEvent)
    assert event.name == UNIFIED_FILE_OPERATION
    assert event.value["file_path"] == "src/auth.py"
    assert event.value["operation"] == "edit"
    assert event.value["confidence"] == "high"
    assert event.value["_source"]["tool"] == "Edit"


def test_create_session_metadata_event():
    """Create CustomEvent from SessionMetadata"""
    metadata = SessionMetadata(
        cwd="/Users/test/project",
        agent_type="claude",
        agent_version="1.5.0",
        git_branch="feature/test",
        git_commit="abc123",
        git_repo="https://github.com/test/repo",
        primary_model="claude-sonnet-4.5",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )

    event = create_session_metadata_event(metadata, message_id="msg-123")

    assert isinstance(event, CustomEvent)
    assert event.name == SESSION_METADATA
    assert event.value["_linked_message_id"] == "msg-123"
    assert event.timestamp_ms == int(metadata.timestamp.timestamp() * 1000)
    assert event.value["cwd"] == "/Users/test/project"
    assert event.value["agent_type"] == "claude"
    assert event.value["agent_version"] == "1.5.0"
    assert event.value["git_branch"] == "feature/test"
    assert event.value["git_commit"] == "abc123"
    assert event.value["git_repo"] == "https://github.com/test/repo"
    assert event.value["primary_model"] == "claude-sonnet-4.5"


def test_create_session_metadata_event_without_message_id():
    """Create SESSION_METADATA CustomEvent without message_id"""
    metadata = SessionMetadata(
        cwd=None,
        agent_type="codex",
        agent_version=None,
        git_branch=None,
        git_commit=None,
        git_repo=None,
        primary_model=None,
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )

    event = create_session_metadata_event(metadata)

    assert isinstance(event, CustomEvent)
    assert event.name == SESSION_METADATA
    assert "_linked_message_id" not in event.value
    assert event.value["cwd"] is None
    assert event.value["agent_type"] == "codex"


def test_create_token_usage_event():
    """Create CustomEvent from TokenUsage"""
    usage = TokenUsage(
        input_tokens=100,
        output_tokens=50,
        cache_read_tokens=25,
        cache_creation_tokens=10,
        reasoning_tokens=5,
        model="claude-sonnet-4.5",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
        is_cumulative=False,
    )

    event = create_token_usage_event(usage, message_id="msg-456")

    assert isinstance(event, CustomEvent)
    assert event.name == TOKEN_USAGE
    assert event.value["_linked_message_id"] == "msg-456"
    assert event.timestamp_ms == int(usage.timestamp.timestamp() * 1000)
    assert event.value["input_tokens"] == 100
    assert event.value["output_tokens"] == 50
    assert event.value["cache_read_tokens"] == 25
    assert event.value["cache_creation_tokens"] == 10
    assert event.value["reasoning_tokens"] == 5
    assert event.value["model"] == "claude-sonnet-4.5"
    assert event.value["is_cumulative"] is False


def test_create_token_usage_event_cumulative():
    """Create cumulative TOKEN_USAGE CustomEvent"""
    usage = TokenUsage(
        input_tokens=1000,
        output_tokens=500,
        model="gpt-4",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
        is_cumulative=True,
    )

    event = create_token_usage_event(usage)

    assert isinstance(event, CustomEvent)
    assert event.name == TOKEN_USAGE
    assert "_linked_message_id" not in event.value
    assert event.value["is_cumulative"] is True
    assert event.value["input_tokens"] == 1000


def test_create_error_event():
    """Create CustomEvent from ErrorEvent"""
    error = ErrorEvent(
        error_type="tool_call_error",
        message="Invalid file path",
        tool_name="Edit",
        tool_call_id="tool-123",
        details="File does not exist: /path/to/file.py",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )

    event = create_error_event(error, tool_call_id="tool-123")

    assert isinstance(event, CustomEvent)
    assert event.name == ERROR_EVENT
    assert event.value["_linked_tool_call_id"] == "tool-123"
    assert event.timestamp_ms == int(error.timestamp.timestamp() * 1000)
    assert event.value["error_type"] == "tool_call_error"
    assert event.value["message"] == "Invalid file path"
    assert event.value["tool_name"] == "Edit"
    assert event.value["tool_call_id"] == "tool-123"
    assert event.value["details"] == "File does not exist: /path/to/file.py"


def test_create_error_event_interruption():
    """Create ERROR_EVENT CustomEvent for interruption"""
    error = ErrorEvent(
        error_type="interruption",
        message="User interrupted execution",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )

    event = create_error_event(error)

    assert isinstance(event, CustomEvent)
    assert event.name == ERROR_EVENT
    assert "_linked_tool_call_id" not in event.value
    assert event.value["error_type"] == "interruption"
    assert event.value["tool_name"] is None


def test_create_compaction_event():
    """Create CustomEvent from CompactionEvent"""
    compaction = CompactionEvent(
        compaction_type="auto_summarization",
        messages_before=100,
        messages_after=20,
        tokens_saved=5000,
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )

    event = create_compaction_event(compaction, message_id="msg-789")

    assert isinstance(event, CustomEvent)
    assert event.name == COMPACTION_EVENT
    assert event.value["_linked_message_id"] == "msg-789"
    assert event.timestamp_ms == int(compaction.timestamp.timestamp() * 1000)
    assert event.value["compaction_type"] == "auto_summarization"
    assert event.value["messages_before"] == 100
    assert event.value["messages_after"] == 20
    assert event.value["tokens_saved"] == 5000


def test_create_compaction_event_manual():
    """Create COMPACTION_EVENT CustomEvent for manual compaction"""
    compaction = CompactionEvent(
        compaction_type="manual",
        timestamp=datetime(2024, 1, 1, 12, 0, 0),
    )

    event = create_compaction_event(compaction)

    assert isinstance(event, CustomEvent)
    assert event.name == COMPACTION_EVENT
    assert "_linked_message_id" not in event.value
    assert event.value["compaction_type"] == "manual"
    assert event.value["messages_before"] is None
    assert event.value["messages_after"] is None
    assert event.value["tokens_saved"] is None
