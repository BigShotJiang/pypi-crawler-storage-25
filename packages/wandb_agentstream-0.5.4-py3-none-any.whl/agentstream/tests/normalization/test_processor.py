from agentstream.events import CustomEvent
from agentstream.normalization.processor import EventProcessor
from agentstream.normalization.synthetic import (
    GIT_COMMIT,
    UNIFIED_FILE_OPERATION,
    UNIFIED_TODO_UPDATE,
)


def test_process_claude_events():
    """Process Claude events to generate synthetic CustomEvent instances"""
    processor = EventProcessor(agent_type="claude", version="1.2.3")

    events = [
        {
            "event_id": "evt-1",
            "tool_name": "TodoWrite",
            "timestamp_ms": 1704067200000,
            "agent_type": "claude",
            "args": {"todos": [{"content": "Fix bug", "status": "pending", "id": "1"}]},
            "result": {"finalTodos": [{"content": "Fix bug", "status": "pending", "id": "1"}]},
        },
        {
            "event_id": "evt-2",
            "tool_name": "Edit",
            "timestamp_ms": 1704067300000,
            "agent_type": "claude",
            "args": {"file_path": "src/auth.py"},
            "result": {"file_path": "src/auth.py"},
        },
    ]

    synthetic_events = processor.process_events(events, session=None)

    # Should have generated CustomEvent instances for todo and file op
    assert len(synthetic_events) >= 2
    assert all(isinstance(e, CustomEvent) for e in synthetic_events)

    todo_events = [e for e in synthetic_events if e.name == UNIFIED_TODO_UPDATE]
    file_events = [e for e in synthetic_events if e.name == UNIFIED_FILE_OPERATION]

    assert len(todo_events) == 1
    assert len(file_events) == 1


def test_process_events_uses_initial_git_state_for_commit_branch():
    processor = EventProcessor(agent_type="claude", version="1.2.3")
    events = [
        {
            "event_id": "evt-commit",
            "tool_name": "Bash",
            "timestamp_ms": 1704067400000,
            "args": {"command": 'git commit -m "ship"'},
            "result": "",
        }
    ]

    synthetic_events = processor.process_events(
        events,
        initial_git_state={"branch": "feature/incremental-seed"},
    )

    commit_events = [e for e in synthetic_events if e.name == GIT_COMMIT]
    assert len(commit_events) == 1
    assert commit_events[0].value["branch"] == "feature/incremental-seed"
