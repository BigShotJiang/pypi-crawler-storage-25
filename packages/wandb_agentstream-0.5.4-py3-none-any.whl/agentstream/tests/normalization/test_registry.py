from agentstream.normalization.base import BaseNormalizer
from agentstream.normalization.registry import get_normalizer


def test_get_normalizer_for_claude():
    """Registry returns normalizer for Claude agent"""
    normalizer = get_normalizer("claude", "1.2.3")
    assert normalizer is not None
    assert isinstance(normalizer, BaseNormalizer)


def test_get_normalizer_version_matching():
    """Registry matches version patterns correctly"""
    # Should match 1.x pattern
    norm1 = get_normalizer("claude", "1.2.3")
    norm2 = get_normalizer("claude", "1.9.0")
    assert isinstance(norm1, type(norm2))


def test_get_normalizer_unknown_agent():
    """Registry returns default normalizer for unknown agents"""
    normalizer = get_normalizer("unknown-agent", "1.0.0")
    assert normalizer is not None
    # Should be the default/fallback normalizer


def test_registry_caches_normalizers():
    """Registry caches normalizer instances"""
    norm1 = get_normalizer("claude", "1.2.3")
    norm2 = get_normalizer("claude", "1.2.3")
    assert norm1 is norm2  # Same instance
