"""Shared pytest fixtures and helpers for agentstream tests."""

from __future__ import annotations

import json
import sqlite3
from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest

import agentstream
from agentstream.adapters.base import Session

# =============================================================================
# Core Fixtures
# =============================================================================


@pytest.fixture
def mock_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Create a mock home directory and patch Path.home()."""
    mock_home_dir = tmp_path / "home"
    mock_home_dir.mkdir()
    monkeypatch.setattr(Path, "home", lambda: mock_home_dir)
    return mock_home_dir


@pytest.fixture
def mock_project_dir(tmp_path: Path) -> Path:
    """Create a mock project directory."""
    project = tmp_path / "project"
    project.mkdir()
    return project


# =============================================================================
# Session Fixtures
# =============================================================================


@pytest.fixture
def make_session() -> Callable[..., Session]:
    """Factory fixture for creating Session objects."""

    def _make_session(
        id: str = "test-session",
        path: Path | None = None,
        format: str = "claude",
        modified_at: float = 0.0,
        metadata: dict[str, Any] | None = None,
    ) -> Session:
        if path is None:
            path = Path("/tmp/test-session.jsonl")
        return Session(
            id=id,
            path=path,
            format=format,
            modified_at=modified_at,
            metadata=metadata,
        )

    return _make_session


@pytest.fixture
def claude_session(tmp_path: Path, make_session: Callable[..., Session]) -> Session:
    """Create a minimal Claude session for testing."""
    session_file = tmp_path / "session.jsonl"
    session_file.write_text(
        '{"type":"user","message":{"content":"Hello"},'
        '"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
        '{"type":"assistant","message":{"content":[{"type":"text","text":"Hi!"}]},'
        '"uuid":"a1","parentUuid":"u1","timestamp":"2024-01-01T00:00:01Z"}\n'
    )
    return make_session(path=session_file, format="claude")


# =============================================================================
# SQLite Database Helpers (for Cursor adapter)
# =============================================================================


def create_sqlite_table(db_path: Path, table_name: str, schema: str) -> sqlite3.Connection:
    """Create a SQLite database with a table.

    Args:
        db_path: Path to the database file.
        table_name: Name of the table to create.
        schema: SQL schema for the table (columns portion).

    Returns:
        Open connection to the database.
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(f"CREATE TABLE IF NOT EXISTS {table_name} ({schema})")
    conn.commit()
    return conn


def insert_kv_data(conn: sqlite3.Connection, table: str, key: str, value: Any) -> None:
    """Insert key-value data into a table.

    Args:
        conn: Database connection.
        table: Table name.
        key: Key string.
        value: Value (will be JSON encoded if not a string).
    """
    if not isinstance(value, str):
        value = json.dumps(value)
    cursor = conn.cursor()
    cursor.execute(f"INSERT OR REPLACE INTO {table} (key, value) VALUES (?, ?)", (key, value))
    conn.commit()


@pytest.fixture
def cursor_workspace_db(tmp_path: Path) -> Callable[[dict[str, Any]], Path]:
    """Factory for creating Cursor workspace state databases."""

    def _create(composer_data: dict[str, Any] | None = None) -> Path:
        db_path = tmp_path / "state.vscdb"
        conn = create_sqlite_table(db_path, "ItemTable", "key TEXT PRIMARY KEY, value BLOB")

        if composer_data is None:
            composer_data = {
                "allComposers": [
                    {
                        "composerId": "test-composer-001",
                        "unifiedMode": "agent",
                        "contextUsagePercent": 15.0,
                        "createdAt": 1704067200000,
                        "lastUpdatedAt": 1704070800000,
                    }
                ]
            }

        insert_kv_data(conn, "ItemTable", "composer.composerData", composer_data)
        conn.close()
        return db_path

    return _create


@pytest.fixture
def cursor_global_db(tmp_path: Path) -> Callable[[list[tuple[str, dict[str, Any]]]], Path]:
    """Factory for creating Cursor global state databases with bubbles."""

    def _create(bubbles: list[tuple[str, dict[str, Any]]] | None = None) -> Path:
        db_path = tmp_path / "global_state.vscdb"
        conn = create_sqlite_table(db_path, "cursorDiskKV", "key TEXT PRIMARY KEY, value BLOB")

        if bubbles is None:
            bubbles = [
                (
                    "bubbleId:test-composer-001:bubble-1",
                    {
                        "bubbleId": "bubble-1",
                        "type": 1,
                        "text": "Hello",
                        "createdAt": 1704067200000,
                    },
                ),
                (
                    "bubbleId:test-composer-001:bubble-2",
                    {
                        "bubbleId": "bubble-2",
                        "type": 2,
                        "text": "Hi there!",
                        "createdAt": 1704067201000,
                    },
                ),
            ]

        for key, value in bubbles:
            insert_kv_data(conn, "cursorDiskKV", key, value)

        conn.close()
        return db_path

    return _create


# =============================================================================
# JSONL File Helpers
# =============================================================================


def write_jsonl(path: Path, entries: list[dict[str, Any]]) -> None:
    """Write entries as JSONL to a file.

    Args:
        path: File path to write to.
        entries: List of dictionaries to write as JSON lines.
    """
    with open(path, "w") as f:
        for entry in entries:
            f.write(json.dumps(entry) + "\n")


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    """Read entries from a JSONL file.

    Args:
        path: File path to read from.

    Returns:
        List of parsed JSON dictionaries.
    """
    entries = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                entries.append(json.loads(line))
    return entries


@pytest.fixture
def write_claude_session(tmp_path: Path) -> Callable[[list[dict[str, Any]]], Path]:
    """Factory for writing Claude session files."""

    def _write(entries: list[dict[str, Any]]) -> Path:
        session_file = tmp_path / "session.jsonl"
        write_jsonl(session_file, entries)
        return session_file

    return _write


# =============================================================================
# Event Helpers
# =============================================================================


def filter_events_by_type(events: list[Any], event_type: str) -> list[Any]:
    """Filter events by their type.

    Args:
        events: List of event objects.
        event_type: Event type string to filter by.

    Returns:
        Filtered list of events.
    """
    return [e for e in events if e.type.value == event_type]


def get_event_types(events: list[Any]) -> list[str]:
    """Get list of event type strings from events.

    Args:
        events: List of event objects.

    Returns:
        List of event type strings.
    """
    return [e.type.value for e in events]


# =============================================================================
# CLI Test Helpers
# =============================================================================


@pytest.fixture
def mock_discover_sessions(monkeypatch: pytest.MonkeyPatch) -> Callable[[list[Session]], None]:
    """Factory to mock agentstream.discover_sessions."""

    def _mock(sessions: list[Session]) -> None:

        monkeypatch.setattr(agentstream, "discover_sessions", lambda *args, **kwargs: sessions)

    return _mock


# =============================================================================
# Assertion Helpers
# =============================================================================


def assert_events_have_timestamps(events: list[Any]) -> None:
    """Assert all events have valid timestamps."""
    for event in events:
        assert hasattr(event, "timestamp_ms"), f"Event {event} missing timestamp_ms"
        assert isinstance(event.timestamp_ms, int), (
            f"timestamp_ms should be int, got {type(event.timestamp_ms)}"
        )
        assert event.timestamp_ms > 0, f"timestamp_ms should be positive, got {event.timestamp_ms}"


def assert_events_ordered_by_timestamp(events: list[Any]) -> None:
    """Assert events are ordered by timestamp (non-decreasing)."""
    timestamps = [e.timestamp_ms for e in events]
    for i in range(1, len(timestamps)):
        assert timestamps[i] >= timestamps[i - 1], (
            f"Events not ordered: {timestamps[i - 1]} > {timestamps[i]} at index {i}"
        )
