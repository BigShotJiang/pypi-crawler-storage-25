"""Tests for analytics module."""

from __future__ import annotations

import uuid
from pathlib import Path

import pytest

from agentstream.analytics import (
    build_file_summary,
    build_session_summary,
    calculate_active_duration_ms,
    generate_event_id,
    generate_session_id,
    is_instruction_file,
    is_internal_session,
    normalize_path,
)
from agentstream.events import (
    CustomEvent,
    TextMessageChunkEvent,
    TextMessageContentEvent,
    TextMessageStartEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
    ToolCallStartEvent,
)
from agentstream.events.base import Role
from agentstream.normalization.synthetic import (
    ERROR_EVENT,
    SESSION_METADATA,
    TOKEN_USAGE,
    UNIFIED_FILE_OPERATION,
)

# =============================================================================
# Test Fixture Helpers
# =============================================================================


def create_session_metadata_event(
    timestamp_ms: int = 1704067200000,
    primary_model: str = "",
    agent_version: str = "",
    cwd: str = "",
    git_branch: str = "",
    git_commit: str = "",
    git_repo: str = "",
) -> CustomEvent:
    """Create a SESSION_METADATA custom event for testing."""
    return CustomEvent(
        timestamp_ms=timestamp_ms,
        name=SESSION_METADATA,
        value={
            "data": {
                "primary_model": primary_model,
                "agent_version": agent_version,
                "cwd": cwd,
                "git_branch": git_branch,
                "git_commit": git_commit,
                "git_repo": git_repo,
            }
        },
    )


def create_token_usage_event(
    timestamp_ms: int = 1704067200000,
    input_tokens: int = 0,
    output_tokens: int = 0,
    cache_read_tokens: int = 0,
    cache_creation_tokens: int = 0,
    reasoning_tokens: int = 0,
    model: str = "",
) -> CustomEvent:
    """Create a TOKEN_USAGE custom event for testing."""
    return CustomEvent(
        timestamp_ms=timestamp_ms,
        name=TOKEN_USAGE,
        value={
            "data": {
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "cache_read_tokens": cache_read_tokens,
                "cache_creation_tokens": cache_creation_tokens,
                "reasoning_tokens": reasoning_tokens,
                "model": model,
            }
        },
    )


def create_file_operation_event(
    timestamp_ms: int = 1704067200000,
    operation: str = "read",
    file_path: str = "",
) -> CustomEvent:
    """Create a UNIFIED_FILE_OPERATION custom event for testing."""
    return CustomEvent(
        timestamp_ms=timestamp_ms,
        name=UNIFIED_FILE_OPERATION,
        value={
            "data": {
                "operation": operation,
                "file_path": file_path,
            }
        },
    )


def create_error_event(
    timestamp_ms: int = 1704067200000,
    error_type: str = "tool_call_error",
    message: str = "",
    tool_name: str = "",
) -> CustomEvent:
    """Create an ERROR_EVENT custom event for testing."""
    return CustomEvent(
        timestamp_ms=timestamp_ms,
        name=ERROR_EVENT,
        value={
            "data": {
                "error_type": error_type,
                "message": message,
                "tool_name": tool_name,
            }
        },
    )


class TestGenerateEventIdValidation:
    """Tests for generate_event_id input validation."""

    def test_raises_on_zero_timestamp(self):
        """Should raise ValueError if timestamp_ms is 0."""
        with pytest.raises(ValueError, match="timestamp_ms must be > 0"):
            generate_event_id("session-123", 0, 0)

    def test_raises_on_negative_timestamp(self):
        """Should raise ValueError if timestamp_ms is negative."""
        with pytest.raises(ValueError, match="timestamp_ms must be > 0"):
            generate_event_id("session-123", 0, -1000)


class TestGenerateSessionId:
    """Tests for generate_session_id function."""

    def test_deterministic(self):
        """Same inputs should produce the same output."""
        id1 = generate_session_id(12345, "claude", "session-abc")
        id2 = generate_session_id(12345, "claude", "session-abc")
        assert id1 == id2

    def test_different_github_ids(self):
        """Different GitHub IDs should produce different session IDs."""
        id1 = generate_session_id(12345, "claude", "session-abc")
        id2 = generate_session_id(67890, "claude", "session-abc")
        assert id1 != id2

    def test_different_agents(self):
        """Different agent types should produce different IDs."""
        id1 = generate_session_id(12345, "claude", "session-abc")
        id2 = generate_session_id(12345, "gemini", "session-abc")
        assert id1 != id2

    def test_different_sessions(self):
        """Different session IDs should produce different IDs."""
        id1 = generate_session_id(12345, "claude", "session-abc")
        id2 = generate_session_id(12345, "claude", "session-xyz")
        assert id1 != id2

    def test_valid_uuid_format(self):
        """Output should be a valid UUID string."""

        id1 = generate_session_id(12345, "claude", "session-abc")
        # This will raise if not a valid UUID
        parsed = uuid.UUID(id1)
        assert str(parsed) == id1

    def test_accepts_string_github_id(self):
        """Should accept string github_id for backwards compatibility."""
        id1 = generate_session_id("12345", "claude", "session-abc")
        id2 = generate_session_id(12345, "claude", "session-abc")
        # String "12345" and int 12345 produce the same ID
        assert id1 == id2


class TestGenerateEventId:
    """Tests for generate_event_id function."""

    def test_deterministic(self):
        """Same inputs should produce the same output."""
        id1 = generate_event_id("session-123", 0, 1000000)
        id2 = generate_event_id("session-123", 0, 1000000)
        assert id1 == id2

    def test_deterministic_multiple_calls(self):
        """Multiple calls with same inputs should always produce same output."""
        ids = [generate_event_id("session-123", 42, 1234567890123) for _ in range(100)]
        assert all(id == ids[0] for id in ids)

    def test_different_sessions(self):
        """Different session IDs should produce different event IDs."""
        id1 = generate_event_id("session-123", 0, 1000000)
        id2 = generate_event_id("session-456", 0, 1000000)
        assert id1 != id2

    def test_different_indices(self):
        """Different event indices should produce different IDs."""
        id1 = generate_event_id("session-123", 0, 1000000)
        id2 = generate_event_id("session-123", 1, 1000000)
        assert id1 != id2

    def test_different_timestamps(self):
        """Different timestamps should produce different IDs."""
        id1 = generate_event_id("session-123", 0, 1000000)
        id2 = generate_event_id("session-123", 0, 2000000)
        assert id1 != id2

    def test_valid_uuid_format(self):
        """Output should be a valid UUID string."""

        id1 = generate_event_id("session-123", 0, 1000000)
        # This will raise if not a valid UUID
        parsed = uuid.UUID(id1)
        assert str(parsed) == id1

    def test_uuid_version_7(self):
        """Generated UUID should have version 7."""

        id1 = generate_event_id("session-123", 0, 1000000)
        parsed = uuid.UUID(id1)
        assert parsed.version == 7

    def test_timestamp_encoded(self):
        """Timestamp should be encoded in the first 48 bits."""
        timestamp_ms = 1767731627790
        id1 = generate_event_id("session-123", 0, timestamp_ms)

        # Extract first 48 bits (12 hex chars)
        uuid_hex = id1.replace("-", "")[:12]
        extracted_ts = int(uuid_hex, 16)

        assert extracted_ts == timestamp_ms

    def test_time_ordering(self):
        """Events with later timestamps should have lexicographically larger UUIDs."""
        id1 = generate_event_id("session-123", 0, 1000000)
        id2 = generate_event_id("session-123", 1, 2000000)
        id3 = generate_event_id("session-123", 2, 3000000)

        # UUIDs should be ordered by time
        assert id1 < id2 < id3

    def test_same_timestamp_different_index(self):
        """Events with same timestamp but different index should have unique IDs."""
        id1 = generate_event_id("session-123", 0, 1000000)
        id2 = generate_event_id("session-123", 1, 1000000)

        # Same timestamp prefix, but different random bits
        assert id1 != id2
        # Both start with same timestamp
        assert id1[:13] == id2[:13]  # First part up to version nibble


class TestBuildSessionSummaryTokenExtraction:
    """Tests for token usage extraction in build_session_summary()."""

    def test_extracts_token_usage_from_single_event(self):
        """Single event with usage data should be extracted."""
        events = [
            CustomEvent(
                timestamp_ms=1704067200000,
                name=TOKEN_USAGE,
                value={
                    "data": {
                        "input_tokens": 1000,
                        "output_tokens": 500,
                        "cache_read_tokens": 200,
                        "cache_creation_tokens": 100,
                        "model": "claude-opus-4-5-20251101",
                    }
                },
            ),
            CustomEvent(
                timestamp_ms=1704067200000,
                name=SESSION_METADATA,
                value={
                    "data": {
                        "primary_model": "claude-opus-4-5-20251101",
                        "cwd": "",
                        "agent_version": "",
                        "git_branch": "",
                        "git_commit": "",
                        "git_repo": "",
                    }
                },
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["input_tokens"] == 1000
        assert summary["output_tokens"] == 500
        assert summary["cached_read_tokens"] == 200
        assert summary["cached_write_tokens"] == 100

    def test_aggregates_token_usage_from_multiple_events(self):
        """Multiple events should have their token usage summed."""
        events = [
            CustomEvent(
                timestamp_ms=1704067200000,
                name=TOKEN_USAGE,
                value={
                    "data": {
                        "input_tokens": 1000,
                        "output_tokens": 500,
                        "cache_read_tokens": 200,
                        "cache_creation_tokens": 100,
                        "model": "claude-opus-4-5-20251101",
                    }
                },
            ),
            CustomEvent(
                timestamp_ms=1704067201000,
                name=TOKEN_USAGE,
                value={
                    "data": {
                        "input_tokens": 1500,
                        "output_tokens": 800,
                        "cache_read_tokens": 0,
                        "cache_creation_tokens": 0,
                        "model": "claude-opus-4-5-20251101",
                    }
                },
            ),
            CustomEvent(
                timestamp_ms=1704067200000,
                name=SESSION_METADATA,
                value={
                    "data": {
                        "primary_model": "claude-opus-4-5-20251101",
                        "cwd": "",
                        "agent_version": "",
                        "git_branch": "",
                        "git_commit": "",
                        "git_repo": "",
                    }
                },
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["input_tokens"] == 2500  # 1000 + 1500
        assert summary["output_tokens"] == 1300  # 500 + 800
        assert summary["cached_read_tokens"] == 200  # only first event has this
        assert summary["cached_write_tokens"] == 100  # only first event has this

    def test_handles_events_without_usage_data(self):
        """Events without usage data should not cause errors."""
        events = [
            CustomEvent(
                timestamp_ms=1704067200000,
                name=SESSION_METADATA,
                value={
                    "data": {
                        "primary_model": "claude-opus-4-5-20251101",
                        "cwd": "",
                        "agent_version": "",
                        "git_branch": "",
                        "git_commit": "",
                        "git_repo": "",
                    }
                },
            ),
            # No TOKEN_USAGE events
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["input_tokens"] == 0
        assert summary["output_tokens"] == 0
        assert summary["cached_read_tokens"] == 0
        assert summary["cached_write_tokens"] == 0

    def test_handles_events_without_custom_events(self):
        """Events without custom events should not cause errors."""
        events = [
            TextMessageChunkEvent(
                timestamp_ms=1704067200000,
                message_id="msg1",
                role=Role.ASSISTANT,
                delta="Response",
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["input_tokens"] == 0
        assert summary["output_tokens"] == 0
        assert summary["cached_read_tokens"] == 0
        assert summary["cached_write_tokens"] == 0


class TestBuildFileSummary:
    """Tests for build_file_summary() reading from UNIFIED_FILE_OPERATION events."""

    def test_extracts_file_operations_from_custom_events(self):
        """Should extract file operations from UNIFIED_FILE_OPERATION custom events."""
        events = [
            CustomEvent(
                timestamp_ms=1704067200000,
                name=UNIFIED_FILE_OPERATION,
                value={
                    "data": {
                        "operation": "read",
                        "file_path": "./src/main.py",
                    }
                },
            ),
            CustomEvent(
                timestamp_ms=1704067201000,
                name=UNIFIED_FILE_OPERATION,
                value={
                    "data": {
                        "operation": "write",
                        "file_path": "./src/test.py",
                    }
                },
            ),
            CustomEvent(
                timestamp_ms=1704067202000,
                name=UNIFIED_FILE_OPERATION,
                value={
                    "data": {
                        "operation": "edit",
                        "file_path": "./README.md",
                    }
                },
            ),
        ]

        summary = build_file_summary(events)

        assert summary["files_read"] == 1
        assert summary["files_written"] == 1
        assert summary["files_edited"] == 1
        assert summary["files_deleted"] == 0
        assert "./src/main.py" in summary["read_paths"]
        assert "./src/test.py" in summary["write_paths"]
        assert "./README.md" in summary["write_paths"]

    def test_counts_search_and_list_operations(self):
        """Should count search and list operations."""
        events = [
            CustomEvent(
                timestamp_ms=1704067200000,
                name=UNIFIED_FILE_OPERATION,
                value={"data": {"operation": "search", "file_path": ""}},
            ),
            CustomEvent(
                timestamp_ms=1704067201000,
                name=UNIFIED_FILE_OPERATION,
                value={"data": {"operation": "list", "file_path": ""}},
            ),
            CustomEvent(
                timestamp_ms=1704067202000,
                name=UNIFIED_FILE_OPERATION,
                value={"data": {"operation": "search", "file_path": ""}},
            ),
        ]

        summary = build_file_summary(events)

        assert summary["search_count"] == 2
        assert summary["list_count"] == 1

    def test_detects_instruction_files(self):
        """Should detect instruction files like AGENTS.md, CLAUDE.md."""
        events = [
            CustomEvent(
                timestamp_ms=1704067200000,
                name=UNIFIED_FILE_OPERATION,
                value={
                    "data": {
                        "operation": "read",
                        "file_path": "./AGENTS.md",
                    }
                },
            ),
            CustomEvent(
                timestamp_ms=1704067201000,
                name=UNIFIED_FILE_OPERATION,
                value={
                    "data": {
                        "operation": "read",
                        "file_path": "./CLAUDE.md",
                    }
                },
            ),
        ]

        summary = build_file_summary(events)

        assert len(summary["instruction_files"]) == 2
        assert "./AGENTS.md" in summary["instruction_files"]
        assert "./CLAUDE.md" in summary["instruction_files"]

    def test_ignores_non_file_operation_events(self):
        """Should ignore events that aren't UNIFIED_FILE_OPERATION."""
        events = [
            CustomEvent(
                timestamp_ms=1704067200000,
                name=TOKEN_USAGE,
                value={"data": {"input_tokens": 100}},
            ),
            CustomEvent(
                timestamp_ms=1704067201000,
                name=SESSION_METADATA,
                value={"data": {"cwd": "/test"}},
            ),
        ]

        summary = build_file_summary(events)

        assert summary["files_read"] == 0
        assert summary["files_written"] == 0


class TestBuildSessionSummaryErrorCounting:
    """Tests for error counting in build_session_summary()."""

    def test_counts_errors_from_error_event_custom_events(self):
        """Should count errors from ERROR_EVENT custom events."""
        events = [
            CustomEvent(
                timestamp_ms=1704067200000,
                name=ERROR_EVENT,
                value={
                    "data": {
                        "error_type": "timeout",
                        "message": "Tool execution timeout",
                        "tool_name": "Bash",
                    }
                },
            ),
            CustomEvent(
                timestamp_ms=1704067201000,
                name=ERROR_EVENT,
                value={
                    "data": {
                        "error_type": "permission_denied",
                        "message": "Permission denied",
                        "tool_name": "Write",
                    }
                },
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["error_count"] == 2

    def test_counts_errors_from_tool_result_events(self):
        """Should count errors from ToolCallResultEvent with is_error=True."""
        events = [
            ToolCallResultEvent(
                timestamp_ms=1704067200000,
                tool_call_result_id="result1",
                tool_call_id="call1",
                result="Error: command failed",
                is_error=True,
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["error_count"] == 1

    def test_counts_errors_from_both_sources(self):
        """Should count errors from both ERROR_EVENT and ToolCallResultEvent."""
        events = [
            CustomEvent(
                timestamp_ms=1704067200000,
                name=ERROR_EVENT,
                value={
                    "data": {
                        "error_type": "timeout",
                        "message": "Timeout",
                        "tool_name": "Bash",
                    }
                },
            ),
            ToolCallResultEvent(
                timestamp_ms=1704067201000,
                tool_call_result_id="result1",
                tool_call_id="call1",
                result="Error: file not found",
                is_error=True,
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["error_count"] == 2


# =============================================================================
# Tests merged from tests/test_analytics.py
# =============================================================================


class TestBuildSessionSummary:
    def test_extracts_parent_session_id_from_subagent(self) -> None:
        """build_session_summary should extract parent_session_id for sub-agents."""
        events = [
            CustomEvent(
                timestamp_ms=1704067200000,
                name="source_entry",
                value={
                    "format": "claude",
                    "entry_type": "user",
                    "raw_line": '{"type":"user","sessionId":"a1b2c3d4-e5f6-7890"}',
                    "index": 0,
                    "raw_event": {"sessionId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"},
                },
            ),
        ]

        summary = build_session_summary(
            agent_session_id="agent-abc123f",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary.get("parent_session_id") is not None
        assert summary["parent_session_id"] != "a1b2c3d4-e5f6-7890-abcd-ef1234567890"

    def test_no_parent_session_id_for_toplevel(self) -> None:
        """build_session_summary should NOT set parent_session_id for top-level sessions."""
        events = [
            CustomEvent(
                timestamp_ms=1704067200000,
                name="source_entry",
                value={
                    "format": "claude",
                    "entry_type": "user",
                    "raw_line": '{"type":"user","sessionId":"a1b2c3d4-e5f6-7890"}',
                    "index": 0,
                    "raw_event": {"sessionId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"},
                },
            ),
        ]

        summary = build_session_summary(
            agent_session_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary.get("parent_session_id") is None

    def test_counts_turns_from_chunk_events(self) -> None:
        """build_session_summary should count user messages from TEXT_MESSAGE_CHUNK events."""
        events = [
            TextMessageChunkEvent(
                timestamp_ms=1704067200000,
                message_id="msg1",
                role=Role.USER,
                delta="Hello, can you help me?",
            ),
            TextMessageChunkEvent(
                timestamp_ms=1704067201000,
                message_id="msg2",
                role=Role.ASSISTANT,
                delta="Of course!",
            ),
            TextMessageChunkEvent(
                timestamp_ms=1704067202000,
                message_id="msg3",
                role=Role.USER,
                delta="Thanks!",
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["turn_count"] == 2  # 2 user messages
        assert summary["message_count"] == 3  # 3 total messages

    def test_counts_tools_from_chunk_events(self) -> None:
        """build_session_summary should count tools from TOOL_CALL_CHUNK events."""
        events = [
            ToolCallChunkEvent(
                timestamp_ms=1704067200000,
                tool_call_id="tc1",
                tool_call_name="read_file",
                delta='{"path": "test.txt"}',
            ),
            ToolCallChunkEvent(
                timestamp_ms=1704067201000,
                tool_call_id="tc2",
                tool_call_name="write_file",
                delta='{"path": "out.txt"}',
            ),
            ToolCallChunkEvent(
                timestamp_ms=1704067202000,
                tool_call_id="tc3",
                tool_call_name="read_file",  # duplicate tool name
                delta='{"path": "other.txt"}',
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["tool_call_count"] == 3  # 3 tool calls
        assert set(summary["tools_used"]) == {"read_file", "write_file"}  # 2 unique tools

    def test_extracts_first_prompt_from_chunk_events(self) -> None:
        """build_session_summary should extract first_prompt from TEXT_MESSAGE_CHUNK events."""
        events = [
            TextMessageChunkEvent(
                timestamp_ms=1704067200000,
                message_id="msg1",
                role=Role.USER,
                delta="Help me refactor the authentication module",
            ),
            TextMessageChunkEvent(
                timestamp_ms=1704067201000,
                message_id="msg2",
                role=Role.ASSISTANT,
                delta="I'll help you with that.",
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["first_prompt"] == "Help me refactor the authentication module"

    def test_works_with_full_lifecycle_events(self) -> None:
        """build_session_summary should still work with TEXT_MESSAGE_START events."""
        events = [
            TextMessageStartEvent(
                timestamp_ms=1704067200000,
                message_id="msg1",
                role=Role.USER,
            ),
            TextMessageContentEvent(
                timestamp_ms=1704067200001,
                message_id="msg1",
                delta="Hello world",
            ),
            ToolCallStartEvent(
                timestamp_ms=1704067201000,
                tool_call_id="tc1",
                tool_call_name="bash",
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["turn_count"] == 1
        assert summary["tool_call_count"] == 1
        assert summary["tools_used"] == ["bash"]
        assert summary["first_prompt"] == "Hello world"

    def test_extracts_reasoning_tokens_from_usage(self) -> None:
        """build_session_summary should extract reasoning_tokens from usage data."""
        events = [
            create_token_usage_event(
                timestamp_ms=1704067200000,
                input_tokens=100,
                output_tokens=200,
                cache_read_tokens=50,
                cache_creation_tokens=25,
                reasoning_tokens=150,
                model="claude-opus-4-5-20251101",
            ),
            create_token_usage_event(
                timestamp_ms=1704067201000,
                input_tokens=80,
                output_tokens=120,
                reasoning_tokens=100,
                model="claude-opus-4-5-20251101",
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["reasoning_tokens"] == 250  # 150 + 100
        assert summary["input_tokens"] == 180  # 100 + 80
        assert summary["output_tokens"] == 320  # 200 + 120
        assert summary["cached_read_tokens"] == 50
        assert summary["cached_write_tokens"] == 25

    def test_extracts_version_and_git_branch(self) -> None:
        """build_session_summary should extract version and git_branch from SESSION_METADATA."""
        events = [
            create_session_metadata_event(
                timestamp_ms=1704067200000,
                agent_version="1.0.25",
                git_branch="feature/new-feature",
                primary_model="claude-sonnet-4-20250514",
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["version"] == "1.0.25"
        assert summary["git_branch"] == "feature/new-feature"

    def test_extracts_version_and_git_branch_from_first_occurrence(self) -> None:
        """build_session_summary should use first occurrence of version/git_branch."""
        events = [
            create_session_metadata_event(
                timestamp_ms=1704067200000,
                agent_version="1.0.24",
            ),
            create_session_metadata_event(
                timestamp_ms=1704067201000,
                agent_version="1.0.25",  # Different version - should be ignored
                git_branch="main",
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["version"] == "1.0.24"
        assert summary["git_branch"] == "main"

    def test_version_and_git_branch_defaults_to_empty(self) -> None:
        """build_session_summary should return empty strings when not present."""
        events = [
            create_session_metadata_event(
                timestamp_ms=1704067200000,
                primary_model="claude-sonnet-4-20250514",
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["version"] == ""
        assert summary["git_branch"] == ""

    def test_extracts_git_repo_and_git_commit_from_cwd(self, monkeypatch) -> None:
        """build_session_summary should extract git_repo and git_commit from cwd."""

        monkeypatch.setattr(
            "agentstream.analytics.resolve_git_repo",
            lambda cwd: "github.com/example/repo" if cwd == "/home/user/project" else None,
        )
        monkeypatch.setattr(
            "agentstream.analytics.find_git_root",
            lambda cwd: Path("/home/user/project") if cwd == "/home/user/project" else None,
        )
        monkeypatch.setattr(
            "agentstream.analytics.get_git_commit_sha",
            lambda git_root: "abc123def456" if str(git_root) == "/home/user/project" else None,
        )

        events = [
            create_session_metadata_event(
                timestamp_ms=1704067200000,
                cwd="/home/user/project",
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["git_repo"] == "github.com/example/repo"
        assert summary["git_commit"] == "abc123def456"

    def test_git_repo_and_git_commit_empty_without_cwd(self) -> None:
        """build_session_summary should return empty strings when cwd is not present."""
        events = [
            create_session_metadata_event(
                timestamp_ms=1704067200000,
                primary_model="claude-sonnet-4-20250514",
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["git_repo"] == ""
        assert summary["git_commit"] == ""

    def test_counts_error_tool_results(self) -> None:
        """build_session_summary should count ToolCallResultEvent with is_error=True."""
        events = [
            TextMessageChunkEvent(
                timestamp_ms=1704067200000,
                message_id="msg1",
                role=Role.USER,
                delta="Run some commands",
            ),
            ToolCallChunkEvent(
                timestamp_ms=1704067201000,
                tool_call_id="tc1",
                tool_call_name="bash",
                delta='{"command": "ls"}',
            ),
            ToolCallResultEvent(
                timestamp_ms=1704067202000,
                tool_call_result_id="tcr1",
                tool_call_id="tc1",
                result="file1.txt\nfile2.txt",
                is_error=False,
            ),
            ToolCallChunkEvent(
                timestamp_ms=1704067203000,
                tool_call_id="tc2",
                tool_call_name="bash",
                delta='{"command": "cat nonexistent"}',
            ),
            ToolCallResultEvent(
                timestamp_ms=1704067204000,
                tool_call_result_id="tcr2",
                tool_call_id="tc2",
                result="cat: nonexistent: No such file or directory",
                is_error=True,
            ),
            ToolCallChunkEvent(
                timestamp_ms=1704067205000,
                tool_call_id="tc3",
                tool_call_name="bash",
                delta='{"command": "invalid_command"}',
            ),
            ToolCallResultEvent(
                timestamp_ms=1704067206000,
                tool_call_result_id="tcr3",
                tool_call_id="tc3",
                result="bash: invalid_command: command not found",
                is_error=True,
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["tool_call_count"] == 3  # 3 tool calls
        assert summary["error_count"] == 2  # 2 errors (tc2 and tc3)

    def test_error_count_zero_when_no_errors(self) -> None:
        """build_session_summary should return error_count=0 when no errors."""
        events = [
            TextMessageChunkEvent(
                timestamp_ms=1704067200000,
                message_id="msg1",
                role=Role.USER,
                delta="Run a command",
            ),
            ToolCallChunkEvent(
                timestamp_ms=1704067201000,
                tool_call_id="tc1",
                tool_call_name="bash",
                delta='{"command": "ls"}',
            ),
            ToolCallResultEvent(
                timestamp_ms=1704067202000,
                tool_call_result_id="tcr1",
                tool_call_id="tc1",
                result="file1.txt",
                is_error=False,
            ),
        ]

        summary = build_session_summary(
            agent_session_id="test-session",
            format="claude",
            modified_at=1704067200.0,
            events=events,
            github_id="test-user",
        )

        assert summary["error_count"] == 0


class TestCalculateActiveDuration:
    def test_calculates_duration_from_chunk_events(self) -> None:
        """calculate_active_duration_ms should work with TEXT_MESSAGE_CHUNK events."""
        events = [
            TextMessageChunkEvent(
                timestamp_ms=1000,
                message_id="msg1",
                role=Role.USER,
                delta="Question",
            ),
            TextMessageChunkEvent(
                timestamp_ms=2000,
                message_id="msg2",
                role=Role.ASSISTANT,
                delta="Answer",
            ),
            TextMessageChunkEvent(
                timestamp_ms=5000,
                message_id="msg3",
                role=Role.USER,
                delta="Follow up",
            ),
            TextMessageChunkEvent(
                timestamp_ms=6000,
                message_id="msg4",
                role=Role.ASSISTANT,
                delta="More answer",
            ),
        ]

        result = calculate_active_duration_ms(events)

        # First turn: 2000 - 1000 = 1000ms
        # Second turn: 6000 - 5000 = 1000ms
        # Total: 2000ms
        assert result.duration_ms == 2000
        assert result.total_chunks == 2
        assert result.capped_chunks == 0

    def test_calculates_duration_without_user_messages(self) -> None:
        """calculate_active_duration_ms should fall back to first-to-last event for CLI sessions."""
        # CLI-initiated sessions have no user messages - just assistant activity
        events = [
            TextMessageChunkEvent(
                timestamp_ms=1000,
                message_id="msg1",
                role=Role.ASSISTANT,
                delta="Starting work...",
            ),
            ToolCallChunkEvent(
                timestamp_ms=2000,
                tool_call_id="tc1",
                tool_call_name="Read",
                parent_message_id="msg1",
                delta="{}",
            ),
            ToolCallResultEvent(
                timestamp_ms=3000,
                tool_call_result_id="tcr1",
                tool_call_id="tc1",
                result="file contents",
                is_error=False,
            ),
            TextMessageChunkEvent(
                timestamp_ms=5000,
                message_id="msg2",
                role=Role.ASSISTANT,
                delta="Done!",
            ),
        ]

        result = calculate_active_duration_ms(events)

        # No user messages, so chunk from first to last: 5000 - 1000 = 4000ms
        assert result.duration_ms == 4000
        assert result.total_chunks == 1
        assert result.capped_chunks == 0

    def test_returns_zero_for_single_event_without_user_messages(self) -> None:
        """calculate_active_duration_ms should return 0 for single-event sessions."""
        events = [
            TextMessageChunkEvent(
                timestamp_ms=1000,
                message_id="msg1",
                role=Role.ASSISTANT,
                delta="Only one message",
            ),
        ]

        result = calculate_active_duration_ms(events)

        # Single event = 0 duration (chunk from ts to ts = 0)
        assert result.duration_ms == 0
        assert result.total_chunks == 1
        assert result.capped_chunks == 0

    def test_returns_zero_for_empty_events(self) -> None:
        """calculate_active_duration_ms should return 0 for empty event list."""
        result = calculate_active_duration_ms([])
        assert result.duration_ms == 0
        assert result.total_chunks == 0
        assert result.capped_chunks == 0

    def test_caps_long_chunks_at_max_duration(self) -> None:
        """calculate_active_duration_ms should cap chunks at 4 hours."""
        # Create events spanning 5 hours with no gaps > 10 min
        # (in reality this would need many events, but for test we just verify capping)
        events = [
            TextMessageChunkEvent(
                timestamp_ms=0,
                message_id="u1",
                role=Role.USER,
                delta="Start",
            ),
            TextMessageChunkEvent(
                timestamp_ms=1000,
                message_id="a1",
                role=Role.ASSISTANT,
                delta="Working...",
            ),
            # 5 hours later (18_000_000 ms) - would trigger gap detection
            # So let's test with a continuous chunk by using events within gap threshold
            TextMessageChunkEvent(
                timestamp_ms=5 * 60 * 60 * 1000,  # 5 hours
                message_id="a2",
                role=Role.ASSISTANT,
                delta="Still working...",
            ),
        ]

        result = calculate_active_duration_ms(events)

        # Gap between 1000ms and 5h is way > 10 min, so creates 2 chunks
        # First chunk: 1000 - 0 = 1000ms (user to first assistant)
        # Second chunk: 5h - 5h = 0ms (single event)
        # But since gap is detected, we get separate chunks
        assert result.capped_chunks == 0  # Neither chunk exceeds 4 hours
        assert result.duration_ms < 4 * 60 * 60 * 1000  # Less than 4 hours


class TestIsInternalSession:
    def test_detects_caveat_message_without_model(self) -> None:
        """is_internal_session should return True for sidechain sessions."""
        summary = {
            "model": "",
            "first_prompt": "Caveat: The messages below were generated by the user...",
        }
        assert is_internal_session(summary) is True

    def test_detects_local_command_caveat(self) -> None:
        """is_internal_session should detect local-command-caveat tags."""
        summary = {
            "model": "",
            "first_prompt": "<local-command-caveat>Some content here",
        }
        assert is_internal_session(summary) is True

    def test_allows_session_with_model(self) -> None:
        """is_internal_session should return False when model is present."""
        summary = {
            "model": "claude-opus-4-5-20251101",
            "first_prompt": "Caveat: The messages below were generated...",
        }
        assert is_internal_session(summary) is False

    def test_allows_normal_session(self) -> None:
        """is_internal_session should return False for normal sessions."""
        summary = {
            "model": "claude-sonnet-4-20250514",
            "first_prompt": "Help me refactor the authentication module",
        }
        assert is_internal_session(summary) is False

    def test_allows_session_without_prompt(self) -> None:
        """is_internal_session should return False if session has turns but no first_prompt."""
        summary = {
            "model": "",
            "first_prompt": "",
            "turn_count": 1,  # Has activity, just no detected first_prompt
        }
        assert is_internal_session(summary) is False


class TestNormalizePath:
    """Tests for normalize_path function."""

    def test_absolute_path_inside_cwd(self) -> None:
        """Absolute path inside cwd should become relative with ./"""
        result = normalize_path("/home/user/project/src/main.py", "/home/user/project")
        assert result == "./src/main.py"

    def test_absolute_path_outside_cwd(self) -> None:
        """Absolute path outside cwd should stay absolute."""
        result = normalize_path("/etc/config", "/home/user/project")
        assert result == "/etc/config"

    def test_relative_path_inside_cwd(self) -> None:
        """Relative path should become normalized with ./"""
        result = normalize_path("src/main.py", "/home/user/project")
        assert result == "./src/main.py"

    def test_relative_path_with_parent_traversal_inside(self) -> None:
        """Parent traversal from subdirectory that stays inside project."""
        result = normalize_path("/home/user/project/README.md", "/home/user/project")
        assert result == "./README.md"

    def test_relative_path_from_subdirectory_becomes_absolute(self) -> None:
        """Relative path from subdirectory cwd normalizes to that subdirectory context."""
        result = normalize_path("../README.md", "/home/user/project/src")
        assert result == "/home/user/project/README.md"

    def test_relative_path_escaping_cwd(self) -> None:
        """Parent traversal that escapes cwd should become absolute."""
        result = normalize_path("../../other/file.py", "/home/user/project")
        assert result == "/home/other/file.py"

    def test_path_at_cwd_root(self) -> None:
        """File at cwd root should be ./filename."""
        result = normalize_path("/home/user/project/README.md", "/home/user/project")
        assert result == "./README.md"

    def test_empty_path(self) -> None:
        """Empty path should be returned as-is."""
        result = normalize_path("", "/home/user/project")
        assert result == ""

    def test_no_cwd(self) -> None:
        """Without cwd, path should be returned with forward slashes."""
        result = normalize_path("src/main.py", None)
        assert result == "src/main.py"

    def test_forward_slashes_preserved(self) -> None:
        """Forward slashes should be used in output."""
        result = normalize_path("/home/user/project/src/main.py", "/home/user/project")
        assert "/" in result
        assert "\\" not in result


class TestIsInstructionFile:
    """Tests for is_instruction_file function."""

    def test_agents_md(self) -> None:
        """AGENTS.md should be detected."""
        assert is_instruction_file("./AGENTS.md") is True
        assert is_instruction_file("/project/AGENTS.md") is True

    def test_claude_md(self) -> None:
        """CLAUDE.md should be detected."""
        assert is_instruction_file("./CLAUDE.md") is True
        assert is_instruction_file("CLAUDE.md") is True

    def test_gemini_md(self) -> None:
        """GEMINI.md should be detected."""
        assert is_instruction_file("./GEMINI.md") is True

    def test_cursorrules(self) -> None:
        """.cursorrules should be detected."""
        assert is_instruction_file("./.cursorrules") is True
        assert is_instruction_file("/project/.cursorrules") is True

    def test_case_insensitive(self) -> None:
        """Detection should be case-insensitive."""
        assert is_instruction_file("./claude.md") is True
        assert is_instruction_file("./Claude.MD") is True

    def test_non_instruction_file(self) -> None:
        """Regular files should not be detected."""
        assert is_instruction_file("./src/main.py") is False
        assert is_instruction_file("./README.md") is False

    def test_empty_path(self) -> None:
        """Empty path should return False."""
        assert is_instruction_file("") is False

    def test_directory_based_patterns(self) -> None:
        """Directory-based instruction patterns should be detected."""
        assert is_instruction_file("./.anthropic/config") is True
        assert is_instruction_file("/project/.cursor/rules") is True


class TestBuildFileSummaryExtended:
    """Extended tests for build_file_summary function."""

    def test_empty_events(self) -> None:
        """Empty events should return empty summary."""
        summary = build_file_summary([])
        assert summary["files_read"] == 0
        assert summary["files_written"] == 0
        assert summary["read_paths"] == []
        assert summary["write_paths"] == []

    def test_read_operations(self) -> None:
        """Read operations should be tracked."""
        events = [
            create_file_operation_event(
                timestamp_ms=1000,
                operation="read",
                file_path="./src/main.py",
            ),
            create_file_operation_event(
                timestamp_ms=2000,
                operation="read",
                file_path="./README.md",
            ),
        ]
        summary = build_file_summary(events)
        assert summary["files_read"] == 2
        assert "./src/main.py" in summary["read_paths"]
        assert "./README.md" in summary["read_paths"]

    def test_write_and_edit_operations(self) -> None:
        """Write and edit operations should be tracked separately."""
        events = [
            create_file_operation_event(
                timestamp_ms=1000,
                operation="write",
                file_path="./new_file.py",
            ),
            create_file_operation_event(
                timestamp_ms=2000,
                operation="edit",
                file_path="./existing.py",
            ),
        ]
        summary = build_file_summary(events)
        assert summary["files_written"] == 1
        assert summary["files_edited"] == 1
        assert "./new_file.py" in summary["write_paths"]
        assert "./existing.py" in summary["write_paths"]

    def test_instruction_file_detection(self) -> None:
        """Instruction files should be detected from read operations."""
        events = [
            create_file_operation_event(
                timestamp_ms=1000,
                operation="read",
                file_path="./CLAUDE.md",
            ),
            create_file_operation_event(
                timestamp_ms=2000,
                operation="read",
                file_path="./src/main.py",
            ),
        ]
        summary = build_file_summary(events)
        assert summary["instruction_files"] == ["./CLAUDE.md"]

    def test_search_and_list_counts(self) -> None:
        """Search and list operations should be counted."""
        events = [
            create_file_operation_event(
                timestamp_ms=1000,
                operation="search",
            ),
            create_file_operation_event(
                timestamp_ms=2000,
                operation="list",
            ),
            create_file_operation_event(
                timestamp_ms=3000,
                operation="search",
            ),
        ]
        summary = build_file_summary(events)
        assert summary["search_count"] == 2
        assert summary["list_count"] == 1

    def test_file_types_counting(self) -> None:
        """File types should be counted by extension."""
        events = [
            create_file_operation_event(
                timestamp_ms=1000,
                operation="read",
                file_path="./a.py",
            ),
            create_file_operation_event(
                timestamp_ms=1001,
                operation="read",
                file_path="./b.py",
            ),
            create_file_operation_event(
                timestamp_ms=1002,
                operation="read",
                file_path="./c.ts",
            ),
        ]
        summary = build_file_summary(events)
        assert summary["file_types"][".py"] == 2
        assert summary["file_types"][".ts"] == 1

    def test_deduplication(self) -> None:
        """Same file read multiple times should only be counted once."""
        events = [
            create_file_operation_event(
                timestamp_ms=1000,
                operation="read",
                file_path="./main.py",
            ),
            create_file_operation_event(
                timestamp_ms=2000,
                operation="read",
                file_path="./main.py",
            ),
        ]
        summary = build_file_summary(events)
        assert summary["files_read"] == 1
        assert summary["read_paths"] == ["./main.py"]
