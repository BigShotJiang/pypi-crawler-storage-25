"""Tests for remote session discovery modules."""
