"""Tests for Claude credentials reading."""

from __future__ import annotations

import json
import sys
import time
from unittest import mock

import pytest

from agentstream.remote.claude_credentials import (
    ClaudeCredentials,
    _read_from_file,
    _read_from_keychain,
    _read_organization_uuid,
    has_claude_credentials,
    read_claude_credentials,
)


class TestClaudeCredentials:
    """Tests for ClaudeCredentials dataclass."""

    def test_is_expired_when_expired(self):
        """Test is_expired returns True when token is expired."""
        # Expired 1 hour ago
        creds = ClaudeCredentials(
            access_token="test_token",
            refresh_token=None,
            expires_at=int((time.time() - 3600) * 1000),  # 1 hour ago in ms
            scopes=["user:inference"],
        )
        assert creds.is_expired is True

    def test_is_expired_when_valid(self):
        """Test is_expired returns False when token is still valid."""
        # Expires in 1 hour
        creds = ClaudeCredentials(
            access_token="test_token",
            refresh_token=None,
            expires_at=int((time.time() + 3600) * 1000),  # 1 hour from now in ms
            scopes=["user:inference"],
        )
        assert creds.is_expired is False

    def test_expires_in_seconds(self):
        """Test expires_in_seconds calculation."""
        future_time = time.time() + 3600
        creds = ClaudeCredentials(
            access_token="test_token",
            refresh_token=None,
            expires_at=int(future_time * 1000),
            scopes=["user:inference"],
        )
        # Should be approximately 3600 seconds (allow 1 second tolerance)
        assert abs(creds.expires_in_seconds - 3600) < 1


class TestReadFromFile:
    """Tests for _read_from_file function."""

    def test_returns_none_when_file_missing(self, tmp_path, monkeypatch):
        """Test returns None when credentials file doesn't exist."""
        monkeypatch.setattr(
            "agentstream.remote.claude_credentials.CLAUDE_CREDENTIALS_FILE",
            tmp_path / "nonexistent" / ".credentials.json",
        )
        assert _read_from_file() is None

    def test_returns_parsed_json(self, tmp_path, monkeypatch):
        """Test returns parsed JSON when file exists and is valid."""
        creds_file = tmp_path / ".credentials.json"
        creds_data = {
            "claudeAiOauth": {
                "accessToken": "sk-ant-oat01-test",
                "refreshToken": "sk-ant-ort01-test",
                "expiresAt": 1748276587173,
                "scopes": ["user:inference", "user:profile"],
            }
        }
        creds_file.write_text(json.dumps(creds_data))

        monkeypatch.setattr(
            "agentstream.remote.claude_credentials.CLAUDE_CREDENTIALS_FILE", creds_file
        )
        result = _read_from_file()

        assert result == creds_data

    def test_returns_none_on_invalid_json(self, tmp_path, monkeypatch):
        """Test returns None when file contains invalid JSON."""
        creds_file = tmp_path / ".credentials.json"
        creds_file.write_text("not valid json {")

        monkeypatch.setattr(
            "agentstream.remote.claude_credentials.CLAUDE_CREDENTIALS_FILE", creds_file
        )
        assert _read_from_file() is None


class TestReadFromKeychain:
    """Tests for _read_from_keychain function."""

    def test_returns_none_on_non_darwin(self, monkeypatch):
        """Test returns None when not on macOS."""
        monkeypatch.setattr(sys, "platform", "linux")
        assert _read_from_keychain() is None

    @pytest.mark.skipif(sys.platform != "darwin", reason="macOS only test")
    def test_returns_none_on_keychain_error(self, monkeypatch):
        """Test returns None when keychain command fails."""
        # Mock subprocess to simulate keychain failure
        mock_result = mock.Mock()
        mock_result.returncode = 44  # Item not found
        mock_result.stdout = ""

        with mock.patch("subprocess.run", return_value=mock_result):
            assert _read_from_keychain() is None

    @pytest.mark.skipif(sys.platform != "darwin", reason="macOS only test")
    def test_returns_parsed_data_on_success(self):
        """Test returns parsed data when keychain read succeeds."""
        creds_data = {
            "claudeAiOauth": {
                "accessToken": "sk-ant-oat01-test",
                "expiresAt": 1748276587173,
            }
        }

        mock_result = mock.Mock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps(creds_data)

        with mock.patch("subprocess.run", return_value=mock_result):
            result = _read_from_keychain()
            assert result == creds_data


class TestReadOrganizationUuid:
    """Tests for _read_organization_uuid function."""

    def test_returns_none_when_config_missing(self, tmp_path, monkeypatch):
        """Test returns None when config file doesn't exist."""
        monkeypatch.setattr(
            "agentstream.remote.claude_credentials.CLAUDE_CONFIG_FILE",
            tmp_path / "nonexistent.json",
        )
        assert _read_organization_uuid() is None

    def test_returns_uuid_when_present(self, tmp_path, monkeypatch):
        """Test returns UUID when present in config."""
        config_file = tmp_path / ".claude.json"
        config_data = {"oauthAccount": {"organizationUuid": "test-org-uuid-123"}}
        config_file.write_text(json.dumps(config_data))

        monkeypatch.setattr("agentstream.remote.claude_credentials.CLAUDE_CONFIG_FILE", config_file)
        assert _read_organization_uuid() == "test-org-uuid-123"


class TestReadClaudeCredentials:
    """Tests for read_claude_credentials function."""

    def test_returns_none_when_no_credentials(self, tmp_path, monkeypatch):
        """Test returns None when no credentials are found."""
        monkeypatch.setattr(
            "agentstream.remote.claude_credentials.CLAUDE_CREDENTIALS_FILE",
            tmp_path / "nonexistent",
        )
        monkeypatch.setattr(sys, "platform", "linux")  # Skip keychain

        assert read_claude_credentials() is None

    def test_returns_credentials_from_file(self, tmp_path, monkeypatch):
        """Test returns ClaudeCredentials from file."""
        creds_file = tmp_path / ".credentials.json"
        config_file = tmp_path / ".claude.json"

        creds_data = {
            "claudeAiOauth": {
                "accessToken": "sk-ant-oat01-test",
                "refreshToken": "sk-ant-ort01-refresh",
                "expiresAt": 1748276587173,
                "scopes": ["user:inference", "user:profile"],
            }
        }
        creds_file.write_text(json.dumps(creds_data))

        config_data = {"oauthAccount": {"organizationUuid": "org-123"}}
        config_file.write_text(json.dumps(config_data))

        monkeypatch.setattr(
            "agentstream.remote.claude_credentials.CLAUDE_CREDENTIALS_FILE", creds_file
        )
        monkeypatch.setattr("agentstream.remote.claude_credentials.CLAUDE_CONFIG_FILE", config_file)
        monkeypatch.setattr(sys, "platform", "linux")  # Skip keychain

        result = read_claude_credentials()

        assert result is not None
        assert result.access_token == "sk-ant-oat01-test"
        assert result.refresh_token == "sk-ant-ort01-refresh"
        assert result.expires_at == 1748276587173
        assert result.scopes == ["user:inference", "user:profile"]
        assert result.organization_uuid == "org-123"

    def test_returns_none_when_no_oauth_section(self, tmp_path, monkeypatch):
        """Test returns None when claudeAiOauth section is missing."""
        creds_file = tmp_path / ".credentials.json"
        creds_file.write_text(json.dumps({"other": "data"}))

        monkeypatch.setattr(
            "agentstream.remote.claude_credentials.CLAUDE_CREDENTIALS_FILE", creds_file
        )
        monkeypatch.setattr(sys, "platform", "linux")

        assert read_claude_credentials() is None


class TestHasClaudeCredentials:
    """Tests for has_claude_credentials function."""

    def test_returns_true_when_file_exists(self, tmp_path, monkeypatch):
        """Test returns True when credentials file exists."""
        creds_file = tmp_path / ".credentials.json"
        creds_file.write_text("{}")

        monkeypatch.setattr(
            "agentstream.remote.claude_credentials.CLAUDE_CREDENTIALS_FILE", creds_file
        )
        monkeypatch.setattr(sys, "platform", "linux")  # Skip keychain check

        assert has_claude_credentials() is True

    def test_returns_false_when_no_credentials(self, tmp_path, monkeypatch):
        """Test returns False when no credentials exist."""
        monkeypatch.setattr(
            "agentstream.remote.claude_credentials.CLAUDE_CREDENTIALS_FILE",
            tmp_path / "nonexistent",
        )
        monkeypatch.setattr(sys, "platform", "linux")

        assert has_claude_credentials() is False
