"""Tests for web sessions client and poller."""

from __future__ import annotations

import time
from datetime import UTC, datetime
from unittest import mock

import httpx
import pytest

from agentstream.remote.claude_credentials import ClaudeCredentials
from agentstream.remote.web_sessions import (
    DEFAULT_POLL_INTERVAL_SECONDS,
    WebSession,
    WebSessionPoller,
    WebSessionsClient,
)


class TestWebSession:
    """Tests for WebSession dataclass."""

    def test_is_empty_true_when_no_entries(self):
        """Test is_empty returns True when entries list is empty."""
        session = WebSession(
            id="test-id",
            name="Test Session",
            project_path="/path/to/project",
            created_at=None,
            updated_at=None,
            model="claude-3-opus",
            git_repo=None,
            git_branch=None,
            entries=[],
        )
        assert session.is_empty is True

    def test_is_empty_false_when_has_entries(self):
        """Test is_empty returns False when entries exist."""
        session = WebSession(
            id="test-id",
            name="Test Session",
            project_path="/path/to/project",
            created_at=None,
            updated_at=None,
            model="claude-3-opus",
            git_repo=None,
            git_branch=None,
            entries=[{"type": "message", "content": "Hello"}],
        )
        assert session.is_empty is False


class TestWebSessionsClient:
    """Tests for WebSessionsClient."""

    def create_valid_credentials(self, expires_in_seconds: float = 3600) -> ClaudeCredentials:
        """Create valid test credentials."""
        return ClaudeCredentials(
            access_token="sk-ant-oat01-test-token",
            refresh_token="sk-ant-ort01-refresh",
            expires_at=int((time.time() + expires_in_seconds) * 1000),
            scopes=["user:inference"],
            organization_uuid="org-123",
        )

    def test_credentials_property_reads_from_storage(self):
        """Test credentials property reads from storage when not set."""
        client = WebSessionsClient(credentials=None)

        with mock.patch("agentstream.remote.web_sessions.read_claude_credentials") as mock_read:
            mock_read.return_value = self.create_valid_credentials()
            creds = client.credentials
            assert creds is not None
            mock_read.assert_called_once()

    def test_credentials_returns_cached(self):
        """Test credentials returns cached credentials."""
        creds = self.create_valid_credentials()
        client = WebSessionsClient(credentials=creds)
        assert client.credentials is creds

    def test_get_headers_raises_without_credentials(self):
        """Test _get_headers raises ValueError without credentials."""
        client = WebSessionsClient(credentials=None)

        with (
            mock.patch(
                "agentstream.remote.web_sessions.read_claude_credentials", return_value=None
            ),
            pytest.raises(ValueError, match="No Claude credentials"),
        ):
            client._get_headers()

    def test_get_headers_includes_auth(self):
        """Test _get_headers includes authorization header."""
        creds = self.create_valid_credentials()
        client = WebSessionsClient(credentials=creds)

        headers = client._get_headers()

        assert headers["Authorization"] == f"Bearer {creds.access_token}"
        assert headers["anthropic-version"] == "2023-06-01"
        assert headers["anthropic-beta"] == "ccr-byoc-2025-07-29"
        assert headers["x-organization-uuid"] == "org-123"

    @pytest.mark.asyncio
    async def test_list_sessions_raises_without_credentials(self):
        """Test list_sessions raises ValueError without credentials."""
        client = WebSessionsClient(credentials=None)

        with (
            mock.patch(
                "agentstream.remote.web_sessions.read_claude_credentials", return_value=None
            ),
            pytest.raises(ValueError, match="No Claude credentials"),
        ):
            await client.list_sessions()

    @pytest.mark.asyncio
    async def test_list_sessions_raises_on_expired_credentials(self):
        """Test list_sessions raises ValueError on expired credentials."""
        expired_creds = ClaudeCredentials(
            access_token="expired-token",
            refresh_token=None,
            expires_at=int((time.time() - 3600) * 1000),  # Expired 1 hour ago
            scopes=["user:inference"],
        )
        client = WebSessionsClient(credentials=expired_creds)

        with (
            mock.patch(
                "agentstream.remote.web_sessions.read_claude_credentials",
                return_value=None,  # Refresh attempt returns None
            ),
            pytest.raises(ValueError, match="expired"),
        ):
            await client.list_sessions()

    @pytest.mark.asyncio
    async def test_list_sessions_parses_response(self):
        """Test list_sessions correctly parses API response with new format."""
        creds = self.create_valid_credentials()
        client = WebSessionsClient(credentials=creds)

        # This matches the actual Anthropic API response format
        mock_response_data = {
            "data": [
                {
                    "id": "session_01Wapx37X7KbxGs2x99Vgymy",
                    "created_at": "2026-02-01T01:41:48.916588Z",
                    "session_context": {
                        "cwd": "/path/to/project",
                        "model": "claude-opus-4-5-20251101",
                        "outcomes": [
                            {
                                "type": "git_repository",
                                "git_info": {
                                    "type": "github",
                                    "repo": "owner/repo",
                                    "branches": ["main", "feature-branch"],
                                },
                            }
                        ],
                    },
                },
                {
                    "id": "session_02Bqpy48Y8LcyHt3y00Wvznz",
                    "created_at": "2026-01-31T10:00:00Z",
                    "session_context": {},
                },
            ],
            "first_id": "session_01Wapx37X7KbxGs2x99Vgymy",
            "last_id": "session_02Bqpy48Y8LcyHt3y00Wvznz",
            "has_more": False,
        }

        mock_response = mock.Mock()
        mock_response.status_code = 200
        mock_response.json = mock.Mock(return_value=mock_response_data)
        mock_response.raise_for_status = mock.Mock()

        with mock.patch("httpx.AsyncClient") as mock_client_class:
            mock_client_instance = mock.AsyncMock()
            mock_client_instance.get = mock.AsyncMock(return_value=mock_response)
            mock_client_class.return_value.__aenter__ = mock.AsyncMock(
                return_value=mock_client_instance
            )
            mock_client_class.return_value.__aexit__ = mock.AsyncMock()

            sessions = await client.list_sessions()

        assert len(sessions) == 2
        assert sessions[0].id == "session_01Wapx37X7KbxGs2x99Vgymy"
        assert sessions[0].project_path == "/path/to/project"
        assert sessions[0].model == "claude-opus-4-5-20251101"
        assert sessions[0].git_repo == "github.com/owner/repo"
        assert sessions[0].git_branch == "main"
        assert sessions[1].id == "session_02Bqpy48Y8LcyHt3y00Wvznz"

    def test_parse_session_returns_none_without_id(self):
        """Test _parse_session returns None when ID is missing."""
        client = WebSessionsClient(credentials=self.create_valid_credentials())
        result = client._parse_session({"name": "No ID Session"})
        assert result is None

    def test_parse_session_handles_new_api_format(self):
        """Test _parse_session handles the new API format with session_context."""
        client = WebSessionsClient(credentials=self.create_valid_credentials())

        data = {
            "id": "session_01Wapx37X7KbxGs2x99Vgymy",
            "created_at": "2026-02-01T01:41:48.916588Z",
            "session_context": {
                "cwd": "/path/to/project",
                "model": "claude-opus-4-5-20251101",
                "outcomes": [
                    {
                        "type": "git_repository",
                        "git_info": {
                            "type": "github",
                            "repo": "owner/repo",
                            "branches": ["feature-branch"],
                        },
                    }
                ],
            },
            "entries": [{"type": "message"}],
        }

        session = client._parse_session(data)

        assert session is not None
        assert session.id == "session_01Wapx37X7KbxGs2x99Vgymy"
        assert session.project_path == "/path/to/project"
        assert session.model == "claude-opus-4-5-20251101"
        assert session.git_repo == "github.com/owner/repo"
        assert session.git_branch == "feature-branch"
        assert session.source == "web"
        assert len(session.entries) == 1

    def test_parse_session_handles_metadata_fallback(self):
        """Test _parse_session falls back to metadata format."""
        client = WebSessionsClient(credentials=self.create_valid_credentials())

        # Old format with metadata instead of session_context
        data = {
            "id": "test-session-id",
            "name": "Test Session",
            "created_at": "2025-01-15T10:00:00Z",
            "updated_at": "2025-01-15T12:00:00Z",
            "metadata": {
                "cwd": "/path/to/project",
                "model": "claude-3-opus",
                "git_repo": "https://github.com/test/repo",
                "git_branch": "main",
            },
            "entries": [{"type": "message"}],
        }

        session = client._parse_session(data)

        assert session is not None
        assert session.id == "test-session-id"
        assert session.name == "Test Session"
        assert session.project_path == "/path/to/project"
        assert session.model == "claude-3-opus"
        assert session.git_repo == "https://github.com/test/repo"
        assert session.git_branch == "main"
        assert session.source == "web"
        assert len(session.entries) == 1

    @pytest.mark.asyncio
    async def test_get_session_events_returns_events(self):
        """Test get_session_events returns events list."""
        creds = self.create_valid_credentials()
        client = WebSessionsClient(credentials=creds)

        mock_response_data = {
            "data": [
                {
                    "uuid": "event-uuid-1",
                    "type": "user",
                    "data": {"message": {"content": "Hello", "role": "user"}},
                },
                {
                    "uuid": "event-uuid-2",
                    "type": "assistant",
                    "data": {"message": {"content": "Hi there!", "role": "assistant"}},
                },
            ],
            "first_id": "event-uuid-1",
            "last_id": "event-uuid-2",
            "has_more": False,
        }

        mock_response = mock.Mock()
        mock_response.status_code = 200
        mock_response.json = mock.Mock(return_value=mock_response_data)
        mock_response.raise_for_status = mock.Mock()

        with mock.patch("httpx.AsyncClient") as mock_client_class:
            mock_client_instance = mock.AsyncMock()
            mock_client_instance.get = mock.AsyncMock(return_value=mock_response)
            mock_client_class.return_value.__aenter__ = mock.AsyncMock(
                return_value=mock_client_instance
            )
            mock_client_class.return_value.__aexit__ = mock.AsyncMock()

            events = await client.get_session_events("session-123")

        assert len(events) == 2
        assert events[0]["uuid"] == "event-uuid-1"
        assert events[0]["type"] == "user"
        assert events[1]["uuid"] == "event-uuid-2"

    @pytest.mark.asyncio
    async def test_get_session_events_returns_empty_on_404(self):
        """Test get_session_events returns empty list on 404."""
        creds = self.create_valid_credentials()
        client = WebSessionsClient(credentials=creds)

        mock_response = mock.Mock()
        mock_response.status_code = 404

        with mock.patch("httpx.AsyncClient") as mock_client_class:
            mock_client_instance = mock.AsyncMock()
            mock_client_instance.get = mock.AsyncMock(return_value=mock_response)
            mock_client_class.return_value.__aenter__ = mock.AsyncMock(
                return_value=mock_client_instance
            )
            mock_client_class.return_value.__aexit__ = mock.AsyncMock()

            events = await client.get_session_events("nonexistent-session")

        assert events == []

    @pytest.mark.asyncio
    async def test_get_session_events_paginates(self):
        """Test get_session_events paginates through all events."""
        creds = self.create_valid_credentials()
        client = WebSessionsClient(credentials=creds)

        # First page response
        page1_response = mock.Mock()
        page1_response.status_code = 200
        page1_response.json = mock.Mock(
            return_value={
                "data": [{"uuid": "event-1", "type": "user"}],
                "first_id": "event-1",
                "last_id": "event-1",
                "has_more": True,
            }
        )
        page1_response.raise_for_status = mock.Mock()

        # Second page response
        page2_response = mock.Mock()
        page2_response.status_code = 200
        page2_response.json = mock.Mock(
            return_value={
                "data": [{"uuid": "event-2", "type": "assistant"}],
                "first_id": "event-2",
                "last_id": "event-2",
                "has_more": False,
            }
        )
        page2_response.raise_for_status = mock.Mock()

        with mock.patch("httpx.AsyncClient") as mock_client_class:
            mock_client_instance = mock.AsyncMock()
            mock_client_instance.get = mock.AsyncMock(side_effect=[page1_response, page2_response])
            mock_client_class.return_value.__aenter__ = mock.AsyncMock(
                return_value=mock_client_instance
            )
            mock_client_class.return_value.__aexit__ = mock.AsyncMock()

            events = await client.get_session_events("session-123", page_size=10)

            # Verify both pages were fetched
            assert mock_client_instance.get.call_count == 2

            # Verify after_id was used for second request
            second_call_args = mock_client_instance.get.call_args_list[1]
            assert second_call_args[1]["params"]["after_id"] == "event-1"

            # Verify all events are returned
            assert len(events) == 2
            assert events[0]["uuid"] == "event-1"
            assert events[1]["uuid"] == "event-2"


class TestWebSessionPoller:
    """Tests for WebSessionPoller."""

    def create_mock_client(self, sessions: list[WebSession] | None = None) -> WebSessionsClient:
        """Create a mock WebSessionsClient."""
        mock_client = mock.Mock(spec=WebSessionsClient)

        # Set up credentials
        mock_creds = ClaudeCredentials(
            access_token="test-token",
            refresh_token=None,
            expires_at=int((time.time() + 3600) * 1000),
            scopes=["user:inference"],
        )
        mock_client.credentials = mock_creds

        # Set up list_sessions
        async def mock_list_sessions(limit=50):
            return sessions or []

        mock_client.list_sessions = mock_list_sessions

        return mock_client

    def test_default_poll_interval(self):
        """Test default poll interval is 30 minutes."""
        poller = WebSessionPoller()
        assert poller._poll_interval == DEFAULT_POLL_INTERVAL_SECONDS
        assert poller._poll_interval == 1800

    def test_is_enabled_default_true(self):
        """Test polling is enabled by default."""
        poller = WebSessionPoller()
        assert poller.is_enabled is True

    def test_enable_disable(self):
        """Test enable and disable methods."""
        poller = WebSessionPoller()

        poller.disable("test reason")
        assert poller.is_enabled is False

        poller.enable()
        assert poller.is_enabled is True

    def test_should_poll_false_when_disabled(self):
        """Test should_poll returns False when disabled."""
        poller = WebSessionPoller()
        poller.disable("test")
        assert poller.should_poll is False

    def test_should_poll_true_on_first_poll(self):
        """Test should_poll returns True before first poll."""
        # Use a short interval to avoid issues with time.monotonic() on fresh systems
        poller = WebSessionPoller(poll_interval=0.001)
        assert poller.should_poll is True

    def test_should_poll_respects_interval(self):
        """Test should_poll respects poll interval."""
        poller = WebSessionPoller(poll_interval=1.0)

        # First poll should always be allowed
        assert poller.should_poll is True

        # Simulate poll
        poller._last_poll_time = time.monotonic()

        # Should not poll immediately after
        assert poller.should_poll is False

        # Wait for interval
        poller._last_poll_time = time.monotonic() - 2.0
        assert poller.should_poll is True

    def test_seconds_until_next_poll(self):
        """Test seconds_until_next_poll calculation."""
        poller = WebSessionPoller(poll_interval=60.0)
        poller._last_poll_time = time.monotonic() - 30.0  # 30 seconds ago

        remaining = poller.seconds_until_next_poll
        assert 29 < remaining < 31  # Approximately 30 seconds remaining

    @pytest.mark.asyncio
    async def test_poll_returns_empty_when_disabled(self):
        """Test poll returns empty list when disabled."""
        poller = WebSessionPoller()
        poller.disable("test")

        result = await poller.poll()
        assert result == []

    @pytest.mark.asyncio
    async def test_poll_returns_empty_without_credentials(self):
        """Test poll returns empty list without credentials."""
        mock_client = mock.Mock(spec=WebSessionsClient)
        mock_client.credentials = None

        poller = WebSessionPoller(client=mock_client)
        result = await poller.poll()
        assert result == []

    @pytest.mark.asyncio
    async def test_poll_returns_new_sessions(self):
        """Test poll returns new sessions."""
        session1 = WebSession(
            id="session-1",
            name="Session 1",
            project_path=None,
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
            model=None,
            git_repo=None,
            git_branch=None,
        )
        mock_client = self.create_mock_client(sessions=[session1])

        poller = WebSessionPoller(client=mock_client)
        result = await poller.poll()

        assert len(result) == 1
        assert result[0].id == "session-1"

    @pytest.mark.asyncio
    async def test_poll_filters_known_sessions(self):
        """Test poll filters out already known sessions."""
        old_time = datetime.now(UTC)

        session1 = WebSession(
            id="session-1",
            name="Session 1",
            project_path=None,
            created_at=old_time,
            updated_at=old_time,
            model=None,
            git_repo=None,
            git_branch=None,
        )
        mock_client = self.create_mock_client(sessions=[session1])

        poller = WebSessionPoller(client=mock_client)

        # First poll - should return the session
        result1 = await poller.poll()
        assert len(result1) == 1

        # Second poll - should return empty (session unchanged)
        poller._last_poll_time = 0  # Reset to allow immediate poll
        result2 = await poller.poll()
        assert len(result2) == 0

    @pytest.mark.asyncio
    async def test_poll_handles_errors_gracefully(self):
        """Test poll handles errors gracefully."""
        mock_client = mock.Mock(spec=WebSessionsClient)
        mock_client.credentials = ClaudeCredentials(
            access_token="test",
            refresh_token=None,
            expires_at=int((time.time() + 3600) * 1000),
            scopes=[],
        )

        async def raise_error(limit=50):
            raise httpx.HTTPError("Connection failed")

        mock_client.list_sessions = raise_error

        poller = WebSessionPoller(client=mock_client)
        result = await poller.poll()

        assert result == []
        assert poller._consecutive_failures == 1

    def test_reset_clears_state(self):
        """Test reset clears all state."""
        poller = WebSessionPoller()
        poller._known_sessions["test"] = time.time()
        poller._consecutive_failures = 5
        poller._last_poll_time = time.monotonic()

        poller.reset()

        assert len(poller._known_sessions) == 0
        assert poller._consecutive_failures == 0
        assert poller._last_poll_time == 0

    def test_mark_session_synced(self):
        """Test mark_session_synced updates known sessions."""
        poller = WebSessionPoller()
        timestamp = time.time()

        poller.mark_session_synced("session-1", timestamp)

        assert poller._known_sessions["session-1"] == timestamp
