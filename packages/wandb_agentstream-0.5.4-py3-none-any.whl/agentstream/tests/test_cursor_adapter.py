"""Tests for CursorAdapter.

This module tests the Cursor IDE adapter which reads session logs from
Cursor's VSCode-based SQLite storage.
"""

import json
import sqlite3
import tempfile
from pathlib import Path

import pytest

import agentstream.adapters.cursor as cursor_module
from agentstream.adapters.base import Session
from agentstream.adapters.cursor import (
    CursorAdapter,
    _parse_ms_timestamp,
    _uri_to_path,
)
from agentstream.events import (
    CustomEvent,
    ReasoningMessageChunkEvent,
    Role,
    RunFinishedEvent,
    RunStartedEvent,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def adapter():
    """Create a CursorAdapter instance."""
    return CursorAdapter()


@pytest.fixture
def temp_cursor_dirs():
    """Create a temporary Cursor-like directory structure for testing.

    Yields:
        Tuple of (workspace_dir, cursor_user_dir, project_dir) paths
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)

        # Create project directory
        project_dir = tmpdir_path / "test_project"
        project_dir.mkdir()

        # Create Cursor user directory structure
        cursor_user = tmpdir_path / "cursor_user"
        cursor_user.mkdir()

        # Create workspaceStorage with a hash directory
        workspace_storage = cursor_user / "workspaceStorage"
        workspace_storage.mkdir()
        workspace_hash_dir = workspace_storage / "abc123hash"
        workspace_hash_dir.mkdir()

        # Create workspace.json pointing to project
        workspace_json = workspace_hash_dir / "workspace.json"
        workspace_json.write_text(json.dumps({"folder": f"file://{project_dir}"}))

        # Create globalStorage directory
        global_storage = cursor_user / "globalStorage"
        global_storage.mkdir()

        yield workspace_hash_dir, cursor_user, project_dir


def create_workspace_state_db(db_path: Path, composer_sessions: list[dict]) -> None:
    """Create a workspace state database with composer data.

    Args:
        db_path: Path to create the database at
        composer_sessions: List of composer session dictionaries
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ItemTable (
            key TEXT PRIMARY KEY,
            value BLOB
        )
    """)

    cursor.execute(
        "INSERT OR REPLACE INTO ItemTable (key, value) VALUES (?, ?)",
        ("composer.composerData", json.dumps(composer_sessions)),
    )

    conn.commit()
    conn.close()


def create_global_state_db(db_path: Path, bubbles: dict[str, list[dict]]) -> None:
    """Create a global state database with bubble data.

    Args:
        db_path: Path to create the database at
        bubbles: Dictionary mapping composer_id to list of bubble dictionaries
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS cursorDiskKV (
            key TEXT PRIMARY KEY,
            value BLOB
        )
    """)

    for composer_id, bubble_list in bubbles.items():
        for bubble in bubble_list:
            bubble_id = bubble.get("bubbleId", "unknown")
            key = f"bubbleId:{composer_id}:{bubble_id}"
            cursor.execute(
                "INSERT OR REPLACE INTO cursorDiskKV (key, value) VALUES (?, ?)",
                (key, json.dumps(bubble)),
            )

    conn.commit()
    conn.close()


# =============================================================================
# Test: Helper Functions
# =============================================================================


class TestParseTimestamp:
    """Tests for _parse_ms_timestamp helper function."""

    def test_valid_millisecond_timestamp(self):
        """Should return millisecond timestamps as-is."""
        ts = _parse_ms_timestamp(1704067200000, 0)
        assert ts == 1704067200000

    def test_second_timestamp_converted_to_ms(self):
        """Timestamps in seconds should be converted to milliseconds."""
        # Timestamps < 1e12 are treated as seconds
        ts = _parse_ms_timestamp(1704067200, 0)
        assert ts == 1704067200000

    def test_string_timestamp(self):
        """String timestamps should be parsed."""
        ts = _parse_ms_timestamp("1704067200000", 0)
        assert ts == 1704067200000

    def test_float_timestamp(self):
        """Float timestamps should be converted to int."""
        ts = _parse_ms_timestamp(1704067200000.5, 0)
        assert ts == 1704067200000

    def test_none_returns_fallback(self):
        """None should return fallback value."""
        ts = _parse_ms_timestamp(None, 12345)
        assert ts == 12345

    def test_invalid_string_returns_fallback(self):
        """Invalid string should return fallback value."""
        ts = _parse_ms_timestamp("not-a-number", 12345)
        assert ts == 12345


class TestUriToPath:
    """Tests for _uri_to_path helper function."""

    def test_valid_file_uri(self):
        """Should convert file:// URI to Path."""
        path = _uri_to_path("file:///Users/test/project")
        assert path == Path("/Users/test/project")

    def test_uri_with_encoded_spaces(self):
        """Should decode URL-encoded characters."""
        path = _uri_to_path("file:///Users/test/my%20project")
        assert path == Path("/Users/test/my project")

    def test_non_file_uri_returns_none(self):
        """Non-file URIs should return None."""
        assert _uri_to_path("https://example.com") is None
        assert _uri_to_path("not-a-uri") is None

    def test_empty_uri_returns_none(self):
        """Empty string should return None."""
        assert _uri_to_path("") is None


# =============================================================================
# Test: Session Discovery
# =============================================================================


class TestWorkspaceDiscovery:
    """Tests for workspace and session discovery."""

    def test_finds_workspace_by_project_path(self, adapter, temp_cursor_dirs):
        """Should find workspace matching project directory."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        # Create workspace state DB with one session
        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        # Create global state DB (empty but required)
        create_global_state_db(cursor_user / "globalStorage" / "state.vscdb", {})

        # Monkey-patch the user directory function for testing

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            assert len(sessions) == 1
            assert sessions[0].id == "session-001"
            assert sessions[0].format == "cursor"
        finally:
            cursor_module._get_cursor_user_dir = original_fn


class TestSessionDiscovery:
    """Tests for extracting sessions from composerData."""

    def test_extracts_multiple_sessions(self, adapter, temp_cursor_dirs):
        """Should extract all sessions from composerData."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "unifiedMode": "agent",
                    "name": "Agent Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                },
                {
                    "composerId": "test-session-002",
                    "unifiedMode": "chat",
                    "name": "Chat Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704068000000,
                },
            ],
        )

        create_global_state_db(cursor_user / "globalStorage" / "state.vscdb", {})

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            assert len(sessions) == 2

            # Sessions should be sorted by modified_at (newest first)
            session_ids = [s.id for s in sessions]
            assert "test-session-001" in session_ids
            assert "test-session-002" in session_ids
        finally:
            cursor_module._get_cursor_user_dir = original_fn


# =============================================================================
# Test: Bubble Parsing
# =============================================================================


class TestBubbleParsingUserMessage:
    """Tests for user message (type 1) parsing."""

    def test_user_message_emits_text_chunk_event(self, adapter, temp_cursor_dirs):
        """User message should produce TextMessageChunkEvent with USER role."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db(
            cursor_user / "globalStorage" / "state.vscdb",
            {
                "test-session-001": [
                    {
                        "bubbleId": "bubble-001",
                        "type": 1,
                        "text": "Hello, help me with this code",
                        "createdAt": 1704067200000,
                    }
                ]
            },
        )

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            assert len(sessions) == 1

            events = list(adapter.read_events(sessions[0]))

            # Find TextMessageChunkEvent with USER role
            user_messages = [
                e for e in events if isinstance(e, TextMessageChunkEvent) and e.role == Role.USER
            ]
            assert len(user_messages) == 1
            assert user_messages[0].delta == "Hello, help me with this code"
            assert user_messages[0].message_id == "bubble-001"
        finally:
            cursor_module._get_cursor_user_dir = original_fn


class TestBubbleParsingAssistantMessage:
    """Tests for assistant message (type 2) parsing."""

    def test_assistant_message_emits_text_chunk_event(self, adapter, temp_cursor_dirs):
        """Assistant message should produce TextMessageChunkEvent with ASSISTANT role."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db(
            cursor_user / "globalStorage" / "state.vscdb",
            {
                "test-session-001": [
                    {
                        "bubbleId": "bubble-002",
                        "type": 2,
                        "text": "I'll help you with that code.",
                        "createdAt": 1704067205000,
                    }
                ]
            },
        )

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            events = list(adapter.read_events(sessions[0]))

            assistant_messages = [
                e
                for e in events
                if isinstance(e, TextMessageChunkEvent) and e.role == Role.ASSISTANT
            ]
            assert len(assistant_messages) == 1
            assert assistant_messages[0].delta == "I'll help you with that code."
            assert assistant_messages[0].message_id == "bubble-002"
        finally:
            cursor_module._get_cursor_user_dir = original_fn


# =============================================================================
# Test: Tool Call Parsing
# =============================================================================


class TestToolCallParsing:
    """Tests for toolFormerData parsing."""

    def test_tool_call_emits_tool_events(self, adapter, temp_cursor_dirs):
        """toolFormerData should produce ToolCallChunkEvent and ToolCallResultEvent."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db(
            cursor_user / "globalStorage" / "state.vscdb",
            {
                "test-session-001": [
                    {
                        "bubbleId": "bubble-002",
                        "type": 2,
                        "text": "I'll edit the file.",
                        "createdAt": 1704067205000,
                        "toolFormerData": {
                            "toolCalls": [
                                {
                                    "id": "call_123",
                                    "name": "edit_file",
                                    "args": {"file": "sort.py", "content": "def sort(): pass"},
                                }
                            ],
                            "toolResults": {
                                "call_123": {"success": True, "message": "File updated"},
                            },
                        },
                    }
                ]
            },
        )

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            events = list(adapter.read_events(sessions[0]))

            # Check ToolCallChunkEvent
            tool_calls = [e for e in events if isinstance(e, ToolCallChunkEvent)]
            assert len(tool_calls) == 1
            assert tool_calls[0].tool_call_id == "call_123"
            assert tool_calls[0].tool_call_name == "edit_file"
            assert "sort.py" in tool_calls[0].delta

            # Check ToolCallResultEvent
            tool_results = [e for e in events if isinstance(e, ToolCallResultEvent)]
            assert len(tool_results) == 1
            assert tool_results[0].tool_call_id == "call_123"
            assert "success" in tool_results[0].result
        finally:
            cursor_module._get_cursor_user_dir = original_fn


# =============================================================================
# Test: Thinking Blocks
# =============================================================================


class TestThinkingBlocks:
    """Tests for allThinkingBlocks parsing."""

    def test_thinking_blocks_emit_reasoning_events(self, adapter, temp_cursor_dirs):
        """allThinkingBlocks should produce ReasoningMessageChunkEvent."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db(
            cursor_user / "globalStorage" / "state.vscdb",
            {
                "test-session-001": [
                    {
                        "bubbleId": "bubble-002",
                        "type": 2,
                        "text": "Here's my solution.",
                        "createdAt": 1704067205000,
                        "allThinkingBlocks": [
                            {"text": "Let me think about the best approach..."},
                            {"thinking": "I should consider edge cases."},
                        ],
                    }
                ]
            },
        )

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            events = list(adapter.read_events(sessions[0]))

            reasoning_events = [e for e in events if isinstance(e, ReasoningMessageChunkEvent)]
            assert len(reasoning_events) == 2
            assert reasoning_events[0].delta == "Let me think about the best approach..."
            assert reasoning_events[1].delta == "I should consider edge cases."
        finally:
            cursor_module._get_cursor_user_dir = original_fn

    def test_string_thinking_blocks_handled(self, adapter, temp_cursor_dirs):
        """String entries in allThinkingBlocks should be handled gracefully."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        # The fixture format uses plain strings in allThinkingBlocks
        create_global_state_db(
            cursor_user / "globalStorage" / "state.vscdb",
            {
                "test-session-001": [
                    {
                        "bubbleId": "bubble-002",
                        "type": 2,
                        "text": "Here's my solution.",
                        "createdAt": 1704067205000,
                        "allThinkingBlocks": ["Let me think about this..."],
                    }
                ]
            },
        )

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            events = list(adapter.read_events(sessions[0]))

            # String entries are skipped since they're not dicts
            reasoning_events = [e for e in events if isinstance(e, ReasoningMessageChunkEvent)]
            # The adapter only processes dict entries in allThinkingBlocks
            assert len(reasoning_events) == 0
        finally:
            cursor_module._get_cursor_user_dir = original_fn


# =============================================================================
# Test: Timestamp Parsing
# =============================================================================


class TestTimestampParsing:
    """Tests for timestamp handling in events."""

    def test_millisecond_timestamp_preserved(self, adapter, temp_cursor_dirs):
        """Millisecond timestamps should be preserved in events."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db(
            cursor_user / "globalStorage" / "state.vscdb",
            {
                "test-session-001": [
                    {
                        "bubbleId": "bubble-001",
                        "type": 1,
                        "text": "Hello",
                        "createdAt": 1704067200000,  # 2024-01-01 00:00:00 UTC
                    },
                    {
                        "bubbleId": "bubble-002",
                        "type": 2,
                        "text": "Hi there",
                        "createdAt": 1704067205000,  # 5 seconds later
                    },
                ]
            },
        )

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            events = list(adapter.read_events(sessions[0]))

            # Find the user and assistant messages
            user_msg = next(
                e for e in events if isinstance(e, TextMessageChunkEvent) and e.role == Role.USER
            )
            assistant_msg = next(
                e
                for e in events
                if isinstance(e, TextMessageChunkEvent) and e.role == Role.ASSISTANT
            )

            assert user_msg.timestamp_ms == 1704067200000
            assert assistant_msg.timestamp_ms == 1704067205000
        finally:
            cursor_module._get_cursor_user_dir = original_fn


# =============================================================================
# Test: Session Metadata
# =============================================================================


class TestSessionMetadata:
    """Tests for session metadata extraction."""

    def test_extracts_lines_added(self, adapter, temp_cursor_dirs):
        """Should extract totalLinesAdded from metadata."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "totalLinesAdded": 50,
                    "totalLinesRemoved": 10,
                    "filesChangedCount": 3,
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db(cursor_user / "globalStorage" / "state.vscdb", {})

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            assert len(sessions) == 1

            metadata = sessions[0].metadata
            assert metadata["totalLinesAdded"] == 50
            assert metadata["totalLinesRemoved"] == 10
            assert metadata["filesChangedCount"] == 3
        finally:
            cursor_module._get_cursor_user_dir = original_fn

    def test_extracts_unified_mode(self, adapter, temp_cursor_dirs):
        """Should extract unifiedMode (agent/chat) from metadata."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "unifiedMode": "agent",
                    "name": "Agent Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db(cursor_user / "globalStorage" / "state.vscdb", {})

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            assert sessions[0].metadata["unifiedMode"] == "agent"
        finally:
            cursor_module._get_cursor_user_dir = original_fn


# =============================================================================
# Test: Empty Session
# =============================================================================


class TestEmptySession:
    """Tests for sessions with no bubbles."""

    def test_empty_session_returns_minimal_events(self, adapter, temp_cursor_dirs):
        """Session with no bubbles should return only run lifecycle events."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "empty-session",
                    "name": "Empty Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704067200000,
                }
            ],
        )

        # Create global state DB with no bubbles for this session
        create_global_state_db(cursor_user / "globalStorage" / "state.vscdb", {})

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            events = list(adapter.read_events(sessions[0]))

            # Empty session yields no events when no bubbles found
            # The adapter returns early if no bubbles are found
            assert len(events) == 0
        finally:
            cursor_module._get_cursor_user_dir = original_fn


# =============================================================================
# Test: Missing Fields
# =============================================================================


class TestMissingFields:
    """Tests for graceful handling of missing optional fields."""

    def test_missing_text_field(self, adapter, temp_cursor_dirs):
        """Should handle bubbles without text field gracefully."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db(
            cursor_user / "globalStorage" / "state.vscdb",
            {
                "test-session-001": [
                    {
                        "bubbleId": "bubble-001",
                        "type": 1,
                        # No 'text' field
                        "createdAt": 1704067200000,
                    }
                ]
            },
        )

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            events = list(adapter.read_events(sessions[0]))

            # Should not crash, but also no TextMessageChunkEvent
            text_events = [e for e in events if isinstance(e, TextMessageChunkEvent)]
            assert len(text_events) == 0
        finally:
            cursor_module._get_cursor_user_dir = original_fn

    def test_missing_timestamp_uses_fallback(self, adapter, temp_cursor_dirs):
        """Should use fallback timestamp when createdAt is missing."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db(
            cursor_user / "globalStorage" / "state.vscdb",
            {
                "test-session-001": [
                    {
                        "bubbleId": "bubble-001",
                        "type": 1,
                        "text": "Hello",
                        # No 'createdAt' field
                    }
                ]
            },
        )

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            events = list(adapter.read_events(sessions[0]))

            # Should not crash and should have events
            user_msgs = [
                e for e in events if isinstance(e, TextMessageChunkEvent) and e.role == Role.USER
            ]
            assert len(user_msgs) == 1
            # Timestamp should be a fallback value (file mtime converted to ms)
            assert user_msgs[0].timestamp_ms > 0
        finally:
            cursor_module._get_cursor_user_dir = original_fn

    def test_missing_bubble_type(self, adapter, temp_cursor_dirs):
        """Should handle bubbles without type field gracefully."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db(
            cursor_user / "globalStorage" / "state.vscdb",
            {
                "test-session-001": [
                    {
                        "bubbleId": "bubble-001",
                        # No 'type' field
                        "text": "Some text",
                        "createdAt": 1704067200000,
                    }
                ]
            },
        )

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            events = list(adapter.read_events(sessions[0]))

            # Should not crash; bubble without type won't emit text events
            text_events = [e for e in events if isinstance(e, TextMessageChunkEvent)]
            assert len(text_events) == 0

            # But should still emit source_entry and run events
            custom_events = [e for e in events if isinstance(e, CustomEvent)]
            assert len(custom_events) >= 1  # At least the source_entry
        finally:
            cursor_module._get_cursor_user_dir = original_fn


# =============================================================================
# Test: Run Events
# =============================================================================


class TestRunEvents:
    """Tests for RUN_STARTED and RUN_FINISHED events."""

    def test_run_started_at_beginning(self, adapter, temp_cursor_dirs):
        """RunStartedEvent should be emitted at the beginning."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db(
            cursor_user / "globalStorage" / "state.vscdb",
            {
                "test-session-001": [
                    {
                        "bubbleId": "bubble-001",
                        "type": 1,
                        "text": "Hello",
                        "createdAt": 1704067200000,
                    }
                ]
            },
        )

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            events = list(adapter.read_events(sessions[0]))

            # First source_entry, then RunStartedEvent
            run_started_events = [e for e in events if isinstance(e, RunStartedEvent)]
            assert len(run_started_events) == 1

            # RunStartedEvent should be near the beginning (after source_entry)
            run_started_idx = events.index(run_started_events[0])
            assert run_started_idx <= 1  # Should be first or second event
        finally:
            cursor_module._get_cursor_user_dir = original_fn

    def test_run_finished_at_end(self, adapter, temp_cursor_dirs):
        """RunFinishedEvent should be emitted at the end."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db(
            cursor_user / "globalStorage" / "state.vscdb",
            {
                "test-session-001": [
                    {
                        "bubbleId": "bubble-001",
                        "type": 1,
                        "text": "Hello",
                        "createdAt": 1704067200000,
                    },
                    {
                        "bubbleId": "bubble-002",
                        "type": 2,
                        "text": "Hi there",
                        "createdAt": 1704067205000,
                    },
                ]
            },
        )

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            events = list(adapter.read_events(sessions[0]))

            run_finished_events = [e for e in events if isinstance(e, RunFinishedEvent)]
            assert len(run_finished_events) == 1

            # RunFinishedEvent should be the last event
            assert events[-1] == run_finished_events[0]
        finally:
            cursor_module._get_cursor_user_dir = original_fn

    def test_run_started_contains_session_info(self, adapter, temp_cursor_dirs):
        """RunStartedEvent should contain session identifiers."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db(
            cursor_user / "globalStorage" / "state.vscdb",
            {
                "test-session-001": [
                    {
                        "bubbleId": "bubble-001",
                        "type": 1,
                        "text": "Hello",
                        "createdAt": 1704067200000,
                    }
                ]
            },
        )

        original_fn = cursor_module._get_cursor_user_dir

        def mock_get_cursor_user_dir() -> Path:
            return cursor_user

        cursor_module._get_cursor_user_dir = mock_get_cursor_user_dir

        try:
            sessions = adapter.discover_sessions(project_dir)
            events = list(adapter.read_events(sessions[0]))

            run_started = next(e for e in events if isinstance(e, RunStartedEvent))
            assert run_started.run_id == "test-session-001"
            assert run_started.thread_id == "test-session-001"
        finally:
            cursor_module._get_cursor_user_dir = original_fn


# =============================================================================
# Test: Adapter Properties
# =============================================================================


class TestAdapterProperties:
    """Tests for adapter property methods."""

    def test_adapter_name(self, adapter):
        """Adapter should have name 'cursor'."""
        assert adapter.name == "cursor"

    def test_write_events_not_implemented(self, adapter):
        """write_events should raise NotImplementedError."""
        with pytest.raises(NotImplementedError) as exc_info:
            adapter.write_events([], None)

        assert "read-only" in str(exc_info.value).lower()


# =============================================================================
# Test: Entry Enrichment
# =============================================================================


def create_global_state_db_with_content(
    db_path: Path,
    bubbles: dict[str, list[dict]],
    content: dict[str, str],
) -> None:
    """Create a global state database with bubbles and content.

    Args:
        db_path: Path to create the database at
        bubbles: Dictionary mapping composer_id to list of bubble dictionaries
        content: Dictionary mapping content IDs to content strings
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS cursorDiskKV (
            key TEXT PRIMARY KEY,
            value BLOB
        )
    """)

    # Add bubbles
    for composer_id, bubble_list in bubbles.items():
        for bubble in bubble_list:
            bubble_id = bubble.get("bubbleId", "unknown")
            key = f"bubbleId:{composer_id}:{bubble_id}"
            cursor.execute(
                "INSERT OR REPLACE INTO cursorDiskKV (key, value) VALUES (?, ?)",
                (key, json.dumps(bubble)),
            )

    # Add content entries
    for content_id, content_value in content.items():
        cursor.execute(
            "INSERT OR REPLACE INTO cursorDiskKV (key, value) VALUES (?, ?)",
            (content_id, content_value),
        )

    conn.commit()
    conn.close()


class TestEnrichEntries:
    """Tests for entry enrichment with computed diffs."""

    def test_enrich_file_creation_computes_diff(self, adapter, temp_cursor_dirs):
        """File creation (afterContentId only) should compute diff from empty."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        # Create workspace state DB
        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        # Create global state DB with content
        after_content_id = "composer.content.abc123"
        create_global_state_db_with_content(
            cursor_user / "globalStorage" / "state.vscdb",
            bubbles={
                "test-session-001": [
                    {
                        "bubbleId": "bubble-001",
                        "type": 2,
                        "createdAt": 1704067200000,
                        "toolFormerData": {
                            "name": "edit_file_v2",
                            "params": json.dumps({"relativeWorkspacePath": "new_file.py"}),
                            "result": json.dumps({"afterContentId": after_content_id}),
                        },
                    }
                ]
            },
            content={
                after_content_id: "def hello():\n    print('Hello')\n",
            },
        )

        session = Session(
            id="test-session-001",
            path=workspace_dir / "state.vscdb",
            format="cursor",
            modified_at=1704070800.0,
            metadata={
                "composerId": "test-session-001",
                "cursor_user": str(cursor_user),
                "workspace_dir": str(workspace_dir),
            },
        )

        # Read entries
        entries = adapter.read_entries(session)
        assert len(entries) == 1

        # Enrich entries
        enriched = adapter.enrich_entries(entries, session)
        assert len(enriched) == 1

        # Check that diff was computed
        entry_content = json.loads(enriched[0]["entry_content"])
        result = entry_content["toolFormerData"]["result"]
        if isinstance(result, str):
            result = json.loads(result)

        assert "_computed_diff" in result
        diff = result["_computed_diff"]
        assert "hunks" in diff
        assert len(diff["hunks"]) > 0

        # All lines should be additions (starts with +)
        for hunk in diff["hunks"]:
            for line in hunk["lines"]:
                if not line.startswith(" "):  # skip context lines
                    assert line.startswith("+"), f"Expected addition, got: {line}"

    def test_enrich_file_edit_computes_diff(self, adapter, temp_cursor_dirs):
        """File edit (beforeContentId + afterContentId) should compute proper diff."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        before_content_id = "composer.content.before123"
        after_content_id = "composer.content.after456"
        create_global_state_db_with_content(
            cursor_user / "globalStorage" / "state.vscdb",
            bubbles={
                "test-session-001": [
                    {
                        "bubbleId": "bubble-001",
                        "type": 2,
                        "createdAt": 1704067200000,
                        "toolFormerData": {
                            "name": "edit_file_v2",
                            "params": json.dumps({"relativeWorkspacePath": "file.py"}),
                            "result": json.dumps(
                                {
                                    "beforeContentId": before_content_id,
                                    "afterContentId": after_content_id,
                                }
                            ),
                        },
                    }
                ]
            },
            content={
                before_content_id: "def hello():\n    print('Hello')\n",
                after_content_id: "def hello():\n    print('Hello, World!')\n",
            },
        )

        session = Session(
            id="test-session-001",
            path=workspace_dir / "state.vscdb",
            format="cursor",
            modified_at=1704070800.0,
            metadata={
                "composerId": "test-session-001",
                "cursor_user": str(cursor_user),
                "workspace_dir": str(workspace_dir),
            },
        )

        entries = adapter.read_entries(session)
        enriched = adapter.enrich_entries(entries, session)

        entry_content = json.loads(enriched[0]["entry_content"])
        result = entry_content["toolFormerData"]["result"]
        if isinstance(result, str):
            result = json.loads(result)

        assert "_computed_diff" in result
        diff = result["_computed_diff"]
        assert "hunks" in diff

        # Should have both removal and addition
        all_lines = []
        for hunk in diff["hunks"]:
            all_lines.extend(hunk["lines"])

        has_removal = any(line.startswith("-") for line in all_lines)
        has_addition = any(line.startswith("+") for line in all_lines)
        assert has_removal, "Expected diff to have removals"
        assert has_addition, "Expected diff to have additions"

    def test_enrich_no_content_ids_unchanged(self, adapter, temp_cursor_dirs):
        """Entries without content IDs should be unchanged."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_workspace_state_db(
            workspace_dir / "state.vscdb",
            [
                {
                    "composerId": "test-session-001",
                    "name": "Test Session",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ],
        )

        create_global_state_db_with_content(
            cursor_user / "globalStorage" / "state.vscdb",
            bubbles={
                "test-session-001": [
                    {
                        "bubbleId": "bubble-001",
                        "type": 1,
                        "text": "Hello",
                        "createdAt": 1704067200000,
                    }
                ]
            },
            content={},
        )

        session = Session(
            id="test-session-001",
            path=workspace_dir / "state.vscdb",
            format="cursor",
            modified_at=1704070800.0,
            metadata={
                "composerId": "test-session-001",
                "cursor_user": str(cursor_user),
                "workspace_dir": str(workspace_dir),
            },
        )

        entries = adapter.read_entries(session)
        original_content = entries[0]["entry_content"]

        enriched = adapter.enrich_entries(entries, session)
        assert enriched[0]["entry_content"] == original_content


class TestComputeDiffHunks:
    """Tests for _compute_diff_hunks helper."""

    def test_identical_content_returns_none(self, adapter):
        """Identical content should return None (no diff)."""
        content = "line1\nline2\nline3\n"
        result = adapter._compute_diff_hunks(content, content)
        assert result is None

    def test_simple_addition(self, adapter):
        """Adding lines should produce addition hunks."""
        old = "line1\nline2\n"
        new = "line1\nline2\nline3\n"
        result = adapter._compute_diff_hunks(old, new)

        assert result is not None
        assert "hunks" in result
        all_lines = []
        for hunk in result["hunks"]:
            all_lines.extend(hunk["lines"])

        assert any("+line3" in line for line in all_lines)

    def test_simple_deletion(self, adapter):
        """Removing lines should produce deletion hunks."""
        old = "line1\nline2\nline3\n"
        new = "line1\nline2\n"
        result = adapter._compute_diff_hunks(old, new)

        assert result is not None
        all_lines = []
        for hunk in result["hunks"]:
            all_lines.extend(hunk["lines"])

        assert any("-line3" in line for line in all_lines)

    def test_modification(self, adapter):
        """Changing content should produce both deletion and addition."""
        old = "hello\n"
        new = "world\n"
        result = adapter._compute_diff_hunks(old, new)

        assert result is not None
        all_lines = []
        for hunk in result["hunks"]:
            all_lines.extend(hunk["lines"])

        has_removal = any(line.startswith("-") for line in all_lines)
        has_addition = any(line.startswith("+") for line in all_lines)
        assert has_removal
        assert has_addition


class TestResolveContentIds:
    """Tests for _resolve_content_ids helper."""

    def test_resolves_existing_content(self, adapter, temp_cursor_dirs):
        """Should resolve content IDs that exist in database."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        content_id = "composer.content.test123"
        content_value = "test file content"

        create_global_state_db_with_content(
            cursor_user / "globalStorage" / "state.vscdb",
            bubbles={},
            content={content_id: content_value},
        )

        global_state_db = cursor_user / "globalStorage" / "state.vscdb"
        result = adapter._resolve_content_ids(global_state_db, {content_id})

        assert content_id in result
        assert result[content_id] == content_value

    def test_missing_content_not_in_result(self, adapter, temp_cursor_dirs):
        """Missing content IDs should not appear in result."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_global_state_db_with_content(
            cursor_user / "globalStorage" / "state.vscdb",
            bubbles={},
            content={},
        )

        global_state_db = cursor_user / "globalStorage" / "state.vscdb"
        result = adapter._resolve_content_ids(global_state_db, {"nonexistent.id"})

        assert "nonexistent.id" not in result

    def test_empty_content_ids_returns_empty(self, adapter, temp_cursor_dirs):
        """Empty content IDs set should return empty dict."""
        workspace_dir, cursor_user, project_dir = temp_cursor_dirs

        create_global_state_db_with_content(
            cursor_user / "globalStorage" / "state.vscdb",
            bubbles={},
            content={"some.id": "content"},
        )

        global_state_db = cursor_user / "globalStorage" / "state.vscdb"
        result = adapter._resolve_content_ids(global_state_db, set())

        assert result == {}
