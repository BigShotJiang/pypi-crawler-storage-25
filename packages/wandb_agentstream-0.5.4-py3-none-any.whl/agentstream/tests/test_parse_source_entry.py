"""Tests for parse_source_entry across all adapters."""

import pytest

from agentstream.adapters.claude import ClaudeAdapter
from agentstream.adapters.codex import CodexAdapter
from agentstream.adapters.cursor import CursorAdapter
from agentstream.adapters.gemini import GeminiAdapter
from agentstream.events import (
    ReasoningMessageChunkEvent,
    Role,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)


class TestClaudeAdapterParseSourceEntry:
    """Tests for ClaudeAdapter.parse_source_entry."""

    @pytest.fixture
    def adapter(self):
        return ClaudeAdapter()

    def test_parse_user_message(self, adapter):
        """Should parse user message entry into TextMessageChunkEvent."""
        entry = {
            "type": "user",
            "uuid": "user-msg-1",
            "timestamp": "2025-01-15T10:00:00Z",
            "message": {"content": "Hello, assistant!"},
            "cwd": "/Users/test/project",
        }
        session_id = "test-session-123"
        entry_index = 5

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, TextMessageChunkEvent)
        assert event.message_id == "user-msg-1"
        assert event.role == Role.USER
        assert event.delta == "Hello, assistant!"
        # Check _source tagging
        assert hasattr(event, "_source")
        assert event._source["entry_index"] == entry_index

    def test_parse_assistant_message_with_text(self, adapter):
        """Should parse assistant message with text content."""
        entry = {
            "type": "assistant",
            "uuid": "asst-msg-1",
            "timestamp": "2025-01-15T10:01:00Z",
            "message": {
                "content": [
                    {"type": "text", "text": "Here is the answer."},
                ],
                "model": "claude-3-5-sonnet-20241022",
                "stop_reason": "end_turn",
            },
        }
        session_id = "test-session-123"
        entry_index = 6

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, TextMessageChunkEvent)
        assert event.message_id == "asst-msg-1"
        assert event.role == Role.ASSISTANT
        assert event.delta == "Here is the answer."
        assert hasattr(event, "_source")
        assert event._source["entry_index"] == entry_index

    def test_parse_assistant_message_with_thinking(self, adapter):
        """Should parse assistant message with thinking blocks."""
        entry = {
            "type": "assistant",
            "uuid": "asst-msg-2",
            "timestamp": "2025-01-15T10:02:00Z",
            "message": {
                "content": [
                    {"type": "thinking", "thinking": "Let me think about this..."},
                    {"type": "text", "text": "I have analyzed the problem."},
                ],
                "model": "claude-3-5-sonnet-20241022",
            },
        }
        session_id = "test-session-123"
        entry_index = 7

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 2
        # First event is thinking
        assert isinstance(events[0], ReasoningMessageChunkEvent)
        assert events[0].delta == "Let me think about this..."
        assert hasattr(events[0], "_source")
        assert events[0]._source["entry_index"] == entry_index

        # Second event is text
        assert isinstance(events[1], TextMessageChunkEvent)
        assert events[1].delta == "I have analyzed the problem."
        assert hasattr(events[1], "_source")
        assert events[1]._source["entry_index"] == entry_index

    def test_parse_assistant_message_with_tool_call(self, adapter):
        """Should parse assistant message with tool use blocks."""
        entry = {
            "type": "assistant",
            "uuid": "asst-msg-3",
            "timestamp": "2025-01-15T10:03:00Z",
            "message": {
                "content": [
                    {
                        "type": "tool_use",
                        "id": "tool-call-1",
                        "name": "Read",
                        "input": {"file_path": "/Users/test/file.py"},
                    }
                ],
                "model": "claude-3-5-sonnet-20241022",
            },
        }
        session_id = "test-session-123"
        entry_index = 8

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, ToolCallChunkEvent)
        assert event.tool_call_id == "tool-call-1"
        assert event.tool_call_name == "Read"
        assert hasattr(event, "_source")
        assert event._source["entry_index"] == entry_index

    def test_parse_user_message_with_tool_result(self, adapter):
        """Should parse user message with tool_result blocks."""
        entry = {
            "type": "user",
            "uuid": "user-msg-2",
            "timestamp": "2025-01-15T10:04:00Z",
            "message": {
                "content": [
                    {
                        "type": "tool_result",
                        "tool_use_id": "tool-call-1",
                        "content": "File contents here",
                    }
                ]
            },
        }
        session_id = "test-session-123"
        entry_index = 9

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, ToolCallResultEvent)
        assert event.tool_call_id == "tool-call-1"
        # Tool results are JSON-serialized with content wrapped in a dict
        assert event.result == '{"content": "File contents here"}'
        assert hasattr(event, "_source")
        assert event._source["entry_index"] == entry_index

    def test_parse_unknown_entry_type_returns_empty(self, adapter):
        """Should return empty list for unknown entry types."""
        entry = {
            "type": "unknown_type",
            "timestamp": "2025-01-15T10:05:00Z",
        }
        session_id = "test-session-123"
        entry_index = 10

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert events == []

    def test_deterministic_message_ids(self, adapter):
        """Should use deterministic message IDs from entry UUID."""
        entry = {
            "type": "user",
            "uuid": "deterministic-uuid-123",
            "timestamp": "2025-01-15T10:06:00Z",
            "message": {"content": "Test"},
        }
        session_id = "test-session-123"
        entry_index = 11

        events1 = adapter.parse_source_entry(entry, entry_index, session_id)
        events2 = adapter.parse_source_entry(entry, entry_index, session_id)

        assert events1[0].message_id == events2[0].message_id
        assert events1[0].message_id == "deterministic-uuid-123"


class TestCodexAdapterParseSourceEntry:
    """Tests for CodexAdapter.parse_source_entry."""

    @pytest.fixture
    def adapter(self):
        return CodexAdapter()

    def test_parse_session_meta(self, adapter):
        """Should return empty list for session_meta entries."""
        entry = {
            "timestamp": "2025-01-15T10:00:00Z",
            "type": "session_meta",
            "payload": {
                "id": "session-123",
                "timestamp": "2025-01-15T10:00:00Z",
                "cwd": "/Users/test/project",
                "originator": "codex",
                "cli_version": "1.0.0",
            },
        }
        session_id = "session-123"
        entry_index = 0

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        # session_meta doesn't produce semantic events
        assert events == []

    def test_parse_user_message(self, adapter):
        """Should parse user message response_item."""
        entry = {
            "timestamp": "2025-01-15T10:01:00Z",
            "type": "response_item",
            "payload": {
                "type": "message",
                "role": "user",
                "content": [{"type": "text", "text": "What is 2+2?"}],
            },
        }
        session_id = "session-123"
        entry_index = 1

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, TextMessageChunkEvent)
        assert event.role == Role.USER
        assert event.delta == "What is 2+2?"
        assert hasattr(event, "_source")
        assert event._source["entry_index"] == entry_index

    def test_parse_assistant_message(self, adapter):
        """Should parse assistant message response_item."""
        entry = {
            "timestamp": "2025-01-15T10:02:00Z",
            "type": "response_item",
            "payload": {
                "type": "message",
                "role": "assistant",
                "content": [{"type": "text", "text": "The answer is 4."}],
            },
        }
        session_id = "session-123"
        entry_index = 2

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, TextMessageChunkEvent)
        assert event.role == Role.ASSISTANT
        assert event.delta == "The answer is 4."
        assert hasattr(event, "_source")
        assert event._source["entry_index"] == entry_index

    def test_parse_reasoning(self, adapter):
        """Should parse reasoning response_item."""
        entry = {
            "timestamp": "2025-01-15T10:03:00Z",
            "type": "response_item",
            "payload": {
                "type": "reasoning",
                "summary": [{"text": "Analyzing the problem"}],
                "encrypted_content": None,
            },
        }
        session_id = "session-123"
        entry_index = 3

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, ReasoningMessageChunkEvent)
        assert event.delta == "Analyzing the problem"
        assert hasattr(event, "_source")
        assert event._source["entry_index"] == entry_index

    def test_parse_function_call(self, adapter):
        """Should parse function_call response_item."""
        entry = {
            "timestamp": "2025-01-15T10:04:00Z",
            "type": "response_item",
            "payload": {
                "type": "function_call",
                "call_id": "call-123",
                "name": "read_file",
                "arguments": '{"file_path": "/path/to/file.py"}',
            },
        }
        session_id = "session-123"
        entry_index = 4

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, ToolCallChunkEvent)
        assert event.tool_call_id == "call-123"
        assert event.tool_call_name == "read_file"
        assert hasattr(event, "_source")
        assert event._source["entry_index"] == entry_index

    def test_parse_function_call_output(self, adapter):
        """Should parse function_call_output response_item."""
        entry = {
            "timestamp": "2025-01-15T10:05:00Z",
            "type": "response_item",
            "payload": {
                "type": "function_call_output",
                "call_id": "call-123",
                "output": "File contents here",
            },
        }
        session_id = "session-123"
        entry_index = 5

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, ToolCallResultEvent)
        assert event.tool_call_id == "call-123"
        assert event.result == "File contents here"
        assert hasattr(event, "_source")
        assert event._source["entry_index"] == entry_index


class TestGeminiAdapterParseSourceEntry:
    """Tests for GeminiAdapter.parse_source_entry."""

    @pytest.fixture
    def adapter(self):
        return GeminiAdapter()

    def test_parse_session_entry_returns_empty(self, adapter):
        """Should return empty list for session envelope."""
        entry = {
            "sessionId": "session-123",
            "projectHash": "abc123",
            "startTime": "2025-01-15T10:00:00Z",
            "lastUpdated": "2025-01-15T10:05:00Z",
            "messages": [],
        }
        session_id = "session-123"
        entry_index = 0

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        # Session envelope doesn't produce semantic events
        assert events == []

    def test_parse_user_message(self, adapter):
        """Should parse user message."""
        entry = {
            "id": "msg-1",
            "timestamp": "2025-01-15T10:01:00Z",
            "type": "user",
            "content": "What is the weather?",
        }
        session_id = "session-123"
        entry_index = 1

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, TextMessageChunkEvent)
        assert event.message_id == "msg-1"
        assert event.role == Role.USER
        assert event.delta == "What is the weather?"
        assert hasattr(event, "_source")
        assert event._source["entry_index"] == entry_index

    def test_parse_assistant_message(self, adapter):
        """Should parse Gemini (assistant) message."""
        entry = {
            "id": "msg-2",
            "timestamp": "2025-01-15T10:02:00Z",
            "type": "gemini",
            "content": "It is sunny today.",
            "model": "gemini-2.0-flash",
        }
        session_id = "session-123"
        entry_index = 2

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, TextMessageChunkEvent)
        assert event.message_id == "msg-2"
        assert event.role == Role.ASSISTANT
        assert event.delta == "It is sunny today."
        assert hasattr(event, "_source")
        assert event._source["entry_index"] == entry_index

    def test_parse_message_with_thoughts(self, adapter):
        """Should parse message with thoughts (reasoning)."""
        entry = {
            "id": "msg-3",
            "timestamp": "2025-01-15T10:03:00Z",
            "type": "gemini",
            "content": "Let me search for that.",
            "thoughts": [
                {
                    "subject": "Planning",
                    "description": "I need to search the codebase",
                    "timestamp": "2025-01-15T10:03:00Z",
                }
            ],
        }
        session_id = "session-123"
        entry_index = 3

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 2
        # First is reasoning
        assert isinstance(events[0], ReasoningMessageChunkEvent)
        assert "Planning" in events[0].delta
        assert hasattr(events[0], "_source")
        assert events[0]._source["entry_index"] == entry_index

        # Second is text
        assert isinstance(events[1], TextMessageChunkEvent)
        assert events[1].delta == "Let me search for that."

    def test_parse_message_with_tool_call(self, adapter):
        """Should parse message with tool calls."""
        entry = {
            "id": "msg-4",
            "timestamp": "2025-01-15T10:04:00Z",
            "type": "gemini",
            "content": "",
            "toolCalls": [
                {
                    "id": "tool-1",
                    "name": "search_files",
                    "args": {"pattern": "*.py"},
                    "status": "success",
                    "timestamp": "2025-01-15T10:04:00Z",
                    "result": [
                        {
                            "functionResponse": {
                                "id": "tool-1",
                                "name": "search_files",
                                "response": {"output": "Found 3 files"},
                            }
                        }
                    ],
                }
            ],
        }
        session_id = "session-123"
        entry_index = 4

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        # Should produce ToolCallChunkEvent and ToolCallResultEvent
        assert len(events) == 2
        assert isinstance(events[0], ToolCallChunkEvent)
        assert events[0].tool_call_id == "tool-1"
        assert events[0].tool_call_name == "search_files"
        assert hasattr(events[0], "_source")
        assert events[0]._source["entry_index"] == entry_index

        assert isinstance(events[1], ToolCallResultEvent)
        assert events[1].tool_call_id == "tool-1"


class TestCursorAdapterParseSourceEntry:
    """Tests for CursorAdapter.parse_source_entry."""

    @pytest.fixture
    def adapter(self):
        return CursorAdapter()

    def test_parse_session_entry_returns_empty(self, adapter):
        """Should return empty list for session metadata."""
        entry = {
            "composerId": "composer-123",
            "name": "Test Session",
            "createdAt": 1705315200000,
            "lastUpdatedAt": 1705318800000,
        }
        session_id = "composer-123"
        entry_index = 0

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        # Session metadata doesn't produce semantic events
        assert events == []

    def test_parse_user_bubble(self, adapter):
        """Should parse user bubble (type=1)."""
        entry = {
            "bubbleId": "bubble-1",
            "type": 1,
            "text": "What is the capital of France?",
            "createdAt": 1705315200000,
        }
        session_id = "composer-123"
        entry_index = 1

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, TextMessageChunkEvent)
        assert event.message_id == "bubble-1"
        assert event.role == Role.USER
        assert event.delta == "What is the capital of France?"
        assert hasattr(event, "_source")
        assert event._source["entry_index"] == entry_index

    def test_parse_assistant_bubble(self, adapter):
        """Should parse assistant bubble (type=2)."""
        entry = {
            "bubbleId": "bubble-2",
            "type": 2,
            "text": "The capital of France is Paris.",
            "createdAt": 1705315260000,
            "model": "gpt-4",
        }
        session_id = "composer-123"
        entry_index = 2

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, TextMessageChunkEvent)
        assert event.message_id == "bubble-2"
        assert event.role == Role.ASSISTANT
        assert event.delta == "The capital of France is Paris."
        assert hasattr(event, "_source")
        assert event._source["entry_index"] == entry_index

    def test_parse_bubble_with_thinking(self, adapter):
        """Should parse bubble with thinking blocks."""
        entry = {
            "bubbleId": "bubble-3",
            "type": 2,
            "text": "Let me help with that.",
            "createdAt": 1705315320000,
            "allThinkingBlocks": [{"text": "I should search the codebase first"}],
        }
        session_id = "composer-123"
        entry_index = 3

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        assert len(events) == 2
        # First is reasoning
        assert isinstance(events[0], ReasoningMessageChunkEvent)
        assert events[0].delta == "I should search the codebase first"
        assert hasattr(events[0], "_source")
        assert events[0]._source["entry_index"] == entry_index

        # Second is text
        assert isinstance(events[1], TextMessageChunkEvent)
        assert events[1].delta == "Let me help with that."

    def test_parse_bubble_with_tool_call_direct_structure(self, adapter):
        """Should parse bubble with toolFormerData (direct structure)."""
        entry = {
            "bubbleId": "bubble-4",
            "type": 2,
            "createdAt": 1705315380000,
            "toolFormerData": {
                "name": "read_file",
                "params": '{"file_path": "/path/to/file.py"}',
                "toolCallId": "tc-1",
                "result": "File contents",
            },
        }
        session_id = "composer-123"
        entry_index = 4

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        # Should produce ToolCallChunkEvent and ToolCallResultEvent
        assert len(events) >= 1
        assert isinstance(events[0], ToolCallChunkEvent)
        assert events[0].tool_call_id == "tc-1"
        assert events[0].tool_call_name == "read_file"
        assert hasattr(events[0], "_source")
        assert events[0]._source["entry_index"] == entry_index

    def test_parse_bubble_with_tool_call_nested_structure(self, adapter):
        """Should parse bubble with toolFormerData (nested structure)."""
        entry = {
            "bubbleId": "bubble-5",
            "type": 2,
            "createdAt": 1705315440000,
            "toolFormerData": {
                "toolCalls": [
                    {
                        "id": "tc-2",
                        "name": "write_file",
                        "args": {"file_path": "/path/to/output.txt", "content": "Hello"},
                    }
                ],
                "toolResults": {"tc-2": "Success"},
            },
        }
        session_id = "composer-123"
        entry_index = 5

        events = adapter.parse_source_entry(entry, entry_index, session_id)

        # Should produce ToolCallChunkEvent and ToolCallResultEvent
        assert len(events) >= 1
        assert isinstance(events[0], ToolCallChunkEvent)
        assert events[0].tool_call_id == "tc-2"
        assert events[0].tool_call_name == "write_file"
        assert hasattr(events[0], "_source")
        assert events[0]._source["entry_index"] == entry_index
