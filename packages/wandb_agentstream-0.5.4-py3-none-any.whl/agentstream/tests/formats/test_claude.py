# tests/formats/test_claude.py
import json

from agentstream.formats.claude import (
    AssistantMessage,
    ClaudeMessageMeta,
    ClaudeSessionMeta,
    ClaudeThinkingMeta,
    ClaudeUsage,
    ContentBlock,
    LogEntry,
    SystemMessage,
    UserMessage,
)


class TestClaudeUsage:
    def test_default_values(self):
        usage = ClaudeUsage()
        assert usage.input_tokens == 0
        assert usage.output_tokens == 0

    def test_with_values(self):
        usage = ClaudeUsage(
            input_tokens=100,
            output_tokens=50,
            cache_creation_input_tokens=10,
            cache_read_input_tokens=5,
        )
        assert usage.input_tokens == 100


class TestClaudeMessageMeta:
    def test_all_fields_optional(self):
        meta = ClaudeMessageMeta()
        assert meta.parent_uuid is None

    def test_with_values(self):
        meta = ClaudeMessageMeta(
            parent_uuid="parent-123",
            is_sidechain=True,
            model="claude-opus-4-5-20251101",
        )
        assert meta.parent_uuid == "parent-123"
        assert meta.is_sidechain is True


class TestClaudeThinkingMeta:
    def test_signature_field(self):
        meta = ClaudeThinkingMeta(signature="abc123signature")
        assert meta.signature == "abc123signature"


class TestClaudeSessionMeta:
    def test_session_metadata(self):
        meta = ClaudeSessionMeta(
            session_id="sess-1",
            cwd="/home/user/project",
            git_branch="main",
        )
        assert meta.session_id == "sess-1"


class TestContentBlock:
    def test_text_block(self):
        block = ContentBlock(type="text", text="Hello world")
        assert block.type == "text"
        assert block.text == "Hello world"

    def test_thinking_block(self):
        block = ContentBlock(
            type="thinking",
            thinking="Let me analyze this...",
            signature="sig123",
        )
        assert block.type == "thinking"
        assert block.signature == "sig123"

    def test_tool_use_block(self):
        block = ContentBlock(
            type="tool_use",
            id="tool-1",
            name="Read",
            input={"file_path": "/etc/passwd"},
        )
        assert block.type == "tool_use"
        assert block.name == "Read"


class TestLogEntry:
    def test_user_entry(self):
        entry = LogEntry(
            type="user",
            message=UserMessage(content="Hello"),
            uuid="uuid-1",
            timestamp="2024-01-01T00:00:00Z",
        )
        assert entry.type == "user"
        assert entry.uuid == "uuid-1"
        assert isinstance(entry.message, UserMessage)

    def test_assistant_entry(self):
        entry = LogEntry(
            type="assistant",
            message=AssistantMessage(content=[ContentBlock(type="text", text="Hi there")]),
            uuid="uuid-2",
            timestamp="2024-01-01T00:00:01Z",
        )
        assert entry.type == "assistant"
        assert isinstance(entry.message, AssistantMessage)

    def test_system_entry(self):
        entry = LogEntry(
            type="system",
            message=SystemMessage(content="System prompt"),
            uuid="uuid-3",
            timestamp="2024-01-01T00:00:00Z",
        )
        assert entry.type == "system"
        assert isinstance(entry.message, SystemMessage)

    def test_parse_from_json(self):
        raw = json.dumps(
            {
                "type": "user",
                "message": {"content": "Test"},
                "uuid": "u1",
                "timestamp": "2024-01-01T00:00:00Z",
            }
        )
        entry = LogEntry.model_validate_json(raw)
        assert entry.uuid == "u1"
        assert isinstance(entry.message, UserMessage)

    def test_parse_assistant_from_json(self):
        """Test that assistant messages are correctly typed when parsed from JSON."""
        raw = json.dumps(
            {
                "type": "assistant",
                "message": {
                    "content": [{"type": "text", "text": "Hello"}],
                },
                "uuid": "u2",
                "timestamp": "2024-01-01T00:00:00Z",
            }
        )
        entry = LogEntry.model_validate_json(raw)
        assert entry.type == "assistant"
        assert isinstance(entry.message, AssistantMessage)

    def test_parse_system_from_json(self):
        """Test that system messages are correctly typed when parsed from JSON."""
        raw = json.dumps(
            {
                "type": "system",
                "message": {"content": "System prompt"},
                "uuid": "u3",
                "timestamp": "2024-01-01T00:00:00Z",
            }
        )
        entry = LogEntry.model_validate_json(raw)
        assert entry.type == "system"
        assert isinstance(entry.message, SystemMessage)
