"""Tests for OpenCode format types (Pydantic models)."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from agentstream.formats.opencode import (
    OpenCodeAssistantMessage,
    OpenCodeFilePart,
    OpenCodeMessagePath,
    OpenCodeModel,
    OpenCodeProject,
    OpenCodeReasoningPart,
    OpenCodeSession,
    OpenCodeSessionSummary,
    OpenCodeStepFinishPart,
    OpenCodeStepStartPart,
    OpenCodeTextPart,
    OpenCodeTime,
    OpenCodeTokens,
    OpenCodeToolPart,
    OpenCodeToolState,
    OpenCodeUserMessage,
)

# =============================================================================
# OpenCodeTime
# =============================================================================


class TestOpenCodeTime:
    def test_required_fields(self):
        t = OpenCodeTime(created=1700000000)
        assert t.created == 1700000000
        assert t.updated is None
        assert t.completed is None

    def test_all_fields(self):
        t = OpenCodeTime(created=1700000000, updated=1700001000, completed=1700002000)
        assert t.updated == 1700001000
        assert t.completed == 1700002000

    def test_extra_fields_ignored(self):
        t = OpenCodeTime(created=1700000000, extra_field="ignored")
        assert t.created == 1700000000
        assert not hasattr(t, "extra_field")


# =============================================================================
# OpenCodeProject
# =============================================================================


class TestOpenCodeProject:
    def test_required_fields(self):
        p = OpenCodeProject(id="proj-1", worktree="/home/user/project")
        assert p.id == "proj-1"
        assert p.worktree == "/home/user/project"
        assert p.vcs is None
        assert p.time is None

    def test_all_fields(self):
        p = OpenCodeProject(
            id="proj-1",
            worktree="/home/user/project",
            vcs="git",
            time=OpenCodeTime(created=1700000000),
        )
        assert p.vcs == "git"
        assert p.time is not None
        assert p.time.created == 1700000000


# =============================================================================
# OpenCodeSessionSummary
# =============================================================================


class TestOpenCodeSessionSummary:
    def test_all_optional(self):
        s = OpenCodeSessionSummary()
        assert s.additions is None
        assert s.deletions is None
        assert s.files is None

    def test_with_values(self):
        s = OpenCodeSessionSummary(additions=10, deletions=5, files=3)
        assert s.additions == 10
        assert s.deletions == 5
        assert s.files == 3


# =============================================================================
# OpenCodeSession
# =============================================================================


class TestOpenCodeSession:
    def test_required_fields(self):
        s = OpenCodeSession(
            id="sess-1",
            projectID="proj-1",
            directory="/home/user/project",
            time=OpenCodeTime(created=1700000000),
        )
        assert s.id == "sess-1"
        assert s.projectID == "proj-1"
        assert s.directory == "/home/user/project"
        assert s.slug is None
        assert s.version is None
        assert s.title is None
        assert s.parentID is None
        assert s.summary is None

    def test_all_fields(self):
        s = OpenCodeSession(
            id="sess-1",
            slug="my-session",
            version="0.1.0",
            projectID="proj-1",
            directory="/home/user/project",
            title="Test Session",
            parentID="sess-0",
            time=OpenCodeTime(created=1700000000),
            summary=OpenCodeSessionSummary(additions=5, deletions=2, files=1),
        )
        assert s.slug == "my-session"
        assert s.title == "Test Session"
        assert s.summary is not None
        assert s.summary.additions == 5


# =============================================================================
# OpenCodeModel
# =============================================================================


class TestOpenCodeModel:
    def test_fields(self):
        m = OpenCodeModel(providerID="anthropic", modelID="claude-sonnet-4-5-20250929")
        assert m.providerID == "anthropic"
        assert m.modelID == "claude-sonnet-4-5-20250929"


# =============================================================================
# OpenCodeTokens
# =============================================================================


class TestOpenCodeTokens:
    def test_defaults(self):
        t = OpenCodeTokens()
        assert t.input == 0
        assert t.output == 0
        assert t.reasoning == 0
        assert t.cache is None

    def test_with_values(self):
        t = OpenCodeTokens(input=100, output=50, reasoning=25, cache={"read": 10, "write": 5})
        assert t.input == 100
        assert t.cache == {"read": 10, "write": 5}


# =============================================================================
# OpenCodeMessagePath
# =============================================================================


class TestOpenCodeMessagePath:
    def test_fields(self):
        p = OpenCodeMessagePath(cwd="/home/user/project", root="/home/user/project")
        assert p.cwd == "/home/user/project"
        assert p.root == "/home/user/project"


# =============================================================================
# OpenCodeUserMessage
# =============================================================================


class TestOpenCodeUserMessage:
    def test_required_fields(self):
        m = OpenCodeUserMessage(
            id="msg-1",
            sessionID="sess-1",
            role="user",
            time=OpenCodeTime(created=1700000000),
        )
        assert m.id == "msg-1"
        assert m.role == "user"
        assert m.agent is None
        assert m.model is None

    def test_with_model(self):
        m = OpenCodeUserMessage(
            id="msg-1",
            sessionID="sess-1",
            role="user",
            time=OpenCodeTime(created=1700000000),
            model=OpenCodeModel(providerID="anthropic", modelID="claude-sonnet-4-5-20250929"),
        )
        assert m.model is not None
        assert m.model.providerID == "anthropic"

    def test_invalid_role_rejected(self):
        with pytest.raises(ValidationError):
            OpenCodeUserMessage(
                id="msg-1",
                sessionID="sess-1",
                role="assistant",
                time=OpenCodeTime(created=1700000000),
            )


# =============================================================================
# OpenCodeAssistantMessage
# =============================================================================


class TestOpenCodeAssistantMessage:
    def test_required_fields(self):
        m = OpenCodeAssistantMessage(
            id="msg-2",
            sessionID="sess-1",
            role="assistant",
            time=OpenCodeTime(created=1700000000),
        )
        assert m.role == "assistant"
        assert m.parentID is None
        assert m.modelID is None
        assert m.cost is None
        assert m.tokens is None
        assert m.finish is None

    def test_all_fields(self):
        m = OpenCodeAssistantMessage(
            id="msg-2",
            sessionID="sess-1",
            role="assistant",
            time=OpenCodeTime(created=1700000000),
            parentID="msg-1",
            modelID="claude-sonnet-4-5-20250929",
            providerID="anthropic",
            agent="coder",
            path=OpenCodeMessagePath(cwd="/project", root="/project"),
            cost=0.05,
            tokens=OpenCodeTokens(input=100, output=50),
            finish="end_turn",
        )
        assert m.cost == 0.05
        assert m.tokens is not None
        assert m.tokens.input == 100
        assert m.path is not None
        assert m.path.cwd == "/project"


# =============================================================================
# OpenCodeToolState
# =============================================================================


class TestOpenCodeToolState:
    def test_completed(self):
        s = OpenCodeToolState(status="completed", output="result")
        assert s.status == "completed"
        assert s.output == "result"
        assert s.error is None

    def test_error(self):
        s = OpenCodeToolState(status="error", error="something went wrong")
        assert s.status == "error"
        assert s.error == "something went wrong"

    def test_with_metadata(self):
        s = OpenCodeToolState(
            status="running",
            input={"path": "/foo"},
            title="Reading file",
            metadata={"key": "value"},
            time={"start": 1700000000},
        )
        assert s.input == {"path": "/foo"}
        assert s.title == "Reading file"

    def test_invalid_status_rejected(self):
        with pytest.raises(ValidationError):
            OpenCodeToolState(status="unknown")


# =============================================================================
# Part Types
# =============================================================================


class TestOpenCodeTextPart:
    def test_fields(self):
        p = OpenCodeTextPart(
            id="part-1", sessionID="sess-1", messageID="msg-1", type="text", text="Hello world"
        )
        assert p.type == "text"
        assert p.text == "Hello world"


class TestOpenCodeReasoningPart:
    def test_fields(self):
        p = OpenCodeReasoningPart(
            id="part-1",
            sessionID="sess-1",
            messageID="msg-1",
            type="reasoning",
            text="Let me think...",
        )
        assert p.type == "reasoning"
        assert p.text == "Let me think..."


class TestOpenCodeToolPart:
    def test_fields(self):
        p = OpenCodeToolPart(
            id="part-1",
            sessionID="sess-1",
            messageID="msg-1",
            type="tool",
            callID="call-1",
            tool="read_file",
            state=OpenCodeToolState(status="completed", output="file contents"),
        )
        assert p.type == "tool"
        assert p.tool == "read_file"
        assert p.state.status == "completed"


class TestOpenCodeStepStartPart:
    def test_fields(self):
        p = OpenCodeStepStartPart(
            id="part-1", sessionID="sess-1", messageID="msg-1", type="step-start"
        )
        assert p.type == "step-start"


class TestOpenCodeStepFinishPart:
    def test_required_fields(self):
        p = OpenCodeStepFinishPart(
            id="part-1", sessionID="sess-1", messageID="msg-1", type="step-finish"
        )
        assert p.type == "step-finish"
        assert p.reason is None
        assert p.cost is None
        assert p.tokens is None

    def test_all_fields(self):
        p = OpenCodeStepFinishPart(
            id="part-1",
            sessionID="sess-1",
            messageID="msg-1",
            type="step-finish",
            reason="end_turn",
            cost=0.03,
            tokens=OpenCodeTokens(input=50, output=30),
        )
        assert p.reason == "end_turn"
        assert p.cost == 0.03
        assert p.tokens is not None
        assert p.tokens.output == 30


class TestOpenCodeFilePart:
    def test_required_fields(self):
        p = OpenCodeFilePart(id="part-1", sessionID="sess-1", messageID="msg-1", type="file")
        assert p.type == "file"
        assert p.mime is None
        assert p.filename is None
        assert p.url is None

    def test_all_fields(self):
        p = OpenCodeFilePart(
            id="part-1",
            sessionID="sess-1",
            messageID="msg-1",
            type="file",
            mime="image/png",
            filename="screenshot.png",
            url="file:///tmp/screenshot.png",
        )
        assert p.mime == "image/png"
        assert p.filename == "screenshot.png"
