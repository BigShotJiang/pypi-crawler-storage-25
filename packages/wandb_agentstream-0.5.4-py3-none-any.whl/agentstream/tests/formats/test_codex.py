"""Tests for Codex format models."""

from agentstream.formats.codex import CodexLogEntry


class TestCodexFormatModels:
    def test_parse_session_meta(self) -> None:
        """Parse a session_meta entry."""
        data = {
            "timestamp": "2026-01-06T00:00:00Z",
            "type": "session_meta",
            "payload": {
                "id": "test-session-id",
                "timestamp": "2026-01-06T00:00:00Z",
                "cwd": "/path/to/project",
                "originator": "codex_cli_rs",
                "cli_version": "0.77.0",
            },
        }
        entry = CodexLogEntry.model_validate(data)
        assert entry.type == "session_meta"
        assert entry.payload["id"] == "test-session-id"

    def test_parse_response_item_message(self) -> None:
        """Parse a response_item with message payload."""
        data = {
            "timestamp": "2026-01-06T00:00:00Z",
            "type": "response_item",
            "payload": {
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": "Hello"}],
            },
        }
        entry = CodexLogEntry.model_validate(data)
        assert entry.type == "response_item"
        assert entry.payload["type"] == "message"
        assert entry.payload["role"] == "user"

    def test_parse_response_item_function_call(self) -> None:
        """Parse a function_call payload."""
        data = {
            "timestamp": "2026-01-06T00:00:00Z",
            "type": "response_item",
            "payload": {
                "type": "function_call",
                "name": "exec_command",
                "arguments": '{"cmd":"pwd"}',
                "call_id": "call_123",
            },
        }
        entry = CodexLogEntry.model_validate(data)
        assert entry.payload["type"] == "function_call"
        assert entry.payload["name"] == "exec_command"

    def test_parse_response_item_reasoning(self) -> None:
        """Parse a reasoning payload with encrypted content."""
        data = {
            "timestamp": "2026-01-06T00:00:00Z",
            "type": "response_item",
            "payload": {
                "type": "reasoning",
                "summary": [{"type": "summary_text", "text": "Thinking about this..."}],
                "encrypted_content": "gAAAAA...",
            },
        }
        entry = CodexLogEntry.model_validate(data)
        assert entry.payload["type"] == "reasoning"
        assert entry.payload["summary"][0]["text"] == "Thinking about this..."
        assert entry.payload["encrypted_content"] == "gAAAAA..."

    def test_parse_event_msg(self) -> None:
        """Parse an event_msg entry."""
        data = {
            "timestamp": "2026-01-06T00:00:00Z",
            "type": "event_msg",
            "payload": {"type": "user_message", "message": "Hello"},
        }
        entry = CodexLogEntry.model_validate(data)
        assert entry.type == "event_msg"
        assert entry.payload["type"] == "user_message"

    def test_parse_turn_context(self) -> None:
        """Parse a turn_context entry."""
        data = {
            "timestamp": "2026-01-06T00:00:00Z",
            "type": "turn_context",
            "payload": {
                "cwd": "/path/to/project",
                "model": "gpt-5-codex",
                "approval_policy": "on-request",
            },
        }
        entry = CodexLogEntry.model_validate(data)
        assert entry.type == "turn_context"
        assert entry.payload["model"] == "gpt-5-codex"
