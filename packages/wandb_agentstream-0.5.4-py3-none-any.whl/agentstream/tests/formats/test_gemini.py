"""Tests for Gemini format models."""

from agentstream.formats.gemini import GeminiSession


class TestGeminiFormatModels:
    def test_parse_simple_session(self) -> None:
        """Parse a minimal Gemini session."""
        data = {
            "sessionId": "f8dd7805-8f62-484f-9419-2ef167035d61",
            "projectHash": "ee6db73636f61fea3f745129b4759a113ca6233f7201467e60c689d5fcab8916",
            "startTime": "2026-01-06T01:48:26.449Z",
            "lastUpdated": "2026-01-06T01:49:17.144Z",
            "messages": [
                {
                    "id": "msg-1",
                    "timestamp": "2026-01-06T01:48:26.449Z",
                    "type": "user",
                    "content": "Hello",
                }
            ],
        }
        session = GeminiSession.model_validate(data)
        assert session.session_id == "f8dd7805-8f62-484f-9419-2ef167035d61"
        assert len(session.messages) == 1
        assert session.messages[0].type == "user"

    def test_parse_message_with_thoughts(self) -> None:
        """Parse a message with thinking/reasoning."""
        data = {
            "sessionId": "test",
            "projectHash": "hash",
            "startTime": "2026-01-06T00:00:00Z",
            "lastUpdated": "2026-01-06T00:00:00Z",
            "messages": [
                {
                    "id": "msg-1",
                    "timestamp": "2026-01-06T00:00:00Z",
                    "type": "gemini",
                    "content": "Here's my answer",
                    "thoughts": [
                        {
                            "subject": "Analyzing request",
                            "description": "Let me think about this...",
                            "timestamp": "2026-01-06T00:00:00Z",
                        }
                    ],
                    "model": "gemini-2.5-pro",
                    "tokens": {"input": 100, "output": 50, "total": 150},
                }
            ],
        }
        session = GeminiSession.model_validate(data)
        msg = session.messages[0]
        assert msg.type == "gemini"
        assert len(msg.thoughts) == 1
        assert msg.thoughts[0].subject == "Analyzing request"
        assert msg.model == "gemini-2.5-pro"
        assert msg.tokens is not None
        assert msg.tokens.total == 150

    def test_parse_message_with_tool_calls(self) -> None:
        """Parse a message with tool calls and results."""
        data = {
            "sessionId": "test",
            "projectHash": "hash",
            "startTime": "2026-01-06T00:00:00Z",
            "lastUpdated": "2026-01-06T00:00:00Z",
            "messages": [
                {
                    "id": "msg-1",
                    "timestamp": "2026-01-06T00:00:00Z",
                    "type": "gemini",
                    "content": "",
                    "toolCalls": [
                        {
                            "id": "tc-1",
                            "name": "read_file",
                            "args": {"file_path": "README.md"},
                            "result": [
                                {
                                    "functionResponse": {
                                        "id": "tc-1",
                                        "name": "read_file",
                                        "response": {"output": "# README"},
                                    }
                                }
                            ],
                            "status": "success",
                            "timestamp": "2026-01-06T00:00:01Z",
                            "displayName": "ReadFile",
                        }
                    ],
                }
            ],
        }
        session = GeminiSession.model_validate(data)
        tc = session.messages[0].tool_calls[0]
        assert tc.name == "read_file"
        assert tc.args == {"file_path": "README.md"}
        assert tc.status == "success"
        assert len(tc.result) == 1

    def test_parse_info_message(self) -> None:
        """Parse an info message (CLI notifications)."""
        data = {
            "sessionId": "test",
            "projectHash": "hash",
            "startTime": "2026-01-06T00:00:00Z",
            "lastUpdated": "2026-01-06T00:00:00Z",
            "messages": [
                {
                    "id": "msg-1",
                    "timestamp": "2026-01-06T00:00:00Z",
                    "type": "info",
                    "content": "Update available!",
                }
            ],
        }
        session = GeminiSession.model_validate(data)
        assert session.messages[0].type == "info"
