#!/bin/bash
# Collect real source entry fixtures from each agent type
#
# This script dumps the most recent session from each agent type in the
# current project directory to tests/fixtures for validation testing.
#
# Usage:
#   cd /path/to/agentstream-py
#   bash tests/fixtures/collect_fixtures.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

echo "Collecting source entry fixtures from $PROJECT_ROOT"
echo ""

for agent in claude cursor gemini codex; do
    echo "==> Collecting $agent session..."

    output_file="$SCRIPT_DIR/$agent/source_events.jsonl"

    # Try to dump most recent session
    if uv run hivemind dump -a "$agent" --path "$PROJECT_ROOT" > "$output_file" 2>&1; then
        # Check if file has content
        if [ -s "$output_file" ]; then
            entry_count=$(wc -l < "$output_file")
            echo "    ✅ Saved $entry_count entries to $agent/source_events.jsonl"
        else
            echo "    ⚠️  No entries found for $agent"
            rm -f "$output_file"
        fi
    else
        echo "    ❌ No $agent sessions found in project"
        rm -f "$output_file"
    fi
    echo ""
done

echo "Done! Fixture files:"
find "$SCRIPT_DIR" -name "source_events.jsonl" -type f | sed "s|$SCRIPT_DIR/||"
