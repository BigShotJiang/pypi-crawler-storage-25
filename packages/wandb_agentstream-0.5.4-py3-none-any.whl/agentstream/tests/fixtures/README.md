# Test Fixtures

This directory contains real source entry dumps from each agent type, used for:
- Validating synthetic data generators produce realistic entries
- Testing normalizer implementations against real data
- Debugging normalization issues with ground truth

## Structure

```
tests/fixtures/
├── claude/
│   └── source_events.jsonl    # Real Claude source entries
├── cursor/
│   └── source_events.jsonl    # Real Cursor source entries
├── gemini/
│   └── source_events.jsonl    # Real Gemini source entries
├── codex/
│   └── source_events.jsonl    # Real Codex source entries
└── collect_fixtures.sh        # Script to refresh fixtures
```

## Collecting Fixtures

To refresh fixtures with the latest sessions from this project:

```bash
cd /path/to/agentstream-py
bash tests/fixtures/collect_fixtures.sh
```

This will:
1. Find the most recent session for each agent type in the project directory
2. Dump source entries in the same format sent to the API
3. Save to `{agent_name}/source_events.jsonl`

## Manual Collection

To dump a specific session:

```bash
# Dump most recent Claude session
uv run hivemind dump -a claude > tests/fixtures/claude/source_events.jsonl

# Dump specific session by ID
uv run hivemind dump -a cursor -s <session-id> > tests/fixtures/cursor/source_events.jsonl
```

## File Format

Each fixture file is JSONL (one JSON object per line) with:

```json
{"entry_index": 0, "entry_content": "{...raw agent format...}", "entry_timestamp_ms": 1234567890}
{"entry_index": 1, "entry_content": "{...raw agent format...}", "entry_timestamp_ms": 1234567891}
```

- `entry_index`: Sequential index starting from 0
- `entry_content`: Raw JSON string in agent-specific format (Claude JSONL, Cursor SQLite-extracted, etc.)
- `entry_timestamp_ms`: Unix timestamp in milliseconds

## Using Fixtures

### Validate Synthetic Data

Compare synthetic generator output to real data:

```python
import json
from pathlib import Path

# Load real fixture
real_entries = []
with open("tests/fixtures/claude/source_events.jsonl") as f:
    for line in f:
        entry = json.loads(line)
        real_entries.append(json.loads(entry["entry_content"]))

# Compare structure and fields
first_real = real_entries[0]
print(f"Real entry has fields: {first_real.keys()}")
```

### Test Normalizers

Feed real data through normalizers:

```python
from agentstream.normalization.registry import get_normalizer

normalizer = get_normalizer("claude", "1.0.0")

# Load source entries
with open("tests/fixtures/claude/source_events.jsonl") as f:
    source_entries = [json.loads(line) for line in f]

# Test session metadata extraction
metadata = normalizer.extract_session_metadata(source_entries, daemon_metadata={})
assert metadata.primary_model is not None
assert metadata.cwd is not None
```

## Maintenance

- **Refresh periodically** as agent formats evolve
- **Include diverse sessions** (different prompts, tool usage patterns)
- **Document anomalies** in comments if sessions have unusual structures
