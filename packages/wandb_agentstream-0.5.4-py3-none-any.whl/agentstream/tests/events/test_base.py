# tests/events/test_base.py
import pytest
from pydantic import ValidationError

from agentstream.events.base import BaseEvent, EventType, Role


class TestEventType:
    def test_event_types_are_strings(self):
        assert EventType.RUN_STARTED == "RUN_STARTED"
        assert EventType.TEXT_MESSAGE_START == "TEXT_MESSAGE_START"
        assert EventType.TOOL_CALL_START == "TOOL_CALL_START"
        assert EventType.CUSTOM == "CUSTOM"

    def test_all_ag_ui_event_types_exist(self):
        """Verify we have all AG-UI protocol event types."""
        required_types = [
            "RUN_STARTED",
            "RUN_FINISHED",
            "RUN_ERROR",
            "TEXT_MESSAGE_START",
            "TEXT_MESSAGE_CONTENT",
            "TEXT_MESSAGE_END",
            "TOOL_CALL_START",
            "TOOL_CALL_ARGS",
            "TOOL_CALL_END",
            "TOOL_CALL_RESULT",
            "CUSTOM",
        ]
        for t in required_types:
            assert hasattr(EventType, t), f"Missing EventType.{t}"


class TestRole:
    def test_roles_are_strings(self):
        assert Role.USER == "user"
        assert Role.ASSISTANT == "assistant"
        assert Role.SYSTEM == "system"


class TestBaseEvent:
    def test_base_event_requires_type_and_timestamp(self):
        with pytest.raises(ValidationError):
            BaseEvent()

    def test_base_event_with_required_fields(self):
        event = BaseEvent(type=EventType.RUN_STARTED, timestamp_ms=1234567890)
        assert event.type == EventType.RUN_STARTED
        assert event.timestamp_ms == 1234567890

    def test_base_event_forbids_extra_fields(self):
        with pytest.raises(ValidationError):
            BaseEvent(type=EventType.RUN_STARTED, timestamp_ms=1234567890, unknown_field="value")
