# tests/events/test_run.py
import pytest
from pydantic import ValidationError

from agentstream.events.base import EventType
from agentstream.events.run import RunErrorEvent, RunFinishedEvent, RunStartedEvent


class TestRunStartedEvent:
    def test_has_correct_type_literal(self):
        event = RunStartedEvent(
            timestamp_ms=1000,
            thread_id="thread-1",
            run_id="run-1",
        )
        assert event.type == EventType.RUN_STARTED

    def test_type_is_enforced(self):
        """Cannot override the type literal."""
        with pytest.raises(ValidationError):
            RunStartedEvent(
                type=EventType.RUN_FINISHED,  # Wrong type
                timestamp_ms=1000,
                thread_id="thread-1",
                run_id="run-1",
            )

    def test_optional_fields(self):
        event = RunStartedEvent(
            timestamp_ms=1000,
            thread_id="thread-1",
            run_id="run-1",
            parent_run_id="parent-1",
        )
        assert event.parent_run_id == "parent-1"


class TestRunFinishedEvent:
    def test_has_correct_type_literal(self):
        event = RunFinishedEvent(timestamp_ms=2000, run_id="run-1")
        assert event.type == EventType.RUN_FINISHED
        assert event.run_id == "run-1"


class TestRunErrorEvent:
    def test_has_correct_type_literal(self):
        event = RunErrorEvent(
            timestamp_ms=3000,
            run_id="run-1",
            message="Something went wrong",
        )
        assert event.type == EventType.RUN_ERROR
        assert event.message == "Something went wrong"
