"""Tests for agentstream events."""
