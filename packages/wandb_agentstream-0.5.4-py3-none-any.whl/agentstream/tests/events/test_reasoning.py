# tests/events/test_reasoning.py
import pytest
from pydantic import ValidationError

from agentstream.events.base import EventType
from agentstream.events.reasoning import (
    ReasoningEndEvent,
    ReasoningMessageContentEvent,
    ReasoningMessageEndEvent,
    ReasoningMessageStartEvent,
    ReasoningStartEvent,
)


class TestReasoningStartEvent:
    def test_has_correct_type_and_required_fields(self):
        event = ReasoningStartEvent(
            timestamp_ms=1000,
            message_id="msg-1",
        )
        assert event.type == EventType.REASONING_START
        assert event.message_id == "msg-1"
        assert event.timestamp_ms == 1000

    def test_type_is_enforced(self):
        """Cannot override the type literal."""
        with pytest.raises(ValidationError):
            ReasoningStartEvent(
                type=EventType.RUN_STARTED,  # Wrong type
                timestamp_ms=1000,
                message_id="msg-1",
            )


class TestReasoningMessageStartEvent:
    def test_has_correct_type_and_required_fields(self):
        event = ReasoningMessageStartEvent(
            timestamp_ms=1000,
            message_id="msg-1",
        )
        assert event.type == EventType.REASONING_MESSAGE_START
        assert event.message_id == "msg-1"

    def test_type_is_enforced(self):
        """Cannot override the type literal."""
        with pytest.raises(ValidationError):
            ReasoningMessageStartEvent(
                type=EventType.RUN_STARTED,  # Wrong type
                timestamp_ms=1000,
                message_id="msg-1",
            )


class TestReasoningMessageContentEvent:
    def test_has_delta_field(self):
        event = ReasoningMessageContentEvent(
            timestamp_ms=1000,
            message_id="msg-1",
            delta="Let me think about this...",
        )
        assert event.type == EventType.REASONING_MESSAGE_CONTENT
        assert event.message_id == "msg-1"
        assert event.delta == "Let me think about this..."

    def test_type_is_enforced(self):
        """Cannot override the type literal."""
        with pytest.raises(ValidationError):
            ReasoningMessageContentEvent(
                type=EventType.RUN_STARTED,  # Wrong type
                timestamp_ms=1000,
                message_id="msg-1",
                delta="thinking...",
            )


class TestReasoningMessageEndEvent:
    def test_has_correct_type(self):
        event = ReasoningMessageEndEvent(
            timestamp_ms=1000,
            message_id="msg-1",
        )
        assert event.type == EventType.REASONING_MESSAGE_END
        assert event.message_id == "msg-1"

    def test_type_is_enforced(self):
        """Cannot override the type literal."""
        with pytest.raises(ValidationError):
            ReasoningMessageEndEvent(
                type=EventType.RUN_STARTED,  # Wrong type
                timestamp_ms=1000,
                message_id="msg-1",
            )


class TestReasoningEndEvent:
    def test_has_correct_type(self):
        event = ReasoningEndEvent(
            timestamp_ms=1000,
            message_id="msg-1",
        )
        assert event.type == EventType.REASONING_END
        assert event.message_id == "msg-1"

    def test_type_is_enforced(self):
        """Cannot override the type literal."""
        with pytest.raises(ValidationError):
            ReasoningEndEvent(
                type=EventType.RUN_STARTED,  # Wrong type
                timestamp_ms=1000,
                message_id="msg-1",
            )
