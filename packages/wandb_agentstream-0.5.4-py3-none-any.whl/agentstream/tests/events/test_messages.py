# tests/events/test_messages.py
import pytest
from pydantic import ValidationError

from agentstream.events.base import EventType, Role
from agentstream.events.messages import (
    TextMessageContentEvent,
    TextMessageEndEvent,
    TextMessageStartEvent,
)


class TestTextMessageStartEvent:
    def test_has_correct_type_and_required_fields(self):
        event = TextMessageStartEvent(
            timestamp_ms=1000,
            message_id="msg-1",
            role=Role.ASSISTANT,
        )
        assert event.type == EventType.TEXT_MESSAGE_START
        assert event.message_id == "msg-1"
        assert event.role == Role.ASSISTANT

    def test_role_as_string(self):
        event = TextMessageStartEvent(
            timestamp_ms=1000,
            message_id="msg-1",
            role="user",  # String instead of enum
        )
        assert event.role == Role.USER

    def test_type_is_enforced(self):
        """Cannot override the type literal."""
        with pytest.raises(ValidationError):
            TextMessageStartEvent(
                type=EventType.RUN_STARTED,  # Wrong type
                timestamp_ms=1000,
                message_id="msg-1",
                role=Role.ASSISTANT,
            )


class TestTextMessageContentEvent:
    def test_has_delta_field(self):
        event = TextMessageContentEvent(
            timestamp_ms=1000,
            message_id="msg-1",
            delta="Hello, ",
        )
        assert event.type == EventType.TEXT_MESSAGE_CONTENT
        assert event.delta == "Hello, "

    def test_type_is_enforced(self):
        """Cannot override the type literal."""
        with pytest.raises(ValidationError):
            TextMessageContentEvent(
                type=EventType.RUN_STARTED,  # Wrong type
                timestamp_ms=1000,
                message_id="msg-1",
                delta="Hello, ",
            )


class TestTextMessageEndEvent:
    def test_has_correct_type(self):
        event = TextMessageEndEvent(
            timestamp_ms=1000,
            message_id="msg-1",
        )
        assert event.type == EventType.TEXT_MESSAGE_END

    def test_type_is_enforced(self):
        """Cannot override the type literal."""
        with pytest.raises(ValidationError):
            TextMessageEndEvent(
                type=EventType.RUN_STARTED,  # Wrong type
                timestamp_ms=1000,
                message_id="msg-1",
            )
