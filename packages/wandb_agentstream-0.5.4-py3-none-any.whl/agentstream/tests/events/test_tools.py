# tests/events/test_tools.py
import pytest
from pydantic import ValidationError

from agentstream.events.base import EventType
from agentstream.events.tools import (
    ToolCallArgsEvent,
    ToolCallEndEvent,
    ToolCallResultEvent,
    ToolCallStartEvent,
)


class TestToolCallStartEvent:
    def test_has_required_fields(self):
        event = ToolCallStartEvent(
            timestamp_ms=1000,
            tool_call_id="tc-1",
            tool_call_name="Read",
            message_id="msg-1",
        )
        assert event.type == EventType.TOOL_CALL_START
        assert event.tool_call_id == "tc-1"
        assert event.tool_call_name == "Read"
        assert event.message_id == "msg-1"

    def test_type_is_enforced(self):
        with pytest.raises(ValidationError):
            ToolCallStartEvent(
                type=EventType.RUN_STARTED,
                timestamp_ms=1000,
                tool_call_id="tc-1",
                tool_call_name="Read",
            )


class TestToolCallArgsEvent:
    def test_args_as_string(self):
        event = ToolCallArgsEvent(
            timestamp_ms=1000,
            tool_call_id="tc-1",
            delta='{"file_path": "/etc/passwd"}',
        )
        assert event.type == EventType.TOOL_CALL_ARGS
        assert event.delta == '{"file_path": "/etc/passwd"}'

    def test_type_is_enforced(self):
        with pytest.raises(ValidationError):
            ToolCallArgsEvent(
                type=EventType.RUN_STARTED,
                timestamp_ms=1000,
                tool_call_id="tc-1",
                delta="{}",
            )


class TestToolCallEndEvent:
    def test_has_correct_type(self):
        event = ToolCallEndEvent(timestamp_ms=1000, tool_call_id="tc-1")
        assert event.type == EventType.TOOL_CALL_END

    def test_type_is_enforced(self):
        with pytest.raises(ValidationError):
            ToolCallEndEvent(
                type=EventType.RUN_STARTED,
                timestamp_ms=1000,
                tool_call_id="tc-1",
            )


class TestToolCallResultEvent:
    def test_has_result_fields(self):
        event = ToolCallResultEvent(
            timestamp_ms=2000,
            tool_call_result_id="tcr-1",
            tool_call_id="tc-1",
            result="File contents here",
        )
        assert event.type == EventType.TOOL_CALL_RESULT
        assert event.result == "File contents here"

    def test_optional_error_flag(self):
        event = ToolCallResultEvent(
            timestamp_ms=2000,
            tool_call_result_id="tcr-1",
            tool_call_id="tc-1",
            result="Error: file not found",
            is_error=True,
        )
        assert event.is_error is True

    def test_type_is_enforced(self):
        with pytest.raises(ValidationError):
            ToolCallResultEvent(
                type=EventType.RUN_STARTED,
                timestamp_ms=2000,
                tool_call_result_id="tcr-1",
                tool_call_id="tc-1",
                result="test",
            )
