# tests/events/test_custom.py
import pytest
from pydantic import ValidationError

from agentstream.events.base import EventType
from agentstream.events.custom import CustomEvent


class TestCustomEvent:
    def test_has_name_and_value(self):
        event = CustomEvent(
            timestamp_ms=1000,
            name="reasoning.start",
            value={"message_id": "msg-1"},
        )
        assert event.type == EventType.CUSTOM
        assert event.name == "reasoning.start"
        assert event.value == {"message_id": "msg-1"}

    def test_file_edit_custom_event(self):
        event = CustomEvent(
            timestamp_ms=1000,
            name="file.edit",
            value={
                "file_path": "/path/to/file.py",
                "patch": "@@ -1,3 +1,4 @@\\n+new line",
            },
        )
        assert event.name == "file.edit"
        assert event.value["file_path"] == "/path/to/file.py"

    def test_value_is_required(self):
        with pytest.raises(ValidationError):
            CustomEvent(timestamp_ms=1000, name="test")

    def test_type_is_enforced(self):
        with pytest.raises(ValidationError):
            CustomEvent(
                type=EventType.RUN_STARTED,
                timestamp_ms=1000,
                name="test",
                value={},
            )
