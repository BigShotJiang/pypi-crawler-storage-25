# agentstream/grouper.py
"""Event grouping - reassemble streaming events into logical messages."""

from __future__ import annotations

import json
from collections.abc import Iterable, Iterator
from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel, ConfigDict

from .events import (
    Event,
    ReasoningMessageChunkEvent,
    ReasoningMessageContentEvent,
    ReasoningMessageEndEvent,
    ReasoningMessageStartEvent,
    Role,
    TextMessageChunkEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    TextMessageStartEvent,
    ToolCallArgsEvent,
    ToolCallChunkEvent,
    ToolCallEndEvent,
    ToolCallResultEvent,
    ToolCallStartEvent,
)


class ContentBlock(BaseModel):
    """A piece of message content."""

    model_config = ConfigDict(extra="forbid")

    text: str


class ReasoningBlock(BaseModel):
    """An extended thinking block."""

    model_config = ConfigDict(extra="forbid")

    content: str
    encrypted_content: str | None = None


class ToolCall(BaseModel):
    """A complete tool invocation with result."""

    model_config = ConfigDict(extra="forbid")

    id: str
    name: str
    message_id: str | None = None
    args: dict[str, Any] = {}
    result: str | None = None
    is_error: bool = False


class MessageGroup(BaseModel):
    """A complete logical message with all its parts."""

    model_config = ConfigDict(extra="forbid")

    id: str
    role: Role
    content: list[ContentBlock] = []
    tool_calls: list[ToolCall] = []
    reasoning: list[ReasoningBlock] = []

    @property
    def text(self) -> str:
        """Convenience: concatenate all content blocks."""
        return "".join(block.text for block in self.content)


@dataclass
class _ReasoningState:
    """State for accumulating a reasoning block."""

    message_id: str
    content_parts: list[str] = field(default_factory=list)
    encrypted_content: str | None = None


@dataclass
class _GrouperState:
    """Internal state for the grouper."""

    messages: dict[str, MessageGroup] = field(default_factory=dict)
    message_order: list[str] = field(default_factory=list)
    tool_calls: dict[str, ToolCall] = field(default_factory=dict)
    tool_call_to_message: dict[str, str] = field(default_factory=dict)
    pending_content: dict[str, list[str]] = field(default_factory=dict)
    pending_args: dict[str, list[str]] = field(default_factory=dict)
    # Reasoning state: message_id -> current reasoning block being built
    pending_reasoning: dict[str, _ReasoningState] = field(default_factory=dict)


def group_events(events: Iterable[Event]) -> Iterator[MessageGroup]:
    """
    Reassemble streaming events into MessageGroups.

    Handles the START/CONTENT/END pattern for messages and tool calls.
    Metadata is extracted from END events.
    """
    state = _GrouperState()

    for event in events:
        if isinstance(event, TextMessageStartEvent):
            # Check if a placeholder MessageGroup already exists (from reasoning events)
            if event.message_id in state.messages:
                # Update the existing placeholder with the correct role
                # (preserves any reasoning blocks already attached)
                state.messages[event.message_id].role = event.role
            else:
                state.messages[event.message_id] = MessageGroup(
                    id=event.message_id,
                    role=event.role,
                )
                state.message_order.append(event.message_id)
            state.pending_content[event.message_id] = []

        elif isinstance(event, TextMessageContentEvent):
            if event.message_id in state.pending_content:
                state.pending_content[event.message_id].append(event.delta)

        elif isinstance(event, TextMessageEndEvent):
            if event.message_id in state.messages:
                msg = state.messages[event.message_id]
                # Finalize content
                if event.message_id in state.pending_content:
                    full_text = "".join(state.pending_content[event.message_id])
                    if full_text:
                        msg.content.append(ContentBlock(text=full_text))

        elif isinstance(event, ToolCallStartEvent):
            tc = ToolCall(
                id=event.tool_call_id,
                name=event.tool_call_name,
                message_id=event.message_id,
            )
            state.tool_calls[event.tool_call_id] = tc
            state.pending_args[event.tool_call_id] = []
            if event.message_id:
                state.tool_call_to_message[event.tool_call_id] = event.message_id

        elif isinstance(event, ToolCallArgsEvent):
            if event.tool_call_id in state.pending_args:
                state.pending_args[event.tool_call_id].append(event.delta)

        elif isinstance(event, ToolCallEndEvent):
            if event.tool_call_id in state.tool_calls:
                tc = state.tool_calls[event.tool_call_id]
                # Parse accumulated args
                args_str = "".join(state.pending_args.get(event.tool_call_id, []))
                if args_str:
                    try:
                        tc.args = json.loads(args_str)
                    except json.JSONDecodeError:
                        tc.args = {"_raw": args_str}
                # Attach to message
                msg_id = state.tool_call_to_message.get(event.tool_call_id)
                if msg_id and msg_id in state.messages:
                    state.messages[msg_id].tool_calls.append(tc)

        elif isinstance(event, ToolCallResultEvent):
            if event.tool_call_id in state.tool_calls:
                tc = state.tool_calls[event.tool_call_id]
                tc.result = event.result
                tc.is_error = event.is_error

        # Reasoning events - accumulate thinking content
        elif isinstance(event, ReasoningMessageStartEvent):
            # Start accumulating reasoning for this message
            state.pending_reasoning[event.message_id] = _ReasoningState(message_id=event.message_id)

        elif isinstance(event, ReasoningMessageContentEvent):
            if event.message_id in state.pending_reasoning:
                state.pending_reasoning[event.message_id].content_parts.append(event.delta)

        elif isinstance(event, ReasoningMessageEndEvent):
            if event.message_id in state.pending_reasoning:
                reasoning_state = state.pending_reasoning[event.message_id]

                # Create the reasoning block and attach to message
                full_content = "".join(reasoning_state.content_parts)
                if full_content:
                    block = ReasoningBlock(
                        content=full_content,
                        encrypted_content=reasoning_state.encrypted_content,
                    )
                    # Attach to message if it exists
                    if event.message_id in state.messages:
                        state.messages[event.message_id].reasoning.append(block)
                    else:
                        # Message might not exist yet (reasoning comes before text)
                        # Create a placeholder that will be updated
                        msg = MessageGroup(
                            id=event.message_id,
                            role=Role.ASSISTANT,  # Reasoning is always from assistant
                        )
                        msg.reasoning.append(block)
                        state.messages[event.message_id] = msg
                        if event.message_id not in state.message_order:
                            state.message_order.append(event.message_id)

                # Clean up
                del state.pending_reasoning[event.message_id]

        # Chunk convenience events - handle as all-in-one events
        elif isinstance(event, TextMessageChunkEvent):
            msg_id = event.message_id
            if msg_id:
                if msg_id not in state.messages:
                    state.messages[msg_id] = MessageGroup(
                        id=msg_id,
                        role=event.role or Role.ASSISTANT,
                    )
                    state.message_order.append(msg_id)
                elif event.role:
                    # Update role if provided
                    state.messages[msg_id].role = event.role

                # Append delta to content
                if event.delta:
                    if msg_id not in state.pending_content:
                        state.pending_content[msg_id] = []
                    state.pending_content[msg_id].append(event.delta)

        elif isinstance(event, ToolCallChunkEvent):
            tc_id = event.tool_call_id
            if tc_id:
                if tc_id not in state.tool_calls:
                    state.tool_calls[tc_id] = ToolCall(
                        id=tc_id,
                        name=event.tool_call_name or "",
                        message_id=event.parent_message_id,
                    )
                    state.pending_args[tc_id] = []
                    if event.parent_message_id:
                        state.tool_call_to_message[tc_id] = event.parent_message_id
                elif event.tool_call_name:
                    # Update name if provided
                    state.tool_calls[tc_id].name = event.tool_call_name

                # Append delta to args
                if event.delta:
                    state.pending_args[tc_id].append(event.delta)

        elif isinstance(event, ReasoningMessageChunkEvent):
            msg_id = event.message_id
            if msg_id:
                # Get or create message
                if msg_id not in state.messages:
                    state.messages[msg_id] = MessageGroup(
                        id=msg_id,
                        role=Role.ASSISTANT,  # Reasoning is always from assistant
                    )
                    state.message_order.append(msg_id)

                # Get or create reasoning state
                if msg_id not in state.pending_reasoning:
                    state.pending_reasoning[msg_id] = _ReasoningState(message_id=msg_id)

                # Append delta to reasoning content
                if event.delta:
                    state.pending_reasoning[msg_id].content_parts.append(event.delta)

    # Finalize chunk-based content and tool calls before yielding
    for msg_id, content_parts in state.pending_content.items():
        if msg_id in state.messages:
            full_text = "".join(content_parts)
            if full_text:
                msg = state.messages[msg_id]
                # Only add if not already present (avoid duplicates from mixed events)
                if not msg.content or msg.content[-1].text != full_text:
                    msg.content.append(ContentBlock(text=full_text))

    # Finalize pending reasoning blocks
    for msg_id, reasoning_state in state.pending_reasoning.items():
        full_content = "".join(reasoning_state.content_parts)
        if full_content and msg_id in state.messages:
            block = ReasoningBlock(
                content=full_content,
                encrypted_content=reasoning_state.encrypted_content,
            )
            msg = state.messages[msg_id]
            # Only add if not already present
            if not msg.reasoning or msg.reasoning[-1].content != full_content:
                msg.reasoning.append(block)

    # Finalize pending tool calls
    for tc_id, tc in state.tool_calls.items():
        args_str = "".join(state.pending_args.get(tc_id, []))
        if args_str:
            try:
                tc.args = json.loads(args_str)
            except json.JSONDecodeError:
                tc.args = {"_raw": args_str}

        # Attach to message if not already attached
        msg_id = state.tool_call_to_message.get(tc_id)
        if msg_id and msg_id in state.messages:
            msg = state.messages[msg_id]
            if tc not in msg.tool_calls:
                msg.tool_calls.append(tc)

    # Yield messages in order
    for msg_id in state.message_order:
        if msg_id in state.messages:
            yield state.messages[msg_id]


__all__ = [
    "ContentBlock",
    "ReasoningBlock",
    "ToolCall",
    "MessageGroup",
    "group_events",
]
