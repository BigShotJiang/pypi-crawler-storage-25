"""Analytics helpers for session statistics."""

from __future__ import annotations

import hashlib
import os
import posixpath
import uuid
from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from agentstream.events import CustomEvent, Event, EventType, Role, ToolCallResultEvent
from agentstream.git_utils import (
    find_git_root,
    get_commit_at_timestamp,
    get_default_branch,
    get_git_commit_sha,
    resolve_git_repo,
)
from agentstream.normalization.synthetic import (
    ERROR_EVENT,
    SESSION_METADATA,
    TOKEN_USAGE,
    UNIFIED_FILE_OPERATION,
)


@dataclass
class ActiveDurationResult:
    """Result of active duration calculation with stats for observability.

    Attributes:
        duration_ms: Total active duration in milliseconds.
        total_chunks: Number of activity chunks detected.
        capped_chunks: Number of chunks that hit the max duration cap.
        max_chunk_ms: The longest single chunk duration (before capping).
    """

    duration_ms: int
    total_chunks: int
    capped_chunks: int
    max_chunk_ms: int

    def __int__(self) -> int:
        """Allow using result directly as int for backward compatibility."""
        return self.duration_ms


# ============================================================================
# Path Normalization
# ============================================================================


def normalize_path(path: str, cwd: str | None) -> str:
    """Normalize a file path to be cwd-relative when possible.

    All paths are normalized to use forward slashes and start with './' if
    they are under the cwd. Paths outside the cwd are kept as absolute paths.

    Args:
        path: The original path (absolute or relative).
        cwd: Session's working directory (project root for normalization).

    Returns:
        CWD-relative path (./src/file.py) or absolute if outside cwd.

    Examples:
        >>> normalize_path("/home/user/project/src/main.py", "/home/user/project")
        './src/main.py'
        >>> normalize_path("/etc/config", "/home/user/project")
        '/etc/config'
        >>> normalize_path("src/main.py", "/home/user/project")
        './src/main.py'
    """
    if not path:
        return path

    if not cwd:
        # Can't normalize without cwd, return as-is with forward slashes
        return path.replace("\\", "/")

    # Normalize cwd (handle trailing slashes, normalize separators)
    cwd = os.path.normpath(cwd)

    # Resolve to absolute path
    if os.path.isabs(path):
        abs_path = os.path.normpath(path)
    else:
        # Relative path - resolve from cwd
        abs_path = os.path.normpath(os.path.join(cwd, path))

    # Try to make cwd-relative
    try:
        rel_path = os.path.relpath(abs_path, cwd)
        # Check if path escapes cwd (starts with ..)
        if not rel_path.startswith(".."):
            # Use posixpath for consistent forward slashes
            return "./" + rel_path.replace("\\", "/")
    except ValueError:
        # On Windows, relpath fails for paths on different drives
        pass

    # Return absolute path for files outside cwd (with forward slashes)
    return abs_path.replace("\\", "/")


# ============================================================================
# Instruction File Detection
# ============================================================================

# Known instruction file patterns (case-insensitive basenames)
INSTRUCTION_FILE_NAMES = frozenset(
    {
        # Agent-specific
        "agents.md",
        "claude.md",
        "gemini.md",
        "codex.md",
        "cursor.md",
        # Dot-file variants
        ".claude",
        ".cursorrules",
        ".cursorignore",
        # Generic
        "instructions.md",
        "ai_instructions.md",
        # Copilot
        ".github/copilot-instructions.md",
    }
)

# Directory-based instruction patterns (path suffixes)
INSTRUCTION_DIR_PATTERNS = frozenset(
    {
        ".anthropic/config",
        ".cursor/rules",
    }
)


def is_instruction_file(path: str) -> bool:
    """Check if a path refers to a known instruction file.

    Args:
        path: File path (can be absolute or relative).

    Returns:
        True if this is a known instruction file pattern.
    """
    if not path:
        return False

    # Normalize path separators
    normalized = path.replace("\\", "/")

    # Check basename (case-insensitive)
    basename = posixpath.basename(normalized).lower()
    if basename in INSTRUCTION_FILE_NAMES:
        return True

    # Check directory-based patterns (path suffix)
    normalized_lower = normalized.lower()
    return any(normalized_lower.endswith(pattern) for pattern in INSTRUCTION_DIR_PATTERNS)


def _count_extensions(paths: Iterable[str]) -> dict[str, int]:
    """Count file extensions from a set of paths.

    Args:
        paths: Iterable of file paths.

    Returns:
        Dict mapping extensions (including dot) to counts.
        Files without extensions are counted under empty string.
    """
    counter: Counter[str] = Counter()
    for path in paths:
        # Get extension (includes the dot)
        _, ext = posixpath.splitext(path)
        counter[ext.lower()] += 1

    # Remove empty extension if present (files without extension)
    result = dict(counter)
    if "" in result and result[""] == 0:
        del result[""]

    return result


def _extract_custom_event_data(event: Event, event_type: str) -> dict[str, Any] | None:
    """Extract data from a custom event if it matches the expected type.

    Args:
        event: Event to extract from.
        event_type: Expected custom event type (e.g., SESSION_METADATA, TOKEN_USAGE).

    Returns:
        Data dict from event.value.data, or None if not matching or invalid.
    """
    if not isinstance(event, CustomEvent) or event.name != event_type:
        return None
    if not isinstance(event.value, dict):
        return None
    data = event.value.get("data")
    return data if isinstance(data, dict) else None


# ============================================================================
# File Summary Building
# ============================================================================


def build_file_summary(events: Iterable[Event]) -> dict[str, Any]:
    """Build file operation summary from events.

    Aggregates file operations from UNIFIED_FILE_OPERATION custom events
    to produce session-level statistics.

    Args:
        events: Iterable of parsed Event objects.

    Returns:
        Dictionary with file operation summary fields.
    """
    read_files: set[str] = set()
    write_files: set[str] = set()
    edit_files: set[str] = set()
    deleted_files: set[str] = set()
    instruction_files: set[str] = set()
    search_count = 0
    list_count = 0

    for event in events:
        data = _extract_custom_event_data(event, UNIFIED_FILE_OPERATION)
        if not data:
            continue

        op_type = data.get("operation")
        path = data.get("file_path", "")

        if not path or not isinstance(path, str):
            # list/search ops may not have a path
            if op_type == "search":
                search_count += 1
            elif op_type == "list":
                list_count += 1
            continue

        if op_type == "read":
            read_files.add(path)
            if is_instruction_file(path):
                instruction_files.add(path)
        elif op_type == "write":
            write_files.add(path)
        elif op_type == "edit":
            edit_files.add(path)
        elif op_type == "delete":
            deleted_files.add(path)
        elif op_type == "search":
            search_count += 1
        elif op_type == "list":
            list_count += 1

    # Compute file types from all paths
    all_write_paths = write_files | edit_files
    all_paths = all_write_paths | read_files
    file_types = _count_extensions(all_paths)

    return {
        "files_read": len(read_files),
        "files_written": len(write_files),
        "files_edited": len(edit_files),
        "files_deleted": len(deleted_files),
        "read_paths": sorted(read_files),
        "write_paths": sorted(all_write_paths),
        "file_types": file_types,
        "instruction_files": sorted(instruction_files),
        "search_count": search_count,
        "list_count": list_count,
    }


# Fixed namespace UUID for AgentStream session ID generation.
# This is a randomly generated UUID that serves as the namespace for UUID v5.
# NEVER change this value - it would break idempotent imports.
AGENTSTREAM_NAMESPACE = uuid.UUID("f47ac10b-58cc-4372-a567-0e02b2c3d479")


def generate_event_id(session_id: str, event_index: int, timestamp_ms: int) -> str:
    """Generate a deterministic, time-ordered event ID (UUID v7-like).

    Creates a UUID that:
    - Is time-ordered using the event's own timestamp (not current time)
    - Is deterministic: same inputs always produce the same output
    - Follows UUID v7 structure for ClickHouse locality benefits

    The structure is:
    - Bits 0-47: Unix timestamp in milliseconds (from event)
    - Bits 48-51: Version = 7 (0111)
    - Bits 52-63: Derived from hash (12 bits)
    - Bits 64-65: Variant = 10 (2 bits)
    - Bits 66-127: Derived from hash (62 bits)

    Args:
        session_id: The internal session ID (UUID string).
        event_index: The event's position within the session (0-based).
        timestamp_ms: The event's timestamp in milliseconds. Must be > 0.

    Returns:
        A UUID string that is time-ordered and deterministic.

    Raises:
        ValueError: If timestamp_ms is <= 0 (required for time-ordering).
    """
    if timestamp_ms <= 0:
        raise ValueError(
            f"Event timestamp_ms must be > 0, got {timestamp_ms}. "
            f"Events require valid timestamps for deterministic ID generation."
        )
    # Create deterministic random bits from session_id and event_index
    hash_input = f"{session_id}:{event_index}".encode()
    hash_bytes = hashlib.sha256(hash_input).digest()

    # Clamp timestamp to 48 bits (supports dates until year 10889)
    ts_48 = timestamp_ms & 0xFFFFFFFFFFFF

    # Build UUID bytes (16 bytes = 128 bits)
    # Bytes 0-5: timestamp (48 bits, big-endian)
    # Byte 6: version (4 bits) + rand_a high (4 bits)
    # Byte 7: rand_a low (8 bits)
    # Byte 8: variant (2 bits) + rand_b high (6 bits)
    # Bytes 9-15: rand_b (56 bits)

    uuid_bytes = bytearray(16)

    # Timestamp (bytes 0-5)
    uuid_bytes[0] = (ts_48 >> 40) & 0xFF
    uuid_bytes[1] = (ts_48 >> 32) & 0xFF
    uuid_bytes[2] = (ts_48 >> 24) & 0xFF
    uuid_bytes[3] = (ts_48 >> 16) & 0xFF
    uuid_bytes[4] = (ts_48 >> 8) & 0xFF
    uuid_bytes[5] = ts_48 & 0xFF

    # Version 7 (0111) + 4 bits from hash
    uuid_bytes[6] = 0x70 | (hash_bytes[0] & 0x0F)

    # 8 bits from hash
    uuid_bytes[7] = hash_bytes[1]

    # Variant (10) + 6 bits from hash
    uuid_bytes[8] = 0x80 | (hash_bytes[2] & 0x3F)

    # Remaining 56 bits from hash (bytes 9-15)
    uuid_bytes[9:16] = hash_bytes[3:10]

    return str(uuid.UUID(bytes=bytes(uuid_bytes)))


def generate_session_id(
    github_id: str | int,
    agent_type: str,
    agent_session_id: str,
) -> str:
    """Generate a deterministic internal session ID.

    Uses UUID v5 (SHA-1 based) to create a collision-proof ID from the tuple
    of (github_id, agent_type, agent_session_id). This ensures:

    - Deterministic: Same inputs always produce the same output (idempotent imports)
    - Collision-proof: Even if agent IDs collide, the full tuple is unique
    - Standard format: UUID string works everywhere
    - Device-independent: Session identity follows the session file, not the device
    - Stable across DB resets: Uses external GitHub ID, not internal user_id

    Args:
        github_id: The user's GitHub ID (stable external identifier).
        agent_type: The agent format (e.g., "claude", "gemini", "codex").
        agent_session_id: The original session ID from the agent tool.

    Returns:
        A UUID v5 string that uniquely identifies this session.
    """
    name = f"{github_id}:{agent_type}:{agent_session_id}"
    return str(uuid.uuid5(AGENTSTREAM_NAMESPACE, name))


# Event types that represent actual agent activity (assistant messages, tool calls, reasoning)
# Excludes CUSTOM events (synthetic metadata) and run lifecycle events.
AGENT_ACTIVITY_TYPES = frozenset(
    {
        # Assistant messages
        EventType.TEXT_MESSAGE_START,
        EventType.TEXT_MESSAGE_CONTENT,
        EventType.TEXT_MESSAGE_END,
        EventType.TEXT_MESSAGE_CHUNK,
        # Tool calls
        EventType.TOOL_CALL_START,
        EventType.TOOL_CALL_ARGS,
        EventType.TOOL_CALL_END,
        EventType.TOOL_CALL_CHUNK,
        EventType.TOOL_CALL_RESULT,
        # Reasoning/thinking
        EventType.REASONING_START,
        EventType.REASONING_MESSAGE_START,
        EventType.REASONING_MESSAGE_CONTENT,
        EventType.REASONING_MESSAGE_END,
        EventType.REASONING_END,
        EventType.REASONING_MESSAGE_CHUNK,
    }
)


def is_user_message(e: Event) -> bool:
    """Check if an event is a user message (TEXT_MESSAGE with role=USER)."""
    return (
        e.type in (EventType.TEXT_MESSAGE_START, EventType.TEXT_MESSAGE_CHUNK)
        and getattr(e, "role", None) == Role.USER
    )


def is_agent_activity(e: Event) -> bool:
    """Check if an event is agent activity (excluding user messages and CUSTOM events)."""
    return e.type in AGENT_ACTIVITY_TYPES and not is_user_message(e)


def calculate_active_duration_ms(events: Iterable[Event]) -> ActiveDurationResult:
    """Calculate the time the agent spent actively working (not waiting for user).

    Uses a chunk-based algorithm that:
    1. Groups consecutive activity events into "chunks" based on time gaps
    2. Caps individual chunks to prevent overcounting during idle periods
    3. Sums all valid chunk durations

    This approach handles:
    - Sessions where user goes idle between prompts (gaps between chunks)
    - CLI-initiated sessions without explicit user messages
    - Long-running tool executions (capped at max chunk duration)

    Only counts actual agent activity events:
    - Assistant text messages (not user messages)
    - Tool calls and results
    - Reasoning/thinking blocks

    Does NOT count:
    - Custom events (source_entry, etc.) - these can span idle time
    - Run lifecycle events (RUN_STARTED, RUN_FINISHED, RUN_ERROR)
    - User messages (they mark turn boundaries, not active time)

    Args:
        events: Iterable of parsed Event objects.

    Returns:
        ActiveDurationResult with duration_ms and capping statistics.
        The result can be used as int via int(result) for backward compatibility.
    """
    # Thresholds for chunk detection
    # If gap between events > MAX_GAP, start a new chunk
    MAX_CHUNK_GAP_MS = 10 * 60 * 1000  # 10 minutes - gaps larger than this are idle time
    # Cap any single chunk at this duration to prevent runaway counting
    MAX_CHUNK_DURATION_MS = 4 * 60 * 60 * 1000  # 4 hours - safety cap for prolific sessions

    events_list = list(events)

    # Collect all activity timestamps (both user and agent)
    # User messages mark the START of a turn, agent activity is the actual work
    activity_events: list[tuple[int, bool]] = []  # (timestamp, is_turn_start)

    for e in events_list:
        if e.timestamp_ms <= 0:
            continue
        if is_user_message(e):
            activity_events.append((e.timestamp_ms, True))  # Turn start
        elif is_agent_activity(e):
            activity_events.append((e.timestamp_ms, False))  # Agent work

    if not activity_events:
        return ActiveDurationResult(duration_ms=0, total_chunks=0, capped_chunks=0, max_chunk_ms=0)

    # Sort by timestamp
    activity_events.sort(key=lambda x: x[0])

    # Calculate duration using chunk-based approach
    # A chunk is a burst of activity separated by gaps > MAX_CHUNK_GAP_MS
    # User messages reset the chunk (new turn)
    total_duration_ms = 0
    total_chunks = 0
    capped_chunks = 0
    max_chunk_ms = 0
    chunk_start_ts: int | None = None
    last_activity_ts: int | None = None

    def finalize_chunk() -> None:
        """Finalize current chunk and update stats."""
        nonlocal total_duration_ms, total_chunks, capped_chunks, max_chunk_ms
        if chunk_start_ts is not None and last_activity_ts is not None:
            raw_duration = last_activity_ts - chunk_start_ts
            capped_duration = min(raw_duration, MAX_CHUNK_DURATION_MS)
            total_duration_ms += capped_duration
            total_chunks += 1
            max_chunk_ms = max(max_chunk_ms, raw_duration)
            if raw_duration > MAX_CHUNK_DURATION_MS:
                capped_chunks += 1

    for ts, is_turn_start in activity_events:
        if is_turn_start:
            # User message: finalize current chunk (if any) and start new turn
            finalize_chunk()
            # New turn starts with user message
            chunk_start_ts = ts
            last_activity_ts = None
        else:
            # Agent activity
            if chunk_start_ts is None:
                # No turn start yet (CLI session without user messages)
                chunk_start_ts = ts
                last_activity_ts = ts
            elif last_activity_ts is None:
                # First agent activity after user message
                last_activity_ts = ts
            else:
                # Check for gap that would indicate a new chunk
                gap = ts - last_activity_ts
                if gap > MAX_CHUNK_GAP_MS:
                    # Large gap - finalize current chunk, start new one
                    finalize_chunk()
                    chunk_start_ts = ts
                last_activity_ts = ts

    # Finalize last chunk
    finalize_chunk()

    return ActiveDurationResult(
        duration_ms=total_duration_ms,
        total_chunks=total_chunks,
        capped_chunks=capped_chunks,
        max_chunk_ms=max_chunk_ms,
    )


def build_session_summary(
    agent_session_id: str,
    format: str,
    modified_at: float,
    events: Iterable[Event],
    github_id: str | int = "",
) -> dict[str, Any]:
    """Build a session summary from session metadata and events.

    Args:
        agent_session_id: The original session ID from the agent tool.
        format: The agent format (e.g., "claude", "gemini", "codex").
        modified_at: Unix timestamp of last modification.
        events: Iterable of parsed Event objects.
        github_id: The user's GitHub ID (for generating internal session ID).

    Returns:
        Dictionary with session summary fields suitable for storage/API.
        Includes both 'id' (internal UUID) and 'agent_session_id' (original).
    """
    events_list = list(events)

    # Generate deterministic internal session ID
    internal_id = generate_session_id(github_id, format, agent_session_id)

    # Extract timestamps from events
    timestamps_ms = [e.timestamp_ms for e in events_list if e.timestamp_ms > 0]

    # For last_activity_at, only consider agent activity events (assistant messages,
    # tool calls, reasoning). This excludes CUSTOM events (synthetic metadata like
    # TOKEN_USAGE, DURATION_STATS) and user messages (including housekeeping like
    # /exit, <local-command-caveat>) that can cause misleading recency when a session
    # is briefly opened/closed without real interaction.
    activity_timestamps_ms = [
        e.timestamp_ms for e in events_list if e.timestamp_ms > 0 and is_agent_activity(e)
    ]

    if timestamps_ms:
        started_at_ms = min(timestamps_ms)
        # Use activity timestamps for last_activity_at, fall back to all timestamps
        last_activity_at_ms = (
            max(activity_timestamps_ms) if activity_timestamps_ms else max(timestamps_ms)
        )
        started_at = datetime.fromtimestamp(started_at_ms / 1000, tz=UTC).isoformat()
        last_activity_at = datetime.fromtimestamp(last_activity_at_ms / 1000, tz=UTC).isoformat()
    else:
        # Fallback to file modification time
        started_at_ms = int(modified_at * 1000)  # Convert seconds to ms
        started_at = datetime.fromtimestamp(modified_at, tz=UTC).isoformat()
        last_activity_at = started_at

    # Count events by type
    # Include both full lifecycle events (TEXT_MESSAGE_START, TOOL_CALL_START) and
    # chunk convenience events (TEXT_MESSAGE_CHUNK, TOOL_CALL_CHUNK) for compatibility
    # with adapters like Claude that emit chunk events directly
    tool_call_events = [
        e for e in events_list if e.type in (EventType.TOOL_CALL_START, EventType.TOOL_CALL_CHUNK)
    ]
    message_events = [
        e
        for e in events_list
        if e.type in (EventType.TEXT_MESSAGE_START, EventType.TEXT_MESSAGE_CHUNK)
    ]
    user_messages = [e for e in message_events if getattr(e, "role", None) == Role.USER]

    # Count errors from ERROR_EVENT custom events and ToolCallResultEvent.is_error
    error_events = [
        e
        for e in events_list
        if (isinstance(e, CustomEvent) and e.name == ERROR_EVENT)
        or (isinstance(e, ToolCallResultEvent) and getattr(e, "is_error", False))
    ]
    error_count = len(error_events)

    # Calculate active duration
    active_duration_ms = calculate_active_duration_ms(events_list)

    # Extract unique tools used
    tools_used = list(
        set(
            getattr(e, "tool_call_name", "")
            for e in tool_call_events
            if getattr(e, "tool_call_name", "")
        )
    )

    # Extract parent session ID for sub-agent sessions
    # Sub-agent files contain a sessionId that differs from their own agent_session_id
    parent_session_id = None
    for e in events_list:
        if isinstance(e, CustomEvent) and e.name == "source_entry":
            value = e.value
            if isinstance(value, dict):
                raw_event = value.get("raw_event", {})
                if isinstance(raw_event, dict):
                    session_id_in_file = raw_event.get("sessionId")
                    if session_id_in_file and session_id_in_file != agent_session_id:
                        # This is a sub-agent: sessionId points to parent
                        parent_session_id = generate_session_id(
                            github_id, format, session_id_in_file
                        )
                        break

    # Extract models from SESSION_METADATA custom events
    models_used: set[str] = set()
    primary_model = ""
    for e in events_list:
        data = _extract_custom_event_data(e, SESSION_METADATA)
        if data:
            model = data.get("primary_model", "")
            if model:
                models_used.add(model)
                if not primary_model:
                    primary_model = model

    # Extract version, git info, and cwd from SESSION_METADATA custom events
    session_version = ""
    git_branch = ""
    git_commit_from_session = ""
    cwd = ""
    for e in events_list:
        data = _extract_custom_event_data(e, SESSION_METADATA)
        if data:
            # Extract all session metadata fields
            if not session_version:
                session_version = data.get("agent_version", "")
            if not git_branch:
                git_branch = data.get("git_branch", "")
            if not git_commit_from_session:
                git_commit_from_session = data.get("git_commit", "")
            if not cwd:
                cwd = data.get("cwd", "")
            # Stop if we have everything
            if session_version and git_branch and cwd and git_commit_from_session:
                break

    # Resolve git_repo and git_commit
    # Priority for git_commit:
    # 1. Session data (Codex stores commit_hash in git object)
    # 2. Git history lookup (find commit on branch at session start time)
    # 3. Current HEAD (fallback)
    git_repo = ""
    git_commit = ""
    git_root = None

    if cwd:
        git_repo = resolve_git_repo(cwd) or ""
        git_root = find_git_root(cwd)

    if git_commit_from_session:
        # Use commit SHA from session data (most accurate)
        git_commit = git_commit_from_session
    elif git_root and git_branch and started_at_ms > 0:
        # Try to find the commit on the branch at session start time
        commit_at_time = get_commit_at_timestamp(git_root, git_branch, started_at_ms)
        if commit_at_time:
            git_commit = commit_at_time
        else:
            # Branch may not exist anymore, try default branch
            default_branch = get_default_branch(git_root)
            if default_branch:
                commit_at_time = get_commit_at_timestamp(git_root, default_branch, started_at_ms)
                if commit_at_time:
                    git_commit = commit_at_time
    # Fallback to current HEAD if nothing else worked
    if not git_commit and git_root:
        git_commit = get_git_commit_sha(git_root) or ""

    # Extract token usage from TOKEN_USAGE custom events
    total_input_tokens = 0
    total_output_tokens = 0
    total_cache_read_tokens = 0
    total_cache_creation_tokens = 0
    total_reasoning_tokens = 0

    for e in events_list:
        data = _extract_custom_event_data(e, TOKEN_USAGE)
        if data:
            total_input_tokens += data.get("input_tokens", 0)
            total_output_tokens += data.get("output_tokens", 0)
            total_cache_read_tokens += data.get("cache_read_tokens", 0)
            total_cache_creation_tokens += data.get("cache_creation_tokens", 0)
            total_reasoning_tokens += data.get("reasoning_tokens", 0)

    # Extract first user message as prompt
    # Handle both full lifecycle events (TEXT_MESSAGE_START + TEXT_MESSAGE_CONTENT)
    # and chunk events (TEXT_MESSAGE_CHUNK with role and delta in same event)
    first_prompt = ""
    user_msg_started = False
    for e in events_list:
        # Check for TEXT_MESSAGE_CHUNK with role=USER (Claude adapter style)
        if e.type == EventType.TEXT_MESSAGE_CHUNK and getattr(e, "role", None) == Role.USER:
            delta = getattr(e, "delta", "")
            if delta:
                first_prompt = str(delta)[:500]
                break
        # Check for TEXT_MESSAGE_START with role=USER (full lifecycle style)
        elif e.type == EventType.TEXT_MESSAGE_START and getattr(e, "role", None) == Role.USER:
            user_msg_started = True
        elif user_msg_started and e.type == EventType.TEXT_MESSAGE_CONTENT:
            first_prompt = str(getattr(e, "delta", ""))[:500]
            break
        elif user_msg_started and e.type == EventType.TEXT_MESSAGE_END:
            break

    # Build file operation summary
    file_summary = build_file_summary(events_list)

    return {
        "id": internal_id,
        "agent_session_id": agent_session_id,
        "agent_type": format,
        "model": primary_model,
        "version": session_version,
        "cwd": cwd,
        "git_branch": git_branch,
        "git_repo": git_repo,
        "git_commit": git_commit,
        "started_at": started_at,
        "last_activity_at": last_activity_at,
        "active_duration_ms": active_duration_ms,
        "turn_count": len(user_messages),
        "message_count": len(message_events),
        "tool_call_count": len(tool_call_events),
        "error_count": error_count,
        "tools_used": tools_used,
        "models_used": list(models_used),
        "first_prompt": first_prompt,
        "hostname": os.uname().nodename,
        "parent_session_id": parent_session_id,
        # Token usage
        "input_tokens": total_input_tokens,
        "output_tokens": total_output_tokens,
        "cached_read_tokens": total_cache_read_tokens,
        "cached_write_tokens": total_cache_creation_tokens,
        "reasoning_tokens": total_reasoning_tokens,
        # File operations
        "file_summary": file_summary,
    }


# Patterns that indicate internal/sidechain-only sessions
_INTERNAL_PROMPT_PATTERNS = (
    "Caveat: The messages below were generated",
    "<local-command-caveat>",
)


def is_internal_session(session_summary: dict[str, Any]) -> bool:
    """Check if a session summary represents an internal/sidechain session.

    Internal sessions are typically:
    - Generated by Claude for local command execution
    - Have no model (because no API calls were made)
    - Have first_prompt starting with a caveat message
    - Have no conversation content (no turns, no model, no prompt)

    These sessions should be filtered out during import as they don't
    represent real user interactions.

    Args:
        session_summary: Session summary dict from build_session_summary().

    Returns:
        True if this appears to be an internal session that should be skipped.
    """
    model = session_summary.get("model", "")
    first_prompt = session_summary.get("first_prompt", "")
    turn_count = session_summary.get("turn_count", 0)

    # Sessions with no conversation content at all (e.g., only file-history-snapshot)
    # These are metadata-only sessions with no actual user interaction
    if not model and not first_prompt and turn_count == 0:
        return True

    # Check if first prompt matches internal patterns (sidechain sessions)
    if not model and first_prompt:
        for pattern in _INTERNAL_PROMPT_PATTERNS:
            if first_prompt.startswith(pattern):
                return True

    return False
