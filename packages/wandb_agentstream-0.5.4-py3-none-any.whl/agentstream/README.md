# agentstream

Read, transform, and write AI agent session logs across formats (Claude, Codex, Gemini) with AG-UI events as the canonical format.

## Installation

```bash
pip install agentstream
```

## Quick Start

```python
import agentstream

# Discover all agent sessions
sessions = agentstream.discover_sessions("~/myproject")

# Read as grouped messages
for msg in agentstream.read_messages(sessions[0]):
    print(f"{msg.role}: {msg.text[:100]}")
    for tc in msg.tool_calls:
        print(f"  -> {tc.name}({tc.args})")
```

## Development

```bash
uv venv
uv pip install -e ".[dev]"

# Run tests with coverage
uv run pytest

# Type checking (ty is Astral's fast type checker)
uv run ty check

# Linting
uv run ruff check agentstream
```

### Version Management

Python and Node.js versions are centralized in `.python-version` and `.node-version` files at the repo root.

**Auto-updated from version files:**
- CI workflows
- devcontainer
- Docker builds (via `make up` in `backend/`)

**Manual updates required when changing versions:**

| File | Settings to update |
|------|-------------------|
| `pyproject.toml` | `requires-python`, `target-version` (ruff), `python-version` (ty) |
| `daemon/pyproject.toml` | `requires-python`, `target-version` |
| `backend/api/pyproject.toml` | `requires-python`, `target-version` |

**Version policy:**
- **SDK (agentstream)**: Supports Python 3.12+ for broad compatibility
- **Backend services (daemon, api)**: Require Python 3.13+ (we control deployment)

## License

MIT
