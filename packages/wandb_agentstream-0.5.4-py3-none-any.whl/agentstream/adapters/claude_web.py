"""Claude Code Web adapter for reading cloud/web session logs.

Web sessions have a different format than local Claude Code sessions.
This adapter handles the web-specific event types and structures.

Note: This adapter is used for processing source_entries from web sessions
that are synced via the daemon. It does not support local file discovery
since web sessions don't have local files.
"""

from __future__ import annotations

import json
import uuid as uuid_module
from collections.abc import Iterable, Iterator
from pathlib import Path
from typing import IO

from agentstream.events import (
    CustomEvent,
    Event,
    ReasoningMessageChunkEvent,
    Role,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)
from agentstream.formats.claude_web import (
    WebAssistantEntry,
    WebContentBlock,
    WebEnvManagerLogEntry,
    WebResultEntry,
    WebSystemEntry,
    WebUserEntry,
)

from .base import Adapter, Session
from .timestamps import parse_timestamp


class ClaudeWebAdapter(Adapter):
    """Adapter for Claude Code web/cloud session logs.

    Handles the web-specific format which differs from local Claude Code format:
    - env_manager_log events for environment setup
    - system events with flat structure
    - Different timestamp locations
    - isReplay field for replayed messages

    NOTE: This adapter is primarily for processing source_entries synced from
    the web API. It does not support local file discovery since web sessions
    don't have local files.
    """

    @property
    def name(self) -> str:
        return "claude_web"

    # === Local file operations (not applicable for web sessions) ===

    def get_base_directories(self) -> list[Path]:
        """Return empty list - web sessions have no local directories."""
        return []

    def matches_path(self, path: Path) -> bool:
        """Return False - web sessions have no local files."""
        return False

    def discover_sessions(self, project_dir: Path) -> list[Session]:
        """Return empty list - web sessions are discovered via API, not files."""
        return []

    def read_entries(self, session: Session) -> list[dict]:
        """Return empty list - web session entries come from API, not files."""
        return []

    def read_events(self, session: Session) -> Iterator[Event]:
        """Not supported - web sessions are processed via parse_source_entry."""
        return iter([])

    def write_events(self, events: Iterable[Event], dest: IO[str]) -> None:
        """Not supported - web sessions cannot be written locally."""
        pass

    # === Source entry parsing (the main functionality) ===

    def parse_source_entry(
        self,
        entry: dict,
        entry_index: int,
        session_id: str,
    ) -> list[Event]:
        """Parse a single source entry into AG-UI events.

        Args:
            entry: Parsed JSON from source_entry.entry_content
            entry_index: Position in session (for event ID generation)
            session_id: Session UUID

        Returns:
            List of AG-UI events (may be empty)
        """
        events: list[Event] = []
        entry_type = entry.get("type")

        # Skip daemon_metadata entry (handled separately)
        if entry_type == "daemon_metadata":
            return events

        # Get timestamp from entry (may be nested in different places)
        fallback_ts = entry.get("_timestamp_ms", 0)
        ts = self._extract_timestamp(entry, fallback_ts)

        if entry_type == "env_manager_log":
            events.extend(self._map_env_manager_log(entry, ts))
        elif entry_type == "system":
            events.extend(self._map_system_entry(entry, ts))
        elif entry_type == "user":
            events.extend(self._map_user_message(entry, ts))
        elif entry_type == "assistant":
            events.extend(self._map_assistant_message(entry, ts))
        elif entry_type == "result":
            events.extend(self._map_result_entry(entry, ts))

        # Tag all events with entry_index for incremental processing
        for event in events:
            if not hasattr(event, "_source"):
                event._source = {}  # type: ignore[attr-defined]
            event._source["entry_index"] = entry_index  # type: ignore[attr-defined, index]

        return events

    def _extract_timestamp(self, entry: dict, fallback_ms: int) -> int:
        """Extract timestamp from entry, handling web format differences.

        Web format may have timestamp in:
        - data.timestamp (for env_manager_log)
        - message.usage (from API response)
        - No timestamp at all (use fallback)
        """
        # Check for root-level timestamp (rare in web format)
        root_ts = entry.get("timestamp")
        if root_ts:
            parsed = parse_timestamp(root_ts)
            if parsed is not None:
                return parsed

        # Check for timestamp in data (env_manager_log)
        if "data" in entry and isinstance(entry["data"], dict):
            data_ts = entry["data"].get("timestamp")
            if data_ts:
                parsed = parse_timestamp(data_ts)
                if parsed is not None:
                    return parsed

        return fallback_ms

    def _map_env_manager_log(self, entry: dict, ts: int) -> list[Event]:
        """Map env_manager_log entry to events."""
        try:
            log_entry = WebEnvManagerLogEntry.model_validate(entry)
        except Exception:
            return []

        # Emit as a custom event for environment setup tracking
        return [
            CustomEvent(
                timestamp_ms=ts,
                name="env_manager_log",
                value={
                    "category": log_entry.data.category,
                    "content": log_entry.data.content,
                    "level": log_entry.data.level,
                },
            )
        ]

    def _map_system_entry(self, entry: dict, ts: int) -> list[Event]:
        """Map system entry to events."""
        try:
            sys_entry = WebSystemEntry.model_validate(entry)
        except Exception:
            return []

        # Emit session metadata as custom event
        return [
            CustomEvent(
                timestamp_ms=ts,
                name="session_init",
                value={
                    "cwd": sys_entry.cwd,
                    "model": sys_entry.model,
                    "claude_code_version": sys_entry.claude_code_version,
                    "tools": sys_entry.tools,
                    "agents": sys_entry.agents,
                },
            )
        ]

    def _map_user_message(self, entry: dict, ts: int) -> list[Event]:
        """Map a user entry to AG-UI events."""
        try:
            user_entry = WebUserEntry.model_validate(entry)
        except Exception:
            return []

        events: list[Event] = []
        msg_id = user_entry.uuid
        content = user_entry.message.content

        if isinstance(content, list):
            # Check if this is a tool_result message
            has_tool_results = any(
                isinstance(block, WebContentBlock) and block.type == "tool_result"
                for block in content
            )

            if has_tool_results:
                # Handle tool_result blocks
                for block in content:
                    if isinstance(block, WebContentBlock) and block.type == "tool_result":
                        tool_use_id = block.tool_use_id or ""
                        result_content = block.content
                        result_str = ""
                        if isinstance(result_content, list):
                            result_str = json.dumps({"content": result_content})
                        elif result_content is not None:
                            result_str = str(result_content)

                        events.append(
                            ToolCallResultEvent(
                                timestamp_ms=ts,
                                tool_call_result_id=str(uuid_module.uuid4()),
                                tool_call_id=tool_use_id,
                                result=result_str,
                                is_error=block.is_error,
                            )
                        )
                return events

            # Extract text blocks
            text_parts: list[str] = []
            for block in content:
                if isinstance(block, WebContentBlock) and block.type == "text" and block.text:
                    text_parts.append(block.text)

            if text_parts:
                events.append(
                    TextMessageChunkEvent(
                        timestamp_ms=ts,
                        message_id=msg_id,
                        role=Role.USER,
                        delta=text_parts[-1],  # Use last text block
                    )
                )
            return events

        # Simple string content
        text_content = content if isinstance(content, str) else ""
        events.append(
            TextMessageChunkEvent(
                timestamp_ms=ts,
                message_id=msg_id,
                role=Role.USER,
                delta=text_content,
            )
        )
        return events

    def _map_assistant_message(self, entry: dict, ts: int) -> list[Event]:
        """Map an assistant entry to AG-UI events."""
        try:
            asst_entry = WebAssistantEntry.model_validate(entry)
        except Exception:
            return []

        events: list[Event] = []
        msg_id = asst_entry.uuid
        text_parts: list[str] = []
        tool_use_blocks: list[WebContentBlock] = []
        thinking_blocks: list[WebContentBlock] = []

        # Process content blocks
        if isinstance(asst_entry.message.content, list):
            for block in asst_entry.message.content:
                if isinstance(block, WebContentBlock):
                    if block.type == "text" and block.text:
                        text_parts.append(block.text)
                    elif block.type == "tool_use":
                        tool_use_blocks.append(block)
                    elif block.type == "thinking" and block.thinking:
                        thinking_blocks.append(block)

        # Emit reasoning chunks first
        for block in thinking_blocks:
            if block.thinking:
                events.append(
                    ReasoningMessageChunkEvent(
                        timestamp_ms=ts,
                        message_id=msg_id,
                        delta=block.thinking,
                    )
                )

        # Emit text message if present
        if text_parts:
            events.append(
                TextMessageChunkEvent(
                    timestamp_ms=ts,
                    message_id=msg_id,
                    role=Role.ASSISTANT,
                    delta="".join(text_parts),
                )
            )

        # Emit tool calls
        for block in tool_use_blocks:
            events.append(
                ToolCallChunkEvent(
                    timestamp_ms=ts,
                    tool_call_id=block.id or "",
                    tool_call_name=block.name or "",
                    parent_message_id=msg_id,
                    delta=json.dumps(block.input or {}),
                )
            )

        # Extract and emit token usage from web format
        if asst_entry.message.usage:
            usage = asst_entry.message.usage
            events.append(
                CustomEvent(
                    timestamp_ms=ts,
                    name="token_usage",
                    value={
                        "input_tokens": usage.input_tokens,
                        "output_tokens": usage.output_tokens,
                        "cache_creation_input_tokens": usage.cache_creation_input_tokens,
                        "cache_read_input_tokens": usage.cache_read_input_tokens,
                    },
                )
            )

        return events

    def _map_result_entry(self, entry: dict, ts: int) -> list[Event]:
        """Map a result/summary entry to events.

        The result entry contains authoritative timing information for the session,
        including the actual work duration (excluding user think time).
        """
        try:
            result_entry = WebResultEntry.model_validate(entry)
        except Exception:
            return []

        events: list[Event] = []

        # Emit session result with authoritative duration
        # This is THE source of truth for active_duration_ms
        events.append(
            CustomEvent(
                timestamp_ms=ts,
                name="session_result",
                value={
                    "duration_ms": result_entry.duration_ms,
                    "duration_api_ms": result_entry.duration_api_ms,
                    "num_turns": result_entry.num_turns,
                    "total_cost_usd": result_entry.total_cost_usd,
                    "subtype": result_entry.subtype or "",
                    "is_error": result_entry.is_error,
                },
            )
        )

        # Emit per-model usage if available
        for model_name, usage in result_entry.model_usage.items():
            events.append(
                CustomEvent(
                    timestamp_ms=ts,
                    name="model_usage",
                    value={
                        "model": model_name,
                        "input_tokens": usage.input_tokens,
                        "output_tokens": usage.output_tokens,
                        "cache_creation_input_tokens": usage.cache_creation_input_tokens,
                        "cache_read_input_tokens": usage.cache_read_input_tokens,
                        "cost_usd": usage.cost_usd,
                    },
                )
            )

        return events
