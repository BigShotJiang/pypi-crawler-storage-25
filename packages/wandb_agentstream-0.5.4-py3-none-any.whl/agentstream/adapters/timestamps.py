"""Shared timestamp utilities for adapters."""

from __future__ import annotations

from datetime import UTC, datetime


def parse_timestamp(ts: str) -> int | None:
    """Parse ISO timestamp to milliseconds.

    Handles various ISO 8601 formats:
    - With "Z" suffix: "2025-01-07T10:00:00Z" -> treated as UTC
    - With offset: "2025-01-07T10:00:00+05:00" -> respected as-is
    - Naive (no timezone): "2025-01-07T10:00:00" -> treated as UTC

    Returns:
        Timestamp in milliseconds, or None if parsing fails.
    """
    if not ts:
        return None
    try:
        # Handle "Z" suffix (Python's fromisoformat needs +00:00 format)
        if ts.endswith("Z"):
            ts = ts[:-1] + "+00:00"

        dt = datetime.fromisoformat(ts)

        # If no timezone info, assume UTC
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)

        return int(dt.timestamp() * 1000)
    except Exception:
        return None


def parse_timestamp_with_fallback(ts: str | int | None, fallback_ms: int) -> int:
    """Parse timestamp to milliseconds, using provided fallback instead of datetime.now().

    This is the preferred function for timestamp parsing. It avoids using
    datetime.now() which can produce incorrect future timestamps when processing
    historical entries.

    Args:
        ts: Timestamp as ISO string, milliseconds integer, or None
        fallback_ms: Fallback timestamp in milliseconds to use if parsing fails

    Returns:
        Parsed timestamp in milliseconds, or fallback_ms if parsing fails
    """
    if ts is None:
        return fallback_ms
    if isinstance(ts, int):
        return ts if ts > 0 else fallback_ms
    # String timestamp - parse as ISO
    parsed = parse_timestamp(ts)
    return parsed if parsed is not None else fallback_ms


def parse_timestamp_or_now(ts: str | None) -> int:
    """Parse ISO timestamp to milliseconds, falling back to current time.

    DEPRECATED: Prefer parse_timestamp_with_fallback() which avoids datetime.now().
    Using datetime.now() as fallback can produce incorrect future timestamps when
    processing historical entries.

    Args:
        ts: ISO timestamp string, or None

    Returns:
        Parsed timestamp in milliseconds, or current time if parsing fails
    """
    if ts:
        parsed = parse_timestamp(ts)
        if parsed is not None:
            return parsed
    return int(datetime.now(UTC).timestamp() * 1000)


class TimestampTracker:
    """Tracks last valid timestamp for fallback handling.

    Use this class when reading events to ensure all events have valid
    timestamps, using fallback to last valid timestamp when parsing fails.

    In server-side processing, use with increment_ms to preserve event ordering
    when multiple entries have missing timestamps.
    """

    def __init__(self, fallback_ms: int, increment_ms: int = 0):
        """Initialize with a fallback timestamp.

        Args:
            fallback_ms: Initial fallback timestamp (e.g., first entry's timestamp).
            increment_ms: Amount to increment fallback each time get_fallback() is called.
                          Use 1ms to preserve event ordering when using fallbacks.
        """
        self._last_valid: int = fallback_ms
        self._fallback: int = fallback_ms
        self._increment_ms: int = increment_ms
        self._fallback_count: int = 0

    def parse(self, ts: str) -> int:
        """Parse timestamp string, returning fallback if parsing fails.

        Updates internal tracking of last valid timestamp.

        Args:
            ts: ISO timestamp string to parse.

        Returns:
            Parsed timestamp in milliseconds, or last valid timestamp as fallback.
        """
        parsed = parse_timestamp(ts)
        if parsed is not None:
            self._last_valid = parsed
            return parsed
        return self._last_valid

    def get_fallback(self) -> int:
        """Get current fallback timestamp, with optional increment.

        When increment_ms > 0, each call returns an incrementally higher value
        to preserve event ordering when multiple entries use fallbacks.

        Returns:
            Fallback timestamp in milliseconds.
        """
        result = self._last_valid + (self._fallback_count * self._increment_ms)
        self._fallback_count += 1
        return result

    def update(self, timestamp_ms: int) -> None:
        """Update last valid timestamp if newer.

        Call this after processing an entry to track the latest known timestamp.

        Args:
            timestamp_ms: Timestamp in milliseconds from a processed event.
        """
        if timestamp_ms > self._last_valid:
            self._last_valid = timestamp_ms
            self._fallback_count = 0  # Reset increment counter on valid timestamp

    @property
    def last_valid(self) -> int:
        """Return the last valid timestamp seen."""
        return self._last_valid
