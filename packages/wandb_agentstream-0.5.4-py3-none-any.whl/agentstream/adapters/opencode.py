"""OpenCode adapter for reading and writing session logs."""

from __future__ import annotations

import json
import os
import platform
import sqlite3
from collections.abc import Iterable, Iterator
from datetime import UTC, datetime
from pathlib import Path
from typing import IO, Any

from agentstream.events import (
    CustomEvent,
    Event,
    ReasoningMessageChunkEvent,
    Role,
    RunFinishedEvent,
    RunStartedEvent,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)
from agentstream.grouper import MessageGroup, group_events

from .base import Adapter, Session
from .timestamps import TimestampTracker


def _get_opencode_data_dir() -> Path:
    """Get OpenCode data directory based on XDG spec."""
    # XDG_DATA_HOME defaults to ~/.local/share on Unix
    system = platform.system()
    if system == "Windows":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return base / "opencode"


def _is_subpath(child: Path, parent: Path) -> bool:
    """Check if child is equal to or a subdirectory of parent."""
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


class OpenCodeAdapter(Adapter):
    """Adapter for OpenCode session storage (JSON files or SQLite in XDG directories)."""

    @property
    def name(self) -> str:
        return "opencode"

    # === Path Detection (for daemon watcher) ===

    @staticmethod
    def _get_db_path() -> Path | None:
        """Return the path to opencode.db if it exists."""
        db_path = _get_opencode_data_dir() / "opencode.db"
        return db_path if db_path.exists() else None

    def get_base_directories(self) -> list[Path]:
        """Return OpenCode session directories."""
        data_dir = _get_opencode_data_dir()
        dirs: list[Path] = []
        # If SQLite DB exists, watch the data dir (for DB file changes)
        if (data_dir / "opencode.db").exists():
            dirs.append(data_dir)
        # Also include legacy storage dir
        storage_dir = data_dir / "storage"
        dirs.append(storage_dir)
        return dirs

    def matches_path(self, path: Path) -> bool:
        """Return True if path is an OpenCode session/message/part file or DB."""
        data_dir = _get_opencode_data_dir()

        # Match SQLite DB and WAL files
        if path.name in ("opencode.db", "opencode.db-wal"):
            try:
                path.resolve().relative_to(data_dir.resolve())
                return True
            except ValueError:
                pass

        # Legacy file-based storage
        storage_dir = data_dir / "storage"
        try:
            path.resolve().relative_to(storage_dir.resolve())
        except ValueError:
            return False

        # OpenCode uses .json files
        if path.suffix != ".json":
            return False

        # Check if it's a session, message, or part file
        parts = path.parts
        return "session" in parts or "message" in parts or "part" in parts

    def get_session_id(self, path: Path) -> str:
        """Extract session ID from a file path.

        OpenCode session files are stored as:
        - session/<project_id>/<session_id>.json
        - message/<session_id>/<message_id>.json
        - part/<message_id>/<part_id>.json
        """
        parts = path.parts

        # If this is a session file directly
        if "session" in parts:
            return path.stem

        # If this is a message file, extract session ID from parent dir
        if "message" in parts and (msg_idx := parts.index("message")) + 1 < len(parts):
            return parts[msg_idx + 1]

        return path.stem

    def extract_sessions_from_file(self, path: Path) -> list[dict]:
        """Extract all sessions from OpenCode SQLite DB."""
        if path.name == "opencode.db" and path.exists():
            try:
                conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=10)
                conn.row_factory = sqlite3.Row
                rows = conn.execute("SELECT id FROM session").fetchall()
                conn.close()
                return [{"id": row["id"], "path": path, "format": self.name} for row in rows]
            except sqlite3.Error:
                pass
        # Fallback for legacy file-based storage
        return [{"id": self.get_session_id(path), "path": path, "format": self.name}]

    # === Raw Entry Reading (for incremental sync) ===

    def read_entries(self, session: Session) -> list[dict]:
        """Read all raw source entries from an OpenCode session.

        Checks SQLite DB first, falls back to file-based storage.
        """
        db_path = self._get_db_path()
        if db_path is not None:
            return self._read_entries_sqlite(session, db_path)

        return self._read_entries_files(session)

    def _read_entries_sqlite(self, session: Session, db_path: Path) -> list[dict]:
        """Read entries from SQLite database."""
        entries: list[dict] = []
        try:
            conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=10)
            conn.row_factory = sqlite3.Row
        except sqlite3.Error:
            return entries

        try:
            # Entry 0: Session info
            cur = conn.execute("SELECT * FROM session WHERE id = ?", (session.id,))
            row = cur.fetchone()
            if row:
                session_data = dict(zip(row.keys(), row, strict=False))
                ts = session_data.get("time_created", 0)
                entries.append(
                    {
                        "entry_index": 0,
                        "entry_content": json.dumps(session_data, separators=(",", ":")),
                        "entry_timestamp_ms": ts if isinstance(ts, int) else 0,
                        "entry_type": "session",
                    }
                )

            # Read messages ordered by time_created
            msg_rows = conn.execute(
                "SELECT * FROM message WHERE session_id = ? ORDER BY time_created",
                (session.id,),
            ).fetchall()

            for msg_row in msg_rows:
                msg_data_raw = msg_row["data"]
                if not msg_data_raw:
                    continue
                try:
                    msg_data = (
                        json.loads(msg_data_raw) if isinstance(msg_data_raw, str) else msg_data_raw
                    )
                except (json.JSONDecodeError, TypeError):
                    continue

                msg_id = msg_row["id"]
                timestamp_ms = msg_data.get("time", {}).get("created", 0)

                entries.append(
                    {
                        "entry_index": len(entries),
                        "entry_content": json.dumps(msg_data, separators=(",", ":")),
                        "entry_timestamp_ms": timestamp_ms,
                        "entry_type": "message",
                    }
                )

                # Read parts for this message
                msg_role = msg_data.get("role", "user")
                part_rows = conn.execute(
                    "SELECT * FROM part WHERE message_id = ? ORDER BY time_created",
                    (msg_id,),
                ).fetchall()

                for part_row in part_rows:
                    part_data_raw = part_row["data"]
                    if not part_data_raw:
                        continue
                    try:
                        part_data = (
                            json.loads(part_data_raw)
                            if isinstance(part_data_raw, str)
                            else part_data_raw
                        )
                    except (json.JSONDecodeError, TypeError):
                        continue

                    # Inject parent message role and timestamp
                    part_data["_parent_role"] = msg_role
                    part_data["_parent_timestamp_ms"] = timestamp_ms

                    # Get part timestamp
                    part_ts = timestamp_ms
                    state = part_data.get("state", {})
                    if isinstance(state, dict):
                        time_data = state.get("time", {})
                        if isinstance(time_data, dict):
                            part_ts = time_data.get("start", timestamp_ms)

                    entries.append(
                        {
                            "entry_index": len(entries),
                            "entry_content": json.dumps(part_data, separators=(",", ":")),
                            "entry_timestamp_ms": part_ts
                            if isinstance(part_ts, int)
                            else timestamp_ms,
                            "entry_type": "part",
                        }
                    )
        except sqlite3.Error:
            pass
        finally:
            conn.close()

        return entries

    def _read_entries_files(self, session: Session) -> list[dict]:
        """Read entries from file-based storage (legacy)."""
        entries = []
        storage_dir = _get_opencode_data_dir() / "storage"

        # Entry 0: Session info
        session_data = self._read_session_file(session.path)
        if session_data:
            entries.append(
                {
                    "entry_index": 0,
                    "entry_content": json.dumps(session_data, separators=(",", ":")),
                    "entry_timestamp_ms": session_data.get("time", {}).get("created", 0),
                    "entry_type": "session",
                }
            )

        # Read all messages for this session
        messages_dir = storage_dir / "message" / session.id
        if messages_dir.exists():
            message_files = sorted(messages_dir.glob("*.json"))

            for msg_file in message_files:
                msg_data = self._read_json_file(msg_file)
                if not msg_data:
                    continue

                msg_id = msg_data.get("id", msg_file.stem)
                timestamp_ms = msg_data.get("time", {}).get("created", 0)

                # Add message entry
                entries.append(
                    {
                        "entry_index": len(entries),
                        "entry_content": json.dumps(msg_data, separators=(",", ":")),
                        "entry_timestamp_ms": timestamp_ms,
                        "entry_type": "message",
                    }
                )

                # Read parts for this message
                # Inject parent message role and timestamp into parts for proper attribution
                msg_role = msg_data.get("role", "user")
                parts_dir = storage_dir / "part" / msg_id
                if parts_dir.exists():
                    part_files = sorted(parts_dir.glob("*.json"))
                    for part_file in part_files:
                        part_data = self._read_json_file(part_file)
                        if not part_data:
                            continue

                        # Inject parent message role and timestamp for parse_source_entry
                        part_data["_parent_role"] = msg_role
                        part_data["_parent_timestamp_ms"] = timestamp_ms

                        # Get part timestamp: tool parts have state.time.start, others use parent
                        part_ts = timestamp_ms
                        state = part_data.get("state", {})
                        if isinstance(state, dict):
                            time_data = state.get("time", {})
                            if isinstance(time_data, dict):
                                part_ts = time_data.get("start", timestamp_ms)

                        entries.append(
                            {
                                "entry_index": len(entries),
                                "entry_content": json.dumps(part_data, separators=(",", ":")),
                                "entry_timestamp_ms": part_ts
                                if isinstance(part_ts, int)
                                else timestamp_ms,
                                "entry_type": "part",
                            }
                        )

        return entries

    def _read_json_file(self, path: Path) -> dict | None:
        """Read and parse a JSON file."""
        try:
            with open(path) as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return None

    def _read_session_file(self, path: Path) -> dict | None:
        """Read session file."""
        return self._read_json_file(path)

    # === Session Discovery ===

    def discover_sessions(self, project_dir: Path) -> list[Session]:
        """Find OpenCode sessions for this project."""
        db_path = self._get_db_path()
        if db_path is not None:
            return self._discover_sessions_sqlite(project_dir, db_path)

        return self._discover_sessions_files(project_dir)

    def _discover_sessions_sqlite(self, project_dir: Path, db_path: Path) -> list[Session]:
        """Discover sessions from SQLite database."""
        sessions: list[Session] = []
        try:
            conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=10)
            conn.row_factory = sqlite3.Row
        except sqlite3.Error:
            return sessions

        try:
            project_resolved = project_dir.resolve()
            is_home_search = project_resolved == Path.home()

            rows = conn.execute(
                "SELECT s.id, s.project_id, s.directory, s.title, s.version, "
                "s.time_created, s.time_updated, p.worktree "
                "FROM session s LEFT JOIN project p ON s.project_id = p.id "
                "ORDER BY s.time_updated DESC"
            ).fetchall()

            for row in rows:
                worktree = Path(row["worktree"]) if row["worktree"] else None

                # Filter by project_dir
                if not is_home_search and worktree:
                    try:
                        wt_resolved = worktree.resolve()
                        matches = (
                            wt_resolved == project_resolved
                            or project_resolved in wt_resolved.parents
                            or wt_resolved in project_resolved.parents
                        )
                        if not matches:
                            continue
                    except (ValueError, OSError):
                        continue

                session_id = row["id"]
                modified_at = row["time_updated"] or row["time_created"] or 0
                # OpenCode timestamps are in milliseconds
                if isinstance(modified_at, int) and modified_at > 1e12:
                    modified_at = modified_at / 1000.0

                cwd = str(worktree) if worktree else row["directory"]

                sessions.append(
                    Session(
                        id=session_id,
                        path=db_path,
                        format=self.name,
                        modified_at=float(modified_at) if modified_at else 0.0,
                        metadata={
                            "projectID": row["project_id"],
                            "directory": row["directory"],
                            "title": row["title"],
                            "version": row["version"],
                            "cwd": cwd,
                        },
                    )
                )
        except sqlite3.Error:
            pass
        finally:
            conn.close()

        return sessions

    def _discover_sessions_files(self, project_dir: Path) -> list[Session]:
        """Discover sessions from file-based storage (legacy)."""
        sessions: list[Session] = []
        storage_dir = _get_opencode_data_dir() / "storage"
        session_dir = storage_dir / "session"
        project_file_dir = storage_dir / "project"

        if not session_dir.exists():
            return sessions

        project_resolved = project_dir.resolve()
        is_home_search = project_resolved == Path.home()

        # Build mapping of project IDs to their worktrees
        project_worktrees: dict[str, Path] = {}
        if project_file_dir.exists():
            for proj_file in project_file_dir.glob("*.json"):
                proj_data = self._read_json_file(proj_file)
                if proj_data and "worktree" in proj_data:
                    proj_id = proj_data.get("id", proj_file.stem)
                    project_worktrees[proj_id] = Path(proj_data["worktree"])

        # Scan all project directories in sessions
        for proj_dir in session_dir.iterdir():
            if not proj_dir.is_dir():
                continue

            project_id = proj_dir.name
            worktree = project_worktrees.get(project_id)

            # Skip if we're searching a specific project and this doesn't match
            if (
                not is_home_search
                and worktree
                and not _is_subpath(worktree, project_resolved)
                and not _is_subpath(project_resolved, worktree)
            ):
                continue

            # Find all session files in this project
            for session_file in proj_dir.glob("*.json"):
                session_data = self._read_json_file(session_file)
                if not session_data:
                    continue

                session_id = session_data.get("id", session_file.stem)
                modified_at = session_data.get("time", {}).get("updated")
                if not modified_at:
                    modified_at = session_data.get("time", {}).get("created", 0)

                # OpenCode timestamps are in milliseconds
                if isinstance(modified_at, int) and modified_at > 1e12:
                    modified_at = modified_at / 1000.0

                sessions.append(
                    Session(
                        id=session_id,
                        path=session_file,
                        format=self.name,
                        modified_at=float(modified_at)
                        if modified_at
                        else session_file.stat().st_mtime,
                        metadata={
                            "projectID": project_id,
                            "directory": session_data.get("directory"),
                            "title": session_data.get("title"),
                            "version": session_data.get("version"),
                            "cwd": str(worktree) if worktree else session_data.get("directory"),
                        },
                    )
                )

        # Sort by modification time, newest first
        sessions.sort(key=lambda s: s.modified_at, reverse=True)
        return sessions

    def read_events(self, session: Session) -> Iterator[Event]:
        """Read AG-UI events from an OpenCode session."""
        storage_dir = _get_opencode_data_dir() / "storage"

        # Read session data
        session_data = self._read_session_file(session.path)
        if not session_data:
            return

        session_cwd = session_data.get("directory")

        # Initialize timestamp tracker with session file mtime as fallback
        # Avoid datetime.now() which produces incorrect future timestamps for historical data
        file_mtime_ms = int(session.modified_at * 1000) if session.modified_at else 0
        ts_tracker = TimestampTracker(file_mtime_ms)

        first_ts = session_data.get("time", {}).get("created", 0)
        if first_ts <= 0:
            first_ts = ts_tracker.last_valid
        else:
            ts_tracker.update(first_ts)

        # Emit RunStarted
        yield RunStartedEvent(
            timestamp_ms=first_ts,
            thread_id=session.id,
            run_id=session.id,
        )

        # Emit source_entry for session
        yield CustomEvent(
            timestamp_ms=first_ts,
            name="source_entry",
            value={
                "format": "opencode",
                "entry_type": "session",
                "raw_data": session_data,
                "index": 0,
            },
        )

        # Read and process messages
        messages_dir = storage_dir / "message" / session.id
        if messages_dir.exists():
            message_files = sorted(messages_dir.glob("*.json"))
            entry_index = 1

            for msg_file in message_files:
                msg_data = self._read_json_file(msg_file)
                if not msg_data:
                    continue

                msg_id = msg_data.get("id", msg_file.stem)
                msg_ts = msg_data.get("time", {}).get("created", 0)
                if msg_ts <= 0:
                    msg_ts = ts_tracker.last_valid
                else:
                    ts_tracker.update(msg_ts)

                # Emit source_entry for message
                yield CustomEvent(
                    timestamp_ms=msg_ts,
                    name="source_entry",
                    value={
                        "format": "opencode",
                        "entry_type": "message",
                        "raw_data": msg_data,
                        "index": entry_index,
                    },
                )
                entry_index += 1

                # Read parts for this message
                parts_dir = storage_dir / "part" / msg_id
                parts_data = []
                if parts_dir.exists():
                    part_files = sorted(parts_dir.glob("*.json"))
                    for part_file in part_files:
                        part_data = self._read_json_file(part_file)
                        if part_data:
                            parts_data.append(part_data)

                            # Emit source_entry for part
                            part_ts = part_data.get("time", {})
                            if isinstance(part_ts, dict):
                                part_ts = part_ts.get("start", 0)
                            if not isinstance(part_ts, int) or part_ts <= 0:
                                part_ts = msg_ts
                            else:
                                ts_tracker.update(part_ts)
                            yield CustomEvent(
                                timestamp_ms=part_ts,
                                name="source_entry",
                                value={
                                    "format": "opencode",
                                    "entry_type": "part",
                                    "raw_data": part_data,
                                    "index": entry_index,
                                },
                            )
                            entry_index += 1

                # Map message and parts to AG-UI events
                yield from self._map_message(msg_data, parts_data, session_cwd)

        # Emit RunFinished
        yield RunFinishedEvent(timestamp_ms=ts_tracker.last_valid, run_id=session.id)

    def _map_message(
        self,
        msg_data: dict,
        parts_data: list[dict],
        session_cwd: str | None,
    ) -> Iterator[Event]:
        """Map an OpenCode message and its parts to AG-UI events."""
        msg_id = msg_data.get("id", "")
        msg_ts = msg_data.get("time", {}).get("created", 0)
        role = msg_data.get("role", "user")

        if role == "user":
            # User messages: extract text from parts
            text_parts = []
            for part in parts_data:
                part_type = part.get("type")
                if part_type == "text":
                    text_parts.append(part.get("text", ""))

            combined_text = "".join(text_parts)
            if combined_text:
                yield TextMessageChunkEvent(
                    timestamp_ms=msg_ts,
                    message_id=msg_id,
                    role=Role.USER,
                    delta=combined_text,
                )

        elif role == "assistant":
            # Assistant messages: process all parts
            text_parts = []
            reasoning_parts = []
            tool_parts = []

            for part in parts_data:
                part_type = part.get("type")
                part_ts = part.get("time", {})
                if isinstance(part_ts, dict):
                    part_ts = part_ts.get("start", msg_ts)
                if not isinstance(part_ts, int):
                    part_ts = msg_ts

                if part_type == "text":
                    text_parts.append((part.get("text", ""), part_ts))

                elif part_type == "reasoning":
                    reasoning_parts.append((part.get("text", ""), part_ts))

                elif part_type == "tool":
                    tool_parts.append((part, part_ts))

            # Emit reasoning first
            for text, ts in reasoning_parts:
                if text:
                    yield ReasoningMessageChunkEvent(
                        timestamp_ms=ts,
                        message_id=msg_id,
                        delta=text,
                    )

            # Emit text content
            for text, ts in text_parts:
                if text:
                    yield TextMessageChunkEvent(
                        timestamp_ms=ts,
                        message_id=msg_id,
                        role=Role.ASSISTANT,
                        delta=text,
                    )

            # Emit tool calls
            for part, ts in tool_parts:
                call_id = part.get("callID", "")
                tool_name = part.get("tool", "")
                state = part.get("state", {})

                tool_input = state.get("input", {})
                yield ToolCallChunkEvent(
                    timestamp_ms=ts,
                    tool_call_id=call_id,
                    tool_call_name=tool_name,
                    parent_message_id=msg_id,
                    delta=json.dumps(tool_input),
                )

                # Emit result if completed
                status = state.get("status")
                if status == "completed":
                    output = state.get("output", "")
                    yield ToolCallResultEvent(
                        timestamp_ms=ts,
                        tool_call_id=call_id,
                        tool_call_result_id=f"{call_id}-result",
                        result=output,
                    )
                elif status == "error":
                    error = state.get("error", "")
                    yield ToolCallResultEvent(
                        timestamp_ms=ts,
                        tool_call_id=call_id,
                        tool_call_result_id=f"{call_id}-result",
                        result=error,
                        is_error=True,
                    )

    def write_events(self, events: Iterable[Event], dest: IO[str]) -> None:
        """Write AG-UI events as OpenCode format.

        Note: OpenCode uses a directory structure, not a single file.
        For file output, we write a JSON Lines format summary.
        """
        events_list = list(events)

        # Extract source entries for this format
        source_entries = [
            e.value
            for e in events_list
            if isinstance(e, CustomEvent)
            and e.name == "source_entry"
            and e.value.get("format") == self.name
        ]

        if source_entries:
            # Same-format: output originals directly
            self._write_source_entries(dest, source_entries)
        else:
            # Cross-format: reconstruct from AG-UI events
            self._reconstruct_from_events(events_list, dest)

    def _write_source_entries(self, dest: IO[str], entries: list[dict[str, object]]) -> None:
        """Write source entries as JSON Lines."""
        for entry in sorted(entries, key=lambda e: int(e.get("index", 0))):
            raw_data = entry.get("raw_data", {})
            dest.write(json.dumps(raw_data) + "\n")

    def _reconstruct_from_events(self, events_list: list[Event], dest: IO[str]) -> None:
        """Reconstruct from AG-UI events (cross-format fallback)."""
        # Group message events
        messages = list(group_events(events_list))
        now_ms = int(datetime.now(UTC).timestamp() * 1000)

        # Write session header
        session_data = {
            "id": "reconstructed-session",
            "projectID": "unknown",
            "directory": "",
            "time": {"created": now_ms, "updated": now_ms},
        }
        dest.write(json.dumps(session_data) + "\n")

        # Write messages
        for msg in messages:
            msg_data = self._message_to_opencode(msg, now_ms)
            dest.write(json.dumps(msg_data) + "\n")

    def _message_to_opencode(self, msg: MessageGroup, timestamp: int) -> dict[str, Any]:
        """Convert a MessageGroup to OpenCode message format."""
        role = "user" if msg.role == Role.USER else "assistant"

        return {
            "id": msg.id,
            "sessionID": "reconstructed-session",
            "role": role,
            "time": {"created": timestamp},
            "text": msg.text,
            "tool_calls": [
                {
                    "callID": tc.id,
                    "tool": tc.name,
                    "state": {
                        "status": "completed" if tc.result else "pending",
                        "input": tc.args,
                        "output": tc.result,
                    },
                }
                for tc in msg.tool_calls
            ],
        }

    def parse_source_entry(
        self,
        entry: dict,
        entry_index: int,
        session_id: str,
    ) -> list[Event]:
        """Parse a single source entry into AG-UI events.

        Args:
            entry: Parsed JSON from source_entry.entry_content
            entry_index: Position in session (for event ID generation)
            session_id: Session UUID

        Returns:
            List of AG-UI events (may be empty)
        """
        events: list[Event] = []

        # Determine entry type from content
        entry_role = entry.get("role")
        entry_type_field = entry.get("type")

        # Skip session entries (no semantic events)
        if "projectID" in entry and "directory" in entry and not entry_role:
            return events

        # Get timestamp - check multiple sources in priority order:
        # 1. For message entries: time.created
        # 2. For tool parts: state.time.start
        # 3. For other parts: _parent_timestamp_ms (injected by read_entries)
        # 4. _timestamp_ms (injected by processing.py from source entry timestamp)
        ts = 0
        time_data = entry.get("time", {})
        if isinstance(time_data, dict) and "created" in time_data:
            ts = time_data.get("created", 0)
        elif "_parent_timestamp_ms" in entry:
            ts = entry.get("_parent_timestamp_ms", 0)

        # For tool parts, also check state.time.start
        state = entry.get("state", {})
        if isinstance(state, dict):
            state_time = state.get("time", {})
            if isinstance(state_time, dict) and "start" in state_time:
                ts = state_time.get("start", ts)

        # Final fallback: use _timestamp_ms injected by processing.py
        # This is critical for entries with missing timestamps to avoid ts=0
        # which causes incorrect duration calculations
        if ts <= 0:
            ts = entry.get("_timestamp_ms", 0)

        # Message entries - text content is in separate part entries
        # We only emit events for parts, not for message entries themselves
        if entry_role == "user" or entry_role == "assistant":
            # Message entries are metadata only - actual content is in parts
            # We don't emit events here; parts will generate the events
            pass

        # Part entries
        elif entry_type_field == "text":
            text = entry.get("text", "")
            msg_id = entry.get("messageID", f"msg-{entry_index}")

            # Determine role from parent message (injected by read_entries)
            parent_role = entry.get("_parent_role", "assistant")
            role = Role.USER if parent_role == "user" else Role.ASSISTANT

            if text:
                events.append(
                    TextMessageChunkEvent(
                        timestamp_ms=ts,
                        message_id=msg_id,
                        role=role,
                        delta=text,
                    )
                )

        elif entry_type_field == "reasoning":
            text = entry.get("text", "")
            msg_id = entry.get("messageID", f"msg-{entry_index}")

            if text:
                events.append(
                    ReasoningMessageChunkEvent(
                        timestamp_ms=ts,
                        message_id=msg_id,
                        delta=text,
                    )
                )

        elif entry_type_field == "tool":
            call_id = entry.get("callID", "")
            tool_name = entry.get("tool", "")
            state = entry.get("state", {})
            msg_id = entry.get("messageID", f"msg-{entry_index}")

            tool_input = state.get("input", {})
            events.append(
                ToolCallChunkEvent(
                    timestamp_ms=ts,
                    tool_call_id=call_id,
                    tool_call_name=tool_name,
                    parent_message_id=msg_id,
                    delta=json.dumps(tool_input),
                )
            )

            status = state.get("status")
            if status == "completed":
                output = state.get("output", "")
                events.append(
                    ToolCallResultEvent(
                        timestamp_ms=ts,
                        tool_call_id=call_id,
                        tool_call_result_id=f"{call_id}-result",
                        result=output,
                    )
                )
            elif status == "error":
                error = state.get("error", "")
                events.append(
                    ToolCallResultEvent(
                        timestamp_ms=ts,
                        tool_call_id=call_id,
                        tool_call_result_id=f"{call_id}-result",
                        result=error,
                        is_error=True,
                    )
                )

        # Tag all events with entry_index for incremental processing
        for event in events:
            if not hasattr(event, "_source"):
                event._source = {}  # type: ignore[attr-defined]
            event._source["entry_index"] = entry_index  # type: ignore[attr-defined, index]

        return events
