"""Gemini CLI adapter for reading and writing session logs."""

from __future__ import annotations

import copy
import hashlib
import json
from collections.abc import Iterable, Iterator
from datetime import UTC, datetime
from pathlib import Path
from typing import IO, Any

from agentstream.analytics import normalize_path
from agentstream.events import (
    CustomEvent,
    Event,
    EventType,
    ReasoningMessageChunkEvent,
    Role,
    RunFinishedEvent,
    RunStartedEvent,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)
from agentstream.formats.gemini import GeminiMessage, GeminiSession, GeminiTokens, GeminiToolCall
from agentstream.grouper import MessageGroup, group_events

from .base import Adapter, Session
from .timestamps import TimestampTracker, parse_timestamp_or_now, parse_timestamp_with_fallback

# Tool names that perform file operations (Gemini conventions)
_FILE_READ_TOOLS = frozenset({"read_file", "ReadFile", "view_file", "cat"})
_FILE_WRITE_TOOLS = frozenset({"write_file", "WriteFile", "create_file"})
_FILE_EDIT_TOOLS = frozenset({"edit_file", "EditFile", "patch_file", "replace_in_file"})
_FILE_DELETE_TOOLS = frozenset({"delete_file", "DeleteFile", "remove_file"})
_FILE_LIST_TOOLS = frozenset({"list_files", "ListFiles", "list_dir", "ls", "glob"})
_FILE_SEARCH_TOOLS = frozenset({"search_files", "SearchFiles", "grep", "find_in_files"})


class GeminiAdapter(Adapter):
    """Adapter for Gemini CLI JSON session logs."""

    @property
    def name(self) -> str:
        return "gemini"

    # === Path Detection (for daemon watcher) ===

    def get_base_directories(self) -> list[Path]:
        """Return Gemini tmp directory."""
        return [Path.home() / ".gemini" / "tmp"]

    def matches_path(self, path: Path) -> bool:
        """Return True if path is a Gemini session file."""
        return ".gemini" in path.parts and path.suffix == ".json"

    # === Raw Entry Reading (for incremental sync) ===

    def read_entries(self, session: Session) -> list[dict]:
        """Read all raw source entries from a Gemini session.

        Gemini stores sessions as JSON with a messages array.
        Each message becomes a separate entry.

        Returns:
            List of entry dicts with: entry_index, entry_content, entry_timestamp_ms
        """

        entries = []

        try:
            data = json.loads(session.path.read_text())
        except (json.JSONDecodeError, OSError):
            return entries

        messages = data.get("messages", [])
        if not isinstance(messages, list):
            return entries

        for i, message in enumerate(messages):
            if not isinstance(message, dict):
                continue

            timestamp_ms = parse_timestamp_or_now(message.get("timestamp"))

            entries.append(
                {
                    "entry_index": i,
                    "entry_content": json.dumps(message),
                    "entry_timestamp_ms": timestamp_ms,
                }
            )

        return entries

    def read_entries_after(self, session: Session, after_index: int = -1) -> list[dict]:
        """Read entries after given index.

        For Gemini, we read the JSON file and filter messages.
        """

        entries = []

        try:
            data = json.loads(session.path.read_text())
        except (json.JSONDecodeError, OSError):
            return entries

        messages = data.get("messages", [])
        if not isinstance(messages, list):
            return entries

        for i, message in enumerate(messages):
            if i <= after_index:
                continue
            if not isinstance(message, dict):
                continue

            timestamp_ms = parse_timestamp_or_now(message.get("timestamp"))

            entries.append(
                {
                    "entry_index": i,
                    "entry_content": json.dumps(message),
                    "entry_timestamp_ms": timestamp_ms,
                }
            )

        return entries

    # === Session Discovery ===

    def discover_sessions(self, project_dir: Path) -> list[Session]:
        """Find Gemini sessions for this project."""
        sessions: list[Session] = []

        # Gemini stores sessions in ~/.gemini/tmp/<sha256-hash>/chats/
        gemini_base = Path.home() / ".gemini" / "tmp"
        if not gemini_base.exists():
            return sessions

        # Calculate SHA256 hash of project path
        project_hash = hashlib.sha256(str(project_dir.resolve()).encode()).hexdigest()

        chats_dir = gemini_base / project_hash / "chats"
        if not chats_dir.exists():
            return sessions

        for session_file in chats_dir.glob("session-*.json"):
            try:
                data = json.loads(session_file.read_text())
                session_id = data.get("sessionId", session_file.stem)

                stat = session_file.stat()
                sessions.append(
                    Session(
                        id=session_id,
                        path=session_file,
                        format=self.name,
                        modified_at=stat.st_mtime,
                        metadata={"projectHash": data.get("projectHash")},
                    )
                )
            except Exception:
                continue  # Skip malformed files

        # Sort by modification time, newest first
        sessions.sort(key=lambda s: s.modified_at, reverse=True)
        return sessions

    def read_events(self, session: Session) -> Iterator[Event]:
        """Read AG-UI events from a Gemini session.

        Ensures all events have valid timestamps using TimestampTracker.
        """
        # Parse raw JSON and keep a copy for lossless round-trip
        # (Pydantic validation may mutate the dict in place)
        raw_data = json.loads(session.path.read_text())
        raw_data_copy = copy.deepcopy(raw_data)
        data = GeminiSession.model_validate(raw_data)

        # Initialize timestamp tracker with file mtime as fallback
        file_mtime_ms = int(session.modified_at * 1000)
        ts_tracker = TimestampTracker(file_mtime_ms)

        # Parse session start time
        start_ts = ts_tracker.parse(data.start_time)

        # Emit session-level source_entry (with messages removed for the session envelope)
        # Use raw_data_copy to preserve original structure before Pydantic mutation
        session_envelope = {k: v for k, v in raw_data_copy.items() if k != "messages"}
        session_envelope["messages"] = []  # Empty placeholder

        yield CustomEvent(
            timestamp_ms=start_ts,
            name="source_entry",
            value={
                "format": "gemini",
                "entry_type": "session",
                "entry": session_envelope,
                "index": 0,
            },
        )

        # Emit RunStarted
        yield RunStartedEvent(
            timestamp_ms=start_ts,
            thread_id=data.session_id,
            run_id=data.session_id,
        )

        # Emit per-message source_entry events
        raw_messages = raw_data_copy.get("messages", [])
        for msg_index, (msg, raw_msg) in enumerate(zip(data.messages, raw_messages, strict=False)):
            ts = ts_tracker.parse(msg.timestamp)

            # Emit source_entry for this message
            yield CustomEvent(
                timestamp_ms=ts,
                name="source_entry",
                value={
                    "format": "gemini",
                    "entry_type": "message",
                    "entry": raw_msg,
                    "index": msg_index + 1,  # +1 because index 0 is session envelope
                },
            )

            if msg.type == "info":
                # CLI notifications as CustomEvent
                yield CustomEvent(
                    timestamp_ms=ts,
                    name="info",
                    value={"content": msg.content, "id": msg.id},
                )
                continue

            # Map gemini -> assistant, user -> user
            role = Role.USER if msg.type == "user" else Role.ASSISTANT

            has_text = bool(msg.content) or role == Role.USER

            # Emit reasoning chunk events for thoughts (before other content)
            for thought in msg.thoughts:
                thought_ts = ts_tracker.parse(thought.timestamp)

                yield ReasoningMessageChunkEvent(
                    timestamp_ms=thought_ts,
                    message_id=msg.id,
                    delta=f"**{thought.subject}**\n{thought.description}",
                )

            # Emit tool calls as chunk events
            for tc in msg.tool_calls:
                tc_ts = ts_tracker.parse(tc.timestamp)

                yield ToolCallChunkEvent(
                    timestamp_ms=tc_ts,
                    tool_call_id=tc.id,
                    tool_call_name=tc.name,
                    parent_message_id=msg.id,
                    delta=json.dumps(tc.args),
                )

                # Tool result is embedded in the same message
                if tc.result:
                    response = tc.result[0].function_response
                    output = response.get("response", {}).get("output", "")
                    yield ToolCallResultEvent(
                        timestamp_ms=tc_ts,
                        tool_call_id=tc.id,
                        tool_call_result_id=f"{tc.id}-result",
                        result=str(output) if output else "",
                    )

            # Emit text message as chunk event if there's content or it's a user message
            if has_text:
                yield TextMessageChunkEvent(
                    timestamp_ms=ts,
                    message_id=msg.id,
                    role=role,
                    delta=msg.content or "",
                )

        # Emit RunFinished - use last valid timestamp
        yield RunFinishedEvent(
            timestamp_ms=ts_tracker.last_valid,
            run_id=data.session_id,
        )

    def write_events(self, events: Iterable[Event], dest: IO[str]) -> None:
        """Write AG-UI events as Gemini JSON."""
        events_list = list(events)

        # Extract source entries for this format
        source_entries = [
            e.value
            for e in events_list
            if isinstance(e, CustomEvent)
            and e.name == "source_entry"
            and e.value.get("format") == self.name
        ]

        if source_entries:
            # Same-format: output originals directly (lossless)
            self._write_source_entries(dest, source_entries)
        else:
            # Cross-format: reconstruct from AG-UI events
            self._reconstruct_from_events(events_list, dest)

    def _write_source_entries(self, dest: IO[str], entries: list[dict[str, object]]) -> None:
        """Write source entries directly for lossless same-format output."""
        # Find session-level entry (entry_type="session")
        session_entry = next((e for e in entries if e.get("entry_type") == "session"), None)

        # Find message entries, sorted by index
        message_entries = sorted(
            [e for e in entries if e.get("entry_type") == "message"],
            key=lambda e: int(e.get("index", 0)),
        )

        # Reassemble the JSON structure
        output: dict[str, object] = dict(session_entry["entry"]) if session_entry else {}
        output["messages"] = [m["entry"] for m in message_entries]

        dest.write(json.dumps(output, indent=2))

    def _reconstruct_from_events(self, events_list: list[Event], dest: IO[str]) -> None:
        """Reconstruct Gemini JSON from AG-UI events (cross-format fallback)."""
        # Extract session metadata from RunStartedEvent
        run_started: RunStartedEvent | None = None
        for event in events_list:
            if event.type == EventType.RUN_STARTED and isinstance(event, RunStartedEvent):
                run_started = event

        # Group message events
        messages = list(group_events(events_list))
        if not messages and not run_started:
            dest.write("{}")
            return

        # Build Gemini session structure - restore from raw_event for round-trip fidelity
        now = datetime.now(UTC).isoformat().replace("+00:00", "Z")

        # Get session ID from RunStartedEvent if available
        session_id = (
            run_started.run_id if run_started else (messages[0].id if messages else "unknown")
        )

        session_data: dict[str, object] = {
            "sessionId": session_id,
            "projectHash": "",
            "startTime": now,
            "lastUpdated": now,
            "messages": [self._message_to_gemini(msg) for msg in messages],
        }

        dest.write(json.dumps(session_data, indent=2))

    def _message_to_gemini(self, msg: MessageGroup) -> dict[str, object]:
        """Convert a MessageGroup to Gemini message format."""
        # Determine message type
        msg_type = "user" if msg.role == Role.USER else "gemini"

        result: dict[str, object] = {
            "id": msg.id,
            "timestamp": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
            "type": msg_type,
            "content": msg.text,
        }

        # Add thoughts from reasoning blocks
        if msg.reasoning:
            thoughts = []
            for r in msg.reasoning:
                # Parse subject/description from formatted content
                content = r.content
                subject = "Thinking"
                description = content
                if content.startswith("**") and "**\n" in content:
                    parts = content.split("**\n", 1)
                    subject = parts[0].strip("*")
                    description = parts[1] if len(parts) > 1 else ""
                thoughts.append(
                    {
                        "subject": subject,
                        "description": description,
                        "timestamp": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
                    }
                )
            result["thoughts"] = thoughts

        # Add tool calls
        if msg.tool_calls:
            tool_calls = []
            for tc in msg.tool_calls:
                tc_entry: dict[str, object] = {
                    "id": tc.id,
                    "name": tc.name,
                    "args": tc.args,
                    "result": [],
                    "status": "error" if tc.is_error else "success",
                    "timestamp": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
                }
                if tc.result is not None:
                    tc_entry["result"] = [
                        {
                            "functionResponse": {
                                "id": tc.id,
                                "name": tc.name,
                                "response": {"output": tc.result},
                            }
                        }
                    ]
                tool_calls.append(tc_entry)
            result["toolCalls"] = tool_calls

        return result

    @staticmethod
    def _build_usage_from_tokens(tokens: GeminiTokens | None) -> dict[str, int] | None:
        """Normalize Gemini token counters for analytics."""
        if tokens is None:
            return None

        usage: dict[str, int] = {}
        if tokens.input:
            usage["input_tokens"] = tokens.input
        if tokens.output:
            usage["output_tokens"] = tokens.output
        if tokens.cached:
            usage["cache_read_input_tokens"] = tokens.cached
        if tokens.thoughts:
            usage["reasoning_tokens"] = tokens.thoughts

        return usage or None

    @staticmethod
    def _extract_single_file_op(
        tc: GeminiToolCall, session_cwd: str | None
    ) -> dict[str, Any] | None:
        """Extract file operation from a single Gemini tool call.

        Args:
            tc: The tool call to extract file op from.
            session_cwd: Working directory for path normalization.

        Returns:
            File operation dict or None if not a file operation.
        """
        tool_name = tc.name or ""
        args = tc.args or {}

        if tool_name in _FILE_READ_TOOLS:
            raw_path = args.get("file_path") or args.get("path")
            if raw_path:
                return {"op": "read", "path": normalize_path(raw_path, session_cwd)}

        elif tool_name in _FILE_WRITE_TOOLS:
            raw_path = args.get("file_path") or args.get("path")
            if raw_path:
                return {"op": "write", "path": normalize_path(raw_path, session_cwd)}

        elif tool_name in _FILE_EDIT_TOOLS:
            raw_path = args.get("file_path") or args.get("path")
            if raw_path:
                return {"op": "edit", "path": normalize_path(raw_path, session_cwd)}

        elif tool_name in _FILE_DELETE_TOOLS:
            raw_path = args.get("file_path") or args.get("path")
            if raw_path:
                return {"op": "delete", "path": normalize_path(raw_path, session_cwd)}

        elif tool_name in _FILE_LIST_TOOLS:
            op_dict: dict[str, Any] = {"op": "list"}
            if "pattern" in args:
                op_dict["pattern"] = args["pattern"]
            raw_path = args.get("path") or args.get("directory")
            if raw_path:
                op_dict["path"] = normalize_path(raw_path, session_cwd)
            return op_dict

        elif tool_name in _FILE_SEARCH_TOOLS:
            op_dict: dict[str, Any] = {"op": "search"}
            if "pattern" in args or "query" in args:
                op_dict["pattern"] = args.get("pattern") or args.get("query")
            raw_path = args.get("path") or args.get("directory")
            if raw_path:
                op_dict["path"] = normalize_path(raw_path, session_cwd)
            return op_dict

        return None

    def parse_source_entry(
        self,
        entry: dict,
        entry_index: int,
        session_id: str,
    ) -> list[Event]:
        """Parse a single source entry into AG-UI events.

        Args:
            entry: Parsed JSON from source_entry.entry_content
            entry_index: Position in session (for event ID generation)
            session_id: Session UUID

        Returns:
            List of AG-UI events (may be empty)
        """

        events: list[Event] = []

        # Skip synthetic daemon_metadata entry (from dump command fixtures)
        if entry.get("type") == "daemon_metadata":
            return events

        # Session envelope doesn't produce semantic events
        if "sessionId" in entry and "messages" in entry:
            return events

        # Parse as GeminiMessage
        try:
            msg = GeminiMessage.model_validate(entry)
        except Exception:
            # Not a valid message - return empty
            return events

        # Parse timestamp from entry (crucial for correct event ordering!)
        # Use _timestamp_ms from processing pipeline as fallback (never datetime.now())
        fallback_ts = entry.get("_timestamp_ms", 0)
        ts = parse_timestamp_with_fallback(msg.timestamp, fallback_ts)

        # Handle info messages
        if msg.type == "info":
            return events

        # Map gemini -> assistant, user -> user
        role = Role.USER if msg.type == "user" else Role.ASSISTANT

        # Emit reasoning chunk events for thoughts (before other content)
        for thought in msg.thoughts:
            events.append(
                ReasoningMessageChunkEvent(
                    timestamp_ms=ts,
                    message_id=msg.id,
                    delta=f"**{thought.subject}**\n{thought.description}",
                )
            )

        # Emit tool calls as chunk events
        for tc in msg.tool_calls:
            events.append(
                ToolCallChunkEvent(
                    timestamp_ms=ts,
                    tool_call_id=tc.id,
                    tool_call_name=tc.name,
                    parent_message_id=msg.id,
                    delta=json.dumps(tc.args),
                )
            )

            # Tool result is embedded in the same message
            if tc.result:
                response = tc.result[0].function_response
                output = response.get("response", {}).get("output", "")
                events.append(
                    ToolCallResultEvent(
                        timestamp_ms=ts,
                        tool_call_id=tc.id,
                        tool_call_result_id=f"{tc.id}-result",
                        result=str(output) if output else "",
                    )
                )

        # Emit text message as chunk event if there's content or it's a user message
        if msg.content or role == Role.USER:
            events.append(
                TextMessageChunkEvent(
                    timestamp_ms=ts,
                    message_id=msg.id,
                    role=role,
                    delta=msg.content or "",
                )
            )

        # Tag all events with entry_index for incremental processing
        for event in events:
            if not hasattr(event, "_source"):
                event._source = {}  # type: ignore[attr-defined]
            event._source["entry_index"] = entry_index  # type: ignore[attr-defined, index]

        return events

    @staticmethod
    def _extract_file_ops(
        tool_calls: list[GeminiToolCall], session_cwd: str | None
    ) -> list[dict[str, Any]]:
        """Extract file operations from Gemini tool calls.

        Args:
            tool_calls: List of tool calls from the message.
            session_cwd: Working directory for path normalization.

        Returns:
            List of file operation dicts.
        """
        file_ops: list[dict[str, Any]] = []
        for tc in tool_calls:
            op = GeminiAdapter._extract_single_file_op(tc, session_cwd)
            if op:
                file_ops.append(op)
        return file_ops
