"""Codex CLI adapter for reading and writing session logs."""

from __future__ import annotations

import json
from collections.abc import Iterable, Iterator
from datetime import UTC, datetime
from pathlib import Path
from typing import IO, Any

from agentstream.analytics import normalize_path
from agentstream.events import (
    CustomEvent,
    Event,
    EventType,
    ReasoningMessageChunkEvent,
    Role,
    RunFinishedEvent,
    RunStartedEvent,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)
from agentstream.formats.codex import CodexLogEntry
from agentstream.grouper import MessageGroup, group_events

from .base import Adapter, Session
from .timestamps import TimestampTracker, parse_timestamp_or_now, parse_timestamp_with_fallback

# Tool names that perform file operations (Codex conventions)
_FILE_READ_TOOLS = frozenset({"read_file", "cat", "view"})
_FILE_WRITE_TOOLS = frozenset({"write_file", "create_file", "write"})
_FILE_EDIT_TOOLS = frozenset({"edit_file", "patch", "apply_diff"})
_FILE_DELETE_TOOLS = frozenset({"delete_file", "rm"})
_FILE_LIST_TOOLS = frozenset({"list_files", "ls", "list_dir"})
_FILE_SEARCH_TOOLS = frozenset({"grep", "search", "find"})
_SHELL_TOOLS = frozenset({"exec_command", "shell", "bash", "run_command"})


def _is_subpath(child: Path, parent: Path) -> bool:
    """Check if child is equal to or a subdirectory of parent."""
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


class CodexAdapter(Adapter):
    """Adapter for Codex CLI JSONL session logs."""

    @property
    def name(self) -> str:
        return "codex"

    # === Path Detection (for daemon watcher) ===

    def get_base_directories(self) -> list[Path]:
        """Return Codex session directories."""
        return [Path.home() / ".codex" / "sessions"]

    def matches_path(self, path: Path) -> bool:
        """Return True if path is a Codex session file."""
        return ".codex" in path.parts and path.suffix == ".jsonl"

    def get_session_id(self, path: Path) -> str:
        """Extract canonical Codex session ID from session_meta payload when available."""
        try:
            with open(path) as f:
                first_line = f.readline().strip()
                if not first_line:
                    return path.stem
                data = json.loads(first_line)
                if data.get("type") == "session_meta":
                    payload = data.get("payload", {})
                    session_id = payload.get("id")
                    if isinstance(session_id, str) and session_id:
                        return session_id
        except (OSError, json.JSONDecodeError):
            pass
        return path.stem

    # === Raw Entry Reading (for incremental sync) ===

    def read_entries(self, session: Session) -> list[dict]:
        """Read all raw source entries from a Codex session.

        Returns:
            List of entry dicts with: entry_index, entry_content, entry_timestamp_ms
        """

        entries = []
        with open(session.path) as f:
            for i, line in enumerate(f):
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    timestamp_ms = parse_timestamp_or_now(entry.get("timestamp"))
                    entries.append(
                        {
                            "entry_index": i,
                            "entry_content": line,  # Keep raw line for fidelity
                            "entry_timestamp_ms": timestamp_ms,
                        }
                    )
                except json.JSONDecodeError:
                    continue
        return entries

    def read_entries_after(self, session: Session, after_index: int = -1) -> list[dict]:
        """Read entries after given index (streaming for efficiency)."""

        entries = []
        with open(session.path) as f:
            for i, line in enumerate(f):
                if i <= after_index:
                    continue
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    timestamp_ms = parse_timestamp_or_now(entry.get("timestamp"))
                    entries.append(
                        {
                            "entry_index": i,
                            "entry_content": line,
                            "entry_timestamp_ms": timestamp_ms,
                        }
                    )
                except json.JSONDecodeError:
                    continue
        return entries

    # === Session Discovery ===

    def discover_sessions(self, project_dir: Path) -> list[Session]:
        """Find Codex sessions for this project."""
        sessions: list[Session] = []

        # Codex stores sessions in ~/.codex/sessions/<year>/<month>/<day>/*.jsonl
        codex_base = Path.home() / ".codex" / "sessions"
        if not codex_base.exists():
            return sessions

        project_resolved = project_dir.resolve()

        # Walk all JSONL files in the sessions directory
        for session_file in codex_base.rglob("*.jsonl"):
            try:
                # Read first line to get session_meta
                with open(session_file) as f:
                    first_line = f.readline().strip()
                    if not first_line:
                        continue

                entry = json.loads(first_line)
                if entry.get("type") != "session_meta":
                    continue

                payload = entry.get("payload", {})
                session_cwd = payload.get("cwd", "")
                session_id = payload.get("id", session_file.stem)

                # Check if session cwd matches project (subdirectory inclusive)
                if not session_cwd:
                    continue
                session_cwd_path = Path(session_cwd)
                if not _is_subpath(session_cwd_path, project_resolved):
                    continue

                stat = session_file.stat()
                sessions.append(
                    Session(
                        id=session_id,
                        path=session_file,
                        format=self.name,
                        modified_at=stat.st_mtime,
                        metadata=payload,
                    )
                )
            except Exception:
                continue

        # Sort by modification time, newest first
        sessions.sort(key=lambda s: s.modified_at, reverse=True)
        return sessions

    def read_events(self, session: Session) -> Iterator[Event]:
        """Read AG-UI events from a Codex session.

        Ensures all events have valid timestamps using TimestampTracker.
        """
        session_meta: dict[str, object] | None = None
        session_cwd: str | None = None
        pending_usage: dict[str, int] | None = None
        pending_usage_model: str | None = None
        current_model: str | None = None

        # Initialize timestamp tracker with file mtime as fallback
        file_mtime_ms = int(session.modified_at * 1000)
        ts_tracker = TimestampTracker(file_mtime_ms)

        with open(session.path) as f:
            for line_index, line in enumerate(f):
                line = line.strip()
                if not line:
                    continue

                try:
                    # Store raw line for lossless round-trip, parse for semantic processing
                    entry = CodexLogEntry.model_validate_json(line)
                except Exception:
                    continue

                ts = ts_tracker.parse(entry.timestamp)

                # Emit source_entry for round-trip fidelity (store raw line for lossless output)
                yield CustomEvent(
                    timestamp_ms=ts,
                    name="source_entry",
                    value={
                        "format": "codex",
                        "entry_type": entry.type,
                        "raw_line": line,
                        "index": line_index,
                    },
                )

                if entry.type == "session_meta":
                    session_meta = entry.payload
                    session_cwd = str(entry.payload.get("cwd", "")) or None
                    yield RunStartedEvent(
                        timestamp_ms=ts,
                        run_id=entry.payload.get("id", session.id),
                        thread_id=entry.payload.get("id", session.id),
                    )

                elif entry.type == "response_item":
                    usage_payload: dict[str, int] | None = None
                    usage_model = pending_usage_model or current_model
                    payload_type = entry.payload.get("type")
                    role = entry.payload.get("role")
                    if pending_usage and payload_type == "message" and role != "user":
                        usage_payload = pending_usage
                        pending_usage = None
                        pending_usage_model = None
                    yield from self._map_response_item(
                        entry.payload, ts, session_cwd, usage_payload, usage_model
                    )

                elif entry.type == "turn_context":
                    yield CustomEvent(
                        timestamp_ms=ts,
                        name="turn_context",
                        value=entry.payload,
                    )
                    if isinstance(entry.payload, dict) and entry.payload.get("model"):
                        current_model = str(entry.payload["model"])

                elif entry.type == "event_msg":
                    # Skip event_msg types that duplicate response_item
                    evt_type = entry.payload.get("type")
                    if evt_type == "token_count":
                        yield CustomEvent(
                            timestamp_ms=ts,
                            name="token_count",
                            value=entry.payload,
                        )
                        usage = self._build_usage_from_token_count(entry.payload)
                        if usage:
                            pending_usage = usage
                            payload_model = entry.payload.get("model")
                            pending_usage_model = (
                                str(payload_model) if payload_model else current_model
                            )
                    # Skip agent_reasoning (duplicates response_item.reasoning)
                    # Skip user_message (duplicates response_item.message)

        # Emit RunFinished
        if session_meta:
            run_id = session_meta.get("id", session.id)
            yield RunFinishedEvent(
                timestamp_ms=ts_tracker.last_valid,
                run_id=str(run_id),
            )

    def _map_response_item(
        self,
        payload: dict[str, object],
        ts: int,
        session_cwd: str | None = None,
        usage: dict[str, int] | None = None,
        usage_model: str | None = None,
    ) -> Iterator[Event]:
        """Map a response_item payload to AG-UI events."""
        item_type = payload.get("type")

        if item_type == "message":
            role_str = payload.get("role", "user")
            role = Role.USER if role_str == "user" else Role.ASSISTANT
            content_blocks = payload.get("content", [])

            # Extract text from content blocks
            text_parts: list[str] = []
            if isinstance(content_blocks, list):
                for block in content_blocks:
                    if isinstance(block, dict) and "text" in block:
                        text = str(block["text"])
                        if text:
                            text_parts.append(text)

            msg_id = f"msg-{ts}"
            combined_text = "".join(text_parts)
            yield TextMessageChunkEvent(
                timestamp_ms=ts,
                message_id=msg_id,
                role=role,
                delta=combined_text,
            )

        elif item_type == "function_call":
            call_id = payload.get("call_id", "")
            name = str(payload.get("name", ""))
            args = str(payload.get("arguments", "{}"))

            yield ToolCallChunkEvent(
                timestamp_ms=ts,
                tool_call_id=str(call_id),
                tool_call_name=name,
                delta=args,
            )

        elif item_type == "function_call_output":
            call_id = payload.get("call_id", "")
            output = payload.get("output", "")

            yield ToolCallResultEvent(
                timestamp_ms=ts,
                tool_call_id=str(call_id),
                tool_call_result_id=f"{call_id}-result",
                result=str(output),
            )

        elif item_type == "reasoning":
            summary_list = payload.get("summary", [])
            summary_text = ""
            if isinstance(summary_list, list):
                texts = []
                for s in summary_list:
                    if isinstance(s, dict) and "text" in s:
                        texts.append(str(s["text"]))
                summary_text = " ".join(texts)

            msg_id = f"reasoning-{ts}"

            yield ReasoningMessageChunkEvent(
                timestamp_ms=ts,
                message_id=msg_id,
                delta=summary_text,
            )

        elif item_type == "custom_tool_call":
            # Codex uses custom_tool_call for apply_patch and other built-in tools
            call_id = payload.get("call_id", "")
            name = str(payload.get("name", ""))
            # custom_tool_call uses "input" (string) instead of "arguments" (JSON)
            tool_input = payload.get("input", "")
            # Wrap input in JSON so it flows through _agui_to_normalizer_events correctly
            args_json = json.dumps({"input": tool_input})

            yield ToolCallChunkEvent(
                timestamp_ms=ts,
                tool_call_id=str(call_id),
                tool_call_name=name,
                delta=args_json,
            )

        elif item_type == "custom_tool_call_output":
            call_id = payload.get("call_id", "")
            output = payload.get("output", "")

            yield ToolCallResultEvent(
                timestamp_ms=ts,
                tool_call_id=str(call_id),
                tool_call_result_id=f"{call_id}-result",
                result=str(output),
            )

        elif item_type == "ghost_snapshot":
            ghost_commit = payload.get("ghost_commit", {})
            if not isinstance(ghost_commit, dict):
                ghost_commit = {}
            # Cast to proper type for CustomEvent
            ghost_value: dict[str, Any] = {str(k): v for k, v in ghost_commit.items()}
            yield CustomEvent(
                timestamp_ms=ts,
                name="ghost_snapshot",
                value=ghost_value,
            )

    def write_events(self, events: Iterable[Event], dest: IO[str]) -> None:
        """Write AG-UI events as Codex JSONL."""
        events_list = list(events)

        # Extract source entries for this format
        source_entries = [
            e.value
            for e in events_list
            if isinstance(e, CustomEvent)
            and e.name == "source_entry"
            and e.value.get("format") == self.name
        ]

        if source_entries:
            # Same-format: output originals directly (lossless)
            self._write_source_entries(dest, source_entries)
        else:
            # Cross-format: reconstruct from AG-UI events
            self._reconstruct_from_events(events_list, dest)

    def _write_source_entries(self, dest: IO[str], entries: list[dict[str, object]]) -> None:
        """Write source entries directly for lossless same-format output."""
        for entry in sorted(entries, key=lambda e: int(e.get("index", 0))):
            raw_line = str(entry.get("raw_line", ""))
            dest.write(raw_line + "\n")

    def _reconstruct_from_events(self, events_list: list[Event], dest: IO[str]) -> None:
        """Reconstruct Codex JSONL from AG-UI events (cross-format fallback)."""
        # Extract session metadata from RunStartedEvent
        run_started: RunStartedEvent | None = None
        for event in events_list:
            if event.type == EventType.RUN_STARTED and isinstance(event, RunStartedEvent):
                run_started = event
                break

        # Group message events
        messages = list(group_events(events_list))
        if not messages and not run_started:
            return

        now = datetime.now(UTC).isoformat().replace("+00:00", "Z")

        # Write session_meta
        session_meta = {
            "timestamp": now,
            "type": "session_meta",
            "payload": {
                "id": run_started.run_id
                if run_started
                else (messages[0].id if messages else "unknown"),
                "timestamp": now,
                "cwd": "",
                "originator": "agentstream",
                "cli_version": "1.0.0",
            },
        }
        dest.write(json.dumps(session_meta) + "\n")

        # Write response_item entries for each message
        for msg in messages:
            for entry in self._message_to_codex_entries(msg):
                dest.write(json.dumps(entry) + "\n")

    def _message_to_codex_entries(self, msg: MessageGroup) -> Iterator[dict[str, object]]:
        """Convert a MessageGroup to Codex JSONL entries."""
        now = datetime.now(UTC).isoformat().replace("+00:00", "Z")

        # Emit reasoning entries first
        for r in msg.reasoning:
            yield {
                "timestamp": now,
                "type": "response_item",
                "payload": {
                    "type": "reasoning",
                    "summary": [{"text": r.content}],
                    "encrypted_content": None,
                },
            }

        # Emit message entry if there's content
        if msg.text or msg.role == Role.USER:
            role = "user" if msg.role == Role.USER else "assistant"
            yield {
                "timestamp": now,
                "type": "response_item",
                "payload": {
                    "type": "message",
                    "role": role,
                    "content": [{"type": "text", "text": msg.text}],
                },
            }

        # Emit tool call entries
        for tc in msg.tool_calls:
            # Function call
            yield {
                "timestamp": now,
                "type": "response_item",
                "payload": {
                    "type": "function_call",
                    "call_id": tc.id,
                    "name": tc.name,
                    "arguments": json.dumps(tc.args),
                },
            }

            # Function output (if we have a result)
            if tc.result is not None:
                yield {
                    "timestamp": now,
                    "type": "response_item",
                    "payload": {
                        "type": "function_call_output",
                        "call_id": tc.id,
                        "output": tc.result,
                    },
                }

    @staticmethod
    def _build_usage_from_token_count(payload: dict[str, object]) -> dict[str, int] | None:
        """Normalize Codex token_count payloads."""
        if not isinstance(payload, dict):
            return None

        source = payload.get("usage")
        if not isinstance(source, dict):
            source = payload

        def _get_value(*keys: str) -> int:
            for key in keys:
                if key in source and isinstance(source[key], int | float):
                    return int(source[key])
            return 0

        usage: dict[str, int] = {}
        input_tokens = _get_value("input_tokens", "input")
        output_tokens = _get_value("output_tokens", "output")
        cached_input = _get_value("cached_input_tokens", "cached")
        reasoning_tokens = _get_value("reasoning_output_tokens", "reasoning_tokens")

        if input_tokens:
            usage["input_tokens"] = input_tokens
        if output_tokens:
            usage["output_tokens"] = output_tokens
        if cached_input:
            usage["cache_read_input_tokens"] = cached_input
        if reasoning_tokens:
            usage["reasoning_tokens"] = reasoning_tokens

        return usage or None

    @staticmethod
    def _extract_file_op_from_function_call(
        name: str, arguments: str, session_cwd: str | None
    ) -> dict[str, Any] | None:
        """Extract file operation from a function call.

        Args:
            name: Function/tool name.
            arguments: JSON string of arguments.
            session_cwd: Working directory for path normalization.

        Returns:
            File operation dict or None.
        """
        # Parse arguments JSON
        try:
            args = json.loads(arguments) if arguments else {}
        except json.JSONDecodeError:
            args = {}

        if not isinstance(args, dict):
            args = {}

        if name in _FILE_READ_TOOLS:
            raw_path = args.get("file_path") or args.get("path") or args.get("file")
            if raw_path:
                return {"op": "read", "path": normalize_path(raw_path, session_cwd)}

        elif name in _FILE_WRITE_TOOLS:
            raw_path = args.get("file_path") or args.get("path") or args.get("file")
            if raw_path:
                return {"op": "write", "path": normalize_path(raw_path, session_cwd)}

        elif name in _FILE_EDIT_TOOLS:
            raw_path = args.get("file_path") or args.get("path") or args.get("file")
            if raw_path:
                return {"op": "edit", "path": normalize_path(raw_path, session_cwd)}

        elif name in _FILE_DELETE_TOOLS:
            raw_path = args.get("file_path") or args.get("path") or args.get("file")
            if raw_path:
                return {"op": "delete", "path": normalize_path(raw_path, session_cwd)}

        elif name in _FILE_LIST_TOOLS:
            op_dict: dict[str, Any] = {"op": "list"}
            if "pattern" in args:
                op_dict["pattern"] = args["pattern"]
            raw_path = args.get("path") or args.get("directory")
            if raw_path:
                op_dict["path"] = normalize_path(raw_path, session_cwd)
            return op_dict

        elif name in _FILE_SEARCH_TOOLS:
            op_dict = {"op": "search"}
            if "pattern" in args or "query" in args:
                op_dict["pattern"] = args.get("pattern") or args.get("query")
            raw_path = args.get("path") or args.get("directory")
            if raw_path:
                op_dict["path"] = normalize_path(raw_path, session_cwd)
            return op_dict

        elif name in _SHELL_TOOLS:
            # Parse shell commands for file operations
            cmd = args.get("cmd") or args.get("command") or ""
            return CodexAdapter._extract_file_op_from_shell(cmd, session_cwd)

        return None

    def parse_source_entry(
        self,
        entry: dict,
        entry_index: int,
        session_id: str,
    ) -> list[Event]:
        """Parse a single source entry into AG-UI events.

        Args:
            entry: Parsed JSON from source_entry.entry_content
            entry_index: Position in session (for event ID generation)
            session_id: Session UUID

        Returns:
            List of AG-UI events (may be empty)
        """

        events: list[Event] = []
        entry_type = entry.get("type")

        # Skip synthetic daemon_metadata entry (from dump command fixtures)
        if entry_type == "daemon_metadata":
            return events

        # session_meta doesn't produce semantic events
        if entry_type == "session_meta":
            return events

        # Parse timestamp from entry (crucial for correct event ordering!)
        # Use _timestamp_ms from processing pipeline as fallback (never datetime.now())
        fallback_ts = entry.get("_timestamp_ms", 0)
        ts = parse_timestamp_with_fallback(entry.get("timestamp"), fallback_ts)

        # Get session CWD from session_meta payload (if available)
        session_cwd: str | None = None
        if entry_type == "session_meta" and "payload" in entry:
            session_cwd = entry["payload"].get("cwd")

        if entry_type == "response_item":
            payload = entry.get("payload", {})
            events.extend(self._map_response_item(payload, ts, session_cwd))

        # Tag all events with entry_index for incremental processing
        for event in events:
            if not hasattr(event, "_source"):
                event._source = {}  # type: ignore[attr-defined]
            event._source["entry_index"] = entry_index  # type: ignore[attr-defined, index]

        return events

    @staticmethod
    def _extract_file_op_from_shell(command: str, session_cwd: str | None) -> dict[str, Any] | None:
        """Extract file operation from shell command (best effort).

        Args:
            command: Shell command string.
            session_cwd: Working directory for path normalization.

        Returns:
            File operation dict or None.
        """
        if not command:
            return None

        parts = command.split()
        if not parts:
            return None

        cmd = parts[0]

        # Read operations
        if cmd in ("cat", "head", "tail", "less", "more", "bat"):
            for arg in parts[1:]:
                if not arg.startswith("-"):
                    return {"op": "read", "path": normalize_path(arg, session_cwd)}

        # Search operations
        elif cmd in ("grep", "rg", "ripgrep", "ag", "ack"):
            return {"op": "search"}

        # List operations
        elif cmd in ("ls", "find", "fd", "tree"):
            return {"op": "list"}

        return None
