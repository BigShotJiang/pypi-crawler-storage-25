"""Claude Code adapter for reading and writing session logs."""

from __future__ import annotations

import json
import re
import uuid
from collections.abc import Iterable, Iterator
from datetime import UTC, datetime
from pathlib import Path
from typing import IO, Any

from agentstream.analytics import normalize_path
from agentstream.events import (
    CustomEvent,
    Event,
    ReasoningMessageChunkEvent,
    Role,
    RunFinishedEvent,
    RunStartedEvent,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)
from agentstream.formats.claude import ContentBlock, LogEntry, ToolUseResult
from agentstream.grouper import MessageGroup, group_events

from .base import Adapter, Session
from .timestamps import parse_timestamp, parse_timestamp_or_now, parse_timestamp_with_fallback

# Tool names that perform file operations
_FILE_READ_TOOLS = frozenset({"Read", "View", "Cat"})
_FILE_WRITE_TOOLS = frozenset({"Write", "Create"})
_FILE_EDIT_TOOLS = frozenset({"Edit", "Patch", "Replace", "MultiEdit"})
_FILE_DELETE_TOOLS = frozenset({"Delete", "Remove"})
_FILE_LIST_TOOLS = frozenset({"Glob", "LS", "List", "ListDir"})
_FILE_SEARCH_TOOLS = frozenset({"Grep", "Search", "Ripgrep", "Find"})

# UUID pattern: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
_UUID_PATTERN = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-" r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)

# Agent subagent pattern: agent-XXXXXXX (hex characters)
_AGENT_PATTERN = re.compile(r"^agent-[0-9a-fA-F]+$")

# Alias for backward compatibility with tests
_parse_timestamp = parse_timestamp


class ClaudeAdapter(Adapter):
    """Adapter for Claude Code JSONL session logs."""

    @property
    def name(self) -> str:
        return "claude"

    # === Path Detection (for daemon watcher) ===

    def get_base_directories(self) -> list[Path]:
        """Return Claude project directories."""
        return [Path.home() / ".claude" / "projects"]

    def matches_path(self, path: Path) -> bool:
        """Return True if path is a Claude session file."""
        # Claude sessions are in ~/.claude/projects/*/
        # Use Path.parts for cross-platform compatibility
        return ".claude" in path.parts and path.suffix == ".jsonl"

    # === Raw Entry Reading (for incremental sync) ===

    def read_entries(self, session: Session) -> list[dict]:
        """Read all raw source entries from a Claude session.

        Returns:
            List of entry dicts with: entry_index, entry_content, entry_timestamp_ms
        """
        entries = []
        with open(session.path) as f:
            for i, line in enumerate(f):
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    timestamp_ms = parse_timestamp_or_now(entry.get("timestamp"))

                    # Strip normalizedMessages from progress events to reduce size
                    # These embed full conversation history redundantly
                    modified = False
                    if entry.get("type") == "progress" and "data" in entry:
                        data = entry["data"]
                        if isinstance(data, dict) and "normalizedMessages" in data:
                            del data["normalizedMessages"]
                            modified = True

                    content = json.dumps(entry, separators=(",", ":")) if modified else line

                    entries.append(
                        {
                            "entry_index": i,
                            "entry_content": content,
                            "entry_timestamp_ms": timestamp_ms,
                        }
                    )
                except json.JSONDecodeError:
                    continue

        return entries

    def read_entries_after(self, session: Session, after_index: int = -1) -> list[dict]:
        """Read entries after given index (streaming for efficiency)."""
        entries = []
        with open(session.path) as f:
            for i, line in enumerate(f):
                if i <= after_index:
                    continue
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    timestamp_ms = parse_timestamp_or_now(entry.get("timestamp"))

                    # Strip normalizedMessages from progress events
                    modified = False
                    if entry.get("type") == "progress" and "data" in entry:
                        data = entry["data"]
                        if isinstance(data, dict) and "normalizedMessages" in data:
                            del data["normalizedMessages"]
                            modified = True

                    content = json.dumps(entry, separators=(",", ":")) if modified else line

                    entries.append(
                        {
                            "entry_index": i,
                            "entry_content": content,
                            "entry_timestamp_ms": timestamp_ms,
                        }
                    )
                except json.JSONDecodeError:
                    continue

        return entries

    # === Session Discovery ===

    def discover_sessions(self, project_dir: Path) -> list[Session]:
        """Find Claude Code sessions in ~/.claude/projects/.

        - If project_dir is home (~), returns ALL sessions from all projects.
        - Otherwise, returns sessions from the exact project directory only.

        Claude stores sessions in ~/.claude/projects/<path-with-slashes-as-dashes>/
        """
        sessions: list[Session] = []

        # Claude stores sessions in ~/.claude/projects/<path>/
        # The path format is the absolute project path with / replaced by -
        # e.g., /Users/foo/bar -> -Users-foo-bar
        claude_base = Path.home() / ".claude" / "projects"
        if not claude_base.exists():
            return sessions

        project_resolved = project_dir.resolve()

        # If searching from home, return ALL sessions from all projects
        if project_resolved == Path.home():
            project_dirs = [d for d in claude_base.iterdir() if d.is_dir()]
        else:
            # Convert project path to Claude's format: /Users/foo/bar -> -Users-foo-bar
            # Claude CLI also replaces dots with dashes (e.g. /.claude/ -> --claude-)
            project_name = str(project_resolved).replace("/", "-").replace(".", "-")
            claude_dir = claude_base / project_name
            if not claude_dir.exists():
                return sessions
            project_dirs = [claude_dir]

        # Collect sessions from matching project directories
        for pdir in project_dirs:
            for session_file in pdir.glob("*.jsonl"):
                session_id = session_file.stem
                # Accept UUID files (top-level) OR agent-XXXX files (sub-agents)
                if not (_UUID_PATTERN.match(session_id) or _AGENT_PATTERN.match(session_id)):
                    continue
                stat = session_file.stat()
                sessions.append(
                    Session(
                        id=session_id,
                        path=session_file,
                        format=self.name,
                        modified_at=stat.st_mtime,
                    )
                )

            # Discover sub-agent files in {session_uuid}/subagents/agent-*.jsonl
            for session_file in pdir.glob("*/subagents/agent-*.jsonl"):
                session_id = session_file.stem
                if not _AGENT_PATTERN.match(session_id):
                    continue
                parent_agent_session_id = session_file.parent.parent.name
                if not _UUID_PATTERN.match(parent_agent_session_id):
                    continue
                stat = session_file.stat()
                sessions.append(
                    Session(
                        id=session_id,
                        path=session_file,
                        format=self.name,
                        modified_at=stat.st_mtime,
                        metadata={"parent_agent_session_id": parent_agent_session_id},
                    )
                )

        # Sort by modification time, newest first
        sessions.sort(key=lambda s: s.modified_at, reverse=True)
        return sessions

    def read_events(self, session: Session) -> Iterator[Event]:
        """Read AG-UI events from a Claude session.

        Ensures all events have valid timestamps by:
        1. Parsing timestamps from each log entry
        2. Tracking the last valid timestamp seen
        3. Using fallback (last valid or file mtime) for entries without timestamps
        """
        # Store tuples of (LogEntry | None, raw_line, line_index, entry_type, timestamp_str,
        # session_id). LogEntry is None for unknown entry types that fail Pydantic validation
        entries: list[tuple[LogEntry | None, str, int, str, str, str | None]] = []

        # Parse all log entries
        with open(session.path) as f:
            for line_index, line in enumerate(f):
                line = line.strip()
                if not line:
                    continue
                try:
                    # First parse as raw JSON to get type and timestamp
                    raw_dict = json.loads(line)
                    entry_type = raw_dict.get("type", "unknown")
                    timestamp = raw_dict.get("timestamp", "")
                    session_id_in_entry = raw_dict.get("sessionId")

                    # Try Pydantic validation for known types
                    try:
                        entry = LogEntry.model_validate(raw_dict)
                    except Exception:
                        # Unknown entry type - preserve raw line but no semantic events
                        entry = None

                    entries.append(
                        (entry, line, line_index, entry_type, timestamp, session_id_in_entry)
                    )
                except json.JSONDecodeError:
                    continue  # Skip malformed JSON lines

        if not entries:
            return

        # Find first valid timestamp for fallback, or use file modification time
        first_valid_ts: int | None = None
        for _, _, _, _, ts_str, _ in entries:
            parsed = _parse_timestamp(ts_str)
            if parsed is not None:
                first_valid_ts = parsed
                break

        # Ultimate fallback: file modification time
        file_mtime_ms = int(session.modified_at * 1000)
        if first_valid_ts is None:
            first_valid_ts = file_mtime_ms

        # Track last valid timestamp for fallback
        last_valid_ts = first_valid_ts

        # Emit RunStarted
        first_entry = entries[0][0]
        first_ts = _parse_timestamp(entries[0][4])
        if first_ts is None:
            first_ts = last_valid_ts
        else:
            last_valid_ts = first_ts

        # Extract session cwd for file path normalization
        session_cwd: str | None = first_entry.cwd if first_entry else None

        yield RunStartedEvent(
            timestamp_ms=first_ts,
            thread_id=session.id,
            run_id=session.id,
        )

        # Process each entry
        for entry, raw_line, line_index, entry_type, timestamp, session_id_in_entry in entries:
            ts = _parse_timestamp(timestamp)
            if ts is None:
                ts = last_valid_ts
            else:
                last_valid_ts = ts

            # Emit source_entry for ALL entries (including unknown types)
            yield CustomEvent(
                timestamp_ms=ts,
                name="source_entry",
                value={
                    "format": "claude",
                    "entry_type": entry_type,
                    "raw_line": raw_line,
                    "index": line_index,
                    "raw_event": {"sessionId": session_id_in_entry} if session_id_in_entry else {},
                },
            )

            # Emit semantic events only for known entry types
            if entry is not None:
                if entry.type == "user":
                    yield from self._map_user_message(entry, ts, session_cwd)
                elif entry.type == "assistant":
                    yield from self._map_assistant_message(entry, ts, session_cwd)

        # Emit RunFinished - use last valid timestamp
        yield RunFinishedEvent(timestamp_ms=last_valid_ts, run_id=session.id)

    def _extract_file_ops(self, entry: LogEntry, session_cwd: str | None) -> list[dict[str, Any]]:
        """Extract file operations from tool use blocks.

        Args:
            entry: The log entry to extract from.
            session_cwd: The session's starting working directory for path normalization.

        Returns:
            List of file operation dicts with op, path, and optional line info.
        """
        file_ops: list[dict[str, Any]] = []

        if entry.type != "assistant":
            return file_ops

        if not hasattr(entry.message, "content") or not isinstance(entry.message.content, list):
            return file_ops

        for block in entry.message.content:
            if not isinstance(block, ContentBlock) or block.type != "tool_use":
                continue

            tool_name = block.name or ""
            tool_input = block.input or {}

            # Extract file operation based on tool type
            if tool_name in _FILE_READ_TOOLS:
                raw_path = tool_input.get("file_path") or tool_input.get("path")
                if raw_path:
                    op: dict[str, Any] = {
                        "op": "read",
                        "path": normalize_path(raw_path, session_cwd),
                    }
                    # Add line range if specified
                    if "offset" in tool_input:
                        op["lines_start"] = tool_input["offset"]
                    if "limit" in tool_input:
                        start = tool_input.get("offset", 1)
                        op["lines_end"] = start + tool_input["limit"] - 1
                    file_ops.append(op)

            elif tool_name in _FILE_WRITE_TOOLS:
                raw_path = tool_input.get("file_path") or tool_input.get("path")
                if raw_path:
                    file_ops.append(
                        {
                            "op": "write",
                            "path": normalize_path(raw_path, session_cwd),
                        }
                    )

            elif tool_name in _FILE_EDIT_TOOLS:
                raw_path = tool_input.get("file_path") or tool_input.get("path")
                if raw_path:
                    file_ops.append(
                        {
                            "op": "edit",
                            "path": normalize_path(raw_path, session_cwd),
                            # Line info will be enriched from tool result if available
                        }
                    )

            elif tool_name in _FILE_DELETE_TOOLS:
                raw_path = tool_input.get("file_path") or tool_input.get("path")
                if raw_path:
                    file_ops.append(
                        {
                            "op": "delete",
                            "path": normalize_path(raw_path, session_cwd),
                        }
                    )

            elif tool_name in _FILE_LIST_TOOLS:
                op_dict: dict[str, Any] = {"op": "list"}
                if "pattern" in tool_input:
                    op_dict["pattern"] = tool_input["pattern"]
                if "path" in tool_input or "directory" in tool_input:
                    raw_path = tool_input.get("path") or tool_input.get("directory")
                    if raw_path:
                        op_dict["path"] = normalize_path(raw_path, session_cwd)
                file_ops.append(op_dict)

            elif tool_name in _FILE_SEARCH_TOOLS:
                op_dict = {"op": "search"}
                if "pattern" in tool_input:
                    op_dict["pattern"] = tool_input["pattern"]
                raw_path = tool_input.get("path") or tool_input.get("directory")
                if raw_path:
                    op_dict["path"] = normalize_path(raw_path, session_cwd)
                file_ops.append(op_dict)

            # Handle Bash/shell commands that might contain file operations
            elif tool_name in ("Bash", "Shell", "Execute", "Run"):
                cmd = tool_input.get("command") or tool_input.get("cmd") or ""
                extracted = self._extract_file_ops_from_shell(cmd, session_cwd)
                file_ops.extend(extracted)

        return file_ops

    def _extract_file_ops_from_shell(
        self, command: str, session_cwd: str | None
    ) -> list[dict[str, Any]]:
        """Extract file operations from shell commands (best effort).

        Args:
            command: Shell command string.
            session_cwd: Working directory for path normalization.

        Returns:
            List of detected file operations.
        """
        file_ops: list[dict[str, Any]] = []

        if not command:
            return file_ops

        # Simple pattern matching for common file commands
        # This is best-effort and won't catch everything
        parts = command.split()
        if not parts:
            return file_ops

        cmd = parts[0]

        # Read operations
        if cmd in ("cat", "head", "tail", "less", "more", "bat"):
            for arg in parts[1:]:
                if not arg.startswith("-"):
                    file_ops.append(
                        {
                            "op": "read",
                            "path": normalize_path(arg, session_cwd),
                        }
                    )

        # Search operations
        elif cmd in ("grep", "rg", "ripgrep", "ag", "ack"):
            file_ops.append({"op": "search"})

        # List operations
        elif cmd in ("ls", "find", "fd", "tree"):
            file_ops.append({"op": "list"})

        return file_ops

    def _map_user_message(
        self, entry: LogEntry, ts: int, session_cwd: str | None
    ) -> Iterator[Event]:
        """Map a user log entry to AG-UI events."""
        msg_id = entry.uuid

        # Check if content is a list (could be tool_result blocks or text blocks)
        content = entry.message.content if hasattr(entry.message, "content") else ""
        if isinstance(content, list):
            # Check if this is a tool_result message (has at least one tool_result block)
            has_tool_results = any(
                isinstance(block, ContentBlock) and block.type == "tool_result" for block in content
            )

            if has_tool_results:
                # Handle tool_result blocks
                for block in content:
                    if isinstance(block, ContentBlock) and block.type == "tool_result":
                        tool_use_id = block.tool_use_id or ""

                        # Build result dict with structured data from toolUseResult
                        # This enables diff extraction from Edit tool results
                        result_dict: dict = {}
                        if isinstance(entry.tool_use_result, ToolUseResult):
                            if entry.tool_use_result.file_path:
                                result_dict["file_path"] = entry.tool_use_result.file_path
                            if entry.tool_use_result.structured_patch:
                                # Convert PatchHunk models to dicts
                                result_dict["structured_patch"] = {
                                    "hunks": [
                                        hunk.model_dump()
                                        for hunk in entry.tool_use_result.structured_patch
                                    ]
                                }
                            if entry.tool_use_result.old_string:
                                result_dict["old_string"] = entry.tool_use_result.old_string
                            if entry.tool_use_result.new_string:
                                result_dict["new_string"] = entry.tool_use_result.new_string

                        # Add text content if no structured data
                        if not result_dict:
                            result_content = block.content
                            if isinstance(result_content, list):
                                result_dict["content"] = result_content
                            elif result_content is not None:
                                result_dict["content"] = str(result_content)

                        result_str = json.dumps(result_dict) if result_dict else ""

                        yield ToolCallResultEvent(
                            timestamp_ms=ts,
                            tool_call_result_id=str(uuid.uuid4()),
                            tool_call_id=tool_use_id,
                            result=result_str,
                            is_error=block.is_error,
                        )
                # Return early after tool results (don't emit regular user message events)
                return

            # Extract text blocks from array content (e.g., IDE-integrated sessions)
            # Concatenate all meaningful text blocks, skipping image placeholders
            text_parts: list[str] = []
            for block in content:
                if isinstance(block, ContentBlock) and block.type == "text" and block.text:
                    # Skip image placeholder strings (e.g., "[Image: source: /path/to/file.png]")
                    if block.text.strip().startswith("[Image:"):
                        continue
                    text_parts.append(block.text)

            if text_parts:
                text_content = "\n\n".join(text_parts)
                yield TextMessageChunkEvent(
                    timestamp_ms=ts,
                    message_id=msg_id,
                    role=Role.USER,
                    delta=text_content,
                )
            return

        # User messages have simple string content - emit as single chunk event
        text_content = content if isinstance(content, str) else ""
        yield TextMessageChunkEvent(
            timestamp_ms=ts,
            message_id=msg_id,
            role=Role.USER,
            delta=text_content,
        )

    def _map_assistant_message(
        self, entry: LogEntry, ts: int, session_cwd: str | None
    ) -> Iterator[Event]:
        """Map an assistant log entry to AG-UI events."""
        msg_id = entry.uuid
        text_parts: list[str] = []
        tool_use_blocks: list[ContentBlock] = []
        thinking_blocks: list[ContentBlock] = []

        # Check for text content, tool_use blocks, and thinking blocks
        if hasattr(entry.message, "content") and isinstance(entry.message.content, list):
            for block in entry.message.content:
                if isinstance(block, ContentBlock):
                    if block.type == "text" and block.text:
                        text_parts.append(block.text)
                    elif block.type == "tool_use":
                        tool_use_blocks.append(block)
                    elif block.type == "thinking" and block.thinking:
                        thinking_blocks.append(block)

        # Determine if we have actual text content
        has_text = bool(text_parts)

        # Emit reasoning chunk events for thinking blocks (before text)
        for block in thinking_blocks:
            # block.thinking is guaranteed non-None because we only add to
            # thinking_blocks when block.thinking is truthy
            assert block.thinking is not None

            yield ReasoningMessageChunkEvent(
                timestamp_ms=ts,
                message_id=msg_id,
                delta=block.thinking,
            )

        # Only emit text message events if there's actual text content
        # (don't create empty text messages for tool-call-only or reasoning-only messages)
        if has_text:
            # Combine all text parts into one chunk
            combined_text = "".join(text_parts)

            yield TextMessageChunkEvent(
                timestamp_ms=ts,
                message_id=msg_id,
                role=Role.ASSISTANT,
                delta=combined_text,
            )

        # Emit tool call chunk events for each tool_use block
        for block in tool_use_blocks:
            tool_call_id = block.id or ""
            tool_name = block.name or ""
            tool_input = block.input or {}

            yield ToolCallChunkEvent(
                timestamp_ms=ts,
                tool_call_id=tool_call_id,
                tool_call_name=tool_name,
                parent_message_id=msg_id,
                delta=json.dumps(tool_input),
            )

    def write_events(self, events: Iterable[Event], dest: IO[str]) -> None:
        """Write AG-UI events as Claude JSONL."""
        events_list = list(events)

        # Extract source entries for this format
        source_entries = [
            e.value
            for e in events_list
            if isinstance(e, CustomEvent)
            and e.name == "source_entry"
            and e.value.get("format") == self.name
        ]

        if source_entries:
            # Same-format: output originals directly (lossless)
            self._write_source_entries(dest, source_entries)
        else:
            # Cross-format: reconstruct from AG-UI events
            self._reconstruct_from_events(events_list, dest)

    def _write_source_entries(self, dest: IO[str], entries: list[dict[str, object]]) -> None:
        """Write source entries directly for lossless same-format output."""
        for entry in sorted(entries, key=lambda e: int(e.get("index", 0))):
            raw_line = str(entry.get("raw_line", ""))
            dest.write(raw_line + "\n")

    def _reconstruct_from_events(self, events: list[Event], dest: IO[str]) -> None:
        """Reconstruct Claude JSONL from AG-UI events (cross-format fallback)."""
        # Group events into messages
        messages = list(group_events(events))

        for msg in messages:
            entry = self._message_to_entry(msg)
            dest.write(json.dumps(entry) + "\n")

    def parse_source_entry(
        self,
        entry: dict,
        entry_index: int,
        session_id: str,
    ) -> list[Event]:
        """Parse a single source entry into AG-UI events.

        Args:
            entry: Parsed JSON from source_entry.entry_content
            entry_index: Position in session (for event ID generation)
            session_id: Session UUID

        Returns:
            List of AG-UI events (may be empty)
        """
        events: list[Event] = []
        entry_type = entry.get("type")

        # Skip synthetic daemon_metadata entry (from dump command fixtures)
        if entry_type == "daemon_metadata":
            return events

        # Parse entry using Pydantic for type safety
        try:
            log_entry = LogEntry.model_validate(entry)
        except Exception:
            # Unknown entry type - return empty list
            return events

        # Get session CWD from entry (if available)
        session_cwd = log_entry.cwd if hasattr(log_entry, "cwd") else None

        # Parse timestamp from entry (crucial for correct event ordering!)
        # Use _timestamp_ms from processing pipeline as fallback (never datetime.now())
        fallback_ts = entry.get("_timestamp_ms", 0)
        ts = parse_timestamp_with_fallback(log_entry.timestamp, fallback_ts)

        if entry_type == "user":
            events.extend(self._map_user_message(log_entry, ts, session_cwd))
        elif entry_type == "assistant":
            events.extend(self._map_assistant_message(log_entry, ts, session_cwd))

        # Tag all events with entry_index for incremental processing
        for event in events:
            if not hasattr(event, "_source"):
                event._source = {}  # type: ignore[attr-defined]
            event._source["entry_index"] = entry_index  # type: ignore[attr-defined, index]

        return events

    def _message_to_entry(self, msg: MessageGroup) -> dict[str, object]:
        """Convert a MessageGroup to a Claude log entry dict.

        Reconstructs the full Claude JSONL format including thinking blocks
        and all preserved metadata for high-fidelity round-trip conversion.
        """
        # Base entry structure
        if msg.role == Role.USER:
            entry: dict[str, object] = {
                "type": "user",
                "message": {"content": msg.text},
                "uuid": msg.id,
                "timestamp": datetime.now(UTC).isoformat(),
            }
        else:  # assistant
            content_blocks: list[dict[str, object]] = []

            # Add thinking blocks first (they appear before text in Claude format)
            for reasoning in msg.reasoning:
                thinking_block: dict[str, object] = {
                    "type": "thinking",
                    "thinking": reasoning.content,
                }
                if reasoning.encrypted_content:
                    thinking_block["signature"] = reasoning.encrypted_content
                content_blocks.append(thinking_block)

            # Add text content
            if msg.text:
                content_blocks.append({"type": "text", "text": msg.text})

            # Add tool use blocks
            for tc in msg.tool_calls:
                content_blocks.append(
                    {
                        "type": "tool_use",
                        "id": tc.id,
                        "name": tc.name,
                        "input": tc.args,
                    }
                )

            # Build message object with standard Claude fields
            message_obj: dict[str, object] = {
                "content": content_blocks,
                "type": "message",
                "role": "assistant",
            }

            entry = {
                "type": "assistant",
                "message": message_obj,
                "uuid": msg.id,
                "timestamp": datetime.now(UTC).isoformat(),
            }

        return entry
