"""Token estimation utilities for Cursor sessions.

Cursor tracks token usage server-side only. Local storage contains
`tokenCount: {inputTokens: 0, outputTokens: 0}` for Agent mode, making
direct extraction impossible.

This module provides estimation functions using available metadata:
- Input tokens: Estimated from `contextUsagePercent` field
- Output tokens: Estimated from assistant bubble text length

All estimates are flagged with `tokens_estimated: True` to distinguish
from actual API-reported token counts.
"""

from __future__ import annotations

from typing import Any

# Cursor's standard context window size (tokens)
# This is the typical limit for models used by Cursor
CURSOR_CONTEXT_WINDOW = 200_000

# Characters per token approximation for English text
# This is a conservative estimate; actual ratio varies by model and content:
# - GPT-4/Claude: ~3.5-4.5 chars/token for English
# - Code: Often closer to 2-3 chars/token due to special tokens
# We use 4 as a balanced estimate that tends to slightly undercount
CHARS_PER_TOKEN = 4


def estimate_input_tokens(context_usage_percent: float) -> int:
    """Estimate input tokens from Cursor's contextUsagePercent field.

    The contextUsagePercent field in Cursor's composerData indicates what
    percentage of the 200k token context window was used during a session.
    This provides a reasonable approximation of cumulative input tokens.

    Note: This is a cumulative measure over the session, not per-turn usage.
    It includes system prompts, file context, and all user messages.

    Args:
        context_usage_percent: The contextUsagePercent value from Cursor
            session metadata (0-100 scale). Values > 100 are clamped.

    Returns:
        Estimated input token count as integer. Returns 0 if input is
        negative or None.

    Example:
        >>> estimate_input_tokens(17.5)
        35000
        >>> estimate_input_tokens(0)
        0
        >>> estimate_input_tokens(100)
        200000
    """
    if context_usage_percent is None or context_usage_percent < 0:
        return 0

    # Clamp to reasonable bounds (can exceed 100% in some edge cases)
    percent = min(context_usage_percent, 100.0)

    return int((percent / 100) * CURSOR_CONTEXT_WINDOW)


def estimate_output_tokens(bubbles: list[dict[str, Any]]) -> int:
    """Estimate output tokens from assistant bubble text content.

    Counts tokens in assistant messages (type=2) using a character-based
    approximation. This is a rough estimate since:
    - Actual tokenization varies by model
    - Code content typically has lower chars/token ratio
    - Special formatting may affect token count

    The estimate tends to slightly undercount actual tokens, which is
    preferable to overcounting for usage tracking purposes.

    Args:
        bubbles: List of bubble dictionaries from Cursor's cursorDiskKV.
            Each bubble should have 'type' (1=user, 2=assistant) and
            'text' fields.

    Returns:
        Estimated output token count as integer. Returns 0 if no
        assistant bubbles are found.

    Example:
        >>> bubbles = [
        ...     {"type": 1, "text": "Hello"},  # user - ignored
        ...     {"type": 2, "text": "Hello there!"},  # assistant - counted
        ... ]
        >>> estimate_output_tokens(bubbles)
        3  # "Hello there!" = 12 chars / 4 = 3 tokens
    """
    if not bubbles:
        return 0

    total_chars = 0

    for bubble in bubbles:
        # Only count assistant bubbles (type=2)
        bubble_type = bubble.get("type")
        if bubble_type != 2:
            continue

        text = bubble.get("text", "")
        if text:
            total_chars += len(text)

        # Also count tool call results if present
        # These contribute to the model's context but are assistant-generated
        tool_data = bubble.get("toolFormerData")
        if tool_data and isinstance(tool_data, dict):
            result = tool_data.get("result", "")
            if result:
                total_chars += len(str(result))

    return total_chars // CHARS_PER_TOKEN


def estimate_session_tokens(
    session_metadata: dict[str, Any],
    bubbles: list[dict[str, Any]],
) -> dict[str, Any]:
    """Estimate token usage for a Cursor session.

    Combines input and output token estimation into a single summary
    suitable for inclusion in session metadata.

    Args:
        session_metadata: Session metadata from Cursor's composerData,
            containing fields like 'contextUsagePercent'.
        bubbles: List of bubble dictionaries from Cursor's cursorDiskKV.

    Returns:
        Dictionary with token estimates:
        - input_tokens: Estimated from contextUsagePercent
        - output_tokens: Estimated from assistant bubble text
        - tokens_estimated: Always True (flags these as estimates)
        - estimation_method: Description of the estimation approach

    Example:
        >>> metadata = {"contextUsagePercent": 25.0}
        >>> bubbles = [{"type": 2, "text": "Here is the answer..."}]
        >>> result = estimate_session_tokens(metadata, bubbles)
        >>> result["input_tokens"]
        50000
        >>> result["tokens_estimated"]
        True
    """
    context_percent = session_metadata.get("contextUsagePercent", 0)

    # Handle None or missing values
    if context_percent is None:
        context_percent = 0

    input_tokens = estimate_input_tokens(context_percent)
    output_tokens = estimate_output_tokens(bubbles or [])

    # Build estimation method description
    methods = []
    if context_percent > 0:
        methods.append(f"input from contextUsagePercent ({context_percent:.1f}%)")
    else:
        methods.append("input unavailable (contextUsagePercent missing)")

    if bubbles:
        assistant_count = sum(1 for b in bubbles if b.get("type") == 2)
        methods.append(
            f"output from {assistant_count} assistant bubbles (~{CHARS_PER_TOKEN} chars/token)"
        )
    else:
        methods.append("output unavailable (no bubbles)")

    return {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "tokens_estimated": True,
        "estimation_method": "; ".join(methods),
    }
