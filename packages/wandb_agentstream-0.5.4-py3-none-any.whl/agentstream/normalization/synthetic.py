"""Synthetic event generation from unified schemas."""

from agentstream.events import CustomEvent

from .schemas import (
    CompactionEvent,
    ErrorEvent,
    SessionMetadata,
    TokenUsage,
    UnifiedFileOperation,
    UnifiedGitCommit,
    UnifiedPullRequest,
    UnifiedSkill,
    UnifiedTodo,
)

# Synthetic event types (ag-ui spec aligned)
UNIFIED_TODO_UPDATE = "UNIFIED_TODO_UPDATE"
UNIFIED_FILE_OPERATION = "UNIFIED_FILE_OPERATION"
UNIFIED_SKILL_ACTIVATION = "UNIFIED_SKILL_ACTIVATION"
SESSION_METADATA = "SESSION_METADATA"
TOKEN_USAGE = "TOKEN_USAGE"
ERROR_EVENT = "ERROR_EVENT"
COMPACTION_EVENT = "COMPACTION_EVENT"
GIT_COMMIT = "GIT_COMMIT"
PR_CREATED = "PR_CREATED"


def create_todo_event(todo: UnifiedTodo, source_event: dict) -> CustomEvent:
    """Create CustomEvent from UnifiedTodo."""
    return CustomEvent(
        timestamp_ms=int(todo.timestamp.timestamp() * 1000),
        name=UNIFIED_TODO_UPDATE,
        value={
            "content": todo.content,
            "status": todo.status,
            "id": todo.id,
            "description": todo.description,
            "active_form": todo.active_form,
            "_source": {
                "event_id": source_event.get("event_id"),
                "agent_type": todo.agent_type,
                "tool": todo.source_tool,
            },
        },
    )


def create_file_operation_event(file_op: UnifiedFileOperation, source_event: dict) -> CustomEvent:
    """Create CustomEvent from UnifiedFileOperation."""
    value = {
        "file_path": file_op.file_path,
        "operation": file_op.operation,
        "confidence": file_op.confidence,
        "_source": {
            "event_id": file_op.source_event_id,
            "agent_type": file_op.agent_type,
            "tool": file_op.source_tool,
        },
    }
    if file_op.content is not None:
        value["content"] = file_op.content
    if file_op.diff:
        value["diff"] = {
            "format_source": file_op.diff.format_source,
            "confidence": file_op.diff.confidence,
            "lines_added": file_op.diff.lines_added,
            "lines_modified": file_op.diff.lines_modified,
            "hunks": [
                {
                    "old_start": h.old_start,
                    "old_count": h.old_count,
                    "new_start": h.new_start,
                    "new_count": h.new_count,
                    "lines": h.lines,
                }
                for h in file_op.diff.hunks
            ],
        }
    return CustomEvent(
        timestamp_ms=int(file_op.timestamp.timestamp() * 1000),
        name=UNIFIED_FILE_OPERATION,
        value=value,
    )


def create_skill_event(skill: UnifiedSkill, source_event: dict) -> CustomEvent:
    """Create CustomEvent from UnifiedSkill."""
    return CustomEvent(
        timestamp_ms=int(skill.timestamp.timestamp() * 1000),
        name=UNIFIED_SKILL_ACTIVATION,
        value={
            "name": skill.name,
            "method": skill.method,
            "skill_type": skill.skill_type,
            "file_path": skill.file_path,
            "args": skill.args,
            "_source": {"event_id": skill.source_event_id, "agent_type": skill.agent_type},
        },
    )


def create_session_metadata_event(
    metadata: SessionMetadata,
    message_id: str | None = None,
) -> CustomEvent:
    """Create CustomEvent from SessionMetadata."""
    value = {
        "cwd": metadata.cwd,
        "agent_type": metadata.agent_type,
        "agent_version": metadata.agent_version,
        "git_branch": metadata.git_branch,
        "git_commit": metadata.git_commit,
        "git_repo": metadata.git_repo,
        "primary_model": metadata.primary_model,
    }
    if message_id:
        value["_linked_message_id"] = message_id
    return CustomEvent(
        timestamp_ms=int(metadata.timestamp.timestamp() * 1000),
        name=SESSION_METADATA,
        value=value,
    )


def create_token_usage_event(
    usage: TokenUsage,
    message_id: str | None = None,
) -> CustomEvent:
    """Create CustomEvent from TokenUsage."""
    value = {
        "input_tokens": usage.input_tokens,
        "output_tokens": usage.output_tokens,
        "cache_read_tokens": usage.cache_read_tokens,
        "cache_creation_tokens": usage.cache_creation_tokens,
        "reasoning_tokens": usage.reasoning_tokens,
        "model": usage.model,
        "is_cumulative": usage.is_cumulative,
    }
    if usage.cost_usd is not None:
        value["cost_usd"] = usage.cost_usd
    if message_id:
        value["_linked_message_id"] = message_id
    return CustomEvent(
        timestamp_ms=int(usage.timestamp.timestamp() * 1000),
        name=TOKEN_USAGE,
        value=value,
    )


def create_error_event(
    error: ErrorEvent,
    tool_call_id: str | None = None,
) -> CustomEvent:
    """Create CustomEvent from ErrorEvent."""
    value = {
        "error_type": error.error_type,
        "message": error.message,
        "tool_name": error.tool_name,
        "tool_call_id": error.tool_call_id,
        "details": error.details,
    }
    if tool_call_id:
        value["_linked_tool_call_id"] = tool_call_id
    return CustomEvent(
        timestamp_ms=int(error.timestamp.timestamp() * 1000),
        name=ERROR_EVENT,
        value=value,
    )


def create_compaction_event(
    compaction: CompactionEvent,
    message_id: str | None = None,
) -> CustomEvent:
    """Create CustomEvent from CompactionEvent."""
    value = {
        "compaction_type": compaction.compaction_type,
        "messages_before": compaction.messages_before,
        "messages_after": compaction.messages_after,
        "tokens_saved": compaction.tokens_saved,
    }
    if message_id:
        value["_linked_message_id"] = message_id
    return CustomEvent(
        timestamp_ms=int(compaction.timestamp.timestamp() * 1000),
        name=COMPACTION_EVENT,
        value=value,
    )


def create_git_commit_event(commit: UnifiedGitCommit, source_event: dict) -> CustomEvent:
    """Create CustomEvent from UnifiedGitCommit."""
    value = {
        "branch": commit.branch,
        "commit_hash": commit.commit_hash,
        "message": commit.message,
        "_source": {
            "event_id": commit.source_event_id,
            "agent_type": commit.agent_type,
            "tool": commit.source_tool,
        },
    }
    return CustomEvent(
        timestamp_ms=int(commit.timestamp.timestamp() * 1000),
        name=GIT_COMMIT,
        value=value,
    )


def create_pr_event(pr: UnifiedPullRequest, source_event: dict) -> CustomEvent:
    """Create CustomEvent from UnifiedPullRequest."""
    value = {
        "url": pr.url,
        "branch": pr.branch,
        "number": pr.number,
        "title": pr.title,
        "_source": {
            "event_id": pr.source_event_id,
            "agent_type": pr.agent_type,
            "tool": pr.source_tool,
        },
    }
    return CustomEvent(
        timestamp_ms=int(pr.timestamp.timestamp() * 1000),
        name=PR_CREATED,
        value=value,
    )
