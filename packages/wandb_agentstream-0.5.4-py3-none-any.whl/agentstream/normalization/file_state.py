"""File system state tracking for diff extraction.

This module provides stateful tracking of file content during session processing,
enabling diff extraction for agents that don't provide structured diffs in their
tool results (e.g., Cursor's old edit_file_v2 format, Gemini's edit operations).
"""


class FileSystemState:
    """Tracks file content during session processing for diff extraction.

    Used by normalizers to compute diffs when:
    - Agent provides full file content but no structured diff
    - Agent only provides content hashes (Cursor's edit_file_v2)
    - Need to compute diff from before/after content

    The state is maintained across all events in a session, allowing normalizers
    to track file reads/writes and compute diffs for edits.

    Example usage:
        >>> state = FileSystemState()
        >>> # Track file read
        >>> state.set_content("file.py", "original content")
        >>> # Later, compute diff for edit
        >>> old_content = state.get_content("file.py")  # "original content"
        >>> new_content = "modified content"
        >>> # ... compute diff from old_content -> new_content ...
        >>> state.set_content("file.py", new_content)  # Update state

    Thread safety: This class is NOT thread-safe. Each session should have its
    own FileSystemState instance.
    """

    def __init__(self):
        """Initialize empty file system state."""
        self.files: dict[str, str] = {}

    def set_content(self, file_path: str, content: str) -> None:
        """Store file content.

        Args:
            file_path: Absolute or relative file path (normalized by adapter)
            content: Full file content as string
        """
        self.files[file_path] = content

    def get_content(self, file_path: str) -> str | None:
        """Get stored file content.

        Args:
            file_path: Absolute or relative file path

        Returns:
            File content if known, else None
        """
        return self.files.get(file_path)

    def has_content(self, file_path: str) -> bool:
        """Check if file content is known.

        Args:
            file_path: Absolute or relative file path

        Returns:
            True if content is stored for this path
        """
        return file_path in self.files

    def clear(self) -> None:
        """Clear all tracked file content.

        Useful for resetting state between sessions.
        """
        self.files.clear()

    def __len__(self) -> int:
        """Get number of files tracked.

        Returns:
            Number of files in state
        """
        return len(self.files)

    def __contains__(self, file_path: str) -> bool:
        """Check if file is tracked.

        Args:
            file_path: File path to check

        Returns:
            True if file content is stored
        """
        return file_path in self.files
