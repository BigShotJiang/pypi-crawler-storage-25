"""Gemini v1.x normalizer."""

import json
from datetime import UTC, datetime

from ..base import BaseNormalizer, compute_diff_from_content
from ..file_state import FileSystemState
from ..schemas import (
    CompactionEvent,
    ErrorEvent,
    SessionMetadata,
    TokenUsage,
    UnifiedDiff,
    UnifiedFileOperation,
    UnifiedGitCommit,
    UnifiedSkill,
    UnifiedTodo,
)
from .git_patterns import (
    is_git_commit_command,
    parse_branch_from_command,
    parse_branch_from_output,
    parse_commit_output,
)


class GeminiV1Normalizer(BaseNormalizer):
    """Normalizer for Gemini v1.x format."""

    FILE_EDIT_TOOLS = {"replace", "edit_file"}
    FILE_WRITE_TOOLS = {"write_file", "create_file"}
    FILE_READ_TOOLS = {"read_file", "view_file"}
    _SHELL_TOOLS = {"run_shell_command"}

    def extract_todo(self, event: dict, todo_state: dict | None = None) -> list[UnifiedTodo] | None:
        """Extract todos from Gemini write_todos tool."""
        if event.get("tool_name") != "write_todos":
            return None

        args = event.get("args", {})
        todos_list = args.get("todos", [])

        if not todos_list:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000)

        unified_todos = []
        for todo in todos_list:
            unified_todos.append(
                UnifiedTodo(
                    content=todo["description"],  # Gemini uses "description" not "content"
                    status=todo["status"],
                    id=None,  # Gemini doesn't provide IDs
                    timestamp=timestamp,
                    source_tool="write_todos",
                    agent_type="gemini",
                )
            )

        return unified_todos

    def extract_file_operation(self, event: dict) -> UnifiedFileOperation | None:
        """Extract file operations from Gemini tools."""
        tool_name = event.get("tool_name")
        args = event.get("args", {})
        result = event.get("result", {})

        # Determine operation and file path
        operation = None
        file_path = args.get("file_path")
        content = None

        if tool_name in self.FILE_EDIT_TOOLS:
            operation = "edit"
            # Gemini edits don't provide full content
        elif tool_name in self.FILE_WRITE_TOOLS:
            operation = "write"
            # Write: content from args
            content = args.get("content") or args.get("contents")
        elif tool_name in self.FILE_READ_TOOLS:
            operation = "read"
            # Read: content from result
            content = result.get("output") or result.get("content") or result.get("contents")

        if not operation or not file_path or not tool_name:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000)

        # Confidence is low for Gemini edits - only have replacement count
        confidence = "low" if operation == "edit" else "high"

        return UnifiedFileOperation(
            file_path=file_path,
            operation=operation,
            timestamp=timestamp,
            diff=None,  # Populated by extract_diff (git fallback)
            confidence=confidence,
            agent_type="gemini",
            source_tool=tool_name,
            source_event_id=event.get("event_id", ""),
            content=content,
        )

    def extract_skill(self, event: dict) -> UnifiedSkill | None:
        """Extract skill activations from Gemini activate_skill tool."""
        if event.get("tool_name") != "activate_skill":
            return None

        args = event.get("args", {})
        skill_name = args.get("name")

        if not skill_name:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000)

        return UnifiedSkill(
            name=skill_name,
            method="tool",
            skill_type="tool",
            timestamp=timestamp,
            agent_type="gemini",
            source_event_id=event.get("event_id", ""),
        )

    @staticmethod
    def _extract_shell_command(args: dict[str, object]) -> str:
        for key in ("command", "cmd", "input", "shell_command"):
            value = args.get(key)
            if isinstance(value, list):
                return " ".join(str(v) for v in value)
            if isinstance(value, str) and value:
                return value
        return ""

    @staticmethod
    def _extract_output_text(result: object) -> str:
        if isinstance(result, str):
            return result
        if isinstance(result, dict):
            result_dict = {str(k): v for k, v in result.items()}
            for key in (
                "output",
                "stdout",
                "content",
                "message",
                "response",
                "result",
                "functionResponse",
            ):
                value = result_dict.get(key)
                if isinstance(value, str) and value:
                    return value
                nested = GeminiV1Normalizer._extract_output_text(value)
                if nested:
                    return nested
        if isinstance(result, list):
            for item in result:
                nested = GeminiV1Normalizer._extract_output_text(item)
                if nested:
                    return nested
        return ""

    def extract_git_commit(
        self, event: dict, git_state: dict[str, object]
    ) -> UnifiedGitCommit | None:
        """Extract git commit from Gemini shell-like tools."""
        tool_name = (event.get("tool_name") or "").strip()
        if tool_name not in self._SHELL_TOOLS:
            return None

        args = event.get("args", {})
        if not isinstance(args, dict):
            return None
        cmd = self._extract_shell_command(args)
        if not cmd:
            return None

        output = self._extract_output_text(event.get("result", {}))

        branch = parse_branch_from_command(cmd)
        if not branch and output:
            branch = parse_branch_from_output(output)
        if branch:
            git_state["branch"] = branch

        if not is_git_commit_command(cmd):
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)

        commit_branch = None
        commit_hash = None
        commit_message = None
        if output:
            parsed = parse_commit_output(output)
            if parsed:
                commit_branch, commit_hash, commit_message = parsed

        resolved_branch = commit_branch or git_state.get("branch") or "unknown"

        return UnifiedGitCommit(
            branch=str(resolved_branch),
            timestamp=timestamp,
            agent_type="gemini",
            source_tool=tool_name,
            source_event_id=event.get("event_id", ""),
            commit_hash=commit_hash,
            message=commit_message,
        )

    def extract_diff(self, event: dict, session) -> UnifiedDiff | None:
        """Extract diff from Gemini tool calls.

        Gemini uses write_file for both creating and editing files.
        The result message indicates whether it was a create or edit:
        - "Successfully created and wrote to new file:" = new file (all additions)
        - "Successfully overwrote file:" = edit (compute diff from state)

        Args:
            event: Tool call event
            session: FileSystemState instance for tracking file content

        Returns:
            UnifiedDiff if diff can be extracted, else None
        """
        tool_name = event.get("tool_name", "")
        args = event.get("args", {})
        result = event.get("result", {})
        # Raw output string for substring matching (e.g. "created and wrote to new file")
        result_str = result.get("output", "") if isinstance(result, dict) else ""

        # Initialize session state if needed
        if session is None:
            session = FileSystemState()
        state = FileSystemState() if not isinstance(session, FileSystemState) else session

        file_path = args.get("file_path")

        # Track file content from READ operations
        if tool_name in self.FILE_READ_TOOLS and file_path:
            # Note: Gemini read_file often has empty result, but we can try
            # In practice, content comes from write_file args
            return None

        # Handle WRITE operations
        if tool_name in self.FILE_WRITE_TOOLS and file_path:
            new_content = args.get("content")
            if not new_content:
                return None

            # Check result to determine if this was a create or edit
            is_create = "created and wrote to new file" in result_str
            is_edit = "overwrote file" in result_str

            if is_edit:
                # Get old content from state
                old_content = state.get_content(file_path)

                if old_content is not None:
                    # Compute diff from old -> new
                    diff = self._compute_diff_from_content(old_content, new_content)
                    # Update state with new content
                    state.set_content(file_path, new_content)
                    return diff

                # No old content - store new content for future diffs
                state.set_content(file_path, new_content)
                return None

            elif is_create:
                # New file - generate "all additions" diff
                diff = self._compute_diff_from_content("", new_content)
                # Update state
                state.set_content(file_path, new_content)
                return diff

            # Unknown result format - store content but don't generate diff
            state.set_content(file_path, new_content)
            return None

        return None

    def _compute_diff_from_content(self, old_content: str, new_content: str) -> UnifiedDiff:
        """Compute unified diff from old and new file content."""
        return compute_diff_from_content(old_content, new_content)

    def extract_session_metadata(
        self,
        source_entries: list[dict],
        daemon_metadata: dict | None = None,
    ) -> SessionMetadata | None:
        """Extract session metadata from source entries.

        Args:
            source_entries: List of source entry dicts with entry_content, entry_timestamp_ms
            daemon_metadata: Optional dict with git_commit, git_repo

        Returns:
            SessionMetadata extracted from first entry + daemon metadata, or None
        """
        if not source_entries:
            return None

        timestamp = datetime.fromtimestamp(source_entries[0]["entry_timestamp_ms"] / 1000, tz=UTC)

        # Extract model from first "gemini" type entry
        primary_model = None
        for entry_dict in source_entries:
            try:
                entry = json.loads(entry_dict["entry_content"])
                if entry.get("type") == "gemini":
                    model = entry.get("model")
                    if model:
                        primary_model = model
                        break
            except (json.JSONDecodeError, KeyError):
                continue

        # Fall back to daemon_metadata.model if not found in source entries
        if not primary_model and daemon_metadata:
            primary_model = daemon_metadata.get("model") or ""

        return SessionMetadata(
            cwd=daemon_metadata.get("cwd") if daemon_metadata else None,
            agent_type="gemini",
            agent_version=daemon_metadata.get("agent_version") if daemon_metadata else None,
            git_branch=daemon_metadata.get("git_branch") if daemon_metadata else None,
            git_commit=daemon_metadata.get("git_commit") if daemon_metadata else None,
            git_repo=daemon_metadata.get("git_repo") if daemon_metadata else None,
            # Never return None - ClickHouse LowCardinality(String) doesn't accept None
            primary_model=primary_model or "",
            timestamp=timestamp,
        )

    def extract_token_usage(self, source_entry: dict) -> list[TokenUsage]:
        """Extract token usage from a single source entry.

        Gemini stores token usage in response_metadata.usage_metadata.

        Args:
            source_entry: Parsed source entry dict (already JSON loaded)

        Returns:
            List of TokenUsage instances (empty if no usage found)
        """
        response_metadata = source_entry.get("response_metadata", {})
        usage_metadata = response_metadata.get("usage_metadata", {})

        if not usage_metadata:
            return []

        timestamp = datetime.fromtimestamp(source_entry.get("_timestamp_ms", 0) / 1000, tz=UTC)

        return [
            TokenUsage(
                input_tokens=usage_metadata.get("prompt_token_count", 0),
                output_tokens=usage_metadata.get("candidates_token_count", 0),
                cache_read_tokens=0,  # Gemini doesn't expose cache details
                cache_creation_tokens=0,
                reasoning_tokens=0,
                model=source_entry.get("model"),
                timestamp=timestamp,
                is_cumulative=False,
            )
        ]

    def extract_error(self, source_entry: dict) -> ErrorEvent | None:
        """Extract error event from a single source entry.

        Gemini errors come from API error responses or tool execution failures.

        Args:
            source_entry: Parsed source entry dict (already JSON loaded)

        Returns:
            ErrorEvent if error found, else None
        """
        timestamp = datetime.fromtimestamp(source_entry.get("_timestamp_ms", 0) / 1000, tz=UTC)

        # Check for API error
        api_error = source_entry.get("error")
        if api_error and isinstance(api_error, dict):
            error_msg = api_error.get("message", "Unknown error")
            status = api_error.get("status", "")
            code = api_error.get("code", 0)

            # Determine error type from status
            error_type = "other"
            if "RESOURCE_EXHAUSTED" in status or code == 429:
                error_type = "rate_limit"
            elif "DEADLINE_EXCEEDED" in status or code == 504:
                error_type = "timeout"
            elif "INVALID_ARGUMENT" in status and "payload size" in error_msg:
                error_type = "context_length"
            elif "CANCELLED" in status:
                error_type = "cancellation"

            return ErrorEvent(
                error_type=error_type,
                message=error_msg,
                tool_name=source_entry.get("tool_name"),
                tool_call_id=source_entry.get("tool_call_id"),
                details=f"Status: {status}, Code: {code}",
                timestamp=timestamp,
            )

        # Check for tool execution error in result
        result = source_entry.get("result", {})
        if isinstance(result, dict):
            result_error = result.get("error")
            if result_error:
                return ErrorEvent(
                    error_type="tool_call_error",
                    message=result_error,
                    tool_name=source_entry.get("tool_name"),
                    tool_call_id=source_entry.get("tool_call_id"),
                    details=None,
                    timestamp=timestamp,
                )

        return None

    def extract_compaction(self, source_entries: list[dict]) -> list[CompactionEvent]:
        """Extract compaction events from source entries.

        Args:
            source_entries: All raw source entries for the session

        Returns:
            Empty list - compaction detection not yet implemented for Gemini
        """
        return []  # Not yet implemented
