"""Claude Web v1.x normalizer for cloud/web sessions.

Web sessions have different metadata and token usage structures than local
Claude Code sessions.
"""

from datetime import UTC, datetime

from ..schemas import (
    SessionMetadata,
    TokenUsage,
)
from .claude_v1 import ClaudeV1Normalizer


class ClaudeWebV1Normalizer(ClaudeV1Normalizer):
    """Normalizer for Claude Web format.

    Extends ClaudeV1Normalizer to handle web-specific differences:
    - Token usage has nested cache_creation.ephemeral_* fields
    - Session metadata comes from daemon_metadata (index -1)
    - Different source format structure
    """

    def extract_session_metadata(
        self,
        source_entries: list[dict],
        daemon_metadata: dict | None = None,
    ) -> SessionMetadata | None:
        """Extract session metadata from daemon_metadata entry.

        For web sessions, metadata comes from the daemon_metadata entry
        (index -1) which is populated from the API response.

        Args:
            source_entries: List of source entry dicts with entry_content, entry_timestamp_ms
            daemon_metadata: Dict from the -1 entry with session metadata

        Returns:
            SessionMetadata extracted from daemon_metadata
        """
        if not daemon_metadata:
            return None

        # Get timestamp from first real entry (index 0) or fallback
        timestamp = datetime.now(UTC)
        for entry_dict in source_entries:
            if entry_dict.get("entry_index", 0) >= 0:
                timestamp = datetime.fromtimestamp(
                    entry_dict.get("entry_timestamp_ms", 0) / 1000, tz=UTC
                )
                break

        return SessionMetadata(
            cwd=daemon_metadata.get("cwd"),
            agent_type="claude",  # Still Claude, just web source
            agent_version=daemon_metadata.get("agent_version", "web"),
            git_branch=daemon_metadata.get("git_branch"),
            git_commit=daemon_metadata.get("git_commit"),
            git_repo=daemon_metadata.get("git_repo"),
            primary_model=daemon_metadata.get("model") or "",
            timestamp=timestamp,
        )

    def extract_token_usage(self, source_entry: dict) -> list[TokenUsage]:
        """Extract token usage from a single source entry.

        Web format has different token usage structure:
        - usage.cache_creation.ephemeral_1h_input_tokens
        - usage.cache_creation.ephemeral_5m_input_tokens

        Args:
            source_entry: Parsed source entry dict (already JSON loaded)

        Returns:
            List of TokenUsage instances (empty if no usage found)
        """
        if source_entry.get("type") != "assistant":
            return []

        message = source_entry.get("message", {})
        usage = message.get("usage")
        if not usage:
            return []

        timestamp = datetime.fromtimestamp(source_entry.get("_timestamp_ms", 0) / 1000, tz=UTC)

        # The ephemeral_*_input_tokens inside cache_creation are a breakdown
        # of cache_creation_input_tokens, not additional tokens. Use the
        # top-level field directly (same as the local claude_v1 adapter).
        return [
            TokenUsage(
                input_tokens=usage.get("input_tokens", 0),
                output_tokens=usage.get("output_tokens", 0),
                cache_read_tokens=usage.get("cache_read_input_tokens", 0),
                cache_creation_tokens=usage.get("cache_creation_input_tokens", 0),
                reasoning_tokens=usage.get("reasoning_tokens", 0),
                model=message.get("model"),
                timestamp=timestamp,
                is_cumulative=False,
            )
        ]

    def extract_compaction(self, source_entries: list[dict]) -> list:
        """Extract compaction events from source entries.

        Web sessions may have different compaction markers.
        Uses parent implementation but handles web-specific entry format.
        """
        # Web events are already JSON loaded in the adapter, but here they're
        # still in entry_content format. Parse and use parent logic.
        parsed_entries = []
        for entry_dict in source_entries:
            try:
                # entry_content is already a string
                content = entry_dict.get("entry_content")
                if isinstance(content, str):
                    parsed_entries.append(
                        {
                            "entry_content": content,
                            "entry_timestamp_ms": entry_dict.get("entry_timestamp_ms", 0),
                        }
                    )
                else:
                    parsed_entries.append(entry_dict)
            except Exception:
                continue

        return super().extract_compaction(parsed_entries)
