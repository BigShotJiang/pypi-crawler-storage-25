"""Shared git command parsing patterns for normalizers."""

import re
from urllib.parse import urlparse

# Branch-changing commands (from the command string)
_GIT_CHECKOUT_RE = re.compile(r"git\s+(?:checkout|switch)\s+(?:-[bBc]\s+)?([^\s;&|]+)")
_GIT_WORKTREE_ADD_RE = re.compile(r"git\s+worktree\s+add\s+\S+\s+(?:-[bB]\s+)?([^\s;&|]+)")

# Branch from command output
_SWITCHED_TO_BRANCH_RE = re.compile(r"Switched to (?:a new )?branch '([^']+)'")

# Commit detection (from command string)
_GIT_COMMIT_CMD_RE = re.compile(r"git\s+commit\b")

# Commit output parsing: [branch abc1234] message
_GIT_COMMIT_OUTPUT_RE = re.compile(r"\[([^\s\]]+)\s+([a-fA-F0-9]+)\]\s+(.+)")

# PR creation detection (from command string)
_GH_PR_CREATE_CMD_RE = re.compile(r"gh\s+pr\s+create\b")

# PR URL extraction from output
_PR_URL_RE = re.compile(r"https://github\.com/[^\s]+/pull/\d+")


def parse_branch_from_command(cmd: str) -> str | None:
    """Extract target branch from a git checkout/switch/worktree command.

    Args:
        cmd: Shell command string

    Returns:
        Branch name if found, else None
    """
    m = _GIT_CHECKOUT_RE.search(cmd)
    if m:
        branch = m.group(1)
        # Ignore option-like tokens such as "--" or "--detach"
        if branch and branch != "--" and not branch.startswith("-"):
            return branch

    m = _GIT_WORKTREE_ADD_RE.search(cmd)
    if m:
        branch = m.group(1)
        # Ignore option-like tokens such as "--" or "--detach"
        if branch and branch != "--" and not branch.startswith("-"):
            return branch

    return None


def parse_branch_from_output(output: str) -> str | None:
    """Extract branch name from git command output.

    Looks for "Switched to branch 'name'" or "Switched to a new branch 'name'".

    Args:
        output: Command stdout/stderr text

    Returns:
        Branch name if found, else None
    """
    m = _SWITCHED_TO_BRANCH_RE.search(output)
    if m:
        return m.group(1)
    return None


def is_git_commit_command(cmd: str) -> bool:
    """Check if command contains a git commit invocation.

    Args:
        cmd: Shell command string

    Returns:
        True if command includes git commit
    """
    return bool(_GIT_COMMIT_CMD_RE.search(cmd))


def parse_commit_output(output: str) -> tuple[str, str, str] | None:
    """Parse branch, hash, and message from git commit output.

    Git commit output format: [branch abc1234] commit message here

    Args:
        output: Command stdout text

    Returns:
        (branch, commit_hash, message) tuple, or None if not parseable
    """
    m = _GIT_COMMIT_OUTPUT_RE.search(output)
    if m:
        return m.group(1), m.group(2), m.group(3)
    return None


def is_pr_create_command(cmd: str) -> bool:
    """Check if command contains a gh pr create invocation.

    Args:
        cmd: Shell command string

    Returns:
        True if command includes gh pr create
    """
    return bool(_GH_PR_CREATE_CMD_RE.search(cmd))


def parse_pr_url_from_output(output: str) -> str | None:
    """Extract a GitHub PR URL from command output.

    gh pr create outputs the PR URL as the last line of output.

    Args:
        output: Command stdout text

    Returns:
        PR URL if found, else None
    """
    m = _PR_URL_RE.search(output)
    if m:
        return m.group(0)
    return None


def parse_pr_number_from_url(url: str) -> int | None:
    """Extract the PR number from a GitHub PR URL.

    Args:
        url: GitHub PR URL (e.g., https://github.com/org/repo/pull/123)

    Returns:
        PR number as int, or None if not parseable
    """
    try:
        path = urlparse(url).path
        parts = path.strip("/").split("/")
        if len(parts) >= 4 and parts[-2] == "pull":
            return int(parts[-1])
    except (ValueError, IndexError):
        pass
    return None


def parse_pr_title_from_command(cmd: str) -> str | None:
    """Extract PR title from --title flag in gh pr create command.

    Args:
        cmd: Shell command string

    Returns:
        Title string if found, else None
    """
    # Match --title "..." or --title '...'
    m = re.search(r'--title\s+["\']([^"\']+)["\']', cmd)
    if m:
        return m.group(1)
    return None
