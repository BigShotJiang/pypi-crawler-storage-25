"""Canonical schemas for unified agent representations."""

from dataclasses import dataclass
from datetime import datetime
from typing import Literal


@dataclass
class UnifiedTodo:
    """Unified todo representation across all agents."""

    content: str
    status: Literal["pending", "in_progress", "completed"]
    id: str | None  # Cursor/Claude have IDs, Codex/Gemini don't
    timestamp: datetime
    source_tool: str
    agent_type: str
    description: str | None = None  # Longer detail (e.g. Claude TaskCreate.description)
    active_form: str | None = None  # Present-tense form (e.g. Claude TaskCreate.activeForm)


@dataclass
class SessionMetadata:
    """Session-level metadata extracted from agent logs."""

    cwd: str | None
    agent_type: str
    agent_version: str | None
    git_branch: str | None
    git_commit: str | None
    git_repo: str | None
    primary_model: str | None
    timestamp: datetime


@dataclass
class TokenUsage:
    """Token usage information from agent API calls."""

    timestamp: datetime
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0
    reasoning_tokens: int = 0
    model: str | None = None
    is_cumulative: bool = False
    cost_usd: float | None = None


@dataclass
class ErrorEvent:
    """Error event extracted from agent logs."""

    error_type: Literal[
        "tool_call_error",
        "interruption",
        "cancellation",
        "timeout",
        "rate_limit",
        "context_length",
        "authentication",
        "api_error",
        "other",
    ]
    message: str
    timestamp: datetime
    tool_name: str | None = None
    tool_call_id: str | None = None
    details: str | None = None


@dataclass
class CompactionEvent:
    """Compaction event (context summarization) extracted from agent logs."""

    compaction_type: Literal["auto_summarization", "context_limit", "manual"]
    timestamp: datetime
    message_id: str | None = None  # UUID for linking to the event in timeline
    messages_before: int | None = None
    messages_after: int | None = None
    tokens_saved: int | None = None


@dataclass
class DiffHunk:
    """A single hunk in unified diff format."""

    old_start: int
    old_count: int
    new_start: int
    new_count: int
    lines: list[str]  # Lines prefixed with ' ', '+', '-'


@dataclass
class UnifiedDiff:
    """Unified diff representation."""

    hunks: list[DiffHunk]
    format_source: Literal[
        "structured_patch",
        "computed",
        "git_fallback",
        "shell_inferred",
        "codex_apply_patch",
        "cursor_diff_chunks",
        "opencode_patch",
    ]
    confidence: Literal["high", "medium", "low"]
    lines_added: list[int]  # Line numbers added
    lines_modified: list[int]  # Line numbers modified


@dataclass
class UnifiedFileOperation:
    """Unified file operation representation."""

    file_path: str
    operation: Literal["read", "write", "edit", "search", "list"]
    timestamp: datetime
    diff: UnifiedDiff | None
    confidence: Literal["high", "medium", "low"]
    agent_type: str
    source_tool: str
    source_event_id: str
    content: str | None = None  # File content (for read: original, for write: new content)


@dataclass
class UnifiedSkill:
    """Unified skill activation representation."""

    name: str
    method: Literal["tool", "file-read"]
    skill_type: str  # "native", "marketplace", "superpowers", etc.
    timestamp: datetime
    agent_type: str
    source_event_id: str
    file_path: str | None = None  # For file-based detection
    args: str | None = None  # For tool-based with args


@dataclass
class UnifiedGitCommit:
    """Git commit detected from shell commands during a session."""

    branch: str
    timestamp: datetime
    agent_type: str
    source_tool: str
    source_event_id: str
    commit_hash: str | None = None
    message: str | None = None


@dataclass
class UnifiedPullRequest:
    """PR creation detected from shell commands during a session."""

    url: str
    branch: str
    timestamp: datetime
    agent_type: str
    source_tool: str
    source_event_id: str
    number: int | None = None
    title: str | None = None
