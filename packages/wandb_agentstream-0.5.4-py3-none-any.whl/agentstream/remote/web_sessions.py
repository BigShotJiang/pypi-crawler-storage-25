"""Web session discovery via Claude/Anthropic API.

This module provides functionality to discover and fetch agent sessions from
Anthropic's cloud API. This enables syncing sessions that were started on
Claude Code for web to the AgentStream backend.

The API endpoint used is the same one that powers Claude's --teleport feature.
"""

from __future__ import annotations

import contextlib
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

import httpx

from agentstream.remote.claude_credentials import ClaudeCredentials, read_claude_credentials

logger = logging.getLogger(__name__)

# Anthropic API configuration
ANTHROPIC_API_BASE = "https://api.anthropic.com"
ANTHROPIC_API_VERSION = "2023-06-01"
ANTHROPIC_BETA = "ccr-byoc-2025-07-29"

# Default polling interval (30 minutes)
DEFAULT_POLL_INTERVAL_SECONDS = 1800


@dataclass
class WebSession:
    """Represents a session from the web/cloud API.

    Contains the session metadata and conversation entries needed for
    syncing to the AgentStream backend.
    """

    id: str
    name: str | None
    project_path: str | None  # The cwd/project path from the session
    created_at: datetime | None
    updated_at: datetime | None
    model: str | None
    git_repo: str | None
    git_branch: str | None

    # Session content
    entries: list[dict[str, Any]] = field(default_factory=list)

    # Source tracking
    source: str = "web"  # 'web' for cloud sessions

    @property
    def is_empty(self) -> bool:
        """Check if session has no entries."""
        return len(self.entries) == 0


class WebSessionsClient:
    """Client for fetching sessions from Anthropic's API.

    Uses Claude Code OAuth credentials to authenticate with the API
    and fetch web session data.
    """

    def __init__(
        self,
        credentials: ClaudeCredentials | None = None,
        timeout: float = 30.0,
    ):
        """Initialize the client.

        Args:
            credentials: Claude OAuth credentials. If None, will attempt to
                read from system storage.
            timeout: HTTP request timeout in seconds.
        """
        self._credentials = credentials
        self._timeout = timeout

    @property
    def credentials(self) -> ClaudeCredentials | None:
        """Get current credentials, reading from storage if needed."""
        if self._credentials is None:
            self._credentials = read_claude_credentials()
        return self._credentials

    def refresh_credentials(self) -> ClaudeCredentials | None:
        """Force refresh of credentials from storage."""
        self._credentials = read_claude_credentials()
        return self._credentials

    def _get_headers(self) -> dict[str, str]:
        """Build request headers with authentication."""
        creds = self.credentials
        if not creds:
            raise ValueError("No Claude credentials available")

        headers = {
            "Authorization": f"Bearer {creds.access_token}",
            "anthropic-version": ANTHROPIC_API_VERSION,
            "anthropic-beta": ANTHROPIC_BETA,
            "Content-Type": "application/json",
        }

        # Add organization UUID if available
        if creds.organization_uuid:
            headers["x-organization-uuid"] = creds.organization_uuid

        return headers

    async def list_sessions(self, limit: int = 50) -> list[WebSession]:
        """List sessions from the API.

        Args:
            limit: Maximum number of sessions to return.

        Returns:
            List of WebSession objects.

        Raises:
            httpx.HTTPError: If the API request fails.
            ValueError: If credentials are not available or invalid.
        """
        creds = self.credentials
        if not creds:
            raise ValueError("No Claude credentials available")

        if creds.is_expired:
            logger.warning("Claude credentials are expired")
            # Try refreshing from storage in case they were updated
            creds = self.refresh_credentials()
            if not creds or creds.is_expired:
                raise ValueError("Claude credentials are expired")

        url = f"{ANTHROPIC_API_BASE}/v1/sessions"
        headers = self._get_headers()

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.get(
                url,
                headers=headers,
                params={"limit": limit},
            )

            if response.status_code == 401:
                logger.error("Authentication failed - credentials may be invalid or expired")
                raise ValueError("Authentication failed")

            if response.status_code == 403:
                logger.error("Access forbidden - organization may not allow API access")
                raise ValueError("Access forbidden")

            response.raise_for_status()
            data = response.json()

        # Parse sessions from response
        # API returns {"data": [...sessions...], "has_more": bool, ...}
        sessions = []
        sessions_list = data.get(
            "data", data.get("sessions", data if isinstance(data, list) else [])
        )
        for session_data in sessions_list:
            session = self._parse_session(session_data)
            if session:
                sessions.append(session)

        logger.info(f"Retrieved {len(sessions)} web sessions from API")
        return sessions

    async def get_session(self, session_id: str) -> WebSession | None:
        """Get a specific session by ID.

        Args:
            session_id: The session ID to fetch.

        Returns:
            WebSession object or None if not found.
        """
        creds = self.credentials
        if not creds:
            raise ValueError("No Claude credentials available")

        url = f"{ANTHROPIC_API_BASE}/v1/sessions/{session_id}"
        headers = self._get_headers()

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.get(url, headers=headers)

            if response.status_code == 404:
                return None

            response.raise_for_status()
            data = response.json()

        return self._parse_session(data)

    async def get_session_events(
        self,
        session_id: str,
        page_size: int = 250,
        max_events: int = 10000,
    ) -> list[dict[str, Any]]:
        """Get all conversation events for a session.

        The API uses `/v1/sessions/{id}/events` endpoint with cursor-based
        pagination via `after_id` parameter.

        Args:
            session_id: The session ID to fetch events for.
            page_size: Number of events per API request (default 100).
            max_events: Maximum total events to fetch as safety limit (default 10000).

        Returns:
            List of event dicts. Returns [] if session not found.

        Raises:
            httpx.HTTPError: If the API request fails (except 404).
            ValueError: If credentials are not available.
        """
        creds = self.credentials
        if not creds:
            raise ValueError("No Claude credentials available")

        url = f"{ANTHROPIC_API_BASE}/v1/sessions/{session_id}/events"
        headers = self._get_headers()

        all_events: list[dict[str, Any]] = []
        after_id: str | None = None

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            while True:
                params: dict[str, Any] = {"limit": page_size}
                if after_id:
                    params["after_id"] = after_id

                response = await client.get(url, headers=headers, params=params)

                if response.status_code == 404:
                    logger.warning(f"Session {session_id[:16]}... not found (404)")
                    return []

                response.raise_for_status()
                data = response.json()

                events = data.get("data", [])
                all_events.extend(events)

                has_more = data.get("has_more", False)
                last_id = data.get("last_id")

                if not has_more or not last_id:
                    break

                after_id = last_id

                # Safety limit to prevent infinite loops
                if len(all_events) >= max_events:
                    logger.warning(
                        f"Session {session_id[:16]}... reached max_events limit ({max_events}). "
                        "Stopping pagination."
                    )
                    break

        logger.debug(f"Retrieved {len(all_events)} events for session {session_id[:16]}...")
        return all_events

    def _parse_session(self, data: dict[str, Any]) -> WebSession | None:
        """Parse a session from API response data.

        The API returns sessions with this structure:
        {
            "id": "session_01Wapx...",
            "created_at": "2026-02-01T01:41:48.916588Z",
            "session_context": {
                "cwd": "/path/to/project",
                "model": "claude-opus-4-5-20251101",
                "outcomes": [{"type": "git_repository", "git_info": {...}}],
                ...
            },
            ...
        }
        """
        session_id = data.get("id") or data.get("session_id")
        if not session_id:
            logger.debug("Session data missing ID, skipping")
            return None

        # Parse timestamps
        created_at = None
        if "created_at" in data:
            with contextlib.suppress(ValueError, AttributeError):
                created_at = datetime.fromisoformat(data["created_at"].replace("Z", "+00:00"))

        updated_at = None
        if "updated_at" in data:
            with contextlib.suppress(ValueError, AttributeError):
                updated_at = datetime.fromisoformat(data["updated_at"].replace("Z", "+00:00"))

        # Extract project/repo information from session_context
        # The API uses session_context instead of metadata
        context = data.get("session_context", {})
        metadata = data.get("metadata", {})  # Fallback for alternate formats

        # Get cwd/project path
        project_path = context.get("cwd") or metadata.get("cwd") or metadata.get("project_path")

        # Get model
        model = context.get("model") or metadata.get("model")

        # Extract git info from outcomes
        git_repo = None
        git_branch = None
        outcomes = context.get("outcomes", [])
        for outcome in outcomes:
            if outcome.get("type") == "git_repository":
                git_info = outcome.get("git_info", {})
                # Build repo URL from git_info
                if git_info.get("type") == "github" and git_info.get("repo"):
                    git_repo = f"github.com/{git_info['repo']}"
                branches = git_info.get("branches", [])
                if branches:
                    git_branch = branches[0]  # Use first branch
                break

        # Fallback to metadata git info
        if not git_repo:
            git_repo = metadata.get("git_repo")
        if not git_branch:
            git_branch = metadata.get("git_branch")

        # Name might be in different places
        name = data.get("name") or data.get("title") or context.get("name")

        return WebSession(
            id=session_id,
            name=name,
            project_path=project_path,
            created_at=created_at,
            updated_at=updated_at,
            model=model,
            git_repo=git_repo,
            git_branch=git_branch,
            entries=data.get("entries", []),
            source="web",
        )


class WebSessionPoller:
    """Polls for new web sessions periodically.

    Designed to be integrated with the daemon's main loop, this class
    manages the polling state and provides sessions that need syncing.
    """

    def __init__(
        self,
        client: WebSessionsClient | None = None,
        poll_interval: float = DEFAULT_POLL_INTERVAL_SECONDS,
    ):
        """Initialize the poller.

        Args:
            client: WebSessionsClient instance. If None, one will be created.
            poll_interval: Time between polls in seconds (default: 30 minutes).
        """
        self._client = client or WebSessionsClient()
        self._poll_interval = poll_interval
        self._last_poll_time: float = 0
        self._known_sessions: dict[str, float] = {}  # session_id -> last_updated_ts
        self._enabled = True
        self._consecutive_failures = 0
        self._max_failures_before_backoff = 3

    @property
    def client(self) -> WebSessionsClient:
        """Get the underlying client."""
        return self._client

    @property
    def is_enabled(self) -> bool:
        """Check if polling is enabled."""
        return self._enabled

    @property
    def should_poll(self) -> bool:
        """Check if it's time to poll again."""
        if not self._enabled:
            return False

        # Apply exponential backoff after consecutive failures
        backoff_multiplier = 2 ** min(self._consecutive_failures, 5)
        effective_interval = self._poll_interval * backoff_multiplier

        return time.monotonic() - self._last_poll_time >= effective_interval

    @property
    def seconds_until_next_poll(self) -> float:
        """Get seconds until next poll is due."""
        if not self._enabled:
            return float("inf")

        backoff_multiplier = 2 ** min(self._consecutive_failures, 5)
        effective_interval = self._poll_interval * backoff_multiplier
        elapsed = time.monotonic() - self._last_poll_time
        return max(0, effective_interval - elapsed)

    @property
    def known_session_ids(self) -> set[str]:
        """Get the set of known session IDs."""
        return set(self._known_sessions.keys())

    def enable(self) -> None:
        """Enable polling."""
        self._enabled = True
        logger.info("Web session polling enabled")

    def disable(self, reason: str = "unknown") -> None:
        """Disable polling.

        Args:
            reason: Reason for disabling (for logging).
        """
        self._enabled = False
        logger.info(f"Web session polling disabled: {reason}")

    async def poll(self) -> list[WebSession]:
        """Poll for new or updated sessions.

        Returns:
            List of sessions that are new or have been updated since last poll.
        """
        if not self._enabled:
            return []

        self._last_poll_time = time.monotonic()

        try:
            # Check if credentials are available
            creds = self._client.credentials
            if not creds:
                logger.debug("No Claude credentials, skipping web session poll")
                return []

            if creds.is_expired:
                logger.debug("Claude credentials expired, skipping web session poll")
                return []

            # Fetch sessions from API
            sessions = await self._client.list_sessions()
            self._consecutive_failures = 0  # Reset on success

            # Filter to new or updated sessions
            new_or_updated = []
            for session in sessions:
                session_key = session.id

                # Get the session's update timestamp
                session_ts = 0.0
                if session.updated_at:
                    session_ts = session.updated_at.timestamp()
                elif session.created_at:
                    session_ts = session.created_at.timestamp()

                # Check if this is new or updated
                last_known_ts = self._known_sessions.get(session_key, 0)
                if session_ts > last_known_ts:
                    new_or_updated.append(session)
                    self._known_sessions[session_key] = session_ts

            if new_or_updated:
                logger.info(f"Found {len(new_or_updated)} new/updated web sessions")
            else:
                logger.debug("No new web sessions found")

            return new_or_updated

        except ValueError as e:
            # Credential issues - disable polling
            self._consecutive_failures += 1
            if self._consecutive_failures >= self._max_failures_before_backoff:
                self.disable(str(e))
            logger.warning(f"Web session poll failed: {e}")
            return []

        except httpx.HTTPError as e:
            # Network/API errors - apply backoff
            self._consecutive_failures += 1
            logger.warning(
                f"Web session poll HTTP error (attempt {self._consecutive_failures}): {e}"
            )
            return []

        except Exception as e:
            # Unexpected errors
            self._consecutive_failures += 1
            logger.error(f"Unexpected error during web session poll: {e}")
            return []

    def mark_session_synced(self, session_id: str, timestamp: float | None = None) -> None:
        """Mark a session as synced with a specific timestamp.

        This is useful when syncing session entries to track the
        last synced state.

        Args:
            session_id: The session ID.
            timestamp: Unix timestamp of the sync. Defaults to now.
        """
        self._known_sessions[session_id] = timestamp or time.time()

    def reset(self) -> None:
        """Reset the poller state.

        Clears known sessions and failure counters.
        """
        self._known_sessions.clear()
        self._consecutive_failures = 0
        self._last_poll_time = 0
        logger.info("Web session poller state reset")
