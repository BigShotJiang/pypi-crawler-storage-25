"""Remote session discovery via cloud APIs.

This module provides functionality to discover and fetch agent sessions from
remote/cloud sources (e.g., Claude Code web sessions) in addition to local
file-based sessions.

Example usage:
    from agentstream.remote import read_claude_credentials, WebSessionsClient

    # Check for Claude credentials
    creds = read_claude_credentials()
    if creds and not creds.is_expired:
        client = WebSessionsClient(credentials=creds)
        sessions = await client.list_sessions()
        for session in sessions:
            print(f"Session: {session.id} - {session.name}")
"""

from agentstream.remote.claude_credentials import (
    ClaudeCredentials,
    has_claude_credentials,
    read_claude_credentials,
)
from agentstream.remote.web_sessions import (
    DEFAULT_POLL_INTERVAL_SECONDS,
    WebSession,
    WebSessionPoller,
    WebSessionsClient,
)

__all__ = [
    # Credentials
    "ClaudeCredentials",
    "read_claude_credentials",
    "has_claude_credentials",
    # Web sessions
    "WebSession",
    "WebSessionsClient",
    "WebSessionPoller",
    "DEFAULT_POLL_INTERVAL_SECONDS",
]
