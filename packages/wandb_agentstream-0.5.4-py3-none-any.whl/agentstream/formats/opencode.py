"""OpenCode format types."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict


class OpenCodeTime(BaseModel):
    """Time information for OpenCode objects."""

    model_config = ConfigDict(extra="ignore")

    created: int
    updated: int | None = None
    completed: int | None = None


class OpenCodeProject(BaseModel):
    """OpenCode project metadata."""

    model_config = ConfigDict(extra="ignore")

    id: str
    worktree: str
    vcs: str | None = None
    time: OpenCodeTime | None = None


class OpenCodeSessionSummary(BaseModel):
    """Session summary statistics."""

    model_config = ConfigDict(extra="ignore")

    additions: int | None = None
    deletions: int | None = None
    files: int | None = None


class OpenCodeSession(BaseModel):
    """OpenCode session metadata."""

    model_config = ConfigDict(extra="ignore")

    id: str
    slug: str | None = None
    version: str | None = None
    projectID: str
    directory: str
    title: str | None = None
    parentID: str | None = None
    time: OpenCodeTime
    summary: OpenCodeSessionSummary | None = None


class OpenCodeModel(BaseModel):
    """Model specification in OpenCode."""

    model_config = ConfigDict(extra="ignore")

    providerID: str
    modelID: str


class OpenCodeTokens(BaseModel):
    """Token usage information."""

    model_config = ConfigDict(extra="ignore")

    input: int = 0
    output: int = 0
    reasoning: int = 0
    cache: dict[str, int] | None = None


class OpenCodeMessagePath(BaseModel):
    """Path information for assistant messages."""

    model_config = ConfigDict(extra="ignore")

    cwd: str
    root: str


class OpenCodeUserMessage(BaseModel):
    """OpenCode user message."""

    model_config = ConfigDict(extra="ignore")

    id: str
    sessionID: str
    role: Literal["user"]
    time: OpenCodeTime
    agent: str | None = None
    model: OpenCodeModel | None = None


class OpenCodeAssistantMessage(BaseModel):
    """OpenCode assistant message."""

    model_config = ConfigDict(extra="ignore")

    id: str
    sessionID: str
    role: Literal["assistant"]
    time: OpenCodeTime
    parentID: str | None = None
    modelID: str | None = None
    providerID: str | None = None
    agent: str | None = None
    path: OpenCodeMessagePath | None = None
    cost: float | None = None
    tokens: OpenCodeTokens | None = None
    finish: str | None = None


class OpenCodeToolState(BaseModel):
    """Tool execution state."""

    model_config = ConfigDict(extra="ignore")

    status: Literal["pending", "running", "completed", "error"]
    input: dict[str, Any] | None = None
    output: str | None = None
    error: str | None = None
    title: str | None = None
    metadata: dict[str, Any] | None = None
    time: dict[str, int] | None = None


class OpenCodeTextPart(BaseModel):
    """Text part in a message."""

    model_config = ConfigDict(extra="ignore")

    id: str
    sessionID: str
    messageID: str
    type: Literal["text"]
    text: str


class OpenCodeReasoningPart(BaseModel):
    """Reasoning/thinking part in a message."""

    model_config = ConfigDict(extra="ignore")

    id: str
    sessionID: str
    messageID: str
    type: Literal["reasoning"]
    text: str


class OpenCodeToolPart(BaseModel):
    """Tool call part in a message."""

    model_config = ConfigDict(extra="ignore")

    id: str
    sessionID: str
    messageID: str
    type: Literal["tool"]
    callID: str
    tool: str
    state: OpenCodeToolState


class OpenCodeStepStartPart(BaseModel):
    """Step start marker."""

    model_config = ConfigDict(extra="ignore")

    id: str
    sessionID: str
    messageID: str
    type: Literal["step-start"]


class OpenCodeStepFinishPart(BaseModel):
    """Step finish marker with usage info."""

    model_config = ConfigDict(extra="ignore")

    id: str
    sessionID: str
    messageID: str
    type: Literal["step-finish"]
    reason: str | None = None
    cost: float | None = None
    tokens: OpenCodeTokens | None = None


class OpenCodeFilePart(BaseModel):
    """File attachment part."""

    model_config = ConfigDict(extra="ignore")

    id: str
    sessionID: str
    messageID: str
    type: Literal["file"]
    mime: str | None = None
    filename: str | None = None
    url: str | None = None
