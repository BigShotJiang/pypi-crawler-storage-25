"""Claude Code Web format types for cloud/web sessions.

Web sessions use a slightly different format than local Claude Code sessions.
Key differences:
- No root-level timestamp (timestamp in nested data or usage fields)
- env_manager_log events for environment setup
- system events have flat structure vs message object
- isReplay field for replayed messages
- Different usage structure (cache_creation.ephemeral_* tokens)
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class WebUsageCache(BaseModel):
    """Cache creation details for web sessions."""

    model_config = ConfigDict(extra="ignore")

    ephemeral_1h_input_tokens: int = 0
    ephemeral_5m_input_tokens: int = 0


class WebUsage(BaseModel):
    """Token usage from Claude API responses (web format)."""

    model_config = ConfigDict(extra="ignore")

    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    cache_creation: WebUsageCache | None = None
    service_tier: str | None = None


class WebContentBlock(BaseModel):
    """Web content block (text, thinking, tool_use, tool_result)."""

    model_config = ConfigDict(extra="ignore")

    type: Literal["text", "thinking", "tool_use", "tool_result"]
    # text fields
    text: str | None = None
    # thinking fields
    thinking: str | None = None
    signature: str | None = None
    # tool_use fields
    id: str | None = None
    name: str | None = None
    input: dict[str, Any] | None = None
    # tool_result fields
    tool_use_id: str | None = None
    content: str | list[Any] | None = None
    is_error: bool = False


class WebUserMessage(BaseModel):
    """User message content (web format)."""

    model_config = ConfigDict(extra="ignore")

    role: Literal["user"] | None = None
    content: str | list[WebContentBlock]


class WebAssistantMessage(BaseModel):
    """Assistant message with content blocks (web format)."""

    model_config = ConfigDict(extra="ignore")

    role: Literal["assistant"] | None = None
    content: list[WebContentBlock]
    model: str | None = None
    stop_reason: str | None = None
    stop_sequence: str | None = None
    usage: WebUsage | None = None
    id: str | None = None  # API message ID
    type: Literal["message"] | None = None
    context_management: dict[str, Any] | None = None


class WebEnvManagerLogData(BaseModel):
    """Data for env_manager_log events."""

    model_config = ConfigDict(extra="ignore")

    category: str = ""
    content: str = ""
    level: str = "info"
    timestamp: str | None = None
    extra: dict[str, Any] = Field(default_factory=dict)


class WebToolUseResult(BaseModel):
    """Result metadata from tool execution (web format)."""

    model_config = ConfigDict(extra="ignore")

    new_todos: list[dict[str, Any]] | None = Field(default=None, validation_alias="newTodos")
    old_todos: list[dict[str, Any]] | None = Field(default=None, validation_alias="oldTodos")


# Entry types for web format


class WebEnvManagerLogEntry(BaseModel):
    """env_manager_log entry for environment setup events."""

    model_config = ConfigDict(extra="ignore")

    type: Literal["env_manager_log"]
    uuid: str
    data: WebEnvManagerLogData


class WebSystemEntry(BaseModel):
    """system entry for session initialization."""

    model_config = ConfigDict(extra="ignore")

    type: Literal["system"]
    uuid: str
    subtype: str | None = None
    cwd: str | None = None
    model: str | None = None
    session_id: str | None = None
    claude_code_version: str | None = None
    agents: list[str] = Field(default_factory=list)
    tools: list[str] = Field(default_factory=list)
    skills: list[str] = Field(default_factory=list)
    slash_commands: list[str] = Field(default_factory=list)
    mcp_servers: list[str] = Field(default_factory=list)
    plugins: list[str] = Field(default_factory=list)
    permission_mode: str | None = Field(default=None, validation_alias="permissionMode")
    output_style: str | None = None
    api_key_source: str | None = Field(default=None, validation_alias="apiKeySource")


class WebUserEntry(BaseModel):
    """User message entry (web format)."""

    model_config = ConfigDict(extra="ignore")

    type: Literal["user"]
    uuid: str
    message: WebUserMessage
    session_id: str | None = None
    is_replay: bool = Field(default=False, validation_alias="isReplay")
    parent_tool_use_id: str | None = None
    tool_use_result: WebToolUseResult | None = None


class WebAssistantEntry(BaseModel):
    """Assistant message entry (web format)."""

    model_config = ConfigDict(extra="ignore")

    type: Literal["assistant"]
    uuid: str
    message: WebAssistantMessage
    session_id: str | None = None
    parent_tool_use_id: str | None = None


class WebModelUsage(BaseModel):
    """Per-model usage stats from result event."""

    model_config = ConfigDict(extra="ignore")

    cache_creation_input_tokens: int = Field(default=0, validation_alias="cacheCreationInputTokens")
    cache_read_input_tokens: int = Field(default=0, validation_alias="cacheReadInputTokens")
    input_tokens: int = Field(default=0, validation_alias="inputTokens")
    output_tokens: int = Field(default=0, validation_alias="outputTokens")
    cost_usd: float = Field(default=0.0, validation_alias="costUSD")
    context_window: int = Field(default=0, validation_alias="contextWindow")
    max_output_tokens: int = Field(default=0, validation_alias="maxOutputTokens")
    web_search_requests: int = Field(default=0, validation_alias="webSearchRequests")


class WebResultEntry(BaseModel):
    """Result/summary entry at end of session (web format).

    Contains authoritative timing and usage information for the session.
    """

    model_config = ConfigDict(extra="ignore")

    type: Literal["result"]
    uuid: str
    session_id: str | None = None
    subtype: str | None = None  # "success" or "error_during_execution"
    result: str | None = None  # Summary text

    # Timing information - THE AUTHORITATIVE SOURCE
    duration_ms: int = 0  # Actual work time (excluding user think time)
    duration_api_ms: int = 0  # Time spent on API calls

    # Turn and usage counts
    num_turns: int = 0
    total_cost_usd: float = 0.0

    # Per-model usage
    model_usage: dict[str, WebModelUsage] = Field(
        default_factory=dict, validation_alias="modelUsage"
    )

    # Aggregated usage
    usage: WebUsage | None = None

    # Errors/issues
    permission_denials: list[str] = Field(default_factory=list)
    is_error: bool = False
