"""Gemini CLI format types."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class GeminiThought(BaseModel):
    """A thought/reasoning entry from Gemini."""

    model_config = ConfigDict(extra="ignore")

    subject: str
    description: str
    timestamp: str


class GeminiToolResult(BaseModel):
    """Result from a Gemini tool call."""

    model_config = ConfigDict(extra="ignore")

    function_response: dict[str, Any] = Field(alias="functionResponse")


class GeminiToolCall(BaseModel):
    """A tool call from Gemini."""

    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    args: dict[str, Any]
    result: list[GeminiToolResult] = []
    status: str
    timestamp: str
    display_name: str | None = Field(default=None, alias="displayName")
    description: str | None = None
    result_display: str | None = Field(default=None, alias="resultDisplay")
    render_output_as_markdown: bool = Field(default=False, alias="renderOutputAsMarkdown")


class GeminiTokens(BaseModel):
    """Token usage from Gemini."""

    model_config = ConfigDict(extra="ignore")

    input: int = 0
    output: int = 0
    cached: int = 0
    thoughts: int = 0
    tool: int = 0
    total: int = 0


class GeminiMessage(BaseModel):
    """A message in a Gemini session."""

    model_config = ConfigDict(extra="ignore")

    id: str
    timestamp: str
    type: Literal["user", "gemini", "info"]
    content: str = ""
    thoughts: list[GeminiThought] = []

    @field_validator("content", mode="before")
    @classmethod
    def _coerce_content(cls, v: Any) -> str:
        """Handle Gemini content that can be a string or list of content blocks."""
        if isinstance(v, str):
            return v
        if isinstance(v, list):
            # Extract text from content blocks, ignore inlineData etc.
            texts = []
            for item in v:
                if isinstance(item, dict) and "text" in item:
                    texts.append(item["text"])
            return "\n".join(texts)
        return str(v) if v else ""

    tool_calls: list[GeminiToolCall] = Field(default=[], alias="toolCalls")
    model: str | None = None
    tokens: GeminiTokens | None = None


class GeminiSession(BaseModel):
    """A complete Gemini session file."""

    model_config = ConfigDict(extra="ignore")

    session_id: str = Field(alias="sessionId")
    project_hash: str = Field(alias="projectHash")
    start_time: str = Field(alias="startTime")
    last_updated: str = Field(alias="lastUpdated")
    messages: list[GeminiMessage]
