"""Claude Code format types and metadata models."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class ClaudeUsage(BaseModel):
    """Token usage from Claude API responses."""

    model_config = ConfigDict(extra="ignore")

    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    reasoning_tokens: int = 0


class ClaudeMessageMeta(BaseModel):
    """Metadata preserved from Claude Code JSONL entries."""

    model_config = ConfigDict(extra="ignore")

    parent_uuid: str | None = None
    is_sidechain: bool = False
    user_type: str | None = None
    request_id: str | None = None
    model: str | None = None
    stop_reason: str | None = None
    api_message_id: str | None = None
    usage: ClaudeUsage | None = None


class ClaudeThinkingMeta(BaseModel):
    """Metadata for Claude thinking blocks (extended thinking)."""

    model_config = ConfigDict(extra="ignore")

    signature: str | None = None


class ClaudeSessionMeta(BaseModel):
    """Session-level metadata from Claude Code."""

    model_config = ConfigDict(extra="ignore")

    session_id: str | None = None
    cwd: str | None = None
    git_branch: str | None = None
    version: str | None = None
    agent_id: str | None = None


class ImageSource(BaseModel):
    """Source data for image content blocks."""

    model_config = ConfigDict(extra="ignore")

    type: str  # "base64"
    media_type: str  # "image/png", "image/jpeg", etc.
    data: str  # base64-encoded image data


class ContentBlock(BaseModel):
    """Claude content block (text, thinking, tool_use, tool_result)."""

    model_config = ConfigDict(extra="ignore")

    # Use str instead of Literal to accept unknown block types (e.g., "image",
    # "document") without failing validation.  The adapter filters by known types.
    type: str
    # text fields
    text: str | None = None
    # image fields
    source: ImageSource | None = None
    # thinking fields
    thinking: str | None = None
    signature: str | None = None
    # tool_use fields
    id: str | None = None
    name: str | None = None
    input: dict[str, Any] | None = None
    # tool_result fields
    tool_use_id: str | None = None
    content: str | list[Any] | None = None
    is_error: bool = False


class UserMessage(BaseModel):
    """User message content."""

    model_config = ConfigDict(extra="ignore")

    role: Literal["user"] | None = None
    content: str | list[ContentBlock]


class SystemMessage(BaseModel):
    """System message content."""

    model_config = ConfigDict(extra="ignore")

    content: str


class AssistantMessage(BaseModel):
    """Assistant message with content blocks."""

    model_config = ConfigDict(extra="ignore")

    role: Literal["assistant"] | None = None
    content: list[ContentBlock]
    model: str | None = None
    stop_reason: str | None = None
    stop_sequence: str | None = None
    usage: ClaudeUsage | None = None
    id: str | None = None  # API message ID


class PatchHunk(BaseModel):
    """A hunk from a unified diff patch."""

    model_config = ConfigDict(extra="ignore")

    old_start: int = Field(validation_alias="oldStart")
    old_count: int = Field(validation_alias="oldLines")
    new_start: int = Field(validation_alias="newStart")
    new_count: int = Field(validation_alias="newLines")
    lines: list[str]


class ToolUseResult(BaseModel):
    """Result metadata from tool execution."""

    model_config = ConfigDict(extra="ignore")

    type: str | None = None
    file_path: str | None = Field(default=None, validation_alias="filePath")
    content: str | list[Any] | None = None
    old_string: str | None = Field(default=None, validation_alias="oldString")
    new_string: str | None = Field(default=None, validation_alias="newString")
    structured_patch: list[PatchHunk] | None = Field(
        default=None, validation_alias="structuredPatch"
    )
    filenames: list[str] | None = None
    mode: str | None = None


class LogEntry(BaseModel):
    """A single line from Claude Code's JSONL log."""

    model_config = ConfigDict(extra="ignore")

    type: Literal["user", "assistant", "system"]
    message: UserMessage | AssistantMessage | SystemMessage
    uuid: str
    parent_uuid: str | None = Field(default=None, validation_alias="parentUuid")
    timestamp: str
    session_id: str | None = Field(default=None, validation_alias="sessionId")
    cwd: str | None = None
    git_branch: str | None = Field(default=None, validation_alias="gitBranch")
    tool_use_result: ToolUseResult | str | None = Field(
        default=None, validation_alias="toolUseResult"
    )
    is_sidechain: bool = Field(default=False, validation_alias="isSidechain")
    user_type: str | None = Field(default=None, validation_alias="userType")
    version: str | None = None
    agent_id: str | None = Field(default=None, validation_alias="agentId")
    request_id: str | None = Field(default=None, validation_alias="requestId")

    @model_validator(mode="before")
    @classmethod
    def select_message_type(cls, data: dict[str, object]) -> dict[str, object]:
        """Select the correct message type based on LogEntry.type field."""
        if isinstance(data, dict) and "type" in data and "message" in data:
            msg_type = data["type"]
            msg_data = data["message"]
            if isinstance(msg_data, dict):  # Only transform if it's raw dict data
                if msg_type == "user":
                    data["message"] = UserMessage.model_validate(msg_data)
                elif msg_type == "assistant":
                    data["message"] = AssistantMessage.model_validate(msg_data)
                elif msg_type == "system":
                    data["message"] = SystemMessage.model_validate(msg_data)
        return data
