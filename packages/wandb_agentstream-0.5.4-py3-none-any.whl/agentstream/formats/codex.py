"""Codex CLI format types."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict


class CodexGitInfo(BaseModel):
    """Git information from Codex session."""

    model_config = ConfigDict(extra="ignore")

    commit_hash: str
    branch: str


class CodexSessionMeta(BaseModel):
    """Codex session metadata payload."""

    model_config = ConfigDict(extra="ignore")

    id: str
    timestamp: str
    cwd: str
    originator: str
    cli_version: str
    instructions: str | None = None
    source: str | None = None
    model_provider: str | None = None
    git: CodexGitInfo | None = None


class CodexContentBlock(BaseModel):
    """Content block in a Codex message."""

    model_config = ConfigDict(extra="ignore")

    type: str  # "input_text", "output_text", etc.
    text: str | None = None


class CodexReasoningSummary(BaseModel):
    """Summary entry in Codex reasoning."""

    model_config = ConfigDict(extra="ignore")

    type: Literal["summary_text"]
    text: str


class CodexLogEntry(BaseModel):
    """A single line from Codex's JSONL log."""

    model_config = ConfigDict(extra="ignore")

    timestamp: str
    type: Literal["session_meta", "response_item", "event_msg", "turn_context"]
    payload: dict[str, Any]
