# agentstream/__init__.py
"""Agentstream - Read, transform, and write AI agent session logs."""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

from .adapters.base import Session
from .analytics import (
    build_session_summary,
    calculate_active_duration_ms,
    generate_event_id,
    generate_session_id,
    is_internal_session,
)
from .events import CustomEvent, Event, EventType, Role
from .git_utils import (
    find_git_root,
    get_git_commit_sha,
    resolve_git_repo,
)
from .grouper import MessageGroup, group_events
from .normalization import (
    UnifiedDiff,
    UnifiedFileOperation,
    UnifiedSkill,
    UnifiedTodo,
    get_normalizer,
)
from .normalization.synthetic import SESSION_METADATA
from .registry import all_adapters, get_adapter, register

# Remote session discovery
from .remote import (
    ClaudeCredentials,
    WebSession,
    WebSessionPoller,
    WebSessionsClient,
    has_claude_credentials,
    read_claude_credentials,
)


def discover_sessions(project_dir: Path | str = ".") -> list[Session]:
    """Discover all agent sessions across all formats."""
    project_dir = Path(project_dir)
    sessions: list[Session] = []
    for adapter in all_adapters():
        sessions.extend(adapter.discover_sessions(project_dir))
    return sorted(sessions, key=lambda s: s.modified_at, reverse=True)


def read_events(session: Session) -> Iterator[Event]:
    """Read events from a session (auto-detects format)."""
    adapter = get_adapter(session.format)
    if not adapter:
        raise ValueError(f"Unknown format: {session.format}")
    return adapter.read_events(session)


def read_events_normalized(session: Session) -> Iterator[Event]:
    """Read events with normalization, including SESSION_METADATA.

    This function reads events from a session and generates a SESSION_METADATA
    custom event with metadata extracted from source entries and git info
    resolved from the filesystem.

    Use this instead of read_events() when you need:
    - Session metadata (cwd, git_branch, git_repo, model, version)
    - Consistent behavior with the server-side normalization pipeline

    Args:
        session: Session to read from.

    Yields:
        Events from the session, with SESSION_METADATA as the first custom event.
    """
    adapter = get_adapter(session.format)
    if not adapter:
        raise ValueError(f"Unknown format: {session.format}")

    normalizer = get_normalizer(session.format, "1.0.0")

    # Read all events and collect source entries
    events_list: list[Event] = []
    source_entries: list[dict] = []

    for event in adapter.read_events(session):
        events_list.append(event)

        # Collect source_entry events for metadata extraction
        if isinstance(event, CustomEvent) and event.name == "source_entry":
            value = event.value
            if isinstance(value, dict) and "raw_line" in value:
                source_entries.append(
                    {
                        "entry_content": value["raw_line"],
                        "entry_timestamp_ms": event.timestamp_ms,
                        "entry_index": value.get("index", 0),
                    }
                )

    # Extract session metadata from source entries
    session_meta = None
    if source_entries and normalizer:
        session_meta = normalizer.extract_session_metadata(source_entries, None)

    # Resolve git info from filesystem if we have cwd
    git_repo = ""
    git_commit = ""
    cwd = ""

    if session_meta and session_meta.cwd:
        cwd = session_meta.cwd
        git_repo = resolve_git_repo(cwd) or ""
        git_root = find_git_root(cwd)
        if git_root:
            git_commit = get_git_commit_sha(git_root) or ""

    # Create SESSION_METADATA custom event
    if session_meta:
        timestamp_ms = int(session_meta.timestamp.timestamp() * 1000)
        metadata_event = CustomEvent(
            timestamp_ms=timestamp_ms,
            name=SESSION_METADATA,
            value={
                "data": {
                    "cwd": cwd or session_meta.cwd or "",
                    "agent_type": session_meta.agent_type or "",
                    "agent_version": session_meta.agent_version or "",
                    "git_branch": session_meta.git_branch or "",
                    "git_commit": git_commit,
                    "git_repo": git_repo,
                    "primary_model": session_meta.primary_model or "",
                }
            },
        )
        yield metadata_event

    # Yield all other events
    yield from events_list


def read_messages(session: Session) -> Iterator[MessageGroup]:
    """Read session as grouped messages."""
    adapter = get_adapter(session.format)
    if not adapter:
        raise ValueError(f"Unknown format: {session.format}")
    return adapter.read_messages(session)


__all__ = [
    # Top-level API
    "discover_sessions",
    "read_events",
    "read_events_normalized",
    "read_messages",
    # Analytics
    "build_session_summary",
    "calculate_active_duration_ms",
    "generate_event_id",
    "generate_session_id",
    "is_internal_session",
    # Types
    "Session",
    "Event",
    "EventType",
    "Role",
    "MessageGroup",
    # Grouper
    "group_events",
    # Normalization
    "UnifiedTodo",
    "UnifiedFileOperation",
    "UnifiedSkill",
    "UnifiedDiff",
    "get_normalizer",
    # Registry
    "get_adapter",
    "all_adapters",
    "register",
    # Remote session discovery
    "ClaudeCredentials",
    "WebSession",
    "WebSessionPoller",
    "WebSessionsClient",
    "has_claude_credentials",
    "read_claude_credentials",
]
