# agentstream/events/reasoning.py
"""Reasoning/thinking event types for extended thinking blocks.

See: https://docs.ag-ui.com/drafts/reasoning
"""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from .base import BaseEvent, EventType


class ReasoningStartEvent(BaseEvent):
    """Marks the start of a reasoning/thinking phase."""

    type: Literal[EventType.REASONING_START] = EventType.REASONING_START
    message_id: str = Field(serialization_alias="messageId")


class ReasoningMessageStartEvent(BaseEvent):
    """Marks the start of a reasoning message stream."""

    type: Literal[EventType.REASONING_MESSAGE_START] = EventType.REASONING_MESSAGE_START
    message_id: str = Field(serialization_alias="messageId")
    role: Literal["assistant"] = "assistant"


class ReasoningMessageContentEvent(BaseEvent):
    """A chunk of reasoning content."""

    type: Literal[EventType.REASONING_MESSAGE_CONTENT] = EventType.REASONING_MESSAGE_CONTENT
    message_id: str = Field(serialization_alias="messageId")
    delta: str


class ReasoningMessageEndEvent(BaseEvent):
    """Marks the end of a reasoning message stream."""

    type: Literal[EventType.REASONING_MESSAGE_END] = EventType.REASONING_MESSAGE_END
    message_id: str = Field(serialization_alias="messageId")


class ReasoningEndEvent(BaseEvent):
    """Marks the end of the reasoning/thinking phase."""

    type: Literal[EventType.REASONING_END] = EventType.REASONING_END
    message_id: str = Field(serialization_alias="messageId")


class ReasoningMessageChunkEvent(BaseEvent):
    """Convenience event that auto-starts/closes reasoning messages.

    First chunk must include messageId. Subsequent chunks only need delta.
    The reasoning message is auto-closed when a new messageId is seen or
    the stream ends.
    """

    type: Literal[EventType.REASONING_MESSAGE_CHUNK] = EventType.REASONING_MESSAGE_CHUNK
    message_id: str | None = Field(default=None, serialization_alias="messageId")
    delta: str | None = None
