# agentstream/events/run.py
from __future__ import annotations

from typing import Literal

from pydantic import Field

from .base import BaseEvent, EventType


class RunStartedEvent(BaseEvent):
    """Emitted when an agent run begins.

    Note: Custom fields like `cwd` should be stored in `raw_event` for spec compliance.
    """

    type: Literal[EventType.RUN_STARTED] = EventType.RUN_STARTED
    thread_id: str = Field(serialization_alias="threadId")
    run_id: str = Field(serialization_alias="runId")
    parent_run_id: str | None = Field(default=None, serialization_alias="parentRunId")


class RunFinishedEvent(BaseEvent):
    """Emitted when an agent run completes successfully."""

    type: Literal[EventType.RUN_FINISHED] = EventType.RUN_FINISHED
    run_id: str = Field(serialization_alias="runId")


class RunErrorEvent(BaseEvent):
    """Emitted when an agent run fails with an error."""

    type: Literal[EventType.RUN_ERROR] = EventType.RUN_ERROR
    run_id: str = Field(serialization_alias="runId")
    message: str
