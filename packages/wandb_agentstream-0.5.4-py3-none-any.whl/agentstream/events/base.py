# agentstream/events/base.py
from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class EventType(StrEnum):
    """AG-UI protocol event types."""

    RUN_STARTED = "RUN_STARTED"
    RUN_FINISHED = "RUN_FINISHED"
    RUN_ERROR = "RUN_ERROR"
    # Full message lifecycle events
    TEXT_MESSAGE_START = "TEXT_MESSAGE_START"
    TEXT_MESSAGE_CONTENT = "TEXT_MESSAGE_CONTENT"
    TEXT_MESSAGE_END = "TEXT_MESSAGE_END"
    # Convenience chunk event (auto start/end)
    TEXT_MESSAGE_CHUNK = "TEXT_MESSAGE_CHUNK"
    # Full tool call lifecycle events
    TOOL_CALL_START = "TOOL_CALL_START"
    TOOL_CALL_ARGS = "TOOL_CALL_ARGS"
    TOOL_CALL_END = "TOOL_CALL_END"
    TOOL_CALL_RESULT = "TOOL_CALL_RESULT"
    # Convenience chunk event (auto start/end)
    TOOL_CALL_CHUNK = "TOOL_CALL_CHUNK"
    CUSTOM = "CUSTOM"
    # Full reasoning lifecycle events
    REASONING_START = "REASONING_START"
    REASONING_MESSAGE_START = "REASONING_MESSAGE_START"
    REASONING_MESSAGE_CONTENT = "REASONING_MESSAGE_CONTENT"
    REASONING_MESSAGE_END = "REASONING_MESSAGE_END"
    REASONING_END = "REASONING_END"
    # Convenience chunk event (auto start/end)
    REASONING_MESSAGE_CHUNK = "REASONING_MESSAGE_CHUNK"


class Role(StrEnum):
    """Message roles."""

    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


class BaseEvent(BaseModel):
    """Base class for all AG-UI events."""

    model_config = ConfigDict(extra="forbid")

    type: EventType
    timestamp_ms: int = Field(serialization_alias="timestamp")
