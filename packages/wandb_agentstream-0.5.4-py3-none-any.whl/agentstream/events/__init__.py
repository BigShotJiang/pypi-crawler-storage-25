"""AG-UI event types for agentstream."""

from __future__ import annotations

import re
from typing import Annotated, Any, Union

from pydantic import Discriminator, TypeAdapter

from .base import BaseEvent, EventType, Role
from .custom import CustomEvent
from .messages import (
    TextMessageChunkEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    TextMessageStartEvent,
)
from .reasoning import (
    ReasoningEndEvent,
    ReasoningMessageChunkEvent,
    ReasoningMessageContentEvent,
    ReasoningMessageEndEvent,
    ReasoningMessageStartEvent,
    ReasoningStartEvent,
)
from .run import RunErrorEvent, RunFinishedEvent, RunStartedEvent
from .tools import (
    ToolCallArgsEvent,
    ToolCallChunkEvent,
    ToolCallEndEvent,
    ToolCallResultEvent,
    ToolCallStartEvent,
)

# Discriminated union of all event types
# Using Union[] syntax for Pydantic Discriminator compatibility
Event = Annotated[
    Union[  # noqa: UP007
        RunStartedEvent,
        RunFinishedEvent,
        RunErrorEvent,
        # Full lifecycle events
        TextMessageStartEvent,
        TextMessageContentEvent,
        TextMessageEndEvent,
        # Chunk convenience event
        TextMessageChunkEvent,
        # Full lifecycle events
        ToolCallStartEvent,
        ToolCallArgsEvent,
        ToolCallEndEvent,
        ToolCallResultEvent,
        # Chunk convenience event
        ToolCallChunkEvent,
        # Full lifecycle events
        ReasoningStartEvent,
        ReasoningMessageStartEvent,
        ReasoningMessageContentEvent,
        ReasoningMessageEndEvent,
        ReasoningEndEvent,
        # Chunk convenience event
        ReasoningMessageChunkEvent,
        CustomEvent,
    ],
    Discriminator("type"),
]

# Type adapter for parsing Event from dict
_event_adapter: TypeAdapter[Event] = TypeAdapter(Event)


def _camel_to_snake(name: str) -> str:
    """Convert camelCase to snake_case."""
    return re.sub(r"(?<!^)(?=[A-Z])", "_", name).lower()


def _convert_keys_to_snake(data: dict[str, Any]) -> dict[str, Any]:
    """Convert dictionary keys from camelCase to snake_case."""
    # Special mappings for fields with different alias names
    alias_map = {
        "content": "result",  # TOOL_CALL_RESULT uses result internally
        "args": "delta",  # TOOL_CALL_ARGS uses delta internally
    }
    result = {}
    for key, value in data.items():
        snake_key = _camel_to_snake(key)
        # Apply special mappings
        if snake_key in alias_map:
            snake_key = alias_map[snake_key]
        result[snake_key] = value
    return result


def event_from_dict(data: dict[str, Any]) -> Event:
    """Parse an Event from a dictionary (handles camelCase keys)."""
    # Convert camelCase keys to snake_case
    snake_data = _convert_keys_to_snake(data)
    return _event_adapter.validate_python(snake_data)


__all__ = [
    # Enums
    "EventType",
    "Role",
    # Base
    "BaseEvent",
    # Run
    "RunStartedEvent",
    "RunFinishedEvent",
    "RunErrorEvent",
    # Messages (full lifecycle)
    "TextMessageStartEvent",
    "TextMessageContentEvent",
    "TextMessageEndEvent",
    # Messages (chunk convenience)
    "TextMessageChunkEvent",
    # Tools (full lifecycle)
    "ToolCallStartEvent",
    "ToolCallArgsEvent",
    "ToolCallEndEvent",
    "ToolCallResultEvent",
    # Tools (chunk convenience)
    "ToolCallChunkEvent",
    # Reasoning (full lifecycle)
    "ReasoningStartEvent",
    "ReasoningMessageStartEvent",
    "ReasoningMessageContentEvent",
    "ReasoningMessageEndEvent",
    "ReasoningEndEvent",
    # Reasoning (chunk convenience)
    "ReasoningMessageChunkEvent",
    # Custom
    "CustomEvent",
    # Union
    "Event",
    # Helpers
    "event_from_dict",
]
