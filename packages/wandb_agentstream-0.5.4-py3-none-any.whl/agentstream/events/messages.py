# agentstream/events/messages.py
from __future__ import annotations

from typing import Literal

from pydantic import Field

from .base import BaseEvent, EventType, Role


class TextMessageStartEvent(BaseEvent):
    """Emitted when a text message begins."""

    type: Literal[EventType.TEXT_MESSAGE_START] = EventType.TEXT_MESSAGE_START
    message_id: str = Field(serialization_alias="messageId")
    role: Role


class TextMessageContentEvent(BaseEvent):
    """Emitted for each chunk of text message content."""

    type: Literal[EventType.TEXT_MESSAGE_CONTENT] = EventType.TEXT_MESSAGE_CONTENT
    message_id: str = Field(serialization_alias="messageId")
    delta: str


class TextMessageEndEvent(BaseEvent):
    """Emitted when a text message completes."""

    type: Literal[EventType.TEXT_MESSAGE_END] = EventType.TEXT_MESSAGE_END
    message_id: str = Field(serialization_alias="messageId")


class TextMessageChunkEvent(BaseEvent):
    """Convenience event that auto-starts/closes text messages.

    First chunk must include messageId and role. Subsequent chunks
    only need delta. The message is auto-closed when a new messageId
    is seen or the stream ends.
    """

    type: Literal[EventType.TEXT_MESSAGE_CHUNK] = EventType.TEXT_MESSAGE_CHUNK
    message_id: str | None = Field(default=None, serialization_alias="messageId")
    role: Role | None = None
    delta: str | None = None
