# agentstream/events/custom.py
from __future__ import annotations

from typing import Any, Literal

from .base import BaseEvent, EventType


class CustomEvent(BaseEvent):
    """Custom event for protocol extensions (reasoning, file ops, etc.)."""

    type: Literal[EventType.CUSTOM] = EventType.CUSTOM
    name: str
    value: dict[str, Any]
