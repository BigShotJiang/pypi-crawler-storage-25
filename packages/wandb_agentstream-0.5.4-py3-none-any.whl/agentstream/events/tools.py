# agentstream/events/tools.py
from __future__ import annotations

from typing import Literal

from pydantic import Field

from .base import BaseEvent, EventType


class ToolCallStartEvent(BaseEvent):
    """Emitted when a tool call begins."""

    type: Literal[EventType.TOOL_CALL_START] = EventType.TOOL_CALL_START
    tool_call_id: str = Field(serialization_alias="toolCallId")
    tool_call_name: str = Field(serialization_alias="toolCallName")
    message_id: str | None = Field(default=None, serialization_alias="messageId")


class ToolCallArgsEvent(BaseEvent):
    """Emitted for streamed tool call arguments."""

    type: Literal[EventType.TOOL_CALL_ARGS] = EventType.TOOL_CALL_ARGS
    tool_call_id: str = Field(serialization_alias="toolCallId")
    delta: str = Field(serialization_alias="args")


class ToolCallEndEvent(BaseEvent):
    """Emitted when tool call arguments are complete."""

    type: Literal[EventType.TOOL_CALL_END] = EventType.TOOL_CALL_END
    tool_call_id: str = Field(serialization_alias="toolCallId")


class ToolCallResultEvent(BaseEvent):
    """Emitted with the result of a tool call."""

    type: Literal[EventType.TOOL_CALL_RESULT] = EventType.TOOL_CALL_RESULT
    tool_call_result_id: str = Field(serialization_alias="toolCallResultId")
    tool_call_id: str = Field(serialization_alias="toolCallId")
    result: str = Field(serialization_alias="content")
    is_error: bool = Field(default=False, serialization_alias="isError")


class ToolCallChunkEvent(BaseEvent):
    """Convenience event that auto-starts/closes tool calls.

    First chunk must include toolCallId and toolCallName. Subsequent chunks
    only need delta (for arguments). The tool call is auto-closed when a
    new toolCallId is seen or the stream ends.
    """

    type: Literal[EventType.TOOL_CALL_CHUNK] = EventType.TOOL_CALL_CHUNK
    tool_call_id: str | None = Field(default=None, serialization_alias="toolCallId")
    tool_call_name: str | None = Field(default=None, serialization_alias="toolCallName")
    parent_message_id: str | None = Field(default=None, serialization_alias="parentMessageId")
    delta: str | None = None
