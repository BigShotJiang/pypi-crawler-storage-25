# Mapify 

**A semantic codebase mapping engine for AI.**

Mapify is a CLI tool that instantly scans your project, parses the Abstract Syntax Trees (ASTs) of your code, and generates a rich Semantic Knowledge Graph. It analyzes how files, classes, and functions are connected to identify the "God Nodes" (the most important files in your architecture), giving you or your AI agents perfect context of how a codebase is wired together.

##  Supported Languages

Mapify uses lightning-fast `tree-sitter` and robust regex parsing to support:
* Python
* TypeScript / JavaScript
* Go
* Rust
* Java
* C / C++
* Ruby
* SQL
* Prisma

## Installation

Install globally using `pip` (or `pipx` for isolated environments):

```bash
pip install mapifyy-cli
```
## Usage 

Navigate into any codebase directory on your machine and run the Mapify engine

```bash
cd your-project-folder
mapify run .
```



Mapify will discover your files, parse them, and generate a mapify-out/ folder containing your Codebase Blueprint and Semantic Graph, ready to be fed into any LLM or MCP agent



## Note

ALways use .gitignore for better analysis
