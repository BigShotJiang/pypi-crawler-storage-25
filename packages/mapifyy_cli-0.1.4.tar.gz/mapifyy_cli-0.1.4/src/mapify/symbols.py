# src/mapify/symbols.py

from pathlib import Path


class SymbolTable:
    """
    Global semantic symbol registry.

    Responsible for:

    - Function ownership
    - Class ownership
    - Import resolution
    - Route resolution
    - Database model resolution
    """

    def __init__(self):

        # =================================================
        # GLOBAL SYMBOL REGISTRIES
        # =================================================

        self.functions = {}

        self.classes = {}

        self.modules = {}

        self.routes = {}

        self.models = {}

    # =====================================================
    # FUNCTION REGISTRATION
    # =====================================================

    def register_function(
        self,
        function_name: str,
        file_path: str
    ):

        node_id = (
            f"{file_path}::{function_name}"
        )

        self.functions[function_name] = {

            "file": file_path,

            "node_id": node_id,
        }

    # =====================================================
    # CLASS REGISTRATION
    # =====================================================

    def register_class(
        self,
        class_name: str,
        file_path: str
    ):

        node_id = (
            f"{file_path}::{class_name}"
        )

        self.classes[class_name] = {

            "file": file_path,

            "node_id": node_id,
        }

    # =====================================================
    # MODULE REGISTRATION
    # =====================================================

    def register_module(
        self,
        module_name: str,
        file_path: str
    ):

        self.modules[module_name] = {

            "file": file_path
        }

    # =====================================================
    # ROUTE REGISTRATION
    # =====================================================

    def register_route(
        self,
        route: str,
        file_path: str
    ):

        self.routes[route] = {

            "file": file_path,

            "node_id": f"route::{route}"
        }

    # =====================================================
    # DATABASE MODEL REGISTRATION
    # =====================================================

    def register_model(
        self,
        model_name: str,
        file_path: str
    ):

        self.models[model_name] = {

            "file": file_path,

            "node_id": f"model::{model_name}"
        }

    # =====================================================
    # FUNCTION RESOLUTION
    # =====================================================

    def resolve_function(
        self,
        function_name: str
    ):

        return self.functions.get(
            function_name
        )

    # =====================================================
    # CLASS RESOLUTION
    # =====================================================

    def resolve_class(
        self,
        class_name: str
    ):

        return self.classes.get(
            class_name
        )

    # =====================================================
    # MODULE RESOLUTION
    # =====================================================

    def resolve_module(
        self,
        module_name: str
    ):

        return self.modules.get(
            module_name
        )

    # =====================================================
    # ROUTE RESOLUTION
    # =====================================================

    def resolve_route(
        self,
        route: str
    ):

        return self.routes.get(
            route
        )

    # =====================================================
    # MODEL RESOLUTION
    # =====================================================

    def resolve_model(
        self,
        model_name: str
    ):

        return self.models.get(
            model_name
        )

    # =====================================================
    # FILE → MODULE CONVERSION
    # =====================================================

    def file_to_module(
        self,
        path: str
    ):

        """
        Convert:

        src/mapify/parser.py

        →

        mapify.parser
        """

        path = Path(path)

        parts = list(path.parts)

        if "src" in parts:

            src_index = parts.index("src")

            parts = parts[src_index + 1:]

        module = ".".join(parts)

        module = module.replace(".py", "")

        module = module.replace(
            ".__init__",
            ""
        )

        return module

    # =====================================================
    # AUTO REGISTER FILE SYMBOLS
    # =====================================================

    def register_file_symbols(
        self,
        file_path: str,
        file_info: dict
    ):

        # ---------------------------------------------
        # MODULE
        # ---------------------------------------------

        module_name = self.file_to_module(
            file_path
        )

        self.register_module(
            module_name,
            file_path
        )

        # ---------------------------------------------
        # FUNCTIONS
        # ---------------------------------------------

        for function_name in file_info.get(
            "functions",
            []
        ):

            self.register_function(
                function_name,
                file_path
            )

        # ---------------------------------------------
        # CLASSES
        # ---------------------------------------------

        for class_name in file_info.get(
            "classes",
            []
        ):

            self.register_class(
                class_name,
                file_path
            )

        # ---------------------------------------------
        # ROUTES
        # ---------------------------------------------

        for route in file_info.get(
            "routes",
            []
        ):

            self.register_route(
                route,
                file_path
            )

        # ---------------------------------------------
        # DATABASE MODELS
        # ---------------------------------------------

        for model in file_info.get(
            "database_reads",
            []
        ):

            self.register_model(
                model,
                file_path
            )

        for model in file_info.get(
            "database_writes",
            []
        ):

            self.register_model(
                model,
                file_path
            )

    # =====================================================
    # EXPORT ALL SYMBOLS
    # =====================================================

    def export(self):

        return {

            "functions":
                self.functions,

            "classes":
                self.classes,

            "modules":
                self.modules,

            "routes":
                self.routes,

            "models":
                self.models,
        }

    # =====================================================
    # STATS
    # =====================================================

    def stats(self):

        return {

            "functions":
                len(self.functions),

            "classes":
                len(self.classes),

            "modules":
                len(self.modules),

            "routes":
                len(self.routes),

            "models":
                len(self.models),
        }