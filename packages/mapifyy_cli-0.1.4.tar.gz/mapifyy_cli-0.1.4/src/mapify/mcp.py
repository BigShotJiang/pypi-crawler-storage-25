# src/mapify/mcp.py
import json
from pathlib import Path
from mcp.server.fastmcp import FastMCP

# Initialize the MCP server
# FastMCP automatically inspects the type hints and docstrings to tell the AI how to use these tools.
mcp = FastMCP("Mapify")

def load_blueprint() -> dict:
    """Helper to load the generated JSON blueprint."""
    path = Path("mapify-out/codebase_blueprint.json")
    if not path.exists():
        return {"error": "Blueprint not found. Run 'mapify run .' first."}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def load_graph() -> dict:
    """Helper to load the NetworkX node-link graph."""
    path = Path("mapify-out/semantic_graph.json")
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

@mcp.tool()
def get_project_summary() -> str:
    """Get a high-level summary of the codebase, including a list of all mapped files."""
    data = load_blueprint()
    if "error" in data: 
        return data["error"]
    
    files = list(data.get("files", {}).keys())
    summary = {
        "project_root": data.get("project_root"),
        "total_files_mapped": len(files),
        "mapped_files": files
    }
    return json.dumps(summary, indent=2)

@mcp.tool()
def get_file_details(file_path: str) -> str:
    """
    Get the extracted architectural details (classes, functions, imports) for a specific file.
    Use get_project_summary first to see valid file paths.
    """
    data = load_blueprint()
    if "error" in data: 
        return data["error"]
    
    files = data.get("files", {})
    if file_path not in files:
        return f"File '{file_path}' not found in the blueprint."
        
    return json.dumps(files[file_path], indent=2)

@mcp.tool()
def get_node_dependencies(node_id: str) -> str:
    """
    Find what a file or class depends on, and what depends on it.
    node_id should be a file path (e.g., 'src/main.py') or a specific entity.
    """
    graph_data = load_graph()
    if not graph_data: 
        return "Semantic graph not found. Run 'mapify run .' first."
    
    links = graph_data.get("links", [])
    # Find all edges where this node is either the source or the target
    dependencies = [
        link for link in links 
        if link.get("source") == node_id or link.get("target") == node_id
    ]
    
    if not dependencies:
        return f"No dependencies found in the graph for: {node_id}"
        
    return json.dumps(dependencies, indent=2)

def serve():
    """Starts the standard input/output MCP server."""
    mcp.run()