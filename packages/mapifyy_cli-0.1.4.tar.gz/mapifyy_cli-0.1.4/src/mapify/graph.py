# src/mapify/graph.py

import json
from pathlib import Path

import networkx as nx

from mapify.resolver import ResolutionEngine


class SemanticGraph:

    """
    Semantic execution graph engine.

    =====================================================
    NODE TYPES
    =====================================================

    - file
    - class
    - function
    - module
    - api
    - state
    - route
    - database_model

    =====================================================
    RELATIONSHIPS
    =====================================================

    - contains
    - imports
    - calls
    - calls_api
    - uses_state
    - defines_route
    - reads
    - writes
    """

 

    def __init__(
        self,
        blueprint_data: dict,
        symbol_table
    ):

        self.data = blueprint_data

        self.symbol_table = symbol_table

        self.resolver = ResolutionEngine(
            symbol_table
        )

        self.G = nx.DiGraph()

    

    def build(self):

        files_data = self.data.get(
            "files",
            {}
        )

      

        for file_path, file_info in files_data.items():

            

            self.G.add_node(
                file_path,
                type="file",
                label=file_path,
            )

            # ---------------------------------------------
            # CLASS NODES
            # ---------------------------------------------

            for cls in file_info.get(
                "classes",
                []
            ):

                class_node_id = (
                    f"{file_path}::{cls}"
                )

                self.G.add_node(
                    class_node_id,
                    type="class",
                    label=cls,
                    file=file_path,
                )

                self.G.add_edge(
                    file_path,
                    class_node_id,
                    relationship="contains",
                )

           

            for func in file_info.get(
                "functions",
                []
            ):

                function_node_id = (
                    f"{file_path}::{func}"
                )

                self.G.add_node(
                    function_node_id,
                    type="function",
                    label=func,
                    file=file_path,
                )

                self.G.add_edge(
                    file_path,
                    function_node_id,
                    relationship="contains",
                )

        # =================================================
        # STEP 2
        # RESOLVED IMPORTS
        # =================================================

        for file_path, file_info in files_data.items():

            for imp in file_info.get(
                "imports",
                []
            ):

                resolved_import = (
                    self.resolver.resolve_import(
                        imp
                    )
                )

                # -----------------------------------------
                # INTERNAL IMPORT
                # -----------------------------------------

                if resolved_import:

                    self.G.add_edge(
                        file_path,
                        resolved_import,
                        relationship="imports",
                    )

                # -----------------------------------------
                # EXTERNAL MODULE
                # -----------------------------------------

                else:

                    module_node_id = (
                        f"module::{imp}"
                    )

                    if not self.G.has_node(
                        module_node_id
                    ):

                        self.G.add_node(
                            module_node_id,
                            type="module",
                            label=imp,
                        )

                    self.G.add_edge(
                        file_path,
                        module_node_id,
                        relationship="imports",
                    )

       

        for file_path, file_info in files_data.items():

            for call in file_info.get(
                "calls",
                []
            ):

                resolved_function = (
                    self.resolver.resolve_function_call(
                        call
                    )
                )


                if resolved_function:

                    self.G.add_edge(
                        file_path,
                        resolved_function,
                        relationship="calls",
                    )


        for file_path, file_info in files_data.items():

            for api in file_info.get(
                "api_calls",
                []
            ):

                api_node_id = (
                    f"api::{api}"
                )

                if not self.G.has_node(
                    api_node_id
                ):

                    self.G.add_node(
                        api_node_id,
                        type="api",
                        label=api,
                    )

                self.G.add_edge(
                    file_path,
                    api_node_id,
                    relationship="calls_api",
                )

        # =================================================
        # STEP 5
        # STATE FLOW
        # =================================================

        for file_path, file_info in files_data.items():

            for state in file_info.get(
                "states",
                []
            ):

                state_node_id = (
                    f"state::{state}"
                )

                if not self.G.has_node(
                    state_node_id
                ):

                    self.G.add_node(
                        state_node_id,
                        type="state",
                        label=state,
                    )

                self.G.add_edge(
                    file_path,
                    state_node_id,
                    relationship="uses_state",
                )

        # =================================================
        # STEP 6
        # ROUTES
        # =================================================

        for file_path, file_info in files_data.items():

            for route in file_info.get(
                "routes",
                []
            ):

                route_node_id = (
                    f"route::{route}"
                )

                if not self.G.has_node(
                    route_node_id
                ):

                    self.G.add_node(
                        route_node_id,
                        type="route",
                        label=route,
                    )

                self.G.add_edge(
                    file_path,
                    route_node_id,
                    relationship="defines_route",
                )

        # =================================================
        # STEP 7
        # DATABASE RELATIONSHIPS
        # =================================================

        for file_path, file_info in files_data.items():

            # ---------------------------------------------
            # READS
            # ---------------------------------------------

            for model in file_info.get(
                "database_reads",
                []
            ):

                model_node_id = (
                    f"model::{model}"
                )

                if not self.G.has_node(
                    model_node_id
                ):

                    self.G.add_node(
                        model_node_id,
                        type="database_model",
                        label=model,
                    )

                self.G.add_edge(
                    file_path,
                    model_node_id,
                    relationship="reads",
                )

            # ---------------------------------------------
            # WRITES
            # ---------------------------------------------

            for model in file_info.get(
                "database_writes",
                []
            ):

                model_node_id = (
                    f"model::{model}"
                )

                if not self.G.has_node(
                    model_node_id
                ):

                    self.G.add_node(
                        model_node_id,
                        type="database_model",
                        label=model,
                    )

                self.G.add_edge(
                    file_path,
                    model_node_id,
                    relationship="writes",
                )

        return self.G

    # =====================================================
    # PAGE RANK
    # =====================================================

    def get_god_nodes(
        self,
        top_n: int = 5
    ):

        if len(self.G.nodes) == 0:

            return []

        try:

            scores = nx.pagerank(
                self.G
            )

        except Exception:

            scores = nx.degree_centrality(
                self.G
            )

        sorted_nodes = sorted(
            scores.items(),
            key=lambda x: x[1],
            reverse=True,
        )

        results = []

        for node, score in sorted_nodes[:top_n]:

            node_data = self.G.nodes[node]

            results.append({

                "id": node,

                "label": node_data.get(
                    "label",
                    ""
                ),

                "type": node_data.get(
                    "type",
                    "unknown"
                ),

                "score": round(score, 4),
            })

        return results

    # =====================================================
    # EXPORT JSON
    # =====================================================

    def export_json(
        self,
        out_path: Path
    ):

        out_path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        data = nx.node_link_data(
            self.G,
            edges="links"
        )

        with open(
            out_path,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(
                data,
                f,
                indent=2,
                ensure_ascii=False,
            )

    # =====================================================
    # EXPORT GRAPHML
    # =====================================================

    def export_graphml(
        self,
        out_path: Path
    ):

        out_path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        nx.write_graphml(
            self.G,
            out_path
        )

    # =====================================================
    # STATS
    # =====================================================

    def stats(self):

        return {

            "total_nodes":
                self.G.number_of_nodes(),

            "total_edges":
                self.G.number_of_edges(),

            "graph_type":
                "Directed",
        }

    # =====================================================
    # NODE BREAKDOWN
    # =====================================================

    def node_breakdown(self):

        breakdown = {}

        for _, data in self.G.nodes(data=True):

            node_type = data.get(
                "type",
                "unknown"
            )

            breakdown[node_type] = (
                breakdown.get(node_type, 0) + 1
            )

        return breakdown

    # =====================================================
    # EXECUTION SUMMARY
    # =====================================================

    def execution_summary(self):

        summary = {

            "routes": [],

            "api_calls": [],

            "database_models": [],

            "states": [],

            "functions": [],
        }

        for _, data in self.G.nodes(data=True):

            node_type = data.get("type")

            if node_type == "route":

                summary["routes"].append(
                    data.get("label")
                )

            elif node_type == "api":

                summary["api_calls"].append(
                    data.get("label")
                )

            elif node_type == "database_model":

                summary["database_models"].append(
                    data.get("label")
                )

            elif node_type == "state":

                summary["states"].append(
                    data.get("label")
                )

            elif node_type == "function":

                summary["functions"].append(
                    data.get("label")
                )

        return summary