import json
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TaskProgressColumn,
)

from mapify.parser import ASTExtractor
from mapify.utils.file_ops import find_valid_files, calculate_file_hash
from mapify.graph import SemanticGraph
from mapify.symbols import SymbolTable

app = typer.Typer(
    name="mapify",
    help="Turn your codebase into a semantic knowledge graph for AI.",
    add_completion=False,
)

console = Console()

@app.command("run")
def run_mapify(
    path: str = typer.Argument(".", help="Directory to map"),
    output: str = typer.Option("mapify-out/codebase_blueprint.json", help="Output JSON path"),
):
    """
    Scan repository and generate:
    - semantic blueprint
    - execution graph
    - symbol table
    """
    root_dir = Path(path).resolve()
    out_path = Path(output).resolve()

    console.print(
        Panel.fit(
            f"[bold blue]Mapify Engine[/bold blue] 🗺️\n"
            f"Target: [green]{root_dir}[/green]"
        )
    )

    with console.status("[bold yellow]Scanning directory and applying .gitignore rules...[/bold yellow]"):
        valid_files = find_valid_files(root_dir)

    if not valid_files:
        console.print("[bold red]No supported code files found.[/bold red]")
        raise typer.Exit(1)

    console.print(f"[bold green]✔[/bold green] Discovered [bold cyan]{len(valid_files)}[/bold cyan] valid files.")

    extractor = ASTExtractor()
    symbol_table = SymbolTable()

    blueprint_data = {
        "project_root": str(root_dir),
        "files": {},
    }

    # =====================================================
    # STEP 3: AST EXTRACTION
    # =====================================================
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        
        task = progress.add_task("[cyan]Extracting AST nodes...", total=len(valid_files))

        for file_path in valid_files:
            # RELATIVE PATH
            rel_path = file_path.relative_to(root_dir)
            rel_path_str = str(rel_path)

            # PARSE FILE
            extracted_data = extractor.parse_file(file_path)

            # BUILD BLUEPRINT
            blueprint_data["files"][rel_path_str] = {
                "hash": calculate_file_hash(file_path),
                "classes": extracted_data["classes"],
                "functions": extracted_data["functions"],
                "imports": extracted_data["imports"],
                "calls": extracted_data["calls"],
                "api_calls": extracted_data["api_calls"],
                "states": extracted_data["states"],
                "routes": extracted_data["routes"],
                "database_reads": extracted_data["database_reads"],
                "database_writes": extracted_data["database_writes"],
            }

            # REGISTER SYMBOLS
            symbol_table.register_file_symbols(
                rel_path_str,
                blueprint_data["files"][rel_path_str]
            )

            progress.advance(task)

    # =====================================================
    # STEP 4: EXPORT RAW BLUEPRINT
    # =====================================================
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(blueprint_data, f, indent=2, ensure_ascii=False)

    # =====================================================
    # STEP 5: EXPORT SYMBOL TABLE
    # =====================================================
    symbol_path = out_path.parent / "symbol_table.json"

    with open(symbol_path, "w", encoding="utf-8") as f:
        json.dump(symbol_table.export(), f, indent=2, ensure_ascii=False)

    # =====================================================
    # STEP 6: BUILD SEMANTIC GRAPH
    # =====================================================
    with console.status("[bold yellow]Building Semantic Graph...[/bold yellow]"):
        graph_engine = SemanticGraph(blueprint_data, symbol_table)
        graph_engine.build()

    # =====================================================
    # STEP 7: EXPORT GRAPH
    # =====================================================
    graph_json_path = out_path.parent / "semantic_graph.json"
    graph_graphml_path = out_path.parent / "semantic_graph.graphml"

    graph_engine.export_json(graph_json_path)
    graph_engine.export_graphml(graph_graphml_path)

    # =====================================================
    # SUCCESS OUTPUT
    # =====================================================
    console.print("\n[bold green]✔ Knowledge Graph generated successfully![/bold green]")
    console.print(f"Saved to: [bold cyan]{out_path.parent}[/bold cyan]")

# =========================================================
# MCP SERVER
# =========================================================
@app.command("serve")
def serve_mcp():
    """
    Start MCP server.
    Used internally by:
    - Cursor
    - Claude Desktop
    - IDE integrations
    """
    from mapify.mcp import serve
    serve()

# =========================================================
# ENTRYPOINT
# =========================================================
def main():
    app()

if __name__ == "__main__":
    main()