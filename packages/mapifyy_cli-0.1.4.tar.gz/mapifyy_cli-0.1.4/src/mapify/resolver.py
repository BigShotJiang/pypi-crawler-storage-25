# src/mapify/resolver.py

class ResolutionEngine:

    def __init__(self, symbol_table):

        self.symbol_table = symbol_table

    # =====================================================
    # FUNCTION RESOLUTION
    # =====================================================

    def resolve_function_call(
        self,
        function_name: str
    ):

        """
        Resolve:

        parse_file

        →

        src/mapify/parser.py::parse_file
        """

        resolved = (
            self.symbol_table.resolve_function(
                function_name
            )
        )

        if not resolved:
            return None

        return resolved["node_id"]

    # =====================================================
    # MODULE RESOLUTION
    # =====================================================

    def resolve_import(
        self,
        module_name: str
    ):

        resolved = (
            self.symbol_table.resolve_module(
                module_name
            )
        )

        if not resolved:
            return None

        return resolved["file"]