# src/mapify/utils/file_ops.py
import os
import hashlib
from pathlib import Path
import pathspec

# Default directories that should ALWAYS be ignored to save time, 
# even if they aren't explicitly in the user's .gitignore.
DEFAULT_IGNORES = [
    ".git/",
    "node_modules/",
    "venv/",
    ".venv/",
    "__pycache__/",
    "build/",
    "dist/",
    ".next/",
    ".cache/",
    "coverage/"
]

# Extensions that Mapify's Tree-sitter engine currently supports
SUPPORTED_EXTENSIONS = {".py", ".ts", ".tsx", ".js", ".jsx"}

def get_ignore_spec(root_dir: Path) -> pathspec.PathSpec:
    """Reads .gitignore and combines it with default ignores into a PathSpec."""
    patterns = list(DEFAULT_IGNORES)
    
    gitignore_path = root_dir / ".gitignore"
    if gitignore_path.exists():
        with open(gitignore_path, "r", encoding="utf-8") as f:
            # Add all non-empty lines from .gitignore
            patterns.extend(line.strip() for line in f if line.strip() and not line.startswith("#"))
            
    # Compile the gitignore style patterns
    return pathspec.PathSpec.from_lines("gitwildmatch", patterns)

def calculate_file_hash(file_path: Path) -> str:
    """
    Calculates the MD5 hash of a file. 
    We will use this later to power the caching layer, so Mapify 
    only re-parses files that have actually changed since the last run.
    """
    hasher = hashlib.md5()
    try:
        with open(file_path, "rb") as f:
            # Read in chunks for memory safety on massive files
            for chunk in iter(lambda: f.read(4096), b""):
                hasher.update(chunk)
    except Exception:
        return ""
    return hasher.hexdigest()

def find_valid_files(root_dir: str | Path) -> list[Path]:
    """
    Recursively scans the directory, applies .gitignore rules, 
    and returns a list of supported files.
    """
    root_path = Path(root_dir).resolve()
    spec = get_ignore_spec(root_path)
    
    valid_files = []
    
    # We use os.walk because it allows us to mutate the 'dirs' list in-place
    # to completely skip walking down ignored directories (massive speedup).
    for dirpath, dirnames, filenames in os.walk(root_path):
        current_dir = Path(dirpath)
        
        # Calculate path relative to root for gitignore matching
        try:
            rel_dir = current_dir.relative_to(root_path)
        except ValueError:
            continue

        # 1. Filter out ignored directories in-place!
        # If a directory is ignored, we remove it from `dirnames` so os.walk skips it.
        dirs_to_keep = []
        for d in dirnames:
            dir_rel_path = rel_dir / d
            # Append trailing slash so pathspec knows it's a directory
            if not spec.match_file(f"{dir_rel_path}/"):
                dirs_to_keep.append(d)
        
        # Mutate the list in-place (this is a feature of os.walk)
        dirnames[:] = dirs_to_keep

        # 2. Filter files
        for f in filenames:
            file_path = current_dir / f
            
            # Skip unsupported file extensions early
            if file_path.suffix not in SUPPORTED_EXTENSIONS:
                continue
                
            file_rel_path = rel_dir / f
            
            # Skip files matching .gitignore
            if spec.match_file(str(file_rel_path)):
                continue
                
            valid_files.append(file_path)

    return valid_files

# Quick local test block
if __name__ == "__main__":
    from rich import print
    
    # Let's test it on the root of our mapify project
    project_root = Path(__file__).parent.parent.parent.parent
    
    print(f"[bold blue]--- Scanning Directory: {project_root.name} ---[/bold blue]")
    files = find_valid_files(project_root)
    
    print(f"[bold green]Found {len(files)} valid code files:[/bold green]")
    for file in files:
        # Print path relative to root so it's easy to read
        print(f" - {file.relative_to(project_root)}")