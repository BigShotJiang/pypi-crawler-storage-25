# src/mapify/parser.py

import re
from pathlib import Path
from tree_sitter import Language, Parser, QueryCursor

# =========================================================
# TREE-SITTER LANGUAGE IMPORTS
# =========================================================

import tree_sitter_python as tspython
import tree_sitter_typescript as tstypescript
import tree_sitter_javascript as tsjavascript
import tree_sitter_go as tsgo
import tree_sitter_rust as tsrust
import tree_sitter_ruby as tsruby
import tree_sitter_java as tsjava
import tree_sitter_c as tsc
import tree_sitter_cpp as tscpp

# =========================================================
# INITIALIZE LANGUAGES
# =========================================================

PY_LANGUAGE = Language(tspython.language())

TS_LANGUAGE = Language(
    tstypescript.language_typescript()
)

TSX_LANGUAGE = Language(
    tstypescript.language_tsx()
)

JS_LANGUAGE = Language(
    tsjavascript.language()
)

GO_LANGUAGE = Language(
    tsgo.language()
)

RUST_LANGUAGE = Language(
    tsrust.language()
)

RUBY_LANGUAGE = Language(
    tsruby.language()
)

JAVA_LANGUAGE = Language(
    tsjava.language()
)

C_LANGUAGE = Language(
    tsc.language()
)

CPP_LANGUAGE = Language(
    tscpp.language()
)

# =========================================================
# TREE-SITTER QUERIES
# =========================================================

PYTHON_QUERIES = """
(class_definition name: (identifier) @class.name)

(function_definition name: (identifier) @function.name)

(import_statement
    name: (dotted_name) @import.name)

(import_from_statement
    module_name: (dotted_name) @import.module)
"""

TYPESCRIPT_QUERIES = """
(class_declaration
    name: (_) @class.name)

(function_declaration
    name: (_) @function.name)

(lexical_declaration
    (variable_declarator
        name: (_) @function.name
        value: [
            (arrow_function)
            (function_expression)
        ]
    )
)

(import_statement
    source: (_) @import.source)
"""

GO_QUERIES = """
(type_declaration
    (type_spec name: (_) @class.name))

(function_declaration
    name: (_) @function.name)

(method_declaration
    name: (_) @function.name)

(import_spec
    path: (_) @import.source)
"""

RUST_QUERIES = """
(struct_item
    name: (_) @class.name)

(enum_item
    name: (_) @class.name)

(function_item
    name: (_) @function.name)

(use_declaration) @import.source
"""

RUBY_QUERIES = """
(class name: (_) @class.name)

(method name: (_) @function.name)
"""

JAVA_QUERIES = """
(class_declaration
    name: (_) @class.name)

(method_declaration
    name: (_) @function.name)
"""

C_QUERIES = """
(struct_specifier
    name: (_) @class.name)

(function_definition
    declarator: (_) @function.name)
"""

CPP_QUERIES = """
(struct_specifier
    name: (_) @class.name)

(class_specifier
    name: (_) @class.name)

(function_definition
    declarator: (_) @function.name)
"""

# =========================================================
# AST EXTRACTOR
# =========================================================


class ASTExtractor:

    def __init__(self):

        # -------------------------------------------------
        # PARSERS
        # -------------------------------------------------

        self.parsers = {
            ".py": Parser(PY_LANGUAGE),

            ".ts": Parser(TS_LANGUAGE),

            ".tsx": Parser(TSX_LANGUAGE),

            ".js": Parser(JS_LANGUAGE),

            ".jsx": Parser(JS_LANGUAGE),

            ".go": Parser(GO_LANGUAGE),

            ".rs": Parser(RUST_LANGUAGE),

            ".rb": Parser(RUBY_LANGUAGE),

            ".java": Parser(JAVA_LANGUAGE),

            ".c": Parser(C_LANGUAGE),

            ".cpp": Parser(CPP_LANGUAGE),

            ".h": Parser(C_LANGUAGE),

            ".hpp": Parser(CPP_LANGUAGE),
        }

        # -------------------------------------------------
        # QUERIES
        # -------------------------------------------------

        self.queries = {
            ".py": PY_LANGUAGE.query(PYTHON_QUERIES),

            ".ts": TS_LANGUAGE.query(TYPESCRIPT_QUERIES),

            ".tsx": TSX_LANGUAGE.query(TYPESCRIPT_QUERIES),

            ".js": JS_LANGUAGE.query(TYPESCRIPT_QUERIES),

            ".jsx": JS_LANGUAGE.query(TYPESCRIPT_QUERIES),

            ".go": GO_LANGUAGE.query(GO_QUERIES),

            ".rs": RUST_LANGUAGE.query(RUST_QUERIES),

            ".rb": RUBY_LANGUAGE.query(RUBY_QUERIES),

            ".java": JAVA_LANGUAGE.query(JAVA_QUERIES),

            ".c": C_LANGUAGE.query(C_QUERIES),

            ".cpp": CPP_LANGUAGE.query(CPP_QUERIES),

            ".h": C_LANGUAGE.query(C_QUERIES),

            ".hpp": CPP_LANGUAGE.query(CPP_QUERIES),
        }

    # =====================================================
    # PRISMA PARSER
    # =====================================================

    def _parse_prisma_regex(
        self,
        path: Path,
        code_bytes: bytes
    ) -> dict:

        text = code_bytes.decode(
            "utf8",
            errors="ignore"
        )

        models = re.findall(
            r'model\s+([A-Za-z0-9_]+)',
            text
        )

        return {
            "file": str(path),

            "classes": models,

            "functions": [],

            "imports": [],

            "calls": [],

            "api_calls": [],

            "states": [],

            "routes": [],

            "database_reads": [],

            "database_writes": [],
        }

    # =====================================================
    # SQL PARSER
    # =====================================================

    def _parse_sql_regex(
        self,
        path: Path,
        code_bytes: bytes
    ) -> dict:

        text = code_bytes.decode(
            "utf8",
            errors="ignore"
        )

        tables = re.findall(
            r'(?i)create\s+table\s+(?:if\s+not\s+exists\s+)?([a-zA-Z0-9_]+)',
            text
        )

        return {
            "file": str(path),

            "classes": tables,

            "functions": [],

            "imports": [],

            "calls": [],

            "api_calls": [],

            "states": [],

            "routes": [],

            "database_reads": [],

            "database_writes": [],
        }

    # =====================================================
    # FUNCTION CALL DETECTION
    # =====================================================

    def _extract_function_calls(
        self,
        code_text: str
    ) -> set:

        calls = set()

        patterns = [
            r'([A-Za-z_][A-Za-z0-9_]*)\('
        ]

        ignored = {
            "if",
            "for",
            "while",
            "switch",
            "catch",
            "return",
            "print",
            "len",
            "range",
            "map",
            "filter",
            "set",
            "list",
            "dict",
        }

        for pattern in patterns:

            matches = re.findall(
                pattern,
                code_text
            )

            for match in matches:

                if match not in ignored:
                    calls.add(match)

        return calls

    # =====================================================
    # API CALL DETECTION
    # =====================================================

    def _extract_api_calls(
        self,
        code_text: str
    ) -> set:

        api_calls = set()

        patterns = [

            r'fetch\([\'"](.+?)[\'"]',

            r'axios\.(?:get|post|put|delete)\([\'"](.+?)[\'"]',
        ]

        for pattern in patterns:

            matches = re.findall(
                pattern,
                code_text
            )

            for match in matches:
                api_calls.add(match)

        return api_calls

    # =====================================================
    # REACT STATE DETECTION
    # =====================================================

    def _extract_state_hooks(
        self,
        code_text: str
    ) -> set:

        states = set()

        matches = re.findall(
            r'const\s+\[(.*?)\,',
            code_text
        )

        for match in matches:
            states.add(match.strip())

        return states

    # =====================================================
    # ROUTE DETECTION
    # =====================================================

    def _extract_routes(
        self,
        path: Path
    ) -> set:

        routes = set()

        path_str = str(path)

        # ---------------------------------------------
        # NEXT.JS APP ROUTES
        # ---------------------------------------------

        if "app/" in path_str and "page." in path_str:

            route = (
                path_str
                .split("app/")[-1]
                .replace("/page.tsx", "")
                .replace("/page.jsx", "")
                .replace("/page.js", "")
                .replace("/page.ts", "")
            )

            route = "/" + route.strip("/")

            if route == "/":
                routes.add("/")

            else:
                routes.add(route)

        return routes

    # =====================================================
    # DATABASE OP DETECTION
    # =====================================================

    def _extract_database_ops(
        self,
        code_text: str
    ):

        reads = set()

        writes = set()

        # ---------------------------------------------
        # READ PATTERNS
        # ---------------------------------------------

        read_patterns = [

            r'([A-Za-z_][A-Za-z0-9_]*)\.find',

            r'([A-Za-z_][A-Za-z0-9_]*)\.findMany',

            r'([A-Za-z_][A-Za-z0-9_]*)\.query',

            r'([A-Za-z_][A-Za-z0-9_]*)\.select',
        ]

        # ---------------------------------------------
        # WRITE PATTERNS
        # ---------------------------------------------

        write_patterns = [

            r'([A-Za-z_][A-Za-z0-9_]*)\.create',

            r'([A-Za-z_][A-Za-z0-9_]*)\.update',

            r'([A-Za-z_][A-Za-z0-9_]*)\.delete',

            r'([A-Za-z_][A-Za-z0-9_]*)\.insert',
        ]

        # ---------------------------------------------
        # READ EXTRACTION
        # ---------------------------------------------

        for pattern in read_patterns:

            matches = re.findall(
                pattern,
                code_text
            )

            for match in matches:
                reads.add(match)

        # ---------------------------------------------
        # WRITE EXTRACTION
        # ---------------------------------------------

        for pattern in write_patterns:

            matches = re.findall(
                pattern,
                code_text
            )

            for match in matches:
                writes.add(match)

        return reads, writes

    # =====================================================
    # MAIN FILE PARSER
    # =====================================================
    
    def parse_file(
        self,
        file_path: str | Path
    ) -> dict:

        path = Path(file_path)

        ext = path.suffix

        # -------------------------------------------------
        # READ FILE
        # -------------------------------------------------

        try:

            with open(path, "rb") as f:
                code_bytes = f.read()

        except Exception as e:

            print(f"Error reading {path}: {e}")

            return {
                "file": str(path),

                "classes": [],

                "functions": [],

                "imports": [],

                "calls": [],

                "api_calls": [],

                "states": [],

                "routes": [],

                "database_reads": [],

                "database_writes": [],
            }

        # -------------------------------------------------
        # PRISMA FALLBACK
        # -------------------------------------------------

        if ext == ".prisma":

            return self._parse_prisma_regex(
                path,
                code_bytes
            )

        # -------------------------------------------------
        # SQL FALLBACK
        # -------------------------------------------------

        if ext == ".sql":

            return self._parse_sql_regex(
                path,
                code_bytes
            )

        # -------------------------------------------------
        # UNSUPPORTED FILES
        # -------------------------------------------------

        if ext not in self.parsers:

            return {
                "file": str(path),

                "classes": [],

                "functions": [],

                "imports": [],

                "calls": [],

                "api_calls": [],

                "states": [],

                "routes": [],

                "database_reads": [],

                "database_writes": [],
            }

        # -------------------------------------------------
        # TREE-SITTER PARSING
        # -------------------------------------------------

        parser = self.parsers[ext]

        tree = parser.parse(code_bytes)

        query = self.queries[ext]

        cursor = QueryCursor(query)

        captures_dict = cursor.captures(
            tree.root_node
        )

        # -------------------------------------------------
        # BASE RESULTS
        # -------------------------------------------------

        results = {

            "file": str(path),

            "classes": set(),

            "functions": set(),

            "imports": set(),

            "calls": set(),

            "api_calls": set(),

            "states": set(),

            "routes": set(),

            "database_reads": set(),

            "database_writes": set(),
        }

        # -------------------------------------------------
        # TREE-SITTER EXTRACTION
        # -------------------------------------------------

        for capture_name, nodes in captures_dict.items():

            for node in nodes:

                text = code_bytes[
                    node.start_byte:node.end_byte
                ].decode("utf8")

                text = text.strip(
                    "\"';{} \n"
                )

                if "class" in capture_name:

                    results["classes"].add(text)

                elif "function" in capture_name:

                    results["functions"].add(text)

                elif "import" in capture_name:

                    results["imports"].add(text)

        # -------------------------------------------------
        # TEXT-BASED SEMANTIC EXTRACTION
        # -------------------------------------------------

        code_text = code_bytes.decode(
            "utf8",
            errors="ignore"
        )

        # FUNCTION CALLS
        results["calls"] = (
            self._extract_function_calls(
                code_text
            )
        )

        # API CALLS
        results["api_calls"] = (
            self._extract_api_calls(
                code_text
            )
        )

        # REACT STATE
        results["states"] = (
            self._extract_state_hooks(
                code_text
            )
        )

        # ROUTES
        results["routes"] = (
            self._extract_routes(
                path
            )
        )

        # DATABASE OPS
        reads, writes = (
            self._extract_database_ops(
                code_text
            )
        )

        results["database_reads"] = reads

        results["database_writes"] = writes

        # -------------------------------------------------
        # CONVERT SETS → LISTS
        # -------------------------------------------------

        final_results = {}

        for key, value in results.items():

            if isinstance(value, set):

                final_results[key] = list(value)

            else:

                final_results[key] = value

        return final_results