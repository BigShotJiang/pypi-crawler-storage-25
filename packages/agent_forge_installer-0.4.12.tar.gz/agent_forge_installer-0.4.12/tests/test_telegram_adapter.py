from __future__ import annotations

import queue
import threading
from datetime import datetime, timezone

from agentforge.claude_usage import ClaudeUsageError
from agentforge.claude_runner import InvokeResult, RateLimitError
from agentforge.rate_limiter import RateLimiter
from agentforge.telegram_adapter import ClawdiaBot, MONITOR_REACT_ONLY
from agentforge.approval_gates import ApprovalGates


class _MockStore:
    """Mock ConversationStore for testing."""
    def get_dynamic_messages(
        self,
        session_id,
        min_msgs=3,
        max_msgs=100,
        hours=4,
        agent_name=None,
        exclude_message_ids=None,
    ):
        return []

    def get_thread_context(self, parent_message_id, exclude_message_ids=None):
        return [], set()

    def save_message(self, *args, **kwargs):
        class _SavedMessage:
            id = 1

        return _SavedMessage()

    def find_telegram_message(self, *, chat_id, telegram_message_id, channel_id=None):
        return None


class _DummyQueue:
    def __init__(self) -> None:
        self.done_calls = 0

    def task_done(self) -> None:
        self.done_calls += 1


def _make_bot() -> ClawdiaBot:
    bot = object.__new__(ClawdiaBot)
    bot.config = {
        "claude": {"model": "sonnet"},
        "bot_name": "clawdia",
        "telegram": {"max_message_length": 4096, "allowed_chat_ids": []},
        "threads": {
            "11": {"name": "architect", "model": "sonnet"},
            "12": {"name": "victor", "model": "sonnet"},
        },
    }
    bot.bot_name = "clawdia"
    bot.agent_api_bases = {}
    bot.api_base = "https://example.test"
    bot.approval_gates = ApprovalGates(root="/tmp", timeout_seconds=1)
    bot.store = _MockStore()
    bot._save_usage = lambda *args, **kwargs: None
    bot._save_message = lambda *args, **kwargs: None
    bot._log_action = lambda *args, **kwargs: None
    bot._save_pending_retry = lambda *args, **kwargs: None
    bot._handle_worker_error = ClawdiaBot._handle_worker_error.__get__(bot, ClawdiaBot)
    bot.rate_limiter = RateLimiter(max_per_minute=10, max_per_hour=60, max_concurrent_sessions=2)
    bot._append_claude_usage_summary = ClawdiaBot._append_claude_usage_summary.__get__(bot, ClawdiaBot)
    bot._append_real_claude_usage = ClawdiaBot._append_real_claude_usage.__get__(bot, ClawdiaBot)
    bot._format_usage_reset_label = ClawdiaBot._format_usage_reset_label.__get__(bot, ClawdiaBot)
    bot._builtin_status = ClawdiaBot._builtin_status.__get__(bot, ClawdiaBot)
    bot._builtin_claude_login = ClawdiaBot._builtin_claude_login.__get__(bot, ClawdiaBot)
    bot._dispatch_builtin = ClawdiaBot._dispatch_builtin.__get__(bot, ClawdiaBot)
    bot._get_current_service_unit = ClawdiaBot._get_current_service_unit.__get__(bot, ClawdiaBot)
    bot._discover_restartable_agents = ClawdiaBot._discover_restartable_agents.__get__(bot, ClawdiaBot)
    bot._build_restart_picker = ClawdiaBot._build_restart_picker.__get__(bot, ClawdiaBot)
    bot._restart_agent_service = ClawdiaBot._restart_agent_service.__get__(bot, ClawdiaBot)
    return bot


def test_should_respond_to_thread_allows_private_chats() -> None:
    bot = _make_bot()
    bot.config["telegram"]["default_for_threads"] = []

    assert bot._should_respond_to_thread({"chat": {"type": "private"}}, 999) is True


def test_should_respond_to_thread_allows_mentions() -> None:
    bot = _make_bot()
    bot.config["telegram"]["default_for_threads"] = []

    assert (
        bot._should_respond_to_thread(
            {"chat": {"type": "supergroup"}, "text": "ping @clawdia"},
            999,
        )
        is True
    )


def test_should_respond_to_thread_allows_configured_default_thread() -> None:
    bot = _make_bot()
    bot.config["telegram"]["default_for_threads"] = [957]

    assert bot._should_respond_to_thread({"chat": {"type": "supergroup"}}, 957) is True
    assert bot._should_respond_to_thread({"chat": {"type": "supergroup"}}, 961) is False


def test_should_respond_to_thread_defaults_to_back_compat_when_unconfigured() -> None:
    bot = _make_bot()

    assert bot._should_respond_to_thread({"chat": {"type": "supergroup"}}, 961) is True


def test_handle_update_records_other_bot_messages_in_project_topics(monkeypatch) -> None:
    bot = _make_bot()
    bot.config["project_topics"] = {
        "16": {
            "name": "dev",
            "label": "Dev",
            "agents": ["clawdia", "victor"],
            "default_agent": "clawdia",
        }
    }
    bot.config["telegram"]["bot_username"] = "clawdia"
    bot.offset = 0
    bot._save_offset = lambda: None
    saved: list[tuple] = []
    bot._save_message = lambda *args, **kwargs: saved.append((args, kwargs))
    monkeypatch.setattr(
        bot,
        "_extract_message_text",
        lambda msg, chat_id, thread_id: msg.get("text"),
    )

    bot._handle_update(
        {
            "update_id": 1,
            "message": {
                "message_id": 964,
                "message_thread_id": 16,
                "chat": {"id": "-100123", "type": "supergroup"},
                "from": {"is_bot": True, "username": "catherine"},
                "text": "Question de suivi",
            },
        }
    )

    assert len(saved) == 1
    args, kwargs = saved[0]
    assert args[0] == "tg--100123-t16"
    assert args[1] == "assistant"
    assert "[@catherine] Question de suivi" == args[2]
    assert kwargs["thread_id"] == 16
    assert kwargs["agent_name"] == "catherine"


def test_worker_invokes_directly(monkeypatch) -> None:
    """Each message is dispatched to _invoke_and_respond directly (no plan phase)."""
    bot = _make_bot()
    invoked: list[dict] = []
    task_queue: queue.Queue = queue.Queue()

    def fake_invoke_and_respond(task, tq):
        invoked.append(task)
        tq.task_done()

    bot._invoke_and_respond = fake_invoke_and_respond

    task = {
        "session_id": "sess-1",
        "user_text": "hello",
        "thread_cfg": {"name": "clawdia"},
        "chat_id": "chat",
        "thread_id": 123,
    }
    task_queue.put(task)
    task_queue.put(None)

    bot._worker("clawdia", task_queue)

    assert len(invoked) == 1
    assert invoked[0]["user_text"] == "hello"


def test_invoke_and_respond_monitor_mode_reacts_without_reply(monkeypatch) -> None:
    bot = _make_bot()
    reactions: list[tuple[str, int, str, int | None, str | None]] = []
    sent_messages: list[str] = []
    task_queue = _DummyQueue()

    monkeypatch.setattr(
        "agentforge.telegram_adapter.invoke_claude",
        lambda **kwargs: InvokeResult(text=MONITOR_REACT_ONLY, model="haiku"),
    )
    bot._set_reaction = lambda chat_id, message_id, emoji, thread_id=None, agent_name=None: reactions.append(
        (chat_id, message_id, emoji, thread_id, agent_name)
    )
    bot._send_message = lambda chat_id, text, thread_id=None, agent_name=None, reply_markup=None: sent_messages.append(text)

    bot._invoke_and_respond(
        {
            "session_id": "sess-monitor-react",
            "user_text": "FYI release is live",
            "thread_cfg": {"name": "clawdia"},
            "chat_id": "chat",
            "thread_id": 123,
            "is_monitor_mode": True,
            "monitor_message_id": 456,
        },
        task_queue,
    )

    assert reactions == [("chat", 456, "👍", 123, "clawdia")]
    assert sent_messages == []
    assert task_queue.done_calls == 1


def test_invoke_and_respond_monitor_mode_replies_without_reaction(monkeypatch) -> None:
    bot = _make_bot()
    reactions: list[tuple[str, int, str, int | None, str | None]] = []
    sent_messages: list[str] = []
    task_queue = _DummyQueue()

    monkeypatch.setattr(
        "agentforge.telegram_adapter.invoke_claude",
        lambda **kwargs: InvokeResult(text="I can take this.", model="haiku"),
    )
    bot._set_reaction = lambda chat_id, message_id, emoji, thread_id=None, agent_name=None: reactions.append(
        (chat_id, message_id, emoji, thread_id, agent_name)
    )
    bot._send_message = lambda chat_id, text, thread_id=None, agent_name=None, reply_markup=None: sent_messages.append(text)

    bot._invoke_and_respond(
        {
            "session_id": "sess-monitor-reply",
            "user_text": "Can someone handle the deploy?",
            "thread_cfg": {"name": "clawdia"},
            "chat_id": "chat",
            "thread_id": 123,
            "is_monitor_mode": True,
            "monitor_message_id": 456,
        },
        task_queue,
    )

    assert reactions == []
    assert sent_messages == ["I can take this."]
    assert task_queue.done_calls == 1


def test_handle_worker_error_sends_message() -> None:
    bot = _make_bot()
    sent_messages: list[str] = []
    task_queue = _DummyQueue()
    bot._send_message = lambda chat_id, text, thread_id=None, agent_name=None, reply_markup=None: sent_messages.append(text)

    bot._handle_worker_error(
        RuntimeError("boom"),
        {},
        "chat",
        123,
        "clawdia",
        task_queue,
    )

    assert sent_messages == ["Sorry, I encountered an error. Please try again."]
    assert task_queue.done_calls == 1


def test_builtin_status_uses_real_claude_usage(monkeypatch) -> None:
    bot = _make_bot()

    def fake_run(*_args, **_kwargs):
        raise RuntimeError("skip system commands")

    monkeypatch.setattr("agentforge.telegram_adapter.subprocess.run", fake_run)
    monkeypatch.setattr(
        "agentforge.telegram_adapter.get_claude_oauth_usage",
        lambda root=None: {
            "five_hour": {"utilization": 32.0, "resets_at": "2026-03-25T14:53:00Z"},
            "seven_day": {"utilization": 83.0, "resets_at": "2026-03-29T17:59:00Z"},
            "seven_day_sonnet": {"utilization": 71.0, "resets_at": "2026-03-29T17:59:00Z"},
        },
    )

    status = bot._builtin_status()

    assert "🔧 Service: `agentforge.service`" in status
    assert "📊 Utilisation" in status
    assert "Session 5h :" in status
    assert "Semaine :" in status
    assert "Sonnet semaine :" in status
    assert "32%" in status
    assert "83%" in status
    assert "71%" in status


def test_builtin_status_reports_unavailable_usage_when_oauth_fails(monkeypatch) -> None:
    bot = _make_bot()

    def fake_run(*_args, **_kwargs):
        raise RuntimeError("skip system commands")

    monkeypatch.setattr("agentforge.telegram_adapter.subprocess.run", fake_run)

    def fake_get_usage(root=None):
        raise ClaudeUsageError("oauth unavailable")

    monkeypatch.setattr("agentforge.telegram_adapter.get_claude_oauth_usage", fake_get_usage)

    status = bot._builtin_status()

    assert "📊 Claude Code" in status
    assert "Données d'usage indisponibles." in status


def test_format_usage_reset_label_uses_toronto_timezone() -> None:
    bot = _make_bot()
    now = datetime(2026, 3, 25, 10, 0, tzinfo=timezone.utc)
    reset_at = datetime(2026, 3, 25, 12, 30, tzinfo=timezone.utc)

    label = bot._format_usage_reset_label(reset_at, now)

    assert label == "dans 2h30"


def test_usage_display_surconsommation_when_ahead_of_pace(monkeypatch) -> None:
    """When utilization is higher than expected pace, label 'surconsommation' on its own line."""
    bot = _make_bot()

    def fake_run(*_args, **_kwargs):
        raise RuntimeError("skip system commands")

    monkeypatch.setattr("agentforge.telegram_adapter.subprocess.run", fake_run)

    # Session 5h: utilization=80%, elapsed=50% of window → delta=+30% → surconsommation
    # reset in 2.5h → time_elapsed = 5h - 2.5h = 2.5h out of 5h = 50% expected
    import datetime as _dt
    now_utc = _dt.datetime.now(_dt.timezone.utc)
    resets_at = (now_utc + _dt.timedelta(hours=2, minutes=30)).strftime("%Y-%m-%dT%H:%M:%SZ")

    monkeypatch.setattr(
        "agentforge.telegram_adapter.get_claude_oauth_usage",
        lambda root=None: {
            "five_hour": {"utilization": 80.0, "resets_at": resets_at},
        },
    )

    status = bot._builtin_status()

    assert "surconsommation" in status
    assert "en réserve" not in status
    # The label must appear on its own line (not appended to the header line)
    lines = status.splitlines()
    header_line = next((l for l in lines if "Session 5h :" in l), None)
    assert header_line is not None
    assert "surconsommation" not in header_line


def test_usage_display_reserve_when_behind_pace(monkeypatch) -> None:
    """When utilization is lower than expected pace, label 'en réserve' on its own line."""
    bot = _make_bot()

    def fake_run(*_args, **_kwargs):
        raise RuntimeError("skip system commands")

    monkeypatch.setattr("agentforge.telegram_adapter.subprocess.run", fake_run)

    # Session 5h: utilization=20%, elapsed=50% of window → delta=-30% → en réserve
    import datetime as _dt
    now_utc = _dt.datetime.now(_dt.timezone.utc)
    resets_at = (now_utc + _dt.timedelta(hours=2, minutes=30)).strftime("%Y-%m-%dT%H:%M:%SZ")

    monkeypatch.setattr(
        "agentforge.telegram_adapter.get_claude_oauth_usage",
        lambda root=None: {
            "five_hour": {"utilization": 20.0, "resets_at": resets_at},
        },
    )

    status = bot._builtin_status()

    assert "en réserve" in status
    assert "surconsommation" not in status
    # The label must appear on its own line
    lines = status.splitlines()
    header_line = next((l for l in lines if "Session 5h :" in l), None)
    assert header_line is not None
    assert "en réserve" not in header_line


def test_handle_worker_error_rate_limit_schedules_catchup_tasks() -> None:
    bot = _make_bot()
    sent_messages: list[str] = []
    scheduled: list[datetime] = []
    task_queue = _DummyQueue()
    bot._send_message = lambda chat_id, text, thread_id=None, agent_name=None, reply_markup=None: sent_messages.append(text)
    bot._schedule_catchup_tasks = lambda restore_at_utc: scheduled.append(restore_at_utc)

    task = {}
    bot._handle_worker_error(
        RateLimitError(retry_after_seconds=90),
        task,
        "chat",
        123,
        "clawdia",
        task_queue,
    )

    assert len(scheduled) == 1
    assert scheduled[0].tzinfo is not None  # must be timezone-aware UTC
    assert len(sent_messages) == 1
    assert sent_messages[0].startswith("⏸ Rate limit Anthropic atteint.")
    assert task_queue.done_calls == 1


def test_callback_query_resolves_pending_approval(monkeypatch) -> None:
    bot = _make_bot()
    sent_messages: list[str] = []
    bot._send_message = lambda chat_id, text, thread_id=None, agent_name=None, reply_markup=None: sent_messages.append(text)
    monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", lambda *args, **kwargs: {"ok": True})

    # Seed a pending approval by issuing an approval request in a worker thread.
    t = threading.Thread(
        target=lambda: bot.approval_gates.request_and_wait(
            chat_id="123",
            thread_id=456,
            command_text="rm -rf /tmp/demo",
            actor_label="archie",
            send_message_fn=lambda *args, **kwargs: None,
        ),
        daemon=True,
    )
    t.start()
    pending = None
    for _ in range(100):
        with bot.approval_gates._lock:  # noqa: SLF001
            if bot.approval_gates._pending:  # noqa: SLF001
                pending = next(iter(bot.approval_gates._pending.values()))  # noqa: SLF001
                break
        threading.Event().wait(0.01)

    assert pending is not None
    bot._handle_callback_query(
        {
            "id": "cb-1",
            "data": f"approval:{pending.request_id}:approve",
            "from": {"id": 42},
            "message": {"chat": {"id": 123}, "message_thread_id": 456},
        }
    )
    t.join(timeout=2)
    assert any("Decision recorded: approved." in m for m in sent_messages)


def test_handle_update_sends_friendly_rate_limit_message() -> None:
    bot = _make_bot()
    sent_messages: list[str] = []
    bot.config["telegram"]["allowed_chat_ids"] = ["123"]
    bot.rate_limiter = RateLimiter(max_per_minute=0, max_per_hour=60, max_concurrent_sessions=2)
    bot._send_message = lambda chat_id, text, thread_id=None, agent_name=None, reply_markup=None: sent_messages.append(text)
    bot._save_offset = lambda: None
    bot._extract_message_text = lambda msg, chat_id, thread_id: "hello"
    bot._dispatch_command = lambda *args, **kwargs: None
    bot._save_message = lambda *args, **kwargs: None
    bot._enqueue_task = lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("should not enqueue"))

    update = {
        "update_id": 1,
        "message": {
            "message_id": 10,
            "chat": {"id": 123},
            "from": {"first_name": "Martin", "is_bot": False},
            "text": "hello",
        },
    }

    bot._handle_update(update)

    assert sent_messages == ["⏱ Tu envoies trop de messages trop vite. Attends une minute."]


def test_dispatch_command_search_routes_to_background_job() -> None:
    bot = _make_bot()
    calls: list[tuple[str, str, str, int]] = []
    bot._start_search_job = (
        lambda cmd_key, query, chat_id, thread_id: calls.append((cmd_key, query, chat_id, thread_id)) or "ack"
    )

    result = bot._dispatch_command("/search latest agentforge release", "chat-1", 42)

    assert result == "ack"
    assert calls == [("/search", "latest agentforge release", "chat-1", 42)]


def test_dispatch_builtin_restart_without_args_returns_picker() -> None:
    bot = _make_bot()

    response = bot._dispatch_builtin("/restart")

    assert isinstance(response, dict)
    assert response["text"] == "Choisis l'agent à redémarrer :"
    buttons = response["reply_markup"]["inline_keyboard"]
    assert {"text": "architect", "callback_data": "/restart architect"} in buttons[0]
    flat_buttons = [button for row in buttons for button in row]
    assert not any(button["text"] == "clawdia" for button in flat_buttons)


def test_dispatch_builtin_claudelogin_returns_fresh_url(monkeypatch) -> None:
    bot = _make_bot()

    class _Completed:
        def __init__(self, returncode: int, stdout: str = "", stderr: str = "") -> None:
            self.returncode = returncode
            self.stdout = stdout
            self.stderr = stderr

    monkeypatch.setattr(
        "agentforge.telegram_adapter.subprocess.run",
        lambda *args, **kwargs: _Completed(
            0,
            stdout="https://claude.ai/oauth/authorize?code=true&state=test\n",
        ),
    )
    monkeypatch.setattr("pathlib.Path.exists", lambda self: True)

    response = bot._dispatch_builtin("/claudelogin")

    assert "https://claude.ai/oauth/authorize?code=true&state=test" in response
    assert "renvoie `/claudelogin`" in response


def test_dispatch_builtin_claudelogin_handles_generation_failure(monkeypatch) -> None:
    bot = _make_bot()

    class _Completed:
        def __init__(self, returncode: int, stdout: str = "", stderr: str = "") -> None:
            self.returncode = returncode
            self.stdout = stdout
            self.stderr = stderr

    monkeypatch.setattr(
        "agentforge.telegram_adapter.subprocess.run",
        lambda *args, **kwargs: _Completed(1, stdout="", stderr="boom"),
    )
    monkeypatch.setattr("pathlib.Path.exists", lambda self: True)

    response = bot._dispatch_builtin("/claudelogin")

    assert "Impossible de générer un lien Claude login frais" in response


def test_dispatch_builtin_claudelogin_handles_missing_generator() -> None:
    bot = _make_bot()

    response = bot._dispatch_builtin("/claudelogin")

    assert "Générateur de lien introuvable" in response


def test_dispatch_command_strips_telegram_bot_suffix_for_builtin(monkeypatch) -> None:
    bot = _make_bot()
    bot._start_search_job = lambda *args, **kwargs: "unexpected"

    class _Completed:
        def __init__(self, returncode: int, stdout: str = "", stderr: str = "") -> None:
            self.returncode = returncode
            self.stdout = stdout
            self.stderr = stderr

    monkeypatch.setattr(
        "agentforge.telegram_adapter.subprocess.run",
        lambda *args, **kwargs: _Completed(
            0,
            stdout="https://claude.ai/oauth/authorize?code=true&state=botsuffix\n",
        ),
    )
    monkeypatch.setattr("pathlib.Path.exists", lambda self: True)

    response = bot._dispatch_command("/claudelogin@TheArchitectClawdiaBot", "chat-1", 1549)

    assert "state=botsuffix" in response


def test_restart_agent_service_rejects_self_restart() -> None:
    bot = _make_bot()

    response = bot._restart_agent_service("clawdia")

    assert "ne peut pas se redémarrer lui-même" in response


def test_restart_agent_service_restarts_selected_agent(monkeypatch) -> None:
    bot = _make_bot()
    calls: list[list[str]] = []

    class _Completed:
        def __init__(self, returncode: int, stdout: str = "", stderr: str = "") -> None:
            self.returncode = returncode
            self.stdout = stdout
            self.stderr = stderr

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        if cmd[:3] == ["systemctl", "--user", "restart"]:
            return _Completed(0)
        if cmd[:3] == ["systemctl", "--user", "is-active"]:
            return _Completed(0, stdout="active\n")
        raise AssertionError(f"Unexpected command: {cmd}")

    monkeypatch.setattr("agentforge.telegram_adapter.subprocess.run", fake_run)

    response = bot._restart_agent_service("architect")

    assert response == "✅ `architect` redémarré (`agentforge-architect.service` actif)."
    assert calls == [
        ["systemctl", "--user", "restart", "agentforge-architect.service"],
        ["systemctl", "--user", "is-active", "agentforge-architect.service"],
    ]


# ---------------------------------------------------------------------------
# _extract_message_text — audio / video_note handling
# ---------------------------------------------------------------------------


def _make_bot_with_send() -> tuple[ClawdiaBot, list]:
    """Return a bot and a list that records _send_message calls."""
    bot = _make_bot()
    bot.token = "test-token"
    sent: list[tuple] = []
    bot._send_message = lambda chat_id, text, thread_id=None, **kw: sent.append(
        (chat_id, text, thread_id)
    )
    bot._extract_message_text = ClawdiaBot._extract_message_text.__get__(
        bot, ClawdiaBot
    )
    return bot, sent


def test_extract_message_text_audio_returns_transcription(monkeypatch) -> None:
    """audio message type is transcribed and the text echoed back."""
    bot, sent = _make_bot_with_send()
    monkeypatch.setattr(
        "agentforge.telegram_adapter.transcribe_audio_file",
        lambda audio, api_base, token: "hello from mp3",
    )

    msg = {"audio": {"file_id": "abc123", "mime_type": "audio/mpeg"}}
    result = bot._extract_message_text(msg, chat_id=1, thread_id=None)

    assert result == "hello from mp3"
    assert any("hello from mp3" in text for _, text, _ in sent)


def test_extract_message_text_audio_transcription_failure_returns_none(monkeypatch) -> None:
    """When audio transcription fails, a helpful message is sent and None returned."""
    bot, sent = _make_bot_with_send()
    monkeypatch.setattr(
        "agentforge.telegram_adapter.transcribe_audio_file",
        lambda audio, api_base, token: None,
    )

    msg = {"audio": {"file_id": "abc123", "mime_type": "audio/mpeg"}}
    result = bot._extract_message_text(msg, chat_id=1, thread_id=None)

    assert result is None
    assert any("incompréhensible" in text for _, text, _ in sent)


def test_extract_message_text_video_note_returns_transcription(monkeypatch) -> None:
    """video_note (circular video) message is transcribed and the text echoed back."""
    bot, sent = _make_bot_with_send()
    monkeypatch.setattr(
        "agentforge.telegram_adapter.transcribe_audio_file",
        lambda audio, api_base, token: "video note content",
    )

    msg = {"video_note": {"file_id": "vid123", "duration": 5}}
    result = bot._extract_message_text(msg, chat_id=2, thread_id=None)

    assert result == "video note content"
    assert any("video note content" in text for _, text, _ in sent)


def test_extract_message_text_video_note_transcription_failure_returns_none(monkeypatch) -> None:
    """When video_note transcription fails, None is returned."""
    bot, sent = _make_bot_with_send()
    monkeypatch.setattr(
        "agentforge.telegram_adapter.transcribe_audio_file",
        lambda audio, api_base, token: None,
    )

    msg = {"video_note": {"file_id": "vid123", "duration": 5}}
    result = bot._extract_message_text(msg, chat_id=2, thread_id=None)

    assert result is None
