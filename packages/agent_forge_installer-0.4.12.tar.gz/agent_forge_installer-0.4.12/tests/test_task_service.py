from __future__ import annotations

from datetime import datetime, timedelta
import json
from pathlib import Path

from agentforge.task_service import TaskService
from agentforge.todo_cli import main as todo_main


def test_update_task_loads_prompt_from_prompt_ref(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    root = tmp_path
    (root / "agents" / "architect").mkdir(parents=True)
    (root / "agents" / "architect" / "config.json").write_text("{}", encoding="utf-8")
    prompt_path = root / "vault" / "Agents" / "architect" / "brief.md"
    prompt_path.parent.mkdir(parents=True, exist_ok=True)
    prompt_path.write_text("Updated prompt body.", encoding="utf-8")

    service = TaskService(root)
    task_id = service.create_task(assignee_id="architect", title="Prompted task")
    assert service.update_task(task_id, prompt_ref="brief.md")

    record = next(task for task in service.list_tasks("architect") if task.task_id == task_id)
    # prompt_ref is no longer serialized; the loaded content lives directly in notes.
    assert record.notes == "Updated prompt body."


def test_render_heartbeat_payload_includes_prompt_ref(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    root = tmp_path
    (root / "agents" / "architect").mkdir(parents=True)
    (root / "agents" / "architect" / "config.json").write_text("{}", encoding="utf-8")
    prompt_path = root / "vault" / "Agents" / "architect" / "brief.md"
    prompt_path.parent.mkdir(parents=True, exist_ok=True)
    prompt_path.write_text("Heartbeat prompt.", encoding="utf-8")

    service = TaskService(root)
    task_id = service.create_task(
        assignee_id="architect",
        title="Heartbeat task",
        due_at=datetime(2026, 4, 15, 10, 0),
        prompt_ref="brief.md",
    )
    payload = service.render_heartbeat_payload("architect", now=datetime(2026, 4, 15, 9, 50))
    assert task_id in payload
    # Prompt content is now directly in notes — no prompt_ref metadata line in payload.
    assert "Heartbeat prompt." in payload


def test_cleanup_legacy_tasks_view_removes_legacy_tasks_file(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    root = tmp_path
    (root / "agents" / "architect").mkdir(parents=True)
    (root / "agents" / "architect" / "config.json").write_text("{}", encoding="utf-8")
    legacy_path = root / "vault" / "Agents" / "architect" / "tasks.md"
    legacy_path.parent.mkdir(parents=True, exist_ok=True)
    legacy_path.write_text("legacy\n", encoding="utf-8")

    service = TaskService(root)
    path = service.cleanup_legacy_tasks_view("architect")
    assert path == legacy_path
    assert not path.exists()


def test_bootstrap_actor_idempotent(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    root = tmp_path
    (root / "agents" / "architect").mkdir(parents=True)
    (root / "agents" / "architect" / "config.json").write_text("{}", encoding="utf-8")

    service = TaskService(root)
    service.bootstrap_actor("architect")
    # Second call must not raise — resolve_list with create=True is idempotent.
    service.bootstrap_actor("architect")


def test_render_heartbeat_payload_limits_to_one_task_and_includes_fail_signal(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    root = tmp_path
    (root / "agents" / "architect").mkdir(parents=True)
    (root / "agents" / "architect" / "config.json").write_text("{}", encoding="utf-8")

    service = TaskService(root)
    first_id = service.create_task(
        assignee_id="architect",
        title="Urgent due task",
        due_at=datetime(2026, 4, 15, 9, 0),
        priority="high",
    )
    service.create_task(
        assignee_id="architect",
        title="Background task",
        priority="low",
    )

    payload = service.render_heartbeat_payload("architect", now=datetime(2026, 4, 15, 9, 5), limit=1)
    assert first_id in payload
    assert "Background task" not in payload
    assert "TASK_FAIL" in payload


def test_claim_actionable_blocks_duplicate_claims_until_released(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    root = tmp_path
    (root / "agents" / "architect").mkdir(parents=True)
    (root / "agents" / "architect" / "config.json").write_text("{}", encoding="utf-8")

    service = TaskService(root)
    task_id = service.create_task(
        assignee_id="architect",
        title="Claimed task",
        due_at=datetime(2026, 4, 15, 10, 0),
    )

    first = service.claim_actionable("architect", now=datetime(2026, 4, 15, 9, 50), limit=1)
    second = service.claim_actionable("architect", now=datetime(2026, 4, 15, 9, 51), limit=1)

    assert [task.task_id for task in first] == [task_id]
    assert second == []

    assert service.complete_task(task_id, completed_at=datetime(2026, 4, 15, 10, 5))
    assert not service._claim_path(task_id).exists()


def test_expired_claim_allows_reclaim(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    root = tmp_path
    (root / "agents" / "architect").mkdir(parents=True)
    (root / "agents" / "architect" / "config.json").write_text("{}", encoding="utf-8")

    service = TaskService(root)
    task_id = service.create_task(
        assignee_id="architect",
        title="Expired claim task",
        due_at=datetime(2026, 4, 15, 10, 0),
    )
    claim_path = service._claim_path(task_id)
    old_claimed_at = datetime(2026, 4, 15, 8, 0)
    claim_path.write_text(
        json.dumps(
            {
                "task_id": task_id,
                "actor_id": "architect",
                "claimed_at": old_claimed_at.isoformat(timespec="minutes"),
                # One minute keeps the fixture obviously expired without depending on production TTL.
                "expires_at": (old_claimed_at + timedelta(minutes=1)).isoformat(timespec="minutes"),
            }
        ),
        encoding="utf-8",
    )

    claimed = service.claim_actionable("architect", now=datetime(2026, 4, 15, 9, 50), limit=1)

    assert [task.task_id for task in claimed] == [task_id]
    replacement = json.loads(claim_path.read_text(encoding="utf-8"))
    assert replacement["claimed_at"] == "2026-04-15T09:50"
    assert replacement["expires_at"] == "2026-04-15T10:05"


def test_due_cli_claim_outputs_task_once(tmp_path: Path, monkeypatch, capsys) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    root = tmp_path
    (root / "agents" / "architect").mkdir(parents=True)
    (root / "agents" / "architect" / "config.json").write_text("{}", encoding="utf-8")

    service = TaskService(root)
    task_id = service.create_task(
        assignee_id="architect",
        title="CLI claimed task",
        due_at=datetime(2026, 4, 15, 10, 0),
    )

    assert todo_main(["due", "--root", str(root), "--agent", "architect", "--format", "heartbeat", "--limit", "1", "--claim"]) == 0
    first = capsys.readouterr().out
    assert task_id in first

    assert todo_main(["due", "--root", str(root), "--agent", "architect", "--format", "heartbeat", "--limit", "1", "--claim"]) == 0
    second = capsys.readouterr().out
    assert second == ""
