from __future__ import annotations

from datetime import datetime
import os
from pathlib import Path

import pytest

from agentforge.twodo.archive import load_archive, unpack_archive
from agentforge.twodo.backend import TwoDoBackend, render_note_block, split_note_block


def test_twodo_backend_roundtrip_local_store(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Roundtrip task",
        notes="human note",
        due_at=datetime(2026, 4, 15, 9, 30),
        recurrence_rule="daily",
        priority="high",
        actor_id="architect",
        prompt="Run the task",
    )

    fetched = backend.read_task(created.task_id)
    assert fetched is not None
    assert fetched.title == "🔁 Roundtrip task"  # recurring tasks get the 🔁 prefix
    assert fetched.list_name == "architect"
    assert fetched.due_at == datetime(2026, 4, 15, 9, 30)
    assert fetched.recurrence_rule == "daily"
    assert fetched.priority == "high"

    payload = unpack_archive(load_archive(fetched.path))
    assert payload["title"] == "🔁 Roundtrip task"
    assert payload["caluid"] == fetched.list_id
    # Prompt content is written directly to notes — no metadata block.
    assert payload["notes"] == "Run the task"
    assert "--- AgentForge ---" not in payload["notes"]


def test_twodo_backend_parses_real_reference_task_when_available() -> None:
    root = Path("/home/agentforge/Dropbox/Apps/2Do")
    sample = root / "tod" / "o_u_k_cc565be8d94148b4b7cf1bfa0c4ec3bf_p__i_0f9e7ccd10a643a680d5103847583d5f_d_.tod"
    if not sample.exists() or not os.access(sample, os.R_OK):
        pytest.skip("Real 2Do Dropbox sample is not available in this environment.")

    backend = TwoDoBackend(Path("/home/agentforge/AgentForge"))
    task = backend.read_task("0f9e7ccd10a643a680d5103847583d5f")
    assert task is not None
    assert task.title.removeprefix("🔁 ") == "Testing before Agent forge"
    assert task.notes == "91827"
    assert task.due_at is not None  # live task — don't assert specific date, it can be rescheduled
    assert task.list_name == "Inbox"
    assert task.locations
    assert task.alarms


def test_twodo_backend_reads_real_lists_and_groups_when_available() -> None:
    root = Path("/home/agentforge/Dropbox/Apps/2Do")
    col_dir = root / "col"
    cal_dir = root / "cal"
    if not col_dir.exists() or not cal_dir.exists():
        pytest.skip("Real 2Do Dropbox metadata is not available in this environment.")

    backend = TwoDoBackend(Path("/home/agentforge/AgentForge"))
    lists = backend.read_lists()
    groups = backend.read_groups()

    assert any(item.title == "Inbox" for item in lists)
    assert any(item.title == "Taches" for item in lists)
    assert groups
    assert "LISTS" in groups.values()


def test_render_note_block_returns_content_directly() -> None:
    # Prompt content goes directly in notes — no metadata block.
    rendered = render_note_block("Do the thing")
    assert rendered == "Do the thing"
    assert "--- AgentForge ---" not in rendered

    # Empty content yields empty string.
    assert render_note_block("") == ""
    assert render_note_block("  ") == ""

    # Whitespace is stripped.
    assert render_note_block("  hello  ") == "hello"


def test_complete_task_monthly_advances_without_drift(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)
    created = backend.create_task(
        list_name="architect",
        title="Monthly task",
        due_at=datetime(2026, 1, 31, 9, 0),
        recurrence_rule="monthly",
        actor_id="architect",
    )
    assert backend.complete_task(created.task_id, completed_at=datetime(2026, 1, 31, 9, 5))

    # Original task is now a completed record (mirroring 2Do app behaviour).
    original = backend.read_task(created.task_id)
    assert original is not None
    assert original.is_completed is True
    assert original.last_completed_at == datetime(2026, 1, 31, 9, 5)

    # A new task carries the next occurrence.
    all_tasks = backend.read_tasks(include_completed=False)
    next_occurrence = next((t for t in all_tasks if "Monthly task" in t.title and not t.is_completed), None)
    assert next_occurrence is not None
    assert next_occurrence.task_id != created.task_id
    assert next_occurrence.due_at == datetime(2026, 2, 28, 9, 0)
    assert next_occurrence.recurrence_rule == "monthly"


def test_schedule_daily_early_run_advances_from_due_date(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)
    created = backend.create_task(
        list_name="architect",
        title="Daily midnight review",
        due_at=datetime(2026, 5, 3, 0, 0),
        recurrence_rule="daily",
        actor_id="architect",
        repeat_from="due",
    )

    assert backend.complete_task(created.task_id, completed_at=datetime(2026, 5, 2, 23, 45))

    next_occurrence = next(t for t in backend.read_tasks(include_completed=False) if "Daily midnight review" in t.title)
    assert next_occurrence.due_at == datetime(2026, 5, 4, 0, 0)
    assert next_occurrence.repeat_from == "due"


def test_schedule_daily_overdue_catches_up_to_next_future_slot(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)
    created = backend.create_task(
        list_name="christophe",
        title="Daily brief",
        due_at=datetime(2026, 4, 30, 8, 18),
        recurrence_rule="daily",
        actor_id="christophe",
        repeat_from="due",
    )

    assert backend.complete_task(created.task_id, completed_at=datetime(2026, 5, 4, 8, 30))

    next_occurrence = next(t for t in backend.read_tasks(include_completed=False) if "Daily brief" in t.title)
    assert next_occurrence.due_at == datetime(2026, 5, 5, 8, 18)
    assert next_occurrence.repeat_from == "due"


def test_schedule_weekly_overdue_catches_up_to_next_future_slot(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)
    created = backend.create_task(
        list_name="christophe",
        title="Weekly brief",
        due_at=datetime(2026, 4, 6, 7, 0),
        recurrence_rule="weekly",
        actor_id="christophe",
        repeat_from="due",
    )

    assert backend.complete_task(created.task_id, completed_at=datetime(2026, 5, 4, 8, 0))

    next_occurrence = next(t for t in backend.read_tasks(include_completed=False) if "Weekly brief" in t.title)
    assert next_occurrence.due_at == datetime(2026, 5, 11, 7, 0)
    assert next_occurrence.repeat_from == "due"


def test_schedule_monthly_overdue_catches_up_to_next_future_slot(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)
    created = backend.create_task(
        list_name="christophe",
        title="Monthly review",
        due_at=datetime(2026, 1, 31, 7, 0),
        recurrence_rule="monthly",
        actor_id="christophe",
        repeat_from="due",
    )

    assert backend.complete_task(created.task_id, completed_at=datetime(2026, 5, 4, 8, 0))

    next_occurrence = next(t for t in backend.read_tasks(include_completed=False) if "Monthly review" in t.title)
    assert next_occurrence.due_at == datetime(2026, 5, 28, 7, 0)
    assert next_occurrence.repeat_from == "due"


def test_repeat_from_completion_weekly_advances_from_completed_time(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)
    created = backend.create_task(
        list_name="christophe",
        title="Weekly from completion",
        due_at=datetime(2026, 5, 4, 8, 0),
        recurrence_rule="weekly",
        actor_id="christophe",
        repeat_from="completion",
    )

    assert backend.complete_task(created.task_id, completed_at=datetime(2026, 5, 6, 15, 0))

    next_occurrence = next(t for t in backend.read_tasks(include_completed=False) if "Weekly from completion" in t.title)
    assert next_occurrence.due_at == datetime(2026, 5, 13, 15, 0)
    assert next_occurrence.repeat_from == "completion"


def test_twodo_backend_omits_empty_locations(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="No location task",
        notes="human note",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert "locations" not in payload


def test_repeat_from_completion_hourly_advances_from_completed_time(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)
    created = backend.create_task(
        list_name="catherine",
        title="Inbox processing",
        due_at=datetime(2026, 4, 14, 9, 0),  # overdue original schedule
        recurrence_rule="hourly",
        actor_id="catherine",
        repeat_from="completion",
    )
    assert created.repeat_from == "completion"

    # Complete the task late — next run must be 1 hour after completion, not schedule.
    assert backend.complete_task(created.task_id, completed_at=datetime(2026, 4, 15, 14, 30))

    all_tasks = backend.read_tasks(include_completed=False)
    next_occurrence = next((t for t in all_tasks if "Inbox processing" in t.title), None)
    assert next_occurrence is not None
    assert next_occurrence.task_id != created.task_id
    assert next_occurrence.due_at == datetime(2026, 4, 15, 15, 30)
    assert next_occurrence.recurrence_rule == "hourly"
    assert next_occurrence.repeat_from == "completion"

    # Native 2Do bitmask: bit 8 (256) is NOT set for "from completion" (2Do uses 0 for completion).
    raw_payload = unpack_archive(load_archive(next_occurrence.path))
    assert not (int(raw_payload["repeattype"]) & 256)


def test_repeat_from_schedule_roundtrip(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="catherine",
        title="Daily from completion",
        due_at=datetime(2026, 4, 14, 9, 0),
        recurrence_rule="daily",
        actor_id="catherine",
        repeat_from="completion",
    )

    fetched = backend.read_task(created.task_id)
    assert fetched is not None
    assert fetched.repeat_from == "completion"


def test_repeat_from_default_is_due_and_repeattype_zero_for_nonrecurring(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Non-recurring tasks must have repeattype=0 and tasktype='0' to be visible in 2Do iOS.

    Previously repeat_from defaulted to 'schedule' which set bit 256, causing tasks
    to be invisible in the 2Do iOS app. The correct default is 'due' (repeattype=0).
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="catherine",
        title="Default repeat_from task",
        actor_id="catherine",
    )
    # Default repeat_from is now "due" so non-recurring tasks get repeattype=0
    assert created.repeat_from == "due"

    payload = unpack_archive(load_archive(created.path))
    # No metadata block at all.
    assert "--- AgentForge ---" not in str(payload.get("notes", ""))
    # Non-recurring task: repeattype must be 0 (no bits set) — matches 2Do iOS native format.
    assert int(payload.get("repeattype", "0")) == 0
    # tasktype must be "0" (integer string) — not "task" — matches 2Do iOS native format.
    assert payload.get("tasktype") == "0"
    # acttype must be "-1" (default/no action) — matches 2Do iOS native format.
    assert payload.get("acttype") == "-1"
    # ruid must be "0" for non-recurring tasks.
    assert payload.get("ruid") == "0"


# ---------------------------------------------------------------------------
# iOS native field compatibility tests
# Derived from real 2Do tasks created on iOS and read back from Dropbox.
# Reference tasks captured 2026-05-13:
#   - "Task de base due today"           (with due date today, 5 PM)
#   - "Task de base due tomorrow..."     (with due date tomorrow, 5 PM)
#   - "Voici mon test à moi via iOS"     (no due date, native iOS)
# ---------------------------------------------------------------------------


def test_new_task_is_not_immediately_completed(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """A freshly created task must never have iscomp=1 — this was a regression bug."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Fresh task",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("iscomp") == "0", "New task must not be marked completed"
    assert created.is_completed is False


def test_task_without_due_date_has_no_due_fields(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """No due date → due absent from payload, duetime=999999.000000, duedateabs absent.

    Matches iOS native format: tasks without a due date omit 'due' and 'duedateabs'
    and use the sentinel value 999999.000000 for duetime.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="No due date task",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    # due must be absent or None — not a date string
    assert payload.get("due") is None, f"Expected no 'due' field, got {payload.get('due')!r}"
    # duetime must be the sentinel value
    assert payload.get("duetime") == "999999.000000", f"Expected sentinel duetime, got {payload.get('duetime')!r}"
    # duedateabs must be absent or None
    assert payload.get("duedateabs") is None, f"Expected no 'duedateabs', got {payload.get('duedateabs')!r}"


def test_task_with_due_date_and_time_has_correct_fields(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Due date with time → due='YYYY-MM-DD', duetime='HHMM.000000', duedateabs=midnight timestamp.

    Matches iOS native format observed in "Task de base due today" and "due tomorrow":
      due: '2026-05-14'
      duedateabs: '1778760000.000000'  (midnight of that date)
      duetime: '1700.000000'           (17:00 = 5 PM, HHMM format)
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    due = datetime(2026, 5, 14, 17, 0)
    created = backend.create_task(
        list_name="architect",
        title="Task due tomorrow at 5 PM",
        due_at=due,
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("due") == "2026-05-14"
    # duetime must be HHMM.000000 format — not 999999
    assert payload.get("duetime") == "1700.000000", f"Expected '1700.000000', got {payload.get('duetime')!r}"
    # duedateabs must be the midnight timestamp for that date
    assert payload.get("duedateabs") is not None
    # Midnight 2026-05-14 in America/Montreal = timestamp (verify it's not 0/sentinel)
    abs_val = float(payload["duedateabs"])
    assert abs_val > 0, "duedateabs should be a real timestamp"
    # Verify it is close to midnight of the due date (within 24 hours)
    due_midnight = datetime(2026, 5, 14, 0, 0)
    from zoneinfo import ZoneInfo
    local_midnight = due_midnight.replace(tzinfo=ZoneInfo("America/Montreal"))
    assert abs(abs_val - local_midnight.timestamp()) < 3600, "duedateabs should be midnight of due date"


def test_task_all_day_has_sentinel_duetime(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """All-day task → duetime=999999.000000 (no time), due present, duedateabs present."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="All-day task",
        due_at=datetime(2026, 5, 14, 0, 0),  # midnight = all-day
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("due") == "2026-05-14"
    assert payload.get("duetime") == "999999.000000", "All-day task must have sentinel duetime"
    assert payload.get("duedateabs") is not None


def test_priority_high_maps_to_one(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """priority='high' → '1' in the raw payload (matches 2Do iOS priority encoding)."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="High priority task",
        priority="high",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("priority") == "1", f"Expected '1' for high priority, got {payload.get('priority')!r}"


def test_priority_low_maps_to_two(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """priority='low' → '2' in the raw payload."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Low priority task",
        priority="low",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("priority") == "2", f"Expected '2' for low priority, got {payload.get('priority')!r}"


def test_priority_medium_maps_to_zero(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """priority='medium' (default) → '0' in the raw payload."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Medium priority task",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("priority") == "0", f"Expected '0' for medium priority, got {payload.get('priority')!r}"


def test_starred_task_field(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Starred tasks must have starred='1' in the payload."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Starred task",
        actor_id="architect",
    )
    # Update via the model directly then write
    created.starred = True
    backend._write_task(created)

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("starred") == "1", "Starred task must have starred='1'"


def test_recurring_task_repeattype_and_ruid(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Recurring tasks must have repeattype=256 (schedule bit) and ruid=task_id.

    This is the native 2Do bit that signals 'repeat from due date'. Non-recurring
    tasks must have repeattype=0. Confirmed by native iOS task inspection.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Daily recurring task",
        due_at=datetime(2026, 5, 14, 9, 0),
        recurrence_rule="daily",
        repeat_from="schedule",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    # repeattype bit 256 must be set for "repeat from due date"
    assert int(payload.get("repeattype", "0")) & 256, "Recurring task (schedule) must have bit 256 set"
    # ruid must be the task_id for recurring tasks
    assert payload.get("ruid") == created.task_id, f"Recurring task ruid must match task_id, got {payload.get('ruid')!r}"


def test_notes_field_stored_and_retrieved(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Notes field must be stored in the payload and round-trip correctly."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Task with note",
        notes="This is the note content.\nWith a second line.",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert "This is the note content." in payload.get("notes", ""), "Notes must be stored in payload"

    fetched = backend.read_task(created.task_id)
    assert fetched is not None
    assert "This is the note content." in fetched.notes


def test_todo_add_em_dash_splits_title_and_notes(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """todo-add 'title — note' must store title in title field and note in notes field.

    The em-dash (—) separator is used by todo_command.sh to split long task strings.
    Previously, the entire string was stored as title and notes was left empty.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    # Simulate what todo-add does: pass the full string as title
    full_string = "Do the thing — full context goes here for the heartbeat to execute"
    created = backend.create_task(
        list_name="architect",
        title=full_string,
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    # The em-dash split is handled by todo_command.sh upstream, not backend.
    # The backend should store exactly what it receives.
    # This test documents the current behaviour (no auto-split in backend).
    assert payload.get("title") == full_string


def test_complete_task_sets_iscomp_one(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """complete_task() must set iscomp='1' in the raw payload."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Task to complete",
        actor_id="architect",
    )
    backend.complete_task(created.task_id, completed_at=datetime(2026, 5, 14, 10, 0))

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("iscomp") == "1", "Completed task must have iscomp='1'"


def test_ios_native_field_set_present(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Our generated tasks must include all fields present in native iOS-created tasks.

    Fields confirmed required from real iOS tasks: taskduration, locationalerttype,
    hasimage, hasaudio. Missing these fields could cause 2Do to reject the file.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="iOS field set test",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    ios_required_fields = {"taskduration", "locationalerttype", "hasimage", "hasaudio"}
    missing = ios_required_fields - set(payload.keys())
    assert not missing, f"Missing iOS-required fields: {missing}"


def test_twodo_backend_drops_legacy_raw_locations(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Legacy location task",
        notes="human note",
        actor_id="architect",
    )
    created.raw["locations"] = []
    backend._write_task(created)

    payload = unpack_archive(load_archive(created.path))
    assert "locations" not in payload


# ---------------------------------------------------------------------------
# iOS task matrix tests — derived from real 2Do tasks created by Martin on
# iOS 2026-05-13, covering every field combination he exercised.
#
# Reference tasks (all in Dropbox/Apps/2Do/tod/, caluid ca51b1e7...):
#   uid 7551a9436a574b8d9c0d93a0f3ff8f00 — "Task de base due today" (due today 17:00)
#   uid 3f8a65fb760a491bb03da17c92ad87c8 — "Task de base due tomorrow..." (due tomorrow 17:00, alarm)
#   uid 7f799944a4934d20912a4a23d11671e1 — "Voici mon test à moi via iOS" (no due, with notes, status=3)
#   uid 50440a410c6a408fa444d6a9ca12ee80 — "Test avec tag" (two tags, no due)
#   uid d426830d235a4f1ca9cb4e44848ece2f — "Test due date" (2026-05-29 15:57, one alarm relative+auto)
#   uid ec22de02f05e45b6b1d3e61d753226f2 — "Test with alert" (2 alarms: manual before + auto)
#   uid d20ee564a11b4d0b88da68f14953a0cf — "Test avec alert" (alarm with absdate)
#   uid 998b4195bf8847babee87c5a5748f15a — "Testing repeat with end date" (daily, recurrenceendtype=1)
#   uid e7dddbad310d4b7685b765687e1d77c3 — "TEST MINIMAL" (minimal, ruid='', no hasaudio/hasimage)
#   uid 40bea022a36a4e3ba2227a8efbd76329 — "TEST task with note — this is note" (note, ruid='0')
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Real iOS task parsing tests — read from Dropbox if available
# ---------------------------------------------------------------------------


def _real_task(uid: str) -> "dict | None":
    """Load a real iOS task from Dropbox if available."""
    import gzip
    import plistlib

    tod_dir = Path("/home/agentforge/Dropbox/Apps/2Do/tod/")
    if not tod_dir.exists():
        return None
    pattern = f"*i_{uid}_d_.tod"
    matches = list(tod_dir.glob(pattern))
    if not matches:
        return None
    try:
        archive = load_archive(matches[0])
        payload = unpack_archive(archive)
        return payload if isinstance(payload, dict) else None
    except Exception:
        return None


@pytest.mark.parametrize("uid,expected_due,expected_duetime", [
    # "Task de base due today" — due 2026-05-13 17:00
    ("7551a9436a574b8d9c0d93a0f3ff8f00", "2026-05-13", "1700.000000"),
    # "Task de base due tomorrow avec alerte thu 14 5:00 PM" — due 2026-05-14 17:00
    ("3f8a65fb760a491bb03da17c92ad87c8", "2026-05-14", "1700.000000"),
    # "Test due date" — due 2026-05-29 15:57
    ("d426830d235a4f1ca9cb4e44848ece2f", "2026-05-29", "1557.000000"),
    # "Test with alert" — due 2026-05-15 17:00
    ("ec22de02f05e45b6b1d3e61d753226f2", "2026-05-15", "1700.000000"),
])
def test_real_ios_task_due_date_fields(uid: str, expected_due: str, expected_duetime: str) -> None:
    """Real iOS tasks encode due date and time in expected formats.

    due: 'YYYY-MM-DD', duetime: 'HHMM.000000' (not 999999), duedateabs: present.
    Confirmed from Martin's iOS test tasks created 2026-05-13.
    """
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    assert payload.get("due") == expected_due, f"Expected due={expected_due!r}, got {payload.get('due')!r}"
    assert payload.get("duetime") == expected_duetime, f"Expected duetime={expected_duetime!r}, got {payload.get('duetime')!r}"
    assert payload.get("duedateabs") is not None, "duedateabs must be present when due date is set"
    abs_val = float(payload["duedateabs"])
    assert abs_val > 0, "duedateabs must be a positive timestamp"


@pytest.mark.parametrize("uid", [
    "7f799944a4934d20912a4a23d11671e1",  # "Voici mon test à moi via iOS"
    "50440a410c6a408fa444d6a9ca12ee80",  # "Test avec tag"
])
def test_real_ios_task_no_due_date(uid: str) -> None:
    """Real iOS tasks with no due date have duetime=999999.000000 and no due/duedateabs.

    This is the iOS native sentinel for 'no due date'.
    """
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    assert payload.get("duetime") == "999999.000000", f"Expected sentinel duetime, got {payload.get('duetime')!r}"
    # due and duedateabs should be absent or None (both are valid in iOS payloads)
    due = payload.get("due")
    assert due is None or due == "" or due == "0", f"Expected no due date, got {due!r}"


def test_real_ios_task_with_tags() -> None:
    """iOS encodes tags as a pipe-delimited string with a specific separator format.

    Observed format: 'tag1_~|$$@$$|~_<order>_~|$$@$$|~__~|$$@$$|~_<idx>_~|$$@$$|~_<uuid>_~|..._+$$|$$+_tag2_~|...'
    Multiple tags are separated by '_+$$|$$+_'.
    The backend must parse and preserve this format.
    """
    uid = "50440a410c6a408fa444d6a9ca12ee80"  # "Test avec tag" — tag1 + tag2
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    tags_raw = payload.get("tags", "")
    assert tags_raw, "Expected tags field to be present and non-empty"
    assert "tag1" in tags_raw, f"Expected 'tag1' in tags, got {tags_raw!r}"
    assert "tag2" in tags_raw, f"Expected 'tag2' in tags, got {tags_raw!r}"
    # Multi-tag separator
    assert "_+$$|$$+_" in tags_raw, "Multiple tags must use '_+$$|$$+_' separator"


def test_real_ios_task_with_relative_alarm() -> None:
    """iOS tasks with a relative alarm have alarms list with reltrig field.

    'Task de base due tomorrow' has one auto alarm at reltrig=61200 (17 hrs after due).
    'Test due date' has reltrig=57420 with relduetime=1 (auto alarm).
    """
    uid = "3f8a65fb760a491bb03da17c92ad87c8"  # due tomorrow + auto alarm
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    alarms = payload.get("alarms", [])
    assert len(alarms) > 0, "Expected at least one alarm"
    alarm = alarms[0]
    assert "reltrig" in alarm or "relduetrig" in alarm, "Alarm must have reltrig or relduetrig"
    assert alarm.get("action") == "CalAlarmActionSound", f"Expected CalAlarmActionSound, got {alarm.get('action')!r}"
    assert alarm.get("sound") == "Basso", f"Expected Basso sound, got {alarm.get('sound')!r}"
    assert alarm.get("isauto") in ("0", "1"), "isauto must be '0' or '1'"


def test_real_ios_task_with_multiple_alarms() -> None:
    """iOS tasks can have multiple alarms: one manual, one auto.

    'Test with alert' (ec22de...) has:
      - alarm[0]: reltrig=-46140 (manual, ~12.8 hours before due)
      - alarm[1]: reltrig=61200 (auto, 17 hours after due midnight)
    """
    uid = "ec22de02f05e45b6b1d3e61d753226f2"  # "Test with alert"
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    alarms = payload.get("alarms", [])
    assert len(alarms) == 2, f"Expected 2 alarms, got {len(alarms)}: {alarms}"
    # Manual alarm (before due date)
    manual = next((a for a in alarms if a.get("isauto") == "0"), None)
    assert manual is not None, "Expected one manual alarm (isauto='0')"
    reltrig_manual = float(manual.get("reltrig", 0))
    assert reltrig_manual < 0, f"Manual alarm should fire before due (negative reltrig), got {reltrig_manual}"
    # Auto alarm
    auto = next((a for a in alarms if a.get("isauto") == "1"), None)
    assert auto is not None, "Expected one auto alarm (isauto='1')"


def test_real_ios_task_with_absolute_alarm() -> None:
    """iOS supports absolute-date alarms (absdate field) in addition to relative ones.

    'Test avec alert' (d20ee5...) has alarm with absdate='2026-05-14 09:17:00 GMT-04:00'
    and absdateint=1778750220.000000.
    """
    uid = "d20ee564a11b4d0b88da68f14953a0cf"  # "Test avec alert"
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    alarms = payload.get("alarms", [])
    assert len(alarms) > 0, "Expected at least one alarm"
    alarm = alarms[0]
    assert "absdate" in alarm or "absdateint" in alarm, (
        "Absolute-date alarm must have 'absdate' or 'absdateint' field"
    )


def test_real_ios_recurring_task_with_end_date() -> None:
    """Recurring tasks with an end date have recurrenceenddate and recurrenceendtype=1.

    'Testing repeat with end date' (998b41...) is daily, ends ~2026-06-13:
      recurrence: '1', repeattype: '256', repeatval: '1'
      recurrenceendtype: '1' (has end date — vs '0' = no end)
      recurrenceenddate: '1781352000.000000' (the end date as timestamp)
    """
    uid = "998b4195bf8847babee87c5a5748f15a"  # "Testing repeat with end date"
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    assert payload.get("recurrenceendtype") == "1", (
        f"Task with end date must have recurrenceendtype='1', got {payload.get('recurrenceendtype')!r}"
    )
    assert payload.get("recurrenceenddate") is not None, "recurrenceenddate must be present"
    end_ts = float(payload["recurrenceenddate"])
    assert end_ts > 0, "recurrenceenddate must be a positive timestamp"
    # Confirm it is approximately 2026-06-13 (within ±2 days)
    from datetime import timezone
    end_dt = datetime.fromtimestamp(end_ts, tz=timezone.utc)
    assert end_dt.year == 2026, f"Expected end year 2026, got {end_dt.year}"
    assert end_dt.month == 6, f"Expected end month June, got {end_dt.month}"


def test_real_ios_recurring_task_field_encoding() -> None:
    """Daily recurring tasks use recurrence='1', repeatval='1', repeattype='256', ruid=uid.

    The ruid must equal the uid for recurring tasks (the repeat-series identifier).
    """
    uid = "998b4195bf8847babee87c5a5748f15a"  # "Testing repeat with end date"
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    assert payload.get("recurrence") == "1", "Daily recurrence: recurrence='1'"
    assert payload.get("repeatval") == "1", "Daily recurrence: repeatval='1'"
    assert int(payload.get("repeattype", "0")) & 256, "Recurring task must have bit 256 set in repeattype"
    assert payload.get("ruid") == uid, f"ruid must equal uid={uid!r}, got {payload.get('ruid')!r}"


def test_real_ios_task_status_field_values() -> None:
    """iOS tasks use status='1' for open tasks and may use status='3' for deferred/someday.

    'Voici mon test à moi via iOS' has status='3' — this is the iOS 'someday' state.
    """
    uid = "7f799944a4934d20912a4a23d11671e1"  # "Voici mon test à moi via iOS"
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    assert payload.get("status") == "3", (
        f"'Voici mon test' should have status='3' (someday), got {payload.get('status')!r}"
    )
    # Confirm not marked as completed
    assert payload.get("iscomp") == "0", "status=3 task must not be marked completed"


def test_real_ios_task_ruid_empty_for_non_recurring() -> None:
    """Non-recurring iOS tasks have ruid='' (empty string) or '0'.

    The 'Task de base due today' (no recurrence) has ruid=''.
    The 'TEST task with note' (created by backend then re-synced) has ruid='0'.
    """
    uid_no_recur = "7551a9436a574b8d9c0d93a0f3ff8f00"  # "Task de base due today"
    payload = _real_task(uid_no_recur)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    ruid = payload.get("ruid", "")
    assert ruid in ("", "0", None), f"Non-recurring task ruid must be empty or '0', got {ruid!r}"


def test_real_ios_task_entity_is_task() -> None:
    """All task .tod files have entity='task'."""
    uids = [
        "7551a9436a574b8d9c0d93a0f3ff8f00",  # due today
        "50440a410c6a408fa444d6a9ca12ee80",  # with tags
        "998b4195bf8847babee87c5a5748f15a",  # recurring with end date
    ]
    for uid in uids:
        payload = _real_task(uid)
        if payload is None:
            pytest.skip("Real 2Do Dropbox tasks not available in this environment.")
        assert payload.get("entity") == "task", f"uid={uid}: entity must be 'task', got {payload.get('entity')!r}"


def test_real_ios_task_notes_with_multiline() -> None:
    """iOS tasks store multiline notes as a single string with \\n newlines.

    All Martin's test tasks have a standard multi-paragraph note body.
    """
    uid = "7f799944a4934d20912a4a23d11671e1"  # "Voici mon test à moi via iOS" — has notes
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    notes = payload.get("notes", "")
    assert notes, "Expected non-empty notes"
    # Notes are stored as a plain string (not encoded)
    assert isinstance(notes, str), f"Notes must be str, got {type(notes).__name__}"


# ---------------------------------------------------------------------------
# Backend synthesis tests — verify our backend produces payloads compatible
# with what iOS native tasks look like (derived from the matrix above)
# ---------------------------------------------------------------------------


def test_backend_duedateabs_is_valid_for_specific_date(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """duedateabs for 2026-05-13 must be a positive timestamp near midnight of that date.

    iOS observed: 1778673600 (midnight UTC on 2026-05-13).
    Our backend stores midnight local (Montreal), which is 1778644800.
    Either is acceptable — what matters is it's within ±24h of the correct date.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Task due today at 5pm",
        due_at=datetime(2026, 5, 13, 17, 0),
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("due") == "2026-05-13"
    assert payload.get("duetime") == "1700.000000"
    abs_val = float(payload["duedateabs"])
    # Must be within 24 hours either side of midnight UTC on 2026-05-13
    midnight_utc_2026_05_13 = 1778673600.0
    assert abs(abs_val - midnight_utc_2026_05_13) <= 86400, (
        f"duedateabs {abs_val} is not within 24h of midnight UTC {midnight_utc_2026_05_13}"
    )


def test_backend_alarm_roundtrip_via_model(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Alarms attached via task.alarms are preserved through write/read roundtrip.

    The TwoDoAlarm.raw dict contains the full iOS alarm payload.  The backend uses
    alarm.raw (if present) when serialising, so all iOS fields survive the cycle.
    iOS alarm fields: action, sound, reltrig, relduetime, isauto, issnooze, entity, deleted.
    """
    from agentforge.twodo.models import TwoDoAlarm

    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Task with alarm",
        due_at=datetime(2026, 5, 15, 17, 0),
        actor_id="architect",
    )

    # iOS-style relative alarm — attached via the model (not raw dict injection)
    ios_alarm_raw = {
        "relduetrig": "0.000000",
        "entity": "alarm",
        "isanniversary": "0",
        "uid": "aabbcc1122334455aabbcc1122334455",
        "sound": "Basso",
        "reltrig": "61200.000000",
        "url": "",
        "lreltrig": "61200.000000",
        "relduetime": "1",
        "isbirthday": "0",
        "action": "CalAlarmActionSound",
        "issnooze": "0",
        "deleted": "0",
        "taskuid": created.task_id,
        "status": "1",
        "isauto": "1",
    }
    created.alarms = [
        TwoDoAlarm(
            trigger_offset_seconds=61200,
            sound="Basso",
            action="CalAlarmActionSound",
            raw=ios_alarm_raw,
        )
    ]
    backend._write_task(created)

    payload = unpack_archive(load_archive(created.path))
    alarms = payload.get("alarms", [])
    assert len(alarms) == 1, f"Expected 1 alarm, got {len(alarms)}"
    alarm = alarms[0]
    assert alarm.get("action") == "CalAlarmActionSound"
    assert alarm.get("sound") == "Basso"
    assert alarm.get("reltrig") == "61200.000000"
    assert alarm.get("isauto") == "1"


def test_backend_tags_field_preserved_from_raw(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Tags stored in the iOS native format are preserved through write/read roundtrip.

    iOS tags format: 'tag1_~|$$@$$|~_<order>_~|$$@$$|~__~|$$@$$|~_<idx>_~|$$@$$|~_<uuid>_...'
    Multiple tags are separated by '_+$$|$$+_'.
    When present in raw, the backend must preserve this field.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Task with ios tags",
        actor_id="architect",
    )

    ios_tags = (
        "tag1_~|$$@$$|~_0_~|$$@$$|~__~|$$@$$|~_1_~|$$@$$|~_fbad121f69a9448ab3e53839613a31cd"
        "_~|$$@$$|~__~|$$@$$|~__~|$$@$$|~_0"
        "_+$$|$$+_"
        "tag2_~|$$@$$|~_0_~|$$@$$|~__~|$$@$$|~_2_~|$$@$$|~_a223888d26984b7c8b113bc14f798960"
        "_~|$$@$$|~__~|$$@$$|~__~|$$@$$|~_0"
    )
    created.raw["tags"] = ios_tags
    backend._write_task(created)

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("tags") == ios_tags, (
        f"iOS tags format must survive roundtrip.\n"
        f"Expected: {ios_tags!r}\n"
        f"Got:      {payload.get('tags')!r}"
    )


def test_backend_non_recurring_has_ruid_zero(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Non-recurring tasks must have ruid='0' — never empty string.

    iOS non-recurring tasks observed with ruid='0' (from backend-generated tasks
    synced to Dropbox then back). Confirmed on uid 40bea022... ('TEST task with note').
    ruid='' is also valid from iOS native tasks; '0' is the AgentForge standard.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Simple non-recurring task",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    ruid = payload.get("ruid", "")
    assert ruid == "0", f"Non-recurring backend task must have ruid='0', got {ruid!r}"


def test_backend_recurring_task_ruid_equals_task_id(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Recurring tasks must have ruid == task_id, matching iOS native behaviour.

    iOS native: '998b4195bf8847babee87c5a5748f15a' has ruid='998b4195bf8847babee87c5a5748f15a'.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Daily recurring task",
        due_at=datetime(2026, 5, 13, 17, 0),
        recurrence_rule="daily",
        repeat_from="schedule",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("ruid") == created.task_id, (
        f"Recurring task ruid must equal task_id={created.task_id!r}, got {payload.get('ruid')!r}"
    )


def test_backend_task_duetime_format_hhmm(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """duetime must be zero-padded HHMM.000000, not raw integer.

    iOS observed: hour=7, minute=47 → '0747.000000' (zero-padded).
    For 17:00 → '1700.000000'. For 15:57 → '1557.000000'.
    Ensure hours < 10 are zero-padded to 4 characters total.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Early morning task",
        due_at=datetime(2026, 5, 20, 7, 47),  # 7:47 AM → must be '0747.000000'
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("duetime") == "0747.000000", (
        f"7:47 AM must produce duetime='0747.000000', got {payload.get('duetime')!r}"
    )


def test_backend_task_acttype_minus_one_for_standard_tasks(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Standard tasks (no action URL, no special type) must have acttype='-1'.

    iOS native test tasks all have acttype='-1' for standard tasks.
    acttype='0' is used for tasks with special action types.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Standard task",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("acttype") == "-1", (
        f"Standard task must have acttype='-1', got {payload.get('acttype')!r}"
    )


def test_backend_task_standard_string_fields_present(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """All iOS-required string fields must be present with correct defaults.

    Derived from the minimal iOS task 'TEST MINIMAL - meme format iOS' (e7dddb...) which
    has every field that iOS populates. Our backend must produce the same set.
    Required: entity='task', wasreceived='0', wassent='0', isanniversary='0',
    isbirth='0', deleted='0', expanded='0', sortfield='0', sortorder='0',
    displayorder='0', startdaydelay='0', taskduration='0', locationalerttype='0'.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Minimal iOS compatible task",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    expected_defaults = {
        "entity": "task",
        "wasreceived": "0",
        "wassent": "0",
        "isanniversary": "0",
        "isbirth": "0",
        "deleted": "0",
        "sortfield": "0",
        "sortorder": "0",
        "displayorder": "0",
        "startdaydelay": "0",
        "taskduration": "0",
        "locationalerttype": "0",
        "recurrenceendrepeats": "0",
        "recurrenceendrepeatsorig": "0",
        "recurrenceendtype": "0",
    }
    for field_name, expected_value in expected_defaults.items():
        actual = payload.get(field_name)
        assert actual == expected_value, (
            f"Field {field_name!r}: expected {expected_value!r}, got {actual!r}"
        )


def test_backend_failure_count_roundtrip(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """af_failure_count is stored as a string and parsed back correctly.

    Real iOS task 'Veille — Product Builder' has af_failure_count='4' stored natively.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Task that will fail",
        actor_id="architect",
    )
    backend.record_failure(
        created.task_id,
        retry_after=datetime(2026, 5, 14, 9, 0),
        error="Something went wrong",
    )

    fetched = backend.read_task(created.task_id)
    assert fetched is not None
    assert fetched.failure_count == 1
    assert fetched.last_error == "Something went wrong"
    assert fetched.retry_after == datetime(2026, 5, 14, 9, 0)

    # Record a second failure
    backend.record_failure(created.task_id, retry_after=datetime(2026, 5, 15, 9, 0), error="Again")
    fetched2 = backend.read_task(created.task_id)
    assert fetched2 is not None
    assert fetched2.failure_count == 2


def test_backend_escalation_task_id_roundtrip(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """af_escalation_task_id is stored and retrieved correctly.

    Real iOS task (4e3a92...) has af_escalation_task_id stored natively in the .tod file.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Task with escalation",
        actor_id="architect",
    )
    escalation_id = "adfa2d46a7d641e891edaee8dd6bfe7c"
    backend.record_failure(
        created.task_id,
        retry_after=datetime(2026, 5, 14, 9, 0),
        escalation_task_id=escalation_id,
    )

    fetched = backend.read_task(created.task_id)
    assert fetched is not None
    assert fetched.escalation_task_id == escalation_id

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("af_escalation_task_id") == escalation_id


def test_backend_af_completed_at_stored_as_iso(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """af_completed_at is stored as ISO 8601 string 'YYYY-MM-DDTHH:MM:SS'.

    Observed in real completed tasks: '2026-05-13T22:56:00'.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Task to complete",
        actor_id="architect",
    )
    completed_at = datetime(2026, 5, 13, 22, 56, 0)
    backend.complete_task(created.task_id, completed_at=completed_at)

    payload = unpack_archive(load_archive(created.path))
    af_completed_at = payload.get("af_completed_at")
    assert af_completed_at is not None, "af_completed_at must be present after completion"
    assert af_completed_at == "2026-05-13T22:56:00", (
        f"Expected ISO format '2026-05-13T22:56:00', got {af_completed_at!r}"
    )


def test_backend_defer_task_updates_due_and_next_run_override(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """defer_task() updates due_at and stores af_deferred_until in the payload."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Task to defer",
        due_at=datetime(2026, 5, 13, 9, 0),
        actor_id="architect",
    )
    new_due = datetime(2026, 5, 20, 9, 0)
    result = backend.defer_task(created.task_id, due_at=new_due)
    assert result is True

    fetched = backend.read_task(created.task_id)
    assert fetched is not None
    assert fetched.due_at == new_due
    assert fetched.next_run_override == new_due

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("af_deferred_until") == "2026-05-20T09:00"
    assert payload.get("due") == "2026-05-20"
    assert payload.get("duetime") == "0900.000000"


def test_backend_update_task_changes_title_and_priority(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """update_task() correctly updates title and priority fields."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Original title",
        priority="medium",
        actor_id="architect",
    )

    result = backend.update_task(created.task_id, title="Updated title", priority="high")
    assert result is True

    fetched = backend.read_task(created.task_id)
    assert fetched is not None
    assert fetched.title == "Updated title"
    assert fetched.priority == "high"

    payload = unpack_archive(load_archive(created.path))
    assert payload.get("title") == "Updated title"
    assert payload.get("priority") == "1"  # high = '1'


def test_backend_recurring_task_prevents_duplicate_on_double_complete(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Completing the same recurring task twice does not create two next-occurrence tasks.

    Guards against the heartbeat completing the same task in two parallel invocations.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Daily dedup task",
        due_at=datetime(2026, 5, 13, 9, 0),
        recurrence_rule="daily",
        repeat_from="schedule",
        actor_id="architect",
    )

    backend.complete_task(created.task_id, completed_at=datetime(2026, 5, 13, 9, 5))
    # Mark original completed again (simulate double-fire)
    original = backend.read_task(created.task_id)
    assert original is not None and original.is_completed

    # There should be exactly one next-occurrence task (not two)
    all_open = backend.read_tasks(include_completed=False)
    pending = [t for t in all_open if "Daily dedup task" in t.title]
    assert len(pending) == 1, f"Expected exactly 1 pending next-occurrence, got {len(pending)}: {[t.task_id for t in pending]}"


def test_backend_read_tasks_excludes_completed_by_default(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """read_tasks() without include_completed=True excludes completed tasks."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    open_task = backend.create_task(list_name="architect", title="Open task", actor_id="architect")
    done_task = backend.create_task(list_name="architect", title="Done task", actor_id="architect")
    backend.complete_task(done_task.task_id, completed_at=datetime(2026, 5, 13, 10, 0))

    open_tasks = backend.read_tasks(include_completed=False)
    open_ids = [t.task_id for t in open_tasks]
    assert open_task.task_id in open_ids, "Open task must appear in read_tasks()"
    assert done_task.task_id not in open_ids, "Completed task must NOT appear in read_tasks()"

    all_tasks = backend.read_tasks(include_completed=True)
    all_ids = [t.task_id for t in all_tasks]
    assert done_task.task_id in all_ids, "Completed task must appear when include_completed=True"


def test_backend_read_tasks_filters_by_list(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """read_tasks(list_id=...) only returns tasks from that list."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    task_a = backend.create_task(list_name="listA", title="Task in A", actor_id="architect")
    task_b = backend.create_task(list_name="listB", title="Task in B", actor_id="architect")

    list_a = backend.resolve_list("listA")
    tasks_in_a = backend.read_tasks(list_id=list_a.list_id)
    ids_in_a = [t.task_id for t in tasks_in_a]

    assert task_a.task_id in ids_in_a, "Task in listA must appear when filtered to listA"
    assert task_b.task_id not in ids_in_a, "Task in listB must NOT appear when filtered to listA"


def test_backend_nonexistent_task_returns_none(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """read_task() returns None for a task_id that does not exist."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    result = backend.read_task("00000000000000000000000000000000")
    assert result is None


def test_backend_complete_nonexistent_task_returns_false(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """complete_task() returns False when the task does not exist."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    result = backend.complete_task("00000000000000000000000000000000")
    assert result is False


def test_backend_update_nonexistent_task_returns_false(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """update_task() returns False when the task does not exist."""
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    result = backend.update_task("00000000000000000000000000000000", title="New")
    assert result is False


def test_backend_weekly_recurrence_repeattype_set(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Weekly recurring tasks with repeat_from='schedule' must have repeattype bit 256 set.

    Verified against iOS native weekly task (Veille — Product Builder, uid 78909a41...).
    Note: that specific task has repeattype='0' because it uses repeat_from='completion'.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Weekly schedule task",
        due_at=datetime(2026, 5, 20, 7, 0),
        recurrence_rule="weekly",
        repeat_from="schedule",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert int(payload.get("repeattype", "0")) & 256, (
        "Weekly task with repeat_from='schedule' must have bit 256 set"
    )
    assert payload.get("ruid") == created.task_id


def test_backend_weekly_completion_repeattype_zero(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Weekly recurring tasks with repeat_from='completion' must NOT have bit 256 set.

    iOS native 'Veille — Product Builder' (78909a41) has recurrence='weekly' but
    repeattype='0' — because it repeats from completion date, not due date.
    """
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Weekly from completion",
        due_at=datetime(2026, 5, 20, 7, 0),
        recurrence_rule="weekly",
        repeat_from="completion",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert not (int(payload.get("repeattype", "0")) & 256), (
        "Weekly task with repeat_from='completion' must NOT have bit 256 set (got "
        f"repeattype={payload.get('repeattype')!r})"
    )


# ---------------------------------------------------------------------------
# iOS task matrix — NEW use cases from Martin's 2026-05-13 real device tasks
#
# New reference tasks (all in Dropbox/Apps/2Do/tod/, caluid ca51b1e7...):
#   uid 7638bf34b43b4c05834d4cf212eff43a — "This is a checklist" (tasktype=1, lastuid)
#   uid 0972d3c3394a4917bafa716bd093cb81 — "Child of a checklist" (has parent field)
#   uid 2cea6d955c634e40afe3f42fbebb64a7 — "Child 2" (second checklist child)
#   uid 78db1c23950d44a7ba4648146801cc9a — "Testing task switched to project" (tasktype=2)
#   uid 1879a987cd474206b21b4e3ec6b7f865 — "Task inside a project" (parent=project uid)
#   uid 25106d7c18ab4c5e832ea3e90991a394 — "Testing photo and audio" (hasimage=1, hasaudio=1)
#   uid 31222377f0b940a5b21c54f8eb44f141 — "Test location" (locations field, Google result)
#   uid 5c9a8e47e61c47a68d759805d35a1c68 — "Task with a location" (locations field, home)
#   uid d1883656a13d481cbd89ade2d016b2ad — "Testing action: call" (acttype=0)
#   uid ac3ca9536e754cfe818205beb48da186 — "Message action" (acttype=1)
#   uid 7467a262bf494ed7b1bbc0424c25cbb9 — "Email action" (acttype=2)
#   uid 9312ca0d9f6645069dc46e481b976cdb — "Visit contact" (acttype=3)
#   uid 1671827402ca431c97b5f03720f04050 — "Visit address" (acttype=8)
#   uid bbd1692537bf400d96470d0f7569979f — "Browse URL" (acttype=9)
#   uid ad92b74c2e0e4c2792baccc50b726e7e — "Google search" (acttype=10)
#   uid e5feb44b92914795bcb61d3e9e1edebc — "Repeat 2 weeks after completion" (repeattype=257)
#   uid e0363522938d443dbf3b33e9c64def76 — "Alert day after due date" (positive reltrig alarm)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Real iOS task parsing — tasktype field (checklist=1, project=2)
# ---------------------------------------------------------------------------


def test_real_ios_checklist_has_tasktype_one() -> None:
    """iOS checklist tasks have tasktype='1'.

    'This is a checklist' (7638bf...) was created as a task then switched to a checklist.
    tasktype: '0'=task, '1'=checklist, '2'=project.
    Checklist parents also have a 'lastuid' field pointing to themselves.
    """
    uid = "7638bf34b43b4c05834d4cf212eff43a"  # "This is a checklist"
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    assert payload.get("tasktype") == "1", (
        f"Checklist task must have tasktype='1', got {payload.get('tasktype')!r}"
    )
    # Checklist parent has lastuid equal to its own uid
    assert payload.get("lastuid") == uid, (
        f"Checklist parent must have lastuid == uid, got {payload.get('lastuid')!r}"
    )


def test_real_ios_project_has_tasktype_two() -> None:
    """iOS project tasks have tasktype='2'.

    'Testing task switched to project' (78db1c...) was switched from a task to a project.
    Projects also have a 'lastuid' field pointing to themselves (same as checklists).
    """
    uid = "78db1c23950d44a7ba4648146801cc9a"  # "Testing task switched to project"
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    assert payload.get("tasktype") == "2", (
        f"Project task must have tasktype='2', got {payload.get('tasktype')!r}"
    )
    assert payload.get("lastuid") == uid, (
        f"Project must have lastuid == uid, got {payload.get('lastuid')!r}"
    )


def test_real_ios_child_task_has_parent_field() -> None:
    """Child tasks inside a checklist or project have a 'parent' field.

    'Child of a checklist' (0972d3...) is a subtask of 'This is a checklist' (7638bf...).
    The 'parent' field contains the uid of the parent checklist/project.
    Child tasks have tasktype='0' (regular task).
    """
    uid = "0972d3c3394a4917bafa716bd093cb81"  # "Child of a checklist"
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    parent_uid = "7638bf34b43b4c05834d4cf212eff43a"  # "This is a checklist"
    assert payload.get("parent") == parent_uid, (
        f"Child task must have parent='{parent_uid}', got {payload.get('parent')!r}"
    )
    # Child tasks are still regular tasks
    assert payload.get("tasktype") == "0", (
        f"Child task must have tasktype='0', got {payload.get('tasktype')!r}"
    )


# ---------------------------------------------------------------------------
# Real iOS task parsing — media attachments (hasimage, hasaudio)
# ---------------------------------------------------------------------------


def test_real_ios_task_with_photo_and_audio() -> None:
    """iOS tasks with photo and audio attachments have hasimage='1', hasaudio='1'.

    'Testing photo and audio' (25106d...) has both a photo and a voice memo.
    The image UUID is stored in imageuuid and audio UUID in audiouuid.
    """
    uid = "25106d7c18ab4c5e832ea3e90991a394"  # "Testing photo and audio"
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    assert payload.get("hasimage") == "1", (
        f"Task with photo must have hasimage='1', got {payload.get('hasimage')!r}"
    )
    assert payload.get("hasaudio") == "1", (
        f"Task with audio must have hasaudio='1', got {payload.get('hasaudio')!r}"
    )
    # UUID fields must be non-empty strings when media is present
    assert payload.get("imageuuid"), "imageuuid must be non-empty when hasimage='1'"
    assert payload.get("audiouuid"), "audiouuid must be non-empty when hasaudio='1'"


# ---------------------------------------------------------------------------
# Real iOS task parsing — geolocation (locations field)
# ---------------------------------------------------------------------------


def test_real_ios_task_locations_field_format() -> None:
    """iOS locations field uses a pipe-delimited format with a specific separator.

    'Task with a location' (5c9a8e...) — location is 'Home' (named, no address):
      'Home_~|$$@$$|~__~|$$@$$|~_45.547708_~|$$@$$|~_-73.586857_~|$$@$$|~_1_~|$$@$$|~_<uuid>_~|$$@$$|~_0'

    'Test location' (31222377...) — location from Google search (with full address):
      'Café lézard_~|$$@$$|~_3119 Rue Masson..._~|$$@$$|~_45.549512_~|$$@$$|~_-73.574180_~|$$@$$|~_2_~|$$@$$|~_<uuid>_~|$$@$$|~_0'

    Format: name_sep_address_sep_lat_sep_lon_sep_type_sep_uuid_sep_0
    Separator: '_~|$$@$$|~_'
    """
    uid = "5c9a8e47e61c47a68d759805d35a1c68"  # "Task with a location"
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    locations = payload.get("locations", "")
    assert locations, "Task with location must have non-empty locations field"
    assert "_~|$$@$$|~_" in locations, (
        f"locations must use '_~|$$@$$|~_' separator, got {locations!r}"
    )
    # Should contain coordinates (latitude/longitude)
    parts = locations.split("_~|$$@$$|~_")
    assert len(parts) >= 4, f"locations must have at least 4 parts, got {len(parts)}: {parts}"
    # Verify latitude/longitude are numeric
    try:
        lat = float(parts[2])
        lon = float(parts[3])
        assert -90 <= lat <= 90, f"Latitude out of range: {lat}"
        assert -180 <= lon <= 180, f"Longitude out of range: {lon}"
    except (ValueError, IndexError) as e:
        pytest.fail(f"Could not parse lat/lon from locations: {locations!r} — {e}")


def test_real_ios_task_location_with_address_from_google() -> None:
    """iOS location from Google search includes full address in the locations field.

    'Test location' (31222377...) was found by searching via 2Do's Google Maps integration.
    It has a full address: '3119 Rue Masson, Montréal, QC, H1Y 1X9, Canada'.
    """
    uid = "31222377f0b940a5b21c54f8eb44f141"  # "Test location"
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    locations = payload.get("locations", "")
    assert locations, "Task with location must have non-empty locations field"
    assert "Masson" in locations or "Caf" in locations, (
        f"Expected Google Maps location to contain address text, got {locations!r}"
    )


# ---------------------------------------------------------------------------
# Real iOS task parsing — action types (acttype field)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("uid,expected_acttype,label", [
    ("d1883656a13d481cbd89ade2d016b2ad", "0", "call contact"),
    ("ac3ca9536e754cfe818205beb48da186", "1", "message contact"),
    ("7467a262bf494ed7b1bbc0424c25cbb9", "2", "email contact"),
    ("9312ca0d9f6645069dc46e481b976cdb", "3", "visit contact"),
    ("1671827402ca431c97b5f03720f04050", "8", "visit address"),
    ("bbd1692537bf400d96470d0f7569979f", "9", "browse URL"),
    ("ad92b74c2e0e4c2792baccc50b726e7e", "10", "Google search"),
])
def test_real_ios_task_action_types(uid: str, expected_acttype: str, label: str) -> None:
    """iOS action types are stored as string integers in the acttype field.

    acttype encoding:
      '-1' = no action (standard task)
       '0' = call contact       (actvalue = contact UUID + name)
       '1' = message contact    (actvalue = contact UUID + name)
       '2' = email contact      (actvalue = contact UUID + name)
       '3' = visit contact      (actvalue = contact UUID + name)
       '8' = visit address      (actvalue = address string)
       '9' = browse URL         (actvalue = URL string)
      '10' = Google search      (actvalue = search query)

    Contact actvalue format: '<UUID>{-;-}<Display Name>'
    """
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    assert payload.get("acttype") == expected_acttype, (
        f"Action '{label}': expected acttype='{expected_acttype}', got {payload.get('acttype')!r}"
    )
    # actvalue must be non-empty for all action types
    actvalue = payload.get("actvalue", "")
    assert actvalue, f"Action '{label}' (acttype={expected_acttype}): actvalue must be non-empty"


def test_real_ios_action_contact_actvalue_format() -> None:
    """Contact-type actions store actvalue as '<UUID>{-;-}<Display Name>'.

    Observed format: '76596E5B-1A34-4DA6-81E4-804FD94C5E71{-;-}Martin Rancourt'
    The {-;-} separator divides the iOS contact UUID from the display name.
    """
    uid = "7467a262bf494ed7b1bbc0424c25cbb9"  # "Email: Martin Rancourt" (acttype=2)
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    actvalue = payload.get("actvalue", "")
    assert "{-;-}" in actvalue, (
        f"Contact action actvalue must use '{{-;-}}' separator, got {actvalue!r}"
    )
    parts = actvalue.split("{-;-}")
    assert len(parts) == 2, f"Expected 2 parts in actvalue, got {len(parts)}: {parts}"
    # First part should look like an iOS contact UUID (hex with dashes, uppercase)
    contact_uuid = parts[0]
    assert len(contact_uuid) > 0, "Contact UUID must not be empty"
    # Second part is the display name
    display_name = parts[1]
    assert len(display_name) > 0, "Contact display name must not be empty"


# ---------------------------------------------------------------------------
# Real iOS task parsing — biweekly recurrence from completion (repeattype=257)
# ---------------------------------------------------------------------------


def test_real_ios_task_biweekly_from_completion() -> None:
    """Repeat every N weeks after completion: repeattype has both bit 256 and bit 1.

    'Testing repeat every 2 weeks after complétion' (e5feb4...) is a biweekly task
    that repeats from completion date (not from due date).

    Observed encoding:
      recurrence: '2'   (unit = weeks)
      repeatval:  '2'   (every 2 weeks)
      repeattype: '257' (bit 256 = schedule bit? or both bits set — needs verification)
      ruid: task uid    (recurring series identifier)

    Note: repeattype=257 = 256 + 1. The meaning of bit 1 in repeattype is not fully
    documented; this test pins the observed iOS behaviour.
    """
    uid = "e5feb44b92914795bcb61d3e9e1edebc"  # "Testing repeat every 2 weeks after complétion"
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    assert payload.get("recurrence") == "2", (
        f"Weekly recurrence: recurrence='2', got {payload.get('recurrence')!r}"
    )
    assert payload.get("repeatval") == "2", (
        f"Every 2 weeks: repeatval='2', got {payload.get('repeatval')!r}"
    )
    repeattype = int(payload.get("repeattype", "0"))
    assert repeattype == 257, (
        f"Biweekly-from-completion: repeattype must be 257, got {repeattype}"
    )
    # Recurring task must have ruid == uid
    assert payload.get("ruid") == uid, (
        f"Recurring task ruid must equal uid={uid!r}, got {payload.get('ruid')!r}"
    )


# ---------------------------------------------------------------------------
# Real iOS task parsing — alarm with positive reltrig (fires AFTER due date)
# ---------------------------------------------------------------------------


def test_real_ios_task_alarm_positive_reltrig_fires_after_due() -> None:
    """An alarm can fire after the due date (positive reltrig in seconds).

    'Alert day after due date at specific time' (e0363522...) due 2026-05-15 at 17:00
    has two alarms:
      - alarm[0]: reltrig=126180 (auto=False) — fires ~35 hours after due date
      - alarm[1]: reltrig=61200 (auto=True)  — standard auto alarm

    reltrig is measured in seconds relative to due datetime (not midnight).
    A positive reltrig means the alarm fires AFTER the due date/time.
    """
    uid = "e0363522938d443dbf3b33e9c64def76"  # "Alert day after due date at specific time"
    payload = _real_task(uid)
    if payload is None:
        pytest.skip("Real 2Do Dropbox tasks not available in this environment.")

    alarms = payload.get("alarms", [])
    assert len(alarms) >= 1, f"Expected at least 1 alarm, got {len(alarms)}"

    # At least one alarm must have a positive reltrig (fires after due date)
    positive_alarms = [
        a for a in alarms
        if a.get("reltrig") is not None and float(a.get("reltrig", 0)) > 0
        and a.get("isauto") == "0"  # manual alarm with positive offset
    ]
    assert len(positive_alarms) >= 1, (
        f"Expected at least one manual alarm with positive reltrig (after due date). "
        f"Alarms: {alarms}"
    )
    manual_alarm = positive_alarms[0]
    reltrig = float(manual_alarm["reltrig"])
    assert reltrig > 0, f"Alarm reltrig must be positive (after due), got {reltrig}"
    # 126180 seconds ≈ 35 hours — confirm it's at least 1 hour after due
    assert reltrig >= 3600, f"Expected alarm at least 1h after due, reltrig={reltrig}"
