"""Helpers for running cron prompts through the shared model chain."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from agentforge.claude_runner import build_system_prompt_context, invoke_model_chain


def _load_json(path: str) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def run_cron_prompt(*, root: str, agent_name: str, config_path: str, prompt: str, agent_dir: str | None = None) -> str:
    config = _load_json(config_path)
    models = config.get("models") or [{"model": config.get("model", "haiku")}]
    max_budget_usd = config.get("max_budget_usd")
    system_prompt = build_system_prompt_context(root, agent_name)
    result = invoke_model_chain(
        root=root,
        models=models,
        prompt=prompt,
        system_prompt=system_prompt,
        max_budget_usd=max_budget_usd,
        agent_name=agent_name,
        agent_dir=agent_dir,
    )
    return result.text


def main() -> int:
    parser = argparse.ArgumentParser(description="Run a cron prompt through the configured model chain")
    parser.add_argument("--root", required=True)
    parser.add_argument("--agent-name", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--prompt-file", required=True)
    parser.add_argument("--agent-dir", default=None, help="Agent directory; if it contains .claude/, passed as --project-dir to Claude Code")
    args = parser.parse_args()

    prompt = Path(args.prompt_file).read_text(encoding="utf-8")
    print(
        run_cron_prompt(
            root=args.root,
            agent_name=args.agent_name,
            config_path=args.config,
            prompt=prompt,
            agent_dir=args.agent_dir,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
