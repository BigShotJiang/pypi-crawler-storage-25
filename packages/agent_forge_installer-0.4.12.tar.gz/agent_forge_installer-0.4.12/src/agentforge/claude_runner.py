"""Claude Code CLI invocation."""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import tempfile
import threading
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from agentforge.llm_backends import (
    BACKEND_CLAUDE,
    BACKEND_CODEX,
    BACKEND_OLLAMA,
    resolve_backend,
)
from agentforge.paths import resolve_claude_bin, resolve_runtime_local_bin, resolve_runtime_root, resolve_vault_root

MONTREAL = ZoneInfo("America/Montreal")

# Pricing per token (USD) — updated 2026-03-23
# Short names (as used in config.json) and full model IDs both supported.
_MODEL_PRICING: dict[str, dict[str, float]] = {
    "claude-opus-4-6": {
        "input": 15.00 / 1_000_000,
        "output": 75.00 / 1_000_000,
        "cache_write": 18.75 / 1_000_000,
        "cache_read": 1.50 / 1_000_000,
    },
    "claude-sonnet-4-6": {
        "input": 3.00 / 1_000_000,
        "output": 15.00 / 1_000_000,
        "cache_write": 3.75 / 1_000_000,
        "cache_read": 0.30 / 1_000_000,
    },
    "claude-haiku-4-5": {
        "input": 0.80 / 1_000_000,
        "output": 4.00 / 1_000_000,
        "cache_write": 1.00 / 1_000_000,
        "cache_read": 0.08 / 1_000_000,
    },
    "claude-haiku-4-5-20251001": {
        "input": 0.80 / 1_000_000,
        "output": 4.00 / 1_000_000,
        "cache_write": 1.00 / 1_000_000,
        "cache_read": 0.08 / 1_000_000,
    },
}
# Short aliases used in config.json ("sonnet", "opus", "haiku")
_MODEL_PRICING["sonnet"] = _MODEL_PRICING["claude-sonnet-4-6"]
_MODEL_PRICING["opus"] = _MODEL_PRICING["claude-opus-4-6"]
_MODEL_PRICING["haiku"] = _MODEL_PRICING["claude-haiku-4-5"]

_DEFAULT_PRICING = _MODEL_PRICING["claude-sonnet-4-6"]

# Registry of in-flight Claude CLI subprocesses keyed by agent/thread name.
# Used by stop_agent() to cancel a running invocation on demand.
_active_subprocesses: dict[str, subprocess.Popen] = {}
_active_subprocesses_lock = threading.Lock()


def stop_agent(agent_name: str) -> bool:
    """Kill any in-flight Claude subprocess for agent_name. Returns True if one was running."""
    with _active_subprocesses_lock:
        proc = _active_subprocesses.pop(agent_name, None)
    if proc is None:
        return False
    try:
        proc.kill()
        proc.wait(timeout=5)
    except Exception:
        pass
    return True


@dataclass
class InvokeResult:
    """Result from a Claude CLI invocation."""

    text: str
    cost_usd: float | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    cache_write_tokens: int | None = None
    cache_read_tokens: int | None = None
    model: str | None = None


@dataclass
class ModelCandidate:
    backend: str
    model: str


def _build_prompt(
    *,
    history_text: str,
    topic_context: str,
    semantic_memory_section: str | None,
    user_text: str,
    thread_text: str = "",
) -> str:
    thread_section = f"## Current Thread\n{thread_text}\n\n" if thread_text else ""
    topic_section = f"\n## Contexte du topic\n{topic_context}\n" if topic_context else ""
    semantic_section = (
        f"\n## Relevant Vault Memories\n{semantic_memory_section}\n"
        if semantic_memory_section
        else ""
    )
    return f"""{thread_section}## Recent Conversation
{history_text}
{topic_section}
{semantic_section}
## Current Message
User: {user_text}

Respond to the user's current message. Be concise."""


def _build_common_env(root: str) -> dict[str, str]:
    runner_env = {**os.environ}
    original_home = runner_env.get("HOME", "")
    if not runner_env.get("GH_CONFIG_DIR") and original_home:
        runner_env["GH_CONFIG_DIR"] = str(Path(original_home) / ".config" / "gh")
    runtime_root = resolve_runtime_root(root)
    runner_env["HOME"] = str(runtime_root)
    runner_env["PATH"] = f"{resolve_runtime_local_bin(root)}:" + runner_env.get("PATH", "/usr/bin:/bin")
    return runner_env


def _build_claude_command(*, root: str, model: str, system_prompt: str | None, max_budget_usd: float | None, prompt: str, project_dir: str | None = None) -> list[str]:
    cmd = [
        resolve_claude_bin(root),
        "-p",
        "--model", model,
        "--dangerously-skip-permissions",
        "--output-format", "json",
    ]
    if project_dir:
        cmd += ["--project-dir", project_dir]
    if system_prompt:
        cmd += ["--system-prompt", system_prompt]
    if max_budget_usd:
        cmd += ["--max-budget-usd", str(max_budget_usd)]
    cmd.append(prompt)
    return cmd


def _build_ollama_command(*, model: str, system_prompt: str | None, prompt: str) -> list[str]:
    cmd = [
        "ollama",
        "launch",
        "claude",
        "--model",
        model,
        "--",
        "-p",
        "--dangerously-skip-permissions",
        "--output-format",
        "json",
    ]
    if system_prompt:
        cmd += ["--system-prompt", system_prompt]
    cmd.append(prompt)
    return cmd


def _build_codex_command(*, root: str, model: str, system_prompt: str | None, prompt: str, output_file: str) -> list[str]:
    effective_prompt = prompt if not system_prompt else f"## System Instructions\n{system_prompt}\n\n{prompt}"
    return [
        "codex",
        "exec",
        "--model",
        model,
        # Skip the bwrap/namespace sandbox — AgentForge runs inside containers that
        # cannot create user namespaces (RTM_NEWADDR / loopback setup fails).
        # This mirrors --dangerously-skip-permissions on the Claude Code backend.
        # The container itself provides the execution boundary.
        "--dangerously-bypass-approvals-and-sandbox",
        "--skip-git-repo-check",
        "-C",
        root,
        "-o",
        output_file,
        effective_prompt,
    ]


def _parse_invoke_result(raw_stdout: str, *, model: str) -> InvokeResult:
    if not raw_stdout:
        return InvokeResult(
            text="I processed your message but had no output. Try rephrasing?",
            model=model,
        )

    response_text = raw_stdout
    cost_usd: float | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    cache_write_tokens: int | None = None
    cache_read_tokens: int | None = None

    try:
        parsed = json.loads(raw_stdout)
        response_text = parsed.get("result") or parsed.get("text") or raw_stdout
        if not response_text:
            response_text = "I processed your message but had no output. Try rephrasing?"
        usage = parsed.get("usage") or {}
        if usage:
            input_tokens = usage.get("input_tokens")
            output_tokens = usage.get("output_tokens")
            cache_write_tokens = usage.get("cache_creation_input_tokens")
            cache_read_tokens = usage.get("cache_read_input_tokens")
            cost_usd = parsed.get("cost_usd") or parsed.get("total_cost_usd") or _calc_cost(usage, model)
    except (json.JSONDecodeError, AttributeError):
        logging.debug("LLM output was not JSON — using raw stdout as text")
        response_text = raw_stdout

    return InvokeResult(
        text=response_text,
        cost_usd=cost_usd,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cache_write_tokens=cache_write_tokens,
        cache_read_tokens=cache_read_tokens,
        model=model,
    )


def _calc_cost(usage: dict, model: str) -> float:
    pricing = _MODEL_PRICING.get(model, _DEFAULT_PRICING)
    return (
        usage.get("input_tokens", 0) * pricing["input"]
        + usage.get("output_tokens", 0) * pricing["output"]
        + usage.get("cache_creation_input_tokens", 0) * pricing["cache_write"]
        + usage.get("cache_read_input_tokens", 0) * pricing["cache_read"]
    )


def _candidate_from_entry(entry: object, *, default_model: str) -> ModelCandidate:
    if isinstance(entry, ModelCandidate):
        return entry
    if isinstance(entry, dict):
        model = str(entry.get("model") or default_model)
        backend = resolve_backend(str(entry.get("backend") or ""), model)
        return ModelCandidate(backend=backend, model=model)
    backend = str(getattr(entry, "backend", "") or "")
    model = str(getattr(entry, "model", "") or default_model)
    return ModelCandidate(backend=resolve_backend(backend, model), model=model)


def _resolve_model_candidates(thread_cfg: dict, config: dict, *, default_model: str = "sonnet") -> list[ModelCandidate]:
    for source in (thread_cfg, config.get("claude", {})):
        raw_models = source.get("models")
        if isinstance(raw_models, list) and raw_models:
            candidates = [
                _candidate_from_entry(item, default_model=default_model)
                for item in raw_models
                if isinstance(item, dict)
            ]
            if candidates:
                return candidates
        raw_model = str(source.get("model") or "")
        if raw_model:
            return [
                ModelCandidate(
                    backend=resolve_backend(str(source.get("backend") or ""), raw_model),
                    model=raw_model,
                )
            ]
    return [ModelCandidate(backend=resolve_backend("", default_model), model=default_model)]


def _invoke_single_candidate(
    *,
    candidate: ModelCandidate,
    root: str,
    system_prompt: str | None,
    prompt: str,
    max_budget_usd: float | None,
    agent_name: str = "",
    agent_dir: str | None = None,
) -> InvokeResult:
    backend = candidate.backend
    model = candidate.model

    if backend == BACKEND_CLAUDE:
        cmd = _build_claude_command(
            root=root,
            model=model,
            system_prompt=system_prompt,
            max_budget_usd=max_budget_usd,
            prompt=prompt,
            project_dir=agent_dir,
        )
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=root,
            env=_build_common_env(root),
        )
        if agent_name:
            with _active_subprocesses_lock:
                _active_subprocesses[agent_name] = proc
        try:
            stdout, stderr = proc.communicate(timeout=1800)
        finally:
            if agent_name:
                with _active_subprocesses_lock:
                    _active_subprocesses.pop(agent_name, None)
        result = subprocess.CompletedProcess(cmd, proc.returncode, stdout, stderr)
        if result.returncode != 0:
            return _handle_claude_compatible_error(result, model=model)
        return _parse_invoke_result((result.stdout or "").strip(), model=model)

    if backend == BACKEND_OLLAMA:
        if max_budget_usd:
            logging.info("max_budget_usd is not enforced for Ollama backend (model=%s)", model)
        cmd = _build_ollama_command(
            model=model,
            system_prompt=system_prompt,
            prompt=prompt,
        )
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=1800,
            cwd=root,
            env=_build_common_env(root),
        )
        if result.returncode != 0:
            logging.error(
                "Ollama Claude bridge error (rc=%s): stderr=%s stdout=%s",
                result.returncode,
                (result.stderr or "").strip()[:300],
                (result.stdout or "").strip()[:300],
            )
            return InvokeResult(text=GENERIC_CLAUDE_INVOCATION_ERROR, model=model)
        return _parse_invoke_result((result.stdout or "").strip(), model=model)

    if backend == BACKEND_CODEX:
        if max_budget_usd:
            logging.info("max_budget_usd is not enforced for Codex backend (model=%s)", model)
        with tempfile.NamedTemporaryFile(prefix="agentforge-codex-", suffix=".txt", delete=False) as handle:
            output_file = handle.name
        try:
            cmd = _build_codex_command(
                root=root,
                model=model,
                system_prompt=system_prompt,
                prompt=prompt,
                output_file=output_file,
            )
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=1800,
                cwd=root,
                env=_build_common_env(root),
            )
            if result.returncode != 0:
                logging.error(
                    "Codex error (rc=%s): stderr=%s stdout=%s",
                    result.returncode,
                    (result.stderr or "").strip()[:300],
                    (result.stdout or "").strip()[:300],
                )
                return InvokeResult(text=GENERIC_CLAUDE_INVOCATION_ERROR, model=model)
            response_text = Path(output_file).read_text(encoding="utf-8").strip()
            if not response_text:
                response_text = (result.stdout or "").strip()
            return InvokeResult(
                text=response_text or "I processed your message but had no output. Try rephrasing?",
                model=model,
            )
        finally:
            try:
                Path(output_file).unlink(missing_ok=True)
            except OSError:
                pass

    raise ValueError(f"Unsupported backend '{backend}'")


def invoke_model_chain(
    *,
    root: str,
    models: list[object],
    prompt: str,
    system_prompt: str | None,
    max_budget_usd: float | None,
    agent_name: str = "",
    agent_dir: str | None = None,
) -> InvokeResult:
    candidates = [_candidate_from_entry(candidate, default_model="sonnet") for candidate in models]
    if not candidates:
        candidates = [ModelCandidate(backend=resolve_backend("", "sonnet"), model="sonnet")]

    last_limit_error: ClaudeCodeLimitError | None = None
    for idx, candidate in enumerate(candidates):
        try:
            return _invoke_single_candidate(
                candidate=candidate,
                root=root,
                system_prompt=system_prompt,
                prompt=prompt,
                max_budget_usd=max_budget_usd,
                agent_name=agent_name,
                agent_dir=agent_dir,
            )
        except ClaudeCodeLimitError as exc:
            last_limit_error = exc
            if idx == len(candidates) - 1:
                raise
            logging.warning(
                "Model quota exhausted for %s/%s; failing over to next candidate",
                candidate.backend,
                candidate.model,
            )
            continue

    raise RuntimeError("invoke_model_chain reached an unexpected fallthrough")

# Matches ccusage / Claude Code JSONL field name (see npm package ccusage).
_USAGE_LIMIT_RESET_MS_RE = re.compile(
    r'usageLimitResetTime["\']?\s*:\s*(\d{10,16})\b', re.IGNORECASE
)
_USAGE_LIMIT_RESET_SNAKE_RE = re.compile(
    r"usage_limit_reset_time\s*[:=]\s*(\d{10,16})\b", re.IGNORECASE
)
_RETRY_AFTER_SEC_RE = re.compile(
    r"(?:retry-after|retry_after)[\"']?\s*[:=]\s*[\"']?(\d+)\b", re.IGNORECASE
)
_ISO_Z_RE = re.compile(
    r"\b(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z)\b"
)
_RESETS_CLOCK_RE = re.compile(
    r"resets\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)\s*\(([^)]+)\)",
    re.IGNORECASE,
)


class RateLimitError(Exception):
    def __init__(self, retry_after_seconds: int = 3600):
        self.retry_after_seconds = retry_after_seconds


class ClaudeCodeLimitError(Exception):
    """Claude Code subscription usage limit reached (weekly/session cap)."""

    def __init__(self, *, restore_at: datetime | None = None) -> None:
        self.restore_at = restore_at
        if restore_at is not None and restore_at.tzinfo is None:
            raise ValueError("restore_at must be timezone-aware")


def _epoch_ms_or_s_to_utc(value: int) -> datetime:
    """Interpret Claude/ccusage timestamps (seconds or milliseconds since epoch)."""
    if value >= 10**12:
        sec = value / 1000.0
    else:
        sec = float(value)
    return datetime.fromtimestamp(sec, tz=timezone.utc)


def parse_retry_after_seconds(raw: str) -> int | None:
    """Parse Retry-After style delay in seconds from CLI output."""
    m = _RETRY_AFTER_SEC_RE.search(raw)
    if not m:
        return None
    sec = int(m.group(1))
    return sec if sec > 0 else None


def parse_quota_restore_at(raw: str) -> datetime | None:
    """
    Best-effort reset time from Claude Code / Anthropic stderr or stdout.

    Aligns with fields analyzed by ccusage (npm `ccusage`), e.g. usageLimitResetTime
    in local JSONL; the CLI sometimes echoes similar JSON.
    """
    if not raw:
        return None
    for pattern in (_USAGE_LIMIT_RESET_MS_RE, _USAGE_LIMIT_RESET_SNAKE_RE):
        m = pattern.search(raw)
        if m:
            try:
                return _epoch_ms_or_s_to_utc(int(m.group(1)))
            except (OSError, OverflowError, ValueError):
                pass
    for m in _ISO_Z_RE.finditer(raw):
        try:
            return datetime.fromisoformat(m.group(1).replace("Z", "+00:00"))
        except ValueError:
            continue
    m = _RESETS_CLOCK_RE.search(raw)
    if m:
        try:
            hour = int(m.group(1))
            minute = int(m.group(2) or 0)
            ampm = m.group(3).lower()
            tz_name = m.group(4).strip()
            if ampm == "pm" and hour != 12:
                hour += 12
            elif ampm == "am" and hour == 12:
                hour = 0
            tz = ZoneInfo(tz_name)
            now = datetime.now(tz)
            candidate = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if candidate <= now:
                candidate += timedelta(days=1)
            return candidate.astimezone(timezone.utc)
        except Exception:
            pass
    return None


def format_claude_code_limit_user_message(
    restore_at: datetime | None,
    *,
    tz: ZoneInfo = MONTREAL,
) -> str:
    """User-facing text when Claude Code quota / subscription usage cap is hit."""
    if restore_at is not None:
        local = restore_at.astimezone(tz)
        label = local.tzname() or str(local.utcoffset() or "")
        return (
            f"Claude Code quota reached. Restore at {local:%Y-%m-%d %H:%M} {label}."
        )
    return (
        "Claude Code quota reached. No exact reset time was in the CLI output. "
        "Claude Code uses rolling windows (see 5-hour blocks in "
        "https://www.npmjs.com/package/ccusage — `npx ccusage@latest blocks`). "
        "Try again after your current window ends."
    )


def format_rate_limit_user_message(retry_after_seconds: int, *, tz: ZoneInfo = MONTREAL) -> str:
    when = datetime.now(tz) + timedelta(seconds=retry_after_seconds)
    label = when.tzname() or str(when.utcoffset() or "")
    return f"Anthropic rate limit reached. Retry around {when:%H:%M} {label}."


GENERIC_CLAUDE_INVOCATION_ERROR = "Sorry, I encountered an error. Please try again."

# Soft warning budget per injected section. Crossing this threshold does not
# truncate, but it is usually a sign the prompt source needs to be distilled.
CONTEXT_SECTION_WARN_CHARS = 4_000
# Hard ceiling per injected section to prevent a single file from dominating the
# system prompt. Canonical vault files should normally stay well below this.
MAX_CONTEXT_SECTION_CHARS = 12_000


def _handle_claude_compatible_error(result: subprocess.CompletedProcess[str], *, model: str) -> InvokeResult:
    stderr = (result.stderr or "").strip()
    stdout = (result.stdout or "").strip()
    raw_for_parse = f"{stderr}\n{stdout}".strip()
    combined = raw_for_parse.lower()
    logging.error(
        f"Claude error (rc={result.returncode}): "
        f"stderr={stderr[:300]} stdout={stdout[:300]}"
    )
    claude_code_limit_signals = [
        "usage limit",
        "claude code limit",
        "subscription limit",
        "usage cap",
        "limit reached",
        "claude pro",
        "out of credits",
        "weekly usage",
        "exceeded your usage",
        "credit balance",
        "not enough credits",
        "session limit",
        "usage for claude",
        "claude code quota",
        "billing cycle",
        "hit your limit",
        "resets 6am",
        "resets at",
    ]
    if any(kw in combined for kw in claude_code_limit_signals):
        logging.warning("Claude Code usage limit detected")
        restore_at = parse_quota_restore_at(raw_for_parse)
        raise ClaudeCodeLimitError(restore_at=restore_at)
    if result.returncode == 1 and not stderr and not stdout:
        logging.warning("Claude Code rc=1 with no output — treating as usage limit")
        raise ClaudeCodeLimitError(restore_at=None)
    rate_limit_signals = [
        "rate limit",
        "429",
        "quota exceeded",
        "overloaded",
        "too many requests",
    ]
    if any(kw in combined for kw in rate_limit_signals):
        logging.warning(f"Claude rate limited: {combined[:200]}")
        retry_sec = parse_retry_after_seconds(raw_for_parse) or 3600
        raise RateLimitError(retry_after_seconds=retry_sec)
    return InvokeResult(text=GENERIC_CLAUDE_INVOCATION_ERROR, model=model)

def _agent_context_paths(root: str, thread_name: str, filename: str) -> list[Path]:
    if not thread_name:
        return []
    return [
        resolve_vault_root(root) / "Agents" / thread_name / filename,
        Path(root) / "agents" / thread_name / filename,
    ]


def _read_optional_text(path: Path) -> str | None:
    try:
        text = path.read_text(encoding="utf-8").strip()
    except OSError as exc:
        logging.debug("Skipping unreadable context file %s: %s", path, exc)
        return None
    if len(text) > CONTEXT_SECTION_WARN_CHARS:
        logging.warning(
            "Large context file %s is %s characters (soft budget %s)",
            path,
            len(text),
            CONTEXT_SECTION_WARN_CHARS,
        )
    if len(text) > MAX_CONTEXT_SECTION_CHARS:
        logging.warning(
            "Truncating context file %s from %s to %s characters",
            path,
            len(text),
            MAX_CONTEXT_SECTION_CHARS,
        )
        text = text[:MAX_CONTEXT_SECTION_CHARS].rstrip()
    return text or None


def _read_first_existing_text(paths: list[Path]) -> str | None:
    for path in paths:
        text = _read_optional_text(path)
        if text:
            return text
    return None


def build_system_prompt_context(root: str, thread_name: str) -> str | None:
    """Build the system prompt by injecting context files in order:
    1. CLAUDE.md (framework guide, read-only)
    2. vault/Agents/_team/CLAUDE.md (instance-specific rules, preferred)
       fallback: agents/shared/CLAUDE.md
       fallback: CLAUDE.local.md
    3. vault/Agents/_team/memory.md (shared facts, vault-native preferred)
       fallback: agents/shared/memory.md
    4. vault/Agents/<name>/soul.md (agent identity, preferred)
       fallback: agents/<name>/soul.md
    5. vault/Agents/<name>/memory.md (agent long-term memory, preferred)
       fallback: agents/<name>/memory.md
    """
    sections: list[str] = []

    # 1. Framework guide
    framework_md = _read_optional_text(Path(root) / "CLAUDE.md")
    if framework_md:
        sections.append(framework_md)

    # 2. Instance-specific rules, preferring canonical _team location.
    shared_claude = _read_first_existing_text(
        [
            resolve_vault_root(root) / "Agents" / "_team" / "CLAUDE.md",
            Path(root) / "agents" / "shared" / "CLAUDE.md",
            Path(root) / "CLAUDE.local.md",
        ]
    )
    if shared_claude:
        sections.append(shared_claude)

    # 3. Shared memory — vault-native preferred, agents/shared fallback.
    shared_memory = _read_first_existing_text(
        [
            resolve_vault_root(root) / "Agents" / "_team" / "memory.md",
            Path(root) / "agents" / "shared" / "memory.md",
        ]
    )
    if shared_memory:
        sections.append(f"## Shared Knowledge\n{shared_memory}")

    system_state = resolve_vault_root(root) / "Agents" / "_team" / "system-state.md"
    config_candidates = [Path(root) / "bot" / "config.json", *sorted((Path(root) / "agents").glob("*/config.json"))]
    newest_config_mtime = max((path.stat().st_mtime for path in config_candidates if path.exists()), default=None)
    if newest_config_mtime is not None:
        if not system_state.exists():
            sections.append(
                "## System State Warning\n"
                "Generated `vault/Agents/_team/system-state.md` is missing. Verify live code/config before stating runtime facts."
            )
        elif system_state.stat().st_mtime < newest_config_mtime:
            sections.append(
                "## System State Warning\n"
                "Generated `vault/Agents/_team/system-state.md` may be stale relative to current config files. "
                "Verify live code/config before stating runtime facts."
            )

    if not thread_name:
        return "\n\n".join(sections) if sections else None

    # 4. Agent soul, 5. Agent memory
    for label, paths in (
        ("Soul", _agent_context_paths(root, thread_name, "soul.md")),
        ("Memory", _agent_context_paths(root, thread_name, "memory.md")),
    ):
        content = _read_first_existing_text(paths)
        if content:
            sections.append(f"## {label}\n{content}")

    return "\n\n".join(sections) if sections else None


# Backward-compatible alias for existing internal imports/tests.
_build_system_prompt_context = build_system_prompt_context


def invoke_claude(
    *,
    session_id: str,
    user_text: str,
    thread_cfg: dict,
    config: dict,
    recent_messages: list[tuple[str, str, str]],
    thread_messages: list[tuple[str, str, str]] | None = None,
    root: str,
) -> InvokeResult:
    """
    Invoke the configured LLM backend and return the response as an InvokeResult.

    Args:
        session_id: Conversation session identifier
        user_text: The user's message
        thread_cfg: Thread/agent config dict
        config: Full bot config
        recent_messages: List of (role, content, timestamp) tuples
        thread_messages: Optional thread-local context, oldest-first
        root: AGENTFORGE_ROOT path

    Returns:
        InvokeResult with text and usage data.

        Note — what this function does NOT inject (handled by shell wrappers):
        - Interactive/Telegram: conversation history, topic section, and semantic
          vault search results are appended to the user prompt by the bot layer.
        - Heartbeat/cron: the agent's actionable todo slice, derived from
          `vault/Agents/<agent>/tasks.md` (legacy fallback supported by the
          todo parser), plus the heartbeat task.md are prepended by heartbeat.sh.
        The system prompt (CLAUDE.md + instance rules + shared memory + soul/memory)
        is built here and is identical in both modes.

    Raises:
        RateLimitError: If Anthropic rate limit hit
        ClaudeCodeLimitError: If Claude Code subscription limit reached
    """
    candidates = _resolve_model_candidates(thread_cfg, config)
    model = candidates[0].model
    thread_name = thread_cfg.get("name", "")

    # Determine display name for this agent's history
    agent_display_name = (
        thread_name.capitalize()
        if thread_name and thread_name != "clawdia"
        else "Clawdia"
    )

    # Format conversation history
    history_lines = []
    for role, content, ts in recent_messages:
        prefix = "User" if role == "user" else agent_display_name
        history_lines.append(f"[{ts}] {prefix}: {content}")

    thread_lines = []
    for role, content, ts in thread_messages or []:
        prefix = "User" if role == "user" else agent_display_name
        thread_lines.append(f"[{ts}] {prefix}: {content}")

    history_text = "\n".join(history_lines) if history_lines else "(No prior messages)"
    thread_text = "\n".join(thread_lines)
    semantic_memory_section = _build_semantic_memory_section(
        root=root,
        user_text=user_text,
        thread_name=thread_name,
    )

    prompt = _build_prompt(
        history_text=history_text,
        topic_context=thread_cfg.get("topic_context", ""),
        semantic_memory_section=semantic_memory_section,
        user_text=user_text,
        thread_text=thread_text,
    )

    cfg = config["claude"]
    system_prompt = build_system_prompt_context(root, thread_name)

    try:
        return invoke_model_chain(
            root=root,
            models=candidates,
            prompt=prompt,
            system_prompt=system_prompt,
            max_budget_usd=cfg.get("max_budget_usd"),
            agent_name=thread_name,
        )
    except subprocess.TimeoutExpired:
        logging.error("LLM model chain timed out after 30 minutes")
        return InvokeResult(
            text=(
                "Désolée, cette tâche a pris trop longtemps (>30 min). "
                "Essaie de la découper en étapes plus courtes."
            ),
            model=model,
        )
    except (RateLimitError, ClaudeCodeLimitError):
        raise
    except Exception as e:
        logging.error(f"Failed to invoke model chain: {e}", exc_info=True)
        return InvokeResult(text="Sorry, something went wrong. Please try again later.", model=model)


def invoke_llm(
    *,
    session_id: str,
    user_text: str,
    thread_cfg: dict,
    config: dict,
    recent_messages: list[tuple[str, str, str]],
    thread_messages: list[tuple[str, str, str]] | None = None,
    root: str,
) -> InvokeResult:
    """Preferred name for backend-aware LLM invocation."""
    return invoke_claude(
        session_id=session_id,
        user_text=user_text,
        thread_cfg=thread_cfg,
        config=config,
        recent_messages=recent_messages,
        thread_messages=thread_messages,
        root=root,
    )


def _build_semantic_memory_section(*, root: str, user_text: str, thread_name: str) -> str | None:
    if not user_text.strip():
        return None
    try:
        from agentforge.vault import DB_PATH, semantic_search_entries
    except Exception:
        return None

    original_db_path = DB_PATH
    try:
        # Keep semantic lookup scoped to the current runtime root.
        from agentforge import vault as vault_module

        vault_module.DB_PATH = Path(root) / "data" / "agent_vault.db"
        results = semantic_search_entries(
            user_text,
            top_k=3,
            agent=None if thread_name in {"", "shared"} else thread_name,
            alpha=0.5,
        )
    except Exception as exc:
        logging.debug("Semantic memory lookup skipped: %s", exc)
        return None
    finally:
        from agentforge import vault as vault_module

        vault_module.DB_PATH = original_db_path

    if not results:
        return None

    lines: list[str] = []
    for row, score in results:
        title = (row["title"] or "").strip()
        header = f"- [{row['id']}] {row['agent']}/{row['category']} score={score:.2f}"
        if title:
            header += f" title={title}"
        content = " ".join((row["content"] or "").split())
        if len(content) > 220:
            content = content[:217] + "..."
        lines.append(f"{header}\n  {content}")
    return "\n".join(lines)
