"""Task service backed by 2Do archives."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
import json
import os
from pathlib import Path

logger = logging.getLogger(__name__)

from agentforge.paths import resolve_vault_root
from agentforge.twodo.backend import TwoDoBackend


DEFAULT_READY_WINDOW_MINUTES = 60
HEARTBEAT_WINDOW_MINUTES = 15
TASK_CLAIM_TTL_MINUTES = HEARTBEAT_WINDOW_MINUTES


@dataclass(slots=True)
class TaskRecord:
    task_id: str
    title: str
    status: str
    assignee_kind: str
    assignee_id: str
    due_at: datetime | None
    schedule_type: str
    recurrence_rule: str | None
    next_run_at: datetime | None
    last_completed_at: datetime | None
    ready_window_minutes: int
    priority: str
    tags: list[str]
    prompt_ref: str | None
    notes: str
    source: str
    source_path: str | None
    source_line: int
    created_at: datetime | None
    updated_at: datetime | None
    failure_count: int = 0
    last_failure_at: datetime | None = None
    retry_after: datetime | None = None
    last_error: str | None = None
    escalation_task_id: str | None = None

    @property
    def can_execute(self) -> bool:
        return self.assignee_kind == "agent"


@dataclass(slots=True)
class TaskFailureResult:
    task_id: str
    assignee_id: str
    title: str
    failure_count: int
    retry_after: datetime
    last_error: str
    escalated: bool = False
    escalation_task_id: str | None = None


def _priority_rank(value: str) -> int:
    return {"high": 0, "medium": 1, "low": 2}.get(value, 1)


def _failure_backoff_minutes(failure_count: int) -> int:
    schedule = {1: 15, 2: 60, 3: 360}
    return schedule.get(failure_count, 1440)


class TaskService:
    def __init__(self, root: Path) -> None:
        self.root = root
        self.backend = TwoDoBackend(root)

    def _legacy_tasks_path(self, actor_id: str, *, kind: str | None = None) -> Path:
        actor, resolved_kind = self.ensure_actor(actor_id)
        actual_kind = kind or resolved_kind
        if actual_kind == "agent":
            return resolve_vault_root(self.root) / "Agents" / actor / "tasks.md"
        return resolve_vault_root(self.root) / "Actors" / actor / "tasks.md"

    def _cleanup_legacy_tasks_view(self, actor_id: str, *, kind: str | None = None) -> Path:
        path = self._legacy_tasks_path(actor_id, kind=kind)
        if path.exists():
            logger.warning("Removing legacy tasks.md for %s — ensure tasks were migrated to 2Do", actor_id)
            path.unlink()
        return path

    def ensure_actor(self, actor_id: str) -> tuple[str, str]:
        actor = actor_id.strip().lstrip("@").lower()
        actor_kind = "agent" if (self.root / "agents" / actor / "config.json").exists() else "human"
        return actor, actor_kind

    def bootstrap_actor(self, actor_id: str) -> None:
        actor, kind = self.ensure_actor(actor_id)
        # resolve_list is idempotent: returns existing list if found, creates only when absent.
        self.backend.resolve_list(actor, create=True)
        self._cleanup_legacy_tasks_view(actor, kind=kind)

    def _claim_dir(self) -> Path:
        path = self.root / "data" / "task_claims"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def _claim_path(self, task_id: str) -> Path:
        return self._claim_dir() / f"{task_id}.json"

    def _read_claim(self, task_id: str) -> dict[str, str] | None:
        path = self._claim_path(task_id)
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return None
        except Exception as exc:
            logger.warning("Could not read claim file %s: %s", path, exc)
            return None
        return payload if isinstance(payload, dict) else None

    def _claim_is_active(self, task_id: str, now: datetime) -> bool:
        payload = self._read_claim(task_id)
        if not payload:
            return False
        try:
            expires_at = datetime.fromisoformat(str(payload.get("expires_at")))
        except (TypeError, ValueError):
            return False
        return expires_at > now

    def claim_task(self, task_id: str, *, actor_id: str, now: datetime | None = None) -> bool:
        now = now or datetime.now().replace(second=0, microsecond=0)
        path = self._claim_path(task_id)
        if self._claim_is_active(task_id, now):
            return False
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        payload = {
            "task_id": task_id,
            "actor_id": actor_id,
            "claimed_at": now.isoformat(timespec="minutes"),
            "expires_at": (now + timedelta(minutes=TASK_CLAIM_TTL_MINUTES)).isoformat(timespec="minutes"),
        }
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        try:
            fd = os.open(path, flags, 0o644)
        except FileExistsError:
            return False
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False)
        return True

    def release_task_claim(self, task_id: str) -> None:
        try:
            self._claim_path(task_id).unlink()
        except FileNotFoundError:
            pass

    def _to_record(self, actor_id: str, task) -> TaskRecord:
        schedule_type = "recurring" if task.recurrence_rule else "one_shot"
        next_run_at = task.next_run_override or task.due_at
        if task.next_run_override is None and task.due_at is not None and schedule_type == "one_shot":
            next_run_at = task.due_at - timedelta(minutes=DEFAULT_READY_WINDOW_MINUTES)
        return TaskRecord(
            task_id=task.task_id,
            title=task.title,
            status="done" if task.is_completed else "open",
            assignee_kind="agent" if (self.root / "agents" / actor_id / "config.json").exists() else "human",
            assignee_id=actor_id,
            due_at=task.due_at,
            schedule_type=schedule_type,
            recurrence_rule=task.recurrence_rule,
            next_run_at=next_run_at,
            last_completed_at=task.last_completed_at,
            ready_window_minutes=DEFAULT_READY_WINDOW_MINUTES,
            priority=task.priority,
            tags=task.tags,
            prompt_ref=task.prompt_ref,
            notes=task.prompt or task.notes,
            source="2do",
            source_path=str(task.path) if task.path else None,
            source_line=0,
            created_at=task.created_at,
            updated_at=task.updated_at,
            failure_count=task.failure_count,
            last_failure_at=task.last_failure_at,
            retry_after=task.retry_after,
            last_error=task.last_error,
            escalation_task_id=task.escalation_task_id,
        )

    def list_tasks(self, actor_id: str, *, status: str | None = None) -> list[TaskRecord]:
        actor, _ = self.ensure_actor(actor_id)
        self.bootstrap_actor(actor)
        tasks = []
        for task in self.backend.read_tasks(include_completed=True):
            if (task.list_name or "").strip().lower() != actor:
                continue
            record = self._to_record(actor, task)
            if status and record.status != status:
                continue
            tasks.append(record)
        tasks.sort(key=lambda item: (item.next_run_at or datetime.max, item.title.lower()))
        return tasks

    def create_task(
        self,
        *,
        assignee_id: str,
        title: str,
        due_at: datetime | None = None,
        recurrence_rule: str | None = None,
        priority: str = "medium",
        tags: list[str] | None = None,
        prompt_ref: str | None = None,
        notes: str = "",
        source: str = "manual",
        ready_window_minutes: int = DEFAULT_READY_WINDOW_MINUTES,
        repeat_from: str = "due",
    ) -> str:
        actor, _ = self.ensure_actor(assignee_id)
        prompt = None
        if prompt_ref:
            actor_base = resolve_vault_root(self.root) / "Agents" / actor
            candidate = actor_base / prompt_ref
            if candidate.exists():
                prompt = candidate.read_text(encoding="utf-8").strip()
        task = self.backend.create_task(
            list_name=actor,
            title=title,
            notes=notes,
            due_at=due_at,
            recurrence_rule=recurrence_rule,
            priority=priority,
            tags=tags or [],
            actor_id=actor,
            prompt=prompt,
            prompt_ref=prompt_ref,
            repeat_from=repeat_from,
        )
        self._cleanup_legacy_tasks_view(actor)
        return task.task_id

    def update_task(
        self,
        task_id: str,
        *,
        title: str | None = None,
        recurrence_rule: str | None = None,
        prompt_ref: str | None = None,
        due_at: datetime | None = None,
        priority: str | None = None,
        tags: list[str] | None = None,
        notes: str | None = None,
    ) -> bool:
        prompt = None
        actor = None
        if prompt_ref:
            existing = self.backend.read_task(task_id)
            if existing:
                actor = (existing.actor_id or existing.list_name or "").strip().lower() or None
            if actor:
                actor_base = resolve_vault_root(self.root) / "Agents" / actor
                candidate = actor_base / prompt_ref
                if candidate.exists():
                    prompt = candidate.read_text(encoding="utf-8").strip()
        updated = self.backend.update_task(
            task_id,
            title=title,
            notes=notes,
            due_at=due_at,
            recurrence_rule=recurrence_rule,
            priority=priority,
            tags=tags,
            prompt=prompt,
            prompt_ref=prompt_ref,
        )
        if updated:
            task = self.backend.read_task(task_id)
            if task and task.list_name:
                self._cleanup_legacy_tasks_view(task.list_name)
        return updated

    def _is_actionable(self, task: TaskRecord, now: datetime) -> bool:
        if task.status != "open":
            return False
        if task.retry_after and task.retry_after > now:
            return False
        if task.due_at is None:
            return True  # no-due-date tasks are always actionable (background work, lowest priority)
        window = HEARTBEAT_WINDOW_MINUTES if task.schedule_type == "recurring" else task.ready_window_minutes
        return now >= (task.due_at - timedelta(minutes=window))

    def select_actionable(self, actor_id: str, *, now: datetime | None = None, limit: int = 8) -> list[TaskRecord]:
        now = now or datetime.now().replace(second=0, microsecond=0)
        items = [item for item in self.list_tasks(actor_id) if self._is_actionable(item, now)]
        items.sort(
            key=lambda task: (
                _priority_rank(task.priority),
                0 if task.due_at is not None else 1,
                task.due_at or datetime.max,
                task.created_at or datetime.max,
                task.title.lower(),
            )
        )
        return items[:limit]

    def claim_actionable(self, actor_id: str, *, now: datetime | None = None, limit: int = 8) -> list[TaskRecord]:
        now = now or datetime.now().replace(second=0, microsecond=0)
        claimed: list[TaskRecord] = []
        # Some actionable tasks may already be claimed, so fetch a larger candidate pool.
        for task in self.select_actionable(actor_id, now=now, limit=max(limit * 10, 50)):
            if self.claim_task(task.task_id, actor_id=actor_id, now=now):
                claimed.append(task)
            if len(claimed) >= limit:
                break
        return claimed

    def render_heartbeat_payload(self, actor_id: str, *, now: datetime | None = None, limit: int = 8, claim: bool = False) -> str:
        actor, kind = self.ensure_actor(actor_id)
        if kind != "agent":
            return ""
        tasks = self.claim_actionable(actor, now=now, limit=limit) if claim else self.select_actionable(actor, now=now, limit=limit)
        if not tasks:
            return ""
        lines = ["## Relevant Structured Tasks", ""]
        for task in tasks:
            lines.append(f"### TASK {task.task_id} — {task.title}")
            lines.append(f"reason:: {'recurring run' if task.schedule_type == 'recurring' else 'ready window'}")
            if task.due_at:
                lines.append(f"scheduled_for:: {task.due_at.strftime('%Y-%m-%d %H:%M')}")
            if task.tags:
                lines.append(f"tags:: {' '.join(task.tags)}")
            lines.append("")
            lines.append(task.notes or task.title)
            lines.append("")
            lines.append(f"After completing this task, output exactly: TASK_DONE {task.task_id}")
            lines.append(f"If you intentionally skip it for now, output exactly: TASK_SKIP {task.task_id}")
            lines.append(f"If execution failed, output exactly: TASK_FAIL {task.task_id}")
            lines.append(f"After TASK_FAIL, you may add one line: TASK_ERROR {task.task_id} <short reason>")
            lines.append("")
        return "\n".join(lines).rstrip()

    def complete_task(self, task_id: str, *, result: str = "done", completed_at: datetime | None = None) -> bool:
        completed = self.backend.complete_task(task_id, completed_at=completed_at)
        if completed:
            self.release_task_claim(task_id)
            task = self.backend.read_task(task_id)
            if task and task.list_name:
                self._cleanup_legacy_tasks_view(task.list_name)
        return completed

    def defer_task(self, task_id: str, *, deferred_until: datetime | None = None, reason: str = "skip") -> bool:
        target = deferred_until or (datetime.now().replace(second=0, microsecond=0) + timedelta(minutes=30))
        deferred = self.backend.defer_task(task_id, due_at=target)
        if deferred:
            self.release_task_claim(task_id)
            task = self.backend.read_task(task_id)
            if task and task.list_name:
                self._cleanup_legacy_tasks_view(task.list_name)
        return deferred

    def fail_task(
        self,
        task_id: str,
        *,
        error: str = "",
        now: datetime | None = None,
        escalation_threshold: int = 3,
    ) -> TaskFailureResult | None:
        current = self.backend.read_task(task_id)
        if current is None:
            return None
        now = now or datetime.now().replace(second=0, microsecond=0)
        failure_count = max(current.failure_count, 0) + 1
        retry_after = now + timedelta(minutes=_failure_backoff_minutes(failure_count))
        escalated = False
        escalation_task_id = current.escalation_task_id

        if failure_count >= escalation_threshold and not escalation_task_id:
            actor = (current.actor_id or current.list_name or "").strip().lower() or "unknown"
            notes = (
                f"Investigate failing task for @{actor}.\n\n"
                f"Original task id: {current.task_id}\n"
                f"Title: {current.title}\n"
                f"Failure count: {failure_count}\n"
                f"Retry after: {retry_after.strftime('%Y-%m-%d %H:%M')}\n"
                f"Last error: {error or 'unspecified failure'}\n\n"
                "Investigate root cause, fix the issue if possible, and open a PR when a code change is needed."
            )
            escalation_task_id = self.create_task(
                assignee_id="architect",
                title=f"Investigate failing task for {actor}: {current.title}",
                priority="high",
                tags=["#autre/self-healing"],
                notes=notes,
                source="heartbeat:task-failure",
            )
            escalated = True

        recorded = self.backend.record_failure(
            task_id,
            retry_after=retry_after,
            error=error or current.last_error,
            escalation_task_id=escalation_task_id,
        )
        if not recorded:
            return None
        self.release_task_claim(task_id)
        return TaskFailureResult(
            task_id=current.task_id,
            assignee_id=(current.actor_id or current.list_name or "").strip().lower(),
            title=current.title,
            failure_count=failure_count,
            retry_after=retry_after,
            last_error=error or "unspecified failure",
            escalated=escalated,
            escalation_task_id=escalation_task_id,
        )

    def cleanup_legacy_tasks_view(self, actor_id: str) -> Path:
        actor, kind = self.ensure_actor(actor_id)
        return self._cleanup_legacy_tasks_view(actor, kind=kind)
