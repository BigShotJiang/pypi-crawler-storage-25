"""Voice note and audio transcription using faster-whisper."""

from __future__ import annotations

import logging
import os
import tempfile

from agentforge.http_client import http_get, http_download

# Mapping from Telegram/MIME types to file extensions for temp files
_MIME_TO_EXT: dict[str, str] = {
    "audio/mpeg": ".mp3",
    "audio/mp4": ".m4a",
    "audio/ogg": ".ogg",
    "audio/flac": ".flac",
    "audio/wav": ".wav",
    "audio/x-wav": ".wav",
    "audio/aac": ".aac",
    "audio/webm": ".webm",
    "video/mp4": ".mp4",   # video_note
    "video/mpeg": ".mpeg",
    "video/webm": ".webm",
}


def _download_and_transcribe(
    file_dict: dict,
    api_base: str,
    token: str,
    suffix: str = ".ogg",
) -> str | None:
    """
    Internal: download a Telegram file by file_id and transcribe with faster-whisper.

    Args:
        file_dict: Any Telegram file-bearing dict (voice, audio, video_note…)
        api_base: Telegram API base URL
        token: Bot token for file download
        suffix: Temp-file extension hint (used by libav for demuxing)

    Returns:
        Transcribed text, or None if transcription failed/unavailable.
    """
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        logging.warning("faster-whisper not installed — audio transcription unavailable")
        return None

    audio_path: str | None = None
    try:
        file_id = file_dict["file_id"]
        file_info = http_get(f"{api_base}/getFile", params={"file_id": file_id})
        file_path = file_info["result"]["file_path"]
        file_url = f"https://api.telegram.org/file/bot{token}/{file_path}"

        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            audio_path = tmp.name

        http_download(file_url, audio_path)

        # Transcribe with faster-whisper tiny model (CPU, int8 quantized, ~75 MB)
        # language=None enables automatic language detection (multilingual support)
        model = WhisperModel("tiny", device="cpu", compute_type="int8")
        segments, _ = model.transcribe(audio_path, language=None)
        text = " ".join(seg.text for seg in segments).strip()

        return text if text else None

    except Exception as e:
        logging.error(f"Audio transcription error: {e}", exc_info=True)
        return None
    finally:
        if audio_path and os.path.exists(audio_path):
            try:
                os.unlink(audio_path)
            except OSError:
                pass


def transcribe_voice_note(
    voice: dict,
    api_base: str,
    token: str,
) -> str | None:
    """
    Download a Telegram voice note (OGG/Opus) and transcribe with faster-whisper.

    Args:
        voice: Telegram voice message dict (must contain 'file_id')
        api_base: Telegram API base URL
        token: Bot token for file download

    Returns:
        Transcribed text, or None if transcription failed/unavailable.
    """
    return _download_and_transcribe(voice, api_base, token, suffix=".ogg")


def transcribe_audio_file(
    audio: dict,
    api_base: str,
    token: str,
) -> str | None:
    """
    Download a Telegram audio file or video_note and transcribe with faster-whisper.

    Handles Telegram ``audio`` objects (uploaded MP3/AAC/FLAC/…) and
    ``video_note`` objects (circular video messages recorded in-app).

    Args:
        audio: Telegram audio or video_note dict (must contain 'file_id')
        api_base: Telegram API base URL
        token: Bot token for file download

    Returns:
        Transcribed text, or None if transcription failed/unavailable.
    """
    mime = audio.get("mime_type", "audio/mpeg")
    suffix = _MIME_TO_EXT.get(mime, ".mp3")
    return _download_and_transcribe(audio, api_base, token, suffix=suffix)
