# Angdigo P1L — versi 0.0.5

Angdigo P1L adalah eksperimen bahasa pemrograman kecil (interpreter minimal) dengan CLI `angd`.
Tujuan: prototipe sintaks yang mudah dibaca dan integrasi ringan dengan Python.

Instal:
```
pip install angdigo-p1l
```

Quickstart:
```
angd run example.adg       # jalankan file Angdigo
angd repl                 # REPL interaktif
angd install <package>    # pip install <package>
angd update version 0.0.5 # update pyproject & __init__ versi
angd version              # tampilkan versi runtime
```

Fitur bahasa (yang sudah diimplementasikan):
- `=` : assignment (contoh: `a = 1 + 2`)
- Aritmetika: `+`, `-`, `*`, `/`, `**`, `%`
- Boolean: `true`, `false`, `false2`, `false#` (dipetakan ke Python True/False)
- `print <expr>` : cetak hasil ekspresi
- `prant <a> <b> ...` : print multi-arg (memisah arg dengan spasi)
- `function[#annotation] name(params)` ... `end` : definisi fungsi
	- contoh anotasi: `function#lang`, `function#install:{package}` (jika `install:{...}` akan menjalankan `pip install` pada paket yang ditentukan saat definisi)
- `mark <name>` : tandai fungsi/entitas
- `fetch <url>` / `fecth <url>` : fetch sederhana (saat ini hanya menampilkan aksi)
- `import <module_or_file>` : import modul Python atau jalankan file `.adg`
- `for <var> in <iter>:` ... `end` : loop (tutup block dengan `end`)
- `control:{key:target ...}` : map kontrol ke variabel/fungsi

Catatan & batasan:
- Interpreter ini adalah prototype: ekspresi dievaluasi lewat AST terbatas.
- Beberapa kata kunci yang mungkin terlihat di bahasa (mis. `make`, `maker`, `module`, `main`) masih direncanakan atau parsial.

Contoh program: lihat `example.adg`.

Kontribusi: buka issue atau fork repositori ini untuk mengembangkan fitur lebih lanjut.
