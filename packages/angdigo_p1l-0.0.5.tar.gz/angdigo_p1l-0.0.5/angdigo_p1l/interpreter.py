import ast
import operator as op
import shlex
import subprocess
import sys
import re
from pathlib import Path

ALLOWED_OPERATORS = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.Pow: op.pow,
    ast.Mod: op.mod,
    ast.FloorDiv: op.floordiv,
    ast.UAdd: op.pos,
    ast.USub: op.neg,
}


class ReturnException(Exception):
    def __init__(self, value):
        self.value = value


class UserFunction:
    def __init__(self, name, params, body, annotation=None):
        self.name = name
        self.params = [p.strip() for p in params.split(",") if p.strip()] if params else []
        self.body = body
        self.annotation = annotation

    def call(self, args, env):
        local = Environment(parent=env)
        for i, p in enumerate(self.params):
            local.vars[p] = args[i] if i < len(args) else None
        try:
            run_lines(self.body, local)
        except ReturnException as r:
            return r.value
        return None


class Environment:
    def __init__(self, parent=None):
        self.vars = {}
        self.functions = {}
        self.controls = {}
        self.marks = {}
        self.parent = parent

    def get(self, name):
        if name in self.vars:
            return self.vars[name]
        if name in self.functions:
            return self.functions[name]
        if self.parent:
            return self.parent.get(name)
        if name in ("true", "True"):
            return True
        if name in ("false", "false2", "false#", "False"):
            return False
        if name == "range":
            return range
        if name == "len":
            return len
        raise NameError(f"Name '{name}' is not defined")

    def set(self, name, value):
        self.vars[name] = value


def _eval_node(node, env):
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        return env.get(node.id)
    if isinstance(node, ast.BinOp):
        left = _eval_node(node.left, env)
        right = _eval_node(node.right, env)
        f = ALLOWED_OPERATORS.get(type(node.op))
        if f is None:
            raise ValueError("Operator tidak diizinkan")
        return f(left, right)
    if isinstance(node, ast.UnaryOp):
        operand = _eval_node(node.operand, env)
        f = ALLOWED_OPERATORS.get(type(node.op))
        if f is None:
            raise ValueError("Operator unary tidak diizinkan")
        return f(operand)
    if isinstance(node, ast.Call):
        func = _eval_node(node.func, env)
        args = [_eval_node(a, env) for a in node.args]
        if isinstance(func, UserFunction):
            return func.call(args, env)
        if callable(func):
            return func(*args)
        raise ValueError("Object not callable")
    if isinstance(node, ast.List):
        return [_eval_node(e, env) for e in node.elts]
    if isinstance(node, ast.Tuple):
        return tuple(_eval_node(e, env) for e in node.elts)
    if isinstance(node, ast.Dict):
        return {_eval_node(k, env): _eval_node(v, env) for k, v in zip(node.keys, node.values)}
    raise ValueError(f"Ekspresi tidak didukung: {ast.dump(node)}")


def eval_expr(expr: str, env: Environment):
    tree = ast.parse(expr, mode="eval")
    return _eval_node(tree.body, env)


def run_lines(lines, env: Environment):
    outputs = []
    i = 0
    while i < len(lines):
        raw = lines[i]
        i += 1
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("function"):
            m = re.match(r'^function(?:#(?P<ann>[^\s]+))?\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*(?:\((?P<params>[^)]*)\))?', line)
            if not m:
                continue
            name = m.group('name')
            ann = m.group('ann')
            params = m.group('params') or ''
            body = []
            while i < len(lines):
                l = lines[i].strip()
                i += 1
                if l == 'end':
                    break
                body.append(lines[i-1])
            func = UserFunction(name, params, body, ann)
            env.functions[name] = func
            if ann and ann.startswith('install'):
                m2 = re.match(r'install:?\{(?P<p>.*)\}', ann)
                pkg = m2.group('p') if m2 else None
                if pkg:
                    subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])
            continue
        if line.startswith('return '):
            expr = line[len('return '):].strip()
            val = eval_expr(expr, env)
            raise ReturnException(val)
        if line.startswith('for '):
            m = re.match(r'for\s+(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s+in\s+(?P<iter>.+):?$', line)
            if not m:
                continue
            var = m.group('var')
            iter_expr = m.group('iter').rstrip(':').strip()
            block = []
            while i < len(lines):
                l = lines[i].strip()
                i += 1
                if l == 'end':
                    break
                block.append(lines[i-1])
            iterable = eval_expr(iter_expr, env)
            for v in iterable:
                env.set(var, v)
                run_lines(block, env)
            continue
        if line.startswith('print '):
            expr = line[len('print '):].strip()
            try:
                val = eval_expr(expr, env)
            except Exception:
                val = expr.strip('"').strip("'")
            outputs.append(val)
            print(val)
            continue
        if line.startswith('prant '):
            rest = line[len('prant '):].strip()
            toks = shlex.split(rest)
            vals = []
            for t in toks:
                try:
                    v = eval_expr(t, env)
                except Exception:
                    v = t
                vals.append(str(v))
            out = ' '.join(vals)
            outputs.append(out)
            print(out)
            continue
        if line.startswith('mark'):
            parts = line.split()
            if len(parts) >= 2:
                target = parts[1]
                env.marks[target] = True
            continue
        if line.startswith('fetch') or line.startswith('fecth'):
            parts = shlex.split(line)
            arg = parts[1] if len(parts) > 1 else ''
            outputs.append(f'fetching {arg}')
            print(f'fetching {arg}')
            continue
        if line.startswith('control'):
            m = re.search(r'\{(?P<body>.*)\}', line)
            if m:
                body = m.group('body')
                pairs = re.findall(r'([A-Za-z0-9_]+)\s*:\s*([A-Za-z0-9_]+)', body)
                for k, v in pairs:
                    try:
                        env.controls[k] = env.get(v)
                    except Exception:
                        env.controls[k] = v
            continue
        if line.startswith('import '):
            parts = shlex.split(line)
            if len(parts) >= 2:
                target = parts[1].strip('"').strip("'")
                p = Path(target)
                if p.exists():
                    src = p.read_text(encoding='utf-8')
                    run_source(src, env)
                else:
                    try:
                        __import__(target)
                        env.set(target, sys.modules[target])
                    except Exception:
                        print(f'could not import {target}', file=sys.stderr)
            continue
        if '=' in line:
            left, right = line.split('=', 1)
            name = left.strip()
            val = eval_expr(right.strip(), env)
            env.set(name, val)
            continue
        if '(' in line and line.endswith(')'):
            try:
                val = eval_expr(line, env)
                if val is not None:
                    outputs.append(val)
                    print(val)
            except Exception as e:
                print(f'Error: {e}', file=sys.stderr)
            continue
        try:
            val = eval_expr(line, env)
            if val is not None:
                outputs.append(val)
                print(val)
            continue
        except Exception:
            print(f'Unknown statement: {line}', file=sys.stderr)
            continue
    return outputs


def run_source(source: str, env: Environment = None):
    if env is None:
        env = Environment()
    lines = source.splitlines()
    return run_lines(lines, env)


def run_file(path: str, env: Environment = None):
    p = Path(path)
    src = p.read_text(encoding='utf-8')
    return run_source(src, env)
