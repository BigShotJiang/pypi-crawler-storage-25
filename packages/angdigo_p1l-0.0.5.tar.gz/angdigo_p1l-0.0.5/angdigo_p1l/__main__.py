import argparse
import sys
import subprocess
import re
from pathlib import Path
from . import __version__
from .interpreter import run_source, run_file


def _update_version_in_pyproject(project_root: Path, new_version: str):
    pyproject = project_root / "pyproject.toml"
    if not pyproject.exists():
        return False
    txt = pyproject.read_text(encoding="utf-8")
    newtxt = re.sub(r'(?m)^version\s*=\s*".*"$', f'version = "{new_version}"', txt, count=1)
    pyproject.write_text(newtxt, encoding="utf-8")
    init_file = project_root / "angdigo_p1l" / "__init__.py"
    if init_file.exists():
        itxt = init_file.read_text(encoding="utf-8")
        inew = re.sub(r'__version__\s*=\s*".*"', f'__version__ = "{new_version}"', itxt, count=1)
        init_file.write_text(inew, encoding="utf-8")
    return True


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    parser = argparse.ArgumentParser(prog="angd", description="Angdigo P1L runtime")
    sub = parser.add_subparsers(dest="cmd")
    runp = sub.add_parser("run", help="Run a source file")
    runp.add_argument("file", nargs="?", help="Source file to run")
    runp.add_argument("-e", "--expr", help="Execute inline expression")
    sub.add_parser("repl", help="Start REPL")
    installp = sub.add_parser("install", help="Install library for angd")
    installp.add_argument("package", help="Package name to install")
    updatep = sub.add_parser("update", help="Update project metadata")
    update_sub = updatep.add_subparsers(dest="update_cmd")
    update_ver = update_sub.add_parser("version", help="Update version")
    update_ver.add_argument("new_version", help="New version string")
    sub.add_parser("version", help="Show version")

    args = parser.parse_args(argv)
    if args.cmd == "run":
        if getattr(args, "expr", None) is not None:
            for o in run_source(args.expr):
                print(o)
            return 0
        if not args.file:
            print("Nothing to run", file=sys.stderr)
            return 2
        run_file(args.file)
    elif args.cmd == "repl":
        print("Angdigo P1L REPL. Ketik 'exit' untuk keluar.")
        try:
            while True:
                line = input("angd> ")
                if line.strip() in ("exit", "quit"):
                    break
                for o in run_source(line):
                    print(o)
        except EOFError:
            print()
    elif args.cmd == "install":
        pkg = args.package
        print(f"Installing {pkg} using pip...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])
    elif args.cmd == "update":
        if getattr(args, "update_cmd", None) == "version":
            newv = args.new_version
            project_root = Path(__file__).resolve().parents[1]
            ok = _update_version_in_pyproject(project_root, newv)
            if ok:
                print(f"Updated project version to {newv}")
            else:
                print("Failed to update version (pyproject.toml not found)", file=sys.stderr)
    elif args.cmd == "version":
        print(__version__)
    else:
        parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
