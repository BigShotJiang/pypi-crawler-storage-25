# Devague now ships a documented spec contract: every frame is a durable, reloadable artifact, and converge returns a structured result (ready_for_spec, blockers, warnings, parked_items, required_next_moves) instead of prose-only advice

> Devague now ships a documented spec contract: every frame is a durable, reloadable artifact, and converge returns a structured result (ready_for_spec, blockers, warnings, parked_items, required_next_moves) instead of prose-only advice

## Audience

- Devague and the assisting LLM that drives it — they coordinate around structured feature-framing state without a rigid wizard

## Before → After

- Before: Framing state is partly implicit and undocumented; converge returns prose-only advice ({passed, missing}); there is no documented contract an LLM can rely on
- After: A vague idea becomes a claim-based, pressure-tested, buildable spec held in a durable, reloadable artifact whose entities are validated

## Why it matters

- An LLM and devague can only coordinate reliably around a contract that is documented, validated, and machine-readable — convergence must mean something, not vibes

## Requirements / honesty conditions

- A frame round-trips losslessly (save then load yields an identical frame) including schema_version, the new claim types, and the structured convergence payload; existing 0.4.0 frames still load
- Every move accepts and emits documented JSON, and the contract spells out per-move input / output / state-transition / validation-errors so an LLM can drive devague without guessing internal state
- Matches shipped 0.4.0 reality — converge --json emits {passed, missing} today and no contract doc is committed (verifiable in the repo before relying on it)
- The contract is enforced by validation on load: a schema-violating frame is rejected with a clear, actionable error rather than silently accepted
- Convergence stays evidence-based and export stays gated on converge passing; the gate is computed only from confirmed claims and confirmed honesty conditions, never a hunch
- The deterministic move-driven model is preserved: no fixed prompt sequence is added; the CLI stays a state tracker and the LLM still chooses the next move
- Every contract operation (create / load / mutate / show / converge / export) runs fully offline against local .devague/ state with zero network calls
- LLM-proposed claims and honesty conditions persist as proposed (origin=llm) and require an explicit user confirm before they affect convergence — nothing auto-confirms
- converge --json emits ONLY the new structured shape {ready_for_spec, blockers, warnings, parked_items, required_next_moves} (hard break); the skill's status helper is updated in the same change; blockers block convergence and warnings do not
- The committed contract doc is the source of truth for kinds / states / fields / transitions and includes at least one worked frame example the CLI can actually round-trip
- create / load / mutate / show round-trip through the JSON store under validation, and the demonstrated operations are covered by passing tests
- Each of the four areas (provenance, honesty-condition confirmation, parking vagueness, convergence failure) has at least one test asserting the contract behavior, all green in CI
- The doc maps the issue's proposed names (llm_proposed, user_confirmed, intentionally_out_of_scope, ...) onto the shipped (state x origin) model so no information is lost and no rename is required
- Each new type's gate impact is documented and tested: requirement is spec-affecting (needs a confirmed honesty condition like other claims); non_goal and decision are descriptive (non-blocking); an unconfirmed assumption surfaces as a warning, not a blocker
- schema_version is written on every save and checked on load; an unknown or newer version fails closed with a clear error rather than corrupting state

## Success signals

- converge returns a structured result (ready_for_spec, blockers, warnings, parked_items, required_next_moves) with blockers instead of prose-only advice
- A documented spec contract exists in the repo, with worked contract examples for at least one feature frame
- The CLI can create, load, mutate, and display a frame locally; core entities are validated
- Tests cover claim provenance, honesty-condition confirmation, parking vagueness, and convergence failure
- The claim-type vocabulary adds non_goal, requirement, assumption, and decision to the shipped set, each with a documented convergence-gate impact
- Every frame carries a schema_version field; load validates by version so existing frames keep loading as the schema grows

## Non-goals

- Not a full PRD generator and not a fixed wizard; the move-driven, deterministic model stays
- The local contract requires no GitHub, agents, or external services
- Convergence is never claimed on vibes, and LLM-proposed content is never silently promoted to confirmed truth
- The contract formalizes 0.4.0's shipped vocabulary as canonical — state in {proposed,confirmed,rejected,parked} x origin in {user,llm}; no rename and no migration of existing frames

## Open / follow-up

- Whether to also publish a formal machine-readable JSON Schema file alongside the prose contract doc + dataclasses, or treat the dataclasses as the schema of record
- Whether requirement-type claims should eventually carry acceptance criteria like plan tasks do (overlaps the spec-to-plan leg), or stay prose-only in the frame
