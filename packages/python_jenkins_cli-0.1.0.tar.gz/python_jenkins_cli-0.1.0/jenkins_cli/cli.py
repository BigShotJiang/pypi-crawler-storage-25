"""Jenkins CLI - Main command group and all subcommands."""
import time
from typing import Optional
import sys
import click
import jenkins
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Confirm

from jenkins_cli import __version__
from jenkins_cli.client import (
    get_client,
    test_connection,
    get_jobs,
    get_job_info,
    get_build_info,
    get_build_console,
    trigger_build,
    stop_build,
    get_queue,
    get_nodes,
    enable_job,
    disable_job,
    delete_job,
    copy_job,
    get_job_config,
    create_job,
)
from jenkins_cli.config import load_config, save_config, get_connection_params
from jenkins_cli.output import (
    console,
    print_jobs,
    print_job_info,
    print_build_info,
    print_queue,
    print_nodes,
    print_success,
    print_error,
    print_info,
)


def handle_error(func):
    """Decorator to handle common Jenkins errors gracefully."""
    import functools

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except jenkins.JenkinsException as e:
            print_error(f"Jenkins error: {e}")
            sys.exit(1)
        except RuntimeError as e:
            print_error(str(e))
            sys.exit(1)
        except Exception as e:
            print_error(f"Unexpected error: {e}")
            sys.exit(1)

    return wrapper


# ──────────────────────────────────────────────
# Root group
# ──────────────────────────────────────────────
@click.group()
@click.version_option(version=__version__, prog_name="jenkins-cli")
def cli():
    """🔧 Jenkins CLI — Manage Jenkins from your terminal.

    \b
    Quick start:
      jenkins-cli config set          Configure connection
      jenkins-cli job list            List all jobs
      jenkins-cli build trigger JOB   Trigger a build
    """
    pass


# ──────────────────────────────────────────────
# config commands
# ──────────────────────────────────────────────
@cli.group()
def config():
    """Manage Jenkins connection configuration."""
    pass


@config.command("set")
@click.option("--url", prompt="Jenkins URL", help="Jenkins server URL")
@click.option("--username", prompt="Username", help="Jenkins username")
@click.option(
    "--token",
    prompt="API Token",
    hide_input=True,
    help="Jenkins API token (not password)",
)
@handle_error
def config_set(url: str, username: str, token: str):
    """Configure Jenkins connection settings."""
    url = url.rstrip("/")
    with Progress(
            SpinnerColumn(), TextColumn("[cyan]Testing connection..."), transient=True
    ) as progress:
        progress.add_task("")
        info = test_connection(url, username, token)

    save_config({"url": url, "username": username, "token": token})
    print_success(f"Connected to Jenkins {info['version']} — {info['num_jobs']} jobs found.")


@config.command("show")
def config_show():
    """Show current configuration (token masked)."""
    cfg = load_config()
    if not cfg:
        print_info("No configuration found. Run: jenkins-cli config set")
        return
    console.print(f"  URL:      [cyan]{cfg.get('url', '-')}[/]")
    console.print(f"  Username: [cyan]{cfg.get('username', '-')}[/]")
    console.print(f"  Token:    [dim]{'*' * 12}[/]")


@config.command("clear")
def config_clear():
    """Remove saved configuration."""
    if Confirm.ask("Clear saved Jenkins configuration?"):
        save_config({})
        print_success("Configuration cleared.")


# ──────────────────────────────────────────────
# job commands
# ──────────────────────────────────────────────
@cli.group()
def job():
    """Manage Jenkins jobs."""
    pass


@job.command("list")
@click.option("--folder", "-f", default=None, help="Filter by folder prefix")
@handle_error
def job_list(folder: Optional[str]):
    """List all jobs."""
    client = get_client()
    with Progress(SpinnerColumn(), TextColumn("[cyan]Fetching jobs..."), transient=True) as p:
        p.add_task("")
        jobs = get_jobs(client, folder)
    if not jobs:
        print_info("No jobs found.")
        return
    print_jobs(jobs)
    console.print(f"\n[dim]Total: {len(jobs)} jobs[/dim]")


@job.command("info")
@click.argument("name")
@handle_error
def job_info(name: str):
    """Show detailed information for a job."""
    client = get_client()
    info = get_job_info(client, name)
    print_job_info(info)


@job.command("enable")
@click.argument("name")
@handle_error
def job_enable(name: str):
    """Enable a job."""
    enable_job(get_client(), name)
    print_success(f"Job '{name}' enabled.")


@job.command("disable")
@click.argument("name")
@handle_error
def job_disable(name: str):
    """Disable a job."""
    disable_job(get_client(), name)
    print_success(f"Job '{name}' disabled.")


@job.command("delete")
@click.argument("name")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
@handle_error
def job_delete(name: str, yes: bool):
    """Delete a job."""
    if not yes and not Confirm.ask(f"Delete job '[red]{name}[/]'?"):
        print_info("Cancelled.")
        return
    delete_job(get_client(), name)
    print_success(f"Job '{name}' deleted.")


@job.command("copy")
@click.argument("from_name")
@click.argument("to_name")
@handle_error
def job_copy(from_name: str, to_name: str):
    """Copy a job."""
    copy_job(get_client(), from_name, to_name)
    print_success(f"Copied '{from_name}' → '{to_name}'.")


@job.command("config")
@click.argument("name")
@click.option("--output", "-o", type=click.Path(), help="Save XML to file")
@handle_error
def job_config(name: str, output: Optional[str]):
    """Get job XML configuration."""
    xml = get_job_config(get_client(), name)
    if output:
        with open(output, "w") as f:
            f.write(xml)
        print_success(f"Config saved to {output}")
    else:
        console.print(xml)


@job.command("create")
@click.argument("name")
@click.argument("config_file", type=click.Path(exists=True))
@handle_error
def job_create(name: str, config_file: str):
    """Create a job from XML config file."""
    with open(config_file) as f:
        xml = f.read()
    create_job(get_client(), name, xml)
    print_success(f"Job '{name}' created.")


# ──────────────────────────────────────────────
# build commands
# ──────────────────────────────────────────────
@cli.group()
def build():
    """Manage Jenkins builds."""
    pass


@build.command("trigger")
@click.argument("job_name")
@click.option(
    "--param",
    "-p",
    multiple=True,
    metavar="KEY=VALUE",
    help="Build parameter (can be repeated)",
)
@click.option("--wait", "-w", is_flag=True, help="Wait for build to complete")
@click.option("--follow", "-f", is_flag=True, help="Follow console output")
@handle_error
def build_trigger(job_name: str, param: tuple, wait: bool, follow: bool):
    """Trigger a build for a job."""
    parameters = {}
    for p in param:
        if "=" not in p:
            print_error(f"Invalid parameter format: '{p}'. Use KEY=VALUE")
            sys.exit(1)
        k, v = p.split("=", 1)
        parameters[k] = v

    client = get_client()
    queue_id = trigger_build(client, job_name, parameters or None)
    print_success(f"Build queued (queue ID: {queue_id})")

    if not (wait or follow):
        return

    # Poll queue until build starts
    print_info("Waiting for build to start...")
    build_num = None
    for _ in range(60):
        time.sleep(3)
        try:
            queue_item = client.get_queue_item(queue_id)
            if "executable" in queue_item:
                build_num = queue_item["executable"]["number"]
                break
        except Exception:
            pass

    if build_num is None:
        print_error("Timed out waiting for build to start.")
        sys.exit(1)

    print_info(f"Build #{build_num} started.")

    if follow:
        _follow_console(client, job_name, build_num)
    elif wait:
        _wait_for_build(client, job_name, build_num)


def _wait_for_build(client, job_name: str, build_num: int):
    with Progress(SpinnerColumn(), TextColumn("[cyan]Build running..."), transient=True) as p:
        p.add_task("")
        while True:
            info = get_build_info(client, job_name, build_num)
            if not info.get("building"):
                break
            time.sleep(5)
    result = info.get("result", "UNKNOWN")
    style = "green" if result == "SUCCESS" else "red"
    console.print(f"\nBuild #{build_num} finished: [{style}]{result}[/{style}]")


def _follow_console(client, job_name: str, build_num: int):
    console.print(f"\n[dim]─── Console Output ───[/dim]")
    offset = 0
    while True:
        output = get_build_console(client, job_name, build_num)
        new_content = output[offset:]
        if new_content:
            print(new_content, end="", flush=True)
            offset = len(output)
        info = get_build_info(client, job_name, build_num)
        if not info.get("building"):
            break
        time.sleep(3)
    result = info.get("result", "UNKNOWN")
    style = "green" if result == "SUCCESS" else "red"
    console.print(f"\n[dim]─── Build #{build_num}: [{style}]{result}[/{style}] ───[/dim]")


@build.command("info")
@click.argument("job_name")
@click.argument("build_num", type=int, default=-1)
@handle_error
def build_info_cmd(job_name: str, build_num: int):
    """Show build information. Use -1 (default) for last build."""
    client = get_client()
    if build_num == -1:
        job = get_job_info(client, job_name)
        last = job.get("lastBuild")
        if not last:
            print_info("No builds found for this job.")
            return
        build_num = last["number"]
    info = get_build_info(client, job_name, build_num)
    print_build_info(info)


@build.command("log")
@click.argument("job_name")
@click.argument("build_num", type=int, default=-1)
@click.option("--follow", "-f", is_flag=True, help="Follow log output in real time")
@handle_error
def build_log(job_name: str, build_num: int, follow: bool):
    """Show build console log."""
    client = get_client()
    if build_num == -1:
        job = get_job_info(client, job_name)
        last = job.get("lastBuild")
        if not last:
            print_info("No builds found.")
            return
        build_num = last["number"]

    if follow:
        _follow_console(client, job_name, build_num)
    else:
        output = get_build_console(client, job_name, build_num)
        console.print(output)


@build.command("stop")
@click.argument("job_name")
@click.argument("build_num", type=int)
@handle_error
def build_stop(job_name: str, build_num: int):
    """Stop a running build."""
    stop_build(get_client(), job_name, build_num)
    print_success(f"Build #{build_num} of '{job_name}' stopped.")


@build.command("history")
@click.argument("job_name")
@click.option("--limit", "-n", default=10, show_default=True, help="Number of builds")
@handle_error
def build_history(job_name: str, limit: int):
    """Show recent build history for a job."""
    client = get_client()
    info = get_job_info(client, job_name)
    # Reuse job_info output which shows recent builds
    print_job_info(info)


# ──────────────────────────────────────────────
# queue commands
# ──────────────────────────────────────────────
@cli.command()
@handle_error
def queue():
    """Show the Jenkins build queue."""
    items = get_queue(get_client())
    print_queue(items)


# ──────────────────────────────────────────────
# node commands
# ──────────────────────────────────────────────
@cli.command()
@handle_error
def nodes():
    """List Jenkins nodes/agents."""
    node_list = get_nodes(get_client())
    print_nodes(node_list)


# ──────────────────────────────────────────────
# ping command
# ──────────────────────────────────────────────
@cli.command()
@handle_error
def ping():
    """Check Jenkins connection status."""
    params = get_connection_params()
    if not all(params.values()):
        print_error("Not configured. Run: jenkins-cli config set")
        sys.exit(1)
    info = test_connection(params["url"], params["username"], params["password"])
    print_success(
        f"Connected! Jenkins {info['version']} — {info['num_jobs']} jobs"
    )


if __name__ == "__main__":
    cli()
