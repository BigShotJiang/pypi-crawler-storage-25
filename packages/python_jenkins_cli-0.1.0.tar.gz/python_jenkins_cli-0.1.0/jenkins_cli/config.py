"""Configuration management for Jenkins CLI."""
import os
import json
from pathlib import Path
from typing import Optional

CONFIG_DIR = Path.home() / ".jenkins-cli"
CONFIG_FILE = CONFIG_DIR / "config.json"


def load_config() -> dict:
    """Load configuration from file."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def save_config(config: dict) -> None:
    """Save configuration to file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)
    os.chmod(CONFIG_FILE, 0o600)


def get_connection_params() -> dict:
    """Get Jenkins connection parameters from config or environment."""
    config = load_config()

    url = os.environ.get("JENKINS_URL") or config.get("url")
    username = os.environ.get("JENKINS_USER") or config.get("username")
    password = os.environ.get("JENKINS_TOKEN") or config.get("token")

    return {"url": url, "username": username, "password": password}


def is_configured() -> bool:
    """Check if Jenkins connection is configured."""
    params = get_connection_params()
    return all(params.values())
