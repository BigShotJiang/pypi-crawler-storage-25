"""Rich terminal output formatters."""
from datetime import datetime
from typing import List, Dict, Any, Optional

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich import box

console = Console()


def _build_status_style(result: Optional[str], building: bool = False) -> tuple:
    """Return (icon, style) for a build result."""
    if building:
        return "⏳", "yellow"
    status_map = {
        "SUCCESS": ("✅", "green"),
        "FAILURE": ("❌", "red"),
        "UNSTABLE": ("⚠️ ", "yellow"),
        "ABORTED": ("🚫", "dim"),
        "NOT_BUILT": ("⬜", "dim"),
    }
    return status_map.get(result or "", ("❓", "dim"))


def _format_duration(ms: Optional[int]) -> str:
    if not ms:
        return "-"
    s = ms // 1000
    if s < 60:
        return f"{s}s"
    m, s = divmod(s, 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m {s}s"


def _format_timestamp(ms: Optional[int]) -> str:
    if not ms:
        return "-"
    return datetime.fromtimestamp(ms / 1000).strftime("%Y-%m-%d %H:%M:%S")


def print_jobs(jobs: List[Dict]) -> None:
    """Print jobs in a formatted table."""
    table = Table(
        title="Jenkins Jobs",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("Name", style="bold", no_wrap=True)
    table.add_column("Status", justify="center")
    table.add_column("URL", style="dim")

    for job in jobs:
        color_map = {
            "blue": ("✅ Stable", "green"),
            "red": ("❌ Failed", "red"),
            "yellow": ("⚠️  Unstable", "yellow"),
            "disabled": ("🚫 Disabled", "dim"),
            "aborted": ("🚫 Aborted", "dim"),
            "notbuilt": ("⬜ Not Built", "dim"),
        }
        color = job.get("color", "")
        # Handle animated (building) states like "blue_anime"
        building = color.endswith("_anime")
        base_color = color.replace("_anime", "")
        status_text, style = color_map.get(base_color, ("❓ Unknown", "dim"))
        if building:
            status_text = "⏳ Building"
            style = "yellow"

        table.add_row(
            job.get("fullname") or job.get("name", ""),
            Text(status_text, style=style),
            job.get("url", ""),
        )

    console.print(table)


def print_job_info(info: Dict) -> None:
    """Print detailed job information."""
    name = info.get("fullName") or info.get("name", "")
    desc = info.get("description") or "No description"
    buildable = "Yes" if info.get("buildable") else "No"

    last_build = info.get("lastBuild") or {}
    last_success = info.get("lastSuccessfulBuild") or {}
    last_fail = info.get("lastFailedBuild") or {}

    panel_content = Text()
    panel_content.append(f"Description:   ", style="bold")
    panel_content.append(f"{desc}\n")
    panel_content.append(f"Buildable:     ", style="bold")
    panel_content.append(f"{buildable}\n")
    panel_content.append(f"URL:           ", style="bold")
    panel_content.append(f"{info.get('url', '-')}\n\n")
    panel_content.append(f"Last Build:    ", style="bold")
    panel_content.append(f"#{last_build.get('number', '-')}\n" if last_build else "-\n")
    panel_content.append(f"Last Success:  ", style="bold")
    panel_content.append(f"#{last_success.get('number', '-')}\n" if last_success else "-\n")
    panel_content.append(f"Last Failure:  ", style="bold")
    panel_content.append(f"#{last_fail.get('number', '-')}\n" if last_fail else "-\n")

    console.print(Panel(panel_content, title=f"[bold cyan]{name}[/]", box=box.ROUNDED))

    # Recent builds table
    builds = info.get("builds", [])[:10]
    if builds:
        table = Table(box=box.SIMPLE, header_style="bold")
        table.add_column("#", justify="right")
        table.add_column("Result", justify="center")
        table.add_column("Duration")
        table.add_column("Timestamp")
        table.add_column("URL", style="dim")

        for b in builds:
            num = b.get("number", "?")
            result = b.get("result")
            building = b.get("building", False)
            icon, style = _build_status_style(result, building)
            table.add_row(
                str(num),
                Text(f"{icon} {result or ('BUILDING' if building else '-')}", style=style),
                _format_duration(b.get("duration")),
                _format_timestamp(b.get("timestamp")),
                b.get("url", ""),
            )
        console.print(table)


def print_build_info(info: Dict) -> None:
    """Print build details."""
    result = info.get("result")
    building = info.get("building", False)
    icon, style = _build_status_style(result, building)

    content = Text()
    content.append("Status:      ", style="bold")
    content.append(f"{icon} {result or ('BUILDING' if building else '-')}\n", style=style)
    content.append("Duration:    ", style="bold")
    content.append(f"{_format_duration(info.get('duration'))}\n")
    content.append("Started:     ", style="bold")
    content.append(f"{_format_timestamp(info.get('timestamp'))}\n")
    content.append("URL:         ", style="bold")
    content.append(f"{info.get('url', '-')}\n")

    causes = info.get("actions", [])
    for action in causes:
        for cause in action.get("causes", []):
            content.append("Triggered:   ", style="bold")
            content.append(f"{cause.get('shortDescription', '-')}\n")

    job_name = info.get("fullDisplayName", "Build Info")
    console.print(Panel(content, title=f"[bold cyan]{job_name}[/]", box=box.ROUNDED))


def print_queue(items: List[Dict]) -> None:
    """Print build queue."""
    if not items:
        console.print("[dim]Queue is empty.[/dim]")
        return

    table = Table(title="Build Queue", box=box.ROUNDED, header_style="bold cyan")
    table.add_column("ID", justify="right")
    table.add_column("Job")
    table.add_column("Why")
    table.add_column("Queued Since")

    for item in items:
        task = item.get("task", {})
        table.add_row(
            str(item.get("id", "")),
            task.get("name", "-"),
            item.get("why", "-"),
            _format_timestamp(item.get("inQueueSince")),
        )
    console.print(table)


def print_nodes(nodes: List[Dict]) -> None:
    """Print nodes/agents."""
    table = Table(title="Jenkins Nodes", box=box.ROUNDED, header_style="bold cyan")
    table.add_column("Name")
    table.add_column("Status", justify="center")
    table.add_column("Offline Reason")

    for node in nodes:
        offline = node.get("offline", False)
        status = Text("🔴 Offline", style="red") if offline else Text("🟢 Online", style="green")
        table.add_row(
            node.get("name", "-"),
            status,
            node.get("offlineCauseReason") or "-",
        )
    console.print(table)


def print_success(msg: str) -> None:
    console.print(f"[green]✅ {msg}[/green]")


def print_error(msg: str) -> None:
    console.print(f"[red]❌ {msg}[/red]")


def print_info(msg: str) -> None:
    console.print(f"[cyan]ℹ  {msg}[/cyan]")
