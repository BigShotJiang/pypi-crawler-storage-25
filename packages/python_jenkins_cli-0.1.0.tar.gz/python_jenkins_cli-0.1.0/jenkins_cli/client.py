"""Jenkins client wrapper using python-jenkins."""
import jenkins
from typing import Optional, List, Dict, Any
from .config import get_connection_params


def get_client() -> jenkins.Jenkins:
    """Create and return a Jenkins client instance."""
    params = get_connection_params()
    if not all(params.values()):
        raise RuntimeError(
            "Jenkins not configured. Run: jenkins-cli config set "
            "or set JENKINS_URL, JENKINS_USER, JENKINS_TOKEN environment variables."
        )
    return jenkins.Jenkins(
        url=params["url"],
        username=params["username"],
        password=params["password"],
    )


def test_connection(url: str, username: str, token: str) -> Dict[str, Any]:
    """Test Jenkins connection and return server info."""
    client = jenkins.Jenkins(url=url, username=username, password=token)
    info = client.get_info()
    return {
        "version": client.get_version(),
        "num_jobs": len(info.get("jobs", [])),
        "description": info.get("description", ""),
    }


def get_jobs(client: jenkins.Jenkins, folder: Optional[str] = None) -> List[Dict]:
    """Get all jobs, optionally within a folder."""
    if folder:
        jobs = client.get_jobs(folder_depth=1, folder_depth_queried=1)
        return [j for j in jobs if j.get("fullname", "").startswith(folder)]
    return client.get_jobs()


def get_job_info(client: jenkins.Jenkins, name: str) -> Dict:
    """Get detailed info for a job."""
    return client.get_job_info(name)


def get_build_info(client: jenkins.Jenkins, name: str, build_num: int) -> Dict:
    """Get build information."""
    return client.get_build_info(name, build_num)


def get_build_console(client: jenkins.Jenkins, name: str, build_num: int) -> str:
    """Get build console output."""
    return client.get_build_console_output(name, build_num)


def trigger_build(
    client: jenkins.Jenkins, name: str, parameters: Optional[Dict] = None
) -> int:
    """Trigger a build and return queue item number."""
    if parameters:
        return client.build_job(name, parameters=parameters)
    return client.build_job(name)


def stop_build(client: jenkins.Jenkins, name: str, build_num: int) -> None:
    """Stop a running build."""
    client.stop_build(name, build_num)


def get_queue(client: jenkins.Jenkins) -> List[Dict]:
    """Get the build queue."""
    return client.get_queue_info()


def get_nodes(client: jenkins.Jenkins) -> List[Dict]:
    """Get all nodes/agents."""
    return client.get_nodes()


def enable_job(client: jenkins.Jenkins, name: str) -> None:
    client.enable_job(name)


def disable_job(client: jenkins.Jenkins, name: str) -> None:
    client.disable_job(name)


def delete_job(client: jenkins.Jenkins, name: str) -> None:
    client.delete_job(name)


def copy_job(client: jenkins.Jenkins, from_name: str, to_name: str) -> None:
    client.copy_job(from_name, to_name)


def get_job_config(client: jenkins.Jenkins, name: str) -> str:
    return client.get_job_config(name)


def create_job(client: jenkins.Jenkins, name: str, config_xml: str) -> None:
    client.create_job(name, config_xml)
