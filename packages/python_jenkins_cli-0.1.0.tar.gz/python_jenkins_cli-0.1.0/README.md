# 🔧 Jenkins CLI

A beautiful, feature-rich command-line interface for Jenkins built with `python-jenkins`, `Click`, and `Rich`.

![Languate - Python](https://img.shields.io/badge/language-python-blue.svg)
![PyPI - License](https://img.shields.io/pypi/l/python-jenkins-cli)
![PyPI](https://img.shields.io/pypi/v/python-jenkins-cli)
![PyPI - Downloads](https://img.shields.io/pypi/dm/python-jenkins-cli)

## Features

- 🔐 Secure credential storage (`~/.jenkins-cli/config.json`, chmod 600)
- 🌿 Environment variable support (`JENKINS_URL`, `JENKINS_USER`, `JENKINS_TOKEN`)
- 📋 List, inspect, enable/disable, copy, delete jobs
- 🚀 Trigger builds with parameters, wait/follow console output
- 📜 View build history and console logs in real-time
- ⏱  Monitor the build queue
- 🖥  List nodes/agents and their status
- 🎨 Rich terminal output with colors, tables, and icons

## Installation

```bash
pip install python-jenkins-cli
```

## Quick Start

```bash
# 1. Configure connection
jenkins-cli config set

# 2. Verify connection
jenkins-cli ping

# 3. List jobs
jenkins-cli job list
```

## Commands

### Configuration
```bash
jenkins-cli config set            # Interactive setup wizard
jenkins-cli config show           # Show current config
jenkins-cli config clear          # Remove saved config
```

### Job Management
```bash
jenkins-cli job list              # List all jobs
jenkins-cli job list --folder ci  # Filter by folder prefix
jenkins-cli job info my-app       # Detailed job info + recent builds
jenkins-cli job enable  my-app    # Enable a job
jenkins-cli job disable my-app    # Disable a job
jenkins-cli job delete  my-app    # Delete a job (with confirmation)
jenkins-cli job copy    src dst   # Copy a job
jenkins-cli job config  my-app    # Show job XML config
jenkins-cli job config  my-app -o job.xml  # Save XML to file
jenkins-cli job create  new-job job.xml    # Create job from XML
```

### Build Management
```bash
jenkins-cli build trigger my-app                    # Trigger build
jenkins-cli build trigger my-app -p ENV=prod        # With parameters
jenkins-cli build trigger my-app -p A=1 -p B=2 -w  # Wait for completion
jenkins-cli build trigger my-app -f                 # Follow console output
jenkins-cli build info    my-app                    # Last build info
jenkins-cli build info    my-app 42                 # Specific build info
jenkins-cli build log     my-app                    # Last build log
jenkins-cli build log     my-app 42 --follow        # Follow log in real-time
jenkins-cli build stop    my-app 42                 # Stop a build
jenkins-cli build history my-app                    # Recent build history
```

### Infrastructure
```bash
jenkins-cli queue   # Show build queue
jenkins-cli nodes   # List all nodes/agents
jenkins-cli ping    # Test connection
```

## Environment Variables

| Variable        | Description              |
|-----------------|--------------------------|
| `JENKINS_URL`   | Jenkins server URL        |
| `JENKINS_USER`  | Jenkins username          |
| `JENKINS_TOKEN` | Jenkins API token         |

Environment variables take precedence over the saved config file.

## Running Tests

```bash
pip install pytest
pytest tests/ -v
```
