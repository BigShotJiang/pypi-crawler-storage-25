import os

from setuptools import setup, find_packages

this_directory = os.path.abspath(os.path.dirname(__file__))


def read_file(filename):
    with open(os.path.join(this_directory, filename), encoding='utf-8') as f:
        long_description = f.read()
    return long_description


setup(
    name="python-jenkins-cli",
    version="0.1.0",
    description="A beautiful command-line interface for Jenkins",
    long_description=read_file('README.md'),
    long_description_content_type="text/markdown",  # 新参数
    url='https://github.com/hanzhichao/jenkins-cli',
    author="Hanzhichao",
    python_requires=">=3.8",
    packages=find_packages(),
    install_requires=[
        "python-jenkins>=1.8.0",
        "click>=8.0.0",
        "rich>=13.0.0",
    ],
    entry_points={
        "console_scripts": [
            "jenkins-cli=jenkins_cli.cli:cli",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
