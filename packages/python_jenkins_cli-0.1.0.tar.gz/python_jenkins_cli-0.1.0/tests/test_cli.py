"""Tests for Jenkins CLI."""
import json
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock
from click.testing import CliRunner

from jenkins_cli.cli import cli
from jenkins_cli.config import load_config, save_config, get_connection_params


# ──────────────────────────────────────────────
# Config tests
# ──────────────────────────────────────────────
class TestConfig:
    def test_save_and_load(self, tmp_path):
        with patch("jenkins_cli.config.CONFIG_FILE", tmp_path / "config.json"), \
             patch("jenkins_cli.config.CONFIG_DIR", tmp_path):
            save_config({"url": "http://jenkins", "username": "admin", "token": "abc"})
            cfg = load_config()
        assert cfg["url"] == "http://jenkins"
        assert cfg["username"] == "admin"

    def test_env_vars_override_config(self, monkeypatch, tmp_path):
        monkeypatch.setenv("JENKINS_URL", "http://env-jenkins")
        monkeypatch.setenv("JENKINS_USER", "env-user")
        monkeypatch.setenv("JENKINS_TOKEN", "env-token")
        with patch("jenkins_cli.config.CONFIG_FILE", tmp_path / "config.json"), \
             patch("jenkins_cli.config.CONFIG_DIR", tmp_path):
            params = get_connection_params()
        assert params["url"] == "http://env-jenkins"
        assert params["username"] == "env-user"
        assert params["password"] == "env-token"


# ──────────────────────────────────────────────
# CLI command tests
# ──────────────────────────────────────────────
@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def mock_client():
    with patch("jenkins_cli.cli.get_client") as mock:
        yield mock.return_value


class TestCLI:
    def test_version(self, runner):
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output

    def test_help(self, runner):
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "Jenkins CLI" in result.output

    def test_job_list(self, runner, mock_client):
        mock_client.get_jobs.return_value = [
            {"name": "my-app", "fullname": "my-app", "color": "blue", "url": "http://j/job/my-app/"},
            {"name": "api", "fullname": "api", "color": "red", "url": "http://j/job/api/"},
        ]
        with patch("jenkins_cli.cli.is_configured", return_value=True):
            result = runner.invoke(cli, ["job", "list"])
        assert result.exit_code == 0
        assert "my-app" in result.output
        assert "api" in result.output

    def test_job_list_empty(self, runner, mock_client):
        mock_client.get_jobs.return_value = []
        with patch("jenkins_cli.cli.is_configured", return_value=True):
            result = runner.invoke(cli, ["job", "list"])
        assert result.exit_code == 0
        assert "No jobs found" in result.output

    def test_build_trigger(self, runner, mock_client):
        mock_client.build_job.return_value = 42
        with patch("jenkins_cli.cli.is_configured", return_value=True):
            result = runner.invoke(cli, ["build", "trigger", "my-app"])
        assert result.exit_code == 0
        assert "42" in result.output  # queue ID

    def test_build_trigger_with_params(self, runner, mock_client):
        mock_client.build_job.return_value = 5
        with patch("jenkins_cli.cli.is_configured", return_value=True):
            result = runner.invoke(
                cli, ["build", "trigger", "my-app", "-p", "ENV=prod", "-p", "VERSION=1.2"]
            )
        assert result.exit_code == 0
        mock_client.build_job.assert_called_once_with(
            "my-app", parameters={"ENV": "prod", "VERSION": "1.2"}
        )

    def test_build_stop(self, runner, mock_client):
        with patch("jenkins_cli.cli.is_configured", return_value=True):
            result = runner.invoke(cli, ["build", "stop", "my-app", "7"])
        assert result.exit_code == 0
        mock_client.stop_build.assert_called_once_with("my-app", 7)

    def test_queue(self, runner, mock_client):
        mock_client.get_queue_info.return_value = []
        with patch("jenkins_cli.cli.is_configured", return_value=True):
            result = runner.invoke(cli, ["queue"])
        assert result.exit_code == 0
        assert "empty" in result.output.lower()

    def test_nodes(self, runner, mock_client):
        mock_client.get_nodes.return_value = [
            {"name": "master", "offline": False, "offlineCauseReason": ""},
            {"name": "agent-1", "offline": True, "offlineCauseReason": "maintenance"},
        ]
        with patch("jenkins_cli.cli.is_configured", return_value=True):
            result = runner.invoke(cli, ["nodes"])
        assert result.exit_code == 0
        assert "master" in result.output
        assert "agent-1" in result.output

    def test_job_delete_cancelled(self, runner, mock_client):
        with patch("jenkins_cli.cli.is_configured", return_value=True):
            result = runner.invoke(cli, ["job", "delete", "old-job"], input="n\n")
        assert result.exit_code == 0
        mock_client.delete_job.assert_not_called()

    def test_invalid_param_format(self, runner, mock_client):
        with patch("jenkins_cli.cli.is_configured", return_value=True):
            result = runner.invoke(cli, ["build", "trigger", "my-app", "-p", "BADPARAM"])
        assert result.exit_code != 0 or "Invalid parameter" in result.output
