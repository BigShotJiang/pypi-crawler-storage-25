class UnsupportedWebDriverException(Exception):
    pass
