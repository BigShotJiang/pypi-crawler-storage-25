## studio_ui v0.3.0

### Features

- add LagoMeteringAdapter (63a5a93)

## studio_ui v0.2.0

### Features

- implement aggregate builder and debrand studio (8e9bee1)
- architect high-fidelity metadata designers (aafc657)

## studio_ui v0.1.2

### Bug Fixes

- implement bulk dependency upgrades and fix typecheck stubs (bf01d94)
- install pnpm and coreutils in release phase (ed335f8)
- enforce tool availability and install pnpm in CI (b8f9465)
- enforce lockfile sync, stage templates, and fix types (a41aad0)
- enhance local dry-run and silence check-ignore spam (29f9ef6)
- modernize gitops auth and api integration (7f15453)
- secure staging logic and resolve test regressions (e31d701)
- implement pnpm/uv lockfile sync and config cleanup (8302956)
- lint cleanup for cli.py (40b3a78)
- support GITLAB_TOKEN and harden auth check (c08b25c)
- implement atomic direct push for CI/CD stability (2947270)
- modularize release package and resolve test regressions (fe8c676)
- build UI in publish job + remove test dependencies (ebe7661)
- preserve static assets in build (b155a0b)

## studio_ui v0.1.1

### Bug Fixes

- install pnpm and coreutils in release phase (ed335f8)
- enforce tool availability and install pnpm in CI (b8f9465)
- enforce lockfile sync, stage templates, and fix types (a41aad0)
- enhance local dry-run and silence check-ignore spam (29f9ef6)
- modernize gitops auth and api integration (7f15453)
- secure staging logic and resolve test regressions (e31d701)
- implement pnpm/uv lockfile sync and config cleanup (8302956)
- lint cleanup for cli.py (40b3a78)
- support GITLAB_TOKEN and harden auth check (c08b25c)
- implement atomic direct push for CI/CD stability (2947270)
- modularize release package and resolve test regressions (fe8c676)
- build UI in publish job + remove test dependencies (ebe7661)
- preserve static assets in build (b155a0b)

