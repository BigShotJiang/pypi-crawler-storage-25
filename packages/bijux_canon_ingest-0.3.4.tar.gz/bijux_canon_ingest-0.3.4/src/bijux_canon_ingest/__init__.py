# SPDX-License-Identifier: Apache-2.0
# Copyright © 2026 Bijan Mousavi

"""Stable package API for ``bijux_canon_ingest``.

The package root intentionally favors low-level, dependency-light exports.
Application services, CLI shims, and configuration builders stay available for
backward compatibility, but they are resolved lazily so importing the package
does not eagerly pull interface and orchestration code into every consumer.
"""

from __future__ import annotations

from typing import Any, assert_never

from ._lazy_exports import LazyExport, resolve_lazy_export
from ._package_api import LAZY_EXPORTS, PUBLIC_API
from ._version import __version__
from .config.cleaning import DEFAULT_CLEAN_CONFIG, CleanConfig, make_cleaner
from .core.rules_dsl import (
    abstract_min_len,
    any_doc,
    category_startswith,
    none_doc,
    parse_rule,
    rule_all,
    rule_and,
    rule_not,
    rule_or,
    title_contains,
)
from .core.rules_lint import SafeVisitor, assert_rule_is_safe_expr
from .core.rules_pred import (
    DEFAULT_RULES,
    All,
    AnyOf,
    Eq,
    LenGt,
    Not,
    Pred,
    RulesConfig,
    StartsWith,
    eval_pred,
)
from .core.structural_dedup import DedupIterator, structural_dedup_lazy
from .core.types import (
    Chunk,
    ChunkWithoutEmbedding,
    CleanDoc,
    RagEnv,
    RawDoc,
    TextNode,
    TreeDoc,
)
from .fp import (
    FakeTime,
    Reader,
    StageInstrumentation,
    State,
    Writer,
    ask,
    asks,
    censor,
    compose,
    ffilter,
    flatmap,
    flow,
    fmap,
    get,
    identity,
    instrument_stage,
    listen,
    local,
    modify,
    pipe,
    probe,
    producer_pipeline,
    put,
    run_state,
    run_writer,
    tee,
    tell,
    tell_many,
    toggle_logging,
    toggle_metrics,
    toggle_validation,
    transpose_option_result,
    transpose_result_option,
    wr_and_then,
    wr_map,
    wr_pure,
)
from .observability import (
    DebugConfig,
    DocRule,
    IngestTaps,
    IngestTrace,
    Observations,
    TraceLens,
)
from .processing.chunking import (
    gen_chunk_doc,
    gen_chunk_spans,
    gen_overlapping_chunks,
    sliding_windows,
)
from .processing.stages import (
    chunk_doc,
    clean_doc,
    embed_chunk,
    iter_chunk_doc,
    iter_chunk_spans,
    iter_overlapping_chunks_text,
    structural_dedup_chunks,
)
from .result import (
    NONE,
    Err,
    ErrInfo,
    NoneVal,
    Ok,
    Option,
    Result,
    ResultsBoth,
    Some,
    all_ok_fail_fast,
    bind_option,
    bind_result,
    collect_both,
    filter_err,
    filter_ok,
    fold_results_collect_errs,
    fold_results_collect_errs_capped,
    fold_results_fail_fast,
    fold_until_error_rate,
    is_err,
    is_none,
    is_ok,
    is_some,
    make_errinfo,
    map_err,
    map_option,
    map_result,
    map_result_iter,
    option_from_nullable,
    option_to_nullable,
    par_try_map_iter,
    partition_results,
    recover,
    recover_iter,
    recover_result_iter,
    result_and_then,
    result_map,
    split_results_to_sinks,
    split_results_to_sinks_guarded,
    tap_err,
    tap_ok,
    to_option,
    try_map_iter,
    unwrap_or,
    unwrap_or_else,
)
from .safeguards.breakers import (
    BreakInfo,
    circuit_breaker_count_emit,
    circuit_breaker_count_truncate,
    circuit_breaker_pred_emit,
    circuit_breaker_pred_truncate,
    circuit_breaker_rate_emit,
    circuit_breaker_rate_truncate,
    short_circuit_on_err_emit,
    short_circuit_on_err_truncate,
)
from .safeguards.memo import (
    DiskCache,
    content_hash_key,
    lru_cache_custom,
    memoize_keyed,
)
from .safeguards.reports import (
    ErrGroup,
    ErrReport,
    fold_error_counts,
    fold_error_report,
    report_to_jsonable,
)
from .safeguards.resources import (
    auto_close,
    managed_stream,
    nested_managed,
    with_resource_stream,
)
from .safeguards.retries import (
    RetryCtx,
    RetryDecision,
    exp_policy,
    fixed_policy,
    is_retriable_errinfo,
    restore_input_order,
    retry_map_iter,
)
from .streaming import (
    Source,
    Transform,
    as_source,
    compose2_transforms,
    compose_transforms,
    ensure_contiguous,
    fence_k,
    fork2_lockstep,
    make_call_gate,
    make_chain,
    make_counter,
    make_merge,
    make_peek,
    make_rate_limit,
    make_roundrobin,
    make_sampler_bernoulli,
    make_sampler_periodic,
    make_sampler_stable,
    make_tap,
    make_throttle,
    make_timestamp,
    multicast,
    source_to_transform,
    tap_prefix,
    throttle,
    trace_iter,
)
from .streaming import trace_iter as _trace_iter
from .tree import (
    assert_acyclic,
    flatten,
    flatten_via_fold,
    fold_count_length_maxdepth,
    fold_tree,
    fold_tree_buffered,
    fold_tree_no_path,
    iter_flatten,
    iter_flatten_buffered,
    linear_accumulate,
    linear_reduce,
    max_depth,
    recursive_flatten,
    scan_count_length_maxdepth,
    scan_tree,
)

__all__ = list(PUBLIC_API)


def __getattr__(name: str) -> Any:
    value = resolve_lazy_export(
        module_name=__name__,
        name=name,
        exports=LAZY_EXPORTS,
    )
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__) | set(LAZY_EXPORTS))
