"""MCP server exposing Pyright language server functionality."""

import json
import subprocess
import tempfile
from pathlib import Path
from subprocess import CompletedProcess
from typing import Any, TypeVar

import fastmcp

mcp = fastmcp.FastMCP("mcp-pyright")

T = TypeVar("T")

# Cache for pyright output
_last_diagnostics: dict[str, Any] = {}


def _run_pyright(
    command: str,
    code: str | None = None,
    file_path: str | None = None,
    python_path: str | None = None,
) -> CompletedProcess[str]:
    """Run a pyright command with the given code or file."""
    cmd = ["pyright", command]

    if python_path:
        cmd.extend(["--pythonpath", python_path])

    if file_path:
        cmd.append(file_path)
    elif code:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(code)
            cmd.append(f.name)

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=30,
    )
    return result


def _parse_pyright_output(output: str) -> dict[str, Any]:
    """Parse pyright JSON output."""
    try:
        parsed: dict[str, Any] = json.loads(output)
        return parsed
    except json.JSONDecodeError:
        return {"error": "Failed to parse pyright output", "raw": output}


@mcp.tool()
def check_types(
    code: str | None = None,
    file_path: str | None = None,
    python_path: str | None = None,
    type_checker_mode: str = "basic",
) -> dict[str, Any]:
    """Check types in a Python file or string of code.

    Performs type checking using Pyright and returns diagnostics.

    Args:
        code: Python code as string (mutually exclusive with file_path).
        file_path: Path to Python file (mutually exclusive with code).
        python_path: Optional path to Python interpreter.
        type_checker_mode: Type checking mode - "basic", "strict", or "overload" (default: "basic").

    Returns:
        Dictionary containing diagnostics, file analyzed, and type checking time.

    Raises:
        ValueError: If neither code nor file_path is provided.
        FileNotFoundError: If file_path doesn't exist.
        RuntimeError: If pyright is not installed.

    Example:
        >>> check_types(code="x: int = 'hello'")
        {'file': '/tmp/...', 'diagnostics': [{'severity': 'error', 'message': '...'}], 'typeCheckingTime': 0.1}
    """
    if not code and not file_path:
        raise ValueError("Either code or file_path must be provided")

    if file_path and not Path(file_path).exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    cmd = ["--outputjson"]

    if python_path:
        cmd.extend(["--pythonpath", python_path])

    if type_checker_mode == "strict":
        cmd.append("--strict")
    elif type_checker_mode == "overload":
        cmd.append("--enableexperimental-features")

    if file_path:
        cmd.append(file_path)
    else:
        if code is None:
            code = ""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(code)
            cmd.append(f.name)

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=30,
    )

    if result.returncode not in (0, 1):
        if "pyright" in result.stderr.lower():
            raise RuntimeError("Pyright not found. Install with: pip install pyright")
        return {"error": result.stderr, "diagnostics": []}

    try:
        output = json.loads(result.stdout)
    except json.JSONDecodeError:
        return {"error": "Failed to parse pyright output", "diagnostics": []}

    diagnostics = output.get("generalDiagnostics", [])

    parsed_diagnostics = []
    for diag in diagnostics:
        parsed_diagnostics.append(
            {
                "range": diag.get("range", {}),
                "severity": _get_severity_name(diag.get("severity", 0)),
                "code": diag.get("code", ""),
                "message": diag.get("message", ""),
            }
        )

    global _last_diagnostics
    _last_diagnostics = {
        "diagnostics": parsed_diagnostics,
        "file": file_path or "stdin",
    }

    return {
        "diagnostics": parsed_diagnostics,
        "file": file_path or "stdin",
        "typeCheckingTime": output.get("summary", {}).get("typeCheckingTime", 0),
    }


def _get_severity_name(severity: int) -> str:
    """Convert pyright severity number to string name."""
    severity_map = {
        0: "error",
        1: "error",
        2: "warning",
        3: "information",
        4: "hint",
    }
    return severity_map.get(severity, "error")


@mcp.tool()
def get_hover(
    code: str,
    position: int,
    python_path: str | None = None,
) -> dict[str, Any]:
    """Get hover information at a specific position.

    Returns type information and documentation for the symbol at the given position.

    Args:
        code: Python code as string.
        position: Character position (0-indexed) in the code.
        python_path: Optional path to Python interpreter.

    Returns:
        Dictionary with contents (markdown), range, and kind.

    Example:
        >>> get_hover("x: int = 1", 0)
        {'contents': '```python\\nint\\n```', 'range': {...}, 'kind': 'python'}
    """
    lines = code.split("\n")
    line = 0
    char = position
    for i, line_text in enumerate(lines):
        if char <= len(line_text):
            line = i
            break
        char -= len(line_text) + 1
    else:
        line = len(lines) - 1
        char = len(lines[-1]) if lines else 0

    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        temp_path = f.name

    cmd = [
        "pyright",
        "--hover",
        f"--position={line}:{char}",
        temp_path,
    ]

    if python_path:
        cmd.extend(["--pythonpath", python_path])

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=30,
    )

    try:
        output: dict[str, Any] = json.loads(result.stdout)
        if output.get("hover"):
            item: dict[str, Any] = output["hover"][0]
            return item
        return {"contents": "", "range": {}, "kind": "python"}
    except (json.JSONDecodeError, KeyError):
        return {"contents": "", "range": {}, "kind": "python"}


@mcp.tool()
def get_completions(
    code: str,
    position: int,
    python_path: str | None = None,
) -> dict[str, Any]:
    """Get code completions at a specific position.

    Returns available completions at the given cursor position.

    Args:
        code: Python code as string.
        position: Character position (0-indexed) in the code.
        python_path: Optional path to Python interpreter.

    Returns:
        Dictionary with completion items (label, detail, documentation, insertText).

    Example:
        >>> get_completions("prin", 4)
        {'items': [{'label': 'print', 'detail': 'def print(...)', ...}]}
    """
    lines = code.split("\n")
    line = 0
    char = position
    for i, line_text in enumerate(lines):
        if char <= len(line_text):
            line = i
            break
        char -= len(line_text) + 1
    else:
        line = len(lines) - 1
        char = len(lines[-1]) if lines else 0

    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        temp_path = f.name

    cmd = [
        "pyright",
        "--completion",
        f"--position={line}:{char}",
        temp_path,
    ]

    if python_path:
        cmd.extend(["--pythonpath", python_path])

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=30,
    )

    try:
        output = json.loads(result.stdout)
        items = output.get("completionItems", [])
        return {
            "items": [
                {
                    "label": item.get("label", ""),
                    "detail": item.get("detail", ""),
                    "documentation": item.get("documentation", {}).get("value", ""),
                    "insertText": item.get("insertText", ""),
                }
                for item in items[:50]
            ]
        }
    except (json.JSONDecodeError, KeyError):
        return {"items": []}


@mcp.tool()
def get_definition(
    code: str,
    position: int,
    python_path: str | None = None,
) -> dict[str, Any]:
    """Get definition location at a specific position.

    Returns the location of the definition for the symbol at the given position.

    Args:
        code: Python code as string.
        position: Character position (0-indexed) in the code.
        python_path: Optional path to Python interpreter.

    Returns:
        Dictionary with definition location (file path, range).

    Example:
        >>> get_definition("def foo(): pass\\nfoo()", 15)
        {'file': '/tmp/...', 'range': {'start': {'line': 0, 'character': 0}, ...}}
    """
    lines = code.split("\n")
    line = 0
    char = position
    for i, line_text in enumerate(lines):
        if char <= len(line_text):
            line = i
            break
        char -= len(line_text) + 1
    else:
        line = len(lines) - 1
        char = len(lines[-1]) if lines else 0

    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        temp_path = f.name

    cmd = [
        "pyright",
        "--definition",
        f"--position={line}:{char}",
        temp_path,
    ]

    if python_path:
        cmd.extend(["--pythonpath", python_path])

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=30,
    )

    try:
        output: dict[str, Any] = json.loads(result.stdout)
        if output.get("definition"):
            defn: dict[str, Any] = output["definition"]
            return defn
        return {"file": "", "range": {}}
    except (json.JSONDecodeError, KeyError):
        return {"file": "", "range": {}}


@mcp.tool()
def find_references(
    code: str,
    position: int,
    python_path: str | None = None,
) -> dict[str, Any]:
    """Find all references to a symbol at a specific position.

    Returns all reference locations for the symbol at the given position.

    Args:
        code: Python code as string.
        position: Character position (0-indexed) in the code.
        python_path: Optional path to Python interpreter.

    Returns:
        Dictionary with reference locations.

    Example:
        >>> find_references("x = 1\\nx", 5)
        {'references': [{'file': '/tmp/...', 'range': {...}}, ...]}
    """
    lines = code.split("\n")
    line = 0
    char = position
    for i, line_text in enumerate(lines):
        if char <= len(line_text):
            line = i
            break
        char -= len(line_text) + 1
    else:
        line = len(lines) - 1
        char = len(lines[-1]) if lines else 0

    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        temp_path = f.name

    cmd = [
        "pyright",
        "--references",
        f"--position={line}:{char}",
        temp_path,
    ]

    if python_path:
        cmd.extend(["--pythonpath", python_path])

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=30,
    )

    try:
        output = json.loads(result.stdout)
        refs = output.get("references", [])
        return {
            "references": [
                {
                    "file": ref.get("filePath", ""),
                    "range": ref.get("range", {}),
                }
                for ref in refs
            ]
        }
    except (json.JSONDecodeError, KeyError):
        return {"references": []}


@mcp.tool()
def get_document_symbols(
    code: str,
    python_path: str | None = None,
) -> dict[str, Any]:
    """Get all symbols in a Python document.

    Returns document symbols including functions, classes, variables, etc.

    Args:
        code: Python code as string.
        python_path: Optional path to Python interpreter.

    Returns:
        Dictionary with symbol information (name, kind, range, containerName).

    Example:
        >>> get_document_symbols("class Foo: pass\\ndef bar(): pass")
        {'symbols': [{'name': 'Foo', 'kind': 'class', ...}, {'name': 'bar', 'kind': 'function', ...}]}
    """
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        temp_path = f.name

    cmd = ["pyright", "--documentsymbols", temp_path]

    if python_path:
        cmd.extend(["--pythonpath", python_path])

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=30,
    )

    try:
        output = json.loads(result.stdout)
        symbols = output.get("item", {}).get("children", [])
        return {
            "symbols": [
                {
                    "name": sym.get("name", ""),
                    "kind": _get_symbol_kind(sym.get("kind", 0)),
                    "range": sym.get("range", {}),
                    "containerName": sym.get("containerName", ""),
                }
                for sym in symbols
            ]
        }
    except (json.JSONDecodeError, KeyError):
        return {"symbols": []}


def _get_symbol_kind(kind: int) -> str:
    """Convert pyright symbol kind number to string name."""
    kind_map = {
        1: "file",
        2: "module",
        3: "namespace",
        4: "package",
        5: "class",
        6: "interface",
        7: "enum",
        8: "enumMember",
        9: "function",
        10: "method",
        11: "property",
        12: "field",
        13: "variable",
        14: "parameter",
        15: "typeParameter",
        16: "constant",
    }
    return kind_map.get(kind, "variable")


@mcp.tool()
def format_code(
    code: str,
    python_path: str | None = None,
) -> dict[str, Any]:
    """Format Python code.

    Formats the given Python code using pyright's formatter.

    Args:
        code: Python code as string.
        python_path: Optional path to Python interpreter.

    Returns:
        Dictionary with formatted code.

    Example:
        >>> format_code("x=1\\ny=2")
        {'formattedCode': 'x = 1\\ny = 2\\n'}
    """
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        temp_path = f.name

    cmd = ["pyright", "--format", temp_path]

    if python_path:
        cmd.extend(["--pythonpath", python_path])

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=30,
    )

    if result.stdout:
        try:
            output = json.loads(result.stdout)
            return {"formattedCode": output.get("fileContents", code)}
        except json.JSONDecodeError:
            pass

    return {"formattedCode": code}


@mcp.resource("diagnostics://latest")
def latest_diagnostics() -> dict[str, Any]:
    """Get the latest type checking diagnostics.

    Returns the most recent diagnostics from a type checking run.

    Returns:
        Dictionary with diagnostics and file information.

    Example:
        >>> latest_diagnostics()
        {'diagnostics': [], 'file': 'stdin'}
    """
    global _last_diagnostics
    return _last_diagnostics
