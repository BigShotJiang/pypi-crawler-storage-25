__version__ = "0.1.0"
__all__ = ["mcp", "__version__"]

from typing import TYPE_CHECKING

from mcp_pyright.mcp import mcp  # noqa: TC004

if TYPE_CHECKING:
    from .mcp import mcp
