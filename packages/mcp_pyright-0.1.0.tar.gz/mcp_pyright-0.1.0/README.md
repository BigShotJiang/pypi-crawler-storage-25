# mcp-pyright

> MCP server that exposes Pyright language server functionality

[![PyPI](https://img.shields.io/pypi/v/mcp-pyright.svg)](https://pypi.org/project/mcp-pyright/)
[![Python](https://img.shields.io/pypi/pyversions/mcp-pyright.svg)](https://pypi.org/project/mcp-pyright/)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

mcp-name: io.github.daedalus/mcp-pyright

## Install

```bash
pip install mcp-pyright
```

## Usage

The MCP server can be used with any MCP-compatible client. It exposes the following tools:

### Type Checking

```python
from mcp_pyright import mcp

# Run type checking
result = check_types(code="x: int = 'hello'")
```

### Get Hover Information

```python
# Get type information at position
result = get_hover(code="x: int = 1", position=0)
```

### Get Completions

```python
# Get code completions
result = get_completions(code="prin", position=4)
```

### Get Definition

```python
# Find definition location
result = get_definition(code="def foo(): pass\nfoo()", position=15)
```

### Find References

```python
# Find all references
result = find_references(code="x = 1\nx", position=5)
```

### Get Document Symbols

```python
# Get all symbols in document
result = get_document_symbols(code="class Foo: pass\ndef bar(): pass")
```

### Format Code

```python
# Format Python code
result = format_code(code="x=1\ny=2")
```

## Development

```bash
git clone https://github.com/daedalus/mcp-pyright.git
cd mcp-pyright
pip install -e ".[test]"

# run tests
pytest

# format
ruff format src/ tests/

# lint
ruff check src/ tests/

# type check
mypy src/
```

## License

MIT
