# neverinstallme

Minimal Python package boilerplate.

```bash
PYTHONPATH=src python3 -m neverinstallme
```
