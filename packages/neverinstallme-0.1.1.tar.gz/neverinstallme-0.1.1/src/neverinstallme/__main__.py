def main() -> None:
    print("hello world2")


if __name__ == "__main__":
    main()
