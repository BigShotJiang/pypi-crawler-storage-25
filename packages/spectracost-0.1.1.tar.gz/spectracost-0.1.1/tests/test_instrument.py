"""Tests for the core instrument() function."""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock

from spectracost import instrument


def test_instrument_openai_client(telemetry_url: str) -> None:
    """instrument() wraps an OpenAI-like client successfully."""
    mock_client = MagicMock()
    mock_client.__class__.__module__ = "openai._client"

    wrapped = instrument(mock_client, api_key="afops_test", endpoint=telemetry_url)

    assert hasattr(wrapped, "chat")
    assert hasattr(wrapped, "embeddings")


def test_instrument_anthropic_client(telemetry_url: str) -> None:
    """instrument() wraps an Anthropic-like client successfully."""
    mock_client = MagicMock()
    mock_client.__class__.__module__ = "anthropic._client"

    wrapped = instrument(mock_client, api_key="afops_test", endpoint=telemetry_url)

    assert hasattr(wrapped, "messages")


def test_instrument_unsupported_client(telemetry_url: str) -> None:
    """instrument() raises ValueError for unsupported client types."""
    # Use a real object (not MagicMock, which auto-creates any attribute via __getattr__)
    mock_client = type("SomeClient", (), {"__module__": "some_other_library"})()

    with pytest.raises(ValueError, match="Unsupported client type"):
        instrument(mock_client, api_key="afops_test", endpoint=telemetry_url)


def test_wrapped_client_proxies_unknown_attributes(telemetry_url: str) -> None:
    """Attributes not intercepted by the wrapper are proxied to the underlying client."""
    mock_client = MagicMock()
    mock_client.__class__.__module__ = "openai._client"
    mock_client.some_custom_property = "hello"

    wrapped = instrument(mock_client, api_key="afops_test", endpoint=telemetry_url)

    assert wrapped.some_custom_property == "hello"
