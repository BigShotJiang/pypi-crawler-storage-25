"""Core instrumentation function."""

from __future__ import annotations

from typing import Optional, TypeVar

from .transport import Transport

T = TypeVar("T")

# Default endpoint for the hosted platform
_DEFAULT_ENDPOINT = "https://spectracost.com/ingest"


def instrument(
    client: T,
    *,
    api_key: str,
    endpoint: str = _DEFAULT_ENDPOINT,
    team: str = "",
    service: str = "",
    feature: str = "",
    environment: str = "production",
    customer_id: str = "",
    tags: Optional[dict[str, str]] = None,
) -> T:
    """Wrap an AI provider client with Spectracost instrumentation.

    Returns a wrapped client that behaves identically to the original, but
    captures usage telemetry (model, tokens, latency, attribution tags) and
    sends it to the Spectracost platform asynchronously.

    Args:
        client: An OpenAI or Anthropic client instance.
        api_key: Your Spectracost API key (starts with "afops_").
        endpoint: Spectracost ingestion endpoint. Override for self-hosted or development.
        team: Default team attribution tag.
        service: Default service attribution tag.
        feature: Default feature attribution tag.
        environment: Default environment ("production", "staging", "development", "test").
        customer_id: Default customer ID for unit economics tracking.
        tags: Additional custom tags to include on every event.

    Returns:
        A wrapped client with the same API as the original.

    Example:
        from openai import OpenAI
        from spectracost import instrument

        client = instrument(
            OpenAI(),
            api_key="afops_...",
            team="search",
            service="query-rewriting",
        )

        # Use exactly like a normal OpenAI client
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello!"}],
        )
    """
    transport = Transport(endpoint=endpoint, api_key=api_key)

    wrapper_kwargs = dict(
        transport=transport,
        team=team,
        service=service,
        feature=feature,
        environment=environment,
        customer_id=customer_id,
        tags=tags,
    )

    # Detect provider by module name, then fall back to duck typing
    client_module = type(client).__module__
    client_name = type(client).__name__.lower()

    if _is_openai(client, client_module, client_name):
        from .providers.openai import OpenAIWrapper
        return OpenAIWrapper(client, **wrapper_kwargs)  # type: ignore[return-value]

    if _is_anthropic(client, client_module, client_name):
        from .providers.anthropic import AnthropicWrapper
        return AnthropicWrapper(client, **wrapper_kwargs)  # type: ignore[return-value]

    raise ValueError(
        f"Unsupported client type: {type(client).__name__} (module: {client_module}). "
        f"Spectracost supports OpenAI and Anthropic clients."
    )


def _is_openai(client: object, module: str, name: str) -> bool:
    """Detect OpenAI client by module, name, or duck typing."""
    if "openai" in module or "openai" in name:
        return True
    # Duck typing: OpenAI clients have client.chat.completions
    chat = getattr(client, "chat", None)
    return chat is not None and hasattr(chat, "completions")


def _is_anthropic(client: object, module: str, name: str) -> bool:
    """Detect Anthropic client by module, name, or duck typing."""
    if "anthropic" in module or "anthropic" in name:
        return True
    # Duck typing: Anthropic clients have client.messages but not client.chat
    return hasattr(client, "messages") and not hasattr(client, "chat")
