"""Convert LaTeX inline equations to Unicode text."""

from __future__ import annotations

import re

# Greek letters
_GREEK = {
    r"\alpha": "α", r"\beta": "β", r"\gamma": "γ", r"\delta": "δ",
    r"\epsilon": "ε", r"\varepsilon": "ε", r"\zeta": "ζ", r"\eta": "η",
    r"\theta": "θ", r"\vartheta": "ϑ",
    r"\iota": "ι", r"\kappa": "κ", r"\lambda": "λ", r"\mu": "μ",
    r"\nu": "ν", r"\xi": "ξ", r"\pi": "π", r"\varpi": "ϖ",
    r"\rho": "ρ", r"\varrho": "ϱ",
    r"\sigma": "σ", r"\varsigma": "ς",
    r"\tau": "τ", r"\upsilon": "υ", r"\phi": "φ", r"\varphi": "φ",
    r"\chi": "χ", r"\psi": "ψ", r"\omega": "ω",
    r"\Gamma": "Γ", r"\Delta": "Δ", r"\Theta": "Θ", r"\Lambda": "Λ",
    r"\Xi": "Ξ", r"\Pi": "Π", r"\Sigma": "Σ", r"\Phi": "Φ",
    r"\Psi": "Ψ", r"\Omega": "Ω",
    r"\infty": "∞",
}

# Operators and symbols
# NOTE: longer keys must appear before shorter prefixes (e.g. \cdots before \cdot,
# \notin before \in, \leq/\geq before \le/\ge, \leftarrow before \left).
# The dict is sorted by key length (longest first) before substitution.
_SYMBOLS = {
    # Ellipsis / dots (must precede \cdot)
    r"\cdots": "···", r"\ldots": "…", r"\vdots": "⋮", r"\ddots": "⋱",
    # Arrows
    r"\leftarrow": "←", r"\rightarrow": "→", r"\Leftarrow": "⇐", r"\Rightarrow": "⇒",
    r"\leftrightarrow": "↔", r"\Leftrightarrow": "⇔",
    r"\uparrow": "↑", r"\downarrow": "↓", r"\updownarrow": "↕",
    r"\Uparrow": "⇑", r"\Downarrow": "⇓", r"\Updownarrow": "⇕",
    r"\to": "→", r"\gets": "←",
    # Relations (longer names first)
    r"\leq": "≤", r"\geq": "≥", r"\neq": "≠",
    r"\le": "≤", r"\ge": "≥", r"\ne": "≠",
    r"\approx": "≈", r"\sim": "∼", r"\equiv": "≡", r"\propto": "∝",
    r"\ll": "≪", r"\gg": "≫",
    # Set / logic
    r"\notin": "∉", r"\in": "∈",
    r"\subset": "⊂", r"\subseteq": "⊆", r"\supset": "⊃", r"\supseteq": "⊇",
    r"\cup": "∪", r"\cap": "∩", r"\setminus": "∖", r"\emptyset": "∅",
    r"\forall": "∀", r"\exists": "∃", r"\nexists": "∄",
    r"\land": "∧", r"\lor": "∨", r"\lnot": "¬", r"\neg": "¬",
    # Brackets
    r"\langle": "⟨", r"\rangle": "⟩",   # U+27E8/27E9 — math angle brackets, in SegoeUISymbol
    r"\lfloor": "⌊", r"\rfloor": "⌋",
    r"\lceil": "⌈", r"\rceil": "⌉",
    # Arithmetic / calculus
    r"\cdot": "·", r"\times": "×", r"\div": "÷",
    r"\pm": "±", r"\mp": "∓",
    r"\partial": "∂", r"\nabla": "∇",
    r"\sum": "Σ", r"\prod": "∏", r"\int": "∫",
    r"\oint": "∮", r"\iint": "∬", r"\iiint": "∭",
    # Misc symbols
    r"\sqrt": "√",   # bare \sqrt (without braces) — see also _handle_sqrt below
    r"\perp": "⊥", r"\parallel": "∥",
    r"\angle": "∠", r"\triangle": "△",
    r"\circ": "∘", r"\bullet": "•", r"\star": "★",
    r"\dagger": "†", r"\ddagger": "‡",
    r"\hbar": "ℏ",
    r"\otimes": "⊗", r"\oplus": "⊕", r"\ominus": "⊖", r"\odot": "⊙",
    r"\%": "%", r"\#": "#", r"\&": "&",
    r"\S": "§", r"\P": "¶", r"\dag": "†", r"\ddag": "‡",
    r"\ast": "*", r"\|": "‖",
    r"\,": " ", r"\;": " ", r"\!": "", r"\quad": "  ", r"\qquad": "    ",
    "~": " ", r"\~": " ",
    # Math function names (no-arg commands)
    r"\exp": "exp", r"\log": "log", r"\ln": "ln",
    r"\sin": "sin", r"\cos": "cos", r"\tan": "tan",
    r"\sinh": "sinh", r"\cosh": "cosh", r"\tanh": "tanh",
    r"\arcsin": "arcsin", r"\arccos": "arccos", r"\arctan": "arctan",
    r"\lim": "lim", r"\max": "max", r"\min": "min",
    r"\sup": "sup", r"\inf": "inf",
    r"\det": "det", r"\dim": "dim", r"\ker": "ker",
    r"\deg": "deg", r"\gcd": "gcd", r"\mod": "mod",
    r"\Re": "Re", r"\Im": "Im",
}


# Superscript digits and letters
_SUPERSCRIPT = {
    "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴",
    "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹",
    "+": "⁺", "-": "⁻", "=": "⁼", "(": "⁽", ")": "⁾",
    "n": "ⁿ", "i": "ⁱ",
    # "." intentionally omitted: Unicode has no superscript period, so
    # expressions like "0.5" fall back to the ^content text notation.
}

# Subscript digits and letters
_SUBSCRIPT = {
    "0": "₀", "1": "₁", "2": "₂", "3": "₃", "4": "₄",
    "5": "₅", "6": "₆", "7": "₇", "8": "₈", "9": "₉",
    "+": "₊", "-": "₋", "=": "₌", "(": "₍", ")": "₎",
    "a": "ₐ", "e": "ₑ", "o": "ₒ", "x": "ₓ",
    "h": "ₕ", "k": "ₖ", "l": "ₗ", "m": "ₘ",
    "n": "ₙ", "p": "ₚ", "s": "ₛ", "t": "ₜ",
}


def _can_fully_superscript(text: str) -> bool:
    """Check if all characters can be converted to Unicode superscript."""
    return all(c in _SUPERSCRIPT or c == " " for c in text)


def _can_fully_subscript(text: str) -> bool:
    """Check if all characters can be converted to Unicode subscript."""
    return all(c in _SUBSCRIPT or c == " " for c in text)


def _to_superscript(text: str) -> str:
    """Convert text to Unicode superscript, best-effort character by character.

    Characters in _SUPERSCRIPT are converted; all others are kept as-is.
    This avoids the all-or-nothing fallback that would leave a bare '^' prefix.
    Example: '1,2, †' → '¹,², †'
    """
    if not text:
        return text
    return "".join(_SUPERSCRIPT.get(c, c) for c in text)


def _to_subscript(text: str) -> str:
    """Convert text to Unicode subscript if fully mappable, else use _ notation."""
    if _can_fully_subscript(text):
        return "".join(_SUBSCRIPT.get(c, c) for c in text if c != " ")
    return "_" + text


def _extract_brace_content(s: str, start: int) -> tuple[str, int]:
    """Extract content within {...} starting at position start.
    Returns (content, end_position)."""
    if start >= len(s) or s[start] != "{":
        # No brace, take single character
        if start < len(s):
            return s[start], start + 1
        return "", start

    depth = 0
    end = start
    for i in range(start, len(s)):
        if s[i] == "{":
            depth += 1
        elif s[i] == "}":
            depth -= 1
            if depth == 0:
                return s[start + 1:i], i + 1
    # Unmatched brace
    return s[start + 1:], len(s)


def latex_to_unicode(latex: str) -> str:
    """Convert a LaTeX inline equation to Unicode text.

    Handles: Greek letters, sub/superscripts, common operators,
    font commands (\\mathbf, \\boldsymbol, etc.), \\frac, \\sqrt,
    \\left/\\right, and many common symbols.

    Args:
        latex: LaTeX string (may include surrounding delimiters).

    Returns:
        Unicode text representation.
    """
    s = latex.strip()

    # Unescape XML entities from DeepL transport
    s = s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")

    # Remove surrounding delimiters
    for start, end in [("$$", "$$"), ("$", "$"), ("\\(", "\\)"), ("\\[", "\\]")]:
        if len(s) > len(start) + len(end) and s.startswith(start) and s.endswith(end):
            s = s[len(start):-len(end)].strip()
            break
    # Remove surrounding ( )
    if s.startswith("(") and s.endswith(")"):
        inner = s[1:-1].strip()
        if inner:
            s = inner

    # --- Pre-processing passes (regex-based, before char loop) ---

    # 1. \frac{a}{b}  →  a/b
    def _replace_frac(m: re.Match) -> str:
        num = m.group(1)
        den = m.group(2)
        return f"{latex_to_unicode(num)}/{latex_to_unicode(den)}"
    s = re.sub(r"\\frac\s*\{([^}]*)\}\s*\{([^}]*)\}", _replace_frac, s)
    # \frac without braces: \frac a b  (rare, just strip command)
    s = re.sub(r"\\frac\b", "", s)

    # 2. \sqrt[n]{x}  →  ⁿ√x  or  \sqrt{x}  →  √x
    def _replace_sqrt(m: re.Match) -> str:
        idx = m.group(1)   # optional [n]
        arg = m.group(2)   # mandatory {x}
        root = latex_to_unicode(arg)
        if idx:
            return _to_superscript(latex_to_unicode(idx)) + "√" + root
        return "√" + root
    s = re.sub(r"\\sqrt\s*(?:\[([^\]]*)\])?\s*\{([^}]*)\}", _replace_sqrt, s)

    # 3. Strip \left and \right size hints (keep the bracket char that follows)
    s = re.sub(r"\\(?:left|right)\s*(?:\\[|])?", "", s)
    # Handle \left\{ \right\} — the backslash before brace is literal in LaTeX
    s = re.sub(r"\\(?:left|right)\s*\\([{}|.])", r"\1", s)

    # 4. Font/style commands: strip command, keep content
    #    Also fix MinerU OCR spacing ("z e r o" → "zero") inside these
    def _strip_font_cmd(m: re.Match) -> str:
        content = m.group(1)
        # collapse OCR-spaced words
        return re.sub(r"(?<=\w) (?=\w(?:\s|$|\}))", "", content)
    s = re.sub(
        r"\\(?:mathrm|mathbf|mathbb|mathcal|mathsf|mathtt|mathfrak"
        r"|boldsymbol|bm|text|textrm|textbf|textit|mathit|textit)\s*\{([^}]*)\}",
        _strip_font_cmd, s,
    )

    # 5. Fix general OCR spacing: "5 0" → "50", "0 . 5" → "0.5"
    s = re.sub(r"(\d) (\d)", r"\1\2", s)
    s = re.sub(r"(\d) (\d)", r"\1\2", s)   # twice for "1 0 0"
    s = re.sub(r"(\d) \. (\d)", r"\1.\2", s)

    # 6. Normalize spaces around ^ and _
    s = re.sub(r"\s*\^\s*", "^", s)
    s = re.sub(r"\s*_\s*", "_", s)
    s = re.sub(r"\{\s+", "{", s)
    s = re.sub(r"\s+\}", "}", s)

    # 7. \bar{X} → X̄,  \hat{X} → Xˆ
    # Use spacing modifier letters (U+00AF macron, U+02C6 circumflex) rather than
    # combining diacritics (U+0304, U+0302) because ReportLab's Paragraph renderer
    # does not attach combining characters to their base glyphs in PDF output.
    # U+02C6 is present in SegoeUISymbol (the eq-font) but absent from NotoSansSC.
    s = re.sub(r"\\bar\s*\{([^}]*)\}", lambda m: m.group(1) + "\u00af", s)
    s = re.sub(r"\\hat\s*\{([^}]*)\}", lambda m: m.group(1) + "\u02c6", s)

    # 8. Replace Greek letters and symbols (longest key first to avoid prefix clashes)
    for cmd in sorted(_GREEK.keys(), key=len, reverse=True):
        s = s.replace(cmd, _GREEK[cmd])
    for cmd in sorted(_SYMBOLS.keys(), key=len, reverse=True):
        s = s.replace(cmd, _SYMBOLS[cmd])

    # 9. Strip remaining decorator commands that just wrap a {} arg
    #    (overrightarrow, vec, tilde, dot, ddot, etc.) — keep the content
    s = re.sub(
        r"\\(?:overrightarrow|overleftarrow|overleftrightarrow"
        r"|vec|tilde|widetilde|widehat|underline|overline"
        r"|dot|ddot|acute|grave|breve|check|mathring"
        r"|emph|operatorname)\s*",
        "", s,
    )

    # 10. Strip bare \left / \right that slipped through (e.g. before non-brace)
    s = re.sub(r"\\(?:left|right)\b\s*", "", s)

    # --- Character-by-character pass for sub/superscripts and braces ---
    result = []
    i = 0
    while i < len(s):
        if s[i] == "^" and i + 1 < len(s):
            content, new_i = _extract_brace_content(s, i + 1)
            content = latex_to_unicode(content)
            result.append(_to_superscript(content))
            i = new_i
        elif s[i] == "_" and i + 1 < len(s):
            content, new_i = _extract_brace_content(s, i + 1)
            content = latex_to_unicode(content)
            result.append(_to_subscript(content))
            i = new_i
        elif s[i] == "{":
            content, new_i = _extract_brace_content(s, i)
            result.append(content)
            i = new_i
        elif s[i] == "}":
            i += 1  # skip stray closing braces
        else:
            result.append(s[i])
            i += 1

    out = "".join(result)

    # Clean up extra spaces
    out = re.sub(r"\s+", " ", out).strip()

    return out
