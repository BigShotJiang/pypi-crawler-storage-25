"""Image loader: handles both CDN URLs and local relative paths with caching."""

from __future__ import annotations

import hashlib
import logging
from pathlib import Path

import requests

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT = 30


class ImageLoader:
    """Download and cache images from URLs, or resolve local paths."""

    def __init__(self, base_dir: Path, cache_dir: Path | None = None) -> None:
        """
        Args:
            base_dir: Base directory for resolving relative paths
                      (typically the layout.json parent directory).
            cache_dir: Directory for caching downloaded images.
                       Defaults to {base_dir}/.mineru_trans_cache/
        """
        self.base_dir = Path(base_dir)
        self.cache_dir = Path(cache_dir) if cache_dir else self.base_dir / ".mineru_trans_cache"
        self._ensure_cache_dir()

    def _ensure_cache_dir(self) -> None:
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def load(self, url_or_path: str) -> Path | None:
        """Load an image from URL or local path.

        Args:
            url_or_path: Either an HTTP(S) URL or a relative file path.

        Returns:
            Local file path to the image, or None if loading failed.
        """
        if not url_or_path:
            return None

        if url_or_path.startswith(("http://", "https://")):
            return self._download(url_or_path)
        else:
            return self._resolve_local(url_or_path)

    def _download(self, url: str) -> Path | None:
        """Download a URL to cache, return cached path."""
        # Use MD5 of URL as cache key, preserve extension
        url_hash = hashlib.md5(url.encode()).hexdigest()
        ext = self._guess_extension(url)
        cached = self.cache_dir / f"{url_hash}{ext}"

        if cached.exists():
            return cached

        try:
            response = requests.get(url, timeout=_DEFAULT_TIMEOUT)
            response.raise_for_status()
            cached.write_bytes(response.content)
            logger.debug("Downloaded image: %s -> %s", url[:80], cached)
            return cached
        except Exception:
            logger.warning("Failed to download image: %s", url[:120])
            return None

    def _resolve_local(self, rel_path: str) -> Path | None:
        """Resolve a relative path against base_dir.

        MinerU layout.json may store image paths as bare filenames while the
        actual files live inside an ``images/`` subdirectory.  We check both
        locations before giving up.
        """
        full_path = self.base_dir / rel_path
        if full_path.exists():
            return full_path
        # Fallback: try images/ subdirectory (MinerU default layout)
        images_path = self.base_dir / "images" / rel_path
        if images_path.exists():
            return images_path
        logger.warning("Local image not found: %s (also tried images/)", full_path)
        return None

    @staticmethod
    def _guess_extension(url: str) -> str:
        """Guess file extension from URL."""
        # Strip query params
        clean = url.split("?")[0]
        for ext in (".jpg", ".jpeg", ".png", ".svg", ".gif", ".webp", ".bmp"):
            if clean.lower().endswith(ext):
                return ext
        return ".png"  # default
