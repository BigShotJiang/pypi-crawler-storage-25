"""Markdown export for translated documents."""

from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..models import Block, LayoutDocument, TranslatedBlock, TranslateDecision


# Block types that map to markdown headings
_HEADING_TYPES = {"title"}

# Translated text block types to include
_TRANSLATE_TEXT_TYPES = {
    "text", "title", "index",
    "header", "footer", "page_footnote", "page_number",
    "table_caption", "image_caption", "table_footnote", "image_footnote",
}


def _strip_eq_placeholders(text: str) -> str:
    """Remove <eq id="N">...</eq> placeholders, leaving a space."""
    text = re.sub(r'<eq id="\d+">.*?</eq>', " ", text)
    text = re.sub(r"\{\{EQ:\d+\}\}", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _get_equation_latex(block: "Block") -> str | None:
    """Extract LaTeX source from an interline_equation block."""
    if not block.lines:
        return None
    parts = []
    for line in block.lines:
        for span in line.spans:
            if span.type == "interline_equation" and span.content:
                parts.append(span.content.strip())
    return " ".join(parts).strip() or None


def _get_image_path(block: "Block") -> str | None:
    """Return the image path for an image_body block."""
    if block.image_path:
        return block.image_path
    if block.lines:
        for line in block.lines:
            for span in line.spans:
                if span.image_path:
                    return span.image_path
    return None


def _resolve_image_link(img_path: str, base_dir: Path, md_dir: Path) -> str:
    """Convert a raw image path to a link relative to the markdown file.

    CDN URLs (http/https) are returned unchanged.
    Local paths are resolved from base_dir and made relative to md_dir.
    """
    if img_path.startswith("http://") or img_path.startswith("https://"):
        return img_path
    abs_path = (base_dir / img_path).resolve()
    try:
        rel = abs_path.relative_to(md_dir.resolve())
        return rel.as_posix()
    except ValueError:
        # Different drive or outside md_dir — use os.path.relpath
        import os
        return Path(os.path.relpath(abs_path, md_dir.resolve())).as_posix()


def export_markdown(
    doc: "LayoutDocument",
    translated_blocks: dict[tuple, "TranslatedBlock"],
    output_path: Path,
    mode: str = "translated",
    base_dir: Path | None = None,
) -> None:
    """Export translated content as a markdown file.

    Args:
        doc: Parsed layout document.
        translated_blocks: Mapping from (page_idx, *block_path) to TranslatedBlock.
        output_path: Destination .md file path.
        mode: "translated" or "bilingual".
        base_dir: Directory where layout.json (and images) live.  Used to
                  compute correct relative image links when the markdown is
                  written to a different location.  Defaults to output_path's
                  parent (assumes images are co-located with the markdown).
    """
    md_dir = output_path.parent
    if base_dir is None:
        base_dir = md_dir
    from ..models import TranslateDecision

    output_path = Path(output_path)

    # Group blocks by page, preserving iteration order
    pages: dict[int, list[tuple[tuple, "TranslatedBlock"]]] = {}
    for key, tb in translated_blocks.items():
        page_idx = key[0]
        pages.setdefault(page_idx, []).append((key, tb))

    lines: list[str] = []

    for page_idx in sorted(pages.keys()):
        page_entries = pages[page_idx]
        # Sort by block_path so blocks appear in document order
        page_entries.sort(key=lambda x: x[0])

        for key, tb in page_entries:
            if tb.decision == TranslateDecision.SKIP:
                continue

            block_type = tb.original.type

            # ── PRESERVE blocks ──────────────────────────────────────────────
            if tb.decision == TranslateDecision.PRESERVE:
                if block_type == "image_body":
                    img_path = _get_image_path(tb.original)
                    if img_path:
                        link = _resolve_image_link(img_path, base_dir, md_dir)
                        lines.append(f"![]({link})")
                        lines.append("")

                elif block_type == "interline_equation":
                    latex = _get_equation_latex(tb.original)
                    if latex:
                        lines.append(f"$${latex}$$")
                        lines.append("")

                elif tb.translated_text:
                    # ref_text, code_body, and other preserved text blocks
                    text = tb.translated_text.strip()
                    if text:
                        if block_type == "code_body":
                            lines.append("```")
                            lines.append(text)
                            lines.append("```")
                        else:
                            lines.append(text)
                        lines.append("")

                continue

            # ── TRANSLATE blocks ─────────────────────────────────────────────
            if block_type == "table_body":
                html = tb.translated_html
                if html:
                    lines.append(html)
                    lines.append("")
                continue

            if block_type not in _TRANSLATE_TEXT_TYPES:
                continue
            if not tb.translated_text:
                continue

            translated = _strip_eq_placeholders(tb.translated_text)
            if not translated:
                continue

            is_heading = block_type in _HEADING_TYPES

            if mode == "bilingual":
                original_text = tb.original.get_text_content().strip()
                if original_text:
                    if is_heading:
                        lines.append(f"## {original_text}")
                    else:
                        lines.append(original_text)
                    lines.append("")

                if is_heading:
                    lines.append(f"## {translated}")
                else:
                    lines.append(translated)
                lines.append("")
                lines.append("---")
                lines.append("")
            else:
                if is_heading:
                    lines.append(f"## {translated}")
                else:
                    lines.append(translated)
                lines.append("")

    # Remove trailing blank lines
    while lines and not lines[-1]:
        lines.pop()

    output_path.write_text("\n".join(lines), encoding="utf-8")
