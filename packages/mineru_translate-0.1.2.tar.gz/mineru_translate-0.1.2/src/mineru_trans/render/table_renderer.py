"""HTML table to ReportLab Table renderer with rotation and cell merging support."""

from __future__ import annotations

import logging
from html.parser import HTMLParser

from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, Table, TableStyle

logger = logging.getLogger(__name__)


class _TableHTMLParser(HTMLParser):
    """Simple HTML table parser that extracts rows and cells."""

    def __init__(self):
        super().__init__()
        self.rows: list[list[dict]] = []
        self._current_row: list[dict] | None = None
        self._current_cell: dict | None = None
        self._cell_text_parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attrs_dict = dict(attrs)
        if tag == "tr":
            self._current_row = []
        elif tag in ("td", "th"):
            self._current_cell = {
                "text": "",
                "colspan": int(attrs_dict.get("colspan", "1")),
                "rowspan": int(attrs_dict.get("rowspan", "1")),
                "is_header": tag == "th",
            }
            self._cell_text_parts = []

    def handle_endtag(self, tag: str) -> None:
        if tag in ("td", "th") and self._current_cell is not None:
            self._current_cell["text"] = " ".join(self._cell_text_parts).strip()
            if self._current_row is not None:
                self._current_row.append(self._current_cell)
            self._current_cell = None
        elif tag == "tr" and self._current_row is not None:
            self.rows.append(self._current_row)
            self._current_row = None

    def handle_data(self, data: str) -> None:
        if self._current_cell is not None:
            self._cell_text_parts.append(data.strip())


def parse_html_table(html: str) -> list[list[dict]]:
    """Parse HTML table into rows of cells."""
    parser = _TableHTMLParser()
    parser.feed(html)
    return parser.rows


def _build_grid(
    rows: list[list[dict]],
    max_cols: int,
    num_rows: int,
    cell_style: ParagraphStyle,
    header_style: ParagraphStyle,
) -> tuple[list[list], list[tuple]]:
    """Build a proper 2D grid handling rowspan/colspan.

    Uses an occupancy matrix to correctly place cells when rowspan
    causes later rows to have fewer explicit cells.

    Returns:
        (data_grid, span_commands)
    """
    # Occupancy matrix: True if cell is occupied by a span from above/left
    occupied = [[False] * max_cols for _ in range(num_rows)]
    data: list[list] = [[""] * max_cols for _ in range(num_rows)]
    span_commands: list[tuple] = []

    for row_idx in range(min(num_rows, len(rows))):
        row_cells = rows[row_idx]
        cell_iter = iter(row_cells)

        col_idx = 0
        for cell in row_cells:
            # Find next unoccupied column
            while col_idx < max_cols and occupied[row_idx][col_idx]:
                col_idx += 1
            if col_idx >= max_cols:
                break

            # Place cell content
            is_header = cell.get("is_header", False)
            style = header_style if is_header else cell_style
            safe_text = (
                cell["text"]
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
            )
            data[row_idx][col_idx] = Paragraph(safe_text, style)

            colspan = min(cell.get("colspan", 1), max_cols - col_idx)
            rowspan = min(cell.get("rowspan", 1), num_rows - row_idx)

            # Mark occupied cells and build SPAN command
            for dr in range(rowspan):
                for dc in range(colspan):
                    r, c = row_idx + dr, col_idx + dc
                    if r < num_rows and c < max_cols:
                        occupied[r][c] = True

            if colspan > 1 or rowspan > 1:
                end_col = col_idx + colspan - 1
                end_row = row_idx + rowspan - 1
                span_commands.append(
                    ("SPAN", (col_idx, row_idx), (end_col, end_row))
                )

            col_idx += colspan

    return data, span_commands


def _estimate_col_widths(
    rows: list[list[dict]],
    max_cols: int,
    table_width: float,
    font_name: str,
    font_size: float,
) -> list[float]:
    """Estimate column widths based on cell content length.

    Strategy: count max character length per column across all rows,
    then distribute table_width proportionally.
    """
    from reportlab.pdfbase.pdfmetrics import stringWidth

    col_max_width: list[float] = [0.0] * max_cols

    # Build occupancy to know which column each cell maps to
    num_rows = len(rows)
    occupied = [[False] * max_cols for _ in range(num_rows)]

    for row_idx, row_cells in enumerate(rows):
        col_idx = 0
        for cell in row_cells:
            while col_idx < max_cols and occupied[row_idx][col_idx]:
                col_idx += 1
            if col_idx >= max_cols:
                break

            colspan = min(cell.get("colspan", 1), max_cols - col_idx)
            rowspan = min(cell.get("rowspan", 1), num_rows - row_idx)

            for dr in range(rowspan):
                for dc in range(colspan):
                    r, c = row_idx + dr, col_idx + dc
                    if r < num_rows and c < max_cols:
                        occupied[r][c] = True

            # Only use single-column cells for width estimation
            if colspan == 1:
                text = cell.get("text", "")
                try:
                    w = stringWidth(text, font_name, font_size)
                except (KeyError, ValueError):
                    w = len(text) * font_size * 0.6  # rough estimate
                # Add padding
                w += 8  # left + right padding
                col_max_width[col_idx] = max(col_max_width[col_idx], w)

            col_idx += colspan

    # Ensure minimum width per column
    min_col_width = 20.0
    for i in range(max_cols):
        col_max_width[i] = max(col_max_width[i], min_col_width)

    # Scale to fit table_width
    total = sum(col_max_width)
    if total > 0:
        scale = table_width / total
        return [w * scale for w in col_max_width]
    else:
        return [table_width / max_cols] * max_cols


def _estimate_row_heights(
    data: list[list],
    col_widths: list[float],
    num_rows: int,
    table_height: float,
    font_size: float,
) -> list[float] | None:
    """Estimate row heights to fill table_height.

    Returns None to let ReportLab auto-calculate if table_height is generous.
    """
    min_row_height = font_size * 1.4 + 4  # leading + padding
    total_min = min_row_height * num_rows

    if total_min <= table_height:
        # Distribute evenly
        return [table_height / num_rows] * num_rows
    else:
        # Let ReportLab auto-calculate, we'll scale later
        return None


def build_reportlab_table(
    html: str,
    bbox: tuple[float, float, float, float],
    font_name: str = "Helvetica",
    font_size: float = 8.0,
    angle: int = 0,
) -> tuple[Table | None, int]:
    """Convert HTML table to a ReportLab Table object.

    Args:
        html: HTML table string (translated).
        bbox: Target bounding box (x0, y0, x1, y1).
        font_name: Font to use for cell text.
        font_size: Font size for cell text.
        angle: Rotation angle (0, 90, 180, 270).

    Returns:
        (Table object or None, effective angle for rendering)
    """
    rows = parse_html_table(html)
    if not rows:
        return None, angle

    # For rotated tables, swap effective width/height for layout calculation
    if angle in (90, 270):
        table_width = bbox[3] - bbox[1]   # use height as width
        table_height = bbox[2] - bbox[0]  # use width as height
    else:
        table_width = bbox[2] - bbox[0]
        table_height = bbox[3] - bbox[1]

    # Determine grid dimensions
    max_cols = 0
    for row in rows:
        col_count = sum(cell["colspan"] for cell in row)
        max_cols = max(max_cols, col_count)
    num_rows = len(rows)

    if max_cols == 0 or num_rows == 0:
        return None, angle

    # Adjust font size based on table density
    # More columns = smaller font to fit
    if max_cols > 8:
        font_size = min(font_size, 6.0)
    elif max_cols > 5:
        font_size = min(font_size, 7.0)

    cell_style = ParagraphStyle(
        name="TableCell",
        fontName=font_name,
        fontSize=font_size,
        leading=font_size * 1.2,
        wordWrap="CJK",
    )

    header_style = ParagraphStyle(
        name="TableHeader",
        fontName=font_name,
        fontSize=font_size,
        leading=font_size * 1.2,
        wordWrap="CJK",
        alignment=1,  # center
    )

    data, span_commands = _build_grid(rows, max_cols, num_rows, cell_style, header_style)

    if not data:
        return None, angle

    # Calculate column widths proportional to content
    col_widths = _estimate_col_widths(rows, max_cols, table_width, font_name, font_size)

    # Calculate row heights
    row_heights = _estimate_row_heights(data, col_widths, num_rows, table_height, font_size)

    table = Table(data, colWidths=col_widths, rowHeights=row_heights)

    style_commands = [
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 1),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3),
    ]

    # Header row background
    if rows and rows[0] and rows[0][0].get("is_header"):
        style_commands.append(
            ("BACKGROUND", (0, 0), (-1, 0), colors.Color(0.9, 0.9, 0.9))
        )

    # Add SPAN commands for cell merging
    style_commands.extend(span_commands)

    table.setStyle(TableStyle(style_commands))

    return table, angle
