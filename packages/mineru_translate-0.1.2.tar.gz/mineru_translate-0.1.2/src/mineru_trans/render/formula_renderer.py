"""Formula renderer: LaTeX to PNG image for inline/interline equations."""

from __future__ import annotations

import hashlib
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class FormulaRenderer:
    """Render LaTeX formulas to PNG images using matplotlib."""

    def __init__(self, cache_dir: Path) -> None:
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def render_inline(
        self, latex: str, font_size: float = 12.0, dpi: int = 150
    ) -> Path | None:
        """Render an inline equation LaTeX string to a PNG image.

        Args:
            latex: LaTeX string (e.g., "\\Delta Q", "N_{zero}").
            font_size: Target font size in points.
            dpi: Resolution for rendering.

        Returns:
            Path to the rendered PNG, or None on failure.
        """
        if not latex or not latex.strip():
            return None

        # Unescape XML entities that were applied for DeepL transport
        clean = latex.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        clean = self._normalize_latex(clean)

        if not clean:
            return None

        # Cache by content hash
        cache_key = hashlib.md5(f"{clean}_{font_size}_{dpi}".encode()).hexdigest()
        cached = self.cache_dir / f"eq_{cache_key}.png"
        if cached.exists():
            return cached

        try:
            import matplotlib
            matplotlib.use("Agg")  # Non-interactive backend
            import matplotlib.pyplot as plt

            fig, ax = plt.subplots(figsize=(0.01, 0.01))
            ax.set_axis_off()
            fig.patch.set_alpha(0)
            ax.patch.set_alpha(0)

            ax.text(
                0, 0.5, f"${clean}$",
                fontsize=font_size,
                verticalalignment="center",
                horizontalalignment="left",
                transform=ax.transAxes,
            )

            fig.savefig(
                str(cached),
                dpi=dpi,
                transparent=True,
                bbox_inches="tight",
                pad_inches=0.01,
            )
            plt.close(fig)

            logger.debug("Rendered equation: %s -> %s", clean[:40], cached.name)
            return cached

        except Exception as e:
            logger.debug("Failed to render equation '%s': %s", clean[:40], e)
            return None

    @staticmethod
    def _normalize_latex(latex: str) -> str:
        """Normalize LaTeX string for matplotlib mathtext."""
        s = latex.strip()
        # Remove surrounding delimiters
        for start, end in [
            ("$$", "$$"), ("$", "$"),
            ("\\(", "\\)"), ("\\[", "\\]"),
            ("(", ")"),
        ]:
            if len(s) > len(start) + len(end) and s.startswith(start) and s.endswith(end):
                s = s[len(start):-len(end)].strip()
                break
        return s
