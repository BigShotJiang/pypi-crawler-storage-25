"""Main PDF renderer using ReportLab Canvas."""

from __future__ import annotations

import logging
from pathlib import Path

from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import Color, black
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import Frame, Paragraph

from ..models import (
    Block,
    FitResult,
    FontInfo,
    LayoutDocument,
    Page,
    TranslatedBlock,
    TranslateDecision,
)
from ..strategy import classify_block, is_container_block
from .formula_renderer import FormulaRenderer
from .image_loader import ImageLoader
from .table_renderer import build_reportlab_table

logger = logging.getLogger(__name__)

# Track registered fonts to avoid re-registration
_registered_fonts: set[str] = set()
_fonts_initialized = False

# Built-in ReportLab fonts that don't need registration
_BUILTIN_FONTS = {
    "Helvetica", "Helvetica-Bold", "Helvetica-Oblique", "Helvetica-BoldOblique",
    "Times-Roman", "Times-Bold", "Times-Italic", "Times-BoldItalic",
    "Courier", "Courier-Bold", "Courier-Oblique", "Courier-BoldOblique",
}


def _init_fonts() -> None:
    """Register CJK fonts and font families once."""
    global _fonts_initialized
    if _fonts_initialized:
        return
    _fonts_initialized = True

    from reportlab.pdfbase.pdfmetrics import registerFontFamily

    # Try to register CJK fonts
    _font_candidates = [
        ("NotoSansCJKsc", [
            "C:/Windows/Fonts/NotoSansSC-VF.ttf",
            "/usr/share/fonts/noto-cjk/NotoSansCJKsc-Regular.otf",
            "/System/Library/Fonts/NotoSansCJKsc-Regular.otf",
        ]),
        ("SimHei", ["C:/Windows/Fonts/simhei.ttf"]),
        ("SimSun", ["C:/Windows/Fonts/simsun.ttc"]),
        # Segoe UI Symbol: covers all Unicode math/super/subscript chars missing
        # from CJK fonts (U+2070–U+209F, arrows, ⌈⌉⌊⌋, ⋮⋱, etc.)
        ("SegoeUISymbol", ["C:/Windows/Fonts/seguisym.ttf"]),
    ]

    for name, paths in _font_candidates:
        for p in paths:
            if Path(p).exists():
                try:
                    pdfmetrics.registerFont(TTFont(name, p))
                    _registered_fonts.add(name)
                    logger.info("Registered font: %s from %s", name, p)
                    break
                except Exception:
                    continue

    # Register SimHei as bold variant for NotoSansCJKsc
    if "NotoSansCJKsc" in _registered_fonts and "SimHei" in _registered_fonts:
        try:
            registerFontFamily(
                "NotoSansCJKsc",
                normal="NotoSansCJKsc",
                bold="SimHei",
                italic="NotoSansCJKsc",
                boldItalic="SimHei",
            )
            logger.info("Registered font family: NotoSansCJKsc (bold=SimHei)")
        except Exception:
            pass

    # Register Latin font
    for name, paths in [
        ("NotoSans", [
            "C:/Windows/Fonts/NotoSans-Regular.ttf",
            "/usr/share/fonts/noto/NotoSans-Regular.ttf",
        ]),
    ]:
        for p in paths:
            if Path(p).exists():
                try:
                    pdfmetrics.registerFont(TTFont(name, p))
                    _registered_fonts.add(name)
                    break
                except Exception:
                    continue


def _try_register_font(font_name: str) -> str:
    """Ensure fonts are initialized and return usable font name."""
    _init_fonts()

    if font_name in _registered_fonts or font_name in _BUILTIN_FONTS:
        return font_name

    # If requested CJK font not found, try any registered CJK font
    cjk_fonts = ["NotoSansCJKsc", "SimHei", "SimSun"]
    if font_name in cjk_fonts:
        for name in cjk_fonts:
            if name in _registered_fonts:
                return name

    # For any unknown font, prefer NotoSansCJKsc (supports both CJK and Latin)
    # over Helvetica (Latin only)
    if "NotoSansCJKsc" in _registered_fonts:
        logger.debug("Font %s not found, falling back to NotoSansCJKsc", font_name)
        return "NotoSansCJKsc"

    logger.debug("Font %s not found, falling back to Helvetica", font_name)
    return "Helvetica"


def measure_translated_height(tb: "TranslatedBlock") -> float:
    """Measure actual ReportLab paragraph height for a translated block.

    Mirrors the text construction in _render_translated_text so the
    measurement reflects exactly what will be rendered.  Used by the
    pipeline to update adjusted_bbox *before* overlap resolution so that
    the resolver works with accurate heights.

    Returns 0.0 if the block cannot be measured (no text, zero width, etc.).
    """
    import re
    from reportlab.platypus import Paragraph
    from reportlab.lib.styles import ParagraphStyle
    from .latex_unicode import latex_to_unicode

    fit = tb.fit_result
    if not fit or not tb.translated_text:
        return 0.0

    bbox = fit.adjusted_bbox
    width = bbox[2] - bbox[0]
    if width <= 0:
        return 0.0

    font_name = _try_register_font(tb.font_info.font_name)
    color = _int_color_to_rl(tb.font_info.color)
    alignment = 1 if tb.is_centered else 0

    style = ParagraphStyle(
        name="measure",
        fontName=font_name,
        fontSize=fit.font_size,
        leading=fit.leading,
        textColor=color,
        wordWrap="CJK",
        alignment=alignment,
    )

    text = tb.translated_text

    _SO = "\x00SO\x00"   # super open
    _SC = "\x00SC\x00"   # super close
    _BO = "\x00BO\x00"   # sub open
    _BC = "\x00BC\x00"   # sub close
    _EO = "\x00EO\x00"   # eq-font open  (SegoeUISymbol)
    _EC = "\x00EC\x00"   # eq-font close

    def replace_eq_tag(match):
        uni = latex_to_unicode(match.group(1))
        return f" {_EO}{uni}{_EC} "
    text = re.sub(r'<eq id="\d+">(.*?)</eq>', replace_eq_tag, text)

    if tb.equations:
        eq_map = {eq["index"]: eq["latex"] for eq in tb.equations}
        def replace_eq_legacy(match):
            idx = int(match.group(1))
            uni = latex_to_unicode(eq_map.get(idx, "?"))
            return f" {_EO}{uni}{_EC} "
        text = re.sub(r"\{\{EQ:(\d+)\}\}", replace_eq_legacy, text)

    text = re.sub(r"<sup>(.*?)</sup>", lambda m: f"{_SO}{m.group(1)}{_SC}", text,
                  flags=re.DOTALL)
    text = re.sub(r"<sub>(.*?)</sub>", lambda m: f"{_BO}{m.group(1)}{_BC}", text,
                  flags=re.DOTALL)
    text = re.sub(r"\^\{([^}]+)\}", lambda m: f"{_SO}{m.group(1)}{_SC}", text)
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    _eq_font = 'SegoeUISymbol' if 'SegoeUISymbol' in _registered_fonts else font_name
    text = (text
            .replace(_EO, f'<font name="{_eq_font}">').replace(_EC, "</font>")
            .replace(_SO, "<super>").replace(_SC, "</super>")
            .replace(_BO, "<sub>").replace(_BC, "</sub>"))
    # Wrap chars that NotoSansCJKsc lacks in SegoeUISymbol:
    #   U+00B2/B3/B9: Latin-1 superscripts ²³¹
    #   U+02B0-U+02FF: Spacing modifier letters (ˆ U+02C6, ˇ U+02C7, etc.)
    #   U+2070-U+209F: Unicode super/subscript block
    if _eq_font != font_name:
        text = re.sub(
            r"[\u00b2\u00b3\u00b9\u02b0-\u02ff\u2070-\u209f]+",
            lambda m: f'<font name="{_eq_font}">{m.group()}</font>',
            text,
        )
    if tb.font_info.is_bold:
        text = f"<b>{text}</b>"

    try:
        para = Paragraph(text, style)
        _, actual_h = para.wrap(width, 10000)
        return actual_h
    except Exception:
        return 0.0


def _to_rl_y(layout_y: float, page_height: float) -> float:
    """Convert layout.json y-coordinate (top-left origin, y↓) to
    ReportLab y-coordinate (bottom-left origin, y↑)."""
    return page_height - layout_y


def _int_color_to_rl(color_int: int) -> Color:
    """Convert sRGB integer color to ReportLab Color."""
    r = ((color_int >> 16) & 0xFF) / 255.0
    g = ((color_int >> 8) & 0xFF) / 255.0
    b = (color_int & 0xFF) / 255.0
    return Color(r, g, b)


class PDFRenderer:
    """Renders translated layout to PDF using ReportLab."""

    def __init__(
        self,
        image_loader: ImageLoader,
        formula_renderer: FormulaRenderer | None = None,
        default_font: str = "Helvetica",
    ) -> None:
        self.image_loader = image_loader
        self.formula_renderer = formula_renderer
        self.default_font = default_font

    def render(
        self,
        doc: LayoutDocument,
        translated_blocks: dict[tuple[int, ...], TranslatedBlock],
        output_path: Path,
    ) -> None:
        """Render the full document to PDF.

        Args:
            doc: The parsed layout document.
            translated_blocks: Map from (page_idx, *block_path) to TranslatedBlock.
            output_path: Output PDF file path.
        """
        first_page = doc.pdf_info[0] if doc.pdf_info else None
        page_w = first_page.page_size[0] if first_page else 612
        page_h = first_page.page_size[1] if first_page else 792

        canvas = Canvas(str(output_path), pagesize=(page_w, page_h))

        for page in doc.pdf_info:
            pw, ph = page.page_size
            canvas.setPageSize((pw, ph))
            self._render_page(canvas, page, translated_blocks, pw, ph)
            canvas.showPage()

        canvas.save()
        logger.info("PDF saved to %s (%d pages)", output_path, len(doc.pdf_info))

    def _render_page(
        self,
        canvas: Canvas,
        page: Page,
        translated_blocks: dict[tuple[int, ...], TranslatedBlock],
        page_width: float,
        page_height: float,
    ) -> None:
        """Render a single page."""
        page_idx = page.page_idx

        # Render para_blocks
        for block_idx, block in enumerate(page.para_blocks):
            self._render_block(
                canvas, block, page_idx, (block_idx,),
                translated_blocks, page_height,
            )

        # Render discarded_blocks
        for block_idx, block in enumerate(page.discarded_blocks):
            self._render_block(
                canvas, block, page_idx, (-1, block_idx),
                translated_blocks, page_height,
            )

    def _render_block(
        self,
        canvas: Canvas,
        block: Block,
        page_idx: int,
        block_path: tuple[int, ...],
        translated_blocks: dict[tuple[int, ...], TranslatedBlock],
        page_height: float,
    ) -> None:
        """Render a single block (may recurse for containers)."""
        key = (page_idx, *block_path)

        # Container blocks: render sub-blocks
        if is_container_block(block):
            for sub_idx, sub_block in enumerate(block.blocks or []):
                self._render_block(
                    canvas, sub_block, page_idx,
                    block_path + (sub_idx,),
                    translated_blocks, page_height,
                )
            return

        # Check if this block has a translation
        tb = translated_blocks.get(key)

        # Image body: render the image
        if block.type == "image_body":
            self._render_image(canvas, block, page_height)
            return

        # Interline equation: render as image
        if block.type == "interline_equation":
            self._render_equation_image(canvas, block, page_height, tb)
            return

        # Table body with HTML: render as table
        if block.type == "table_body" and tb and tb.translated_html:
            self._render_html_table(canvas, block, tb, page_height)
            return

        # Text content (translated or original)
        if tb and tb.translated_text and tb.fit_result:
            self._render_translated_text(canvas, tb, page_height)
        elif block.lines:
            self._render_original_text(canvas, block, page_height, tb=tb)

    def _render_image(
        self, canvas: Canvas, block: Block, page_height: float
    ) -> None:
        """Render an image block."""
        image_path = self._find_image_path(block)
        if not image_path:
            return

        local_path = self.image_loader.load(image_path)
        if not local_path:
            return

        x0, y0, x1, y1 = block.bbox
        width = x1 - x0
        height = y1 - y0
        rl_y = _to_rl_y(y1, page_height)

        try:
            canvas.drawImage(
                str(local_path), x0, rl_y, width, height,
                preserveAspectRatio=True, mask="auto",
            )
        except Exception:
            logger.warning("Failed to render image at bbox %s", block.bbox)

    def _render_equation_image(
        self, canvas: Canvas, block: Block, page_height: float,
        tb: TranslatedBlock | None = None,
    ) -> None:
        """Render an interline equation using its image_path."""
        image_path = self._find_image_path(block)
        if not image_path:
            # Fallback: render LaTeX as text
            text = block.get_text_content()
            if text:
                self._render_text_at_bbox(canvas, text, block.bbox, page_height, 8.0)
            return

        local_path = self.image_loader.load(image_path)
        if not local_path:
            return

        # Use overlap-resolver-adjusted position if available
        bbox = tb.fit_result.adjusted_bbox if (tb and tb.fit_result) else block.bbox
        x0, y0, x1, y1 = bbox
        width = x1 - x0
        height = y1 - y0
        rl_y = _to_rl_y(y1, page_height)

        try:
            canvas.drawImage(
                str(local_path), x0, rl_y, width, height,
                preserveAspectRatio=True, mask="auto",
            )
        except Exception:
            logger.warning("Failed to render equation image at bbox %s", block.bbox)

    def _render_html_table(
        self,
        canvas: Canvas,
        block: Block,
        tb: TranslatedBlock,
        page_height: float,
    ) -> None:
        """Render a translated HTML table with rotation and cell merging."""
        bbox = tb.fit_result.adjusted_bbox if tb.fit_result else block.bbox
        font_name = _try_register_font(tb.font_info.font_name)
        angle = block.angle

        # Build table with rotation awareness
        result = build_reportlab_table(
            tb.translated_html,
            bbox,
            font_name=font_name,
            font_size=tb.font_info.font_size * 0.8,
            angle=angle,
        )
        table, effective_angle = result
        if not table:
            return

        x0, y0, x1, y1 = bbox
        width = x1 - x0
        height = y1 - y0

        try:
            if effective_angle in (90, 270):
                # Rotated table: the "logical" table is wider than tall,
                # but the bbox is narrow and tall.
                logical_w = height  # bbox height becomes table width
                logical_h = width   # bbox width becomes table height
                tw, th = table.wrap(logical_w, logical_h)

                canvas.saveState()

                if effective_angle == 270:
                    # After translate(x0, rl_bottom) + rotate(90):
                    #   local (lx, ly) -> page (x0 - ly, rl_bottom + lx)
                    # Table drawOn at (0, -th):
                    #   bottom-left (0, -th) -> page (x0 + th, rl_bottom) = right side
                    #   top-left (0, 0) -> page (x0, rl_bottom) = left side
                    #   top-right (tw, 0) -> page (x0, rl_bottom + tw) = top
                    # So table occupies page x=[x0, x0+th], y=[rl_bottom, rl_bottom+tw]
                    rl_x = x0
                    rl_y = _to_rl_y(y1, page_height)  # bottom of bbox in RL
                    canvas.translate(rl_x, rl_y)
                    canvas.rotate(90)

                    scale_x = logical_w / tw if tw > logical_w else 1.0
                    scale_y = logical_h / th if th > logical_h else 1.0
                    scale = min(scale_x, scale_y)
                    if scale < 1.0:
                        canvas.scale(scale, scale)
                    table.drawOn(canvas, 0, -th)

                else:  # 90
                    # After translate(x1, rl_top) + rotate(-90):
                    #   local (lx, ly) -> page (x1 + ly, rl_top - lx)
                    # drawOn at (0, -th):
                    #   top-left (0, 0) -> page (x1, rl_top)
                    #   bottom-right (tw, -th) -> page (x1 - th, rl_top - tw)
                    rl_x = x1
                    rl_y = _to_rl_y(y0, page_height)  # top of bbox in RL
                    canvas.translate(rl_x, rl_y)
                    canvas.rotate(-90)

                    scale_x = logical_w / tw if tw > logical_w else 1.0
                    scale_y = logical_h / th if th > logical_h else 1.0
                    scale = min(scale_x, scale_y)
                    if scale < 1.0:
                        canvas.scale(scale, scale)
                    table.drawOn(canvas, 0, -th)

                canvas.restoreState()
            else:
                # Normal (0° or 180°) table
                rl_y = _to_rl_y(y0, page_height)
                tw, th = table.wrap(width, height)

                # Scale to fit if needed
                scale_x = width / tw if tw > width else 1.0
                scale_y = height / th if th > height else 1.0
                scale = min(scale_x, scale_y)

                if scale < 0.99:
                    canvas.saveState()
                    canvas.translate(x0, rl_y - height)
                    canvas.scale(scale, scale)
                    table.drawOn(canvas, 0, 0)
                    canvas.restoreState()
                else:
                    table.drawOn(canvas, x0, rl_y - th)

        except Exception as e:
            logger.warning("Failed to render table at bbox %s: %s", bbox, e)

    def _render_translated_text(
        self,
        canvas: Canvas,
        tb: TranslatedBlock,
        page_height: float,
    ) -> None:
        """Render translated text with fitted font size."""
        import re

        fit = tb.fit_result
        bbox = fit.adjusted_bbox
        font_name = _try_register_font(tb.font_info.font_name)
        color = _int_color_to_rl(tb.font_info.color)

        # Alignment: center for centered titles
        alignment = 1 if tb.is_centered else 0  # 0=LEFT, 1=CENTER

        style = ParagraphStyle(
            name="translated",
            fontName=font_name,
            fontSize=fit.font_size,
            leading=fit.leading,
            textColor=color,
            wordWrap="CJK",
            alignment=alignment,
        )

        text = tb.translated_text

        # Step 1: Replace <eq> tags with Unicode text (before HTML escaping)
        from .latex_unicode import latex_to_unicode

        _SO = "\x00SO\x00"   # super open
        _SC = "\x00SC\x00"   # super close
        _BO = "\x00BO\x00"   # sub open
        _BC = "\x00BC\x00"   # sub close
        _EO = "\x00EO\x00"   # eq-font open  (SegoeUISymbol)
        _EC = "\x00EC\x00"   # eq-font close

        def replace_eq_tag(match):
            uni = latex_to_unicode(match.group(1))
            return f" {_EO}{uni}{_EC} "
        text = re.sub(r'<eq id="\d+">(.*?)</eq>', replace_eq_tag, text)

        # Handle legacy {{EQ:N}} pattern
        if tb.equations:
            eq_map = {eq["index"]: eq["latex"] for eq in tb.equations}
            def replace_eq_legacy(match):
                idx = int(match.group(1))
                uni = latex_to_unicode(eq_map.get(idx, "?"))
                return f" {_EO}{uni}{_EC} "
            text = re.sub(r"\{\{EQ:(\d+)\}\}", replace_eq_legacy, text)

        # Step 1.5: Convert HTML sup/sub and LaTeX ^{...} to ReportLab tags via
        # placeholder technique (null bytes can't appear in normal text).
        # Must happen BEFORE HTML-escaping so the tags aren't mangled.

        # <sup>...</sup> → ReportLab <super>...</super>
        text = re.sub(r"<sup>(.*?)</sup>", lambda m: f"{_SO}{m.group(1)}{_SC}", text,
                      flags=re.DOTALL)
        # <sub>...</sub> → ReportLab <sub>...</sub>
        text = re.sub(r"<sub>(.*?)</sub>", lambda m: f"{_BO}{m.group(1)}{_BC}", text,
                      flags=re.DOTALL)
        # ^{...} literal LaTeX superscript notation (e.g. "^{a,c,*}") → <super>
        text = re.sub(r"\^\{([^}]+)\}", lambda m: f"{_SO}{m.group(1)}{_SC}", text)

        # Step 2: Now text is pure text (no XML tags), escape for ReportLab Paragraph
        text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

        # Step 2.5: Restore placeholders as ReportLab-compatible tags
        _eq_font = 'SegoeUISymbol' if 'SegoeUISymbol' in _registered_fonts else font_name
        text = (text
                .replace(_EO, f'<font name="{_eq_font}">').replace(_EC, "</font>")
                .replace(_SO, "<super>").replace(_SC, "</super>")
                .replace(_BO, "<sub>").replace(_BC, "</sub>"))

        # Wrap chars that NotoSansCJKsc lacks in SegoeUISymbol:
        #   U+00B2/B3/B9: Latin-1 superscripts ²³¹
        #   U+02B0-U+02FF: Spacing modifier letters (ˆ U+02C6, ˇ U+02C7, etc.)
        #   U+2070-U+209F: Unicode super/subscript block
        if _eq_font != font_name:
            text = re.sub(
                r"[\u00b2\u00b3\u00b9\u02b0-\u02ff\u2070-\u209f]+",
                lambda m: f'<font name="{_eq_font}">{m.group()}</font>',
                text,
            )

        if tb.font_info.is_bold:
            text = f"<b>{text}</b>"

        para = Paragraph(text, style)

        x0, y0, x1, y1 = bbox
        width = x1 - x0
        height = y1 - y0
        angle = tb.original.angle

        if angle in (90, 270):
            # Rotated text: swap width/height for layout, render with rotation
            logical_w = height  # text flows along bbox height
            logical_h = width   # text height fits in bbox width
            rl_y_bottom = _to_rl_y(y1, page_height)

            canvas.saveState()
            if angle == 270:
                canvas.translate(x0, rl_y_bottom)
                canvas.rotate(90)
            else:
                canvas.translate(x1, _to_rl_y(y0, page_height))
                canvas.rotate(-90)

            _, actual_para_h = para.wrap(logical_w, 10000)
            frame_h = max(logical_h, actual_para_h)
            frame = Frame(
                0, -frame_h, logical_w, frame_h,
                leftPadding=0, rightPadding=0,
                topPadding=0, bottomPadding=0,
            )
            frame.addFromList([para], canvas)
            canvas.restoreState()
        else:
            rl_y = _to_rl_y(y1, page_height)
            # Pre-wrap to get the actual height ReportLab will render. The
            # fitting engine may use different font metrics than the renderer
            # (NotoSansCJKsc), causing the paragraph to exceed the adjusted_bbox.
            # IMPORTANT: we must NOT expand the frame — in ReportLab coordinates
            # the frame bottom is fixed at rl_y, so expanding upward would move
            # text into the space of blocks above (including images).
            # Instead, shrink the font size until the text fits in `height`.
            _, actual_h = para.wrap(width, height * 10)
            if actual_h > height + 1:
                current_fs = fit.font_size
                while actual_h > height + 1 and current_fs > 3.0:
                    current_fs = round(current_fs - 0.5, 1)
                    shrunk_style = ParagraphStyle(
                        name="translated_shrunk",
                        fontName=font_name,
                        fontSize=current_fs,
                        leading=current_fs * 1.1,
                        textColor=color,
                        wordWrap="CJK",
                        alignment=alignment,
                    )
                    para = Paragraph(text, shrunk_style)
                    _, actual_h = para.wrap(width, height * 10)
                logger.debug(
                    "Shrunk font %.1f→%.1fpt to fit bbox (actual=%.1f, height=%.1f): %r",
                    fit.font_size, current_fs, actual_h, height,
                    (tb.translated_text or "")[:40],
                )
            # Never expand the frame beyond bbox height: in ReportLab coords
            # the frame bottom is fixed at rl_y, so a taller frame grows
            # *upward* — into the space of blocks rendered above (images, etc.).
            # If text still overflows at 3pt, it is clipped at the bottom of
            # the bbox rather than rendered over preceding content.
            frame_h = height
            frame = Frame(
                x0, rl_y, width, frame_h,
                leftPadding=0, rightPadding=0,
                topPadding=0, bottomPadding=0,
            )
            frame.addFromList([para], canvas)

    def _render_original_text(
        self,
        canvas: Canvas,
        block: Block,
        page_height: float,
        tb: "TranslatedBlock | None" = None,
    ) -> None:
        """Render original (untranslated) text content."""
        text = block.get_text_content()
        if not text:
            return

        if tb and tb.font_info:
            # Use font size extracted from source PDF — exact match to original.
            font_size = tb.font_info.font_size
            font_name = _try_register_font(tb.font_info.font_name)
        else:
            # Fallback: bbox height ≈ glyph height ≈ font_size for MinerU bboxes.
            font_size = max(6.0, block.bbox[3] - block.bbox[1])
            font_name = _try_register_font(self.default_font)
        self._render_text_at_bbox(canvas, text, block.bbox, page_height, font_size, font_name)

    def _render_text_at_bbox(
        self,
        canvas: Canvas,
        text: str,
        bbox: tuple[float, float, float, float],
        page_height: float,
        font_size: float,
        font_name: str = "Helvetica",
    ) -> None:
        """Helper: render text within a bbox using Paragraph + Frame."""
        style = ParagraphStyle(
            name="default",
            fontName=font_name,
            fontSize=font_size,
            leading=font_size * 1.2,
            wordWrap="CJK",
        )

        safe_text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        para = Paragraph(safe_text, style)

        x0, y0, x1, y1 = bbox
        width = x1 - x0
        height = y1 - y0
        rl_y = _to_rl_y(y1, page_height)

        # Ensure frame is tall enough for at least one line (bbox height from the
        # source PDF may be only the glyph height, smaller than full leading).
        _, actual_h = para.wrap(width, 10000)
        frame_h = max(height, actual_h)

        frame = Frame(
            x0, rl_y, width, frame_h,
            leftPadding=0, rightPadding=0,
            topPadding=0, bottomPadding=0,
        )
        frame.addFromList([para], canvas)

    @staticmethod
    def _find_image_path(block: Block) -> str | None:
        """Extract image_path from a block or its spans."""
        if block.image_path:
            return block.image_path
        if block.lines:
            for line in block.lines:
                for span in line.spans:
                    if span.image_path:
                        return span.image_path
        return None
