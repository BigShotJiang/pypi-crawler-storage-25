"""Match extracted font spans to layout.json blocks via bbox overlap."""

from __future__ import annotations

import logging
from collections import Counter

from ..models import Block, FontInfo
from .extractor import ExtractedFontSpan
from .fallback import estimate_font_info

logger = logging.getLogger(__name__)


def compute_iou(
    bbox1: tuple[float, float, float, float],
    bbox2: tuple[float, float, float, float],
) -> float:
    """Compute Intersection over Union of two bounding boxes."""
    x0 = max(bbox1[0], bbox2[0])
    y0 = max(bbox1[1], bbox2[1])
    x1 = min(bbox1[2], bbox2[2])
    y1 = min(bbox1[3], bbox2[3])

    if x0 >= x1 or y0 >= y1:
        return 0.0

    intersection = (x1 - x0) * (y1 - y0)
    area1 = (bbox1[2] - bbox1[0]) * (bbox1[3] - bbox1[1])
    area2 = (bbox2[2] - bbox2[0]) * (bbox2[3] - bbox2[1])
    union = area1 + area2 - intersection

    if union <= 0:
        return 0.0
    return intersection / union


def compute_containment(
    inner: tuple[float, float, float, float],
    outer: tuple[float, float, float, float],
) -> float:
    """Compute how much of inner bbox is contained within outer bbox."""
    x0 = max(inner[0], outer[0])
    y0 = max(inner[1], outer[1])
    x1 = min(inner[2], outer[2])
    y1 = min(inner[3], outer[3])

    if x0 >= x1 or y0 >= y1:
        return 0.0

    intersection = (x1 - x0) * (y1 - y0)
    inner_area = (inner[2] - inner[0]) * (inner[3] - inner[1])

    if inner_area <= 0:
        return 0.0
    return intersection / inner_area


def match_font_to_block(
    block: Block,
    extracted_spans: list[ExtractedFontSpan],
    iou_threshold: float = 0.1,
    target_lang: str = "en",
) -> FontInfo:
    """Find the best matching font info for a layout block.

    Matches by bbox overlap, then takes the most common font among
    overlapping spans.

    Args:
        block: The layout block to match.
        extracted_spans: All extracted font spans for the page.
        iou_threshold: Minimum IoU or containment to consider a match.
        target_lang: Target language (for fallback font selection).

    Returns:
        FontInfo for the block.
    """
    if not extracted_spans:
        return estimate_font_info(block, target_lang)

    matches: list[ExtractedFontSpan] = []

    for span in extracted_spans:
        # Try both IoU and containment (span inside block)
        iou = compute_iou(block.bbox, span.bbox)
        containment = compute_containment(span.bbox, block.bbox)

        if iou >= iou_threshold or containment >= 0.5:
            matches.append(span)

    if not matches:
        return estimate_font_info(block, target_lang)

    # Weight each span by its text length so that tiny symbols (footnote
    # markers: *, †, ‡ at ~6pt) don't tie with or override the main body
    # text of a block when both appear in the same bbox.
    font_name_w: Counter = Counter()
    font_size_w: Counter = Counter()
    for m in matches:
        w = max(len(m.text.strip()), 1)
        font_name_w[m.font_name] += w
        font_size_w[m.font_size] += w

    most_common_name = font_name_w.most_common(1)[0][0]
    most_common_size = font_size_w.most_common(1)[0][0]
    is_bold = any(m.is_bold for m in matches if m.font_name == most_common_name)
    is_italic = any(m.is_italic for m in matches if m.font_name == most_common_name)
    # Most common color among dominant font matches
    colors = Counter(
        m.color for m in matches if m.font_name == most_common_name
    )
    color = colors.most_common(1)[0][0] if colors else 0x000000

    return FontInfo(
        font_name=most_common_name,
        font_size=most_common_size,
        is_bold=is_bold,
        is_italic=is_italic,
        color=color,
    )
