"""Font extraction from source PDF using PyMuPDF."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class ExtractedFontSpan:
    """Font metadata extracted from a PDF span via PyMuPDF."""

    font_name: str
    font_size: float
    is_bold: bool
    is_italic: bool
    color: int  # sRGB integer
    bbox: tuple[float, float, float, float]
    text: str


def extract_fonts_from_pdf(
    pdf_path: str | Path,
) -> list[list[ExtractedFontSpan]] | None:
    """Extract font information per page from a PDF using PyMuPDF.

    Args:
        pdf_path: Path to the source PDF.

    Returns:
        List of pages, each containing a list of ExtractedFontSpan.
        Returns None if PyMuPDF is not available or extraction fails.
    """
    try:
        import fitz  # PyMuPDF
    except ImportError:
        logger.warning("PyMuPDF not installed. Font extraction unavailable.")
        return None

    pdf_path = Path(pdf_path)
    if not pdf_path.exists():
        logger.warning("Source PDF not found: %s", pdf_path)
        return None

    try:
        doc = fitz.open(str(pdf_path))
    except Exception:
        logger.exception("Failed to open PDF: %s", pdf_path)
        return None

    all_pages: list[list[ExtractedFontSpan]] = []

    for page_num in range(len(doc)):
        page = doc[page_num]
        page_spans: list[ExtractedFontSpan] = []

        try:
            text_dict = page.get_text("dict")
        except Exception:
            logger.warning("Failed to extract text from page %d", page_num)
            all_pages.append([])
            continue

        for block in text_dict.get("blocks", []):
            if block.get("type") != 0:  # 0 = text block in PyMuPDF
                continue
            for line in block.get("lines", []):
                for span in line.get("spans", []):
                    flags = span.get("flags", 0)
                    page_spans.append(
                        ExtractedFontSpan(
                            font_name=span.get("font", ""),
                            font_size=round(span.get("size", 10.0), 1),
                            is_bold=bool(flags & 16),  # bit 4
                            is_italic=bool(flags & 2),  # bit 1
                            color=span.get("color", 0),
                            bbox=(
                                span["bbox"][0],
                                span["bbox"][1],
                                span["bbox"][2],
                                span["bbox"][3],
                            ),
                            text=span.get("text", ""),
                        )
                    )

        all_pages.append(page_spans)

    doc.close()
    logger.info(
        "Extracted fonts from %d pages, total %d spans",
        len(all_pages),
        sum(len(p) for p in all_pages),
    )
    return all_pages


def is_scanned_page(
    extracted_spans: list[ExtractedFontSpan], expected_block_count: int
) -> bool:
    """Detect if a page is scanned (no real text layer).

    Args:
        extracted_spans: Spans extracted by PyMuPDF for this page.
        expected_block_count: Number of text blocks MinerU found on this page.

    Returns:
        True if the page appears to be scanned.
    """
    if not extracted_spans:
        return True
    # If PyMuPDF found very few spans relative to MinerU blocks, it's likely scanned
    if expected_block_count > 0 and len(extracted_spans) / expected_block_count < 0.2:
        return True
    return False
