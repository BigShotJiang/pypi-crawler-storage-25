"""Fallback font estimation when source PDF is unavailable or is a scanned document."""

from __future__ import annotations

import logging

from ..models import Block, FontInfo

logger = logging.getLogger(__name__)

# Default fonts by target language family
_CJK_LANGUAGES = {"zh", "zh-hans", "zh-hant", "ja", "ko"}

# Common font names available on most systems
_DEFAULT_CJK_FONT = "NotoSansCJKsc"  # Will be registered in pdf_renderer
_DEFAULT_LATIN_FONT = "NotoSans"
_FALLBACK_FONT = "Helvetica"  # ReportLab built-in, always available


def estimate_font_size(block: Block, ref_line_height: float = 15.0) -> float:
    """Estimate font size from bbox dimensions.

    For rotated blocks (angle=90/270): use bbox WIDTH (the narrow side).
    For normal blocks: use bbox HEIGHT.
    For multi-line blocks: use average line height.

    Args:
        ref_line_height: Typical single-line block height on this page (pt).
            Used to estimate the number of visual lines in VLM-packed blocks.
            Pass the median height of true single-line blocks (h ≤ 20) on the
            same page for best results; defaults to 15.0 if unavailable.
    """
    angle = getattr(block, "angle", 0)

    if angle in (90, 270):
        # Rotated: the "height" of text is the bbox width (narrow dimension).
        # MinerU bbox width ≈ glyph height (no leading) ≈ font_size directly.
        text_height = block.bbox[2] - block.bbox[0]  # width
        return round(max(text_height, 5.0), 1)

    if block.lines and len(block.lines) > 1:
        # True multi-line: each line has its own bbox whose height ≈ glyph height.
        # avg_height works well for CJK (glyph height ≈ font_size), but for Latin
        # text MinerU often measures line bboxes including leading, causing
        # avg_height to overestimate by ~1.2×.  Cap with a height-derived upper
        # bound: font_size ≤ block_height / (n_lines × 1.2).  For CJK blocks where
        # avg_height is accurate the cap is not tighter, so CJK is unaffected.
        total_height = sum(
            line.bbox[3] - line.bbox[1] for line in block.lines
        )
        avg_height = total_height / len(block.lines)
        n_lines = len(block.lines)
        block_height = block.bbox[3] - block.bbox[1]
        height_cap = block_height / (n_lines * 1.2)
        return round(min(avg_height, max(5.0, height_cap)), 1)

    height = block.bbox[3] - block.bbox[1]
    width = block.bbox[2] - block.bbox[0]

    # Single-line or no lines.
    # MinerU VLM mode packs all paragraph text into a single "line", so a
    # tall block with many chars is actually multi-line content.  Using
    # height*0.75 would give e.g. 47pt for a 63pt paragraph block, causing
    # the fitting engine to size body text LARGER than section titles.
    #
    # For tall single-line blocks we use TWO estimates and take the minimum:
    #
    # 1. Geometric: font_size ≈ sqrt(w × h / (n_chars × leading)) × 0.75
    #    The 0.75 factor compensates for partial OCR recovery (40–70% of
    #    glyphs on scanned pages).  Can overshoot when recovery is very low.
    #
    # 2. Height-based: font_size ≈ h / (n_lines × leading)
    #    where n_lines = round(h / ref_line_height).  Anchored to the page's
    #    own single-line block heights, so it adapts to the document's actual
    #    font size without depending on OCR recovery rate.
    #
    # For VLM-packed tall blocks, estimate n_lines from the page's reference
    # line height and derive font_size from that. This is independent of
    # n_chars (so it works for both scanned docs with partial OCR and
    # non-scanned docs with full text recovery).
    if height > 20 and block.lines:
        n_lines_est = max(1, round(height / ref_line_height))
        height_est = height / (n_lines_est * 1.2)
        return round(max(height_est, 5.0), 1)

    return round(max(height, 5.0), 1)


def get_default_font_name(target_lang: str) -> str:
    """Get default font name based on target language."""
    if target_lang.lower() in _CJK_LANGUAGES:
        return _DEFAULT_CJK_FONT
    return _DEFAULT_LATIN_FONT


def estimate_font_info(block: Block, target_lang: str = "en", ref_line_height: float = 15.0) -> FontInfo:
    """Estimate font info for a block using fallback heuristics.

    Args:
        block: The block to estimate font info for.
        target_lang: Target language (affects font selection).
        ref_line_height: Typical single-line block height on this page (pt).
            See estimate_font_size for details.

    Returns:
        Estimated FontInfo.
    """
    font_size = estimate_font_size(block, ref_line_height=ref_line_height)
    # Clamp to reasonable range
    font_size = max(5.0, min(font_size, 72.0))

    font_name = get_default_font_name(target_lang)

    # Heuristic: title blocks are often bold
    is_bold = block.type == "title"

    return FontInfo(
        font_name=font_name,
        font_size=font_size,
        is_bold=is_bold,
        is_italic=False,
        color=0x000000,
    )
