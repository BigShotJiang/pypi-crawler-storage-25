"""Overlap detection and resolution for translated blocks.

Phase B algorithm:
1. Partition blocks into non-interacting columns (no horizontal overlap)
2. Within each column, single-pass top-to-bottom resolution
3. If content exceeds page height, compress gaps then shrink proportionally
"""

from __future__ import annotations

import logging
import re

from ..models import FitResult, FontInfo, TranslatedBlock
from .engine import fit_text_in_bbox, smart_wrap

logger = logging.getLogger(__name__)

_MIN_GAP = 1.0  # minimum gap between blocks (points)

# Safety headroom for smart_wrap vs ReportLab height discrepancy.
# smart_wrap underestimates rendered height; shrinking to target_height exactly
# can cause step-5.5 to re-expand the block, creating oscillation.
# Requiring total <= target_height * _SHRINK_HEADROOM leaves enough slack.
_SHRINK_HEADROOM = 0.92

# Block types whose rendered size is fixed (formula/code images).
# These must never be shrunk by the overlap resolver — only pushed.
_FIXED_SIZE_TYPES = {"interline_equation", "code", "code_body"}


def compute_overlap(
    bbox1: tuple[float, float, float, float],
    bbox2: tuple[float, float, float, float],
) -> float:
    """Compute vertical overlap amount between two bboxes.

    Returns the overlap in points (positive = overlapping).
    Only considers overlap when bboxes also share horizontal space.
    """
    # Check horizontal overlap first
    h_overlap = min(bbox1[2], bbox2[2]) - max(bbox1[0], bbox2[0])
    if h_overlap <= 0:
        return 0.0

    # Vertical overlap
    v_overlap = min(bbox1[3], bbox2[3]) - max(bbox1[1], bbox2[1])
    return max(0.0, v_overlap)


def _get_bbox(block: TranslatedBlock) -> tuple[float, float, float, float]:
    """Get the effective bbox (adjusted if fit_result exists)."""
    if block.fit_result:
        return block.fit_result.adjusted_bbox
    return block.original.bbox


def _set_bbox(block: TranslatedBlock, bbox: tuple[float, float, float, float]) -> None:
    """Set the adjusted bbox on a block's fit_result."""
    if block.fit_result:
        block.fit_result = FitResult(
            font_size=block.fit_result.font_size,
            leading=block.fit_result.leading,
            lines=block.fit_result.lines,
            adjusted_bbox=bbox,
            expanded=block.fit_result.expanded,
        )


def _has_horizontal_overlap(
    a: tuple[float, float, float, float],
    b: tuple[float, float, float, float],
) -> bool:
    return a[0] < b[2] and b[0] < a[2]


def _is_text_block(block: TranslatedBlock) -> bool:
    """Check if a block has shrinkable text content.

    Fixed-size blocks (interline equations, code) are excluded: their visual
    size is determined by the renderer, not by the adjusted_bbox, so shrinking
    their bbox would just clip/overflow the content rather than reduce it.
    """
    if block.original.type in _FIXED_SIZE_TYPES:
        return False
    return block.translated_text is not None and block.fit_result is not None


def _block_height(block: TranslatedBlock) -> float:
    bbox = _get_bbox(block)
    return bbox[3] - bbox[1]


# ------------------------------------------------------------------
# Main entry point
# ------------------------------------------------------------------

def resolve_overlaps(
    blocks: list[TranslatedBlock],
    page_height: float,
    min_font_size: float = 6.0,
    max_shrink_ratio: float = 0.6,
    obstacles: list[tuple[float, float, float, float]] | None = None,
) -> None:
    """Detect and resolve overlaps between translated blocks on a page.

    Modifies blocks in-place. Guarantees all content fits within page_height.
    ``obstacles`` are immovable bboxes (e.g. images) that text blocks must not
    overlap with.
    """
    if not blocks:
        return

    # Step 1: Partition into columns (obstacle-aware)
    columns = _partition_columns(blocks, obstacles)

    # Step 2 & 3: Resolve each column independently
    for column in columns:
        _resolve_column(column, page_height, min_font_size, obstacles)


# ------------------------------------------------------------------
# Step 1: Column partitioning
# ------------------------------------------------------------------

def _obstacle_separates(
    a: tuple[float, float, float, float],
    b: tuple[float, float, float, float],
    obstacles: list[tuple[float, float, float, float]],
) -> bool:
    """Return True if any obstacle fully separates blocks a and b vertically.

    An obstacle "separates" a and b when:
    - It lies between them vertically (a.y1 <= obs.y0 <= b.y0 or vice versa), AND
    - It horizontally overlaps the shared x-region of a and b.

    This prevents full-page-width captions/separators from merging text blocks
    that live on opposite sides of an image into the same resolution column.
    """
    # Determine which block is above / below
    top, bot = (a, b) if a[3] <= b[1] else (b, a)
    # Shared horizontal extent
    shared_x0 = max(top[0], bot[0])
    shared_x1 = min(top[2], bot[2])
    if shared_x1 <= shared_x0:
        return False  # no horizontal overlap — callers already filter this out
    shared_band = (shared_x0, top[3], shared_x1, bot[1])
    for obs in obstacles:
        if not _has_horizontal_overlap(shared_band, obs):
            continue
        # Obstacle lies in the vertical gap [top.y1, bot.y0] if it has
        # any vertical overlap with that range.
        if obs[3] > top[3] and obs[1] < bot[1]:
            return True
    return False


def _partition_columns(
    blocks: list[TranslatedBlock],
    obstacles: list[tuple[float, float, float, float]] | None = None,
) -> list[list[TranslatedBlock]]:
    """Group blocks into columns that share horizontal space.

    Blocks in different columns cannot overlap vertically since they
    occupy different horizontal bands, so they can be resolved independently.

    When ``obstacles`` are given, two blocks that share horizontal space but
    are separated by an obstacle (e.g. a full-page image) are NOT merged into
    the same column — they can be resolved independently.
    """
    columns: list[list[TranslatedBlock]] = []

    for block in blocks:
        bbox = _get_bbox(block)
        placed = False
        for col in columns:
            for existing in col:
                ex_bbox = _get_bbox(existing)
                if not _has_horizontal_overlap(bbox, ex_bbox):
                    continue
                # Don't merge if an obstacle lies between the two blocks
                if obstacles and _obstacle_separates(bbox, ex_bbox, obstacles):
                    continue
                col.append(block)
                placed = True
                break
            if placed:
                break
        if not placed:
            columns.append([block])

    return columns


def _resolve_block_obstacle_overlap(
    block: TranslatedBlock,
    page_height: float,
    min_font_size: float,
    obstacles: list[tuple[float, float, float, float]] | None,
) -> None:
    """Ensure a single block does not overlap any obstacle.

    If the block starts before an obstacle (y0 < obs.y0) and overlaps it,
    try to shrink the block so it ends before the obstacle.  If shrinking
    fails, push the block below the obstacle instead.  Also resolves any
    further obstacle overlaps after repositioning.
    """
    if not obstacles:
        return
    for obs in sorted(obstacles, key=lambda o: o[1]):
        bbox = _get_bbox(block)
        if not _has_horizontal_overlap(bbox, obs):
            continue
        v_overlap = min(bbox[3], obs[3]) - max(bbox[1], obs[1])
        if v_overlap <= 0:
            continue
        # Block overlaps this obstacle
        if bbox[1] < obs[1]:
            # Block starts before obstacle: try shrinking to fit above it
            target_h = obs[1] - bbox[1] - _MIN_GAP
            if target_h > 0 and _is_text_block(block):
                compress_min_fs = min(3.0, min_font_size)
                if _try_shrink_to_height(block, target_h, compress_min_fs):
                    logger.debug(
                        "Shrunk block to fit above obstacle at y=%.1f (target_h=%.1f)",
                        obs[1], target_h,
                    )
                    continue
        # Can't shrink above obstacle (or block starts inside it): push below
        new_y0 = obs[3] + _MIN_GAP
        height = bbox[3] - bbox[1]
        new_y1 = new_y0 + height
        new_y0, new_y1 = _skip_obstacles(new_y0, new_y1, bbox, obstacles)
        _set_bbox(block, (bbox[0], new_y0, bbox[2], new_y1))
        logger.debug(
            "Pushed block below obstacle at y=%.1f → y0=%.1f",
            obs[3], new_y0,
        )


def _resolve_column(
    column: list[TranslatedBlock],
    page_height: float,
    min_font_size: float,
    obstacles: list[tuple[float, float, float, float]] | None = None,
) -> None:
    """Resolve overlaps within a single column and ensure page fit."""
    if len(column) <= 1:
        # Single block — resolve obstacle overlaps, then check page overflow
        if column:
            _resolve_block_obstacle_overlap(
                column[0], page_height, min_font_size, obstacles
            )
            _ensure_page_fit_single(column[0], page_height, min_font_size)
        return

    # Sort by y0 (top of bbox)
    column.sort(key=lambda b: _get_bbox(b)[1])

    # Single pass: resolve overlaps top to bottom
    shrink_attempted: set[int] = set()

    for i in range(1, len(column)):
        bbox_prev = _get_bbox(column[i - 1])
        bbox_curr = _get_bbox(column[i])

        # Only push if blocks actually share horizontal space
        if not _has_horizontal_overlap(bbox_prev, bbox_curr):
            continue

        overlap = bbox_prev[3] - bbox_curr[1] + _MIN_GAP
        if overlap <= 0:
            continue

        # Strategy A: Try shrinking the upper block (if text, not yet attempted)
        if (
            id(column[i - 1]) not in shrink_attempted
            and _is_text_block(column[i - 1])
            and column[i - 1].fit_result.expanded
        ):
            shrink_attempted.add(id(column[i - 1]))
            target_height = _block_height(column[i - 1]) - overlap
            if target_height > 0:
                success = _try_shrink_to_height(
                    column[i - 1], target_height, min_font_size
                )
                if success:
                    continue  # Overlap resolved by shrinking

        # Strategy B: Push current block down, skipping over any obstacle areas
        shift = overlap
        old = bbox_curr
        new_y0 = old[1] + shift
        new_y1 = old[3] + shift
        new_y0, new_y1 = _skip_obstacles(new_y0, new_y1, old, obstacles)
        new_bbox = (old[0], new_y0, old[2], new_y1)
        _set_bbox(column[i], new_bbox)
        logger.debug(
            "Pushed block at y=%.1f down by %.1f",
            old[1], new_y0 - old[1],
        )

    # After block-to-block pass, also resolve any block-obstacle overlaps
    # (a block that was NOT pushed by another block may still overlap an obstacle).
    if obstacles:
        for block in column:
            _resolve_block_obstacle_overlap(
                block, page_height, min_font_size, obstacles
            )

    # Step 3: Check page overflow and compress if needed
    last_bbox = _get_bbox(column[-1])
    if last_bbox[3] > page_height:
        _compress_column(column, page_height, min_font_size, obstacles)


def _skip_obstacles(
    y0: float,
    y1: float,
    bbox: tuple[float, float, float, float],
    obstacles: list[tuple[float, float, float, float]] | None,
) -> tuple[float, float, float, float]:
    """If the proposed [y0, y1] would intersect any horizontally-overlapping
    obstacle, push y0/y1 below the obstacle's bottom edge."""
    if not obstacles:
        return y0, y1
    height = y1 - y0
    for obs in sorted(obstacles, key=lambda o: o[1]):
        if not _has_horizontal_overlap((bbox[0], y0, bbox[2], y1), obs):
            continue
        # Vertical intersection check
        if y0 < obs[3] and y1 > obs[1]:
            y0 = obs[3] + _MIN_GAP
            y1 = y0 + height
    return y0, y1


# ------------------------------------------------------------------
# Shrink a block to fit target height
# ------------------------------------------------------------------

def _try_shrink_to_height(
    block: TranslatedBlock,
    target_height: float,
    min_font_size: float,
) -> bool:
    """Try to re-fit a block so it fits within target_height.

    Returns True if successful.
    """
    if not block.translated_text or not block.fit_result:
        return False

    # Strip equation placeholders for fitting
    clean = re.sub(r'<eq id="\d+">.*?</eq>', " ", block.translated_text)
    clean = re.sub(r"\{\{EQ:\d+\}\}", " ", clean).strip()
    if not clean:
        return False

    bbox = _get_bbox(block)
    width = bbox[2] - bbox[0]
    font_name = block.font_info.font_name

    # Try progressively smaller sizes
    for font_size in _frange(block.fit_result.font_size, min_font_size, -0.5):
        for leading_factor in (1.2, 1.1, 1.05, 1.0):
            leading = font_size * leading_factor
            lines = smart_wrap(clean, font_name, font_size, width)
            total = len(lines) * leading
            if total <= target_height * _SHRINK_HEADROOM:
                new_bbox = (bbox[0], bbox[1], bbox[2], bbox[1] + total)
                block.fit_result = FitResult(
                    font_size=font_size,
                    leading=leading,
                    lines=lines,
                    adjusted_bbox=new_bbox,
                    expanded=False,
                )
                return True

    return False


# ------------------------------------------------------------------
# Step 3: Page overflow compression
# ------------------------------------------------------------------

def _compress_column(
    column: list[TranslatedBlock],
    page_height: float,
    min_font_size: float,
    obstacles: list[tuple[float, float, float, float]] | None = None,
) -> None:
    """Compress a column so all blocks fit within page_height."""
    if not column:
        return

    first_y0 = _get_bbox(column[0])[1]
    raw_available = page_height - first_y0

    # Subtract obstacle regions that horizontally overlap with this column.
    # Without this, a column that has images in the middle will overestimate
    # available space (e.g., 822pt raw but only 391pt usable after images).
    obstacle_blocked = 0.0
    if obstacles:
        col_x0 = min(_get_bbox(b)[0] for b in column)
        col_x1 = max(_get_bbox(b)[2] for b in column)
        col_band = (col_x0, first_y0, col_x1, page_height)
        # Collect obstacle vertical intervals that fall within [first_y0, page_height]
        # and overlap horizontally with the column.
        blocked_intervals: list[tuple[float, float]] = []
        for obs in obstacles:
            if not _has_horizontal_overlap(col_band, obs):
                continue
            obs_y0 = max(obs[1], first_y0)
            obs_y1 = min(obs[3], page_height)
            if obs_y1 > obs_y0:
                blocked_intervals.append((obs_y0, obs_y1))
        # Merge overlapping intervals to avoid double-counting
        blocked_intervals.sort()
        merged_y1 = -1.0
        for iy0, iy1 in blocked_intervals:
            if iy0 > merged_y1:
                obstacle_blocked += iy1 - iy0
                merged_y1 = iy1
            elif iy1 > merged_y1:
                obstacle_blocked += iy1 - merged_y1
                merged_y1 = iy1

    available = max(1.0, raw_available - obstacle_blocked)

    # Calculate total content height and gaps
    total_content = sum(_block_height(b) for b in column)
    min_total_gap = _MIN_GAP * max(0, len(column) - 1)

    # Phase 1: Compress gaps to minimum
    if total_content + min_total_gap <= available:
        # Just tighten gaps — redistribute evenly
        remaining = available - total_content
        gap = remaining / max(1, len(column) - 1) if len(column) > 1 else 0
        _reposition_column(column, first_y0, gap, obstacles)
        logger.debug("Compressed gaps to fit page (gap=%.1f)", gap)
        return

    # Phase 2: Must shrink content proportionally
    target_total = available - min_total_gap
    if target_total <= 0:
        logger.warning("Page has no room for content (available=%.1f)", available)
        target_total = available * 0.95

    shrink_factor = target_total / total_content if total_content > 0 else 1.0
    shrink_factor = min(1.0, shrink_factor)  # never upscale

    logger.debug(
        "Compressing column: %d blocks, shrink_factor=%.2f",
        len(column), shrink_factor,
    )

    for block in column:
        if _is_text_block(block):
            old_height = _block_height(block)
            new_height = max(1.0, old_height * shrink_factor)
            # Use a hard floor of 3pt during compression (smaller than the normal
            # min_font_size) so very crowded pages can still fit all content.
            # The user accepts small font sizes over content loss.
            compress_min_fs = min(3.0, min_font_size)
            _try_shrink_to_height(block, new_height, compress_min_fs)

    # Reposition from top with minimum gaps
    _reposition_column(column, first_y0, _MIN_GAP, obstacles)

    # Final safety clamp: if any block still exceeds page_height (e.g. text
    # too long even at min_font_size), clip y1 to page boundary so content is
    # rendered as much as possible rather than placed entirely off-page.
    for block in column:
        bbox = _get_bbox(block)
        if bbox[1] >= page_height:
            # Entire block is off-page — push it to the last visible sliver
            _set_bbox(block, (bbox[0], page_height - 1, bbox[2], page_height))
            logger.warning(
                "Block %s completely off-page (y0=%.1f); clamped to page bottom",
                block.original.type, bbox[1],
            )
        elif bbox[3] > page_height:
            _set_bbox(block, (bbox[0], bbox[1], bbox[2], page_height))
            logger.debug(
                "Block %s clamped: y1 %.1f → %.1f",
                block.original.type, bbox[3], page_height,
            )


def _reposition_column(
    column: list[TranslatedBlock],
    start_y: float,
    gap: float,
    obstacles: list[tuple[float, float, float, float]] | None = None,
) -> None:
    """Reposition all blocks in a column from start_y with given gap,
    skipping over any obstacle areas (e.g. images)."""
    current_y = start_y
    for block in column:
        bbox = _get_bbox(block)
        height = bbox[3] - bbox[1]
        # Skip past any obstacles that would intersect this block's proposed position
        new_y0, new_y1 = _skip_obstacles(current_y, current_y + height, bbox, obstacles)
        new_bbox = (bbox[0], new_y0, bbox[2], new_y1)
        _set_bbox(block, new_bbox)
        current_y = new_y1 + gap


def _ensure_page_fit_single(
    block: TranslatedBlock,
    page_height: float,
    min_font_size: float,
) -> None:
    """Ensure a single block fits within page height."""
    bbox = _get_bbox(block)
    if bbox[3] <= page_height:
        return
    overflow = bbox[3] - page_height
    if _is_text_block(block):
        target = _block_height(block) - overflow
        if target > 0:
            success = _try_shrink_to_height(block, target, min_font_size)
            if success:
                return
    # Hard clamp as last resort
    if bbox[1] < page_height:
        _set_bbox(block, (bbox[0], bbox[1], bbox[2], page_height))


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _frange(start: float, stop: float, step: float) -> list[float]:
    """Generate float range (inclusive of start, inclusive of stop if hit)."""
    result = []
    v = start
    while v >= stop:
        result.append(round(v, 1))
        v += step  # step is negative
    return result
