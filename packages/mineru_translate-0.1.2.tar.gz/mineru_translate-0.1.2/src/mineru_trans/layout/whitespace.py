"""Whitespace analysis for intelligent block expansion."""

from __future__ import annotations

from ..models import Block, Page
from ..strategy import is_container_block


def collect_page_bboxes(page: Page) -> list[tuple[float, float, float, float]]:
    """Collect bboxes of all leaf blocks on a page.

    Recursively descends into container blocks (table, image, list, code)
    to collect only leaf-level bboxes that participate in layout.
    """
    bboxes: list[tuple[float, float, float, float]] = []
    for block in page.para_blocks:
        _collect_leaf_bboxes(block, bboxes)
    for block in page.discarded_blocks:
        _collect_leaf_bboxes(block, bboxes)
    return bboxes


def _collect_leaf_bboxes(
    block: Block, out: list[tuple[float, float, float, float]]
) -> None:
    if is_container_block(block):
        # Image blocks occupy their full visual bbox — always add it so that
        # whitespace analysis treats the image area as taken space.
        if block.type == "image" and block.bbox:
            out.append(block.bbox)
        else:
            for sub in block.blocks or []:
                _collect_leaf_bboxes(sub, out)
    else:
        out.append(block.bbox)


def _has_horizontal_overlap(
    a: tuple[float, float, float, float],
    b: tuple[float, float, float, float],
) -> bool:
    """Check if two bboxes share horizontal space."""
    return a[0] < b[2] and b[0] < a[2]


def _has_vertical_overlap(
    a: tuple[float, float, float, float],
    b: tuple[float, float, float, float],
) -> bool:
    """Check if two bboxes share vertical space."""
    return a[1] < b[3] and b[1] < a[3]


# Minimum page margin to keep (points) so text doesn't touch page edge
_MIN_PAGE_MARGIN = 36.0


def compute_available_space(
    block_bbox: tuple[float, float, float, float],
    block_type: str,
    is_centered: bool,
    all_bboxes: list[tuple[float, float, float, float]],
    page_width: float,
    page_height: float,
) -> tuple[float, float, float, float]:
    """Compute the expanded bbox a block can use without overlapping neighbors.

    Expansion strategy:
    - Vertically: use up to 75% of the gap to neighbors above/below.
    - Horizontally for text/title blocks: expand toward page margins
      (up to 70% of gap to lateral neighbors, respecting a minimum page margin).
    - Horizontally for centered titles: symmetric expansion (80% of smaller gap).

    Args:
        block_bbox: The block's original (x0, y0, x1, y1).
        block_type: E.g. "text", "title".
        is_centered: Whether the block was detected as centered.
        all_bboxes: All leaf-block bboxes on the same page.
        page_width: Page width in points.
        page_height: Page height in points.

    Returns:
        Expanded bbox (x0, y0, x1, y1).
    """
    x0, y0, x1, y1 = block_bbox

    # --- Vertical expansion ---
    # Find nearest vertical neighbor above and below (among horizontally-overlapping blocks)
    nearest_above_y1 = 0.0  # page top
    nearest_below_y0 = page_height  # page bottom

    for other in all_bboxes:
        if other == block_bbox:
            continue
        if not _has_horizontal_overlap(block_bbox, other):
            continue
        # Other is above this block
        if other[3] <= y0:
            nearest_above_y1 = max(nearest_above_y1, other[3])
        # Other is below this block
        if other[1] >= y1:
            nearest_below_y0 = min(nearest_below_y0, other[1])

    gap_above = y0 - nearest_above_y1
    gap_below = nearest_below_y0 - y1

    new_y0 = y0 - gap_above * 0.75
    new_y1 = y1 + gap_below * 0.75

    # --- Horizontal expansion ---
    # Find nearest horizontal neighbors (among vertically-overlapping blocks)
    left_margin = max(_MIN_PAGE_MARGIN, 0.0)
    right_margin = page_width - max(_MIN_PAGE_MARGIN, 0.0)
    nearest_left_x1 = left_margin
    nearest_right_x0 = right_margin

    for other in all_bboxes:
        if other == block_bbox:
            continue
        if not _has_vertical_overlap(block_bbox, other):
            continue
        if other[2] <= x0:
            nearest_left_x1 = max(nearest_left_x1, other[2])
        if other[0] >= x1:
            nearest_right_x0 = min(nearest_right_x0, other[0])

    # Column peers: blocks that share horizontal space with this block.
    # The rightmost peer's x1 defines the column's natural right margin.
    # Using this ensures all blocks in the same column get the same available
    # right bound, preventing visual misalignment where some blocks extend
    # further right than others due to differing gap sizes.
    col_peers_x1 = [
        other[2] for other in all_bboxes
        if other != block_bbox and _has_horizontal_overlap(block_bbox, other)
    ]
    col_right = max([x1] + col_peers_x1)  # never shrink below own x1

    if is_centered and block_type in ("text", "title", "header", "footer", "page_number", "page_footnote"):
        # Symmetric expansion to preserve centering (applies to intentionally
        # centered blocks: titles, author lines, etc.).
        # Excluded: image_caption — sub-figure labels like "(b)" happen to be
        # centered because they're under the middle column of a figure grid,
        # but expanding them to full page width merges unrelated columns and
        # cascades into layout errors.
        gap_left = x0 - nearest_left_x1
        gap_right = nearest_right_x0 - x1
        expand = min(gap_left, gap_right) * 0.8
        if expand > 2.0:
            new_x0 = x0 - expand
            new_x1 = x1 + expand
        else:
            new_x0 = x0
            new_x1 = x1
    elif block_type in ("text", "title", "header", "footer", "page_number", "page_footnote"):
        # Left: keep percentage-of-gap expansion (anchored at block left edge in fitting)
        gap_left = x0 - nearest_left_x1
        new_x0 = x0 - gap_left * 0.7
        # Right: prefer the column's natural right boundary (max x1 of same-column
        # peers), which reflects the actual usable column width.  Only cap at
        # nearest_right_x0 when there is a *real* block to the right (not just the
        # page-margin placeholder), so titles and headers that sit at the right edge
        # of a column can expand to the full column width.
        if nearest_right_x0 < right_margin:
            # An actual block occupies space to the right — respect it.
            new_x1 = min(nearest_right_x0, col_right)
        else:
            # No actual block to the right — use col_right (column natural boundary).
            new_x1 = col_right
        new_x1 = max(new_x1, x1)  # never shrink
    else:
        new_x0 = x0
        new_x1 = x1

    return (new_x0, new_y0, new_x1, new_y1)
