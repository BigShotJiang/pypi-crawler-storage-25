"""Layout engine: fit translated text into bounding boxes with adaptive font sizing."""

from __future__ import annotations

import logging
import textwrap

from reportlab.lib.units import mm
from reportlab.pdfbase.pdfmetrics import stringWidth

from ..models import FitResult, FontInfo

logger = logging.getLogger(__name__)

# ReportLab built-in font for measurement fallback
_FALLBACK_FONT = "Helvetica"


# Cache resolved font names to avoid repeated expensive "font not registered" checks.
# stringWidth() with an unregistered font does an expensive internal lookup before
# raising KeyError (~1ms vs ~0.008ms for a registered font). We probe once and cache.
_font_name_cache: dict[str, str] = {}

# Cache single-character widths by (font, size, char).
# wrap_text_cjk measures characters one-by-one; caching avoids re-measuring the same
# char at the same size (especially useful for CJK where all chars share similar widths).
_char_width_cache: dict[tuple[str, float, str], float] = {}


def measure_text_width(text: str, font_name: str, font_size: float) -> float:
    """Measure the width of a text string in points.

    Falls back to Helvetica if the specified font is not registered.
    Single-character lookups are cached for performance.
    """
    actual = _font_name_cache.get(font_name)
    if actual is None:
        try:
            stringWidth("a", font_name, 12.0)
            actual = font_name
        except (KeyError, ValueError):
            actual = _FALLBACK_FONT
        _font_name_cache[font_name] = actual

    if len(text) == 1:
        key = (actual, font_size, text)
        w = _char_width_cache.get(key)
        if w is None:
            w = stringWidth(text, actual, font_size)
            _char_width_cache[key] = w
        return w

    return stringWidth(text, actual, font_size)


def wrap_text(
    text: str, font_name: str, font_size: float, max_width: float
) -> list[str]:
    """Wrap text to fit within max_width at the given font/size.

    Returns list of wrapped lines.
    """
    if not text.strip():
        return []

    words = text.split()
    if not words:
        return []

    lines: list[str] = []
    current_line = ""

    for word in words:
        test_line = f"{current_line} {word}".strip() if current_line else word
        width = measure_text_width(test_line, font_name, font_size)

        if width <= max_width:
            current_line = test_line
        else:
            if current_line:
                lines.append(current_line)
            # If single word exceeds width, still add it (will overflow)
            current_line = word

    if current_line:
        lines.append(current_line)

    return lines


def _is_cjk_text(text: str) -> bool:
    """Check if text is predominantly CJK (character-based wrapping needed)."""
    cjk_count = sum(1 for c in text if "\u4e00" <= c <= "\u9fff" or "\u3000" <= c <= "\u303f")
    return cjk_count > len(text) * 0.3


def wrap_text_cjk(
    text: str, font_name: str, font_size: float, max_width: float
) -> list[str]:
    """Wrap CJK text character by character to fit within max_width."""
    if not text.strip():
        return []

    lines: list[str] = []
    current_line = ""
    current_width = 0.0

    for char in text:
        char_width = measure_text_width(char, font_name, font_size)
        if current_width + char_width <= max_width:
            current_line += char
            current_width += char_width
        else:
            if current_line:
                lines.append(current_line)
            current_line = char
            current_width = char_width

    if current_line:
        lines.append(current_line)

    return lines


def smart_wrap(
    text: str, font_name: str, font_size: float, max_width: float
) -> list[str]:
    """Wrap text using appropriate strategy (word-based or CJK character-based)."""
    if _is_cjk_text(text):
        return wrap_text_cjk(text, font_name, font_size, max_width)
    return wrap_text(text, font_name, font_size, max_width)


def fit_text_in_bbox(
    text: str,
    bbox: tuple[float, float, float, float],
    font_info: FontInfo,
    min_font_size: float = 6.0,
    max_shrink_ratio: float = 0.6,
    available_bbox: tuple[float, float, float, float] | None = None,
    preferred_font_size: float | None = None,
) -> FitResult:
    """Fit translated text into a bounding box by adapting font size.

    Algorithm:
    0. (Optional) If preferred_font_size + available_bbox given, try larger font first
    1. Try original font size with text wrapping in original bbox
    2. Progressively shrink font size (step 0.5pt)
    3. If still doesn't fit at min size, try tighter leading
    4. If available_bbox is given, try fitting in the expanded space
    5. If still doesn't fit, expand bbox height (bounded by available_bbox)

    Args:
        text: The translated text to fit.
        bbox: Original bounding box (x0, y0, x1, y1).
        font_info: Font metadata.
        min_font_size: Absolute minimum font size.
        max_shrink_ratio: Max shrink ratio (e.g., 0.6 = can shrink to 60% of original).
        available_bbox: Optional expanded bbox from whitespace analysis. When
            provided, expansion is bounded by this region.
        preferred_font_size: When set (e.g. for title blocks), try this font size in
            available_bbox BEFORE the normal shrink loop. Allows headings to use
            available whitespace at a larger font than the tiny original bbox allows.

    Returns:
        FitResult with the chosen font size, wrapped lines, and adjusted bbox.
    """
    if not text.strip():
        return FitResult(
            font_size=font_info.font_size,
            leading=font_info.font_size * 1.2,
            lines=[],
            adjusted_bbox=bbox,
        )

    width = bbox[2] - bbox[0]
    height = bbox[3] - bbox[1]

    if width <= 0 or height <= 0:
        return FitResult(
            font_size=font_info.font_size,
            leading=font_info.font_size * 1.2,
            lines=[text],
            adjusted_bbox=bbox,
        )

    original_size = font_info.font_size
    # Soft floor: prefer not going below this, but will if text still doesn't fit
    soft_min = max(min_font_size, original_size * max_shrink_ratio)
    # Hard floor: absolute minimum
    hard_min = min_font_size
    font_name = font_info.font_name

    # Step 0: Preferred-font early path (e.g. for title blocks).
    # When a preferred font size and a wider available_bbox exist, try the preferred
    # size in the available space BEFORE falling into the normal shrink loop.
    # This lets headings render at a readable size instead of fitting into a tiny bbox.
    if preferred_font_size and available_bbox:
        avail_w = available_bbox[2] - available_bbox[0]
        avail_h = available_bbox[3] - available_bbox[1]
        if avail_w > width + 2.0:
            pref_start = max(preferred_font_size, hard_min)
            for try_size in _font_size_range(pref_start, hard_min):
                try_leading = try_size * 1.2
                try_lines = smart_wrap(text, font_name, try_size, avail_w)
                try_total = len(try_lines) * try_leading
                if try_total <= avail_h:
                    # Keep original left edge to preserve column alignment
                    tight = (
                        bbox[0],
                        bbox[1],
                        min(available_bbox[2], bbox[0] + avail_w),
                        bbox[1] + try_total,
                    )
                    return FitResult(
                        font_size=try_size,
                        leading=try_leading,
                        lines=try_lines,
                        adjusted_bbox=tight,
                    )

    # Quick estimate: skip font sizes that obviously can't fit multi-line text.
    # estimated_max uses area (width × height) — valid for multi-line blocks where
    # bbox height ≈ total text height.  For single-line blocks the PDF bbox height
    # is only the glyph height (no leading), so we must NOT let height cap the
    # starting font_size when the text fits in one line at original_size.
    n_chars = len(text)
    if n_chars > 0:
        estimated_max = (width * height / n_chars) ** 0.5
        capped = min(original_size, max(hard_min, round(estimated_max * 2, 1)))
        if capped < original_size and len(smart_wrap(text, font_name, original_size, width)) == 1:
            # Single-line text: height-based cap is wrong — bbox height excludes leading.
            font_size = original_size
        else:
            font_size = capped
    else:
        font_size = original_size
    while font_size >= hard_min:
        leading = font_size * 1.2
        lines = smart_wrap(text, font_name, font_size, width)
        total_height = len(lines) * leading

        if total_height <= height:
            return FitResult(
                font_size=font_size,
                leading=leading,
                lines=lines,
                adjusted_bbox=bbox,
            )
        # Single-line text: height constraint is irrelevant for font-size choice.
        # PDF bboxes often capture glyph height only (no descenders/leading).
        # Return at this font size; Step 5.5 will measure the actual height and
        # the overlap resolver will push down any blocks below if needed.
        if len(lines) == 1:
            return FitResult(
                font_size=font_size,
                leading=leading,
                lines=lines,
                adjusted_bbox=bbox,
            )
        font_size = round(font_size - 0.5, 1)

    # Step 3: At minimum font size, try tighter leading in original bbox
    font_size = hard_min
    lines = smart_wrap(text, font_name, font_size, width)

    for leading_factor in (1.1, 1.05, 1.0):
        leading = font_size * leading_factor
        total_height = len(lines) * leading
        if total_height <= height:
            return FitResult(
                font_size=font_size,
                leading=leading,
                lines=lines,
                adjusted_bbox=bbox,
            )

    # Step 4: Try fitting in available_bbox (expanded whitespace region)
    if available_bbox is not None:
        avail_width = available_bbox[2] - available_bbox[0]
        avail_height = available_bbox[3] - available_bbox[1]

        # 4a: For wider available_bbox, try original font size with wider width first
        if avail_width > width + 2.0:
            for try_size in _font_size_range(original_size, hard_min):
                try_leading = try_size * 1.2
                try_lines = smart_wrap(text, font_name, try_size, avail_width)
                try_total = len(try_lines) * try_leading
                if try_total <= avail_height:
                    # Anchor to original left edge, extend rightward.
                    # Centering via _tight_bbox can shift x0 left/right of the
                    # original column margin, causing visual misalignment with
                    # adjacent blocks that stay at the original x0.
                    tight = (
                        bbox[0],
                        bbox[1],
                        min(available_bbox[2], bbox[0] + avail_width),
                        bbox[1] + try_total,
                    )
                    return FitResult(
                        font_size=try_size,
                        leading=try_leading,
                        lines=try_lines,
                        adjusted_bbox=tight,
                    )

        # 4b: Try min font + tight leading in available height (original width)
        lines = smart_wrap(text, font_name, hard_min, width)
        for leading_factor in (1.1, 1.05, 1.0):
            leading = hard_min * leading_factor
            total_height = len(lines) * leading
            if total_height <= avail_height:
                tight = _tight_bbox_vertical(bbox, available_bbox, total_height)
                return FitResult(
                    font_size=hard_min,
                    leading=leading,
                    lines=lines,
                    adjusted_bbox=tight,
                    expanded=True,
                )

        # 4c: Try min font + tight leading with wider width
        if avail_width > width + 2.0:
            lines = smart_wrap(text, font_name, hard_min, avail_width)
            for leading_factor in (1.05, 1.0):
                leading = hard_min * leading_factor
                total_height = len(lines) * leading
                if total_height <= avail_height:
                    tight = (
                        bbox[0],
                        bbox[1],
                        min(available_bbox[2], bbox[0] + avail_width),
                        bbox[1] + total_height,
                    )
                    return FitResult(
                        font_size=hard_min,
                        leading=leading,
                        lines=lines,
                        adjusted_bbox=tight,
                        expanded=True,
                    )

        # 4d: Must expand within available_bbox bounds
        leading = hard_min * 1.05
        lines = smart_wrap(text, font_name, hard_min, max(width, avail_width))
        needed_height = len(lines) * leading
        # Clamp expansion to available_bbox
        max_y1 = available_bbox[3]
        expanded_y1 = min(bbox[1] + needed_height, max_y1)
        used_width = max(width, avail_width) if avail_width > width + 2.0 else width
        if used_width > width:
            # Anchor to original left edge, extend rightward (same as 4a/4c).
            tight_x0 = bbox[0]
            tight_x1 = min(available_bbox[2], bbox[0] + avail_width)
        else:
            tight_x0 = bbox[0]
            tight_x1 = bbox[2]
        expanded_bbox = (tight_x0, bbox[1], tight_x1, expanded_y1)

        logger.debug(
            "Expanding bbox from height %.1f to %.1f (avail=%.1f) for text: %s...",
            height,
            expanded_y1 - bbox[1],
            avail_height,
            text[:40],
        )

        return FitResult(
            font_size=hard_min,
            leading=leading,
            lines=lines,
            adjusted_bbox=expanded_bbox,
            expanded=True,
        )

    # Step 5: No available_bbox — unbounded expansion (legacy path)
    leading = font_size * 1.05
    needed_height = len(lines) * leading
    expanded_bbox = (bbox[0], bbox[1], bbox[2], bbox[1] + needed_height)

    logger.debug(
        "Expanding bbox from height %.1f to %.1f for text: %s...",
        height,
        needed_height,
        text[:40],
    )

    return FitResult(
        font_size=font_size,
        leading=leading,
        lines=lines,
        adjusted_bbox=expanded_bbox,
        expanded=True,
    )


def _font_size_range(start: float, end: float, step: float = 0.5) -> list[float]:
    """Generate font sizes from start down to end (inclusive)."""
    sizes = []
    s = start
    while s >= end:
        sizes.append(round(s, 1))
        s -= step
    return sizes


def _tight_bbox(
    original: tuple[float, float, float, float],
    available: tuple[float, float, float, float],
    used_width: float,
    used_height: float,
) -> tuple[float, float, float, float]:
    """Compute a tight bbox centered on the original, within available bounds."""
    orig_cx = (original[0] + original[2]) / 2
    x0 = max(available[0], orig_cx - used_width / 2)
    x1 = min(available[2], orig_cx + used_width / 2)
    y0 = original[1]
    y1 = y0 + used_height
    return (x0, y0, x1, y1)


def _tight_bbox_vertical(
    original: tuple[float, float, float, float],
    available: tuple[float, float, float, float],
    used_height: float,
) -> tuple[float, float, float, float]:
    """Expand bbox downward from original y0, within available bounds.

    Always anchors at the original top edge (y0) so blocks never move
    upward into image or other content areas above them.
    """
    y0 = original[1]  # anchor at original top — never move up
    y1 = y0 + used_height
    # If y1 exceeds available bottom, clamp and shift y0 up only if needed
    if y1 > available[3]:
        y1 = available[3]
        y0 = max(available[1], y1 - used_height)
    return (original[0], y0, original[2], y1)
