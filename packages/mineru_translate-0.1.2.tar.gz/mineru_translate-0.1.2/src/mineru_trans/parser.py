"""Parser for MinerU layout.json files."""

from __future__ import annotations

import json
import logging
from pathlib import Path

from .models import Block, LayoutDocument, Line, Page, Span

logger = logging.getLogger(__name__)


def parse(layout_path: str | Path) -> LayoutDocument:
    """Parse a MinerU layout.json file into a LayoutDocument model.

    Args:
        layout_path: Path to the layout.json file.

    Returns:
        Parsed LayoutDocument.
    """
    layout_path = Path(layout_path)
    if not layout_path.exists():
        raise FileNotFoundError(f"Layout file not found: {layout_path}")

    with open(layout_path, encoding="utf-8") as f:
        raw = json.load(f)

    doc = LayoutDocument.model_validate(raw)

    page_count = len(doc.pdf_info)
    block_count = sum(len(p.para_blocks) for p in doc.pdf_info)
    discarded_count = sum(len(p.discarded_blocks) for p in doc.pdf_info)
    logger.info(
        "Parsed layout.json: %d pages, %d para_blocks, %d discarded_blocks, backend=%s",
        page_count,
        block_count,
        discarded_count,
        doc.backend,
    )

    return doc


def get_block_stats(doc: LayoutDocument) -> dict[str, int]:
    """Count block types across the entire document. Useful for debugging."""
    stats: dict[str, int] = {}

    def count_block(block: Block) -> None:
        key = block.type
        if block.sub_type:
            key = f"{block.type}({block.sub_type})"
        stats[key] = stats.get(key, 0) + 1
        if block.blocks:
            for sub in block.blocks:
                count_block(sub)

    for page in doc.pdf_info:
        for block in page.para_blocks:
            count_block(block)
        for block in page.discarded_blocks:
            count_block(block)

    return dict(sorted(stats.items(), key=lambda x: -x[1]))


def get_span_stats(doc: LayoutDocument) -> dict[str, int]:
    """Count span types across the entire document."""
    stats: dict[str, int] = {}

    def walk_block(block: Block) -> None:
        if block.lines:
            for line in block.lines:
                for span in line.spans:
                    stats[span.type] = stats.get(span.type, 0) + 1
        if block.blocks:
            for sub in block.blocks:
                walk_block(sub)

    for page in doc.pdf_info:
        for block in page.para_blocks:
            walk_block(block)
        for block in page.discarded_blocks:
            walk_block(block)

    return dict(sorted(stats.items(), key=lambda x: -x[1]))
