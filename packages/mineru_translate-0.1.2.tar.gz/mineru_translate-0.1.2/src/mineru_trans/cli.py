"""CLI entry point for mineru-trans."""
from __future__ import annotations

import logging
import os
import re
from pathlib import Path

import click


# Default settings per provider
_PROVIDER_DEFAULTS: dict[str, dict] = {
    "openai": {
        "model": "gpt-4o-mini",
        "base_url": None,
        "envvar": "OPENAI_API_KEY",
    },
    "anthropic": {
        "model": "claude-haiku-4-5-20251001",
        "base_url": None,
        "envvar": "ANTHROPIC_API_KEY",
    },
    "deepl": {
        "model": None,
        "base_url": None,
        "envvar": "DEEPL_API_KEY",
    },
}

# BCP 47-style language code pattern: e.g. "en", "zh", "zh-hans", "zh-CN"
_LANG_RE = re.compile(r"^[a-zA-Z]{2,8}(-[a-zA-Z0-9]{2,8})*$")

# Known valid language codes (ISO 639-1 + common BCP 47 variants).
# LLM providers accept any language name, but we validate against this set
# to catch obvious typos (e.g. "ch" instead of "zh").
_KNOWN_LANGS: set[str] = {
    # ISO 639-1 two-letter codes
    "af", "ar", "bg", "bn", "ca", "cs", "cy", "da", "de", "el",
    "en", "eo", "es", "et", "fa", "fi", "fr", "ga", "gl", "gu",
    "he", "hi", "hr", "hu", "hy", "id", "is", "it", "ja", "ka",
    "kn", "ko", "lt", "lv", "mk", "ml", "mr", "ms", "mt", "nl",
    "no", "pl", "pt", "ro", "ru", "sk", "sl", "sq", "sr", "sv",
    "sw", "ta", "te", "th", "tr", "uk", "ur", "vi", "zh",
    # Common BCP 47 variants
    "zh-hans", "zh-hant", "zh-cn", "zh-tw", "zh-hk",
    "en-us", "en-gb", "en-au", "en-ca",
    "pt-br", "pt-pt",
    "es-es", "es-mx", "es-419",
    "fr-fr", "fr-ca",
    "de-de", "de-at", "de-ch",
    "nb", "nn",  # Norwegian Bokmål / Nynorsk
}


def _validate_lang(code: str, param_name: str, allow_auto: bool = False) -> None:
    """Raise UsageError if code is not a valid language code."""
    if code.lower() == "auto":
        if allow_auto:
            return
        raise click.UsageError(
            f'{param_name} language cannot be "auto"; specify a target language such as "zh" or "en".'
        )
    if not _LANG_RE.match(code):
        hint = ' (or "auto")' if allow_auto else ""
        raise click.UsageError(
            f"Invalid {param_name} language code {code!r}. "
            f"Expected a BCP 47 code such as 'en', 'zh', 'zh-hans'{hint}."
        )
    if code.lower() not in _KNOWN_LANGS:
        raise click.UsageError(
            f"Unknown {param_name} language code {code!r}. "
            f"Common codes: en, zh, zh-hans, zh-hant, ja, ko, de, fr, es, ru, ar, pt, pt-br. "
            f"Use --source auto to skip source-language detection."
            if allow_auto else
            f"Unknown {param_name} language code {code!r}. "
            f"Common codes: en, zh, zh-hans, zh-hant, ja, ko, de, fr, es, ru, ar, pt, pt-br."
        )


def _setup_logging(verbose: bool, debug: bool) -> None:
    if debug:
        level = logging.DEBUG
    elif verbose:
        level = logging.INFO
    else:
        level = logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


@click.command("mineru-translate")
@click.argument("pdf",         type=click.Path(exists=True))
@click.option("-l", "--layout", "layout_json_opt", default=None,
              type=click.Path(exists=True),
              help="Path to MinerU layout.json (alternative to positional argument).")
@click.option("-o", "--output",      "output",      default=None,                                help="Output directory or file path (default: same directory as input PDF).")
@click.option("-f", "--format",      "fmt",         default="pdf", show_default=True,
              type=click.Choice(["pdf", "md"], case_sensitive=False),
              help="Output format: pdf or md.")
@click.option("-s", "--source",      "source_lang", default="auto",  show_default=True,          help="Source language code (e.g. en, auto).")
@click.option("-t", "--target",      "target_lang", default="zh",    show_default=True,          help="Target language code (e.g. zh, en).")
@click.option("-p", "--provider",    "provider",    default="openai", show_default=True,
              type=click.Choice(["openai", "anthropic", "deepl"], case_sensitive=False),
              help="Translation provider.")
@click.option("-m", "--model",       "model",       default=None,  help="Model name (provider default if omitted).")
@click.option("-k", "--api-key",     "api_key",     default=None,  help="API key (or OPENAI_API_KEY / ANTHROPIC_API_KEY / DEEPL_API_KEY env var).")
@click.option("--base-url",          "base_url",    default=None,  help="Custom base URL for OpenAI-compatible endpoints.")
@click.option("-c", "--concurrency", "concurrency", default=8,     show_default=True, type=int,  help="Concurrent translation requests.")
@click.option("--mineru-token",      "mineru_key",  default=None,  envvar="MINERU_TOKEN",        help="MinerU API token (required when layout.json is not provided).")
@click.option("--keep-cache",        "keep_cache",  is_flag=True,  default=False,                help="Keep translation cache and parsed directory after translation (useful for debugging).")
@click.option("--md-mode",           "md_mode",     default="translated", show_default=True,
              type=click.Choice(["translated", "bilingual"], case_sensitive=False),
              help="Markdown export mode: translated (translation only) or bilingual (original + translation).")
@click.option("-v", "--verbose",     "verbose",     is_flag=True,  default=False,                help="Verbose logging (use -vv / --debug for debug level).")
@click.option("-d", "--debug",       "debug",       is_flag=True,  default=False,                help="Debug mode: extra logging.")
def main(
    pdf: str,
    layout_json_opt: str | None,
    output: str | None,
    fmt: str,
    source_lang: str,
    target_lang: str,
    provider: str,
    model: str | None,
    api_key: str | None,
    base_url: str | None,
    concurrency: int,
    mineru_key: str | None,
    keep_cache: bool,
    md_mode: str,
    debug: bool,
    verbose: bool,
) -> None:
    """Translate a PDF to another language, preserving layout."""
    _setup_logging(verbose, debug)

    pdf_path = Path(pdf)
    provider = provider.lower()

    # ── Parameter validation ──────────────────────────────────────────────
    effective_layout = layout_json_opt
    if effective_layout and not effective_layout.lower().endswith(".json"):
        raise click.UsageError(
            f"Layout file {effective_layout!r} does not appear to be a JSON file (.json expected)."
        )

    _validate_lang(source_lang, "--source", allow_auto=True)
    _validate_lang(target_lang, "--target", allow_auto=False)

    if concurrency < 1:
        raise click.UsageError("--concurrency must be at least 1.")

    if not pdf_path.suffix.lower() == ".pdf":
        raise click.UsageError(f"Input file {pdf!r} does not appear to be a PDF.")

    # ── base-url: strip trailing endpoint path added by mistake ──────────
    if base_url:
        for _suffix in ("/chat/completions", "/completions"):
            if base_url.rstrip("/").endswith(_suffix):
                base_url = base_url.rstrip("/")[: -len(_suffix)]
                click.echo(f"Note: --base-url trimmed to {base_url!r}")
                break

    # ── API key / model early validation ──────────────────────────────────
    resolved_api_key = api_key or os.environ.get(_PROVIDER_DEFAULTS[provider]["envvar"])
    if not resolved_api_key:
        envvar = _PROVIDER_DEFAULTS[provider]["envvar"]
        raise click.UsageError(
            f"API key required for --provider {provider}. "
            f"Use --api-key or set the {envvar} environment variable."
        )
    if provider == "openai" and not (model or _PROVIDER_DEFAULTS[provider]["model"]):
        raise click.UsageError("--model is required for provider 'openai'.")

    if output and not Path(output).is_dir():
        out_parent = Path(output).parent
        if not out_parent.exists():
            out_parent.mkdir(parents=True, exist_ok=True)

    # ── Output path ──────────────────────────────────────────────────────
    # If -o is a file path with a known extension, infer format from it.
    if output and not Path(output).is_dir():
        out_ext = Path(output).suffix.lower()
        if out_ext == ".md":
            fmt = "md"
        elif out_ext == ".pdf":
            fmt = "pdf"

    stem = f"{pdf_path.stem}_translated"
    ext = ".md" if fmt == "md" else ".pdf"
    if output:
        p = Path(output)
        out_path = (p / f"{stem}{ext}") if p.is_dir() else p
    else:
        out_path = pdf_path.parent / f"{stem}{ext}"

    if fmt == "md":
        md_output: str | None = str(out_path)
        output_path = None
    else:
        md_output = None
        output_path = out_path

    # ── Layout JSON ──────────────────────────────────────────────────────
    # Determine the output directory for parsed results.
    # If -o is given, use its directory; otherwise default to PDF's directory.
    if output:
        out_dir = Path(output) if Path(output).is_dir() else Path(output).parent
    else:
        out_dir = pdf_path.parent

    parse_dir: Path | None = None
    if effective_layout:
        layout_path = Path(effective_layout)
    else:
        if not mineru_key:
            raise click.UsageError(
                "MinerU API key is required when layout.json argument is not provided.\n"
                "Use --mineru-token <token> or set the MINERU_TOKEN environment variable."
            )
        from mineru_trans.mineru_parser import parse_pdf_with_mineru
        parse_dir = out_dir / f"{pdf_path.stem}_parsed"
        click.echo(f"Parsing {pdf_path.name} with MinerU...")
        layout_path = parse_pdf_with_mineru(
            pdf_path=pdf_path,
            output_dir=parse_dir,
            token=mineru_key,
        )
        click.echo(f"Parsed: {layout_path}")

    # ── Cache file: next to the output PDF (or source PDF if no PDF output) ──
    cache_stem = output_path.stem if output_path else f"{pdf_path.stem}_translated"
    cache_file = (output_path.parent if output_path else pdf_path.parent) / f"{cache_stem}_cache.json"

    # ── API key fallback from env var ─────────────────────────────────────
    api_key = resolved_api_key

    # ── Translation engine ────────────────────────────────────────────────
    engine, engine_name = _create_engine(
        provider=provider,
        api_key=api_key,
        model=model,
        base_url=base_url,
    )

    # ── Run pipeline ──────────────────────────────────────────────────────
    from mineru_trans.pipeline import translate_document

    try:
        translate_document(
            layout_path=layout_path,
            output_path=output_path,
            target_lang=target_lang,
            engine=engine,
            source_lang=source_lang,
            source_pdf_path=str(pdf_path),
            cache_dir=str(cache_file),
            engine_name=engine_name,
            concurrency=concurrency,
            md_output=md_output,
            md_mode=md_mode,
            progress=None if (verbose or debug) else click.echo,
        )
    except Exception as exc:
        if verbose or debug:
            logging.getLogger(__name__).exception("Translation failed")
        raise click.ClickException(str(exc)) from exc

    if output_path:
        click.echo(f"Done: {output_path}")
    if md_output:
        click.echo(f"Markdown: {md_output}")
    if cache_file.exists():
        if keep_cache:
            click.echo(f"Cache kept: {cache_file}")
        else:
            cache_file.unlink()
            click.echo(f"Cache deleted: {cache_file}")
    if parse_dir and parse_dir.exists():
        if keep_cache:
            click.echo(f"Parsed dir kept: {parse_dir}")
        else:
            import shutil
            shutil.rmtree(parse_dir)
            click.echo(f"Parsed dir deleted: {parse_dir}")


def _create_engine(
    provider: str,
    api_key: str | None,
    model: str | None,
    base_url: str | None,
):
    """Instantiate translation engine. Returns (engine, engine_name)."""
    defaults = _PROVIDER_DEFAULTS[provider]
    resolved_model = model or defaults["model"]
    resolved_base_url = base_url or defaults["base_url"]

    if provider == "deepl":
        if not api_key:
            raise click.UsageError(
                "DeepL API key required. Use --api-key or set DEEPL_API_KEY."
            )
        from mineru_trans.translation.deepl_engine import DeepLEngine
        return DeepLEngine(api_key), "deepl"

    if provider == "anthropic":
        if not api_key:
            raise click.UsageError(
                "API key required for anthropic. Use --api-key or set ANTHROPIC_API_KEY."
            )
        resolved_model = model or defaults["model"]
        from mineru_trans.translation.anthropic_engine import AnthropicEngine
        return AnthropicEngine(api_key=api_key, model=resolved_model), "anthropic"

    # openai → LLMEngine (OpenAI-compatible)
    if not api_key:
        raise click.UsageError(
            f"API key required for {provider}. "
            f"Use --api-key or set {defaults['envvar']}."
        )
    if not resolved_model:
        raise click.UsageError(f"-model required for provider '{provider}'.")

    from mineru_trans.translation.llm_engine import LLMEngine
    return LLMEngine(
        api_key=api_key,
        base_url=resolved_base_url,
        model=resolved_model,
    ), provider


if __name__ == "__main__":
    main()
