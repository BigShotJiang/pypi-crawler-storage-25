"""Parse PDFs using MinerU API (mineru-open-sdk)."""

from __future__ import annotations

import io
import json
import logging
import zipfile
from pathlib import Path

logger = logging.getLogger(__name__)


def parse_pdf_with_mineru(
    pdf_path: str | Path,
    output_dir: str | Path,
    token: str,
    model: str = "vlm",
    ocr: bool = True,
    timeout: int = 600,
) -> Path:
    """Parse a PDF via MinerU API and extract layout.json + images.

    Args:
        pdf_path: Path to the source PDF file.
        output_dir: Directory to save parsed output (layout.json, images/).
        token: MinerU API token.
        model: Parsing model — ``"vlm"`` (precise) or ``"pipeline"``.
        ocr: Enable OCR for scanned pages.
        timeout: Max seconds to wait for parsing to complete.

    Returns:
        Path to the extracted ``layout.json`` file.

    Raises:
        RuntimeError: If parsing fails or layout.json is not found.
    """
    from mineru import MinerU

    pdf_path = Path(pdf_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    logger.info("Parsing %s with MinerU (model=%s, ocr=%s)...", pdf_path.name, model, ocr)

    with MinerU(token=token) as client:
        result = client.extract(
            str(pdf_path),
            model=model,
            ocr=ocr,
            timeout=timeout,
            formula=False,
        )

    if result.state != "done":
        raise RuntimeError(
            f"MinerU parsing failed: state={result.state}, "
            f"error={result.error or 'unknown'}"
        )

    # Extract layout.json and images from the zip
    if result._zip_bytes is None:
        raise RuntimeError("MinerU returned no zip data")

    layout_path: Path | None = None
    with zipfile.ZipFile(io.BytesIO(result._zip_bytes)) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            name = info.filename
            # Extract layout.json
            if name == "layout.json" or name.endswith("/layout.json"):
                data = zf.read(name)
                dest = output_dir / "layout.json"
                dest.write_bytes(data)
                layout_path = dest
                logger.info("Extracted layout.json (%d bytes)", len(data))
            # Extract images
            elif name.startswith("images/") or "/images/" in name:
                data = zf.read(name)
                # Preserve just the filename under images/
                img_name = Path(name).name
                img_dir = output_dir / "images"
                img_dir.mkdir(exist_ok=True)
                (img_dir / img_name).write_bytes(data)

    if layout_path is None:
        raise RuntimeError("layout.json not found in MinerU output")

    # Count extracted images
    img_dir = output_dir / "images"
    img_count = len(list(img_dir.glob("*"))) if img_dir.exists() else 0
    logger.info(
        "MinerU parsing complete: layout.json + %d images in %s",
        img_count,
        output_dir,
    )

    return layout_path
