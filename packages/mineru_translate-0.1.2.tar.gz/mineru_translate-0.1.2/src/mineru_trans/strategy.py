"""Translation strategy: determine which blocks/spans to translate."""

from __future__ import annotations

from .models import Block, Span, TranslateDecision

# Block types that should be translated (leaf blocks with text content)
_TRANSLATE_BLOCK_TYPES = {"text", "title", "index"}

# Block types that should never be translated
_PRESERVE_BLOCK_TYPES = {"interline_equation"}

# Container block types that have mixed children
_CONTAINER_BLOCK_TYPES = {"table", "image", "list", "code"}

# Sub-block types within containers that should be translated
_TRANSLATE_SUB_TYPES = {"table_caption", "table_footnote", "image_caption", "image_footnote"}

# Sub-block types within containers that should NOT be translated
_PRESERVE_SUB_TYPES = {"image_body", "code_body"}

# Discarded block types — translate all of them
_DISCARDED_TYPES = {"header", "footer", "page_number", "page_footnote"}


def classify_block(block: Block) -> TranslateDecision:
    """Determine translation decision for a top-level or sub-level block.

    For container blocks (table, image, list, code), this returns the decision
    for the container itself. Individual sub-blocks should be classified separately.
    """
    block_type = block.type

    # Direct translate types
    if block_type in _TRANSLATE_BLOCK_TYPES:
        return TranslateDecision.TRANSLATE

    # Direct preserve types
    if block_type in _PRESERVE_BLOCK_TYPES:
        return TranslateDecision.PRESERVE

    # Discarded block types — translate
    if block_type in _DISCARDED_TYPES:
        return TranslateDecision.TRANSLATE

    # List blocks: depends on sub_type
    if block_type == "list":
        if block.sub_type == "ref_text":
            return TranslateDecision.PRESERVE
        return TranslateDecision.TRANSLATE

    # ref_text as a standalone type (L2 block inside list)
    if block_type == "ref_text":
        return TranslateDecision.PRESERVE

    # Container blocks: need per-child classification
    if block_type in _CONTAINER_BLOCK_TYPES:
        return TranslateDecision.TRANSLATE  # container itself, children vary

    # Sub-block types within containers
    if block_type in _TRANSLATE_SUB_TYPES:
        return TranslateDecision.TRANSLATE

    if block_type in _PRESERVE_SUB_TYPES:
        return TranslateDecision.PRESERVE

    # table_body: translate (HTML content)
    if block_type == "table_body":
        return TranslateDecision.TRANSLATE

    # Code blocks
    if block_type == "code":
        if block.sub_type in ("code", "algorithm"):
            return TranslateDecision.PRESERVE
        return TranslateDecision.PRESERVE

    # Unknown type — preserve by default
    return TranslateDecision.PRESERVE


def classify_span(span: Span) -> TranslateDecision:
    """Determine translation decision for a span."""
    if span.type == "text":
        return TranslateDecision.TRANSLATE
    if span.type == "table":
        return TranslateDecision.TRANSLATE
    # inline_equation, interline_equation, image — preserve
    return TranslateDecision.PRESERVE


def should_translate_block(block: Block) -> bool:
    """Convenience: returns True if block should be translated."""
    return classify_block(block) == TranslateDecision.TRANSLATE


def is_container_block(block: Block) -> bool:
    """Check if block is a container with sub-blocks."""
    return block.blocks is not None and len(block.blocks) > 0
