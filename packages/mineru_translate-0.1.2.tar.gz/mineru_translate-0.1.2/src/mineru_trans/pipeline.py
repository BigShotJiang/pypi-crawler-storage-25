"""Main pipeline: orchestrates the full translation workflow."""

from __future__ import annotations

import logging
from collections.abc import Callable
from pathlib import Path

from .font.extractor import ExtractedFontSpan, extract_fonts_from_pdf, is_scanned_page
from .font.fallback import estimate_font_info
from .font.matcher import match_font_to_block
from .layout.engine import fit_text_in_bbox
from .layout.overlap import resolve_overlaps
from .layout.whitespace import collect_page_bboxes, compute_available_space
from .models import (
    Block,
    FontInfo,
    LayoutDocument,
    Page,
    TranslatedBlock,
    TranslateDecision,
)
from .parser import parse
from .render.image_loader import ImageLoader
from .render.pdf_renderer import PDFRenderer
from .strategy import classify_block, is_container_block
from .translation.base import TranslationEngine
from .translation.batcher import (
    TranslationUnit,
    collect_translation_units,
    translate_units,
)

logger = logging.getLogger(__name__)


def translate_document(
    layout_path: str | Path,
    output_path: str | Path | None,
    target_lang: str,
    engine: TranslationEngine,
    source_lang: str = "auto",
    glossary: dict[str, str] | None = None,
    source_pdf_path: str | Path | None = None,
    min_font_size: float = 6.0,
    max_shrink_ratio: float = 0.6,
    cache_dir: str | Path | None = None,
    engine_name: str = "deepl",
    concurrency: int = 1,
    md_output: str | Path | None = None,
    md_mode: str = "translated",
    progress: Callable[[str], None] | None = None,
) -> None:
    """Execute the full translation pipeline.

    Args:
        layout_path: Path to MinerU layout.json.
        output_path: Output PDF path. If None, PDF rendering is skipped.
        target_lang: Target language code.
        engine: Translation engine instance.
        source_lang: Source language code (default: auto-detect).
        glossary: Optional terminology dict.
        source_pdf_path: Optional source PDF for font extraction.
        min_font_size: Minimum allowed font size.
        max_shrink_ratio: Max font shrink ratio.
        cache_dir: Optional directory for translation cache.
        engine_name: Engine name used as part of the cache key.
        concurrency: Number of concurrent API requests (default: 1).
        md_output: Optional path for markdown export.
        md_mode: Markdown export mode: "translated" or "bilingual".
    """
    layout_path = Path(layout_path)
    output_path = Path(output_path) if output_path is not None else None

    # Step 1: Parse layout.json
    logger.info("Step 1: Parsing layout.json...")
    if progress: progress("Parsing layout...")
    doc = parse(layout_path)
    logger.info("Parsed %d pages", len(doc.pdf_info))

    # Step 2: Extract fonts from source PDF (optional)
    logger.info("Step 2: Extracting fonts...")
    font_pages: list[list[ExtractedFontSpan]] | None = None
    if source_pdf_path:
        font_pages = extract_fonts_from_pdf(source_pdf_path)

    # Step 3: Collect translation units
    logger.info("Step 3: Collecting translation units...")
    units = collect_translation_units(doc)
    logger.info("Collected %d translation units", len(units))

    # Step 4: Translate
    logger.info("Step 4: Translating...")
    if progress: progress(f"Translating {len(units)} blocks...")
    cache = None
    if cache_dir is not None:
        from .translation.cache import TranslationCache
        cache = TranslationCache(Path(cache_dir), engine_name)
    try:
        translate_units(units, engine, source_lang, target_lang, glossary, cache=cache, concurrency=concurrency)
    finally:
        if cache is not None:
            cache.close()

    # Step 5: Build translated blocks with font info and layout fitting
    logger.info("Step 5: Building translated blocks...")
    # Register fonts before layout fitting so character width measurements use
    # the actual CJK font metrics (not the Helvetica fallback).
    from .render.pdf_renderer import _init_fonts as _register_fonts
    from .layout.engine import _font_name_cache, _char_width_cache
    _register_fonts()
    _font_name_cache.clear()  # discard any stale Helvetica fallbacks
    _char_width_cache.clear()
    translated_blocks: dict[tuple[int, ...], TranslatedBlock] = {}

    # Index units by (page_idx, *block_path)
    unit_map: dict[tuple[int, ...], TranslationUnit] = {}
    for unit in units:
        key = (unit.page_idx, *unit.block_path)
        unit_map[key] = unit

    for page in doc.pdf_info:
        page_idx = page.page_idx
        page_font_spans = (
            font_pages[page_idx]
            if font_pages and page_idx < len(font_pages)
            else []
        )
        is_scanned = (
            is_scanned_page(page_font_spans, len(page.para_blocks))
            if page_font_spans is not None
            else True
        )

        # Collect all leaf block bboxes for whitespace analysis
        all_page_bboxes = collect_page_bboxes(page)

        # Compute page-level font estimation context from true single-line
        # blocks (h ≤ 20).  Their median height is the reference line height
        # used to estimate n_lines in VLM-packed tall blocks.
        single_h = [
            b.bbox[3] - b.bbox[1]
            for b in page.para_blocks
            if b.bbox and (b.bbox[3] - b.bbox[1]) <= 20
        ]
        ref_line_height = (
            sorted(single_h)[len(single_h) // 2] if single_h else 15.0
        )

        # Compute column left margins from VLM-packed tall blocks (h > 20).
        # Each distinct x0 represents a column's left edge; used to detect
        # and correct first-line indent in true single-line blocks.
        column_margins = sorted({
            b.bbox[0]
            for b in page.para_blocks
            if b.bbox and (b.bbox[3] - b.bbox[1]) > 20
        })

        # Process para_blocks
        for block_idx, block in enumerate(page.para_blocks):
            _build_translated_block(
                block, page_idx, (block_idx,),
                unit_map, translated_blocks,
                page_font_spans if not is_scanned else [],
                target_lang, min_font_size, max_shrink_ratio,
                page_width=page.page_size[0],
                page_height=page.page_size[1],
                all_page_bboxes=all_page_bboxes,
                ref_line_height=ref_line_height,
                column_margins=column_margins,
            )

        # Process discarded_blocks
        for block_idx, block in enumerate(page.discarded_blocks):
            _build_translated_block(
                block, page_idx, (-1, block_idx),
                unit_map, translated_blocks,
                page_font_spans if not is_scanned else [],
                target_lang, min_font_size, max_shrink_ratio,
                page_width=page.page_size[0],
                page_height=page.page_size[1],
                all_page_bboxes=all_page_bboxes,
                ref_line_height=ref_line_height,
                column_margins=column_margins,
            )

    # Steps 5.5 + 6 run iteratively until paragraph heights stabilise.
    # Rationale: smart_wrap() (used in layout engine and overlap resolver) gives
    # different line-break metrics than ReportLab's Paragraph.  After correcting
    # heights in step 5.5 the overlap resolver may call _try_shrink_to_height
    # (which also uses smart_wrap) and introduce new height errors.  Iterating
    # until no corrections are needed guarantees the rendered PDF is free of
    # overlaps and content truncation.
    from .render.pdf_renderer import measure_translated_height
    from .models import FitResult

    _MAX_ITER = 12
    for _iter in range(_MAX_ITER):
        # Step 5.5: correct adjusted_bbox heights with actual ReportLab metrics
        logger.info("Step 5.5 (iter %d): Correcting paragraph heights with ReportLab metrics...", _iter + 1)
        height_corrections = 0
        for key, tb in translated_blocks.items():
            if not tb.translated_text or not tb.fit_result:
                continue
            if tb.original.angle in (90, 270):
                continue  # rotated blocks use different geometry
            actual_h = measure_translated_height(tb)
            if actual_h <= 0:
                continue
            fit = tb.fit_result
            bbox = fit.adjusted_bbox
            current_h = bbox[3] - bbox[1]
            if actual_h > current_h + 0.5:
                # Cap correction at available page space to avoid off-page expansion
                # that would just oscillate with the compressor next iteration.
                page_obj = next(
                    (p for p in doc.pdf_info if p.page_idx == key[0]), None
                )
                max_h = (page_obj.page_size[1] - bbox[1]) if page_obj else actual_h
                corrected_h = min(actual_h, max_h)
                if corrected_h <= current_h + 0.5:
                    continue
                new_bbox = (bbox[0], bbox[1], bbox[2], bbox[1] + corrected_h)
                tb.fit_result = FitResult(
                    font_size=fit.font_size,
                    leading=fit.leading,
                    lines=fit.lines,
                    adjusted_bbox=new_bbox,
                    expanded=False,  # Fixed height: resolver must push others, not shrink this
                )
                height_corrections += 1
                logger.debug(
                    "Height correction for %s: fitted=%.1f → actual=%.1f",
                    key, current_h, actual_h,
                )
        logger.info("Step 5.5 (iter %d): Corrected %d block heights", _iter + 1, height_corrections)

        # Step 6: Resolve overlaps per page
        logger.info("Step 6 (iter %d): Resolving overlaps...", _iter + 1)
        for page in doc.pdf_info:
            # Separate regular blocks from discarded blocks (key[1] == -1).
            # Discarded blocks often span the full page width and would merge
            # left/right columns into one, causing _compress_column to push
            # blocks off-page.  Treat them as obstacles instead.
            all_regular = [
                tb for key, tb in translated_blocks.items()
                if key[0] == page.page_idx and tb.fit_result is not None
                and (len(key) < 2 or key[1] != -1)
            ]
            discarded_tbs = [
                tb for key, tb in translated_blocks.items()
                if key[0] == page.page_idx and tb.fit_result is not None
                and len(key) >= 2 and key[1] == -1
            ]
            image_obstacles = _collect_image_obstacles(page)
            # Resolve horizontal overlaps among discarded blocks (headers/footers)
            # before using their bboxes as obstacles for regular blocks.
            _resolve_discarded_horiz_overlaps(discarded_tbs, min_font_size)
            discarded_obstacles = [tb.fit_result.adjusted_bbox for tb in discarded_tbs]
            base_obstacles = image_obstacles + discarded_obstacles

            # Separate image_caption blocks from text/title blocks.
            # Full-width captions span both left and right columns; if they
            # participate in the same resolution pass as text blocks they act
            # as a "bridge" that merges both columns into one, causing the
            # single-pass resolver to miss overlaps between the caption and
            # the column that isn't immediately adjacent in the sorted order.
            # Fix: resolve captions first (among themselves), then treat the
            # resolved caption bboxes as obstacles for the text block pass.
            caption_blocks = [
                tb for tb in all_regular
                if tb.original.type == "image_caption"
            ]
            regular_blocks = [
                tb for tb in all_regular
                if tb.original.type != "image_caption"
            ]

            if caption_blocks:
                resolve_overlaps(
                    caption_blocks, page.page_size[1], min_font_size, max_shrink_ratio,
                    obstacles=base_obstacles,
                )

            caption_obstacles = [
                tb.fit_result.adjusted_bbox
                for tb in caption_blocks
                if tb.fit_result is not None
            ]
            resolve_overlaps(
                regular_blocks, page.page_size[1], min_font_size, max_shrink_ratio,
                obstacles=base_obstacles + caption_obstacles,
            )

        if height_corrections == 0:
            logger.info("Steps 5.5+6: Converged after %d iteration(s)", _iter + 1)
            break
    else:
        logger.warning("Steps 5.5+6: Did not fully converge after %d iterations", _MAX_ITER)

    # Post-loop safety clamp: hard-clamp any block that still exceeds page height.
    # _compress_column's internal clamp can miss blocks when discarded blocks with wide
    # x-spans merge left/right columns, corrupting first_y0 and reposition math.
    # This pass guarantees no block renders off-page regardless of column grouping.
    from .models import FitResult as _FitResultClamp
    for page in doc.pdf_info:
        ph = page.page_size[1]
        for key, tb in translated_blocks.items():
            if key[0] != page.page_idx or not tb.fit_result:
                continue
            bbox = tb.fit_result.adjusted_bbox
            if bbox[3] > ph and bbox[1] < ph:
                tb.fit_result = _FitResultClamp(
                    font_size=tb.fit_result.font_size,
                    leading=tb.fit_result.leading,
                    lines=tb.fit_result.lines,
                    adjusted_bbox=(bbox[0], bbox[1], bbox[2], ph),
                    expanded=tb.fit_result.expanded,
                )
                logger.debug(
                    "Post-loop clamp: block %s y1 %.1f → %.1f",
                    key, bbox[3], ph,
                )
            elif bbox[1] >= ph:
                # Entire block is off-page — push to last visible sliver
                tb.fit_result = _FitResultClamp(
                    font_size=tb.fit_result.font_size,
                    leading=tb.fit_result.leading,
                    lines=tb.fit_result.lines,
                    adjusted_bbox=(bbox[0], ph - 1, bbox[2], ph),
                    expanded=tb.fit_result.expanded,
                )
                logger.warning(
                    "Post-loop clamp: block %s completely off-page (y0=%.1f); clamped",
                    key, bbox[1],
                )

    # Step 6.5: Export markdown (if requested)
    if md_output:
        logger.info("Step 6.5: Exporting markdown (%s)...", md_mode)
        from .render.markdown_exporter import export_markdown
        export_markdown(doc, translated_blocks, Path(md_output), mode=md_mode,
                        base_dir=layout_path.parent)
        logger.info("Markdown exported: %s", md_output)

    # Step 7: Render PDF
    if output_path is not None:
        logger.info("Step 7: Rendering PDF...")
        if progress: progress("Rendering PDF...")
        base_dir = layout_path.parent
        image_loader = ImageLoader(base_dir)
        cache_dir = base_dir / ".mineru_trans_cache"
        from .render.formula_renderer import FormulaRenderer
        formula_renderer = FormulaRenderer(cache_dir)
        renderer = PDFRenderer(image_loader, formula_renderer=formula_renderer)
        renderer.render(doc, translated_blocks, output_path)
    else:
        logger.info("Step 7: Skipped (no PDF output requested)")

    # Step 8: Validate
    logger.info("Step 8: Validating...")
    _validate_translation(doc, translated_blocks)

    if output_path:
        logger.info("Translation complete: %s", output_path)
    if md_output:
        logger.info("Markdown complete: %s", md_output)


def _build_translated_block(
    block: Block,
    page_idx: int,
    block_path: tuple[int, ...],
    unit_map: dict[tuple[int, ...], TranslationUnit],
    translated_blocks: dict[tuple[int, ...], TranslatedBlock],
    font_spans: list[ExtractedFontSpan],
    target_lang: str,
    min_font_size: float,
    max_shrink_ratio: float,
    page_width: float = 544.0,
    page_height: float = 792.0,
    all_page_bboxes: list[tuple[float, float, float, float]] | None = None,
    ref_line_height: float = 15.0,
    column_margins: list[float] | None = None,
) -> None:
    """Build a TranslatedBlock with font info and layout fitting."""
    key = (page_idx, *block_path)

    # Recurse into container blocks
    if is_container_block(block):
        for sub_idx, sub_block in enumerate(block.blocks or []):
            _build_translated_block(
                sub_block, page_idx, block_path + (sub_idx,),
                unit_map, translated_blocks, font_spans,
                target_lang, min_font_size, max_shrink_ratio,
                page_width=page_width,
                page_height=page_height,
                all_page_bboxes=all_page_bboxes,
                ref_line_height=ref_line_height,
                column_margins=column_margins,
            )
        return

    decision = classify_block(block)
    unit = unit_map.get(key)

    # Get font info
    if font_spans:
        font_info = match_font_to_block(block, font_spans, target_lang=target_lang)
    else:
        font_info = estimate_font_info(block, target_lang, ref_line_height=ref_line_height)

    # Resolve to the font name the renderer will actually use. The fitting
    # engine must measure with the same font; otherwise Helvetica (fallback)
    # metrics differ from NotoSansCJKsc and paragraphs are taller than the
    # computed frame, causing Frame.addFromList to silently drop content.
    from .render.pdf_renderer import _try_register_font
    resolved_font = _try_register_font(font_info.font_name)
    if resolved_font != font_info.font_name:
        font_info = FontInfo(
            font_name=resolved_font,
            font_size=font_info.font_size,
            is_bold=font_info.is_bold,
            is_italic=font_info.is_italic,
            color=font_info.color,
        )

    # Title blocks are always rendered bold regardless of source font.
    if block.type == "title" and not font_info.is_bold:
        font_info = FontInfo(
            font_name=font_info.font_name,
            font_size=font_info.font_size,
            is_bold=True,
            is_italic=font_info.is_italic,
            color=font_info.color,
        )

    # For bold blocks, the renderer uses the bold font variant via <b> markup
    # (e.g. NotoSansCJKsc → SimHei via registerFontFamily).  The bold variant
    # is often wider than the regular font, so use it for fitting measurements
    # to avoid under-estimating line widths and causing unexpected wrapping.
    # font_info (with the original font_name) is kept for the renderer.
    fitting_font_info = font_info
    if font_info.is_bold and font_info.font_name == "NotoSansCJKsc":
        from .render.pdf_renderer import _registered_fonts as _rfn
        if "SimHei" in _rfn:
            fitting_font_info = FontInfo(
                font_name="SimHei",
                font_size=font_info.font_size,
                is_bold=font_info.is_bold,
                is_italic=font_info.is_italic,
                color=font_info.color,
            )

    tb = TranslatedBlock(
        original=block,
        font_info=font_info,
        decision=decision,
    )

    # Detect centered text: title always; non-title only when the block is
    # significantly narrower than the page (avoids centering full-width paragraphs
    # whose bbox center also falls near page center).
    bbox_center_x = (block.bbox[0] + block.bbox[2]) / 2
    page_center_x = page_width / 2
    bbox_width = block.bbox[2] - block.bbox[0]
    if abs(bbox_center_x - page_center_x) < 30:
        if block.type == "title" or bbox_width < page_width * 0.75:
            tb.is_centered = True

    # Detect first-line indent for true single-line blocks (h ≤ 20, non-title).
    # Only applies to scanned/VLM PDFs (font_spans empty): for these, VLM-packed
    # tall blocks reliably anchor to the column left edge. For non-scanned PDFs,
    # blocks at varying x0 are legitimately positioned (authors, affiliations, etc.)
    # and must not be moved.
    render_bbox = block.bbox
    if column_margins and not font_spans:
        block_h = block.bbox[3] - block.bbox[1]
        if block_h <= 20:
            # Find this block's column left margin (largest column x0 ≤ block x0)
            candidates = [m for m in column_margins if m <= block.bbox[0]]
            if candidates:
                col_margin = max(candidates)
                indent = block.bbox[0] - col_margin
                # 10–60pt: genuine paragraph indent (not a column gap)
                if 10 < indent < 60:
                    render_bbox = (col_margin, block.bbox[1], block.bbox[2], block.bbox[3])
                    logger.debug(
                        "De-indenting block %s: x0 %.1f → %.1f (indent=%.1fpt)",
                        key, block.bbox[0], col_margin, indent,
                    )

    # For rotated blocks (angle=90/270), fitting must use logical dimensions
    # (width↔height swapped) so text wraps correctly for the rotated frame.
    # The renderer derives logical_w/logical_h from the physical bbox, so
    # adjusted_bbox must always be stored in physical (unswapped) coordinates.
    _is_rotated = block.angle in (90, 270)
    if _is_rotated:
        _x0, _y0, _x1, _y1 = render_bbox
        _phys_w, _phys_h = _x1 - _x0, _y1 - _y0
        # Logical: width = physical_height, height = physical_width
        fit_bbox = (_x0, _y0, _x0 + _phys_h, _y0 + _phys_w)
    else:
        fit_bbox = render_bbox

    if unit and unit.translated:
        if unit.is_html:
            tb.translated_html = unit.translated
            # For HTML tables, create a simple fit result with original bbox
            tb.fit_result = _make_simple_fit(block, font_info)
        else:
            # Store equations for mixed content rendering
            if unit.equations:
                tb.equations = [
                    {"index": eq.index, "latex": eq.latex, "bbox": eq.original_bbox}
                    for eq in unit.equations
                ]
            # Strip equation placeholders from text for layout fitting
            import re
            # Strip leading CJK full-width spaces (U+3000) that translation
            # engines add as Chinese paragraph indentation — not wanted here.
            translated_stripped = unit.translated.lstrip("\u3000 \t")
            clean_text = re.sub(r'<eq id="\d+">.*?</eq>', " ", translated_stripped)
            clean_text = re.sub(r"\{\{EQ:\d+\}\}", " ", clean_text).strip()
            tb.translated_text = translated_stripped  # keep placeholders for rendering
            # Compute available whitespace for this block (not used for rotated blocks)
            avail = None
            if all_page_bboxes is not None and not _is_rotated:
                avail = compute_available_space(
                    render_bbox, block.type, tb.is_centered,
                    all_page_bboxes, page_width, page_height,
                )

            # Preferred font size for title blocks: try to render at ≥10pt
            # using available whitespace so headings don't appear smaller than body text.
            preferred_size = None
            if block.type == "title" and avail is not None:
                preferred_size = max(font_info.font_size, 10.0)

            # Pass 1: determine font_size from original (pre-translation) text.
            # This preserves the original document's visual font size regardless
            # of how much the translated text expands or contracts.
            from .translation.batcher import merge_block_text
            original_text, _ = merge_block_text(block)
            original_clean = re.sub(r'<eq id="\d+">.*?</eq>', " ", original_text)
            original_clean = re.sub(r"\{\{EQ:\d+\}\}", " ", original_clean).strip()

            # If translation left the text unchanged, skip layout fitting and
            # use the original font size / bbox directly.
            if clean_text == original_clean:
                from .models import FitResult as _FRU
                tb.fit_result = _FRU(
                    font_size=font_info.font_size,
                    leading=font_info.font_size * 1.2,
                    lines=[],
                    adjusted_bbox=render_bbox,
                    expanded=False,
                )
                translated_blocks[key] = tb
                return

            orig_result = fit_text_in_bbox(
                original_clean or clean_text,  # fallback to translated if original empty
                fit_bbox, fitting_font_info,
                min_font_size, max_shrink_ratio,
                available_bbox=avail,
                preferred_font_size=preferred_size,
            )

            if _is_rotated:
                # For rotated blocks, Pass 1 already used logical dimensions.
                # Just run Pass 2 in the same logical space at the locked font size,
                # then restore the physical bbox so the renderer computes correct
                # logical_w/logical_h from the physical dimensions.
                locked_font = FontInfo(
                    font_name=fitting_font_info.font_name,
                    font_size=orig_result.font_size,
                    is_bold=font_info.is_bold,
                    is_italic=font_info.is_italic,
                    color=font_info.color,
                )
                raw_result = fit_text_in_bbox(
                    clean_text, fit_bbox, locked_font,
                    min_font_size=orig_result.font_size,
                    max_shrink_ratio=1.0,
                    available_bbox=None,
                )
                from .models import FitResult as _FitResult
                tb.fit_result = _FitResult(
                    font_size=raw_result.font_size,
                    leading=raw_result.leading,
                    lines=raw_result.lines,
                    adjusted_bbox=render_bbox,  # physical bbox for renderer
                    expanded=raw_result.expanded,
                )
            else:
                # Pass 2: compute the actual rendering bbox using translated text at the
                # determined font size. Lock the font so it can only expand the bbox,
                # not shrink the font further.
                locked_font = FontInfo(
                    font_name=fitting_font_info.font_name,
                    font_size=orig_result.font_size,
                    is_bold=font_info.is_bold,
                    is_italic=font_info.is_italic,
                    color=font_info.color,
                )
                # Pass 2 starts from the horizontal extent Pass 1 chose so that
                # narrow blocks (e.g. de-indented titles) inherit the rightward
                # expansion that Pass 1's step-0 already computed.
                #
                # Exception: header/footer/page_number/page_footnote blocks are
                # often single-character-wide in the source (e.g. "47卷" = 25pt),
                # so Pass 1 exits early via the single-line path without expanding.
                # Pass 2 then inherits the same narrow bbox and the translated text
                # (e.g. "Volume 47") wraps.  Fix: for these discarded block types,
                # seed Pass 2 with the full available span so the text can always
                # fit on one line.  Body text (text/title) is unaffected.
                _is_discarded_type = block.type in (
                    "header", "footer", "page_number", "page_footnote"
                )
                if _is_discarded_type and avail is not None:
                    pass2_bbox = (
                        avail[0],       # full available left edge
                        render_bbox[1],
                        avail[2],       # full available right edge
                        render_bbox[3],
                    )
                else:
                    pass2_bbox = (
                        orig_result.adjusted_bbox[0],  # x0 from pass 1 (may be expanded)
                        render_bbox[1],                # y0 from original position
                        orig_result.adjusted_bbox[2],  # x1 from pass 1 (may be expanded)
                        render_bbox[3],                # y1 from original position
                    )
                tb.fit_result = fit_text_in_bbox(
                    clean_text, pass2_bbox, locked_font,
                    min_font_size=orig_result.font_size,  # don't shrink below determined size
                    max_shrink_ratio=1.0,                 # no shrinking allowed
                    available_bbox=avail,
                )

            # Centered titles: re-center the adjusted_bbox around the page center.
            # fit_text_in_bbox always anchors the tight bbox at bbox[0] (left edge),
            # which shifts the frame off-center when the title expands horizontally.
            # Re-centering ensures alignment=CENTER in the renderer produces visually
            # correct centering on the page.
            if tb.is_centered and tb.fit_result:
                from .models import FitResult as _FR
                fit = tb.fit_result
                abbox = fit.adjusted_bbox
                abbox_w = abbox[2] - abbox[0]
                # fit_text_in_bbox step 4a wraps for avail_width but anchors the
                # tight bbox at bbox[0], which can be right of avail[0].  For a
                # centered block this makes the tight bbox narrower than the wrap
                # width, so the text re-wraps inside the Frame.  Use avail_width
                # as the frame width when it's wider than the tight bbox so the
                # Frame matches the wrap width.
                if avail is not None and (avail[2] - avail[0]) > abbox_w + 2.0:
                    frame_w = avail[2] - avail[0]
                else:
                    frame_w = abbox_w
                cx = page_width / 2
                new_x0 = cx - frame_w / 2
                new_x1 = cx + frame_w / 2
                # Clamp to page bounds
                if new_x0 < 0:
                    new_x0, new_x1 = 0.0, frame_w
                elif new_x1 > page_width:
                    new_x0, new_x1 = page_width - frame_w, page_width
                tb.fit_result = _FR(
                    font_size=fit.font_size,
                    leading=fit.leading,
                    lines=fit.lines,
                    adjusted_bbox=(new_x0, abbox[1], new_x1, abbox[3]),
                    expanded=fit.expanded,
                )
            elif _is_discarded_type and not tb.is_centered and tb.fit_result and avail is not None:
                # Right-side discarded blocks (e.g. right-margin page numbers):
                # Pass 2 used the full avail span as pass2_bbox, so the frame may
                # extend far to the left of the original block position, causing
                # left-aligned text to appear off to the left.
                # Fix: measure the actual rendered text width and right-anchor the
                # tight bbox at the original x1, so the block stays near the right margin.
                orig_cx = (render_bbox[0] + render_bbox[2]) / 2
                if orig_cx > page_width / 2:
                    from .models import FitResult as _FRD
                    from .layout.engine import measure_text_width as _mtw
                    fit = tb.fit_result
                    if fit.lines:
                        # Use widest line to size the frame
                        line_w = max(
                            _mtw(ln, font_info.font_name, fit.font_size)
                            for ln in fit.lines
                        )
                        # 1.05× buffer so ReportLab doesn't re-wrap due to rounding
                        new_x1 = render_bbox[2]
                        new_x0 = max(avail[0], new_x1 - line_w * 1.05)
                        tb.fit_result = _FRD(
                            font_size=fit.font_size,
                            leading=fit.leading,
                            lines=fit.lines,
                            adjusted_bbox=(new_x0, fit.adjusted_bbox[1], new_x1, fit.adjusted_bbox[3]),
                            expanded=fit.expanded,
                        )

    elif decision == TranslateDecision.PRESERVE and block.lines:
        # Preserve blocks: render original text with proper fitting
        text = block.get_text_content()
        if text:
            tb.translated_text = text
            raw_result = fit_text_in_bbox(
                text, fit_bbox, fitting_font_info,
                min_font_size, max_shrink_ratio,
            )
            if _is_rotated:
                from .models import FitResult as _FitResult
                tb.fit_result = _FitResult(
                    font_size=raw_result.font_size,
                    leading=raw_result.leading,
                    lines=raw_result.lines,
                    adjusted_bbox=render_bbox,
                    expanded=raw_result.expanded,
                )
            else:
                tb.fit_result = raw_result

    translated_blocks[key] = tb


def _resolve_discarded_horiz_overlaps(
    blocks: list[TranslatedBlock],
    min_font_size: float,
) -> None:
    """Resolve horizontal overlaps among discarded (header/footer) blocks.

    These blocks sit side-by-side at the same y level.  When translated text
    expands a block into its right neighbour, clip the left block's x1 to just
    before the neighbour's x0 and re-fit the text to the new width.
    """
    import re as _re
    from .models import FitResult as _FR, FontInfo as _FI

    active = [tb for tb in blocks if tb.fit_result is not None]
    active.sort(key=lambda tb: tb.fit_result.adjusted_bbox[0])

    for i, tb_a in enumerate(active):
        for tb_b in active[i + 1:]:
            if not tb_a.fit_result or not tb_b.fit_result:
                continue
            bbox_a = tb_a.fit_result.adjusted_bbox
            bbox_b = tb_b.fit_result.adjusted_bbox
            h_ov = min(bbox_a[2], bbox_b[2]) - max(bbox_a[0], bbox_b[0])
            v_ov = min(bbox_a[3], bbox_b[3]) - max(bbox_a[1], bbox_b[1])
            if h_ov <= 0 or v_ov <= 0:
                continue
            # Clip left block's x1 to just before right block's x0
            new_x1 = bbox_b[0] - 1.0
            if new_x1 - bbox_a[0] < 5.0:
                continue  # would make bbox trivially narrow; skip
            if tb_a.translated_text:
                clean = _re.sub(r'<eq id="\d+">.*?</eq>', " ", tb_a.translated_text)
                clean = _re.sub(r"\{\{EQ:\d+\}\}", " ", clean).strip()
                locked = _FI(
                    font_name=tb_a.font_info.font_name,
                    font_size=tb_a.fit_result.font_size,
                    is_bold=tb_a.font_info.is_bold,
                    is_italic=tb_a.font_info.is_italic,
                    color=tb_a.font_info.color,
                )
                clipped_bbox = (bbox_a[0], bbox_a[1], new_x1, bbox_a[3])
                new_fit = fit_text_in_bbox(
                    clean, clipped_bbox, locked,
                    min_font_size=min_font_size,
                    max_shrink_ratio=1.0,
                )
                tb_a.fit_result = _FR(
                    font_size=new_fit.font_size,
                    leading=new_fit.leading,
                    lines=new_fit.lines,
                    adjusted_bbox=(bbox_a[0], bbox_a[1], new_x1, new_fit.adjusted_bbox[3]),
                    expanded=False,
                )
            else:
                fit = tb_a.fit_result
                tb_a.fit_result = _FR(
                    font_size=fit.font_size,
                    leading=fit.leading,
                    lines=fit.lines,
                    adjusted_bbox=(bbox_a[0], bbox_a[1], new_x1, bbox_a[3]),
                    expanded=False,
                )
            logger.debug(
                "Clipped discarded block %s x1 %.1f → %.1f (was overlapping %s)",
                tb_a.original.type, bbox_a[2], new_x1, tb_b.original.type,
            )


def _collect_image_obstacles(
    page: "Page",
) -> list[tuple[float, float, float, float]]:
    """Return bboxes of all fixed-position blocks on the page (images and
    interline equations) that text blocks must not overlap with."""
    obstacles: list[tuple[float, float, float, float]] = []
    for block in page.para_blocks:
        if block.type in ("image", "interline_equation") and block.bbox:
            obstacles.append(block.bbox)
    return obstacles


def _make_simple_fit(block: Block, font_info: FontInfo) -> FitResult:
    """Create a simple FitResult using the block's original bbox."""
    from .models import FitResult

    return FitResult(
        font_size=font_info.font_size,
        leading=font_info.font_size * 1.2,
        lines=[],
        adjusted_bbox=block.bbox,
    )


def _validate_translation(
    doc: LayoutDocument,
    translated_blocks: dict[tuple[int, ...], TranslatedBlock],
) -> None:
    """Validate translated blocks for content loss, overlap, and out-of-bounds."""
    from .translation.batcher import collect_translation_units

    total_units = 0
    missing = 0
    overlaps = 0
    oob = 0

    # Check 1: Content loss — every collected unit should have a translation
    units = collect_translation_units(doc)
    for unit in units:
        total_units += 1
        key = (unit.page_idx, *unit.block_path)
        tb = translated_blocks.get(key)
        if tb is None:
            missing += 1
            logger.warning(
                "Content loss: no translated block for key %s (text: %r)",
                key, unit.text[:60],
            )
        elif not tb.translated_text and not tb.translated_html:
            missing += 1
            logger.warning(
                "Content loss: empty translation for key %s (text: %r)",
                key, unit.text[:60],
            )

    # Checks 2 & 3: Overlap and out-of-bounds per page
    for page in doc.pdf_info:
        page_idx = page.page_idx
        pw, ph = page.page_size

        # Collect fit results for this page
        entries: list[tuple[tuple[int, ...], tuple[float, float, float, float]]] = []
        for key, tb in translated_blocks.items():
            if key[0] == page_idx and tb.fit_result is not None:
                entries.append((key, tb.fit_result.adjusted_bbox))

        # Out-of-bounds check
        for key, bbox in entries:
            x0, y0, x1, y1 = bbox
            if x0 < -2 or y0 < -2 or x1 > pw + 2 or y1 > ph + 2:
                oob += 1
                logger.warning(
                    "Out-of-bounds: block %s bbox %s exceeds page %.0fx%.0f",
                    key, tuple(round(v, 1) for v in bbox), pw, ph,
                )

        # Overlap check (O(n²); pages have few blocks so this is fine)
        for i in range(len(entries)):
            for j in range(i + 1, len(entries)):
                key_a, a = entries[i]
                key_b, b = entries[j]
                ox = min(a[2], b[2]) - max(a[0], b[0])
                oy = min(a[3], b[3]) - max(a[1], b[1])
                if ox > 2 and oy > 2:  # 2pt tolerance
                    overlaps += 1
                    logger.warning(
                        "Overlap: blocks %s %s and %s %s overlap by (%.1f x %.1f)pt",
                        key_a, tuple(round(v, 1) for v in a),
                        key_b, tuple(round(v, 1) for v in b),
                        ox, oy,
                    )

    logger.info(
        "Validation: %d units, %d missing/empty, %d overlaps, %d out-of-bounds",
        total_units, missing, overlaps, oob,
    )
