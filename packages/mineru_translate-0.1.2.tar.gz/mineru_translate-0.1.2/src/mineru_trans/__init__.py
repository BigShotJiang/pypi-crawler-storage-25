"""mineru-trans: PDF layout-preserving translation based on MinerU API output."""

__version__ = "0.1.0"
