"""Data models for MinerU layout.json structure."""

from __future__ import annotations

from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field, model_validator


class Span(BaseModel):
    """A span is the smallest text/content unit within a line."""

    bbox: tuple[float, float, float, float]
    type: Literal["text", "inline_equation", "interline_equation", "image", "table"]
    content: str | None = None
    html: str | None = None
    image_path: str | None = None
    score: float | None = None

    @model_validator(mode="before")
    @classmethod
    def normalize_image_path(cls, data: dict) -> dict:
        """Accept both 'image_path' and 'img_path' field names."""
        if isinstance(data, dict) and "img_path" in data and "image_path" not in data:
            data["image_path"] = data.pop("img_path")
        return data


class Line(BaseModel):
    """A line contains one or more spans."""

    bbox: tuple[float, float, float, float]
    spans: list[Span] = Field(default_factory=list)


class Block(BaseModel):
    """A block is a content element on a page (text, image, table, etc.).

    Leaf blocks have `lines` (text, title, interline_equation, etc.).
    Container blocks have `blocks` (image, table, list, code).
    """

    type: str
    bbox: tuple[float, float, float, float]
    angle: int = 0
    index: int | None = None
    sub_type: str | None = None
    lines: list[Line] | None = None
    blocks: list[Block] | None = None
    # Fields that may appear on container-level or special blocks
    image_path: str | None = None
    html: str | None = None

    @model_validator(mode="before")
    @classmethod
    def normalize_fields(cls, data: dict) -> dict:
        if isinstance(data, dict):
            # Accept img_path as image_path
            if "img_path" in data and "image_path" not in data:
                data["image_path"] = data.pop("img_path")
        return data

    @property
    def width(self) -> float:
        return self.bbox[2] - self.bbox[0]

    @property
    def height(self) -> float:
        return self.bbox[3] - self.bbox[1]

    def get_text_content(self) -> str:
        """Extract all text content from this block's lines/spans."""
        if not self.lines:
            return ""
        parts = []
        for line in self.lines:
            for span in line.spans:
                if span.type == "text" and span.content:
                    parts.append(span.content)
        return " ".join(parts)


class Page(BaseModel):
    """A single page from the PDF."""

    page_idx: int
    page_size: tuple[float, float]
    para_blocks: list[Block] = Field(default_factory=list)
    discarded_blocks: list[Block] = Field(default_factory=list)


class LayoutDocument(BaseModel):
    """Root model for MinerU's layout.json output."""

    pdf_info: list[Page]
    backend: str = Field(default="pipeline", alias="_backend")
    version_name: str = Field(default="", alias="_version_name")

    model_config = {"populate_by_name": True}


# --- Translation result models ---


class TranslateDecision(str, Enum):
    """Decision for whether a block/span should be translated."""

    TRANSLATE = "translate"
    PRESERVE = "preserve"  # Render as-is, do not translate
    SKIP = "skip"  # Do not render at all


class FontInfo(BaseModel):
    """Font metadata for a text element."""

    font_name: str = "NotoSans"
    font_size: float = 10.0
    is_bold: bool = False
    is_italic: bool = False
    color: int = 0x000000  # sRGB integer


class FitResult(BaseModel):
    """Result of fitting translated text into a bbox."""

    font_size: float
    leading: float  # line spacing
    lines: list[str]  # wrapped text lines
    adjusted_bbox: tuple[float, float, float, float]
    expanded: bool = False  # whether bbox was expanded beyond original


class TranslatedBlock(BaseModel):
    """A block with its translation and layout fitting results."""

    original: Block
    translated_text: str | None = None  # None means keep original
    translated_html: str | None = None  # For table bodies
    font_info: FontInfo = Field(default_factory=FontInfo)
    fit_result: FitResult | None = None
    decision: TranslateDecision = TranslateDecision.PRESERVE
    # Inline equation placeholders for mixed content rendering
    equations: list[dict] | None = None  # [{index, latex, bbox}, ...]
    is_centered: bool = False  # Whether original text was centered

    model_config = {"arbitrary_types_allowed": True}
