"""DeepL translation engine implementation."""

from __future__ import annotations

import html as _html
import logging
import re

import deepl

from .base import TranslationEngine
from .retry import retry_with_backoff

logger = logging.getLogger(__name__)

# Exceptions that are safe to retry (transient / rate-limit)
_RETRYABLE_EXCEPTIONS: tuple[type[Exception], ...] = (
    deepl.TooManyRequestsException,
    deepl.ConnectionException,
    ConnectionError,
    TimeoutError,
)

# Map common language codes to DeepL format
_LANG_MAP_SOURCE = {
    "zh": "ZH",
    "en": "EN",
    "ja": "JA",
    "ko": "KO",
    "fr": "FR",
    "de": "DE",
    "es": "ES",
    "pt": "PT",
    "ru": "RU",
    "it": "IT",
    "auto": None,  # DeepL auto-detects when source_lang is None
}

_LANG_MAP_TARGET = {
    "zh": "ZH-HANS",
    "zh-hans": "ZH-HANS",
    "zh-hant": "ZH-HANT",
    "en": "EN-US",
    "en-us": "EN-US",
    "en-gb": "EN-GB",
    "ja": "JA",
    "ko": "KO",
    "fr": "FR",
    "de": "DE",
    "es": "ES",
    "pt": "PT-BR",
    "pt-br": "PT-BR",
    "pt-pt": "PT-PT",
    "ru": "RU",
    "it": "IT",
}


class DeepLEngine(TranslationEngine):
    """Translation engine using the DeepL API."""

    def __init__(self, api_key: str, max_retries: int = 5) -> None:
        self.translator = deepl.Translator(api_key)
        self._glossary_cache: dict[str, deepl.GlossaryInfo] = {}
        self._max_retries = max_retries

    def _get_source_lang(self, lang: str) -> str | None:
        return _LANG_MAP_SOURCE.get(lang.lower(), lang.upper())

    def _get_target_lang(self, lang: str) -> str:
        mapped = _LANG_MAP_TARGET.get(lang.lower())
        if mapped is None:
            raise ValueError(
                f"Unsupported target language: {lang}. "
                f"Supported: {list(_LANG_MAP_TARGET.keys())}"
            )
        return mapped

    def _get_or_create_glossary(
        self,
        glossary: dict[str, str],
        source_lang: str,
        target_lang: str,
    ) -> deepl.GlossaryInfo | None:
        """Create a DeepL glossary or return cached one."""
        if not glossary:
            return None

        src = self._get_source_lang(source_lang)
        tgt = self._get_target_lang(target_lang)
        if src is None:
            # Can't create glossary without explicit source language
            logger.warning("Glossary requires explicit source language, skipping")
            return None

        cache_key = f"{src}_{tgt}_{hash(frozenset(glossary.items()))}"
        if cache_key in self._glossary_cache:
            return self._glossary_cache[cache_key]

        try:
            glossary_info = self.translator.create_glossary(
                "mineru-trans-glossary",
                source_lang=src,
                target_lang=tgt,
                entries=glossary,
            )
            self._glossary_cache[cache_key] = glossary_info
            logger.info("Created DeepL glossary with %d entries", len(glossary))
            return glossary_info
        except Exception:
            logger.exception("Failed to create DeepL glossary")
            return None

    def translate_batch(
        self,
        texts: list[str],
        source_lang: str,
        target_lang: str,
        glossary: dict[str, str] | None = None,
    ) -> list[str]:
        if not texts:
            return []

        src = self._get_source_lang(source_lang)
        tgt = self._get_target_lang(target_lang)

        kwargs: dict = {}
        if glossary:
            glossary_info = self._get_or_create_glossary(glossary, source_lang, target_lang)
            if glossary_info:
                kwargs["glossary"] = glossary_info

        # Use XML tag handling to protect <eq> tags (inline equations)
        has_eq_tags = any("<eq " in t for t in texts)
        if has_eq_tags:
            texts = [_escape_xml_outside_eq(t) for t in texts]
            kwargs["tag_handling"] = "xml"
            kwargs["ignore_tags"] = ["eq"]

        results = retry_with_backoff(
            self.translator.translate_text,
            texts,
            source_lang=src,
            target_lang=tgt,
            retryable_exceptions=_RETRYABLE_EXCEPTIONS,
            max_retries=self._max_retries,
            **kwargs,
        )

        # DeepL returns a list of TextResult objects
        if has_eq_tags:
            return [_html.unescape(r.text) for r in results]
        return [r.text for r in results]

    def translate_html(
        self,
        html: str,
        source_lang: str,
        target_lang: str,
        glossary: dict[str, str] | None = None,
    ) -> str:
        if not html.strip():
            return html

        src = self._get_source_lang(source_lang)
        tgt = self._get_target_lang(target_lang)

        kwargs: dict = {"tag_handling": "html"}
        if glossary:
            glossary_info = self._get_or_create_glossary(glossary, source_lang, target_lang)
            if glossary_info:
                kwargs["glossary"] = glossary_info

        result = retry_with_backoff(
            self.translator.translate_text,
            html,
            source_lang=src,
            target_lang=tgt,
            retryable_exceptions=_RETRYABLE_EXCEPTIONS,
            max_retries=self._max_retries,
            **kwargs,
        )

        return result.text


# ---------------------------------------------------------------------------
# XML helpers
# ---------------------------------------------------------------------------

_EQ_TAG_RE = re.compile(r'<eq[^>]*>.*?</eq>', re.DOTALL)


def _escape_xml_outside_eq(text: str) -> str:
    """Escape XML special chars in text segments that lie outside <eq> tags.

    DeepL's tag_handling="xml" requires the entire input to be well-formed XML.
    LaTeX inside <eq> tags may contain raw < > & chars which are already safe
    (they are in ignore_tags).  The plain-text parts between eq tags can also
    contain these chars (e.g. "where x > 0") and must be escaped.
    """
    parts = _EQ_TAG_RE.split(text)
    tags = _EQ_TAG_RE.findall(text)
    result: list[str] = []
    for i, part in enumerate(parts):
        # Escape & first to avoid double-escaping, then < and >
        escaped = part.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        result.append(escaped)
        if i < len(tags):
            result.append(tags[i])
    return "".join(result)
