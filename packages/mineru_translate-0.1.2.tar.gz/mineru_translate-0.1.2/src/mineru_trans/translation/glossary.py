"""Glossary (terminology) loader for CSV files."""

from __future__ import annotations

import csv
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def load_glossary(path: str | Path) -> dict[str, str]:
    """Load a glossary CSV file with source,target columns.

    Expected format:
        source,target
        afforestation,造林
        flow duration curve,流量历时曲线

    Args:
        path: Path to the CSV file.

    Returns:
        Dictionary mapping source terms to target terms.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Glossary file not found: {path}")

    glossary: dict[str, str] = {}
    with open(path, encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or "source" not in reader.fieldnames or "target" not in reader.fieldnames:
            raise ValueError(
                f"Glossary CSV must have 'source' and 'target' columns, "
                f"got: {reader.fieldnames}"
            )
        for row in reader:
            source = row["source"].strip()
            target = row["target"].strip()
            if source and target:
                glossary[source] = target

    logger.info("Loaded glossary with %d terms from %s", len(glossary), path)
    return glossary
