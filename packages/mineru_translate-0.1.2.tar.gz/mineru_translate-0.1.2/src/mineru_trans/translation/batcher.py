"""Batch translation with equation placeholder handling."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ..models import Block, LayoutDocument, Line, Span, TranslateDecision
from ..strategy import classify_block, classify_span, is_container_block
from .base import TranslationEngine

if TYPE_CHECKING:
    from .cache import TranslationCache

logger = logging.getLogger(__name__)

# Placeholder pattern for inline equations during translation
# Uses XML tags so DeepL's ignore_tags can protect them
_EQ_PLACEHOLDER = '<eq id="{index}">{latex}</eq>'
_EQ_PATTERN = re.compile(r'<eq id="(\d+)">(.*?)</eq>')


class TranslationPipelineError(RuntimeError):
    """Raised when translation cannot be completed successfully."""


@dataclass
class EquationPlaceholder:
    """Tracks an inline equation replaced by a placeholder."""

    index: int
    latex: str
    original_bbox: tuple[float, float, float, float]


@dataclass
class TranslationUnit:
    """A unit of text to be translated, with metadata for reassembly."""

    text: str  # Text with equation placeholders
    page_idx: int
    block_path: list[int]  # Index path to locate the block (e.g., [3] or [5, 1])
    is_html: bool = False  # Whether this is HTML table content
    equations: list[EquationPlaceholder] = field(default_factory=list)
    translated: str | None = None  # Filled after translation


def merge_block_text(block: Block) -> tuple[str, list[EquationPlaceholder]]:
    """Merge all lines in a block into a single translation unit.

    Inline equations are replaced with {{EQ:N}} placeholders.

    Returns:
        (merged_text, list_of_equation_placeholders)
    """
    if not block.lines:
        return "", []

    all_parts: list[str] = []
    equations: list[EquationPlaceholder] = []
    eq_counter = 0

    for line in block.lines:
        line_parts: list[str] = []
        for span in line.spans:
            if span.type == "text" and span.content:
                # Strip Unicode replacement characters (U+FFFD) from MinerU OCR failures
                cleaned = span.content.strip().replace("\ufffd", "")
                if cleaned:
                    line_parts.append(cleaned)
            elif span.type == "inline_equation" and span.content:
                # Escape LaTeX for XML safety (DeepL uses XML tag handling)
                safe_latex = (
                    span.content
                    .replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                )
                placeholder = _EQ_PLACEHOLDER.format(
                    index=eq_counter, latex=safe_latex
                )
                line_parts.append(placeholder)
                equations.append(
                    EquationPlaceholder(
                        index=eq_counter,
                        latex=span.content,
                        original_bbox=span.bbox,
                    )
                )
                eq_counter += 1
        if line_parts:
            all_parts.append(" ".join(line_parts))

    merged = " ".join(all_parts)
    return merged, equations


def restore_equations(
    translated: str, equations: list[EquationPlaceholder]
) -> list[dict]:
    """Split translated text back into text and equation segments.

    Returns:
        List of dicts: {"type": "text", "content": "..."} or
                       {"type": "equation", "latex": "...", "bbox": (...)}
    """
    if not equations:
        return [{"type": "text", "content": translated}]

    result = []
    last_end = 0
    for match in _EQ_PATTERN.finditer(translated):
        if match.start() > last_end:
            text_part = translated[last_end : match.start()]
            if text_part.strip():
                result.append({"type": "text", "content": text_part})
        eq_idx = int(match.group(1))
        if eq_idx < len(equations):
            eq = equations[eq_idx]
            result.append({
                "type": "equation",
                "latex": eq.latex,
                "bbox": eq.original_bbox,
            })
        last_end = match.end()

    if last_end < len(translated):
        text_part = translated[last_end:]
        if text_part.strip():
            result.append({"type": "text", "content": text_part})

    return result


def collect_translation_units(doc: LayoutDocument) -> list[TranslationUnit]:
    """Walk the entire document and collect all translation units.

    Returns a flat list of TranslationUnit objects ready for batch translation.
    """
    units: list[TranslationUnit] = []

    for page in doc.pdf_info:
        page_idx = page.page_idx

        # Process para_blocks
        for block_idx, block in enumerate(page.para_blocks):
            _collect_from_block(block, page_idx, [block_idx], units)

        # Process discarded_blocks (also translate)
        for block_idx, block in enumerate(page.discarded_blocks):
            _collect_from_block(block, page_idx, [-1, block_idx], units)

    logger.info("Collected %d translation units", len(units))
    return units


def _collect_from_block(
    block: Block,
    page_idx: int,
    path: list[int],
    units: list[TranslationUnit],
) -> None:
    """Recursively collect translation units from a block."""
    decision = classify_block(block)

    if decision == TranslateDecision.PRESERVE:
        return  # Skip entirely

    if is_container_block(block):
        # Process sub-blocks individually
        for sub_idx, sub_block in enumerate(block.blocks or []):
            _collect_from_block(sub_block, page_idx, path + [sub_idx], units)
        return

    # Leaf block that should be translated
    if decision == TranslateDecision.TRANSLATE:
        # Check for table HTML content in spans
        if block.lines:
            for line in block.lines:
                for span in line.spans:
                    if span.type == "table" and span.html:
                        units.append(
                            TranslationUnit(
                                text=span.html,
                                page_idx=page_idx,
                                block_path=path,
                                is_html=True,
                            )
                        )
                        return

        # Regular text block: merge lines
        text, equations = merge_block_text(block)
        if text.strip():
            units.append(
                TranslationUnit(
                    text=text,
                    page_idx=page_idx,
                    block_path=path,
                    equations=equations,
                )
            )


def translate_units(
    units: list[TranslationUnit],
    engine: TranslationEngine,
    source_lang: str,
    target_lang: str,
    glossary: dict[str, str] | None = None,
    batch_size: int = 50,
    cache: TranslationCache | None = None,
    concurrency: int = 1,
) -> None:
    """Translate all units using the given engine. Modifies units in-place.

    Args:
        concurrency: Number of concurrent API requests (default: 1 = sequential).
    """
    # Separate HTML and plain text units
    html_units = [u for u in units if u.is_html]
    text_units = [u for u in units if not u.is_html]

    cache_hits = 0
    cache_misses = 0

    # --- HTML units ---
    # Partition into cache hits and misses
    html_miss_units: list[TranslationUnit] = []
    for unit in html_units:
        if cache is not None:
            cached = cache.get(unit.text, source_lang, target_lang)
            if cached is not None:
                unit.translated = cached
                cache_hits += 1
                continue
        cache_misses += 1
        html_miss_units.append(unit)

    def _translate_html_unit(unit: TranslationUnit) -> str:
        try:
            return engine.translate_html(unit.text, source_lang, target_lang, glossary)
        except Exception as exc:
            raise TranslationPipelineError(
                f"Failed to translate HTML unit at page {unit.page_idx}"
            ) from exc

    if html_miss_units:
        if concurrency > 1:
            from concurrent.futures import ThreadPoolExecutor
            with ThreadPoolExecutor(max_workers=concurrency) as executor:
                results = list(executor.map(_translate_html_unit, html_miss_units))
        else:
            results = [_translate_html_unit(u) for u in html_miss_units]

        for unit, result in zip(html_miss_units, results):
            unit.translated = result
            if cache is not None:
                cache.put(unit.text, source_lang, target_lang, result)

    # --- Text units in batches ---
    # Build list of (batch_units, miss_indices, miss_texts) for each batch
    batches: list[tuple[list[TranslationUnit], list[int], list[str]]] = []
    for i in range(0, len(text_units), batch_size):
        batch = text_units[i : i + batch_size]
        texts = [u.text for u in batch]

        cached_results = (
            cache.get_batch(texts, source_lang, target_lang)
            if cache is not None
            else [None] * len(texts)
        )

        miss_indices: list[int] = []
        miss_texts: list[str] = []
        for idx, cached in enumerate(cached_results):
            if cached is not None:
                batch[idx].translated = cached
                cache_hits += 1
            else:
                miss_indices.append(idx)
                miss_texts.append(texts[idx])
                cache_misses += 1

        if miss_texts:
            batches.append((batch, miss_indices, miss_texts))

    def _translate_text_batch(
        args: tuple[list[TranslationUnit], list[int], list[str]]
    ) -> tuple[list[TranslationUnit], list[int], list[str], list[str] | None]:
        batch, miss_indices, miss_texts = args
        try:
            results = engine.translate_batch(miss_texts, source_lang, target_lang, glossary)
            return batch, miss_indices, miss_texts, results
        except Exception as exc:
            first_unit = batch[miss_indices[0]]
            raise TranslationPipelineError(
                "Failed to translate batch of "
                f"{len(miss_texts)} units starting at page {first_unit.page_idx}"
            ) from exc

    if batches:
        if concurrency > 1:
            from concurrent.futures import ThreadPoolExecutor
            with ThreadPoolExecutor(max_workers=concurrency) as executor:
                batch_results = list(executor.map(_translate_text_batch, batches))
        else:
            batch_results = [_translate_text_batch(b) for b in batches]

        for batch, miss_indices, miss_texts, results in batch_results:
            for miss_idx, translated in zip(miss_indices, results):
                batch[miss_idx].translated = translated
            if cache is not None:
                cache.put_batch(miss_texts, source_lang, target_lang, results)

    if cache is not None:
        cache.save()
        total = cache_hits + cache_misses
        logger.info("Cache: %d hits, %d misses out of %d units", cache_hits, cache_misses, total)

    translated_count = sum(1 for u in units if u.translated is not None)
    logger.info("Translated %d/%d units", translated_count, len(units))
