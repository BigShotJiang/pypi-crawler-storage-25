"""Abstract base class for translation engines."""

from __future__ import annotations

from abc import ABC, abstractmethod


class TranslationEngine(ABC):
    """Interface for translation engines (DeepL, LLM, etc.)."""

    @abstractmethod
    def translate_batch(
        self,
        texts: list[str],
        source_lang: str,
        target_lang: str,
        glossary: dict[str, str] | None = None,
    ) -> list[str]:
        """Translate a batch of plain text strings.

        Args:
            texts: List of texts to translate.
            source_lang: Source language code (e.g., "en", "zh", "auto").
            target_lang: Target language code.
            glossary: Optional term mapping {source_term: target_term}.

        Returns:
            List of translated texts, same length as input.
        """

    @abstractmethod
    def translate_html(
        self,
        html: str,
        source_lang: str,
        target_lang: str,
        glossary: dict[str, str] | None = None,
    ) -> str:
        """Translate text within HTML, preserving HTML structure/tags.

        Args:
            html: HTML string (e.g., table markup).
            source_lang: Source language code.
            target_lang: Target language code.
            glossary: Optional term mapping.

        Returns:
            HTML string with translated text content.
        """
