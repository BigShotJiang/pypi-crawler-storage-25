"""File-based translation cache using JSON storage."""

from __future__ import annotations

import hashlib
import json
import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)


class TranslationCache:
    """Caches translation results in a JSON file.

    The cache is loaded entirely into memory on init. Writes go to memory
    first, then are flushed to disk via :meth:`save` (called automatically
    after each batch in the batcher, and on :meth:`close`).

    File writes use a temporary file + ``os.replace`` to avoid corruption
    if the process is interrupted mid-write.
    """

    def __init__(self, cache_dir: Path, engine_name: str) -> None:
        self._engine_name = engine_name
        p = Path(cache_dir)
        if p.suffix == ".json":
            # Direct file path (new style: <output>_cache.json)
            self._cache_dir = p.parent
            self._cache_file = p
        else:
            # Directory (legacy style: <dir>/translations.json)
            self._cache_dir = p
            self._cache_file = p / "translations.json"
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._data: dict[str, dict[str, str]] = {}
        self._dirty = False
        self._load()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get(self, text: str, source_lang: str, target_lang: str) -> str | None:
        """Return cached translation or ``None`` on miss."""
        key = self._make_key(text, source_lang, target_lang)
        entry = self._data.get(key)
        if entry is not None:
            return entry["translated"]
        return None

    def put(
        self, text: str, source_lang: str, target_lang: str, translated: str
    ) -> None:
        """Store a translation result in the cache."""
        key = self._make_key(text, source_lang, target_lang)
        self._data[key] = {"source": text, "translated": translated}
        self._dirty = True

    def get_batch(
        self, texts: list[str], source_lang: str, target_lang: str
    ) -> list[str | None]:
        """Batch lookup — returns a list parallel to *texts*."""
        return [self.get(t, source_lang, target_lang) for t in texts]

    def put_batch(
        self,
        texts: list[str],
        source_lang: str,
        target_lang: str,
        translated: list[str],
    ) -> None:
        """Batch store."""
        for t, tr in zip(texts, translated):
            self.put(t, source_lang, target_lang, tr)

    def save(self) -> None:
        """Persist the in-memory cache to disk (atomic write)."""
        if not self._dirty:
            return
        tmp_path = self._cache_file.with_suffix(".tmp")
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(self._data, f, ensure_ascii=False)
            os.replace(tmp_path, self._cache_file)
            self._dirty = False
        except Exception:
            logger.exception("Failed to save translation cache")
            # Clean up temp file on failure
            try:
                tmp_path.unlink(missing_ok=True)
            except OSError:
                pass

    def close(self) -> None:
        """Flush pending writes."""
        self.save()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _make_key(self, text: str, source_lang: str, target_lang: str) -> str:
        raw = f"{self._engine_name}\0{source_lang}\0{target_lang}\0{text}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _load(self) -> None:
        if not self._cache_file.exists():
            logger.info("No existing translation cache found, starting fresh")
            return
        try:
            with open(self._cache_file, "r", encoding="utf-8") as f:
                self._data = json.load(f)
            logger.info(
                "Loaded %d cached translations from %s",
                len(self._data),
                self._cache_file,
            )
        except (json.JSONDecodeError, OSError):
            logger.warning(
                "Failed to load translation cache from %s, starting fresh",
                self._cache_file,
            )
            self._data = {}
