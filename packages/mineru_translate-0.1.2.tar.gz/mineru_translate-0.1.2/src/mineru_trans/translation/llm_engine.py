"""LLM translation engine using OpenAI-compatible API."""

from __future__ import annotations

import json
import logging
import re

from .base import TranslationEngine
from .retry import retry_with_backoff

logger = logging.getLogger(__name__)

try:
    from openai import APIConnectionError, APITimeoutError, RateLimitError, InternalServerError
    _RETRYABLE_EXCEPTIONS: tuple[type[Exception], ...] = (
        RateLimitError,
        APIConnectionError,
        APITimeoutError,
        InternalServerError,
        ConnectionError,
        TimeoutError,
    )
except ImportError:
    _RETRYABLE_EXCEPTIONS = (ConnectionError, TimeoutError)

# How many texts to send per LLM API call (internal sub-batch)
_LLM_SUB_BATCH = 4


class LLMEngine(TranslationEngine):
    """Translation engine using an OpenAI-compatible LLM API."""

    def __init__(
        self,
        api_key: str,
        base_url: str,
        model: str,
        max_retries: int = 5,
    ) -> None:
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise ImportError(
                "openai package required for LLM engine. "
                "Install with: pip install 'mineru-trans[llm]'"
            ) from exc

        self._client = OpenAI(api_key=api_key, base_url=base_url)
        self._model = model
        self._max_retries = max_retries

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _call(self, messages: list[dict]) -> str:
        response = self._client.chat.completions.create(
            model=self._model,
            messages=messages,
            temperature=0.1,
            extra_body={"thinking_mode": False},
        )
        return (response.choices[0].message.content or "").strip()

    @staticmethod
    def _eq_note(texts: list[str] | str) -> str:
        haystack = texts if isinstance(texts, str) else " ".join(texts)
        if "<eq " in haystack:
            return (
                ' Preserve ALL <eq id="N">...</eq> tags exactly as-is; '
                "never translate or alter their content."
            )
        return ""

    # ------------------------------------------------------------------
    # translate_batch
    # ------------------------------------------------------------------

    def translate_batch(
        self,
        texts: list[str],
        source_lang: str,
        target_lang: str,
        glossary: dict[str, str] | None = None,
    ) -> list[str]:
        if not texts:
            return []

        results: list[str] = []
        for i in range(0, len(texts), _LLM_SUB_BATCH):
            chunk = texts[i : i + _LLM_SUB_BATCH]
            results.extend(
                self._translate_chunk(chunk, source_lang, target_lang, glossary)
            )
        return results

    def _translate_chunk(
        self,
        texts: list[str],
        source_lang: str,
        target_lang: str,
        glossary: dict[str, str] | None,
    ) -> list[str]:
        src = source_lang if source_lang != "auto" else "the source language"
        glossary_note = ""
        if glossary:
            pairs = "; ".join(
                f'"{k}"→"{v}"' for k, v in list(glossary.items())[:20]
            )
            glossary_note = f" Apply these term mappings: {pairs}."

        system_prompt = (
            f"You are a professional academic paper translator. "
            f"Translate the following texts from {src} to {target_lang}. "
            f"Keep translations concise and close to the original length. "
            f"Return ONLY a JSON array of translated strings with the same "
            f"number of elements as the input — no extra keys, no markdown fences."
            f"{self._eq_note(texts)}"
            f"{glossary_note}"
        )
        user_content = json.dumps(texts, ensure_ascii=False)

        def _do_call() -> str:
            return self._call(
                [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_content},
                ]
            )

        try:
            raw = retry_with_backoff(
                _do_call,
                retryable_exceptions=_RETRYABLE_EXCEPTIONS,
                max_retries=self._max_retries,
            )
            return self._parse_json_array(raw, len(texts))
        except Exception as exc:
            logger.warning(
                "Batch LLM translation failed (%s), falling back to per-item calls", exc
            )
            return [
                self._translate_one(t, source_lang, target_lang, glossary)
                for t in texts
            ]

    def _translate_one(
        self,
        text: str,
        source_lang: str,
        target_lang: str,
        glossary: dict[str, str] | None,
    ) -> str:
        src = source_lang if source_lang != "auto" else "the source language"
        glossary_note = ""
        if glossary:
            pairs = "; ".join(
                f'"{k}"→"{v}"' for k, v in list(glossary.items())[:10]
            )
            glossary_note = f" Apply these term mappings: {pairs}."

        system_prompt = (
            f"You are a professional academic paper translator. "
            f"Translate the following text from {src} to {target_lang}. "
            f"Keep translations concise and close to the original length. "
            f"Return ONLY the translated text with no explanations."
            f"{self._eq_note(text)}"
            f"{glossary_note}"
        )

        def _do_call() -> str:
            return self._call(
                [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": text},
                ]
            )

        try:
            return retry_with_backoff(
                _do_call,
                retryable_exceptions=_RETRYABLE_EXCEPTIONS,
                max_retries=self._max_retries,
            )
        except Exception as exc:
            logger.error("LLM single-item translation failed: %s", exc)
            return text  # return original on total failure

    @staticmethod
    def _parse_json_array(raw: str, expected: int) -> list[str]:
        """Extract a JSON array of *expected* strings from raw LLM output."""
        # Strip possible markdown code fences
        raw = re.sub(r"^```[a-z]*\n?", "", raw.strip())
        raw = re.sub(r"\n?```$", "", raw.strip())

        # Direct parse
        try:
            result = json.loads(raw)
            if isinstance(result, list) and len(result) == expected:
                return [str(item) for item in result]
        except json.JSONDecodeError:
            pass

        # Find first JSON array in the response
        match = re.search(r"\[[\s\S]*\]", raw)
        if match:
            try:
                result = json.loads(match.group())
                if isinstance(result, list) and len(result) == expected:
                    return [str(item) for item in result]
            except json.JSONDecodeError:
                pass

        raise ValueError(
            f"Could not parse JSON array of length {expected} from LLM response: "
            f"{raw[:300]!r}"
        )

    # ------------------------------------------------------------------
    # translate_html
    # ------------------------------------------------------------------

    def translate_html(
        self,
        html: str,
        source_lang: str,
        target_lang: str,
        glossary: dict[str, str] | None = None,
    ) -> str:
        if not html.strip():
            return html

        src = source_lang if source_lang != "auto" else "the source language"
        glossary_note = ""
        if glossary:
            pairs = "; ".join(
                f'"{k}"→"{v}"' for k, v in list(glossary.items())[:20]
            )
            glossary_note = f" Apply these term mappings: {pairs}."

        system_prompt = (
            f"You are a professional academic paper translator. "
            f"Translate the visible text content inside the HTML from {src} to {target_lang}. "
            f"Preserve ALL HTML tags, attributes, and structure exactly unchanged. "
            f"Return ONLY the translated HTML — no explanations, no fences."
            f"{glossary_note}"
        )

        def _do_call() -> str:
            return self._call(
                [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": html},
                ]
            )

        try:
            return retry_with_backoff(
                _do_call,
                retryable_exceptions=_RETRYABLE_EXCEPTIONS,
                max_retries=self._max_retries,
            )
        except Exception as exc:
            logger.error("LLM HTML translation failed: %s", exc)
            return html
