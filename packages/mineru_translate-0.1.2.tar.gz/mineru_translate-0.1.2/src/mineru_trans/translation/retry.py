"""Retry utility with exponential backoff for translation API calls."""

from __future__ import annotations

import logging
import random
import time
from typing import Callable, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")


def retry_with_backoff(
    func: Callable[..., T],
    *args: object,
    retryable_exceptions: tuple[type[Exception], ...],
    max_retries: int = 5,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    **kwargs: object,
) -> T:
    """Call *func* with automatic retry on transient failures.

    Uses exponential backoff with jitter:
        delay = min(base_delay * 2^attempt, max_delay) * uniform(0.5, 1.0)

    Args:
        func: The callable to invoke.
        retryable_exceptions: Exception types that should trigger a retry.
        max_retries: Maximum number of retry attempts (0 = no retries).
        base_delay: Initial delay in seconds before the first retry.
        max_delay: Upper bound on the delay between retries.

    Returns:
        The return value of *func*.

    Raises:
        The last exception raised by *func* if all retries are exhausted.
    """
    last_exc: Exception | None = None
    func_name = getattr(func, "__name__", repr(func))
    for attempt in range(max_retries + 1):
        try:
            return func(*args, **kwargs)
        except retryable_exceptions as exc:
            last_exc = exc
            if attempt >= max_retries:
                logger.error(
                    "All %d retries exhausted for %s: %s",
                    max_retries,
                    func_name,
                    exc,
                )
                raise
            delay = min(base_delay * (2 ** attempt), max_delay)
            delay *= random.uniform(0.5, 1.0)
            logger.warning(
                "Retryable error in %s (attempt %d/%d), retrying in %.1fs: %s",
                func_name,
                attempt + 1,
                max_retries,
                delay,
                exc,
            )
            time.sleep(delay)

    # Should never reach here, but satisfy type checker
    raise last_exc  # type: ignore[misc]
