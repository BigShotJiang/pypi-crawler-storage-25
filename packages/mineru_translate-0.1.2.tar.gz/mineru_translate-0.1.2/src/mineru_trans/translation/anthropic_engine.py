"""Translation engine using the Anthropic API (Claude models)."""

from __future__ import annotations

import json
import logging
import re

from .base import TranslationEngine
from .retry import retry_with_backoff

logger = logging.getLogger(__name__)

try:
    from anthropic import APIConnectionError, APITimeoutError, RateLimitError, InternalServerError
    _RETRYABLE_EXCEPTIONS: tuple[type[Exception], ...] = (
        RateLimitError,
        APIConnectionError,
        APITimeoutError,
        InternalServerError,
        ConnectionError,
        TimeoutError,
    )
except ImportError:
    _RETRYABLE_EXCEPTIONS = (ConnectionError, TimeoutError)

_LLM_SUB_BATCH = 4  # initial sub-batch size; halved automatically on parse failure


class AnthropicEngine(TranslationEngine):
    """Translation engine using the Anthropic Messages API."""

    def __init__(
        self,
        api_key: str,
        model: str,
        max_retries: int = 5,
    ) -> None:
        try:
            import anthropic
        except ImportError as exc:
            raise ImportError(
                "anthropic package required for Anthropic engine. "
                "Install with: pip install 'mineru-trans[anthropic]'"
            ) from exc

        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = model
        self._max_retries = max_retries

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _call(self, system: str, user: str) -> str:
        import anthropic
        response = self._client.messages.create(
            model=self._model,
            max_tokens=4096,
            system=system,
            messages=[{"role": "user", "content": user}],
            temperature=0.1,
        )
        return (response.content[0].text or "").strip()

    @staticmethod
    def _eq_note(texts: list[str] | str) -> str:
        haystack = texts if isinstance(texts, str) else " ".join(texts)
        if "<eq " in haystack:
            return (
                ' Preserve ALL <eq id="N">...</eq> tags exactly as-is; '
                "never translate or alter their content."
            )
        return ""

    # ------------------------------------------------------------------
    # translate_batch
    # ------------------------------------------------------------------

    def translate_batch(
        self,
        texts: list[str],
        source_lang: str,
        target_lang: str,
        glossary: dict[str, str] | None = None,
    ) -> list[str]:
        if not texts:
            return []

        results: list[str] = []
        for i in range(0, len(texts), _LLM_SUB_BATCH):
            chunk = texts[i : i + _LLM_SUB_BATCH]
            results.extend(
                self._translate_chunk(chunk, source_lang, target_lang, glossary)
            )
        return results

    def _translate_chunk(
        self,
        texts: list[str],
        source_lang: str,
        target_lang: str,
        glossary: dict[str, str] | None,
    ) -> list[str]:
        """Translate a chunk, halving the batch on JSON parse failure until per-item."""
        if len(texts) == 1:
            return [self._translate_one(texts[0], source_lang, target_lang, glossary)]

        src = source_lang if source_lang != "auto" else "the source language"
        glossary_note = ""
        if glossary:
            pairs = "; ".join(
                f'"{k}"→"{v}"' for k, v in list(glossary.items())[:20]
            )
            glossary_note = f" Apply these term mappings: {pairs}."

        system_prompt = (
            f"You are a professional academic paper translator. "
            f"Translate the following texts from {src} to {target_lang}. "
            f"Keep translations concise and close to the original length. "
            f"Return ONLY a JSON array of translated strings with the same "
            f"number of elements as the input — no extra keys, no markdown fences."
            f"{self._eq_note(texts)}"
            f"{glossary_note}"
        )
        user_content = json.dumps(texts, ensure_ascii=False)

        def _do_call() -> str:
            return self._call(system_prompt, user_content)

        try:
            raw = retry_with_backoff(
                _do_call,
                retryable_exceptions=_RETRYABLE_EXCEPTIONS,
                max_retries=self._max_retries,
            )
            return self._parse_json_array(raw, len(texts))
        except ValueError:
            # Response truncated or malformed — split in half and retry each half
            mid = len(texts) // 2
            logger.warning(
                "Batch parse failed for %d items, splitting into %d + %d",
                len(texts), mid, len(texts) - mid,
            )
            left = self._translate_chunk(texts[:mid], source_lang, target_lang, glossary)
            right = self._translate_chunk(texts[mid:], source_lang, target_lang, glossary)
            return left + right

    def _translate_one(
        self,
        text: str,
        source_lang: str,
        target_lang: str,
        glossary: dict[str, str] | None,
    ) -> str:
        src = source_lang if source_lang != "auto" else "the source language"
        glossary_note = ""
        if glossary:
            pairs = "; ".join(
                f'"{k}"→"{v}"' for k, v in list(glossary.items())[:10]
            )
            glossary_note = f" Apply these term mappings: {pairs}."

        system_prompt = (
            f"You are a professional academic paper translator. "
            f"Translate the following text from {src} to {target_lang}. "
            f"Keep translations concise and close to the original length. "
            f"Return ONLY the translated text with no explanations."
            f"{self._eq_note(text)}"
            f"{glossary_note}"
        )

        def _do_call() -> str:
            return self._call(system_prompt, text)

        try:
            return retry_with_backoff(
                _do_call,
                retryable_exceptions=_RETRYABLE_EXCEPTIONS,
                max_retries=self._max_retries,
            )
        except Exception as exc:
            logger.error("Anthropic single-item translation failed: %s", exc)
            return text

    @staticmethod
    def _parse_json_array(raw: str, expected: int) -> list[str]:
        raw = re.sub(r"^```[a-z]*\n?", "", raw.strip())
        raw = re.sub(r"\n?```$", "", raw.strip())

        try:
            result = json.loads(raw)
            if isinstance(result, list) and len(result) == expected:
                return [str(item) for item in result]
        except json.JSONDecodeError:
            pass

        match = re.search(r"\[[\s\S]*\]", raw)
        if match:
            try:
                result = json.loads(match.group())
                if isinstance(result, list) and len(result) == expected:
                    return [str(item) for item in result]
            except json.JSONDecodeError:
                pass

        raise ValueError(
            f"Could not parse JSON array of length {expected} from Anthropic response: "
            f"{raw[:300]!r}"
        )

    # ------------------------------------------------------------------
    # translate_html
    # ------------------------------------------------------------------

    def translate_html(
        self,
        html: str,
        source_lang: str,
        target_lang: str,
        glossary: dict[str, str] | None = None,
    ) -> str:
        if not html.strip():
            return html

        src = source_lang if source_lang != "auto" else "the source language"
        glossary_note = ""
        if glossary:
            pairs = "; ".join(
                f'"{k}"→"{v}"' for k, v in list(glossary.items())[:20]
            )
            glossary_note = f" Apply these term mappings: {pairs}."

        system_prompt = (
            f"You are a professional academic paper translator. "
            f"Translate the visible text content inside the HTML from {src} to {target_lang}. "
            f"Preserve ALL HTML tags, attributes, and structure exactly unchanged. "
            f"Return ONLY the translated HTML — no explanations, no fences."
            f"{glossary_note}"
        )

        def _do_call() -> str:
            return self._call(system_prompt, html)

        try:
            return retry_with_backoff(
                _do_call,
                retryable_exceptions=_RETRYABLE_EXCEPTIONS,
                max_retries=self._max_retries,
            )
        except Exception as exc:
            logger.error("Anthropic HTML translation failed: %s", exc)
            return html
