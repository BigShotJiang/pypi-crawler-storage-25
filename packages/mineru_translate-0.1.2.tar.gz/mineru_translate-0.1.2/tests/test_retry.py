"""Tests for the retry utility."""

from __future__ import annotations

import time
from unittest.mock import MagicMock, patch

import pytest

from mineru_trans.translation.retry import retry_with_backoff


class _TransientError(Exception):
    pass


class _PermanentError(Exception):
    pass


class TestRetryWithBackoff:
    """Tests for retry_with_backoff."""

    def test_succeeds_on_first_try(self):
        func = MagicMock(return_value="ok")
        result = retry_with_backoff(
            func, "a", retryable_exceptions=(_TransientError,), max_retries=3
        )
        assert result == "ok"
        func.assert_called_once_with("a")

    @patch("mineru_trans.translation.retry.time.sleep")
    def test_retries_on_transient_error(self, mock_sleep):
        func = MagicMock(side_effect=[_TransientError("err"), "ok"])
        result = retry_with_backoff(
            func, retryable_exceptions=(_TransientError,), max_retries=3
        )
        assert result == "ok"
        assert func.call_count == 2
        assert mock_sleep.call_count == 1

    @patch("mineru_trans.translation.retry.time.sleep")
    def test_raises_after_max_retries(self, mock_sleep):
        func = MagicMock(side_effect=_TransientError("fail"))
        with pytest.raises(_TransientError, match="fail"):
            retry_with_backoff(
                func, retryable_exceptions=(_TransientError,), max_retries=2
            )
        # 1 initial + 2 retries = 3 calls
        assert func.call_count == 3
        assert mock_sleep.call_count == 2

    def test_does_not_retry_non_retryable(self):
        func = MagicMock(side_effect=_PermanentError("fatal"))
        with pytest.raises(_PermanentError, match="fatal"):
            retry_with_backoff(
                func, retryable_exceptions=(_TransientError,), max_retries=5
            )
        func.assert_called_once()

    @patch("mineru_trans.translation.retry.time.sleep")
    def test_exponential_backoff_delays(self, mock_sleep):
        func = MagicMock(
            side_effect=[_TransientError("e")] * 3 + ["ok"]
        )
        retry_with_backoff(
            func,
            retryable_exceptions=(_TransientError,),
            max_retries=5,
            base_delay=1.0,
            max_delay=60.0,
        )
        assert mock_sleep.call_count == 3
        # Delays should be increasing (with jitter in [0.5, 1.0])
        delays = [call.args[0] for call in mock_sleep.call_args_list]
        assert all(d > 0 for d in delays)
        # base * 2^0 * jitter, base * 2^1 * jitter, base * 2^2 * jitter
        assert delays[0] <= 1.0  # max 1.0 * 1.0
        assert delays[1] <= 2.0  # max 1.0 * 2.0
        assert delays[2] <= 4.0  # max 1.0 * 4.0

    @patch("mineru_trans.translation.retry.time.sleep")
    def test_max_delay_cap(self, mock_sleep):
        func = MagicMock(
            side_effect=[_TransientError("e")] * 10 + ["ok"]
        )
        retry_with_backoff(
            func,
            retryable_exceptions=(_TransientError,),
            max_retries=10,
            base_delay=1.0,
            max_delay=5.0,
        )
        delays = [call.args[0] for call in mock_sleep.call_args_list]
        assert all(d <= 5.0 for d in delays)

    def test_zero_retries(self):
        func = MagicMock(side_effect=_TransientError("fail"))
        with pytest.raises(_TransientError):
            retry_with_backoff(
                func, retryable_exceptions=(_TransientError,), max_retries=0
            )
        func.assert_called_once()

    @patch("mineru_trans.translation.retry.time.sleep")
    def test_kwargs_passed_through(self, mock_sleep):
        func = MagicMock(side_effect=[_TransientError("e"), "ok"])
        result = retry_with_backoff(
            func, "pos_arg",
            retryable_exceptions=(_TransientError,),
            max_retries=3,
            kw1="val1",
        )
        assert result == "ok"
        func.assert_called_with("pos_arg", kw1="val1")
