"""Tests for CLI behavior and translation failure handling."""

from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from mineru_trans import cli
from mineru_trans.cli import main
from mineru_trans.translation.batcher import TranslationPipelineError, TranslationUnit, translate_units
from mineru_trans.translation.retry import retry_with_backoff


class _AlwaysFailEngine:
    """Engine stub that always raises a retryable error."""

    def translate_batch(self, texts, source_lang, target_lang, glossary=None):
        retry_with_backoff(
            self._raise_retryable,
            retryable_exceptions=(ConnectionError,),
            max_retries=2,
            base_delay=0,
            max_delay=0,
        )
        return texts

    def translate_html(self, html, source_lang, target_lang, glossary=None):
        retry_with_backoff(
            self._raise_retryable,
            retryable_exceptions=(ConnectionError,),
            max_retries=2,
            base_delay=0,
            max_delay=0,
        )
        return html

    @staticmethod
    def _raise_retryable():
        raise ConnectionError("upstream timeout")


def test_translate_rejects_unsupported_input_file():
    runner = CliRunner()
    input_path = Path("README.md").resolve()
    result = runner.invoke(
        main,
        [str(input_path), "--target", "zh", "--api-key", "dummy"],
    )

    assert result.exit_code != 0
    assert "README.md" in result.output
    assert "does not appear to be a PDF." in result.output


def test_translate_accepts_layout_json_without_pdf_token(monkeypatch):
    runner = CliRunner()
    calls: dict[str, object] = {}

    def _fake_create_engine(
        provider: str,
        api_key: str | None,
        model: str | None,
        base_url: str | None,
    ):
        calls["provider"] = provider
        calls["api_key"] = api_key
        calls["model"] = model
        calls["base_url"] = base_url
        return object(), provider

    def _fake_translate_document(**kwargs):
        calls.update(kwargs)

    monkeypatch.setattr(cli, "_create_engine", _fake_create_engine)
    monkeypatch.setattr("mineru_trans.pipeline.translate_document", _fake_translate_document)

    pdf_path = Path("demo/example.pdf").resolve()
    layout_path = Path("demo/example_parsed/layout.json").resolve()
    result = runner.invoke(
        main,
        [
            str(pdf_path),
            "--layout",
            str(layout_path),
            "--target",
            "zh",
            "--api-key",
            "dummy",
        ],
    )

    assert result.exit_code == 0
    assert calls["layout_path"] == layout_path
    assert calls["target_lang"] == "zh"
    assert calls["source_pdf_path"] == str(pdf_path)
    assert calls["provider"] == "openai"
    assert calls["cache_dir"] == str(pdf_path.parent / "example_translated_cache.json")


def test_translate_units_raise_after_retry_exhausted():
    units = [
        TranslationUnit(
            text="hello world",
            page_idx=0,
            block_path=[0],
        )
    ]

    with pytest.raises(TranslationPipelineError, match="Failed to translate batch"):
        translate_units(
            units,
            engine=_AlwaysFailEngine(),
            source_lang="en",
            target_lang="zh",
            concurrency=1,
        )
