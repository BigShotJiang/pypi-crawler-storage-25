"""Regression tests for overlap resolution."""

from __future__ import annotations

import pytest

from mineru_trans.layout.overlap import resolve_overlaps
from mineru_trans.models import Block, FitResult, FontInfo, TranslatedBlock, TranslateDecision


def _make_tb(x0: float, y0: float, x1: float, y1: float, text: str = "test") -> TranslatedBlock:
    block = Block(type="text", bbox=(x0, y0, x1, y1), lines=[])
    fi = FontInfo(font_name="Helvetica", font_size=10.0)
    fr = FitResult(
        font_size=10.0, leading=12.0, lines=[text], adjusted_bbox=(x0, y0, x1, y1)
    )
    return TranslatedBlock(
        original=block,
        font_info=fi,
        decision=TranslateDecision.TRANSLATE,
        translated_text=text,
        fit_result=fr,
    )


class TestTwoColumnLayout:
    """Blocks in side-by-side columns must not push each other vertically."""

    def test_side_by_side_blocks_not_moved(self) -> None:
        """Left-column block must not push right-column block down.

        Regression: full-width table caused both columns to merge into one
        resolution group, making the right column block get pushed below
        the left column block even though they don't overlap horizontally.
        """
        # Full-width table body bridges both columns
        table_body = _make_tb(44, 112, 502, 248)
        table_foot = _make_tb(46, 249, 502, 269)

        # Left column text (x=45-262)
        left_text = _make_tb(45, 282, 262, 484, "left column")

        # Right column text (x=285-501) — must NOT be pushed below left_text
        right_text = _make_tb(285, 282, 501, 388, "right column")

        # Right column titles and text below right_text
        title1 = _make_tb(285, 414, 328, 424, "4. Results")
        title2 = _make_tb(285, 439, 374, 448, "4.1 Eval")
        right_text2 = _make_tb(285, 462, 501, 485, "results text")

        # Second full-width table
        cap2 = _make_tb(45, 494, 134, 514, "Table 3")
        body2 = _make_tb(44, 516, 502, 651, "table2 body")
        foot2 = _make_tb(46, 654, 373, 663, "footnote2")

        blocks = [
            table_body, table_foot,
            left_text, right_text,
            title1, title2, right_text2,
            cap2, body2, foot2,
        ]

        resolve_overlaps(blocks, page_height=743.0)

        def adj_y0(tb: TranslatedBlock) -> float:
            assert tb.fit_result is not None
            return tb.fit_result.adjusted_bbox[1]

        # left_text and right_text are in different visual columns — neither
        # should be displaced from its original y position.
        assert abs(adj_y0(left_text) - 282) < 2, (
            f"left_text was pushed to y={adj_y0(left_text):.1f}, expected ~282"
        )
        assert abs(adj_y0(right_text) - 282) < 2, (
            f"right_text was pushed to y={adj_y0(right_text):.1f}, expected ~282 "
            "(regression: was pushed to 485+ by left_text)"
        )
        # Titles and other right-column blocks should also stay in place
        assert abs(adj_y0(title1) - 414) < 2
        assert abs(adj_y0(title2) - 439) < 2
        assert abs(adj_y0(right_text2) - 462) < 2

    def test_truly_overlapping_blocks_are_resolved(self) -> None:
        """Blocks that genuinely overlap horizontally and vertically must be pushed."""
        upper = _make_tb(50, 100, 300, 200, "upper")
        lower = _make_tb(50, 150, 300, 250, "lower")  # overlaps upper by 50pt

        resolve_overlaps([upper, lower], page_height=792.0)

        assert lower.fit_result is not None
        # lower should have been pushed down so it starts at or after upper's end
        assert lower.fit_result.adjusted_bbox[1] >= 200, (
            f"lower block was not pushed down: y0={lower.fit_result.adjusted_bbox[1]:.1f}"
        )

    def test_non_overlapping_same_column_not_moved(self) -> None:
        """Blocks with a gap between them must not be moved."""
        upper = _make_tb(50, 100, 300, 200)
        lower = _make_tb(50, 210, 300, 310)  # gap of 10pt

        resolve_overlaps([upper, lower], page_height=792.0)

        assert lower.fit_result is not None
        assert abs(lower.fit_result.adjusted_bbox[1] - 210) < 2
