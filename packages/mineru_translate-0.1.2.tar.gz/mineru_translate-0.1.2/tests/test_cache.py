"""Tests for the translation cache."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from mineru_trans.translation.cache import TranslationCache


@pytest.fixture
def cache_dir(tmp_path: Path) -> Path:
    return tmp_path / "cache"


class TestTranslationCache:
    """Tests for TranslationCache."""

    def test_put_and_get(self, cache_dir: Path):
        cache = TranslationCache(cache_dir, "deepl")
        cache.put("hello", "en", "zh", "你好")
        assert cache.get("hello", "en", "zh") == "你好"
        cache.close()

    def test_get_miss(self, cache_dir: Path):
        cache = TranslationCache(cache_dir, "deepl")
        assert cache.get("missing", "en", "zh") is None
        cache.close()

    def test_batch_operations(self, cache_dir: Path):
        cache = TranslationCache(cache_dir, "deepl")
        texts = ["hello", "world", "foo"]
        translated = ["你好", "世界", "富"]
        cache.put_batch(texts, "en", "zh", translated)

        results = cache.get_batch(["hello", "bar", "world"], "en", "zh")
        assert results == ["你好", None, "世界"]
        cache.close()

    def test_persistence_across_instances(self, cache_dir: Path):
        # Write and close
        cache1 = TranslationCache(cache_dir, "deepl")
        cache1.put("hello", "en", "zh", "你好")
        cache1.close()

        # Reopen and read
        cache2 = TranslationCache(cache_dir, "deepl")
        assert cache2.get("hello", "en", "zh") == "你好"
        cache2.close()

    def test_different_engines_different_keys(self, cache_dir: Path):
        cache_deepl = TranslationCache(cache_dir, "deepl")
        cache_deepl.put("hello", "en", "zh", "你好-deepl")
        cache_deepl.close()

        cache_llm = TranslationCache(cache_dir, "llm")
        # Same text, different engine → miss
        assert cache_llm.get("hello", "en", "zh") is None
        cache_llm.close()

    def test_different_lang_pairs_different_keys(self, cache_dir: Path):
        cache = TranslationCache(cache_dir, "deepl")
        cache.put("hello", "en", "zh", "你好")
        cache.put("hello", "en", "ja", "こんにちは")

        assert cache.get("hello", "en", "zh") == "你好"
        assert cache.get("hello", "en", "ja") == "こんにちは"
        cache.close()

    def test_save_creates_valid_json(self, cache_dir: Path):
        cache = TranslationCache(cache_dir, "deepl")
        cache.put("hello", "en", "zh", "你好")
        cache.save()

        cache_file = cache_dir / "translations.json"
        assert cache_file.exists()
        data = json.loads(cache_file.read_text(encoding="utf-8"))
        assert len(data) == 1
        entry = list(data.values())[0]
        assert entry["source"] == "hello"
        assert entry["translated"] == "你好"
        cache.close()

    def test_corrupted_cache_file_starts_fresh(self, cache_dir: Path):
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file = cache_dir / "translations.json"
        cache_file.write_text("not valid json", encoding="utf-8")

        cache = TranslationCache(cache_dir, "deepl")
        assert cache.get("anything", "en", "zh") is None
        # Should still work for new entries
        cache.put("hello", "en", "zh", "你好")
        assert cache.get("hello", "en", "zh") == "你好"
        cache.close()

    def test_overwrite_existing_entry(self, cache_dir: Path):
        cache = TranslationCache(cache_dir, "deepl")
        cache.put("hello", "en", "zh", "你好v1")
        cache.put("hello", "en", "zh", "你好v2")
        assert cache.get("hello", "en", "zh") == "你好v2"
        cache.close()

    def test_no_save_when_not_dirty(self, cache_dir: Path):
        cache = TranslationCache(cache_dir, "deepl")
        cache.save()  # No entries, should not create file
        cache_file = cache_dir / "translations.json"
        assert not cache_file.exists()
        cache.close()
