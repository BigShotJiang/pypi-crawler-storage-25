from __future__ import annotations

from aimp_framework.base import IntegerField, ListField, NumberField, Schema, StringField, TextField
from aimp_sdk import mode


class SearchSchema:
    class Inputs(Schema.Inputs):
        query = TextField(required=True)

    class Outputs(Schema.Outputs):
        matches = ListField(
            item_schema={
                "image_id": StringField(),
                "filename": StringField(),
                "score": NumberField(),
            },
            required=True,
        )
        count = IntegerField(required=True)

    class Params(Schema.Params):
        pass


@mode(name="search")
async def run_search(
    request: SearchSchema.Inputs,
    _parameters: SearchSchema.Params,
) -> SearchSchema.Outputs:
    query = request.query.strip() or "query"
    return {
        "matches": [
            {
                "image_id": f"{query}-1",
                "filename": f"{query}.png",
                "score": 0.91,
            }
        ],
        "count": 1,
    }
