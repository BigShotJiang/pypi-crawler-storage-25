from __future__ import annotations

from aimp_sdk import Model, mode
from aimp_sdk.vector_store import Vector, TextField as VectorTextField
from aimp_framework.base import IntegerField, Metric, Schema, TextField


class EmbedEngine:
    def load(self):
        return None


class EmbedInput(Schema):
    text = TextField(required=True)


class EmbedOutput(Schema):
    embedding = IntegerField(required=True, multiple=True)


class EmbedModel(Model):
    engine = EmbedEngine
    vectors = []

    async def embed(self, request: EmbedInput) -> EmbedOutput:
        return {"embedding": [int(len(request.text))]}


class DocsVector(Vector):
    alias = "docs"
    name = "Documents"
    description = "Document embeddings used by vector-backed modes."
    dimension = 1536
    metric = Metric.COSINE
    text = VectorTextField(required=True)


EmbedModel.vectors = [DocsVector]


class SearchSchema:
    class Inputs(Schema.Inputs):
        query = TextField(required=True)

    class Outputs(Schema.Outputs):
        results = TextField(required=True, multiple=True)
        count = IntegerField(required=True)

    class Params(Schema.Params):
        top_k = IntegerField(default=5, min=1, max=20)


class IndexSchema:
    class Inputs(Schema.Inputs):
        items = TextField(required=True, multiple=True)

    class Outputs(Schema.Outputs):
        indexed = IntegerField(required=True)

    class Params(Schema.Params):
        pass


@mode(name="search")
async def run_search(
    request: SearchSchema.Inputs,
    parameters: SearchSchema.Params,
    model: EmbedModel,
) -> SearchSchema.Outputs:
    runtime = model._mode_runtime
    query_len = len(request.query)
    ordered = sorted(runtime._rows, key=lambda item: abs(len(item) - query_len))
    top_k = parameters.top_k if parameters is not None else 5
    hits = ordered[:top_k]
    return {"results": hits, "count": len(hits)}


@mode(name="find")
async def run_find(
    request: IndexSchema.Inputs,
    _parameters: IndexSchema.Params,
    model: EmbedModel,
) -> IndexSchema.Outputs:
    runtime = model._mode_runtime
    runtime._rows.extend(list(request.items))
    return {"indexed": len(request.items)}


_rows: list[str] = []
