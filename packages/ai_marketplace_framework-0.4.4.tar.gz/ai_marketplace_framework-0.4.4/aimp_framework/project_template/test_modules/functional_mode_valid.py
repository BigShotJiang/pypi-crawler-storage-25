from aimp_sdk import mode
from aimp_framework.base import Schema, TextField


class SampleSchema:
    class Inputs(Schema.Inputs):
        query = TextField(required=True)

    class Outputs(Schema.Outputs):
        result = TextField(required=True)

    class Params(Schema.Params):
        pass


@mode(name="sample")
async def run_sample(
    inputs: SampleSchema.Inputs,
    params: SampleSchema.Params,
) -> SampleSchema.Outputs:
    _ = params
    return SampleSchema.Outputs.validate({"result": inputs.query})
