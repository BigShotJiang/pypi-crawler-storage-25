from aimp_sdk import mode
from aimp_framework.base import ImageField, Schema, SelectField, TextField


class CompareSchema:
    class Inputs(Schema.Inputs):
        image = ImageField(description="Input image")
        notes = TextField(required=True)

    class Outputs(Schema.Outputs):
        result = TextField(required=True)

    class Params(Schema.Params):
        output_format = SelectField(options=["json", "text"], default="json")


@mode(name="compare")
async def run_compare(
    request: CompareSchema.Inputs,
    _parameters: CompareSchema.Params,
) -> CompareSchema.Outputs:
    _ = request
    return CompareSchema.Outputs.validate({"result": "ok"})
