from aimp_sdk import mode
from aimp_framework.base import Schema, TextField


class Shared:
    class Inputs(Schema.Inputs):
        query = TextField(required=True)

    class Outputs(Schema.Outputs):
        result = TextField(required=True)

    class Params(Schema.Params):
        pass


@mode(name="search")
async def run_first(
    inputs: Shared.Inputs,
    params: Shared.Params,
) -> Shared.Outputs:
    _ = params
    return Shared.Outputs.validate({"result": inputs.query})


@mode(name="search")
async def run_second(
    inputs: Shared.Inputs,
    params: Shared.Params,
) -> Shared.Outputs:
    _ = params
    return Shared.Outputs.validate({"result": inputs.query})
