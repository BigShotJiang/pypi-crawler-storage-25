class NotAModeModule:
    pass
