from aimp_sdk import mode
from aimp_framework.base import Schema, TextField


class GenerateSchema:
    class Inputs(Schema.Inputs):
        input_data = TextField(description="Primary input")

    class Outputs(Schema.Outputs):
        ok = TextField(required=True)

    class Params(Schema.Params):
        pass


@mode(name="generate")
async def run_generate(
    inputs: GenerateSchema.Inputs,
    params: GenerateSchema.Params,
) -> GenerateSchema.Outputs:
    _ = params
    return GenerateSchema.Outputs.validate({"ok": "yes"})
