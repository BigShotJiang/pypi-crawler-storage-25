"""Public ``@mode`` entrypoints for {{PROJECT_NAME}}.

Keep this file thin:
- declare public mode handlers only
- shape public I/O through ``schemas.py``
- delegate behavior to ``models/{{MODEL_KEY}}/model.py``
"""

from __future__ import annotations

from aimp_sdk import mode

from models.{{MODEL_KEY}}.model import {{MODEL_CLASS_NAME}}
from playground import ExamplePlayground
from schemas import ExampleSchema


@mode(
    name="example",
    label="Example",
    description="Runs the example mode.",
    playground=ExamplePlayground,
)
async def run_example(
    inputs: ExampleSchema.Inputs,
    params: ExampleSchema.Params,
    model: {{MODEL_CLASS_NAME}},
) -> ExampleSchema.Outputs:
    """Handle the public example mode."""
    _ = params
    output = await model.process(inputs)
    return ExampleSchema.Outputs(result=output.result)
