"""Schema definitions for the root agent.

Public agent schemas (mode contracts) are defined here.
These are used by modes for validation and typed handler I/O.
"""

from __future__ import annotations

from aimp_framework.base import Schema
from aimp_framework.base import TextField


class ExampleSchema:
    """Contract schema for the example mode."""

    class Inputs(Schema.Inputs):
        query = TextField(
            description="The query to process",
            required=True,
        )

    class Outputs(Schema.Outputs):
        result = TextField(required=True)

    class Params(Schema.Params):
        pass
