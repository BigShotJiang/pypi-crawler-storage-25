"""Playground specifications for public modes.

Playground specs define how the Playground UI renders mode inputs and outputs.
Each spec is linked from its mode class via Mode.playground.
"""

from __future__ import annotations

from aimp_sdk.playground import PlaygroundSpec, Markdown

from schemas import ExampleSchema


class ExamplePlayground(PlaygroundSpec):
    """Playground spec for the example mode."""

    view = Markdown(ExampleSchema.Outputs.result)
