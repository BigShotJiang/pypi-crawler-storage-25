"""Model implementation for {{MODEL_KEY}}."""

from __future__ import annotations

from aimp_sdk import Model

from .engine import {{MODEL_CLASS_NAME}}Engine
from .schemas import GenerateInput, GenerateOutput, ProcessInput, ProcessOutput
from .tuning import {{MODEL_CLASS_NAME}}Tuning
from .vectors import {{MODEL_CLASS_NAME}}DocsVector


class {{MODEL_CLASS_NAME}}(Model):
    """Internal model capability unit."""

    engine = {{MODEL_CLASS_NAME}}Engine
    vectors = [{{MODEL_CLASS_NAME}}DocsVector]
    tuning = {{MODEL_CLASS_NAME}}Tuning

    async def generate(self, input: GenerateInput) -> GenerateOutput:
        text = input.prompt.strip()
        token_count = min(input.max_tokens, max(1, len(text.split())))
        return GenerateOutput.validate({"text": text, "tokens_used": token_count})

    async def process(self, input: ProcessInput) -> ProcessOutput:
        return ProcessOutput.validate({"result": input.query.strip()})
