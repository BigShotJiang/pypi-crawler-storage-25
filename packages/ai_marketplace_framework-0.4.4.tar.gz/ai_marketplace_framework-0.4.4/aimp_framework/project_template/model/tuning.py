"""Tuning capability for {{MODEL_KEY}} model."""

from __future__ import annotations

from aimp_sdk import FineTuneSchema, TuneResult, TuningSession, TuningTextField


class {{MODEL_CLASS_NAME}}DatasetSchema(FineTuneSchema):
    prompt = TuningTextField(required=True, description="Training prompt text")
    completion = TuningTextField(required=True, description="Expected completion text")


class {{MODEL_CLASS_NAME}}Tuning:
    """Model-scoped tuning capability."""

    strategy = "lora"
    training_runtime_profile = "cpu"
    dataset_requirements = {"format": "aimp_tuning_bundle_v1"}
    dataset_spec = {"format": "aimp_tuning_bundle_v1"}
    objective = {"name": "validation_loss", "direction": "minimize"}
    split_policy = {"strategy": "auto", "validation_ratio": 0.1}
    parameters = {
        "learning_rate": {
            "kind": "float",
            "default": 1e-4,
            "min": 1e-6,
            "max": 1e-2,
            "required": True,
        },
        "num_epochs": {
            "kind": "integer",
            "default": 3,
            "min": 1,
            "max": 20,
            "required": True,
        },
    }

    async def run(self, session: TuningSession) -> TuneResult:
        records = session.train_dataset.num_rows + session.validation_dataset.num_rows
        return TuneResult(metrics={"validation_loss": 0.0, "records": float(records)})
