"""Tuning capability for {{MODEL_KEY}} model."""

from __future__ import annotations

from .runner import {{MODEL_CLASS_NAME}}Tuning

__all__ = ["{{MODEL_CLASS_NAME}}Tuning"]
