"""Tuning hyperparameter schema for {{MODEL_KEY}} model."""

from __future__ import annotations

from aimp_framework.base import IntegerField, NumberField, Schema


class {{MODEL_CLASS_NAME}}Hyperparams(Schema):
    learning_rate = NumberField(default=1e-4, min=1e-6, max=1e-2)
    num_epochs = IntegerField(default=3, min=1, max=20)
    batch_size = IntegerField(default=8, min=1, max=256)
