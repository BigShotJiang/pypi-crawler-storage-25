"""Internal schemas for {{MODEL_KEY}} model actions."""

from __future__ import annotations

from aimp_framework.base import IntegerField, Schema, TextField


class GenerateInput(Schema):
    prompt = TextField(required=True)
    max_tokens = IntegerField(required=False, default=100, min=1)


class GenerateOutput(Schema):
    text = TextField(required=True)
    tokens_used = IntegerField(required=True)


class ProcessInput(Schema):
    query = TextField(required=True)


class ProcessOutput(Schema):
    result = TextField(required=True)
