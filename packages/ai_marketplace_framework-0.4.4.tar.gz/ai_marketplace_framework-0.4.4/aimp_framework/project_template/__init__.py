"""Framework-owned canonical project template."""
