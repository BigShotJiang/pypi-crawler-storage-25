"""Low-level framework primitives used by the SDK."""

from __future__ import annotations

from enum import Enum
from typing import Any, ClassVar


_MISSING = object()


class Engine:
    """Base class for model execution engines."""

    def load(self) -> Any:
        raise NotImplementedError(f"{type(self).__name__} must implement load(self)")

    def build(self) -> None:
        pass

    def teardown(self) -> None:
        pass

    def apply_adapter(self, adapter_path: str, adapter_name: str) -> None:
        raise NotImplementedError(
            f"{type(self).__name__} does not support adapters; "
            "implement apply_adapter(self, adapter_path, adapter_name)"
        )


class Metric(str, Enum):
    """Supported vector similarity metrics."""

    COSINE = "cosine"
    DOT = "dot"
    EUCLIDEAN = "euclidean"


def _is_json_value(value: Any) -> bool:
    if value is None or isinstance(value, (str, int, float, bool)):
        return True
    if isinstance(value, list):
        return all(_is_json_value(item) for item in value)
    if isinstance(value, dict):
        return all(
            isinstance(key, str) and _is_json_value(item) for key, item in value.items()
        )
    return False


class Field:
    """Base class for all schema field types."""

    kind: str = "text"
    supports_range_lookups: ClassVar[bool] = False

    def __init__(
        self,
        *,
        description: str | None = None,
        label: str | None = None,
        required: bool = True,
        default: Any = _MISSING,
        multiple: bool = False,
        filterable: bool = False,
    ) -> None:
        self.name: str = ""
        self.description = description
        self.label = label
        self.required = required
        self.default = default
        self.multiple = multiple
        self.filterable = filterable

    def contract(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "name": self.name,
            "kind": self.kind,
            "required": self.required,
        }
        if self.description:
            payload["description"] = self.description
        if self.label:
            payload["label"] = self.label
        if self.default is not _MISSING:
            payload["default"] = self.default
        if self.multiple:
            payload["multiple"] = True
        return payload

    def has_default(self) -> bool:
        return self.default is not _MISSING

    def validate_value(self, value: Any, *, field_name: str | None = None) -> None:
        target = field_name or self.name or "value"
        if self.multiple:
            if not isinstance(value, (list, tuple)):
                raise TypeError(f"{target} must be a list.")
            for item in value:
                self._validate_scalar(item, field_name=target)
            return
        self._validate_scalar(value, field_name=target)

    def _validate_scalar(self, value: Any, *, field_name: str) -> None:
        _ = value, field_name

    def validate_lookup(self, lookup: str, value: Any, *, field_name: str) -> None:
        if lookup == "exact":
            self.validate_value(value, field_name=field_name)
            return
        if lookup == "in":
            if not isinstance(value, (list, tuple)):
                raise TypeError(f"{field_name}__in must be a list or tuple.")
            for item in value:
                self.validate_value(item, field_name=field_name)
            return
        if lookup in {"gte", "lte"}:
            if not self.supports_range_lookups:
                raise TypeError(f"{field_name} does not support {lookup} lookups.")
            self.validate_value(value, field_name=field_name)
            return
        raise ValueError(f"Unsupported lookup '{lookup}' for {field_name}.")


class TextField(Field):
    kind = "text"

    def _validate_scalar(self, value: Any, *, field_name: str) -> None:
        if not isinstance(value, str):
            raise TypeError(f"{field_name} must be a string.")


class StringField(Field):
    kind = "string"

    def _validate_scalar(self, value: Any, *, field_name: str) -> None:
        if not isinstance(value, str):
            raise TypeError(f"{field_name} must be a string.")


class IntegerField(Field):
    kind = "integer"
    supports_range_lookups = True

    def __init__(
        self,
        *,
        min: int | None = None,
        max: int | None = None,
        step: int | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.min = min
        self.max = max
        self.step = step

    def contract(self) -> dict[str, Any]:
        payload = super().contract()
        if self.min is not None:
            payload["min"] = self.min
        if self.max is not None:
            payload["max"] = self.max
        if self.step is not None:
            payload["step"] = self.step
        return payload

    def _validate_scalar(self, value: Any, *, field_name: str) -> None:
        if isinstance(value, bool) or not isinstance(value, int):
            raise TypeError(f"{field_name} must be an integer.")
        if self.min is not None and value < self.min:
            raise ValueError(f"{field_name} must be >= {self.min}.")
        if self.max is not None and value > self.max:
            raise ValueError(f"{field_name} must be <= {self.max}.")


class NumberField(Field):
    kind = "number"
    supports_range_lookups = True

    def __init__(
        self,
        *,
        min: float | None = None,
        max: float | None = None,
        step: float | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.min = min
        self.max = max
        self.step = step

    def contract(self) -> dict[str, Any]:
        payload = super().contract()
        if self.min is not None:
            payload["min"] = self.min
        if self.max is not None:
            payload["max"] = self.max
        if self.step is not None:
            payload["step"] = self.step
        return payload

    def _validate_scalar(self, value: Any, *, field_name: str) -> None:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"{field_name} must be a number.")
        number = float(value)
        if self.min is not None and number < self.min:
            raise ValueError(f"{field_name} must be >= {self.min}.")
        if self.max is not None and number > self.max:
            raise ValueError(f"{field_name} must be <= {self.max}.")


class BooleanField(Field):
    kind = "boolean"

    def _validate_scalar(self, value: Any, *, field_name: str) -> None:
        if not isinstance(value, bool):
            raise TypeError(f"{field_name} must be a boolean.")


class SelectField(Field):
    kind = "select"

    def __init__(self, *, options: list[str], **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.options = options

    def contract(self) -> dict[str, Any]:
        payload = super().contract()
        payload["options"] = [{"value": opt} for opt in self.options]
        return payload

    def _validate_scalar(self, value: Any, *, field_name: str) -> None:
        if value not in self.options:
            raise ValueError(
                f"{field_name} must be one of: {', '.join(str(item) for item in self.options)}"
            )


class ImageField(Field):
    kind = "image"


class AudioField(Field):
    kind = "audio"


class VideoField(Field):
    kind = "video"


class FileField(Field):
    kind = "file"


class JsonField(Field):
    kind = "json"

    def _validate_scalar(self, value: Any, *, field_name: str) -> None:
        if not _is_json_value(value):
            raise TypeError(f"{field_name} must be JSON-serializable.")


class ListField(Field):
    """A typed list output field that describes the shape of each item.

    Use this instead of ``JsonField`` when the output is a list of objects
    with a known structure.  The ``item_schema`` maps item key names to
    ``Field`` instances that describe each key's type.

    Example::

        matches = ListField(
            item_schema={
                "image_id": StringField(),
                "filename": StringField(),
                "score":    NumberField(),
            },
            required=True,
        )
    """

    kind = "json"

    def __init__(self, *, item_schema: dict[str, "Field"], **kwargs: Any) -> None:
        super().__init__(**kwargs)
        if not isinstance(item_schema, dict) or not item_schema:
            raise ValueError("ListField requires a non-empty item_schema dict.")
        for key, field in item_schema.items():
            if not isinstance(key, str) or not key.strip():
                raise ValueError("ListField item_schema keys must be non-empty strings.")
            if not isinstance(field, Field):
                raise TypeError(
                    f"ListField item_schema[{key!r}] must be a Field instance, "
                    f"got {type(field).__name__}."
                )
        self.item_schema: dict[str, "Field"] = dict(item_schema)

    def contract(self) -> dict[str, Any]:
        payload = super().contract()
        payload["items"] = {
            name: {"kind": field.kind, "name": name}
            for name, field in self.item_schema.items()
        }
        return payload

    def _validate_scalar(self, value: Any, *, field_name: str) -> None:
        if not isinstance(value, list):
            raise TypeError(f"{field_name} must be a list.")
        for i, item in enumerate(value):
            if not isinstance(item, dict):
                raise TypeError(f"{field_name}[{i}] must be a dict.")
            if not _is_json_value(item):
                raise TypeError(f"{field_name}[{i}] must be JSON-serializable.")


class Schema:
    """Django-style base class for input/output/parameter declarations."""

    _fields: ClassVar[dict[str, Field]] = {}
    __schema_role__: ClassVar[str | None] = None

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        fields: dict[str, Field] = {}
        for name, value in cls.__dict__.items():
            if isinstance(value, Field):
                value.name = name
                fields[name] = value
        cls._fields = fields

    def __init__(self, **data: Any) -> None:
        values = type(self)._validated_values(data)
        for name, value in values.items():
            setattr(self, name, value)

    @classmethod
    def _validated_values(cls, data: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(data, dict):
            raise TypeError(f"{cls.__name__} expects a dict, got {type(data).__name__}")

        unknown = sorted(set(data) - set(cls._fields))
        if unknown:
            raise ValueError(
                f"{cls.__name__} received unknown fields: {', '.join(unknown)}"
            )

        values: dict[str, Any] = {}
        for name, field in cls._fields.items():
            if name in data:
                value = data[name]
                if value is None and not field.required:
                    values[name] = None
                    continue
                field.validate_value(value, field_name=name)
                values[name] = value
            elif field.default is not _MISSING:
                field.validate_value(field.default, field_name=name)
                values[name] = field.default
            elif field.required:
                raise ValueError(f"{cls.__name__} requires field '{name}'")
            else:
                values[name] = None

        return values

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Schema:
        if not isinstance(data, dict):
            raise TypeError(f"{cls.__name__} expects a dict, got {type(data).__name__}")
        return cls(**data)

    @classmethod
    def validate(cls, data: dict[str, Any]) -> Schema:
        return cls.from_dict(data)

    @classmethod
    def contract(cls) -> list[dict[str, Any]]:
        return [field.contract() for field in cls._fields.values()]


Schema.Inputs = type(
    "Inputs",
    (Schema,),
    {"__schema_role__": "inputs", "__module__": __name__},
)
Schema.Outputs = type(
    "Outputs",
    (Schema,),
    {"__schema_role__": "outputs", "__module__": __name__},
)
Schema.Params = type(
    "Params",
    (Schema,),
    {"__schema_role__": "params", "__module__": __name__},
)
