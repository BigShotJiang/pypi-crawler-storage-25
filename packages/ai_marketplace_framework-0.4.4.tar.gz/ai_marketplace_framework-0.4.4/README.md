# ai-marketplace-framework

Low-level primitives for AI Marketplace SDK internals.

## Install

```bash
python -m pip install ai-marketplace-framework
```

## What It Provides

`ai-marketplace-framework` contains low-level building blocks used by
`ai-marketplace-sdk` (schema fields, schema validation, and engine base types).
Agent/Mode/Model authoring belongs to `ai-marketplace-sdk`.

Framework-owned canonical project templates live under
`aimp_framework.project_template`. CLI bootstrap tools consume these files as-is;
they do not define architecture.

## Minimal Example

```python
from aimp_framework.base import Engine, Schema, TextField


class ExampleInput(Schema):
    prompt = TextField(required=True)


class ExampleEngine(Engine):
    def load(self):
        return None
```

## Project Links

- Repository: https://github.com/zakariaalmoktar/AI-Marketplace-Platform
- Issues: https://github.com/zakariaalmoktar/AI-Marketplace-Platform/issues
