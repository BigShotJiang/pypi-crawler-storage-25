"""Tests for the Schema and Field system."""

import pytest
from aimp_framework.base import (
    Schema,
    TextField,
    IntegerField,
    NumberField,
    BooleanField,
    SelectField,
    JsonField,
    ListField,
    StringField,
)


class SampleSchema(Schema):
    name = TextField(description="A name", required=True)
    count = IntegerField(default=0, min=0, max=100, description="A count")
    score = NumberField(default=0.5, min=0.0, max=1.0, step=0.1)
    active = BooleanField(default=True)
    category = SelectField(options=["a", "b", "c"], default="a")
    data = JsonField(required=False)


class TestSchema:
    def test_fields_collected_on_subclass(self):
        assert "name" in SampleSchema._fields
        assert "count" in SampleSchema._fields
        assert "score" in SampleSchema._fields
        assert "active" in SampleSchema._fields
        assert "category" in SampleSchema._fields
        assert "data" in SampleSchema._fields

    def test_field_names_assigned(self):
        assert SampleSchema._fields["name"].name == "name"
        assert SampleSchema._fields["count"].name == "count"

    def test_validate_full_data(self):
        s = SampleSchema.validate({"name": "test", "count": 5, "score": 0.8})
        assert s.name == "test"
        assert s.count == 5
        assert s.score == 0.8

    def test_validate_with_defaults(self):
        s = SampleSchema.validate({"name": "test"})
        assert s.name == "test"
        assert s.count == 0
        assert s.score == 0.5
        assert s.active is True
        assert s.category == "a"

    def test_validate_optional_field_none(self):
        s = SampleSchema.validate({"name": "test"})
        assert s.data is None

    def test_validate_missing_required_field(self):
        with pytest.raises(ValueError, match="requires field 'name'"):
            SampleSchema.validate({})

    def test_validate_unknown_field(self):
        with pytest.raises(ValueError, match="unknown fields"):
            SampleSchema.validate({"name": "x", "bogus": 1})

    def test_validate_rejects_non_dict(self):
        with pytest.raises(TypeError, match="expects a dict"):
            SampleSchema.validate("not a dict")

    def test_constructor_accepts_kwargs(self):
        sample = SampleSchema(name="alpha", count=2, score=0.9)
        assert sample.name == "alpha"
        assert sample.count == 2
        assert sample.score == 0.9

    def test_from_dict_matches_validate(self):
        from_dict = SampleSchema.from_dict({"name": "beta", "count": 3})
        validated = SampleSchema.validate({"name": "beta", "count": 3})
        assert from_dict.name == validated.name
        assert from_dict.count == validated.count

    def test_constructor_rejects_unknown(self):
        with pytest.raises(ValueError, match="unknown fields"):
            SampleSchema(name="x", bogus=1)


class TestFieldContract:
    def test_text_field_contract(self):
        field = TextField(description="A name", required=True)
        field.name = "name"
        c = field.contract()
        assert c["name"] == "name"
        assert c["kind"] == "text"
        assert c["required"] is True
        assert c["description"] == "A name"
        assert "default" not in c

    def test_integer_field_contract(self):
        field = IntegerField(default=10, min=0, max=100, step=5)
        field.name = "count"
        c = field.contract()
        assert c["kind"] == "integer"
        assert c["default"] == 10
        assert c["min"] == 0
        assert c["max"] == 100
        assert c["step"] == 5

    def test_number_field_contract(self):
        field = NumberField(default=0.5, min=0.0, max=1.0, step=0.1, label="Score")
        field.name = "score"
        c = field.contract()
        assert c["kind"] == "number"
        assert c["label"] == "Score"

    def test_select_field_contract(self):
        field = SelectField(options=["x", "y", "z"], default="x")
        field.name = "choice"
        c = field.contract()
        assert c["kind"] == "select"
        assert c["options"] == [{"value": "x"}, {"value": "y"}, {"value": "z"}]

    def test_boolean_field_contract(self):
        field = BooleanField(default=True, description="Toggle")
        field.name = "active"
        c = field.contract()
        assert c["kind"] == "boolean"
        assert c["default"] is True

    def test_list_field_contract_uses_public_json_kind(self):
        field = ListField(
            item_schema={
                "image_id": StringField(),
                "filename": StringField(),
            }
        )
        field.name = "matches"
        c = field.contract()
        assert c["kind"] == "json"
        assert c["items"] == {
            "image_id": {"kind": "string", "name": "image_id"},
            "filename": {"kind": "string", "name": "filename"},
        }


class TestSchemaContract:
    def test_contract_generates_list(self):
        contract = SampleSchema.contract()
        assert isinstance(contract, list)
        assert len(contract) == 6

    def test_contract_field_names(self):
        contract = SampleSchema.contract()
        names = [f["name"] for f in contract]
        assert "name" in names
        assert "count" in names

    def test_contract_playground_ui_fields(self):
        contract = SampleSchema.contract()
        count_field = next(f for f in contract if f["name"] == "count")
        assert count_field["min"] == 0
        assert count_field["max"] == 100
        assert count_field["default"] == 0

        score_field = next(f for f in contract if f["name"] == "score")
        assert score_field["min"] == 0.0
        assert score_field["max"] == 1.0
        assert score_field["step"] == 0.1
