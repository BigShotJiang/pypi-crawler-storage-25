"""Security utilities for Netcanon."""
