"""The Architect CLI — pure terminal interface.

Planning uses interactive prompts (questionary arrow-key menus).
Execution streams opencode output raw to the terminal — no TUI overlay.
Results are written to tasks/SUMMARY.md and printed as a terminal summary.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import shlex
import subprocess
import sys
import time
from collections.abc import Callable, Generator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

# Set ESCDELAY before any textual import so Textual's constants module picks
# it up. The default (100ms) makes ESC feel laggy — 30ms is below human
# perception but long enough to distinguish bare ESC from ANSI sequences.
# Only set if the user hasn't explicitly overridden it.
if "ESCDELAY" not in os.environ:
    os.environ["ESCDELAY"] = "30"

if TYPE_CHECKING:
    from prompt_toolkit.output import Output
    from prompt_toolkit.styles import Style as PromptStyle

    from the_architect.core.circuit import CircuitBreaker
    from the_architect.core.presets import Preset
    from the_architect.core.project_health import HealthCheck
    from the_architect.core.resume_verification import ResumeVerificationResult
    from the_architect.core.templates import GoalTemplate

from datetime import UTC

import click
from loguru import logger
from prompt_toolkit.layout.dimension import D
from rich.console import Console
from rich.markup import escape

from the_architect import __full_version__, __version__
from the_architect.config import ArchitectConfig, load_config, write_config
from the_architect.core.cost_analytics import CostAnalytics
from the_architect.core.estimate_cost import EstimateResult
from the_architect.core.hooks import (
    HookEvent,
    HookResult,
    execute_hooks_for_event,
    load_hooks,
)
from the_architect.core.monitor_state import MonitorStateWriter
from the_architect.core.planner import (
    GOAL_FILE_NAME,
    PlanningFailedError,
    PlanningRequest,
    check_pending_tasks,
    run_planner,
)
from the_architect.core.progress import (
    find_failed_tasks,
    reconcile_progress_with_task_files,
    reconcile_task_status,
    task_is_done,
    task_is_resolved,
    task_status,
)
from the_architect.core.provider import (
    ArchitectProvider,
    ProviderNotFoundError,
    detect_available_providers,
    detect_provider,
    supported_providers,
)
from the_architect.core.provider_setup import ensure_provider_setup
from the_architect.core.retrospective import (
    RetrospectiveRequest,
    run_retrospective,
    run_task_reassessment,
)
from the_architect.core.runner import (
    TaskResult,
    TokenUsage,
    run_all,
    run_task,
    setup_logging,
)
from the_architect.core.success import (
    RetrospectiveRound,
    notify_run_completion,
    print_success_summary,
    write_success_md,
)
from the_architect.core.tasks import (
    Task,
    TaskPlan,
    TaskScope,
    TaskStatus,
    discover_tasks,
    duplicate_task_prefixes,
    is_retro_task,
    task_sort_key,
)
from the_architect.core.token_ledger import (
    LedgerRunRecord,
    LedgerTaskRecord,
    TokenLedger,
    append_run,
    load_ledger,
    save_ledger,
)
from the_architect.tui.screens.pre_run import BACK_SENTINEL

console = Console()

GOAL_DISPLAY_LIMIT = 400
_PERSISTENT_MAX_RETRIES = 30
_PERSISTENT_RETROSPECTIVE_ROUNDS = 3
_PERSISTENT_FIXUP_ATTEMPTS = 5
_INFINITE_LOOP_RETROSPECTIVE_ROUNDS = 2


@dataclass(frozen=True)
class CycleValidationResult:
    """Deterministic validation result for a completed execution/review cycle."""

    passed: bool
    reason: str = ""
    unresolved_tasks: tuple[str, ...] = ()


def _truncate_goal_for_display(goal: str, limit: int = GOAL_DISPLAY_LIMIT) -> str:
    """Return a bounded single-line goal summary for terminal/TUI headers."""
    normalized = " ".join(goal.split())
    if len(normalized) <= limit:
        return normalized
    return normalized[:limit] + "..."


async def _fire_hooks(
    project: Path,
    event: HookEvent,
    context: dict[str, str] | None = None,
    renderer: object | None = None,
) -> list[HookResult]:
    """Fire all enabled hooks for *event* in *project*.

    Non-blocking, non-fatal — hook failures are logged but never
    propagate to the caller.  Follows the notification silent-failure
    pattern from ``notifications.py``.

    Args:
        project: The project root directory.
        event: The lifecycle event to fire hooks for.
        context: Optional environment variables to inject into the subprocess.
        renderer: Optional TUI renderer for pushing hook events to
            the diagnostics tab.

    Returns:
        List of HookResult objects (one per matching enabled hook).
    """
    try:
        hooks = load_hooks(project)
        if not hooks:
            return []
        results = await execute_hooks_for_event(hooks, event, context=context)
        for r in results:
            if r.exit_code != 0:
                logger.warning(f"Hook '{event}' failed (exit {r.exit_code}): {r.command!r}")
            else:
                logger.info(f"Hook '{event}' completed: {r.command!r}")
            # Push hook execution event to the TUI diagnostics tab
            if renderer is not None:
                try:
                    renderer.push_event_line(  # type: ignore[attr-defined]
                        "hooks",
                        {
                            "event": str(r.event),
                            "command": r.command,
                            "exit_code": str(r.exit_code),
                            "duration": f"{r.duration_seconds:.1f}s",
                        },
                    )
                except Exception:
                    pass
        return results
    except Exception as exc:
        logger.debug(f"Hook execution failed (non-fatal): {exc!r}")
        return []


# ---------------------------------------------------------------------------
# Alternate screen buffer — clean terminal like opencode, vim, htop
# ---------------------------------------------------------------------------


@contextmanager
def alternate_screen() -> Generator[None, None, None]:
    """Enter the terminal alternate screen buffer, restoring the original on exit.

    When the architect starts, it switches to a fresh, empty alternate screen
    — just like ``vim``, ``htop``, ``lazygit``, and ``opencode`` do.  When it
    exits (normally, on error, or Ctrl+C), the original terminal content is
    restored exactly as it was.

    This is a no-op when stdout is not a real TTY (e.g. piped output, Click
    test runner) so that automated tools and tests are not affected.

    On Windows, VT (Virtual Terminal) processing is enabled on both stdout and
    stderr before writing the escape sequence.  Modern Windows Terminal and
    PowerShell 5.1+ support VT natively, but the Windows console host
    (conhost.exe) requires an explicit ``SetConsoleMode`` call to activate it.
    Without this, the escape bytes appear as literal characters instead of
    switching the alternate screen.

    Uses ANSI escape sequence ``CSI ? 1049 h`` (enter alternate screen +
    save cursor) and ``CSI ? 1049 l`` (exit alternate screen + restore cursor).
    """
    if not sys.stdout.isatty():
        yield
        return

    # Enable VT processing on Windows so the ANSI escapes work in conhost.exe
    # (Windows Terminal / PowerShell 7 have VT on by default, but this is
    # harmless there and required for PowerShell 5.1 / classic cmd.exe).
    # INVALID_HANDLE_VALUE is 0xFFFFFFFF (unsigned) which ctypes returns as a
    # large positive integer on 64-bit Python, or as -1 on 32-bit. We compare
    # against both to be safe.
    if sys.platform == "win32":
        try:
            import ctypes
            import ctypes.wintypes

            ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
            ENABLE_PROCESSED_OUTPUT = 0x0001
            INVALID_HANDLE_VALUE = 0xFFFFFFFFFFFFFFFF  # 64-bit; ctypes also returns -1 on 32-bit
            kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
            for handle_id in (-10, -11, -12):  # stdin, stdout, stderr
                handle = kernel32.GetStdHandle(handle_id)
                if handle and handle not in (0xFFFFFFFF, INVALID_HANDLE_VALUE, -1):
                    mode = ctypes.wintypes.DWORD(0)
                    if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                        kernel32.SetConsoleMode(
                            handle,
                            mode.value
                            | ENABLE_VIRTUAL_TERMINAL_PROCESSING
                            | ENABLE_PROCESSED_OUTPUT,
                        )
        except Exception:
            pass  # Non-fatal — fall through and try the escape sequence anyway

    # Enter alternate screen buffer + save cursor
    sys.stdout.write("\033[?1049h")
    sys.stdout.flush()

    try:
        yield
    finally:
        # Exit alternate screen and disable any terminal input modes a nested
        # TUI/provider may have left enabled.
        sys.stdout.write("\033[?1049l")
        sys.stdout.flush()
        try:
            from the_architect.tui.terminal import restore_terminal_input_modes

            restore_terminal_input_modes()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------


def _setup_loguru() -> None:
    """Configure loguru — INFO to stderr, no timestamps in normal mode."""
    logger.remove()
    logger.add(
        sys.stderr,
        format="<level>{level: <8}</level> | {message}",
        level="WARNING",
        colorize=sys.stderr.isatty() and not bool(os.environ.get("NO_COLOR")),
    )


# ---------------------------------------------------------------------------
# Task helpers
# ---------------------------------------------------------------------------


def _provider_has_any_models() -> bool:
    """Check whether the active provider can list at least one model.

    Uses auto-detection to find the installed provider.

    Returns:
        True if the provider has at least one model available.
    """
    try:
        from the_architect.core.provider import detect_provider

        return detect_provider("auto").has_any_models()
    except Exception:
        return False


# Backward-compatible alias — tests import this name
_opencode_has_any_models = _provider_has_any_models


def _apply_persistent_mode(config: ArchitectConfig, enabled: bool | None = None) -> None:
    """Apply persistent-mode derived settings to a runtime config."""
    if enabled is not None:
        config.persistent = enabled

    if config.persistent:
        config.max_retries = _PERSISTENT_MAX_RETRIES
        config.retrospective_rounds = _PERSISTENT_RETROSPECTIVE_ROUNDS
        # Also increase fixup_attempts for more resilient gate recovery
        if "fixup_attempts" not in config.validation_gate:
            config.validation_gate["fixup_attempts"] = _PERSISTENT_FIXUP_ATTEMPTS


def _infinite_loop_active(config: ArchitectConfig) -> bool:
    """Return whether this config is inside an active Infinite Loop chain."""
    return bool(
        getattr(config, "_infinite_loop_enabled", False)
        or getattr(config, "_infinite_loop_chain_enabled", False)
    )


def _apply_infinite_loop_mode(config: ArchitectConfig) -> None:
    """Apply Infinite Loop runtime settings without enabling Persistent Mode."""
    if not _infinite_loop_active(config) or config.persistent:
        return
    config.retrospective_rounds = max(
        config.retrospective_rounds,
        _INFINITE_LOOP_RETROSPECTIVE_ROUNDS,
    )


def _filter_and_set_status(tasks: list[Task], progress_file: Path) -> list[Task]:
    """Return tasks with their status mirrored from PROGRESS.md (read-only, no mutation).

    Mapping:
      - ``Done``   → :class:`TaskStatus.DONE`
      - ``Failed`` → :class:`TaskStatus.FAILED`
      - ``Blocked`` and ``Pending`` (and anything else) → the task's original
        status, which is :class:`TaskStatus.PENDING` coming from
        :func:`discover_tasks`.

    Callers use the resulting statuses to drive the resume screen, the
    status tables, and skip decisions.  Anything that should be skipped
    silently by the main execution loop is now also filtered by
    :func:`the_architect.core.progress.task_is_resolved` inside
    ``_run_all_inner`` — this helper exists mainly for UI layers.
    """
    result: list[Task] = []
    for task in tasks:
        status = task_status(progress_file, task.prefix)
        if status == "Done":
            new_status = TaskStatus.DONE
        elif status == "Failed":
            new_status = TaskStatus.FAILED
        else:
            # Pending, Blocked, missing row — carry the task's existing
            # status (PENDING by default) so the UI doesn't misrepresent it.
            result.append(task)
            continue
        result.append(
            Task(
                name=task.name,
                prefix=task.prefix,
                number=task.number,
                path=task.path,
                title=task.title,
                status=new_status,
                depends_on=task.depends_on,
            )
        )
    return result


def _infinite_loop_should_continue_after_exit(
    config: ArchitectConfig,
    exc: SystemExit,
    *,
    chain_enabled: bool | None = None,
) -> bool:
    """Return True when a normal ``SystemExit`` should become the next loop iteration."""
    active = _infinite_loop_active(config) or bool(chain_enabled)
    if not active:
        return False
    return exc.code is None or exc.code == 0


def _infinite_loop_has_clean_exit_state(project: Path, config: ArchitectConfig) -> bool:
    """Return True when on-disk task state is clean enough to continue the loop.

    This is a defensive guard for rare nested-flow mismatches where the run
    writes a successful summary and all task rows are terminal, but still exits
    with ``SystemExit(1)``. Infinite Loop should not stop on that false negative.
    Real incomplete or failed cycles remain blocking because validation catches
    pending work and unrecovered failed/blocked original tasks.
    """
    tasks_dir = project / config.tasks_dir.name
    if not config.progress_file.exists():
        return False
    if not discover_tasks(tasks_dir):
        return False
    if check_pending_tasks(tasks_dir, config.progress_file):
        return False
    return _validate_cycle(tasks_dir, config.progress_file).passed


def _infinite_loop_reset_sleep_interrupted_tasks(project: Path, config: ArchitectConfig) -> int:
    """Reset tasks that failed only due to sleep/wake gaps back to Pending.

    When the host machine sleeps mid-run and the Architect's sleep-wake gap
    detector kills the provider subprocess, the attempt is not a real failure.
    After wake, the Infinite Loop driver calls this to rewrite those tasks'
    PROGRESS.md rows from ``Failed`` → ``Pending`` so the next iteration
    picks them up normally.

    Returns the number of tasks reset.  Returns 0 when there are no
    sleep-interrupted tasks or PROGRESS.md can't be read.
    """
    from the_architect.core.runner import get_sleep_interrupted_tasks

    sleep_tasks = get_sleep_interrupted_tasks()
    if not sleep_tasks:
        return 0

    progress_file = config.progress_file
    if not progress_file.exists():
        return 0

    try:
        content = progress_file.read_text(encoding="utf-8")
    except OSError:
        return 0

    import re

    reset_count = 0
    new_lines: list[str] = []
    for line in content.splitlines(keepends=True):
        # Match PROGRESS.md task rows: | T07 | ... | Failed | ... |
        # The status column is the 3rd pipe-delimited field.
        m = re.match(r"^(\|\s*)(T\w+|R\w+)(\s*\|[^|]*\|)\s*Failed\s*(\|.*)$", line)
        if m and m.group(2).strip() in sleep_tasks:
            # Replace "Failed" with "Pending" for sleep-only failures
            line = f"{m.group(1)}{m.group(2)}{m.group(3)} Pending {m.group(4)}\n"
            reset_count += 1
            logger.info(
                f"Infinite Loop: reset sleep-interrupted task "
                f"{m.group(2).strip()} from Failed → Pending"
            )
        new_lines.append(line)

    if reset_count > 0:
        try:
            progress_file.write_text("".join(new_lines), encoding="utf-8")
        except OSError as exc:
            logger.warning(f"Infinite Loop: failed to write PROGRESS.md reset: {exc!r}")
            return 0

    return reset_count


def _infinite_loop_reset_idle_timeout_tasks(project: Path, config: ArchitectConfig) -> int:
    """Reset tasks that failed only due to provider idle timeouts back to Pending.

    When the provider subprocess went silent and was killed by the idle-timeout
    watchdog, the attempt is an environmental event — not a real agent failure.
    The Infinite Loop driver calls this to rewrite those tasks' PROGRESS.md rows
    from ``Failed`` → ``Pending`` so the next iteration picks them up normally.

    Returns the number of tasks reset.  Returns 0 when there are no
    idle-timeout tasks or PROGRESS.md can't be read.
    """
    from the_architect.core.runner import get_idle_timeout_tasks

    idle_tasks = get_idle_timeout_tasks()
    if not idle_tasks:
        return 0

    progress_file = config.progress_file
    if not progress_file.exists():
        return 0

    try:
        content = progress_file.read_text(encoding="utf-8")
    except OSError:
        return 0

    import re

    reset_count = 0
    new_lines: list[str] = []
    for line in content.splitlines(keepends=True):
        m = re.match(r"^(\|\s*)(T\w+|R\w+)(\s*\|[^|]*\|)\s*Failed\s*(\|.*)$", line)
        if m and m.group(2).strip() in idle_tasks:
            line = f"{m.group(1)}{m.group(2)}{m.group(3)} Pending {m.group(4)}\n"
            reset_count += 1
            logger.info(
                f"Infinite Loop: reset idle-timeout task {m.group(2).strip()} from Failed → Pending"
            )
        new_lines.append(line)

    if reset_count > 0:
        try:
            progress_file.write_text("".join(new_lines), encoding="utf-8")
        except OSError as exc:
            logger.warning(
                f"Infinite Loop: failed to write PROGRESS.md idle-timeout reset: {exc!r}"
            )
            return 0

    return reset_count


def _infinite_loop_success_after_clean_failure(
    *,
    success: bool,
    project: Path,
    config: ArchitectConfig,
    return_on_success: bool,
) -> bool:
    """Return effective loop success after a false-negative nested failure."""
    if success:
        return True
    if not (return_on_success or _infinite_loop_active(config)):
        return False
    try:
        if _infinite_loop_has_clean_exit_state(project, config):
            tasks_dir = project / config.tasks_dir.name
            tasks = _filter_and_set_status(discover_tasks(tasks_dir), config.progress_file)
            _recover_missing_summary_for_terminal_tasks(project, tasks, tasks_dir, config)
            logger.warning(
                "Infinite Loop: nested run reported failure after clean task state; "
                "treating cycle as successful so the loop can continue"
            )
            return True
    except Exception as exc:
        logger.debug(f"Infinite Loop clean-state check failed: {exc!r}")
    return False


def _monitor_state_needs_killed_finalizer(current_status: str) -> bool:
    """Return True when the global finalizer should mark the run killed."""
    from the_architect.core.monitor_state import (
        RUN_STATUS_DONE,
        RUN_STATUS_FAILED,
        RUN_STATUS_KILLED,
    )

    return current_status not in (RUN_STATUS_DONE, RUN_STATUS_FAILED, RUN_STATUS_KILLED)


def _task_is_terminal(task: Task) -> bool:
    """Return True if a task's in-memory status is terminal (no more work).

    Terminal statuses are ``DONE`` and ``FAILED``.  ``BLOCKED`` is not yet
    represented in :class:`TaskStatus` — blocked PROGRESS.md rows round-trip
    through :func:`_filter_and_set_status` as ``PENDING``, which is
    deliberate: a blocked task will be retried on the next loop when the
    resource constraint (rate-limit, budget) lifts, so treating it as
    non-terminal at the CLI layer is correct.

    Prefer this helper over raw ``t.status == TaskStatus.DONE`` wherever the
    intent is "there is no outstanding work on this task" — a ``Failed``
    task is resolved just as firmly as a ``Done`` one, and silently lumping
    it into "pending" causes the retrospective-loop regression.
    """
    return task.status in (TaskStatus.DONE, TaskStatus.FAILED)


def _task_needs_work(task: Task) -> bool:
    """Inverse of :func:`_task_is_terminal` — ``True`` when the task is pending.

    Provided as a readable complement at call sites that filter by "still
    needs to run".  Equivalent to ``not _task_is_terminal(task)``.
    """
    return not _task_is_terminal(task)


def _resolve_infinite_loop_goal(
    current_goal: str,
    config: ArchitectConfig,
    tasks_dir: Path,
) -> str:
    """Return the goal to reuse for the next Infinite Loop planning pass."""
    goal_file_goal = _read_goal_md(tasks_dir).strip()
    if goal_file_goal:
        goal = goal_file_goal
    elif current_goal.strip():
        goal = current_goal.strip()
    else:
        stored_goal = str(getattr(config, "_infinite_loop_goal", "") or "").strip()
        goal = stored_goal or _read_goal_from_instructions(tasks_dir).strip()

    if goal:
        config._infinite_loop_goal = goal  # type: ignore[attr-defined]
    return goal


def _validate_cycle(tasks_dir: Path, progress_file: Path) -> CycleValidationResult:
    """Validate that the current execution/retrospective cycle is fully clean."""
    if not progress_file.exists():
        logger.debug("Skipping cycle validation because PROGRESS.md does not exist")
        return CycleValidationResult(True)

    discovered = discover_tasks(tasks_dir)
    repaired = reconcile_progress_with_task_files(progress_file, discovered)
    if repaired:
        logger.info("Reconciled missing PROGRESS.md task rows: " + ", ".join(repaired))
    if not discovered:
        return CycleValidationResult(False, "No task files were found after execution.")

    pending: list[str] = []
    failed_recovery: list[str] = []
    failed_original: list[str] = []
    done_recovery = False

    for task in discovered:
        status = task_status(progress_file, task.prefix)
        display = f"{task.prefix} {task.title or task.name} ({status or 'Missing'})"
        if is_retro_task(task.prefix) and status == "Done":
            done_recovery = True
        if status in (None, "Pending", "Running"):
            pending.append(display)
        elif is_retro_task(task.prefix) and status in ("Failed", "Blocked"):
            failed_recovery.append(display)
        elif not is_retro_task(task.prefix) and status in ("Failed", "Blocked"):
            failed_original.append(display)

    if pending:
        return CycleValidationResult(
            False,
            "Pending work remains after retrospective validation.",
            tuple(pending),
        )
    if failed_recovery:
        return CycleValidationResult(
            False,
            "Recovery tasks failed or were blocked during retrospective validation.",
            tuple(failed_recovery),
        )
    if failed_original and not done_recovery:
        return CycleValidationResult(
            False,
            "Original tasks failed or were blocked, and no successful recovery task was completed.",
            tuple(failed_original),
        )
    return CycleValidationResult(True)


def _format_cycle_validation_feedback(result: CycleValidationResult) -> str:
    """Return a reviewer-readable explanation of a failed cycle validation."""
    if result.passed:
        return ""
    lines = [result.reason or "Cycle validation failed."]
    if result.unresolved_tasks:
        lines.append("")
        lines.append("Unresolved tasks:")
        lines.extend(f"- {task}" for task in result.unresolved_tasks)
    return "\n".join(lines)


def _write_cycle_validation_to_progress(
    progress_file: Path,
    result: CycleValidationResult,
    round_number: int,
) -> None:
    """Persist deterministic cycle validation details into PROGRESS.md."""
    if not progress_file.exists():
        return
    try:
        content = progress_file.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return

    status = "Passed" if result.passed else "Failed"
    lines = [
        "## Cycle Validation",
        "",
        f"**Round:** {round_number}",
        f"**Status:** {status}",
    ]
    if result.reason:
        lines.append(f"**Reason:** {result.reason}")
    if result.unresolved_tasks:
        lines.append("")
        lines.append("### Unresolved Tasks")
        lines.extend(f"- {task}" for task in result.unresolved_tasks)
    section = "\n".join(lines).rstrip() + "\n"

    pattern = re.compile(r"\n## Cycle Validation\s*\n.*?(?=\n---|\n## |\Z)", re.DOTALL)
    if pattern.search(content):
        updated = pattern.sub("\n" + section, content, count=1)
    else:
        insert_before = "\n---\n\n## Lessons Learned"
        if insert_before in content:
            updated = content.replace(insert_before, f"\n{section}{insert_before}", 1)
        else:
            updated = content.rstrip() + "\n\n" + section

    try:
        progress_file.write_text(updated, encoding="utf-8")
    except OSError:
        return


def _recover_missing_summary_for_terminal_tasks(
    project: Path,
    tasks: list[Task],
    tasks_dir: Path,
    config: ArchitectConfig,
) -> None:
    """Write a best-effort SUMMARY.md when interrupted finalization left it missing."""
    summary_file = tasks_dir / "SUMMARY.md"
    if summary_file.exists():
        return
    recovered_results = [
        TaskResult(
            prefix=task.prefix,
            title=task.title or task.name,
            status="done" if task.status == TaskStatus.DONE else "failed",
            duration_seconds=0.0,
            attempts=0,
            tokens=TokenUsage(),
            model="",
        )
        for task in tasks
    ]
    try:
        write_success_md(
            project,
            recovered_results,
            0.0,
            TokenUsage(),
            original_goal=_resolve_infinite_loop_goal("", config, tasks_dir),
        )
        logger.info("Recovered missing tasks/SUMMARY.md for all-terminal task state")
    except Exception as exc:
        logger.warning(f"Failed to recover missing SUMMARY.md: {exc!r}")


_FORBIDDEN_RETROSPECTIVE_TASK_PATTERNS: tuple[str, ...] = (
    r"\bgit\s+checkout\b",
    r"\bgit\s+reset\b",
    r"\bgit\s+restore\b",
    r"\bgit\s+clean\b",
    r"\brm\s+-rf\b",
)


def _unsafe_retrospective_tasks(tasks: list[Task]) -> list[str]:
    """Return retro task files that contain forbidden destructive recovery instructions."""
    unsafe: list[str] = []
    for task in tasks:
        if not is_retro_task(task.prefix):
            continue
        try:
            content = task.path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for pattern in _FORBIDDEN_RETROSPECTIVE_TASK_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE):
                unsafe.append(task.path.name)
                break
    return unsafe


# ---------------------------------------------------------------------------
# The Architect brand colour constant
# ---------------------------------------------------------------------------

ARCHITECT_GREEN = "#7cc800"

# Dim horizontal rule printed after each task's status line to visually close
# one task's block before the next "══ TNN" header.  Width is intentionally
# modest (41 chars) so it reads as a subtle separator, not a full-width rule.
_SEPARATOR = "[dim]" + "─" * 41 + "[/dim]"

# Shared questionary style — The Architect green for user input and selections
_QUESTIONARY_STYLE = None
_PROMPT_LEFT_PAD = 2
_PROMPT_RIGHT_PAD = 2


def _wait_for_keypress() -> None:
    """Block until the user presses any key — cross-platform implementation.

    On POSIX systems (Linux, macOS) uses ``termios``/``tty`` to put stdin
    into raw mode so a single keystroke is read without requiring Enter.

    On Windows uses ``msvcrt.getch()`` which does the same without needing
    raw-mode setup.

    Raises on non-interactive stdin (pipe, CI, redirect) so callers can
    wrap in ``except Exception`` to skip silently.
    """
    if sys.platform == "win32":
        import msvcrt

        msvcrt.getch()
    else:
        import termios
        import tty

        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _padded_window(content: Any) -> Any:
    """Wrap prompt_toolkit content in a horizontally padded layout."""
    from prompt_toolkit.layout import Layout, VSplit, Window

    return Layout(
        VSplit(
            [
                Window(width=D.exact(_PROMPT_LEFT_PAD), dont_extend_width=True),
                Window(content=content),
                Window(width=D.exact(_PROMPT_RIGHT_PAD), dont_extend_width=True),
            ]
        )
    )


def _get_prompt_toolkit_output() -> Output:
    """Return a safe prompt_toolkit Output, falling back to DummyOutput on Windows CI.

    On Windows without a real console (e.g. CI runners, piped stdout),
    prompt_toolkit's Win32Output tries to call GetConsoleScreenBufferInfo and
    raises NoConsoleScreenBufferError.  We detect this up front and return a
    DummyOutput so interactive prompts degrade gracefully instead of crashing.

    Returns:
        A prompt_toolkit Output instance appropriate for the current environment.
    """
    try:
        from prompt_toolkit.output.defaults import create_output

        return create_output()
    except Exception:
        from prompt_toolkit.output import DummyOutput

        return DummyOutput()


def _prompt_text_input(
    title: str,
    instruction: str,
    default: str = "",
) -> str | None:
    """Prompt for free text with right-side padding in the main pane."""
    from prompt_toolkit import Application
    from prompt_toolkit.buffer import Buffer
    from prompt_toolkit.key_binding import KeyBindings, KeyPressEvent
    from prompt_toolkit.layout.controls import BufferControl
    from prompt_toolkit.styles import Style as PtStyle

    cancelled = False
    buffer = Buffer(multiline=True)
    if default:
        buffer.text = default

    kb = KeyBindings()

    @kb.add("c-c")
    def _(event: KeyPressEvent) -> None:
        nonlocal cancelled
        cancelled = True
        event.app.exit()

    @kb.add("c-m")
    def _(event: KeyPressEvent) -> None:
        event.app.exit()

    console.print(
        f"[bold {ARCHITECT_GREEN}]{title}[/bold {ARCHITECT_GREEN}]  [grey62]{instruction}[/grey62]"
    )
    from prompt_toolkit.layout import Layout, VSplit, Window

    layout = Layout(
        VSplit(
            [
                Window(content=BufferControl(buffer=buffer), wrap_lines=True),
                Window(width=D.exact(_PROMPT_RIGHT_PAD), dont_extend_width=True),
            ]
        )
    )

    pt_style = PtStyle(
        [
            ("", f"fg:{ARCHITECT_GREEN} bold"),
            ("header", f"fg:{ARCHITECT_GREEN} bold"),
            ("instruction", "fg:#666666"),
        ]
    )

    app: Application[object] = Application(
        layout=layout,
        key_bindings=kb,
        style=pt_style,
        full_screen=False,
        output=_get_prompt_toolkit_output(),
    )
    app.run()

    if cancelled:
        return None
    return buffer.text


def _questionary_style() -> PromptStyle:
    """Return the shared questionary Style with The Architect green theming.

    Lazy-imported so we don't pay the import cost at module level.

    Visual rules:
    - Cursor row (highlighted): ``›`` arrow + green bold text — NO background.
      ``noinherit`` kills the prompt_toolkit default ``reverse`` (green bg /
      dark text) that would otherwise appear on the focused row.
    - Checkbox checked item (selected): green ``●`` dot, row text normal —
      no background colour on the row itself.
    - Checkbox unchecked item: dim ``○`` dot, row text normal.
    - pointer token: green ``›`` character drawn by questionary before the row.

    Returns:
        A prompt_toolkit Style instance.
    """
    global _QUESTIONARY_STYLE
    if _QUESTIONARY_STYLE is not None:
        return _QUESTIONARY_STYLE

    from prompt_toolkit.styles import Style

    _QUESTIONARY_STYLE = Style(
        [
            ("qmark", f"fg:{ARCHITECT_GREEN} bold"),
            ("question", "bold"),
            ("answer", f"fg:{ARCHITECT_GREEN}"),
            # Cursor row: green arrow pointer drawn via pointer="›".
            # noinherit removes the default `reverse` so there is NO background
            # highlight — only the › arrow + green bold text shows the active row.
            ("highlighted", f"noinherit fg:{ARCHITECT_GREEN} bold"),
            # questionary uses class:selected for the default item in select()
            # AND for checked items in checkbox(). In both cases the item should
            # be green bold with no background — noinherit kills the reverse.
            ("selected", f"noinherit fg:{ARCHITECT_GREEN} bold"),
            # The › pointer character itself is green.
            ("pointer", f"fg:{ARCHITECT_GREEN} bold"),
            # Checkbox indicator tokens: ● green when checked, ○ dim when not.
            ("checkbox-selected", f"fg:{ARCHITECT_GREEN}"),
            ("checkbox", "fg:#666666"),
            ("instruction", "fg:#666666"),
        ]
    )
    return _QUESTIONARY_STYLE


# ---------------------------------------------------------------------------
# Interactive mode selection screen
# ---------------------------------------------------------------------------


def _prompt_provider_selection(available: list[ArchitectProvider]) -> ArchitectProvider:
    """Show an interactive provider selection screen when multiple providers are installed.

    Presented when multiple providers are detected and the
    user has not specified a preference in ``architect.toml``.


    Args:
        available: List of installed providers (at least 2).

    Returns:
        The selected :class:`~the_architect.core.provider.ArchitectProvider`.
    """
    # TUI fast-path — Phase 12. When the TUI is active, render
    # provider selection as a Textual screen so nothing plain-terminal
    # appears before the main TUI opens.
    if _tui_mode_enabled():
        try:
            from the_architect.tui.screens.pre_run import (
                ProviderOption,
                run_provider_selection,
            )

            opts = [
                ProviderOption(
                    display_name=p.display_name,
                    version=p.get_version(),
                    provider=p,
                )
                for p in available
            ]
            idx = run_provider_selection(opts)
            if idx is BACK_SENTINEL:
                # Back pressed on provider screen (first screen) — exit.
                raise SystemExit(0)
            return available[int(idx)]  # type: ignore[call-overload]
        except SystemExit:
            raise
        except Exception as exc:
            logger.debug(f"TUI provider selection failed, falling back to prompt_toolkit: {exc!r}")

    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings, KeyPressEvent
    from prompt_toolkit.layout import FormattedTextControl
    from prompt_toolkit.styles import Style as PtStyle

    selected_idx = 0
    cancelled = False
    n = len(available)

    # Resolve each provider's version string ONCE, up front.  The render
    # callback below runs on every keystroke; calling ``get_version()``
    # from there would spawn ``opencode --version`` / ``claude --version``
    # (each ~hundreds of ms) on every arrow-key press and make the screen
    # feel sluggish.  The provider's own cache protects future callers too,
    # but we resolve here as well so the behaviour does not depend on
    # cache internals.
    versions: list[str] = [p.get_version() for p in available]

    kb = KeyBindings()

    @kb.add("up")
    def _(event: KeyPressEvent) -> None:
        nonlocal selected_idx
        selected_idx = (selected_idx - 1) % n

    @kb.add("down")
    def _(event: KeyPressEvent) -> None:
        nonlocal selected_idx
        selected_idx = (selected_idx + 1) % n

    @kb.add("enter")
    def _(event: KeyPressEvent) -> None:
        event.app.exit()

    @kb.add("c-c")
    def _(event: KeyPressEvent) -> None:
        nonlocal cancelled
        cancelled = True
        event.app.exit()

    def _render() -> list[tuple[str, str]]:
        lines: list[tuple[str, str]] = []
        lines.append(("class:header", "\n The Architect  "))
        lines.append(("class:dim", "select provider\n\n"))
        lines.append(("class:dim", "  Multiple AI CLI providers are installed.\n"))
        lines.append(("class:dim", "  Select which provider to use for this run.\n\n"))

        for i, p in enumerate(available):
            if i == selected_idx:
                lines.append(("class:pointer", "  › "))
                lines.append(("class:focused", f"{p.display_name}"))
            else:
                lines.append(("", "    "))
                lines.append(("", f"{p.display_name}"))

            # Show version if available.  Use the pre-resolved list so
            # the render callback stays pure in-memory — never fork a
            # subprocess per keystroke.
            ver = versions[i]
            if ver and ver != "unknown":
                lines.append(("class:dim", f"  (v{ver})"))
            lines.append(("", "\n"))

        lines.append(("", "\n"))
        lines.append(("class:dim", "  ↑↓ navigate   Enter confirm"))
        return lines

    content = FormattedTextControl(_render)
    layout = _padded_window(content)

    pt_style = PtStyle(
        [
            ("header", f"bold {ARCHITECT_GREEN}"),
            ("pointer", "bold"),
            ("focused", f"bold {ARCHITECT_GREEN}"),
            ("dim", "#888888"),
        ]
    )

    app: Application[object] = Application(
        layout=layout,
        key_bindings=kb,
        style=pt_style,
        full_screen=False,
        output=_get_prompt_toolkit_output(),
    )
    app.run()

    if cancelled:
        raise SystemExit(0)

    return available[selected_idx]


def _prompt_update_action(update_msg: str, install_hint: str) -> str:
    """Single-keypress prompt when an outdated provider is detected.

    Replaces ``questionary.confirm`` with a :mod:`prompt_toolkit` screen that
    reacts to a single keystroke — no Enter required.  The user can press
    ``Enter`` to continue with the outdated provider, ``U`` to update it, or
    ``Esc`` / Ctrl+C to abort.

    Args:
        update_msg: The warning message from ``provider.check_update_available()``.
        install_hint: The provider's install / update command string
            (from ``provider.install_hint()``), shown so the user knows how
            to upgrade without having to look it up.

    Returns:
        ``"continue"`` — user chose to proceed with the outdated provider.
        ``"update"``   — user chose to run the provider update command.
        ``"exit"``     — user chose to abort.
    """
    # TUI fast-path — Phase 13. Render the outdated-provider warning
    # inside the Textual TUI when enabled.
    if _tui_mode_enabled():
        try:
            from the_architect.tui.screens.pre_run import run_update_action_screen

            return run_update_action_screen(update_msg, install_hint)
        except Exception as exc:
            logger.debug(f"TUI update-action screen failed, falling back: {exc!r}")

    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings, KeyPressEvent
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.styles import Style as PtStyle

    result = "exit"
    kb = KeyBindings()

    @kb.add("c")
    @kb.add("C")
    @kb.add("enter")
    def _(event: KeyPressEvent) -> None:
        nonlocal result
        result = "continue"
        event.app.exit()

    @kb.add("u")
    @kb.add("U")
    def _(event: KeyPressEvent) -> None:
        nonlocal result
        result = "update"
        event.app.exit()

    @kb.add("q")
    @kb.add("Q")
    @kb.add("escape")
    @kb.add("c-c")
    def _(event: KeyPressEvent) -> None:
        nonlocal result
        result = "exit"
        event.app.exit()

    def _render() -> list[tuple[str, str]]:
        return [
            ("class:warning", f"\n  ⚠  {update_msg}\n\n"),
            ("class:dim", f"  Update:  {install_hint}\n\n"),
            ("class:key", "  Enter"),
            ("class:dim", "  continue anyway    "),
            ("class:key", "U"),
            ("class:dim", "  update provider    "),
            ("class:key", "Esc"),
            ("class:dim", "  exit\n"),
        ]

    content = FormattedTextControl(_render)
    layout = _padded_window(content)

    pt_style = PtStyle(
        [
            ("warning", "bold yellow"),
            ("dim", "#888888"),
            ("key", f"bold {ARCHITECT_GREEN}"),
        ]
    )

    app: Application[object] = Application(
        layout=layout,
        key_bindings=kb,
        style=pt_style,
        full_screen=False,
        output=_get_prompt_toolkit_output(),
    )
    app.run()
    return result


def _check_provider_update_before_model_work(
    provider: ArchitectProvider,
    config: ArchitectConfig,
    headless: bool,
    project: Path | None = None,
    model_override: str | None = None,
) -> None:
    """Warn about provider readiness before any model-backed learning or planning.

    This runs immediately after the goal is known. If the provider is outdated,
    interactive users can stop before walking away; headless users see the
    warning without blocking automation. If *project* is supplied, a small live
    provider health check also runs at the same stage and reports auth/quota/
    billing issues without exiting the process. Per-config flags prevent
    duplicate prompts when planning prompts are collected in one phase and
    executed in another.
    """
    if not getattr(config, "_provider_update_checked", False):
        config._provider_update_checked = True  # type: ignore[attr-defined]

        update_msg = provider.check_update_available()
        if update_msg:
            if not headless:
                try:
                    hint = provider.install_hint()
                except Exception:
                    hint = ""
                action = _prompt_update_action(update_msg=update_msg, install_hint=hint)
                if action == "update":
                    _run_provider_update(update_msg=update_msg, install_hint=hint)
                if action == "exit":
                    console.print("[dim]Aborted by user.[/dim]")
                    raise SystemExit(0)
            else:
                console.print(f"\n[bold yellow]⚠  {update_msg}[/bold yellow]")
            console.print()

    if project is None or getattr(config, "_provider_health_checked", False):
        return
    config._provider_health_checked = True  # type: ignore[attr-defined]

    from the_architect.core.provider_health import ProviderHealthError, check_provider_health

    try:
        asyncio.run(
            check_provider_health(
                provider=provider,
                project_dir=project,
                model_override=model_override or None,
                agent_override="architect" if provider.supports_agents() else None,
                config_override=(project / ".architect" / "architect.json")
                if provider.supports_agents()
                else None,
            )
        )
    except ProviderHealthError as exc:
        message = str(exc)
        logger.warning(f"Provider health check warning: {message}")
        if headless:
            console.print(f"\n[bold yellow]⚠  Provider issue: {message}[/bold yellow]")
            console.print()
        else:
            _prompt_provider_issue_warning(message)


def _provider_update_command(update_msg: str, install_hint: str) -> list[str] | None:
    """Return a safe provider update command from the provider's warning text."""
    match = re.search(r"Update with:\s*(.+)", update_msg)
    command = match.group(1).strip() if match else install_hint.strip()
    if not command or command.startswith(("http://", "https://")):
        return None
    if command.lower().startswith("see "):
        return None
    try:
        return shlex.split(command)
    except ValueError:
        return None


def _run_provider_update(update_msg: str, install_hint: str) -> bool:
    """Run the provider's advertised update command and keep the session alive."""
    command = _provider_update_command(update_msg, install_hint)
    if not command:
        console.print("[yellow]Provider update command is not executable automatically.[/yellow]")
        if install_hint:
            console.print(f"[dim]Update manually: {install_hint}[/dim]")
        return False

    console.print(f"\n[dim]Running: {' '.join(command)}[/dim]\n")
    result = subprocess.run(command, check=False)  # noqa: S603 - user approved update command
    if result.returncode == 0:
        console.print("[green]Provider update completed. Continuing...[/green]\n")
        return True

    console.print(
        f"[yellow]Provider update failed with exit code {result.returncode}. Continuing...[/yellow]"
    )
    console.print(f"[dim]Run manually: {' '.join(command)}[/dim]\n")
    return False


def _prompt_provider_issue_warning(message: str) -> None:
    """Show a provider health warning without exiting The Architect."""
    if _tui_mode_enabled():
        try:
            console.print(f"\n[bold yellow]⚠  Provider issue: {message}[/bold yellow]")
            console.print("[dim]Fix the provider if needed, then continue.[/dim]\n")
            return
        except Exception:
            pass

    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings, KeyPressEvent
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.styles import Style as PtStyle

    kb = KeyBindings()

    @kb.add("enter")
    @kb.add("c")
    @kb.add("C")
    def _(event: KeyPressEvent) -> None:
        event.app.exit()

    def _render() -> list[tuple[str, str]]:
        return [
            ("class:warning", f"\n  ⚠  Provider issue detected\n\n  {message}\n\n"),
            (
                "class:dim",
                "  The Architect will continue, but provider work may fail "
                "until this is fixed.\n\n",
            ),
            ("class:key", "  Enter"),
            ("class:dim", "  continue\n"),
        ]

    app: Application[object] = Application(
        layout=_padded_window(FormattedTextControl(_render)),
        key_bindings=kb,
        style=PtStyle(
            [
                ("warning", "bold yellow"),
                ("dim", "#888888"),
                ("key", f"bold {ARCHITECT_GREEN}"),
            ]
        ),
        full_screen=False,
        output=_get_prompt_toolkit_output(),
    )
    app.run()


def _prompt_self_update_action(current_version: str, latest_version: str) -> str:
    """Single-keypress prompt when a newer version of The Architect is available.

    Shown during startup, after the splash animation.  The user can press
    ``Enter`` / ``Esc`` to continue with the installed version or ``U`` to
    install the update and restart.

    Args:
        current_version: The currently installed version string.
        latest_version: The newer version available on PyPI.

    Returns:
        ``"continue"`` — user chose to proceed with the current version.
        ``"update"``   — user chose to install the update and restart.
    """
    if _tui_mode_enabled():
        try:
            from the_architect.tui.screens.pre_run import run_self_update_screen

            return run_self_update_screen(current_version, latest_version)
        except Exception as exc:
            logger.debug(f"TUI self-update screen failed, falling back: {exc!r}")

    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings, KeyPressEvent
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.styles import Style as PtStyle

    result = "continue"
    kb = KeyBindings()

    @kb.add("enter")
    @kb.add("escape")
    @kb.add("c-c")
    def _(event: KeyPressEvent) -> None:
        nonlocal result
        result = "continue"
        event.app.exit()

    @kb.add("u")
    @kb.add("U")
    def _(event: KeyPressEvent) -> None:
        nonlocal result
        result = "update"
        event.app.exit()

    def _render() -> list[tuple[str, str]]:
        return [
            ("class:title", "\n  The Architect — update available\n\n"),
            ("class:dim", "  Version "),
            ("class:title", latest_version),
            ("class:dim", f" is available  (you have {current_version})\n\n"),
            ("class:dim", "  pip install --upgrade the-architect\n\n"),
            ("class:key", "  Enter"),
            ("class:dim", "  continue anyway    "),
            ("class:key", "U"),
            ("class:dim", "  update & restart\n"),
        ]

    content = FormattedTextControl(_render)
    layout = _padded_window(content)

    pt_style = PtStyle(
        [
            ("title", f"bold {ARCHITECT_GREEN}"),
            ("dim", "#888888"),
            ("key", f"bold {ARCHITECT_GREEN}"),
        ]
    )

    app: Application[object] = Application(
        layout=layout,
        key_bindings=kb,
        style=pt_style,
        full_screen=False,
        output=_get_prompt_toolkit_output(),
    )
    app.run()
    return result


def _tui_mode_enabled() -> bool:
    """Return True when interactive screens should be rendered with Textual."""
    return os.environ.get("ARCHITECT_TUI", "").lower() in ("1", "true", "yes")


def _is_dumb_terminal() -> bool:
    """Return True when the terminal is explicitly incapable of ANSI/VT output.

    Only ``TERM=dumb`` is treated as a hard incapability signal.  An *unset*
    or empty ``TERM`` is **not** treated as dumb — Windows PowerShell and
    Windows Terminal never set ``TERM`` at all, but they fully support VT
    escape sequences and colour.  Treating an empty ``TERM`` as dumb was the
    bug that forced Windows users onto the legacy prompt_toolkit fallback
    screens instead of the modern Textual TUI.
    """
    return os.environ.get("TERM", "").lower() == "dumb"


def _resolve_tui_default(
    explicit: bool | None,
    headless: bool = False,
) -> bool:
    """Resolve the three-state ``--tui/--no-tui/auto`` flag into a bool.

    Phase 8: TUI is on by default whenever it is safe — a real TTY with
    color support and an interactive-capable terminal. Users keep full
    control via ``--no-tui`` (opt out), ``--tui`` (force on), ``NO_COLOR``
    environment variable, or piping stdout to a file.

    Args:
        explicit: The value from ``--tui/--no-tui``. ``None`` means the
            user didn't pass either flag and auto-detection should run.
        headless: When ``True``, the TUI is forced off regardless of
            the explicit flag — headless mode is for unattended runs
            and implies no terminal UI.

    Returns:
        ``True`` when the Textual TUI should be used, ``False``
        otherwise.
    """
    if headless:
        return False
    if explicit is not None:
        return explicit
    # Auto-detect: TTY + color support + not a dumb terminal.
    try:
        if not sys.stdout.isatty():
            return False
    except Exception:
        return False
    if os.environ.get("NO_COLOR", "").strip():
        return False
    if _is_dumb_terminal():
        return False
    return True


def _prompt_mode_selection(
    provider: ArchitectProvider | None = None,
) -> dict[str, bool | int] | None:
    """Show a single-screen interactive configuration for The Architect run.

    Presented when the user runs ``architect`` without any mode flags
    (``--free``, ``--persistent``).  Power users who pass flags on the
    command line skip this screen entirely.

    The screen is provider-aware:
    - Free Tier and Token Budget are only shown when the provider supports
      OpenRouter free-tier rotation (OpenCode + OpenRouter configured).
    - When only Persistent is available, the screen is simplified to a
      single checkbox.

    Args:
        provider: The active AI CLI provider.  Used to determine which
            options are available.  Defaults to showing all options when
            not specified (backward-compatible behaviour).

    Returns:
        Dictionary with mode names mapped to their values, or None when
        the user pressed Back.
        Example:
        ``{"free": True, "persistent": False, "integrity": True,``
        ``"token_budget_per_hour": 0}``
        ``token_budget_per_hour`` is 0 when the user doesn't type a budget (unlimited).
    """

    # TUI fast-path — Phase 3. When --tui is active (or ARCHITECT_TUI=1),
    # render the mode-selection screen with Textual instead of
    # prompt_toolkit. Same return shape, so callers are unchanged.
    show_free_tui = provider.supports_free_tier() if provider is not None else True
    if _tui_mode_enabled():
        try:
            from the_architect.tui.screens import run_mode_selection

            result = run_mode_selection(show_free=show_free_tui)
            if result is BACK_SENTINEL:
                return None  # Signal: user pressed Back
            return result  # type: ignore[return-value]
        except SystemExit:
            raise
        except Exception as exc:
            logger.debug(f"TUI mode selection failed, falling back to prompt_toolkit: {exc!r}")

    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings, KeyPressEvent
    from prompt_toolkit.layout import FormattedTextControl
    from prompt_toolkit.styles import Style as PtStyle

    # Determine which options are available for this provider.
    # Free Tier (OpenRouter rotation) is provider-specific.
    # Persistent and Token Budget are universal — always shown.
    show_free = show_free_tui

    # Index mapping:
    #   show_free:  0=free  1=persistent  2=file-integrity  3=budget
    #   hide_free:  0=persistent  1=file-integrity  2=budget
    IDX_FREE = 0 if show_free else -1
    IDX_PERSISTENT = 1 if show_free else 0
    IDX_FILE_INTEGRITY = 2 if show_free else 1
    IDX_BUDGET = 3 if show_free else 2
    ITEM_COUNT = 4 if show_free else 3

    # ── Mutable state ────────────────────────────────────────────────────
    free = False
    persistent = False
    integrity = True
    budget_text = ""
    focused = 0
    cancelled = False
    BUDGET_MAX_LEN = 10

    # ── Key bindings ─────────────────────────────────────────────────────
    kb = KeyBindings()

    @kb.add("up")
    def _(event: KeyPressEvent) -> None:
        nonlocal focused
        focused = (focused - 1) % ITEM_COUNT

    @kb.add("down")
    def _(event: KeyPressEvent) -> None:
        nonlocal focused
        focused = (focused + 1) % ITEM_COUNT

    @kb.add("tab")
    def _(event: KeyPressEvent) -> None:
        nonlocal focused
        focused = (focused + 1) % ITEM_COUNT

    @kb.add("space")
    def _(event: KeyPressEvent) -> None:
        nonlocal free, persistent, integrity
        if focused == IDX_FREE:
            free = not free
        elif focused == IDX_PERSISTENT:
            persistent = not persistent
        elif focused == IDX_FILE_INTEGRITY:
            integrity = not integrity

    @kb.add("enter")
    def _(event: KeyPressEvent) -> None:
        event.app.exit()

    @kb.add("c-c")
    def _(event: KeyPressEvent) -> None:
        nonlocal cancelled
        cancelled = True
        event.app.exit()

    # Digit keys for budget input (always available — budget is universal)
    for _digit in "0123456789":

        def _make_handler(d: str) -> Callable[[KeyPressEvent], None]:
            def handler(event: KeyPressEvent) -> None:
                nonlocal budget_text
                if focused == IDX_BUDGET and len(budget_text) < BUDGET_MAX_LEN:
                    budget_text += d

            return handler

        kb.add(_digit)(_make_handler(_digit))

    @kb.add("backspace")
    def _(event: KeyPressEvent) -> None:
        nonlocal budget_text
        if focused == IDX_BUDGET:
            budget_text = budget_text[:-1]

    @kb.add("delete")
    def _(event: KeyPressEvent) -> None:
        nonlocal budget_text
        if focused == IDX_BUDGET:
            budget_text = ""

    # ── Layout ───────────────────────────────────────────────────────────
    def _render() -> list[tuple[str, str]]:
        lines: list[tuple[str, str]] = []

        # Header
        lines.append(("class:header", "\n The Architect  "))
        lines.append(("class:dim", "configure run\n\n"))

        if show_free:
            # Free Tier (OpenCode + OpenRouter only)
            ck = "x" if free else " "
            if focused == IDX_FREE:
                lines.append(("class:pointer", "  › "))
                lines.append(("class:focused", f"[{ck}] "))
            else:
                lines.append(("", "    "))
                lines.append(("", f"[{ck}] "))
            lines.append(("", "Free Tier"))
            lines.append(("class:dim", "        (OpenRouter free models, rotate on rate limit)\n"))

        # Persistent (universal)
        ck = "x" if persistent else " "
        if focused == IDX_PERSISTENT:
            lines.append(("class:pointer", "  › "))
            lines.append(("class:focused", f"[{ck}] "))
        else:
            lines.append(("", "    "))
            lines.append(("", f"[{ck}] "))
        lines.append(("", "Persistent"))
        lines.append(("class:dim", "       (30 retries, deeper retrospective)\n"))

        ck = "x" if integrity else " "
        if focused == IDX_FILE_INTEGRITY:
            lines.append(("class:pointer", "  › "))
            lines.append(("class:focused", f"[{ck}] "))
        else:
            lines.append(("", "    "))
            lines.append(("", f"[{ck}] "))
        lines.append(("", "File integrity defense"))
        lines.append(("class:dim", "  (architect_eval snapshots before existing-file edits)\n"))

        # Token Budget (universal)
        bd = budget_text or "0"
        if focused == IDX_BUDGET:
            lines.append(("class:pointer", "  › "))
            lines.append(("class:focused", "Token budget/hr: "))
            lines.append(("class:focused", bd))
            lines.append(("class:cursor", "█"))
        else:
            lines.append(("", "    "))
            lines.append(("", "Token budget/hr: "))
            lines.append(("", bd))
        lines.append(("class:dim", "  (0 = unlimited)\n"))

        # Instructions
        lines.append(("", "\n"))
        if focused == IDX_BUDGET:
            lines.append(
                ("class:dim", "  ↑↓ navigate   Type amount   Backspace delete   Enter confirm")
            )
        else:
            lines.append(("class:dim", "  ↑↓ navigate   Space toggle   Enter confirm"))

        return lines

    content = FormattedTextControl(_render)
    layout = _padded_window(content)

    pt_style = PtStyle(
        [
            ("header", f"bold {ARCHITECT_GREEN}"),
            ("pointer", "bold"),
            ("focused", "bold"),
            ("cursor", "bold"),
            ("dim", "#888888"),
        ]
    )

    app: Application[object] = Application(
        layout=layout,
        key_bindings=kb,
        style=pt_style,
        full_screen=False,
        output=_get_prompt_toolkit_output(),
    )
    app.run()

    if cancelled:
        raise SystemExit(0)

    # ── Parse budget ─────────────────────────────────────────────────────
    try:
        token_budget = int(budget_text.strip() or "0")
    except ValueError:
        token_budget = 0

    return {
        "free": free if show_free else False,
        "persistent": persistent,
        "integrity": integrity,
        "token_budget_per_hour": max(token_budget, 0),
    }


def _prompt_resume_screen(
    pending_tasks: list[Task],
    config: ArchitectConfig,
    provider: ArchitectProvider | None = None,
    verification_results: list[ResumeVerificationResult] | None = None,
) -> dict[str, bool | int | str]:
    """Show a resume screen when pending tasks exist from a previous run.

    Displays the pending task count and names, pre-fills settings from
    the current config, and lets the user confirm execution, adjust
    settings, or switch to replan mode.

    The screen is provider-aware: Free Tier and Token Budget are only
    shown when the provider supports OpenRouter free-tier rotation.

    Args:
        pending_tasks: List of pending Task objects.
        config: Current ArchitectConfig (used for pre-filling settings).
        provider: The active AI CLI provider.  Used to determine which
            options are available.
        verification_results: Optional verification results showing which
            completed tasks are still valid. Passed to the TUI resume
            screen for display.

    Returns:
        Dictionary with keys:
        - ``free``: bool
        - ``persistent``: bool
        - ``token_budget_per_hour``: int
        - ``action``: ``"execute"`` or ``"replan"``
    """

    # TUI fast-path — Phase 3. When --tui is active (or ARCHITECT_TUI=1),
    # render the resume screen with Textual instead of prompt_toolkit.
    show_free_tui = provider.supports_free_tier() if provider is not None else True
    if _tui_mode_enabled():
        try:
            from the_architect.tui.screens import run_resume_screen

            return run_resume_screen(
                pending_tasks=pending_tasks,
                config=config,
                show_free=show_free_tui,
                verification_results=verification_results,
            )
        except SystemExit:
            raise
        except Exception as exc:
            logger.debug(f"TUI resume screen failed, falling back to prompt_toolkit: {exc!r}")

    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings, KeyPressEvent
    from prompt_toolkit.layout import FormattedTextControl
    from prompt_toolkit.styles import Style as PtStyle

    # Determine which options are available for this provider.
    # Free Tier (OpenRouter rotation) is provider-specific.
    # Persistent and Token Budget are universal — always shown.
    show_free = show_free_tui

    # Index mapping:
    #   show_free:  0=free  1=persistent  2=file-integrity  3=budget  4=replan  5=execute
    #   hide_free:  0=persistent  1=file-integrity  2=budget  3=replan  4=execute
    IDX_FREE = 0 if show_free else -1
    IDX_PERSISTENT = 1 if show_free else 0
    IDX_FILE_INTEGRITY = 2 if show_free else 1
    IDX_BUDGET = 3 if show_free else 2
    IDX_REPLAN = 4 if show_free else 3
    IDX_EXECUTE = 5 if show_free else 4
    ITEM_COUNT = 6 if show_free else 5

    # ── Mutable state ────────────────────────────────────────────────────
    free = config.free_mode if show_free else False
    persistent = config.persistent
    integrity = config.integrity
    budget_text = str(config.token_budget_per_hour) if config.token_budget_per_hour > 0 else ""
    focused = 0
    cancelled = False
    action = "execute"
    BUDGET_MAX_LEN = 10

    # ── Key bindings ─────────────────────────────────────────────────────
    kb = KeyBindings()

    @kb.add("up")
    def _(event: KeyPressEvent) -> None:
        nonlocal focused
        focused = (focused - 1) % ITEM_COUNT

    @kb.add("down")
    def _(event: KeyPressEvent) -> None:
        nonlocal focused
        focused = (focused + 1) % ITEM_COUNT

    @kb.add("tab")
    def _(event: KeyPressEvent) -> None:
        nonlocal focused
        focused = (focused + 1) % ITEM_COUNT

    @kb.add("space")
    def _(event: KeyPressEvent) -> None:
        nonlocal free, persistent, integrity, action
        if focused == IDX_FREE:
            free = not free
        elif focused == IDX_PERSISTENT:
            persistent = not persistent
        elif focused == IDX_FILE_INTEGRITY:
            integrity = not integrity
        elif focused == IDX_REPLAN:
            action = "replan"
            event.app.exit()
        elif focused == IDX_EXECUTE:
            action = "execute"
            event.app.exit()

    @kb.add("enter")
    def _(event: KeyPressEvent) -> None:
        nonlocal action
        if focused == IDX_REPLAN:
            action = "replan"
        else:
            action = "execute"
        event.app.exit()

    @kb.add("c-c")
    def _(event: KeyPressEvent) -> None:
        nonlocal cancelled
        cancelled = True
        event.app.exit()

    # Digit keys for budget input (universal — always registered)
    for _digit in "0123456789":

        def _make_handler(d: str) -> Callable[[KeyPressEvent], None]:
            def handler(event: KeyPressEvent) -> None:
                nonlocal budget_text
                if focused == IDX_BUDGET and len(budget_text) < BUDGET_MAX_LEN:
                    budget_text += d

            return handler

        kb.add(_digit)(_make_handler(_digit))

    @kb.add("backspace")
    def _(event: KeyPressEvent) -> None:
        nonlocal budget_text
        if focused == IDX_BUDGET:
            budget_text = budget_text[:-1]

    @kb.add("delete")
    def _(event: KeyPressEvent) -> None:
        nonlocal budget_text
        if focused == IDX_BUDGET:
            budget_text = ""

    # ── Layout ───────────────────────────────────────────────────────────
    def _render() -> list[tuple[str, str]]:
        lines: list[tuple[str, str]] = []

        # Header
        lines.append(("class:header", "\n The Architect  "))
        lines.append(("class:dim", "resume run\n\n"))

        # Task summary
        n = len(pending_tasks)
        lines.append(("class:label", f"  {n} pending task{'s' if n != 1 else ''} to execute\n"))
        for t in pending_tasks[:5]:
            name = getattr(t, "name", str(t))
            prefix = getattr(t, "prefix", "")
            title = getattr(t, "title", name)
            lines.append(("class:dim", f"    {prefix}  {title}\n"))
        if n > 5:
            lines.append(("class:dim", f"    ... and {n - 5} more\n"))
        lines.append(("", "\n"))

        # Settings section
        lines.append(("class:label", "  Settings\n"))

        if show_free:
            # Free Tier (OpenCode + OpenRouter only)
            ck = "x" if free else " "
            if focused == IDX_FREE:
                lines.append(("class:pointer", "  › "))
                lines.append(("class:focused", f"[{ck}] "))
            else:
                lines.append(("", "    "))
                lines.append(("", f"[{ck}] "))
            lines.append(("", "Free Tier"))
            lines.append(("class:dim", "        (OpenRouter free models)\n"))

        # Persistent (universal)
        ck = "x" if persistent else " "
        if focused == IDX_PERSISTENT:
            lines.append(("class:pointer", "  › "))
            lines.append(("class:focused", f"[{ck}] "))
        else:
            lines.append(("", "    "))
            lines.append(("", f"[{ck}] "))
        lines.append(("", "Persistent"))
        lines.append(("class:dim", "       (30 retries, deeper retrospective)\n"))

        ck = "x" if integrity else " "
        if focused == IDX_FILE_INTEGRITY:
            lines.append(("class:pointer", "  › "))
            lines.append(("class:focused", f"[{ck}] "))
        else:
            lines.append(("", "    "))
            lines.append(("", f"[{ck}] "))
        lines.append(("", "File integrity defense"))
        lines.append(("class:dim", "  (architect_eval snapshots before existing-file edits)\n"))

        # Token Budget (universal)
        bd = budget_text or "0"
        if focused == IDX_BUDGET:
            lines.append(("class:pointer", "  › "))
            lines.append(("class:focused", "Token budget/hr: "))
            lines.append(("class:focused", bd))
            lines.append(("class:cursor", "█"))
        else:
            lines.append(("", "    "))
            lines.append(("", "Token budget/hr: "))
            lines.append(("", bd))
        lines.append(("class:dim", "  (0 = unlimited)\n"))

        # Separator
        lines.append(("", "\n"))

        # Actions
        if focused == IDX_REPLAN:
            lines.append(("class:pointer", "  › "))
            lines.append(("class:action_focused", "Replan"))
        else:
            lines.append(("", "    "))
            lines.append(("class:action", "Replan"))
        lines.append(("class:dim", "               (start fresh with a new goal)\n"))

        if focused == IDX_EXECUTE:
            lines.append(("class:pointer", "  › "))
            lines.append(("class:action_focused", "Execute"))
        else:
            lines.append(("", "    "))
            lines.append(("class:action", "Execute"))
        lines.append(("class:dim", "             (continue running pending tasks)\n"))

        # Instructions
        lines.append(("", "\n"))
        if focused == IDX_BUDGET:
            lines.append(
                ("class:dim", "  ↑↓ navigate   Type amount   Backspace delete   Enter execute")
            )
        elif focused == IDX_REPLAN:
            lines.append(("class:dim", "  ↑↓ navigate   Space/Enter to replan"))
        elif focused == IDX_EXECUTE:
            lines.append(("class:dim", "  ↑↓ navigate   Enter to execute"))
        else:
            lines.append(("class:dim", "  ↑↓ navigate   Space toggle   Enter execute"))

        return lines

    content = FormattedTextControl(_render)
    layout = _padded_window(content)

    pt_style = PtStyle(
        [
            ("header", f"bold {ARCHITECT_GREEN}"),
            ("pointer", "bold"),
            ("focused", "bold"),
            ("cursor", "bold"),
            ("dim", "#888888"),
            ("label", "bold"),
            ("action", ""),
            ("action_focused", "bold #7cc800"),
        ]
    )

    app: Application[object] = Application(
        layout=layout,
        key_bindings=kb,
        style=pt_style,
        full_screen=False,
        output=_get_prompt_toolkit_output(),
    )
    app.run()

    if cancelled:
        raise SystemExit(0)

    # ── Parse budget ─────────────────────────────────────────────────────
    try:
        token_budget = int(budget_text.strip() or "0")
    except ValueError:
        token_budget = 0

    return {
        "free": free if show_free else False,
        "persistent": persistent,
        "integrity": integrity,
        "token_budget_per_hour": max(token_budget, 0),
        "action": action,
    }


# ---------------------------------------------------------------------------
# Interactive planning prompts (opencode-style arrow-key menus)
# ---------------------------------------------------------------------------


def _prompt_goal() -> str:
    """Prompt the user for their development goal.

    Returns:
        The goal string (non-empty).
    """
    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect[/bold {ARCHITECT_GREEN}]  "
        f"[grey62]fire-and-forget autonomous development[/grey62]"
    )
    console.print()

    goal = _prompt_text_input(
        "What do you want to build?",
        "(describe the feature, component, or goal)",
    )

    if goal is None:
        console.print("[dim]Cancelled.[/dim]")
        raise SystemExit(0)
    if not goal.strip():
        console.print("[red]No goal provided. Exiting.[/red]")
        raise SystemExit(1)

    return str(goal.strip())


def _prompt_scope(initial_scope: str = "standard") -> str | None:
    """Prompt the user to select task scope (non-TUI / questionary fallback).

    This path is only reached when the TUI tabbed pre-run screen was not used
    (headless, --no-tui, or non-interactive terminal).  The TUI path always
    goes through ``run_pre_run_tabbed`` which has scope built in.

    Args:
        initial_scope: Pre-fill scope from previous run
            ('standard', 'simple', 'complex').

    Returns:
        The selected scope string, or None if the user pressed Back.
    """
    import questionary

    choice = questionary.select(
        "Task scope",
        choices=[
            questionary.Choice(
                "Standard — one feature area per task, balanced context  (recommended)",
                value="standard",
            ),
            questionary.Choice(
                "Simple   — one thing per task, tends toward smaller context per run  "
                "(weak/local models)",
                value="simple",
            ),
            questionary.Choice(
                "Complex  — one subsystem per task, tends toward larger context per run  "
                "(frontier models only)",
                value="complex",
            ),
        ],
        pointer="›",
        style=_questionary_style(),
    ).ask()

    if choice is None:
        console.print("[dim]Cancelled.[/dim]")
        raise SystemExit(0)

    return TaskScope(choice)


def _prompt_architect_model(
    project_dir: Path,
    provider: ArchitectProvider | None = None,
) -> str | None:
    """Prompt the user to select the architect model from available provider models.

    Fetches the model list and the currently configured model concurrently,
    then presents an arrow-key selection.

    Args:
        project_dir: The project root directory.
        provider: The active provider.  Defaults to auto-detection when not specified.

    Returns:
        Selected model string, or None to use provider default.
    """
    import questionary

    if provider is None:
        provider = detect_provider("auto")

    provider_name = provider.display_name

    # Fetch models and current config concurrently. The Textual splash /
    # tabbed pre-run screen is the loading indicator here — no stdout
    # spinner is started because that would fight the TUI for the screen.
    async def _fetch() -> tuple[list[str], str]:
        loop = asyncio.get_event_loop()
        models, current = await asyncio.gather(
            loop.run_in_executor(None, provider.list_models),
            loop.run_in_executor(None, provider.get_resolved_model, project_dir, "architect"),
        )
        return models, current

    models, current = asyncio.run(_fetch())

    if not models and not current:
        # Can't list models — fall back to free text
        typed = _prompt_text_input(
            "Architect model",
            f"({provider.display_name} model string, or leave blank for default)",
        )
        return typed.strip() if typed and typed.strip() else None

    # TUI fast-path — Phase 13. When the TUI is active, render the
    # architect-model picker as a Textual screen so nothing
    # plain-terminal appears mid-pre-run.
    if _tui_mode_enabled():
        try:
            from the_architect.tui.screens.pre_run import run_model_picker

            result = run_model_picker(
                provider_name=provider_name,
                models=list(models or []),
                current=current or "",
            )
            if result is BACK_SENTINEL:
                return None  # Signal: user pressed Back
            # run_model_picker returns str or None after BACK_SENTINEL check
            if isinstance(result, str):
                return result
            return current if current else None
        except SystemExit:
            raise
        except Exception as exc:
            logger.debug(f"TUI model picker failed, falling back to questionary: {exc!r}")

    # Build choices list — current model first so the cursor starts on it.
    # We intentionally avoid passing default= to questionary.select()
    # because that adds the item to selected_options, which makes it
    # permanently green bold (class:selected) even when the cursor
    # moves away.  Instead, we rely on the list order to set the
    # initial cursor position (first item = cursor start).
    choices: list[questionary.Choice] = []

    if models:
        # Put current model at top so the cursor starts there
        ordered = list(models)
        if current and current in ordered:
            ordered.remove(current)
            ordered.insert(0, current)
        elif current:
            ordered.insert(0, current)

        for m in ordered:
            label = f"  {m}"
            if m == current:
                label += "  [current]"
            choices.append(questionary.Choice(label, value=m))
    elif current:
        choices.append(questionary.Choice(f"  {current}  [current]", value=current))

    # Blank / provider-default option goes last — it's the fallback
    default_label = f"  (use {provider_name} default)"
    choices.append(questionary.Choice(default_label, value=""))

    selected = questionary.select(
        "Architect model",
        choices=choices,
        pointer="›",
        style=_questionary_style(),
    ).ask()

    if selected is None:
        console.print("[dim]Cancelled.[/dim]")
        raise SystemExit(0)

    # When the user picks "use provider default", resolve their actual default
    # model rather than returning None.
    if not selected:
        return current if current else None

    return str(selected)


def _prompt_exec_agent(
    project_dir: Path,
    provider: ArchitectProvider | None = None,
) -> str | None:
    """Prompt the user to select the execution agent.

    For providers that don't support named agents (Claude Code), this
    prompt is skipped and an empty string is returned.

    Args:
        project_dir: The project root directory.
        provider: The active provider.  Defaults to auto-detection when not specified.

    Returns:
        Selected agent string, or empty string for provider default.
    """
    import questionary

    if provider is None:
        provider = detect_provider("auto")

    # Providers without named-agent support — skip the prompt
    if not provider.supports_agents():
        return ""

    # Textual splash / tabbed pre-run screen is the loading indicator.
    agents = provider.list_agents(project_dir)

    if not agents:
        return ""

    # TUI fast-path — Phase 13. Render the execution-agent picker as
    # a Textual screen when the TUI is active.
    if _tui_mode_enabled():
        try:
            from the_architect.tui.screens.pre_run import run_agent_picker

            result = run_agent_picker(
                provider_name=provider.display_name,
                agents=list(agents),
            )
            if result is BACK_SENTINEL:
                return None  # Signal: user pressed Back
            return str(result)
        except SystemExit:
            raise
        except Exception as exc:
            logger.debug(f"TUI agent picker failed, falling back to questionary: {exc!r}")

    choices = [questionary.Choice(f"  (use {provider.display_name} default)", value="")]
    for a in agents:
        choices.append(questionary.Choice(f"  {a}", value=a))

    selected = questionary.select(
        "Execution agent",
        choices=choices,
        pointer="›",
        style=_questionary_style(),
    ).ask()

    if selected is None:
        console.print("[dim]Cancelled.[/dim]")
        raise SystemExit(0)

    return str(selected)


def run_planning_mode(
    project: Path,
    config: ArchitectConfig,
    headless: bool = False,
    goal_text: str = "",
    scope_text: str = "",
    context_paths: tuple[Path, ...] = (),
    architect_model_override: str = "",
    execution_model_override: str | None = None,
    _skip_pending_guard: bool = False,
    provider: ArchitectProvider | None = None,
) -> None:
    """Interactive planning mode — prompts then runs the architect agent.

    After all prompts are answered, the terminal is cleared and a clean
    header is shown — matching the execution mode layout.

    In headless mode, all interactive prompts are skipped. Required values
    must come from flags or environment variables.

    Args:
        project: The project root directory.
        config: The The Architect configuration.
        headless: If True, skip all interactive prompts.
        goal_text: Pre-supplied goal (from --goal flag or env var).
        scope_text: Pre-supplied scope (from --scope flag or env var).
        context_paths: Pre-supplied context paths (from --context flag or env var).
        architect_model_override: Pre-supplied architect model (from --architect-model flag).
        execution_model_override: Pre-supplied execution model (from --execution-model flag or
            interactively collected by ``_collect_planning_prompts``).  ``None`` means the
            prompt has not been shown yet and should be shown now.  An empty string ``""``
            means the user explicitly chose the provider default (no override).
        _skip_pending_guard: If True, skip the pending-task guard (already ran
            in ``_collect_planning_prompts`` before the alternate screen).
        provider: The AI CLI provider to use.  Defaults to auto-detection when not specified.
    """
    if provider is None:
        provider = detect_provider("auto")
    # ── Pending task guard ─────────────────────────────────────────────
    # Check for unfinished tasks before asking for a new goal.
    # This prevents users from accidentally starting a new goal on top of
    # incomplete work they may have forgotten about.
    # Skipped when prompts were already collected before the alternate screen.
    if not _skip_pending_guard:
        tasks_dir = project / config.tasks_dir.name
        progress_file = config.progress_file
        pending = check_pending_tasks(tasks_dir, progress_file)
        if pending:
            if headless:
                # In headless mode, log the warning and continue automatically
                logger.warning(
                    f"Found {len(pending)} unfinished task(s) — "
                    "archiving and continuing in headless mode"
                )
            else:
                # TUI fast-path — Phase 14. Render the pending-task
                # warning inside the TUI so nothing leaks to plain
                # terminal before the TUI opens.
                if _tui_mode_enabled():
                    try:
                        from the_architect.tui.screens.pre_run import (
                            run_pending_tasks_screen,
                        )

                        if not run_pending_tasks_screen(list(pending)):
                            raise SystemExit(0)
                    except SystemExit:
                        raise
                    except Exception as exc:
                        logger.debug(f"TUI pending-tasks screen failed, falling back: {exc!r}")
                    else:
                        # TUI confirmed → skip the plain confirm below.
                        pending = []

                if pending:
                    console.print()
                    console.print(
                        f"[yellow]⚠  You have {len(pending)} unfinished task(s):[/yellow]"
                    )
                    for name in pending:
                        console.print(f"[dim]   • {name}[/dim]")
                    console.print()
                    console.print(
                        "[dim]Run [bold]architect[/bold] (without --plan) to finish "
                        "them first.[/dim]"
                    )
                    console.print(
                        "[dim]Or continue below to start a new goal — "
                        "previous tasks will be archived.[/dim]"
                    )
                    console.print()
                    import questionary as _q

                    confirmed = _q.confirm(
                        "Start a new goal anyway? (previous tasks will be archived)",
                        default=False,
                        style=_questionary_style(),
                    ).ask()
                    if confirmed is not True:
                        console.print(
                            "[dim]Aborted. "
                            "Run [bold]architect[/bold] to finish existing tasks.[/dim]"
                        )
                        raise SystemExit(0)

    # ── Goal resolution ────────────────────────────────────────────────
    # Load context files first so we can extract goal from them if needed
    context_content = ""
    context_labelled: list[tuple[str, str]] = []
    if context_paths:
        from the_architect.core.context import format_context_for_prompt, load_context_paths

        try:
            context_labelled = load_context_paths(list(context_paths))
            context_content = format_context_for_prompt(context_labelled)
        except FileNotFoundError as exc:
            console.print(f"[red]Error: {exc}[/red]")
            raise SystemExit(1)

    if goal_text:
        goal = goal_text
    elif headless:
        # Try to extract goal from context files
        if context_content:
            from the_architect.core.context import extract_goal_from_context

            extracted = extract_goal_from_context(context_content)
            if extracted:
                goal = extracted
                logger.info(f"Extracted goal from context: {goal[:80]}...")
            else:
                console.print(
                    "[red]Headless mode requires --goal or --context with a goal section.[/red]"
                )
                raise SystemExit(1)
        else:
            console.print("[red]Headless mode requires --goal or --context.[/red]")
            console.print("[dim]Provide a goal with --goal or context files with --context.[/dim]")
            raise SystemExit(1)
    else:
        goal = _prompt_goal()

    if goal:
        config._infinite_loop_goal = goal  # type: ignore[attr-defined]

    # Warn immediately after the goal is known, before scope/model prompts,
    # learning, or planning. If the user intends to walk away after submitting
    # a goal, this is the last safe point to block for provider maintenance.
    _check_provider_update_before_model_work(
        provider,
        config,
        headless,
        project=project,
        model_override=architect_model_override or None,
    )

    # ── Scope resolution ───────────────────────────────────────────────
    if scope_text:
        scope = TaskScope(scope_text)
    elif headless:
        scope = TaskScope.STANDARD  # Default in headless mode
    else:
        scope_result = _prompt_scope(initial_scope=config.last_scope or "standard")
        if scope_result is None:
            # Back pressed — in this non-state-machine path, just retry
            scope_result = "standard"
        scope = TaskScope(scope_result)

    # ── Model / agent resolution ────────────────────────────────────────
    # If the tabbed pre-run screen already asked for the architect model
    # (even if the user picked the provider default — empty string), we
    # must not prompt again here.  The ``_tabbed_model_collected`` flag
    # is set by ``_collect_planning_prompts`` when the tabbed path runs.
    _tabbed_model_collected = getattr(config, "_tabbed_model_collected", False)
    architect_model: str | None
    if architect_model_override:
        architect_model = architect_model_override
    elif _tabbed_model_collected:
        # User picked provider default in the tabbed screen — resolve it
        # explicitly here so downstream status lines still show the model.
        resolved = provider.get_resolved_model(project, "architect") if provider else ""
        architect_model = resolved if resolved else None
    elif headless:
        # In headless mode, resolve the provider's default model explicitly.
        resolved = provider.get_resolved_model(project, "architect")
        architect_model = resolved if resolved else None
    else:
        architect_model = _prompt_architect_model(project, provider=provider)

    if execution_model_override is not None:
        # Already resolved (either from --execution-model flag or from
        # _collect_planning_prompts).  An empty string means the user chose
        # the provider default — still skip the prompt.
        config.execution_agent = execution_model_override
    elif not headless:
        exec_agent = _prompt_exec_agent(project, provider=provider)
        config.execution_agent = exec_agent or ""

    # Clear the terminal and show a clean header — same style as execution
    if not headless:
        console.clear()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect[/bold {ARCHITECT_GREEN}]  "
        f"[grey62]v{__version__}[/grey62]  [grey62]planning[/grey62]"
    )
    console.print()
    display_goal = _truncate_goal_for_display(goal)
    console.print(
        f"[grey62]Goal:[/grey62] [{ARCHITECT_GREEN}]{escape(display_goal)}[/{ARCHITECT_GREEN}]"
    )
    console.print(f"[grey62]Scope:[/grey62] [{ARCHITECT_GREEN}]{scope.value}[/{ARCHITECT_GREEN}]")
    # Resolve the model from the provider when no explicit override was set,
    # so the planning header always shows which model will be used.
    display_model = architect_model
    if not display_model:
        try:
            display_model = provider.get_resolved_model(project, "architect")
        except Exception:
            pass
    if display_model:
        console.print(
            f"[grey62]Model:[/grey62] [{ARCHITECT_GREEN}]{display_model}[/{ARCHITECT_GREEN}]"
        )
    if context_labelled:
        console.print(
            f"[grey62]Context:[/grey62] "
            f"[{ARCHITECT_GREEN}]{len(context_labelled)} file(s)[/{ARCHITECT_GREEN}]"
        )
    console.print()
    console.print(f"[grey62]Starting architect via {provider.display_name}...[/grey62]")
    console.print()

    # ── Project context setup (structure + ARCHITECT.md + provider) ────
    from the_architect.core.architect_md import (
        read_architect_md,
        write_or_update_architect_md,
    )
    from the_architect.core.project_intelligence import (
        format_project_intelligence_for_prompt,
        read_project_intelligence,
        write_project_intelligence,
    )
    from the_architect.core.structure import detect_structure, format_structure_for_prompt

    # The Textual splash / planning wait screen is the loading indicator.
    structure_report = detect_structure(project)
    structure_prompt = format_structure_for_prompt(structure_report)

    # Write/update the structure section in ARCHITECT.md
    write_or_update_architect_md(project, structure_report)
    try:
        write_project_intelligence(project, structure_report)
    except Exception as exc:
        logger.warning(f"Structured project intelligence write failed; continuing: {exc!r}")

    ensure_provider_setup(provider, project, config)

    # Log files for pre-planning and planning sessions
    log_dir = config.log_dir
    log_dir.mkdir(parents=True, exist_ok=True)
    intelligence_log = log_dir / "intelligence.log"
    planning_log = log_dir / "architect.log"

    # Optional model-based memory curation. The deterministic pass above is
    # always present; this provider-model pass runs only when ARCHITECT.md is
    # still shallow or inconsistent with repo evidence.
    from the_architect.core.intelligence import refresh_project_intelligence

    try:
        if _tui_mode_enabled():
            from the_architect.tui import WaitLogRenderer, tui_wait_session

            with tui_wait_session(enabled=True, title="learning project…") as _wait:
                _wait.set_detail("Refreshing ARCHITECT.md before planning")
                _intelligence_renderer = WaitLogRenderer(session=_wait)
                asyncio.run(
                    refresh_project_intelligence(
                        project_dir=project,
                        config=config,
                        provider=provider,
                        structure_report=structure_report,
                        model_override=architect_model,
                        log_path=intelligence_log,
                        renderer=_intelligence_renderer,
                    )
                )
        else:
            asyncio.run(
                refresh_project_intelligence(
                    project_dir=project,
                    config=config,
                    provider=provider,
                    structure_report=structure_report,
                    model_override=architect_model,
                    log_path=intelligence_log,
                )
            )
    except Exception as exc:
        logger.warning(f"Project intelligence refresh failed; continuing to planning: {exc!r}")

    # Read full ARCHITECT.md content for prompt injection after all memory refreshes.
    architect_md_content = read_architect_md(project) or ""
    structured_intelligence_content = format_project_intelligence_for_prompt(
        read_project_intelligence(project)
    )

    request = PlanningRequest(
        goal=goal,
        scope=scope,
        project_dir=project,
        model_override=architect_model,
        context_content=context_content,
        structure_report=structure_prompt,
        architect_md_content=architect_md_content,
        structured_intelligence_content=structured_intelligence_content,
    )

    try:
        if _tui_mode_enabled():
            from the_architect.tui import WaitLogRenderer, tui_wait_session

            with tui_wait_session(enabled=True, title="planning…") as _wait:
                _wait.set_detail(f"Goal: {display_goal}\nScope: {scope.value}")
                _plan_renderer = WaitLogRenderer(session=_wait)
                result = asyncio.run(
                    run_planner(
                        request,
                        config,
                        log_path=planning_log,
                        provider=provider,
                        renderer=_plan_renderer,
                    )
                )
        else:
            # Non-TUI path: no loading indicator at all. The provider
            # streams its own output, and once it completes the success
            # line below confirms planning finished.
            result = asyncio.run(
                run_planner(request, config, log_path=planning_log, provider=provider)
            )
        console.print()
        console.print(f"[#7cc800]✓ Created {len(result.tasks_created)} tasks[/#7cc800]")
        console.print()

        # Run history is written to tasks/SUMMARY.md at completion. ARCHITECT.md
        # is reserved for durable project intelligence, not per-run logs.
    except PlanningFailedError as e:
        console.print(f"[red]Planning failed: {e}[/red]")
        raise SystemExit(1)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# Pre-flight prompt collection (runs BEFORE alternate screen)
# ---------------------------------------------------------------------------


def _collect_planning_prompts(
    project: Path,
    config: ArchitectConfig,
    headless: bool = False,
    goal_text: str = "",
    scope_text: str = "",
    context_paths: tuple[Path, ...] = (),
    architect_model_override: str = "",
    execution_model_override: str = "",
    provider: ArchitectProvider | None = None,
) -> tuple[str, str, str, str | None]:
    """Collect all planning prompts with back-navigation support.

    This runs the interactive portion of planning (pending-task guard, goal,
    scope, model, agent selection) **before** the alternate screen is entered,
    so that questionary / prompt_toolkit renders at the top of the visible
    area rather than at the bottom of the alternate screen buffer.

    The actual planner execution (opencode) is **not** triggered here — that
    happens inside the alternate screen via ``run_planning_mode``.

    In headless mode all prompts are skipped and the original values are
    returned unchanged.

    Phase A: The linear flow is now a state machine.  When the user presses
    Backspace on any TUI screen, the flow returns to the previous step and
    re-prompts.  Only the TUI path supports back navigation — the plain
    terminal path remains linear (questionary does not have a "back" concept).

    Args:
        project: The project root directory.
        config: The pre-loaded Architect configuration (mutated in place for
            ``execution_agent`` when an agent is selected).
        headless: If True, skip all interactive prompts.
        goal_text: Pre-supplied goal (from --goal flag or env var).
        scope_text: Pre-supplied scope (from --scope flag or env var).
        context_paths: Pre-supplied context paths.
        architect_model_override: Pre-supplied architect model.
        execution_model_override: Pre-supplied execution model.  An empty
            string means the user has not yet been asked; ``None`` is never
            passed in but may appear in the return value when headless mode
            skips the prompt entirely.
        provider: The AI CLI provider.  Defaults to auto-detection.

    Returns:
        Tuple of ``(goal_text, scope_text, architect_model, execution_model)``
        with any interactively collected values filled in.  ``execution_model``
        is ``None`` when headless mode is active and no override was supplied
        (signals ``run_planning_mode`` to skip the prompt without overriding
        ``config.execution_agent``).
    """
    if not _infinite_loop_active(config):
        config._infinite_loop_enabled = False  # type: ignore[attr-defined]

    if headless:
        # Return None for execution_model when no override was given so that
        # run_planning_mode skips the prompt without clobbering the config.
        exec_override: str | None = execution_model_override if execution_model_override else None
        return goal_text, scope_text, architect_model_override, exec_override

    if provider is None:
        provider = detect_provider("auto")

    # ── Pending task guard ─────────────────────────────────────────────
    tasks_dir = project / config.tasks_dir.name
    progress_file = config.progress_file
    pending = check_pending_tasks(tasks_dir, progress_file)
    if pending:
        # TUI fast-path — Phase 14.
        if _tui_mode_enabled():
            try:
                from the_architect.tui.screens.pre_run import (
                    run_pending_tasks_screen,
                )

                if not run_pending_tasks_screen(list(pending)):
                    raise SystemExit(0)
            except SystemExit:
                raise
            except Exception as exc:
                logger.debug(f"TUI pending-tasks screen failed, falling back: {exc!r}")
            else:
                pending = []

        if pending:
            console.print()
            console.print(f"[yellow]⚠  You have {len(pending)} unfinished task(s):[/yellow]")
            for name in pending:
                console.print(f"[dim]   • {name}[/dim]")
            console.print()
            console.print(
                "[dim]Run [bold]architect[/bold] (without --plan) to finish them first.[/dim]"
            )
            console.print(
                "[dim]Or continue below to start a new goal — "
                "previous tasks will be archived.[/dim]"
            )
            console.print()
            import questionary as _q

            confirmed = _q.confirm(
                "Start a new goal anyway? (previous tasks will be archived)",
                default=False,
                style=_questionary_style(),
            ).ask()
            if confirmed is not True:
                console.print(
                    "[dim]Aborted. Run [bold]architect[/bold] to finish existing tasks.[/dim]"
                )
                raise SystemExit(0)

    # ── TUI tabbed screen (planning pre-run) ─────────────────────────
    # When the TUI is active, show the unified tabbed PreRunScreen
    # instead of the linear chain of individual screens.
    # Skip during Infinite Loop iterations — goal/scope/model are already
    # resolved from iteration 1; re-showing the screen on every planning
    # pass causes an interactive spin (each dismiss triggers SystemExit(0)
    # which the loop absorbs and immediately re-shows the same screen).
    if _tui_mode_enabled() and provider is not None and not _infinite_loop_active(config):
        try:
            from the_architect.tui.screens.pre_run_tabbed import run_pre_run_tabbed

            # Collect only runnable providers for the Provider tab.
            _all_providers = detect_available_providers(require_models=True)
            if not _all_providers:
                _all_providers = [provider]

            result = run_pre_run_tabbed(
                providers=_all_providers,
                config=config,
                project_dir=project,
                goal_text=goal_text,
                scope_text=scope_text,
                architect_model=architect_model_override,
                execution_model=execution_model_override,
                free_mode=False,
                persistent=False,
            )
            if result is not None:
                goal_text = result.goal
                scope_text = result.scope
                architect_model_override = result.architect_model or ""
                execution_model_override = result.execution_agent or ""
                _check_provider_update_before_model_work(
                    provider,
                    config,
                    headless,
                    project=project,
                    model_override=architect_model_override or None,
                )
                config.execution_agent = result.execution_agent or ""
                config.free_mode = result.free
                config.persistent = result.persistent
                config.integrity = result.integrity
                config.force_reassessment = result.force_reassessment
                config._infinite_loop_enabled = result.infinite_loop  # type: ignore[attr-defined]
                config.token_budget_per_hour = result.token_budget_per_hour
                if result.provider_name:
                    config.provider = result.provider_name

                # Signal to the caller that mode settings were already
                # collected by the tabbed screen — skip the separate
                # _prompt_mode_selection call below.
                config._tabbed_mode_collected = True  # type: ignore[attr-defined]

                # Signal that the architect model was already resolved by
                # the tabbed screen (even if the user picked provider
                # default — empty string).  Prevents run_planning_mode
                # from prompting again.
                config._tabbed_model_collected = True  # type: ignore[attr-defined]

                # Persist values for next run
                try:
                    write_config(
                        project,
                        {
                            "last_scope": scope_text,
                            "architect_model": architect_model_override,
                            "execution_agent": config.execution_agent,
                            "provider": config.provider,
                            "force_reassessment": config.force_reassessment,
                        },
                    )
                except Exception as exc:
                    logger.debug(f"Failed to persist pre-run values: {exc!r}")

                return goal_text, scope_text, architect_model_override, execution_model_override
        except SystemExit:
            raise
        except Exception as exc:
            logger.debug(f"Tabbed pre-run screen failed, falling back to linear: {exc!r}")

    # ── State machine for back-navigable prompts ───────────────────────
    # Steps: goal → scope → model → agent
    # Each step can return a sentinel (empty str / None) on "back" to
    # return to the previous step.  CLI-supplied values (from flags) skip
    # their step entirely and cannot be navigated back to — the user
    # provided them explicitly.
    step = "goal"
    goal_from_flag = bool(goal_text)
    scope_from_flag = bool(scope_text)
    model_from_flag = bool(architect_model_override)
    agent_from_flag = bool(execution_model_override)

    while True:
        if step == "goal":
            if goal_from_flag:
                step = "scope"
                continue
            goal_text = _prompt_goal()
            if not goal_text:
                # Back pressed on first screen — stay at goal
                continue
            _check_provider_update_before_model_work(
                provider,
                config,
                headless,
                project=project,
                model_override=architect_model_override or None,
            )
            step = "scope"

        elif step == "scope":
            if scope_from_flag:
                step = "model"
                continue
            initial_scope = config.last_scope or "standard"
            scope_result = _prompt_scope(initial_scope=initial_scope)
            if scope_result is None:
                # Back pressed — go back to goal
                step = "goal"
                goal_text = ""
                goal_from_flag = False
                continue
            scope_text = scope_result
            step = "model"

        elif step == "model":
            if model_from_flag:
                step = "agent"
                continue
            resolved_model = _prompt_architect_model(project, provider=provider)
            if resolved_model is None:
                # Back pressed — go back to scope
                step = "scope"
                scope_text = ""
                scope_from_flag = False
                continue
            architect_model_override = resolved_model or ""
            step = "agent"

        elif step == "agent":
            if agent_from_flag:
                break
            exec_agent = _prompt_exec_agent(project, provider=provider)
            if exec_agent is None:
                # Back pressed — go back to model
                step = "model"
                architect_model_override = ""
                model_from_flag = False
                continue
            execution_model_override = exec_agent
            config.execution_agent = exec_agent
            break

    # ── Persist values for next run ────────────────────────────────────
    # Goal and context_paths are NOT persisted (spec requirement).
    # Scope and architect_model are persisted so the next run pre-fills.
    try:
        write_config(
            project,
            {
                "last_scope": scope_text,
                "architect_model": architect_model_override,
                "execution_agent": config.execution_agent,
            },
        )
    except Exception as exc:
        logger.debug(f"Failed to persist pre-run values: {exc!r}")

    return goal_text, scope_text, architect_model_override, execution_model_override


# ---------------------------------------------------------------------------
# Execution — raw terminal passthrough
# ---------------------------------------------------------------------------


def _ansi_supported() -> bool:
    """Return True if the current terminal supports ANSI escape codes and colour.

    Returns False when:
    - stdout is not a TTY
    - NO_COLOR env var is set (https://no-color.org/)
    - TERM is explicitly set to 'dumb'

    An unset or empty TERM is *not* treated as dumb.  Windows PowerShell
    and Windows Terminal never set TERM at all but support VT/ANSI output.

    Returns:
        True if ANSI output is appropriate.
    """
    if not sys.stdout.isatty():
        return False
    if os.environ.get("NO_COLOR"):
        return False
    if _is_dumb_terminal():
        return False
    return True


# ---------------------------------------------------------------------------
# Legacy stdout-ANSI spinners / countdowns were removed (build 10135+).
# Every loading / waiting / between-task state is now a Textual screen in
# the single ArchitectApp — no background threads painting to stdout, no
# leftover frames surviving app teardown. See the_architect/tui/screens/
# for the splash, wait, and execution surfaces that replaced them.
# ---------------------------------------------------------------------------


async def _run_tasks_raw(
    project: Path,
    config: ArchitectConfig,
    tasks: list[Task],
    free_rotator: object | None = None,
    monitor_writer: MonitorStateWriter | None = None,
    provider: ArchitectProvider | None = None,
    original_goal: str = "",
    model_override: str | None = None,
    use_tui: bool = False,
    verify_resume: bool = True,
) -> tuple[bool, list[TaskResult], float]:
    """Run all tasks with provider output going directly to the terminal.

    The provider renders natively — no piping, no JSON parsing.  Minimal
    architect headers are printed before and after each task so the user
    knows what's running; everything in between is pure provider output.

    Args:
        project: The project root directory.
        config: The The Architect configuration.
        tasks: The tasks to run.
        free_rotator: Optional FreeModelRotator for --free mode.
        monitor_writer: Optional MonitorStateWriter for dashboard state updates.
        provider: The AI CLI provider to use.  Defaults to auto-detection.
        original_goal: Original planning goal text for the TUI display.
        model_override: Architect model override for replanning.
        use_tui: Whether the Textual TUI is active.
        verify_resume: When ``True`` (default), verify completed tasks
            against their baselines before resuming.

    Returns:
        Tuple of (all_succeeded, results, total_duration).
    """
    duplicates = duplicate_task_prefixes(tasks)
    if duplicates:
        # Try to resolve by filtering out orphan task files created by execution
        # agents (not tracked in PROGRESS.md). Only refuse if the conflict is
        # between two tracked tasks.
        orphan_filtered = False
        try:
            _progress_content = config.progress_file.read_text(encoding="utf-8")
        except OSError:
            _progress_content = ""

        for prefix, names in sorted(duplicates.items()):
            # A task is "tracked" if its prefix appears in PROGRESS.md
            _prefix_pattern = re.compile(rf"^\|\s*{re.escape(prefix)}\s+\|", re.MULTILINE)
            tracked = [n for n in names if _prefix_pattern.search(_progress_content)]
            orphans = [n for n in names if n not in tracked]
            if len(orphans) == 1 and len(tracked) == 1:
                # Clear case: one tracked task, one orphan — remove the orphan
                orphan_name = orphans[0]
                tasks = [t for t in tasks if t.name != orphan_name]
                logger.warning(
                    f"Filtered orphan task file created by execution agent: "
                    f"{orphan_name} (prefix {prefix} already tracked as {tracked[0]})"
                )
                console.print(
                    f"[yellow]⚠ Filtered orphan task file: {orphan_name}[/yellow]  "
                    f"[dim](prefix {prefix} already tracked as {tracked[0]})[/dim]"
                )
                orphan_filtered = True

        if not orphan_filtered:
            details = "; ".join(
                f"{prefix}: {', '.join(names)}" for prefix, names in sorted(duplicates.items())
            )
            console.print(
                "[red]Duplicate task prefixes found; refusing to start execution.[/red]\n"
                f"[dim]{details}[/dim]\n"
                "[dim]Task prefixes are the runtime identity used by PROGRESS.md and the TUI, "
                "so each prefix must appear once.[/dim]"
            )
            return False, [], 0.0

    plan = TaskPlan(tasks=tasks)
    results: list[TaskResult] = []
    run_start = time.time()

    pending_count = sum(1 for t in tasks if _task_needs_work(t))

    reassessment_log_dir = config.log_dir
    reassessment_log_dir.mkdir(parents=True, exist_ok=True)

    # Phase 7 — set once the Textual ArchitectApp is running so that
    # between-task reassessment (fired from on_task_done below) can
    # render as a wait-screen overlay on the already-running app
    # instead of spinning up a fresh WaitApp in a second thread.
    tui_overlay_app: dict[str, object | None] = {"app": None}

    # Hook for refreshing the TUI Progress tab after reassessment creates
    # new tasks on disk (split tasks T04A/T04B or retro tasks T04R1).
    # Set to a callable once the TUI session is active; None otherwise.
    # Using a dict so run_reassessment_if_needed (defined before the TUI
    # session opens) can see the hook that is set later inside the session.
    _tui_plan_refresh_hook: dict[str, Any] = {"fn": None}

    def _sync_plan_from_disk() -> None:
        """Re-discover tasks on disk and add any new ones to plan.tasks.

        Called after reassessment so that split tasks (T04A, T04B) or retro
        tasks (T04R1) written to disk during reassessment become visible in
        the TUI Progress tab and in the execution loop's task list.

        Also fires the TUI refresh hook when the TUI is active so the new
        rows appear immediately without waiting for the next task start.
        """
        _tasks_dir = project / config.tasks_dir.name
        try:
            fresh_tasks = _filter_and_set_status(discover_tasks(_tasks_dir), config.progress_file)
        except Exception as exc:
            logger.warning(f"Post-reassessment task re-discovery failed (non-fatal): {exc!r}")
            return

        known_prefixes = {t.prefix for t in plan.tasks}
        added: list[str] = []
        for ft in fresh_tasks:
            if ft.prefix not in known_prefixes:
                plan.tasks.append(ft)
                known_prefixes.add(ft.prefix)
                added.append(ft.prefix)

        if added:
            # Re-sort so new tasks (T04A before T05, T04R1 after T04) land in
            # the correct execution order.  The for-loop in _run_all_inner
            # iterates plan.tasks by index and will pick up the newly-added
            # tasks because Python list iteration sees appended items.
            plan.tasks.sort(key=task_sort_key)
            logger.info(
                f"Post-reassessment: added {len(added)} new task(s) to plan: " + ", ".join(added)
            )

        # Fire TUI refresh (no-op when TUI is not active).
        hook = _tui_plan_refresh_hook.get("fn")
        if hook is not None:
            try:
                hook(added)
            except Exception as exc:
                logger.debug(f"TUI plan-refresh hook raised (non-fatal): {exc!r}")

    def run_reassessment_if_needed(result: TaskResult) -> None:
        """Run targeted reassessment when a task may affect remaining work."""
        force_reassessment = config.force_reassessment
        if provider is None or (not force_reassessment and not _result_needs_reassessment(result)):
            return

        console.print(f"[dim]↺ reassessing downstream tasks after {result.prefix}…[/dim]")
        overlay_app = tui_overlay_app["app"]
        if overlay_app is not None:
            from the_architect.tui import WaitLogRenderer, tui_wait_session

            with tui_wait_session(
                enabled=True,
                title=f"reassessing after {result.prefix}…",
                overlay_app=overlay_app,  # type: ignore[arg-type]
            ) as _wait:
                _wait.set_detail(
                    f"Task: {result.prefix}\nStatus: {result.status}\n"
                    f"Outcome: {result.outcome_summary[:200]}"
                )
                _reassess_renderer = WaitLogRenderer(session=_wait)
                try:
                    reassessment = _run_reassessment_in_thread(
                        run_task_reassessment(
                            project_dir=project,
                            provider=provider,
                            config=config,
                            completed_task=result.prefix,
                            outcome_summary=result.outcome_summary,
                            original_goal=original_goal,
                            model_override=model_override,
                            log_path=reassessment_log_dir / f"{result.prefix.lower()}_reassess.log",
                            renderer=_reassess_renderer,
                            task_status=result.status,
                            force=force_reassessment,
                        )
                    )
                except Exception as exc:
                    logger.warning(f"Inline reassessment failed for {result.prefix}: {exc!r}")
                    reassessment = None
        else:
            # Non-TUI path: run reassessment in a fresh thread so we never
            # nest asyncio.run() calls inside the outer event loop context.
            try:
                reassessment = _run_reassessment_in_thread(
                    run_task_reassessment(
                        project_dir=project,
                        provider=provider,
                        config=config,
                        completed_task=result.prefix,
                        outcome_summary=result.outcome_summary,
                        original_goal=original_goal,
                        model_override=model_override,
                        log_path=reassessment_log_dir / f"{result.prefix.lower()}_reassess.log",
                        task_status=result.status,
                        force=force_reassessment,
                    )
                )
            except Exception as exc:
                logger.warning(f"Inline reassessment failed for {result.prefix}: {exc!r}")
                reassessment = None

        if reassessment is not None and reassessment.tasks_updated:
            console.print()
            console.print(
                f"[yellow]↺ Reassessed after {result.prefix}[/yellow]  "
                f"[dim]{reassessment.summary}[/dim]"
            )

        # Always re-sync plan.tasks from disk so any new task files written
        # by reassessment (split tasks T04A/T04B, retro tasks T04R1) are
        # visible to the execution loop and to the TUI Progress tab.
        _sync_plan_from_disk()

    def on_task_start(task: Task) -> None:
        remaining = sum(1 for t in plan.tasks if _task_needs_work(t))
        title = task.title or task.name
        suffix = (
            f"  [dim]({remaining}/{pending_count} remaining)[/dim]" if pending_count > 1 else ""
        )
        console.print()
        console.print(f"[bold #7cc800]══ {task.prefix}[/bold #7cc800]  [dim]{title}[/dim]{suffix}")
        if monitor_writer is not None:
            try:
                monitor_writer.on_task_start(task)
            except Exception:
                pass

    def on_task_done(result: TaskResult) -> None:
        results.append(result)
        _record_task_outcome(config.progress_file, result)
        run_reassessment_if_needed(result)
        console.print()
        console.print(
            f"[#7cc800]✓ {result.prefix} done[/#7cc800]  "
            f"[dim]{_fmt_duration(result.duration_seconds)}[/dim]"
        )
        console.print(_SEPARATOR)
        if monitor_writer is not None:
            try:
                monitor_writer.on_task_done(
                    result.prefix,
                    tokens=result.tokens.total,
                    input_tokens=result.tokens.input_tokens,
                    output_tokens=result.tokens.output_tokens,
                    cache_read_tokens=result.tokens.cache_read_tokens,
                    cache_write_tokens=result.tokens.cache_write_tokens,
                    model=result.model,
                )
            except Exception:
                pass

    def on_task_failed(result: TaskResult) -> None:
        results.append(result)
        run_reassessment_if_needed(result)
        console.print()
        console.print(f"[red]✗ {result.prefix} failed after {config.max_retries} attempts[/red]")
        console.print(_SEPARATOR)
        if monitor_writer is not None:
            try:
                monitor_writer.on_task_failed(
                    result.prefix,
                    tokens=result.tokens.total,
                    input_tokens=result.tokens.input_tokens,
                    output_tokens=result.tokens.output_tokens,
                    cache_read_tokens=result.tokens.cache_read_tokens,
                    cache_write_tokens=result.tokens.cache_write_tokens,
                    model=result.model,
                )
            except Exception:
                pass

    def on_attempt_start(attempt_num: int, model: str | None) -> None:
        if attempt_num > 1:
            model_note = f" → {model}" if model else ""
            console.print()
            console.print(
                f"[yellow]↻ Retry {attempt_num}/{config.max_retries}{model_note}[/yellow]"
            )
            console.print()
        if monitor_writer is not None:
            try:
                monitor_writer.on_attempt_start(attempt_num, model)
            except Exception:
                pass

    def on_model_switched(old_model: str, new_model: str | None) -> None:
        """Called when --free mode rotates to a new model due to rate limit."""
        if new_model:
            console.print()
            console.print(
                f"[yellow]⚡ Rate limit hit on {old_model}[/yellow]  "
                f"[dim]→ switching to {new_model}[/dim]"
            )
            console.print()
        else:
            console.print()
            console.print(
                f"[yellow]⚡ Rate limit hit on {old_model}[/yellow]  "
                f"[dim]→ all free models exhausted, falling back to default[/dim]"
            )
            console.print()
        if monitor_writer is not None and new_model:
            try:
                monitor_writer.on_model_rotated(new_model)
            except Exception:
                pass

    def on_attempt_done(attempt_num: int, success: bool) -> None:
        if not success and attempt_num < config.max_retries:
            next_model = (
                config.retry_model_2
                if attempt_num + 1 == 2 and config.retry_model_2
                else config.retry_model_3
                if attempt_num + 1 == 3 and config.retry_model_3
                else None
            )
            model_note = f" switching to {next_model}" if next_model else ""
            console.print(
                f"\n[dim]Attempt {attempt_num} did not mark task Done —"
                f" retrying ({attempt_num + 1}/{config.max_retries}){model_note}...[/dim]"
            )
        if monitor_writer is not None:
            try:
                monitor_writer.on_attempt_done(attempt_num, success)
            except Exception:
                pass

    def on_circuit_event(event_name: str, data: dict[str, Any]) -> None:
        """Forward circuit/cooldown/replan events to the monitor writer."""
        if monitor_writer is None:
            return
        try:
            if event_name == "circuit_state_change":
                monitor_writer.on_circuit_state_change(
                    state=data.get("state", "CLOSED"),
                    no_progress=data.get("no_progress", 0),
                    same_error=data.get("same_error", 0),
                    no_progress_threshold=data.get("no_progress_threshold", 3),
                    same_error_threshold=data.get("same_error_threshold", 3),
                )
            elif event_name == "cooldown_start":
                monitor_writer.on_cooldown_start(
                    task_id=data.get("task_id", ""),
                    wait_count=data.get("wait_count", 0),
                )
            elif event_name == "cooldown_end":
                monitor_writer.on_cooldown_end()
            elif event_name == "replan_start":
                monitor_writer.on_replan(task_id=data.get("task_id", ""))
            elif event_name == "replan_end":
                monitor_writer.on_replan_done()
        except Exception:
            pass  # Monitor write failure must not stop the run

    # Pre-populate results for already-resolved tasks so the run summary
    # summary reflects their real state.  Done → skipped (they were
    # already complete before this run).  Failed → we surface them as
    # failed in the summary so the reviewer has full visibility and the
    # user is not misled into thinking every task succeeded.
    for t in plan.tasks:
        if t.status == TaskStatus.DONE:
            results.append(TaskResult(prefix=t.prefix, title=t.title or t.name, status="skipped"))
        elif t.status == TaskStatus.FAILED:
            results.append(TaskResult(prefix=t.prefix, title=t.title or t.name, status="failed"))

    # Build a pause callback for the runner's between-task delay. The
    # callback just blocks for ``seconds`` — no stdout painting, since
    # the Textual execution screen is the canonical UI surface. Legacy
    # stdout countdowns were removed along with the rest of the spinner
    # machinery.
    pause_index = {"n": 0}

    def _on_pause(seconds: int) -> None:
        pause_index["n"] += 1
        if seconds > 0:
            time.sleep(seconds)

    from the_architect.tui import tui_execution_session

    with tui_execution_session(enabled=bool(use_tui and _ansi_supported())) as _tui_session:
        # Publish the live app so between-task reassessment can render
        # as a wait-screen overlay on top of this app (Phase 7).
        tui_overlay_app["app"] = _tui_session.app

        # When the TUI is active, wrap the existing runner callbacks so
        # every circuit/cooldown/model/attempt event is also forwarded
        # into the Diagnostics and Progress tabs.  Business-logic callbacks
        # continue to fire unchanged.
        _orig_on_task_start = on_task_start
        _orig_on_attempt_start = on_attempt_start
        _orig_on_circuit_event = on_circuit_event
        _orig_on_model_switched = on_model_switched

        _tui_task_statuses: dict[str, str] = {
            t.prefix: "done"
            if t.status == TaskStatus.DONE
            else "failed"
            if t.status == TaskStatus.FAILED
            else "pending"
            for t in plan.tasks
        }
        # Per-task details for the Tasks tab DataTable.
        # Populated by on_task_done / on_task_failed callbacks.
        _tui_task_details: dict[str, dict[str, str]] = {}

        def _tui_progress_rows() -> list[dict[str, str]]:
            return [
                {
                    "prefix": t.prefix,
                    "title": t.title or t.name,
                    "status": _tui_task_statuses.get(t.prefix, "pending"),
                    "priority": t.priority or "medium",
                    **_tui_task_details.get(t.prefix, {}),
                }
                for t in plan.tasks
            ]

        def _tui_publish_progress() -> None:
            _tui_session.update_progress_tasks(_tui_progress_rows())

        def _tui_on_plan_refresh(added_prefixes: list[str]) -> None:
            """Called by _sync_plan_from_disk when new tasks appear on disk.

            Seeds _tui_task_statuses for each new prefix and republishes the
            full task list so the Progress tab shows split/retro tasks the
            moment they are created.
            """
            for prefix in added_prefixes:
                if prefix not in _tui_task_statuses:
                    _tui_task_statuses[prefix] = "pending"
            if added_prefixes:
                _tui_publish_progress()

        # Register the hook so _sync_plan_from_disk (defined before the TUI
        # session) can call it once the TUI is ready.
        _tui_plan_refresh_hook["fn"] = _tui_on_plan_refresh

        def _enabled(value: bool) -> str:
            return "enabled" if value else "disabled"

        def _tui_execution_settings() -> dict[str, str]:
            execution_model = ""
            if config.free_mode and free_rotator is not None:
                execution_model = str(getattr(free_rotator, "current_model", "") or "")
            if not execution_model:
                execution_model = config.standalone_mode or ""
            if not execution_model and provider is not None:
                try:
                    execution_model = provider.get_resolved_model(
                        project, config.execution_agent or "build"
                    )
                except Exception:
                    execution_model = ""

            supports_agents = False
            if provider is not None:
                try:
                    supports_agents = provider.supports_agents()
                except Exception:
                    supports_agents = False

            agent = config.execution_agent or "provider default"
            if provider is not None and not supports_agents:
                agent = "not supported"

            return {
                "Goal": _truncate_goal_for_display(original_goal),
                "Project": str(project),
                "Provider": getattr(provider, "display_name", "auto")
                if provider is not None
                else "auto",
                "Configured provider": config.provider,
                "Execution agent": agent,
                "Execution model": execution_model or "provider default",
                "Architect/review model": model_override
                or config.architect_model
                or "provider default",
                "Free mode": _enabled(config.free_mode),
                "Persistent mode": _enabled(config.persistent),
                "Integrity defense": _enabled(config.integrity),
                "Force reassessment": _enabled(config.force_reassessment),
                "Infinite Loop": _enabled(bool(getattr(config, "_infinite_loop_enabled", False))),
                "Retrospective rounds": str(config.retrospective_rounds),
                "Max retries": str(config.max_retries),
                "Retry pause": f"{config.retry_pause}s",
                "Pause between tasks": f"{config.pause_between_tasks}s",
                "Retry model 2": config.retry_model_2 or "same/default",
                "Retry model 3": config.retry_model_3 or "same/default",
                "Carry retry context": _enabled(config.carry_context),
                "Retry prompt mode": config.retry_prompt_mode,
                "Circuit replan": _enabled(config.circuit_enable_replan),
                "Cooldown detection": _enabled(config.cooldown_detection),
                "Circuit cooldown": f"{config.circuit_cooldown_minutes}m",
                "Token budget/hour": str(config.token_budget_per_hour or "unlimited"),
                "Token budget/run": str(config.token_budget_per_run or "unlimited"),
                "Task timeout": str(config.task_timeout or "unlimited"),
                "Tasks in run": str(len(plan.tasks)),
            }

        def _tui_on_task_start(t: Task) -> None:
            _tui_task_statuses[t.prefix] = "running"
            _tui_publish_progress()
            _tui_session.update_details(
                task=f"{t.prefix} {t.title or t.name}",
                phase="starting",
                attempt="1",
                model="",
                tokens="",
            )
            _tui_session.update_footer(f"{t.prefix} | starting {t.title or t.name}")
            # Phase 18: also show run-scoped state in the header.
            if _tui_session.app is not None:
                try:
                    _tui_session.app.set_status(f"{t.prefix} · starting · {t.title or t.name}")
                except Exception:
                    pass
            _tui_session.push_event("task_start", {"task": t.prefix, "title": t.title or t.name})
            # Also echo a banner into the Output tab so it's not empty before
            # provider output arrives.
            if _tui_session.app is not None:
                try:
                    _tui_session.app.push_output_line("")
                    _tui_session.app.push_output_line(f"══ {t.prefix}  {t.title or t.name}")
                except Exception:
                    pass
            _orig_on_task_start(t)

        def _tui_on_attempt_start(attempt_num: int, model: str | None) -> None:
            _tui_session.update_details(
                phase="executing",
                attempt=f"{attempt_num}/{config.max_retries}",
                model=model or "default",
            )
            _tui_session.update_footer(
                f"attempt {attempt_num}/{config.max_retries} | model {model or 'default'}"
            )
            # Phase 18: run-scoped header status.
            if _tui_session.app is not None:
                try:
                    _tui_session.app.set_status(
                        f"attempt {attempt_num}/{config.max_retries} · {model or 'default'}"
                    )
                except Exception:
                    pass
            _tui_session.push_event(
                "attempt_start",
                {"attempt": attempt_num, "model": model or "default"},
            )
            # Echo attempt header into the Output tab for visibility.
            if _tui_session.app is not None:
                try:
                    _tui_session.app.push_output_line(
                        f"→ attempt {attempt_num}/{config.max_retries} · model {model or 'default'}"
                    )
                except Exception:
                    pass
            _orig_on_attempt_start(attempt_num, model)

        def _tui_on_circuit_event(event_name: str, data: dict[str, Any]) -> None:
            _tui_session.push_event(event_name, data)
            if event_name == "cooldown_start":
                _tui_session.update_details(phase="cooldown")
                _tui_session.update_footer(f"cooldown | wait {data.get('wait_count', 0)}")
            elif event_name == "cooldown_end":
                _tui_session.update_details(phase="resumed")
                _tui_session.update_footer("resumed after cooldown")
            elif event_name == "replan_start":
                _tui_session.update_details(phase="replanning")
                _tui_session.update_footer("replanning task")
            elif event_name == "replan_end":
                _tui_session.update_details(phase="replan_done")
                _tui_session.update_footer("replan complete")
            elif event_name == "sleep_detected":
                # The host machine slept mid-attempt.  Update the TUI to
                # show a "sleeping" banner and restore the terminal so
                # mouse-cursor codes don't bleed into the console on wake.
                _sleep_retry = data.get("sleep_retries", "?")
                _tui_session.update_details(phase="sleeping")
                _tui_session.update_footer(
                    f"computer sleeping — will resume on wake  (sleep-retry {_sleep_retry})"
                )
                if _tui_session.app is not None:
                    try:
                        _tui_session.app.push_output_line(
                            f"[dim]Computer slept mid-task — "
                            f"waiting for wake (sleep-retry {_sleep_retry}/10)[/dim]"
                        )
                        _tui_session.app.set_status("sleeping — will resume automatically on wake")
                    except Exception:
                        pass
                # Proactively restore terminal modes so mouse-tracking
                # escape codes don't bleed into the console if the
                # terminal loses its TUI state during suspend.
                try:
                    from the_architect.tui.terminal import restore_terminal_input_modes

                    restore_terminal_input_modes()
                except Exception:
                    pass
            elif event_name == "wake_resumed":
                _tui_session.update_details(phase="executing")
                _tui_session.update_footer("woke from sleep — resuming task")
                if _tui_session.app is not None:
                    try:
                        _tui_session.app.push_output_line(
                            "[#7cc800]Computer woke — retrying task[/#7cc800]"
                        )
                        _tui_session.app.set_status("")
                    except Exception:
                        pass
            _orig_on_circuit_event(event_name, data)

        def _tui_on_model_switched(old_model: str, new_model: str | None) -> None:
            _tui_session.push_event(
                "model_switched",
                {"from": old_model, "to": new_model or "default"},
            )
            _tui_session.update_details(model=new_model or "default")
            _tui_session.update_footer(f"switched model | now {new_model or 'default'}")
            _orig_on_model_switched(old_model, new_model)

        # Swap the callbacks only when the TUI is actually running.
        _ts: Callable[[Task], None]
        _as: Callable[[int, str | None], None]
        _ce: Callable[[str, dict[str, Any]], None]
        _ms: Callable[[str, str | None], None]
        _td: Callable[[TaskResult], None]
        _tf: Callable[[TaskResult], None]

        def _tui_on_task_done(result: TaskResult) -> None:
            _tui_task_statuses[result.prefix] = "done"
            # Store per-task details for the Tasks tab DataTable
            _tui_task_details[result.prefix] = {
                "tokens": str(result.tokens.total),
                "model": result.model or "",
            }
            _tui_publish_progress()
            _tui_session.push_event(
                "task_done",
                {"task": result.prefix, "duration": f"{result.duration_seconds:.1f}s"},
            )
            if _tui_session.app is not None:
                try:
                    _tui_session.app.push_output_line(
                        f"✓ {result.prefix} done · {result.duration_seconds:.1f}s"
                    )
                except Exception:
                    pass
            on_task_done(result)
            # Push live cost data to the Costs tab
            if _tui_session.app is not None:
                try:
                    from the_architect.core.token_ledger import estimate_cost_detailed

                    _session_cost_usd = 0.0
                    _model_costs_map: dict[str, float] = {}
                    _session_tokens_total = 0
                    for r in results:
                        if r.model and r.tokens.total > 0:
                            c = estimate_cost_detailed(
                                input_tokens=r.tokens.input_tokens,
                                output_tokens=r.tokens.output_tokens,
                                cache_read_tokens=r.tokens.cache_read_tokens,
                                cache_write_tokens=r.tokens.cache_write_tokens,
                                model=r.model,
                            )
                            _session_cost_usd += c
                            _model_costs_map[r.model] = _model_costs_map.get(r.model, 0.0) + c
                        _session_tokens_total += r.tokens.total
                    last_cost = 0.0
                    if result.model and result.tokens.total > 0:
                        last_cost = estimate_cost_detailed(
                            input_tokens=result.tokens.input_tokens,
                            output_tokens=result.tokens.output_tokens,
                            cache_read_tokens=result.tokens.cache_read_tokens,
                            cache_write_tokens=result.tokens.cache_write_tokens,
                            model=result.model,
                        )
                    costs_payload: dict[str, object] = {
                        "session_cost_usd": _session_cost_usd,
                        "last_task_cost_usd": last_cost,
                        "session_tokens": _session_tokens_total,
                        "model_costs": _model_costs_map,
                    }
                    if config.token_budget_per_run > 0:
                        budget_used = _session_tokens_total
                        budget_remaining = max(0, config.token_budget_per_run - budget_used)
                        budget_pct = min(100, (budget_used / config.token_budget_per_run) * 100)
                        costs_payload["budget_per_run"] = config.token_budget_per_run
                        costs_payload["budget_per_run_used"] = budget_used
                        costs_payload["budget_per_run_remaining"] = budget_remaining
                        costs_payload["budget_per_run_pct"] = budget_pct
                    _tui_session.update_costs(costs_payload)
                except Exception:
                    pass

        def _tui_on_task_failed(result: TaskResult) -> None:
            _tui_task_statuses[result.prefix] = "failed"
            # Store per-task details for the Tasks tab DataTable
            _tui_task_details[result.prefix] = {
                "tokens": str(result.tokens.total),
                "model": result.model or "",
            }
            _tui_publish_progress()
            _tui_session.push_event("task_failed", {"task": result.prefix})
            if _tui_session.app is not None:
                try:
                    _tui_session.app.push_output_line(
                        f"✗ {result.prefix} failed after {config.max_retries} attempts"
                    )
                except Exception:
                    pass
            on_task_failed(result)
            # Push live cost data to the Costs tab
            if _tui_session.app is not None:
                try:
                    from the_architect.core.token_ledger import estimate_cost_detailed

                    _session_cost_usd_f = 0.0
                    _model_costs_map_f: dict[str, float] = {}
                    _session_tokens_total_f = 0
                    for r in results:
                        if r.model and r.tokens.total > 0:
                            c = estimate_cost_detailed(
                                input_tokens=r.tokens.input_tokens,
                                output_tokens=r.tokens.output_tokens,
                                cache_read_tokens=r.tokens.cache_read_tokens,
                                cache_write_tokens=r.tokens.cache_write_tokens,
                                model=r.model,
                            )
                            _session_cost_usd_f += c
                            _model_costs_map_f[r.model] = _model_costs_map_f.get(r.model, 0.0) + c
                        _session_tokens_total_f += r.tokens.total
                    last_cost_f = 0.0
                    if result.model and result.tokens.total > 0:
                        last_cost_f = estimate_cost_detailed(
                            input_tokens=result.tokens.input_tokens,
                            output_tokens=result.tokens.output_tokens,
                            cache_read_tokens=result.tokens.cache_read_tokens,
                            cache_write_tokens=result.tokens.cache_write_tokens,
                            model=result.model,
                        )
                    costs_payload_f: dict[str, object] = {
                        "session_cost_usd": _session_cost_usd_f,
                        "last_task_cost_usd": last_cost_f,
                        "session_tokens": _session_tokens_total_f,
                        "model_costs": _model_costs_map_f,
                    }
                    if config.token_budget_per_run > 0:
                        budget_used_f = _session_tokens_total_f
                        budget_remaining_f = max(0, config.token_budget_per_run - budget_used_f)
                        budget_pct_f = min(100, (budget_used_f / config.token_budget_per_run) * 100)
                        costs_payload_f["budget_per_run"] = config.token_budget_per_run
                        costs_payload_f["budget_per_run_used"] = budget_used_f
                        costs_payload_f["budget_per_run_remaining"] = budget_remaining_f
                        costs_payload_f["budget_per_run_pct"] = budget_pct_f
                    _tui_session.update_costs(costs_payload_f)
                except Exception:
                    pass

        if _tui_session.app is not None:
            _tui_session.update_details(goal=original_goal)
            _tui_session.update_settings(_tui_execution_settings())
            _tui_publish_progress()
            _ts = _tui_on_task_start
            _as = _tui_on_attempt_start
            _ce = _tui_on_circuit_event
            _ms = _tui_on_model_switched
            _td = _tui_on_task_done
            _tf = _tui_on_task_failed
        else:
            _ts = on_task_start
            _as = on_attempt_start
            _ce = on_circuit_event
            _ms = on_model_switched
            _td = on_task_done
            _tf = on_task_failed

        # ── Pre-run hooks ────────────────────────────────────────────────
        _hook_renderer: object | None = None
        if _tui_session.app is not None:
            _hook_renderer = _tui_session.renderer
        await _fire_hooks(project, HookEvent.pre_run, renderer=_hook_renderer)

        success = await run_all(
            plan=plan,
            config=config,
            on_task_start=_ts,
            on_task_done=_td,
            on_task_failed=_tf,
            on_attempt_start=_as,
            on_attempt_done=on_attempt_done,
            on_task_pause=_on_pause,
            free_rotator=free_rotator,
            on_model_switched=_ms,
            on_circuit_event=_ce,
            provider=provider,
            on_first_output=None,
            renderer=_tui_session.renderer,
            verify_resume=verify_resume,
        )

    # Clear overlay ref once the main app has torn down.
    tui_overlay_app["app"] = None

    total_duration = time.time() - run_start
    return success, results, total_duration


def _fmt_duration(seconds: float) -> str:
    """Format seconds as M:SS."""
    total = int(seconds)
    h, remainder = divmod(total, 3600)
    m, s = divmod(remainder, 60)
    if h > 0:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


def _read_goal_md(tasks_dir: Path) -> str:
    """Read tasks/GOAL.md, returning the original planning goal when present."""
    goal_md = tasks_dir / GOAL_FILE_NAME
    if not goal_md.exists():
        return ""
    try:
        content = goal_md.read_text(encoding="utf-8")
    except OSError:
        return ""

    lines = content.splitlines()
    if lines and lines[0].strip().startswith("#"):
        lines = lines[1:]
    return "\n".join(lines).strip()


def _read_goal_from_instructions(tasks_dir: Path) -> str:
    """Try to read the original goal from tasks/INSTRUCTIONS.md.

    Falls back to empty string if the file doesn't exist or can't be parsed.

    Args:
        tasks_dir: Path to the tasks/ directory.

    Returns:
        The goal string, or empty string if not found.
    """
    goal_md = _read_goal_md(tasks_dir)
    if goal_md:
        return goal_md

    instructions_md = tasks_dir / "INSTRUCTIONS.md"
    if not instructions_md.exists():
        return ""
    try:
        content = instructions_md.read_text(encoding="utf-8")
        # Prefer canonical "## Goal"; provider-written plans often use
        # "## Goal Summary", which Infinite Loop must also be able to reuse.
        import re

        match = re.search(
            r"^## Goal\s*\n\s*(.+?)(?:\n\s*##|\n\s*$)",
            content,
            re.DOTALL | re.MULTILINE,
        )
        if not match:
            match = re.search(
                r"^## Goal Summary\s*\n\s*(.+?)(?:\n\s*##|\n\s*$)",
                content,
                re.DOTALL | re.MULTILINE,
            )
        if match:
            return match.group(1).strip()
    except OSError:
        pass
    return ""


def _record_task_outcome(progress_file: Path, result: TaskResult) -> None:
    """Persist a concise task outcome row and refresh Last Task Summary."""
    try:
        content = progress_file.read_text(encoding="utf-8")
    except OSError:
        return

    summary = (result.outcome_summary or "Downstream impact: none").strip()
    summary_single = summary.replace("\n", " ; ")
    impact = "Possible" if "Downstream impact: possible" in summary else "None"
    row = (
        f"| {result.prefix} | {summary_single} | Captured in summary | "
        f"Captured in summary | {impact} |\n"
    )
    marker = (
        "## Task Outcomes\n\n"
        "| Task | Outcome | Files | Verification | Impact on Next Tasks |\n"
        "|------|---------|-------|--------------|----------------------|\n"
    )
    if marker in content and row not in content:
        content = content.replace(marker, marker + row)

    import re

    content = re.sub(
        r"## Last Task Summary\s*\n\s*.*?(?=\n---)",
        f"## Last Task Summary\n\n{summary}\n",
        content,
        flags=re.DOTALL,
    )

    try:
        progress_file.write_text(content, encoding="utf-8")
    except OSError:
        return


def _task_results_needing_reassessment(results: list[TaskResult]) -> list[TaskResult]:
    """Return task results that should trigger downstream task reassessment."""
    return [result for result in results if _result_needs_reassessment(result)]


def _result_needs_reassessment(result: TaskResult) -> bool:
    """Return True for conditional downstream reassessment triggers."""
    if result.status == "failed":
        return True
    return result.status == "done" and "Downstream impact: possible" in result.outcome_summary


def _run_reassessment_in_thread(coro: Any) -> Any:
    """Run an async reassessment coroutine in a dedicated thread.

    Using a dedicated thread guarantees the coroutine runs in a fresh
    event loop — safe regardless of whether the caller is itself inside
    an async context.  This avoids the ``asyncio.run()`` re-entrancy
    issue that arises when ``on_task_done`` (a sync callback) is invoked
    from within an outer ``asyncio.run()`` call chain.

    Args:
        coro: The coroutine to run (e.g. ``run_task_reassessment(...)``).

    Returns:
        The coroutine's return value.

    Raises:
        Any exception raised by the coroutine is re-raised in the
        calling thread.
    """
    import concurrent.futures

    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(asyncio.run, coro)
        return future.result()


def _provider_install_hint() -> str:
    """Return the install command for the detected provider.

    Returns:
        Human-readable install command string.
    """
    from the_architect.core.provider import detect_provider

    try:
        return detect_provider("auto").install_hint()
    except Exception:
        from the_architect.core.opencode_provider import OpenCodeProvider

        return OpenCodeProvider().install_hint()


# Backward-compatible alias — tests import this name
_opencode_install_hint = _provider_install_hint


def _render_dry_run_summary(
    tasks: list[Task],
    config: ArchitectConfig,
    provider: ArchitectProvider | None = None,
) -> None:
    """Render the dry-run plan summary and exit.

    Displays task list, estimated cost, and dependency validation results.
    Task files created by the planner remain on disk for user review.

    Args:
        tasks: Discovered tasks from the planner.
        config: The Architect configuration.
        provider: The resolved AI CLI provider, if available.
    """
    console.print()
    console.print("[bold cyan]═" * 60 + "[/bold cyan]")
    console.print("[bold cyan]  DRY-RUN MODE — Plan Summary[/bold cyan]")
    console.print("[bold cyan]═" * 60 + "[/bold cyan]")
    console.print()

    # Task list
    from rich.table import Table

    console.print("[bold]Tasks:[/bold]")
    table = Table(show_header=True, header_style="bold", box=None)
    table.add_column("#", style="dim", width=5)
    table.add_column("Task", style="bold", width=8)
    table.add_column("Title", width=40)
    table.add_column("Deps", style="dim", width=12)

    for idx, t in enumerate(tasks, 1):
        deps_str = ", ".join(t.depends_on) if t.depends_on else "—"
        table.add_row(str(idx), t.prefix, t.title or t.name, deps_str)

    console.print(table)
    console.print()

    # Cost estimate
    try:
        from the_architect.core.estimate_cost import estimate_run_cost
        from the_architect.core.token_ledger import load_ledger

        model = ""
        if config.standalone_mode:
            model = config.standalone_mode
        if not model:
            ledger = load_ledger(config.project_root)
            if ledger.records:
                last_run = ledger.records[-1]
                if last_run.model_breakdown:
                    model = last_run.model_breakdown[0].model
        if not model:
            model = "anthropic/claude-sonnet-4-20250514"

        estimate = estimate_run_cost(ledger, model, len(tasks))

        console.print("[bold]Cost Estimate:[/bold]")
        conf_label = {
            "high": "green",
            "medium": "yellow",
            "low": "red",
        }.get(estimate.confidence, "white")
        console.print(
            f"  Model: [bold]{model}[/bold]  "
            f"Confidence: [{conf_label}]{estimate.confidence}[/{conf_label}]"
        )
        console.print(
            f"  Estimated cost: [bold]${estimate.cost_low:.2f}[/bold] – "
            f"[bold]${estimate.cost_high:.2f}[/bold] "
            f"(avg [bold]${estimate.cost_avg:.2f}[/bold])"
        )
        if estimate.historical_runs > 0:
            console.print(f"  Based on [bold]{estimate.historical_runs}[/bold] historical run(s)")
        else:
            console.print("  Based on pricing table only (no historical data)")
        console.print()
    except Exception as exc:
        logger.warning(f"Cost estimation failed during dry-run (non-fatal): {exc!r}")
        console.print("[bold]Cost Estimate:[/bold]")
        console.print("  [dim]Unable to estimate (no historical data or pricing info)[/dim]")
        console.print()

    # Dependency validation
    from the_architect.core.tasks import (
        detect_dependency_cycles,
        detect_missing_dependencies,
    )

    cycles = detect_dependency_cycles(tasks)
    missing_deps = detect_missing_dependencies(tasks)

    has_issues = bool(cycles) or bool(missing_deps)

    console.print("[bold]Dependency Validation:[/bold]")
    if cycles:
        for cycle in cycles:
            console.print(f"  [red]✗ Cycle detected:[/red] {' → '.join(cycle)}")
    if missing_deps:
        for prefix, missing in sorted(missing_deps.items()):
            console.print(
                f"  [yellow]⚠ {prefix}[/yellow] depends on non-existent task(s): "
                f"{', '.join(missing)}"
            )
    if not has_issues:
        console.print("  [green]✓ No dependency issues found[/green]")
    console.print()

    # Config summary
    console.print("[bold]Configuration:[/bold]")
    console.print(f"  Provider: [bold]{provider.display_name if provider else 'unknown'}[/bold]")
    console.print(f"  Scope: [bold]{config.last_scope or 'standard'}[/bold]")
    console.print(f"  Max retries: [bold]{config.max_retries}[/bold]")
    if config.token_budget_per_hour > 0:
        console.print(f"  Token budget/hour: [bold]{config.token_budget_per_hour}[/bold]")
    if config.token_budget_per_run > 0:
        console.print(f"  Token budget/run: [bold]{config.token_budget_per_run}[/bold]")
    if config.task_timeout > 0:
        console.print(f"  Task timeout: [bold]{config.task_timeout}s[/bold]")
    console.print()

    # Footer
    console.print("[dim]Task files created in tasks/ for review.[/dim]")
    console.print("[dim]Run without --dry-run to execute the plan.[/dim]")
    console.print()


def _format_dry_run_json(
    tasks: list[Task],
    config: ArchitectConfig,
    provider: ArchitectProvider | None = None,
) -> str:
    """Return the dry-run plan summary as structured JSON.

    Computes the same data as [_render_dry_run_summary][] but returns
    clean JSON for machine consumption.

    Args:
        tasks: Discovered tasks from the planner.
        config: The Architect configuration.
        provider: The resolved AI CLI provider, if available.

    Returns:
        JSON string with tasks, estimate, validation, and config sections.
    """
    # Task list
    tasks_out: list[dict[str, object]] = []
    for task in tasks:
        tasks_out.append(
            {
                "task_id": task.prefix,
                "title": task.title or task.name,
                "depends_on": task.depends_on,
            }
        )

    # Cost estimate
    estimate_out: dict[str, object] = {
        "model": "",
        "task_count": len(tasks),
        "cost_low": 0.0,
        "cost_high": 0.0,
        "cost_avg": 0.0,
        "historical_runs": 0,
        "confidence": "low",
    }
    try:
        from the_architect.core.estimate_cost import estimate_run_cost
        from the_architect.core.token_ledger import load_ledger

        model = ""
        if config.standalone_mode:
            model = config.standalone_mode
        if not model:
            ledger = load_ledger(config.project_root)
            if ledger.records:
                last_run = ledger.records[-1]
                if last_run.model_breakdown:
                    model = last_run.model_breakdown[0].model
        if not model:
            model = "anthropic/claude-sonnet-4-20250514"

        ledger = load_ledger(config.project_root)
        estimate = estimate_run_cost(ledger, model, len(tasks))

        estimate_out = {
            "model": model,
            "task_count": len(tasks),
            "cost_low": estimate.cost_low,
            "cost_high": estimate.cost_high,
            "cost_avg": estimate.cost_avg,
            "historical_runs": estimate.historical_runs,
            "confidence": estimate.confidence,
        }
    except Exception:
        # Fallback: return zeroed estimate with low confidence
        pass

    # Dependency validation
    from the_architect.core.tasks import (
        detect_dependency_cycles,
        detect_missing_dependencies,
    )

    cycles = detect_dependency_cycles(tasks)
    missing_deps = detect_missing_dependencies(tasks)

    validation_out: dict[str, object] = {
        "cycles": [list(c) for c in cycles],
        "missing_deps": {k: list(v) for k, v in missing_deps.items()},
    }

    # Config summary
    config_out: dict[str, object] = {
        "model": config.standalone_mode or "",
        "scope": config.last_scope or "standard",
        "provider": provider.display_name if provider else "unknown",
        "max_retries": config.max_retries,
    }
    if config.token_budget_per_hour > 0:
        config_out["token_budget_per_hour"] = config.token_budget_per_hour
    if config.token_budget_per_run > 0:
        config_out["token_budget_per_run"] = config.token_budget_per_run
    if config.task_timeout > 0:
        config_out["task_timeout"] = config.task_timeout

    result: dict[str, object] = {
        "tasks": tasks_out,
        "estimate": estimate_out,
        "validation": validation_out,
        "config": config_out,
    }

    return json.dumps(result, indent=2)


# ---------------------------------------------------------------------------
# Main CLI
# ---------------------------------------------------------------------------


@click.group(invoke_without_command=True)
@click.version_option(
    __full_version__,
    "-V",
    "--version",
    message="architect v%(version)s",
)
@click.pass_context
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Project directory (default: current working directory)",
)
@click.option("--plan", is_flag=True, help="Force planning mode")
@click.option(
    "--standalone",
    default="",
    metavar="MODEL",
    help="Use this model directly (bypasses provider config)",
)
@click.option(
    "--from",
    "from_task",
    default="",
    metavar="PREFIX",
    help="Resume from a specific task prefix, e.g. --from T03",
)
@click.option(
    "--only",
    "only_task",
    default="",
    metavar="PREFIX",
    help="Run a single task only, e.g. --only T05",
)
@click.option(
    "--persistent",
    is_flag=True,
    help="Persistent mode: retry up to 30 times with 3 retrospective rounds",
)
@click.option(
    "--free",
    "free_mode",
    is_flag=True,
    help="Use free-tier OpenRouter models, rotating on rate limits (OpenCode + OpenRouter only)",
)
@click.option(
    "--headless",
    is_flag=True,
    help="Headless mode: no interactive prompts, all input via flags or env vars",
)
@click.option(
    "--goal",
    "goal_text",
    default="",
    metavar="TEXT",
    help="Planning goal (replaces interactive prompt, required in headless mode without --context)",
)
@click.option(
    "--scope",
    "scope_text",
    default=None,
    metavar="SCOPE",
    type=click.Choice(["simple", "standard", "complex"], case_sensitive=False),
    help="Task scope: simple, standard, or complex (default: standard)",
)
@click.option(
    "--context",
    "context_paths",
    multiple=True,
    type=click.Path(exists=True, path_type=Path),
    metavar="FILE_OR_DIR",
    help="Add file or directory to planning context (repeatable)",
)
@click.option(
    "--architect-model",
    "architect_model",
    default="",
    metavar="MODEL",
    help="Model for the architect agent (overrides opencode default)",
)
@click.option(
    "--execution-model",
    "execution_model",
    default="",
    metavar="MODEL",
    help="Model for the execution agent (overrides opencode default)",
)
@click.option(
    "--no-tui",
    "no_tui",
    is_flag=True,
    default=False,
    help=(
        "Disable the Textual TUI and fall back to plain CLI output. "
        "The TUI is on by default whenever stdout is a "
        "TTY with colour support; use this flag, NO_COLOR=1, TERM=dumb, "
        "--headless, or a non-TTY pipe to opt out."
    ),
)
@click.option(
    "--dry-run",
    "dry_run",
    is_flag=True,
    default=False,
    help="Run planner only — display plan summary and exit without executing tasks",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    default=False,
    help="Output dry-run summary as structured JSON (only effective with --dry-run)",
)
@click.option(
    "--no-verify-resume",
    "no_verify_resume",
    is_flag=True,
    default=False,
    help="Disable automatic resume verification (skip baseline comparison)",
)
def main(
    ctx: click.Context,
    project: Path | None,
    plan: bool,
    standalone: str,
    from_task: str,
    only_task: str,
    persistent: bool,
    free_mode: bool,
    headless: bool,
    goal_text: str,
    scope_text: str,
    context_paths: tuple[Path, ...],
    architect_model: str,
    execution_model: str,
    no_tui: bool,
    dry_run: bool,
    as_json: bool,
    no_verify_resume: bool,
) -> None:
    """The Architect — fire-and-forget autonomous development."""
    _setup_loguru()

    if ctx.invoked_subcommand is not None:
        return

    # --dry-run is mutually exclusive with execution-intent flags
    if dry_run and (from_task or only_task or persistent):
        conflicts = []
        if from_task:
            conflicts.append("--from")
        if only_task:
            conflicts.append("--only")
        if persistent:
            conflicts.append("--persistent")
        console.print(
            f"[red]Error: --dry-run is mutually exclusive with {', '.join(conflicts)}.[/red]"
        )
        raise SystemExit(1)

    # Phase 11 — single opt-out flag. TUI is on by default whenever
    # stdout is a TTY with colour support. --no-tui / NO_COLOR=1 /
    # TERM=dumb / --headless / piping stdout all turn it off.
    explicit = False if no_tui else None
    resolved_use_tui = _resolve_tui_default(explicit, headless=headless)

    # Propagate to interactive screens via env var so prompt helpers can
    # branch without taking a new parameter everywhere.
    if resolved_use_tui:
        os.environ["ARCHITECT_TUI"] = "1"
    else:
        os.environ.pop("ARCHITECT_TUI", None)
    use_tui = resolved_use_tui

    resolved_project = (project or Path.cwd()).resolve()

    # Resolve headless from env var if flag not set
    if not headless:
        headless = os.environ.get("ARCHITECT_HEADLESS", "").lower() in ("true", "1", "yes")

    # Resolve goal from env var if flag not set
    if not goal_text:
        goal_text = os.environ.get("ARCHITECT_GOAL", "")

    # Resolve scope from env var if flag not set
    if not scope_text:
        scope_text = os.environ.get("ARCHITECT_SCOPE", "")

    # Resolve context from env var if flag not set
    if not context_paths:
        env_context = os.environ.get("ARCHITECT_CONTEXT", "")
        if env_context:
            context_paths = tuple(Path(p) for p in env_context.split(os.pathsep) if p.strip())

    # Resolve architect-model from env var if flag not set
    if not architect_model:
        architect_model = os.environ.get("ARCHITECT_ARCHITECT_MODEL", "")

    # Resolve execution-model from env var if flag not set
    if not execution_model:
        execution_model = os.environ.get("ARCHITECT_EXECUTION_MODEL", "")

    # ── Early config + task discovery ───────────────────────────────────
    # Done BEFORE launching tmux so we can:
    #   1. Write the monitor state file before the dashboard pane starts
    #   2. Show the right dashboard screen immediately (PLANNING vs RUNNING)
    # This is cheap — no prompts, no opencode calls.
    config = load_config(resolved_project)

    if standalone:
        config.standalone_mode = standalone

    # ── Guard: standalone_mode must be compatible with the active provider ─
    # Runs here (before tmux / prompts) so the bad value is cleared before
    # it can be forwarded into _run_main via _pre_loaded_config.
    # Identical logic lives in _run_main for the non-pre-loaded path.
    if config.standalone_mode:
        _provider_hint = os.environ.get("ARCHITECT_PROVIDER", "").strip() or config.provider
        _is_claude_code_hint = _provider_hint in ("claude-code", "claude")
        if not _is_claude_code_hint:
            # Try to detect from installed binaries
            try:
                from the_architect.core.claude_code_provider import ClaudeCodeProvider as _CCP

                _det = detect_provider(_provider_hint if _provider_hint != "auto" else "auto")
                _is_claude_code_hint = isinstance(_det, _CCP)
            except Exception:
                pass
        if _is_claude_code_hint:
            sm = config.standalone_mode
            is_openrouter = sm.startswith("openrouter/") or (
                "/" in sm and not sm.startswith("claude")
            )
            if is_openrouter:
                logger.warning(
                    f"standalone_mode '{sm}' is incompatible with Claude Code "
                    "(OpenRouter model ID) — clearing"
                )
                config.standalone_mode = ""
                from the_architect.config import write_config as _write_cfg

                _write_cfg(resolved_project, {"standalone_mode": ""})

    # ── Phase 1 — Provider binary check (BEFORE tmux, no interactive UI) ──
    # Only check that at least one provider is installed.  If multiple are
    # installed the interactive selection is deferred until AFTER tmux
    # launches (Phase 2 below), so the prompt appears inside the left pane.
    #
    # If the user already chose a provider via architect.toml or the
    # ARCHITECT_PROVIDER env var (set by a previous Phase 2 selection and
    # forwarded into tmux), skip the check entirely.
    _provider_env = os.environ.get("ARCHITECT_PROVIDER", "").strip()
    _active_provider: ArchitectProvider | None = None

    try:
        if config.provider != "auto":
            # Explicit preference in architect.toml — validate immediately
            _active_provider = detect_provider(config.provider)
        elif _provider_env:
            # Already selected in a previous Phase 2 run (forwarded via env var)
            _active_provider = detect_provider(_provider_env)
        else:
            # Auto mode — check that at least one provider is installed and configured.
            _available_pre = detect_available_providers(require_models=True)
            if not _available_pre:
                installed_pre = detect_available_providers()
                if installed_pre:
                    console.print("[red]Error: No configured AI CLI provider found.[/red]")
                    console.print()
                    console.print(
                        "[dim]Installed providers were found, but none reported usable "
                        "models/API credentials. Run [bold]architect doctor[/bold] "
                        "for details.[/dim]"
                    )
                    raise SystemExit(1)

                console.print("[red]Error: No supported AI CLI found.[/red]")
                console.print()
                console.print("[dim]Install one of:[/dim]")
                for candidate in supported_providers():
                    console.print(
                        f"[dim]  {candidate.display_name}: {candidate.install_hint()}[/dim]"
                    )
                raise SystemExit(1)
            elif len(_available_pre) == 1:
                # Only one provider — resolve now, no prompt needed
                _active_provider = _available_pre[0]
            # else: multiple installed → defer selection to Phase 2 (post-tmux)
    except ProviderNotFoundError as _pnfe:
        console.print(f"[red]Error: {_pnfe}[/red]")
        raise SystemExit(1)

    # ── Provider usability check (non-blocking, only when already resolved) ─
    # Only warn when the provider appears to have no models/API key configured.
    # Skip when _active_provider is None (both installed, selection deferred).
    if _active_provider is not None and not _active_provider.has_any_models():
        user_cfg = _active_provider.find_user_config(resolved_project)
        if user_cfg is None:
            console.print()
            console.print(
                f"[yellow]{_active_provider.display_name} may not be configured yet.[/yellow]"
            )
            console.print()
            if _active_provider.name == "opencode":
                console.print(
                    "The Architect uses OpenCode to run AI agents. "
                    "OpenCode needs at least one provider."
                )
                console.print(
                    "Run [bold]opencode[/bold] once to set up a provider, then come back."
                )
                console.print()
                console.print("[dim]OpenCode looks for config in:[/dim]")
                console.print("[dim]  • OPENCODE_CONFIG env var (explicit config file path)[/dim]")
                console.print("[dim]  • OPENCODE_CONFIG_DIR env var (config directory)[/dim]")
                console.print("[dim]  • opencode.json / opencode.jsonc in the project root[/dim]")
                console.print("[dim]  • ~/.config/opencode/opencode.json (global)[/dim]")
                console.print("[dim]  • Built-in free models (no config needed)[/dim]")
            elif _active_provider.name == "codex":
                console.print(
                    "The Architect uses Codex CLI to run AI agents. "
                    "Set CODEX_API_KEY or run [bold]codex[/bold] to configure."
                )
                console.print()
                console.print("[dim]Codex CLI looks for config in:[/dim]")
                console.print("[dim]  • CODEX_API_KEY env var[/dim]")
                console.print("[dim]  • ~/.codex/config.toml (global)[/dim]")
            elif _active_provider.name == "gemini-cli":
                console.print(
                    "The Architect uses Gemini CLI to run AI agents. "
                    "Set GEMINI_API_KEY or run [bold]gemini[/bold] to configure."
                )
                console.print()
                console.print("[dim]Gemini CLI looks for config in:[/dim]")
                console.print("[dim]  • GEMINI_API_KEY env var[/dim]")
                console.print("[dim]  • GEMINI_MODEL env var (override default model)[/dim]")
                console.print("[dim]  • .gemini/settings.json (project-local)[/dim]")
                console.print("[dim]  • ~/.gemini/settings.json (global)[/dim]")
            else:
                console.print(
                    f"The Architect uses {_active_provider.display_name} to run AI agents. "
                    "Set ANTHROPIC_API_KEY or run [bold]claude[/bold] to configure."
                )
                console.print()
                console.print("[dim]Claude Code looks for config in:[/dim]")
                console.print("[dim]  • ANTHROPIC_API_KEY env var[/dim]")
                console.print("[dim]  • CLAUDE.md in the project root[/dim]")
                console.print("[dim]  • ~/.claude/CLAUDE.md (global)[/dim]")
            raise SystemExit(1)

    # ── Discover tasks BEFORE asking mode selection ─────────────────────
    # Mode selection (Free / Persistent) only affects execution — it is
    # meaningless when there are no tasks yet.  We check for tasks first,
    # then only ask about modes when we know execution will happen.
    tasks_dir = resolved_project / config.tasks_dir.name
    _tasks_pre = discover_tasks(tasks_dir)
    progress_file = config.progress_file
    _tasks_pre = _filter_and_set_status(_tasks_pre, progress_file)

    # Apply --only / --from for the pre-check
    if only_task:
        _matched_pre = [t for t in _tasks_pre if t.prefix.upper() == only_task.upper()]
        if not _matched_pre:
            console.print(f"[red]No task found with prefix '{only_task}'.[/red]")
            console.print("[dim]Run 'architect list' to see available tasks.[/dim]")
            raise SystemExit(1)
        _tasks_pre = _matched_pre
    elif from_task:
        _prefixes_pre = [t.prefix.upper() for t in _tasks_pre]
        _start_pre = from_task.upper()
        if _start_pre not in _prefixes_pre:
            console.print(f"[red]No task found with prefix '{from_task}'.[/red]")
            console.print("[dim]Run 'architect list' to see available tasks.[/dim]")
            raise SystemExit(1)
        _idx_pre = _prefixes_pre.index(_start_pre)
        _tasks_pre = _tasks_pre[_idx_pre:]

    _all_done_pre = bool(_tasks_pre) and all(_task_is_terminal(t) for t in _tasks_pre)
    _no_tasks_pre = not _tasks_pre
    _needs_planning = plan or _no_tasks_pre or (_all_done_pre and not only_task and not from_task)

    # ── Write monitor state BEFORE launching tmux ───────────────────────
    # The dashboard pane starts alongside the left pane. Writing the state
    # here ensures the dashboard shows the right screen immediately.
    if _needs_planning:
        if _all_done_pre and not plan and not only_task and not from_task and headless:
            _recover_missing_summary_for_terminal_tasks(
                resolved_project,
                _tasks_pre,
                tasks_dir,
                config,
            )
            console.print(
                "[#7cc800]✓ All tasks complete.[/#7cc800]  "
                "[dim]Use --plan to start a new goal.[/dim]"
            )
            raise SystemExit(0)
        try:
            from the_architect.core.monitor_state import write_planning_state

            write_planning_state(resolved_project, goal=goal_text or "")
        except Exception:
            pass
    else:
        # Execution path: tasks exist and are not all done.
        # The monitor state file may still contain a terminal status (DONE/
        # FAILED) from a previous run.  The dashboard reads it the moment
        # its pane starts, sees a terminal status, and exits after 2 seconds —
        # causing the "right panel shows for 1-2 seconds then disappears" bug.
        # Writing a fresh RUNNING state here clears the stale status so the
        # dashboard stays alive throughout the resume-screen interaction and
        # into execution (where MonitorStateWriter takes over).
        try:
            from the_architect.core.monitor_state import (
                RUN_STATUS_RUNNING,
                TASK_STATUS_DONE,
                TASK_STATUS_FAILED,
                TASK_STATUS_PENDING,
                write_monitor_state,
            )

            def _monitor_status_for(task: Task) -> str:
                """Map a Task in-memory status to the monitor's string vocabulary.

                Mirrors the terminal-vs-pending distinction the execution
                loop uses: DONE and FAILED are terminal and must appear as
                such on the dashboard; everything else is Pending from the
                monitor's perspective.
                """
                if task.status == TaskStatus.DONE:
                    return TASK_STATUS_DONE
                if task.status == TaskStatus.FAILED:
                    return TASK_STATUS_FAILED
                return TASK_STATUS_PENDING

            write_monitor_state(
                resolved_project,
                {
                    "status": RUN_STATUS_RUNNING,
                    "project_name": resolved_project.name,
                    "tasks": [
                        {
                            "id": t.prefix,
                            "title": t.title or t.name,
                            "status": _monitor_status_for(t),
                            "replanned": False,
                        }
                        for t in _tasks_pre
                    ],
                    "current_task_id": None,
                    "current_task_title": None,
                    "current_attempt": 0,
                    "total_tasks": len(_tasks_pre),
                    "tasks_completed": sum(1 for t in _tasks_pre if t.status == TaskStatus.DONE),
                },
            )
        except Exception:
            pass

    # Note: an earlier revision rendered a plain-ANSI Matrix-rain loader
    # here (before Textual mounts) to cover the ~0.2s provider-detection
    # gap. In practice it produced a visible left-aligned green flash
    # that users found distracting, and the real splash `SplashScreen`
    # already covers the gap once Textual takes over. Removed.

    # ── Phase 2 — Provider selection (scroll buffer, after tmux) ─────────
    # Provider selection that doesn't need an interactive prompt
    # (single provider, explicit env/config, headless) runs here. When
    # the user actually needs to pick between multiple providers the
    # prompt is deferred into ``_tui_flow`` below so it happens inside
    # the same :class:`ArchitectApp` as every other pre-run screen —
    # this is what eliminates the previous alt-screen flash between
    # provider selection and the next prompt.
    _needs_interactive_provider_selection = False
    if _active_provider is None:
        _available_post = detect_available_providers(require_models=True)
        if not _available_post:
            console.print("[red]Error: No configured AI CLI provider found.[/red]")
            console.print("[dim]Run [bold]architect doctor[/bold] for provider diagnostics.[/dim]")
            raise SystemExit(1)
        elif len(_available_post) == 1:
            _active_provider = _available_post[0]
        elif headless:
            _active_provider = _available_post[0]
        else:
            _needs_interactive_provider_selection = True
            _provider_candidates = _available_post
        if _active_provider is not None:
            os.environ["ARCHITECT_PROVIDER"] = _active_provider.name

            # Usability check for the newly selected provider
            if not _active_provider.has_any_models():
                user_cfg = _active_provider.find_user_config(resolved_project)
                if user_cfg is None:
                    console.print()
                    console.print(
                        f"[yellow]{_active_provider.display_name} may not be configured yet."
                        "[/yellow]"
                    )
                    console.print()
                    if _active_provider.name == "opencode":
                        console.print(
                            "Run [bold]opencode[/bold] once to set up a provider, then come back."
                        )
                    elif _active_provider.name == "codex":
                        console.print("Set CODEX_API_KEY or run [bold]codex[/bold] to configure.")
                    elif _active_provider.name == "gemini-cli":
                        console.print("Set GEMINI_API_KEY or run [bold]gemini[/bold] to configure.")
                    else:
                        console.print(
                            "Set ANTHROPIC_API_KEY or run [bold]claude[/bold] to configure."
                        )
                    raise SystemExit(1)

    # Widen to str | None now so the type stays consistent whether or not
    # _collect_planning_prompts runs (it can return None for the model).
    execution_model_resolved: str | None = execution_model or None

    try:
        # Phase 20: host ONE ArchitectApp for the entire interactive
        # flow — provider check, planning prompts, mode selection,
        # planning wait, execution, retrospective, reassessment — all
        # inside the same running app. Every run_*_screen() call
        # inside the flow detects the active runner and pushes onto
        # the live app instead of booting its own harness (which is
        # what caused the visible flash between screens).
        def _tui_flow() -> None:
            nonlocal goal_text, scope_text, architect_model
            nonlocal execution_model_resolved, persistent, free_mode
            nonlocal _active_provider

            # Configure file logging early so the Infinite Loop driver and
            # TUI runner emit their lifecycle traces into
            # ``.architect/logs/the_architect.log`` even when the alternate
            # screen is active and stderr is hidden by Textual.
            try:
                from the_architect.core.runner import setup_logging

                config.log_dir.mkdir(parents=True, exist_ok=True)
                setup_logging(config.log_dir)
                # Add a dedicated runtime log so loop/runner lifecycle
                # entries survive the planner's per-iteration log
                # archive cleanup. ``setup_logging`` already writes to
                # ``the_architect.log`` (which the planner now skips when
                # clearing the directory), but a second sink targeted
                # specifically at runtime traces makes them trivial to
                # locate during a live failure.
                runtime_log = config.log_dir / "architect_runtime.log"
                if not getattr(_run_main, "_runtime_log_added", False):
                    logger.add(
                        runtime_log,
                        level="DEBUG",
                        rotation="5 MB",
                        retention=5,
                        format="{time} | {level} | {name}:{line} | {message}",
                        filter=lambda record: any(
                            tag in record["message"]
                            for tag in (
                                "Infinite Loop",
                                "Architect TUI app",
                                "Planning phase completed",
                            )
                        ),
                    )
                    _run_main._runtime_log_added = True  # type: ignore[attr-defined]
            except Exception as _log_exc:
                logger.debug(f"Could not configure file logging early: {_log_exc!r}")

            # ── Self-update check ─────────────────────────────────
            # Runs while the splash animation is still showing.  The
            # PyPI request is short (5 s timeout); if an update exists
            # the user sees the notification immediately after the
            # minimum splash hold.  Skipped in headless mode.
            if not headless:
                try:
                    from the_architect.core.self_update import (
                        check_self_update,
                        run_self_update,
                    )

                    _current_v, _latest_v = check_self_update()
                    if _current_v and _latest_v:
                        action = _prompt_self_update_action(_current_v, _latest_v)
                        if action == "update":
                            run_self_update()
                            raise SystemExit(0)
                except SystemExit:
                    raise
                except Exception as _su_exc:
                    logger.debug(f"Self-update check failed (non-fatal): {_su_exc!r}")

            # ── Interactive provider selection (if deferred) ──────
            if _needs_interactive_provider_selection:
                _active_provider = _prompt_provider_selection(_provider_candidates)
                os.environ["ARCHITECT_PROVIDER"] = _active_provider.name
                # Usability check for the newly selected provider.
                if not _active_provider.has_any_models():
                    user_cfg = _active_provider.find_user_config(resolved_project)
                    if user_cfg is None:
                        raise SystemExit(1)

            # ── Planning flow ─────────────────────────────────────
            if _needs_planning:
                # Auto-enable planning for the common empty / done cases.
                if not headless:
                    if (_all_done_pre or _no_tasks_pre) and not plan_local["v"]:
                        plan_local["v"] = True

                (
                    new_goal,
                    new_scope,
                    new_architect_model,
                    new_execution_model,
                ) = _collect_planning_prompts(
                    resolved_project,
                    config,
                    headless=headless,
                    goal_text=goal_text or "",
                    scope_text=scope_text or "",
                    context_paths=context_paths,
                    architect_model_override=architect_model,
                    execution_model_override=execution_model,
                    provider=_active_provider,
                )
                goal_text = new_goal
                scope_text = new_scope
                architect_model = new_architect_model
                execution_model_resolved = new_execution_model

                # Re-resolve the active provider if the user selected a
                # different one in the tabbed pre-run screen.  The tabbed
                # screen stores the selection in config.provider (a name
                # string like "codex").  If that name differs from the
                # provider we started with, resolve a fresh provider object
                # so that all downstream calls (update check, planning,
                # execution) use the correct binary.
                _selected_provider_name = getattr(config, "provider", "auto")
                if (
                    _selected_provider_name
                    and _selected_provider_name != "auto"
                    and (
                        _active_provider is None or _active_provider.name != _selected_provider_name
                    )
                ):
                    try:
                        _active_provider = detect_provider(_selected_provider_name)
                        os.environ["ARCHITECT_PROVIDER"] = _active_provider.name
                    except Exception as _rp_exc:
                        logger.debug(
                            f"Could not re-resolve provider {_selected_provider_name!r}: "
                            f"{_rp_exc!r} — keeping current provider"
                        )

                # Update the planning state with the resolved goal.
                try:
                    from the_architect.core.monitor_state import write_planning_state

                    write_planning_state(resolved_project, goal=goal_text or "")
                except Exception:
                    pass

            # ── Mode selection (only when execution will happen) ──
            _pending_pre_local = (
                [t for t in _tasks_pre if _task_needs_work(t)] if _tasks_pre else []
            )
            _mode_already_collected = getattr(config, "_tabbed_mode_collected", False)
            _needs_mode_prompt_local = (
                not _mode_already_collected
                and not (persistent or free_mode)
                and not headless
                and not _pending_pre_local
            )
            if _needs_mode_prompt_local:
                modes = _prompt_mode_selection(provider=_active_provider)
                if modes is not None:
                    if modes.get("persistent"):
                        persistent = True
                    if modes.get("free"):
                        free_mode = True
                    config.integrity = bool(modes.get("integrity", config.integrity))
                    if modes.get("token_budget_per_hour"):
                        config.token_budget_per_hour = modes["token_budget_per_hour"]
                    # ── Validation Gate ────────────────────────
                    vg_mode = modes.get("validation_gate")
                    if isinstance(vg_mode, dict) and vg_mode:
                        config.validation_gate = vg_mode

            if persistent:
                _apply_persistent_mode(config, True)

            if free_mode:
                config.free_mode = True

            _apply_infinite_loop_mode(config)

            # Persist interactive settings to architect.toml for next run.
            if _needs_mode_prompt_local:
                from the_architect.config import write_config

                write_config(
                    resolved_project,
                    {
                        "free_mode": config.free_mode,
                        "persistent": config.persistent,
                        "integrity": config.integrity,
                        "token_budget_per_hour": config.token_budget_per_hour,
                        "validation_gate": config.validation_gate,
                        "last_scope": scope_text,
                        "architect_model": architect_model,
                    },
                )

            loop_iteration = 1
            infinite_loop_chain_enabled = _infinite_loop_active(config)
            logger.info(
                "Infinite Loop driver: entering loop "
                f"(active={infinite_loop_chain_enabled}, plan={plan_local['v']})"
            )
            while True:
                if infinite_loop_chain_enabled:
                    config._infinite_loop_enabled = True  # type: ignore[attr-defined]
                    config._infinite_loop_chain_enabled = True  # type: ignore[attr-defined]

                infinite_loop_enabled = infinite_loop_chain_enabled or _infinite_loop_active(config)
                logger.info(
                    f"Infinite Loop driver: iteration {loop_iteration} starting "
                    f"(plan={plan_local['v']}, active={infinite_loop_enabled})"
                )
                try:
                    _run_main(
                        project=resolved_project,
                        plan=plan_local["v"],
                        standalone=standalone,
                        from_task=from_task,
                        only_task=only_task,
                        persistent=persistent,
                        free_mode=free_mode,
                        headless=headless,
                        goal_text=goal_text or "",
                        scope_text=scope_text or "",
                        context_paths=context_paths,
                        architect_model=architect_model,
                        execution_model=execution_model_resolved,
                        _pre_loaded_config=config,
                        provider=_active_provider,
                        use_tui=use_tui,
                        _return_on_success=infinite_loop_enabled,
                        _suppress_success_screen=infinite_loop_enabled,
                        _return_after_planning=infinite_loop_enabled and plan_local["v"],
                        dry_run=dry_run,
                        as_json=as_json,
                        verify_resume=not no_verify_resume,
                    )
                except SystemExit as exc:
                    logger.info(
                        "Infinite Loop driver: nested run raised SystemExit "
                        f"code={exc.code} during iteration {loop_iteration}"
                    )
                    if not _infinite_loop_should_continue_after_exit(
                        config,
                        exc,
                        chain_enabled=infinite_loop_enabled,
                    ):
                        if infinite_loop_enabled and _infinite_loop_has_clean_exit_state(
                            resolved_project,
                            config,
                        ):
                            logger.warning(
                                "Infinite Loop driver: nested run raised nonzero SystemExit "
                                f"code={exc.code}, but post-run task state is clean; "
                                "continuing loop"
                            )
                        elif infinite_loop_enabled and exc.code == 1:
                            # Check whether all failed tasks were killed only by
                            # sleep/wake gaps (not real agent failures).  If so,
                            # reset those tasks to Pending and continue the loop
                            # rather than dying — sleeping is a hardware event,
                            # not a reason to abort the entire autonomous run.
                            _sleep_reset = _infinite_loop_reset_sleep_interrupted_tasks(
                                resolved_project, config
                            )
                            # Same logic for provider idle timeouts — the provider
                            # subprocess going silent is also an environmental event,
                            # not a real agent failure.
                            _idle_reset = _infinite_loop_reset_idle_timeout_tasks(
                                resolved_project, config
                            )
                            _env_reset = _sleep_reset + _idle_reset
                            if _env_reset > 0:
                                logger.warning(
                                    f"Infinite Loop driver: {_sleep_reset} sleep + "
                                    f"{_idle_reset} idle-timeout task(s) reset to Pending, "
                                    "continuing loop"
                                )
                            else:
                                # Check if there are pending tasks to execute —
                                # reassessment may have split a failed task into
                                # smaller tasks (T03A-D) that are Pending.  The
                                # next iteration will create a fresh scheduler
                                # that sees them and executes them.
                                loop_tasks_dir = resolved_project / config.tasks_dir.name
                                loop_progress_file = config.progress_file
                                loop_pending = check_pending_tasks(
                                    loop_tasks_dir, loop_progress_file
                                )
                                if loop_pending:
                                    logger.info(
                                        f"Infinite Loop driver: SystemExit(1) but "
                                        f"{len(loop_pending)} pending task(s) remain "
                                        f"— continuing loop for execution"
                                    )
                                    plan_local["v"] = False  # Force execution, not planning
                                else:
                                    logger.info(
                                        "Infinite Loop driver: SystemExit not eligible "
                                        "for loop continuation, re-raising"
                                    )
                                    raise
                        else:
                            logger.info(
                                "Infinite Loop driver: SystemExit not eligible for loop "
                                "continuation, re-raising"
                            )
                            raise
                    else:
                        logger.info("Infinite Loop driver: SystemExit absorbed, continuing loop")

                infinite_loop_chain_enabled = infinite_loop_enabled or _infinite_loop_active(config)
                if not infinite_loop_chain_enabled:
                    logger.info(
                        "Infinite Loop driver: chain disabled after iteration "
                        f"{loop_iteration}, exiting loop"
                    )
                    return

                config._infinite_loop_enabled = True  # type: ignore[attr-defined]
                config._infinite_loop_chain_enabled = True  # type: ignore[attr-defined]

                loop_tasks_dir = resolved_project / config.tasks_dir.name
                loop_progress_file = config.progress_file
                loop_pending = check_pending_tasks(loop_tasks_dir, loop_progress_file)
                logger.info(
                    f"Infinite Loop driver: post-iteration pending_tasks={loop_pending} "
                    f"(plan_was={plan_local['v']})"
                )
                if loop_pending:
                    logger.warning(
                        "Infinite Loop iteration returned with pending tasks; "
                        "forcing execution before planning another iteration"
                    )
                    plan_local["v"] = False
                    continue

                loop_goal = _resolve_infinite_loop_goal(
                    goal_text or "",
                    config,
                    loop_tasks_dir,
                )
                if not loop_goal:
                    logger.error(
                        "Infinite Loop driver: could not resolve a goal to reuse; stopping"
                    )
                    console.print(
                        "[red]Infinite Loop could not find the original goal to reuse.[/red]"
                    )
                    raise SystemExit(1)
                goal_text = loop_goal
                logger.info(
                    f"Infinite Loop driver: reusing goal for next iteration ({loop_goal!r:.80})"
                )

                try:
                    from the_architect.tui.runner import active_runner

                    _runner = active_runner()
                    if _runner is not None:
                        _runner.app.push_event_line(
                            "infinite_loop_rerun",
                            {"iteration": loop_iteration + 1},
                        )
                        _runner.app.push_output_line(
                            f"Infinite Loop: starting iteration {loop_iteration + 1}"
                        )
                except SystemExit:
                    raise
                except Exception as exc:
                    logger.debug(f"Infinite Loop status update failed: {exc!r}")

                loop_iteration += 1
                logger.info(
                    f"Infinite Loop driver: starting iteration {loop_iteration} (plan=True)"
                )
                console.print(
                    f"[yellow]Infinite Loop[/yellow]  "
                    f"[dim]starting iteration {loop_iteration}[/dim]"
                )
                plan_local["v"] = True

        # Mutable wrapper so _tui_flow (nested closure) can update
        # ``plan`` — the outer ``plan`` name is bound by click options.
        plan_local: dict[str, bool] = {"v": plan}

        if use_tui and not headless:
            from the_architect.tui.runner import ArchitectAppRunner

            # Non-daemon worker for Infinite Loop / persistent runs so the
            # run survives TUI detach and SIGHUP (terminal close / SSH drop).
            _runner_persistent = persistent or bool(
                getattr(config, "_infinite_loop_enabled", False)
            )
            ArchitectAppRunner(flow=_tui_flow, persistent=_runner_persistent).run()
        else:
            with alternate_screen():
                _tui_flow()

    finally:
        # ── Terminal mode cleanup ──────────────────────────────────────────
        # Belt-and-braces restore for failed Infinite Loop / TUI exits. Textual
        # and the runner also restore modes, but the outer Click boundary is the
        # last reliable place before tmux teardown to disable leaked mouse input.
        try:
            from the_architect.tui.terminal import restore_terminal_input_modes

            restore_terminal_input_modes()
        except Exception:
            pass

        # ── Monitor state cleanup ──────────────────────────────────────────
        # If the process exits while the state file still says PLANNING or
        # RUNNING (e.g. Ctrl+C during prompts, crash before execution),
        # write KILLED so the dashboard pane doesn't stay stuck forever.
        # Only overwrite if the current status is a non-terminal state —
        # never clobber DONE or FAILED from a successful run.
        try:
            from the_architect.core.monitor_state import (
                RUN_STATUS_KILLED,
                read_monitor_state,
                write_monitor_state,
            )

            current_state = read_monitor_state(resolved_project)
            current_status = current_state.get("status", "") if current_state else ""
            if _monitor_state_needs_killed_finalizer(current_status):
                write_monitor_state(
                    resolved_project,
                    {
                        "status": RUN_STATUS_KILLED,
                        "project_name": resolved_project.name,
                        "tasks": current_state.get("tasks", []) if current_state else [],
                        "current_task_id": None,
                    },
                )
        except Exception:
            pass

        # ── Tmux session teardown removed ────────────────────────────────
        # Sessions are no longer managed by The Architect — detach is
        # handled natively via SIGHUP and the pause menu Detach button.
        pass


def _run_main(
    project: Path,
    plan: bool = False,
    standalone: str = "",
    from_task: str = "",
    only_task: str = "",
    persistent: bool = False,
    free_mode: bool = False,
    headless: bool = False,
    goal_text: str = "",
    scope_text: str = "",
    context_paths: tuple[Path, ...] = (),
    architect_model: str = "",
    execution_model: str | None = "",
    _pre_loaded_config: ArchitectConfig | None = None,
    provider: ArchitectProvider | None = None,
    use_tui: bool = False,
    _return_on_success: bool = False,
    _suppress_success_screen: bool = False,
    _return_after_planning: bool = False,
    dry_run: bool = False,
    as_json: bool = False,
    verify_resume: bool = True,
) -> None:
    """Main flow: planning, execution, and retrospective review.

    Flow:
        Planning → Execution → Retrospective 1 → Execution → Retrospective 2 → Execution → Done

    Retrospective rounds are skipped when:
    - ``config.retrospective_rounds`` is 0
    - ``--only`` is used (targeted single-task run)
    - The reviewer finds no issues (no new tasks created)

    With ``--persistent``:
    - ``max_retries`` is raised to 30 (persistence wins)
    - ``retrospective_rounds`` is set to 2 (deeper review)

    With ``--free``:
    - ``free_mode`` is set to True on the config
    - The Architect fetches free-tier OpenRouter models and rotates through them
    - On rate limit, switches to the next free model
    - When all free models are exhausted, falls back to default

    With ``--headless``:
    - All interactive prompts are skipped
    - Required values must be provided via flags or env vars
    - Missing required values cause a clear error and non-zero exit

    Args:
        project: The project root directory.
        plan: Force planning mode.
        standalone: Bypass opencode.json and use this model directly.
        from_task: Resume from a specific task prefix.
        only_task: Run a single task only.
        persistent: Persistent mode (30 retries, 3 retrospective rounds).
        free_mode: Use free-tier OpenRouter models.
        headless: Headless mode (no interactive prompts).
        goal_text: Pre-supplied planning goal.
        scope_text: Pre-supplied task scope.
        context_paths: Pre-supplied context file paths.
        architect_model: Pre-supplied architect model override.
        execution_model: Pre-supplied execution model override.  ``None``
            means the prompt was already shown by ``_collect_planning_prompts``
            and the user chose the opencode default (empty string would also
            work, but ``None`` is the explicit sentinel passed through).
        _pre_loaded_config: Pre-loaded and mutated config from ``main()``.
            When provided, mode-selection prompts and opencode checks are
            skipped because they already ran before the alternate screen.
        dry_run: Dry-run mode — run the planner, display the plan summary,
            and exit without executing any tasks.
        as_json: Output dry-run summary as structured JSON instead of Rich tables.
        verify_resume: When ``True`` (default), verify completed tasks against
            their baselines before resuming a partially-finished run.
            Set to ``False`` via ``--no-verify-resume`` to disable.
    """
    # Use the pre-loaded config when available (interactive prompts and
    # opencode checks already ran in main() before the alternate screen).
    if _pre_loaded_config is not None:
        config = _pre_loaded_config
    else:
        config = load_config(project)

        if standalone:
            config.standalone_mode = standalone

        # ── Guard: standalone_mode must be compatible with the active provider ─
        # standalone_mode is persisted to architect.toml.  If it was set during
        # a previous OpenCode/free-mode run (e.g. "openrouter/z-ai/glm-5.1"),
        # it will be silently passed to Claude Code on the next run — which
        # doesn't understand OpenRouter model IDs and will fail.
        # Clear it and warn rather than let it poison the run.
        if config.standalone_mode and provider is not None:
            from the_architect.core.claude_code_provider import ClaudeCodeProvider

            if isinstance(provider, ClaudeCodeProvider):
                sm = config.standalone_mode
                # OpenRouter model IDs always start with "openrouter/"
                # or contain a "/" that indicates a non-Anthropic namespace.
                is_openrouter = sm.startswith("openrouter/") or (
                    "/" in sm and not sm.startswith("claude")
                )
                if is_openrouter:
                    console.print(
                        f"[yellow]⚠  standalone_mode '{sm}' is an OpenRouter model — "
                        f"not compatible with Claude Code. Clearing it.[/yellow]"
                    )
                    logger.warning(
                        f"standalone_mode '{sm}' is incompatible with Claude Code "
                        f"(OpenRouter model ID) — clearing for this run"
                    )
                    config.standalone_mode = ""
                    write_config(project, {"standalone_mode": ""})

        # ── Interactive mode selection (only when no mode flags passed) ─────
        # Power users who pass --free or --persistent skip the prompt entirely.
        # In headless mode, skip all interactive prompts.
        # If pending tasks exist, skip — the resume screen below handles it.
        tasks_dir_pre = project / config.tasks_dir.name
        _tasks_pre_run = discover_tasks(tasks_dir_pre)
        progress_file_pre = config.progress_file
        _tasks_pre_run = _filter_and_set_status(_tasks_pre_run, progress_file_pre)
        _pending_pre_run = (
            [t for t in _tasks_pre_run if _task_needs_work(t)] if _tasks_pre_run else []
        )

        any_mode_flag = persistent or free_mode
        _tabbed_mode = getattr(config, "_tabbed_mode_collected", False)
        _needs_mode_prompt = (
            not any_mode_flag and not _tabbed_mode and not headless and not _pending_pre_run
        )
        if _needs_mode_prompt:
            modes = _prompt_mode_selection(provider=provider)
            # Clear the mode-selection UI before the execution header renders.
            # _prompt_mode_selection uses full_screen=False so its rendered
            # text stays in the buffer.  Without this clear the execution
            # header starts below the leftover mode-selection text.
            console.clear()
            if modes is not None:
                if modes.get("persistent"):
                    persistent = True
                if modes.get("free"):
                    free_mode = True
                config.integrity = bool(modes.get("integrity", config.integrity))
                if modes.get("token_budget_per_hour"):
                    config.token_budget_per_hour = modes["token_budget_per_hour"]
                # ── Validation Gate ────────────────────────
                vg_mode = modes.get("validation_gate")
                if isinstance(vg_mode, dict) and vg_mode:
                    config.validation_gate = vg_mode

        if persistent:
            _apply_persistent_mode(config, True)

        if free_mode:
            config.free_mode = True

        # Persist interactive settings to architect.toml for next run
        if _needs_mode_prompt:
            from the_architect.config import write_config

            write_config(
                project,
                {
                    "free_mode": config.free_mode,
                    "persistent": config.persistent,
                    "integrity": config.integrity,
                    "token_budget_per_hour": config.token_budget_per_hour,
                    "validation_gate": config.validation_gate,
                    "last_scope": scope_text,
                    "architect_model": architect_model,
                },
            )

        # Provider already checked in main() — no need to re-check here
        pass

    tasks_dir = project / config.tasks_dir.name
    tasks = discover_tasks(tasks_dir)
    progress_file = config.progress_file
    tasks = _filter_and_set_status(tasks, progress_file)

    # Track the original goal for retrospective context
    original_goal = ""

    # Apply --only
    if only_task:
        matched = [t for t in tasks if t.prefix.upper() == only_task.upper()]
        if not matched:
            console.print(f"[red]No task found with prefix '{only_task}'.[/red]")
            console.print("[dim]Run 'architect list' to see available tasks.[/dim]")
            raise SystemExit(1)
        tasks = matched

    # Apply --from
    elif from_task:
        prefixes = [t.prefix.upper() for t in tasks]
        start = from_task.upper()
        if start not in prefixes:
            console.print(f"[red]No task found with prefix '{from_task}'.[/red]")
            console.print("[dim]Run 'architect list' to see available tasks.[/dim]")
            raise SystemExit(1)
        idx = prefixes.index(start)
        tasks = tasks[idx:]

    # Decide mode
    # A task is "done" from the loop's perspective when its status is
    # terminal (DONE or FAILED) — a FAILED task must not be silently re-run
    # as if it were pending.  Only a human-triggered `architect retry` or a
    # reviewer R-task can resurrect a failed task for re-execution.
    all_done = bool(tasks) and all(_task_is_terminal(t) for t in tasks)
    no_tasks = not tasks

    if plan or no_tasks or (all_done and not only_task and not from_task):
        if all_done and not plan and not only_task and not from_task:
            _recover_missing_summary_for_terminal_tasks(project, tasks, tasks_dir, config)
            console.print(
                "[#7cc800]✓ All tasks complete.[/#7cc800]  "
                "[dim]Use --plan to start a new goal.[/dim]"
            )
            raise SystemExit(0)
        run_planning_mode(
            project,
            config,
            headless=headless,
            goal_text=goal_text,
            scope_text=scope_text,
            context_paths=context_paths,
            architect_model_override=architect_model,
            execution_model_override=execution_model,
            # Skip pending-task guard when prompts were already collected
            # before the alternate screen in main().
            _skip_pending_guard=(_pre_loaded_config is not None),
            provider=provider,
        )
        # After planning, reload and execute
        tasks = discover_tasks(tasks_dir)
        tasks = _filter_and_set_status(tasks, progress_file)
        if not tasks:
            console.print("[red]Planning did not create any tasks.[/red]")
            raise SystemExit(1)
        if _return_after_planning:
            logger.info("Planning phase completed and returned to outer driver before execution")
            return

    # Dry-run mode: display plan summary and exit without executing
    if dry_run:
        logger.info("Dry-run mode: displaying plan summary and exiting")
        if as_json:
            click.echo(_format_dry_run_json(tasks, config, provider))
        else:
            _render_dry_run_summary(tasks, config, provider)
        raise SystemExit(0)

    # Try to read the original goal for retrospective context
    original_goal = _read_goal_from_instructions(tasks_dir)
    if original_goal and _infinite_loop_active(config) and not goal_text.strip():
        config._infinite_loop_goal = original_goal  # type: ignore[attr-defined]

    # Filter to pending.  Terminal tasks (Done or Failed) are NOT pending —
    # a failed task requires explicit human/reviewer action before the
    # executor tries it again.
    pending = [t for t in tasks if _task_needs_work(t)]
    if not pending:
        console.print("[#7cc800]✓ All selected tasks are already resolved.[/#7cc800]")
        raise SystemExit(0)

    # ── Resume screen: confirm execution or replan ──────────────────────
    # When pending tasks exist and we're not in headless/plan mode, show
    # a resume screen so the user can confirm, adjust settings, or replan.
    # Skip if mode flags were already set via CLI (--free, --persistent).
    if (
        not headless
        and not plan
        and not only_task
        and not from_task
        and not _infinite_loop_active(config)
    ):
        # ── Pre-verification: check completed tasks before resume screen ──
        # Verification runs before the screen so results can be displayed
        # to the user. The runner will skip already-verified tasks.
        _verify_results: list[ResumeVerificationResult] | None = None
        if verify_resume:
            _done_tasks = [t for t in tasks if t.status.value == "done"]
            if _done_tasks:
                try:
                    from the_architect.core.resume_verification import (
                        verify_all_completed_tasks,
                    )
                    from the_architect.core.tasks import TaskPlan

                    _plan = TaskPlan(tasks=tasks)
                    _verify_results = verify_all_completed_tasks(_plan, config)
                    _vc = sum(1 for r in _verify_results if r.status == "valid")
                    _sc = sum(1 for r in _verify_results if r.status == "stale")
                    _mc = sum(1 for r in _verify_results if r.status == "missing")
                    logger.info(
                        "Pre-verification: %d valid, %d stale, %d missing",
                        _vc,
                        _sc,
                        _mc,
                    )
                except Exception as _exc:
                    logger.warning("Pre-verification failed — proceeding without it: {_exc!r}")
                    _verify_results = None

        any_mode_flag = persistent or free_mode
        if not any_mode_flag:
            if (use_tui or _tui_mode_enabled()) and provider is not None:
                from the_architect.tui.screens.pre_run_tabbed import run_pre_run_tabbed

                _all_providers = detect_available_providers(require_models=True)
                if not _all_providers:
                    _all_providers = [provider]

                pre_run = run_pre_run_tabbed(
                    providers=_all_providers,
                    config=config,
                    project_dir=project,
                    goal_text=goal_text,
                    scope_text=scope_text,
                    architect_model=architect_model,
                    execution_model=execution_model or "",
                    free_mode=free_mode,
                    persistent=persistent,
                    pending_tasks=pending,
                    action="execute",
                    verification_results=_verify_results,
                )
                if pre_run is None:
                    raise SystemExit(0)
                resume: dict[str, bool | int | str] = {
                    "free": pre_run.free,
                    "persistent": pre_run.persistent,
                    "integrity": pre_run.integrity,
                    "force_reassessment": pre_run.force_reassessment,
                    "token_budget_per_hour": pre_run.token_budget_per_hour,
                    "action": pre_run.action,
                }
                goal_text = pre_run.goal
                scope_text = pre_run.scope
                architect_model = pre_run.architect_model or ""
                execution_model = pre_run.execution_agent or ""
                config.execution_agent = execution_model
                config.force_reassessment = pre_run.force_reassessment
                config._infinite_loop_enabled = pre_run.infinite_loop  # type: ignore[attr-defined]
                # If the user selected Infinite Loop, upgrade the runner to
                # persistent mode so the SIGHUP handler is installed and
                # the pause menu Detach button becomes functional.
                if pre_run.infinite_loop and _tui_mode_enabled():
                    try:
                        from the_architect.tui.runner import active_runner

                        _ar = active_runner()
                        if _ar is not None:
                            _ar.activate_persistence()
                    except Exception:
                        pass
                # The tabbed pending-task screen already collected the model,
                # agent, and mode choices. Replan should go straight into the
                # planner from here, not fall through to legacy prompt screens.
                config._tabbed_model_collected = True  # type: ignore[attr-defined]
                config._tabbed_mode_collected = True  # type: ignore[attr-defined]
                if pre_run.provider_name:
                    config.provider = pre_run.provider_name
                    if provider.name != pre_run.provider_name:
                        try:
                            provider = detect_provider(pre_run.provider_name)
                            os.environ["ARCHITECT_PROVIDER"] = provider.name
                        except Exception as exc:
                            logger.debug(
                                f"Could not re-resolve provider {pre_run.provider_name!r}: "
                                f"{exc!r} — keeping current provider"
                            )
            else:
                resume = _prompt_resume_screen(
                    pending,
                    config,
                    provider=provider,
                    verification_results=_verify_results,
                )
                # Clear the resume-screen UI before the next content renders.
                # _prompt_resume_screen uses full_screen=False so its rendered
                # text stays in the scroll buffer.  Without this clear the
                # execution header (or planning prompts) would start below the
                # leftover resume-screen text instead of at the top.
                console.clear()
            if resume.get("action") == "replan":
                run_planning_mode(
                    project,
                    config,
                    headless=headless,
                    goal_text=goal_text,
                    scope_text=scope_text,
                    context_paths=context_paths,
                    architect_model_override=architect_model,
                    execution_model_override=execution_model,
                    # The user already chose Replan from the pending-task screen.
                    # Do not show the same pending-task guard again before the
                    # actual planning run starts.
                    _skip_pending_guard=True,
                    provider=provider,
                )
                # After planning, reload and execute
                tasks = discover_tasks(tasks_dir)
                tasks = _filter_and_set_status(tasks, progress_file)
                if not tasks:
                    console.print("[red]Planning did not create any tasks.[/red]")
                    raise SystemExit(1)
                pending = [t for t in tasks if _task_needs_work(t)]
                if not pending:
                    console.print("[#7cc800]✓ All selected tasks are already done.[/#7cc800]")
                    raise SystemExit(0)
            else:
                # Apply settings from resume screen — always assign both on AND
                # off; if-True guards here would silently keep old config values
                # when the user toggles something off.
                free_mode = bool(resume.get("free", False))
                config.free_mode = free_mode

                persistent = bool(resume.get("persistent", False))
                config.persistent = persistent
                config.integrity = bool(resume.get("integrity", config.integrity))
                config.force_reassessment = bool(
                    resume.get("force_reassessment", config.force_reassessment)
                )
                _apply_persistent_mode(config)
                _apply_infinite_loop_mode(config)

                config.token_budget_per_hour = int(resume.get("token_budget_per_hour") or 0)

                # Persist settings to architect.toml for next run
                from the_architect.config import write_config

                write_config(
                    project,
                    {
                        "free_mode": config.free_mode,
                        "persistent": config.persistent,
                        "integrity": config.integrity,
                        "force_reassessment": config.force_reassessment,
                        "token_budget_per_hour": config.token_budget_per_hour,
                        "last_scope": scope_text,
                        "architect_model": architect_model,
                    },
                )

    _apply_persistent_mode(config)
    _apply_infinite_loop_mode(config)

    # Warn if tasks/INSTRUCTIONS.md is missing — not fatal, just informational
    instructions_md = tasks_dir / "INSTRUCTIONS.md"
    if not instructions_md.exists():
        console.print(
            "[yellow]⚠  tasks/INSTRUCTIONS.md not found — "
            "agents will have less project context. "
            "Run --plan to regenerate.[/yellow]"
        )

    # ── Free mode: validate + fetch free models from OpenRouter ────────────
    # This runs BEFORE the header print so the "free mode" label is only
    # shown when free mode is actually active.
    free_rotator = None
    if config.free_mode:
        # Guard: free tier only works with OpenCode + OpenRouter.
        # Clear the flag immediately if the provider doesn't support it,
        # so the header never shows "free mode" when it won't be used.
        if provider is not None and not provider.supports_free_tier():
            console.print()
            console.print(
                f"[yellow]⚠  Free Tier is not supported with {provider.display_name} — "
                f"falling back to default model.[/yellow]"
            )
            config.free_mode = False
            from the_architect.config import write_config

            write_config(project, {"free_mode": False})
        else:
            from the_architect.core.free_models import FreeModelRotator

            # Textual splash covers the network fetch; no stdout spinner.
            free_rotator = FreeModelRotator()
            asyncio.run(free_rotator.fetch_free_models())

            if free_rotator.total_count == 0:
                console.print(
                    "[yellow]⚠  No free models found on OpenRouter — "
                    "falling back to default model.[/yellow]"
                )
                config.free_mode = False
                free_rotator = None
                from the_architect.config import write_config

                write_config(project, {"free_mode": False})
            else:
                console.print(
                    f"[{ARCHITECT_GREEN}]{free_rotator.total_count} free model(s) "
                    f"available[/{ARCHITECT_GREEN}]  "
                    f"[dim]starting with {free_rotator.current_model}[/dim]"
                )

    # Show what we're about to run (after free mode validation so the label is accurate)
    console.print()
    mode_label = "  [grey62]free mode[/grey62]" if config.free_mode else ""
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect[/bold {ARCHITECT_GREEN}]  "
        f"[grey62]v{__version__}[/grey62]  "
        f"[{ARCHITECT_GREEN}]{len(pending)} task(s) to run[/{ARCHITECT_GREEN}]"
        f"{mode_label}"
    )
    # Show the execution model — resolve from provider if no explicit override
    exec_model_display = (
        execution_model if isinstance(execution_model, str) else (execution_model or "")
    )
    if not exec_model_display and provider is not None:
        try:
            exec_model_display = provider.get_resolved_model(
                project, config.execution_agent or "build"
            )
        except Exception:
            pass
    if exec_model_display:
        console.print(
            f"[grey62]Model:[/grey62] [{ARCHITECT_GREEN}]{exec_model_display}[/{ARCHITECT_GREEN}]"
        )

    # Ensure provider setup only when a provider has already been selected.
    # Some test and headless control-flow paths intentionally run without a
    # real provider object and should not auto-detect local CLIs here.
    if provider is not None:
        ensure_provider_setup(provider, project, config)
    setup_logging(config.log_dir)

    # ── Monitor state writer (feeds the tmux dashboard) ─────────────────
    # Always create the writer — even when --no-monitor is set (which only
    # controls tmux launching, not state-file writes).  The dashboard pane
    # reads this file to render live status; without it the state stays
    # stuck at PLANNING forever.
    monitor_writer: MonitorStateWriter | None = None
    try:
        monitor_writer = MonitorStateWriter(
            project_dir=project,
            tasks=tasks,
            free_rotator=free_rotator,
            max_retries=config.max_retries,
        )
    except Exception as _mw_exc:
        logger.debug(f"Monitor writer init failed (non-fatal): {_mw_exc!r}")
        monitor_writer = None

    # ── Initial execution ──────────────────────────────────────────────
    all_results: list[TaskResult] = []
    run_start = time.time()

    try:
        success, results, exec_duration = asyncio.run(
            _run_tasks_raw(
                project,
                config,
                tasks,
                free_rotator=free_rotator,
                monitor_writer=monitor_writer,
                provider=provider,
                original_goal=original_goal,
                model_override=architect_model or None,
                use_tui=use_tui,
                verify_resume=verify_resume,
            )
        )
    except RuntimeError as e:
        console.print(f"\n[red]Error: {e}[/red]")
        raise SystemExit(1)
    except Exception as e:
        # Catch-all for fire-and-forget robustness: any unexpected exception
        # (asyncio errors, OS errors, etc.) must not silently crash the process
        # without telling the user what happened.
        console.print(f"\n[red]Unexpected error during task execution: {e!r}[/red]")
        logger.error(f"Unexpected error during task execution: {e!r}")
        raise SystemExit(1)

    all_results.extend(results)

    # ── Retrospective rounds ───────────────────────────────────────────
    # Skip retrospective when using --only (targeted single-task run)
    # or when retrospective_rounds is 0
    should_run_retrospective = config.retrospective_rounds > 0 and not only_task
    collected_retrospective_rounds: list[RetrospectiveRound] = []

    if should_run_retrospective:
        validation_feedback = ""
        for round_num in range(1, config.retrospective_rounds + 1):
            console.print()
            console.print(
                f"[bold {ARCHITECT_GREEN}]══ Retrospective {round_num}/"
                f"{config.retrospective_rounds}[/bold {ARCHITECT_GREEN}]  "
                f"[dim]reviewing completed work[/dim]"
            )
            console.print()

            retro_request = RetrospectiveRequest(
                round_number=round_num,
                project_dir=project,
                original_goal=original_goal,
                validation_feedback=validation_feedback,
                model_override=architect_model or None,
            )

            log_dir = config.log_dir
            log_dir.mkdir(parents=True, exist_ok=True)
            retro_log = log_dir / f"reviewer_round{round_num}.log"

            retro_start = time.time()
            retro_exc: Exception | None = None
            if _tui_mode_enabled():
                from the_architect.tui import WaitLogRenderer, tui_wait_session

                with tui_wait_session(
                    enabled=True, title=f"retrospective {round_num} reviewing…"
                ) as _wait:
                    _wait.set_detail(
                        f"Round {round_num} of {config.retrospective_rounds}\n"
                        f"Project: {project}\n"
                        f"Log: {retro_log.name}"
                    )
                    _retro_renderer = WaitLogRenderer(session=_wait)
                    try:
                        retro_result = asyncio.run(
                            run_retrospective(
                                retro_request,
                                config,
                                log_path=retro_log,
                                provider=provider,
                                renderer=_retro_renderer,
                            )
                        )
                    except Exception as e:
                        retro_exc = e
            else:
                # Non-TUI path: no stdout spinner. Provider streams directly.
                try:
                    retro_result = asyncio.run(
                        run_retrospective(
                            retro_request, config, log_path=retro_log, provider=provider
                        )
                    )
                except Exception as e:
                    retro_exc = e
            if retro_exc is not None:
                console.print(f"[red]Retrospective round {round_num} failed: {retro_exc}[/red]")
                success = False
                break
            retro_duration = time.time() - retro_start

            # Collect retrospective round summary for tasks/SUMMARY.md
            collected_retrospective_rounds.append(
                RetrospectiveRound(
                    round_number=round_num,
                    issues_found=retro_result.issues_found,
                    fixes_planned=retro_result.fixes_planned,
                    tasks_created=retro_result.tasks_created,
                    duration_seconds=retro_duration,
                )
            )

            if not retro_result.tasks_created:
                validation = _validate_cycle(tasks_dir, progress_file)
                _write_cycle_validation_to_progress(progress_file, validation, round_num)
                collected_retrospective_rounds[-1].validation_passed = validation.passed
                collected_retrospective_rounds[-1].validation_reason = validation.reason
                collected_retrospective_rounds[-1].unresolved_tasks = list(
                    validation.unresolved_tasks
                )
                if validation.passed:
                    console.print()
                    console.print(
                        f"[#7cc800]✓ Retrospective {round_num} — "
                        "validation passed[/#7cc800]  [dim]build is clean[/dim]"
                    )
                    success = True
                    break

                validation_feedback = _format_cycle_validation_feedback(validation)
                console.print()
                console.print(
                    f"[yellow]⚠ Retrospective {round_num} validation failed[/yellow]  "
                    f"[dim]{validation.reason}[/dim]"
                )
                if round_num >= config.retrospective_rounds:
                    success = False
                    break
                continue

            console.print()
            console.print(
                f"[yellow]⚠ Retrospective {round_num} — "
                f"{len(retro_result.tasks_created)} issue(s) found[/yellow]  "
                f"[dim]{retro_result.summary}[/dim]"
            )

            # Discover and execute the new R-prefixed tasks
            retro_tasks = discover_tasks(tasks_dir)
            retro_tasks = _filter_and_set_status(retro_tasks, progress_file)
            retro_pending = [t for t in retro_tasks if _task_needs_work(t)]

            unsafe_tasks = _unsafe_retrospective_tasks(retro_pending)
            if unsafe_tasks:
                console.print(
                    "[red]Retrospective created unsafe recovery task(s); refusing to execute.[/red]"
                )
                console.print(
                    "[dim]Forbidden destructive git/file recovery instructions found in: "
                    f"{', '.join(unsafe_tasks)}[/dim]"
                )
                success = False
                break

            # Add retrospective tasks to the monitor writer so they appear
            # on the dashboard
            if monitor_writer is not None and retro_pending:
                try:
                    monitor_writer.add_tasks(retro_pending)
                except Exception:
                    pass

            if not retro_pending:
                # All fix-up tasks already done (unlikely but possible)
                continue

            console.print()
            console.print(
                f"[bold {ARCHITECT_GREEN}]The Architect[/bold {ARCHITECT_GREEN}]  "
                f"[{ARCHITECT_GREEN}]{len(retro_pending)} fix-up task(s) from "
                f"retrospective {round_num}[/{ARCHITECT_GREEN}]"
            )

            try:
                retro_success, retro_results, retro_duration = asyncio.run(
                    _run_tasks_raw(
                        project,
                        config,
                        retro_pending,
                        free_rotator=free_rotator,
                        monitor_writer=monitor_writer,
                        provider=provider,
                        original_goal=original_goal,
                        model_override=architect_model or None,
                        use_tui=use_tui,
                        verify_resume=verify_resume,
                    )
                )
            except RuntimeError as e:
                console.print(f"\n[red]Error: {e}[/red]")
                success = False
                break
            except Exception as e:
                console.print(
                    f"\n[red]Unexpected error during retrospective execution: {e!r}[/red]"
                )
                logger.error(f"Unexpected error during retrospective execution: {e!r}")
                success = False
                break

            all_results.extend(retro_results)

            if not retro_success:
                console.print(f"[red]Fix-up execution failed after retrospective {round_num}[/red]")

            validation = _validate_cycle(tasks_dir, progress_file)
            _write_cycle_validation_to_progress(progress_file, validation, round_num)
            collected_retrospective_rounds[-1].validation_passed = validation.passed
            collected_retrospective_rounds[-1].validation_reason = validation.reason
            collected_retrospective_rounds[-1].unresolved_tasks = list(validation.unresolved_tasks)
            if validation.passed:
                console.print()
                console.print(
                    f"[#7cc800]✓ Retrospective {round_num} validation passed[/#7cc800]  "
                    "[dim]cycle is clean[/dim]"
                )
                success = True
                break

            validation_feedback = _format_cycle_validation_feedback(validation)
            console.print()
            console.print(
                f"[yellow]⚠ Retrospective {round_num} validation failed[/yellow]  "
                f"[dim]{validation.reason}[/dim]"
            )
            if round_num >= config.retrospective_rounds:
                success = False
                break

    success = _infinite_loop_success_after_clean_failure(
        success=success,
        project=project,
        config=config,
        return_on_success=_return_on_success,
    )

    # ── Final summary ──────────────────────────────────────────────────
    # Write final monitor state before generating the summary
    if monitor_writer is not None:
        try:
            monitor_writer.on_run_done(success)
        except Exception:
            pass

    try:
        total_duration = time.time() - run_start
        total_tokens = TokenUsage()
        for r in all_results:
            total_tokens = total_tokens + r.tokens
        retro_rounds = collected_retrospective_rounds if collected_retrospective_rounds else None
        success_path = write_success_md(
            project,
            all_results,
            total_duration,
            total_tokens,
            retrospective_rounds=retro_rounds,
            original_goal=original_goal,
        )

        # ── Token ledger recording ────────────────────────────────────────
        if config.token_ledger:
            try:
                ledger = load_ledger(project)
                outcome = "success" if success else "failure"
                append_run(ledger, all_results, original_goal, total_duration, outcome)
                save_ledger(project, ledger)
            except Exception as _ledger_exc:
                logger.debug(f"Token ledger recording failed (non-fatal): {_ledger_exc!r}")

        # TUI path: show the animated success screen instead of the plain
        # terminal summary.  The screen blocks until the user presses Enter,
        # Q, or Escape, then the ArchitectAppRunner exits cleanly.
        suppress_success_screen = _suppress_success_screen or bool(_infinite_loop_active(config))
        if use_tui and not suppress_success_screen:
            try:
                from the_architect.tui.runner import active_runner

                _runner = active_runner()
                if _runner is not None:
                    _runner.app.show_success(
                        results=all_results,
                        total_duration=total_duration,
                        total_tokens=total_tokens,
                        success_md_path=str(success_path),
                        retrospective_rounds=retro_rounds,
                        token_budget_per_run=config.token_budget_per_run,
                    )
            except Exception as _tui_exc:
                logger.debug(f"TUI success screen failed (non-fatal): {_tui_exc!r}")
                # Fall through to the plain terminal summary below.
                print_success_summary(
                    all_results,
                    total_duration,
                    total_tokens,
                    success_path,
                    retrospective_rounds=retro_rounds,
                )
        elif not suppress_success_screen:
            # Plain terminal summary (non-TUI / headless path).
            print_success_summary(
                all_results,
                total_duration,
                total_tokens,
                success_path,
                retrospective_rounds=retro_rounds,
            )

            # Pause so the user can read the summary before the screen closes.
            # Skipped in headless mode (no interactive terminal).
            if not headless:
                try:
                    console.print("[dim]Press any key to exit…[/dim]")
                    _wait_for_keypress()
                except Exception:
                    # Non-interactive terminal (pipe, CI, etc.) — skip silently.
                    pass

        # ── Run completion notification ────────────────────────────────────
        try:
            notify_run_completion(
                notify_on_complete=config.notify_on_complete,
                notify_on_fail=config.notify_on_fail,
                results=all_results,
                total_duration=total_duration,
            )
        except Exception as _notif_exc:
            logger.debug(f"Run completion notification failed (non-fatal): {_notif_exc!r}")

        # ── Post-run hooks ────────────────────────────────────────────────
        try:
            asyncio.run(
                _fire_hooks(
                    project,
                    HookEvent.post_run_success if success else HookEvent.post_run_failure,
                )
            )
        except Exception as _hook_exc:
            logger.debug(f"Post-run hook failed (non-fatal): {_hook_exc!r}")
    except Exception as exc:
        # Summary generation must not crash the process — log and continue.
        logger.error(f"Error generating final summary: {exc!r}")
        console.print(f"\n[red]Error generating final summary: {exc}[/red]")

    if success and (_return_on_success or _infinite_loop_active(config)):
        return

    raise SystemExit(0 if success else 1)


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------


def _format_priority_cell(priority: str | None) -> str:
    """Return a Rich markup string for a task priority value.

    Args:
        priority: The priority string or ``None`` (defaults to medium).

    Returns:
        A Rich markup string with color-coded priority indicator.
    """
    effective = priority if priority else "medium"
    if effective == "critical":
        return "[red]● Critical[/red]"
    if effective == "high":
        return "[yellow]● High[/yellow]"
    if effective == "medium":
        return "[dim]○ Medium[/dim]"
    # low
    return "[dim]○ Low[/dim]"


def _format_list_json(
    project: Path,
    tasks: list[Task],
    progress_file: Path,
) -> str:
    """Return the task list as structured JSON.

    Args:
        project: Resolved project root path.
        tasks: Discovered task objects.
        progress_file: Path to PROGRESS.md for status lookup.

    Returns:
        JSON string with project path and tasks array containing
        prefix, title, status, depends_on, and priority per task.
    """
    tasks_out: list[dict[str, object]] = []
    for task in tasks:
        status = task_status(progress_file, task.prefix) or "Pending"
        tasks_out.append(
            {
                "task_id": task.prefix,
                "title": task.title or task.name,
                "status": status,
                "depends_on": task.depends_on,
                "priority": task.priority if task.priority else "medium",
            }
        )
    result: dict[str, object] = {
        "project": str(project),
        "tasks": tasks_out,
    }
    return json.dumps(result, indent=2)


@main.command(name="list")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
)
@click.option(
    "--tui",
    "use_tui",
    is_flag=True,
    help="Render the task list in the Textual TUI",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def list_cmd(project: Path | None, use_tui: bool, as_json: bool) -> None:
    """Show all tasks and their status."""
    _setup_loguru()
    proj = (project or Path.cwd()).resolve()

    # Mutual exclusion: --json cannot be combined with --tui
    if as_json and use_tui:
        console.print("[red]Error: --json and --tui are mutually exclusive.[/red]")
        raise SystemExit(1)

    if use_tui or (not as_json and _tui_mode_enabled()):
        try:
            from the_architect.tui.screens import run_list_screen

            run_list_screen(project=proj)
            return
        except Exception as exc:
            logger.debug(f"TUI list screen failed, falling back to rich: {exc!r}")

    config = load_config(proj)
    tasks_dir = proj / config.tasks_dir.name

    if not tasks_dir.exists():
        console.print("[dim]No tasks directory found.[/dim]")
        return

    tasks = discover_tasks(tasks_dir)
    progress_file = config.progress_file

    if not tasks:
        console.print("[dim]No tasks found.[/dim]")
        return

    if as_json:
        click.echo(_format_list_json(proj, tasks, progress_file))
        return

    from rich import box
    from rich.table import Table

    table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
    table.add_column("Task", width=8)
    table.add_column("Title")
    table.add_column("Priority", width=14)
    table.add_column("Deps", width=16)
    table.add_column("Status", width=10)

    for task in tasks:
        status = task_status(progress_file, task.prefix)
        if status == "Done":
            status_cell = "[#7cc800]✓ Done[/#7cc800]"
        elif status == "Failed":
            status_cell = "[red]✗ Failed[/red]"
        elif status == "Blocked":
            status_cell = "[yellow]⏸ Blocked[/yellow]"
        elif status and status.startswith("Skipped"):
            status_cell = "[magenta]⊘ Skipped[/magenta]"
        else:
            status_cell = "[dim]○ Pending[/dim]"

        # Format priority display
        priority_cell = _format_priority_cell(task.priority)

        # Format dependency display
        if task.depends_on:
            deps_cell = "→ " + ", ".join(task.depends_on)
        else:
            deps_cell = "—"
        table.add_row(task.prefix, task.title or task.name, priority_cell, deps_cell, status_cell)

    console.print()
    console.print(table)


def _format_deps_json(
    project: Path,
    tasks: list[Task],
    progress_file: Path,
) -> str:
    """Return the dependency graph as structured JSON.

    Args:
        project: Resolved project root path.
        tasks: Discovered task objects.
        progress_file: Path to PROGRESS.md for status lookup.

    Returns:
        JSON string with project path and tasks array containing
        prefix, title, status, depends_on, depended_by, and priority per task.
    """
    # Build reverse dependency map: prefix -> list of prefixes that depend on it
    depended_by_map: dict[str, list[str]] = {}
    for task in tasks:
        for dep in task.depends_on:
            depended_by_map.setdefault(dep, []).append(task.prefix)

    tasks_out: list[dict[str, object]] = []
    for task in tasks:
        status = task_status(progress_file, task.prefix) or "Pending"
        tasks_out.append(
            {
                "task_id": task.prefix,
                "title": task.title or task.name,
                "status": status,
                "depends_on": task.depends_on,
                "depended_by": depended_by_map.get(task.prefix, []),
                "priority": task.priority if task.priority else "medium",
            }
        )
    result: dict[str, object] = {
        "project": str(project),
        "tasks": tasks_out,
    }
    return json.dumps(result, indent=2)


@main.command(name="deps")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
)
@click.option(
    "--tui",
    "use_tui",
    is_flag=True,
    help="Render the dependency graph in the Textual TUI",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def deps_cmd(project: Path | None, use_tui: bool, as_json: bool) -> None:
    """Show the task dependency graph.

    Displays each task with its dependencies (tasks it depends on) and
    dependents (tasks that depend on it).  Helps visualize execution
    order and identify tasks that can run in parallel.
    """
    _setup_loguru()
    proj = (project or Path.cwd()).resolve()

    # Mutual exclusion: --json cannot be combined with --tui
    if as_json and use_tui:
        console.print("[red]Error: --json and --tui are mutually exclusive.[/red]")
        raise SystemExit(1)

    if use_tui or (not as_json and _tui_mode_enabled()):
        try:
            from the_architect.tui.screens import run_deps_screen

            run_deps_screen(project=proj)
            return
        except Exception as exc:
            logger.debug(f"TUI deps screen failed, falling back to rich: {exc!r}")

    config = load_config(proj)
    tasks_dir = proj / config.tasks_dir.name

    if not tasks_dir.exists():
        console.print("[dim]No tasks directory found.[/dim]")
        return

    tasks = discover_tasks(tasks_dir)
    progress_file = config.progress_file

    if not tasks:
        console.print("[dim]No tasks found.[/dim]")
        return

    if as_json:
        click.echo(_format_deps_json(proj, tasks, progress_file))
        return

    # Build reverse dependency map: prefix -> list of prefixes that depend on it
    depended_by: dict[str, list[str]] = {}
    for task in tasks:
        for dep in task.depends_on:
            depended_by.setdefault(dep, []).append(task.prefix)

    from rich import box
    from rich.table import Table

    table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
    table.add_column("Task", width=8)
    table.add_column("Title")
    table.add_column("Priority", width=14)
    table.add_column("Depends On", width=16)
    table.add_column("Depended By", width=16)
    table.add_column("Status", width=10)

    for task in tasks:
        status = task_status(progress_file, task.prefix)
        if status == "Done":
            status_cell = "[#7cc800]✓ Done[/#7cc800]"
        elif status == "Failed":
            status_cell = "[red]✗ Failed[/red]"
        elif status == "Blocked":
            status_cell = "[yellow]⏸ Blocked[/yellow]"
        elif status and status.startswith("Skipped"):
            status_cell = "[magenta]⊘ Skipped[/magenta]"
        else:
            status_cell = "[dim]○ Pending[/dim]"

        # Format priority display
        priority_cell = _format_priority_cell(task.priority)

        # Format dependency display
        if task.depends_on:
            deps_cell = "→ " + ", ".join(task.depends_on)
        else:
            deps_cell = "—"

        # Format dependent display
        dependents = depended_by.get(task.prefix, [])
        if dependents:
            dependents_cell = "← " + ", ".join(dependents)
        else:
            dependents_cell = "—"

        table.add_row(
            task.prefix,
            task.title or task.name,
            priority_cell,
            deps_cell,
            dependents_cell,
            status_cell,
        )

    console.print()
    console.print(table)


@main.command()
@click.option("--task", "-t", default=None, help="Task prefix to retry (e.g. T03)")
@click.option("--last", "last", is_flag=True, default=False, help="Retry the last failed task")
@click.option(
    "--failed",
    "reset_failed",
    is_flag=True,
    default=False,
    help="Reset all failed tasks to Pending (does not run them)",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output in JSON format for scripted workflows",
)
@click.option(
    "--yes",
    "--force",
    "force",
    is_flag=True,
    help="Skip confirmation prompt (required with --json)",
)
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
)
def retry(
    task: str | None,
    last: bool,
    reset_failed: bool,
    as_json: bool,
    force: bool,
    project: Path | None,
) -> None:
    """Retry a specific task (reset its terminal status and re-run).

    Handles both Done and Failed rows — flipping either back to Pending
    so the main loop will pick the task up again.  This is the intended
    escape hatch when a task has been marked Failed by the runner's
    retry exhaustion and the user wants to try again after fixing an
    external issue (e.g. restoring network access, fixing credentials).

    Use --last to retry the most recent failed task.  Use --failed to
    reset all failed tasks to Pending so the next run picks them up.
    """
    _setup_loguru()

    task_obj: Task | None = None
    task_prefix: str | None = None
    previous_status: str | None = None

    # Validate mutual exclusivity
    flags_used = sum([task is not None, last, reset_failed])
    if flags_used > 1:
        if as_json:
            click.echo(
                json.dumps(
                    {
                        "project": str(project or Path.cwd()),
                        "error": "--task, --last, and --failed are mutually exclusive",
                    },
                    indent=2,
                )
            )
        else:
            console.print("[red]Error: --task, --last, and --failed are mutually exclusive.[/red]")
        raise SystemExit(1)

    # --json requires --force — no interactive retry in scripted mode
    if as_json and not force:
        click.echo(json.dumps({"project": str(project or Path.cwd()), "cancelled": True}, indent=2))
        return

    proj = (project or Path.cwd()).resolve()
    config = load_config(proj)
    progress_file = config.progress_file
    tasks_dir = proj / config.tasks_dir.name

    # --- Handle --last: retry the most recent failed task ---
    if last:
        from the_architect.core.progress import find_failed_tasks

        failed = find_failed_tasks(progress_file, tasks_dir)
        if not failed:
            if as_json:
                click.echo(
                    json.dumps({"project": str(proj), "error": "No failed tasks found"}, indent=2)
                )
            else:
                console.print("[yellow]No failed tasks found.[/yellow]")
            raise SystemExit(1)
        target_task = failed[-1]  # last in plan order
        previous_status = "Failed"
        task_prefix = target_task.prefix
        task_obj = target_task
        if as_json:
            click.echo(
                json.dumps(
                    {
                        "project": str(proj),
                        "task_id": task_prefix,
                        "title": target_task.title,
                        "action": "retry_last",
                        "previous_status": previous_status,
                    },
                    indent=2,
                )
            )
        else:
            console.print(
                f"[dim]Retrying last failed task: {task_prefix} ({target_task.title})[/dim]"
            )

    # --- Handle --failed: reset all failed tasks to Pending ---
    elif reset_failed:
        from the_architect.core.progress import find_failed_tasks

        failed = find_failed_tasks(progress_file, tasks_dir)
        if not failed:
            if as_json:
                click.echo(
                    json.dumps(
                        {"project": str(proj), "error": "No failed tasks to reset"}, indent=2
                    )
                )
            else:
                console.print("[yellow]No failed tasks to reset.[/yellow]")
            raise SystemExit(1)
        reset_count = 0
        for t in failed:
            if reconcile_task_status(progress_file, t.prefix, "Pending", completed="—"):
                reset_count += 1
        if as_json:
            click.echo(
                json.dumps(
                    {
                        "project": str(proj),
                        "action": "reset_failed",
                        "count": reset_count,
                        "tasks": [{"task_id": t.prefix, "title": t.title} for t in failed],
                    },
                    indent=2,
                )
            )
        else:
            console.print(f"[dim]Reset {reset_count} failed task(s) to Pending.[/dim]")
            for t in failed:
                console.print(f"  [dim]  {t.prefix} — {t.title}[/dim]")
            console.print("[dim]Run [bold]architect[/bold] to execute the reset tasks.[/dim]")
        raise SystemExit(0)

    # --- Handle --task: retry a specific task (existing behavior) ---
    elif task is not None:
        task_prefix = task
        if not task_is_resolved(progress_file, task_prefix):
            if as_json:
                pass  # suppressed — will be in JSON output
            else:
                console.print(
                    f"[dim]Task {task_prefix} is not in a terminal state — running now.[/dim]"
                )

        # Reset in PROGRESS.md if it was Done, Failed, or Blocked.
        if progress_file.exists():
            current = task_status(progress_file, task_prefix)
            if current in ("Done", "Failed", "Blocked"):
                previous_status = current
                if reconcile_task_status(progress_file, task_prefix, "Pending", completed="—"):
                    if as_json:
                        pass  # suppressed — will be in JSON output
                    else:
                        console.print(f"[dim]Reset {task_prefix} ({current} → Pending).[/dim]")

        all_tasks = discover_tasks(tasks_dir)
        task_obj = next((t for t in all_tasks if t.prefix.upper() == task_prefix.upper()), None)

        if not task_obj:
            if as_json:
                click.echo(
                    json.dumps(
                        {
                            "project": str(proj),
                            "task_id": task_prefix,
                            "error": f"Task {task_prefix} not found in tasks/",
                        },
                        indent=2,
                    )
                )
            else:
                console.print(f"[red]Task {task_prefix} not found in tasks/.[/red]")
            raise SystemExit(1)

        if as_json:
            click.echo(
                json.dumps(
                    {
                        "project": str(proj),
                        "task_id": task_prefix,
                        "title": task_obj.title,
                        "action": "retry_task",
                        "previous_status": previous_status or "Pending",
                        "reset_status": "Pending",
                    },
                    indent=2,
                )
            )

    else:
        if as_json:
            click.echo(
                json.dumps(
                    {
                        "project": str(proj),
                        "error": "Specify one of --task, --last, or --failed",
                    },
                    indent=2,
                )
            )
        else:
            console.print("[red]Error: Specify one of --task, --last, or --failed.[/red]")
        raise SystemExit(1)

    from the_architect.core.provider import ProviderNotFoundError, detect_provider

    # At this point task_obj is guaranteed set (other branches exit early)
    assert task_obj is not None

    try:
        _run_provider = detect_provider("auto")
    except ProviderNotFoundError:
        if as_json:
            click.echo(
                json.dumps({"project": str(proj), "error": "No supported AI CLI found"}, indent=2)
            )
        else:
            console.print("[red]Error: No supported AI CLI found.[/red]")
        raise SystemExit(1)
    ensure_provider_setup(_run_provider, proj, config)
    setup_logging(config.log_dir)
    asyncio.run(run_task(task_obj, config))


@main.command()
@click.option("--task", "-t", default=None, help="Task prefix to skip (e.g. T03)")
@click.option(
    "--last", "skip_last", is_flag=True, help="Skip the last failed task (highest plan order)"
)
@click.option(
    "--failed",
    "skip_failed",
    is_flag=True,
    help="Skip all failed tasks (mark all Failed → Done)",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output in JSON format for scripted workflows",
)
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
)
def skip(
    task: str | None,
    skip_last: bool,
    skip_failed: bool,
    as_json: bool,
    project: Path | None,
) -> None:
    """Mark a task as Done without running it.

    Use --task to skip a specific task.  Use --last to skip the most recent
    failed task.  Use --failed to skip all failed tasks at once.

    Supports all terminal statuses (Pending, Failed, Blocked, Skipped) —
    any of them can be transitioned to Done.
    """
    _setup_loguru()

    # Validate mutual exclusivity
    flags_used = sum([task is not None, skip_last, skip_failed])
    if flags_used > 1:
        console.print("[red]Error: --task, --last, and --failed are mutually exclusive.[/red]")
        raise SystemExit(1)
    if flags_used == 0:
        console.print("[red]Error: Specify one of --task, --last, or --failed.[/red]")
        raise SystemExit(1)

    proj = (project or Path.cwd()).resolve()
    config = load_config(proj)
    progress_file = config.progress_file
    tasks_dir = proj / config.tasks_dir.name

    if not progress_file.exists():
        console.print("[red]PROGRESS.md not found.[/red]")
        console.print("[dim]Run [bold]architect --plan[/bold] first to create tasks.[/dim]")
        raise SystemExit(1)

    # --- Handle --last: skip the last failed task ---
    if skip_last:
        failed = find_failed_tasks(progress_file, tasks_dir)
        if not failed:
            console.print("[yellow]No failed tasks found.[/yellow]")
            raise SystemExit(1)
        target_task = failed[-1]  # last in plan order
        task_prefix = target_task.prefix
        _skip_single_task(progress_file, task_prefix, as_json)
        raise SystemExit(0)

    # --- Handle --failed: skip all failed tasks ---
    if skip_failed:
        failed = find_failed_tasks(progress_file, tasks_dir)
        if not failed:
            console.print("[yellow]No failed tasks to skip.[/yellow]")
            raise SystemExit(1)
        skipped: list[str] = []
        today = __import__("datetime").date.today().isoformat()
        for t in failed:
            if reconcile_task_status(progress_file, t.prefix, "Done", completed=today):
                skipped.append(t.prefix)
                _increment_tasks_completed(progress_file)
        if as_json:
            click.echo(json.dumps({"skipped": skipped, "project": str(proj)}))
        else:
            console.print(f"[dim]Skipped {len(skipped)} failed task(s):[/dim]")
            for prefix in skipped:
                console.print(f"  [dim]  {prefix}[/dim]")
        raise SystemExit(0)

    # --- Handle --task: skip a specific task ---
    assert task is not None
    _skip_single_task(progress_file, task, as_json)


def _skip_single_task(
    progress_file: Path,
    task_prefix: str,
    as_json: bool,
) -> bool:
    """Mark a single task as Done in PROGRESS.md, incrementing the counter.

    Handles all terminal statuses (Pending, Failed, Blocked, Skipped) plus
    already-Done tasks.  Increments ``**Tasks completed:** N`` when the task
    was not already Done.

    Args:
        progress_file: Path to PROGRESS.md.
        task_prefix: Task prefix to skip, e.g. ``"T03"``.
        as_json: If True, output JSON instead of Rich console output.

    Returns:
        True if the task was marked Done (was not already Done).
    """
    # Check if already Done
    if task_is_done(progress_file, task_prefix):
        if as_json:
            click.echo(
                json.dumps(
                    {
                        "task": task_prefix,
                        "status": "already_done",
                        "message": f"Task {task_prefix} is already Done",
                    }
                )
            )
        else:
            console.print(f"[dim]Task {task_prefix} is already Done.[/dim]")
        return False

    # Check if the row exists (any status)
    current = task_status(progress_file, task_prefix)
    if current is None:
        if as_json:
            click.echo(
                json.dumps(
                    {
                        "task": task_prefix,
                        "status": "error",
                        "message": f"Task {task_prefix} not found in PROGRESS.md",
                    }
                )
            )
        else:
            console.print(f"[red]Task {task_prefix} not found in PROGRESS.md.[/red]")
        raise SystemExit(1)

    # Use reconcile_task_status to handle any status → Done transition
    today = __import__("datetime").date.today().isoformat()
    if not reconcile_task_status(progress_file, task_prefix, "Done", completed=today):
        if as_json:
            click.echo(
                json.dumps(
                    {
                        "task": task_prefix,
                        "status": "error",
                        "message": f"Could not update PROGRESS.md for task {task_prefix}",
                    }
                )
            )
        else:
            console.print(f"[red]Could not update PROGRESS.md for task {task_prefix}.[/red]")
        raise SystemExit(1)

    # Increment the "Tasks completed" counter
    _increment_tasks_completed(progress_file)

    if as_json:
        click.echo(
            json.dumps(
                {
                    "task": task_prefix,
                    "status": "done",
                    "previous_status": current,
                    "message": f"Task {task_prefix} marked as Done",
                }
            )
        )
    else:
        if current:
            console.print(
                f"[#7cc800]✓ Task {task_prefix} marked as Done ({current} → Done).[/#7cc800]"
            )
        else:
            console.print(f"[#7cc800]✓ Task {task_prefix} marked as Done.[/#7cc800]")

    return True


def _increment_tasks_completed(progress_file: Path) -> None:
    """Increment the ``**Tasks completed:** N`` counter in PROGRESS.md.

    Reads the file, finds the counter line, increments it by 1, and writes
    back.  If the line is missing, it is added after ``## Overall Status``.

    Args:
        progress_file: Path to PROGRESS.md.
    """
    content = progress_file.read_text(encoding="utf-8")

    # Try to find and increment the existing counter
    counter_pattern = re.compile(r"(\*\*Tasks completed:\*\*\s*)(\d+)")
    match = counter_pattern.search(content)
    if match:
        new_count = int(match.group(2)) + 1
        updated = counter_pattern.sub(rf"\g<1>{new_count}", content, count=1)
        progress_file.write_text(updated, encoding="utf-8")
        return

    # Fallback: add the counter line if missing (should not happen in practice)
    header_pattern = re.compile(r"(## Overall Status\s*\n)")
    if header_pattern.search(content):
        updated = header_pattern.sub(r"\g<1>\n**Tasks completed:** 1\n", content, count=1)
        progress_file.write_text(updated, encoding="utf-8")


@main.command()
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
@click.option(
    "--yes",
    "--force",
    "force",
    is_flag=True,
    help="Skip confirmation prompt (use with caution)",
)
def reset(project: Path | None, as_json: bool, force: bool) -> None:
    """Reset PROGRESS.md to initial state."""
    _setup_loguru()
    from the_architect.core.progress import PROGRESS_TEMPLATE

    proj = (project or Path.cwd()).resolve()
    config = load_config(proj)
    progress_file = config.progress_file

    if not progress_file.exists():
        if as_json:
            click.echo(
                json.dumps(
                    {"project": str(proj), "reset": False, "error": "PROGRESS.md not found"},
                    indent=2,
                )
            )
        else:
            console.print("[red]PROGRESS.md not found.[/red]")
            console.print("[dim]Run [bold]architect --plan[/bold] first to create tasks.[/dim]")
        raise SystemExit(1)

    if not force:
        if as_json:
            # JSON mode requires --force — no interactive prompt in scripted mode
            click.echo(
                json.dumps({"project": str(proj), "reset": False, "cancelled": True}, indent=2)
            )
            return
        if not click.confirm("This will reset PROGRESS.md to initial state. Continue?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    content = PROGRESS_TEMPLATE.format(
        tasks_completed=0,
        next_task="T00",
        task_rows="",
        current_state="Reset at user's request.",
        last_summary="",
    )
    progress_file.write_text(content, encoding="utf-8")
    if as_json:
        click.echo(json.dumps({"project": str(proj), "reset": True}, indent=2))
    else:
        console.print("[#7cc800]✓ PROGRESS.md reset.[/#7cc800]")


@main.command()
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
@click.option(
    "--yes",
    "--force",
    "force",
    is_flag=True,
    help="Skip confirmation prompt (use with caution)",
)
def cancel(project: Path | None, as_json: bool, force: bool) -> None:
    """Remove a stale lock file so the next run is not blocked.

    The Architect writes a lock file at .architect/runner.lock when it starts.
    If The Architect was killed (Ctrl+C, terminal close, crash) without cleaning
    up, the lock file remains and blocks the next run.

    This command removes the lock file so you can run architect again.
    It also cleans up the monitor state file so ``architect monitor --watch``
    does not show stale data.

    It does NOT kill any running process — use Ctrl+C or your OS tools
    for that.

    \b
    Examples:
      architect cancel
      architect cancel --force    # skip confirmation if PID is still alive
      architect cancel --json     # machine-readable output
    """
    _setup_loguru()
    import os

    proj = (project or Path.cwd()).resolve()
    lock_path = proj / ".architect" / "runner.lock"

    if not lock_path.exists():
        if as_json:
            click.echo(
                json.dumps({"project": str(proj), "lock_file": "not_found", "cancelled": False})
            )
        else:
            console.print("[dim]No lock file found — nothing to cancel.[/dim]")
            console.print(f"[dim](looked in {lock_path})[/dim]")
        return

    # Read PID from lock file
    try:
        pid_str = lock_path.read_text(encoding="utf-8").strip()
        pid = int(pid_str)
    except (OSError, ValueError):
        pid = None

    # Check if the process is still alive
    process_alive = False
    if pid is not None:
        try:
            # Signal 0 = existence check only — does NOT kill the process.
            # Cross-platform: works on Windows, Linux, and macOS (Python 3.x).
            os.kill(pid, 0)
            process_alive = True
        except (ProcessLookupError, PermissionError, OSError):
            # ProcessLookupError on Linux/macOS, plain OSError on Windows —
            # both indicate the process is gone.
            process_alive = False

    # Handle PID-alive confirmation
    pid_action = "none"
    if pid is not None and process_alive:
        if as_json:
            click.echo(
                json.dumps(
                    {
                        "project": str(proj),
                        "lock_file": "found",
                        "pid": pid,
                        "pid_alive": True,
                        "cancelled": False,
                        "message": "Process still running — use --force to skip confirmation",
                    }
                )
            )
            return
        if not force:
            console.print(f"[yellow]⚠  The Architect is still running (PID {pid}).[/yellow]")
            console.print()
            if not click.confirm(f"  Stop PID {pid}?", default=False):
                console.print(
                    "[dim]Process left running. Use Ctrl+C in the original terminal.[/dim]"
                )
                console.print("[dim]Lock file not removed.[/dim]")
                return
        # --force or user confirmed — send SIGTERM
        try:
            import signal

            os.kill(pid, signal.SIGTERM)
            pid_action = "signalled"
            if not as_json:
                console.print(f"[dim]Sent termination signal to PID {pid}.[/dim]")
                console.print()
        except (ProcessLookupError, PermissionError) as sig_err:
            if not as_json:
                console.print(f"[yellow]Could not terminate process: {sig_err}[/yellow]")

    if not as_json:
        if pid is not None and process_alive and pid_action == "none":
            console.print(f"[dim]Stale lock found (PID {pid} is no longer running).[/dim]")
        elif pid is not None and not process_alive and pid_action == "none":
            console.print(f"[dim]Stale lock found (PID {pid} is no longer running).[/dim]")
        elif pid is None and pid_action == "none":
            console.print("[dim]Lock file found but PID could not be read — removing.[/dim]")

    # Remove the lock
    try:
        lock_path.unlink()
    except OSError as e:
        if as_json:
            click.echo(
                json.dumps(
                    {
                        "project": str(proj),
                        "lock_file": "error",
                        "error": str(e),
                        "cancelled": False,
                    }
                )
            )
        else:
            console.print(f"[red]Failed to remove lock file: {e}[/red]")
        raise SystemExit(1)

    # Clean up monitor state — write a cancelled state so monitor --watch exits
    try:
        from the_architect.core.monitor_state import (
            RUN_STATUS_FAILED,
            write_monitor_state,
        )

        # Read existing monitor state to preserve historical data
        existing_state: dict[str, Any] | None = None
        try:
            from the_architect.core.monitor_state import read_monitor_state

            existing_state = read_monitor_state(proj)
        except Exception:
            pass

        state: dict[str, Any] = {
            "status": RUN_STATUS_FAILED,
            "project_name": proj.name,
            "cancelled": True,
            "cancelled_at": __import__("datetime", fromlist=["UTC", "datetime"])
            .datetime.now(tz=__import__("datetime", fromlist=["UTC", "datetime"]).UTC)
            .isoformat(),
        }
        # Preserve existing fields if available
        if existing_state and isinstance(existing_state, dict):
            for key in (
                "run_started_at",
                "current_task_id",
                "current_task_title",
                "tasks",
                "tokens",
                "circuit_breaker",
            ):
                if key in existing_state:
                    state[key] = existing_state[key]

        write_monitor_state(proj, state)
    except Exception:
        # Monitor state cleanup is best-effort — never fail the cancel because of it
        pass

    if as_json:
        click.echo(
            json.dumps(
                {
                    "project": str(proj),
                    "lock_file": "removed",
                    "pid": pid,
                    "pid_action": pid_action,
                    "monitor_state": "cleaned",
                    "cancelled": True,
                }
            )
        )
    else:
        console.print("[#7cc800]✓ Lock removed.[/#7cc800]")
        console.print("[dim]Monitor state cleaned.[/dim]")
        console.print("[dim]You can now run [bold]architect[/bold] again.[/dim]")


def _get_last_run_summary(project: Path) -> dict[str, Any] | None:
    """Load the most recent run record from the token ledger.

    Returns a dict with keys: date, goal, tasks_done, tasks_total,
    tokens, cost, outcome. Returns ``None`` when the ledger is empty
    or unreadable.  All errors are caught silently — the ledger is
    optional infrastructure.

    Args:
        project: The project root directory.

    Returns:
        A summary dict or ``None``.
    """
    try:
        ledger = load_ledger(project)
        if not ledger.records:
            return None
        record = ledger.records[-1]
        goal = record.goal_summary or ""
        if len(goal) > 60:
            goal = goal[:57] + "..."
        return {
            "date": record.timestamp[:10],
            "goal": goal,
            "tasks_done": sum(1 for t in record.task_breakdown if t.status == "done"),
            "tasks_total": record.task_count,
            "tokens": record.total_tokens,
            "cost": record.total_cost_estimate,
            "outcome": record.outcome,
        }
    except Exception as exc:
        logger.debug(f"Could not load last run summary: {exc!r}")
        return None


def _format_status_json(project: Path, config: ArchitectConfig) -> str:
    """Gather status data and return deterministic JSON string.

    Mirrors the same data displayed by the Rich ``status`` output:
    lock state, task list, circuit breakers, token budget, log files,
    and last run summary.
    Handles missing files gracefully — no exceptions for absent directories.
    """
    result: dict[str, Any] = {
        "project": str(project),
        "running": False,
        "pid": None,
        "tasks": [],
        "task_summary": {"total": 0, "done": 0, "failed": 0, "pending": 0, "blocked": 0},
        "circuit_breakers": [],
        "token_budget": None,
        "log_dir": None,
        "log_files": None,
        "last_run": None,
    }

    # ── Lock file ────────────────────────────────────────────────────────
    lock_path = project / ".architect" / "runner.lock"
    if lock_path.exists():
        try:
            pid = int(lock_path.read_text(encoding="utf-8").strip())
            try:
                os.kill(pid, 0)
                result["running"] = True
                result["pid"] = pid
            except (ProcessLookupError, PermissionError, OSError):
                # Stale lock — process is gone.
                result["running"] = False
                result["pid"] = pid
        except (OSError, ValueError):
            pass

    # ── Tasks ────────────────────────────────────────────────────────────
    tasks_dir = project / config.tasks_dir.name
    progress_file = config.progress_file

    if tasks_dir.exists():
        tasks = discover_tasks(tasks_dir)
        summary = {"total": 0, "done": 0, "failed": 0, "pending": 0, "blocked": 0}
        task_list = []
        for task in tasks:
            status = task_status(progress_file, task.prefix)
            task_list.append(
                {"prefix": task.prefix, "title": task.title or task.name, "status": status}
            )
            summary["total"] += 1
            if status == "Done":
                summary["done"] += 1
            elif status == "Failed":
                summary["failed"] += 1
            elif status == "Blocked":
                summary["blocked"] += 1
            else:
                summary["pending"] += 1
        result["tasks"] = task_list
        result["task_summary"] = summary

    # ── Circuit breaker ──────────────────────────────────────────────────
    circuit_file = project / ".architect" / "circuit.json"
    if circuit_file.exists():
        try:
            circuit_data = json.loads(circuit_file.read_text(encoding="utf-8"))
            circuit_list = []
            for tid, s in circuit_data.items():
                if s.get("state") in ("OPEN", "HALF_OPEN"):
                    circuit_list.append(
                        {
                            "task": tid,
                            "state": s.get("state", "?"),
                            "no_progress": s.get("consecutive_no_progress", 0),
                            "same_error": s.get("consecutive_same_error", 0),
                        }
                    )
            result["circuit_breakers"] = circuit_list
        except (OSError, json.JSONDecodeError):
            pass

    # ── Token budget ─────────────────────────────────────────────────────
    token_budget_info: dict[str, object] = {}
    if config.token_budget_per_hour > 0:
        token_budget_info["per_hour"] = config.token_budget_per_hour
    if config.token_budget_per_run > 0:
        token_budget_info["per_run"] = config.token_budget_per_run
    if config.task_timeout > 0:
        token_budget_info["task_timeout"] = config.task_timeout
    if token_budget_info:
        result["token_budget"] = token_budget_info

    # ── Logs ─────────────────────────────────────────────────────────────
    log_dir = config.log_dir
    if log_dir.exists():
        result["log_dir"] = str(log_dir)
        try:
            log_files = sorted(
                log_dir.glob("*.log"),
                key=lambda f: f.stat().st_mtime,
                reverse=True,
            )
            if log_files:
                file_list = []
                for lf in log_files[:5]:
                    size_kb = lf.stat().st_size // 1024
                    file_list.append({"name": lf.name, "size_kb": size_kb})
                result["log_files"] = file_list
        except OSError:
            pass

    # ── Last run summary ─────────────────────────────────────────────────
    last_run = _get_last_run_summary(project)
    if last_run is not None:
        result["last_run"] = last_run

    return json.dumps(result, indent=2, sort_keys=True)


@main.command(name="status")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
)
@click.option(
    "--tui",
    "use_tui",
    is_flag=True,
    help="Render status in the Textual TUI",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output status as machine-readable JSON",
)
def status_cmd(project: Path | None, use_tui: bool, as_json: bool) -> None:
    """Show current run state, circuit breaker, and token budget.

    Displays:
    - Active lock file (is a run in progress?)
    - Task list with Done/Pending status
    - Last run summary from token ledger (date, goal, tasks, tokens, cost, outcome)
    - Circuit breaker state per task
    - Token budget usage (if configured)
    - Log directory location
    """
    _setup_loguru()

    proj = (project or Path.cwd()).resolve()

    # ── JSON output path ─────────────────────────────────────────────────
    if as_json:
        config = load_config(proj)
        click.echo(_format_status_json(proj, config))
        return

    if use_tui or _tui_mode_enabled():
        try:
            from the_architect.tui.screens import run_status_screen

            run_status_screen(project=proj)
            return
        except Exception as exc:
            logger.debug(f"TUI status screen failed, falling back to rich: {exc!r}")

    config = load_config(proj)

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect[/bold {ARCHITECT_GREEN}]  [dim]{proj}[/dim]"
    )
    console.print()

    # ── Lock file ────────────────────────────────────────────────────────
    lock_path = proj / ".architect" / "runner.lock"
    if lock_path.exists():
        try:
            pid = int(lock_path.read_text(encoding="utf-8").strip())
            try:
                # Signal 0 = existence check only — does NOT kill the process.
                # Cross-platform: works on Windows, Linux, and macOS (Python 3.x).
                os.kill(pid, 0)
                console.print(f"[yellow]● Running[/yellow]  PID {pid}")
            except (ProcessLookupError, PermissionError, OSError):
                # ProcessLookupError on Linux/macOS, plain OSError on Windows —
                # both indicate the process is gone.
                console.print(
                    "[dim]○ Not running[/dim]  [dim](stale lock — run architect cancel)[/dim]"
                )
        except (OSError, ValueError):
            console.print("[dim]○ Not running[/dim]")
    else:
        console.print("[dim]○ Not running[/dim]")

    console.print()

    # ── Tasks ────────────────────────────────────────────────────────────
    tasks_dir = proj / config.tasks_dir.name
    progress_file = config.progress_file

    if not tasks_dir.exists():
        console.print(
            "[dim]No tasks directory found. Run [bold]architect --plan[/bold] to start.[/dim]"
        )
    else:
        tasks = discover_tasks(tasks_dir)
        if not tasks:
            console.print("[dim]No tasks found.[/dim]")
        else:
            from rich import box
            from rich.table import Table

            table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
            table.add_column("Task", width=8)
            table.add_column("Title")
            table.add_column("Status", width=10)

            done_count = 0
            for task in tasks:
                status = task_status(progress_file, task.prefix)
                if status == "Done":
                    done_count += 1
                    status_str = "[#7cc800]✓ Done[/#7cc800]"
                elif status == "Failed":
                    status_str = "[red]✗ Failed[/red]"
                elif status == "Blocked":
                    status_str = "[yellow]⏸ Blocked[/yellow]"
                else:
                    status_str = "[dim]○ Pending[/dim]"
                table.add_row(task.prefix, task.title or task.name, status_str)

            console.print(table)
            console.print(f"[dim]{done_count}/{len(tasks)} tasks complete[/dim]")

    console.print()

    # ── Last run summary ─────────────────────────────────────────────────
    last_run = _get_last_run_summary(proj)
    if last_run is not None:
        outcome = last_run["outcome"]
        if outcome == "success":
            outcome_str = "[#7cc800]✓ Success[/#7cc800]"
        else:
            outcome_str = "[red]✗ Failed[/red]"
        console.print("[bold]Last Run[/bold]")
        console.print(f"  [dim]Date:[/dim]  {last_run['date']}  [dim]Outcome:[/dim]  {outcome_str}")
        console.print(f"  [dim]Goal:[/dim]  {last_run['goal']}")
        console.print(
            f"  [dim]Tasks:[/dim]  {last_run['tasks_done']}/{last_run['tasks_total']}  "
            f"[dim]Tokens:[/dim]  {last_run['tokens']:,}  "
            f"[dim]Cost:[/dim]  ${last_run['cost']:.4f}"
        )
        console.print()

    # ── Circuit breaker ──────────────────────────────────────────────────
    circuit_file = proj / ".architect" / "circuit.json"
    if circuit_file.exists():
        try:
            circuit_data = json.loads(circuit_file.read_text(encoding="utf-8"))
            open_tasks = [
                (tid, s)
                for tid, s in circuit_data.items()
                if s.get("state") in ("OPEN", "HALF_OPEN")
            ]
            if open_tasks:
                console.print("[yellow]Circuit breaker:[/yellow]")
                for tid, s in open_tasks:
                    state = s.get("state", "?")
                    no_prog = s.get("consecutive_no_progress", 0)
                    same_err = s.get("consecutive_same_error", 0)
                    console.print(
                        f"  [yellow]{tid}[/yellow]  {state}  "
                        f"[dim]no_progress={no_prog}  same_error={same_err}[/dim]"
                    )
                console.print()
        except (OSError, json.JSONDecodeError):
            pass

    # ── Token budget ─────────────────────────────────────────────────────
    if config.token_budget_per_hour > 0:
        console.print(
            f"[dim]Token budget/hour:[/dim]  {config.token_budget_per_hour:,} tokens/hour  "
            "[dim](tracked per run — resets on restart)[/dim]"
        )
    if config.token_budget_per_run > 0:
        console.print(
            f"[dim]Token budget/run:[/dim]  {config.token_budget_per_run:,} tokens/run  "
            "[dim](cumulative — stops run when exceeded)[/dim]"
        )
    if config.task_timeout > 0:
        console.print(
            f"[dim]Task timeout:[/dim]  {config.task_timeout}s/task  "
            "[dim](kills task subprocess on wall-clock timeout)[/dim]"
        )
    if (
        config.token_budget_per_hour > 0
        or config.token_budget_per_run > 0
        or config.task_timeout > 0
    ):
        console.print()

    # ── Logs ─────────────────────────────────────────────────────────────
    log_dir = config.log_dir  # already resolved as absolute path by load_config
    if log_dir.exists():
        log_files = sorted(log_dir.glob("*.log"), key=lambda f: f.stat().st_mtime, reverse=True)
        if log_files:
            console.print(f"[dim]Logs:[/dim]  {log_dir}")
            for lf in log_files[:5]:
                size_kb = lf.stat().st_size // 1024
                console.print(f"  [dim]{lf.name}  ({size_kb} KB)[/dim]")
            if len(log_files) > 5:
                console.print(f"  [dim]… and {len(log_files) - 5} more[/dim]")
            console.print()


# ---------------------------------------------------------------------------
# Token report command
# ---------------------------------------------------------------------------


def _fmt_cost(dollars: float) -> str:
    """Format a USD cost value for display.

    Args:
        dollars: Cost amount in USD.

    Returns:
        Formatted string like ``"$0.00"`` or ``"$12.34"``.
    """
    return f"${dollars:.2f}"


def _render_token_report_table(
    ledger: TokenLedger,
    top_models: int | None = None,
) -> None:
    """Render the token ledger as a Rich table with summary totals.

    Args:
        ledger: A :class:`~the_architect.core.token_ledger.TokenLedger` instance.
        top_models: When set, limit the per-model breakdown to the N most
            expensive models.
    """
    from rich import box
    from rich.table import Table

    from the_architect.core.success import _fmt_tokens

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect[/bold {ARCHITECT_GREEN}]  "
        "[dim]Token Ledger Report[/dim]"
    )
    console.print()

    if not ledger.records:
        console.print("[dim]No token ledger data found.[/dim]")
        console.print()
        return

    # ── Per-run table ────────────────────────────────────────────────────
    table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
    table.add_column("Date", width=10)
    table.add_column("Goal", no_wrap=False)
    table.add_column("Tasks", justify="right", width=6)
    table.add_column("Tokens", justify="right", width=8)
    table.add_column("Est. Cost", justify="right", width=9)
    table.add_column("Outcome", width=10)

    for record in ledger.records:
        # Extract date portion from ISO timestamp
        date_str = record.timestamp[:10] if len(record.timestamp) >= 10 else record.timestamp
        goal = record.goal_summary or "—"
        if len(goal) > 60:
            goal = goal[:57] + "..."
        tasks_str = str(record.task_count)
        tokens_str = _fmt_tokens(record.total_tokens) if record.total_tokens else "—"
        cost_str = _fmt_cost(record.total_cost_estimate)
        if record.outcome == "success":
            outcome_str = "[#7cc800]✓ Success[/#7cc800]"
        else:
            outcome_str = "[red]✗ Failed[/red]"
        table.add_row(date_str, goal, tasks_str, tokens_str, cost_str, outcome_str)

    console.print(table)

    # ── Summary totals ───────────────────────────────────────────────────
    total_runs = len(ledger.records)
    total_tokens = ledger.total_tokens_all_runs()
    total_cost = ledger.total_cost_all_runs()

    console.print()
    console.print(
        f"[bold]Summary[/bold]  "
        f"{total_runs} run{'s' if total_runs != 1 else ''}  "
        f"· {_fmt_tokens(total_tokens)} tokens  "
        f"· {_fmt_cost(total_cost)} est. cost"
    )

    # ── Per-model breakdown ──────────────────────────────────────────────
    model_totals = ledger.model_totals()
    if model_totals:
        # Calculate cost per model using the pricing table
        from the_architect.core.token_ledger import estimate_cost

        model_costs: list[tuple[str, float, int]] = []
        for model, usage in model_totals.items():
            cost = estimate_cost(usage.total, model)
            model_costs.append((model, cost, usage.total))

        # Sort by cost descending
        model_costs.sort(key=lambda x: x[1], reverse=True)
        if top_models:
            model_costs = model_costs[:top_models]

        console.print()
        console.print("[dim]Per-model cost breakdown:[/dim]")
        for model, cost, tokens in model_costs:
            short_model = model
            # Shorten provider prefixes
            for prefix in ("anthropic/", "openai/", "google/"):
                if short_model.startswith(prefix):
                    short_model = short_model[len(prefix) :]
                    break
            console.print(
                f"  [dim]{short_model}[/dim]  {_fmt_tokens(tokens)} tokens  · {_fmt_cost(cost)}"
            )

    console.print()


def _render_token_report_tasks_table(ledger: TokenLedger) -> None:
    """Render per-task cost breakdown for the token report as a Rich table.

    Args:
        ledger: A :class:`~the_architect.core.token_ledger.TokenLedger` instance.
    """
    from rich import box
    from rich.table import Table

    from the_architect.core.success import _fmt_tokens

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect[/bold {ARCHITECT_GREEN}]  "
        "[dim]Token Ledger — Per-Task Cost Breakdown[/dim]"
    )
    console.print()

    if not ledger.records:
        console.print("[dim]No token ledger data found.[/dim]")
        console.print()
        return

    # Collect all tasks across all runs
    all_tasks: list[tuple[str, LedgerTaskRecord]] = []
    for record in ledger.records:
        run_date = record.timestamp[:10] if len(record.timestamp) >= 10 else record.timestamp
        for task in record.task_breakdown:
            all_tasks.append((run_date, task))

    if not all_tasks:
        console.print("[dim]No per-task cost data found in ledger records.[/dim]")
        console.print("[dim]Task-level tracking requires a run after enabling the feature.[/dim]")
        console.print()
        return

    table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
    table.add_column("Date", width=10, style="dim")
    table.add_column("Task", width=8, style="dim")
    table.add_column("Title", no_wrap=False)
    table.add_column("Tokens", justify="right", width=8, style="dim")
    table.add_column("Est. Cost", justify="right", width=9, style="dim")
    table.add_column("Model", width=20, style="dim")
    table.add_column("Status", justify="center", width=8)

    for run_date, task in all_tasks:
        # Truncate title to 40 characters
        title = task.title or "[dim](untitled)[/dim]"
        if len(title) > 40:
            title = title[:37].rstrip() + "…"

        # Status icon
        status_lower = task.status.lower() if task.status else ""
        if status_lower == "done":
            status_str = "[green]✓ done[/green]"
        elif status_lower == "failed":
            status_str = "[red]✗ failed[/red]"
        elif status_lower == "skipped":
            status_str = "[yellow]⊘ skipped[/yellow]"
        else:
            status_str = f"[dim]{task.status}[/dim]"

        task_tokens = task.input_tokens + task.output_tokens
        model_display = task.model or "—"
        # Shorten model name
        if len(model_display) > 20:
            model_display = "…" + model_display[-17:]

        table.add_row(
            run_date,
            task.task_id,
            title,
            _fmt_tokens(task_tokens) if task_tokens else "—",
            _fmt_cost(task.cost_estimate),
            model_display,
            status_str,
        )

    console.print(table)

    # Summary totals
    total_tasks = len(all_tasks)
    total_tokens = sum(t.input_tokens + t.output_tokens for _, t in all_tasks)
    total_cost = sum(t.cost_estimate for _, t in all_tasks)

    console.print()
    console.print(
        f"[bold]Summary[/bold]  "
        f"{total_tasks} task{'s' if total_tasks != 1 else ''}  "
        f"· {_fmt_tokens(total_tokens)} tokens  "
        f"· {_fmt_cost(total_cost)} est. cost"
    )
    console.print()


def _format_token_report_json(ledger: TokenLedger) -> str:
    """Return the token ledger as structured JSON for machine consumption.

    Args:
        ledger: A :class:`~the_architect.core.token_ledger.TokenLedger` instance.

    Returns:
        JSON string containing run records and summary data.
    """
    from the_architect.core.token_ledger import estimate_cost

    result: dict[str, object] = {
        "runs": [r.model_dump() for r in ledger.records],
        "summary": {
            "total_runs": len(ledger.records),
            "total_tokens": ledger.total_tokens_all_runs(),
            "total_cost_estimate": ledger.total_cost_all_runs(),
        },
    }

    # Per-model breakdown
    model_totals = ledger.model_totals()
    if model_totals:
        model_costs: list[dict[str, object]] = []
        for model, usage in model_totals.items():
            cost = estimate_cost(usage.total, model)
            model_costs.append(
                {
                    "model": model,
                    "total_tokens": usage.total,
                    "input_tokens": usage.input_tokens,
                    "output_tokens": usage.output_tokens,
                    "cost_estimate": cost,
                }
            )
        model_costs.sort(key=lambda x: x["cost_estimate"], reverse=True)  # type: ignore[arg-type, return-value]
        result["model_breakdown"] = model_costs

    return json.dumps(result, indent=2)


@main.command(name="token-report")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Project directory (default: current working directory)",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
@click.option(
    "--since",
    default=None,
    metavar="DATE",
    help="Show only runs on or after DATE (e.g. 2026-05-01)",
)
@click.option(
    "--top-models",
    type=int,
    default=None,
    metavar="N",
    help="Show only the N most expensive models in the breakdown",
)
@click.option(
    "--until",
    default=None,
    metavar="DATE",
    help="Show only runs before DATE (e.g. 2026-05-15)",
)
@click.option(
    "--model",
    default=None,
    metavar="NAME",
    help="Show only runs that used the specified model (e.g. gpt-4o)",
)
@click.option(
    "--tasks",
    "show_tasks",
    is_flag=True,
    help="Show per-task cost breakdown",
)
def token_report_cmd(
    project: Path | None,
    as_json: bool,
    since: str | None,
    top_models: int | None,
    until: str | None,
    model: str | None,
    show_tasks: bool,
) -> None:
    """Show cross-run token usage and estimated costs from the token ledger.

    Reads ``.architect/token_ledger.json`` and displays a formatted summary
    of token usage, costs, and per-model breakdowns across all Architect runs.
    Use ``--tasks`` to see per-task cost breakdown.
    """
    _setup_loguru()

    proj = (project or Path.cwd()).resolve()

    ledger = load_ledger(proj)

    # Apply date filter
    if since or until:
        ledger = ledger.filter_by_date(start=since, end=until)

    # Apply model filter
    if model:
        ledger = ledger.filter_by_model(model)

    if show_tasks:
        if as_json:
            # JSON output already includes task_breakdown via model_dump()
            click.echo(_format_token_report_json(ledger))
            return
        _render_token_report_tasks_table(ledger)
        return

    if as_json:
        click.echo(_format_token_report_json(ledger))
        return

    _render_token_report_table(ledger, top_models=top_models)


# ---------------------------------------------------------------------------
# Budget command
# ---------------------------------------------------------------------------


def _format_budget_json(
    config: ArchitectConfig,
    ledger: TokenLedger,
) -> str:
    """Return the budget overview as structured JSON for machine consumption.

    Args:
        config: The loaded :class:`~the_architect.config.ArchitectConfig`.
        ledger: A :class:`~the_architect.core.token_ledger.TokenLedger` instance.

    Returns:
        JSON string containing budget config, ledger totals, averages, and
        per-model breakdown.
    """
    from the_architect.core.token_ledger import estimate_cost

    total_tokens = ledger.total_tokens_all_runs()
    total_cost = ledger.total_cost_all_runs()
    run_count = len(ledger.records)
    task_count = sum(r.task_count for r in ledger.records)

    # Averages
    avg_tokens_per_task = total_tokens / task_count if task_count > 0 else 0
    avg_tokens_per_run = total_tokens / run_count if run_count > 0 else 0
    avg_cost_per_run = total_cost / run_count if run_count > 0 else 0.0

    # Per-model breakdown
    model_totals = ledger.model_totals()
    model_breakdown: list[dict[str, object]] = []
    if model_totals:
        for model, usage in model_totals.items():
            cost = estimate_cost(usage.total, model)
            pct = (usage.total / total_tokens * 100) if total_tokens > 0 else 0.0
            model_breakdown.append(
                {
                    "model": model,
                    "tokens": usage.total,
                    "cost_usd": cost,
                    "pct": round(pct, 1),
                }
            )
        model_breakdown.sort(key=lambda x: x["cost_usd"], reverse=True)  # type: ignore[arg-type, return-value]

    result: dict[str, object] = {
        "budget": {
            "per_hour": config.token_budget_per_hour,
            "per_run": config.token_budget_per_run,
            "task_timeout": config.task_timeout,
        },
        "ledger": {
            "total_tokens": total_tokens,
            "total_cost_usd": total_cost,
            "run_count": run_count,
            "task_count": task_count,
        },
        "averages": {
            "tokens_per_task": round(avg_tokens_per_task),
            "tokens_per_run": round(avg_tokens_per_run),
            "cost_per_run": round(avg_cost_per_run, 6),
        },
        "model_breakdown": model_breakdown,
    }

    return json.dumps(result, indent=2)


def _render_budget_table(
    config: ArchitectConfig,
    ledger: TokenLedger,
) -> None:
    """Render the budget overview as a Rich table.

    Args:
        config: The loaded :class:`~the_architect.config.ArchitectConfig`.
        ledger: A :class:`~the_architect.core.token_ledger.TokenLedger` instance.
    """
    from rich import box
    from rich.table import Table

    from the_architect.core.success import _fmt_tokens

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect[/bold {ARCHITECT_GREEN}]  "
        "[dim]Token Budget Overview[/dim]"
    )
    console.print()

    # ── Budget configuration ─────────────────────────────────────────────
    console.print("[bold]Budget Configuration[/bold]")
    per_hour = config.token_budget_per_hour
    per_run = config.token_budget_per_run

    if per_hour > 0:
        console.print(f"  Per-hour limit:  [bold]{_fmt_tokens(per_hour)} tokens[/bold]")
    else:
        console.print("  Per-hour limit:  [dim]unlimited[/dim]")

    if per_run > 0:
        console.print(f"  Per-run limit:   [bold]{_fmt_tokens(per_run)} tokens[/bold]")
    else:
        console.print("  Per-run limit:   [dim]unlimited[/dim]")

    if config.task_timeout > 0:
        console.print(f"  Task timeout:    [bold]{config.task_timeout}s[/bold]")
    else:
        console.print("  Task timeout:    [dim]unlimited[/dim]")

    console.print()

    # ── Ledger summary ───────────────────────────────────────────────────
    total_tokens = ledger.total_tokens_all_runs()
    total_cost = ledger.total_cost_all_runs()
    run_count = len(ledger.records)
    task_count = sum(r.task_count for r in ledger.records)

    if run_count == 0:
        console.print("[dim]No token ledger data found.[/dim]")
        console.print()
        return

    console.print("[bold]Ledger Summary[/bold]")
    console.print(f"  Runs:          {run_count}")
    console.print(f"  Tasks:         {task_count}")
    console.print(f"  Total tokens:  {_fmt_tokens(total_tokens)}")
    console.print(f"  Est. cost:     {_fmt_cost(total_cost)}")

    # ── Averages ─────────────────────────────────────────────────────────
    avg_tokens_per_task = total_tokens / task_count if task_count > 0 else 0
    avg_tokens_per_run = total_tokens / run_count if run_count > 0 else 0
    avg_cost_per_run = total_cost / run_count if run_count > 0 else 0.0

    console.print()
    console.print("[bold]Averages[/bold]")
    console.print(f"  Tokens per task:  {_fmt_tokens(round(avg_tokens_per_task))}")
    console.print(f"  Tokens per run:   {_fmt_tokens(round(avg_tokens_per_run))}")
    console.print(f"  Cost per run:     {_fmt_cost(avg_cost_per_run)}")

    # ── Per-model breakdown ──────────────────────────────────────────────
    model_totals = ledger.model_totals()
    if model_totals:
        from the_architect.core.token_ledger import estimate_cost

        model_costs: list[tuple[str, float, int, float]] = []
        for model, usage in model_totals.items():
            cost = estimate_cost(usage.total, model)
            pct = (usage.total / total_tokens * 100) if total_tokens > 0 else 0.0
            model_costs.append((model, cost, usage.total, pct))

        # Sort by cost descending
        model_costs.sort(key=lambda x: x[1], reverse=True)

        console.print()
        console.print("[bold]Per-Model Breakdown[/bold]")

        table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
        table.add_column("Model", no_wrap=False)
        table.add_column("Tokens", justify="right", width=8)
        table.add_column("Est. Cost", justify="right", width=9)
        table.add_column("%", justify="right", width=5)

        for model, cost, tokens, pct in model_costs:
            short_model = model
            for prefix in ("anthropic/", "openai/", "google/"):
                if short_model.startswith(prefix):
                    short_model = short_model[len(prefix) :]
                    break
            table.add_row(
                short_model,
                _fmt_tokens(tokens),
                _fmt_cost(cost),
                f"{pct:.0f}%",
            )

        console.print(table)

    console.print()


# ---------------------------------------------------------------------------
# Estimate command helpers
# ---------------------------------------------------------------------------


def _format_estimate_json(estimate: EstimateResult) -> str:
    """Return the cost estimate as structured JSON for machine consumption.

    Args:
        estimate: An EstimateResult instance from the estimation module.

    Returns:
        JSON string containing the estimate fields.
    """
    result: dict[str, object] = {
        "model": estimate.model,
        "task_count": estimate.task_count,
        "cost_low": estimate.cost_low,
        "cost_high": estimate.cost_high,
        "cost_avg": estimate.cost_avg,
        "historical_runs": estimate.historical_runs,
        "confidence": estimate.confidence,
    }

    return json.dumps(result, indent=2)


def _render_estimate_table(estimate: EstimateResult) -> None:
    """Render the cost estimate as a Rich table.

    Args:
        estimate: An EstimateResult instance from the estimation module.
    """
    from rich import box
    from rich.table import Table

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect[/bold {ARCHITECT_GREEN}]  "
        "[dim]Pre-run Cost Estimate[/dim]"
    )
    console.print()

    # Confidence colour
    conf = estimate.confidence
    if conf == "high":
        conf_style = f"[{ARCHITECT_GREEN}]{conf}[/{ARCHITECT_GREEN}]"
    elif conf == "medium":
        conf_style = "[yellow]medium[/yellow]"
    else:
        conf_style = "[red]low[/red]"

    # Data table
    table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
    table.add_column("Model", no_wrap=False)
    table.add_column("Tasks", justify="right", width=6)
    table.add_column("Avg Cost", justify="right", width=9)
    table.add_column("Low", justify="right", width=9)
    table.add_column("High", justify="right", width=9)
    table.add_column("Runs", justify="right", width=5)
    table.add_column("Confidence", justify="center", width=10)

    table.add_row(
        estimate.model,
        str(estimate.task_count),
        _fmt_cost(estimate.cost_avg),
        _fmt_cost(estimate.cost_low),
        _fmt_cost(estimate.cost_high),
        str(estimate.historical_runs),
        conf_style,
    )

    console.print(table)

    # Context note
    if estimate.historical_runs == 0:
        console.print()
        console.print(
            "[dim]Note: No historical data available — estimate based on "
            "model pricing table only.[/dim]"
        )
    elif estimate.confidence == "low":
        console.print()
        console.print("[dim]Note: Limited historical data — estimate may vary significantly.[/dim]")

    console.print()


# ---------------------------------------------------------------------------
# Estimate command
# ---------------------------------------------------------------------------


@main.command(name="estimate")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Project directory (default: current working directory)",
)
@click.option(
    "--model",
    "model_override",
    default=None,
    help="Override model for estimation (default: config or most recent ledger model)",
)
@click.option(
    "--tasks",
    "task_count_override",
    type=click.INT,
    default=None,
    help="Override task count for estimation (default: historical average or 5)",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def estimate_cmd(
    project: Path | None,
    model_override: str | None,
    task_count_override: int | None,
    as_json: bool,
) -> None:
    """Estimate the cost of an upcoming Architect run.

    Uses historical token ledger data to predict how much a future run will
    cost based on the selected model and expected number of tasks.  Falls
    back to model pricing tables when no historical data exists.
    """
    from the_architect.core.estimate_cost import (
        estimate_run_cost,
        get_task_count_stats,
    )

    _setup_loguru()

    proj = (project or Path.cwd()).resolve()
    config = load_config(proj)
    ledger = load_ledger(proj)

    # Determine model: --model > standalone_mode > most recent ledger model > default
    model: str = model_override or ""
    if not model and config.standalone_mode:
        model = config.standalone_mode
    if not model and ledger.records:
        # Use the most recent model from the ledger
        last_run = ledger.records[-1]
        if last_run.model_breakdown:
            model = last_run.model_breakdown[0].model
    if not model:
        model = "anthropic/claude-sonnet-4-20250514"

    # Determine task count: --tasks > historical average > default 5
    task_count: int = task_count_override if task_count_override is not None else 0
    if task_count == 0:
        stats = get_task_count_stats(ledger)
        if stats.run_count > 0:
            task_count = max(1, round(stats.avg_tasks))
        else:
            task_count = 5

    # Run estimation
    result: EstimateResult = estimate_run_cost(ledger, model, task_count)

    if as_json:
        click.echo(_format_estimate_json(result))
        return

    _render_estimate_table(result)


@main.command(name="budget")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Project directory (default: current working directory)",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def budget_cmd(project: Path | None, as_json: bool) -> None:
    """Show token budget configuration and historical usage from the ledger.

    Displays configured budget limits, historical token usage totals,
    per-model cost breakdown, and average tokens per task and per run.
    Use this before starting a run to check your spending patterns.
    """
    _setup_loguru()

    proj = (project or Path.cwd()).resolve()
    config = load_config(proj)
    ledger = load_ledger(proj)

    if as_json:
        click.echo(_format_budget_json(config, ledger))
        return

    _render_budget_table(config, ledger)


# ---------------------------------------------------------------------------
# Cost analytics command
# ---------------------------------------------------------------------------


def _format_cost_json(analytics: CostAnalytics) -> str:
    """Return the cost analytics as structured JSON for machine consumption.

    Args:
        analytics: A CostAnalytics instance from the aggregation module.

    Returns:
        JSON string containing total cost, tokens, run count, model breakdown,
        top expensive tasks, and daily spending.
    """
    model_breakdown_list: list[dict[str, object]] = []
    for model_name, summary in analytics.model_breakdown.items():
        model_breakdown_list.append(
            {
                "model": model_name,
                "total_cost": summary.total_cost,
                "total_tokens": summary.total_tokens,
                "run_count": summary.run_count,
                "avg_cost_per_run": summary.avg_cost_per_run,
            }
        )
    model_breakdown_list.sort(key=lambda x: x["total_cost"], reverse=True)  # type: ignore[arg-type, return-value]

    top_tasks_list: list[dict[str, object]] = []
    for task in analytics.top_expensive_tasks:
        top_tasks_list.append(
            {
                "run_id": task.run_id,
                "task_id": task.task_id,
                "title": task.title,
                "cost_estimate": task.cost_estimate,
                "model": task.model,
                "tokens": task.tokens,
            }
        )

    daily_list: list[dict[str, object]] = []
    for entry in analytics.daily_spending:
        daily_list.append(
            {
                "date": entry.date,
                "cost": entry.cost,
                "tokens": entry.tokens,
                "runs": entry.runs,
            }
        )

    result: dict[str, object] = {
        "total_cost": analytics.total_cost,
        "total_tokens": analytics.total_tokens,
        "run_count": analytics.run_count,
        "model_breakdown": model_breakdown_list,
        "top_expensive_tasks": top_tasks_list,
        "daily_spending": daily_list,
    }

    return json.dumps(result, indent=2)


def _render_cost_table(
    analytics: CostAnalytics,
    since: str | None = None,
    until: str | None = None,
    model: str | None = None,
) -> None:
    """Render the cost analytics as Rich tables.

    Args:
        analytics: A CostAnalytics instance from the aggregation module.
        since: Inclusive start date filter (for display context).
        until: Exclusive end date filter (for display context).
        model: Model filter (for display context).
    """
    from rich import box
    from rich.table import Table

    from the_architect.core.success import _fmt_tokens

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect[/bold {ARCHITECT_GREEN}]  "
        "[dim]Cross-run Cost Analytics[/dim]"
    )
    console.print()

    # ── Filter context ───────────────────────────────────────────────────
    filters: list[str] = []
    if since:
        filters.append(f"since {since}")
    if until:
        filters.append(f"until {until}")
    if model:
        filters.append(f"model {model}")
    if filters:
        console.print(f"[dim]Filters: {', '.join(filters)}[/dim]")
        console.print()

    # ── Summary section ──────────────────────────────────────────────────
    console.print("[bold]Summary[/bold]")
    console.print(f"  Total cost:    [bold]{_fmt_cost(analytics.total_cost)}[/bold]")
    console.print(f"  Total tokens:  {_fmt_tokens(analytics.total_tokens)}")
    console.print(f"  Runs:          {analytics.run_count}")
    console.print()

    # ── Model breakdown ──────────────────────────────────────────────────
    if analytics.model_breakdown:
        console.print("[bold]Model Breakdown[/bold]")
        table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
        table.add_column("Model", no_wrap=False)
        table.add_column("Cost", justify="right", width=9)
        table.add_column("Tokens", justify="right", width=10)
        table.add_column("Runs", justify="right", width=5)
        table.add_column("Avg/Run", justify="right", width=9)

        sorted_models = sorted(
            analytics.model_breakdown.items(),
            key=lambda item: item[1].total_cost,
            reverse=True,
        )
        for model_name, summary in sorted_models:
            short_model = model_name
            for prefix in ("anthropic/", "openai/", "google/"):
                if short_model.startswith(prefix):
                    short_model = short_model[len(prefix) :]
                    break
            table.add_row(
                short_model,
                _fmt_cost(summary.total_cost),
                _fmt_tokens(summary.total_tokens),
                str(summary.run_count),
                _fmt_cost(summary.avg_cost_per_run),
            )
        console.print(table)
        console.print()

    # ── Top expensive tasks ──────────────────────────────────────────────
    if analytics.top_expensive_tasks:
        console.print("[bold]Top Expensive Tasks[/bold]")
        table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
        table.add_column("Task", no_wrap=True, width=8)
        table.add_column("Title", no_wrap=False)
        table.add_column("Model", no_wrap=False)
        table.add_column("Cost", justify="right", width=9)
        table.add_column("Tokens", justify="right", width=10)

        for task in analytics.top_expensive_tasks:
            short_model = task.model
            for prefix in ("anthropic/", "openai/", "google/"):
                if short_model.startswith(prefix):
                    short_model = short_model[len(prefix) :]
                    break
            title = task.title or task.task_id
            table.add_row(
                task.task_id,
                title,
                short_model,
                _fmt_cost(task.cost_estimate),
                _fmt_tokens(task.tokens),
            )
        console.print(table)
        console.print()

    # ── Daily spending ───────────────────────────────────────────────────
    if analytics.daily_spending:
        console.print("[bold]Daily Spending[/bold]")
        table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
        table.add_column("Date", no_wrap=True, width=12)
        table.add_column("Cost", justify="right", width=9)
        table.add_column("Tokens", justify="right", width=10)
        table.add_column("Runs", justify="right", width=5)

        for entry in analytics.daily_spending:
            table.add_row(
                entry.date,
                _fmt_cost(entry.cost),
                _fmt_tokens(entry.tokens),
                str(entry.runs),
            )
        console.print(table)
        console.print()


@main.command(name="cost")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Project directory (default: current working directory)",
)
@click.option(
    "--since",
    "-s",
    default=None,
    help="Inclusive start date filter (ISO format, e.g. 2026-05-01)",
)
@click.option(
    "--until",
    "-u",
    default=None,
    help="Exclusive end date filter (ISO format, e.g. 2026-06-01)",
)
@click.option(
    "--model",
    "-m",
    default=None,
    help="Filter by model name (e.g. claude-sonnet-4)",
)
@click.option(
    "--top",
    "-n",
    type=click.INT,
    default=10,
    help="Number of top expensive tasks to show (default: 10)",
)
@click.option(
    "--tui",
    "use_tui",
    is_flag=True,
    help="Render cost analytics in the Textual TUI",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def cost_cmd(
    project: Path | None,
    since: str | None,
    until: str | None,
    model: str | None,
    top: int,
    use_tui: bool,
    as_json: bool,
) -> None:
    """Show cross-run cost analytics from the token ledger.

    Aggregates historical run data into total spending, per-model breakdown,
    top expensive tasks, and daily spending trends.  Use --since/--until to
    narrow the date range, --model to filter by a specific model.
    """
    from the_architect.core.cost_analytics import aggregate_costs

    _setup_loguru()

    proj = (project or Path.cwd()).resolve()

    # Mutual exclusion: --tui cannot be combined with filter flags
    if use_tui and (as_json or since or until or model):
        console.print(
            "[red]Error: --tui cannot be combined with --json, --since, --until, or --model.[/red]"
        )
        raise SystemExit(1)

    if use_tui or _tui_mode_enabled():
        try:
            from the_architect.tui.screens import run_cost_screen

            run_cost_screen(project=proj)
            return
        except Exception as exc:
            logger.debug(f"TUI cost screen failed, falling back to rich: {exc!r}")

    ledger = load_ledger(proj)

    analytics: CostAnalytics = aggregate_costs(
        ledger,
        since=since,
        until=until,
        model=model,
        top_n=top,
    )

    if as_json:
        click.echo(_format_cost_json(analytics))
        return

    if analytics.run_count == 0:
        console.print()
        console.print("[dim]No cost data available.[/dim]")
        console.print()
        return

    _render_cost_table(analytics, since=since, until=until, model=model)


@main.command(name="init")
@click.option(
    "--project",
    "-p",
    type=click.Path(file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Directory to initialise (default: current directory)",
)
@click.option(
    "--force",
    is_flag=True,
    help="Overwrite existing files",
)
def init_cmd(project: Path | None, force: bool) -> None:
    """Initialise a project directory for The Architect.

    Creates:
    - AGENTS.md  — project rules for the build agent (edit this!)
    - architect.toml  — configuration with commented defaults

    Safe to run in existing projects — will not overwrite unless --force.
    """
    _setup_loguru()
    proj = (project or Path.cwd()).resolve()
    proj.mkdir(parents=True, exist_ok=True)

    created: list[str] = []
    skipped: list[str] = []

    # ── AGENTS.md ────────────────────────────────────────────────────────
    agents_md = proj / "AGENTS.md"
    if agents_md.exists() and not force:
        skipped.append("AGENTS.md")
    else:
        agents_md.write_text(
            "# Project Rules\n\n"
            "> The Architect reads this file before every task.\n"
            "> Add your project's conventions, constraints, and architecture here.\n\n"
            "## Stack\n\n"
            "<!-- e.g. Python 3.12, FastAPI, PostgreSQL -->\n\n"
            "## Conventions\n\n"
            "<!-- e.g. Use loguru for logging. No print(). Type hints on all functions. -->\n\n"
            "## Constraints\n\n"
            "<!-- e.g. Never modify files outside src/. All tests must pass before Done. -->\n\n"
            "## Architecture\n\n"
            "<!-- Key decisions and folder structure -->\n",
            encoding="utf-8",
        )
        created.append("AGENTS.md")

    # ── architect.toml ───────────────────────────────────────────────────
    toml_path = proj / "architect.toml"
    if toml_path.exists() and not force:
        skipped.append("architect.toml")
    else:
        toml_path.write_text(
            "# The Architect configuration\n"
            "# Run 'architect config' to see all options.\n\n"
            "[architect]\n"
            "# max_retries = 3            # retry attempts per task\n"
            "# retry_pause = 30           # seconds between retries\n"
            "# pause_between_tasks = 10   # seconds between tasks\n"
            "# retrospective_rounds = 1   # reviewer rounds after execution\n"
            "# carry_context = true       # inject previous attempt context on retry\n"
            "# token_budget_per_hour = 0  # max tokens/hour, 0 = unlimited\n",
            encoding="utf-8",
        )
        created.append("architect.toml")

    console.print()
    if created:
        for name in created:
            console.print(f"[{ARCHITECT_GREEN}]✓[/{ARCHITECT_GREEN}]  Created  [bold]{name}[/bold]")
    if skipped:
        for name in skipped:
            console.print(
                f"[dim]–  Skipped  {name}  (already exists — use --force to overwrite)[/dim]"
            )

    console.print()
    if created:
        console.print(
            f"[bold {ARCHITECT_GREEN}]Project initialised.[/bold {ARCHITECT_GREEN}]  "
            "Next: edit [bold]AGENTS.md[/bold] with your project rules, then run "
            f"[bold {ARCHITECT_GREEN}]architect --plan[/bold {ARCHITECT_GREEN}]"
        )
    else:
        console.print("[dim]Nothing to do — all files already exist.[/dim]")
    console.print()


@main.command(name="logs")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
)
@click.option(
    "--task",
    "-t",
    default="",
    metavar="PREFIX",
    help="Show logs for a specific task prefix (e.g. T01)",
)
@click.option(
    "--tail",
    "-n",
    default=50,
    show_default=True,
    metavar="N",
    help="Show last N lines of each log file",
)
@click.option(
    "--all",
    "show_all",
    is_flag=True,
    help="Show full log content (overrides --tail)",
)
@click.option(
    "--tui",
    "use_tui",
    is_flag=True,
    help="Render logs in the Textual TUI (paneled file picker + content)",
)
def logs_cmd(
    project: Path | None,
    task: str,
    tail: int,
    show_all: bool,
    use_tui: bool,
) -> None:
    """Show execution logs.

    Without --task: lists all available log files.
    With --task T01: shows the log for that task.

    \b
    Examples:
      architect logs               # list all log files
      architect logs --task T01    # show T01 log (last 50 lines)
      architect logs --task T01 --tail 100
      architect logs --task T01 --all
    """
    _setup_loguru()
    proj = (project or Path.cwd()).resolve()

    if use_tui or _tui_mode_enabled():
        try:
            from the_architect.tui.screens import run_logs_screen

            # `--all` overrides tail in the CLI view; the TUI paneled view
            # uses tail=0 to mean "no cap".
            effective_tail = 0 if show_all else tail
            run_logs_screen(project=proj, task_prefix=task, tail=effective_tail)
            return
        except Exception as exc:
            logger.debug(f"TUI logs screen failed, falling back to rich: {exc!r}")

    config = load_config(proj)
    log_dir = config.log_dir  # already resolved as absolute path by load_config

    if not log_dir.exists():
        console.print("[dim]No log directory found. Run architect to generate logs.[/dim]")
        return

    log_files = sorted(log_dir.glob("*.log"), key=lambda f: f.stat().st_mtime, reverse=True)

    if not log_files:
        console.print("[dim]No log files found.[/dim]")
        return

    # ── Show specific task log ───────────────────────────────────────────
    if task:
        prefix = task.upper()
        matches = [lf for lf in log_files if lf.name.upper().startswith(prefix)]
        if not matches:
            console.print(f"[red]No log found for task {prefix}.[/red]")
            _total = len(log_files)
            _names = ", ".join(lf.stem for lf in log_files[:10])
            _suffix = f" (+{_total - 10} more)" if _total > 10 else ""
            console.print(f"[dim]Available logs: {_names}{_suffix}[/dim]")
            raise SystemExit(1)

        for log_file in matches:
            console.print()
            console.print(f"[bold dim]── {log_file.name} ──[/bold dim]")
            console.print()
            try:
                raw = log_file.read_text(encoding="utf-8", errors="replace")
                # Strip JSON lines — show only human-readable text events
                lines: list[str] = []
                for line in raw.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    # Try to parse as JSON and extract display text
                    try:
                        import json as _json2

                        event = _json2.loads(line)
                        etype = event.get("type", "")
                        part = event.get("part", {})
                        if etype == "text" and isinstance(part, dict):
                            t = (part.get("text") or "").strip()
                            if t:
                                lines.extend(t.split("\n"))
                        elif etype == "error":
                            msg = str(event.get("message", event.get("error", ""))).strip()
                            if msg:
                                lines.append(f"[ERROR] {msg}")
                    except Exception:
                        # Not JSON — raw log line
                        lines.append(line)

                if not show_all:
                    lines = lines[-tail:]

                for ln in lines:
                    console.print(ln)
            except OSError as e:
                console.print(f"[red]Could not read {log_file.name}: {e}[/red]")
        return

    # ── List all log files ───────────────────────────────────────────────
    from rich import box
    from rich.table import Table

    console.print()
    table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
    table.add_column("Log file")
    table.add_column("Size", width=10)
    table.add_column("Modified", width=20)

    import datetime as _dt

    for lf in log_files:
        stat = lf.stat()
        size = f"{stat.st_size // 1024} KB" if stat.st_size >= 1024 else f"{stat.st_size} B"
        mtime = _dt.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
        table.add_row(lf.name, size, mtime)

    console.print(table)
    console.print("[dim]Use [bold]architect logs --task T01[/bold] to view a specific log.[/dim]")
    console.print()


@main.command(name="config")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
)
@click.option(
    "--set",
    "set_values",
    multiple=True,
    metavar="KEY=VALUE",
    help="Set a config value, e.g. --set max_retries=5 --set carry_context=false",
)
@click.option(
    "--tui",
    "use_tui",
    is_flag=True,
    help="Show the configuration in a Textual viewer (read-only, scrollable)",
)
def config_cmd(project: Path | None, set_values: tuple[str, ...], use_tui: bool) -> None:
    """Show or update The Architect configuration.

    Without --set: shows the current configuration and its source
    (architect.toml or built-in default).

    With --set KEY=VALUE: updates architect.toml with the given values.
    Multiple --set flags are allowed.

    \b
    Configurable options:
      max_retries                  Maximum retry attempts per task (default: 3)
      retry_pause                  Seconds to wait between retries (default: 30)
      pause_between_tasks          Seconds to wait between tasks (default: 10)
      retrospective_rounds         Retrospective review rounds (default: 1)
      retry_model_2                Fallback model for attempt 2 (default: "")
      retry_model_3                Fallback model for attempt 3 (default: "")
      standalone_mode              Bypass opencode.json, use this model (default: "")
      execution_agent              Agent name for task execution (default: "")
      carry_context                Inject previous attempt context on retry (default: true)
      retry_prompt_mode            Retry prompt style: focused or same (default: focused)
      free_mode                    Use free OpenRouter models, rotate on rate limit (default: false)
      integrity                    Snapshot existing files before edits and treat
                                   leftovers as corruption signals (default: true)
      token_budget_per_hour        Max tokens per hour, 0=unlimited (default: 0)
       token_budget_per_run         Max tokens per run, 0=unlimited (default: 0)
       task_timeout                 Max wall-clock seconds per task, 0=unlimited (default: 0)

    \b
    Circuit breaker options:
      circuit_no_progress_threshold  Attempts with no file writes before opening (default: 3)
      circuit_same_error_threshold   Attempts with same error before opening (default: 3)
      circuit_token_decline_pct      Token decline % that contributes to opening (default: 60)
      circuit_cooldown_minutes       Minutes before HALF_OPEN retry after opening (default: 30)
      circuit_enable_replan          Replan failing tasks via architect agent (default: true)
      cooldown_detection             Detect provider rate-limits and wait 1h (default: true)

    \b
    Examples:
      architect config
      architect config --set max_retries=5
      architect config --set carry_context=false --set retry_prompt_mode=same
      architect config --set retry_model_2="openrouter/google/gemini-2.5-pro"
      architect config --set token_budget_per_hour=500000
       architect config --set token_budget_per_run=1000000
       architect config --set task_timeout=300
      architect config --set circuit_no_progress_threshold=5
    """
    _setup_loguru()
    proj = (project or Path.cwd()).resolve()
    config = load_config(proj)
    toml_path = proj / "architect.toml"

    if set_values:
        # Parse KEY=VALUE pairs
        updates: dict[str, object] = {}
        for item in set_values:
            if "=" not in item:
                console.print(f"[red]Invalid format '{item}' — use KEY=VALUE[/red]")
                raise SystemExit(1)
            key, _, raw_val = item.partition("=")
            key = key.strip()
            raw_val = raw_val.strip()

            # Type coercion — infer from current field type
            field = ArchitectConfig.model_fields.get(key)
            if field is None:
                console.print(f"[red]Unknown config key: '{key}'[/red]")
                console.print(
                    "[dim]Run [bold]architect config[/bold] to see available options.[/dim]"
                )
                raise SystemExit(1)

            # Coerce to the right Python type
            annotation = field.annotation
            try:
                if isinstance(annotation, type) and annotation is bool:
                    if raw_val.lower() in ("true", "1", "yes"):
                        updates[key] = True
                    elif raw_val.lower() in ("false", "0", "no"):
                        updates[key] = False
                    else:
                        raise ValueError(f"Expected true/false for '{key}'")
                elif isinstance(annotation, type) and annotation is int:
                    updates[key] = int(raw_val)
                else:
                    updates[key] = raw_val
            except ValueError as e:
                console.print(f"[red]Invalid value for '{key}': '{raw_val}' — {e}[/red]")
                raise SystemExit(1)

        try:
            written = write_config(proj, updates)
        except (ValueError, TypeError) as e:
            console.print(f"[red]Config error: {e}[/red]")
            raise SystemExit(1)

        console.print(f"[#7cc800]✓ Saved to {written.relative_to(proj)}[/#7cc800]")
        for key, val in updates.items():
            console.print(f"  [dim]{key}[/dim] = [bold]{val}[/bold]")
        return

    # Show current config
    has_toml = toml_path.exists()

    # TUI fast-path — Phase 3. When --tui is passed, render the config
    # in a scrollable Textual viewer instead of dumping rich text.
    if use_tui:
        try:
            from the_architect.tui.screens import run_config_screen

            run_config_screen(config=config, toml_path=toml_path, has_toml=has_toml)
            return
        except Exception as exc:
            logger.debug(f"TUI config viewer failed, falling back to rich output: {exc!r}")

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect config[/bold {ARCHITECT_GREEN}]  "
        f"[grey62]{'architect.toml' if has_toml else 'defaults only'}[/grey62]"
    )
    console.print()

    # Fields to display — exclude internal path fields
    display_fields = [
        ("max_retries", config.max_retries),
        ("retry_pause", config.retry_pause),
        ("pause_between_tasks", config.pause_between_tasks),
        ("retrospective_rounds", config.retrospective_rounds),
        ("retry_model_2", config.retry_model_2 or "[dim](default)[/dim]"),
        ("retry_model_3", config.retry_model_3 or "[dim](default)[/dim]"),
        ("standalone_mode", config.standalone_mode or "[dim](not set)[/dim]"),
        ("execution_agent", config.execution_agent or "[dim](not set)[/dim]"),
        ("carry_context", config.carry_context),
        ("retry_prompt_mode", config.retry_prompt_mode),
        ("free_mode", config.free_mode),
        ("persistent", config.persistent),
        ("token_budget_per_hour", config.token_budget_per_hour),
        ("token_budget_per_run", config.token_budget_per_run),
        ("task_timeout", config.task_timeout),
        ("integrity", config.integrity),
    ]

    for key, val in display_fields:
        console.print(f"  [grey62]{key:<22}[/grey62] {val}")

    console.print()
    if has_toml:
        console.print(f"[dim]Config file: {toml_path}[/dim]")
    else:
        console.print("[dim]No architect.toml found — using built-in defaults.[/dim]")
        console.print("[dim]Run [bold]architect config --set KEY=VALUE[/bold] to create one.[/dim]")
    console.print()


def _format_circuit_json(
    cb: CircuitBreaker,
    project_path: Path,
    all_task_prefixes: set[str],
) -> str:
    """Return the circuit breaker state as structured JSON.

    Args:
        cb: The loaded :class:`~the_architect.core.circuit.CircuitBreaker`.
        project_path: Resolved project root path.
        all_task_prefixes: Set of all task prefixes discovered in the tasks directory.

    Returns:
        JSON string with tasks array, project path, and summary counts.
    """
    from the_architect.core.circuit import CircuitState

    states = cb.all_states()

    # Build task entries — include tasks with no circuit state as CLOSED
    tasks: list[dict[str, object]] = []
    for task_id in sorted({*states.keys(), *all_task_prefixes}):
        state = states.get(task_id)
        if state is None:
            # Task has no circuit state — implicitly CLOSED
            tasks.append(
                {
                    "task_id": task_id,
                    "state": CircuitState.CLOSED,
                    "consecutive_no_progress": 0,
                    "consecutive_same_error": 0,
                    "recovery_action": None,
                    "opened_at": None,
                }
            )
        else:
            tasks.append(
                {
                    "task_id": task_id,
                    "state": state.state,
                    "consecutive_no_progress": state.consecutive_no_progress,
                    "consecutive_same_error": state.consecutive_same_error,
                    "recovery_action": state.recovery_action.value
                    if state.recovery_action
                    else None,
                    "opened_at": state.opened_at,
                }
            )

    # Summary counts
    state_counts: dict[str, int] = {}
    for entry in tasks:
        s = str(entry["state"])
        state_counts[s] = state_counts.get(s, 0) + 1

    result: dict[str, object] = {
        "project": str(project_path),
        "tasks": tasks,
        "summary": {
            "total": len(tasks),
            "closed": state_counts.get(CircuitState.CLOSED, 0),
            "open": state_counts.get(CircuitState.OPEN, 0),
            "half_open": state_counts.get(CircuitState.HALF_OPEN, 0),
        },
    }

    return json.dumps(result, indent=2)


@main.command(name="circuit")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
)
@click.option(
    "--reset",
    "reset_task",
    default="",
    metavar="TASK_ID",
    help="Reset a specific task's circuit state to CLOSED (e.g. --reset T04)",
)
@click.option(
    "--tui",
    "use_tui",
    is_flag=True,
    help="Render the circuit inspector in the Textual TUI",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def circuit_cmd(project: Path | None, reset_task: str, use_tui: bool, as_json: bool) -> None:
    """Show or reset circuit breaker state for all tasks.

    Without --reset: shows the current circuit state for every tracked task,
    including which thresholds are elevated and the recovery action if OPEN.

    With --reset TASK_ID: manually resets that task's circuit state to CLOSED
    with zeroed counters.  Use this after fixing the underlying problem
    (e.g. installing a missing dependency) so The Architect can retry without
    waiting for the cooldown period.

    \b
    Examples:
      architect circuit
      architect circuit --reset T04
    """
    _setup_loguru()

    # Mutual exclusion: --json cannot be combined with --tui or --reset
    if as_json and use_tui:
        console.print("[red]Error: --json and --tui are mutually exclusive.[/red]")
        raise SystemExit(1)
    if as_json and reset_task:
        console.print("[red]Error: --json and --reset are mutually exclusive.[/red]")
        raise SystemExit(1)

    from datetime import datetime

    from rich import box
    from rich.table import Table

    from the_architect.core.circuit import CircuitState, load_circuit_state

    proj = (project or Path.cwd()).resolve()
    config = load_config(proj)

    cb = load_circuit_state(proj, config)

    if as_json:
        # Also gather tasks from the tasks directory for tasks with no circuit state
        tasks_dir = proj / config.tasks_dir.name
        all_tasks = discover_tasks(tasks_dir)
        all_task_prefixes = {t.prefix for t in all_tasks}
        click.echo(_format_circuit_json(cb, proj, all_task_prefixes))
        return

    if reset_task:
        # Normalise prefix format (accept "t04" or "T04")
        task_id = reset_task.upper()
        cb.reset_task(task_id)
        console.print(f"[#7cc800]✓ Circuit state for {task_id} reset to CLOSED.[/#7cc800]")
        return

    if use_tui or _tui_mode_enabled():
        try:
            from the_architect.tui.screens import run_circuit_screen

            run_circuit_screen(project=proj)
            return
        except Exception as exc:
            logger.debug(f"TUI circuit screen failed, falling back to rich: {exc!r}")

    states = cb.all_states()

    # Also show tasks from the tasks directory that have no circuit state yet
    tasks_dir = proj / config.tasks_dir.name
    all_tasks = discover_tasks(tasks_dir)
    for t in all_tasks:
        if t.prefix not in states:
            states[t.prefix] = None  # type: ignore[assignment]

    if not states:
        console.print()
        console.print("[dim]No circuit state found — all tasks implicitly CLOSED.[/dim]")
        console.print("[dim]Run [bold]architect[/bold] to start task execution.[/dim]")
        return

    table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
    table.add_column("Task", width=8)
    table.add_column("State", width=12)
    table.add_column("No-prog", width=9)
    table.add_column("Same-err", width=10)
    table.add_column("Recovery", width=10)
    table.add_column("Opened", width=20)

    for task_id in sorted(states.keys()):
        state = states[task_id]

        if state is None:
            # Task exists but has no circuit state — implicitly CLOSED
            table.add_row(
                task_id,
                "[dim]CLOSED[/dim]",
                "[dim]0[/dim]",
                "[dim]0[/dim]",
                "[dim]—[/dim]",
                "[dim]—[/dim]",
            )
            continue

        if state.state == CircuitState.CLOSED:
            state_str = "[#7cc800]CLOSED[/#7cc800]"
        elif state.state == CircuitState.OPEN:
            state_str = "[red]OPEN[/red]"
        else:
            state_str = "[yellow]HALF_OPEN[/yellow]"

        no_prog = str(state.consecutive_no_progress)
        same_err = str(state.consecutive_same_error)
        recovery = str(state.recovery_action.value) if state.recovery_action else "—"

        opened_str = "—"
        if state.opened_at:
            try:
                then = datetime.fromisoformat(state.opened_at)
                now = datetime.now(tz=UTC)
                if then.tzinfo is None:
                    then = then.replace(tzinfo=UTC)
                elapsed = int((now - then).total_seconds())
                if elapsed < 60:
                    opened_str = f"{elapsed}s ago"
                elif elapsed < 3600:
                    opened_str = f"{elapsed // 60}m ago"
                else:
                    opened_str = f"{elapsed // 3600}h {(elapsed % 3600) // 60}m ago"
            except (ValueError, TypeError):
                logger.debug(f"Could not parse circuit opened_at timestamp: {state.opened_at!r}")
                opened_str = state.opened_at[:16] if state.opened_at else "—"

        table.add_row(task_id, state_str, no_prog, same_err, recovery, opened_str)

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect circuit breaker[/bold {ARCHITECT_GREEN}]  "
        f"[grey62]{proj}[/grey62]"
    )
    console.print()
    console.print(table)
    console.print(
        "[dim]Use [bold]architect circuit --reset TASK_ID[/bold] to manually reset a task.[/dim]"
    )
    console.print()


@main.command()
def version() -> None:
    """Show The Architect version."""
    click.echo(f"architect v{__full_version__}")


@main.command()
@click.option(
    "--live",
    is_flag=True,
    default=False,
    help="Run a live health probe against the detected provider.",
)
@click.option(
    "--live-timeout",
    type=float,
    default=30.0,
    show_default=True,
    help="Timeout in seconds for the live health probe.",
)
@click.option(
    "--project",
    is_flag=True,
    default=False,
    help="Run project-level health checks (lock file, tasks, baselines, circuits, ledger, presets)",
)
@click.option(
    "--project-path",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Project directory for --project checks (default: current working directory).",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    default=False,
    help="Output as machine-readable JSON.",
)
@click.option(
    "--tui",
    "use_tui",
    is_flag=True,
    help="Render project health checks in the Textual TUI (requires --project).",
)
def doctor_cmd(
    live: bool,
    live_timeout: float,
    project: bool,
    project_path: Path | None,
    as_json: bool,
    use_tui: bool,
) -> None:
    """Run static pre-flight diagnostics, optionally with a live provider health probe."""
    from rich.table import Table

    from the_architect.config import load_config

    # --json for environment diagnostics (without --project) or project health (with --project)
    effective_json = as_json

    # Mutual exclusion: --tui cannot be combined with --json
    if use_tui and as_json:
        console.print("[red]Error: --tui cannot be combined with --json.[/red]")
        raise SystemExit(1)

    # --tui requires --project (environment diagnostics remain CLI-only)
    if use_tui and not project:
        console.print(
            "[red]Error: --tui requires --project. Environment diagnostics are CLI-only.[/red]"
        )
        raise SystemExit(1)

    checks: list[tuple[str, str, str]] = []
    any_failed = False

    py_ok = sys.version_info >= (3, 11)
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    checks.append(("Python version", "✓" if py_ok else "✗", py_ver))
    if not py_ok:
        any_failed = True

    selected_provider: ArchitectProvider | None = None
    try:
        selected_provider = detect_provider("auto")
        checks.append(
            (
                "Selected provider",
                "✓",
                f"{selected_provider.display_name} ({selected_provider.name})",
            )
        )
    except ProviderNotFoundError:
        checks.append(("Selected provider", "✗", "No installed provider detected"))
        any_failed = True

    proj_root = Path.cwd()
    config_file = proj_root / "architect.toml"
    if config_file.exists():
        try:
            load_config(proj_root)
            checks.append(("Config", "✓", "architect.toml valid"))
        except Exception as e:
            checks.append(("Config", "✗", f"Invalid: {e}"))
            any_failed = True
    else:
        checks.append(("Config", "-", "No architect.toml (using defaults)"))

    provider_rows: list[tuple[str, str, str]] = []
    for provider in supported_providers():
        selected_marker = (
            " (selected)" if selected_provider and provider.name == selected_provider.name else ""
        )
        try:
            installed = provider.is_installed()
        except Exception as exc:
            provider_rows.append((provider.display_name, "✗", f"install check failed: {exc}"))
            if selected_provider and provider.name == selected_provider.name:
                any_failed = True
            continue

        if not installed:
            provider_rows.append(
                (
                    provider.display_name,
                    "-",
                    f"not installed; install with `{provider.install_hint()}`",
                )
            )
            continue

        version_text = provider.get_version()
        try:
            has_models = provider.has_any_models()
        except Exception as exc:
            has_models = False
            model_detail = f"model/config check failed: {exc}"
        else:
            model_detail = "models configured" if has_models else "no models/API key detected"

        update_msg = provider.check_update_available()
        detail_parts = [f"installed, {version_text}", model_detail]
        if update_msg:
            detail_parts.append(f"update: {update_msg}")
        detail = "; ".join(detail_parts) + selected_marker
        status = "✓" if has_models else "✗"
        provider_rows.append((provider.display_name, status, detail))
        if selected_provider and provider.name == selected_provider.name and not has_models:
            any_failed = True

    if not effective_json:
        table = Table(show_header=False, box=None, padding=(0, 1))
        table.add_column("Check", style="bold")
        table.add_column("Status", width=3)
        table.add_column("Detail")
        for name, status, detail in checks:
            table.add_row(name, status, detail)

        console.print()
        console.print("[bold]The Architect — Environment Diagnostics[/bold]")
        console.print()
        console.print(table)
        console.print()
        provider_table = Table(show_header=True, box=None, padding=(0, 1))
        provider_table.add_column("Provider", style="bold")
        provider_table.add_column("Status", width=3)
        provider_table.add_column("Detail")
        for name, status, detail in provider_rows:
            provider_table.add_row(name, status, detail)
        console.print("[bold]Providers[/bold]")
        console.print(provider_table)
        console.print()
    elif not project:
        # JSON output for environment diagnostics (non-project mode)
        click.echo(_format_env_diagnostics_json(checks, provider_rows))
        raise SystemExit(1 if any_failed else 0)

    # Project health checks (opt-in)
    project_failed = False
    if project:
        proj = (project_path or Path.cwd()).resolve()
        from the_architect.core.project_health import run_project_checks

        health_checks: list[HealthCheck] = run_project_checks(proj)

        if effective_json:
            click.echo(_format_project_health_json(proj, health_checks))
            has_fail = any(c.status == "fail" for c in health_checks)
            raise SystemExit(1 if has_fail else 0)

        if use_tui or _tui_mode_enabled():
            try:
                from the_architect.tui.screens import run_doctor_screen

                run_doctor_screen(project=proj)
                return
            except Exception as exc:
                console.print(f"[red]TUI launch failed: {exc}[/red]")
                raise SystemExit(1)

        console.print()
        console.print("[bold]Project Health[/bold]")
        proj_table = Table(show_header=True, box=None, padding=(0, 1))
        proj_table.add_column("Check", style="bold")
        proj_table.add_column("Status", width=3)
        proj_table.add_column("Detail")
        for check in health_checks:
            if check.status == "ok":
                symbol = "✓"
                style = "green"
            elif check.status == "warn":
                symbol = "⚠"
                style = "yellow"
            else:
                symbol = "✗"
                style = "red"
                project_failed = True
            proj_table.add_row(check.label, f"[{style}]{symbol}[/{style}]", check.detail)
        console.print(proj_table)
        console.print()

    # Live health probe (opt-in)
    live_failed = False
    if live and not effective_json:
        if selected_provider is None:
            console.print()
            console.print("[yellow]Live check skipped — no provider detected.[/yellow]")
        else:
            from the_architect.core.provider_health import (
                ProviderHealthError,
                check_provider_health,
            )

            console.print()
            console.print("[bold]Live Health Check[/bold]")
            console.print(
                f"Probing {selected_provider.display_name} (timeout {int(live_timeout)}s)..."
            )
            try:
                asyncio.run(
                    check_provider_health(
                        provider=selected_provider,
                        project_dir=Path.cwd(),
                        timeout_seconds=live_timeout,
                    )
                )
                console.print("[green]✓ API reachable — live check passed.[/green]")
            except ProviderHealthError as exc:
                console.print(f"[red]✗ Live check failed: {exc}[/red]")
                live_failed = True
            except Exception as exc:
                console.print(f"[red]✗ Live check error: {exc}[/red]")
                live_failed = True

    if any_failed:
        console.print()
        console.print("[red]Some required checks failed.[/red]")
        console.print(
            "[dim]Unavailable or unconfigured optional providers are hidden from provider "
            "selection lists.[/dim]"
        )
        raise SystemExit(1)
    if project_failed:
        console.print()
        console.print("[red]Some project health checks failed.[/red]")
        raise SystemExit(1)
    if live_failed:
        console.print()
        console.print("[red]Live health check failed.[/red]")
        raise SystemExit(1)
    console.print("[green]All checks passed.[/green]")
    raise SystemExit(0)


def _format_env_diagnostics_json(
    checks: list[tuple[str, str, str]],
    provider_rows: list[tuple[str, str, str]],
) -> str:
    """Return environment diagnostics as structured JSON.

    Args:
        checks: List of (name, status, detail) tuples for environment checks.
        provider_rows: List of (name, status, detail) tuples for provider checks.

    Returns:
        JSON string with checks array and providers array.
    """
    checks_out: list[dict[str, str]] = []
    for name, status, detail in checks:
        checks_out.append(
            {
                "check": name,
                "status": "pass" if status == "✓" else ("fail" if status == "✗" else "skip"),
                "detail": detail,
            }
        )

    providers_out: list[dict[str, str]] = []
    for name, status, detail in provider_rows:
        providers_out.append(
            {
                "provider": name,
                "status": "pass" if status == "✓" else ("fail" if status == "✗" else "skip"),
                "detail": detail,
            }
        )

    return json.dumps(
        {
            "checks": checks_out,
            "providers": providers_out,
        },
        indent=2,
    )


def _format_project_health_json(
    project: Path,
    checks: list[HealthCheck],
) -> str:
    """Return project health check results as structured JSON.

    Args:
        project: Resolved project root path.
        checks: List of HealthCheck results from run_project_checks().

    Returns:
        JSON string with checks array, project path, and summary counts.
    """
    summary: dict[str, int] = {"ok": 0, "warn": 0, "fail": 0}
    checks_out: list[dict[str, str]] = []
    for check in checks:
        summary[check.status] += 1
        checks_out.append(
            {
                "status": check.status,
                "label": check.label,
                "detail": check.detail,
            }
        )
    return json.dumps(
        {
            "checks": checks_out,
            "project": str(project),
            "summary": summary,
        },
        indent=2,
    )


def _format_diff_json(
    project: Path,
    task_filter: str | None = None,
) -> str:
    """Gather baseline diff data and return deterministic JSON string.

    Reads workspace baselines from ``.architect/baselines/``, runs
    :func:`baseline.detect_changes` for each, and returns structured
    JSON with a tasks array containing per-task created/modified/deleted
    file lists.

    Args:
        project: Resolved project root path.
        task_filter: Optional task prefix to filter to a single task.

    Returns:
        JSON string with ``tasks`` array and ``project`` path.
    """
    from the_architect.core.baseline import detect_changes, read_baseline

    baselines_dir = project / ".architect" / "baselines"

    tasks_result: list[dict[str, object]] = []

    if baselines_dir.is_dir():
        json_files = sorted(baselines_dir.glob("*.json"))
        for json_file in json_files:
            # Determine task prefix from baseline file
            file_stem = json_file.stem
            # If a task filter is set, only include matching baselines
            if task_filter and file_stem.upper() != task_filter.upper():
                continue

            try:
                baseline = read_baseline(json_file)
            except (OSError, ValueError) as exc:
                logger.warning(f"Diff: cannot read baseline {json_file.name}: {exc!r}")
                continue

            try:
                changes = detect_changes(baseline, project)
            except OSError as exc:
                logger.warning(f"Diff: cannot detect changes for {json_file.name}: {exc!r}")
                continue

            task_prefix = baseline.task_prefix or file_stem

            tasks_result.append(
                {
                    "task_id": task_prefix,
                    "created": sorted(changes.get("created", [])),
                    "modified": sorted(changes.get("modified", [])),
                    "deleted": sorted(changes.get("deleted", [])),
                }
            )

    result: dict[str, object] = {
        "project": str(project),
        "tasks": tasks_result,
    }

    return json.dumps(result, indent=2, sort_keys=True)


@main.command(name="diff")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
)
@click.option(
    "--task",
    "task_filter",
    default=None,
    metavar="TASK_ID",
    help="Filter to a specific task (e.g. --task T01)",
)
@click.option(
    "--tui",
    "use_tui",
    is_flag=True,
    help="Render the diff viewer in the Textual TUI",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def diff_cmd(project: Path | None, task_filter: str | None, use_tui: bool, as_json: bool) -> None:
    """Show what files were created, modified, or deleted per task.

    Reads workspace baselines from ``.architect/baselines/`` and compares
    against the current workspace to display per-task change summaries.
    Each task baseline is captured before task execution by the runner.

    \b
    Examples:
      architect diff
      architect diff --task T01
      architect diff --json
    """
    _setup_loguru()

    # Mutual exclusion: --json and --tui cannot be combined
    if as_json and use_tui:
        console.print("[red]Error: --json and --tui are mutually exclusive.[/red]")
        raise SystemExit(1)

    from rich import box
    from rich.table import Table

    from the_architect.core.baseline import detect_changes, read_baseline

    proj = (project or Path.cwd()).resolve()

    # ── JSON output path ─────────────────────────────────────────────────
    if as_json:
        click.echo(_format_diff_json(proj, task_filter))
        return

    if use_tui:
        from the_architect.tui.screens import run_diff_screen

        run_diff_screen(project=proj)
        return

    baselines_dir = proj / ".architect" / "baselines"

    if not baselines_dir.is_dir():
        console.print()
        console.print(f"[dim]No baseline data available in {baselines_dir}[/dim]")
        console.print("[dim]Baselines are captured automatically during task execution.[/dim]")
        return

    json_files = sorted(baselines_dir.glob("*.json"))
    if not json_files:
        console.print()
        console.print("[dim]No baseline data available.[/dim]")
        console.print("[dim]Baselines are captured automatically during task execution.[/dim]")
        return

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect — Diff[/bold {ARCHITECT_GREEN}]  [dim]{proj}[/dim]"
    )
    console.print()

    # Gather diff data
    diff_data: list[dict[str, object]] = []
    for json_file in json_files:
        file_stem = json_file.stem
        if task_filter and file_stem.upper() != task_filter.upper():
            continue

        try:
            baseline = read_baseline(json_file)
        except (OSError, ValueError) as exc:
            logger.warning(f"Diff: cannot read baseline {json_file.name}: {exc!r}")
            console.print(f"[red]✗ Cannot read baseline {json_file.name}: {exc}[/red]")
            continue

        try:
            changes = detect_changes(baseline, proj)
        except OSError as exc:
            logger.warning(f"Diff: cannot detect changes for {json_file.name}: {exc!r}")
            console.print(f"[red]✗ Cannot detect changes for {json_file.name}: {exc}[/red]")
            continue

        task_prefix = baseline.task_prefix or file_stem

        created = sorted(changes.get("created", []))
        modified = sorted(changes.get("modified", []))
        deleted = sorted(changes.get("deleted", []))

        diff_data.append(
            {
                "task_id": task_prefix,
                "created": created,
                "modified": modified,
                "deleted": deleted,
            }
        )

    if not diff_data:
        if task_filter:
            console.print(f"[dim]No baseline data found for task {task_filter}.[/dim]")
        else:
            console.print("[dim]No baseline data available.[/dim]")
        return

    for entry in diff_data:
        task_id = str(entry["task_id"])
        created = entry["created"]  # type: ignore[assignment]
        modified = entry["modified"]  # type: ignore[assignment]
        deleted = entry["deleted"]  # type: ignore[assignment]

        console.print(f"[bold]{task_id}[/bold]")
        console.print(
            f"  Created: [green]{len(created)}[/green]  |  "
            f"Modified: [yellow]{len(modified)}[/yellow]  |  "
            f"Deleted: [red]{len(deleted)}[/red]"
        )

        if created:
            table = Table(box=box.SIMPLE, padding=(0, 1), show_header=False)
            table.add_column("File", style="green")
            for f in created:
                table.add_row(f"  {f}")
            console.print(table)

        if modified:
            table = Table(box=box.SIMPLE, padding=(0, 1), show_header=False)
            table.add_column("File", style="yellow")
            for f in modified:
                table.add_row(f"  {f}")
            console.print(table)

        if deleted:
            table = Table(box=box.SIMPLE, padding=(0, 1), show_header=False)
            table.add_column("File", style="red")
            for f in deleted:
                table.add_row(f"  {f}")
            console.print(table)

        console.print()


# ---------------------------------------------------------------------------
# History command
# ---------------------------------------------------------------------------


def _render_history_tasks_table(records: list[LedgerRunRecord]) -> None:
    """Render per-task cost breakdown for run history as a Rich table.

    Args:
        records: List of ledger run records to display.
    """
    from rich import box
    from rich.table import Table

    from the_architect.core.success import _fmt_duration, _fmt_tokens

    if not records:
        console.print()
        console.print("[dim]No run history found.[/dim]")
        console.print("[dim]Run history is recorded automatically after each Architect run.[/dim]")
        console.print()
        return

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect — Run History "
        f"(Task Detail)[/bold {ARCHITECT_GREEN}]  "
        f"[dim]{len(records)} run(s)[/dim]"
    )
    console.print()

    table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
    table.add_column("Run", width=10, style="dim")
    table.add_column("Task", width=8, style="dim")
    table.add_column("Title", no_wrap=False)
    table.add_column("Tokens", justify="right", width=8, style="dim")
    table.add_column("Cost", justify="right", width=9, style="dim")
    table.add_column("Model", width=20, style="dim")
    table.add_column("Duration", justify="right", width=7, style="dim")
    table.add_column("Status", justify="center", width=8)

    for r in records:
        run_date = r.timestamp[:10] if r.timestamp else "—"
        task_breakdown = r.task_breakdown

        if not task_breakdown:
            table.add_row(
                run_date,
                "—",
                "[dim](no task data)[/dim]",
                "—",
                "—",
                "—",
                "—",
                "[dim]—[/dim]",
            )
            continue

        for idx, task in enumerate(task_breakdown):
            # First row of a run shows the date; subsequent rows are blank
            display_date = run_date if idx == 0 else ""

            # Truncate title to 40 characters
            title = task.title or "[dim](untitled)[/dim]"
            if len(title) > 40:
                title = title[:37].rstrip() + "…"

            # Status icon
            status_lower = task.status.lower() if task.status else ""
            if status_lower == "done":
                status_str = "[green]✓ done[/green]"
            elif status_lower == "failed":
                status_str = "[red]✗ failed[/red]"
            elif status_lower == "skipped":
                status_str = "[yellow]⊘ skipped[/yellow]"
            else:
                status_str = f"[dim]{task.status}[/dim]"

            task_tokens = task.input_tokens + task.output_tokens
            model_display = task.model or "—"
            # Shorten model name
            if len(model_display) > 20:
                model_display = "…" + model_display[-17:]

            table.add_row(
                display_date,
                task.task_id,
                title,
                _fmt_tokens(task_tokens) if task_tokens else "—",
                _fmt_cost(task.cost_estimate),
                model_display,
                _fmt_duration(task.duration_seconds) if task.duration_seconds else "—",
                status_str,
            )

    console.print(table)
    console.print()


def _format_history_tasks_json(records: list[LedgerRunRecord]) -> str:
    """Return per-task run history as structured JSON for machine consumption.

    Each run record includes the run-level metadata plus a ``task_breakdown``
    array of per-task cost records.

    Args:
        records: List of ledger run records to serialise.

    Returns:
        JSON string containing an array of run record objects with task_breakdown.
    """
    result: list[dict[str, object]] = []
    for r in records:
        result.append(
            {
                "run_id": r.run_id,
                "timestamp": r.timestamp,
                "goal_summary": r.goal_summary,
                "total_tokens": r.total_tokens,
                "total_cost_estimate": r.total_cost_estimate,
                "task_count": r.task_count,
                "outcome": r.outcome,
                "duration_seconds": r.duration_seconds,
                "task_breakdown": [t.model_dump() for t in r.task_breakdown],
            }
        )
    return json.dumps(result, indent=2)


def _format_history_json(records: list[LedgerRunRecord]) -> str:
    """Return the run history as a JSON array for machine consumption.

    Args:
        records: List of ledger run records to serialise.

    Returns:
        JSON string containing an array of run record objects.
    """
    result: list[dict[str, object]] = []
    for r in records:
        result.append(
            {
                "run_id": r.run_id,
                "timestamp": r.timestamp,
                "goal_summary": r.goal_summary,
                "total_tokens": r.total_tokens,
                "total_cost_estimate": r.total_cost_estimate,
                "task_count": r.task_count,
                "outcome": r.outcome,
                "duration_seconds": r.duration_seconds,
            }
        )
    return json.dumps(result, indent=2)


def _render_history_table(records: list[LedgerRunRecord]) -> None:
    """Render the run history as a Rich table.

    Args:
        records: List of ledger run records to display.
    """
    from rich import box
    from rich.table import Table

    from the_architect.core.success import _fmt_duration, _fmt_tokens

    if not records:
        console.print()
        console.print("[dim]No run history found.[/dim]")
        console.print("[dim]Run history is recorded automatically after each Architect run.[/dim]")
        console.print()
        return

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect — Run History[/bold {ARCHITECT_GREEN}]  "
        f"[dim]{len(records)} run(s)[/dim]"
    )
    console.print()

    table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
    table.add_column("Date", width=12, style="dim")
    table.add_column("Goal", no_wrap=False)
    table.add_column("Tasks", justify="right", width=5, style="dim")
    table.add_column("Tokens", justify="right", width=8, style="dim")
    table.add_column("Cost", justify="right", width=9, style="dim")
    table.add_column("Duration", justify="right", width=7, style="dim")
    table.add_column("Outcome", justify="center", width=8)

    for r in records:
        # Truncate goal to 60 characters for display
        goal = r.goal_summary[:60]
        if len(r.goal_summary) > 60:
            goal = goal.rstrip() + "…"

        # Outcome icon
        if r.outcome == "success":
            outcome_str = "[green]✓ success[/green]"
        else:
            outcome_str = "[red]✗ failure[/red]"

        table.add_row(
            r.timestamp[:10] if r.timestamp else "—",
            goal or "[dim](no goal)[/dim]",
            str(r.task_count),
            _fmt_tokens(r.total_tokens),
            _fmt_cost(r.total_cost_estimate),
            _fmt_duration(r.duration_seconds),
            outcome_str,
        )

    console.print(table)
    console.print()


@main.command(name="history")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Project directory (default: current working directory)",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
@click.option(
    "--since",
    default=None,
    metavar="DATE",
    help="Show only runs on or after DATE (e.g. 2026-05-01)",
)
@click.option(
    "--until",
    default=None,
    metavar="DATE",
    help="Show only runs before DATE (e.g. 2026-05-15)",
)
@click.option(
    "--outcome",
    default=None,
    metavar="STATUS",
    type=click.Choice(["success", "failure"], case_sensitive=False),
    help="Filter by run outcome (success or failure)",
)
@click.option(
    "--limit",
    type=int,
    default=None,
    metavar="N",
    help="Show only the most recent N runs",
)
@click.option(
    "--tui",
    "use_tui",
    is_flag=True,
    help="Open run history in the Textual TUI",
)
@click.option(
    "--tasks",
    "show_tasks",
    is_flag=True,
    help="Show per-task cost breakdown instead of run-level summary",
)
def history_cmd(
    project: Path | None,
    as_json: bool,
    since: str | None,
    until: str | None,
    outcome: str | None,
    limit: int | None,
    use_tui: bool,
    show_tasks: bool,
) -> None:
    """View past run history from the token ledger.

    Reads ``.architect/token_ledger.json`` and displays a table of previous
    Architect runs with goals, token counts, costs, task counts, outcomes,
    and durations.  Supports filtering by date range, outcome, and limit.
    Use ``--tasks`` to see per-task cost breakdown.
    """
    _setup_loguru()

    # Mutual exclusion: --json and --tui cannot be combined
    if as_json and use_tui:
        console.print("[red]Error: --json and --tui are mutually exclusive.[/red]")
        raise SystemExit(1)

    # Mutual exclusion: --tasks and --tui cannot be combined
    if show_tasks and use_tui:
        console.print("[red]Error: --tasks and --tui are mutually exclusive.[/red]")
        raise SystemExit(1)

    proj = (project or Path.cwd()).resolve()

    if use_tui:
        from the_architect.tui.screens import run_history_screen

        run_history_screen(project=proj)
        return

    ledger = load_ledger(proj)

    # Apply date filters
    if since or until:
        ledger = ledger.filter_by_date(start=since, end=until)

    # Apply outcome filter
    if outcome:
        outcome_lower = outcome.lower()
        filtered_records = [r for r in ledger.records if r.outcome.lower() == outcome_lower]
        ledger = TokenLedger(records=filtered_records)

    # Apply limit (most recent N)
    if limit and limit > 0:
        ledger = TokenLedger(records=ledger.records[-limit:])

    if show_tasks:
        if as_json:
            click.echo(_format_history_tasks_json(ledger.records))
            return
        _render_history_tasks_table(ledger.records)
        return

    if as_json:
        click.echo(_format_history_json(ledger.records))
        return

    _render_history_table(ledger.records)


# ---------------------------------------------------------------------------
# TUI standalone command
# ---------------------------------------------------------------------------


@main.command(name="tui")
def tui_cmd() -> None:
    """Launch the Textual TUI (phase 1 — standalone preview).

    Phase 1 boots the execution screen with a tabbed viewport
    (Live / Progress / Diagnostics / Settings) and a status footer. It is a preview
    surface — later phases wire it into planning, retrospective,
    reassessment, and interactive run/resume/config.
    """
    try:
        from the_architect.tui.app import ArchitectApp
    except ImportError as exc:  # pragma: no cover — textual is a hard dep
        click.echo(f"TUI unavailable: {exc}")
        return
    ArchitectApp().run()


@main.command(name="monitor")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
)
@click.option(
    "--tui",
    "use_tui",
    is_flag=True,
    help="Render the monitor in the Textual TUI (default)",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output current monitor state as machine-readable JSON",
)
@click.option(
    "--watch",
    "-w",
    "as_watch",
    is_flag=True,
    help="Continuously poll and output JSON (one object per line, NDJSON)",
)
@click.option(
    "--interval",
    "-i",
    type=int,
    default=5,
    help="Polling interval in seconds for --watch mode (default: 5)",
)
@click.option(
    "--follow",
    is_flag=True,
    help="Keep watching past terminal states (done/failed) in --watch mode",
)
def monitor_cmd(
    project: Path | None,
    use_tui: bool,
    as_json: bool,
    as_watch: bool,
    interval: int,
    follow: bool,
) -> None:
    """Open the live monitoring screen for a running Architect session.

    Reads ``.architect/monitor_state.json`` and displays live task / circuit /
    token state in the TUI monitor screen.  Works from any terminal —
    useful for reconnecting after detach (Esc → Detach from a persistent
    or Infinite Loop run) or checking progress from a second terminal.

    With ``--json``, outputs the current monitor state as clean JSON for
    scripted monitoring, external dashboards, and notification systems.

    With ``--watch`` (or ``-w``), continuously polls the monitor state at the
    configured interval and outputs one JSON object per line (NDJSON format).
    Auto-exits when the run reaches a terminal state (DONE/FAILED) unless
    ``--follow`` is used to keep watching.  Press Ctrl+C to stop.

    \b
    Examples:
      architect monitor
      architect monitor --json
      architect monitor --watch
      architect monitor --watch --interval 10
      architect monitor --watch --follow
    """
    _setup_loguru()

    # --watch implies --json
    effective_json = as_json or as_watch

    # Mutual exclusion: --json/--watch and --tui cannot be combined
    if effective_json and use_tui:
        console.print("[red]Error: --json/--watch and --tui are mutually exclusive.[/red]")
        raise SystemExit(1)

    proj = (project or Path.cwd()).resolve()

    # --watch mode: continuous JSON polling loop
    if as_watch:
        _monitor_watch_loop(proj, interval, follow)
        return

    # --json mode: one-shot JSON output of current monitor state
    if as_json:
        from the_architect.core.monitor_state import read_monitor_state

        state = read_monitor_state(proj)
        if state is None:
            # No state file — output an empty/neutral state
            state = {
                "project": str(proj),
                "status": "NO_STATE",
                "current_task_id": None,
                "current_task_title": None,
                "tasks": [],
            }
        click.echo(json.dumps(state, indent=2))
        return

    # Default: TUI monitor screen
    try:
        from the_architect.tui.screens import run_monitor_screen

        run_monitor_screen(project=proj)
    except Exception as exc:
        logger.debug(f"TUI monitor screen failed: {exc!r}")
        console.print("[red]Could not open monitor screen.[/red]")
        console.print(f"[dim]{exc}[/dim]")
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# Monitor watch loop helper
# ---------------------------------------------------------------------------


_TERMINAL_STATUSES = {"DONE", "FAILED"}


def _monitor_watch_loop(
    project_dir: Path,
    interval: int = 5,
    follow: bool = False,
) -> None:
    """Continuously poll monitor state and output NDJSON.

    Reads ``.architect/monitor_state.json`` at the given interval and prints
    one JSON object per line.  Exits cleanly on SIGINT (Ctrl+C) or when the
    run reaches a terminal state (DONE/FAILED) unless ``follow`` is True.

    Args:
        project_dir: The project root directory.
        interval: Polling interval in seconds.
        follow: If True, continue watching past terminal states.
    """
    from the_architect.core.monitor_state import read_monitor_state

    def _sigint_handler(signum: int, frame: object) -> None:
        """Handle SIGINT for clean exit from watch loop."""
        # Write a final newline to ensure the last JSON line is complete
        raise KeyboardInterrupt

    # Install signal handler for clean Ctrl+C exit.
    # Guarded: signal.signal() can fail in restricted environments
    # (e.g. non-main thread, some CI runners). SIGINT itself is
    # cross-platform (POSIX + Windows), but registration may not be.
    import signal

    try:
        signal.signal(signal.SIGINT, _sigint_handler)
    except (ValueError, OSError):
        pass

    try:
        while True:
            state = read_monitor_state(project_dir)
            if state is None:
                # No state file — output an empty/neutral state
                state = {
                    "project": str(project_dir),
                    "status": "NO_STATE",
                    "current_task_id": None,
                    "current_task_title": None,
                    "tasks": [],
                }
            click.echo(json.dumps(state))

            # Check for terminal status
            current_status = state.get("status", "")
            if current_status in _TERMINAL_STATUSES and not follow:
                # Print final state already output above — exit cleanly
                return

            # Wait for the next poll
            try:
                import time

                time.sleep(interval)
            except (KeyboardInterrupt, SystemExit):
                # Ctrl+C during sleep — exit cleanly
                return

    except KeyboardInterrupt:
        # Ctrl+C — exit cleanly without error
        pass


# ---------------------------------------------------------------------------
# Feedback command — user guidance between tasks
# ---------------------------------------------------------------------------


def _format_feedback_json(
    feedback_data: dict[str, object] | None,
    project: str,
) -> str:
    """Serialise feedback state to JSON.

    Args:
        feedback_data: Parsed feedback dict or ``None`` if no feedback.
        project: Resolved project path string.

    Returns:
        JSON string with feedback state.
    """
    return json.dumps(
        {
            "project": project,
            "feedback": feedback_data,
        },
        indent=2,
    )


# ---------------------------------------------------------------------------
# Rollback command
# ---------------------------------------------------------------------------


def _format_rollback_json(
    project: Path,
    plan: dict[str, Any],
    result: dict[str, Any] | None,
) -> str:
    """Format rollback data as deterministic JSON string.

    Args:
        project: Resolved project root path.
        plan: Dict with files_to_restore, files_to_delete, files_unchanged counts.
        result: Dict with restored_count, deleted_count, errors (or None for dry-run).

    Returns:
        JSON string with project, plan, and optional result.
    """
    output: dict[str, Any] = {
        "project": str(project),
        "plan": plan,
    }
    if result is not None:
        output["result"] = result
    return json.dumps(output, indent=2, sort_keys=True)


def _render_rollback_table(
    plan_dict: dict[str, Any],
    result_dict: dict[str, Any] | None,
    dry_run: bool,
) -> None:
    """Render the rollback plan (and result) as a Rich table.

    Args:
        plan_dict: Dict with restore_count, delete_count, unchanged_count,
            files_to_restore, files_to_delete keys.
        result_dict: Dict with restored_count, deleted_count, errors
            (None for dry-run preview).
        dry_run: Whether this is a dry-run preview.
    """
    from rich.table import Table

    table = Table(title="Rollback Plan")
    table.add_column("File", style="cyan")
    table.add_column("Action", style="bold")
    table.add_column("Status", style="green")

    # Restore rows
    restore_files: list[str] = plan_dict.get("files_to_restore", [])
    for rel_path in sorted(restore_files):
        status = "Would restore" if dry_run else "Restored"
        table.add_row(rel_path, "Restore", status)

    # Delete rows
    delete_files: list[str] = plan_dict.get("files_to_delete", [])
    for rel_path in sorted(delete_files):
        status = "Would delete" if dry_run else "Deleted"
        table.add_row(rel_path, "Delete", status)

    console.print()
    console.print(f"[bold {ARCHITECT_GREEN}]The Architect — Rollback[/bold {ARCHITECT_GREEN}]")
    console.print()
    console.print(table)
    console.print()

    # Summary
    restore_count: int = plan_dict.get("restore_count", 0)
    delete_count: int = plan_dict.get("delete_count", 0)
    unchanged_count: int = plan_dict.get("unchanged_count", 0)
    console.print(
        f"  Restore: [bold]{restore_count}[/bold] file(s)  "
        f"Delete: [bold]{delete_count}[/bold] file(s)  "
        f"Unchanged: [bold]{unchanged_count}[/bold] file(s)"
    )

    if result_dict:
        errors: list[dict[str, str]] = result_dict.get("errors", [])
        if errors:
            console.print()
            console.print("[red]Errors:[/red]")
            for err in errors:
                console.print(f"  [red]✗[/red] {err['path']}: {err['message']}")
        console.print()
        restored: int = result_dict["restored_count"]
        deleted: int = result_dict["deleted_count"]
        console.print(
            f"[green]Rollback complete.[/green] "
            f"Restored {restored}, "
            f"Deleted {deleted}, "
            f"Errors {len(errors)}."
        )
    console.print()


@main.command(name="rollback")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Project directory (default: current working directory)",
)
@click.option(
    "--task",
    "task_filter",
    default=None,
    metavar="TASK_ID",
    help="Rollback a specific task's baseline (e.g. --task T01)",
)
@click.option(
    "--all",
    "rollback_all",
    is_flag=True,
    help="Rollback all tasks from the most recent run (uses earliest baseline)",
)
@click.option(
    "--dry-run",
    "dry_run",
    is_flag=True,
    help="Show what would change without modifying files",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
@click.option(
    "--yes",
    "--force",
    "force",
    is_flag=True,
    help="Skip confirmation prompt (use with caution)",
)
def rollback_cmd(
    project: Path | None,
    task_filter: str | None,
    rollback_all: bool,
    dry_run: bool,
    as_json: bool,
    force: bool,
) -> None:
    """Restore files to pre-run state using captured baselines.

    Reads workspace baselines from ``.architect/baselines/`` and restores
    modified files to their original content while deleting files that were
    created during the run.

    \b
    Examples:
      architect rollback --task T01
      architect rollback --all
      architect rollback --dry-run
      architect rollback --task T01 --yes
      architect rollback --json
    """
    _setup_loguru()

    # Mutual exclusion: --task and --all cannot be combined
    if task_filter and rollback_all:
        console.print("[red]Error: --task and --all are mutually exclusive.[/red]")
        raise SystemExit(1)

    proj = _resolve_project(project)

    from the_architect.core.baseline import read_baseline
    from the_architect.core.rollback import (
        compute_rollback_plan,
        execute_rollback,
        list_run_baselines,
    )

    # Discover available baselines
    baselines = list_run_baselines(proj)
    if not baselines:
        console.print()
        console.print("[dim]No baseline data available.[/dim]")
        console.print("[dim]Baselines are captured automatically during task execution.[/dim]")
        raise SystemExit(1)

    # Select the target baseline
    target_baseline_info = None
    if task_filter:
        # Find baseline matching the task filter
        for info in baselines:
            if info.task_prefix.upper() == task_filter.upper():
                target_baseline_info = info
                break
        if target_baseline_info is None:
            available = ", ".join(b.task_prefix for b in baselines)
            console.print(
                f"[red]Error: no baseline found for task '{task_filter}'. "
                f"Available: {available}[/red]"
            )
            raise SystemExit(1)
    elif rollback_all:
        # Use the earliest baseline (first in sorted list) as the run-level baseline
        target_baseline_info = baselines[0]
    else:
        # Interactive selection when neither --task nor --all is provided
        import questionary

        choices = [f"{b.task_prefix} ({b.timestamp[:10]}, {b.file_count} files)" for b in baselines]
        selected_idx = questionary.select(
            "Select a task baseline to rollback:",
            choices=choices,
            style=_questionary_style(),
        ).ask()
        if selected_idx is None:
            console.print("[dim]Cancelled.[/dim]")
            raise SystemExit(0)
        # Parse the index from the selected string
        selected_idx_int = choices.index(selected_idx)
        target_baseline_info = baselines[selected_idx_int]

    # Read the baseline
    baseline_path = Path(target_baseline_info.file_path)
    try:
        baseline = read_baseline(baseline_path)
    except (OSError, ValueError) as exc:
        console.print(f"[red]Error reading baseline: {exc}[/red]")
        raise SystemExit(1)

    # Compute rollback plan
    plan = compute_rollback_plan(baseline, proj)

    # Build plan summary dict
    plan_dict = {
        "restore_count": len(plan.files_to_restore),
        "delete_count": len(plan.files_to_delete),
        "unchanged_count": len(plan.files_unchanged),
        "files_to_restore": list(plan.files_to_restore.keys()),
        "files_to_delete": list(plan.files_to_delete),
    }

    # JSON output path — compute plan but do not execute
    if as_json:
        if dry_run:
            result = execute_rollback(plan, proj, dry_run=True)
        else:
            # For --json without --dry-run, still execute
            result = execute_rollback(plan, proj, dry_run=False)
        result_dict = {
            "restored_count": result.restored_count,
            "deleted_count": result.deleted_count,
            "unchanged_count": result.unchanged_count,
            "errors": [{"path": e.path, "message": e.message} for e in result.errors],
        }
        click.echo(_format_rollback_json(proj, plan_dict, result_dict))
        return

    # Nothing to do?
    if not plan.files_to_restore and not plan.files_to_delete:
        console.print("[dim]No changes to rollback — all files are unchanged.[/dim]")
        return

    # Dry-run mode — show plan and exit
    if dry_run:
        result = execute_rollback(plan, proj, dry_run=True)
        result_dict = {
            "restored_count": result.restored_count,
            "deleted_count": result.deleted_count,
            "unchanged_count": result.unchanged_count,
            "errors": [{"path": e.path, "message": e.message} for e in result.errors],
        }
        _render_rollback_table(plan_dict, result_dict, dry_run=True)
        console.print("[yellow]Dry-run complete — no files were modified.[/yellow]")
        return

    # TUI mode — interactive confirmation screen when in TTY
    if not force and sys.stdout.isatty():
        from the_architect.tui.screens.rollback_screen import run_rollback_screen

        tui_result = run_rollback_screen(
            project=proj,
            baseline_path=baseline_path,
            task_filter=task_filter,
        )
        if tui_result is not None:
            # User approved — show result table
            result_dict = {
                "restored_count": tui_result.restored_count,
                "deleted_count": tui_result.deleted_count,
                "unchanged_count": tui_result.unchanged_count,
                "errors": [{"path": e.path, "message": e.message} for e in tui_result.errors],
            }
            _render_rollback_table(plan_dict, result_dict, dry_run=False)
            if tui_result.errors:
                raise SystemExit(1)
            return
        # User cancelled — TUI returned None
        console.print("[dim]Cancelled.[/dim]")
        raise SystemExit(0)

    # Show the plan (always as preview before confirmation)
    _render_rollback_table(plan_dict, None, dry_run=True)

    # Confirmation prompt (unless --yes/--force)
    if not force:
        import questionary

        confirm = questionary.confirm(
            f"This will restore {len(plan.files_to_restore)} file(s) and "
            f"delete {len(plan.files_to_delete)} file(s). Continue?",
            style=_questionary_style(),
        ).ask()
        if confirm is None:
            console.print("[dim]Cancelled.[/dim]")
            raise SystemExit(0)
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise SystemExit(0)

    # Execute the rollback
    result = execute_rollback(plan, proj, dry_run=False)
    result_dict = {
        "restored_count": result.restored_count,
        "deleted_count": result.deleted_count,
        "unchanged_count": result.unchanged_count,
        "errors": [{"path": e.path, "message": e.message} for e in result.errors],
    }
    _render_rollback_table(plan_dict, result_dict, dry_run=False)

    if result.errors:
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# Preset command group
# ---------------------------------------------------------------------------


@click.group(name="preset")
@click.pass_context
def preset_cmd(ctx: click.Context) -> None:
    """Save and recall configuration presets.

    Create named presets (e.g. "sprint", "quick-fix") with config overrides
    and apply them with one command. Presets are stored per-project in
    ``.architect/presets.json``.

    \b
    Examples:
      architect preset create sprint --description "Fast iteration" --max-retries 5
      architect preset list
      architect preset show sprint
      architect preset apply sprint
      architect preset delete sprint
    """
    pass


# -- Project option helper ---------------------------------------------------
_PROJECT_OPT = click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Project directory (default: current working directory)",
)


def _resolve_project(project: Path | None) -> Path:
    """Return the resolved project root."""
    return (project or Path.cwd()).resolve()


# -- preset create -----------------------------------------------------------


@preset_cmd.command(name="create")
@_PROJECT_OPT
@click.argument("name")
@click.option(
    "--description",
    "-d",
    default="",
    help="Human-readable description of the preset",
)
@click.option(
    "--field",
    "-f",
    "fields",
    multiple=True,
    metavar="KEY=VALUE",
    help=(
        "Config field override (repeatable). Example: --field max-retries=5 --field free-mode=true"
    ),
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def preset_create(
    project: Path | None,
    name: str,
    description: str,
    fields: tuple[str, ...],
    as_json: bool,
) -> None:
    """Create or update a named configuration preset.

    Save config field overrides under *NAME*.  Use ``--field KEY=VALUE``
    one or more times to set config values.  If a preset with *NAME*
    already exists it is updated in place.

    \b
    Examples:
      architect preset create sprint -d "Fast iteration" --field max-retries=5
      architect preset create deep -d "Deep work" \
        --field persistent=true --field retrospective-rounds=3
    """
    _setup_loguru()
    from the_architect.core.presets import save_preset

    proj = _resolve_project(project)

    # Parse field overrides
    config_overrides: dict[str, object] = {}
    for raw in fields:
        if "=" not in raw:
            if as_json:
                click.echo(
                    json.dumps(
                        {"project": str(proj), "error": f"field must be KEY=VALUE, got: {raw}"},
                        indent=2,
                    )
                )
            else:
                console.print(f"[red]Error: field must be KEY=VALUE, got: {raw}[/red]")
            raise SystemExit(1)
        key, value = raw.split("=", 1)
        key = key.strip()
        value = value.strip()

        # Type coercion: bool, int, float, or str
        if value.lower() == "true":
            config_overrides[key] = True
        elif value.lower() == "false":
            config_overrides[key] = False
        else:
            # Try int, then float, else keep as str
            try:
                config_overrides[key] = int(value)
            except ValueError:
                try:
                    config_overrides[key] = float(value)
                except ValueError:
                    config_overrides[key] = value

    # Validate field names against ArchitectConfig
    valid_fields = set(ArchitectConfig.model_fields.keys())
    path_fields = {"tasks_dir", "progress_file", "log_dir", "agents_path", "docs_path"}
    writable_fields = valid_fields - path_fields
    for key in config_overrides:
        if key not in writable_fields:
            if as_json:
                click.echo(
                    json.dumps(
                        {"project": str(proj), "error": f"unknown config field '{key}'"},
                        indent=2,
                    )
                )
            else:
                console.print(
                    f"[red]Error: unknown config field '{key}'. "
                    f"Valid fields: {sorted(writable_fields)}[/red]"
                )
            raise SystemExit(1)

    preset = save_preset(proj, name, description, config_overrides)
    is_update = preset.created_at != preset.updated_at
    action = "updated" if is_update else "created"

    if as_json:
        click.echo(_format_preset_create_json(preset, str(proj), action))
        return

    console.print(
        f"[green]Preset [bold]{preset.name}[/bold] {action}.[/green]  "
        f"Fields: {len(preset.config_overrides)}"
    )


# -- preset list -------------------------------------------------------------


def _format_preset_list_json(presets: list[Preset], project: str) -> str:
    """Serialise preset list for ``--json`` output."""
    return json.dumps(
        {"project": project, "presets": [p.model_dump() for p in presets]},
        indent=2,
    )


@preset_cmd.command(name="list")
@_PROJECT_OPT
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def preset_list(project: Path | None, as_json: bool) -> None:
    """List all saved configuration presets.

    Shows a table of preset names, descriptions, field counts, and
    last-updated timestamps.
    """
    _setup_loguru()
    from the_architect.core.presets import list_presets

    proj = _resolve_project(project)

    presets = list_presets(proj)

    if as_json:
        click.echo(_format_preset_list_json(presets, str(proj)))
        return

    if not presets:
        console.print("[dim]No presets saved.[/dim]")
        console.print(
            "[dim]Use [bold]architect preset create NAME --field KEY=VALUE[/bold] to add one.[/dim]"
        )
        return

    from rich.table import Table

    table = Table(show_header=True, header_style="bold", box=None)
    table.add_column("Name", style="cyan")
    table.add_column("Description")
    table.add_column("Fields", justify="right")
    table.add_column("Updated")

    for p in presets:
        table.add_row(
            p.name,
            p.description or "—",
            str(len(p.config_overrides)),
            p.updated_at[:19],
        )

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect — Presets[/bold {ARCHITECT_GREEN}]  "
        f"[dim]{proj}[/dim]"
    )
    console.print()
    console.print(table)


# -- preset show -------------------------------------------------------------


def _format_preset_show_json(preset_data: object | None, project: str) -> str:
    """Serialise a single preset for ``--json`` output."""
    from the_architect.core.presets import Preset

    if isinstance(preset_data, Preset):
        preset_data = preset_data.model_dump()
    return json.dumps({"project": project, "preset": preset_data}, indent=2)


def _format_preset_create_json(preset_data: object, project: str, action: str) -> str:
    """Serialise preset create result for ``--json`` output."""
    from the_architect.core.presets import Preset

    if isinstance(preset_data, Preset):
        preset_data = preset_data.model_dump()
    return json.dumps(
        {
            "project": project,
            "preset": preset_data,
            "action": action,
        },
        indent=2,
    )


def _format_preset_apply_json(
    name: str, project: str, config_file: str | None, fields_count: int
) -> str:
    """Serialise preset apply result for ``--json`` output."""
    return json.dumps(
        {
            "project": project,
            "preset": name,
            "config_file": config_file,
            "fields_applied": fields_count,
        },
        indent=2,
    )


def _format_preset_delete_json(name: str, project: str) -> str:
    """Serialise preset delete result for ``--json`` output."""
    return json.dumps(
        {
            "project": project,
            "preset": name,
        },
        indent=2,
    )


@preset_cmd.command(name="show")
@_PROJECT_OPT
@click.argument("name")
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def preset_show(project: Path | None, name: str, as_json: bool) -> None:
    """Show details of a saved preset.

    Displays the preset name, description, creation/update times, and all
    stored config field overrides.
    """
    _setup_loguru()
    from the_architect.core.presets import get_preset

    proj = _resolve_project(project)

    preset = get_preset(proj, name)
    if not preset:
        console.print(f"[red]Error: preset '{name}' not found.[/red]")
        raise SystemExit(1)

    if as_json:
        click.echo(_format_preset_show_json(preset, str(proj)))
        return

    console.print()
    console.print(f"[bold {ARCHITECT_GREEN}]Preset: {preset.name}[/bold {ARCHITECT_GREEN}]")
    console.print()
    console.print(f"  Description : {preset.description or '—'}")
    console.print(f"  Created     : {preset.created_at[:19]}")
    console.print(f"  Updated     : {preset.updated_at[:19]}")
    console.print()

    if preset.config_overrides:
        console.print("  [bold]Config overrides[/bold]")
        for key, val in sorted(preset.config_overrides.items()):
            console.print(f"    {key} = {val}")
    else:
        console.print("  [dim]No config overrides.[/dim]")
    console.print()


# -- preset apply ------------------------------------------------------------


@preset_cmd.command(name="apply")
@_PROJECT_OPT
@click.argument("name")
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def preset_apply(project: Path | None, name: str, as_json: bool) -> None:
    """Apply a preset — merge its config overrides into architect.toml.

    Reads the named preset and merges its ``config_overrides`` into the
    current ``architect.toml`` using the existing ``write_config()`` merge
    semantics.  Existing values not in the preset are preserved.
    """
    _setup_loguru()
    from the_architect.core.presets import get_preset

    proj = _resolve_project(project)

    preset = get_preset(proj, name)
    if not preset:
        if as_json:
            click.echo(
                json.dumps({"project": str(proj), "error": f"preset '{name}' not found"}, indent=2)
            )
        else:
            console.print(f"[red]Error: preset '{name}' not found.[/red]")
        raise SystemExit(1)

    if not preset.config_overrides:
        if as_json:
            click.echo(_format_preset_apply_json(name, str(proj), None, 0))
        else:
            console.print(f"[yellow]Preset '{name}' has no config overrides to apply.[/yellow]")
        return

    # Cast values to the types expected by write_config (str/int/bool/float)
    typed_overrides: dict[str, object] = {}
    for key, val in preset.config_overrides.items():
        if isinstance(val, (str, int, bool, float)):
            typed_overrides[key] = val
        else:
            typed_overrides[key] = str(val)

    config_file = write_config(proj, typed_overrides)

    if as_json:
        click.echo(
            _format_preset_apply_json(name, str(proj), str(config_file), len(typed_overrides))
        )
        return

    console.print(
        f"[green]Applied preset [bold]{name}[/bold].[/green]  "
        f"Wrote {len(typed_overrides)} field(s) to {config_file}"
    )


# -- preset delete -----------------------------------------------------------


@preset_cmd.command(name="delete")
@_PROJECT_OPT
@click.argument("name")
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def preset_delete(project: Path | None, name: str, as_json: bool) -> None:
    """Delete a saved preset.

    Permanently removes the named preset from ``.architect/presets.json``.
    """
    _setup_loguru()
    from the_architect.core.presets import delete_preset

    proj = _resolve_project(project)

    deleted = delete_preset(proj, name)
    if deleted:
        if as_json:
            click.echo(_format_preset_delete_json(name, str(proj)))
        else:
            console.print(f"[green]Preset [bold]{name}[/bold] deleted.[/green]")
    else:
        if as_json:
            click.echo(
                json.dumps(
                    {"project": str(proj), "error": f"preset '{name}' not found"},
                    indent=2,
                )
            )
        else:
            console.print(f"[red]Error: preset '{name}' not found.[/red]")
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# Feedback command
# ---------------------------------------------------------------------------


@main.command(name="feedback")
@click.option(
    "--project",
    "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Project directory (default: current working directory)",
)
@click.option(
    "--write",
    "write_msg",
    default=None,
    metavar="MESSAGE",
    help="Write a feedback message for the next task",
)
@click.option(
    "--target",
    "target_task",
    default=None,
    metavar="TASK_ID",
    help="Target a specific task (e.g. T03). Defaults to next pending task.",
)
@click.option(
    "--view",
    "view_feedback",
    is_flag=True,
    help="Display current feedback (same as no flags)",
)
@click.option(
    "--clear",
    "clear_feedback",
    is_flag=True,
    help="Remove stored feedback",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def feedback_cmd(
    project: Path | None,
    write_msg: str | None,
    target_task: str | None,
    view_feedback: bool,
    clear_feedback: bool,
    as_json: bool,
) -> None:
    """View, write, or clear user feedback for the next task.

    Write guidance that gets injected into the next task's execution prompt.
    Feedback is consumed once — it is cleared after injection.

    \b
    Examples:
      architect feedback --write "Fix the auth flow, not the UI"
      architect feedback --write "Use SQLite" --target T05
      architect feedback --view
      architect feedback --clear
      architect feedback --json
    """
    _setup_loguru()
    proj = (project or Path.cwd()).resolve()

    from the_architect.core.feedback import clear_feedback as fb_clear
    from the_architect.core.feedback import load_feedback, save_feedback

    # --- Write path -------------------------------------------------------
    if write_msg is not None:
        state = save_feedback(proj, write_msg, target_task=target_task)
        if as_json:
            click.echo(_format_feedback_json(state.model_dump(), str(proj)))
        else:
            console.print(
                f"[green]Feedback saved.[/green] "
                f"Target: [cyan]{state.target_task or 'next pending task'}[/cyan]"
            )
            console.print(f"  Message: {state.message}")
        return

    # --- Clear path -------------------------------------------------------
    if clear_feedback:
        fb_clear(proj)
        if as_json:
            click.echo(_format_feedback_json(None, str(proj)))
        else:
            console.print("[green]Feedback cleared.[/green]")
        return

    # --- View / default path ----------------------------------------------
    fb = load_feedback(proj)
    if as_json:
        click.echo(_format_feedback_json(fb.model_dump() if fb else None, str(proj)))
        return

    if fb:
        console.print("[bold]Current feedback[/bold]")
        console.print(f"  Message: {fb.message}")
        console.print(f"  Target:  {fb.target_task or 'next pending task'}")
        console.print(f"  Written: {fb.written_at}")
    else:
        console.print("[dim]No feedback stored.[/dim]")


# ---------------------------------------------------------------------------
# Report command — post-run summary from tasks/SUMMARY.md
# ---------------------------------------------------------------------------


def _parse_summary_md(
    summary_path: Path,
) -> dict[str, Any] | None:
    """Parse tasks/SUMMARY.md into a structured dict.

    Args:
        summary_path: Path to the SUMMARY.md file.

    Returns:
        Dictionary with date, duration, result, goal, tasks, totals, insights,
        or ``None`` if the file cannot be parsed.
    """
    content = summary_path.read_text(encoding="utf-8")

    # Extract date
    date_match = re.search(r"\*\*Date:\*\*\s*(.+)", content)
    date_str = date_match.group(1).strip() if date_match else ""

    # Extract duration
    # There may be multiple Duration lines — take the first (header-level)
    durations = re.findall(r"\*\*Duration:\*\*\s*(.+)", content)
    duration_str = durations[0].strip() if durations else ""

    # Extract result
    result_match = re.search(r"\*\*Result:\*\*\s*(.+)", content)
    result_str = result_match.group(1).strip() if result_match else ""

    # Determine short result label
    if "All tasks completed" in result_str or "✓" in result_str:
        result_label = "success"
    elif "task(s) failed" in result_str or "✗" in result_str:
        result_label = "failed"
    else:
        result_label = "unknown"

    # Extract goal
    goal_section = re.search(r"## Goal\n\n(.*?)(?=\n## |\Z)", content, re.DOTALL)
    goal_str = goal_section.group(1).strip() if goal_section else ""

    # Extract tasks table rows
    tasks: list[dict[str, str]] = []
    tasks_section = re.search(r"## Tasks\n\n(.*?)(?=\n## |\Z)", content, re.DOTALL)
    if tasks_section:
        table_text = tasks_section.group(1)
        header_skipped = False
        for line in table_text.split("\n"):
            line = line.strip()
            if line.startswith("|") and not line.startswith("|--"):
                cells = [c.strip() for c in line.split("|") if c.strip()]
                # Skip header row
                if not header_skipped and cells[0] == "Task":
                    header_skipped = True
                    continue
                if len(cells) >= 3:
                    tasks.append(
                        {
                            "task": cells[0],
                            "title": cells[1] if len(cells) > 1 else "",
                            "status": cells[2] if len(cells) > 2 else "",
                            "attempts": cells[3] if len(cells) > 3 else "",
                            "model": cells[4] if len(cells) > 4 else "",
                            "duration": cells[5] if len(cells) > 5 else "",
                            "tokens": cells[6] if len(cells) > 6 else "",
                        }
                    )

    # Extract totals section
    totals_section = re.search(r"## Totals\n\n(.*?)(\n\n##|\n*$)", content, re.DOTALL)
    totals: dict[str, str] = {}
    if totals_section:
        totals_text = totals_section.group(1)
        for line in totals_text.split("\n"):
            line = line.strip().lstrip("- ")
            key_match = re.match(r"\*\*(.+?):\*\*\s*(.*)", line)
            if key_match:
                totals[key_match.group(1).strip()] = key_match.group(2).strip()

    # Extract insights section
    insights_section = re.search(r"## Insights\n\n(.*?)(\n\n##|\n*$)", content, re.DOTALL)
    insights: dict[str, str] = {}
    if insights_section:
        insights_text = insights_section.group(1)
        for line in insights_text.split("\n"):
            line = line.strip().lstrip("- ")
            key_match = re.match(r"\*\*(.+?):\*\*\s*(.*)", line)
            if key_match:
                insights[key_match.group(1).strip()] = key_match.group(2).strip()

    return {
        "date": date_str,
        "duration": duration_str,
        "result": result_label,
        "goal": goal_str,
        "tasks": tasks,
        "totals": totals,
        "insights": insights,
    }


def _format_report_json(project: str, data: dict[str, Any]) -> str:
    """Serialise report data for ``--json`` output.

    Args:
        project: Resolved project directory path.
        data: Parsed summary data from ``_parse_summary_md``.

    Returns:
        JSON string with project, date, duration, result, goal, tasks, totals, insights.
    """
    return json.dumps(
        {
            "project": project,
            "date": data.get("date", ""),
            "duration": data.get("duration", ""),
            "result": data.get("result", ""),
            "goal": data.get("goal", ""),
            "tasks": data.get("tasks", []),
            "totals": data.get("totals", {}),
            "insights": data.get("insights", {}),
        },
        indent=2,
    )


def _render_report_table(data: dict[str, Any]) -> None:
    """Render the report as a Rich table.

    Args:
        data: Parsed summary data from ``_parse_summary_md``.
    """
    from rich import box
    from rich.table import Table

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect[/bold {ARCHITECT_GREEN}]  [dim]Run Report[/dim]"
    )
    console.print()

    # Header info
    result = data.get("result", "unknown")
    if result == "success":
        result_style = f"[{ARCHITECT_GREEN}]✓ {result}[/{ARCHITECT_GREEN}]"
    elif result == "failed":
        result_style = "[red]✗ failed[/red]"
    else:
        result_style = f"[dim]{result}[/dim]"

    header_table = Table(box=box.SIMPLE, padding=(0, 1))
    header_table.add_column("Key", style="dim", width=10)
    header_table.add_column("Value", no_wrap=False)
    header_table.add_row("Date", str(data.get("date", "—")))
    header_table.add_row("Duration", str(data.get("duration", "—")))
    header_table.add_row("Result", result_style)
    console.print(header_table)

    # Goal
    goal = data.get("goal", "")
    if goal:
        console.print()
        console.print(f"[bold]Goal[/bold]  [dim]{goal}[/dim]")

    # Tasks table
    tasks = data.get("tasks", [])
    if tasks:
        console.print()
        task_table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
        task_table.add_column("Task", style="dim", width=6)
        task_table.add_column("Title", no_wrap=False)
        task_table.add_column("Status", width=10)
        task_table.add_column("Attempts", justify="right", width=5)
        task_table.add_column("Model", width=18)
        task_table.add_column("Time", justify="right", width=6)
        task_table.add_column("Tokens", justify="right", width=8)

        for t in tasks:
            task_table.add_row(
                t.get("task", ""),
                t.get("title", ""),
                t.get("status", ""),
                t.get("attempts", "—"),
                f"[dim]{t.get('model', '')}[/dim]",
                f"[dim]{t.get('duration', '—')}[/dim]",
                f"[dim]{t.get('tokens', '—')}[/dim]",
            )
        console.print(task_table)

    # Totals
    totals = data.get("totals", {})
    if totals:
        console.print()
        console.print("[bold]Totals[/bold]")
        for key, value in totals.items():
            console.print(f"  [dim]{key}[/dim]: {value}")

    # Insights
    insights = data.get("insights", {})
    if insights:
        console.print()
        console.print("[bold]Insights[/bold]")
        for key, value in insights.items():
            console.print(f"  [dim]{key}[/dim]: {value}")

    console.print()


@main.command(name="report")
@_PROJECT_OPT
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def report_cmd(project: Path | None, as_json: bool) -> None:
    """View the last run's summary report.

    Reads ``tasks/SUMMARY.md`` written after the most recent Architect run
    and displays key metrics: date, duration, result, task outcomes, token
    totals, and performance insights.  Use ``--json`` for machine-readable
    output suitable for scripting.

    \b
    Examples:
      architect report
      architect report --json
      architect report -p /path/to/project
    """
    _setup_loguru()
    proj = _resolve_project(project)

    summary_path = proj / "tasks" / "SUMMARY.md"
    if not summary_path.exists():
        console.print("[dim]No run summary found.[/dim]")
        console.print(
            f"[dim]Run [bold]architect run[/bold] first, or check "
            f"[cyan]{summary_path}[/cyan] exists.[/dim]"
        )
        raise SystemExit(1)

    data = _parse_summary_md(summary_path)
    if data is None:
        console.print("[red]Error: could not parse SUMMARY.md.[/red]")
        raise SystemExit(1)

    if as_json:
        click.echo(_format_report_json(str(proj), data))
        return

    _render_report_table(data)


# ---------------------------------------------------------------------------
# Template command group
# ---------------------------------------------------------------------------


@click.group(name="template")
@click.pass_context
def template_cmd(ctx: click.Context) -> None:
    """Manage goal templates — reusable goal descriptions with placeholders.

    Create named templates (e.g. "bugfix", "feature") with parameterised
    goal text containing ``{variable}`` placeholders.  Run a template to
    launch a full Architect run with substituted values.

    \b
    Examples:
      architect template create bugfix --goal "Fix {issue}" --description "Bug fix"
      architect template list
      architect template show bugfix
      architect template run bugfix --var issue="null pointer in auth"
      architect template delete bugfix
    """
    pass


# -- template create ---------------------------------------------------------


@template_cmd.command(name="create")
@_PROJECT_OPT
@click.argument("name")
@click.option(
    "--goal",
    "-g",
    required=True,
    help="Goal text with {variable} placeholders",
)
@click.option(
    "--description",
    "-d",
    default="",
    help="Human-readable description of the template",
)
@click.option(
    "--config",
    "-c",
    "fields",
    multiple=True,
    metavar="KEY=VALUE",
    help=(
        "Config field override (repeatable). Example: --config max-retries=5 "
        "--config free-mode=true"
    ),
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def template_create(
    project: Path | None,
    name: str,
    goal: str,
    description: str,
    fields: tuple[str, ...],
    as_json: bool,
) -> None:
    """Create a named goal template.

    Save goal text with ``{variable}`` placeholders under *NAME*.
    Use ``--config KEY=VALUE`` to attach config overrides.
    If a template with *NAME* already exists, the command fails.

    \b
    Examples:
      architect template create feature -g "Add {feature} to {module}" \\
        -d "Feature template" --config max-retries=5
    """
    _setup_loguru()
    from the_architect.core.templates import create_template

    proj = _resolve_project(project)

    # Parse config overrides
    config_overrides: dict[str, object] = {}
    for raw in fields:
        if "=" not in raw:
            console.print(f"[red]Error: config must be KEY=VALUE, got: {raw}[/red]")
            raise SystemExit(1)
        key, value = raw.split("=", 1)
        key = key.strip()
        value = value.strip()

        # Type coercion: bool, int, float, or str
        if value.lower() == "true":
            config_overrides[key] = True
        elif value.lower() == "false":
            config_overrides[key] = False
        else:
            try:
                config_overrides[key] = int(value)
            except ValueError:
                try:
                    config_overrides[key] = float(value)
                except ValueError:
                    config_overrides[key] = value

    # Validate field names against ArchitectConfig
    valid_fields = set(ArchitectConfig.model_fields.keys())
    path_fields = {"tasks_dir", "progress_file", "log_dir", "agents_path", "docs_path"}
    writable_fields = valid_fields - path_fields
    for key in config_overrides:
        if key not in writable_fields:
            console.print(
                f"[red]Error: unknown config field '{key}'. "
                f"Valid fields: {sorted(writable_fields)}[/red]"
            )
            raise SystemExit(1)

    try:
        template = create_template(proj, name, goal, description, config_overrides)
    except ValueError as exc:
        if as_json:
            click.echo(json.dumps({"project": str(proj), "error": str(exc)}, indent=2))
        else:
            console.print(f"[red]Error: {exc}[/red]")
        raise SystemExit(1)

    if as_json:
        click.echo(_format_template_create_json(template, str(proj)))
        return

    console.print(
        f"[green]Template [bold]{template.name}[/bold] created.[/green]  "
        f"Variables: {len(template.variables)}"
    )


# -- template list -----------------------------------------------------------


def _format_template_create_json(template: GoalTemplate, project: str) -> str:
    """Serialise a created template for ``--json`` output."""
    return json.dumps(
        {"project": project, "action": "created", "template": template.model_dump()},
        indent=2,
    )


def _format_template_list_json(templates: list[GoalTemplate], project: str) -> str:
    """Serialise template list for ``--json`` output."""
    return json.dumps(
        {"project": project, "templates": [t.model_dump() for t in templates]},
        indent=2,
    )


@template_cmd.command(name="list")
@_PROJECT_OPT
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def template_list(project: Path | None, as_json: bool) -> None:
    """List all saved goal templates.

    Shows a table of template names, descriptions, variable counts, and
    last-updated timestamps.
    """
    _setup_loguru()
    from the_architect.core.templates import list_templates

    proj = _resolve_project(project)

    templates = list_templates(proj)

    if as_json:
        click.echo(_format_template_list_json(templates, str(proj)))
        return

    if not templates:
        console.print("[dim]No templates saved.[/dim]")
        console.print(
            '[dim]Use [bold]architect template create NAME -g "goal text"[/bold] to add one.[/dim]'
        )
        return

    from rich.table import Table

    table = Table(show_header=True, header_style="bold", box=None)
    table.add_column("Name", style="cyan")
    table.add_column("Description")
    table.add_column("Vars", justify="right")
    table.add_column("Updated")

    for t in templates:
        table.add_row(
            t.name,
            t.description or "—",
            str(len(t.variables)),
            t.updated_at[:19],
        )

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect — Templates[/bold {ARCHITECT_GREEN}]  "
        f"[dim]{proj}[/dim]"
    )
    console.print()
    console.print(table)


# -- template show -----------------------------------------------------------


def _format_template_show_json(template_data: object | None, project: str) -> str:
    """Serialise a single template for ``--json`` output."""
    from the_architect.core.templates import GoalTemplate

    if isinstance(template_data, GoalTemplate):
        template_data = template_data.model_dump()
    return json.dumps({"project": project, "template": template_data}, indent=2)


@template_cmd.command(name="show")
@_PROJECT_OPT
@click.argument("name")
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def template_show(project: Path | None, name: str, as_json: bool) -> None:
    """Show details of a saved template.

    Displays the template name, description, goal text with placeholders,
    variable list, config overrides, and timestamps.
    """
    _setup_loguru()
    from the_architect.core.templates import show_template

    proj = _resolve_project(project)

    template = show_template(proj, name)
    if not template:
        console.print(f"[red]Error: template '{name}' not found.[/red]")
        raise SystemExit(1)

    if as_json:
        click.echo(_format_template_show_json(template, str(proj)))
        return

    console.print()
    console.print(f"[bold {ARCHITECT_GREEN}]Template: {template.name}[/bold {ARCHITECT_GREEN}]")
    console.print()
    console.print(f"  Description : {template.description or '—'}")
    console.print(f"  Goal        : {template.goal_text}")
    console.print(f"  Created     : {template.created_at[:19]}")
    console.print(f"  Updated     : {template.updated_at[:19]}")
    console.print()

    if template.variables:
        console.print("  [bold]Variables[/bold]")
        for var in template.variables:
            console.print(f"    {{{var}}}")
    else:
        console.print("  [dim]No variables.[/dim]")
    console.print()

    if template.config_overrides:
        console.print("  [bold]Config overrides[/bold]")
        for key, val in sorted(template.config_overrides.items()):
            console.print(f"    {key} = {val}")
    else:
        console.print("  [dim]No config overrides.[/dim]")
    console.print()


# -- template run ------------------------------------------------------------


@template_cmd.command(name="run")
@_PROJECT_OPT
@click.argument("name")
@click.option(
    "--var",
    "-v",
    "vars_raw",
    multiple=True,
    metavar="VAR=VALUE",
    help="Variable value (repeatable). Example: --var feature=login",
)
@click.option(
    "--headless",
    is_flag=True,
    help="Fail if variables are missing (no interactive prompts)",
)
def template_run(
    project: Path | None,
    name: str,
    vars_raw: tuple[str, ...],
    headless: bool,
) -> None:
    """Run a template — substitute variables and launch the Architect.

    Loads the named template, substitutes ``{variable}`` placeholders with
    values from ``--var``, applies config overrides, then runs the full
    Architect flow.

    If variables remain after ``--var`` substitution and the terminal is
    interactive, you will be prompted for each remaining variable.

    \b
    Examples:
      architect template run feature --var feature=login --var module=auth
      architect template run bugfix --var issue="null pointer"
    """
    _setup_loguru()
    from the_architect.core.templates import (
        extract_variables,
        show_template,
        substitute_variables,
    )

    proj = _resolve_project(project)

    template = show_template(proj, name)
    if not template:
        console.print(f"[red]Error: template '{name}' not found.[/red]")
        raise SystemExit(1)

    # Parse --var KEY=VALUE pairs
    vars_dict: dict[str, str] = {}
    for raw in vars_raw:
        if "=" not in raw:
            console.print(f"[red]Error: var must be VAR=VALUE, got: {raw}[/red]")
            raise SystemExit(1)
        key, value = raw.split("=", 1)
        vars_dict[key.strip()] = value.strip()

    # Substitute known variables
    substituted_goal = substitute_variables(template.goal_text, vars_dict)

    # Check for remaining variables
    remaining = extract_variables(substituted_goal)

    if remaining:
        if headless:
            console.print(
                f"[red]Error: unsatisfied variables: {', '.join(remaining)}. "
                f"Provide them with --var or drop --headless for prompts.[/red]"
            )
            raise SystemExit(1)

        # Interactive prompts for remaining variables
        import questionary

        for var_name in remaining:
            answer = questionary.text(
                f"Value for {{{var_name}}}:",
                style=_questionary_style(),
            ).ask()
            if answer is None:
                console.print("[red]Error: interrupted.[/red]")
                raise SystemExit(1)
            substituted_goal = substitute_variables(substituted_goal, {var_name: answer})

    # Verify no remaining placeholders
    final_remaining = extract_variables(substituted_goal)
    if final_remaining:
        console.print(
            f"[red]Error: unsatisfied variables after substitution: "
            f"{', '.join(final_remaining)}.[/red]"
        )
        raise SystemExit(1)

    # Apply config overrides
    if template.config_overrides:
        # Cast values to types expected by write_config
        typed_overrides: dict[str, object] = {}
        for key, val in template.config_overrides.items():
            if isinstance(val, (str, int, bool, float)):
                typed_overrides[key] = val
            else:
                typed_overrides[key] = str(val)
        write_config(proj, typed_overrides)

    # Run the Architect with the substituted goal
    _run_main(proj, goal_text=substituted_goal)


# -- template delete ---------------------------------------------------------


def _format_template_delete_json(name: str, project: str) -> str:
    """Serialise a deleted template for ``--json`` output."""
    return json.dumps(
        {"project": project, "action": "deleted", "template_name": name},
        indent=2,
    )


@template_cmd.command(name="delete")
@_PROJECT_OPT
@click.argument("name")
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def template_delete(project: Path | None, name: str, as_json: bool) -> None:
    """Delete a saved template.

    Permanently removes the named template from ``.architect/templates.json``.
    """
    _setup_loguru()
    from the_architect.core.templates import delete_template

    proj = _resolve_project(project)

    deleted = delete_template(proj, name)
    if deleted:
        if as_json:
            click.echo(_format_template_delete_json(name, str(proj)))
            return
        console.print(f"[green]Template [bold]{name}[/bold] deleted.[/green]")
    else:
        if as_json:
            click.echo(
                json.dumps(
                    {"project": str(proj), "error": f"template '{name}' not found"},
                    indent=2,
                )
            )
        else:
            console.print(f"[red]Error: template '{name}' not found.[/red]")
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# Hooks command group — lifecycle hooks management
# ---------------------------------------------------------------------------


def _format_hooks_list_json(hooks_data: list[dict[str, object]], project: str) -> str:
    """Serialise hooks list for ``--json`` output.

    Args:
        hooks_data: List of hook dicts (from HookConfig.model_dump()).
        project: Resolved project path string.

    Returns:
        JSON string with hooks array.
    """
    return json.dumps(
        {
            "project": project,
            "hooks": hooks_data,
        },
        indent=2,
    )


def _format_hooks_run_json(
    results: list[dict[str, object]],
    project: str,
    event: str,
) -> str:
    """Serialise hooks run results for ``--json`` output.

    Args:
        results: List of HookResult dicts.
        project: Resolved project path string.
        event: The lifecycle event that was triggered.

    Returns:
        JSON string with run results.
    """
    return json.dumps(
        {
            "project": project,
            "event": event,
            "results": results,
        },
        indent=2,
    )


def _format_hooks_add_json(
    hook_data: dict[str, object],
    project: str,
    index: int,
) -> str:
    """Serialise hooks add result for ``--json`` output.

    Args:
        hook_data: Hook dict (from HookConfig.model_dump()).
        project: Resolved project path string.
        index: Zero-based index of the added hook.

    Returns:
        JSON string with add result.
    """
    return json.dumps(
        {
            "project": project,
            "action": "added",
            "index": index,
            "hook": hook_data,
        },
        indent=2,
    )


def _format_hooks_remove_json(
    hook_data: dict[str, object],
    project: str,
    index: int,
) -> str:
    """Serialise hooks remove result for ``--json`` output.

    Args:
        hook_data: Hook dict (from HookConfig.model_dump()).
        project: Resolved project path string.
        index: Zero-based index of the removed hook.

    Returns:
        JSON string with remove result.
    """
    return json.dumps(
        {
            "project": project,
            "action": "removed",
            "index": index,
            "hook": hook_data,
        },
        indent=2,
    )


@click.group(name="hooks")
@click.pass_context
def hooks_cmd(ctx: click.Context) -> None:
    """Manage lifecycle hooks — shell commands at run lifecycle points.

    Hooks are stored per-project in ``.architect/hooks.json``.
    Supported events: pre_run, post_task, post_run_success, post_run_failure.

    \b
    Examples:
      architect hooks list
      architect hooks add --event pre_run --command "echo starting"
      architect hooks remove --index 0
      architect hooks run --event pre_run
    """
    pass


# -- hooks list --------------------------------------------------------------


@hooks_cmd.command(name="list")
@_PROJECT_OPT
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def hooks_list(project: Path | None, as_json: bool) -> None:
    """List all configured lifecycle hooks.

    Shows a table of hook index, event, command, enabled status, and timeout.
    """
    _setup_loguru()
    from the_architect.core.hooks import list_hooks

    proj = _resolve_project(project)
    hooks = list_hooks(proj)

    if as_json:
        click.echo(_format_hooks_list_json([h.model_dump() for h in hooks], str(proj)))
        return

    if not hooks:
        console.print("[dim]No hooks configured.[/dim]")
        console.print(
            "[dim]Use [bold]architect hooks add -e <event> -c <cmd>[/bold] to add one.[/dim]"
        )
        return

    from rich.table import Table

    table = Table(show_header=True, header_style="bold", box=None)
    table.add_column("Index", justify="right", style="dim")
    table.add_column("Event", style="cyan")
    table.add_column("Command", style="green")
    table.add_column("Enabled", justify="center")
    table.add_column("Timeout", justify="right")

    for idx, hook in enumerate(hooks):
        enabled_str = "[green]on[/green]" if hook.enabled else "[red]off[/red]"
        table.add_row(
            str(idx),
            hook.event.value,
            hook.command,
            enabled_str,
            f"{hook.timeout}s",
        )

    console.print()
    console.print(
        f"[bold {ARCHITECT_GREEN}]The Architect — Hooks[/bold {ARCHITECT_GREEN}]  [dim]{proj}[/dim]"
    )
    console.print()
    console.print(table)


# -- hooks add ---------------------------------------------------------------


@hooks_cmd.command(name="add")
@_PROJECT_OPT
@click.option(
    "--event",
    "-e",
    type=click.Choice(["pre_run", "post_task", "post_run_success", "post_run_failure"]),
    required=True,
    help="Lifecycle event that triggers this hook",
)
@click.option(
    "--command",
    "-c",
    required=True,
    help="Shell command to execute when the event fires",
)
@click.option(
    "--timeout",
    "-t",
    type=click.INT,
    default=30,
    help="Maximum seconds for command execution (default: 30)",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def hooks_add(
    project: Path | None,
    event: str,
    command: str,
    timeout: int,
    as_json: bool,
) -> None:
    """Add a new lifecycle hook.

    Creates a hook that fires a shell command when the specified lifecycle
    event occurs. Hooks are stored per-project in ``.architect/hooks.json``.
    """
    _setup_loguru()
    from the_architect.core.hooks import HookConfig, HookEvent, add_hook, list_hooks

    proj = _resolve_project(project)

    hook = HookConfig(
        event=HookEvent(event),
        command=command,
        timeout=timeout,
    )
    added = add_hook(proj, hook)
    idx = len(list_hooks(proj)) - 1

    if as_json:
        click.echo(_format_hooks_add_json(added.model_dump(), str(proj), idx))
        return

    console.print()
    console.print(f"[green]Hook added.[/green]  Index: [cyan]{idx}[/cyan]")
    console.print(f"  Event:   [cyan]{added.event.value}[/cyan]")
    console.print(f"  Command: [green]{added.command}[/green]")
    console.print(f"  Timeout: [dim]{added.timeout}s[/dim]")


# -- hooks remove ------------------------------------------------------------


@hooks_cmd.command(name="remove")
@_PROJECT_OPT
@click.option(
    "--index",
    "-i",
    type=click.INT,
    required=True,
    help="Zero-based index of the hook to remove (use 'list' to see indices)",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def hooks_remove(
    project: Path | None,
    index: int,
    as_json: bool,
) -> None:
    """Remove a hook by its zero-based index.

    Use ``architect hooks list`` to see available indices.
    """
    _setup_loguru()
    from the_architect.core.hooks import list_hooks, remove_hook

    proj = _resolve_project(project)
    hooks = list_hooks(proj)

    if index < 0 or index >= len(hooks):
        if as_json:
            click.echo(
                json.dumps(
                    {
                        "project": str(proj),
                        "error": f"index {index} out of range",
                    },
                    indent=2,
                )
            )
        else:
            console.print(
                f"[red]Error: index {index} out of range.[/red] Valid indices: 0–{len(hooks) - 1}"
            )
        raise SystemExit(1)

    removed_hook = hooks[index]
    ok = remove_hook(proj, index)

    if ok:
        if as_json:
            click.echo(_format_hooks_remove_json(removed_hook.model_dump(), str(proj), index))
            return

        console.print()
        console.print(
            f"[green]Hook removed.[/green]  "
            f"Event: [cyan]{removed_hook.event.value}[/cyan]  "
            f"Command: [green]{removed_hook.command}[/green]"
        )
    else:
        if as_json:
            click.echo(
                json.dumps(
                    {
                        "project": str(proj),
                        "error": "failed to remove hook",
                    },
                    indent=2,
                )
            )
        else:
            console.print("[red]Error: failed to remove hook.[/red]")
        raise SystemExit(1)


# -- hooks run ---------------------------------------------------------------


@hooks_cmd.command(name="run")
@_PROJECT_OPT
@click.option(
    "--event",
    "-e",
    type=click.Choice(["pre_run", "post_task", "post_run_success", "post_run_failure"]),
    required=True,
    help="Lifecycle event to trigger hooks for",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output as machine-readable JSON",
)
def hooks_run(
    project: Path | None,
    event: str,
    as_json: bool,
) -> None:
    """Execute all enabled hooks for a specific event immediately.

    Useful for testing hooks without running a full Architect session.
    """
    _setup_loguru()
    from the_architect.core.hooks import HookEvent, execute_hooks_for_event, list_hooks

    proj = _resolve_project(project)
    hooks = list_hooks(proj)
    hook_event = HookEvent(event)

    # Check if any hooks match
    matching = [h for h in hooks if h.event == hook_event and h.enabled]
    if not matching:
        if as_json:
            click.echo(_format_hooks_run_json([], str(proj), event))
        else:
            console.print(f"[dim]No enabled hooks for event [cyan]{event}[/cyan].[/dim]")
        return

    results = asyncio.run(execute_hooks_for_event(hooks, hook_event))

    if as_json:
        click.echo(_format_hooks_run_json([r.model_dump() for r in results], str(proj), event))
        return

    console.print()
    console.print(f"[bold]Ran {len(results)} hook(s) for [cyan]{event}[/cyan]:[/bold]")
    for result in results:
        status = (
            "[green]OK[/green]" if result.exit_code == 0 else f"[red]exit {result.exit_code}[/red]"
        )
        console.print(f"  [{status}] {result.command}")
        if result.stdout:
            console.print(f"       stdout: {result.stdout.strip()}")
        if result.stderr:
            console.print(f"       stderr: {result.stderr.strip()}")
        if result.error:
            console.print(f"       error:  [red]{result.error}[/red]")


# ---------------------------------------------------------------------------
# Register command groups
# ---------------------------------------------------------------------------

main.add_command(preset_cmd, name="preset")
main.add_command(template_cmd, name="template")
main.add_command(hooks_cmd, name="hooks")

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


if __name__ == "__main__":
    main()
