"""ccstory — Claude Code usage recap with narrative.

Companion to ccusage: ccusage tells you the bill, ccstory tells you the story.
"""

__version__ = "0.3.0"
