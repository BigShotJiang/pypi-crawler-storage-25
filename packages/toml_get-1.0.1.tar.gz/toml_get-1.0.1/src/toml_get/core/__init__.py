import argparse
import tomllib
from collections.abc import Iterable
from typing import Any, Optional

__all__ = ["main", "run"]


def main(args: Optional[Iterable] = None) -> None:
    ans: Any
    parser: argparse.ArgumentParser
    space: argparse.Namespace
    parser = argparse.ArgumentParser(fromfile_prefix_chars="@")
    parser.add_argument("file")
    parser.add_argument("key", nargs="*")
    parser.add_argument("--default")
    parser.add_argument("--outstring", default="%s\n")
    space = parser.parse_args(args)
    ans = run(space.file, *space.key, default=space.default)
    try:
        ans = space.outstring % ans
    except Exception:
        ans = default
    if ans is not None:
        print(ans, end="")


def run(file: str, /, *keys: Any, default: object) -> Any:
    with open(file, "rb") as stream:
        data = tomllib.load(stream)
    try:
        for x in keys:
            y = str(x) if isinstance(data, dict) else int(x)
            data = data[y]
    except Exception:
        return default
    else:
        return data
