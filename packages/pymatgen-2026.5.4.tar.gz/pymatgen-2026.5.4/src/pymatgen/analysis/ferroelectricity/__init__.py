"""Package for analyzing ferroelectricity."""
