from __future__ import annotations

from typing import Any

from .document import DocumentSearch
from .factory import SearchFactory
from .web import WebSearch


def docsearch(*args: Any, **kwargs: Any) -> DocumentSearch:
    return SearchFactory.create_doc_search(*args, **kwargs)


def websearch(*args: Any, **kwargs: Any) -> WebSearch:
    return SearchFactory.create_web_search(*args, **kwargs)
