from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Sequence

from .models import ChunkHit, ChunkRecord
from .retrievers import BM25Retriever
from .search_types import SearchCandidate


class SearchStrategy(ABC):
    @abstractmethod
    def search(
        self,
        query: str,
        candidates: Sequence[SearchCandidate],
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        raise NotImplementedError


class BM25SearchStrategy(SearchStrategy):
    def __init__(self, retriever: Optional[BM25Retriever] = None) -> None:
        self.retriever = retriever or BM25Retriever()

    def search(
        self,
        query: str,
        candidates: Sequence[SearchCandidate],
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        chunks = [
            ChunkRecord(
                id=candidate.id,
                title=candidate.title,
                content=candidate.content,
                metadata=dict(candidate.metadata),
            )
            for candidate in candidates
        ]
        hits = self.retriever.score(query=query, chunks=chunks)
        return [
            {
                "id": hit.chunk.id,
                "title": hit.chunk.title,
                "content": hit.chunk.content,
                "metadata": hit.chunk.metadata,
                "score": hit.score,
            }
            for hit in hits
        ]


class VectorSearchStrategy(SearchStrategy):
    def __init__(self, embedding_model: Any) -> None:
        self.embedding_model = embedding_model

    def search(
        self,
        query: str,
        candidates: Sequence[SearchCandidate],
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        raise NotImplementedError("`VectorSearchStrategy` requires a concrete embedding implementation.")


class SemanticSearchStrategy(SearchStrategy):
    def __init__(self, llm: Any, summarizer: Any | None = None) -> None:
        self.llm = llm
        self.summarizer = summarizer or llm

    def search(
        self,
        query: str,
        candidates: Sequence[SearchCandidate],
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        raise NotImplementedError("`SemanticSearchStrategy` requires an LLM-backed scoring implementation.")


class GenerativeSearchStrategy(SearchStrategy):
    def __init__(self, llm: Any, agent: Any | None = None) -> None:
        self.llm = llm
        self.agent = agent

    def search(
        self,
        query: str,
        candidates: Sequence[SearchCandidate],
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        raise NotImplementedError("`GenerativeSearchStrategy` requires an agentic search implementation.")


class DiffusionRetrievalStrategy(SearchStrategy):
    def __init__(self, diffusion_model: Any) -> None:
        self.diffusion_model = diffusion_model

    def search(
        self,
        query: str,
        candidates: Sequence[SearchCandidate],
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        raise NotImplementedError("`DiffusionRetrievalStrategy` requires a diffusion retrieval implementation.")
