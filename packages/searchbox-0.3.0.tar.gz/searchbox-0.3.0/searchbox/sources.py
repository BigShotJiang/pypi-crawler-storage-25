from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, List

from .repository import DocumentRepository
from .search_types import SearchCandidate


class CandidateSource(ABC):
    @abstractmethod
    def fetch_candidates(self, query: str, top_k: int = 20) -> List[SearchCandidate]:
        raise NotImplementedError


class RepositoryCandidateSource(CandidateSource):
    def __init__(self, repository: DocumentRepository) -> None:
        self.repository = repository

    def fetch_candidates(self, query: str, top_k: int = 20) -> List[SearchCandidate]:
        chunks = self.repository.fetch_chunks()
        return [
            SearchCandidate(
                id=chunk.id,
                title=chunk.title,
                content=chunk.content,
                metadata=dict(chunk.metadata),
            )
            for chunk in chunks
        ]


class WebCandidateSource(CandidateSource):
    def __init__(self, web_fetcher: Any) -> None:
        self.web_fetcher = web_fetcher

    def fetch_candidates(self, query: str, top_k: int = 20) -> List[SearchCandidate]:
        return list(self.web_fetcher.search_and_crawl(query, top_k=top_k))
