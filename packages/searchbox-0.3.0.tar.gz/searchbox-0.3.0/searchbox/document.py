from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence

from .base import BaseSearch
from .extractors import FileTextExtractor
from .models import ChunkRecord
from .repository import DocumentRepository, SqliteDocumentRepository
from .search_types import SearchCandidate
from .sources import CandidateSource, RepositoryCandidateSource
from .strategies import BM25SearchStrategy, SearchStrategy


class DocumentIngestor:
    def __init__(
        self,
        repository: DocumentRepository,
        extractor: Optional[FileTextExtractor] = None,
        chunk_size: int = 240,
        chunk_overlap: int = 40,
    ) -> None:
        if chunk_size <= 0:
            raise ValueError("`chunk_size` must be greater than 0.")
        if chunk_overlap < 0:
            raise ValueError("`chunk_overlap` must be greater than or equal to 0.")
        if chunk_overlap >= chunk_size:
            raise ValueError("`chunk_overlap` must be smaller than `chunk_size`.")

        self.repository = repository
        self.extractor = extractor or FileTextExtractor()
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def add_path(
        self,
        path: str,
        recursive: bool = True,
        include_hidden: bool = False,
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[int] = None,
    ) -> List[str]:
        return self.add_paths(
            paths=[path],
            recursive=recursive,
            include_hidden=include_hidden,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )

    def add_paths(
        self,
        paths: Sequence[str],
        recursive: bool = True,
        include_hidden: bool = False,
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[int] = None,
    ) -> List[str]:
        effective_chunk_size = self.chunk_size if chunk_size is None else chunk_size
        effective_chunk_overlap = self.chunk_overlap if chunk_overlap is None else chunk_overlap
        indexed_chunks: List[ChunkRecord] = []
        source_paths: List[str] = []

        for raw_path in paths:
            path = Path(raw_path).expanduser()
            if not path.exists():
                raise FileNotFoundError(f"Path does not exist: {path}")

            if path.is_dir():
                indexed_chunks.extend(
                    self._build_directory_chunks(
                        path=path,
                        recursive=recursive,
                        include_hidden=include_hidden,
                        chunk_size=effective_chunk_size,
                        chunk_overlap=effective_chunk_overlap,
                    )
                )
            else:
                indexed_chunks.extend(
                    self._build_file_chunks(
                        path=path,
                        chunk_size=effective_chunk_size,
                        chunk_overlap=effective_chunk_overlap,
                    )
                )

        for chunk in indexed_chunks:
            source_path = chunk.metadata.get("source_path")
            if source_path:
                source_paths.append(source_path)

        unique_source_paths = sorted(set(source_paths))
        if unique_source_paths:
            self.repository.delete_by_source_paths(unique_source_paths)
        return self.repository.upsert_chunks(indexed_chunks)

    def supported_extensions(self) -> List[str]:
        return self.extractor.supported_extensions()

    def _build_directory_chunks(
        self,
        path: Path,
        recursive: bool,
        include_hidden: bool,
        chunk_size: int,
        chunk_overlap: int,
    ) -> List[ChunkRecord]:
        pattern = "**/*" if recursive else "*"
        chunks: List[ChunkRecord] = []
        for file_path in sorted(path.glob(pattern)):
            if not file_path.is_file():
                continue
            if not include_hidden and self._is_hidden(file_path=file_path, root=path):
                continue
            chunks.extend(
                self._build_file_chunks(
                    path=file_path,
                    chunk_size=chunk_size,
                    chunk_overlap=chunk_overlap,
                    source_root=path,
                )
            )
        return chunks

    def _build_file_chunks(
        self,
        path: Path,
        chunk_size: int,
        chunk_overlap: int,
        source_root: Optional[Path] = None,
    ) -> List[ChunkRecord]:
        text = self.extractor.read_text(path)
        if not text:
            return []

        chunks = self._chunk_text(text, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        if not chunks:
            return []

        source_path = str(path if source_root is None else path.relative_to(source_root))
        title = path.stem.replace("_", " ").replace("-", " ").strip() or path.name

        rows: List[ChunkRecord] = []
        for index, chunk in enumerate(chunks):
            rows.append(
                ChunkRecord(
                    id=self._make_chunk_id(path=path, chunk_index=index),
                    title=title,
                    content=chunk,
                    metadata={
                        "source_path": source_path,
                        "source_name": path.name,
                        "chunk_index": index,
                        "chunk_count": len(chunks),
                    },
                )
            )
        return rows

    def _chunk_text(self, content: str, chunk_size: int, chunk_overlap: int) -> List[str]:
        words = content.split()
        if not words:
            return []
        if len(words) <= chunk_size:
            return [" ".join(words)]

        step = chunk_size - chunk_overlap
        chunks: List[str] = []
        for start in range(0, len(words), step):
            piece = words[start : start + chunk_size]
            if not piece:
                break
            chunks.append(" ".join(piece))
            if start + chunk_size >= len(words):
                break
        return chunks

    def _make_chunk_id(self, path: Path, chunk_index: int) -> str:
        base = re.sub(r"\W+", "-", str(path).lower()).strip("-")[:48] or "document"
        return f"{base}-chunk-{chunk_index}"

    def _is_hidden(self, file_path: Path, root: Path) -> bool:
        return any(part.startswith(".") for part in file_path.relative_to(root).parts)


class DocSearch(BaseSearch):
    def __init__(
        self,
        source: CandidateSource,
        strategies: Mapping[str, SearchStrategy],
        default_mode: str = "bm25",
        default_top_k: int = 5,
    ) -> None:
        super().__init__(strategies=strategies, default_mode=default_mode, default_top_k=default_top_k)
        self.source = source

    def fetch_candidates(self, query: str, top_k: int = 20) -> List[SearchCandidate]:
        return self.source.fetch_candidates(query, top_k=top_k)


class DocumentSearch(DocSearch):
    def __init__(
        self,
        db_path: str = "searchbox.db",
        default_top_k: int = 5,
        chunk_size: int = 240,
        chunk_overlap: int = 40,
        repository: Optional[DocumentRepository] = None,
        source: Optional[CandidateSource] = None,
        strategies: Optional[Mapping[str, SearchStrategy]] = None,
        extractor: Optional[FileTextExtractor] = None,
        default_mode: str = "bm25",
    ) -> None:
        repository = repository or SqliteDocumentRepository(db_path=db_path)
        extractor = extractor or FileTextExtractor()
        source = source or RepositoryCandidateSource(repository)
        strategies = dict(strategies or {"bm25": BM25SearchStrategy()})
        if default_mode not in strategies:
            raise ValueError("`default_mode` must exist in `strategies`.")

        self.repository = repository
        self.extractor = extractor
        self.ingestor = DocumentIngestor(
            repository=repository,
            extractor=extractor,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )

        super().__init__(
            source=source,
            strategies=strategies,
            default_mode=default_mode,
            default_top_k=default_top_k,
        )

    def add_path(
        self,
        path: str,
        recursive: bool = True,
        include_hidden: bool = False,
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[int] = None,
    ) -> List[str]:
        return self.ingestor.add_path(
            path=path,
            recursive=recursive,
            include_hidden=include_hidden,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )

    def add_paths(
        self,
        paths: Sequence[str],
        recursive: bool = True,
        include_hidden: bool = False,
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[int] = None,
    ) -> List[str]:
        return self.ingestor.add_paths(
            paths=paths,
            recursive=recursive,
            include_hidden=include_hidden,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )

    def response(
        self,
        query: str,
        top_k: Optional[int] = None,
        mode: Optional[str] = None,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        return self.search(query=query, top_k=top_k, mode=mode, **kwargs)

    def search(
        self,
        query: str,
        mode: Optional[str] = None,
        top_k: Optional[int] = None,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        limit = top_k or self.default_top_k
        chunk_hits = super().search(query=query, mode=mode, top_k=limit, **kwargs)
        if not chunk_hits:
            return []
        return self._aggregate_hits(chunk_hits=chunk_hits, limit=limit)

    def search_pretty(
        self,
        query: str,
        top_k: Optional[int] = None,
        mode: Optional[str] = None,
        snippet_length: int = 280,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        if snippet_length <= 0:
            raise ValueError("`snippet_length` must be greater than 0.")

        results = self.search(query=query, top_k=top_k, mode=mode, **kwargs)
        pretty_results: List[Dict[str, Any]] = []
        for item in results:
            metadata = item.get("metadata", {})
            snippet = item.get("content", "")
            if len(snippet) > snippet_length:
                snippet = f"{snippet[: snippet_length - 3].rstrip()}..."
            pretty_results.append(
                {
                    "path": item["id"],
                    "file_name": metadata.get("source_name") or item.get("title"),
                    "score": item["score"],
                    "matched_chunk_count": len(metadata.get("matched_chunks", [])),
                    "matched_chunks": metadata.get("matched_chunks", []),
                    "best_chunk_index": metadata.get("best_chunk_index"),
                    "snippet": snippet,
                }
            )
        return pretty_results

    def supported_extensions(self) -> List[str]:
        return self.ingestor.supported_extensions()

    def count(self) -> int:
        return self.repository.count()

    def clear(self) -> None:
        self.repository.clear()

    def _aggregate_hits(self, chunk_hits: Sequence[Dict[str, Any]], limit: int) -> List[Dict[str, Any]]:
        grouped: Dict[str, Dict[str, Any]] = {}
        for hit in chunk_hits:
            metadata = hit.get("metadata", {})
            source_path = metadata.get("source_path") or hit["id"]
            existing = grouped.get(source_path)
            if existing is None:
                grouped[source_path] = {
                    "id": source_path,
                    "title": metadata.get("source_name") or hit.get("title") or source_path,
                    "content": hit["content"],
                    "metadata": {
                        "source_path": source_path,
                        "source_name": metadata.get("source_name"),
                        "chunk_count": metadata.get("chunk_count", 1),
                        "matched_chunks": [metadata.get("chunk_index", 0)],
                        "best_chunk_index": metadata.get("chunk_index", 0),
                        "best_chunk_score": hit["score"],
                    },
                    "score": round(hit["score"], 6),
                }
                continue

            existing["metadata"]["matched_chunks"].append(metadata.get("chunk_index", 0))
            best_chunk_score = existing["metadata"].get("best_chunk_score", existing["score"])
            existing["score"] = round(existing["score"] + (hit["score"] * 0.15), 6)
            if hit["score"] > best_chunk_score:
                existing["content"] = hit["content"]
                existing["metadata"]["best_chunk_index"] = metadata.get("chunk_index", 0)
                existing["metadata"]["best_chunk_score"] = hit["score"]

        results = list(grouped.values())
        for item in results:
            item["metadata"]["matched_chunks"] = sorted(set(item["metadata"]["matched_chunks"]))
            item["metadata"].pop("best_chunk_score", None)
        results.sort(key=lambda item: item["score"], reverse=True)
        return results[:limit]
