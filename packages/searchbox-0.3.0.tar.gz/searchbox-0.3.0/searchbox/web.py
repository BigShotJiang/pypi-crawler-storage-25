from __future__ import annotations

from typing import Mapping

from .base import BaseSearch
from .search_types import SearchCandidate
from .sources import CandidateSource, WebCandidateSource
from .strategies import BM25SearchStrategy, SearchStrategy


class WebSearch(BaseSearch):
    def __init__(
        self,
        web_fetcher,
        strategies: Mapping[str, SearchStrategy] | None = None,
        default_mode: str = "bm25",
        default_top_k: int = 5,
    ) -> None:
        strategies = dict(strategies or {"bm25": BM25SearchStrategy()})
        self.source: CandidateSource = WebCandidateSource(web_fetcher)
        super().__init__(strategies=strategies, default_mode=default_mode, default_top_k=default_top_k)

    def fetch_candidates(self, query: str, top_k: int = 20) -> list[SearchCandidate]:
        return self.source.fetch_candidates(query, top_k=top_k)
