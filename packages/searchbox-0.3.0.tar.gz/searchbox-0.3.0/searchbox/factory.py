from __future__ import annotations

from typing import Mapping, Optional

from .document import DocumentSearch
from .extractors import FileTextExtractor
from .repository import DocumentRepository, SqliteDocumentRepository
from .strategies import BM25SearchStrategy, SearchStrategy
from .web import WebSearch


class SearchFactory:
    @staticmethod
    def default_strategies() -> Mapping[str, SearchStrategy]:
        return {"bm25": BM25SearchStrategy()}

    @staticmethod
    def create_doc_search(
        db_path: str = "searchbox.db",
        repository: Optional[DocumentRepository] = None,
        extractor: Optional[FileTextExtractor] = None,
        strategies: Optional[Mapping[str, SearchStrategy]] = None,
        chunk_size: int = 240,
        chunk_overlap: int = 40,
        default_top_k: int = 5,
        default_mode: str = "bm25",
    ) -> DocumentSearch:
        repository = repository or SqliteDocumentRepository(db_path=db_path)
        strategies = strategies or SearchFactory.default_strategies()
        return DocumentSearch(
            db_path=db_path,
            repository=repository,
            extractor=extractor,
            strategies=strategies,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            default_top_k=default_top_k,
            default_mode=default_mode,
        )

    @staticmethod
    def create_web_search(
        web_fetcher,
        strategies: Optional[Mapping[str, SearchStrategy]] = None,
        default_mode: str = "bm25",
        default_top_k: int = 5,
    ) -> WebSearch:
        return WebSearch(
            web_fetcher=web_fetcher,
            strategies=strategies or SearchFactory.default_strategies(),
            default_mode=default_mode,
            default_top_k=default_top_k,
        )
