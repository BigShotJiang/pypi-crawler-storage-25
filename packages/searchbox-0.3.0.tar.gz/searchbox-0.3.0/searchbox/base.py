from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Mapping, Optional

from .search_types import SearchCandidate
from .strategies import SearchStrategy


class BaseSearch(ABC):
    def __init__(
        self,
        strategies: Mapping[str, SearchStrategy],
        default_mode: str,
        default_top_k: int = 5,
    ) -> None:
        if not strategies:
            raise ValueError("`strategies` must not be empty.")
        if default_mode not in strategies:
            raise ValueError("`default_mode` must exist in `strategies`.")
        self.strategies = dict(strategies)
        self.default_mode = default_mode
        self.default_top_k = default_top_k

    @abstractmethod
    def fetch_candidates(self, query: str, top_k: int = 20) -> List[SearchCandidate]:
        raise NotImplementedError

    def search(
        self,
        query: str,
        mode: Optional[str] = None,
        top_k: Optional[int] = None,
        candidate_multiplier: int = 2,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        effective_mode = mode or self.default_mode
        if effective_mode not in self.strategies:
            raise ValueError(f"Unknown search mode: {effective_mode}")

        limit = top_k or self.default_top_k
        candidates = self.fetch_candidates(query, top_k=max(limit * candidate_multiplier, limit))
        results = self.strategies[effective_mode].search(query, candidates, top_k=limit, **kwargs)
        return results[:limit]
