# ntsc-encoder (pybind11)

This directory builds the `ntsc_encoder` Python extension module using C++/pybind11.

## Requirements

- Python 3.9+
- A C++ compiler + CMake 3.18+
- No OpenCV dependency is required to build/install this wheel.
  The input is a NumPy HxWx3 `uint8` array (e.g. produced by `cv2.imread()` + `cv2.cvtColor`).
- Build tools:
  - `python -m pip install -U build twine`

## Build a wheel/sdist locally

From this directory (`Code/Encoder`):

```bash
python -m pip install -U pip
python -m pip install -U build twine scikit-build-core pybind11 numpy
python -m build
```

Artifacts will appear in `dist/`.

Check metadata:

```bash
twine check dist/*
```

## Upload to PyPI

Recommended: upload to TestPyPI first.

```bash
# TestPyPI
python -m twine upload -r testpypi dist/*

# PyPI
python -m twine upload dist/*
```

You’ll need an API token configured in `~/.pypirc` or exported via environment variables.

## Building wheels for multiple platforms (recommended)

To avoid requiring end users to have a compiler + OpenCV dev libs, publish prebuilt wheels.
Typical approach: GitHub Actions + `cibuildwheel`.

High-level steps:
1. Add `cibuildwheel` workflow
2. Build wheels for Linux (manylinux), macOS, Windows
3. Upload wheels + sdist with `twine`

If you want, I can add a ready-to-use GitHub Actions workflow for `cibuildwheel`.

## Troubleshooting

If `pip install ntsc-encoder` succeeds but `import ntsc_encoder` fails, it usually means the wheel did not contain the compiled extension (or it was installed into the wrong location). For scikit-build-core, ensure `CMakeLists.txt` has `install(TARGETS ntsc_encoder ... DESTINATION ${SKBUILD_PLATLIB_DIR})`.
