#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include "encoder.cpp"

namespace py = pybind11;

static py::buffer_info checked_rgb_buffer(const py::array& input) {
    auto buf = input.request();
    if (buf.ndim != 3 || buf.shape[2] != 3) {
        throw std::runtime_error("Expected HxWx3 uint8 image");
    }
    if (buf.itemsize != 1) {
        throw std::runtime_error("Expected uint8 image");
    }
    // Ensure C-contiguous HxWx3
    const auto h = buf.shape[0];
    const auto w = buf.shape[1];
    if (buf.strides[2] != 1 || buf.strides[1] != 3 || buf.strides[0] != static_cast<ssize_t>(w * 3)) {
        throw std::runtime_error("Expected contiguous HxWx3 image (RGB)");
    }
    return buf;
}

PYBIND11_MODULE(ntsc_encoder, m) {
    py::class_<Encoder>(m, "Encoder")
        .def(py::init([](py::array input, uint dac_bits, double dac_frequency_hz) {
            auto buf = checked_rgb_buffer(input);
            const uint h = static_cast<uint>(buf.shape[0]);
            const uint w = static_cast<uint>(buf.shape[1]);

            return new Encoder(static_cast<const uint8_t*>(buf.ptr), w, h, dac_bits, dac_frequency_hz);
        }), py::arg("image"), py::arg("dac_bits") = 8, py::arg("dac_frequency_hz") = 14.318e6)
        .def("encode", &Encoder::encode)
        .def("save_as_c_header", &Encoder::save_as_c_header)
        .def("get_samples_per_line", &Encoder::get_samples_per_line)
        .def("get_framebuffer", [](Encoder& self) {
            uint16_t* data = self.get_encoded_framebuffer();
            size_t total = (size_t)262 * self.get_samples_per_line();
            py::array_t<uint16_t> result(total);
            std::memcpy(result.mutable_data(), data, total * sizeof(uint16_t));
            return result;
        });
}
