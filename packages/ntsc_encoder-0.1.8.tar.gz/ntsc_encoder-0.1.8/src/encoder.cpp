#include <cstdint>
#include <cassert>
#include <ostream>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

class Encoder {
    // NTSC timing constants (в секундах)
    static constexpr double NTSC_H_PERIOD_S = 63.556e-6;      // Период горизонтальной строки
    static constexpr double NTSC_HSYNC_S = 4.7e-6;             // Длительность HSYNC
    static constexpr double NTSC_EQUALIZING_PULSE_S = 2.0e-6;  // Длительность equalizing pulse
    static constexpr double NTSC_VERTICAL_SERRATION_S = 4.7e-6; // Длительность vertical serration
    static constexpr double NTSC_BURST_FRONT_PORCH_S = 0.75e-6; // Front porch перед burst
    static constexpr double NTSC_BURST_BACK_PORCH_S = 5.8e-6;   // Back porch (включая burst)
    
    static constexpr auto NTSC_TOTAL_LINES = 262;
    static constexpr auto NTSC_ACTIVE_VIDEO_START_LINE = 21;
    static constexpr auto NTSC_SETUP_IRE = 7.5;
    static constexpr auto NTSC_SCALE_Y = ((100 - NTSC_SETUP_IRE) / 100);
    static constexpr auto NTSC_LEVEL_SYNC_IRE = -40.0;
    static constexpr auto NTSC_LEVEL_BLANK_IRE = 0.0;
    static constexpr auto NTSC_LEVEL_WHITE_IRE = 100.0;
    static constexpr auto NTSC_LEVEL_BLACK_IRE = NTSC_LEVEL_BLANK_IRE + NTSC_SETUP_IRE;
    static constexpr auto NTSC_LEVEL_BURST_HIGH_IRE = 20.0;
    static constexpr auto NTSC_LEVEL_BURST_LOW_IRE = -20.0;
    static constexpr auto NTSC_MAXIMUM_CHROMA_EXTRUSION_IRE = 131.0;
    static constexpr auto NTSC_COMPOSITE_AMPLITUDE_IRE = (NTSC_MAXIMUM_CHROMA_EXTRUSION_IRE - NTSC_LEVEL_SYNC_IRE);
    static constexpr auto NTSC_LEVEL_SYNC_DAC = 0.0;


    private:
        // Ширина и высота изображения
        uint width;
        uint height;

        // Размерности DAC (цифрового-аналогового преобразователя)
        uint dac_bits;
        uint dac_scale;
        double dac_frequency_hz;  // Частота дискретизации ЦАП

        // Динамические параметры семплирования (вычисляются из dac_frequency_hz)
        uint samples_per_line;
        uint hsync_width;
        uint equalizing_pulse_width;
        uint vertical_serration_width;
        uint color_burst_front_porch;
        uint color_burst_back_porch;

        // Уровни сигнала в единицах DAC для различных частей NTSC сигнала
        int ntsc_level_blank_dac;
        int ntsc_level_black_dac;
        int ntsc_level_burst_low_dac;
        int ntsc_level_burst_high_dac;

        // RGB image stored as tightly packed bytes: row-major, 3 bytes per pixel.
        std::vector<uint8_t> image_rgb;
        uint16_t* encoded_ntsc_framebuffer;  // Динамический буфер


        inline int32_t ntsc_set_color(uint8_t red, uint8_t green, uint8_t blue, int phase) {
            red = (uint8_t)(((double) red / 255) * 100);
            green = (uint8_t)(((double) green / 255) * 100);
            blue = (uint8_t)(((double) blue / 255) * 100);

            const double luminance = (0.587 * green + 0.114 * blue + 0.299 * red);
            const double u_comp = (blue - luminance) * 0.4921;   // U component
            const double v_comp = (red - luminance) * 0.8773;    // V component

            assert(phase == 0 || phase == 90 || phase == 180 || phase == 270);

            double vanilla_signal = 0.0;

            if (phase == 0) {
                vanilla_signal = luminance + v_comp;   // cos(0)=1, sin(0)=0
            }

            if (phase == 90) {
                vanilla_signal = luminance + u_comp;   // cos(90)=0, sin(90)=1
            }

            if (phase == 180) {
                vanilla_signal = luminance - v_comp;   // cos(180)=-1, sin(180)=0
            }

            if (phase == 270) {
                vanilla_signal = luminance - u_comp;   // cos(270)=0, sin(270)=-1
            }

            return (int32_t)(NTSC_SCALE_Y * vanilla_signal + NTSC_SETUP_IRE) * this->dac_scale + this->ntsc_level_blank_dac;
        }

        inline void equalizing(uint16_t *buffer) {
          uint16_t *current = buffer;
          uint16_t *next_front = current + this->equalizing_pulse_width;
          while (current < next_front)
            *current++ = NTSC_LEVEL_SYNC_DAC;
          next_front = buffer + this->samples_per_line / 2;
          while (current < next_front)
            *current++ = this->ntsc_level_black_dac;
          next_front = current + this->equalizing_pulse_width;
          while (current < next_front)
            *current++ = NTSC_LEVEL_SYNC_DAC;
          next_front = buffer + this->samples_per_line;
          while (current < next_front)
            *current++ = this->ntsc_level_blank_dac;
        }

        inline void vertical_sync(uint16_t *buffer) {
          uint16_t *current = buffer;
          uint16_t *next_front =
              buffer + this->samples_per_line / 2 - this->vertical_serration_width;
          while (current < next_front)
            *current++ = NTSC_LEVEL_SYNC_DAC;
          next_front = current + this->vertical_serration_width;
          while (current < next_front)
            *current++ = this->ntsc_level_blank_dac;
          next_front = buffer + this->samples_per_line - this->vertical_serration_width;
          while (current < next_front)
            *current++ = NTSC_LEVEL_SYNC_DAC;
          next_front = buffer + this->samples_per_line;
          while (current < next_front)
            *current++ = this->ntsc_level_blank_dac;
        }

        inline void blank(uint16_t *buffer) {
          uint16_t *current = buffer;
          uint16_t *next_front = buffer + this->samples_per_line;
          while (current < next_front)
            *current++ = this->ntsc_level_blank_dac;
        }

        inline void blank_line(uint16_t *buffer) {
          uint16_t *current = buffer;
          uint16_t *next_front = buffer + this->hsync_width;
          while (current < next_front)
            *current++ = NTSC_LEVEL_SYNC_DAC;
          next_front = current + this->color_burst_front_porch;
          while (current < next_front)
            *current++ = this->ntsc_level_blank_dac;
          for (int j = 0; j < 9; j++) {
            *current++ = this->ntsc_level_blank_dac;      // Phase 0°
            *current++ = this->ntsc_level_burst_low_dac;  // Phase 90°
            *current++ = this->ntsc_level_blank_dac;      // Phase 180°
            *current++ = this->ntsc_level_burst_high_dac; // Phase 270°
          }
          next_front = buffer + this->samples_per_line;
          while (current < next_front)
            *current++ = this->ntsc_level_blank_dac;
        }

        inline void active_video(uint16_t *buffer, const size_t scanline_number) {
          uint16_t *current = buffer;
          uint16_t *next_front = current + this->hsync_width;
          while (current < next_front)
            *current++ = NTSC_LEVEL_SYNC_DAC;
          next_front = current + this->color_burst_front_porch;

          while (current < next_front)
            *current++ = this->ntsc_level_blank_dac;
          for (int j = 0; j < 9; j++) {
            *current++ = this->ntsc_level_blank_dac;      // Phase 0°
            *current++ = this->ntsc_level_burst_low_dac;  // Phase 90°
            *current++ = this->ntsc_level_blank_dac;      // Phase 180°
            *current++ = this->ntsc_level_burst_high_dac; // Phase 270°
          }

          next_front = current + this->color_burst_back_porch;
          while (current < next_front) {
            *current++ = this->ntsc_level_blank_dac;
          }


        // Отрисовка вся здесь
        auto image_row = scanline_number - NTSC_ACTIVE_VIDEO_START_LINE;
        const uint8_t* row_ptr = this->image_rgb.data() + (static_cast<size_t>(image_row) * this->width * 3);

          for (int pixel_index = 0; pixel_index < this->width; pixel_index++) {
            auto r = row_ptr[pixel_index * 3 + 0];
            auto g = row_ptr[pixel_index * 3 + 1];
            auto b = row_ptr[pixel_index * 3 + 2];

            uint16_t phase0, phase1;

            if (pixel_index & 1) {
                // Нечетный пиксель: фазы 180° и 270°
                phase0 = ntsc_set_color(r, g, b, 180);
                phase1 = ntsc_set_color(r, g, b, 270);
            } else {
                // Четный пиксель: фазы 0° и 90°
                phase0 = ntsc_set_color(r, g, b, 0);
                phase1 = ntsc_set_color(r, g, b, 90);
            }


            *(uint32_t *)current = ((uint32_t)phase1 << 16) | phase0;
            current += 2;
          }

          next_front = buffer + this->samples_per_line;
          while (current < next_front)
            *current++ = this->ntsc_level_blank_dac;
        }

        inline void ntsc_generate_scanline(uint16_t *output_buffer, const size_t scanline_number) {
            uint16_t *buffer_ptr = output_buffer;

            // Vertical blanking interval (lines 0-8)
            if (scanline_number <= 2 || (scanline_number >= 6 && scanline_number <= 8)) {
                equalizing(buffer_ptr);
            }
            else if (scanline_number >= 3 && scanline_number <= 5) {
                vertical_sync(buffer_ptr);
            }
            // Active video or blanking
            else if (scanline_number < NTSC_ACTIVE_VIDEO_START_LINE ||
                     scanline_number >= NTSC_ACTIVE_VIDEO_START_LINE + this->height) {
                blank_line(buffer_ptr);
            }
            else {
                active_video(buffer_ptr, scanline_number);
            }
        }


    public:
        Encoder(const uint8_t* rgb_data, uint width, uint height, uint dac_bits = 8, double dac_frequency_hz = 14.318e6) {
            this->width = width;
            this->height = height;
            this->dac_bits = dac_bits;
            this->dac_frequency_hz = dac_frequency_hz;

            // Вычисляем все параметры семплирования на основе DAC частоты
            uint raw_spl = (uint)(dac_frequency_hz * NTSC_H_PERIOD_S + 0.5);
            // Округляем вверх до ближайшего кратного 4 (для синхронного детектирования)
            this->samples_per_line = ((raw_spl + 3) / 4) * 4;
            
            this->hsync_width = (uint)(dac_frequency_hz * NTSC_HSYNC_S + 0.5);
            this->equalizing_pulse_width = (uint)(dac_frequency_hz * NTSC_EQUALIZING_PULSE_S + 0.5);
            this->vertical_serration_width = (uint)(dac_frequency_hz * NTSC_VERTICAL_SERRATION_S + 0.5);
            this->color_burst_front_porch = (uint)(dac_frequency_hz * NTSC_BURST_FRONT_PORCH_S + 0.5);
            this->color_burst_back_porch = (uint)(dac_frequency_hz * NTSC_BURST_BACK_PORCH_S + 0.5);

            this->image_rgb.assign(rgb_data, rgb_data + (static_cast<size_t>(width) * height * 3));

            // Выделяем динамический буфер
            this->encoded_ntsc_framebuffer = new uint16_t[NTSC_TOTAL_LINES * this->samples_per_line]{0};

            this->dac_scale = (1 << this->dac_bits) / NTSC_COMPOSITE_AMPLITUDE_IRE;
            this->ntsc_level_blank_dac = (NTSC_LEVEL_BLANK_IRE - NTSC_LEVEL_SYNC_IRE) * this->dac_scale;
            this->ntsc_level_black_dac = (NTSC_LEVEL_BLACK_IRE - NTSC_LEVEL_SYNC_IRE) * this->dac_scale;
            this->ntsc_level_burst_low_dac = (NTSC_LEVEL_BURST_LOW_IRE - NTSC_LEVEL_SYNC_IRE) * this->dac_scale;
            this->ntsc_level_burst_high_dac = (NTSC_LEVEL_BURST_HIGH_IRE - NTSC_LEVEL_SYNC_IRE) * this->dac_scale;
        }
        
        ~Encoder() {
            delete[] this->encoded_ntsc_framebuffer;
        }


        inline void encode() {
            for (size_t current_scanline = 0; current_scanline < NTSC_TOTAL_LINES; ++current_scanline) {
                uint16_t* line_buffer = encoded_ntsc_framebuffer + current_scanline * this->samples_per_line;
                ntsc_generate_scanline(line_buffer, current_scanline);
            }
        }

        inline uint16_t* get_encoded_framebuffer() {
            return this->encoded_ntsc_framebuffer;
        }
        
        inline uint get_samples_per_line() const {
            return this->samples_per_line;
        }

        void save_as_c_header(const string& filename) {
            ofstream out(filename);

            if (!out) {
                cerr << "Failed to create " << filename << endl;
                return;
            }

            out << "// Auto-generated NTSC frame data\n";
            out << "#include <stdint.h>\n\n";

            out << "static uint16_t frame_data["
                << (NTSC_TOTAL_LINES * this->samples_per_line)
                << "] = {\n";

            size_t total = NTSC_TOTAL_LINES * this->samples_per_line;

            for (size_t i = 0; i < total; i++) {
                if (i % 8 == 0) out << "    ";  // Отступ

                out << encoded_ntsc_framebuffer[i];

                if (i < total - 1) out << ",";
                if (i % 8 == 7) out << "\n";    // 8 значений на строку
            }

            out << "\n};\n";
            out << "const unsigned int frame_data_len = " << total << ";\n";

            out.close();
            cout << "Saved: " << filename << " (" << total << " values)" << endl;
        }
};
