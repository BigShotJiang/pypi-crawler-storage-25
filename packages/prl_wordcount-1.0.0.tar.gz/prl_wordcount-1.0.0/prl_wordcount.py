#!/usr/bin/env python3
"""
PRL Word Count Analyzer
=======================
Automated word-count analysis for Physical Review Letters (PRL) submissions.
Runs texcount, parses equations & figures, applies APS conversion formulas,
and generates an HTML report.

Usage:
    prl-wordcount path/to/paper.tex [-o report.html] [--open] [--limit N]

Requirements:
    - texcount (Perl script) in PATH
    - Python 3.8+

Install:
    pip install prl-wordcount
    # or: pip install -e .
"""

import subprocess, re, os, sys, json, struct, argparse, webbrowser
from pathlib import Path
from datetime import date

__version__ = "1.0.0"

# ---------------------------------------------------------------------------
# PRL conversion constants
# ---------------------------------------------------------------------------
WORDS_PER_EQ_ROW_1COL = 16    # single-column equation row
WORDS_PER_EQ_ROW_2COL = 32    # two-column equation row (wide)
DEFAULT_LIMIT = 3750          # PRL Letter limit


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def run(cmd_args, cwd=None):
    """Run a command as a list of arguments, return stdout or '' on failure."""
    try:
        return subprocess.check_output(
            cmd_args, text=True, stderr=subprocess.DEVNULL, cwd=cwd
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return ''


def read_file(path):
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()


def get_png_size(filepath):
    """Read PNG dimensions from IHDR chunk without external libraries."""
    try:
        with open(filepath, 'rb') as f:
            f.read(8)          # PNG signature
            f.read(4)          # IHDR length
            f.read(4)          # 'IHDR'
            w = struct.unpack('>I', f.read(4))[0]
            h = struct.unpack('>I', f.read(4))[0]
            return w, h
    except Exception:
        return None, None


def get_jpg_size(filepath):
    """Read JPEG dimensions without external libraries (simple parser)."""
    try:
        with open(filepath, 'rb') as f:
            f.read(2)
            while True:
                marker = f.read(2)
                if marker[0] != 0xFF:
                    return None, None
                if marker[1] in (0xC0, 0xC2):  # SOF0, SOF2
                    f.read(3)
                    h = struct.unpack('>H', f.read(2))[0]
                    w = struct.unpack('>H', f.read(2))[0]
                    return w, h
                length = struct.unpack('>H', f.read(2))[0]
                f.read(length - 2)
    except Exception:
        return None, None


def get_image_size(filepath):
    """Return (width, height) for common image formats."""
    ext = Path(filepath).suffix.lower()
    if ext == '.png':
        return get_png_size(filepath)
    elif ext in ('.jpg', '.jpeg'):
        return get_jpg_size(filepath)
    elif ext == '.pdf':
        try:
            text = run(['pdfinfo', str(filepath)])
            if text:
                m = re.search(r'Page size:\s+([\d.]+)\s+x\s+([\d.]+)', text)
                if m:
                    return float(m.group(1)), float(m.group(2))
        except Exception:
            pass
        return None, None
    else:
        return None, None


# ---------------------------------------------------------------------------
# TeX parsing
# ---------------------------------------------------------------------------

class TeXParser:
    """Minimal LaTeX parser for equation/figure inventory."""

    def __init__(self, tex_path, tex_dir):
        self.path = tex_path
        self.dir = tex_dir
        self.text = read_file(tex_path)
        self.text = re.sub(r'(?<!\\)%.*', '', self.text)

    def split_main_appendix(self):
        """Split source at \\appendix, return (main_body, appendix)."""
        parts = re.split(r'\\appendix\b', self.text, maxsplit=1)
        if len(parts) == 2:
            return parts[0], parts[1]
        return self.text, ''

    def count_equation_rows(self, text):
        """Count displayed equation rows in a text block.

        Returns: (num_environments, num_rows, list_of_details)
        """
        results = []

        # equation / equation* environments (may contain aligned/gathered/split)
        for m in re.finditer(
            r'\\begin\{equation\*?\}(.*?)\\end\{equation\*?\}', text, re.DOTALL
        ):
            body = m.group(1)
            rows = body.count('\\\\') + 1
            sub_env_rows = 0
            for sub_m in re.finditer(
                r'\\begin\{(aligned|gathered|split|align|align\*|eqnarray\*?)\}'
                r'(.*?)\\end\{\1\}', body, re.DOTALL
            ):
                sub_body = sub_m.group(2)
                sub_env_rows += sub_body.count('\\\\') + 1
            if sub_env_rows > 0:
                rows = sub_env_rows + (1 if rows > 1 else 0)

            results.append({
                'rows': max(rows, 1),
                'type': 'equation',
                'snippet': body.strip()[:80]
            })

        # align / align* / eqnarray environments (standalone)
        for m in re.finditer(
            r'\\begin\{(align\*?|eqnarray\*?)\}(.*?)\\end\{\1\}', text, re.DOTALL
        ):
            body = m.group(2)
            rows = body.count('\\\\') + 1
            results.append({
                'rows': max(rows, 1),
                'type': m.group(1),
                'snippet': body.strip()[:80]
            })

        num_envs = len(results)
        num_rows = sum(r['rows'] for r in results)
        return num_envs, num_rows, results

    def find_figures(self, text):
        """Find all figure includes and extract image paths.

        Returns list of dicts.
        """
        figures = []

        for m in re.finditer(
            r'\\begin\{(figure\*?)\}(.*?)\\end\{\1\}',
            text, re.DOTALL
        ):
            body = m.group(2)
            is_wide = (m.group(1) == 'figure*')
            label = ''
            lm = re.search(r'\\label\{([^}]+)\}', body)
            if lm:
                label = lm.group(1)

            img_m = re.search(
                r'\\includegraphics\s*(\[[^\]]*\])?\s*\{([^}]+)\}',
                body
            )
            if not img_m:
                continue

            img_path = img_m.group(2)
            resolved = self._resolve_path(img_path)

            opts = img_m.group(1) or ''
            env_width = None
            env_height = None
            wm = re.search(r'width\s*=\s*([0-9.]+)\s*\\(?:textwidth|columnwidth)', opts)
            hm = re.search(r'height\s*=\s*([0-9.]+)\s*\\(?:textheight|textwidth)', opts)
            if wm:
                env_width = float(wm.group(1))
            if hm:
                env_height = float(hm.group(1))

            keepaspect = 'keepaspectratio' in opts

            cap_words = 0
            cap_m = re.search(r'\\caption\{(.*?)\}(?:\s*\\label|\s*$)', body, re.DOTALL)
            if cap_m:
                cap_text = cap_m.group(1)
                cap_text = re.sub(r'\\[a-zA-Z]+\{.*?\}', '', cap_text)
                cap_text = re.sub(r'\\[a-zA-Z]+', '', cap_text)
                cap_text = re.sub(r'\$.*?\$', 'EQ', cap_text)
                cap_words = len(cap_text.split())

            figures.append({
                'path': resolved,
                'label': label,
                'is_wide': is_wide,
                'env_width': env_width,
                'env_height': env_height,
                'keepaspect': keepaspect,
                'caption_words': cap_words,
            })

        return figures

    def _resolve_path(self, img_path):
        """Resolve image path relative to tex file directory."""
        if not Path(img_path).suffix:
            for ext in ['.png', '.jpg', '.jpeg', '.pdf', '.eps']:
                candidate = Path(self.dir) / (img_path + ext)
                if candidate.exists():
                    return str(candidate)
        candidate = Path(self.dir) / img_path
        if candidate.exists():
            return str(candidate)
        return str(Path(self.dir) / img_path)


# ---------------------------------------------------------------------------
# PRL formula application
# ---------------------------------------------------------------------------

def figure_word_count(is_wide, aspect_ratio):
    """Compute PRL word-equivalent for a figure."""
    if is_wide:
        return round(300.0 / aspect_ratio + 40)
    else:
        return round(150.0 / aspect_ratio + 20)


# ---------------------------------------------------------------------------
# HTML report generator
# ---------------------------------------------------------------------------

def generate_html(report):
    """Generate standalone HTML report from report dict."""

    limit = report.get('word_limit', DEFAULT_LIMIT)

    def esc(s):
        return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

    # ---- Section table rows ----
    sec_rows = ''
    for s in report['sections']:
        style = 'style="color:#9ca3af"' if s.get('excluded') else ''
        sec_rows += f'''
        <tr {style}>
            <td>{esc(s['name'])}</td>
            <td class="num">{s['text']}</td>
            <td class="num">{s['header']}</td>
            <td class="num">{s['caption']}</td>
            <td class="num">{s['inlines']}</td>
            <td class="num">{s['displayed']}</td>
        </tr>'''

    # ---- Equation rows ----
    eq_rows = ''
    for eq in report['main_equations']:
        cls = 'multi' if eq['rows'] > 1 else ''
        eq_rows += f'''
        <div class="eq-item {cls}">
            <span>{esc(eq['label'])}</span>
            <span class="rows">{eq['rows']} row{"s" if eq["rows"]>1 else ""}</span>
        </div>'''

    # ---- Figure cards ----
    fig_cards = ''
    for f in report['figures']:
        tag_cls = 'ok' if not f.get('missing') else 'bad'
        col_type = 'figure* (2-col)' if f['is_wide'] else 'figure (1-col)'
        dims = f'{f["img_w"]}&times;{f["img_h"]} px' if f.get('img_w') else 'unknown dimensions'
        formula = f'300 / {f["aspect"]:.3f} + 40' if f['is_wide'] else f'150 / {f["aspect"]:.3f} + 20'
        fig_cards += f'''
        <div class="fig-card">
            <div>
                <strong>{esc(f['label'])}</strong> &mdash; {esc(f.get('caption_preview', ''))}<br>
                <span class="dims">{dims} &middot; aspect = {f["aspect"]:.3f} &middot;
                <span class="tag {tag_cls}">{col_type}</span></span>
            </div>
            <div>
                <div style="font-size:0.8rem;color:var(--muted)">{formula}</div>
                <div class="count">{f['prl_words']} words</div>
            </div>
        </div>'''

    # ---- Composition bars ----
    total = report['prl_total']
    body_pct = report['body_text_words'] / total * 100
    cap_pct = report['caption_words'] / total * 100
    eq_pct = report['eq_words'] / total * 100
    fig_pct = report['figure_words'] / total * 100
    limit_pct = limit / total * 100

    over_under = "Over" if total > limit else "Under"
    delta = abs(total - limit)
    verdict_cls = 'over' if total > limit else 'ok'

    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PRL Word Count — {esc(report['filename'])}</title>
<style>
  :root {{
    --bg: #ffffff; --text: #1a1a2e; --muted: #6b7280; --border: #e5e7eb;
    --accent: #2563eb; --accent-light: #eff6ff;
    --warn: #dc2626; --warn-light: #fef2f2;
    --green: #059669; --green-light: #ecfdf5;
    --amber: #d97706; --amber-light: #fffbeb;
    --radius: 8px;
  }}
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: #f8f9fb; color: var(--text); line-height: 1.6; padding: 40px 20px;
  }}
  .container {{ max-width: 960px; margin: 0 auto; }}
  h1 {{ font-size: 1.75rem; font-weight: 700; margin-bottom: 4px; }}
  h1 .file {{ color: var(--accent); }}
  .subtitle {{ color: var(--muted); font-size: 0.925rem; margin-bottom: 32px; }}
  h2 {{
    font-size: 1.2rem; font-weight: 600; margin: 40px 0 16px;
    padding-bottom: 8px; border-bottom: 2px solid var(--border);
  }}
  h3 {{ font-size: 1rem; font-weight: 600; margin: 24px 0 12px; color: #374151; }}
  .card {{
    background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 24px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.04);
  }}
  .stat-grid {{
    display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 12px; margin-bottom: 20px;
  }}
  .stat {{
    background: var(--bg); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 16px; text-align: center;
  }}
  .stat .value {{ font-size: 1.75rem; font-weight: 700; }}
  .stat .label {{ font-size: 0.8rem; color: var(--muted); margin-top: 2px; }}
  .stat.warn .value {{ color: var(--warn); }}
  .stat.good .value {{ color: var(--green); }}
  .verdict {{
    padding: 20px 24px; border-radius: var(--radius); margin-bottom: 24px;
  }}
  .verdict.over {{ background: var(--warn-light); border: 1px solid #fecaca; }}
  .verdict.ok {{ background: var(--green-light); border: 1px solid #a7f3d0; }}
  .verdict .big {{ font-size: 1.35rem; font-weight: 700; }}
  .verdict.over .big {{ color: var(--warn); }}
  .verdict.ok .big {{ color: var(--green); }}
  .verdict .detail {{ margin-top: 4px; font-size: 0.925rem; }}
  .verdict.over .detail {{ color: #991b1b; }}
  .verdict.ok .detail {{ color: #065f46; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 0.9rem; }}
  thead th {{
    text-align: left; font-weight: 600; font-size: 0.8rem; text-transform: uppercase;
    letter-spacing: 0.04em; color: var(--muted); padding: 8px 12px;
    border-bottom: 1px solid var(--border);
  }}
  tbody td {{ padding: 7px 12px; border-bottom: 1px solid #f3f4f6; }}
  tbody tr:last-child td {{ border-bottom: none; }}
  .num {{ text-align: right; font-variant-numeric: tabular-nums; }}
  .total-row td {{
    font-weight: 700; border-top: 2px solid var(--border); background: #fafbfc;
  }}
  .tag {{
    display: inline-block; font-size: 0.75rem; font-weight: 600;
    padding: 2px 8px; border-radius: 12px;
  }}
  .tag.ok {{ background: var(--green-light); color: var(--green); }}
  .tag.warn {{ background: var(--amber-light); color: var(--amber); }}
  .tag.bad {{ background: var(--warn-light); color: var(--warn); }}
  .bar-row {{
    display: flex; align-items: center; gap: 10px; margin-bottom: 6px; font-size: 0.875rem;
  }}
  .bar-label {{ width: 140px; text-align: right; flex-shrink: 0; color: #4b5563; }}
  .bar-track {{
    flex: 1; height: 20px; background: #f3f4f6; border-radius: 4px;
    overflow: hidden; position: relative;
  }}
  .bar-fill {{ height: 100%; border-radius: 4px; }}
  .bar-num {{ width: 60px; font-weight: 600; font-size: 0.85rem; }}
  .eq-grid {{
    display: grid; grid-template-columns: repeat(auto-fill, minmax(420px, 1fr)); gap: 6px;
  }}
  .eq-item {{
    display: flex; justify-content: space-between; padding: 5px 10px;
    background: #f9fafb; border-radius: 4px; font-size: 0.85rem;
  }}
  .eq-item .rows {{ color: var(--muted); }}
  .eq-item.multi {{ background: #eff6ff; }}
  .fig-card {{
    display: grid; grid-template-columns: 1fr auto; gap: 12px; padding: 10px 14px;
    background: #f9fafb; border-radius: 6px; margin-bottom: 8px;
    font-size: 0.875rem; align-items: center;
  }}
  .fig-card .dims {{ color: var(--muted); font-size: 0.8rem; }}
  .fig-card .count {{ font-weight: 700; color: var(--accent); font-size: 1.05rem; text-align: right; }}
  .rec {{
    padding: 12px 16px; background: #f0f9ff; border-left: 3px solid var(--accent);
    border-radius: 0 6px 6px 0; margin: 8px 0; font-size: 0.9rem;
  }}
  @media print {{ body {{ background: white; padding: 0; }} .card {{ box-shadow: none; break-inside: avoid; }} }}
</style>
</head>
<body>
<div class="container">

<h1>PRL Word Count Report &mdash; <span class="file">{esc(report['filename'])}</span></h1>
<p class="subtitle">Generated {date.today().isoformat()} &middot;
   PRL limit: <strong>{limit:,} words</strong> &middot;
   APS <em>Length Limits and Guidelines for Physical Review Article Types</em></p>

<div class="verdict {verdict_cls}">
  <div class="big">{'&#9888;' if total > limit else '&#10004;'} {over_under} PRL limit by {delta:,} words ({abs(total-limit)/limit*100:.0f}%)</div>
  <div class="detail">Estimated total: <strong>{total:,} words</strong> | PRL limit: <strong>{limit:,} words</strong></div>
</div>

<div class="stat-grid">
  <div class="stat {'warn' if total > limit else 'good'}"><div class="value">{total:,}</div><div class="label">PRL Estimated Total</div></div>
  <div class="stat"><div class="value">{limit:,}</div><div class="label">PRL Limit (Letter)</div></div>
  <div class="stat {'warn' if total > limit else 'good'}"><div class="value">{'+' if total > limit else ''}{delta:,}</div><div class="label">{'Overage' if total > limit else 'Remaining'}</div></div>
  <div class="stat"><div class="value">{report['body_text_words']:,}</div><div class="label">Body Text</div></div>
  <div class="stat"><div class="value">{report['eq_words']:,}</div><div class="label">Displayed Eqs ({report['main_eq_row_count']} rows)</div></div>
  <div class="stat"><div class="value">{report['figure_words']:,}</div><div class="label">Figures ({len(report['figures'])} total)</div></div>
  <div class="stat"><div class="value">{report['caption_words']:,}</div><div class="label">Figure Captions</div></div>
  <div class="stat"><div class="value">{report.get('appendix_text_words', 0):,}</div><div class="label">Appendix (excluded)</div></div>
</div>

<h2>1. Word Count Breakdown</h2>
<div class="card">
  <h3>Counted toward PRL limit</h3>
  <table>
    <thead><tr><th>Component</th><th class="num">Words</th><th>Notes</th></tr></thead>
    <tbody>
      <tr><td>Body text (excl. abstract)</td><td class="num">{report['body_text_words']:,}</td><td>Introduction through Conclusion</td></tr>
      <tr><td>Figure/table captions</td><td class="num">{report['caption_words']:,}</td><td>{len(report['figures'])} figures</td></tr>
      <tr><td>Displayed equations ({report['main_eq_row_count']} rows &times; {WORDS_PER_EQ_ROW_1COL})</td><td class="num">{report['eq_words']:,}</td><td>{report['main_eq_env_count']} equation environments</td></tr>
      <tr><td>Figure word-equivalents</td><td class="num">{report['figure_words']:,}</td><td>APS conversion formula</td></tr>
      <tr class="total-row"><td><strong>PRL Total</strong></td><td class="num"><strong>{total:,}</strong></td><td></td></tr>
    </tbody>
  </table>
</div>

<div class="card">
  <h3>Not counted (excluded by PRL rules)</h3>
  <table>
    <thead><tr><th>Component</th><th class="num">Words</th><th>Exclusion Rule</th></tr></thead>
    <tbody>
      <tr style="color:#9ca3af"><td>Abstract</td><td class="num">{report.get('abstract_words', 0)}</td><td>Abstract excluded</td></tr>
      <tr style="color:#9ca3af"><td>Title / Authors / Affiliations</td><td class="num">~30</td><td>Title, author byline excluded</td></tr>
      <tr style="color:#9ca3af"><td>References</td><td class="num">0</td><td>Bibliography excluded</td></tr>
      <tr style="color:#9ca3af"><td><strong>Appendix (End Matter)</strong></td><td class="num"><strong>{report.get('appendix_text_words', 0):,}</strong></td><td>Allowed up to ~2 extra pages</td></tr>
      <tr style="color:#9ca3af"><td>Appendix equations ({report.get('app_eq_row_count', 0)} rows)</td><td class="num">{report.get('app_eq_words', 0):,}</td><td>Part of End Matter</td></tr>
    </tbody>
  </table>
</div>

<h2>2. Body Text by Section</h2>
<div class="card">
  <table>
    <thead><tr><th>Section</th><th class="num">Text</th><th class="num">Header</th><th class="num">Caption</th><th class="num">Inlines</th><th class="num">Displayed</th></tr></thead>
    <tbody>{sec_rows}</tbody>
  </table>
</div>

<h2>3. Displayed Equation Inventory (Main Text)</h2>
<div class="card">
  <p style="font-size:0.875rem;color:var(--muted);margin-bottom:12px">
    Conversion: 1 row = <strong>{WORDS_PER_EQ_ROW_1COL} words</strong> (single-column equation).
    Total: {report['main_eq_env_count']} equations, {report['main_eq_row_count']} rows, <strong>{report['eq_words']} words</strong>.
  </p>
  <div class="eq-grid">{eq_rows}</div>
</div>

<h2>4. Figure Word-Equivalent Calculation</h2>
<div class="card">
  <p style="font-size:0.875rem;color:var(--muted);margin-bottom:16px">
    APS formulas. Single-column: <strong>(150 / aspect) + 20</strong> &nbsp;|&nbsp;
    Two-column: <strong>(300 / aspect) + 40</strong>
  </p>
  {fig_cards}
  <div style="margin-top:12px;font-weight:600;text-align:right">
    Figures total: <strong>{report['figure_words']} words</strong>
  </div>
</div>

<h2>5. Word Count Composition</h2>
<div class="card">
  <div class="bar-row">
    <span class="bar-label">Body text</span>
    <span class="bar-track"><span class="bar-fill" style="width:{body_pct:.1f}%;background:#2563eb"></span></span>
    <span class="bar-num">{report['body_text_words']:,}</span>
  </div>
  <div class="bar-row">
    <span class="bar-label">Captions</span>
    <span class="bar-track"><span class="bar-fill" style="width:{cap_pct:.1f}%;background:#7c3aed"></span></span>
    <span class="bar-num">{report['caption_words']:,}</span>
  </div>
  <div class="bar-row">
    <span class="bar-label">Displayed Eqs</span>
    <span class="bar-track"><span class="bar-fill" style="width:{eq_pct:.1f}%;background:#059669"></span></span>
    <span class="bar-num">{report['eq_words']:,}</span>
  </div>
  <div class="bar-row">
    <span class="bar-label">Figures</span>
    <span class="bar-track"><span class="bar-fill" style="width:{fig_pct:.1f}%;background:#d97706"></span></span>
    <span class="bar-num">{report['figure_words']:,}</span>
  </div>
  <div class="bar-row" style="margin-top:8px">
    <span class="bar-label" style="font-weight:700">Total</span>
    <span class="bar-track" style="background:transparent;position:relative">
      <span class="bar-fill" style="width:100%;background:{'#dc2626' if total > limit else '#059669'}"></span>
      <span style="position:absolute;left:{limit_pct:.1f}%;top:0;bottom:0;width:2px;background:#000" title="PRL {limit} limit"></span>
    </span>
    <span class="bar-num" style="color:{'#dc2626' if total > limit else '#059669'}">{total:,}</span>
  </div>
  <p style="font-size:0.8rem;color:var(--muted);margin-top:6px;text-align:right">
    &#x2502; = PRL {limit:,} limit ({limit_pct:.1f}% of bar)
  </p>
</div>

<p style="text-align:center;color:var(--muted);font-size:0.8rem;margin-top:32px">
  Generated by <a href="https://github.com/USER/prl-wordcount">prl-wordcount</a> v{__version__} &middot;
  PRL rules per <a href="https://journals.aps.org/authors/length-guide">APS Length Guide</a>
</p>
</div>
</body>
</html>'''
    return html


# ---------------------------------------------------------------------------
# Main analysis pipeline
# ---------------------------------------------------------------------------

def analyze(tex_path, output_html=None, open_browser=False, word_limit=DEFAULT_LIMIT):
    """Run full PRL word count analysis on a .tex file.

    Args:
        tex_path: Path to the .tex file
        output_html: Path for HTML report (optional; auto-generated if None)
        open_browser: Open report in browser if True
        word_limit: Word limit for the target journal (default: 3750)

    Returns:
        dict with full report data
    """
    tex_path = Path(tex_path).resolve()
    if not tex_path.exists():
        raise FileNotFoundError(f'File not found: {tex_path}')

    tex_dir = tex_path.parent

    # Resolve output path (absolute) before changing cwd
    if output_html is None:
        output_html = str(tex_dir / f"{tex_path.stem}_prl_report.html")
    output_html = str(Path(output_html).resolve())
    Path(output_html).parent.mkdir(parents=True, exist_ok=True)

    report = {
        'filename': tex_path.name,
        'tex_path': str(tex_path),
        'date': date.today().isoformat(),
        'word_limit': word_limit,
    }

    # ------------------------------------------------------------------
    # Step 1: Run texcount (from the tex file's directory for include resolution)
    # ------------------------------------------------------------------
    print(f'[1/5] Running texcount on {tex_path.name}...')
    tc_out = run(['texcount', '-sub', '-utf8', tex_path.name], cwd=str(tex_dir))
    if not tc_out:
        raise RuntimeError(
            'texcount failed. Is it installed?\n'
            'Install via TeX Live: tlmgr install texcount\n'
            'Or see: https://ctan.org/pkg/texcount'
        )

    # Parse texcount output
    report['encoding'] = 'utf8'
    enc_m = re.search(r'Encoding:\s*(\S+)', tc_out)
    if enc_m:
        report['encoding'] = enc_m.group(1)

    for key, pattern in [
        ('tc_text_words', r'Words in text:\s*(\d+)'),
        ('tc_header_words', r'Words in headers:\s*(\d+)'),
        ('tc_caption_words', r'Words outside text.*?:\s*(\d+)'),
        ('tc_headers', r'Number of headers:\s*(\d+)'),
        ('tc_floats', r'Number of floats.*?:\s*(\d+)'),
        ('tc_inlines', r'Number of math inlines:\s*(\d+)'),
        ('tc_displayed', r'Number of math displayed:\s*(\d+)'),
    ]:
        m = re.search(pattern, tc_out)
        report[key] = int(m.group(1)) if m else 0

    # Parse subcounts
    subcounts = []
    in_sub = False
    for line in tc_out.splitlines():
        if line.strip().startswith('Subcounts:'):
            in_sub = True
            continue
        if in_sub and line.strip():
            m = re.match(
                r'\s*(\d+)\+(\d+)\+(\d+)\s*\((\d+)/(\d+)/(\d+)/(\d+)\)\s*(.*)',
                line
            )
            if m:
                subcounts.append({
                    'text': int(m.group(1)),
                    'header': int(m.group(2)),
                    'caption': int(m.group(3)),
                    'headers_count': int(m.group(4)),
                    'floats_count': int(m.group(5)),
                    'inlines': int(m.group(6)),
                    'displayed': int(m.group(7)),
                    'name': m.group(8).strip(),
                })

    # Tag sections: identify abstract, appendix, references
    sections = []
    appendix_started = False
    for sc in subcounts:
        name_lower = sc['name'].lower()
        excluded = False

        if any(kw in name_lower for kw in ['_top_', 'abstract']):
            excluded = True
        elif any(kw in name_lower for kw in ['reference', 'bibliography']):
            excluded = True
        elif any(kw in name_lower for kw in ['appendix', 'end matter']):
            appendix_started = True
            excluded = True
        elif appendix_started:
            excluded = True

        sections.append({**sc, 'excluded': excluded})

    report['sections'] = sections

    # Sum counted body text words
    counted = [s for s in sections if not s['excluded']]
    report['body_text_words'] = sum(s['text'] for s in counted)
    report['body_header_words'] = sum(s['header'] for s in counted)
    report['caption_words'] = sum(s['caption'] for s in counted)

    # Appendix: everything after \appendix that isn't abstract/references
    report['appendix_text_words'] = sum(
        s['text'] for s in sections
        if s.get('excluded')
        and not any(kw in s['name'].lower() for kw in ['_top_', 'abstract', 'reference'])
    )
    report['abstract_words'] = sum(
        s['text'] + s['header'] for s in sections
        if '_top_' in s['name'].lower() or 'abstract' in s['name'].lower()
    )

    # ------------------------------------------------------------------
    # Step 2: Parse equations
    # ------------------------------------------------------------------
    print('[2/5] Parsing displayed equations...')
    parser = TeXParser(str(tex_path), str(tex_dir))
    main_body, appendix_body = parser.split_main_appendix()

    main_envs, main_rows, main_eq_details = parser.count_equation_rows(main_body)
    app_envs, app_rows, app_eq_details = parser.count_equation_rows(appendix_body)

    report['main_eq_env_count'] = main_envs
    report['main_eq_row_count'] = main_rows
    report['app_eq_env_count'] = app_envs
    report['app_eq_row_count'] = app_rows
    report['eq_words'] = main_rows * WORDS_PER_EQ_ROW_1COL
    report['app_eq_words'] = app_rows * WORDS_PER_EQ_ROW_1COL

    # Label equations for display (generic: use snippet preview)
    eq_labels = []
    for i, eq in enumerate(main_eq_details):
        preview = eq.get('snippet', '')[:60].replace('\n', ' ').strip()
        label = f"Eq. {i+1} — {preview}" if preview else f"Eq. {i+1}"
        eq_labels.append({'label': label, 'rows': eq['rows']})
    report['main_equations'] = eq_labels

    # ------------------------------------------------------------------
    # Step 3: Find figures and measure dimensions
    # ------------------------------------------------------------------
    print('[3/5] Finding figures and measuring dimensions...')
    figures = parser.find_figures(main_body)
    total_fig_words = 0
    for f in figures:
        img_path = f['path']
        w, h = get_image_size(img_path)
        f['img_w'] = w
        f['img_h'] = h

        if w and h and h > 0:
            aspect = w / h
            f['aspect'] = aspect
            f['prl_words'] = figure_word_count(f['is_wide'], aspect)
        else:
            f['aspect'] = 1.33  # 4:3 default
            f['prl_words'] = figure_word_count(f['is_wide'], f['aspect'])
            f['missing'] = True

        caption_preview = ''
        if f.get('caption_words', 0) > 0:
            caption_preview = f'{f["caption_words"]} caption words'
        f['caption_preview'] = caption_preview

        total_fig_words += f['prl_words']

    report['figures'] = figures
    report['figure_words'] = total_fig_words

    # ------------------------------------------------------------------
    # Step 4: Compute PRL total
    # ------------------------------------------------------------------
    print('[4/5] Computing PRL totals...')
    report['prl_total'] = (
        report['body_text_words'] +
        report['body_header_words'] +
        report['caption_words'] +
        report['eq_words'] +
        report['figure_words'] +
        report.get('footnote_words', 0)
    )
    report['body_text_words'] = report['body_text_words'] + report['body_header_words']

    # ------------------------------------------------------------------
    # Step 5: Generate HTML
    # ------------------------------------------------------------------
    print(f'[5/5] Generating HTML report → {output_html}')
    html = generate_html(report)
    with open(output_html, 'w', encoding='utf-8') as f:
        f.write(html)
    report['html_path'] = output_html

    if open_browser:
        webbrowser.open(Path(output_html).as_uri())

    # Print summary
    print()
    print(f"{'='*60}")
    print(f"  PRL Word Count Summary — {tex_path.name}")
    print(f"{'='*60}")
    print(f"  Body text:           {report['body_text_words']:>6,} words")
    print(f"  Captions:            {report['caption_words']:>6,} words")
    print(f"  Displayed eqs:       {report['eq_words']:>6,} words  ({main_rows} rows × {WORDS_PER_EQ_ROW_1COL})")
    print(f"  Figures:             {report['figure_words']:>6,} words  ({len(figures)} figures)")
    print(f"  {'─' * 50}")
    print(f"  PRL TOTAL:           {report['prl_total']:>6,} words")
    print(f"  PRL LIMIT:           {word_limit:>6,} words")
    delta = report['prl_total'] - word_limit
    tag = 'OVER' if delta > 0 else 'UNDER'
    print(f"  Status:              {tag} by {abs(delta):,} words ({abs(delta)/word_limit*100:.0f}%)")
    print(f"{'='*60}")
    print(f"  Report: {output_html}")
    print()

    return report


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    """Console script entry point."""
    ap = argparse.ArgumentParser(
        description='PRL Word Count Analyzer — APS-compliant word count for LaTeX manuscripts'
    )
    ap.add_argument('texfile', help='Path to the .tex file to analyze')
    ap.add_argument('-o', '--output', help='Output HTML report path (default: auto)')
    ap.add_argument('--open', action='store_true', dest='open_browser',
                    help='Open report in browser after generation')
    ap.add_argument('--json', action='store_true', help='Also output JSON to stdout')
    ap.add_argument('--limit', type=int, default=DEFAULT_LIMIT,
                    help=f'Word limit for target journal (default: {DEFAULT_LIMIT})')
    ap.add_argument('--version', action='version', version=f'prl-wordcount {__version__}')
    args = ap.parse_args()

    report = analyze(
        args.texfile,
        output_html=args.output,
        open_browser=args.open_browser,
        word_limit=args.limit,
    )

    if args.json:
        json_out = {
            k: v for k, v in report.items()
            if k not in ('sections', 'main_equations', 'figures')
        }
        print(json.dumps(json_out, indent=2))


if __name__ == '__main__':
    main()
