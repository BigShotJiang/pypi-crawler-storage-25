import numpy as _np
from mpi4py import MPI as _MPI

from jax import core
from jax.ffi import ffi_lowering
from jax.core import ShapedArray

from mpi4jax._src.utils import (
    HashableMPIType,
    default_primitive_impl,
    to_dtype_handle,
    to_mpi_handle,
    to_mpi_ptr,
    unpack_hashable,
    wrap_as_hashable,
    ordered_effect,
    NOTSET,
    raise_if_token_is_set,
)
from mpi4jax._src.jax_compat import (
    register_lowering,
    get_token_effect,
    set_token_effect,
    Primitive,
)
from mpi4jax._src.decorators import (
    translation_rule_cpu,
    translation_rule_cuda,
    translation_rule_xpu,
)
from mpi4jax._src.validation import enforce_types
from mpi4jax._src.utils import get_default_comm


# The Jax primitive
mpi_recv_p = Primitive("recv_mpi")  # Create the primitive
mpi_recv_impl = default_primitive_impl(mpi_recv_p)


# This function applies the primitive to an AST
@enforce_types(
    source=_np.integer,
    tag=_np.integer,
    comm=(type(None), _MPI.Intracomm, HashableMPIType),
    status=(type(None), _MPI.Status, HashableMPIType),
)
def recv(
    x,
    source=_MPI.ANY_SOURCE,
    *,
    tag=_MPI.ANY_TAG,
    comm=None,
    status=None,
    token=NOTSET,
):
    """Perform a recv (receive) operation.

    .. warning::

        Unlike mpi4py's recv, this returns a *new* array with the received data.

    Arguments:
        x: Array or scalar input with the correct shape and dtype. This can contain
           arbitrary data and will not be overwritten.
        source (int): Rank of the source MPI process.
        tag (int): Tag of this message.
        comm (mpi4py.MPI.Comm): The MPI communicator to use (defaults to
            a clone of :obj:`COMM_WORLD`).
        status (mpi4py.MPI.Status): Status object, can be used for introspection.

    Returns:
        DeviceArray: Received data.
    """
    raise_if_token_is_set(token)

    if comm is None:
        comm = get_default_comm()

    comm = wrap_as_hashable(comm)

    if status is not None:
        status = wrap_as_hashable(status)

    return mpi_recv_p.bind(x, source=source, tag=tag, comm=comm, status=status)


def _mpi_recv_xla_encode(ctx, x, source, tag, comm, status):
    """Common lowering for all platforms using FFI with attributes."""
    from mpi4jax._src.xla_bridge import MPI_STATUS_IGNORE_ADDR

    comm = unpack_hashable(comm)
    status = unpack_hashable(status)

    x_aval, *_ = ctx.avals_in
    x_nptype = x_aval.dtype

    nitems = _np.prod(x_aval.shape, dtype=_np.int64)
    dtype_handle = _np.int64(to_dtype_handle(x_nptype))

    if status is None:
        status_ptr = _np.int64(MPI_STATUS_IGNORE_ADDR)
    else:
        status_ptr = _np.int64(to_mpi_ptr(status))

    token = get_token_effect(ctx, ordered_effect)
    operands = (token,)

    # recv only takes token as operand but outputs (result, token)
    ctx_with_token = ctx.replace(
        avals_in=(core.abstract_token,),
        avals_out=(*ctx.avals_out, core.abstract_token),
    )

    lowering_rule = ffi_lowering(
        "mpi_recv_ffi",
        has_side_effect=True,
    )

    results = lowering_rule(
        ctx_with_token,
        *operands,
        nitems=nitems,
        source=_np.int64(source),
        tag=_np.int64(tag),
        comm=_np.int64(to_mpi_handle(comm)),
        dtype=dtype_handle,
        status=status_ptr,
    )

    results = list(results)
    token = results.pop(-1)
    set_token_effect(ctx, ordered_effect, token)

    return results


# Platform-specific lowering rules (all use the same FFI implementation)
mpi_recv_xla_encode_cpu = translation_rule_cpu(_mpi_recv_xla_encode)
mpi_recv_xla_encode_cuda = translation_rule_cuda(_mpi_recv_xla_encode)
mpi_recv_xla_encode_xpu = translation_rule_xpu(_mpi_recv_xla_encode)


# This function evaluates only the shapes during AST construction
def mpi_recv_abstract_eval(xs, source, tag, comm, status):
    return ShapedArray(xs.shape, xs.dtype), {ordered_effect}


mpi_recv_p.def_impl(mpi_recv_impl)
mpi_recv_p.def_effectful_abstract_eval(mpi_recv_abstract_eval)

# assign to the primitive the correct encoder
register_lowering(mpi_recv_p, mpi_recv_xla_encode_cpu, platform="cpu")
register_lowering(mpi_recv_p, mpi_recv_xla_encode_cuda, platform="cuda")
register_lowering(mpi_recv_p, mpi_recv_xla_encode_xpu, platform="xpu")
