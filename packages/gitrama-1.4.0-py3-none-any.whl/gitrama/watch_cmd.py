"""
gtr watch — Real-Time Breach Alerting
======================================
Monitors files flagged by `gtr predict` for new commits.
Fires an alert the moment a predicted high-risk file is touched.

Reads from .gitrama/last_predict.json (written by gtr predict).
Falls back to last_scan.json fragile_modules if no prediction exists.

Run as a background monitor: gtr watch
Run once to check: gtr watch --once

Author: Alfonso Harding Jr
Company: Gitrama LLC
Copyright © 2026 Gitrama LLC. All Rights Reserved.
"""

import json
import os
import sys
import time
import subprocess
import platform
from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console
from rich.panel import Panel

console = Console()

# ─── Constants ────────────────────────────────────────────────────────────────

LAST_PREDICT_FILE = Path(".gitrama") / "last_predict.json"
LAST_SCAN_FILE    = Path("last_scan.json")
WATCH_STATE_FILE  = Path(".gitrama") / "watch_state.json"
POLL_INTERVAL     = 300  # seconds (5 minutes)


# ─── Git helpers ──────────────────────────────────────────────────────────────

def _run(cmd, timeout: int = 15) -> str:
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=timeout, encoding="utf-8", errors="replace",
            shell=isinstance(cmd, str),
        )
        return result.stdout.strip()
    except Exception:
        return ""


def _get_latest_commit_for_file(filepath: str, since_hash: str = "") -> dict:
    """Get the most recent commit touching a specific file."""
    cmd = [
        "git", "log", "--oneline", "-1",
        "--pretty=format:%H|%an|%at|%s",
        "--", filepath,
    ]
    raw = _run(cmd)
    if not raw or "|" not in raw:
        return {}

    parts = raw.split("|", 3)
    if len(parts) < 4:
        return {}

    commit_hash = parts[0][:12]
    if since_hash and commit_hash == since_hash:
        return {}  # No new commit

    return {
        "hash":    commit_hash,
        "author":  parts[1],
        "ts":      int(parts[2]) if parts[2].isdigit() else 0,
        "message": parts[3][:80],
    }


def _get_repo_name() -> str:
    remote = _run(["git", "remote", "get-url", "origin"])
    if remote:
        if remote.endswith(".git"):
            remote = remote[:-4]
        parts = remote.rstrip("/").replace("git@github.com:", "").replace("https://github.com/", "").split("/")
        if len(parts) >= 2:
            return f"{parts[-2]}/{parts[-1]}"
    return Path(os.getcwd()).name


# ─── Load watched files ───────────────────────────────────────────────────────

def _load_watched_files() -> tuple[list[dict], str, str]:
    """
    Load files to watch from last_predict.json.
    Falls back to last_scan.json fragile_modules.
    Returns (files, pred_id, source_label)
    """
    # Primary: last_predict.json
    if LAST_PREDICT_FILE.exists():
        try:
            with open(LAST_PREDICT_FILE) as f:
                data = json.load(f)
            files   = data.get("files", [])
            pred_id = data.get("pred_id", "unknown")
            if files:
                return files, pred_id, "gtr predict"
        except Exception:
            pass

    # Fallback: last_scan.json fragile_modules
    if LAST_SCAN_FILE.exists():
        try:
            with open(LAST_SCAN_FILE) as f:
                data = json.load(f)
            fragile = data.get("fragile_modules", [])
            files   = [
                {"path": m.get("path", ""), "score": m.get("risk_score", 0), "level": "HIGH"}
                for m in fragile
                if m.get("path")
            ]
            if files:
                return files, "scan", "gtr scan"
        except Exception:
            pass

    return [], "", "none"


# ─── Watch state ──────────────────────────────────────────────────────────────

def _load_watch_state() -> dict:
    """Load last-seen commit hashes per file."""
    try:
        if WATCH_STATE_FILE.exists():
            with open(WATCH_STATE_FILE) as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _save_watch_state(state: dict):
    """Save last-seen commit hashes per file."""
    try:
        WATCH_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(WATCH_STATE_FILE, "w") as f:
            json.dump(state, f, indent=2)
    except Exception:
        pass


def _initialize_watch_state(watched_files: list[dict]) -> dict:
    """Record the current latest commit for each watched file as baseline."""
    state = {}
    for f in watched_files:
        filepath = f.get("path", "")
        if not filepath:
            continue
        commit = _get_latest_commit_for_file(filepath)
        if commit:
            state[filepath] = commit["hash"]
        else:
            state[filepath] = ""
    return state


# ─── Alert rendering ──────────────────────────────────────────────────────────

def _render_breach_alert(filepath: str, file_meta: dict, commit: dict, repo_name: str):
    """Render a breach alert when a predicted file is touched."""
    level = file_meta.get("level", "HIGH")
    score = file_meta.get("score", 0)
    ts    = datetime.fromtimestamp(commit["ts"], tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    color = "bold red" if level == "CRITICAL" else "bold yellow"

    console.print()
    console.print(Panel(
        f"[{color}]⚠  BREACH ALERT — {filepath}[/{color}]\n\n"
        f"  Commit:   {commit['hash']} — \"{commit['message']}\"\n"
        f"  Author:   {commit['author']}\n"
        f"  Time:     {ts}\n\n"
        f"  This file was flagged [bold]{level}[/bold] risk (score: {score}) by your last prediction.\n"
        f"  Run [bold]gtr scan[/bold] to update your risk assessment.\n"
        f"  Run [bold]gtr chat --deep[/bold] to analyze this commit's impact.",
        title=f"[{color}]🌿 gtr watch — {repo_name}[/{color}]",
        border_style="red" if level == "CRITICAL" else "yellow",
        padding=(1, 2),
    ))
    console.print()

    # Log alert to ~/.gitrama/alerts.json
    _log_alert(filepath, file_meta, commit, repo_name)


def _log_alert(filepath: str, file_meta: dict, commit: dict, repo_name: str):
    """Append breach alert to ~/.gitrama/alerts.json."""
    alerts_file = Path.home() / ".gitrama" / "alerts.json"
    alerts_file.parent.mkdir(parents=True, exist_ok=True)

    existing = []
    try:
        if alerts_file.exists():
            with open(alerts_file) as f:
                existing = json.load(f)
    except Exception:
        pass

    existing.append({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "repo":      repo_name,
        "file":      filepath,
        "level":     file_meta.get("level", "HIGH"),
        "score":     file_meta.get("score", 0),
        "commit":    commit,
    })

    if len(existing) > 200:
        existing = existing[-200:]

    try:
        with open(alerts_file, "w") as f:
            json.dump(existing, f, indent=2)
    except Exception:
        pass


# ─── Poll loop ────────────────────────────────────────────────────────────────

def _check_once(watched_files: list[dict], state: dict, repo_name: str) -> tuple[int, dict]:
    """
    Check all watched files for new commits.
    Returns (alert_count, updated_state).
    """
    alerts = 0
    file_map = {f["path"]: f for f in watched_files if f.get("path")}

    for filepath, file_meta in file_map.items():
        last_hash = state.get(filepath, "")
        commit    = _get_latest_commit_for_file(filepath, since_hash=last_hash)

        if commit:
            _render_breach_alert(filepath, file_meta, commit, repo_name)
            state[filepath] = commit["hash"]
            alerts += 1

    return alerts, state


def cmd_watch(
    once: bool = False,
    interval: int = POLL_INTERVAL,
):
    """
    Main entry point for `gtr watch`.
    Called from the CLI dispatcher.
    """
    # ── Git repo check ─────────────────────────────────────────────────────────
    result = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        capture_output=True, text=True,
        shell=platform.system() == "Windows",
    )
    if result.returncode != 0:
        console.print("\n[red]Not a git repository.[/red] Run [bold]gtr watch[/bold] from inside a git repo.\n")
        sys.exit(1)

    repo_name = _get_repo_name()

    # ── Load watched files ─────────────────────────────────────────────────────
    watched_files, pred_id, source = _load_watched_files()

    if not watched_files:
        console.print()
        console.print(Panel(
            "[bold yellow]🌿 No files to watch.[/bold yellow]\n\n"
            "Run [bold]gtr predict[/bold] first to identify high-risk files.\n"
            "Then run [bold]gtr watch[/bold] to monitor them.",
            border_style="yellow",
        ))
        sys.exit(0)

    # ── Initialize state ───────────────────────────────────────────────────────
    state = _load_watch_state()

    # First run — establish baseline
    new_files = [f for f in watched_files if f.get("path") not in state]
    if new_files:
        baseline = _initialize_watch_state(new_files)
        state.update(baseline)
        _save_watch_state(state)

    # ── Display watch header ───────────────────────────────────────────────────
    console.print()

    critical_files = [f for f in watched_files if f.get("level") == "CRITICAL"]
    high_files     = [f for f in watched_files if f.get("level") == "HIGH"]

    file_list = "\n".join(
        f"   {f.get('level', 'HIGH'):8s}  {f.get('path', '')}  [dim](score: {f.get('score', 0)})[/dim]"
        for f in watched_files[:8]
    )

    source_line = f"Source: [bold]{source}[/bold]"
    if pred_id and pred_id != "scan":
        source_line += f"  |  Prediction: [dim]{pred_id}[/dim]"

    console.print(Panel(
        f"[bold green]Watching {len(watched_files)} high-risk file(s) — {repo_name}[/bold green]\n"
        f"[dim]{source_line}[/dim]\n\n"
        f"{file_list}\n\n"
        f"[dim]Polling every {interval // 60} min. Press Ctrl+C to stop.[/dim]",
        title="[bold green]🌿 gtr watch[/bold green]",
        border_style="green",
        padding=(1, 2),
    ))
    console.print()

    if once:
        alerts, state = _check_once(watched_files, state, repo_name)
        _save_watch_state(state)
        if alerts == 0:
            console.print("[dim green]✓ No new commits on watched files.[/dim green]\n")
        return

    # ── Poll loop ──────────────────────────────────────────────────────────────
    try:
        while True:
            alerts, state = _check_once(watched_files, state, repo_name)
            _save_watch_state(state)

            if alerts == 0:
                now = datetime.now().strftime("%H:%M:%S")
                console.print(f"[dim]  {now}  No new commits. Next check in {interval // 60} min...[/dim]")

            time.sleep(interval)

    except KeyboardInterrupt:
        console.print("\n[dim]Watch stopped. Run [bold]gtr watch[/bold] to resume.[/dim]\n")


# ─── CLI wiring ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="gtr watch — Monitor predicted high-risk files for new commits")
    parser.add_argument("--once",     action="store_true",          help="Check once and exit")
    parser.add_argument("--interval", type=int, default=POLL_INTERVAL, help="Poll interval in seconds")

    args = parser.parse_args()
    cmd_watch(
        once     = args.once,
        interval = args.interval,
    )