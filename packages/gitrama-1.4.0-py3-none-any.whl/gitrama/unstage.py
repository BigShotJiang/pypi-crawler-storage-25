"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

This software is proprietary and confidential.
Unauthorized copying, distribution, or use is strictly prohibited.

Gitrama LLC
South Carolina Limited Liability Company
"""

# gtr unstage — Remove files from the staging area.
#
# Lets developers unstage files without touching git directly.
# Supports specific files, interactive selection, or unstage all.
#
# Usage:
#     gtr unstage                 Interactive — pick files to unstage
#     gtr unstage <file>          Unstage a specific file
#     gtr unstage --all           Unstage everything staged
#     gtr unstage -a              Same, short flag

import subprocess
from typing import Optional, List

import typer
from rich.console import Console
from rich.prompt import Confirm

console = Console()


# ─── Git helpers ──────────────────────────────────────────────────────────────

def _run_git(*args: str) -> tuple[int, str, str]:
    """Run a git command, return (returncode, stdout, stderr)."""
    try:
        result = subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
        )
        return result.returncode, result.stdout.strip(), result.stderr.strip()
    except Exception as e:
        return 1, "", str(e)


def _get_staged_files() -> list[dict]:
    """
    Return list of staged files with status and path.

    For renamed files (status R), both old and new paths are captured
    so the caller has the full picture. Dict shape:
      Renamed: {"status": "Renamed", "path": <new>, "old_path": <old>}
      Others:  {"status": "...",     "path": <path>}
    """
    code, out, err = _run_git("diff", "--name-status", "--staged")
    if code != 0:
        if err:
            console.print(f"  [red]git error:[/red] {err}")
        return []
    if not out:
        return []

    files = []
    for line in out.splitlines():
        parts = line.strip().split("\t")
        if len(parts) < 2:
            continue

        status_code = parts[0][0].upper()
        status_map = {"M": "Modified", "A": "Added", "D": "Deleted", "R": "Renamed"}
        status = status_map.get(status_code, status_code)

        if status_code == "R" and len(parts) >= 3:
            # Renamed: parts[1] = old path, parts[2] = new path
            files.append({
                "status":   "Renamed",
                "path":     parts[2].strip(),
                "old_path": parts[1].strip(),
            })
        else:
            files.append({
                "status": status,
                "path":   parts[-1].strip(),
            })

    return files


def _unstage_files(files: list[dict]) -> tuple[bool, str]:
    """
    Unstage specific files using git restore --staged.
    Falls back to git reset HEAD for git < 2.23.

    Accepts file dicts (from _get_staged_files). For renamed files,
    git restore --staged requires the new path (what exists in the index).
    old_path is stored in the dict for display only — not used for unstaging.

    Processes per-file so partial failures are caught and reported
    individually rather than silently treating the batch as success/fail.
    Reports primary error — not fallback error — so the user sees
    the real cause.
    """
    failed = []

    for f in files:
        # For renames, git restore --staged needs the new path (what's in the index)
        # old_path no longer exists in the index after a rename
        unstage_path = f["path"]
        display_path = f["path"]

        # Reject paths containing newlines or null bytes — errors="replace"
        # in _run_git could silently munge a corrupted index path.
        if any(ord(c) in (0, 10, 13) for c in unstage_path):
            failed.append((display_path, "invalid path: contains unsafe characters"))
            continue

        # -- before path prevents filenames starting with - being
        # misinterpreted as flags by git
        code, _, primary_err = _run_git("restore", "--staged", "--", unstage_path)
        if code == 0:
            continue

        # Fallback for older git versions (< 2.23)
        code, _, fallback_err = _run_git("reset", "HEAD", "--", unstage_path)
        if code != 0:
            # Report primary error — it's more informative than fallback
            failed.append((display_path, primary_err or fallback_err))

    if failed:
        msg = "\n".join(f"  {p}: {e}" for p, e in failed)
        return False, msg

    return True, ""


def _status_style(status: str) -> tuple[str, str]:
    """Return (color, symbol) for a status string."""
    return {
        "Modified": ("#4fc3f7", "M"),
        "Added":    ("#44cc88", "A"),
        "Deleted":  ("#ff5566", "D"),
        "Renamed":  ("#ffaa00", "R"),
    }.get(status, ("#e8eaf0", "?"))


# ─── Interactive selector ─────────────────────────────────────────────────────

def _interactive_select(staged: list[dict]) -> list[dict]:
    """
    Show a numbered list of staged files and let the user pick which to unstage.
    Returns list of selected file dicts (from _get_staged_files).
    """
    console.print()
    console.print("  [dim]Staged files — enter numbers to unstage (e.g. 1 3 4)[/dim]\n")

    for i, f in enumerate(staged, 1):
        color, sym = _status_style(f["status"])
        num   = f"[dim]{i:>2}[/dim]"
        badge = f"[bold {color}]{sym}[/bold {color}]"
        path  = f"[white]{f['path']}[/white]"
        # Show both paths for renames so user sees the full picture
        if f["status"] == "Renamed" and f.get("old_path"):
            path += f"  [dim](was {f['old_path']})[/dim]"
        console.print(f"  {num}  {badge}  {path}")

    console.print()
    console.print("  [dim]a = all  ·  q = cancel[/dim]")
    console.print()

    raw = console.input("  [green]>[/green] ").strip().lower()

    if not raw or raw == "q":
        return []

    if raw == "a":
        return staged[:]

    selected = []
    seen = set()
    for token in raw.split():
        try:
            idx = int(token) - 1
            if 0 <= idx < len(staged):
                f = staged[idx]
                if f["path"] not in seen:
                    seen.add(f["path"])
                    selected.append(f)
                else:
                    console.print(f"  [yellow]⚠  {token} already selected — skipped[/yellow]")
            else:
                console.print(f"  [yellow]⚠  {token} out of range — skipped[/yellow]")
        except ValueError:
            console.print(f"  [yellow]⚠  '{token}' not a number — skipped[/yellow]")

    return selected


# ─── Main command ─────────────────────────────────────────────────────────────

def unstage(
    files: Optional[List[str]] = typer.Argument(
        None,
        help="Files to unstage. Leave empty for interactive selection."
    ),
    all_files: bool = typer.Option(
        False, "--all", "-a",
        help="Unstage all staged files at once"
    ),
):
    """
    📤 Remove files from the staging area.

    No git commands needed — just pick what to unstage.
    Files return to modified/untracked state. Your changes are NOT lost.

    \b
    EXAMPLES:
      gtr unstage                     Interactive file picker
      gtr unstage gitrama/auth.py     Unstage a specific file
      gtr unstage auth.py cli.py      Unstage multiple files
      gtr unstage --all               Unstage everything
      gtr unstage -a                  Same, short flag

    \b
    NOTE:
      Unstaging moves files out of the staging area — it does NOT
      discard your changes. Your edits remain in the working tree.
    """

    # ── Get current staged files ───────────────────────────────────────────────
    staged = _get_staged_files()

    if not staged:
        console.print("\n  [dim]Nothing staged. Use [bold]gtr add[/bold] to stage files.[/dim]\n")
        return

    # ── Determine which files to unstage ──────────────────────────────────────

    if all_files:
        to_unstage = staged[:]

    elif files:
        # Validate provided files are actually staged — match to full dicts
        # Keep new-path and old-path indexes separate to avoid blind overwrites
        staged_by_path     = {f["path"]: f for f in staged}
        # NOTE: if two renames share the same old_path (e.g. after history rewrite),
        # the last one wins silently. Acceptable — git itself prevents this in normal use.
        staged_by_old_path = {f["old_path"]: f for f in staged if "old_path" in f}
        seen = set()
        to_unstage = []
        for fp in files:
            f = staged_by_path.get(fp) or staged_by_old_path.get(fp)
            if f:
                # Deduplicate — user may pass both old and new path of a rename
                if f["path"] not in seen:
                    seen.add(f["path"])
                    to_unstage.append(f)
            else:
                console.print(f"  [yellow]⚠  {fp} is not staged — skipped[/yellow]")
        if not to_unstage:
            console.print("\n  [yellow]None of the specified files are staged.[/yellow]\n")
            return

    else:
        # Interactive selection
        if len(staged) == 1:
            f = staged[0]
            color, sym = _status_style(f["status"])
            console.print()
            line = f"  [bold {color}]{sym}[/bold {color}]  [white]{f['path']}[/white]"
            if f["status"] == "Renamed" and f.get("old_path"):
                line += f"  [dim](was {f['old_path']})[/dim]"
            line += "  [dim]is the only staged file[/dim]"
            console.print(line)
            console.print()
            confirmed = Confirm.ask("  Unstage it?", default=True)
            if not confirmed:
                console.print("  [dim]Cancelled.[/dim]\n")
                return
            to_unstage = [f]
        else:
            to_unstage = _interactive_select(staged)

    if not to_unstage:
        console.print("\n  [dim]Nothing selected — staging area unchanged.[/dim]\n")
        return

    # ── Execute unstage ────────────────────────────────────────────────────────

    console.print()
    ok, err = _unstage_files(to_unstage)

    if ok:
        for f in to_unstage:
            console.print(f"  [green]✓[/green]  [white]{f['path']}[/white]  [dim]unstaged[/dim]")

        # Fresh git call — accurate post-op count, not arithmetic on stale data
        remaining = len(_get_staged_files())
        console.print()

        if remaining > 0:
            console.print(
                f"  [dim]{remaining} file{'s' if remaining != 1 else ''} still staged. "
                f"Run [bold]gtr status[/bold] to review.[/dim]"
            )
        else:
            console.print(
                "  [dim]Staging area is now empty. "
                "Run [bold]gtr add[/bold] to re-stage files.[/dim]"
            )
        console.print()

    else:
        console.print(f"\n  [red]✗  Unstage failed:[/red] {err}\n")
        raise typer.Exit(1)
