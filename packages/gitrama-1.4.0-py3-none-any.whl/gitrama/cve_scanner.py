"""
Gitrama CVE Scanner
Parses dependency files for Java, JavaScript, and Python.
Cross-references against OSV (Open Source Vulnerabilities) API.
No API key required — osv.dev is free and open.

Copyright © 2026 Gitrama LLC. All Rights Reserved.
"""

import os
import re
import json
import time
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, field

import requests

OSV_BATCH_URL = "https://api.osv.dev/v1/querybatch"
OSV_TIMEOUT   = 30
MAX_BATCH     = 1000  # OSV batch limit per request


# ─── Data structures ──────────────────────────────────────────────────────────

@dataclass
class Dependency:
    name:      str
    version:   str
    ecosystem: str           # Maven, npm, PyPI
    source:    str           # which file it came from
    group:     str = ""      # Maven groupId


@dataclass
class CVEFinding:
    dep:       Dependency
    cve_id:    str
    severity:  str           # CRITICAL, HIGH, MEDIUM, LOW, UNKNOWN
    cvss:      float
    summary:   str
    fixed_in:  str
    churn:     int = 0       # populated by correlation engine


# ─── Dependency parsers ───────────────────────────────────────────────────────

def _parse_pom_xml(filepath: str) -> list[Dependency]:
    """Parse Maven pom.xml for dependencies."""
    deps = []
    try:
        tree = ET.parse(filepath)
        root = tree.getroot()
        ns = {"m": "http://maven.apache.org/POM/4.0.0"}

        # Handle both namespaced and non-namespaced pom.xml
        def find_all(tag):
            results = root.findall(f".//m:{tag}", ns)
            if not results:
                results = root.findall(f".//{tag}")
            return results

        for dep in find_all("dependency"):
            group   = dep.findtext("m:groupId", namespaces=ns) or dep.findtext("groupId") or ""
            art     = dep.findtext("m:artifactId", namespaces=ns) or dep.findtext("artifactId") or ""
            version = dep.findtext("m:version", namespaces=ns) or dep.findtext("version") or ""

            # Skip property placeholders like ${spring.version}
            if not art or not version or version.startswith("${"):
                continue

            deps.append(Dependency(
                name=f"{group}:{art}" if group else art,
                version=version.strip(),
                ecosystem="Maven",
                source=filepath,
                group=group,
            ))
    except Exception:
        pass
    return deps


def _parse_build_gradle(filepath: str) -> list[Dependency]:
    """Parse Gradle build.gradle for dependencies."""
    deps = []
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        # Match: implementation 'group:artifact:version' or "group:artifact:version"
        pattern = re.compile(
            r'''(?:implementation|api|compile|testImplementation|runtimeOnly|compileOnly)\s*['"]([\w.\-]+):([\w.\-]+):([\w.\-]+)['"]'''
        )
        for m in pattern.finditer(content):
            group, artifact, version = m.group(1), m.group(2), m.group(3)
            deps.append(Dependency(
                name=f"{group}:{artifact}",
                version=version,
                ecosystem="Maven",
                source=filepath,
                group=group,
            ))
    except Exception:
        pass
    return deps


def _parse_package_json(filepath: str) -> list[Dependency]:
    """Parse npm package.json for dependencies."""
    deps = []
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            data = json.load(f)

        for section in ("dependencies", "devDependencies", "peerDependencies"):
            for name, version in data.get(section, {}).items():
                # Strip semver prefixes: ^1.2.3 → 1.2.3
                clean = re.sub(r'^[\^~>=<v]+', '', version.strip())
                if clean and clean != "*":
                    deps.append(Dependency(
                        name=name,
                        version=clean,
                        ecosystem="npm",
                        source=filepath,
                    ))
    except Exception:
        pass
    return deps


def _parse_requirements_txt(filepath: str) -> list[Dependency]:
    """Parse Python requirements.txt for dependencies."""
    deps = []
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("-"):
                    continue

                # Handle: package==1.2.3, package>=1.2.3, package~=1.2.3
                m = re.match(r'^([\w.\-\[\]]+)\s*[=~><]{1,2}\s*([\w.\-]+)', line)
                if m:
                    deps.append(Dependency(
                        name=m.group(1).split("[")[0],  # strip extras like [security]
                        version=m.group(2),
                        ecosystem="PyPI",
                        source=filepath,
                    ))
    except Exception:
        pass
    return deps


def _parse_jar_manifest(filepath: str) -> list[Dependency]:
    """Extract dependency info from JAR MANIFEST.MF."""
    deps = []
    try:
        with zipfile.ZipFile(filepath, "r") as zf:
            if "META-INF/MANIFEST.MF" not in zf.namelist():
                return deps
            with zf.open("META-INF/MANIFEST.MF") as mf:
                content = mf.read().decode("utf-8", errors="ignore")

            name    = ""
            version = ""
            for line in content.splitlines():
                if line.startswith("Implementation-Title:"):
                    name = line.split(":", 1)[1].strip()
                elif line.startswith("Implementation-Version:"):
                    version = line.split(":", 1)[1].strip()
                elif line.startswith("Bundle-SymbolicName:"):
                    name = line.split(":", 1)[1].strip().split(";")[0].strip()
                elif line.startswith("Bundle-Version:"):
                    version = line.split(":", 1)[1].strip()

            if name and version:
                deps.append(Dependency(
                    name=name,
                    version=version,
                    ecosystem="Maven",
                    source=filepath,
                ))
    except Exception:
        pass
    return deps


# ─── Repo walker ──────────────────────────────────────────────────────────────

SKIP_DIRS = {
    ".git", "node_modules", ".venv", "venv", "__pycache__",
    ".gradle", "build", "target", "dist", ".idea", ".mvn",
}

def find_dependencies(repo_root: str) -> list[Dependency]:
    """Walk the repo and parse all supported dependency files."""
    all_deps: list[Dependency] = []
    root = Path(repo_root)

    try:
        paths = list(root.rglob("*"))
    except Exception:
            paths = []
    for path in paths:
        # Skip noise directories
        if any(skip in path.parts for skip in SKIP_DIRS):
            continue

        name = path.name.lower()

        if name == "pom.xml":
            all_deps.extend(_parse_pom_xml(str(path)))
        elif name == "build.gradle" or name == "build.gradle.kts":
            all_deps.extend(_parse_build_gradle(str(path)))
        elif name == "package.json":
            all_deps.extend(_parse_package_json(str(path)))
        elif name in ("requirements.txt", "requirements-dev.txt",
                      "requirements-test.txt", "requirements_dev.txt"):
            all_deps.extend(_parse_requirements_txt(str(path)))
        elif path.suffix == ".jar":
            all_deps.extend(_parse_jar_manifest(str(path)))

    # Deduplicate by (name, version, ecosystem)
    seen = set()
    unique = []
    for dep in all_deps:
        key = (dep.name, dep.version, dep.ecosystem)
        if key not in seen:
            seen.add(key)
            unique.append(dep)

    return unique


# ─── OSV API ──────────────────────────────────────────────────────────────────

def _build_osv_query(dep: Dependency) -> dict:
    """Build a single OSV query object for one dependency."""
    return {
        "package": {
            "name":      dep.name,
            "ecosystem": dep.ecosystem,
        },
        "version": dep.version,
    }


def _parse_severity(vuln: dict) -> tuple[str, float]:
    """Extract severity label and CVSS score from an OSV vuln object."""
    cvss = 0.0
    severity = "UNKNOWN"

    # GHSA entries use database_specific.severity as a string
    db_severity = vuln.get("database_specific", {}).get("severity", "")
    if db_severity.upper() in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
        severity = db_severity.upper()
        # Map string severity to approximate CVSS midpoint
        cvss_map = {"CRITICAL": 9.5, "HIGH": 8.0, "MEDIUM": 5.5, "LOW": 2.0}
        cvss = cvss_map.get(severity, 0.0)
        return severity, cvss

    # Try database_specific CVSS first
    for sev in vuln.get("severity", []):
        if sev.get("type") == "CVSS_V3":
            try:
                score_str = sev.get("score", "")
                # Extract numeric score from CVSS vector or plain number
                if "/" in score_str:
                    # It's a vector string — extract base score from affected
                    pass
                else:
                    cvss = float(score_str)
            except Exception:
                pass

    # Fallback: check affected[].ecosystem_specific
    if cvss == 0.0:
        for aff in vuln.get("affected", []):
            db_specific = aff.get("database_specific", {})
            score = db_specific.get("cvss", 0)
            if isinstance(score, (int, float)):
                cvss = max(cvss, float(score))

    # Map CVSS to severity label
    if cvss >= 9.0:
        severity = "CRITICAL"
    elif cvss >= 7.0:
        severity = "HIGH"
    elif cvss >= 4.0:
        severity = "MEDIUM"
    elif cvss > 0.0:
        severity = "LOW"
    else:
        severity = "UNKNOWN"

    return severity, cvss


def _get_fixed_version(vuln: dict, dep: Dependency) -> str:
    """Extract the fixed version from an OSV vuln object."""
    for affected in vuln.get("affected", []):
        pkg = affected.get("package", {})
        if pkg.get("ecosystem", "").lower() != dep.ecosystem.lower():
            continue
        for r in affected.get("ranges", []):
            for event in r.get("events", []):
                fixed = event.get("fixed")
                if fixed:
                    return fixed
    return "no fix available"


def query_osv(deps: list[Dependency]) -> list[CVEFinding]:
    """
    Batch query the OSV API for all dependencies.
    Handles pagination — OSV allows max 1000 queries per request.
    Returns a flat list of CVEFindings.
    """
    if not deps:
        return []

    findings: list[CVEFinding] = []

    for i in range(0, len(deps), MAX_BATCH):
        batch = deps[i:i + MAX_BATCH]
        queries = [_build_osv_query(d) for d in batch]

        try:
            response = requests.post(
                OSV_BATCH_URL,
                json={"queries": queries},
                timeout=OSV_TIMEOUT,
                headers={"Content-Type": "application/json"},
            )
            response.raise_for_status()
            results = response.json().get("results", [])
        except requests.exceptions.Timeout:
            print(f"[warn] OSV API timed out on batch {i//MAX_BATCH + 1}")
            continue
        except Exception as e:
            print(f"[warn] OSV API error: {e}")
            continue

        for dep, result in zip(batch, results):
            vulns = result.get("vulns", [])
            for vuln in vulns:
                # Skip stub records — OSV entries with no meaningful data
                if not vuln.get("affected") and not vuln.get("severity") and not vuln.get("summary"):
                    continue

                cve_ids = [
                    alias for alias in vuln.get("aliases", [])
                    if alias.startswith("CVE-")
                ]
                cve_id   = cve_ids[0] if cve_ids else vuln.get("id", "UNKNOWN")
                severity, cvss = _parse_severity(vuln)
                fixed_in       = _get_fixed_version(vuln, dep)
                summary        = vuln.get("summary", "No description available")[:120]

                # Skip findings with no actionable data
                if severity == "UNKNOWN" and summary == "No description available":
                    continue

                findings.append(CVEFinding(
                    dep=dep,
                    cve_id=cve_id,
                    severity=severity,
                    cvss=cvss,
                    summary=summary,
                    fixed_in=fixed_in,
                ))

        if i + MAX_BATCH < len(deps):
            time.sleep(0.5)

    return findings

# ─── Churn correlation ────────────────────────────────────────────────────────

def correlate_with_churn(
    findings: list[CVEFinding],
    last_scan_path: str = "last_scan.json",
) -> list[CVEFinding]:
    """
    Enrich CVE findings with churn scores from last_scan.json.
    Files that are both high-churn AND have a CVE get flagged highest priority.
    """
    try:
        with open(last_scan_path, "r", encoding="utf-8") as f:
            scan = json.load(f)
    except Exception:
        return findings  # No scan data — return findings as-is

    # Build a churn lookup: filename → churn count
    churn_map: dict[str, int] = {}
    for module in scan.get("modules", []):
        churn_map[module.get("path", "")] = module.get("churn", 0)
        for f in module.get("files", []):
            churn_map[f.get("path", "")] = f.get("churn", 0)

    for finding in findings:
        source = finding.dep.source
        # Try exact match first, then basename
        churn = churn_map.get(source, 0)
        if not churn:
            churn = churn_map.get(os.path.basename(source), 0)
        finding.churn = churn

    # Re-sort: CRITICAL with high churn rises to top
    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}
    findings.sort(key=lambda f: (severity_order.get(f.severity, 4), -f.churn, -f.cvss))

    return findings


# ─── Output formatter ─────────────────────────────────────────────────────────

SEVERITY_COLORS = {
    "CRITICAL": "\033[91m",  # bright red
    "HIGH":     "\033[31m",  # red
    "MEDIUM":   "\033[33m",  # yellow
    "LOW":      "\033[32m",  # green
    "UNKNOWN":  "\033[90m",  # gray
}
RESET = "\033[0m"
BOLD  = "\033[1m"


def format_findings(
    findings:  list[CVEFinding],
    deps:      list[Dependency],
    show_all:  bool = False,
) -> str:
    """Format CVE findings for terminal output."""
    lines = []

    # Summary header
    total_deps  = len(deps)
    total_vulns = len(findings)
    critical    = sum(1 for f in findings if f.severity == "CRITICAL")
    high        = sum(1 for f in findings if f.severity == "HIGH")

    lines.append(f"\n{BOLD}Dependency scan complete{RESET}")
    lines.append(f"  {total_deps} packages scanned  •  {total_vulns} vulnerabilities found")
    if critical:
        lines.append(f"  {SEVERITY_COLORS['CRITICAL']}{BOLD}{critical} CRITICAL{RESET}  {SEVERITY_COLORS['HIGH']}{high} HIGH{RESET}")
    lines.append("")

    if not findings:
        lines.append("  No known vulnerabilities found.")
        return "\n".join(lines)

    # Show top 20 by default, all if --all flag
    display = findings if show_all else findings[:20]

    # Column widths
    lines.append(f"  {'SEVERITY':<10} {'PACKAGE':<35} {'CVE':<20} {'CVSS':<6} {'CHURN'}")
    lines.append("  " + "─" * 85)

    for f in display:
        color   = SEVERITY_COLORS.get(f.severity, "")
        pkg     = f"{f.dep.name} {f.dep.version}"[:34]
        churn   = f"{f.churn}x" if f.churn else "—"
        cvss    = f"{f.cvss:.1f}" if f.cvss else "—"
        lines.append(
            f"  {color}{BOLD}{f.severity:<10}{RESET} "
            f"{pkg:<35} "
            f"{f.cve_id:<20} "
            f"{cvss:<6} "
            f"{churn}"
        )
        lines.append(f"  {'':10} {f.summary[:70]}")
        if f.fixed_in and f.fixed_in != "no fix available":
            lines.append(f"  {'':10} Fix available: {f.fixed_in}")
        lines.append("")

    if not show_all and len(findings) > 20:
        lines.append(f"  ... {len(findings) - 20} more. Run with --all to see everything.")

    return "\n".join(lines)


# ─── Main entry point ─────────────────────────────────────────────────────────

def run_cve_scan(
    repo_root:      str  = ".",
    show_all:       bool = False,
    last_scan_path: str  = "last_scan.json",
    json_output:    bool = False,
) -> list[CVEFinding]:
    """
    Full CVE scan pipeline:
    1. Parse dependency files
    2. Query OSV API
    3. Correlate with churn data
    4. Return findings (and print formatted output)
    """
    print(f"Scanning dependencies in {os.path.abspath(repo_root)}...")

    # Step 1 — parse
    deps = find_dependencies(repo_root)
    if not deps:
        print("No supported dependency files found.")
        print("Supported: pom.xml, build.gradle, package.json, requirements.txt, *.jar")
        return []

    ecosystems = {}
    for d in deps:
        ecosystems[d.ecosystem] = ecosystems.get(d.ecosystem, 0) + 1
    ecosystem_str = "  ".join(f"{eco}: {n}" for eco, n in sorted(ecosystems.items()))
    print(f"Found {len(deps)} packages  ({ecosystem_str})")

    deps = [d for d in deps if d.version.strip()]
    if not deps:
        print("No versioned dependencies found — all versions are inherited from a parent BOM.")
        print("Tip: scan the parent pom.xml directly for version resolution.")
        return []
    versioned_str = "  ".join(f"{eco}: {sum(1 for d in deps if d.ecosystem==eco)}" 
                           for eco in sorted(set(d.ecosystem for d in deps)))
    print(f"Versioned packages: {len(deps)}  ({versioned_str})")


    print("Querying OSV vulnerability database...")

    # Step 2 — OSV lookup
    findings = query_osv(deps)

    # Step 3 — correlate with scan data
    findings = correlate_with_churn(findings, last_scan_path)

    # Step 4 — output
    if json_output:
        output = [
            {
                "package":   f.dep.name,
                "version":   f.dep.version,
                "ecosystem": f.dep.ecosystem,
                "source":    f.dep.source,
                "cve_id":    f.cve_id,
                "severity":  f.severity,
                "cvss":      f.cvss,
                "summary":   f.summary,
                "fixed_in":  f.fixed_in,
                "churn":     f.churn,
            }
            for f in findings
        ]
        print(json.dumps(output, indent=2))
    else:
        print(format_findings(findings, deps, show_all=show_all))

    return findings


# ─── CLI entry ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Gitrama CVE Scanner")
    parser.add_argument("path",     nargs="?", default=".", help="Repo root path")
    parser.add_argument("--all",    action="store_true",    help="Show all findings")
    parser.add_argument("--json",   action="store_true",    help="Output as JSON")
    parser.add_argument("--scan",   default="last_scan.json", help="Path to last_scan.json")
    args = parser.parse_args()

    run_cve_scan(
        repo_root=args.path,
        show_all=args.all,
        last_scan_path=args.scan,
        json_output=args.json,
    )