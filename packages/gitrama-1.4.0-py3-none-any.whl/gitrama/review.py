"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

This software is proprietary and confidential.
Unauthorized copying, distribution, or use is strictly prohibited.

Gitrama LLC
South Carolina Limited Liability Company
"""

# ─── PRIORITY TODOs ───────────────────────────────────────────────────────────
#
# P0 — CRITICAL: Normalize get_value() key lookup in config.py
#   get_value() currently does a case-sensitive dict lookup, which means
#   get_value("GITRAMA_TOKEN") and get_value("gitrama_token") can return
#   different results depending on how the key was saved. This has already
#   caused auth failures in review.py and diff.py.
#
#   Fix (one line in config.py):
#     def get_value(key: str) -> Optional[Any]:
#         key = key.lower()
#         config = load_config()
#         return config.get(key) or config.get(key.upper()) or os.environ.get(key.upper())
#
#   Once done, remove all defensive fallback chains from callers:
#     # Every caller becomes just:
#     token = get_value("gitrama_token") or ""
#
# ─────────────────────────────────────────────────────────────────────────────


"""
gtr review — AI code review before you push.

Sends your local diff + full repo context (risk scores, churn, coupling,
last touched, test coverage) to the Intelligence Engine and returns
actionable feedback — like a senior engineer who knows your codebase.

Unlike lint (rules-based) or SonarQube (pattern-based), gtr review
understands your repo's history and surfaces judgment, not just findings.

Usage:
    gtr review              Review staged changes
    gtr review --all        Review all uncommitted changes (staged + unstaged)
    gtr review --full       Full review: security + logic + history + coupling
    gtr review --quick      Quick pass: critical issues only, no suggestions
"""

import code
import json
import subprocess
from pathlib import Path
from typing import Optional

import requests
import typer
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.text import Text

from .config import get_value, GITRAMA_API_URL

# Browser panel — optional, never crashes CLI
try:
    from .review_html import open_review_panel as _open_review_panel
except Exception:
    _open_review_panel = None

console = Console()

# ─── Constants ────────────────────────────────────────────────────────────────

# URL set globally in config.py — change it there
REQUEST_TIMEOUT  = 60          # review takes longer than a diff
SCAN_FILE        = Path(".gitrama/last_scan.json")
MAX_DIFF_CHARS   = 12_000      # cap payload to avoid token blowout
MAX_LOG_LINES    = 20

# ─── Review system prompt ─────────────────────────────────────────────────────


REVIEW_SYSTEM_PROMPT = """
You are a senior software engineer performing a pre-commit code review.
You have deep knowledge of this specific codebase — its history, its
fragile areas, its patterns, and its past bugs.

You are NOT a linter. Do not flag style issues or formatting.
You ARE a thoughtful engineer. Flag things that actually matter:

  🔴 SECURITY    — auth bypasses, injection vectors, exposed secrets,
                   unsafe deserialization, missing validation
  🔴 CORRECTNESS — logic errors, off-by-one, wrong assumptions,
                   race conditions, unhandled edge cases
  ⚠  RISK        — changes to high-churn files, missing test coverage,
                   patterns that caused bugs here before
  ⚠  COUPLING    — changes that likely require updates to related files
  💡 SUGGESTION  — optional improvements, not blockers
  ✓  GOOD        — explicitly acknowledge what was done well

OUT OF SCOPE — do not flag these:
  - Theoretical attack vectors requiring malicious or corrupted git state
    (null bytes in filenames, embedded newlines, history rewrites)
  - Edge cases requiring empty repos, no-commit state, or git internals
  - Stale comments, docstring alignment, or comment/code phrasing issues
  - Any finding you would describe as "low probability", "low exploitability",
    "minor but", "worth noting", or "edge case"
  - Defensive coding suggestions where the dangerous path is already blocked
  - Duplicate or near-duplicate findings already raised in this review

Your review must:
- Be grounded in the repo context provided (risk scores, churn, history)
- Reference specific line numbers when flagging issues
- Be concise — no padding, no generic advice
- End with: overall verdict (ship it / fix before merge / needs discussion)
  and a suggested commit message for these changes

FORMAT RULES — follow exactly:
- Each finding starts on its own line with its emoji label
- One blank line between every finding
- One blank line before the verdict
- Never combine two findings into one paragraph
- Never use markdown headers or bold text
- A developer is reading this in a terminal

Example structure:

🔴 SECURITY Finding title. auth.py:47
Detail about the issue.
→ Suggested fix.

⚠ RISK Finding title.
Detail about the risk.

💡 SUGGESTION Optional improvement.

✓ GOOD What was done well.

Verdict: fix before merge
Suggested commit: fix(auth): harden token validation
""".strip()


# ─── Git helpers ──────────────────────────────────────────────────────────────

def _run_git(*args: str) -> str:
    try:
        result = subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
        )
        return result.stdout.strip()
    except Exception:
        return ""


def _load_scan() -> Optional[dict]:
    if not SCAN_FILE.exists():
        return None
    try:
        with open(SCAN_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _get_risk_scores(scan: dict) -> dict:
    scores = {}
    for entry in scan.get("files", []) + scan.get("results", []):
        path  = entry.get("path") or entry.get("file")
        score = entry.get("risk") or entry.get("risk_score") or entry.get("fragility")
        if path and score is not None:
            scores[path] = int(score)
    return scores


def _get_hotspot_pairs(scan: dict) -> list:
    return (
        scan.get("boundary_entropy", {}).get("hotspots")
        or scan.get("hotspots")
        or []
    )


def _get_last_touched(path: str) -> str:
    out = _run_git("log", "-1", "--format=%an|%cr", "--", path)
    if not out:
        return ""
    parts = out.split("|", 1)
    return f"{parts[0].strip()}, {parts[1].strip()}" if len(parts) == 2 else ""


def _get_churn(path: str, days: int = 30) -> int:
    out = _run_git("log", f"--since={days} days ago", "--oneline", "--", path)
    return len(out.splitlines()) if out else 0


def _find_test_file(path: str) -> Optional[str]:
    p = Path(path)
    stem = p.stem
    parent = str(p.parent)
    candidates = [
        f"tests/test_{stem}.py",
        f"tests/{stem}_test.py",
        f"test/test_{stem}.py",
        f"test_{stem}.py",
        f"{parent}/tests/test_{stem}.py",
    ]
    for c in candidates:
        if Path(c).exists():
            return c
    return None


# ─── Payload builder ──────────────────────────────────────────────────────────

def _build_review_payload(
    diff: str,
    changed_files: list[dict],
    scan: Optional[dict],
    quick: bool,
) -> str:
    """
    Build the full context payload for the Intelligence Engine.
    This is what makes gtr review smarter than a linter —
    every piece of repo intelligence we have goes in here.
    """
    lines = []

    # ── Mode ──────────────────────────────────────────────────────────────────
    if quick:
        lines.append("MODE: Quick review — flag critical issues only (security, correctness). Skip suggestions.")
    else:
        lines.append("MODE: Full review — security, correctness, risk, coupling, suggestions.")

    lines.append("")

    # ── Branch / commit context ───────────────────────────────────────────────
    branch   = _run_git("rev-parse", "--abbrev-ref", "HEAD")
    recent   = _run_git("log", "--oneline", f"-{MAX_LOG_LINES}")
    if branch:
        lines.append(f"Branch: {branch}")
    if recent:
        lines.append(f"Recent commits:\n{recent}")
    lines.append("")

    # ── Per-file intelligence ─────────────────────────────────────────────────
    risk_scores = _get_risk_scores(scan) if scan else {}
    hotspot_pairs = _get_hotspot_pairs(scan) if scan else []

    lines.append("=== Changed Files ===")
    for f in changed_files:
        path   = f["path"]
        status = f["status"]
        risk   = risk_scores.get(path)
        churn  = _get_churn(path)
        touched = _get_last_touched(path)
        test   = _find_test_file(path)
        test_changed = test and test in {x["path"] for x in changed_files}

        file_line = f"{status}: {path}"
        if risk is not None:
            file_line += f"  [risk: {risk}{'🔴' if risk>=80 else '⚠' if risk>=50 else ''}]"
        if churn >= 8:
            file_line += f"  [churn: {churn} commits/30d{'⚡' if churn>=20 else ''}]"
        if touched:
            file_line += f"  [last touched: {touched}]"
        if test and not test_changed:
            file_line += f"  [⚠ {test} exists but NOT modified]"
        elif test and test_changed:
            file_line += f"  [✓ {test} also modified]"
        else:
            file_line += "  [no test file found]"

        lines.append(file_line)

        # Coupling partners not in this diff
        coupling_misses = []
        for pair in hotspot_pairs:
            files = pair.get("files", [])
            if path in files:
                for partner in files:
                    if partner != path and partner not in {x["path"] for x in changed_files}:
                        coupling_misses.append(f"{partner} (co-changed {pair.get('count',0)}x)")
        if coupling_misses:
            lines.append(f"  Coupling partners NOT in this diff: {', '.join(coupling_misses[:3])}")

    lines.append("")

    # ── Raw diff ──────────────────────────────────────────────────────────────
    lines.append("=== Diff ===")
    diff_section = diff[:MAX_DIFF_CHARS]
    if len(diff) > MAX_DIFF_CHARS:
        diff_section += f"\n... (truncated — {len(diff) - MAX_DIFF_CHARS} chars omitted)"
    lines.append(diff_section)

    return "\n".join(lines)


# ─── Server call ──────────────────────────────────────────────────────────────

def _call_review(payload: str, token: str) -> Optional[str]:
    """Send review payload to /chat endpoint, return AI response."""
    try:
        response = requests.post(
            f"{GITRAMA_API_URL}/chat",
            headers={
                "Content-Type": "application/json",
                "x-gitrama-token": token,
            },
            json={
                "messages": [
                    {"role": "user", "content": REVIEW_SYSTEM_PROMPT},
                    {"role": "user", "content": payload}],
                "git_context": "",   # context is already in the payload
                "stream": False,
            },
            timeout=REQUEST_TIMEOUT,
        )

        if response.status_code == 401:
            console.print("[red]Auth failed — check your GITRAMA_TOKEN.[/red]")
            return None
        if response.status_code == 429:
            console.print("[yellow]Daily review limit reached. Upgrade at gitrama.ai.[/yellow]")
            return None
        if response.status_code != 200:
            console.print(f"[red]Server error ({response.status_code}) — try again.[/red]")
            return None

        data = response.json()
        return data.get("reply") or data.get("summary")

    except requests.exceptions.ConnectionError:
        console.print("[red]Cannot reach api.gitrama.ai. Check your connection.[/red]")
        return None
    except requests.exceptions.Timeout:
        console.print("[yellow]Review timed out — server is busy. Try again.[/yellow]")
        return None
    except Exception:
        return None


# ─── Output renderer ──────────────────────────────────────────────────────────

def _render_review(
    review_text: str,
    changed_files: list[dict],
    risk_scores: dict,
    quick: bool,
) -> None:
    """Render the review panel to the terminal."""

    # ── File summary bar ──────────────────────────────────────────────────────
    console.print()
    for f in changed_files:
        path   = f["path"]
        status = f["status"]
        risk   = risk_scores.get(path)

        status_color = {
            "Modified": "cyan", "Added": "green",
            "Deleted": "red",   "Renamed": "yellow",
        }.get(status, "white")

        if risk is None:
            risk_text = Text(" [risk: unknown]", style="dim")
        elif risk >= 80:
            risk_text = Text(f" [risk: {risk} 🔴]", style="bold red")
        elif risk >= 50:
            risk_text = Text(f" [risk: {risk} ⚠]", style="bold yellow")
        else:
            risk_text = Text(f" [risk: {risk}]", style="bold green")

        line = Text(f"  {status:<12}", style=status_color)
        line += Text(f"{path:<50}", style="white")
        line += risk_text
        console.print(line)

    console.print()

    # ── Review panel ──────────────────────────────────────────────────────────
    mode_label = "Quick Review" if quick else "Full Review"
    console.print(
        Panel(
            review_text,
            title=f"[bold green]🌿 gtr review — {mode_label}[/bold green]",
            border_style="green",
            padding=(1, 2),
        )
    )
    console.print()


# ─── Main Command ─────────────────────────────────────────────────────────────

def review(
    all_changes: bool = typer.Option(
        False, "--uncommitted", "-u",
        help="Review all uncommitted changes (staged + unstaged)"
    ),
    quick: bool = typer.Option(
        False, "--quick", "-q",
        help="Quick pass — critical issues only, no suggestions"
    ),
    full: bool = typer.Option(
        False, "--full", "-f",
        help="Full review: security, logic, history, coupling, suggestions"
    ),
):
    """
    🧠 AI code review before you push.

    Sends your diff + repo intelligence (risk scores, churn, coupling,
    test coverage) to the Intelligence Engine for a full pre-commit code review.

    Smarter than lint. Faster than a PR review. Runs before you push.

    \b
    EXAMPLES:
      gtr review                Review staged changes (default)
      gtr review --uncommitted  Review everything not yet committed
      gtr review -u             Same, short flag
      gtr review --quick        Critical issues only, fast
      gtr review -q             Same, short flag
      gtr review --full         Full review with suggestions
      gtr review -f             Same, short flag

    \b
    WHAT IT CHECKS:
      🔴 Security     — auth bypasses, injection, exposed secrets
      🔴 Correctness  — logic errors, edge cases, race conditions
      ⚠  Risk         — high-churn files, missing tests, fragile patterns
      ⚠  Coupling     — files you probably should have changed too
      💡 Suggestions  — optional improvements, not blockers
      ✓  Acknowledged — what was done well
    """

    token = get_value("gitrama_token") or get_value("GITRAMA_TOKEN") or os.environ.get("GITRAMA_TOKEN") or ""

    # ── Collect diff ──────────────────────────────────────────────────────────

    if all_changes:
        diff = _run_git("diff", "HEAD")
        name_status = _run_git("diff", "--name-status", "HEAD")
        scope_label = "all uncommitted changes"
    else:
        diff = _run_git("diff", "--staged")
        name_status = _run_git("diff", "--name-status", "--staged")
        scope_label = "staged changes"

    if not diff:
        if all_changes:
            console.print("[dim]No uncommitted changes.[/dim]")
        else:
            console.print(
                "[dim]No staged changes.[/dim] "
                "Use [bold]git add[/bold] to stage files, "
                "or run [bold]gtr review --all[/bold] to review everything."
            )
        return

    # ── Parse changed files ───────────────────────────────────────────────────

    changed_files = []
    for line in name_status.splitlines():
        parts = line.strip().split("\t", 1)
        if len(parts) < 2:
            continue
        status_code = parts[0][0].upper()
        path = parts[1].split("\t")[-1].strip()
        status_map = {"M": "Modified", "A": "Added", "D": "Deleted", "R": "Renamed"}
        changed_files.append({"status": status_map.get(status_code, status_code), "path": path})

    if not changed_files:
        console.print("[dim]No changes to review.[/dim]")
        return

    # ── Load scan data ────────────────────────────────────────────────────────

    scan = _load_scan()
    risk_scores = _get_risk_scores(scan) if scan else {}

    # ── Build payload ─────────────────────────────────────────────────────────

    console.print(
        f"\n  [dim]Reviewing {len(changed_files)} file"
        f"{'s' if len(changed_files) != 1 else ''} "
        f"({scope_label})...[/dim]"
    )

    payload = _build_review_payload(
        diff=diff,
        changed_files=changed_files,
        scan=scan,
        quick=quick,
    )

    # ── Call Intelligence Engine ──────────────────────────────────────────────

    with console.status("[dim]Intelligence Engine is reviewing your changes...[/dim]"):
        review_text = _call_review(payload, token)

    if not review_text:
        console.print(
            "[yellow]Review unavailable — server unreachable. "
            "Your diff is clean to commit.[/yellow]"
        )
        return

    # ── Render terminal output ────────────────────────────────────────────────

    _render_review(
        review_text=review_text,
        changed_files=changed_files,
        risk_scores=risk_scores,
        quick=quick,
    )

    # ── Browser panel ─────────────────────────────────────────────────────────
    # Opens after terminal output — non-blocking, never crashes CLI.

    if _open_review_panel:
        label = "--uncommitted" if all_changes else ("--quick" if quick else "--staged")
        t = _open_review_panel(
            review_text=review_text,
            changed_files=changed_files,
            risk_scores=risk_scores,
            label=label,
        )
        if t is not None:
            t.join(timeout=5.0)
