"""
Gitrama Usage Tracking
Manages free tier request counting — local + server enforced.
5 free requests for scan, ask, and chat messages.
Request 6 shows the token message and revokes access.

Copyright © 2026 Gitrama LLC. All Rights Reserved.
"""

import os
import json
import uuid
import hashlib
import platform
from pathlib import Path

GITRAMA_DIR   = Path.home() / ".gitrama"
USAGE_FILE    = GITRAMA_DIR / "usage.json"
CONFIG_FILE   = GITRAMA_DIR / "config.json"
FREE_LIMIT    = 5


# ─── Machine ID ───────────────────────────────────────────────────────────────

def _generate_machine_id() -> str:
    """
    Generate a stable machine ID from hardware identifiers.
    Hashed for privacy — never sends raw hardware info.
    Falls back to a random UUID stored locally if hardware ID unavailable.
    """
    components = []

    # Platform info
    components.append(platform.node())
    components.append(platform.machine())
    components.append(platform.processor())

    # Username
    components.append(os.environ.get("USERNAME") or os.environ.get("USER") or "")

    # Home directory path — stable per user per machine
    components.append(str(Path.home()))

    raw = "|".join(c for c in components if c)

    if raw.count("|") >= 2:
        return hashlib.sha256(raw.encode()).hexdigest()[:32]

    # Fallback — generate and store a random UUID
    return _get_or_create_random_id()


def _get_or_create_random_id() -> str:
    """Fallback machine ID — random UUID stored in ~/.gitrama/config.json"""
    GITRAMA_DIR.mkdir(parents=True, exist_ok=True)

    try:
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r") as f:
                data = json.load(f)
                if "machine_id" in data:
                    return data["machine_id"]
    except Exception:
        pass

    new_id = uuid.uuid4().hex[:32]
    try:
        config = {}
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
        config["machine_id"] = new_id
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
    except Exception:
        pass

    return new_id


def get_machine_id() -> str:
    """Return the stable machine ID for this installation."""
    GITRAMA_DIR.mkdir(parents=True, exist_ok=True)

    try:
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r") as f:
                data = json.load(f)
                if "machine_id" in data:
                    return data["machine_id"]
    except Exception:
        pass

    machine_id = _generate_machine_id()

    try:
        config = {}
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
        config["machine_id"] = machine_id
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
    except Exception:
        pass

    return machine_id


# ─── Local counter ────────────────────────────────────────────────────────────

def _load_usage() -> dict:
    """Load usage data from disk. Returns empty dict on any error."""
    try:
        if USAGE_FILE.exists():
            with open(USAGE_FILE, "r") as f:
                return json.load(f)
    except Exception:
        pass
    return {"requests": 0, "machine_id": get_machine_id()}


def _save_usage(data: dict) -> None:
    """Save usage data to disk. Failures are silently swallowed."""
    try:
        GITRAMA_DIR.mkdir(parents=True, exist_ok=True)
        with open(USAGE_FILE, "w") as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass


def get_local_count() -> int:
    """Return the current local request count."""
    return _load_usage().get("requests", 0)


def increment_local() -> int:
    """Increment the local counter and return the new count."""
    data = _load_usage()
    data["requests"] = data.get("requests", 0) + 1
    data["machine_id"] = get_machine_id()
    _save_usage(data)
    return data["requests"]


def is_locally_blocked() -> bool:
    """Return True if the local counter has hit or exceeded the free limit."""
    return get_local_count() >= FREE_LIMIT


# ─── Token message ────────────────────────────────────────────────────────────

UPGRADE_MESSAGE = """
╭─────────────────────────────────────────────────────────╮
│                                                         │
│   You've used your 5 free Gitrama requests.             │
│                                                         │
│   To continue, add your token:                          │
│                                                         │
│   gtr config set gitrama_token YOUR_TOKEN               │
│                                                         │
│   Get your token at: gitrama.ai                         │
│                                                         │
╰─────────────────────────────────────────────────────────╯
"""


# ─── Main gate ────────────────────────────────────────────────────────────────

def check_usage(token: str = "") -> tuple[bool, str]:
    """
    Check if the user is allowed to make a request.

    Returns (allowed: bool, reason: str).
    - If token is present and valid: always allowed, no counting.
    - If no token and under limit: allowed, count incremented.
    - If no token and at/over limit: blocked, show upgrade message.

    The local check is fast and runs first.
    Server-side enforcement happens at the API level.
    """
    # Paid users with a token — never blocked locally
    if token and token.strip():
        return True, "authenticated"

    # Check local counter first — fast path
    count = get_local_count()
    if count >= FREE_LIMIT:
        return False, UPGRADE_MESSAGE

    # Under limit — increment and allow
    new_count = increment_local()
    return True, f"free:{new_count}/{FREE_LIMIT}"