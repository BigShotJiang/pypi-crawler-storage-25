"""
scan_report.py — HTML browser panel for gtr scan
=================================================
Drop-in addition to scan.py.

Add the following imports at the top of scan.py:
    import tempfile
    import webbrowser

Usage in cmd_scan():
    scan_start = time.time()
    ...
    scan_duration = time.time() - scan_start
    if output_format == "json":
        print(json.dumps(result, indent=2))
    else:
        render_scan_result(result, repo_name, verbose=verbose, duration=scan_duration)
        render_scan_html(result, repo_name, duration=scan_duration)

Author: Alfonso Harding Jr
Company: Gitrama LLC
"""

import os
import tempfile
import webbrowser
from pathlib import Path


# ═══════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════

def _si_color_hex(si: int) -> str:
    if si >= 75: return "#4ade80"
    if si >= 60: return "#c9a84c"
    if si >= 45: return "#fb923c"
    return "#f87171"

def _si_label(si: int) -> str:
    if si >= 90: return "exceptional stability"
    if si >= 75: return "stable"
    if si >= 60: return "complex but stable"
    if si >= 45: return "architectural pressure"
    return "high risk"

def _level_color(level: str) -> str:
    return {
        "CRITICAL": "#f87171",
        "HIGH":     "#fb923c",
        "MEDIUM":   "#c9a84c",
        "LOW":      "#4ade80",
        "NONE":     "#4ade80",
    }.get(level, "#6b7c72")

def _fmt_duration(seconds: float) -> str:
    if seconds <= 0:
        return ""
    if seconds < 60:
        return f"{seconds:.1f}s"
    return f"{int(seconds // 60)}m {int(seconds % 60)}s"

def _score_bar(score: int) -> str:
    pct   = min(100, max(0, score))
    color = _si_color_hex(100 - score)
    return (
        f'<div class="score-bar-wrap">'
        f'<div class="score-bar-fill" style="width:{pct}%;background:{color};"></div>'
        f'</div>'
    )

def _fragile_row(i: int, mod: dict) -> str:
    path  = mod.get("path", "")
    score = mod.get("risk_score", 0)
    color = "#f87171" if score >= 70 else "#c9a84c" if score >= 40 else "#4ade80"
    is_security = any(k in path.lower() for k in [
        "bluetooth", "auth", "ssl", "tls", "crypto", "security",
        "payment", "jwt", "token", "cred", "passwd", "secret",
    ])
    flag = (
        '<span class="cve-flag" title="Security-sensitive path — monitor closely">'
        '&#9888; security-sensitive</span>'
    ) if is_security else ""
    return (
        f'<div class="fragile-row">'
        f'<span class="fragile-num">{i}</span>'
        f'<span class="fragile-path">{path}{flag}</span>'
        f'<span class="fragile-score" style="color:{color};">{score}</span>'
        f'</div>'
    )

def _coupling_row(i: int, hotspot: str) -> str:
    return (
        f'<div class="coupling-row">'
        f'<span class="coupling-num">{i}</span>'
        f'<span class="coupling-pair">{hotspot}</span>'
        f'</div>'
    )

def _signal_row_html(key: str, label: str, signals: dict) -> str:
    sig     = signals.get(key, {})
    level   = sig.get("level", "NONE")
    score   = sig.get("score", 0)
    details = sig.get("details", "")
    color   = _level_color(level)

    affected_key = {
        "continuity_risk":  "affected_modules",
        "boundary_entropy": "hotspots",
        "recurrence_risk":  "recurring_files",
    }.get(key, "affected_modules")

    affected      = sig.get(affected_key, [])
    affected_html = ""
    if affected:
        items = "".join(
            f'<div class="sig-affected-item">&#8594; {a}</div>'
            for a in affected[:4]
        )
        affected_html = f'<div class="sig-affected">{items}</div>'

    dot_class = {
        "CRITICAL": "red", "HIGH": "gold",
        "MEDIUM": "gold", "LOW": "green", "NONE": "green",
    }.get(level, "green")

    return (
        f'<div class="signal-row">'
        f'<div class="sig-dot {dot_class}"></div>'
        f'<div class="sig-body">'
        f'<div class="sig-title">'
        f'<span class="sig-name">{label}</span>'
        f'<span class="sig-level" style="color:{color};">{level}</span>'
        f'<span class="sig-score">(score: {score})</span>'
        f'</div>'
        f'{_score_bar(score)}'
        f'<div class="sig-detail">{details}</div>'
        f'{affected_html}'
        f'</div>'
        f'</div>'
    )


# ═══════════════════════════════════════════════════════════
# HTML BUILDER
# ═══════════════════════════════════════════════════════════

def build_scan_html(result: dict, repo_name: str, duration: float = 0.0) -> str:
    """
    Build the full HTML scan report from a scan result dict.

    Args:
        result:    The dict returned by send_scan_request()
        repo_name: e.g. "torvalds/linux"
        duration:  Elapsed scan time in seconds (time.time() - scan_start)
    """
    si         = result.get("stability_index", 0)
    delta      = result.get("delta")
    delta_days = result.get("delta_period_days", 90)
    signals    = result.get("signals", {})
    fragile    = result.get("fragile_modules", [])
    scan_id    = result.get("scan_id", "")
    scanned_at = result.get("scanned_at", "")
    narrative  = result.get("narrative", "")

    if not narrative:
        try:
            from .scan import generate_narrative
            narrative = generate_narrative(result, repo_name)
        except Exception:
            narrative = ""

    si_color = _si_color_hex(si)
    si_lbl   = _si_label(si)
    dur_str  = _fmt_duration(duration)
    dur_html = f" &middot; completed in {dur_str}" if dur_str else ""

    delta_html = ""
    if delta is not None and delta != 0:
        sign  = "&#8593;" if delta > 0 else "&#8595;"
        dcol  = "#4ade80" if delta > 0 else "#f87171"
        delta_html = (
            f'<span class="delta-badge" style="color:{dcol};'
            f'border-color:{dcol}20;background:{dcol}10;">'
            f'{sign} {abs(delta)}pts in {delta_days}d</span>'
        )

    signal_rows = (
        _signal_row_html("continuity_risk",  "Continuity Risk",  signals) +
        _signal_row_html("boundary_entropy", "Boundary Entropy", signals) +
        _signal_row_html("recurrence_risk",  "Recurrence Risk",  signals)
    )

    fragile_rows     = "".join(_fragile_row(i, m) for i, m in enumerate(fragile[:8], 1))
    fragile_section  = (
        f'<div class="panel">'
        f'<div class="panel-title">Most Fragile Modules</div>'
        f'{fragile_rows or "<div class=\'empty-state\'>No fragile modules detected.</div>"}'
        f'</div>'
    ) if fragile else ""

    hotspots         = signals.get("boundary_entropy", {}).get("hotspots", [])
    coupling_rows    = "".join(_coupling_row(i, h) for i, h in enumerate(hotspots[:6], 1))
    coupling_section = (
        f'<div class="panel">'
        f'<div class="panel-title">Highest Coupling Clusters</div>'
        f'{coupling_rows or "<div class=\'empty-state\'>No coupling clusters detected.</div>"}'
        f'</div>'
    ) if hotspots else ""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>gtr scan &mdash; {repo_name}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,200;0,9..144,400;1,9..144,300&family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet" />
  <style>
    :root {{
      --forest-deep: #080f0a;
      --sage:        #5a8a6a;
      --sage-light:  #a8d5b5;
      --cream:       #f7f4ee;
      --ink-muted:   #6b7c72;
      --ink-soft:    #3d4a42;
      --border:      rgba(168,213,181,0.1);
      --gold:        #c9a84c;
      --gold-light:  #f0d98a;
      --sig-detail:  #8aaa96;
    }}
    *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
    html {{ scroll-behavior: smooth; }}
    body {{
      font-family: 'DM Sans', sans-serif;
      background: var(--forest-deep);
      color: var(--cream);
      line-height: 1.6; min-height: 100vh; padding: 0 0 80px;
    }}
    body::before {{
      content: ''; position: fixed; inset: 0;
      background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.018'/%3E%3C/svg%3E");
      pointer-events: none; z-index: 0;
    }}
    .header {{
      background: rgba(10,16,12,0.9); backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border);
      padding: 0 2.5rem; height: 62px;
      display: flex; align-items: center; justify-content: space-between;
      position: sticky; top: 0; z-index: 50;
    }}
    .header-logo {{
      display: flex; align-items: center; gap: 10px;
      font-family: 'Fraunces', serif; font-size: 1.25rem; font-weight: 400;
      color: var(--sage-light); text-decoration: none;
    }}
    .header-meta {{
      display: flex; align-items: center; gap: 1.5rem;
      font-family: 'DM Mono', monospace; font-size: 0.85rem; color: var(--ink-muted);
    }}
    .header-badge {{
      background: rgba(201,168,76,0.1); border: 1px solid rgba(201,168,76,0.2);
      color: var(--gold); padding: 3px 12px; border-radius: 20px;
      font-size: 0.75rem; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase;
    }}
    .page {{ max-width: 1060px; margin: 0 auto; padding: 2.5rem 2rem 0; position: relative; z-index: 1; }}
    .score-hero {{
      background: rgba(255,255,255,0.015); border: 1px solid var(--border);
      border-radius: 20px; padding: 2.5rem 3rem; margin-bottom: 2rem;
      position: relative; overflow: hidden;
    }}
    .score-hero::before {{
      content: ''; position: absolute; top: -100px; right: -100px;
      width: 400px; height: 400px;
      background: radial-gradient(circle, {si_color}08 0%, transparent 70%);
      pointer-events: none;
    }}
    .score-top {{
      display: flex; align-items: flex-start; justify-content: space-between;
      gap: 2rem; flex-wrap: wrap; margin-bottom: 1.5rem;
    }}
    .score-left {{ flex: 1; }}
    .score-num-row {{ display: flex; align-items: baseline; gap: 12px; margin-bottom: 8px; }}
    .score-num {{
      font-family: 'Fraunces', serif; font-size: 5.5rem; font-weight: 200;
      color: {si_color}; line-height: 1; letter-spacing: -0.04em;
    }}
    .score-denom {{ font-size: 1.75rem; color: var(--ink-soft); }}
    .score-label-row {{ display: flex; align-items: center; gap: 12px; }}
    .score-tag {{
      font-size: 0.82rem; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;
      color: {si_color}; background: {si_color}14; border: 1px solid {si_color}30;
      padding: 4px 12px; border-radius: 20px;
    }}
    .delta-badge {{
      font-size: 0.85rem; font-weight: 600;
      padding: 4px 12px; border-radius: 20px; border: 1px solid;
    }}
    .score-repo {{
      font-family: 'DM Mono', monospace;
      font-size: 1.2rem; color: var(--sage-light); margin-top: 0.6rem;
    }}
    .score-right {{ text-align: right; }}
    .score-right .label {{
      font-size: 0.75rem; font-weight: 700; letter-spacing: 0.1em;
      text-transform: uppercase; color: var(--gold); margin-bottom: 8px;
    }}
    .score-right .sublabel {{
      font-size: 0.85rem; color: var(--ink-muted);
      font-family: 'DM Mono', monospace; line-height: 1.9;
    }}
    .narrative {{
      font-size: 1rem; color: var(--ink-muted); line-height: 1.85;
      border-left: 3px solid rgba(90,138,106,0.35);
      padding-left: 1.25rem; font-style: italic;
    }}
    .narrative strong {{
      font-family: 'DM Mono', monospace;
      color: var(--gold-light); font-style: normal; font-weight: 500;
    }}
    .signals-box {{
      background: rgba(255,255,255,0.015); border: 1px solid var(--border);
      border-radius: 16px; padding: 1.75rem 2rem;
      margin-bottom: 1.5rem; position: relative;
    }}
    .box-title {{
      position: absolute; top: -14px; left: 24px;
      background: var(--forest-deep); padding: 0 10px;
      font-size: 0.85rem; color: var(--sage); font-weight: 600; letter-spacing: 0.05em;
    }}
    .signal-row {{
      display: flex; align-items: flex-start; gap: 14px;
      padding: 14px 0; border-bottom: 1px solid rgba(168,213,181,0.05);
    }}
    .signal-row:last-child {{ border-bottom: none; padding-bottom: 0; }}
    .sig-dot {{
      width: 14px; height: 14px; border-radius: 50%;
      flex-shrink: 0; margin-top: 5px;
    }}
    .sig-dot.green {{ background: #4ade80; box-shadow: 0 0 8px rgba(74,222,128,0.5); }}
    .sig-dot.gold  {{ background: #c9a84c; box-shadow: 0 0 8px rgba(201,168,76,0.5); }}
    .sig-dot.red   {{ background: #f87171; box-shadow: 0 0 8px rgba(248,113,113,0.5); }}
    .sig-body {{ flex: 1; }}
    .sig-title {{ font-size: 16px; color: var(--sage-light); margin-bottom: 5px; }}
    .sig-name {{ font-weight: 600; }}
    .sig-level {{ font-size: 14px; margin-left: 8px; font-weight: 700; letter-spacing: 0.05em; }}
    .sig-score {{
      font-size: 14px; color: var(--ink-soft); margin-left: 6px;
      font-family: 'DM Mono', monospace;
    }}
    .sig-detail {{ font-size: 15px; color: var(--sig-detail); line-height: 1.65; margin-top: 4px; }}
    .sig-affected {{ margin-top: 8px; }}
    .sig-affected-item {{
      font-size: 13px; font-family: 'DM Mono', monospace;
      color: var(--gold-light); opacity: 0.8; line-height: 1.9;
    }}
    .score-bar-wrap {{
      height: 4px; background: rgba(255,255,255,0.06);
      border-radius: 2px; margin: 8px 0 0; overflow: hidden;
    }}
    .score-bar-fill {{ height: 100%; border-radius: 2px; transition: width 0.6s ease; }}
    .bottom-grid {{
      display: grid; grid-template-columns: 1fr 1fr;
      gap: 1.25rem; margin-bottom: 2rem;
    }}
    .panel {{
      background: rgba(255,255,255,0.02); border: 1px solid var(--border);
      border-radius: 14px; padding: 1.5rem;
    }}
    .panel-title {{
      font-size: 0.75rem; font-weight: 700; letter-spacing: 0.12em;
      text-transform: uppercase; color: var(--gold); margin-bottom: 1.1rem;
    }}
    .empty-state {{ font-size: 0.9rem; color: var(--ink-muted); }}
    .fragile-row {{
      display: flex; align-items: center; gap: 10px;
      padding: 9px 0; border-bottom: 1px solid rgba(168,213,181,0.05);
    }}
    .fragile-row:last-child {{ border-bottom: none; padding-bottom: 0; }}
    .fragile-num {{ font-size: 0.85rem; color: var(--ink-soft); width: 20px; flex-shrink: 0; }}
    .fragile-path {{
      font-family: 'DM Mono', monospace; font-size: 0.88rem;
      color: var(--sage-light); flex: 1;
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }}
    .fragile-score {{
      font-family: 'DM Mono', monospace; font-size: 0.95rem;
      font-weight: 700; width: 32px; text-align: right; flex-shrink: 0;
    }}
    .cve-flag {{
      font-size: 0.7rem; font-weight: 700;
      color: #f87171; background: rgba(248,113,113,0.08);
      border: 1px solid rgba(248,113,113,0.2);
      padding: 1px 6px; border-radius: 4px;
      margin-left: 8px; vertical-align: middle; white-space: nowrap;
    }}
    .coupling-row {{
      display: flex; align-items: center; gap: 10px;
      padding: 9px 0; border-bottom: 1px solid rgba(168,213,181,0.05);
    }}
    .coupling-row:last-child {{ border-bottom: none; padding-bottom: 0; }}
    .coupling-num {{ font-size: 0.85rem; color: var(--ink-soft); width: 20px; flex-shrink: 0; }}
    .coupling-pair {{
      font-family: 'DM Mono', monospace; font-size: 0.88rem;
      color: var(--sig-detail); flex: 1;
    }}
    .report-footer {{
      display: flex; justify-content: space-between; align-items: center;
      padding-top: 1.25rem; margin-top: 1rem;
      border-top: 1px solid rgba(168,213,181,0.06);
      font-family: 'DM Mono', monospace; font-size: 0.78rem;
      color: #3d5445; flex-wrap: wrap; gap: 0.5rem;
    }}
    @media (max-width: 800px) {{
      .bottom-grid {{ grid-template-columns: 1fr; }}
      .score-num   {{ font-size: 4rem; }}
      .score-top   {{ flex-direction: column; }}
      .header      {{ padding: 0 1.25rem; }}
    }}
    @keyframes fadeUp {{
      from {{ opacity: 0; transform: translateY(16px); }}
      to   {{ opacity: 1; transform: translateY(0); }}
    }}
    .score-hero   {{ animation: fadeUp 0.5s ease both; }}
    .signals-box  {{ animation: fadeUp 0.5s 0.1s ease both; }}
    .bottom-grid  {{ animation: fadeUp 0.5s 0.2s ease both; }}
  </style>
</head>
<body>

  <header class="header">
    <a href="https://gitrama.ai" class="header-logo" target="_blank">&#127807; Gitrama</a>
    <div class="header-meta">
      <span>{repo_name}</span>
      <span class="header-badge">gtr scan &middot; v1.4.0</span>
    </div>
  </header>

  <div class="page">

    <div class="score-hero">
      <div class="score-top">
        <div class="score-left">
          <div class="score-num-row">
            <div class="score-num">{si}</div>
            <div class="score-denom">/ 100</div>
          </div>
          <div class="score-label-row">
            <span class="score-tag">{si_lbl}</span>
            {delta_html}
          </div>
          <div class="score-repo">{repo_name}</div>
        </div>
        <div class="score-right">
          <div class="label">Stability Index</div>
          <div class="sublabel">
            Deterministic &middot; Commit History<br>
            No LLM &middot; No Static Analysis
          </div>
        </div>
      </div>
      <div class="narrative">{narrative}</div>
    </div>

    <div class="signals-box">
      <div class="box-title">Decay Signals</div>
      {signal_rows}
    </div>

    <div class="bottom-grid">
      {fragile_section}
      {coupling_section}
    </div>

    <div class="report-footer">
      <span>Gitrama Repository Intelligence &middot; Deterministic Scoring &middot; No LLM</span>
      <span>Scan ID: {scan_id} &middot; {scanned_at}{dur_html}</span>
    </div>

  </div>
</body>
</html>"""


# ═══════════════════════════════════════════════════════════
# RENDER + OPEN
# ═══════════════════════════════════════════════════════════

def render_scan_html(result: dict, repo_name: str,
                     duration: float = 0.0, auto_open: bool = True) -> str:
    """
    Generate the scan HTML report, write to a temp file,
    and open it in the default browser (same pattern as gtr diff).

    Args:
        result:    The dict returned by send_scan_request()
        repo_name: e.g. "torvalds/linux"
        duration:  Elapsed scan time in seconds (pass time.time() - scan_start)
        auto_open: Set False for CI/CD pipelines
    """
    html       = build_scan_html(result, repo_name, duration=duration)
    short_name = repo_name.replace("/", "_").replace("\\", "_")
    html_path  = Path(tempfile.gettempdir()) / f"gtr_scan_{short_name}.html"

    html_path.write_text(html, encoding="utf-8")

    if auto_open:
        try:
            if os.name == "nt":
                os.startfile(str(html_path))
            else:
                webbrowser.open(f"file://{html_path}", new=2)
        except Exception:
            pass  # Never let browser open failure kill the CLI

    return str(html_path)
