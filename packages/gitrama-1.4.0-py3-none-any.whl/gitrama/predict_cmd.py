"""
gtr predict — Predictive Failure Hotspot Forecasting
=====================================================
Analyzes commit history to forecast which files are most
likely to experience incidents in the next N days.

Four signals combined into a prediction score:
  1. Recurrence velocity   — patch frequency acceleration
  2. Churn concentration   — ownership + recent inactivity
  3. Coupling exposure     — co-change with other high-risk files
  4. Decay trajectory      — rolling Stability Index direction

Every prediction is timestamped and saved locally.
Optionally published to gitrama.ai for immutable public record.

Author: Alfonso Harding Jr
Company: Gitrama LLC
Copyright © 2026 Gitrama LLC. All Rights Reserved.
"""

import json
import os
import re
import subprocess
import sys
import time
import uuid
import hashlib
import platform
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.rule import Rule
from rich import box

console = Console()

# ─── Constants ────────────────────────────────────────────────────────────────

PREDICTIONS_FILE  = Path.home() / ".gitrama" / "predictions.json"
LAST_PREDICT_FILE = Path(".gitrama") / "last_predict.json"  # repo-local, for gtr watch

DEFAULT_HORIZON   = 90   # days
MAX_FILES_OUTPUT  = 10
MIN_COMMITS       = 5    # minimum commits to a file before scoring

NOW_TS  = int(time.time())
DAYS    = 86400

RISK_COLORS = {
    "CRITICAL": "bold red",
    "HIGH":     "bold yellow",
    "MEDIUM":   "yellow",
    "LOW":      "green",
}

RISK_ICONS = {
    "CRITICAL": "🔴",
    "HIGH":     "🟠",
    "MEDIUM":   "🟡",
    "LOW":      "🟢",
}

NOISE_FILES = {
    "package-lock.json", "yarn.lock", "poetry.lock", "Pipfile.lock",
    "Cargo.lock", "composer.lock", "Gemfile.lock", ".gitignore",
    "README.md", "CHANGELOG.md", "LICENSE", "LICENSE.txt",
    "pyproject.toml", "setup.cfg",
}

NOISE_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico",
    ".woff", ".woff2", ".ttf", ".eot", ".pdf",
    ".zip", ".tar", ".gz", ".min.js", ".min.css",
}

NOISE_PREFIXES = (
    ".git/", "node_modules/", ".venv/", "venv/",
    "__pycache__/", "dist/", "build/", ".gradle/",
)


# ─── Git helpers ──────────────────────────────────────────────────────────────

def _run(cmd, timeout: int = 30) -> str:
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=timeout, encoding="utf-8", errors="replace",
            shell=isinstance(cmd, str),
        )
        return result.stdout.strip()
    except Exception:
        return ""


def _is_noise(filepath: str) -> bool:
    name = os.path.basename(filepath)
    if name in NOISE_FILES:
        return True
    if any(filepath.startswith(p) for p in NOISE_PREFIXES):
        return True
    _, ext = os.path.splitext(name)
    if ext in NOISE_EXTENSIONS:
        return True
    return False


def _get_repo_name() -> str:
    remote = _run(["git", "remote", "get-url", "origin"])
    if remote:
        if remote.endswith(".git"):
            remote = remote[:-4]
        parts = remote.rstrip("/").replace("git@github.com:", "").replace("https://github.com/", "").split("/")
        if len(parts) >= 2:
            return f"{parts[-2]}/{parts[-1]}"
    return Path(os.getcwd()).name


# ─── Data collection ──────────────────────────────────────────────────────────

def _collect_file_commits(horizon_days: int) -> dict[str, list[dict]]:
    """
    Collect per-file commit history.
    Returns: {filepath: [{ts, author, email, message}, ...]}
    Looks back horizon_days * 3 to have enough history for trend analysis.
    """
    lookback = horizon_days * 3
    cutoff   = NOW_TS - (lookback * DAYS)

    raw = _run([
        "git", "log",
        f"--after={cutoff}",
        "--pretty=format:%H|%an|%ae|%at|%s",
        "--name-only",
        "--no-merges",
    ], timeout=60)

    if not raw:
        return {}

    file_commits: dict[str, list[dict]] = defaultdict(list)
    current_meta = None

    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue

        if "|" in line and len(line.split("|")) == 5:
            parts        = line.split("|", 4)
            current_meta = {
                "hash":    parts[0][:12],
                "author":  parts[1],
                "email":   parts[2],
                "ts":      int(parts[3]) if parts[3].isdigit() else 0,
                "message": parts[4],
            }
        elif current_meta and "/" in line or (current_meta and "." in line):
            if not _is_noise(line):
                file_commits[line].append(current_meta)

    return file_commits


def _collect_all_file_authors(lookback_days: int = 365) -> dict[str, dict[str, int]]:
    """
    Collect all-time author → commit count per file (for ownership analysis).
    Returns: {filepath: {author: commit_count}}
    """
    cutoff = NOW_TS - (lookback_days * DAYS)
    raw    = _run([
        "git", "log",
        f"--after={cutoff}",
        "--pretty=format:%an|%at",
        "--name-only",
        "--no-merges",
    ], timeout=60)

    file_authors: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    current_author = None
    current_ts     = 0

    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        if "|" in line and len(line.split("|")) == 2:
            parts          = line.split("|", 1)
            current_author = parts[0]
            current_ts     = int(parts[1]) if parts[1].isdigit() else 0
        elif current_author and ("/" in line or "." in line):
            if not _is_noise(line):
                file_authors[line][current_author] += 1

    return file_authors


def _collect_coupling_map(horizon_days: int) -> dict[str, set[str]]:
    """
    Build a co-change coupling map: files that frequently change together.
    Returns: {filepath: {coupled_file, ...}}
    """
    cutoff = NOW_TS - (horizon_days * DAYS)
    raw    = _run([
        "git", "log",
        f"--after={cutoff}",
        "--pretty=format:%H",
        "--name-only",
        "--no-merges",
    ], timeout=60)

    commit_files: list[list[str]] = []
    current_commit = None
    current_files  = []

    for line in raw.splitlines():
        line = line.strip()
        if not line:
            if current_files:
                commit_files.append(current_files)
                current_files = []
            continue
        if len(line) == 40 and all(c in "0123456789abcdef" for c in line):
            if current_files:
                commit_files.append(current_files)
            current_files  = []
            current_commit = line
        elif current_commit and ("/" in line or "." in line):
            if not _is_noise(line):
                current_files.append(line)

    if current_files:
        commit_files.append(current_files)

    coupling: dict[str, set[str]] = defaultdict(set)
    for files in commit_files:
        if len(files) < 2:
            continue
        for f in files:
            for g in files:
                if f != g:
                    coupling[f].add(g)

    return coupling


# ─── Prediction engine ────────────────────────────────────────────────────────

def _score_recurrence_velocity(commits: list[dict], horizon_days: int) -> tuple[float, str]:
    """
    Measure acceleration in patch frequency.
    Compare patch rate in the last third of the window vs the first third.
    Acceleration = rising risk. Deceleration = stabilizing.
    Returns (score 0-100, signal_label)
    """
    if len(commits) < MIN_COMMITS:
        return 0.0, ""

    window   = horizon_days * DAYS
    third    = window // 3
    now      = NOW_TS
    early_ts = now - window
    mid_ts   = now - (third * 2)
    recent_ts = now - third

    early  = [c for c in commits if early_ts  <= c["ts"] < mid_ts]
    recent = [c for c in commits if recent_ts <= c["ts"] <= now]

    if not recent:
        return 0.0, ""

    # Normalize by time period length
    early_rate  = len(early)  / (third / DAYS) if early  else 0
    recent_rate = len(recent) / (third / DAYS) if recent else 0

    if recent_rate == 0:
        return 0.0, ""

    acceleration = recent_rate / max(early_rate, 0.01)

    # Fix keywords in recent commits
    fix_keywords = {"fix", "hotfix", "patch", "bug", "revert", "urgent", "broken", "critical"}
    fix_recent   = sum(
        1 for c in commits
        if c["ts"] >= recent_ts and any(kw in c["message"].lower() for kw in fix_keywords)
    )

    base_score  = min(50, acceleration * 20)
    fix_bonus   = min(30, fix_recent * 10)
    total_score = min(100, base_score + fix_bonus)

    signal = ""
    if acceleration > 2.0:
        signal = "recurrence ↑↑"
    elif acceleration > 1.3:
        signal = "recurrence ↑"
    elif fix_recent >= 3:
        signal = f"{fix_recent} fix commits"

    return total_score, signal


def _score_churn_concentration(
    file_commits: list[dict],
    all_authors: dict[str, int],
    horizon_days: int,
) -> tuple[float, str]:
    """
    Measure ownership concentration + maintainer inactivity.
    High ownership % + recent inactivity = high risk.
    Returns (score 0-100, signal_label)
    """
    if not all_authors:
        return 0.0, ""

    total = sum(all_authors.values())
    if total == 0:
        return 0.0, ""

    top_author     = max(all_authors, key=lambda k: all_authors[k])
    top_pct        = all_authors[top_author] / total
    recent_cutoff  = NOW_TS - (30 * DAYS)

    # When did top author last commit to this file?
    top_commits    = [c for c in file_commits if c["author"] == top_author]
    last_ts        = max((c["ts"] for c in top_commits), default=0)
    inactive_days  = (NOW_TS - last_ts) // DAYS if last_ts else 999
    bus_factor     = len([a for a in all_authors if all_authors[a] / total > 0.1])

    ownership_score  = top_pct * 50                                    # 0-50
    inactivity_score = min(30, (inactive_days / 90) * 30)              # 0-30
    bus_factor_score = max(0, (3 - bus_factor) * 7)                    # 0-21

    total_score = min(100, ownership_score + inactivity_score + bus_factor_score)

    signal = ""
    if top_pct >= 0.7 and inactive_days > 30:
        signal = f"single owner inactive {inactive_days}d"
    elif top_pct >= 0.6:
        signal = f"ownership gap ({int(top_pct*100)}% {top_author.split()[0]})"
    elif bus_factor == 1:
        signal = "bus factor: 1"

    return total_score, signal


def _score_coupling_exposure(
    filepath: str,
    coupling_map: dict[str, set[str]],
    file_scores: dict[str, float],
) -> tuple[float, str]:
    """
    Measure risk propagation from coupled files.
    A file coupled to many other high-risk files inherits their risk.
    Returns (score 0-100, signal_label)
    """
    coupled = coupling_map.get(filepath, set())
    if not coupled:
        return 0.0, ""

    # Score based on how many of the coupled files are also high-risk
    high_risk_coupled = [f for f in coupled if file_scores.get(f, 0) >= 50]
    coupling_score    = min(40, len(coupled) * 5)
    propagation_score = min(60, len(high_risk_coupled) * 15)
    total_score       = min(100, coupling_score + propagation_score)

    signal = ""
    if high_risk_coupled:
        signal = f"coupling ({len(coupled)} files, {len(high_risk_coupled)} high-risk)"
    elif len(coupled) > 5:
        signal = f"high coupling ({len(coupled)} files)"

    return total_score, signal


def _score_decay_trajectory(commits: list[dict], horizon_days: int) -> tuple[float, str]:
    """
    Measure whether fix/patch density is trending up over time.
    Rising fix density = degrading code quality = higher incident risk.
    Returns (score 0-100, signal_label)
    """
    if len(commits) < 4:
        return 0.0, ""

    fix_keywords = {"fix", "hotfix", "patch", "bug", "revert", "broken", "urgent"}

    # Split into 3 equal windows
    sorted_commits = sorted(commits, key=lambda c: c["ts"])
    third          = len(sorted_commits) // 3
    if third == 0:
        return 0.0, ""

    windows = [
        sorted_commits[:third],
        sorted_commits[third:third*2],
        sorted_commits[third*2:],
    ]

    fix_rates = []
    for window in windows:
        if not window:
            fix_rates.append(0.0)
            continue
        fixes = sum(1 for c in window if any(kw in c["message"].lower() for kw in fix_keywords))
        fix_rates.append(fixes / len(window))

    # Is the trajectory rising?
    if len(fix_rates) < 3:
        return 0.0, ""

    trajectory = fix_rates[2] - fix_rates[0]

    if trajectory <= 0:
        return 0.0, ""

    score  = min(100, trajectory * 200)
    signal = "fix density ↑" if trajectory > 0.2 else ""

    return score, signal


def _estimate_horizon(prediction_score: float, horizon_days: int) -> str:
    """
    Convert a prediction score into an estimated days-to-incident range.
    Higher score = shorter horizon.
    """
    if prediction_score >= 85:
        days = int(horizon_days * 0.2)
        return f"~{days} days"
    elif prediction_score >= 70:
        days = int(horizon_days * 0.4)
        return f"~{days} days"
    elif prediction_score >= 55:
        days = int(horizon_days * 0.6)
        return f"~{days} days"
    elif prediction_score >= 40:
        days = int(horizon_days * 0.8)
        return f"~{days} days"
    else:
        return f"~{horizon_days} days"


def _score_to_level(score: float) -> str:
    if score >= 80: return "CRITICAL"
    if score >= 60: return "HIGH"
    if score >= 40: return "MEDIUM"
    return "LOW"


def run_prediction_engine(horizon_days: int) -> list[dict]:
    """
    Main prediction engine.
    Returns ranked list of file predictions.
    """
    console.print("[dim]Collecting commit history...[/dim]")
    file_commits  = _collect_file_commits(horizon_days)

    if not file_commits:
        return []

    console.print("[dim]Analyzing ownership patterns...[/dim]")
    all_file_authors = _collect_all_file_authors(lookback_days=365)

    console.print("[dim]Mapping coupling relationships...[/dim]")
    coupling_map = _collect_coupling_map(horizon_days)

    # ── Pass 1: Score recurrence + churn (no coupling dependency) ──────────────
    preliminary_scores: dict[str, float] = {}

    for filepath, commits in file_commits.items():
        if len(commits) < MIN_COMMITS:
            continue

        r_score, _ = _score_recurrence_velocity(commits, horizon_days)
        c_score, _ = _score_churn_concentration(
            commits, all_file_authors.get(filepath, {}), horizon_days
        )
        d_score, _ = _score_decay_trajectory(commits, horizon_days)

        preliminary_scores[filepath] = (r_score * 0.35 + c_score * 0.35 + d_score * 0.15)

    # ── Pass 2: Full score with coupling (uses Pass 1 scores for propagation) ──
    predictions = []

    for filepath, commits in file_commits.items():
        if len(commits) < MIN_COMMITS:
            continue

        r_score, r_signal = _score_recurrence_velocity(commits, horizon_days)
        c_score, c_signal = _score_churn_concentration(
            commits, all_file_authors.get(filepath, {}), horizon_days
        )
        x_score, x_signal = _score_coupling_exposure(filepath, coupling_map, preliminary_scores)
        d_score, d_signal = _score_decay_trajectory(commits, horizon_days)

        # Weighted composite
        prediction_score = (
            r_score * 0.35 +
            c_score * 0.30 +
            x_score * 0.20 +
            d_score * 0.15
        )

        if prediction_score < 15:
            continue

        # Collect active signals
        signals = [s for s in [r_signal, c_signal, x_signal, d_signal] if s]
        signal_str = " + ".join(signals[:2]) if signals else "pattern detected"

        # Most recent commit info
        recent_commit = max(commits, key=lambda c: c["ts"])
        last_author   = recent_commit["author"]
        last_message  = recent_commit["message"][:60]

        predictions.append({
            "file":             filepath,
            "score":            round(prediction_score, 1),
            "level":            _score_to_level(prediction_score),
            "horizon":          _estimate_horizon(prediction_score, horizon_days),
            "signal":           signal_str,
            "commit_count":     len(commits),
            "last_author":      last_author,
            "last_commit":      last_message,
            "r_score":          round(r_score, 1),
            "c_score":          round(c_score, 1),
            "x_score":          round(x_score, 1),
            "d_score":          round(d_score, 1),
        })

    # Sort by prediction score descending
    predictions.sort(key=lambda p: p["score"], reverse=True)
    return predictions[:MAX_FILES_OUTPUT]


# ─── Output rendering ─────────────────────────────────────────────────────────

def render_predictions(
    predictions: list[dict],
    repo_name: str,
    horizon_days: int,
    pred_id: str,
    timestamp: str,
    commit_count: int,
):
    """Render prediction results to terminal."""
    console.print()

    if not predictions:
        console.print(Panel(
            "[bold green]🔮 No significant risk patterns detected.[/bold green]\n\n"
            f"Analyzed {commit_count} commits over {horizon_days}-day window.\n"
            "All files show stable commit patterns — no incident indicators found.",
            title="[bold green]🌿 gtr predict[/bold green]",
            border_style="green",
            padding=(1, 2),
        ))
        return

    critical = sum(1 for p in predictions if p["level"] == "CRITICAL")
    high     = sum(1 for p in predictions if p["level"] == "HIGH")

    header = (
        f"[bold]Risk Forecast[/bold]  [dim]horizon: {horizon_days} days   |   "
        f"commits analyzed: {commit_count}[/dim]\n"
        f"[dim]Repo: {repo_name}[/dim]"
    )
    if critical:
        header += f"\n\n[bold red]{critical} CRITICAL[/bold red]  [yellow]{high} HIGH[/yellow] — immediate attention recommended"

    console.print(Panel(
        header,
        title="[bold green]🌿 gtr predict[/bold green]",
        border_style="green",
        padding=(1, 2),
    ))

    console.print()

    table = Table(box=box.SIMPLE, show_header=True, padding=(0, 1))
    table.add_column("RANK",    style="dim",         width=5,  no_wrap=True)
    table.add_column("LEVEL",   style="bold",        width=10, no_wrap=True)
    table.add_column("FILE",                         width=40, no_wrap=True)
    table.add_column("SCORE",   style="dim",         width=7,  no_wrap=True)
    table.add_column("HORIZON", style="cyan",        width=10, no_wrap=True)
    table.add_column("SIGNAL",  style="dim italic",  width=35)

    for i, p in enumerate(predictions, 1):
        color = RISK_COLORS.get(p["level"], "white")
        icon  = RISK_ICONS.get(p["level"], "⚪")
        fname = p["file"]
        if len(fname) > 38:
            fname = "..." + fname[-35:]

        table.add_row(
            str(i),
            f"[{color}]{icon} {p['level']}[/{color}]",
            fname,
            f"{p['score']}",
            p["horizon"],
            p["signal"],
        )

    console.print(table)
    console.print()

    # ── Top finding detail ──
    top = predictions[0]
    console.print(Panel(
        f"[bold]Top risk:[/bold] {top['file']}\n\n"
        f"  Prediction score:  [bold]{top['score']}[/bold] / 100\n"
        f"  Estimated window:  [cyan]{top['horizon']}[/cyan]\n"
        f"  Commits analyzed:  {top['commit_count']}\n"
        f"  Last activity:     {top['last_author']} — \"{top['last_commit']}\"\n\n"
        f"  [dim]Recurrence: {top['r_score']}   Ownership: {top['c_score']}   "
        f"Coupling: {top['x_score']}   Decay: {top['d_score']}[/dim]",
        title="[bold yellow]📍 Highest Risk File[/bold yellow]",
        border_style="yellow",
        padding=(1, 2),
    ))

    console.print()
    console.print(f"  [dim]Prediction ID: [bold]{pred_id}[/bold][/dim]")
    console.print(f"  [dim]Timestamp:     {timestamp}[/dim]")
    console.print(f"  [dim]Saved to:      ~/.gitrama/predictions.json[/dim]")
    console.print()
    console.print(
        "  [dim]Run [bold]gtr watch[/bold] to monitor these files for new commits.[/dim]"
    )
    console.print()


# ─── Persistence ──────────────────────────────────────────────────────────────

def _save_prediction(
    pred_id: str,
    timestamp: str,
    repo_name: str,
    horizon_days: int,
    predictions: list[dict],
    commit_count: int,
):
    """Save prediction to ~/.gitrama/predictions.json (append)."""
    PREDICTIONS_FILE.parent.mkdir(parents=True, exist_ok=True)

    existing = []
    try:
        if PREDICTIONS_FILE.exists():
            with open(PREDICTIONS_FILE, "r") as f:
                existing = json.load(f)
    except Exception:
        existing = []

    record = {
        "pred_id":      pred_id,
        "timestamp":    timestamp,
        "repo":         repo_name,
        "horizon_days": horizon_days,
        "commit_count": commit_count,
        "predictions":  predictions,
    }

    existing.append(record)

    # Keep last 100 predictions
    if len(existing) > 100:
        existing = existing[-100:]

    try:
        with open(PREDICTIONS_FILE, "w") as f:
            json.dump(existing, f, indent=2)
    except Exception:
        pass


def _save_last_predict(predictions: list[dict], pred_id: str, timestamp: str):
    """
    Save last_predict.json to the repo root .gitrama/ dir.
    Used by gtr watch to know which files to monitor.
    """
    try:
        LAST_PREDICT_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(LAST_PREDICT_FILE, "w") as f:
            json.dump({
                "pred_id":   pred_id,
                "timestamp": timestamp,
                "files":     [
                    {
                        "path":  p["file"],
                        "score": p["score"],
                        "level": p["level"],
                    }
                    for p in predictions
                ],
            }, f, indent=2)
    except Exception:
        pass


# ─── Main entry point ─────────────────────────────────────────────────────────

def cmd_predict(
    horizon: int = DEFAULT_HORIZON,
    json_output: bool = False,
    show_all: bool = False,
    no_save: bool = False,
):
    """
    Main entry point for `gtr predict`.
    Called from the CLI dispatcher.
    """
    import platform as _platform

    # ── Auth gate ──────────────────────────────────────────────────────────────
    token = ""
    try:
        config_path = Path.home() / ".gitrama" / "config.json"
        if config_path.exists():
            with open(config_path) as f:
                cfg   = json.load(f)
                token = cfg.get("token") or cfg.get("gitrama_token") or ""
    except Exception:
        pass
    if not token:
        token = os.environ.get("GITRAMA_TOKEN", "")

    if token:
        try:
            from .auth_cache import check_limit, increment_local_usage
            ok, reason = check_limit(cost=1)
            if not ok:
                console.print(Panel(
                    "[bold yellow]🌿 You've used your 5 free Gitrama requests.[/bold yellow]\n\n"
                    "To continue, add your token:\n"
                    "  [bold]gtr config set gitrama_token YOUR_TOKEN[/bold]\n\n"
                    "Get your token at: [bold]gitrama.ai[/bold]",
                    border_style="yellow",
                ))
                sys.exit(0)
        except ImportError:
            pass
    else:
        try:
            from .usage import check_usage
            allowed, reason = check_usage(token="")
            if not allowed:
                console.print(reason)
                sys.exit(0)
        except ImportError:
            pass

    # ── Git repo check ─────────────────────────────────────────────────────────
    result = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        capture_output=True, text=True,
        shell=_platform.system() == "Windows",
    )
    if result.returncode != 0:
        console.print("\n[red]Not a git repository.[/red] Run [bold]gtr predict[/bold] from inside a git repo.\n")
        sys.exit(1)

    repo_name    = ""
    remote       = _run(["git", "remote", "get-url", "origin"])
    if remote:
        if remote.endswith(".git"):
            remote = remote[:-4]
        parts = remote.rstrip("/").replace("git@github.com:", "").replace("https://github.com/", "").split("/")
        if len(parts) >= 2:
            repo_name = f"{parts[-2]}/{parts[-1]}"
    if not repo_name:
        repo_name = Path(os.getcwd()).name

    commit_count_raw = _run(["git", "rev-list", "--count", "HEAD"], timeout=15)
    commit_count     = int(commit_count_raw) if commit_count_raw.isdigit() else 0

    console.print()
    console.print(Panel(
        f"[bold]Analyzing commit patterns...[/bold]\n"
        f"[dim]Repo: {repo_name}   |   Horizon: {horizon} days   |   "
        f"Total commits: {commit_count}[/dim]",
        title="[bold green]🌿 gtr predict[/bold green]",
        border_style="green",
        padding=(1, 2),
    ))
    console.print()

    # ── Run engine ────────────────────────────────────────────────────────────
    predictions = run_prediction_engine(horizon_days=horizon)

    # ── Generate prediction ID and timestamp ──────────────────────────────────
    ts_utc    = datetime.now(timezone.utc)
    timestamp = ts_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    date_part = ts_utc.strftime("%Y%m%d")

    # Deterministic ID: date + repo hash + top file hash
    top_file  = predictions[0]["file"] if predictions else "none"
    raw_id    = f"{date_part}:{repo_name}:{top_file}"
    short_hash = hashlib.md5(raw_id.encode()).hexdigest()[:6]
    pred_id   = f"pred_{date_part}_{short_hash}"

    # ── Output ────────────────────────────────────────────────────────────────
    if json_output:
        output = {
            "pred_id":      pred_id,
            "timestamp":    timestamp,
            "repo":         repo_name,
            "horizon_days": horizon,
            "commit_count": commit_count,
            "predictions":  predictions,
        }
        print(json.dumps(output, indent=2))
    else:
        render_predictions(
            predictions  = predictions,
            repo_name    = repo_name,
            horizon_days = horizon,
            pred_id      = pred_id,
            timestamp    = timestamp,
            commit_count = commit_count,
        )

    # ── Save ──────────────────────────────────────────────────────────────────
    if not no_save and predictions:
        _save_prediction(pred_id, timestamp, repo_name, horizon, predictions, commit_count)
        _save_last_predict(predictions, pred_id, timestamp)

    # ── Increment usage ───────────────────────────────────────────────────────
    if token:
        try:
            from .auth_cache import increment_local_usage
            increment_local_usage(cost=1)
        except ImportError:
            pass

    return predictions


# ─── CLI wiring ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="gtr predict — Forecast failure hotspots from commit history")
    parser.add_argument("--horizon", type=int, default=DEFAULT_HORIZON,
                        help=f"Forecast window in days (default: {DEFAULT_HORIZON})")
    parser.add_argument("--json",    action="store_true", help="Output as JSON")
    parser.add_argument("--all",     action="store_true", help="Show all findings (no limit)")
    parser.add_argument("--no-save", action="store_true", help="Don't save prediction to disk")

    args = parser.parse_args()
    cmd_predict(
        horizon     = args.horizon,
        json_output = args.json,
        show_all    = args.all,
        no_save     = args.no_save,
    )