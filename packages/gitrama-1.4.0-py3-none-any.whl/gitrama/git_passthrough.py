"""
Gitrama Git Passthrough — Shared Module

Used by BOTH:
  - CLI:  gtr git "shortlog -sn --all"
  - MCP:  gtr_git tool in server.py

Whitelists read-only git commands. Blocks anything that
could mutate the repo or execute arbitrary code.

Location: gitrama/git_passthrough.py (alongside cli.py, config.py, etc.)
"""

from __future__ import annotations

import os
import shlex
import subprocess
from typing import Optional


# ── Whitelisted subcommands (read-only, no mutations) ──
ALLOWED_SUBCOMMANDS = {
    "shortlog",    # contributor stats
    "log",         # commit history
    "blame",       # line-level ownership
    "show",        # commit/object details
    "diff",        # change comparison
    "ls-files",    # tracked file listing
    "branch",      # branch listing
    "status",      # working tree status
    "rev-parse",   # ref resolution
    "rev-list",    # commit enumeration
    "tag",         # tag listing
    "stash",       # stash listing (read only: "list")
    "remote",      # remote listing
    "config",      # config reading (--get only)
    "name-rev",    # name resolution
    "describe",    # tag description
    "whatchanged",  # file-level change log
}

# ── Blocked flags (even on allowed subcommands) ──
BLOCKED_FLAGS = {
    "--exec", "-c", "--upload-pack", "--receive-pack",
}

# ── Max output to prevent memory issues ──
MAX_OUTPUT_CHARS = 50_000


def validate_git_command(command: str) -> tuple[bool, str, list[str]]:
    """
    Validate and parse a git command string.

    Args:
        command: Git command string, with or without "git" prefix.
                 e.g. "shortlog -sn --all" or "git shortlog -sn --all"

    Returns:
        (is_valid, error_message, parsed_args)
        parsed_args does NOT include "git" — just subcommand + flags.
    """
    try:
        parts = shlex.split(command)
    except ValueError as e:
        return False, f"Invalid command syntax: {e}", []

    if not parts:
        return False, "Empty command", []

    # Strip leading "git" if provided
    if parts[0] == "git":
        parts = parts[1:]

    if not parts:
        return False, "No git subcommand provided", []

    subcommand = parts[0]

    if subcommand not in ALLOWED_SUBCOMMANDS:
        return (
            False,
            f"'{subcommand}' is not allowed. "
            f"Allowed: {', '.join(sorted(ALLOWED_SUBCOMMANDS))}",
            [],
        )

    # Check for blocked flags
    for flag in parts[1:]:
        for blocked in BLOCKED_FLAGS:
            if flag.startswith(blocked):
                return False, f"Flag '{flag}' is not allowed for security reasons", []

    # Special case: config only allows --get and --list
    if subcommand == "config":
        safe_config = any(f in parts for f in ["--get", "--list", "--get-all", "-l"])
        if not safe_config:
            return False, "git config only allowed with --get, --get-all, or --list", []

    # Special case: stash only allows "list"
    if subcommand == "stash":
        if len(parts) < 2 or parts[1] != "list":
            return False, "git stash only allowed with 'list' subcommand", []

    return True, "", parts


def run_git_passthrough(
    command: str,
    cwd: Optional[str] = None,
    timeout: int = 30,
) -> dict[str, any]:
    """
    Validate and run a git command synchronously.

    Used by the CLI (gtr git).

    Args:
        command: Git command string (e.g. "shortlog -sn --all")
        cwd: Working directory (defaults to os.getcwd())
        timeout: Max seconds to wait

    Returns:
        dict with keys: success, stdout, stderr, returncode
    """
    is_valid, error, args = validate_git_command(command)
    if not is_valid:
        return {
            "success": False,
            "stdout": "",
            "stderr": error,
            "returncode": -1,
        }

    work_dir = cwd or os.getcwd()
    cmd = ["git"] + args

    try:
        result = subprocess.run(
            cmd, cwd=work_dir,
            capture_output=True, text=True, timeout=timeout,
        )
        stdout = result.stdout.strip()
        stderr = result.stderr.strip()

        if len(stdout) > MAX_OUTPUT_CHARS:
            stdout = stdout[:MAX_OUTPUT_CHARS] + f"\n\n... (truncated, {len(stdout)} total chars)"

        return {
            "success": result.returncode == 0,
            "stdout": stdout,
            "stderr": stderr,
            "returncode": result.returncode,
        }
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "stdout": "",
            "stderr": f"Command timed out after {timeout}s",
            "returncode": -1,
        }
    except FileNotFoundError:
        return {
            "success": False,
            "stdout": "",
            "stderr": "git not found in PATH",
            "returncode": -1,
        }


async def run_git_passthrough_async(
    command: str,
    cwd: Optional[str] = None,
    timeout: int = 30,
) -> dict[str, any]:
    """
    Validate and run a git command asynchronously.

    Used by the MCP server (gtr_git tool).

    Args:
        command: Git command string (e.g. "shortlog -sn --all")
        cwd: Working directory
        timeout: Max seconds to wait

    Returns:
        dict with keys: success, stdout, stderr, returncode
    """
    import asyncio

    is_valid, error, args = validate_git_command(command)
    if not is_valid:
        return {
            "success": False,
            "stdout": "",
            "stderr": error,
            "returncode": -1,
        }

    work_dir = cwd or os.environ.get("GTR_CWD", os.getcwd())
    cmd = ["git"] + args

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=work_dir,
        )
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            proc.communicate(), timeout=timeout
        )
        stdout = stdout_bytes.decode("utf-8", errors="replace").strip()
        stderr = stderr_bytes.decode("utf-8", errors="replace").strip()

        if len(stdout) > MAX_OUTPUT_CHARS:
            stdout = stdout[:MAX_OUTPUT_CHARS] + f"\n\n... (truncated, {len(stdout)} total chars)"

        return {
            "success": proc.returncode == 0,
            "stdout": stdout,
            "stderr": stderr,
            "returncode": proc.returncode,
        }
    except asyncio.TimeoutError:
        return {
            "success": False,
            "stdout": "",
            "stderr": f"Command timed out after {timeout}s",
            "returncode": -1,
        }
    except FileNotFoundError:
        return {
            "success": False,
            "stdout": "",
            "stderr": "git not found in PATH",
            "returncode": -1,
        }
