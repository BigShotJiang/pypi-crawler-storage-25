"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

Gitrama LLC
South Carolina Limited Liability Company
"""
"""
gtr setup — Interactive provider configuration wizard.
"""
import httpx
import typer
import requests
from rich.console import Console
from rich.panel   import Panel
from rich.prompt  import Prompt, Confirm
from rich.table   import Table

from .config     import set_value, set_provider, get_value, CONFIG_PATH, PROVISIONING_URL, PROVIDER_URLS
from .ai_client  import (
    AIClient,
    PROVIDER_GITRAMA, PROVIDER_OPENAI,
    PROVIDER_ANTHROPIC, PROVIDER_OLLAMA,
    PROVIDER_GROK,
    DEFAULT_MODELS, GITRAMA_DEFAULT_URL,
)

console = Console()

# ── Minimum supported CLI version ─────────────────────────────────────────────
MIN_VERSION     = "1.4.0"
CURRENT_VERSION = "1.4.0"


def check_version():
    """
    Check if this CLI version is still supported.
    Hits /version on provisioning server — if server returns a min_version
    higher than CURRENT_VERSION, block and prompt user to upgrade.
    Returns True if OK to proceed, False if blocked.
    """
    try:
        with httpx.Client(timeout=5.0) as client:
            resp = client.get(f"{PROVISIONING_URL}/version")
            if resp.status_code == 200:
                data = resp.json()
                server_min = data.get("min_version", MIN_VERSION)
                if _version_lt(CURRENT_VERSION, server_min):
                    console.print()
                    console.print(Panel(
                        f"[bold red]Gitrama CLI v{CURRENT_VERSION} is no longer supported.[/bold red]\n\n"
                        f"Minimum required version: [bold yellow]{server_min}[/bold yellow]\n\n"
                        f"Upgrade now:\n"
                        f"  [bold cyan]pip install --upgrade gitrama[/bold cyan]\n\n"
                        f"  [dim]https://gitrama.ai[/dim]",
                        border_style="red",
                        title="⚠  Update Required",
                    ))
                    console.print()
                    return False
    except Exception:
        pass  # network down or endpoint doesn't exist yet — allow through
    return True


def _version_lt(v1: str, v2: str) -> bool:
    """Return True if v1 < v2 (simple semver comparison)."""
    try:
        return tuple(int(x) for x in v1.split(".")) < tuple(int(x) for x in v2.split("."))
    except Exception:
        return False


def setup():
    """
    ⚙️  Interactive setup wizard — configure your AI provider and Gitrama token.
    """
    # ── Version check first ───────────────────────────────────────────────────
    if not check_version():
        raise typer.Exit(1)

    console.print()
    console.print(Panel.fit(
        "[bold cyan]Gitrama Setup Wizard[/bold cyan]\n"
        "[dim]Configure your Gitrama token and AI provider.[/dim]",
        border_style="cyan"
    ))
    console.print()

    # ── Step 1: Gitrama token ─────────────────────────────────────────────────
    console.print("[bold]Step 1 of 5 — Gitrama License Token[/bold]\n")

    existing_token = get_value("gitrama_token")
    if existing_token:
        masked = existing_token[:8] + "••••••••" + existing_token[-4:]
        console.print(f"[dim]Current token:[/dim] [cyan]{masked}[/cyan]")
        if not Confirm.ask("Enter a new token?", default=False):
            console.print("[green]✓[/green] Keeping existing token.\n")
        else:
            existing_token = None

    if not existing_token:
        console.print("A free Gitrama token gives you 50 AI requests/day.")
        console.print(
            "Don't have one? Get yours free at: "
            "[bold cyan]https://gitrama.ai/free[/bold cyan]\n"
        )

        while True:
            token = Prompt.ask(
                "[bold yellow]Paste your Gitrama token[/bold yellow] [dim](starts with gtr_)[/dim]"
            ).strip()

            if not token.startswith("gtr_"):
                console.print("[yellow]⚠  That doesn't look like a Gitrama token (should start with gtr_)[/yellow]")
                if not Confirm.ask("Try again?", default=True):
                    console.print("[dim]You can re-run 'gtr setup' at any time.[/dim]")
                    raise typer.Exit(0)
                continue

            # Validate token against provisioning server
            console.print("[dim]Validating token...[/dim]")
            try:
                with httpx.Client(timeout=8.0) as client:
                    resp = client.post(
                        f"{PROVISIONING_URL}/auth/validate",
                        json={"token": token},
                    )
                    data = resp.json()

                if data.get("valid"):
                    first_name  = data.get("first_name", "")
                    tier        = data.get("tier", "free")
                    daily_limit = data.get("daily_limit", 50)
                    daily_used  = data.get("daily_used", 0)

                    set_value("gitrama_token", token)
                    _save_auth_cache(token, data)

                    greeting = f"Welcome{', ' + first_name if first_name else ''}!"
                    console.print(
                        f"[bold green]✓ Token valid![/bold green] {greeting}\n"
                        f"  Tier:  [cyan]{tier.title()}[/cyan]\n"
                        f"  Usage: [cyan]{daily_used}/{daily_limit}[/cyan] requests today\n"
                    )
                    break
                else:
                    msg = data.get("message", "Invalid token.")
                    console.print(f"[bold red]✗ {msg}[/bold red]")
                    if not Confirm.ask("Try a different token?", default=True):
                        console.print("[dim]You can re-run 'gtr setup' at any time.[/dim]")
                        raise typer.Exit(0)

            except httpx.RequestError:
                console.print("[yellow]⚠  Could not reach Gitrama servers. Token saved locally.[/yellow]")
                console.print("[dim]Run 'gtr health' when connected to verify.[/dim]")
                set_value("gitrama_token", token)
                break

    # ── Step 2: Choose AI provider ────────────────────────────────────────────
    console.print("[bold]Step 2 of 5 — Choose your AI provider[/bold]\n")

    table = Table(show_header=True, header_style="bold cyan", box=None, padding=(0, 2))
    table.add_column("#",        style="bold yellow", width=4)
    table.add_column("Provider", style="bold white",  width=18)
    table.add_column("Cost",     style="green",       width=14)
    table.add_column("Details")

    table.add_row("1", "Gitrama Hosted", "Free",         "Default. Uses Gitrama's AI server. No key needed.")
    table.add_row("2", "OpenAI",         "Your API key", "GPT-4o, GPT-4o-mini. Fast and reliable.")
    table.add_row("3", "Anthropic",      "Your API key", "Claude Haiku or Sonnet. Excellent at code.")
    table.add_row("4", "xAI Grok",       "Your API key", "Grok-3-fast. Fast, capable, competitive pricing.")
    table.add_row("5", "Ollama (local)", "Free",         "Run models locally. 100% private, no internet.")

    console.print(table)
    console.print()

    choice = Prompt.ask(
        "[bold yellow]Enter number[/bold yellow]",
        choices=["1", "2", "3", "4", "5"],
        default="1"
    )

    provider_map = {
        "1": PROVIDER_GITRAMA,
        "2": PROVIDER_OPENAI,
        "3": PROVIDER_ANTHROPIC,
        "4": PROVIDER_GROK,
        "5": PROVIDER_OLLAMA,
    }
    provider = provider_map[choice]
    set_provider(provider)
    console.print(f"\n[green]✓[/green] Provider set to [bold]{provider}[/bold]\n")

    # ── Step 3: Provider-specific config ──────────────────────────────────────
    console.print("[bold]Step 3 of 5 — Provider configuration[/bold]\n")

    if provider == PROVIDER_GITRAMA:
        _setup_gitrama()
    elif provider == PROVIDER_OPENAI:
        _setup_openai()
    elif provider == PROVIDER_ANTHROPIC:
        _setup_anthropic()
    elif provider == PROVIDER_GROK:
        _setup_grok()
    elif provider == PROVIDER_OLLAMA:
        _setup_ollama()

    # ── Step 4: Test connection ───────────────────────────────────────────────
    console.print("\n[bold]Step 4 of 5 — Testing connection[/bold]\n")
    console.print("[dim]Connecting to your AI provider...[/dim]")

    try:
        api_key = get_value("api_key")
        model   = get_value("model")
        _test_provider_connection(provider, api_key, model)
    except Exception as e:
        console.print(f"[bold red]✗ Connection failed:[/bold red] {e}")
        console.print()
        if Confirm.ask("[yellow]Would you like to try a different provider?[/yellow]"):
            setup()
            return
        else:
            console.print("[dim]You can re-run 'gtr setup' at any time.[/dim]")
            return

    # ── Step 5: Telemetry opt-in ──────────────────────────────────────────────
    console.print("\n[bold]Step 5 of 5 — Help train AskG.I.T.[/bold]\n")
    console.print(
        "  Gitrama is building a purpose-built AI model trained on real developer\n"
        "  sessions. With your permission, anonymised [bold]gtr ask[/bold] and [bold]gtr scan[/bold]\n"
        "  sessions from your machine will be used as training data.\n"
    )
    console.print("  [dim]What is collected:[/dim]")
    console.print("  [green]✓[/green] Your questions and AskG.I.T.'s responses")
    console.print("  [green]✓[/green] Repo structure signals (commit count, module names, signal scores)")
    console.print("  [green]✓[/green] Command outcomes — what worked, what failed, how it recovered")
    console.print()
    console.print("  [dim]What is never collected:[/dim]")
    console.print("  [red]✗[/red] Source code or file contents")
    console.print("  [red]✗[/red] Commit messages or diffs")
    console.print("  [red]✗[/red] Author names, emails, or any PII")
    console.print("  [red]✗[/red] API keys or tokens")
    console.print()
    console.print("  [dim]You can change this at any time with: gtr setup --telemetry[/dim]\n")

    telemetry = Confirm.ask(
        "  [bold]Allow anonymised session data to help train AskG.I.T.?[/bold]",
        default=True
    )
    set_value("telemetry", telemetry)

    if telemetry:
        console.print("\n  [green]✓[/green] Telemetry enabled. Thank you — you're helping build something great. 🌿")
    else:
        console.print("\n  [dim]✓ Telemetry off. You can enable it later with: gtr setup --telemetry[/dim]")

    # ── Done ──────────────────────────────────────────────────────────────────
    console.print()
    console.print(Panel.fit(
        f"[bold green]Gitrama is ready! 🌿[/bold green]\n\n"
        f"Provider: [cyan]{provider}[/cyan]\n\n"
        f"Run [bold]gtr commit[/bold] to generate your first AI commit message.\n"
        f"Run [bold]gtr scan[/bold]   to analyze your repo's structural health.\n"
        f"Run [bold]gtr health[/bold] to verify your connection anytime.",
        border_style="green"
    ))
    console.print()


# ── Auth cache helper ─────────────────────────────────────────────────────────

def _save_auth_cache(token: str, data: dict):
    """Populate auth cache after successful setup validation."""
    import hashlib, json, time
    from datetime import datetime, timezone

    try:
        config_path = CONFIG_PATH
        config_path.parent.mkdir(parents=True, exist_ok=True)

        config = {}
        if config_path.exists():
            with open(config_path) as f:
                config = json.load(f)

        token_hash = hashlib.sha256(token.encode()).hexdigest()

        config["auth_cache"] = {
            "token_hash":  token_hash[:16],
            "valid":       True,
            "tier":        data.get("tier", "free"),
            "user_id":     data.get("user_id", ""),
            "email":       data.get("email", ""),
            "first_name":  data.get("first_name", ""),
            "daily_limit": data.get("daily_limit", 50),
            "daily_used":  data.get("daily_used", 0),
            "cached_at":   int(time.time()),
            "usage_date":  datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        }

        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)

    except Exception:
        pass  # cache failure is non-fatal


# ── Provider setup helpers ────────────────────────────────────────────────────

def _test_provider_connection(provider, api_key, model):
    """
    Provider-aware health check for Step 4 of the setup wizard.
    Calls each provider's own endpoint directly — never routes through
    the Gitrama tunnel when BYOK is configured.
    """
    import requests as _req

    if provider == PROVIDER_GITRAMA:
        url  = get_value("api_url") or GITRAMA_DEFAULT_URL
        resp = _req.get(f"{url.rstrip('/')}/health", timeout=8)
        resp.raise_for_status()
        console.print("[bold green]✓ Connection successful![/bold green]")
        data = resp.json() if resp.content else {}
        if data.get("model"):
            console.print(f"  Model:    [cyan]{data['model']}[/cyan]")
        console.print(f"  Provider: [cyan]gitrama[/cyan]")

    elif provider == PROVIDER_OPENAI:
        resp = _req.get(
            "https://api.openai.com/v1/models",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10
        )
        if resp.status_code == 401:
            raise Exception("Invalid OpenAI API key — check your key at platform.openai.com/api-keys")
        if resp.status_code == 429:
            raise Exception("OpenAI quota exceeded — check your billing at platform.openai.com/usage")
        resp.raise_for_status()
        console.print("[bold green]✓ Connection successful![/bold green]")
        console.print(f"  Provider: [cyan]openai[/cyan]")
        console.print(f"  Model:    [cyan]{model}[/cyan]")

    elif provider == PROVIDER_ANTHROPIC:
        resp = _req.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key":         api_key,
                "anthropic-version": "2023-06-01",
                "content-type":      "application/json",
            },
            json={
                "model":      model or "claude-haiku-4-5-20251001",
                "max_tokens": 8,
                "messages":   [{"role": "user", "content": "ping"}],
            },
            timeout=15
        )
        if resp.status_code == 401:
            raise Exception("Invalid Anthropic API key — check your key at console.anthropic.com")
        resp.raise_for_status()
        console.print("[bold green]✓ Connection successful![/bold green]")
        console.print(f"  Provider: [cyan]anthropic[/cyan]")
        console.print(f"  Model:    [cyan]{model}[/cyan]")

    elif provider == PROVIDER_GROK:
        # xAI Grok — OpenAI-compatible endpoint
        resp = _req.get(
            "https://api.x.ai/v1/models",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10
        )
        if resp.status_code == 401:
            raise Exception("Invalid xAI API key — check your key at console.x.ai")
        if resp.status_code == 429:
            raise Exception("xAI quota exceeded — check your billing at console.x.ai")
        resp.raise_for_status()
        console.print("[bold green]✓ Connection successful![/bold green]")
        console.print(f"  Provider: [cyan]grok[/cyan]")
        console.print(f"  Model:    [cyan]{model}[/cyan]")

    elif provider == PROVIDER_OLLAMA:
        ollama_url = get_value("ollama_url") or "http://localhost:11434"
        resp       = _req.get(f"{ollama_url.rstrip('/')}/api/tags", timeout=5)
        resp.raise_for_status()
        console.print("[bold green]✓ Connection successful![/bold green]")
        console.print(f"  Provider: [cyan]ollama[/cyan]")
        console.print(f"  Model:    [cyan]{model}[/cyan]")

    else:
        raise Exception(f"Unknown provider '{provider}'")


def _setup_gitrama():
    """Configure Gitrama hosted server."""
    current_url = get_value("api_url") or GITRAMA_DEFAULT_URL
    console.print(f"Using Gitrama hosted server: [cyan]{current_url}[/cyan]")
    console.print("[dim]No additional API key required.[/dim]")

    if Confirm.ask("\nUse a custom server URL instead?", default=False):
        url = Prompt.ask("Enter your server URL", default=current_url)
        set_value("api_url", url.rstrip("/"))
        console.print("[green]✓[/green] Server URL updated.")


def _setup_openai():
    """Configure OpenAI BYOK."""
    console.print("You'll need an OpenAI API key.")
    console.print("[dim]Get one at: https://platform.openai.com/api-keys[/dim]\n")

    api_key = Prompt.ask("Enter your OpenAI API key [dim](sk-••••••••)[/dim]")
    if not api_key.startswith("sk-"):
        console.print("[yellow]⚠ That doesn't look like an OpenAI key (should start with sk-)[/yellow]")
        if not Confirm.ask("Continue anyway?", default=False):
            return

    set_value("api_key", api_key)

    console.print()
    model_table = Table(show_header=False, box=None, padding=(0, 2))
    model_table.add_column("#",     style="bold yellow", width=4)
    model_table.add_column("Model", style="white",       width=20)
    model_table.add_column("Notes", style="dim")
    model_table.add_row("1", "gpt-4o-mini", "Recommended. Fast, cheap, great for Git tasks.")
    model_table.add_row("2", "gpt-4o",      "More powerful. Higher cost.")
    model_table.add_row("3", "gpt-4-turbo", "Strong reasoning. Moderate cost.")
    model_table.add_row("4", "Custom",      "Enter your own model name.")
    console.print(model_table)
    console.print()

    model_choice = Prompt.ask("Choose model", choices=["1", "2", "3", "4"], default="1")
    model_map    = {"1": "gpt-4o-mini", "2": "gpt-4o", "3": "gpt-4-turbo"}
    model        = Prompt.ask("Enter model name") if model_choice == "4" else model_map[model_choice]

    set_value("model", model)
    console.print(f"[green]✓[/green] OpenAI configured with model [cyan]{model}[/cyan]")


def _setup_anthropic():
    """Configure Anthropic BYOK."""
    console.print("You'll need an Anthropic API key.")
    console.print("[dim]Get one at: https://console.anthropic.com/[/dim]\n")

    api_key = Prompt.ask("Enter your Anthropic API key [dim](sk-ant-••••••••)[/dim]")
    if not api_key.startswith("sk-ant-"):
        console.print("[yellow]⚠ That doesn't look like an Anthropic key (should start with sk-ant-)[/yellow]")
        if not Confirm.ask("Continue anyway?", default=False):
            return

    set_value("api_key", api_key)

    console.print()
    model_table = Table(show_header=False, box=None, padding=(0, 2))
    model_table.add_column("#",     style="bold yellow", width=4)
    model_table.add_column("Model", style="white",       width=34)
    model_table.add_column("Notes", style="dim")
    model_table.add_row("1", "claude-haiku-4-5-20251001", "Recommended. Fastest and most affordable.")
    model_table.add_row("2", "claude-sonnet-4-6",         "More capable. Moderate cost.")
    model_table.add_row("3", "Custom",                    "Enter your own model name.")
    console.print(model_table)
    console.print()

    model_choice = Prompt.ask("Choose model", choices=["1", "2", "3"], default="1")
    model_map    = {"1": "claude-haiku-4-5-20251001", "2": "claude-sonnet-4-6"}
    model        = Prompt.ask("Enter model name") if model_choice == "3" else model_map[model_choice]

    set_value("model", model)
    console.print(f"[green]✓[/green] Anthropic configured with model [cyan]{model}[/cyan]")


def _setup_grok():
    """Configure xAI Grok BYOK."""
    console.print("You'll need an xAI API key.")
    console.print("[dim]Get one at: https://console.x.ai[/dim]\n")

    api_key = Prompt.ask("Enter your xAI API key [dim](xai-••••••••)[/dim]")
    if not api_key.startswith("xai-"):
        console.print("[yellow]⚠ That doesn't look like an xAI key (should start with xai-)[/yellow]")
        if not Confirm.ask("Continue anyway?", default=False):
            return

    set_value("api_key", api_key)

    console.print()
    model_table = Table(show_header=False, box=None, padding=(0, 2))
    model_table.add_column("#",     style="bold yellow", width=4)
    model_table.add_column("Model", style="white",       width=22)
    model_table.add_column("Notes", style="dim")
    model_table.add_row("1", "grok-4.20-reasoning", "Recommended. Best balance of speed and quality.")
    model_table.add_row("2", "grok-4",              "More capable. Best for complex reasoning tasks.")
    model_table.add_row("3", "grok-3-fast",         "Faster, lower cost option.")
    model_table.add_row("4", "Custom",              "Enter your own model name.")
    console.print(model_table)
    console.print()

    model_choice = Prompt.ask("Choose model", choices=["1", "2", "3", "4"], default="1")
    model_map = {
        "1": "grok-4.20-reasoning",
        "2": "grok-4",
        "3": "grok-3-fast",
    }
    model = Prompt.ask("Enter model name") if model_choice == "4" else model_map[model_choice]

    set_value("model", model)
    console.print(f"[green]✓[/green] xAI Grok configured with model [cyan]{model}[/cyan]")


def _setup_ollama():
    """Configure local Ollama instance."""
    console.print("Ollama runs AI models locally on your machine.")
    console.print("[dim]Install Ollama at: https://ollama.ai — then run: ollama pull mistral[/dim]\n")

    current_url = get_value("ollama_url") or "http://localhost:11434"
    console.print(f"Default server URL: [cyan]{current_url}[/cyan]")
    console.print("[dim]Press Enter to keep the default, or type a custom URL.[/dim]\n")

    ollama_url = Prompt.ask(
        "Ollama server URL",
        default=current_url
    )
    set_value("ollama_url", ollama_url.rstrip("/"))

    try:
        resp   = requests.get(f"{ollama_url.rstrip('/')}/api/tags", timeout=3)
        resp.raise_for_status()
        models = [m["name"] for m in resp.json().get("models", [])]
        if models:
            console.print(f"\n[green]✓ Ollama is running.[/green] Found {len(models)} model(s):\n")
            for i, m in enumerate(models[:8], 1):
                console.print(f"  {i}. {m}")
            console.print()
            model_input = Prompt.ask("Enter model name to use", default=models[0])
        else:
            console.print("[yellow]⚠ Ollama is running but no models found.[/yellow]")
            console.print("[dim]Pull a model first: ollama pull mistral[/dim]")
            model_input = Prompt.ask("Enter model name", default="mistral")
    except Exception:
        console.print("[yellow]⚠ Could not reach Ollama at that URL.[/yellow]")
        console.print("[dim]Make sure Ollama is running: ollama serve[/dim]")
        model_input = Prompt.ask("Enter model name anyway", default="mistral")

    set_value("model", model_input)
    console.print(f"[green]✓[/green] Ollama configured with model [cyan]{model_input}[/cyan]")