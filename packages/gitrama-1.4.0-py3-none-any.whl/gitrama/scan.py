"""
gtr scan — CLI-side Git metadata collector
==========================================
Collects raw Git history from the local repo and ships it
to the Gitrama Intelligence Engine on the provisioning server.

Author: Alfonso Harding Jr
Company: Gitrama LLC
"""

import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import httpx
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich import box

from .config import (
    PROVISIONING_URL,
    CONFIG_PATH,
    MAX_COMMITS,
    SCAN_COST,
    TIMEOUT_SCAN,
)

console = Console()


# ═══════════════════════════════════════════════════════════
# CONFIG
# ═══════════════════════════════════════════════════════════

def load_token() -> Optional[str]:
    """Load token from ~/.gitrama/config.json."""
    try:
        if CONFIG_PATH.exists():
            with open(CONFIG_PATH) as f:
                config = json.load(f)
                return (
                    config.get("token") or
                    config.get("gitrama_token") or
                    os.environ.get("GITRAMA_TOKEN")
                )
    except Exception:
        pass
    return os.environ.get("GITRAMA_TOKEN")


def load_config() -> dict:
    """Load full config."""
    try:
        if CONFIG_PATH.exists():
            with open(CONFIG_PATH) as f:
                return json.load(f)
    except Exception:
        pass
    return {}


# ═══════════════════════════════════════════════════════════
# GIT METADATA COLLECTION
# ═══════════════════════════════════════════════════════════

def run_git(args: list[str], cwd: str = ".") -> str:
    """Run a git command and return stdout. Returns '' on error."""
    try:
        result = subprocess.run(
            ["git"] + args,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            cwd=cwd,
        )
        if result.returncode != 0:
            return ""
        return result.stdout.strip()
    except Exception:
        return ""


def is_git_repo(path: str = ".") -> bool:
    """Check if current directory is a git repo."""
    result = run_git(["rev-parse", "--is-inside-work-tree"], cwd=path)
    return result == "true"


def get_repo_name(path: str = ".") -> str:
    """Get repo name from remote or directory name."""
    remote = run_git(["remote", "get-url", "origin"], cwd=path)
    if remote:
        if remote.endswith(".git"):
            remote = remote[:-4]
        remote = remote.rstrip("/")
        parts = remote.replace("git@github.com:", "").replace("https://github.com/", "").split("/")
        if len(parts) >= 2:
            return f"{parts[-2]}/{parts[-1]}"
    return Path(path).resolve().name


def get_current_branch(path: str = ".") -> str:
    return run_git(["branch", "--show-current"], cwd=path) or "main"


def collect_commits(path: str = ".", depth: Optional[int] = None) -> list[dict]:
    """
    Collect commit history. Returns list of commit dicts.
    Each commit: hash, author, email, timestamp, files_changed, insertions, deletions, message
    """
    limit = depth or MAX_COMMITS

    log_output = run_git([
        "log",
        f"--max-count={limit}",
        "--format=%H|%an|%ae|%at|%s",
        "--numstat",
    ], cwd=path)

    if not log_output:
        return []

    commits = []
    current_commit = None
    files_buffer = []

    def _flush():
        if current_commit is not None:
            current_commit["files_changed"] = [f["path"] for f in files_buffer]
            current_commit["insertions"] = sum(f["ins"] for f in files_buffer)
            current_commit["deletions"] = sum(f["del"] for f in files_buffer)
            commits.append(current_commit)

    for line in log_output.splitlines():
        if not line.strip():
            continue

        if "|" in line and len(line.split("|")) == 5:
            _flush()
            current_commit = None
            files_buffer = []
            parts = line.split("|", 4)
            try:
                current_commit = {
                    "hash":          parts[0][:12],
                    "author":        parts[1],
                    "email":         parts[2],
                    "timestamp":     int(parts[3]),
                    "message":       parts[4],
                    "files_changed": [],
                    "insertions":    0,
                    "deletions":     0,
                }
            except (ValueError, IndexError):
                current_commit = None
        elif current_commit and "\t" in line:
            parts = line.split("\t", 2)
            if len(parts) == 3:
                try:
                    ins  = int(parts[0]) if parts[0] != "-" else 0
                    dels = int(parts[1]) if parts[1] != "-" else 0
                    files_buffer.append({"ins": ins, "del": dels, "path": parts[2]})
                except ValueError:
                    pass

    _flush()
    return commits


def collect_contributors(commits: list[dict]) -> list[dict]:
    """Derive contributor stats from commit list."""
    authors: dict[str, dict] = {}

    for c in commits:
        key = c["email"] or c["author"]
        if key not in authors:
            authors[key] = {
                "name":         c["author"],
                "email":        c["email"],
                "commit_count": 0,
                "last_commit":  0,
                "insertions":   0,
                "deletions":    0,
            }
        authors[key]["commit_count"] += 1
        authors[key]["insertions"]   += c["insertions"]
        authors[key]["deletions"]    += c["deletions"]
        if c["timestamp"] > authors[key]["last_commit"]:
            authors[key]["last_commit"] = c["timestamp"]

    return sorted(authors.values(), key=lambda x: x["commit_count"], reverse=True)


def collect_file_tree(path: str = ".") -> list[str]:
    """Get list of tracked files (excluding binary/vendor)."""
    output = run_git(["ls-files"], cwd=path)
    if not output:
        return []

    files = output.splitlines()

    skip_prefixes  = ("node_modules/", "vendor/", ".git/", "dist/", "build/", "__pycache__/")
    skip_extensions = (".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".woff", ".woff2",
                       ".ttf", ".eot", ".pdf", ".zip", ".tar", ".gz", ".lock")

    filtered = [
        f for f in files
        if not any(f.startswith(p) for p in skip_prefixes)
        and not any(f.endswith(e) for e in skip_extensions)
    ]

    return filtered[:5000]


def collect_metadata(path: str = ".", depth: Optional[int] = None) -> dict:
    """Collect all Git metadata for a local repo."""
    commits      = collect_commits(path, depth)
    contributors = collect_contributors(commits)
    file_tree    = collect_file_tree(path)

    repo_age_days = 0
    if commits:
        oldest_ts     = min(c["timestamp"] for c in commits)
        newest_ts     = max(c["timestamp"] for c in commits)
        repo_age_days = max(1, (newest_ts - oldest_ts) // 86400)

    return {
        "commits":       commits,
        "contributors":  contributors,
        "file_tree":     file_tree,
        "branch":        get_current_branch(path),
        "total_commits": len(commits),
        "repo_age_days": repo_age_days,
        "collected_at":  int(time.time()),
    }


# ═══════════════════════════════════════════════════════════
# SERVER COMMUNICATION
# ═══════════════════════════════════════════════════════════

def send_scan_request(token: str, repo_name: str, metadata: dict,
                      repo_type: str = "local", repo_url: Optional[str] = None) -> dict:
    """POST /scan to the provisioning server."""
    payload = {
        "token":     token,
        "repo_name": repo_name,
        "repo_type": repo_type,
        "metadata":  metadata,
    }
    if repo_url:
        payload["repo_url"] = repo_url

    try:
        with httpx.Client(timeout=TIMEOUT_SCAN) as client:
            resp = client.post(f"{PROVISIONING_URL}/scan", json=payload)

        if resp.status_code == 200:
            return resp.json()

        try:
            err    = resp.json()
            detail = err.get("detail", err.get("message", "Unknown error"))
        except Exception:
            detail = resp.text or f"HTTP {resp.status_code}"

        if resp.status_code == 401:
            raise ScanError("invalid_token", "Your Gitrama token is invalid or expired.")
        if resp.status_code == 402:
            raise ScanError("limit_reached", detail)
        if resp.status_code == 403:
            raise ScanError("trial_expired", detail)
        raise ScanError("server_error", detail)

    except httpx.TimeoutException:
        raise ScanError("timeout", "Scan timed out. Large repos can take up to 2 minutes.")
    except httpx.ConnectError:
        raise ScanError("connection_error", "Cannot reach provisioning.gitrama.ai. Check your connection.")
    except ScanError:
        raise
    except Exception as e:
        raise ScanError("unknown", str(e))


class ScanError(Exception):
    def __init__(self, code: str, message: str):
        self.code    = code
        self.message = message
        super().__init__(message)


# ═══════════════════════════════════════════════════════════
# OUTPUT RENDERING
# ═══════════════════════════════════════════════════════════

RISK_COLORS = {
    "CRITICAL": "bold red",
    "HIGH":     "bold yellow",
    "MEDIUM":   "yellow",
    "LOW":      "green",
    "NONE":     "dim green",
}

RISK_ICONS = {
    "CRITICAL": "🔴",
    "HIGH":     "🟠",
    "MEDIUM":   "🟡",
    "LOW":      "🟢",
    "NONE":     "✅",
}


def generate_narrative(result: dict, repo_name: str) -> str:
    """Generate a 2-3 sentence plain-English summary of the scan result."""
    si         = result.get("stability_index", 0)
    signals    = result.get("signals", {})
    delta      = result.get("delta")
    delta_days = result.get("delta_period_days", 90)

    continuity  = signals.get("continuity_risk", {})
    boundary    = signals.get("boundary_entropy", {})
    recurrence  = signals.get("recurrence_risk", {})

    c_score = continuity.get("score", 0)
    b_score = boundary.get("score", 0)
    r_score = recurrence.get("score", 0)
    c_level = continuity.get("level", "NONE")
    b_level = boundary.get("level", "NONE")
    r_level = recurrence.get("level", "NONE")

    parts      = []
    short_name = repo_name.split("/")[-1] if "/" in repo_name else repo_name

    # ── Sentence 1: Overall health ──
    if si >= 90:
        parts.append(f"{short_name} is in excellent structural health with no significant risk signals.")
    elif si >= 75:
        parts.append(f"{short_name} is structurally healthy with minor areas worth monitoring.")
    elif si >= 60:
        parts.append(f"{short_name} shows moderate structural stress in some areas — worth tracking over time.")
    elif si >= 45:
        parts.append(
            f"{short_name} shows moderate architectural pressure across several signals. "
            f"Trend analysis will determine whether these pressures are stabilizing or increasing."
        )
    else:
        parts.append(
            f"{short_name} carries significant structural risk across multiple dimensions — "
            f"immediate attention recommended."
        )

    # ── Sentence 2: Dominant signal ──
    dominant     = max(
        [("continuity", c_score, continuity), ("boundary", b_score, boundary), ("recurrence", r_score, recurrence)],
        key=lambda x: x[1]
    )
    name, score, sig = dominant

    if score >= 10:
        if name == "continuity":
            affected = sig.get("affected_modules", [])
            mod      = affected[0] if affected else "key modules"
            parts.append(
                f"Ownership concentration detected in {mod} — commit history suggests a thin bus factor. "
                f"Note: this is based on Git history and may not reflect actual team ownership or governance structure."
            )
        elif name == "boundary":
            hotspots = sig.get("hotspots", [])
            if hotspots:
                top       = hotspots[0]
                top_lower = top.lower()
                if "test" in top_lower or "spec" in top_lower or "docs" in top_lower:
                    parts.append(
                        f"High co-change detected between {top}. For mature frameworks this is expected — "
                        f"strong test discipline naturally produces code/test coupling. "
                        f"Worth monitoring for non-test modules."
                    )
                else:
                    parts.append(
                        f"Logical coupling detected — {top} are frequently co-changed. "
                        f"This may indicate hidden architectural dependencies or refactor candidates."
                    )
            else:
                parts.append(
                    "Cross-module coupling detected. Review whether co-changing modules share "
                    "hidden dependencies not reflected in the architecture."
                )
        elif name == "recurrence":
            files   = sig.get("recurring_files", [])
            reverts = int(sig.get("details", "0").split(" ")[0]) if sig.get("details") else 0
            if files:
                parts.append(
                    f"Recurrence patterns detected — {files[0]} has been repeatedly patched. "
                    f"This may indicate an unresolved root cause worth investigating."
                )
            elif reverts > 0:
                parts.append(
                    f"{reverts} revert commits detected in recent history — "
                    f"monitor whether this is an isolated spike or an ongoing pattern."
                )

    # ── Sentence 3: Trend or reassurance ──
    if delta is not None and delta != 0:
        direction = "improved" if delta > 0 else "declined"
        magnitude = abs(delta)
        if magnitude >= 10:
            parts.append(
                f"The Stability Index has {direction} by {magnitude} points over the last {delta_days} days — "
                f"{'a positive trajectory worth sustaining.' if delta > 0 else 'worth investigating the cause.'}"
            )
        elif magnitude > 0:
            parts.append(
                f"The index has {direction} slightly ({magnitude}pts) over {delta_days} days — "
                f"scan regularly to confirm the direction."
            )
    else:
        if c_level == "NONE" and b_level == "NONE" and r_level == "NONE":
            parts.append("All structural signals are clean — no action required.")
        else:
            parts.append(
                "These signals are most valuable as trend data. "
                "Scan regularly to track whether coupling is increasing or stability is improving over time."
            )

    return " ".join(parts)


def render_scan_result(result: dict, repo_name: str, verbose: bool = False):
    """Render the scan result to the terminal."""
    si         = result.get("stability_index", 0)
    delta      = result.get("delta")
    delta_days = result.get("delta_period_days", 90)
    signals    = result.get("signals", {})
    fragile    = result.get("fragile_modules", [])

    if si >= 90:
        si_label = "exceptional stability"
        si_color = "green"
    elif si >= 75:
        si_label = "stable"
        si_color = "green"
    elif si >= 60:
        si_label = "complex but stable"
        si_color = "yellow"
    elif si >= 45:
        si_label = "architectural pressure"
        si_color = "yellow"
    else:
        si_label = "high risk"
        si_color = "red"

    delta_str = ""
    if delta is not None and delta != 0:
        sign  = "↑" if delta > 0 else "↓"
        color = "green" if delta > 0 else "red"
        delta_str = f"  [{color}]({sign} {abs(delta)}pts in {delta_days}d)[/{color}]"

    console.print()
    narrative = generate_narrative(result, repo_name)

    console.print(Panel(
        f"[bold]Stability Index:[/bold]  [{si_color}]{si} / 100[/{si_color}]  [dim]({si_label})[/dim]{delta_str}\n"
        f"[dim]Repo: {repo_name}[/dim]\n\n"
        f"[italic]{narrative}[/italic]",
        title="[bold green]🌿 gtr scan[/bold green]",
        border_style="green",
        padding=(1, 2),
    ))

    console.print()
    for signal_key, label in [
        ("continuity_risk",  "Continuity Risk "),
        ("boundary_entropy", "Boundary Entropy"),
        ("recurrence_risk",  "Recurrence Risk "),
    ]:
        sig      = signals.get(signal_key, {})
        level    = sig.get("level", "UNKNOWN")
        details  = sig.get("details", "")
        affected = sig.get("affected_modules", sig.get("hotspots", sig.get("recurring_files", [])))
        score    = sig.get("score", 0)
        color    = RISK_COLORS.get(level, "white")
        icon     = RISK_ICONS.get(level, "⚪")

        console.print(f"  {icon}  [bold]{label}[/bold]   [{color}]{level:8s}[/{color}]  [dim](score: {score})[/dim]")
        if details:
            console.print(f"       [dim]{details}[/dim]")
        if verbose and affected:
            for a in affected[:3]:
                console.print(f"       [dim]→ {a}[/dim]")
        console.print()

    hotspots = signals.get("boundary_entropy", {}).get("hotspots", [])
    if hotspots:
        console.print("  [bold]Highest coupling clusters:[/bold]")
        for i, h in enumerate(hotspots[:5], 1):
            console.print(f"  [dim]{i}.[/dim]  [yellow]{h}[/yellow]")
        console.print()

    if fragile:
        console.print("  [bold]Most fragile modules:[/bold]")
        for i, mod in enumerate(fragile[:5], 1):
            path      = mod.get("path", "")
            score     = mod.get("risk_score", 0)
            bar_color = "red" if score >= 80 else "yellow" if score >= 50 else "green"
            dots      = "." * max(1, 42 - len(path))
            console.print(f"  [dim]{i}.[/dim]  {path}[dim]{dots}[/dim] [{bar_color}]{score:3d}[/{bar_color}]")
        console.print()

    scan_id    = result.get("scan_id", "")
    scanned_at = result.get("scanned_at", "")
    console.print(f"  [dim]Scan ID: {scan_id}   •   {scanned_at}[/dim]")
    console.print()


def render_error(error: ScanError):
    """Render a graceful error message."""
    console.print()

    if error.code == "invalid_token":
        console.print(Panel(
            "[bold yellow]🌿 Token validation failed.[/bold yellow]\n\n"
            "Re-run setup to refresh your token:\n"
            "  [bold]→ gtr setup[/bold]\n\n"
            "Or get a new one at [bold]gitrama.ai[/bold]",
            border_style="yellow",
        ))

    elif error.code == "limit_reached":
        console.print(Panel(
            "[bold yellow]🌿 You've used your 5 free Gitrama scans.[/bold yellow]\n\n"
            "To continue, add your token:\n"
            "  [bold]gtr config set gitrama_token YOUR_TOKEN[/bold]\n\n"
            "Get your token at: [bold]gitrama.ai[/bold]",
            border_style="yellow",
        ))

    elif error.code == "trial_expired":
        console.print(Panel(
            "[bold yellow]🌿 Your 14-day trial has ended.[/bold yellow]\n\n"
            "Continue with Pro for unlimited scans:\n"
            "  [bold]→ gitrama.ai/#pricing[/bold]  [dim]($19/mo)[/dim]",
            border_style="yellow",
        ))

    elif error.code in ("timeout", "connection_error"):
        console.print(Panel(
            f"[bold red]🌿 Connection error.[/bold red]\n\n{error.message}",
            border_style="red",
        ))

    else:
        console.print(Panel(
            f"[bold red]🌿 Scan failed.[/bold red]\n\n{error.message}",
            border_style="red",
        ))

    console.print()


def render_no_token():
    """Render prompt when no token is configured."""
    console.print()
    console.print(Panel(
        "[bold green]🌿 Try Gitrama free — no token needed.[/bold green]\n\n"
        "Run up to 5 scans before signing up.\n"
        "Get your free token at:\n\n"
        "  [bold]→ gitrama.ai[/bold]\n\n"
        "Once you have your token, run:\n"
        "  [bold]→ gtr setup[/bold]",
        border_style="green",
    ))
    console.print()


# ═══════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════

def cmd_scan(
    path: str = ".",
    verbose: bool = False,
    output_format: str = "terminal",
    branch: Optional[str] = None,
    depth: Optional[int] = None,
):
    """
    Main entry point for `gtr scan`.
    Called from the CLI dispatcher.
    """
    # Resolve path to absolute so cwd is always correct
    path  = str(Path(path).resolve())
    token = load_token()

    # ── Auth gate ──────────────────────────────────────────────────────────────
    if token:
        # Has token — provisioning server controls the limit
        from .auth_cache import check_limit, increment_local_usage, flush_cache
        ok, reason = check_limit(cost=SCAN_COST)
        if not ok:
            if reason == "no_token":
                render_no_token()
            elif reason == "invalid_token":
                flush_cache()
                render_error(ScanError("invalid_token", "Your Gitrama token is invalid or expired."))
            elif reason == "limit_reached":
                render_error(ScanError("limit_reached", "Daily scan limit reached. Resets at midnight UTC."))
            elif reason == "trial_expired":
                render_error(ScanError("trial_expired", "Your 14-day trial has ended."))
            sys.exit(1)
    else:
        # No token — local 5-request free tier
        from .usage import check_usage
        allowed, reason = check_usage(token="")
        if not allowed:
            console.print(reason)
            sys.exit(0)

    # ── Git repo check ─────────────────────────────────────────────────────────
    if not is_git_repo(path):
        console.print("\n[red]Not a git repository.[/red] Run [bold]gtr scan[/bold] from inside a git repo.\n")
        sys.exit(1)

    repo_name = get_repo_name(path)

    # ── Collect metadata ───────────────────────────────────────────────────────
    with Progress(
        SpinnerColumn(),
        TextColumn("[dim]{task.description}[/dim]"),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task(f"Reading git history for {repo_name}...", total=None)
        metadata = collect_metadata(path, depth)
        progress.update(task, description=f"Found {metadata['total_commits']} commits, "
                                          f"{len(metadata['contributors'])} contributors, "
                                          f"{len(metadata['file_tree'])} files")
        time.sleep(0.4)

    # ── Send to server ─────────────────────────────────────────────────────────
    # No token — can't scan without one (scan requires server intelligence)
    if not token:
        console.print(Panel(
            "[bold green]🌿 One more step — add your free token to run the scan.[/bold green]\n\n"
            "The scan engine lives on our server and needs your token to connect.\n\n"
            "Get yours free at: [bold]gitrama.ai[/bold]\n\n"
            "Then run: [bold]gtr config set gitrama_token YOUR_TOKEN[/bold]",
            border_style="green",
        ))
        sys.exit(0)

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[dim]{task.description}[/dim]"),
            console=console,
            transient=True,
        ) as progress:
            task   = progress.add_task("Sending to Gitrama Intelligence Engine...", total=None)
            result = send_scan_request(token, repo_name, metadata)

    except ScanError as e:
        if e.code == "invalid_token":
            from .auth_cache import flush_cache
            flush_cache()
        if e.code == "limit_reached":
            from .auth_cache import flush_cache
            flush_cache()
        render_error(e)
        sys.exit(1)

    # ── Update local usage count ───────────────────────────────────────────────
    if token:
        from .auth_cache import increment_local_usage
        increment_local_usage(cost=SCAN_COST)

    # ── Render result ──────────────────────────────────────────────────────────
    if output_format == "json":
        print(json.dumps(result, indent=2))
    else:
        render_scan_result(result, repo_name, verbose=verbose)


# ═══════════════════════════════════════════════════════════
# CLI WIRING (for direct invocation / testing)
# ═══════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="gtr scan — Analyze your repo's structural health")
    parser.add_argument("path",     nargs="?", default=".",        help="Repo path (default: current directory)")
    parser.add_argument("--verbose", "-v", action="store_true",    help="Show affected modules per signal")
    parser.add_argument("--format", dest="output_format",
                        choices=["terminal", "json"], default="terminal")
    parser.add_argument("--depth",  type=int,                      help="Limit commit history depth")

    args = parser.parse_args()
    cmd_scan(
        path          = args.path,
        verbose       = args.verbose,
        output_format = args.output_format,
        depth         = args.depth,
    )