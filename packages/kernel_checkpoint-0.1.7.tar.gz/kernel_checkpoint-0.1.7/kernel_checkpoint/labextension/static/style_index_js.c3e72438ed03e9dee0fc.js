"use strict";
(self["webpackChunkkernel_checkpoint"] = self["webpackChunkkernel_checkpoint"] || []).push([["style_index_js"],{

/***/ "./node_modules/css-loader/dist/runtime/api.js"
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
(module) {



/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
module.exports = function (cssWithMappingToString) {
  var list = [];

  // return the list of modules as css string
  list.toString = function toString() {
    return this.map(function (item) {
      var content = "";
      var needLayer = typeof item[5] !== "undefined";
      if (item[4]) {
        content += "@supports (".concat(item[4], ") {");
      }
      if (item[2]) {
        content += "@media ".concat(item[2], " {");
      }
      if (needLayer) {
        content += "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {");
      }
      content += cssWithMappingToString(item);
      if (needLayer) {
        content += "}";
      }
      if (item[2]) {
        content += "}";
      }
      if (item[4]) {
        content += "}";
      }
      return content;
    }).join("");
  };

  // import a list of modules into the list
  list.i = function i(modules, media, dedupe, supports, layer) {
    if (typeof modules === "string") {
      modules = [[null, modules, undefined]];
    }
    var alreadyImportedModules = {};
    if (dedupe) {
      for (var k = 0; k < this.length; k++) {
        var id = this[k][0];
        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }
    for (var _k = 0; _k < modules.length; _k++) {
      var item = [].concat(modules[_k]);
      if (dedupe && alreadyImportedModules[item[0]]) {
        continue;
      }
      if (typeof layer !== "undefined") {
        if (typeof item[5] === "undefined") {
          item[5] = layer;
        } else {
          item[1] = "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {").concat(item[1], "}");
          item[5] = layer;
        }
      }
      if (media) {
        if (!item[2]) {
          item[2] = media;
        } else {
          item[1] = "@media ".concat(item[2], " {").concat(item[1], "}");
          item[2] = media;
        }
      }
      if (supports) {
        if (!item[4]) {
          item[4] = "".concat(supports);
        } else {
          item[1] = "@supports (".concat(item[4], ") {").concat(item[1], "}");
          item[4] = supports;
        }
      }
      list.push(item);
    }
  };
  return list;
};

/***/ },

/***/ "./node_modules/css-loader/dist/runtime/sourceMaps.js"
/*!************************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/sourceMaps.js ***!
  \************************************************************/
(module) {



module.exports = function (item) {
  var content = item[1];
  var cssMapping = item[3];
  if (!cssMapping) {
    return content;
  }
  if (typeof btoa === "function") {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    var sourceMapping = "/*# ".concat(data, " */");
    return [content].concat([sourceMapping]).join("\n");
  }
  return [content].join("\n");
};

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js"
/*!****************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
  \****************************************************************************/
(module) {



var stylesInDOM = [];
function getIndexByIdentifier(identifier) {
  var result = -1;
  for (var i = 0; i < stylesInDOM.length; i++) {
    if (stylesInDOM[i].identifier === identifier) {
      result = i;
      break;
    }
  }
  return result;
}
function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];
  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var indexByIdentifier = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3],
      supports: item[4],
      layer: item[5]
    };
    if (indexByIdentifier !== -1) {
      stylesInDOM[indexByIdentifier].references++;
      stylesInDOM[indexByIdentifier].updater(obj);
    } else {
      var updater = addElementStyle(obj, options);
      options.byIndex = i;
      stylesInDOM.splice(i, 0, {
        identifier: identifier,
        updater: updater,
        references: 1
      });
    }
    identifiers.push(identifier);
  }
  return identifiers;
}
function addElementStyle(obj, options) {
  var api = options.domAPI(options);
  api.update(obj);
  var updater = function updater(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap && newObj.supports === obj.supports && newObj.layer === obj.layer) {
        return;
      }
      api.update(obj = newObj);
    } else {
      api.remove();
    }
  };
  return updater;
}
module.exports = function (list, options) {
  options = options || {};
  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];
    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDOM[index].references--;
    }
    var newLastIdentifiers = modulesToDom(newList, options);
    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];
      var _index = getIndexByIdentifier(_identifier);
      if (stylesInDOM[_index].references === 0) {
        stylesInDOM[_index].updater();
        stylesInDOM.splice(_index, 1);
      }
    }
    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/insertBySelector.js"
/*!********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertBySelector.js ***!
  \********************************************************************/
(module) {



var memo = {};

/* istanbul ignore next  */
function getTarget(target) {
  if (typeof memo[target] === "undefined") {
    var styleTarget = document.querySelector(target);

    // Special case to return head of iframe instead of iframe itself
    if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
      try {
        // This will throw an exception if access to iframe is blocked
        // due to cross-origin restrictions
        styleTarget = styleTarget.contentDocument.head;
      } catch (e) {
        // istanbul ignore next
        styleTarget = null;
      }
    }
    memo[target] = styleTarget;
  }
  return memo[target];
}

/* istanbul ignore next  */
function insertBySelector(insert, style) {
  var target = getTarget(insert);
  if (!target) {
    throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
  }
  target.appendChild(style);
}
module.exports = insertBySelector;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/insertStyleElement.js"
/*!**********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertStyleElement.js ***!
  \**********************************************************************/
(module) {



/* istanbul ignore next  */
function insertStyleElement(options) {
  var element = document.createElement("style");
  options.setAttributes(element, options.attributes);
  options.insert(element, options.options);
  return element;
}
module.exports = insertStyleElement;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js"
/*!**********************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js ***!
  \**********************************************************************************/
(module, __unused_webpack_exports, __webpack_require__) {



/* istanbul ignore next  */
function setAttributesWithoutAttributes(styleElement) {
  var nonce =  true ? __webpack_require__.nc : 0;
  if (nonce) {
    styleElement.setAttribute("nonce", nonce);
  }
}
module.exports = setAttributesWithoutAttributes;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/styleDomAPI.js"
/*!***************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleDomAPI.js ***!
  \***************************************************************/
(module) {



/* istanbul ignore next  */
function apply(styleElement, options, obj) {
  var css = "";
  if (obj.supports) {
    css += "@supports (".concat(obj.supports, ") {");
  }
  if (obj.media) {
    css += "@media ".concat(obj.media, " {");
  }
  var needLayer = typeof obj.layer !== "undefined";
  if (needLayer) {
    css += "@layer".concat(obj.layer.length > 0 ? " ".concat(obj.layer) : "", " {");
  }
  css += obj.css;
  if (needLayer) {
    css += "}";
  }
  if (obj.media) {
    css += "}";
  }
  if (obj.supports) {
    css += "}";
  }
  var sourceMap = obj.sourceMap;
  if (sourceMap && typeof btoa !== "undefined") {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  }

  // For old IE
  /* istanbul ignore if  */
  options.styleTagTransform(css, styleElement, options.options);
}
function removeStyleElement(styleElement) {
  // istanbul ignore if
  if (styleElement.parentNode === null) {
    return false;
  }
  styleElement.parentNode.removeChild(styleElement);
}

/* istanbul ignore next  */
function domAPI(options) {
  if (typeof document === "undefined") {
    return {
      update: function update() {},
      remove: function remove() {}
    };
  }
  var styleElement = options.insertStyleElement(options);
  return {
    update: function update(obj) {
      apply(styleElement, options, obj);
    },
    remove: function remove() {
      removeStyleElement(styleElement);
    }
  };
}
module.exports = domAPI;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/styleTagTransform.js"
/*!*********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleTagTransform.js ***!
  \*********************************************************************/
(module) {



/* istanbul ignore next  */
function styleTagTransform(css, styleElement) {
  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css;
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild);
    }
    styleElement.appendChild(document.createTextNode(css));
  }
}
module.exports = styleTagTransform;

/***/ },

/***/ "./style/index.js"
/*!************************!*\
  !*** ./style/index.js ***!
  \************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _base_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base.css */ "./style/base.css");



/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./style/base.css"
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \**************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/* Kernel Checkpoint Extension styles */

/* ------------------------------------------------------------------ */
/*  Dialog body                                                        */
/* ------------------------------------------------------------------ */

.kc-dialog-body {
  min-width: 650px;
  max-height: 65vh;
  overflow-y: auto;
  padding: 4px 0;
}

/* ------------------------------------------------------------------ */
/*  Panel                                                              */
/* ------------------------------------------------------------------ */

.kc-panel {
  font-family: var(--jp-ui-font-family);
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-ui-font-color1);
}

/* ------------------------------------------------------------------ */
/*  Flash messages                                                     */
/* ------------------------------------------------------------------ */

.kc-flash {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  border-radius: 4px;
  margin-bottom: 12px;
  font-size: var(--jp-ui-font-size1);
}

.kc-flash-success {
  background: var(--jp-success-color3, #d4edda);
  color: var(--jp-success-color1, #155724);
  border: 1px solid var(--jp-success-color2, #c3e6cb);
}

.kc-flash-error {
  background: var(--jp-error-color3, #f8d7da);
  color: var(--jp-error-color1, #721c24);
  border: 1px solid var(--jp-error-color2, #f5c6cb);
}

.kc-flash-close {
  background: none;
  border: none;
  cursor: pointer;
  font-size: 18px;
  line-height: 1;
  color: inherit;
  padding: 0 4px;
}

/* ------------------------------------------------------------------ */
/*  Create section                                                     */
/* ------------------------------------------------------------------ */

.kc-create-section {
  margin-bottom: 14px;
  padding-bottom: 14px;
  border-bottom: 1px solid var(--jp-border-color1);
}

.kc-create-form {
  display: flex;
  gap: 8px;
  align-items: center;
}

/* ------------------------------------------------------------------ */
/*  Shared button / input                                              */
/* ------------------------------------------------------------------ */

.kc-btn {
  display: inline-flex;
  align-items: center;
  border: 1px solid var(--jp-border-color1);
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  padding: 4px 12px;
  border-radius: 3px;
  cursor: pointer;
  font-size: var(--jp-ui-font-size1);
  white-space: nowrap;
  line-height: 1.5;
}

.kc-btn:hover {
  background: var(--jp-layout-color2);
}

.kc-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.kc-btn-primary {
  background: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1, #fff);
  border-color: var(--jp-brand-color1);
}

.kc-btn-primary:hover {
  background: var(--jp-brand-color2);
}

.kc-btn-danger {
  color: var(--jp-error-color1);
  border-color: var(--jp-error-color1);
}

.kc-btn-danger:hover {
  background: var(--jp-error-color1);
  color: var(--jp-ui-inverse-font-color1, #fff);
}

.kc-btn-restore {
  color: var(--jp-success-color1);
  border-color: var(--jp-success-color1);
}

.kc-btn-restore:hover {
  background: var(--jp-success-color1);
  color: var(--jp-ui-inverse-font-color1, #fff);
}

.kc-btn-xs {
  padding: 2px 8px;
  font-size: var(--jp-ui-font-size0);
}

.kc-input {
  border: 1px solid var(--jp-border-color1);
  background: var(--jp-layout-color0);
  color: var(--jp-ui-font-color1);
  padding: 4px 8px;
  border-radius: 3px;
  font-size: var(--jp-ui-font-size1);
  flex: 1;
  min-width: 0;
}

.kc-input:focus {
  outline: none;
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 1px var(--jp-brand-color1);
}

.kc-input-sm {
  padding: 2px 6px;
  font-size: var(--jp-ui-font-size0);
}

/* ------------------------------------------------------------------ */
/*  Checkpoint list                                                    */
/* ------------------------------------------------------------------ */

.kc-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.kc-placeholder {
  padding: 24px;
  text-align: center;
  color: var(--jp-ui-font-color2);
}

.kc-placeholder-error {
  color: var(--jp-error-color1);
}

/* ------------------------------------------------------------------ */
/*  Single checkpoint item                                             */
/* ------------------------------------------------------------------ */

.kc-item {
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  padding: 10px 12px;
  background: var(--jp-layout-color0);
}

.kc-item-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
}

.kc-item-info {
  flex: 1;
  min-width: 0;
}

.kc-item-name {
  font-weight: 600;
  color: var(--jp-ui-font-color0);
  word-break: break-all;
}

.kc-item-meta {
  display: flex;
  gap: 10px;
  margin-top: 4px;
  align-items: center;
}

.kc-item-date {
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
}

.kc-item-actions {
  display: flex;
  gap: 4px;
  flex-shrink: 0;
  align-items: center;
  flex-wrap: wrap;
  justify-content: flex-end;
}

.kc-confirm-label {
  font-size: var(--jp-ui-font-size0);
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

/* ------------------------------------------------------------------ */
/*  Phase badge                                                        */
/* ------------------------------------------------------------------ */

.kc-phase {
  display: inline-block;
  padding: 1px 8px;
  border-radius: 10px;
  font-size: var(--jp-ui-font-size0);
  font-weight: 500;
}

.kc-phase-completed {
  background: var(--jp-success-color3, #d4edda);
  color: var(--jp-success-color1, #155724);
}

.kc-phase-failed {
  background: var(--jp-error-color3, #f8d7da);
  color: var(--jp-error-color1, #721c24);
}

.kc-phase-in-progress,
.kc-phase-running,
.kc-phase-pending {
  background: var(--jp-warn-color3, #fff3cd);
  color: var(--jp-warn-color1, #856404);
}

/* ------------------------------------------------------------------ */
/*  Rename form                                                        */
/* ------------------------------------------------------------------ */

.kc-rename-form {
  display: flex;
  gap: 4px;
  align-items: center;
}

/* ------------------------------------------------------------------ */
/*  Detail pane                                                        */
/* ------------------------------------------------------------------ */

.kc-detail {
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px solid var(--jp-border-color2);
  font-size: var(--jp-ui-font-size0);
}

.kc-detail-row {
  display: flex;
  gap: 8px;
  margin-bottom: 4px;
}

.kc-detail-label {
  font-weight: 600;
  color: var(--jp-ui-font-color1);
  min-width: 110px;
  flex-shrink: 0;
}

.kc-detail-section {
  margin-top: 8px;
}

.kc-detail-file {
  display: flex;
  justify-content: space-between;
  padding: 3px 0;
  color: var(--jp-ui-font-color2);
  gap: 12px;
}

.kc-detail-image-name {
  word-break: break-all;
}

.kc-detail-time {
  flex-shrink: 0;
  color: var(--jp-ui-font-color2);
}

/* ------------------------------------------------------------------ */
/*  Footer                                                             */
/* ------------------------------------------------------------------ */

.kc-footer {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid var(--jp-border-color1);
  display: flex;
  justify-content: flex-end;
}
`, "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA,uCAAuC;;AAEvC,uEAAuE;AACvE,wEAAwE;AACxE,uEAAuE;;AAEvE;EACE,gBAAgB;EAChB,gBAAgB;EAChB,gBAAgB;EAChB,cAAc;AAChB;;AAEA,uEAAuE;AACvE,wEAAwE;AACxE,uEAAuE;;AAEvE;EACE,qCAAqC;EACrC,kCAAkC;EAClC,+BAA+B;AACjC;;AAEA,uEAAuE;AACvE,wEAAwE;AACxE,uEAAuE;;AAEvE;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,iBAAiB;EACjB,kBAAkB;EAClB,mBAAmB;EACnB,kCAAkC;AACpC;;AAEA;EACE,6CAA6C;EAC7C,wCAAwC;EACxC,mDAAmD;AACrD;;AAEA;EACE,2CAA2C;EAC3C,sCAAsC;EACtC,iDAAiD;AACnD;;AAEA;EACE,gBAAgB;EAChB,YAAY;EACZ,eAAe;EACf,eAAe;EACf,cAAc;EACd,cAAc;EACd,cAAc;AAChB;;AAEA,uEAAuE;AACvE,wEAAwE;AACxE,uEAAuE;;AAEvE;EACE,mBAAmB;EACnB,oBAAoB;EACpB,gDAAgD;AAClD;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,mBAAmB;AACrB;;AAEA,uEAAuE;AACvE,wEAAwE;AACxE,uEAAuE;;AAEvE;EACE,oBAAoB;EACpB,mBAAmB;EACnB,yCAAyC;EACzC,mCAAmC;EACnC,+BAA+B;EAC/B,iBAAiB;EACjB,kBAAkB;EAClB,eAAe;EACf,kCAAkC;EAClC,mBAAmB;EACnB,gBAAgB;AAClB;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,kCAAkC;EAClC,6CAA6C;EAC7C,oCAAoC;AACtC;;AAEA;EACE,kCAAkC;AACpC;;AAEA;EACE,6BAA6B;EAC7B,oCAAoC;AACtC;;AAEA;EACE,kCAAkC;EAClC,6CAA6C;AAC/C;;AAEA;EACE,+BAA+B;EAC/B,sCAAsC;AACxC;;AAEA;EACE,oCAAoC;EACpC,6CAA6C;AAC/C;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;AACpC;;AAEA;EACE,yCAAyC;EACzC,mCAAmC;EACnC,+BAA+B;EAC/B,gBAAgB;EAChB,kBAAkB;EAClB,kCAAkC;EAClC,OAAO;EACP,YAAY;AACd;;AAEA;EACE,aAAa;EACb,oCAAoC;EACpC,4CAA4C;AAC9C;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;AACpC;;AAEA,uEAAuE;AACvE,wEAAwE;AACxE,uEAAuE;;AAEvE;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,kBAAkB;EAClB,+BAA+B;AACjC;;AAEA;EACE,6BAA6B;AAC/B;;AAEA,uEAAuE;AACvE,wEAAwE;AACxE,uEAAuE;;AAEvE;EACE,yCAAyC;EACzC,kBAAkB;EAClB,kBAAkB;EAClB,mCAAmC;AACrC;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,uBAAuB;EACvB,SAAS;AACX;;AAEA;EACE,OAAO;EACP,YAAY;AACd;;AAEA;EACE,gBAAgB;EAChB,+BAA+B;EAC/B,qBAAqB;AACvB;;AAEA;EACE,aAAa;EACb,SAAS;EACT,eAAe;EACf,mBAAmB;AACrB;;AAEA;EACE,+BAA+B;EAC/B,kCAAkC;AACpC;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,cAAc;EACd,mBAAmB;EACnB,eAAe;EACf,yBAAyB;AAC3B;;AAEA;EACE,kCAAkC;EAClC,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA,uEAAuE;AACvE,wEAAwE;AACxE,uEAAuE;;AAEvE;EACE,qBAAqB;EACrB,gBAAgB;EAChB,mBAAmB;EACnB,kCAAkC;EAClC,gBAAgB;AAClB;;AAEA;EACE,6CAA6C;EAC7C,wCAAwC;AAC1C;;AAEA;EACE,2CAA2C;EAC3C,sCAAsC;AACxC;;AAEA;;;EAGE,0CAA0C;EAC1C,qCAAqC;AACvC;;AAEA,uEAAuE;AACvE,wEAAwE;AACxE,uEAAuE;;AAEvE;EACE,aAAa;EACb,QAAQ;EACR,mBAAmB;AACrB;;AAEA,uEAAuE;AACvE,wEAAwE;AACxE,uEAAuE;;AAEvE;EACE,gBAAgB;EAChB,iBAAiB;EACjB,6CAA6C;EAC7C,kCAAkC;AACpC;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,kBAAkB;AACpB;;AAEA;EACE,gBAAgB;EAChB,+BAA+B;EAC/B,gBAAgB;EAChB,cAAc;AAChB;;AAEA;EACE,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,cAAc;EACd,+BAA+B;EAC/B,SAAS;AACX;;AAEA;EACE,qBAAqB;AACvB;;AAEA;EACE,cAAc;EACd,+BAA+B;AACjC;;AAEA,uEAAuE;AACvE,wEAAwE;AACxE,uEAAuE;;AAEvE;EACE,gBAAgB;EAChB,iBAAiB;EACjB,6CAA6C;EAC7C,aAAa;EACb,yBAAyB;AAC3B","sourcesContent":["/* Kernel Checkpoint Extension styles */\n\n/* ------------------------------------------------------------------ */\n/*  Dialog body                                                        */\n/* ------------------------------------------------------------------ */\n\n.kc-dialog-body {\n  min-width: 650px;\n  max-height: 65vh;\n  overflow-y: auto;\n  padding: 4px 0;\n}\n\n/* ------------------------------------------------------------------ */\n/*  Panel                                                              */\n/* ------------------------------------------------------------------ */\n\n.kc-panel {\n  font-family: var(--jp-ui-font-family);\n  font-size: var(--jp-ui-font-size1);\n  color: var(--jp-ui-font-color1);\n}\n\n/* ------------------------------------------------------------------ */\n/*  Flash messages                                                     */\n/* ------------------------------------------------------------------ */\n\n.kc-flash {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 8px 12px;\n  border-radius: 4px;\n  margin-bottom: 12px;\n  font-size: var(--jp-ui-font-size1);\n}\n\n.kc-flash-success {\n  background: var(--jp-success-color3, #d4edda);\n  color: var(--jp-success-color1, #155724);\n  border: 1px solid var(--jp-success-color2, #c3e6cb);\n}\n\n.kc-flash-error {\n  background: var(--jp-error-color3, #f8d7da);\n  color: var(--jp-error-color1, #721c24);\n  border: 1px solid var(--jp-error-color2, #f5c6cb);\n}\n\n.kc-flash-close {\n  background: none;\n  border: none;\n  cursor: pointer;\n  font-size: 18px;\n  line-height: 1;\n  color: inherit;\n  padding: 0 4px;\n}\n\n/* ------------------------------------------------------------------ */\n/*  Create section                                                     */\n/* ------------------------------------------------------------------ */\n\n.kc-create-section {\n  margin-bottom: 14px;\n  padding-bottom: 14px;\n  border-bottom: 1px solid var(--jp-border-color1);\n}\n\n.kc-create-form {\n  display: flex;\n  gap: 8px;\n  align-items: center;\n}\n\n/* ------------------------------------------------------------------ */\n/*  Shared button / input                                              */\n/* ------------------------------------------------------------------ */\n\n.kc-btn {\n  display: inline-flex;\n  align-items: center;\n  border: 1px solid var(--jp-border-color1);\n  background: var(--jp-layout-color1);\n  color: var(--jp-ui-font-color1);\n  padding: 4px 12px;\n  border-radius: 3px;\n  cursor: pointer;\n  font-size: var(--jp-ui-font-size1);\n  white-space: nowrap;\n  line-height: 1.5;\n}\n\n.kc-btn:hover {\n  background: var(--jp-layout-color2);\n}\n\n.kc-btn:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n.kc-btn-primary {\n  background: var(--jp-brand-color1);\n  color: var(--jp-ui-inverse-font-color1, #fff);\n  border-color: var(--jp-brand-color1);\n}\n\n.kc-btn-primary:hover {\n  background: var(--jp-brand-color2);\n}\n\n.kc-btn-danger {\n  color: var(--jp-error-color1);\n  border-color: var(--jp-error-color1);\n}\n\n.kc-btn-danger:hover {\n  background: var(--jp-error-color1);\n  color: var(--jp-ui-inverse-font-color1, #fff);\n}\n\n.kc-btn-restore {\n  color: var(--jp-success-color1);\n  border-color: var(--jp-success-color1);\n}\n\n.kc-btn-restore:hover {\n  background: var(--jp-success-color1);\n  color: var(--jp-ui-inverse-font-color1, #fff);\n}\n\n.kc-btn-xs {\n  padding: 2px 8px;\n  font-size: var(--jp-ui-font-size0);\n}\n\n.kc-input {\n  border: 1px solid var(--jp-border-color1);\n  background: var(--jp-layout-color0);\n  color: var(--jp-ui-font-color1);\n  padding: 4px 8px;\n  border-radius: 3px;\n  font-size: var(--jp-ui-font-size1);\n  flex: 1;\n  min-width: 0;\n}\n\n.kc-input:focus {\n  outline: none;\n  border-color: var(--jp-brand-color1);\n  box-shadow: 0 0 0 1px var(--jp-brand-color1);\n}\n\n.kc-input-sm {\n  padding: 2px 6px;\n  font-size: var(--jp-ui-font-size0);\n}\n\n/* ------------------------------------------------------------------ */\n/*  Checkpoint list                                                    */\n/* ------------------------------------------------------------------ */\n\n.kc-list {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n\n.kc-placeholder {\n  padding: 24px;\n  text-align: center;\n  color: var(--jp-ui-font-color2);\n}\n\n.kc-placeholder-error {\n  color: var(--jp-error-color1);\n}\n\n/* ------------------------------------------------------------------ */\n/*  Single checkpoint item                                             */\n/* ------------------------------------------------------------------ */\n\n.kc-item {\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 4px;\n  padding: 10px 12px;\n  background: var(--jp-layout-color0);\n}\n\n.kc-item-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  gap: 12px;\n}\n\n.kc-item-info {\n  flex: 1;\n  min-width: 0;\n}\n\n.kc-item-name {\n  font-weight: 600;\n  color: var(--jp-ui-font-color0);\n  word-break: break-all;\n}\n\n.kc-item-meta {\n  display: flex;\n  gap: 10px;\n  margin-top: 4px;\n  align-items: center;\n}\n\n.kc-item-date {\n  color: var(--jp-ui-font-color2);\n  font-size: var(--jp-ui-font-size0);\n}\n\n.kc-item-actions {\n  display: flex;\n  gap: 4px;\n  flex-shrink: 0;\n  align-items: center;\n  flex-wrap: wrap;\n  justify-content: flex-end;\n}\n\n.kc-confirm-label {\n  font-size: var(--jp-ui-font-size0);\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n}\n\n/* ------------------------------------------------------------------ */\n/*  Phase badge                                                        */\n/* ------------------------------------------------------------------ */\n\n.kc-phase {\n  display: inline-block;\n  padding: 1px 8px;\n  border-radius: 10px;\n  font-size: var(--jp-ui-font-size0);\n  font-weight: 500;\n}\n\n.kc-phase-completed {\n  background: var(--jp-success-color3, #d4edda);\n  color: var(--jp-success-color1, #155724);\n}\n\n.kc-phase-failed {\n  background: var(--jp-error-color3, #f8d7da);\n  color: var(--jp-error-color1, #721c24);\n}\n\n.kc-phase-in-progress,\n.kc-phase-running,\n.kc-phase-pending {\n  background: var(--jp-warn-color3, #fff3cd);\n  color: var(--jp-warn-color1, #856404);\n}\n\n/* ------------------------------------------------------------------ */\n/*  Rename form                                                        */\n/* ------------------------------------------------------------------ */\n\n.kc-rename-form {\n  display: flex;\n  gap: 4px;\n  align-items: center;\n}\n\n/* ------------------------------------------------------------------ */\n/*  Detail pane                                                        */\n/* ------------------------------------------------------------------ */\n\n.kc-detail {\n  margin-top: 10px;\n  padding-top: 10px;\n  border-top: 1px solid var(--jp-border-color2);\n  font-size: var(--jp-ui-font-size0);\n}\n\n.kc-detail-row {\n  display: flex;\n  gap: 8px;\n  margin-bottom: 4px;\n}\n\n.kc-detail-label {\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n  min-width: 110px;\n  flex-shrink: 0;\n}\n\n.kc-detail-section {\n  margin-top: 8px;\n}\n\n.kc-detail-file {\n  display: flex;\n  justify-content: space-between;\n  padding: 3px 0;\n  color: var(--jp-ui-font-color2);\n  gap: 12px;\n}\n\n.kc-detail-image-name {\n  word-break: break-all;\n}\n\n.kc-detail-time {\n  flex-shrink: 0;\n  color: var(--jp-ui-font-color2);\n}\n\n/* ------------------------------------------------------------------ */\n/*  Footer                                                             */\n/* ------------------------------------------------------------------ */\n\n.kc-footer {\n  margin-top: 12px;\n  padding-top: 12px;\n  border-top: 1px solid var(--jp-border-color1);\n  display: flex;\n  justify-content: flex-end;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./style/base.css"
/*!************************!*\
  !*** ./style/base.css ***!
  \************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./base.css */ "./node_modules/css-loader/dist/cjs.js!./style/base.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }

}]);
//# sourceMappingURL=style_index_js.c3e72438ed03e9dee0fc.js.map