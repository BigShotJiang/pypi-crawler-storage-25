"use strict";
(self["webpackChunkkernel_checkpoint"] = self["webpackChunkkernel_checkpoint"] || []).push([["lib_index_js"],{

/***/ "./lib/api.js"
/*!********************!*\
  !*** ./lib/api.js ***!
  \********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CheckpointAPI: () => (/* binding */ CheckpointAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


const API_NAMESPACE = 'kernel-checkpoint';
function makeRequest(endpoint, init = {}) {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const url = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, API_NAMESPACE, endpoint);
    return _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(url, init, settings);
}
function jsonInit(method, data) {
    return {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    };
}
async function handleResponse(response) {
    if (!response.ok) {
        let detail = response.statusText;
        try {
            const body = await response.json();
            detail = body.message || body.error || JSON.stringify(body);
        }
        catch (_a) {
            // use statusText
        }
        throw new Error(detail);
    }
    return response.json();
}
var CheckpointAPI;
(function (CheckpointAPI) {
    async function getConfig() {
        const resp = await makeRequest('config');
        return handleResponse(resp);
    }
    CheckpointAPI.getConfig = getConfig;
    async function listCheckpoints(namespace) {
        const resp = await makeRequest(`checkpoints?namespace=${encodeURIComponent(namespace)}`);
        return handleResponse(resp);
    }
    CheckpointAPI.listCheckpoints = listCheckpoints;
    async function getCheckpoint(namespace, name) {
        const resp = await makeRequest(`checkpoints/${encodeURIComponent(namespace)}/${encodeURIComponent(name)}`);
        return handleResponse(resp);
    }
    CheckpointAPI.getCheckpoint = getCheckpoint;
    async function createCheckpoint(request) {
        const resp = await makeRequest('checkpoints', jsonInit('POST', request));
        return handleResponse(resp);
    }
    CheckpointAPI.createCheckpoint = createCheckpoint;
    async function deleteCheckpoint(namespace, name) {
        const resp = await makeRequest(`checkpoints/${encodeURIComponent(namespace)}/${encodeURIComponent(name)}`, { method: 'DELETE' });
        if (!resp.ok) {
            let detail = resp.statusText;
            try {
                const body = await resp.json();
                detail = body.message || body.error || JSON.stringify(body);
            }
            catch (_a) {
                // use statusText
            }
            throw new Error(detail);
        }
    }
    CheckpointAPI.deleteCheckpoint = deleteCheckpoint;
    async function updateCheckpoint(namespace, name, data) {
        const resp = await makeRequest(`checkpoints/${encodeURIComponent(namespace)}/${encodeURIComponent(name)}`, jsonInit('PUT', data));
        return handleResponse(resp);
    }
    CheckpointAPI.updateCheckpoint = updateCheckpoint;
})(CheckpointAPI || (CheckpointAPI = {}));


/***/ },

/***/ "./lib/checkpoint-panel.js"
/*!*********************************!*\
  !*** ./lib/checkpoint-panel.js ***!
  \*********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CheckpointPanel: () => (/* binding */ CheckpointPanel)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./api */ "./lib/api.js");


const CHECKPOINT_REFRESH_INTERVAL = 3;
function mapPhaseDisplay(phase) {
    return phase === 'Completed' ? 'Ready' : 'Pending';
}
function PhaseIndicator({ phase }) {
    const display = mapPhaseDisplay(phase);
    const cls = display.toLowerCase().replace(/\s+/g, '-');
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `kc-phase kc-phase-${cls}` }, display);
}
function formatDate(iso) {
    return new Date(iso).toLocaleString();
}
function CheckpointPanel(props) {
    const { namespace, kernelId, kernelSpecName, notebookName, onRestore } = props;
    const [checkpoints, setCheckpoints] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [showCreateForm, setShowCreateForm] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [newName, setNewName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [creating, setCreating] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [restoring, setRestoring] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [expandedDetail, setExpandedDetail] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [detailData, setDetailData] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [renamingName, setRenamingName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [renameValue, setRenameValue] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [flash, setFlash] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [confirmDelete, setConfirmDelete] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [confirmRestore, setConfirmRestore] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    /* ------------------------------------------------------------------ */
    /*  Data fetching                                                      */
    /* ------------------------------------------------------------------ */
    const fetchCheckpoints = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        var _a, _b;
        setLoading(true);
        setError(null);
        try {
            const result = await _api__WEBPACK_IMPORTED_MODULE_1__.CheckpointAPI.listCheckpoints(namespace);
            setCheckpoints((_a = result.items) !== null && _a !== void 0 ? _a : []);
        }
        catch (err) {
            setError((_b = err.message) !== null && _b !== void 0 ? _b : 'Failed to load checkpoints');
        }
        finally {
            setLoading(false);
        }
    }, [namespace]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        fetchCheckpoints();
    }, [fetchCheckpoints]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const id = setInterval(fetchCheckpoints, CHECKPOINT_REFRESH_INTERVAL * 1000);
        return () => clearInterval(id);
    }, [fetchCheckpoints]);
    /* ------------------------------------------------------------------ */
    /*  Actions                                                            */
    /* ------------------------------------------------------------------ */
    const handleCreate = async () => {
        var _a;
        if (!newName.trim()) {
            return;
        }
        setCreating(true);
        setFlash(null);
        try {
            await _api__WEBPACK_IMPORTED_MODULE_1__.CheckpointAPI.createCheckpoint({
                name: newName.trim(),
                namespace,
                kernelId,
                buildImage: false,
                metadata: {
                    kernelId,
                    kernelName: kernelSpecName,
                    notebookName
                }
            });
            setNewName('');
            setShowCreateForm(false);
            setFlash({ type: 'success', text: 'Checkpoint created successfully.' });
            await fetchCheckpoints();
        }
        catch (err) {
            setFlash({
                type: 'error',
                text: (_a = err.message) !== null && _a !== void 0 ? _a : 'Failed to create checkpoint'
            });
        }
        finally {
            setCreating(false);
        }
    };
    const handleDelete = async (name) => {
        var _a;
        setFlash(null);
        setConfirmDelete(null);
        try {
            await _api__WEBPACK_IMPORTED_MODULE_1__.CheckpointAPI.deleteCheckpoint(namespace, name);
            setFlash({ type: 'success', text: `Checkpoint "${name}" deleted.` });
            if (expandedDetail === name) {
                setExpandedDetail(null);
                setDetailData(null);
            }
            await fetchCheckpoints();
        }
        catch (err) {
            setFlash({
                type: 'error',
                text: (_a = err.message) !== null && _a !== void 0 ? _a : 'Failed to delete checkpoint'
            });
        }
    };
    const handleViewStatus = async (name) => {
        var _a;
        if (expandedDetail === name) {
            setExpandedDetail(null);
            setDetailData(null);
            return;
        }
        try {
            const detail = await _api__WEBPACK_IMPORTED_MODULE_1__.CheckpointAPI.getCheckpoint(namespace, name);
            setDetailData(detail);
            setExpandedDetail(name);
        }
        catch (err) {
            setFlash({
                type: 'error',
                text: (_a = err.message) !== null && _a !== void 0 ? _a : 'Failed to get checkpoint details'
            });
        }
    };
    const handleRestore = async (checkpointName) => {
        var _a, _b, _c, _d;
        setConfirmRestore(null);
        setRestoring(checkpointName);
        setFlash(null);
        try {
            const detail = await _api__WEBPACK_IMPORTED_MODULE_1__.CheckpointAPI.getCheckpoint(namespace, checkpointName);
            const checkpointFile = (_a = detail.checkpointFiles) === null || _a === void 0 ? void 0 : _a[0];
            if (!(checkpointFile === null || checkpointFile === void 0 ? void 0 : checkpointFile.storagePath)) {
                throw new Error('No checkpoint file path available for this checkpoint');
            }
            const cpKernelId = (_c = (_b = detail.metadata) === null || _b === void 0 ? void 0 : _b.kernelId) !== null && _c !== void 0 ? _c : '';
            if (!cpKernelId) {
                throw new Error('No kernel ID found in checkpoint metadata');
            }
            await onRestore(checkpointName, checkpointFile.storagePath, checkpointFile.containerName, cpKernelId);
            setFlash({
                type: 'success',
                text: `Kernel restored from "${checkpointName}". The kernel is restarting.`
            });
        }
        catch (err) {
            setFlash({
                type: 'error',
                text: (_d = err.message) !== null && _d !== void 0 ? _d : 'Failed to restore checkpoint'
            });
        }
        finally {
            setRestoring(null);
        }
    };
    const handleRename = async (oldName) => {
        var _a;
        const trimmed = renameValue.trim();
        if (!trimmed || trimmed === oldName) {
            setRenamingName(null);
            return;
        }
        setFlash(null);
        try {
            await _api__WEBPACK_IMPORTED_MODULE_1__.CheckpointAPI.updateCheckpoint(namespace, oldName, {
                name: trimmed
            });
            setRenamingName(null);
            setFlash({ type: 'success', text: `Checkpoint renamed to "${trimmed}".` });
            await fetchCheckpoints();
        }
        catch (err) {
            setFlash({
                type: 'error',
                text: (_a = err.message) !== null && _a !== void 0 ? _a : 'Failed to rename checkpoint'
            });
        }
    };
    /* ------------------------------------------------------------------ */
    /*  Render                                                             */
    /* ------------------------------------------------------------------ */
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-panel" },
        flash && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `kc-flash kc-flash-${flash.type}` },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, flash.text),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-flash-close", onClick: () => setFlash(null) }, "\u00D7"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-create-section" }, !showCreateForm ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-btn kc-btn-primary", onClick: () => setShowCreateForm(true) }, "Save Kernel State")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-create-form" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "kc-input", type: "text", placeholder: "Enter checkpoint name\u2026", value: newName, onChange: e => setNewName(e.target.value), onKeyDown: e => {
                    if (e.key === 'Enter') {
                        handleCreate();
                    }
                }, autoFocus: true, disabled: creating }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-btn kc-btn-primary", disabled: creating || !newName.trim(), onClick: handleCreate }, creating ? 'Saving…' : 'Save'),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-btn", onClick: () => {
                    setShowCreateForm(false);
                    setNewName('');
                } }, "Cancel")))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-list" }, loading && checkpoints.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-placeholder" }, "Loading checkpoints\u2026")) : error ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-placeholder kc-placeholder-error" }, error)) : checkpoints.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-placeholder" }, "No checkpoints found. Click \u201CSave Kernel State\u201D to create one.")) : (checkpoints.map(cp => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: cp.name, className: "kc-item" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-item-header" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-item-info" },
                    renamingName === cp.name ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-rename-form" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "kc-input kc-input-sm", type: "text", value: renameValue, onChange: e => setRenameValue(e.target.value), onKeyDown: e => {
                                if (e.key === 'Enter') {
                                    handleRename(cp.name);
                                }
                                if (e.key === 'Escape') {
                                    setRenamingName(null);
                                }
                            }, autoFocus: true }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-btn kc-btn-xs", onClick: () => handleRename(cp.name) }, "OK"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-btn kc-btn-xs", onClick: () => setRenamingName(null) }, "Cancel"))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "kc-item-name", title: cp.name }, cp.name)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-item-meta" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(PhaseIndicator, { phase: cp.phase }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "kc-item-date" }, formatDate(cp.createdAt)))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-item-actions" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-btn kc-btn-xs", onClick: () => handleViewStatus(cp.name) }, expandedDetail === cp.name ? 'Hide' : 'Details'),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-btn kc-btn-xs", onClick: () => {
                            setRenamingName(cp.name);
                            setRenameValue(cp.name);
                        } }, "Rename"),
                    confirmDelete === cp.name ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "kc-confirm-label" }, "Delete?"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-btn kc-btn-xs kc-btn-danger", onClick: () => handleDelete(cp.name) }, "Yes"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-btn kc-btn-xs", onClick: () => setConfirmDelete(null) }, "No"))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-btn kc-btn-xs kc-btn-danger", onClick: () => setConfirmDelete(cp.name) }, "Delete")),
                    confirmRestore === cp.name ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "kc-confirm-label" }, "Restore?"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-btn kc-btn-xs kc-btn-restore", onClick: () => handleRestore(cp.name) }, "Yes"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-btn kc-btn-xs", onClick: () => setConfirmRestore(null) }, "No"))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "kc-btn kc-btn-xs kc-btn-restore", disabled: restoring !== null || cp.phase !== 'Completed', title: cp.phase !== 'Completed'
                            ? 'Checkpoint must be completed to restore'
                            : 'Restore from this checkpoint', onClick: () => setConfirmRestore(cp.name) }, restoring === cp.name ? 'Restoring…' : 'Restore')))),
            expandedDetail === cp.name && detailData && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-detail" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-detail-row" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "kc-detail-label" }, "Status"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, mapPhaseDisplay(detailData.phase))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-detail-row" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "kc-detail-label" }, "Message"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, detailData.message)),
                detailData.podRef && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-detail-row" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "kc-detail-label" }, "Pod"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, detailData.podRef.name))),
                detailData.checkpointFiles &&
                    detailData.checkpointFiles.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-detail-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "kc-detail-label" }, "Checkpoint Files"),
                    detailData.checkpointFiles.map((f, i) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: i, className: "kc-detail-file" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, f.containerName),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "kc-detail-time" }, formatDate(f.checkpointTime))))))),
                detailData.builtImages &&
                    detailData.builtImages.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "kc-detail-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "kc-detail-label" }, "Built Images"),
                    detailData.builtImages.map((img, i) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: i, className: "kc-detail-file" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "kc-detail-image-name" }, img.imageName),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "kc-detail-time" }, formatDate(img.buildTime))))))))))))))));
}


/***/ },

/***/ "./lib/index.js"
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _checkpoint_panel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./checkpoint-panel */ "./lib/checkpoint-panel.js");
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./api */ "./lib/api.js");







/**
 * ReactWidget wrapper that hosts the CheckpointPanel React tree inside a
 * JupyterLab Dialog body.
 */
class CheckpointDialogBody extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(props) {
        super();
        this._props = props;
        this.addClass('kc-dialog-body');
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_4___default().createElement(_checkpoint_panel__WEBPACK_IMPORTED_MODULE_5__.CheckpointPanel, this._props);
    }
}
const COMMAND_ID = 'kernel-checkpoint:open';
const plugin = {
    id: 'kernel-checkpoint:plugin',
    description: 'An extension for saving and restoring kernel pod state with jupyter enterprise gateway',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    activate: (app, notebookTracker) => {
        console.log('JupyterLab extension kernel-checkpoint is activated!');
        app.commands.addCommand(COMMAND_ID, {
            label: 'Saving Points',
            caption: 'Manage kernel checkpoints',
            execute: async () => {
                var _a;
                const panel = notebookTracker.currentWidget;
                if (!panel) {
                    return;
                }
                const sessionContext = panel.sessionContext;
                await sessionContext.ready;
                let config;
                try {
                    config = await _api__WEBPACK_IMPORTED_MODULE_6__.CheckpointAPI.getConfig();
                }
                catch (err) {
                    await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
                        title: 'Configuration Error',
                        body: 'Failed to load checkpoint configuration. Ensure CHECKPOINT_API_URL is set.',
                        buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton()]
                    });
                    return;
                }
                if (!config.namespace) {
                    await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
                        title: 'Configuration Error',
                        body: 'Namespace not configured. Set CHECKPOINT_NAMESPACE environment variable or deploy in Kubernetes.',
                        buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton()]
                    });
                    return;
                }
                const kernel = (_a = sessionContext.session) === null || _a === void 0 ? void 0 : _a.kernel;
                if (!kernel) {
                    await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
                        title: 'No Kernel',
                        body: 'No kernel is connected. Please start a kernel first.',
                        buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton()]
                    });
                    return;
                }
                const kernelId = kernel.id;
                const kernelSpecName = kernel.name || 'python_kubernetes';
                const notebookName = panel.title.label || '';
                const onRestore = async (checkpointName, checkpointFilePath, containerName, cpKernelId) => {
                    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__.ServerConnection.makeSettings();
                    const kernelUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.URLExt.join(settings.baseUrl, 'api', 'kernels');
                    const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__.ServerConnection.makeRequest(kernelUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            name: kernelSpecName,
                            env: {
                                KERNEL_CHECKPOINT_NAME: checkpointName,
                                KERNEL_CHECKPOINT_FILE_PATH: checkpointFilePath,
                                KERNEL_CHECKPOINT_CONTAINER_NAME: containerName,
                                KERNEL_ID: cpKernelId
                            }
                        })
                    }, settings);
                    if (!response.ok) {
                        const errText = await response.text();
                        throw new Error(`Failed to create restored kernel: ${errText}`);
                    }
                    const kernelData = await response.json();
                    await sessionContext.changeKernel({ id: kernelData.id });
                };
                const body = new CheckpointDialogBody({
                    namespace: config.namespace,
                    kernelId,
                    kernelSpecName,
                    notebookName,
                    onRestore
                });
                await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
                    title: 'Kernel Checkpoints',
                    body,
                    buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.cancelButton({ label: 'Close' })]
                });
                body.dispose();
            }
        });
        // Inject a toolbar button into every notebook panel
        notebookTracker.widgetAdded.connect((_sender, panel) => {
            const button = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ToolbarButton({
                label: 'Saving Points',
                tooltip: 'Open kernel checkpoint manager',
                onClick: () => {
                    app.commands.execute(COMMAND_ID);
                }
            });
            panel.toolbar.insertItem(10, 'kernel-checkpoint', button);
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }

}]);
//# sourceMappingURL=lib_index_js.3571ff1d8cbf7ea37b2e.js.map