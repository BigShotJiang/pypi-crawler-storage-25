"""Filesystem access abstract base class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path


class FSInterface(ABC):
    """Filesystem-like operations needed by fschema fields."""

    @abstractmethod
    def node_name(self, path: Path) -> str:
        """Return the display name of *path*."""

    @abstractmethod
    def child_path(self, path: Path, fs_name: str) -> Path:
        """Return the child path named *fs_name* under *path*."""

    @abstractmethod
    def list_directory(self, path: Path) -> list[Path]:
        """Return children of the directory at *path*."""

    @abstractmethod
    def require_file(self, path: Path) -> None:
        """Raise if *path* is not a file."""

    @abstractmethod
    def require_directory(self, path: Path) -> None:
        """Raise if *path* is not a directory."""

    @abstractmethod
    def read_file(self, path: Path, *, encoding: str = "utf-8") -> str:
        """Return file content from *path*."""
