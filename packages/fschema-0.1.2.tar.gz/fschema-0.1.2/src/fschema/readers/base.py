"""Reader abstract base class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class Reader(ABC):
    """Parse the content of a filesystem node."""

    @abstractmethod
    def read(self, content: str) -> Any:
        """Return parsed content for raw file *content*."""
