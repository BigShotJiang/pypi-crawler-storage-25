"""Data transformer abstract base class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class DataTransformer(ABC):
    """Transform parsed content into the final loaded value."""

    @abstractmethod
    def transform(self, data: Any) -> Any:
        """Return transformed *data*."""
