"""Identity data transformer."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from fschema.data.base import DataTransformer


@dataclass(frozen=True)
class IdentityTransformer(DataTransformer):
    """Return parsed content unchanged."""

    def transform(self, data: Any) -> Any:
        return data
