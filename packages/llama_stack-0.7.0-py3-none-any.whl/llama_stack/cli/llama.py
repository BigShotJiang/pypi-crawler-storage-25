# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the terms described in the LICENSE file in
# the root directory of this source tree.

import argparse

from llama_stack.log import setup_logging

# Initialize logging early before any loggers get created
setup_logging()

from .stack import StackParser  # type: ignore[attr-defined]
from .stack.utils import print_subcommand_description


class LlamaCLIParser:
    """Defines CLI parser for Llama CLI"""

    def __init__(self) -> None:
        self.parser = argparse.ArgumentParser(
            prog="llama",
            description="Welcome to the Llama CLI",
            add_help=True,
            formatter_class=argparse.RawTextHelpFormatter,
        )

        # Default command is to print help
        self.parser.set_defaults(func=lambda args: self.parser.print_help())

        subparsers = self.parser.add_subparsers(title="subcommands")

        # Add sub-commands
        StackParser.create(subparsers)  # type: ignore[no-untyped-call]

        print_subcommand_description(self.parser, subparsers)  # type: ignore[no-untyped-call]

    def parse_args(self) -> argparse.Namespace:
        args = self.parser.parse_args()
        if not isinstance(args, argparse.Namespace):
            raise TypeError(f"Expected argparse.Namespace, got {type(args)}")
        return args

    def run(self, args: argparse.Namespace) -> None:
        args.func(args)


def main() -> None:
    """Entry point for the Llama CLI."""
    parser = LlamaCLIParser()
    args = parser.parse_args()
    parser.run(args)


if __name__ == "__main__":
    main()
