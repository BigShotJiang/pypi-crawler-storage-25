# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the terms described in the LICENSE file in
# the root directory of this source tree.
from typing import Any

from pydantic import BaseModel, SecretStr

from llama_stack.core.datatypes import Api

from .config import BraintrustScoringConfig


class BraintrustProviderDataValidator(BaseModel):
    """Validator for Braintrust provider data requiring an OpenAI API key."""

    openai_api_key: SecretStr


async def get_provider_impl(
    config: BraintrustScoringConfig,
    deps: dict[Api, Any],
):
    from .braintrust import BraintrustScoringImpl

    impl = BraintrustScoringImpl(config, deps[Api.datasetio], deps[Api.datasets])
    await impl.initialize()
    return impl
