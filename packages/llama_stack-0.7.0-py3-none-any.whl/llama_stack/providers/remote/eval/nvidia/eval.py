# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the terms described in the LICENSE file in
# the root directory of this source tree.
from typing import Any

import httpx

from llama_stack.providers.utils.inference.model_registry import ModelRegistryHelper
from llama_stack_api import (
    Benchmark,
    BenchmarksProtocolPrivate,
    DatasetIO,
    Datasets,
    Eval,
    EvaluateResponse,
    EvaluateRowsRequest,
    Inference,
    Job,
    JobCancelRequest,
    JobResultRequest,
    JobStatus,
    JobStatusRequest,
    Responses,
    RunEvalRequest,
    Scoring,
    ScoringResult,
)

from .config import NVIDIAEvalConfig

DEFAULT_NAMESPACE = "nvidia"


class NVIDIAEvalImpl(
    Eval,
    BenchmarksProtocolPrivate,
    ModelRegistryHelper,
):
    """Evaluation provider implementation using NVIDIA evaluation services."""

    def __init__(
        self,
        config: NVIDIAEvalConfig,
        datasetio_api: DatasetIO,
        datasets_api: Datasets,
        scoring_api: Scoring,
        inference_api: Inference,
        responses_api: Responses,
    ) -> None:
        self.config = config
        self.datasetio_api = datasetio_api
        self.datasets_api = datasets_api
        self.scoring_api = scoring_api
        self.inference_api = inference_api
        self.responses_api = responses_api

        ModelRegistryHelper.__init__(self)
        self._client: httpx.AsyncClient | None = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("Client not initialized. Call initialize() first.")
        return self._client

    async def initialize(self) -> None:
        self._client = httpx.AsyncClient(timeout=httpx.Timeout(30.0))

    async def shutdown(self) -> None:
        if self._client:
            await self._client.aclose()

    async def _evaluator_get(self, path: str):
        """Helper for making GET requests to the evaluator service."""
        response = await self.client.get(url=f"{self.config.evaluator_url}{path}")
        response.raise_for_status()
        return response.json()

    async def _evaluator_post(self, path: str, data: dict[str, Any]):
        """Helper for making POST requests to the evaluator service."""
        response = await self.client.post(url=f"{self.config.evaluator_url}{path}", json=data)
        response.raise_for_status()
        return response.json()

    async def _evaluator_delete(self, path: str) -> None:
        """Helper for making DELETE requests to the evaluator service."""
        response = await self.client.delete(url=f"{self.config.evaluator_url}{path}")
        response.raise_for_status()

    async def register_benchmark(self, task_def: Benchmark) -> None:
        """Register a benchmark as an evaluation configuration."""
        await self._evaluator_post(
            "/v1/evaluation/configs",
            {
                "namespace": DEFAULT_NAMESPACE,
                "name": task_def.benchmark_id,
                # metadata is copied to request body as-is
                **task_def.metadata,
            },
        )

    async def unregister_benchmark(self, benchmark_id: str) -> None:
        """Unregister a benchmark evaluation configuration from NeMo Evaluator."""
        await self._evaluator_delete(f"/v1/evaluation/configs/{DEFAULT_NAMESPACE}/{benchmark_id}")

    async def run_eval(
        self,
        request: RunEvalRequest,
    ) -> Job:
        """Run an evaluation job for a benchmark."""
        model = (
            request.benchmark_config.eval_candidate.model
            if request.benchmark_config.eval_candidate.type == "model"
            else request.benchmark_config.eval_candidate.config.model
        )
        nvidia_model = self.get_provider_model_id(model) or model

        result = await self._evaluator_post(
            "/v1/evaluation/jobs",
            {
                "config": f"{DEFAULT_NAMESPACE}/{request.benchmark_id}",
                "target": {"type": "model", "model": nvidia_model},
            },
        )

        return Job(job_id=result["id"], status=JobStatus.in_progress)

    async def evaluate_rows(
        self,
        request: EvaluateRowsRequest,
    ) -> EvaluateResponse:
        raise NotImplementedError()

    async def job_status(self, request: JobStatusRequest) -> Job:
        """Get the status of an evaluation job.

        EvaluatorStatus: "created", "pending", "running", "cancelled", "cancelling", "failed", "completed".
        JobStatus: "scheduled", "in_progress", "completed", "cancelled", "failed"
        """
        result = await self._evaluator_get(f"/v1/evaluation/jobs/{request.job_id}")
        result_status = result["status"]

        job_status = JobStatus.failed
        if result_status in ["created", "pending"]:
            job_status = JobStatus.scheduled
        elif result_status in ["running"]:
            job_status = JobStatus.in_progress
        elif result_status in ["completed"]:
            job_status = JobStatus.completed
        elif result_status in ["cancelled"]:
            job_status = JobStatus.cancelled

        return Job(job_id=request.job_id, status=job_status)

    async def job_cancel(self, request: JobCancelRequest) -> None:
        """Cancel the evaluation job."""
        await self._evaluator_post(f"/v1/evaluation/jobs/{request.job_id}/cancel", {})

    async def job_result(self, request: JobResultRequest) -> EvaluateResponse:
        """Returns the results of the evaluation job."""

        job_status_request = JobStatusRequest(benchmark_id=request.benchmark_id, job_id=request.job_id)
        job = await self.job_status(job_status_request)
        status = job.status
        if not status or status != JobStatus.completed:
            raise ValueError(f"Job {request.job_id} not completed. Status: {status.value}")

        result = await self._evaluator_get(f"/v1/evaluation/jobs/{request.job_id}/results")

        return EvaluateResponse(
            # TODO: these are stored in detailed results on NeMo Evaluator side; can be added
            generations=[],
            scores={
                request.benchmark_id: ScoringResult(
                    score_rows=[],
                    aggregated_results=result,
                )
            },
        )
