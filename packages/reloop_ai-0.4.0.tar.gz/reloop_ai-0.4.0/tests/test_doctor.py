"""Tests for the ``reloop doctor`` CLI command."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from src.cli.main import app

runner = CliRunner()


@pytest.fixture(autouse=True)
def _patch_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Ensure a consistent environment for every test."""
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-key")
    monkeypatch.delenv("BLAXEL_API_KEY", raising=False)


# --------------------------------------------------------------------------- #
# Happy-path: all checks pass
# --------------------------------------------------------------------------- #


def test_doctor_all_pass(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("BLAXEL_API_KEY", "bl-test")

    mock_redis_client = MagicMock()
    mock_redis_client.ping.return_value = True

    with (
        patch("redis.from_url", return_value=mock_redis_client),
        patch("httpx.get") as mock_get,
    ):
        mock_get.return_value = MagicMock(status_code=200)
        mock_get.return_value.raise_for_status = MagicMock()

        result = runner.invoke(app, ["doctor"])

    assert result.exit_code == 0
    assert "ReLoop Doctor" in result.output


# --------------------------------------------------------------------------- #
# Missing OPENAI_API_KEY → exit 1
# --------------------------------------------------------------------------- #


def test_doctor_missing_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    mock_redis_client = MagicMock()
    mock_redis_client.ping.return_value = True

    with (
        patch("redis.from_url", return_value=mock_redis_client),
        patch("httpx.get") as mock_get,
    ):
        mock_get.return_value = MagicMock(status_code=200)
        mock_get.return_value.raise_for_status = MagicMock()

        result = runner.invoke(app, ["doctor"])

    assert result.exit_code == 1
    assert "OPENAI_API_KEY" in result.output


# --------------------------------------------------------------------------- #
# Redis unreachable — still runs, just shows ❌
# --------------------------------------------------------------------------- #


def test_doctor_redis_down() -> None:
    with (
        patch("redis.from_url", side_effect=ConnectionError("refused")),
        patch("httpx.get") as mock_get,
    ):
        mock_get.return_value = MagicMock(status_code=200)
        mock_get.return_value.raise_for_status = MagicMock()

        result = runner.invoke(app, ["doctor"])

    assert result.exit_code == 0
    assert "Redis" in result.output


# --------------------------------------------------------------------------- #
# Server unreachable — still runs, just shows ❌
# --------------------------------------------------------------------------- #


def test_doctor_server_down() -> None:
    mock_redis_client = MagicMock()
    mock_redis_client.ping.return_value = True

    with (
        patch("redis.from_url", return_value=mock_redis_client),
        patch("httpx.get", side_effect=Exception("Connection refused")),
    ):
        result = runner.invoke(app, ["doctor"])

    assert result.exit_code == 0
    assert "API Server" in result.output
