"""Tests for the @reloop.retry decorator."""

from __future__ import annotations

import asyncio
from unittest.mock import patch

import pytest

import reloop


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class FakeSyncMemory:
    """In-memory stand-in for SyncFailureMemory used by the decorator."""

    def __init__(self, **kwargs):
        self.failures: list[dict] = []
        self.successes: list[dict] = []
        self.search_results: list[dict] = []

    def store_failure(self, **kwargs) -> str:
        self.failures.append(kwargs)
        return "fail-id"

    def store_success(self, **kwargs) -> str:
        self.successes.append(kwargs)
        return "succ-id"

    def search(self, query: str, limit: int = 5) -> list[dict]:
        return self.search_results


@pytest.fixture
def fake_memory():
    """Patch SyncFailureMemory so the decorator uses our fake."""
    mem = FakeSyncMemory()
    with patch("src.decorators.SyncFailureMemory", return_value=mem):
        yield mem


# ---------------------------------------------------------------------------
# Tests — sync functions
# ---------------------------------------------------------------------------


def test_sync_function_succeeds(fake_memory):
    """Decorated sync function returns normally on success."""

    @reloop.retry(max_retries=3)
    def greet(name: str) -> str:
        return f"hello {name}"

    assert greet("world") == "hello world"
    assert len(fake_memory.successes) == 1
    assert fake_memory.successes[0]["approach"] == "function call succeeded"


def test_sync_retries_on_failure(fake_memory):
    """Decorator retries a sync function up to max_retries times (max_retries+1 total calls)."""
    call_count = 0

    @reloop.retry(max_retries=2)  # 2 retries → 3 total calls
    def flaky():
        nonlocal call_count
        call_count += 1
        raise ValueError("boom")

    with patch("time.sleep"):  # skip real backoff
        with pytest.raises(ValueError, match="boom"):
            flaky()

    assert call_count == 3
    assert len(fake_memory.failures) == 3


def test_sync_succeeds_on_second_attempt(fake_memory):
    """Decorator returns success when function recovers on second try."""
    call_count = 0

    @reloop.retry(max_retries=3)
    def eventually_works():
        nonlocal call_count
        call_count += 1
        if call_count < 2:
            raise RuntimeError("not yet")
        return "ok"

    with patch("time.sleep"):
        result = eventually_works()

    assert result == "ok"
    assert call_count == 2
    assert len(fake_memory.failures) == 1
    assert len(fake_memory.successes) == 1


def test_sync_stores_failure_details(fake_memory):
    """Failure record includes error type and message."""

    @reloop.retry(max_retries=0)  # 0 retries → exactly 1 call → 1 failure stored
    def bad():
        raise TypeError("wrong type")

    with pytest.raises(TypeError):
        bad()

    assert len(fake_memory.failures) == 1
    rec = fake_memory.failures[0]
    assert rec["error_type"] == "TypeError"
    assert rec["error_message"] == "wrong type"


def test_sync_preserves_function_metadata():
    """functools.wraps preserves __name__ and __doc__."""

    @reloop.retry(max_retries=2)
    def my_func():
        """My docstring."""

    assert my_func.__name__ == "my_func"
    assert my_func.__doc__ == "My docstring."


def test_sync_reraises_after_max_retries(fake_memory):
    """After exhausting retries, the last exception is re-raised."""

    @reloop.retry(max_retries=2)
    def always_fails():
        raise OSError("disk full")

    with patch("time.sleep"):
        with pytest.raises(OSError, match="disk full"):
            always_fails()


# ---------------------------------------------------------------------------
# Tests — async functions
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_function_succeeds(fake_memory):
    """Decorated async function returns normally on success."""

    @reloop.retry(max_retries=3)
    async def greet(name: str) -> str:
        return f"hello {name}"

    result = await greet("world")
    assert result == "hello world"
    assert len(fake_memory.successes) == 1


@pytest.mark.asyncio
async def test_async_retries_on_failure(fake_memory):
    """Decorator retries an async function max_retries times (max_retries+1 total calls)."""
    call_count = 0

    @reloop.retry(max_retries=2)  # 2 retries → 3 total calls
    async def flaky():
        nonlocal call_count
        call_count += 1
        raise ValueError("async boom")

    with patch("asyncio.sleep", side_effect=lambda _: None):
        with pytest.raises(ValueError, match="async boom"):
            await flaky()

    assert call_count == 3
    assert len(fake_memory.failures) == 3


@pytest.mark.asyncio
async def test_async_succeeds_on_second_attempt(fake_memory):
    """Async function recovers on second try."""
    call_count = 0

    @reloop.retry(max_retries=3)
    async def eventually_works():
        nonlocal call_count
        call_count += 1
        if call_count < 2:
            raise RuntimeError("not yet")
        return "ok"

    async def _noop_sleep(_):
        pass

    with patch("src.decorators.asyncio") as mock_aio:
        mock_aio.sleep = _noop_sleep
        result = await eventually_works()

    assert result == "ok"
    assert call_count == 2
    assert len(fake_memory.failures) == 1
    assert len(fake_memory.successes) == 1


@pytest.mark.asyncio
async def test_async_stores_failure_details(fake_memory):
    """Async failure record includes error type and message."""

    @reloop.retry(max_retries=0)  # 0 retries → exactly 1 call → 1 failure stored
    async def bad():
        raise KeyError("missing")

    with pytest.raises(KeyError):
        await bad()

    assert len(fake_memory.failures) == 1
    rec = fake_memory.failures[0]
    assert rec["error_type"] == "KeyError"
    assert rec["error_message"] == "'missing'"
