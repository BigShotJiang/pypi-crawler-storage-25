"""Tests for reloop export / reloop import CLI commands."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml
from typer.testing import CliRunner

from src.cli.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

SAMPLE_EXPORT_RESPONSE = {
    "name": "ReLoop Failure Playbook",
    "version": "1.0",
    "domain": "",
    "failures": [
        {
            "id": "f-1",
            "signature": {"error_type": "ModuleNotFoundError", "error_category": "dependency_error"},
            "analysis": {"root_cause": "sharp not installed"},
        },
        {
            "id": "f-2",
            "signature": {"error_type": "TypeError", "error_category": "type_error"},
            "analysis": {"root_cause": "wrong arg type"},
        },
    ],
    "stats": {"total": 2, "categories": {"dependency_error": 1, "type_error": 1}},
}


def _mock_export_client():
    mock_resp = MagicMock()
    mock_resp.json.return_value = SAMPLE_EXPORT_RESPONSE
    mock_resp.raise_for_status = MagicMock()
    mock_client = MagicMock()
    mock_client.get.return_value = mock_resp
    return mock_client


def test_export_default_yaml(tmp_path):
    out_file = tmp_path / "reloop-playbook.yaml"
    with patch("src.cli.main._http_client", return_value=_mock_export_client()):
        result = runner.invoke(app, ["export", "--output", str(out_file)])
    assert result.exit_code == 0
    assert "Exported 2 failures" in result.output
    loaded = yaml.safe_load(out_file.read_text())
    assert len(loaded["failures"]) == 2


def test_export_json_format(tmp_path):
    out_file = tmp_path / "playbook.json"
    with patch("src.cli.main._http_client", return_value=_mock_export_client()):
        result = runner.invoke(app, ["export", "--output", str(out_file), "--format", "json"])
    assert result.exit_code == 0
    assert "Exported 2 failures" in result.output
    loaded = json.loads(out_file.read_text())
    assert loaded["failures"][0]["id"] == "f-1"


def test_export_json_format_renames_extension(tmp_path):
    out_file = tmp_path / "playbook.yaml"
    with patch("src.cli.main._http_client", return_value=_mock_export_client()):
        result = runner.invoke(app, ["export", "--output", str(out_file), "--format", "json"])
    assert result.exit_code == 0
    # Should have been written as .json
    json_file = out_file.with_suffix(".json")
    assert json_file.exists()


def test_export_api_error():
    mock_client = MagicMock()
    mock_client.get.side_effect = Exception("Connection refused")
    with patch("src.cli.main._http_client", return_value=mock_client):
        result = runner.invoke(app, ["export"])
    assert result.exit_code == 1
    assert "Error" in result.output


# ---------------------------------------------------------------------------
# Import
# ---------------------------------------------------------------------------

def test_import_yaml(tmp_path):
    playbook = {
        "failures": [
            {"id": "f-1", "signature": {}, "analysis": {}},
        ],
        "domain": "",
    }
    file = tmp_path / "playbook.yaml"
    file.write_text(yaml.dump(playbook))

    mock_resp = MagicMock()
    mock_resp.json.return_value = {"imported": 1, "errors": 0, "total": 1}
    mock_resp.raise_for_status = MagicMock()
    mock_client = MagicMock()
    mock_client.post.return_value = mock_resp

    with patch("src.cli.main._http_client", return_value=mock_client):
        result = runner.invoke(app, ["import", str(file)])
    assert result.exit_code == 0
    assert "Imported 1 failures" in result.output


def test_import_json(tmp_path):
    playbook = {
        "failures": [
            {"id": "f-1", "signature": {}, "analysis": {}},
            {"id": "f-2", "signature": {}, "analysis": {}},
        ],
        "domain": "web",
    }
    file = tmp_path / "playbook.json"
    file.write_text(json.dumps(playbook))

    mock_resp = MagicMock()
    mock_resp.json.return_value = {"imported": 2, "errors": 0, "total": 2}
    mock_resp.raise_for_status = MagicMock()
    mock_client = MagicMock()
    mock_client.post.return_value = mock_resp

    with patch("src.cli.main._http_client", return_value=mock_client):
        result = runner.invoke(app, ["import", str(file)])
    assert result.exit_code == 0
    assert "Imported 2 failures" in result.output


def test_import_file_not_found():
    result = runner.invoke(app, ["import", "/nonexistent/playbook.yaml"])
    assert result.exit_code == 1
    assert "File not found" in result.output


def test_import_api_error(tmp_path):
    file = tmp_path / "playbook.json"
    file.write_text(json.dumps({"failures": [], "domain": ""}))

    mock_client = MagicMock()
    mock_client.post.side_effect = Exception("Server error")

    with patch("src.cli.main._http_client", return_value=mock_client):
        result = runner.invoke(app, ["import", str(file)])
    assert result.exit_code == 1
    assert "Error" in result.output
