"""Shared pytest fixtures for ReLoop test suite."""

from __future__ import annotations

import asyncio
from typing import Any, AsyncIterator

import pytest

from src.models import (
    ErrorCategory,
    ErrorSignature,
    FailureAnalysis,
    FailureRecord,
    MemoryStatsResponse,
    SuccessRecord,
    Task,
)
from src.providers.base import (
    Checkpoint,
    ExecutionResult,
    LLMProvider,
    LLMResponse,
    MemoryBackend,
    SandboxProvider,
)


# ---------------------------------------------------------------------------
# Event loop policy
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def event_loop_policy():
    return asyncio.DefaultEventLoopPolicy()


# ---------------------------------------------------------------------------
# Sample data factories
# ---------------------------------------------------------------------------

def make_error_signature(
    error_type: str = "ModuleNotFoundError",
    error_message: str = "Module not found: sharp",
    error_category: ErrorCategory = ErrorCategory.DEPENDENCY_ERROR,
) -> ErrorSignature:
    return ErrorSignature(
        error_type=error_type,
        error_category=error_category,
        error_message=error_message,
    )


def make_failure_analysis(
    root_cause: str = "sharp package not installed",
    suggested_fix: str = "npm install sharp",
) -> FailureAnalysis:
    return FailureAnalysis(
        root_cause=root_cause,
        what_was_tried="npm run build",
        why_it_failed="sharp is a peer dependency of next/image optimization",
        suggested_fix=suggested_fix,
        confidence=0.95,
    )


def make_failure_record(
    task_id: str = "task-001",
    attempt_number: int = 1,
    error_type: str = "ModuleNotFoundError",
    error_message: str = "Module not found: sharp",
    error_category: ErrorCategory = ErrorCategory.DEPENDENCY_ERROR,
    suggested_fix: str = "npm install sharp",
) -> FailureRecord:
    return FailureRecord(
        task_id=task_id,
        attempt_number=attempt_number,
        signature=make_error_signature(error_type, error_message, error_category),
        analysis=make_failure_analysis(suggested_fix=suggested_fix),
        cost_usd=0.01,
    )


def make_success_record(task_id: str = "task-001", attempt_number: int = 4) -> SuccessRecord:
    return SuccessRecord(
        task_id=task_id,
        attempt_number=attempt_number,
        solution={"approach": "installed sharp, changed port, fixed types, fixed db url"},
        learning={"failure_count": 3, "transferable": True},
        metrics={"total_attempts": 4, "total_cost_usd": 0.05},
    )


def make_task(
    instruction: str = "Fix and start the demo Next.js project",
    max_retries: int = 5,
    max_budget_usd: float = 1.0,
) -> Task:
    return Task(
        instruction=instruction,
        max_retries=max_retries,
        max_budget_usd=max_budget_usd,
    )


# ---------------------------------------------------------------------------
# pytest fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_failure_record() -> FailureRecord:
    return make_failure_record()


@pytest.fixture
def sample_success_record() -> SuccessRecord:
    return make_success_record()


@pytest.fixture
def sample_task() -> Task:
    return make_task()


# ---------------------------------------------------------------------------
# Mock MemoryBackend
# ---------------------------------------------------------------------------

class InMemoryBackend(MemoryBackend):
    """Simple in-memory implementation of MemoryBackend for tests."""

    def __init__(self) -> None:
        self._failures: dict[str, FailureRecord] = {}
        self._successes: dict[str, SuccessRecord] = {}

    async def store_failure(self, failure: FailureRecord) -> str:
        self._failures[failure.id] = failure
        return failure.id

    async def store_success(self, success: SuccessRecord) -> str:
        self._successes[success.id] = success
        return success.id

    async def get_similar_failures(
        self,
        error_type: str,
        error_message: str,
        limit: int = 5,
        embedding: list[float] | None = None,
    ) -> list[FailureRecord]:
        results = []
        for f in self._failures.values():
            if f.signature.error_type == error_type or error_type in f.signature.error_message:
                results.append(f)
        return results[:limit]

    async def search(
        self,
        query: str,
        limit: int = 5,
        filters: dict[str, Any] | None = None,
    ) -> list[FailureRecord]:
        results = []
        query_lower = query.lower()
        for f in self._failures.values():
            if (
                query_lower in f.signature.error_message.lower()
                or query_lower in f.analysis.root_cause.lower()
            ):
                results.append(f)
        return results[:limit]

    async def get_failure(self, failure_id: str) -> FailureRecord | None:
        return self._failures.get(failure_id)

    async def get_failures_for_task(self, task_id: str) -> list[FailureRecord]:
        return [f for f in self._failures.values() if f.task_id == task_id]

    async def get_stats(self) -> MemoryStatsResponse:
        category_counts: dict[str, int] = {}
        confidence_total = 0.0
        for f in self._failures.values():
            cat = f.signature.error_category.value
            category_counts[cat] = category_counts.get(cat, 0) + 1
            confidence_total += f.analysis.confidence

        avg_conf = confidence_total / len(self._failures) if self._failures else 0.0
        return MemoryStatsResponse(
            total_failures=len(self._failures),
            total_successes=len(self._successes),
            top_error_categories=category_counts,
            avg_confidence=avg_conf,
        )

    async def clear(self) -> None:
        self._failures.clear()
        self._successes.clear()


# ---------------------------------------------------------------------------
# Mock SandboxProvider
# ---------------------------------------------------------------------------

class MockSandboxProvider(SandboxProvider):
    """Deterministic sandbox for tests. Tracks executed commands."""

    def __init__(self, command_results: dict[str, ExecutionResult] | None = None) -> None:
        self._results = command_results or {}
        self._sandboxes: set[str] = set()
        self._checkpoints: dict[str, list[Checkpoint]] = {}
        self.executed_commands: list[tuple[str, str]] = []  # (sandbox_id, command)

    def set_result(self, command: str, result: ExecutionResult) -> None:
        self._results[command] = result

    async def create(self, config: dict[str, Any] | None = None) -> str:
        sandbox_id = f"sandbox-{len(self._sandboxes) + 1:04d}"
        self._sandboxes.add(sandbox_id)
        self._checkpoints[sandbox_id] = []
        return sandbox_id

    async def execute(
        self,
        sandbox_id: str,
        command: str,
        timeout: int = 120,
    ) -> ExecutionResult:
        self.executed_commands.append((sandbox_id, command))
        if command in self._results:
            return self._results[command]
        return ExecutionResult(exit_code=0, stdout="ok", stderr="")

    async def checkpoint(self, sandbox_id: str) -> str:
        cp = Checkpoint(
            task_id="test",
            attempt_number=len(self._checkpoints.get(sandbox_id, [])),
            sandbox_snapshot_id=f"snap-{sandbox_id}",
        )
        self._checkpoints.setdefault(sandbox_id, []).append(cp)
        return cp.id

    async def restore(self, sandbox_id: str, checkpoint_id: str) -> None:
        pass  # no-op in tests

    async def destroy(self, sandbox_id: str) -> None:
        self._sandboxes.discard(sandbox_id)

    async def list_checkpoints(self, sandbox_id: str) -> list[Checkpoint]:
        return self._checkpoints.get(sandbox_id, [])


# ---------------------------------------------------------------------------
# Mock LLMProvider
# ---------------------------------------------------------------------------

class MockLLMProvider(LLMProvider):
    """Returns canned responses. Can be pre-loaded with a response queue."""

    def __init__(self, canned_responses: list[str] | None = None) -> None:
        self._responses = list(canned_responses or [])
        self._default = "No fix available."
        self.call_count = 0

    def _next_response(self) -> str:
        self.call_count += 1
        if self._responses:
            return self._responses.pop(0)
        return self._default

    async def generate(
        self,
        prompt: str,
        system: str = "",
        temperature: float = 0.3,
    ) -> LLMResponse:
        return LLMResponse(content=self._next_response(), tokens_used=100, cost_usd=0.001)

    async def generate_with_tools(
        self,
        prompt: str,
        system: str = "",
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.3,
    ) -> LLMResponse:
        return LLMResponse(content=self._next_response(), tokens_used=150, cost_usd=0.002)

    async def stream(
        self,
        prompt: str,
        system: str = "",
    ) -> AsyncIterator[str]:
        response = self._next_response()

        async def _gen():
            for token in response.split():
                yield token + " "

        return _gen()

    async def embed(self, text: str) -> list[float]:
        # Deterministic pseudo-embedding based on text length
        val = len(text) / 1000.0
        return [val] * 128


# ---------------------------------------------------------------------------
# Fixture instances
# ---------------------------------------------------------------------------

@pytest.fixture
def memory_backend() -> InMemoryBackend:
    return InMemoryBackend()


@pytest.fixture
def sandbox_provider() -> MockSandboxProvider:
    return MockSandboxProvider()


@pytest.fixture
def llm_provider() -> MockLLMProvider:
    return MockLLMProvider()
