"""Tests for the MemoryBackend interface using the InMemoryBackend mock."""

from __future__ import annotations

import pytest

from src.models import ErrorCategory, ErrorSignature, FailureAnalysis, FailureRecord
from tests.conftest import InMemoryBackend, make_failure_record, make_success_record


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _record(
    task_id: str = "t1",
    attempt: int = 1,
    error_type: str = "ModuleNotFoundError",
    error_message: str = "Module not found: sharp",
    category: ErrorCategory = ErrorCategory.DEPENDENCY_ERROR,
    fix: str = "npm install sharp",
) -> FailureRecord:
    return make_failure_record(
        task_id=task_id,
        attempt_number=attempt,
        error_type=error_type,
        error_message=error_message,
        error_category=category,
        suggested_fix=fix,
    )


# ---------------------------------------------------------------------------
# store_failure / get_failure round-trip
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_store_and_retrieve_failure():
    backend = InMemoryBackend()
    record = _record()
    returned_id = await backend.store_failure(record)
    assert returned_id == record.id

    retrieved = await backend.get_failure(record.id)
    assert retrieved is not None
    assert retrieved.id == record.id
    assert retrieved.task_id == record.task_id
    assert retrieved.signature.error_type == record.signature.error_type
    assert retrieved.analysis.suggested_fix == record.analysis.suggested_fix


@pytest.mark.asyncio
async def test_get_failure_missing_returns_none():
    backend = InMemoryBackend()
    result = await backend.get_failure("nonexistent-id")
    assert result is None


@pytest.mark.asyncio
async def test_store_multiple_failures_independent():
    backend = InMemoryBackend()
    r1 = _record(task_id="t1", attempt=1, error_type="TypeError")
    r2 = _record(task_id="t1", attempt=2, error_type="ConfigError")
    r3 = _record(task_id="t2", attempt=1, error_type="TypeError")

    await backend.store_failure(r1)
    await backend.store_failure(r2)
    await backend.store_failure(r3)

    assert await backend.get_failure(r1.id) is not None
    assert await backend.get_failure(r2.id) is not None
    assert await backend.get_failure(r3.id) is not None


# ---------------------------------------------------------------------------
# store_success
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_store_success_round_trip():
    backend = InMemoryBackend()
    success = make_success_record(task_id="t1", attempt_number=3)
    returned_id = await backend.store_success(success)
    assert returned_id == success.id


# ---------------------------------------------------------------------------
# get_similar_failures
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_get_similar_failures_by_type():
    backend = InMemoryBackend()
    r1 = _record(error_type="ModuleNotFoundError", error_message="Module not found: sharp")
    r2 = _record(error_type="TypeError", error_message="Type error in component")
    r3 = _record(error_type="ModuleNotFoundError", error_message="Module not found: pg")

    for r in [r1, r2, r3]:
        await backend.store_failure(r)

    results = await backend.get_similar_failures("ModuleNotFoundError", "some message")
    assert len(results) == 2
    result_types = {r.signature.error_type for r in results}
    assert result_types == {"ModuleNotFoundError"}


@pytest.mark.asyncio
async def test_get_similar_failures_limit_respected():
    backend = InMemoryBackend()
    for i in range(10):
        r = _record(error_type="ModuleNotFoundError", error_message=f"module {i} missing")
        await backend.store_failure(r)

    results = await backend.get_similar_failures("ModuleNotFoundError", "", limit=3)
    assert len(results) <= 3


@pytest.mark.asyncio
async def test_get_similar_failures_empty_when_no_match():
    backend = InMemoryBackend()
    await backend.store_failure(_record(error_type="TypeError"))
    results = await backend.get_similar_failures("NetworkError", "timeout", limit=5)
    assert results == []


# ---------------------------------------------------------------------------
# get_failures_for_task
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_get_failures_for_task_returns_correct_records():
    backend = InMemoryBackend()
    r1 = _record(task_id="task-A", attempt=1)
    r2 = _record(task_id="task-A", attempt=2, error_type="TypeError")
    r3 = _record(task_id="task-B", attempt=1)

    for r in [r1, r2, r3]:
        await backend.store_failure(r)

    task_a_failures = await backend.get_failures_for_task("task-A")
    assert len(task_a_failures) == 2
    task_ids = {f.task_id for f in task_a_failures}
    assert task_ids == {"task-A"}

    task_b_failures = await backend.get_failures_for_task("task-B")
    assert len(task_b_failures) == 1


@pytest.mark.asyncio
async def test_get_failures_for_task_empty_when_none():
    backend = InMemoryBackend()
    results = await backend.get_failures_for_task("nonexistent-task")
    assert results == []


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_search_finds_by_message_substring():
    backend = InMemoryBackend()
    r1 = _record(error_message="Module not found: sharp")
    r2 = _record(error_message="port 3000 already in use", fix="change port to 3001")
    # Override r2's root_cause so it doesn't contain "sharp"
    r2.analysis.root_cause = "port conflict with existing process"
    await backend.store_failure(r1)
    await backend.store_failure(r2)

    results = await backend.search("sharp")
    assert len(results) == 1
    assert results[0].signature.error_message == "Module not found: sharp"


@pytest.mark.asyncio
async def test_search_case_insensitive():
    backend = InMemoryBackend()
    r = _record(error_message="Module not found: sharp")
    await backend.store_failure(r)

    results = await backend.search("SHARP")
    assert len(results) == 1


@pytest.mark.asyncio
async def test_search_returns_empty_when_no_match():
    backend = InMemoryBackend()
    await backend.store_failure(_record(error_message="port conflict"))
    results = await backend.search("completely unrelated query xyz")
    assert results == []


# ---------------------------------------------------------------------------
# get_stats
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_get_stats_empty_backend():
    backend = InMemoryBackend()
    stats = await backend.get_stats()
    assert stats.total_failures == 0
    assert stats.total_successes == 0
    assert stats.top_error_categories == {}
    assert stats.avg_confidence == 0.0


@pytest.mark.asyncio
async def test_get_stats_aggregation():
    backend = InMemoryBackend()
    await backend.store_failure(
        _record(category=ErrorCategory.DEPENDENCY_ERROR)
    )
    await backend.store_failure(
        _record(category=ErrorCategory.DEPENDENCY_ERROR, error_message="other missing module")
    )
    await backend.store_failure(
        _record(category=ErrorCategory.CONFIG_ERROR, error_type="ConfigError", error_message="bad port")
    )
    await backend.store_success(make_success_record())

    stats = await backend.get_stats()
    assert stats.total_failures == 3
    assert stats.total_successes == 1
    assert stats.top_error_categories.get("dependency_error") == 2
    assert stats.top_error_categories.get("config_error") == 1
    assert 0.0 < stats.avg_confidence <= 1.0


@pytest.mark.asyncio
async def test_get_stats_avg_confidence_correct():
    backend = InMemoryBackend()
    # Two records with different confidence values
    r1 = FailureRecord(
        task_id="t",
        attempt_number=1,
        signature=ErrorSignature(error_type="E", error_message="msg"),
        analysis=FailureAnalysis(
            root_cause="x", what_was_tried="y", why_it_failed="z", suggested_fix="w",
            confidence=0.6,
        ),
    )
    r2 = FailureRecord(
        task_id="t",
        attempt_number=2,
        signature=ErrorSignature(error_type="E", error_message="msg2"),
        analysis=FailureAnalysis(
            root_cause="x", what_was_tried="y", why_it_failed="z", suggested_fix="w",
            confidence=1.0,
        ),
    )
    await backend.store_failure(r1)
    await backend.store_failure(r2)

    stats = await backend.get_stats()
    assert abs(stats.avg_confidence - 0.8) < 1e-9


# ---------------------------------------------------------------------------
# clear
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_clear_removes_all_failures():
    backend = InMemoryBackend()
    for i in range(5):
        await backend.store_failure(_record(attempt=i))
    await backend.store_success(make_success_record())

    await backend.clear()

    stats = await backend.get_stats()
    assert stats.total_failures == 0
    assert stats.total_successes == 0


@pytest.mark.asyncio
async def test_clear_then_store_works():
    backend = InMemoryBackend()
    await backend.store_failure(_record())
    await backend.clear()

    r = _record(error_message="after clear")
    await backend.store_failure(r)
    retrieved = await backend.get_failure(r.id)
    assert retrieved is not None
    assert retrieved.signature.error_message == "after clear"
