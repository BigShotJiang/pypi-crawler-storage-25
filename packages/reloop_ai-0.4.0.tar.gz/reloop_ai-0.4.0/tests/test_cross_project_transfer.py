"""Tests for cross-project failure transfer and transferable flag."""

from __future__ import annotations

import pytest

from src.core.distiller import Distiller
from src.core.memory import FailureMemoryManager
from src.models import (
    ErrorCategory,
    ErrorSignature,
    FailureAnalysis,
    FailureRecord,
)
from tests.conftest import InMemoryBackend, MockLLMProvider, make_failure_record


# ---------------------------------------------------------------------------
# Cross-project search
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_search_cross_project_returns_transferable_only():
    """search_cross_project should only return records with transferable=True."""
    backend = InMemoryBackend()
    mgr = FailureMemoryManager(backend)

    # Store a transferable failure from project A
    f_transferable = make_failure_record(
        task_id="project-a",
        error_type="ModuleNotFoundError",
        error_message="Module not found: sharp",
    )
    f_transferable.transferable = True
    await backend.store_failure(f_transferable)

    # Store a non-transferable failure from project A
    f_specific = make_failure_record(
        task_id="project-a",
        error_type="SyntaxError",
        error_message="Unexpected token at line 42 in app/specific.tsx",
    )
    f_specific.transferable = False
    await backend.store_failure(f_specific)

    results = await mgr.search_cross_project(query="sharp", exclude_task_id="project-b")
    assert len(results) >= 1
    assert all(r.transferable for r in results)


@pytest.mark.asyncio
async def test_search_cross_project_excludes_own_task():
    """search_cross_project should exclude failures from the caller's task."""
    backend = InMemoryBackend()
    mgr = FailureMemoryManager(backend)

    # Failure from project A
    f_a = make_failure_record(task_id="project-a", error_message="Module not found: sharp")
    f_a.transferable = True
    await backend.store_failure(f_a)

    # Failure from project B (the caller)
    f_b = make_failure_record(task_id="project-b", error_message="Module not found: sharp")
    f_b.transferable = True
    await backend.store_failure(f_b)

    results = await mgr.search_cross_project(
        query="sharp", exclude_task_id="project-b"
    )
    for r in results:
        assert r.task_id != "project-b"


@pytest.mark.asyncio
async def test_search_cross_project_empty_memory():
    """search_cross_project should return empty list when no failures stored."""
    backend = InMemoryBackend()
    mgr = FailureMemoryManager(backend)

    results = await mgr.search_cross_project(query="anything")
    assert results == []


# ---------------------------------------------------------------------------
# Transferable flag in store_failure
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_store_failure_with_transferable_true():
    backend = InMemoryBackend()
    mgr = FailureMemoryManager(backend)

    sig = ErrorSignature(
        error_type="ModuleNotFoundError",
        error_message="Module not found: sharp",
        error_category=ErrorCategory.DEPENDENCY_ERROR,
    )
    analysis = FailureAnalysis(
        root_cause="sharp not installed",
        what_was_tried="npm run build",
        why_it_failed="sharp missing",
        suggested_fix="npm install sharp",
        confidence=0.9,
    )

    record = await mgr.store_failure(
        task_id="task-001",
        attempt_number=1,
        signature=sig,
        analysis=analysis,
        context={},
        cost=0.01,
        transferable=True,
    )
    assert record.transferable is True


@pytest.mark.asyncio
async def test_store_failure_with_transferable_false():
    backend = InMemoryBackend()
    mgr = FailureMemoryManager(backend)

    sig = ErrorSignature(
        error_type="SyntaxError",
        error_message="Unexpected token at line 42",
        error_category=ErrorCategory.RUNTIME_ERROR,
    )
    analysis = FailureAnalysis(
        root_cause="typo on line 42",
        what_was_tried="compile",
        why_it_failed="syntax error",
        suggested_fix="fix line 42",
        confidence=0.8,
    )

    record = await mgr.store_failure(
        task_id="task-001",
        attempt_number=1,
        signature=sig,
        analysis=analysis,
        context={},
        cost=0.01,
        transferable=False,
    )
    assert record.transferable is False


# ---------------------------------------------------------------------------
# Transferable keyword heuristic in Distiller
# ---------------------------------------------------------------------------


def test_is_transferable_by_keywords_generic_errors():
    """Generic errors like missing deps, port conflicts should be transferable."""
    assert Distiller._is_transferable_by_keywords("Module not found: sharp") is True
    assert Distiller._is_transferable_by_keywords("EADDRINUSE: port 3000") is True
    assert Distiller._is_transferable_by_keywords("npm ERR! missing script") is True
    assert Distiller._is_transferable_by_keywords("environment variable DATABASE_URL not set") is True
    assert Distiller._is_transferable_by_keywords("Connection refused at localhost:5432") is True


def test_is_transferable_by_keywords_specific_errors():
    """Highly specific errors should not be flagged as transferable."""
    assert Distiller._is_transferable_by_keywords("Unexpected token at line 42") is False
    assert Distiller._is_transferable_by_keywords("Cannot read property 'foo' of undefined") is False


# ---------------------------------------------------------------------------
# Distiller.distill_failure returns transferable flag
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_distill_failure_returns_transferable():
    """distill_failure should return a 3-tuple including the transferable flag."""
    llm = MockLLMProvider(canned_responses=[
        '{"root_cause": "sharp missing", "what_was_tried": "build", '
        '"why_it_failed": "no sharp", "suggested_fix": "npm install sharp", '
        '"anti_pattern": "", "confidence": 0.9, "transferable": true}'
    ])
    distiller = Distiller(llm)

    analysis, cost, transferable = await distiller.distill_failure(
        command="npm run build",
        output="",
        error="Module not found: sharp",
    )
    assert transferable is True
    assert analysis.root_cause == "sharp missing"


@pytest.mark.asyncio
async def test_distill_failure_transferable_false():
    llm = MockLLMProvider(canned_responses=[
        '{"root_cause": "typo on line 42", "what_was_tried": "compile", '
        '"why_it_failed": "syntax error", "suggested_fix": "fix line 42", '
        '"anti_pattern": "", "confidence": 0.8, "transferable": false}'
    ])
    distiller = Distiller(llm)

    analysis, cost, transferable = await distiller.distill_failure(
        command="tsc --noEmit",
        output="",
        error="Unexpected token at line 42",
    )
    assert transferable is False


@pytest.mark.asyncio
async def test_distill_failure_fallback_uses_keyword_heuristic():
    """When the LLM fails, the keyword heuristic should determine transferable."""
    # LLM that returns invalid JSON to force the fallback path
    llm = MockLLMProvider(canned_responses=["not valid json at all"])
    distiller = Distiller(llm)

    # Generic error -> transferable=True via heuristic
    analysis, cost, transferable = await distiller.distill_failure(
        command="npm install",
        output="",
        error="npm ERR! missing dependency sharp",
    )
    assert transferable is True

    # Specific error -> transferable=False via heuristic
    llm2 = MockLLMProvider(canned_responses=["not valid json"])
    distiller2 = Distiller(llm2)
    analysis2, cost2, transferable2 = await distiller2.distill_failure(
        command="tsc",
        output="",
        error="Unexpected token at line 42",
    )
    assert transferable2 is False
