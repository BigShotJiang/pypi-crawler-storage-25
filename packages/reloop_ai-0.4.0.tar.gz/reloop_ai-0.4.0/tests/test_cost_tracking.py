"""Tests for end-to-end cost tracking through the REJD pipeline.

Verifies that every LLM call (planner, distiller, judge) contributes to
attempt.cost_usd and task.total_cost_usd, and that no path returns $0
when tokens were actually consumed.
"""

from __future__ import annotations

import asyncio

import pytest

from src.core.agent import ReLoopAgent
from src.models import Task, TaskStatus
from src.providers.base import ExecutionResult
from tests.conftest import InMemoryBackend, MockLLMProvider, MockSandboxProvider


@pytest.fixture
def _mock_llm() -> MockLLMProvider:
    """LLM that returns valid JSON for distiller/planner prompts."""
    return MockLLMProvider(canned_responses=[
        # 1. Planner response (plan_next_action → generate)
        '{"strategy": "run npm install", "commands": ["npm install"], "avoid_patterns": [], "confidence": 0.8}',
        # 2. classify_error → generate (after failure)
        '{"category": "dependency_error"}',
        # 3. distill_failure → generate
        '{"root_cause": "missing dep", "what_was_tried": "npm install", '
        '"why_it_failed": "sharp not found", "suggested_fix": "npm install sharp", '
        '"anti_pattern": "", "confidence": 0.9}',
        # 4. Planner response (second attempt)
        '{"strategy": "run npm install sharp", "commands": ["npm install sharp"], "avoid_patterns": [], "confidence": 0.9}',
        # 5. distill_success → generate (after success)
        '{"approach": "installed sharp", "key_insight": "add missing deps", '
        '"failures_that_helped": ["missing dep"], "transferable": true}',
    ])


@pytest.fixture
def _mock_sandbox() -> MockSandboxProvider:
    """Sandbox: first command fails, second succeeds."""
    sb = MockSandboxProvider()
    sb.set_result("npm install", ExecutionResult(
        exit_code=1,
        stdout="",
        stderr="npm ERR! missing dependency: sharp",
    ))
    sb.set_result("npm install sharp", ExecutionResult(
        exit_code=0,
        stdout="added 12 packages",
        stderr="",
    ))
    return sb


@pytest.mark.asyncio
async def test_cost_nonzero_after_run(
    _mock_llm: MockLLMProvider,
    _mock_sandbox: MockSandboxProvider,
) -> None:
    """Run a task through ReLoopAgent and verify cost_usd > 0 everywhere."""
    backend = InMemoryBackend()
    agent = ReLoopAgent(
        memory_backend=backend,
        sandbox=_mock_sandbox,
        llm=_mock_llm,
        max_retries=3,
        max_budget_usd=1.0,
        circuit_breaker_threshold=5,
    )

    task = Task(instruction="npm install", max_retries=3, max_budget_usd=1.0)
    result = await agent.run(task)

    # Task must have completed with at least 2 attempts (1 fail + 1 success)
    assert len(result.attempts) >= 2, f"Expected >=2 attempts, got {len(result.attempts)}"

    # Every attempt must have cost_usd > 0
    for attempt in result.attempts:
        assert attempt.cost_usd > 0, (
            f"Attempt {attempt.attempt_number} has cost_usd=0; "
            f"LLM calls should always contribute cost"
        )

    # Task total must equal sum of attempt costs
    # (distiller costs are added to both attempt and task independently,
    #  so task.total_cost_usd should be >= sum of attempt costs from _execute,
    #  but in practice they should match since distiller adds to both)
    assert result.total_cost_usd > 0, "Task total_cost_usd must be > 0"

    # The MockLLMProvider returns cost_usd=0.001 per call.
    # With at least 3 LLM calls (planner + classify + distill for attempt 1,
    # planner + distill_success for attempt 2), total should be >= 0.003.
    assert result.total_cost_usd >= 0.003, (
        f"Expected total_cost_usd >= 0.003, got {result.total_cost_usd}"
    )


@pytest.mark.asyncio
async def test_cost_estimate_nonzero_with_tokens() -> None:
    """Verify _estimate_cost returns > 0 when tokens > 0, even for unknown models."""
    from src.providers.llm.openai import _estimate_cost

    # Known model
    cost = _estimate_cost("gpt-4o", prompt_tokens=1000, completion_tokens=500)
    assert cost > 0

    # Unknown model — should use fallback pricing
    cost = _estimate_cost("unknown-model-xyz", prompt_tokens=1000, completion_tokens=500)
    assert cost > 0

    # Zero tokens — should return 0
    cost = _estimate_cost("gpt-4o", prompt_tokens=0, completion_tokens=0)
    assert cost == 0.0

    # Tokens present but model pricing rounds to zero — floor kicks in
    cost = _estimate_cost("unknown-model-xyz", prompt_tokens=1, completion_tokens=0)
    assert cost > 0, "Cost must be > 0 when tokens were used"
