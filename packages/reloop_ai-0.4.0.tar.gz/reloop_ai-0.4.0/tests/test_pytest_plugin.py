"""Tests for the ReLoop pytest plugin."""

from __future__ import annotations

import pytest


pytest_plugins = ["pytester"]

# The pytester subprocess won't have our package installed, so we need
# to inject the plugin via conftest.py in the temporary directory.
_CONFTEST_SNIPPET = """
import sys, os
# Add the project root to sys.path so `src` is importable
sys.path.insert(0, os.environ.get("RELOOP_PROJECT_ROOT", ""))
from src.pytest_plugin import *
"""


@pytest.fixture
def reloop_pytester(pytester: pytest.Pytester, monkeypatch) -> pytest.Pytester:
    """Pytester with the ReLoop plugin loaded via conftest."""
    import os
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    monkeypatch.setenv("RELOOP_PROJECT_ROOT", project_root)
    pytester.makeconftest(_CONFTEST_SNIPPET)
    return pytester


def test_plugin_does_nothing_without_flag(reloop_pytester: pytest.Pytester) -> None:
    """Without --reloop, the plugin should be completely inert."""
    reloop_pytester.makepyfile(
        """
        def test_pass():
            assert True

        def test_fail():
            assert False
        """
    )
    result = reloop_pytester.runpytest("-v")
    result.assert_outcomes(passed=1, failed=1)
    # Should NOT contain ReLoop summary output
    assert "ReLoop failure memory summary" not in result.stdout.str()


def test_plugin_captures_failure_with_flag(reloop_pytester: pytest.Pytester, tmp_path) -> None:
    """With --reloop, test failures should be captured into memory."""
    db_path = str(tmp_path / "test_memory.db")
    reloop_pytester.makepyfile(
        """
        def test_always_fails():
            assert 1 == 2, "expected equality"
        """
    )
    result = reloop_pytester.runpytest(
        "--reloop",
        "--reloop-backend=sqlite",
        f"--reloop-sqlite-path={db_path}",
        "-v",
    )
    result.assert_outcomes(failed=1)
    # The terminal summary should mention ReLoop
    output = result.stdout.str()
    assert "ReLoop" in output


def test_plugin_passing_tests_no_capture(reloop_pytester: pytest.Pytester, tmp_path) -> None:
    """Passing tests should not trigger failure capture."""
    db_path = str(tmp_path / "test_memory.db")
    reloop_pytester.makepyfile(
        """
        def test_passes():
            assert True
        """
    )
    result = reloop_pytester.runpytest(
        "--reloop",
        "--reloop-backend=sqlite",
        f"--reloop-sqlite-path={db_path}",
        "-v",
    )
    result.assert_outcomes(passed=1)


def test_plugin_registers_options(reloop_pytester: pytest.Pytester) -> None:
    """The --reloop flag should be registered."""
    result = reloop_pytester.runpytest("--help")
    output = result.stdout.str()
    assert "--reloop" in output


def test_plugin_never_crashes_pytest(reloop_pytester: pytest.Pytester) -> None:
    """Even with a bad backend config, plugin must not crash pytest."""
    reloop_pytester.makepyfile(
        """
        def test_fail():
            raise ValueError("boom")
        """
    )
    # Use an invalid redis URL -- plugin should fail silently
    result = reloop_pytester.runpytest(
        "--reloop",
        "--reloop-backend=redis",
        "--reloop-redis-url=redis://nonexistent:9999",
        "-v",
    )
    # pytest itself should still run and report the failure
    result.assert_outcomes(failed=1)
