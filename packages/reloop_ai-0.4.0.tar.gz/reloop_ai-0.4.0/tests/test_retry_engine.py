"""Tests for the real RetryEngine from src/core/retry.py."""

from __future__ import annotations

import pytest

from src.core.memory import FailureMemoryManager
from src.core.retry import RetryEngine
from src.models import (
    Attempt,
    AttemptStatus,
    CircuitBreakerState,
    ErrorCategory,
    ErrorSignature,
    StepResult,
    Task,
)
from tests.conftest import InMemoryBackend, MockLLMProvider, make_task


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def backend():
    return InMemoryBackend()


@pytest.fixture
def llm():
    return MockLLMProvider()


@pytest.fixture
def memory(backend, llm):
    return FailureMemoryManager(backend, llm=llm)


@pytest.fixture
def engine(memory):
    return RetryEngine(
        memory=memory,
        max_retries=5,
        max_budget_usd=1.0,
        circuit_breaker_threshold=3,
    )


# ---------------------------------------------------------------------------
# should_retry tests
# ---------------------------------------------------------------------------


class TestShouldRetry:
    def test_retry_allowed_first_attempt(self, engine):
        task = make_task(max_retries=5)
        task.current_attempt = 1
        assert engine.should_retry(task) is True

    def test_retry_denied_max_retries(self, engine):
        task = make_task(max_retries=5)
        task.current_attempt = 5
        assert engine.should_retry(task) is False

    def test_retry_denied_budget_exceeded(self, engine):
        task = make_task(max_budget_usd=0.50)
        task.current_attempt = 1
        task.total_cost_usd = 0.60
        assert engine.should_retry(task) is False

    def test_retry_allowed_under_budget(self, engine):
        task = make_task(max_budget_usd=1.0)
        task.current_attempt = 1
        task.total_cost_usd = 0.10
        assert engine.should_retry(task) is True

    def test_retry_uses_min_of_task_and_engine_retries(self):
        """Engine max_retries=5, task max_retries=2 => effective=2."""
        backend = InMemoryBackend()
        llm = MockLLMProvider()
        mem = FailureMemoryManager(backend, llm=llm)
        engine = RetryEngine(memory=mem, max_retries=5, max_budget_usd=1.0)
        task = make_task(max_retries=2)
        task.current_attempt = 2
        assert engine.should_retry(task) is False

    def test_retry_uses_min_of_task_and_engine_budget(self):
        """Engine budget=1.0, task budget=0.20 => effective=0.20."""
        backend = InMemoryBackend()
        llm = MockLLMProvider()
        mem = FailureMemoryManager(backend, llm=llm)
        engine = RetryEngine(memory=mem, max_retries=5, max_budget_usd=1.0)
        task = make_task(max_budget_usd=0.20)
        task.current_attempt = 1
        task.total_cost_usd = 0.25
        assert engine.should_retry(task) is False


# ---------------------------------------------------------------------------
# Circuit breaker tests
# ---------------------------------------------------------------------------


class TestCircuitBreaker:
    def _make_failed_attempt(self, attempt_number: int, error_text: str = "error") -> Attempt:
        attempt = Attempt(attempt_number=attempt_number, status=AttemptStatus.FAILED)
        step = StepResult(
            step_number=1, description="run", command="test",
            status=AttemptStatus.FAILED, error=error_text,
        )
        attempt.steps.append(step)
        attempt.failure_record_id = f"rec-{attempt_number}"
        return attempt

    def test_circuit_closed_few_attempts(self, engine):
        """Circuit stays closed when below threshold."""
        task = make_task()
        task.current_attempt = 1
        task.attempts = [self._make_failed_attempt(1)]
        task.metadata["attempt_1_error_hash"] = "abc123"
        assert engine.should_retry(task) is True

    def test_circuit_open_repeated_same_error(self, engine):
        """Circuit opens after 3 identical error hashes."""
        task = make_task()
        task.current_attempt = 3
        for i in range(1, 4):
            task.attempts.append(self._make_failed_attempt(i))
            task.metadata[f"attempt_{i}_error_hash"] = "same_hash"
        assert engine.should_retry(task) is False

    def test_circuit_closed_different_errors(self, engine):
        """Circuit stays closed when errors differ."""
        task = make_task()
        task.current_attempt = 3
        for i in range(1, 4):
            task.attempts.append(self._make_failed_attempt(i))
            task.metadata[f"attempt_{i}_error_hash"] = f"hash_{i}"
        assert engine.should_retry(task) is True

    def test_get_circuit_breaker_state_open(self, engine):
        task = make_task()
        task.current_attempt = 3
        for i in range(1, 4):
            task.attempts.append(self._make_failed_attempt(i))
            task.metadata[f"attempt_{i}_error_hash"] = "same_hash"
        state = engine.get_circuit_breaker_state(task)
        assert state.is_open is True
        assert state.consecutive_same_error == 3
        assert state.error_hash == "same_hash"

    def test_get_circuit_breaker_state_closed(self, engine):
        task = make_task()
        task.current_attempt = 1
        state = engine.get_circuit_breaker_state(task)
        assert state.is_open is False
        assert state.consecutive_same_error == 0


# ---------------------------------------------------------------------------
# prepare_retry_context tests
# ---------------------------------------------------------------------------


class TestPrepareRetryContext:
    @pytest.mark.asyncio
    async def test_returns_expected_keys(self, engine):
        task = make_task()
        task.current_attempt = 1
        error = ErrorSignature(
            error_type="ModuleNotFoundError",
            error_category=ErrorCategory.DEPENDENCY_ERROR,
            error_message="No module named 'sharp'",
        )
        ctx = await engine.prepare_retry_context(task, error)
        assert "recalled_memories" in ctx
        assert "anti_patterns" in ctx
        assert "raw_failures" in ctx
        assert "error_signature" in ctx
        assert "attempt_number" in ctx
        assert "total_cost_usd" in ctx

    @pytest.mark.asyncio
    async def test_recalled_memories_from_backend(self, engine, backend, memory):
        """When backend has a matching failure, it appears in context."""
        from tests.conftest import make_failure_record
        record = make_failure_record(error_type="ModuleNotFoundError")
        await backend.store_failure(record)

        task = make_task()
        task.current_attempt = 1
        error = ErrorSignature(
            error_type="ModuleNotFoundError",
            error_category=ErrorCategory.DEPENDENCY_ERROR,
            error_message="No module named 'sharp'",
        )
        ctx = await engine.prepare_retry_context(task, error)
        assert len(ctx["raw_failures"]) > 0


# ---------------------------------------------------------------------------
# Recommendation helper tests
# ---------------------------------------------------------------------------


class TestRecommendation:
    def test_dependency_recommendation(self):
        rec = RetryEngine._recommendation_for_error_type("ModuleNotFoundError")
        assert "missing package" in rec.lower() or "pip install" in rec.lower()

    def test_permission_recommendation(self):
        rec = RetryEngine._recommendation_for_error_type("PermissionError")
        assert "permission" in rec.lower()

    def test_timeout_recommendation(self):
        rec = RetryEngine._recommendation_for_error_type("TimeoutError")
        assert "timeout" in rec.lower()

    def test_unknown_recommendation(self):
        rec = RetryEngine._recommendation_for_error_type("SomethingWeird")
        assert "fundamental issue" in rec.lower()
