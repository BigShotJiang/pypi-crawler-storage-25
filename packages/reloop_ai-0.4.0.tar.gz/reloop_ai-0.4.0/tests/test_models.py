"""Tests for ReLoop data models (src/models.py)."""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone

import pytest

from src.models import (
    Attempt,
    AttemptStatus,
    Checkpoint,
    CreateTaskRequest,
    ErrorCategory,
    ErrorSignature,
    FailureAnalysis,
    FailureRecord,
    MemoryStatsResponse,
    StepResult,
    SuccessRecord,
    Task,
    TaskResponse,
    TaskStatus,
    TimelineEvent,
    TimelineEventType,
)


# ---------------------------------------------------------------------------
# ErrorCategory
# ---------------------------------------------------------------------------

class TestErrorCategory:
    def test_all_expected_values_exist(self):
        expected = {
            "dependency_error",
            "runtime_error",
            "config_error",
            "type_error",
            "network_error",
            "permission_error",
            "timeout_error",
            "unknown",
        }
        actual = {e.value for e in ErrorCategory}
        assert actual == expected

    def test_is_string_enum(self):
        assert isinstance(ErrorCategory.DEPENDENCY_ERROR, str)
        assert ErrorCategory.DEPENDENCY_ERROR == "dependency_error"

    def test_unknown_is_default_sentinel(self):
        sig = ErrorSignature(error_type="SomeError", error_message="oops")
        assert sig.error_category == ErrorCategory.UNKNOWN


# ---------------------------------------------------------------------------
# ErrorSignature
# ---------------------------------------------------------------------------

class TestErrorSignature:
    def test_hash_generated_automatically(self):
        sig = ErrorSignature(error_type="TypeError", error_message="cannot read property")
        assert sig.error_hash != ""
        assert len(sig.error_hash) == 16

    def test_same_error_produces_same_hash(self):
        sig1 = ErrorSignature(error_type="TypeError", error_message="cannot read property")
        sig2 = ErrorSignature(error_type="TypeError", error_message="cannot read property")
        assert sig1.error_hash == sig2.error_hash

    def test_different_message_produces_different_hash(self):
        sig1 = ErrorSignature(error_type="TypeError", error_message="foo")
        sig2 = ErrorSignature(error_type="TypeError", error_message="bar")
        assert sig1.error_hash != sig2.error_hash

    def test_hash_is_sha256_prefix(self):
        error_type = "ModuleNotFoundError"
        error_message = "Module not found: sharp"
        raw = f"{error_type}:{error_message}"
        expected = hashlib.sha256(raw.encode()).hexdigest()[:16]
        sig = ErrorSignature(error_type=error_type, error_message=error_message)
        assert sig.error_hash == expected

    def test_custom_hash_not_overwritten(self):
        sig = ErrorSignature(
            error_type="TypeError",
            error_message="oops",
            error_hash="customhash12345a",
        )
        assert sig.error_hash == "customhash12345a"

    def test_code_context_defaults_to_empty(self):
        sig = ErrorSignature(error_type="E", error_message="msg")
        assert sig.code_context == ""

    def test_all_error_categories_accepted(self):
        for cat in ErrorCategory:
            sig = ErrorSignature(
                error_type="Err",
                error_message="msg",
                error_category=cat,
            )
            assert sig.error_category == cat


# ---------------------------------------------------------------------------
# FailureRecord
# ---------------------------------------------------------------------------

class TestFailureRecord:
    def _make(self, **kwargs) -> FailureRecord:
        defaults = dict(
            task_id="task-abc",
            attempt_number=1,
            signature=ErrorSignature(
                error_type="ModuleNotFoundError",
                error_message="Module not found: sharp",
                error_category=ErrorCategory.DEPENDENCY_ERROR,
            ),
            analysis=FailureAnalysis(
                root_cause="sharp not installed",
                what_was_tried="npm run build",
                why_it_failed="sharp is required by next/image",
                suggested_fix="npm install sharp",
            ),
        )
        defaults.update(kwargs)
        return FailureRecord(**defaults)

    def test_id_auto_generated(self):
        r = self._make()
        assert r.id != ""
        assert len(r.id) == 12

    def test_unique_ids(self):
        r1 = self._make()
        r2 = self._make()
        assert r1.id != r2.id

    def test_timestamp_set_automatically(self):
        r = self._make()
        assert r.timestamp is not None
        assert r.timestamp.tzinfo is not None

    def test_default_cost_is_zero(self):
        r = self._make()
        assert r.cost_usd == 0.0

    def test_custom_cost(self):
        r = self._make(cost_usd=0.05)
        assert r.cost_usd == 0.05

    def test_context_defaults_to_empty_dict(self):
        r = self._make()
        assert r.context == {}

    def test_embedding_defaults_to_empty_list(self):
        r = self._make()
        assert r.embedding == []

    def test_topics_defaults_to_empty_list(self):
        r = self._make()
        assert r.topics == []

    def test_serialization_roundtrip(self):
        r = self._make(cost_usd=0.02)
        data = r.model_dump()
        restored = FailureRecord.model_validate(data)
        assert restored.id == r.id
        assert restored.task_id == r.task_id
        assert restored.signature.error_hash == r.signature.error_hash
        assert restored.analysis.suggested_fix == r.analysis.suggested_fix
        assert restored.cost_usd == r.cost_usd

    def test_json_roundtrip(self):
        r = self._make()
        json_str = r.model_dump_json()
        restored = FailureRecord.model_validate_json(json_str)
        assert restored.id == r.id


# ---------------------------------------------------------------------------
# SuccessRecord
# ---------------------------------------------------------------------------

class TestSuccessRecord:
    def test_id_auto_generated(self):
        s = SuccessRecord(task_id="t1", attempt_number=3)
        assert s.id != ""

    def test_solution_defaults_empty(self):
        s = SuccessRecord(task_id="t1", attempt_number=1)
        assert s.solution == {}

    def test_custom_solution(self):
        s = SuccessRecord(
            task_id="t1",
            attempt_number=2,
            solution={"approach": "installed sharp"},
        )
        assert s.solution["approach"] == "installed sharp"


# ---------------------------------------------------------------------------
# Task
# ---------------------------------------------------------------------------

class TestTask:
    def test_id_auto_generated(self):
        t = Task(instruction="do something")
        assert t.id != ""
        assert len(t.id) == 12

    def test_default_status_is_pending(self):
        t = Task(instruction="do something")
        assert t.status == TaskStatus.PENDING

    def test_default_retries(self):
        t = Task(instruction="do something")
        assert t.max_retries == 5

    def test_default_budget(self):
        t = Task(instruction="do something")
        assert t.max_budget_usd == 1.0

    def test_default_cost_is_zero(self):
        t = Task(instruction="do something")
        assert t.total_cost_usd == 0.0

    def test_attempts_default_empty(self):
        t = Task(instruction="do something")
        assert t.attempts == []

    def test_current_attempt_default_zero(self):
        t = Task(instruction="do something")
        assert t.current_attempt == 0

    def test_completed_at_default_none(self):
        t = Task(instruction="do something")
        assert t.completed_at is None

    def test_result_default_none(self):
        t = Task(instruction="do something")
        assert t.result is None


# ---------------------------------------------------------------------------
# TaskResponse.from_task
# ---------------------------------------------------------------------------

class TestTaskResponseFromTask:
    def test_basic_conversion(self):
        task = Task(instruction="fix the project", max_retries=3, max_budget_usd=0.5)
        response = TaskResponse.from_task(task)
        assert response.id == task.id
        assert response.instruction == task.instruction
        assert response.status == TaskStatus.PENDING
        assert response.current_attempt == 0
        assert response.total_attempts == 0
        assert response.total_cost_usd == 0.0
        assert response.created_at == task.created_at
        assert response.completed_at is None
        assert response.result is None

    def test_total_attempts_reflects_attempts_list(self):
        task = Task(instruction="test")
        task.attempts = [
            Attempt(attempt_number=1, status=AttemptStatus.FAILED),
            Attempt(attempt_number=2, status=AttemptStatus.FAILED),
        ]
        response = TaskResponse.from_task(task)
        assert response.total_attempts == 2

    def test_completed_task(self):
        now = datetime.now(timezone.utc)
        task = Task(instruction="test")
        task.status = TaskStatus.SUCCEEDED
        task.completed_at = now
        task.result = "success"
        task.total_cost_usd = 0.03
        response = TaskResponse.from_task(task)
        assert response.status == TaskStatus.SUCCEEDED
        assert response.completed_at == now
        assert response.result == "success"
        assert response.total_cost_usd == 0.03


# ---------------------------------------------------------------------------
# Checkpoint
# ---------------------------------------------------------------------------

class TestCheckpoint:
    def test_defaults(self):
        cp = Checkpoint(task_id="t1", attempt_number=2)
        assert cp.id != ""
        assert cp.step_number == 0
        assert cp.sandbox_snapshot_id == ""
        assert cp.reversible is True
        assert cp.description == ""

    def test_created_at_set(self):
        cp = Checkpoint(task_id="t1", attempt_number=1)
        assert cp.created_at is not None


# ---------------------------------------------------------------------------
# FailureAnalysis constraints
# ---------------------------------------------------------------------------

class TestFailureAnalysis:
    def test_confidence_defaults(self):
        fa = FailureAnalysis(
            root_cause="x",
            what_was_tried="y",
            why_it_failed="z",
            suggested_fix="w",
        )
        assert fa.confidence == 0.8

    def test_confidence_clamped_lower(self):
        with pytest.raises(Exception):
            FailureAnalysis(
                root_cause="x",
                what_was_tried="y",
                why_it_failed="z",
                suggested_fix="w",
                confidence=-0.1,
            )

    def test_confidence_clamped_upper(self):
        with pytest.raises(Exception):
            FailureAnalysis(
                root_cause="x",
                what_was_tried="y",
                why_it_failed="z",
                suggested_fix="w",
                confidence=1.1,
            )


# ---------------------------------------------------------------------------
# Timeline events
# ---------------------------------------------------------------------------

class TestTimelineEvent:
    def test_defaults(self):
        event = TimelineEvent(
            task_id="t1",
            event_type=TimelineEventType.TASK_CREATED,
        )
        assert event.id != ""
        assert event.attempt_number == 0
        assert event.step_number == 0
        assert event.message == ""
        assert event.data == {}

    def test_all_event_types_exist(self):
        expected = {
            "task.created",
            "attempt.started",
            "step.started",
            "step.completed",
            "step.failed",
            "memory.recalled",
            "memory.stored",
            "checkpoint.created",
            "checkpoint.restored",
            "attempt.succeeded",
            "attempt.failed",
            "circuit_breaker.open",
            "task.completed",
            "task.abandoned",
            "prediction",
        }
        actual = {e.value for e in TimelineEventType}
        assert actual == expected
