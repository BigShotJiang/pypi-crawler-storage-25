"""Tests for the OpenTelemetry tracing module."""

from __future__ import annotations

import importlib
import sys
from unittest import mock

import pytest

from src.telemetry import (
    _NoOpSpan,
    _NoOpTracer,
    configure_tracing,
    get_tracer,
    is_configured,
    reset,
)


@pytest.fixture(autouse=True)
def _reset_telemetry():
    """Reset telemetry state before each test."""
    reset()
    yield
    reset()


class TestNoOpTracer:
    """Verify the no-op tracer works correctly when OTel is missing."""

    def test_noop_tracer_returns_span(self) -> None:
        tracer = _NoOpTracer()
        span = tracer.start_as_current_span("test.span")
        assert isinstance(span, _NoOpSpan)

    def test_noop_tracer_start_span(self) -> None:
        tracer = _NoOpTracer()
        span = tracer.start_span("test.span")
        assert isinstance(span, _NoOpSpan)

    def test_noop_span_context_manager(self) -> None:
        span = _NoOpSpan()
        with span as s:
            assert s is span

    def test_noop_span_methods_dont_raise(self) -> None:
        span = _NoOpSpan()
        span.set_attribute("key", "value")
        span.set_status("ok")
        span.record_exception(ValueError("test"))
        span.end()


class TestGetTracer:
    """Test get_tracer() behavior."""

    def test_returns_noop_when_otel_missing(self) -> None:
        # Simulate OTel not being installed
        with mock.patch.dict(sys.modules, {
            "opentelemetry": None,
            "opentelemetry.trace": None,
            "opentelemetry.sdk.trace": None,
        }):
            reset()
            tracer = get_tracer()
            assert isinstance(tracer, _NoOpTracer)

    def test_get_tracer_returns_consistent_instance(self) -> None:
        tracer1 = get_tracer()
        tracer2 = get_tracer()
        assert tracer1 is tracer2

    def test_span_from_get_tracer_works(self) -> None:
        tracer = get_tracer()
        span = tracer.start_as_current_span("reloop.retrieve")
        # Should work as context manager
        with span:
            pass


class TestConfigureTracing:
    """Test configure_tracing() behavior."""

    def test_returns_false_when_otel_missing(self) -> None:
        with mock.patch.dict(sys.modules, {
            "opentelemetry": None,
            "opentelemetry.trace": None,
            "opentelemetry.sdk.trace": None,
        }):
            reset()
            result = configure_tracing(service_name="test")
            assert result is False
            assert not is_configured()

    def test_configure_with_otel_available(self) -> None:
        """If OTel is installed, configure_tracing should succeed."""
        try:
            import opentelemetry  # noqa: F401
            import opentelemetry.sdk.trace  # noqa: F401
        except ImportError:
            pytest.skip("OpenTelemetry not installed")

        result = configure_tracing(service_name="reloop-test")
        assert result is True
        assert is_configured()

        tracer = get_tracer()
        assert not isinstance(tracer, _NoOpTracer)

    def test_spans_created_when_otel_available(self) -> None:
        """Verify actual spans are created when OTel is configured."""
        try:
            import opentelemetry  # noqa: F401
            from opentelemetry.sdk.trace import TracerProvider  # noqa: F401
            from opentelemetry.sdk.trace.export import (
                SimpleSpanProcessor,
            )
            from opentelemetry.sdk.trace.export.in_memory import (
                InMemorySpanExporter,
            )
        except ImportError:
            pytest.skip("OpenTelemetry not installed")

        exporter = InMemorySpanExporter()
        configure_tracing(service_name="reloop-test", exporter=exporter)

        tracer = get_tracer()
        with tracer.start_as_current_span("reloop.test") as span:
            span.set_attribute("test.key", "test.value")

        spans = exporter.get_finished_spans()
        assert len(spans) == 1
        assert spans[0].name == "reloop.test"
        assert spans[0].attributes.get("test.key") == "test.value"


class TestIsConfigured:
    """Test is_configured() state tracking."""

    def test_not_configured_by_default(self) -> None:
        assert not is_configured()

    def test_configured_after_setup(self) -> None:
        try:
            import opentelemetry  # noqa: F401
        except ImportError:
            pytest.skip("OpenTelemetry not installed")

        configure_tracing()
        assert is_configured()

    def test_reset_clears_configured(self) -> None:
        try:
            import opentelemetry  # noqa: F401
        except ImportError:
            pytest.skip("OpenTelemetry not installed")

        configure_tracing()
        assert is_configured()
        reset()
        assert not is_configured()
