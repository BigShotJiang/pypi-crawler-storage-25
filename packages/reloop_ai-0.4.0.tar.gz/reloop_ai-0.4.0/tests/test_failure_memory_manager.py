"""Tests for the FailureMemoryManager (src/core/memory.py)."""

from __future__ import annotations

import pytest

from src.core.memory import FailureMemoryManager
from src.models import (
    ErrorCategory,
    ErrorSignature,
    FailureAnalysis,
)
from tests.conftest import InMemoryBackend, MockLLMProvider, make_failure_record


# ---------------------------------------------------------------------------
# store_failure
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_store_failure_creates_record():
    backend = InMemoryBackend()
    llm = MockLLMProvider()
    mgr = FailureMemoryManager(backend, llm=llm)

    sig = ErrorSignature(
        error_type="ModuleNotFoundError",
        error_message="Module not found: sharp",
        error_category=ErrorCategory.DEPENDENCY_ERROR,
    )
    analysis = FailureAnalysis(
        root_cause="sharp not installed",
        what_was_tried="npm run build",
        why_it_failed="sharp is missing",
        suggested_fix="npm install sharp",
        confidence=0.9,
    )

    record = await mgr.store_failure(
        task_id="task-001",
        attempt_number=1,
        signature=sig,
        analysis=analysis,
        context={"instruction": "build project"},
        cost=0.01,
    )

    assert record.task_id == "task-001"
    assert record.attempt_number == 1
    assert record.signature.error_type == "ModuleNotFoundError"

    # Verify it was stored in the backend
    retrieved = await backend.get_failure(record.id)
    assert retrieved is not None
    assert retrieved.id == record.id


@pytest.mark.asyncio
async def test_store_failure_generates_embedding():
    backend = InMemoryBackend()
    llm = MockLLMProvider()
    mgr = FailureMemoryManager(backend, llm=llm)

    sig = ErrorSignature(error_type="TypeError", error_message="bad type")
    analysis = FailureAnalysis(
        root_cause="type mismatch",
        what_was_tried="compile",
        why_it_failed="wrong type",
        suggested_fix="fix types",
        confidence=0.8,
    )

    record = await mgr.store_failure(
        task_id="t1", attempt_number=1, signature=sig,
        analysis=analysis, context={}, cost=0.0,
    )

    # MockLLMProvider.embed returns a list of floats
    assert len(record.embedding) > 0


@pytest.mark.asyncio
async def test_store_failure_without_llm():
    backend = InMemoryBackend()
    mgr = FailureMemoryManager(backend, llm=None)

    sig = ErrorSignature(error_type="TypeError", error_message="bad type")
    analysis = FailureAnalysis(
        root_cause="type mismatch",
        what_was_tried="compile",
        why_it_failed="wrong type",
        suggested_fix="fix types",
        confidence=0.8,
    )

    record = await mgr.store_failure(
        task_id="t1", attempt_number=1, signature=sig,
        analysis=analysis, context={}, cost=0.0,
    )

    # No LLM means local fallback embedding (1536-dim deterministic vector)
    assert len(record.embedding) == 1536


# ---------------------------------------------------------------------------
# store_success
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_store_success_creates_record():
    backend = InMemoryBackend()
    mgr = FailureMemoryManager(backend)

    record = await mgr.store_success(
        task_id="task-002",
        attempt_number=3,
        solution={"approach": "installed sharp"},
        learning={"failure_count": 2},
        metrics={"total_attempts": 3, "total_cost_usd": 0.05},
    )

    assert record.task_id == "task-002"
    assert record.attempt_number == 3
    stats = await backend.get_stats()
    assert stats.total_successes == 1


# ---------------------------------------------------------------------------
# recall
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_recall_finds_similar_failures():
    backend = InMemoryBackend()
    llm = MockLLMProvider()
    mgr = FailureMemoryManager(backend, llm=llm)

    # Pre-seed some failures
    f1 = make_failure_record(
        error_type="ModuleNotFoundError",
        error_message="Module not found: sharp",
    )
    f2 = make_failure_record(
        error_type="TypeError",
        error_message="Type mismatch in component",
    )
    await backend.store_failure(f1)
    await backend.store_failure(f2)

    results = await mgr.recall("ModuleNotFoundError", "Module not found: sharp")
    assert len(results) >= 1
    assert all(r.signature.error_type == "ModuleNotFoundError" for r in results)


@pytest.mark.asyncio
async def test_recall_returns_empty_for_no_match():
    backend = InMemoryBackend()
    mgr = FailureMemoryManager(backend)

    results = await mgr.recall("NetworkError", "timeout")
    assert results == []


# ---------------------------------------------------------------------------
# build_memory_context
# ---------------------------------------------------------------------------

def test_build_memory_context_empty():
    backend = InMemoryBackend()
    mgr = FailureMemoryManager(backend)
    assert mgr.build_memory_context([]) == ""


def test_build_memory_context_with_failures():
    backend = InMemoryBackend()
    mgr = FailureMemoryManager(backend)

    failures = [
        make_failure_record(
            error_type="ModuleNotFoundError",
            error_message="Module not found: sharp",
            suggested_fix="npm install sharp",
        ),
    ]

    context = mgr.build_memory_context(failures)
    assert "ModuleNotFoundError" in context
    assert "sharp" in context
    assert "npm install sharp" in context
    assert "Previous failures" in context


# ---------------------------------------------------------------------------
# get_stats
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_get_stats_delegates_to_backend():
    backend = InMemoryBackend()
    mgr = FailureMemoryManager(backend)

    await backend.store_failure(make_failure_record())

    stats = await mgr.get_stats()
    assert stats.total_failures == 1


# ---------------------------------------------------------------------------
# predict_likely_failures
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_predict_likely_failures_returns_predictions():
    backend = InMemoryBackend()
    mgr = FailureMemoryManager(backend)

    # Store failures that match the instruction text
    f = make_failure_record(
        error_type="ModuleNotFoundError",
        error_message="Module not found: sharp",
    )
    # Override root_cause to contain "sharp" for search match
    f.analysis.root_cause = "sharp package missing"
    await backend.store_failure(f)

    predictions = await mgr.predict_likely_failures(
        instruction="Fix sharp module issue",
    )
    assert isinstance(predictions, list)
    # The search for "Fix sharp module issue" should match "sharp" in root_cause
    if predictions:
        assert predictions[0]["error_type"] == "ModuleNotFoundError"
        assert 0.0 <= predictions[0]["prediction_score"] <= 1.0


@pytest.mark.asyncio
async def test_predict_likely_failures_empty_memory():
    backend = InMemoryBackend()
    mgr = FailureMemoryManager(backend)

    predictions = await mgr.predict_likely_failures(instruction="build project")
    assert predictions == []
