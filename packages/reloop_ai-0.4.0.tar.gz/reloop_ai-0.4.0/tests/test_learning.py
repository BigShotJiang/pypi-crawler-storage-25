"""A/B learning tests — does failure memory actually reduce attempts?

These tests compare two agents running an identical deterministic task:
  - Agent A: starts with an EMPTY memory backend (no past knowledge).
  - Agent B: starts with a PRE-SEEDED memory backend (prior failure records).

The scenario mimics the hackathon demo: a broken Next.js project with multiple
fixable bugs.  Without memory, the LLM cannot consult past failures and must
discover each fix from scratch.  With memory, the loop immediately surfaces the
known fix for the first error and can apply it directly.

Because we are testing control-flow (not real LLM intelligence), the mock LLM
provider returns fix commands based on whether relevant failure records appear in
the memory query result.  This makes the "improvement" fully deterministic and
verifiable.
"""

from __future__ import annotations

from typing import Any, AsyncIterator

import pytest

from src.models import (
    ErrorCategory,
    ErrorSignature,
    FailureAnalysis,
    FailureRecord,
    SuccessRecord,
    Task,
    TaskStatus,
)
from src.providers.base import ExecutionResult, LLMProvider, LLMResponse
from tests.conftest import (
    InMemoryBackend,
    MockSandboxProvider,
    make_failure_record,
)


# ---------------------------------------------------------------------------
# Memory-aware REJD loop
#
# This variant actually consults the memory backend before choosing the next
# command, reflecting the real REJD "Retrieve" step.
# ---------------------------------------------------------------------------

class MemoryAwareREJDLoop:
    """REJD loop that selects fix commands based on recalled memory.

    The scenario:
    - The project has two bugs: missing `sharp` dep and wrong port.
    - Without memory, the agent tries generic commands and fails repeatedly.
    - With memory, the agent immediately identifies the right fix.

    Command selection logic (deterministic):
      - If memory contains a fix for "sharp" → use the correct npm install command
      - If memory contains a fix for "port" → use the correct port-change command
      - Otherwise → use a generic failing command
    """

    def __init__(
        self,
        memory: InMemoryBackend,
        sandbox: MockSandboxProvider,
        llm: LLMProvider,
        *,
        max_retries: int = 10,
        max_budget_usd: float = 5.0,
    ) -> None:
        self.memory = memory
        self.sandbox = sandbox
        self.llm = llm
        self.max_retries = max_retries
        self.max_budget_usd = max_budget_usd
        self.attempt_log: list[dict[str, Any]] = []

    async def _select_command(self, task_id: str, step_description: str) -> str:
        """Return the best command based on recalled memory."""
        similar = await self.memory.get_failures_for_task(task_id)
        known_fixes = {f.analysis.suggested_fix for f in similar}

        # If we know about the sharp fix, use it
        if any("sharp" in fix for fix in known_fixes):
            return "npm install sharp && npm run build"

        # If we know about the port fix, use it
        if any("3001" in fix or "port" in fix.lower() for fix in known_fixes):
            return "sed -i 's/port: 3000/port: 3001/' next.config.js && npm run dev"

        # No memory → generic failing attempt
        return "npm run build"

    async def run(self, task: Task) -> "MemoryAwareREJDResult":
        sandbox_id = await self.sandbox.create()
        total_cost = 0.0

        # Simulate scenario: first two attempts fail without memory,
        # but with memory the correct command is selected immediately.

        scenario = DemoScenario()

        for attempt_num in range(1, self.max_retries + 1):
            if total_cost >= self.max_budget_usd:
                break

            # RETRIEVE
            past_failures = await self.memory.get_failures_for_task(task.id)
            known_fixes = {f.analysis.suggested_fix for f in past_failures}

            # SELECT command (memory-informed or naive)
            cmd = await self._select_command(task.id, task.instruction)

            # EXECUTE
            exec_result = scenario.execute(cmd)
            total_cost += 0.001

            log_entry = {
                "attempt": attempt_num,
                "command": cmd,
                "success": exec_result.success,
                "known_fixes_count": len(known_fixes),
            }
            self.attempt_log.append(log_entry)

            # JUDGE + DISTILL
            if exec_result.success:
                task.status = TaskStatus.SUCCEEDED
                await self.memory.store_success(
                    SuccessRecord(
                        task_id=task.id,
                        attempt_number=attempt_num,
                        solution={"command": cmd},
                        learning={"failure_count": len(past_failures)},
                    )
                )
                return MemoryAwareREJDResult(
                    success=True,
                    attempts=attempt_num,
                    total_cost=total_cost,
                )

            # Store failure in memory for future RETRIEVE steps
            sig = ErrorSignature(
                error_type="BuildError",
                error_message=exec_result.stderr,
                error_category=ErrorCategory.DEPENDENCY_ERROR
                if "sharp" in exec_result.stderr
                else ErrorCategory.CONFIG_ERROR,
            )
            fix = "npm install sharp" if "sharp" in exec_result.stderr else "Change port to 3001"
            failure = FailureRecord(
                task_id=task.id,
                attempt_number=attempt_num,
                signature=sig,
                analysis=FailureAnalysis(
                    root_cause=exec_result.stderr,
                    what_was_tried=cmd,
                    why_it_failed=exec_result.stderr,
                    suggested_fix=fix,
                    confidence=0.9,
                ),
                cost_usd=0.001,
            )
            await self.memory.store_failure(failure)

        task.status = TaskStatus.ABANDONED
        return MemoryAwareREJDResult(
            success=False,
            attempts=self.max_retries,
            total_cost=total_cost,
        )


class MemoryAwareREJDResult:
    def __init__(self, success: bool, attempts: int, total_cost: float) -> None:
        self.success = success
        self.attempts = attempts
        self.total_cost = total_cost


class DemoScenario:
    """Deterministic execution model for the demo broken Next.js project.

    Command resolution rules:
    - 'npm install sharp' in command → sharp error resolved
    - correct port change in command → port error resolved
    - 'npm run build' alone → fails with "Module not found: sharp"
    - correct npm install + build → success
    """

    def execute(self, command: str) -> ExecutionResult:
        cmd = command.lower()

        if "npm install sharp" in cmd and "npm run build" in cmd:
            return ExecutionResult(exit_code=0, stdout="Build successful", stderr="")

        if "npm install sharp" in cmd:
            return ExecutionResult(
                exit_code=0, stdout="sharp installed", stderr=""
            )

        if "3001" in cmd or ("sed" in cmd and "port" in cmd):
            return ExecutionResult(exit_code=0, stdout="Server started on port 3001", stderr="")

        # Default: build fails due to missing sharp
        return ExecutionResult(
            exit_code=1,
            stdout="",
            stderr="Module not found: sharp",
        )


# ---------------------------------------------------------------------------
# Mock LLM (dummy — not driving decisions in this suite)
# ---------------------------------------------------------------------------

class DummyLLM(LLMProvider):
    async def generate(self, prompt: str, system: str = "", temperature: float = 0.3) -> LLMResponse:
        return LLMResponse(content="", tokens_used=0, cost_usd=0.0)

    async def generate_with_tools(
        self, prompt: str, system: str = "", tools: list | None = None, temperature: float = 0.3
    ) -> LLMResponse:
        return LLMResponse(content="", tokens_used=0, cost_usd=0.0)

    async def stream(self, prompt: str, system: str = "") -> AsyncIterator[str]:
        async def _empty():
            return
            yield  # make it an async generator

        return _empty()

    async def embed(self, text: str) -> list[float]:
        return [0.0] * 128


# ---------------------------------------------------------------------------
# A/B Learning Tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_agent_with_memory_succeeds_in_fewer_attempts_than_without():
    """Core A/B test: memory reduces the number of attempts to success."""
    llm = DummyLLM()

    # --- Agent A: no prior memory ---
    memory_a = InMemoryBackend()
    sandbox_a = MockSandboxProvider()
    task_a = Task(instruction="Fix and build the demo Next.js project", max_retries=10, max_budget_usd=5.0)
    loop_a = MemoryAwareREJDLoop(memory_a, sandbox_a, llm, max_retries=10)
    result_a = await loop_a.run(task_a)

    # --- Agent B: memory pre-seeded with the sharp fix ---
    memory_b = InMemoryBackend()
    sharp_failure = make_failure_record(
        task_id=task_a.id,  # different task triggers same retrieval via error type
        attempt_number=1,
        error_type="BuildError",
        error_message="Module not found: sharp",
        error_category=ErrorCategory.DEPENDENCY_ERROR,
        suggested_fix="npm install sharp",
    )
    # Store under a different (past) task id so get_failures_for_task returns it
    # We override task_id to simulate cross-task memory
    sharp_failure_b = make_failure_record(
        task_id="past-task-001",
        attempt_number=1,
        error_type="BuildError",
        error_message="Module not found: sharp",
        error_category=ErrorCategory.DEPENDENCY_ERROR,
        suggested_fix="npm install sharp",
    )
    await memory_b.store_failure(sharp_failure_b)

    sandbox_b = MockSandboxProvider()
    task_b = Task(instruction="Fix and build the demo Next.js project", max_retries=10, max_budget_usd=5.0)
    # Pre-seed memory_b with the failure stored under task_b.id for RETRIEVE
    sharp_failure_for_b = make_failure_record(
        task_id=task_b.id,
        attempt_number=0,
        error_type="BuildError",
        error_message="Module not found: sharp",
        error_category=ErrorCategory.DEPENDENCY_ERROR,
        suggested_fix="npm install sharp",
    )
    await memory_b.store_failure(sharp_failure_for_b)

    loop_b = MemoryAwareREJDLoop(memory_b, sandbox_b, llm, max_retries=10)
    result_b = await loop_b.run(task_b)

    # Both should eventually succeed
    assert result_b.success is True, "Agent WITH memory should succeed"

    # Agent B (with memory) should succeed in fewer attempts than Agent A (without)
    assert result_b.attempts <= result_a.attempts, (
        f"Agent WITH memory ({result_b.attempts} attempts) should need no more attempts "
        f"than Agent WITHOUT memory ({result_a.attempts} attempts)"
    )


@pytest.mark.asyncio
async def test_agent_without_memory_fails_more_times_before_learning():
    """Agent without memory fails on the same error multiple times before fixing it."""
    llm = DummyLLM()
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    task = Task(instruction="build project", max_retries=10, max_budget_usd=5.0)

    loop = MemoryAwareREJDLoop(memory, sandbox, llm, max_retries=10)
    result = await loop.run(task)

    # Without pre-seeded memory, the first attempt must fail (no known fix)
    assert len(loop.attempt_log) >= 1
    first_attempt = loop.attempt_log[0]
    assert first_attempt["known_fixes_count"] == 0, (
        "First attempt should have zero recalled fixes (empty memory)"
    )


@pytest.mark.asyncio
async def test_agent_with_memory_uses_fix_on_first_attempt():
    """Agent WITH memory should select the correct command on attempt 1."""
    llm = DummyLLM()
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    task = Task(instruction="build project", max_retries=10, max_budget_usd=5.0)

    # Pre-seed memory with the known fix
    await memory.store_failure(
        make_failure_record(
            task_id=task.id,
            attempt_number=0,
            error_type="BuildError",
            error_message="Module not found: sharp",
            error_category=ErrorCategory.DEPENDENCY_ERROR,
            suggested_fix="npm install sharp",
        )
    )

    loop = MemoryAwareREJDLoop(memory, sandbox, llm, max_retries=10)
    result = await loop.run(task)

    assert result.success is True
    assert result.attempts == 1, (
        "With the fix in memory, agent should succeed on first attempt"
    )
    assert loop.attempt_log[0]["known_fixes_count"] >= 1


@pytest.mark.asyncio
async def test_memory_accumulates_across_attempts():
    """Each failed attempt adds a record; later attempts have more context."""
    llm = DummyLLM()
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    task = Task(instruction="build project", max_retries=10, max_budget_usd=5.0)

    loop = MemoryAwareREJDLoop(memory, sandbox, llm, max_retries=10)
    result = await loop.run(task)

    if len(loop.attempt_log) > 1:
        for i in range(1, len(loop.attempt_log)):
            prev = loop.attempt_log[i - 1]
            curr = loop.attempt_log[i]
            assert curr["known_fixes_count"] >= prev["known_fixes_count"], (
                f"Attempt {i+1} should have at least as many recalled fixes as attempt {i}"
            )


@pytest.mark.asyncio
async def test_failure_memory_cost_is_lower_with_memory():
    """Fewer attempts = lower total cost when memory is available."""
    llm = DummyLLM()

    # Agent without memory
    memory_a = InMemoryBackend()
    task_a = Task(instruction="build project", max_retries=10, max_budget_usd=5.0)
    loop_a = MemoryAwareREJDLoop(memory_a, MockSandboxProvider(), llm, max_retries=10)
    result_a = await loop_a.run(task_a)

    # Agent with memory
    memory_b = InMemoryBackend()
    task_b = Task(instruction="build project", max_retries=10, max_budget_usd=5.0)
    await memory_b.store_failure(
        make_failure_record(
            task_id=task_b.id,
            attempt_number=0,
            error_type="BuildError",
            error_message="Module not found: sharp",
            error_category=ErrorCategory.DEPENDENCY_ERROR,
            suggested_fix="npm install sharp",
        )
    )
    loop_b = MemoryAwareREJDLoop(memory_b, MockSandboxProvider(), llm, max_retries=10)
    result_b = await loop_b.run(task_b)

    assert result_b.total_cost <= result_a.total_cost, (
        "Agent with failure memory should spend less (fewer attempts)"
    )
