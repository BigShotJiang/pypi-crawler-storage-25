"""Tests for the ReLoop CLI commands."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from src.cli.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# --help
# ---------------------------------------------------------------------------

def test_help_output():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "ReLoop" in result.output
    assert "Self-Healing" in result.output or "Failure Memory" in result.output


# ---------------------------------------------------------------------------
# version command
# ---------------------------------------------------------------------------

def test_version_command():
    result = runner.invoke(app, ["version"])
    assert result.exit_code == 0
    assert "0.4.0" in result.output


# ---------------------------------------------------------------------------
# run command (mocked HTTP)
# ---------------------------------------------------------------------------

def test_run_command_success():
    mock_response = MagicMock()
    mock_response.json.return_value = {"id": "task-123", "status": "running"}
    mock_response.raise_for_status = MagicMock()

    mock_client = MagicMock()
    mock_client.post.return_value = mock_response

    with patch("src.cli.main._http_client", return_value=mock_client):
        result = runner.invoke(app, ["run", "Fix the build"])
    assert result.exit_code == 0
    assert "task-123" in result.output


def test_run_command_failure():
    mock_client = MagicMock()
    mock_client.post.side_effect = Exception("Connection refused")

    with patch("src.cli.main._http_client", return_value=mock_client):
        result = runner.invoke(app, ["run", "Fix the build"])
    assert result.exit_code == 1
    assert "Error" in result.output


# ---------------------------------------------------------------------------
# status command (mocked HTTP)
# ---------------------------------------------------------------------------

def test_status_command_success():
    mock_response = MagicMock()
    mock_response.json.return_value = {
        "status": "succeeded",
        "total_attempts": 3,
        "total_cost_usd": 0.042,
        "result": "Build successful",
    }
    mock_response.raise_for_status = MagicMock()

    mock_client = MagicMock()
    mock_client.get.return_value = mock_response

    with patch("src.cli.main._http_client", return_value=mock_client):
        result = runner.invoke(app, ["status", "task-123"])
    assert result.exit_code == 0
    assert "succeeded" in result.output


# ---------------------------------------------------------------------------
# stats command (mocked HTTP)
# ---------------------------------------------------------------------------

def test_stats_command_success():
    mock_response = MagicMock()
    mock_response.json.return_value = {
        "total_failures": 10,
        "total_successes": 5,
        "avg_confidence": 0.85,
        "top_error_categories": {"dependency_error": 6, "config_error": 4},
    }
    mock_response.raise_for_status = MagicMock()

    mock_client = MagicMock()
    mock_client.get.return_value = mock_response

    with patch("src.cli.main._http_client", return_value=mock_client):
        result = runner.invoke(app, ["stats"])
    assert result.exit_code == 0
    assert "10" in result.output
    assert "5" in result.output


# ---------------------------------------------------------------------------
# memories command (mocked HTTP)
# ---------------------------------------------------------------------------

def test_memories_search_success():
    mock_response = MagicMock()
    mock_response.json.return_value = {
        "results": [
            {
                "signature": {"error_type": "ModuleNotFoundError"},
                "analysis": {"root_cause": "sharp not installed"},
            }
        ]
    }
    mock_response.raise_for_status = MagicMock()

    mock_client = MagicMock()
    mock_client.post.return_value = mock_response

    with patch("src.cli.main._http_client", return_value=mock_client):
        result = runner.invoke(app, ["memories", "--query", "sharp"])
    assert result.exit_code == 0
    assert "ModuleNotFoundError" in result.output


def test_memories_no_results():
    mock_response = MagicMock()
    mock_response.json.return_value = {"results": []}
    mock_response.raise_for_status = MagicMock()

    mock_client = MagicMock()
    mock_client.post.return_value = mock_response

    with patch("src.cli.main._http_client", return_value=mock_client):
        result = runner.invoke(app, ["memories", "--query", "nonexistent"])
    assert result.exit_code == 0
    assert "No memories found" in result.output


# ---------------------------------------------------------------------------
# health command (mocked HTTP)
# ---------------------------------------------------------------------------

def test_health_command_success():
    mock_response = MagicMock()
    mock_response.json.return_value = {"status": "ok", "version": "0.1.0"}
    mock_response.raise_for_status = MagicMock()

    mock_client = MagicMock()
    mock_client.get.return_value = mock_response

    with patch("src.cli.main._http_client", return_value=mock_client):
        result = runner.invoke(app, ["health"])
    assert result.exit_code == 0
    assert "healthy" in result.output


def test_health_command_unreachable():
    mock_client = MagicMock()
    mock_client.get.side_effect = Exception("Connection refused")

    with patch("src.cli.main._http_client", return_value=mock_client):
        result = runner.invoke(app, ["health"])
    assert result.exit_code == 1
    assert "unreachable" in result.output


# ---------------------------------------------------------------------------
# No-arg invocation shows help
# ---------------------------------------------------------------------------

def test_no_args_shows_help():
    result = runner.invoke(app, [])
    # Typer with no_args_is_help=True returns exit code 0 or 2 depending on version
    assert result.exit_code in (0, 2)
    assert "Usage" in result.output or "Commands" in result.output or "run" in result.output
