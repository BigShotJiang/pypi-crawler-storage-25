"""Comprehensive tests for the Context Surfaces integration.

Covers:
1. ContextModel definitions (FailureSurface, SuccessSurface, get_reloop_data_model)
2. ContextSurfacesManager client wrapper (surface lifecycle, agent keys, tools, import)
3. API routes (/v1/surfaces/...)
4. Edge cases (missing admin key, 404 surface, empty records, etc.)
"""

from __future__ import annotations

import json
import sys
import types
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from httpx import ASGITransport, AsyncClient


# ---------------------------------------------------------------------------
# Mock the external `context_surfaces` package before importing our code.
# The package is not installed in the test environment.
# ---------------------------------------------------------------------------

def _build_context_surfaces_mock() -> types.ModuleType:
    """Create a mock `context_surfaces` package with the classes our code imports."""
    # Top-level module
    cs = types.ModuleType("context_surfaces")

    # --- context_model sub-module ---
    cs_cm = types.ModuleType("context_surfaces.context_model")

    class _ContextField:
        def __init__(self, **kwargs: Any) -> None:
            self.kwargs = kwargs

    class _ContextModel:
        __redis_key_template__: str = ""

    class _ContextRelationship:
        def __init__(self, **kwargs: Any) -> None:
            self.kwargs = kwargs

    cs_cm.ContextField = _ContextField  # type: ignore[attr-defined]
    cs_cm.ContextModel = _ContextModel  # type: ignore[attr-defined]
    cs_cm.ContextRelationship = _ContextRelationship  # type: ignore[attr-defined]

    # Attach sub-module to parent
    cs.context_model = cs_cm  # type: ignore[attr-defined]

    # --- Top-level exports used by our modules ---
    cs.ContextField = _ContextField  # type: ignore[attr-defined]
    cs.ContextModel = _ContextModel  # type: ignore[attr-defined]
    cs.ContextRelationship = _ContextRelationship  # type: ignore[attr-defined]

    def _export_data_model(title: str, description: str, entities: list) -> dict:
        return {
            "title": title,
            "description": description,
            "entities": [e.__name__ for e in entities],
        }

    cs.export_data_model = _export_data_model  # type: ignore[attr-defined]

    # Client-side classes
    cs.UnifiedClient = MagicMock  # type: ignore[attr-defined]
    cs.CreateContextSurfaceRequest = MagicMock  # type: ignore[attr-defined]
    cs.DataSourceConnectionConfig = MagicMock  # type: ignore[attr-defined]
    cs.DataSourceRequest = MagicMock  # type: ignore[attr-defined]
    cs.CreateAgentKeyRequest = MagicMock  # type: ignore[attr-defined]

    return cs


# Install mock before any project imports that touch context_surfaces
_cs_mock = _build_context_surfaces_mock()
sys.modules["context_surfaces"] = _cs_mock
sys.modules["context_surfaces.context_model"] = _cs_mock.context_model  # type: ignore[attr-defined]


# Now safe to import project code
from src.providers.memory.context_surfaces import (  # noqa: E402
    FailureSurface,
    SuccessSurface,
    get_reloop_data_model,
)
from src.providers.memory.context_surfaces_client import ContextSurfacesManager  # noqa: E402
from src.api.routes.surfaces import (  # noqa: E402
    CreateSurfaceRequest,
    SurfaceResponse,
    CreateAgentKeyRequest as RouteAgentKeyRequest,
    AgentKeyResponse,
    ImportResponse,
    ToolQueryRequest,
    SetupRequest,
    SetupResponse,
    router as surfaces_router,
)
from src.config import Settings  # noqa: E402


# =========================================================================
# 1. ContextModel definition tests
# =========================================================================


class TestFailureSurface:
    """Tests for the FailureSurface ContextModel."""

    def test_redis_key_template(self):
        assert FailureSurface.__redis_key_template__ == "failure:{id}"

    def test_has_expected_fields(self):
        """All expected field names should be class attributes."""
        expected_fields = [
            "id", "task_id", "attempt_number", "error_type",
            "error_category", "error_message", "error_hash",
            "root_cause", "what_was_tried", "why_it_failed",
            "suggested_fix", "anti_pattern", "confidence",
            "cost_usd", "timestamp", "embedding",
        ]
        for field in expected_fields:
            assert hasattr(FailureSurface, field), f"Missing field: {field}"

    def test_has_resolved_by_relationship(self):
        assert hasattr(FailureSurface, "resolved_by")


class TestSuccessSurface:
    """Tests for the SuccessSurface ContextModel."""

    def test_redis_key_template(self):
        assert SuccessSurface.__redis_key_template__ == "success:{id}"

    def test_has_expected_fields(self):
        expected_fields = [
            "id", "task_id", "attempt_number", "approach",
            "key_insight", "failure_count", "total_attempts",
            "total_cost_usd", "timestamp",
        ]
        for field in expected_fields:
            assert hasattr(SuccessSurface, field), f"Missing field: {field}"

    def test_has_prior_failures_relationship(self):
        assert hasattr(SuccessSurface, "prior_failures")


class TestGetReloopDataModel:
    """Tests for the get_reloop_data_model export function."""

    def test_returns_dict(self):
        result = get_reloop_data_model()
        assert isinstance(result, dict)

    def test_has_title(self):
        result = get_reloop_data_model()
        assert result["title"] == "ReLoop Failure Memory"

    def test_has_description(self):
        result = get_reloop_data_model()
        assert "failure" in result["description"].lower()
        assert "success" in result["description"].lower()

    def test_includes_both_entities(self):
        result = get_reloop_data_model()
        assert "FailureSurface" in result["entities"]
        assert "SuccessSurface" in result["entities"]


# =========================================================================
# 2. ContextSurfacesManager client tests
# =========================================================================


def _make_settings(**overrides: Any) -> Settings:
    """Create a Settings instance with test defaults."""
    defaults = {
        "context_surfaces_admin_key": "test-admin-key-123",
        "context_surfaces_api_url": "https://test.example.com",
        "redis_url": "redis://localhost:6379",
    }
    defaults.update(overrides)
    return Settings(**defaults)


class TestContextSurfacesManagerInit:

    def test_initial_state(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        assert mgr._surface_id is None
        assert mgr._agent_keys == []
        assert mgr._client is None

    def test_get_client_creates_unified_client(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        client = mgr._get_client()
        assert client is not None
        # Second call returns same instance
        assert mgr._get_client() is client

    def test_get_client_passes_credentials(self):
        config = _make_settings(
            context_surfaces_admin_key="my-key",
            context_surfaces_api_url="https://custom.url",
        )
        mgr = ContextSurfacesManager(config=config)
        with patch(
            "context_surfaces.UnifiedClient"
        ) as mock_uc:
            mock_uc.return_value = MagicMock()
            mgr._client = None  # force re-init
            mgr._get_client()
            mock_uc.assert_called_once_with(
                admin_key="my-key",
                api_url="https://custom.url",
                timeout=10.0,
            )


class TestContextSurfacesManagerEnsureSurface:

    @pytest.mark.asyncio
    async def test_ensure_surface_creates_surface(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)

        mock_response = MagicMock()
        mock_response.surface_id = "surf-abc123"
        mock_client = MagicMock()
        mock_client.create_context_surface = AsyncMock(return_value=mock_response)
        mgr._client = mock_client

        result = await mgr.ensure_surface()
        assert result == "surf-abc123"
        assert mgr._surface_id == "surf-abc123"
        mock_client.create_context_surface.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_ensure_surface_returns_cached(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        mgr._surface_id = "already-created"

        result = await mgr.ensure_surface()
        assert result == "already-created"


class TestContextSurfacesManagerAgentKey:

    @pytest.mark.asyncio
    async def test_create_agent_key(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        mgr._surface_id = "surf-001"

        mock_response = MagicMock()
        mock_response.agent_key = "ak-secret-key-12345678"
        mock_client = MagicMock()
        mock_client.create_agent_key = AsyncMock(return_value=mock_response)
        mgr._client = mock_client

        key = await mgr.create_agent_key(name="test-agent", description="test")
        assert key == "ak-secret-key-12345678"
        mock_client.create_agent_key.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_get_or_create_agent_key_returns_cached(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        mgr._surface_id = "surf-001"
        mgr._agent_keys = [{"name": "cached", "key": "cached-key"}]

        result = await mgr.get_or_create_agent_key()
        assert result == "cached-key"

    @pytest.mark.asyncio
    async def test_get_or_create_agent_key_creates_when_missing(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        mgr._surface_id = "surf-001"

        mock_response = MagicMock()
        mock_response.agent_key = "new-key-001"
        mock_client = MagicMock()
        mock_client.create_agent_key = AsyncMock(return_value=mock_response)
        mgr._client = mock_client

        result = await mgr.get_or_create_agent_key()
        assert result == "new-key-001"
        assert mgr._agent_keys[-1]["key"] == "new-key-001"


class TestContextSurfacesManagerTools:

    @pytest.mark.asyncio
    async def test_list_tools(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        mgr._surface_id = "surf-001"
        mgr._agent_keys = [{"name": "test", "key": "ak-test"}]

        mock_response = MagicMock()
        mock_response.tools = [
            {"name": "search_failures", "description": "Search failure records"},
            {"name": "get_failure", "description": "Get a failure by ID"},
        ]
        mock_client = MagicMock()
        mock_client.list_tools = AsyncMock(return_value=mock_response)
        mgr._client = mock_client

        tools = await mgr.list_tools(agent_key="ak-test")
        assert len(tools) == 2
        assert tools[0]["name"] == "search_failures"

    @pytest.mark.asyncio
    async def test_query_tool(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        mgr._surface_id = "surf-001"
        mgr._agent_keys = [{"name": "test", "key": "ak-test"}]

        mock_client = MagicMock()
        mock_client.query_tool = AsyncMock(return_value={"result": "found"})
        mgr._client = mock_client

        result = await mgr.query_tool(
            tool_name="search_failures",
            arguments={"query": "ModuleNotFoundError"},
            agent_key="ak-test",
        )
        assert result == {"result": "found"}
        mock_client.query_tool.assert_awaited_once_with(
            agent_key="ak-test",
            tool_name="search_failures",
            arguments={"query": "ModuleNotFoundError"},
        )


class TestContextSurfacesManagerImport:

    @pytest.mark.asyncio
    async def test_import_existing_records(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        mgr._surface_id = "surf-001"

        mock_client = MagicMock()
        mock_client.import_data = AsyncMock()
        mgr._client = mock_client

        # Mock redis backend
        failure_data = {
            "id": "f1",
            "task_id": "t1",
            "attempt_number": 1,
            "signature": {
                "error_type": "ModuleNotFoundError",
                "error_category": "dependency_error",
                "error_message": "sharp not found",
                "error_hash": "abc123",
            },
            "analysis": {
                "root_cause": "missing dep",
                "what_was_tried": "npm build",
                "why_it_failed": "sharp missing",
                "suggested_fix": "npm install sharp",
                "anti_pattern": None,
                "confidence": 0.9,
            },
            "cost_usd": 0.01,
            "timestamp": "2026-04-11T10:00:00Z",
            "embedding": None,
        }

        success_data = {
            "id": "s1",
            "task_id": "t1",
            "attempt_number": 4,
            "solution": {"approach": "installed sharp", "key_insight": "check deps first"},
            "learning": {"failure_count": 3},
            "metrics": {"total_attempts": 4, "total_cost_usd": 0.05},
            "timestamp": "2026-04-11T11:00:00Z",
        }

        mock_redis = AsyncMock()
        # First scan returns failure keys, second returns empty
        mock_redis.scan = AsyncMock(
            side_effect=[
                (0, ["failure:f1"]),   # failure scan
                (0, ["success:s1"]),   # success scan
            ]
        )
        mock_redis.hget = AsyncMock(
            side_effect=[
                json.dumps(failure_data),
                json.dumps(success_data),
            ]
        )

        mock_backend = MagicMock()
        mock_backend._get_client = AsyncMock(return_value=mock_redis)

        counts = await mgr.import_existing_records(mock_backend)
        assert counts["failures"] == 1
        assert counts["successes"] == 1
        assert mock_client.import_data.await_count == 2

    @pytest.mark.asyncio
    async def test_import_empty_records(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        mgr._surface_id = "surf-001"

        mock_client = MagicMock()
        mock_client.import_data = AsyncMock()
        mgr._client = mock_client

        mock_redis = AsyncMock()
        mock_redis.scan = AsyncMock(
            side_effect=[
                (0, []),  # no failures
                (0, []),  # no successes
            ]
        )

        mock_backend = MagicMock()
        mock_backend._get_client = AsyncMock(return_value=mock_redis)

        counts = await mgr.import_existing_records(mock_backend)
        assert counts["failures"] == 0
        assert counts["successes"] == 0
        mock_client.import_data.assert_not_awaited()


# =========================================================================
# 3. API route tests
# =========================================================================


def _create_test_app():
    """Create a minimal FastAPI app with surfaces router for testing.

    Ensures CONTEXT_SURFACES_AVAILABLE is True in the routes module so the
    router-level dependency doesn't reject all requests with 503.  This is
    necessary because the real ``context_surfaces`` package may not be
    installed; the test file installs a mock into sys.modules, but when
    the full test suite runs, other modules may import the client first
    and lock the flag to False.
    """
    import src.api.routes.surfaces as _surfaces_mod

    _surfaces_mod.CONTEXT_SURFACES_AVAILABLE = True

    from fastapi import FastAPI

    app = FastAPI()
    app.include_router(surfaces_router)
    return app


@pytest.fixture
def mock_manager():
    """A mock ContextSurfacesManager with sensible defaults."""
    mgr = MagicMock(spec=ContextSurfacesManager)
    mgr._surface_id = "surf-test-001"
    mgr._agent_key = "ak-test-key"
    mgr._agent_keys = [{"name": "reloop-agent", "key": "ak-test-key"}]
    mgr.ensure_surface = AsyncMock(return_value="surf-test-001")
    mgr.create_agent_key = AsyncMock(return_value="ak-new-key")
    mgr.list_tools = AsyncMock(return_value=[{"name": "tool1"}])
    mgr.query_tool = AsyncMock(return_value={"data": "result"})
    mgr.import_existing_records = AsyncMock(
        return_value={"failures": 5, "successes": 2}
    )
    mgr._get_client = MagicMock(return_value=MagicMock())
    return mgr


class TestSurfaceRoutesNoManager:
    """Tests when surfaces_manager is not configured (503 responses)."""

    @pytest.mark.asyncio
    async def test_create_surface_503_when_no_manager(self):
        app = _create_test_app()
        app.state.surfaces_manager = None

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/v1/surfaces", json={"name": "test"})
            assert resp.status_code == 503
            assert "not configured" in resp.json()["detail"]

    @pytest.mark.asyncio
    async def test_list_surfaces_503_when_no_manager(self):
        app = _create_test_app()
        app.state.surfaces_manager = None

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces")
            assert resp.status_code == 503

    @pytest.mark.asyncio
    async def test_get_surface_503_when_no_manager(self):
        app = _create_test_app()
        app.state.surfaces_manager = None

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces/fake-id")
            assert resp.status_code == 503

    @pytest.mark.asyncio
    async def test_delete_surface_503_when_no_manager(self):
        app = _create_test_app()
        app.state.surfaces_manager = None

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.delete("/v1/surfaces/fake-id")
            assert resp.status_code == 503


class TestCreateSurfaceRoute:

    @pytest.mark.asyncio
    async def test_create_surface_success(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/v1/surfaces",
                json={"name": "my-surface", "description": "Test surface"},
            )
            assert resp.status_code == 201
            data = resp.json()
            assert data["surface_id"] == "surf-test-001"
            assert data["name"] == "my-surface"
            assert data["description"] == "Test surface"

    @pytest.mark.asyncio
    async def test_create_surface_default_name(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/v1/surfaces", json={})
            assert resp.status_code == 201
            assert resp.json()["name"] == "reloop-failure-memory"

    @pytest.mark.asyncio
    async def test_create_surface_500_on_failure(self, mock_manager):
        mock_manager.ensure_surface = AsyncMock(side_effect=RuntimeError("boom"))
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/v1/surfaces", json={"name": "test"})
            assert resp.status_code == 500


class TestListSurfacesRoute:

    @pytest.mark.asyncio
    async def test_list_surfaces_with_surface(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces")
            assert resp.status_code == 200
            data = resp.json()
            assert len(data) == 1
            assert data[0]["surface_id"] == "surf-test-001"

    @pytest.mark.asyncio
    async def test_list_surfaces_empty(self, mock_manager):
        mock_manager._surface_id = None
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces")
            assert resp.status_code == 200
            assert resp.json() == []


class TestGetSurfaceRoute:

    @pytest.mark.asyncio
    async def test_get_surface_found(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces/surf-test-001")
            assert resp.status_code == 200
            assert resp.json()["surface_id"] == "surf-test-001"

    @pytest.mark.asyncio
    async def test_get_surface_not_found(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces/wrong-id")
            assert resp.status_code == 404
            assert "not found" in resp.json()["detail"]


class TestDeleteSurfaceRoute:

    @pytest.mark.asyncio
    async def test_delete_surface_success(self, mock_manager):
        mock_client = MagicMock()
        mock_client.delete_context_surface = AsyncMock()
        mock_manager._get_client = MagicMock(return_value=mock_client)

        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.delete("/v1/surfaces/surf-test-001")
            assert resp.status_code == 204

    @pytest.mark.asyncio
    async def test_delete_surface_not_found(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.delete("/v1/surfaces/wrong-id")
            assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_delete_surface_500_on_failure(self, mock_manager):
        mock_client = MagicMock()
        mock_client.delete_context_surface = AsyncMock(
            side_effect=RuntimeError("delete failed")
        )
        mock_manager._get_client = MagicMock(return_value=mock_client)

        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.delete("/v1/surfaces/surf-test-001")
            assert resp.status_code == 500


class TestAgentKeyRoutes:

    @pytest.mark.asyncio
    async def test_create_agent_key(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/v1/surfaces/surf-test-001/agents",
                json={"name": "my-agent", "description": "test agent"},
            )
            assert resp.status_code == 201
            data = resp.json()
            assert data["agent_key"] == "ak-new-key"
            assert data["name"] == "my-agent"

    @pytest.mark.asyncio
    async def test_create_agent_key_wrong_surface(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/v1/surfaces/wrong-id/agents",
                json={"name": "my-agent"},
            )
            assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_create_agent_key_500_on_failure(self, mock_manager):
        mock_manager.create_agent_key = AsyncMock(
            side_effect=RuntimeError("key creation failed")
        )
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/v1/surfaces/surf-test-001/agents",
                json={"name": "test"},
            )
            assert resp.status_code == 500

    @pytest.mark.asyncio
    async def test_list_agent_keys_with_cached_key(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces/surf-test-001/agents")
            assert resp.status_code == 200
            data = resp.json()
            assert len(data) == 1
            # Keys are masked in list responses (only create returns the full key)
            assert data[0]["agent_key"] == "****-key"
            assert data[0]["name"] == "reloop-agent"

    @pytest.mark.asyncio
    async def test_list_agent_keys_empty(self, mock_manager):
        mock_manager._agent_keys = []
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces/surf-test-001/agents")
            assert resp.status_code == 200
            assert resp.json() == []

    @pytest.mark.asyncio
    async def test_list_agent_keys_wrong_surface(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces/wrong-id/agents")
            assert resp.status_code == 404


class TestImportRoute:

    @pytest.mark.asyncio
    async def test_import_records_success(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager
        app.state.memory = MagicMock()  # memory backend present

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/v1/surfaces/surf-test-001/import")
            assert resp.status_code == 200
            data = resp.json()
            assert data["failures"] == 5
            assert data["successes"] == 2

    @pytest.mark.asyncio
    async def test_import_records_wrong_surface(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager
        app.state.memory = MagicMock()

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/v1/surfaces/wrong-id/import")
            assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_import_records_no_memory_backend(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager
        app.state.memory = None  # no memory backend

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/v1/surfaces/surf-test-001/import")
            assert resp.status_code == 503
            assert "Memory backend" in resp.json()["detail"]

    @pytest.mark.asyncio
    async def test_import_records_500_on_failure(self, mock_manager):
        mock_manager.import_existing_records = AsyncMock(
            side_effect=RuntimeError("import boom")
        )
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager
        app.state.memory = MagicMock()

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/v1/surfaces/surf-test-001/import")
            assert resp.status_code == 500


class TestSetupRoute:

    @pytest.mark.asyncio
    async def test_setup_success(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager
        app.state.memory = MagicMock()

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/v1/surfaces/setup",
                json={"name": "my-surface", "agent_key_name": "my-agent"},
            )
            assert resp.status_code == 201
            data = resp.json()
            assert data["surface_id"] == "surf-test-001"
            assert data["agent_key"] == "ak-new-key"
            assert data["import_counts"]["failures"] == 5
            assert data["import_counts"]["successes"] == 2

    @pytest.mark.asyncio
    async def test_setup_without_import(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/v1/surfaces/setup",
                json={"import_existing": False},
            )
            assert resp.status_code == 201
            data = resp.json()
            assert data["surface_id"] == "surf-test-001"
            assert data["agent_key"] == "ak-new-key"
            assert data["import_counts"] is None

    @pytest.mark.asyncio
    async def test_setup_503_when_no_manager(self):
        app = _create_test_app()
        app.state.surfaces_manager = None

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/v1/surfaces/setup", json={})
            assert resp.status_code == 503


class TestToolRoutes:

    @pytest.mark.asyncio
    async def test_list_tools(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces/surf-test-001/tools")
            assert resp.status_code == 200
            data = resp.json()
            assert len(data) == 1
            assert data[0]["name"] == "tool1"

    @pytest.mark.asyncio
    async def test_list_tools_wrong_surface(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces/wrong-id/tools")
            assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_list_tools_500_on_failure(self, mock_manager):
        mock_manager.list_tools = AsyncMock(side_effect=RuntimeError("tools error"))
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces/surf-test-001/tools")
            assert resp.status_code == 500

    @pytest.mark.asyncio
    async def test_query_tool_success(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/v1/surfaces/surf-test-001/query",
                json={
                    "tool_name": "search_failures",
                    "arguments": {"query": "sharp"},
                },
            )
            assert resp.status_code == 200
            assert resp.json() == {"data": "result"}

    @pytest.mark.asyncio
    async def test_query_tool_with_agent_key(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/v1/surfaces/surf-test-001/query",
                json={
                    "tool_name": "get_failure",
                    "arguments": {"id": "f1"},
                    "agent_key": "custom-key",
                },
            )
            assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_query_tool_wrong_surface(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/v1/surfaces/wrong-id/query",
                json={"tool_name": "search", "arguments": {}},
            )
            assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_query_tool_500_on_failure(self, mock_manager):
        mock_manager.query_tool = AsyncMock(
            side_effect=RuntimeError("query failed")
        )
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/v1/surfaces/surf-test-001/query",
                json={"tool_name": "search", "arguments": {}},
            )
            assert resp.status_code == 500


# =========================================================================
# 4. Pydantic request/response model tests
# =========================================================================


class TestRequestResponseModels:

    def test_create_surface_request_defaults(self):
        req = CreateSurfaceRequest()
        assert req.name == "reloop-failure-memory"
        assert req.description is None

    def test_surface_response_fields(self):
        resp = SurfaceResponse(
            surface_id="s1", name="test", description="desc"
        )
        assert resp.surface_id == "s1"
        assert resp.name == "test"

    def test_create_agent_key_request_defaults(self):
        req = RouteAgentKeyRequest()
        assert req.name == "reloop-agent"

    def test_agent_key_response(self):
        resp = AgentKeyResponse(agent_key="ak-123", name="my-agent")
        assert resp.agent_key == "ak-123"

    def test_import_response(self):
        resp = ImportResponse(failures=3, successes=1)
        assert resp.failures == 3
        assert resp.successes == 1

    def test_tool_query_request(self):
        req = ToolQueryRequest(
            tool_name="search",
            arguments={"q": "test"},
            agent_key="ak-1",
        )
        assert req.tool_name == "search"
        assert req.arguments == {"q": "test"}
        assert req.agent_key == "ak-1"

    def test_tool_query_request_defaults(self):
        req = ToolQueryRequest(tool_name="search")
        assert req.arguments == {}
        assert req.agent_key is None


# =========================================================================
# 5. Edge case tests
# =========================================================================


class TestEdgeCases:

    @pytest.mark.asyncio
    async def test_ensure_surface_called_by_create_agent_key(self):
        """create_agent_key should call ensure_surface if no surface_id."""
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)

        mock_surf_response = MagicMock()
        mock_surf_response.surface_id = "auto-surf"
        mock_key_response = MagicMock()
        mock_key_response.agent_key = "auto-key"

        mock_client = MagicMock()
        mock_client.create_context_surface = AsyncMock(
            return_value=mock_surf_response
        )
        mock_client.create_agent_key = AsyncMock(return_value=mock_key_response)
        mgr._client = mock_client

        key = await mgr.create_agent_key()
        assert key == "auto-key"
        assert mgr._surface_id == "auto-surf"
        mock_client.create_context_surface.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_list_tools_uses_cached_agent_key(self):
        """list_tools with no explicit key should use get_or_create_agent_key."""
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        mgr._surface_id = "surf-001"
        mgr._agent_keys = [{"name": "cached", "key": "cached-key-abc"}]

        mock_response = MagicMock()
        mock_response.tools = []
        mock_client = MagicMock()
        mock_client.list_tools = AsyncMock(return_value=mock_response)
        mgr._client = mock_client

        tools = await mgr.list_tools()
        assert tools == []
        mock_client.list_tools.assert_awaited_once_with(
            agent_key="cached-key-abc"
        )

    @pytest.mark.asyncio
    async def test_delete_resets_surface_and_agent_key(self, mock_manager):
        """DELETE /surfaces/{id} should clear cached surface_id and agent_key."""
        mock_client = MagicMock()
        mock_client.delete_context_surface = AsyncMock()
        mock_manager._get_client = MagicMock(return_value=mock_client)

        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.delete("/v1/surfaces/surf-test-001")
            assert resp.status_code == 204

        # After delete, surface_id should be None and agent_keys cleared
        assert mock_manager._surface_id is None
        assert mock_manager._agent_keys == []

    def test_surface_response_empty_description(self):
        resp = SurfaceResponse(surface_id="s1", name="test")
        assert resp.description == ""


# =========================================================================
# 6. Tests for new functionality (Tasks #6-#9 fixes)
# =========================================================================


class TestClientTimeout:
    """W2: UnifiedClient receives a timeout parameter."""

    def test_default_timeout(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        assert mgr._timeout == 10.0

    def test_custom_timeout(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config, timeout=30.0)
        assert mgr._timeout == 30.0

    def test_timeout_passed_to_client(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config, timeout=5.0)
        with patch(
            "context_surfaces.UnifiedClient"
        ) as mock_uc:
            mock_uc.return_value = MagicMock()
            mgr._client = None  # force re-init
            mgr._get_client()
            mock_uc.assert_called_once_with(
                admin_key=config.context_surfaces_admin_key,
                api_url=config.context_surfaces_api_url,
                timeout=5.0,
            )


class TestMaskedAgentKeys:
    """C2: Agent keys are masked in list endpoint responses."""

    @pytest.mark.asyncio
    async def test_keys_are_masked_shows_last_4(self, mock_manager):
        mock_manager._agent_keys = [
            {"name": "agent-1", "key": "ak-secret-key-12345678"},
        ]
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces/surf-test-001/agents")
            assert resp.status_code == 200
            data = resp.json()
            assert len(data) == 1
            assert data[0]["agent_key"] == "****5678"
            assert data[0]["name"] == "agent-1"

    @pytest.mark.asyncio
    async def test_short_key_fully_masked(self, mock_manager):
        mock_manager._agent_keys = [
            {"name": "short", "key": "ab"},
        ]
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces/surf-test-001/agents")
            data = resp.json()
            assert data[0]["agent_key"] == "****"

    @pytest.mark.asyncio
    async def test_create_returns_full_key(self, mock_manager):
        """POST /agents returns the unmasked key (one-time exposure)."""
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/v1/surfaces/surf-test-001/agents",
                json={"name": "test-agent"},
            )
            assert resp.status_code == 201
            assert resp.json()["agent_key"] == "ak-new-key"  # full key, not masked


class TestMultipleAgentKeys:
    """W5: Manager now tracks multiple agent keys."""

    @pytest.mark.asyncio
    async def test_create_agent_key_appends_to_list(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        mgr._surface_id = "surf-001"

        mock_response_1 = MagicMock()
        mock_response_1.agent_key = "key-aaa"
        mock_response_2 = MagicMock()
        mock_response_2.agent_key = "key-bbb"
        mock_client = MagicMock()
        mock_client.create_agent_key = AsyncMock(
            side_effect=[mock_response_1, mock_response_2]
        )
        mgr._client = mock_client

        await mgr.create_agent_key(name="first")
        await mgr.create_agent_key(name="second")

        assert len(mgr._agent_keys) == 2
        assert mgr._agent_keys[0] == {"name": "first", "key": "key-aaa"}
        assert mgr._agent_keys[1] == {"name": "second", "key": "key-bbb"}

    @pytest.mark.asyncio
    async def test_get_or_create_returns_most_recent(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)
        mgr._surface_id = "surf-001"
        mgr._agent_keys = [
            {"name": "old", "key": "old-key"},
            {"name": "new", "key": "new-key"},
        ]

        result = await mgr.get_or_create_agent_key()
        assert result == "new-key"

    @pytest.mark.asyncio
    async def test_list_agents_shows_all_keys(self, mock_manager):
        mock_manager._agent_keys = [
            {"name": "agent-1", "key": "key-alpha-1234"},
            {"name": "agent-2", "key": "key-beta-56789"},
        ]
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/v1/surfaces/surf-test-001/agents")
            assert resp.status_code == 200
            data = resp.json()
            assert len(data) == 2
            assert data[0]["name"] == "agent-1"
            assert data[1]["name"] == "agent-2"


class TestEnsureSurfaceWithName:
    """S3: ensure_surface() accepts an optional name parameter."""

    @pytest.mark.asyncio
    async def test_ensure_surface_passes_custom_name(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)

        mock_response = MagicMock()
        mock_response.surface_id = "surf-custom"
        mock_client = MagicMock()
        mock_client.create_context_surface = AsyncMock(return_value=mock_response)
        mgr._client = mock_client

        result = await mgr.ensure_surface(name="my-custom-surface")
        assert result == "surf-custom"
        mock_client.create_context_surface.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_ensure_surface_default_name(self):
        config = _make_settings()
        mgr = ContextSurfacesManager(config=config)

        mock_response = MagicMock()
        mock_response.surface_id = "surf-default"
        mock_client = MagicMock()
        mock_client.create_context_surface = AsyncMock(return_value=mock_response)
        mgr._client = mock_client

        result = await mgr.ensure_surface()
        assert result == "surf-default"


class TestSetupRouteEdgeCases:
    """S2: POST /v1/surfaces/setup convenience endpoint edge cases."""

    @pytest.mark.asyncio
    async def test_setup_defaults(self, mock_manager):
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager
        app.state.memory = MagicMock()

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/v1/surfaces/setup", json={})
            assert resp.status_code == 201
            data = resp.json()
            assert data["surface_id"] == "surf-test-001"
            assert data["agent_key"] == "ak-new-key"

    @pytest.mark.asyncio
    async def test_setup_surface_creation_failure(self, mock_manager):
        mock_manager.ensure_surface = AsyncMock(
            side_effect=RuntimeError("surface fail")
        )
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/v1/surfaces/setup", json={})
            assert resp.status_code == 500

    @pytest.mark.asyncio
    async def test_setup_agent_key_creation_failure(self, mock_manager):
        mock_manager.create_agent_key = AsyncMock(
            side_effect=RuntimeError("key fail")
        )
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/v1/surfaces/setup", json={})
            assert resp.status_code == 500

    @pytest.mark.asyncio
    async def test_setup_import_failure_is_non_fatal(self, mock_manager):
        """Import errors during setup should not fail the whole request."""
        mock_manager.import_existing_records = AsyncMock(
            side_effect=RuntimeError("import oops")
        )
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager
        app.state.memory = MagicMock()

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/v1/surfaces/setup",
                json={"import_existing": True},
            )
            assert resp.status_code == 201
            data = resp.json()
            assert data["surface_id"] == "surf-test-001"
            assert data["import_counts"] is None  # import failed, so None

    @pytest.mark.asyncio
    async def test_setup_no_memory_skips_import(self, mock_manager):
        """If no memory backend, import_existing=True should just skip import."""
        app = _create_test_app()
        app.state.surfaces_manager = mock_manager
        app.state.memory = None

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/v1/surfaces/setup",
                json={"import_existing": True},
            )
            assert resp.status_code == 201
            assert resp.json()["import_counts"] is None

    def test_setup_request_defaults(self):
        req = SetupRequest()
        assert req.name == "reloop-failure-memory"
        assert req.agent_key_name == "reloop-agent"
        assert req.import_existing is True

    def test_setup_response_model(self):
        resp = SetupResponse(
            surface_id="s1",
            agent_key="ak-123",
            import_counts=ImportResponse(failures=2, successes=1),
        )
        assert resp.surface_id == "s1"
        assert resp.import_counts.failures == 2
