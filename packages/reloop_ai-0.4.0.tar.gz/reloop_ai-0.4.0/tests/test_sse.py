"""Tests for src/api/sse.py — SSE event formatting."""

from __future__ import annotations

import json

import pytest

from src.api.sse import format_sse_event
from src.models import TimelineEvent, TimelineEventType


# ---------------------------------------------------------------------------
# format_sse_event tests
# ---------------------------------------------------------------------------


class TestFormatSseEvent:
    def _make_event(self, **overrides) -> TimelineEvent:
        defaults = dict(
            task_id="task-001",
            event_type=TimelineEventType.TASK_CREATED,
            message="Task created",
        )
        defaults.update(overrides)
        return TimelineEvent(**defaults)

    def test_returns_dict_with_data_and_id(self):
        event = self._make_event()
        result = format_sse_event(event)
        assert isinstance(result, dict)
        assert "data" in result
        assert "id" in result

    def test_id_matches_event_id(self):
        event = self._make_event()
        result = format_sse_event(event)
        assert result["id"] == event.id

    def test_data_is_valid_json(self):
        event = self._make_event()
        result = format_sse_event(event)
        # data should be a JSON string from model_dump_json
        parsed = json.loads(result["data"])
        assert parsed["task_id"] == "task-001"
        assert parsed["event_type"] == "task.created"
        assert parsed["message"] == "Task created"

    def test_no_event_key(self):
        """SSE dict should NOT contain 'event' key per sse.py comments."""
        event = self._make_event()
        result = format_sse_event(event)
        assert "event" not in result

    def test_attempt_number_included(self):
        event = self._make_event(
            event_type=TimelineEventType.ATTEMPT_STARTED,
            attempt_number=3,
        )
        result = format_sse_event(event)
        parsed = json.loads(result["data"])
        assert parsed["attempt_number"] == 3

    def test_step_number_included(self):
        event = self._make_event(
            event_type=TimelineEventType.STEP_COMPLETED,
            step_number=2,
        )
        result = format_sse_event(event)
        parsed = json.loads(result["data"])
        assert parsed["step_number"] == 2

    def test_data_field_included(self):
        event = self._make_event(data={"exit_code": 0, "output": "ok"})
        result = format_sse_event(event)
        parsed = json.loads(result["data"])
        assert parsed["data"]["exit_code"] == 0

    def test_various_event_types(self):
        """Ensure all event types format without errors."""
        for evt_type in TimelineEventType:
            event = self._make_event(event_type=evt_type)
            result = format_sse_event(event)
            parsed = json.loads(result["data"])
            assert parsed["event_type"] == evt_type.value
