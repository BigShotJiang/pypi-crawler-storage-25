"""Tests for SyncFailureMemory — the synchronous wrapper around FailureMemory."""

from __future__ import annotations

from src.standalone import SyncFailureMemory


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _make_sync_memory(tmp_path) -> SyncFailureMemory:
    """Create a SyncFailureMemory backed by a temporary SQLite database."""
    return SyncFailureMemory(
        backend="sqlite",
        sqlite_path=str(tmp_path / "test_sync.db"),
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_search_returns_list_without_await(tmp_path):
    """search() works without await and returns a plain list."""
    mem = _make_sync_memory(tmp_path)
    results = mem.search("test")
    assert isinstance(results, list)


def test_store_failure_returns_id(tmp_path):
    """store_failure() works without await and returns a string ID."""
    mem = _make_sync_memory(tmp_path)
    fid = mem.store_failure(
        error_type="ImportError",
        error_message="No module named 'sharp'",
        root_cause="Missing dependency",
        suggested_fix="pip install sharp",
    )
    assert isinstance(fid, str)
    assert len(fid) > 0


def test_stats_returns_dict(tmp_path):
    """stats() works without await and returns a dict."""
    mem = _make_sync_memory(tmp_path)
    s = mem.stats()
    assert isinstance(s, dict)
    assert "total_failures" in s
    assert "total_successes" in s


def test_store_and_search_roundtrip(tmp_path):
    """Stored failures are found via search."""
    mem = _make_sync_memory(tmp_path)
    mem.store_failure(
        error_type="TypeError",
        error_message="Cannot read property 'map' of undefined",
        root_cause="Null reference",
        suggested_fix="Add null check",
    )
    results = mem.search("Cannot read property")
    assert len(results) >= 1
    assert results[0]["error_type"] == "TypeError"


def test_store_success_returns_id(tmp_path):
    """store_success() works without await."""
    mem = _make_sync_memory(tmp_path)
    sid = mem.store_success(
        approach="Added null check before .map()",
        key_insight="Always guard array operations",
    )
    assert isinstance(sid, str)
    assert len(sid) > 0


def test_clear_removes_data(tmp_path):
    """clear() works without await and actually removes data."""
    mem = _make_sync_memory(tmp_path)
    mem.store_failure(
        error_type="KeyError",
        error_message="'foo'",
        root_cause="Missing key",
        suggested_fix="Use .get()",
    )
    stats_before = mem.stats()
    assert stats_before["total_failures"] >= 1

    mem.clear()
    stats_after = mem.stats()
    assert stats_after["total_failures"] == 0


def test_works_inside_running_event_loop(tmp_path):
    """SyncFailureMemory works even when called from an async context.

    This simulates the Jupyter / async-framework scenario where
    asyncio.run() would normally crash.
    """
    import asyncio

    async def _inner():
        mem = _make_sync_memory(tmp_path)
        results = mem.search("test")
        assert isinstance(results, list)
        s = mem.stats()
        assert isinstance(s, dict)

    asyncio.run(_inner())
