"""Tests for streaming run CLI command."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch, PropertyMock

import pytest
from typer.testing import CliRunner

from src.cli.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_task_response(task_id="task-abc", status="running"):
    mock_resp = MagicMock()
    mock_resp.json.return_value = {"id": task_id, "status": status}
    mock_resp.raise_for_status = MagicMock()
    return mock_resp


class FakeSSEStream:
    """Simulate an httpx streaming response for SSE."""

    def __init__(self, events: list[dict]):
        lines = []
        for event in events:
            lines.append(f"data: {json.dumps(event)}")
        lines.append("data: [DONE]")
        self._lines = lines

    def iter_lines(self):
        yield from self._lines

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


# ---------------------------------------------------------------------------
# Streaming run
# ---------------------------------------------------------------------------

def test_run_stream_success():
    """run --stream should print SSE events as they arrive."""
    mock_client = MagicMock()
    mock_client.post.return_value = _make_task_response()

    sse_events = [
        {"type": "attempt_start", "attempt": 1},
        {"type": "attempt_failed", "attempt": 1, "error_type": "ModuleNotFoundError"},
        {"type": "attempt_start", "attempt": 2},
        {"type": "task_succeeded", "total_attempts": 2, "total_cost_usd": 0.05},
    ]

    with patch("src.cli.main._http_client", return_value=mock_client), \
         patch("httpx.stream", return_value=FakeSSEStream(sse_events)):
        result = runner.invoke(app, ["run", "Fix the build", "--stream"])

    assert result.exit_code == 0
    assert "Task created" in result.output
    assert "Attempt 1 starting" in result.output
    assert "Attempt 1 failed: ModuleNotFoundError" in result.output
    assert "Attempt 2 starting" in result.output
    assert "succeeded after 2 attempts" in result.output
    assert "$0.05" in result.output


def test_run_stream_task_failed():
    """Streaming should handle task_failed events."""
    mock_client = MagicMock()
    mock_client.post.return_value = _make_task_response()

    sse_events = [
        {"type": "attempt_start", "attempt": 1},
        {"type": "attempt_failed", "attempt": 1, "error_type": "RuntimeError"},
        {"type": "task_failed", "reason": "budget exhausted"},
    ]

    with patch("src.cli.main._http_client", return_value=mock_client), \
         patch("httpx.stream", return_value=FakeSSEStream(sse_events)):
        result = runner.invoke(app, ["run", "Fix the build", "--stream"])

    assert result.exit_code == 0
    assert "Task failed: budget exhausted" in result.output


def test_run_stream_fallback_to_poll():
    """When SSE fails, run should fall back to polling."""
    mock_create_resp = _make_task_response()
    mock_poll_resp = MagicMock()
    mock_poll_resp.json.return_value = {
        "id": "task-abc",
        "status": "succeeded",
        "total_attempts": 3,
        "total_cost_usd": 0.12,
        "result": "All bugs fixed",
    }
    mock_poll_resp.raise_for_status = MagicMock()

    mock_client = MagicMock()
    mock_client.post.return_value = mock_create_resp
    mock_client.get.return_value = mock_poll_resp

    with patch("src.cli.main._http_client", return_value=mock_client), \
         patch("httpx.stream", side_effect=Exception("SSE not available")):
        result = runner.invoke(app, ["run", "Fix the build", "--stream"])

    assert result.exit_code == 0
    assert "SSE unavailable" in result.output
    assert "succeeded after 3 attempts" in result.output


def test_run_no_stream():
    """run --no-stream should poll instead of SSE."""
    mock_create_resp = _make_task_response()
    mock_poll_resp = MagicMock()
    mock_poll_resp.json.return_value = {
        "id": "task-abc",
        "status": "succeeded",
        "total_attempts": 2,
        "total_cost_usd": 0.03,
    }
    mock_poll_resp.raise_for_status = MagicMock()

    mock_client = MagicMock()
    mock_client.post.return_value = mock_create_resp
    mock_client.get.return_value = mock_poll_resp

    with patch("src.cli.main._http_client", return_value=mock_client):
        result = runner.invoke(app, ["run", "Fix the build", "--no-stream"])

    assert result.exit_code == 0
    assert "succeeded after 2 attempts" in result.output


def test_run_alternative_event_names():
    """SSE events may use alternative naming conventions."""
    mock_client = MagicMock()
    mock_client.post.return_value = _make_task_response()

    sse_events = [
        {"type": "attempt_started", "attempt_number": 1},
        {"type": "attempt_failure", "attempt_number": 1, "error": "TypeError"},
        {"type": "task_success", "attempts": 2, "cost": 0.08},
    ]

    with patch("src.cli.main._http_client", return_value=mock_client), \
         patch("httpx.stream", return_value=FakeSSEStream(sse_events)):
        result = runner.invoke(app, ["run", "Fix types", "--stream"])

    assert result.exit_code == 0
    assert "Attempt 1 starting" in result.output
    assert "Attempt 1 failed: TypeError" in result.output
    assert "succeeded after 2 attempts" in result.output
