"""Tests for the REJD core loop against mock providers.

These tests simulate the full Retrieve-Execute-Judge-Distill cycle using
deterministic mock providers. They verify loop control logic (circuit breaker,
budget enforcement, max retries) without any real I/O.
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from src.models import (
    Attempt,
    AttemptStatus,
    ErrorCategory,
    ErrorSignature,
    FailureAnalysis,
    FailureRecord,
    SuccessRecord,
    Task,
    TaskStatus,
)
from src.providers.base import ExecutionResult
from tests.conftest import (
    InMemoryBackend,
    MockLLMProvider,
    MockSandboxProvider,
    make_failure_record,
)


# ---------------------------------------------------------------------------
# Minimal REJD loop implementation used only by tests
# (reflects the architecture described in CLAUDE.md without importing
# not-yet-implemented src/core/agent.py)
# ---------------------------------------------------------------------------

class REJDResult:
    def __init__(
        self,
        success: bool,
        attempts: int,
        total_cost: float,
        abandoned: bool = False,
        abandon_reason: str = "",
    ) -> None:
        self.success = success
        self.attempts = attempts
        self.total_cost = total_cost
        self.abandoned = abandoned
        self.abandon_reason = abandon_reason


class SimpleREJDLoop:
    """A minimal REJD loop that exercises the same control-flow as the real agent.

    Retrieve  — query memory for similar past failures
    Execute   — run command in sandbox
    Judge     — classify result as success or failure
    Distill   — store failure record; loop or succeed

    Parameters
    ----------
    memory:
        MemoryBackend instance.
    sandbox:
        SandboxProvider instance.
    llm:
        LLMProvider (used for fix generation; not heavily exercised here).
    commands:
        Ordered list of (command, ExecutionResult) pairs representing the
        steps the agent will run each attempt.  The loop iterates through
        them in order; once exhausted the task succeeds.
    circuit_breaker_threshold:
        Consecutive identical-error-hash failures before abandoning.
    """

    def __init__(
        self,
        memory: InMemoryBackend,
        sandbox: MockSandboxProvider,
        llm: MockLLMProvider,
        commands: list[tuple[str, ExecutionResult]],
        circuit_breaker_threshold: int = 3,
    ) -> None:
        self.memory = memory
        self.sandbox = sandbox
        self.llm = llm
        self.commands = list(commands)
        self.circuit_breaker_threshold = circuit_breaker_threshold
        self._consecutive_same_error: int = 0
        self._last_error_hash: str = ""

    async def run(self, task: Task) -> REJDResult:
        sandbox_id = await self.sandbox.create()
        attempt_num = 0
        total_cost = 0.0

        while task.current_attempt <= task.max_retries:
            # Budget guard
            if total_cost >= task.max_budget_usd:
                return REJDResult(
                    success=False,
                    attempts=attempt_num,
                    total_cost=total_cost,
                    abandoned=True,
                    abandon_reason="budget_exceeded",
                )

            # Max retries guard
            if task.current_attempt > task.max_retries:
                return REJDResult(
                    success=False,
                    attempts=attempt_num,
                    total_cost=total_cost,
                    abandoned=True,
                    abandon_reason="max_retries_exceeded",
                )

            task.current_attempt += 1
            attempt_num += 1

            # --- RETRIEVE ---
            past_failures = await self.memory.get_failures_for_task(task.id)

            # --- EXECUTE ---
            if not self.commands:
                # No more commands → task succeeded
                task.status = TaskStatus.SUCCEEDED
                await self.memory.store_success(
                    SuccessRecord(
                        task_id=task.id,
                        attempt_number=attempt_num,
                        solution={"approach": "all steps completed"},
                        learning={"failure_count": len(past_failures)},
                    )
                )
                return REJDResult(success=True, attempts=attempt_num, total_cost=total_cost)

            cmd, result = self.commands.pop(0)
            cost_this_attempt = 0.001 * attempt_num
            total_cost += cost_this_attempt

            # --- JUDGE ---
            if result.success:
                # Pop remaining commands means success — but simulate one pass
                task.status = TaskStatus.SUCCEEDED
                await self.memory.store_success(
                    SuccessRecord(
                        task_id=task.id,
                        attempt_number=attempt_num,
                        solution={"command": cmd, "output": result.stdout},
                        learning={"failure_count": len(past_failures)},
                    )
                )
                return REJDResult(success=True, attempts=attempt_num, total_cost=total_cost)

            # --- DISTILL (failure path) ---
            error_type = "CommandError"
            error_message = result.stderr or result.stdout
            sig = ErrorSignature(
                error_type=error_type,
                error_message=error_message,
                error_category=ErrorCategory.UNKNOWN,
            )
            failure = FailureRecord(
                task_id=task.id,
                attempt_number=attempt_num,
                signature=sig,
                analysis=FailureAnalysis(
                    root_cause=error_message,
                    what_was_tried=cmd,
                    why_it_failed=error_message,
                    suggested_fix="unknown",
                    confidence=0.5,
                ),
                cost_usd=cost_this_attempt,
            )
            await self.memory.store_failure(failure)

            # Circuit breaker check
            if sig.error_hash == self._last_error_hash:
                self._consecutive_same_error += 1
            else:
                self._consecutive_same_error = 1
                self._last_error_hash = sig.error_hash

            if self._consecutive_same_error >= self.circuit_breaker_threshold:
                task.status = TaskStatus.ABANDONED
                return REJDResult(
                    success=False,
                    attempts=attempt_num,
                    total_cost=total_cost,
                    abandoned=True,
                    abandon_reason="circuit_breaker",
                )

        return REJDResult(
            success=False,
            attempts=attempt_num,
            total_cost=total_cost,
            abandoned=True,
            abandon_reason="max_retries_exceeded",
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fail(message: str) -> ExecutionResult:
    return ExecutionResult(exit_code=1, stdout="", stderr=message)


def _ok(output: str = "ok") -> ExecutionResult:
    return ExecutionResult(exit_code=0, stdout=output, stderr="")


# ---------------------------------------------------------------------------
# REJD Loop Flow Tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_rejd_task_succeeds_on_first_attempt():
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    llm = MockLLMProvider()
    task = Task(instruction="run a passing command", max_retries=5, max_budget_usd=1.0)

    loop = SimpleREJDLoop(
        memory, sandbox, llm,
        commands=[("npm run build", _ok("Build succeeded"))],
    )
    result = await loop.run(task)

    assert result.success is True
    assert result.attempts == 1
    assert result.abandoned is False


@pytest.mark.asyncio
async def test_rejd_task_fails_then_succeeds():
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    llm = MockLLMProvider()
    task = Task(instruction="fix the project", max_retries=5, max_budget_usd=1.0)

    loop = SimpleREJDLoop(
        memory, sandbox, llm,
        commands=[
            ("npm run build", _fail("Module not found: sharp")),
            ("npm install sharp && npm run build", _ok("Build succeeded")),
        ],
    )
    result = await loop.run(task)

    assert result.success is True
    assert result.attempts == 2

    # Failure from attempt 1 was stored
    failures = await memory.get_failures_for_task(task.id)
    assert len(failures) == 1
    assert "sharp" in failures[0].signature.error_message

    # Success record was stored
    stats = await memory.get_stats()
    assert stats.total_successes == 1


@pytest.mark.asyncio
async def test_rejd_failure_stored_in_memory_each_attempt():
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    llm = MockLLMProvider()
    task = Task(instruction="multi-step failing task", max_retries=10, max_budget_usd=1.0)

    loop = SimpleREJDLoop(
        memory, sandbox, llm,
        commands=[
            ("step1", _fail("Error A")),
            ("step2", _fail("Error B")),
            ("step3", _fail("Error C")),
            ("step4", _ok()),
        ],
    )
    result = await loop.run(task)

    assert result.success is True
    assert result.attempts == 4

    failures = await memory.get_failures_for_task(task.id)
    assert len(failures) == 3


@pytest.mark.asyncio
async def test_rejd_memory_recall_on_retry():
    """Memory backend is queried before each retry attempt."""
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    llm = MockLLMProvider()
    task = Task(instruction="test memory recall", max_retries=5, max_budget_usd=1.0)

    # Pre-seed memory with a relevant past failure
    past_failure = make_failure_record(
        task_id=task.id,
        attempt_number=0,
        error_type="ModuleNotFoundError",
        error_message="Module not found: sharp",
        suggested_fix="npm install sharp",
    )
    await memory.store_failure(past_failure)

    loop = SimpleREJDLoop(
        memory, sandbox, llm,
        commands=[("npm run build", _ok("Build succeeded"))],
    )
    result = await loop.run(task)

    assert result.success is True
    # Memory was already populated (the RETRIEVE step would surface this)
    failures = await memory.get_failures_for_task(task.id)
    assert len(failures) >= 1  # at minimum the pre-seeded record


# ---------------------------------------------------------------------------
# Circuit Breaker Tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_circuit_breaker_triggers_after_n_consecutive_same_errors():
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    llm = MockLLMProvider()
    task = Task(instruction="stuck task", max_retries=10, max_budget_usd=1.0)

    # Same error message → same hash → circuit breaker should trip at threshold=3
    same_error = "EADDRINUSE: port 3000"
    loop = SimpleREJDLoop(
        memory, sandbox, llm,
        commands=[
            ("start", _fail(same_error)),
            ("start", _fail(same_error)),
            ("start", _fail(same_error)),
            ("start", _fail(same_error)),  # never reached
        ],
        circuit_breaker_threshold=3,
    )
    result = await loop.run(task)

    assert result.success is False
    assert result.abandoned is True
    assert result.abandon_reason == "circuit_breaker"
    assert result.attempts == 3


@pytest.mark.asyncio
async def test_circuit_breaker_does_not_trigger_for_different_errors():
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    llm = MockLLMProvider()
    task = Task(instruction="varied errors", max_retries=10, max_budget_usd=1.0)

    loop = SimpleREJDLoop(
        memory, sandbox, llm,
        commands=[
            ("step1", _fail("Error A")),
            ("step2", _fail("Error B")),
            ("step3", _fail("Error C")),
            ("step4", _ok()),
        ],
        circuit_breaker_threshold=3,
    )
    result = await loop.run(task)

    assert result.success is True
    assert result.abandoned is False


@pytest.mark.asyncio
async def test_circuit_breaker_resets_on_different_error():
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    llm = MockLLMProvider()
    task = Task(instruction="reset test", max_retries=10, max_budget_usd=1.0)

    same_error = "same error"
    loop = SimpleREJDLoop(
        memory, sandbox, llm,
        commands=[
            ("s1", _fail(same_error)),
            ("s2", _fail(same_error)),
            ("s3", _fail("different error")),  # resets counter
            ("s4", _fail(same_error)),
            ("s5", _fail(same_error)),
            ("s6", _ok()),
        ],
        circuit_breaker_threshold=3,
    )
    result = await loop.run(task)

    assert result.success is True


# ---------------------------------------------------------------------------
# Budget Enforcement Tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_budget_exceeded_abandons_task():
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    llm = MockLLMProvider()
    # Very tight budget — costs 0.001*attempt per attempt, exceeds 0.002 on attempt 3
    task = Task(instruction="expensive task", max_retries=10, max_budget_usd=0.002)

    loop = SimpleREJDLoop(
        memory, sandbox, llm,
        commands=[
            ("cmd1", _fail("Error 1")),
            ("cmd2", _fail("Error 2")),
            ("cmd3", _fail("Error 3")),
        ],
    )
    result = await loop.run(task)

    assert result.success is False
    assert result.abandoned is True
    assert result.abandon_reason == "budget_exceeded"


@pytest.mark.asyncio
async def test_task_within_budget_succeeds():
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    llm = MockLLMProvider()
    task = Task(instruction="in-budget task", max_retries=5, max_budget_usd=1.0)

    loop = SimpleREJDLoop(
        memory, sandbox, llm,
        commands=[("cmd", _ok())],
    )
    result = await loop.run(task)

    assert result.success is True
    assert result.total_cost < task.max_budget_usd


# ---------------------------------------------------------------------------
# Max Retries Enforcement Tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_max_retries_exceeded_abandons_task():
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    llm = MockLLMProvider()
    task = Task(instruction="always failing", max_retries=3, max_budget_usd=10.0)

    loop = SimpleREJDLoop(
        memory, sandbox, llm,
        commands=[
            ("cmd1", _fail("Err A")),
            ("cmd2", _fail("Err B")),
            ("cmd3", _fail("Err C")),
            ("cmd4", _fail("Err D")),  # beyond max_retries
        ],
        circuit_breaker_threshold=100,
    )
    result = await loop.run(task)

    assert result.success is False
    assert result.abandoned is True
    # 3 retries consumed + 1 initial = at most 4 attempts, but max_retries=3
    assert result.attempts <= task.max_retries + 1


@pytest.mark.asyncio
async def test_succeeds_exactly_at_max_retries_boundary():
    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    llm = MockLLMProvider()
    task = Task(instruction="edge case", max_retries=3, max_budget_usd=10.0)

    loop = SimpleREJDLoop(
        memory, sandbox, llm,
        commands=[
            ("cmd1", _fail("Err A")),
            ("cmd2", _fail("Err B")),
            ("cmd3", _ok()),  # succeeds on attempt 3 (≤ max_retries)
        ],
        circuit_breaker_threshold=100,
    )
    result = await loop.run(task)

    assert result.success is True
    assert result.attempts == 3
