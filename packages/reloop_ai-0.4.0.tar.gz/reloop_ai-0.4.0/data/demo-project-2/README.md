# Demo Project 2 -- Cross-Project Transfer Demo

This is a **second** broken Next.js project used to demonstrate ReLoop's
cross-project failure transfer. It shares overlapping failure patterns with
`demo-project/` so the agent can leverage lessons learned from Project A
when tackling Project B.

---

## The 3 Deliberate Bugs

| # | File | Type | Expected Error |
|---|------|------|----------------|
| 1 | `package.json` | Dependency error | `Module not found: prisma` |
| 2 | `next.config.js` | Config error | `EADDRINUSE: port 3000` |
| 3 | `.env` | Config error | `REDIS_URL connection refused` |

### Bug 1 -- Missing `@prisma/client` dependency

`@prisma/client` is imported in `src/app/page.tsx` but is not listed in
`package.json`. This mirrors the "missing sharp" pattern from Project A.

```
Error: Module not found: Can't resolve '@prisma/client'
```

**Fix:** `npm install @prisma/client`

---

### Bug 2 -- Port 3000 conflict (same pattern as Project A)

`next.config.js` explicitly sets `port: 3000`. If the agent already learned
from Project A that port 3000 causes EADDRINUSE, it should proactively
change the port without needing to fail first.

```
Error: listen EADDRINUSE: address already in use :::3000
```

**Fix:** Change `port: 3000` to `port: 3002` in `next.config.js`.

---

### Bug 3 -- Invalid `REDIS_URL`

The `.env` file contains a deliberately wrong Redis connection string.
This mirrors the "bad DATABASE_URL" pattern from Project A -- a different
service, but the same category of config/env error.

```
Error: Connection refused at 127.0.0.1:6380
```

**Fix:** Replace `REDIS_URL` with a valid Redis connection string.

---

## Demo Flow: Cross-Project Transfer

### Without Transfer (agent has no memory from Project A)

```
Attempt 1 -> FAIL  (Missing prisma)
Attempt 2 -> FAIL  (Port conflict)
Attempt 3 -> FAIL  (Bad REDIS_URL)
Attempt 4 -> SUCCESS
```

### With Transfer (agent has memory from Project A)

```
Attempt 1 -> SUCCESS  (Agent recalls: missing deps -> install them,
                        port 3000 -> change it, bad env vars -> fix them)
```

Timeline comparison: 4 attempts vs 1 attempt. The memory transfers.
