/** @type {import('next').NextConfig} */

// BUG 2: Port 3000 is already in use (same pattern as demo-project).
// An agent that learned from Project A should proactively change this.
const nextConfig = {
  reactStrictMode: true,
  serverRuntimeConfig: {
    // port 3000 is already in use — this will cause EADDRINUSE: port 3000
    port: 3000,
  },
};

module.exports = nextConfig;
