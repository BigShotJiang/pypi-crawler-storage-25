// BUG 1: @prisma/client is imported but NOT listed in package.json.
// This mirrors the "missing sharp" pattern from demo-project.
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export default async function Home() {
  // BUG 3 surfaces here at runtime: REDIS_URL points to a non-existent Redis instance.
  // The ioredis connection will fail with "Connection refused".
  const Redis = (await import("ioredis")).default;
  const redis = new Redis(process.env.REDIS_URL || "redis://127.0.0.1:6380");

  let status = "unknown";
  try {
    await redis.ping();
    status = "connected";
  } catch {
    status = "connection failed";
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="mb-8 text-4xl font-bold">Demo Project 2</h1>
      <p className="text-gray-600">Redis status: {status}</p>
      <p className="mt-4 text-sm text-gray-400">
        This project has 3 deliberate bugs for the cross-project transfer demo.
      </p>
    </main>
  );
}
