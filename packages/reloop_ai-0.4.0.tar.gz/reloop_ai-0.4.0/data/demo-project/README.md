# Demo Next.js Project — ReLoop Self-Healing Demo

This is a minimal Next.js project with **4 deliberate bugs** used to demonstrate
[ReLoop](../../README.md)'s self-healing capabilities. The agent detects each
failure, stores it in failure memory, and retries with accumulated knowledge until
the project builds and runs successfully.

---

## The 4 Deliberate Bugs

| # | File | Type | Expected Error |
|---|------|------|----------------|
| 1 | `package.json` | Dependency error | `Module not found: sharp` |
| 2 | `next.config.js` | Config error | `EADDRINUSE: port 3000` |
| 3 | `src/app/page.tsx` | TypeScript type error | `Type 'number' is not assignable to type 'string'` |
| 4 | `.env` | Config error | `Connection refused` (bad DATABASE_URL) |

### Bug 1 — Missing `sharp` dependency

`sharp` is required by Next.js for image optimisation when `next/image` is used
with `unoptimized: false` (the default). It is intentionally absent from
`package.json`.

```
Error: Module not found: Can't resolve 'sharp'
```

**Fix:** `npm install sharp`

---

### Bug 2 — Port 3000 conflict

`next.config.js` explicitly sets `port: 3000` in `serverRuntimeConfig`. If
another process is already bound to port 3000 (common in dev environments), the
server fails immediately on startup.

```
Error: listen EADDRINUSE: address already in use :::3000
```

**Fix:** Change `port: 3000` to `port: 3001` in `next.config.js`.

---

### Bug 3 — TypeScript type mismatch

In `src/app/page.tsx`, the variable `userId` is declared with type `string` but
assigned the numeric literal `42`.

```
Type error: Type 'number' is not assignable to type 'string'.
```

**Fix:** Change `const userId: string = 42` to either `const userId: string = "42"`
or `const userId: number = 42`.

---

### Bug 4 — Invalid `DATABASE_URL`

The `.env` file contains a deliberately wrong connection string:

```
DATABASE_URL=postgres://wrong:wrong@localhost:5432/nonexistent
```

The database `nonexistent` does not exist and the credentials are invalid, causing
a connection failure at runtime.

```
Error: Connection refused / password authentication failed for user "wrong"
```

**Fix:** Replace `DATABASE_URL` with a valid PostgreSQL connection string.

---

## Expected ReLoop Demo Flow

```
Attempt 1 → FAIL  (Missing sharp — captured in failure memory)
Attempt 2 → FAIL  (Port conflict — captured, sharp fix injected from memory)
Attempt 3 → FAIL  (TS type error — captured, port fix injected from memory)
Attempt 4 → SUCCESS (All failures addressed via memory-informed retry)
```

Timeline: RED → RED → RED → GREEN

See `expected-errors.json` for the machine-readable error manifest.
