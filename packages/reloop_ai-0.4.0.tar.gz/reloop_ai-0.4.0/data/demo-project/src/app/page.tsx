import Image from "next/image";

// BUG 3: TypeScript type error — `userId` is declared as string but assigned a number.
// tsc will report: Type 'number' is not assignable to type 'string'
const userId: string = 42;

interface WelcomeProps {
  title: string;
}

function WelcomeCard({ title }: WelcomeProps) {
  return (
    <div className="rounded-lg border p-6 shadow-sm">
      <h2 className="text-xl font-semibold">{title}</h2>
      <p className="mt-2 text-gray-600">User ID: {userId}</p>
    </div>
  );
}

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="mb-8 text-4xl font-bold">Demo Next.js App</h1>

      {/* BUG 1 surfaces here: next/image requires `sharp` for optimisation */}
      <Image
        src="/placeholder.png"
        alt="Placeholder"
        width={200}
        height={200}
        priority
      />

      <WelcomeCard title="Hello from ReLoop demo" />

      <p className="mt-8 text-sm text-gray-400">
        This project has 4 deliberate bugs for the ReLoop self-healing demo.
      </p>
    </main>
  );
}
