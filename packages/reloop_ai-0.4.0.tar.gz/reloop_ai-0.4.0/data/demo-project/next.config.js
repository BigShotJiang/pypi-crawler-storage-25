/** @type {import('next').NextConfig} */

// BUG 2: Port 3000 is already in use on this machine (e.g. another dev server).
// Setting port: 3000 here will cause EADDRINUSE error on startup.
const nextConfig = {
  reactStrictMode: true,
  serverRuntimeConfig: {
    // port 3000 is already in use — this will cause EADDRINUSE: port 3000
    port: 3000,
  },
  images: {
    // next/image optimization requires the `sharp` package at runtime
    // BUG 1 surfaces when any page uses next/image (see page.tsx)
    unoptimized: false,
  },
};

module.exports = nextConfig;
