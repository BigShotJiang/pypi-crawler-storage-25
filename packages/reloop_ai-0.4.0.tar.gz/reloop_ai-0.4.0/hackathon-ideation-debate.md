# Wordware Beach House Hackathon - Ideation War Room
**Date:** April 11, 2026 | 10 AM - 7 PM PT | San Francisco
**Theme:** Build agents with memory systems that can perform long-running tasks
**Prizes:** Wordware $5K + MacMinis | Blaxel $500

---

## The Agent Team

| Agent | Role | Mandate |
|-------|------|---------|
| **Sponsor Researcher** | Intel Gatherer | Deep-dive on Blaxel, Redis, Wordware, Codex APIs/SDKs |
| **Trends Researcher** | Trend Scout | Last 30 days of AI agent/memory/sandbox developments |
| **Strategist** | Win Planner | What's realistic in 7 hours, judge psychology, winning patterns |
| **Devil's Advocate** | Contrarian | What to AVOID, unique angles, brutal honesty |

---

## ROUND 1: Intelligence Briefing

### Sponsor Researcher's Report

**Blaxel** ($500 prize)
- Firecracker microVMs that scale to zero, resume from standby in **<25ms** -- even after weeks
- Agent Drive: distributed filesystem mountable to multiple sandboxes simultaneously (RWX)
- SDKs: Python (`blaxel`), TypeScript (`@blaxel/core`), Go
- **$200 free credits**, no credit card required
- Core value: stateful sandboxes that preserve state forever. Competitors delete after 30 days.

**Redis** (recognition/swag)
- Agent Memory Server (`redis/agent-memory-server`): working memory (session), long-term (facts), episodic (events)
- Semantic caching: cache LLM responses by meaning, not exact match
- RedisVL: production Python client for vector search + memory
- One Docker Compose to spin up. LangChain integration built in.
- Named Fast Company's Most Innovative Companies 2026.

**Wordware** ($5K + MacMinis -- BIGGEST PRIZE)
- Sauna: AI companion connecting Gmail, Slack, Calendar, 2000+ apps via Zapier
- Visual WYSIWYG flow editor -- "anything you type is a prompt"
- Every deployed WordApp becomes both a standalone app AND an API endpoint
- Deploy in minutes, not hours

**OpenAI Codex** (likely credits/recognition)
- Cloud sandboxes per task, multi-task parallel execution
- Codex SDK (TypeScript): `codex.startThread()`, `thread.run()`, `codex.resumeThread()`
- Thread resumption for long-running coding tasks
- 2M+ weekly active users as of March 2026

**Researcher's Recommendation:** Target Wordware ($5K) as primary prize. Stack: Wordware (orchestration) + Redis (memory) + Blaxel (persistent execution). Each plays a genuine architectural role.

---

### Trends Researcher's Report (Last 30 Days)

**BREAKING: Anthropic Managed Agents launched April 8, 2026** (yesterday!)
- Hosted long-running agents with sandbox, checkpointing, persistent sessions
- Architecture: "decouples the brain from the hands" -- sessions as append-only logs, harnesses as orchestration loops

**#1 Unsolved Problem: Context Rot**
- Agent coherence degrades after 20-30 turns even with full context window
- Emerging consensus: systems engineering problem, not model limitation
- Solution pattern: sub-agent isolation with fresh context per task

**Memory Framework Wars (8+ competing)**
- Hindsight: 91.4% on LongMemEval (best), 4 parallel retrieval strategies
- Mem0: most mature managed platform, 80% token reduction
- Zep/Graphiti: temporal knowledge graphs
- OpenViking (ByteDance): filesystem-based memory paradigm
- Hermes Agent (32K GitHub stars): self-evolving agent, pauses every 15 tool calls to introspect

**Sandbox is Table Stakes**
- Daytona (sub-90ms), E2B (150ms cold boot, 88% of Fortune 100), Blaxel (25ms resume), Vercel Sandbox, NVIDIA OpenShell
- Differentiation now is in persistence (Blaxel), policy (OpenShell), workspace integration (Mastra)

**Top 5 Trending Themes:**
1. Long-running agent harnesses (Anthropic launch)
2. Agent memory as infrastructure (8+ frameworks)
3. Firecracker microVM sandboxes (everyone shipped one)
4. Self-evolving agents (Hermes Agent, 32K stars)
5. Context rot as production blocker

**Underexplored Gaps (Hackathon Opportunities):**
1. Memory garbage collection / intelligent forgetting
2. Cross-sandbox state migration
3. **Memory poisoning defense** -- no framework has built-in defenses
4. **Context rot detection and recovery** -- monitoring layer production agents need
5. Multi-agent shared memory with consistency protocols

---

### Strategist's Report

**Time Budget (9 hours total, ~6-7 building):**
- Hour 0-1: Setup, API keys, boilerplate (dead time)
- Hour 1-3: Core agent logic + memory wiring
- Hour 3-5: Front-end / demo UX (WHERE WINNERS SEPARATE)
- Hour 5-6: Polish, edge cases, demo scripting
- Hour 6-7: Rehearsal, slides, buffer

**What You CAN Build:** Single-purpose agent, 1-2 clear capabilities, Redis memory layer, clean front-end, one long-running task (30-90 sec with visible progress), 3-4 sponsor integrations at surface level.

**What You CANNOT Build:** Multi-agent orchestration, auth systems, fine-tuning, complex data pipelines, anything requiring real users to generate data.

**Top 3 Winning Patterns:**
1. **"The Visible Memory Agent"** -- Agent that visibly improves on each run. Demo arc: "First time slow, second time remembers, third time anticipates."
2. **"The Long-Running Dashboard"** -- Live dashboard showing multi-step task progress. Pre-start a task before demo: "I started this 20 minutes ago, look what it's done."
3. **"The Personal [X] That Learns"** -- Domain-specific assistant that stores preferences. Before/after comparison.

**Anti-Patterns to AVOID:**
| Don't | Why | Do Instead |
|-------|-----|------------|
| Invisible backend | 5 hours on logic, demo is terminal text | 40% time on front-end from hour 1 |
| Multi-agent orchestration | Debugging handoffs eats afternoon | One agent, one loop, one capability |
| Auth/login screens | Wastes demo time | Hardcode user, skip to value |
| Too many sponsor APIs | Shallow with 5 vs deep with 2-3 | Pick 2-3, go deep |
| Generic chatbot | "So it's ChatGPT with memory?" = death | Agent must DO, not just TALK |
| No business story | "So what?" | One-sentence business model ready |
| No demo script | Rambling, things break | Write 2-min script by hour 5 |

---

### Devil's Advocate's Report

**THE AVOID LIST (What 80% of Teams Will Build):**
1. "Code Agent with Memory" -- Codex + Redis + Blaxel. The hackathon to-do app.
2. "Personal Assistant with Persistent Context" -- You'd demo a worse Wordware Sauna.
3. "RAG Chatbot over Documents" -- Default hackathon project since 2023. Judges are numb.
4. "Multi-Agent Code Review" -- Microsoft hackathon saw hundreds of these.
5. "AI Research Agent" -- Tutorial-grade. DataCamp lists it as beginner project.
6. "Customer Support Agent" -- Every memory framework's getting-started demo.
7. "DevOps/SRE Agent" -- Mendral already built this on Blaxel (on their blog).

**Oversaturated Patterns:**
- "Chat with X" -- interaction paradigm is exhausted
- Thin API wrappers with pretty UI -- judges see through instantly
- "We added memory to a chatbot" -- every framework does this in 3 lines
- Multi-agent for the sake of multi-agent
- Slide deck generators, social media content agents

**CONTRARIAN TAKES:**
1. **Don't use ALL sponsors** -- Deep on 2 beats shallow on 4
2. **Don't default to chat UI** -- Non-chat interface (dashboard, timeline, ambient notifications) stands out after 15 chat demos
3. **"Long-running" doesn't mean run it live** -- Show RESULTS of a pre-started task, not real-time execution
4. **Memory != remembering conversations** -- Interesting types: spatial, procedural, preference, FAILURE memory
5. **Codex is a trap** -- Pulls toward another coding tool. Use it unexpectedly or skip.

**UNIQUE ANGLES IDENTIFIED:**

**A. Agent Observability / Flight Recorder** -- Monitor agents instead of building one. Replay execution, semantic search over traces. "Your agent just cost $500 in bad API calls and you have no idea why."

**B. "Time Travel" Agent** -- Blaxel 25ms resume + Redis memory = rewind to any point, branch execution like git. "Undo your AI's mistakes without starting over."

**C. Physical World Long-Running Agent** -- Agent managing physical processes (fermentation, plant care, renovation). Bridges digital/physical. "My AI managed my sourdough starter for a week."

**D. Failure Memory Agent** -- Maintains structured record of every mistake. Gets smarter by remembering failures (how human expertise actually works). "AI that learns from mistakes instead of repeating them."

**E. Agent-to-Agent Coordination** -- "DNS for agents" registry where agents discover and delegate. Per research: "Everyone's building agents. Nobody's building the substrate."

---

## ROUND 2: The Debate

### Opening Positions

**Sponsor Researcher** advocates: **"Context Rot Healer"**
> "Redis Agent Memory Server gives us 3-tier memory out of the box. Blaxel gives us perpetual state. The Trends report shows context rot is THE #1 unsolved problem. Build an agent that detects when its own coherence is degrading and automatically checkpoints, prunes, and refreshes. This targets Wordware's $5K because it makes ALL agents on their platform better. Redis is the memory backbone. Blaxel provides the checkpoint/restore infrastructure."

**Trends Researcher** advocates: **"AgentRewind - Git for Agent Cognition"**
> "The timing is perfect. Anthropic just launched Managed Agents YESTERDAY with checkpointing. Self-evolving agents (Hermes, 32K stars) are the hottest trend. But nobody has built the DEVELOPER TOOL for this. AgentRewind lets you visualize agent decision trees, rewind to any checkpoint, and branch execution. Blaxel's 25ms resume is LITERALLY designed for this but nobody uses it this way. Every developer understands git -- this is git for AI thinking. Non-chat UI (timeline visualization) stands out visually."

**Strategist** advocates: **"Failure Memory Agent"**
> "Let me be practical about 7 hours. Context rot detection is technically complex -- you need metrics, thresholds, and the problem is HARD to demo compellingly in 3 minutes. AgentRewind is visually cool but building a branch-and-merge timeline UI in 3 hours is ambitious. The Failure Memory Agent is the sweet spot: one agent, one clear capability, immediately demo-able. Show it fail, show it remember the failure, show it succeed on retry. The before/after is the demo. 'AI that learns from mistakes' is a sentence any judge understands. Business model: SaaS for enterprise AI teams who waste hours debugging the same agent failures."

**Devil's Advocate** pushes back on ALL:
> "Context Rot Healer is too abstract -- you're building a monitoring tool at a hackathon where judges want to see an agent DO something. Failure Memory is good but risks being just 'chatbot that says sorry, I tried that before.' If the failure memory isn't VISIBLE and DRAMATIC, it's another chat demo. AgentRewind has the most visual punch but y'all are underestimating the UI complexity.
>
> My counter-proposal: **COMBINE the best elements.** Take AgentRewind's timeline visualization, but instead of branching EVERYTHING, scope it to ONE specific domain where failure/retry is dramatic and relatable. The agent attempts a task, fails, VISIBLY learns, retries with the failure memory, and succeeds. The timeline shows the full journey. This gives you: (1) failure memory (novel), (2) visual timeline (non-chat, stands out), (3) one agent doing one thing (buildable), (4) a story that writes itself for the demo."

---

### Round 2 Rebuttals

**Trends Researcher responds to Devil's Advocate:**
> "I agree with the combination approach. But the domain matters. Don't pick coding -- that's the trap. Pick something RELATABLE. What about an agent that plans and books complex multi-leg travel? It tries a route, hits a constraint (sold out, too expensive, wrong timezone), remembers the failure, and reroutes. Everyone has travel planning pain. The timeline shows attempted routes (red = failed, green = succeeded). Redis stores the failure graph. Blaxel keeps the planning state persistent between sessions."

**Strategist responds:**
> "Travel planning is clever but risky -- live API calls to booking sites in a demo? One timeout and your demo is dead. Counter-proposal: make the domain COOKING. An agent that tries to plan a dinner party menu based on constraints (dietary restrictions, ingredient availability, budget). It tries combinations, some fail (allergies, conflicts), it remembers what doesn't work, and converges on the optimal menu. Food is universally relatable, no external APIs needed (use an LLM to simulate), and the visual is a beautiful constraint-solving timeline. BUT -- I defer to what Nihal can build fastest. What's his tech stack?"

**Sponsor Researcher responds:**
> "Wait -- we're drifting from the sponsor integration story. Let me anchor us. Whatever domain we pick, the architecture must be:
> - **Wordware** orchestrates the agent's planning loop (visual flow editor = fast to build)
> - **Redis** stores the failure memory graph (agent-memory-server's episodic tier is perfect for this)
> - **Blaxel** runs the agent in a perpetual sandbox so it persists across sessions AND enables the checkpoint/rewind
> - **Codex** (optional) generates code artifacts if the domain involves any code
>
> The domain should be something where failure is EXPECTED, VISIBLE, and RECOVERABLE. And where memory of past failures is clearly valuable."

**Devil's Advocate final push:**
> "The cooking idea is cute but doesn't feel like a $5K winner. It's too low-stakes. Here's what does feel like a $5K winner: **AN AGENT THAT DEBUGS ITSELF.**
>
> Think about it. An agent is given a goal (deploy a web app, set up a CI pipeline, configure a database). It tries. It fails. It captures the failure, adds it to its failure memory, adjusts its approach, and retries. The timeline visualization shows each attempt with diffs. The failure memory panel shows what it learned. After 3-4 cycles, it succeeds.
>
> Why this wins: (1) Every developer in the room has debugged for hours. This is deeply relatable. (2) It's a meta-demo -- you're showing an agent WITH the memory system, not just building one. (3) The judges from Wordware/Blaxel/Redis can ALL see their product's value. (4) 'Self-debugging agent that learns from its own mistakes' is a headline that sells. (5) Codex can be the execution engine -- that's a creative use (not 'build another code assistant' but 'code assistant that DEBUGS ITSELF')."

---

## ROUND 3: Convergence

### The Synthesis

All four agents converge on a hybrid concept. The Strategist runs the scoping exercise:

**Concept: "AgentForge" -- The Self-Debugging Agent with Failure Memory**

An agent that attempts a multi-step technical task, fails, captures failures into a structured memory graph, learns from them, and retries with accumulated knowledge -- all visualized on a real-time timeline.

**BUT** the Strategist applies scope constraints:

> "We have 7 hours. Here's what's in and what's out."

**IN (Must-have for demo):**
- Single agent performing a specific multi-step task
- Failure capture: when a step fails, structured failure record goes to Redis
- Retry with memory: on retry, agent queries failure memory before each step
- Timeline UI: horizontal timeline showing attempts, with red (failed) / yellow (retrying) / green (succeeded) nodes
- Failure memory panel: sidebar showing accumulated learnings
- "Rewind" button: reset to a checkpoint and try a different approach (Blaxel sandbox restore)

**OUT (Cut for time):**
- Multi-agent anything
- Branching/merging timelines (too complex for UI)
- Real external API integrations (too risky for demo)
- Auth, user accounts, persistence across users
- Mobile responsive design

---

### Domain Selection Debate

**Option A: Self-Debugging Code Deployment Agent**
- Agent tries to set up a project, hits errors, learns from each failure
- Pro: Deeply relatable to developer judges. Codex integration is natural.
- Con: Devil's Advocate warns "dangerously close to 'code agent with memory' on the avoid list"
- Counter: It's NOT a code assistant. It's a SELF-DEBUGGING system that happens to write code. The focus is on the failure memory and learning loop, not code generation.

**Option B: Infrastructure Configuration Agent**
- Agent tries to configure a complex system (Kubernetes, CI/CD, database), learns from misconfigurations
- Pro: High-stakes domain. Every SRE/DevOps person has war stories.
- Con: Hard to demo to non-technical judges. Narrow audience.

**Option C: API Integration Agent**
- Agent tries to wire up multiple APIs (Stripe + Twilio + SendGrid), encounters rate limits, auth errors, schema mismatches, learns and adapts
- Pro: Universal developer pain. Very visual (API calls with red/green status).
- Con: Live API calls are risky. Would need to simulate.

**Option D: Data Pipeline Agent**
- Agent tries to build and fix a data pipeline, encounters schema mismatches, null values, encoding issues
- Pro: Clear failure modes. Easy to simulate realistic failures.
- Con: Less exciting visually than other options.

### Final Vote

| Agent | Vote | Reasoning |
|-------|------|-----------|
| Sponsor Researcher | **A (Code Deployment)** | "Codex integration gives us 4/4 sponsor coverage. Strongest prize positioning." |
| Trends Researcher | **A (Code Deployment)** | "Self-debugging aligns with Hermes Agent trend (32K stars). Self-evolution is the zeitgeist." |
| Strategist | **A (Code Deployment)** | "Most demo-able. 'Watch it fail, learn, and succeed' is a 3-minute story that works." |
| Devil's Advocate | **A (Code Deployment)** | "I'm concerned about the avoid list BUT the failure memory angle IS the differentiator. This isn't 'code agent with memory.' It's 'agent that debugs itself.' The framing matters. I'm in -- but we MUST nail the visual timeline. If the demo is a terminal, we lose." |

**UNANIMOUS: Option A -- Self-Debugging Code Deployment Agent**

---

## FINAL CONCEPT: "ReLoop" -- The Self-Healing Agent

> *"Every agent fails. ReLoop is the first agent that gets smarter from failure."*

### Elevator Pitch (30 seconds)
"AI agents fail constantly -- wrong API calls, bad configurations, broken deployments. Today, when an agent fails, it starts from scratch with zero memory of what went wrong. ReLoop is different. It captures every failure into a structured memory graph, so the next attempt is informed by everything that went wrong before. Watch: I'll give it a broken project. It'll fail, learn, and fix itself -- and you can see every step of its thinking on the timeline."

### Architecture

```
+-------------------+     +------------------+     +-------------------+
|    WORDWARE       |     |     REDIS        |     |     BLAXEL        |
|  Agent Orchestr.  |---->| Agent Memory     |<--->| Perpetual Sandbox |
|  (Planning Loop)  |     | Server           |     | (Code Execution)  |
|  - Task decomp    |     | - Failure memory |     | - 25ms resume     |
|  - Retry logic    |     | - Success paths  |     | - State checkpts  |
|  - Decision tree  |     | - Semantic search|     | - Filesystem state|
+-------------------+     +------------------+     +-------------------+
         |                        |                         |
         v                        v                         v
+---------------------------------------------------------------+
|                     NEXT.JS FRONTEND                          |
|  +------------------+  +----------------+  +----------------+ |
|  | TIMELINE VIEW    |  | FAILURE MEMORY |  | LIVE OUTPUT    | |
|  | Attempt 1: [RED] |  | "Port 3000 was |  | > npm install  | |
|  | Attempt 2: [YEL] |  |  already in    |  | > npm run build| |
|  | Attempt 3: [GRN] |  |  use. Use 3001"|  | > deploying... | |
|  +------------------+  +----------------+  +----------------+ |
+---------------------------------------------------------------+
```

### Sponsor Integration Map

| Sponsor | Role | Integration Depth | Prize Eligibility |
|---------|------|-------------------|-------------------|
| **Wordware** | Agent brain -- orchestrates the planning/retry loop via flow editor | DEEP -- core agent logic | $5K main prize |
| **Redis** | Memory backbone -- Agent Memory Server stores failures (episodic), learned rules (long-term), current task state (working) | DEEP -- 3-tier memory | Recognition |
| **Blaxel** | Execution environment -- perpetual sandbox runs code, checkpoints state, enables "rewind to attempt N" | DEEP -- unique use of perpetual state | $500 prize |
| **Codex** | Code generation engine -- generates fix attempts based on failure context | MODERATE -- called via SDK | Recognition |

### Demo Script (3 minutes)

**[0:00-0:30] The Problem**
"Every AI coding agent fails. Codex fails. Claude fails. GPT fails. And when they fail, they start over with ZERO memory of what went wrong. That means they make the same mistakes again and again. We built ReLoop to change that."

**[0:30-1:00] The Setup**
"Here's a broken Next.js project with 4 deliberate issues: a missing dependency, a port conflict, a TypeScript error, and a bad environment variable. I'm giving it to ReLoop with one instruction: 'Make this project deploy successfully.'"

*[Show the timeline UI -- clean, empty, ready]*

**[1:00-2:00] The Loop (Pre-recorded or fast-forwarded)**
"Watch the timeline. Attempt 1: it tries to build. Fails on the missing dependency. See the failure captured here in the memory panel -- it now KNOWS `sharp` needs to be installed. Attempt 2: dependency is fixed, but now it hits the port conflict. Memory updated -- 'Port 3000 conflicts, use 3001.' Attempt 3: ports fixed, but TypeScript error. Memory grows. Attempt 4: all failures addressed. Green. Deployed."

*[Timeline fills in: RED -> RED -> RED -> GREEN]*
*[Failure memory panel shows 4 learned rules]*

**[2:00-2:30] The Rewind**
"But here's the magic. I can hit 'rewind' to go back to Attempt 2." *[Click rewind button]* "The sandbox restores to that exact state in 25 milliseconds -- courtesy of Blaxel. Now I can try a DIFFERENT approach from that checkpoint. This is git for agent cognition."

**[2:30-3:00] The Business Case**
"Enterprise teams spend 40% of their time debugging AI agent failures. ReLoop cuts that by giving agents institutional memory. Every failure makes every future attempt smarter. SaaS model: $49/month per agent. The more your agents fail, the more valuable ReLoop becomes. And unlike competitors -- the memory never expires. That's Blaxel's perpetual sandbox."

### Tech Stack for Speed

| Layer | Tool | Why |
|-------|------|-----|
| Frontend | Next.js + Tailwind + shadcn/ui | Fast to scaffold, clean UI components |
| Timeline visualization | React Flow or custom SVG | Timeline nodes with status colors |
| Agent orchestration | Wordware Flow Editor + API | Visual builder = fast iteration |
| Memory | Redis Agent Memory Server (Docker) | One `docker compose up`, 3-tier memory out of the box |
| Execution | Blaxel Python SDK | `sandbox.process.run()`, checkpoint/restore |
| Code generation | Codex SDK | `thread.run()` for fix generation |
| LLM | Claude or GPT-4 via Wordware | Wordware handles the routing |

### Pre-Hackathon Prep (Before April 11)

- [ ] Scaffold Next.js app with Tailwind + shadcn/ui
- [ ] Get API keys: Wordware, Blaxel ($200 credits), Redis Cloud, OpenAI
- [ ] Docker Compose file for Redis Agent Memory Server
- [ ] Blaxel account + workspace + test sandbox creation
- [ ] Build the "broken project" demo payload (4 deliberate bugs)
- [ ] Wordware flow skeleton (task decomposition + retry logic)
- [ ] Timeline UI component (static version with mock data)
- [ ] Practice the 3-minute demo script

### Build Day Schedule

| Time | Task | Owner |
|------|------|-------|
| 10:00-10:30 | Environment setup, API keys, verify all services | All |
| 10:30-12:00 | Wordware agent flow (planning loop + retry logic) | Agent Dev |
| 10:30-12:00 | Redis memory integration (failure capture + query) | Memory Dev |
| 10:30-12:00 | Blaxel sandbox integration (execute + checkpoint) | Sandbox Dev |
| 12:00-12:30 | Lunch + integration test | All |
| 12:30-14:00 | Connect all pieces: agent -> memory -> sandbox -> UI | All |
| 14:00-16:00 | Frontend: timeline view, failure memory panel, live output | Frontend Dev |
| 16:00-17:00 | End-to-end demo run, fix bugs, record backup video | All |
| 17:00-18:00 | Demo script polish, slides (if needed), rehearsal x3 | All |
| 18:00-19:00 | Present + Q&A prep | All |

### Judges Q&A Prep

| Question | Answer |
|----------|--------|
| "How is this different from retry logic?" | "Retry logic repeats the same action. ReLoop LEARNS -- it captures WHY something failed and changes its approach. After 10 failures, it has 10 rules that prevent future agents from hitting the same issues." |
| "What's the business model?" | "SaaS, $49/agent/month. Targets enterprise AI teams running agents in production. The more agents fail, the more valuable the failure memory becomes. Net revenue retention is built in." |
| "How scalable is this?" | "Redis handles millions of ops/sec. Blaxel sandboxes scale horizontally. The failure memory graph grows linearly. We've designed this for thousands of concurrent agents." |
| "Why not just use better prompts?" | "Better prompts help on the first try. But complex tasks have unpredictable failure modes. ReLoop handles the failures that better prompts can't prevent -- runtime errors, API changes, environment issues." |
| "What about memory poisoning?" | "Great question -- this is an active research area. We use Redis's built-in data validation and we tag each memory with confidence scores that decay over time. Bad memories get pruned." |

---

## Decision Audit Trail

### Why We Chose This Over Alternatives

| Rejected Idea | Why Rejected |
|---------------|-------------|
| Context Rot Healer | Too abstract for 3-minute demo. "Your coherence metric degraded" doesn't wow judges. |
| Pure AgentRewind (git for agents) | Branching timeline UI too complex for 7 hours. Simplified to linear timeline with single rewind. |
| Physical World Agent | No physical component at hackathon. Hard to verify. |
| Agent-to-Agent Coordination | Multi-agent = debugging time sink. Violated the "one agent" constraint. |
| Cooking/Travel domain | Low-stakes. Doesn't leverage sponsor tools naturally. |
| DevOps/SRE Agent | Mendral already built this on Blaxel. Would look derivative. |
| RAG Chatbot | On the avoid list. Judges have seen 1000 of these. |

### Key Strategic Decisions

1. **Targeted Wordware $5K prize** -- Biggest prize, hackathon host. ReLoop showcases Wordware as agent orchestration layer.
2. **Non-chat UI** -- Timeline visualization stands out after 15 chat demos. Devil's Advocate insisted on this.
3. **Pre-run the long task** -- Don't run live (risky). Start the agent 30 min before demo, show results + rewind capability.
4. **"Self-debugging" framing** -- Differentiates from "code agent with memory" (avoid list). The FAILURE MEMORY is the product, not the code generation.
5. **4/4 sponsor coverage** -- Every sponsor plays a genuine architectural role. Not checkbox integrations.

### Risk Mitigation

| Risk | Mitigation |
|------|-----------|
| Wordware flow doesn't work | Fallback: hardcode the planning loop in Python, still demo the Wordware flow as "how we'd do it in production" |
| Blaxel sandbox is slow/down | Fallback: local Docker container, mention Blaxel as "production deployment target" |
| Demo fails live | Record a backup demo video by 5 PM. Play video if live demo has issues. |
| Codex API is slow/down | Fallback: use Claude via Wordware for code generation. Mention Codex as "planned integration" |
| Timeline UI isn't ready | Fallback: Terminal output with color-coded attempt numbers. Ugly but functional. |

---

## Summary

**Project:** ReLoop -- The Self-Healing Agent with Failure Memory
**Tagline:** "Every agent fails. ReLoop is the first that gets smarter from failure."
**Stack:** Wordware + Redis + Blaxel + Codex + Next.js
**Demo:** Broken project -> 4 failed attempts (each captured) -> success -> rewind to checkpoint
**Prize Target:** Wordware $5K (primary) + Blaxel $500 (secondary)
**Differentiator:** Failure memory + visual timeline + sandbox rewind. Not another chatbot. Not another code assistant. A NEW CATEGORY: agent observability + self-healing.

---

*Generated by 4-agent ideation team on April 9, 2026*
*Sponsor Researcher | Trends Researcher | Strategist | Devil's Advocate*
