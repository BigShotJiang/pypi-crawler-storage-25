<!-- BEGIN:nextjs-agent-rules -->
# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.
<!-- END:nextjs-agent-rules -->

## Git Workflow -- Pull Request Required

**MANDATORY**: All changes to this directory (`dashboard/`) must go through a pull request before merging to `main`.

- **Do NOT** commit directly to `main`
- **Do NOT** push directly to `main`
- Create a feature branch, push it, and open a PR via `gh pr create`
- Auto-review the PR diff for correctness, type safety, and rule compliance
- Fix any issues found, push fixes, and re-review until clean
- Auto-approve and merge (`gh pr merge --squash --delete-branch`) once all checks pass
- The entire cycle (PR → review → fix → approve → merge) must be fully automated with no manual steps
