"use client";

import type { ErrorCategory } from "@/lib/types";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/*  Design tokens per category                                         */
/* ------------------------------------------------------------------ */

interface CategoryStyle {
  label: string;
  colorClass: string;
  bgClass: string;
  borderClass: string;
}

const CATEGORY_STYLES: Record<ErrorCategory, CategoryStyle> = {
  dependency_error: {
    label: "DEPENDENCY",
    colorClass: "text-purple-400",
    bgClass: "bg-purple-500/[0.12]",
    borderClass: "border-purple-500/25",
  },
  config_error: {
    label: "CONFIG",
    colorClass: "text-amber-500",
    bgClass: "bg-amber-500/[0.12]",
    borderClass: "border-amber-500/25",
  },
  type_error: {
    label: "TYPE ERROR",
    colorClass: "text-red-400",
    bgClass: "bg-red-500/[0.12]",
    borderClass: "border-red-500/25",
  },
  runtime_error: {
    label: "RUNTIME",
    colorClass: "text-amber-500",
    bgClass: "bg-amber-500/[0.08]",
    borderClass: "border-amber-500/20",
  },
  network_error: {
    label: "NETWORK",
    colorClass: "text-blue-400",
    bgClass: "bg-blue-500/[0.12]",
    borderClass: "border-blue-500/25",
  },
  permission_error: {
    label: "PERMISSION",
    colorClass: "text-red-500",
    bgClass: "bg-red-500/10",
    borderClass: "border-red-500/[0.22]",
  },
  timeout_error: {
    label: "TIMEOUT",
    colorClass: "text-yellow-400",
    bgClass: "bg-yellow-500/10",
    borderClass: "border-yellow-500/20",
  },
  unknown: {
    label: "UNKNOWN",
    colorClass: "text-muted-foreground",
    bgClass: "bg-white/[0.06]",
    borderClass: "border-white/10",
  },
};

/* ------------------------------------------------------------------ */
/*  Props                                                              */
/* ------------------------------------------------------------------ */

interface FailurePatternBadgeProps {
  category: ErrorCategory;
  className?: string;
  size?: "sm" | "md";
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

export function FailurePatternBadge({
  category,
  className,
  size = "sm",
}: FailurePatternBadgeProps) {
  const style = CATEGORY_STYLES[category] ?? CATEGORY_STYLES.unknown;
  const isMd = size === "md";

  return (
    <span
      className={cn(
        "inline-flex items-center shrink-0 font-semibold tracking-widest whitespace-nowrap border rounded-md",
        style.colorClass,
        style.bgClass,
        style.borderClass,
        isMd ? "text-[11px] px-2 py-0.5" : "text-[10px] px-1.5 py-px",
        className,
      )}
    >
      {style.label}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  Helper: derive category from error category string                */
/* ------------------------------------------------------------------ */

export function getCategoryStyle(category: ErrorCategory): CategoryStyle {
  return CATEGORY_STYLES[category] ?? CATEGORY_STYLES.unknown;
}
