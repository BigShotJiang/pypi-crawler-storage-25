"use client";

import { useRouter, usePathname } from "next/navigation";
import { RotateCcw, LayoutDashboard, GitCompareArrows } from "lucide-react";

interface AppShellProps {
  children: React.ReactNode;
  /** Extra elements rendered on the right side of the nav bar */
  navRight?: React.ReactNode;
  /** Extra elements rendered between nav links and right side */
  navCenter?: React.ReactNode;
}

export function AppShell({ children, navRight, navCenter }: AppShellProps) {
  const router = useRouter();
  const pathname = usePathname();

  const navLinks = [
    { label: "Dashboard", href: "/", icon: LayoutDashboard, match: (p: string) => p === "/" },
    { label: "A/B Compare", href: "/ab", icon: GitCompareArrows, match: (p: string) => p.startsWith("/ab") },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[var(--bg-primary)]">
      {/* Glass navigation bar */}
      <header className="rl-nav-glass sticky top-0 z-30 h-12">
        <div className="h-full px-5 flex items-center gap-4">
          {/* Logo */}
          <button
            onClick={() => router.push("/")}
            className="flex items-center gap-2.5 shrink-0 bg-transparent border-none cursor-pointer p-0"
          >
            <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-[var(--bg-surface-hover)]">
              <RotateCcw className="w-3.5 h-3.5 text-[var(--accent)]" />
            </div>
            <span className="text-sm font-semibold text-[var(--text-primary)] tracking-tight">
              ReLoop
            </span>
          </button>

          {/* Divider */}
          <div className="w-px h-5 bg-[var(--border-default)]" />

          {/* Nav links */}
          <nav className="flex items-center gap-1">
            {navLinks.map((item) => {
              const active = item.match(pathname);
              const Icon = item.icon;
              return (
                <button
                  key={item.label}
                  onClick={() => router.push(item.href)}
                  className="flex items-center gap-1.5 border-none outline-none cursor-pointer"
                  style={{
                    padding: "5px 12px",
                    borderRadius: "var(--radius-md)",
                    fontSize: "var(--font-xs)",
                    fontWeight: active ? 500 : 400,
                    letterSpacing: "-0.01em",
                    color: active ? "var(--text-primary)" : "var(--text-muted)",
                    backgroundColor: active ? "var(--bg-surface-hover)" : "transparent",
                    transition: "color var(--transition-fast), background-color var(--transition-fast)",
                  }}
                >
                  <span style={{ color: active ? "var(--accent)" : "var(--text-muted)" }}>
                    <Icon className="w-3.5 h-3.5" />
                  </span>
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Center slot (e.g. stats pills, breadcrumbs) */}
          {navCenter}

          {/* Right slot (e.g. action buttons) -- pushed to the right */}
          {navRight && (
            <div className="ml-auto flex items-center gap-2.5">
              {navRight}
            </div>
          )}
        </div>
      </header>

      {/* Page content */}
      {children}
    </div>
  );
}
