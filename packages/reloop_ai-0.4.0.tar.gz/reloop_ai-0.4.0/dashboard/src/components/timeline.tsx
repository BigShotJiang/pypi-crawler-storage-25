"use client";

import { useState } from "react";
import type { Attempt, AttemptStatus } from "@/lib/types";
import { cn } from "@/lib/utils";
import { AttemptDetail } from "./attempt-detail";
import { FONT } from "@/lib/tokens";

interface TimelineProps {
  attempts: Attempt[];
  activeAttemptNumber?: number;
  maxRetries?: number;
  className?: string;
}

/* ------------------------------------------------------------------ */
/*  Status helpers                                                     */
/* ------------------------------------------------------------------ */

const STATUS_CONFIG: Record<
  AttemptStatus,
  { fill: string; glow: string; pulseClass: string; glowClass: string; label: string }
> = {
  succeeded: {
    fill: "#27a644",
    glow: "0 0 12px 3px rgba(39,166,68,0.35), 0 0 24px 6px rgba(39,166,68,0.15)",
    pulseClass: "animate-pulse-green",
    glowClass: "animate-glow-green",
    label: "Pass",
  },
  failed: {
    fill: "#ef4444",
    glow: "0 0 12px 3px rgba(239,68,68,0.35), 0 0 24px 6px rgba(239,68,68,0.15)",
    pulseClass: "animate-pulse-red",
    glowClass: "animate-glow-red",
    label: "Fail",
  },
  running: {
    fill: "#eab308",
    glow: "0 0 12px 3px rgba(234,179,8,0.35), 0 0 24px 6px rgba(234,179,8,0.15)",
    pulseClass: "animate-pulse-yellow",
    glowClass: "animate-glow-yellow",
    label: "Run",
  },
  pending: {
    fill: "#48484a",
    glow: "none",
    pulseClass: "",
    glowClass: "",
    label: "---",
  },
};

function getConfig(status: AttemptStatus) {
  return STATUS_CONFIG[status] ?? STATUS_CONFIG.pending;
}

/* ------------------------------------------------------------------ */
/*  Connector gradient between two nodes                               */
/* ------------------------------------------------------------------ */

function connectorGradient(fromStatus: AttemptStatus, toStatus: AttemptStatus): string {
  const from = getConfig(fromStatus).fill;
  const to = getConfig(toStatus).fill;
  return `linear-gradient(90deg, ${from}, ${to})`;
}

/* ------------------------------------------------------------------ */
/*  Status icon inside node                                            */
/* ------------------------------------------------------------------ */

function StatusIcon({ status }: { status: AttemptStatus }) {
  if (status === "succeeded") {
    return (
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
        <path
          d="M3.5 7.5L5.5 9.5L10.5 4.5"
          stroke="#fff"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    );
  }
  if (status === "failed") {
    return (
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
        <path
          d="M4.5 4.5L9.5 9.5M9.5 4.5L4.5 9.5"
          stroke="#fff"
          strokeWidth="1.8"
          strokeLinecap="round"
        />
      </svg>
    );
  }
  if (status === "running") {
    return (
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
        <circle cx="4.5" cy="7" r="1.2" fill="#fff" />
        <circle cx="7" cy="7" r="1.2" fill="#fff" opacity="0.7" />
        <circle cx="9.5" cy="7" r="1.2" fill="#fff" opacity="0.4" />
      </svg>
    );
  }
  return null;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

export function Timeline({
  attempts,
  activeAttemptNumber,
  maxRetries = 5,
  className,
}: TimelineProps) {
  const [selectedAttempt, setSelectedAttempt] = useState<number | null>(
    attempts.length > 0 ? attempts[attempts.length - 1].attempt_number : null,
  );

  const selected = attempts.find((a) => a.attempt_number === selectedAttempt);

  // Determine the latest/active node for pulse animation
  const latestAttemptNum = activeAttemptNumber
    ?? (attempts.length > 0 ? attempts[attempts.length - 1].attempt_number : -1);

  // Prediction nodes (remaining retries)
  const lastAttemptNum =
    attempts.length > 0 ? attempts[attempts.length - 1].attempt_number : 0;
  const lastStatus =
    attempts.length > 0 ? attempts[attempts.length - 1].status : null;
  const showPredictions = lastStatus === "running" || lastStatus === "failed";
  const predictedCount = showPredictions
    ? Math.min(2, maxRetries - lastAttemptNum)
    : 0;

  return (
    <div className={cn("flex flex-col gap-5", className)}>
      {/* Node row */}
      <div className="relative flex items-center gap-0 overflow-x-auto pb-6 pt-4 px-2">
        {attempts.map((attempt, idx) => {
          const isSelected = attempt.attempt_number === selectedAttempt;
          const isLatest = attempt.attempt_number === latestAttemptNum;
          const config = getConfig(attempt.status);
          const showConnector = idx < attempts.length - 1 || predictedCount > 0;
          const nextStatus =
            idx < attempts.length - 1 ? attempts[idx + 1].status : "pending";

          return (
            <div
              key={attempt.attempt_number}
              className="flex items-center animate-fade-in-scale"
              style={{
                animationDelay: `${idx * 80}ms`,
                animationFillMode: "both",
              }}
            >
              {/* ---- Node ---- */}
              <button
                type="button"
                onClick={() =>
                  setSelectedAttempt(
                    isSelected ? null : attempt.attempt_number,
                  )
                }
                className="relative flex flex-col items-center gap-2 group focus:outline-none"
                title={`Attempt ${attempt.attempt_number} -- ${attempt.status}`}
              >
                {/* Outer glow ring for latest node */}
                {isLatest && attempt.status !== "pending" && (
                  <>
                    <span
                      className="absolute top-0 left-1/2 -translate-x-1/2 rounded-full animate-ring-expand pointer-events-none"
                      style={{
                        width: "42px",
                        height: "42px",
                        border: `2px solid ${config.fill}`,
                        opacity: 0.4,
                      }}
                    />
                    <span
                      className="absolute top-0 left-1/2 -translate-x-1/2 rounded-full animate-ring-expand-delay pointer-events-none"
                      style={{
                        width: "42px",
                        height: "42px",
                        border: `1.5px solid ${config.fill}`,
                        opacity: 0.2,
                      }}
                    />
                  </>
                )}

                {/* Circle node */}
                <div
                  className={cn(
                    "relative flex items-center justify-center transition-transform duration-200",
                    isLatest && config.pulseClass,
                  )}
                  style={{
                    width: "42px",
                    height: "42px",
                    borderRadius: "50%",
                    backgroundColor: config.fill,
                    boxShadow: isSelected
                      ? config.glow
                      : attempt.status !== "pending"
                        ? `0 0 8px 2px ${config.fill}33, 0 0 16px 4px ${config.fill}15`
                        : "none",
                    transform: isSelected
                      ? "scale(1.12) translateY(-2px)"
                      : "scale(1)",
                    cursor: "pointer",
                  }}
                >
                  <StatusIcon status={attempt.status} />

                  {/* Inner ring accent */}
                  <div
                    className="absolute inset-0 rounded-full pointer-events-none"
                    style={{
                      border: `1.5px solid rgba(255,255,255,${isSelected ? 0.25 : 0.1})`,
                    }}
                  />
                </div>

                {/* Labels */}
                <div className="flex flex-col items-center gap-0.5">
                  <span
                    style={{
                      fontSize: "11px",
                      fontWeight: 600,
                      color: isSelected ? "#ffffff" : "rgba(255,255,255,0.55)",
                      letterSpacing: "-0.08px",
                      fontFamily: FONT,
                      transition: "color 0.2s ease",
                    }}
                  >
                    Attempt {attempt.attempt_number}
                  </span>
                  <span
                    style={{
                      fontSize: "10px",
                      fontWeight: 500,
                      color: isSelected ? config.fill : "rgba(255,255,255,0.35)",
                      letterSpacing: "0.02em",
                      fontFamily: FONT,
                      textTransform: "uppercase",
                      transition: "color 0.2s ease",
                    }}
                  >
                    {config.label}
                  </span>
                </div>
              </button>

              {/* ---- Connector line ---- */}
              {showConnector && idx < attempts.length - 1 && (
                <div
                  className="flex items-center mx-1.5"
                  style={{ marginTop: "-28px" }}
                >
                  <div
                    className="animate-connector-flow"
                    style={{
                      height: "2px",
                      width: "48px",
                      borderRadius: "1px",
                      background: connectorGradient(attempt.status, nextStatus),
                      opacity: 0.7,
                    }}
                  />
                </div>
              )}
            </div>
          );
        })}

        {/* Connector from last real node to predictions */}
        {predictedCount > 0 && attempts.length > 0 && (
          <div
            className="flex items-center mx-1.5"
            style={{ marginTop: "-28px" }}
          >
            <div
              style={{
                height: "2px",
                width: "48px",
                borderRadius: "1px",
                backgroundImage:
                  "repeating-linear-gradient(90deg, rgba(255,255,255,0.12) 0px, rgba(255,255,255,0.12) 4px, transparent 4px, transparent 10px)",
              }}
            />
          </div>
        )}

        {/* Prediction nodes */}
        {Array.from({ length: predictedCount }).map((_, idx) => {
          const predNum = lastAttemptNum + idx + 1;
          const isLastPred = idx === predictedCount - 1;
          return (
            <div
              key={`pred-${predNum}`}
              className="flex items-center animate-fade-in"
              style={{
                animationDelay: `${(attempts.length + idx) * 80 + 100}ms`,
                animationFillMode: "both",
              }}
            >
              <div className="relative flex flex-col items-center gap-2">
                <div
                  className="flex items-center justify-center"
                  style={{
                    width: "42px",
                    height: "42px",
                    borderRadius: "50%",
                    backgroundColor: "rgba(255,255,255,0.04)",
                    border: "1.5px dashed rgba(255,255,255,0.12)",
                  }}
                >
                  <span
                    style={{
                      fontSize: "12px",
                      fontWeight: 600,
                      color: "rgba(255,255,255,0.3)",
                      fontFamily: FONT,
                    }}
                  >
                    {predNum}
                  </span>
                </div>
                <div className="flex flex-col items-center gap-0.5">
                  <span
                    style={{
                      fontSize: "11px",
                      fontWeight: 600,
                      color: "rgba(255,255,255,0.3)",
                      letterSpacing: "-0.08px",
                      fontFamily: FONT,
                    }}
                  >
                    Attempt {predNum}
                  </span>
                  <span
                    style={{
                      fontSize: "10px",
                      fontWeight: 500,
                      color: "rgba(255,255,255,0.2)",
                      letterSpacing: "0.02em",
                      fontFamily: FONT,
                      textTransform: "uppercase",
                    }}
                  >
                    Next
                  </span>
                </div>
              </div>
              {!isLastPred && (
                <div
                  className="flex items-center mx-1.5"
                  style={{ marginTop: "-28px" }}
                >
                  <div
                    style={{
                      height: "2px",
                      width: "48px",
                      borderRadius: "1px",
                      backgroundImage:
                        "repeating-linear-gradient(90deg, rgba(255,255,255,0.12) 0px, rgba(255,255,255,0.12) 4px, transparent 4px, transparent 10px)",
                    }}
                  />
                </div>
              )}
            </div>
          );
        })}

        {/* Empty state */}
        {attempts.length === 0 && (
          <div className="flex items-center gap-4 animate-fade-in">
            <div
              className="flex items-center justify-center animate-breathe"
              style={{
                width: "42px",
                height: "42px",
                borderRadius: "50%",
                backgroundColor: "rgba(255,255,255,0.04)",
                border: "1.5px dashed rgba(255,255,255,0.12)",
              }}
            >
              <span
                style={{
                  fontSize: "14px",
                  fontWeight: 600,
                  color: "rgba(255,255,255,0.3)",
                  fontFamily: FONT,
                }}
              >
                ?
              </span>
            </div>
            <div className="flex flex-col gap-0.5">
              <span
                style={{
                  fontSize: "14px",
                  fontWeight: 600,
                  color: "rgba(255,255,255,0.55)",
                  letterSpacing: "-0.224px",
                  fontFamily: FONT,
                }}
              >
                Waiting for first attempt
              </span>
              <span
                style={{
                  fontSize: "12px",
                  fontWeight: 400,
                  color: "rgba(255,255,255,0.3)",
                  letterSpacing: "-0.12px",
                  fontFamily: FONT,
                }}
              >
                The agent will begin executing shortly...
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Detail panel */}
      {selected && (
        <div
          key={selected.attempt_number}
          className="animate-fade-in-up"
          style={{ animationDuration: "0.3s" }}
        >
          <AttemptDetail attempt={selected} />
        </div>
      )}
    </div>
  );
}
