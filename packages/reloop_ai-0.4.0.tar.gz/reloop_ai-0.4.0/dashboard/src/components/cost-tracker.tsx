"use client";

import type { Attempt } from "@/lib/types";
import { cn } from "@/lib/utils";
import { TrendingDown, Zap } from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Props                                                              */
/* ------------------------------------------------------------------ */

interface CostTrackerProps {
  attempts: Attempt[];
  totalCost: number;
  maxBudget?: number;
  className?: string;
}

/* ------------------------------------------------------------------ */
/*  Budget bar                                                         */
/* ------------------------------------------------------------------ */

function BudgetBar({ usedPct }: { usedPct: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 overflow-hidden h-[2px] rounded-full bg-white/[0.08]">
        <div
          className="h-full rounded-full transition-[width] duration-300 ease-out"
          style={{
            width: `${Math.min(usedPct, 100)}%`,
            backgroundColor: "var(--apple-blue)",
          }}
        />
      </div>
      <span className="text-xs font-normal text-white/80 tracking-tight font-mono tabular-nums">
        {Math.round(usedPct)}%
      </span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

export function CostTracker({
  attempts,
  totalCost,
  maxBudget = 1.0,
  className,
}: CostTrackerProps) {
  const firstAttemptCost = attempts[0]?.cost_usd ?? 0;
  const blindRetryCost = firstAttemptCost * attempts.length;
  const savedAmount = Math.max(0, blindRetryCost - totalCost);
  const budgetUsedPct = Math.min(100, (totalCost / maxBudget) * 100);
  const maxCost = Math.max(...attempts.map((a) => a.cost_usd), 0.001);

  return (
    <div className={cn("flex items-center gap-4", className)}>
      {/* Budget info */}
      <div className="space-y-1.5 min-w-[90px]">
        <p className="uppercase text-xs font-semibold text-muted-foreground tracking-widest">
          Budget
        </p>
        <p className="text-[17px] font-semibold text-white tracking-tight tabular-nums">
          ${totalCost.toFixed(4)}
        </p>
        <p className="text-xs font-normal text-muted-foreground tracking-tight">
          of ${maxBudget.toFixed(2)}
        </p>
        <BudgetBar usedPct={budgetUsedPct} />
      </div>

      {/* Separator */}
      <div className="w-px h-10 bg-white/[0.06]" />

      {/* Per-attempt bar chart */}
      <div className="flex-1 min-w-0">
        <p className="uppercase mb-1.5 text-xs font-semibold text-muted-foreground tracking-widest">
          Cost per Attempt
        </p>
        <div className="flex items-end gap-1 h-9">
          {attempts.map((attempt) => {
            const heightPct = (attempt.cost_usd / maxCost) * 100;

            return (
              <div
                key={attempt.attempt_number}
                className="flex flex-col items-center gap-0.5"
              >
                <div
                  className="w-4 rounded-sm transition-[height] duration-300 ease-out opacity-70"
                  style={{
                    height: `${Math.max(3, heightPct * 0.36)}px`,
                    backgroundColor: "var(--apple-blue)",
                  }}
                />
                <span className="text-[10px] font-normal text-muted-foreground">
                  {attempt.attempt_number}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Separator */}
      <div className="w-px h-10 bg-white/[0.06]" />

      {/* Saved amount */}
      {savedAmount > 0.001 ? (
        <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-emerald-500/[0.08] border border-emerald-500/[0.15]">
          <TrendingDown className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
          <div>
            <p className="uppercase leading-tight text-[10px] font-semibold text-emerald-500/70 tracking-widest">
              Saved
            </p>
            <p className="text-sm font-semibold text-emerald-500 tracking-tight tabular-nums">
              ${savedAmount.toFixed(4)}
            </p>
          </div>
        </div>
      ) : (
        <div className="flex items-center gap-1.5">
          <Zap className="h-3 w-3 text-muted-foreground" />
          <span className="text-xs font-normal text-muted-foreground tracking-tight">
            {attempts.length} attempts
          </span>
        </div>
      )}
    </div>
  );
}
