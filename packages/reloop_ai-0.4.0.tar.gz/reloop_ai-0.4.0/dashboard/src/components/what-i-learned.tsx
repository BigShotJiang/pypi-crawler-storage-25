"use client";

import { useState } from "react";
import type { Task, FailureRecord } from "@/lib/types";
import { cn } from "@/lib/utils";
import {
  Brain,
  CheckCircle2,
  Copy,
  Check,
  Clock,
  DollarSign,
  RotateCcw,
  Lightbulb,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function formatDuration(startedAt: string, completedAt: string | null): string {
  const start = new Date(startedAt).getTime();
  const end = completedAt ? new Date(completedAt).getTime() : Date.now();
  const diffMs = end - start;
  const seconds = Math.floor(diffMs / 1000);
  const minutes = Math.floor(seconds / 60);
  if (minutes === 0) return `${seconds}s`;
  return `${minutes}m ${seconds % 60}s`;
}

function deriveLearnedBullets(failures: FailureRecord[], task: Task): string[] {
  const bullets: string[] = [];

  // One bullet per distinct failure with a suggested fix
  for (const f of failures) {
    const fix = f.analysis.suggested_fix;
    if (fix && fix.trim().length > 0) {
      bullets.push(fix.trim());
    }
    if (bullets.length >= 5) break;
  }

  // Fill with generic insight if not enough
  if (bullets.length === 0 && task.result) {
    bullets.push(`Task completed successfully: ${task.result}`);
  }

  if (bullets.length < 2 && task.attempts.length > 1) {
    bullets.push(
      `Required ${task.attempts.length} attempts before succeeding — each failure contributed a rule to memory.`
    );
  }

  return bullets;
}

function buildCopyText(
  task: Task,
  failures: FailureRecord[],
  bullets: string[]
): string {
  const duration = formatDuration(task.created_at, task.completed_at);
  const lines = [
    `ReLoop — What I Learned`,
    `─────────────────────────`,
    `Task: ${task.instruction}`,
    `Attempts: ${task.attempts.length}`,
    `Total cost: $${task.total_cost_usd.toFixed(4)}`,
    `Duration: ${duration}`,
    ``,
    `Learnings:`,
    ...bullets.map((b, i) => `${i + 1}. ${b}`),
  ];
  return lines.join("\n");
}

/* ------------------------------------------------------------------ */
/*  Props                                                              */
/* ------------------------------------------------------------------ */

interface WhatILearnedProps {
  task: Task;
  failures: FailureRecord[];
  className?: string;
  /** Start collapsed (default: false) */
  defaultCollapsed?: boolean;
}

/* ------------------------------------------------------------------ */
/*  Component                                                         */
/* ------------------------------------------------------------------ */

export function WhatILearned({
  task,
  failures,
  className,
  defaultCollapsed = false,
}: WhatILearnedProps) {
  const [copied, setCopied] = useState(false);
  const [collapsed, setCollapsed] = useState(defaultCollapsed);

  // Only show for succeeded tasks
  if (task.status !== "succeeded") return null;

  const duration = formatDuration(task.created_at, task.completed_at);
  const bullets = deriveLearnedBullets(failures, task);

  async function handleCopy() {
    const text = buildCopyText(task, failures, bullets);
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback -- create a temp textarea
      const el = document.createElement("textarea");
      el.value = text;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }

  return (
    <div
      className={cn(
        "overflow-hidden rounded-xl border border-emerald-500/20",
        className,
      )}
      style={{ backgroundColor: "#1a1f1b" }}
    >
      {/* Header */}
      <button
        type="button"
        onClick={() => setCollapsed((v) => !v)}
        className="w-full flex items-center gap-3 p-4 text-left bg-transparent border-none cursor-pointer"
      >
        <div className="flex items-center justify-center w-8 h-8 rounded-full shrink-0 bg-emerald-500/[0.12]">
          <Brain className="h-4 w-4 text-emerald-500" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
            <h3 className="text-[15px] font-semibold text-white tracking-tight">
              What I Learned
            </h3>
          </div>
          <p className="text-xs font-normal text-muted-foreground tracking-tight mt-0.5">
            {bullets.length} insight{bullets.length !== 1 ? "s" : ""} distilled from {task.attempts.length} attempt{task.attempts.length !== 1 ? "s" : ""}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {/* Copy button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              void handleCopy();
            }}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-lg border-none cursor-pointer transition-all duration-150",
              copied
                ? "bg-emerald-500/[0.15] text-emerald-500"
                : "bg-white/[0.08] text-white/80",
            )}
            style={{ fontSize: "12px" }}
          >
            {copied ? (
              <Check className="h-3 w-3" />
            ) : (
              <Copy className="h-3 w-3" />
            )}
            {copied ? "Copied!" : "Copy"}
          </button>

          {collapsed ? (
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          ) : (
            <ChevronUp className="h-4 w-4 text-muted-foreground" />
          )}
        </div>
      </button>

      {/* Body */}
      {!collapsed && (
        <div className="px-4 pb-4 space-y-4 border-t border-emerald-500/[0.08]">
          {/* Stats row */}
          <div className="flex items-center gap-4 pt-3 flex-wrap">
            {/* Attempts */}
            <div className="flex items-center gap-1.5">
              <RotateCcw className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-[13px] font-normal text-white/80 tracking-tight">
                {task.attempts.length} attempt{task.attempts.length !== 1 ? "s" : ""}
              </span>
            </div>

            <div className="w-px h-3.5 bg-white/[0.08]" />

            {/* Cost */}
            <div className="flex items-center gap-1.5">
              <DollarSign className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-[13px] font-normal text-white/80 tracking-tight tabular-nums">
                ${task.total_cost_usd.toFixed(4)}
              </span>
            </div>

            <div className="w-px h-3.5 bg-white/[0.08]" />

            {/* Duration */}
            <div className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-[13px] font-normal text-white/80 tracking-tight">
                {duration}
              </span>
            </div>
          </div>

          {/* Learned bullets */}
          <div className="space-y-2">
            {bullets.map((bullet, idx) => (
              <div
                key={idx}
                className="flex items-start gap-2.5 p-3 rounded-lg bg-white/[0.04]"
              >
                <div className="flex items-center justify-center w-5 h-5 rounded-full shrink-0 mt-0.5 bg-emerald-500/[0.12]">
                  <Lightbulb className="h-3 w-3 text-emerald-500" />
                </div>
                <p className="text-[13px] font-normal text-white/80 leading-[1.47] tracking-tight">
                  {bullet}
                </p>
              </div>
            ))}
          </div>

          {/* Success result */}
          {task.result && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-emerald-500/[0.06] border border-emerald-500/[0.12]">
              <CheckCircle2 className="h-3.5 w-3.5 shrink-0 mt-0.5 text-emerald-500" />
              <p className="text-[13px] font-normal text-white/80 leading-[1.47] tracking-tight">
                {task.result}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
