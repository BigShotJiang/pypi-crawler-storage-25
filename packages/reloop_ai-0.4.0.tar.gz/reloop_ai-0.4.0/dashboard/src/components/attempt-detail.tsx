"use client";

import { useState } from "react";
import type { Attempt, StepResult, AttemptStatus } from "@/lib/types";
import { cn } from "@/lib/utils";
import {
  Clock,
  Terminal,
  DollarSign,
  ChevronDown,
  ChevronRight,
  Brain,
  Copy,
  Check,
  XCircle,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Props                                                              */
/* ------------------------------------------------------------------ */

interface AttemptDetailProps {
  attempt: Attempt;
  className?: string;
}

/* ------------------------------------------------------------------ */
/*  Status dot                                                         */
/* ------------------------------------------------------------------ */

const STATUS_DOT_COLORS: Record<string, string> = {
  succeeded: "#27a644",
  failed: "#ef4444",
  running: "#d97706",
};

const STATUS_TEXT_CLASSES: Record<string, string> = {
  succeeded: "text-emerald-500",
  failed: "text-red-500",
  running: "text-amber-500",
};

function StatusDot({ status }: { status: AttemptStatus }) {
  const color = STATUS_DOT_COLORS[status] ?? "rgba(255,255,255,0.3)";
  return (
    <span
      className={cn(
        "inline-block shrink-0 w-1.5 h-1.5 rounded-full",
        status === "running" && "animate-pulse",
      )}
      style={{ backgroundColor: color }}
    />
  );
}

/* ------------------------------------------------------------------ */
/*  Copy button                                                        */
/* ------------------------------------------------------------------ */

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  function handleCopy() {
    void navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <button
      type="button"
      onClick={handleCopy}
      className="p-1 rounded-[5px] text-muted-foreground transition-colors duration-200 hover:text-white/80"
      title="Copy to clipboard"
    >
      {copied ? (
        <Check className="h-3 w-3 text-emerald-500" />
      ) : (
        <Copy className="h-3 w-3" />
      )}
    </button>
  );
}

/* ------------------------------------------------------------------ */
/*  Step row                                                           */
/* ------------------------------------------------------------------ */

function StepRow({ step, isLast }: { step: StepResult; isLast: boolean }) {
  const [expanded, setExpanded] = useState(true);

  const stepDuration =
    step.completed_at && step.started_at
      ? Math.round(
          (new Date(step.completed_at).getTime() - new Date(step.started_at).getTime()) / 1000,
        )
      : null;

  return (
    <div className="flex gap-2.5">
      {/* Vertical line + status dot */}
      <div className="flex flex-col items-center pt-2">
        <StatusDot status={step.status} />
        {!isLast && (
          <div className="flex-1 mt-1 min-h-[16px] w-px bg-white/[0.06]" />
        )}
      </div>

      {/* Step content */}
      <div className="flex-1 min-w-0 pb-2">
        {/* Step header */}
        <button
          type="button"
          onClick={() => setExpanded(!expanded)}
          className="w-full flex items-start gap-2 text-left group"
        >
          <div className="flex-1 min-w-0">
            <p className="text-[13px] font-normal text-white leading-[1.47] tracking-tight">
              {step.description}
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {stepDuration !== null && (
              <span className="text-xs font-normal text-muted-foreground tracking-tight">
                {stepDuration}s
              </span>
            )}
            <span className="text-xs font-normal text-muted-foreground tracking-tight">
              #{step.step_number}
            </span>
            {expanded ? (
              <ChevronDown className="h-3 w-3 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-3 w-3 text-muted-foreground" />
            )}
          </div>
        </button>

        {/* Collapsible content */}
        {expanded && (
          <div className="mt-2 space-y-2">
            {/* Command block */}
            {step.command && (
              <div
                className="overflow-hidden rounded-lg"
                style={{ backgroundColor: "var(--apple-bg-near-black)" }}
              >
                <div className="flex items-center justify-between px-3 py-1.5">
                  <div className="flex items-center gap-1.5">
                    <Terminal className="h-3 w-3 text-muted-foreground" />
                    <span className="uppercase text-xs font-semibold text-muted-foreground tracking-widest">
                      Command
                    </span>
                  </div>
                  <CopyButton text={step.command} />
                </div>
                <div className="px-3 py-2">
                  <code className="break-all leading-relaxed text-[13px] font-mono" style={{ color: "var(--apple-link-dark)" }}>
                    <span className="select-none text-white/30">$ </span>
                    {step.command}
                  </code>
                </div>
              </div>
            )}

            {/* Output block */}
            {step.output && (
              <div
                className="overflow-hidden rounded-lg"
                style={{ backgroundColor: "var(--apple-bg-near-black)" }}
              >
                <div className="flex items-center justify-between px-3 py-1.5">
                  <span className="uppercase text-xs font-semibold text-muted-foreground tracking-widest">
                    Output
                  </span>
                  <CopyButton text={step.output} />
                </div>
                <pre className="px-3 py-2 overflow-x-auto whitespace-pre-wrap break-all max-h-24 overflow-y-auto terminal-scroll text-[13px] text-white leading-relaxed font-mono">
                  {step.output.split("\n").map((line, i) => (
                    <div key={i} className="flex gap-2">
                      <span className="select-none shrink-0 text-right w-5 text-[11px] font-mono text-white/20">
                        {i + 1}
                      </span>
                      <span className="flex-1">{line}</span>
                    </div>
                  ))}
                </pre>
              </div>
            )}

            {/* Error block */}
            {step.error && (
              <div className="overflow-hidden rounded-lg bg-red-500/[0.04]">
                <div className="flex items-center justify-between px-3 py-1.5">
                  <div className="flex items-center gap-1.5">
                    <XCircle className="h-3 w-3 text-red-500" />
                    <span className="uppercase text-xs font-semibold text-red-500 tracking-widest">
                      Error
                    </span>
                  </div>
                  <CopyButton text={step.error} />
                </div>
                <div className="px-3 py-2">
                  <p className="break-all leading-relaxed text-[13px] text-red-500 font-mono">
                    {step.error}
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main component                                                     */
/* ------------------------------------------------------------------ */

export function AttemptDetail({ attempt, className }: AttemptDetailProps) {
  const [stepsExpanded, setStepsExpanded] = useState(true);
  const [memoriesExpanded, setMemoriesExpanded] = useState(true);

  const duration =
    attempt.completed_at && attempt.started_at
      ? Math.round(
          (new Date(attempt.completed_at).getTime() -
            new Date(attempt.started_at).getTime()) /
            1000,
        )
      : null;

  const statusTextClass = STATUS_TEXT_CLASSES[attempt.status] ?? "text-muted-foreground";

  return (
    <div
      className={cn("overflow-hidden rounded-lg", className)}
      style={{ backgroundColor: "var(--apple-surface-1)" }}
    >
      {/* Header */}
      <div className="flex items-center justify-between gap-4 px-3 py-3">
        <div className="flex items-center gap-2.5">
          <span className="text-sm font-semibold text-white tracking-tight">
            Attempt {attempt.attempt_number}
          </span>
          <span
            className={cn(
              "inline-flex items-center gap-1.5 text-xs font-normal rounded-full px-2.5 py-0.5 bg-white/[0.08] tracking-tight",
              statusTextClass,
            )}
          >
            <StatusDot status={attempt.status} />
            {attempt.status.toUpperCase()}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {duration !== null && (
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-[5px] bg-white/[0.06]">
              <Clock className="h-3 w-3 text-muted-foreground" />
              <span className="text-xs font-normal text-white/80 tracking-tight">
                {duration}s
              </span>
            </div>
          )}
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-[5px] bg-white/[0.06]">
            <DollarSign className="h-3 w-3 text-muted-foreground" />
            <span className="text-xs font-normal text-white/80 tracking-tight tabular-nums">
              ${attempt.cost_usd.toFixed(3)}
            </span>
          </div>
        </div>
      </div>

      <div className="p-3 space-y-3">
        {/* Recalled memories */}
        {attempt.recalled_memories.length > 0 && (
          <div className="space-y-1.5">
            <button
              type="button"
              onClick={() => setMemoriesExpanded(!memoriesExpanded)}
              className="flex items-center gap-1.5 text-left w-full"
            >
              <Brain className="h-3 w-3" style={{ color: "var(--apple-blue)" }} />
              <span className="uppercase text-xs font-semibold text-muted-foreground tracking-widest">
                Recalled memories ({attempt.recalled_memories.length})
              </span>
              {memoriesExpanded ? (
                <ChevronDown className="h-3 w-3 ml-auto text-muted-foreground" />
              ) : (
                <ChevronRight className="h-3 w-3 ml-auto text-muted-foreground" />
              )}
            </button>
            {memoriesExpanded && (
              <div className="flex gap-1.5 flex-wrap pl-4">
                {attempt.recalled_memories.map((mem) => (
                  <span
                    key={mem}
                    className="text-xs font-normal rounded-full px-2.5 py-0.5 bg-white/[0.08] tracking-tight"
                    style={{ color: "var(--apple-link-dark)" }}
                  >
                    {mem.slice(0, 8)}
                  </span>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Steps */}
        <div className="space-y-1.5">
          <button
            type="button"
            onClick={() => setStepsExpanded(!stepsExpanded)}
            className="flex items-center gap-1.5 text-left w-full"
          >
            <span className="uppercase text-xs font-semibold text-muted-foreground tracking-widest">
              Steps ({attempt.steps.length})
            </span>
            {stepsExpanded ? (
              <ChevronDown className="h-3 w-3 ml-auto text-muted-foreground" />
            ) : (
              <ChevronRight className="h-3 w-3 ml-auto text-muted-foreground" />
            )}
          </button>

          {stepsExpanded && (
            <>
              {attempt.steps.length === 0 ? (
                <p className="pl-4 text-[13px] font-normal text-muted-foreground italic">
                  No steps recorded yet.
                </p>
              ) : (
                <div className="pl-1">
                  {attempt.steps.map((step, idx) => (
                    <StepRow
                      key={step.step_number}
                      step={step}
                      isLast={idx === attempt.steps.length - 1}
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
