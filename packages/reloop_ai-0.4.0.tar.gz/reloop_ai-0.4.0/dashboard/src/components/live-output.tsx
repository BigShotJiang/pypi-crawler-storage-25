"use client";

import { useEffect, useRef, useState, useMemo, useCallback } from "react";
import { cn } from "@/lib/utils";
import {
  Search,
  X,
  Copy,
  Check,
  ArrowDown,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Public types                                                       */
/* ------------------------------------------------------------------ */

export interface OutputLine {
  id: string;
  text: string;
  type: "info" | "success" | "error" | "command" | "system";
  timestamp?: string;
}

interface LiveOutputProps {
  lines: OutputLine[];
  className?: string;
  title?: string;
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function lineColorClass(type: OutputLine["type"]): string {
  switch (type) {
    case "success":  return "text-emerald-500";
    case "error":    return "text-red-500";
    case "command":  return "text-[#2997ff]";
    case "system":   return "text-muted-foreground";
    default:         return "text-white";
  }
}

function linePrefix(type: OutputLine["type"]): string {
  switch (type) {
    case "command": return "$ ";
    case "system":  return "~ ";
    case "error":   return "x ";
    case "success": return "> ";
    default:        return "  ";
  }
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

export function LiveOutput({
  lines,
  className,
  title = "Live Output",
}: LiveOutputProps) {
  const bottomRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [autoScroll, setAutoScroll] = useState(true);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<OutputLine["type"] | "all">("all");
  const [copied, setCopied] = useState(false);
  const [cursorVisible, setCursorVisible] = useState(true);

  // Blinking cursor
  useEffect(() => {
    const interval = setInterval(() => {
      setCursorVisible((v) => !v);
    }, 530);
    return () => clearInterval(interval);
  }, []);

  // Filter lines
  const filteredLines = useMemo(() => {
    let result = lines;
    if (filterType !== "all") {
      result = result.filter((l) => l.type === filterType);
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter((l) => l.text.toLowerCase().includes(q));
    }
    return result;
  }, [lines, filterType, searchQuery]);

  // Highlight matching text
  const highlightMatch = useCallback(
    (text: string) => {
      if (!searchQuery) return text;
      const idx = text.toLowerCase().indexOf(searchQuery.toLowerCase());
      if (idx === -1) return text;
      return (
        <>
          {text.slice(0, idx)}
          <span className="bg-blue-500/25 text-[#2997ff] rounded-sm px-0.5">
            {text.slice(idx, idx + searchQuery.length)}
          </span>
          {text.slice(idx + searchQuery.length)}
        </>
      );
    },
    [searchQuery],
  );

  // Auto-scroll
  useEffect(() => {
    if (autoScroll) {
      bottomRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [lines, autoScroll]);

  // Detect manual scroll up
  function handleScroll() {
    const el = containerRef.current;
    if (!el) return;
    const isAtBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
    if (!isAtBottom && autoScroll) {
      setAutoScroll(false);
    }
  }

  function handleCopyAll() {
    const text = filteredLines
      .map((l) => `${linePrefix(l.type)}${l.text}`)
      .join("\n");
    void navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  const errorCount = lines.filter((l) => l.type === "error").length;
  const commandCount = lines.filter((l) => l.type === "command").length;

  return (
    <div
      className={cn("flex flex-col overflow-hidden rounded-lg", className)}
      style={{ backgroundColor: "var(--apple-bg-near-black)" }}
    >
      {/* Title bar */}
      <div className="flex items-center gap-2 px-4 py-2.5">
        {/* Traffic-light dots for terminal feel */}
        <div className="flex items-center gap-1.5 mr-2">
          <span className="w-[10px] h-[10px] rounded-full bg-red-500/60" />
          <span className="w-[10px] h-[10px] rounded-full bg-amber-500/60" />
          <span className="w-[10px] h-[10px] rounded-full bg-emerald-500/60" />
        </div>
        <span className="truncate flex-1 text-xs font-semibold text-muted-foreground tracking-tight">
          {title}
        </span>

        {/* Stats */}
        <div className="flex items-center gap-2 shrink-0">
          {errorCount > 0 && (
            <button
              type="button"
              onClick={() => setFilterType(filterType === "error" ? "all" : "error")}
              className={cn(
                "px-2 py-0.5 text-xs font-normal rounded-[5px] tracking-tight transition-all duration-150",
                filterType === "error"
                  ? "text-red-500 bg-red-500/10"
                  : "text-muted-foreground bg-transparent",
              )}
            >
              {errorCount} err
            </button>
          )}
          {commandCount > 0 && (
            <span className="text-xs font-normal text-muted-foreground tracking-tight">
              {commandCount} cmd
            </span>
          )}
          <span className="text-xs font-normal text-muted-foreground tracking-tight">
            {lines.length} lines
          </span>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-1.5 px-4 py-1 bg-white/[0.03]">
        <button
          type="button"
          onClick={() => {
            setSearchOpen(!searchOpen);
            if (searchOpen) {
              setSearchQuery("");
              setFilterType("all");
            }
          }}
          className={cn(
            "p-1 rounded-[5px] transition-all duration-150",
            searchOpen
              ? "text-white bg-white/[0.08]"
              : "text-muted-foreground bg-transparent",
          )}
          title="Search output"
        >
          <Search className="h-3.5 w-3.5" />
        </button>

        <button
          type="button"
          onClick={handleCopyAll}
          className="p-1 rounded-[5px] text-muted-foreground transition-colors duration-200 hover:text-white/80"
          title="Copy all output"
        >
          {copied ? (
            <Check className="h-3.5 w-3.5 text-emerald-500" />
          ) : (
            <Copy className="h-3.5 w-3.5" />
          )}
        </button>

        <div className="flex-1" />

        <button
          type="button"
          onClick={() => {
            setAutoScroll(!autoScroll);
            if (!autoScroll) {
              bottomRef.current?.scrollIntoView({ behavior: "smooth" });
            }
          }}
          className={cn(
            "p-1 rounded-[5px] transition-all duration-150",
            autoScroll
              ? "text-[#0071e3] bg-[#0071e3]/10"
              : "text-muted-foreground bg-transparent",
          )}
          title={autoScroll ? "Auto-scroll ON" : "Auto-scroll OFF"}
        >
          <ArrowDown className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Search bar */}
      {searchOpen && (
        <div className="flex items-center gap-2 px-4 py-1.5 bg-white/[0.03]">
          <Search className="h-3 w-3 shrink-0 text-muted-foreground" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter output..."
            className="flex-1 bg-transparent outline-none text-[13px] font-normal text-white font-mono placeholder:text-muted-foreground"
            autoFocus
          />
          {searchQuery && (
            <span className="text-xs font-normal text-muted-foreground">
              {filteredLines.length} match{filteredLines.length !== 1 ? "es" : ""}
            </span>
          )}
          <button
            type="button"
            onClick={() => {
              setSearchQuery("");
              setSearchOpen(false);
              setFilterType("all");
            }}
            className="p-0.5 rounded-[5px] text-muted-foreground hover:text-white/80 transition-colors duration-200"
          >
            <X className="h-3 w-3" />
          </button>
        </div>
      )}

      {/* Terminal body */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto leading-5 terminal-scroll"
        style={{
          minHeight: 120,
          maxHeight: 260,
          backgroundColor: "var(--apple-bg-near-black)",
          fontSize: "13px",
        }}
      >
        {filteredLines.length === 0 && lines.length === 0 ? (
          <div className="flex items-center gap-2 px-4 py-3">
            <span
              className="inline-block w-[7px] h-3.5 transition-opacity duration-100"
              style={{
                backgroundColor: "rgba(0,113,227,0.6)",
                opacity: cursorVisible ? 1 : 0,
              }}
            />
            <span className="text-muted-foreground font-mono">
              Waiting for output...
            </span>
          </div>
        ) : filteredLines.length === 0 ? (
          <div className="flex items-center gap-2 px-4 py-3">
            <span className="text-[13px] text-muted-foreground font-mono">
              No matching lines
            </span>
          </div>
        ) : (
          <>
            {filteredLines.map((line, idx) => (
              <div
                key={line.id}
                className="flex gap-0"
              >
                {/* Line number */}
                <span className="text-right pr-3 pl-2 select-none shrink-0 w-10 text-xs text-white/20 font-mono">
                  {idx + 1}
                </span>

                {/* Timestamp */}
                {line.timestamp && (
                  <span className="px-2 shrink-0 select-none text-[11px] text-white/30 font-mono">
                    {new Date(line.timestamp).toLocaleTimeString("en-US", {
                      hour12: false,
                      hour: "2-digit",
                      minute: "2-digit",
                      second: "2-digit",
                    })}
                  </span>
                )}

                {/* Content */}
                <span className={cn("flex-1 px-2 break-all font-mono", lineColorClass(line.type))}>
                  <span className="select-none opacity-30">
                    {linePrefix(line.type)}
                  </span>
                  {highlightMatch(line.text)}
                </span>
              </div>
            ))}

            {/* Blinking cursor line */}
            <div className="flex items-center gap-0 py-1">
              <span className="text-right pr-3 pl-2 select-none w-10 text-xs text-white/20 font-mono">
                {filteredLines.length + 1}
              </span>
              <span className="flex items-center gap-1 px-2 text-[#2997ff]">
                <span className="select-none opacity-30 font-mono">$ </span>
                <span
                  className="inline-block w-[7px] h-3.5 transition-opacity duration-100"
                  style={{
                    backgroundColor: "rgba(0,113,227,0.6)",
                    opacity: cursorVisible ? 1 : 0,
                  }}
                />
              </span>
            </div>
          </>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Scroll-to-bottom indicator */}
      {!autoScroll && filteredLines.length > 0 && (
        <button
          type="button"
          onClick={() => {
            setAutoScroll(true);
            bottomRef.current?.scrollIntoView({ behavior: "smooth" });
          }}
          className="flex items-center justify-center gap-1.5 py-1.5 bg-white/[0.04] text-xs font-normal text-muted-foreground transition-colors duration-200 hover:text-white/80"
        >
          <ArrowDown className="h-3 w-3" />
          <span>Scroll to latest</span>
        </button>
      )}
    </div>
  );
}

/** Convert raw text output to structured OutputLine array */
export function parseOutputLines(raw: string, baseId = "line"): OutputLine[] {
  return raw
    .split("\n")
    .filter(Boolean)
    .map((text, i) => {
      const type: OutputLine["type"] = text.startsWith("$")
        ? "command"
        : text.toLowerCase().includes("error") ||
            text.toLowerCase().includes("err!")
          ? "error"
          : text.toLowerCase().includes("success") ||
              text.startsWith(">") ||
              text.includes("ready")
            ? "success"
            : text.startsWith("~") || text.toLowerCase().includes("starting")
              ? "system"
              : "info";
      return { id: `${baseId}-${i}`, text, type };
    });
}
