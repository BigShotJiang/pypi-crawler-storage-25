"use client";

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Lightbulb, Copy, Check, ArrowUpRight } from "lucide-react";
import { FONT } from "@/lib/tokens";
import { fetchLearnings } from "@/lib/api";
import type { LearningsResponse, LearningItem } from "@/lib/types";
import { formatDuration, formatCurrency } from "@/lib/utils";

/* ── Confidence badge ──────────────────────────────────────────────── */

function ConfidenceBadge({ confidence }: { confidence: number }) {
  const pct = Math.round(confidence * 100);
  let color: string;
  let bg: string;

  if (pct >= 80) {
    color = "#27a644";
    bg = "rgba(39,166,68,0.12)";
  } else if (pct >= 50) {
    color = "#d97706";
    bg = "rgba(217,119,6,0.12)";
  } else {
    color = "rgba(255,255,255,0.48)";
    bg = "rgba(255,255,255,0.06)";
  }

  return (
    <span
      className="font-mono"
      style={{
        fontSize: 10,
        fontWeight: 600,
        color,
        backgroundColor: bg,
        padding: "2px 6px",
        borderRadius: 4,
        letterSpacing: "0.02em",
      }}
    >
      {pct}%
    </span>
  );
}

/* ── Transferable badge ────────────────────────────────────────────── */

function TransferableBadge() {
  return (
    <span
      style={{
        fontSize: 10,
        fontWeight: 600,
        letterSpacing: "0.05em",
        textTransform: "uppercase" as const,
        color: "#5e6ad2",
        backgroundColor: "rgba(94,106,210,0.12)",
        padding: "2px 6px",
        borderRadius: 4,
      }}
    >
      Transferable
    </span>
  );
}

/* ── Single learning row ───────────────────────────────────────────── */

function LearningRow({ item, index }: { item: LearningItem; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -8 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.1 + index * 0.06, duration: 0.3 }}
      className="flex items-start gap-3"
      style={{
        padding: "10px 0",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      <span
        style={{
          color: "#27a644",
          fontSize: 14,
          lineHeight: "20px",
          flexShrink: 0,
          marginTop: 1,
        }}
      >
        &bull;
      </span>
      <div className="flex-1 min-w-0">
        <p
          style={{
            color: "rgba(255,255,255,0.8)",
            fontSize: 13,
            lineHeight: 1.5,
            letterSpacing: "-0.13px",
            fontFamily: FONT,
            margin: 0,
          }}
        >
          {item.insight}
        </p>
        <div className="flex items-center gap-2 mt-1.5 flex-wrap">
          <ConfidenceBadge confidence={item.confidence} />
          {item.transferable && <TransferableBadge />}
          {item.category !== "unknown" && item.category !== "success" && (
            <span
              className="font-mono"
              style={{
                fontSize: 10,
                color: "rgba(255,255,255,0.32)",
                letterSpacing: "0.02em",
              }}
            >
              {item.category.replace("_", " ")}
            </span>
          )}
        </div>
      </div>
    </motion.div>
  );
}

/* ── Main component ────────────────────────────────────────────────── */

interface LearningCardProps {
  taskId: string;
  /** If provided, uses this data instead of fetching */
  data?: LearningsResponse | null;
  className?: string;
}

export function LearningCard({ taskId, data: externalData, className }: LearningCardProps) {
  const [data, setData] = useState<LearningsResponse | null>(externalData ?? null);
  const [loading, setLoading] = useState(!externalData);
  const [copied, setCopied] = useState(false);

  const load = useCallback(async () => {
    if (externalData) return;
    try {
      const resp = await fetchLearnings(taskId);
      setData(resp);
    } catch {
      // Build mock learnings from task ID for demo fallback
      setData({
        task_id: taskId,
        task_name: "Task",
        status: "succeeded",
        attempt_count: 4,
        total_cost_usd: 0.32,
        total_time_ms: 12300,
        learnings: [
          { insight: "Run `npm install sharp` before starting the server — Next.js image optimization requires it", confidence: 0.95, transferable: true, category: "dependency_error" },
          { insight: "Use `--port 3001` or kill the process using port 3000 — don't hardcode port 3000", confidence: 0.92, transferable: true, category: "config_error" },
          { insight: "Use `Number(session.id)` for type conversion — TypeScript strict mode rejects implicit coercion", confidence: 0.88, transferable: true, category: "type_error" },
          { insight: "Solution: Project deployed successfully on port 3001", confidence: 0.95, transferable: true, category: "success" },
        ],
      });
    } finally {
      setLoading(false);
    }
  }, [taskId, externalData]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (externalData) {
      setData(externalData);
      setLoading(false);
    }
  }, [externalData]);

  function handleCopyMarkdown() {
    if (!data) return;
    const lines = [
      `## What I Learned`,
      `**Task:** ${data.task_name}`,
      `**Attempts:** ${data.attempt_count} | **Cost:** ${formatCurrency(data.total_cost_usd)} | **Time:** ${formatDuration(data.total_time_ms)}`,
      ``,
      ...data.learnings.map((l) => {
        const badges = [
          `${Math.round(l.confidence * 100)}% confidence`,
          l.transferable ? "transferable" : "",
          l.category !== "unknown" && l.category !== "success" ? l.category.replace("_", " ") : "",
        ].filter(Boolean).join(", ");
        return `- ${l.insight} _(${badges})_`;
      }),
    ];
    navigator.clipboard.writeText(lines.join("\n")).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  if (loading) {
    return (
      <div
        className={className}
        style={{
          backgroundColor: "#191a1b",
          borderRadius: 8,
          borderLeft: "3px solid rgba(39,166,68,0.3)",
          padding: "20px 24px",
        }}
      >
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full border-2 border-[rgba(255,255,255,0.12)] border-t-[rgba(255,255,255,0.5)] animate-spin" />
          <span style={{ color: "rgba(255,255,255,0.48)", fontSize: 13 }}>Loading learnings...</span>
        </div>
      </div>
    );
  }

  if (!data || data.learnings.length === 0) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
        className={className}
        style={{
          backgroundColor: "#191a1b",
          borderRadius: 8,
          borderLeft: "3px solid #27a644",
          overflow: "hidden",
        }}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between"
          style={{ padding: "16px 20px 0 20px" }}
        >
          <div className="flex items-center gap-2.5">
            <div
              className="flex items-center justify-center"
              style={{
                width: 28,
                height: 28,
                borderRadius: 7,
                backgroundColor: "rgba(39,166,68,0.12)",
              }}
            >
              <Lightbulb className="h-3.5 w-3.5" style={{ color: "#27a644" }} />
            </div>
            <span
              style={{
                color: "#ffffff",
                fontWeight: 600,
                fontSize: 14,
                letterSpacing: "-0.224px",
                fontFamily: FONT,
              }}
            >
              What I Learned
            </span>
          </div>

          <button
            type="button"
            onClick={handleCopyMarkdown}
            className="flex items-center gap-1.5 transition-all"
            style={{
              backgroundColor: copied ? "rgba(39,166,68,0.12)" : "rgba(255,255,255,0.04)",
              color: copied ? "#27a644" : "rgba(255,255,255,0.48)",
              fontSize: 11,
              fontWeight: 500,
              padding: "4px 10px",
              borderRadius: 6,
              border: "none",
              cursor: "pointer",
              letterSpacing: "-0.08px",
            }}
          >
            {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
            {copied ? "Copied" : "Copy as Markdown"}
          </button>
        </div>

        {/* Stats row */}
        <div
          className="flex items-center gap-4 flex-wrap"
          style={{ padding: "12px 20px 0 20px" }}
        >
          <span
            className="font-mono"
            style={{
              fontSize: 12,
              color: "rgba(255,255,255,0.48)",
              letterSpacing: "-0.12px",
            }}
          >
            {data.attempt_count} attempt{data.attempt_count !== 1 ? "s" : ""}
          </span>
          <span style={{ color: "rgba(255,255,255,0.12)" }}>|</span>
          <span
            className="font-mono"
            style={{
              fontSize: 12,
              color: "rgba(255,255,255,0.48)",
              letterSpacing: "-0.12px",
            }}
          >
            {formatCurrency(data.total_cost_usd)} total
          </span>
          <span style={{ color: "rgba(255,255,255,0.12)" }}>|</span>
          <span
            className="font-mono"
            style={{
              fontSize: 12,
              color: "rgba(255,255,255,0.48)",
              letterSpacing: "-0.12px",
            }}
          >
            {formatDuration(data.total_time_ms)}
          </span>
        </div>

        {/* Learnings list */}
        <div style={{ padding: "8px 20px 16px 20px" }}>
          {data.learnings.map((item, i) => (
            <LearningRow key={`${item.category}-${i}`} item={item} index={i} />
          ))}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
