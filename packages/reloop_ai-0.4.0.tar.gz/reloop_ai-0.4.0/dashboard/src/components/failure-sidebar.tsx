"use client";

import { useState, useMemo } from "react";
import type { FailureRecord } from "@/lib/types";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Brain,
  Lightbulb,
  ChevronRight,
  ChevronDown,
  Search,
  X,
  Pin,
  Trash2,
  AlertCircle,
} from "lucide-react";
import { FONT } from "@/lib/tokens";

/* ------------------------------------------------------------------ */
/*  Props                                                              */
/* ------------------------------------------------------------------ */

interface FailureSidebarProps {
  failures: FailureRecord[];
  recalledIds?: string[];
  className?: string;
}

/* ------------------------------------------------------------------ */
/*  Confidence Meter -- with decay visual                              */
/* ------------------------------------------------------------------ */

function confidenceColor(pct: number): string {
  if (pct >= 80) return "#27a644";
  if (pct >= 50) return "#eab308";
  return "#ef4444";
}

function confidenceTrackColor(pct: number): string {
  if (pct >= 80) return "rgba(39,166,68,0.12)";
  if (pct >= 50) return "rgba(234,179,8,0.12)";
  return "rgba(239,68,68,0.10)";
}

function formatRelativeTime(timestamp: string): string {
  const diffMs = Date.now() - new Date(timestamp).getTime();
  const mins = Math.floor(diffMs / 60_000);
  const hours = Math.floor(mins / 60);
  const days = Math.floor(hours / 24);
  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (mins > 0) return `${mins}m ago`;
  return "just now";
}

interface ConfidenceMeterProps {
  confidence: number;
  timestamp?: string;
}

function ConfidenceMeter({ confidence, timestamp }: ConfidenceMeterProps) {
  const pct = Math.round(confidence * 100);
  const barColor = confidenceColor(pct);
  const trackColor = confidenceTrackColor(pct);
  const isStale = pct < 50;
  const relTime = timestamp ? formatRelativeTime(timestamp) : null;

  return (
    <div className="space-y-1.5">
      <div className="flex items-center gap-2.5">
        <div
          className="flex-1 overflow-hidden"
          style={{
            height: "4px",
            borderRadius: "2px",
            backgroundColor: trackColor,
          }}
        >
          <div
            className="animate-confidence-fill"
            style={{
              height: "100%",
              borderRadius: "2px",
              width: `${pct}%`,
              backgroundColor: barColor,
              opacity: isStale ? 0.6 : 1,
            }}
          />
        </div>
        <span
          style={{
            fontSize: "12px",
            fontWeight: 600,
            color: barColor,
            letterSpacing: "-0.12px",
            fontFamily: FONT,
            fontVariantNumeric: "tabular-nums",
            opacity: isStale ? 0.6 : 1,
          }}
        >
          {pct}%
        </span>
      </div>
      {relTime && (
        <p
          style={{
            fontSize: "11px",
            fontWeight: 400,
            color: isStale ? "rgba(255,255,255,0.24)" : "rgba(255,255,255,0.48)",
            letterSpacing: "-0.08px",
            fontFamily: FONT,
          }}
        >
          {pct}% confidence · {relTime}
          {isStale && " · fading"}
        </p>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Category helpers                                                   */
/* ------------------------------------------------------------------ */

const CATEGORY_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  dependency_error: { bg: "rgba(139,92,246,0.10)", text: "#a78bfa", border: "rgba(139,92,246,0.2)" },
  runtime_error:    { bg: "rgba(239,68,68,0.10)", text: "#f87171", border: "rgba(239,68,68,0.2)" },
  config_error:     { bg: "rgba(234,179,8,0.10)", text: "#fbbf24", border: "rgba(234,179,8,0.2)" },
  type_error:       { bg: "rgba(59,130,246,0.10)", text: "#60a5fa", border: "rgba(59,130,246,0.2)" },
  network_error:    { bg: "rgba(236,72,153,0.10)", text: "#f472b6", border: "rgba(236,72,153,0.2)" },
  permission_error: { bg: "rgba(251,146,60,0.10)", text: "#fb923c", border: "rgba(251,146,60,0.2)" },
  timeout_error:    { bg: "rgba(234,179,8,0.10)", text: "#fbbf24", border: "rgba(234,179,8,0.2)" },
  unknown:          { bg: "rgba(255,255,255,0.06)", text: "rgba(255,255,255,0.48)", border: "rgba(255,255,255,0.08)" },
};

function getCategoryStyle(category: string) {
  return CATEGORY_COLORS[category] ?? CATEGORY_COLORS.unknown;
}

function categoryLabel(category: string): string {
  return category
    .replace(/_/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

/* ------------------------------------------------------------------ */
/*  Failure Card                                                       */
/* ------------------------------------------------------------------ */

interface FailureCardProps {
  failure: FailureRecord;
  isRecalled: boolean;
  index: number;
}

function FailureCard({ failure, isRecalled, index }: FailureCardProps) {
  const [expanded, setExpanded] = useState(isRecalled);
  const [pinned, setPinned] = useState(false);
  const [hovered, setHovered] = useState(false);

  const confidencePct = Math.round(failure.analysis.confidence * 100);
  const isStale = confidencePct < 50;
  const catStyle = getCategoryStyle(failure.signature.error_category);

  return (
    <div
      className="overflow-hidden animate-fade-in-up"
      style={{
        animationDelay: `${index * 60}ms`,
        animationFillMode: "both",
        borderRadius: "10px",
        backgroundColor: hovered ? "#2a2a2d" : "#1d1d1f",
        border: `1px solid ${
          isRecalled && hovered
            ? "rgba(41,151,255,0.3)"
            : hovered
              ? "rgba(255,255,255,0.12)"
              : "rgba(255,255,255,0.06)"
        }`,
        transition: "background-color 0.2s ease, border-color 0.2s ease, opacity 0.2s ease",
        opacity: isStale ? 0.65 : 1,
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Card header */}
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="w-full text-left p-3 flex items-start gap-2.5 group"
      >
        <div className="flex-1 min-w-0 space-y-2">
          <div className="flex items-center gap-1.5 flex-wrap">
            {isRecalled && (
              <span
                style={{
                  fontSize: "10px",
                  fontWeight: 700,
                  color: "#2997ff",
                  backgroundColor: "rgba(41,151,255,0.12)",
                  border: "1px solid rgba(41,151,255,0.2)",
                  borderRadius: "980px",
                  padding: "1px 8px",
                  letterSpacing: "0.04em",
                  fontFamily: FONT,
                  textTransform: "uppercase",
                }}
              >
                Recalled
              </span>
            )}
            {pinned && (
              <span
                style={{
                  fontSize: "10px",
                  fontWeight: 700,
                  color: "#eab308",
                  backgroundColor: "rgba(234,179,8,0.12)",
                  border: "1px solid rgba(234,179,8,0.2)",
                  borderRadius: "980px",
                  padding: "1px 8px",
                  letterSpacing: "0.04em",
                  fontFamily: FONT,
                  textTransform: "uppercase",
                }}
              >
                Pinned
              </span>
            )}
            {/* Error category badge */}
            <span
              className="inline-flex items-center gap-1"
              style={{
                fontSize: "10px",
                fontWeight: 600,
                color: catStyle.text,
                backgroundColor: catStyle.bg,
                border: `1px solid ${catStyle.border}`,
                borderRadius: "980px",
                padding: "1px 8px",
                letterSpacing: "0.02em",
                fontFamily: FONT,
              }}
            >
              <AlertCircle className="h-2.5 w-2.5" />
              {categoryLabel(failure.signature.error_category)}
            </span>
          </div>
          <p
            className="truncate"
            style={{
              fontSize: "13px",
              fontWeight: 500,
              color: "#ffffff",
              letterSpacing: "-0.08px",
              fontFamily: FONT,
            }}
          >
            {failure.signature.error_type}
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0 pt-0.5">
          {/* Mini confidence indicator */}
          <div
            className="flex items-center justify-center"
            style={{
              width: "28px",
              height: "28px",
              borderRadius: "50%",
              backgroundColor: confidenceTrackColor(confidencePct),
              position: "relative",
            }}
          >
            <span
              style={{
                fontSize: "9px",
                fontWeight: 700,
                color: confidenceColor(confidencePct),
                fontFamily: FONT,
                fontVariantNumeric: "tabular-nums",
              }}
            >
              {confidencePct}
            </span>
          </div>
          {expanded ? (
            <ChevronDown className="h-3.5 w-3.5" style={{ color: "rgba(255,255,255,0.48)" }} />
          ) : (
            <ChevronRight className="h-3.5 w-3.5" style={{ color: "rgba(255,255,255,0.35)" }} />
          )}
        </div>
      </button>

      {/* Expandable content */}
      {expanded && (
        <div
          className="px-3 pb-3 space-y-3 pt-1 animate-expand"
          style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}
        >
          {/* Root cause */}
          <div className="space-y-1">
            <p
              className="uppercase"
              style={{
                fontSize: "10px",
                fontWeight: 700,
                color: "rgba(255,255,255,0.4)",
                letterSpacing: "0.06em",
                fontFamily: FONT,
              }}
            >
              Root Cause
            </p>
            <p
              style={{
                fontSize: "13px",
                fontWeight: 400,
                color: "rgba(255,255,255,0.8)",
                lineHeight: 1.5,
                letterSpacing: "-0.08px",
                fontFamily: FONT,
              }}
            >
              {failure.analysis.root_cause}
            </p>
          </div>

          {/* Suggested fix */}
          <div
            className="flex items-start gap-2.5 p-2.5"
            style={{
              borderRadius: "8px",
              backgroundColor: "rgba(234,179,8,0.06)",
              border: "1px solid rgba(234,179,8,0.1)",
            }}
          >
            <Lightbulb className="h-3.5 w-3.5 shrink-0 mt-0.5" style={{ color: "#eab308" }} />
            <div>
              <p
                className="uppercase mb-1"
                style={{
                  fontSize: "10px",
                  fontWeight: 700,
                  color: "rgba(234,179,8,0.7)",
                  letterSpacing: "0.06em",
                  fontFamily: FONT,
                }}
              >
                Suggested Fix
              </p>
              <p
                style={{
                  fontSize: "13px",
                  fontWeight: 400,
                  color: "rgba(255,255,255,0.8)",
                  lineHeight: 1.5,
                  letterSpacing: "-0.08px",
                  fontFamily: FONT,
                }}
              >
                {failure.analysis.suggested_fix}
              </p>
            </div>
          </div>

          {/* Confidence meter */}
          <div className="space-y-1.5">
            <p
              className="uppercase"
              style={{
                fontSize: "10px",
                fontWeight: 700,
                color: "rgba(255,255,255,0.4)",
                letterSpacing: "0.06em",
                fontFamily: FONT,
              }}
            >
              Confidence
            </p>
            <ConfidenceMeter
              confidence={failure.analysis.confidence}
              timestamp={failure.timestamp}
            />
          </div>

          {/* Pin & Forget buttons */}
          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setPinned(!pinned);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5"
              style={{
                fontSize: "11px",
                fontWeight: 500,
                borderRadius: "8px",
                backgroundColor: pinned
                  ? "rgba(0,113,227,0.15)"
                  : "rgba(255,255,255,0.06)",
                border: `1px solid ${pinned ? "rgba(0,113,227,0.25)" : "rgba(255,255,255,0.06)"}`,
                color: pinned ? "#2997ff" : "rgba(255,255,255,0.7)",
                letterSpacing: "-0.08px",
                fontFamily: FONT,
                transition: "all 0.2s ease",
              }}
            >
              <Pin className={cn("h-3 w-3", pinned && "fill-current")} />
              {pinned ? "Pinned" : "Pin"}
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5"
              style={{
                fontSize: "11px",
                fontWeight: 500,
                borderRadius: "8px",
                backgroundColor: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.06)",
                color: "rgba(255,255,255,0.7)",
                letterSpacing: "-0.08px",
                fontFamily: FONT,
                transition: "all 0.2s ease",
              }}
            >
              <Trash2 className="h-3 w-3" />
              Forget
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main sidebar                                                       */
/* ------------------------------------------------------------------ */

export function FailureSidebar({
  failures,
  recalledIds = [],
  className,
}: FailureSidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);

  const recalledFailures = failures.filter((f) =>
    recalledIds.includes(f.id),
  );
  const otherFailures = failures.filter(
    (f) => !recalledIds.includes(f.id),
  );

  const filteredRecalled = useMemo(() => {
    if (!searchQuery) return recalledFailures;
    const q = searchQuery.toLowerCase();
    return recalledFailures.filter(
      (f) =>
        f.signature.error_type.toLowerCase().includes(q) ||
        f.signature.error_category.toLowerCase().includes(q) ||
        f.analysis.root_cause.toLowerCase().includes(q) ||
        f.analysis.suggested_fix.toLowerCase().includes(q),
    );
  }, [recalledFailures, searchQuery]);

  const filteredOther = useMemo(() => {
    if (!searchQuery) return otherFailures;
    const q = searchQuery.toLowerCase();
    return otherFailures.filter(
      (f) =>
        f.signature.error_type.toLowerCase().includes(q) ||
        f.signature.error_category.toLowerCase().includes(q) ||
        f.analysis.root_cause.toLowerCase().includes(q) ||
        f.analysis.suggested_fix.toLowerCase().includes(q),
    );
  }, [otherFailures, searchQuery]);

  const totalFiltered = filteredRecalled.length + filteredOther.length;

  return (
    <div className={cn("flex flex-col h-full", className)}>
      {/* Header */}
      <div className="flex items-center gap-2.5 px-3 py-3">
        <div
          className="flex items-center justify-center"
          style={{
            width: "28px",
            height: "28px",
            borderRadius: "8px",
            backgroundColor: "rgba(0,113,227,0.12)",
          }}
        >
          <Brain className="h-3.5 w-3.5 shrink-0" style={{ color: "#2997ff" }} />
        </div>
        <div className="flex-1 min-w-0">
          <h2
            style={{
              fontSize: "14px",
              fontWeight: 600,
              color: "#ffffff",
              letterSpacing: "-0.224px",
              fontFamily: FONT,
            }}
          >
            Failure Memory
          </h2>
        </div>
        {failures.length > 0 && (
          <span
            style={{
              fontSize: "11px",
              fontWeight: 600,
              color: "rgba(255,255,255,0.55)",
              backgroundColor: "rgba(255,255,255,0.06)",
              borderRadius: "980px",
              padding: "2px 10px",
              letterSpacing: "-0.08px",
              fontFamily: FONT,
              fontVariantNumeric: "tabular-nums",
            }}
          >
            {failures.length}
          </span>
        )}
        <button
          type="button"
          onClick={() => {
            setSearchOpen(!searchOpen);
            if (searchOpen) setSearchQuery("");
          }}
          className="p-1.5"
          style={{
            borderRadius: "8px",
            color: searchOpen ? "#ffffff" : "rgba(255,255,255,0.48)",
            backgroundColor: searchOpen ? "rgba(255,255,255,0.08)" : "transparent",
            transition: "all 0.2s ease",
          }}
        >
          <Search className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Search bar */}
      {searchOpen && (
        <div
          className="flex items-center gap-2 px-3 py-2 animate-slide-in-down"
          style={{
            backgroundColor: "rgba(255,255,255,0.04)",
            borderTop: "1px solid rgba(255,255,255,0.06)",
            borderBottom: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <Search className="h-3 w-3 shrink-0" style={{ color: "rgba(255,255,255,0.48)" }} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search failures..."
            className="flex-1 bg-transparent outline-none"
            style={{
              fontSize: "13px",
              fontWeight: 400,
              color: "#ffffff",
              letterSpacing: "-0.08px",
              fontFamily: FONT,
            }}
            autoFocus
          />
          {searchQuery && (
            <span
              style={{
                fontSize: "11px",
                fontWeight: 500,
                color: "rgba(255,255,255,0.4)",
                fontFamily: FONT,
                fontVariantNumeric: "tabular-nums",
              }}
            >
              {totalFiltered} result{totalFiltered !== 1 ? "s" : ""}
            </span>
          )}
          <button
            type="button"
            onClick={() => {
              setSearchQuery("");
              setSearchOpen(false);
            }}
            className="p-0.5"
            style={{
              borderRadius: "5px",
              color: "rgba(255,255,255,0.48)",
              transition: "color 0.2s ease",
            }}
          >
            <X className="h-3 w-3" />
          </button>
        </div>
      )}

      <ScrollArea className="flex-1">
        <div className="p-3 space-y-2.5">
          {failures.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-3 py-10 text-center animate-fade-in">
              <div
                className="flex items-center justify-center animate-breathe"
                style={{
                  width: "48px",
                  height: "48px",
                  borderRadius: "14px",
                  backgroundColor: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                <Brain className="h-5 w-5" style={{ color: "rgba(255,255,255,0.3)" }} />
              </div>
              <div className="space-y-1">
                <p
                  style={{
                    fontSize: "14px",
                    fontWeight: 600,
                    color: "rgba(255,255,255,0.7)",
                    letterSpacing: "-0.224px",
                    fontFamily: FONT,
                  }}
                >
                  No failures yet
                </p>
                <p
                  className="max-w-[200px]"
                  style={{
                    fontSize: "12px",
                    fontWeight: 400,
                    color: "rgba(255,255,255,0.35)",
                    letterSpacing: "-0.12px",
                    lineHeight: 1.5,
                    fontFamily: FONT,
                  }}
                >
                  The agent will learn from failures and store them here for future recall.
                </p>
              </div>
            </div>
          ) : totalFiltered === 0 && searchQuery ? (
            <div className="flex flex-col items-center justify-center gap-2.5 py-10 text-center animate-fade-in">
              <Search className="h-4 w-4" style={{ color: "rgba(255,255,255,0.3)" }} />
              <p
                style={{
                  fontSize: "13px",
                  fontWeight: 400,
                  color: "rgba(255,255,255,0.4)",
                  fontFamily: FONT,
                }}
              >
                No failures matching &quot;{searchQuery}&quot;
              </p>
            </div>
          ) : (
            <>
              {/* Recalled Memories section */}
              {filteredRecalled.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 px-1">
                    <div
                      style={{
                        width: "3px",
                        height: "12px",
                        borderRadius: "2px",
                        backgroundColor: "#2997ff",
                      }}
                    />
                    <p
                      className="uppercase"
                      style={{
                        fontSize: "10px",
                        fontWeight: 700,
                        color: "rgba(255,255,255,0.45)",
                        letterSpacing: "0.08em",
                        fontFamily: FONT,
                      }}
                    >
                      Recalled ({filteredRecalled.length})
                    </p>
                  </div>
                  {filteredRecalled.map((failure, idx) => (
                    <FailureCard
                      key={failure.id}
                      failure={failure}
                      isRecalled
                      index={idx}
                    />
                  ))}
                </div>
              )}

              {/* Learned Rules section */}
              {filteredOther.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 px-1">
                    <div
                      style={{
                        width: "3px",
                        height: "12px",
                        borderRadius: "2px",
                        backgroundColor: "rgba(255,255,255,0.2)",
                      }}
                    />
                    <p
                      className="uppercase"
                      style={{
                        fontSize: "10px",
                        fontWeight: 700,
                        color: "rgba(255,255,255,0.45)",
                        letterSpacing: "0.08em",
                        fontFamily: FONT,
                      }}
                    >
                      Learned ({filteredOther.length})
                    </p>
                  </div>
                  {filteredOther.map((failure, idx) => (
                    <FailureCard
                      key={failure.id}
                      failure={failure}
                      isRecalled={false}
                      index={idx + filteredRecalled.length}
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
