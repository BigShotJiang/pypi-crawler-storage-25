"use client";

import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import type { Attempt } from "@/lib/types";
import { cn } from "@/lib/utils";
import { TrendingDown, DollarSign, Zap, BarChart3 } from "lucide-react";

/* ── colour tokens (matching A/B page palette) ─────────────────────────── */

const C = {
  bg: "#000000",
  surface: "#0a0a0a",
  surfaceRaised: "#111111",
  border: "#1e1e1e",
  text: "#f4f4f5",
  textSecondary: "#a1a1aa",
  textMuted: "#52525b",
  accent: "#10b981",
  danger: "#ef4444",
  dangerGlow: "rgba(239,68,68,0.10)",
  dangerSubtle: "rgba(239,68,68,0.06)",
  success: "#10b981",
  successGlow: "rgba(16,185,129,0.10)",
  successSubtle: "rgba(16,185,129,0.06)",
} as const;

/* ── Animated counter hook ─────────────────────────────────────────────── */

function useAnimatedNumber(target: number, duration = 1000): number {
  const [value, setValue] = useState(0);
  const frameRef = useRef<number | null>(null);
  const startRef = useRef<number | null>(null);
  const startValueRef = useRef(0);

  useEffect(() => {
    startValueRef.current = value;
    startRef.current = null;

    function animate(timestamp: number) {
      if (!startRef.current) startRef.current = timestamp;
      const elapsed = timestamp - startRef.current;
      const progress = Math.min(elapsed / duration, 1);
      // Ease out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(startValueRef.current + (target - startValueRef.current) * eased);
      if (progress < 1) {
        frameRef.current = requestAnimationFrame(animate);
      }
    }

    frameRef.current = requestAnimationFrame(animate);
    return () => {
      if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target, duration]);

  return value;
}

/* ── Types ─────────────────────────────────────────────────────────────── */

export interface CostScoreboardProps {
  /** Cost of with-memory run (dollars) */
  withMemoryCost: number;
  /** Cost of without-memory run (dollars) */
  withoutMemoryCost: number;
  /** Attempts from the with-memory run */
  withMemoryAttempts: Attempt[];
  /** Attempts from the without-memory run */
  withoutMemoryAttempts: Attempt[];
  /** Optional aggregate savings across all tasks */
  totalSavedAllTasks?: number;
  className?: string;
  /** Mini version for the overview/dashboard page */
  mini?: boolean;
}

/* ── Per-attempt bar (coloured by side) ────────────────────────────────── */

function CostBars({
  attempts,
  color,
  label,
}: {
  attempts: Attempt[];
  color: string;
  label: string;
}) {
  const maxCost = Math.max(...attempts.map((a) => a.cost_usd), 0.001);

  return (
    <div className="space-y-2">
      <p
        className="uppercase font-mono"
        style={{
          color: C.textMuted,
          fontSize: 10,
          fontWeight: 600,
          letterSpacing: "0.06em",
        }}
      >
        {label}
      </p>
      <div className="flex items-end gap-1.5 h-10">
        {attempts.map((a, i) => {
          const heightPct = (a.cost_usd / maxCost) * 100;
          return (
            <div
              key={a.attempt_number}
              className="flex flex-col items-center gap-0.5"
            >
              <motion.div
                className="w-5 rounded-sm"
                style={{ backgroundColor: color, opacity: 0.75 }}
                initial={{ height: 0 }}
                animate={{ height: Math.max(3, heightPct * 0.4) }}
                transition={{ duration: 0.5, delay: i * 0.08, ease: "easeOut" }}
              />
              <span
                className="font-mono"
                style={{ fontSize: 9, color: C.textMuted }}
              >
                {a.attempt_number}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ── Mini scoreboard (for overview page) ───────────────────────────────── */

function MiniScoreboard({
  withMemoryCost,
  withoutMemoryCost,
  savedPct,
  savedAmount,
  className,
}: {
  withMemoryCost: number;
  withoutMemoryCost: number;
  savedPct: number;
  savedAmount: number;
  className?: string;
}) {
  const animPct = useAnimatedNumber(savedPct);

  return (
    <div
      className={cn("overflow-hidden", className)}
      style={{
        borderRadius: "var(--radius-lg, 12px)",
        border:
          savedAmount > 0.001
            ? `1px solid ${C.success}30`
            : `1px solid ${C.border}`,
        backgroundColor: savedAmount > 0.001 ? `${C.success}06` : C.surface,
      }}
    >
      <div
        className="flex items-center justify-between"
        style={{ padding: "14px 20px" }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{
              backgroundColor:
                savedAmount > 0.001 ? C.successGlow : `${C.text}08`,
            }}
          >
            <TrendingDown
              className="h-4 w-4"
              style={{ color: savedAmount > 0.001 ? C.success : C.textMuted }}
            />
          </div>
          <div>
            <p
              className="text-sm font-semibold tracking-tight"
              style={{ color: C.text, margin: 0 }}
            >
              Memory Savings
            </p>
            <p className="text-xs" style={{ color: C.textMuted, margin: 0 }}>
              ${withMemoryCost.toFixed(3)} vs ${withoutMemoryCost.toFixed(3)}{" "}
              without memory
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {savedAmount > 0.001 && (
            <motion.span
              className="font-mono font-semibold"
              style={{
                color: C.success,
                fontSize: 20,
                letterSpacing: "-0.3px",
              }}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: 0.3 }}
            >
              -{Math.round(animPct)}%
            </motion.span>
          )}
          <span
            className="font-mono tabular-nums"
            style={{
              color: savedAmount > 0.001 ? C.success : C.textMuted,
              fontSize: 14,
              fontWeight: 600,
            }}
          >
            ${savedAmount.toFixed(3)} saved
          </span>
        </div>
      </div>
    </div>
  );
}

/* ── Full scoreboard (for A/B page) ────────────────────────────────────── */

export function CostScoreboard({
  withMemoryCost,
  withoutMemoryCost,
  withMemoryAttempts,
  withoutMemoryAttempts,
  totalSavedAllTasks,
  className,
  mini = false,
}: CostScoreboardProps) {
  const savedAmount = Math.max(0, withoutMemoryCost - withMemoryCost);
  const savedPct =
    withoutMemoryCost > 0
      ? Math.round((savedAmount / withoutMemoryCost) * 100)
      : 0;

  // Animated values
  const animWithout = useAnimatedNumber(withoutMemoryCost);
  const animWith = useAnimatedNumber(withMemoryCost);
  const animPct = useAnimatedNumber(savedPct);

  const displayTotalSaved = totalSavedAllTasks ?? savedAmount;

  if (mini) {
    return (
      <MiniScoreboard
        withMemoryCost={withMemoryCost}
        withoutMemoryCost={withoutMemoryCost}
        savedPct={savedPct}
        savedAmount={savedAmount}
        className={className}
      />
    );
  }

  return (
    <div
      className={cn("overflow-hidden", className)}
      style={{
        borderRadius: 16,
        border: `1px solid ${savedAmount > 0.001 ? `${C.success}25` : C.border}`,
        backgroundColor: C.surface,
      }}
    >
      {/* Top accent line */}
      {savedAmount > 0.001 && (
        <div
          style={{
            height: 2,
            background: `linear-gradient(90deg, ${C.success}60, ${C.success}10)`,
          }}
        />
      )}

      <div className="p-5 lg:p-6 space-y-5">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{
              backgroundColor: C.successGlow,
              border: `1.5px solid ${C.success}20`,
            }}
          >
            <BarChart3 className="h-4 w-4" style={{ color: C.success }} />
          </div>
          <div>
            <h3
              style={{
                color: C.text,
                fontWeight: 600,
                fontSize: 16,
                letterSpacing: "-0.3px",
                lineHeight: 1.3,
                margin: 0,
              }}
            >
              Cost Savings
            </h3>
            <p
              style={{
                color: C.textMuted,
                fontSize: 12,
                letterSpacing: "-0.12px",
                margin: 0,
              }}
            >
              Memory-informed vs blind retry costs
            </p>
          </div>
        </div>

        {/* Big numbers row */}
        <div className="grid grid-cols-3 gap-4">
          {/* Without memory cost */}
          <div
            className="p-4 rounded-xl text-center"
            style={{
              backgroundColor: C.dangerSubtle,
              border: `1px solid ${C.danger}15`,
            }}
          >
            <p
              className="uppercase font-mono"
              style={{
                color: `${C.danger}80`,
                fontSize: 10,
                fontWeight: 600,
                letterSpacing: "0.06em",
                marginBottom: 6,
              }}
            >
              Without Memory
            </p>
            <p
              className="font-mono tabular-nums"
              style={{
                color: `${C.danger}cc`,
                fontWeight: 700,
                fontSize: 26,
                letterSpacing: "-0.5px",
                lineHeight: 1.15,
              }}
            >
              ${animWithout.toFixed(3)}
            </p>
            <p
              className="font-mono"
              style={{ color: C.textMuted, fontSize: 11, marginTop: 4 }}
            >
              {withoutMemoryAttempts.length} attempt
              {withoutMemoryAttempts.length !== 1 ? "s" : ""}
            </p>
          </div>

          {/* With memory cost */}
          <div
            className="p-4 rounded-xl text-center"
            style={{
              backgroundColor: C.successSubtle,
              border: `1px solid ${C.success}15`,
            }}
          >
            <p
              className="uppercase font-mono"
              style={{
                color: `${C.success}80`,
                fontSize: 10,
                fontWeight: 600,
                letterSpacing: "0.06em",
                marginBottom: 6,
              }}
            >
              With Memory
            </p>
            <p
              className="font-mono tabular-nums"
              style={{
                color: C.success,
                fontWeight: 700,
                fontSize: 26,
                letterSpacing: "-0.5px",
                lineHeight: 1.15,
              }}
            >
              ${animWith.toFixed(3)}
            </p>
            <p
              className="font-mono"
              style={{ color: C.textMuted, fontSize: 11, marginTop: 4 }}
            >
              {withMemoryAttempts.length} attempt
              {withMemoryAttempts.length !== 1 ? "s" : ""}
            </p>
          </div>

          {/* Savings percentage */}
          <div
            className="p-4 rounded-xl text-center relative overflow-hidden"
            style={{
              backgroundColor:
                savedAmount > 0.001 ? `${C.success}0a` : `${C.text}04`,
              border: `1px solid ${savedAmount > 0.001 ? `${C.success}25` : C.border}`,
              boxShadow:
                savedAmount > 0.001 ? `0 0 30px ${C.success}10` : "none",
            }}
          >
            <p
              className="uppercase font-mono"
              style={{
                color: savedAmount > 0.001 ? C.success : C.textMuted,
                fontSize: 10,
                fontWeight: 600,
                letterSpacing: "0.06em",
                marginBottom: 6,
              }}
            >
              Saved
            </p>
            <motion.p
              className="font-mono tabular-nums"
              style={{
                color: savedAmount > 0.001 ? C.success : C.textMuted,
                fontWeight: 700,
                fontSize: 32,
                letterSpacing: "-0.5px",
                lineHeight: 1.15,
              }}
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.4, delay: 0.6 }}
            >
              {Math.round(animPct)}%
            </motion.p>
            <p
              className="font-mono tabular-nums"
              style={{
                color: savedAmount > 0.001 ? `${C.success}99` : C.textMuted,
                fontSize: 12,
                fontWeight: 600,
                marginTop: 4,
              }}
            >
              ${savedAmount.toFixed(3)}
            </p>
          </div>
        </div>

        {/* Cost bars — side by side */}
        <div
          className="grid grid-cols-2 gap-6 pt-2"
          style={{
            borderTop: `1px solid ${C.border}`,
            paddingTop: 16,
          }}
        >
          <CostBars
            attempts={withoutMemoryAttempts}
            color={C.danger}
            label="Blind Retry Cost"
          />
          <CostBars
            attempts={withMemoryAttempts}
            color={C.success}
            label="Memory-Informed Cost"
          />
        </div>

        {/* Aggregate savings line */}
        {savedAmount > 0.001 && (
          <motion.div
            className="flex items-center justify-center gap-2 py-2.5 rounded-lg"
            style={{
              backgroundColor: C.successGlow,
              border: `1px solid ${C.success}20`,
            }}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.8 }}
          >
            <DollarSign className="h-3.5 w-3.5" style={{ color: C.success }} />
            <span
              className="font-mono"
              style={{
                color: C.success,
                fontSize: 13,
                fontWeight: 600,
                letterSpacing: "-0.15px",
              }}
            >
              Total saved across all tasks: ${displayTotalSaved.toFixed(3)}
            </span>
          </motion.div>
        )}
      </div>
    </div>
  );
}
