"use client";

import { useState } from "react";
import type { Attempt } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Copy, Check, ChevronDown, ChevronRight, Maximize2, Minimize2 } from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Props & types                                                      */
/* ------------------------------------------------------------------ */

interface DiffViewerProps {
  leftAttempt: Attempt;
  rightAttempt: Attempt;
  className?: string;
}

interface DiffLine {
  text: string;
  kind: "left-only" | "right-only" | "common";
}

/* ------------------------------------------------------------------ */
/*  Diff algorithm                                                     */
/* ------------------------------------------------------------------ */

/** Simple line-by-line LCS diff */
function diffLines(leftLines: string[], rightLines: string[]): DiffLine[] {
  const m = leftLines.length;
  const n = rightLines.length;

  const dp: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (leftLines[i - 1] === rightLines[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1] + 1;
      } else {
        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
      }
    }
  }

  const result: DiffLine[] = [];
  let i = m;
  let j = n;
  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && leftLines[i - 1] === rightLines[j - 1]) {
      result.unshift({ text: leftLines[i - 1], kind: "common" });
      i--;
      j--;
    } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
      result.unshift({ text: rightLines[j - 1], kind: "right-only" });
      j--;
    } else {
      result.unshift({ text: leftLines[i - 1], kind: "left-only" });
      i--;
    }
  }
  return result;
}

/** Collect all output lines from an attempt's steps */
function attemptOutput(attempt: Attempt): string {
  return attempt.steps
    .map((s) => {
      const parts: string[] = [];
      if (s.command) parts.push(`$ ${s.command}`);
      if (s.output) parts.push(s.output);
      if (s.error) parts.push(`ERROR: ${s.error}`);
      return parts.join("\n");
    })
    .join("\n");
}

/* ------------------------------------------------------------------ */
/*  Copy button                                                        */
/* ------------------------------------------------------------------ */

function CopyButton({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);

  function handleCopy() {
    void navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <button
      type="button"
      onClick={handleCopy}
      className="flex items-center gap-1 p-1 rounded-[5px] text-muted-foreground transition-colors duration-200 hover:text-white/80"
      title={`Copy ${label || "content"}`}
    >
      {copied ? (
        <Check className="h-3 w-3 text-emerald-500" />
      ) : (
        <Copy className="h-3 w-3" />
      )}
    </button>
  );
}

/* ------------------------------------------------------------------ */
/*  Diff grouping                                                      */
/* ------------------------------------------------------------------ */

/** Group consecutive common lines for collapsible sections */
interface DiffGroup {
  kind: "changes" | "common";
  lines: DiffLine[];
  startIndex: number;
}

function groupDiffLines(diff: DiffLine[]): DiffGroup[] {
  const groups: DiffGroup[] = [];
  let currentGroup: DiffGroup | null = null;

  diff.forEach((line, idx) => {
    const groupKind = line.kind === "common" ? "common" : "changes";

    if (!currentGroup || currentGroup.kind !== groupKind) {
      if (currentGroup) groups.push(currentGroup);
      currentGroup = { kind: groupKind, lines: [line], startIndex: idx };
    } else {
      currentGroup.lines.push(line);
    }
  });

  if (currentGroup) groups.push(currentGroup);
  return groups;
}

/* ------------------------------------------------------------------ */
/*  Diff column                                                        */
/* ------------------------------------------------------------------ */

function DiffColumn({
  lines,
  side,
}: {
  lines: DiffLine[];
  side: "left" | "right";
}) {
  const groups = groupDiffLines(lines);
  let lineNum = 1;

  return (
    <div className="flex-1 min-w-0 overflow-x-auto">
      <div className="min-w-0">
        {groups.map((group, gIdx) => {
          if (group.kind === "common" && group.lines.length > 4) {
            return (
              <CollapsibleCommon
                key={gIdx}
                lines={group.lines}
                side={side}
                startLineNum={lineNum}
                onCount={(n) => { lineNum += n; }}
              />
            );
          }

          return group.lines.map((line, idx) => {
            const isOwnSide = side === "left" ? line.kind === "left-only" : line.kind === "right-only";
            const isOtherSide = side === "left" ? line.kind === "right-only" : line.kind === "left-only";

            if (isOtherSide) {
              return (
                <div
                  key={`${gIdx}-${idx}`}
                  className="px-3 flex items-center h-[22px] bg-white/[0.01]"
                >
                  <span className="w-6 text-[11px] font-mono select-none">&nbsp;</span>
                </div>
              );
            }

            const currentLineNum = lineNum++;

            // Line colors
            let bgClass = "";
            let textClass = "text-white/80";
            let numClass = "text-white/20";

            if (line.kind === "common") {
              textClass = "text-muted-foreground";
              numClass = "text-white/20";
            } else if (isOwnSide && side === "left") {
              bgClass = "bg-red-500/[0.04]";
              textClass = "text-white/80";
              numClass = "text-red-500/40";
            } else if (isOwnSide && side === "right") {
              bgClass = "bg-emerald-500/[0.04]";
              textClass = "text-white/80";
              numClass = "text-emerald-500/40";
            }

            return (
              <div
                key={`${gIdx}-${idx}`}
                className={cn(
                  "flex items-start gap-0 whitespace-pre-wrap break-all font-mono leading-[22px] text-[13px]",
                  bgClass,
                  textClass,
                )}
              >
                <span
                  className={cn("shrink-0 text-right pr-2 select-none w-8 text-[11px] font-mono", numClass)}
                >
                  {currentLineNum}
                </span>
                <span
                  className={cn(
                    "shrink-0 text-center select-none w-4 text-[11px] font-mono",
                    isOwnSide
                      ? cn(
                          "font-semibold",
                          side === "left" ? "text-red-500" : "text-emerald-500",
                        )
                      : "text-white/20",
                  )}
                >
                  {isOwnSide ? (side === "left" ? "-" : "+") : " "}
                </span>
                <span className="flex-1 min-w-0 px-2">{line.text}</span>
              </div>
            );
          });
        })}
        {lines.length === 0 && (
          <div className="px-3 py-4 text-xs font-normal text-muted-foreground italic">
            No output
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Collapsible common section                                         */
/* ------------------------------------------------------------------ */

function CollapsibleCommon({
  lines,
  side,
  startLineNum,
  onCount,
}: {
  lines: DiffLine[];
  side: "left" | "right";
  startLineNum: number;
  onCount: (n: number) => void;
}) {
  const [expanded, setExpanded] = useState(false);

  const visibleLines = lines.filter((l) => {
    if (side === "left") return l.kind !== "right-only";
    return l.kind !== "left-only";
  });

  onCount(visibleLines.length);

  if (!expanded) {
    return (
      <button
        type="button"
        onClick={() => setExpanded(true)}
        className="w-full flex items-center gap-1.5 px-3 py-1 bg-white/[0.02] text-[11px] text-muted-foreground font-mono transition-colors duration-200 hover:bg-white/[0.04]"
      >
        <ChevronRight className="h-3 w-3" />
        <span>{visibleLines.length} unchanged lines</span>
      </button>
    );
  }

  let lineNum = startLineNum;
  return (
    <div>
      <button
        type="button"
        onClick={() => setExpanded(false)}
        className="w-full flex items-center gap-1.5 px-3 py-0.5 bg-white/[0.02] text-[11px] text-muted-foreground font-mono transition-colors duration-200 hover:bg-white/[0.04]"
      >
        <ChevronDown className="h-3 w-3" />
        <span>collapse</span>
      </button>
      {lines.map((line, idx) => {
        const isOtherSide = side === "left" ? line.kind === "right-only" : line.kind === "left-only";
        if (isOtherSide) {
          return (
            <div
              key={idx}
              className="px-3 h-[22px] bg-white/[0.01]"
            />
          );
        }
        const currentLineNum = lineNum++;
        return (
          <div
            key={idx}
            className="flex items-start gap-0 whitespace-pre-wrap break-all font-mono leading-[22px] text-[13px] text-muted-foreground"
          >
            <span className="shrink-0 text-right pr-2 select-none w-8 text-[11px] font-mono text-white/20">
              {currentLineNum}
            </span>
            <span className="shrink-0 text-center select-none w-4 text-[11px] font-mono text-white/20">
              {" "}
            </span>
            <span className="flex-1 min-w-0 px-2">{line.text}</span>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main component                                                     */
/* ------------------------------------------------------------------ */

export function DiffViewer({ leftAttempt, rightAttempt, className }: DiffViewerProps) {
  const [expanded, setExpanded] = useState(true);

  const leftText = attemptOutput(leftAttempt);
  const rightText = attemptOutput(rightAttempt);

  const leftLines = leftText ? leftText.split("\n") : [];
  const rightLines = rightText ? rightText.split("\n") : [];

  const diff = diffLines(leftLines, rightLines);

  const removedCount = diff.filter((l) => l.kind === "left-only").length;
  const addedCount = diff.filter((l) => l.kind === "right-only").length;
  const commonCount = diff.filter((l) => l.kind === "common").length;

  return (
    <div
      className={cn("overflow-hidden rounded-lg", className)}
      style={{ backgroundColor: "var(--apple-bg-near-black)" }}
    >
      {/* Column headers */}
      <div className="flex">
        <div className="flex-1 px-3 py-2.5 flex items-center gap-2 bg-white/[0.03]">
          <span className="inline-block shrink-0 w-1.5 h-1.5 rounded-full bg-red-500" />
          <span className="text-xs font-semibold text-white tracking-tight">
            Attempt {leftAttempt.attempt_number}
          </span>
          <span className="ml-auto flex items-center gap-2">
            <span className="uppercase text-[10px] font-normal text-muted-foreground tracking-widest">
              {leftAttempt.status}
            </span>
            <CopyButton text={leftText} label="left side" />
          </span>
        </div>
        <div className="flex-1 px-3 py-2.5 flex items-center gap-2 bg-white/[0.05]">
          <span className="inline-block shrink-0 w-1.5 h-1.5 rounded-full bg-emerald-500" />
          <span className="text-xs font-semibold text-white tracking-tight">
            Attempt {rightAttempt.attempt_number}
          </span>
          <span className="ml-auto flex items-center gap-2">
            <span className="uppercase text-[10px] font-normal text-muted-foreground tracking-widest">
              {rightAttempt.status}
            </span>
            <CopyButton text={rightText} label="right side" />
          </span>
        </div>
      </div>

      {/* Stats bar */}
      <div className="flex items-center gap-4 px-4 py-1.5 bg-white/[0.02] text-[11px] text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-red-500" />
          <span className="text-red-500 font-semibold">{removedCount}</span>
          removed
        </span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500" />
          <span className="text-emerald-500 font-semibold">{addedCount}</span>
          added
        </span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-white/30" />
          <span>{commonCount}</span>
          unchanged
        </span>

        {/* Diff visual bar */}
        <div className="flex-1 flex items-center gap-0 overflow-hidden h-[2px] rounded-full bg-white/[0.06]">
          {removedCount > 0 && (
            <div
              className="h-full bg-red-500"
              style={{ width: `${(removedCount / (removedCount + addedCount + commonCount)) * 100}%` }}
            />
          )}
          {commonCount > 0 && (
            <div
              className="h-full bg-white/20"
              style={{ width: `${(commonCount / (removedCount + addedCount + commonCount)) * 100}%` }}
            />
          )}
          {addedCount > 0 && (
            <div
              className="h-full bg-emerald-500"
              style={{ width: `${(addedCount / (removedCount + addedCount + commonCount)) * 100}%` }}
            />
          )}
        </div>

        <button
          type="button"
          onClick={() => setExpanded(!expanded)}
          className="p-1 rounded-[5px] text-muted-foreground transition-colors duration-200 hover:text-white/80"
          title={expanded ? "Collapse diff" : "Expand diff"}
        >
          {expanded ? <Minimize2 className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
        </button>
      </div>

      {/* Side-by-side diff */}
      {expanded && (
        <div className="flex max-h-[400px] overflow-y-auto terminal-scroll">
          <div className="flex-1 min-w-0" style={{ backgroundColor: "var(--apple-bg-near-black)" }}>
            <DiffColumn lines={diff} side="left" />
          </div>
          <div className="flex-1 min-w-0" style={{ backgroundColor: "#212123" }}>
            <DiffColumn lines={diff} side="right" />
          </div>
        </div>
      )}
    </div>
  );
}
