"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { useRouter, useParams } from "next/navigation";
import {
  RotateCcw,
  RefreshCw,
  Rewind,
  CheckCircle2,
  DollarSign,
  Zap,
  FileDiff,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Play,
  Timer,
  AlertTriangle,
  ShieldAlert,
} from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { Timeline } from "@/components/timeline";
import { FailureSidebar } from "@/components/failure-sidebar";
import { LiveOutput, parseOutputLines } from "@/components/live-output";
import { CostTracker } from "@/components/cost-tracker";
import { DiffViewer } from "@/components/diff-viewer";
import { LearningCard } from "@/components/learning-card";
import {
  fetchTask,
  getMockTask,
  getMockFailures,
  subscribeToTimeline,
  fetchCheckpoints,
  restoreCheckpoint,
  retryTask,
  predictFailures,
} from "@/lib/api";

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";
import type { Task, FailureRecord, Checkpoint, TimelineEvent, TaskStatus, PredictionResult } from "@/lib/types";
import { cn } from "@/lib/utils";
import type { OutputLine } from "@/components/live-output";

/* ── Apple-style status indicator ──────────────────────────────────────── */

function StatusBadge({ status }: { status: TaskStatus }) {
  const base =
    "inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg h-auto";

  switch (status) {
    case "succeeded":
      return (
        <span
          className={cn(base)}
          style={{
            backgroundColor: "#272729",
            color: "rgba(255,255,255,0.8)",
            fontWeight: 400,
            fontSize: 12,
            letterSpacing: "-0.12px",
          }}
        >
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: "#27a644" }} />
          Succeeded
        </span>
      );
    case "running":
      return (
        <span
          className={cn(base)}
          style={{
            backgroundColor: "#272729",
            color: "rgba(255,255,255,0.8)",
            fontWeight: 400,
            fontSize: 12,
            letterSpacing: "-0.12px",
          }}
        >
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full rounded-full opacity-40 animate-ping" style={{ backgroundColor: "#d97706" }} />
            <span className="relative inline-flex h-2 w-2 rounded-full" style={{ backgroundColor: "#d97706" }} />
          </span>
          Running
        </span>
      );
    case "failed":
      return (
        <span
          className={cn(base)}
          style={{
            backgroundColor: "#272729",
            color: "rgba(255,255,255,0.8)",
            fontWeight: 400,
            fontSize: 12,
            letterSpacing: "-0.12px",
          }}
        >
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: "#ef4444" }} />
          Failed
        </span>
      );
    case "abandoned":
      return (
        <span
          className={cn(base)}
          style={{
            backgroundColor: "#272729",
            color: "rgba(255,255,255,0.48)",
            fontWeight: 400,
            fontSize: 12,
            letterSpacing: "-0.12px",
          }}
        >
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: "rgba(255,255,255,0.48)" }} />
          Abandoned
        </span>
      );
    default:
      return (
        <span
          className={cn(base)}
          style={{
            backgroundColor: "#272729",
            color: "rgba(255,255,255,0.48)",
            fontWeight: 400,
            fontSize: 12,
          }}
        >
          {status}
        </span>
      );
  }
}

/* ── Elapsed time counter ───────────────────────────────────────────────── */

function ElapsedTime({ startedAt, completedAt }: { startedAt: string; completedAt: string | null }) {
  const [elapsed, setElapsed] = useState("");

  useEffect(() => {
    function update() {
      const start = new Date(startedAt).getTime();
      const end = completedAt ? new Date(completedAt).getTime() : Date.now();
      const diffMs = end - start;
      const seconds = Math.floor(diffMs / 1000);
      const minutes = Math.floor(seconds / 60);
      const hours = Math.floor(minutes / 60);

      if (hours > 0) {
        setElapsed(`${hours}h ${minutes % 60}m ${seconds % 60}s`);
      } else if (minutes > 0) {
        setElapsed(`${minutes}m ${seconds % 60}s`);
      } else {
        setElapsed(`${seconds}s`);
      }
    }

    update();
    if (!completedAt) {
      const interval = setInterval(update, 1000);
      return () => clearInterval(interval);
    }
  }, [startedAt, completedAt]);

  return (
    <div className="flex items-center gap-1.5" style={{ color: "rgba(255,255,255,0.48)", fontSize: 12, letterSpacing: "-0.12px" }}>
      <Timer className="h-3 w-3" />
      <span className="font-mono tabular-nums">{elapsed}</span>
    </div>
  );
}

/* ── Main page ──────────────────────────────────────────────────────────── */

export default function TaskDetailPage() {
  const router = useRouter();
  const params = useParams();
  const taskId = params.id as string;

  const [task, setTask] = useState<Task | null>(null);
  const [failures, setFailures] = useState<FailureRecord[]>([]);
  const [checkpoints, setCheckpoints] = useState<Checkpoint[]>([]);
  const [outputLines, setOutputLines] = useState<OutputLine[]>([]);
  const [loading, setLoading] = useState(true);
  const [rewinding, setRewinding] = useState(false);
  const [retrying, setRetrying] = useState(false);
  const [diffPairIndex, setDiffPairIndex] = useState(0);
  const [diffOpen, setDiffOpen] = useState(false);
  const [predictions, setPredictions] = useState<PredictionResult[]>([]);
  const lineCountRef = useRef(0);

  const appendLine = useCallback((text: string, type: OutputLine["type"] = "info") => {
    const id = `line-${lineCountRef.current++}`;
    setOutputLines((prev) => [...prev.slice(-199), { id, text, type, timestamp: new Date().toISOString() }]);
  }, []);

  const loadFailures = useCallback(async () => {
    try {
      const resp = await fetch(`${API_URL}/v1/memories/failures?task_id=${taskId}`);
      if (resp.ok) {
        const data = await resp.json() as FailureRecord[];
        setFailures(data);
      }
    } catch {
      // ignore failures fetch errors silently
    }
  }, [taskId]);

  const loadTask = useCallback(async () => {
    try {
      const [t, ckpts] = await Promise.all([
        fetchTask(taskId),
        fetchCheckpoints(taskId).catch(() => [] as Checkpoint[]),
      ]);
      setTask(t);
      setCheckpoints(ckpts);
      void loadFailures();

      // Load predictions for this task
      predictFailures(t.instruction).then((preds) => {
        setPredictions(preds);
      }).catch(() => {
        // Fall back to mock predictions
      });

      const lines: OutputLine[] = [];
      t.attempts.forEach((attempt) => {
        lines.push(...parseOutputLines(
          `Attempt ${attempt.attempt_number} started`,
          `init-${attempt.attempt_number}`,
        ).map((l) => ({ ...l, type: "system" as OutputLine["type"] })));
        attempt.steps.forEach((step) => {
          if (step.command) {
            lines.push({ id: `cmd-${attempt.attempt_number}-${step.step_number}`, text: step.command, type: "command" });
          }
          if (step.output) {
            lines.push(...parseOutputLines(step.output, `out-${attempt.attempt_number}-${step.step_number}`));
          }
          if (step.error) {
            lines.push({ id: `err-${attempt.attempt_number}-${step.step_number}`, text: step.error, type: "error" });
          }
        });
      });
      setOutputLines(lines);
    } catch {
      const mockTask = getMockTask(taskId);
      setTask(mockTask);
      setFailures(getMockFailures());
      setPredictions([
        { error_type: "ModuleNotFoundError", prediction_score: 0.68, root_cause: "Missing npm dependency", suggested_prevention: "Run npm install sharp before build", based_on_failures: 3 },
        { error_type: "EADDRINUSE", prediction_score: 0.54, root_cause: "Port already occupied", suggested_prevention: "Use --port 3001 or kill existing process", based_on_failures: 2 },
        { error_type: "TS2322", prediction_score: 0.41, root_cause: "Type mismatch in auth module", suggested_prevention: "Add explicit type conversions for session IDs", based_on_failures: 2 },
      ]);
      const lines: OutputLine[] = [];
      mockTask.attempts.forEach((attempt) => {
        lines.push({ id: `sys-${attempt.attempt_number}`, text: `Attempt ${attempt.attempt_number} started`, type: "system" });
        attempt.steps.forEach((step) => {
          if (step.command) lines.push({ id: `cmd-${attempt.attempt_number}-${step.step_number}`, text: step.command, type: "command" });
          if (step.output) lines.push(...parseOutputLines(step.output, `out-${attempt.attempt_number}-${step.step_number}`));
          if (step.error) lines.push({ id: `err-${attempt.attempt_number}-${step.step_number}`, text: step.error, type: "error" });
        });
      });
      setOutputLines(lines);
    } finally {
      setLoading(false);
    }
  }, [taskId, loadFailures]);

  useEffect(() => {
    void loadTask();
  }, [loadTask]);

  useEffect(() => {
    if (!task || task.status !== "running") return;

    const cleanup = subscribeToTimeline(taskId, (event: TimelineEvent) => {
      appendLine(event.message || JSON.stringify(event.data), "info");

      if (event.event_type === "step.started" || event.event_type === "step.completed") {
        void loadTask();
      }
      if (event.event_type === "memory.stored") {
        void loadFailures();
      }
      if (event.event_type === "prediction" && event.data?.predictions) {
        setPredictions(event.data.predictions as PredictionResult[]);
      }
    });

    return cleanup;
  }, [task, taskId, appendLine, loadTask, loadFailures]);

  async function handleRewind() {
    if (!task || checkpoints.length === 0) return;
    const latest = checkpoints[checkpoints.length - 1];
    setRewinding(true);
    appendLine(`Rewinding to checkpoint ${latest.id.slice(0, 8)}...`, "system");
    try {
      await restoreCheckpoint(taskId, latest.id);
      appendLine("Checkpoint restored in 25ms -- resuming from saved state", "success");
      await loadTask();
    } catch {
      appendLine("Rewind used saved snapshot (mock mode)", "success");
    } finally {
      setRewinding(false);
    }
  }

  async function handleRetry() {
    if (!task) return;
    setRetrying(true);
    appendLine("Retrying task...", "system");
    try {
      await retryTask(taskId);
      appendLine("Retry initiated", "success");
      await loadTask();
    } catch {
      appendLine("Retry requested (mock mode)", "success");
    } finally {
      setRetrying(false);
    }
  }

  const latestAttempt = task?.attempts[task.attempts.length - 1];
  const recalledIds = latestAttempt?.recalled_memories ?? [];

  // Compute which predictions matched actual failures
  const actualErrorTypes = new Set(
    failures.map((f) => f.signature.error_type.toLowerCase()),
  );
  const predictionsWithMatches: (PredictionResult & { matched: boolean })[] =
    predictions.map((p) => ({
      ...p,
      matched: actualErrorTypes.has(p.error_type.toLowerCase()),
    }));

  /* Loading state */
  if (loading) {
    return (
      <AppShell>
        <div className="flex-1 flex items-center justify-center">
          <div className="flex flex-col items-center gap-4">
            <div className="w-6 h-6 rounded-full border-2 border-[rgba(255,255,255,0.12)] border-t-[rgba(255,255,255,0.8)] animate-spin" />
            <span style={{ color: "rgba(255,255,255,0.48)", fontSize: 14, fontWeight: 400, letterSpacing: "-0.224px" }}>Loading task...</span>
          </div>
        </div>
      </AppShell>
    );
  }

  /* Not found */
  if (!task) {
    return (
      <AppShell>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center space-y-4">
            <p style={{ color: "rgba(255,255,255,0.48)", fontSize: 17, letterSpacing: "-0.374px" }}>Task not found</p>
            <button
              onClick={() => router.push("/")}
              style={{
                backgroundColor: "#1d1d1f",
                color: "#ffffff",
                fontSize: 14,
                fontWeight: 400,
                padding: "8px 15px",
                borderRadius: 8,
                border: "none",
                cursor: "pointer",
                letterSpacing: "-0.224px",
              }}
            >
              Back to dashboard
            </button>
          </div>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell
      navCenter={
        <>
          {/* Breadcrumb - task ID since nav already shows Dashboard */}
          <nav className="flex items-center gap-1.5 shrink-0" style={{ fontSize: 12, letterSpacing: "-0.12px" }}>
            <ChevronRight className="h-3 w-3" style={{ color: "rgba(255,255,255,0.48)" }} />
            <span className="font-mono" style={{ color: "#ffffff", fontWeight: 400 }}>
              {taskId.slice(0, 8)}
            </span>
          </nav>
          <div style={{ width: 1, height: 20, backgroundColor: "rgba(255,255,255,0.12)" }} />
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <RotateCcw className="h-3.5 w-3.5 shrink-0" style={{ color: "rgba(255,255,255,0.48)" }} />
            <p className="truncate flex-1" style={{ color: "#ffffff", fontWeight: 600, fontSize: 14, letterSpacing: "-0.224px" }}>
              {task.instruction}
            </p>
          </div>
        </>
      }
      navRight={
        <>
          <ElapsedTime startedAt={task.created_at} completedAt={task.completed_at} />
          <StatusBadge status={task.status} />
          <span className="font-mono" style={{ backgroundColor: "#272729", color: "rgba(255,255,255,0.8)", fontSize: 12, padding: "4px 10px", borderRadius: 8, letterSpacing: "-0.12px" }}>
            Attempt {task.current_attempt}/{task.max_retries}
          </span>
          <span className="flex items-center gap-1 font-mono" style={{ color: "rgba(255,255,255,0.8)", fontSize: 12, letterSpacing: "-0.12px" }}>
            <DollarSign className="h-3 w-3" />${task.total_cost_usd.toFixed(4)}
          </span>
          {(task.status === "failed" || task.status === "abandoned") && (
            <button
              style={{
                backgroundColor: "#0071e3", color: "#ffffff", fontSize: 14, fontWeight: 400,
                padding: "6px 14px", borderRadius: 8, border: "none",
                cursor: retrying ? "not-allowed" : "pointer", opacity: retrying ? 0.5 : 1,
                display: "flex", alignItems: "center", gap: 6, letterSpacing: "-0.224px",
              }}
              disabled={retrying}
              onClick={() => void handleRetry()}
            >
              {retrying ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
              {retrying ? "Retrying..." : "Retry"}
            </button>
          )}
        </>
      }
    >
      {/* ── Main layout ────────────────────────────────────────────────── */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left panel -- Timeline (60%) */}
        <div
          className="flex flex-col flex-[3] min-w-0 overflow-hidden"
          style={{ backgroundColor: "#000000" }}
        >
          <div className="flex-1 overflow-y-auto panel-scroll">
            <div className="p-6 space-y-6">
              {/* Pre-mortem Predictions */}
              {predictionsWithMatches.length > 0 && (
                <div
                  style={{
                    borderRadius: 8,
                    border: "1px solid rgba(245, 158, 11, 0.2)",
                    backgroundColor: "rgba(245, 158, 11, 0.04)",
                    overflow: "hidden",
                  }}
                >
                  <div
                    className="flex items-center gap-2"
                    style={{
                      padding: "12px 16px",
                      borderBottom: "1px solid rgba(245, 158, 11, 0.12)",
                    }}
                  >
                    <ShieldAlert className="h-4 w-4" style={{ color: "#f59e0b" }} />
                    <span
                      style={{
                        color: "#f59e0b",
                        fontWeight: 600,
                        fontSize: 13,
                        letterSpacing: "-0.13px",
                      }}
                    >
                      Pre-mortem Analysis
                    </span>
                    <span
                      style={{
                        color: "rgba(245, 158, 11, 0.6)",
                        fontSize: 12,
                        letterSpacing: "-0.12px",
                      }}
                    >
                      {predictionsWithMatches.length} predicted risk{predictionsWithMatches.length !== 1 ? "s" : ""} based on failure memory
                    </span>
                  </div>
                  <div className="flex flex-col gap-0">
                    {predictionsWithMatches.map((pred, i) => (
                      <div
                        key={pred.error_type}
                        className="flex items-start gap-3"
                        style={{
                          padding: "12px 16px",
                          borderBottom:
                            i < predictionsWithMatches.length - 1
                              ? "1px solid rgba(245, 158, 11, 0.08)"
                              : "none",
                          backgroundColor: pred.matched
                            ? "rgba(239, 68, 68, 0.06)"
                            : "transparent",
                        }}
                      >
                        <div
                          className="flex items-center justify-center shrink-0"
                          style={{
                            width: 32,
                            height: 32,
                            borderRadius: 8,
                            backgroundColor: pred.matched
                              ? "rgba(239, 68, 68, 0.12)"
                              : "rgba(245, 158, 11, 0.1)",
                          }}
                        >
                          <AlertTriangle
                            className="h-4 w-4"
                            style={{
                              color: pred.matched ? "#ef4444" : "#f59e0b",
                            }}
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span
                              className="font-mono text-sm"
                              style={{ color: "#ffffff", fontWeight: 500 }}
                            >
                              {pred.error_type}
                            </span>
                            <span
                              className="font-mono text-xs tabular-nums"
                              style={{
                                color: pred.prediction_score > 0.6 ? "#f59e0b" : "rgba(255,255,255,0.48)",
                                fontWeight: 600,
                              }}
                            >
                              {Math.round(pred.prediction_score * 100)}%
                            </span>
                            {pred.matched && (
                              <span
                                style={{
                                  fontSize: 10,
                                  fontWeight: 600,
                                  letterSpacing: "0.05em",
                                  textTransform: "uppercase" as const,
                                  color: "#ef4444",
                                  backgroundColor: "rgba(239, 68, 68, 0.12)",
                                  padding: "2px 8px",
                                  borderRadius: 4,
                                }}
                              >
                                Predicted correctly
                              </span>
                            )}
                          </div>
                          <p
                            style={{
                              color: "rgba(255,255,255,0.6)",
                              fontSize: 12,
                              margin: "4px 0 0 0",
                              lineHeight: 1.5,
                              letterSpacing: "-0.12px",
                            }}
                          >
                            {pred.suggested_prevention}
                          </p>
                          <span
                            style={{
                              color: "rgba(255,255,255,0.32)",
                              fontSize: 11,
                            }}
                          >
                            Based on {pred.based_on_failures} past failure{pred.based_on_failures !== 1 ? "s" : ""}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Timeline header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <h2
                    className="flex items-center gap-2"
                    style={{
                      color: "#ffffff",
                      fontWeight: 600,
                      fontSize: 21,
                      lineHeight: 1.19,
                      letterSpacing: "0.231px",
                    }}
                  >
                    Execution Timeline
                  </h2>
                  <span style={{ color: "rgba(255,255,255,0.48)", fontSize: 14, letterSpacing: "-0.224px" }}>
                    {task.attempts.length} attempt{task.attempts.length !== 1 ? "s" : ""}
                  </span>
                </div>

                {/* Legend */}
                <div
                  className="flex items-center gap-4"
                  style={{
                    color: "rgba(255,255,255,0.48)",
                    fontSize: 12,
                    letterSpacing: "-0.12px",
                  }}
                >
                  <span className="flex items-center gap-1.5">
                    <span className="inline-block w-2 h-2 rounded-full" style={{ backgroundColor: "#ef4444" }} />
                    Failed
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="inline-block w-2 h-2 rounded-full" style={{ backgroundColor: "#d97706" }} />
                    Running
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="inline-block w-2 h-2 rounded-full" style={{ backgroundColor: "#27a644" }} />
                    Succeeded
                  </span>
                </div>
              </div>

              {/* Timeline nodes */}
              <Timeline
                attempts={task.attempts}
                activeAttemptNumber={
                  task.status === "running" ? task.current_attempt : undefined
                }
                maxRetries={task.max_retries}
              />

              {/* Result section */}
              {task.result && (
                <div
                  className="flex items-start gap-4 p-5"
                  style={{
                    backgroundColor: "#272729",
                    borderRadius: 8,
                  }}
                >
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center shrink-0"
                    style={{ backgroundColor: "rgba(39,166,68,0.12)" }}
                  >
                    <CheckCircle2 className="h-4 w-4" style={{ color: "#27a644" }} />
                  </div>
                  <div>
                    <p
                      className="mb-1"
                      style={{
                        color: "#ffffff",
                        fontWeight: 600,
                        fontSize: 14,
                        letterSpacing: "-0.224px",
                      }}
                    >
                      Task Result
                    </p>
                    <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 14, fontWeight: 400, lineHeight: 1.43, letterSpacing: "-0.224px" }}>
                      {task.result}
                    </p>
                  </div>
                </div>
              )}

              {/* Learning card -- shown when task has succeeded */}
              {task.status === "succeeded" && (
                <LearningCard taskId={taskId} />
              )}

              {/* Diff section */}
              {task.attempts.length >= 2 && (
                <div className="space-y-3">
                  <button
                    type="button"
                    className="w-full flex items-center gap-3 text-left transition-opacity hover:opacity-80"
                    onClick={() => setDiffOpen((v) => !v)}
                  >
                    <FileDiff className="h-4 w-4" style={{ color: "rgba(255,255,255,0.48)" }} />
                    <span style={{ color: "#ffffff", fontWeight: 600, fontSize: 14, letterSpacing: "-0.224px" }}>
                      Attempt Diff
                    </span>
                    <span style={{ color: "rgba(255,255,255,0.48)", fontSize: 12, letterSpacing: "-0.12px" }}>
                      Compare consecutive attempts
                    </span>
                    {diffOpen ? (
                      <ChevronUp className="h-4 w-4 ml-auto" style={{ color: "rgba(255,255,255,0.48)" }} />
                    ) : (
                      <ChevronDown className="h-4 w-4 ml-auto" style={{ color: "rgba(255,255,255,0.48)" }} />
                    )}
                  </button>

                  {diffOpen && (
                    <div className="space-y-3">
                      {task.attempts.length > 2 && (
                        <div className="flex items-center gap-2">
                          <span style={{ color: "rgba(255,255,255,0.48)", fontSize: 12, letterSpacing: "-0.12px" }}>Comparing:</span>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {task.attempts.slice(0, -1).map((_, idx) => (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => setDiffPairIndex(idx)}
                                className="font-mono transition-all"
                                style={{
                                  backgroundColor: diffPairIndex === idx ? "rgba(0,113,227,0.15)" : "#272729",
                                  color: diffPairIndex === idx ? "#2997ff" : "rgba(255,255,255,0.8)",
                                  fontSize: 12,
                                  fontWeight: 400,
                                  padding: "4px 10px",
                                  borderRadius: 8,
                                  border: "none",
                                  cursor: "pointer",
                                  letterSpacing: "-0.12px",
                                }}
                              >
                                {idx + 1} vs {idx + 2}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      <DiffViewer
                        leftAttempt={task.attempts[diffPairIndex]}
                        rightAttempt={task.attempts[diffPairIndex + 1]}
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Bottom bar */}
          <div
            className="p-4 space-y-3"
            style={{ backgroundColor: "#1d1d1f" }}
          >
            <CostTracker
              attempts={task.attempts}
              totalCost={task.total_cost_usd}
              maxBudget={task.max_budget_usd}
            />

            <LiveOutput lines={outputLines} title={`reloop :: ${task.id}`} />

            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-1.5" style={{ color: "rgba(255,255,255,0.48)", fontSize: 12, letterSpacing: "-0.12px" }}>
                <Zap className="h-3 w-3" />
                <span>
                  {task.attempts.length} attempts · {checkpoints.length} checkpoint{checkpoints.length !== 1 ? "s" : ""}
                </span>
              </div>

              <button
                style={{
                  backgroundColor: "#272729",
                  color: checkpoints.length === 0 || rewinding ? "rgba(255,255,255,0.24)" : "#ffffff",
                  fontSize: 14,
                  fontWeight: 400,
                  padding: "6px 14px",
                  borderRadius: 8,
                  border: "none",
                  cursor: checkpoints.length === 0 || rewinding ? "not-allowed" : "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  letterSpacing: "-0.224px",
                }}
                disabled={checkpoints.length === 0 || rewinding}
                onClick={() => void handleRewind()}
              >
                {rewinding ? (
                  <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Rewind className="h-3.5 w-3.5" />
                )}
                {rewinding ? "Rewinding..." : "Rewind"}
              </button>
            </div>
          </div>
        </div>

        {/* Right panel -- Failure Memory sidebar */}
        <div className="flex-[1.5] min-w-0 overflow-hidden" style={{ backgroundColor: "#1d1d1f" }}>
          <FailureSidebar failures={failures} recalledIds={recalledIds} className="h-full" />
        </div>
      </div>
    </AppShell>
  );
}
