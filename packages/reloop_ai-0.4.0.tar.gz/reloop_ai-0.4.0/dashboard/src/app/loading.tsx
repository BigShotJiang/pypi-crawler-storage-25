export default function Loading() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-4">
      {/* Animated logo mark */}
      <div className="relative">
        <div className="w-10 h-10 rounded-xl border border-white/10 bg-white/[0.03] flex items-center justify-center">
          <div className="w-3 h-3 rounded-full bg-primary animate-pulse" />
        </div>
        <div className="absolute inset-0 rounded-xl animate-ring-expand border border-primary/30" />
        <div className="absolute inset-0 rounded-xl animate-ring-expand-delay border border-primary/20" />
      </div>

      {/* Loading text */}
      <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
        <span>Loading</span>
        <span className="animate-blink">_</span>
      </div>

      {/* Progress bar */}
      <div className="w-32 h-0.5 bg-white/5 rounded-full overflow-hidden">
        <div className="h-full w-1/4 bg-primary/60 rounded-full animate-progress" />
      </div>
    </div>
  );
}
