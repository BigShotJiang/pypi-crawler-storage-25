import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// ─── Formatting Utilities ──────────────────────────────────────────

/**
 * Format a number as USD currency.
 * formatCurrency(1234.5) => "$1,234.50"
 * formatCurrency(0.005) => "$0.01"
 */
export function formatCurrency(
  amount: number,
  options?: { compact?: boolean }
): string {
  if (options?.compact && Math.abs(amount) >= 1000) {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      notation: "compact",
      maximumFractionDigits: 1,
    }).format(amount);
  }
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 4,
  }).format(amount);
}

/**
 * Format a duration in milliseconds to a human-readable string.
 * formatDuration(65000)  => "1m 5s"
 * formatDuration(3500)   => "3.5s"
 * formatDuration(150)    => "150ms"
 */
export function formatDuration(ms: number): string {
  if (ms < 0) return "0ms";
  if (ms < 1000) return `${Math.round(ms)}ms`;
  if (ms < 60_000) {
    const seconds = ms / 1000;
    return seconds % 1 === 0 ? `${seconds}s` : `${seconds.toFixed(1)}s`;
  }
  if (ms < 3_600_000) {
    const minutes = Math.floor(ms / 60_000);
    const seconds = Math.round((ms % 60_000) / 1000);
    return seconds > 0 ? `${minutes}m ${seconds}s` : `${minutes}m`;
  }
  const hours = Math.floor(ms / 3_600_000);
  const minutes = Math.round((ms % 3_600_000) / 60_000);
  return minutes > 0 ? `${hours}h ${minutes}m` : `${hours}h`;
}

/**
 * Format a date/timestamp as relative time from now.
 * formatRelativeTime(Date.now() - 30000) => "30s ago"
 * formatRelativeTime(Date.now() - 7200000) => "2h ago"
 */
export function formatRelativeTime(
  timestamp: number | Date
): string {
  const now = Date.now();
  const time = typeof timestamp === "number" ? timestamp : timestamp.getTime();
  const diffMs = now - time;

  if (diffMs < 0) return "just now";
  if (diffMs < 5_000) return "just now";
  if (diffMs < 60_000) return `${Math.floor(diffMs / 1000)}s ago`;
  if (diffMs < 3_600_000) return `${Math.floor(diffMs / 60_000)}m ago`;
  if (diffMs < 86_400_000) return `${Math.floor(diffMs / 3_600_000)}h ago`;
  if (diffMs < 604_800_000) return `${Math.floor(diffMs / 86_400_000)}d ago`;
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
  }).format(new Date(time));
}

// ─── Status Color Utilities ────────────────────────────────────────

export type AgentStatus =
  | "succeeded"
  | "failed"
  | "running"
  | "pending"
  | "healing"
  | "idle";

/**
 * Map a status string to its Tailwind color classes.
 * Returns an object with bg, text, border, and dot colors.
 */
export function getStatusColors(status: AgentStatus) {
  const map: Record<
    AgentStatus,
    { bg: string; text: string; border: string; dot: string; glow: string }
  > = {
    succeeded: {
      bg: "bg-green-500/10",
      text: "text-green-400",
      border: "border-green-500/20",
      dot: "bg-green-500",
      glow: "animate-glow-green",
    },
    failed: {
      bg: "bg-red-500/10",
      text: "text-red-400",
      border: "border-red-500/20",
      dot: "bg-red-500",
      glow: "animate-glow-red",
    },
    running: {
      bg: "bg-yellow-500/10",
      text: "text-yellow-400",
      border: "border-yellow-500/20",
      dot: "bg-yellow-500",
      glow: "animate-glow-yellow",
    },
    pending: {
      bg: "bg-zinc-500/10",
      text: "text-zinc-400",
      border: "border-zinc-500/20",
      dot: "bg-zinc-500",
      glow: "",
    },
    healing: {
      bg: "bg-blue-500/10",
      text: "text-blue-400",
      border: "border-blue-500/20",
      dot: "bg-blue-500",
      glow: "animate-glow-blue",
    },
    idle: {
      bg: "bg-zinc-500/10",
      text: "text-zinc-500",
      border: "border-zinc-500/20",
      dot: "bg-zinc-600",
      glow: "",
    },
  };
  return map[status] ?? map.idle;
}

/**
 * Return a single Tailwind text color class for a status.
 */
export function getStatusTextColor(status: string): string {
  switch (status) {
    case "succeeded":
      return "text-green-400";
    case "failed":
      return "text-red-400";
    case "running":
      return "text-yellow-400";
    case "healing":
      return "text-blue-400";
    case "pending":
      return "text-zinc-400";
    default:
      return "text-zinc-500";
  }
}

// ─── Animation Utilities ───────────────────────────────────────────

/**
 * Calculate a staggered animation delay for list items.
 * Returns a CSS style object for use in inline styles.
 *
 * Usage:
 *   <div className="animate-fade-in-up" style={staggerDelay(index)}>
 */
export function staggerDelay(
  index: number,
  baseMs: number = 60
): { animationDelay: string; animationFillMode: string } {
  return {
    animationDelay: `${index * baseMs}ms`,
    animationFillMode: "both",
  };
}

/**
 * Calculate a capped animation delay (useful for large lists).
 * Delay increases per item but caps at maxMs.
 */
export function cappedStaggerDelay(
  index: number,
  baseMs: number = 60,
  maxMs: number = 600
): { animationDelay: string; animationFillMode: string } {
  const delay = Math.min(index * baseMs, maxMs);
  return {
    animationDelay: `${delay}ms`,
    animationFillMode: "both",
  };
}
