export const COLORS = {
  bg: {
    base: "#000000",
    elevated: "#1d1d1f",
    surface: "#272729",
    surfaceHover: "#2a2a2d",
    surfaceAlt: "#242426",
  },
  text: {
    primary: "#ffffff",
    secondary: "rgba(255,255,255,0.8)",
    muted: "rgba(255,255,255,0.48)",
  },
  accent: {
    blue: "#0071e3",
    blueHover: "#0077ed",
    blueDisabled: "rgba(0,113,227,0.4)",
    link: "#2997ff",
  },
  status: {
    success: "#27a644",
    error: "#ef4444",
    warning: "#d97706",
    pending: "rgba(255,255,255,0.24)",
  },
  nav: {
    bg: "rgba(0,0,0,0.8)",
    blur: "saturate(180%) blur(20px)",
  },
  border: "rgba(255,255,255,0.08)",
  divider: "rgba(255,255,255,0.12)",
} as const;

export const FONT =
  "-apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', 'Helvetica Neue', Helvetica, Arial, sans-serif";

export const MONO = "'SF Mono', ui-monospace, Menlo, monospace";
