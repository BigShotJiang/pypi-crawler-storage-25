@AGENTS.md

## Git Workflow -- Pull Request Required

**All changes to the dashboard MUST go through a pull request before merging to main.**

1. **Create a feature branch** from `main`: `git checkout -b <type>/<short-description>`
2. **Commit changes** to the feature branch with conventional commit messages
3. **Push the feature branch** to remote: `git push -u origin <branch-name>`
4. **Open a pull request** against `main` using `gh pr create`
5. **Auto-review the PR** -- read the diff, check for correctness, type safety, CLAUDE.md compliance, and breaking changes
6. **If issues found** -- fix automatically, commit fixes, push, and re-review
7. **Repeat until clean** -- loop steps 5-6 until no issues remain
8. **Approve** -- `gh pr review --approve -b "Automated review passed: <summary>"`
9. **Merge** -- `gh pr merge --squash --delete-branch`

### Rules

- Never commit or push directly to `main`
- Never merge without completing the automated review cycle
- Never force push to any branch
- One logical change per PR -- keep PRs small and reviewable
- PR title follows conventional commits format (e.g., `feat(dashboard): add timeline hover states`)
- PR body must include a Summary and Test Plan section
- Fix review issues in new commits (do not force-push over review history)
