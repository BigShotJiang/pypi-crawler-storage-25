"""OpenTelemetry tracing integration for ReLoop.

Provides optional tracing for the REJD loop phases. When OpenTelemetry
is not installed, all functions return no-op objects so instrumented code
runs without changes.

Usage:
    from src.telemetry import configure_tracing, get_tracer

    configure_tracing(service_name="reloop")
    tracer = get_tracer()

    with tracer.start_as_current_span("reloop.retrieve"):
        ...
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Any, Iterator

logger = logging.getLogger(__name__)

_tracer: Any = None
_configured: bool = False


def _otel_available() -> bool:
    """Check if OpenTelemetry SDK is installed."""
    try:
        import opentelemetry.trace  # noqa: F401
        import opentelemetry.sdk.trace  # noqa: F401
        return True
    except ImportError:
        return False


class _NoOpSpan:
    """Minimal no-op span when OpenTelemetry is not available."""

    def set_attribute(self, key: str, value: Any) -> None:
        pass

    def set_status(self, status: Any, description: str | None = None) -> None:
        pass

    def record_exception(self, exception: BaseException) -> None:
        pass

    def end(self) -> None:
        pass

    def __enter__(self) -> "_NoOpSpan":
        return self

    def __exit__(self, *args: Any) -> None:
        pass


class _NoOpTracer:
    """Minimal no-op tracer when OpenTelemetry is not available."""

    def start_as_current_span(self, name: str, **kwargs: Any) -> _NoOpSpan:
        return _NoOpSpan()

    def start_span(self, name: str, **kwargs: Any) -> _NoOpSpan:
        return _NoOpSpan()


def configure_tracing(
    service_name: str = "reloop",
    exporter: Any = None,
) -> bool:
    """Set up OpenTelemetry tracing.

    Args:
        service_name: The service name for traces.
        exporter: Optional SpanExporter instance. If None, uses a
                  ConsoleSpanExporter for development.

    Returns:
        True if tracing was configured, False if OTel is not installed.
    """
    global _tracer, _configured

    if not _otel_available():
        logger.info("OpenTelemetry not installed; tracing disabled")
        _tracer = _NoOpTracer()
        _configured = False
        return False

    try:
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import (
            BatchSpanProcessor,
            ConsoleSpanExporter,
            SimpleSpanProcessor,
        )
        from opentelemetry.sdk.resources import Resource

        resource = Resource.create({"service.name": service_name})
        provider = TracerProvider(resource=resource)

        if exporter is None:
            # Default to console exporter for dev
            processor = SimpleSpanProcessor(ConsoleSpanExporter())
        else:
            processor = BatchSpanProcessor(exporter)

        provider.add_span_processor(processor)
        trace.set_tracer_provider(provider)

        _tracer = trace.get_tracer("reloop", "0.3.2")
        _configured = True
        logger.info("OpenTelemetry tracing configured for service=%s", service_name)
        return True
    except Exception:
        logger.warning("Failed to configure OpenTelemetry tracing", exc_info=True)
        _tracer = _NoOpTracer()
        _configured = False
        return False


def get_tracer() -> Any:
    """Return the configured tracer, or a no-op tracer if OTel is not available.

    Safe to call before configure_tracing() -- returns a no-op tracer.
    """
    global _tracer
    if _tracer is not None:
        return _tracer

    if _otel_available():
        try:
            from opentelemetry import trace
            _tracer = trace.get_tracer("reloop", "0.3.2")
            return _tracer
        except Exception:
            pass

    _tracer = _NoOpTracer()
    return _tracer


def is_configured() -> bool:
    """Return True if OpenTelemetry tracing has been configured."""
    return _configured


def reset() -> None:
    """Reset the tracer state. Primarily for testing."""
    global _tracer, _configured
    _tracer = None
    _configured = False
