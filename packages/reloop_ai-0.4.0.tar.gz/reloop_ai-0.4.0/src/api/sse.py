"""Server-Sent Events utilities for real-time timeline streaming."""

from __future__ import annotations

import logging
from typing import AsyncIterator, Any

from src.models import TimelineEvent
from src.core.timeline import TimelineManager

logger = logging.getLogger(__name__)


def format_sse_event(event: TimelineEvent) -> dict[str, Any]:
    """Format a TimelineEvent as an SSE-compatible dict.

    Returns a dict with ``data`` and ``id`` keys ready for EventSourceResponse.
    """
    # Do NOT set "event" key — browser EventSource.onmessage only fires
    # for events with no named event type (or type "message"). Named events
    # require explicit addEventListener() which our frontend doesn't use.
    return {
        "data": event.model_dump_json(),
        "id": event.id,
    }


async def create_event_stream(
    timeline: TimelineManager,
    task_id: str,
) -> AsyncIterator[dict[str, Any]]:
    """Async generator that yields SSE-formatted dicts for a given task.

    Uses the TimelineManager's async-generator-based subscribe() method
    which replays existing events then streams new ones in real-time.
    """
    try:
        async for event in timeline.subscribe(task_id):
            yield format_sse_event(event)
    except GeneratorExit:
        logger.debug("SSE stream closed for task %s", task_id)
