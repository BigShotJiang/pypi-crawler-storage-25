"""Memory routes — search, list failures, get failure, stats, predict, export/import."""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Query, Request, Response

from src.models import (
    ErrorCategory,
    FailureRecord,
    MemorySearchRequest,
    MemorySearchResponse,
    MemoryStatsResponse,
    PlaybookExport,
    PlaybookImport,
    PredictionRequest,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/memories", tags=["memories"])


def _get_memory(request: Request):
    """Get memory backend, raise 503 if unavailable."""
    memory = request.app.state.memory
    if memory is None:
        raise HTTPException(
            status_code=503,
            detail="Memory backend is not configured. Set REDIS_URL or install aiosqlite.",
        )
    return memory


# ---------------------------------------------------------------------------
# POST /v1/memories/search — semantic search over failure memory
# ---------------------------------------------------------------------------

@router.post("/search", response_model=MemorySearchResponse)
async def search_memories(
    body: MemorySearchRequest,
    request: Request,
) -> MemorySearchResponse:
    """Semantic search over stored failure records.

    When cross_project=True, searches ALL failures across every task/project
    and returns only transferable failures. This enables knowledge transfer
    from Project A to Project B.
    """
    memory = _get_memory(request)

    # Cross-project search via FailureMemoryManager
    if body.cross_project:
        memory_manager = getattr(request.app.state, "memory_manager", None)
        if memory_manager is None:
            raise HTTPException(
                status_code=503,
                detail="Memory manager is not configured. "
                "Cross-project search requires the full memory manager.",
            )
        try:
            results: list[FailureRecord] = await memory_manager.search_cross_project(
                query=body.query,
                exclude_task_id=body.exclude_task_id,
                limit=body.limit,
            )
        except Exception as exc:
            logger.exception("Cross-project memory search failed: %s", exc)
            raise HTTPException(
                status_code=500, detail="Cross-project memory search failed"
            ) from exc

        return MemorySearchResponse(failures=results, total_count=len(results))

    # Standard search
    filters: dict = {}
    if body.error_type is not None:
        filters["error_type"] = body.error_type
    if body.error_category is not None:
        filters["error_category"] = body.error_category.value

    try:
        results = await memory.search(
            query=body.query,
            limit=body.limit,
            filters=filters if filters else None,
        )
    except Exception as exc:
        logger.exception("Memory search failed: %s", exc)
        raise HTTPException(status_code=500, detail="Memory search failed") from exc

    return MemorySearchResponse(failures=results, total_count=len(results))


# ---------------------------------------------------------------------------
# GET /v1/memories/failures — list recent failures
# ---------------------------------------------------------------------------

@router.get("/failures", response_model=list[FailureRecord])
async def list_failures(
    request: Request,
    limit: int = Query(default=20, ge=1, le=200),
    error_category: Optional[ErrorCategory] = Query(default=None),
    task_id: Optional[str] = Query(default=None),
) -> list[FailureRecord]:
    """List recent failure records, optionally filtered."""
    memory = _get_memory(request)

    try:
        if task_id is not None:
            records: list[FailureRecord] = await memory.get_failures_for_task(task_id)
        else:
            records = await memory.search(query="", limit=limit)

        if error_category is not None:
            records = [
                r for r in records
                if r.signature.error_category == error_category
            ]

        return records[:limit]

    except Exception as exc:
        logger.exception("Failed to list failures: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to retrieve failures") from exc


# ---------------------------------------------------------------------------
# GET /v1/memories/transferred — list transferable failures
# ---------------------------------------------------------------------------

@router.get("/transferred", response_model=list[FailureRecord])
async def list_transferred(
    request: Request,
    limit: int = Query(default=20, ge=1, le=200),
) -> list[FailureRecord]:
    """List failure records marked as transferable across projects.

    These are generic lessons (dependency errors, config issues, port conflicts,
    env vars) that can help any project succeed faster.
    """
    memory = _get_memory(request)

    try:
        records: list[FailureRecord] = await memory.search(query="", limit=limit * 2)
        transferred = [r for r in records if r.transferable]
        return transferred[:limit]

    except Exception as exc:
        logger.exception("Failed to list transferred failures: %s", exc)
        raise HTTPException(
            status_code=500, detail="Failed to retrieve transferred failures"
        ) from exc


# ---------------------------------------------------------------------------
# GET /v1/memories/failures/{failure_id} — get a specific failure
# ---------------------------------------------------------------------------

@router.get("/failures/{failure_id}", response_model=FailureRecord)
async def get_failure(failure_id: str, request: Request) -> FailureRecord:
    """Return a single failure record by ID."""
    memory = _get_memory(request)

    try:
        record = await memory.get_failure(failure_id)
    except Exception as exc:
        logger.exception("Failed to fetch failure %s: %s", failure_id, exc)
        raise HTTPException(status_code=500, detail="Failed to retrieve failure") from exc

    if record is None:
        raise HTTPException(
            status_code=404,
            detail=f"Failure record '{failure_id}' not found",
        )
    return record


# ---------------------------------------------------------------------------
# GET /v1/memories/stats — aggregate memory statistics
# ---------------------------------------------------------------------------

@router.get("/stats", response_model=MemoryStatsResponse)
async def memory_stats(request: Request) -> MemoryStatsResponse:
    """Return aggregate statistics about the failure memory store."""
    memory = _get_memory(request)

    try:
        return await memory.get_stats()
    except Exception as exc:
        logger.exception("Failed to retrieve memory stats: %s", exc)
        raise HTTPException(
            status_code=500, detail="Failed to retrieve memory statistics"
        ) from exc


# ---------------------------------------------------------------------------
# POST /v1/memories/predict — proactive failure prediction
# ---------------------------------------------------------------------------

@router.post("/predict")
async def predict_failures(
    body: PredictionRequest,
    request: Request,
) -> list[dict[str, Any]]:
    """Predict likely failures before execution based on past failure patterns.

    Returns a ranked list of predicted failures with scores and prevention advice.
    """
    memory_manager = getattr(request.app.state, "memory_manager", None)
    if memory_manager is None:
        raise HTTPException(
            status_code=503,
            detail="Memory manager is not configured. Cannot generate predictions.",
        )

    try:
        predictions = await memory_manager.predict_likely_failures(
            instruction=body.instruction,
            context=body.context,
            limit=body.limit,
        )
        return predictions
    except Exception as exc:
        logger.exception("Prediction failed: %s", exc)
        raise HTTPException(status_code=500, detail="Prediction failed") from exc


# ---------------------------------------------------------------------------
# GET /v1/memories/export — export failure playbook
# ---------------------------------------------------------------------------

@router.get("/export")
async def export_playbook(
    request: Request,
    domain: Optional[str] = Query(default=None),
    format: str = Query(default="json"),
) -> Response:
    """Export all failure records as a portable playbook."""
    memory = _get_memory(request)

    try:
        records: list[FailureRecord] = await memory.search(query="", limit=1000)
    except Exception as exc:
        logger.exception("Failed to fetch failures for export: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to fetch failures") from exc

    if domain:
        domain_lower = domain.lower()
        records = [
            r for r in records
            if any(domain_lower in t.lower() for t in r.topics)
        ]

    categories: dict[str, int] = {}
    for record in records:
        cat = record.signature.error_category.value
        categories[cat] = categories.get(cat, 0) + 1

    playbook = PlaybookExport(
        domain=domain or "",
        failures=records,
        stats={"total": len(records), "categories": categories},
    )

    payload = playbook.model_dump(mode="json")
    json_bytes = json.dumps(payload, default=str, indent=2).encode()

    return Response(
        content=json_bytes,
        media_type="application/json",
        headers={
            "Content-Disposition": 'attachment; filename="reloop-playbook.json"'
        },
    )


# ---------------------------------------------------------------------------
# POST /v1/memories/import — import failure playbook
# ---------------------------------------------------------------------------

@router.post("/import")
async def import_playbook(body: PlaybookImport, request: Request) -> dict:
    """Import a failure playbook, storing each record in the memory backend."""
    memory = _get_memory(request)

    imported = 0
    errors = 0
    for record in body.failures:
        if body.domain and body.domain not in record.topics:
            record.topics = [body.domain, *record.topics]
        try:
            await memory.store_failure(record)
            imported += 1
        except Exception as exc:
            logger.warning("Failed to import failure record %s: %s", record.id, exc)
            errors += 1

    return {
        "imported": imported,
        "errors": errors,
        "total": len(body.failures),
    }
