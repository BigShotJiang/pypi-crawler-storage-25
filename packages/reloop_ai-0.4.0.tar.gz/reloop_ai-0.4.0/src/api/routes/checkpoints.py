"""Checkpoint routes — list checkpoints and restore to a prior state."""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from src.models import (
    Checkpoint,
    Task,
    TimelineEventType,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/tasks", tags=["checkpoints"])


class RestoreResponse(BaseModel):
    message: str
    checkpoint_id: str
    task_id: str


# ---------------------------------------------------------------------------
# GET /v1/tasks/{task_id}/checkpoints — list checkpoints for a task
# ---------------------------------------------------------------------------

@router.get("/{task_id}/checkpoints", response_model=list[Checkpoint])
async def list_checkpoints(task_id: str, request: Request) -> list[Checkpoint]:
    """List all sandbox checkpoints for a task."""
    tasks: dict[str, Task] = request.app.state.tasks
    task = tasks.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"Task '{task_id}' not found")

    sandbox = request.app.state.sandbox
    if sandbox is None:
        raise HTTPException(
            status_code=503,
            detail="Sandbox provider is not available",
        )

    # Resolve sandbox_id — stored in task metadata by the agent
    sandbox_id: str | None = task.metadata.get("sandbox_id")
    if not sandbox_id:
        return []

    try:
        return await sandbox.list_checkpoints(sandbox_id)
    except Exception as exc:  # noqa: BLE001
        logger.exception(
            "Failed to list checkpoints for task %s (sandbox %s): %s",
            task_id,
            sandbox_id,
            exc,
        )
        raise HTTPException(
            status_code=500,
            detail="Failed to list checkpoints",
        ) from exc


# ---------------------------------------------------------------------------
# POST /v1/tasks/{task_id}/checkpoints/{checkpoint_id}/restore
# ---------------------------------------------------------------------------

@router.post(
    "/{task_id}/checkpoints/{checkpoint_id}/restore",
    response_model=RestoreResponse,
)
async def restore_checkpoint(
    task_id: str,
    checkpoint_id: str,
    request: Request,
) -> RestoreResponse:
    """Restore the sandbox for a task to a specific checkpoint."""
    tasks: dict[str, Task] = request.app.state.tasks
    task = tasks.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"Task '{task_id}' not found")

    sandbox = request.app.state.sandbox
    if sandbox is None:
        raise HTTPException(
            status_code=503,
            detail="Sandbox provider is not available",
        )

    sandbox_id: str | None = task.metadata.get("sandbox_id")
    if not sandbox_id:
        raise HTTPException(
            status_code=400,
            detail="Task has no associated sandbox; cannot restore checkpoint",
        )

    try:
        await sandbox.restore(sandbox_id, checkpoint_id)
    except Exception as exc:  # noqa: BLE001
        logger.exception(
            "Checkpoint restore failed for task %s checkpoint %s: %s",
            task_id,
            checkpoint_id,
            exc,
        )
        raise HTTPException(
            status_code=500,
            detail=f"Failed to restore checkpoint '{checkpoint_id}'",
        ) from exc

    # Emit a timeline event so the frontend can show the rewind
    timeline = request.app.state.timeline
    timeline.emit(
        task_id=task_id,
        event_type=TimelineEventType.CHECKPOINT_RESTORED,
        data={"checkpoint_id": checkpoint_id, "sandbox_id": sandbox_id},
        message=f"Restored to checkpoint {checkpoint_id}",
    )

    return RestoreResponse(
        message=f"Successfully restored to checkpoint '{checkpoint_id}'",
        checkpoint_id=checkpoint_id,
        task_id=task_id,
    )
