"""Context Surfaces routes — manage surfaces, agent keys, tools, and queries."""

from __future__ import annotations

import logging
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field

from src.providers.memory.context_surfaces_client import CONTEXT_SURFACES_AVAILABLE

logger = logging.getLogger(__name__)

_UNAVAILABLE_DETAIL = (
    "Context Surfaces feature unavailable: requires context-surfaces package "
    "(Python 3.11-3.13)"
)


def require_context_surfaces() -> None:
    """Router-level dependency: reject all requests when package is missing."""
    if not CONTEXT_SURFACES_AVAILABLE:
        raise HTTPException(status_code=503, detail=_UNAVAILABLE_DETAIL)


router = APIRouter(
    prefix="/v1/surfaces",
    tags=["surfaces"],
    dependencies=[Depends(require_context_surfaces)],
)


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------

class CreateSurfaceRequest(BaseModel):
    name: str = Field(default="reloop-failure-memory", description="Surface name")
    description: Optional[str] = Field(
        default=None,
        description="Human-readable description of the surface",
    )


class SurfaceResponse(BaseModel):
    surface_id: str
    name: str
    description: str = ""


class CreateAgentKeyRequest(BaseModel):
    name: str = Field(default="reloop-agent", description="Agent key name")
    description: Optional[str] = Field(
        default=None,
        description="Description of the agent key",
    )


class AgentKeyResponse(BaseModel):
    agent_key: str
    name: str


class ImportResponse(BaseModel):
    failures: int
    successes: int


class ToolQueryRequest(BaseModel):
    tool_name: str = Field(description="Name of the MCP tool to invoke")
    arguments: dict[str, Any] = Field(
        default_factory=dict,
        description="Arguments to pass to the tool",
    )
    agent_key: Optional[str] = Field(
        default=None,
        description="Agent key to use. Uses cached key if omitted.",
    )


class SetupRequest(BaseModel):
    name: str = Field(default="reloop-failure-memory", description="Surface name")
    agent_key_name: str = Field(default="reloop-agent", description="Agent key name")
    import_existing: bool = Field(
        default=True,
        description="Whether to import existing failure/success records from Redis",
    )


class SetupResponse(BaseModel):
    surface_id: str
    agent_key: str
    import_counts: ImportResponse | None = None


# ---------------------------------------------------------------------------
# Dependency helper
# ---------------------------------------------------------------------------

def _get_surfaces_manager(request: Request):
    """Get the ContextSurfacesManager from app state, raise 503 if unavailable."""
    manager = getattr(request.app.state, "surfaces_manager", None)
    if manager is None:
        raise HTTPException(
            status_code=503,
            detail=(
                "Context Surfaces manager is not configured. "
                "Set CONTEXT_SURFACES_ADMIN_KEY to enable."
            ),
        )
    return manager


# ---------------------------------------------------------------------------
# POST /v1/surfaces/setup — one-shot surface + agent key + import
# ---------------------------------------------------------------------------

@router.post("/setup", status_code=201, response_model=SetupResponse)
async def setup_surface(
    body: SetupRequest,
    request: Request,
) -> SetupResponse:
    """Create surface, generate an agent key, and optionally import existing data.

    This is a convenience endpoint that combines create-surface, create-agent-key,
    and import into a single call. The agent key is returned in full exactly once.
    """
    manager = _get_surfaces_manager(request)

    try:
        surface_id = await manager.ensure_surface(name=body.name)
    except Exception as exc:
        logger.exception("Setup: failed to create surface: %s", exc)
        raise HTTPException(
            status_code=500, detail="Failed to create context surface"
        ) from exc

    try:
        agent_key = await manager.create_agent_key(name=body.agent_key_name)
    except Exception as exc:
        logger.exception("Setup: failed to create agent key: %s", exc)
        raise HTTPException(
            status_code=500, detail="Failed to create agent key"
        ) from exc

    import_counts = None
    if body.import_existing:
        memory = getattr(request.app.state, "memory", None)
        if memory is not None:
            try:
                counts = await manager.import_existing_records(memory)
                import_counts = ImportResponse(
                    failures=counts["failures"],
                    successes=counts["successes"],
                )
            except Exception as exc:
                logger.warning("Setup: import failed (non-fatal): %s", exc)

    return SetupResponse(
        surface_id=surface_id,
        agent_key=agent_key,
        import_counts=import_counts,
    )


# ---------------------------------------------------------------------------
# POST /v1/surfaces — create a new context surface
# ---------------------------------------------------------------------------

@router.post("", status_code=201, response_model=SurfaceResponse)
async def create_surface(
    body: CreateSurfaceRequest,
    request: Request,
) -> SurfaceResponse:
    """Create a new context surface backed by ReLoop's Redis data."""
    manager = _get_surfaces_manager(request)

    try:
        surface_id = await manager.ensure_surface(name=body.name)
    except Exception as exc:
        logger.exception("Failed to create context surface: %s", exc)
        raise HTTPException(
            status_code=500, detail="Failed to create context surface"
        ) from exc

    return SurfaceResponse(
        surface_id=surface_id,
        name=body.name,
        description=body.description or "",
    )


# ---------------------------------------------------------------------------
# GET /v1/surfaces — list surfaces
# ---------------------------------------------------------------------------

@router.get("", response_model=list[SurfaceResponse])
async def list_surfaces(request: Request) -> list[SurfaceResponse]:
    """List all context surfaces (currently only the singleton surface)."""
    manager = _get_surfaces_manager(request)

    surface_id = manager._surface_id
    if surface_id is None:
        return []

    return [
        SurfaceResponse(
            surface_id=surface_id,
            name="reloop-failure-memory",
            description="ReLoop structured failure and success records",
        )
    ]


# ---------------------------------------------------------------------------
# GET /v1/surfaces/{surface_id} — get surface details
# ---------------------------------------------------------------------------

@router.get("/{surface_id}", response_model=SurfaceResponse)
async def get_surface(surface_id: str, request: Request) -> SurfaceResponse:
    """Get details for a specific context surface."""
    manager = _get_surfaces_manager(request)

    if manager._surface_id != surface_id:
        raise HTTPException(
            status_code=404,
            detail=f"Surface '{surface_id}' not found",
        )

    return SurfaceResponse(
        surface_id=surface_id,
        name="reloop-failure-memory",
        description="ReLoop structured failure and success records",
    )


# ---------------------------------------------------------------------------
# DELETE /v1/surfaces/{surface_id} — delete a surface
# ---------------------------------------------------------------------------

@router.delete("/{surface_id}", status_code=204, response_class=Response)
async def delete_surface(surface_id: str, request: Request) -> Response:
    """Delete a context surface."""
    manager = _get_surfaces_manager(request)

    if manager._surface_id != surface_id:
        raise HTTPException(
            status_code=404,
            detail=f"Surface '{surface_id}' not found",
        )

    try:
        client = manager._get_client()
        await client.delete_context_surface(surface_id)
        manager._surface_id = None
        manager._agent_keys.clear()
    except Exception as exc:
        logger.exception("Failed to delete surface %s: %s", surface_id, exc)
        raise HTTPException(
            status_code=500, detail="Failed to delete context surface"
        ) from exc

    return Response(status_code=204)


# ---------------------------------------------------------------------------
# POST /v1/surfaces/{surface_id}/agents — create an agent key
# ---------------------------------------------------------------------------

@router.post(
    "/{surface_id}/agents",
    status_code=201,
    response_model=AgentKeyResponse,
)
async def create_agent_key(
    surface_id: str,
    body: CreateAgentKeyRequest,
    request: Request,
) -> AgentKeyResponse:
    """Create an agent key for the specified context surface."""
    manager = _get_surfaces_manager(request)

    if manager._surface_id != surface_id:
        raise HTTPException(
            status_code=404,
            detail=f"Surface '{surface_id}' not found",
        )

    try:
        key = await manager.create_agent_key(
            name=body.name,
            description=body.description or f"Agent key: {body.name}",
        )
    except Exception as exc:
        logger.exception("Failed to create agent key: %s", exc)
        raise HTTPException(
            status_code=500, detail="Failed to create agent key"
        ) from exc

    return AgentKeyResponse(agent_key=key, name=body.name)


# ---------------------------------------------------------------------------
# GET /v1/surfaces/{surface_id}/agents — list agent keys
# ---------------------------------------------------------------------------

@router.get("/{surface_id}/agents", response_model=list[AgentKeyResponse])
async def list_agent_keys(
    surface_id: str,
    request: Request,
) -> list[AgentKeyResponse]:
    """List agent keys for the specified context surface."""
    manager = _get_surfaces_manager(request)

    if manager._surface_id != surface_id:
        raise HTTPException(
            status_code=404,
            detail=f"Surface '{surface_id}' not found",
        )

    # Return all tracked agent keys with masked secrets.
    # Only the create endpoint exposes the full key (one-time).
    results: list[AgentKeyResponse] = []
    for entry in manager._agent_keys:
        raw = entry["key"]
        masked = "****" + raw[-4:] if len(raw) > 4 else "****"
        results.append(AgentKeyResponse(agent_key=masked, name=entry["name"]))
    return results


# ---------------------------------------------------------------------------
# POST /v1/surfaces/{surface_id}/import — import existing failure records
# ---------------------------------------------------------------------------

@router.post("/{surface_id}/import", response_model=ImportResponse)
async def import_records(
    surface_id: str,
    request: Request,
) -> ImportResponse:
    """Import existing failure/success records from Redis into the context surface."""
    manager = _get_surfaces_manager(request)

    if manager._surface_id != surface_id:
        raise HTTPException(
            status_code=404,
            detail=f"Surface '{surface_id}' not found",
        )

    memory = getattr(request.app.state, "memory", None)
    if memory is None:
        raise HTTPException(
            status_code=503,
            detail="Memory backend is not configured. Cannot import records.",
        )

    try:
        counts = await manager.import_existing_records(memory)
    except Exception as exc:
        logger.exception("Failed to import records into surface %s: %s", surface_id, exc)
        raise HTTPException(
            status_code=500, detail="Failed to import records"
        ) from exc

    return ImportResponse(failures=counts["failures"], successes=counts["successes"])


# ---------------------------------------------------------------------------
# GET /v1/surfaces/{surface_id}/tools — list auto-generated MCP tools
# ---------------------------------------------------------------------------

@router.get("/{surface_id}/tools")
async def list_tools(
    surface_id: str,
    request: Request,
) -> list[dict[str, Any]]:
    """List auto-generated MCP tools for the context surface."""
    manager = _get_surfaces_manager(request)

    if manager._surface_id != surface_id:
        raise HTTPException(
            status_code=404,
            detail=f"Surface '{surface_id}' not found",
        )

    try:
        tools = await manager.list_tools()
    except Exception as exc:
        logger.exception("Failed to list tools for surface %s: %s", surface_id, exc)
        raise HTTPException(
            status_code=500, detail="Failed to list tools"
        ) from exc

    return tools


# ---------------------------------------------------------------------------
# POST /v1/surfaces/{surface_id}/query — query a tool
# ---------------------------------------------------------------------------

@router.post("/{surface_id}/query")
async def query_tool(
    surface_id: str,
    body: ToolQueryRequest,
    request: Request,
) -> Any:
    """Query an auto-generated MCP tool on the context surface."""
    manager = _get_surfaces_manager(request)

    if manager._surface_id != surface_id:
        raise HTTPException(
            status_code=404,
            detail=f"Surface '{surface_id}' not found",
        )

    try:
        result = await manager.query_tool(
            tool_name=body.tool_name,
            arguments=body.arguments,
            agent_key=body.agent_key,
        )
    except Exception as exc:
        logger.exception(
            "Tool query failed (surface=%s, tool=%s): %s",
            surface_id,
            body.tool_name,
            exc,
        )
        raise HTTPException(
            status_code=500,
            detail=f"Tool query failed: {body.tool_name}",
        ) from exc

    return result
