"""Task management routes — create, list, get, retry, timeline, SSE."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from sse_starlette.sse import EventSourceResponse

from src.models import (
    CircuitBreakerState,
    CreateTaskRequest,
    Task,
    TaskResponse,
    TaskStatus,
    TimelineEvent,
    TimelineEventType,
)
from src.api.sse import create_event_stream

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/tasks", tags=["tasks"])


# ---------------------------------------------------------------------------
# Dependency helpers — pull objects from app.state
# ---------------------------------------------------------------------------

def _get_tasks(request: Request) -> dict[str, Task]:
    return request.app.state.tasks


def _get_task_store(request: Request):
    return getattr(request.app.state, "task_store", None)


def _get_agent(request: Request):
    return request.app.state.agent


def _get_timeline(request: Request):
    return request.app.state.timeline


# ---------------------------------------------------------------------------
# POST /v1/tasks — create + start a task
# ---------------------------------------------------------------------------

@router.post("", status_code=201, response_model=TaskResponse)
async def create_task(
    body: CreateTaskRequest,
    request: Request,
) -> TaskResponse:
    """Create a new task and launch it in the background."""
    task = Task(
        instruction=body.instruction,
        max_retries=body.max_retries,
        max_budget_usd=body.max_budget_usd,
        metadata=body.metadata,
        status=TaskStatus.PENDING,
    )

    tasks: dict[str, Task] = request.app.state.tasks
    tasks[task.id] = task

    # Persist to SQLite
    task_store = _get_task_store(request)
    if task_store is not None:
        await task_store.save_task(task)

    # Emit creation event
    timeline = request.app.state.timeline
    timeline.emit(
        task_id=task.id,
        event_type=TimelineEventType.TASK_CREATED,
        message=f"Task created: {task.instruction[:80]}",
    )

    # Launch agent in background — don't await so we return immediately
    agent = request.app.state.agent
    asyncio.create_task(_run_agent(agent, task, tasks, task_store))

    return TaskResponse.from_task(task)


async def _run_agent(agent, task: Task, tasks: dict[str, Task], task_store=None) -> None:
    """Background coroutine that drives the agent loop for a task."""
    try:
        task.status = TaskStatus.RUNNING
        await agent.run(task)
    except Exception as exc:  # noqa: BLE001
        logger.exception("Unhandled error running task %s: %s", task.id, exc)
        task.status = TaskStatus.FAILED
    finally:
        # Ensure the dict always has the latest state (task is mutated in-place)
        tasks[task.id] = task
        # Persist final state
        if task_store is not None:
            try:
                await task_store.save_task(task)
            except Exception:  # noqa: BLE001
                logger.warning("Failed to persist task %s after run", task.id)


# ---------------------------------------------------------------------------
# GET /v1/tasks — list all tasks
# ---------------------------------------------------------------------------

@router.get("", response_model=list[TaskResponse])
async def list_tasks(request: Request) -> list[TaskResponse]:
    """Return a summary list of all tasks."""
    tasks: dict[str, Task] = request.app.state.tasks
    return [TaskResponse.from_task(t) for t in tasks.values()]


# ---------------------------------------------------------------------------
# GET /v1/tasks/{task_id} — get a single task (full model)
# ---------------------------------------------------------------------------

@router.get("/{task_id}", response_model=Task)
async def get_task(task_id: str, request: Request) -> Task:
    """Return the full Task model, including all attempts."""
    tasks: dict[str, Task] = request.app.state.tasks
    task = tasks.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"Task '{task_id}' not found")
    return task


# ---------------------------------------------------------------------------
# POST /v1/tasks/{task_id}/retry — manual retry
# ---------------------------------------------------------------------------

@router.post("/{task_id}/retry", response_model=TaskResponse)
async def retry_task(task_id: str, request: Request) -> TaskResponse:
    """Reset task status and relaunch the agent."""
    tasks: dict[str, Task] = request.app.state.tasks
    task = tasks.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"Task '{task_id}' not found")

    # Reset for a fresh retry cycle
    task.status = TaskStatus.PENDING
    task.current_attempt += 1
    task.completed_at = None
    task.result = None

    task_store = _get_task_store(request)
    if task_store is not None:
        await task_store.save_task(task)

    agent = request.app.state.agent
    asyncio.create_task(_run_agent(agent, task, tasks, task_store))

    return TaskResponse.from_task(task)


# ---------------------------------------------------------------------------
# GET /v1/tasks/{task_id}/timeline — full event timeline
# ---------------------------------------------------------------------------

@router.get("/{task_id}/timeline", response_model=list[TimelineEvent])
async def get_task_timeline(task_id: str, request: Request) -> list[TimelineEvent]:
    """Return all timeline events for a task."""
    tasks: dict[str, Task] = request.app.state.tasks
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail=f"Task '{task_id}' not found")

    timeline = request.app.state.timeline
    return timeline.get_timeline(task_id)


# ---------------------------------------------------------------------------
# GET /v1/tasks/{task_id}/sse — Server-Sent Events stream
# ---------------------------------------------------------------------------

@router.get("/{task_id}/sse")
async def task_sse(task_id: str, request: Request) -> EventSourceResponse:
    """Stream real-time timeline events for a task via SSE."""
    tasks: dict[str, Task] = request.app.state.tasks
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail=f"Task '{task_id}' not found")

    timeline = request.app.state.timeline

    async def _generator():
        async for event_dict in create_event_stream(timeline, task_id):
            yield event_dict

    return EventSourceResponse(_generator())


# ---------------------------------------------------------------------------
# GET /v1/tasks/{task_id}/circuit-breaker — circuit breaker visibility
# ---------------------------------------------------------------------------

@router.get("/{task_id}/circuit-breaker", response_model=CircuitBreakerState)
async def get_circuit_breaker(task_id: str, request: Request) -> CircuitBreakerState:
    """Return the current circuit breaker state for a task.

    If the circuit is open (last N consecutive attempts share the same error),
    the response explains why retries have stopped and what to check.
    """
    tasks: dict[str, Task] = request.app.state.tasks
    task = tasks.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"Task '{task_id}' not found")

    retry_engine = request.app.state.retry_engine
    if retry_engine is None:
        # No memory backend configured — circuit breaker is always closed
        return CircuitBreakerState()
    return retry_engine.get_circuit_breaker_state(task)


# ---------------------------------------------------------------------------
# GET /v1/tasks/{task_id}/learnings — learning summary for a task
# ---------------------------------------------------------------------------

@router.get("/{task_id}/learnings")
async def get_task_learnings(task_id: str, request: Request) -> dict[str, Any]:
    """Return a structured learning summary for a task.

    Extracts learnings from the task's failure records and success record.
    Works even when the task is still running (returns partial learnings
    from failures so far).
    """
    tasks: dict[str, Task] = request.app.state.tasks
    task = tasks.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"Task '{task_id}' not found")

    # Compute total time
    if task.created_at and task.completed_at:
        total_time_ms = (task.completed_at - task.created_at).total_seconds() * 1000
    elif task.created_at:
        from datetime import datetime, timezone
        total_time_ms = (datetime.now(timezone.utc) - task.created_at).total_seconds() * 1000
    else:
        total_time_ms = 0

    learnings: list[dict[str, Any]] = []

    # Extract learnings from failure records via memory backend
    memory = getattr(request.app.state, "memory", None)
    if memory is not None:
        try:
            failure_records = await memory.get_failures_for_task(task_id)
            for fr in failure_records:
                learnings.append({
                    "insight": fr.analysis.suggested_fix or fr.analysis.root_cause,
                    "confidence": fr.analysis.confidence,
                    "transferable": getattr(fr, "transferable", True),
                    "category": fr.signature.error_category.value,
                })
        except Exception:
            logger.warning("Could not fetch failure records for learnings of task %s", task_id)

    # If no memory backend or no records, derive from task attempts
    if not learnings:
        for attempt in task.attempts:
            if attempt.status == "failed":
                for step in attempt.steps:
                    if step.error:
                        learnings.append({
                            "insight": f"Avoid: {step.error}",
                            "confidence": 0.7,
                            "transferable": True,
                            "category": "unknown",
                        })

    # Add success insight if task succeeded
    if task.status == TaskStatus.SUCCEEDED and task.result:
        learnings.append({
            "insight": f"Solution: {task.result}",
            "confidence": 0.95,
            "transferable": True,
            "category": "success",
        })

    return {
        "task_id": task_id,
        "task_name": task.instruction,
        "status": task.status.value,
        "attempt_count": len(task.attempts),
        "total_cost_usd": task.total_cost_usd,
        "total_time_ms": round(total_time_ms, 1),
        "learnings": learnings,
    }


# ---------------------------------------------------------------------------
# POST /v1/tasks/ab-comparison — A/B demo: with vs without memory
# ---------------------------------------------------------------------------

@router.post("/ab-comparison", status_code=201)
async def ab_comparison(
    body: CreateTaskRequest,
    request: Request,
) -> dict[str, Any]:
    """Run the same task twice **in parallel**: without memory then with memory.

    Returns immediately with task IDs while both agents run in the
    background.  The frontend polls ``GET /v1/tasks/{id}`` for live
    progress — each agent mutates its task in-place so every poll
    reflects real attempt data.  This is the demo money shot.
    """
    import uuid

    base_id = uuid.uuid4().hex[:12]
    agent = request.app.state.agent
    tasks_store: dict[str, Task] = request.app.state.tasks

    # ── Create the two tasks directly in the store ──────────────────
    # No-memory gets 1 retry (typical agent: no learning, gives up fast)
    # With-memory gets 5 retries (memory-aided: learns from failures)
    no_mem_task = Task(
        instruction=body.instruction,
        max_retries=1,
        max_budget_usd=body.max_budget_usd,
        metadata=dict(body.metadata, ab_side="without_memory"),
    )
    no_mem_task.id = f"{base_id}_no_mem"
    tasks_store[no_mem_task.id] = no_mem_task

    with_mem_task = Task(
        instruction=body.instruction,
        max_retries=max(body.max_retries, 5),
        max_budget_usd=body.max_budget_usd,
        metadata=dict(body.metadata, ab_side="with_memory"),
    )
    with_mem_task.id = f"{base_id}_with_mem"
    tasks_store[with_mem_task.id] = with_mem_task

    # ── Build a no-memory agent (ephemeral SQLite backend) ──────────
    from src.providers.memory.sqlite_backend import SQLiteMemoryBackend
    from src.core.agent import ReLoopAgent

    empty_backend = SQLiteMemoryBackend(":memory:")
    no_mem_agent = ReLoopAgent(
        memory_backend=empty_backend,
        sandbox=agent._sandbox,
        llm=agent._llm,
        max_retries=body.max_retries,
        max_budget_usd=body.max_budget_usd,
        circuit_breaker_threshold=agent._circuit_breaker_threshold,
    )

    # ── Launch both agents in parallel ──────────────────────────────
    # Each agent.run() mutates the task in-place, so polling the store
    # returns real-time attempt data as the REJD loop progresses.

    async def _run_single(run_agent, task: Task) -> None:
        try:
            task.status = TaskStatus.RUNNING
            await run_agent.run(task)
        except Exception as exc:
            logger.exception("A/B agent failed for %s: %s", task.id, exc)
            task.status = TaskStatus.ABANDONED

    asyncio.create_task(_run_single(no_mem_agent, no_mem_task))
    asyncio.create_task(_run_single(agent, with_mem_task))

    return {
        "without_memory": {
            "task_id": no_mem_task.id,
            "status": "running",
            "succeeded": False,
            "total_attempts": 0,
            "total_cost_usd": 0.0,
        },
        "with_memory": {
            "task_id": with_mem_task.id,
            "status": "running",
            "succeeded": False,
            "total_attempts": 0,
            "total_cost_usd": 0.0,
        },
    }
