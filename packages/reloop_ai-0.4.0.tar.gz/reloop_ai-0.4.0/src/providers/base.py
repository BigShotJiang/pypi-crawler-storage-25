"""Abstract provider interfaces — all backends implement these."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, AsyncIterator

from src.models import (
    Checkpoint,
    FailureRecord,
    MemoryStatsResponse,
    SuccessRecord,
)


class MemoryBackend(ABC):
    """Stores and retrieves failure/success records."""

    @abstractmethod
    async def store_failure(self, failure: FailureRecord) -> str:
        """Store a failure record. Returns the record ID."""

    @abstractmethod
    async def store_success(self, success: SuccessRecord) -> str:
        """Store a success record. Returns the record ID."""

    @abstractmethod
    async def get_similar_failures(
        self,
        error_type: str,
        error_message: str,
        limit: int = 5,
        embedding: list[float] | None = None,
    ) -> list[FailureRecord]:
        """Find failures with similar error signatures."""

    @abstractmethod
    async def search(
        self,
        query: str,
        limit: int = 5,
        filters: dict[str, Any] | None = None,
    ) -> list[FailureRecord]:
        """Semantic search over failure memory."""

    @abstractmethod
    async def get_failure(self, failure_id: str) -> FailureRecord | None:
        """Get a single failure by ID."""

    @abstractmethod
    async def get_failures_for_task(self, task_id: str) -> list[FailureRecord]:
        """Get all failures for a given task."""

    @abstractmethod
    async def get_stats(self) -> MemoryStatsResponse:
        """Get aggregate memory statistics."""

    @abstractmethod
    async def clear(self) -> None:
        """Clear all stored memories. Use with caution."""


class SandboxProvider(ABC):
    """Executes commands in an isolated sandbox environment."""

    @abstractmethod
    async def create(self, config: dict[str, Any] | None = None) -> str:
        """Create a new sandbox. Returns sandbox ID."""

    @abstractmethod
    async def execute(
        self,
        sandbox_id: str,
        command: str,
        timeout: int = 120,
    ) -> ExecutionResult:
        """Execute a command in the sandbox. Returns result."""

    @abstractmethod
    async def checkpoint(self, sandbox_id: str) -> str:
        """Create a checkpoint of the sandbox state. Returns checkpoint ID."""

    @abstractmethod
    async def restore(self, sandbox_id: str, checkpoint_id: str) -> None:
        """Restore sandbox to a checkpoint."""

    @abstractmethod
    async def destroy(self, sandbox_id: str) -> None:
        """Destroy a sandbox and free resources."""

    @abstractmethod
    async def list_checkpoints(self, sandbox_id: str) -> list[Checkpoint]:
        """List all checkpoints for a sandbox."""


class LLMProvider(ABC):
    """Generates text and performs reasoning via an LLM."""

    @abstractmethod
    async def generate(
        self,
        prompt: str,
        system: str = "",
        temperature: float = 0.3,
    ) -> LLMResponse:
        """Generate a completion. Returns structured response."""

    @abstractmethod
    async def generate_with_tools(
        self,
        prompt: str,
        system: str = "",
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.3,
    ) -> LLMResponse:
        """Generate with tool-calling support."""

    @abstractmethod
    async def stream(
        self,
        prompt: str,
        system: str = "",
    ) -> AsyncIterator[str]:
        """Stream a completion token-by-token."""

    @abstractmethod
    async def embed(self, text: str) -> list[float]:
        """Generate an embedding vector for text."""


# --- Result types used by providers ---

class ExecutionResult:
    """Result from sandbox command execution."""

    def __init__(
        self,
        exit_code: int,
        stdout: str,
        stderr: str,
        duration_ms: int = 0,
    ) -> None:
        self.exit_code = exit_code
        self.stdout = stdout
        self.stderr = stderr
        self.duration_ms = duration_ms

    @property
    def success(self) -> bool:
        return self.exit_code == 0

    @property
    def output(self) -> str:
        return self.stdout if self.success else self.stderr

    def to_dict(self) -> dict[str, Any]:
        return {
            "exit_code": self.exit_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "duration_ms": self.duration_ms,
            "success": self.success,
        }


class LLMResponse:
    """Result from LLM generation."""

    def __init__(
        self,
        content: str,
        tool_calls: list[dict[str, Any]] | None = None,
        tokens_used: int = 0,
        cost_usd: float = 0.0,
        model: str = "",
    ) -> None:
        self.content = content
        self.tool_calls = tool_calls or []
        self.tokens_used = tokens_used
        self.cost_usd = cost_usd
        self.model = model

    def to_dict(self) -> dict[str, Any]:
        return {
            "content": self.content,
            "tool_calls": self.tool_calls,
            "tokens_used": self.tokens_used,
            "cost_usd": self.cost_usd,
            "model": self.model,
        }
