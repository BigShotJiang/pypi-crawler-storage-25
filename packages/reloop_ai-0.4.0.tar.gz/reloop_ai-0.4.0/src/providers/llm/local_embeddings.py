"""Local Embedding Provider -- offline semantic embeddings for ReLoop.

Provides a fallback embedding pipeline when the OpenAI API is unavailable:

1. sentence-transformers (all-MiniLM-L6-v2) — real semantic embeddings,
   384-dim zero-padded to 1536.  Install with: pip install 'reloop[local-embeddings]'
2. TF-IDF via scikit-learn (good quality, optional dependency)
3. Bag-of-words with IDF weighting (decent quality, no external deps)

All approaches produce normalized vectors suitable for cosine similarity.
"""

from __future__ import annotations

import hashlib
import logging
import math
import re
from collections import Counter
from typing import Any

logger = logging.getLogger(__name__)

# Target dimensionality for the bag-of-words fallback.  We use random
# projection from word hashes to keep vectors a fixed size so they work
# with Redis VECTOR indexes that expect a constant dimension.
_BOW_DIM = 1536


class LocalEmbedder:
    """Offline text embedder with two strategy tiers.

    Tier 1 -- TF-IDF (requires ``scikit-learn >= 1.4``):
        Builds a vocabulary from all texts seen so far and produces sparse
        TF-IDF vectors projected to a fixed dimensionality via hashing.

    Tier 2 -- Bag-of-words with random projection (zero dependencies):
        Each unique token is mapped to a deterministic pseudo-random direction
        (seeded by the token hash) and the text embedding is the IDF-weighted
        normalised sum.  Texts sharing tokens will have positive cosine
        similarity.

    Both tiers produce vectors of length ``_BOW_DIM`` (1536) so they are
    compatible with the Redis VECTOR index used for OpenAI embeddings.
    """

    def __init__(self) -> None:
        self._method: str = "none"
        self._st_model: Any = None  # sentence_transformers.SentenceTransformer
        self._st_available: bool = False
        self._tfidf: Any = None  # sklearn TfidfVectorizer
        self._sklearn_available: bool = False
        self._idf_corpus: list[str] = []
        self._idf_table: dict[str, float] = {}
        self._doc_count: int = 0
        self._initialised: bool = False

    # ------------------------------------------------------------------
    # Initialisation
    # ------------------------------------------------------------------

    def _init_once(self) -> None:
        if self._initialised:
            return
        self._initialised = True

        # Tier 1: sentence-transformers (real semantic embeddings)
        try:
            from sentence_transformers import SentenceTransformer  # type: ignore[import]

            self._st_model = SentenceTransformer("all-MiniLM-L6-v2")
            self._st_available = True
            self._method = "sentence-transformers"
            logger.info(
                "LocalEmbedder: using sentence-transformers (all-MiniLM-L6-v2) "
                "for real semantic embeddings"
            )
            return
        except Exception:
            logger.debug(
                "sentence-transformers not available "
                "(install with: pip install 'reloop[local-embeddings]')"
            )

        # Tier 2: TF-IDF via scikit-learn
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer  # type: ignore[import]

            self._tfidf = TfidfVectorizer(
                max_features=_BOW_DIM,
                sublinear_tf=True,
                dtype=float,
            )
            self._sklearn_available = True
            self._method = "tfidf"
            logger.info("LocalEmbedder: using scikit-learn TF-IDF embeddings")
            return
        except ImportError:
            pass

        # Tier 3: Bag-of-words random projection (zero deps)
        self._method = "bow"
        logger.info(
            "LocalEmbedder: using bag-of-words random projection embeddings "
            "(install sentence-transformers or scikit-learn for better quality)"
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def method(self) -> str:
        """Return the active embedding method: 'tfidf' or 'bow'."""
        self._init_once()
        return self._method

    def embed(self, text: str) -> list[float]:
        """Produce a normalised embedding vector for *text*.

        Returns a list of ``_BOW_DIM`` floats (unit length).
        """
        self._init_once()
        if self._st_available:
            return self._embed_sentence_transformers(text)
        if self._sklearn_available:
            return self._embed_tfidf(text)
        return self._embed_bow(text)

    # ------------------------------------------------------------------
    # Tier 1 -- sentence-transformers (real semantic embeddings)
    # ------------------------------------------------------------------

    def _embed_sentence_transformers(self, text: str) -> list[float]:
        """Generate a real semantic embedding using sentence-transformers.

        all-MiniLM-L6-v2 produces 384-dim vectors; we zero-pad to _BOW_DIM
        for compatibility with the Redis VECTOR index.
        """
        try:
            vec = self._st_model.encode(text, normalize_embeddings=True).tolist()
            if len(vec) < _BOW_DIM:
                vec = vec + [0.0] * (_BOW_DIM - len(vec))
            elif len(vec) > _BOW_DIM:
                vec = vec[:_BOW_DIM]
            return _normalise(vec)
        except Exception as exc:
            logger.warning(
                "sentence-transformers encode failed (%s); falling back to BoW", exc
            )
            return self._embed_bow(text)

    # ------------------------------------------------------------------
    # Tier 2 -- TF-IDF via scikit-learn
    # ------------------------------------------------------------------

    def _embed_tfidf(self, text: str) -> list[float]:
        """Generate a TF-IDF vector projected to fixed dimensionality."""
        # Add to corpus and refit (incremental-ish: refit is cheap for
        # the small corpus sizes we see during a single agent session).
        self._idf_corpus.append(text)
        try:
            self._tfidf.fit(self._idf_corpus)
            vec = self._tfidf.transform([text])
            dense = vec.toarray()[0]  # shape: (max_features,)
            # Pad or truncate to _BOW_DIM
            result = list(dense)
            if len(result) < _BOW_DIM:
                result.extend([0.0] * (_BOW_DIM - len(result)))
            elif len(result) > _BOW_DIM:
                result = result[:_BOW_DIM]
            # Normalise
            return _normalise(result)
        except Exception as exc:
            logger.warning("TF-IDF embed failed (%s); falling back to BoW", exc)
            return self._embed_bow(text)

    # ------------------------------------------------------------------
    # Tier 2 -- Bag-of-words with random projection (no deps)
    # ------------------------------------------------------------------

    def _embed_bow(self, text: str) -> list[float]:
        """Bag-of-words embedding via deterministic random projection."""
        tokens = _tokenise(text)
        if not tokens:
            return [0.0] * _BOW_DIM

        # Update lightweight IDF table
        self._doc_count += 1
        unique_tokens = set(tokens)
        for tok in unique_tokens:
            self._idf_table[tok] = self._idf_table.get(tok, 0) + 1

        # TF for this document
        tf = Counter(tokens)
        max_tf = max(tf.values())

        acc = [0.0] * _BOW_DIM
        for tok, count in tf.items():
            # Augmented TF to dampen high-frequency tokens
            tf_weight = 0.5 + 0.5 * (count / max_tf)
            # IDF: log(N / df)
            df = self._idf_table.get(tok, 1)
            idf_weight = math.log((self._doc_count + 1) / (df + 1)) + 1.0
            weight = tf_weight * idf_weight

            # Deterministic random direction from token hash
            direction = _token_direction(tok)
            for j in range(_BOW_DIM):
                acc[j] += weight * direction[j]

        return _normalise(acc)


# ======================================================================
# Module-level helpers
# ======================================================================

_TOKEN_RE = re.compile(r"[a-z0-9_]+")


def _tokenise(text: str) -> list[str]:
    """Lowercase tokenisation keeping alphanumeric + underscore runs."""
    return _TOKEN_RE.findall(text.lower())


def _normalise(vec: list[float]) -> list[float]:
    """L2-normalise a vector (return zero vector if norm is zero)."""
    norm = math.sqrt(sum(v * v for v in vec))
    if norm == 0.0:
        return vec
    return [v / norm for v in vec]


def _token_direction(token: str) -> list[float]:
    """Map a token to a deterministic unit-ish direction in R^_BOW_DIM.

    Uses MD5 hash bytes to seed a simple LCG for reproducible pseudo-random
    floats in [-1, 1].
    """
    word_hash = hashlib.md5(token.encode("utf-8")).digest()  # noqa: S324
    seed = int.from_bytes(word_hash[:8], "little")
    a_lcg = 6364136223846793005
    c_lcg = 1
    mod = 1 << 64
    direction = [0.0] * _BOW_DIM
    for j in range(_BOW_DIM):
        seed = (a_lcg * seed + c_lcg) % mod
        direction[j] = (seed / mod) * 2.0 - 1.0
    return direction
