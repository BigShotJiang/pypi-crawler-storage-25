"""Context Surfaces ContextModel definitions for ReLoop failure/success records.

Maps ReLoop's existing Redis data (failure:{id}, success:{id}) to ContextModel
subclasses so that context-surfaces can auto-generate MCP tools, RediSearch
indices, and OpenAPI schemas from a single source of truth.
"""

from __future__ import annotations

from typing import Optional

from context_surfaces.context_model import (
    ContextField,
    ContextModel,
    ContextRelationship,
)
from context_surfaces import export_data_model


class FailureSurface(ContextModel):
    """A structured failure record captured during a ReLoop REJD loop attempt.

    Important: These flat fields do NOT match the nested JSON structure that
    RedisMemoryBackend stores in its ``data`` hash field (which nests error
    fields under ``signature`` and analysis fields under ``analysis``).
    Context Surfaces accesses data exclusively via ``import_existing_records``
    in ContextSurfacesManager, which flattens the nested Redis JSON into
    these flat fields before import.  Do NOT point Context Surfaces at the
    raw Redis hashes directly — the field names will not match.
    """

    __redis_key_template__ = "failure:{id}"

    id: str = ContextField(
        description="Unique failure record identifier",
        is_key_component=True,
    )
    task_id: str = ContextField(
        description="Parent task identifier",
        index="tag",
    )
    attempt_number: int = ContextField(
        description="Which attempt produced this failure (1-based)",
        index="numeric",
        sortable=True,
    )
    error_type: str = ContextField(
        description="Exception or error class name",
        index="tag",
    )
    error_category: str = ContextField(
        description="High-level category (dependency_error, config_error, ...)",
        index="tag",
    )
    error_message: str = ContextField(
        description="Full error message text",
        index="text",
    )
    error_hash: str = ContextField(
        description="SHA-256 prefix for deduplication",
        index="tag",
    )
    root_cause: str = ContextField(
        description="LLM-distilled root cause analysis",
        index="text",
    )
    what_was_tried: str = ContextField(
        description="Description of the approach that was attempted",
        index="text",
    )
    why_it_failed: str = ContextField(
        description="Explanation of why the approach did not work",
        index="text",
    )
    suggested_fix: str = ContextField(
        description="Recommended fix for future attempts",
        index="text",
    )
    anti_pattern: Optional[str] = ContextField(
        description="Anti-pattern to avoid in future attempts",
        default=None,
        index="text",
    )
    confidence: float = ContextField(
        description="Confidence score for the analysis (0.0-1.0)",
        index="numeric",
        sortable=True,
    )
    cost_usd: float = ContextField(
        description="Cost in USD for this attempt",
        index="numeric",
        sortable=True,
    )
    timestamp: str = ContextField(
        description="ISO-8601 timestamp of the failure",
        index="tag",
    )
    embedding: Optional[list[float]] = ContextField(
        description="Vector embedding for semantic similarity search",
        default=None,
        index="vector",
        vector_dim=1536,
        distance_metric="COSINE",
    )


class SuccessSurface(ContextModel):
    """A structured success record captured when a ReLoop task completes."""

    __redis_key_template__ = "success:{id}"

    id: str = ContextField(
        description="Unique success record identifier",
        is_key_component=True,
    )
    task_id: str = ContextField(
        description="Parent task identifier",
        index="tag",
    )
    attempt_number: int = ContextField(
        description="Which attempt succeeded (1-based)",
        index="numeric",
        sortable=True,
    )
    approach: str = ContextField(
        description="Description of the successful approach",
        index="text",
    )
    key_insight: str = ContextField(
        description="Key insight that led to success",
        index="text",
    )
    failure_count: int = ContextField(
        description="Number of failures before this success",
        index="numeric",
    )
    total_attempts: int = ContextField(
        description="Total attempts including the successful one",
        index="numeric",
    )
    total_cost_usd: float = ContextField(
        description="Cumulative cost across all attempts",
        index="numeric",
        sortable=True,
    )
    timestamp: str = ContextField(
        description="ISO-8601 timestamp of the success",
        index="tag",
    )


# Relationships defined after both classes to avoid forward reference NameError.
# ContextRelationship is a descriptor evaluated at assignment time, not a type
# annotation, so `from __future__ import annotations` does not defer resolution.
FailureSurface.resolved_by = ContextRelationship(
    description="The success record that resolved failures for this task",
    source_field="task_id",
)
FailureSurface.__annotations__["resolved_by"] = SuccessSurface

SuccessSurface.prior_failures = ContextRelationship(
    description="Failure records from prior attempts on the same task",
    source_field="task_id",
)
SuccessSurface.__annotations__["prior_failures"] = FailureSurface


def get_reloop_data_model() -> dict:
    """Export the complete ReLoop data model for Context Surfaces.

    Returns a dictionary matching the Context Surfaces OpenAPI schema,
    suitable for passing to the ContextSurfacesClient or MCP server.
    """
    return export_data_model(
        title="ReLoop Failure Memory",
        description=(
            "Structured failure and success records from ReLoop's REJD loop. "
            "Failures include error signatures, root cause analysis, suggested "
            "fixes, and vector embeddings for semantic search. Successes capture "
            "the approach and key insight that resolved prior failures."
        ),
        entities=[FailureSurface, SuccessSurface],
    )
