"""Context Surfaces client for ReLoop failure memory.

Manages the lifecycle of context surfaces: creation, agent key management,
data import, and MCP tool queries.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from src.config import Settings

DEFAULT_TIMEOUT_SECONDS: float = 10.0

logger = logging.getLogger(__name__)

try:
    from context_surfaces import UnifiedClient as _UnifiedClient  # noqa: F401

    CONTEXT_SURFACES_AVAILABLE = True
except Exception:
    CONTEXT_SURFACES_AVAILABLE = False
    logger.info(
        "context-surfaces package not available — "
        "Context Surfaces features will be disabled"
    )


class ContextSurfacesManager:
    """Manages a Context Surfaces surface backed by ReLoop's Redis data."""

    def __init__(
        self,
        config: Settings,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
    ) -> None:
        self._config = config
        self._timeout = timeout
        self._client: Any = None  # UnifiedClient, lazily initialized
        self._surface_id: str | None = None
        self._agent_keys: list[dict[str, str]] = []  # [{"name": ..., "key": ...}]

    def _get_client(self) -> Any:
        """Lazily initialize the UnifiedClient."""
        if self._client is None:
            from context_surfaces import UnifiedClient

            self._client = UnifiedClient(
                admin_key=self._config.context_surfaces_admin_key,
                api_url=self._config.context_surfaces_api_url,
                timeout=self._timeout,
            )
        return self._client

    async def ensure_surface(
        self,
        name: str = "reloop-failure-memory",
    ) -> str:
        """Create the context surface if it does not already exist.

        Args:
            name: Surface name (default: "reloop-failure-memory").

        Returns the surface_id.
        """
        if self._surface_id is not None:
            return self._surface_id

        from context_surfaces import (
            CreateContextSurfaceRequest,
            DataSourceConnectionConfig,
            DataSourceRequest,
        )
        from src.providers.memory.context_surfaces import get_reloop_data_model

        client = self._get_client()
        data_model = get_reloop_data_model()

        request = CreateContextSurfaceRequest(
            name=name,
            description=(
                "ReLoop structured failure and success records "
                "with semantic search and auto-generated MCP tools."
            ),
            data_source=DataSourceRequest(
                connection=DataSourceConnectionConfig(
                    url=self._config.redis_url,
                ),
            ),
            data_model=data_model,
        )

        response = await client.create_context_surface(request)
        self._surface_id = response.surface_id
        logger.info("Context surface created: %s", self._surface_id)
        return self._surface_id

    async def create_agent_key(
        self,
        name: str = "reloop-agent",
        description: str = "ReLoop REJD loop agent key",
    ) -> str:
        """Create an agent key for the current surface.

        Returns the agent key string.
        """
        from context_surfaces import CreateAgentKeyRequest

        surface_id = await self.ensure_surface()
        client = self._get_client()

        request = CreateAgentKeyRequest(
            surface_id=surface_id,
            name=name,
            description=description,
        )

        response = await client.create_agent_key(request)
        key = response.agent_key
        self._agent_keys.append({"name": name, "key": key})
        logger.info("Agent key created: %s (name=%s)", key[:8] + "...", name)
        return key

    async def get_or_create_agent_key(self) -> str:
        """Return the most recent agent key, or create one if none exist."""
        if self._agent_keys:
            return self._agent_keys[-1]["key"]

        return await self.create_agent_key()

    async def list_tools(self, agent_key: str | None = None) -> list[dict[str, Any]]:
        """List auto-generated MCP tools for the surface.

        Args:
            agent_key: Agent key to use. If None, uses the cached key.

        Returns:
            List of tool definitions (name, description, parameters).
        """
        key = agent_key or await self.get_or_create_agent_key()
        client = self._get_client()
        response = await client.list_tools(agent_key=key)
        return response.tools

    async def query_tool(
        self,
        tool_name: str,
        arguments: dict[str, Any],
        agent_key: str | None = None,
    ) -> Any:
        """Query a specific auto-generated MCP tool.

        Args:
            tool_name: Name of the MCP tool to invoke.
            arguments: Tool arguments dict.
            agent_key: Agent key to use. If None, uses the cached key.

        Returns:
            Tool response data.
        """
        key = agent_key or await self.get_or_create_agent_key()
        client = self._get_client()
        response = await client.query_tool(
            agent_key=key,
            tool_name=tool_name,
            arguments=arguments,
        )
        return response

    async def import_existing_records(self, redis_backend: Any) -> dict[str, int]:
        """Import all existing failure/success records from RedisMemoryBackend.

        Reads records from Redis and imports them into the context surface
        using the UnifiedClient.import_data() method.

        Args:
            redis_backend: A RedisMemoryBackend instance.

        Returns:
            Dict with counts: {"failures": N, "successes": N}.
        """
        await self.ensure_surface()
        client = self._get_client()
        redis_client = await redis_backend._get_client()

        # Collect all failure records
        failures: list[dict[str, Any]] = []
        cursor = 0
        while True:
            cursor, keys = await redis_client.scan(
                cursor, match="failure:*", count=200, _type="hash"
            )
            for key in keys:
                raw = await redis_client.hget(key, "data")
                if raw:
                    record = json.loads(raw)
                    # Flatten nested structure for context surfaces
                    flat: dict[str, Any] = {
                        "id": record.get("id", ""),
                        "task_id": record.get("task_id", ""),
                        "attempt_number": record.get("attempt_number", 0),
                        "error_type": record.get("signature", {}).get(
                            "error_type", ""
                        ),
                        "error_category": record.get("signature", {}).get(
                            "error_category", ""
                        ),
                        "error_message": record.get("signature", {}).get(
                            "error_message", ""
                        ),
                        "error_hash": record.get("signature", {}).get(
                            "error_hash", ""
                        ),
                        "root_cause": record.get("analysis", {}).get(
                            "root_cause", ""
                        ),
                        "what_was_tried": record.get("analysis", {}).get(
                            "what_was_tried", ""
                        ),
                        "why_it_failed": record.get("analysis", {}).get(
                            "why_it_failed", ""
                        ),
                        "suggested_fix": record.get("analysis", {}).get(
                            "suggested_fix", ""
                        ),
                        "anti_pattern": record.get("analysis", {}).get(
                            "anti_pattern"
                        ),
                        "confidence": record.get("analysis", {}).get(
                            "confidence", 0.0
                        ),
                        "cost_usd": record.get("cost_usd", 0.0),
                        "timestamp": record.get("timestamp", ""),
                        "embedding": record.get("embedding"),
                    }
                    failures.append(flat)
            if cursor == 0:
                break

        # Collect all success records
        successes: list[dict[str, Any]] = []
        cursor = 0
        while True:
            cursor, keys = await redis_client.scan(
                cursor, match="success:*", count=200, _type="hash"
            )
            for key in keys:
                raw = await redis_client.hget(key, "data")
                if raw:
                    record = json.loads(raw)
                    flat = {
                        "id": record.get("id", ""),
                        "task_id": record.get("task_id", ""),
                        "attempt_number": record.get("attempt_number", 0),
                        "approach": record.get("solution", {}).get("approach", ""),
                        "key_insight": record.get("solution", {}).get(
                            "key_insight", ""
                        ),
                        "failure_count": record.get("learning", {}).get(
                            "failure_count", 0
                        ),
                        "total_attempts": record.get("metrics", {}).get(
                            "total_attempts", 0
                        ),
                        "total_cost_usd": record.get("metrics", {}).get(
                            "total_cost_usd", 0.0
                        ),
                        "timestamp": record.get("timestamp", ""),
                    }
                    successes.append(flat)
            if cursor == 0:
                break

        # Import into context surface
        if failures:
            await client.import_data(
                surface_id=self._surface_id,
                entity="FailureSurface",
                records=failures,
            )
            logger.info("Imported %d failure records", len(failures))

        if successes:
            await client.import_data(
                surface_id=self._surface_id,
                entity="SuccessSurface",
                records=successes,
            )
            logger.info("Imported %d success records", len(successes))

        return {"failures": len(failures), "successes": len(successes)}
