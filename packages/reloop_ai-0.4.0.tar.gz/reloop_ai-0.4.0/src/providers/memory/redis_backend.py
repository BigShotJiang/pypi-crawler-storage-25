"""Redis Memory Backend — primary production backend for ReLoop failure memory.

Uses Redis 8.6+ native vector sets (VADD/VSIM) for O(log N) semantic similarity
search when available. Falls back to RediSearch FT.SEARCH if the module is loaded.
When neither is present, uses sorted-set indexes with pipelined batch fetches
(avoids SCAN for all hot paths). Final fallback: error_type and error_hash
secondary indexes for targeted lookups.
"""

from __future__ import annotations

import json
import logging
import struct
from typing import Any

from src.config import settings
from src.models import (
    ErrorCategory,
    FailureRecord,
    MemoryStatsResponse,
    SuccessRecord,
)
from src.providers.base import MemoryBackend

logger = logging.getLogger(__name__)

# Embedding dimension for the RediSearch VECTOR index (text-embedding-3-small = 1536)
_EMBED_DIM = 1536


class RedisMemoryBackend(MemoryBackend):
    """Redis-backed memory store using hashes, sorted sets, and optional RediSearch."""

    def __init__(
        self,
        redis_url: str | None = None,
        index_name: str | None = None,
    ) -> None:
        self._redis_url = redis_url or settings.redis_url
        self._index_name = index_name or settings.redis_memory_index
        self._client: Any = None  # redis.asyncio.Redis
        self._has_redisearch: bool = False
        self._has_vset: bool = False  # Redis 8.6+ native vector sets (VADD/VSIM)
        self._vset_key: str = f"{self._index_name}:vset"
        self._ft_index_created: bool = False

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _get_client(self) -> Any:
        """Lazily initialise the async Redis client."""
        if self._client is None:
            try:
                import redis.asyncio as aioredis  # type: ignore[import]

                self._client = aioredis.from_url(
                    self._redis_url,
                    decode_responses=True,
                )
                # Probe for RediSearch module
                try:
                    await self._client.execute_command("FT._LIST")
                    self._has_redisearch = True
                    logger.info("RediSearch module detected")
                except Exception:
                    self._has_redisearch = False
                    logger.debug("RediSearch module not available")

                # Ensure FT index exists when RediSearch is present
                if self._has_redisearch:
                    await self._ensure_ft_index()

                # Probe for Redis 8.6+ native vector sets (VADD/VSIM)
                try:
                    await self._client.execute_command("VCARD", self._vset_key)
                    self._has_vset = True
                    logger.info(
                        "Redis 8.6+ vector sets available (VADD/VSIM) -- key=%s",
                        self._vset_key,
                    )
                except Exception:
                    self._has_vset = False
                    logger.debug("Redis vector sets not available; using fallback search")
            except Exception as exc:
                logger.warning("Redis connection failed: %s", exc)
                raise
        return self._client

    async def _ensure_ft_index(self) -> None:
        """Create the RediSearch full-text + vector index if it doesn't exist.

        Index schema on Hash keys prefixed with ``failure:``:
        - error_type: TAG (filterable)
        - error_category: TAG (filterable)
        - error_hash: TAG (exact match)
        - error_message: TEXT (full-text searchable)
        - root_cause: TEXT
        - suggested_fix: TEXT
        - task_id: TAG
        - embedding_blob: VECTOR (HNSW, cosine, FP32)
        """
        if self._ft_index_created:
            return
        client = self._client
        try:
            # Check if the index already exists
            await client.execute_command("FT.INFO", self._index_name)
            self._ft_index_created = True
            logger.debug("RediSearch index %r already exists", self._index_name)
            return
        except Exception:
            pass  # Index doesn't exist yet -- create it

        try:
            await client.execute_command(
                "FT.CREATE",
                self._index_name,
                "ON",
                "HASH",
                "PREFIX",
                "1",
                "failure:",
                "SCHEMA",
                "error_type",
                "TAG",
                "SORTABLE",
                "error_category",
                "TAG",
                "SORTABLE",
                "error_hash",
                "TAG",
                "task_id",
                "TAG",
                "error_message",
                "TEXT",
                "WEIGHT",
                "2.0",
                "root_cause",
                "TEXT",
                "suggested_fix",
                "TEXT",
                "embedding_blob",
                "VECTOR",
                "HNSW",
                "6",
                "TYPE",
                "FLOAT32",
                "DIM",
                str(_EMBED_DIM),
                "DISTANCE_METRIC",
                "COSINE",
            )
            self._ft_index_created = True
            logger.info(
                "Created RediSearch index %r with VECTOR field (dim=%d)",
                self._index_name,
                _EMBED_DIM,
            )
        except Exception as exc:
            logger.warning("Failed to create RediSearch index: %s", exc)
            # RediSearch is present but index creation failed -- disable it
            self._has_redisearch = False

    @staticmethod
    def _failure_key(failure_id: str) -> str:
        return f"failure:{failure_id}"

    @staticmethod
    def _success_key(success_id: str) -> str:
        return f"success:{success_id}"

    @staticmethod
    def _task_failures_key(task_id: str) -> str:
        return f"task:{task_id}:failures"

    @staticmethod
    def _task_successes_key(task_id: str) -> str:
        return f"task:{task_id}:successes"

    def _serialize_failure(self, failure: FailureRecord) -> str:
        return failure.model_dump_json()

    def _deserialize_failure(self, raw: str) -> FailureRecord | None:
        try:
            data = json.loads(raw)
            return FailureRecord.model_validate(data)
        except Exception as exc:
            logger.warning("Failed to deserialise failure record: %s", exc)
            return None

    @staticmethod
    def _cosine_similarity(a: list[float], b: list[float]) -> float:
        """Compute cosine similarity between two vectors.

        Uses numpy if available, otherwise falls back to pure-Python math.
        Returns a value in [-1, 1]; returns 0.0 if either vector is zero-length.
        """
        if not a or not b or len(a) != len(b):
            return 0.0
        try:
            import numpy as np  # type: ignore[import]

            va = np.array(a, dtype=float)
            vb = np.array(b, dtype=float)
            norm_a = float(np.linalg.norm(va))
            norm_b = float(np.linalg.norm(vb))
            if norm_a == 0.0 or norm_b == 0.0:
                return 0.0
            return float(np.dot(va, vb) / (norm_a * norm_b))
        except ImportError:
            import math

            dot = sum(x * y for x, y in zip(a, b))
            norm_a = math.sqrt(sum(x * x for x in a))
            norm_b = math.sqrt(sum(y * y for y in b))
            if norm_a == 0.0 or norm_b == 0.0:
                return 0.0
            return dot / (norm_a * norm_b)

    @staticmethod
    def _parse_vsim_result(raw: Any) -> list[str]:
        """Parse VSIM response into element IDs.

        Handles both flat [id, score, id, score, ...] and nested [[id, score], ...].
        """
        if not raw:
            return []
        ids: list[str] = []
        if isinstance(raw, list):
            if raw and isinstance(raw[0], (list, tuple)):
                # RESP3 nested pairs
                ids = [str(pair[0]) for pair in raw]
            else:
                # RESP2 flat -- check if alternating id/score pairs
                is_scored = False
                if len(raw) >= 2:
                    try:
                        float(raw[1])
                        is_scored = True
                    except (ValueError, TypeError):
                        pass
                if is_scored:
                    ids = [str(raw[i]) for i in range(0, len(raw), 2)]
                else:
                    ids = [str(x) for x in raw]
        return ids

    def _serialize_success(self, success: SuccessRecord) -> str:
        return success.model_dump_json()

    async def _batch_get_failures(
        self, client: Any, failure_ids: list[str]
    ) -> list[FailureRecord]:
        """Fetch multiple failure records in a single pipeline round-trip."""
        if not failure_ids:
            return []
        pipe = client.pipeline()
        for fid in failure_ids:
            pipe.hget(self._failure_key(fid), "data")
        raw_list = await pipe.execute()
        results: list[FailureRecord] = []
        for raw in raw_list:
            if raw:
                record = self._deserialize_failure(raw)
                if record:
                    results.append(record)
        return results

    async def _batch_get_embeddings(
        self, client: Any, failure_ids: list[str]
    ) -> list[tuple[str, list[float] | None]]:
        """Fetch embeddings for multiple failure IDs in a single pipeline."""
        if not failure_ids:
            return []
        pipe = client.pipeline()
        for fid in failure_ids:
            pipe.hget(self._failure_key(fid), "embedding")
        raw_list = await pipe.execute()
        results: list[tuple[str, list[float] | None]] = []
        for fid, raw_emb in zip(failure_ids, raw_list):
            if raw_emb:
                try:
                    emb: list[float] = json.loads(raw_emb)
                    results.append((fid, emb))
                except Exception:
                    results.append((fid, None))
            else:
                results.append((fid, None))
        return results

    async def _ft_vector_search(
        self,
        client: Any,
        embedding: list[float],
        limit: int,
    ) -> list[FailureRecord]:
        """Use RediSearch FT.SEARCH with KNN vector similarity."""
        # Pad/truncate embedding to match index dimension
        emb = embedding
        if len(emb) < _EMBED_DIM:
            emb = emb + [0.0] * (_EMBED_DIM - len(emb))
        elif len(emb) > _EMBED_DIM:
            emb = emb[:_EMBED_DIM]
        vec_blob = struct.pack(f"{_EMBED_DIM}f", *emb)

        # FT.SEARCH index "*=>[KNN N @embedding_blob $vec]" PARAMS 2 vec <blob>
        # SORTBY __embedding_blob_score ASC RETURN 1 data LIMIT 0 N DIALECT 2
        query = f"*=>[KNN {limit} @embedding_blob $vec AS vec_score]"
        raw = await client.execute_command(
            "FT.SEARCH",
            self._index_name,
            query,
            "PARAMS",
            "2",
            "vec",
            vec_blob,
            "SORTBY",
            "vec_score",
            "ASC",
            "RETURN",
            "1",
            "data",
            "LIMIT",
            "0",
            str(limit),
            "DIALECT",
            "2",
        )
        return self._parse_ft_search_results(raw)

    async def _ft_text_search(
        self,
        client: Any,
        query: str,
        limit: int,
        filters: dict[str, Any] | None = None,
    ) -> list[FailureRecord]:
        """Use RediSearch FT.SEARCH for full-text queries."""
        # Escape special RediSearch characters in the query
        escaped = query
        for ch in r"\,.<>{}[]\"':;!@#$%^&*()-+=~":
            escaped = escaped.replace(ch, f"\\{ch}")

        ft_query = escaped
        # Append TAG filters
        if filters:
            filter_parts: list[str] = []
            if "error_category" in filters:
                filter_parts.append(
                    f"@error_category:{{{filters['error_category']}}}"
                )
            if "error_type" in filters:
                et = filters["error_type"]
                for ch in r"\,.<>{}[]\"':;!@#$%^&*()-+=~":
                    et = et.replace(ch, f"\\{ch}")
                filter_parts.append(f"@error_type:{{{et}}}")
            if filter_parts:
                ft_query = f"({ft_query}) {' '.join(filter_parts)}"

        raw = await client.execute_command(
            "FT.SEARCH",
            self._index_name,
            ft_query,
            "RETURN",
            "1",
            "data",
            "LIMIT",
            "0",
            str(limit),
        )
        return self._parse_ft_search_results(raw)

    @staticmethod
    def _parse_ft_search_results(raw: Any) -> list[FailureRecord]:
        """Parse FT.SEARCH response into FailureRecord list.

        FT.SEARCH returns [total, key1, [field, value, ...], key2, [...], ...]
        """
        results: list[FailureRecord] = []
        if not raw or (isinstance(raw, list) and len(raw) < 2):
            return results
        items = raw[1:]
        i = 0
        while i + 1 < len(items):
            _key = items[i]
            fields = items[i + 1]
            i += 2
            # fields is a flat list [field_name, value, field_name, value, ...]
            data_val = None
            if isinstance(fields, list):
                for j in range(0, len(fields) - 1, 2):
                    if fields[j] == "data":
                        data_val = fields[j + 1]
                        break
            if data_val:
                try:
                    data = json.loads(data_val)
                    record = FailureRecord.model_validate(data)
                    results.append(record)
                except Exception:
                    pass
        return results

    # ------------------------------------------------------------------
    # MemoryBackend interface
    # ------------------------------------------------------------------

    async def store_failure(self, failure: FailureRecord) -> str:
        """Store a failure record in Redis hash + sorted set + secondary indexes."""
        try:
            client = await self._get_client()
            payload = self._serialize_failure(failure)
            key = self._failure_key(failure.id)

            pipe = client.pipeline()
            # Store the full JSON blob
            pipe.hset(key, "data", payload)
            pipe.hset(key, "error_hash", failure.signature.error_hash)
            pipe.hset(key, "error_type", failure.signature.error_type)
            pipe.hset(key, "error_category", failure.signature.error_category.value)
            pipe.hset(key, "error_message", failure.signature.error_message[:500])
            pipe.hset(key, "root_cause", failure.analysis.root_cause[:500])
            pipe.hset(key, "suggested_fix", failure.analysis.suggested_fix[:500])
            pipe.hset(key, "task_id", failure.task_id)
            # Store embedding vector as JSON for Python-side cosine similarity
            if failure.embedding:
                pipe.hset(key, "embedding", json.dumps(failure.embedding))
            # Store embedding as binary blob for RediSearch VECTOR field
            if failure.embedding and self._has_redisearch:
                # Pad or truncate to _EMBED_DIM for consistent index
                emb = failure.embedding
                if len(emb) < _EMBED_DIM:
                    emb = emb + [0.0] * (_EMBED_DIM - len(emb))
                elif len(emb) > _EMBED_DIM:
                    emb = emb[:_EMBED_DIM]
                vec_blob = struct.pack(f"{_EMBED_DIM}f", *emb)
                pipe.hset(key, "embedding_blob", vec_blob)
            # Add to the per-task sorted set, scored by timestamp
            score = failure.timestamp.timestamp()
            pipe.zadd(self._task_failures_key(failure.task_id), {failure.id: score})
            # Global failures index for iteration
            pipe.zadd("failures:all", {failure.id: score})
            # Secondary indexes: sets keyed by error_type and error_category
            pipe.sadd(
                f"idx:error_type:{failure.signature.error_type}",
                failure.id,
            )
            pipe.sadd(
                f"idx:error_category:{failure.signature.error_category.value}",
                failure.id,
            )
            pipe.sadd(
                f"idx:error_hash:{failure.signature.error_hash}",
                failure.id,
            )
            await pipe.execute()

            # Index in native vector set for O(log N) similarity search
            if self._has_vset and failure.embedding:
                try:
                    vec_bin = struct.pack(f"{len(failure.embedding)}f", *failure.embedding)
                    await client.execute_command(
                        "VADD",
                        self._vset_key,
                        "FP32",
                        vec_bin,
                        failure.id,
                    )
                except Exception as vset_exc:
                    logger.debug("VADD failed for %s: %s", failure.id, vset_exc)
            logger.debug("Stored failure %s", failure.id)
        except Exception as exc:
            logger.warning("store_failure failed: %s", exc)
        return failure.id

    async def store_success(self, success: SuccessRecord) -> str:
        """Store a success record."""
        try:
            client = await self._get_client()
            payload = self._serialize_success(success)
            key = self._success_key(success.id)
            score = success.timestamp.timestamp()

            pipe = client.pipeline()
            pipe.hset(key, "data", payload)
            pipe.hset(key, "task_id", success.task_id)
            pipe.zadd(self._task_successes_key(success.task_id), {success.id: score})
            pipe.zadd("successes:all", {success.id: score})
            await pipe.execute()
            logger.debug("Stored success %s", success.id)
        except Exception as exc:
            logger.warning("store_success failed: %s", exc)
        return success.id

    async def get_similar_failures(
        self,
        error_type: str,
        error_message: str,
        limit: int = 5,
        embedding: list[float] | None = None,
    ) -> list[FailureRecord]:
        """Find failures with similar error signatures.

        Strategy (in order of preference):
        1. VSIM -- Redis 8.6+ native vector similarity (O(log N), server-side)
        2. FT.SEARCH KNN -- RediSearch vector similarity (server-side, HNSW)
        3. Sorted-set + pipelined cosine -- batch-fetch from failures:all (no SCAN)
        4. Secondary index lookup -- exact error_hash match via idx:error_hash:*
        5. Secondary index lookup -- error_type match via idx:error_type:*
        """
        try:
            client = await self._get_client()
            import hashlib

            exact_hash = hashlib.sha256(
                f"{error_type}:{error_message}".encode()
            ).hexdigest()[:16]

            results: list[FailureRecord] = []

            # --- 1. Native VSIM (Redis 8.6+ vector sets) ---
            if embedding and self._has_vset:
                try:
                    vec_bin = struct.pack(f"{len(embedding)}f", *embedding)
                    raw = await client.execute_command(
                        "VSIM",
                        self._vset_key,
                        "FP32",
                        vec_bin,
                        "COUNT",
                        limit,
                    )
                    failure_ids = self._parse_vsim_result(raw)
                    results = await self._batch_get_failures(client, failure_ids)
                    if results:
                        logger.debug(
                            "VSIM returned %d results for error_type=%r",
                            len(results),
                            error_type,
                        )
                        return results
                except Exception as vsim_exc:
                    logger.debug("VSIM search failed, falling back: %s", vsim_exc)

            # --- 2. RediSearch FT.SEARCH KNN vector similarity ---
            if embedding and self._has_redisearch:
                try:
                    results = await self._ft_vector_search(client, embedding, limit)
                    if results:
                        logger.debug(
                            "FT.SEARCH KNN returned %d results for error_type=%r",
                            len(results),
                            error_type,
                        )
                        return results
                except Exception as ft_exc:
                    logger.debug("FT.SEARCH KNN failed, falling back: %s", ft_exc)

            # --- 3. Sorted-set + pipelined cosine similarity (no SCAN) ---
            if embedding:
                # Get all failure IDs from the global sorted set (ordered by timestamp)
                all_ids = await client.zrevrange("failures:all", 0, -1)
                if all_ids:
                    # Batch-fetch embeddings in one pipeline round-trip
                    id_emb_pairs = await self._batch_get_embeddings(client, all_ids)
                    scored: list[tuple[float, str]] = []
                    for fid, stored_emb in id_emb_pairs:
                        if stored_emb:
                            sim = self._cosine_similarity(embedding, stored_emb)
                            scored.append((sim, fid))
                    if scored:
                        scored.sort(key=lambda x: x[0], reverse=True)
                        top_ids = [fid for _, fid in scored[:limit]]
                        results = await self._batch_get_failures(client, top_ids)
                        if results:
                            logger.debug(
                                "Pipelined cosine returned %d results for error_type=%r",
                                len(results),
                                error_type,
                            )
                            return results

            # --- 4. Exact error_hash match via secondary index (no SCAN) ---
            hash_ids = await client.smembers(f"idx:error_hash:{exact_hash}")
            if hash_ids:
                hash_id_list = list(hash_ids)[:limit]
                results = await self._batch_get_failures(client, hash_id_list)
                if results:
                    return results

            # --- 5. error_type match via secondary index (no SCAN) ---
            type_ids = await client.smembers(f"idx:error_type:{error_type}")
            if type_ids:
                type_id_list = list(type_ids)[:limit]
                results = await self._batch_get_failures(client, type_id_list)
                # Sort by timestamp desc, most recent first
                results.sort(key=lambda r: r.timestamp, reverse=True)
                return results[:limit]

            return []

        except Exception as exc:
            logger.warning("get_similar_failures failed: %s", exc)
            return []

    async def search(
        self,
        query: str,
        limit: int = 5,
        filters: dict[str, Any] | None = None,
    ) -> list[FailureRecord]:
        """Text search across failure records.

        Strategy:
        1. RediSearch FT.SEARCH -- full-text search with TAG filters (server-side)
        2. Sorted-set + pipelined substring match (no SCAN)
        """
        try:
            client = await self._get_client()

            # --- 1. RediSearch full-text search ---
            if self._has_redisearch:
                try:
                    results = await self._ft_text_search(
                        client, query, limit, filters
                    )
                    if results:
                        logger.debug(
                            "FT.SEARCH text returned %d results for query=%r",
                            len(results),
                            query,
                        )
                        return results
                except Exception as ft_exc:
                    logger.debug("FT.SEARCH text failed, falling back: %s", ft_exc)

            # --- 2. Sorted-set iteration with pipelined fetch (no SCAN) ---
            query_lower = query.lower()
            all_ids = await client.zrevrange("failures:all", 0, -1)
            if not all_ids:
                return []

            # Batch-fetch all data in one pipeline
            records = await self._batch_get_failures(client, all_ids)
            results: list[FailureRecord] = []
            for record in records:
                # Match against searchable fields
                searchable = " ".join(
                    [
                        record.analysis.root_cause,
                        record.signature.error_message,
                        record.analysis.suggested_fix,
                        record.analysis.why_it_failed,
                        record.analysis.what_was_tried,
                        record.signature.error_type,
                    ]
                ).lower()

                if query_lower in searchable:
                    # Apply optional filters
                    if filters:
                        if "error_category" in filters:
                            if (
                                record.signature.error_category.value
                                != filters["error_category"]
                            ):
                                continue
                        if "error_type" in filters:
                            if record.signature.error_type != filters["error_type"]:
                                continue
                    results.append(record)
                    if len(results) >= limit:
                        break

            return results

        except Exception as exc:
            logger.warning("search failed: %s", exc)
            return []

    async def get_failure(self, failure_id: str) -> FailureRecord | None:
        """Direct hash lookup by ID."""
        try:
            client = await self._get_client()
            raw = await client.hget(self._failure_key(failure_id), "data")
            if raw:
                return self._deserialize_failure(raw)
        except Exception as exc:
            logger.warning("get_failure(%s) failed: %s", failure_id, exc)
        return None

    async def get_failures_for_task(self, task_id: str) -> list[FailureRecord]:
        """Range query on the per-task sorted set with pipelined fetch."""
        try:
            client = await self._get_client()
            # All members, sorted ascending by score (timestamp)
            ids = await client.zrange(self._task_failures_key(task_id), 0, -1)
            return await self._batch_get_failures(client, ids)
        except Exception as exc:
            logger.warning("get_failures_for_task(%s) failed: %s", task_id, exc)
            return []

    async def get_stats(self) -> MemoryStatsResponse:
        """Aggregate counts and metrics across all stored records.

        Uses sorted-set + pipelined batch fetch instead of SCAN.
        """
        try:
            client = await self._get_client()

            total_failures = await client.zcard("failures:all")
            total_successes = await client.zcard("successes:all")

            # Batch-fetch category and confidence from all failures via pipeline
            all_ids = await client.zrevrange("failures:all", 0, -1)

            category_counts: dict[str, int] = {}
            confidence_sum = 0.0
            confidence_count = 0

            if all_ids:
                # Pipeline: fetch error_category and data for each failure
                pipe = client.pipeline()
                for fid in all_ids:
                    pipe.hget(self._failure_key(fid), "error_category")
                    pipe.hget(self._failure_key(fid), "data")
                raw_results = await pipe.execute()

                # raw_results alternates: [cat1, data1, cat2, data2, ...]
                for i in range(0, len(raw_results), 2):
                    cat = raw_results[i]
                    raw_data = raw_results[i + 1] if i + 1 < len(raw_results) else None
                    if cat:
                        category_counts[cat] = category_counts.get(cat, 0) + 1
                    if raw_data:
                        record = self._deserialize_failure(raw_data)
                        if record:
                            confidence_sum += record.analysis.confidence
                            confidence_count += 1

            avg_confidence = (
                confidence_sum / confidence_count if confidence_count else 0.0
            )
            # Top-5 by count
            top_categories = dict(
                sorted(category_counts.items(), key=lambda x: x[1], reverse=True)[:5]
            )

            return MemoryStatsResponse(
                total_failures=total_failures,
                total_successes=total_successes,
                top_error_categories=top_categories,
                avg_confidence=avg_confidence,
            )

        except Exception as exc:
            logger.warning("get_stats failed: %s", exc)
            return MemoryStatsResponse(
                total_failures=0,
                total_successes=0,
                top_error_categories={},
                avg_confidence=0.0,
            )

    async def clear(self) -> None:
        """Delete all failure, success, and index keys."""
        try:
            client = await self._get_client()
            keys_to_delete: list[str] = []

            # Gather failure keys from the global sorted set (no SCAN needed)
            failure_ids = await client.zrange("failures:all", 0, -1)
            for fid in failure_ids:
                keys_to_delete.append(self._failure_key(fid))

            # Gather success keys from the global sorted set
            success_ids = await client.zrange("successes:all", 0, -1)
            for sid in success_ids:
                keys_to_delete.append(self._success_key(sid))

            # Gather secondary index keys via SCAN (only idx:* keys, not data keys)
            cursor = 0
            while True:
                cursor, keys = await client.scan(
                    cursor, match="idx:*", count=200
                )
                keys_to_delete.extend(keys)
                if cursor == 0:
                    break

            # Gather task sorted set keys via SCAN
            cursor = 0
            while True:
                cursor, keys = await client.scan(
                    cursor, match="task:*:failures", count=200
                )
                keys_to_delete.extend(keys)
                if cursor == 0:
                    break
            cursor = 0
            while True:
                cursor, keys = await client.scan(
                    cursor, match="task:*:successes", count=200
                )
                keys_to_delete.extend(keys)
                if cursor == 0:
                    break

            extra = ["failures:all", "successes:all", self._vset_key]
            keys_to_delete.extend(extra)

            if keys_to_delete:
                await client.delete(*keys_to_delete)

            # Drop FT index if it exists
            if self._has_redisearch:
                try:
                    await client.execute_command(
                        "FT.DROPINDEX", self._index_name, "DD"
                    )
                    self._ft_index_created = False
                except Exception:
                    pass

            logger.info("Cleared %d Redis keys", len(keys_to_delete))
        except Exception as exc:
            logger.warning("clear failed: %s", exc)
