"""SQLite Memory Backend — local dev backend for ReLoop failure memory.

Uses aiosqlite for async SQLite operations. No external services required.
Ideal for testing and local development without a Redis instance.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from src.models import (
    FailureRecord,
    MemoryStatsResponse,
    SuccessRecord,
)
from src.providers.base import MemoryBackend

logger = logging.getLogger(__name__)

_CREATE_FAILURES_TABLE = """
CREATE TABLE IF NOT EXISTS failures (
    id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL,
    attempt_number INTEGER NOT NULL,
    timestamp TEXT NOT NULL,
    error_type TEXT NOT NULL,
    error_category TEXT NOT NULL,
    error_message TEXT NOT NULL,
    error_hash TEXT NOT NULL,
    code_context TEXT NOT NULL DEFAULT '',
    root_cause TEXT NOT NULL DEFAULT '',
    what_was_tried TEXT NOT NULL DEFAULT '',
    why_it_failed TEXT NOT NULL DEFAULT '',
    suggested_fix TEXT NOT NULL DEFAULT '',
    anti_pattern TEXT NOT NULL DEFAULT '',
    confidence REAL NOT NULL DEFAULT 0.8,
    topics TEXT NOT NULL DEFAULT '[]',
    cost_usd REAL NOT NULL DEFAULT 0.0,
    embedding TEXT NOT NULL DEFAULT '',
    data TEXT NOT NULL
);
"""

_CREATE_SUCCESSES_TABLE = """
CREATE TABLE IF NOT EXISTS successes (
    id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL,
    attempt_number INTEGER NOT NULL,
    timestamp TEXT NOT NULL,
    data TEXT NOT NULL
);
"""

_CREATE_FAILURES_IDX_TASK = (
    "CREATE INDEX IF NOT EXISTS idx_failures_task_id ON failures (task_id);"
)
_CREATE_FAILURES_IDX_HASH = (
    "CREATE INDEX IF NOT EXISTS idx_failures_error_hash ON failures (error_hash);"
)
_CREATE_FAILURES_IDX_CATEGORY = (
    "CREATE INDEX IF NOT EXISTS idx_failures_error_category ON failures (error_category);"
)


class SQLiteMemoryBackend(MemoryBackend):
    """Local SQLite-backed memory store using aiosqlite."""

    def __init__(self, db_path: str | None = None) -> None:
        self._db_path = db_path or "reloop_memory.db"
        self._conn: Any = None  # aiosqlite.Connection

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _get_conn(self) -> Any:
        """Lazily open the SQLite connection and initialise schema."""
        if self._conn is None:
            try:
                import aiosqlite  # type: ignore[import]

                # Ensure parent directory exists when using a path
                path = Path(self._db_path)
                if path.parent != Path("."):
                    path.parent.mkdir(parents=True, exist_ok=True)

                self._conn = await aiosqlite.connect(self._db_path)
                self._conn.row_factory = aiosqlite.Row
                await self._conn.execute("PRAGMA journal_mode=WAL;")
                await self._conn.execute("PRAGMA foreign_keys=ON;")
                await self._conn.execute(_CREATE_FAILURES_TABLE)
                await self._conn.execute(_CREATE_SUCCESSES_TABLE)
                await self._conn.execute(_CREATE_FAILURES_IDX_TASK)
                await self._conn.execute(_CREATE_FAILURES_IDX_HASH)
                await self._conn.execute(_CREATE_FAILURES_IDX_CATEGORY)
                await self._conn.commit()
            except Exception as exc:
                logger.error("Failed to open SQLite database %s: %s", self._db_path, exc)
                raise
        return self._conn

    def _deserialize_failure(self, raw: str) -> FailureRecord | None:
        try:
            return FailureRecord.model_validate(json.loads(raw))
        except Exception as exc:
            logger.warning("Failed to deserialise failure record: %s", exc)
            return None

    def _deserialize_success(self, raw: str) -> SuccessRecord | None:
        try:
            return SuccessRecord.model_validate(json.loads(raw))
        except Exception as exc:
            logger.warning("Failed to deserialise success record: %s", exc)
            return None

    @staticmethod
    def _cosine_similarity(a: list[float], b: list[float]) -> float:
        """Compute cosine similarity between two vectors.

        Uses numpy if available, otherwise falls back to pure-Python math.
        Returns a value in [-1, 1]; returns 0.0 if either vector is zero-length.
        """
        if not a or not b or len(a) != len(b):
            return 0.0
        try:
            import numpy as np  # type: ignore[import]

            va = np.array(a, dtype=float)
            vb = np.array(b, dtype=float)
            norm_a = float(np.linalg.norm(va))
            norm_b = float(np.linalg.norm(vb))
            if norm_a == 0.0 or norm_b == 0.0:
                return 0.0
            return float(np.dot(va, vb) / (norm_a * norm_b))
        except ImportError:
            import math

            dot = sum(x * y for x, y in zip(a, b))
            norm_a = math.sqrt(sum(x * x for x in a))
            norm_b = math.sqrt(sum(y * y for y in b))
            if norm_a == 0.0 or norm_b == 0.0:
                return 0.0
            return dot / (norm_a * norm_b)

    # ------------------------------------------------------------------
    # MemoryBackend interface
    # ------------------------------------------------------------------

    async def store_failure(self, failure: FailureRecord) -> str:
        """Upsert a failure record into the failures table."""
        try:
            conn = await self._get_conn()
            payload = failure.model_dump_json()
            embedding_json = json.dumps(failure.embedding) if failure.embedding else ""
            await conn.execute(
                """
                INSERT OR REPLACE INTO failures (
                    id, task_id, attempt_number, timestamp,
                    error_type, error_category, error_message, error_hash,
                    code_context, root_cause, what_was_tried, why_it_failed,
                    suggested_fix, anti_pattern, confidence,
                    topics, cost_usd, embedding, data
                ) VALUES (
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?,
                    ?, ?, ?, ?
                )
                """,
                (
                    failure.id,
                    failure.task_id,
                    failure.attempt_number,
                    failure.timestamp.isoformat(),
                    failure.signature.error_type,
                    failure.signature.error_category.value,
                    failure.signature.error_message,
                    failure.signature.error_hash,
                    failure.signature.code_context,
                    failure.analysis.root_cause,
                    failure.analysis.what_was_tried,
                    failure.analysis.why_it_failed,
                    failure.analysis.suggested_fix,
                    failure.analysis.anti_pattern,
                    failure.analysis.confidence,
                    json.dumps(failure.topics),
                    failure.cost_usd,
                    embedding_json,
                    payload,
                ),
            )
            await conn.commit()
            logger.debug("Stored failure %s in SQLite", failure.id)
        except Exception as exc:
            logger.warning("store_failure failed: %s", exc)
        return failure.id

    async def store_success(self, success: SuccessRecord) -> str:
        """Upsert a success record."""
        try:
            conn = await self._get_conn()
            payload = success.model_dump_json()
            await conn.execute(
                """
                INSERT OR REPLACE INTO successes (
                    id, task_id, attempt_number, timestamp, data
                ) VALUES (?, ?, ?, ?, ?)
                """,
                (
                    success.id,
                    success.task_id,
                    success.attempt_number,
                    success.timestamp.isoformat(),
                    payload,
                ),
            )
            await conn.commit()
            logger.debug("Stored success %s in SQLite", success.id)
        except Exception as exc:
            logger.warning("store_success failed: %s", exc)
        return success.id

    async def get_similar_failures(
        self,
        error_type: str,
        error_message: str,
        limit: int = 5,
        embedding: list[float] | None = None,
    ) -> list[FailureRecord]:
        """Find similar failures, using vector cosine similarity when an
        embedding is provided, otherwise falling back to LIKE queries.
        """
        try:
            conn = await self._get_conn()

            # 1. Vector search -- load embeddings and rank by cosine similarity
            #    Only return results above a minimum similarity threshold to
            #    avoid flooding the caller with irrelevant matches.
            _MIN_SIM = 0.1
            if embedding:
                cursor = await conn.execute(
                    "SELECT data, embedding FROM failures WHERE embedding != '' ORDER BY timestamp DESC"
                )
                rows = await cursor.fetchall()
                scored: list[tuple[float, FailureRecord]] = []
                for row in rows:
                    stored_emb_raw = row["embedding"]
                    if not stored_emb_raw:
                        continue
                    try:
                        stored_emb: list[float] = json.loads(stored_emb_raw)
                        sim = self._cosine_similarity(embedding, stored_emb)
                    except Exception:
                        continue
                    if sim < _MIN_SIM:
                        continue
                    record = self._deserialize_failure(row["data"])
                    if record:
                        scored.append((sim, record))

                if scored:
                    scored.sort(key=lambda x: x[0], reverse=True)
                    return [rec for _, rec in scored[:limit]]

            # 2. Exact match on error_hash
            import hashlib

            exact_hash = hashlib.sha256(
                f"{error_type}:{error_message}".encode()
            ).hexdigest()[:16]

            cursor = await conn.execute(
                "SELECT data FROM failures WHERE error_hash = ? ORDER BY timestamp DESC LIMIT ?",
                (exact_hash, limit),
            )
            rows = await cursor.fetchall()
            if rows:
                return [
                    r
                    for r in (self._deserialize_failure(row["data"]) for row in rows)
                    if r is not None
                ]

            # 3. Fallback: LIKE on error_type + partial error_message
            pattern = f"%{error_message[:100]}%"
            type_pattern = f"%{error_type}%"
            cursor = await conn.execute(
                """
                SELECT data FROM failures
                WHERE error_type LIKE ?
                   OR error_message LIKE ?
                ORDER BY timestamp DESC
                LIMIT ?
                """,
                (type_pattern, pattern, limit),
            )
            rows = await cursor.fetchall()
            return [
                r
                for r in (self._deserialize_failure(row["data"]) for row in rows)
                if r is not None
            ]
        except Exception as exc:
            logger.warning("get_similar_failures failed: %s", exc)
            return []

    async def search(
        self,
        query: str,
        limit: int = 5,
        filters: dict[str, Any] | None = None,
    ) -> list[FailureRecord]:
        """Full-text search using LIKE on multiple columns."""
        try:
            conn = await self._get_conn()
            pattern = f"%{query}%"

            # Build WHERE clause
            where_parts = [
                "(root_cause LIKE ? OR error_message LIKE ? OR suggested_fix LIKE ?)"
            ]
            params: list[Any] = [pattern, pattern, pattern]

            if filters:
                if "error_category" in filters:
                    where_parts.append("error_category = ?")
                    params.append(filters["error_category"])
                if "error_type" in filters:
                    where_parts.append("error_type = ?")
                    params.append(filters["error_type"])

            params.append(limit)
            where_sql = " AND ".join(where_parts)
            sql = f"""
                SELECT data FROM failures
                WHERE {where_sql}
                ORDER BY timestamp DESC
                LIMIT ?
            """
            cursor = await conn.execute(sql, params)
            rows = await cursor.fetchall()
            return [
                r
                for r in (self._deserialize_failure(row["data"]) for row in rows)
                if r is not None
            ]
        except Exception as exc:
            logger.warning("search failed: %s", exc)
            return []

    async def get_failure(self, failure_id: str) -> FailureRecord | None:
        """Direct PK lookup."""
        try:
            conn = await self._get_conn()
            cursor = await conn.execute(
                "SELECT data FROM failures WHERE id = ?", (failure_id,)
            )
            row = await cursor.fetchone()
            if row:
                return self._deserialize_failure(row["data"])
        except Exception as exc:
            logger.warning("get_failure(%s) failed: %s", failure_id, exc)
        return None

    async def get_failures_for_task(self, task_id: str) -> list[FailureRecord]:
        """All failures for a task ordered by timestamp."""
        try:
            conn = await self._get_conn()
            cursor = await conn.execute(
                "SELECT data FROM failures WHERE task_id = ? ORDER BY timestamp ASC",
                (task_id,),
            )
            rows = await cursor.fetchall()
            return [
                r
                for r in (self._deserialize_failure(row["data"]) for row in rows)
                if r is not None
            ]
        except Exception as exc:
            logger.warning("get_failures_for_task(%s) failed: %s", task_id, exc)
            return []

    async def get_stats(self) -> MemoryStatsResponse:
        """Aggregate statistics from SQLite."""
        try:
            conn = await self._get_conn()

            row = await (
                await conn.execute("SELECT COUNT(*) AS cnt FROM failures")
            ).fetchone()
            total_failures: int = row["cnt"] if row else 0

            row = await (
                await conn.execute("SELECT COUNT(*) AS cnt FROM successes")
            ).fetchone()
            total_successes: int = row["cnt"] if row else 0

            # Top error categories
            cursor = await conn.execute(
                """
                SELECT error_category, COUNT(*) AS cnt
                FROM failures
                GROUP BY error_category
                ORDER BY cnt DESC
                LIMIT 5
                """
            )
            rows = await cursor.fetchall()
            top_categories = {row["error_category"]: row["cnt"] for row in rows}

            # Average confidence
            row = await (
                await conn.execute("SELECT AVG(confidence) AS avg_conf FROM failures")
            ).fetchone()
            avg_confidence: float = float(row["avg_conf"]) if row and row["avg_conf"] is not None else 0.0

            return MemoryStatsResponse(
                total_failures=total_failures,
                total_successes=total_successes,
                top_error_categories=top_categories,
                avg_confidence=avg_confidence,
            )
        except Exception as exc:
            logger.warning("get_stats failed: %s", exc)
            return MemoryStatsResponse(
                total_failures=0,
                total_successes=0,
                top_error_categories={},
                avg_confidence=0.0,
            )

    async def clear(self) -> None:
        """Delete all rows from failures and successes tables."""
        try:
            conn = await self._get_conn()
            await conn.execute("DELETE FROM failures")
            await conn.execute("DELETE FROM successes")
            await conn.commit()
            logger.info("SQLite memory cleared")
        except Exception as exc:
            logger.warning("clear failed: %s", exc)
