"""Docker Sandbox Provider — local dev fallback for ReLoop.

Uses asyncio.create_subprocess_exec to drive Docker CLI commands.
No API keys required — works with any local Docker daemon.
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from typing import Any

from src.models import Checkpoint
from src.providers.base import ExecutionResult, SandboxProvider

logger = logging.getLogger(__name__)

_DEFAULT_IMAGE = "node:20-slim"


class DockerSandbox(SandboxProvider):
    """Local Docker sandbox provider using subprocess Docker CLI calls."""

    def __init__(self, image: str | None = None) -> None:
        self._image = image or _DEFAULT_IMAGE
        # Maps sandbox_id -> current container ID (may change on restore)
        self._containers: dict[str, str] = {}
        # sandbox_id -> list of checkpoint metadata dicts (mirrors BlaxelSandbox)
        self._checkpoints: dict[str, list[dict[str, Any]]] = {}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _run_cmd(self, *args: str, timeout: float = 60.0) -> tuple[int, str, str]:
        """Run a docker CLI command, returning (exit_code, stdout, stderr)."""
        try:
            proc = await asyncio.create_subprocess_exec(
                *args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(), timeout=timeout
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.communicate()
                return (1, "", f"Command timed out after {timeout}s: {' '.join(args)}")

            exit_code = proc.returncode if proc.returncode is not None else 1
            return (
                exit_code,
                stdout_bytes.decode("utf-8", errors="replace").strip(),
                stderr_bytes.decode("utf-8", errors="replace").strip(),
            )
        except FileNotFoundError:
            return (1, "", "docker CLI not found — is Docker installed?")
        except Exception as exc:
            return (1, "", str(exc))

    def _container_for(self, sandbox_id: str) -> str | None:
        return self._containers.get(sandbox_id)

    def _task_image_prefix(self, sandbox_id: str) -> str:
        """Deterministic image tag prefix for checkpoints of a sandbox."""
        return f"reloop-checkpoint-{sandbox_id}"

    # ------------------------------------------------------------------
    # SandboxProvider interface
    # ------------------------------------------------------------------

    async def create(self, config: dict[str, Any] | None = None) -> str:
        """Run a detached container and return a logical sandbox_id."""
        image = (config or {}).get("image", self._image)
        sandbox_id = uuid.uuid4().hex[:12]

        exit_code, container_id, stderr = await self._run_cmd(
            "docker", "run", "-d", "--rm",
            "--name", f"reloop-{sandbox_id}",
            # Keep the container alive waiting for commands
            image,
            "tail", "-f", "/dev/null",
            timeout=60.0,
        )
        if exit_code != 0:
            logger.error("docker run failed: %s", stderr)
            raise RuntimeError(f"docker run failed: {stderr}")

        # container_id is the full 64-char SHA; store just the short form
        cid = container_id[:12] if container_id else f"reloop-{sandbox_id}"
        self._containers[sandbox_id] = f"reloop-{sandbox_id}"
        self._checkpoints[sandbox_id] = []
        logger.info("Created Docker sandbox %s -> container %s", sandbox_id, cid)
        return sandbox_id

    async def execute(
        self,
        sandbox_id: str,
        command: str,
        timeout: int = 120,
    ) -> ExecutionResult:
        """docker exec the command inside the sandbox container."""
        container = self._container_for(sandbox_id)
        if not container:
            return ExecutionResult(
                exit_code=1,
                stdout="",
                stderr=f"No container for sandbox {sandbox_id}",
                duration_ms=0,
            )

        start_ms = int(time.monotonic() * 1000)
        exit_code, stdout, stderr = await self._run_cmd(
            "docker", "exec", container,
            "sh", "-c", command,
            timeout=float(timeout),
        )
        duration_ms = int(time.monotonic() * 1000) - start_ms
        logger.debug(
            "exec in %s (exit %d): %s", container, exit_code, command[:80]
        )
        return ExecutionResult(
            exit_code=exit_code,
            stdout=stdout,
            stderr=stderr,
            duration_ms=duration_ms,
        )

    async def checkpoint(self, sandbox_id: str) -> str:
        """docker commit current container to create an image snapshot."""
        container = self._container_for(sandbox_id)
        if not container:
            raise RuntimeError(f"No container for sandbox {sandbox_id}")

        checkpoint_id = uuid.uuid4().hex[:8]
        image_tag = f"{self._task_image_prefix(sandbox_id)}:{checkpoint_id}"

        exit_code, image_id, stderr = await self._run_cmd(
            "docker", "commit", container, image_tag,
            timeout=60.0,
        )
        if exit_code != 0:
            raise RuntimeError(f"docker commit failed: {stderr}")

        # Track checkpoint metadata locally for consistent list_checkpoints()
        self._checkpoints.setdefault(sandbox_id, []).append({
            "id": checkpoint_id,
            "sandbox_id": sandbox_id,
            "timestamp": time.time(),
            "image_tag": image_tag,
            "image_id": image_id,
            "restore_ms": None,
        })

        logger.info(
            "Checkpoint %s for sandbox %s -> image %s", checkpoint_id, sandbox_id, image_tag
        )
        return checkpoint_id

    async def restore(self, sandbox_id: str, checkpoint_id: str) -> None:
        """Stop current container and start a new one from the checkpoint image."""
        old_container = self._container_for(sandbox_id)
        image_tag = f"{self._task_image_prefix(sandbox_id)}:{checkpoint_id}"

        # Find the checkpoint metadata
        ckpt_list = self._checkpoints.get(sandbox_id, [])
        ckpt_meta = next((c for c in ckpt_list if c["id"] == checkpoint_id), None)
        if ckpt_meta is None:
            raise ValueError(
                f"Checkpoint '{checkpoint_id}' not found for sandbox '{sandbox_id}'"
            )

        restore_start_ms = int(time.monotonic() * 1000)

        # Stop old container if it exists
        if old_container:
            await self._run_cmd("docker", "rm", "-f", old_container, timeout=30.0)

        new_container_name = f"reloop-{sandbox_id}"
        exit_code, container_id, stderr = await self._run_cmd(
            "docker", "run", "-d", "--rm",
            "--name", new_container_name,
            image_tag,
            "tail", "-f", "/dev/null",
            timeout=60.0,
        )
        if exit_code != 0:
            raise RuntimeError(
                f"docker run from checkpoint {checkpoint_id} failed: {stderr}"
            )

        restore_ms = int(time.monotonic() * 1000) - restore_start_ms
        ckpt_meta["restore_ms"] = restore_ms

        self._containers[sandbox_id] = new_container_name
        logger.info(
            "Restored sandbox %s to checkpoint %s in %dms",
            sandbox_id, checkpoint_id, restore_ms,
        )

    async def destroy(self, sandbox_id: str) -> None:
        """docker rm -f the sandbox container."""
        container = self._container_for(sandbox_id)
        if not container:
            logger.debug("destroy: no container for sandbox %s", sandbox_id)
            return

        exit_code, _, stderr = await self._run_cmd(
            "docker", "rm", "-f", container, timeout=30.0
        )
        if exit_code != 0:
            logger.warning("docker rm -f %s failed: %s", container, stderr)

        self._containers.pop(sandbox_id, None)
        self._checkpoints.pop(sandbox_id, None)
        logger.info("Destroyed sandbox %s (container %s)", sandbox_id, container)

    async def list_checkpoints(self, sandbox_id: str) -> list[Checkpoint]:
        """Return checkpoints for a sandbox.

        Uses locally tracked metadata first (populated by checkpoint()).
        Falls back to querying docker images if no local metadata exists.
        """
        # Prefer local metadata — it has timing info and correct ordering
        items = self._checkpoints.get(sandbox_id, [])
        if items:
            result = []
            for idx, item in enumerate(items):
                restore_ms = item.get("restore_ms")
                if restore_ms is not None:
                    description = (
                        f"Docker checkpoint at {item.get('timestamp', 0):.0f} "
                        f"(last restored in {restore_ms}ms)"
                    )
                else:
                    description = f"Docker checkpoint at {item.get('timestamp', 0):.0f}"

                snapshot_data: dict[str, Any] = {"type": "docker"}
                if restore_ms is not None:
                    snapshot_data["restore_ms"] = restore_ms

                result.append(
                    Checkpoint(
                        id=item["id"],
                        task_id=sandbox_id,
                        attempt_number=idx,
                        sandbox_snapshot_id=item.get("image_id", item["id"]),
                        working_memory_snapshot=snapshot_data,
                        description=description,
                        reversible=True,
                    )
                )
            return result

        # Fallback: query docker images directly
        prefix = self._task_image_prefix(sandbox_id)
        exit_code, stdout, stderr = await self._run_cmd(
            "docker", "images",
            "--format", "{{.Repository}}:{{.Tag}}\t{{.ID}}\t{{.CreatedAt}}",
            "--filter", f"reference={prefix}:*",
            timeout=30.0,
        )
        if exit_code != 0:
            logger.warning("docker images failed: %s", stderr)
            return []

        checkpoints: list[Checkpoint] = []
        for idx, line in enumerate(stdout.splitlines()):
            line = line.strip()
            if not line:
                continue
            parts = line.split("\t")
            ref = parts[0] if parts else ""
            # Extract checkpoint_id from tag portion: prefix:checkpoint_id
            tag_part = ref.split(":", 1)[1] if ":" in ref else ref
            cp = Checkpoint(
                id=tag_part,
                task_id=sandbox_id,
                attempt_number=idx,
                sandbox_snapshot_id=parts[1] if len(parts) > 1 else "",
                description=f"Docker commit from {sandbox_id}",
                reversible=True,
            )
            checkpoints.append(cp)

        return checkpoints
