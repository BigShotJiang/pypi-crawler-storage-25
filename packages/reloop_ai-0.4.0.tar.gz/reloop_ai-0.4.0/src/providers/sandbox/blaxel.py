"""Blaxel Sandbox Provider — primary execution backend for ReLoop.

Uses the official Blaxel Python SDK (`blaxel.core.SandboxInstance`).
Sandboxes are Firecracker microVMs that scale to zero and resume from
standby in <25ms.

Install: pip install blaxel
Auth:    BL_API_KEY + BL_WORKSPACE env vars, or bl login
Docs:    https://docs.blaxel.ai/Get-started
SDK:     https://github.com/blaxel-ai/sdk-python

Checkpoint strategy (remote — Blaxel SDK available):
  - checkpoint(): tar /app into /tmp/reloop-checkpoints/<id>.tar.gz inside
    the sandbox, then write a JSON manifest alongside it.  This captures
    real file-system state, not just a marker.
  - restore(): kill running user processes, wipe /app, and extract the
    saved tar back to /.  Timing is recorded so the UI can show
    "restored in Xms".

Checkpoint strategy (local fallback — no Blaxel SDK):
  - checkpoint(): snapshot the working directory into a host-side tar
    archive under _LOCAL_CKPT_DIR, plus a JSON manifest capturing env
    vars and command history.
  - restore(): extract the tar archive back to the working directory,
    reload env vars, and return the restored state.  This makes
    checkpoint/restore functional for demos even without Blaxel.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import tarfile
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any

from src.config import settings
from src.models import Checkpoint
from src.providers.base import ExecutionResult, SandboxProvider

logger = logging.getLogger(__name__)

# Checkpoint directory inside every sandbox (remote Blaxel microVM)
_CKPT_DIR = "/tmp/reloop-checkpoints"

# Host-side checkpoint directory for the local fallback path
_LOCAL_CKPT_DIR = Path(tempfile.gettempdir()) / "reloop-local-checkpoints"

# Lazy import — blaxel may not be installed (Python 3.10-3.13 only)
_SandboxInstance = None


def _get_sandbox_class():
    """Lazy-load blaxel.core.SandboxInstance."""
    global _SandboxInstance
    if _SandboxInstance is None:
        from blaxel.core import SandboxInstance
        _SandboxInstance = SandboxInstance
    return _SandboxInstance


def _ensure_local_ckpt_dir() -> Path:
    """Create the host-side checkpoint directory if it doesn't exist."""
    _LOCAL_CKPT_DIR.mkdir(parents=True, exist_ok=True)
    return _LOCAL_CKPT_DIR


class BlaxelSandbox(SandboxProvider):
    """Blaxel Firecracker microVM sandbox provider.

    Uses SandboxInstance from the official blaxel SDK for:
    - sandbox.process.exec() -- command execution
    - sandbox.fs.read/write -- file operations

    When the Blaxel SDK is not available or the sandbox is not connected,
    falls back to host-filesystem snapshots so checkpoint/restore works
    for local development and demo scenarios.
    """

    def __init__(
        self,
        api_key: str | None = None,
        workspace: str | None = None,
    ) -> None:
        self._api_key = api_key or settings.blaxel_api_key
        self._workspace = workspace or settings.blaxel_workspace

        # Blaxel SDK reads BL_API_KEY / BL_WORKSPACE from os.environ at
        # import time. Pydantic-settings loads .env into its own fields but
        # does NOT export to os.environ, so the SDK sees nothing. Fix this
        # by injecting the values into the environment.
        if self._api_key:
            os.environ.setdefault("BL_API_KEY", self._api_key)
        if self._workspace:
            os.environ.setdefault("BL_WORKSPACE", self._workspace)

        # sandbox_id -> SandboxInstance mapping (None = local-only sandbox)
        self._sandboxes: dict[str, Any] = {}
        # sandbox_id -> list of checkpoint metadata dicts
        self._checkpoints: dict[str, list[dict[str, Any]]] = {}
        # sandbox_id -> working directory path (local fallback)
        self._working_dirs: dict[str, str] = {}
        # sandbox_id -> list of commands executed (local fallback history)
        self._command_history: dict[str, list[str]] = {}
        # sandbox_id -> dict of env vars captured during execution
        self._env_snapshots: dict[str, dict[str, str]] = {}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _is_remote(self, sandbox_id: str) -> bool:
        """True when a real Blaxel SandboxInstance is backing this sandbox."""
        sb = self._sandboxes.get(sandbox_id)
        return sb is not None and sb is not _SENTINEL_LOCAL

    # ------------------------------------------------------------------
    # SandboxProvider interface
    # ------------------------------------------------------------------

    async def create(self, config: dict[str, Any] | None = None) -> str:
        """Create a new sandbox.

        Tries the Blaxel SDK first. If the SDK is not installed or auth
        fails, falls back to a local working directory so the rest of the
        provider (execute, checkpoint, restore) still works.
        """
        sandbox_name = f"reloop-{uuid.uuid4().hex[:8]}"

        # --- Try remote Blaxel sandbox first ---
        try:
            SandboxInstance = _get_sandbox_class()
            sandbox_config = {
                "name": sandbox_name,
                "image": "blaxel/base-image:latest",
                "memory": 4096,
                "ports": [{"target": 3000, "protocol": "HTTP"}],
                "labels": {"project": "reloop", "type": "rejd-sandbox"},
            }
            if config:
                sandbox_config.update(config)

            sandbox = await SandboxInstance.create_if_not_exists(sandbox_config)
            self._sandboxes[sandbox_name] = sandbox
            self._checkpoints[sandbox_name] = []
            logger.info("Created Blaxel sandbox (remote): %s", sandbox_name)
            return sandbox_name

        except Exception as exc:
            logger.warning(
                "Blaxel SDK unavailable (%s); falling back to local sandbox for %s",
                exc, sandbox_name,
            )

        # --- Local fallback: create a temp working directory ---
        work_dir = Path(tempfile.mkdtemp(prefix=f"reloop-{sandbox_name}-"))
        # If user passed a project path to seed the sandbox, copy it in
        seed_path = (config or {}).get("seed_path")
        if seed_path and Path(seed_path).is_dir():
            shutil.copytree(seed_path, work_dir, dirs_exist_ok=True)

        self._sandboxes[sandbox_name] = _SENTINEL_LOCAL
        self._working_dirs[sandbox_name] = str(work_dir)
        self._checkpoints[sandbox_name] = []
        self._command_history[sandbox_name] = []
        self._env_snapshots[sandbox_name] = {}
        logger.info(
            "Created local sandbox: %s (workdir: %s)", sandbox_name, work_dir,
        )
        return sandbox_name

    async def execute(
        self,
        sandbox_id: str,
        command: str,
        timeout: int = 120,
    ) -> ExecutionResult:
        """Execute a command in the sandbox.

        Remote: uses sandbox.process.exec().
        Local:  runs the command via asyncio subprocess in the working dir.
        """
        if sandbox_id not in self._sandboxes:
            return ExecutionResult(
                exit_code=1,
                stdout="",
                stderr=f"Sandbox '{sandbox_id}' not found",
                duration_ms=0,
            )

        if self._is_remote(sandbox_id):
            return await self._execute_remote(sandbox_id, command, timeout)
        return await self._execute_local(sandbox_id, command, timeout)

    # --- Remote execute (Blaxel SDK) ---

    async def _execute_remote(
        self, sandbox_id: str, command: str, timeout: int,
    ) -> ExecutionResult:
        sandbox = self._sandboxes[sandbox_id]
        start_ms = int(time.monotonic() * 1000)
        try:
            process = await sandbox.process.exec({
                "name": f"cmd-{uuid.uuid4().hex[:6]}",
                "command": command,
                "working_dir": "/app",
                "wait_for_completion": True,
                "timeout": timeout * 1000,  # SDK uses milliseconds
            })

            duration_ms = int(time.monotonic() * 1000) - start_ms

            exit_code = getattr(process, "exit_code", 0) or 0
            stdout = getattr(process, "stdout", "") or ""
            stderr = getattr(process, "stderr", "") or ""

            if hasattr(process, "output"):
                stdout = process.output or stdout
            if hasattr(process, "logs"):
                stdout = stdout or (process.logs or "")

            return ExecutionResult(
                exit_code=int(exit_code),
                stdout=str(stdout),
                stderr=str(stderr),
                duration_ms=duration_ms,
            )

        except Exception as exc:
            duration_ms = int(time.monotonic() * 1000) - start_ms
            logger.error("execute failed on sandbox %s: %s", sandbox_id, exc)
            return ExecutionResult(
                exit_code=1, stdout="", stderr=str(exc), duration_ms=duration_ms,
            )

    # --- Local execute (subprocess) ---

    async def _execute_local(
        self, sandbox_id: str, command: str, timeout: int,
    ) -> ExecutionResult:
        work_dir = self._working_dirs.get(sandbox_id, "/tmp")
        env = {**os.environ, **self._env_snapshots.get(sandbox_id, {})}
        start_ms = int(time.monotonic() * 1000)

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=work_dir,
                env=env,
            )
            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(), timeout=float(timeout),
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.communicate()
                duration_ms = int(time.monotonic() * 1000) - start_ms
                return ExecutionResult(
                    exit_code=1,
                    stdout="",
                    stderr=f"Command timed out after {timeout}s",
                    duration_ms=duration_ms,
                )

            duration_ms = int(time.monotonic() * 1000) - start_ms
            exit_code = proc.returncode if proc.returncode is not None else 1

            result = ExecutionResult(
                exit_code=exit_code,
                stdout=stdout_bytes.decode("utf-8", errors="replace"),
                stderr=stderr_bytes.decode("utf-8", errors="replace"),
                duration_ms=duration_ms,
            )

            # Track command history for checkpoint metadata
            self._command_history.setdefault(sandbox_id, []).append(command)

            return result

        except Exception as exc:
            duration_ms = int(time.monotonic() * 1000) - start_ms
            logger.error("local execute failed for sandbox %s: %s", sandbox_id, exc)
            return ExecutionResult(
                exit_code=1, stdout="", stderr=str(exc), duration_ms=duration_ms,
            )

    # ------------------------------------------------------------------
    # Checkpoint — remote (Blaxel SDK)
    # ------------------------------------------------------------------

    async def checkpoint(self, sandbox_id: str) -> str:
        """Create a checkpoint of the sandbox state.

        Remote: tar /app inside the Blaxel microVM.
        Local:  tar the working directory on the host filesystem.

        Returns the checkpoint ID.
        """
        if sandbox_id not in self._sandboxes:
            raise ValueError(f"Sandbox '{sandbox_id}' not found")

        if self._is_remote(sandbox_id):
            return await self._checkpoint_remote(sandbox_id)
        return await self._checkpoint_local(sandbox_id)

    async def _checkpoint_remote(self, sandbox_id: str) -> str:
        """Capture a real filesystem checkpoint of /app inside the Blaxel sandbox."""
        sandbox = self._sandboxes[sandbox_id]
        checkpoint_id = f"ckpt-{uuid.uuid4().hex[:8]}"
        tar_path = f"{_CKPT_DIR}/{checkpoint_id}.tar.gz"
        manifest_path = f"{_CKPT_DIR}/{checkpoint_id}.json"
        ts = time.time()

        try:
            # 1. Ensure checkpoint directory exists
            await sandbox.process.exec({
                "name": f"ckpt-mkdir-{checkpoint_id}",
                "command": f"mkdir -p {_CKPT_DIR}",
                "working_dir": "/",
                "wait_for_completion": True,
                "timeout": 10_000,
            })

            # 2. Tar the /app directory
            tar_cmd = (
                f"tar -czf {tar_path} "
                f"--exclude={_CKPT_DIR} "
                "-C / app"
            )
            tar_proc = await sandbox.process.exec({
                "name": f"ckpt-tar-{checkpoint_id}",
                "command": tar_cmd,
                "working_dir": "/",
                "wait_for_completion": True,
                "timeout": 60_000,
            })
            tar_exit = getattr(tar_proc, "exit_code", 0) or 0
            if int(tar_exit) != 0:
                tar_stderr = getattr(tar_proc, "stderr", "") or ""
                raise RuntimeError(
                    f"tar failed (exit {tar_exit}): {tar_stderr}"
                )

            # 3. Write JSON manifest for integrity checks
            manifest = json.dumps({
                "checkpoint_id": checkpoint_id,
                "sandbox_id": sandbox_id,
                "timestamp": ts,
                "tar_path": tar_path,
            })
            await sandbox.fs.write(manifest_path, manifest)

            logger.info(
                "Checkpoint %s created for sandbox %s (archive: %s)",
                checkpoint_id, sandbox_id, tar_path,
            )
        except Exception as exc:
            logger.error(
                "Failed to create remote checkpoint %s for sandbox %s: %s",
                checkpoint_id, sandbox_id, exc,
            )
            raise

        self._checkpoints.setdefault(sandbox_id, []).append({
            "id": checkpoint_id,
            "sandbox_id": sandbox_id,
            "timestamp": ts,
            "tar_path": tar_path,
            "local": False,
            "restore_ms": None,
        })
        return checkpoint_id

    # ------------------------------------------------------------------
    # Checkpoint — local fallback
    # ------------------------------------------------------------------

    async def _checkpoint_local(self, sandbox_id: str) -> str:
        """Snapshot the local working directory to a tar archive on the host.

        Captures:
        - All files in the working directory (tar.gz archive)
        - Current environment variable overrides
        - Command history up to this point
        """
        checkpoint_id = f"ckpt-{uuid.uuid4().hex[:8]}"
        ts = time.time()
        ckpt_dir = _ensure_local_ckpt_dir() / sandbox_id
        ckpt_dir.mkdir(parents=True, exist_ok=True)
        tar_path = str(ckpt_dir / f"{checkpoint_id}.tar.gz")
        manifest_path = str(ckpt_dir / f"{checkpoint_id}.json")

        work_dir = self._working_dirs.get(sandbox_id)
        if not work_dir or not Path(work_dir).is_dir():
            raise RuntimeError(
                f"Working directory for sandbox '{sandbox_id}' does not exist"
            )

        try:
            # 1. Create tar archive of the entire working directory
            #    Run in executor to avoid blocking the event loop
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._tar_directory, work_dir, tar_path)

            # 2. Capture env vars and command history into manifest
            env_vars = dict(self._env_snapshots.get(sandbox_id, {}))
            cmd_history = list(self._command_history.get(sandbox_id, []))

            manifest_data = {
                "checkpoint_id": checkpoint_id,
                "sandbox_id": sandbox_id,
                "timestamp": ts,
                "tar_path": tar_path,
                "working_dir": work_dir,
                "env_vars": env_vars,
                "command_history": cmd_history,
                "file_count": sum(
                    1 for _ in Path(work_dir).rglob("*") if _.is_file()
                ),
            }

            with open(manifest_path, "w") as f:
                json.dump(manifest_data, f, indent=2)

            logger.info(
                "Local checkpoint %s created for sandbox %s "
                "(archive: %s, files: %d, commands: %d)",
                checkpoint_id, sandbox_id, tar_path,
                manifest_data["file_count"], len(cmd_history),
            )

        except Exception as exc:
            logger.error(
                "Failed to create local checkpoint %s for sandbox %s: %s",
                checkpoint_id, sandbox_id, exc,
            )
            raise

        self._checkpoints.setdefault(sandbox_id, []).append({
            "id": checkpoint_id,
            "sandbox_id": sandbox_id,
            "timestamp": ts,
            "tar_path": tar_path,
            "local": True,
            "env_vars": env_vars,
            "command_history": cmd_history,
            "restore_ms": None,
        })
        return checkpoint_id

    @staticmethod
    def _tar_directory(source_dir: str, tar_path: str) -> None:
        """Create a gzipped tar archive of *source_dir* at *tar_path*."""
        with tarfile.open(tar_path, "w:gz") as tar:
            tar.add(source_dir, arcname=".")

    # ------------------------------------------------------------------
    # Restore — remote (Blaxel SDK)
    # ------------------------------------------------------------------

    async def restore(self, sandbox_id: str, checkpoint_id: str) -> None:
        """Restore sandbox to a previously captured checkpoint.

        Remote: wipe /app and extract the tar archive inside the microVM.
        Local:  wipe the working directory and extract the host-side archive,
                then restore env vars and command history.

        Timing is tracked and stored in the in-memory checkpoint record so
        the frontend can display "restored in Xms".
        """
        if sandbox_id not in self._sandboxes:
            raise ValueError(f"Sandbox '{sandbox_id}' not found")

        # Find the checkpoint metadata
        ckpt_list = self._checkpoints.get(sandbox_id, [])
        ckpt_meta = next((c for c in ckpt_list if c["id"] == checkpoint_id), None)
        if ckpt_meta is None:
            raise ValueError(
                f"Checkpoint '{checkpoint_id}' not found for sandbox '{sandbox_id}'"
            )

        if self._is_remote(sandbox_id):
            await self._restore_remote(sandbox_id, checkpoint_id, ckpt_meta)
        else:
            await self._restore_local(sandbox_id, checkpoint_id, ckpt_meta)

    async def _restore_remote(
        self, sandbox_id: str, checkpoint_id: str, ckpt_meta: dict[str, Any],
    ) -> None:
        """Restore /app inside the Blaxel microVM from a tar archive."""
        sandbox = self._sandboxes[sandbox_id]
        tar_path = ckpt_meta.get("tar_path", f"{_CKPT_DIR}/{checkpoint_id}.tar.gz")
        manifest_path = f"{_CKPT_DIR}/{checkpoint_id}.json"

        restore_start_ms = int(time.monotonic() * 1000)

        try:
            # 1. Verify the manifest / archive exists
            try:
                manifest_raw = await sandbox.fs.read(manifest_path)
                manifest = json.loads(manifest_raw) if manifest_raw else {}
                if manifest.get("tar_path"):
                    tar_path = manifest["tar_path"]
            except Exception as exc:
                raise RuntimeError(
                    f"Cannot read checkpoint manifest at {manifest_path}: {exc}"
                ) from exc

            # 2. Kill running user processes that might lock files in /app
            await sandbox.process.exec({
                "name": f"restore-pkill-{checkpoint_id}",
                "command": "pkill -TERM -u $(id -u) || true",
                "working_dir": "/",
                "wait_for_completion": True,
                "timeout": 5_000,
            })
            await sandbox.process.exec({
                "name": f"restore-sleep-{checkpoint_id}",
                "command": "sleep 0.3 || true",
                "working_dir": "/",
                "wait_for_completion": True,
                "timeout": 5_000,
            })

            # 3. Remove current /app contents (keep the directory itself)
            await sandbox.process.exec({
                "name": f"restore-clean-{checkpoint_id}",
                "command": "find /app -mindepth 1 -delete || true",
                "working_dir": "/",
                "wait_for_completion": True,
                "timeout": 15_000,
            })

            # 4. Extract checkpoint archive back to /
            extract_proc = await sandbox.process.exec({
                "name": f"restore-extract-{checkpoint_id}",
                "command": f"tar -xzf {tar_path} -C /",
                "working_dir": "/",
                "wait_for_completion": True,
                "timeout": 60_000,
            })
            extract_exit = getattr(extract_proc, "exit_code", 0) or 0
            if int(extract_exit) != 0:
                extract_stderr = getattr(extract_proc, "stderr", "") or ""
                raise RuntimeError(
                    f"tar extract failed (exit {extract_exit}): {extract_stderr}"
                )

            restore_ms = int(time.monotonic() * 1000) - restore_start_ms
            ckpt_meta["restore_ms"] = restore_ms

            logger.info(
                "Restored sandbox %s to checkpoint %s in %dms",
                sandbox_id, checkpoint_id, restore_ms,
            )

        except Exception as exc:
            restore_ms = int(time.monotonic() * 1000) - restore_start_ms
            logger.error(
                "Remote restore of sandbox %s to checkpoint %s failed after %dms: %s",
                sandbox_id, checkpoint_id, restore_ms, exc,
            )
            raise

    # ------------------------------------------------------------------
    # Restore — local fallback
    # ------------------------------------------------------------------

    async def _restore_local(
        self, sandbox_id: str, checkpoint_id: str, ckpt_meta: dict[str, Any],
    ) -> None:
        """Restore the local working directory from a host-side tar archive.

        Steps:
        1. Verify the archive exists on disk.
        2. Wipe the current working directory contents.
        3. Extract the tar archive back into the working directory.
        4. Restore environment variable overrides.
        5. Reset command history to the state at checkpoint time.
        """
        tar_path = ckpt_meta.get("tar_path", "")
        if not tar_path or not Path(tar_path).is_file():
            # Try to find the manifest on disk for the path
            ckpt_dir = _LOCAL_CKPT_DIR / sandbox_id
            manifest_path = ckpt_dir / f"{checkpoint_id}.json"
            if manifest_path.is_file():
                with open(manifest_path) as f:
                    manifest = json.load(f)
                tar_path = manifest.get("tar_path", "")
            if not tar_path or not Path(tar_path).is_file():
                raise RuntimeError(
                    f"Checkpoint archive not found for '{checkpoint_id}'. "
                    f"Looked for: {tar_path}"
                )

        work_dir = self._working_dirs.get(sandbox_id)
        if not work_dir:
            raise RuntimeError(
                f"No working directory for sandbox '{sandbox_id}'"
            )

        restore_start_ms = int(time.monotonic() * 1000)

        try:
            loop = asyncio.get_running_loop()

            # 1. Wipe current working directory contents
            await loop.run_in_executor(
                None, self._wipe_directory_contents, work_dir,
            )

            # 2. Extract the checkpoint archive into the working directory
            await loop.run_in_executor(
                None, self._extract_tar, tar_path, work_dir,
            )

            # 3. Restore environment variable overrides
            saved_env = ckpt_meta.get("env_vars", {})
            self._env_snapshots[sandbox_id] = dict(saved_env)

            # 4. Reset command history to the checkpoint state
            saved_history = ckpt_meta.get("command_history", [])
            self._command_history[sandbox_id] = list(saved_history)

            restore_ms = int(time.monotonic() * 1000) - restore_start_ms
            ckpt_meta["restore_ms"] = restore_ms

            logger.info(
                "Restored local sandbox %s to checkpoint %s in %dms "
                "(env_vars: %d, commands: %d)",
                sandbox_id, checkpoint_id, restore_ms,
                len(saved_env), len(saved_history),
            )

        except Exception as exc:
            restore_ms = int(time.monotonic() * 1000) - restore_start_ms
            logger.error(
                "Local restore of sandbox %s to checkpoint %s failed after %dms: %s",
                sandbox_id, checkpoint_id, restore_ms, exc,
            )
            raise

    @staticmethod
    def _wipe_directory_contents(dir_path: str) -> None:
        """Remove all contents of *dir_path* without removing the directory itself."""
        d = Path(dir_path)
        for child in d.iterdir():
            if child.is_dir():
                shutil.rmtree(child)
            else:
                child.unlink()

    @staticmethod
    def _extract_tar(tar_path: str, dest_dir: str) -> None:
        """Extract a gzipped tar archive into *dest_dir*."""
        with tarfile.open(tar_path, "r:gz") as tar:
            tar.extractall(path=dest_dir)

    # ------------------------------------------------------------------
    # Destroy
    # ------------------------------------------------------------------

    async def destroy(self, sandbox_id: str) -> None:
        """Remove sandbox reference and clean up local resources."""
        is_local = not self._is_remote(sandbox_id)
        self._sandboxes.pop(sandbox_id, None)
        self._checkpoints.pop(sandbox_id, None)

        if is_local:
            # Clean up the local working directory
            work_dir = self._working_dirs.pop(sandbox_id, None)
            if work_dir and Path(work_dir).is_dir():
                shutil.rmtree(work_dir, ignore_errors=True)
            # Clean up local checkpoint archives
            ckpt_dir = _LOCAL_CKPT_DIR / sandbox_id
            if ckpt_dir.is_dir():
                shutil.rmtree(ckpt_dir, ignore_errors=True)
            self._command_history.pop(sandbox_id, None)
            self._env_snapshots.pop(sandbox_id, None)
            logger.info("Destroyed local sandbox %s", sandbox_id)
        else:
            # Let Blaxel handle cleanup via auto scale-to-zero
            logger.info("Released sandbox %s (will auto-scale to zero)", sandbox_id)

    # ------------------------------------------------------------------
    # List checkpoints
    # ------------------------------------------------------------------

    async def list_checkpoints(self, sandbox_id: str) -> list[Checkpoint]:
        """Return locally tracked checkpoints for a sandbox."""
        items = self._checkpoints.get(sandbox_id, [])
        result = []
        for idx, item in enumerate(items):
            restore_ms = item.get("restore_ms")
            if restore_ms is not None:
                description = (
                    f"Checkpoint at {item.get('timestamp', 0):.0f} "
                    f"(last restored in {restore_ms}ms)"
                )
            else:
                description = f"Checkpoint at {item.get('timestamp', 0):.0f}"

            # Include snapshot metadata in the working_memory_snapshot field
            # so the API/UI can show what was captured
            snapshot_data: dict[str, Any] = {}
            if item.get("local"):
                snapshot_data["type"] = "local"
                snapshot_data["env_var_count"] = len(item.get("env_vars", {}))
                snapshot_data["command_count"] = len(item.get("command_history", []))
            else:
                snapshot_data["type"] = "remote"
            if restore_ms is not None:
                snapshot_data["restore_ms"] = restore_ms

            result.append(
                Checkpoint(
                    id=item["id"],
                    task_id=sandbox_id,
                    attempt_number=idx,
                    sandbox_snapshot_id=item["id"],
                    working_memory_snapshot=snapshot_data,
                    description=description,
                    reversible=True,
                )
            )
        return result

    # ------------------------------------------------------------------
    # Extra helpers for the local fallback
    # ------------------------------------------------------------------

    def set_env(self, sandbox_id: str, key: str, value: str) -> None:
        """Set an environment variable override for a local sandbox."""
        self._env_snapshots.setdefault(sandbox_id, {})[key] = value

    def get_working_dir(self, sandbox_id: str) -> str | None:
        """Return the host-side working directory for a local sandbox."""
        return self._working_dirs.get(sandbox_id)


# Sentinel object to distinguish local-only sandboxes from missing ones.
# When self._sandboxes[id] is _SENTINEL_LOCAL, the sandbox exists but has
# no remote Blaxel SandboxInstance behind it.
_SENTINEL_LOCAL = object()
