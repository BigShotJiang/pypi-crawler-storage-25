"""ReLoop data models — shared across all modules."""

from __future__ import annotations

import hashlib
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# --- Enums ---

class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    ABANDONED = "abandoned"


class AttemptStatus(str, Enum):
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class ErrorCategory(str, Enum):
    DEPENDENCY_ERROR = "dependency_error"
    RUNTIME_ERROR = "runtime_error"
    CONFIG_ERROR = "config_error"
    TYPE_ERROR = "type_error"
    NETWORK_ERROR = "network_error"
    PERMISSION_ERROR = "permission_error"
    TIMEOUT_ERROR = "timeout_error"
    UNKNOWN = "unknown"


class TimelineEventType(str, Enum):
    TASK_CREATED = "task.created"
    ATTEMPT_STARTED = "attempt.started"
    STEP_STARTED = "step.started"
    STEP_COMPLETED = "step.completed"
    STEP_FAILED = "step.failed"
    MEMORY_RECALLED = "memory.recalled"
    MEMORY_STORED = "memory.stored"
    CHECKPOINT_CREATED = "checkpoint.created"
    CHECKPOINT_RESTORED = "checkpoint.restored"
    ATTEMPT_SUCCEEDED = "attempt.succeeded"
    ATTEMPT_FAILED = "attempt.failed"
    PREDICTION = "prediction"
    CIRCUIT_BREAKER_OPEN = "circuit_breaker.open"
    TASK_COMPLETED = "task.completed"
    TASK_ABANDONED = "task.abandoned"


# --- Core Data Models ---

def _make_id() -> str:
    return uuid.uuid4().hex[:12]


def _now() -> datetime:
    return datetime.now(timezone.utc)


class ErrorSignature(BaseModel):
    error_type: str
    error_category: ErrorCategory = ErrorCategory.UNKNOWN
    error_message: str
    error_hash: str = ""
    code_context: str = ""

    def model_post_init(self, __context: Any) -> None:
        if not self.error_hash:
            raw = f"{self.error_type}:{self.error_message}"
            self.error_hash = hashlib.sha256(raw.encode()).hexdigest()[:16]


class FailureAnalysis(BaseModel):
    root_cause: str
    what_was_tried: str
    why_it_failed: str
    suggested_fix: str
    anti_pattern: str = ""
    confidence: float = Field(default=0.8, ge=0.0, le=1.0)


class FailureRecord(BaseModel):
    id: str = Field(default_factory=_make_id)
    task_id: str
    attempt_number: int
    timestamp: datetime = Field(default_factory=_now)
    signature: ErrorSignature
    analysis: FailureAnalysis
    context: dict[str, Any] = Field(default_factory=dict)
    embedding: list[float] = Field(default_factory=list)
    topics: list[str] = Field(default_factory=list)
    cost_usd: float = 0.0
    transferable: bool = Field(
        default=True,
        description="Whether this failure is transferable across projects. "
        "Most failures (dependency errors, config errors, type errors) are "
        "universally useful. Set to False for project-specific failures.",
    )


class SuccessRecord(BaseModel):
    id: str = Field(default_factory=_make_id)
    task_id: str
    attempt_number: int
    timestamp: datetime = Field(default_factory=_now)
    solution: dict[str, str] = Field(default_factory=dict)
    learning: dict[str, Any] = Field(default_factory=dict)
    metrics: dict[str, Any] = Field(default_factory=dict)


class Checkpoint(BaseModel):
    id: str = Field(default_factory=_make_id)
    task_id: str
    attempt_number: int
    step_number: int = 0
    sandbox_snapshot_id: str = ""
    working_memory_snapshot: dict[str, Any] = Field(default_factory=dict)
    description: str = ""
    created_at: datetime = Field(default_factory=_now)
    reversible: bool = True


# --- Task & Attempt Models ---

class StepResult(BaseModel):
    step_number: int
    description: str
    command: str = ""
    output: str = ""
    status: AttemptStatus = AttemptStatus.RUNNING
    error: str | None = None
    started_at: datetime = Field(default_factory=_now)
    completed_at: datetime | None = None
    cost_usd: float = 0.0


class Attempt(BaseModel):
    attempt_number: int
    status: AttemptStatus = AttemptStatus.RUNNING
    steps: list[StepResult] = Field(default_factory=list)
    recalled_memories: list[str] = Field(default_factory=list)
    failure_record_id: str | None = None
    checkpoint_id: str | None = None
    started_at: datetime = Field(default_factory=_now)
    completed_at: datetime | None = None
    cost_usd: float = 0.0


class Task(BaseModel):
    id: str = Field(default_factory=_make_id)
    instruction: str
    status: TaskStatus = TaskStatus.PENDING
    attempts: list[Attempt] = Field(default_factory=list)
    current_attempt: int = 0
    max_retries: int = 5
    max_budget_usd: float = 1.0
    total_cost_usd: float = 0.0
    created_at: datetime = Field(default_factory=_now)
    completed_at: datetime | None = None
    result: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


# --- Timeline Event ---

class TimelineEvent(BaseModel):
    id: str = Field(default_factory=_make_id)
    task_id: str
    event_type: TimelineEventType
    attempt_number: int = 0
    step_number: int = 0
    timestamp: datetime = Field(default_factory=_now)
    data: dict[str, Any] = Field(default_factory=dict)
    message: str = ""


# --- API Request/Response Models ---

class CreateTaskRequest(BaseModel):
    instruction: str
    max_retries: int = 5
    max_budget_usd: float = 1.0
    metadata: dict[str, Any] = Field(default_factory=dict)


class TaskResponse(BaseModel):
    id: str
    instruction: str
    status: TaskStatus
    current_attempt: int
    total_attempts: int
    total_cost_usd: float
    created_at: datetime
    completed_at: datetime | None
    result: str | None

    @classmethod
    def from_task(cls, task: Task) -> TaskResponse:
        return cls(
            id=task.id,
            instruction=task.instruction,
            status=task.status,
            current_attempt=task.current_attempt,
            total_attempts=len(task.attempts),
            total_cost_usd=task.total_cost_usd,
            created_at=task.created_at,
            completed_at=task.completed_at,
            result=task.result,
        )


class MemorySearchRequest(BaseModel):
    query: str
    error_type: str | None = None
    error_category: ErrorCategory | None = None
    limit: int = 5
    cross_project: bool = Field(
        default=False,
        description="If True, search across all projects/tasks and return only "
        "transferable failures. Enables cross-project knowledge transfer.",
    )
    exclude_task_id: str | None = Field(
        default=None,
        description="When using cross_project mode, exclude failures from this "
        "task ID to avoid returning the caller's own failures.",
    )


class MemorySearchResponse(BaseModel):
    failures: list[FailureRecord]
    total_count: int


class MemoryStatsResponse(BaseModel):
    total_failures: int
    total_successes: int
    top_error_categories: dict[str, int]
    avg_confidence: float


class PredictionRequest(BaseModel):
    instruction: str
    context: dict[str, str] | None = None
    limit: int = 3


class CircuitBreakerState(BaseModel):
    is_open: bool = False
    reason: str = ""
    consecutive_same_error: int = 0
    error_hash: str = ""
    error_type: str = ""
    recommendation: str = ""


class PlaybookExport(BaseModel):
    name: str = "ReLoop Failure Playbook"
    version: str = "1.0"
    exported_at: datetime = Field(default_factory=_now)
    domain: str = ""
    failures: list[FailureRecord] = Field(default_factory=list)
    stats: dict[str, Any] = Field(default_factory=dict)


class PlaybookImport(BaseModel):
    failures: list[FailureRecord]
    domain: str = ""
