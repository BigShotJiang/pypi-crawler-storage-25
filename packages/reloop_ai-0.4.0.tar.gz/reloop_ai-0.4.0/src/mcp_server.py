"""ReLoop MCP Server — Persistent Failure Memory for Claude Code, Cursor, and Windsurf.

Exposes 5 core tools via the Model Context Protocol:
    1. reloop_search_memories   — semantic search over failure memory (with cross-project support)
    2. reloop_get_anti_patterns — return known anti-patterns with confidence scores
    3. reloop_predict_failures  — predict likely failures before execution
    4. reloop_get_stats         — return memory statistics
    5. reloop_import_playbook   — import a failure playbook JSON to seed memory

Run with:
    python -m src.mcp_server

Or register in Claude Code's MCP settings using examples/integrations/mcp_config.json.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from typing import Any

# ---------------------------------------------------------------------------
# Ensure the project root is on sys.path so `src.*` imports resolve whether
# this file is executed as `python src/mcp_server.py` or directly as a module.
# ---------------------------------------------------------------------------
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from mcp.server.fastmcp import FastMCP

from src.config import settings
from src.models import (
    ErrorCategory,
    ErrorSignature,
    FailureAnalysis,
    FailureRecord,
    PlaybookImport,
    Task,
    TaskStatus,
)

logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# MCP server instance
# ---------------------------------------------------------------------------

mcp = FastMCP("ReLoop Failure Memory")

# ---------------------------------------------------------------------------
# Provider initialisation — mirrors src/api/server.py but synchronous-friendly
# ---------------------------------------------------------------------------

_memory_backend = None
_memory_manager = None


async def _init_memory_backend():
    """Try Redis first, fall back to SQLite for local dev."""
    # Try Redis
    try:
        from src.providers.memory.redis_backend import RedisMemoryBackend  # type: ignore
        backend = RedisMemoryBackend(
            redis_url=settings.redis_url,
            index_name=settings.redis_memory_index,
        )
        logger.info("MCP: Using RedisMemoryBackend")
        return backend
    except ImportError:
        logger.debug("RedisMemoryBackend not importable, trying SQLite")
    except Exception as exc:
        logger.debug("RedisMemoryBackend init failed (%s), trying SQLite", exc)

    # Fall back to SQLite
    try:
        from src.providers.memory.sqlite_backend import SQLiteMemoryBackend  # type: ignore
        backend = SQLiteMemoryBackend()
        logger.info("MCP: Using SQLiteMemoryBackend (fallback)")
        return backend
    except ImportError:
        logger.warning("SQLiteMemoryBackend not importable — memory tools will be degraded")
    except Exception as exc:
        logger.warning("SQLiteMemoryBackend init failed: %s", exc)

    return None


async def _init_memory_manager(backend):
    """Create a FailureMemoryManager wrapping the backend."""
    if backend is None:
        return None
    try:
        from src.core.memory import FailureMemoryManager  # type: ignore

        # Try to get an LLM provider for embeddings
        llm = None
        try:
            from src.providers.llm.openai import OpenAILLM  # type: ignore
            llm = OpenAILLM(api_key=settings.openai_api_key, model=settings.codex_model)
        except Exception:
            pass

        return FailureMemoryManager(backend=backend, llm=llm)
    except Exception as exc:
        logger.debug("Could not init FailureMemoryManager: %s", exc)
        return None


def _run_async(coro):
    """Run a coroutine synchronously, reusing any existing event loop."""
    try:
        loop = asyncio.get_running_loop()
        # We're inside a running loop — use run_coroutine_threadsafe
        import concurrent.futures
        future = asyncio.run_coroutine_threadsafe(coro, loop)
        return future.result(timeout=30)
    except RuntimeError:
        # No running loop — safe to use asyncio.run
        return asyncio.run(coro)


# ---------------------------------------------------------------------------
# Lazy initialisation — initialised on first tool call
# ---------------------------------------------------------------------------

_initialized = False


def _ensure_initialized():
    global _memory_backend, _memory_manager, _initialized
    if _initialized:
        return
    _memory_backend = _run_async(_init_memory_backend())
    _memory_manager = _run_async(_init_memory_manager(_memory_backend))
    _initialized = True


# ---------------------------------------------------------------------------
# Helper — format a FailureRecord as human-readable text
# ---------------------------------------------------------------------------

def _format_failure(record: FailureRecord, index: int | None = None) -> str:
    prefix = f"{index}. " if index is not None else ""
    sig = record.signature
    ana = record.analysis
    lines = [
        f"{prefix}[{sig.error_type}]",
        f"   Error    : {sig.error_message[:200]}",
        f"   Category : {sig.error_category}",
        f"   Root cause: {ana.root_cause}",
        f"   Fix      : {ana.suggested_fix}",
        f"   Confidence: {ana.confidence:.0%}",
    ]
    if ana.anti_pattern:
        lines.append(f"   Anti-pattern: {ana.anti_pattern}")
    transferable_label = "Yes" if record.transferable else "No"
    lines.append(
        f"   Record ID: {record.id}  |  Task: {record.task_id}"
        f"  |  Attempt #{record.attempt_number}  |  Transferable: {transferable_label}"
    )
    return "\n".join(lines)


# ===========================================================================
# Tool 1 — reloop_search_memories
# ===========================================================================

@mcp.tool()
def reloop_search_memories(
    query: str,
    limit: int = 5,
    cross_project: bool = False,
    exclude_task_id: str = "",
) -> str:
    """Search ReLoop's persistent failure memory for past errors and their fixes.

    Use this before writing code or debugging — ReLoop may already know the
    root cause and fix for the error you're dealing with. Results include error
    type, root cause analysis, suggested fix, and confidence score.

    When cross_project is True, searches ALL failures across every project and
    task — enabling knowledge transfer from Project A to Project B. Only
    transferable failures are returned in cross-project mode.

    Args:
        query: Natural-language description of the error or problem to search for.
               E.g. "missing sharp dependency nextjs", "port 3000 already in use".
        limit: Maximum number of results to return (default 5, max 20).
        cross_project: If True, search across all projects/tasks and return only
                       transferable failures. If False, search normally.
        exclude_task_id: When using cross_project mode, exclude failures from this
                         task ID (useful to avoid returning the caller's own failures).
    """
    _ensure_initialized()

    limit = max(1, min(limit, 20))

    # Cross-project search via FailureMemoryManager
    if cross_project and _memory_manager is not None:
        try:
            records: list[FailureRecord] = _run_async(
                _memory_manager.search_cross_project(
                    query=query,
                    exclude_task_id=exclude_task_id or None,
                    limit=limit,
                )
            )
        except Exception as exc:
            return f"Cross-project search failed: {exc}"
    elif _memory_backend is not None:
        try:
            records = _run_async(
                _memory_backend.search(query, limit=limit)
            )
        except Exception as exc:
            return f"Search failed: {exc}"
    else:
        return "Memory backend not available. Ensure Redis or SQLite is configured."

    if not records:
        mode = "cross-project " if cross_project else ""
        return (
            f"No failure records found in {mode}search matching: {query!r}\n\n"
            f"ReLoop hasn't seen this kind of failure yet. Once failures are "
            f"stored, future searches will find them."
        )

    mode_label = " (cross-project)" if cross_project else ""
    lines = [
        f"Found {len(records)} failure record(s) matching {query!r}{mode_label}:\n",
    ]
    for i, record in enumerate(records, start=1):
        lines.append(_format_failure(record, index=i))
        lines.append("")  # blank line between records

    return "\n".join(lines)


# ===========================================================================
# Tool 2 — reloop_get_anti_patterns
# ===========================================================================

@mcp.tool()
def reloop_get_anti_patterns(domain: str = "") -> str:
    """Get a list of anti-patterns learned from past failures, with confidence scores.

    Anti-patterns are recurring mistakes that the agent has already made and learned
    from. Use this to avoid known pitfalls when working in a specific tech domain.

    Returns anti-patterns sorted by confidence (highest first), deduplicated,
    with the confidence score indicating how reliable each pattern is.

    Args:
        domain: Optional domain filter, e.g. "nextjs", "python", "docker", "redis".
                Leave empty to get all anti-patterns across all domains.
    """
    _ensure_initialized()

    if _memory_backend is None:
        return "Memory backend not available. Ensure Redis or SQLite is configured."

    query = domain.strip() if domain.strip() else "anti-pattern failure error"
    try:
        records: list[FailureRecord] = _run_async(
            _memory_backend.search(query, limit=50)
        )
    except Exception as exc:
        return f"Failed to retrieve anti-patterns: {exc}"

    # Extract non-empty anti_pattern fields, tracking best confidence
    seen: dict[str, tuple[float, str, str]] = {}  # pattern -> (confidence, error_type, root_cause)
    for record in records:
        ap = record.analysis.anti_pattern.strip()
        if not ap:
            continue
        # Filter by domain if specified
        if domain.strip():
            domain_lower = domain.strip().lower()
            combined = (
                ap.lower()
                + record.signature.error_message.lower()
                + record.signature.error_type.lower()
                + " ".join(t.lower() for t in record.topics)
            )
            if domain_lower not in combined:
                continue
        existing_conf = seen.get(ap, (0.0, "", ""))[0]
        if record.analysis.confidence > existing_conf:
            seen[ap] = (
                record.analysis.confidence,
                record.signature.error_type,
                record.analysis.root_cause,
            )

    if not seen:
        scope = f" in domain {domain!r}" if domain else ""
        return (
            f"No anti-patterns found{scope}.\n\n"
            f"Anti-patterns are stored when failures are recorded with an anti_pattern field. "
            f"Run the agent on some tasks and failures will be catalogued automatically."
        )

    # Sort by confidence descending
    sorted_patterns = sorted(seen.items(), key=lambda x: x[1][0], reverse=True)

    scope_header = f" (domain: {domain})" if domain else " (all domains)"
    lines = [f"Anti-patterns learned from failure memory{scope_header}:\n"]
    for i, (pattern, (conf, error_type, root_cause)) in enumerate(sorted_patterns, start=1):
        lines.append(f"{i}. [{conf:.0%} confidence] {pattern}")
        if error_type:
            lines.append(f"   Error type : {error_type}")
        if root_cause:
            lines.append(f"   Root cause : {root_cause}")

    lines.append(
        f"\nTotal: {len(sorted_patterns)} unique anti-pattern(s). "
        f"Avoid these when writing or debugging code."
    )
    return "\n".join(lines)


# ===========================================================================
# Tool 3 — reloop_predict_failures
# ===========================================================================

@mcp.tool()
def reloop_predict_failures(
    instruction: str,
    context: str = "",
    limit: int = 3,
) -> str:
    """Predict likely failures BEFORE executing a task, based on past failure patterns.

    Use this proactively before running commands, deployments, or builds.
    ReLoop analyses its failure memory and predicts what's most likely to go wrong,
    with prevention advice so you can avoid the failure entirely.

    Returns a ranked list of predicted failures with prediction scores (0-100%),
    root causes, and suggested preventions.

    Args:
        instruction: Description of the task you're about to execute.
                     E.g. "npm install && npm run build in a Next.js project",
                     "deploy to production", "run database migrations".
        context: Optional comma-separated context values like framework name,
                 language, or environment. E.g. "nextjs,typescript,docker".
        limit: Maximum number of predictions to return (default 3, max 10).
    """
    _ensure_initialized()

    if _memory_manager is None:
        if _memory_backend is None:
            return "Memory backend not available. Ensure Redis or SQLite is configured."
        return (
            "Memory manager not available — predictions require the full memory manager. "
            "Basic search is still available via reloop_search_memories."
        )

    limit = max(1, min(limit, 10))

    # Parse context string into a dict
    context_dict: dict[str, str] | None = None
    if context.strip():
        context_dict = {
            f"tag_{i}": tag.strip()
            for i, tag in enumerate(context.split(","))
            if tag.strip()
        }

    try:
        predictions: list[dict[str, Any]] = _run_async(
            _memory_manager.predict_likely_failures(
                instruction=instruction,
                context=context_dict,
                limit=limit,
            )
        )
    except Exception as exc:
        return f"Prediction failed: {exc}"

    if not predictions:
        return (
            f"No failure predictions for: {instruction!r}\n\n"
            f"ReLoop hasn't seen enough similar failures to make predictions. "
            f"As more failures are recorded, predictions will become available."
        )

    lines = [
        f"Predicted failures for: {instruction!r}\n",
        f"Based on {sum(p.get('based_on_failures', 0) for p in predictions)} "
        f"historical failure(s):\n",
    ]
    for i, pred in enumerate(predictions, start=1):
        score = pred.get("prediction_score", 0)
        lines.append(f"{i}. [{score:.0%} likelihood] {pred.get('error_type', 'Unknown')}")
        if pred.get("root_cause"):
            lines.append(f"   Root cause : {pred['root_cause']}")
        if pred.get("suggested_prevention"):
            lines.append(f"   Prevention : {pred['suggested_prevention']}")
        lines.append(f"   Based on   : {pred.get('based_on_failures', 0)} past failure(s)")
        lines.append("")

    lines.append(
        "Address these predicted failures proactively to avoid them during execution."
    )
    return "\n".join(lines)


# ===========================================================================
# Tool 4 — reloop_get_stats
# ===========================================================================

@mcp.tool()
def reloop_get_stats() -> str:
    """Get aggregate statistics from ReLoop's failure memory.

    Returns total failures and successes stored, top error categories,
    average confidence, and overall success rate. Useful for understanding
    how much the agent has learned over time and which error categories
    are most common.
    """
    _ensure_initialized()

    if _memory_backend is None:
        return "Memory backend not available. Ensure Redis or SQLite is configured."

    try:
        stats = _run_async(_memory_backend.get_stats())
    except Exception as exc:
        return f"Failed to retrieve memory statistics: {exc}"

    if stats.total_failures == 0 and stats.total_successes == 0:
        return (
            "ReLoop memory is empty.\n\n"
            "No failures or successes have been recorded yet. "
            "Run tasks through the agent or use reloop_import_playbook to seed memory."
        )

    lines = [
        "ReLoop Failure Memory Statistics",
        "=================================",
        f"  Total failures stored : {stats.total_failures}",
        f"  Total successes stored: {stats.total_successes}",
        f"  Average confidence    : {stats.avg_confidence:.1%}",
    ]

    if stats.top_error_categories:
        lines.append("\nTop error categories:")
        sorted_cats = sorted(
            stats.top_error_categories.items(), key=lambda x: x[1], reverse=True
        )
        for category, count in sorted_cats[:10]:
            bar = "#" * min(count, 20)
            lines.append(f"  {category:<30} {count:>4}  {bar}")

    total_known = stats.total_failures + stats.total_successes
    if total_known > 0:
        success_rate = stats.total_successes / total_known
        lines.append(f"\n  Overall success rate : {success_rate:.1%}")

    lines.append(
        "\nReLoop gets smarter with every failure. "
        "Use reloop_search_memories to recall what was learned."
    )

    return "\n".join(lines)


# ===========================================================================
# Tool 5 — reloop_import_playbook
# ===========================================================================

@mcp.tool()
def reloop_import_playbook(playbook_json: str) -> str:
    """Import a failure playbook JSON to seed ReLoop's memory with known failures.

    Use this to bootstrap a new project with failure knowledge from other projects,
    teams, or exported playbooks. Each failure record in the playbook is stored
    in ReLoop's memory and becomes immediately searchable.

    The playbook JSON should have this structure:
    {
        "failures": [
            {
                "task_id": "project-name",
                "attempt_number": 1,
                "signature": {
                    "error_type": "ModuleNotFoundError",
                    "error_category": "dependency_error",
                    "error_message": "No module named 'sharp'"
                },
                "analysis": {
                    "root_cause": "sharp is not installed",
                    "what_was_tried": "npm run build",
                    "why_it_failed": "Missing native dependency",
                    "suggested_fix": "npm install sharp",
                    "anti_pattern": "Don't assume native deps are pre-installed",
                    "confidence": 0.95
                },
                "transferable": true
            }
        ],
        "domain": "nextjs"
    }

    Args:
        playbook_json: A JSON string containing the playbook with a "failures" array
                       and optional "domain" field. Each failure must have at minimum
                       a signature (error_type, error_message) and analysis (root_cause,
                       suggested_fix).
    """
    _ensure_initialized()

    if _memory_backend is None:
        return "Memory backend not available. Ensure Redis or SQLite is configured."

    # Parse JSON
    try:
        data = json.loads(playbook_json)
    except json.JSONDecodeError as exc:
        return (
            f"Invalid JSON: {exc}\n\n"
            f"The playbook_json argument must be a valid JSON string. "
            f"See the tool description for the expected format."
        )

    # Validate structure
    if not isinstance(data, dict):
        return "Invalid playbook format: expected a JSON object with a 'failures' array."

    failures_raw = data.get("failures")
    if not failures_raw or not isinstance(failures_raw, list):
        return (
            "Invalid playbook format: missing or empty 'failures' array.\n\n"
            "Expected: {\"failures\": [{...}, ...], \"domain\": \"optional\"}"
        )

    domain = data.get("domain", "")

    # Parse and store each failure
    imported = 0
    errors_list: list[str] = []
    for i, entry in enumerate(failures_raw):
        try:
            # Validate via PlaybookImport's individual record parsing
            record = FailureRecord(**entry)
            if domain and domain not in record.topics:
                record.topics = [domain, *record.topics]
            _run_async(_memory_backend.store_failure(record))
            imported += 1
        except Exception as exc:
            errors_list.append(f"  Record {i + 1}: {exc}")

    lines = [
        f"Playbook import complete.",
        f"  Imported : {imported} failure record(s)",
        f"  Errors   : {len(errors_list)}",
        f"  Total    : {len(failures_raw)}",
    ]
    if domain:
        lines.append(f"  Domain   : {domain}")

    if errors_list:
        lines.append("\nImport errors:")
        lines.extend(errors_list[:10])
        if len(errors_list) > 10:
            lines.append(f"  ... and {len(errors_list) - 10} more error(s)")

    if imported > 0:
        lines.append(
            "\nImported failures are now searchable via reloop_search_memories."
        )

    return "\n".join(lines)


# ===========================================================================
# Bonus Tool — reloop_store_failure (kept for manual failure entry)
# ===========================================================================

@mcp.tool()
def reloop_store_failure(
    error_type: str,
    error_message: str,
    root_cause: str,
    suggested_fix: str,
    task_id: str = "manual",
    anti_pattern: str = "",
    confidence: float = 0.9,
    transferable: bool = True,
) -> str:
    """Store a single failure and its fix into ReLoop's persistent memory.

    Call this when you've solved a tricky bug, diagnosed a confusing error, or
    found a fix that should be remembered for next time. Future sessions and other
    projects will benefit from this stored knowledge.

    Args:
        error_type: Short error name, e.g. "ModuleNotFoundError", "PortConflict".
        error_message: The full error message text.
        root_cause: One-line explanation of why the error happened.
        suggested_fix: Concrete fix — command, code change, or action to take.
        task_id: Optional task identifier for grouping related failures (default: "manual").
        anti_pattern: Optional pattern to avoid in the future, e.g. "Don't use port 3000".
        confidence: How confident you are in this fix, 0.0-1.0 (default 0.9).
        transferable: Whether this failure applies across projects (default True).
                      Set to False for project-specific failures.
    """
    _ensure_initialized()

    if _memory_backend is None:
        return "Memory backend not available. Ensure Redis or SQLite is configured."

    confidence = max(0.0, min(1.0, confidence))

    signature = ErrorSignature(
        error_type=error_type,
        error_category=ErrorCategory.UNKNOWN,
        error_message=error_message,
    )
    analysis = FailureAnalysis(
        root_cause=root_cause,
        what_was_tried="Manual entry via MCP",
        why_it_failed=error_message,
        suggested_fix=suggested_fix,
        anti_pattern=anti_pattern,
        confidence=confidence,
    )
    record = FailureRecord(
        task_id=task_id,
        attempt_number=0,
        signature=signature,
        analysis=analysis,
        context={"source": "mcp_manual"},
        transferable=transferable,
    )

    try:
        record_id = _run_async(_memory_backend.store_failure(record))
    except Exception as exc:
        return f"Failed to store failure record: {exc}"

    return (
        f"Failure stored successfully.\n"
        f"  Record ID    : {record_id}\n"
        f"  Error type   : {error_type}\n"
        f"  Root cause   : {root_cause}\n"
        f"  Fix          : {suggested_fix}\n"
        f"  Confidence   : {confidence:.0%}\n"
        f"  Transferable : {'Yes' if transferable else 'No'}\n"
        f"\nThis failure will now appear in future reloop_search_memories calls."
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run()
