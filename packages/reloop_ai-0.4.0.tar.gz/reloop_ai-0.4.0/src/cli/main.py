"""ReLoop CLI — command-line interface for the ReLoop agent."""

from __future__ import annotations

import asyncio
import json
import shutil
import time
from enum import Enum
from pathlib import Path

import typer
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.spinner import Spinner
from rich.table import Table

app = typer.Typer(
    name="reloop",
    help="ReLoop — The Self-Healing Agent with Failure Memory",
    no_args_is_help=True,
)
console = Console()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _api_url() -> str:
    """Return the base API URL from config."""
    from src.config import settings
    return f"http://{settings.api_host}:{settings.api_port}"


def _http_client():
    """Create an httpx client for API calls."""
    import httpx
    return httpx.Client(base_url=_api_url(), timeout=30.0)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

class FormatChoice(str, Enum):
    yaml = "yaml"
    json = "json"


def _stream_task_events(task_id: str) -> None:
    """Connect to SSE endpoint and stream task events to the console."""
    import httpx

    url = f"{_api_url()}/v1/tasks/{task_id}/sse"
    try:
        with httpx.stream("GET", url, timeout=None) as stream:
            for line in stream.iter_lines():
                if not line.startswith("data: "):
                    continue
                payload = line[6:]
                if payload.strip() == "[DONE]":
                    break
                try:
                    event = json.loads(payload)
                except json.JSONDecodeError:
                    continue
                etype = event.get("type", event.get("event", ""))
                if etype in ("attempt_start", "attempt_started"):
                    attempt = event.get("attempt", event.get("attempt_number", "?"))
                    console.print(f"\U0001f504 Attempt {attempt} starting...")
                elif etype in ("attempt_failed", "attempt_failure"):
                    attempt = event.get("attempt", event.get("attempt_number", "?"))
                    err = event.get("error_type", event.get("error", "unknown"))
                    console.print(f"\u274c Attempt {attempt} failed: {err}")
                elif etype in ("task_succeeded", "task_success"):
                    attempts = event.get("total_attempts", event.get("attempts", "?"))
                    cost = event.get("total_cost_usd", event.get("cost", 0))
                    console.print(
                        f"\u2705 Task succeeded after {attempts} attempts "
                        f"(cost: ${float(cost):.2f})"
                    )
                elif etype in ("task_failed", "task_abandoned"):
                    console.print(f"\u274c Task failed: {event.get('reason', 'unknown')}")
    except Exception:
        # SSE connection failed — caller will fall back to polling
        raise


def _poll_task(task_id: str) -> None:
    """Poll task status until terminal state, then print summary."""
    import httpx

    client = _http_client()
    with Live(Spinner("dots", text="Waiting for task..."), console=console, transient=True):
        while True:
            resp = client.get(f"/v1/tasks/{task_id}")
            resp.raise_for_status()
            data = resp.json()
            task_status = data.get("status", "unknown")
            if task_status in ("succeeded", "failed", "abandoned"):
                break
            time.sleep(2)

    if task_status == "succeeded":
        console.print(
            f"\u2705 Task succeeded after {data.get('total_attempts', '?')} attempts "
            f"(cost: ${data.get('total_cost_usd', 0):.2f})"
        )
    else:
        console.print(f"\u274c Task {task_status}")
    if data.get("result"):
        console.print(f"Result: {str(data['result'])[:200]}")


@app.command()
def run(
    instruction: str = typer.Argument(..., help="Task instruction for the agent"),
    max_retries: int = typer.Option(5, "--max-retries", "-r", help="Maximum retry attempts"),
    budget: float = typer.Option(1.0, "--budget", "-b", help="Maximum budget in USD"),
    stream: bool = typer.Option(True, "--stream/--no-stream", help="Stream SSE events (default: True)"),
) -> None:
    """Create and run a new task."""
    client = _http_client()
    try:
        resp = client.post(
            "/v1/tasks",
            json={
                "instruction": instruction,
                "max_retries": max_retries,
                "max_budget_usd": budget,
            },
        )
        resp.raise_for_status()
        data = resp.json()
        task_id = data.get("id", "unknown")
        console.print(f"[green]Task created:[/green] {task_id}")
        console.print(f"Status: {data.get('status', 'unknown')}")

        # Stream or poll for completion
        if stream:
            try:
                _stream_task_events(task_id)
            except Exception:
                console.print("[yellow]SSE unavailable, falling back to polling...[/yellow]")
                _poll_task(task_id)
        else:
            _poll_task(task_id)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def status(
    task_id: str = typer.Argument(..., help="Task ID to check"),
) -> None:
    """Get status of a task."""
    client = _http_client()
    try:
        resp = client.get(f"/v1/tasks/{task_id}")
        resp.raise_for_status()
        data = resp.json()
        table = Table(title=f"Task {task_id}")
        table.add_column("Field", style="cyan")
        table.add_column("Value")
        table.add_row("Status", data.get("status", "unknown"))
        table.add_row("Attempts", str(data.get("total_attempts", 0)))
        table.add_row("Cost", f"${data.get('total_cost_usd', 0):.4f}")
        if data.get("result"):
            table.add_row("Result", str(data["result"])[:200])
        console.print(table)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def memories(
    query: str = typer.Option("", "--query", "-q", help="Search query"),
    limit: int = typer.Option(10, "--limit", "-l", help="Max results"),
) -> None:
    """Search or list failure memories."""
    client = _http_client()
    try:
        if query:
            resp = client.post(
                "/v1/memories/search",
                json={"query": query, "limit": limit},
            )
        else:
            resp = client.get("/v1/memories/failures", params={"limit": limit})
        resp.raise_for_status()
        data = resp.json()
        failures = data.get("results", data) if isinstance(data, dict) else data
        if not failures:
            console.print("[yellow]No memories found.[/yellow]")
            return
        for f in failures[:limit]:
            if isinstance(f, dict):
                console.print(
                    f"[red]{f.get('signature', {}).get('error_type', 'unknown')}[/red]: "
                    f"{f.get('analysis', {}).get('root_cause', 'unknown')}"
                )
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def stats() -> None:
    """Show memory statistics."""
    client = _http_client()
    try:
        resp = client.get("/v1/memories/stats")
        resp.raise_for_status()
        data = resp.json()
        table = Table(title="Memory Statistics")
        table.add_column("Metric", style="cyan")
        table.add_column("Value")
        table.add_row("Total Failures", str(data.get("total_failures", 0)))
        table.add_row("Total Successes", str(data.get("total_successes", 0)))
        table.add_row("Avg Confidence", f"{data.get('avg_confidence', 0):.2f}")
        categories = data.get("top_error_categories", {})
        if categories:
            table.add_row("Top Categories", ", ".join(f"{k}: {v}" for k, v in categories.items()))
        console.print(table)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def serve(
    host: str = typer.Option(None, "--host", help="Host to bind to (default: API_HOST env or 0.0.0.0)"),
    port: int = typer.Option(None, "--port", "-p", help="Port to bind to (default: API_PORT env or 8000)"),
    reload: bool = typer.Option(False, "--reload", help="Enable auto-reload"),
) -> None:
    """Start the ReLoop API server."""
    import uvicorn
    from src.config import settings
    _host = host or settings.api_host
    _port = port or settings.api_port
    console.print(f"[green]Starting ReLoop API server on {_host}:{_port}[/green]")
    uvicorn.run("src.api.server:app", host=_host, port=_port, reload=reload)


@app.command()
def health() -> None:
    """Check API server health."""
    client = _http_client()
    try:
        resp = client.get("/v1/health")
        resp.raise_for_status()
        data = resp.json()
        console.print(f"[green]Server is healthy[/green]: {data}")
    except Exception as exc:
        console.print(f"[red]Server unreachable:[/red] {exc}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def init() -> None:
    """Initialize ReLoop in current directory — creates .env template and config."""
    env_path = Path(".env")
    config_path = Path("reloop.yaml")

    if env_path.exists():
        console.print("[yellow].env already exists — skipping.[/yellow]")
    else:
        env_path.write_text(
            "# ReLoop environment variables\n"
            "REDIS_URL=redis://localhost:6379\n"
            "REDIS_MEMORY_INDEX=reloop-failures\n"
            "OPENAI_API_KEY=\n"
            "BLAXEL_API_KEY=\n"
            "BLAXEL_WORKSPACE=\n"
            "API_PORT=8000\n"
            "API_HOST=0.0.0.0\n"
            "NEXT_PUBLIC_API_URL=http://localhost:8000\n"
            "MAX_RETRIES=5\n"
            "MAX_BUDGET_USD=1.00\n"
        )
        console.print("[green]Created .env template.[/green]")

    if config_path.exists():
        console.print("[yellow]reloop.yaml already exists — skipping.[/yellow]")
    else:
        default_config = Path(__file__).resolve().parents[2] / "reloop.yaml"
        if default_config.exists():
            shutil.copy(default_config, config_path)
            console.print("[green]Created reloop.yaml from default.[/green]")
        else:
            config_path.write_text(
                "# ReLoop configuration\n"
                "max_retries: 5\n"
                "max_budget_usd: 1.0\n"
                "circuit_breaker_threshold: 3\n"
            )
            console.print("[green]Created reloop.yaml.[/green]")

    console.print(Panel("ReLoop initialized. Edit .env with your API keys, then run [bold]reloop serve[/bold]."))


@app.command()
def demo() -> None:
    """Run the demo scenario (broken Next.js project with 4 bugs)."""
    from src.config import settings
    from src.core.agent import ReLoopAgent
    from src.models import Task as ReLoopTask
    from src.providers.memory.sqlite_backend import SQLiteMemoryBackend

    console.print(Panel("[bold]ReLoop Demo[/bold] — Broken Next.js project with 4 deliberate bugs"))

    async def _run_demo() -> None:
        memory = SQLiteMemoryBackend()
        await memory.initialize()
        agent = ReLoopAgent(memory=memory)

        task = ReLoopTask(
            instruction="Fix the broken Next.js project in data/demo-project that has 4 bugs: "
            "missing dependency (sharp), port conflict (3000), TypeScript error, and bad DATABASE_URL.",
            max_retries=settings.max_retries,
            max_budget_usd=settings.max_budget_usd,
        )
        console.print(f"[bold]Task:[/bold] {task.id}")

        result = await agent.run(task)
        status_color = "green" if result.status.value == "succeeded" else "red"
        console.print(f"[{status_color}]Result: {result.status.value}[/{status_color}]")
        console.print(f"  Attempts: {len(result.attempts)}")

    asyncio.run(_run_demo())


@app.command(name="export")
def export_playbook(
    output: str = typer.Option("reloop-playbook.yaml", "--output", "-o", help="Output file path"),
    fmt: FormatChoice = typer.Option(FormatChoice.yaml, "--format", "-f", help="Output format (yaml or json)"),
) -> None:
    """Export failure memories as a portable playbook."""
    client = _http_client()
    try:
        resp = client.get("/v1/memories/export")
        resp.raise_for_status()
        data = resp.json()

        failures = data.get("failures", [])

        # Override output extension to match format
        out_path = Path(output)
        if fmt == FormatChoice.json and out_path.suffix not in (".json",):
            out_path = out_path.with_suffix(".json")

        if fmt == FormatChoice.yaml:
            import yaml
            out_path.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))
        else:
            out_path.write_text(json.dumps(data, indent=2, default=str))

        console.print(f"Exported {len(failures)} failures to {out_path}")
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", style="bold red")
        raise typer.Exit(code=1)


@app.command(name="import")
def import_playbook(
    file: str = typer.Argument(..., help="Path to playbook file (YAML or JSON)"),
) -> None:
    """Import a failure playbook from a file."""
    file_path = Path(file)
    if not file_path.exists():
        console.print(f"[red]Error:[/red] File not found: {file}")
        raise typer.Exit(code=1)

    try:
        raw = file_path.read_text()
        if file_path.suffix in (".yaml", ".yml"):
            import yaml
            data = yaml.safe_load(raw)
        else:
            data = json.loads(raw)

        client = _http_client()
        resp = client.post("/v1/memories/import", json=data)
        resp.raise_for_status()
        result = resp.json()
        imported = result.get("imported", 0)
        console.print(f"Imported {imported} failures from {file_path}")
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def doctor() -> None:
    """Run environment checks and report readiness."""
    import os
    import sys

    from src.config import settings

    table = Table(title="ReLoop Doctor")
    table.add_column("Status", width=4)
    table.add_column("Check", style="cyan")
    table.add_column("Detail")

    # 1. Python version >= 3.11
    py_ver = sys.version_info
    py_ok = py_ver >= (3, 11)
    table.add_row(
        "[green]✅[/green]" if py_ok else "[red]❌[/red]",
        "Python >= 3.11",
        f"{py_ver.major}.{py_ver.minor}.{py_ver.micro}"
        if py_ok
        else f"{py_ver.major}.{py_ver.minor}.{py_ver.micro} — upgrade to 3.11+",
    )

    # 2. OPENAI_API_KEY set
    api_key = os.environ.get("OPENAI_API_KEY", "")
    key_ok = bool(api_key)
    table.add_row(
        "[green]✅[/green]" if key_ok else "[red]❌[/red]",
        "OPENAI_API_KEY",
        "set" if key_ok else "not set — export OPENAI_API_KEY=sk-...",
    )

    # 3. Redis reachable
    redis_ok = False
    redis_detail = settings.redis_url
    try:
        import redis as _redis

        client = _redis.from_url(settings.redis_url, socket_connect_timeout=2)
        client.ping()
        redis_ok = True
        redis_detail = f"{settings.redis_url} — reachable"
    except Exception as exc:
        redis_detail = f"{settings.redis_url} — {exc}"
    table.add_row(
        "[green]✅[/green]" if redis_ok else "[red]❌[/red]",
        "Redis",
        redis_detail,
    )

    # 4. Blaxel configured
    bl_key = os.environ.get("BLAXEL_API_KEY", "")
    bl_ok = bool(bl_key)
    table.add_row(
        "[green]✅[/green]" if bl_ok else "[red]❌[/red]",
        "Blaxel API Key",
        "set" if bl_ok else "not set — export BLAXEL_API_KEY=...",
    )

    # 5. Server reachable
    server_ok = False
    server_url = f"http://localhost:{settings.api_port}/v1/health"
    try:
        import httpx

        resp = httpx.get(server_url, timeout=2.0)
        resp.raise_for_status()
        server_ok = True
        server_detail = f"{server_url} — healthy"
    except Exception as exc:
        server_detail = f"{server_url} — {exc}"
    table.add_row(
        "[green]✅[/green]" if server_ok else "[red]❌[/red]",
        "API Server",
        server_detail,
    )

    console.print(table)

    # Exit with non-zero if any critical check failed
    if not py_ok or not key_ok:
        raise typer.Exit(code=1)


@app.command()
def version() -> None:
    """Show ReLoop version."""
    console.print("ReLoop v0.4.0")


if __name__ == "__main__":
    app()
