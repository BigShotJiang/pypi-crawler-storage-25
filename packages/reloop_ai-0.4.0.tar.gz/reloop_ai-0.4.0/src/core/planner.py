"""Planner — LLM-driven planning step for the REJD loop.

Before each execution attempt, the planner sends the task instruction and
accumulated failure history to the LLM, which returns a structured plan:
what strategy to use, which commands to run, and which anti-patterns to avoid.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field

from src.models import FailureRecord
from src.providers.base import LLMProvider

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------
# System prompt — the core planning orchestrator directive
# ------------------------------------------------------------------

_PLANNER_SYSTEM_PROMPT = """You are the planning orchestrator for ReLoop — a self-healing agent framework.

Your role is to decide, before each execution attempt, WHAT the agent should do next.

The ReLoop agent follows the REJD loop:
  RETRIEVE  — query failure memory for similar past failures
  EXECUTE   — run command(s) in an isolated sandbox
  JUDGE     — determine success or failure
  DISTILL   — extract learnings and store in memory
  REPEAT    — loop with accumulated knowledge until success or budget runs out

You receive:
  - The original task instruction
  - A list of previous failed attempts (what was tried, why it failed, anti-patterns)
  - The current retry attempt number
  - Any retrieved memories from similar past failures

You must output a JSON object with exactly these fields:
  {
    "strategy": "<one sentence describing the overall approach for this attempt>",
    "commands": ["<shell command 1>", "<shell command 2>", ...],
    "avoid_patterns": ["<anti-pattern 1>", "<anti-pattern 2>", ...],
    "confidence": <float between 0.0 and 1.0>
  }

Guidelines:
- If this is attempt 1 (no failure history), propose the most straightforward approach.
- If there are past failures, propose something DIFFERENT from what was tried before.
- The "commands" field should contain concrete, executable shell commands that address the task.
- The "avoid_patterns" field should list specific things NOT to do, derived from failure analysis.
- "confidence" should reflect how likely this plan is to succeed given the failure history (0.0 = uncertain, 1.0 = very confident).
- Be precise and actionable. Vague strategies like "try again" are not acceptable.
- If all previous failures point to the same root cause, ensure the strategy directly addresses it.
- Always output valid JSON. Do not include any text outside the JSON object.
"""


# ------------------------------------------------------------------
# PlanResult dataclass
# ------------------------------------------------------------------

@dataclass
class PlanResult:
    """Structured planning output from the LLM orchestrator."""
    strategy: str
    commands: list[str] = field(default_factory=list)
    avoid_patterns: list[str] = field(default_factory=list)
    confidence: float = 0.5
    cost_usd: float = 0.0

    def to_dict(self) -> dict:
        return {
            "strategy": self.strategy,
            "commands": self.commands,
            "avoid_patterns": self.avoid_patterns,
            "confidence": self.confidence,
        }


# ------------------------------------------------------------------
# Planner
# ------------------------------------------------------------------

class Planner:
    """Calls the LLM to decide the next action in the REJD loop.

    This is the strategic decision-maker that shapes every retry attempt.
    """

    def __init__(self, llm: LLMProvider) -> None:
        self._llm = llm

    async def plan_next_action(
        self,
        instruction: str,
        failure_history: list[FailureRecord],
        retry_context: dict,
    ) -> PlanResult:
        """Plan the next execution attempt.

        Sends the task instruction and all accumulated failure context to
        the LLM, which returns a structured plan specifying what strategy
        to use, which commands to run, and which patterns to avoid.

        Args:
            instruction: The original task instruction.
            failure_history: All FailureRecord objects from previous attempts.
            retry_context: The retry context dict from the RETRIEVE step,
                           including recalled_memories and anti_patterns.

        Returns:
            A PlanResult with strategy, commands, avoid_patterns, confidence.
            Falls back to a minimal plan if the LLM is unavailable.
        """
        prompt = self._build_planning_prompt(instruction, failure_history, retry_context)

        # Try orchestrate() first (structured flow), fall back to generate()
        try:
            if hasattr(self._llm, "orchestrate"):
                raw = await self._llm.orchestrate(  # type: ignore[union-attr]
                    instruction=instruction,
                    context={
                        "failure_history": [
                            {
                                "attempt": fr.attempt_number,
                                "error_type": fr.signature.error_type,
                                "root_cause": fr.analysis.root_cause,
                                "what_was_tried": fr.analysis.what_was_tried,
                                "why_it_failed": fr.analysis.why_it_failed,
                                "suggested_fix": fr.analysis.suggested_fix,
                                "anti_pattern": fr.analysis.anti_pattern,
                            }
                            for fr in failure_history
                        ],
                        "retry_attempt": len(failure_history) + 1,
                        "recalled_memories": retry_context.get("recalled_memories", ""),
                        "anti_patterns": retry_context.get("anti_patterns", []),
                        "prediction_warnings": retry_context.get("prediction_warnings", []),
                    },
                )
                return self._parse_orchestrate_result(raw, instruction)
        except Exception as exc:
            logger.warning("orchestrate() failed, falling back to generate(): %s", exc)

        # Fall back to generate() with the structured planning prompt
        try:
            response = await self._llm.generate(
                prompt=prompt,
                system=_PLANNER_SYSTEM_PROMPT,
                temperature=0.2,  # Low temperature for deterministic planning
            )
            result = self._parse_llm_response(response.content, instruction)
            result.cost_usd = response.cost_usd
            return result
        except Exception as exc:
            logger.warning("Planner.plan_next_action failed: %s", exc)
            return self._fallback_plan(instruction, failure_history)

    # ------------------------------------------------------------------
    # Prompt construction
    # ------------------------------------------------------------------

    def _build_planning_prompt(
        self,
        instruction: str,
        failure_history: list[FailureRecord],
        retry_context: dict,
    ) -> str:
        """Build the planning prompt with full failure context."""
        lines: list[str] = [
            f"TASK: {instruction}",
            "",
            f"ATTEMPT NUMBER: {len(failure_history) + 1}",
            "",
        ]

        if failure_history:
            lines.append(f"FAILURE HISTORY ({len(failure_history)} previous attempts):")
            for fr in failure_history:
                lines.extend([
                    f"  Attempt {fr.attempt_number}:",
                    f"    Error type:    {fr.signature.error_type}",
                    f"    Root cause:    {fr.analysis.root_cause}",
                    f"    What was tried: {fr.analysis.what_was_tried}",
                    f"    Why it failed:  {fr.analysis.why_it_failed}",
                    f"    Suggested fix:  {fr.analysis.suggested_fix}",
                ])
                if fr.analysis.anti_pattern:
                    lines.append(f"    Anti-pattern:   {fr.analysis.anti_pattern}")
                lines.append("")
        else:
            lines.extend([
                "FAILURE HISTORY: None (this is the first attempt)",
                "",
            ])

        recalled = retry_context.get("recalled_memories", "")
        if recalled:
            lines.extend([
                "CRITICAL — LEARNINGS FROM PAST FAILURES (apply these or you WILL fail):",
                str(recalled)[:1500],
                "",
            ])

        anti_patterns = retry_context.get("anti_patterns", [])
        if anti_patterns:
            lines.extend([
                "ANTI-PATTERNS — DO NOT repeat these mistakes:",
                *[f"  - {ap}" for ap in anti_patterns],
                "",
            ])

        prediction_warnings = retry_context.get("prediction_warnings", [])
        if prediction_warnings:
            lines.extend([
                "PREDICTED FAILURES (high probability — apply preventive fixes NOW):",
                *[f"  - {w}" for w in prediction_warnings],
                "",
            ])

        lines.extend([
            "Based on the above, output a JSON plan for the next attempt.",
            "The plan must directly address any known failures.",
            "Do not repeat strategies that have already failed.",
        ])

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Response parsing
    # ------------------------------------------------------------------

    def _parse_llm_response(self, content: str, instruction: str) -> PlanResult:
        """Parse the LLM's JSON response into a PlanResult."""
        if not content:
            return self._fallback_plan(instruction, [])

        # Extract JSON from the response (handle markdown code blocks)
        text = content.strip()
        if "```" in text:
            # Strip markdown code fences
            for fence in ("```json", "```"):
                text = text.replace(fence, "")
            text = text.strip()

        # Find the JSON object boundaries
        start = text.find("{")
        end = text.rfind("}") + 1
        if start == -1 or end == 0:
            logger.warning("No JSON object found in planner response; using fallback")
            return self._fallback_plan(instruction, [])

        try:
            data = json.loads(text[start:end])
        except json.JSONDecodeError as exc:
            logger.warning("Failed to parse planner JSON: %s", exc)
            return self._fallback_plan(instruction, [])

        strategy = str(data.get("strategy", "Execute the task as specified"))
        commands = [str(c) for c in data.get("commands", [instruction])]
        avoid_patterns = [str(p) for p in data.get("avoid_patterns", [])]
        confidence = float(data.get("confidence", 0.5))
        confidence = max(0.0, min(1.0, confidence))

        if not commands:
            commands = [instruction]

        return PlanResult(
            strategy=strategy,
            commands=commands,
            avoid_patterns=avoid_patterns,
            confidence=confidence,
        )

    def _parse_orchestrate_result(self, raw: dict, instruction: str) -> PlanResult:
        """Parse structured output from the orchestrate() method."""
        if not raw:
            return self._fallback_plan(instruction, [])

        strategy = str(raw.get("strategy", "Execute the task as specified"))
        commands = [str(c) for c in raw.get("commands", [instruction])]
        avoid_patterns = [str(p) for p in raw.get("avoid_patterns", [])]
        confidence = float(raw.get("confidence", 0.5))
        confidence = max(0.0, min(1.0, confidence))

        if not commands:
            commands = [instruction]

        return PlanResult(
            strategy=strategy,
            commands=commands,
            avoid_patterns=avoid_patterns,
            confidence=confidence,
        )

    # ------------------------------------------------------------------
    # Fallback
    # ------------------------------------------------------------------

    @staticmethod
    def _fallback_plan(instruction: str, failure_history: list[FailureRecord]) -> PlanResult:
        """Minimal fallback plan when the LLM planner is unavailable."""
        avoid: list[str] = []
        for fr in failure_history:
            if fr.analysis.anti_pattern:
                avoid.append(fr.analysis.anti_pattern)

        return PlanResult(
            strategy="Execute the task directly (planner unavailable)",
            commands=[instruction],
            avoid_patterns=avoid,
            confidence=0.3,
        )
