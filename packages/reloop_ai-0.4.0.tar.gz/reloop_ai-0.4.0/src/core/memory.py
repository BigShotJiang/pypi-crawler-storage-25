"""Failure Memory Graph — manages storage and retrieval of failure/success records."""

from __future__ import annotations

import logging
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any

from src.config import settings
from src.models import (
    ErrorSignature,
    FailureAnalysis,
    FailureRecord,
    MemoryStatsResponse,
    SuccessRecord,
)
from src.providers.base import LLMProvider, MemoryBackend

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Local embedding fallback -- uses LocalEmbedder (TF-IDF or BoW)
# ---------------------------------------------------------------------------

_local_embedder_instance: Any = None


def _get_local_embedder() -> Any:
    """Return a shared LocalEmbedder instance (lazy init)."""
    global _local_embedder_instance  # noqa: PLW0603
    if _local_embedder_instance is None:
        from src.providers.llm.local_embeddings import LocalEmbedder

        _local_embedder_instance = LocalEmbedder()
        logger.info(
            "memory: initialised local embedding fallback (method=%s)",
            _local_embedder_instance.method,
        )
    return _local_embedder_instance


def _local_embedding(text: str) -> list[float]:
    """Generate a local embedding using LocalEmbedder (TF-IDF or BoW).

    Returns a list of 1536 floats (unit-length), compatible with the
    OpenAI text-embedding-3-small dimension used by the Redis VECTOR index.
    """
    return _get_local_embedder().embed(text)


def _apply_confidence_decay(
    failures: list[FailureRecord],
    decay_rate: float = 0.1,
) -> list[FailureRecord]:
    """Apply time-based confidence decay to recalled failures.

    Older memories have their confidence reduced so recent learnings
    are prioritised. Decay formula: effective = original * max(0.1, 1 - rate * days_old).
    """
    now = datetime.now(timezone.utc)
    for f in failures:
        age_days = (now - f.timestamp).total_seconds() / 86400
        decay_factor = max(0.1, 1.0 - decay_rate * age_days)
        f.analysis.confidence = round(f.analysis.confidence * decay_factor, 3)
    # Re-sort by decayed confidence (highest first)
    failures.sort(key=lambda f: f.analysis.confidence, reverse=True)
    return failures


class FailureMemoryManager:
    """Wraps a MemoryBackend to provide high-level failure memory operations."""

    def __init__(self, backend: MemoryBackend, llm: LLMProvider | None = None) -> None:
        self._backend = backend
        self._llm = llm

    async def recall(
        self,
        error_type: str,
        error_message: str,
        limit: int = 5,
    ) -> list[FailureRecord]:
        """Return similar past failures with confidence decay applied."""
        try:
            # Attempt to generate an embedding for semantic search
            query_text = f"{error_type}: {error_message}"
            query_embedding: list[float] | None = None
            if self._llm is not None:
                try:
                    query_embedding = await self._llm.embed(query_text)
                except Exception:
                    logger.debug(
                        "embed() failed for recall query; using local embedding fallback"
                    )
            # Fall back to local embedding when API embedding is unavailable or empty
            if not query_embedding:
                query_embedding = _local_embedding(query_text)
                logger.debug("Using local embedding fallback for recall query")

            failures = await self._backend.get_similar_failures(
                error_type=error_type,
                error_message=error_message,
                limit=limit * 2,  # fetch extra so we have good ones after decay
                embedding=query_embedding,
            )
            # Apply confidence decay — old memories score lower
            failures = _apply_confidence_decay(
                failures,
                decay_rate=settings.confidence_decay_rate
                if hasattr(settings, "confidence_decay_rate")
                else 0.1,
            )
            # Return top N after decay re-ranking
            failures = failures[:limit]
            logger.debug(
                "Recalled %d similar failures for error_type=%r (with confidence decay)",
                len(failures),
                error_type,
            )
            return failures
        except Exception:
            logger.exception(
                "Failed to recall memories for error_type=%r", error_type
            )
            return []

    async def store_failure(
        self,
        task_id: str,
        attempt_number: int,
        signature: ErrorSignature,
        analysis: FailureAnalysis,
        context: dict[str, Any],
        cost: float,
        transferable: bool = True,
    ) -> FailureRecord:
        """Create and persist a FailureRecord; returns the stored record."""
        record = FailureRecord(
            task_id=task_id,
            attempt_number=attempt_number,
            signature=signature,
            analysis=analysis,
            context=context,
            cost_usd=cost,
            transferable=transferable,
        )
        # Generate embedding for semantic search
        embed_text = (
            f"{signature.error_type}: {signature.error_message} "
            f"{analysis.root_cause}"
        )
        if self._llm is not None:
            try:
                record.embedding = await self._llm.embed(embed_text)
            except Exception:
                logger.debug(
                    "embed() failed for task_id=%s attempt=%d; using local fallback",
                    task_id,
                    attempt_number,
                )
        # Fall back to local embedding when API embedding is unavailable or empty
        if not record.embedding:
            record.embedding = _local_embedding(embed_text)
            logger.debug(
                "Using local embedding fallback for task_id=%s attempt=%d",
                task_id,
                attempt_number,
            )
        try:
            record_id = await self._backend.store_failure(record)
            logger.info(
                "Stored failure record id=%s for task_id=%s attempt=%d",
                record_id,
                task_id,
                attempt_number,
            )
        except Exception:
            logger.exception(
                "Failed to store failure for task_id=%s attempt=%d",
                task_id,
                attempt_number,
            )
        return record

    async def store_success(
        self,
        task_id: str,
        attempt_number: int,
        solution: dict[str, str],
        learning: dict[str, Any],
        metrics: dict[str, Any],
    ) -> SuccessRecord:
        """Create and persist a SuccessRecord; returns the stored record."""
        record = SuccessRecord(
            task_id=task_id,
            attempt_number=attempt_number,
            solution=solution,
            learning=learning,
            metrics=metrics,
        )
        try:
            record_id = await self._backend.store_success(record)
            logger.info(
                "Stored success record id=%s for task_id=%s attempt=%d",
                record_id,
                task_id,
                attempt_number,
            )
        except Exception:
            logger.exception(
                "Failed to store success for task_id=%s attempt=%d",
                task_id,
                attempt_number,
            )
        return record

    def build_memory_context(self, failures: list[FailureRecord]) -> str:
        """Format recalled failures into a prompt string for the LLM.

        Returns a multi-line string describing past failures with root causes
        and suggested fixes so the LLM can avoid repeating the same mistakes.
        """
        if not failures:
            return ""

        lines: list[str] = ["Previous failures encountered:"]
        for i, record in enumerate(failures, start=1):
            sig = record.signature
            ana = record.analysis
            line = (
                f"{i}. [{sig.error_type}] {sig.error_message} "
                f"— Root cause: {ana.root_cause} "
                f"— Fix: {ana.suggested_fix}"
            )
            if ana.anti_pattern:
                line += f" — Anti-pattern: {ana.anti_pattern}"
            lines.append(line)

        return "\n".join(lines)

    async def get_stats(self) -> MemoryStatsResponse:
        """Delegate to the backend for aggregate memory statistics."""
        try:
            return await self._backend.get_stats()
        except Exception:
            logger.exception("Failed to get memory stats")
            return MemoryStatsResponse(
                total_failures=0,
                total_successes=0,
                top_error_categories={},
                avg_confidence=0.0,
            )

    async def search_cross_project(
        self,
        query: str,
        exclude_task_id: str | None = None,
        limit: int = 5,
    ) -> list[FailureRecord]:
        """Search ALL failures across all task IDs (cross-project transfer).

        Returns only transferable failures ranked by similarity and confidence.
        This enables memories from Project A to help Project B succeed faster.

        Args:
            query: Natural-language description of the error or problem.
            exclude_task_id: Optional task ID to exclude from results (avoids
                returning failures from the caller's own task).
            limit: Maximum number of results to return.
        """
        try:
            # Fetch extra candidates so we have enough after filtering
            candidates = await self._backend.search(
                query=query,
                limit=limit * 4,
            )

            # Filter to transferable only, optionally excluding a task
            filtered: list[FailureRecord] = []
            for record in candidates:
                if not record.transferable:
                    continue
                if exclude_task_id and record.task_id == exclude_task_id:
                    continue
                filtered.append(record)

            # Apply confidence decay so recent learnings rank higher
            filtered = _apply_confidence_decay(
                filtered,
                decay_rate=settings.confidence_decay_rate
                if hasattr(settings, "confidence_decay_rate")
                else 0.1,
            )

            return filtered[:limit]
        except Exception:
            logger.exception(
                "Cross-project search failed for query=%r", query
            )
            return []

    async def predict_likely_failures(
        self,
        instruction: str,
        context: dict[str, str] | None = None,
        limit: int = 3,
    ) -> list[dict[str, Any]]:
        """Predict failures likely to occur before execution begins (pre-mortem).

        Searches failure memory using the instruction text and any context values
        (e.g. framework name, language). For each matching failure, a prediction
        score is calculated as: confidence * (matches / total_records).

        Returns a list of dicts sorted by prediction_score descending, deduplicated
        by error_type.
        """
        # Gather total record count for normalisation
        try:
            stats = await self._backend.get_stats()
            total_records = max(stats.total_failures, 1)  # avoid division by zero
        except Exception:
            logger.debug("predict_likely_failures: could not fetch stats; using total=1")
            total_records = 1

        # Build a list of search queries: instruction + individual context values
        queries: list[str] = [instruction]
        if context:
            for value in context.values():
                if value and value.strip():
                    queries.append(value.strip())

        # Run all searches and collect raw failures
        all_failures: list[FailureRecord] = []
        for query in queries:
            try:
                results = await self._backend.search(query=query, limit=limit * 4)
                all_failures.extend(results)
            except Exception:
                logger.debug(
                    "predict_likely_failures: search failed for query=%r", query
                )

        if not all_failures:
            return []

        # Group by error_type, merging multiple records into a single prediction
        # Score formula: confidence * (hit_count / total_records)
        grouped: dict[str, dict[str, Any]] = defaultdict(
            lambda: {
                "error_type": "",
                "hit_count": 0,
                "total_confidence": 0.0,
                "root_cause": "",
                "suggested_prevention": "",
                "based_on_failures": 0,
            }
        )

        seen_ids: set[str] = set()
        for record in all_failures:
            if record.id in seen_ids:
                continue
            seen_ids.add(record.id)

            et = record.signature.error_type
            entry = grouped[et]
            entry["error_type"] = et
            entry["hit_count"] += 1
            entry["total_confidence"] += record.analysis.confidence
            entry["based_on_failures"] = entry["hit_count"]
            # Keep the most recent (highest confidence) root_cause / prevention text
            if record.analysis.confidence >= (
                entry["total_confidence"] / entry["hit_count"]
            ):
                entry["root_cause"] = record.analysis.root_cause
                entry["suggested_prevention"] = (
                    record.analysis.suggested_fix or record.analysis.anti_pattern
                )

        predictions: list[dict[str, Any]] = []
        for et, entry in grouped.items():
            hit_count = entry["hit_count"]
            avg_confidence = entry["total_confidence"] / hit_count
            prediction_score = round(
                avg_confidence * (hit_count / total_records), 4
            )
            # Clamp to [0, 1]
            prediction_score = min(1.0, max(0.0, prediction_score))
            predictions.append(
                {
                    "error_type": et,
                    "prediction_score": prediction_score,
                    "root_cause": entry["root_cause"],
                    "suggested_prevention": entry["suggested_prevention"],
                    "based_on_failures": hit_count,
                }
            )

        predictions.sort(key=lambda p: p["prediction_score"], reverse=True)
        return predictions[:limit]
