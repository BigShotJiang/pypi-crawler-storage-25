"""Memory-Informed Retry Engine — decides when to retry and prepares rich context."""

from __future__ import annotations

import logging
from typing import Any

from src.models import CircuitBreakerState, ErrorSignature, FailureRecord, Task
from src.core.memory import FailureMemoryManager

logger = logging.getLogger(__name__)


class RetryEngine:
    """Decides whether a task should be retried and prepares memory-enriched context.

    Circuit breaker logic: if the last N consecutive failures all share the
    same error_hash, the circuit is considered open and retries are stopped.
    """

    def __init__(
        self,
        memory: FailureMemoryManager,
        max_retries: int = 5,
        max_budget_usd: float = 1.0,
        circuit_breaker_threshold: int = 3,
    ) -> None:
        self._memory = memory
        self._max_retries = max_retries
        self._max_budget_usd = max_budget_usd
        self._circuit_breaker_threshold = circuit_breaker_threshold

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def should_retry(self, task: Task) -> bool:
        """Return True if the task is eligible for another attempt.

        Checks (in order):
        1. Retry count — current_attempt must be < max_retries.
        2. Budget — total_cost_usd must be < max_budget_usd.
        3. Circuit breaker — last N attempts must NOT all share the same
           error_hash (prevents hammering the same unrecoverable error).
        """
        # Use task-level overrides if they differ from engine defaults; the
        # engine defaults serve as a system-wide ceiling.
        effective_max_retries = min(task.max_retries, self._max_retries)
        effective_max_budget = min(task.max_budget_usd, self._max_budget_usd)

        if task.current_attempt >= effective_max_retries:
            logger.info(
                "task_id=%s: retry denied — attempt %d >= max_retries %d",
                task.id,
                task.current_attempt,
                effective_max_retries,
            )
            return False

        if task.total_cost_usd >= effective_max_budget:
            logger.info(
                "task_id=%s: retry denied — cost $%.4f >= budget $%.4f",
                task.id,
                task.total_cost_usd,
                effective_max_budget,
            )
            return False

        if self._circuit_is_open(task):
            logger.info(
                "task_id=%s: retry denied — circuit breaker open after %d identical failures",
                task.id,
                self._circuit_breaker_threshold,
            )
            return False

        return True

    async def prepare_retry_context(
        self,
        task: Task,
        last_error: ErrorSignature,
    ) -> dict[str, Any]:
        """Build a rich context dict that the REJD loop injects into the next attempt.

        Queries failure memory for similar past failures and distills them into:
        - ``recalled_memories`` — formatted string for LLM consumption
        - ``anti_patterns`` — list of patterns the LLM should avoid
        - ``raw_failures`` — raw FailureRecord objects for further processing
        - ``error_signature`` — the error that triggered this retry
        """
        similar_failures: list[FailureRecord] = await self._memory.recall(
            error_type=last_error.error_type,
            error_message=last_error.error_message,
            limit=5,
        )

        memory_context_str = self._memory.build_memory_context(similar_failures)

        anti_patterns: list[str] = [
            record.analysis.anti_pattern
            for record in similar_failures
            if record.analysis.anti_pattern
        ]

        logger.debug(
            "task_id=%s: prepared retry context with %d similar failures",
            task.id,
            len(similar_failures),
        )

        return {
            "recalled_memories": memory_context_str,
            "anti_patterns": anti_patterns,
            "raw_failures": similar_failures,
            "error_signature": last_error.model_dump(),
            "attempt_number": task.current_attempt,
            "total_cost_usd": task.total_cost_usd,
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _circuit_is_open(self, task: Task) -> bool:
        """Return True if the last N consecutive attempts all have the same error hash.

        We extract error hashes from attempts that carry a failure_record_id
        **and** whose last step has a non-empty error field, falling back to
        checking the attempt's failure_record_id metadata stored in task context.

        In practice the REJD loop stamps each attempt's failure_record_id once
        the failure has been distilled and stored.  We use the last N attempts
        that actually failed (have a failure_record_id) and compare the error
        signatures stored in the task's metadata dict keyed by attempt number.
        """
        threshold = self._circuit_breaker_threshold
        if len(task.attempts) < threshold:
            return False

        # Walk the last `threshold` failed attempts in reverse order.
        failed_attempts = [
            a for a in task.attempts if a.failure_record_id is not None
        ]
        if len(failed_attempts) < threshold:
            return False

        recent = failed_attempts[-threshold:]

        # Retrieve the error hashes stored by the REJD loop in task.metadata.
        # Key format: "attempt_{n}_error_hash"
        hashes: list[str] = []
        for attempt in recent:
            key = f"attempt_{attempt.attempt_number}_error_hash"
            h = task.metadata.get(key, "")
            if not h:
                # Fall back: check the last step's error text for a stable signal.
                if attempt.steps:
                    last_step = attempt.steps[-1]
                    h = last_step.error or ""
            hashes.append(h)

        if not hashes or any(h == "" for h in hashes):
            return False

        return len(set(hashes)) == 1

    def get_circuit_breaker_state(self, task: Task) -> CircuitBreakerState:
        """Return a CircuitBreakerState describing the current circuit breaker status.

        If the last N consecutive failed attempts share the same error hash
        (where N >= circuit_breaker_threshold), the circuit is OPEN and the
        returned state describes the repeated error and a recommended action.
        """
        threshold = self._circuit_breaker_threshold
        failed_attempts = [a for a in task.attempts if a.failure_record_id is not None]

        if len(failed_attempts) < threshold:
            return CircuitBreakerState()

        recent = failed_attempts[-threshold:]

        hashes: list[str] = []
        error_type: str = ""
        for attempt in recent:
            key = f"attempt_{attempt.attempt_number}_error_hash"
            h = task.metadata.get(key, "")
            if not h and attempt.steps:
                h = attempt.steps[-1].error or ""
            hashes.append(h)
            # Capture error_type from the last attempt's metadata if available
            if not error_type:
                error_type = task.metadata.get(
                    f"attempt_{attempt.attempt_number}_error_type", ""
                )

        if not hashes or any(h == "" for h in hashes) or len(set(hashes)) != 1:
            return CircuitBreakerState()

        repeated_hash = hashes[0]
        consecutive = len(recent)
        recommendation = self._recommendation_for_error_type(error_type)

        return CircuitBreakerState(
            is_open=True,
            reason=(
                f"Agent has failed {consecutive} consecutive times with the same error"
            ),
            consecutive_same_error=consecutive,
            error_hash=repeated_hash,
            error_type=error_type,
            recommendation=recommendation,
        )

    # ------------------------------------------------------------------
    # Private recommendation helper
    # ------------------------------------------------------------------

    @staticmethod
    def _recommendation_for_error_type(error_type: str) -> str:
        """Return human-readable advice based on the error type string."""
        et = error_type.lower()
        if "dependency" in et or "modulenotfounderror" in et or "importerror" in et:
            return (
                "This suggests a fundamental issue that retrying won't fix. "
                "Check: missing package installation (run `pip install` or `npm install`), "
                "incorrect import path, or a typo in the dependency name."
            )
        if "permission" in et or "permissionerror" in et:
            return (
                "This suggests a fundamental issue that retrying won't fix. "
                "Check: file or directory permissions, sudo requirements, "
                "or read-only filesystem mounts."
            )
        if "timeout" in et or "timeouterror" in et:
            return (
                "This suggests a fundamental issue that retrying won't fix. "
                "Check: network connectivity, upstream service availability, "
                "or increase the timeout threshold in configuration."
            )
        if "type" in et or "typeerror" in et or "attributeerror" in et:
            return (
                "This suggests a fundamental issue that retrying won't fix. "
                "Check: type mismatches in the code, wrong API usage, "
                "or an unexpected None value being accessed."
            )
        if "config" in et or "valueerror" in et or "environment" in et:
            return (
                "This suggests a fundamental issue that retrying won't fix. "
                "Check: environment variables, configuration files, "
                "or invalid parameter values passed to the agent."
            )
        if "network" in et or "connectionerror" in et or "urlerror" in et:
            return (
                "This suggests a fundamental issue that retrying won't fix. "
                "Check: network connectivity, firewall rules, DNS resolution, "
                "or whether the target service is running."
            )
        return (
            "This suggests a fundamental issue that retrying won't fix. "
            "Check: the task instructions for ambiguity, sandbox environment "
            "health, and whether the required resources are available."
        )
