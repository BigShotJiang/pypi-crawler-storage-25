"""Failure/Success Distillation — uses an LLM to extract structured learnings."""

from __future__ import annotations

import json
import logging
from typing import Any

from src.models import (
    Attempt,
    ErrorCategory,
    FailureAnalysis,
    Task,
)
from src.providers.base import LLMProvider

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Prompt templates (module-level constants)
# ---------------------------------------------------------------------------

FAILURE_DISTILLATION_PROMPT = """\
You are an expert software debugger. Analyse the following failed command execution and produce a structured failure report.

## Command
{command}

## Output
{output}

## Error
{error}

## Additional Context
{context}

Respond with a JSON object containing exactly these fields:
- "root_cause": str — the fundamental reason the command failed
- "what_was_tried": str — a concise description of what the command attempted
- "why_it_failed": str — the specific mechanism of the failure
- "suggested_fix": str — the most actionable fix to try next
- "anti_pattern": str — a pattern/approach to avoid in future attempts (empty string if none)
- "confidence": float between 0.0 and 1.0 — how confident you are in this analysis
- "transferable": bool — true if this lesson is generic and applies across projects (e.g. missing dependencies, config issues, port conflicts, env vars), false if it is specific to exact file content or line numbers

Return only valid JSON, no markdown fences, no extra text.
"""

SUCCESS_DISTILLATION_PROMPT = """\
You are an expert software engineer. Summarise what made the following task succeed after multiple attempts.

## Task Instruction
{instruction}

## Attempts Summary
{attempts_summary}

Respond with a JSON object containing exactly these fields:
- "approach": str — the high-level approach that ultimately worked
- "key_insight": str — the most important insight that led to success
- "failures_that_helped": list[str] — short descriptions of failures that guided the solution
- "transferable": bool — whether this learning applies to other similar tasks

Return only valid JSON, no markdown fences, no extra text.
"""

ERROR_CLASSIFICATION_PROMPT = """\
Classify the following error into exactly one of these categories:
- dependency_error
- runtime_error
- config_error
- type_error
- network_error
- permission_error
- timeout_error
- unknown

Error type: {error_type}
Error message: {error_message}

Respond with a JSON object: {{"category": "<one of the categories above>"}}
Return only valid JSON, no markdown fences, no extra text.
"""

# Mapping of lowercase keywords to ErrorCategory values used in fallback logic.
_KEYWORD_CATEGORY_MAP: list[tuple[list[str], ErrorCategory]] = [
    (
        [
            "module not found", "cannot find module", "no such module",
            "import error", "modulenotfounderror", "importerror",
            "no module named", "package.json",
            "npm error", "npm err", "enoent", "not installed",
            "missing dependency", "peer dep", "could not resolve",
            "cannot find package", "sharp", "missing script",
        ],
        ErrorCategory.DEPENDENCY_ERROR,
    ),
    (
        [
            "type error", "typeerror", "type mismatch",
            "is not assignable to", "ts(", "typescript",
            "expected string", "expected number", "cannot read propert",
            "attributeerror", "nameerror",
        ],
        ErrorCategory.TYPE_ERROR,
    ),
    (
        [
            "config", "configuration", "environment variable",
            "env var", "eaddrinuse", "port", "address already in use",
            "database_url", "connection refused", "econnrefused",
            ".env", "invalid option", "bad config",
            "filenotfounderror", "enverror",
        ],
        ErrorCategory.CONFIG_ERROR,
    ),
    (
        [
            "runtime error", "runtimeerror", "segfault",
            "stack overflow", "heap", "killed", "oom",
            "exit code", "exit status", "signal",
            "uncaught exception", "unhandled rejection",
            "oserror", "ioerror", "systemexit", "exception",
        ],
        ErrorCategory.RUNTIME_ERROR,
    ),
    (
        [
            "network", "timeout", "econnreset", "dns",
            "fetch failed", "socket hang up", "etimeout",
            "connectionerror", "networkerror", "ssl", "enetunreach",
        ],
        ErrorCategory.NETWORK_ERROR,
    ),
    (
        [
            "permission denied", "eacces", "eperm",
            "not permitted", "access denied", "forbidden",
            "permissionerror",
        ],
        ErrorCategory.PERMISSION_ERROR,
    ),
    (
        [
            "timed out", "timeout", "deadline exceeded",
            "operation timed out", "timeouterror",
        ],
        ErrorCategory.TIMEOUT_ERROR,
    ),
]


class Distiller:
    """Uses an LLM to turn raw execution failures/successes into structured learnings."""

    def __init__(self, llm: LLMProvider) -> None:
        self._llm = llm

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def distill_failure(
        self,
        command: str,
        output: str,
        error: str,
        context: dict[str, Any] | None = None,
    ) -> tuple[FailureAnalysis, float, bool]:
        """Analyse a failed execution and return (FailureAnalysis, cost_usd, transferable).

        The *transferable* flag indicates whether the lesson is generic enough
        to help other projects (e.g. dependency errors, config issues, port
        conflicts) vs. specific to exact file content or line numbers.
        """
        context_str = json.dumps(context or {}, indent=2)
        prompt = FAILURE_DISTILLATION_PROMPT.format(
            command=command,
            output=output or "(no output)",
            error=error or "(no error text)",
            context=context_str,
        )
        try:
            response = await self._llm.generate(prompt=prompt, temperature=0.2)
            data = self._parse_json(response.content)
            transferable = bool(data.get("transferable", True))
            return FailureAnalysis(
                root_cause=data.get("root_cause", "Unknown root cause"),
                what_was_tried=data.get("what_was_tried", command),
                why_it_failed=data.get("why_it_failed", error),
                suggested_fix=data.get("suggested_fix", ""),
                anti_pattern=data.get("anti_pattern", ""),
                confidence=float(data.get("confidence", 0.7)),
            ), response.cost_usd, transferable
        except Exception:
            logger.exception("distill_failure failed; returning minimal analysis")
            # When LLM fails, use keyword heuristic for transferability
            transferable = self._is_transferable_by_keywords(error)
            return FailureAnalysis(
                root_cause="LLM distillation failed — see raw error",
                what_was_tried=command,
                why_it_failed=error,
                suggested_fix="Investigate the raw error output manually",
                anti_pattern="",
                confidence=0.3,
            ), 0.0, transferable

    @staticmethod
    def _is_transferable_by_keywords(error_text: str) -> bool:
        """Heuristic: generic errors (deps, config, ports, env) are transferable."""
        generic_keywords = [
            "module not found", "not installed", "missing dependency",
            "eaddrinuse", "port", "address already in use",
            "environment variable", "env var", "database_url",
            "connection refused", "config", "permission denied",
            "npm err", "pip install", "package.json",
        ]
        lower = error_text.lower()
        return any(kw in lower for kw in generic_keywords)

    async def distill_success(
        self,
        task: Task,
        attempts: list[Attempt],
    ) -> tuple[dict[str, Any], float]:
        """Summarise what approach worked. Returns (summary_dict, cost_usd)."""
        attempts_summary = self._format_attempts_summary(attempts)
        prompt = SUCCESS_DISTILLATION_PROMPT.format(
            instruction=task.instruction,
            attempts_summary=attempts_summary,
        )
        try:
            response = await self._llm.generate(prompt=prompt, temperature=0.3)
            data = self._parse_json(response.content)
            return {
                "approach": data.get("approach", ""),
                "key_insight": data.get("key_insight", ""),
                "failures_that_helped": data.get("failures_that_helped", []),
                "transferable": bool(data.get("transferable", True)),
                "total_attempts": len(attempts),
            }, response.cost_usd
        except Exception:
            logger.exception("distill_success failed; returning minimal summary")
            return {
                "approach": "Unknown — LLM distillation failed",
                "key_insight": "",
                "failures_that_helped": [],
                "transferable": False,
                "total_attempts": len(attempts),
            }, 0.0

    async def classify_error(
        self,
        error_type: str,
        error_message: str,
    ) -> tuple[ErrorCategory, float]:
        """Classify an error into an ErrorCategory. Returns (category, cost_usd)."""
        prompt = ERROR_CLASSIFICATION_PROMPT.format(
            error_type=error_type,
            error_message=error_message,
        )
        try:
            response = await self._llm.generate(prompt=prompt, temperature=0.0)
            data = self._parse_json(response.content)
            category_str = data.get("category", "unknown")
            return ErrorCategory(category_str), response.cost_usd
        except Exception:
            logger.warning(
                "classify_error LLM call failed; falling back to keyword heuristics"
            )
            return self._classify_by_keywords(error_type, error_message), 0.0

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_json(text: str) -> dict[str, Any]:
        """Extract the first valid JSON object from an LLM response string."""
        text = text.strip()
        # Strip common markdown code fences if present.
        if text.startswith("```"):
            lines = text.splitlines()
            # Drop first and last fence lines.
            text = "\n".join(lines[1:-1] if lines[-1].startswith("```") else lines[1:])
            text = text.strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            # Attempt to find a JSON object substring.
            start = text.find("{")
            end = text.rfind("}") + 1
            if start != -1 and end > start:
                return json.loads(text[start:end])
            raise

    @staticmethod
    def _format_attempts_summary(attempts: list[Attempt]) -> str:
        """Format attempts as a readable summary string for the LLM prompt."""
        lines: list[str] = []
        for attempt in attempts:
            status_label = attempt.status.value
            step_errors = [
                s.error for s in attempt.steps if s.error
            ]
            error_summary = "; ".join(step_errors) if step_errors else "no errors"
            lines.append(
                f"Attempt {attempt.attempt_number} [{status_label}]: {error_summary}"
            )
        return "\n".join(lines) if lines else "No attempts recorded."

    @staticmethod
    def _classify_by_keywords(error_type: str, error_message: str) -> ErrorCategory:
        """Keyword-based fallback classifier when the LLM is unavailable."""
        combined = (error_type + " " + error_message).lower()
        for keywords, category in _KEYWORD_CATEGORY_MAP:
            if any(kw in combined for kw in keywords):
                return category
        return ErrorCategory.UNKNOWN
