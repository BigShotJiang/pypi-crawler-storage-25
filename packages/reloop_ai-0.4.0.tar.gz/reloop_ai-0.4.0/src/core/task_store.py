"""SQLite-backed task persistence — tasks survive server restarts."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

import aiosqlite

from src.models import Task

logger = logging.getLogger(__name__)

_DEFAULT_DB = "reloop_tasks.db"


class TaskStore:
    """Async SQLite store for tasks and timeline events."""

    def __init__(self, db_path: str = _DEFAULT_DB) -> None:
        self._db_path = db_path
        self._db: aiosqlite.Connection | None = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def init(self) -> None:
        """Open the database and create tables if they don't exist."""
        self._db = await aiosqlite.connect(self._db_path)
        await self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS tasks (
                id          TEXT PRIMARY KEY,
                instruction TEXT NOT NULL,
                status      TEXT NOT NULL,
                result      TEXT,
                metadata    TEXT NOT NULL DEFAULT '{}',
                created_at  TEXT NOT NULL,
                updated_at  TEXT NOT NULL,
                full_json   TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS timeline_events (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id    TEXT NOT NULL,
                event_type TEXT NOT NULL,
                data       TEXT NOT NULL DEFAULT '{}',
                timestamp  TEXT NOT NULL
            );
            """
        )
        await self._db.commit()
        logger.info("TaskStore initialised (db=%s)", self._db_path)

    async def close(self) -> None:
        """Close the database connection."""
        if self._db is not None:
            await self._db.close()
            self._db = None

    # ------------------------------------------------------------------
    # Task CRUD
    # ------------------------------------------------------------------

    async def save_task(self, task: Task) -> None:
        """Insert or update (upsert) a task."""
        assert self._db is not None, "TaskStore not initialised"
        now = datetime.now(timezone.utc).isoformat()
        full_json = task.model_dump_json()
        await self._db.execute(
            """
            INSERT INTO tasks (id, instruction, status, result, metadata,
                               created_at, updated_at, full_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                status     = excluded.status,
                result     = excluded.result,
                metadata   = excluded.metadata,
                updated_at = excluded.updated_at,
                full_json  = excluded.full_json
            """,
            (
                task.id,
                task.instruction,
                task.status.value,
                task.result,
                json.dumps(task.metadata),
                task.created_at.isoformat() if task.created_at else now,
                now,
                full_json,
            ),
        )
        await self._db.commit()

    async def get_task(self, task_id: str) -> Task | None:
        """Load a single task by ID, or return None."""
        assert self._db is not None, "TaskStore not initialised"
        async with self._db.execute(
            "SELECT full_json FROM tasks WHERE id = ?", (task_id,)
        ) as cursor:
            row = await cursor.fetchone()
        if row is None:
            return None
        return Task.model_validate_json(row[0])

    async def list_tasks(self) -> list[Task]:
        """Return all persisted tasks."""
        assert self._db is not None, "TaskStore not initialised"
        tasks: list[Task] = []
        async with self._db.execute(
            "SELECT full_json FROM tasks ORDER BY created_at"
        ) as cursor:
            async for row in cursor:
                tasks.append(Task.model_validate_json(row[0]))
        return tasks

    # ------------------------------------------------------------------
    # Timeline events
    # ------------------------------------------------------------------

    async def append_event(
        self,
        task_id: str,
        event_type: str,
        data: dict[str, Any],
        timestamp: str,
    ) -> None:
        """Append a timeline event for a task."""
        assert self._db is not None, "TaskStore not initialised"
        await self._db.execute(
            """
            INSERT INTO timeline_events (task_id, event_type, data, timestamp)
            VALUES (?, ?, ?, ?)
            """,
            (task_id, event_type, json.dumps(data), timestamp),
        )
        await self._db.commit()

    async def get_events(self, task_id: str) -> list[dict[str, Any]]:
        """Return all timeline events for a task, ordered by insertion."""
        assert self._db is not None, "TaskStore not initialised"
        events: list[dict[str, Any]] = []
        async with self._db.execute(
            "SELECT task_id, event_type, data, timestamp "
            "FROM timeline_events WHERE task_id = ? ORDER BY id",
            (task_id,),
        ) as cursor:
            async for row in cursor:
                events.append(
                    {
                        "task_id": row[0],
                        "event_type": row[1],
                        "data": json.loads(row[2]),
                        "timestamp": row[3],
                    }
                )
        return events
