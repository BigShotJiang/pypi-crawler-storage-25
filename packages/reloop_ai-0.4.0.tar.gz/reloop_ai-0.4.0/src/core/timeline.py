"""Event Timeline Manager — stores, retrieves, and streams TimelineEvent objects."""

from __future__ import annotations

import asyncio
import json
import logging
from collections import defaultdict
from typing import Any, AsyncIterator

from src.models import TimelineEvent, TimelineEventType

logger = logging.getLogger(__name__)


class TimelineManager:
    """In-memory timeline of events with SSE streaming support."""

    def __init__(self) -> None:
        # task_id -> list[TimelineEvent] (append-only)
        self._events: dict[str, list[TimelineEvent]] = defaultdict(list)
        # task_id -> list of subscriber queues
        self._subscribers: dict[str, list[asyncio.Queue[TimelineEvent | None]]] = defaultdict(list)

    # ------------------------------------------------------------------
    # Event emission
    # ------------------------------------------------------------------

    def emit(
        self,
        task_id: str,
        event_type: TimelineEventType,
        attempt_number: int = 0,
        step_number: int = 0,
        data: dict[str, Any] | None = None,
        message: str = "",
    ) -> TimelineEvent:
        """Create, store, and broadcast a TimelineEvent.

        Returns the newly created event so callers can inspect it if needed.
        """
        event = TimelineEvent(
            task_id=task_id,
            event_type=event_type,
            attempt_number=attempt_number,
            step_number=step_number,
            data=data or {},
            message=message,
        )
        self._events[task_id].append(event)

        # Notify all active subscribers for this task.
        dead_queues: list[asyncio.Queue[TimelineEvent | None]] = []
        for queue in self._subscribers[task_id]:
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                logger.warning(
                    "SSE subscriber queue full for task_id=%s; dropping event", task_id
                )
            except Exception:
                logger.exception("Unexpected error notifying SSE subscriber")
                dead_queues.append(queue)

        for q in dead_queues:
            self._subscribers[task_id].remove(q)

        logger.debug(
            "Emitted event type=%s for task_id=%s attempt=%d",
            event_type.value,
            task_id,
            attempt_number,
        )
        return event

    # ------------------------------------------------------------------
    # Retrieval
    # ------------------------------------------------------------------

    def get_timeline(self, task_id: str) -> list[TimelineEvent]:
        """Return all events for a task, sorted chronologically by timestamp."""
        events = self._events.get(task_id, [])
        return sorted(events, key=lambda e: e.timestamp)

    # ------------------------------------------------------------------
    # SSE streaming
    # ------------------------------------------------------------------

    async def subscribe(self, task_id: str) -> AsyncIterator[TimelineEvent]:
        """Async generator that yields new TimelineEvents as they are emitted.

        Immediately yields all existing events for the task so that late
        subscribers catch up, then streams new ones in real-time.

        Terminates when a ``None`` sentinel is put into the queue (which the
        caller must do explicitly, e.g. when the task completes) or when the
        generator is closed from outside.

        Usage::

            async for event in timeline.subscribe(task_id):
                yield format_sse(event)
        """
        queue: asyncio.Queue[TimelineEvent | None] = asyncio.Queue(maxsize=256)

        # First, replay existing events so the subscriber is fully caught up.
        for event in self.get_timeline(task_id):
            await queue.put(event)

        self._subscribers[task_id].append(queue)
        try:
            while True:
                event = await queue.get()
                if event is None:
                    # Sentinel — task is done, close the stream.
                    break
                yield event
        finally:
            # Clean up: remove this queue from the subscriber list.
            try:
                self._subscribers[task_id].remove(queue)
            except ValueError:
                pass

    def close_subscribers(self, task_id: str) -> None:
        """Send a None sentinel to all subscribers for a task, ending their streams."""
        for queue in list(self._subscribers.get(task_id, [])):
            try:
                queue.put_nowait(None)
            except asyncio.QueueFull:
                pass

    # ------------------------------------------------------------------
    # SSE formatting
    # ------------------------------------------------------------------

    @staticmethod
    def format_sse(event: TimelineEvent) -> str:
        """Format a TimelineEvent as a Server-Sent Events data string.

        Output format::

            id: <event_id>
            event: <event_type>
            data: <json payload>

            (blank line)
        """
        payload = {
            "id": event.id,
            "task_id": event.task_id,
            "event_type": event.event_type.value,
            "attempt_number": event.attempt_number,
            "step_number": event.step_number,
            "timestamp": event.timestamp.isoformat(),
            "data": event.data,
            "message": event.message,
        }
        data_line = json.dumps(payload, default=str)
        return (
            f"id: {event.id}\n"
            f"event: {event.event_type.value}\n"
            f"data: {data_line}\n\n"
        )
