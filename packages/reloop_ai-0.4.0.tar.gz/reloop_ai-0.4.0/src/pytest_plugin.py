"""ReLoop pytest plugin -- automatically capture test failures into failure memory.

Usage:
    pytest --reloop           # enable failure capture
    pytest --reloop --reloop-backend sqlite  # use SQLite backend
    pytest --reloop --reloop-sqlite-path my_memory.db

The plugin hooks into pytest's test lifecycle:
- On session start: searches memory for known-bad tests and prints warnings.
- On test failure: stores a failure record with error details.
"""

from __future__ import annotations

import logging
from typing import Any

import pytest

logger = logging.getLogger(__name__)


def pytest_addoption(parser: pytest.Parser) -> None:
    """Register --reloop CLI options."""
    group = parser.getgroup("reloop", "ReLoop failure memory integration")
    group.addoption(
        "--reloop",
        action="store_true",
        default=False,
        help="Enable ReLoop failure memory capture for test failures.",
    )
    group.addoption(
        "--reloop-backend",
        default="sqlite",
        choices=["auto", "redis", "sqlite"],
        help="Memory backend to use (default: sqlite).",
    )
    group.addoption(
        "--reloop-sqlite-path",
        default="reloop_test_memory.db",
        help="Path to SQLite database for failure memory (default: reloop_test_memory.db).",
    )
    group.addoption(
        "--reloop-redis-url",
        default="redis://localhost:6379",
        help="Redis URL for failure memory (default: redis://localhost:6379).",
    )


def _get_memory(config: pytest.Config) -> Any:
    """Create and cache a SyncFailureMemory on the config object."""
    if hasattr(config, "_reloop_memory"):
        return config._reloop_memory

    try:
        from src.standalone import SyncFailureMemory

        memory = SyncFailureMemory(
            redis_url=config.getoption("--reloop-redis-url"),
            backend=config.getoption("--reloop-backend"),
            sqlite_path=config.getoption("--reloop-sqlite-path"),
        )
        config._reloop_memory = memory  # type: ignore[attr-defined]
        return memory
    except Exception:
        logger.debug("Failed to initialise ReLoop memory; plugin disabled", exc_info=True)
        config._reloop_memory = None  # type: ignore[attr-defined]
        return None


def pytest_sessionstart(session: pytest.Session) -> None:
    """At session start, search memory for tests that have failed before."""
    if not session.config.getoption("--reloop", default=False):
        return

    try:
        memory = _get_memory(session.config)
        if memory is None:
            return

        results = memory.search("test_failure", limit=20)
        if results:
            session.config._reloop_warnings = results  # type: ignore[attr-defined]
            tw = session.config.get_terminal_writer()
            tw.sep("=", "ReLoop: known failure patterns", bold=True)
            for r in results[:10]:
                tw.line(
                    f"  WARNING: {r.get('code_context', r.get('error_type', '?'))} "
                    f"-- {r.get('root_cause', r.get('error_message', '')[:80])}"
                )
            tw.sep("=")
    except Exception:
        logger.debug("ReLoop sessionstart hook failed", exc_info=True)


_current_config: pytest.Config | None = None


def pytest_configure(config: pytest.Config) -> None:
    """Store a reference to the config for use in logreport hook."""
    global _current_config
    _current_config = config


def pytest_runtest_logreport(report: pytest.TestReport) -> None:
    """After each test phase, capture failures into ReLoop memory."""
    # Only capture actual test failures in the "call" phase
    if report.when != "call" or not report.failed:
        return

    config = _current_config
    if config is None:
        return

    if not config.getoption("--reloop", default=False):
        return

    try:
        memory = _get_memory(config)
        if memory is None:
            return

        error_message = report.longreprtext[:500] if report.longreprtext else str(report.longrepr)[:500]
        test_name = report.nodeid

        memory.store_failure(
            error_type="test_failure",
            error_message=error_message,
            code_context=test_name,
            root_cause=f"Test {test_name} failed",
            suggested_fix="Investigate and fix the failing test",
            task_id="pytest-session",
            confidence=0.7,
            error_category="runtime_error",
            transferable=True,
        )
        logger.debug("ReLoop: captured failure for %s", test_name)
    except Exception:
        # Plugin must NEVER crash pytest
        logger.debug("ReLoop: failed to store test failure", exc_info=True)


@pytest.hookimpl(trylast=True)
def pytest_terminal_summary(
    terminalreporter: Any,
    exitstatus: int,
    config: pytest.Config,
) -> None:
    """Print a summary of failures captured by ReLoop."""
    if not config.getoption("--reloop", default=False):
        return

    try:
        memory = _get_memory(config)
        if memory is None:
            return

        stats = memory.stats()
        total = stats.get("total_failures", 0)
        if total > 0:
            terminalreporter.write_sep("=", "ReLoop failure memory summary")
            terminalreporter.write_line(f"  Total failures in memory: {total}")
    except Exception:
        logger.debug("ReLoop: terminal summary failed", exc_info=True)
