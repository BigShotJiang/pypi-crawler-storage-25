"""ReLoop @retry decorator -- one-line failure memory for any function.

Usage::

    import reloop

    @reloop.retry(max_retries=3)
    async def deploy():
        subprocess.run(["npm", "install"], check=True)

    @reloop.retry(max_retries=3)
    def build():
        subprocess.run(["make", "build"], check=True)
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import logging
import traceback
from typing import Any, Callable, TypeVar

from src.standalone import SyncFailureMemory

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


def retry(
    max_retries: int = 3,
    memory: bool = True,
    budget_usd: float = 1.0,
    task_id: str | None = None,
) -> Callable[[F], F]:
    """Decorator that adds failure-memory-aware retries to any function.

    Args:
        max_retries: Maximum number of retry attempts (total calls = max_retries + 1).
        memory: Whether to use ReLoop failure memory for storing/recalling errors.
        budget_usd: Cost budget placeholder (reserved for future use).
        task_id: Optional task identifier for grouping failures in memory.
    """

    def decorator(fn: F) -> F:
        fn_name = fn.__qualname__
        effective_task_id = task_id or fn_name

        # Lazily initialised so we don't spin up a backend thread at import time
        _memory_instance: list[SyncFailureMemory | None] = [None]

        def _get_memory() -> SyncFailureMemory:
            if _memory_instance[0] is None:
                _memory_instance[0] = SyncFailureMemory(backend="auto")
            return _memory_instance[0]

        def _recall_warnings() -> None:
            """Search memory for past failures of this function and log warnings."""
            if not memory:
                return
            try:
                mem = _get_memory()
                similar = mem.search(fn_name, limit=3)
                for rec in similar:
                    logger.warning(
                        "reloop: past failure for %s — %s: %s (fix: %s)",
                        fn_name,
                        rec.get("error_type", "?"),
                        rec.get("error_message", "?"),
                        rec.get("suggested_fix", "unknown"),
                    )
            except Exception:
                logger.debug("reloop: could not recall past failures", exc_info=True)

        def _store_failure(exc: BaseException, attempt: int) -> None:
            """Store a failure record in memory."""
            if not memory:
                return
            try:
                mem = _get_memory()
                mem.store_failure(
                    error_type=type(exc).__name__,
                    error_message=str(exc),
                    root_cause=f"Exception in {fn_name}",
                    suggested_fix="",
                    task_id=effective_task_id,
                    attempt_number=attempt,
                    code_context=traceback.format_exc(),
                )
            except Exception:
                logger.debug("reloop: could not store failure", exc_info=True)

        def _store_success(attempt: int) -> None:
            """Store a success record in memory."""
            if not memory:
                return
            try:
                mem = _get_memory()
                mem.store_success(
                    approach="function call succeeded",
                    key_insight=f"{fn_name} succeeded on attempt {attempt}",
                    task_id=effective_task_id,
                    attempt_number=attempt,
                )
            except Exception:
                logger.debug("reloop: could not store success", exc_info=True)

        if inspect.iscoroutinefunction(fn):

            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                _recall_warnings()
                last_exc: BaseException | None = None
                total_attempts = max_retries + 1  # 1 initial + max_retries retries
                for attempt in range(1, total_attempts + 1):
                    try:
                        result = await fn(*args, **kwargs)
                        _store_success(attempt)
                        return result
                    except Exception as exc:
                        last_exc = exc
                        _store_failure(exc, attempt)
                        if attempt < total_attempts:
                            backoff = 2 ** (attempt - 1)  # 1s, 2s, 4s ...
                            logger.info(
                                "reloop: %s attempt %d/%d failed (%s), retrying in %ds",
                                fn_name,
                                attempt,
                                total_attempts,
                                exc,
                                backoff,
                            )
                            await asyncio.sleep(backoff)
                raise last_exc  # type: ignore[misc]

            return async_wrapper  # type: ignore[return-value]

        else:

            @functools.wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                import time

                _recall_warnings()
                last_exc: BaseException | None = None
                total_attempts = max_retries + 1  # 1 initial + max_retries retries
                for attempt in range(1, total_attempts + 1):
                    try:
                        result = fn(*args, **kwargs)
                        _store_success(attempt)
                        return result
                    except Exception as exc:
                        last_exc = exc
                        _store_failure(exc, attempt)
                        if attempt < total_attempts:
                            backoff = 2 ** (attempt - 1)  # 1s, 2s, 4s ...
                            logger.info(
                                "reloop: %s attempt %d/%d failed (%s), retrying in %ds",
                                fn_name,
                                attempt,
                                total_attempts,
                                exc,
                                backoff,
                            )
                            time.sleep(backoff)
                raise last_exc  # type: ignore[misc]

            return sync_wrapper  # type: ignore[return-value]

    return decorator
