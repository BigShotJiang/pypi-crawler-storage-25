"""ReLoop configuration — loads from environment and reloop.yaml."""

from __future__ import annotations

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Redis
    redis_url: str = "redis://localhost:6379"
    redis_memory_index: str = "reloop-failures"
    redis_admin_key: str = ""

    # Blaxel
    blaxel_api_key: str = ""
    blaxel_workspace: str = ""
    bl_api_key: str = ""
    bl_workspace: str = ""

    # OpenAI
    openai_api_key: str = ""
    codex_model: str = "gpt-4o"  # Chat model for planner/distiller (codex doesn't support chat API)
    reasoning_model: str = "o1"  # Deep reasoning for root cause analysis
    fast_model: str = "gpt-4o-mini"  # Fast/cheap model for classification and embeddings

    # API
    api_port: int = 8000
    api_host: str = "0.0.0.0"

    # Frontend
    next_public_api_url: str = "http://localhost:8000"

    # Orchestrator
    max_retries: int = 5
    max_budget_usd: float = 1.0
    circuit_breaker_threshold: int = 3

    # Memory
    embedding_model: str = "text-embedding-3-small"
    similarity_threshold: float = 0.75
    max_similar_failures: int = 5
    confidence_decay_rate: float = 0.1  # confidence penalty per day

    # Context Surfaces
    context_surfaces_admin_key: str = ""
    context_surfaces_api_url: str = "https://cloud.redis.io/context-surfaces"
    context_surfaces_mcp_url: str = "https://gcp-us-east4.context-surfaces.redis.io/mcp"

    # Sandbox
    sandbox_timeout_seconds: int = 120
    checkpoint_enabled: bool = True

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()
