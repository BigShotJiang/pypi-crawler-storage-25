---
name: rejd-test
description: Run REJD core loop and memory tests quickly
disable-model-invocation: true
---

Run these tests and report results concisely:
1. `python -m pytest tests/test_core_loop.py -v`
2. `python -m pytest tests/test_memory.py -v`
Report pass/fail counts and any failure details.
