---
name: demo-check
description: Run full pre-demo verification — REJD loop, A/B comparison, Redis memory, Blaxel checkpoints, SSE streaming, and frontend build
disable-model-invocation: true
---

Run the following verification steps and report status for each:

1. `cd dashboard && npm run build` — verify frontend builds
2. `python -m pytest tests/` — verify all tests pass
3. `docker-compose ps` — verify Redis is running
4. `python -m src.core.agent --demo` — verify demo scenario runs
5. `python -m src.core.agent --ab-demo` — verify A/B comparison works
6. Report: which steps passed/failed, and what to fix
