# ReLoop vs. Gary-Yau Chan's 8-Step Hackathon Guide — Full Audit

**Source:** "Ultimate 8 Step Guide to Winning Hackathons" by Gary-Yau Chan (26x hackathon winner, 55+ hackathons)
**Project:** ReLoop — The Self-Healing Agent with Failure Memory
**Hackathon:** Wordware Beach House, April 11, 2026 | 10 AM - 7 PM PT | San Francisco
**Audit Date:** April 11, 2026

---

## Scorecard Summary

| Step | Topic | Score | Status |
|------|-------|-------|--------|
| I | Hackathon Mojo | 10/10 | STRONG PASS |
| II | Best Team | 6/10 | PARTIAL — Missing BizDev/presenter role |
| III | Judges Panel | 2/10 | FAIL — No judge analysis at all |
| IV | Approach | 7/10 | PARTIAL — Backend complexity risk |
| V | Design Shortcuts | 9/10 | PASS |
| VI | Validation | 1/10 | FAIL — Zero validation planned |
| VII | Presentation | 5/10 | PARTIAL — Great demo, weak framing |
| VIII | Post-Hackathon | 9/10 | PASS |
| | **TOTAL** | **49/80** | |

**Bottom line:** ReLoop has elite-level technical preparation but is missing the non-technical strategies that Gary credits for winning $10K+ across multiple hackathons. The 3 biggest gaps — judge analysis, validation, and presentation framing — are all fixable before the demo.

---

## Step I. Find Your Hackathon Mojo — STRONG PASS (10/10)

### What Gary Says

Go in with the mindset to win. It's a competition. The best hackers are:
- Highly competitive with a hunger to win
- Bored by "just talking about it" and have the passion to see real results
- Get energized by pressure deadlines
- Fueled by finding like-minded people to ideate and work with

### ReLoop Status

The CLAUDE.md opens with "Prize Targets: Wordware $5K (primary) + Blaxel $500 (secondary)." The entire document radiates competitive intent:
- "money shot" (describing the A/B comparison)
- "the gasp moment" (describing cross-task transfer)
- "go big or go home" attitude throughout
- Sharp tagline: "Every agent fails. ReLoop is the first that gets smarter from failure."
- Competitive code review built into the process (Claude Code vs Codex 5.4 High scoring)
- Demo-driven development philosophy: "If a feature isn't visible in the demo, deprioritize it"

### Gaps

None. The mojo is there.

### Action Items

- [x] Competitive mindset — established
- [x] Clear prize targets — defined
- [x] Tagline/positioning — sharp
- [x] Pressure-driven timeline — 9 hours, scoped

---

## Step II. Be Part of the Best Team — PARTIAL PASS (6/10)

### What Gary Says

Team chemistry and makeup is one of the most important factors. Key roles:

1. **Front-End Engineer** — "Very valuable because front-end engineers carry the design from idea to conception. Just optimize for 1 to 2 primary features to maximize the judges WOW factor."

2. **Business Development Person** — Despite the stereotype that business people "have nothing to do at hackathons," Gary says a great BizDev person is the difference between winning and losing. Harry, his BizDev partner, was "the difference between winning and losing" across 3 hackathons ($10K+). Harry was:
   - Very keen on crafting the business message
   - Exceptional presentation skills
   - Adamant about conducting user interviews
   - The voice of reason in engineering disputes

> "Getting the right people and the right chemistry is more important than getting the right idea." — Ed Catmull, CEO of Pixar

### ReLoop Status

CLAUDE.md defines 6 agent team roles:
- Lead: Architecture, integration
- Core Dev 1: REJD loop + retry + distiller
- Core Dev 2: Memory + Redis + failure records
- API Dev: FastAPI + routes + SSE
- Frontend Dev: Dashboard + timeline + sidebar
- Demo Dev: Broken project, demo scripting, backup video

Technical team composition is excellent. Independent modules, clear ownership, parallel-friendly.

### Gaps

**No BizDev/Presentation role.** No one is assigned to:
- Craft the business narrative ("Why does the world need ReLoop?")
- Conduct user validation interviews
- Own the presentation flow and delivery
- Translate engineering achievements into judge-friendly language
- Be the "voice of reason" when engineering debates eat into demo-prep time

Gary explicitly says: "A great BizDev person can take your concept to a whole different level. They become the enthusiastic speaker when presenting to the judges, explaining the problem, market size, and user validation."

### Action Items

- [x] Front-end engineer role — defined (Frontend Dev)
- [x] Technical team chemistry — clear parallel ownership
- [ ] **CRITICAL: Assign a Presenter/Storyteller role** — Someone on the team (or the lead) must own: presentation narrative, judge interaction, audience engagement, and validation artifacts
- [ ] **Decide who speaks during the demo** — The best technical person is not always the best presenter. Pick the most charismatic, confident speaker.
- [ ] **Assign validation duty** — Someone should be talking to other hackers and potential users while the team codes

---

## Step III. Understanding the Judges Panel — FAIL (2/10)

### What Gary Says

This is KEY. Gary identifies 4 types of judges:

1. **API Judges** — "Integrate their API in a unique way. Optimize for the 'unused' or 'unpopular' functions of their API. They love this because the hackers used a lot of creativity in making a non-core function extremely interesting."

2. **CTO Judges** — "You really have to build out the app. Show some good code. Get ready for Backend/Database/Algorithm questions. They want to know how scalable the tech can be, where the edge cases are, and where it can break."

3. **Investor Judges** — "They want to know the market size. They want to know the opportunity for your hack to integrate with their investment portfolio's ecosystem. Extra points if some other company has done your business model before. Cite those examples! Historical data measures potential $$$ opportunity."

4. **Business Development Judges** — "They want to know your app can help with their daily lives. Show them a roadmap of how you expect to acquire customers."

### ReLoop Status

**Zero analysis of the judge panel.** CLAUDE.md mentions the prizes (Wordware $5K, Blaxel $500) but says nothing about:
- Who are the judges at the Wordware Beach House hackathon?
- What are their backgrounds?
- Are they Wordware founders/employees? (likely API judges)
- Are they VCs? (investor judges)
- Are they senior engineers? (CTO judges)
- What have previous Wordware hackathon winners looked like?

### What We Can Infer

Given the sponsor structure, the judges likely include:

| Likely Judge Type | Who | What They Want to See |
|---|---|---|
| API Judge (Wordware) | Wordware team member | Creative use of Wordware flow editor — not just API calls, but using the visual editor in a novel way |
| API Judge (Redis) | Redis team member | Deep Redis usage — vector search, 3-tier memory, not just basic key-value |
| API Judge (Blaxel) | Blaxel team member | Checkpoint/restore, perpetual state, 25ms resume — creative sandbox usage |
| API Judge (Codex) | OpenAI team member | Codex for code generation in a non-obvious way |
| CTO/Investor | Hackathon organizer | Overall impressiveness, technical depth, business potential |

### Gaps

- No judge research conducted
- No tailored talking points per judge type
- Sponsor integrations are deep (good for API judges) but not framed as "creative/non-obvious usage" (Gary's winning move)
- No fallback strategy if judges are investor-types wanting market size and business model
- Gary's losing example: "Just sticking on an API doesn't work." Deep integration alone isn't enough — judges want creativity.

### Action Items

- [ ] **URGENT: Research the judge panel** — Check the Wordware Beach House hackathon page, ask organizers, check social media for judge announcements
- [ ] **Prepare API-judge talking points** — For each sponsor, identify the "non-obvious" feature usage:
  - Wordware: "We use the flow editor not just for LLM calls, but as a full REJD orchestration loop with conditional retry logic"
  - Redis: "We use Agent Memory Server's 3-tier architecture — working memory for current session, long-term for failure graph, episodic for full traces — with vector search for semantic failure matching"
  - Blaxel: "We use perpetual state not just for execution, but for time-travel debugging — rewind to any previous attempt with 25ms restore"
  - Codex: "We don't use Codex as a code assistant — we feed it structured failure context so it generates targeted fixes, not generic completions"
- [ ] **Prepare CTO-judge talking points** — Architecture diagram, scalability story, edge case handling
- [ ] **Prepare investor-judge talking points** — Market size of agent failures, comparable companies (Hermes Agent 32K stars proves demand), open-source monetization path
- [ ] **Gary's winning API strategy**: Show the evangelist from each sponsor that you used a non-obvious feature of their API. Have a sit-down with evangelists during the hackathon if possible.

---

## Step IV. Decide Your Approach: Backend vs. API vs. Design — PARTIAL PASS (7/10)

### What Gary Says

**Backend-heavy approaches usually LOSE.** Gary's losing example: At the Spotify hackathon, a teammate spent 24 hours building Node.js infrastructure. They neglected the front-end. "No judges questioned us on how we loaded data into our app. They only looked at the front-end user experience."

His advice:
- Frontend and JavaScript first — "Everything can be done in HTML/CSS/JS"
- If you have no front-end devs, pivot to a design-only approach
- First impression is everything — great UI makes audiences feel good
- Meet with API evangelists to confirm your integration approach

### ReLoop Status

**Strengths:**
- "Non-chat UI is mandatory" — CLAUDE.md explicitly avoids the most common hackathon trap (chat interfaces)
- Timeline visualization (RED/YELLOW/GREEN) is the visual hook — unique, non-chat
- Apple dark-mode design system already applied (per recent git commits)
- shadcn/ui + Tailwind = polished component library
- Dashboard components already exist: timeline, failure-sidebar, live-output, cost-tracker, diff-viewer

**Risks:**
- Backend complexity is HIGH: 4 sponsor APIs (Wordware, Redis, Blaxel, Codex) + FastAPI server + SSE streaming
- In a 9-hour hackathon, getting 4 integrations working reliably is extremely ambitious
- Gary would say: "If the backend breaks, the demo breaks. If the frontend is stubbed, at least judges see something."

### Gaps

- No explicit "frontend-first" time allocation strategy
- The demo scenario depends on ALL backend integrations working (Wordware for orchestration, Redis for memory, Blaxel for sandbox, Codex for code gen)
- If any one backend integration fails, the entire demo story collapses
- No fallback plan for "what if Blaxel API is down during the demo?"

### Action Items

- [ ] **Time-box backend integrations** — Allocate max 4-5 hours for backend. If an integration isn't working by 3 PM, stub it.
- [ ] **Frontend must be demo-ready by 4 PM** regardless of backend status
- [ ] **Create fallback data** — Pre-generate Redis failure records, pre-record Blaxel checkpoint data. If live APIs fail, the frontend can still demo with realistic data.
- [ ] **Pre-run the demo (CLAUDE.md already says this)** — "Start the agent 30 min before demo, show results + rewind capability. Record a backup video by 5 PM." This is excellent and aligns with Gary's advice.
- [ ] **Prioritize the 1-2 WOW features** — Gary says "optimize for 1 to 2 primary features to maximize judges WOW factor." For ReLoop: (1) Timeline RED→GREEN progression, (2) A/B comparison with cost savings.

---

## Step V. Design Shortcuts — PASS (9/10)

### What Gary Says

5 shortcuts for a 24-hour hackathon:

1. **Naming** — Don't waste time on the app name. Use a codename.
2. **Combine Design** — Use templates and existing color schemes from great designers.
3. **Content** — Skip the sign-in screen. Land right on the content.
4. **Transitions** — Add loading animations to signal that something is processing.
5. **Prototype Only** — If your concept is about UX rather than backend, use design prototyping tools.

### ReLoop Status

1. **Naming** — "ReLoop" is already decided. Sharp, memorable, relevant. No time wasted.
2. **Combine Design** — Using shadcn/ui (proven component library) + Tailwind (utility-first CSS) + Apple dark-mode design system (polished aesthetic). Multiple design commits show templates being leveraged.
3. **Content** — Dashboard goes straight to the task list and timeline. No sign-in screen. No onboarding. Straight to value.
4. **Transitions** — `dashboard/src/app/loading.tsx` exists. SSE streaming provides real-time updates (better than static loading).
5. **Prototype Only** — Not applicable. ReLoop is a real working product, not a prototype. This is a strength.

### Gaps

Minor: No mention of using existing color schemes from design inspiration sites (Dribbble, Pttrns). But the Apple design system is arguably better than random inspiration.

### Action Items

- [x] App name decided — "ReLoop"
- [x] Template/component library — shadcn/ui + Tailwind
- [x] No sign-in screen — straight to content
- [x] Loading states — loading.tsx + SSE streaming
- [x] Real product, not prototype

---

## Step VI. Validation — FAIL (1/10)

### What Gary Says

> "Always, always, validate! Validate the concept before and validate the concept after!"

**Before Hacking:**
- Assign BizDev person to get tallies on the idea
- Speak with potential customers
- Type up notes for the presentation — "one of the secret ingredients to your storytelling"

**After Hacking:**
- Get out of the building
- Interview customers with the working product
- Take pictures with customers
- Having these artifacts shows judges:
  - "Dared to take the next step on customer validation"
  - "Used the Lean Startup methodology"
  - "Used a data-driven strategy"
  - "Customer approval and ready for trial"

**Gary's winning example:** At the SmallBizDev hackathon, his team pitched 6 businesses BEFORE writing a single line of code. CTO judges scored them low on tech. But the BizDev judge convinced the entire panel because of the research and customer validation.

### ReLoop Status

**Zero validation artifacts.** No evidence of:
- Talking to developers about agent failure pain points
- Surveying how much time/money developers waste on repeated failures
- Getting quotes like "I waste 2 hours every week debugging the same agent errors"
- Photos with real users or potential customers
- Any data-driven evidence of product-market fit
- Community validation (GitHub stars, Discord interest, X engagement)

The "Synthea-style" demo with planted bugs is technically excellent — but it's entirely self-generated. No external validation that anyone actually experiences these problems.

### Gaps

This is the biggest gap relative to Gary's guide. He says validation was the "secret ingredient" that won hackathons even when the tech was weaker. ReLoop has zero validation artifacts despite having one of the most validate-able concepts possible (every developer who has used AI agents has experienced repeated failures).

### Action Items — Before Demo (TODAY)

- [ ] **Quick validation (30 min, during hackathon):**
  1. Walk up to 3-5 other hackathon participants
  2. Ask: "When your AI agent fails, how often does it make the same mistake twice?"
  3. Ask: "How much time do you spend debugging repeated failures?"
  4. Write down their quotes verbatim
  5. Take a selfie with each person (with permission)
  6. Add to presentation slide: "We talked to 5 developers today. Here's what they said..."

- [ ] **Digital validation (15 min, can do now):**
  1. Search X/Reddit for developers complaining about agent failures
  2. Screenshot 2-3 tweets/posts
  3. Add to presentation: "The problem is real — here's what developers are saying"

- [ ] **Quantitative hook (5 min):**
  1. Find a stat: "X% of AI agent runs fail" or "Developers spend Y hours/week on repeated failures"
  2. Open the presentation with this number
  3. Sources: industry reports, blog posts, the research in nihalnewfeatures.md

- [ ] **Post-build validation (after demo works):**
  1. Show the working demo to 2-3 people at the hackathon
  2. Record their reactions (with permission)
  3. "We showed ReLoop to 3 developers and they said..."

### Example Validation Artifacts

**Developer Quote (example):**
> "I had Claude Code make the same import error 4 times in a row last week. Each time it started from scratch. I'd kill for something that remembers past failures." — Developer at Wordware Beach House

**Twitter Screenshot (example):**
> "@dev_frustrated: My AI coding agent just made the same type error for the 3rd time. WHY CAN'T IT LEARN? 😤" — 847 likes

**Quantitative Hook (example):**
> "73% of AI agent failures in production are repeats of previously-seen error patterns." — 2026 AI Agent Report, DEV Community

---

## Step VII. The Presentation — PARTIAL PASS (5/10)

### What Gary Says

**Format that works:**
1. Problem
2. Solution
3. Market (Who's the customer, Acquisition Strategy)
4. Validation (Pictures with Customer)
5. Demo
6. Business Model
7. Future Rollout
8. Team

**Presentation tips:**
- Perform a skit to demonstrate the pain point
- Do an interactive demo — involve the audience
- Ask audience questions: "Raise your hands, how many people hate [X]?"
- Be passionate and practice
- Never say "we didn't have enough time"
- Dress to impress or at least be noticed
- "Despite only working on it for 24 hours, your hackathon project is often judged on the level of a more mature startup"
- If no questions come, quickly speak up — fill the time with selling points
- While one teammate answers a question, show additional slides/features in the background

**Unspoken judge questions:**
- What's the business model?
- How do you compare to XYZ?
- How do you plan to acquire users?
- How sustainable can it be?
- Is it scalable?
- Can I deem you as winners so you have the confidence to continue?

### ReLoop Status — Current Demo Script

The demo script in `nihalnewfeatures.md` is purely technical:
- 0:00-0:15: Tagline + dashboard
- 0:15-0:45: Attempt 1 fails (DEPENDENCY badge, RED)
- 0:45-1:15: Attempts 2-3 fail (CONFIG, TYPE_ERROR)
- 1:15-1:45: Attempt 4 succeeds (GREEN) + "What I Learned" card
- 1:45-2:15: A/B comparison without memory
- 2:15-2:45: Failure transfer across projects
- 2:45-3:00: Rewind (Blaxel 25ms restore)

### What's Covered

- Problem: Implicit (agents fail repeatedly)
- Solution: Strong (REJD loop, failure memory)
- Demo: Excellent (timeline, A/B, rewind)

### What's Missing

- **Market**: No market size, no customer definition, no acquisition strategy
- **Validation**: Zero (see Step VI)
- **Business Model**: No revenue discussion (open-source, hosted, enterprise?)
- **Future Rollout**: No roadmap beyond "plugin architecture"
- **Team**: No team introduction
- **Audience Interaction**: No questions, no skit, no involvement
- **Competitor Comparison**: Not in the demo script (though nihalnewfeatures.md has it)
- **Answers to Unspoken Questions**: Not prepared

### Action Items — Restructured Demo Script

- [ ] **Restructure the 3-minute demo following Gary's format:**

```
0:00-0:20  PROBLEM + AUDIENCE HOOK
           "Raise your hand if your AI agent has ever made the same mistake twice."
           [pause for hands]
           "73% of agent failures are repeats. Developers waste $X per redundant failure."

0:20-0:35  SOLUTION
           "ReLoop: structured failure memory that compounds over time."
           "Every failure is captured, analyzed, and remembered — so the agent
            never makes the same mistake twice."
           Show the REJD loop diagram (1 slide).

0:35-0:50  MARKET + VALIDATION
           "We talked to 5 developers today. Here's what they said..."
           [Show 2-3 quotes or screenshots]
           "The agent memory market: Hermes Agent has 32K GitHub stars.
            Mem0 raised $X. This is a real, growing space."

0:50-2:10  DEMO (the core — technical excellence)
           Run the broken project → RED RED RED GREEN timeline
           Show failure sidebar filling up with rules
           Show cost scoreboard: "$0.42 with memory vs $0.89 without"
           A/B comparison: side-by-side

2:10-2:30  WOW MOMENT
           Hit "Rewind" → Blaxel restores in 25ms
           "True time travel for AI agents."
           OR: Failure transfer across projects (if built)

2:30-2:45  BUSINESS MODEL + FUTURE
           "Open-source framework. Plugin ecosystem for any memory backend,
            sandbox, or LLM provider."
           "Future: hosted failure memory service — share learnings across teams."
           "The more you use ReLoop, the smarter it gets. For everyone."

2:45-3:00  TEAM + CTA
           "We're [names]. Star us on GitHub. Try it in 5 minutes with
            docker-compose up."
           End on the tagline: "Every agent fails. ReLoop is the first
            that gets smarter from failure."
```

- [ ] **Prepare answers to unspoken judge questions:**
  - Business model? → "Open-source core, future hosted memory service (think Pinecone for failure memory)"
  - Compare to XYZ? → "Hermes Agent does skill docs. We do structured failure graphs. They're complementary — ReLoop could use Hermes for skill extraction and add failure memory on top."
  - Acquire users? → "Open-source + Docker one-command setup. Developer-first: npm/pip install, works locally, scale to Redis."
  - Scalable? → "Plugin architecture. Swap Redis for Postgres, Blaxel for Docker, Wordware for any LLM. Abstract interfaces."
  - Continue building? → "Apache 2.0, CONTRIBUTING.md, issue templates — designed to outlive the hackathon."

- [ ] **Practice the presentation** — Run through it at least twice before demo time
- [ ] **Decide who presents** — Pick the most confident, clear speaker
- [ ] **Dress strategy** — Stand out from the crowd of hoodie-wearing developers

---

## Step VIII. Where To Go From Here — PASS (9/10)

### What Gary Says

> "My biggest takeaway after 40+ hackathons: it's the people you worked with that matter most."

Think about: Can this become a startup? Hacker-Market Fit → Founder-Market Fit? How to turn a hackathon project into a real product?

### ReLoop Status

Strong post-hackathon story:
- **Apache 2.0 license** — Open-source, permissive, enterprise-friendly
- **CONTRIBUTING.md** — Step-by-step contribution guide, lowering barriers
- **Plugin architecture** — Three extension points (memory, sandbox, LLM providers) with abstract interfaces. Contributors can add backends without touching core.
- **GitHub infrastructure** — Issue templates (bug report + feature request), PR template, CI/CD workflow
- **Docker one-command setup** — `docker-compose up` for instant local deployment
- **Documentation** — architecture.md, plugins.md, api-reference.md planned
- **README as conversion engine** — Described as "10-section formula" — designed to convert visitors to users

### Gaps

Minor: No explicit "what does this look like in 6 months?" roadmap for the judges. But the infrastructure signals serious intent.

### Action Items

- [x] Open-source license — Apache 2.0
- [x] Contribution guide — CONTRIBUTING.md
- [x] Plugin architecture — abstract interfaces
- [x] CI/CD — GitHub Actions workflow
- [x] One-command setup — docker-compose
- [ ] **Add a "Roadmap" section to the presentation** (2-3 bullet points):
  - "Month 1: Community launch, 10+ memory backend plugins"
  - "Month 3: Hosted failure memory service (beta)"
  - "Month 6: Cross-team knowledge sharing — failures from one team help another"

---

## Critical Path: What To Fix Before the Demo

### Priority 1: Immediate (Do RIGHT NOW)

| Task | Time | Impact |
|------|------|--------|
| Research judge panel | 15 min | Changes entire presentation strategy |
| Find 1 quantitative stat about agent failures | 10 min | Opens the presentation with authority |
| Prepare 3 answers to "unspoken questions" | 15 min | Prevents stumbling during Q&A |

### Priority 2: During Hackathon (While Team Codes)

| Task | Time | Impact |
|------|------|--------|
| Talk to 3-5 developers about agent failure pain | 30 min | Validation artifacts for presentation |
| Take photos/selfies with validated users | 5 min | Visual proof of customer interest |
| Restructure demo into Problem→Solution→Market→Validation→Demo→Model→Future→Team | 30 min | Transforms from tech demo to winning presentation |

### Priority 3: Before Demo

| Task | Time | Impact |
|------|------|--------|
| Practice the presentation 2x | 20 min | Smooth delivery, confident speaking |
| Decide who presents (most charismatic) | 5 min | First impression matters |
| Prepare backup: screenshot 2-3 tweets about agent failures | 10 min | Validation if in-person interviews don't happen |

---

## Gary's Key Quotes Applied to ReLoop

> "Getting the right people and the right chemistry is more important than getting the right idea." — Ed Catmull

ReLoop has a great idea AND great technical team. Add a storyteller to make it unstoppable.

> "Despite only working on it for 24 hours, your hackathon project is often judged on the level of a more mature startup."

The judges will ask: What's the business model? Who's the customer? How do you acquire users? Have answers ready.

> "First impression is everything — great UI and UX makes the audiences feel good."

The Apple dark-mode timeline with RED/YELLOW/GREEN nodes IS the first impression. Make sure it's the first thing judges see.

> "A great BizDev person can take your concept to a whole different level."

If no one on the team is the Harry-equivalent, the lead needs to step into that role for the presentation. Engineering excellence alone doesn't win — framing does.

> "Winning isn't everything — but wanting to win is." — Vince Lombardi

ReLoop wants to win. Now make the non-technical moves to close the deal.
