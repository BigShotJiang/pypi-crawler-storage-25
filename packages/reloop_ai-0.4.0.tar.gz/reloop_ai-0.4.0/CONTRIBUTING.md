# Contributing to ReLoop

Thank you for your interest in contributing to ReLoop. This guide explains how
to get the development environment running, the code style we enforce, and how
to open a pull request.

---

## Table of Contents

1. [Dev Environment Setup](#dev-environment-setup)
2. [Running Tests](#running-tests)
3. [Code Style](#code-style)
4. [Architecture Overview](#architecture-overview)
5. [PR Process](#pr-process)

---

## Dev Environment Setup

### Prerequisites

- Python 3.11+
- Node.js 20+ (for the dashboard)
- Docker + Docker Compose (for Redis + local services)
- Git

### Steps

```bash
# 1. Clone the repo
git clone https://github.com/your-org/reloop.git
cd reloop

# 2. Create a Python virtual environment
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate

# 3. Install Python dependencies (includes test + lint tools)
pip install -r requirements.txt

# 4. Copy the example environment file
cp .env.example .env
# Edit .env and fill in your API keys

# 5. Start Redis (required for failure memory)
docker-compose up redis -d

# 6. Start the API server
uvicorn src.api.server:app --reload

# 7. (Optional) Start the Next.js dashboard
cd dashboard
npm install
npm run dev
```

The API will be available at `http://localhost:8000` and the dashboard at
`http://localhost:3000`.

---

## Running Tests

```bash
# Run the full test suite
python -m pytest tests/

# Run a specific test file
python -m pytest tests/test_models.py

# Run with verbose output
python -m pytest tests/ -v

# Run with coverage
python -m pytest tests/ --cov=src --cov-report=term-missing
```

All tests use `pytest` and `pytest-asyncio`. Async tests are marked with
`@pytest.mark.asyncio`. The test suite uses mock providers — no real Redis,
Blaxel, or API keys are needed.

---

## Code Style

### Python

We use [`ruff`](https://docs.astral.sh/ruff/) for linting and formatting, and
[`mypy`](https://mypy.readthedocs.io/) for static type checking.

```bash
# Lint
ruff check src/ tests/

# Auto-fix lint issues
ruff check src/ tests/ --fix

# Format
ruff format src/ tests/

# Type check
mypy src/
```

All code must pass `ruff check` and `mypy` before merging. PRs that introduce
type errors or lint warnings will not be approved.

**Style rules (enforced by ruff):**
- Maximum line length: 100 characters
- Use `from __future__ import annotations` in all Python files
- Prefer f-strings over `%` or `.format()`
- Use `|` union syntax for type hints (Python 3.10+ style)
- No unused imports

### TypeScript / Next.js (dashboard)

```bash
cd dashboard

# Lint
npm run lint

# Format check
npx prettier --check .

# Auto-format
npx prettier --write .

# Type check
npm run type-check
```

---

## Architecture Overview

ReLoop is built around the **REJD loop** (Retrieve-Execute-Judge-Distill).
Understanding this loop is essential before contributing to core modules.

```
NEW TASK
  └─> RETRIEVE  Query Redis for similar past failures (by error type + semantic similarity)
  └─> EXECUTE   Run the task command in a Blaxel Firecracker sandbox
  └─> JUDGE     Classify the outcome: success or failure
        ├─ SUCCESS ─> DISTILL  Store solution + learnings ─> DONE
        └─ FAILURE ─> DISTILL  Capture root cause, fix, confidence ─> STORE
                         └─> Budget/retries left? ─> RETRY (back to RETRIEVE)
                         └─> Exhausted? ─> ABANDON ─> STORE
```

### Module Map

```
src/
├── models.py              Pydantic data models (FailureRecord, Task, Attempt, …)
├── config.py              Settings loaded from .env / environment variables
├── core/
│   ├── agent.py           Main REJD orchestrator — the control loop
│   ├── memory.py          High-level failure memory operations (build on MemoryBackend)
│   ├── retry.py           Retry engine: manages attempts, budget, circuit breaker
│   ├── timeline.py        Timeline event recording
│   └── distiller.py       LLM-powered failure/success distillation
├── providers/
│   ├── base.py            Abstract interfaces (MemoryBackend, SandboxProvider, LLMProvider)
│   ├── llm/               Concrete LLM providers (OpenAI, OpenAI Agents SDK)
│   ├── memory/            Concrete memory backends (Redis, SQLite)
│   └── sandbox/           Concrete sandbox providers (Blaxel, Docker)
├── api/
│   ├── server.py          FastAPI entry point
│   ├── routes/            REST endpoints (tasks, memories, checkpoints)
│   └── sse.py             Server-Sent Events for real-time streaming
└── cli/
    └── main.py            CLI entry point
```

### Extension Points

ReLoop has three formal extension points, each defined by an abstract base class
in `src/providers/base.py`:

| Interface | Implement to add... |
|-----------|-------------------|
| `MemoryBackend` | A new failure memory store (e.g. PostgreSQL, Pinecone) |
| `SandboxProvider` | A new execution environment (e.g. E2B, Modal) |
| `LLMProvider` | A new LLM or agent framework (e.g. Claude, Gemini) |

To add a new backend: subclass the relevant ABC, implement all abstract methods,
and register it in the provider factory. No changes to core loop code are needed.

---

## PR Process

### Before Opening a PR

1. Create a branch from `main`:
   ```bash
   git checkout -b feat/my-feature
   ```
2. Make your changes and commit using [Conventional Commits](https://www.conventionalcommits.org/):
   ```
   feat(memory):   add Pinecone memory backend
   fix(retry):     handle zero-budget edge case
   docs:           update API reference for /v1/memories/search
   test(core):     add circuit breaker regression test
   ```
3. Ensure all checks pass locally:
   ```bash
   ruff check src/ tests/
   mypy src/
   python -m pytest tests/
   ```
4. Push and open a PR against `main`.

### PR Checklist

- [ ] All tests pass (`python -m pytest tests/`)
- [ ] No ruff lint errors
- [ ] No mypy type errors
- [ ] New behaviour is covered by tests
- [ ] PR description explains *why* the change is needed, not just *what* changed
- [ ] No secrets or API keys committed

### Review Process

- PRs require at least one approving review before merging.
- Feedback will be given within 48 hours.
- Squash-merge is preferred to keep the main history clean.

---

## Questions?

Open an issue or start a discussion on GitHub. We're happy to help you get
oriented before you invest time in a large contribution.
