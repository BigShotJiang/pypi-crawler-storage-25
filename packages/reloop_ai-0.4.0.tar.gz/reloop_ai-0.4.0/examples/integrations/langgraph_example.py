"""ReLoop + LangGraph integration example.

Adds failure memory to a LangGraph state graph so the agent
avoids repeating past mistakes on each retry.
"""

import asyncio

from src.standalone import FailureMemory

# from langgraph.graph import StateGraph  # uncomment when langgraph is installed

memory = FailureMemory()  # auto-detects Redis, falls back to SQLite


async def before_retry(state: dict) -> dict:
    """Inject similar past failures into state before retrying."""
    similar = await memory.search(state["last_error"])
    state["failure_context"] = similar
    return state


async def after_failure(state: dict) -> dict:
    """Store failure in memory after an attempt fails."""
    await memory.store_failure(
        error_type=state.get("error_type", "UnknownError"),
        error_message=state.get("last_error", ""),
        root_cause=state.get("root_cause", ""),
        suggested_fix=state.get("suggested_fix", ""),
        task_id=state.get("task_id", "langgraph-task"),
    )
    return state


# Example graph wiring (pseudo-code):
#
# graph = StateGraph(AgentState)
# graph.add_node("execute", execute_node)
# graph.add_node("before_retry", before_retry)
# graph.add_node("after_failure", after_failure)
# graph.add_edge("execute", "check_result")
# graph.add_conditional_edges("check_result", {
#     "success": END,
#     "failure": "after_failure",
# })
# graph.add_edge("after_failure", "before_retry")
# graph.add_edge("before_retry", "execute")


if __name__ == "__main__":
    # Quick smoke test
    async def main():
        await memory.store_failure(
            error_type="ImportError",
            error_message="No module named 'sharp'",
            root_cause="Missing dependency",
            suggested_fix="pip install sharp",
        )
        results = await memory.search("ImportError sharp")
        print(f"Found {len(results)} similar failures")
        for r in results:
            print(f"  - [{r['error_type']}] {r['error_message']}")

    asyncio.run(main())
