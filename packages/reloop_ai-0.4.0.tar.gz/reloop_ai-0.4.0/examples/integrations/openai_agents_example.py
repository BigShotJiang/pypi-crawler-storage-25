"""ReLoop + OpenAI Agents SDK integration example.

Exposes failure memory as a function_tool so OpenAI agents
can search and store failure knowledge.
"""

import asyncio
import json

from src.standalone import FailureMemory

# from agents import Agent, Runner, function_tool  # uncomment when agents SDK is installed

memory = FailureMemory()


# @function_tool  # uncomment when agents SDK is installed
async def search_failures(query: str) -> str:
    """Search past agent failures for similar errors.

    Args:
        query: Error description or keywords to search for.

    Returns:
        JSON list of similar past failures with suggested fixes.
    """
    results = await memory.search(query)
    if not results:
        return "No similar failures found in memory."
    return json.dumps(results, indent=2)


# @function_tool  # uncomment when agents SDK is installed
async def store_failure(error_type: str, error_message: str, suggested_fix: str = "") -> str:
    """Store a failure in ReLoop memory so future agents can learn from it.

    Args:
        error_type: The class of error (e.g. ImportError, TypeError).
        error_message: The full error message.
        suggested_fix: How to fix this error.

    Returns:
        Confirmation with the stored failure ID.
    """
    failure_id = await memory.store_failure(
        error_type=error_type,
        error_message=error_message,
        suggested_fix=suggested_fix,
    )
    return f"Stored failure {failure_id}"


# Agent definition (uncomment when agents SDK is installed):
#
# agent = Agent(
#     name="Self-Healing Agent",
#     instructions=(
#         "You are a self-healing coding agent. Before attempting any fix, "
#         "search failure memory for similar past errors. After a failure, "
#         "store it in memory so you don't repeat the same mistake."
#     ),
#     tools=[search_failures, store_failure],
# )
#
# async def main():
#     result = await Runner.run(agent, "Fix the build error in the project")
#     print(result.final_output)


if __name__ == "__main__":
    async def main():
        fid = await memory.store_failure(
            error_type="ModuleNotFoundError",
            error_message="No module named 'numpy'",
            suggested_fix="pip install numpy",
        )
        print(f"Stored failure: {fid}")
        print(await search_failures("ModuleNotFoundError numpy"))

    asyncio.run(main())
