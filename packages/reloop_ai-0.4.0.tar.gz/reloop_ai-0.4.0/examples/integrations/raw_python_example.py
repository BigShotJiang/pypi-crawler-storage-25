"""ReLoop standalone usage -- no framework required.

Shows the simplest possible usage of ReLoop failure memory:
store failures, search them, get anti-patterns, view stats.
"""

import asyncio

from src.standalone import FailureMemory


async def main():
    # 1. Create memory (auto-detects Redis, falls back to SQLite)
    memory = FailureMemory()

    # 2. Store some failures
    await memory.store_failure(
        error_type="ImportError",
        error_message="No module named 'sharp'",
        root_cause="sharp is not in requirements.txt",
        suggested_fix="pip install sharp",
        anti_pattern="Don't assume image processing libs are pre-installed",
        error_category="dependency_error",
    )

    await memory.store_failure(
        error_type="OSError",
        error_message="[Errno 98] Address already in use: port 3000",
        root_cause="Another process is using port 3000",
        suggested_fix="Kill the existing process or use a different port",
        anti_pattern="Always check port availability before binding",
        error_category="config_error",
    )

    await memory.store_failure(
        error_type="TypeError",
        error_message="Type 'string' is not assignable to type 'number'",
        root_cause="API returns string IDs but type expects number",
        suggested_fix="Parse string to number or update the type definition",
        error_category="type_error",
    )

    # 3. Search for similar failures
    print("=== Search: 'module not found' ===")
    results = await memory.search("module not found")
    for r in results:
        print(f"  [{r['error_type']}] {r['error_message']}")
        print(f"    Fix: {r['suggested_fix']}")
        print()

    # 4. Get anti-patterns
    print("=== Anti-patterns ===")
    patterns = await memory.get_anti_patterns()
    for p in patterns:
        print(f"  - {p}")
    print()

    # 5. View stats
    print("=== Stats ===")
    s = await memory.stats()
    print(f"  Total failures: {s['total_failures']}")
    print(f"  Total successes: {s['total_successes']}")
    print(f"  Avg confidence: {s['avg_confidence']:.2f}")
    print(f"  Top categories: {s['top_error_categories']}")

    # 6. Store a success
    await memory.store_success(
        approach="Installed missing dep + changed port + fixed type",
        key_insight="Check dependencies, ports, and types in that order",
        task_id="demo-task",
    )

    s = await memory.stats()
    print(f"\n  After success: {s['total_successes']} successes recorded")


if __name__ == "__main__":
    asyncio.run(main())
