"""ReLoop + CrewAI integration example.

Exposes failure memory as a CrewAI Tool so agents can search
past failures before attempting a task.
"""

import asyncio

from src.standalone import FailureMemory

# from crewai import Agent, Task, Crew, Tool  # uncomment when crewai is installed

memory = FailureMemory()


def search_failures_sync(query: str) -> str:
    """Synchronous wrapper for CrewAI tool compatibility."""
    results = asyncio.get_event_loop().run_until_complete(memory.search(query))
    if not results:
        return "No similar failures found."
    lines = []
    for r in results:
        lines.append(
            f"[{r['error_type']}] {r['error_message']} "
            f"-- Fix: {r['suggested_fix']}"
        )
    return "\n".join(lines)


def store_failure_sync(description: str) -> str:
    """Store a failure from a tool call. Expects 'type: message' format."""
    parts = description.split(":", 1)
    error_type = parts[0].strip() if len(parts) > 1 else "UnknownError"
    error_message = parts[1].strip() if len(parts) > 1 else description
    asyncio.get_event_loop().run_until_complete(
        memory.store_failure(error_type=error_type, error_message=error_message)
    )
    return f"Stored failure: {error_type}"


# CrewAI tool definitions (uncomment when crewai is installed):
#
# failure_search_tool = Tool(
#     name="search_failures",
#     func=search_failures_sync,
#     description="Search past agent failures for similar errors. Input: error description string.",
# )
#
# failure_store_tool = Tool(
#     name="store_failure",
#     func=store_failure_sync,
#     description="Store a failure in memory. Input: 'ErrorType: error message'.",
# )
#
# agent = Agent(
#     role="Self-Healing Developer",
#     goal="Fix code issues without repeating past mistakes",
#     tools=[failure_search_tool, failure_store_tool],
# )


if __name__ == "__main__":
    async def main():
        await memory.store_failure(
            error_type="TypeError",
            error_message="Cannot read property 'map' of undefined",
            root_cause="Data not loaded before render",
            suggested_fix="Add null check or loading state",
        )
        results = await memory.search("TypeError map undefined")
        print(f"Found {len(results)} similar failures")

    asyncio.run(main())
