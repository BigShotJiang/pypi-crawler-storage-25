#!/usr/bin/env python3
"""Seed Redis with high-quality failure memories for the ReLoop hackathon demo.

These memories teach the agent about Blaxel sandbox constraints:
- sh shell (not bash)
- No curl, wget, sudo, apt-get, pip, python3
- Has node, npm, npx
- Heredocs unreliable; use echo or node -e
- Multi-line && can fail in sh

Usage:
    .venv/bin/python scripts/seed_memory.py
"""

from __future__ import annotations

import json
import os
import sys

# Ensure project root is on sys.path so `src` imports work
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

from datetime import datetime, timezone, timedelta
from src.models import ErrorCategory, ErrorSignature, FailureAnalysis, FailureRecord


def build_failures() -> list[FailureRecord]:
    """Build the list of sandbox-specific failure memories."""

    base_time = datetime.now(timezone.utc) - timedelta(hours=2)
    task_id = "seed-sandbox-knowledge"

    failures: list[FailureRecord] = []

    # ------------------------------------------------------------------ #
    # 1. curl: not found
    # ------------------------------------------------------------------ #
    failures.append(FailureRecord(
        id="seed_curl_notfound",
        task_id=task_id,
        attempt_number=1,
        timestamp=base_time + timedelta(minutes=0),
        signature=ErrorSignature(
            error_type="CommandNotFound",
            error_category=ErrorCategory.RUNTIME_ERROR,
            error_message="sh: curl: not found",
            code_context="curl -s https://api.example.com/data > response.json",
        ),
        analysis=FailureAnalysis(
            root_cause="The Blaxel Firecracker microVM sandbox uses a minimal sh shell and does not include curl or wget.",
            what_was_tried="Attempted to use curl to fetch data from a remote API endpoint.",
            why_it_failed="curl is not installed in the sandbox environment. Only node, npm, and npx are available.",
            suggested_fix=(
                "Use Node.js built-in http/https module instead. Example:\n"
                "node -e \"const https = require('https'); "
                "https.get('https://api.example.com/data', res => { "
                "let d=''; res.on('data', c => d+=c); "
                "res.on('end', () => { require('fs').writeFileSync('response.json', d); console.log('Done'); }); "
                "});\""
            ),
            anti_pattern="Never use curl, wget, or any system HTTP client in the Blaxel sandbox.",
            confidence=0.98,
        ),
        context={
            "task_type": "api_call",
            "language": "shell",
            "framework": "blaxel-sandbox",
            "sandbox": "firecracker",
            "available_tools": ["node", "npm", "npx"],
            "unavailable_tools": ["curl", "wget", "python3", "pip", "sudo", "apt-get"],
        },
        topics=["sandbox", "curl", "http", "blaxel", "node"],
        cost_usd=0.002,
    ))

    # ------------------------------------------------------------------ #
    # 2. sudo: not found
    # ------------------------------------------------------------------ #
    failures.append(FailureRecord(
        id="seed_sudo_notfound",
        task_id=task_id,
        attempt_number=2,
        timestamp=base_time + timedelta(minutes=5),
        signature=ErrorSignature(
            error_type="CommandNotFound",
            error_category=ErrorCategory.PERMISSION_ERROR,
            error_message="sh: sudo: not found",
            code_context="sudo npm install -g typescript",
        ),
        analysis=FailureAnalysis(
            root_cause="The Blaxel sandbox runs as root already — there is no sudo command and no need for privilege escalation.",
            what_was_tried="Attempted to use sudo to install a global npm package.",
            why_it_failed="sudo is not available in the sandbox. The sandbox already runs with sufficient permissions.",
            suggested_fix=(
                "Remove sudo from the command. Run directly:\n"
                "npm install -g typescript\n"
                "Or better yet, install locally: npm install typescript"
            ),
            anti_pattern="Never use sudo in the Blaxel sandbox. Commands already run with full permissions.",
            confidence=0.99,
        ),
        context={
            "task_type": "package_install",
            "language": "shell",
            "framework": "blaxel-sandbox",
            "sandbox": "firecracker",
        },
        topics=["sandbox", "sudo", "permissions", "blaxel", "npm"],
        cost_usd=0.001,
    ))

    # ------------------------------------------------------------------ #
    # 3. apt-get: not found
    # ------------------------------------------------------------------ #
    failures.append(FailureRecord(
        id="seed_aptget_notfound",
        task_id=task_id,
        attempt_number=3,
        timestamp=base_time + timedelta(minutes=10),
        signature=ErrorSignature(
            error_type="CommandNotFound",
            error_category=ErrorCategory.DEPENDENCY_ERROR,
            error_message="sh: apt-get: not found",
            code_context="apt-get install -y python3 build-essential",
        ),
        analysis=FailureAnalysis(
            root_cause="The Blaxel Firecracker sandbox has no OS package manager (apt-get, yum, apk). Only npm is available for installing packages.",
            what_was_tried="Attempted to install system packages using apt-get.",
            why_it_failed="No OS-level package manager exists in the sandbox. The sandbox is a minimal Firecracker microVM with only Node.js tooling.",
            suggested_fix=(
                "Cannot install OS-level packages. Use npm for all dependencies:\n"
                "npm install <package-name>\n"
                "For native modules, look for pure-JS alternatives on npm. "
                "For build tools, use npx to run build scripts."
            ),
            anti_pattern="Never use apt-get, yum, apk, or any OS package manager. Only npm/npx work.",
            confidence=0.99,
        ),
        context={
            "task_type": "package_install",
            "language": "shell",
            "framework": "blaxel-sandbox",
            "sandbox": "firecracker",
        },
        topics=["sandbox", "apt-get", "package-manager", "blaxel", "npm"],
        cost_usd=0.001,
    ))

    # ------------------------------------------------------------------ #
    # 4. sh: syntax error with &&
    # ------------------------------------------------------------------ #
    failures.append(FailureRecord(
        id="seed_sh_syntax_error",
        task_id=task_id,
        attempt_number=4,
        timestamp=base_time + timedelta(minutes=15),
        signature=ErrorSignature(
            error_type="ShellSyntaxError",
            error_category=ErrorCategory.RUNTIME_ERROR,
            error_message="sh: syntax error: unexpected end of file",
            code_context=(
                "cd /app && \\\n"
                "npm install && \\\n"
                "npm run build && \\\n"
                "npm start"
            ),
        ),
        analysis=FailureAnalysis(
            root_cause="The sandbox shell is sh (not bash). Multi-line commands with && and line continuations (\\) can fail with syntax errors in sh.",
            what_was_tried="Ran a chain of commands using && with backslash line continuations.",
            why_it_failed="sh handles line continuations and complex && chains differently from bash. Heredocs also don't always work.",
            suggested_fix=(
                "Use semicolons instead of && for command chaining, or run commands separately:\n"
                "cd /app ; npm install ; npm run build ; npm start\n"
                "Or run each command as a separate execution step.\n"
                "For writing files, use: echo 'content' > file.txt\n"
                "Or: node -e \"require('fs').writeFileSync('file.txt', 'content')\""
            ),
            anti_pattern="Avoid complex && chains, heredocs, and bash-specific syntax. Use simple sh-compatible commands.",
            confidence=0.95,
        ),
        context={
            "task_type": "build",
            "language": "shell",
            "framework": "blaxel-sandbox",
            "sandbox": "firecracker",
            "shell": "sh",
        },
        topics=["sandbox", "shell", "syntax", "sh", "bash", "blaxel"],
        cost_usd=0.003,
    ))

    # ------------------------------------------------------------------ #
    # 5. TypeScript strict mode errors
    # ------------------------------------------------------------------ #
    failures.append(FailureRecord(
        id="seed_ts_strict_mode",
        task_id=task_id,
        attempt_number=5,
        timestamp=base_time + timedelta(minutes=20),
        signature=ErrorSignature(
            error_type="TypeScriptCompileError",
            error_category=ErrorCategory.TYPE_ERROR,
            error_message=(
                "error TS2307: Cannot find module './components/Timeline' or its corresponding type declarations.\n"
                "error TS7006: Parameter 'props' implicitly has an 'any' type."
            ),
            code_context=(
                "import Timeline from './components/Timeline'\n"
                "export default function Page(props) { return <Timeline data={props.data} /> }"
            ),
        ),
        analysis=FailureAnalysis(
            root_cause="TypeScript strict mode requires explicit type annotations and proper module exports. Missing type declarations and implicit 'any' types cause compilation failures.",
            what_was_tried="Compiled a TypeScript/Next.js project with strict mode enabled.",
            why_it_failed="Components were not properly exported with type annotations. Parameters had implicit 'any' types which strict mode forbids.",
            suggested_fix=(
                "1. Use named exports with explicit types:\n"
                "   export function Timeline({ data }: { data: TimelineData[] }) { ... }\n"
                "2. Add type annotations to all function parameters:\n"
                "   export default function Page(props: { data: string[] }) { ... }\n"
                "3. Ensure components have .tsx extension and are default-exported:\n"
                "   export default Timeline;\n"
                "4. If module resolution fails, check tsconfig.json paths and baseUrl."
            ),
            anti_pattern="Never leave parameters untyped when TypeScript strict mode is enabled. Always use explicit exports.",
            confidence=0.92,
        ),
        context={
            "task_type": "build",
            "language": "typescript",
            "framework": "nextjs",
            "strict_mode": True,
        },
        topics=["typescript", "strict-mode", "nextjs", "types", "exports"],
        cost_usd=0.004,
    ))

    # ------------------------------------------------------------------ #
    # 6. Port 3000 already in use
    # ------------------------------------------------------------------ #
    failures.append(FailureRecord(
        id="seed_port_3000_inuse",
        task_id=task_id,
        attempt_number=6,
        timestamp=base_time + timedelta(minutes=25),
        signature=ErrorSignature(
            error_type="PortConflict",
            error_category=ErrorCategory.CONFIG_ERROR,
            error_message="Error: listen EADDRINUSE: address already in use :::3000",
            code_context="npm run dev  # or: next dev",
        ),
        analysis=FailureAnalysis(
            root_cause="Port 3000 is the default for many Node.js frameworks (Next.js, Express, React dev server). In the sandbox, a previous process or another service may already be using it.",
            what_was_tried="Started a Next.js dev server on the default port 3000.",
            why_it_failed="Port 3000 is already occupied by another process in the sandbox environment.",
            suggested_fix=(
                "Use a different port (4000 or higher):\n"
                "PORT=4000 npm run dev\n"
                "Or for Next.js specifically: npx next dev -p 4000\n"
                "Or set it in package.json scripts: \"dev\": \"next dev -p 4000\"\n"
                "To kill the existing process: kill $(lsof -t -i:3000) 2>/dev/null ; npm run dev"
            ),
            anti_pattern="Never assume port 3000 is available. Always specify an explicit port >= 4000.",
            confidence=0.97,
        ),
        context={
            "task_type": "server_start",
            "language": "javascript",
            "framework": "nextjs",
            "port": 3000,
        },
        topics=["port", "EADDRINUSE", "nextjs", "server", "config"],
        cost_usd=0.002,
    ))

    # ------------------------------------------------------------------ #
    # 7. python3: not found
    # ------------------------------------------------------------------ #
    failures.append(FailureRecord(
        id="seed_python3_notfound",
        task_id=task_id,
        attempt_number=7,
        timestamp=base_time + timedelta(minutes=30),
        signature=ErrorSignature(
            error_type="CommandNotFound",
            error_category=ErrorCategory.RUNTIME_ERROR,
            error_message="sh: python3: not found",
            code_context="python3 -c \"import json; print(json.dumps({'status': 'ok'}))\"",
        ),
        analysis=FailureAnalysis(
            root_cause="Python is not installed in the Blaxel Firecracker microVM sandbox. Only Node.js runtime is available.",
            what_was_tried="Attempted to run a Python script for JSON processing.",
            why_it_failed="python3 (and python, pip) are not available in the sandbox. The sandbox only provides node, npm, and npx.",
            suggested_fix=(
                "Rewrite the logic in Node.js instead:\n"
                "node -e \"console.log(JSON.stringify({status: 'ok'}))\"\n"
                "For file processing: node -e \"const fs = require('fs'); const data = JSON.parse(fs.readFileSync('input.json','utf8')); fs.writeFileSync('output.json', JSON.stringify(data, null, 2));\"\n"
                "For HTTP servers: use Node.js http module or install express via npm."
            ),
            anti_pattern="Never use python3, python, or pip in the Blaxel sandbox. Rewrite all Python logic in Node.js.",
            confidence=0.99,
        ),
        context={
            "task_type": "scripting",
            "language": "shell",
            "framework": "blaxel-sandbox",
            "sandbox": "firecracker",
            "available_tools": ["node", "npm", "npx"],
            "unavailable_tools": ["python3", "python", "pip"],
        },
        topics=["sandbox", "python", "node", "blaxel", "scripting"],
        cost_usd=0.001,
    ))

    # ------------------------------------------------------------------ #
    # 8. Heredoc syntax failure in sh
    # ------------------------------------------------------------------ #
    failures.append(FailureRecord(
        id="seed_heredoc_failure",
        task_id=task_id,
        attempt_number=8,
        timestamp=base_time + timedelta(minutes=35),
        signature=ErrorSignature(
            error_type="ShellSyntaxError",
            error_category=ErrorCategory.RUNTIME_ERROR,
            error_message="sh: syntax error: unexpected end of file (heredoc)",
            code_context=(
                "cat << 'EOF' > config.json\n"
                "{\n"
                "  \"port\": 4000,\n"
                "  \"host\": \"0.0.0.0\"\n"
                "}\n"
                "EOF"
            ),
        ),
        analysis=FailureAnalysis(
            root_cause="Heredocs (cat << EOF) are unreliable in the Blaxel sandbox sh shell. They frequently fail with unexpected end-of-file errors.",
            what_was_tried="Used a heredoc to write a multi-line JSON config file.",
            why_it_failed="The sh shell in the sandbox does not reliably support heredoc syntax. Line endings and quoting interact badly.",
            suggested_fix=(
                "Use echo or node to write files instead:\n"
                "echo '{\"port\": 4000, \"host\": \"0.0.0.0\"}' > config.json\n"
                "Or for multi-line content, use node:\n"
                "node -e \"require('fs').writeFileSync('config.json', JSON.stringify({port: 4000, host: '0.0.0.0'}, null, 2))\"\n"
                "For larger files, create a small .js script and run it with node."
            ),
            anti_pattern="Never use heredocs (cat << EOF) in the Blaxel sandbox. Use echo for single-line or node -e for multi-line file writes.",
            confidence=0.96,
        ),
        context={
            "task_type": "file_write",
            "language": "shell",
            "framework": "blaxel-sandbox",
            "sandbox": "firecracker",
            "shell": "sh",
        },
        topics=["sandbox", "heredoc", "shell", "sh", "file-write", "blaxel"],
        cost_usd=0.002,
    ))

    # ------------------------------------------------------------------ #
    # 9. Server hangs without backgrounding
    # ------------------------------------------------------------------ #
    failures.append(FailureRecord(
        id="seed_server_hang",
        task_id=task_id,
        attempt_number=9,
        timestamp=base_time + timedelta(minutes=40),
        signature=ErrorSignature(
            error_type="ProcessHang",
            error_category=ErrorCategory.RUNTIME_ERROR,
            error_message="Command timed out — server process blocks shell",
            code_context="npm install express && node server.js && curl localhost:3000/health",
        ),
        analysis=FailureAnalysis(
            root_cause=(
                "node server.js runs a long-lived HTTP server that never exits. "
                "The shell waits for it to finish, so subsequent commands (verification, tests) never run."
            ),
            what_was_tried="Started an Express server and tried to verify it in the same command chain.",
            why_it_failed=(
                "The server process blocks the shell indefinitely. Commands after && never execute "
                "because node server.js doesn't return."
            ),
            suggested_fix=(
                "Background the server and wait for it to start:\n"
                "node server.js &\n"
                "sleep 2\n"
                "node -e \"require('http').get('http://localhost:3000/health', r => { "
                "let d=''; r.on('data',c=>d+=c); r.on('end',()=>{ console.log(d); process.exit(0) }) })\"\n"
                "CRITICAL: Always use & to background servers, then sleep 1-2s before verifying."
            ),
            anti_pattern=(
                "NEVER chain server start with && verification. The server blocks forever. "
                "Always background with & and sleep before testing."
            ),
            confidence=0.99,
        ),
        context={
            "task_type": "server_start",
            "language": "javascript",
            "framework": "express",
            "sandbox": "firecracker",
        },
        topics=["server", "express", "background", "hang", "timeout", "blaxel"],
        cost_usd=0.003,
    ))

    # ------------------------------------------------------------------ #
    # 10. npm install needs --no-audit for speed
    # ------------------------------------------------------------------ #
    failures.append(FailureRecord(
        id="seed_npm_slow",
        task_id=task_id,
        attempt_number=10,
        timestamp=base_time + timedelta(minutes=45),
        signature=ErrorSignature(
            error_type="SlowExecution",
            error_category=ErrorCategory.RUNTIME_ERROR,
            error_message="npm install timed out or was extremely slow",
            code_context="npm install express body-parser cors morgan",
        ),
        analysis=FailureAnalysis(
            root_cause="npm install with default options runs audit checks and funding messages which slow execution in sandboxed environments.",
            what_was_tried="Ran npm install with multiple packages using default npm settings.",
            why_it_failed="npm audit and fund checks add significant overhead in sandboxes with limited network.",
            suggested_fix=(
                "Use --no-audit --no-fund flags to speed up installs:\n"
                "npm install --no-audit --no-fund express\n"
                "Also prefer installing one package at a time if possible."
            ),
            anti_pattern="Always use npm install --no-audit --no-fund in sandbox environments for faster installs.",
            confidence=0.90,
        ),
        context={
            "task_type": "package_install",
            "language": "javascript",
            "framework": "npm",
            "sandbox": "firecracker",
        },
        topics=["npm", "install", "performance", "sandbox", "blaxel"],
        cost_usd=0.001,
    ))

    return failures


def seed_redis(failures: list[FailureRecord]) -> None:
    """Store failures in Redis using the same format as RedisMemoryBackend."""

    redis_url = os.environ.get("REDIS_URL", "redis://localhost:6379")

    import redis as redis_lib
    client = redis_lib.from_url(redis_url, decode_responses=True)

    # Verify connection
    try:
        client.ping()
        print(f"Connected to Redis at {redis_url}")
    except Exception as exc:
        print(f"ERROR: Cannot connect to Redis at {redis_url}: {exc}")
        sys.exit(1)

    seeded_count = 0

    for failure in failures:
        failure_key = f"failure:{failure.id}"
        payload = failure.model_dump_json()
        score = failure.timestamp.timestamp()

        pipe = client.pipeline()

        # Store the full JSON blob + indexed fields (matches RedisMemoryBackend.store_failure)
        pipe.hset(failure_key, "data", payload)
        pipe.hset(failure_key, "error_hash", failure.signature.error_hash)
        pipe.hset(failure_key, "error_type", failure.signature.error_type)
        pipe.hset(failure_key, "error_category", failure.signature.error_category.value)
        pipe.hset(failure_key, "task_id", failure.task_id)

        # Per-task sorted set, scored by timestamp
        task_failures_key = f"task:{failure.task_id}:failures"
        pipe.zadd(task_failures_key, {failure.id: score})

        # Global failures sorted set
        pipe.zadd("failures:all", {failure.id: score})

        pipe.execute()
        seeded_count += 1

        print(
            f"  [{seeded_count}] {failure.id:30s}  "
            f"cat={failure.signature.error_category.value:20s}  "
            f"conf={failure.analysis.confidence:.2f}  "
            f"err={failure.signature.error_message[:60]}"
        )

    # Print summary
    total_in_redis = client.zcard("failures:all")
    print(f"\nSeeded {seeded_count} failure memories.")
    print(f"Total failures in Redis (failures:all): {total_in_redis}")

    # Quick verification — read one back
    sample_key = f"failure:{failures[0].id}"
    raw = client.hget(sample_key, "data")
    if raw:
        parsed = json.loads(raw)
        print(f"\nVerification — read back '{failures[0].id}':")
        print(f"  error_type:    {parsed['signature']['error_type']}")
        print(f"  error_message: {parsed['signature']['error_message'][:80]}")
        print(f"  suggested_fix: {parsed['analysis']['suggested_fix'][:80]}...")
    else:
        print(f"\nWARNING: Could not read back {sample_key}")


def flush_redis() -> None:
    """Flush all failure memories from Redis."""
    redis_url = os.environ.get("REDIS_URL", "redis://localhost:6379")
    import redis as redis_lib
    client = redis_lib.from_url(redis_url, decode_responses=True)

    # Delete all failure:* keys and sorted sets
    pipe = client.pipeline()
    for key in client.scan_iter("failure:*"):
        pipe.delete(key)
    for key in client.scan_iter("task:*:failures"):
        pipe.delete(key)
    for key in client.scan_iter("success:*"):
        pipe.delete(key)
    pipe.delete("failures:all")
    pipe.delete("successes:all")
    # Also clear any vector set keys
    for key in client.scan_iter("reloop-failures:*"):
        pipe.delete(key)
    pipe.execute()
    print("Flushed all failure/success memories from Redis.")


def main() -> None:
    print("=" * 70)
    print("ReLoop — Seeding Redis with Blaxel Sandbox Failure Memories")
    print("=" * 70)
    print()

    if "--flush" in sys.argv:
        flush_redis()
        print()

    failures = build_failures()
    print(f"Built {len(failures)} failure records.\n")

    seed_redis(failures)

    print()
    print("Done. The agent will now recall these sandbox constraints")
    print("when it encounters similar errors in Blaxel microVMs.")
    print("=" * 70)


if __name__ == "__main__":
    main()
