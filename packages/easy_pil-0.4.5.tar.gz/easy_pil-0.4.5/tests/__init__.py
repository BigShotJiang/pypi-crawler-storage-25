"""Tests for easy-pil."""
