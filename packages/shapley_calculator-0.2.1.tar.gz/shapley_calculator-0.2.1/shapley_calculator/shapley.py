import numpy as np
from math import factorial
import random
from tqdm import tqdm
import matplotlib.pyplot as plt
import concurrent.futures
import multiprocessing
import warnings
from .utils import get_kernel_weights, solve_kernel_shap


class _ModelWrapper:
    """Internal wrapper to unify predict and predict_proba interfaces"""
    def __init__(self, model, model_type='auto', class_idx=1):
        self.model = model
        self.model_type = model_type
        self.class_idx = class_idx
        
        # Auto-detect model type if not specified
        if self.model_type == 'auto':
            if hasattr(model, 'predict_proba'):
                self.model_type = 'classification'
            else:
                self.model_type = 'regression'

    def predict(self, X):
        if self.model_type == 'classification':
            # Returns probability of the selected class
            return self.model.predict_proba(X)[:, self.class_idx]
        else:
            return self.model.predict(X)


class ShapleyValueCalculator:
    def __init__(self, model, X, y=None, num_samples=100, random_state=42, 
                 model_type='auto', class_idx=1, n_jobs=-1):
        """
        Initialize Shapley Value Calculator v0.2.1
        
        Args:
            model: Trained model with predict or predict_proba method
            X: numpy array or list - input data shape (n_samples, n_features)
            y: Optional target values
            num_samples: int - number of samples for Shapley value estimation
            random_state: int - seed for reproducibility
            model_type: 'auto', 'regression', or 'classification'
            class_idx: int - index of class to explain (for classification)
            n_jobs: int - number of parallel jobs (-1 for all CPUs)
        """
        self.model = _ModelWrapper(model, model_type, class_idx)
        self.X = np.array(X)
        self.y = np.array(y) if y is not None else None
        self.num_samples = num_samples
        self.n_features = self.X.shape[1]
        self.n_jobs = n_jobs if n_jobs != -1 else multiprocessing.cpu_count()
        self.baseline = self._get_baseline_prediction()
        self.random_state = random_state
        self.kernel_weights = get_kernel_weights(self.n_features)
        
        # Set seed
        random.seed(self.random_state)
        np.random.seed(self.random_state)

    def _get_baseline_prediction(self):
        """Get baseline prediction on zero features"""
        X_baseline = np.zeros((1, self.n_features))
        return self.model.predict(X_baseline)[0]

    def _calculate_weights(self):
        """DEPRECATED: Use get_kernel_weights from utils"""
        return self.kernel_weights

    def _get_predictions_batch(self, x, coalitions):
        """Get model predictions for a batch of coalitions"""
        X_modified = np.zeros((len(coalitions), self.n_features))
        for i, coalition in enumerate(coalitions):
            X_modified[i, coalition] = x[coalition]
        return self.model.predict(X_modified)

    def get_shapley_values(self, sample_idx=None, normalize=False):
        """
        Calculate Shapley values for a given example or averaged over all examples
        
        Args:
            sample_idx: index of the example to calculate or None to average over all examples
            normalize: bool, whether to normalize Shapley values to sum to 1
        """
        if sample_idx is not None:
            values = self._compute_shapley_for_sample(self.X[sample_idx])
        else:
            if self.n_jobs > 1 and len(self.X) > 1:
                print(f"Computing Shapley values for {len(self.X)} samples using {self.n_jobs} cores (ProcessPool)...")
                # Using ProcessPoolExecutor for true CPU parallelization
                with concurrent.futures.ProcessPoolExecutor(max_workers=self.n_jobs) as executor:
                    results = list(tqdm(executor.map(self._compute_shapley_for_sample, self.X), 
                                       total=len(self.X), desc="Processing samples"))
                values = np.mean(results, axis=0)
            else:
                print("Computing Shapley values for all samples sequentially...")
                values = np.mean([self._compute_shapley_for_sample(x) for x in tqdm(self.X)], axis=0)
        
        if normalize:
            # Handle case when there are negative values
            abs_values = np.abs(values)
            total = np.sum(abs_values)
            if total != 0:
                # Normalize while preserving signs and ensuring exact sum of 1
                signs = np.sign(values)
                normalized = abs_values / total
                values = signs * normalized
                
                # Adjust to ensure exact sum of 1
                values = values / np.sum(np.abs(values))
                
        return values

    def _compute_shapley_for_sample(self, x):
        """Calculate Shapley values for a single example with Hybrid Exact/Sampling logic"""
        # Set seed before each calculation
        random.seed(self.random_state)
        np.random.seed(self.random_state)
        
        n = self.n_features
        
        # 1. Check if exact calculation is feasible
        if n <= 10: # for n <= 10, 2^10 = 1024, very fast
            num_coalitions = 2**n
            coalition_matrix = np.zeros((num_coalitions, n))
            for i in range(num_coalitions):
                # Generate binary representation
                bin_str = bin(i)[2:].zfill(n)
                coalition_matrix[i] = np.array([int(b) for b in bin_str])
            
            row_sums = coalition_matrix.sum(axis=1)
            weights = np.array([self.kernel_weights[int(s)] for s in row_sums])
        else:
            # 2. Vectorized Sampling for large n
            num_samples = self.num_samples
            
            # Hybrid approach: Exact for size 1 and n-1, sample others
            # Features (size 1)
            exact_size_1 = np.eye(n)
            # All but one (size n-1)
            exact_size_n_1 = 1 - np.eye(n)
            
            # Random samples for the rest
            n_random = max(0, num_samples - 2*n)
            if n_random > 0:
                random_coalitions = np.random.randint(0, 2, size=(n_random, n))
                coalition_matrix = np.vstack([exact_size_1, exact_size_n_1, random_coalitions])
            else:
                coalition_matrix = np.vstack([exact_size_1, exact_size_n_1])
            
            row_sums = coalition_matrix.sum(axis=1)
            weights = np.array([self.kernel_weights[int(s)] for s in row_sums])
        
        # Handle cases where weight might be inf (size 0 or n)
        weights = np.clip(weights, 0, 1e6)
        
        # Vectorized prediction
        X_modified = np.zeros((len(coalition_matrix), n))
        for i in range(len(coalition_matrix)):
            mask = coalition_matrix[i].astype(bool)
            X_modified[i, mask] = x[mask]
        
        predictions = self.model.predict(X_modified)
        
        # Solve for Shapley values
        shapley_values = solve_kernel_shap(
            coalition_matrix, 
            predictions, 
            weights, 
            self.baseline,
            self.model.predict(x.reshape(1, -1))[0]
        )
        
        return shapley_values

    def plot_shapley_values(self, feature_names=None, sample_idx=None, normalize=True, title=None):
        """
        Visualize Shapley values as a horizontal bar chart
        
        Args:
            feature_names: list of feature names
            sample_idx: index of a specific example or None for averaged values
            normalize: whether to normalize Shapley values
            title: title of the chart
        """
        values = self.get_shapley_values(sample_idx=sample_idx, normalize=normalize)
        
        if feature_names is None:
            feature_names = [f"Feature {i}" for i in range(self.n_features)]
            
        # Create color scheme
        colors = ['darkred' if x > 0 else 'darkblue' for x in values]
        alphas = np.abs(values) / max(np.abs(values))  # Normalize for transparency
        
        # Create plot
        plt.figure(figsize=(10, 6))
        y_pos = np.arange(len(feature_names))
        
        bars = plt.barh(y_pos, values, align='center', alpha=0.8)
        
        # Set colors with gradient
        for bar, color, alpha in zip(bars, colors, alphas):
            bar.set_color(color)
            bar.set_alpha(alpha)
        
        plt.yticks(y_pos, feature_names)
        plt.xlabel('Shapley Value')
        plt.title(title or 'Feature Importance (Shapley Values)')
        
        # Add vertical line at zero
        plt.axvline(x=0, color='black', linestyle='-', linewidth=0.5)
        
        # Add values at the ends of bars
        for i, v in enumerate(values):
            plt.text(v + np.sign(v) * 0.01, i, f'{v:.3f}', 
                    ha='left' if v > 0 else 'right', 
                    va='center')
        
        plt.tight_layout()
        return plt.gcf()

    def plot_summary(self, feature_names=None, title=None):
        """
        Visualize Shapley values across all samples using a Beeswarm plot
        
        Args:
            feature_names: list of feature names
            title: title of the chart
        """
        if feature_names is None:
            feature_names = [f"Feature {i}" for i in range(self.n_features)]

        # Get values for all samples
        print(f"Calculating all samples for summary plot using {self.n_jobs} cores...")
        with concurrent.futures.ProcessPoolExecutor(max_workers=self.n_jobs) as executor:
            all_shap_values = list(tqdm(executor.map(self._compute_shapley_for_sample, self.X), 
                                       total=len(self.X), desc="Processing samples"))
        
        all_shap_values = np.array(all_shap_values)
        
        plt.figure(figsize=(12, 8))
        y_pos = np.arange(len(feature_names))
        
        # Sort features by mean absolute shapley value
        mean_abs_shap = np.abs(all_shap_values).mean(0)
        idx_sorted = np.argsort(mean_abs_shap)
        
        for i, idx in enumerate(idx_sorted):
            values = all_shap_values[:, idx]
            # Add jitter
            jitter = np.random.normal(0, 0.05, size=len(values))
            
            # Color points by feature value (normalized)
            f_values = self.X[:, idx]
            norm_f_values = (f_values - f_values.min()) / (f_values.max() - f_values.min() + 1e-8)
            
            sc = plt.scatter(values, i + jitter, c=norm_f_values, 
                            cmap='coolwarm', alpha=0.6, s=15, edgecolors='none')
        
        plt.yticks(np.arange(len(feature_names)), [feature_names[i] for i in idx_sorted])
        plt.axvline(x=0, color='gray', linestyle='--', alpha=0.5)
        plt.xlabel('Shapley Value (impact on model output)')
        plt.title(title or 'Summary Plot (Impact Distribution)')
        
        # Add colorbar
        cb = plt.colorbar(sc, label='Feature Value (Low to High)')
        cb.set_ticks([0, 1])
        cb.set_ticklabels(['Low', 'High'])
        
        plt.tight_layout()
        return plt.gcf()

    def plot_local(self, sample_idx, feature_names=None, title=None):
        """
        Enhanced visualization for a single sample with actual feature values
        """
        values = self.get_shapley_values(sample_idx=sample_idx)
        x_sample = self.X[sample_idx]
        
        if feature_names is None:
            feature_names = [f"Feature {i}" for i in range(self.n_features)]
            
        labels = [f"{name}\n({val:.2f})" for name, val in zip(feature_names, x_sample)]
        
        # Sort by impact
        idx_sorted = np.argsort(np.abs(values))
        
        plt.figure(figsize=(10, 6))
        colors = ['red' if v > 0 else 'blue' for v in values[idx_sorted]]
        
        plt.barh(np.arange(len(values)), values[idx_sorted], color=colors, alpha=0.7)
        plt.yticks(np.arange(len(values)), [labels[i] for i in idx_sorted])
        plt.xlabel('Impact (Shapley Value)')
        plt.title(title or f'Sample Explanation (Sample #{sample_idx})')
        plt.axvline(x=0, color='black', lw=0.5)
        
        plt.tight_layout()
        return plt.gcf()

    def get_summary_report(self, feature_names=None):
        """
        Generate a text-based importance report for console/Jupyter
        """
        values = self.get_shapley_values(normalize=True)
        if feature_names is None:
            feature_names = [f"Feature {i}" for i in range(self.n_features)]
            
        # Combine and sort
        importance = list(zip(feature_names, values))
        importance.sort(key=lambda x: abs(x[1]), reverse=True)
        
        report = "\n" + "="*50 + "\n"
        report += " SHAPLEY IMPORTANCE REPORT (v0.2.1)\n"
        report += "="*50 + "\n"
        report += f"{'Feature':<25} | {'Importance':<15} | {'Bar'}\n"
        report += "-"*50 + "\n"
        
        for name, val in importance:
            bar_size = int(abs(val) * 20)
            bar = ("#" if val > 0 else "x") * bar_size
            report += f"{name:<25} | {val:>10.4f}      | {bar}\n"
            
        report += "="*50 + "\n"
        report += f"Total Samples: {len(self.X)}\n"
        report += f"Model Type:    {self.model.model_type.upper()}\n"
        report += "-"*50 + "\n"
        report += "💡 ПОДСКАЗКА ДЛЯ ПОНИМАНИЯ (ELI5):\n"
        report += " (+) Плюс: признак как 'друг', который помогает башне расти (увеличивает прогноз).\n"
        report += " (-) Минус: признак 'уменьшает' результат (тянет прогноз вниз).\n"
        report += "Чем больше значков (# или x), тем сильнее влияние признака!\n"
        report += "="*50 + "\n"
        
        return report