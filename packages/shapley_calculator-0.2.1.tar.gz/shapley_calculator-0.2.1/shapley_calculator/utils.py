import numpy as np
from math import factorial, comb

def get_kernel_weights(n_features):
    """
    Precompute KernelSHAP weights for all coalition sizes.
    w(S) = (n-1) / (comb(n, |S|) * |S| * (n-|S|))
    """
    weights = np.zeros(n_features + 1)
    for size in range(1, n_features):
        weights[size] = (n_features - 1) / (comb(n_features, size) * size * (n_features - size))
    
    # Coalitions of size 0 and n features theoretically have infinite weight
    # In practice, we handle them as constraints or very large values
    weights[0] = 1e6 
    weights[n_features] = 1e6
    return weights

def solve_kernel_shap(coalitions, predictions, weights, baseline, full_prediction):
    """
    Solve for Shapley values using Weighted Least Squares.
    Ensures that the sum of Shapley values roughly equals (full_prediction - baseline).
    """
    # y is the deviation from the baseline f(null)
    y = predictions - baseline
    
    # We want to solve X @ phi = y with weights W
    # where X is the binary coalition matrix and phi are the Shapley values
    
    # Use sqrt(W) for weighted least squares if using standard lstsq
    # Alternatively, use W @ X for normal equations
    sqrt_W = np.sqrt(weights)
    X_weighted = coalitions * sqrt_W[:, np.newaxis]
    y_weighted = y * sqrt_W
    
    try:
        # Solve using least squares
        # rcond=None handles small singular values
        phi, residuals, rank, s = np.linalg.lstsq(X_weighted, y_weighted, rcond=None)
        
        # Simple adjustment to ensure sum-to-prediction property (Efficiency Axiom)
        # TreeShap followed this exactly, KernelSHAP can have small residuals
        prediction_diff = full_prediction - baseline
        current_sum = np.sum(phi)
        
        if abs(current_sum) > 1e-9:
            # Distribute error proportionally or equally
            error = prediction_diff - current_sum
            phi += error / len(phi)
            
        return phi
    except Exception as e:
        print(f"Error solving KernelSHAP: {e}")
        return np.zeros(coalitions.shape[1])
