import typer
from pathlib import Path

from agentgrid_cli.errors import map_exit_code
from agentgrid_cli.executors.deploy_executor import DeployExecutor


def deploy() -> None:
    executor = DeployExecutor(config_path=Path("agentgrid.yaml"))
    result = executor.execute(progress=typer.echo)
    if not result.success:
        typer.echo(f"deploy failed: {result.message}")
        raise typer.Exit(code=map_exit_code(result.error_code))
    typer.echo(result.message)


def register(app: typer.Typer) -> None:
    app.command("deploy")(deploy)
