import typer

from agentgrid_cli import __version__


def version() -> None:
    typer.echo(f"agentgrid-cli {__version__}")


def register(app: typer.Typer) -> None:
    app.command("version")(version)
