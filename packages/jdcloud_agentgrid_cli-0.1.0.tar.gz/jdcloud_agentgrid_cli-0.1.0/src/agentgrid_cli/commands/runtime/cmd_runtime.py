import json

import typer

from agentgrid_cli.adapters.jdcloud.jcr_client import is_jcr_uri
from agentgrid_cli.adapters.jdcloud.runtime_client import RuntimeClient

runtime_app = typer.Typer(help="AgentRuntime 资源管理")


@runtime_app.command("create")
def runtime_create(
    name: str = typer.Option(..., "--name"),
    role_name: str = typer.Option(..., "--role-name"),
    artifact_type: str = typer.Option(..., "--artifact-type"),
    artifact_url: str = typer.Option(..., "--artifact-url"),
) -> None:
    if artifact_type == "DockerImage" and not is_jcr_uri(artifact_url):
        typer.echo("artifact-url must be a JCR URI")
        raise typer.Exit(code=1)

    result = RuntimeClient().create_runtime(
        name=name,
        role_name=role_name,
        artifact_type=artifact_type,
        artifact_url=artifact_url,
    )
    typer.echo(json.dumps(result, ensure_ascii=False))


@runtime_app.command("get")
def runtime_get(runtime_id: str = typer.Option(..., "--runtime-id")) -> None:
    typer.echo(json.dumps(RuntimeClient().get_runtime(runtime_id), ensure_ascii=False))


@runtime_app.command("update")
def runtime_update(
    runtime_id: str = typer.Option(..., "--runtime-id"),
    description: str | None = typer.Option(None, "--description"),
    artifact_url: str | None = typer.Option(None, "--artifact-url"),
) -> None:
    updates: dict[str, object] = {}
    if description is not None:
        updates["description"] = description
    if artifact_url is not None:
        if not is_jcr_uri(artifact_url):
            typer.echo("artifact-url must be a JCR URI")
            raise typer.Exit(code=1)
        updates["artifact_url"] = artifact_url
    if not updates:
        typer.echo("no updates provided")
        raise typer.Exit(code=1)

    result = RuntimeClient().update_runtime(runtime_id, **updates)
    typer.echo(json.dumps(result, ensure_ascii=False))


@runtime_app.command("delete")
def runtime_delete(runtime_id: str = typer.Option(..., "--runtime-id")) -> None:
    typer.echo(
        json.dumps(RuntimeClient().delete_runtime(runtime_id), ensure_ascii=False)
    )


@runtime_app.command("list")
def runtime_list(
    limit: int | None = typer.Option(None, "--limit"),
    next_token: str | None = typer.Option(None, "--next-token"),
) -> None:
    runtimes = RuntimeClient().list_runtimes(limit=limit, next_token=next_token)
    typer.echo(json.dumps(runtimes, ensure_ascii=False))


@runtime_app.command("release")
def runtime_release(
    runtime_id: str = typer.Option(..., "--runtime-id"),
    version: str = typer.Option(..., "--version"),
) -> None:
    typer.echo(
        json.dumps(
            RuntimeClient().release_runtime(runtime_id, version=version),
            ensure_ascii=False,
        )
    )


@runtime_app.command("version")
def runtime_version(
    runtime_id: str = typer.Option(..., "--runtime-id"),
    version: str | None = typer.Option(None, "--version"),
) -> None:
    typer.echo(
        json.dumps(
            RuntimeClient().get_runtime_version(runtime_id, version=version),
            ensure_ascii=False,
        )
    )


@runtime_app.command("versions")
def runtime_versions(runtime_id: str = typer.Option(..., "--runtime-id")) -> None:
    typer.echo(
        json.dumps(
            RuntimeClient().list_runtime_versions(runtime_id), ensure_ascii=False
        )
    )
