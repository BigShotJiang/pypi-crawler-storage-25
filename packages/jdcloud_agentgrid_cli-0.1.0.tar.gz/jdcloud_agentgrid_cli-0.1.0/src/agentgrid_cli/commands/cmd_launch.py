import logging

import typer
from pathlib import Path

from agentgrid_cli.errors import map_exit_code
from agentgrid_cli.executors.lifecycle_executor import LifecycleExecutor

logger = logging.getLogger(__name__)


def launch(
    image_uri: str | None = typer.Option(None, "--image-uri", help="镜像 URI"),
) -> None:
    logger.info("[launch] 开始执行 launch 命令")
    executor = LifecycleExecutor(config_path=Path("agentgrid.yaml"))
    result = executor.launch(image_uri=image_uri, progress=typer.echo)
    if not result.success:
        logger.error("[launch] launch 失败: %s", result.message)
        typer.echo(f"launch failed: {result.message}")
        raise typer.Exit(code=map_exit_code(result.error_code))
    logger.info("[launch] launch 完成")
    typer.echo(f"launch success: {result.message}")


def register(app: typer.Typer) -> None:
    app.command("launch")(launch)
