import json

import typer

from agentgrid_cli.adapters.jdcloud.tools_client import ToolsClient
from agentgrid_cli.commands.tools.cmd_tools_session import session_app

tools_app = typer.Typer(help="AgentTools 资源管理")
tools_app.add_typer(session_app, name="session")


@tools_app.command("create")
def tools_create(
    name: str = typer.Option(..., "--name"),
    description: str | None = typer.Option(None, "--description"),
) -> None:
    typer.echo(
        json.dumps(
            ToolsClient().create_tool(name=name, description=description),
            ensure_ascii=False,
        )
    )


@tools_app.command("show")
def tools_show(tool_id: str = typer.Option(..., "--tool-id")) -> None:
    typer.echo(json.dumps(ToolsClient().get_tool(tool_id), ensure_ascii=False))


@tools_app.command("delete")
def tools_delete(tool_id: str = typer.Option(..., "--tool-id")) -> None:
    typer.echo(json.dumps(ToolsClient().delete_tool(tool_id), ensure_ascii=False))


@tools_app.command("list")
def tools_list() -> None:
    typer.echo(json.dumps(ToolsClient().list_tools(), ensure_ascii=False))
