import json

import typer

from agentgrid_cli.adapters.jdcloud.tools_client import ToolsClient

session_app = typer.Typer(help="Tools Session 子命令")


@session_app.command("create")
def session_create(
    tool_id: str = typer.Option(..., "--tool-id"),
    name: str | None = typer.Option(None, "--name"),
    max_life_time: int | None = typer.Option(None, "--max-life-time"),
) -> None:
    typer.echo(
        json.dumps(
            ToolsClient().create_session(
                tool_id=tool_id,
                name=name,
                max_life_time=max_life_time,
            ),
            ensure_ascii=False,
        )
    )


@session_app.command("show")
def session_show(
    session_id: str = typer.Option(..., "--session-id"),
    tool_id: str = typer.Option(..., "--tool-id"),
) -> None:
    typer.echo(
        json.dumps(
            ToolsClient().get_session(session_id=session_id, tool_id=tool_id),
            ensure_ascii=False,
        )
    )


@session_app.command("delete")
def session_delete(
    session_id: str = typer.Option(..., "--session-id"),
    tool_id: str = typer.Option(..., "--tool-id"),
) -> None:
    typer.echo(
        json.dumps(
            ToolsClient().delete_session(session_id=session_id, tool_id=tool_id),
            ensure_ascii=False,
        )
    )


@session_app.command("list")
def session_list(tool_id: str = typer.Option(..., "--tool-id")) -> None:
    typer.echo(
        json.dumps(ToolsClient().list_sessions(tool_id=tool_id), ensure_ascii=False)
    )


@session_app.command("logs")
def session_logs(
    session_id: str = typer.Option(..., "--session-id"),
    limit: int | None = typer.Option(None, "--limit"),
) -> None:
    _ = session_id
    _ = limit
    typer.echo("tools session logs 暂不支持")
    raise typer.Exit(code=1)


@session_app.command("set-ttl")
def session_set_ttl(
    session_id: str = typer.Option(..., "--session-id"),
    ttl_seconds: int = typer.Option(..., "--ttl-seconds"),
) -> None:
    _ = session_id
    _ = ttl_seconds
    typer.echo("tools session set-ttl 暂不支持")
    raise typer.Exit(code=1)
