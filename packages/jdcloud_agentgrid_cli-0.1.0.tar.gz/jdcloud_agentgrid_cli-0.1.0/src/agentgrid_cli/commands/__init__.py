import typer

from .cmd_build import register as register_build
from .cmd_config import register as register_config
from .cmd_deploy import register as register_deploy
from .cmd_destroy import register as register_destroy
from .cmd_init import register as register_init
from .cmd_invoke import register as register_invoke
from .cmd_launch import register as register_launch
from .cmd_status import register as register_status
from .cmd_version import register as register_version


def register_root_commands(app: typer.Typer) -> None:
    register_version(app)
    register_init(app)
    register_config(app)
    register_launch(app)
    register_build(app)
    register_deploy(app)
    register_status(app)
    register_invoke(app)
    register_destroy(app)
