import typer
from pathlib import Path

from agentgrid_cli.errors import map_exit_code
from agentgrid_cli.executors.build_executor import BuildExecutor


def build(
    image_uri: str | None = typer.Option(None, "--image-uri", help="镜像 URI"),
    dependency_mode: str | None = typer.Option(
        None, "--dependency-mode", help="uv 或 pip，覆盖配置文件中的值"
    ),
) -> None:
    executor = BuildExecutor(config_path=Path("agentgrid.yaml"))
    result = executor.execute(
        image_uri=image_uri,
        dependency_mode=dependency_mode,
        progress=typer.echo,
    )
    if not result.success:
        typer.echo(f"build failed: {result.message}")
        raise typer.Exit(code=map_exit_code(result.error_code))
    typer.echo(result.message)


def register(app: typer.Typer) -> None:
    app.command("build")(build)
