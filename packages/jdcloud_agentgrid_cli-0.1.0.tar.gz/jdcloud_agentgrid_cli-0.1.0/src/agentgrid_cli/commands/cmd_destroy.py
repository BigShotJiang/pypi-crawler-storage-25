import typer
from pathlib import Path

from agentgrid_cli.errors import map_exit_code
from agentgrid_cli.executors.lifecycle_executor import LifecycleExecutor


def destroy() -> None:
    executor = LifecycleExecutor(config_path=Path("agentgrid.yaml"))
    result = executor.destroy()
    if not result.success:
        typer.echo(f"destroy failed: {result.message}")
        raise typer.Exit(code=map_exit_code(result.error_code))
    typer.echo(result.message)


def register(app: typer.Typer) -> None:
    app.command("destroy")(destroy)
