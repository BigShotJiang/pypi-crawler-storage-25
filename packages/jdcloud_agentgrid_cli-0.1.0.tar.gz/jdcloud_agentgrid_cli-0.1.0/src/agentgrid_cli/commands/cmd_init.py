import typer
from pathlib import Path

from agentgrid_cli.services.init_service import SUPPORTED_TEMPLATES, init_project


def init(
    project: str = typer.Argument(..., help="项目目录名"),
    template: str = typer.Option("basic", "--template", help="模板名"),
) -> None:
    if template not in SUPPORTED_TEMPLATES:
        raise typer.BadParameter(
            f"template must be one of: {', '.join(sorted(SUPPORTED_TEMPLATES))}"
        )

    try:
        created = init_project(Path(project), template)
    except Exception as exc:  # noqa: BLE001
        typer.echo(f"init failed: {exc}")
        raise typer.Exit(code=1)

    typer.echo(f"initialized {project}")
    for path in created:
        typer.echo(f"created: {path}")


def register(app: typer.Typer) -> None:
    app.command("init")(init)
