import typer
from pathlib import Path

from agentgrid_cli.errors import map_exit_code
from agentgrid_cli.executors.status_executor import StatusExecutor


def status() -> None:
    executor = StatusExecutor(config_path=Path("agentgrid.yaml"))
    result = executor.execute()
    if not result.success:
        typer.echo(f"status failed: {result.message}")
        raise typer.Exit(code=map_exit_code(result.error_code))
    typer.echo(result.message)


def register(app: typer.Typer) -> None:
    app.command("status")(status)
