import typer
from pathlib import Path

from agentgrid_cli.services.config_service import (
    apply_config_updates,
    dump_yaml,
    interactive_config,
    load_config,
)


def config(
    show: bool = typer.Option(False, "--show", help="显示配置"),
    dry_run: bool = typer.Option(False, "--dry-run", help="仅预览不落盘"),
    launch_type: str | None = typer.Option(
        None, "--launch-type", help="local 或 cloud"
    ),
    dependency_mode: str | None = typer.Option(
        None, "--dependency-mode", help="uv 或 pip"
    ),
) -> None:
    config_path = Path("agentgrid.yaml")

    try:
        if show and launch_type is None and dependency_mode is None and not dry_run:
            data = load_config(config_path)
            typer.echo(dump_yaml(data))
            return

        if launch_type is not None or dependency_mode is not None or dry_run:
            data = apply_config_updates(
                config_path=config_path,
                launch_type=launch_type,
                dependency_mode=dependency_mode,
                dry_run=dry_run,
            )
        else:
            data = interactive_config(config_path)
            if show:
                typer.echo(dump_yaml(data))
            return
    except ValueError as exc:
        raise typer.BadParameter(str(exc))

    if show or dry_run:
        typer.echo(dump_yaml(data))
        return

    typer.echo("config updated")


def register(app: typer.Typer) -> None:
    app.command("config")(config)
