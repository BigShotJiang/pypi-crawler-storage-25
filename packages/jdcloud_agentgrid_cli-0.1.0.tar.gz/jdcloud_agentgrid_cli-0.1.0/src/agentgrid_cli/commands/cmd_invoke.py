import typer
import json
from pathlib import Path
from typing import Any

import click

from agentgrid_cli.errors import map_exit_code
from agentgrid_cli.executors.invoke_executor import InvokeExecutor


_EXIT_WORDS = {"exit", "quit", "q"}


def _is_stream_response(value: Any) -> bool:
    if isinstance(value, (str, bytes, dict)):
        return False
    return hasattr(value, "__iter__")


def _extract_stream_text(event: Any) -> tuple[str, bool]:
    if not isinstance(event, dict):
        return str(event), False

    event_type = str(event.get("event") or event.get("type") or "").strip().lower()
    is_done = event_type in {"done", "finish", "finished", "complete", "completed"}

    for key in ("content", "text", "delta", "output", "output_text"):
        value = event.get(key)
        if isinstance(value, str) and value:
            return value, is_done

    data = event.get("data")
    if isinstance(data, dict):
        for key in ("content", "text", "delta", "output", "output_text"):
            value = data.get(key)
            if isinstance(value, str) and value:
                return value, is_done

    return json.dumps(event, ensure_ascii=False), is_done


def _print_invoke_output(output: Any) -> None:
    if _is_stream_response(output):
        has_printed = False
        ended_with_newline = False
        for event in output:
            text, is_done = _extract_stream_text(event)
            if text:
                typer.echo(text, nl=False)
                has_printed = True
                ended_with_newline = False
            if is_done:
                typer.echo("")
                ended_with_newline = True
        if has_printed and not ended_with_newline:
            typer.echo("")
        return

    if isinstance(output, dict):
        typer.echo(json.dumps(output, ensure_ascii=False))
        return

    typer.echo(str(output))


def _prompt_next_payload() -> str | None:
    try:
        user_input = typer.prompt(
            "下一轮 payload（输入 exit/quit/q 退出）",
            default="",
            show_default=False,
        )
    except (click.Abort, EOFError, KeyboardInterrupt):
        return None
    return user_input.strip()


def invoke(
    payload: str = typer.Argument("ping", help="第一轮调用 payload"),
    api_key: str | None = typer.Option(
        None,
        "--api-key",
        envvar="AGENTGRID_RUNTIME_API_KEY",
        help="云端 Runtime API Key",
    ),
) -> None:
    executor = InvokeExecutor(config_path=Path("agentgrid.yaml"))
    context_result = executor.resolve_context(api_key=api_key)
    if not context_result.success:
        typer.echo(f"invoke failed: {context_result.message}")
        raise typer.Exit(code=map_exit_code(context_result.error_code))

    context = context_result.data or {}
    launch_type = str(context.get("launch_type", "local"))

    current_payload = payload.strip()
    if not current_payload or current_payload.lower() in _EXIT_WORDS:
        return

    if launch_type == "cloud":
        from agentgrid_cli.adapters.jdcloud.runtime_client import RuntimeClient

        runtime_client = RuntimeClient(
            region_id=str(context.get("region_id", "cn-north-1"))
        )
        runtime_id = str(context.get("runtime_id", ""))
        try:
            with runtime_client.open_runtime_session(runtime_id) as session:
                while True:
                    result = executor.execute(
                        payload=current_payload,
                        context=context,
                        session=session,
                    )
                    if not result.success:
                        typer.echo(f"invoke failed: {result.message}")
                        raise typer.Exit(code=map_exit_code(result.error_code))

                    output = (result.data or {}).get("output", result.message)
                    _print_invoke_output(output)

                    next_payload = _prompt_next_payload()
                    if next_payload is None:
                        return
                    if not next_payload:
                        continue
                    if next_payload.lower() in _EXIT_WORDS:
                        return
                    current_payload = next_payload
        except typer.Exit:
            raise
        except Exception as exc:  # noqa: BLE001
            typer.echo(f"invoke failed: {exc}")
            raise typer.Exit(code=map_exit_code("UNKNOWN_ERROR"))

    while True:
        result = executor.execute(payload=current_payload, context=context)
        if not result.success:
            typer.echo(f"invoke failed: {result.message}")
            raise typer.Exit(code=map_exit_code(result.error_code))

        output = (result.data or {}).get("output", result.message)
        _print_invoke_output(output)

        next_payload = _prompt_next_payload()
        if next_payload is None:
            return
        if not next_payload:
            continue
        if next_payload.lower() in _EXIT_WORDS:
            return
        current_payload = next_payload


def register(app: typer.Typer) -> None:
    app.command("invoke")(invoke)
