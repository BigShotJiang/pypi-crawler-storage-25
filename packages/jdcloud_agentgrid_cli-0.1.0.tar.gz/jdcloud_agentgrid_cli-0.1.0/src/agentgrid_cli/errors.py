EXIT_CODE_MAP = {
    "AUTH_FAILED": 11,
    "CONFIG_INVALID": 12,
    "RESOURCE_NOT_FOUND": 13,
    "RATE_LIMIT_OR_TIMEOUT": 14,
    "UNKNOWN_ERROR": 20,
}


def map_exit_code(error_code: str | None) -> int:
    if not error_code:
        return EXIT_CODE_MAP["UNKNOWN_ERROR"]
    return EXIT_CODE_MAP.get(error_code, EXIT_CODE_MAP["UNKNOWN_ERROR"])
