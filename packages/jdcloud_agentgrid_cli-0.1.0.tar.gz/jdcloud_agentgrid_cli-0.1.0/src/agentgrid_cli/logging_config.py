import logging
import os
from dataclasses import dataclass
from typing import Any

SENSITIVE_KEYS = {"apikey", "access_key", "secret_key", "token", "authorization"}


def _to_bool(raw: str | None, default: bool = False) -> bool:
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def mask_sensitive(data: Any) -> Any:
    if isinstance(data, dict):
        masked: dict[Any, Any] = {}
        for key, value in data.items():
            key_text = str(key).lower()
            if key_text in SENSITIVE_KEYS:
                masked[key] = "***"
            else:
                masked[key] = mask_sensitive(value)
        return masked
    if isinstance(data, list):
        return [mask_sensitive(item) for item in data]
    if isinstance(data, tuple):
        return tuple(mask_sensitive(item) for item in data)
    return data


class SensitiveDataFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, dict):
            record.msg = mask_sensitive(record.msg)
        return True


@dataclass
class LoggingRuntimeConfig:
    console_enabled: bool
    file_enabled: bool
    level: str
    file_path: str


def setup_cli_logging(force: bool = False) -> LoggingRuntimeConfig:
    console_enabled = _to_bool(os.getenv("AGENTGRID_LOG_CONSOLE"), default=False)
    file_enabled = _to_bool(os.getenv("AGENTGRID_FILE_ENABLED"), default=False)
    level = os.getenv("AGENTGRID_LOG_LEVEL", "INFO").upper()
    file_path = os.getenv("AGENTGRID_LOG_FILE", "agentgrid.log")

    formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s - %(message)s")

    for logger_name in ("agentgrid_cli", "agentgrid"):
        logger = logging.getLogger(logger_name)
        logger.setLevel(level)
        logger.propagate = False

        if force:
            logger.handlers.clear()

        if console_enabled:
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            console_handler.addFilter(SensitiveDataFilter())
            logger.addHandler(console_handler)

        if file_enabled:
            file_handler = logging.FileHandler(file_path, encoding="utf-8")
            file_handler.setFormatter(formatter)
            file_handler.addFilter(SensitiveDataFilter())
            logger.addHandler(file_handler)

    return LoggingRuntimeConfig(
        console_enabled=console_enabled,
        file_enabled=file_enabled,
        level=level,
        file_path=file_path,
    )
