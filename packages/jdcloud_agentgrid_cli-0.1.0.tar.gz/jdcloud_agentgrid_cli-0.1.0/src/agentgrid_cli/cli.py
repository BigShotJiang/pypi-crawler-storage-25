import typer

from .commands import register_root_commands
from .commands.runtime import runtime_app
from .commands.tools import tools_app
from .logging_config import setup_cli_logging

app = typer.Typer(add_completion=False)


@app.callback()
def root() -> None:
    setup_cli_logging(force=True)


register_root_commands(app)
app.add_typer(runtime_app, name="runtime")
app.add_typer(tools_app, name="tools")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
