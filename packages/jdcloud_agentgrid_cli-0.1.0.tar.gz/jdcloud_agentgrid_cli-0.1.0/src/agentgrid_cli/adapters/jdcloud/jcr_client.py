import base64
import logging
import subprocess
from typing import Any

from jdcloud_sdk.services.containerregistry.apis.CreateRegistryRequest import (
    CreateRegistryParameters,
    CreateRegistryRequest,
)
from jdcloud_sdk.services.containerregistry.apis.CreateRepositoryRequest import (
    CreateRepositoryParameters,
    CreateRepositoryRequest,
)
from jdcloud_sdk.services.containerregistry.apis.DescribeRegistryRequest import (
    DescribeRegistryParameters,
    DescribeRegistryRequest,
)
from jdcloud_sdk.services.containerregistry.apis.DescribeRepositoriesRequest import (
    DescribeRepositoriesParameters,
    DescribeRepositoriesRequest,
)
from jdcloud_sdk.services.containerregistry.apis.GetAuthorizationTokenRequest import (
    GetAuthorizationTokenParameters,
    GetAuthorizationTokenRequest,
)

from agentgrid_cli.adapters.jdcloud.sdk_client import (
    JDCloudContainerRegistrySDKClient,
)

logger = logging.getLogger(__name__)


def is_jcr_uri(uri: str) -> bool:
    return uri.startswith("jdcloud-jcr://") or ".jcr.service.jdcloud.com/" in uri


def build_registry_host(registry_name: str, region_id: str) -> str:
    return f"{registry_name}-{region_id}.jcr.service.jdcloud.com"


def build_remote_image_ref(
    registry_name: str, region_id: str, repo: str, tag: str
) -> str:
    host = build_registry_host(registry_name, region_id)
    return f"{host}/{repo}:{tag}"


class JcrClient:
    def __init__(
        self,
        region_id: str,
        sdk_client: JDCloudContainerRegistrySDKClient | None = None,
    ) -> None:
        self.region_id = region_id
        self.sdk_client = sdk_client

    def _send(self, request: Any) -> dict[str, Any]:
        if self.sdk_client is None:
            self.sdk_client = JDCloudContainerRegistrySDKClient()
        return self.sdk_client.send(request)

    def ensure_registry(self, registry_name: str) -> dict[str, str]:
        try:
            return self.describe_registry(registry_name)
        except RuntimeError:
            logger.info("registry %s 不存在，正在创建...", registry_name)
            return self.create_registry(registry_name)

    def describe_registry(self, registry_name: str) -> dict[str, str]:
        params = DescribeRegistryParameters(
            regionId=self.region_id, registryName=registry_name
        )
        result = self._send(DescribeRegistryRequest(parameters=params))
        return {
            "name": str(result.get("name") or ""),
            "registry_uri": str(result.get("registryUri") or ""),
        }

    def create_registry(self, registry_name: str) -> dict[str, str]:
        params = CreateRegistryParameters(
            regionId=self.region_id, registryName=registry_name
        )
        result = self._send(CreateRegistryRequest(parameters=params))
        return {
            "name": str(result.get("name") or registry_name),
            "registry_uri": str(result.get("registryUri") or ""),
        }

    def ensure_repository(
        self, registry_name: str, repository_name: str
    ) -> dict[str, str]:
        existing = self.list_repositories(
            registry_name=registry_name, filter_name=repository_name
        )
        for repo in existing:
            if repo.get("name") == repository_name:
                return repo

        logger.info(
            "repository %s/%s 不存在，正在创建...", registry_name, repository_name
        )
        return self.create_repository(registry_name, repository_name)

    def list_repositories(
        self,
        registry_name: str | None = None,
        filter_name: str | None = None,
    ) -> list[dict[str, str]]:
        params = DescribeRepositoriesParameters(regionId=self.region_id)
        if registry_name:
            params.setRegistryName(registry_name)
        if filter_name:
            params.setFilters(
                [{"name": "name", "operator": "eq", "values": [filter_name]}]
            )

        result = self._send(DescribeRepositoriesRequest(parameters=params))
        items = result.get("repositories") or result.get("data") or []
        normalized: list[dict[str, str]] = []
        for item in items:
            normalized.append(
                {
                    "name": str(item.get("repositoryName") or item.get("name") or ""),
                    "registry_name": str(
                        item.get("registryName") or registry_name or ""
                    ),
                }
            )
        return normalized

    def create_repository(
        self, registry_name: str, repository_name: str
    ) -> dict[str, str]:
        params = CreateRepositoryParameters(
            regionId=self.region_id,
            registryName=registry_name,
            repositoryName=repository_name,
        )
        self._send(CreateRepositoryRequest(parameters=params))
        return {
            "name": repository_name,
            "registry_name": registry_name,
        }

    def get_authorization_token(self, registry_name: str) -> str:
        params = GetAuthorizationTokenParameters(
            regionId=self.region_id, registryName=registry_name
        )
        result = self._send(GetAuthorizationTokenRequest(parameters=params))
        token_b64 = str(result.get("authorizationToken") or "")
        if not token_b64:
            raise RuntimeError("未能获取 JCR authorization token")
        decoded = base64.b64decode(token_b64).decode("utf-8")
        parts = decoded.split(":", 1)
        if len(parts) != 2:
            raise RuntimeError(f"authorization token 格式不正确: {decoded[:10]}...")
        return decoded

    def push_image(
        self,
        local_image: str,
        registry_name: str,
        repo: str,
        tag: str,
    ) -> str:
        if not local_image:
            raise ValueError("local_image is required")
        if not registry_name or not repo or not tag:
            raise ValueError("registry_name/repo/tag are required")

        registry_host = build_registry_host(registry_name, self.region_id)
        remote_ref = f"{registry_host}/{repo}:{tag}"

        auth_token = self.get_authorization_token(registry_name)
        user, password = auth_token.split(":", 1)

        self._docker_login(registry_host, user, password)
        self._docker_tag(local_image, remote_ref)
        self._docker_push(remote_ref)

        return remote_ref

    def _docker_login(self, registry_host: str, username: str, password: str) -> None:
        logger.info("docker login %s", registry_host)
        proc = subprocess.run(
            ["docker", "login", registry_host, "-u", username, "--password-stdin"],
            input=password,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"docker login 失败: {proc.stderr.strip()}")

    def _docker_tag(self, local_image: str, remote_ref: str) -> None:
        logger.info("docker tag %s -> %s", local_image, remote_ref)
        proc = subprocess.run(
            ["docker", "tag", local_image, remote_ref],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"docker tag 失败: {proc.stderr.strip()}")

    def _docker_push(self, remote_ref: str) -> None:
        logger.info("docker push %s", remote_ref)
        proc = subprocess.run(
            ["docker", "push", remote_ref],
            capture_output=True,
            text=True,
            timeout=600,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"docker push 失败: {proc.stderr.strip()}")
