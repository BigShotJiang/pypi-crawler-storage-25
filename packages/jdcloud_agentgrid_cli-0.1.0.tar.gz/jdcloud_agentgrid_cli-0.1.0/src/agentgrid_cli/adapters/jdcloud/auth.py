import configparser
import os
from pathlib import Path

from agentgrid_cli.adapters.jdcloud.models import Credentials


def _pair_or_error(
    access_key: str | None, secret_key: str | None, source: str
) -> Credentials | None:
    if access_key is None and secret_key is None:
        return None
    if not access_key or not secret_key:
        raise ValueError(f"{source} requires both access_key and secret_key")
    return Credentials(access_key=access_key, secret_key=secret_key)


def _load_local_credentials(path: Path) -> Credentials | None:
    if not path.exists():
        return None
    parser = configparser.ConfigParser()
    parser.read(path, encoding="utf-8")
    section = "default"
    if not parser.has_section(section):
        return None
    access_key = parser.get(section, "access_key_id", fallback=None)
    secret_key = parser.get(section, "secret_access_key", fallback=None)
    return _pair_or_error(access_key, secret_key, "local credentials file")


def load_credentials(
    access_key: str | None = None,
    secret_key: str | None = None,
    local_credentials_path: Path | None = None,
) -> Credentials:
    cli_creds = _pair_or_error(access_key, secret_key, "cli args")
    if cli_creds is not None:
        return cli_creds

    env_creds = _pair_or_error(
        os.getenv("JDCLOUD_ACCESS_KEY"),
        os.getenv("JDCLOUD_SECRET_KEY"),
        "environment variables",
    )
    if env_creds is not None:
        return env_creds

    credentials_path = (
        local_credentials_path or Path.home() / ".jdcloud" / "credentials"
    )
    file_creds = _load_local_credentials(credentials_path)
    if file_creds is not None:
        return file_creds

    raise ValueError("jdcloud credentials not found")
