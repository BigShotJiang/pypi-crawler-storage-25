from dataclasses import dataclass


@dataclass
class Credentials:
    access_key: str
    secret_key: str
