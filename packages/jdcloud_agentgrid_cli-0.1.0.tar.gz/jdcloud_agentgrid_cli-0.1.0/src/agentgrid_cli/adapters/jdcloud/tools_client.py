from typing import Any

from jdcloud_sdk.services.agentgrid.apis.CreateCodeInterpreterRequest import (
    CreateCodeInterpreterParameters,
    CreateCodeInterpreterRequest,
)
from jdcloud_sdk.services.agentgrid.apis.CreateCodeInterpreterSessionRequest import (
    CreateCodeInterpreterSessionParameters,
    CreateCodeInterpreterSessionRequest,
)
from jdcloud_sdk.services.agentgrid.apis.DeleteCodeInterpreterRequest import (
    DeleteCodeInterpreterParameters,
    DeleteCodeInterpreterRequest,
)
from jdcloud_sdk.services.agentgrid.apis.DeleteCodeInterpreterSessionRequest import (
    DeleteCodeInterpreterSessionParameters,
    DeleteCodeInterpreterSessionRequest,
)
from jdcloud_sdk.services.agentgrid.apis.DescribeCodeInterpreterRequest import (
    DescribeCodeInterpreterParameters,
    DescribeCodeInterpreterRequest,
)
from jdcloud_sdk.services.agentgrid.apis.DescribeCodeInterpretersRequest import (
    DescribeCodeInterpretersParameters,
    DescribeCodeInterpretersRequest,
)
from jdcloud_sdk.services.agentgrid.apis.DescribeCodeInterpreterSessionRequest import (
    DescribeCodeInterpreterSessionParameters,
    DescribeCodeInterpreterSessionRequest,
)
from jdcloud_sdk.services.agentgrid.apis.DescribeCodeInterpreterSessionsRequest import (
    DescribeCodeInterpreterSessionsParameters,
    DescribeCodeInterpreterSessionsRequest,
)

from agentgrid_cli.adapters.jdcloud.sdk_client import (
    JDCloudAgentGridSDKClient,
    get_default_region_id,
)


def _pick(data: dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in data and data[key] is not None:
            return data[key]
    return default


class ToolsClient:
    def __init__(
        self,
        region_id: str | None = None,
        sdk_client: JDCloudAgentGridSDKClient | None = None,
    ) -> None:
        self.region_id = region_id or get_default_region_id()
        self.sdk_client = sdk_client

    def _send(self, request):
        if self.sdk_client is None:
            self.sdk_client = JDCloudAgentGridSDKClient(region_id=self.region_id)
        return self.sdk_client.send(request)

    def create_tool(self, name: str, description: str | None = None) -> dict[str, str]:
        params = CreateCodeInterpreterParameters(
            regionId=self.region_id,
            name=name,
            networkConfiguration={
                "enablePublicNetwork": True,
                "enableSandbox": True,
            },
        )
        if description:
            params.setDescription(description)
        request = CreateCodeInterpreterRequest(parameters=params)
        result = self._send(request)
        return {
            "tool_id": str(result.get("codeInterpreterId") or ""),
            "name": str(result.get("name") or name),
        }

    def get_tool(self, tool_id: str) -> dict[str, str]:
        params = DescribeCodeInterpreterParameters(
            regionId=self.region_id,
            codeInterpreterId=tool_id,
        )
        request = DescribeCodeInterpreterRequest(parameters=params)
        result = self._send(request)
        return {
            "tool_id": str(result.get("codeInterpreterId") or tool_id),
            "name": str(result.get("name") or ""),
            "state": str(result.get("state") or ""),
        }

    def delete_tool(self, tool_id: str) -> dict[str, str]:
        params = DeleteCodeInterpreterParameters(
            regionId=self.region_id,
            codeInterpreterId=tool_id,
        )
        request = DeleteCodeInterpreterRequest(parameters=params)
        self._send(request)
        return {"tool_id": tool_id, "deleted": "true"}

    def list_tools(self) -> list[dict[str, str]]:
        params = DescribeCodeInterpretersParameters(regionId=self.region_id)
        request = DescribeCodeInterpretersRequest(parameters=params)
        result = self._send(request)
        items = result.get("codeInterpreters") or []
        data: list[dict[str, str]] = []
        for item in items:
            data.append(
                {
                    "tool_id": str(item.get("codeInterpreterId") or ""),
                    "name": str(item.get("name") or ""),
                    "state": str(item.get("state") or ""),
                }
            )
        return data

    def create_session(
        self,
        tool_id: str,
        name: str | None = None,
        max_life_time: int | None = None,
    ) -> dict[str, str]:
        params = CreateCodeInterpreterSessionParameters(
            regionId=self.region_id,
            codeInterpreterId=tool_id,
        )
        if name:
            params.setName(name)
        if max_life_time is not None:
            params.setMaxLifeTime(max_life_time)

        request = CreateCodeInterpreterSessionRequest(parameters=params)
        result = self._send(request)
        return {
            "tool_id": tool_id,
            "session_id": str(result.get("sessionId") or ""),
        }

    def get_session(
        self, session_id: str, tool_id: str | None = None
    ) -> dict[str, str]:
        if not tool_id:
            raise ValueError("tool_id is required for session operations")

        params = DescribeCodeInterpreterSessionParameters(
            regionId=self.region_id,
            codeInterpreterId=tool_id,
            sessionId=session_id,
        )
        request = DescribeCodeInterpreterSessionRequest(parameters=params)
        result = self._send(request)
        return {
            "tool_id": str(result.get("codeInterpreterId") or tool_id),
            "session_id": str(result.get("sessionId") or session_id),
            "status": str(result.get("state") or ""),
        }

    def delete_session(
        self, session_id: str, tool_id: str | None = None
    ) -> dict[str, str]:
        if not tool_id:
            raise ValueError("tool_id is required for session operations")

        params = DeleteCodeInterpreterSessionParameters(
            regionId=self.region_id,
            codeInterpreterId=tool_id,
            sessionId=session_id,
        )
        request = DeleteCodeInterpreterSessionRequest(parameters=params)
        self._send(request)
        return {"session_id": session_id, "deleted": "true"}

    def list_sessions(self, tool_id: str | None = None) -> list[dict[str, str]]:
        if not tool_id:
            raise ValueError("tool_id is required for session operations")

        params = DescribeCodeInterpreterSessionsParameters(
            regionId=self.region_id,
            codeInterpreterId=tool_id,
        )

        request = DescribeCodeInterpreterSessionsRequest(parameters=params)
        result = self._send(request)
        sessions = result.get("codeInterpreterSessions") or []
        data: list[dict[str, str]] = []
        for item in sessions:
            data.append(
                {
                    "tool_id": tool_id,
                    "session_id": str(item.get("sessionId") or ""),
                    "status": str(item.get("state") or ""),
                }
            )
        return data

    def get_session_logs(
        self, session_id: str, limit: int | None = None
    ) -> dict[str, object]:
        _ = session_id
        _ = limit
        raise NotImplementedError("tools session logs 暂不支持")

    def set_session_ttl(self, session_id: str, ttl_seconds: int) -> dict[str, object]:
        _ = session_id
        _ = ttl_seconds
        raise NotImplementedError("tools session set-ttl 暂不支持")
