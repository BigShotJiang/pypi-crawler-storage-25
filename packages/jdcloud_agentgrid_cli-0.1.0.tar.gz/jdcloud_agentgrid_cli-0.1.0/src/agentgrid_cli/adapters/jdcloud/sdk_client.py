import os
from typing import Any

from jdcloud_sdk.core.config import Config
from jdcloud_sdk.core.credential import Credential
from jdcloud_sdk.core.logger import Logger, ERROR
from jdcloud_sdk.services.agentgrid.client.AgentgridClient import AgentgridClient
from jdcloud_sdk.services.containerregistry.client.ContainerregistryClient import (
    ContainerregistryClient,
)

from agentgrid_cli.adapters.jdcloud.auth import load_credentials

_silent_logger = Logger(ERROR)


def _build_runtime_error_message(response: Any) -> str:
    message = f"{response.error.code}: {response.error.message}"
    request_id = getattr(response, "request_id", None) or getattr(
        response, "requestId", None
    )
    if request_id:
        return f"{message} (requestId={request_id})"
    return message


def get_default_region_id() -> str:
    return os.getenv("JDCLOUD_REGION", "cn-north-1")


class JDCloudAgentGridSDKClient:
    def __init__(
        self,
        region_id: str | None = None,
        access_key: str | None = None,
        secret_key: str | None = None,
        endpoint: str | None = None,
        timeout: int = 10,
    ) -> None:
        _ = region_id
        creds = load_credentials(access_key=access_key, secret_key=secret_key)
        credential = Credential(
            access_key=creds.access_key, secret_key=creds.secret_key
        )
        if endpoint:
            config = Config(endpoint=endpoint, timeout=timeout)
        else:
            config = Config(timeout=timeout)

        self._client = AgentgridClient(
            credential=credential, config=config, logger=_silent_logger
        )

    def send(self, request: Any) -> dict[str, Any]:
        response = self._client.send(request)
        if response.error is not None:
            raise RuntimeError(_build_runtime_error_message(response))

        result = response.result
        if result is None:
            return {}
        if isinstance(result, dict):
            return result
        return {"data": result}


class JDCloudContainerRegistrySDKClient:
    def __init__(
        self,
        access_key: str | None = None,
        secret_key: str | None = None,
        endpoint: str | None = None,
        timeout: int = 10,
    ) -> None:
        creds = load_credentials(access_key=access_key, secret_key=secret_key)
        credential = Credential(
            access_key=creds.access_key, secret_key=creds.secret_key
        )
        if endpoint:
            config = Config(endpoint=endpoint, timeout=timeout)
        else:
            config = Config(timeout=timeout)

        self._client = ContainerregistryClient(
            credential=credential, config=config, logger=_silent_logger
        )

    def send(self, request: Any) -> dict[str, Any]:
        response = self._client.send(request)
        if response.error is not None:
            raise RuntimeError(_build_runtime_error_message(response))

        result = response.result
        if result is None:
            return {}
        if isinstance(result, dict):
            return result
        return {"data": result}
