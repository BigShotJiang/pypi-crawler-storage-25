from dataclasses import dataclass
from contextlib import AbstractContextManager
import logging
import time
from typing import Any

from jdcloud_sdk.services.agentgrid.apis.CreateRuntimeEndpointRequest import (
    CreateRuntimeEndpointParameters,
    CreateRuntimeEndpointRequest,
)
from jdcloud_sdk.services.agentgrid.apis.CreateRuntimeRequest import (
    CreateRuntimeParameters,
    CreateRuntimeRequest,
)
from jdcloud_sdk.services.agentgrid.apis.DeleteRuntimeRequest import (
    DeleteRuntimeParameters,
    DeleteRuntimeRequest,
)
from jdcloud_sdk.services.agentgrid.apis.DescribeRuntimeEndpointRequest import (
    DescribeRuntimeEndpointParameters,
    DescribeRuntimeEndpointRequest,
)
from jdcloud_sdk.services.agentgrid.apis.DescribeRuntimeRequest import (
    DescribeRuntimeParameters,
    DescribeRuntimeRequest,
)
from jdcloud_sdk.services.agentgrid.apis.DescribeRuntimesRequest import (
    DescribeRuntimesParameters,
    DescribeRuntimesRequest,
)
from jdcloud_sdk.services.agentgrid.apis.DescribeRuntimeVersionsRequest import (
    DescribeRuntimeVersionsParameters,
    DescribeRuntimeVersionsRequest,
)
from jdcloud_sdk.services.agentgrid.apis.ModifyRuntimeVersionRequest import (
    ModifyRuntimeVersionParameters,
    ModifyRuntimeVersionRequest,
)
from jdcloud_sdk.services.agentgrid.apis.UpdateRuntimeAttributesRequest import (
    UpdateRuntimeAttributesParameters,
    UpdateRuntimeAttributesRequest,
)
from jdcloud_sdk.services.agentgrid.apis.UpdateRuntimeRequest import (
    UpdateRuntimeParameters,
    UpdateRuntimeRequest,
)

from agentgrid_cli.adapters.jdcloud.sdk_client import (
    JDCloudAgentGridSDKClient,
    get_default_region_id,
)

logger = logging.getLogger(__name__)

RUNTIME_READY_STATES = {"running", "active"}
RUNTIME_WAITING_STATES = {"pending", "creating"}
RUNTIME_ERROR_STATES = {"updating", "deleting", "deleted", "failed"}


def _load_runtime_session_factory():
    try:
        from agentgrid import runtime_session

        return runtime_session
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(
            "无法导入 jdcloud-agentgrid runtime_session，请安装 jdcloud-agentgrid>=0.1.5 并确认依赖版本兼容"
        ) from exc


@dataclass
class RuntimeDeployResult:
    runtime_id: str
    endpoint: str
    version: str


def _pick(data: dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in data and data[key] is not None:
            return data[key]
    return default


class RuntimeClient:
    def __init__(
        self,
        region_id: str | None = None,
        sdk_client: JDCloudAgentGridSDKClient | None = None,
    ) -> None:
        self.region_id = region_id or get_default_region_id()
        self.sdk_client = sdk_client

    def _send(self, request):
        if self.sdk_client is None:
            self.sdk_client = JDCloudAgentGridSDKClient(region_id=self.region_id)
        return self.sdk_client.send(request)

    def deploy_image(
        self,
        runtime_name: str,
        role_name: str,
        image_uri: str,
        envs: dict[str, str] | None = None,
    ) -> RuntimeDeployResult:
        _ = role_name
        created = self.create_runtime(
            name=runtime_name,
            artifact_type="DockerImage",
            artifact_url=image_uri,
            envs=envs,
        )
        runtime_id = created["runtime_id"]
        endpoint = self._ensure_runtime_endpoint(runtime_id)
        version = str(created.get("version") or created.get("current_version") or "")
        return RuntimeDeployResult(
            runtime_id=runtime_id, endpoint=endpoint, version=version
        )

    def get_runtime_status(self, runtime_id: str) -> str:
        data = self.get_runtime(runtime_id)
        return str(data.get("state", "unknown"))

    def wait_runtime_ready(
        self,
        runtime_id: str,
        timeout: float = 300,
        interval: float = 10,
    ) -> str:
        start = time.monotonic()
        while True:
            status = self.get_runtime_status(runtime_id)
            normalized_status = status.strip().lower()
            logger.info("runtime %s 状态: %s", runtime_id, status)
            if normalized_status in RUNTIME_READY_STATES:
                return status
            if normalized_status in RUNTIME_ERROR_STATES:
                raise RuntimeError(
                    f"runtime {runtime_id} 状态进入 {status}，无法继续等待就绪"
                )
            elapsed = time.monotonic() - start
            if elapsed >= timeout:
                raise TimeoutError(
                    f"runtime {runtime_id} 在 {timeout}s 内未就绪，当前状态: {status}"
                )
            if normalized_status in RUNTIME_WAITING_STATES:
                time.sleep(interval)
                continue
            time.sleep(interval)

    def invoke_runtime(
        self,
        runtime_id: str,
        payload: str,
        api_key: str,
        session: Any | None = None,
    ) -> tuple[bool, Any]:
        if session is not None:
            return True, session.invoke(payload, api_key=api_key)

        with self.open_runtime_session(runtime_id) as runtime_session:
            return True, runtime_session.invoke(payload, api_key=api_key)

    def open_runtime_session(self, runtime_id: str) -> AbstractContextManager[Any]:
        runtime_session = _load_runtime_session_factory()
        return runtime_session(self.region_id, runtime_id)

    def destroy_runtime(self, runtime_id: str) -> tuple[bool, str]:
        deleted = self.delete_runtime(runtime_id)
        return True, str(deleted)

    def create_runtime(
        self,
        name: str,
        # role_name: str,
        artifact_type: str,
        artifact_url: str,
        description: str | None = None,
        envs: dict[str, str] | None = None,
        tags: dict[str, str] | None = None,
    ) -> dict[str, str]:
        # _ = role_name
        _ = tags
        if artifact_type != "DockerImage":
            raise ValueError("only DockerImage artifact_type is supported")

        params = CreateRuntimeParameters(
            regionId=self.region_id,
            name=name,
            artifactConfiguration={"image": {"imageUrl": artifact_url}},
            authorizerConfiguration={"type": "API_KEY"},
            networkConfiguration={
                "enablePublicNetwork": True,
                "enableSandbox": True,
            },
        )
        if description:
            params.setDescription(description)
        if envs:
            params.setEnvs(
                [{"key": key, "value": value} for key, value in envs.items()]
            )

        request = CreateRuntimeRequest(parameters=params)
        result = self._send(request)
        runtime_id = str(result.get("runtimeId") or "")
        return {
            "runtime_id": runtime_id,
            "name": str(result.get("name") or name),
            "version": str(result.get("version") or result.get("currentVersion") or ""),
            "state": str(result.get("state") or ""),
        }

    def get_runtime(self, runtime_id: str) -> dict[str, str]:
        params = DescribeRuntimeParameters(
            regionId=self.region_id, runtimeId=runtime_id
        )
        request = DescribeRuntimeRequest(parameters=params)
        result = self._send(request)
        runtime_view = result.get("runtimeView") or {}
        return {
            "runtime_id": str(
                _pick(runtime_view, "runtimeId", default=None) or runtime_id
            ),
            "name": str(_pick(runtime_view, "name", default=None) or ""),
            "state": str(_pick(runtime_view, "state", default=None) or ""),
            "api_key": str(_pick(runtime_view, "apiKey", default=None) or ""),
            "current_version": str(
                _pick(runtime_view, "currentVersion", "queriedVersion", default=None)
                or ""
            ),
            "endpoint": str(
                _pick(
                    runtime_view,
                    "endpoint",
                    "publicEndpoint",
                    "internalEndpoint",
                    default=None,
                )
                or ""
            ),
        }

    def update_runtime(self, runtime_id: str, **updates: object) -> dict[str, object]:
        description = updates.get("description")
        artifact_url = updates.get("artifact_url")

        if artifact_url is None and description is not None:
            attr_params = UpdateRuntimeAttributesParameters(
                regionId=self.region_id,
                runtimeId=runtime_id,
            )
            attr_params.setDescription(str(description))
            attr_request = UpdateRuntimeAttributesRequest(parameters=attr_params)
            result = self._send(attr_request)
            return {"runtime_id": runtime_id, "updated": result}

        params = UpdateRuntimeParameters(
            regionId=self.region_id,
            runtimeId=runtime_id,
            authorizerConfiguration={"type": "API_KEY"},
            artifactConfiguration={"image": {"imageUrl": str(artifact_url or "")}},
            networkConfiguration={
                "enablePublicNetwork": True,
                "enableSandbox": True,
            },
        )
        if isinstance(description, str):
            params.setDescription(description)

        request = UpdateRuntimeRequest(parameters=params)
        result = self._send(request)
        return {"runtime_id": runtime_id, "updated": result}

    def delete_runtime(self, runtime_id: str) -> dict[str, str]:
        params = DeleteRuntimeParameters(regionId=self.region_id, runtimeId=runtime_id)
        request = DeleteRuntimeRequest(parameters=params)
        self._send(request)
        return {"runtime_id": runtime_id, "deleted": "true"}

    def list_runtimes(
        self, limit: int | None = None, next_token: str | None = None
    ) -> list[dict[str, str]]:
        params = DescribeRuntimesParameters(regionId=self.region_id)
        if limit is not None:
            params.setPageSize(limit)
        if next_token:
            try:
                page = int(next_token)
            except ValueError:
                page = None
            if page is not None:
                params.setPageNumber(page)

        request = DescribeRuntimesRequest(parameters=params)
        result = self._send(request)
        runtimes = result.get("runtimes") or []
        normalized: list[dict[str, str]] = []
        for item in runtimes:
            normalized.append(
                {
                    "runtime_id": str(item.get("runtimeId") or ""),
                    "name": str(item.get("name") or ""),
                    "state": str(item.get("state") or ""),
                }
            )
        return normalized

    def release_runtime(self, runtime_id: str, version: str) -> dict[str, str]:
        params = ModifyRuntimeVersionParameters(
            regionId=self.region_id,
            runtimeId=runtime_id,
            version=version,
        )
        request = ModifyRuntimeVersionRequest(parameters=params)
        self._send(request)
        return {"runtime_id": runtime_id, "released": "true", "version": version}

    def get_runtime_version(
        self, runtime_id: str, version: str | None = None
    ) -> dict[str, str]:
        params = DescribeRuntimeParameters(
            regionId=self.region_id, runtimeId=runtime_id
        )
        if version:
            params.setVersion(version)

        request = DescribeRuntimeRequest(parameters=params)
        result = self._send(request)
        return {
            "runtime_id": str(result.get("runtimeId") or runtime_id),
            "version": str(
                result.get("queriedVersion") or result.get("currentVersion") or ""
            ),
            "state": str(result.get("state") or ""),
        }

    def list_runtime_versions(self, runtime_id: str) -> list[dict[str, str]]:
        params = DescribeRuntimeVersionsParameters(
            regionId=self.region_id,
            runtimeId=runtime_id,
        )
        request = DescribeRuntimeVersionsRequest(parameters=params)
        result = self._send(request)
        versions = result.get("runtimeVersions") or []
        normalized: list[dict[str, str]] = []
        for item in versions:
            normalized.append(
                {
                    "runtime_id": runtime_id,
                    "version": str(item.get("version") or ""),
                    "state": str(item.get("state") or ""),
                }
            )
        return normalized

    def _ensure_runtime_endpoint(self, runtime_id: str) -> str:
        create_params = CreateRuntimeEndpointParameters(
            regionId=self.region_id,
            runtimeId=runtime_id,
        )
        self._send(CreateRuntimeEndpointRequest(parameters=create_params))

        describe_params = DescribeRuntimeEndpointParameters(
            regionId=self.region_id,
            runtimeId=runtime_id,
        )
        result = self._send(DescribeRuntimeEndpointRequest(parameters=describe_params))
        return str(
            result.get("publicEndpoint")
            or result.get("endpoint")
            or result.get("internalEndpoint")
            or ""
        )
