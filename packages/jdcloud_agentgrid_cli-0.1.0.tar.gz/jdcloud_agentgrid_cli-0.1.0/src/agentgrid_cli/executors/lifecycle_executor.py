import logging
from pathlib import Path
from typing import Callable

from agentgrid_cli.adapters.jdcloud.runtime_client import RuntimeClient
from agentgrid_cli.config import ConfigManager
from agentgrid_cli.docker import runner
from agentgrid_cli.executors.build_executor import BuildExecutor
from agentgrid_cli.executors.deploy_executor import DeployExecutor
from agentgrid_cli.executors.result import ExecutionResult

logger = logging.getLogger(__name__)


def run_build(
    config_path: Path,
    image_uri: str | None = None,
    progress: Callable[[str], None] | None = None,
) -> ExecutionResult:
    return BuildExecutor(config_path=config_path).execute(
        image_uri=image_uri,
        progress=progress,
    )


def run_deploy(
    config_path: Path,
    progress: Callable[[str], None] | None = None,
) -> ExecutionResult:
    return DeployExecutor(config_path=config_path).execute(progress=progress)


class LifecycleExecutor:
    def __init__(self, config_path: Path | str = Path("agentgrid.yaml")) -> None:
        self.config_path = Path(config_path)
        self.config_manager = ConfigManager(self.config_path)

    def launch(
        self,
        image_uri: str | None = None,
        progress: Callable[[str], None] | None = None,
    ) -> ExecutionResult:
        def emit(message: str) -> None:
            if progress is not None:
                progress(message)

        emit("[launch] 步骤 1/2: 开始构建 (build)")
        logger.info("[launch] 步骤 1/2: 开始构建 (build)")
        build_result = run_build(self.config_path, image_uri=image_uri, progress=emit)
        if not build_result.success:
            message = f"[launch] 构建失败: {build_result.message}"
            emit(message)
            logger.error(message)
            return build_result
        emit("[launch] 步骤 1/2: 构建完成 ✓")
        logger.info("[launch] 步骤 1/2: 构建完成 ✓")

        emit("[launch] 步骤 2/2: 开始部署 (deploy)")
        logger.info("[launch] 步骤 2/2: 开始部署 (deploy)")
        deploy_result = run_deploy(self.config_path, progress=emit)
        if not deploy_result.success:
            message = f"[launch] 部署失败: {deploy_result.message}"
            emit(message)
            logger.error(message)
        else:
            emit("[launch] 步骤 2/2: 部署完成 ✓")
            logger.info("[launch] 步骤 2/2: 部署完成 ✓")
        return deploy_result

    def destroy(self) -> ExecutionResult:
        data = self.config_manager.read_raw()
        launch_type = data.get("common", {}).get("launch_type", "local")
        if launch_type == "cloud":
            cloud_cfg = data.get("launch_types", {}).get("cloud", {})
            region_id = str(cloud_cfg.get("region", "cn-north-1"))
            state = data.setdefault("state", {})
            runtime_id = str(state.get("runtime_id", ""))
            if not runtime_id:
                return ExecutionResult(
                    success=False,
                    message="state.runtime_id is empty, run deploy first",
                    error_code="CONFIG_INVALID",
                )

            ok, output = RuntimeClient(region_id=region_id).destroy_runtime(runtime_id)
            if not ok:
                return ExecutionResult(
                    success=False, message=output, error_code="DESTROY_FAILED"
                )

            state["runtime_id"] = ""
            state["endpoint"] = ""
            self.config_manager.write_raw_atomic(data)
            return ExecutionResult(success=True, message=output)

        if launch_type != "local":
            return ExecutionResult(
                success=False, message=f"unsupported launch_type: {launch_type}"
            )

        state = data.setdefault("state", {})
        container_name = str(state.get("runtime_id", ""))
        if not container_name:
            agent_name = str(data.get("common", {}).get("agent_name", "agent"))
            container_name = f"agentgrid-{agent_name}"

        ok, output = runner.destroy_local_container(container_name)
        if not ok:
            return ExecutionResult(
                success=False, message=output, error_code="DESTROY_FAILED"
            )

        state["runtime_id"] = ""
        state["endpoint"] = ""
        self.config_manager.write_raw_atomic(data)
        return ExecutionResult(
            success=True, message=f"destroy success: {container_name}"
        )
