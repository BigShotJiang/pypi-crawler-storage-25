import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from agentgrid_cli.config import ConfigManager
from agentgrid_cli.docker import builder
from agentgrid_cli.executors.result import ExecutionResult
from agentgrid_cli.strategies.cloud_strategy import CloudStrategy

logger = logging.getLogger(__name__)


class BuildExecutor:
    def __init__(self, config_path: Path | str = Path("agentgrid.yaml")) -> None:
        self.config_manager = ConfigManager(config_path)

    def execute(
        self,
        image_uri: str | None = None,
        dependency_mode: str | None = None,
        progress: Callable[[str], None] | None = None,
    ) -> ExecutionResult:
        def emit(message: str) -> None:
            if progress is not None:
                progress(message)

        emit("[build] 读取配置文件")
        logger.info("[build] 读取配置文件")
        data = self.config_manager.read_raw()
        launch_type = str(data.get("common", {}).get("launch_type", "local"))
        emit(f"[build] launch_type={launch_type}")
        logger.info("[build] launch_type=%s", launch_type)

        if dependency_mode is not None:
            data.setdefault("common", {})["dependency_mode"] = dependency_mode

        project_dir = self.config_manager.path.parent
        emit(f"[build] 确保 Dockerfile 存在: {project_dir}")
        logger.info("[build] 确保 Dockerfile 存在: %s", project_dir)
        builder.ensure_dockerfile(project_dir, data)

        if launch_type == "cloud":
            emit(f"[build] 执行云端构建, image_uri={image_uri}")
            logger.info("[build] 执行云端构建, image_uri=%s", image_uri)
            cloud_result = CloudStrategy().build(data=data, image_uri=image_uri)
            if not cloud_result.success:
                emit(f"[build] 云端构建失败: {cloud_result.message}")
                logger.error("[build] 云端构建失败: %s", cloud_result.message)
                return cloud_result

            state = data.setdefault("state", {})
            state["last_image_uri"] = str(
                (cloud_result.data or {}).get("image_uri", "")
            )
            state["last_build_at"] = datetime.now(timezone.utc).isoformat()
            self.config_manager.write_raw_atomic(data)
            emit(f"[build] 云端构建完成: {state['last_image_uri']}")
            logger.info("[build] 云端构建完成: %s", state["last_image_uri"])
            return cloud_result

        if launch_type != "local":
            return ExecutionResult(
                success=False,
                message=f"unsupported launch_type: {launch_type}",
                error_code="CONFIG_INVALID",
            )

        common = data.get("common", {})
        local_cfg = data.get("launch_types", {}).get("local", {})

        if image_uri is None:
            agent_name = str(common.get("agent_name", "agentgrid-agent"))
            image_tag = str(local_cfg.get("image_tag", "latest"))
            image_uri = f"{agent_name}:{image_tag}"

        emit(f"[build] 构建本地镜像: {image_uri}")
        logger.info("[build] 构建本地镜像: %s", image_uri)
        ok, output = builder.build_local_image(image_uri)
        if not ok:
            emit(f"[build] 本地镜像构建失败: {output}")
            logger.error("[build] 本地镜像构建失败: %s", output)
            return ExecutionResult(
                success=False, message=output, error_code="BUILD_FAILED"
            )

        state = data.setdefault("state", {})
        state["last_image_uri"] = image_uri
        state["last_build_at"] = datetime.now(timezone.utc).isoformat()
        self.config_manager.write_raw_atomic(data)
        emit(f"[build] 本地镜像构建完成: {image_uri}")
        logger.info("[build] 本地镜像构建完成: %s", image_uri)
        return ExecutionResult(success=True, message=f"build success: {image_uri}")
