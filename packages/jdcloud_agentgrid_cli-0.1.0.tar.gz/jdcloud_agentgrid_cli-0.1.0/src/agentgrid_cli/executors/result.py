from dataclasses import dataclass
from typing import Any


@dataclass
class ExecutionResult:
    success: bool
    message: str = ""
    error_code: str = ""
    data: dict[str, Any] | None = None
