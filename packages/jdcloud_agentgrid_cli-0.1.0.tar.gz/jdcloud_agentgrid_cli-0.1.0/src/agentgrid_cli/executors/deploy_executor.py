import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from agentgrid_cli.adapters.jdcloud.runtime_client import RuntimeClient
from agentgrid_cli.config import ConfigManager
from agentgrid_cli.executors.result import ExecutionResult
from agentgrid_cli.docker import runner

logger = logging.getLogger(__name__)


class DeployExecutor:
    def __init__(self, config_path: Path | str = Path("agentgrid.yaml")) -> None:
        self.config_manager = ConfigManager(config_path)

    def execute(self, progress: Callable[[str], None] | None = None) -> ExecutionResult:
        def emit(message: str) -> None:
            if progress is not None:
                progress(message)

        emit("[deploy] 读取配置文件")
        logger.info("[deploy] 读取配置文件")
        data = self.config_manager.read_raw()
        launch_type = data.get("common", {}).get("launch_type", "local")
        emit(f"[deploy] launch_type={launch_type}")
        logger.info("[deploy] launch_type=%s", launch_type)
        if launch_type == "cloud":
            return self._deploy_cloud(data, progress=progress)
        if launch_type != "local":
            return ExecutionResult(
                success=False, message=f"unsupported launch_type: {launch_type}"
            )

        return self._deploy_local(data, progress=progress)

    def _deploy_local(
        self,
        data: dict,
        progress: Callable[[str], None] | None = None,
    ) -> ExecutionResult:
        def emit(message: str) -> None:
            if progress is not None:
                progress(message)

        emit("[deploy:local] 开始本地部署")
        logger.info("[deploy:local] 开始本地部署")
        state = data.setdefault("state", {})
        image_uri = str(state.get("last_image_uri", ""))
        if not image_uri:
            return ExecutionResult(
                success=False,
                message="state.last_image_uri is empty, run build first",
                error_code="CONFIG_INVALID",
            )

        agent_name = str(data.get("common", {}).get("agent_name", "agent"))
        container_name = f"agentgrid-{agent_name}"
        local_cfg = data.get("launch_types", {}).get("local", {})
        invoke_port = int(local_cfg.get("invoke_port", 8000))

        emit(
            f"[deploy:local] 启动容器 {container_name}, 镜像: {image_uri}, 端口: {invoke_port}"
        )
        logger.info(
            "[deploy:local] 启动容器 %s, 镜像: %s, 端口: %d",
            container_name,
            image_uri,
            invoke_port,
        )
        ok, output = runner.run_local_container(image_uri, container_name, invoke_port)
        if not ok:
            emit(f"[deploy:local] 容器启动失败: {output}")
            logger.error("[deploy:local] 容器启动失败: %s", output)
            return ExecutionResult(
                success=False, message=output, error_code="DEPLOY_FAILED"
            )

        state["runtime_id"] = container_name
        state["endpoint"] = f"http://127.0.0.1:{invoke_port}"
        state["last_deploy_at"] = datetime.now(timezone.utc).isoformat()
        self.config_manager.write_raw_atomic(data)
        emit(f"[deploy:local] 本地部署完成, endpoint: {state['endpoint']}")
        logger.info("[deploy:local] 本地部署完成, endpoint: %s", state["endpoint"])
        return ExecutionResult(
            success=True, message=f"deploy success: {container_name}"
        )

    def _deploy_cloud(
        self,
        data: dict,
        progress: Callable[[str], None] | None = None,
    ) -> ExecutionResult:
        def emit(message: str) -> None:
            if progress is not None:
                progress(message)

        state = data.setdefault("state", {})
        image_uri = str(state.get("last_image_uri", ""))
        if not image_uri:
            return ExecutionResult(
                success=False,
                message="state.last_image_uri is empty, run build first",
                error_code="CONFIG_INVALID",
            )

        launch_types = data.setdefault("launch_types", {})
        cloud_cfg = launch_types.setdefault("cloud", {})
        region_id = str(cloud_cfg.get("region", "cn-north-1"))
        runtime_name = str(cloud_cfg.get("runtime_name", "Auto"))
        # role_name = str(cloud_cfg.get("runtime_role_name", "Auto"))
        envs = cloud_cfg.get("runtime_envs", {})

        client = RuntimeClient(region_id=region_id)

        emit(f"创建 runtime '{runtime_name}'，镜像: {image_uri}")
        logger.info("创建 runtime '%s'，镜像: %s", runtime_name, image_uri)
        created = client.create_runtime(
            name=runtime_name,
            # role_name=role_name,
            artifact_type="DockerImage",
            artifact_url=image_uri,
            envs=envs,
        )
        runtime_id = created["runtime_id"]

        emit(f"等待 runtime {runtime_id} 就绪...")
        logger.info("等待 runtime %s 就绪...", runtime_id)
        client.wait_runtime_ready(runtime_id)

        emit("获取 runtime 信息...")
        logger.info("获取 runtime %s 详情...", runtime_id)
        runtime_detail = client.get_runtime(runtime_id)
        runtime_api_key = str(runtime_detail.get("api_key") or "")
        if runtime_api_key:
            cloud_cfg["runtime_apikey_name"] = runtime_api_key

        emit("获取 runtime endpoint...")
        logger.info("获取 runtime endpoint...")
        endpoint = client._ensure_runtime_endpoint(runtime_id)

        version = str(created.get("version") or "")

        state["runtime_id"] = runtime_id
        state["endpoint"] = endpoint
        state["last_deploy_version"] = version
        state["last_deploy_at"] = datetime.now(timezone.utc).isoformat()
        self.config_manager.write_raw_atomic(data)
        return ExecutionResult(success=True, message=f"deploy success: {runtime_id}")
