import os
from pathlib import Path
from typing import Any

from agentgrid_cli.adapters.jdcloud.runtime_client import RuntimeClient
from agentgrid_cli.config import ConfigManager
from agentgrid_cli.docker import runner
from agentgrid_cli.executors.result import ExecutionResult


class InvokeExecutor:
    def __init__(self, config_path: Path | str = Path("agentgrid.yaml")) -> None:
        self.config_manager = ConfigManager(config_path)

    def resolve_context(self, api_key: str | None = None) -> ExecutionResult:
        data = self.config_manager.read_raw()
        launch_type = data.get("common", {}).get("launch_type", "local")

        if launch_type == "cloud":
            cloud_cfg = data.get("launch_types", {}).get("cloud", {})
            region_id = str(cloud_cfg.get("region", "cn-north-1"))
            runtime_id = str(data.get("state", {}).get("runtime_id", ""))
            if not runtime_id:
                return ExecutionResult(
                    success=False,
                    message="state.runtime_id is empty, run deploy first",
                    error_code="CONFIG_INVALID",
                )
            resolved_api_key = self._resolve_api_key(api_key, cloud_cfg)
            if not resolved_api_key:
                return ExecutionResult(
                    success=False,
                    message="runtime api key is empty, set --api-key or AGENTGRID_RUNTIME_API_KEY or launch_types.cloud.runtime_apikey_name",
                    error_code="CONFIG_INVALID",
                )
            return ExecutionResult(
                success=True,
                data={
                    "launch_type": "cloud",
                    "region_id": region_id,
                    "runtime_id": runtime_id,
                    "api_key": resolved_api_key,
                },
            )

        if launch_type != "local":
            return ExecutionResult(
                success=False, message=f"unsupported launch_type: {launch_type}"
            )

        endpoint = str(data.get("state", {}).get("endpoint", ""))
        if not endpoint:
            return ExecutionResult(
                success=False,
                message="state.endpoint is empty, run deploy first",
                error_code="CONFIG_INVALID",
            )

        return ExecutionResult(
            success=True,
            data={
                "launch_type": "local",
                "endpoint": endpoint,
            },
        )

    def execute(
        self,
        payload: str,
        *,
        api_key: str | None = None,
        session: Any | None = None,
        context: dict[str, Any] | None = None,
    ) -> ExecutionResult:
        if context is None:
            resolved = self.resolve_context(api_key=api_key)
            if not resolved.success:
                return resolved
            context = resolved.data or {}

        launch_type = str(context.get("launch_type", "local"))
        if launch_type == "cloud":
            region_id = str(context.get("region_id", "cn-north-1"))
            runtime_id = str(context.get("runtime_id", ""))
            resolved_api_key = str(context.get("api_key") or "")
            try:
                ok, output = RuntimeClient(region_id=region_id).invoke_runtime(
                    runtime_id=runtime_id,
                    payload=payload,
                    api_key=resolved_api_key,
                    session=session,
                )
            except Exception as exc:  # noqa: BLE001
                return ExecutionResult(
                    success=False,
                    message=str(exc),
                    error_code="INVOKE_FAILED",
                )
            if not ok:
                return ExecutionResult(
                    success=False, message=str(output), error_code="INVOKE_FAILED"
                )
            return ExecutionResult(success=True, data={"output": output})

        endpoint = str(context.get("endpoint", ""))

        ok, output = runner.invoke_local_endpoint(endpoint, payload)
        if not ok:
            return ExecutionResult(
                success=False, message=output, error_code="INVOKE_FAILED"
            )
        return ExecutionResult(success=True, message=output, data={"output": output})

    @staticmethod
    def _resolve_api_key(api_key: str | None, cloud_cfg: dict[str, Any]) -> str:
        if api_key:
            return api_key
        from_env = os.getenv("AGENTGRID_RUNTIME_API_KEY", "")
        if from_env:
            return from_env
        return str(cloud_cfg.get("runtime_apikey_name") or "")
