from pathlib import Path

from agentgrid_cli.adapters.jdcloud.runtime_client import RuntimeClient
from agentgrid_cli.config import ConfigManager
from agentgrid_cli.docker import runner
from agentgrid_cli.executors.result import ExecutionResult


class StatusExecutor:
    def __init__(self, config_path: Path | str = Path("agentgrid.yaml")) -> None:
        self.config_manager = ConfigManager(config_path)

    def execute(self) -> ExecutionResult:
        data = self.config_manager.read_raw()
        launch_type = data.get("common", {}).get("launch_type", "local")
        if launch_type == "cloud":
            cloud_cfg = data.get("launch_types", {}).get("cloud", {})
            region_id = str(cloud_cfg.get("region", "cn-north-1"))
            runtime_id = str(data.get("state", {}).get("runtime_id", ""))
            if not runtime_id:
                return ExecutionResult(
                    success=False,
                    message="state.runtime_id is empty, run deploy first",
                    error_code="CONFIG_INVALID",
                )
            status = RuntimeClient(region_id=region_id).get_runtime_status(runtime_id)
            return ExecutionResult(success=True, message=status)

        if launch_type != "local":
            return ExecutionResult(
                success=False, message=f"unsupported launch_type: {launch_type}"
            )

        state = data.get("state", {})
        container_name = str(state.get("runtime_id", ""))
        if not container_name:
            agent_name = str(data.get("common", {}).get("agent_name", "agent"))
            container_name = f"agentgrid-{agent_name}"

        status = runner.get_local_status(container_name)
        return ExecutionResult(success=True, message=status)
