import os
import time
from pathlib import Path
from typing import Any

import yaml

from .models import AgentGridConfig


class ConfigManager:
    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)

    def default_raw(self) -> dict[str, Any]:
        return AgentGridConfig().to_dict()

    def read_raw(self) -> dict[str, Any]:
        if not self.path.exists():
            data = self.default_raw()
            self.write_raw_atomic(data)
            return data

        text = self.path.read_text(encoding="utf-8")
        loaded = yaml.safe_load(text)
        if loaded is None:
            loaded = {}
        if not isinstance(loaded, dict):
            raise ValueError("agentgrid.yaml content must be a mapping")
        return loaded

    def write_raw_atomic(self, data: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        dumped = yaml.safe_dump(data, sort_keys=False)
        tmp.write_text(dumped, encoding="utf-8")
        tmp.replace(self.path)


class FileLock:
    def __init__(
        self,
        path: Path | str,
        timeout_seconds: float = 10.0,
        poll_seconds: float = 0.02,
    ) -> None:
        self.path = Path(path)
        self.timeout_seconds = timeout_seconds
        self.poll_seconds = poll_seconds
        self._locked = False

    def acquire(self) -> None:
        start = time.monotonic()
        self.path.parent.mkdir(parents=True, exist_ok=True)

        while True:
            try:
                fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.close(fd)
                self._locked = True
                return
            except FileExistsError:
                if time.monotonic() - start >= self.timeout_seconds:
                    raise TimeoutError(f"acquire lock timeout: {self.path}")
                time.sleep(self.poll_seconds)

    def release(self) -> None:
        if not self._locked:
            return
        try:
            self.path.unlink(missing_ok=True)
        finally:
            self._locked = False
