from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class CommonConfig:
    agent_name: str = "my-agent"
    entry_point: str = "app.py"
    language: str = "Python"
    language_version: str = "3.12"
    dependencies_file: str = "requirements.txt"
    dependency_mode: str = "pip"
    launch_type: str = "cloud"
    runtime_envs: dict[str, str] = field(default_factory=dict)


@dataclass
class LocalLaunchConfig:
    image_tag: str = "latest"
    invoke_port: int = 8080
    ports: list[str] = field(default_factory=lambda: ["8080:8080"])


@dataclass
class CloudLaunchConfig:
    region: str = "cn-north-1"
    image_tag: str = "{{timestamp}}"
    jcr_registry: str = "agentgrid"
    jcr_repo: str = "my-agent"
    runtime_name: str = "MyAgentRuntime"
    # runtime_role_name: str = "Auto"
    runtime_apikey_name: str = ""
    runtime_envs: dict[str, str] = field(default_factory=dict)


@dataclass
class LaunchTypesConfig:
    local: LocalLaunchConfig = field(default_factory=LocalLaunchConfig)
    cloud: CloudLaunchConfig = field(default_factory=CloudLaunchConfig)


@dataclass
class DockerBuildConfig:
    base_image: str = "python:3.12-slim"
    build_script: str = "scripts/setup.sh"


@dataclass
class StateConfig:
    runtime_id: str = ""
    endpoint: str = ""
    last_image_uri: str = ""
    last_build_at: str = ""
    last_deploy_at: str = ""
    last_deploy_version: str = ""


@dataclass
class AgentGridConfig:
    common: CommonConfig = field(default_factory=CommonConfig)
    launch_types: LaunchTypesConfig = field(default_factory=LaunchTypesConfig)
    docker_build: DockerBuildConfig = field(default_factory=DockerBuildConfig)
    state: StateConfig = field(default_factory=StateConfig)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
