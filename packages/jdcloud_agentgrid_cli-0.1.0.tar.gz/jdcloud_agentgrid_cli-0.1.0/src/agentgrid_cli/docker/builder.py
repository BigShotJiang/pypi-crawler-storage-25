import subprocess
from pathlib import Path

from jinja2 import Environment, FileSystemLoader


def ensure_dockerfile(project_dir: Path, data: dict) -> None:
    dockerfile_path = project_dir / "Dockerfile"
    if dockerfile_path.exists():
        return

    docker_build = data.get("docker_build", {})
    common = data.get("common", {})

    base_image = str(docker_build.get("base_image", "python:3.12-slim"))
    dependencies_file = str(common.get("dependencies_file", "requirements.txt"))
    build_script = str(docker_build.get("build_script", ""))
    entry_point = str(common.get("entry_point", "app.py"))
    dependency_mode = str(common.get("dependency_mode", "uv"))

    module_name = entry_point.removesuffix(".py")
    has_build_script = bool(build_script) and (project_dir / build_script).exists()

    template_dir = Path(__file__).resolve().parents[1] / "templates"
    env = Environment(loader=FileSystemLoader(template_dir), autoescape=False)
    template = env.get_template("Dockerfile.j2")

    content = template.render(
        base_image=base_image,
        dependencies_file=dependencies_file,
        build_script=build_script,
        has_build_script=has_build_script,
        module_name=module_name,
        dependency_mode=dependency_mode,
    )

    dockerfile_path.write_text(content, encoding="utf-8")


def build_local_image(image_uri: str) -> tuple[bool, str]:
    cmd = ["docker", "build", "-t", image_uri, "."]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    output = (proc.stdout or "") + (proc.stderr or "")
    return proc.returncode == 0, output.strip()


def build_cloud_image(image_uri: str) -> tuple[bool, str]:
    cmd = ["docker", "build", "--platform", "linux/amd64", "-t", image_uri, "."]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    output = (proc.stdout or "") + (proc.stderr or "")
    return proc.returncode == 0, output.strip()
