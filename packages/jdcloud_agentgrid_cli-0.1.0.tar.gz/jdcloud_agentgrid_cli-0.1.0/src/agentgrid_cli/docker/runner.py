import subprocess

import requests


def run_local_container(
    image_uri: str, container_name: str, invoke_port: int
) -> tuple[bool, str]:
    subprocess.run(
        ["docker", "rm", "-f", container_name], capture_output=True, text=True
    )
    cmd = [
        "docker",
        "run",
        "-d",
        "--name",
        container_name,
        "--network",
        "host",
        image_uri,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    output = (proc.stdout or "") + (proc.stderr or "")
    return proc.returncode == 0, output.strip()


def get_local_status(container_name: str) -> str:
    cmd = ["docker", "inspect", "-f", "{{.State.Status}}", container_name]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        return "not_found"
    return (proc.stdout or "").strip() or "unknown"


def invoke_local_endpoint(endpoint: str, payload: str) -> tuple[bool, str]:
    try:
        response = requests.post(endpoint, json={"input": payload}, timeout=15)
        response.raise_for_status()
        return True, response.text
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)


def destroy_local_container(container_name: str) -> tuple[bool, str]:
    proc = subprocess.run(
        ["docker", "rm", "-f", container_name],
        capture_output=True,
        text=True,
    )
    output = (proc.stdout or "") + (proc.stderr or "")
    return proc.returncode == 0, output.strip()
