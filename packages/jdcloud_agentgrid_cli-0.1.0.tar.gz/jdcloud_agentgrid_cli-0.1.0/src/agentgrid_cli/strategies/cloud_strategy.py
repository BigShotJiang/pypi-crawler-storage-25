import logging
from datetime import datetime, timezone

from agentgrid_cli.adapters.jdcloud.jcr_client import JcrClient
from agentgrid_cli.docker.builder import build_cloud_image
from agentgrid_cli.executors.result import ExecutionResult

logger = logging.getLogger(__name__)

_DEFAULT_REGISTRY_PREFIX = "agentgrid"


class CloudStrategy:
    def build(self, data: dict, image_uri: str | None = None) -> ExecutionResult:
        common = data.get("common", {})
        cloud_cfg = data.get("launch_types", {}).get("cloud", {})

        registry_name = str(cloud_cfg.get("jcr_registry", _DEFAULT_REGISTRY_PREFIX))
        repo = str(cloud_cfg.get("jcr_repo", ""))
        tag = str(cloud_cfg.get("image_tag", "{{timestamp}}"))
        region_id = str(cloud_cfg.get("region", "cn-north-1"))

        if registry_name == _DEFAULT_REGISTRY_PREFIX:
            logger.info("未指定 jcr_registry，使用默认值: %s", registry_name)

        if not repo:
            repo = str(common.get("agent_name", "agentgrid-agent"))

        if tag == "{{timestamp}}":
            tag = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")

        if image_uri is None:
            agent_name = str(common.get("agent_name", "agentgrid-agent"))
            image_uri = f"{agent_name}:{tag}"

        ok, output = build_cloud_image(image_uri)
        if not ok:
            return ExecutionResult(
                success=False, message=output, error_code="BUILD_FAILED"
            )

        jcr = JcrClient(region_id=region_id)
        logger.info("检查 JCR registry '%s'...", registry_name)
        jcr.ensure_registry(registry_name)
        logger.info("检查 JCR repository '%s'...", repo)
        jcr.ensure_repository(registry_name, repo)

        logger.info("推送镜像到 JCR...")
        remote_uri = jcr.push_image(
            local_image=image_uri,
            registry_name=registry_name,
            repo=repo,
            tag=tag,
        )

        return ExecutionResult(
            success=True,
            message=f"cloud build success: {remote_uri}",
            data={"image_uri": remote_uri},
        )
