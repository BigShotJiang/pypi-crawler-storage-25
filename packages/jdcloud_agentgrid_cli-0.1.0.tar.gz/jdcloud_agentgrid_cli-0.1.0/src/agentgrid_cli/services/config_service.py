from pathlib import Path
from typing import Any

import typer
import yaml

from agentgrid_cli.config import ConfigManager

ALLOWED_LAUNCH_TYPES = {"local", "cloud"}
ALLOWED_DEPENDENCY_MODES = {"uv", "pip"}


def load_config(config_path: Path) -> dict[str, Any]:
    manager = ConfigManager(config_path)
    return manager.read_raw()


def apply_config_updates(
    config_path: Path,
    launch_type: str | None,
    dependency_mode: str | None,
    dry_run: bool,
) -> dict[str, Any]:
    manager = ConfigManager(config_path)
    data = manager.read_raw()

    if launch_type is not None:
        if launch_type not in ALLOWED_LAUNCH_TYPES:
            raise ValueError("launch_type must be local or cloud")
        common = data.setdefault("common", {})
        common["launch_type"] = launch_type

    if dependency_mode is not None:
        if dependency_mode not in ALLOWED_DEPENDENCY_MODES:
            raise ValueError("dependency_mode must be uv or pip")
        common = data.setdefault("common", {})
        common["dependency_mode"] = dependency_mode

    if not dry_run:
        manager.write_raw_atomic(data)
    return data


def dump_yaml(data: dict[str, Any]) -> str:
    return yaml.safe_dump(data, sort_keys=False)


def _prompt_value(label: str, current: Any, default: Any = "") -> str:
    display = current if current not in (None, "") else default
    prompt_text = f"  {label}"
    if display:
        prompt_text += f" [{display}]"
    prompt_text += ": "
    value = input(prompt_text).strip()
    return value if value else str(display) if display != "" else ""


def _prompt_envs(label: str, current_envs: dict[str, str]) -> dict[str, str]:
    envs = dict(current_envs)
    typer.echo(f"\n  🔐 {label}")
    typer.echo(
        "  输入 KEY=VALUE 添加变量，输入 'del KEY' 删除，输入 'clear' 清空，直接回车结束"
    )

    while True:
        raw = input("  变量: ").strip()
        if not raw:
            break
        if raw == "clear":
            envs.clear()
            typer.echo("  已清空所有变量")
            continue
        if raw.startswith("del "):
            key = raw[4:].strip()
            if key in envs:
                del envs[key]
                typer.echo(f"  已删除: {key}")
            else:
                typer.echo(f"  未找到: {key}")
            continue
        if "=" not in raw:
            typer.echo("  格式错误，请使用 KEY=VALUE")
            continue
        key, _, val = raw.partition("=")
        key = key.strip()
        val = val.strip()
        if not key:
            typer.echo("  KEY 不能为空")
            continue
        envs[key] = val
        typer.echo(f"  已添加: {key}")

    if envs:
        typer.echo(f"  共 {len(envs)} 个变量")
    return envs


def interactive_config(config_path: Path) -> dict[str, Any]:
    manager = ConfigManager(config_path)
    data = manager.read_raw()
    common = data.setdefault("common", {})
    launch_types = data.setdefault("launch_types", {})
    local_cfg = launch_types.setdefault("local", {})
    cloud_cfg = launch_types.setdefault("cloud", {})

    if not config_path.exists():
        typer.echo(f"  已生成默认配置: {config_path}")

    typer.echo("\n  🔧 AgentGrid 交互式配置\n")
    step = 0
    total_common = 6

    step += 1
    typer.echo(f"  [{step}/{total_common}] 🤖 Agent 名称")
    val = _prompt_value("Agent 名称", common.get("agent_name"), "my-agent")
    if val:
        common["agent_name"] = val

    step += 1
    typer.echo(f"\n  [{step}/{total_common}] 📝 程序入口文件")
    val = _prompt_value("程序入口文件", common.get("entry_point"), "app.py")
    if val:
        common["entry_point"] = val

    step += 1
    typer.echo(f"\n  [{step}/{total_common}] 🐍 Python 版本")
    val = _prompt_value("Python 版本", common.get("language_version"), "3.12")
    if val:
        common["language_version"] = val

    step += 1
    typer.echo(f"\n  [{step}/{total_common}] 📦 依赖文件")
    val = _prompt_value("依赖文件", common.get("dependencies_file"), "requirements.txt")
    if val:
        common["dependencies_file"] = val

    step += 1
    current_dm = common.get("dependency_mode", "uv")
    typer.echo(f"\n  [{step}/{total_common}] 🔧 依赖管理模式 (uv/pip)")
    while True:
        val = _prompt_value("依赖管理模式", current_dm, "uv")
        if val in ALLOWED_DEPENDENCY_MODES:
            common["dependency_mode"] = val
            break
        typer.echo("  依赖管理模式必须是 uv 或 pip")

    step += 1
    current_lt = common.get("launch_type", "cloud")
    typer.echo(f"\n  [{step}/{total_common}] 🚀 部署模式 (local/cloud)")
    while True:
        val = _prompt_value("部署模式", current_lt, "cloud")
        if val in ALLOWED_LAUNCH_TYPES:
            common["launch_type"] = val
            break
        typer.echo(f"  部署模式必须是 local 或 cloud")

    launch_type = common["launch_type"]

    if launch_type == "local":
        local_items = [
            ("镜像标签", "image_tag", "latest"),
            ("调用端口", "invoke_port", "8080"),
            ("端口映射", "ports", "8080:8080"),
        ]
        typer.echo(f"\n  🏠 本地部署配置")
        for label, key, default in local_items:
            current = local_cfg.get(key, default)
            val = _prompt_value(label, current, default)
            if val:
                if key == "invoke_port":
                    try:
                        local_cfg[key] = int(val)
                    except ValueError:
                        typer.echo(f"  端口必须是数字，保留当前值: {current}")
                elif key == "ports":
                    local_cfg[key] = [v.strip() for v in val.split(",") if v.strip()]
                else:
                    local_cfg[key] = val

        local_cfg_envs = _prompt_envs(
            "本地环境变量（会注入到Agent运行时）", local_cfg.get("runtime_envs", {})
        )
        local_cfg["runtime_envs"] = local_cfg_envs

    elif launch_type == "cloud":
        cloud_items = [
            ("区域", "region", "cn-north-1"),
            ("镜像标签", "image_tag", "{{timestamp}}"),
            (
                "容器镜像仓库注册表（要求全局唯一，建议加一个10位随机后缀，避免冲突问题）",
                "jcr_registry",
                "agentgrid",
            ),
            ("镜像名称", "jcr_repo", "my-agent"),
            (
                "Agent运行时名称(系统自动根据名称查找，若不存在将自动创建)",
                "runtime_name",
                "MyAgentRuntime",
            ),
            # ("运行时角色名", "runtime_role_name", "Auto"),
        ]
        typer.echo(f"\n  ☁️ 云端部署配置")
        for label, key, default in cloud_items:
            current = cloud_cfg.get(key, default)
            val = _prompt_value(label, current, default)
            if val:
                cloud_cfg[key] = val

        cloud_cfg_envs = _prompt_envs(
            "云端环境变量（会注入到Agent运行时）", cloud_cfg.get("runtime_envs", {})
        )
        cloud_cfg["runtime_envs"] = cloud_cfg_envs

    common_envs = _prompt_envs(
        "应用级环境变量（本地和云端共享的环境变量）", common.get("runtime_envs", {})
    )
    common["runtime_envs"] = common_envs

    manager.write_raw_atomic(data)
    typer.echo(f"\n  ✅ 配置已保存到 {config_path}\n")

    return data
