from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from agentgrid_cli.config import ConfigManager

SUPPORTED_TEMPLATES = {"basic", "basic_stream"}

_REQUIREMENTS_TXT = "jdcloud-agentgrid>=0.1.4\n"


def init_project(project_dir: Path, template: str) -> list[Path]:
    if template not in SUPPORTED_TEMPLATES:
        raise ValueError(f"unsupported template: {template}")

    if project_dir.exists() and any(project_dir.iterdir()):
        raise FileExistsError(f"project directory is not empty: {project_dir}")

    project_dir.mkdir(parents=True, exist_ok=True)
    template_dir = Path(__file__).resolve().parents[1] / "templates"
    env = Environment(loader=FileSystemLoader(template_dir), autoescape=False)
    project_name = project_dir.name.replace("-", "_").replace(" ", "_")
    created: list[Path] = []

    template_name = "agent.py.j2" if template == "basic" else "agent_stream.py.j2"
    app_template = env.get_template(template_name)
    app_py = project_dir / "app.py"
    app_py.write_text(app_template.render(), encoding="utf-8")
    created.append(app_py)

    pyproject_template = env.get_template("pyproject.toml.j2")
    pyproject_toml = project_dir / "pyproject.toml"
    pyproject_toml.write_text(
        pyproject_template.render(project_name=project_name), encoding="utf-8"
    )
    created.append(pyproject_toml)

    requirements_txt = project_dir / "requirements.txt"
    requirements_txt.write_text(_REQUIREMENTS_TXT, encoding="utf-8")
    created.append(requirements_txt)

    dockerignore = project_dir / ".dockerignore"
    dockerignore.write_text(
        ".venv\n__pycache__\n*.pyc\n.git\nuv.lock\n", encoding="utf-8"
    )
    created.append(dockerignore)

    config_path = project_dir / "agentgrid.yaml"
    config_manager = ConfigManager(config_path)
    config_manager.write_raw_atomic(config_manager.default_raw())
    created.append(config_path)

    return created
