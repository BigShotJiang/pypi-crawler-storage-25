# AgentGrid CLI

AgentGrid CLI 用于本地与京东云 Runtime 的最简部署与管理。

## 快速开始

1. 初始化示例项目

```bash
agentgrid init demo
```

2. 进入项目目录并切换为本地模式

```bash
cd demo
agentgrid config --launch-type local
```

3. 一键构建并部署

```bash
agentgrid launch
```

4. 查看运行状态

```bash
agentgrid status
```

## 核心命令

- `agentgrid version`
- `agentgrid init`
- `agentgrid config`
- `agentgrid build`
- `agentgrid deploy`
- `agentgrid launch`
- `agentgrid status`
- `agentgrid invoke`
- `agentgrid destroy`

## Runtime 子命令

- `agentgrid runtime create/get/update/delete/list`
- `agentgrid runtime release/version/versions`

`runtime create` / `runtime update --artifact-url` 在 `DockerImage` 场景要求使用 JCR URI（例如 `jdcloud-jcr://...`）。

## Invoke 交互模式

- `agentgrid invoke` 为多轮交互模式：首轮使用命令参数，后续在终端持续输入 payload。
- 输入 `exit` / `quit` / `q` 可退出交互。
- 云端模式会使用 `jdcloud-agentgrid` 的 `runtime_session` 复用同一会话进行多轮调用。
- Runtime API Key 优先级：`--api-key` > 环境变量 `AGENTGRID_RUNTIME_API_KEY` > `launch_types.cloud.runtime_apikey_name`。

## Tools 子命令

- `agentgrid tools create/show/delete/list`
- `agentgrid tools session create/show/delete/list/logs/set-ttl`
