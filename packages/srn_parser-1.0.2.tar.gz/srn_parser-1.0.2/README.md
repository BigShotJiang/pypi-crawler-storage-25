# srn-parser

Parse Sarine `.srn` gemstone scan files and export to Wavefront OBJ.

SRN files are produced by [Sarine Technologies](https://sarine.com/) diamond scanning systems (DiaMension, DiaScan). They contain stone metadata (weight, color, clarity, dimensions, etc.) and a 3D mesh of the scanned gemstone. The format stores geometry only — no texture coordinates, UVs, or per-face colors. Face normals are computed from the mesh geometry during export, using flat shading which is appropriate for gemstone facets. A generic gemstone material can optionally be included via `--mtl`.

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install .
```

For development:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

No dependencies — pure Python stdlib. Dev extras install `ruff`, `pytest`, and `pre-commit`.

## CLI Usage

### View stone metadata

```bash
srn-parser info stone.srn
srn-parser info stone.srn --json
```

### Convert to OBJ

```bash
srn-parser convert stone.srn -o output.obj
srn-parser convert stone.srn -o output.obj --mtl          # include material file
srn-parser convert stone.srn -o output.obj --high-res     # use high-resolution mesh
srn-parser convert stone.srn -o output.obj --scale 0.001  # custom scale factor
srn-parser convert stone.srn -o output.obj --no-normals   # skip normal computation
```

SRN coordinates are in micrometers. The default `--scale` of `1e-6` converts to meters.

## Python API

```python
from srn_parser import parse_srn, export_obj

# Parse an SRN file
srn = parse_srn("stone.srn")

# Access metadata
print(srn.metadata.name)        # "b15306"
print(srn.metadata.weight)      # 1.58 (carats)
print(srn.metadata.color)       # "Blue"
print(srn.metadata.clarity)     # "IF"
print(srn.metadata.shape_group) # "ROUND"

# Access mesh data
print(len(srn.mesh.vertices))   # 682
print(len(srn.mesh.faces))      # 343

# High-resolution mesh (from ConcSculptorData, when available)
if srn.high_res_mesh:
    print(len(srn.high_res_mesh.vertices))  # 983

# Export to OBJ
export_obj(srn.mesh, "output.obj", name=srn.metadata.name)

# Export with material file and custom scale
export_obj(srn.mesh, "output.obj", name="diamond", scale=0.001, mtl=True)

# Export high-res mesh
export_obj(srn.high_res_mesh, "output_hires.obj", name="diamond_hires")
```

## SRN Format

The SRN format is a proprietary binary container (SPF) with three sections:

| Section | Content |
|---------|---------|
| `stone.hdr` | Key-value metadata (name, weight, color, clarity, dimensions, etc.) |
| `extdata.dat` | Binary measurement data, including a high-resolution mesh (ConcSculptorData) |
| `smesh.dat` | DirectX .X text-format 3D mesh (vertices and faces) |

## Tests

```bash
pytest -v
```

## Sample Data

The `samples/` directory contains an example SRN file from Sarine DiaScan measurements.
