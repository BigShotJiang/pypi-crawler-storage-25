"""Parser for Sarine .srn (SPF container) files."""

from __future__ import annotations

import struct
from datetime import datetime, timezone
from pathlib import Path

from .directx import parse_directx_mesh
from .models import Mesh, SRNFile, StoneMetadata

SPF_MAGIC = b"SPF "


def parse_srn(path: str | Path) -> SRNFile:
    """Parse a .srn file and return an SRNFile object."""
    path = Path(path)
    with open(path, "rb") as f:
        data = f.read()
    return _parse_container(data)


def _parse_container(data: bytes) -> SRNFile:
    """Parse the SPF binary container."""
    # Validate magic
    if not data.startswith(SPF_MAGIC):
        raise ValueError(f"Not an SRN file: expected magic {SPF_MAGIC!r}, got {data[:4]!r}")

    # Header: 20 bytes magic string + 12 bytes unknown + 4 bytes section count
    offset = 20 + 12
    (section_count,) = struct.unpack_from("<I", data, offset)
    offset += 4

    sections: dict[str, bytes] = {}
    for _ in range(section_count):
        (data_size,) = struct.unpack_from("<I", data, offset)
        offset += 4
        (name_len,) = struct.unpack_from("<I", data, offset)
        offset += 4
        name = data[offset : offset + name_len].decode("ascii")
        offset += name_len
        section_data = data[offset : offset + data_size]
        offset += data_size
        sections[name] = section_data

    # Parse metadata from stone.hdr
    metadata = StoneMetadata()
    if "stone.hdr" in sections:
        metadata = _parse_metadata(sections["stone.hdr"])

    # Parse mesh from smesh.dat
    mesh = Mesh(vertices=[], faces=[])
    if "smesh.dat" in sections:
        text = sections["smesh.dat"].decode("ISO-8859-1")
        mesh = parse_directx_mesh(text)

    # Store raw extdata and try to extract high-res mesh
    ext_data = sections.get("extdata.dat", b"")
    high_res_mesh = _try_parse_conc_sculptor(ext_data)

    return SRNFile(
        metadata=metadata,
        mesh=mesh,
        high_res_mesh=high_res_mesh,
        ext_data=ext_data,
    )


def _parse_metadata(data: bytes) -> StoneMetadata:
    """Parse the stone.hdr section (INI-style key=value pairs)."""
    text = data.decode("ISO-8859-1")

    # Strip the [data] prefix
    if "[data]" in text:
        text = text.split("[data]", 1)[1]

    kvs: dict[str, str] = {}
    for line in text.split("\r\n"):
        line = line.strip()
        if "=" in line:
            key, _, value = line.partition("=")
            kvs[key.strip()] = value.strip()

    def _parse_timestamp(val: str) -> datetime | None:
        if not val:
            return None
        try:
            return datetime.fromtimestamp(int(val), tz=timezone.utc)
        except (ValueError, OSError):
            return None

    def _parse_float(val: str) -> float:
        if not val:
            return 0.0
        try:
            return float(val)
        except ValueError:
            return 0.0

    # stoneWeight can be "carat_weight,measured_weight"
    weight = 0.0
    measured_weight = None
    weight_str = kvs.get("stoneWeight", "")
    if "," in weight_str:
        parts = weight_str.split(",")
        weight = _parse_float(parts[0])
        measured_weight = _parse_float(parts[1])
    else:
        weight = _parse_float(weight_str)

    price_val = kvs.get("stonePrice", "")

    return StoneMetadata(
        name=kvs.get("stoneName", ""),
        date=_parse_timestamp(kvs.get("stoneDate", "")),
        weight=weight,
        measured_weight=measured_weight,
        price=_parse_float(price_val) if price_val else None,
        shape_name=kvs.get("shapeName", ""),
        shape_group=kvs.get("shapeGroup", ""),
        color=kvs.get("stoneColor", ""),
        clarity=kvs.get("stoneClarity", ""),
        width=_parse_float(kvs.get("stoneWidth", "")),
        length=_parse_float(kvs.get("stoneLength", "")),
        height=_parse_float(kvs.get("stoneHeight", "")),
        polish=kvs.get("stonePolish", ""),
        symmetry=kvs.get("stoneSymmetry", ""),
        fluorescence=kvs.get("stoneFluorescence", ""),
        certificate_num=kvs.get("stoneCertificateNum", ""),
        associated_lab=kvs.get("StoneAssociatedLab", ""),
        measure_date=_parse_timestamp(kvs.get("stoneMeasureDate", "")),
        measure_mode=kvs.get("StoneMeasureMode", ""),
    )


def _try_parse_conc_sculptor(ext_data: bytes) -> Mesh | None:
    """Try to extract a high-resolution mesh from the ConcSculptorData section."""
    marker = b"ConcSculptorData"
    idx = ext_data.find(marker)
    if idx < 0:
        return None

    try:
        offset = idx + len(marker)
        # Header: uint32 unknown (=2), uint32 vertex_count
        (_unknown, vertex_count) = struct.unpack_from("<II", ext_data, offset)
        offset += 8

        # Read vertex_count * 3 doubles (XYZ)
        vertices: list[tuple[float, float, float]] = []
        for _ in range(vertex_count):
            x, y, z = struct.unpack_from("<ddd", ext_data, offset)
            vertices.append((x, y, z))
            offset += 24

        # Read face data: uint32 face_count, then faces
        (face_count,) = struct.unpack_from("<I", ext_data, offset)
        offset += 4

        faces: list[tuple[int, ...]] = []
        for _ in range(face_count):
            (n_verts,) = struct.unpack_from("<I", ext_data, offset)
            offset += 4
            indices = struct.unpack_from(f"<{n_verts}I", ext_data, offset)
            faces.append(tuple(indices))
            offset += n_verts * 4

        return Mesh(vertices=vertices, faces=faces, right_handed=True)
    except (struct.error, IndexError, OverflowError):
        return None
