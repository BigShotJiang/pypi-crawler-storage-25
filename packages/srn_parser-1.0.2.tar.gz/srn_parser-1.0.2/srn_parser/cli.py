"""Command-line interface for srn-parser."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .exporters.obj import export_obj
from .parser import parse_srn


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="srn-parser",
        description="Parse Sarine .srn gemstone files and export to OBJ.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # info command
    info_parser = subparsers.add_parser("info", help="Display stone metadata.")
    info_parser.add_argument("file", type=Path, help="Path to .srn file")
    info_parser.add_argument("--json", action="store_true", help="Output as JSON")

    # convert command
    convert_parser = subparsers.add_parser("convert", help="Convert to OBJ format.")
    convert_parser.add_argument("file", type=Path, help="Path to .srn file")
    convert_parser.add_argument("-o", "--output", type=Path, help="Output .obj path")
    convert_parser.add_argument(
        "--scale",
        type=float,
        default=1e-6,
        help="Scale factor for coordinates (default: 1e-6, micrometers to meters)",
    )
    convert_parser.add_argument(
        "--no-normals",
        action="store_true",
        help="Skip computing face normals",
    )
    convert_parser.add_argument(
        "--mtl",
        action="store_true",
        help="Generate companion .mtl material file",
    )
    convert_parser.add_argument(
        "--high-res",
        action="store_true",
        help="Use high-resolution ConcSculptorData mesh instead of standard mesh",
    )

    args = parser.parse_args(argv)

    if not args.file.exists():
        print(f"Error: file not found: {args.file}", file=sys.stderr)
        sys.exit(1)

    srn = parse_srn(args.file)

    if args.command == "info":
        _cmd_info(srn, as_json=args.json)
    elif args.command == "convert":
        _cmd_convert(srn, args)


def _cmd_info(srn, *, as_json: bool) -> None:
    m = srn.metadata
    data = {
        "name": m.name,
        "date": m.date.isoformat() if m.date else None,
        "weight_ct": m.weight,
        "measured_weight_ct": m.measured_weight,
        "price": m.price,
        "shape": m.shape_name,
        "shape_group": m.shape_group,
        "color": m.color,
        "clarity": m.clarity,
        "width_mm": m.width,
        "length_mm": m.length,
        "height_mm": m.height,
        "polish": m.polish or None,
        "symmetry": m.symmetry or None,
        "fluorescence": m.fluorescence or None,
        "certificate": m.certificate_num or None,
        "lab": m.associated_lab or None,
        "measure_date": m.measure_date.isoformat() if m.measure_date else None,
        "measure_mode": m.measure_mode,
        "mesh_vertices": len(srn.mesh.vertices),
        "mesh_faces": len(srn.mesh.faces),
        "high_res_vertices": len(srn.high_res_mesh.vertices) if srn.high_res_mesh else None,
        "high_res_faces": len(srn.high_res_mesh.faces) if srn.high_res_mesh else None,
    }

    if as_json:
        print(json.dumps(data, indent=2))
    else:
        print(f"Stone: {m.name}")
        print(f"Shape: {m.shape_name} ({m.shape_group})")
        print(f"Weight: {m.weight} ct")
        if m.measured_weight is not None:
            print(f"Measured weight: {m.measured_weight} ct")
        if m.price is not None:
            print(f"Price: ${m.price:.2f}")
        print(f"Color: {m.color}")
        print(f"Clarity: {m.clarity}")
        print(f"Dimensions: {m.width:.3f} x {m.length:.3f} x {m.height:.3f} mm")
        if m.polish:
            print(f"Polish: {m.polish}")
        if m.symmetry:
            print(f"Symmetry: {m.symmetry}")
        if m.fluorescence:
            print(f"Fluorescence: {m.fluorescence}")
        if m.certificate_num:
            print(f"Certificate: {m.certificate_num}")
        if m.associated_lab:
            print(f"Lab: {m.associated_lab}")
        print(f"Measure mode: {m.measure_mode}")
        if m.date:
            print(f"Date: {m.date.strftime('%Y-%m-%d %H:%M:%S UTC')}")
        print(f"Mesh: {len(srn.mesh.vertices)} vertices, {len(srn.mesh.faces)} faces")
        if srn.high_res_mesh:
            print(
                f"High-res mesh: {len(srn.high_res_mesh.vertices)} vertices, "
                f"{len(srn.high_res_mesh.faces)} faces"
            )


def _cmd_convert(srn, args) -> None:
    mesh = srn.mesh
    if args.high_res:
        if srn.high_res_mesh is None:
            print("Error: no high-resolution mesh available in this file", file=sys.stderr)
            sys.exit(1)
        mesh = srn.high_res_mesh

    output = args.output
    if output is None:
        output = Path(srn.metadata.name or "stone").with_suffix(".obj")

    export_obj(
        mesh,
        output,
        name=srn.metadata.name or "stone",
        scale=args.scale,
        normals=not args.no_normals,
        mtl=args.mtl,
    )

    print(f"Exported {len(mesh.vertices)} vertices, {len(mesh.faces)} faces -> {output}")
    if args.mtl:
        print(f"Material file -> {output.with_suffix('.mtl')}")


if __name__ == "__main__":
    main()
