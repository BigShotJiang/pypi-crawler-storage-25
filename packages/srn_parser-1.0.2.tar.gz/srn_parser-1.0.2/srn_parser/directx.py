"""Parser for DirectX .X text format meshes (as found in smesh.dat sections)."""

from __future__ import annotations

from .models import Mesh


def parse_directx_mesh(text: str) -> Mesh:
    """Parse a DirectX .X text-format mesh into a Mesh object.

    Expects the standard format:
        xof 0303txt 0032
        Header { ... }
        Mesh { vertex_count; vertices...; face_count; faces...; }
    """
    right_handed = "RightHanded" in text

    # Extract the Mesh { ... } block content
    mesh_start = text.index("Mesh {")
    # Find the matching closing brace - need to handle nested braces
    brace_depth = 0
    mesh_body_start = text.index("{", mesh_start) + 1
    pos = mesh_body_start
    while pos < len(text):
        if text[pos] == "{":
            brace_depth += 1
        elif text[pos] == "}":
            if brace_depth == 0:
                break
            brace_depth -= 1
        pos += 1
    mesh_body = text[mesh_body_start:pos]

    # Split on ;; which separates the four main parts:
    # vertex_count; vertices;; face_count; faces;;
    # But we need to be careful - split by ";\n" after stripping
    lines = mesh_body.strip().split(";\n")

    vertex_count = int(lines[0].strip())
    face_count = int(lines[2].strip())

    # Parse vertices: "x;y;z;," separated by ",\n" (last ends without comma)
    vertex_block = lines[1].strip()
    vertices: list[tuple[float, float, float]] = []
    for entry in vertex_block.split(",\n"):
        entry = entry.strip().rstrip(",")
        parts = [p for p in entry.split(";") if p.strip()]
        if len(parts) >= 3:
            vertices.append((float(parts[0]), float(parts[1]), float(parts[2])))

    # Parse faces: "n;i0,i1,...;," separated by ",\n" (last ends without comma)
    face_block = lines[3].strip()
    faces: list[tuple[int, ...]] = []
    for entry in face_block.split(",\n"):
        entry = entry.strip().rstrip(",")
        parts = entry.split(";")
        # parts[0] = vertex count for this face, parts[1] = comma-separated indices
        if len(parts) >= 2 and parts[1].strip():
            indices = tuple(int(i) for i in parts[1].strip().split(",") if i.strip())
            faces.append(indices)

    assert len(vertices) == vertex_count, f"Expected {vertex_count} vertices, got {len(vertices)}"
    assert len(faces) == face_count, f"Expected {face_count} faces, got {len(faces)}"

    return Mesh(vertices=vertices, faces=faces, right_handed=right_handed)
