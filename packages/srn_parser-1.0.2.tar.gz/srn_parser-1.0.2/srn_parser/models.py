from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass
class StoneMetadata:
    name: str = ""
    date: datetime | None = None
    weight: float = 0.0
    measured_weight: float | None = None
    price: float | None = None
    shape_name: str = ""
    shape_group: str = ""
    color: str = ""
    clarity: str = ""
    width: float = 0.0
    length: float = 0.0
    height: float = 0.0
    polish: str = ""
    symmetry: str = ""
    fluorescence: str = ""
    certificate_num: str = ""
    associated_lab: str = ""
    measure_date: datetime | None = None
    measure_mode: str = ""


@dataclass
class Mesh:
    vertices: list[tuple[float, float, float]]
    faces: list[tuple[int, ...]]
    right_handed: bool = True


@dataclass
class SRNFile:
    metadata: StoneMetadata
    mesh: Mesh
    high_res_mesh: Mesh | None = None
    ext_data: bytes = b""
