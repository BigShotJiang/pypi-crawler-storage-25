"""Wavefront OBJ exporter for SRN mesh data."""

from __future__ import annotations

import math
from pathlib import Path

from ..models import Mesh

Vec3 = tuple[float, float, float]


def _cross(a: Vec3, b: Vec3) -> Vec3:
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def _sub(a: Vec3, b: Vec3) -> Vec3:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _normalize(v: Vec3) -> Vec3:
    length = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2)
    if length < 1e-12:
        return (0.0, 0.0, 1.0)
    return (v[0] / length, v[1] / length, v[2] / length)


def compute_face_normals(
    mesh: Mesh,
) -> list[tuple[float, float, float]]:
    """Compute one flat normal per face using the cross product of the first two edges."""
    normals: list[tuple[float, float, float]] = []
    for face in mesh.faces:
        if len(face) < 3:
            normals.append((0.0, 0.0, 1.0))
            continue
        v0 = mesh.vertices[face[0]]
        v1 = mesh.vertices[face[1]]
        v2 = mesh.vertices[face[2]]
        edge1 = _sub(v1, v0)
        edge2 = _sub(v2, v0)
        normal = _normalize(_cross(edge1, edge2))
        normals.append(normal)
    return normals


def export_obj(
    mesh: Mesh,
    path: str | Path,
    *,
    name: str = "stone",
    scale: float = 1e-6,
    normals: bool = True,
    mtl: bool = False,
) -> None:
    """Export a Mesh to Wavefront OBJ format.

    Args:
        mesh: The mesh to export.
        path: Output .obj file path.
        name: Object name written to the OBJ header.
        scale: Scale factor applied to vertex coordinates.
               SRN coordinates are in micrometers; default 1e-6 converts to meters.
        normals: If True, compute and write per-face normals (flat shading).
        mtl: If True, write a companion .mtl file with a basic gemstone material.
    """
    path = Path(path)

    face_normals = compute_face_normals(mesh) if normals else []

    mtl_name = path.stem + ".mtl" if mtl else None

    lines: list[str] = []
    lines.append(f"# SRN Parser - {name}")
    if mtl_name:
        lines.append(f"mtllib {mtl_name}")
    lines.append(f"o {name}")
    lines.append("")

    # Vertices
    for v in mesh.vertices:
        lines.append(f"v {v[0] * scale:.6f} {v[1] * scale:.6f} {v[2] * scale:.6f}")

    # Normals
    if face_normals:
        lines.append("")
        for n in face_normals:
            lines.append(f"vn {n[0]:.6f} {n[1]:.6f} {n[2]:.6f}")

    lines.append("")
    if mtl_name:
        lines.append("usemtl gemstone")
    lines.append("s off")

    # Faces (1-based indexing)
    for i, face in enumerate(mesh.faces):
        if face_normals:
            ni = i + 1  # 1-based normal index
            indices = " ".join(f"{idx + 1}//{ni}" for idx in face)
        else:
            indices = " ".join(str(idx + 1) for idx in face)
        lines.append(f"f {indices}")

    lines.append("")
    path.write_text("\n".join(lines))

    if mtl:
        _write_mtl(path.with_suffix(".mtl"))


def _write_mtl(path: Path) -> None:
    """Write a basic gemstone material file."""
    lines = [
        "# SRN Parser - gemstone material",
        "newmtl gemstone",
        "Ka 0.100000 0.100000 0.100000",
        "Kd 0.800000 0.800000 0.800000",
        "Ks 1.000000 1.000000 1.000000",
        "Ns 200.000000",
        "Ni 2.420000",
        "d 0.950000",
        "illum 2",
        "",
    ]
    path.write_text("\n".join(lines))
