"""Tests for the SRN binary container parser."""

import pytest

from srn_parser.models import Mesh, SRNFile, StoneMetadata
from srn_parser.parser import _parse_metadata, parse_srn


class TestParseSRN:
    def test_parses_b15924(self, sample_b15924):
        srn = parse_srn(sample_b15924)
        assert isinstance(srn, SRNFile)
        assert isinstance(srn.metadata, StoneMetadata)
        assert isinstance(srn.mesh, Mesh)

    def test_rejects_invalid_magic(self, tmp_path):
        bad_file = tmp_path / "bad.srn"
        bad_file.write_bytes(b"NOT AN SRN FILE")
        with pytest.raises(ValueError, match="Not an SRN file"):
            parse_srn(bad_file)


class TestMetadata:
    def test_b15924_metadata(self, sample_b15924):
        srn = parse_srn(sample_b15924)
        m = srn.metadata
        assert m.name == "b15924"
        assert m.weight == 1.11
        assert m.shape_name == "ROUND-P11-P11"
        assert m.shape_group == "ROUND"
        assert m.color == "Blue"
        assert m.clarity == "IF"
        assert m.width == pytest.approx(1.11)
        assert m.length == pytest.approx(6.02)
        assert m.height == pytest.approx(3.899)
        assert m.measure_mode == "Fastest"

    def test_date_parsing(self, sample_b15924):
        srn = parse_srn(sample_b15924)
        assert srn.metadata.date is not None
        assert srn.metadata.date.year == 2022

    def test_empty_optional_fields(self, sample_b15924):
        srn = parse_srn(sample_b15924)
        assert srn.metadata.polish == ""
        assert srn.metadata.symmetry == ""
        assert srn.metadata.fluorescence == ""
        assert srn.metadata.certificate_num == ""

    def test_parse_metadata_handles_missing_keys(self):
        data = b"[data]\r\nstoneName=test\r\n"
        m = _parse_metadata(data)
        assert m.name == "test"
        assert m.weight == 0.0
        assert m.price is None
        assert m.date is None


class TestMesh:
    def test_b15924_mesh_counts(self, sample_b15924):
        srn = parse_srn(sample_b15924)
        assert len(srn.mesh.vertices) == 880
        assert len(srn.mesh.faces) == 442

    def test_vertices_are_3d_tuples(self, sample_b15924):
        srn = parse_srn(sample_b15924)
        for v in srn.mesh.vertices:
            assert len(v) == 3
            assert all(isinstance(c, float) for c in v)

    def test_face_indices_in_range(self, sample_b15924):
        srn = parse_srn(sample_b15924)
        n_verts = len(srn.mesh.vertices)
        for face in srn.mesh.faces:
            assert len(face) >= 3
            for idx in face:
                assert 0 <= idx < n_verts

    def test_right_handed(self, sample_b15924):
        srn = parse_srn(sample_b15924)
        assert srn.mesh.right_handed is True


class TestHighResMesh:
    def test_b15924_high_res_exists(self, sample_b15924):
        srn = parse_srn(sample_b15924)
        assert srn.high_res_mesh is not None
        assert len(srn.high_res_mesh.vertices) == 912
        assert len(srn.high_res_mesh.faces) == 458

    def test_high_res_more_detail(self, sample_b15924):
        srn = parse_srn(sample_b15924)
        assert len(srn.high_res_mesh.vertices) > len(srn.mesh.vertices)
        assert len(srn.high_res_mesh.faces) > len(srn.mesh.faces)

    def test_high_res_indices_in_range(self, sample_b15924):
        srn = parse_srn(sample_b15924)
        n_verts = len(srn.high_res_mesh.vertices)
        for face in srn.high_res_mesh.faces:
            assert len(face) >= 3
            for idx in face:
                assert 0 <= idx < n_verts


class TestExtData:
    def test_ext_data_present(self, sample_b15924):
        srn = parse_srn(sample_b15924)
        assert len(srn.ext_data) > 0

    def test_ext_data_contains_conc_sculptor(self, sample_b15924):
        srn = parse_srn(sample_b15924)
        assert b"ConcSculptorData" in srn.ext_data
