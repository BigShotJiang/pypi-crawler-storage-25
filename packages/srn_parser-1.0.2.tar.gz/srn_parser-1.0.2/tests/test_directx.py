"""Tests for the DirectX .X text mesh parser."""

import pytest

from srn_parser.directx import parse_directx_mesh
from srn_parser.models import Mesh

MINIMAL_MESH = """\
xof 0303txt 0032

Header {
 1;
 0;
 1;
}

Mesh {
 4;
 0.0;0.0;0.0;,
 1.0;0.0;0.0;,
 1.0;1.0;0.0;,
 0.0;1.0;0.0;;
 2;
 3;0,1,2;,
 3;0,2,3;;

 RightHanded {
  1;
 }
}
"""

MESH_NO_RIGHT_HANDED = """\
xof 0303txt 0032

Header {
 1;
 0;
 1;
}

Mesh {
 3;
 0.0;0.0;0.0;,
 1.0;0.0;0.0;,
 0.5;1.0;0.0;;
 1;
 3;0,1,2;;
}
"""


class TestParseDirectXMesh:
    def test_minimal_mesh(self):
        mesh = parse_directx_mesh(MINIMAL_MESH)
        assert isinstance(mesh, Mesh)
        assert len(mesh.vertices) == 4
        assert len(mesh.faces) == 2

    def test_vertex_values(self):
        mesh = parse_directx_mesh(MINIMAL_MESH)
        assert mesh.vertices[0] == (0.0, 0.0, 0.0)
        assert mesh.vertices[1] == (1.0, 0.0, 0.0)
        assert mesh.vertices[2] == (1.0, 1.0, 0.0)
        assert mesh.vertices[3] == (0.0, 1.0, 0.0)

    def test_face_indices(self):
        mesh = parse_directx_mesh(MINIMAL_MESH)
        assert mesh.faces[0] == (0, 1, 2)
        assert mesh.faces[1] == (0, 2, 3)

    def test_right_handed_flag(self):
        mesh = parse_directx_mesh(MINIMAL_MESH)
        assert mesh.right_handed is True

    def test_no_right_handed(self):
        mesh = parse_directx_mesh(MESH_NO_RIGHT_HANDED)
        assert mesh.right_handed is False
        assert len(mesh.vertices) == 3
        assert len(mesh.faces) == 1

    def test_missing_mesh_block_raises(self):
        with pytest.raises(ValueError):
            parse_directx_mesh("xof 0303txt 0032\nHeader { 1; 0; 1; }")

    def test_quad_faces(self):
        mesh = parse_directx_mesh(MINIMAL_MESH)
        # Second face has 3 vertices (both are triangles in this test)
        assert all(len(f) == 3 for f in mesh.faces)

    def test_negative_coords(self):
        text = MINIMAL_MESH.replace("0.0;0.0;0.0", "-1.5;-2.5;-3.5")
        mesh = parse_directx_mesh(text)
        assert mesh.vertices[0] == (-1.5, -2.5, -3.5)
