"""Tests for the Wavefront OBJ exporter."""

import math

import pytest

from srn_parser.exporters.obj import compute_face_normals, export_obj
from srn_parser.models import Mesh


@pytest.fixture
def triangle_mesh():
    """A single triangle in the XY plane."""
    return Mesh(
        vertices=[(0.0, 0.0, 0.0), (1.0, 0.0, 0.0), (0.0, 1.0, 0.0)],
        faces=[(0, 1, 2)],
    )


@pytest.fixture
def quad_mesh():
    """A quad (two-triangle square) in the XY plane."""
    return Mesh(
        vertices=[
            (0.0, 0.0, 0.0),
            (1.0, 0.0, 0.0),
            (1.0, 1.0, 0.0),
            (0.0, 1.0, 0.0),
        ],
        faces=[(0, 1, 2, 3)],
    )


class TestComputeFaceNormals:
    def test_xy_plane_normal_points_z(self, triangle_mesh):
        normals = compute_face_normals(triangle_mesh)
        assert len(normals) == 1
        nx, ny, nz = normals[0]
        assert abs(nx) < 1e-9
        assert abs(ny) < 1e-9
        assert abs(nz - 1.0) < 1e-9

    def test_xz_plane_normal(self):
        mesh = Mesh(
            vertices=[(0.0, 0.0, 0.0), (1.0, 0.0, 0.0), (0.0, 0.0, 1.0)],
            faces=[(0, 1, 2)],
        )
        normals = compute_face_normals(mesh)
        nx, ny, nz = normals[0]
        assert abs(nx) < 1e-9
        assert abs(ny - (-1.0)) < 1e-9
        assert abs(nz) < 1e-9

    def test_normals_are_unit_length(self, triangle_mesh):
        normals = compute_face_normals(triangle_mesh)
        for n in normals:
            length = math.sqrt(n[0] ** 2 + n[1] ** 2 + n[2] ** 2)
            assert abs(length - 1.0) < 1e-9

    def test_quad_normal(self, quad_mesh):
        normals = compute_face_normals(quad_mesh)
        assert len(normals) == 1
        assert abs(normals[0][2] - 1.0) < 1e-9

    def test_degenerate_face_returns_default(self):
        mesh = Mesh(
            vertices=[(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)],
            faces=[(0, 1, 2)],
        )
        normals = compute_face_normals(mesh)
        length = math.sqrt(sum(c**2 for c in normals[0]))
        assert abs(length - 1.0) < 1e-9


class TestExportOBJ:
    def test_creates_file(self, triangle_mesh, tmp_path):
        out = tmp_path / "test.obj"
        export_obj(triangle_mesh, out, name="test")
        assert out.exists()
        content = out.read_text()
        assert "o test" in content

    def test_vertex_count(self, triangle_mesh, tmp_path):
        out = tmp_path / "test.obj"
        export_obj(triangle_mesh, out)
        content = out.read_text()
        v_lines = [ln for ln in content.splitlines() if ln.startswith("v ")]
        assert len(v_lines) == 3

    def test_face_count(self, triangle_mesh, tmp_path):
        out = tmp_path / "test.obj"
        export_obj(triangle_mesh, out)
        content = out.read_text()
        f_lines = [ln for ln in content.splitlines() if ln.startswith("f ")]
        assert len(f_lines) == 1

    def test_normals_present_by_default(self, triangle_mesh, tmp_path):
        out = tmp_path / "test.obj"
        export_obj(triangle_mesh, out)
        content = out.read_text()
        vn_lines = [ln for ln in content.splitlines() if ln.startswith("vn ")]
        assert len(vn_lines) == 1
        f_lines = [ln for ln in content.splitlines() if ln.startswith("f ")]
        assert "//" in f_lines[0]

    def test_no_normals_option(self, triangle_mesh, tmp_path):
        out = tmp_path / "test.obj"
        export_obj(triangle_mesh, out, normals=False)
        content = out.read_text()
        vn_lines = [ln for ln in content.splitlines() if ln.startswith("vn ")]
        assert len(vn_lines) == 0
        f_lines = [ln for ln in content.splitlines() if ln.startswith("f ")]
        assert "//" not in f_lines[0]

    def test_scale_factor(self, triangle_mesh, tmp_path):
        out = tmp_path / "test.obj"
        export_obj(triangle_mesh, out, scale=2.0, normals=False)
        content = out.read_text()
        v_lines = [ln for ln in content.splitlines() if ln.startswith("v ")]
        parts = v_lines[1].split()
        assert float(parts[1]) == pytest.approx(2.0)

    def test_one_based_indexing(self, triangle_mesh, tmp_path):
        out = tmp_path / "test.obj"
        export_obj(triangle_mesh, out, normals=False)
        content = out.read_text()
        f_lines = [ln for ln in content.splitlines() if ln.startswith("f ")]
        indices = f_lines[0].split()[1:]
        assert indices == ["1", "2", "3"]

    def test_mtl_file_created(self, triangle_mesh, tmp_path):
        out = tmp_path / "test.obj"
        export_obj(triangle_mesh, out, mtl=True)
        mtl_path = tmp_path / "test.mtl"
        assert mtl_path.exists()
        content = mtl_path.read_text()
        assert "newmtl gemstone" in content
        assert "Ni 2.420000" in content

    def test_mtl_referenced_in_obj(self, triangle_mesh, tmp_path):
        out = tmp_path / "test.obj"
        export_obj(triangle_mesh, out, mtl=True)
        content = out.read_text()
        assert "mtllib test.mtl" in content
        assert "usemtl gemstone" in content

    def test_flat_shading(self, triangle_mesh, tmp_path):
        out = tmp_path / "test.obj"
        export_obj(triangle_mesh, out)
        content = out.read_text()
        assert "s off" in content


class TestExportFromSampleFiles:
    def test_export_b15924(self, sample_b15924, tmp_path):
        from srn_parser import export_obj, parse_srn

        srn = parse_srn(sample_b15924)
        out = tmp_path / "b15924.obj"
        export_obj(srn.mesh, out, name=srn.metadata.name)
        content = out.read_text()
        v_lines = [ln for ln in content.splitlines() if ln.startswith("v ")]
        f_lines = [ln for ln in content.splitlines() if ln.startswith("f ")]
        vn_lines = [ln for ln in content.splitlines() if ln.startswith("vn ")]
        assert len(v_lines) == 880
        assert len(f_lines) == 442
        assert len(vn_lines) == 442

    def test_export_high_res(self, sample_b15924, tmp_path):
        from srn_parser import export_obj, parse_srn

        srn = parse_srn(sample_b15924)
        out = tmp_path / "hires.obj"
        export_obj(srn.high_res_mesh, out)
        content = out.read_text()
        v_lines = [ln for ln in content.splitlines() if ln.startswith("v ")]
        assert len(v_lines) == 912
