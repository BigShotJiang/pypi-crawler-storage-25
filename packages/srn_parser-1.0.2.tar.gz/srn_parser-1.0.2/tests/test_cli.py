"""Tests for the CLI interface."""

import json

import pytest

from srn_parser.cli import main


class TestInfoCommand:
    def test_info_output(self, sample_b15924, capsys):
        main(["info", str(sample_b15924)])
        output = capsys.readouterr().out
        assert "b15924" in output
        assert "ROUND" in output
        assert "1.11 ct" in output
        assert "Blue" in output
        assert "IF" in output
        assert "880 vertices" in output

    def test_info_json(self, sample_b15924, capsys):
        main(["info", str(sample_b15924), "--json"])
        output = capsys.readouterr().out
        data = json.loads(output)
        assert data["name"] == "b15924"
        assert data["weight_ct"] == 1.11
        assert data["mesh_vertices"] == 880
        assert data["mesh_faces"] == 442
        assert data["high_res_vertices"] == 912

    def test_info_missing_file(self, tmp_path):
        with pytest.raises(SystemExit):
            main(["info", str(tmp_path / "nonexistent.srn")])


class TestConvertCommand:
    def test_convert_creates_obj(self, sample_b15924, tmp_path):
        out = tmp_path / "out.obj"
        main(["convert", str(sample_b15924), "-o", str(out)])
        assert out.exists()
        content = out.read_text()
        assert content.startswith("# SRN Parser")

    def test_convert_default_filename(self, sample_b15924, capsys):
        main(["convert", str(sample_b15924)])
        output = capsys.readouterr().out
        assert "b15924.obj" in output

    def test_convert_with_mtl(self, sample_b15924, tmp_path):
        out = tmp_path / "out.obj"
        main(["convert", str(sample_b15924), "-o", str(out), "--mtl"])
        assert out.exists()
        assert (tmp_path / "out.mtl").exists()

    def test_convert_high_res(self, sample_b15924, tmp_path, capsys):
        out = tmp_path / "out.obj"
        main(["convert", str(sample_b15924), "-o", str(out), "--high-res"])
        output = capsys.readouterr().out
        assert "912 vertices" in output

    def test_convert_no_normals(self, sample_b15924, tmp_path):
        out = tmp_path / "out.obj"
        main(["convert", str(sample_b15924), "-o", str(out), "--no-normals"])
        content = out.read_text()
        assert "vn " not in content

    def test_convert_custom_scale(self, sample_b15924, tmp_path):
        out = tmp_path / "out.obj"
        main(["convert", str(sample_b15924), "-o", str(out), "--scale", "0.001"])
        content = out.read_text()
        v_line = [ln for ln in content.splitlines() if ln.startswith("v ")][0]
        x = float(v_line.split()[1])
        assert abs(x) > 0.01  # much larger than default 1e-6 scale
