import re
from typing import Optional, Pattern, Union, Any

from rubigram.types import Update
from rubigram.filters import Filter
from rubigram.enums import ChatType, FileType


def text() -> Filter:
    async def wrapper(client, update: "Update") -> bool:
        return bool(update.message_updates[0].message.text)

    return Filter(wrapper)


def bot() -> Filter:
    async def wrapper(client, update: "Update") -> bool:
        return update.message_updates[0].type == ChatType.Bot
        return update.message_updates[0].object_guid.startswith("b0")

    return Filter(wrapper)


def private() -> Filter:
    async def wrapper(client, update: "Update") -> bool:
        return update.message_updates[0].type == ChatType.User
        return update.message_updates[0].object_guid.startswith("u0")

    return Filter(wrapper)


def group() -> Filter:
    async def wrapper(client, update: "Update") -> bool:
        return update.message_updates[0].type == ChatType.Group
        return update.message_updates[0].object_guid.startswith("g0")

    return Filter(wrapper)


def channel() -> Filter:
    async def wrapper(client, update: "Update") -> bool:
        return update.message_updates[0].type == ChatType.Channel
        return update.message_updates[0].object_guid.startswith("c0")

    return Filter(wrapper)


def service() -> Filter:
    async def wrapper(client, update: "Update") -> bool:
        return update.message_updates[0].type == ChatType.Service
        return update.message_updates[0].object_guid.startswith("s0")

    return Filter(wrapper)


def edited() -> Filter:
    async def wrapper(client, update: "Update") -> bool:
        return update.message_updates[0].message.is_edited

    return Filter(wrapper)


def forward() -> Filter:
    async def wrapper(client, update: "Update") -> bool:
        return not update.message_updates[0].message.forwarded_from is None

    return Filter(wrapper)


def location() -> Filter:
    async def wrapper(client, update: "Update") -> bool:
        return not update.message_updates[0].message.location is None

    return Filter(wrapper)


def contact(
    phone_number: Optional[str] = None
) -> Filter:
    async def wrapper(client, update: Update) -> bool:
        if phone_number:
            contact_message = update.message_updates[0].message.contact_message
            return contact_message and contact_message.phone_number == phone_number

        return not update.message_updates[0].message.contact_message is None

    return Filter(wrapper)


def file(
    type: Optional[Union["FileType", list["FileType"]]] = None
) -> Filter:
    async def wrapper(client, update: "Update") -> bool:
        if isinstance(type, FileType):
            file_inline = update.message_updates[0].message.file_inline
            return file_inline and file_inline.type == type

        return not update.message_updates[0].message.file_inline is None

    return Filter(wrapper)


def command(
    command: Union[str, list[str]],
    prefix: Union[str, list[str]] = "/",
    case_sensitive: bool = False,
    startswith: bool = False
) -> Filter:
    async def wrapper(client, update: "Update") -> bool:
        message = update.message_updates[0].message
        if message.text is None:
            return

        commands = command if isinstance(command, list) else [command]
        prefixs = prefix if isinstance(prefix, list) else [prefix]

        if not case_sensitive:
            commands = [c.lower() for c in commands]

        command_list = tuple(p + c for p in prefixs for c in commands)

        text = message.text if case_sensitive else message.text.lower()
        return any(text.startswith(c) if startswith else text == c for c in command_list)

    return Filter(wrapper)


def chat(
    chat: Union[str, list[str]]
) -> Filter:
    async def wrapper(client, update: "Update") -> bool:
        chats = chat if isinstance(chat, list) else [chat]
        return update.message_updates[0].message.author_object_guid in chats

    return Filter(wrapper)


def regex(
    pattern: Union[str, list[str]],
    flags: int = re.IGNORECASE
) -> Filter:
    async def wrapper(client, update: "Update") -> bool:
        text = update.message_updates[0].message.text
        if text is None:
            return False

        patterns = pattern if isinstance(pattern, list) else [pattern]
        compiled_patterns = [re.compile(p, flags) for p in patterns]

        return any(p.search(text) for p in compiled_patterns)

    return Filter(wrapper)