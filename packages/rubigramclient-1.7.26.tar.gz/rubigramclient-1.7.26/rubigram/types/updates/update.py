from typing import Optional, Any, cast
from dataclasses import dataclass, field

import rubigram
from rubigram.enums import ParseMode
from rubigram.types.chats.chat_update import ChatUpdate
from rubigram.types.messages.message_update import MessageUpdate
from .notification import Notifications
from rubigram.types.base import Base


@dataclass(repr=False)
class Update(Base):
    chat_updates: list["ChatUpdate"]
    message_updates: list["MessageUpdate"]
    show_notifications: list["Notifications"]
    user_guid: str
    client: "rubigram.Client"
    raw: dict = field(repr=False)

    @classmethod
    def read(cls, data: dict[str, Any], **kwargs) -> "Update":
        data.update(kwargs)
        chat = [ChatUpdate.read(i) for i in data.get("chat_updates", [])]
        # chat_updates = data.get("chat_updates", [])
        message_updates = data.get("message_updates", [])
        show_notifications = data.get("show_notifications", [])
        return cls(
            chat_updates=chat,
            message_updates=[
                MessageUpdate.read(message_update) for message_update in message_updates
            ],
            show_notifications=[
                Notifications.read(notification) for notification in show_notifications
            ],
            user_guid=str(data.get("user_guid")),
            client=cast(rubigram.Client, data.get("client")),
            raw=data,
        )

    async def reply_text(
        self,
        text: str,
        quote: bool = True,
        metadata: ... = None,
        parse_mode: Optional["ParseMode"] = None,
        auto_delete: Optional[int] = None,
    ):
        message = self.message_updates[0]
        if not quote:
            reply_id = None
        else:
            reply_id = message.message_id
        return await self.client.send_message(
            guid=message.object_guid,
            text=text,
            reply_to_message_id=reply_id,
            metadata=metadata,
            parse_mode=parse_mode,
            auto_delete=auto_delete,
        )
