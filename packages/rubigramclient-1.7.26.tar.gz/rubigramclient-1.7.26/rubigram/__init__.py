class StopPropagation(StopAsyncIteration):
    pass


class ContinuePropagation(StopAsyncIteration):
    pass


from .storage import Storage
from . import enums, types, sync
from .client import Client
from .bot import Bot


__version__ = "1.7.26"
__author__ = ["PyJavad", "DeveloperYasin"]
__github__ = "https://github.ocm/DevJavad/rubigram"