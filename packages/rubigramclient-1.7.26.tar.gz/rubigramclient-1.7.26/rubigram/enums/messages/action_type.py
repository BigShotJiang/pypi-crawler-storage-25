from enum import Enum


class ActionType(Enum):
    EDIT = "Edit"
    NEW = "New"