from enum import Enum


class FileType(Enum):
    GIF = "Gif"
    FILE = "File"
    IMAGE = "Image"
    VIDEO = "Video"
    MUSIC = "Music"
    VOCIE = "Voice"
    VIDEO_MESSAGE = "VideoMessage"