from enum import Enum


class MessageType(Enum):
    GIF = "Gif"
    TEXT = "Text"
    FILE = "File"
    IMAGE = "Image"
    VIDEO = "Video"
    MUSIC = "Music"
    VOCIE = "Voice"
    OTHER = "Other"
    NOT_MESSAGE = "NotMessage"