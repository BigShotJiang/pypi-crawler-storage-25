from enum import Enum, auto


class ChatType(Enum):
    Bot = auto()
    User = auto()
    Group = auto()
    Channel = auto()
    Service = auto()


