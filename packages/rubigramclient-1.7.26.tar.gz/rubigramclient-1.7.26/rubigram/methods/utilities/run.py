import logging
import rubigram
import asyncio
from typing import Awaitable, Any
from typing import Optional,Callable,Union
from rubigram import utils

logger = logging.getLogger(__name__)



StartupType = Awaitable[Any]


class Run:
    def run(
        self: "rubigram.Client",
        on_startup: Optional[StartupType] = None
    ):
        async def main_runner():
            await self.start()
            print("Client Started...")
            
            
            if on_startup:
                await on_startup 
                    
                    
            if self.dispatcher and self.dispatcher.handlers:
                await self.get__updates()
            return self

        try:
            # loop = asyncio.get_running_loop()
            # self.loop = loop
            loop = self.loop or utils.get_event_loop()
        except RuntimeError:
            return asyncio.run(main_runner())
        
        if self.dispatcher and self.dispatcher.handlers:
            return loop.run_until_complete(main_runner())
        else:
            return asyncio.run(main_runner())

        # return loop.create_task(main_runner())
   