import logging
import rubigram


logger = logging.getLogger(__name__)


class Stop:
    async def stop(
        self: "rubigram.Client"
    ):
        await self.connection.disconnect()