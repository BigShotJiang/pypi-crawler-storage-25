import rubigram



class Polling:
    async def start_polling(
        self: "rubigram.Client",
        limit: int = 10,
        rate_limit: int = 1
    ):
        pass