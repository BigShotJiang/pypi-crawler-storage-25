import logging
import rubigram


logger = logging.getLogger(__name__)


class Start:
    async def start(
        self: "rubigram.Client"
    ):
        await self.connection.connect()

        self.me = await self.get_me()
        self.guid = self.me.user_guid