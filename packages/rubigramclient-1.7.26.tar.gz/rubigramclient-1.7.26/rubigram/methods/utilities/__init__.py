from .run import Run
from .stop import Stop
from .start import Start
from .get_updates import GetUpdates
from .add_handler import AddHandler


class Utilities(
    Run,
    Stop,
    Start,
    GetUpdates,
    AddHandler
):
    pass