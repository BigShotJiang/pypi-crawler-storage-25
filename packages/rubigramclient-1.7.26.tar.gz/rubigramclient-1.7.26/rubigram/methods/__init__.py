from .auth import Auth
from .users import Users
from .chats import Chats
from .messages import Messages
from .advanced import Advanced
from .utilities import Utilities
from .decorators import Decorators


class Methods(
    Auth,
    Users,
    Chats,
    Messages,
    Advanced,
    Utilities,
    Decorators
):
    pass