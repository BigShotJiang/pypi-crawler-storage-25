#  RubigramClient - Rubika API library for python
#  Copyright (C) 2025-present Javad <https://github.com/DevJavad>
#  Github - https://github.com/DevJavad/rubigram


from ..base import Base

from dataclasses import dataclass


@dataclass(repr=False)
class InlineMessage(Base):
    ...