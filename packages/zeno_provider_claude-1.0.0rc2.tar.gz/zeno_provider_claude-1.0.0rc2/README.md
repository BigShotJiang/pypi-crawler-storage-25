# zeno-provider-claude

Claude Agent SDK provider for Zeno. Wraps `claude-agent-sdk` (`ClaudeSDKClient`)
behind Zeno's `Provider` Protocol so an `Agent` definition stays portable
across providers.

## Install

```bash
uv add 'zeno-framework[claude]'
```

The `zeno-framework` meta-package ships Claude as the default; this extra is
the explicit form for environments that pin extras.

## Usage

```python
from zeno.agent import Agent
from zeno.app import ZenoApp
from zeno.channels.cli.channel import CliChannel
from zeno.providers.claude_sdk import ClaudeSDKProvider

app = ZenoApp(
    agent=Agent(
        name="root",
        instructions="You are a helpful personal assistant.",
        permission_mode="bypassPermissions",
    ),
    channels=[CliChannel()],
    provider=ClaudeSDKProvider(),
)
```

`ClaudeSDKProvider` reads `ANTHROPIC_API_KEY` from the environment via the
underlying SDK. Set it before `app.start()`.

### Resuming SDK sessions

Pass a `session_lookup` callable to resume a prior SDK session keyed by
`(user_id, channel, thread_key)`:

```python
async def lookup_session(user_id: str, channel: str, thread_key: str | None) -> str | None:
    return await my_store.get_sdk_session_id(user_id, channel, thread_key)


provider = ClaudeSDKProvider(session_lookup=lookup_session)
```

When `session_lookup` returns `None` (or is omitted), each turn starts a fresh
SDK session.

## Capabilities

`ClaudeSDKProvider` is the only Zeno provider that supports:

- `sub_agents` — Claude Agent SDK dispatch via `AgentDefinition`
- `built_in_tools` — `WebSearch`, `WebFetch`, `Bash`, etc.
- `permission_mode` — `default` / `acceptEdits` / `bypassPermissions` / `plan`
- Streaming assistant text via `ctx.stream(...)`
- SDK hook bridge (`PreToolUse` / `PostToolUse` / `UserPromptSubmit` and the
  optional `SubagentStart` / `SubagentStop` / `PostToolUseFailure` hooks when
  available) translated into Zeno trace events.

Part of the [Zeno framework](https://github.com/nkootstra/zeno).
