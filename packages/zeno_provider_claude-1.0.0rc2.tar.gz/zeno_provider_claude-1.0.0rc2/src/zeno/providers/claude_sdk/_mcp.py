"""Claude Agent SDK tool wrapping.

Wraps `ToolSpec` objects from `zeno-core` into the SDK's `SdkMcpTool` shape
and assembles an in-process `McpSdkServerConfig` via
`claude_agent_sdk.create_sdk_mcp_server`. Tool names seen by the SDK
follow the canonical `mcp__<server_key>__<tool_name>` form (the
`allowed_tool_names` helper in `zeno.runtime.mcp` produces those names
and is used by `_options.agent_to_claude_options`).
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from claude_agent_sdk import SdkMcpTool, create_sdk_mcp_server
from zeno.context import current_ctx

if TYPE_CHECKING:
    from zeno.tool import ToolSpec


def to_sdk_tool(spec: ToolSpec) -> SdkMcpTool[Any]:
    """Return an `SdkMcpTool` whose handler bridges the SDK's `(args) -> dict` shape
    to the Zeno `(ctx, **kwargs) -> Any` shape.
    """
    handler = spec.handler
    decoders: dict[str, Callable[[Any], Any]] = spec._param_decoders
    name = spec.name

    async def _sdk_handler(args: dict[str, Any]) -> dict[str, Any]:
        try:
            ctx = current_ctx()
        except LookupError as exc:
            return {
                "content": [
                    {
                        "type": "text",
                        "text": f"Tool '{name}' invoked outside a bound turn: {exc}",
                    }
                ],
                "is_error": True,
            }
        kwargs = {k: decoders[k](v) if k in decoders else v for k, v in args.items()}
        try:
            result = await handler(ctx, **kwargs)
        except Exception as exc:  # noqa: BLE001 — tool errors become is_error envelopes
            return {
                "content": [{"type": "text", "text": str(exc)}],
                "is_error": True,
            }
        return {"content": [{"type": "text", "text": _stringify(result)}]}

    return SdkMcpTool(
        name=spec.name,
        description=spec.description,
        input_schema=spec.schema,
        handler=_sdk_handler,
    )


def build_mcp_server(server_key: str, specs: list[ToolSpec], *, version: str = "1.0.0") -> Any:
    """Build an `McpSdkServerConfig` from a list of `ToolSpec`s.

    The returned value is passed directly as
    `ClaudeAgentOptions.mcp_servers = {server_key: result}`.
    """
    return create_sdk_mcp_server(
        name=server_key,
        version=version,
        tools=[to_sdk_tool(spec) for spec in specs],
    )


def _stringify(result: Any) -> str:
    if isinstance(result, str):
        return result
    import json

    try:
        return json.dumps(result, default=str)
    except TypeError:
        return str(result)
