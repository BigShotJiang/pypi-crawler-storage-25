"""SDK hook bridge — translate Claude Agent SDK hooks into Zeno trace events.

Three hooks are documented in the SDK and bound unconditionally:
  - `PreToolUse`   → `ToolCallStarted`
  - `PostToolUse`  → `ToolCallCompleted(error=result.is_error)`
  - `UserPromptSubmit` → `InboundMessage` (metadata-only)

Three hooks are undocumented-but-helios-verified. We probe for their
input type at import time. If present, we bind them; if absent, we log
once and proceed. Never fail.
  - `SubagentStart`      → `SubAgentStarted`
  - `SubagentStop`       → `SubAgentCompleted(error=False)`
  - `PostToolUseFailure` → `ToolCallCompleted(error=True)`

Hook handler return shape matches helios `assistant/tracing/hooks.py:45`:
  `{"async_": True, "asyncTimeout": 5000}` to unblock the SDK loop.
  Work runs in a background-pinned task.

Return shape matches what `ClaudeAgentOptions(hooks=...)` expects:
  `dict[HookEvent, list[HookMatcher]]`. Each event name maps to a list of
  `HookMatcher(hooks=[callback])` entries — the SDK's
  `_convert_hooks_to_internal_format` iterates matchers and reads
  `matcher.hooks`, so a bare callable value would be silently dropped.

Use `build_hooks(tracer)` at `ZenoApp` construction; `ClaudeSDKProvider`
wires the result into `ClaudeAgentOptions(hooks=...)` automatically.
"""

from __future__ import annotations

import importlib
import logging
from collections.abc import Callable
from typing import Any

from zeno.observability.events import (
    InboundMessage,
    SubAgentCompleted,
    SubAgentStarted,
    ToolCallCompleted,
    ToolCallStarted,
    _Envelope,
)
from zeno.observability.tracer import BackgroundDispatcher, Tracer

logger = logging.getLogger("zeno.observability")

_PROBE_NAMES = (
    "SubagentStartHookInput",
    "SubagentStopHookInput",
    "PostToolUseFailureHookInput",
)

_probe_reported = False


def _probe_sdk_hooks() -> set[str]:
    """Return the set of optional SDK hook names available in the installed SDK."""
    global _probe_reported
    try:
        types_mod = importlib.import_module("claude_agent_sdk.types")
    except ImportError:
        if not _probe_reported:
            logger.info("claude_agent_sdk not installed; SDK hook bridge will not bind any hooks")
            _probe_reported = True
        return set()

    available: set[str] = set()
    for name in _PROBE_NAMES:
        if hasattr(types_mod, name):
            available.add(name)

    if not _probe_reported and len(available) < len(_PROBE_NAMES):
        missing = sorted(set(_PROBE_NAMES) - available)
        logger.info(
            "Sub-agent lifecycle hooks unavailable in installed SDK (%s); "
            "sub-agent trace events will be skipped.",
            ", ".join(missing),
        )
        _probe_reported = True

    return available


_ASYNC_ACK = {"async_": True, "asyncTimeout": 5000}


HookPayload = dict[str, Any]


def build_hooks(
    tracer: Tracer,
    *,
    turn_id_provider: Callable[[], str] | None = None,
    user_id_provider: Callable[[], str | None] | None = None,
    session_id_provider: Callable[[], str | None] | None = None,
    dispatcher: BackgroundDispatcher | None = None,
) -> dict[str, Any]:
    """Build an SDK `hooks=` dict that emits Zeno events via `tracer`.

    The provider callables let the caller inject the current turn's IDs
    when the hook fires (typically: read from `current_ctx()`). Unset
    providers emit events with `None` for the corresponding field.

    Returns a mapping of `HookEvent` names to `[HookMatcher(hooks=[cb])]`.
    """
    dispatcher = dispatcher or BackgroundDispatcher()

    def _env(sequence: int = 0) -> _Envelope:
        return _Envelope(
            turn_id=turn_id_provider() if turn_id_provider else "unbound",
            sequence=sequence,
            user_id=user_id_provider() if user_id_provider else None,
            session_id=session_id_provider() if session_id_provider else None,
        )

    async def _pre_tool_use(
        payload: HookPayload, _tool_use_id: str | None = None, _ctx: Any = None
    ) -> dict[str, Any]:
        tool_name = _extract(payload, "tool_name", "toolName")
        tool_use_id = _extract(payload, "tool_use_id", "toolUseId")
        _safe_emit(
            tracer,
            ToolCallStarted(
                envelope=_env(),
                tool_name=str(tool_name) if tool_name else "<unknown>",
                tool_use_id=str(tool_use_id) if tool_use_id else None,
            ),
        )
        return _ASYNC_ACK

    async def _post_tool_use(
        payload: HookPayload, _tool_use_id: str | None = None, _ctx: Any = None
    ) -> dict[str, Any]:
        tool_name = _extract(payload, "tool_name", "toolName")
        tool_use_id = _extract(payload, "tool_use_id", "toolUseId")
        error = bool(_extract(payload, "is_error", "isError") or False)
        _safe_emit(
            tracer,
            ToolCallCompleted(
                envelope=_env(),
                tool_name=str(tool_name) if tool_name else "<unknown>",
                tool_use_id=str(tool_use_id) if tool_use_id else None,
                duration_ms=None,
                error=error,
            ),
        )
        return _ASYNC_ACK

    async def _user_prompt_submit(
        payload: HookPayload, _tool_use_id: str | None = None, _ctx: Any = None
    ) -> dict[str, Any]:
        prompt = _extract(payload, "prompt") or ""
        _safe_emit(
            tracer,
            InboundMessage(
                envelope=_env(),
                channel="sdk",
                thread_key=None,
                text_length=len(str(prompt)),
            ),
        )
        return _ASYNC_ACK

    callbacks: dict[str, Callable[..., Any]] = {
        "PreToolUse": _pre_tool_use,
        "PostToolUse": _post_tool_use,
        "UserPromptSubmit": _user_prompt_submit,
    }

    available = _probe_sdk_hooks()

    if "SubagentStartHookInput" in available:

        async def _subagent_start(
            payload: HookPayload, _tool_use_id: str | None = None, _ctx: Any = None
        ) -> dict[str, Any]:
            name = _extract(payload, "sub_agent", "subagent", "name") or "<unknown>"
            _safe_emit(
                tracer,
                SubAgentStarted(envelope=_env(), sub_agent_name=str(name)),
            )
            return _ASYNC_ACK

        callbacks["SubagentStart"] = _subagent_start

    if "SubagentStopHookInput" in available:

        async def _subagent_stop(
            payload: HookPayload, _tool_use_id: str | None = None, _ctx: Any = None
        ) -> dict[str, Any]:
            name = _extract(payload, "sub_agent", "subagent", "name") or "<unknown>"
            _safe_emit(
                tracer,
                SubAgentCompleted(
                    envelope=_env(),
                    sub_agent_name=str(name),
                    duration_ms=None,
                    error=False,
                ),
            )
            return _ASYNC_ACK

        callbacks["SubagentStop"] = _subagent_stop

    if "PostToolUseFailureHookInput" in available:

        async def _post_tool_use_failure(
            payload: HookPayload, _tool_use_id: str | None = None, _ctx: Any = None
        ) -> dict[str, Any]:
            tool_name = _extract(payload, "tool_name", "toolName") or "<unknown>"
            tool_use_id = _extract(payload, "tool_use_id", "toolUseId")
            _safe_emit(
                tracer,
                ToolCallCompleted(
                    envelope=_env(),
                    tool_name=str(tool_name),
                    tool_use_id=str(tool_use_id) if tool_use_id else None,
                    duration_ms=None,
                    error=True,
                ),
            )
            return _ASYNC_ACK

        callbacks["PostToolUseFailure"] = _post_tool_use_failure

    return _wrap_as_matchers(callbacks)


def _wrap_as_matchers(
    callbacks: dict[str, Callable[..., Any]],
) -> dict[str, Any]:
    """Wrap each callback in a `HookMatcher(hooks=[cb])` so the SDK accepts it.

    The SDK is imported lazily; if it is not installed, return the callbacks
    dict unchanged so test fixtures that don't supply the SDK still work.
    """
    try:
        from claude_agent_sdk.types import HookMatcher
    except ImportError:
        return dict(callbacks)
    return {event: [HookMatcher(hooks=[cb])] for event, cb in callbacks.items()}


def _extract(payload: Any, *keys: str) -> Any:
    """Look up the first matching key (dict or attribute access)."""
    for key in keys:
        if isinstance(payload, dict) and key in payload:
            return payload[key]
        if hasattr(payload, key):
            return getattr(payload, key)
    return None


def _safe_emit(tracer: Tracer, event: Any) -> None:
    try:
        tracer.on_event(event)
    except Exception:  # noqa: BLE001
        logger.exception("Tracer raised during hook-bridge emit")
