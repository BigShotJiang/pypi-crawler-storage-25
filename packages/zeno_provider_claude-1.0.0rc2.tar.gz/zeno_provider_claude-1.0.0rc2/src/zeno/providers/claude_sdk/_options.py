"""Translate a Zeno `Agent` tree into Claude Agent SDK `ClaudeAgentOptions`.

Lives in the provider package, not in `zeno-core`, so that core stays
provider-agnostic. The translation rules used to live on
`Agent.build_options`; they were moved here in 1.0.0rc2 to remove the
Claude-SDK type leak from core's public surface.

Semantics preserved from the previous in-core implementation:
  - First positional of every `@tool` function is `Ctx`; see `zeno.tool`.
  - If `sub_agents` is non-empty, the new package auto-appends `"Agent"`
    to `allowed_tools` so the Claude Agent SDK routes sub-agent dispatches
    to the `AgentDefinition`s passed in. `"Agent"` is the canonical tool
    name in the current bundled CLI; `"Task"` remains as a CLI-side alias
    but only the canonical form is emitted.
  - Every sub-agent gets its own per-sub-agent MCP server key
    (`f"{mcp_server_key}_{sub_agent.name}"`) so tool-name collisions
    between orchestrator and sub-agent don't silently overwrite each
    other.
  - `built_in_tools` names SDK-native tools (e.g. ``"WebSearch"``,
    ``"Bash"``). Names pass through unvalidated so new SDK tools work
    without a Zeno release. Duplicates are deduped; order is preserved
    for deterministic `allowed_tools` output.
  - `permission_mode` threads directly into `ClaudeAgentOptions`. Default
    is `None` (SDK's prompting default). Set ``"bypassPermissions"`` on
    non-interactive channels.
  - `instructions` is the default system prompt; callers may override per
    turn via ``system_prompt_override``.
  - `resume=session_id` threads through when provided.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from claude_agent_sdk import AgentDefinition, ClaudeAgentOptions
from zeno.providers.claude_sdk._mcp import build_mcp_server
from zeno.runtime.mcp import allowed_tool_names

if TYPE_CHECKING:
    from zeno.agent import Agent, SubAgent


def agent_to_claude_options(
    agent: Agent,
    *,
    mcp_server_key: str,
    session_id: str | None = None,
    system_prompt_override: str | None = None,
) -> ClaudeAgentOptions:
    """Translate an `Agent` tree into a `ClaudeAgentOptions`."""
    root_specs = agent._tool_specs()
    allowed = allowed_tool_names(mcp_server_key, root_specs)
    # Union in SDK built-ins before appending the "Agent" sentinel so
    # sub-agent routing lands last. `dict.fromkeys` dedupes while
    # preserving insertion order — tests assert list order, so a plain
    # `set(...)` would be a regression.
    if agent.built_in_tools:
        allowed = list(dict.fromkeys([*allowed, *agent.built_in_tools]))
    mcp_servers: dict[str, object] = {
        mcp_server_key: build_mcp_server(mcp_server_key, root_specs),
    }

    agents: dict[str, AgentDefinition] = {}
    for sa in agent.sub_agents:
        sa_key = f"{mcp_server_key}_{sa.name}"
        sa_specs = sa._tool_specs()
        if sa_specs:
            mcp_servers[sa_key] = build_mcp_server(sa_key, sa_specs)
        agents[sa.name] = _to_agent_definition(sa, sa_key)

    if agent.sub_agents:
        allowed = [*allowed, "Agent"]

    return ClaudeAgentOptions(
        system_prompt=system_prompt_override or agent.instructions,
        allowed_tools=allowed,
        mcp_servers=mcp_servers,  # type: ignore[arg-type]
        agents=agents or None,
        model=agent.model,
        permission_mode=agent.permission_mode,  # type: ignore[arg-type]
        resume=session_id,
    )


def _to_agent_definition(sub_agent: SubAgent, mcp_server_key: str) -> AgentDefinition:
    """Translate a `SubAgent` into the SDK's `AgentDefinition`."""
    specs = sub_agent._tool_specs()
    tool_names = allowed_tool_names(mcp_server_key, specs)
    if sub_agent.built_in_tools:
        tool_names = list(dict.fromkeys([*tool_names, *sub_agent.built_in_tools]))
    return AgentDefinition(
        description=sub_agent.instructions.split("\n", 1)[0].strip(),
        prompt=sub_agent.instructions,
        tools=tool_names,
        model=sub_agent.model,
        mcpServers=[mcp_server_key] if specs else None,
        maxTurns=sub_agent.max_turns,
    )
