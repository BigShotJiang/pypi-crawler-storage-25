"""Characterization tests for `ClaudeSDKProvider`.

Locked behaviours that any change to `ClaudeSDKProvider` must preserve.
If one of these fails during a refactor, the regression is in
`ClaudeSDKProvider`, not in the tests.

Design notes:
- We replace the real `ClaudeSDKClient` via monkeypatching
  `claude_agent_sdk.ClaudeSDKClient` for each test, so we never touch
  Anthropic.
- We construct a minimal `Ctx` with stub streams + a recording tracer so
  the streaming/tracing paths are observable.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from datetime import UTC, datetime
from types import SimpleNamespace
from typing import Any

import pytest
from zeno.agent import Agent, SubAgent
from zeno.channels.messages import IncomingMessage
from zeno.context import Ctx
from zeno.providers.claude_sdk import ClaudeSDKProvider
from zeno.providers.claude_sdk._options import agent_to_claude_options
from zeno.providers.protocol import Capabilities
from zeno.tool import tool

# ---------------------------------------------------------------------------
# Minimal Ctx plumbing
# ---------------------------------------------------------------------------


@dataclass
class _StreamRecorder:
    chunks: list[str] = field(default_factory=list)
    finalized: bool = False

    async def stream(self, chunk: str) -> None:
        self.chunks.append(chunk)

    async def finalize(self) -> None:
        self.finalized = True

    async def reply(self, _msg: Any) -> None:  # pragma: no cover
        raise AssertionError("reply should not fire in ClaudeSDKProvider tests")


@dataclass
class _RecordingTracer:
    events: list[object] = field(default_factory=list)

    def on_event(self, event: object) -> None:
        self.events.append(event)


def _make_ctx(recorder: _StreamRecorder, tracer: Any | None = None) -> Ctx:
    return Ctx(
        user_id="alice",
        session_id=None,
        channel="cli",
        memory=SimpleNamespace(),
        reply=recorder.reply,
        stream=recorder.stream,
        finalize=recorder.finalize,
        http=SimpleNamespace(),  # type: ignore[arg-type]
        logger=None,
        tracer=tracer,
    )


def _msg(text: str = "hi") -> IncomingMessage:
    return IncomingMessage(
        user_id="alice",
        text=text,
        received_at=datetime(2026, 4, 21, 12, 0, 0, tzinfo=UTC),
        thread_key=None,
    )


# ---------------------------------------------------------------------------
# Mock `ClaudeSDKClient`
# ---------------------------------------------------------------------------


class _MockSDKClient:
    """Recorded calls + canned response stream, replacing `ClaudeSDKClient`."""

    # Class-level containers so the test can inspect what the provider did.
    instances: list[_MockSDKClient] = []

    def __init__(self, *, options: Any) -> None:
        self.options = options
        self.queries: list[str] = []
        self.canned_chunks: list[object] = list(_MockSDKClient._next_chunks)
        _MockSDKClient._next_chunks = []
        _MockSDKClient.instances.append(self)

    async def __aenter__(self) -> _MockSDKClient:
        return self

    async def __aexit__(self, *exc_info: Any) -> None:
        return None

    async def query(self, text: str) -> None:
        self.queries.append(text)

    async def receive_response(self) -> AsyncIterator[object]:
        for chunk in self.canned_chunks:
            yield chunk

    # Set by the test before constructing the provider.
    _next_chunks: list[object] = []

    @classmethod
    def set_next_chunks(cls, chunks: list[object]) -> None:
        cls._next_chunks = chunks

    @classmethod
    def reset(cls) -> None:
        cls.instances = []
        cls._next_chunks = []


@pytest.fixture(autouse=True)
def _patch_sdk_client(monkeypatch: pytest.MonkeyPatch) -> None:
    _MockSDKClient.reset()
    # Patch in both the SDK module and the provider's already-bound import.
    monkeypatch.setattr(
        "claude_agent_sdk.ClaudeSDKClient",
        _MockSDKClient,
    )
    monkeypatch.setattr(
        "zeno.providers.claude_sdk.provider.ClaudeSDKClient",
        _MockSDKClient,
    )


# ---------------------------------------------------------------------------
# Tools used by characterization tests
# ---------------------------------------------------------------------------


@tool
async def _ping(_ctx: Ctx, text: str) -> str:
    """Return text unchanged."""
    return text


# ---------------------------------------------------------------------------
# Capabilities
# ---------------------------------------------------------------------------


def test_capabilities_are_full_true() -> None:
    caps = ClaudeSDKProvider().capabilities
    assert caps == Capabilities(
        supports_sub_agents=True,
        supports_built_in_tools=True,
        supports_permission_mode=True,
        supports_streaming=True,
    )


def test_capabilities_are_constant() -> None:
    # Same instance returned each access — avoids surprise mutation.
    p = ClaudeSDKProvider()
    assert p.capabilities is p.capabilities


# ---------------------------------------------------------------------------
# Structural Protocol compliance
# ---------------------------------------------------------------------------


def test_claude_sdk_provider_is_a_provider() -> None:
    from zeno.providers.protocol import Provider

    assert isinstance(ClaudeSDKProvider(), Provider)


# ---------------------------------------------------------------------------
# Options translation delegation
# ---------------------------------------------------------------------------


async def test_options_match_agent_to_claude_options_byte_for_byte() -> None:
    """Provider's translation of (agent, ctx, msg) must match
    `agent_to_claude_options(agent, ...)` with the same inputs.
    Locks the "pure refactor" guarantee.
    """
    agent = Agent(
        name="root",
        instructions="Base instructions",
        tools=[_ping],
        built_in_tools=["WebSearch"],
        permission_mode="bypassPermissions",
    )
    recorder = _StreamRecorder()
    ctx = _make_ctx(recorder)
    ctx.state["composed_prompt"] = "Composed prompt"

    provider = ClaudeSDKProvider()
    _MockSDKClient.set_next_chunks([])
    await provider.run_turn(agent=agent, ctx=ctx, msg=_msg())

    assert len(_MockSDKClient.instances) == 1
    actual = _MockSDKClient.instances[0].options

    expected = agent_to_claude_options(
        agent,
        mcp_server_key="zeno_app",
        session_id=None,
        system_prompt_override="Composed prompt",
    )
    # Compare the fields we control; ignore `hooks` (tracer-dependent) and any
    # SDK fields that carry unpicklable state (e.g. stderr pipes).
    compared = (
        "system_prompt",
        "allowed_tools",
        "model",
        "permission_mode",
        "resume",
    )
    for field_name in compared:
        assert getattr(actual, field_name) == getattr(expected, field_name), field_name
    # mcp_servers build a fresh `Server` instance per call, so compare
    # structurally rather than by identity.
    actual_servers = actual.mcp_servers
    expected_servers = expected.mcp_servers
    assert isinstance(actual_servers, dict)
    assert isinstance(expected_servers, dict)
    assert set(actual_servers.keys()) == set(expected_servers.keys())


async def test_composed_prompt_absent_uses_agent_instructions() -> None:
    agent = Agent(name="root", instructions="Fallback instructions", tools=[_ping])
    recorder = _StreamRecorder()
    ctx = _make_ctx(recorder)
    # no composed_prompt key -> base instructions flow through
    _MockSDKClient.set_next_chunks([])
    await ClaudeSDKProvider().run_turn(agent=agent, ctx=ctx, msg=_msg())
    opts = _MockSDKClient.instances[0].options
    assert opts.system_prompt == "Fallback instructions"


# ---------------------------------------------------------------------------
# session_lookup behaviour
# ---------------------------------------------------------------------------


async def test_session_lookup_value_threaded_into_resume() -> None:
    calls: list[tuple[str, str, str | None]] = []

    async def lookup(user_id: str, channel: str, thread_key: str | None) -> str | None:
        calls.append((user_id, channel, thread_key))
        return "sess_42"

    agent = Agent(name="root", instructions="x", tools=[_ping])
    recorder = _StreamRecorder()
    ctx = _make_ctx(recorder)
    provider = ClaudeSDKProvider(session_lookup=lookup)
    _MockSDKClient.set_next_chunks([])
    await provider.run_turn(agent=agent, ctx=ctx, msg=_msg())

    assert calls == [("alice", "cli", None)]
    assert _MockSDKClient.instances[0].options.resume == "sess_42"


async def test_session_lookup_none_leaves_resume_none() -> None:
    agent = Agent(name="root", instructions="x", tools=[_ping])
    recorder = _StreamRecorder()
    ctx = _make_ctx(recorder)
    _MockSDKClient.set_next_chunks([])
    await ClaudeSDKProvider().run_turn(agent=agent, ctx=ctx, msg=_msg())
    assert _MockSDKClient.instances[0].options.resume is None


async def test_session_lookup_returning_none_leaves_resume_none() -> None:
    async def lookup(user_id: str, channel: str, thread_key: str | None) -> str | None:
        return None

    agent = Agent(name="root", instructions="x", tools=[_ping])
    recorder = _StreamRecorder()
    ctx = _make_ctx(recorder)
    _MockSDKClient.set_next_chunks([])
    await ClaudeSDKProvider(session_lookup=lookup).run_turn(agent=agent, ctx=ctx, msg=_msg())
    assert _MockSDKClient.instances[0].options.resume is None


# ---------------------------------------------------------------------------
# Streaming bridge
# ---------------------------------------------------------------------------


async def test_streams_text_chunks_in_order_then_finalizes() -> None:
    """Three text chunks land on ctx.stream in order, and finalize runs."""
    recorder = _StreamRecorder()
    ctx = _make_ctx(recorder)
    _MockSDKClient.set_next_chunks(
        [
            SimpleNamespace(text="hel"),
            SimpleNamespace(text="lo "),
            SimpleNamespace(text="world"),
        ]
    )
    agent = Agent(name="root", instructions="x", tools=[_ping])
    await ClaudeSDKProvider().run_turn(agent=agent, ctx=ctx, msg=_msg())
    assert recorder.chunks == ["hel", "lo ", "world"]
    assert recorder.finalized is True


async def test_chunks_without_text_are_ignored() -> None:
    """SDK yields non-text chunks (tool_use, thinking, etc.) — only .text chunks stream."""
    recorder = _StreamRecorder()
    ctx = _make_ctx(recorder)
    _MockSDKClient.set_next_chunks(
        [
            SimpleNamespace(text="keep"),
            SimpleNamespace(other="drop"),  # no .text attr
            SimpleNamespace(text=None),  # None text value
            SimpleNamespace(text=""),  # empty text
            SimpleNamespace(text="also-keep"),
        ]
    )
    agent = Agent(name="root", instructions="x", tools=[_ping])
    await ClaudeSDKProvider().run_turn(agent=agent, ctx=ctx, msg=_msg())
    assert recorder.chunks == ["keep", "also-keep"]


async def test_query_receives_user_message_text() -> None:
    recorder = _StreamRecorder()
    ctx = _make_ctx(recorder)
    _MockSDKClient.set_next_chunks([])
    agent = Agent(name="root", instructions="x", tools=[_ping])
    await ClaudeSDKProvider().run_turn(agent=agent, ctx=ctx, msg=_msg(text="please help"))
    assert _MockSDKClient.instances[0].queries == ["please help"]


# ---------------------------------------------------------------------------
# Hook-bridge wiring
# ---------------------------------------------------------------------------


async def test_hooks_attached_when_tracer_is_present() -> None:
    recorder = _StreamRecorder()
    tracer = _RecordingTracer()
    ctx = _make_ctx(recorder, tracer=tracer)
    agent = Agent(name="root", instructions="x", tools=[_ping])
    _MockSDKClient.set_next_chunks([])
    await ClaudeSDKProvider().run_turn(agent=agent, ctx=ctx, msg=_msg())
    hooks = _MockSDKClient.instances[0].options.hooks
    assert hooks is not None
    assert "PreToolUse" in hooks
    assert "PostToolUse" in hooks


async def test_no_hooks_attached_when_tracer_is_none() -> None:
    recorder = _StreamRecorder()
    ctx = _make_ctx(recorder, tracer=None)
    agent = Agent(name="root", instructions="x", tools=[_ping])
    _MockSDKClient.set_next_chunks([])
    await ClaudeSDKProvider().run_turn(agent=agent, ctx=ctx, msg=_msg())
    # When no tracer, we don't build a hooks dict — hooks stays at SDK default.
    hooks = _MockSDKClient.instances[0].options.hooks
    assert hooks is None


async def test_hook_events_carry_bound_turn_id() -> None:
    """SDK hook callbacks emit events stamped with the bound turn_id."""
    from zeno.context import bind_ctx
    from zeno.observability.events import ToolCallStarted

    recorder = _StreamRecorder()
    tracer = _RecordingTracer()
    ctx = Ctx(
        user_id="alice",
        session_id=None,
        channel="cli",
        memory=SimpleNamespace(),
        reply=recorder.reply,
        stream=recorder.stream,
        finalize=recorder.finalize,
        http=SimpleNamespace(),  # type: ignore[arg-type]
        logger=None,
        tracer=tracer,
        turn_id="turn-abc-123",
    )
    agent = Agent(name="root", instructions="x", tools=[_ping])
    _MockSDKClient.set_next_chunks([])

    with bind_ctx(ctx):
        await ClaudeSDKProvider().run_turn(agent=agent, ctx=ctx, msg=_msg())
        hooks = _MockSDKClient.instances[0].options.hooks
        assert hooks is not None
        entry = hooks["PreToolUse"]
        cb = entry[0].hooks[0] if isinstance(entry, list) else entry
        await cb({"tool_name": "ping", "tool_use_id": "u9"})

    starts = [e for e in tracer.events if isinstance(e, ToolCallStarted)]
    assert len(starts) == 1
    assert starts[0].envelope.turn_id == "turn-abc-123"
    assert starts[0].envelope.user_id == "alice"


# ---------------------------------------------------------------------------
# sub_agents / built_in_tools order regressions
# ---------------------------------------------------------------------------


async def test_sub_agents_append_agent_sentinel_to_allowed_tools() -> None:
    sub = SubAgent(name="weather", instructions="w", tools=[])
    agent = Agent(name="root", instructions="x", tools=[_ping], sub_agents=[sub])
    recorder = _StreamRecorder()
    ctx = _make_ctx(recorder)
    _MockSDKClient.set_next_chunks([])
    await ClaudeSDKProvider().run_turn(agent=agent, ctx=ctx, msg=_msg())
    allowed = list(_MockSDKClient.instances[0].options.allowed_tools)
    assert "Agent" in allowed
    assert allowed[-1] == "Agent"


async def test_built_in_tools_order_preserved_before_sub_agent_sentinel() -> None:
    sub = SubAgent(name="x", instructions="x", tools=[])
    agent = Agent(
        name="root",
        instructions="x",
        tools=[_ping],
        built_in_tools=["WebSearch", "WebFetch"],
        sub_agents=[sub],
    )
    recorder = _StreamRecorder()
    ctx = _make_ctx(recorder)
    _MockSDKClient.set_next_chunks([])
    await ClaudeSDKProvider().run_turn(agent=agent, ctx=ctx, msg=_msg())
    allowed = list(_MockSDKClient.instances[0].options.allowed_tools)
    ws = allowed.index("WebSearch")
    wf = allowed.index("WebFetch")
    agent_idx = allowed.index("Agent")
    assert ws < wf < agent_idx


# ---------------------------------------------------------------------------
# ContextVar invariant: client constructed *inside* the coroutine, so `bind_ctx`
# from the turn worker is still active and tools can observe `current_ctx()`.
# ---------------------------------------------------------------------------


async def test_client_constructed_during_run_turn_call() -> None:
    """Instances list grows only when run_turn is called (construction inside
    the coroutine, not in __init__).
    """
    provider = ClaudeSDKProvider()
    assert _MockSDKClient.instances == []
    recorder = _StreamRecorder()
    ctx = _make_ctx(recorder)
    agent = Agent(name="root", instructions="x", tools=[_ping])
    _MockSDKClient.set_next_chunks([])
    await provider.run_turn(agent=agent, ctx=ctx, msg=_msg())
    assert len(_MockSDKClient.instances) == 1
