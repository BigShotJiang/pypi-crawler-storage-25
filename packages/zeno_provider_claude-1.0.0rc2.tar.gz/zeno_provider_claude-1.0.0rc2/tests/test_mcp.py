"""Tests for `zeno.providers.claude_sdk._mcp` — tool wrapping + server build."""

from __future__ import annotations

from zeno.context import Ctx
from zeno.providers.claude_sdk._mcp import build_mcp_server, to_sdk_tool
from zeno.tool import get_spec, tool


def test_build_mcp_server_returns_sdk_config() -> None:
    @tool
    async def hello(ctx: Ctx, name: str) -> str:
        return f"hi {name}"

    server = build_mcp_server("zeno_app", [get_spec(hello)])
    # `create_sdk_mcp_server` returns a dict-like McpSdkServerConfig.
    # Shape: {"type": "sdk", "name": "zeno_app", "instance": <server>}.
    assert server["type"] == "sdk"
    assert server["name"] == "zeno_app"


def test_to_sdk_tool_preserves_spec_shape() -> None:
    @tool
    async def echo(ctx: Ctx, text: str) -> str:
        return text

    spec = get_spec(echo)
    sdk = to_sdk_tool(spec)
    assert sdk.name == "echo"
    assert sdk.description == spec.description
    assert sdk.input_schema == spec.schema
