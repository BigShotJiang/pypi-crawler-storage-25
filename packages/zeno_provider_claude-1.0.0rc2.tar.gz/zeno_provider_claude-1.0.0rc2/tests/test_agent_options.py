"""Tests for `agent_to_claude_options` — the free-function translator that
takes an `Agent` tree and returns a `ClaudeAgentOptions`.

These assertions used to live on `Agent.build_options` in `zeno-core`'s
`test_agent.py`. They moved here when the translation moved out of core.
"""

from __future__ import annotations

from zeno.agent import Agent, SubAgent
from zeno.context import Ctx
from zeno.providers.claude_sdk._options import agent_to_claude_options
from zeno.tool import tool


@tool
async def t_one(ctx: Ctx, x: int) -> str:
    return str(x)


@tool
async def t_two(ctx: Ctx, s: str) -> str:
    return s


@tool
async def t_research(ctx: Ctx, query: str) -> str:
    return query


SERVER_KEY = "zeno_test"


def test_agent_with_two_tools_lists_both_in_allowed_tools() -> None:
    agent = Agent(name="root", instructions="Be helpful.", tools=[t_one, t_two])
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert f"mcp__{SERVER_KEY}__t_one" in options.allowed_tools
    assert f"mcp__{SERVER_KEY}__t_two" in options.allowed_tools
    assert "Agent" not in options.allowed_tools
    assert "Task" not in options.allowed_tools


def test_agent_with_sub_agents_auto_injects_canonical_agent_name() -> None:
    sa = SubAgent(name="researcher", instructions="Research.", tools=[t_research])
    agent = Agent(name="root", instructions="Be helpful.", tools=[t_one], sub_agents=[sa])

    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert "Agent" in options.allowed_tools
    # Guard against double-listing the canonical and its legacy alias.
    assert "Task" not in options.allowed_tools
    assert options.agents is not None
    assert "researcher" in options.agents


def test_agent_empty_produces_no_agent_and_empty_allowed() -> None:
    agent = Agent(name="root", instructions="Be helpful.")
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert options.allowed_tools == []
    assert "Agent" not in options.allowed_tools
    assert "Task" not in options.allowed_tools
    assert options.agents is None


def test_agent_resume_session_id() -> None:
    agent = Agent(name="root", instructions="Be helpful.")
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY, session_id="abc")

    assert options.resume == "abc"


def test_agent_system_prompt_override() -> None:
    agent = Agent(name="root", instructions="default")
    options = agent_to_claude_options(
        agent, mcp_server_key=SERVER_KEY, system_prompt_override="overridden"
    )

    assert options.system_prompt == "overridden"


def test_sub_agent_tools_namespaced_under_per_sub_agent_key() -> None:
    sa = SubAgent(name="researcher", instructions="Research.", tools=[t_research])
    agent = Agent(name="root", instructions="i", sub_agents=[sa])

    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)
    researcher = options.agents["researcher"]  # type: ignore[index]

    expected_key = f"{SERVER_KEY}_researcher"
    assert researcher.tools == [f"mcp__{expected_key}__t_research"]
    # Per-sub-agent MCP server is registered so the SDK can resolve the tool.
    assert expected_key in options.mcp_servers  # type: ignore[operator]


def test_sub_agent_without_tools_has_no_mcp_servers() -> None:
    sa = SubAgent(name="summarizer", instructions="Summarize.", tools=[])
    agent = Agent(name="root", instructions="i", sub_agents=[sa])

    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)
    summarizer = options.agents["summarizer"]  # type: ignore[index]

    assert summarizer.tools == []
    assert summarizer.mcpServers is None


def test_agent_model_propagates() -> None:
    agent = Agent(name="root", instructions="i", model="claude-sonnet-4-6")
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert options.model == "claude-sonnet-4-6"


def test_mcp_server_registered_under_server_key() -> None:
    agent = Agent(name="root", instructions="i", tools=[t_one])
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert SERVER_KEY in options.mcp_servers  # type: ignore[operator]


def test_sub_agent_max_turns_propagates_to_agent_definition() -> None:
    sa = SubAgent(name="researcher", instructions="Research.", max_turns=3)
    agent = Agent(name="root", instructions="i", sub_agents=[sa])

    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert options.agents["researcher"].maxTurns == 3  # type: ignore[index]


def test_sub_agent_max_turns_defaults_to_none() -> None:
    sa = SubAgent(name="researcher", instructions="Research.")
    agent = Agent(name="root", instructions="i", sub_agents=[sa])

    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert options.agents["researcher"].maxTurns is None  # type: ignore[index]


def test_agent_built_in_tools_added_to_allowed_tools() -> None:
    agent = Agent(name="root", instructions="i", built_in_tools=["WebSearch"])
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert "WebSearch" in options.allowed_tools


def test_agent_built_in_tools_preserve_list_order() -> None:
    agent = Agent(name="root", instructions="i", built_in_tools=["WebSearch", "WebFetch"])
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert options.allowed_tools.index("WebSearch") < options.allowed_tools.index("WebFetch")


def test_agent_built_in_tools_coexist_with_mcp_tools() -> None:
    agent = Agent(
        name="root",
        instructions="i",
        tools=[t_one],
        built_in_tools=["WebSearch"],
    )
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert f"mcp__{SERVER_KEY}__t_one" in options.allowed_tools
    assert "WebSearch" in options.allowed_tools


def test_agent_built_in_tools_deduped() -> None:
    agent = Agent(name="root", instructions="i", built_in_tools=["WebSearch", "WebSearch"])
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert options.allowed_tools.count("WebSearch") == 1


def test_agent_built_in_tools_default_empty_list_preserves_backcompat() -> None:
    agent = Agent(name="root", instructions="i", tools=[t_one])
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    # Byte-identical to pre-change: only the MCP-prefixed name, no extras.
    assert options.allowed_tools == [f"mcp__{SERVER_KEY}__t_one"]


def test_agent_built_in_tools_precede_canonical_agent_sentinel() -> None:
    sa = SubAgent(name="researcher", instructions="Research.")
    agent = Agent(
        name="root",
        instructions="i",
        built_in_tools=["WebSearch"],
        sub_agents=[sa],
    )
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert options.allowed_tools[-1] == "Agent"
    assert "WebSearch" in options.allowed_tools
    assert options.allowed_tools.index("WebSearch") < options.allowed_tools.index("Agent")


def test_agent_permission_mode_propagates() -> None:
    agent = Agent(name="root", instructions="i", permission_mode="bypassPermissions")
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert options.permission_mode == "bypassPermissions"


def test_agent_permission_mode_defaults_to_none() -> None:
    agent = Agent(name="root", instructions="i")
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert options.permission_mode is None


def test_sub_agent_built_in_tools_added_to_agent_definition() -> None:
    sa = SubAgent(name="researcher", instructions="Research.", built_in_tools=["WebFetch"])
    agent = Agent(name="root", instructions="i", sub_agents=[sa])
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    researcher = options.agents["researcher"]  # type: ignore[index]
    assert researcher.tools is not None
    assert "WebFetch" in researcher.tools


def test_sub_agent_built_in_tools_coexist_with_mcp_tools() -> None:
    sa = SubAgent(
        name="researcher",
        instructions="Research.",
        tools=[t_research],
        built_in_tools=["WebSearch"],
    )
    agent = Agent(name="root", instructions="i", sub_agents=[sa])
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    researcher = options.agents["researcher"]  # type: ignore[index]
    assert researcher.tools is not None
    expected_mcp_key = f"{SERVER_KEY}_researcher"
    assert f"mcp__{expected_mcp_key}__t_research" in researcher.tools
    assert "WebSearch" in researcher.tools


def test_sub_agent_built_in_tools_deduped() -> None:
    sa = SubAgent(
        name="researcher",
        instructions="Research.",
        built_in_tools=["WebSearch", "WebSearch"],
    )
    agent = Agent(name="root", instructions="i", sub_agents=[sa])
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    researcher = options.agents["researcher"]  # type: ignore[index]
    assert researcher.tools is not None
    assert researcher.tools.count("WebSearch") == 1


def test_root_and_sub_agent_built_ins_are_independent() -> None:
    sa = SubAgent(
        name="researcher",
        instructions="Research.",
        built_in_tools=["WebFetch"],
    )
    agent = Agent(
        name="root",
        instructions="i",
        built_in_tools=["WebSearch"],
        sub_agents=[sa],
    )
    options = agent_to_claude_options(agent, mcp_server_key=SERVER_KEY)

    assert "WebSearch" in options.allowed_tools
    assert "WebFetch" not in options.allowed_tools

    researcher = options.agents["researcher"]  # type: ignore[index]
    assert researcher.tools is not None
    assert "WebFetch" in researcher.tools
    assert "WebSearch" not in researcher.tools
