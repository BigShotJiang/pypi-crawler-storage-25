"""Tests for the SDK envelope produced by `to_sdk_tool`.

These assertions used to live on `ToolSpec.to_sdk_tool` in
`zeno-core`'s `test_tool.py`. They moved here when the SDK-wrapping
moved out of core in 1.0.0rc2.
"""

# NOTE: This module intentionally does *not* use `from __future__ import annotations`.
# `get_type_hints` cannot resolve locally-scoped classes when all annotations are
# strings, and tool authors routinely write `class Note(BaseModel): ...` next to
# their `@tool` functions. Keeping eager annotations here matches real-world use.

import datetime as dt
from dataclasses import dataclass
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
from pydantic import BaseModel
from zeno.context import Ctx, bind_ctx
from zeno.protocols.memory import (
    KnowledgeViewProtocol,
    MemoryViewProtocol,
    UserMemoryViewProtocol,
)
from zeno.providers.claude_sdk._mcp import to_sdk_tool
from zeno.tool import get_spec, tool


class _Note(BaseModel):
    text: str
    pinned: bool = False


@dataclass
class _FakeUserMemoryView(UserMemoryViewProtocol):
    async def search(self, query: str, k: int = 5) -> list[Any]:
        return []

    async def add(self, text: str, meta: dict[str, Any] | None = None) -> None:
        return None


@dataclass
class _FakeKnowledgeView(KnowledgeViewProtocol):
    async def search(self, query: str, k: int = 5) -> list[Any]:
        return []

    async def add(self, text: str, meta: dict[str, Any] | None = None) -> None:
        return None


@dataclass
class _FakeMemoryView(MemoryViewProtocol):
    user: _FakeUserMemoryView
    knowledge: _FakeKnowledgeView
    session: Any = None
    conversation: Any = None


@pytest.fixture
def fake_ctx() -> Ctx:
    return Ctx(
        user_id="alice",
        session_id=None,
        channel="test",
        memory=_FakeMemoryView(user=_FakeUserMemoryView(), knowledge=_FakeKnowledgeView()),
        reply=AsyncMock(),
        stream=AsyncMock(),
        finalize=AsyncMock(),
        http=httpx.AsyncClient(transport=httpx.MockTransport(lambda req: httpx.Response(200))),
        logger=MagicMock(),
        tracer=MagicMock(),
    )


async def test_sdk_handler_happy_path(fake_ctx: Ctx) -> None:
    @tool
    async def greet(ctx: Ctx, name: str) -> str:
        return f"hi {name}"

    sdk_tool = to_sdk_tool(get_spec(greet))
    with bind_ctx(fake_ctx):
        result = await sdk_tool.handler({"name": "alice"})
    assert result == {"content": [{"type": "text", "text": "hi alice"}]}


async def test_sdk_handler_serializes_dict_result(fake_ctx: Ctx) -> None:
    @tool
    async def f(ctx: Ctx) -> dict[str, int]:
        return {"count": 3}

    sdk_tool = to_sdk_tool(get_spec(f))
    with bind_ctx(fake_ctx):
        result = await sdk_tool.handler({})
    assert result["content"][0]["text"] == '{"count": 3}'


async def test_sdk_handler_converts_exception_to_is_error(fake_ctx: Ctx) -> None:
    @tool
    async def f(ctx: Ctx) -> str:
        raise RuntimeError("boom")

    sdk_tool = to_sdk_tool(get_spec(f))
    with bind_ctx(fake_ctx):
        result = await sdk_tool.handler({})
    assert result["is_error"] is True
    assert "boom" in result["content"][0]["text"]


async def test_sdk_handler_decodes_datetime(fake_ctx: Ctx) -> None:
    seen: list[dt.datetime] = []

    @tool
    async def f(ctx: Ctx, when: dt.datetime) -> str:
        seen.append(when)
        return "ok"

    sdk_tool = to_sdk_tool(get_spec(f))
    with bind_ctx(fake_ctx):
        await sdk_tool.handler({"when": "2026-04-19T10:00:00"})
    assert seen == [dt.datetime(2026, 4, 19, 10, 0, 0)]


async def test_sdk_handler_rehydrates_pydantic(fake_ctx: Ctx) -> None:
    captured: list[_Note] = []

    @tool
    async def f(ctx: Ctx, note: _Note) -> str:
        captured.append(note)
        return note.text

    sdk_tool = to_sdk_tool(get_spec(f))
    with bind_ctx(fake_ctx):
        await sdk_tool.handler({"note": {"text": "hi", "pinned": True}})
    assert captured[0].text == "hi"
    assert captured[0].pinned is True


async def test_sdk_handler_outside_turn_returns_is_error() -> None:
    @tool
    async def f(ctx: Ctx) -> str:
        return "ok"

    sdk_tool = to_sdk_tool(get_spec(f))
    result = await sdk_tool.handler({})
    assert result["is_error"] is True
