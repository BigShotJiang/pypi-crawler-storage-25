"""Convenience functions that combine multiple crgutils steps."""

from __future__ import annotations

from pathlib import Path

from ._dataset import CRGDataset
from ._loader import load
from ._check import check
from ._modifiers import apply_modifiers
from ._types import GridNaNMode


def read(
    path: str | Path,
    *,
    raise_on_error: bool = True,
    # ---- scale modifiers ----
    scale_z:               float | None = None,
    scale_slope:           float | None = None,
    scale_bank:            float | None = None,
    scale_length:          float | None = None,
    scale_width:           float | None = None,
    scale_curvature:       float | None = None,
    # ---- NaN handling ----
    grid_nan_mode:         int | str | GridNaNMode | None = None,
    grid_nan_offset:       float | None = None,
    # ---- repositioning by reference point ----
    ref_point_u:           float | None = None,
    ref_point_u_frac:      float | None = None,
    ref_point_u_offset:    float | None = None,
    ref_point_v:           float | None = None,
    ref_point_v_frac:      float | None = None,
    ref_point_v_offset:    float | None = None,
    ref_point_x:           float | None = None,
    ref_point_y:           float | None = None,
    ref_point_z:           float | None = None,
    ref_point_phi:         float | None = None,
    # ---- reference line offsets / rotation ----
    ref_line_offset_x:     float | None = None,
    ref_line_offset_y:     float | None = None,
    ref_line_offset_z:     float | None = None,
    ref_line_offset_phi:   float | None = None,
    ref_line_rot_center_x: float | None = None,
    ref_line_rot_center_y: float | None = None,
) -> CRGDataset | None:
    """Load a .crg file, validate it, and apply modifiers in one call.

    Equivalent to::

        ds = crgutils.load(path)
        crgutils.check(ds, raise_on_error=True)
        crgutils.apply_modifiers(ds, **ds.pending_modifiers)
        ds.pending_modifiers.clear()

    File-embedded ``pending_modifiers`` are always applied first. Any modifier
    kwargs passed here override same-named keys from the file's embedded
    modifiers.

    Parameters
    ----------
    path:
        Path to a ``.crg`` file.
    raise_on_error:
        If ``True`` (default), raise :exc:`ValueError` on validation failure.
        If ``False``, return ``None`` instead.
    scale_z, scale_slope, ... :
        Modifier overrides — see :func:`~crgutils.apply_modifiers`.

    Returns
    -------
    CRGDataset | None
        The loaded, validated, modified dataset; or ``None`` if
        *raise_on_error* is ``False`` and validation fails.
    """
    ds = load(path)
    if not check(ds, raise_on_error=raise_on_error):
        return None

    # Build dict of explicitly-supplied caller overrides (skip None sentinels)
    _locs = locals()
    _modifier_keys = [
        "scale_z", "scale_slope", "scale_bank", "scale_length",
        "scale_width", "scale_curvature", "grid_nan_mode", "grid_nan_offset",
        "ref_point_u", "ref_point_u_frac", "ref_point_u_offset",
        "ref_point_v", "ref_point_v_frac", "ref_point_v_offset",
        "ref_point_x", "ref_point_y", "ref_point_z", "ref_point_phi",
        "ref_line_offset_x", "ref_line_offset_y", "ref_line_offset_z",
        "ref_line_offset_phi", "ref_line_rot_center_x", "ref_line_rot_center_y",
    ]
    caller_overrides = {k: _locs[k] for k in _modifier_keys if _locs[k] is not None}

    merged = {**ds.pending_modifiers, **caller_overrides}
    apply_modifiers(ds, **merged)
    ds.pending_modifiers.clear()
    return ds
