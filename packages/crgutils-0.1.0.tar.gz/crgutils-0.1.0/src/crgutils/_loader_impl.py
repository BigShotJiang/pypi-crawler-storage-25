"""Full implementation of the .crg / IPLOS file parser.

Supports ASCII formats LRFI / LDFI and binary formats KRBI / KDBI.
"""

from __future__ import annotations

import math
import re
import struct
from enum import Enum, auto
from pathlib import Path
from typing import Any

import numpy as np

from ._dataset import CRGDataset
from ._types import (
    BorderMode,
    RefLineContinue,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_NAN_TOKENS = frozenset({"*missing*", "**unused**", "*nan*"})


class _DataFormat(Enum):
    LRFI = auto()  # ASCII long real formatted interchangeable
    LDFI = auto()  # ASCII long double formatted interchangeable
    KRBI = auto()  # binary kernel real (float32, big-endian)
    KDBI = auto()  # binary kernel double (float64, big-endian)


# Option / modifier key → (EvalOptions field name, converter)
_OPT_MAP: dict[str, tuple[str, Any]] = {
    "border_mode_u":       ("border_mode_u",       lambda v: BorderMode(int(float(v)))),
    "border_mode_v":       ("border_mode_v",        lambda v: BorderMode(int(float(v)))),
    "border_offset_u":     ("border_offset_u",      float),
    "border_offset_v":     ("border_offset_v",      float),
    "smooth_u_begin":      ("smooth_u_begin",       float),
    "smooth_u_end":        ("smooth_u_end",         float),
    "refline_continuation":("ref_line_continue",    lambda v: RefLineContinue(int(float(v)))),
    "refline_search_close":("ref_line_close",       float),
    "refline_search_far":  ("ref_line_far",         float),
}

_MOD_MAP: dict[str, str] = {
    "scale_z":              "scale_z",
    "scale_slope":          "scale_slope",
    "scale_bank":           "scale_bank",
    "scale_length":         "scale_length",
    "scale_width":          "scale_width",
    "scale_curvature":      "scale_curvature",
    "grid_nan_mode":        "grid_nan_mode",
    "grid_nan_offset":      "grid_nan_offset",
    "ref_point_v":          "ref_point_v",
    "ref_point_v_frac":     "ref_point_v_frac",
    "ref_point_v_offset":   "ref_point_v_offset",
    "ref_point_u":          "ref_point_u",
    "ref_point_u_frac":     "ref_point_u_frac",
    "ref_point_u_offset":   "ref_point_u_offset",
    "ref_point_x":          "ref_point_x",
    "ref_point_y":          "ref_point_y",
    "ref_point_z":          "ref_point_z",
    "ref_point_phi":        "ref_point_phi",
    "ref_line_offset_x":    "ref_line_offset_x",
    "ref_line_offset_y":    "ref_line_offset_y",
    "ref_line_offset_z":    "ref_line_offset_z",
    "ref_line_offset_phi":  "ref_line_offset_phi",
    "ref_line_rot_center_x":"ref_line_rot_center_x",
    "ref_line_rot_center_y":"ref_line_rot_center_y",
}


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def _load_impl(path: Path) -> CRGDataset:
    raw = path.read_bytes()
    # Split at first data-section separator (the $$$$... line)
    header_bytes, data_bytes, data_format = _split_header_data(raw)
    header_text = header_bytes.decode("latin-1", errors="replace")

    # Parse header into a dict of key→value
    ctx = _parse_header(header_text, path)

    # Build CRGDataset from parsed header context
    ds = _build_dataset(ctx, data_bytes, data_format, path)
    return ds


# ---------------------------------------------------------------------------
# Header/data split
# ---------------------------------------------------------------------------

def _split_header_data(
    raw: bytes,
) -> tuple[bytes, bytes, _DataFormat]:
    """Find the $$$$... separator line and split raw bytes into header + data.

    For binary formats (KRBI/KDBI) the data section must NOT be re-joined via
    split/join because binary values may contain 0x0A bytes.  We locate the
    separator by scanning line-by-line through the ASCII header and then take
    everything from the byte immediately after the separator line's newline.
    """
    sep_byte_end = None
    pos = 0
    while pos < len(raw):
        nl = raw.find(b"\n", pos)
        if nl < 0:
            line = raw[pos:]
            nl = len(raw) - 1
        else:
            line = raw[pos: nl]
        stripped = line.rstrip(b"\r")
        if stripped.startswith(b"$$$$"):
            sep_byte_end = nl + 1  # byte after the separator line's newline
            break
        pos = nl + 1

    if sep_byte_end is None:
        raise ValueError("No data separator ($$$$...) found in CRG file")

    header_bytes = raw[:sep_byte_end]
    data_bytes   = raw[sep_byte_end:]

    # Detect data format from header
    data_format = _detect_format(header_bytes.decode("latin-1", errors="replace"))
    return header_bytes, data_bytes, data_format


def _detect_format(header: str) -> _DataFormat:
    for line in header.splitlines():
        s = line.strip().upper()
        if s.startswith("#:"):
            fmt = s[2:].strip()
            return {
                "LRFI": _DataFormat.LRFI,
                "LDFI": _DataFormat.LDFI,
                "KRBI": _DataFormat.KRBI,
                "KDBI": _DataFormat.KDBI,
            }.get(fmt, _DataFormat.LRFI)
    return _DataFormat.LRFI


# ---------------------------------------------------------------------------
# Header parser
# ---------------------------------------------------------------------------

class _ParseCtx:
    """Mutable parsing state."""
    def __init__(self, path: Path) -> None:
        self.path = path
        self.comment = ""
        # Road CRG params
        self.u_start  = 0.0
        self.u_end    = 0.0
        self.x_start  = 0.0
        self.y_start  = 0.0
        self.phi_start = 0.0
        self.x_end    = None   # may not be specified
        self.y_end    = None
        self.phi_end  = 0.0
        self.u_inc    = 1.0
        self.v_right  = None
        self.v_left   = None
        self.v_inc    = None
        self.slope_start = 0.0
        self.slope_end   = 0.0
        self.bank_start  = 0.0
        self.bank_end    = 0.0
        self.z_start     = 0.0
        self.z_end       = 0.0
        # Channel definitions (in order)
        self.channels: list[dict] = []   # {type: 'U'|'D', name: str, v: float|None}
        self.data_format: _DataFormat = _DataFormat.LRFI
        # Options / modifiers
        self.options:   dict[str, Any] = {}
        self.modifiers: dict[str, Any] = {}


def _parse_header(text: str, path: Path) -> _ParseCtx:
    ctx = _ParseCtx(path)
    section = "NONE"
    lines = text.splitlines()

    for line in lines:
        # Strip inline comments after "!"
        comment_idx = line.find("!")
        if comment_idx >= 0:
            line = line[:comment_idx]
        line = line.rstrip()

        if not line:
            continue

        # Section markers
        if line.startswith("$"):
            tag = line.lstrip("$").strip().upper()
            if not tag or tag.startswith("!"):
                continue  # $! separator lines
            if tag.startswith("CT"):
                section = "CT"
            elif tag.startswith("ROAD_CRG_OPTS") or tag.startswith("ROAD_CRG_OPTS"):
                section = "OPTS"
            elif tag.startswith("ROAD_CRG_MODS"):
                section = "MODS"
            elif tag.startswith("ROAD_CRG"):
                section = "ROAD_CRG"
            elif tag.startswith("KD_DEF"):
                section = "KD_DEF"
            elif tag.startswith("ROAD_CRG_FILE"):
                section = "FILE"
            else:
                section = "UNKNOWN"
            continue

        # Line comments (* in column 1 or % anywhere)
        if line.startswith("*") or line.startswith("%"):
            if section == "CT":
                ctx.comment += line.lstrip("*% ") + "\n"
            continue

        if section == "CT":
            ctx.comment += line + "\n"
            continue

        if section == "ROAD_CRG":
            _parse_road_crg_line(ctx, line)
        elif section == "KD_DEF":
            _parse_kd_def_line(ctx, line)
        elif section == "OPTS":
            _parse_option_line(ctx, line)
        elif section == "MODS":
            _parse_modifier_line(ctx, line)

    return ctx


def _strip_value(raw: str) -> str:
    """Extract the value after '=' and strip whitespace + inline comment."""
    if "=" in raw:
        val = raw.split("=", 1)[1]
    else:
        val = raw
    # strip inline comment
    for ch in ("!", "*", "%"):
        idx = val.find(ch)
        if idx >= 0:
            val = val[:idx]
    return val.strip()


def _parse_road_crg_line(ctx: _ParseCtx, line: str) -> None:
    key = line.split("=")[0].strip().lower() if "=" in line else ""
    val_str = _strip_value(line) if "=" in line else ""
    try:
        val = float(val_str) if val_str else 0.0
    except ValueError:
        return

    mapping = {
        "reference_line_start_u":   "u_start",
        "reference_line_end_u":     "u_end",
        "reference_line_start_x":   "x_start",
        "reference_line_start_y":   "y_start",
        "reference_line_start_phi": "phi_start",
        "reference_line_end_x":     "x_end",
        "reference_line_end_y":     "y_end",
        "reference_line_end_phi":   "phi_end",
        "reference_line_increment": "u_inc",
        "long_section_v_right":     "v_right",
        "long_section_v_left":      "v_left",
        "long_section_v_increment": "v_inc",
        "reference_line_start_z":   "z_start",
        "reference_line_end_z":     "z_end",
        "reference_line_start_s":   "slope_start",
        "reference_line_end_s":     "slope_end",
        "reference_line_start_b":   "bank_start",
        "reference_line_end_b":     "bank_end",
    }
    attr = mapping.get(key)
    if attr:
        setattr(ctx, attr, val)


def _parse_kd_def_line(ctx: _ParseCtx, line: str) -> None:
    s = line.strip()
    if s.startswith("#:"):
        fmt_str = s[2:].strip().upper()
        ctx.data_format = {
            "LRFI": _DataFormat.LRFI,
            "LDFI": _DataFormat.LDFI,
            "KRBI": _DataFormat.KRBI,
            "KDBI": _DataFormat.KDBI,
        }.get(fmt_str, _DataFormat.LRFI)
        return

    if s.upper().startswith("U:"):
        ctx.channels.append({"type": "U", "name": s[2:].split(",")[0].strip(), "v": None})
        return

    if s.upper().startswith("D:"):
        desc = s[2:]
        # Try to extract v position from name "long section at v = X.XXX"
        v_pos = None
        m = re.search(r"v\s*=\s*([+-]?\d+\.?\d*)", desc, re.IGNORECASE)
        if m:
            v_pos = float(m.group(1))
        name = desc.split(",")[0].strip()
        ctx.channels.append({"type": "D", "name": name, "v": v_pos})
        return


def _parse_option_line(ctx: _ParseCtx, line: str) -> None:
    if "=" not in line:
        return
    key = line.split("=")[0].strip().lower().replace(" ", "_")
    val_str = _strip_value(line)
    try:
        val = float(val_str)
    except ValueError:
        return
    info = _OPT_MAP.get(key)
    if info:
        field, converter = info
        try:
            ctx.options[field] = converter(val)
        except Exception:
            pass


def _parse_modifier_line(ctx: _ParseCtx, line: str) -> None:
    if "=" not in line:
        return
    key = line.split("=")[0].strip().lower().replace(" ", "_")
    val_str = _strip_value(line)
    try:
        val = float(val_str)
    except ValueError:
        return
    field = _MOD_MAP.get(key)
    if field:
        ctx.modifiers[field] = val


# ---------------------------------------------------------------------------
# Dataset builder
# ---------------------------------------------------------------------------

def _build_dataset(
    ctx: _ParseCtx,
    data_bytes: bytes,
    data_format: _DataFormat,
    path: Path,
) -> CRGDataset:
    # Determine channel layout
    d_channels = [ch for ch in ctx.channels if ch["type"] == "D"]

    # Split into special ref-line channels vs z-grid channels
    phi_col   = None
    bank_col  = None
    slope_col = None
    z_cols:   list[int] = []   # indices into d_channels
    v_positions: list[float] = []

    for i, ch in enumerate(d_channels):
        name_lower = ch["name"].lower()
        if "phi" in name_lower or "heading" in name_lower:
            phi_col = i
        elif "bank" in name_lower:
            bank_col = i
        elif "slope" in name_lower:
            slope_col = i
        else:
            z_cols.append(i)
            # v position from channel description or from uniform spacing
            if ch["v"] is not None:
                v_positions.append(ch["v"])

    # If v positions weren't embedded in channel names, derive from header
    if not v_positions:
        v_positions = _derive_v_positions(ctx, len(z_cols))
    else:
        # Rebuild v_positions using only z channels (skip phi/bank/slope)
        v_positions = [d_channels[i]["v"] for i in z_cols if d_channels[i]["v"] is not None]
        if len(v_positions) != len(z_cols):
            v_positions = _derive_v_positions(ctx, len(z_cols))

    n_v = len(z_cols)
    if n_v == 0:
        raise ValueError("No z-grid (D:) channels found in CRG file")

    # Total columns in the data matrix
    n_d = len(d_channels)

    # Parse data matrix (auto-detect n_u from actual data when u_end not given)
    n_u_hdr = (
        max(2, round((ctx.u_end - ctx.u_start) / ctx.u_inc) + 1)
        if ctx.u_end != ctx.u_start
        else 0   # 0 means "auto-detect from data"
    )
    matrix = _parse_data_matrix(
        data_bytes, data_format, n_u_hdr, n_d
    )  # shape (actual_n_u, n_d)
    n_u = matrix.shape[0]

    # Recompute u_end if it wasn't specified
    if ctx.u_end == ctx.u_start:
        ctx.u_end = ctx.u_start + (n_u - 1) * ctx.u_inc

    u_arr = np.linspace(ctx.u_start, ctx.u_end, n_u)

    # Extract channels from matrix
    phi_arr   = matrix[:, phi_col].astype(float)   if phi_col  is not None else None
    bank_arr  = matrix[:, bank_col].astype(float)  if bank_col is not None else None
    slope_arr = matrix[:, slope_col].astype(float) if slope_col is not None else None

    z_matrix = matrix[:, z_cols].T.astype(np.float64)  # shape (n_v, n_u)

    # Handle NaN normalization: store mean per row
    import warnings as _warnings
    with _warnings.catch_warnings():
        _warnings.simplefilter("ignore", RuntimeWarning)
        z_mean = np.nanmean(z_matrix, axis=1)  # (n_v,)
    z_mean = np.where(np.isnan(z_mean), 0.0, z_mean)
    z_norm = (z_matrix - z_mean[:, np.newaxis]).astype(np.float32)

    # Build reference line x, y, phi
    x_arr, y_arr, phi_full = _build_ref_line(ctx, u_arr, phi_arr)

    # ref_z: from slope integration
    ref_z_arr = _build_ref_z(ctx, u_arr, slope_arr)

    # Utility precomputation
    phi_first_sin = math.sin(float(phi_full[0]))
    phi_first_cos = math.cos(float(phi_full[0]))
    phi_last_sin  = math.sin(float(phi_full[-1]))
    phi_last_cos  = math.cos(float(phi_full[-1]))

    # v array
    v_arr = np.array(v_positions, dtype=float)
    v_equally = _check_v_equally_spaced(v_arr)
    v_inc = float(v_arr[1] - v_arr[0]) if (v_equally and len(v_arr) > 1) else 0.0

    has_bank = bank_arr is not None and not np.all(np.isnan(bank_arr))

    return CRGDataset(
        u=u_arr,
        x=x_arr,
        y=y_arr,
        phi=phi_full,
        v=v_arr,
        z=z_norm,
        z_mean=z_mean,
        ref_z=ref_z_arr,
        bank=bank_arr,
        slope=slope_arr,
        u_inc=ctx.u_inc,
        v_inc=v_inc,
        u_is_closed=False,
        v_equally_spaced=v_equally,
        has_bank=has_bank,
        phi_first_sin=phi_first_sin,
        phi_first_cos=phi_first_cos,
        phi_last_sin=phi_last_sin,
        phi_last_cos=phi_last_cos,
        default_options=ctx.options,
        pending_modifiers=ctx.modifiers,
        source_file=str(path),
        comment=ctx.comment.strip(),
    )


def _derive_v_positions(ctx: _ParseCtx, n_z: int) -> list[float]:
    """Derive v positions from header when not embedded in channel names."""
    if ctx.v_right is not None and ctx.v_left is not None and ctx.v_inc is not None:
        v_min = ctx.v_right   # v_right is negative (right of centerline)
        v_max = ctx.v_left
        v_inc = ctx.v_inc
        n = round((v_max - v_min) / v_inc) + 1
        return list(np.linspace(v_min, v_max, n))
    elif ctx.v_right is not None and ctx.v_left is not None:
        return list(np.linspace(ctx.v_right, ctx.v_left, n_z))
    else:
        return list(np.linspace(-1.5, 1.5, n_z))


def _check_v_equally_spaced(v: np.ndarray, tol: float = 1e-6) -> bool:
    if len(v) < 2:
        return True
    diffs = np.diff(v)
    return bool(np.all(np.abs(diffs - diffs[0]) < tol))


def _build_ref_line(
    ctx: _ParseCtx,
    u_arr: np.ndarray,
    phi_col_data: np.ndarray | None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Build reference line x, y arrays and full phi array."""
    n_u = len(u_arr)

    if phi_col_data is not None:
        # Phi channel given directly in data
        phi_full = phi_col_data.copy()
        # Handle **unused** / NaN at row 0 by filling from start
        if np.isnan(phi_full[0]):
            phi_full[0] = ctx.phi_start
        # Integrate to get x, y
        x = np.empty(n_u)
        y = np.empty(n_u)
        x[0] = ctx.x_start
        y[0] = ctx.y_start
        for i in range(1, n_u):
            ph = float(phi_full[i - 1])
            x[i] = x[i - 1] + ctx.u_inc * math.cos(ph)
            y[i] = y[i - 1] + ctx.u_inc * math.sin(ph)
    elif ctx.x_end is not None and ctx.y_end is not None:
        # Straight line: interpolate x, y from start to end
        x = np.linspace(ctx.x_start, ctx.x_end, n_u)
        y = np.linspace(ctx.y_start, ctx.y_end, n_u)
        # phi: constant or interpolated
        phi_full = np.full(n_u, ctx.phi_start)
        if ctx.phi_start != ctx.phi_end:
            phi_full = np.linspace(ctx.phi_start, ctx.phi_end, n_u)
    else:
        # Only start phi / end phi given: integrate phi from start
        phi_full = np.linspace(ctx.phi_start, ctx.phi_end, n_u)
        x = np.empty(n_u)
        y = np.empty(n_u)
        x[0] = ctx.x_start
        y[0] = ctx.y_start
        for i in range(1, n_u):
            ph = float(phi_full[i - 1])
            x[i] = x[i - 1] + ctx.u_inc * math.cos(ph)
            y[i] = y[i - 1] + ctx.u_inc * math.sin(ph)

    return x, y, phi_full


def _build_ref_z(
    ctx: _ParseCtx,
    u_arr: np.ndarray,
    slope_col_data: np.ndarray | None,
) -> np.ndarray | None:
    n_u = len(u_arr)
    if slope_col_data is not None:
        # Integrate slope data to get ref z
        slope = slope_col_data.copy()
        if np.isnan(slope[0]):
            slope[0] = ctx.slope_start
        ref_z = np.empty(n_u)
        ref_z[0] = ctx.z_start
        for i in range(1, n_u):
            s = float(slope[i - 1]) if not math.isnan(float(slope[i - 1])) else 0.0
            ref_z[i] = ref_z[i - 1] + ctx.u_inc * s
        return ref_z
    elif ctx.z_start != 0.0 or ctx.z_end != 0.0:
        return np.linspace(ctx.z_start, ctx.z_end, n_u)
    elif ctx.slope_start != 0.0 or ctx.slope_end != 0.0:
        slopes = np.linspace(ctx.slope_start, ctx.slope_end, n_u)
        ref_z = np.empty(n_u)
        ref_z[0] = ctx.z_start
        for i in range(1, n_u):
            ref_z[i] = ref_z[i - 1] + ctx.u_inc * float(slopes[i - 1])
        return ref_z
    return None


# ---------------------------------------------------------------------------
# Data matrix parsers
# ---------------------------------------------------------------------------

def _parse_data_matrix(
    data_bytes: bytes,
    fmt: _DataFormat,
    n_u: int,
    n_d: int,
) -> np.ndarray:
    """Parse data section into array of shape (n_u, n_d)."""
    if fmt == _DataFormat.LRFI:
        return _parse_ascii_matrix(data_bytes, n_u, n_d, field_width=10)
    elif fmt == _DataFormat.LDFI:
        return _parse_ascii_matrix(data_bytes, n_u, n_d, field_width=20)
    elif fmt == _DataFormat.KRBI:
        return _parse_binary_matrix(data_bytes, n_u, n_d, item_size=4)
    else:  # KDBI
        return _parse_binary_matrix(data_bytes, n_u, n_d, item_size=8)


def _parse_ascii_matrix(
    data_bytes: bytes,
    n_u: int,
    n_d: int,
    field_width: int = 10,
) -> np.ndarray:
    """Parse LRFI (10-char fields) or LDFI (20-char fields) ASCII data section.

    Values are fixed-width: each field is exactly *field_width* characters.
    Adjacent negative values are not space-separated, so whitespace-splitting
    fails — we must read fixed-width chunks per record line.

    The IPLOS "long format" puts each data row in one or more 80-char records,
    wrapping if n_d × field_width > 80.

    If *n_u* == 0, the number of rows is auto-detected from the data.
    """
    text = data_bytes.decode("latin-1", errors="replace")
    lines = [ln.rstrip("\r\n") for ln in text.splitlines()]
    # Filter out blank lines for counting purposes
    non_blank = [ln for ln in lines if ln.strip()]

    n_per_line = max(1, 80 // field_width)   # columns per 80-char record
    # Records needed per data row
    n_lines_per_row = max(1, math.ceil(n_d / n_per_line))

    if n_u == 0:
        # Auto-detect: each data row spans n_lines_per_row records
        n_u = max(1, len(non_blank) // n_lines_per_row)

    nan_set = _NAN_TOKENS
    values: list[float] = []
    line_idx = 0

    for _ in range(n_u):
        row_vals: list[float] = []
        remaining = n_d

        while remaining > 0 and line_idx < len(lines):
            ln = lines[line_idx]
            line_idx += 1

            # Skip blank lines
            if not ln.strip():
                continue

            # How many fields in this record?
            n_this = min(remaining, n_per_line)

            pos = 0
            for _ in range(n_this):
                chunk = ln[pos: pos + field_width]
                token = chunk.strip()
                if token.lower() in nan_set:
                    row_vals.append(float("nan"))
                else:
                    try:
                        row_vals.append(float(token))
                    except ValueError:
                        row_vals.append(float("nan"))
                pos += field_width

            remaining -= n_this

        # Pad row if not enough fields
        while len(row_vals) < n_d:
            row_vals.append(float("nan"))
        values.extend(row_vals[:n_d])

    # Pad if needed
    n_total = n_u * n_d
    while len(values) < n_total:
        values.append(float("nan"))

    return np.array(values[:n_total], dtype=np.float64).reshape(n_u, n_d)


def _parse_binary_matrix(
    data_bytes: bytes,
    n_u: int,
    n_d: int,
    item_size: int,
) -> np.ndarray:
    """Parse KRBI / KDBI binary data section.

    IEEE big-endian, 80-byte records.
    KRBI: 4-byte float, 20 per record
    KDBI: 8-byte double, 10 per record

    If *n_u* == 0, the number of rows is auto-detected from the data.
    """
    n_per_record = 80 // item_size
    fmt_char = "f" if item_size == 4 else "d"

    # Auto-detect n_u from file size
    n_records = len(data_bytes) // 80
    total_values = n_records * n_per_record
    if n_u == 0:
        n_u = max(1, total_values // n_d) if n_d > 0 else 1

    total_items = n_u * n_d
    values: list[float] = []
    offset = 0

    while len(values) < total_items and offset + item_size <= len(data_bytes):
        chunk = data_bytes[offset: offset + item_size]
        offset += item_size
        if _check_nan_pattern(chunk, item_size):
            values.append(float("nan"))
        else:
            (v,) = struct.unpack(f">{fmt_char}", chunk)
            values.append(float(v))

    # Pad if needed
    while len(values) < total_items:
        values.append(float("nan"))

    return np.array(values[:total_items], dtype=np.float64).reshape(n_u, n_d)


def _check_nan_pattern(chunk: bytes, item_size: int) -> bool:
    """Return True if the bytes represent a NaN (any kind)."""
    if item_size == 4:
        bits = struct.unpack(">I", chunk)[0]
        exp = (bits >> 23) & 0xFF
        mant = bits & 0x7FFFFF
        return exp == 0xFF and mant != 0
    else:
        bits = struct.unpack(">Q", chunk)[0]
        exp = (bits >> 52) & 0x7FF
        mant = bits & 0x000FFFFFFFFFFFFF
        return exp == 0x7FF and mant != 0


def _is_little_endian() -> bool:
    return struct.pack("H", 1) == b"\x01\x00"
