"""Pure evaluation functions operating on CRGDataset arrays.

These are internal helpers called by ContactPoint.  They do not cache state;
all statefulness (history, options) lives in ContactPoint.
"""

from __future__ import annotations

import math
from collections import deque
from typing import TYPE_CHECKING

import numpy as np

from ._types import BorderMode, RefLineContinue, CurvMode, EvalOptions

if TYPE_CHECKING:
    from ._dataset import CRGDataset

_MAX_BORDER_ERR = 1.0e-8  # tolerance for numeric inaccuracies near border [m]


# ---------------------------------------------------------------------------
# Internal helper: clip u for closed reference lines
# ---------------------------------------------------------------------------

def _clip_u_closed(ds: "CRGDataset", opts: EvalOptions, u: float) -> float:
    """Wrap u into [u_close_min, u_close_max] if refline is closed."""
    if not ds.u_is_closed:
        return u
    if opts.ref_line_continue != RefLineContinue.CLOSE_TRACK:
        return u
    u_range = ds.u_close_max - ds.u_close_min
    if u_range <= 0:
        return u
    return ds.u_close_min + math.fmod(u - ds.u_close_min, u_range) % u_range


# ---------------------------------------------------------------------------
# _eval_uv_to_z
# ---------------------------------------------------------------------------

def _eval_uv_to_z(
    ds: "CRGDataset",
    opts: EvalOptions,
    u: float,
    v: float,
) -> float:
    """Bilinear elevation interpolation at road coordinate (u, v).

    Port of ``crgDataEvaluv2z`` in crgEvalz.c.
    Returns NaN on NONE-mode boundary violation instead of raising, so callers
    can distinguish refusals from real errors.
    """
    n_u = ds.n_u
    n_v = ds.n_v

    u = _clip_u_closed(ds, opts, u)

    # ---- u direction -------------------------------------------------------
    frac_u = (u - ds.u_min) / ds.u_inc
    in_core_u = True
    z_offset = 0.0
    calc_value = True
    calc_bank = True
    calc_smooth_base = 0  # 0=no, 1=begin, 2=end

    if u < ds.u_min or u > ds.u_max:
        in_core_u = False
        bm_u = opts.border_mode_u

        if bm_u == BorderMode.NONE:
            return float("nan")
        elif bm_u == BorderMode.EX_KEEP:
            if frac_u < 0.0:
                frac_u = 0.0
                calc_smooth_base = 1
            else:
                calc_smooth_base = 2
        elif bm_u == BorderMode.EX_ZERO:
            calc_value = False
            calc_bank = False
            calc_smooth_base = 1 if frac_u < 0.0 else 2
        elif bm_u == BorderMode.REPEAT:
            max_frac = (ds.u_max - ds.u_min) / ds.u_inc
            frac_u = math.fmod((u - ds.u_min) / ds.u_inc, max_frac)
            if frac_u < 0.0:
                frac_u += max_frac
            u = ds.u_min + frac_u * ds.u_inc
            in_core_u = True
        elif bm_u == BorderMode.REFLECT:
            u_size = ds.u_max - ds.u_min
            max_frac = u_size / ds.u_inc
            rep_seq = int((u - ds.u_min) / u_size)
            revert = abs(rep_seq) % 2
            frac_u = abs(frac_u) - abs(rep_seq) * max_frac
            if revert:
                frac_u = max_frac - frac_u
            u = ds.u_min + frac_u * ds.u_inc
            in_core_u = True

        z_offset += opts.border_offset_u

    # clamp and compute idx_u
    if frac_u < 0.0:
        frac_u = 0.0
    idx_u = int(frac_u)
    if idx_u >= n_u - 1:
        idx_u = n_u - 2
        frac_u = 1.0
    else:
        frac_u -= idx_u

    # ---- v direction -------------------------------------------------------
    in_core_v = True

    if ds.v_equally_spaced:
        frac_v = (v - ds.v_min) / ds.v_inc
        calc_index_v = True

        if v < ds.v_min or v > ds.v_max:
            in_core_v = False
            bm_v = opts.border_mode_v

            if bm_v == BorderMode.NONE:
                return float("nan")
            elif bm_v == BorderMode.EX_KEEP:
                if frac_v < 0.0:
                    frac_v = 0.0
                    calc_index_v = False
                # frac_v > 1 handled by index clamp
            elif bm_v == BorderMode.EX_ZERO:
                calc_value = False
            elif bm_v == BorderMode.REPEAT:
                v_size = ds.v_max - ds.v_min
                max_frac = v_size / ds.v_inc
                frac_v = math.fmod((v - ds.v_min) / ds.v_inc, max_frac)
                if frac_v < 0.0:
                    frac_v += max_frac
                v = ds.v_min + frac_v * ds.v_inc
                in_core_v = True
            elif bm_v == BorderMode.REFLECT:
                v_size = ds.v_max - ds.v_min
                max_frac = v_size / ds.v_inc
                rep_seq = int((v - ds.v_min) / v_size)
                revert = abs(rep_seq) % 2
                frac_v = abs(frac_v) - abs(rep_seq) * max_frac
                if revert:
                    frac_v = max_frac - frac_v
                v = ds.v_min + frac_v * ds.v_inc
                in_core_v = True

            z_offset += opts.border_offset_v

        if calc_index_v:
            if frac_v < 0.0:
                frac_v = 0.0
            idx_v = int(frac_v)
            if idx_v >= n_v - 1:
                idx_v = n_v - 2
                frac_v = 1.0
            else:
                frac_v -= idx_v
        else:
            idx_v = 0

    else:
        # non-equally spaced v: binary search via numpy
        v_pos = v
        bm_v = opts.border_mode_v

        if v_pos < ds.v_min or v_pos > ds.v_max:
            in_core_v = False

            if abs(v_pos - ds.v_min) < _MAX_BORDER_ERR:
                v_pos = ds.v_min
            elif abs(v_pos - ds.v_max) < _MAX_BORDER_ERR:
                v_pos = ds.v_max
            else:
                if bm_v == BorderMode.NONE:
                    return float("nan")
                elif bm_v == BorderMode.EX_ZERO:
                    calc_value = False
                elif bm_v == BorderMode.REPEAT:
                    v_range = ds.v_max - ds.v_min
                    if v_pos > ds.v_max:
                        v_pos = ds.v_min + math.fmod(v_pos - ds.v_max, v_range)
                    else:
                        v_pos = ds.v_max + math.fmod(v_pos - ds.v_min, v_range)
                    in_core_v = True
                elif bm_v == BorderMode.REFLECT:
                    v_range = ds.v_max - ds.v_min
                    if v_pos > ds.v_max:
                        remainder = math.fmod(v_pos - ds.v_max, v_range)
                        rep_seq = int((v_pos - ds.v_max) / v_range)
                        revert = not (abs(rep_seq) % 2)
                        v_pos = (ds.v_max - remainder) if revert else (ds.v_min + remainder)
                    else:
                        remainder = math.fmod(v_pos - ds.v_min, v_range)
                        rep_seq = int((v_pos - ds.v_min) / v_range)
                        revert = abs(rep_seq) % 2
                        v_pos = (ds.v_max + remainder) if revert else (ds.v_min - remainder)
                    in_core_v = True

            z_offset += opts.border_offset_v

        idx_v = int(np.searchsorted(ds.v, v_pos, side="right")) - 1
        idx_v = max(0, min(idx_v, n_v - 2))
        dv = ds.v[idx_v + 1] - ds.v[idx_v]
        frac_v = (v_pos - ds.v[idx_v]) / dv if dv > 0 else 0.0
        frac_v = max(0.0, min(1.0, frac_v))

    # ---- bilinear interpolation on z grid ----------------------------------
    z = 0.0
    if calc_value:
        z00 = float(ds.z[idx_v,     idx_u])
        z10 = float(ds.z[idx_v,     idx_u + 1]) - z00
        z01 = float(ds.z[idx_v + 1, idx_u])
        z11 = float(ds.z[idx_v + 1, idx_u + 1]) - (z10 + z01)
        z01 -= z00
        z = (z11 * frac_v + z10) * frac_u + z01 * frac_v + z00
        z += ds.z_mean[idx_v]  # de-normalise

    # ---- add reference line elevation --------------------------------------
    if ds.ref_z is not None:
        if len(ds.ref_z) > 1:
            ref_idx = min(idx_u, len(ds.ref_z) - 2)
            ref_frac = frac_u
            z += float(ds.ref_z[ref_idx]) + ref_frac * float(
                ds.ref_z[ref_idx + 1] - ds.ref_z[ref_idx]
            )
        else:
            z += float(ds.ref_z[0])

    # ---- banking -----------------------------------------------------------
    if ds.has_bank and calc_bank and ds.bank is not None:
        v_bank = max(ds.v_min, min(ds.v_max, v))
        if len(ds.bank) > 1:
            bank_idx = min(idx_u, len(ds.bank) - 2)
            bank = float(ds.bank[bank_idx]) + frac_u * float(
                ds.bank[bank_idx + 1] - ds.bank[bank_idx]
            )
        else:
            bank = float(ds.bank[0])
        z += bank * v_bank

    # ---- apply border offsets ----------------------------------------------
    if frac_u < 0.0:
        frac_u = 0.0
    elif frac_u > 1.0:
        frac_u = 1.0

    if not in_core_u:
        bm_u = opts.border_mode_u
        if bm_u == BorderMode.EX_ZERO:
            z = z_offset
        elif bm_u == BorderMode.EX_KEEP:
            z += z_offset
    elif not in_core_v:
        bm_v = opts.border_mode_v
        if bm_v == BorderMode.EX_ZERO:
            z = z_offset
        elif bm_v == BorderMode.EX_KEEP:
            z += z_offset

    # ---- smoothing ---------------------------------------------------------
    smooth_scale = 1.0
    smooth_base = 0.0
    calc_smooth = False

    if opts.smooth_u_begin is not None or opts.smooth_u_end is not None:
        if in_core_u or calc_smooth_base:
            if opts.smooth_u_begin is not None:
                sz = opts.smooth_u_begin
                if (u - ds.u_min) <= sz:
                    smooth_scale = 0.0 if u < ds.u_min else (u - ds.u_min) / sz
                    calc_smooth_base = 1
                    calc_smooth = True
            if opts.smooth_u_end is not None:
                sz = opts.smooth_u_end
                if (ds.u_max - u) <= sz:
                    smooth_scale = 0.0 if u > ds.u_max else (ds.u_max - u) / sz
                    calc_smooth_base = 2
                    calc_smooth = True

        if calc_smooth_base == 1:
            if ds.ref_z is not None and len(ds.ref_z) > 0:
                smooth_base += float(ds.ref_z[0])
        elif calc_smooth_base == 2:
            if ds.ref_z is not None and len(ds.ref_z) > 0:
                smooth_base += float(ds.ref_z[-1])

    if calc_smooth:
        z = smooth_base + (z - smooth_base) * smooth_scale

    return z


# ---------------------------------------------------------------------------
# _eval_uv_to_xy
# ---------------------------------------------------------------------------

def _eval_uv_to_xy(
    ds: "CRGDataset",
    opts: EvalOptions,
    u: float,
    v: float,
) -> tuple[float, float]:
    """Convert road (u, v) to Cartesian (x, y).

    Port of ``crgDataEvaluv2xy`` in crgEvaluv2xy.c.
    """
    # Fallback: identity (no reference line)
    if ds.x is None or len(ds.x) == 0:
        return u, v

    u = _clip_u_closed(ds, opts, u)

    frac = (u - ds.u_min) / ds.u_inc
    n = ds.n_u

    if frac < 0.0:
        # extrapolate before start
        du = frac * ds.u_inc
        x = float(ds.x[0]) + du * ds.phi_first_cos - v * ds.phi_first_sin
        y = float(ds.y[0]) + du * ds.phi_first_sin + v * ds.phi_first_cos
        return x, y

    index = int(frac)
    if index >= n - 1:
        # extrapolate beyond end
        du = (frac - (n - 1)) * ds.u_inc
        x = float(ds.x[-1]) + du * ds.phi_last_cos - v * ds.phi_last_sin
        y = float(ds.y[-1]) + du * ds.phi_last_sin + v * ds.phi_last_cos
        return x, y

    frac -= index  # remaining fraction within segment [0, 1)

    p1 = np.array([ds.x[index],     ds.y[index]])
    p2 = np.array([ds.x[index + 1], ds.y[index + 1]])

    # normal on P1→P2 (rotate 90° CCW)
    d12 = p2 - p1
    n12 = np.array([-d12[1], d12[0]])
    length = math.sqrt(n12[0] ** 2 + n12[1] ** 2)
    if length > 1e-10:
        n12 /= length

    # normal n1 at P1 (use P0 if available)
    n1 = n12.copy()
    if index > 0:
        p0 = np.array([ds.x[index - 1], ds.y[index - 1]])
        d02 = p2 - p0
        n1 = np.array([-d02[1], d02[0]])
        length = math.sqrt(n1[0] ** 2 + n1[1] ** 2)
        if length > 1e-10:
            n1 /= length
    dot = n1[0] * n12[0] + n1[1] * n12[1]
    if abs(dot) > 1e-10:
        n1 /= dot
    A = p1 + v * n1

    # normal n2 at P2 (use P3 if available)
    n2 = n12.copy()
    if index < n - 2:
        p3 = np.array([ds.x[index + 2], ds.y[index + 2]])
        d13 = p3 - p1
        n2 = np.array([-d13[1], d13[0]])
        length = math.sqrt(n2[0] ** 2 + n2[1] ** 2)
        if length > 1e-10:
            n2 /= length
    dot = n2[0] * n12[0] + n2[1] * n12[1]
    if abs(dot) > 1e-10:
        n2 /= dot
    B = p2 + v * n2

    result = A + frac * (B - A)
    return float(result[0]), float(result[1])


# ---------------------------------------------------------------------------
# _xy_to_uv  (dot-product walk)
# ---------------------------------------------------------------------------

def _xy_to_uv(
    ds: "CRGDataset",
    opts: EvalOptions,
    x: float,
    y: float,
    history: deque,
) -> tuple[float, float]:
    """Convert Cartesian (x, y) to road (u, v).

    Port of ``crgEvalxy2uv`` in crgEvalxy2uv.c.
    Uses a history deque for warm starts on successive nearby queries.
    """
    n = ds.n_u
    X = ds.x
    Y = ds.y

    # close / far thresholds for history lookup
    u_inc = ds.u_inc
    close_dist2 = (10.0 * u_inc) ** 2
    far_dist2   = (100.0 * u_inc) ** 2

    # --- seed index from history ---
    index_min = -1
    best_dist2 = float("inf")
    for (hx, hy, hi) in history:
        d2 = (x - hx) ** 2 + (y - hy) ** 2
        if d2 < close_dist2:
            index_min = hi
            break
        if d2 < far_dist2 and d2 < best_dist2:
            best_dist2 = d2
            index_min = hi

    if index_min < 0:
        # global scan: every 10 points
        best_dist2 = float("inf")
        for i in range(0, n, 10):
            d2 = (x - float(X[i])) ** 2 + (y - float(Y[i])) ** 2
            if d2 < best_dist2:
                best_dist2 = d2
                index_min = i
        # also check last point
        d2 = (x - float(X[-1])) ** 2 + (y - float(Y[-1])) ** 2
        if d2 < best_dist2:
            index_min = n - 1

    # ensure index_min >= 1 so we can look back
    if index_min < 1:
        index_min = 1
    elif index_min > n - 1:
        index_min = n - 1

    # --- forward walk ---
    while True:
        ip1 = min(index_min + 1, n - 1)
        im1 = max(index_min - 1, 0)
        dot = ((x - float(X[index_min])) * (float(X[ip1]) - float(X[im1])) +
               (y - float(Y[index_min])) * (float(Y[ip1]) - float(Y[im1])))
        if dot > 0 and index_min < n - 1:
            index_min += 1
        else:
            break

    # --- backward walk ---
    while True:
        im1 = max(index_min - 1, 0)
        im2 = max(index_min - 2, 0)
        dot = ((x - float(X[im1])) * (float(X[index_min]) - float(X[im2])) +
               (y - float(Y[im1])) * (float(Y[index_min]) - float(Y[im2])))
        if dot < 0 and index_min > 1:
            index_min -= 1
        else:
            break

    # --- compute v (perpendicular distance) ---
    i0 = index_min - 1
    i1 = index_min
    dx_seg = float(X[i1]) - float(X[i0])
    dy_seg = float(Y[i1]) - float(Y[i0])
    seg_len = math.sqrt(dx_seg ** 2 + dy_seg ** 2)

    if seg_len < 1e-12:
        v_res = 0.0
        u_frac = 0.0
    else:
        # cross product gives signed lateral distance
        v_res = (dx_seg * (y - float(Y[i0])) - dy_seg * (x - float(X[i0]))) / seg_len
        # dot product gives longitudinal fraction in segment
        u_frac = (dx_seg * (x - float(X[i0])) + dy_seg * (y - float(Y[i0]))) / (seg_len ** 2)
        u_frac = max(0.0, min(1.0, u_frac))

    u_res = ds.u_min + i0 * ds.u_inc + u_frac * ds.u_inc

    # --- out-of-range extrapolation ---
    if u_res < ds.u_min:
        # project onto first tangent
        v_res = -(ds.phi_first_sin * (x - float(X[0])) - ds.phi_first_cos * (y - float(Y[0])))
    elif u_res > ds.u_max:
        v_res = -(ds.phi_last_sin * (x - float(X[-1])) - ds.phi_last_cos * (y - float(Y[-1])))

    # --- update history ---
    history.appendleft((x, y, index_min))

    return u_res, v_res


# ---------------------------------------------------------------------------
# _eval_uv_to_pk
# ---------------------------------------------------------------------------

def _eval_uv_to_pk(
    ds: "CRGDataset",
    opts: EvalOptions,
    u: float,
    v: float,
) -> tuple[float, float]:
    """Return (heading phi [rad], curvature [1/m]) at road (u, v).

    Port of ``crgDataEvaluv2pk`` in crgEvalpk.c.
    """
    u = _clip_u_closed(ds, opts, u)

    n = ds.n_u
    frac = (u - ds.u_min) / ds.u_inc

    if frac < 0.0:
        index = 0
    else:
        index = int(frac)
        if index >= n - 1:
            index = n - 2

    frac = frac - index
    frac = max(0.0, min(1.0, frac))

    # --- heading phi: linear interpolation of phi channel ---
    phi = float(ds.phi[index]) + frac * float(ds.phi[index + 1] - ds.phi[index])

    # --- curvature: d(phi)/du ---
    if n < 2:
        curv = 0.0
    elif index == 0:
        dphi = float(ds.phi[1] - ds.phi[0])
        curv = dphi / ds.u_inc
    elif index >= n - 2:
        dphi = float(ds.phi[n - 1] - ds.phi[n - 2])
        curv = dphi / ds.u_inc
    else:
        dphi = float(ds.phi[index + 1] - ds.phi[index - 1])
        curv = dphi / (2.0 * ds.u_inc)

    # --- lateral curvature adjustment ---
    if opts.curv_mode == CurvMode.LATERAL and abs(curv * v) < 1.0:
        # adjust curvature for off-axis position
        curv = curv / (1.0 - curv * v)

    return phi, curv
