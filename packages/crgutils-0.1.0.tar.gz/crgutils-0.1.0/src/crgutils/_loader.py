"""Load a .crg (IPLOS) file into a CRGDataset.

Supports text formats LRFI / LDFI and binary formats KRBI / KDBI.
"""

from __future__ import annotations

# Implementation in Phase 2 & 3
from pathlib import Path
from ._dataset import CRGDataset


def load(path: str | Path) -> CRGDataset:
    """Load a .crg file and return a :class:`CRGDataset`.

    Parameters
    ----------
    path:
        Absolute or relative path to a ``.crg`` file.

    Returns
    -------
    CRGDataset
        Parsed dataset.  Modifiers embedded in the file header are stored in
        ``dataset.pending_modifiers`` and are **not** applied automatically;
        call :func:`~crgutils.apply_modifiers` if desired.
    """
    from ._loader_impl import _load_impl
    return _load_impl(Path(path))
