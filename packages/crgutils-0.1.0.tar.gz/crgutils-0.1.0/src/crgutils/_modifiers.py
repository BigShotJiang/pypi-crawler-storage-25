"""Apply modifiers to a CRGDataset in-place.

Modifiers are applied once and then discarded (matching C semantics from
``crgDataSetModifiersApply``).  They transform the raw data arrays so that
all subsequent evaluations use the modified geometry.
"""

from __future__ import annotations

import math
import numpy as np

from ._dataset import CRGDataset
from ._types import GridNaNMode


def apply_modifiers(
    dataset: CRGDataset,
    *,
    # ---- scale modifiers ----
    scale_z:           float | None = None,
    scale_slope:       float | None = None,
    scale_bank:        float | None = None,
    scale_length:      float | None = None,
    scale_width:       float | None = None,
    scale_curvature:   float | None = None,
    # ---- NaN handling ----
    grid_nan_mode:     int | str | GridNaNMode = GridNaNMode.KEEP_LAST,
    grid_nan_offset:   float = 0.0,
    # ---- repositioning by reference point ----
    ref_point_u:       float | None = None,
    ref_point_u_frac:  float | None = None,
    ref_point_u_offset:float | None = None,
    ref_point_v:       float | None = None,
    ref_point_v_frac:  float | None = None,
    ref_point_v_offset:float | None = None,
    ref_point_x:       float | None = None,
    ref_point_y:       float | None = None,
    ref_point_z:       float | None = None,
    ref_point_phi:     float | None = None,
    # ---- reference line offsets / rotation ----
    ref_line_offset_x:   float = 0.0,
    ref_line_offset_y:   float = 0.0,
    ref_line_offset_z:   float = 0.0,
    ref_line_offset_phi: float = 0.0,
    ref_line_rot_center_x: float = 0.0,
    ref_line_rot_center_y: float = 0.0,
) -> CRGDataset:
    """Apply modifiers in-place to *dataset* and return it.

    Only the explicitly provided keyword arguments are applied.  This mirrors
    the C convention where modifiers are applied once and then removed.

    Parameters
    ----------
    dataset:
        Dataset to modify in-place.
    scale_z:
        Multiply all elevation grid values by this factor.
    scale_slope:
        Multiply slope channel values.
    scale_bank:
        Multiply banking channel values.
    scale_length:
        Stretch u axis (and ref line) by this factor.
    scale_width:
        Stretch v axis by this factor.
    scale_curvature:
        Scale the curvature of the reference line.
    grid_nan_mode:
        How NaN values in the z grid are treated: ``"keep"``, ``"set_zero"``,
        ``"keep_last"`` (or integer 0/1/2).
    grid_nan_offset:
        Offset applied to formerly-NaN cells.
    ref_point_u / ref_point_u_frac / ref_point_u_offset:
        Specify the "from" u position of the reference point
        (absolute u, fractional, or fractional + offset).
    ref_point_v / ref_point_v_frac / ref_point_v_offset:
        "From" v position.
    ref_point_x / ref_point_y / ref_point_z / ref_point_phi:
        Target world position / heading for the reference point.
    ref_line_offset_x/y/z/phi:
        Direct translation / rotation of the whole reference line.
    ref_line_rot_center_x/y:
        Rotation center for ref_line_offset_phi.

    Returns
    -------
    CRGDataset
        The same *dataset* object (for chaining).
    """
    # --- scale z grid ---
    if scale_z is not None and scale_z != 1.0:
        z64 = dataset.z.astype(np.float64)
        # de-normalise, scale, re-normalise
        z64 = (z64 + dataset.z_mean[:, np.newaxis]) * scale_z
        dataset.z_mean[:] = z64.mean(axis=1)
        dataset.z = (z64 - dataset.z_mean[:, np.newaxis]).astype(np.float32)

    # --- scale slope ---
    if scale_slope is not None and scale_slope != 1.0 and dataset.slope is not None:
        dataset.slope = dataset.slope * scale_slope

    # --- scale bank ---
    if scale_bank is not None and scale_bank != 1.0 and dataset.bank is not None:
        dataset.bank = dataset.bank * scale_bank

    # --- scale length (u axis) ---
    if scale_length is not None and scale_length != 1.0:
        dataset.u = dataset.u * scale_length
        dataset.x = dataset.x * scale_length  # approximate for straight lines
        dataset.u_inc = dataset.u_inc * scale_length
        # recompute u-derived fields
        _recompute_utility(dataset)

    # --- scale width (v axis) ---
    if scale_width is not None and scale_width != 1.0:
        dataset.v = dataset.v * scale_width
        dataset.v_inc = dataset.v_inc * scale_width

    # --- scale curvature ---
    if scale_curvature is not None and scale_curvature != 1.0:
        _scale_curvature(dataset, scale_curvature)

    # --- NaN handling ---
    _apply_nan_mode(dataset, grid_nan_mode, grid_nan_offset)

    # --- repositioning ---
    needs_transform = any(p is not None for p in (
        ref_point_u, ref_point_u_frac, ref_point_x, ref_point_y, ref_point_phi
    ))
    has_offset = (ref_line_offset_x != 0.0 or ref_line_offset_y != 0.0
                  or ref_line_offset_z != 0.0 or ref_line_offset_phi != 0.0)

    if needs_transform or has_offset:
        _apply_transform(
            dataset,
            ref_point_u=ref_point_u,
            ref_point_u_frac=ref_point_u_frac,
            ref_point_u_offset=ref_point_u_offset,
            ref_point_v=ref_point_v,
            ref_point_v_frac=ref_point_v_frac,
            ref_point_v_offset=ref_point_v_offset,
            ref_point_x=ref_point_x,
            ref_point_y=ref_point_y,
            ref_point_z=ref_point_z,
            ref_point_phi=ref_point_phi,
            ref_line_offset_x=ref_line_offset_x,
            ref_line_offset_y=ref_line_offset_y,
            ref_line_offset_z=ref_line_offset_z,
            ref_line_offset_phi=ref_line_offset_phi,
            ref_line_rot_center_x=ref_line_rot_center_x,
            ref_line_rot_center_y=ref_line_rot_center_y,
        )

    return dataset


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _apply_nan_mode(
    dataset: CRGDataset,
    mode: int | str | GridNaNMode,
    offset: float,
) -> None:
    if isinstance(mode, str):
        mode = {"keep": GridNaNMode.KEEP, "set_zero": GridNaNMode.SET_ZERO,
                "keep_last": GridNaNMode.KEEP_LAST}[mode.lower()]
    mode = GridNaNMode(int(mode))

    if mode == GridNaNMode.KEEP and offset == 0.0:
        return

    z64 = dataset.z.astype(np.float64) + dataset.z_mean[:, np.newaxis]
    nan_mask = np.isnan(z64)

    if not nan_mask.any():
        return

    if mode == GridNaNMode.SET_ZERO:
        z64[nan_mask] = 0.0 + offset
    elif mode == GridNaNMode.KEEP_LAST:
        # Replace each NaN column-wise with the last valid value on the same v row
        for iv in range(dataset.n_v):
            row = z64[iv]
            last_valid = 0.0
            for iu in range(dataset.n_u):
                if np.isnan(row[iu]):
                    row[iu] = last_valid + offset
                else:
                    last_valid = row[iu]
    elif mode == GridNaNMode.KEEP:
        z64[nan_mask] += offset

    dataset.z_mean = z64.mean(axis=1)
    dataset.z = (z64 - dataset.z_mean[:, np.newaxis]).astype(np.float32)


def _scale_curvature(dataset: CRGDataset, factor: float) -> None:
    """Scale reference line curvature by integrating a scaled phi."""
    if dataset.n_u < 2:
        return
    # curvature = d(phi)/du; scale it by reintegrating
    phi = dataset.phi.copy()
    phi0 = float(phi[0])
    dphi = np.diff(phi)
    dphi_scaled = dphi * factor
    phi_new = np.concatenate([[phi0], phi0 + np.cumsum(dphi_scaled)])
    dataset.phi = phi_new

    # Recompute x, y from new phi
    x = np.empty(dataset.n_u)
    y = np.empty(dataset.n_u)
    x[0] = float(dataset.x[0])
    y[0] = float(dataset.y[0])
    for i in range(1, dataset.n_u):
        ph = float(phi_new[i - 1])
        x[i] = x[i - 1] + dataset.u_inc * math.cos(ph)
        y[i] = y[i - 1] + dataset.u_inc * math.sin(ph)
    dataset.x = x
    dataset.y = y
    _recompute_utility(dataset)


def _apply_transform(
    dataset: CRGDataset,
    *,
    ref_point_u,
    ref_point_u_frac,
    ref_point_u_offset,
    ref_point_v,
    ref_point_v_frac,
    ref_point_v_offset,
    ref_point_x,
    ref_point_y,
    ref_point_z,
    ref_point_phi,
    ref_line_offset_x,
    ref_line_offset_y,
    ref_line_offset_z,
    ref_line_offset_phi,
    ref_line_rot_center_x,
    ref_line_rot_center_y,
) -> None:
    """Reposition and/or rotate the reference line."""
    from ._eval import _eval_uv_to_xy, _eval_uv_to_pk
    from ._types import EvalOptions

    opts = EvalOptions()

    # --- resolve "from" u position ---
    u_pos = dataset.u_min  # default
    if ref_point_u is not None:
        u_pos = ref_point_u
    elif ref_point_u_frac is not None:
        u_pos = dataset.u_min + ref_point_u_frac * (dataset.u_max - dataset.u_min)
        if ref_point_u_offset is not None:
            u_pos += ref_point_u_offset

    # --- resolve "from" v position ---
    v_pos = 0.0
    if ref_point_v is not None:
        v_pos = ref_point_v
    elif ref_point_v_frac is not None:
        v_pos = dataset.v_min + ref_point_v_frac * (dataset.v_max - dataset.v_min)
        if ref_point_v_offset is not None:
            v_pos += ref_point_v_offset

    # --- get current position and heading at "from" point ---
    from_x, from_y = _eval_uv_to_xy(dataset, opts, u_pos, v_pos)
    from_phi, _ = _eval_uv_to_pk(dataset, opts, u_pos, v_pos)

    # --- determine target position / heading ---
    to_x   = ref_point_x   if ref_point_x   is not None else from_x
    to_y   = ref_point_y   if ref_point_y   is not None else from_y
    to_phi = ref_point_phi if ref_point_phi is not None else from_phi

    # --- compute rotation needed to align from_phi → to_phi ---
    rot_angle = to_phi - from_phi + ref_line_offset_phi

    # --- rotate all reference line points around rot_center ---
    cx = ref_line_rot_center_x
    cy = ref_line_rot_center_y
    cos_a = math.cos(rot_angle)
    sin_a = math.sin(rot_angle)

    x_new = dataset.x.copy().astype(float)
    y_new = dataset.y.copy().astype(float)

    dx = x_new - cx
    dy = y_new - cy
    x_new = cx + dx * cos_a - dy * sin_a
    y_new = cy + dx * sin_a + dy * cos_a

    # --- translate: move rotated "from" point to "to" position ---
    # compute where "from" ended up after rotation
    dx_f = from_x - cx
    dy_f = from_y - cy
    rot_from_x = cx + dx_f * cos_a - dy_f * sin_a
    rot_from_y = cy + dx_f * sin_a + dy_f * cos_a

    # C API semantics: ref_line_offset_x/y are added to the target position
    tx = to_x + ref_line_offset_x - rot_from_x
    ty = to_y + ref_line_offset_y - rot_from_y

    x_new += tx
    y_new += ty

    dataset.x = x_new
    dataset.y = y_new

    # --- apply ref line z offset ---
    if ref_line_offset_z != 0.0 and dataset.ref_z is not None:
        dataset.ref_z = dataset.ref_z + ref_line_offset_z

    # --- recompute phi from new x/y ---
    phi_new = np.empty(dataset.n_u)
    for i in range(dataset.n_u - 1):
        dx_i = x_new[i + 1] - x_new[i]
        dy_i = y_new[i + 1] - y_new[i]
        phi_new[i] = math.atan2(dy_i, dx_i)
    phi_new[-1] = phi_new[-2] if dataset.n_u > 1 else 0.0
    dataset.phi = phi_new

    _recompute_utility(dataset)


def _recompute_utility(dataset: CRGDataset) -> None:
    """Recompute precomputed trig / utility fields after geometry change."""
    if dataset.n_u < 2:
        return
    dataset.phi_first_sin = math.sin(float(dataset.phi[0]))
    dataset.phi_first_cos = math.cos(float(dataset.phi[0]))
    dataset.phi_last_sin  = math.sin(float(dataset.phi[-1]))
    dataset.phi_last_cos  = math.cos(float(dataset.phi[-1]))


def apply_pending_modifiers(dataset: CRGDataset) -> None:
    """Apply modifiers stored in ``dataset.pending_modifiers`` in-place."""
    if not dataset.pending_modifiers:
        return
    apply_modifiers(dataset, **dataset.pending_modifiers)
    dataset.pending_modifiers.clear()
