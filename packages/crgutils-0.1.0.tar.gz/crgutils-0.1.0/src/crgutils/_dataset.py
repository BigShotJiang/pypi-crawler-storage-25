"""CRGDataset: the core data container for a loaded .crg file."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ._contact_point import ContactPoint
    from ._types import BorderMode, CurvMode, RefLineContinue

import numpy as np


@dataclass
class CRGDataset:
    """Holds all arrays and metadata parsed from a single .crg file.

    Coordinate system
    -----------------
    u  — arc-length along the reference line [m]
    v  — lateral offset from the reference line [m]
    x, y — Cartesian world coordinates of the reference line [m]
    phi  — heading angle of the reference line [rad]
    z  — elevation grid, shape (n_v, n_u) [m], float32

    All arrays are stored in increasing u / v order.
    """

    # --- Reference line (all float64, shape (n_u,)) ---
    u:   np.ndarray   # u coordinates
    x:   np.ndarray   # Cartesian x of ref line (derived from phi if absent)
    y:   np.ndarray   # Cartesian y of ref line
    phi: np.ndarray   # heading angles [rad]

    # --- Cross-section grid ---
    v: np.ndarray     # v positions, shape (n_v,), float64
    z: np.ndarray     # elevation grid, shape (n_v, n_u), float32
    z_mean: np.ndarray  # per-v-channel mean subtracted during normalisation, (n_v,)

    # --- Optional reference line channels (shape (n_u,) or scalar) ---
    ref_z: np.ndarray | None   # ref line elevation [m]
    bank:  np.ndarray | None   # banking [1/m]  (tan of bank angle)
    slope: np.ndarray | None   # slope [1]

    # --- Grid spacing / topology ---
    u_inc:             float
    v_inc:             float = 0.0   # 0 if v is non-equally spaced
    u_is_closed:       bool  = False
    u_close_min:       float = 0.0
    u_close_max:       float = 0.0
    v_equally_spaced:  bool  = True
    has_bank:          bool  = False

    # --- Precomputed trigonometry for extrapolation ---
    phi_first_sin: float = 0.0
    phi_first_cos: float = 1.0
    phi_last_sin:  float = 0.0
    phi_last_cos:  float = 1.0

    # --- Options / modifiers embedded in the file header ---
    default_options:   dict[str, Any] = field(default_factory=dict)
    pending_modifiers: dict[str, Any] = field(default_factory=dict)

    # --- Source info (informational only) ---
    source_file: str = ""
    comment:     str = ""

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def u_min(self) -> float:
        return float(self.u[0])

    @property
    def u_max(self) -> float:
        return float(self.u[-1])

    @property
    def v_min(self) -> float:
        return float(self.v[0])

    @property
    def v_max(self) -> float:
        return float(self.v[-1])

    @property
    def u_range(self) -> tuple[float, float]:
        return (self.u_min, self.u_max)

    @property
    def v_range(self) -> tuple[float, float]:
        return (self.v_min, self.v_max)

    @property
    def shape(self) -> tuple[int, int]:
        """(n_v, n_u)"""
        return self.z.shape

    @property
    def n_u(self) -> int:
        return len(self.u)

    @property
    def n_v(self) -> int:
        return len(self.v)

    # ------------------------------------------------------------------
    # Human-readable summaries
    # ------------------------------------------------------------------

    def info(self) -> str:
        lines = [
            f"CRGDataset: {self.source_file}",
            f"  u range : [{self.u_min:.4f}, {self.u_max:.4f}] m  (n={self.n_u}, inc={self.u_inc:.4f})",
            f"  v range : [{self.v_min:.4f}, {self.v_max:.4f}] m  (n={self.n_v}"
            + (f", inc={self.v_inc:.4f})" if self.v_equally_spaced else ", irregular)"),
            f"  z shape : {self.z.shape}  (float32)",
            f"  has_bank: {self.has_bank}",
            f"  closed  : {self.u_is_closed}",
        ]
        return "\n".join(lines)

    def channel_info(self) -> str:
        n_channels = 1 + self.n_v  # U virtual + v channels
        if self.phi is not None and len(self.phi):
            n_channels += 1
        lines = [f"Channel count: {n_channels}"]
        lines.append(f"  U  : u coordinate, virtual, [{self.u_min:.4f}, {self.u_max:.4f}] m")
        if self.phi is not None and len(self.phi):
            lines.append(f"  phi: heading angle, [{float(self.phi.min()):.4f}, {float(self.phi.max()):.4f}] rad")
        for i, vpos in enumerate(self.v):
            zch = self.z[i]
            lines.append(
                f"  D{i+1} : v={vpos:+.4f} m, z in [{float(np.nanmin(zch)+self.z_mean[i]):.4f}, "
                f"{float(np.nanmax(zch)+self.z_mean[i]):.4f}] m"
            )
        return "\n".join(lines)

    def road_info(self) -> str:
        lines = [
            "Road information:",
            f"  reference line : u=[{self.u_min:.4f}, {self.u_max:.4f}] m",
            f"  x range        : [{float(self.x.min()):.4f}, {float(self.x.max()):.4f}] m",
            f"  y range        : [{float(self.y.min()):.4f}, {float(self.y.max()):.4f}] m",
            f"  phi range      : [{float(self.phi.min()):.4f}, {float(self.phi.max()):.4f}] rad",
            f"  v range        : [{self.v_min:.4f}, {self.v_max:.4f}] m",
        ]
        z_all = self.z.astype(np.float64) + self.z_mean[:, np.newaxis]
        lines.append(
            f"  z range        : [{float(np.nanmin(z_all)):.4f}, {float(np.nanmax(z_all)):.4f}] m"
        )
        return "\n".join(lines)

    def create_contact_point(
        self,
        *,
        border_mode_u:     BorderMode | None      = None,
        border_mode_v:     BorderMode | None      = None,
        border_offset_u:   float | None           = None,
        border_offset_v:   float | None           = None,
        smooth_u_begin:    float | None           = None,
        smooth_u_end:      float | None           = None,
        ref_line_continue: RefLineContinue | None = None,
        curv_mode:         CurvMode | None        = None,
        ref_line_search_u: float | None           = None,
        ref_line_close:    float | None           = None,
        ref_line_far:      float | None           = None,
        history_size:      int | None             = None,
    ) -> ContactPoint:
        """Create a :class:`ContactPoint` evaluation context for this dataset.

        All parameters correspond to fields of :class:`~crgutils.EvalOptions`.
        Omitted parameters use the dataset's ``default_options`` or the
        :class:`~crgutils.EvalOptions` defaults.

        Returns
        -------
        ContactPoint
            A new evaluation context bound to this dataset.
        """
        from ._contact_point import ContactPoint  # lazy import — avoids circular dep
        _locs = locals()
        _option_keys = [
            "border_mode_u", "border_mode_v", "border_offset_u", "border_offset_v",
            "smooth_u_begin", "smooth_u_end", "ref_line_continue", "curv_mode",
            "ref_line_search_u", "ref_line_close", "ref_line_far", "history_size",
        ]
        options = {k: _locs[k] for k in _option_keys if _locs[k] is not None}
        return ContactPoint(self, **options)
