"""ContactPoint: stateful evaluation context for a CRGDataset."""

from __future__ import annotations

from collections import deque
from typing import Any

import numpy as np

from ._dataset import CRGDataset
from ._types import EvalOptions
from ._eval import (
    _eval_uv_to_z,
    _eval_uv_to_xy,
    _xy_to_uv,
    _eval_uv_to_pk,
)


class ContactPoint:
    """Evaluation context for a :class:`CRGDataset`.

    A ``ContactPoint`` binds a dataset to a set of :class:`EvalOptions` and
    maintains a small history deque that accelerates successive nearby queries
    (warm start for the xy→uv search).

    Multiple ``ContactPoint`` instances on the same dataset are safe to use
    independently (each has its own history and options).

    Parameters
    ----------
    dataset:
        The CRG dataset to evaluate against.
    **options:
        Keyword arguments that override :class:`EvalOptions` defaults.
        Keys must be valid :class:`EvalOptions` field names.

    Examples
    --------
    >>> import crgutils
    >>> ds = crgutils.load("road.crg")
    >>> cp = crgutils.ContactPoint(ds)
    >>> z = cp.eval_uv_to_z(5.0, 0.0)
    >>> x, y = cp.eval_uv_to_xy(5.0, 0.5)
    >>> u, v = cp.eval_xy_to_uv(x, y)
    """

    def __init__(self, dataset: CRGDataset, **options: Any) -> None:
        self._ds = dataset
        # Merge dataset-level default options with caller overrides
        merged = {**dataset.default_options, **options}
        self._options = EvalOptions(**merged)
        self._history: deque[tuple[float, float, int]] = deque(
            maxlen=self._options.history_size
        )

        # Pre-seed history if ref_line_search_u is set
        if self._options.ref_line_search_u is not None:
            su = self._options.ref_line_search_u
            idx = int((su - dataset.u_min) / dataset.u_inc)
            idx = max(1, min(idx, dataset.n_u - 1))
            x_seed, y_seed = _eval_uv_to_xy(dataset, self._options, su, 0.0)
            self._history.appendleft((x_seed, y_seed, idx))

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    def with_options(self, **overrides: Any) -> "ContactPoint":
        """Return a new ``ContactPoint`` with option overrides applied.

        The new instance shares the same dataset but gets a fresh history.
        """
        from dataclasses import asdict
        current = asdict(self._options)
        current.update(overrides)
        return ContactPoint(self._ds, **current)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def options(self) -> EvalOptions:
        return self._options

    @property
    def dataset(self) -> CRGDataset:
        return self._ds

    # ------------------------------------------------------------------
    # Primary evaluation methods
    # ------------------------------------------------------------------

    def eval_uv_to_z(self, u: float, v: float) -> float:
        """Bilinear elevation at road coordinate (u, v) [m]."""
        return _eval_uv_to_z(self._ds, self._options, u, v)

    def eval_xy_to_z(self, x: float, y: float) -> float:
        """Elevation at Cartesian position (x, y) [m]."""
        u, v = _xy_to_uv(self._ds, self._options, x, y, self._history)
        return _eval_uv_to_z(self._ds, self._options, u, v)

    def eval_uv_to_xy(self, u: float, v: float) -> tuple[float, float]:
        """Convert road (u, v) to Cartesian (x, y) [m]."""
        return _eval_uv_to_xy(self._ds, self._options, u, v)

    def eval_xy_to_uv(self, x: float, y: float) -> tuple[float, float]:
        """Convert Cartesian (x, y) to road (u, v) [m]."""
        return _xy_to_uv(self._ds, self._options, x, y, self._history)

    def eval_uv_to_pk(self, u: float, v: float) -> tuple[float, float]:
        """Heading [rad] and curvature [1/m] at road (u, v)."""
        return _eval_uv_to_pk(self._ds, self._options, u, v)

    def eval_xy_to_pk(self, x: float, y: float) -> tuple[float, float]:
        """Heading [rad] and curvature [1/m] at Cartesian (x, y)."""
        u, v = _xy_to_uv(self._ds, self._options, x, y, self._history)
        return _eval_uv_to_pk(self._ds, self._options, u, v)

    # ------------------------------------------------------------------
    # Vectorised convenience methods
    # ------------------------------------------------------------------

    def eval_uv_to_z_grid(
        self,
        u: "np.ndarray",
        v: "np.ndarray",
    ) -> "np.ndarray":
        """Vectorised elevation evaluation over arrays of (u, v) pairs.

        Parameters
        ----------
        u, v:
            1-D arrays of matching length or broadcastable shapes.

        Returns
        -------
        np.ndarray
            Elevation values, same shape as broadcast(u, v).
        """
        u_arr = np.asarray(u, dtype=float).ravel()
        v_arr = np.asarray(v, dtype=float).ravel()
        z_arr = np.empty(len(u_arr), dtype=float)
        for i in range(len(u_arr)):
            z_arr[i] = _eval_uv_to_z(self._ds, self._options, float(u_arr[i]), float(v_arr[i]))
        return z_arr

    def eval_xy_to_z_grid(
        self,
        x: "np.ndarray",
        y: "np.ndarray",
    ) -> "np.ndarray":
        """Vectorised elevation evaluation over arrays of (x, y) pairs."""
        x_arr = np.asarray(x, dtype=float).ravel()
        y_arr = np.asarray(y, dtype=float).ravel()
        z_arr = np.empty(len(x_arr), dtype=float)
        for i in range(len(x_arr)):
            z_arr[i] = self.eval_xy_to_z(float(x_arr[i]), float(y_arr[i]))
        return z_arr

    def __repr__(self) -> str:
        return (
            f"ContactPoint(dataset={self._ds.source_file!r}, "
            f"border_mode_u={self._options.border_mode_u.name}, "
            f"border_mode_v={self._options.border_mode_v.name})"
        )
