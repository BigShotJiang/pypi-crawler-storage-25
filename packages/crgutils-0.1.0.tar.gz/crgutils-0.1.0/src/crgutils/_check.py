"""Validate a CRGDataset for consistency and accuracy.

Port of ``crgCheck()`` / ``crgCheckOpts()`` / ``crgCheckData()`` from
crgLoader.c / crgMgr.c.
"""

from __future__ import annotations

import math
import warnings

import numpy as np

from ._dataset import CRGDataset


def check(dataset: CRGDataset, *, raise_on_error: bool = False) -> bool:
    """Validate *dataset* for internal consistency.

    Parameters
    ----------
    dataset:
        The dataset to validate.
    raise_on_error:
        If True, raise a ``ValueError`` instead of returning False.

    Returns
    -------
    bool
        ``True`` if all checks pass.
    """
    errors: list[str] = []
    warnings_: list[str] = []

    # --- basic shape checks ---
    if dataset.n_u < 2:
        errors.append(f"u axis has fewer than 2 points ({dataset.n_u})")
    if dataset.n_v < 1:
        errors.append(f"v axis has no points ({dataset.n_v})")
    if dataset.z.shape != (dataset.n_v, dataset.n_u):
        errors.append(
            f"z shape {dataset.z.shape} does not match (n_v={dataset.n_v}, n_u={dataset.n_u})"
        )

    # --- u increment consistency ---
    if dataset.n_u >= 2:
        computed_inc = (dataset.u_max - dataset.u_min) / (dataset.n_u - 1)
        if abs(computed_inc - dataset.u_inc) > 1e-6 * max(1.0, abs(dataset.u_inc)):
            warnings_.append(
                f"u_inc mismatch: stored={dataset.u_inc:.6f}, computed={computed_inc:.6f}"
            )

    # --- v monotonicity ---
    if dataset.n_v >= 2:
        diffs = np.diff(dataset.v.astype(float))
        if not np.all(diffs > 0):
            errors.append("v array is not strictly increasing")

    # --- phi continuity (warn on large jumps) ---
    if dataset.n_u >= 2:
        phi_unwrapped = np.unwrap(dataset.phi.astype(float))
        dphi = np.abs(np.diff(phi_unwrapped))
        max_dphi = float(dphi.max()) if len(dphi) else 0.0
        if max_dphi > math.pi / 2:
            warnings_.append(
                f"Large heading jump detected: max |Δphi| = {math.degrees(max_dphi):.1f}°"
            )

    # --- NaN fraction in z grid ---
    nan_count = int(np.isnan(dataset.z.astype(float)).sum())
    total = dataset.z.size
    if nan_count > 0:
        frac = nan_count / total
        if frac > 0.5:
            errors.append(f"More than 50% of z values are NaN ({nan_count}/{total})")
        elif frac > 0.1:
            warnings_.append(f"{nan_count}/{total} z values are NaN ({100*frac:.1f}%)")

    # --- reference line x/y length vs u length ---
    if dataset.n_u >= 2:
        dx = np.diff(dataset.x.astype(float))
        dy = np.diff(dataset.y.astype(float))
        seg_lengths = np.sqrt(dx ** 2 + dy ** 2)
        total_xy = float(seg_lengths.sum())
        total_u  = dataset.u_max - dataset.u_min
        if total_u > 0 and abs(total_xy - total_u) / total_u > 0.05:
            warnings_.append(
                f"Reference line arc length {total_xy:.3f} m differs from "
                f"u range {total_u:.3f} m by more than 5%"
            )

    for w in warnings_:
        warnings.warn(f"CRGDataset check: {w}", UserWarning, stacklevel=2)

    if errors:
        msg = "CRGDataset validation failed:\n" + "\n".join(f"  - {e}" for e in errors)
        if raise_on_error:
            raise ValueError(msg)
        warnings.warn(msg, UserWarning, stacklevel=2)
        return False

    return True
