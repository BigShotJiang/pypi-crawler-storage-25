"""Enumerations and option dataclasses for crgutils."""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


class BorderMode(IntEnum):
    """How to handle queries outside the data boundary."""
    NONE     = 0  # refuse evaluation (raise CRGEvalError)
    EX_ZERO  = 1  # return z = 0
    EX_KEEP  = 2  # clamp to boundary value (default)
    REPEAT   = 3  # wrap / repeat the data
    REFLECT  = 4  # reflect the data


class RefLineContinue(IntEnum):
    """How the reference line extends beyond the primary u range."""
    EXTRAPOLATE = 0  # extrapolate tangentially (default)
    CLOSE_TRACK = 1  # try to close the loop


class CurvMode(IntEnum):
    """How curvature is computed away from the reference line."""
    LATERAL  = 0  # based on lateral v position (default)
    REF_LINE = 1  # use reference-line curvature unchanged


class GridNaNMode(IntEnum):
    """How NaN values in the elevation grid are treated."""
    KEEP       = 0  # leave NaNs as-is
    SET_ZERO   = 1  # replace NaNs with 0
    KEEP_LAST  = 2  # propagate last valid boundary value (default)


@dataclass(frozen=True)
class EvalOptions:
    """Immutable evaluation options for a ContactPoint.

    All fields correspond 1-to-1 with the C dCrgCpOption* constants.
    """
    border_mode_u:      BorderMode       = BorderMode.EX_KEEP
    border_mode_v:      BorderMode       = BorderMode.EX_KEEP
    border_offset_u:    float            = 0.0
    border_offset_v:    float            = 0.0
    smooth_u_begin:     float | None     = None   # m; smoothing zone at data onset
    smooth_u_end:       float | None     = None   # m; smoothing zone at data offset
    ref_line_continue:  RefLineContinue  = RefLineContinue.EXTRAPOLATE
    curv_mode:          CurvMode         = CurvMode.LATERAL
    ref_line_search_u:  float | None     = None   # pre-seed u for history search
    ref_line_close:     float | None     = None   # near criteria [m]
    ref_line_far:       float | None     = None   # far criteria [m]
    history_size:       int              = 50
