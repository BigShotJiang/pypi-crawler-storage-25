"""Working memory buffer — always-visible memories within a session."""

from __future__ import annotations

from collections import Counter, OrderedDict, deque
from uuid import UUID

from fractal_memory.config import FractalConfig


class WorkingMemoryBuffer:
    def __init__(self, config: FractalConfig) -> None:
        self._config = config
        self._recent: OrderedDict[UUID, int] = OrderedDict()  # id → turn
        self._just_written: deque[UUID] = deque(maxlen=config.buffer_just_written_max)
        self._pinned: set[UUID] = set()
        self._auto_promoted: set[UUID] = set()
        self._access_counts: Counter[UUID] = Counter()
        self._turn = 0
        # Phase 2: habituation — counts consecutive turns each memory is in context
        self._habituation_counter: Counter[UUID] = Counter()

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def pinned(self) -> set[UUID]:
        """Set of pinned memory IDs."""
        return set(self._pinned)

    @property
    def auto_promoted(self) -> set[UUID]:
        """Set of auto-promoted memory IDs."""
        return set(self._auto_promoted)

    @property
    def just_written(self) -> list[UUID]:
        """Recently written memory IDs."""
        return list(self._just_written)

    @property
    def recent(self) -> dict[UUID, int]:
        """Recent memory IDs mapped to their turn number."""
        return dict(self._recent)

    @property
    def access_counts(self) -> dict[UUID, int]:
        """Access count per memory ID."""
        return dict(self._access_counts)

    @property
    def habituation_counter(self) -> dict[UUID, int]:
        """Habituation counter per memory ID."""
        return dict(self._habituation_counter)

    @property
    def turn(self) -> int:
        """Current turn number."""
        return self._turn

    def add_recent(self, memory_id: UUID) -> None:
        self._recent[memory_id] = self._turn
        self._recent.move_to_end(memory_id)
        self._turn += 1
        self._evict_if_needed()

    def add_just_written(self, memory_id: UUID) -> None:
        # If just_written is full, the oldest overflows to recent
        if len(self._just_written) == self._just_written.maxlen:
            overflow = self._just_written[0]
            self.add_recent(overflow)
        self._just_written.append(memory_id)

    def pin(self, memory_id: UUID) -> None:
        self._pinned.add(memory_id)

    def unpin(self, memory_id: UUID) -> None:
        self._pinned.discard(memory_id)

    def on_access(self, memory_id: UUID) -> None:
        self._access_counts[memory_id] += 1
        if self._access_counts[memory_id] >= self._config.buffer_auto_promote_threshold:
            self._auto_promoted.add(memory_id)

    def get_buffer_ids(self) -> list[UUID]:
        """Return buffer IDs in priority order: pinned, auto-promoted, just_written, recent."""
        seen: set[UUID] = set()
        result: list[UUID] = []

        for memory_id in self._pinned:
            if memory_id not in seen:
                result.append(memory_id)
                seen.add(memory_id)

        for memory_id in self._auto_promoted:
            if memory_id not in seen:
                result.append(memory_id)
                seen.add(memory_id)

        for memory_id in reversed(self._just_written):
            if memory_id not in seen:
                result.append(memory_id)
                seen.add(memory_id)

        for memory_id in reversed(self._recent):
            if memory_id not in seen:
                result.append(memory_id)
                seen.add(memory_id)

        return result

    def clear(self) -> None:
        self._recent.clear()
        self._just_written.clear()
        self._pinned.clear()
        self._auto_promoted.clear()
        self._access_counts.clear()
        self._turn = 0
        self._habituation_counter.clear()

    # ------------------------------------------------------------------
    # Phase 2: Habituation (B-8 related)
    # ------------------------------------------------------------------

    def update_habituation(self, injected_ids: list[UUID]) -> list[UUID]:
        """Update habituation counters based on what was injected this turn.

        Increments counter for each injected memory. Resets counter for any
        memory that was previously tracked but NOT in the current injection set
        (topic shifted — memory left context).

        Args:
            injected_ids: IDs of memories injected into context this turn.

        Returns:
            list of memory IDs that have been in context for >= habituation_window
            consecutive turns and should be suppressed from injection.
        """
        injected_set = set(injected_ids)
        # Reset counter for memories that left context
        for mid in list(self._habituation_counter.keys()):
            if mid not in injected_set:
                del self._habituation_counter[mid]
        # Increment counter for currently injected memories
        for mid in injected_ids:
            self._habituation_counter[mid] += 1

        window = self._config.habituation_window
        return [
            mid for mid, count in self._habituation_counter.items()
            if count >= window
        ]

    def is_habituated(self, memory_id: UUID) -> bool:
        """Return True if this memory has been in context for >= habituation_window turns."""
        return self._habituation_counter.get(memory_id, 0) >= self._config.habituation_window

    def reset_habituation(self, memory_id: UUID) -> None:
        """Reset the habituation counter for a specific memory (topic shift)."""
        self._habituation_counter.pop(memory_id, None)

    def _evict_if_needed(self) -> None:
        """Evict oldest recent entries beyond soft cap (pinned/auto-promoted immune)."""
        while len(self._recent) > self._config.buffer_soft_cap:
            # Find the oldest entry that is NOT pinned/auto-promoted
            to_evict: UUID | None = None
            for mid in self._recent:
                if mid not in self._pinned and mid not in self._auto_promoted:
                    to_evict = mid
                    break
            if to_evict is None:
                break  # all entries are pinned/promoted — can't evict
            del self._recent[to_evict]
