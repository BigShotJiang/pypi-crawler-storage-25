"""Domain detection and management (Phase 2 — project metadata seeding)."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from uuid import UUID

from fractal_memory._compat import utcnow
from fractal_memory.config import FractalConfig
from fractal_memory.models import ContextTags
from fractal_memory.storage import Storage

logger = logging.getLogger(__name__)


@dataclass
class DomainStats:
    """Statistics for a single domain. P2→P3 contract — morphogens need domain_density."""

    name: str
    memory_count: int
    session_count: int
    first_created: datetime
    avg_internal_edge_weight: float
    edge_count: int


class DomainManager:
    """Detect and manage memory domains.

    Phase 2 strategy: deterministic detection from explicit context or project
    metadata. No clustering — full organic domain emergence is Phase 3.
    """

    def __init__(self, storage: Storage, config: FractalConfig) -> None:
        self._storage = storage
        self._config = config

    async def detect_domain(
        self, context: ContextTags, text: str
    ) -> str:
        """Determine the domain for new content.

        Strategy (in priority order):
        1. Explicit context["domain"] → use directly.
        2. context["project"] → derive as "project-<name>".
        3. Fallback → "general".

        Args:
            context: ContextTags dict with optional project/domain keys.
            text: Raw content text (unused in Phase 2; available for Phase 3 NLP).

        Returns:
            Domain string.
        """
        if context.get("domain"):
            return str(context["domain"])
        if context.get("project"):
            project_name = str(context["project"])
            return f"project-{project_name}"
        return "general"

    async def suggest_domain_from_associations(
        self,
        memory_id: UUID,
        association_edges: list[tuple[UUID, float]],
        current_domain: str,
        domain_lookup: dict[UUID, str],
    ) -> str | None:
        """Suggest a domain reassignment if the majority of neighbors are elsewhere.

        Called during consolidation (soft suggestion, never auto-applied in Phase 2).

        Args:
            memory_id: The memory being evaluated.
            association_edges: List of (neighbor_id, weight) tuples.
            current_domain: The memory's current domain.
            domain_lookup: dict mapping memory_id → domain for neighbors.

        Returns:
            Suggested domain string, or None if no drift detected.
        """
        if not association_edges:
            return None

        total_weight = sum(w for _, w in association_edges)
        if total_weight == 0:
            return None

        # Weighted domain vote
        domain_weights: dict[str, float] = {}
        for neighbor_id, weight in association_edges:
            neighbor_domain = domain_lookup.get(neighbor_id)
            if neighbor_domain and neighbor_domain != current_domain:
                domain_weights[neighbor_domain] = (
                    domain_weights.get(neighbor_domain, 0.0) + weight
                )

        if not domain_weights:
            return None

        # Find the dominant foreign domain
        best_domain = max(domain_weights, key=lambda d: domain_weights[d])
        best_weight = domain_weights[best_domain]
        if best_weight / total_weight >= self._config.domain_drift_threshold:
            logger.debug(
                "Domain drift suggestion: memory %s -> %s (%.0f%% of edge weight)",
                memory_id, best_domain, best_weight / total_weight * 100,
            )
            return best_domain

        return None

    async def domain_stats(self, domain: str) -> DomainStats:
        """Return statistics for a domain. P2→P3 contract: morphogens need domain_density.

        Args:
            domain: Domain name.

        Returns:
            DomainStats dataclass.
        """
        memories = await self._storage.get_memories_by_domain(domain)
        memory_count = len(memories)

        session_count = await self._storage.get_session_count(domain)

        first_created = (
            min(m.created_at for m in memories)
            if memories
            else utcnow()
        )

        # Compute internal edge weight (edges where both endpoints are in this domain)
        memory_ids_in_domain = {m.id for m in memories}
        internal_edges = await self._storage.get_domain_internal_edges(memory_ids_in_domain)
        total_internal_weight = sum(w for _, _, w in internal_edges)
        internal_edge_count = len(internal_edges)

        avg_weight = (
            total_internal_weight / internal_edge_count
            if internal_edge_count > 0
            else 0.0
        )

        return DomainStats(
            name=domain,
            memory_count=memory_count,
            session_count=session_count,
            first_created=first_created,
            avg_internal_edge_weight=avg_weight,
            edge_count=internal_edge_count,
        )

    async def list_domains_with_stats(self) -> list[DomainStats]:
        """Return stats for all domains."""
        raw_domains = await self._storage.list_domains()
        results = []
        for domain_name, _count, _last_updated in raw_domains:
            stats = await self.domain_stats(domain_name)
            results.append(stats)
        return results
