"""Coincidence gate + waiting room management."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum
from uuid import UUID, uuid4

from fractal_memory._compat import utcnow
from fractal_memory.config import FractalConfig
from fractal_memory.embeddings import EmbeddingProvider
from fractal_memory.models import WaitingRoomEntry
from fractal_memory.storage import Storage

logger = logging.getLogger(__name__)


class Signal(StrEnum):
    EXPLICIT_STORE = "explicit_store"
    TOPIC_RELEVANCE = "topic_relevance"
    NOVELTY = "novelty"
    REPETITION = "repetition"
    EMPHASIS = "emphasis"



@dataclass
class GateDecision:
    passed: bool
    signals: list[Signal]
    intensity: float
    waiting_room_entry: WaitingRoomEntry | None = None
    embedding: list[float] | None = None
    """Pre-computed embedding from gate evaluation, reused by store() to avoid redundant embed() call. None if gate did not compute an embedding."""


class CoincidenceGate:
    def __init__(
        self,
        storage: Storage,
        embeddings: EmbeddingProvider,
        config: FractalConfig,
    ) -> None:
        self._storage = storage
        self._embeddings = embeddings
        self._config = config

    async def evaluate(
        self,
        content: str,
        signals: list[Signal | str],
        domain: str | None = None,
    ) -> GateDecision:
        """Evaluate whether content passes the coincidence gate.

        If signal count meets the threshold, content passes immediately.
        Otherwise, checks the waiting room for a semantic match (second signal).
        If no match, content is added to the waiting room.

        Args:
            content: Raw text content to evaluate.
            signals: List of coincidence signals detected for this content.
                     Accepts both Signal enum members and string signal names.
            domain: Domain context for the content.

        Returns:
            GateDecision indicating pass/fail, intensity, and any waiting room promotion.
        """
        # Coerce string signal names to Signal enum (Issue #1)
        coerced: list[Signal] = []
        for s in signals:
            if isinstance(s, str) and not isinstance(s, Signal):
                try:
                    coerced.append(Signal(s))
                except ValueError:
                    logger.warning("Unknown signal string %r — skipping", s)
            else:
                coerced.append(s)
        signals = coerced

        intensity = self._compute_intensity(signals)

        if len(signals) >= self._config.gate_signal_count:
            logger.debug("Gate passed: %d signals (threshold=%d)", len(signals), self._config.gate_signal_count)
            return GateDecision(
                passed=True, signals=signals, intensity=intensity
            )

        # Not enough signals — check waiting room for a semantic match
        embedding = await self._embeddings.embed(content)
        existing = await self._check_waiting_room(embedding, domain)

        if existing:
            # Second signal arrived — promote from waiting room
            logger.debug("Promoting from waiting room: entry %s", existing.id)
            await self._storage.delete_waiting_room_entry(existing.id)
            return GateDecision(
                passed=True,
                signals=signals,
                intensity=intensity,
                waiting_room_entry=existing,
                embedding=embedding,
            )

        # No match — add to waiting room
        logger.debug("Gate deferred: adding to waiting room (domain=%s)", domain)
        await self._add_to_waiting_room(
            content,
            signals[0] if signals else Signal.TOPIC_RELEVANCE,
            embedding,
            domain,
        )
        return GateDecision(passed=False, signals=signals, intensity=intensity)

    async def _check_waiting_room(
        self, embedding: list[float], domain: str | None
    ) -> WaitingRoomEntry | None:
        return await self._storage.find_waiting_room_by_content(
            embedding, threshold=self._config.waiting_room_similarity_threshold,
            domain=domain,
        )

    async def _add_to_waiting_room(
        self,
        content: str,
        signal: Signal | str,
        embedding: list[float],
        domain: str | None,
    ) -> None:
        # Coerce string signal names to Signal enum (Issue #1)
        if isinstance(signal, str):
            try:
                signal = Signal(signal)
            except ValueError:
                logger.warning("Unknown signal string %r — defaulting to TOPIC_RELEVANCE", signal)
                signal = Signal.TOPIC_RELEVANCE
        entry = WaitingRoomEntry(
            id=uuid4(),
            content=content,
            first_signal={"type": signal.value, "timestamp": utcnow().isoformat()},
            domain=domain,
            created_at=utcnow(),
            sessions_elapsed=0,
            embedding=embedding,
        )
        await self._storage.store_waiting_room_entry(entry)
        await self._storage.evict_oldest_waiting_room(self._config.waiting_room_max)

    async def expire_waiting_room(self) -> int:
        expired = await self._storage.get_expired_waiting_room_entries(
            self._config.waiting_room_expiry_sessions
        )
        for entry in expired:
            await self._storage.delete_waiting_room_entry(entry.id)
        return len(expired)

    def _compute_intensity(self, signals: list[Signal]) -> float:
        base = self._config.gate_base_intensity
        signal_weights: dict[Signal, float] = {
            Signal.EMPHASIS: self._config.gate_signal_weight_emphasis,
            Signal.EXPLICIT_STORE: self._config.gate_signal_weight_explicit_store,
            Signal.REPETITION: self._config.gate_signal_weight_repetition,
            Signal.NOVELTY: self._config.gate_signal_weight_novelty,
            Signal.TOPIC_RELEVANCE: self._config.gate_signal_weight_topic_relevance,
        }
        bonus = sum(signal_weights.get(s, 0.0) for s in signals)
        return min(1.0, max(0.0, base + bonus))
