"""Configuration system for fractal-memory."""

from __future__ import annotations

import logging
import os
import tomllib
from dataclasses import dataclass, fields
from pathlib import Path

logger = logging.getLogger(__name__)


def _check_range(name: str, value: int | float, lo: int | float, hi: int | float) -> None:
    """Validate a config value is within [lo, hi]. Raises ValueError if not."""
    if not (lo <= value <= hi):
        raise ValueError(f"{name} must be in [{lo}, {hi}], got {value}")


@dataclass(frozen=True)
class FractalConfig:
    """Central configuration for the fractal-memory system.

    Every tunable parameter lives here as the single source of truth.
    Fields are grouped by subsystem. Later-phase fields have defaults so
    existing configs remain backward-compatible.

    Morphogen sensitivity annotations (Phase 3+ self-calibration):
      [H] = high sensitivity — small changes have large behavioural impact
      [M] = medium sensitivity
      [L] = low sensitivity — safe to auto-tune aggressively
    """

    # -- Storage (P1) --
    # Path to the SQLite database file. Created with 0600 permissions.
    db_path: Path = Path("~/.fractal_memory/memory.db")

    # -- Embedding (P1) --
    # sentence-transformers model name for local embedding generation.
    embedding_model: str = "all-MiniLM-L6-v2"
    # Embedding vector dimensionality. Must match the chosen model.
    embedding_dim: int = 384

    # -- LLM (P1) --
    # Provider: "bridge" | "anthropic" | "ollama". Default uses Claude Code bridge.
    llm_provider: str = "bridge"
    # Model name passed to the chosen LLM provider.
    llm_model: str = "sonnet"
    # API key for "anthropic" provider. Sourced from FRACTAL_LLM_API_KEY env var.
    llm_api_key: str | None = None
    # Base URL for Ollama server (P1). Only used when llm_provider is "ollama".
    # Must start with http:// or https://.
    ollama_base_url: str = "http://localhost:11434"
    # Timeout in seconds for LLM API calls. Range: 5–120.
    llm_timeout_seconds: float = 30.0
    # Max concurrent LLM calls allowed. Range: 1–10.
    llm_max_concurrent: int = 3
    # Max LLM calls per session (safety limit to prevent runaway costs). Range: 50–1000.
    llm_max_calls_per_session: int = 200

    # -- Retrieval (P1) --
    # [M] Fraction of context_window_tokens reserved for memory injection. Range: 0.05–0.30.
    memory_token_budget_pct: float = 0.15
    # Total context window size (tokens) of the host LLM.
    context_window_tokens: int = 200_000
    # [L] Max memories at L1 (tag only) zoom level. Range: 50–500.
    top_l1: int = 200
    # [L] Max memories at L2 (summary) zoom level. Range: 10–100.
    top_l2: int = 50
    # [M] Max memories at L3 (full context) zoom level. Range: 3–20.
    top_l3: int = 10
    # [L] Weight of cosine similarity in final score. Range: 0.5–1.0.
    scoring_cosine_weight: float = 0.8
    # [L] Weight of intensity in final score (must equal 1 - scoring_cosine_weight). Range: 0.0–0.5.
    scoring_intensity_weight: float = 0.2
    # Number of near-miss hint memories to include beyond L1 cutoff. Range: 0–50.
    hint_window_size: int = 20
    # Minimum score for a memory to be included in hints. Range: 0.0–0.5.
    hint_min_score: float = 0.1

    # -- Gate (P1) --
    # [H] Number of coincident signals required to pass the gate. Range: 1–5.
    # Default is 1 so that store("text") works out of the box with a single signal.
    # Increase to 2+ for stricter gating once multiple signal sources are configured.
    gate_signal_count: int = 1
    # Max entries in the waiting room before oldest are evicted. Range: 50–500.
    waiting_room_max: int = 100
    # [L] Sessions before a waiting room entry expires. Range: 2–10.
    waiting_room_expiry_sessions: int = 3
    # Cosine similarity threshold for waiting room semantic matching. Range: 0.70–0.95.
    waiting_room_similarity_threshold: float = 0.85
    # Base intensity value before signal bonuses. Range: 0.0–1.0.
    gate_base_intensity: float = 0.5
    # Intensity bonus per signal type: emphasis, explicit_store, repetition, novelty, topic_relevance.
    gate_signal_weight_emphasis: float = 0.20
    gate_signal_weight_explicit_store: float = 0.15
    gate_signal_weight_repetition: float = 0.10
    gate_signal_weight_novelty: float = 0.05
    gate_signal_weight_topic_relevance: float = 0.05

    # -- Lifecycle (P1) --
    # [L] Sessions-worth of inactivity before probation memories are pruned. Range: 3–20.
    pruning_ttl_sessions: int = 5
    # [M] Retrieval count to promote probation → confirmed. Range: 1–5.
    confirmation_threshold: int = 2
    # [M] Retrieval count to promote confirmed → permanent. Range: 5–50.
    permanence_threshold: int = 10

    # -- Buffer (P1) --
    # [L] Soft cap on working memory buffer size. Pinned/auto-promoted are exempt. Range: 10–50.
    buffer_soft_cap: int = 20
    # Max recently-written memories held before overflow to recent. Range: 1–10.
    buffer_just_written_max: int = 3
    # [L] Access count to auto-promote a memory within a session. Range: 2–10.
    buffer_auto_promote_threshold: int = 3
    # [L] Consecutive turns in context before habituation suppresses re-injection. Range: 3–10.
    habituation_window: int = 5
    # [M] Cosine distance threshold for topic-shift detection. Range: 0.2–0.6.
    topic_shift_threshold: float = 0.4

    # -- Association (Phase 2+) --
    # [M] Decay factor applied to activation spread per hop. Range: 0.3–0.7.
    activation_decay: float = 0.5
    # [L] Max association edges per memory node. Range: 10–50.
    edge_cap_per_node: int = 20
    # [L] Turns of refractory period after association activation. Range: 1–5.
    refractory_turns: int = 2
    # [M] Weight increment for L2 co-retrieved memories. Range: 0.05–0.3.
    co_retrieval_weight_l2: float = 0.1
    # [M] Weight increment for L3 co-retrieved memories (higher zoom = stronger bond). Range: 0.1–0.5.
    co_retrieval_weight_l3: float = 0.2
    # [L] EMA alpha for trail context centroid update. Range: 0.5–0.9.
    trail_ema_alpha: float = 0.7
    # [L] Asymptotic increment rate for stigmergic trail weight. Range: 0.05–0.2.
    trail_increment_rate: float = 0.1
    # [L] Association boost weight in final retrieval score. Range: 0.1–0.5.
    association_boost_weight: float = 0.3
    # [H] Minimum viable edge weight — edges below this are pruned by slow-wave decay. Range: 0.001–0.05.
    min_viable_edge_weight: float = 0.01
    # [L] Edge weight clamp minimum. Range: 0.001–0.05.
    edge_weight_min: float = 0.01
    # [L] Edge weight clamp maximum. Range: 0.95–1.0.
    edge_weight_max: float = 0.99

    # -- Consolidation (Phase 2+) --
    # [H] Cosine similarity threshold for conflict detection. Range: 0.75–0.95.
    conflict_detection_threshold: float = 0.85
    # [H] Cosine similarity threshold for merge candidates. Range: 0.70–0.90.
    merge_similarity_threshold: float = 0.80
    # [L] Sessions before a scar entry expires. Range: 10–50.
    scar_ttl_sessions: int = 20
    # [M] Multiplicative decay factor for slow-wave homeostasis. Range: 0.7–0.99.
    slow_wave_decay_factor: float = 0.85

    # -- Correction (Phase 2+) --
    # [M] Cosine similarity threshold: above = partial correction, below = full replacement. Range: 0.3–0.8.
    correction_similarity_threshold: float = 0.5
    # [L] Intensity bump for partial corrections. Range: 0.05–0.3.
    correction_intensity_bump: float = 0.1
    # [L] Intensity for full-correction replacement memories. Range: 0.5–1.0.
    correction_replacement_intensity: float = 0.9

    # -- Scar (Phase 2+) --
    # [H] Cosine similarity threshold for scar pattern matching. Range: 0.5–0.9.
    scar_match_threshold: float = 0.7
    # [H] Score multiplier for direct scar attribution (aggressive suppression). Range: 0.2–0.8.
    scar_direct_penalty: float = 0.5
    # [M] Score multiplier for indirect (co-retrieval) scar attribution. Range: 0.5–0.95.
    scar_indirect_penalty: float = 0.8

    # -- Feedback / Danger Theory (Phase 2+) --
    # [H] Cosine similarity threshold for re-ask detection. Range: 0.7–0.95.
    reask_similarity_threshold: float = 0.85
    # [M] Message length ratio to trigger deep engagement signal. Range: 1.2–2.0.
    engagement_length_ratio: float = 1.5
    # [M] Minimum query-to-message topical similarity for engagement. Range: 0.4–0.8.
    engagement_topic_similarity: float = 0.6

    # -- Domain (Phase 2+) --
    # [M] Fraction of edge weight in foreign domain to trigger drift suggestion. Range: 0.5–0.9.
    domain_drift_threshold: float = 0.70

    # -- Feature flags (Phase 2+) --
    # Enable spreading activation boost during retrieval. Set False to disable Phase 2 association boost.
    enable_spreading_activation: bool = True
    # Enable scar tissue penalty during retrieval. Set False to disable scar suppression.
    enable_scar_penalty: bool = True
    # Enable LLM judge at session_end. Set False to skip retrospective evaluation (saves LLM cost).
    enable_llm_judge: bool = True

    # -- Chronic (Phase 3+) --
    # [M] Per-session decay multiplier for chronic score. Range: 0.90–0.99.
    chronic_decay_factor: float = 0.97
    # [L] Weight of retrieval bump added to chronic score. Range: 0.01–0.10.
    chronic_retrieval_weight: float = 0.03
    # [M] Chronic score threshold for bootstrap inclusion. Range: 0.5–0.9.
    chronic_promotion_threshold: float = 0.7

    # -- Maintenance (Phase 3+) --
    # Minutes between intra-session maintenance checks. Range: 5–30.
    intra_session_interval_minutes: int = 15
    # Minutes after which a session is considered "long". Range: 30–120.
    long_session_threshold_minutes: int = 45

    # -- Morphogen (Phase 3+) --
    # [L] B-11 allosteric learning rate. Range: 0.01–0.20.
    morphogen_alpha: float = 0.05
    # [L] B-11 rolling average window for judge scores. Range: 5–20.
    morphogen_ema_window: int = 10
    # [L] Memories/session density at which domain_density morphogen saturates to 1.0. Range: 20–200.
    morphogen_density_saturation: float = 50.0

    # -- Apoptosis (Phase 3+) --
    # [H] Cosine similarity below which a memory is considered context-drifted. Range: 0.1–0.5.
    apoptosis_context_drift_threshold: float = 0.3
    # [M] Reconsolidation count ceiling before apoptosis is triggered. Range: 3–10.
    apoptosis_contradiction_limit: int = 5
    # [H] Vitality floor — memories below this are apoptosis candidates. Range: 0.01–0.2.
    apoptosis_min_vitality: float = 0.05
    # [L] Intensity of fragments created during apoptosis decomposition. Range: 0.1–0.5.
    apoptosis_fragment_strength: float = 0.3
    # [L] TTL (in sessions) for apoptosis scars — longer than normal scars. Range: 20–60.
    apoptosis_scar_duration: int = 30

    # -- Niche construction (Phase 3+) --
    # [L] Edge weight attraction rate for co-retrieved memories with positive outcome. Range: 0.01–0.15.
    niche_attract_rate: float = 0.05
    # [L] Edge weight repulsion rate for competing memories with negative outcome. Range: 0.01–0.10.
    niche_repel_rate: float = 0.03
    # [L] Minimum modularity improvement required to accept a domain proposal. Range: 0.01–0.20.
    niche_modularity_threshold: float = 0.05
    # [L] Minimum cluster size for Louvain domain proposals. Range: 5–20.
    niche_min_cluster_size: int = 10

    # -- Dreaming / REM (Phase 3+) --
    # [L] Cosine similarity lower bound for REM recombination pair selection. Range: 0.1–0.5.
    rem_resonance_min: float = 0.3
    # [L] Cosine similarity upper bound for REM recombination pair selection. Range: 0.5–0.9.
    rem_resonance_max: float = 0.7
    # [M] Coherence score threshold for storing REM synthesis memories. Range: 0.4–0.8.
    rem_emergence_threshold: float = 0.6
    # [L] Max memory pairs evaluated per REM cycle. Range: 10–50.
    rem_max_pairs: int = 20
    # [L] Number of top memories (by retrieval_count × intensity) selected for REM. Range: 10–50.
    rem_top_memories: int = 20
    # Enable REM recombination during dreaming. Set False to skip LLM-based synthesis.
    rem_enabled: bool = False
    # [L] Intensity of memories created during REM synthesis. Range: 0.1–0.5.
    rem_synthesis_intensity: float = 0.3
    # Enable dawn re-zoom during dreaming. Set False to skip LLM-based re-zoom.
    dawn_rezoom_enabled: bool = False
    # [L] Bandit posterior downscaling factor during slow-wave phase. Range: 0.7–0.99.
    bandit_downscale_factor: float = 0.85

    # -- System states (Phase 3+) --
    # [M] Consecutive retrieval misses before STRESS state triggers. Range: 2–5.
    stress_miss_threshold: int = 3
    # [M] Explicit corrections in quick succession to trigger STRESS. Range: 1–5.
    stress_correction_threshold: int = 2
    # [M] Consecutive successes in STRESS before recovering to FLOW. Range: 2–5.
    stress_recovery_successes: int = 3
    # [M] Memory count threshold for "mature" domain classification. Range: 20–100.
    domain_sparse_memory_threshold: int = 50
    # [M] Session count threshold for "mature" domain classification. Range: 5–20.
    domain_sparse_session_threshold: int = 10

    # -- Bootstrap (P1) --
    # [M] Fraction of memory_token_budget reserved for session bootstrap. Range: 0.10–0.50.
    bootstrap_budget_pct: float = 0.30

    # -- Session summary (P1) --
    # Max memories included in session summary prompt. Range: 5–50.
    summary_max_memories: int = 10
    # Max queries included in session summary prompt. Range: 5–50.
    summary_max_queries: int = 10

    # -- Input validation (P1) --
    # Max character length for store() text input.
    max_text_length: int = 50_000
    # Max character length for retrieve() query input.
    max_query_length: int = 10_000
    # Max character length for domain names.
    max_domain_length: int = 100
    # Regex pattern for valid domain names.
    domain_pattern: str = r"^[a-zA-Z0-9_\-\.]+$"

    # -- Dashboard (Phase 2+) --
    # Host to bind the diagnostic dashboard HTTP server. Localhost only.
    dashboard_host: str = "127.0.0.1"
    # TCP port for the diagnostic dashboard. Range: 1024–65535.
    dashboard_port: int = 8765

    # -- MCP behaviour --
    # When True, the MCP server instructs Claude to automatically start sessions,
    # store memories, retrieve context, and end sessions without being asked.
    # Set to False to make fractal-memory purely on-demand (no automatic behaviour).
    # Can be toggled via ~/.fractal_memory/config.toml: auto_session = false
    auto_session: bool = True

    # Default domain used when no domain is passed to store/retrieve/session_start.
    # Override with FRACTAL_DEFAULT_DOMAIN env var or default_domain in config.toml.
    default_domain: str = "general"

    # Number of store/retrieve ops between flushes to session_activity table.
    # Lower = more accurate dashboard heartbeat, higher = less write overhead.
    # Range: 1–50.
    activity_flush_interval: int = 5

    # -- MCP (Phase 4+) --
    # TCP port for the MCP server. Range: 1024–65535.
    mcp_port: int = 3900

    def __post_init__(self) -> None:
        """Validate config values at construction time."""
        # Embedding & text limits (Issue #19, #20)
        _check_range("embedding_dim", self.embedding_dim, 1, 4096)
        _check_range("max_text_length", self.max_text_length, 100, 1_000_000)
        _check_range("max_query_length", self.max_query_length, 100, 1_000_000)
        _check_range("memory_token_budget_pct", self.memory_token_budget_pct, 0.0001, 0.50)
        _check_range("gate_signal_count", self.gate_signal_count, 1, 5)
        _check_range("top_l1", self.top_l1, 1, 500)
        _check_range("top_l2", self.top_l2, 1, 100)
        _check_range("top_l3", self.top_l3, 1, 20)
        if not (self.top_l3 <= self.top_l2 <= self.top_l1):
            raise ValueError(
                f"Zoom level ordering violated: top_l3 ({self.top_l3}) <= "
                f"top_l2 ({self.top_l2}) <= top_l1 ({self.top_l1}) required"
            )
        _check_range("buffer_soft_cap", self.buffer_soft_cap, 0, 50)
        _check_range("activity_flush_interval", self.activity_flush_interval, 1, 50)
        _check_range("pruning_ttl_sessions", self.pruning_ttl_sessions, 0, 20)
        _check_range("scoring_cosine_weight", self.scoring_cosine_weight, 0.5, 1.0)
        _check_range("scoring_intensity_weight", self.scoring_intensity_weight, 0.0, 0.5)
        # Weight sum validation (Issue #22)
        weight_sum = self.scoring_cosine_weight + self.scoring_intensity_weight
        if abs(weight_sum - 1.0) > 0.01:
            raise ValueError(
                f"scoring_cosine_weight + scoring_intensity_weight must sum to 1.0 "
                f"(±0.01), got {weight_sum:.3f}"
            )
        # -- Lifecycle & Buffer (P1) --
        # Safety ranges: wider than recommended ranges to allow test/edge-case configs
        _check_range("confirmation_threshold", self.confirmation_threshold, 1, 50)
        _check_range("permanence_threshold", self.permanence_threshold, 1, 100)
        _check_range("buffer_just_written_max", self.buffer_just_written_max, 1, 50)
        _check_range("buffer_auto_promote_threshold", self.buffer_auto_promote_threshold, 1, 50)
        _check_range("habituation_window", self.habituation_window, 1, 50)
        _check_range("topic_shift_threshold", self.topic_shift_threshold, 0.01, 1.0)
        _check_range("waiting_room_max", self.waiting_room_max, 1, 10000)
        _check_range("waiting_room_expiry_sessions", self.waiting_room_expiry_sessions, 1, 100)
        _check_range("waiting_room_similarity_threshold", self.waiting_room_similarity_threshold, 0.01, 1.0)
        _check_range("hint_window_size", self.hint_window_size, 0, 500)
        _check_range("hint_min_score", self.hint_min_score, 0.0, 1.0)
        # -- Association (Phase 2+) --
        _check_range("activation_decay", self.activation_decay, 0.01, 1.0)
        _check_range("edge_cap_per_node", self.edge_cap_per_node, 1, 500)
        _check_range("refractory_turns", self.refractory_turns, 0, 50)
        _check_range("co_retrieval_weight_l2", self.co_retrieval_weight_l2, 0.0, 1.0)
        _check_range("co_retrieval_weight_l3", self.co_retrieval_weight_l3, 0.0, 1.0)
        _check_range("trail_ema_alpha", self.trail_ema_alpha, 0.01, 1.0)
        _check_range("trail_increment_rate", self.trail_increment_rate, 0.001, 1.0)
        _check_range("association_boost_weight", self.association_boost_weight, 0.0, 1.0)
        _check_range("min_viable_edge_weight", self.min_viable_edge_weight, 0.0001, 0.5)
        # -- Consolidation (Phase 2+) --
        _check_range("conflict_detection_threshold", self.conflict_detection_threshold, 0.1, 1.0)
        _check_range("merge_similarity_threshold", self.merge_similarity_threshold, 0.1, 1.0)
        _check_range("scar_ttl_sessions", self.scar_ttl_sessions, 1, 200)
        _check_range("slow_wave_decay_factor", self.slow_wave_decay_factor, 0.01, 1.0)
        # -- Correction (Phase 2+) --
        _check_range("correction_similarity_threshold", self.correction_similarity_threshold, 0.01, 1.0)
        _check_range("correction_intensity_bump", self.correction_intensity_bump, 0.0, 1.0)
        _check_range("correction_replacement_intensity", self.correction_replacement_intensity, 0.01, 1.0)
        # -- Ollama (P1) --
        if not self.ollama_base_url or not self.ollama_base_url.startswith(("http://", "https://")):
            raise ValueError(
                f"ollama_base_url must start with http:// or https://, got {self.ollama_base_url!r}"
            )
        # -- Scar (Phase 2+) --
        _check_range("scar_match_threshold", self.scar_match_threshold, 0.01, 1.0)
        _check_range("scar_direct_penalty", self.scar_direct_penalty, 0.01, 1.0)
        _check_range("scar_indirect_penalty", self.scar_indirect_penalty, 0.01, 1.0)
        # -- Feedback (Phase 2+) --
        _check_range("reask_similarity_threshold", self.reask_similarity_threshold, 0.1, 1.0)
        _check_range("engagement_length_ratio", self.engagement_length_ratio, 0.5, 10.0)
        _check_range("engagement_topic_similarity", self.engagement_topic_similarity, 0.01, 1.0)
        # -- Domain (Phase 2+) --
        _check_range("domain_drift_threshold", self.domain_drift_threshold, 0.1, 1.0)
        # -- Chronic (Phase 3+) --
        _check_range("chronic_decay_factor", self.chronic_decay_factor, 0.5, 1.0)
        _check_range("chronic_retrieval_weight", self.chronic_retrieval_weight, 0.001, 1.0)
        _check_range("chronic_promotion_threshold", self.chronic_promotion_threshold, 0.01, 1.0)
        # -- Maintenance (Phase 3+) --
        _check_range("intra_session_interval_minutes", self.intra_session_interval_minutes, 1, 120)
        _check_range("long_session_threshold_minutes", self.long_session_threshold_minutes, 5, 480)
        # -- Morphogen (Phase 3+) --
        _check_range("morphogen_alpha", self.morphogen_alpha, 0.001, 1.0)
        _check_range("morphogen_ema_window", self.morphogen_ema_window, 2, 100)
        _check_range("morphogen_density_saturation", self.morphogen_density_saturation, 1, 1000)
        # -- Apoptosis (Phase 3+) --
        _check_range("apoptosis_context_drift_threshold", self.apoptosis_context_drift_threshold, 0.01, 1.0)
        _check_range("apoptosis_contradiction_limit", self.apoptosis_contradiction_limit, 1, 100)
        _check_range("apoptosis_min_vitality", self.apoptosis_min_vitality, 0.001, 1.0)
        _check_range("apoptosis_fragment_strength", self.apoptosis_fragment_strength, 0.01, 1.0)
        _check_range("apoptosis_scar_duration", self.apoptosis_scar_duration, 1, 200)
        # -- Niche (Phase 3+) --
        _check_range("niche_attract_rate", self.niche_attract_rate, 0.001, 1.0)
        _check_range("niche_repel_rate", self.niche_repel_rate, 0.001, 1.0)
        _check_range("niche_modularity_threshold", self.niche_modularity_threshold, 0.001, 1.0)
        _check_range("niche_min_cluster_size", self.niche_min_cluster_size, 1, 100)
        # -- Dreaming / REM (Phase 3+) --
        _check_range("rem_resonance_min", self.rem_resonance_min, 0.0, 1.0)
        _check_range("rem_resonance_max", self.rem_resonance_max, 0.0, 1.0)
        if self.rem_resonance_min >= self.rem_resonance_max:
            raise ValueError(
                f"rem_resonance_min ({self.rem_resonance_min}) must be < "
                f"rem_resonance_max ({self.rem_resonance_max})"
            )
        _check_range("rem_emergence_threshold", self.rem_emergence_threshold, 0.0, 1.0)
        _check_range("rem_max_pairs", self.rem_max_pairs, 1, 200)
        _check_range("rem_top_memories", self.rem_top_memories, 1, 200)
        _check_range("rem_synthesis_intensity", self.rem_synthesis_intensity, 0.01, 1.0)
        _check_range("bandit_downscale_factor", self.bandit_downscale_factor, 0.01, 1.0)
        # -- System states (Phase 3+) --
        _check_range("stress_miss_threshold", self.stress_miss_threshold, 1, 50)
        _check_range("stress_correction_threshold", self.stress_correction_threshold, 1, 50)
        _check_range("stress_recovery_successes", self.stress_recovery_successes, 1, 50)
        _check_range("domain_sparse_memory_threshold", self.domain_sparse_memory_threshold, 1, 1000)
        _check_range("domain_sparse_session_threshold", self.domain_sparse_session_threshold, 1, 100)
        # -- LLM --
        _check_range("llm_timeout_seconds", self.llm_timeout_seconds, 1, 300)
        _check_range("llm_max_concurrent", self.llm_max_concurrent, 1, 50)
        _check_range("llm_max_calls_per_session", self.llm_max_calls_per_session, 1, 100000)

    @property
    def memory_token_budget(self) -> int:
        """Computed token budget for memory injection."""
        return int(self.context_window_tokens * self.memory_token_budget_pct)


# Env var mapping: ENV_VAR -> config field name
_ENV_OVERRIDES: dict[str, str] = {
    "FRACTAL_DB_PATH": "db_path",
    "FRACTAL_LLM_API_KEY": "llm_api_key",
    "FRACTAL_LLM_PROVIDER": "llm_provider",
    "FRACTAL_LLM_MODEL": "llm_model",
    "FRACTAL_OLLAMA_BASE_URL": "ollama_base_url",
    "FRACTAL_AUTO_SESSION": "auto_session",
    "FRACTAL_DEFAULT_DOMAIN": "default_domain",
    "FRACTAL_ACTIVITY_FLUSH_INTERVAL": "activity_flush_interval",
}


def load_config(path: Path | None = None, *, pioneer: bool = True) -> FractalConfig:
    """Load config from TOML file + env var overrides.

    Args:
        path: Path to TOML config file. Defaults to ~/.fractal_memory/config.toml.
        pioneer: If True, sets gate_signal_count=1 (Phase 1 Pioneer stage).
    """
    if path is None:
        path = Path("~/.fractal_memory/config.toml").expanduser()

    overrides: dict[str, object] = {}

    # 1. Read TOML file if it exists
    if path.exists():
        with open(path, "rb") as f:
            toml_data = tomllib.load(f)
        field_names = {fld.name for fld in fields(FractalConfig)}
        for key, value in toml_data.items():
            if key in field_names:
                overrides[key] = value

    # 2. Apply env var overrides
    for env_var, field_name in _ENV_OVERRIDES.items():
        env_val = os.environ.get(env_var)
        if env_val is not None:
            overrides[field_name] = env_val

    # 3. Convert types (Issue #51 — robust type coercion for env var strings)
    if "db_path" in overrides:
        overrides["db_path"] = Path(str(overrides["db_path"])).expanduser()
    if "auto_session" in overrides and isinstance(overrides["auto_session"], str):
        overrides["auto_session"] = overrides["auto_session"].lower() not in ("0", "false", "no")
    # Auto-detect int/float fields from FractalConfig dataclass definition
    # so all numeric env vars are coerced, not just a hardcoded subset.
    _FIELD_TYPES: dict[str, type] = {}
    for _f in fields(FractalConfig):
        _origin = getattr(_f.type, "__origin__", None)
        # Resolve Optional/Union — check args for int/float
        _args = getattr(_f.type, "__args__", ())
        if _f.type is int or _f.type == "int" or int in _args:
            _FIELD_TYPES[_f.name] = int
        elif _f.type is float or _f.type == "float" or float in _args:
            _FIELD_TYPES[_f.name] = float
        elif isinstance(_f.default, int) and not isinstance(_f.default, bool):
            _FIELD_TYPES[_f.name] = int
        elif isinstance(_f.default, float):
            _FIELD_TYPES[_f.name] = float
    for field_name, field_type in _FIELD_TYPES.items():
        if field_name in overrides and isinstance(overrides[field_name], str):
            try:
                overrides[field_name] = field_type(overrides[field_name])
            except ValueError:
                logger.warning(
                    "Invalid %s value for %s: %r",
                    field_type.__name__, field_name, overrides[field_name],
                )

    # 4. Pioneer stage override
    if pioneer and "gate_signal_count" not in overrides:
        overrides["gate_signal_count"] = 1

    return FractalConfig(**overrides)
