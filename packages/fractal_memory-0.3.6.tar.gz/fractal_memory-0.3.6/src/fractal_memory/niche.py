"""Niche construction — self-organising domain formation via co-retrieval (B-6, Phase 3)."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING
from uuid import UUID

import numpy as np

from fractal_memory.config import FractalConfig

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from fractal_memory.associations import AssociationNetwork
    from fractal_memory.domains import DomainManager
    from fractal_memory.storage import Storage


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class DomainProposal:
    """A proposed domain reassignment derived from Louvain community detection."""

    memory_ids: list[UUID]
    proposed_domain: str       # new or existing domain name
    current_domains: list[str]  # domains these memories currently belong to
    modularity_delta: float    # improvement over current assignment
    confidence: float          # 0–1


@dataclass
class NicheHealth:
    """Niche metrics for a domain."""

    domain: str
    internal_cohesion: float   # mean edge weight within domain
    external_separation: float  # mean edge weight to other domains
    stability_sessions: int
    memory_count: int


# ---------------------------------------------------------------------------
# NicheConstructor
# ---------------------------------------------------------------------------


class NicheConstructor:
    """Actively shapes domain structure through co-retrieval feedback.

    Co-retrieval with positive outcomes attracts memories (edges strengthen);
    negative outcomes repel competing memories (edges weaken).

    Louvain community detection runs during weekly maintenance (not real-time).
    """

    def __init__(
        self,
        storage: "Storage",
        associations: "AssociationNetwork",
        domains: "DomainManager",
        config: FractalConfig,
    ) -> None:
        self._storage = storage
        self._associations = associations
        self._domains = domains
        self._config = config
        # domain → last reassignment session count
        self._stability: dict[str, int] = {}
        self._session_count: int = 0
        self._total_reassignments: int = 0

    # ------------------------------------------------------------------
    # Co-retrieval feedback
    # ------------------------------------------------------------------

    async def on_co_retrieval_outcome(
        self,
        memory_ids: list[UUID],
        outcome: str,
        domain: str,
    ) -> None:
        """Update association edge weights based on co-retrieval feedback.

        Args:
            memory_ids: IDs of memories co-retrieved together.
            outcome: ``"positive"`` or ``"negative"``.
            domain: Current domain (for metadata only).
        """
        attract_rate = self._config.niche_attract_rate
        repel_rate = self._config.niche_repel_rate
        min_w = self._config.edge_weight_min
        max_w = self._config.edge_weight_max

        if outcome == "positive":
            for i, id_a in enumerate(memory_ids):
                for id_b in memory_ids[i + 1 :]:
                    await self._associations.adjust_edge_weight(  # type: ignore[attr-defined]
                        id_a, id_b,
                        delta_fn=lambda w: max(min_w, min(max_w, w + attract_rate * (1.0 - w))),
                    )
        elif outcome == "negative":
            for i, id_a in enumerate(memory_ids):
                for id_b in memory_ids[i + 1 :]:
                    await self._associations.adjust_edge_weight(  # type: ignore[attr-defined]
                        id_a, id_b,
                        delta_fn=lambda w: max(min_w, min(max_w, w - repel_rate * w)),
                    )

    # ------------------------------------------------------------------
    # Domain cluster detection
    # ------------------------------------------------------------------

    async def detect_domain_clusters(self) -> list[DomainProposal]:
        """Run Louvain community detection on the association graph.

        Returns proposals for domain reassignments.  Only clusters with
        modularity improvement > ``niche_modularity_threshold`` and minimum
        size ``niche_min_cluster_size`` are returned.
        """
        try:
            import networkx as nx
            from networkx.algorithms.community import louvain_communities
        except ImportError:
            return []

        # Build graph from association edges
        edges = await self._associations.get_all_edges()  # type: ignore[attr-defined]
        if not edges:
            return []

        G = nx.Graph()
        for edge in edges:
            G.add_edge(str(edge["source"]), str(edge["target"]), weight=float(edge.get("weight", 0.1)))

        if G.number_of_nodes() < self._config.niche_min_cluster_size:
            return []

        # Deterministic seed (hashlib for cross-process reproducibility)
        import hashlib
        node_list = sorted(G.nodes())
        edge_list = sorted((u, v, G[u][v]["weight"]) for u, v in G.edges())
        seed_str = "".join(node_list) + "".join(f"{w:.3f}" for _, _, w in edge_list)
        seed = int(hashlib.sha256(seed_str.encode()).hexdigest(), 16) % (2**31)

        try:
            communities = louvain_communities(G, seed=seed, weight="weight")
        except Exception:
            return []

        proposals: list[DomainProposal] = []
        for community in communities:
            if len(community) < self._config.niche_min_cluster_size:
                continue

            memory_ids = [UUID(nid) for nid in community if _is_valid_uuid(nid)]
            if not memory_ids:
                continue

            # Estimate modularity delta (simplified: internal density vs overall)
            internal_edges = G.subgraph(list(community)).number_of_edges()
            total_edges = G.number_of_edges()
            modularity_delta = internal_edges / max(1, total_edges) - (
                len(community) / max(1, G.number_of_nodes())
            ) ** 2
            if modularity_delta < self._config.niche_modularity_threshold:
                continue

            # Gather current domains
            current_domains: list[str] = []
            for mid in memory_ids[:20]:  # sample up to 20
                mem = await self._storage.get_memory(mid)  # type: ignore[attr-defined]
                if mem:
                    current_domains.append(mem.domain)

            dominant_domain = max(set(current_domains), key=current_domains.count) if current_domains else "unknown"
            proposals.append(
                DomainProposal(
                    memory_ids=memory_ids,
                    proposed_domain=dominant_domain,
                    current_domains=list(set(current_domains)),
                    modularity_delta=modularity_delta,
                    confidence=min(1.0, modularity_delta * 5),
                )
            )

        return proposals

    async def apply_domain_proposals(self, proposals: list[DomainProposal]) -> int:
        """Apply approved domain proposals.

        Reassigns memories to the proposed domain.  Called during weekly
        maintenance.

        Returns:
            Count of memories reassigned.
        """
        count = 0
        for proposal in proposals:
            for mid in proposal.memory_ids:
                mem = await self._storage.get_memory(mid)  # type: ignore[attr-defined]
                if mem and mem.domain != proposal.proposed_domain:
                    mem.domain = proposal.proposed_domain
                    await self._storage.update_memory(mem)  # type: ignore[attr-defined]
                    count += 1
            self._stability[proposal.proposed_domain] = self._session_count
        self._total_reassignments += count
        return count

    # ------------------------------------------------------------------
    # Health metrics
    # ------------------------------------------------------------------

    async def get_niche_health(self, domain: str) -> NicheHealth:
        """Return niche metrics for a domain."""
        memories = await self._storage.get_memories_by_domain(domain)  # type: ignore[attr-defined]
        memory_count = len(memories)
        domain_ids = {mem.id for mem in memories}

        internal_weights: list[float] = []
        external_weights: list[float] = []

        try:
            edges = await self._associations.get_all_edges()  # type: ignore[attr-defined]
            for edge in edges:
                src = UUID(str(edge["source"])) if not isinstance(edge["source"], UUID) else edge["source"]
                tgt = UUID(str(edge["target"])) if not isinstance(edge["target"], UUID) else edge["target"]
                w = float(edge.get("weight", 0.0))
                both_internal = (src in domain_ids) and (tgt in domain_ids)
                one_external = (src in domain_ids) != (tgt in domain_ids)
                if both_internal:
                    internal_weights.append(w)
                elif one_external:
                    external_weights.append(w)
        except Exception:
            logger.debug("NicheHealth edge weight iteration failed", exc_info=True)

        stability = self._session_count - self._stability.get(domain, 0)

        return NicheHealth(
            domain=domain,
            internal_cohesion=float(np.mean(internal_weights)) if internal_weights else 0.0,
            external_separation=1.0 - (float(np.mean(external_weights)) if external_weights else 0.0),
            stability_sessions=stability,
            memory_count=memory_count,
        )

    def increment_session(self) -> None:
        """Increment the internal session counter."""
        self._session_count += 1

    @property
    def session_count(self) -> int:
        """Public read-only access to the session counter."""
        return self._session_count

    @property
    def total_reassignments(self) -> int:
        """Public read-only access to the total reassignment counter."""
        return self._total_reassignments


def _is_valid_uuid(val: str) -> bool:
    try:
        UUID(val)
        return True
    except (ValueError, AttributeError):
        return False
