"""Memory lifecycle management — probation → confirmed → permanent."""

from __future__ import annotations

import logging
from datetime import datetime
from uuid import UUID

from fractal_memory._compat import utcnow
from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.storage import Storage

logger = logging.getLogger(__name__)


class LifecycleManager:
    def __init__(self, storage: Storage, config: FractalConfig) -> None:
        self._storage = storage
        self._config = config

    async def on_memory_retrieved(self, memory: Memory) -> Memory:
        """Update lifecycle after a memory is retrieved. Increments retrieval count
        and checks promotion thresholds (probation→confirmed→permanent).

        Args:
            memory: The retrieved memory to update.

        Returns:
            The updated Memory with incremented counters and possibly new lifecycle status.
        """
        memory.retrieval_count += 1
        memory.last_accessed = utcnow()
        memory.updated_at = utcnow()

        # Promotion checks
        if (
            memory.lifecycle == LifecycleStatus.PROBATION
            and memory.retrieval_count >= self._config.confirmation_threshold
        ):
            memory.lifecycle = LifecycleStatus.CONFIRMED
            logger.debug("Memory %s promoted to CONFIRMED", memory.id)

        elif memory.lifecycle == LifecycleStatus.CONFIRMED:
            if memory.retrieval_count >= self._config.permanence_threshold:
                session_count = await self._get_distinct_session_count(memory)
                if session_count >= 3:
                    memory.lifecycle = LifecycleStatus.PERMANENT
                    logger.debug("Memory %s promoted to PERMANENT", memory.id)

        await self._storage.update_memory(memory)
        return memory

    async def on_memory_missed(self, memory: Memory) -> Memory:
        memory.miss_count += 1
        memory.updated_at = utcnow()
        await self._storage.update_memory(memory)
        return memory

    async def prune_expired(self) -> list[UUID]:
        """Delete stale probation memories. Returns pruned IDs."""
        stale = await self._storage.get_probation_memories(
            self._config.pruning_ttl_sessions
        )
        pruned: list[UUID] = []
        for mem in stale:
            if mem.lifecycle in (
                LifecycleStatus.SAFETY_CRITICAL,
                LifecycleStatus.PERMANENT,
            ):
                continue
            await self._storage.delete_memory(mem.id)
            pruned.append(mem.id)
            logger.debug("Pruned probation memory %s", mem.id)
        return pruned

    async def mark_safety_critical(self, memory_id: UUID) -> None:
        mem = await self._storage.get_memory(memory_id)
        if mem is None:
            raise ValueError(f"Memory {memory_id} not found")
        mem.lifecycle = LifecycleStatus.SAFETY_CRITICAL
        mem.updated_at = utcnow()
        await self._storage.update_memory(mem)

    async def pin(self, memory_id: UUID) -> None:
        mem = await self._storage.get_memory(memory_id)
        if mem is None:
            raise ValueError(f"Memory {memory_id} not found")
        if mem.lifecycle in (LifecycleStatus.PERMANENT, LifecycleStatus.SAFETY_CRITICAL):
            # Still mark as pinned even if already permanent
            if not mem.pinned:
                mem.pinned = True
                mem.updated_at = utcnow()
                await self._storage.update_memory(mem)
            return
        mem.lifecycle = LifecycleStatus.PERMANENT
        mem.pinned = True
        mem.updated_at = utcnow()
        await self._storage.update_memory(mem)

    async def unpin(self, memory_id: UUID) -> None:
        mem = await self._storage.get_memory(memory_id)
        if mem is None:
            raise ValueError(f"Memory {memory_id} not found")
        if mem.lifecycle == LifecycleStatus.SAFETY_CRITICAL:
            return
        mem.pinned = False
        if mem.lifecycle == LifecycleStatus.PERMANENT:
            # Only demote if the memory wasn't organically PERMANENT
            organically_permanent = (
                mem.retrieval_count >= self._config.permanence_threshold
            )
            if not organically_permanent:
                mem.lifecycle = LifecycleStatus.CONFIRMED
        mem.updated_at = utcnow()
        await self._storage.update_memory(mem)

    async def _get_distinct_session_count(self, memory: Memory) -> int:
        """Count distinct sessions since this memory was created."""
        sessions = await self._storage.get_sessions_since(memory.created_at)
        return len([s for s in sessions if s.ended_at is not None])
