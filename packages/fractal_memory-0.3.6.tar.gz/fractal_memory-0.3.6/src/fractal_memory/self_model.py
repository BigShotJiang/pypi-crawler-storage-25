"""Self-model — health metrics and introspection (Phase 3)."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from fractal_memory.config import FractalConfig

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from fractal_memory.associations import AssociationNetwork
    from fractal_memory.bandits import ContextualBandit
    from fractal_memory.domains import DomainManager
    from fractal_memory.kalman import CascadeWarning
    from fractal_memory.morphogens import MorphogeneticField
    from fractal_memory.states import SystemStateManager
    from fractal_memory.storage import Storage


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class HealthReport:
    """Comprehensive health assessment of the organism."""

    retrieval_hit_rate: float
    freshness: float
    compression_ratio: float
    growth_rate: int
    total_memories: dict[str, int]         # domain → count
    domain_health: dict[str, dict]          # domain → NicheHealth as dict
    morphogen_convergence: dict             # {"converged": bool, "variance": float}
    chronic_memories_count: int
    system_state: str
    association_density: float
    scar_count: int
    bandit_arm_distribution: dict
    cascade_warnings: list                  # list[CascadeWarning]
    flagged_parameters: list[str]


@dataclass
class ExplanationReport:
    """Explanation for the last retrieval decision."""

    query: str
    retrieved_memories: list[dict]   # [{id, score, cosine, assoc_boost, scar_penalty}]
    suppressed_memories: list[dict]  # [{id, reason}]
    system_state: str
    morphogens: dict
    bandit_arm_selected: str


# ---------------------------------------------------------------------------
# SelfModel
# ---------------------------------------------------------------------------


class SelfModel:
    """Maintains a model of the organism's own knowledge and performance.

    Exposes ``health()`` and ``explain_last()`` as the P3→P4 public API.
    """

    def __init__(
        self,
        storage: "Storage",
        associations: "AssociationNetwork",
        morphogens: "MorphogeneticField",
        domains: "DomainManager",
        config: FractalConfig,
        states: "SystemStateManager | None" = None,
        bandits: "ContextualBandit | None" = None,
    ) -> None:
        self._storage = storage
        self._associations = associations
        self._morphogens = morphogens
        self._domains = domains
        self._config = config
        self._states = states
        self._bandits = bandits

        # Set by the retrieval pipeline each exchange
        self._last_query: str = ""
        self._last_retrieved: list[dict] = []
        self._last_suppressed: list[dict] = []
        self._cascade_warnings: list = []
        self._cascade_warning_log: list[dict] = []

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def cascade_warning_log(self) -> list[dict]:
        """Historical log of cascade warnings."""
        return list(self._cascade_warning_log)

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------

    async def health(self) -> HealthReport:
        """Compute and return the full health assessment.

        P3→P4 contract — provides everything the dashboard needs.
        """
        # Fetch session stats once and reuse (Issue #15)
        session_stats: dict = {}
        try:
            session_stats = await self._storage.get_session_stats()  # type: ignore[attr-defined]
        except Exception:
            pass

        # Retrieval hit rate
        try:
            hits = float(session_stats.get("retrieval_hits", 0))
            total_retrievals = float(session_stats.get("retrieval_total", 1))
            retrieval_hit_rate = hits / max(1.0, total_retrievals)
        except Exception:
            retrieval_hit_rate = 0.0

        # Memory counts per domain
        total_memories: dict[str, int] = {}
        domain_list: list = []
        try:
            domain_list = await self._domains.list_domains_with_stats()
            for d in domain_list:
                total_memories[d.name] = d.memory_count
        except Exception:
            pass

        # Association density
        association_density = 0.0
        try:
            graph_stats = await self._associations.get_stats()
            n_nodes = float(graph_stats.get("nodes_with_edges", 1))
            n_edges = float(graph_stats.get("edge_count", 0))
            association_density = n_edges / max(1.0, n_nodes)
        except Exception:
            pass

        # Scar count
        scar_count = 0
        try:
            scar_count = await self._storage.count_active_scars()  # type: ignore[attr-defined]
        except Exception:
            pass

        # Chronic memories count
        chronic_memories_count = 0
        try:
            chronic_mems = await self._storage.get_chronic_memories(  # type: ignore[attr-defined]
                threshold=self._config.chronic_promotion_threshold
            )
            chronic_memories_count = len(chronic_mems)
        except Exception:
            pass

        # Morphogen convergence
        morphogen_convergence: dict = {"converged": False, "variance": 1.0}
        try:
            converged = self._morphogens.has_converged()
            morphogen_convergence = {"converged": converged, "variance": 0.0 if converged else 1.0}
        except Exception:
            pass

        # System state
        system_state = "flow"
        if self._states is not None:
            system_state = self._states.current_state_str

        # Bandit arm distribution
        bandit_arm_distribution: dict = {}
        if self._bandits is not None:
            try:
                bandit_arm_distribution = self._bandits.get_arm_stats()
            except Exception:
                pass

        flagged_parameters = self.flag_parameter_drift()

        # Freshness: fraction of memories updated in the last 7 days
        freshness = 0.5
        try:
            recent = await self._storage.get_recent_memories(limit=100)  # type: ignore[attr-defined]
            if recent:
                from fractal_memory._compat import utcnow
                from datetime import timedelta
                now = utcnow()
                fresh_count = sum(1 for m in recent if (now - m.updated_at).days < 7)
                freshness = fresh_count / len(recent)
        except Exception:
            logger.debug("Could not compute freshness", exc_info=True)

        # Compression ratio: average zoom depth achieved
        # L3 memories with non-placeholder tags indicate full compression
        compression_ratio = 1.0
        try:
            total_count = sum(total_memories.values())
            if total_count > 0 and chronic_memories_count > 0:
                compression_ratio = max(0.1, min(5.0, total_count / max(1, chronic_memories_count)))
        except Exception:
            logger.debug("Could not compute compression_ratio", exc_info=True)

        # Growth rate: net memories stored in the latest session
        growth_rate = 0
        try:
            growth_rate = int(session_stats.get("store_total", 0)) // max(1, int(session_stats.get("session_count", 1)))
        except Exception:
            logger.debug("Could not compute growth_rate", exc_info=True)

        # Domain health: per-domain statistics
        domain_health: dict[str, dict] = {}
        try:
            for d in domain_list:
                domain_health[d.name] = {
                    "memory_count": d.memory_count,
                    "session_count": d.session_count,
                    "avg_edge_weight": d.avg_internal_edge_weight,
                    "edge_count": d.edge_count,
                }
        except Exception:
            logger.debug("Could not compute domain_health", exc_info=True)

        return HealthReport(
            retrieval_hit_rate=retrieval_hit_rate,
            freshness=freshness,
            compression_ratio=compression_ratio,
            growth_rate=growth_rate,
            total_memories=total_memories,
            domain_health=domain_health,
            morphogen_convergence=morphogen_convergence,
            chronic_memories_count=chronic_memories_count,
            system_state=system_state,
            association_density=association_density,
            scar_count=scar_count,
            bandit_arm_distribution=bandit_arm_distribution,
            cascade_warnings=list(self._cascade_warnings),
            flagged_parameters=flagged_parameters,
        )

    # ------------------------------------------------------------------
    # Explain last
    # ------------------------------------------------------------------

    async def explain_last(self) -> ExplanationReport:
        """Explain the last retrieval decision."""
        morphogen_dict: dict = {}
        if self._morphogens.last_morphogens is not None:
            ms = self._morphogens.last_morphogens
            morphogen_dict = {
                "information_richness": ms.information_richness,
                "retrieval_pressure": ms.retrieval_pressure,
                "domain_density": ms.domain_density,
            }

        bandit_arm = ""
        if self._bandits is not None:
            bandit_arm = self._bandits.current_arm or ""

        state_str = "flow"
        if self._states is not None:
            state_str = self._states.current_state_str

        return ExplanationReport(
            query=self._last_query,
            retrieved_memories=list(self._last_retrieved),
            suppressed_memories=list(self._last_suppressed),
            system_state=state_str,
            morphogens=morphogen_dict,
            bandit_arm_selected=bandit_arm,
        )

    # ------------------------------------------------------------------
    # Domain maturity
    # ------------------------------------------------------------------

    async def domain_maturity(self, domain: str) -> str:
        """Classify domain maturity for P3→P4 gate.

        Returns one of: "pioneer" | "shrub" | "forest" | "mature".
        """
        try:
            stats = await self._domains.domain_stats(domain)  # type: ignore[attr-defined]
            mem_count = stats.memory_count if stats else 0
            session_count = getattr(stats, "session_count", 0) or 0
        except Exception:
            return "pioneer"

        converged = False
        try:
            converged = self._morphogens.has_converged()
        except Exception:
            pass

        if mem_count < 30 or session_count < 5:
            return "pioneer"
        if mem_count < 100 or session_count < 15:
            return "shrub"
        if mem_count < 300 or not converged:
            return "forest"
        return "mature"

    # ------------------------------------------------------------------
    # Parameter drift detection
    # ------------------------------------------------------------------

    def flag_parameter_drift(self) -> list[str]:
        """Check for morphogen-derived parameters drifted beyond 2× initial default.

        Returns list of flagged parameter names.
        """
        flagged: list[str] = []
        try:
            for curve in self._morphogens.curves:
                current_val = self._morphogens.get_parameter(curve.name)
                if current_val is None:
                    continue
                if current_val > curve.base_value * 2 or (
                    curve.base_value > 0 and current_val < curve.base_value / 2
                ):
                    flagged.append(curve.name)
        except Exception:
            pass
        return flagged

    # ------------------------------------------------------------------
    # Update hooks (called by retrieval pipeline)
    # ------------------------------------------------------------------

    def record_retrieval(
        self,
        query: str,
        retrieved: list[dict],
        suppressed: list[dict],
    ) -> None:
        """Record the last retrieval for explain_last."""
        self._last_query = query
        self._last_retrieved = retrieved
        self._last_suppressed = suppressed

    def record_cascade_warnings(self, warnings: list) -> None:
        """Store cascade warnings for the health report."""
        self._cascade_warnings = list(warnings)

    @property
    def cascade_warnings(self) -> list:
        """Public read-only access to current cascade warnings."""
        return list(self._cascade_warnings)
