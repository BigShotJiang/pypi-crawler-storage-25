"""Scar tissue — anti-pattern records that suppress harmful retrieval patterns."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from uuid import UUID, uuid4

import numpy as np

from fractal_memory._compat import utcnow
from fractal_memory.config import FractalConfig
from fractal_memory.embeddings import EmbeddingProvider
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.storage import Storage

logger = logging.getLogger(__name__)


@dataclass
class Scar:
    """A scar record suppressing a retrieval pattern."""

    id: UUID
    pattern_embedding: list[float]
    memory_id: UUID | None  # best-effort attribution
    reason: str
    created_at: datetime
    ttl_sessions: int
    sessions_elapsed: int = 0


class ScarTissueManager:
    """Manages scar tissue — creation, penalty application, and expiry.

    Scars operate on embedding patterns (not memory IDs directly) so that a
    scar fires when a *similar query* is asked again, regardless of which
    specific memory is being scored.
    """

    def __init__(
        self,
        storage: Storage,
        embeddings: EmbeddingProvider,
        config: FractalConfig,
    ) -> None:
        self._storage = storage
        self._embeddings = embeddings
        self._config = config

    # ------------------------------------------------------------------
    # Creation
    # ------------------------------------------------------------------

    async def create_scar(
        self,
        reason: str,
        subtype: str,
        query_embedding: list[float],
        memory_ids: list[UUID],
    ) -> Scar:
        """Create a new scar record, or reset TTL on a similar existing scar.

        The pattern_embedding is set to query_embedding — this is the
        retrieval context that produced the bad outcome. TTL is determined
        by subtype severity.

        Args:
            reason: Human-readable description of why the scar was created.
            subtype: Signal subtype ('correction', 're_ask', 'rejection', 'abandonment').
            query_embedding: The retrieval context embedding.
            memory_ids: Memory IDs involved (first is used for attribution).

        Returns:
            The created (or reinforced) Scar.
        """
        # TTL by severity
        ttl = self._ttl_for_subtype(subtype)

        # Check for existing scar with similar pattern (cosine > 0.85)
        existing = await self._storage.find_scar_by_pattern(
            query_embedding, threshold=0.85
        )
        if existing is not None:
            scar_id, _ = existing
            await self._storage.reset_scar_sessions_elapsed(scar_id)
            logger.debug("Reinforced existing scar %s (TTL reset)", scar_id)
            return Scar(
                id=scar_id,
                pattern_embedding=query_embedding,
                memory_id=memory_ids[0] if memory_ids else None,
                reason=reason,
                created_at=utcnow(),
                ttl_sessions=ttl,
                sessions_elapsed=0,
            )

        memory_id = memory_ids[0] if memory_ids else None
        scar_id = uuid4()
        await self._storage.store_scar(
            scar_id=scar_id,
            pattern_embedding=query_embedding,
            memory_id=memory_id,
            reason=reason,
            ttl_sessions=ttl,
        )
        logger.info(
            "Created scar %s (subtype=%s, ttl=%d, memory_id=%s)",
            scar_id, subtype, ttl, memory_id,
        )
        return Scar(
            id=scar_id,
            pattern_embedding=query_embedding,
            memory_id=memory_id,
            reason=reason,
            created_at=utcnow(),
            ttl_sessions=ttl,
        )

    def _ttl_for_subtype(self, subtype: str) -> int:
        """Return TTL sessions based on signal severity."""
        base = self._config.scar_ttl_sessions  # default 20
        if subtype in ("correction", "rejection"):
            return base
        elif subtype in ("re_ask", "abandonment"):
            return base // 2
        else:
            return base

    # ------------------------------------------------------------------
    # Penalty application
    # ------------------------------------------------------------------

    async def apply_scar_penalty(
        self,
        query_embedding: list[float],
        scored_memories: list[tuple[Memory, float]],
    ) -> list[tuple[Memory, float]]:
        """Apply scar penalties to a scored memory list.

        For each scored memory:
        - If query pattern matches a scar (cosine > 0.7) AND the scar's
          memory_id matches: multiply score by 0.5 (direct suppression).
        - If query pattern matches but memory_id doesn't: check if memory
          was co-retrieved — apply 0.8 multiplier (weak suppression).
        - SAFETY_CRITICAL memories are exempt.

        Args:
            query_embedding: Current query embedding.
            scored_memories: List of (Memory, score) tuples.

        Returns:
            Re-scored list (same order, potentially lower scores).
        """
        active_scars = await self._storage.get_active_scars()
        if not active_scars:
            return scored_memories

        query_vec = np.array(query_embedding, dtype=np.float32)
        query_norm = np.linalg.norm(query_vec)
        if query_norm == 0:
            return scored_memories

        # Precompute which scars match the current query pattern
        matching_scars: list[tuple[UUID | None, float]] = []  # (memory_id, sim)
        for scar_id, pattern_emb, scar_memory_id, reason, ttl, elapsed, *_rest in active_scars:
            p_vec = np.array(pattern_emb, dtype=np.float32)
            p_norm = np.linalg.norm(p_vec)
            if p_norm == 0:
                continue
            sim = float(np.dot(query_vec, p_vec) / (query_norm * p_norm))
            if sim >= self._config.scar_match_threshold:
                matching_scars.append((scar_memory_id, sim))

        if not matching_scars:
            return scored_memories

        scarred_ids = {mid for mid, _ in matching_scars if mid is not None}

        # Batch-load all edges for scored memories to avoid N+1 queries (Issue #37)
        non_scarred_ids = [
            m.id for m, _ in scored_memories
            if m.id not in scarred_ids
            and m.lifecycle != LifecycleStatus.SAFETY_CRITICAL
        ]
        neighbor_map: dict[UUID, set[UUID]] = {}
        if non_scarred_ids and scarred_ids:
            for mid in non_scarred_ids:
                edges = await self._storage.get_associations(mid)
                neighbor_map[mid] = {e[0] for e in edges}

        result: list[tuple[Memory, float]] = []
        for memory, score in scored_memories:
            # Safety-critical memories are never penalised
            if memory.lifecycle == LifecycleStatus.SAFETY_CRITICAL:
                result.append((memory, score))
                continue

            if memory.id in scarred_ids:
                # Direct attribution — aggressive penalty
                new_score = score * self._config.scar_direct_penalty
                logger.debug(
                    "Scar direct penalty on memory %s: %.3f -> %.3f",
                    memory.id, score, new_score,
                )
                result.append((memory, new_score))
            else:
                # Indirect penalty — check pre-loaded neighbors
                neighbors = neighbor_map.get(memory.id, set())
                if neighbors & scarred_ids:
                    new_score = score * self._config.scar_indirect_penalty
                    logger.debug(
                        "Scar indirect penalty on memory %s: %.3f -> %.3f",
                        memory.id, score, new_score,
                    )
                    result.append((memory, new_score))
                else:
                    result.append((memory, score))

        return result

    # ------------------------------------------------------------------
    # Expiry
    # ------------------------------------------------------------------

    async def expire_scars(self) -> int:
        """Increment sessions_elapsed and delete expired scars.

        Called at session_end.

        Returns:
            Count of scars expired and deleted.
        """
        await self._storage.increment_scar_sessions()
        count = await self._storage.delete_expired_scars()
        if count:
            logger.info("Expired %d scars", count)
        return count

    # ------------------------------------------------------------------
    # Access
    # ------------------------------------------------------------------

    async def get_active_scars(self) -> list[Scar]:
        """Return all non-expired scars as Scar objects."""
        from datetime import datetime
        raw = await self._storage.get_active_scars()
        return [
            Scar(
                id=scar_id,
                pattern_embedding=pattern_emb,
                memory_id=scar_memory_id,
                reason=reason,
                created_at=datetime.fromisoformat(created_at_str),
                ttl_sessions=ttl,
                sessions_elapsed=elapsed,
            )
            for scar_id, pattern_emb, scar_memory_id, reason, ttl, elapsed, created_at_str in raw
        ]
