"""Tiered maintenance scheduler (Phase 3) — intra-session / session-end / daily / weekly / monthly."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import TYPE_CHECKING

from fractal_memory._compat import utcnow
from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from fractal_memory.apoptosis import ApoptosisManager
    from fractal_memory.consolidation import ConsolidationEngine
    from fractal_memory.dreaming import DreamingEngine
    from fractal_memory.folding import DimensionalFolder
    from fractal_memory.kalman import CircuitBreaker
    from fractal_memory.niche import NicheConstructor
    from fractal_memory.self_model import HealthReport, SelfModel
    from fractal_memory.storage import Storage


# ---------------------------------------------------------------------------
# Data class
# ---------------------------------------------------------------------------


@dataclass
class MaintenanceReport:
    """Summary of actions taken by a maintenance cycle."""

    tier: str  # "intra_session" | "session_end" | "daily" | "weekly" | "monthly"
    actions_taken: dict[str, int] = field(default_factory=dict)
    duration_seconds: float = 0.0
    health_snapshot: "HealthReport | None" = None
    errors: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Tier names
# ---------------------------------------------------------------------------

_DAILY = "daily"
_WEEKLY = "weekly"
_MONTHLY = "monthly"


# ---------------------------------------------------------------------------
# MaintenanceScheduler
# ---------------------------------------------------------------------------


class MaintenanceScheduler:
    """Orchestrates tiered maintenance across all subsystems.

    Daily/weekly/monthly maintenance is triggered on session_start (no external
    cron dependency).  Intra-session maintenance runs during long sessions.
    """

    def __init__(
        self,
        storage: "Storage",
        consolidation: "ConsolidationEngine",
        dreaming: "DreamingEngine",
        apoptosis: "ApoptosisManager",
        niche: "NicheConstructor",
        self_model: "SelfModel",
        folding: "DimensionalFolder",
        cascade: "CircuitBreaker",
        config: FractalConfig,
    ) -> None:
        self._storage = storage
        self._consolidation = consolidation
        self._dreaming = dreaming
        self._apoptosis = apoptosis
        self._niche = niche
        self._self_model = self_model
        self._folding = folding
        self._cascade = cascade
        self._config = config

        # Intra-session tracking
        self._last_intra_session_run: datetime | None = None
        self._intra_session_turn_count: int = 0
        # Dashboard-visible state
        self._last_report: MaintenanceReport | None = None
        self._tier_run_log: list[dict] = []
        self._report_history: list[MaintenanceReport] = []

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def last_intra_session_run(self) -> datetime | None:
        """Timestamp of the last intra-session maintenance run."""
        return self._last_intra_session_run

    @property
    def intra_session_turn_count(self) -> int:
        """Turn count at the last intra-session maintenance check."""
        return self._intra_session_turn_count

    @property
    def last_report(self) -> MaintenanceReport | None:
        """The most recent maintenance report."""
        return self._last_report

    @property
    def tier_run_log(self) -> list[dict]:
        """Log of tier-level maintenance runs."""
        return list(self._tier_run_log)

    @property
    def report_history(self) -> list[MaintenanceReport]:
        """History of maintenance reports."""
        return list(self._report_history)

    # ------------------------------------------------------------------
    # Intra-session (lightweight)
    # ------------------------------------------------------------------

    async def intra_session_maintenance(
        self,
        session_start_time: datetime,
        turn_count: int,
    ) -> bool:
        """Run lightweight intra-session maintenance if conditions are met.

        Triggers when:
        - elapsed time > long_session_threshold_minutes
        - it has been > intra_session_interval_minutes since last run
        - turn_count > 30

        No LLM calls — purely local computation.

        Returns:
            True if maintenance ran.
        """
        now = utcnow()
        elapsed_minutes = (now - session_start_time).total_seconds() / 60.0

        if elapsed_minutes <= self._config.long_session_threshold_minutes:
            return False
        if turn_count <= 30:
            return False
        if self._last_intra_session_run is not None:
            since_last = (now - self._last_intra_session_run).total_seconds() / 60.0
            if since_last <= self._config.intra_session_interval_minutes:
                return False

        # Perform lightweight maintenance
        try:
            await self._consolidation.merge_duplicates(similarity_threshold=0.90)
        except Exception:
            logger.warning("Intra-session merge_duplicates failed", exc_info=True)

        self._last_intra_session_run = now
        return True

    # ------------------------------------------------------------------
    # Session-end (standard)
    # ------------------------------------------------------------------

    async def session_end_maintenance(self, session_data: dict) -> MaintenanceReport:
        """Standard session-end maintenance pipeline.

        Runs in order:
        1. dreaming (slow-wave + REM + dawn)
        2. consolidation
        3. update vitality + chronic scores
        4. update folded stats
        5. cascade detection
        6. health snapshot
        """
        t_start = time.monotonic()
        actions: dict[str, int] = {}
        errors: list[str] = []

        session_memories = session_data.get("session_memory_ids", [])
        domain = session_data.get("domain", self._config.default_domain)

        # 1. Dreaming
        try:
            dream_report = await self._dreaming.dream_cycle(session_memories)
            actions["edges_pruned"] = dream_report.slow_wave.edges_pruned
            actions["rem_syntheses_stored"] = dream_report.rem.syntheses_stored
        except Exception:
            logger.exception("Maintenance step 1 (dreaming) failed")
            errors.append("dreaming")

        # 2. Consolidation (skipped — handled by _hook_consolidation)
        # Consolidation already runs as Hook 3 in session_end. Running it
        # again here would duplicate work. See _hook_consolidation.

        # 3. Update vitality + chronic scores
        try:
            accessed_ids = session_data.get("accessed_memory_ids", [])
            updated = await self._storage.update_vitality_batch(accessed_ids)  # type: ignore[attr-defined]
            actions["vitality_updated"] = updated
            updated_c = await self._storage.update_chronic_batch(accessed_ids)  # type: ignore[attr-defined]
            actions["chronic_updated"] = updated_c
        except Exception:
            logger.exception("Maintenance step 3 (vitality/chronic) failed")
            errors.append("vitality_chronic")

        # 4. Update folded stats
        try:
            stats: dict[str, float] = {}
            edge_stats = await self._storage.get_edge_stats()  # type: ignore[attr-defined]
            stats["associations"] = float(edge_stats.get("mean_weight", 0.0))
            self._folding.update_folded_stats(stats)
        except Exception:
            logger.exception("Maintenance step 4 (folded stats) failed")
            errors.append("folded_stats")

        # 5. Cascade detection
        cascade_warning = None
        try:
            session_metrics = session_data.get("session_metrics", {})
            cascade_warning = self._cascade.observe(session_metrics)
            if cascade_warning is not None:
                self._self_model.record_cascade_warnings([cascade_warning])
                actions["cascade_warnings"] = 1
        except Exception:
            logger.exception("Maintenance step 5 (cascade detection) failed")
            errors.append("cascade")

        # 6. Health snapshot
        health_snapshot = None
        try:
            health_snapshot = await self._self_model.health()
        except Exception:
            logger.exception("Maintenance step 6 (health snapshot) failed")
            errors.append("health")

        # 7. Auto-demote zombie PERMANENT memories
        try:
            demoted = await self._demote_zombie_permanent(domain)
            if demoted:
                actions["permanent_demoted"] = demoted
        except Exception:
            logger.exception("Maintenance step 7 (zombie demotion) failed")
            errors.append("zombie_demotion")

        duration = time.monotonic() - t_start
        return MaintenanceReport(
            tier="session_end",
            actions_taken=actions,
            duration_seconds=duration,
            health_snapshot=health_snapshot,
            errors=errors,
        )

    # ------------------------------------------------------------------
    # Scheduled tiers
    # ------------------------------------------------------------------

    async def daily_maintenance(self) -> MaintenanceReport:
        """Lightweight background maintenance (triggered if >24h since last run)."""
        t_start = time.monotonic()
        actions: dict[str, int] = {}
        errors: list[str] = []

        try:
            pruned = await self._consolidation.prune_expired()
            actions["pruned"] = pruned
        except Exception:
            logger.exception("Daily maintenance: prune_expired failed")
            errors.append("prune_expired")

        try:
            weakened = await self._storage.weaken_unused_edges()  # type: ignore[attr-defined]
            actions["edges_weakened"] = weakened
        except Exception:
            logger.exception("Daily maintenance: weaken_unused_edges failed")
            errors.append("weaken_edges")

        try:
            updated = await self._storage.update_vitality_all()  # type: ignore[attr-defined]
            actions["vitality_updated"] = updated
        except Exception:
            logger.exception("Daily maintenance: update_vitality_all failed")
            errors.append("vitality_all")

        await self._storage.set_maintenance_log(_DAILY, utcnow())  # type: ignore[attr-defined]
        duration = time.monotonic() - t_start
        return MaintenanceReport(tier=_DAILY, actions_taken=actions, duration_seconds=duration, errors=errors)

    async def weekly_maintenance(self) -> MaintenanceReport:
        """Deeper pattern detection (triggered if >7d since last run)."""
        t_start = time.monotonic()
        actions: dict[str, int] = {}
        errors: list[str] = []

        # Louvain domain clustering
        try:
            proposals = await self._niche.detect_domain_clusters()
            applied = await self._niche.apply_domain_proposals(proposals)
            actions["domain_reassignments"] = applied
        except Exception:
            logger.exception("Weekly maintenance: domain clustering failed")
            errors.append("domain_clustering")

        await self._storage.set_maintenance_log(_WEEKLY, utcnow())  # type: ignore[attr-defined]
        duration = time.monotonic() - t_start
        return MaintenanceReport(tier=_WEEKLY, actions_taken=actions, duration_seconds=duration, errors=errors)

    async def monthly_maintenance(self) -> MaintenanceReport:
        """Major restructuring (triggered if >30d since last run)."""
        import numpy as np

        t_start = time.monotonic()
        actions: dict[str, int] = {}
        errors: list[str] = []

        # Apoptosis batch check + execution (all domains) — Issues #3, #31
        try:
            domain_list = await self._storage.list_domains_with_counts()  # type: ignore[attr-defined]
            total_candidates = 0
            total_executed = 0
            for domain_info in domain_list:
                # Compute domain centroid instead of zero-vector (Issue #31)
                domain_embeddings = await self._storage.get_all_embeddings(domain_info["domain"])
                if domain_embeddings:
                    emb_matrix = np.array([vec for _, vec in domain_embeddings], dtype=np.float32)
                    ctx_emb = np.mean(emb_matrix, axis=0)
                else:
                    ctx_emb = np.zeros(self._config.embedding_dim, dtype=np.float32)
                decisions = await self._apoptosis.batch_check(
                    domain_info["domain"], ctx_emb
                )
                total_candidates += len(decisions)
                # Execute apoptosis on candidates (Issue #3)
                for decision in decisions:
                    if decision.should_apoptose:
                        try:
                            memory = await self._storage.get_memory(decision.memory_id)
                            if memory is not None:
                                await self._apoptosis.execute_apoptosis(memory, decision.reason)
                                total_executed += 1
                        except Exception:
                            logger.debug("Apoptosis execution failed for %s", decision.memory_id, exc_info=True)
            actions["apoptosis_candidates"] = total_candidates
            actions["apoptosis_executed"] = total_executed
        except Exception:
            logger.exception("Monthly maintenance: apoptosis batch check failed")
            errors.append("apoptosis_batch")

        # Parameter drift check
        try:
            flagged = self._self_model.flag_parameter_drift()
            actions["flagged_parameters"] = len(flagged)
        except Exception:
            logger.exception("Monthly maintenance: parameter drift check failed")
            errors.append("parameter_drift")

        # Full health assessment
        health_snapshot = None
        try:
            health_snapshot = await self._self_model.health()
        except Exception:
            logger.exception("Monthly maintenance: health assessment failed")
            errors.append("health")

        await self._storage.set_maintenance_log(_MONTHLY, utcnow())  # type: ignore[attr-defined]
        duration = time.monotonic() - t_start
        return MaintenanceReport(
            tier=_MONTHLY,
            actions_taken=actions,
            duration_seconds=duration,
            health_snapshot=health_snapshot,
            errors=errors,
        )

    # ------------------------------------------------------------------
    # Zombie demotion
    # ------------------------------------------------------------------

    async def _demote_zombie_permanent(self, domain: str) -> int:
        """Demote PERMANENT memories with chronic_score below threshold.

        A PERMANENT memory whose chronic_score has decayed below the promotion
        threshold is a zombie — it consumes bootstrap budget but never
        contributes.  Demoting it to CONFIRMED lets normal lifecycle
        (apoptosis, pruning) reclaim it if it remains unused.

        Returns:
            Number of memories demoted.
        """
        permanent = await self._storage.get_memories_by_lifecycle(  # type: ignore[attr-defined]
            LifecycleStatus.PERMANENT
        )
        threshold = self._config.chronic_promotion_threshold
        demoted = 0
        for mem in permanent:
            if mem.domain != domain:
                continue
            if mem.lifecycle == LifecycleStatus.SAFETY_CRITICAL:
                continue
            if mem.pinned:
                continue
            if mem.chronic_score < threshold:
                mem.lifecycle = LifecycleStatus.CONFIRMED
                mem.updated_at = utcnow()
                await self._storage.update_memory(mem)  # type: ignore[attr-defined]
                logger.info(
                    "Demoted zombie PERMANENT memory %s (chronic=%.3f < %.3f)",
                    mem.id, mem.chronic_score, threshold,
                )
                demoted += 1
        return demoted

    # ------------------------------------------------------------------
    # Schedule checking
    # ------------------------------------------------------------------

    async def should_run_scheduled(self, schedule: str) -> bool:
        """Check if a scheduled maintenance cycle should run.

        Reads last-run timestamp from the ``maintenance_log`` table.
        """
        intervals: dict[str, timedelta] = {
            _DAILY: timedelta(days=1),
            _WEEKLY: timedelta(days=7),
            _MONTHLY: timedelta(days=30),
        }
        if schedule not in intervals:
            return False

        try:
            log = await self._storage.get_maintenance_log(schedule)  # type: ignore[attr-defined]
            if log is None:
                return True
            last_run = log
            return utcnow() - last_run >= intervals[schedule]
        except Exception:
            return True
