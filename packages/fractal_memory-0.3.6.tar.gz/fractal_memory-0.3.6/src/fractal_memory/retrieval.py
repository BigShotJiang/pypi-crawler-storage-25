"""Retrieval engine — scoring pipeline + progressive injection."""

from __future__ import annotations

import logging
from uuid import UUID

import numpy as np

from fractal_memory.config import FractalConfig
from fractal_memory.embeddings import EmbeddingProvider
from fractal_memory.models import LifecycleStatus, Memory, RetrievalResult
from fractal_memory.storage import Storage

logger = logging.getLogger(__name__)


class RetrievalEngine:
    """Scoring pipeline + progressive injection.

    Phase 2 extensions (all optional for backward compatibility):
    - association_boost via AssociationNetwork.spreading_activation()
    - scar_penalty via ScarTissueManager.apply_scar_penalty()
    - habituation filtering via WorkingMemoryBuffer.is_habituated()
    """

    def __init__(
        self,
        storage: Storage,
        embeddings: EmbeddingProvider,
        config: FractalConfig,
        associations: object | None = None,   # AssociationNetwork | None
        scars: object | None = None,           # ScarTissueManager | None
        buffer: object | None = None,          # WorkingMemoryBuffer | None
    ) -> None:
        self._storage = storage
        self._embeddings = embeddings
        self._config = config
        self._associations = associations  # Phase 2+
        self._scars = scars                # Phase 2+
        self._buffer = buffer              # Phase 2+
        # Embedding cache per domain — avoids repeated numpy array allocation (Issue #49)
        self._embedding_cache: dict[str, tuple[list[UUID], np.ndarray]] = {}
        self._cache_dirty: set[str] = set()

    def invalidate_cache(self, domain: str | None = None) -> None:
        """Mark domain embedding cache as dirty. Called after store/delete (Issue #49)."""
        if domain is None:
            self._embedding_cache.clear()
        else:
            self._embedding_cache.pop(domain, None)

    async def _get_cached_embeddings(
        self, domain: str,
    ) -> tuple[list[UUID], np.ndarray]:
        """Return (ids, numpy_matrix) for a domain, using cache when available."""
        if domain not in self._embedding_cache:
            all_embeddings = await self._storage.get_all_embeddings(domain)
            if not all_embeddings:
                return [], np.empty((0, 0), dtype=np.float32)
            ids = [eid for eid, _ in all_embeddings]
            vecs = np.array([vec for _, vec in all_embeddings], dtype=np.float32)
            self._embedding_cache[domain] = (ids, vecs)
        return self._embedding_cache[domain]

    async def retrieve(
        self,
        query: str,
        domain: str | None = None,
        token_budget: int | None = None,
        overrides: dict[str, float] | None = None,
    ) -> RetrievalResult:
        """Retrieve memories matching a query using progressive injection.

        Scores all domain memories by cosine similarity + intensity weighting,
        selects top-N at each zoom level (L1/L2/L3), and applies pressure
        response if the token budget is exceeded.

        Args:
            query: Search query text.
            domain: Domain to search in. Defaults to config.default_domain.
            token_budget: Override token budget. Defaults to config.memory_token_budget.
            overrides: Phase 3 morphogen-derived parameter overrides. Keys may include
                ``retrieval_breadth``, ``activation_decay``, ``gate_strictness``, etc.

        Note: L3 ⊂ L2 ⊂ L1 by ranked score. This is intentional — each tier
        represents the top N memories, not exclusive slices. Token budget
        estimation in ``_estimate_result_tokens`` handles deduplication
        internally. See ``FRACTAL_MEMORY.md`` retrieval pipeline design.

        Args:
            query: Search query text.
            domain: Domain to search in. Defaults to config.default_domain.
            token_budget: Override token budget. Defaults to config.memory_token_budget.

        Returns:
            RetrievalResult with L3/L2/L1 memories, hints, and budget usage.
        """
        if domain is None:
            domain = self._config.default_domain

        if token_budget is not None:
            if token_budget <= 0:
                raise ValueError(f"token_budget must be > 0, got {token_budget}")
            budget = token_budget
        else:
            budget = self._config.memory_token_budget

        # 1. Embed query
        query_vec = await self._embeddings.embed(query)

        # 2. Load all embeddings for domain (cached numpy array — Issue #49)
        ids, vecs_array = await self._get_cached_embeddings(domain)
        if len(ids) == 0:
            return RetrievalResult(token_budget_total=budget)

        # 3. Score
        cosine_scores = self._cosine_similarity_batch_np(query_vec, vecs_array)

        # 4. Load intensity for weighting
        memories_by_id: dict[UUID, Memory] = {}
        all_memories = await self._storage.get_memories_by_ids(ids)
        for m in all_memories:
            memories_by_id[m.id] = m

        # 5. Final score = cosine * w_cos + intensity * w_int
        w_cos = self._config.scoring_cosine_weight
        w_int = self._config.scoring_intensity_weight
        scored: list[tuple[UUID, float]] = []
        for uid, cos_sim in zip(ids, cosine_scores):
            mem = memories_by_id.get(uid)
            intensity = mem.intensity if mem else 0.5
            final_score = cos_sim * w_cos + intensity * w_int
            scored.append((uid, final_score))

        # 4a. Apply scar penalty (Phase 2+)
        if self._scars is not None and self._config.enable_scar_penalty:
            hydrated_for_scar = list(zip(
                [memories_by_id[uid] for uid in ids if uid in memories_by_id],
                [s for uid, s in scored if uid in memories_by_id],
            ))
            # Re-pair with original scored list after penalty
            penalised = await self._scars.apply_scar_penalty(query_vec, hydrated_for_scar)  # type: ignore[union-attr]
            id_to_score: dict[UUID, float] = {m.id: s for m, s in penalised}
            scored = [(uid, id_to_score.get(uid, sc)) for uid, sc in scored]

        # 4b. Spreading activation boost (Phase 2+)
        if self._associations is not None and self._config.enable_spreading_activation:
            top_seeds = [uid for uid, _ in scored[:self._config.top_l3]]
            boosts = await self._associations.spreading_activation(top_seeds)  # type: ignore[union-attr]
            scored = [
                (uid, sc + boosts.get(uid, 0.0) * self._config.association_boost_weight)
                for uid, sc in scored
            ]

        scored.sort(key=lambda x: x[1], reverse=True)

        # 6. Progressive injection: 200/50/10 split
        # Phase 3: morphogen overrides can tune retrieval_breadth → top_l1 count
        eff_top_l1 = self._config.top_l1
        if overrides and "retrieval_breadth" in overrides:
            # retrieval_breadth is a multiplier (1.0 = default)
            eff_top_l1 = max(1, int(self._config.top_l1 * overrides["retrieval_breadth"]))
        top_l1 = min(eff_top_l1, len(scored))
        top_l2 = min(self._config.top_l2, len(scored))
        top_l3 = min(self._config.top_l3, len(scored))

        l1_ids = [uid for uid, _ in scored[:top_l1]]
        l2_ids = [uid for uid, _ in scored[:top_l2]]
        l3_ids = [uid for uid, _ in scored[:top_l3]]

        # 7. Hydrate
        l1_memories = [memories_by_id[uid] for uid in l1_ids if uid in memories_by_id]
        l2_memories = [memories_by_id[uid] for uid in l2_ids if uid in memories_by_id]
        l3_memories = [memories_by_id[uid] for uid in l3_ids if uid in memories_by_id]

        # 8. Token budget tracking
        token_used = self._estimate_result_tokens(l1_memories, l2_memories, l3_memories)

        # 9. Pressure response
        result = RetrievalResult(
            l3_memories=l3_memories,
            l2_memories=l2_memories,
            l1_memories=l1_memories,
            hints=[],
            token_budget_used=token_used,
            token_budget_total=budget,
        )
        if token_used > budget:
            result = self._apply_pressure(result, budget)

        # 9a. Filter habituated memories from injection (Phase 2+)
        if self._buffer is not None:
            l3_memories = self._filter_habituated(result.l3_memories)
            l2_memories = self._filter_habituated(result.l2_memories)
            token_used_after = self._estimate_result_tokens(result.l1_memories, l2_memories, l3_memories)
            result = RetrievalResult(
                l3_memories=l3_memories,
                l2_memories=l2_memories,
                l1_memories=result.l1_memories,
                hints=result.hints,
                token_budget_used=token_used_after,
                token_budget_total=budget,
            )

        # 9b. Record co-retrieval for association formation (Phase 2+)
        # Exclude L3 IDs from L2 call to avoid double-counting (Issue #14)
        if self._associations is not None:
            l3_id_set = {m.id for m in l3_memories}
            l2_only_ids = [m.id for m in l2_memories if m.id not in l3_id_set]
            l3_ids_for_assoc = [m.id for m in l3_memories]
            if l2_only_ids:
                await self._associations.on_co_retrieval(l2_only_ids, zoom_level=2)  # type: ignore[union-attr]
            if l3_ids_for_assoc:
                await self._associations.on_co_retrieval(l3_ids_for_assoc, zoom_level=3)  # type: ignore[union-attr]

        # 9c. Enter refractory for L3-injected memories (Phase 2+)
        if self._associations is not None and l3_memories:
            await self._associations.enter_refractory([m.id for m in l3_memories])  # type: ignore[union-attr]

        # 9d. Advance refractory turn counter (Phase 2+)
        if self._associations is not None:
            self._associations.advance_turn()  # type: ignore[union-attr]

        # 10. Hints: near-miss memories
        hint_start = top_l1
        hint_end = min(hint_start + self._config.hint_window_size, len(scored))
        if hint_end > hint_start:
            hint_ids = [uid for uid, _ in scored[hint_start:hint_end]]
            min_score = self._config.hint_min_score
            scores_by_id = dict(scored)
            hints = []
            for uid in hint_ids:
                s = scores_by_id.get(uid, 0.0)
                if s >= min_score and uid in memories_by_id:
                    hints.append(memories_by_id[uid])
            result.hints = hints

        return result

    async def score(
        self, query: str, domain: str | None = None
    ) -> list[tuple[Memory, float]]:
        """Public scoring interface — P1→P2 contract.

        Includes Phase 2 modifiers (scar penalty + association boost) when
        the respective modules are wired in.
        """
        if domain is None:
            domain = self._config.default_domain

        query_vec = await self._embeddings.embed(query)
        all_embeddings = await self._storage.get_all_embeddings(domain)
        if not all_embeddings:
            return []

        ids = [eid for eid, _ in all_embeddings]
        vecs = [vec for _, vec in all_embeddings]
        cosine_scores = self._cosine_similarity_batch(query_vec, vecs)

        memories_by_id: dict[UUID, Memory] = {}
        for m in await self._storage.get_memories_by_ids(ids):
            memories_by_id[m.id] = m

        scored: list[tuple[UUID, float]] = []
        for uid, cos_sim in zip(ids, cosine_scores):
            mem = memories_by_id.get(uid)
            if mem is None:
                continue
            final_score = (
                cos_sim * self._config.scoring_cosine_weight
                + mem.intensity * self._config.scoring_intensity_weight
            )
            scored.append((uid, final_score))

        # Phase 2 scar penalty
        if self._scars is not None and self._config.enable_scar_penalty:
            hydrated = [(memories_by_id[uid], sc) for uid, sc in scored if uid in memories_by_id]
            penalised = await self._scars.apply_scar_penalty(query_vec, hydrated)  # type: ignore[union-attr]
            id_to_score = {m.id: s for m, s in penalised}
            scored = [(uid, id_to_score.get(uid, sc)) for uid, sc in scored]

        # Phase 2 association boost
        if self._associations is not None and self._config.enable_spreading_activation:
            top_seeds = [uid for uid, _ in sorted(scored, key=lambda x: x[1], reverse=True)[:self._config.top_l3]]
            boosts = await self._associations.spreading_activation(top_seeds)  # type: ignore[union-attr]
            scored = [
                (uid, sc + boosts.get(uid, 0.0) * self._config.association_boost_weight)
                for uid, sc in scored
            ]

        results: list[tuple[Memory, float]] = [
            (memories_by_id[uid], sc)
            for uid, sc in scored
            if uid in memories_by_id
        ]
        results.sort(key=lambda x: x[1], reverse=True)
        return results

    def _filter_habituated(self, memories: list[Memory]) -> list[Memory]:
        """Remove habituated memories from injection. SAFETY_CRITICAL are exempt."""
        if self._buffer is None:
            return memories
        return [
            m for m in memories
            if m.lifecycle == LifecycleStatus.SAFETY_CRITICAL
            or not self._buffer.is_habituated(m.id)  # type: ignore[union-attr]
        ]

    def _cosine_similarity_batch(
        self, query_vec: list[float], memory_vecs: list[list[float]]
    ) -> list[float]:
        m = np.array(memory_vecs, dtype=np.float32)
        return self._cosine_similarity_batch_np(query_vec, m)

    def _cosine_similarity_batch_np(
        self, query_vec: list[float], m: np.ndarray,
    ) -> list[float]:
        """Cosine similarity against a pre-built numpy matrix (Issue #49)."""
        q = np.array(query_vec, dtype=np.float32)
        q_norm = np.linalg.norm(q)
        if q_norm == 0:
            return [0.0] * m.shape[0]
        q = q / q_norm
        m_norms = np.linalg.norm(m, axis=1, keepdims=True)
        # Zero-vector memories get similarity 0.0 — not a valid unit vector (Issue #6)
        zero_mask = (m_norms.squeeze() == 0)
        m_norms = np.where(m_norms == 0, 1.0, m_norms)  # avoid division by zero
        m_normed = m / m_norms
        sims = m_normed @ q
        sims[zero_mask] = 0.0  # force zero-vector similarity to 0.0
        return sims.tolist()

    def _estimate_tokens(self, text: str) -> int:
        """Estimate token count with CJK-aware heuristic (Issue #7).

        CJK characters typically map to 1-2 tokens each, not 0.25.
        Latin/ASCII characters average ~4 chars per token.
        """
        weighted = sum(2 if ord(c) > 0x2E80 else 1 for c in text)
        return max(1, weighted // 4)

    def _estimate_result_tokens(
        self,
        l1_memories: list[Memory],
        l2_memories: list[Memory],
        l3_memories: list[Memory],
    ) -> int:
        total = 0
        l3_ids = {m.id for m in l3_memories}
        l2_ids = {m.id for m in l2_memories}

        for m in l3_memories:
            total += self._estimate_tokens(m.l3_full)
        for m in l2_memories:
            if m.id not in l3_ids:
                total += self._estimate_tokens(m.l2_summary)
        for m in l1_memories:
            if m.id not in l3_ids and m.id not in l2_ids:
                total += self._estimate_tokens(m.l1_label)
        return total

    def _apply_pressure(
        self, result: RetrievalResult, budget: int
    ) -> RetrievalResult:
        """Demote lowest-scored memories from L3→L2 and L2→L1 until under budget."""
        l3 = list(result.l3_memories)
        l2 = list(result.l2_memories)
        l1 = list(result.l1_memories)

        while self._estimate_result_tokens(l1, l2, l3) > budget and len(l3) > 0:
            # Demote lowest-scored L3 to L2 only
            demoted = l3.pop()
            # It's already in L2 (since L2 ⊃ L3 in ranked list)

        while self._estimate_result_tokens(l1, l2, l3) > budget and len(l2) > len(l3):
            # Demote lowest-scored L2 to L1 only
            l2.pop()
            # It's already in L1 (since L1 ⊃ L2)

        token_used = self._estimate_result_tokens(l1, l2, l3)
        return RetrievalResult(
            l3_memories=l3,
            l2_memories=l2,
            l1_memories=l1,
            hints=result.hints,
            token_budget_used=token_used,
            token_budget_total=budget,
        )
