"""Morphogenetic fields + allosteric self-correction (B-1, B-11, Phase 3).

Computes 3 morphogen signals from observable session state and maps them to
system parameters via learnable response curves.  Curves are self-corrected at
session_end using the LLM judge score (policy gradient, B-11).
"""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING

from fractal_memory._compat import utcnow

import numpy as np

from fractal_memory.config import FractalConfig

if TYPE_CHECKING:
    from fractal_memory.domains import DomainManager
    from fractal_memory.embeddings import EmbeddingProvider
    from fractal_memory.feedback import DangerTheoryDetector
    from fractal_memory.storage import Storage


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class MorphogenState:
    """Snapshot of the three morphogen signals at a point in time."""

    information_richness: float  # 0–1: novel info being provided by user
    retrieval_pressure: float    # 0–1: how precise/urgent the user's needs are
    domain_density: float        # 0–1: how populated the current domain is
    timestamp: datetime = field(default_factory=utcnow)


@dataclass
class ResponseCurve:
    """One parameter's deterministic function of morphogen inputs.

    The learnable variables ``midpoint`` and ``steepness`` are updated by B-11
    at session_end.
    """

    name: str                           # parameter name, e.g. "gate_strictness"
    morphogen_weights: dict[str, float]  # morphogen → coefficient
    base_value: float                   # pre-morphogen default
    midpoint: float                     # B-11 learnable: sigmoid centre
    steepness: float                    # B-11 learnable: sigmoid slope
    min_value: float                    # hard floor
    max_value: float                    # hard ceiling

    def compute(self, morphogens: MorphogenState) -> float:
        """Apply the weighted sigmoid to produce a parameter value.

        Formula::

            x = sum(weight * getattr(morphogens, name)
                    for name, weight in morphogen_weights.items())
            sigmoid = 1 / (1 + exp(-steepness * (x - midpoint)))
            result = base_value + (max_value - base_value) * sigmoid

        Result clamped to [min_value, max_value].
        """
        x = 0.0
        for morph_name, weight in self.morphogen_weights.items():
            val = float(getattr(morphogens, morph_name, 0.0))
            if math.isnan(val) or math.isinf(val):
                val = 0.0
            x += weight * val
        try:
            sig = 1.0 / (1.0 + math.exp(-self.steepness * (x - self.midpoint)))
        except OverflowError:
            sig = 0.0 if x < self.midpoint else 1.0
        result = self.base_value + (self.max_value - self.base_value) * sig
        return max(self.min_value, min(self.max_value, result))


# ---------------------------------------------------------------------------
# Allosteric updater (B-11)
# ---------------------------------------------------------------------------


class AllostericUpdater:
    """Policy-gradient updates for response curve midpoint and steepness.

    Maintains a per-curve exponential moving average of judge scores.
    """

    def __init__(self, alpha: float = 0.05, ema_window: int = 10) -> None:
        self._alpha = alpha
        self._ema_window = ema_window
        # curve_name → deque of recent judge scores
        self._score_history: dict[str, deque[float]] = {}
        # curve_name → current EMA
        self._ema: dict[str, float] = {}

    def _rolling_mean(self, curve_name: str) -> float:
        history = self._score_history.get(curve_name)
        if not history:
            return 0.5  # neutral prior
        return float(np.mean(list(history)))

    def update(
        self,
        curve: ResponseCurve,
        judge_score: float,
        morphogens: MorphogenState,
    ) -> None:
        """Apply B-11 policy gradient update to curve midpoint and steepness.

        Steps:
        1. ``delta = judge_score - rolling_mean``
        2. Move midpoint toward current morphogen input when delta > 0.
        3. Adjust steepness proportional to signal strength.
        4. Clamp midpoint to [0, 1], steepness to [1, 50].
        """
        name = curve.name
        if name not in self._score_history:
            self._score_history[name] = deque(maxlen=self._ema_window)
        self._score_history[name].append(judge_score)

        # Track per-morphogen scores for competitive_inhibition (B-11)
        for morph_name in curve.morphogen_weights:
            composite_key = f"{name}_{morph_name}"
            if composite_key not in self._score_history:
                self._score_history[composite_key] = deque(maxlen=self._ema_window)
            self._score_history[composite_key].append(judge_score)

        rolling_mean = self._rolling_mean(name)
        delta = judge_score - rolling_mean

        # Morphogen input for this curve
        morph_input = sum(
            w * getattr(morphogens, m, 0.0)
            for m, w in curve.morphogen_weights.items()
        )

        # Update midpoint
        direction = math.copysign(1.0, morph_input - curve.midpoint)
        curve.midpoint = curve.midpoint + self._alpha * delta * direction
        curve.midpoint = max(0.0, min(1.0, curve.midpoint))

        # Update steepness
        curve.steepness = curve.steepness + self._alpha * delta * (
            abs(morph_input - curve.midpoint) - curve.steepness * 0.1
        )
        curve.steepness = max(1.0, min(50.0, curve.steepness))

    def competitive_inhibition(
        self,
        curves: list[ResponseCurve],
        morphogens: MorphogenState,
    ) -> None:
        """Reduce weight of morphogen with worse recent accuracy.

        When two morphogens push a parameter in opposite directions, the one
        with worse recent prediction (lower EMA score when it dominated) has
        its weight reduced by 20%.  Prevents oscillation.
        """
        for curve in curves:
            if len(curve.morphogen_weights) < 2:
                continue
            # Find morphogen with lowest recent EMA contribution
            scores_by_morph: dict[str, float] = {}
            for morph_name, weight in curve.morphogen_weights.items():
                contrib = weight * getattr(morphogens, morph_name, 0.0)
                scores_by_morph[morph_name] = abs(contrib)

            if not scores_by_morph:
                continue

            # Check if two morphogens push in opposite directions
            weights_list = list(curve.morphogen_weights.values())
            if not any(w > 0 for w in weights_list) or not any(w < 0 for w in weights_list):
                continue  # All same direction — no competition

            worst_morph = min(
                scores_by_morph.keys(),
                key=lambda m: scores_by_morph[m] * self._rolling_mean(f"{curve.name}_{m}"),
            )
            old_weight = curve.morphogen_weights[worst_morph]
            # Apply floor to prevent weight degeneration toward zero (Issue #32)
            if old_weight >= 0:
                curve.morphogen_weights[worst_morph] = max(0.1, old_weight * 0.8)
            else:
                curve.morphogen_weights[worst_morph] = min(-0.1, old_weight * 0.8)


# ---------------------------------------------------------------------------
# Default response curve definitions
# ---------------------------------------------------------------------------

def _default_response_curves() -> list[ResponseCurve]:
    """Engineering-intuition initial response curves per the Phase 3 plan."""
    return [
        ResponseCurve(
            name="gate_strictness",
            morphogen_weights={"domain_density": 0.5, "information_richness": -0.2},
            base_value=0.3,
            midpoint=0.5,
            steepness=5.0,
            min_value=0.1,
            max_value=0.9,
        ),
        ResponseCurve(
            name="activation_decay",
            morphogen_weights={"retrieval_pressure": 0.3, "domain_density": 0.2},
            base_value=0.3,
            midpoint=0.5,
            steepness=5.0,
            min_value=0.2,
            max_value=0.8,
        ),
        ResponseCurve(
            name="pruning_ttl",
            morphogen_weights={"domain_density": -1.0},
            base_value=5.0,
            midpoint=0.5,
            steepness=5.0,
            min_value=2.0,
            max_value=20.0,
        ),
        ResponseCurve(
            name="chronic_threshold",
            morphogen_weights={"domain_density": 0.3},
            base_value=0.4,
            midpoint=0.5,
            steepness=5.0,
            min_value=0.4,
            max_value=0.9,
        ),
        ResponseCurve(
            name="retrieval_breadth",
            morphogen_weights={"retrieval_pressure": -0.5},
            base_value=0.8,
            midpoint=0.5,
            steepness=5.0,
            min_value=0.2,
            max_value=1.0,
        ),
        ResponseCurve(
            name="buffer_soft_cap",
            morphogen_weights={"retrieval_pressure": -0.2, "information_richness": 0.3},
            base_value=20.0,
            midpoint=0.5,
            steepness=5.0,
            min_value=5.0,
            max_value=50.0,
        ),
        ResponseCurve(
            name="habituation_window",
            morphogen_weights={"retrieval_pressure": 0.2},
            base_value=5.0,
            midpoint=0.5,
            steepness=5.0,
            min_value=3.0,
            max_value=15.0,
        ),
        ResponseCurve(
            name="edge_cap_per_node",
            morphogen_weights={"domain_density": 0.3},
            base_value=20.0,
            midpoint=0.5,
            steepness=5.0,
            min_value=5.0,
            max_value=50.0,
        ),
    ]


# ---------------------------------------------------------------------------
# MorphogeneticField
# ---------------------------------------------------------------------------

# Domain density saturation constant is read from config.morphogen_density_saturation.


class MorphogeneticField:
    """Orchestrates morphogen computation, parameter mapping, and B-11 updates.

    Reads from:
    - ``DangerTheoryDetector`` (information_richness component)
    - ``DomainManager`` (domain_density component)
    - ``EmbeddingProvider`` (retrieval_pressure via query variance)

    Feeds dynamic parameter values to all other subsystems.
    """

    def __init__(
        self,
        config: FractalConfig,
        storage: "Storage",
        feedback: "DangerTheoryDetector",
        domains: "DomainManager",
        embeddings: "EmbeddingProvider",
    ) -> None:
        self._config = config
        self._storage = storage
        self._feedback = feedback
        self._domains = domains
        self._embeddings = embeddings

        self._curves: list[ResponseCurve] = _default_response_curves()
        self._updater = AllostericUpdater(
            alpha=config.morphogen_alpha,
            ema_window=config.morphogen_ema_window,
        )
        self._last_morphogens: MorphogenState | None = None
        self._last_param_values: dict[str, float] = {}
        # Sliding window of (midpoint, steepness) per curve for convergence check
        self._curve_history: dict[str, deque[tuple[float, float]]] = {
            c.name: deque(maxlen=10) for c in self._curves
        }
        # Recent query embeddings for retrieval_pressure computation
        self._recent_query_embeddings: deque[np.ndarray] = deque(maxlen=3)
        # Candidate counts for information_richness
        self._candidate_counts: deque[float] = deque(maxlen=10)

    # ------------------------------------------------------------------
    # Morphogen computation
    # ------------------------------------------------------------------

    async def compute_morphogens(self, session_context: dict) -> MorphogenState:
        """Compute the three morphogen values from observable session state.

        Args:
            session_context: Dict with keys such as ``domain``,
                ``new_candidates_this_session``, and ``query_embedding``.

        Returns:
            A :class:`MorphogenState` snapshot.
        """
        domain: str = session_context.get("domain", self._config.default_domain)
        query_emb: np.ndarray | None = session_context.get("query_embedding")

        # ---- information_richness ------------------------------------------
        store_signal_score: float = 0.0
        if hasattr(self._feedback, "get_information_richness_signal"):
            store_signal_score = float(
                self._feedback.get_information_richness_signal()  # type: ignore[attr-defined]
            )

        # Candidate ratio component
        new_candidates: float = float(session_context.get("new_candidates_this_session", 0))
        if self._candidate_counts:
            hist_avg = float(np.mean(list(self._candidate_counts))) + 1e-8
            candidate_ratio = min(1.0, new_candidates / hist_avg)
        else:
            candidate_ratio = 0.5
        self._candidate_counts.append(new_candidates)

        information_richness = max(0.0, min(1.0, 0.5 * store_signal_score + 0.5 * candidate_ratio))

        # ---- retrieval_pressure --------------------------------------------
        if query_emb is not None:
            self._recent_query_embeddings.append(query_emb)

        if len(self._recent_query_embeddings) >= 3:
            embs = np.stack(list(self._recent_query_embeddings))
            # Variance across the stack, mean across dimensions
            variance = float(np.mean(np.var(embs, axis=0)))
            retrieval_pressure = max(0.0, min(1.0, 1.0 - variance))
        else:
            retrieval_pressure = 0.5

        # ---- domain_density ------------------------------------------------
        try:
            stats = await self._domains.domain_stats(domain)
            memory_count = float(stats.memory_count if stats else 0)
            session_count = float(getattr(stats, "session_count", 1) or 1)
        except Exception:
            memory_count = 0.0
            session_count = 1.0

        raw_density = memory_count / (session_count + 1) / self._config.morphogen_density_saturation
        domain_density = max(0.0, min(1.0, raw_density))

        state = MorphogenState(
            information_richness=information_richness,
            retrieval_pressure=retrieval_pressure,
            domain_density=domain_density,
        )
        self._last_morphogens = state
        return state

    # ------------------------------------------------------------------
    # Parameter mapping
    # ------------------------------------------------------------------

    def apply_morphogens(self, morphogens: MorphogenState) -> dict[str, float]:
        """Compute all parameter values from the current morphogen state.

        Returns:
            Dict mapping parameter names to morphogen-derived values.
        """
        result: dict[str, float] = {}
        for curve in self._curves:
            result[curve.name] = curve.compute(morphogens)
        self._last_param_values = dict(result)
        return result

    def get_parameter(self, name: str) -> float:
        """Return the last computed morphogen-derived value for a parameter.

        Returns the base_value of the named curve if no morphogen computation
        has been performed yet.
        """
        if name in self._last_param_values:
            return self._last_param_values[name]
        # Fall back to the curve's base value
        for curve in self._curves:
            if curve.name == name:
                return curve.base_value
        return 0.5  # neutral default

    # ------------------------------------------------------------------
    # B-11 self-correction
    # ------------------------------------------------------------------

    async def update_curves(
        self, judge_score: float, morphogens: MorphogenState
    ) -> None:
        """Apply B-11 updates to all curves and persist.

        Called at session_end after LLM judge evaluation.
        """
        for curve in self._curves:
            self._updater.update(curve, judge_score, morphogens)
            self._curve_history[curve.name].append((curve.midpoint, curve.steepness))

        self._updater.competitive_inhibition(self._curves, morphogens)

    # ------------------------------------------------------------------
    # Convergence gate
    # ------------------------------------------------------------------

    def has_converged(self, window: int = 10) -> bool:
        """Return True if all curves have converged.

        Convergence = variance of midpoint < 0.01 AND variance of steepness
        < 0.5 across the last *window* sessions.
        """
        for curve in self._curves:
            history = list(self._curve_history[curve.name])
            if len(history) < window:
                return False
            midpoints = [h[0] for h in history[-window:]]
            steepnesses = [h[1] for h in history[-window:]]
            if float(np.var(midpoints)) >= 0.01:
                return False
            if float(np.var(steepnesses)) >= 0.5:
                return False
        return True

    # ------------------------------------------------------------------
    # History (P3→P4 contract)
    # ------------------------------------------------------------------

    async def get_history(self) -> list[MorphogenState]:
        """Return morphogen history from previous sessions.

        Reads the ``morphogens`` JSON column from the sessions table.
        Returns an empty list if no prior sessions have morphogen data.
        """
        try:
            rows = await self._storage.get_morphogen_history()  # type: ignore[attr-defined]
            states: list[MorphogenState] = []
            for row in rows:
                if row:
                    states.append(
                        MorphogenState(
                            information_richness=float(row.get("information_richness", 0.5)),
                            retrieval_pressure=float(row.get("retrieval_pressure", 0.5)),
                            domain_density=float(row.get("domain_density", 0.5)),
                        )
                    )
            return states
        except Exception:
            return []

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    @property
    def curves(self) -> list[ResponseCurve]:
        """The current list of response curves."""
        return list(self._curves)

    @property
    def curve_history(self) -> dict[str, list[tuple[float, float]]]:
        """Sliding window of ``(midpoint, steepness)`` per curve name."""
        return {k: list(v) for k, v in self._curve_history.items()}

    @property
    def last_morphogens(self) -> MorphogenState | None:
        """The most recent morphogen state computed this session."""
        return self._last_morphogens
