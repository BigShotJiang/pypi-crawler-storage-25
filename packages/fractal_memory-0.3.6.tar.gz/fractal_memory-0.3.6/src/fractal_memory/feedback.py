"""Feedback architecture — Danger Theory (real-time) + Batched LLM Judge (retrospective)."""

from __future__ import annotations

import json
import logging
import re
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from uuid import UUID

import numpy as np

from fractal_memory._compat import utcnow
from fractal_memory.config import FractalConfig
from fractal_memory.embeddings import EmbeddingProvider
from fractal_memory.llm import LLMProvider, LLMUnavailableError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


class FeedbackSignalType(StrEnum):
    DANGER = "danger"
    SAFETY = "safety"


class FeedbackSubtype(StrEnum):
    CORRECTION = "correction"
    RE_ASK = "re_ask"
    REJECTION = "rejection"
    ABANDONMENT = "abandonment"
    CONFIRMATION = "confirmation"
    ENGAGEMENT = "engagement"


@dataclass
class FeedbackSignal:
    """A single feedback signal detected from user behaviour."""

    type: FeedbackSignalType
    subtype: FeedbackSubtype
    confidence: float
    memory_ids: list[UUID]
    message: str
    timestamp: datetime = field(default_factory=utcnow)


@dataclass
class RetrievalTriple:
    """A (memory, query, response) triple collected during the session for batched judging."""

    memory_id: UUID
    memory_l2: str
    query: str
    response_summary: str | None
    has_clear_signal: bool


@dataclass
class JudgeRating:
    """LLM judge rating for a single retrieval triple."""

    memory_id: UUID
    rating: int       # 0 = clearly unused, 1 = unclear, 2 = clearly used
    confidence: float


class StoreSignalSubtype(StrEnum):
    SURPRISE = "surprise"
    RESOLUTION = "resolution"
    PREFERENCE = "preference"
    COMMITMENT = "commitment"
    PATTERN = "pattern"


@dataclass
class StoreSignal:
    """A store-worthiness signal detected from an exchange."""

    subtype: StoreSignalSubtype
    score: float               # 0.10–0.30 per trigger type
    text_excerpt: str          # first 200 chars of query
    confidence: float          # always 1.0 for heuristic triggers
    suggested_intensity: float # 0.5 base + 0.1 per additional trigger, capped at 0.9


# ---------------------------------------------------------------------------
# Regex patterns for Danger Theory (B-2)
# ---------------------------------------------------------------------------

_DANGER_CORRECTION = re.compile(
    r"(?i)(?:\bno\b\s*,|"
    r"\b(?:that(?:'s| is| was)? wrong|that(?:'s| is| was)? not right|"
    r"i said \w+,? not \w+|not correct|not right|not accurate|not true|"
    r"forget that|that(?:'s| is| was)? outdated|wrong|incorrect)\b)"
)
_DANGER_REJECTION = re.compile(
    r"(?i)\b(forget that|ignore that|disregard|that'?s? irrelevant|"
    r"not what i asked|that'?s? not helpful)\b"
)
_SAFETY_CONFIRMATION = re.compile(
    r"(?i)\b(yes|exactly|that'?s? right|correct|perfect|great|"
    r"exactly right|spot on|you'?re? right|confirmed)\b"
)

# Pattern to strip code blocks and quoted text before regex matching
_CODE_BLOCK_RE = re.compile(r"```[\s\S]*?```|`[^`\n]+`|\"[^\"]*\"|'[^']*'")


def _strip_code_and_quotes(text: str) -> str:
    """Remove inline/fenced code blocks and quoted strings to reduce false positives."""
    return _CODE_BLOCK_RE.sub("", text)



# ---------------------------------------------------------------------------
# Danger Theory Detector
# ---------------------------------------------------------------------------


class DangerTheoryDetector:
    """Real-time B-2 implementation: pattern-based danger/safety signal detection.

    Zero cost, zero latency — pure regex and embedding cosine comparison.
    False positives are acceptable because scar tissue has TTL.
    """

    def __init__(
        self,
        config: FractalConfig,
    ) -> None:
        self._config = config
        # Session state: last 3 queries with embeddings for re-ask detection
        self._recent_queries: deque[tuple[str, list[float]]] = deque(maxlen=3)
        self._avg_message_length: float = 0.0
        self._message_count: int = 0
        self._session_signals: list[FeedbackSignal] = []

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def session_signals(self) -> list[FeedbackSignal]:
        """All feedback signals collected this session."""
        return list(self._session_signals)

    @property
    def message_count(self) -> int:
        """Number of messages processed this session."""
        return self._message_count

    @property
    def avg_message_length(self) -> float:
        """Running average message length this session."""
        return self._avg_message_length

    def detect_signals(
        self,
        user_message: str,
        query_embedding: list[float],
        injected_memory_ids: list[UUID],
    ) -> list[FeedbackSignal]:
        """Detect danger and safety signals from a user message.

        Args:
            user_message: The raw user message text.
            query_embedding: Embedding of the retrieval query.
            injected_memory_ids: IDs of memories that were injected into context.

        Returns:
            list of FeedbackSignal detected in this turn.
        """
        signals: list[FeedbackSignal] = []
        now = utcnow()

        # Strip code blocks and quoted text to reduce false positives
        cleaned = _strip_code_and_quotes(user_message)

        # -- Danger: correction --
        if _DANGER_CORRECTION.search(cleaned):
            sig = FeedbackSignal(
                type=FeedbackSignalType.DANGER,
                subtype=FeedbackSubtype.CORRECTION,
                confidence=1.0,
                memory_ids=list(injected_memory_ids),
                message=user_message,
                timestamp=now,
            )
            signals.append(sig)

        # -- Danger: rejection (distinct from correction) --
        if _DANGER_REJECTION.search(cleaned) and not _DANGER_CORRECTION.search(
            cleaned
        ):
            sig = FeedbackSignal(
                type=FeedbackSignalType.DANGER,
                subtype=FeedbackSubtype.REJECTION,
                confidence=1.0,
                memory_ids=list(injected_memory_ids),
                message=user_message,
                timestamp=now,
            )
            signals.append(sig)

        # -- Danger: re-ask (same question asked again) --
        if self._recent_queries and query_embedding:
            q_vec = np.array(query_embedding, dtype=np.float32)
            q_norm = np.linalg.norm(q_vec)
            if q_norm > 0:
                for _prev_query, prev_emb in self._recent_queries:
                    p_vec = np.array(prev_emb, dtype=np.float32)
                    p_norm = np.linalg.norm(p_vec)
                    if p_norm > 0:
                        sim = float(np.dot(q_vec, p_vec) / (q_norm * p_norm))
                        if sim >= self._config.reask_similarity_threshold:
                            sig = FeedbackSignal(
                                type=FeedbackSignalType.DANGER,
                                subtype=FeedbackSubtype.RE_ASK,
                                confidence=1.0,
                                memory_ids=list(injected_memory_ids),
                                message=user_message,
                                timestamp=now,
                            )
                            signals.append(sig)
                            break

        # -- Safety: confirmation (mutually exclusive with correction — Issue #15) --
        has_correction = any(
            s.subtype == FeedbackSubtype.CORRECTION for s in signals
        )
        if not has_correction and _SAFETY_CONFIRMATION.search(cleaned):
            sig = FeedbackSignal(
                type=FeedbackSignalType.SAFETY,
                subtype=FeedbackSubtype.CONFIRMATION,
                confidence=1.0,
                memory_ids=list(injected_memory_ids),
                message=user_message,
                timestamp=now,
            )
            signals.append(sig)

        # -- Safety: deep engagement (long, topically continuous message) --
        if (
            self._avg_message_length > 0
            and len(user_message) >= self._avg_message_length * self._config.engagement_length_ratio
            and self._recent_queries
            and query_embedding
        ):
            _prev_query, prev_emb = self._recent_queries[-1]
            q_vec = np.array(query_embedding, dtype=np.float32)
            p_vec = np.array(prev_emb, dtype=np.float32)
            q_norm = np.linalg.norm(q_vec)
            p_norm = np.linalg.norm(p_vec)
            if q_norm > 0 and p_norm > 0:
                topic_sim = float(np.dot(q_vec, p_vec) / (q_norm * p_norm))
                if topic_sim >= self._config.engagement_topic_similarity:
                    sig = FeedbackSignal(
                        type=FeedbackSignalType.SAFETY,
                        subtype=FeedbackSubtype.ENGAGEMENT,
                        confidence=1.0,
                        memory_ids=list(injected_memory_ids),
                        message=user_message,
                        timestamp=now,
                    )
                    signals.append(sig)

        # -- Update running state --
        if query_embedding:
            self._recent_queries.append((user_message, query_embedding))
        self._message_count += 1
        self._avg_message_length = (
            (self._avg_message_length * (self._message_count - 1) + len(user_message))
            / self._message_count
        )

        self._session_signals.extend(signals)
        return signals

    def get_session_signals(self) -> list[FeedbackSignal]:
        """Return all signals collected this session. P2→P3 contract for morphogens."""
        return list(self._session_signals)

    def reset_session(self) -> None:
        """Clear session-scoped state."""
        self._recent_queries.clear()
        self._avg_message_length = 0.0
        self._message_count = 0
        self._session_signals = []


# ---------------------------------------------------------------------------
# Store Signal Detector (Option B — Store Trigger Taxonomy)
# ---------------------------------------------------------------------------

_RESOLUTION_RE = re.compile(
    r"(?i)\b(so the answer is|turns out|it was|we decided|the fix is|"
    r"the solution is|I figured out|it works because)\b"
)
_PREFERENCE_RE = re.compile(
    r"(?i)\b(I prefer|I always|I never|I want|I don't want|we use|we don't use|"
    r"our standard|my rule is|always use|never use)\b"
)
_COMMITMENT_RE = re.compile(
    r"(?i)\b(I will|we will|I'm going to|we're going to|I've decided|we've decided|"
    r"next time I'll|from now on|going forward)\b"
)

_SURPRISE_NOVELTY_THRESHOLD: float = 0.3
_PATTERN_SIMILARITY_THRESHOLD: float = 0.75
_PATTERN_MIN_COUNT: int = 3


class StoreSignalDetector:
    """Heuristic store-trigger detector — zero LLM cost, runs on every exchange.

    Detects 5 trigger types (Surprise, Resolution, Preference, Commitment, Pattern)
    and emits StoreSignal objects. Feeds information_richness morphogen to Phase 3.
    """

    def __init__(self, embeddings: EmbeddingProvider, config: FractalConfig) -> None:
        self._embeddings = embeddings
        self._config = config
        # (query, response, embedding) for the last 5 exchanges
        self._recent_exchanges: deque[tuple[str, str, list[float]]] = deque(maxlen=5)
        self._session_score: float = 0.0
        # Dashboard-visible state
        self._score_history: list[float] = []

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def session_score(self) -> float:
        """Accumulated store-signal score this session."""
        return self._session_score

    @property
    def recent_exchanges(self) -> list[tuple[str, str, list[float]]]:
        """Recent exchange tuples (query, response, embedding)."""
        return list(self._recent_exchanges)

    @property
    def score_history(self) -> list[float]:
        """History of session scores."""
        return list(self._score_history)

    async def detect_store_signals(
        self,
        query: str,
        response: str,
        query_embedding: list[float],
    ) -> list[StoreSignal]:
        """Analyze a single exchange and return any store-worthy signals.

        Args:
            query: The user query text.
            response: The assistant response text.
            query_embedding: Pre-computed embedding of the query.

        Returns:
            list of StoreSignal, one per matched trigger.
        """
        signals: list[StoreSignal] = []
        text_excerpt = query[:200]
        combined_text = f"{query} {response}"

        # 1. Surprise: embedding novelty — query is distant from all recent exchanges
        if query_embedding and self._recent_exchanges:
            q_vec = np.array(query_embedding, dtype=np.float32)
            q_norm = float(np.linalg.norm(q_vec))
            if q_norm > 0:
                max_sim = 0.0
                for _, _, prev_emb in self._recent_exchanges:
                    p_vec = np.array(prev_emb, dtype=np.float32)
                    p_norm = float(np.linalg.norm(p_vec))
                    if p_norm > 0:
                        sim = float(np.dot(q_vec, p_vec) / (q_norm * p_norm))
                        if sim > max_sim:
                            max_sim = sim
                if max_sim < _SURPRISE_NOVELTY_THRESHOLD:
                    signals.append(StoreSignal(
                        subtype=StoreSignalSubtype.SURPRISE,
                        score=0.30,
                        text_excerpt=text_excerpt,
                        confidence=1.0,
                        suggested_intensity=0.5,  # recalculated below
                    ))

        # 2. Resolution
        if _RESOLUTION_RE.search(combined_text):
            signals.append(StoreSignal(
                subtype=StoreSignalSubtype.RESOLUTION,
                score=0.20,
                text_excerpt=text_excerpt,
                confidence=1.0,
                suggested_intensity=0.5,
            ))

        # 3. Preference
        if _PREFERENCE_RE.search(combined_text):
            signals.append(StoreSignal(
                subtype=StoreSignalSubtype.PREFERENCE,
                score=0.20,
                text_excerpt=text_excerpt,
                confidence=1.0,
                suggested_intensity=0.5,
            ))

        # 4. Commitment
        if _COMMITMENT_RE.search(combined_text):
            signals.append(StoreSignal(
                subtype=StoreSignalSubtype.COMMITMENT,
                score=0.25,
                text_excerpt=text_excerpt,
                confidence=1.0,
                suggested_intensity=0.5,
            ))

        # 5. Pattern: same topic in 3+ recent exchanges
        if query_embedding and len(self._recent_exchanges) >= _PATTERN_MIN_COUNT - 1:
            q_vec = np.array(query_embedding, dtype=np.float32)
            q_norm = float(np.linalg.norm(q_vec))
            if q_norm > 0:
                similar_count = 0
                for _, _, prev_emb in self._recent_exchanges:
                    p_vec = np.array(prev_emb, dtype=np.float32)
                    p_norm = float(np.linalg.norm(p_vec))
                    if p_norm > 0:
                        sim = float(np.dot(q_vec, p_vec) / (q_norm * p_norm))
                        if sim >= _PATTERN_SIMILARITY_THRESHOLD:
                            similar_count += 1
                if similar_count >= _PATTERN_MIN_COUNT - 1:
                    signals.append(StoreSignal(
                        subtype=StoreSignalSubtype.PATTERN,
                        score=0.10,
                        text_excerpt=text_excerpt,
                        confidence=1.0,
                        suggested_intensity=0.5,
                    ))

        # Set suggested_intensity: 0.5 base + 0.1 per trigger, capped at 0.9
        trigger_count = len(signals)
        intensity = min(0.9, 0.5 + 0.1 * trigger_count)
        for sig in signals:
            sig.suggested_intensity = intensity

        # Accumulate session score
        session_delta = sum(s.score for s in signals)
        self._session_score += session_delta

        # Update exchange history
        self._recent_exchanges.append((query, response, query_embedding))

        if signals:
            logger.debug(
                "StoreSignalDetector: %d signals detected (subtypes=%s, session_score=%.2f)",
                len(signals),
                [s.subtype for s in signals],
                self._session_score,
            )

        return signals

    def get_information_richness_signal(self) -> float:
        """Return normalized session score for Phase 3 MorphogeneticField.

        Returns:
            float in [0, 1] representing information density of this session.
        """
        return min(1.0, self._session_score / 2.0)

    def reset_session(self) -> None:
        """Clear session-scoped state."""
        self._recent_exchanges.clear()
        self._session_score = 0.0


# ---------------------------------------------------------------------------
# Batched LLM Judge (B-5)
# ---------------------------------------------------------------------------

_JUDGE_SYSTEM = """\
You are a strict evaluator. Your ONLY job is to judge whether a stored memory
was actually used in an AI assistant's response. You output ONLY a JSON array
of integers. No explanation, no commentary, no markdown — just the array.

Rating scale:
  0 = NOT used. The response would be identical without this memory.
  1 = UNCERTAIN. Topical overlap exists but no definitive evidence the memory was used.
  2 = CLEARLY used. The response contains a specific fact, recommendation, or
decision that directly matches the memory's specific content.

Strict rules:
- Rating 2 requires SPECIFIC EVIDENCE: a named technology, exact number, or
concrete recommendation that matches the memory. Topical similarity alone is
NEVER enough for 2.
- If the memory says "prefer X" and the response recommends X by name: 2.
- If memory and response share the same broad topic but the response doesn't
use the memory's specific information: 0 or 1, NOT 2.
- When in doubt between 1 and 2, ALWAYS choose 1.
- When in doubt between 0 and 1, prefer 0.
- Ask yourself: could a competent AI have produced this exact response without
ever seeing the memory? If yes: 0 or 1, NOT 2.\
"""

_JUDGE_USER_TEMPLATE = """\
Rate each triple below (0, 1, or 2). Respond with ONLY a JSON array.

CALIBRATION EXAMPLES (do not include these in your output):
- Memory: "User prefers pytest" / Response: "Let's use pytest" → 2 (names the specific tool)
- Memory: "User likes TDD" / Response: "Let's write tests first" → 1 (aligns with TDD \
but doesn't explicitly reference TDD or the preference — could be standard practice)
- Memory: "User dislikes Redux" / Response: "Use Zustand instead" → 1 (avoids Redux but \
doesn't explicitly reference the dislike — Zustand is a common recommendation anyway)
- Memory: "User prefers dark theme" / Response: "Here's how to set up linting" → 0 (unrelated)

KEY: for a 2, the response must contain something UNLIKELY without the memory.
Generic best practices that happen to align with the memory are 1, not 2.

{triples_formatted}

JSON array:\
"""

_JUDGE_BATCH_SIZE: int = 20


class BatchedLLMJudge:
    """Retrospective B-5 LLM judge: evaluates retrieval triples at session end.

    Only evaluates triples WITHOUT clear real-time signals (those already
    handled by DangerTheoryDetector). This keeps LLM cost bounded.

    Prompt validated in Phase 0: 87% accuracy, 80% precision, 85.7% recall,
    Cohen's kappa 0.804. Uses Sonnet (not Haiku — Haiku achieved only ~50%
    precision on this task).
    """

    def __init__(self, llm: LLMProvider, config: FractalConfig) -> None:
        self._llm = llm
        self._config = config
        self._triples: list[RetrievalTriple] = []

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def triples(self) -> list[RetrievalTriple]:
        """Retrieval triples collected for evaluation."""
        return list(self._triples)

    def record_triple(
        self,
        memory_id: UUID,
        memory_l2: str,
        query: str,
        response_summary: str | None,
        has_clear_signal: bool,
    ) -> None:
        """Record a retrieval triple for retrospective evaluation.

        Args:
            memory_id: ID of the memory that was injected.
            memory_l2: L2 summary of the memory (for the judge prompt).
            query: The retrieval query used.
            response_summary: Optional summary of the AI's response.
            has_clear_signal: True if already handled by danger theory (skip judging).
        """
        self._triples.append(
            RetrievalTriple(
                memory_id=memory_id,
                memory_l2=memory_l2,
                query=query,
                response_summary=response_summary,
                has_clear_signal=has_clear_signal,
            )
        )

    async def evaluate(self) -> list[JudgeRating]:
        """Evaluate all ambiguous triples (those without clear real-time signals).

        Called at session_end. Returns JudgeRating for each evaluated triple.
        Triples with has_clear_signal=True are skipped.
        If LLM is unavailable, returns empty list — consolidation proceeds without
        judge data and relies solely on real-time signals.

        Returns:
            list of JudgeRating objects.
        """
        ambiguous = [t for t in self._triples if not t.has_clear_signal]
        if not ambiguous:
            return []

        # Phase 0 validation used Sonnet (87% accuracy, kappa=0.804).
        # Haiku achieves ~50% precision on this task — not suitable.
        # Warn if the LLM provider is not using Sonnet.
        model = getattr(self._llm, "model_name", None) or ""
        if isinstance(model, str) and "haiku" in model.lower():
            logger.warning(
                "BatchedLLMJudge: model '%s' may produce unreliable ratings. "
                "Phase 0 validation requires Sonnet (haiku achieved ~50%% precision).",
                model,
            )

        ratings: list[JudgeRating] = []
        # Process in chunks of JUDGE_BATCH_SIZE
        for chunk_start in range(0, len(ambiguous), _JUDGE_BATCH_SIZE):
            chunk = ambiguous[chunk_start : chunk_start + _JUDGE_BATCH_SIZE]
            chunk_ratings = await self._evaluate_chunk(chunk)
            # For same memory across chunks: take max rating (optimistic)
            for rating in chunk_ratings:
                existing = next(
                    (r for r in ratings if r.memory_id == rating.memory_id), None
                )
                if existing is None:
                    ratings.append(rating)
                else:
                    existing.rating = max(existing.rating, rating.rating)

        logger.info(
            "LLM judge evaluated %d triples → %d ratings",
            len(ambiguous),
            len(ratings),
        )
        return ratings

    async def _evaluate_chunk(
        self, triples: list[RetrievalTriple]
    ) -> list[JudgeRating]:
        """Evaluate a single chunk of ≤JUDGE_BATCH_SIZE triples."""
        triples_formatted = self._format_triples(triples)
        prompt = _JUDGE_USER_TEMPLATE.format(triples_formatted=triples_formatted)

        try:
            response = await self._llm.complete(
                prompt=prompt,
                system=_JUDGE_SYSTEM,
                max_tokens=200,
            )
        except LLMUnavailableError:
            logger.warning("LLM judge unavailable — skipping chunk of %d triples", len(triples))
            return []

        return self._parse_ratings(triples, response)

    def _format_triples(self, triples: list[RetrievalTriple]) -> str:
        """Format triples for the judge prompt."""
        lines = []
        for i, t in enumerate(triples, 1):
            lines.append(f"Triple {i}:")
            lines.append(f'  Memory: "{t.memory_l2}"')
            lines.append(f'  Query: "{t.query}"')
            if t.response_summary:
                lines.append(f'  Response: "{t.response_summary}"')
            lines.append("")
        return "\n".join(lines)

    def _parse_ratings(
        self, triples: list[RetrievalTriple], response: str
    ) -> list[JudgeRating]:
        """Parse LLM response into JudgeRating objects.

        Fallback strategy:
        1. Strip markdown fences and try json.loads.
        2. Extract numbers via regex.
        3. Default all to 1 (unclear) on persistent failure.
        """
        # Strip markdown fences
        cleaned = response.strip()
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```[a-zA-Z]*\n?", "", cleaned)
            cleaned = re.sub(r"\n?```$", "", cleaned)
            cleaned = cleaned.strip()

        rating_ints: list[int] = []

        # Try JSON parse
        try:
            parsed = json.loads(cleaned)
            if isinstance(parsed, list):
                rating_ints = [int(x) for x in parsed]
        except (json.JSONDecodeError, ValueError, TypeError):
            pass

        # Fallback: regex extraction — match digits at line start or after
        # known delimiters to avoid capturing incidental digits (Issue #33)
        if not rating_ints:
            found = re.findall(r"(?:^|rating[:\s]*|score[:\s]*|[\-\*]\s*)([012])\b", cleaned, re.MULTILINE)
            rating_ints = [int(x) for x in found]

        # Clamp and pad/truncate to match triple count
        def clamp(v: int) -> int:
            return max(0, min(2, v))

        if len(rating_ints) < len(triples):
            # Pad with 1 (unclear)
            rating_ints.extend([1] * (len(triples) - len(rating_ints)))
        elif len(rating_ints) > len(triples):
            rating_ints = rating_ints[: len(triples)]

        return [
            JudgeRating(
                memory_id=t.memory_id,
                rating=clamp(r),
                confidence=1.0,
            )
            for t, r in zip(triples, rating_ints)
        ]

    def get_cost_estimate(self) -> float:
        """Estimate LLM cost for evaluation (approximate — based on triple count)."""
        ambiguous = sum(1 for t in self._triples if not t.has_clear_signal)
        chunks = (ambiguous + _JUDGE_BATCH_SIZE - 1) // _JUDGE_BATCH_SIZE
        # Rough estimate: ~500 tokens input + ~50 tokens output per chunk
        return chunks * 0.001  # nominal cost placeholder

    def reset_session(self) -> None:
        """Clear session-scoped triple list."""
        self._triples = []
