"""Tests for Phase 2 — AssociationNetwork (B-8, B-15)."""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory.associations import AssociationNetwork
from fractal_memory.config import FractalConfig
from fractal_memory.storage import Storage


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _unit_vec(dim: int = 384, seed: int = 0) -> list[float]:
    rng = np.random.RandomState(seed)
    v = rng.randn(dim).astype(np.float32)
    return (v / np.linalg.norm(v)).tolist()


@pytest.fixture
async def net(storage: Storage, mock_embeddings, tmp_config: FractalConfig):
    return AssociationNetwork(storage, mock_embeddings, tmp_config)


# ---------------------------------------------------------------------------
# Co-retrieval — edge formation (B-8)
# ---------------------------------------------------------------------------


async def test_on_co_retrieval_creates_edge(net: AssociationNetwork, storage: Storage):
    a, b = uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=2)
    edges = await storage.get_associations(a)
    neighbor_ids = [e[0] for e in edges]
    assert b in neighbor_ids


async def test_on_co_retrieval_l2_weight(net: AssociationNetwork, storage: Storage):
    a, b = uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=2)
    edges = await storage.get_associations(a)
    weight = next(e[1] for e in edges if e[0] == b)
    assert abs(weight - 0.1) < 1e-6


async def test_on_co_retrieval_l3_weight(net: AssociationNetwork, storage: Storage):
    a, b = uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=3)
    edges = await storage.get_associations(a)
    weight = next(e[1] for e in edges if e[0] == b)
    assert abs(weight - 0.2) < 1e-6


async def test_on_co_retrieval_l1_ignored(net: AssociationNetwork, storage: Storage):
    a, b = uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=1)
    edges = await storage.get_associations(a)
    assert not edges


async def test_on_co_retrieval_strengthens_existing(net: AssociationNetwork, storage: Storage):
    a, b = uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=2)  # 0.1
    await net.on_co_retrieval([a, b], zoom_level=2)  # should increase
    edges = await storage.get_associations(a)
    weight = next(e[1] for e in edges if e[0] == b)
    assert weight > 0.1


async def test_on_co_retrieval_single_memory_no_edge(net: AssociationNetwork, storage: Storage):
    a = uuid4()
    await net.on_co_retrieval([a], zoom_level=3)
    edges = await storage.get_associations(a)
    assert not edges


# ---------------------------------------------------------------------------
# Edge cap enforcement (B-8)
# ---------------------------------------------------------------------------


async def test_edge_cap_enforced(tmp_path, mock_embeddings):
    config = FractalConfig(db_path=tmp_path / "cap_test.db", edge_cap_per_node=3)
    storage = Storage(config)
    await storage.initialize()
    net = AssociationNetwork(storage, mock_embeddings, config)

    anchor = uuid4()
    neighbors = [uuid4() for _ in range(5)]
    for n in neighbors:
        await net.on_co_retrieval([anchor, n], zoom_level=2)

    total = await storage.count_associations(anchor)
    assert total <= config.edge_cap_per_node
    await storage.close()


# ---------------------------------------------------------------------------
# Spreading activation (B-8)
# ---------------------------------------------------------------------------


async def test_spreading_activation_returns_boosts(net: AssociationNetwork, storage: Storage):
    a, b, c = uuid4(), uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=2)
    await net.on_co_retrieval([a, c], zoom_level=3)

    boosts = await net.spreading_activation([a])
    assert b in boosts or c in boosts


async def test_spreading_activation_skips_refractory(net: AssociationNetwork, storage: Storage):
    a, b = uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=3)
    await net.enter_refractory([b])

    boosts = await net.spreading_activation([a])
    assert b not in boosts


async def test_spreading_activation_excludes_seeds(net: AssociationNetwork, storage: Storage):
    a, b = uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=2)
    boosts = await net.spreading_activation([a, b])
    # Seeds themselves should not appear as boost targets
    assert a not in boosts


# ---------------------------------------------------------------------------
# Refractory periods (B-8)
# ---------------------------------------------------------------------------


async def test_refractory_expires_after_turns(net: AssociationNetwork, storage: Storage, tmp_config: FractalConfig):
    a, b = uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=2)
    await net.enter_refractory([b])

    # b should be refractory initially
    boosts_before = await net.spreading_activation([a])
    assert b not in boosts_before

    # Advance turns until refractory expires
    for _ in range(tmp_config.refractory_turns + 1):
        net.advance_turn()

    boosts_after = await net.spreading_activation([a])
    assert b in boosts_after


async def test_advance_turn_increments_counter(net: AssociationNetwork):
    assert net._turn_counter == 0
    net.advance_turn()
    assert net._turn_counter == 1
    net.advance_turn()
    assert net._turn_counter == 2


# ---------------------------------------------------------------------------
# Slow-wave decay (B-13 partial)
# ---------------------------------------------------------------------------


async def test_decay_all_weights_reduces_weights(net: AssociationNetwork, storage: Storage):
    a, b = uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=3)
    initial_edges = await storage.get_associations(a)
    initial_weight = next(e[1] for e in initial_edges if e[0] == b)

    await net.decay_all_weights(factor=0.85)

    after_edges = await storage.get_associations(a)
    if after_edges:  # edge survived decay
        after_weight = next((e[1] for e in after_edges if e[0] == b), None)
        if after_weight is not None:
            assert after_weight < initial_weight


async def test_decay_prunes_weak_edges(tmp_path, mock_embeddings):
    config = FractalConfig(db_path=tmp_path / "decay.db")
    storage = Storage(config)
    await storage.initialize()
    net = AssociationNetwork(storage, mock_embeddings, config)

    a, b = uuid4(), uuid4()
    # Insert edge with weight just above prune threshold
    await storage.store_association(a, b, weight=0.02)
    pruned = await net.decay_all_weights(factor=0.3)  # 0.02 * 0.3 = 0.006 < 0.01
    assert pruned >= 1
    await storage.close()


# ---------------------------------------------------------------------------
# Stigmergic trails (B-15)
# ---------------------------------------------------------------------------


async def test_strengthen_trail_updates_trail_weight(net: AssociationNetwork, storage: Storage):
    a, b = uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=2)

    q_emb = _unit_vec(seed=1)
    await net.strengthen_trail([a, b], query_embedding=q_emb)

    edges = await storage.get_associations(a)
    e = next((e for e in edges if e[0] == b), None)
    assert e is not None
    trail_weight = e[2]
    assert trail_weight > 0


async def test_strengthen_trail_sets_centroid(net: AssociationNetwork, storage: Storage):
    a, b = uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=3)

    q_emb = _unit_vec(seed=5)
    await net.strengthen_trail([a, b], query_embedding=q_emb)

    edges = await storage.get_associations(a)
    e = next((e for e in edges if e[0] == b), None)
    assert e is not None
    centroid = e[3]
    assert centroid is not None and len(centroid) > 0


async def test_get_trail_boost_returns_boost(net: AssociationNetwork, storage: Storage):
    a, b = uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=3)

    q_emb = _unit_vec(seed=7)
    await net.strengthen_trail([a, b], query_embedding=q_emb)

    # Query with same embedding — should get a boost for b
    boosts = await net.get_trail_boost(q_emb, [a, b])
    assert any(v > 0 for v in boosts.values())


async def test_get_trail_boost_empty_when_no_trails(net: AssociationNetwork):
    q_emb = _unit_vec()
    candidates = [uuid4() for _ in range(3)]
    boosts = await net.get_trail_boost(q_emb, candidates)
    assert boosts == {}


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------


async def test_get_stats_empty(net: AssociationNetwork):
    stats = await net.get_stats()
    assert stats["edge_count"] == 0
    assert stats["avg_weight"] == 0.0


async def test_get_stats_with_edges(net: AssociationNetwork, storage: Storage):
    a, b, c = uuid4(), uuid4(), uuid4()
    await net.on_co_retrieval([a, b], zoom_level=2)
    await net.on_co_retrieval([b, c], zoom_level=3)

    stats = await net.get_stats()
    assert stats["edge_count"] >= 2
    assert stats["avg_weight"] > 0
    assert stats["nodes_with_edges"] >= 3


# ---------------------------------------------------------------------------
# Issue #10 — prune_below() (SQL DELETE)
# ---------------------------------------------------------------------------


async def test_prune_below_deletes_weak_edges(net: AssociationNetwork, storage: Storage):
    """prune_below removes edges below threshold, keeps those at or above."""
    from datetime import datetime
    a, b, c, d = uuid4(), uuid4(), uuid4(), uuid4()
    now = datetime.utcnow().isoformat()
    # Create edges with varying weights
    conn = storage._ensure_conn()
    await conn.execute(
        "INSERT INTO associations (source_id, target_id, weight, created_at) VALUES (?, ?, ?, ?)",
        (str(a), str(b), 0.005, now),
    )
    await conn.execute(
        "INSERT INTO associations (source_id, target_id, weight, created_at) VALUES (?, ?, ?, ?)",
        (str(a), str(c), 0.05, now),
    )
    await conn.execute(
        "INSERT INTO associations (source_id, target_id, weight, created_at) VALUES (?, ?, ?, ?)",
        (str(a), str(d), 0.5, now),
    )
    await conn.commit()
    result = await net.prune_below(threshold=0.01)
    assert result == 1
    # Verify remaining edges
    edges = await storage.get_associations(a)
    weights = {round(w, 3) for _, w, _, _ in edges}
    assert 0.005 not in weights
    assert 0.05 in weights
    assert 0.5 in weights


async def test_prune_below_empty_graph(net: AssociationNetwork):
    """prune_below on empty graph returns 0 without error."""
    result = await net.prune_below(0.01)
    assert result == 0


async def test_prune_below_threshold_boundary(net: AssociationNetwork, storage: Storage):
    """Edge with weight exactly at threshold is NOT deleted (strict less-than)."""
    from datetime import datetime
    a, b = uuid4(), uuid4()
    now = datetime.utcnow().isoformat()
    conn = storage._ensure_conn()
    await conn.execute(
        "INSERT INTO associations (source_id, target_id, weight, created_at) VALUES (?, ?, ?, ?)",
        (str(a), str(b), 0.01, now),
    )
    await conn.commit()
    result = await net.prune_below(threshold=0.01)
    assert result == 0
    edges = await storage.get_associations(a)
    assert len(edges) == 1
