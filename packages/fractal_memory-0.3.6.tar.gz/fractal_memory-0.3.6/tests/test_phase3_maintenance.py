"""Tests for fractal_memory.maintenance — MaintenanceScheduler (Phase 3)."""

from __future__ import annotations

from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.maintenance import MaintenanceReport, MaintenanceScheduler


@pytest.fixture
def cfg() -> FractalConfig:
    return FractalConfig(
        long_session_threshold_minutes=30,
        intra_session_interval_minutes=15,
    )


def _make_scheduler(cfg: FractalConfig) -> MaintenanceScheduler:
    storage = AsyncMock()
    storage.update_vitality_batch.return_value = 5
    storage.update_chronic_batch.return_value = 5
    storage.get_edge_stats.return_value = {"mean_weight": 0.6}
    storage.weaken_unused_edges.return_value = 3
    storage.update_vitality_all.return_value = 10
    storage.get_reinforced_scars.return_value = []
    storage.list_domains_with_counts.return_value = []
    storage.set_maintenance_log = AsyncMock()
    storage.get_maintenance_log.return_value = None

    consolidation = AsyncMock()
    consolidation.merge_duplicates.return_value = None
    consolidation.run.return_value = MagicMock(merges_performed=2, memories_pruned=1)
    consolidation.prune_expired.return_value = 3

    dreaming = AsyncMock()
    dreaming.dream_cycle.return_value = MagicMock(
        slow_wave=MagicMock(edges_pruned=4),
        rem=MagicMock(syntheses_stored=1),
    )

    apoptosis = AsyncMock()
    apoptosis.batch_check.return_value = []

    niche = AsyncMock()
    niche.detect_domain_clusters.return_value = []
    niche.apply_domain_proposals.return_value = 0

    self_model = AsyncMock()
    self_model.health.return_value = MagicMock()
    self_model.flag_parameter_drift.return_value = []
    self_model.record_cascade_warnings = MagicMock()

    folding = MagicMock()
    folding.update_folded_stats = MagicMock()

    cascade = AsyncMock()
    cascade.observe.return_value = None

    return MaintenanceScheduler(
        storage=storage,
        consolidation=consolidation,
        dreaming=dreaming,
        apoptosis=apoptosis,
        niche=niche,
        self_model=self_model,
        folding=folding,
        cascade=cascade,
        config=cfg,
    )


# ---------------------------------------------------------------------------
# intra_session_maintenance
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_intra_session_runs_when_conditions_met(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    long_ago = datetime.utcnow() - timedelta(minutes=60)
    ran = await sched.intra_session_maintenance(session_start_time=long_ago, turn_count=35)
    assert ran is True


@pytest.mark.asyncio
async def test_intra_session_skips_when_session_too_short(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    recently = datetime.utcnow() - timedelta(minutes=5)
    ran = await sched.intra_session_maintenance(session_start_time=recently, turn_count=40)
    assert ran is False


@pytest.mark.asyncio
async def test_intra_session_skips_when_low_turn_count(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    long_ago = datetime.utcnow() - timedelta(minutes=60)
    ran = await sched.intra_session_maintenance(session_start_time=long_ago, turn_count=10)
    assert ran is False


@pytest.mark.asyncio
async def test_intra_session_skips_when_recently_run(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    long_ago = datetime.utcnow() - timedelta(minutes=60)
    # Run once
    await sched.intra_session_maintenance(session_start_time=long_ago, turn_count=40)
    # Run again immediately — should skip
    ran = await sched.intra_session_maintenance(session_start_time=long_ago, turn_count=40)
    assert ran is False


@pytest.mark.asyncio
async def test_intra_session_updates_last_run(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    long_ago = datetime.utcnow() - timedelta(minutes=60)
    assert sched._last_intra_session_run is None
    await sched.intra_session_maintenance(session_start_time=long_ago, turn_count=40)
    assert sched._last_intra_session_run is not None


# ---------------------------------------------------------------------------
# session_end_maintenance
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_session_end_returns_report(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    report = await sched.session_end_maintenance({})
    assert isinstance(report, MaintenanceReport)
    assert report.tier == "session_end"


@pytest.mark.asyncio
async def test_session_end_records_edges_pruned(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    report = await sched.session_end_maintenance({"session_memory_ids": []})
    assert report.actions_taken.get("edges_pruned") == 4


@pytest.mark.asyncio
async def test_session_end_records_rem_syntheses(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    report = await sched.session_end_maintenance({})
    assert report.actions_taken.get("rem_syntheses_stored") == 1


@pytest.mark.asyncio
async def test_session_end_records_vitality_updated(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    sched._storage.update_vitality_batch.return_value = 7
    report = await sched.session_end_maintenance({"accessed_memory_ids": []})
    assert report.actions_taken.get("vitality_updated") == 7


@pytest.mark.asyncio
async def test_session_end_has_health_snapshot(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    report = await sched.session_end_maintenance({})
    assert report.health_snapshot is not None


@pytest.mark.asyncio
async def test_session_end_duration_positive(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    report = await sched.session_end_maintenance({})
    assert report.duration_seconds >= 0.0


@pytest.mark.asyncio
async def test_session_end_tolerates_dreaming_failure(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    sched._dreaming.dream_cycle.side_effect = Exception("dreaming failed")
    report = await sched.session_end_maintenance({})
    assert report.tier == "session_end"


# ---------------------------------------------------------------------------
# daily_maintenance
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_daily_maintenance_returns_report(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    report = await sched.daily_maintenance()
    assert report.tier == "daily"
    assert isinstance(report.actions_taken, dict)


@pytest.mark.asyncio
async def test_daily_maintenance_records_pruned(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    report = await sched.daily_maintenance()
    assert report.actions_taken.get("pruned") == 3


@pytest.mark.asyncio
async def test_daily_maintenance_records_edges_weakened(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    report = await sched.daily_maintenance()
    assert report.actions_taken.get("edges_weakened") == 3


@pytest.mark.asyncio
async def test_daily_maintenance_sets_log(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    await sched.daily_maintenance()
    sched._storage.set_maintenance_log.assert_called_once()


# ---------------------------------------------------------------------------
# weekly_maintenance
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_weekly_maintenance_returns_report(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    report = await sched.weekly_maintenance()
    assert report.tier == "weekly"


@pytest.mark.asyncio
async def test_weekly_maintenance_tolerates_niche_failure(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    sched._niche.detect_domain_clusters.side_effect = Exception("networkx missing")
    report = await sched.weekly_maintenance()
    assert report.tier == "weekly"


# ---------------------------------------------------------------------------
# monthly_maintenance
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_monthly_maintenance_returns_report(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    report = await sched.monthly_maintenance()
    assert report.tier == "monthly"


@pytest.mark.asyncio
async def test_monthly_maintenance_has_health_snapshot(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    report = await sched.monthly_maintenance()
    assert report.health_snapshot is not None


@pytest.mark.asyncio
async def test_monthly_maintenance_tolerates_storage_failure(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    sched._storage.list_domains_with_counts.side_effect = Exception("DB error")
    report = await sched.monthly_maintenance()
    assert report.tier == "monthly"


# ---------------------------------------------------------------------------
# should_run_scheduled
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_should_run_when_no_log(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    sched._storage.get_maintenance_log.return_value = None
    result = await sched.should_run_scheduled("daily")
    assert result is True


@pytest.mark.asyncio
async def test_should_not_run_when_recently_run(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    # Ran 1 hour ago — daily interval is 24h
    sched._storage.get_maintenance_log.return_value = datetime.utcnow() - timedelta(hours=1)
    result = await sched.should_run_scheduled("daily")
    assert result is False


@pytest.mark.asyncio
async def test_should_run_when_overdue(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    # Ran 2 days ago — daily interval is 24h
    sched._storage.get_maintenance_log.return_value = datetime.utcnow() - timedelta(days=2)
    result = await sched.should_run_scheduled("daily")
    assert result is True


@pytest.mark.asyncio
async def test_should_run_returns_false_for_unknown_schedule(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    result = await sched.should_run_scheduled("hourly")
    assert result is False


@pytest.mark.asyncio
async def test_should_run_tolerates_storage_exception(cfg: FractalConfig) -> None:
    sched = _make_scheduler(cfg)
    sched._storage.get_maintenance_log.side_effect = Exception("DB error")
    result = await sched.should_run_scheduled("daily")
    assert result is True
