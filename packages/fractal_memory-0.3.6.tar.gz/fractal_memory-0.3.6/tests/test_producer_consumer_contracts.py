"""Producer-consumer contract verification — stats keys match consumer expectations."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus, Memory, RetrievalResult, SessionSummary


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = float(np.linalg.norm(vec))
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm():
    mock = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        lower = prompt.lower()
        if "summarize" in lower or "summary" in lower:
            return "Session summary for testing."
        return json.dumps({
            "l0_tag": "test:tag",
            "l1_label": "Test label",
            "l2_summary": "Test summary",
            "l3_full": "Full test context",
        })
    mock.complete = AsyncMock(side_effect=_complete)
    mock.model_name = "mock-model"
    return mock


def _make_mock_embeddings(dim: int = 384):
    mock = AsyncMock()
    mock.embed = AsyncMock(side_effect=lambda text: _deterministic_embed(text, dim))
    mock.embed_batch = AsyncMock(
        side_effect=lambda texts: [_deterministic_embed(t, dim) for t in texts]
    )
    mock.model_name = "mock-model"
    mock.dimension = dim
    return mock


@pytest.fixture
def config(tmp_path):
    return FractalConfig(
        db_path=tmp_path / "contract_test.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
        enable_llm_judge=False,
    )


@pytest.fixture
async def fm(config):
    fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
    await fm.initialize()
    yield fm
    await fm.close()


# ---------------------------------------------------------------------------
# get_stats() contract
# ---------------------------------------------------------------------------


class TestGetStatsContract:
    """Verify get_stats() returns all expected keys."""

    async def test_stats_has_overall_section(self, fm):
        await fm.session_start("test-domain")
        stats = await fm.get_stats()
        assert "overall" in stats
        overall = stats["overall"]
        assert "total_memories" in overall
        assert "total_sessions" in overall
        assert "total_domains" in overall

    async def test_stats_has_domains_section(self, fm):
        await fm.session_start("test-domain")
        stats = await fm.get_stats()
        assert "domains" in stats
        assert isinstance(stats["domains"], list)

    async def test_stats_has_current_session(self, fm):
        await fm.session_start("test-domain")
        stats = await fm.get_stats()
        assert "current_session" in stats
        session = stats["current_session"]
        assert session is not None
        assert "session_id" in session
        assert "domain" in session
        assert "started_at" in session
        assert "duration_seconds" in session
        assert "stores" in session
        assert "retrievals" in session

    async def test_stats_has_lifecycle_section(self, fm):
        await fm.session_start("test-domain")
        stats = await fm.get_stats()
        assert "lifecycle" in stats
        assert isinstance(stats["lifecycle"], dict)

    async def test_stats_has_buffer_section(self, fm):
        await fm.session_start("test-domain")
        stats = await fm.get_stats()
        assert "buffer" in stats
        buffer = stats["buffer"]
        assert "pinned" in buffer
        assert "auto_promoted" in buffer
        assert "just_written" in buffer
        assert "recent" in buffer

    async def test_stats_has_associations_section(self, fm):
        await fm.session_start("test-domain")
        stats = await fm.get_stats()
        assert "associations" in stats

    async def test_stats_has_scars_section(self, fm):
        await fm.session_start("test-domain")
        stats = await fm.get_stats()
        assert "scars" in stats
        assert "active_count" in stats["scars"]

    async def test_stats_has_recent_stores(self, fm):
        await fm.session_start("test-domain")
        stats = await fm.get_stats()
        assert "recent_stores" in stats
        assert isinstance(stats["recent_stores"], list)

    async def test_stats_has_recent_retrievals(self, fm):
        await fm.session_start("test-domain")
        stats = await fm.get_stats()
        assert "recent_retrievals" in stats
        assert isinstance(stats["recent_retrievals"], list)

    async def test_stats_numeric_values_not_none(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Test memory")
        stats = await fm.get_stats()
        assert stats["overall"]["total_memories"] is not None
        assert isinstance(stats["overall"]["total_memories"], int)
        assert stats["overall"]["total_sessions"] is not None
        assert isinstance(stats["overall"]["total_sessions"], int)

    async def test_domain_entry_has_expected_keys(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Memory in test domain")
        stats = await fm.get_stats()
        if stats["domains"]:
            domain = stats["domains"][0]
            assert "name" in domain
            assert "memory_count" in domain
            assert "last_active" in domain
            assert "lifecycle" in domain


# ---------------------------------------------------------------------------
# RetrievalResult contract
# ---------------------------------------------------------------------------


class TestRetrievalResultContract:
    """Verify RetrievalResult has expected fields."""

    async def test_retrieval_result_has_memory_lists(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Test memory for retrieval")
        result = await fm.retrieve("test")
        assert hasattr(result, "l3_memories")
        assert hasattr(result, "l2_memories")
        assert hasattr(result, "l1_memories")
        assert isinstance(result.l3_memories, list)
        assert isinstance(result.l2_memories, list)
        assert isinstance(result.l1_memories, list)

    async def test_retrieval_result_has_budget_fields(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Budget test memory")
        result = await fm.retrieve("budget")
        assert hasattr(result, "token_budget_used")
        assert hasattr(result, "token_budget_total")
        assert isinstance(result.token_budget_used, int)
        assert isinstance(result.token_budget_total, int)

    async def test_retrieval_result_has_hints(self, fm):
        await fm.session_start("test-domain")
        result = await fm.retrieve("hints test")
        assert hasattr(result, "hints")
        assert isinstance(result.hints, list)

    async def test_retrieval_result_has_store_suggestions(self, fm):
        await fm.session_start("test-domain")
        result = await fm.retrieve("store suggestions")
        assert hasattr(result, "store_suggestions")
        assert isinstance(result.store_suggestions, list)


# ---------------------------------------------------------------------------
# Memory fields contract
# ---------------------------------------------------------------------------


class TestMemoryFieldsContract:
    """Verify stored Memory has all required fields."""

    async def test_store_returns_memory_with_all_fields(self, fm):
        await fm.session_start("test-domain")
        mem = await fm.store("Complete memory test")
        assert mem is not None
        assert mem.id is not None
        assert mem.domain == "test-domain"
        assert mem.l0_tag is not None
        assert mem.l1_label is not None
        assert mem.l2_summary is not None
        assert mem.l3_full is not None
        assert mem.l4_raw == "Complete memory test"
        assert mem.embedding is not None
        assert len(mem.embedding) == 384
        assert mem.embedding_model is not None
        assert mem.intensity >= 0.0
        assert mem.lifecycle == LifecycleStatus.PROBATION
        assert mem.created_at is not None
        assert mem.updated_at is not None

    async def test_memory_persists_to_storage(self, fm):
        await fm.session_start("test-domain")
        mem = await fm.store("Persistence test")
        assert mem is not None
        fetched = await fm.get(mem.id)
        assert fetched is not None
        assert fetched.id == mem.id
        assert fetched.domain == mem.domain
        assert fetched.l4_raw == mem.l4_raw


# ---------------------------------------------------------------------------
# SessionSummary contract
# ---------------------------------------------------------------------------


class TestSessionSummaryContract:
    """Verify session_end() returns SessionSummary with expected fields."""

    async def test_session_summary_has_all_fields(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Session memory")
        summary = await fm.session_end()
        assert hasattr(summary, "session_id")
        assert hasattr(summary, "summary")
        assert hasattr(summary, "memories_stored")
        assert hasattr(summary, "memories_retrieved")
        assert hasattr(summary, "duration_seconds")
        assert hasattr(summary, "hook_failures")
        assert isinstance(summary.hook_failures, list)
        assert summary.memories_stored >= 1
        assert summary.duration_seconds >= 0

    async def test_session_summary_counts_accurate(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Memory 1")
        await fm.store("Memory 2")
        await fm.retrieve("test query")
        summary = await fm.session_end()
        assert summary.memories_stored == 2
        assert summary.memories_retrieved >= 1


# ---------------------------------------------------------------------------
# health() contract
# ---------------------------------------------------------------------------


class TestHealthReportContract:
    """Verify health() returns HealthReport with expected fields."""

    async def test_health_has_all_sections(self, fm):
        await fm.session_start("test-domain")
        report = await fm.health()
        assert hasattr(report, "retrieval_hit_rate")
        assert hasattr(report, "freshness")
        assert hasattr(report, "compression_ratio")
        assert hasattr(report, "growth_rate")
        assert hasattr(report, "total_memories")
        assert hasattr(report, "domain_health")
        assert hasattr(report, "morphogen_convergence")
        assert hasattr(report, "chronic_memories_count")
        assert hasattr(report, "system_state")
        assert hasattr(report, "association_density")
        assert hasattr(report, "scar_count")
        assert hasattr(report, "bandit_arm_distribution")
        assert hasattr(report, "cascade_warnings")
        assert hasattr(report, "flagged_parameters")

    async def test_health_numeric_fields_are_numbers(self, fm):
        await fm.session_start("test-domain")
        report = await fm.health()
        assert isinstance(report.retrieval_hit_rate, (int, float))
        assert isinstance(report.freshness, (int, float))
        assert isinstance(report.compression_ratio, (int, float))
        assert isinstance(report.growth_rate, (int, float))
        assert isinstance(report.association_density, (int, float))
        assert isinstance(report.scar_count, int)
        assert isinstance(report.chronic_memories_count, int)

    async def test_health_morphogen_convergence_keys(self, fm):
        await fm.session_start("test-domain")
        report = await fm.health()
        mc = report.morphogen_convergence
        assert "converged" in mc
        assert "variance" in mc


# ---------------------------------------------------------------------------
# MaintenanceReport contract
# ---------------------------------------------------------------------------


class TestMaintenanceReportContract:
    """Verify MaintenanceReport has expected fields."""

    async def test_daily_report_has_fields(self, fm):
        report = await fm._maintenance.daily_maintenance()
        assert report.tier == "daily"
        assert isinstance(report.actions_taken, dict)
        assert isinstance(report.duration_seconds, float)
        assert isinstance(report.errors, list)

    async def test_weekly_report_has_fields(self, fm):
        report = await fm._maintenance.weekly_maintenance()
        assert report.tier == "weekly"
        assert isinstance(report.actions_taken, dict)

    async def test_monthly_report_has_fields(self, fm):
        report = await fm._maintenance.monthly_maintenance()
        assert report.tier == "monthly"
        assert isinstance(report.actions_taken, dict)
        # Monthly should include health_snapshot
        # (may be None if health computation fails, but the field should exist)
        assert hasattr(report, "health_snapshot")
