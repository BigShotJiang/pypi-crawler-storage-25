"""Stress tests for O(N^2) algorithms, SQL parameter limits, and scale degradation.

Goes beyond test_stress_scale.py (500-1000 memories) to test:
- 5K-10K memory operations (store, retrieve, consolidation)
- SQL 999-parameter limit batching correctness
- Association edge scaling (linear vs quadratic)
- Concurrent writes at scale
- Niche detection with large graphs
- Memory deletion cascades
- Retrieval scaling curves
"""

from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock
from uuid import UUID, uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.storage import Storage
from fractal_memory.llm import LLMProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Generate a deterministic unit-norm embedding from text."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm():
    provider = AsyncMock(spec=LLMProvider)

    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower():
            return "Scale test session summary."
        return json.dumps({
            "l0_tag": "scale:test",
            "l1_label": "scale-test",
            "l2_summary": "Scale test memory.",
            "l3_full": "Scale test memory with full context.",
        })

    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings(dim=384):
    provider = AsyncMock()

    async def _embed(text):
        return _deterministic_embed(text, dim)

    async def _embed_batch(texts):
        return [_deterministic_embed(t, dim) for t in texts]

    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = dim
    return provider


def _make_memory(i: int, domain: str = "scale", dim: int = 384) -> Memory:
    """Create a Memory object for batch insertion (bypasses LLM)."""
    now = datetime.now(timezone.utc)
    return Memory(
        id=uuid4(),
        domain=domain,
        created_at=now,
        updated_at=now,
        context={},
        l0_tag="s:t",
        l1_label="label",
        l2_summary=f"Memory {i} summary",
        l3_full=f"Memory {i} full context with extra detail for realistic sizing",
        l4_raw=f"Memory {i} raw text input for the store operation",
        embedding=_deterministic_embed(f"unique-mem-{i}", dim),
        embedding_model="mock",
    )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def scale_config(tmp_path):
    return FractalConfig(
        db_path=tmp_path / "scale.db",
        gate_signal_count=1,
        llm_max_calls_per_session=50000,
    )


@pytest.fixture
async def scale_storage(scale_config):
    s = Storage(scale_config)
    await s.initialize()
    yield s
    await s.close()


# ---------------------------------------------------------------------------
# Test 1: Store 10K memories, verify count
# ---------------------------------------------------------------------------


class TestStore10K:
    @pytest.mark.asyncio
    async def test_store_10k_memories_verify_count(self, scale_storage: Storage):
        """Batch-insert 10K memories via storage.store_memory, verify count == 10000.

        Target: complete in under 60 seconds. This tests that the storage layer
        handles high-volume inserts without degradation or errors.
        """
        n = 10_000
        start = time.perf_counter()
        for i in range(n):
            mem = _make_memory(i)
            await scale_storage.store_memory(mem)
        elapsed = time.perf_counter() - start

        count = await scale_storage.count_memories()
        assert count == n, f"Expected {n} memories, got {count}"
        assert elapsed < 60, f"10K inserts took {elapsed:.1f}s (limit: 60s)"


# ---------------------------------------------------------------------------
# Test 2: Retrieve against 10K memories
# ---------------------------------------------------------------------------


class TestRetrieve10K:
    @pytest.mark.asyncio
    async def test_retrieve_against_10k_memories(self, scale_config: FractalConfig, scale_storage: Storage):
        """After seeding 10K memories, retrieval should complete in <5s.

        Uses RetrievalEngine directly to bypass LLM overhead. Measures pure
        scoring + ranking latency at 10K scale.
        """
        from fractal_memory.retrieval import RetrievalEngine

        # Seed 10K memories in a single domain
        n = 10_000
        for i in range(n):
            await scale_storage.store_memory(_make_memory(i))

        embeddings = _make_mock_embeddings()
        engine = RetrievalEngine(
            storage=scale_storage,
            embeddings=embeddings,
            config=scale_config,
        )

        start = time.perf_counter()
        result = await engine.retrieve("unique query about memory 5000", domain="scale")
        elapsed = time.perf_counter() - start

        assert elapsed < 5, f"Retrieval against 10K took {elapsed:.2f}s (limit: 5s)"
        # Should return at least some L1 memories
        total_returned = len(result.l1_memories) + len(result.l2_memories) + len(result.l3_memories)
        assert total_returned > 0, "Retrieval returned no memories from 10K pool"


# ---------------------------------------------------------------------------
# Test 3: Consolidation sim_matrix with 5K memories
# ---------------------------------------------------------------------------


class TestSimMatrix5K:
    @pytest.mark.asyncio
    async def test_consolidation_sim_matrix_5k(self, scale_storage: Storage):
        """Seed 5K memories, fetch all embeddings, compute numpy sim_matrix.

        Verifies no OOM and completion in <30s. This directly tests the
        O(N^2) similarity matrix computation that consolidation uses.
        """
        n = 5_000
        for i in range(n):
            await scale_storage.store_memory(_make_memory(i))

        start = time.perf_counter()
        all_embeddings = await scale_storage.get_all_embeddings("scale")
        assert len(all_embeddings) == n

        # Build the matrix and compute pairwise similarities (the O(N^2) part)
        vecs = np.array([emb for _, emb in all_embeddings], dtype=np.float32)
        norms = np.linalg.norm(vecs, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1.0, norms)
        vecs_normed = vecs / norms
        sim_matrix = vecs_normed @ vecs_normed.T
        elapsed = time.perf_counter() - start

        assert sim_matrix.shape == (n, n), f"Expected ({n},{n}), got {sim_matrix.shape}"
        assert elapsed < 30, f"5K sim_matrix took {elapsed:.1f}s (limit: 30s)"
        # Diagonal should be ~1.0 (self-similarity)
        assert np.allclose(np.diag(sim_matrix), 1.0, atol=0.01)


# ---------------------------------------------------------------------------
# Test 4: Association edge scaling
# ---------------------------------------------------------------------------


class TestAssociationEdgeScaling:
    @pytest.mark.asyncio
    async def test_association_edge_scaling_linear(self, scale_storage: Storage):
        """Create edges at 100, 1K, 5K scale and verify get_all_associations timing.

        Checks that retrieval time grows roughly linearly (not quadratically)
        with edge count.
        """
        # Pre-create enough memories to reference
        mem_ids = []
        for i in range(200):
            mem = _make_memory(i)
            await scale_storage.store_memory(mem)
            mem_ids.append(mem.id)

        # Helper to create N edges using pairs from mem_ids
        async def create_edges(count: int) -> None:
            created = 0
            for i in range(len(mem_ids)):
                for j in range(i + 1, len(mem_ids)):
                    if created >= count:
                        return
                    await scale_storage.store_association(
                        mem_ids[i], mem_ids[j], weight=0.5
                    )
                    created += 1

        timings = {}
        for target_count in [100, 1000, 5000]:
            # Reset associations by recreating storage
            # Instead, just add more edges (cumulative)
            await create_edges(target_count)

            start = time.perf_counter()
            edges = await scale_storage.get_all_associations()
            elapsed = time.perf_counter() - start
            timings[target_count] = elapsed

        # 5K should complete in reasonable time
        assert timings[5000] < 10, f"get_all_associations at 5K took {timings[5000]:.2f}s"
        # Rough linearity check: 5K time should be less than 50x the 100 time
        # (if truly quadratic, it would be 2500x)
        if timings[100] > 0.0001:
            ratio = timings[5000] / timings[100]
            assert ratio < 200, (
                f"Scaling appears super-linear: 5K/100 ratio = {ratio:.1f}"
            )


# ---------------------------------------------------------------------------
# Test 5: Batch get_memories_by_ids with 2K IDs (SQL 999 param limit)
# ---------------------------------------------------------------------------


class TestBatchGetMemoriesByIds:
    @pytest.mark.asyncio
    async def test_get_memories_by_ids_2k(self, scale_storage: Storage):
        """Create 2K memories, batch-fetch all by ID. Verifies SQL 999-param limit
        is handled correctly (the storage layer should batch internally or
        handle the large IN clause).
        """
        n = 2_000
        ids: list[UUID] = []
        for i in range(n):
            mem = _make_memory(i)
            await scale_storage.store_memory(mem)
            ids.append(mem.id)

        start = time.perf_counter()
        fetched = await scale_storage.get_memories_by_ids(ids)
        elapsed = time.perf_counter() - start

        assert len(fetched) == n, f"Expected {n} memories, got {len(fetched)}"
        assert elapsed < 10, f"Batch fetch of {n} IDs took {elapsed:.2f}s (limit: 10s)"
        # Verify order preservation
        fetched_ids = [m.id for m in fetched]
        assert fetched_ids == ids, "Returned memories should preserve input order"

    @pytest.mark.asyncio
    async def test_get_memories_by_ids_batch_boundaries(self, scale_config: FractalConfig):
        """Test exact batch boundary: 900 (within), 901 (crosses batch), 1800 (two full batches)."""
        s = Storage(scale_config)
        await s.initialize()
        try:
            for boundary in [900, 901, 1800]:
                mems = [_make_memory(i, domain="batch-boundary") for i in range(boundary)]
                for m in mems:
                    await s.store_memory(m)

                ids = [m.id for m in mems]
                fetched = await s.get_memories_by_ids(ids)
                assert len(fetched) == boundary, f"Expected {boundary}, got {len(fetched)}"
                # Verify order preserved across batch boundary
                for orig, got in zip(ids, fetched):
                    assert orig == got.id, f"Order broken at boundary {boundary}"
        finally:
            await s.close()


# ---------------------------------------------------------------------------
# Test 6: batch_decay_and_prune with 10K edges
# ---------------------------------------------------------------------------


class TestBatchDecayAndPrune:
    @pytest.mark.asyncio
    async def test_batch_decay_and_prune_10k_edges(self, scale_storage: Storage):
        """Create 10K association edges, run batch_decay_and_prune.

        Verifies the batch SQL approach completes without errors and prunes
        edges below the minimum weight threshold.
        """
        # Create enough nodes
        mem_ids = []
        for i in range(300):
            mem = _make_memory(i)
            await scale_storage.store_memory(mem)
            mem_ids.append(mem.id)

        # Create 10K edges with varying weights
        edge_count = 0
        for i in range(len(mem_ids)):
            for j in range(i + 1, len(mem_ids)):
                if edge_count >= 10_000:
                    break
                # Half the edges are weak (will be pruned after decay)
                weight = 0.05 if edge_count % 2 == 0 else 0.8
                await scale_storage.store_association(
                    mem_ids[i], mem_ids[j], weight=weight
                )
                edge_count += 1
            if edge_count >= 10_000:
                break

        total_before = await scale_storage.get_total_association_count()
        assert total_before > 0, "Should have edges before decay"

        start = time.perf_counter()
        # Decay factor 0.5 on weight 0.05 => 0.025, still above min 0.01
        # But a second decay would push it below.
        # Use a decay that pushes weak edges below min_weight
        pruned = await scale_storage.batch_decay_and_prune(factor=0.1, min_weight=0.01)
        elapsed = time.perf_counter() - start

        assert elapsed < 15, f"batch_decay_and_prune on 10K edges took {elapsed:.1f}s"
        total_after = await scale_storage.get_total_association_count()
        # Some edges should have been pruned (the weak ones at 0.05 * 0.1 = 0.005 < 0.01)
        assert pruned > 0, "Should have pruned at least some weak edges"
        assert total_after < total_before, "Edge count should decrease after pruning"


# ---------------------------------------------------------------------------
# Test 7: Apoptosis batch check with 5K memories
# ---------------------------------------------------------------------------


class TestApoptosisBatchCheck:
    @pytest.mark.asyncio
    async def test_apoptosis_vitality_query_5k(self, scale_storage: Storage):
        """Seed 5K memories with low vitality, verify get_memories_by_vitality completes.

        Apoptosis uses this query to find candidate memories. At scale, the query
        should complete without timing out.
        """
        n = 5_000
        for i in range(n):
            mem = _make_memory(i)
            # Set half of memories to very low vitality
            mem.vitality = 0.01 if i % 2 == 0 else 0.9
            await scale_storage.store_memory(mem)

        start = time.perf_counter()
        low_vitality = await scale_storage.get_memories_by_vitality(max_vitality=0.05)
        elapsed = time.perf_counter() - start

        assert elapsed < 5, f"Vitality query on 5K took {elapsed:.2f}s (limit: 5s)"
        assert len(low_vitality) == n // 2, (
            f"Expected {n // 2} low-vitality memories, got {len(low_vitality)}"
        )


# ---------------------------------------------------------------------------
# Test 8: Niche detection with 500 nodes and 2K edges
# ---------------------------------------------------------------------------


class TestNicheDetection:
    @pytest.mark.asyncio
    async def test_niche_detection_500_nodes(self, scale_config: FractalConfig, scale_storage: Storage):
        """Create 500 memories with 2K edges, verify detect_domain_clusters completes.

        Uses the actual NicheConstructor + AssociationNetwork stack to run
        Louvain community detection at realistic scale.
        """
        from fractal_memory.niche import NicheConstructor
        from fractal_memory.associations import AssociationNetwork
        from fractal_memory.domains import DomainManager

        # Create 500 memories across 5 implicit clusters
        mem_ids = []
        for i in range(500):
            cluster = i % 5
            mem = _make_memory(i, domain=f"cluster-{cluster}")
            await scale_storage.store_memory(mem)
            mem_ids.append(mem.id)

        # Create ~2K edges with cluster-aware weighting
        edge_count = 0
        rng = np.random.RandomState(42)
        while edge_count < 2000:
            i = rng.randint(0, 500)
            j = rng.randint(0, 500)
            if i == j:
                continue
            # Intra-cluster edges are stronger
            same_cluster = (i % 5) == (j % 5)
            weight = 0.7 if same_cluster else 0.2
            await scale_storage.store_association(
                mem_ids[i], mem_ids[j], weight=weight
            )
            edge_count += 1

        embeddings = _make_mock_embeddings()
        associations = AssociationNetwork(
            storage=scale_storage, embeddings=embeddings, config=scale_config
        )
        domains = DomainManager(storage=scale_storage, config=scale_config)
        niche = NicheConstructor(
            storage=scale_storage,
            associations=associations,
            domains=domains,
            config=scale_config,
        )

        start = time.perf_counter()
        proposals = await niche.detect_domain_clusters()
        elapsed = time.perf_counter() - start

        assert elapsed < 30, f"Niche detection with 500 nodes took {elapsed:.1f}s (limit: 30s)"
        # Should complete without error; proposals may be empty depending on modularity


# ---------------------------------------------------------------------------
# Test 9: Memory deletion cascade at scale
# ---------------------------------------------------------------------------


class TestDeletionCascade:
    @pytest.mark.asyncio
    async def test_deletion_cascade_no_orphaned_edges(self, scale_storage: Storage):
        """Create 1K memories with associations, delete 100, verify no orphaned edges.

        Tests that delete_memory properly cascades to remove association edges
        referencing deleted memory IDs.
        """
        n = 1_000
        mem_ids = []
        for i in range(n):
            mem = _make_memory(i)
            await scale_storage.store_memory(mem)
            mem_ids.append(mem.id)

        # Create edges: each memory connected to next 3
        for i in range(n - 3):
            for offset in [1, 2, 3]:
                await scale_storage.store_association(
                    mem_ids[i], mem_ids[i + offset], weight=0.5
                )

        edges_before = await scale_storage.get_total_association_count()
        assert edges_before > 0

        # Delete first 100 memories
        deleted_ids = set()
        start = time.perf_counter()
        for i in range(100):
            result = await scale_storage.delete_memory(mem_ids[i])
            assert result is True, f"Failed to delete memory {i}"
            deleted_ids.add(mem_ids[i])
        elapsed = time.perf_counter() - start

        assert elapsed < 30, f"Deleting 100 memories with cascade took {elapsed:.1f}s"

        # Verify no orphaned edges reference deleted memories
        all_edges = await scale_storage.get_all_associations()
        for src, tgt, _weight in all_edges:
            assert src not in deleted_ids, f"Orphaned edge source: {src}"
            assert tgt not in deleted_ids, f"Orphaned edge target: {tgt}"

        # Verify remaining count
        remaining = await scale_storage.count_memories()
        assert remaining == n - 100


# ---------------------------------------------------------------------------
# Test 10: Retrieval scaling curve
# ---------------------------------------------------------------------------


class TestRetrievalScalingCurve:
    @pytest.mark.asyncio
    async def test_retrieval_time_scaling(self, scale_config: FractalConfig, scale_storage: Storage):
        """Measure retrieval time at 100, 500, 1K, 2K memories.

        Verify sub-linear or at most linear scaling. At 2K the retrieval
        should still complete in under 3 seconds.
        """
        from fractal_memory.retrieval import RetrievalEngine

        embeddings = _make_mock_embeddings()
        engine = RetrievalEngine(
            storage=scale_storage,
            embeddings=embeddings,
            config=scale_config,
        )

        timings: dict[int, float] = {}
        total_inserted = 0

        for target_n in [100, 500, 1000, 2000]:
            # Insert memories up to target
            for i in range(total_inserted, target_n):
                await scale_storage.store_memory(_make_memory(i))
            total_inserted = target_n

            # Invalidate retrieval engine embedding cache
            engine.invalidate_cache()

            # Measure retrieval time (average of 3 queries)
            times = []
            for q in range(3):
                start = time.perf_counter()
                await engine.retrieve(f"scaling test query {q}", domain="scale")
                times.append(time.perf_counter() - start)
            timings[target_n] = sum(times) / len(times)

        # At 2K, retrieval should still be fast (5s allows for CI load spikes)
        assert timings[2000] < 5, (
            f"Retrieval at 2K memories took {timings[2000]:.2f}s (limit: 5s)"
        )

        # Scaling check: 2K time should be less than 30x the 100-memory time
        # (perfectly linear would be 20x; we allow slight overhead but catch O(N^2) ~400x)
        if timings[100] > 0.0001:
            ratio = timings[2000] / timings[100]
            assert ratio < 30, (
                f"Retrieval scaling appears super-linear: "
                f"2K/100 ratio = {ratio:.1f} (timings: {timings})"
            )


# ---------------------------------------------------------------------------
# Test 11: get_all_embeddings at 5K
# ---------------------------------------------------------------------------


class TestGetAllEmbeddings5K:
    @pytest.mark.asyncio
    async def test_get_all_embeddings_5k(self, scale_storage: Storage):
        """Verify get_all_embeddings returns correct count and dimensions at 5K.

        This is the foundation for consolidation and retrieval scoring.
        """
        n = 5_000
        dim = 384
        for i in range(n):
            await scale_storage.store_memory(_make_memory(i, dim=dim))

        start = time.perf_counter()
        all_embeddings = await scale_storage.get_all_embeddings("scale")
        elapsed = time.perf_counter() - start

        assert len(all_embeddings) == n, f"Expected {n} embeddings, got {len(all_embeddings)}"
        assert elapsed < 10, f"get_all_embeddings(5K) took {elapsed:.2f}s (limit: 10s)"

        # Verify embedding dimensions
        for uid, emb in all_embeddings[:10]:  # Spot-check first 10
            assert isinstance(uid, UUID)
            assert len(emb) == dim, f"Embedding dim mismatch: expected {dim}, got {len(emb)}"

        # Verify last embedding too
        _, last_emb = all_embeddings[-1]
        assert len(last_emb) == dim


# ---------------------------------------------------------------------------
# Test 12: Concurrent stores at scale
# ---------------------------------------------------------------------------


class TestConcurrentStores:
    @pytest.mark.asyncio
    async def test_concurrent_stores_after_5k(self, scale_config: FractalConfig):
        """50 concurrent store_memory calls after 5K existing memories.

        Verifies that concurrent writes do not cause database locks, corruption,
        or integrity violations under WAL mode.
        """
        storage = Storage(scale_config)
        await storage.initialize()

        try:
            # Seed 5K memories
            for i in range(5000):
                await storage.store_memory(_make_memory(i))

            count_before = await storage.count_memories()
            assert count_before == 5000

            # Now fire 50 concurrent inserts
            concurrent_count = 50

            async def store_one(idx: int) -> None:
                mem = _make_memory(5000 + idx)
                await storage.store_memory(mem)

            start = time.perf_counter()
            tasks = [asyncio.create_task(store_one(i)) for i in range(concurrent_count)]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            elapsed = time.perf_counter() - start

            # Check for errors
            errors = [r for r in results if isinstance(r, Exception)]
            assert len(errors) == 0, f"Concurrent stores had {len(errors)} errors: {errors[:3]}"

            # Verify total count
            count_after = await storage.count_memories()
            assert count_after == 5000 + concurrent_count, (
                f"Expected {5000 + concurrent_count} memories, got {count_after}"
            )
            assert elapsed < 30, f"50 concurrent stores took {elapsed:.1f}s (limit: 30s)"
        finally:
            await storage.close()
