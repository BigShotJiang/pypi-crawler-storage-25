"""Stress tests for input boundary extremes — text, unicode, embeddings, domains, numerics.

Probes every validation and storage boundary in the system with ~30 tests covering:
- Text length edge cases (empty, max, over-max, single char, null bytes)
- Unicode extremes (CJK, emoji, RTL, zero-width joiners, combining chars, mixed scripts)
- Embedding pathological values (NaN, Inf, zero vector, dimension mismatch, large floats)
- Domain validation boundaries (max length, over-max, special chars, valid patterns, empty)
- Numeric boundaries (intensity 0/1/negative/over-1, token budget 0, vitality, chronic score)
"""

from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.llm import LLMProvider
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.storage import Storage, _pack_embedding, _unpack_embedding


# ── Helpers ────────────────────────────────────────────────────────────


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive unit embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm() -> LLMProvider:
    """Create a mock LLM provider with realistic side_effect."""
    provider = AsyncMock(spec=LLMProvider)

    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower():
            return "Boundary stress test session summary."
        return json.dumps({
            "l0_tag": "boundary:test",
            "l1_label": "boundary-test",
            "l2_summary": "Boundary stress test memory.",
            "l3_full": "Boundary stress test memory with full context.",
        })

    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings(dim: int = 384):
    """Create mock embedding provider with deterministic embeddings."""
    provider = AsyncMock()

    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text, dim)

    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t, dim) for t in texts]

    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = dim
    return provider


# ── Fixtures ───────────────────────────────────────────────────────────


@pytest.fixture
def stress_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "stress_boundary.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
    )


@pytest.fixture
async def stress_fm(stress_config: FractalConfig):
    fm = FractalMemory(stress_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
    await fm.initialize()
    yield fm
    if fm._session.current_session is not None:
        try:
            await fm.session_end()
        except Exception:
            pass
    await fm.close()


@pytest.fixture
async def stress_storage(stress_config: FractalConfig):
    s = Storage(stress_config)
    await s.initialize()
    yield s
    await s.close()


# ── Text boundary tests ───────────────────────────────────────────────


class TestTextBoundaries:
    @pytest.mark.asyncio
    async def test_empty_string_store_raises(self, stress_fm: FractalMemory):
        """Empty string passed to store() must raise ValueError."""
        await stress_fm.session_start("boundary")
        with pytest.raises(ValueError, match="must not be empty"):
            await stress_fm.store("", domain="boundary")

    @pytest.mark.asyncio
    async def test_whitespace_only_store_raises(self, stress_fm: FractalMemory):
        """Whitespace-only text passed to store() must raise ValueError."""
        await stress_fm.session_start("boundary")
        with pytest.raises(ValueError, match="must not be empty"):
            await stress_fm.store("   \t\n  ", domain="boundary")

    @pytest.mark.asyncio
    async def test_max_length_text_succeeds(self, stress_fm: FractalMemory):
        """Text at exactly max_text_length (50,000 chars) should store successfully."""
        await stress_fm.session_start("boundary")
        text = "x" * 50_000
        mem = await stress_fm.store(text, domain="boundary")
        assert mem is not None
        assert mem.l4_raw == text

    @pytest.mark.asyncio
    async def test_over_max_length_text_raises(self, stress_fm: FractalMemory):
        """Text exceeding max_text_length must raise ValueError."""
        await stress_fm.session_start("boundary")
        text = "x" * 50_001
        with pytest.raises(ValueError, match="exceeds max length"):
            await stress_fm.store(text, domain="boundary")

    @pytest.mark.asyncio
    async def test_1mb_text_with_increased_config(self, tmp_path: Path):
        """1MB text should succeed when max_text_length is raised to 1,000,000."""
        cfg = FractalConfig(
            db_path=tmp_path / "big_text.db",
            gate_signal_count=1,
            max_text_length=1_000_000,
            llm_max_calls_per_session=10000,
        )
        fm = FractalMemory(cfg, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            await fm.session_start("boundary")
            text = "A" * 1_000_000
            mem = await fm.store(text, domain="boundary")
            assert mem is not None
            assert len(mem.l4_raw) == 1_000_000
        finally:
            if fm._session.current_session:
                await fm.session_end()
            await fm.close()

    @pytest.mark.asyncio
    async def test_text_with_null_bytes(self, stress_fm: FractalMemory):
        """Text containing null bytes should be stored and retrieved correctly."""
        await stress_fm.session_start("boundary")
        text = "before\x00after\x00end"
        mem = await stress_fm.store(text, domain="boundary")
        assert mem is not None
        result = await stress_fm.retrieve("null bytes", domain="boundary")
        # Memory was stored; raw text preserved
        found = [m for m in result.l3_memories if m.l4_raw == text]
        assert len(found) > 0, "Memory with null bytes should be retrievable"

    @pytest.mark.asyncio
    async def test_single_character_text_succeeds(self, stress_fm: FractalMemory):
        """Single non-whitespace character should store successfully."""
        await stress_fm.session_start("boundary")
        mem = await stress_fm.store("X", domain="boundary")
        assert mem is not None
        assert mem.l4_raw == "X"


# ── Unicode stress tests ──────────────────────────────────────────────


class TestUnicodeBoundaries:
    @pytest.mark.asyncio
    async def test_cjk_characters(self, stress_fm: FractalMemory):
        """CJK (Chinese/Japanese/Korean) text should store and retrieve."""
        await stress_fm.session_start("boundary")
        text = "This system uses fractal memory. " + "\u4e16\u754c\u4f60\u597d\u3053\u3093\u306b\u3061\u306f\ud55c\uad6d\uc5b4"
        mem = await stress_fm.store(text, domain="boundary")
        assert mem is not None
        result = await stress_fm.retrieve("\u4e16\u754c\u4f60\u597d", domain="boundary")
        assert result is not None

    @pytest.mark.asyncio
    async def test_emoji_text(self, stress_fm: FractalMemory):
        """Emoji-heavy text should store and retrieve without corruption."""
        await stress_fm.session_start("boundary")
        text = "Status report: great progress today! \U0001f680\U0001f525\U0001f4af\U0001f30d\U0001f916\U0001f9e0"
        mem = await stress_fm.store(text, domain="boundary")
        assert mem is not None
        assert "\U0001f680" in mem.l4_raw
        result = await stress_fm.retrieve("status report emoji", domain="boundary")
        assert result is not None

    @pytest.mark.asyncio
    async def test_rtl_arabic_text(self, stress_fm: FractalMemory):
        """RTL Arabic text should store and retrieve correctly."""
        await stress_fm.session_start("boundary")
        text = "Important note about Arabic text: " + "\u0645\u0631\u062d\u0628\u0627 \u0628\u0627\u0644\u0639\u0627\u0644\u0645"
        mem = await stress_fm.store(text, domain="boundary")
        assert mem is not None
        result = await stress_fm.retrieve("\u0645\u0631\u062d\u0628\u0627", domain="boundary")
        assert result is not None

    @pytest.mark.asyncio
    async def test_zero_width_joiners(self, stress_fm: FractalMemory):
        """Text with zero-width joiners (ZWJ) should store and retrieve."""
        await stress_fm.session_start("boundary")
        # Family emoji with ZWJ sequences
        text = "User family context: \U0001f468\u200d\U0001f469\u200d\U0001f467\u200d\U0001f466 prefers dark mode"
        mem = await stress_fm.store(text, domain="boundary")
        assert mem is not None
        assert "\u200d" in mem.l4_raw

    @pytest.mark.asyncio
    async def test_combining_characters_diacritics(self, stress_fm: FractalMemory):
        """Text with combining diacritical marks should store correctly."""
        await stress_fm.session_start("boundary")
        # e + combining acute accent = e-acute; a + combining ring above
        text = "User preference: caf\u0065\u0301 style. Scandinavian names like \u0061\u030a are common."
        mem = await stress_fm.store(text, domain="boundary")
        assert mem is not None
        assert "\u0301" in mem.l4_raw

    @pytest.mark.asyncio
    async def test_mixed_scripts_single_text(self, stress_fm: FractalMemory):
        """Text mixing Latin, Cyrillic, Greek, Hebrew, and CJK should store."""
        await stress_fm.session_start("boundary")
        text = (
            "Latin: Hello. "
            "\u041a\u0438\u0440\u0438\u043b\u043b\u0438\u0446\u0430: \u041f\u0440\u0438\u0432\u0435\u0442. "
            "\u0395\u03bb\u03bb\u03b7\u03bd\u03b9\u03ba\u03ac: \u0393\u03b5\u03b9\u03b1. "
            "\u05e2\u05d1\u05e8\u05d9\u05ea: \u05e9\u05dc\u05d5\u05dd. "
            "\u4e2d\u6587: \u4f60\u597d."
        )
        mem = await stress_fm.store(text, domain="boundary")
        assert mem is not None
        result = await stress_fm.retrieve("multilingual hello", domain="boundary")
        assert result is not None


# ── Embedding boundary tests ──────────────────────────────────────────


class TestEmbeddingBoundaries:
    def test_nan_in_embedding_raises(self):
        """NaN value in embedding must cause _pack_embedding to raise ValueError."""
        embedding = [0.1, 0.2, float("nan"), 0.4]
        with pytest.raises(ValueError, match="NaN or Inf"):
            _pack_embedding(embedding)

    def test_inf_in_embedding_raises(self):
        """Inf value in embedding must cause _pack_embedding to raise ValueError."""
        embedding = [0.1, float("inf"), 0.3, 0.4]
        with pytest.raises(ValueError, match="NaN or Inf"):
            _pack_embedding(embedding)

    def test_negative_inf_in_embedding_raises(self):
        """Negative Inf in embedding must cause _pack_embedding to raise ValueError."""
        embedding = [0.1, float("-inf"), 0.3]
        with pytest.raises(ValueError, match="NaN or Inf"):
            _pack_embedding(embedding)

    def test_zero_vector_packs_successfully(self):
        """All-zero embedding should pack and unpack without error."""
        embedding = [0.0] * 384
        packed = _pack_embedding(embedding)
        unpacked = _unpack_embedding(packed, dim=384)
        assert all(v == 0.0 for v in unpacked)

    @pytest.mark.asyncio
    async def test_zero_vector_retrieval_similarity(self, stress_storage: Storage):
        """A zero-vector memory should have 0.0 cosine similarity with any query."""
        mem = Memory(
            id=uuid4(), domain="test",
            created_at=datetime.now(timezone.utc), updated_at=datetime.now(timezone.utc),
            context={}, l0_tag="zero", l1_label="zero-vec",
            l2_summary="Zero vector embedding test",
            l3_full="Full zero vector", l4_raw="raw zero vector text",
            embedding=[0.0] * 384,
            embedding_model="mock",
        )
        await stress_storage.store_memory(mem)
        fetched = await stress_storage.get_memory(mem.id)
        assert fetched is not None
        # Cosine similarity with any non-zero vector should be 0.0
        query_vec = np.array(_deterministic_embed("anything"))
        mem_vec = np.array(fetched.embedding)
        norm_q = np.linalg.norm(query_vec)
        norm_m = np.linalg.norm(mem_vec)
        if norm_q > 0 and norm_m > 0:
            sim = float(np.dot(query_vec, mem_vec) / (norm_q * norm_m))
        else:
            sim = 0.0
        assert sim == 0.0, "Zero vector should have 0.0 similarity"

    def test_dimension_mismatch_packing_works(self):
        """_pack_embedding works regardless of dimension — it just packs the list."""
        emb_128 = _deterministic_embed("test", dim=128)
        packed = _pack_embedding(emb_128)
        unpacked = _unpack_embedding(packed, dim=128)
        assert len(unpacked) == 128
        # Also pack a 384-dim and verify
        emb_384 = _deterministic_embed("test", dim=384)
        packed_384 = _pack_embedding(emb_384)
        unpacked_384 = _unpack_embedding(packed_384, dim=384)
        assert len(unpacked_384) == 384

    def test_very_large_float_values_pack(self):
        """Very large (but finite) float values should pack successfully."""
        embedding = [1e30, -1e30, 1e-30, -1e-30]
        packed = _pack_embedding(embedding)
        unpacked = _unpack_embedding(packed, dim=4)
        assert len(unpacked) == 4
        assert not any(math.isnan(v) for v in unpacked)
        assert not any(math.isinf(v) for v in unpacked)

    def test_empty_embedding_raises(self):
        """Empty embedding list should raise ValueError from _pack_embedding."""
        with pytest.raises(ValueError, match="must not be empty"):
            _pack_embedding([])


# ── Domain boundary tests ─────────────────────────────────────────────


class TestDomainBoundaries:
    @pytest.mark.asyncio
    async def test_max_length_domain_succeeds(self, stress_fm: FractalMemory):
        """Domain at exactly max_domain_length (100 chars) should be accepted."""
        await stress_fm.session_start("boundary")
        domain = "a" * 100
        mem = await stress_fm.store("Valid max domain test", domain=domain)
        assert mem is not None
        assert mem.domain == domain

    @pytest.mark.asyncio
    async def test_over_max_domain_raises(self, stress_fm: FractalMemory):
        """Domain exceeding max_domain_length must raise ValueError."""
        await stress_fm.session_start("boundary")
        domain = "a" * 101
        with pytest.raises(ValueError, match="exceeds max length"):
            await stress_fm.store("Over max domain test", domain=domain)

    @pytest.mark.asyncio
    async def test_domain_with_special_chars_raises(self, stress_fm: FractalMemory):
        """Domain with disallowed special characters must raise ValueError."""
        await stress_fm.session_start("boundary")
        for bad_domain in ["hello world", "test!", "user@domain", "path/to", "semi;colon"]:
            with pytest.raises(ValueError, match="Invalid domain name"):
                await stress_fm.store("Special char domain test", domain=bad_domain)

    @pytest.mark.asyncio
    async def test_domain_with_dots_and_hyphens_succeeds(self, stress_fm: FractalMemory):
        """Domain with dots and hyphens (matching pattern) should succeed."""
        await stress_fm.session_start("boundary")
        domain = "my-project.v2.alpha"
        mem = await stress_fm.store("Dot-hyphen domain test", domain=domain)
        assert mem is not None
        assert mem.domain == domain

    @pytest.mark.asyncio
    async def test_empty_domain_raises(self, stress_fm: FractalMemory):
        """Empty string domain must raise ValueError."""
        await stress_fm.session_start("boundary")
        with pytest.raises(ValueError, match="must not be an empty string"):
            await stress_fm.store("Empty domain test", domain="")


# ── Numeric boundary tests ────────────────────────────────────────────


class TestNumericBoundaries:
    @pytest.mark.asyncio
    async def test_intensity_zero_succeeds(self, stress_fm: FractalMemory):
        """Intensity 0.0 should store successfully."""
        await stress_fm.session_start("boundary")
        mem = await stress_fm.store("Zero intensity memory", domain="boundary", intensity=0.0)
        assert mem is not None
        # Intensity may be gate-adjusted upward, but store itself should not reject 0.0
        assert mem.intensity >= 0.0

    @pytest.mark.asyncio
    async def test_intensity_one_succeeds(self, stress_fm: FractalMemory):
        """Intensity 1.0 should store successfully."""
        await stress_fm.session_start("boundary")
        mem = await stress_fm.store("Max intensity memory", domain="boundary", intensity=1.0)
        assert mem is not None
        assert mem.intensity == 1.0

    @pytest.mark.asyncio
    async def test_negative_intensity_raises(self, stress_fm: FractalMemory):
        """Negative intensity should raise ValueError."""
        await stress_fm.session_start("boundary")
        with pytest.raises(ValueError, match="intensity must be in"):
            await stress_fm.store("Negative intensity", domain="boundary", intensity=-0.1)

    @pytest.mark.asyncio
    async def test_over_one_intensity_raises(self, stress_fm: FractalMemory):
        """Intensity > 1.0 should raise ValueError."""
        await stress_fm.session_start("boundary")
        with pytest.raises(ValueError, match="intensity must be in"):
            await stress_fm.store("Over one intensity", domain="boundary", intensity=1.1)

    @pytest.mark.asyncio
    async def test_token_budget_zero_retrieve_raises(self, stress_fm: FractalMemory):
        """Token budget of 0 must raise ValueError (retrieval requires budget > 0)."""
        await stress_fm.session_start("boundary")
        await stress_fm.store("Memory for zero-budget retrieval test", domain="boundary")
        with pytest.raises(ValueError, match="token_budget must be > 0"):
            await stress_fm.retrieve("budget test", domain="boundary", token_budget=0)

    @pytest.mark.asyncio
    async def test_negative_token_budget_raises(self, stress_fm: FractalMemory):
        """Negative token budget should raise ValueError."""
        await stress_fm.session_start("boundary")
        await stress_fm.store("Some memory for budget test with enough words to store")
        with pytest.raises(ValueError, match="token_budget must be > 0"):
            await stress_fm.retrieve("budget test", token_budget=-100)

    @pytest.mark.asyncio
    async def test_vitality_zero_retrievals(self, stress_storage: Storage):
        """Memory with 0 retrieval and 0 miss counts should have valid vitality."""
        mem = Memory(
            id=uuid4(), domain="test",
            created_at=datetime.now(timezone.utc), updated_at=datetime.now(timezone.utc),
            context={}, l0_tag="v", l1_label="vitality",
            l2_summary="Zero retrieval vitality test",
            l3_full="Full vitality text", l4_raw="raw vitality text",
            embedding=_deterministic_embed("vitality-zero"),
            embedding_model="mock",
            retrieval_count=0, miss_count=0,
            vitality=1.0,
        )
        await stress_storage.store_memory(mem)
        updated = await stress_storage.update_vitality_batch([mem.id])
        assert updated == 1
        fetched = await stress_storage.get_memory(mem.id)
        assert fetched is not None
        assert not math.isnan(fetched.vitality)
        assert 0.0 <= fetched.vitality <= 1.0

    @pytest.mark.asyncio
    async def test_chronic_score_float_boundaries(self, stress_storage: Storage):
        """Chronic score at float boundaries (0.0, 1.0, tiny epsilon) should persist."""
        for chronic_val in [0.0, 1.0, 1e-15, 0.9999999999]:
            mem = Memory(
                id=uuid4(), domain="test",
                created_at=datetime.now(timezone.utc), updated_at=datetime.now(timezone.utc),
                context={}, l0_tag="c", l1_label="chronic",
                l2_summary=f"Chronic {chronic_val}",
                l3_full="Full", l4_raw="raw",
                embedding=_deterministic_embed(f"chronic-{chronic_val}"),
                embedding_model="mock",
                chronic_score=chronic_val,
            )
            await stress_storage.store_memory(mem)
            fetched = await stress_storage.get_memory(mem.id)
            assert fetched is not None
            assert not math.isnan(fetched.chronic_score)
            assert fetched.chronic_score == pytest.approx(chronic_val, abs=1e-10)
