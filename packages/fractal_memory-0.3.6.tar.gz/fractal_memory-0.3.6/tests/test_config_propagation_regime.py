"""Config propagation and regime transition tests."""

from __future__ import annotations

import dataclasses
import json
import os
from pathlib import Path
from unittest.mock import AsyncMock

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig, load_config


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = float(np.linalg.norm(vec))
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm():
    mock = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        lower = prompt.lower()
        if "summarize" in lower or "summary" in lower:
            return "Session summary."
        return json.dumps({
            "l0_tag": "test:tag", "l1_label": "label",
            "l2_summary": "summary", "l3_full": "full",
        })
    mock.complete = AsyncMock(side_effect=_complete)
    mock.model_name = "mock-model"
    return mock


def _make_mock_embeddings(dim: int = 384):
    mock = AsyncMock()
    mock.embed = AsyncMock(side_effect=lambda text: _deterministic_embed(text, dim))
    mock.embed_batch = AsyncMock(
        side_effect=lambda texts: [_deterministic_embed(t, dim) for t in texts]
    )
    mock.model_name = "mock-model"
    mock.dimension = dim
    return mock


@pytest.fixture
def config(tmp_path):
    return FractalConfig(
        db_path=tmp_path / "config_test.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
    )


@pytest.fixture
async def fm(config):
    fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
    await fm.initialize()
    yield fm
    await fm.close()


# ---------------------------------------------------------------------------
# Config propagation
# ---------------------------------------------------------------------------


class TestConfigPropagation:
    """Verify _propagate_config updates all subsystems."""

    def test_propagate_config_updates_all_subsystems(self, fm):
        """After _propagate_config, all subsystems should reference the new config."""
        original_config = fm._config
        new_config = dataclasses.replace(original_config, gate_signal_count=2)
        fm._propagate_config(new_config)

        # All subsystems should now have the new config
        subsystems = [
            ("storage", fm._storage),
            ("retrieval", fm._retrieval),
            ("gate", fm._gate),
            ("lifecycle", fm._lifecycle),
            ("session", fm._session),
            ("consolidation", fm._consolidation),
            ("associations", fm._associations),
            ("morphogens", fm._morphogens),
            ("self_model", fm._self_model),
            ("domain_manager", fm._domain_manager),
            ("bandits", fm._bandits),
            ("dreaming", fm._dreaming),
            ("maintenance", fm._maintenance),
            ("apoptosis", fm._apoptosis),
            ("scars", fm._scars),
            ("niche", fm._niche),
            ("buffer", fm._buffer),
            ("folding", fm._folding),
            ("cascade", fm._cascade),
            ("danger_theory", fm._danger_theory),
            ("store_signal_detector", fm._store_signal_detector),
            ("judge", fm._judge),
            ("states", fm._states),
        ]

        for name, subsystem in subsystems:
            assert subsystem._config is new_config, (
                f"Subsystem {name} still references old config"
            )

    def test_propagate_config_updates_fm_config(self, fm):
        """The FractalMemory's own _config should be updated."""
        new_config = dataclasses.replace(fm._config, gate_signal_count=3)
        fm._propagate_config(new_config)
        assert fm._config is new_config
        assert fm._config.gate_signal_count == 3

    def test_propagate_preserves_other_fields(self, fm):
        """Only changed fields should differ; the rest remain."""
        original = fm._config
        new_config = dataclasses.replace(original, gate_signal_count=2)
        fm._propagate_config(new_config)
        assert fm._config.db_path == original.db_path
        assert fm._config.embedding_dim == original.embedding_dim
        assert fm._config.top_l3 == original.top_l3


# ---------------------------------------------------------------------------
# Gate transition (Pioneer → Shrub)
# ---------------------------------------------------------------------------


class TestGateTransition:
    """Verify Pioneer → Shrub gate transition."""

    async def test_gate_stays_at_1_with_few_memories(self, fm):
        """Gate should remain at 1 with insufficient memories/sessions."""
        assert fm._config.gate_signal_count == 1
        await fm._check_gate_transition()
        assert fm._config.gate_signal_count == 1

    async def test_gate_transitions_with_enough_data(self, config):
        """Gate should transition to 2 when thresholds met."""
        # Create an FM with low thresholds for easy transition
        low_thresh_config = dataclasses.replace(
            config,
            domain_sparse_memory_threshold=2,
            domain_sparse_session_threshold=2,
        )
        fm = FractalMemory(
            low_thresh_config,
            llm=_make_mock_llm(),
            embeddings=_make_mock_embeddings(),
        )
        await fm.initialize()
        try:
            # Store enough memories and sessions
            await fm.session_start("test-domain")
            await fm.store("Memory 1")
            await fm.store("Memory 2")
            await fm.session_end()
            await fm.session_start("test-domain")
            await fm.store("Memory 3")
            await fm.session_end()

            # Now check transition
            await fm._check_gate_transition()
            assert fm._config.gate_signal_count == 2
        finally:
            await fm.close()


# ---------------------------------------------------------------------------
# Config validation
# ---------------------------------------------------------------------------


class TestConfigValidation:
    """Verify config validation catches invalid values."""

    def test_weight_sum_validation(self):
        """Scoring weights must sum to ~1.0."""
        with pytest.raises(ValueError, match="sum to 1.0"):
            FractalConfig(scoring_cosine_weight=0.9, scoring_intensity_weight=0.5)

    def test_zoom_ordering_validation(self):
        """L1 >= L2 >= L3 ordering must be enforced."""
        with pytest.raises(ValueError, match="ordering"):
            FractalConfig(top_l1=5, top_l2=10, top_l3=20)

    def test_gate_signal_count_range(self):
        """gate_signal_count must be in [1, 5]."""
        with pytest.raises(ValueError):
            FractalConfig(gate_signal_count=0)
        with pytest.raises(ValueError):
            FractalConfig(gate_signal_count=6)

    def test_embedding_dim_range(self):
        """embedding_dim must be in [1, 4096]."""
        with pytest.raises(ValueError):
            FractalConfig(embedding_dim=0)

    def test_rem_resonance_ordering(self):
        """rem_resonance_min must be < rem_resonance_max."""
        with pytest.raises(ValueError, match="rem_resonance_min"):
            FractalConfig(rem_resonance_min=0.8, rem_resonance_max=0.3)

    def test_valid_config_passes(self):
        """A valid config should not raise."""
        config = FractalConfig()
        assert config.gate_signal_count == 1


# ---------------------------------------------------------------------------
# load_config
# ---------------------------------------------------------------------------


class TestLoadConfig:
    """Verify load_config handles TOML, env vars, and defaults."""

    def test_default_config_loads(self):
        """load_config with no TOML should return defaults."""
        config = load_config(Path("/nonexistent/path.toml"))
        assert config.gate_signal_count == 1  # pioneer mode
        assert config.default_domain == "general"

    def test_env_var_override_respected(self, monkeypatch):
        """FRACTAL_* env vars should override config values."""
        monkeypatch.setenv("FRACTAL_DEFAULT_DOMAIN", "my-env-domain")
        config = load_config(Path("/nonexistent/path.toml"))
        assert config.default_domain == "my-env-domain"

    def test_env_var_llm_provider(self, monkeypatch):
        """FRACTAL_LLM_PROVIDER env var should be respected."""
        monkeypatch.setenv("FRACTAL_LLM_PROVIDER", "ollama")
        config = load_config(Path("/nonexistent/path.toml"))
        assert config.llm_provider == "ollama"

    def test_toml_loading(self, tmp_path):
        """Valid TOML file should be loaded."""
        toml_path = tmp_path / "config.toml"
        toml_path.write_text('default_domain = "toml-domain"\ntop_l3 = 5\n')
        config = load_config(toml_path)
        assert config.default_domain == "toml-domain"
        assert config.top_l3 == 5

    def test_env_overrides_toml(self, tmp_path, monkeypatch):
        """Env vars should take precedence over TOML."""
        toml_path = tmp_path / "config.toml"
        toml_path.write_text('default_domain = "toml-domain"\n')
        monkeypatch.setenv("FRACTAL_DEFAULT_DOMAIN", "env-domain")
        config = load_config(toml_path)
        assert config.default_domain == "env-domain"

    def test_pioneer_flag_sets_gate_to_1(self):
        """pioneer=True should set gate_signal_count=1."""
        config = load_config(Path("/nonexistent"), pioneer=True)
        assert config.gate_signal_count == 1

    def test_pioneer_false_uses_default(self):
        """pioneer=False should use the default gate_signal_count."""
        config = load_config(Path("/nonexistent"), pioneer=False)
        # Default in dataclass is 1, so still 1
        assert config.gate_signal_count == 1


# ---------------------------------------------------------------------------
# Folding regime
# ---------------------------------------------------------------------------


class TestFoldingRegime:
    """Verify folding regime transitions."""

    async def test_bootstrap_regime_initial(self, fm):
        """New system should start in BOOTSTRAP regime."""
        # determine_regime is called during session_start
        await fm.session_start("test-domain")
        # With 0 sessions and 0 memories, should be bootstrap
        regime = fm._folding.current_regime
        assert regime in ("BOOTSTRAP", "LEARNING", "MATURE")  # depends on session count

    async def test_folding_is_active_returns_bool(self, fm):
        """is_active should return a boolean."""
        await fm.session_start("test-domain")
        for subsystem in ("morphogens", "bandits", "states", "niche"):
            result = fm._folding.is_active(subsystem)
            assert isinstance(result, bool)

    def test_determine_regime_with_many_sessions(self, fm):
        """With many sessions and memories, should transition to learning/mature."""
        fm._folding.determine_regime(
            session_count=20, memory_count=200, morphogens_converged=True
        )
        regime = fm._folding.current_regime
        assert regime in ("LEARNING", "MATURE")

    def test_determine_regime_with_few_sessions(self, fm):
        """With few sessions, should remain in bootstrap."""
        fm._folding.determine_regime(
            session_count=1, memory_count=5, morphogens_converged=False
        )
        assert fm._folding.current_regime == "BOOTSTRAP"
