"""Resource lifecycle tests — verify proper open/close of DB, LLM, etc."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch, MagicMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.storage import Storage


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = float(np.linalg.norm(vec))
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm():
    mock = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        return json.dumps({
            "l0_tag": "test:tag", "l1_label": "label",
            "l2_summary": "summary", "l3_full": "full",
        })
    mock.complete = AsyncMock(side_effect=_complete)
    mock.model_name = "mock-model"
    return mock


def _make_mock_embeddings(dim: int = 384):
    mock = AsyncMock()
    mock.embed = AsyncMock(side_effect=lambda text: _deterministic_embed(text, dim))
    mock.embed_batch = AsyncMock(
        side_effect=lambda texts: [_deterministic_embed(t, dim) for t in texts]
    )
    mock.model_name = "mock-model"
    mock.dimension = dim
    return mock


@pytest.fixture
def config(tmp_path):
    return FractalConfig(
        db_path=tmp_path / "resource_test.db",
        gate_signal_count=1,
    )


# ---------------------------------------------------------------------------
# Storage lifecycle
# ---------------------------------------------------------------------------


class TestStorageLifecycle:
    """Verify Storage open/close behavior."""

    async def test_storage_initialize_creates_connection(self, config):
        storage = Storage(config)
        await storage.initialize()
        assert storage._conn is not None
        await storage.close()

    async def test_storage_close_sets_conn_none(self, config):
        storage = Storage(config)
        await storage.initialize()
        await storage.close()
        assert storage._conn is None

    async def test_storage_double_close_no_error(self, config):
        """Calling close() twice should not raise."""
        storage = Storage(config)
        await storage.initialize()
        await storage.close()
        # Second close should be safe
        await storage.close()

    async def test_storage_ensure_conn_raises_after_close(self, config):
        """_ensure_conn() should raise RuntimeError after close."""
        storage = Storage(config)
        await storage.initialize()
        await storage.close()
        with pytest.raises(RuntimeError, match="not initialized"):
            storage._ensure_conn()

    async def test_storage_operations_after_close_raise(self, config):
        """DB operations after close should raise."""
        storage = Storage(config)
        await storage.initialize()
        await storage.close()
        with pytest.raises(RuntimeError):
            await storage.count_memories()


# ---------------------------------------------------------------------------
# FractalMemory lifecycle
# ---------------------------------------------------------------------------


class TestFractalMemoryLifecycle:
    """Verify FractalMemory open/close behavior."""

    async def test_close_calls_storage_close(self, config):
        fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        with patch.object(fm._storage, "close", wraps=fm._storage.close) as spy:
            await fm.close()
            spy.assert_called_once()

    async def test_close_sets_initialized_false(self, config):
        fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        assert fm._initialized is True
        await fm.close()
        assert fm._initialized is False

    async def test_double_close_no_error(self, config):
        """Calling close() twice should not raise."""
        fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        await fm.close()
        await fm.close()  # Should not raise

    async def test_context_manager_closes_on_exit(self, config):
        """async with FractalMemory() should close on exit."""
        async with FractalMemory(
            config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings()
        ) as fm:
            assert fm._initialized is True
        assert fm._initialized is False

    async def test_context_manager_closes_on_exception(self, config):
        """FractalMemory should close even if body raises."""
        fm_ref = None
        try:
            async with FractalMemory(
                config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings()
            ) as fm:
                fm_ref = fm
                raise ValueError("test error")
        except ValueError:
            pass
        assert fm_ref is not None
        assert fm_ref._initialized is False


# ---------------------------------------------------------------------------
# LLM provider lifecycle
# ---------------------------------------------------------------------------


class TestLLMProviderLifecycle:
    """Verify LLM provider close is called."""

    async def test_close_calls_llm_provider_close(self, config):
        """If LLM provider has close(), it should be called."""
        mock_llm = _make_mock_llm()
        # Add a close method to simulate OllamaProvider/AnthropicProvider
        mock_llm.close = AsyncMock()
        fm = FractalMemory(config, llm=mock_llm, embeddings=_make_mock_embeddings())
        await fm.initialize()
        # The raw provider is stored inside the tracker
        fm._llm_tracker._provider = mock_llm
        await fm.close()
        mock_llm.close.assert_called_once()

    async def test_close_handles_llm_close_failure(self, config):
        """LLM close failure should not prevent storage close."""
        mock_llm = _make_mock_llm()
        mock_llm.close = AsyncMock(side_effect=RuntimeError("close failed"))
        fm = FractalMemory(config, llm=mock_llm, embeddings=_make_mock_embeddings())
        await fm.initialize()
        fm._llm_tracker._provider = mock_llm
        # Should not raise despite LLM close failure
        await fm.close()
        assert fm._initialized is False


# ---------------------------------------------------------------------------
# Warmup task lifecycle
# ---------------------------------------------------------------------------


class TestWarmupTaskLifecycle:
    """Verify embedding warmup task is properly managed."""

    async def test_close_cancels_warmup_task(self, config):
        """close() should cancel the warmup task if still running."""
        fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        # The warmup task should exist
        assert hasattr(fm, "_warmup_task")
        await fm.close()
        # After close, task should be done or cancelled
        if hasattr(fm, "_warmup_task"):
            assert fm._warmup_task.done() or fm._warmup_task.cancelled()
