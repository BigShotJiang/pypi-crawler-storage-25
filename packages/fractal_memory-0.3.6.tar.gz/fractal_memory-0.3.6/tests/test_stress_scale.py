"""Scale stress tests — large memory counts, retrieval quality at scale.

Tests system behavior with 500-1000+ memories to verify:
- Retrieval quality doesn't degrade at scale
- Storage performance stays acceptable
- Token budget enforcement works under pressure
- Association network handles dense graphs
- Lifecycle state machine works across many memories
"""

from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path
from unittest.mock import AsyncMock

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.llm import LLMProvider
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.storage import Storage


# ── Helpers ────────────────────────────────────────────────────────────

def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm() -> LLMProvider:
    provider = AsyncMock(spec=LLMProvider)

    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        if "summarize" in prompt.lower():
            return "Scale test summary."
        return json.dumps({
            "l0_tag": "scale:test",
            "l1_label": "scale-test",
            "l2_summary": "A scale test memory.",
            "l3_full": "A scale test memory with full context.",
        })

    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings():
    provider = AsyncMock()

    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text)

    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t) for t in texts]

    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = 384
    return provider


@pytest.fixture
def scale_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "scale_test.db",
        gate_signal_count=1,
        llm_max_calls_per_session=50000,
    )


@pytest.fixture
async def scale_fm(scale_config: FractalConfig):
    fm = FractalMemory(scale_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
    await fm.initialize()
    yield fm
    if fm._session.current_session is not None:
        try:
            await fm.session_end()
        except Exception:
            pass
    await fm.close()


@pytest.fixture
async def scale_storage(scale_config: FractalConfig):
    s = Storage(scale_config)
    await s.initialize()
    yield s
    await s.close()


# ── Large memory count ────────────────────────────────────────────────

TOPIC_CATEGORIES = [
    "Python programming best practices",
    "JavaScript frontend frameworks",
    "Database optimization techniques",
    "DevOps and CI/CD pipelines",
    "Machine learning algorithms",
    "API design patterns",
    "Security best practices",
    "Cloud infrastructure management",
    "Testing strategies",
    "System architecture decisions",
]


class TestLargeScale:
    @pytest.mark.asyncio
    async def test_500_memories_store_and_retrieve(self, scale_fm: FractalMemory):
        """Store 500 memories across topics, verify retrieval still works."""
        await scale_fm.session_start("scale")

        start = time.perf_counter()
        stored_ids = []
        for i in range(500):
            topic = TOPIC_CATEGORIES[i % len(TOPIC_CATEGORIES)]
            mem = await scale_fm.store(
                f"{topic}: detail #{i} about subtopic {i % 50}",
                domain="scale",
            )
            assert mem is not None, f"Store {i} failed"
            stored_ids.append(mem.id)
        store_elapsed = time.perf_counter() - start

        # Should complete in under 2 minutes
        assert store_elapsed < 120, f"500 stores took {store_elapsed:.1f}s"

        # Retrieve should still find relevant memories
        start = time.perf_counter()
        result = await scale_fm.retrieve(
            "How to optimize database queries?", domain="scale"
        )
        retrieve_elapsed = time.perf_counter() - start

        assert len(result.l3_memories) > 0, "Should find L3 memories at 500 scale"
        assert retrieve_elapsed < 5, f"Retrieve took {retrieve_elapsed:.2f}s at 500 memories"

    @pytest.mark.asyncio
    async def test_retrieval_quality_at_200(self, scale_fm: FractalMemory):
        """At 200 memories, retrieval should still rank relevant memories highly."""
        await scale_fm.session_start("scale")

        # Store 200 diverse memories with 1 known target
        for i in range(199):
            await scale_fm.store(f"Generic memory {i} about unrelated topic {i % 30}", domain="scale")

        target = await scale_fm.store(
            "Always use connection pooling for PostgreSQL in production",
            domain="scale",
        )

        result = await scale_fm.retrieve(
            "database connection pooling", domain="scale"
        )
        l3_ids = [m.id for m in result.l3_memories]
        assert target.id in l3_ids, "Target memory should be in L3 at 200 memories"


# ── Storage direct scale tests ────────────────────────────────────────

class TestStorageScale:
    @pytest.mark.asyncio
    async def test_1000_direct_storage_inserts(self, scale_storage: Storage):
        """1000 direct inserts to storage layer should complete in under 30s."""
        from datetime import datetime
        from uuid import uuid4

        start = time.perf_counter()
        for i in range(1000):
            mem = Memory(
                id=uuid4(), domain=f"domain-{i % 5}",
                created_at=datetime.utcnow(), updated_at=datetime.utcnow(),
                context={}, l0_tag=f"t{i}", l1_label=f"l{i}",
                l2_summary=f"summary {i}", l3_full=f"full {i}",
                l4_raw=f"raw text {i} " * 10,
                embedding=_deterministic_embed(f"storage-scale-{i}"),
                embedding_model="mock",
                intensity=0.5 + (i % 10) * 0.05,
            )
            await scale_storage.store_memory(mem)
        elapsed = time.perf_counter() - start

        assert elapsed < 30, f"1000 inserts took {elapsed:.1f}s"
        count = await scale_storage.count_memories()
        assert count == 1000

    @pytest.mark.asyncio
    async def test_list_domains_with_many_domains(self, scale_storage: Storage):
        """20 domains should all appear in list_domains."""
        from datetime import datetime
        from uuid import uuid4

        for i in range(20):
            mem = Memory(
                id=uuid4(), domain=f"domain-{i}",
                created_at=datetime.utcnow(), updated_at=datetime.utcnow(),
                context={}, l0_tag="t", l1_label="l",
                l2_summary="s", l3_full="f", l4_raw="r",
                embedding=_deterministic_embed(f"domain-{i}"),
                embedding_model="mock",
            )
            await scale_storage.store_memory(mem)

        domains = await scale_storage.list_domains()
        assert len(domains) == 20

    @pytest.mark.asyncio
    async def test_get_all_memories_for_large_domain(self, scale_storage: Storage):
        """Should efficiently fetch 500 memories from a single domain."""
        from datetime import datetime
        from uuid import uuid4

        for i in range(500):
            mem = Memory(
                id=uuid4(), domain="big-domain",
                created_at=datetime.utcnow(), updated_at=datetime.utcnow(),
                context={}, l0_tag=f"t{i}", l1_label=f"l{i}",
                l2_summary=f"s{i}", l3_full=f"f{i}", l4_raw=f"r{i}",
                embedding=_deterministic_embed(f"big-{i}"),
                embedding_model="mock",
            )
            await scale_storage.store_memory(mem)

        start = time.perf_counter()
        memories = await scale_storage.get_memories_by_domain("big-domain")
        elapsed = time.perf_counter() - start

        assert len(memories) == 500
        assert elapsed < 5, f"Fetching 500 memories took {elapsed:.2f}s"


# ── Association network scale ─────────────────────────────────────────

class TestAssociationScale:
    @pytest.mark.asyncio
    async def test_dense_association_graph(self, scale_fm: FractalMemory):
        """Store 100 memories, retrieve many times to build dense association graph."""
        await scale_fm.session_start("scale")

        mems = []
        for i in range(100):
            m = await scale_fm.store(f"Association test memory {i} about topic {i % 10}", domain="scale")
            mems.append(m)

        # Do many retrievals to build associations via co-retrieval
        for i in range(50):
            await scale_fm.retrieve(f"topic {i % 10}", domain="scale")

        stats = await scale_fm.get_stats()
        assoc_count = stats.get("associations", {}).get("total_edges", 0)
        # Should have formed some associations
        assert assoc_count >= 0  # At minimum, doesn't crash


# ── Token budget enforcement ──────────────────────────────────────────

class TestTokenBudgetScale:
    @pytest.mark.asyncio
    async def test_token_budget_respected_at_300_memories(self, scale_fm: FractalMemory):
        """Token budget should not be exceeded even with 300 memories."""
        await scale_fm.session_start("scale")

        for i in range(300):
            await scale_fm.store(f"Token budget test memory {i}: " + "x" * 50, domain="scale")

        result = await scale_fm.retrieve("token budget test", domain="scale")
        assert result.token_budget_used <= result.token_budget_total, (
            f"Budget exceeded: {result.token_budget_used} > {result.token_budget_total}"
        )


# ── Lifecycle distribution at scale ───────────────────────────────────

class TestLifecycleScale:
    @pytest.mark.asyncio
    async def test_lifecycle_distribution_across_sessions(self, scale_config: FractalConfig):
        """Multiple sessions with repeated retrievals should promote memories."""
        fm = FractalMemory(scale_config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()

        try:
            # Session 1: store memories
            await fm.session_start("scale")
            for i in range(20):
                await fm.store(f"Lifecycle scale memory {i}", domain="scale")
            await fm.session_end()

            # Sessions 2-4: retrieve repeatedly to trigger promotions
            for session_num in range(3):
                await fm.session_start("scale")
                for i in range(20):
                    await fm.retrieve(f"Lifecycle scale memory {i}", domain="scale")
                await fm.session_end()

            # Check lifecycle distribution
            await fm.session_start("scale")
            stats = await fm.get_stats()
            lifecycle = stats.get("lifecycle", {})
            # After multiple retrievals, some should have been promoted
            confirmed = lifecycle.get("confirmed", 0)
            probation = lifecycle.get("probation", 0)
            total = confirmed + probation + lifecycle.get("permanent", 0) + lifecycle.get("safety_critical", 0)
            assert total >= 20, f"Should have at least 20 memories, got {total}"
        finally:
            if fm._session.current_session:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()


# ── Database file size ────────────────────────────────────────────────

class TestDatabaseSize:
    @pytest.mark.asyncio
    async def test_db_size_reasonable_at_500_memories(self, scale_config: FractalConfig, scale_storage: Storage):
        """500 memories with 384-dim embeddings should keep DB under 10MB."""
        from datetime import datetime
        from uuid import uuid4

        for i in range(500):
            mem = Memory(
                id=uuid4(), domain="size-test",
                created_at=datetime.utcnow(), updated_at=datetime.utcnow(),
                context={}, l0_tag=f"t{i}", l1_label=f"l{i}",
                l2_summary=f"summary {i} " * 5, l3_full=f"full text {i} " * 20,
                l4_raw=f"raw text content {i} " * 50,
                embedding=_deterministic_embed(f"size-{i}"),
                embedding_model="mock",
            )
            await scale_storage.store_memory(mem)

        db_path = scale_config.db_path
        db_size_mb = db_path.stat().st_size / (1024 * 1024)
        assert db_size_mb < 10, f"DB is {db_size_mb:.2f}MB for 500 memories (limit: 10MB)"
