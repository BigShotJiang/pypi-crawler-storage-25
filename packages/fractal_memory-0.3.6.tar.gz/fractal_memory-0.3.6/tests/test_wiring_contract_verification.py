"""Wiring contract verification — spy on real subsystems to ensure they're called."""

from __future__ import annotations

import json
from datetime import datetime
from unittest.mock import AsyncMock, patch, MagicMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus, Memory


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = float(np.linalg.norm(vec))
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm():
    mock = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        lower = prompt.lower()
        if "summarize" in lower or "summary" in lower:
            return "Session focused on testing. Tests were written and verified."
        return json.dumps({
            "l0_tag": "test:tag",
            "l1_label": "Test label",
            "l2_summary": "Test summary for memory",
            "l3_full": "Full test context for the memory entry",
        })
    mock.complete = AsyncMock(side_effect=_complete)
    mock.model_name = "mock-model"
    return mock


def _make_mock_embeddings(dim: int = 384):
    mock = AsyncMock()
    mock.embed = AsyncMock(side_effect=lambda text: _deterministic_embed(text, dim))
    mock.embed_batch = AsyncMock(
        side_effect=lambda texts: [_deterministic_embed(t, dim) for t in texts]
    )
    mock.model_name = "mock-model"
    mock.dimension = dim
    return mock


@pytest.fixture
def config(tmp_path):
    return FractalConfig(
        db_path=tmp_path / "wiring_test.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
        enable_llm_judge=False,  # Avoid LLM cost in wiring tests
    )


@pytest.fixture
async def fm(config):
    fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
    await fm.initialize()
    yield fm
    await fm.close()


# ---------------------------------------------------------------------------
# Store wiring
# ---------------------------------------------------------------------------


class TestStoreWiring:
    """Verify subsystems called during store()."""

    async def test_store_calls_gate_evaluate(self, fm):
        await fm.session_start("test-domain")
        with patch.object(fm._gate, "evaluate", wraps=fm._gate.evaluate) as spy:
            await fm.store("Test memory text")
            spy.assert_called_once()

    async def test_store_calls_zoom_generate(self, fm):
        await fm.session_start("test-domain")
        with patch.object(fm._zoom, "generate", wraps=fm._zoom.generate) as spy:
            await fm.store("Test memory for zoom")
            spy.assert_called_once()

    async def test_store_calls_embeddings_embed(self, fm):
        await fm.session_start("test-domain")
        with patch.object(fm._embeddings, "embed", wraps=fm._embeddings.embed) as spy:
            await fm.store("Test memory for embedding")
            assert spy.call_count >= 1

    async def test_store_calls_storage_store_memory(self, fm):
        await fm.session_start("test-domain")
        with patch.object(fm._storage, "store_memory", wraps=fm._storage.store_memory) as spy:
            result = await fm.store("Test memory for storage")
            if result is not None:  # Not gated out
                spy.assert_called_once()

    async def test_store_calls_session_record_store(self, fm):
        await fm.session_start("test-domain")
        with patch.object(fm._session, "record_store", wraps=fm._session.record_store) as spy:
            result = await fm.store("Test memory for session record")
            if result is not None:
                spy.assert_called_once()

    async def test_store_calls_buffer_add_just_written(self, fm):
        await fm.session_start("test-domain")
        with patch.object(fm._buffer, "add_just_written", wraps=fm._buffer.add_just_written) as spy:
            result = await fm.store("Test memory for buffer")
            if result is not None:
                spy.assert_called_once()

    async def test_store_calls_retrieval_invalidate_cache(self, fm):
        await fm.session_start("test-domain")
        with patch.object(fm._retrieval, "invalidate_cache", wraps=fm._retrieval.invalidate_cache) as spy:
            result = await fm.store("Cache invalidation test")
            if result is not None:
                spy.assert_called()


# ---------------------------------------------------------------------------
# Retrieve wiring
# ---------------------------------------------------------------------------


class TestRetrieveWiring:
    """Verify subsystems called during retrieve()."""

    async def _store_and_retrieve(self, fm, query="test query"):
        await fm.session_start("test-domain")
        await fm.store("Python is great for backend development")
        await fm.store("TypeScript is used for frontend work")
        return await fm.retrieve(query)

    async def test_retrieve_calls_embeddings_embed(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Some memory")
        with patch.object(fm._embeddings, "embed", wraps=fm._embeddings.embed) as spy:
            await fm.retrieve("test query")
            assert spy.call_count >= 1

    async def test_retrieve_calls_retrieval_engine(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Some memory")
        with patch.object(fm._retrieval, "retrieve", wraps=fm._retrieval.retrieve) as spy:
            await fm.retrieve("test query")
            spy.assert_called_once()

    async def test_retrieve_calls_buffer_update_habituation(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Some memory")
        with patch.object(fm._buffer, "update_habituation", wraps=fm._buffer.update_habituation) as spy:
            await fm.retrieve("test query")
            spy.assert_called_once()

    async def test_retrieve_calls_buffer_get_buffer_ids(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Some memory")
        with patch.object(fm._buffer, "get_buffer_ids", wraps=fm._buffer.get_buffer_ids) as spy:
            await fm.retrieve("test query")
            spy.assert_called_once()

    async def test_retrieve_calls_folding_is_active(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Some memory")
        with patch.object(fm._folding, "is_active", wraps=fm._folding.is_active) as spy:
            await fm.retrieve("test query")
            assert spy.call_count >= 1  # Called for morphogens, bandits, states, niche

    async def test_retrieve_calls_session_record_retrieval(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Some memory")
        with patch.object(fm._session, "record_retrieval", wraps=fm._session.record_retrieval) as spy:
            await fm.retrieve("test query")
            spy.assert_called_once()

    async def test_retrieve_calls_self_model_record_retrieval(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Some memory")
        with patch.object(fm._self_model, "record_retrieval", wraps=fm._self_model.record_retrieval) as spy:
            await fm.retrieve("test query")
            spy.assert_called_once()

    async def test_retrieve_calls_lifecycle_on_memory_retrieved(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Important memory for retrieval")
        with patch.object(fm._lifecycle, "on_memory_retrieved", wraps=fm._lifecycle.on_memory_retrieved) as spy:
            result = await fm.retrieve("important memory")
            if result.l3_memories:
                assert spy.call_count >= 1

    async def test_retrieve_with_user_message_calls_danger_detect(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Some memory about testing")
        with patch.object(fm._danger_theory, "detect_signals", wraps=fm._danger_theory.detect_signals) as spy:
            await fm.retrieve("test query", user_message="that's wrong, not what I asked")
            spy.assert_called_once()

    async def test_retrieve_calls_judge_record_triple(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Memory for judge")
        with patch.object(fm._judge, "record_triple", wraps=fm._judge.record_triple) as spy:
            result = await fm.retrieve("judge test query")
            if result.l3_memories:
                assert spy.call_count >= 1

    async def test_retrieve_calls_maintenance_intra_session(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Some memory")
        with patch.object(fm._maintenance, "intra_session_maintenance", wraps=fm._maintenance.intra_session_maintenance) as spy:
            await fm.retrieve("test query")
            spy.assert_called_once()


# ---------------------------------------------------------------------------
# Session start wiring
# ---------------------------------------------------------------------------


class TestSessionStartWiring:
    """Verify subsystems called during session_start()."""

    async def test_session_start_calls_buffer_clear(self, fm):
        with patch.object(fm._buffer, "clear", wraps=fm._buffer.clear) as spy:
            await fm.session_start("test-domain")
            spy.assert_called_once()

    async def test_session_start_calls_danger_theory_reset(self, fm):
        with patch.object(fm._danger_theory, "reset_session", wraps=fm._danger_theory.reset_session) as spy:
            await fm.session_start("test-domain")
            spy.assert_called_once()

    async def test_session_start_calls_states_reset(self, fm):
        with patch.object(fm._states, "reset_session", wraps=fm._states.reset_session) as spy:
            await fm.session_start("test-domain")
            spy.assert_called_once()

    async def test_session_start_calls_niche_increment(self, fm):
        with patch.object(fm._niche, "increment_session", wraps=fm._niche.increment_session) as spy:
            await fm.session_start("test-domain")
            spy.assert_called_once()

    async def test_session_start_calls_check_gate_transition(self, fm):
        with patch.object(fm, "_check_gate_transition", wraps=fm._check_gate_transition) as spy:
            await fm.session_start("test-domain")
            spy.assert_called()

    async def test_session_start_calls_folding_determine_regime(self, fm):
        with patch.object(fm._folding, "determine_regime", wraps=fm._folding.determine_regime) as spy:
            await fm.session_start("test-domain")
            spy.assert_called_once()

    async def test_session_start_calls_session_start(self, fm):
        with patch.object(fm._session, "start", wraps=fm._session.start) as spy:
            await fm.session_start("test-domain")
            spy.assert_called_once()

    async def test_session_start_calls_llm_tracker_reset(self, fm):
        with patch.object(fm._llm_tracker, "reset_session", wraps=fm._llm_tracker.reset_session) as spy:
            await fm.session_start("test-domain")
            spy.assert_called_once()

    async def test_session_start_calls_maintenance_should_run(self, fm):
        with patch.object(fm._maintenance, "should_run_scheduled", wraps=fm._maintenance.should_run_scheduled) as spy:
            await fm.session_start("test-domain")
            assert spy.call_count >= 1  # Called for daily, weekly, monthly


# ---------------------------------------------------------------------------
# Session end wiring
# ---------------------------------------------------------------------------


class TestSessionEndWiring:
    """Verify subsystems called during session_end()."""

    async def test_session_end_calls_session_end(self, fm):
        await fm.session_start("test-domain")
        with patch.object(fm._session, "end", wraps=fm._session.end) as spy:
            await fm.session_end()
            spy.assert_called_once()

    async def test_session_end_runs_hooks(self, fm):
        """Session end hooks are registered and the hook runner invokes them."""
        await fm.session_start("test-domain")
        # Verify hooks are registered on the session manager
        assert len(fm._session._on_session_end_hooks) >= 6, (
            f"Expected >=6 session-end hooks, got {len(fm._session._on_session_end_hooks)}"
        )
        # Track which hooks fire by wrapping them
        called = []
        original_hooks = list(fm._session._on_session_end_hooks)
        fm._session._on_session_end_hooks.clear()
        for hook in original_hooks:
            async def _wrapper(h=hook):
                called.append(h.__name__)
                await h()
            fm._session._on_session_end_hooks.append(_wrapper)
        await fm.session_end()
        assert len(called) == len(original_hooks)


# ---------------------------------------------------------------------------
# Correct/Confirm wiring
# ---------------------------------------------------------------------------


class TestCorrectionWiring:
    """Verify subsystems called during correct() and confirm()."""

    async def test_correct_calls_scar_create(self, fm):
        await fm.session_start("test-domain")
        mem = await fm.store("Original memory text")
        assert mem is not None
        with patch.object(fm._scars, "create_scar", wraps=fm._scars.create_scar) as spy:
            await fm.correct(mem.id, "Corrected memory text that is very different from original")
            spy.assert_called_once()

    async def test_correct_calls_zoom_generate(self, fm):
        await fm.session_start("test-domain")
        mem = await fm.store("Original memory for zoom test")
        assert mem is not None
        with patch.object(fm._zoom, "generate", wraps=fm._zoom.generate) as spy:
            await fm.correct(mem.id, "Completely different correction text")
            spy.assert_called()

    async def test_correct_calls_embeddings_embed(self, fm):
        await fm.session_start("test-domain")
        mem = await fm.store("Original for embed test")
        assert mem is not None
        with patch.object(fm._embeddings, "embed", wraps=fm._embeddings.embed) as spy:
            await fm.correct(mem.id, "New correction text")
            assert spy.call_count >= 1

    async def test_confirm_calls_lifecycle_on_retrieved(self, fm):
        await fm.session_start("test-domain")
        mem = await fm.store("Memory to confirm")
        assert mem is not None
        with patch.object(fm._lifecycle, "on_memory_retrieved", wraps=fm._lifecycle.on_memory_retrieved) as spy:
            await fm.confirm(mem.id)
            spy.assert_called_once()

    async def test_confirm_calls_associations_get_edges(self, fm):
        await fm.session_start("test-domain")
        mem = await fm.store("Memory for edge check")
        assert mem is not None
        with patch.object(fm._associations, "get_edges", wraps=fm._associations.get_edges) as spy:
            await fm.confirm(mem.id)
            spy.assert_called_once()


# ---------------------------------------------------------------------------
# Maintenance wiring
# ---------------------------------------------------------------------------


class TestMaintenanceWiring:
    """Verify subsystems called during maintenance tiers."""

    async def test_daily_maintenance_calls_consolidation_prune(self, fm):
        await fm.initialize()
        with patch.object(fm._consolidation, "prune_expired", wraps=fm._consolidation.prune_expired) as spy:
            await fm._maintenance.daily_maintenance()
            spy.assert_called_once()

    async def test_daily_maintenance_calls_weaken_edges(self, fm):
        await fm.initialize()
        with patch.object(fm._storage, "weaken_unused_edges", wraps=fm._storage.weaken_unused_edges) as spy:
            await fm._maintenance.daily_maintenance()
            spy.assert_called_once()

    async def test_daily_maintenance_calls_update_vitality(self, fm):
        await fm.initialize()
        with patch.object(fm._storage, "update_vitality_all", wraps=fm._storage.update_vitality_all) as spy:
            await fm._maintenance.daily_maintenance()
            spy.assert_called_once()

    async def test_weekly_maintenance_calls_niche_detect(self, fm):
        await fm.initialize()
        with patch.object(fm._niche, "detect_domain_clusters", wraps=fm._niche.detect_domain_clusters) as spy:
            await fm._maintenance.weekly_maintenance()
            spy.assert_called_once()

    async def test_monthly_maintenance_calls_apoptosis(self, fm):
        await fm.initialize()
        with patch.object(fm._apoptosis, "batch_check", wraps=fm._apoptosis.batch_check) as spy:
            # Need at least one memory for apoptosis to run
            await fm.session_start("test-domain")
            await fm.store("Memory for apoptosis test")
            await fm._maintenance.monthly_maintenance()
            # batch_check may be called if domain has memories
            # If no memories exist in domain list, it won't be called

    async def test_monthly_maintenance_calls_self_model_health(self, fm):
        await fm.initialize()
        with patch.object(fm._self_model, "health", wraps=fm._self_model.health) as spy:
            await fm._maintenance.monthly_maintenance()
            spy.assert_called_once()

    async def test_monthly_maintenance_calls_flag_parameter_drift(self, fm):
        await fm.initialize()
        with patch.object(fm._self_model, "flag_parameter_drift", wraps=fm._self_model.flag_parameter_drift) as spy:
            await fm._maintenance.monthly_maintenance()
            assert spy.call_count >= 1


# ---------------------------------------------------------------------------
# Initialize wiring
# ---------------------------------------------------------------------------


class TestInitializeWiring:
    """Verify subsystems called during initialize()."""

    async def test_initialize_calls_storage_initialize(self, config):
        fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        with patch.object(fm._storage, "initialize", wraps=fm._storage.initialize) as spy:
            await fm.initialize()
            spy.assert_called_once()
        await fm.close()

    async def test_initialize_calls_check_gate_transition(self, config):
        fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        with patch.object(fm, "_check_gate_transition", wraps=fm._check_gate_transition) as spy:
            await fm.initialize()
            spy.assert_called_once()
        await fm.close()


# ---------------------------------------------------------------------------
# Close wiring
# ---------------------------------------------------------------------------


class TestCloseWiring:
    """Verify subsystems called during close()."""

    async def test_close_calls_storage_close(self, config):
        fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        with patch.object(fm._storage, "close", wraps=fm._storage.close) as spy:
            await fm.close()
            spy.assert_called_once()
