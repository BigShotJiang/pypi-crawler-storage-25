"""Stress tests for config validation and extreme-but-valid config behaviour.

Tests fall into two categories:
1. Validation tests (sync) — verify FractalConfig.__post_init__ rejects bad values.
2. Pipeline tests (async) — verify FractalMemory operates correctly under
   extreme-but-valid config permutations with mocked LLM/embeddings.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock

import numpy as np
import pytest

from fractal_memory import FractalMemory, Signal
from fractal_memory.config import FractalConfig
from fractal_memory.llm import LLMProvider
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.storage import Storage


# ── Helpers ──────────────────────────────────────────────────────────────


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive unit-norm embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm() -> LLMProvider:
    """Return an AsyncMock LLM provider that handles zoom and summary prompts."""
    provider = AsyncMock(spec=LLMProvider)

    async def _complete(
        prompt: str, system: str | None = None, max_tokens: int = 500
    ) -> str:
        if "summarize" in prompt.lower() or "Summarize" in prompt:
            return "Config permutation test session summary."
        return json.dumps(
            {
                "l0_tag": "cfg:perm",
                "l1_label": "config-perm-test",
                "l2_summary": "A config-permutation stress test memory.",
                "l3_full": "A config-permutation stress test memory with full context.",
            }
        )

    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings(dim: int = 384):
    """Return an AsyncMock embedding provider for the given dimensionality."""
    provider = AsyncMock()

    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text, dim=dim)

    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t, dim=dim) for t in texts]

    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = dim
    return provider


# ── Async fixture helper ─────────────────────────────────────────────────


async def _make_fm(config: FractalConfig, dim: int = 384) -> FractalMemory:
    """Build and initialise a FractalMemory with mocked providers."""
    fm = FractalMemory(
        config,
        llm=_make_mock_llm(),
        embeddings=_make_mock_embeddings(dim=dim),
    )
    await fm.initialize()
    return fm


async def _teardown_fm(fm: FractalMemory) -> None:
    """Clean-up helper: end session if active, then close."""
    if fm._session.current_session is not None:
        try:
            await fm.session_end()
        except Exception:
            pass
    await fm.close()


# ═══════════════════════════════════════════════════════════════════════════
# PART 1 — Config validation tests (sync, no async needed)
# ═══════════════════════════════════════════════════════════════════════════


class TestConfigValidationRejections:
    """Verify __post_init__ raises ValueError for invalid config values."""

    def test_weight_sum_not_one(self):
        """scoring_cosine_weight + scoring_intensity_weight must sum to 1.0 +/- 0.01."""
        with pytest.raises(ValueError, match="sum to 1.0"):
            FractalConfig(scoring_cosine_weight=0.9, scoring_intensity_weight=0.0)

    def test_zoom_ordering_violated(self):
        """top_l3 > top_l2 violates zoom level ordering constraint."""
        with pytest.raises(ValueError, match="Zoom level ordering violated"):
            FractalConfig(top_l1=100, top_l2=5, top_l3=10)

    def test_gate_signal_count_zero(self):
        """gate_signal_count = 0 is below the minimum of 1."""
        with pytest.raises(ValueError, match="gate_signal_count"):
            FractalConfig(gate_signal_count=0)

    def test_gate_signal_count_six(self):
        """gate_signal_count = 6 exceeds the maximum of 5."""
        with pytest.raises(ValueError, match="gate_signal_count"):
            FractalConfig(gate_signal_count=6)

    def test_embedding_dim_zero(self):
        """embedding_dim = 0 is below the minimum of 1."""
        with pytest.raises(ValueError, match="embedding_dim"):
            FractalConfig(embedding_dim=0)

    def test_embedding_dim_5000(self):
        """embedding_dim = 5000 exceeds the maximum of 4096."""
        with pytest.raises(ValueError, match="embedding_dim"):
            FractalConfig(embedding_dim=5000)

    def test_max_text_length_below_minimum(self):
        """max_text_length = 50 is below the minimum of 100."""
        with pytest.raises(ValueError, match="max_text_length"):
            FractalConfig(max_text_length=50)

    def test_merge_similarity_threshold_negative(self):
        """merge_similarity_threshold = -0.1 is below the minimum of 0.1."""
        with pytest.raises(ValueError, match="merge_similarity_threshold"):
            FractalConfig(merge_similarity_threshold=-0.1)

    def test_merge_similarity_threshold_above_max(self):
        """merge_similarity_threshold = 1.5 exceeds the maximum of 1.0."""
        with pytest.raises(ValueError, match="merge_similarity_threshold"):
            FractalConfig(merge_similarity_threshold=1.5)


# ═══════════════════════════════════════════════════════════════════════════
# PART 2 — Pipeline tests (async, need FractalMemory + mocks)
# ═══════════════════════════════════════════════════════════════════════════


class TestGateSignalCountPipeline:
    """Verify gate_signal_count affects store pass/defer behaviour."""

    @pytest.mark.asyncio
    async def test_gate_signal_count_1_stores_immediately(self, tmp_path: Path):
        """With gate_signal_count=1, a single EXPLICIT_STORE signal passes the gate."""
        cfg = FractalConfig(
            db_path=tmp_path / "gate1.db",
            gate_signal_count=1,
        )
        fm = await _make_fm(cfg)
        try:
            await fm.session_start("test")
            mem = await fm.store(
                "gate_signal_count=1 passes immediately",
                domain="test",
                signals=[Signal.EXPLICIT_STORE],
            )
            assert mem is not None, "Memory should pass gate with 1 signal when count=1"
            assert mem.domain == "test"
        finally:
            await _teardown_fm(fm)

    @pytest.mark.asyncio
    async def test_gate_signal_count_2_defers_single_signal(self, tmp_path: Path):
        """With gate_signal_count=2, a single signal goes to waiting room (returns None)."""
        cfg = FractalConfig(
            db_path=tmp_path / "gate2.db",
            gate_signal_count=2,
        )
        fm = await _make_fm(cfg)
        try:
            await fm.session_start("test")
            mem = await fm.store(
                "This needs two signals to pass the gate",
                domain="test",
                signals=[Signal.EXPLICIT_STORE],
            )
            assert mem is None, "Memory should be deferred to waiting room with 1 signal when count=2"
        finally:
            await _teardown_fm(fm)


class TestZoomExtremePipeline:
    """Verify retrieval works with extreme zoom level configurations."""

    @pytest.mark.asyncio
    async def test_zoom_all_ones(self, tmp_path: Path):
        """top_l1=1, top_l2=1, top_l3=1 restricts retrieval to a single memory per level."""
        cfg = FractalConfig(
            db_path=tmp_path / "zoom111.db",
            gate_signal_count=1,
            top_l1=1,
            top_l2=1,
            top_l3=1,
        )
        fm = await _make_fm(cfg)
        try:
            await fm.session_start("test")
            await fm.store("Only memory in the system", domain="test")
            result = await fm.retrieve("memory", domain="test")
            # With only 1 memory, we should get at most 1 at each level
            assert len(result.l3_memories) <= 1
        finally:
            await _teardown_fm(fm)

    @pytest.mark.asyncio
    async def test_zoom_wide_range(self, tmp_path: Path):
        """top_l3=3, top_l2=10, top_l1=50 with several stored memories.

        Note: l3_memories may exceed top_l3 because the working-memory buffer
        prepends recently-written memories (just_written + recent) to L3.
        The key assertion is that retrieval succeeds without error.
        """
        cfg = FractalConfig(
            db_path=tmp_path / "zoom_wide.db",
            gate_signal_count=1,
            top_l1=50,
            top_l2=10,
            top_l3=3,
        )
        fm = await _make_fm(cfg)
        try:
            await fm.session_start("test")
            for i in range(8):
                await fm.store(f"Memory about topic {i} for zoom testing", domain="test")
            result = await fm.retrieve("topic", domain="test")
            # Retrieval engine picks top_l3=3, but buffer merges recently-written
            # memories into L3, so total L3 count can exceed top_l3.
            # At minimum the retrieval engine contributed up to 3 scored memories.
            assert len(result.l3_memories) >= 1
            assert result is not None
        finally:
            await _teardown_fm(fm)


class TestMergeSimilarityPipeline:
    """Verify merge_similarity_threshold extremes do not crash consolidation."""

    @pytest.mark.asyncio
    async def test_merge_threshold_099_no_merges(self, tmp_path: Path):
        """merge_similarity_threshold=0.99 means virtually nothing qualifies for merge."""
        cfg = FractalConfig(
            db_path=tmp_path / "merge_strict.db",
            gate_signal_count=1,
            merge_similarity_threshold=0.99,
        )
        fm = await _make_fm(cfg)
        try:
            await fm.session_start("test")
            await fm.store("Python is great for scripting", domain="test")
            await fm.store("Python is great for automation", domain="test")
            result = await fm.retrieve("Python", domain="test")
            # Both memories should exist independently — no merge at 0.99 threshold
            assert len(result.l3_memories) >= 1
        finally:
            await _teardown_fm(fm)

    @pytest.mark.asyncio
    async def test_merge_threshold_010_all_eligible(self, tmp_path: Path):
        """merge_similarity_threshold=0.10 makes nearly all memories merge-eligible."""
        cfg = FractalConfig(
            db_path=tmp_path / "merge_loose.db",
            gate_signal_count=1,
            merge_similarity_threshold=0.10,
        )
        fm = await _make_fm(cfg)
        try:
            await fm.session_start("test")
            await fm.store("Dogs are loyal companions", domain="test")
            await fm.store("Cats are independent creatures", domain="test")
            # With threshold=0.10, even these dissimilar memories qualify.
            # The important thing is the pipeline does not crash.
            result = await fm.retrieve("pets", domain="test")
            assert result is not None
        finally:
            await _teardown_fm(fm)


class TestFeatureFlagsDisabled:
    """Verify the system survives with all optional Phase 2 features disabled."""

    @pytest.mark.asyncio
    async def test_all_features_disabled_no_crash(self, tmp_path: Path):
        """Disabling spreading activation, scar penalty, and LLM judge must not crash."""
        cfg = FractalConfig(
            db_path=tmp_path / "features_off.db",
            gate_signal_count=1,
            enable_spreading_activation=False,
            enable_scar_penalty=False,
            enable_llm_judge=False,
        )
        fm = await _make_fm(cfg)
        try:
            await fm.session_start("test")
            mem = await fm.store("A simple memory with all features off", domain="test")
            assert mem is not None
            result = await fm.retrieve("simple memory", domain="test")
            assert result is not None
            assert len(result.l3_memories) >= 1

            # Verify disabled features were not invoked during retrieval.
            # When enable_scar_penalty=False, no scar penalty should have been
            # applied — the retrieval engine skips the scar scoring path entirely.
            # We check that no scar-penalty calls were made on the scars subsystem.
            if hasattr(fm._scars, '_storage'):
                conn = fm._storage._ensure_conn()
                async with conn.execute("SELECT COUNT(*) FROM scars") as cur:
                    row = await cur.fetchone()
                    assert row[0] == 0, (
                        f"Expected 0 scars with scar penalty disabled, got {row[0]}"
                    )

            # When enable_spreading_activation=False, no association boost
            # should have been computed. Verify that retrieval scores have no
            # spreading-activation component by checking the memories carry no
            # association-boost metadata.
            for m in result.l3_memories:
                ctx = getattr(m, "context", {}) or {}
                assert "spreading_activation_boost" not in ctx, (
                    "Spreading activation boost found despite feature being disabled"
                )

            summary = await fm.session_end()
            assert summary is not None
        finally:
            # session already ended above, just close
            if fm._session.current_session is not None:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()


class TestEmbeddingDimExtremes:
    """Verify the system works at the lowest valid embedding dimension."""

    @pytest.mark.asyncio
    async def test_embedding_dim_1(self, tmp_path: Path):
        """embedding_dim=1 is the minimum valid dimension — store and retrieve must work."""
        cfg = FractalConfig(
            db_path=tmp_path / "dim1.db",
            gate_signal_count=1,
            embedding_dim=1,
        )
        fm = await _make_fm(cfg, dim=1)
        try:
            await fm.session_start("test")
            mem = await fm.store("Minimal dimension memory", domain="test")
            assert mem is not None
            assert len(mem.embedding) == 1
            result = await fm.retrieve("minimal", domain="test")
            assert result is not None
        finally:
            await _teardown_fm(fm)


class TestConfigPropagation:
    """Verify FractalMemory propagates config to all subsystems."""

    @pytest.mark.asyncio
    async def test_config_reaches_all_subsystems(self, tmp_path: Path):
        """After construction every subsystem's _config must be the same object."""
        cfg = FractalConfig(
            db_path=tmp_path / "propagation.db",
            gate_signal_count=1,
        )
        fm = await _make_fm(cfg)
        try:
            # These are the subsystem attribute names set during __init__
            subsystem_attrs = [
                "_storage",
                "_retrieval",
                "_gate",
                "_lifecycle",
                "_session",
                "_consolidation",
                "_associations",
                "_morphogens",
                "_self_model",
                "_domain_manager",
                "_bandits",
                "_dreaming",
                "_maintenance",
                "_apoptosis",
                "_scars",
                "_niche",
                "_buffer",
                "_folding",
                "_cascade",
                "_danger_theory",
                "_store_signal_detector",
                "_judge",
                "_states",
            ]
            for attr_name in subsystem_attrs:
                subsystem = getattr(fm, attr_name, None)
                assert subsystem is not None, f"Subsystem {attr_name} not found on FractalMemory"
                sub_cfg = getattr(subsystem, "_config", None)
                assert sub_cfg is not None, f"Subsystem {attr_name} has no _config attribute"
                assert sub_cfg is fm._config, (
                    f"Subsystem {attr_name}._config is not the same object as FractalMemory._config"
                )

            # Now test _propagate_config replaces config on all subsystems
            import dataclasses
            new_cfg = dataclasses.replace(cfg, gate_signal_count=3)
            fm._propagate_config(new_cfg)
            assert fm._config is new_cfg
            for attr_name in subsystem_attrs:
                subsystem = getattr(fm, attr_name)
                assert subsystem._config is new_cfg, (
                    f"After _propagate_config, {attr_name}._config was not updated"
                )
        finally:
            await _teardown_fm(fm)
