"""Stress tests for graceful degradation under storage/LLM failures.

Chaos monkey tests that inject failures into storage (SQLite) and LLM
subsystems to verify the system degrades gracefully: no partial writes,
no corrupt state, no unhandled crashes. PRAGMA integrity_check must pass
after every chaos scenario.
"""

from __future__ import annotations

import asyncio
import json
import random
import sqlite3
from datetime import datetime
from pathlib import Path
from unittest.mock import AsyncMock, patch
from uuid import UUID, uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.storage import Storage
from fractal_memory.llm import LLMProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive, unit-norm embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm():
    """Create a mock LLM provider that returns valid zoom JSON."""
    provider = AsyncMock(spec=LLMProvider)

    async def _complete(
        prompt: str, system: str | None = None, max_tokens: int = 500
    ) -> str:
        if "summarize" in prompt.lower():
            return "Chaos test session summary."
        return json.dumps({
            "l0_tag": "chaos:test",
            "l1_label": "chaos-test",
            "l2_summary": "Chaos memory.",
            "l3_full": "Full chaos memory.",
        })

    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings(dim: int = 384):
    """Create a mock embedding provider with deterministic output."""
    provider = AsyncMock()

    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text, dim)

    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t, dim) for t in texts]

    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = dim
    return provider


def _make_memory(i: int, domain: str = "chaos") -> Memory:
    """Create a test memory with deterministic embedding."""
    now = datetime.now(tz=None)
    return Memory(
        id=uuid4(),
        domain=domain,
        created_at=now,
        updated_at=now,
        context={},
        l0_tag="c:t",
        l1_label="label",
        l2_summary=f"Chaos mem {i}",
        l3_full=f"Chaos memory {i} full",
        l4_raw=f"raw chaos {i}",
        embedding=_deterministic_embed(f"chaos-{i}"),
        embedding_model="mock",
    )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def chaos_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "chaos_monkey.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
    )


@pytest.fixture
async def chaos_fm(chaos_config: FractalConfig):
    """FractalMemory instance with mock LLM + embeddings for chaos tests."""
    fm = FractalMemory(
        chaos_config,
        llm=_make_mock_llm(),
        embeddings=_make_mock_embeddings(),
    )
    await fm.initialize()
    yield fm
    if fm._session.current_session is not None:
        try:
            await fm.session_end()
        except Exception:
            pass
    await fm.close()


@pytest.fixture
async def chaos_storage(chaos_config: FractalConfig):
    """Bare Storage instance for direct DB chaos tests."""
    s = Storage(chaos_config)
    await s.initialize()
    yield s
    await s.close()


async def _integrity_check(storage: Storage) -> bool:
    """Run PRAGMA integrity_check and return True if OK."""
    conn = storage._ensure_conn()
    async with conn.execute("PRAGMA integrity_check") as cur:
        row = await cur.fetchone()
    return row[0] == "ok"


# ===========================================================================
# Storage failure tests
# ===========================================================================


class TestStorageFailures:
    """Tests for graceful degradation under SQLite storage failures."""

    @pytest.mark.asyncio
    async def test_commit_failure_after_store_raises_cleanly(
        self, chaos_fm: FractalMemory
    ):
        """Patch conn.commit to raise once during store() -- error propagates cleanly.

        In SQLite WAL mode, the INSERT may be visible to the same connection
        even before commit(). This test verifies that:
        1. The commit failure raises an exception to the caller (not swallowed).
        2. The database remains in a consistent, non-corrupt state afterward.
        3. Subsequent operations still work.
        """
        await chaos_fm.session_start("chaos")

        # Store one memory successfully first to verify the pipeline works
        mem_ok = await chaos_fm.store("Baseline memory before chaos")
        assert mem_ok is not None

        storage = chaos_fm._storage
        conn = storage._ensure_conn()
        original_commit = conn.commit

        commit_call_count = 0

        async def _failing_commit():
            nonlocal commit_call_count
            commit_call_count += 1
            # Fail on the first commit call during the next store
            if commit_call_count == 1:
                raise sqlite3.OperationalError("disk I/O error")
            return await original_commit()

        with patch.object(conn, "commit", side_effect=_failing_commit):
            with pytest.raises(Exception):
                await chaos_fm.store("This memory may or may not persist")

        # Verify no partial write
        count = await chaos_fm._storage.count_memories()
        assert count <= 1, f"Partial write detected: {count} memories in DB (expected at most 1 from baseline)"

        # The important thing: the error was raised (not swallowed), and the
        # database is in a consistent state for future operations.
        # Verify a subsequent store still works:
        mem_after = await chaos_fm.store("Memory after commit failure recovery")
        assert mem_after is not None

        # Integrity check -- DB must not be corrupted
        assert await _integrity_check(storage)

    @pytest.mark.asyncio
    async def test_intermittent_database_locked(
        self, chaos_fm: FractalMemory
    ):
        """Patch commit to fail intermittently with 'database is locked'.

        Some stores should fail, others should succeed. DB must remain consistent.
        Uses commit patching since store_memory calls commit once per store,
        giving predictable failure frequency.
        """
        await chaos_fm.session_start("chaos")

        storage = chaos_fm._storage
        conn = storage._ensure_conn()
        original_commit = conn.commit
        call_count = 0

        async def _locked_commit():
            nonlocal call_count
            call_count += 1
            if call_count % 3 == 0:
                raise sqlite3.OperationalError("database is locked")
            return await original_commit()

        succeeded = 0
        failed = 0

        with patch.object(conn, "commit", side_effect=_locked_commit):
            for i in range(15):
                try:
                    mem = await chaos_fm.store(f"Intermittent locked test {i}")
                    if mem is not None:
                        succeeded += 1
                except Exception:
                    failed += 1

        # At least some should succeed, some should fail
        assert succeeded > 0, "Expected at least some successful stores"
        assert failed > 0, "Expected at least some failures from locked DB"

        # DB integrity must hold
        assert await _integrity_check(storage)

    @pytest.mark.asyncio
    async def test_connection_lost_during_session_end(
        self, chaos_config: FractalConfig
    ):
        """Patch conn.commit to raise during session_end -- no crash.

        session_end involves multiple writes (session update, session_summary).
        Even if commit fails partway through, the method should not crash
        with an unhandled exception that escapes the top-level API.
        """
        fm = FractalMemory(
            chaos_config,
            llm=_make_mock_llm(),
            embeddings=_make_mock_embeddings(),
        )
        await fm.initialize()

        try:
            await fm.session_start("chaos")
            await fm.store("Memory before session_end chaos")

            storage = fm._storage
            conn = storage._ensure_conn()
            original_commit = conn.commit
            fail_count = 0

            async def _partial_fail_commit():
                nonlocal fail_count
                fail_count += 1
                # Let the first few commits through (session update),
                # then fail on later ones (session_summary)
                if fail_count >= 3:
                    raise sqlite3.OperationalError("connection lost")
                return await original_commit()

            # session_end may raise from internal hooks, but should not crash
            # with an unhandled exception that corrupts state
            with patch.object(conn, "commit", side_effect=_partial_fail_commit):
                try:
                    await fm.session_end()
                except Exception:
                    # session_end is allowed to raise, but it must not leave
                    # the process in a corrupted state
                    pass

            # The DB file should still be accessible and pass integrity check
            assert await _integrity_check(storage)
        finally:
            await fm.close()

    @pytest.mark.asyncio
    async def test_cascade_delete_partial_failure_rollback(
        self, chaos_storage: Storage
    ):
        """Inject error mid-SAVEPOINT -- rollback works, original memory still exists.

        delete_memory uses SAVEPOINT for atomicity. If an error occurs after
        clearing chain refs but before DELETE FROM memories completes, ROLLBACK
        should restore the original state.

        We use a wrapper around the connection's internal _execute method
        which is what aiosqlite uses under the hood, preserving the async
        context manager protocol.
        """
        # Store a memory directly
        mem = _make_memory(0)
        await chaos_storage.store_memory(mem)

        conn = chaos_storage._ensure_conn()
        original_execute_method = conn._execute

        async def _fail_mid_delete(fn, sql, parameters):
            # The internal _execute receives (sqlite3_method, sql, parameters)
            if isinstance(sql, str) and "DELETE FROM memories" in sql:
                raise sqlite3.OperationalError("I/O error mid-delete")
            return await original_execute_method(fn, sql, parameters)

        with patch.object(conn, "_execute", side_effect=_fail_mid_delete):
            with pytest.raises(sqlite3.OperationalError, match="I/O error"):
                await chaos_storage.delete_memory(mem.id)

        # Memory should still exist after rollback
        fetched = await chaos_storage.get_memory(mem.id)
        assert fetched is not None, "Memory should survive failed delete (SAVEPOINT rollback)"
        assert fetched.id == mem.id

        # Integrity check
        assert await _integrity_check(chaos_storage)

    @pytest.mark.asyncio
    async def test_pragma_integrity_after_chaos(
        self, chaos_fm: FractalMemory
    ):
        """After a mixed bag of storage errors, PRAGMA integrity_check passes.

        This test runs multiple stores with random failure injection and then
        verifies the database is not corrupted.
        """
        await chaos_fm.session_start("chaos")

        storage = chaos_fm._storage
        conn = storage._ensure_conn()
        original_execute = conn._execute
        rng = random.Random(42)

        async def _random_fail_execute(fn, sql, parameters):
            if rng.random() < 0.15:  # 15% failure rate
                raise sqlite3.OperationalError("random chaos failure")
            return await original_execute(fn, sql, parameters)

        with patch.object(conn, "_execute", side_effect=_random_fail_execute):
            for i in range(20):
                try:
                    await chaos_fm.store(f"Chaos integrity test {i}")
                except Exception:
                    pass

        # The acid test: integrity_check must pass
        assert await _integrity_check(storage), "DB corrupted after random storage failures"


# ===========================================================================
# LLM failure tests
# ===========================================================================


class TestLLMFailures:
    """Tests for graceful degradation under LLM provider failures."""

    @pytest.mark.asyncio
    async def test_llm_timeout_during_store(self, chaos_config: FractalConfig):
        """Mock LLM raises TimeoutError -- store returns None or raises, no partial writes."""
        mock_llm = _make_mock_llm()

        async def _timeout_complete(*args, **kwargs):
            raise asyncio.TimeoutError("LLM timeout")

        mock_llm.complete = AsyncMock(side_effect=_timeout_complete)

        fm = FractalMemory(
            chaos_config,
            llm=mock_llm,
            embeddings=_make_mock_embeddings(),
        )
        await fm.initialize()

        try:
            await fm.session_start("chaos")

            # store() calls ZoomGenerator which calls LLM. If LLM times out,
            # ZoomGenerator catches LLMUnavailableError but TimeoutError may
            # propagate. Either way, no partial memory should be written.
            result = None
            raised = False
            try:
                result = await fm.store("Timeout test memory")
            except Exception:
                raised = True

            # Either it returned None (gated/fallback) or raised -- but no partial write
            storage = fm._storage
            count = await storage.count_memories()
            if result is None or raised:
                assert count == 0, "No memory should be persisted when LLM times out"

            assert await _integrity_check(storage)
        finally:
            if fm._session.current_session is not None:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()

    @pytest.mark.asyncio
    async def test_llm_returns_invalid_json(self, chaos_config: FractalConfig):
        """Mock LLM returns 'not json' -- store handles gracefully via fallback zoom."""
        mock_llm = _make_mock_llm()

        async def _invalid_json(*args, **kwargs):
            return "This is not valid JSON at all"

        mock_llm.complete = AsyncMock(side_effect=_invalid_json)

        fm = FractalMemory(
            chaos_config,
            llm=mock_llm,
            embeddings=_make_mock_embeddings(),
        )
        await fm.initialize()

        try:
            await fm.session_start("chaos")
            # ZoomGenerator._parse_zoom_response falls back to _generate_fallback
            # when JSON parsing fails, so store should still succeed
            mem = await fm.store("Invalid JSON LLM test memory")

            # Should succeed via fallback zoom generation
            assert mem is not None, "Store should succeed with fallback zoom when LLM returns bad JSON"
            assert mem.l0_tag  # Should have some tag from fallback
            assert mem.l4_raw == "Invalid JSON LLM test memory"

            assert await _integrity_check(fm._storage)
        finally:
            if fm._session.current_session is not None:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()

    @pytest.mark.asyncio
    async def test_llm_returns_empty_string(self, chaos_config: FractalConfig):
        """Mock LLM returns '' -- store handles gracefully."""
        mock_llm = _make_mock_llm()

        async def _empty_response(*args, **kwargs):
            return ""

        mock_llm.complete = AsyncMock(side_effect=_empty_response)

        fm = FractalMemory(
            chaos_config,
            llm=mock_llm,
            embeddings=_make_mock_embeddings(),
        )
        await fm.initialize()

        try:
            await fm.session_start("chaos")
            # Empty string will fail JSON parse -> fallback zoom
            mem = await fm.store("Empty LLM response test memory")
            assert mem is not None, "Store should succeed with fallback zoom on empty LLM response"

            assert await _integrity_check(fm._storage)
        finally:
            if fm._session.current_session is not None:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()

    @pytest.mark.asyncio
    async def test_llm_runtime_error_during_store(
        self, chaos_config: FractalConfig
    ):
        """Mock LLM raises RuntimeError -- store returns None or raises cleanly."""
        mock_llm = _make_mock_llm()

        async def _runtime_error(*args, **kwargs):
            raise RuntimeError("LLM internal failure")

        mock_llm.complete = AsyncMock(side_effect=_runtime_error)

        fm = FractalMemory(
            chaos_config,
            llm=mock_llm,
            embeddings=_make_mock_embeddings(),
        )
        await fm.initialize()

        try:
            await fm.session_start("chaos")

            result = None
            raised = False
            try:
                result = await fm.store("RuntimeError LLM test")
            except Exception:
                raised = True

            # No partial writes
            storage = fm._storage
            count = await storage.count_memories()
            if result is None or raised:
                assert count == 0, "No memory should persist when LLM raises RuntimeError"

            assert await _integrity_check(storage)
        finally:
            if fm._session.current_session is not None:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()

    @pytest.mark.asyncio
    async def test_llm_intermittent_50_percent_failure(
        self, chaos_config: FractalConfig
    ):
        """20 store attempts with 50% LLM failure -- some succeed, some fail, DB consistent."""
        mock_llm = _make_mock_llm()
        call_count = 0

        async def _intermittent(
            prompt: str, system: str | None = None, max_tokens: int = 500
        ) -> str:
            nonlocal call_count
            call_count += 1
            if call_count % 2 == 0:
                raise ConnectionError("LLM unavailable")
            if "summarize" in prompt.lower():
                return "Intermittent session summary."
            return json.dumps({
                "l0_tag": "ok:tag",
                "l1_label": "ok-label",
                "l2_summary": "Ok summary.",
                "l3_full": "Ok full text.",
            })

        mock_llm.complete = AsyncMock(side_effect=_intermittent)

        fm = FractalMemory(
            chaos_config,
            llm=mock_llm,
            embeddings=_make_mock_embeddings(),
        )
        await fm.initialize()

        try:
            await fm.session_start("chaos")

            succeeded = 0
            failed = 0
            for i in range(20):
                try:
                    mem = await fm.store(f"Intermittent LLM test {i}")
                    if mem is not None:
                        succeeded += 1
                    else:
                        failed += 1
                except Exception:
                    failed += 1

            # Some should succeed (the LLM works on odd calls)
            assert succeeded > 0, "Expected some stores to succeed with 50% LLM failure"
            # Some should fail
            assert failed > 0, "Expected some stores to fail with 50% LLM failure"

            # Memory count should match succeeded count
            storage = fm._storage
            count = await storage.count_memories()
            assert count == succeeded, f"DB memory count {count} != succeeded {succeeded}"

            assert await _integrity_check(storage)
        finally:
            if fm._session.current_session is not None:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()


# ===========================================================================
# Combined chaos tests
# ===========================================================================


class TestCombinedChaos:
    """Tests combining storage and LLM failures simultaneously."""

    @pytest.mark.asyncio
    async def test_random_30_percent_storage_failure_injection(
        self, chaos_fm: FractalMemory
    ):
        """Patch _execute with 30% failure rate during full session.

        After the chaos, PRAGMA integrity_check must pass.
        Uses _execute (aiosqlite internal) to preserve the async context manager.
        """
        await chaos_fm.session_start("chaos")

        storage = chaos_fm._storage
        conn = storage._ensure_conn()
        original_execute = conn._execute
        rng = random.Random(123)

        async def _30pct_fail_execute(fn, sql, parameters):
            if rng.random() < 0.30:
                raise sqlite3.OperationalError("random 30% failure")
            return await original_execute(fn, sql, parameters)

        with patch.object(conn, "_execute", side_effect=_30pct_fail_execute):
            for i in range(15):
                try:
                    await chaos_fm.store(f"30pct chaos {i}")
                except Exception:
                    pass

            try:
                result = await chaos_fm.retrieve("chaos query")
            except Exception:
                pass

        # After removing the patch, run integrity check
        assert await _integrity_check(storage), "DB corrupted after 30% random storage failures"

    @pytest.mark.asyncio
    async def test_llm_fails_but_storage_ok(self, chaos_config: FractalConfig):
        """Store with LLM that always fails -- verify no memories created.

        If the LLM always fails and no fallback applies, the store should either
        return None or raise, and zero memories should be in the DB.
        """
        mock_llm = _make_mock_llm()

        async def _always_fail(*args, **kwargs):
            raise ConnectionError("LLM permanently down")

        mock_llm.complete = AsyncMock(side_effect=_always_fail)

        fm = FractalMemory(
            chaos_config,
            llm=mock_llm,
            embeddings=_make_mock_embeddings(),
        )
        await fm.initialize()

        try:
            await fm.session_start("chaos")

            results = []
            errors = 0
            for i in range(5):
                try:
                    mem = await fm.store(f"LLM-dead test {i}")
                    results.append(mem)
                except Exception:
                    errors += 1

            # If the zoom generator's fallback is not triggered by generic
            # ConnectionError (only LLMUnavailableError), all should fail
            storage = fm._storage
            count = await storage.count_memories()

            # The store either returned None for all (fallback zoom succeeded
            # but gate rejected) or raised. Either way, any memory that was
            # returned should be retrievable.
            stored_count = sum(1 for r in results if r is not None)
            assert count == stored_count, (
                f"DB has {count} memories but {stored_count} non-None results"
            )

            assert await _integrity_check(storage)
        finally:
            if fm._session.current_session is not None:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()

    @pytest.mark.asyncio
    async def test_storage_ok_but_embeddings_fail(
        self, chaos_config: FractalConfig
    ):
        """Patch embed to raise -- store fails cleanly, no partial writes."""
        mock_embeddings = _make_mock_embeddings()

        async def _embed_fail(text: str) -> list[float]:
            raise RuntimeError("Embedding model crashed")

        mock_embeddings.embed = AsyncMock(side_effect=_embed_fail)

        fm = FractalMemory(
            chaos_config,
            llm=_make_mock_llm(),
            embeddings=mock_embeddings,
        )
        await fm.initialize()

        try:
            await fm.session_start("chaos")

            raised = False
            result = None
            try:
                result = await fm.store("Embedding failure test")
            except Exception:
                raised = True

            # Either raised or returned None -- no partial write
            storage = fm._storage
            count = await storage.count_memories()
            assert count == 0, (
                "No memory should be persisted when embeddings fail"
            )
            assert raised or result is None

            assert await _integrity_check(storage)
        finally:
            if fm._session.current_session is not None:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()

    @pytest.mark.asyncio
    async def test_rapid_error_recovery(self, chaos_config: FractalConfig):
        """Alternate between working and broken LLM -- successful stores are retrievable."""
        mock_llm = _make_mock_llm()
        is_broken = False

        async def _alternating_llm(
            prompt: str, system: str | None = None, max_tokens: int = 500
        ) -> str:
            if is_broken:
                raise ConnectionError("LLM temporarily down")
            if "summarize" in prompt.lower():
                return "Recovery test session summary."
            return json.dumps({
                "l0_tag": "recov:test",
                "l1_label": "recovery-test",
                "l2_summary": "Recovery memory.",
                "l3_full": "Full recovery memory.",
            })

        mock_llm.complete = AsyncMock(side_effect=_alternating_llm)

        fm = FractalMemory(
            chaos_config,
            llm=mock_llm,
            embeddings=_make_mock_embeddings(),
        )
        await fm.initialize()

        try:
            await fm.session_start("chaos")

            stored_ids: list[UUID] = []

            for i in range(10):
                is_broken = (i % 2 == 1)  # Broken on odd iterations
                try:
                    mem = await fm.store(f"Recovery test {i}")
                    if mem is not None:
                        stored_ids.append(mem.id)
                except Exception:
                    pass

            # Should have some successful stores (even iterations)
            assert len(stored_ids) > 0, "Expected some successful stores"

            # Verify successful stores are retrievable
            is_broken = False  # LLM working for retrieval
            for mid in stored_ids:
                fetched = await fm.get(mid)
                assert fetched is not None, f"Successfully stored memory {mid} should be retrievable"

            assert await _integrity_check(fm._storage)
        finally:
            if fm._session.current_session is not None:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()

    @pytest.mark.asyncio
    async def test_full_session_with_intermittent_everything(
        self, chaos_config: FractalConfig
    ):
        """Full session lifecycle with intermittent LLM + occasional storage hiccups.

        session_end must not crash, and integrity_check must pass.
        """
        mock_llm = _make_mock_llm()
        llm_call_count = 0

        async def _flaky_llm(
            prompt: str, system: str | None = None, max_tokens: int = 500
        ) -> str:
            nonlocal llm_call_count
            llm_call_count += 1
            # Fail every 3rd LLM call
            if llm_call_count % 3 == 0:
                raise ConnectionError("Intermittent LLM failure")
            if "summarize" in prompt.lower():
                return "Flaky session summary."
            return json.dumps({
                "l0_tag": "flaky:test",
                "l1_label": "flaky-test",
                "l2_summary": "Flaky memory.",
                "l3_full": "Full flaky memory.",
            })

        mock_llm.complete = AsyncMock(side_effect=_flaky_llm)

        fm = FractalMemory(
            chaos_config,
            llm=mock_llm,
            embeddings=_make_mock_embeddings(),
        )
        await fm.initialize()

        try:
            await fm.session_start("chaos")

            storage = fm._storage
            conn = storage._ensure_conn()
            original_execute = conn._execute
            storage_fail_count = 0

            async def _occasional_storage_fail(fn, sql, parameters):
                nonlocal storage_fail_count
                storage_fail_count += 1
                # Fail every 11th storage call (sparse failures)
                if storage_fail_count % 11 == 0:
                    raise sqlite3.OperationalError("occasional storage hiccup")
                return await original_execute(fn, sql, parameters)

            succeeded = 0
            failed = 0

            # Phase 1: Store with intermittent failures
            with patch.object(
                conn, "_execute", side_effect=_occasional_storage_fail
            ):
                for i in range(12):
                    try:
                        mem = await fm.store(f"Intermittent everything {i}")
                        if mem is not None:
                            succeeded += 1
                    except Exception:
                        failed += 1

            # Phase 2: Retrieve (should work since we removed the patch)
            try:
                result = await fm.retrieve("intermittent test query")
                # result should be a valid RetrievalResult even if empty
                assert result is not None
            except Exception:
                pass  # Retrieval failure is acceptable in this chaos scenario

            # Phase 3: session_end must not crash
            session_end_crashed = False
            try:
                await fm.session_end()
            except Exception:
                session_end_crashed = True
                # Even if it raises, the process should be alive

            # Final verification: DB integrity
            assert await _integrity_check(storage), (
                "DB corrupted after full session with intermittent failures"
            )

            # At least some operations should have succeeded
            assert succeeded > 0 or failed > 0, (
                "Expected at least some store attempts to execute"
            )
        finally:
            # Ensure cleanup even if test assertions fail
            if fm._session.current_session is not None:
                try:
                    await fm.session_end()
                except Exception:
                    pass
            await fm.close()
