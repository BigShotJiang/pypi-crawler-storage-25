"""Stress tests for overlapping destructive operations on shared memory sets.

Targets race conditions between apoptosis, consolidation, and raw storage
operations when multiple async tasks contend for the same memory IDs,
association edges, and scar records.

NOTE: aiosqlite uses a single connection per Storage instance.  The
``delete_memory`` method uses SAVEPOINTs which cannot be interleaved on a
shared connection.  Tests that mix ``delete_memory`` with other write
operations therefore use an ``asyncio.Semaphore`` to serialise SAVEPOINT
regions while still exercising async scheduling pressure between stores
and deletes.  Tests that do *not* involve SAVEPOINTs (e.g. association
update/delete, scar creation) can run fully concurrently.
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock
from uuid import uuid4, UUID

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.storage import Storage
from fractal_memory.llm import LLMProvider
from fractal_memory.associations import AssociationNetwork
from fractal_memory.scar import ScarTissueManager
from fractal_memory.lifecycle import LifecycleManager
from fractal_memory.domains import DomainManager
from fractal_memory.zoom import ZoomGenerator
from fractal_memory.apoptosis import ApoptosisManager, ApoptosisDecision


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

DIM = 384
DOMAIN = "race"


def _deterministic_embed(text: str, dim: int = DIM) -> list[float]:
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm() -> AsyncMock:
    provider = AsyncMock(spec=LLMProvider)

    async def _complete(
        prompt: str, system: str | None = None, max_tokens: int = 500
    ) -> str:
        if "summarize" in prompt.lower():
            return "Race test session summary."
        # For merge, return valid merge JSON
        return json.dumps({
            "l0_tag": "merged:tag",
            "l1_label": "merged-label",
            "l2_summary": "Merged summary.",
            "l3_full": "Merged full context that is definitely long enough to pass validation.",
            "contrast": None,
        })

    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings(dim: int = DIM) -> AsyncMock:
    provider = AsyncMock()

    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text, dim)

    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t, dim) for t in texts]

    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = dim
    return provider


def _make_memory(
    i: int,
    domain: str = DOMAIN,
    dim: int = DIM,
    base_text: str = "near-duplicate",
) -> Memory:
    """Create a memory. Use same base_text for near-duplicates."""
    now = datetime.now(timezone.utc)
    text = f"{base_text} variant {i}"
    return Memory(
        id=uuid4(),
        domain=domain,
        created_at=now,
        updated_at=now,
        context={},
        l0_tag="r:t",
        l1_label="race-label",
        l2_summary=f"Near dup {i}",
        l3_full=f"Near duplicate memory {i} for race testing",
        l4_raw=text,
        embedding=_deterministic_embed(text, dim),
        embedding_model="mock",
    )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def race_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "race_test.db",
        gate_signal_count=1,
        merge_similarity_threshold=0.3,  # low threshold to force merge candidates
    )


@pytest.fixture
async def race_storage(race_config: FractalConfig) -> Storage:
    s = Storage(race_config)
    await s.initialize()
    yield s
    await s.close()


async def _seed_memories(
    storage: Storage, n: int = 50, domain: str = DOMAIN
) -> list[Memory]:
    """Store n near-duplicate memories and wire associations between consecutive pairs."""
    mems: list[Memory] = []
    for i in range(n):
        m = _make_memory(i, domain=domain)
        await storage.store_memory(m)
        mems.append(m)
    # Create chain of associations: 0-1, 1-2, ..., (n-2)-(n-1)
    for i in range(n - 1):
        await storage.store_association(
            source_id=mems[i].id,
            target_id=mems[i + 1].id,
            weight=0.5,
        )
    return mems


async def _integrity_check(storage: Storage) -> bool:
    """Run PRAGMA integrity_check and return True if OK."""
    conn = storage._ensure_conn()
    async with conn.execute("PRAGMA integrity_check") as cur:
        row = await cur.fetchone()
    return row[0] == "ok"


# ---------------------------------------------------------------------------
# Test 1: Double-delete on the same memory (sequential, tests idempotency)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_double_delete_same_memory(race_storage: Storage) -> None:
    """Two sequential delete_memory calls on the same ID: first returns True,
    second returns False. No crash."""
    mem = _make_memory(0)
    await race_storage.store_memory(mem)

    first = await race_storage.delete_memory(mem.id)
    second = await race_storage.delete_memory(mem.id)

    assert first is True
    assert second is False
    # The memory must be gone
    assert await race_storage.get_memory(mem.id) is None


# ---------------------------------------------------------------------------
# Test 2: Concurrent delete of many distinct memories — count consistent
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_concurrent_delete_many(race_storage: Storage) -> None:
    """Delete 10 distinct memories using a semaphore to serialise SAVEPOINT
    regions while preserving async scheduling between tasks.
    After all deletes finish, count must be exactly N - deleted."""
    mems = await _seed_memories(race_storage, 50)
    to_delete = mems[:10]
    initial_count = await race_storage.count_memories(DOMAIN)
    assert initial_count == 50

    sem = asyncio.Semaphore(1)

    async def guarded_delete(m: Memory) -> bool:
        async with sem:
            return await race_storage.delete_memory(m.id)

    results = await asyncio.gather(
        *[guarded_delete(m) for m in to_delete],
        return_exceptions=True,
    )

    # No exceptions expected
    exceptions = [r for r in results if isinstance(r, Exception)]
    assert len(exceptions) == 0, f"Unexpected exceptions: {exceptions}"

    # All should have returned True (each targets a unique ID)
    assert all(r is True for r in results)

    remaining = await race_storage.count_memories(DOMAIN)
    assert remaining == 40


# ---------------------------------------------------------------------------
# Test 3: Orphaned edge invariant after concurrent deletes
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_no_orphaned_edges_after_concurrent_deletes(
    race_storage: Storage,
) -> None:
    """Delete 10 memories via serialised SAVEPOINTs, then verify no association
    edges reference any of the deleted memory IDs."""
    mems = await _seed_memories(race_storage, 50)
    to_delete = mems[:10]
    deleted_ids = {m.id for m in to_delete}

    sem = asyncio.Semaphore(1)

    async def guarded_delete(m: Memory) -> bool:
        async with sem:
            return await race_storage.delete_memory(m.id)

    await asyncio.gather(
        *[guarded_delete(m) for m in to_delete],
        return_exceptions=True,
    )

    # Collect all remaining association edges
    all_edges = await race_storage.get_all_associations()
    for src, tgt, _w in all_edges:
        assert src not in deleted_ids, f"Orphaned source edge referencing deleted memory {src}"
        assert tgt not in deleted_ids, f"Orphaned target edge referencing deleted memory {tgt}"


# ---------------------------------------------------------------------------
# Test 4: Scar creation during concurrent operations
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_concurrent_scar_creation(
    race_storage: Storage, race_config: FractalConfig,
) -> None:
    """Create scars for multiple memories concurrently.
    No duplicate scar IDs and all scars are persisted."""
    embeddings = _make_mock_embeddings()
    scars_mgr = ScarTissueManager(race_storage, embeddings, race_config)

    # Create 15 scars concurrently, each with a distinct embedding
    tasks = []
    for i in range(15):
        emb = _deterministic_embed(f"unique scar pattern {i}")
        tasks.append(
            scars_mgr.create_scar(
                reason=f"test_scar_{i}",
                subtype="correction",
                query_embedding=emb,
                memory_ids=[uuid4()],
            )
        )

    results = await asyncio.gather(*tasks, return_exceptions=True)

    errors = [r for r in results if isinstance(r, Exception)]
    assert len(errors) == 0, f"Scar creation errors: {errors}"

    created_scars = [r for r in results if not isinstance(r, Exception)]
    scar_ids = [s.id for s in created_scars]
    # IDs must be unique
    assert len(scar_ids) == len(set(scar_ids)), "Duplicate scar IDs detected"

    # Verify all are in storage
    active = await race_storage.get_active_scars()
    stored_ids = {s[0] for s in active}
    for sid in scar_ids:
        assert sid in stored_ids, f"Scar {sid} not found in storage after concurrent creation"


# ---------------------------------------------------------------------------
# Test 5: Fragment store interleaved with source memory deletes
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_fragment_store_during_concurrent_deletes(
    race_storage: Storage,
) -> None:
    """Store new fragment memories while deleting their source memories.
    Uses a semaphore to serialise SAVEPOINT-using deletes with other writes.
    PRAGMA integrity_check must pass."""
    mems = await _seed_memories(race_storage, 20)
    sem = asyncio.Semaphore(1)

    async def store_fragment(idx: int) -> None:
        frag = _make_memory(100 + idx, base_text="fragment")
        async with sem:
            await race_storage.store_memory(frag)

    async def delete_source(mem: Memory) -> bool:
        async with sem:
            return await race_storage.delete_memory(mem.id)

    # Interleave stores and deletes
    tasks = []
    for i in range(10):
        tasks.append(store_fragment(i))
        tasks.append(delete_source(mems[i]))

    results = await asyncio.gather(*tasks, return_exceptions=True)
    errors = [r for r in results if isinstance(r, Exception)]
    assert len(errors) == 0, f"Errors during interleaved ops: {errors}"

    # All deletes should have succeeded (unique IDs)
    delete_results = [r for r in results if isinstance(r, bool)]
    assert all(r is True for r in delete_results)

    # All fragments should exist
    remaining = await race_storage.count_memories(DOMAIN)
    # 20 original - 10 deleted + 10 fragments = 20
    assert remaining == 20

    # Integrity check
    assert await _integrity_check(race_storage)


# ---------------------------------------------------------------------------
# Test 6: Concurrent association modifications on overlapping edges
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_concurrent_association_modifications(
    race_storage: Storage,
) -> None:
    """Concurrently update and delete associations on overlapping edges.
    No crash, integrity check passes."""
    mems = await _seed_memories(race_storage, 20)

    async def update_weight(i: int) -> None:
        """Strengthen the edge between mems[i] and mems[i+1]."""
        await race_storage.update_association_weight(
            mems[i].id, mems[i + 1].id, 0.9
        )

    async def delete_edge(i: int) -> None:
        """Delete the edge between mems[i] and mems[i+1]."""
        await race_storage.delete_association(mems[i].id, mems[i + 1].id)

    # Mix updates and deletes on overlapping pairs
    tasks = []
    for i in range(0, 18, 2):
        tasks.append(update_weight(i))
        tasks.append(delete_edge(i))      # same edge: update vs delete race
        tasks.append(update_weight(i + 1))

    results = await asyncio.gather(*tasks, return_exceptions=True)
    errors = [r for r in results if isinstance(r, Exception)]
    assert len(errors) == 0, f"Concurrent association ops errors: {errors}"

    assert await _integrity_check(race_storage)


# ---------------------------------------------------------------------------
# Test 7: Conservation law — memories remaining + deleted == N
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_conservation_law(race_storage: Storage) -> None:
    """Start with N memories. Delete a subset via serialised SAVEPOINTs.
    memories_remaining + len(delete_successes) must equal N."""
    N = 30
    mems = await _seed_memories(race_storage, N)
    sem = asyncio.Semaphore(1)

    # Delete every other memory (15 total)
    to_delete = mems[::2]

    async def guarded_delete(m: Memory) -> bool:
        async with sem:
            return await race_storage.delete_memory(m.id)

    results = await asyncio.gather(
        *[guarded_delete(m) for m in to_delete],
        return_exceptions=True,
    )

    deleted_count = sum(1 for r in results if r is True)
    remaining = await race_storage.count_memories(DOMAIN)

    assert remaining + deleted_count == N, (
        f"Conservation violated: {remaining} remaining + {deleted_count} deleted != {N}"
    )

    # Verify no dangling chain references
    conn = race_storage._ensure_conn()
    async with conn.execute(
        "SELECT id, chain_next, chain_prev FROM memories WHERE chain_next IS NOT NULL OR chain_prev IS NOT NULL"
    ) as cur:
        async for row in cur:
            if row["chain_next"]:
                ref = await race_storage.get_memory(UUID(row["chain_next"]))
                assert ref is not None, f"Dangling chain_next: {row['id']} -> {row['chain_next']}"
            if row["chain_prev"]:
                ref = await race_storage.get_memory(UUID(row["chain_prev"]))
                assert ref is not None, f"Dangling chain_prev: {row['id']} -> {row['chain_prev']}"


# ---------------------------------------------------------------------------
# Test 8: Stale reference handling — get_associations for deleted memory
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_stale_reference_after_delete(race_storage: Storage) -> None:
    """Delete a memory, then call get_associations for it.
    Must return an empty list (no crash, no stale data)."""
    mems = await _seed_memories(race_storage, 5)
    target = mems[2]

    # target should have edges to mems[1] and mems[3]
    edges_before = await race_storage.get_associations(target.id)
    assert len(edges_before) > 0

    await race_storage.delete_memory(target.id)

    # After delete, get_associations should return empty
    edges_after = await race_storage.get_associations(target.id)
    assert edges_after == [], f"Expected empty edges after delete, got {len(edges_after)}"

    # Also verify no edges remain at the SQL level
    conn = race_storage._ensure_conn()
    async with conn.execute(
        "SELECT COUNT(*) FROM associations WHERE source_id = ? OR target_id = ?",
        (str(target.id), str(target.id)),
    ) as cur:
        row = await cur.fetchone()
        assert row[0] == 0, f"Found {row[0]} orphaned edges for deleted memory"


# ---------------------------------------------------------------------------
# Test 9: Concurrent store and delete on non-overlapping IDs
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_concurrent_store_and_delete(race_storage: Storage) -> None:
    """Store new memories while deleting old ones, using a semaphore to
    serialise SAVEPOINT-using operations. Final count must be consistent."""
    old = await _seed_memories(race_storage, 20)
    new_mems = [_make_memory(100 + i, base_text="fresh") for i in range(20)]
    sem = asyncio.Semaphore(1)

    async def store_new(m: Memory) -> str:
        async with sem:
            await race_storage.store_memory(m)
        return "stored"

    async def delete_old(m: Memory) -> bool:
        async with sem:
            return await race_storage.delete_memory(m.id)

    tasks = []
    for i in range(20):
        tasks.append(store_new(new_mems[i]))
        tasks.append(delete_old(old[i]))

    results = await asyncio.gather(*tasks, return_exceptions=True)
    errors = [r for r in results if isinstance(r, Exception)]
    assert len(errors) == 0, f"Concurrent store/delete errors: {errors}"

    # All old should be deleted, all new should exist
    final_count = await race_storage.count_memories(DOMAIN)
    # 20 old deleted + 20 new stored = 20 remaining
    assert final_count == 20, f"Expected 20 memories, got {final_count}"

    assert await _integrity_check(race_storage)


# ---------------------------------------------------------------------------
# Test 10: Full race — apoptosis + storage deletes with serialisation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_full_race_apoptosis_and_storage_ops(
    race_storage: Storage, race_config: FractalConfig,
) -> None:
    """Create a set of memories, run apoptosis execute calls sequentially
    while also running raw storage deletes on an overlapping range.
    PRAGMA integrity_check must pass afterwards."""
    embeddings = _make_mock_embeddings()
    llm = _make_mock_llm()

    associations = AssociationNetwork(race_storage, embeddings, race_config)
    scars_mgr = ScarTissueManager(race_storage, embeddings, race_config)

    apoptosis_mgr = ApoptosisManager(
        storage=race_storage,
        associations=associations,
        scars=scars_mgr,
        embeddings=embeddings,
        llm=llm,
        config=race_config,
    )

    # Seed 30 memories with associations
    mems = await _seed_memories(race_storage, 30)

    # Run apoptosis execute on first 10 memories (each does internal
    # store_memory for fragments + delete_memory + scar creation)
    apoptosis_reports = []
    for i in range(10):
        report = await apoptosis_mgr.execute_apoptosis(mems[i], reason="obsolescence")
        apoptosis_reports.append(report)

    # Now delete memories 5-15 (some already deleted by apoptosis above)
    delete_results = []
    for i in range(5, 15):
        result = await race_storage.delete_memory(mems[i].id)
        delete_results.append(result)

    # Database must be consistent
    assert await _integrity_check(race_storage)

    # No orphaned edges referencing deleted memories
    deleted_ids = set()
    for i in range(15):
        if await race_storage.get_memory(mems[i].id) is None:
            deleted_ids.add(mems[i].id)

    all_edges = await race_storage.get_all_associations()
    for src, tgt, _w in all_edges:
        assert src not in deleted_ids, f"Orphaned source edge: {src}"
        assert tgt not in deleted_ids, f"Orphaned target edge: {tgt}"

    # Verify some apoptosis reports were generated
    assert len(apoptosis_reports) == 10
    for report in apoptosis_reports:
        assert report.reason == "obsolescence"


# ---------------------------------------------------------------------------
# Test 11: Concurrent batch_decay_and_prune interleaved with deletes
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_concurrent_decay_and_deletes(race_storage: Storage) -> None:
    """Run batch_decay_and_prune while deleting memories that own edges.
    Uses a semaphore to serialise SAVEPOINT regions. No crash, integrity passes."""
    mems = await _seed_memories(race_storage, 30)
    sem = asyncio.Semaphore(1)

    async def decay() -> int:
        async with sem:
            return await race_storage.batch_decay_and_prune(factor=0.5, min_weight=0.3)

    async def guarded_delete(m: Memory) -> bool:
        async with sem:
            return await race_storage.delete_memory(m.id)

    results = await asyncio.gather(
        decay(),
        *[guarded_delete(mems[i]) for i in range(10)],
        return_exceptions=True,
    )

    errors = [r for r in results if isinstance(r, Exception)]
    assert len(errors) == 0, f"Concurrent decay + delete errors: {errors}"
    assert await _integrity_check(race_storage)

    # Verify the right number of memories remain
    remaining = await race_storage.count_memories(DOMAIN)
    assert remaining == 20  # 30 - 10 deleted


# ---------------------------------------------------------------------------
# Test 12: Rapid fire store -> delete -> verify cycle
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_rapid_store_delete_store_same_id(race_storage: Storage) -> None:
    """Store a memory, delete it, and immediately store a new memory with a
    different ID at high speed. Verifies no stale cache or locking issues."""
    for _ in range(50):
        mem = _make_memory(0, base_text="rapid")
        await race_storage.store_memory(mem)
        deleted = await race_storage.delete_memory(mem.id)
        assert deleted is True
        assert await race_storage.get_memory(mem.id) is None

    # Final state: zero memories with the rapid base text pattern
    remaining = await race_storage.count_memories(DOMAIN)
    assert remaining == 0
    assert await _integrity_check(race_storage)
