"""Cross-domain isolation tests — domain A data must not leak into domain B."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = float(np.linalg.norm(vec))
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm():
    mock = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        lower = prompt.lower()
        if "summarize" in lower or "summary" in lower:
            return "Session summary."
        return json.dumps({
            "l0_tag": "test:tag", "l1_label": "label",
            "l2_summary": "summary", "l3_full": "full",
        })
    mock.complete = AsyncMock(side_effect=_complete)
    mock.model_name = "mock-model"
    return mock


def _make_mock_embeddings(dim: int = 384):
    mock = AsyncMock()
    mock.embed = AsyncMock(side_effect=lambda text: _deterministic_embed(text, dim))
    mock.embed_batch = AsyncMock(
        side_effect=lambda texts: [_deterministic_embed(t, dim) for t in texts]
    )
    mock.model_name = "mock-model"
    mock.dimension = dim
    return mock


@pytest.fixture
def config(tmp_path):
    return FractalConfig(
        db_path=tmp_path / "isolation_test.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
        enable_llm_judge=False,
    )


@pytest.fixture
async def fm(config):
    fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
    await fm.initialize()
    yield fm
    await fm.close()


# ---------------------------------------------------------------------------
# Retrieval isolation
# ---------------------------------------------------------------------------


class TestRetrievalIsolation:
    """Retrieve should only return memories from the active domain."""

    async def test_retrieve_only_returns_own_domain(self, fm):
        """Memories in domain A should not appear in domain B retrieval."""
        # Store in domain A
        await fm.session_start("domain-a")
        mem_a = await fm.store("Python is used in domain A")
        assert mem_a is not None
        await fm.session_end()

        # Store in domain B
        await fm.session_start("domain-b")
        mem_b = await fm.store("Java is used in domain B")

        # Retrieve from domain B
        result = await fm.retrieve("what language?")
        for mem in result.l3_memories:
            assert mem.domain == "domain-b", (
                f"Memory from domain {mem.domain} leaked into domain-b retrieval"
            )

    async def test_retrieve_explicit_domain_override(self, fm):
        """Explicit domain parameter should override session domain."""
        await fm.session_start("session-domain")
        await fm.store("Memory in session domain")
        await fm.store("Memory in session domain 2", domain="other-domain")

        # Retrieve with explicit domain override
        result = await fm.retrieve("memory", domain="other-domain")
        for mem in result.l3_memories:
            assert mem.domain == "other-domain"


# ---------------------------------------------------------------------------
# Store isolation
# ---------------------------------------------------------------------------


class TestStoreIsolation:
    """Store should respect domain boundaries."""

    async def test_store_inherits_session_domain(self, fm):
        """Store without explicit domain uses session domain."""
        await fm.session_start("my-project")
        mem = await fm.store("Project memory")
        assert mem is not None
        assert mem.domain == "my-project"

    async def test_store_explicit_domain_overrides_session(self, fm):
        """Store with explicit domain uses that domain."""
        await fm.session_start("default-domain")
        mem = await fm.store("Cross-domain store", domain="other-domain")
        assert mem is not None
        assert mem.domain == "other-domain"

    async def test_get_memories_by_domain_isolated(self, fm):
        """get_memories_by_domain should only return memories from that domain."""
        await fm.session_start("domain-x")
        await fm.store("Memory X1")
        await fm.store("Memory X2")
        await fm.session_end()

        await fm.session_start("domain-y")
        await fm.store("Memory Y1")

        mems_x = await fm.get_memories_by_domain("domain-x")
        mems_y = await fm.get_memories_by_domain("domain-y")

        for m in mems_x:
            assert m.domain == "domain-x"
        for m in mems_y:
            assert m.domain == "domain-y"

        # Different counts
        assert len(mems_x) == 2
        assert len(mems_y) == 1


# ---------------------------------------------------------------------------
# Stats isolation
# ---------------------------------------------------------------------------


class TestStatsIsolation:
    """Domain stats should be accurate per domain."""

    async def test_stats_per_domain_accurate(self, fm):
        """Memory counts per domain should be accurate in stats."""
        await fm.session_start("alpha")
        await fm.store("Alpha 1")
        await fm.store("Alpha 2")
        await fm.store("Alpha 3")
        await fm.session_end()

        await fm.session_start("beta")
        await fm.store("Beta 1")

        stats = await fm.get_stats()
        domain_map = {d["name"]: d["memory_count"] for d in stats["domains"]}
        assert domain_map.get("alpha", 0) == 3
        assert domain_map.get("beta", 0) == 1


# ---------------------------------------------------------------------------
# Bootstrap isolation
# ---------------------------------------------------------------------------


class TestBootstrapIsolation:
    """Bootstrap context should be scoped to the session domain."""

    async def test_bootstrap_summary_from_same_domain(self, fm):
        """Bootstrap should include summary from the same domain's last session."""
        await fm.session_start("domain-a")
        await fm.store("Domain A work")
        await fm.session_end()

        await fm.session_start("domain-b")
        await fm.store("Domain B work")
        await fm.session_end()

        # Start new session in domain A — should get domain A's summary
        ctx = await fm.session_start("domain-a")
        if ctx.last_summary:
            # Summary should reference domain A content, not domain B
            assert ctx.last_summary is not None


# ---------------------------------------------------------------------------
# Domain validation
# ---------------------------------------------------------------------------


class TestDomainValidation:
    """Domain name validation should be enforced."""

    async def test_empty_domain_raises(self, fm):
        """Empty string domain should raise ValueError."""
        await fm.session_start("valid-domain")
        with pytest.raises(ValueError):
            await fm.store("test", domain="")

    async def test_invalid_domain_raises(self, fm):
        """Domain with invalid characters should raise ValueError."""
        await fm.session_start("valid-domain")
        with pytest.raises(ValueError):
            await fm.store("test", domain="invalid domain with spaces!")

    async def test_valid_domain_formats(self, fm):
        """Various valid domain formats should work."""
        valid_domains = [
            "simple",
            "with-hyphens",
            "with_underscores",
            "with.dots",
            "CamelCase",
            "mix-of_all.formats123",
        ]
        for domain in valid_domains:
            await fm.session_start(domain)
            mem = await fm.store(f"Memory in {domain}")
            assert mem is not None
            assert mem.domain == domain
            await fm.session_end()


# ---------------------------------------------------------------------------
# Domain list
# ---------------------------------------------------------------------------


class TestDomainList:
    """list_domains should return all domains with correct counts."""

    async def test_list_domains_returns_all(self, fm):
        """All domains with memories should appear in list."""
        await fm.session_start("proj-alpha")
        await fm.store("Alpha content")
        await fm.session_end()

        await fm.session_start("proj-beta")
        await fm.store("Beta content 1")
        await fm.store("Beta content 2")
        await fm.session_end()

        domains = await fm.list_domains()
        names = {d.name for d in domains}
        assert "proj-alpha" in names
        assert "proj-beta" in names

        # Verify counts
        counts = {d.name: d.memory_count for d in domains}
        assert counts["proj-alpha"] == 1
        assert counts["proj-beta"] == 2
