"""Tests for Option 1 — MCP dashboard co-launch (shared asyncio loop).

Verifies:
- _run_dashboard exits cleanly when dashboard extras are not importable.
- _run_dashboard passes host/port from FractalConfig to uvicorn (no hardcoding).
- _run_dashboard logs error and returns cleanly if uvicorn fails to start.
- lifespan cancels the dashboard task and calls fm.close() on shutdown.
- dashboard_host / dashboard_port defaults are correct.
- Config values are overridable (single source of truth).
"""

from __future__ import annotations

import asyncio
import logging
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from fractal_memory.config import FractalConfig


# ---------------------------------------------------------------------------
# Config: dashboard fields are present with correct defaults
# ---------------------------------------------------------------------------


def test_dashboard_host_default():
    """dashboard_host defaults to localhost — dashboard never binds to 0.0.0.0."""
    assert FractalConfig().dashboard_host == "127.0.0.1"


def test_dashboard_port_default():
    """dashboard_port defaults to 8765."""
    assert FractalConfig().dashboard_port == 8765


def test_dashboard_host_configurable(tmp_path: Path):
    """dashboard_host is overridable via FractalConfig — no hardcoding in server."""
    config = FractalConfig(db_path=tmp_path / "m.db", dashboard_host="127.0.0.2")
    assert config.dashboard_host == "127.0.0.2"


def test_dashboard_port_configurable(tmp_path: Path):
    """dashboard_port is overridable via FractalConfig — no hardcoding in server."""
    config = FractalConfig(db_path=tmp_path / "m.db", dashboard_port=9999)
    assert config.dashboard_port == 9999


# ---------------------------------------------------------------------------
# _run_dashboard: graceful no-op when dashboard extras missing
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_dashboard_missing_extras_logs_warning(tmp_path: Path, caplog):
    """_run_dashboard logs a warning and exits cleanly if dashboard extras absent.

    This ensures the MCP server starts even without `pip install [dashboard]`.
    """
    from fractal_memory.mcp.server import _run_dashboard

    config = FractalConfig(db_path=tmp_path / "m.db", gate_signal_count=1)
    mock_fm = MagicMock()
    mock_fm._config = config
    type(mock_fm).config = property(lambda self: self._config)

    dashboard_key = "fractal_memory.dashboard.app"
    original = sys.modules.get(dashboard_key, ...)
    # Setting to None makes the import raise ImportError
    sys.modules[dashboard_key] = None  # type: ignore[assignment]
    try:
        with caplog.at_level(logging.WARNING, logger="fractal_memory.mcp.server"):
            await _run_dashboard(mock_fm)
        assert any(
            "Dashboard extras not installed" in r.message for r in caplog.records
        ), "Expected warning about missing dashboard extras"
    finally:
        if original is ...:
            sys.modules.pop(dashboard_key, None)
        else:
            sys.modules[dashboard_key] = original  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# _run_dashboard: passes host/port from config to uvicorn (real function)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_dashboard_uses_config_host_port(tmp_path: Path):
    """_run_dashboard reads host and port from fm._config, not hardcoded values.

    Tests the real _run_dashboard implementation by mocking only its external
    dependencies (uvicorn and create_dashboard), not by replacing the function.
    """
    from fractal_memory.mcp.server import _run_dashboard

    config = FractalConfig(
        db_path=tmp_path / "m.db",
        gate_signal_count=1,
        dashboard_host="127.0.0.1",
        dashboard_port=18765,
    )
    mock_fm = MagicMock()
    mock_fm._config = config
    type(mock_fm).config = property(lambda self: self._config)

    captured: list[dict] = []

    mock_uvicorn_config = MagicMock(side_effect=lambda app, host, port, log_level: (
        captured.append({"host": host, "port": port}) or MagicMock()
    ))
    mock_server = AsyncMock()
    mock_server.serve = AsyncMock(return_value=None)
    mock_uvicorn_server = MagicMock(return_value=mock_server)
    mock_create = MagicMock(return_value=MagicMock())

    import fractal_memory.mcp.server as srv_mod

    with (
        patch.object(srv_mod, "uvicorn", create=True) as mock_uv,
        patch("fractal_memory.dashboard.app.create_dashboard", mock_create, create=True),
    ):
        mock_uv.Config = mock_uvicorn_config
        mock_uv.Server = mock_uvicorn_server
        # Patch the internal import inside _run_dashboard
        with patch.dict(
            "sys.modules",
            {"fractal_memory.dashboard.app": MagicMock(create_dashboard=mock_create)},
        ):
            await _run_dashboard(mock_fm)

    assert len(captured) == 1, "uvicorn.Config must be called exactly once"
    assert captured[0]["host"] == "127.0.0.1"
    assert captured[0]["port"] == 18765


# ---------------------------------------------------------------------------
# _run_dashboard: handles uvicorn startup failure (port in use, etc.)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_dashboard_handles_startup_failure(tmp_path: Path, caplog):
    """_run_dashboard logs error and returns if uvicorn fails to start.

    This covers port-already-in-use and other OS-level failures. The MCP
    server must continue running even when the dashboard cannot bind.
    """
    from fractal_memory.mcp.server import _run_dashboard

    config = FractalConfig(db_path=tmp_path / "m.db", gate_signal_count=1)
    mock_fm = MagicMock()
    mock_fm._config = config
    type(mock_fm).config = property(lambda self: self._config)

    import fractal_memory.mcp.server as srv_mod

    with (
        patch.object(srv_mod, "uvicorn", create=True) as mock_uv,
        patch.dict(
            "sys.modules",
            {"fractal_memory.dashboard.app": MagicMock(create_dashboard=MagicMock())},
        ),
        caplog.at_level(logging.ERROR, logger="fractal_memory.mcp.server"),
    ):
        # Simulate port already in use — raised before serve() is called
        mock_uv.Config = MagicMock(side_effect=OSError("Address already in use"))
        mock_uv.Server = MagicMock()

        # Must not raise — must return cleanly
        await _run_dashboard(mock_fm)

    assert any(
        "Dashboard server failed" in r.message for r in caplog.records
    ), "Startup failure must be logged as an error"


# ---------------------------------------------------------------------------
# lifespan: dashboard task is cancelled and fm.close() is called on shutdown
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_lifespan_cancels_dashboard_task_on_shutdown(tmp_path: Path):
    """lifespan cancels the background dashboard task when the context exits.

    Verifies that CancelledError is raised inside the dashboard coroutine
    (confirming the cancel propagated) and that fm.close() is called.
    """
    from fractal_memory import FractalMemory
    from fractal_memory.mcp.server import lifespan

    config = FractalConfig(db_path=tmp_path / "test_lifespan.db", gate_signal_count=1)

    cancellation_received = False

    async def mock_run_dashboard(fm: object) -> None:
        nonlocal cancellation_received
        try:
            await asyncio.sleep(9999)
        except asyncio.CancelledError:
            cancellation_received = True
            raise

    fake_server = MagicMock()

    import fractal_memory.mcp.server as srv_mod

    with patch.object(srv_mod, "_run_dashboard", mock_run_dashboard):
        with patch("fractal_memory.mcp.server.FractalMemory") as MockFM:
            mock_fm = AsyncMock(spec=FractalMemory)
            mock_fm._session = MagicMock()
            mock_fm._session.current_session = None
            mock_fm.get_current_session = MagicMock(return_value=None)
            mock_fm._config = config
            type(mock_fm).config = property(lambda self: self._config)
            mock_fm._storage = AsyncMock()
            mock_fm._storage.upsert_session_activity = AsyncMock()
            mock_fm.record_activity = AsyncMock()
            mock_fm._activity_stores = 0
            mock_fm._activity_retrievals = 0
            type(mock_fm).activity_stores = property(lambda s: 0)
            type(mock_fm).activity_retrievals = property(lambda s: 0)
            # session_start returns a context with a session object
            session_ctx = MagicMock()
            session_ctx.session.id = "test-session-id"
            session_ctx.session.started_at = "2024-01-01T00:00:00"
            mock_fm.session_start = AsyncMock(return_value=session_ctx)
            MockFM.return_value = mock_fm

            async with lifespan(fake_server) as ctx:
                assert "fm" in ctx
                # Yield control so dashboard_task can start
                await asyncio.sleep(0)

    assert cancellation_received, (
        "Dashboard task must receive CancelledError when lifespan exits"
    )
    mock_fm.close.assert_awaited_once()


@pytest.mark.asyncio
async def test_lifespan_closes_fm_even_if_no_active_session(tmp_path: Path):
    """fm.close() is always called on shutdown regardless of session state."""
    from fractal_memory import FractalMemory
    from fractal_memory.mcp.server import lifespan

    async def mock_run_dashboard(fm: object) -> None:
        await asyncio.sleep(9999)

    fake_server = MagicMock()

    import fractal_memory.mcp.server as srv_mod

    with patch.object(srv_mod, "_run_dashboard", mock_run_dashboard):
        with patch("fractal_memory.mcp.server.FractalMemory") as MockFM:
            mock_fm = AsyncMock(spec=FractalMemory)
            mock_fm._session = MagicMock()
            mock_fm._session.current_session = None  # No active session
            mock_fm.get_current_session = MagicMock(return_value=None)
            mock_fm._config = FractalConfig(
                db_path=tmp_path / "t.db", gate_signal_count=1
            )
            type(mock_fm).config = property(lambda self: self._config)
            mock_fm._storage = AsyncMock()
            mock_fm._storage.upsert_session_activity = AsyncMock()
            mock_fm.record_activity = AsyncMock()
            mock_fm._activity_stores = 0
            mock_fm._activity_retrievals = 0
            type(mock_fm).activity_stores = property(lambda s: 0)
            type(mock_fm).activity_retrievals = property(lambda s: 0)
            # session_start returns a context with a session object
            session_ctx = MagicMock()
            session_ctx.session.id = "test-session-id"
            session_ctx.session.started_at = "2024-01-01T00:00:00"
            mock_fm.session_start = AsyncMock(return_value=session_ctx)
            MockFM.return_value = mock_fm

            async with lifespan(fake_server):
                await asyncio.sleep(0)

    mock_fm.close.assert_awaited_once()
    # session_end must NOT be called when there is no active session
    mock_fm.session_end.assert_not_awaited()
