"""Stress tests for retrieval correctness under adversarial inputs.

Tests 22 adversarial scenarios grouped into:
- Near-duplicate adversarial
- Duplicate flooding
- Chain reference adversarial
- Circular associations
- Scar adversarial
- Token budget pressure
- Retrieval invariants
- Edge cases
"""

from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock
from uuid import uuid4, UUID

import numpy as np
import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus, Memory, RetrievalResult
from fractal_memory.storage import Storage, _pack_embedding
from fractal_memory.retrieval import RetrievalEngine
from fractal_memory.scar import ScarTissueManager, Scar
from fractal_memory.associations import AssociationNetwork


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive unit-norm embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_embeddings(dim: int = 384) -> AsyncMock:
    provider = AsyncMock()

    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text, dim)

    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t, dim) for t in texts]

    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = dim
    return provider


def _make_memory(
    i: int,
    domain: str = "adv",
    text: str | None = None,
    lifecycle: LifecycleStatus = LifecycleStatus.PROBATION,
    embedding: list[float] | None = None,
    intensity: float = 0.5,
    chronic_score: float = 0.0,
    reconsolidation_count: int = 0,
    chain_next: UUID | None = None,
    chain_prev: UUID | None = None,
) -> Memory:
    now = datetime.now(timezone.utc)
    actual_text = text or f"adversarial memory {i}"
    return Memory(
        id=uuid4(),
        domain=domain,
        created_at=now,
        updated_at=now,
        context={},
        l0_tag="a:t",
        l1_label="label",
        l2_summary=f"Adv mem {i}",
        l3_full=f"Adversarial memory {i} full",
        l4_raw=actual_text,
        embedding=embedding or _deterministic_embed(actual_text),
        embedding_model="mock",
        lifecycle=lifecycle,
        intensity=intensity,
        chronic_score=chronic_score,
        reconsolidation_count=reconsolidation_count,
        chain_next=chain_next,
        chain_prev=chain_prev,
    )


@pytest.fixture
def adv_config(tmp_path: Path) -> FractalConfig:
    """Adversarial test config with reduced sizes for speed."""
    return FractalConfig(
        db_path=tmp_path / "adv_test.db",
        gate_signal_count=1,
        top_l1=200,
        top_l2=50,
        top_l3=10,
        enable_scar_penalty=True,
        enable_spreading_activation=False,
    )


@pytest.fixture
async def adv_storage(adv_config: FractalConfig):
    s = Storage(adv_config)
    await s.initialize()
    yield s
    await s.close()


@pytest.fixture
def mock_embed() -> AsyncMock:
    return _make_mock_embeddings()


# ===========================================================================
# Test Class 1: Near-Duplicate Adversarial
# ===========================================================================


class TestNearDuplicateAdversarial:
    """Near-duplicate and opposite-meaning memories."""

    async def test_near_duplicates_opposite_meanings(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Store 'Python is great' and 'Python is terrible' with similar embeddings.

        Even with similar embeddings, both should appear in results as separate
        memories, and the one closer to the query should rank higher.
        """
        # Create two memories with intentionally close (but not identical) embeddings
        base_emb = np.array(_deterministic_embed("Python programming"), dtype=np.float32)
        # Perturb slightly for "great" and "terrible"
        rng = np.random.RandomState(42)
        perturb = rng.randn(384).astype(np.float32) * 0.05
        emb_great = (base_emb + perturb).tolist()
        emb_terrible = (base_emb - perturb).tolist()

        m_great = _make_memory(1, text="Python is great", embedding=emb_great)
        m_terrible = _make_memory(2, text="Python is terrible", embedding=emb_terrible)
        await adv_storage.store_memory(m_great)
        await adv_storage.store_memory(m_terrible)

        engine = RetrievalEngine(adv_storage, mock_embed, adv_config)
        result = await engine.retrieve("Python is great", domain="adv")

        # Both memories should appear (only 2 total)
        all_ids = {m.id for m in result.l1_memories}
        assert m_great.id in all_ids
        assert m_terrible.id in all_ids
        # They should be separate entries
        assert len(result.l1_memories) == 2

    async def test_identical_embeddings_different_domains(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Two memories with the same embedding in different domains.

        Domain-scoped retrieval should return only the memory from the queried domain.
        """
        shared_emb = _deterministic_embed("shared concept")
        m_a = _make_memory(1, domain="domain-a", embedding=shared_emb)
        m_b = _make_memory(2, domain="domain-b", embedding=shared_emb)
        await adv_storage.store_memory(m_a)
        await adv_storage.store_memory(m_b)

        engine = RetrievalEngine(adv_storage, mock_embed, adv_config)

        result_a = await engine.retrieve("shared concept", domain="domain-a")
        result_b = await engine.retrieve("shared concept", domain="domain-b")

        a_ids = {m.id for m in result_a.l1_memories}
        b_ids = {m.id for m in result_b.l1_memories}

        assert m_a.id in a_ids
        assert m_b.id not in a_ids
        assert m_b.id in b_ids
        assert m_a.id not in b_ids


# ===========================================================================
# Test Class 2: Duplicate Flooding
# ===========================================================================


class TestDuplicateFlooding:
    """Flood attacks with duplicates."""

    async def test_same_text_100_times(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Store the same text 100 times. Retrieval must not crash."""
        for i in range(100):
            m = _make_memory(i, text="duplicate content flood")
            await adv_storage.store_memory(m)

        engine = RetrievalEngine(adv_storage, mock_embed, adv_config)
        result = await engine.retrieve("duplicate content flood", domain="adv")

        # Should return results without crashing
        assert isinstance(result, RetrievalResult)
        assert len(result.l1_memories) > 0
        # L3 should be capped at top_l3
        assert len(result.l3_memories) <= adv_config.top_l3
        # L2 capped at top_l2
        assert len(result.l2_memories) <= adv_config.top_l2

    async def test_retrieval_ranking_stability(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Same query run 5 times must produce identical results each time."""
        for i in range(15):
            await adv_storage.store_memory(_make_memory(i))

        engine = RetrievalEngine(adv_storage, mock_embed, adv_config)

        results = []
        for _ in range(5):
            r = await engine.retrieve("adversarial memory 0", domain="adv")
            results.append([m.id for m in r.l3_memories])

        # All 5 runs should produce the same ordering
        for i in range(1, 5):
            assert results[i] == results[0], (
                f"Run {i} differs from run 0: {results[i]} != {results[0]}"
            )


# ===========================================================================
# Test Class 3: Chain Reference Adversarial
# ===========================================================================


class TestChainAdversarial:
    """Cyclic and self-referencing chain pointers."""

    async def test_cyclic_chain_delete(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """A->B->C->A cycle: delete should not infinite loop."""
        m_a = _make_memory(1, text="chain A")
        m_b = _make_memory(2, text="chain B")
        m_c = _make_memory(3, text="chain C")

        # Set up cycle A -> B -> C -> A
        m_a.chain_next = m_b.id
        m_b.chain_next = m_c.id
        m_c.chain_next = m_a.id
        m_b.chain_prev = m_a.id
        m_c.chain_prev = m_b.id
        m_a.chain_prev = m_c.id

        await adv_storage.store_memory(m_a)
        await adv_storage.store_memory(m_b)
        await adv_storage.store_memory(m_c)

        # Deleting should succeed without hanging
        deleted = await adv_storage.delete_memory(m_b.id)
        assert deleted is True

        # A and C should still exist, with chain pointers cleared
        remaining_a = await adv_storage.get_memory(m_a.id)
        remaining_c = await adv_storage.get_memory(m_c.id)
        assert remaining_a is not None
        assert remaining_c is not None
        # chain_next/chain_prev pointing to m_b should be NULL
        assert remaining_a.chain_next is None  # was m_b.id
        assert remaining_c.chain_prev is None  # was m_b.id

    async def test_self_referencing_chain_delete(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Memory with chain_next == own id: delete handles gracefully."""
        m = _make_memory(1, text="self-chain")
        m.chain_next = m.id
        m.chain_prev = m.id
        await adv_storage.store_memory(m)

        deleted = await adv_storage.delete_memory(m.id)
        assert deleted is True
        assert await adv_storage.get_memory(m.id) is None

    async def test_association_self_loop_prevention(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """store_association with source_id == target_id should be prevented."""
        m = _make_memory(1, text="self-loop memory")
        await adv_storage.store_memory(m)

        # Storage layer silently skips self-loops
        await adv_storage.store_association(m.id, m.id, weight=0.5)

        # Count should be 0 (self-loop was rejected)
        count = await adv_storage.count_associations(m.id)
        assert count == 0


# ===========================================================================
# Test Class 4: Circular Associations
# ===========================================================================


class TestCircularAssociations:
    """Circular association graph with spreading activation."""

    async def test_circular_association_no_infinite_loop(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """A->B->C->A cycle in associations: spreading activation must terminate."""
        config = FractalConfig(
            db_path=adv_config.db_path,
            gate_signal_count=1,
            enable_spreading_activation=True,
            enable_scar_penalty=False,
        )

        m_a = _make_memory(1, text="assoc circle A")
        m_b = _make_memory(2, text="assoc circle B")
        m_c = _make_memory(3, text="assoc circle C")
        await adv_storage.store_memory(m_a)
        await adv_storage.store_memory(m_b)
        await adv_storage.store_memory(m_c)

        # Create circular edges
        await adv_storage.store_association(m_a.id, m_b.id, weight=0.5)
        await adv_storage.store_association(m_b.id, m_c.id, weight=0.5)
        await adv_storage.store_association(m_c.id, m_a.id, weight=0.5)

        associations = AssociationNetwork(adv_storage, mock_embed, config)
        engine = RetrievalEngine(
            adv_storage, mock_embed, config, associations=associations,
        )

        # Must complete without hanging (timeout at 10s is a safety net)
        result = await asyncio.wait_for(
            engine.retrieve("assoc circle A", domain="adv"),
            timeout=10.0,
        )
        assert isinstance(result, RetrievalResult)
        assert len(result.l1_memories) == 3


# ===========================================================================
# Test Class 5: Scar Adversarial
# ===========================================================================


class TestScarAdversarial:
    """Adversarial scar tissue scenarios."""

    async def test_scar_exempts_safety_critical(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Scar penalty should NOT be applied to SAFETY_CRITICAL memories."""
        # Store a safety-critical memory
        m_safe = _make_memory(
            1, text="critical safety info", lifecycle=LifecycleStatus.SAFETY_CRITICAL,
        )
        await adv_storage.store_memory(m_safe)

        # Create a scar that matches this memory's embedding
        scar_id = uuid4()
        scar_emb = m_safe.embedding  # exact match
        await adv_storage.store_scar(
            scar_id, scar_emb, m_safe.id, "test scar", ttl_sessions=20,
        )

        # Score WITH scar penalty enabled
        scars = ScarTissueManager(adv_storage, mock_embed, adv_config)
        engine_with_scar = RetrievalEngine(
            adv_storage, mock_embed, adv_config, scars=scars,
        )

        result = await engine_with_scar.retrieve("critical safety info", domain="adv")

        # Safety-critical memory must still appear
        l3_ids = {m.id for m in result.l3_memories}
        assert m_safe.id in l3_ids

        scored_with_scar = await engine_with_scar.score("critical safety info", domain="adv")
        score_with_scar = None
        for mem, score in scored_with_scar:
            if mem.id == m_safe.id:
                score_with_scar = score
                break
        assert score_with_scar is not None, "Safety-critical memory not found in scored results"

        # Score WITHOUT scar penalty (no scars manager)
        engine_no_scar = RetrievalEngine(
            adv_storage, mock_embed, adv_config,
        )
        scored_without_scar = await engine_no_scar.score("critical safety info", domain="adv")
        score_without_scar = None
        for mem, score in scored_without_scar:
            if mem.id == m_safe.id:
                score_without_scar = score
                break
        assert score_without_scar is not None, "Safety-critical memory not found in no-scar results"

        # Scores must be equal: scar penalty was NOT applied to safety-critical memory
        assert score_with_scar == pytest.approx(score_without_scar, abs=0.01), (
            f"Safety-critical memory was penalized by scar: "
            f"with_scar={score_with_scar:.4f}, without_scar={score_without_scar:.4f}"
        )

    async def test_scar_near_threshold_boundary(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Scar pattern near the 0.7 threshold: test boundary behavior."""
        m = _make_memory(1, text="boundary scar test")
        await adv_storage.store_memory(m)

        # Create scar with exact embedding (similarity = 1.0, well above 0.7)
        scar_id_high = uuid4()
        await adv_storage.store_scar(
            scar_id_high, m.embedding, m.id, "high-match scar",
            ttl_sessions=20,
        )

        scars = ScarTissueManager(adv_storage, mock_embed, adv_config)

        # Query with the same embedding should trigger the scar
        scored_with_scar = await scars.apply_scar_penalty(
            m.embedding,
            [(m, 1.0)],
        )
        # Score should be penalized (direct penalty = 0.5)
        for mem, score in scored_with_scar:
            if mem.id == m.id:
                assert score == pytest.approx(0.5, abs=0.01), (
                    f"Direct scar penalty not applied: got {score}"
                )

    async def test_100_active_scars_performance(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """100 active scars: retrieval still completes in <5s."""
        # Store some memories
        for i in range(20):
            await adv_storage.store_memory(_make_memory(i))

        # Create 100 scars with varied patterns
        for i in range(100):
            scar_id = uuid4()
            scar_emb = _deterministic_embed(f"scar pattern {i}")
            await adv_storage.store_scar(
                scar_id, scar_emb, None, f"test scar {i}",
                ttl_sessions=20, sessions_elapsed=0,
            )

        scars = ScarTissueManager(adv_storage, mock_embed, adv_config)
        engine = RetrievalEngine(
            adv_storage, mock_embed, adv_config, scars=scars,
        )

        start = time.monotonic()
        result = await engine.retrieve("adversarial memory 5", domain="adv")
        elapsed = time.monotonic() - start

        assert elapsed < 5.0, f"Retrieval with 100 scars took {elapsed:.2f}s (>5s)"
        assert isinstance(result, RetrievalResult)

    async def test_expired_scar_no_penalty(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Expired scar (sessions_elapsed >= ttl) should not penalize after cleanup."""
        m = _make_memory(1, text="expired scar target")
        await adv_storage.store_memory(m)

        # Create scar that is already expired
        scar_id = uuid4()
        await adv_storage.store_scar(
            scar_id, m.embedding, m.id, "expired scar",
            ttl_sessions=5, sessions_elapsed=5,
        )

        # Delete expired scars
        deleted = await adv_storage.delete_expired_scars()
        assert deleted >= 1

        # Verify the scar was actually deleted from the DB
        active_scars = await adv_storage.get_active_scars()
        active_scar_ids = {s[0] if isinstance(s, tuple) else s.id for s in active_scars}
        assert scar_id not in active_scar_ids, (
            f"Expired scar {scar_id} still present in get_active_scars() after deletion"
        )

        scars = ScarTissueManager(adv_storage, mock_embed, adv_config)
        engine = RetrievalEngine(
            adv_storage, mock_embed, adv_config, scars=scars,
        )

        # Score without scar should be unpenalized
        scored = await engine.score("expired scar target", domain="adv")
        assert len(scored) == 1
        mem, score = scored[0]
        # Should be near full score (cosine ~1.0 * 0.8 + intensity 0.5 * 0.2 = ~0.9)
        assert score > 0.7, f"Expired scar still penalizing: score={score}"

    async def test_zero_vector_scar_no_nan(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Zero-vector scar pattern must not cause NaN in similarity computation."""
        m = _make_memory(1, text="zero scar test")
        await adv_storage.store_memory(m)

        # Create scar with zero vector — _pack_embedding doesn't allow NaN/Inf
        # but it does allow all-zeros
        zero_emb = [0.0] * 384
        scar_id = uuid4()
        await adv_storage.store_scar(
            scar_id, zero_emb, m.id, "zero vector scar",
            ttl_sessions=20, sessions_elapsed=0,
        )

        scars = ScarTissueManager(adv_storage, mock_embed, adv_config)
        engine = RetrievalEngine(
            adv_storage, mock_embed, adv_config, scars=scars,
        )

        result = await engine.retrieve("zero scar test", domain="adv")
        # Must not crash, no NaN in scores
        assert isinstance(result, RetrievalResult)
        for mem in result.l3_memories:
            # Scores are internal but the fact we get results means no NaN crash
            assert mem is not None

        # Double-check with direct scoring
        scored = await engine.score("zero scar test", domain="adv")
        for mem, score in scored:
            import math
            assert not math.isnan(score), f"NaN score for memory {mem.id}"
            assert not math.isinf(score), f"Inf score for memory {mem.id}"


# ===========================================================================
# Test Class 6: Token Budget Pressure
# ===========================================================================


class TestTokenBudgetPressure:
    """Token budget edge cases."""

    async def test_massive_l3_tiny_budget(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Massive L3 memories with tiny token budget: only highest-scored included."""
        # Create memories with very long l3_full
        for i in range(20):
            m = _make_memory(i)
            m.l3_full = f"Very long adversarial memory {i} " * 200  # ~4000 chars each
            await adv_storage.store_memory(m)

        engine = RetrievalEngine(adv_storage, mock_embed, adv_config)

        # Tiny budget: should trigger pressure response
        result = await engine.retrieve(
            "adversarial memory 5", domain="adv", token_budget=50,
        )

        assert isinstance(result, RetrievalResult)
        # Budget pressure should have reduced L3 count
        assert len(result.l3_memories) < 10
        # Result should still be valid
        assert result.token_budget_total == 50

    async def test_safety_critical_overflow_budget(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """All SAFETY_CRITICAL memories that exceed budget: some still returned."""
        for i in range(15):
            m = _make_memory(
                i,
                text=f"critical memory {i}",
                lifecycle=LifecycleStatus.SAFETY_CRITICAL,
            )
            m.l3_full = f"Safety critical info {i} " * 100
            await adv_storage.store_memory(m)

        engine = RetrievalEngine(adv_storage, mock_embed, adv_config)

        result = await engine.retrieve(
            "critical memory 3", domain="adv", token_budget=100,
        )

        # Even under severe budget pressure, we should get some results
        # The engine applies pressure by demoting L3->L2->L1, not dropping entirely
        assert isinstance(result, RetrievalResult)
        assert len(result.l1_memories) > 0, "No memories returned under budget pressure"


# ===========================================================================
# Test Class 7: Retrieval Invariants
# ===========================================================================


class TestRetrievalInvariants:
    """Structural invariants that must hold for every retrieval."""

    async def test_l3_subset_l2_subset_l1(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """L3 IDs must be a subset of L2 IDs, which must be a subset of L1 IDs."""
        for i in range(30):
            await adv_storage.store_memory(_make_memory(i))

        engine = RetrievalEngine(adv_storage, mock_embed, adv_config)
        result = await engine.retrieve("adversarial memory 10", domain="adv")

        l3_ids = {m.id for m in result.l3_memories}
        l2_ids = {m.id for m in result.l2_memories}
        l1_ids = {m.id for m in result.l1_memories}

        # Guard against trivially-passing empty sets: at least one tier must be non-empty
        assert len(l1_ids) > 0, (
            "All tiers are empty — subset assertion would pass trivially. "
            "With 30 stored memories, L1 must contain at least one result."
        )

        assert l3_ids <= l2_ids, (
            f"L3 not subset of L2: L3-only = {l3_ids - l2_ids}"
        )
        assert l2_ids <= l1_ids, (
            f"L2 not subset of L1: L2-only = {l2_ids - l1_ids}"
        )

    async def test_scores_monotonically_non_increasing_per_tier(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Within each tier, scores should be monotonically non-increasing."""
        for i in range(30):
            await adv_storage.store_memory(
                _make_memory(i, intensity=0.1 + (i % 10) * 0.08),
            )

        engine = RetrievalEngine(adv_storage, mock_embed, adv_config)
        scored = await engine.score("adversarial memory 15", domain="adv")
        scores = [s for _, s in scored]

        # The score() method returns sorted descending
        for i in range(1, len(scores)):
            assert scores[i] <= scores[i - 1] + 1e-9, (
                f"Scores not non-increasing at index {i}: "
                f"{scores[i-1]:.6f} -> {scores[i]:.6f}"
            )

    async def test_empty_domain_retrieval(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Retrieval on a domain with no memories returns empty result, no crash."""
        engine = RetrievalEngine(adv_storage, mock_embed, adv_config)
        result = await engine.retrieve("anything", domain="nonexistent-domain")

        assert isinstance(result, RetrievalResult)
        assert result.l3_memories == []
        assert result.l2_memories == []
        assert result.l1_memories == []
        assert result.hints == []

    async def test_zero_similarity_all_memories(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """All memories have zero-vector embeddings: retrieval returns empty or minimal results."""
        zero_emb = [0.0] * 384
        for i in range(10):
            m = _make_memory(i, embedding=zero_emb)
            await adv_storage.store_memory(m)

        engine = RetrievalEngine(adv_storage, mock_embed, adv_config)
        result = await engine.retrieve("test query", domain="adv")

        # Zero-vector memories get cosine similarity 0.0 (handled by engine)
        # They may still appear due to intensity weight, but scores should be very low
        assert isinstance(result, RetrievalResult)
        # Verify no NaN scores via score() method
        scored = await engine.score("test query", domain="adv")
        for mem, score in scored:
            import math
            assert not math.isnan(score), f"NaN score with zero-vector embedding"
            # Score should be only intensity-based: 0.5 * 0.2 = 0.1
            assert score == pytest.approx(0.1, abs=0.05)


# ===========================================================================
# Test Class 8: Edge Cases
# ===========================================================================


class TestEdgeCases:
    """Extreme-value edge cases."""

    async def test_chronic_score_at_float_limits(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Memory with chronic_score at float limits: retrieval handles correctly."""
        m_max = _make_memory(1, text="max chronic", chronic_score=1.0)
        m_zero = _make_memory(2, text="zero chronic", chronic_score=0.0)
        # Use a very small float (not 0)
        m_tiny = _make_memory(3, text="tiny chronic", chronic_score=1e-300)
        await adv_storage.store_memory(m_max)
        await adv_storage.store_memory(m_zero)
        await adv_storage.store_memory(m_tiny)

        engine = RetrievalEngine(adv_storage, mock_embed, adv_config)
        result = await engine.retrieve("chronic", domain="adv")

        assert isinstance(result, RetrievalResult)
        assert len(result.l1_memories) == 3
        # All three should be present
        ids = {m.id for m in result.l1_memories}
        assert m_max.id in ids
        assert m_zero.id in ids
        assert m_tiny.id in ids

    async def test_max_reconsolidation_count(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Memory with maximum reconsolidation_count still appears in retrieval."""
        m = _make_memory(
            1, text="reconsolidated many times", reconsolidation_count=999999,
        )
        await adv_storage.store_memory(m)

        engine = RetrievalEngine(adv_storage, mock_embed, adv_config)
        result = await engine.retrieve("reconsolidated many times", domain="adv")

        l1_ids = {mem.id for mem in result.l1_memories}
        assert m.id in l1_ids, "High-reconsolidation memory excluded from results"

    async def test_retrieval_cache_freshness(
        self, adv_storage: Storage, mock_embed: AsyncMock, adv_config: FractalConfig,
    ) -> None:
        """Retrieval immediately after store: new memory appears in results."""
        engine = RetrievalEngine(adv_storage, mock_embed, adv_config)

        # First retrieval to warm cache
        m1 = _make_memory(1, text="existing memory")
        await adv_storage.store_memory(m1)
        result1 = await engine.retrieve("existing memory", domain="adv")
        assert m1.id in {m.id for m in result1.l1_memories}

        # Store new memory and invalidate cache
        m2 = _make_memory(2, text="brand new memory")
        await adv_storage.store_memory(m2)
        engine.invalidate_cache(domain="adv")

        # New memory should appear immediately
        result2 = await engine.retrieve("brand new memory", domain="adv")
        r2_ids = {m.id for m in result2.l1_memories}
        assert m2.id in r2_ids, (
            "New memory not found in retrieval results after cache invalidation"
        )
