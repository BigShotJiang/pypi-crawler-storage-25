"""Determinism and reproducibility tests — same inputs should produce same outputs."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig, load_config
from fractal_memory.models import LifecycleStatus


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = float(np.linalg.norm(vec))
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm():
    mock = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        lower = prompt.lower()
        if "summarize" in lower or "summary" in lower:
            return "Session summary."
        return json.dumps({
            "l0_tag": "test:tag", "l1_label": "Test label",
            "l2_summary": "Test summary", "l3_full": "Full context",
        })
    mock.complete = AsyncMock(side_effect=_complete)
    mock.model_name = "mock-model"
    return mock


def _make_mock_embeddings(dim: int = 384):
    mock = AsyncMock()
    mock.embed = AsyncMock(side_effect=lambda text: _deterministic_embed(text, dim))
    mock.embed_batch = AsyncMock(
        side_effect=lambda texts: [_deterministic_embed(t, dim) for t in texts]
    )
    mock.model_name = "mock-model"
    mock.dimension = dim
    return mock


@pytest.fixture
def config(tmp_path):
    return FractalConfig(
        db_path=tmp_path / "determinism_test.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
        enable_llm_judge=False,
    )


@pytest.fixture
async def fm(config):
    fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
    await fm.initialize()
    yield fm
    await fm.close()


# ---------------------------------------------------------------------------
# Embedding determinism
# ---------------------------------------------------------------------------


class TestEmbeddingDeterminism:
    """Same text should always produce the same embedding."""

    def test_same_text_same_embedding(self):
        """Deterministic embed should be consistent."""
        emb1 = _deterministic_embed("hello world")
        emb2 = _deterministic_embed("hello world")
        assert emb1 == emb2

    def test_different_text_different_embedding(self):
        """Different text should produce different embeddings."""
        emb1 = _deterministic_embed("hello world")
        emb2 = _deterministic_embed("goodbye world")
        assert emb1 != emb2

    def test_embedding_is_unit_vector(self):
        """Embeddings should be normalized to unit length."""
        emb = _deterministic_embed("test text")
        norm = np.linalg.norm(emb)
        assert abs(norm - 1.0) < 0.001


# ---------------------------------------------------------------------------
# Retrieval determinism
# ---------------------------------------------------------------------------


class TestRetrievalDeterminism:
    """Same query should produce same ranking across multiple calls."""

    async def test_retrieval_ranking_deterministic(self, fm):
        """Same query 5 times should return identical ranking."""
        await fm.session_start("test-domain")
        await fm.store("Python is great for backend")
        await fm.store("TypeScript powers the frontend")
        await fm.store("PostgreSQL is the database")

        rankings = []
        for _ in range(5):
            result = await fm.retrieve("what language for APIs?")
            ranking = [m.id for m in result.l3_memories]
            rankings.append(ranking)

        # All rankings should be identical
        for i in range(1, len(rankings)):
            assert rankings[i] == rankings[0], (
                f"Ranking {i} differs from ranking 0"
            )

    async def test_retrieval_scores_deterministic(self, fm):
        """Same query should produce same token budget usage."""
        await fm.session_start("test-domain")
        await fm.store("Test memory for score")

        results = []
        for _ in range(3):
            result = await fm.retrieve("test")
            results.append(result.token_budget_used)

        # Budget usage should be consistent
        for i in range(1, len(results)):
            assert results[i] == results[0]


# ---------------------------------------------------------------------------
# Config determinism
# ---------------------------------------------------------------------------


class TestConfigDeterminism:
    """Config loading should be deterministic."""

    def test_config_load_order_deterministic(self, tmp_path):
        """Same config inputs should produce same config."""
        toml_path = tmp_path / "config.toml"
        toml_path.write_text('default_domain = "test-domain"\ntop_l3 = 5\n')

        config1 = load_config(toml_path)
        config2 = load_config(toml_path)

        assert config1.default_domain == config2.default_domain
        assert config1.top_l3 == config2.top_l3
        assert config1.gate_signal_count == config2.gate_signal_count

    def test_default_config_consistent(self):
        """Default config should always produce same values."""
        c1 = FractalConfig()
        c2 = FractalConfig()
        assert c1.gate_signal_count == c2.gate_signal_count
        assert c1.top_l3 == c2.top_l3
        assert c1.scoring_cosine_weight == c2.scoring_cosine_weight


# ---------------------------------------------------------------------------
# Store determinism
# ---------------------------------------------------------------------------


class TestStoreDeterminism:
    """Store operations should produce consistent results."""

    async def test_store_same_text_same_embedding(self, fm):
        """Storing the same text should produce the same embedding."""
        await fm.session_start("test-domain")
        mem1 = await fm.store("Consistent memory text")
        assert mem1 is not None

        # Store same text again (different memory ID but same embedding)
        mem2 = await fm.store("Consistent memory text")
        assert mem2 is not None

        # Embeddings should be identical
        assert mem1.embedding == mem2.embedding

    async def test_store_preserves_exact_text(self, fm):
        """l4_raw should be exactly the input text."""
        await fm.session_start("test-domain")
        text = "Exact text preservation test with special chars: <>&\"'"
        mem = await fm.store(text)
        assert mem is not None
        assert mem.l4_raw == text


# ---------------------------------------------------------------------------
# Bootstrap determinism
# ---------------------------------------------------------------------------


class TestBootstrapDeterminism:
    """Bootstrap ordering should be deterministic."""

    async def test_bootstrap_ordering_consistent(self, config):
        """Multiple session starts should produce same bootstrap order."""
        fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
        await fm.initialize()
        try:
            # Create some memories
            await fm.session_start("test-domain")
            for i in range(5):
                mem = await fm.store(f"Memory number {i} for bootstrap test")
                if mem and i < 2:
                    await fm.pin(mem.id)
            await fm.session_end()

            # Start multiple sessions and compare bootstrap
            bootstraps = []
            for _ in range(3):
                ctx = await fm.session_start("test-domain")
                ids = [m.id for m in ctx.bootstrap_memories]
                bootstraps.append(ids)
                await fm.session_end()

            # All bootstrap orderings should be identical
            for i in range(1, len(bootstraps)):
                assert bootstraps[i] == bootstraps[0], (
                    f"Bootstrap {i} differs from bootstrap 0"
                )
        finally:
            await fm.close()


# ---------------------------------------------------------------------------
# Scar determinism
# ---------------------------------------------------------------------------


class TestScarDeterminism:
    """Scar penalty should be deterministic."""

    async def test_scar_penalty_consistent(self, fm):
        """Same scar pattern should produce same penalty."""
        await fm.session_start("test-domain")
        mem = await fm.store("Memory that will get scarred")
        assert mem is not None

        # Create scar via correction
        await fm.correct(mem.id, "Completely wrong information that needs replacing")

        # Retrieve multiple times — scar penalty should be consistent
        results = []
        for _ in range(3):
            result = await fm.retrieve("wrong information")
            results.append(len(result.l3_memories))

        # Results should be consistent
        for i in range(1, len(results)):
            assert results[i] == results[0]
