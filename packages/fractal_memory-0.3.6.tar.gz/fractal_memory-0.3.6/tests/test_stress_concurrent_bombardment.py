"""Concurrent bombardment stress tests for fractal-memory.

Extends test_stress_concurrency.py with deeper race-condition probes:
100-op concurrent storms, cache races, interleaved sessions, concurrent
pin/unpin mutations, store+delete contention, and storage-level integrity
checks under heavy parallel load.

Uses real SQLite storage with deterministic mock embeddings and LLM.
"""

from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.llm import LLMProvider
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.storage import Storage


# ── Helpers ───────────────────────────────────────────────────────────


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm() -> LLMProvider:
    provider = AsyncMock(spec=LLMProvider)

    async def _complete(
        prompt: str, system: str | None = None, max_tokens: int = 500
    ) -> str:
        if "summarize" in prompt.lower():
            return "Stress test session summary."
        return json.dumps(
            {
                "l0_tag": "stress:test",
                "l1_label": "stress-test",
                "l2_summary": "A stress test memory.",
                "l3_full": "A stress test memory with full context.",
            }
        )

    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings(dim: int = 384):
    provider = AsyncMock()

    async def _embed(text: str) -> list[float]:
        return _deterministic_embed(text, dim)

    async def _embed_batch(texts: list[str]) -> list[list[float]]:
        return [_deterministic_embed(t, dim) for t in texts]

    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = dim
    return provider


def _make_memory(i: int, domain: str = "stress") -> Memory:
    """Create a deterministic Memory object for storage-level tests."""
    return Memory(
        id=uuid4(),
        domain=domain,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
        context={},
        l0_tag="s:t",
        l1_label="label",
        l2_summary=f"summary-{i}",
        l3_full=f"full-{i}",
        l4_raw=f"raw-{i}",
        embedding=_deterministic_embed(f"mem-{i}"),
        embedding_model="mock",
    )


# ── Fixtures ──────────────────────────────────────────────────────────


@pytest.fixture
def stress_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "bombardment.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
    )


@pytest.fixture
async def stress_fm(stress_config):
    fm = FractalMemory(
        stress_config,
        llm=_make_mock_llm(),
        embeddings=_make_mock_embeddings(),
    )
    await fm.initialize()
    yield fm
    if fm._session.current_session is not None:
        try:
            await fm.session_end()
        except Exception:
            pass
    await fm.close()


@pytest.fixture
async def stress_storage(stress_config):
    s = Storage(stress_config)
    await s.initialize()
    yield s
    await s.close()


# ── Test 1: 100 concurrent stores in a single session ────────────────


class TestConcurrentBombardment:
    @pytest.mark.asyncio
    async def test_100_concurrent_stores_single_session(
        self, stress_fm: FractalMemory
    ):
        """100 concurrent fm.store() calls must all succeed with zero lost writes."""
        await stress_fm.session_start("stress")

        async def _store(i: int):
            return await stress_fm.store(
                f"Bombardment store number {i} with unique payload for deduplication"
            )

        tasks = [_store(i) for i in range(100)]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Got {len(errors)} errors: {errors[:5]}"

        successes = [r for r in results if r is not None and not isinstance(r, Exception)]
        assert len(successes) == 100, f"Expected 100 stored memories, got {len(successes)}"

        stats = await stress_fm.get_stats()
        assert stats["overall"]["total_memories"] >= 100


# ── Test 2: 50 concurrent retrieves while storing ────────────────────


    @pytest.mark.asyncio
    async def test_50_concurrent_retrieves_while_storing(
        self, stress_fm: FractalMemory
    ):
        """25 stores + 25 retrieves concurrently: no stale cache, no errors."""
        await stress_fm.session_start("stress")

        # Seed some memories so retrieves have something to find
        for i in range(10):
            await stress_fm.store(f"Seed memory for concurrent retrieval test {i}")

        async def _store(i: int):
            return await stress_fm.store(
                f"Concurrent store during retrieve test {i}"
            )

        async def _retrieve(i: int):
            return await stress_fm.retrieve(
                f"seed memory {i % 10}", domain="stress"
            )

        store_tasks = [_store(i) for i in range(25)]
        retrieve_tasks = [_retrieve(i) for i in range(25)]
        all_tasks = store_tasks + retrieve_tasks

        results = await asyncio.gather(*all_tasks, return_exceptions=True)

        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Mixed store+retrieve errors: {errors[:5]}"

        # Verify stores landed
        stats = await stress_fm.get_stats()
        assert stats["overall"]["total_memories"] >= 35  # 10 seed + 25 new


# ── Test 3: Concurrent store + delete same domain ────────────────────


    @pytest.mark.asyncio
    async def test_concurrent_store_and_delete_same_domain(
        self, stress_fm: FractalMemory
    ):
        """Store 20 memories concurrently, then delete 10, then store 20 more
        concurrently. Validates data consistency after mixed mutations on the
        same domain.

        SQLite SAVEPOINT-based deletes cannot safely interleave with other
        writes on the same aiosqlite connection, so deletes run in their
        own sequential phase — the stress here is on the write storms
        surrounding them.
        """
        await stress_fm.session_start("stress")

        # Phase 1: store 20 memories concurrently
        async def _store_initial(i: int):
            return await stress_fm.store(
                f"Initial memory for delete contention test {i}"
            )

        phase1 = await asyncio.gather(
            *[_store_initial(i) for i in range(20)], return_exceptions=True
        )
        errors = [r for r in phase1 if isinstance(r, Exception)]
        assert len(errors) == 0, f"Phase-1 store errors: {errors[:3]}"
        initial_ids = [r.id for r in phase1 if r is not None]
        assert len(initial_ids) == 20

        # Phase 2: delete 10 old ones sequentially
        for mid in initial_ids[:10]:
            deleted = await stress_fm._storage.delete_memory(mid)
            assert deleted

        # Phase 3: store 20 new memories concurrently
        async def _store_new(i: int):
            return await stress_fm.store(
                f"New memory during delete contention {i}"
            )

        phase3 = await asyncio.gather(
            *[_store_new(i) for i in range(20)], return_exceptions=True
        )
        errors = [r for r in phase3 if isinstance(r, Exception)]
        assert len(errors) == 0, f"Phase-3 store errors: {errors[:3]}"

        # Count should be: 20 initial - 10 deleted + 20 new = 30
        count = await stress_fm._storage.count_memories(domain="stress")
        assert count == 30, f"Expected 30, got {count}"


# ── Test 4: Concurrent corrections on same memory ────────────────────


    @pytest.mark.asyncio
    async def test_concurrent_corrections_same_topic(
        self, stress_fm: FractalMemory
    ):
        """Store one memory, then 10 concurrent stores with similar text.

        Verify no exceptions and final memory count is consistent.
        The reconsolidation engine may merge some, but no crash.
        """
        await stress_fm.session_start("stress")

        # Store an initial "base" memory
        base = await stress_fm.store(
            "The project uses Python 3.12 for the backend services"
        )
        assert base is not None

        # 10 concurrent "corrections" / near-duplicate stores
        async def _correct(i: int):
            return await stress_fm.store(
                f"The project uses Python 3.12 for backend services — correction {i}"
            )

        tasks = [_correct(i) for i in range(10)]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Concurrent correction errors: {errors[:5]}"

        # At least the base should survive; corrections may or may not be merged
        stats = await stress_fm.get_stats()
        assert stats["overall"]["total_memories"] >= 1


# ── Test 5: Concurrent pin/unpin ─────────────────────────────────────


    @pytest.mark.asyncio
    async def test_concurrent_pin_unpin(self, stress_fm: FractalMemory):
        """Store memories, then concurrently pin and unpin overlapping sets.

        Final state: each memory has a valid boolean pinned field; no DB errors.
        """
        await stress_fm.session_start("stress")

        # Store 20 memories
        mems = []
        for i in range(20):
            m = await stress_fm.store(f"Pin contention test memory {i}")
            assert m is not None
            mems.append(m)

        # Concurrently: pin first 15, unpin last 15 (overlap of 10)
        async def _pin(mem: Memory):
            mem.pinned = True
            mem.updated_at = datetime.now(timezone.utc)
            await stress_fm._storage.update_memory(mem)

        async def _unpin(mem: Memory):
            mem.pinned = False
            mem.updated_at = datetime.now(timezone.utc)
            await stress_fm._storage.update_memory(mem)

        pin_tasks = [_pin(m) for m in mems[:15]]
        unpin_tasks = [_unpin(m) for m in mems[5:]]
        all_tasks = pin_tasks + unpin_tasks

        results = await asyncio.gather(*all_tasks, return_exceptions=True)

        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Pin/unpin contention errors: {errors[:5]}"

        # Verify every memory has a valid pinned state
        for m in mems:
            fetched = await stress_fm.get(m.id)
            assert fetched is not None
            assert isinstance(fetched.pinned, bool)


# ── Test 6: Interleaved session start/end with concurrent stores ─────


    @pytest.mark.asyncio
    async def test_interleaved_sessions_with_concurrent_stores(
        self, stress_config: FractalConfig
    ):
        """Start session, fire stores, end session, start new session,
        fire more stores. No errors across the boundary.
        """
        fm = FractalMemory(
            stress_config,
            llm=_make_mock_llm(),
            embeddings=_make_mock_embeddings(),
        )
        await fm.initialize()

        try:
            # Session 1: concurrent stores
            await fm.session_start("stress")

            async def _store_s1(i: int):
                return await fm.store(f"Session-1 concurrent memory {i}")

            tasks_s1 = [_store_s1(i) for i in range(20)]
            results_s1 = await asyncio.gather(*tasks_s1, return_exceptions=True)
            errors_s1 = [r for r in results_s1 if isinstance(r, Exception)]
            assert len(errors_s1) == 0, f"Session-1 errors: {errors_s1[:3]}"

            await fm.session_end()

            # Session 2: more concurrent stores
            await fm.session_start("stress")

            async def _store_s2(i: int):
                return await fm.store(f"Session-2 concurrent memory {i}")

            tasks_s2 = [_store_s2(i) for i in range(20)]
            results_s2 = await asyncio.gather(*tasks_s2, return_exceptions=True)
            errors_s2 = [r for r in results_s2 if isinstance(r, Exception)]
            assert len(errors_s2) == 0, f"Session-2 errors: {errors_s2[:3]}"

            # Verify all memories from both sessions persist
            stats = await fm.get_stats()
            assert stats["overall"]["total_memories"] >= 40

            await fm.session_end()
        finally:
            await fm.close()


# ── Test 7: Embedding cache invalidation under load ──────────────────


    @pytest.mark.asyncio
    async def test_embedding_cache_invalidation_under_load(
        self, stress_fm: FractalMemory
    ):
        """Store and retrieve interleaved rapidly. Recently stored memories
        should be findable in subsequent retrieves WITHOUT manual cache
        invalidation -- the system's automatic invalidation after store()
        must keep the cache fresh.
        """
        await stress_fm.session_start("stress")

        # Interleave: store a unique memory, then immediately retrieve it
        # Do NOT call invalidate_cache() -- rely on automatic invalidation
        found_count = 0
        for i in range(20):
            unique_phrase = f"xylophone-{i}-quantum-{i * 7}"
            mem = await stress_fm.store(
                f"Unique marker memory about {unique_phrase} for cache test"
            )
            assert mem is not None

            result = await stress_fm.retrieve(unique_phrase, domain="stress")
            # Check if the just-stored memory appears in results
            result_ids = [m.id for m in result.l3_memories]
            result_ids += [m.id for m in result.l2_memories]
            result_ids += [m.id for m in result.l1_memories]
            if mem.id in result_ids:
                found_count += 1

        # At least half should be found (cache must not be permanently stale)
        assert found_count >= 10, (
            f"Only {found_count}/20 recently stored memories were retrievable — "
            "automatic cache invalidation after store() may be broken"
        )


# ── Test 8: 100 stores across 10 domains simultaneously ─────────────


    @pytest.mark.asyncio
    async def test_100_stores_across_10_domains(
        self, stress_config: FractalConfig
    ):
        """10 domains x 10 stores each, all concurrent. Each domain should
        have exactly 10 memories.
        """
        fm = FractalMemory(
            stress_config,
            llm=_make_mock_llm(),
            embeddings=_make_mock_embeddings(),
        )
        await fm.initialize()

        try:
            await fm.session_start("multi-domain")

            domains = [f"domain-{d}" for d in range(10)]

            async def _store_in_domain(domain: str, i: int):
                return await fm.store(
                    f"Multi-domain store in {domain} item {i}",
                    domain=domain,
                )

            tasks = [
                _store_in_domain(domains[d], i)
                for d in range(10)
                for i in range(10)
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            errors = [r for r in results if isinstance(r, Exception)]
            assert len(errors) == 0, f"Multi-domain errors: {errors[:5]}"

            # Verify per-domain counts
            for domain in domains:
                count = await fm._storage.count_memories(domain=domain)
                assert count == 10, (
                    f"Domain {domain} has {count} memories, expected 10"
                )

            await fm.session_end()
        finally:
            await fm.close()


# ── Test 9: Concurrent storage-level writes + integrity check ────────


class TestStorageLevelBombardment:
    @pytest.mark.asyncio
    async def test_100_concurrent_storage_writes_integrity(
        self, stress_storage: Storage
    ):
        """100 concurrent storage.store_memory() calls. Then run
        PRAGMA integrity_check to verify no corruption.
        """

        async def _write(i: int):
            mem = _make_memory(i)
            await stress_storage.store_memory(mem)
            return mem.id

        tasks = [_write(i) for i in range(100)]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Storage write errors: {errors[:5]}"

        # Verify count
        count = await stress_storage.count_memories()
        assert count == 100, f"Expected 100, got {count}"

        # Run SQLite integrity check
        conn = stress_storage._ensure_conn()
        async with conn.execute("PRAGMA integrity_check") as cur:
            row = await cur.fetchone()
            assert row[0] == "ok", f"Integrity check failed: {row[0]}"


# ── Test 10: Concurrent get_memory during stores ─────────────────────


    @pytest.mark.asyncio
    async def test_concurrent_get_memory_during_stores(
        self, stress_storage: Storage
    ):
        """50 stores + 50 get_memory calls concurrently: no OperationalError.

        Reads may return None for not-yet-inserted memories — that is fine;
        the critical assertion is zero exceptions.
        """
        # Pre-insert 50 memories to read from
        pre_ids = []
        for i in range(50):
            mem = _make_memory(i, domain="pre-seed")
            await stress_storage.store_memory(mem)
            pre_ids.append(mem.id)

        async def _write(i: int):
            mem = _make_memory(100 + i)
            await stress_storage.store_memory(mem)
            return mem.id

        async def _read(mem_id):
            return await stress_storage.get_memory(mem_id)

        write_tasks = [_write(i) for i in range(50)]
        read_tasks = [_read(mid) for mid in pre_ids]
        all_tasks = write_tasks + read_tasks

        results = await asyncio.gather(*all_tasks, return_exceptions=True)

        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Concurrent read/write errors: {errors[:5]}"

        # All pre-seeded reads should return actual Memory objects
        read_results = results[50:]  # second half are reads
        none_reads = [r for r in read_results if r is None]
        assert len(none_reads) == 0, (
            f"{len(none_reads)} pre-seeded reads returned None"
        )


# ── Test 11: Concurrent count_memories during mutations ──────────────


    @pytest.mark.asyncio
    async def test_concurrent_count_during_mutations(
        self, stress_storage: Storage
    ):
        """Concurrent stores + counts, with sequential deletes between
        write storms. Verifies count_memories always returns a valid
        non-negative value and final count is deterministic.

        Deletes run in a separate phase because aiosqlite's single
        connection cannot safely interleave SAVEPOINT-based deletes
        with concurrent writes.
        """
        # Pre-insert 20 memories
        to_delete_ids = []
        for i in range(20):
            mem = _make_memory(i)
            await stress_storage.store_memory(mem)
            to_delete_ids.append(mem.id)

        # Phase 1: concurrent stores + counts (no deletes)
        async def _store(i: int):
            mem = _make_memory(100 + i)
            await stress_storage.store_memory(mem)

        async def _count():
            result = await stress_storage.count_memories()
            assert result >= 0, f"count_memories returned negative: {result}"
            return result

        store_tasks = [_store(i) for i in range(15)]
        count_tasks = [_count() for _ in range(10)]
        all_tasks = store_tasks + count_tasks

        results = await asyncio.gather(*all_tasks, return_exceptions=True)

        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"Store+count contention errors: {errors[:5]}"

        # Phase 2: sequential deletes
        for mid in to_delete_ids[:10]:
            await stress_storage.delete_memory(mid)

        # Phase 3: more concurrent counts to ensure consistency after deletes
        count_results = await asyncio.gather(
            *[_count() for _ in range(10)], return_exceptions=True
        )
        count_errors = [r for r in count_results if isinstance(r, Exception)]
        assert len(count_errors) == 0, f"Post-delete count errors: {count_errors[:3]}"

        # Final count: 20 initial - 10 deleted + 15 new = 25
        final_count = await stress_storage.count_memories()
        assert final_count == 25, f"Expected 25, got {final_count}"


# ── Test 12: Rapid sequential session cycling ────────────────────────


class TestSessionCyclingBombardment:
    @pytest.mark.asyncio
    async def test_rapid_sequential_session_cycling(
        self, stress_config: FractalConfig
    ):
        """10 cycles of session_start + store + session_end, all sequential.

        Verifies no leaked state, no stale session references, and all
        memories survive across cycles.
        """
        fm = FractalMemory(
            stress_config,
            llm=_make_mock_llm(),
            embeddings=_make_mock_embeddings(),
        )
        await fm.initialize()

        try:
            for cycle in range(10):
                ctx = await fm.session_start("stress")
                assert ctx is not None

                mem = await fm.store(
                    f"Cycle-{cycle} memory for rapid session cycling test"
                )
                assert mem is not None

                summary = await fm.session_end()
                assert summary is not None

            # Verify memories persisted across cycles.
            # Note: consolidation hooks during session_end may prune some
            # probation memories, so we only require a majority survive.
            stats = await fm.get_stats()
            assert stats["overall"]["total_memories"] >= 5, (
                f"Expected >= 5 memories across 10 cycles (some pruned by "
                f"consolidation), got {stats['overall']['total_memories']}"
            )
            assert stats["overall"]["total_sessions"] >= 10
        finally:
            await fm.close()
