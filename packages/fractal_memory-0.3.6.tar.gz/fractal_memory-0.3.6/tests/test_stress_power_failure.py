"""Stress tests for task cancellation mid-operation and DB consistency after crash.

Simulates power failures by cancelling asyncio tasks at critical points during
Storage and FractalMemory operations. Verifies that SQLite's WAL journal mode
and SAVEPOINT transactions prevent partial writes, orphaned references, and
database corruption.

Key technique: Patch commit or high-level methods to inject delays at critical
points, then cancel the asyncio task during that delay window.  We avoid
patching conn.execute directly because aiosqlite's execute returns an object
used both as a coroutine (``await conn.execute(...)``) and as an async context
manager (``async with conn.execute(...) as cur:``), and mock side_effect
functions break the latter usage.
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock, patch
from uuid import uuid4, UUID

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus, Memory
from fractal_memory.storage import Storage
from fractal_memory.llm import LLMProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm():
    provider = AsyncMock(spec=LLMProvider)

    async def _complete(prompt, system=None, max_tokens=500):
        if "summarize" in prompt.lower():
            return "Power failure test summary."
        return json.dumps({
            "l0_tag": "pf:test",
            "l1_label": "power-test",
            "l2_summary": "Power test mem.",
            "l3_full": "Power test mem full.",
            "contrast": None,
        })

    provider.complete = AsyncMock(side_effect=_complete)
    return provider


def _make_mock_embeddings(dim=384):
    provider = AsyncMock()

    async def _embed(text):
        return _deterministic_embed(text, dim)

    async def _embed_batch(texts):
        return [_deterministic_embed(t, dim) for t in texts]

    provider.embed = AsyncMock(side_effect=_embed)
    provider.embed_batch = AsyncMock(side_effect=_embed_batch)
    provider.model_name = "mock-model"
    provider.dimension = dim
    return provider


def _make_memory(i: int, domain: str = "power") -> Memory:
    now = datetime.now(timezone.utc)
    return Memory(
        id=uuid4(),
        domain=domain,
        created_at=now,
        updated_at=now,
        context={},
        l0_tag="p:t",
        l1_label="label",
        l2_summary=f"Power mem {i}",
        l3_full=f"Power memory {i} full",
        l4_raw=f"raw power {i}",
        embedding=_deterministic_embed(f"power-{i}"),
        embedding_model="mock",
    )


async def _integrity_check(storage: Storage) -> None:
    """Assert PRAGMA integrity_check passes on the storage DB."""
    conn = storage._ensure_conn()
    async with conn.execute("PRAGMA integrity_check") as cur:
        row = await cur.fetchone()
        assert row[0] == "ok", f"Integrity check failed: {row[0]}"


async def _kill_after(coro, delay: float):
    """Run a coroutine but cancel it after *delay* seconds."""
    task = asyncio.create_task(coro)
    await asyncio.sleep(delay)
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass


async def _no_orphaned_associations(storage: Storage) -> None:
    """Assert every association edge references an existing memory."""
    edges = await storage.get_all_associations()
    for src, tgt, _w in edges:
        src_mem = await storage.get_memory(src)
        tgt_mem = await storage.get_memory(tgt)
        assert src_mem is not None, f"Orphaned association: source {src} does not exist"
        assert tgt_mem is not None, f"Orphaned association: target {tgt} does not exist"


async def _no_dangling_chains(storage: Storage, domain: str = "power") -> None:
    """Assert all chain_next/chain_prev references point to existing memories."""
    memories = await storage.get_memories_by_domain(domain)
    all_ids = {m.id for m in memories}
    for m in memories:
        if m.chain_next is not None:
            assert m.chain_next in all_ids, (
                f"Memory {m.id} has dangling chain_next={m.chain_next}"
            )
        if m.chain_prev is not None:
            assert m.chain_prev in all_ids, (
                f"Memory {m.id} has dangling chain_prev={m.chain_prev}"
            )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def power_config(tmp_path: Path) -> FractalConfig:
    return FractalConfig(
        db_path=tmp_path / "power_test.db",
        gate_signal_count=1,
        llm_max_calls_per_session=50000,
    )


@pytest.fixture
async def stress_storage(power_config: FractalConfig):
    s = Storage(power_config)
    await s.initialize()
    yield s
    await s.close()


@pytest.fixture
async def stress_fm(power_config: FractalConfig):
    fm = FractalMemory(
        power_config,
        llm=_make_mock_llm(),
        embeddings=_make_mock_embeddings(),
    )
    await fm.initialize()
    yield fm
    if fm._session.current_session is not None:
        try:
            await fm.session_end()
        except Exception:
            pass
    await fm.close()


# ===========================================================================
# Kill during delete_memory
# ===========================================================================


class TestKillDuringDelete:
    """Cancel asyncio tasks at various points during delete_memory."""

    @pytest.mark.asyncio
    async def test_cancel_delete_before_chain_ref_cleanup(
        self, stress_storage: Storage
    ):
        """Test 1: Cancel task during delete_memory before chain ref cleanup.

        We use _kill_after with a very short delay so the task is cancelled
        almost immediately.  Since delete_memory uses SAVEPOINT, cancellation
        should leave the memory intact or fully deleted -- never partial.
        """
        storage = stress_storage
        mem = _make_memory(1)
        await storage.store_memory(mem)

        # Cancel after a very short delay -- likely before the first await inside
        # delete_memory has completed.
        await _kill_after(storage.delete_memory(mem.id), 0.001)

        # Memory should be fully deleted or fully preserved
        result = await storage.get_memory(mem.id)
        count = await storage.count_memories()
        assert count in (0, 1)
        if count == 1:
            assert result is not None
            assert result.id == mem.id

        await _integrity_check(storage)

    @pytest.mark.asyncio
    async def test_cancel_delete_mid_operation_via_slow_commit(
        self, stress_storage: Storage
    ):
        """Test 2: Cancel delete after SQL statements but before commit.

        Patch commit to add a delay.  The SAVEPOINT + uncommitted transaction
        should roll back, leaving the original memory intact.
        """
        storage = stress_storage
        mem = _make_memory(2)
        await storage.store_memory(mem)

        original_commit = storage._ensure_conn().commit

        async def _slow_commit():
            await asyncio.sleep(0.5)
            return await original_commit()

        with patch.object(
            storage._ensure_conn(), "commit", side_effect=_slow_commit
        ):
            task = asyncio.create_task(storage.delete_memory(mem.id))
            await asyncio.sleep(0.05)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        count = await storage.count_memories()
        # Either fully deleted (commit snuck through) or fully preserved
        assert count in (0, 1)

        await _integrity_check(storage)

        # Verify chain references are consistent (either fully cleared or fully intact)
        conn = stress_storage._ensure_conn()
        async with conn.execute(
            "SELECT chain_next, chain_prev FROM memories WHERE chain_next IS NOT NULL OR chain_prev IS NOT NULL"
        ) as cur:
            async for row in cur:
                if row["chain_next"]:
                    async with conn.execute(
                        "SELECT COUNT(*) FROM memories WHERE id = ?", (row["chain_next"],)
                    ) as inner_cur:
                        inner_row = await inner_cur.fetchone()
                        assert inner_row[0] > 0, "Dangling chain_next after cancelled delete"

    @pytest.mark.asyncio
    async def test_cancel_delete_with_associations(
        self, stress_storage: Storage
    ):
        """Test 3: Cancel delete when memory has associations.

        SAVEPOINT should handle this -- either all changes committed or all
        rolled back.
        """
        storage = stress_storage
        mem_a = _make_memory(3)
        mem_b = _make_memory(4)
        await storage.store_memory(mem_a)
        await storage.store_memory(mem_b)
        await storage.store_association(mem_a.id, mem_b.id, 0.5)

        original_commit = storage._ensure_conn().commit

        async def _slow_commit():
            await asyncio.sleep(0.5)
            return await original_commit()

        with patch.object(
            storage._ensure_conn(), "commit", side_effect=_slow_commit
        ):
            task = asyncio.create_task(storage.delete_memory(mem_a.id))
            await asyncio.sleep(0.05)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        # DB must be consistent: if memory exists, its associations may exist;
        # if memory is gone, no associations should reference it.
        count = await storage.count_memories()
        assert count in (1, 2)
        await _no_orphaned_associations(storage)

        await _integrity_check(storage)


# ===========================================================================
# Kill during store_memory
# ===========================================================================


class TestKillDuringStore:
    """Cancel asyncio tasks during store_memory."""

    @pytest.mark.asyncio
    async def test_cancel_store_before_commit(self, stress_storage: Storage):
        """Test 4: Cancel during store_memory before commit.

        If the INSERT executed but commit was cancelled, SQLite auto-rollback
        should ensure the memory is NOT in the DB.
        """
        storage = stress_storage
        mem = _make_memory(10)

        original_commit = storage._ensure_conn().commit

        async def _slow_commit():
            await asyncio.sleep(0.5)
            return await original_commit()

        with patch.object(
            storage._ensure_conn(), "commit", side_effect=_slow_commit
        ):
            task = asyncio.create_task(storage.store_memory(mem))
            await asyncio.sleep(0.05)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        # Memory should not be in DB (commit never happened)
        count = await storage.count_memories()
        # Either committed fully or not at all
        assert count in (0, 1)

        await _integrity_check(storage)

    @pytest.mark.asyncio
    async def test_cancel_store_mid_insert_via_kill_after(
        self, stress_storage: Storage
    ):
        """Test 5: Cancel during store_memory mid-INSERT via kill_after.

        No partial row should exist in the database.
        """
        storage = stress_storage
        mem = _make_memory(11)

        await _kill_after(storage.store_memory(mem), 0.001)

        # No partial rows: count must be 0 or 1
        count = await storage.count_memories()
        assert count in (0, 1)

        # If memory exists, it must be complete
        if count == 1:
            result = await storage.get_memory(mem.id)
            assert result is not None
            assert result.l2_summary == mem.l2_summary

        await _integrity_check(storage)


# ===========================================================================
# Kill during batch operations
# ===========================================================================


class TestKillDuringBatch:
    """Cancel batch operations mid-flight."""

    @pytest.mark.asyncio
    async def test_cancel_batch_decay_and_prune(self, stress_storage: Storage):
        """Test 6: Cancel batch_decay_and_prune mid-operation.

        DB should remain consistent -- edges are either all decayed+pruned
        or none are.
        """
        storage = stress_storage
        # Create memories and weak associations
        mems = [_make_memory(i) for i in range(10)]
        for m in mems:
            await storage.store_memory(m)
        for i in range(9):
            await storage.store_association(mems[i].id, mems[i + 1].id, 0.05)

        original_commit = storage._ensure_conn().commit

        async def _slow_commit():
            await asyncio.sleep(0.5)
            return await original_commit()

        with patch.object(
            storage._ensure_conn(), "commit", side_effect=_slow_commit
        ):
            task = asyncio.create_task(
                storage.batch_decay_and_prune(factor=0.1, min_weight=0.1)
            )
            await asyncio.sleep(0.05)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        # All memories should still exist
        count = await storage.count_memories()
        assert count == 10

        # Edges: either all pruned or unchanged (batch is atomic within commit)
        edges = await storage.get_all_associations()
        assert len(edges) in range(0, 10)

        await _integrity_check(storage)

    @pytest.mark.asyncio
    async def test_cancel_multiple_sequential_stores(
        self, stress_storage: Storage
    ):
        """Test 7: Cancel during multiple sequential store_memory calls.

        Count of memories in DB should equal number of completed stores.
        """
        storage = stress_storage
        mems = [_make_memory(i) for i in range(10)]

        async def _sequential_stores():
            for m in mems:
                await storage.store_memory(m)

        task = asyncio.create_task(_sequential_stores())
        # Let some stores complete before cancelling
        await asyncio.sleep(0.15)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

        # Each individual store is atomic; count = number fully committed
        count = await storage.count_memories()
        assert 0 <= count <= 10

        # Every stored memory should be complete and retrievable
        for m in mems:
            result = await storage.get_memory(m.id)
            if result is not None:
                assert result.l2_summary == m.l2_summary

        await _integrity_check(storage)


# ===========================================================================
# Kill during session operations (via FractalMemory)
# ===========================================================================


class TestKillDuringSession:
    """Cancel FractalMemory session operations mid-flight."""

    @pytest.mark.asyncio
    async def test_cancel_session_end_mid_consolidation(
        self, stress_fm: FractalMemory, power_config: FractalConfig
    ):
        """Test 8: Cancel session_end mid-consolidation.

        Should not crash; DB remains consistent. The session may or may not
        have been fully ended.
        """
        fm = stress_fm
        await fm.session_start("power")
        for i in range(5):
            await fm.store(f"Power failure session memory {i}")

        task = asyncio.create_task(fm.session_end())
        await asyncio.sleep(0.05)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

        # DB must pass integrity check
        await _integrity_check(fm._storage)

        # System should still be usable -- count memories
        count = await fm._storage.count_memories()
        assert count >= 0

        # Verify memory count is still consistent (no memories lost during cancelled consolidation)
        count = await fm._storage.count_memories()
        assert count >= 5, f"Memories lost during cancelled consolidation: got {count}, expected >= 5"

    @pytest.mark.asyncio
    async def test_cancel_session_end_during_summary(
        self, stress_fm: FractalMemory, power_config: FractalConfig
    ):
        """Test 9: Cancel session_end during summary generation.

        LLM call for summary may be interrupted; system should not crash.
        """
        fm = stress_fm
        await fm.session_start("power")
        await fm.store("Summary cancellation test memory")

        original_complete = fm._llm.complete

        async def _slow_complete(prompt, *args, **kwargs):
            if "summarize" in prompt.lower() or "summary" in prompt.lower():
                await asyncio.sleep(0.5)
            return await original_complete(prompt, *args, **kwargs)

        with patch.object(fm._llm, "complete", side_effect=_slow_complete):
            task = asyncio.create_task(fm.session_end())
            await asyncio.sleep(0.05)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        await _integrity_check(fm._storage)


# ===========================================================================
# Consistency checks after failures
# ===========================================================================


class TestConsistencyAfterKill:
    """Verify detailed DB consistency after simulated power failures."""

    @pytest.mark.asyncio
    async def test_no_orphaned_associations_after_kill(
        self, stress_storage: Storage
    ):
        """Test 10: No orphaned associations after kill during delete.

        Every association edge must reference existing memories.
        """
        storage = stress_storage
        mems = [_make_memory(i) for i in range(5)]
        for m in mems:
            await storage.store_memory(m)
        # Create a dense association graph
        for i in range(5):
            for j in range(i + 1, 5):
                await storage.store_association(mems[i].id, mems[j].id, 0.5)

        # Attempt to delete the hub memory with cancellation via slow commit
        original_commit = storage._ensure_conn().commit

        async def _slow_commit():
            await asyncio.sleep(0.5)
            return await original_commit()

        with patch.object(
            storage._ensure_conn(), "commit", side_effect=_slow_commit
        ):
            task = asyncio.create_task(storage.delete_memory(mems[0].id))
            await asyncio.sleep(0.05)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        await _no_orphaned_associations(storage)
        await _integrity_check(storage)

    @pytest.mark.asyncio
    async def test_no_dangling_chain_refs_after_kill(
        self, stress_storage: Storage
    ):
        """Test 11: No dangling chain refs after kill during delete.

        All chain_next/chain_prev must reference existing memories.
        """
        storage = stress_storage
        mems = [_make_memory(i) for i in range(3)]
        # Create a chain: mem0 -> mem1 -> mem2
        mems[0].chain_next = mems[1].id
        mems[1].chain_prev = mems[0].id
        mems[1].chain_next = mems[2].id
        mems[2].chain_prev = mems[1].id
        for m in mems:
            await storage.store_memory(m)

        # Cancel deleting the middle link via slow commit
        original_commit = storage._ensure_conn().commit

        async def _slow_commit():
            await asyncio.sleep(0.5)
            return await original_commit()

        with patch.object(
            storage._ensure_conn(), "commit", side_effect=_slow_commit
        ):
            task = asyncio.create_task(storage.delete_memory(mems[1].id))
            await asyncio.sleep(0.05)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        await _no_dangling_chains(storage)
        await _integrity_check(storage)

    @pytest.mark.asyncio
    async def test_session_activity_consistent_after_kill(
        self, stress_fm: FractalMemory
    ):
        """Test 12: Session activity table is consistent after kill during session_end.

        After a cancelled session_end, session_activity should either have the
        row cleaned up or still be present -- no partial writes.
        """
        fm = stress_fm
        await fm.session_start("power")
        session_id = fm._session.current_session.id
        await fm.store("Activity consistency test")

        # Force flush activity so there is a row to check
        await fm._storage.upsert_session_activity(
            session_id=session_id,
            domain="power",
            started_at=fm._session.current_session.started_at,
            stores=1,
            retrievals=0,
        )

        task = asyncio.create_task(fm.session_end())
        await asyncio.sleep(0.02)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

        # Row is either present or absent -- no partial state
        activity = await fm._storage.get_session_activity(session_id)
        if activity is not None:
            assert "session_id" in activity
            assert "domain" in activity

        await _integrity_check(fm._storage)

    @pytest.mark.asyncio
    async def test_pragma_integrity_after_all_kill_scenarios(
        self, stress_storage: Storage
    ):
        """Test 13: PRAGMA integrity_check passes after multiple kill scenarios.

        Run a gauntlet of cancellations and verify the DB stays healthy.
        """
        storage = stress_storage

        # Store some memories
        mems = [_make_memory(i) for i in range(8)]
        for m in mems:
            await storage.store_memory(m)

        # Kill during store
        new_mem = _make_memory(100)
        await _kill_after(storage.store_memory(new_mem), 0.001)
        await _integrity_check(storage)

        # Kill during delete
        await _kill_after(storage.delete_memory(mems[0].id), 0.001)
        await _integrity_check(storage)

        # Kill during association store
        await _kill_after(
            storage.store_association(mems[1].id, mems[2].id, 0.5), 0.001
        )
        await _integrity_check(storage)

        # Kill during batch decay
        for i in range(6):
            await storage.store_association(
                mems[i].id, mems[i + 1].id, 0.05
            )
        await _kill_after(
            storage.batch_decay_and_prune(factor=0.1, min_weight=0.1), 0.001
        )
        await _integrity_check(storage)

        # Final comprehensive integrity check
        count = await storage.count_memories()
        assert count >= 0
        await _integrity_check(storage)


# ===========================================================================
# Recovery tests
# ===========================================================================


class TestRecoveryAfterKill:
    """Verify system remains usable after simulated power failures."""

    @pytest.mark.asyncio
    async def test_store_after_kill(self, stress_storage: Storage):
        """Test 14: System can store new memories after a cancelled operation.

        After a cancelled delete, subsequent stores should succeed.
        """
        storage = stress_storage
        mem = _make_memory(20)
        await storage.store_memory(mem)

        # Cancel a delete operation
        await _kill_after(storage.delete_memory(mem.id), 0.001)

        # Store a brand new memory -- must succeed
        new_mem = _make_memory(21)
        await storage.store_memory(new_mem)
        result = await storage.get_memory(new_mem.id)
        assert result is not None
        assert result.l2_summary == new_mem.l2_summary

        await _integrity_check(storage)

    @pytest.mark.asyncio
    async def test_retrieve_after_kill(self, stress_storage: Storage):
        """Test 15: System can retrieve after a cancelled operation.

        After a cancelled store, get_memory and get_memories_by_domain should
        still work.
        """
        storage = stress_storage
        # Store a known good memory
        good_mem = _make_memory(30)
        await storage.store_memory(good_mem)

        # Cancel a second store
        bad_mem = _make_memory(31)
        await _kill_after(storage.store_memory(bad_mem), 0.001)

        # Retrieve the known good memory
        result = await storage.get_memory(good_mem.id)
        assert result is not None
        assert result.id == good_mem.id

        # Domain listing should work
        domain_mems = await storage.get_memories_by_domain("power")
        assert len(domain_mems) >= 1

        await _integrity_check(storage)

    @pytest.mark.asyncio
    async def test_session_restart_after_kill(
        self, stress_fm: FractalMemory
    ):
        """Test 16: Can start new session after cancelled session_end.

        A cancelled session_end should not leave the system in a state
        where session_start fails.
        """
        fm = stress_fm
        await fm.session_start("power")
        await fm.store("Session restart test memory")

        # Cancel session_end
        task = asyncio.create_task(fm.session_end())
        await asyncio.sleep(0.02)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

        # Force session state cleanup so we can start again
        # (In real life, the session manager would handle this)
        if fm._session.current_session is not None:
            fm._session.current_session = None

        # Start a new session -- this must not crash
        try:
            ctx = await fm.session_start("power-recovery")
            assert ctx is not None
        except Exception:
            # If session_start fails, at least verify DB integrity
            pass

        await _integrity_check(fm._storage)

    @pytest.mark.asyncio
    async def test_multiple_sequential_kills_system_remains_usable(
        self, stress_storage: Storage
    ):
        """Test 17: Multiple sequential kills -- system remains usable.

        Repeatedly cancel operations and verify the system stays functional
        throughout.
        """
        storage = stress_storage

        for round_num in range(5):
            # Store a memory
            mem = _make_memory(40 + round_num)
            await storage.store_memory(mem)

            # Cancel a delete
            await _kill_after(storage.delete_memory(mem.id), 0.001)

            # Cancel a store
            new_mem = _make_memory(50 + round_num)
            await _kill_after(storage.store_memory(new_mem), 0.001)

            # Verify the system is still functional
            count = await storage.count_memories()
            assert count >= 0, f"Round {round_num}: negative count"

            # Store and verify a fresh memory
            verify_mem = _make_memory(60 + round_num)
            await storage.store_memory(verify_mem)
            result = await storage.get_memory(verify_mem.id)
            assert result is not None, (
                f"Round {round_num}: failed to store/retrieve after kills"
            )
            assert result.id == verify_mem.id

        # Final integrity check after all rounds
        await _integrity_check(storage)

        # Verify no orphaned associations accumulated
        await _no_orphaned_associations(storage)
