"""Tests for retrieval engine."""

from datetime import datetime
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus, Memory, RetrievalResult
from fractal_memory.retrieval import RetrievalEngine
from fractal_memory.storage import Storage


def _make_memory(domain="test", embedding=None, intensity=0.5, **kwargs) -> Memory:
    if embedding is None:
        rng = np.random.RandomState(hash(str(uuid4())) % 2**31)
        embedding = (rng.randn(384).astype(np.float32) / 10).tolist()
    defaults = dict(
        id=uuid4(),
        domain=domain,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
        context={},
        l0_tag="test:tag",
        l1_label="test-label",
        l2_summary="test summary text here",
        l3_full="test full context text that is a bit longer",
        l4_raw="raw text",
        embedding=embedding,
        embedding_model="test-model",
        intensity=intensity,
    )
    defaults.update(kwargs)
    return Memory(**defaults)


async def test_empty_domain_returns_empty(storage, mock_embeddings, tmp_config):
    engine = RetrievalEngine(storage, mock_embeddings, tmp_config)
    result = await engine.retrieve("test query", "empty_domain")
    assert result.l3_memories == []
    assert result.l2_memories == []
    assert result.l1_memories == []


async def test_basic_retrieval(storage, mock_embeddings, tmp_config):
    engine = RetrievalEngine(storage, mock_embeddings, tmp_config)
    # Store some memories
    for _ in range(5):
        await storage.store_memory(_make_memory())

    result = await engine.retrieve("test query", "test")
    assert len(result.l3_memories) <= tmp_config.top_l3
    assert len(result.l2_memories) <= tmp_config.top_l2
    assert len(result.l1_memories) <= tmp_config.top_l1


async def test_progressive_injection_counts(storage, mock_embeddings):
    config = FractalConfig(
        db_path=storage._db_path,
        gate_signal_count=1,
        top_l1=200,
        top_l2=50,
        top_l3=10,
    )
    engine = RetrievalEngine(storage, mock_embeddings, config)

    # Store 20 memories
    for i in range(20):
        rng = np.random.RandomState(i)
        emb = (rng.randn(384).astype(np.float32)).tolist()
        await storage.store_memory(_make_memory(embedding=emb))

    result = await engine.retrieve("test query", "test")
    assert len(result.l3_memories) == 10
    assert len(result.l2_memories) == 20
    assert len(result.l1_memories) == 20


async def test_domain_filtering(storage, mock_embeddings, tmp_config):
    engine = RetrievalEngine(storage, mock_embeddings, tmp_config)
    await storage.store_memory(_make_memory(domain="alpha"))
    await storage.store_memory(_make_memory(domain="beta"))

    result = await engine.retrieve("test", "alpha")
    for m in result.l3_memories + result.l2_memories + result.l1_memories:
        assert m.domain == "alpha"


async def test_intensity_weighting(storage, mock_embeddings, tmp_config):
    engine = RetrievalEngine(storage, mock_embeddings, tmp_config)
    # Two memories with same embedding but different intensity
    emb = [0.1] * 384
    m_low = _make_memory(embedding=emb, intensity=0.1)
    m_high = _make_memory(embedding=emb, intensity=0.9)
    await storage.store_memory(m_low)
    await storage.store_memory(m_high)

    scored = await engine.score("test", "test")
    # Higher intensity should rank higher when cosine is the same
    assert len(scored) == 2
    if scored[0][0].id == m_high.id:
        assert scored[0][1] >= scored[1][1]


async def test_score_interface(storage, mock_embeddings, tmp_config):
    engine = RetrievalEngine(storage, mock_embeddings, tmp_config)
    await storage.store_memory(_make_memory())
    scored = await engine.score("test", "test")
    assert len(scored) == 1
    mem, score = scored[0]
    assert isinstance(mem, Memory)
    assert isinstance(score, float)


async def test_token_budget_tracking(storage, mock_embeddings, tmp_config):
    engine = RetrievalEngine(storage, mock_embeddings, tmp_config)
    for _ in range(5):
        await storage.store_memory(_make_memory())
    result = await engine.retrieve("test", "test")
    assert result.token_budget_total == tmp_config.memory_token_budget
    assert result.token_budget_used >= 0


async def test_pressure_response_demotes(storage, mock_embeddings):
    """Over-budget retrieval demotes lowest-scored L3 memories."""
    # Use a very tight token budget to trigger pressure
    config = FractalConfig(
        db_path=storage._db_path,
        gate_signal_count=1,
        top_l1=200,
        top_l2=50,
        top_l3=10,
        memory_token_budget_pct=0.0001,  # very tight
        context_window_tokens=100,  # → budget = 0
    )
    engine = RetrievalEngine(storage, mock_embeddings, config)

    for i in range(15):
        rng = np.random.RandomState(i)
        emb = rng.randn(384).astype(np.float32).tolist()
        await storage.store_memory(_make_memory(
            embedding=emb,
            l3_full="A" * 200,  # ~50 tokens each
        ))

    result = await engine.retrieve("test", "test")
    # With budget effectively 0, pressure should demote all L3
    assert len(result.l3_memories) < 10


async def test_near_miss_hints_included(storage, mock_embeddings):
    """Memories just outside top-L1 appear as hints."""
    config = FractalConfig(
        db_path=storage._db_path,
        gate_signal_count=1,
        top_l1=5,
        top_l2=3,
        top_l3=1,
    )
    engine = RetrievalEngine(storage, mock_embeddings, config)

    # Store more than top_l1 memories so there are candidates for hints
    for i in range(30):
        rng = np.random.RandomState(i + 100)
        emb = rng.randn(384).astype(np.float32).tolist()
        await storage.store_memory(_make_memory(embedding=emb))

    result = await engine.retrieve("test", "test")
    # L1 should be capped at 5, and there should be hint candidates
    assert len(result.l1_memories) == 5
    # Hints are memories ranked 6-25 (hint_start=5, hint_end=25)
    # They may or may not pass the min_score threshold, but the mechanism works
    assert isinstance(result.hints, list)


# ---------------------------------------------------------------------------
# Issue #19 / #20: Token budget validation
# ---------------------------------------------------------------------------


async def test_retrieve_token_budget_zero_raises_valueerror(storage, mock_embeddings, tmp_config):
    """token_budget=0 now raises ValueError (must be > 0)."""
    engine = RetrievalEngine(storage, mock_embeddings, tmp_config)
    for _ in range(3):
        await storage.store_memory(_make_memory())
    with pytest.raises(ValueError, match="token_budget must be > 0"):
        await engine.retrieve("test", "test", token_budget=0)


async def test_retrieve_token_budget_none_uses_config_default(storage, mock_embeddings, tmp_config):
    """Issue #19: token_budget=None uses config default."""
    engine = RetrievalEngine(storage, mock_embeddings, tmp_config)
    result = await engine.retrieve("test", "test", token_budget=None)
    assert result.token_budget_total == tmp_config.memory_token_budget


async def test_retrieve_negative_budget_raises_valueerror(storage, mock_embeddings, tmp_config):
    """Negative token_budget raises ValueError."""
    engine = RetrievalEngine(storage, mock_embeddings, tmp_config)
    with pytest.raises(ValueError, match="token_budget must be > 0"):
        await engine.retrieve("test", "test", token_budget=-1)
