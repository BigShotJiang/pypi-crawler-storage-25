"""Schema migration torture tests — stress every upgrade path v1-v7 -> v8,
data preservation across migrations, and corruption/edge-case handling.

Creates databases at each historical schema version with realistic test data,
migrates via Storage.initialize(), and verifies full data integrity.
"""

from __future__ import annotations

import json
import struct
from datetime import datetime, timedelta, timezone
from pathlib import Path
from uuid import uuid4

import aiosqlite
import numpy as np
import pytest

from fractal_memory.config import FractalConfig
from fractal_memory.storage import Storage, _pack_embedding, _unpack_embedding


# ── Helpers ──────────────────────────────────────────────────────────

CURRENT_SCHEMA_VERSION = 8

# All tables expected at v8.
ALL_V8_TABLES = [
    "memories",
    "tasks",
    "waiting_room",
    "sessions",
    "associations",
    "scars",
    "session_summaries",
    "session_activity",
    "maintenance_log",
    "morphogen_history",
    "correction_events",
    "bandit_state",
    "schema_version",
]

# Memory column set expected at v8 (includes 'pinned').
ALL_V8_MEMORY_COLUMNS = {
    "id", "domain", "created_at", "updated_at", "context",
    "l0_tag", "l1_label", "l2_summary", "l3_full", "l4_raw",
    "embedding", "embedding_model", "intensity",
    "retrieval_count", "miss_count", "last_accessed",
    "lifecycle", "chronic_score", "contrast",
    "chain_next", "chain_prev", "vitality",
    "reconsolidation_count", "origin", "trust_score",
    "pinned",
}


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    """Produce a deterministic, content-sensitive embedding."""
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


# ── Version-specific database builders ────────────────────────────────

# Shared test data IDs — stable across helpers so preservation tests
# can locate records after migration.
_MEM_ID = "aaaaaaaa-1111-2222-3333-444444444444"
_SESSION_ID = "bbbbbbbb-1111-2222-3333-444444444444"
_ASSOC_SRC = _MEM_ID
_ASSOC_TGT = "cccccccc-1111-2222-3333-444444444444"
_SCAR_ID = "dddddddd-1111-2222-3333-444444444444"
_SUMMARY_SID = "eeeeeeee-1111-2222-3333-444444444444"


async def _create_v1_database(db_path: Path) -> None:
    """Create a minimal v1 schema database with test data."""
    conn = await aiosqlite.connect(str(db_path))
    conn.row_factory = aiosqlite.Row

    await conn.executescript("""
        CREATE TABLE schema_version (version INTEGER PRIMARY KEY);
        INSERT INTO schema_version (version) VALUES (1);

        CREATE TABLE memories (
            id TEXT PRIMARY KEY, domain TEXT NOT NULL,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL, context TEXT,
            l0_tag TEXT NOT NULL, l1_label TEXT NOT NULL,
            l2_summary TEXT NOT NULL, l3_full TEXT NOT NULL, l4_raw TEXT NOT NULL,
            embedding BLOB NOT NULL, embedding_model TEXT NOT NULL,
            intensity REAL NOT NULL DEFAULT 0.5,
            retrieval_count INTEGER NOT NULL DEFAULT 0,
            miss_count INTEGER NOT NULL DEFAULT 0,
            last_accessed TEXT,
            lifecycle TEXT NOT NULL DEFAULT 'probation',
            chronic_score REAL NOT NULL DEFAULT 0.0,
            contrast TEXT, chain_next TEXT, chain_prev TEXT,
            vitality REAL NOT NULL DEFAULT 1.0,
            reconsolidation_count INTEGER NOT NULL DEFAULT 0,
            origin TEXT NOT NULL DEFAULT 'organic',
            trust_score REAL NOT NULL DEFAULT 1.0
        );

        CREATE TABLE tasks (
            id TEXT PRIMARY KEY, description TEXT NOT NULL,
            created_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active',
            related_memory_ids TEXT, priority INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE waiting_room (
            id TEXT PRIMARY KEY, content TEXT NOT NULL,
            first_signal TEXT, domain TEXT,
            created_at TEXT NOT NULL,
            sessions_elapsed INTEGER NOT NULL DEFAULT 0,
            embedding BLOB
        );

        CREATE TABLE sessions (
            id TEXT PRIMARY KEY, domain TEXT NOT NULL,
            started_at TEXT NOT NULL, ended_at TEXT, summary TEXT
        );

        CREATE TABLE associations (
            source_id TEXT NOT NULL, target_id TEXT NOT NULL,
            weight REAL NOT NULL DEFAULT 0.1,
            created_at TEXT NOT NULL,
            PRIMARY KEY (source_id, target_id)
        );

        CREATE TABLE scars (
            id TEXT PRIMARY KEY,
            pattern TEXT NOT NULL,
            memory_id TEXT,
            reason TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
    """)

    # Insert test memory
    embedding = _pack_embedding(_deterministic_embed("v1 test memory"))
    now = datetime.now(timezone.utc).isoformat()
    await conn.execute(
        """INSERT INTO memories (id, domain, created_at, updated_at, context,
           l0_tag, l1_label, l2_summary, l3_full, l4_raw,
           embedding, embedding_model, intensity, retrieval_count,
           miss_count, lifecycle, chronic_score, vitality,
           reconsolidation_count, origin, trust_score)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (_MEM_ID, "torture-domain", now, now, '{"src":"v1"}',
         "torture:tag", "torture-label", "Torture test summary",
         "Full torture text", "Raw torture data",
         embedding, "mock", 0.75, 5,
         2, "confirmed", 0.3, 0.9,
         1, "organic", 0.95),
    )

    # Insert test session
    await conn.execute(
        "INSERT INTO sessions (id, domain, started_at) VALUES (?,?,?)",
        (_SESSION_ID, "torture-domain", now),
    )

    # Insert test association (v1 format: no trail columns)
    await conn.execute(
        "INSERT INTO associations (source_id, target_id, weight, created_at) VALUES (?,?,?,?)",
        (_ASSOC_SRC, _ASSOC_TGT, 0.42, now),
    )

    # Insert test scar (v1 format: pattern TEXT, no ttl/sessions_elapsed)
    await conn.execute(
        "INSERT INTO scars (id, pattern, memory_id, reason, created_at) VALUES (?,?,?,?,?)",
        (_SCAR_ID, "bad pattern text", _MEM_ID, "was harmful", now),
    )

    await conn.commit()
    await conn.close()


async def _create_v2_database(db_path: Path) -> None:
    """v2: associations + trail columns, scars with pattern_embedding, session_summaries."""
    await _create_v1_database(db_path)
    conn = await aiosqlite.connect(str(db_path))
    conn.row_factory = aiosqlite.Row

    # v1->v2: add trail columns to associations
    await conn.execute(
        "ALTER TABLE associations ADD COLUMN trail_weight REAL NOT NULL DEFAULT 0.0"
    )
    await conn.execute(
        "ALTER TABLE associations ADD COLUMN trail_context_centroid BLOB"
    )

    # Recreate scars with v2 schema (pattern_embedding BLOB)
    await conn.execute("DROP TABLE scars")
    await conn.execute("""CREATE TABLE scars (
        id TEXT PRIMARY KEY, pattern_embedding BLOB NOT NULL,
        memory_id TEXT, reason TEXT NOT NULL,
        created_at TEXT NOT NULL,
        ttl_sessions INTEGER NOT NULL DEFAULT 20,
        sessions_elapsed INTEGER NOT NULL DEFAULT 0
    )""")
    # Re-insert scar with embedding format
    scar_emb = _pack_embedding(_deterministic_embed("scar pattern"))
    now = datetime.now(timezone.utc).isoformat()
    await conn.execute(
        """INSERT INTO scars (id, pattern_embedding, memory_id, reason, created_at,
           ttl_sessions, sessions_elapsed) VALUES (?,?,?,?,?,?,?)""",
        (_SCAR_ID, scar_emb, _MEM_ID, "was harmful", now, 20, 3),
    )

    # session_summaries
    await conn.execute("""CREATE TABLE IF NOT EXISTS session_summaries (
        session_id TEXT PRIMARY KEY, started_at TEXT NOT NULL, ended_at TEXT NOT NULL,
        store_count INTEGER NOT NULL DEFAULT 0, retrieve_count INTEGER NOT NULL DEFAULT 0,
        scar_count INTEGER NOT NULL DEFAULT 0, merge_count INTEGER NOT NULL DEFAULT 0,
        edge_count INTEGER NOT NULL DEFAULT 0
    )""")
    await conn.execute(
        """INSERT INTO session_summaries
           (session_id, started_at, ended_at, store_count, retrieve_count,
            scar_count, merge_count, edge_count)
           VALUES (?,?,?,?,?,?,?,?)""",
        (_SUMMARY_SID, now, now, 10, 5, 1, 2, 3),
    )

    await conn.execute("INSERT OR REPLACE INTO schema_version (version) VALUES (2)")
    await conn.commit()
    await conn.close()


async def _create_v3_database(db_path: Path) -> None:
    """v3: adds session_activity table."""
    await _create_v2_database(db_path)
    conn = await aiosqlite.connect(str(db_path))
    conn.row_factory = aiosqlite.Row

    await conn.execute("""CREATE TABLE IF NOT EXISTS session_activity (
        session_id TEXT PRIMARY KEY, domain TEXT NOT NULL,
        started_at TEXT NOT NULL,
        stores INTEGER NOT NULL DEFAULT 0, retrievals INTEGER NOT NULL DEFAULT 0,
        last_updated TEXT NOT NULL
    )""")
    await conn.execute("INSERT OR REPLACE INTO schema_version (version) VALUES (3)")
    await conn.commit()
    await conn.close()


async def _create_v4_database(db_path: Path) -> None:
    """v4: adds maintenance_log, correction_events, and retrieval_hits column."""
    await _create_v3_database(db_path)
    conn = await aiosqlite.connect(str(db_path))
    conn.row_factory = aiosqlite.Row

    await conn.execute("""CREATE TABLE IF NOT EXISTS maintenance_log (
        tier TEXT PRIMARY KEY, last_run TEXT NOT NULL
    )""")
    await conn.execute("""CREATE TABLE IF NOT EXISTS correction_events (
        id TEXT PRIMARY KEY, occurred_at TEXT NOT NULL,
        memory_id TEXT, original_pattern TEXT,
        correction_text TEXT, scar_id TEXT, session_id TEXT
    )""")
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_correction_events_occurred_at "
        "ON correction_events(occurred_at)"
    )
    await conn.execute("INSERT OR REPLACE INTO schema_version (version) VALUES (4)")
    await conn.commit()
    await conn.close()


async def _create_v5_database(db_path: Path) -> None:
    """v5: adds morphogen_history table."""
    await _create_v4_database(db_path)
    conn = await aiosqlite.connect(str(db_path))
    conn.row_factory = aiosqlite.Row

    await conn.execute("""CREATE TABLE IF NOT EXISTS morphogen_history (
        id TEXT PRIMARY KEY, session_id TEXT NOT NULL,
        morphogens TEXT NOT NULL, created_at TEXT NOT NULL
    )""")
    await conn.execute("INSERT OR REPLACE INTO schema_version (version) VALUES (5)")
    await conn.commit()
    await conn.close()


async def _create_v6_database(db_path: Path) -> None:
    """v6: adds retrieval_hits column on session_summaries."""
    await _create_v5_database(db_path)
    conn = await aiosqlite.connect(str(db_path))
    conn.row_factory = aiosqlite.Row

    await conn.execute(
        "ALTER TABLE session_summaries ADD COLUMN retrieval_hits INTEGER NOT NULL DEFAULT 0"
    )
    await conn.execute("INSERT OR REPLACE INTO schema_version (version) VALUES (6)")
    await conn.commit()
    await conn.close()


async def _create_v7_database(db_path: Path) -> None:
    """v7: adds bandit_state table."""
    await _create_v6_database(db_path)
    conn = await aiosqlite.connect(str(db_path))
    conn.row_factory = aiosqlite.Row

    await conn.execute("""CREATE TABLE IF NOT EXISTS bandit_state (
        id TEXT PRIMARY KEY, state_json TEXT NOT NULL, created_at TEXT NOT NULL
    )""")
    await conn.execute("INSERT OR REPLACE INTO schema_version (version) VALUES (7)")
    await conn.commit()
    await conn.close()


# Map version number to its builder
_VERSION_BUILDERS = {
    1: _create_v1_database,
    2: _create_v2_database,
    3: _create_v3_database,
    4: _create_v4_database,
    5: _create_v5_database,
    6: _create_v6_database,
    7: _create_v7_database,
}


async def _get_table_names(conn: aiosqlite.Connection) -> set[str]:
    """Return the set of user table names in the database."""
    tables: set[str] = set()
    async with conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ) as cur:
        async for row in cur:
            tables.add(row[0])
    return tables


async def _get_column_names(conn: aiosqlite.Connection, table: str) -> set[str]:
    """Return the set of column names for *table*."""
    cols: set[str] = set()
    async with conn.execute(f"PRAGMA table_info({table})") as cur:
        async for row in cur:
            cols.add(row["name"])
    return cols


async def _get_schema_version(conn: aiosqlite.Connection) -> int:
    async with conn.execute("SELECT MAX(version) FROM schema_version") as cur:
        row = await cur.fetchone()
        return row[0] if row and row[0] else 0


# ── Tests ─────────────────────────────────────────────────────────────


class TestParameterizedMigration:
    """Tests 1-7: Migrate from each legacy version (v1..v7) to current v8."""

    @pytest.mark.asyncio
    @pytest.mark.parametrize("source_version", [1, 2, 3, 4, 5, 6, 7])
    async def test_migration_reaches_current_version(
        self, tmp_path: Path, source_version: int
    ):
        """After migrating from v{source_version}, schema_version == current."""
        db_path = tmp_path / f"v{source_version}_to_current.db"
        builder = _VERSION_BUILDERS[source_version]
        await builder(db_path)

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn = s._ensure_conn()
            version = await _get_schema_version(conn)
            assert version >= CURRENT_SCHEMA_VERSION, (
                f"Expected schema version >= {CURRENT_SCHEMA_VERSION} after "
                f"migrating from v{source_version}, got {version}"
            )
        finally:
            await s.close()

    @pytest.mark.asyncio
    @pytest.mark.parametrize("source_version", [1, 2, 3, 4, 5, 6, 7])
    async def test_migration_preserves_memory_data(
        self, tmp_path: Path, source_version: int
    ):
        """Memory rows survive migration from every source version."""
        db_path = tmp_path / f"v{source_version}_mem_data.db"
        builder = _VERSION_BUILDERS[source_version]
        await builder(db_path)

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            count = await s.count_memories()
            assert count == 1, f"Expected 1 memory after v{source_version} migration, got {count}"

            memories = await s.get_recent_memories(limit=1)
            assert len(memories) == 1
            m = memories[0]
            assert m.domain == "torture-domain"
            assert m.l0_tag == "torture:tag"
            assert m.l2_summary == "Torture test summary"
            assert m.intensity == pytest.approx(0.75, abs=1e-6)
            assert m.retrieval_count == 5
        finally:
            await s.close()

    @pytest.mark.asyncio
    @pytest.mark.parametrize("source_version", [1, 2, 3, 4, 5, 6, 7])
    async def test_migration_creates_all_v8_tables(
        self, tmp_path: Path, source_version: int
    ):
        """All v8 tables exist after migrating from each source version."""
        db_path = tmp_path / f"v{source_version}_tables.db"
        builder = _VERSION_BUILDERS[source_version]
        await builder(db_path)

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn = s._ensure_conn()
            tables = await _get_table_names(conn)
            for expected in ALL_V8_TABLES:
                assert expected in tables, (
                    f"Table '{expected}' missing after v{source_version}->v8 migration. "
                    f"Present: {sorted(tables)}"
                )
        finally:
            await s.close()


# ── Data preservation deep checks ────────────────────────────────────


class TestDataPreservation:
    """Tests 8-11: detailed data preservation across migrations."""

    @pytest.mark.asyncio
    async def test_all_memory_fields_preserved(self, tmp_path: Path):
        """Test 8: All 26 memory columns at v8 are accessible after v1->v8 migration."""
        db_path = tmp_path / "fields_preserved.db"
        await _create_v1_database(db_path)

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn = s._ensure_conn()
            # Verify column set
            cols = await _get_column_names(conn, "memories")
            assert cols == ALL_V8_MEMORY_COLUMNS, (
                f"Memory column mismatch.\n"
                f"  Missing: {ALL_V8_MEMORY_COLUMNS - cols}\n"
                f"  Extra:   {cols - ALL_V8_MEMORY_COLUMNS}"
            )

            # Verify the actual row values
            async with conn.execute(
                "SELECT * FROM memories WHERE id = ?", (_MEM_ID,)
            ) as cur:
                row = await cur.fetchone()
            assert row is not None, "Test memory disappeared after migration"
            assert row["domain"] == "torture-domain"
            assert row["l0_tag"] == "torture:tag"
            assert row["l1_label"] == "torture-label"
            assert row["l2_summary"] == "Torture test summary"
            assert row["l3_full"] == "Full torture text"
            assert row["l4_raw"] == "Raw torture data"
            assert row["embedding_model"] == "mock"
            assert abs(row["intensity"] - 0.75) < 1e-6
            assert row["retrieval_count"] == 5
            assert row["miss_count"] == 2
            assert row["lifecycle"] == "confirmed"
            assert abs(row["chronic_score"] - 0.3) < 1e-6
            assert abs(row["vitality"] - 0.9) < 1e-6
            assert row["reconsolidation_count"] == 1
            assert row["origin"] == "organic"
            assert abs(row["trust_score"] - 0.95) < 1e-6
            assert row["pinned"] == 0  # default after migration

            # Embedding round-trip
            emb = _unpack_embedding(row["embedding"])
            expected = _deterministic_embed("v1 test memory")
            assert len(emb) == len(expected)
            for a, b in zip(emb, expected):
                assert abs(a - b) < 1e-5
        finally:
            await s.close()

    @pytest.mark.asyncio
    async def test_associations_preserved_from_v2(self, tmp_path: Path):
        """Test 9: Associations (with trail columns) survive v2->v8 migration."""
        db_path = tmp_path / "assoc_preserved.db"
        await _create_v2_database(db_path)

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn = s._ensure_conn()
            async with conn.execute(
                "SELECT * FROM associations WHERE source_id = ? AND target_id = ?",
                (_ASSOC_SRC, _ASSOC_TGT),
            ) as cur:
                row = await cur.fetchone()
            assert row is not None, "Association row lost after v2->v8 migration"
            assert abs(row["weight"] - 0.42) < 1e-6
            assert abs(row["trail_weight"] - 0.0) < 1e-6

            # Verify trail columns exist
            cols = await _get_column_names(conn, "associations")
            assert "trail_weight" in cols
            assert "trail_context_centroid" in cols
        finally:
            await s.close()

    @pytest.mark.asyncio
    async def test_scars_preserved_from_v2(self, tmp_path: Path):
        """Test 10: Scars (pattern_embedding BLOB format) survive v2->v8 migration."""
        db_path = tmp_path / "scars_preserved.db"
        await _create_v2_database(db_path)

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn = s._ensure_conn()
            async with conn.execute(
                "SELECT * FROM scars WHERE id = ?", (_SCAR_ID,)
            ) as cur:
                row = await cur.fetchone()
            assert row is not None, "Scar lost after v2->v8 migration"
            assert row["reason"] == "was harmful"
            assert row["memory_id"] == _MEM_ID
            assert row["ttl_sessions"] == 20
            assert row["sessions_elapsed"] == 3

            # Verify embedding round-trip
            emb = _unpack_embedding(row["pattern_embedding"])
            expected = _deterministic_embed("scar pattern")
            assert len(emb) == len(expected)
            for a, b in zip(emb, expected):
                assert abs(a - b) < 1e-5
        finally:
            await s.close()

    @pytest.mark.asyncio
    async def test_session_summaries_preserved_with_retrieval_hits(
        self, tmp_path: Path
    ):
        """Test 11: Session summaries survive migration; retrieval_hits added for v4+."""
        db_path = tmp_path / "summaries_preserved.db"
        await _create_v6_database(db_path)  # v6 has retrieval_hits column

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn = s._ensure_conn()

            # Verify summary data
            async with conn.execute(
                "SELECT * FROM session_summaries WHERE session_id = ?",
                (_SUMMARY_SID,),
            ) as cur:
                row = await cur.fetchone()
            assert row is not None, "Session summary lost after migration"
            assert row["store_count"] == 10
            assert row["retrieve_count"] == 5
            assert row["scar_count"] == 1
            assert row["merge_count"] == 2
            assert row["edge_count"] == 3

            # retrieval_hits column should exist (added at v6)
            cols = await _get_column_names(conn, "session_summaries")
            assert "retrieval_hits" in cols
            assert row["retrieval_hits"] == 0  # default
        finally:
            await s.close()


# ── Corruption and edge-case tests ───────────────────────────────────


class TestCorruptionAndEdgeCases:
    """Tests 12-16: missing tables, weird versions, double init, empty DB."""

    @pytest.mark.asyncio
    async def test_missing_schema_version_table(self, tmp_path: Path):
        """Test 12: DB exists but has no schema_version table at all.

        Storage.initialize() runs _SCHEMA_SQL which uses CREATE TABLE IF NOT EXISTS,
        so it will create schema_version and seed version 1, then migrate.
        """
        db_path = tmp_path / "no_schema_table.db"
        # Create a DB with only a memories table (no schema_version)
        conn = await aiosqlite.connect(str(db_path))
        await conn.execute("""CREATE TABLE memories (
            id TEXT PRIMARY KEY, domain TEXT NOT NULL,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL, context TEXT,
            l0_tag TEXT NOT NULL, l1_label TEXT NOT NULL,
            l2_summary TEXT NOT NULL, l3_full TEXT NOT NULL, l4_raw TEXT NOT NULL,
            embedding BLOB NOT NULL, embedding_model TEXT NOT NULL,
            intensity REAL NOT NULL DEFAULT 0.5,
            retrieval_count INTEGER NOT NULL DEFAULT 0,
            miss_count INTEGER NOT NULL DEFAULT 0,
            last_accessed TEXT,
            lifecycle TEXT NOT NULL DEFAULT 'probation',
            chronic_score REAL NOT NULL DEFAULT 0.0,
            contrast TEXT, chain_next TEXT, chain_prev TEXT,
            vitality REAL NOT NULL DEFAULT 1.0,
            reconsolidation_count INTEGER NOT NULL DEFAULT 0,
            origin TEXT NOT NULL DEFAULT 'organic',
            trust_score REAL NOT NULL DEFAULT 1.0
        )""")
        embedding = _pack_embedding(_deterministic_embed("orphan memory"))
        now = datetime.now(timezone.utc).isoformat()
        await conn.execute(
            """INSERT INTO memories (id, domain, created_at, updated_at,
               l0_tag, l1_label, l2_summary, l3_full, l4_raw,
               embedding, embedding_model)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (str(uuid4()), "orphan", now, now,
             "o:tag", "orphan", "summary", "full", "raw",
             embedding, "mock"),
        )
        await conn.commit()
        await conn.close()

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn = s._ensure_conn()
            version = await _get_schema_version(conn)
            assert version >= CURRENT_SCHEMA_VERSION
            count = await s.count_memories()
            assert count == 1, "Memory lost when schema_version table was missing"
        finally:
            await s.close()

    @pytest.mark.asyncio
    async def test_schema_version_zero(self, tmp_path: Path):
        """Test 13: schema_version exists but holds version 0.

        The migration code reads MAX(version); if it sees 0 it treats it as
        needing full migration (< 2, < 3, ... < 8).
        """
        db_path = tmp_path / "version_zero.db"
        await _create_v1_database(db_path)

        # Overwrite the version to 0
        conn = await aiosqlite.connect(str(db_path))
        await conn.execute("DELETE FROM schema_version")
        await conn.execute("INSERT INTO schema_version (version) VALUES (0)")
        await conn.commit()
        await conn.close()

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn_obj = s._ensure_conn()
            version = await _get_schema_version(conn_obj)
            assert version >= CURRENT_SCHEMA_VERSION
            tables = await _get_table_names(conn_obj)
            for t in ALL_V8_TABLES:
                assert t in tables, f"Table '{t}' missing after v0 migration"
        finally:
            await s.close()

    @pytest.mark.asyncio
    async def test_future_version_999_no_crash(self, tmp_path: Path):
        """Test 14: schema_version = 999 (future). Migration should skip gracefully."""
        db_path = tmp_path / "future_v999.db"
        # Build a v7 database (has all tables), then set version to 999
        await _create_v7_database(db_path)
        conn = await aiosqlite.connect(str(db_path))
        await conn.execute("INSERT OR REPLACE INTO schema_version (version) VALUES (999)")
        await conn.commit()
        await conn.close()

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        # Should not raise
        await s.initialize()
        try:
            conn_obj = s._ensure_conn()
            version = await _get_schema_version(conn_obj)
            # Version should still be 999 — migration does not downgrade
            assert version == 999, f"Expected version 999 preserved, got {version}"

            # Data should still be accessible
            count = await s.count_memories()
            assert count == 1
        finally:
            await s.close()

    @pytest.mark.asyncio
    async def test_double_initialize_idempotent(self, tmp_path: Path):
        """Test 15: Calling initialize() twice on the same DB yields identical results."""
        db_path = tmp_path / "double_init.db"
        await _create_v1_database(db_path)

        # First initialization
        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s1 = Storage(cfg)
        await s1.initialize()

        conn1 = s1._ensure_conn()
        v1 = await _get_schema_version(conn1)
        tables1 = await _get_table_names(conn1)
        mem_cols1 = await _get_column_names(conn1, "memories")
        count1 = await s1.count_memories()
        await s1.close()

        # Second initialization on the same DB
        s2 = Storage(cfg)
        await s2.initialize()

        conn2 = s2._ensure_conn()
        v2 = await _get_schema_version(conn2)
        tables2 = await _get_table_names(conn2)
        mem_cols2 = await _get_column_names(conn2, "memories")
        count2 = await s2.count_memories()
        await s2.close()

        assert v1 == v2, f"Schema version changed on second init: {v1} -> {v2}"
        assert tables1 == tables2, "Table set changed on second init"
        assert mem_cols1 == mem_cols2, "Memory columns changed on second init"
        assert count1 == count2, "Memory count changed on second init"

    @pytest.mark.asyncio
    async def test_empty_database_file(self, tmp_path: Path):
        """Test 16: An empty (0-byte) database file. Storage creates schema from scratch."""
        db_path = tmp_path / "empty.db"
        # Create a 0-byte file
        db_path.touch()
        assert db_path.stat().st_size == 0

        cfg = FractalConfig(db_path=db_path, gate_signal_count=1)
        s = Storage(cfg)
        await s.initialize()
        try:
            conn = s._ensure_conn()
            version = await _get_schema_version(conn)
            assert version >= CURRENT_SCHEMA_VERSION

            tables = await _get_table_names(conn)
            for t in ALL_V8_TABLES:
                assert t in tables, f"Table '{t}' missing in fresh-from-empty DB"

            # Should be able to store and retrieve
            count = await s.count_memories()
            assert count == 0

            # Verify fresh DB is usable: store and retrieve a memory
            from fractal_memory.models import Memory
            from datetime import datetime, timezone
            from uuid import uuid4
            import numpy as np

            def _embed(text, dim=384):
                seed = hash(text) % (2**31)
                rng = np.random.RandomState(seed)
                vec = rng.randn(dim).astype(np.float32)
                norm = np.linalg.norm(vec)
                if norm > 0:
                    vec = vec / norm
                return vec.tolist()

            test_mem = Memory(
                id=uuid4(), domain="test", created_at=datetime.now(timezone.utc),
                updated_at=datetime.now(timezone.utc), context={},
                l0_tag="t:t", l1_label="test", l2_summary="test summary",
                l3_full="test full", l4_raw="test raw",
                embedding=_embed("test memory"), embedding_model="mock",
            )
            await s.store_memory(test_mem)
            retrieved = await s.get_memory(test_mem.id)
            assert retrieved is not None, "Fresh DB: stored memory not retrievable"
            assert retrieved.l0_tag == "t:t"
        finally:
            await s.close()
