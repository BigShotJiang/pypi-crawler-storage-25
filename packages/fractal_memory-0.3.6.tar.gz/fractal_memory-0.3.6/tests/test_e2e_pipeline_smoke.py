"""End-to-end pipeline smoke tests — full lifecycle with real wiring."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock
from uuid import uuid4

import numpy as np
import pytest

from fractal_memory import FractalMemory
from fractal_memory.config import FractalConfig
from fractal_memory.models import LifecycleStatus


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = float(np.linalg.norm(vec))
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def _make_mock_llm():
    mock = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        lower = prompt.lower()
        if "summarize" in lower or "summary" in lower:
            return "Session focused on testing. Tests were verified."
        return json.dumps({
            "l0_tag": "test:tag",
            "l1_label": "Test label",
            "l2_summary": "Test summary for the stored memory",
            "l3_full": "Full detailed context for the stored memory entry",
        })
    mock.complete = AsyncMock(side_effect=_complete)
    mock.model_name = "mock-model"
    return mock


def _make_mock_embeddings(dim: int = 384):
    mock = AsyncMock()
    mock.embed = AsyncMock(side_effect=lambda text: _deterministic_embed(text, dim))
    mock.embed_batch = AsyncMock(
        side_effect=lambda texts: [_deterministic_embed(t, dim) for t in texts]
    )
    mock.model_name = "mock-model"
    mock.dimension = dim
    return mock


@pytest.fixture
def config(tmp_path):
    return FractalConfig(
        db_path=tmp_path / "e2e_test.db",
        gate_signal_count=1,
        llm_max_calls_per_session=10000,
        enable_llm_judge=False,
    )


@pytest.fixture
async def fm(config):
    fm = FractalMemory(config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings())
    await fm.initialize()
    yield fm
    await fm.close()


# ---------------------------------------------------------------------------
# Full lifecycle
# ---------------------------------------------------------------------------


class TestFullLifecycle:
    """Complete CRUD and session lifecycle tests."""

    async def test_store_retrieve_delete_cycle(self, fm):
        """Store → retrieve → delete → verify gone."""
        await fm.session_start("test-domain")
        mem = await fm.store("Python is great for APIs")
        assert mem is not None
        assert mem.domain == "test-domain"

        result = await fm.retrieve("what language for APIs?")
        assert isinstance(result.l3_memories, list)

        deleted = await fm.delete(mem.id)
        assert deleted is True

        fetched = await fm.get(mem.id)
        assert fetched is None

    async def test_session_start_end_returns_summary(self, fm):
        """Session start → store → end → verify summary."""
        ctx = await fm.session_start("test-domain")
        assert ctx.session is not None
        assert ctx.session.domain == "test-domain"

        await fm.store("Important decision made")
        summary = await fm.session_end()

        assert summary.memories_stored >= 1
        assert summary.duration_seconds >= 0
        assert summary.summary is not None

    async def test_multiple_stores_and_retrieval(self, fm):
        """Store multiple memories and retrieve."""
        await fm.session_start("test-domain")
        await fm.store("Python is used for backend services")
        await fm.store("TypeScript powers the frontend")
        await fm.store("PostgreSQL is the primary database")

        result = await fm.retrieve("what technologies do we use?")
        # Should find at least some memories
        total = len(result.l3_memories) + len(result.l2_memories) + len(result.l1_memories)
        assert total >= 0  # May or may not match depending on embeddings

    async def test_correction_creates_new_or_updates(self, fm):
        """Correct a memory — should create scar and update/replace."""
        await fm.session_start("test-domain")
        mem = await fm.store("We use MySQL for the database")
        assert mem is not None

        corrected = await fm.correct(mem.id, "Actually we use PostgreSQL, not MySQL")
        assert corrected is not None
        # Correction should have either same ID (partial) or new ID (full replacement)
        assert corrected.id is not None

    async def test_confirm_promotes_lifecycle(self, fm):
        """Confirm a memory — should promote from PROBATION."""
        await fm.session_start("test-domain")
        mem = await fm.store("User prefers dark mode")
        assert mem is not None
        assert mem.lifecycle == LifecycleStatus.PROBATION

        await fm.confirm(mem.id)
        updated = await fm.get(mem.id)
        # Should be CONFIRMED or higher after confirm()
        assert updated is not None
        assert updated.lifecycle in (LifecycleStatus.CONFIRMED, LifecycleStatus.PERMANENT)

    async def test_pin_makes_permanent(self, fm):
        """Pin a memory — should promote to PERMANENT."""
        await fm.session_start("test-domain")
        mem = await fm.store("Critical deployment process")
        assert mem is not None

        await fm.pin(mem.id)
        updated = await fm.get(mem.id)
        assert updated is not None
        assert updated.lifecycle == LifecycleStatus.PERMANENT

    async def test_unpin_reverts_lifecycle(self, fm):
        """Unpin a memory — should revert from PERMANENT."""
        await fm.session_start("test-domain")
        mem = await fm.store("Process to unpin")
        assert mem is not None

        await fm.pin(mem.id)
        await fm.unpin(mem.id)
        updated = await fm.get(mem.id)
        assert updated is not None
        assert updated.lifecycle != LifecycleStatus.PERMANENT

    async def test_mark_critical_sets_safety_lifecycle(self, fm):
        """Mark as safety-critical — should be SAFETY_CRITICAL lifecycle."""
        await fm.session_start("test-domain")
        mem = await fm.store("Never deploy on Fridays")
        assert mem is not None

        await fm.mark_critical(mem.id)
        updated = await fm.get(mem.id)
        assert updated is not None
        assert updated.lifecycle == LifecycleStatus.SAFETY_CRITICAL


# ---------------------------------------------------------------------------
# Domain isolation
# ---------------------------------------------------------------------------


class TestDomainIsolation:
    """Verify domain isolation in the pipeline."""

    async def test_multi_domain_store_retrieve(self, fm):
        """Memories stored in different domains should be isolated."""
        await fm.session_start("domain-a")
        await fm.store("Alpha project uses Rust")
        await fm.session_end()

        await fm.session_start("domain-b")
        await fm.store("Beta project uses Go")

        # Retrieving from domain-b should not return domain-a memories
        result = await fm.retrieve("what language?")
        for mem in result.l3_memories:
            assert mem.domain == "domain-b"

    async def test_session_inherits_domain(self, fm):
        """Stores without explicit domain should inherit session domain."""
        await fm.session_start("my-project")
        mem = await fm.store("Session domain inheritance test")
        assert mem is not None
        assert mem.domain == "my-project"


# ---------------------------------------------------------------------------
# Session bootstrap
# ---------------------------------------------------------------------------


class TestSessionBootstrap:
    """Verify bootstrap context is populated."""

    async def test_bootstrap_includes_summary(self, fm):
        """Second session should have last session's summary."""
        await fm.session_start("test-domain")
        await fm.store("First session memory")
        await fm.session_end()

        ctx = await fm.session_start("test-domain")
        assert ctx.last_summary is not None

    async def test_bootstrap_includes_safety_critical(self, fm):
        """Safety-critical memories should always be in bootstrap."""
        await fm.session_start("test-domain")
        mem = await fm.store("CRITICAL: never delete production data")
        assert mem is not None
        await fm.mark_critical(mem.id)
        await fm.session_end()

        ctx = await fm.session_start("test-domain")
        bootstrap_ids = {m.id for m in ctx.bootstrap_memories}
        assert mem.id in bootstrap_ids


# ---------------------------------------------------------------------------
# Stats and health
# ---------------------------------------------------------------------------


class TestStatsAndHealth:
    """Verify stats and health report after operations."""

    async def test_stats_reflect_operations(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Memory for stats")
        await fm.store("Another memory for stats")

        stats = await fm.get_stats()
        assert stats["overall"]["total_memories"] >= 2

    async def test_health_returns_valid_report(self, fm):
        await fm.session_start("test-domain")
        report = await fm.health()
        assert report is not None
        assert isinstance(report.retrieval_hit_rate, (int, float))
        assert isinstance(report.system_state, str)

    async def test_explain_last_after_retrieval(self, fm):
        await fm.session_start("test-domain")
        await fm.store("Some important fact")
        await fm.retrieve("important")

        explanation = await fm.explain_last()
        assert explanation is not None
        assert explanation.query == "important"
        assert isinstance(explanation.retrieved_memories, list)


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    """Edge cases in the pipeline."""

    async def test_retrieve_with_no_memories(self, fm):
        """Retrieve from empty domain should return empty results."""
        await fm.session_start("empty-domain")
        result = await fm.retrieve("anything")
        assert len(result.l3_memories) == 0

    async def test_store_empty_text_raises(self, fm):
        await fm.session_start("test-domain")
        with pytest.raises(ValueError, match="must not be empty"):
            await fm.store("")

    async def test_store_without_session_raises(self, fm):
        with pytest.raises(RuntimeError, match="No active session"):
            await fm.store("orphan memory")

    async def test_retrieve_without_session_raises(self, fm):
        with pytest.raises(RuntimeError, match="No active session"):
            await fm.retrieve("orphan query")

    async def test_end_without_start_raises(self, fm):
        with pytest.raises(RuntimeError, match="No active session"):
            await fm.session_end()

    async def test_store_invalid_domain_raises(self, fm):
        await fm.session_start("test-domain")
        with pytest.raises(ValueError):
            await fm.store("test", domain="invalid domain with spaces!")

    async def test_store_invalid_intensity_raises(self, fm):
        await fm.session_start("test-domain")
        with pytest.raises(ValueError, match="intensity"):
            await fm.store("test", intensity=1.5)

    async def test_double_session_start_auto_ends(self, fm):
        """Starting a new session while one is active should auto-end the old one."""
        await fm.session_start("domain-1")
        await fm.store("Memory in domain 1")
        # Starting another session should auto-end the first
        ctx2 = await fm.session_start("domain-2")
        assert ctx2.session.domain == "domain-2"

    async def test_correct_nonexistent_returns_none(self, fm):
        await fm.session_start("test-domain")
        result = await fm.correct(uuid4(), "correction for nothing")
        assert result is None

    async def test_delete_nonexistent_returns_false(self, fm):
        result = await fm.delete(uuid4())
        assert result is False

    async def test_context_manager_lifecycle(self, config):
        """async with FractalMemory() should initialize and close."""
        async with FractalMemory(
            config, llm=_make_mock_llm(), embeddings=_make_mock_embeddings()
        ) as fm:
            assert fm._initialized is True
            await fm.session_start("test-domain")
            mem = await fm.store("Context manager test")
            assert mem is not None
        assert fm._initialized is False


# ---------------------------------------------------------------------------
# Task management
# ---------------------------------------------------------------------------


class TestTaskManagement:
    """Verify task CRUD through the facade."""

    async def test_add_and_list_tasks(self, fm):
        task = await fm.add_task("Implement feature X")
        assert task is not None
        assert task.description == "Implement feature X"

        tasks = await fm.list_tasks()
        assert len(tasks) >= 1
        assert any(t.id == task.id for t in tasks)

    async def test_complete_task(self, fm):
        from fractal_memory.models import TaskStatus
        task = await fm.add_task("Task to complete")
        await fm.complete_task(task.id)
        tasks = await fm.list_tasks(TaskStatus.COMPLETED)
        assert any(t.id == task.id for t in tasks)
