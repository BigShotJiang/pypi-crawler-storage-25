"""Static analysis / lint tests — AST-based architectural rule verification."""

from __future__ import annotations

import ast
import inspect
import os
from pathlib import Path

import pytest

# Root of the fractal_memory package
_SRC_ROOT = Path(__file__).resolve().parent.parent / "src" / "fractal_memory"
_ALL_PY_FILES = sorted(_SRC_ROOT.glob("**/*.py"))


def _parse_file(path: Path) -> ast.Module:
    """Parse a Python source file and return the AST."""
    return ast.parse(path.read_text(encoding="utf-8"), filename=str(path))


def _get_source_files(exclude: set[str] | None = None, exclude_dirs: set[str] | None = None) -> list[Path]:
    """Return all .py source files, optionally excluding some by name or parent dir."""
    exclude = exclude or set()
    exclude_dirs = exclude_dirs or set()
    return [
        f for f in _ALL_PY_FILES
        if f.name not in exclude
        and "__pycache__" not in str(f)
        and not any(d in f.parts for d in exclude_dirs)
    ]


# ---------------------------------------------------------------------------
# Bare except detection
# ---------------------------------------------------------------------------


class TestBareExcept:
    """No bare `except:` in source — every except should specify an exception type."""

    def test_no_bare_except_in_source(self):
        violations = []
        for path in _get_source_files():
            tree = _parse_file(path)
            for node in ast.walk(tree):
                if isinstance(node, ast.ExceptHandler) and node.type is None:
                    violations.append(
                        f"{path.relative_to(_SRC_ROOT.parent.parent)}:{node.lineno}"
                    )
        assert not violations, (
            f"Found {len(violations)} bare except clause(s):\n"
            + "\n".join(f"  - {v}" for v in violations)
        )


# ---------------------------------------------------------------------------
# Type hints on public methods
# ---------------------------------------------------------------------------


class TestTypeHints:
    """Public methods on key classes should have return type annotations."""

    def test_fractal_memory_public_methods_have_return_type(self):
        from fractal_memory import FractalMemory

        missing = []
        for name, method in inspect.getmembers(FractalMemory, predicate=inspect.isfunction):
            if name.startswith("_"):
                continue
            sig = inspect.signature(method)
            if sig.return_annotation is inspect.Parameter.empty:
                missing.append(name)
        assert not missing, (
            f"Public methods missing return type annotation:\n"
            + "\n".join(f"  - {m}" for m in missing)
        )


# ---------------------------------------------------------------------------
# No mutable default arguments
# ---------------------------------------------------------------------------


class TestMutableDefaults:
    """No mutable default arguments (def foo(x=[]) anti-pattern)."""

    def test_no_mutable_default_arguments(self):
        violations = []
        for path in _get_source_files():
            tree = _parse_file(path)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    for default in node.args.defaults + node.args.kw_defaults:
                        if default is None:
                            continue
                        if isinstance(default, (ast.List, ast.Dict, ast.Set)):
                            violations.append(
                                f"{path.relative_to(_SRC_ROOT.parent.parent)}:{node.lineno} "
                                f"in {node.name}()"
                            )
        assert not violations, (
            f"Found {len(violations)} mutable default argument(s):\n"
            + "\n".join(f"  - {v}" for v in violations)
        )


# ---------------------------------------------------------------------------
# Config fields have defaults
# ---------------------------------------------------------------------------


class TestConfigDefaults:
    """Every FractalConfig field should have a default value."""

    def test_config_fields_all_have_defaults(self):
        from dataclasses import fields
        from fractal_memory.config import FractalConfig

        missing = []
        for f in fields(FractalConfig):
            if f.default is f.default_factory:
                # Both are MISSING sentinel
                from dataclasses import MISSING
                if f.default is MISSING and f.default_factory is MISSING:
                    missing.append(f.name)
        assert not missing, (
            f"FractalConfig fields without defaults:\n"
            + "\n".join(f"  - {m}" for m in missing)
        )


# ---------------------------------------------------------------------------
# No sync I/O in async functions
# ---------------------------------------------------------------------------


class TestNoSyncIO:
    """Async functions should not call synchronous I/O (open, time.sleep, etc.)."""

    _SYNC_IO_NAMES = {"open", "sleep"}

    def test_no_sync_io_in_async_functions(self):
        violations = []
        # Exclude files where sync I/O is expected or where names alias async equivalents
        exclude = {"config.py", "__init__.py", "storage.py", "embeddings.py", "_compat.py", "llm.py"}
        for path in _get_source_files(exclude=exclude, exclude_dirs={"mcp", "dashboard"}):
            tree = _parse_file(path)
            for node in ast.walk(tree):
                if isinstance(node, ast.AsyncFunctionDef):
                    for child in ast.walk(node):
                        if isinstance(child, ast.Call):
                            func = child.func
                            name = None
                            if isinstance(func, ast.Name):
                                name = func.id
                            elif isinstance(func, ast.Attribute):
                                name = func.attr
                            if name in self._SYNC_IO_NAMES:
                                violations.append(
                                    f"{path.relative_to(_SRC_ROOT.parent.parent)}:{child.lineno} "
                                    f"async {node.name}() calls sync {name}()"
                                )
        assert not violations, (
            f"Found {len(violations)} sync I/O call(s) in async functions:\n"
            + "\n".join(f"  - {v}" for v in violations)
        )


# ---------------------------------------------------------------------------
# Try/except blocks should log
# ---------------------------------------------------------------------------


class TestExceptLogging:
    """Every except block should contain a logger call for observability."""

    def test_all_try_except_blocks_log(self):
        violations = []
        # Some except blocks legitimately don't log (e.g., pass for optional imports)
        exempt_patterns = {"ImportError", "ModuleNotFoundError", "CancelledError"}

        # Exclude MCP/dashboard which use return-error patterns instead of logger
        for path in _get_source_files(exclude_dirs={"mcp", "dashboard"}):
            tree = _parse_file(path)
            for node in ast.walk(tree):
                if isinstance(node, ast.ExceptHandler):
                    # Skip exempt exception types
                    if node.type is not None:
                        exc_name = ""
                        if isinstance(node.type, ast.Name):
                            exc_name = node.type.id
                        elif isinstance(node.type, ast.Attribute):
                            exc_name = node.type.attr
                        if exc_name in exempt_patterns:
                            continue
                    # Check if handler body contains a logger call or 'pass' (single-line)
                    has_log = False
                    is_pass_only = (
                        len(node.body) == 1
                        and isinstance(node.body[0], ast.Pass)
                    )
                    # Check for raise (re-raising is fine)
                    has_raise = any(isinstance(n, ast.Raise) for n in ast.walk(node))
                    # Check for return (return-error pattern is fine)
                    has_return = any(isinstance(n, ast.Return) for n in node.body)
                    if is_pass_only or has_raise or has_return:
                        continue
                    for child in ast.walk(node):
                        if isinstance(child, ast.Call):
                            func = child.func
                            if isinstance(func, ast.Attribute):
                                obj = func.value
                                if isinstance(obj, ast.Name) and obj.id == "logger":
                                    has_log = True
                                    break
                    if not has_log:
                        violations.append(
                            f"{path.relative_to(_SRC_ROOT.parent.parent)}:{node.lineno}"
                        )
        # Allow some violations (sqlite migrations, fallback assignments, etc.)
        MAX_ALLOWED = 15
        assert len(violations) <= MAX_ALLOWED, (
            f"Found {len(violations)} except blocks without logger calls "
            f"(allowed {MAX_ALLOWED}):\n"
            + "\n".join(f"  - {v}" for v in violations)
        )


# ---------------------------------------------------------------------------
# Storage methods use _ensure_conn
# ---------------------------------------------------------------------------


class TestStorageEnsureConn:
    """All async Storage methods that access the DB should call _ensure_conn()."""

    def test_all_storage_methods_use_ensure_conn(self):
        storage_path = _SRC_ROOT / "storage.py"
        tree = _parse_file(storage_path)

        violations = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == "Storage":
                for item in node.body:
                    if isinstance(item, ast.AsyncFunctionDef):
                        if item.name.startswith("_") and item.name not in (
                            "_migrate_phase2_schema",
                            "_migrate_phase3_schema",
                        ):
                            continue
                        # Skip non-DB methods
                        if item.name in ("initialize", "close", "__aenter__", "__aexit__"):
                            continue
                        # Check for _ensure_conn call
                        has_ensure = False
                        for child in ast.walk(item):
                            if isinstance(child, ast.Call):
                                func = child.func
                                if isinstance(func, ast.Attribute) and func.attr == "_ensure_conn":
                                    has_ensure = True
                                    break
                                if isinstance(func, ast.Name) and func.id == "_ensure_conn":
                                    has_ensure = True
                                    break
                        if not has_ensure:
                            violations.append(item.name)
        assert not violations, (
            f"Storage async methods missing _ensure_conn():\n"
            + "\n".join(f"  - {m}" for m in violations)
        )


# ---------------------------------------------------------------------------
# No hardcoded magic numbers
# ---------------------------------------------------------------------------


class TestMagicNumbers:
    """Detect hardcoded numeric literals that should be in config."""

    # Exemptions: 0, 1, 2, -1, 0.0, 1.0, 0.5, 100 are common and safe
    _EXEMPT_NUMBERS = {0, 1, 2, -1, 0.0, 1.0, 0.5, 100, 3, 4, 10, 0.01, 0.1, 2.0}

    def test_no_hardcoded_magic_numbers_in_init(self):
        """Check __init__.py for magic numbers (the main facade)."""
        init_path = _SRC_ROOT / "__init__.py"
        tree = _parse_file(init_path)

        magic_nums = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
                if node.value not in self._EXEMPT_NUMBERS:
                    magic_nums.append(f"line {node.lineno}: {node.value}")

        # Allow some magic numbers (line counts, etc.)
        MAX_ALLOWED = 10
        assert len(magic_nums) <= MAX_ALLOWED, (
            f"Found {len(magic_nums)} magic numbers in __init__.py "
            f"(allowed {MAX_ALLOWED}):\n"
            + "\n".join(f"  - {v}" for v in magic_nums)
        )


# ---------------------------------------------------------------------------
# Session hooks wrapped in try/except
# ---------------------------------------------------------------------------


class TestSessionHookSafety:
    """Session hook runner should catch exceptions from each hook."""

    def test_session_hooks_wrapped_in_try_except(self):
        session_path = _SRC_ROOT / "session.py"
        tree = _parse_file(session_path)

        # Find the _end_locked method and verify it has try/except around hook calls
        for node in ast.walk(tree):
            if isinstance(node, ast.AsyncFunctionDef) and node.name == "_end_locked":
                # Look for a for loop over hooks
                has_hook_loop = False
                loop_has_try = False
                for child in ast.walk(node):
                    if isinstance(child, ast.For):
                        # Check if loop variable relates to hooks
                        for body_item in child.body:
                            if isinstance(body_item, ast.Try):
                                loop_has_try = True
                        has_hook_loop = True
                if has_hook_loop:
                    assert loop_has_try, "Hook loop in _end_locked should have try/except"


# ---------------------------------------------------------------------------
# Import hygiene
# ---------------------------------------------------------------------------


class TestImportHygiene:
    """Check for common import anti-patterns."""

    def test_no_wildcard_imports(self):
        violations = []
        for path in _get_source_files(exclude={"__init__.py"}):
            tree = _parse_file(path)
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom) and any(
                    alias.name == "*" for alias in node.names
                ):
                    violations.append(
                        f"{path.relative_to(_SRC_ROOT.parent.parent)}:{node.lineno}"
                    )
        assert not violations, (
            f"Found {len(violations)} wildcard import(s):\n"
            + "\n".join(f"  - {v}" for v in violations)
        )


# ---------------------------------------------------------------------------
# Async context manager protocol
# ---------------------------------------------------------------------------


class TestAsyncContextManager:
    """FractalMemory should support async context manager protocol."""

    def test_fractal_memory_has_aenter_aexit(self):
        from fractal_memory import FractalMemory

        assert hasattr(FractalMemory, "__aenter__"), "Missing __aenter__"
        assert hasattr(FractalMemory, "__aexit__"), "Missing __aexit__"

    async def test_context_manager_works(self, tmp_path):
        from fractal_memory import FractalMemory
        from fractal_memory.config import FractalConfig

        config = FractalConfig(
            db_path=tmp_path / "ctx_test.db",
            gate_signal_count=1,
        )
        async with FractalMemory(
            config,
            llm=_make_mock_llm(),
            embeddings=_make_mock_embeddings(),
        ) as fm:
            assert fm._initialized is True
        assert fm._initialized is False


def _make_mock_llm():
    from unittest.mock import AsyncMock
    import json
    mock = AsyncMock()
    async def _complete(prompt: str, system: str | None = None, max_tokens: int = 500) -> str:
        return json.dumps({
            "l0_tag": "test:tag", "l1_label": "label",
            "l2_summary": "summary", "l3_full": "full",
        })
    mock.complete = AsyncMock(side_effect=_complete)
    mock.model_name = "mock-model"
    return mock


def _make_mock_embeddings(dim: int = 384):
    from unittest.mock import AsyncMock
    mock = AsyncMock()
    mock.embed = AsyncMock(side_effect=lambda text: _deterministic_embed(text, dim))
    mock.embed_batch = AsyncMock(
        side_effect=lambda texts: [_deterministic_embed(t, dim) for t in texts]
    )
    mock.model_name = "mock-model"
    mock.dimension = dim
    return mock


def _deterministic_embed(text: str, dim: int = 384) -> list[float]:
    import numpy as np
    seed = hash(text) % (2**31)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = float(np.linalg.norm(vec))
    if norm > 0:
        vec = vec / norm
    return vec.tolist()
