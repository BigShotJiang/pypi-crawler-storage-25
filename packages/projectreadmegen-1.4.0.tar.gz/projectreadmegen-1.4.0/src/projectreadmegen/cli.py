# cli.py

import sys
import os
import logging
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from projectreadmegen.scanner import scan_directory, load_config
from projectreadmegen.detector import detect_stack
from projectreadmegen.generator import generate_readme, save_readme
from projectreadmegen.config import PRESETS
from projectreadmegen import grok
from projectreadmegen import usagetracker

logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s: %(message)s"
)
logger = logging.getLogger(__name__)

app = typer.Typer(help="projectreadmegen — Auto-generate README files from folder structure.")


@app.command()
def generate(
    path: str = typer.Argument(".", help="Path to the project directory"),
    template: str | None = typer.Option(None, "--template", "-t",
        help="Template to use: minimal | standard | full | academic"),
    output: str = typer.Option("README.md", "--output", "-o",
        help="Output filename (default: README.md)"),
    no_badges: bool = typer.Option(False, "--no-badges",
        help="Disable badge generation"),
    depth: int = typer.Option(3, "--depth", "-d",
        help="Max folder tree depth (default: 3)"),
    dry_run: bool = typer.Option(False, "--dry-run",
        help="Print README to terminal without saving to file"),
    force: bool = typer.Option(False, "--force", "-f",
        help="Overwrite existing README.md without confirmation"),
    ai: bool = typer.Option(False, "--ai", "--grok",
        help="Use Grok AI to generate enhanced README"),
    auto_ai: bool = typer.Option(False, "--auto-ai",
        help="Auto-detect and use AI when API key is available"),
):
    console = Console()
    root = Path(path).resolve()
    
    if not root.exists():
        console.print(f"[red]Error: Path '{path}' does not exist.[/red]")
        raise typer.Exit(code=1)
    
    if not root.is_dir():
        console.print(f"[red]Error:[/red] '{path}' is not a directory.")
        raise typer.Exit(code=1)
    
    config = load_config(str(root))
    if template:
        config["template"] = template
    if no_badges:
        config["include_badges"] = False
    config["max_tree_depth"] = depth
    
    if ai:
        config["ai_enabled"] = True
    if auto_ai:
        config["ai_enabled"] = True
    
    use_ai = config.get("ai_enabled", False) or auto_ai
    
    if use_ai:
        usagetracker.show_key_setup()
    
    output_path = root / output
    if output_path.exists() and not dry_run and not force:
        overwrite = typer.confirm(f"'{output}' already exists. Overwrite?", default=False)
        if not overwrite:
            console.print("[yellow]Cancelled.[/yellow]")
            raise typer.Exit(code=0)
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
        console=console,
    ) as progress:
        task = progress.add_task("Scanning project...", total=None)
        scan = scan_directory(str(root), max_depth=config["max_tree_depth"])
        
        progress.update(task, description="Detecting stack...")
        detection = detect_stack(scan)
        
        if use_ai:
            allowed, message = usagetracker.check_free_limit()
            
            if not allowed:
                can_continue = usagetracker.handle_exhausted()
                if not can_continue:
                    raise typer.Exit(code=1)
            
            if "Free use" in message:
                console.print(f"[yellow]{message}[/yellow]")
            
            progress.update(task, description="Generating README with Grok AI...")
            try:
                readme = grok.generate_ai_readme(scan, detection, config)
            except Exception as e:
                console.print(f"[yellow]AI generation failed: {e}, falling back to template[/yellow]")
                readme = generate_readme(scan, detection, config)
        else:
            progress.update(task, description="Generating README...")
            readme = generate_readme(scan, detection, config)
    
    if dry_run:
        console.print(Panel(readme, title="[cyan]README Preview[/cyan]", expand=False))
    else:
        save_readme(readme, str(output_path))
        
        credits_msg = usagetracker.get_remaining_credits()
        
        console.print(Panel(
            f"[green]README generated![/green]\n\n"
            f"  Project  : [bold]{scan['name']}[/bold]\n"
            f"  Language : [bold]{detection['primary_lang']}[/bold]\n"
            f"  Type     : [bold]{detection['project_type']}[/bold]\n"
            f"  Template : [bold]{config['template']}[/bold]\n"
            f"  Saved to : [bold]{output_path}[/bold]\n\n"
            f"{credits_msg}",
            title="projectreadmegen",
            border_style="green",
        ))


@app.command()
def interactive(
    path: str = typer.Argument(".", help="Path to the project directory"),
):
    """Interactive mode — answer 5 questions to customize your README."""
    console = Console()
    console.print("[bold cyan]projectreadmegen — Interactive Mode[/bold cyan]\n")
    
    root = Path(path).resolve()
    config = load_config(str(root))
    
    config["author"] = typer.prompt("Your name")
    config["github_username"] = typer.prompt("Your GitHub username")
    config["template"] = typer.prompt(
        "Template [minimal/standard/full/academic]", default="standard"
    )
    include_tree = typer.confirm("Include folder tree in README?", default=True)
    config["include_tree"] = include_tree
    
    scan = scan_directory(str(root), max_depth=config["max_tree_depth"])
    detection = detect_stack(scan)
    readme = generate_readme(scan, detection, config)
    
    output_path = root / config["output_file"]
    save_readme(readme, str(output_path))
    
    console.print(f"\n[green]README saved to {output_path}[/green]")


if __name__ == "__main__":
    app()
