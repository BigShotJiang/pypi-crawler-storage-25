from projectreadmegen.cli import app
app()
