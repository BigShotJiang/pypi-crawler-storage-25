# projectreadmegen

Auto-generate README files from folder structure, with optional AI enhancement using Groq API.

## Installation

```bash
pip install projectreadmegen
```

## Quick Start (Works immediately)

```bash
# Run directly with Python (no PATH setup needed)
python -m projectreadmegen generate .

# Or add to PATH for convenience (run once)
set PATH=%PATH%;%APPDATA%\Python\Python314\Scripts

# Then use simple command
projectreadmegen generate .
```

## AI-Powered README

```bash
# Get free API key at https://console.groq.com/keys
export GROQ_API_KEY=your_key_here

# Generate AI-powered README
python -m projectreadmegen generate . --ai
```

## Options

- `--template, -t`: Template to use (minimal, standard, full, academic)
- `--output, -o`: Output filename (default: README.md)
- `--depth, -d`: Max folder tree depth (default: 3)
- `--ai, --grok`: Use Groq AI to generate enhanced README
- `--auto-ai`: Auto-detect and use AI when API key is available

## Configuration

Create `readmegen.config.json` in your project root:

```json
{
    "template": "standard",
    "ai_enabled": true,
    "groq_api_key": "your_key_here"
}
```

## Features

- Auto-detect project type and tech stack
- Generate folder tree visualization
- AI-powered README generation with Groq
- Multiple template options (minimal, standard, full, academic)
- Badge generation for language and license
