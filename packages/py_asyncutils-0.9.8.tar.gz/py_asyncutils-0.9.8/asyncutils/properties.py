# ty: ignore[unresolved-attribute]
from asyncutils import sync_await
from asyncutils._internal.compat import Placeholder, partial
from asyncutils._internal.helpers import fullname, get_loop_and_set, subscriptable
from asyncutils._internal.submodules import properties_all as __all__
from asyncio.locks import Lock
from weakref import WeakKeyDictionary
@subscriptable
class AsyncProperty:
    __slots__ = '__doc__', '_cls', '_deleted', '_loop', '_name', '_strict', 'fdel', 'fget', 'fset'
    def __new__(cls, fget=None, fset=None, fdel=None, *, doc=None, strict=True):
        if fget is None: return partial(cls, Placeholder, fset, fdel, doc=doc, strict=strict)
        (_ := super().__new__(cls)).fget, _.fset, _.fdel, _.__doc__, _._deleted, _._loop, _._strict = fget, fset, fdel, doc or getattr(fget, '__doc__', None), set(), get_loop_and_set(), strict; return _
    def __get__(self, obj, _=None, /): self._raise_for_unbound(); return self._get_helper(f'asyncutils.properties.AsyncProperty: unreadable attribute: {self._name}') if (f := self.fget) is None else self if obj is None else self._get_helper('asyncutils.properties.AsyncProperty: cannot get deleted attribute') if obj in self._deleted else self._helper(f, obj)
    def __set__(self, obj, val, /):
        self._raise_for_unbound()
        if (f := self.fset) is None: return self._set_helper('asyncutils.properties.AsyncProperty: immutable attribute', val)
        if obj in self._deleted: return self._set_helper('asyncutils.properties.AsyncProperty: cannot set deleted attribute', val)
        self._helper(f, obj, val, c='set')
    def __delete__(self, obj, /):
        self._raise_for_unbound()
        if (f := self.fdel) is None:
            if self._strict: raise AttributeError('asyncutils.properties.AsyncProperty: undeletable attribute', name=self._name)
            return self._deleted.add(obj)
        self._helper(f, obj, c='delete')
    def __set_name__(self, typ, name, /): self._name, self._cls = name, typ
    def __repr__(self): return f'{fullname(self)}({self.fget!r}, {self.fset!r}, {self.fdel!r}, doc={self.__doc__!r}, strict={self._strict})'
    def _raise_for_unbound(self):
        if not all(hasattr(self, _) for _ in ('_name', '_cls')): raise TypeError(f'{self!r} is not bound to a class')
    def _get_helper(self, msg):
        if self._strict: raise AttributeError(msg, name=self._name)
        return self
    def _helper(self, f, *a, c='get'):
        try: return sync_await(f(*a), loop=self._loop)
        except BaseException as e: raise AttributeError(f'failed to {c} attribute {self._name}') from e
    def _set_helper(self, msg, val):
        if self._strict: raise AttributeError(msg, name=self._name)
        type.__setattr__(self._cls, self._name, val)
    def getter(self, fget, /): return type(self)(fget, self.fset, self.fdel, doc=self.__doc__, strict=self._strict)
    def setter(self, fset, /): return type(self)(self.fget, fset, self.fdel, doc=self.__doc__, strict=self._strict)
    def deleter(self, fdel, /): return type(self)(self.fget, self.fset, fdel, doc=self.__doc__, strict=self._strict)
class AsyncLockProperty(AsyncProperty):
    __slots__ = '_cache', '_lock_getter'
    @staticmethod
    def _new_lock(_, *, lock_impl=Lock): return lock_impl()
    def __new__(cls, *a, lock_getter=None, **k):
        if isinstance(_ := super().__new__(cls, *a, **k), cls): _._lock_getter, _._cache = lock_getter or _._new_lock, WeakKeyDictionary()
        return _
    def __repr__(self): return f'{super().__repr__()[:-1]}, lock_getter={self._lock_getter!r})'
    def _helper(self, f, *a, c='get'):
        async def _():
            async with self.get_lock(a[0]): await f(*a)
        return super()._helper(_, c=c)
    def get_lock(self, obj):
        if (r := (c := self._cache).get(obj)) is None: c[obj] = r = self._lock_getter(obj)
        return r
class coercedmethod: # noqa: N801
    __slots__ = '__f', '__n', '__o'
    def __init_subclass__(cls, /, **_): raise TypeError('cannot subclass asyncutils.properties.coercedmethod')
    def __init__(self, f, /): self.__f = f
    def __set_name__(self, typ, name, /): self.__o, self.__n = typ, name
    def __getattr__(self, n, /): return getattr(self.__f, n)
    def __get__(self, obj, typ=None, /):
        if obj is None: raise AttributeError(f'class {fullname(typ)} has no attribute {self.__n!r}', name=self.__n) if typ is self.__o else RuntimeError('incorrectly bound asyncutils.properties.coercedmethod')
        if not (typ is None or isinstance(obj, typ)): raise TypeError('asyncutils.properties.coercedmethod: __get__ called incorrectly')
        return lambda *a, **k: self.__f(obj, *a, **k)