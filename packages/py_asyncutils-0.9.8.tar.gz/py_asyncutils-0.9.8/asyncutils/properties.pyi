'''Asynchronous descriptors, mimicking :class:`property` and optionally applying a lock.'''
from ._internal.types import AsyncLockLike
from _collections_abc import Awaitable, Callable, Hashable
from asyncio.locks import Lock
from typing import Any, Concatenate, Self, final, overload
__all__ = 'AsyncLockProperty', 'AsyncProperty', 'coercedmethod'
class AsyncProperty[T, R]:
    '''A property with asynchronous getters, setters and deleters running synchronously via event loop scheduling.'''
    @overload
    def __new__(cls, *, doc: str|None=..., strict: bool=...) -> Callable[[Callable[[R], Awaitable[T]]], Self]: ...
    @overload
    def __new__(cls, fget: Callable[[R], Awaitable[T]]|None, fset: Callable[[R, T], Awaitable[None]]|None=..., fdel: Callable[[R], Awaitable[None]]|None=..., *, doc: str|None=..., strict: bool=...) -> Self: ...
    @overload
    def __get__(self, instance: R, owner: type[R]|None=..., /) -> Self|T: ...
    @overload
    def __get__(self, instance: None, owner: type, /) -> Self: ...
    def __set__(self, instance: R, value: T, /) -> None: ...
    def __delete__(self, instance: R, /) -> None: ...
    def __set_name__(self, typ: type[R], name: str, /) -> None: ...
    def getter(self, fget: Callable[[R], Awaitable[T]], /) -> Self: '''Return another async property with the given function as the getter.'''
    def setter(self, fset: Callable[[R, T], Awaitable[None]], /) -> Self: '''Return another async property with the given function as the setter.'''
    def deleter(self, fdel: Callable[[R], Awaitable[None]], /) -> Self: '''Return another async property with the given function as the deleter.'''
    @property
    def fget(self) -> Callable[[R], Awaitable[T]]|None: '''The getter function for this property, or `None` if it doesn't exist.'''
    @property
    def fset(self) -> Callable[[R, T], Awaitable[None]]|None: '''The setter function for this property, or `None` if it doesn't exist.'''
    @property
    def fdel(self) -> Callable[[R], Awaitable[None]]|None: '''The deleter function for this property, or `None` if it doesn't exist.'''
class AsyncLockProperty[T, R: Hashable](AsyncProperty[T, R]):
    '''A property that applies an async lock to its getters, setters and deleters.'''
    @overload
    @staticmethod
    def _new_lock[L: AsyncLockLike[Any]](_: R, *, lock_impl: type[L]) -> L: ...
    @overload
    @staticmethod
    def _new_lock(_: R) -> Lock: '''Default way to create a new lock for the given object. The implementation should not cache the locks for each instance, since that is done by this class already.'''
    @overload
    def __new__(cls, *, doc: str|None=..., strict: bool=..., lock_getter: Callable[[R], AsyncLockLike[Any]]|None=...) -> Callable[[Callable[[R], Awaitable[T]]], Self]: ...
    @overload
    def __new__(cls, fget: Callable[[R], Awaitable[T]]|None, fset: Callable[[R, T], Awaitable[None]]|None=..., fdel: Callable[[R], Awaitable[None]]|None=..., *, doc: str|None=..., strict: bool=..., lock_getter: Callable[[R], AsyncLockLike[Any]]|None=...) -> Self: ...
    def get_lock(self, obj: R) -> AsyncLockLike[Any]: '''Get the lock for the given object, applying a cache that unfortunately requires the object to be hashable and weakly referencable.'''
@final
class coercedmethod[T, R, **P]: # noqa: N801
    '''Interpret any callable as a regular function in a class body so that access on instance returns something like a bound method.'''
    def __init__(self, func: Callable[Concatenate[R, P], T], /): ...
    def __getattr__(self, name: str, /) -> Any: ...
    def __set_name__(self, owner: type[R], name: str, /) -> None: ...
    def __get__(self, instance: R, owner: type[R]|None=..., /) -> Callable[P, T]: '''Return the 'bound method'. The descriptor itself is hidden and cannot be accessed on the class it is defined in, only instances of.'''