from asyncutils import coercedmethod, getcontext, ignore_valerrs
from asyncutils._internal.submodules import rwlocks_all as __all__
from _collections import deque
from asyncio.locks import Condition, Lock
from contextlib import asynccontextmanager
from _heapq import heappush, heappop
def _rwlock_sub_new(cls, /): (_ := object.__new__(cls)).setup(); return _
class B:
    __slots__ = '__wrapped__', 'reader', 'reading', 'writer', 'writing'
    def __init__(self, l, f, /, _=__slots__[1:]):
        for s in _: setattr(self, s, getattr(l, s))
        self.__wrapped__ = f
    def __init_subclass__(cls, f=__import__('_operator').methodcaller, /, *, m, **_):
        if getattr(cls, '__slots__', True): raise TypeError('__slots__ must be an empty tuple')
        c = f(m)
        async def g(self, *a, **k):
            async with c(self): return await self.__wrapped__(*a, **k)
        cls.__call__ = g; super().__init_subclass__(**_) # ty: ignore[invalid-assignment]
    def __getattr__(self, n, /): return getattr(self.__wrapped__, n)
t = '', (B,), {'__slots__': ()}
class RWLock:
    reader, writer = (coercedmethod(type(*t, m=m)) for m in ('reading', 'writing')); __slots__ = '_wa', # ty: ignore[no-matching-overload]
    def __new__(cls, /, prefer_writers=None): return _rwlock_sub_new(WritePreferredRWLock if (getcontext().RWLOCK_DEFAULT_PREFER_WRITERS if prefer_writers is None else prefer_writers) else ReadPreferredRWLock)
    def locked(self): return self._wa # ty: ignore[unresolved-attribute]
    def __init_subclass__(cls, /, **_):
        if not isinstance(getattr(cls, '__slots__', None), tuple): raise TypeError('subclass of asyncutils.rwlocks.RWLock must have tuple __slots__')
        if cls.__new__ is __class__.__new__: cls.__new__ = _rwlock_sub_new # ty: ignore[invalid-assignment,unresolved-reference]
        super().__init_subclass__(**_)
class ReadPreferredRWLock(RWLock):
    __slots__ = '_cm', '_readers'
    def setup(self): self._readers, self._cm, self._wa = 0, Lock(), Lock()
    @asynccontextmanager
    async def reading(self):
        async with self._cm:
            if (r := self._readers+1) == 1: await self._wa.acquire()
            self._readers = r
        try: yield
        finally:
            async with self._cm:
                if (r := self._readers-1) == 0: self._wa.release()
                self._readers = r
    @asynccontextmanager
    async def writing(self):
        async with self._wa: yield
    def locked(self): return self._wa.locked()
class WritePreferredRWLock(RWLock):
    __slots__ = '_cond', '_nr', '_nw'
    def setup(self): self._cond, self._wa = Condition(), False; self._nr = self._nw = 0
    @asynccontextmanager
    async def reading(self):
        async with (C := self._cond):
            w = C.wait
            while self._wa or self._nw > 0: await w()
            self._nr += 1
        try: yield
        finally:
            async with C:
                if (r := self._nr-1) == 0: C.notify_all()
                self._nr = r
    @asynccontextmanager
    async def writing(self):
        async with (C := self._cond):
            w = C.wait; self._nw += 1
            while self._wa or self._nr > 0: await w()
            self._nw -= 1; self._wa = True
        try: yield
        finally:
            async with C: self._wa = False; C.notify_all()
class FairRWLock(RWLock):
    __slots__ = '_cond', '_qd', '_readers'
    def setup(self): self._cond, self._wa, self._readers, self._qd = Condition(), False, 0, deque()
    @asynccontextmanager
    async def reading(self):
        async with (C := self._cond):
            (Q := self._qd).append(E := (False, C._get_loop().create_future())) # ty: ignore[unresolved-attribute]
            w = C.wait
            try:
                while True:
                    if Q[0] is not E or self._wa: await w()
                    else: self._readers += 1; Q.popleft(); E[-1].set_result(True); break
            except:
                with ignore_valerrs: Q.remove(E)
                raise
        try: yield
        finally:
            async with C:
                if (r := self._readers-1) == 0: C.notify_all()
                self._readers = r
    @asynccontextmanager
    async def writing(self):
        async with (C := self._cond):
            w = C.wait
            (Q := self._qd).append(E := (True, C._get_loop().create_future())) # ty: ignore[unresolved-attribute]
            try:
                while True:
                    if Q[0] is not E or self._wa or self._readers > 0: await w()
                    else: self._wa = True; Q.popleft(); E[-1].set_result(True); break
            except:
                with ignore_valerrs: Q.remove(E)
                raise
        try: yield
        finally:
            async with C: self._wa = False; C.notify_all()
class PriorityRWLock(RWLock):
    __slots__ = '_cnt', '_cond', '_il', '_qd', '_readers'
    def __new__(cls, /, prefer_writers=None): return _rwlock_sub_new(WritePreferredPriorityRWLock if (getcontext().RWLOCK_DEFAULT_PREFER_WRITERS if prefer_writers is None else prefer_writers) else FairPriorityRWLock)
    def __init_subclass__(cls, /, **_):
        if getattr(cls, '__slots__', None) != (): raise TypeError('__slots__ must be an empty tuple for asyncutils.rwlocks.PriorityRWLock subclass')
        cls.__new__ = _rwlock_sub_new; super().__init_subclass__(**_) # ty: ignore[invalid-assignment]
    def setup(self): self._cond, self._cnt, self._il, self._wa, self._readers, self._qd = Condition(), 0, Lock(), False, 0, []
    async def _push_item(self, priority, is_writer):
        async with self._il: self._cnt = (c := self._cnt)+1
        heappush(self._qd, E := (priority, *((is_writer, c) if isinstance(self, WritePreferredPriorityRWLock) else (c, is_writer)), self._cond._get_loop().create_future())); return E # ty: ignore[unresolved-attribute]
    @asynccontextmanager
    async def reading(self, priority=0):
        async with (C := self._cond):
            E, Q, w = await self._push_item(priority, False), self._qd, C.wait
            try:
                while True:
                    if Q[0] is not E or self._wa: await w()
                    else: self._readers += 1; heappop(Q); E[-1].set_result(True); break
            except:
                with ignore_valerrs: Q.remove(E)
                raise
        try: yield
        finally:
            async with C:
                if (r := self._readers-1) == 0: C.notify_all()
                self._readers = r
    @asynccontextmanager
    async def writing(self, priority=0):
        async with (C := self._cond):
            E, Q, w = await self._push_item(priority, True), self._qd, C.wait
            try:
                while True:
                    if Q[0] is not E or self._wa or self._readers > 0: await w()
                    else: self._wa = True; heappop(Q); E[-1].set_result(True); break
            except:
                with ignore_valerrs: Q.remove(E)
                raise
        try: yield
        finally:
            async with C: self._wa = False; C.notify_all()
class FairPriorityRWLock(PriorityRWLock): __slots__ = ()
class WritePreferredPriorityRWLock(PriorityRWLock): __slots__ = ()
del B, t