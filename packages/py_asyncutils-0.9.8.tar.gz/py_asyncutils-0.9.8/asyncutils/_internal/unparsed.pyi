'''This submodule automatically reads the config from the file whose path is specified by `AUTILSCFGPATH`.

.. important:: Values will be overwritten by command-line arguments when this module runs as a script.'''
from .helpers import Bag
from typing import Any, Final, overload
N: Final[Bag]
'''The frozen part of the configuration as a light namespace-like object.'''
C: Final[dict[str, Any]]
'''The contextual portion of the configuration as a flattened :class:`dict` mapping upper-case keys to values.'''
D: Final[dict[str, str]]
'''A :class:`dict` mapping file extensions to module names for loading config files. Is queried by :func:`tools.loadf`. Stable.'''
c: Final[str]
'''The path to the config file used, or an empty string if no config file was read.'''
@overload
def l(path: int, ext: str, /) -> dict[str, Any]: ...
@overload
def l(path: str, ext: str|None=..., /) -> dict[str, Any]: '''Load a config file from the given string path or file descriptor (in which case the file extension should be passed but leniently defaults to json), from which the file extension and thus appropriate parsing library is determined.'''