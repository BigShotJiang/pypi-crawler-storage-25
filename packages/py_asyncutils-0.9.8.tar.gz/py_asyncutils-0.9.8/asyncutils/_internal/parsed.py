from asyncutils.constants import POSSIBLE_EXECUTORS as C
from asyncutils._internal.compat import j
import argparse as A
i, b, d, e, f, g, J, p = '--', 'store_const', 'executor', 'Equivalent to "-e %s".', 'store_true', 'count', 'ETYP', A.ArgumentParser(prog='asyncutils', description='''A versatile, feature-rich library of async tools integrated into the asyncio framework, aiming to make asynchronous programming easier for everyone.
Has CLI and colored REPL support for quick development.
On both conda and pip as py-asyncutils.''', add_help=False, argument_default=A.SUPPRESS, fromfile_prefix_chars='@', formatter_class=A.RawTextHelpFormatter, epilog='''Use @<filename> to insert command-line arguments from the file of that name at the exact position of this parameter.
The file should have one argument per line; this format differs from that described below.

Use the AUTILSCFGPATH environment variable to specify a path to a file of a supported type containing the default configuration.
A --config option is not offered due to the complexity of implementation and ease to revert to a default config within a one-off config.
See the possible keys in format.json5, which can be accessed using tools.get_cfg_json_format().

Note that the inner workings of this library is tightly coupled with the ever-evolving asyncio framework.
As such, it is probably incompatible with full-fledged third-party async frameworks such as curio, anyio, trio, and tornado.''', **j)
(a := (h := lambda f=p.add_mutually_exclusive_group: f().add_argument)())('-l', '--log-to', nargs='?', const='MAKE', metavar='FILE', help='''This module uses a logger, so that post-mortem debugging can be done by inspecting the log file created.
When FILE, interpreted as a file descriptor if an integer, is passed, the logging output goes to a file with that name.
Passing 'NULL' for FILE is equivalent to specifying the --no-log option.
If FILE is 'MEMORY', logs are stored in memory and returned and voided whenever get_past_logs is called.
If FILE is 'MAKE' or no filename is passed but the option specified, an attempt is made to create a file of format 'asyncutils_log<number>.log' in the
current working directory for logging, for number from 1 to 4096. If you have more than 4096 log files, you should probably clean them up.
Log file rotation is not currently supported.
If FILE is 'STDOUT', log to stdout.
If FILE is 'STDERR', log to stderr. This is also the default behaviour and fallback if the above steps fail.''')
a('-n', '--no-log', action=b, const='NULL', dest='log_to', help='''Disable logging completely.
A disabled logger is still created to make subsequent logging.getLogger calls return it.
Thus, this option cannot avoid the cost of importing logging and instantiating the logger early on.''')
(a := h())('-e', '--executor', choices=C, metavar=J, help='''Choose an executor class to use when necessary depending on the value of ETYP as follows:
thread: Use concurrent.futures.thread.ThreadPoolExecutor. This is the default and will be used if the third-party options are passed but not installed.
The below options are experimental.
process: Use concurrent.futures.process.ProcessPoolExecutor. Use with care, since this depends on CPU architecture.
interpreter: Use concurrent.futures.interpreter.InterpreterPoolExecutor. May throw various errors relating to unshareable objects.
The below options are third-party.
loky_noreuse: Use a new loky.process_executor.ProcessPoolExecutor every time.
loky: Reuse a loky.process_executor.ProcessPoolExecutor if possible.
dask: Use dask.distributed.Client, the API of which just so happens to be a superset of those of concurrent.futures executors.
ipython: Use ipyparallel.ViewExecutor.
elib_flux_cluster: Use executorlib.executor.flux.FluxClusterExecutor.
elib_flux_job: Use executorlib.executor.flux.FluxJobExecutor.
elib_slurm_cluster: Use executorlib.executor.slurm.SlurmClusterExecutor.
elib_slurm_job: Use executorlib.executor.slurm.SlurmJobExecutor.
elib_single_node: Use executorlib.executor.single.SingleNodeExecutor.
pebble_thread: Use pebble.pool.thread.ThreadPool.
pebble_process: Use pebble.pool.process.ProcessPool.
deadpool: Use deadpool.Deadpool.
Note: The executorlib project is Python <3.14 only, meaning the executors extra may not work on higher Python versions, causing installation of the
entire all extra to also fail.
There are some implementations from niche libraries (found on a PyPI-wide search using the keyword "executor") that are intentionally excluded, since
they either require prior configuration to be useful (as is the case with adaptive-executor), are too small (contextvars-executor), unmaintained
(celery-executor), too little-known (sequential-executor), rely on possibly outdated implementation details (bounded-pool-executor), have specific
backends seldom used for this purpose (Flask-Executor) or have completely incompatible APIs (thread-executor). In those cases, pass the fully qualified
name to -c and bear the potential consequences.''')
a('-c', '--custom-executor', dest='executor', metavar=J, help='Use a custom executor not included in the above options by specifying the name of an implementation.\nPassing "package.submodule.Implementation", for example, will execute "from package.submodule import Implementation as Executor".')
for _ in C: a(i+_.replace('_', '-'), action=b, const=_, dest=d, help=e%_)
(a := (h := lambda t, d, f=p.add_argument_group: f(t, d).add_argument)('verbosity', 'Adjust the amount of output of this program.'))('-Q', action=g, default=0, help='Produce less logging output. Additive.')
a('-V', action=g, default=0, help='Produce more logging output. Additive.')
(a := h('repl', 'Configure the behaviour of the Read-Eval-Print Loop of this module.'))('-q', '--quiet', action=f, help='Do not display the banner and exit message in the REPL; the -q flag can be passed to the python command directly to achieve the same effect.')
a('-b', '--basic-repl', action=f, help='Do not use the console with colors and enhanced functionality from _pyrepl. Use only if you have experienced a bug with the colored console.')
a('-m', '--max-memerrs', type=int, metavar='M', help='''The REPL will exit on the M+1-th MemoryError to prevent consuming too many computer resources.
M defaults to 3.
Set to a negative value to disable the threshold completely.''')
(a := h('testing', 'Options to more conveniently test this module.'))('-p', '--load-all', action=f, help='Preload all submodules of this module. Useful for testing, but incurs noticeable performance penalty.')
a('-s', '--seed', help='Seed the random instance used internally by this module with SEED, which will be interpreted as an integer if possible.')
a('-d', '--debug', action=f, help='Enable debug mode to produce more logging output by entering the global debug context manager. Different from -VV, since\nthe verbosity flags take effect again when the context manager is manually exited.')
a('-P', '--pdb', action=f, help='Intended for developers of this library only; open the pdb debugger interface when the exit code of the console is greater than zero,\nor an uncaught error occurs in the console execution logic itself.')
(a := h('metadata', 'Get basic information about this installation of asyncutils.'))('-v', '--version', action='version', version=__import__('asyncutils').__version__.representation, help='Print the current version number of asyncutils, in the form as specified by __version__.representation, and exit.\nUseful for checking if the installation succeeded.')
a('-?', '-h', '--help', action='help', help='Print this help message and exit.')
del a, b, C, d, e, f, g, h, i, j, J, A