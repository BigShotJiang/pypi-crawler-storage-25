import os
import threading
from datetime import datetime
from typing import Optional

from sqlmodel import Session, select

from pixlstash.database import DBPriority
from pixlstash.db_models.import_folder import ImportFolder
from pixlstash.db_models.picture import Picture
from pixlstash.utils.image_processing.image_utils import ImageUtils
from pixlstash.pixl_logging import get_logger
from pixlstash.stacking import (
    assign_picture_to_stack,
    get_or_create_stack_for_picture,
    parse_stack_tags_from_filename,
)
from pixlstash.tasks.base_task import BaseTask


logger = get_logger(__name__)


class WatchFolderImportTask(BaseTask):
    """Task that imports discovered files from watch folders."""

    def __init__(
        self,
        database,
        candidate_files: list[dict],
        total_candidates: int,
        last_checked_updates: Optional[dict[int, float]] = None,
    ):
        super().__init__(
            task_type="WatchFolderImportTask",
            params={
                "candidate_count": len(candidate_files or []),
                "total_candidates": int(total_candidates or 0),
            },
        )
        self._db = database
        self._candidate_files = candidate_files or []
        self._last_checked_updates = {
            int(folder_id): float(last_checked)
            for folder_id, last_checked in (last_checked_updates or {}).items()
        }
        self._total_candidates = int(total_candidates or 0)
        self._processed_count = 0
        self._stop_event = threading.Event()

    def on_cancel(self) -> None:
        self._stop_event.set()

    def _run_task(self):
        new_pictures = []
        stack_assignments = []
        delete_paths = []

        for candidate in self._candidate_files:
            if self._stop_event.is_set():
                logger.debug(
                    "WatchFolderImportTask cancelled, stopping early at task %s",
                    self.id,
                )
                break
            file_path = candidate.get("file_path")
            if not file_path:
                continue

            try:
                pixel_sha = ImageUtils.calculate_hash_from_file_path(file_path)
            except Exception as exc:
                logger.warning("Failed to hash watched file %s: %s", file_path, exc)
                self._processed_count += 1
                continue

            def find_existing(session: Session, hash_value: str):
                return session.exec(
                    select(Picture).where(Picture.pixel_sha == hash_value)
                ).first()

            existing = self._db.run_task(find_existing, pixel_sha)
            if existing:
                logger.debug("Already have picture with sha %s, skipping", pixel_sha)
                self._processed_count += 1
                continue

            try:
                pic = ImageUtils.create_picture_from_file(
                    image_root_path=self._db.image_root,
                    source_file_path=file_path,
                    pixel_sha=pixel_sha,
                )
                pic.imported_at = datetime.now()
                import_source_folder = candidate.get("import_source_folder")
                if isinstance(import_source_folder, str) and import_source_folder:
                    pic.import_source_folder = import_source_folder
                new_pictures.append(pic)

                stack_id, source_id = parse_stack_tags_from_filename(file_path)
                if stack_id or source_id:
                    stack_assignments.append((pic, stack_id, source_id))
                if bool(candidate.get("delete_after_import", False)):
                    delete_paths.append(file_path)
            except Exception as exc:
                logger.warning("Failed to import watched file %s: %s", file_path, exc)
            finally:
                self._processed_count += 1

        changed = []
        imported_ids = []
        if new_pictures:

            def insert_pictures(session: Session, pictures: list[Picture]):
                session.add_all(pictures)
                session.commit()
                for pic in pictures:
                    session.refresh(pic)
                return pictures

            inserted = self._db.run_task(
                insert_pictures,
                new_pictures,
                priority=DBPriority.IMMEDIATE,
            )

            if stack_assignments:

                def apply_stack_assignments(session: Session, assignments: list[tuple]):
                    for pic, stack_id, source_id in assignments:
                        if pic.id is None:
                            continue
                        if stack_id:
                            assign_picture_to_stack(session, pic.id, stack_id)
                            continue
                        if source_id:
                            resolved_stack_id = get_or_create_stack_for_picture(
                                session, source_id
                            )
                            if resolved_stack_id:
                                assign_picture_to_stack(
                                    session,
                                    pic.id,
                                    resolved_stack_id,
                                )

                self._db.run_task(
                    apply_stack_assignments,
                    stack_assignments,
                    priority=DBPriority.IMMEDIATE,
                )

            for pic in inserted or []:
                if getattr(pic, "id", None) is None:
                    continue
                imported_ids.append(pic.id)
                changed.append((Picture, pic.id, "imported_at", pic.imported_at))

            logger.info("Added %d new pictures from watch folders.", len(imported_ids))

            if delete_paths:
                for file_path in delete_paths:
                    try:
                        os.remove(file_path)
                    except Exception as exc:
                        logger.warning(
                            "Failed to delete watched file %s: %s",
                            file_path,
                            exc,
                        )

        if self._last_checked_updates:

            def update_last_checked(session: Session, updates: dict[int, float]):
                folders = session.exec(
                    select(ImportFolder).where(
                        ImportFolder.id.in_(list(updates.keys()))
                    )
                ).all()
                for folder in folders:
                    next_ts = updates.get(int(folder.id))
                    if next_ts is None:
                        continue
                    folder.last_checked = float(next_ts)
                    session.add(folder)
                session.commit()

            self._db.run_task(
                update_last_checked,
                self._last_checked_updates,
                priority=DBPriority.IMMEDIATE,
            )

        return {
            "changed_count": len(changed),
            "changed": changed,
            "imported_picture_ids": imported_ids,
            "candidate_count": self._total_candidates,
        }
