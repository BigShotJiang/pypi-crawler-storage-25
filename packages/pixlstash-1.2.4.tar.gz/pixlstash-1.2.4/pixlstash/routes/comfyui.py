import asyncio
import json
import mimetypes
import os
import random
import threading
import time
import uuid
from copy import deepcopy
from urllib.parse import quote

import requests
import websockets
from fastapi import APIRouter, Body, HTTPException, Request, WebSocket
from fastapi.websockets import WebSocketDisconnect
from sqlmodel import select

from datetime import datetime

from pixlstash.database import DBPriority
from pixlstash.db_models import (
    Character,
    Face,
    Picture,
    PictureProjectMember,
    PictureSetMember,
    PictureStack,
    User,
)
from pixlstash.event_types import EventType
from pixlstash.utils.comfyui_utilities import extract_comfy_workflow_info
from pixlstash.utils.image_processing.image_utils import ImageUtils
from pixlstash.utils.service.path_utils import resolve_path_within
from pixlstash.stacking import (
    build_stack_filename_prefix,
    get_or_create_stack_for_picture,
)
from platformdirs import user_data_dir

from pixlstash.pixl_logging import get_logger

logger = get_logger(__name__)

PLACEHOLDER_IMAGE = "{{image_path}}"
PLACEHOLDER_CAPTION = "{{caption}}"
DEFAULT_COMFYUI_URL = "http://127.0.0.1:8188/"
SEED_FIELDS = {"noise_seed", "seed"}
SEED_NODE_CLASSES = {"RandomNoise", "KSampler", "KSamplerAdvanced"}


def _extract_history_entry(history_payload: dict, prompt_id: str) -> dict:
    if not isinstance(history_payload, dict):
        return {}
    if prompt_id in history_payload and isinstance(history_payload[prompt_id], dict):
        return history_payload[prompt_id]
    if "status" in history_payload or "outputs" in history_payload:
        return history_payload
    return {}


def _extract_text_from_value(value) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (int, float, bool)):
        return str(value)
    if isinstance(value, list):
        for item in value:
            text = _extract_text_from_value(item)
            if text:
                return text
        return ""
    if isinstance(value, dict):
        for key in (
            "exception_message",
            "error",
            "message",
            "details",
            "detail",
            "exception",
            "reason",
            "node_errors",
        ):
            if key in value:
                text = _extract_text_from_value(value.get(key))
                if text:
                    return text
        try:
            return json.dumps(value, ensure_ascii=True)
        except Exception:
            return str(value)
    return str(value)


def _extract_history_status_and_error(
    history_payload: dict, prompt_id: str
) -> tuple[str | None, str | None]:
    entry = _extract_history_entry(history_payload, prompt_id)
    status = entry.get("status") or {}
    status_str = None
    if isinstance(status, dict):
        raw_status = status.get("status_str") or status.get("status")
        if raw_status is not None:
            status_str = str(raw_status).strip().lower() or None

    error_text = ""
    message_items = status.get("messages") if isinstance(status, dict) else None
    if isinstance(message_items, list):
        for item in reversed(message_items):
            event_name = ""
            event_payload = None
            if isinstance(item, (list, tuple)) and item:
                event_name = str(item[0] or "").strip().lower()
                event_payload = item[1] if len(item) > 1 else None
            elif isinstance(item, dict):
                event_name = str(item.get("type") or "").strip().lower()
                event_payload = item
            if event_name in {
                "execution_error",
                "execution_failed",
                "error",
                "execution_interrupted",
            }:
                if status_str is None:
                    status_str = "error"
                error_text = _extract_text_from_value(event_payload)
                if error_text:
                    break

    if not error_text:
        for candidate in (
            entry.get("error"),
            entry.get("exception_message"),
            status.get("error") if isinstance(status, dict) else None,
            status.get("message") if isinstance(status, dict) else None,
            status.get("details") if isinstance(status, dict) else None,
        ):
            error_text = _extract_text_from_value(candidate)
            if error_text:
                break

    return status_str, (error_text or None)


def _workflow_builtin_dir() -> str:
    return os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), "..", "data", "comfyui-workflows", "built-in"
        )
    )


def _workflow_user_dir() -> str:
    return os.path.join(user_data_dir("pixlstash"), "comfyui-workflows", "user")


def _workflow_dirs() -> list[tuple[str, str]]:
    return [
        ("user", _workflow_user_dir()),
        ("built-in", _workflow_builtin_dir()),
    ]


def _resolve_workflow_path(name: str) -> tuple[str | None, str | None]:
    normalized = _normalize_workflow_name(name)
    if not normalized:
        return None, None
    for source, folder in _workflow_dirs():
        try:
            path = resolve_path_within(folder, normalized)
        except ValueError:
            return None, None
        if os.path.isfile(path):
            return path, source
    return None, None


def _normalize_workflow_name(name: str) -> str:
    safe = os.path.basename(name or "").strip()
    if not safe:
        return ""
    if not safe.lower().endswith(".json"):
        safe = f"{safe}.json"
    return safe


def _load_workflow_json(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _save_workflow_json(path: str, payload: dict) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=True)


def _find_placeholder_usage(payload: dict) -> tuple[bool, list[str]]:
    dump = json.dumps(payload, ensure_ascii=False)
    missing = []
    if PLACEHOLDER_IMAGE not in dump:
        missing.append(PLACEHOLDER_IMAGE)
    if PLACEHOLDER_CAPTION not in dump:
        missing.append(PLACEHOLDER_CAPTION)
    is_t2i = PLACEHOLDER_IMAGE in missing
    if is_t2i:
        # t2i workflow: valid when the caption placeholder is present
        valid = PLACEHOLDER_CAPTION not in missing
    else:
        # i2i workflow: valid as long as image placeholder is present;
        # caption is optional (hidden in UI when absent)
        valid = True
    return valid, missing


def _replace_placeholders(value, replacements: dict[str, str]):
    if isinstance(value, str):
        updated = value
        for key, replacement in replacements.items():
            if key in updated:
                updated = updated.replace(key, replacement)
        return updated
    if isinstance(value, list):
        return [_replace_placeholders(item, replacements) for item in value]
    if isinstance(value, dict):
        return {
            key: _replace_placeholders(val, replacements) for key, val in value.items()
        }
    return value


def _randomize_seeds(workflow: dict) -> None:
    """Replace seed values in sampler/noise nodes with a fresh random integer.

    This mirrors what the ComfyUI frontend does when 'randomize' is enabled,
    ensuring repeated runs on the same prompt produce different images.
    """
    for node in workflow.values():
        if not isinstance(node, dict):
            continue
        if node.get("class_type") not in SEED_NODE_CLASSES:
            continue
        inputs = node.get("inputs")
        if not isinstance(inputs, dict):
            continue
        for field in SEED_FIELDS:
            if field in inputs and isinstance(inputs[field], (int, float)):
                inputs[field] = random.randint(0, 2**32 - 1)


def _apply_fixed_seed(workflow: dict, seed: int) -> None:
    """Set seed values in sampler/noise nodes to a specific fixed integer."""
    for node in workflow.values():
        if not isinstance(node, dict):
            continue
        if node.get("class_type") not in SEED_NODE_CLASSES:
            continue
        inputs = node.get("inputs")
        if not isinstance(inputs, dict):
            continue
        for field in SEED_FIELDS:
            if field in inputs and isinstance(inputs[field], (int, float)):
                inputs[field] = seed


def _apply_filename_prefix(workflow: dict, prefix: str) -> bool:
    updated = False
    for node in workflow.values():
        if not isinstance(node, dict):
            continue
        if node.get("class_type") != "SaveImage":
            continue
        inputs = node.get("inputs") or {}
        if not isinstance(inputs, dict):
            inputs = {}
        inputs["filename_prefix"] = prefix
        node["inputs"] = inputs
        updated = True
    return updated


def _upload_image_to_comfyui(base_url: str, file_path: str) -> str:
    mime_type, _ = mimetypes.guess_type(file_path)
    if not mime_type:
        mime_type = "application/octet-stream"
    with open(file_path, "rb") as handle:
        files = {
            "image": (os.path.basename(file_path), handle, mime_type),
        }
        data = {
            "type": "input",
            "overwrite": "true",
        }
        try:
            response = requests.post(
                f"{base_url}/upload/image",
                files=files,
                data=data,
                timeout=30,
            )
        except requests.RequestException as exc:
            logger.warning("ComfyUI upload request failed: %s", exc)
            raise HTTPException(
                status_code=502,
                detail="ComfyUI upload request failed",
            ) from exc
    if response.status_code >= 300:
        detail = (response.text or "").strip()
        logger.warning(
            "ComfyUI upload failed: status=%s detail=%s",
            response.status_code,
            detail,
        )
        raise HTTPException(
            status_code=502,
            detail=f"ComfyUI upload failed: {response.status_code} {detail}",
        )
    try:
        payload = response.json()
    except ValueError as exc:
        detail = (response.text or "").strip()
        logger.warning("ComfyUI upload invalid JSON: %s", detail)
        raise HTTPException(
            status_code=502,
            detail="ComfyUI upload returned invalid JSON",
        ) from exc
    name = payload.get("name") or payload.get("filename")
    if not name:
        raise HTTPException(
            status_code=502, detail="ComfyUI upload response missing name"
        )
    subfolder = payload.get("subfolder") or ""
    if subfolder:
        return f"{subfolder}/{name}"
    return name


def _submit_comfyui_prompt(
    base_url: str,
    workflow: dict,
    client_id: str | None = None,
) -> dict:
    # Strip PixlStash-specific metadata keys before sending to ComfyUI.
    # ComfyUI iterates all top-level entries as nodes and will crash on any
    # non-dict value (e.g. the list stored in "pixlstash_output_nodes").
    clean_workflow = {
        k: v for k, v in workflow.items() if not k.startswith("pixlstash_")
    }
    # Pass the workflow under extra_pnginfo so ComfyUI embeds it in the
    # generated PNG automatically (same as the ComfyUI frontend does).
    payload = {
        "prompt": clean_workflow,
        "extra_data": {
            "extra_pnginfo": {
                "workflow": clean_workflow,
            }
        },
    }
    if client_id:
        payload["client_id"] = client_id
    try:
        response = requests.post(
            f"{base_url}/prompt",
            json=payload,
            timeout=30,
        )
    except requests.RequestException as exc:
        logger.warning("ComfyUI prompt request failed: %s", exc)
        raise HTTPException(
            status_code=502,
            detail="ComfyUI prompt request failed",
        ) from exc
    if response.status_code >= 300:
        detail = (response.text or "").strip()
        logger.warning(
            "ComfyUI prompt failed: status=%s detail=%s",
            response.status_code,
            detail,
        )
        raise HTTPException(
            status_code=502,
            detail=f"ComfyUI prompt failed: {response.status_code} {detail}",
        )
    try:
        return response.json()
    except ValueError as exc:
        detail = (response.text or "").strip()
        logger.warning("ComfyUI prompt invalid JSON: %s", detail)
        raise HTTPException(
            status_code=502,
            detail="ComfyUI prompt returned invalid JSON",
        ) from exc


def _extract_output_node_ids(workflow: dict, payload: dict) -> list[str]:
    nodes = []
    raw_payload_nodes = payload.get("output_node_ids") or payload.get("output_node_id")
    if raw_payload_nodes is not None:
        if isinstance(raw_payload_nodes, list):
            nodes = [str(node) for node in raw_payload_nodes if node is not None]
        else:
            nodes = [str(raw_payload_nodes)]

    workflow_nodes = []
    if isinstance(workflow, dict):
        raw_workflow_nodes = workflow.get("pixlstash_output_nodes")
        if raw_workflow_nodes is None:
            raw_workflow_nodes = workflow.get("pixlstash_output_node")
        if raw_workflow_nodes is not None:
            if isinstance(raw_workflow_nodes, list):
                workflow_nodes = [
                    str(node) for node in raw_workflow_nodes if node is not None
                ]
            else:
                workflow_nodes = [str(raw_workflow_nodes)]

    if nodes:
        return nodes
    if workflow_nodes:
        return workflow_nodes

    save_nodes = []
    for node_id, node in workflow.items():
        if not isinstance(node, dict):
            continue
        if node.get("class_type") == "SaveImage":
            save_nodes.append(str(node_id))
    return save_nodes


def _fetch_comfyui_history(base_url: str, prompt_id: str) -> dict:
    try:
        response = requests.get(
            f"{base_url}/history/{prompt_id}",
            timeout=30,
        )
    except requests.RequestException as exc:
        logger.warning("ComfyUI history request failed: %s", exc)
        raise HTTPException(
            status_code=502,
            detail="ComfyUI history request failed",
        ) from exc
    if response.status_code >= 300:
        detail = (response.text or "").strip()
        logger.warning(
            "ComfyUI history failed: status=%s detail=%s",
            response.status_code,
            detail,
        )
        raise HTTPException(
            status_code=502,
            detail=f"ComfyUI history failed: {response.status_code} {detail}",
        )
    try:
        return response.json()
    except ValueError as exc:
        detail = (response.text or "").strip()
        logger.warning("ComfyUI history invalid JSON: %s", detail)
        raise HTTPException(
            status_code=502,
            detail="ComfyUI history returned invalid JSON",
        ) from exc


def _extract_comfyui_output_images(
    history_payload: dict,
    prompt_id: str,
    output_node_ids: list[str] | None,
) -> list[dict]:
    outputs = {}
    if isinstance(history_payload, dict):
        if "outputs" in history_payload:
            outputs = history_payload.get("outputs") or {}
        elif prompt_id in history_payload:
            outputs = history_payload.get(prompt_id, {}).get("outputs") or {}

    if not isinstance(outputs, dict):
        return []

    node_filter = set(output_node_ids or [])
    images = []
    for node_id, node_payload in outputs.items():
        if node_filter and str(node_id) not in node_filter:
            continue
        if not isinstance(node_payload, dict):
            continue
        for image in node_payload.get("images") or []:
            if not isinstance(image, dict):
                continue
            filename = image.get("filename")
            if not filename:
                continue
            images.append(
                {
                    "filename": filename,
                    "subfolder": image.get("subfolder") or "",
                    "type": image.get("type") or "output",
                }
            )
    return images


def _wait_for_comfyui_outputs(
    base_url: str,
    prompt_id: str,
    output_node_ids: list[str] | None,
    timeout_s: float = 180.0,
    poll_s: float = 1.0,
) -> list[dict]:
    deadline = time.time() + timeout_s
    last_images = []
    while time.time() < deadline:
        history_payload = _fetch_comfyui_history(base_url, prompt_id)
        images = _extract_comfyui_output_images(
            history_payload, prompt_id, output_node_ids
        )
        status_str, error_text = _extract_history_status_and_error(
            history_payload, prompt_id
        )
        if images:
            return images
        if status_str in {"error", "failed", "failure", "interrupted", "cancelled"}:
            raise RuntimeError(error_text or f"ComfyUI status={status_str}")
        if error_text and status_str != "success":
            raise RuntimeError(error_text)
        last_images = images
        time.sleep(poll_s)
    return last_images


def _emit_comfyui_failure_progress(server, prompt_id: str, message: str) -> None:
    try:
        server.vault.notify(
            EventType.PLUGIN_PROGRESS,
            {
                "plugin": "ComfyUI",
                "status": "failed",
                "run_id": f"comfyui-{prompt_id}",
                "message": str(message or "ComfyUI failed"),
                "current": 0,
                "total": 0,
                "progress": 0,
            },
        )
    except Exception as exc:
        logger.debug("Failed to emit ComfyUI failure progress event: %s", exc)


def _download_comfyui_image(base_url: str, entry: dict) -> tuple[bytes, str]:
    filename = entry.get("filename")
    subfolder = entry.get("subfolder") or ""
    file_type = entry.get("type") or "output"
    params = {
        "filename": filename,
        "subfolder": subfolder,
        "type": file_type,
    }
    try:
        response = requests.get(
            f"{base_url}/view",
            params=params,
            timeout=30,
        )
    except requests.RequestException as exc:
        logger.warning("ComfyUI image fetch failed: %s", exc)
        raise HTTPException(
            status_code=502,
            detail="ComfyUI image fetch failed",
        ) from exc
    if response.status_code >= 300:
        detail = (response.text or "").strip()
        logger.warning(
            "ComfyUI image fetch failed: status=%s detail=%s",
            response.status_code,
            detail,
        )
        raise HTTPException(
            status_code=502,
            detail=f"ComfyUI image fetch failed: {response.status_code} {detail}",
        )
    ext = os.path.splitext(filename or "")[1].lower() or ".png"
    return response.content, ext


def _unique_edit_filename(output_dir: str, stem: str, ext: str) -> str:
    """Return ``{stem}_edit{n}{ext}`` with the first n >= 1 that is unused in output_dir."""
    n = 1
    while True:
        candidate = f"{stem}_edit{n}{ext}"
        if not os.path.exists(os.path.join(output_dir, candidate)):
            return candidate
        n += 1


def _import_comfyui_outputs(
    server,
    image_entries: list[tuple[bytes, str]],
    output_dir: str | None = None,
    reference_folder_id: int | None = None,
    source_file_stem: str | None = None,
) -> tuple[list[int], list[int]]:
    if not image_entries:
        return [], []

    shas = [
        ImageUtils.calculate_hash_from_bytes(img_bytes)
        for img_bytes, _ in image_entries
    ]

    existing_pictures = server.vault.db.run_immediate_read_task(
        lambda session: Picture.find(session, pixel_shas=shas, include_unimported=True)
    )
    existing_map = {pic.pixel_sha: pic for pic in existing_pictures}

    new_entries = [
        (entry, sha)
        for entry, sha in zip(image_entries, shas)
        if sha not in existing_map
    ]

    new_pictures = []
    for (img_bytes, ext), sha in new_entries:
        if output_dir and source_file_stem:
            pic_uuid = _unique_edit_filename(output_dir, source_file_stem, ext)
        else:
            pic_uuid = f"{uuid.uuid4()}{ext}"
        new_pictures.append(
            ImageUtils.create_picture_from_bytes(
                image_root_path=server.vault.image_root,
                image_bytes=img_bytes,
                picture_uuid=pic_uuid,
                pixel_sha=sha,
                output_dir=output_dir,
                reference_folder_id=reference_folder_id,
            )
        )

    def import_task(session):
        if new_pictures:
            session.add_all(new_pictures)
            session.commit()
            for pic in new_pictures:
                session.refresh(pic)
        return new_pictures

    if new_pictures:
        new_pictures = server.vault.db.run_task(import_task)

        def mark_imported(session, ids: list[int]):
            if not ids:
                return []
            now = datetime.utcnow()
            pics = session.exec(select(Picture).where(Picture.id.in_(ids))).all()
            updated = []
            for pic in pics:
                if pic.imported_at is None:
                    pic.imported_at = now
                    session.add(pic)
                    updated.append(pic.id)
            session.commit()
            return updated

        server.vault.db.run_task(mark_imported, [pic.id for pic in new_pictures])

    new_ids = [pic.id for pic in new_pictures if pic.id is not None]
    duplicate_ids = [
        pic.id
        for sha in shas
        if (pic := existing_map.get(sha)) is not None and pic.id is not None
    ]
    return new_ids, duplicate_ids


def _assign_outputs_to_stack_top(
    server,
    stack_id: int,
    picture_ids: list[int],
) -> None:
    if not stack_id or not picture_ids:
        return

    def update_stack(session):
        stack = session.get(PictureStack, stack_id)
        if stack is None:
            return
        pics = session.exec(select(Picture).where(Picture.stack_id == stack_id)).all()
        has_positions = any(pic.stack_position is not None for pic in pics)
        shift = len(picture_ids)
        if has_positions and shift:
            for pic in pics:
                if pic.id in picture_ids:
                    continue
                if pic.stack_position is not None:
                    pic.stack_position += shift
                    session.add(pic)

        for idx, pic_id in enumerate(picture_ids):
            pic = session.get(Picture, pic_id)
            if pic is None:
                continue
            pic.stack_id = stack_id
            pic.stack_position = idx
            session.add(pic)

        stack.updated_at = datetime.utcnow()
        session.add(stack)
        session.commit()

    server.vault.db.run_task(update_stack)


def _copy_face_assignments(
    server,
    source_picture_id: int | None,
    target_picture_ids: list[int],
) -> None:
    if not source_picture_id or not target_picture_ids:
        return

    def copy_task(session):
        source_faces = session.exec(
            select(Face).where(Face.picture_id == source_picture_id)
        ).all()
        if not source_faces:
            return 0
        target_ids = [pid for pid in target_picture_ids if pid is not None]
        if not target_ids:
            return 0
        existing_targets = session.exec(
            select(Face.picture_id).where(Face.picture_id.in_(target_ids))
        ).all()
        skip_ids = set(existing_targets)
        new_faces = []
        for target_id in target_ids:
            if target_id in skip_ids:
                continue
            for face in source_faces:
                new_faces.append(
                    Face(
                        picture_id=target_id,
                        frame_index=face.frame_index,
                        face_index=face.face_index,
                        character_id=face.character_id,
                        bbox=face.bbox,
                    )
                )
        if new_faces:
            session.add_all(new_faces)
            session.commit()
        return len(new_faces)

    copied = server.vault.db.run_task(copy_task)
    if copied:
        logger.info(
            "Copied %s face assignments to %s picture(s) from %s",
            copied,
            len(target_picture_ids),
            source_picture_id,
        )


def _copy_set_and_project_assignments(
    server,
    source_picture_id: int | None,
    target_picture_ids: list[int],
) -> None:
    if not source_picture_id or not target_picture_ids:
        return

    def copy_task(session):
        source_set_ids = [
            row.set_id
            for row in session.exec(
                select(PictureSetMember).where(
                    PictureSetMember.picture_id == source_picture_id
                )
            ).all()
        ]
        source_project_ids = [
            row.project_id
            for row in session.exec(
                select(PictureProjectMember).where(
                    PictureProjectMember.picture_id == source_picture_id
                )
            ).all()
        ]
        if not source_set_ids and not source_project_ids:
            return 0

        new_set_members = []
        new_project_members = []
        for target_id in target_picture_ids:
            existing_sets = {
                row.set_id
                for row in session.exec(
                    select(PictureSetMember).where(
                        PictureSetMember.picture_id == target_id
                    )
                ).all()
            }
            for set_id in source_set_ids:
                if set_id not in existing_sets:
                    new_set_members.append(
                        PictureSetMember(set_id=set_id, picture_id=target_id)
                    )
            existing_projects = {
                row.project_id
                for row in session.exec(
                    select(PictureProjectMember).where(
                        PictureProjectMember.picture_id == target_id
                    )
                ).all()
            }
            for project_id in source_project_ids:
                if project_id not in existing_projects:
                    new_project_members.append(
                        PictureProjectMember(
                            project_id=project_id, picture_id=target_id
                        )
                    )

        if new_set_members:
            session.add_all(new_set_members)
        if new_project_members:
            session.add_all(new_project_members)
        if new_set_members or new_project_members:
            session.commit()
        return len(new_set_members) + len(new_project_members)

    total = server.vault.db.run_task(copy_task)
    if total:
        logger.info(
            "Copied set/project assignments (%s entries) to %s picture(s) from %s",
            total,
            len(target_picture_ids),
            source_picture_id,
        )


def _assign_pictures_to_view_context(
    server,
    new_ids: list[int],
    set_id: int | None,
    project_id: int | None,
    character_id: int | None,
) -> None:
    """Assign newly generated pictures directly to the current view context.

    Called for T2I outputs when the user is browsing a specific set, project,
    or character.  Unlike _copy_set_and_project_assignments this works without
    a source picture to copy from.
    """
    if not new_ids:
        return
    if not any([set_id, project_id, character_id]):
        return

    def assign(session):
        # Resolve character → reference set so the picture appears in the
        # character view as well as the regular set view.
        effective_set_ids = [s for s in [set_id] if s is not None]
        if character_id is not None:
            char = session.get(Character, character_id)
            if char and char.reference_picture_set_id:
                ref_sid = char.reference_picture_set_id
                if ref_sid not in effective_set_ids:
                    effective_set_ids.append(ref_sid)

        for pic_id in new_ids:
            existing_sets = {
                row.set_id
                for row in session.exec(
                    select(PictureSetMember).where(
                        PictureSetMember.picture_id == pic_id
                    )
                ).all()
            }
            for sid in effective_set_ids:
                if sid not in existing_sets:
                    session.add(PictureSetMember(set_id=sid, picture_id=pic_id))

            if project_id is not None:
                existing_projects = {
                    row.project_id
                    for row in session.exec(
                        select(PictureProjectMember).where(
                            PictureProjectMember.picture_id == pic_id
                        )
                    ).all()
                }
                if project_id not in existing_projects:
                    session.add(
                        PictureProjectMember(project_id=project_id, picture_id=pic_id)
                    )
        session.commit()

    server.vault.db.run_task(assign)
    logger.info(
        "Assigned %s T2I picture(s) to view context (set=%s, project=%s, character=%s)",
        len(new_ids),
        set_id,
        project_id,
        character_id,
    )


def _set_source_picture_id_on_pictures(
    server,
    source_picture_id: int | None,
    target_picture_ids: list[int],
) -> None:
    if not source_picture_id or not target_picture_ids:
        return

    def update(session):
        for pid in target_picture_ids:
            pic = session.get(Picture, pid)
            if pic is not None:
                pic.source_picture_id = source_picture_id
                session.add(pic)
        session.commit()

    server.vault.db.run_task(update)


def _process_comfyui_outputs(
    server,
    base_url: str,
    prompt_id: str,
    output_node_ids: list[str] | None,
    stack_id: int | None,
    source_picture_id: int | None,
    view_context: dict | None = None,
) -> None:
    try:
        images = _wait_for_comfyui_outputs(base_url, prompt_id, output_node_ids)
        if not images:
            logger.warning("ComfyUI produced no outputs for prompt %s", prompt_id)
            _emit_comfyui_failure_progress(
                server,
                prompt_id,
                "ComfyUI finished without outputs.",
            )
            return
        entries = []
        for entry in images:
            img_bytes, ext = _download_comfyui_image(base_url, entry)
            if img_bytes:
                entries.append((img_bytes, ext))

        output_dir: str | None = None
        ref_folder_id: int | None = None
        source_file_stem: str | None = None
        if source_picture_id is not None:
            src_pic = server.vault.db.run_immediate_read_task(
                lambda session: session.get(Picture, source_picture_id)
            )
            if (
                src_pic is not None
                and src_pic.reference_folder_id is not None
                and src_pic.file_path
                and os.path.isabs(src_pic.file_path)
            ):
                output_dir = os.path.dirname(src_pic.file_path)
                ref_folder_id = src_pic.reference_folder_id
                raw = src_pic.original_file_name or os.path.basename(src_pic.file_path)
                source_file_stem = os.path.splitext(raw)[0] if raw else None

        new_ids, duplicate_ids = _import_comfyui_outputs(
            server,
            entries,
            output_dir=output_dir,
            reference_folder_id=ref_folder_id,
            source_file_stem=source_file_stem,
        )
        all_ids = [pid for pid in new_ids + duplicate_ids if pid is not None]
        if stack_id and new_ids:
            _assign_outputs_to_stack_top(server, stack_id, new_ids)
        if new_ids:
            if stack_id:
                # I2I: copy face records directly (positions are structurally similar)
                _copy_face_assignments(server, source_picture_id, new_ids)
            else:
                # T2I: let face extraction run and schedule similarity-based assignment
                _set_source_picture_id_on_pictures(server, source_picture_id, new_ids)
            _copy_set_and_project_assignments(server, source_picture_id, new_ids)
        if new_ids and view_context:
            _assign_pictures_to_view_context(
                server,
                new_ids,
                set_id=view_context.get("set_id"),
                project_id=view_context.get("project_id"),
                character_id=view_context.get("character_id"),
            )

        if new_ids:
            server.vault.notify(EventType.PICTURE_IMPORTED, new_ids)
        if all_ids:
            server.vault.notify(EventType.CHANGED_PICTURES, all_ids)
    except RuntimeError as exc:
        logger.warning("ComfyUI prompt %s failed before outputs: %s", prompt_id, exc)
        _emit_comfyui_failure_progress(server, prompt_id, str(exc))
    except Exception as exc:
        logger.warning("Failed to import ComfyUI outputs: %s", exc)
        _emit_comfyui_failure_progress(server, prompt_id, str(exc))


def _comfyui_abort(base_url: str) -> dict:
    """Interrupt the currently running ComfyUI execution and clear the queue.

    Calls ComfyUI's ``POST /interrupt`` to stop the active run, then
    ``POST /queue`` with ``{"clear": true}`` to remove pending items.
    Returns a dict with ``interrupted`` and ``queue_cleared`` booleans.
    """
    result = {"interrupted": False, "queue_cleared": False}
    try:
        resp = requests.post(f"{base_url}/interrupt", timeout=10)
        result["interrupted"] = resp.status_code < 300
        if not result["interrupted"]:
            logger.warning(
                "ComfyUI /interrupt returned %s: %s",
                resp.status_code,
                (resp.text or "").strip()[:200],
            )
    except requests.RequestException as exc:
        logger.warning("ComfyUI /interrupt request failed: %s", exc)

    try:
        resp = requests.post(f"{base_url}/queue", json={"clear": True}, timeout=10)
        result["queue_cleared"] = resp.status_code < 300
        if not result["queue_cleared"]:
            logger.warning(
                "ComfyUI /queue clear returned %s: %s",
                resp.status_code,
                (resp.text or "").strip()[:200],
            )
    except requests.RequestException as exc:
        logger.warning("ComfyUI /queue clear request failed: %s", exc)

    return result


def create_router(server) -> APIRouter:
    router = APIRouter()

    @router.websocket("/ws/comfyui")
    async def comfyui_progress_proxy(websocket: WebSocket):
        await websocket.accept()
        session_id = websocket.cookies.get("session_id")
        user = None
        if session_id:
            user_id = server.auth.active_session_ids.get(session_id)
            if user_id is not None:
                user = server.vault.db.run_task(
                    lambda session: session.get(User, user_id),
                    priority=DBPriority.IMMEDIATE,
                )

        comfyui_url = getattr(user, "comfyui_url", None) if user else None
        comfyui_url = (comfyui_url or DEFAULT_COMFYUI_URL).rstrip("/")
        client_id = (
            websocket.query_params.get("clientId")
            or websocket.query_params.get("client_id")
            or f"pixlstash-{uuid.uuid4().hex[:8]}"
        )
        ws_base = (
            comfyui_url.replace("https://", "wss://")
            if comfyui_url.startswith("https://")
            else comfyui_url.replace("http://", "ws://")
        )
        ws_url = f"{ws_base}/ws?clientId={quote(client_id)}"

        async def forward_upstream(upstream):
            try:
                async for message in upstream:
                    if isinstance(message, (bytes, bytearray)):
                        await websocket.send_bytes(bytes(message))
                    else:
                        await websocket.send_text(message)
            except asyncio.CancelledError:
                raise
            except WebSocketDisconnect:
                logger.debug(
                    "ComfyUI WebSocket client disconnected while forwarding upstream."
                )
            except Exception as exc:
                logger.debug("ComfyUI WebSocket upstream forward failed: %s", exc)

        async def forward_downstream(upstream):
            try:
                while True:
                    message = await websocket.receive_text()
                    if message:
                        await upstream.send(message)
            except asyncio.CancelledError:
                raise
            except WebSocketDisconnect:
                logger.debug("ComfyUI WebSocket client disconnected normally.")
            except Exception as exc:
                logger.debug("ComfyUI WebSocket downstream receive failed: %s", exc)

        try:
            async with websockets.connect(
                ws_url, ping_interval=None, close_timeout=2
            ) as upstream:
                upstream_task = asyncio.create_task(forward_upstream(upstream))
                downstream_task = asyncio.create_task(forward_downstream(upstream))
                done, pending = await asyncio.wait(
                    {upstream_task, downstream_task},
                    return_when=asyncio.FIRST_COMPLETED,
                )
                for task in pending:
                    task.cancel()
                await asyncio.gather(*pending, return_exceptions=True)
                for task in done:
                    exc = task.exception()
                    if exc:
                        raise exc
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning("ComfyUI progress proxy failed: %s", exc)
        finally:
            try:
                await websocket.close()
            except Exception as exc:
                logger.debug("Failed to close WebSocket cleanly: %s", exc)

    @router.get(
        "/comfyui/workflows",
        summary="List ComfyUI workflows",
        description="Lists discovered built-in and user workflows with placeholder validation metadata.",
    )
    async def list_comfyui_workflows():
        workflow_dirs = {
            "built_in": _workflow_builtin_dir(),
            "user": _workflow_user_dir(),
        }
        workflows = []
        seen = set()
        for source, folder in _workflow_dirs():
            if not os.path.isdir(folder):
                continue
            for entry in sorted(os.listdir(folder)):
                if not entry.lower().endswith(".json"):
                    continue
                if entry in seen:
                    continue
                seen.add(entry)
                path = os.path.join(folder, entry)
                try:
                    payload = _load_workflow_json(path)
                    valid, missing = _find_placeholder_usage(payload)
                except Exception as exc:
                    logger.warning("Failed to read workflow %s: %s", entry, exc)
                    valid = False
                    missing = [PLACEHOLDER_IMAGE, PLACEHOLDER_CAPTION]
                workflows.append(
                    {
                        "name": entry,
                        "display_name": os.path.splitext(entry)[0],
                        "valid": valid,
                        "missing_placeholders": missing,
                        "source": source,
                        "workflow_type": "t2i"
                        if PLACEHOLDER_IMAGE in missing
                        else "i2i",
                    }
                )
        workflows.sort(key=lambda item: item.get("name", ""))
        return {
            "workflows": workflows,
            "workflow_dirs": workflow_dirs,
        }

    @router.delete(
        "/comfyui/workflows/{workflow_name}",
        summary="Delete user workflow",
        description="Deletes a workflow JSON from the user workflow directory.",
    )
    async def delete_comfyui_workflow(workflow_name: str):
        normalized = _normalize_workflow_name(workflow_name)
        if not normalized:
            raise HTTPException(status_code=400, detail="workflow_name is required")
        workflow_dir = _workflow_user_dir()
        try:
            path = resolve_path_within(workflow_dir, normalized)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid workflow name")
        if not os.path.isfile(path):
            raise HTTPException(status_code=404, detail="Workflow not found in user")
        try:
            os.remove(path)
        except OSError as exc:
            logger.warning("Failed to delete workflow %s: %s", normalized, exc)
            raise HTTPException(status_code=500, detail="Failed to delete workflow")
        return {"status": "success", "name": normalized}

    @router.post(
        "/comfyui/abort",
        summary="Abort ComfyUI execution",
        description="Interrupts the currently running ComfyUI prompt and clears the pending queue.",
    )
    async def abort_comfyui(request: Request):
        user = server.auth.get_user_for_request(request)
        comfyui_url = getattr(user, "comfyui_url", None) if user else None
        comfyui_url = (comfyui_url or DEFAULT_COMFYUI_URL).rstrip("/")
        result = _comfyui_abort(comfyui_url)
        return {"status": "success", **result}

    @router.post(
        "/comfyui/run_i2i",
        summary="Run ComfyUI image-to-image",
        description="Submits i2i prompts for one or more picture ids and imports generated outputs back into PixlStash.",
    )
    async def run_comfyui_i2i(request: Request, payload: dict = Body(...)):
        workflow_name = _normalize_workflow_name(payload.get("workflow_name"))
        if not workflow_name:
            raise HTTPException(status_code=400, detail="workflow_name is required")

        raw_ids = payload.get("picture_ids")
        if raw_ids is None:
            raw_ids = [payload.get("picture_id")]
        if not isinstance(raw_ids, list) or not raw_ids:
            raise HTTPException(status_code=400, detail="picture_ids must be a list")
        try:
            picture_ids = [int(pid) for pid in raw_ids if pid is not None]
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail="picture_ids must be integers")
        if not picture_ids:
            raise HTTPException(status_code=400, detail="picture_ids must be integers")

        caption = payload.get("caption") or ""
        if not isinstance(caption, str):
            caption = str(caption)
        client_id = payload.get("client_id") or payload.get("clientId") or None
        if client_id is not None:
            client_id = str(client_id)

        workflow_path, workflow_source = _resolve_workflow_path(workflow_name)
        if not workflow_path:
            raise HTTPException(status_code=404, detail="Workflow not found")

        workflow_payload = _load_workflow_json(workflow_path)
        valid, missing = _find_placeholder_usage(workflow_payload)
        if not valid and PLACEHOLDER_IMAGE in missing:
            raise HTTPException(
                status_code=400,
                detail=f"Workflow missing placeholders: {', '.join(missing)}",
            )
        output_node_ids = _extract_output_node_ids(workflow_payload, payload)

        user = server.auth.get_user_for_request(request)
        comfyui_url = getattr(user, "comfyui_url", None) if user else None
        comfyui_url = (comfyui_url or DEFAULT_COMFYUI_URL).rstrip("/")

        def fetch_pictures(session, ids: list[int]):
            return session.exec(select(Picture).where(Picture.id.in_(ids))).all()

        pics = server.vault.db.run_task(fetch_pictures, picture_ids)
        pic_map = {pic.id: pic for pic in pics}

        prompts = []
        for pic_id in picture_ids:
            pic = pic_map.get(pic_id)
            if not pic or not getattr(pic, "file_path", None):
                raise HTTPException(status_code=404, detail="Picture not found")
            resolved_path = ImageUtils.resolve_picture_path(
                server.vault.image_root, pic.file_path
            )
            if not resolved_path or not os.path.isfile(resolved_path):
                raise HTTPException(status_code=404, detail="Picture file missing")

            uploaded_name = _upload_image_to_comfyui(comfyui_url, resolved_path)
            replacements = {
                PLACEHOLDER_IMAGE: uploaded_name,
                PLACEHOLDER_CAPTION: caption,
            }
            workflow_instance = _replace_placeholders(
                deepcopy(workflow_payload), replacements
            )
            _randomize_seeds(workflow_instance)
            stack_id = server.vault.db.run_task(
                get_or_create_stack_for_picture,
                pic_id,
            )
            prefix_seed = ""
            for node in workflow_instance.values():
                if not isinstance(node, dict):
                    continue
                if node.get("class_type") != "SaveImage":
                    continue
                inputs = node.get("inputs") or {}
                prefix_seed = str(inputs.get("filename_prefix") or "")
                break
            if stack_id:
                prefix_value = build_stack_filename_prefix(
                    prefix_seed, stack_id, pic_id
                )
                if not _apply_filename_prefix(workflow_instance, prefix_value):
                    logger.warning(
                        "ComfyUI workflow has no SaveImage node to tag for stack %s",
                        stack_id,
                    )
            response_payload = _submit_comfyui_prompt(
                comfyui_url,
                workflow_instance,
                client_id,
            )
            prompt_id = response_payload.get("prompt_id") or response_payload.get("id")
            if prompt_id:
                worker = threading.Thread(
                    target=_process_comfyui_outputs,
                    args=(
                        server,
                        comfyui_url,
                        str(prompt_id),
                        output_node_ids,
                        stack_id,
                        pic_id,
                    ),
                    daemon=True,
                )
                worker.start()
            prompts.append(
                {
                    "picture_id": pic_id,
                    "prompt_id": prompt_id,
                    "workflow": workflow_name,
                }
            )

        return {"status": "success", "prompts": prompts}

    @router.post(
        "/comfyui/run_t2i",
        summary="Run ComfyUI text-to-image",
        description="Submits a t2i prompt using only a caption and imports generated outputs back into PixlStash.",
    )
    async def run_comfyui_t2i(request: Request, payload: dict = Body(...)):
        workflow_name = _normalize_workflow_name(payload.get("workflow_name"))
        if not workflow_name:
            raise HTTPException(status_code=400, detail="workflow_name is required")

        caption = payload.get("caption") or ""
        if not isinstance(caption, str):
            caption = str(caption)
        client_id = payload.get("client_id") or payload.get("clientId") or None
        if client_id is not None:
            client_id = str(client_id)
        raw_source_id = payload.get("source_picture_id")
        source_picture_id: int | None = (
            int(raw_source_id) if raw_source_id is not None else None
        )

        raw_set_id = payload.get("set_id")
        raw_project_id = payload.get("project_id")
        raw_character_id = payload.get("character_id")
        view_context: dict | None = None
        ctx: dict = {}
        if raw_set_id is not None:
            try:
                ctx["set_id"] = int(raw_set_id)
            except (TypeError, ValueError):
                # Ignore invalid set_id values but log for debugging.
                logger.debug(
                    "Ignoring invalid set_id value in run_comfyui_t2i: %r", raw_set_id
                )
        if raw_project_id is not None:
            try:
                ctx["project_id"] = int(raw_project_id)
            except (TypeError, ValueError):
                # Ignore invalid project_id values but log for debugging.
                logger.debug(
                    "Ignoring invalid project_id value in run_comfyui_t2i: %r",
                    raw_project_id,
                )
        if raw_character_id is not None:
            try:
                ctx["character_id"] = int(raw_character_id)
            except (TypeError, ValueError):
                # Ignore invalid character_id values but log for debugging.
                logger.debug(
                    "Ignoring invalid character_id value in run_comfyui_t2i: %r",
                    raw_character_id,
                )
        if ctx:
            view_context = ctx

        workflow_path, _ = _resolve_workflow_path(workflow_name)
        if not workflow_path:
            raise HTTPException(status_code=404, detail="Workflow not found")

        workflow_payload = _load_workflow_json(workflow_path)
        if PLACEHOLDER_IMAGE in json.dumps(workflow_payload, ensure_ascii=False):
            raise HTTPException(
                status_code=400,
                detail="This workflow requires an image input and cannot be used for text-to-image generation.",
            )

        output_node_ids = _extract_output_node_ids(workflow_payload, payload)

        user = server.auth.get_user_for_request(request)
        comfyui_url = getattr(user, "comfyui_url", None) if user else None
        comfyui_url = (comfyui_url or DEFAULT_COMFYUI_URL).rstrip("/")

        seed_mode = payload.get("seed_mode", "random")
        fixed_seed = payload.get("seed")

        replacements = {PLACEHOLDER_CAPTION: caption}
        workflow_instance = _replace_placeholders(
            deepcopy(workflow_payload), replacements
        )
        if seed_mode == "fixed":
            if fixed_seed is None or (
                isinstance(fixed_seed, str) and fixed_seed.strip() == ""
            ):
                raise HTTPException(
                    status_code=400,
                    detail="Invalid seed: when seed_mode is 'fixed', seed must be an integer between 0 and 4294967295.",
                )
            try:
                seed_int = int(fixed_seed)
            except (TypeError, ValueError):
                raise HTTPException(
                    status_code=400,
                    detail="Invalid seed: when seed_mode is 'fixed', seed must be an integer between 0 and 4294967295.",
                )
            if not (0 <= seed_int <= 2**32 - 1):
                raise HTTPException(
                    status_code=400,
                    detail="Invalid seed: must be between 0 and 4294967295.",
                )
            _apply_fixed_seed(workflow_instance, seed_int)
        else:
            _randomize_seeds(workflow_instance)

        response_payload = _submit_comfyui_prompt(
            comfyui_url, workflow_instance, client_id
        )
        prompt_id = response_payload.get("prompt_id") or response_payload.get("id")
        if prompt_id:
            worker = threading.Thread(
                target=_process_comfyui_outputs,
                args=(
                    server,
                    comfyui_url,
                    str(prompt_id),
                    output_node_ids,
                    None,
                    source_picture_id,
                ),
                kwargs={"view_context": view_context},
                daemon=True,
            )
            worker.start()

        prompts = []
        if prompt_id:
            prompts.append({"prompt_id": prompt_id})
        return {
            "status": "success",
            "prompts": prompts,
            "workflow": workflow_name,
        }

    @router.post(
        "/comfyui/workflows/import",
        summary="Import ComfyUI workflow",
        description="Saves a workflow JSON into the user workflow directory, optionally overwriting an existing file.",
    )
    async def import_comfyui_workflow(payload: dict = Body(...)):
        name = _normalize_workflow_name(payload.get("name"))
        if not name:
            raise HTTPException(status_code=400, detail="name is required")
        workflow = payload.get("workflow")
        if not isinstance(workflow, dict):
            raise HTTPException(
                status_code=400, detail="workflow must be a JSON object"
            )
        overwrite = bool(payload.get("overwrite"))

        workflow_dir = _workflow_user_dir()
        os.makedirs(workflow_dir, exist_ok=True)
        try:
            path = resolve_path_within(workflow_dir, name)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid workflow name")
        if os.path.exists(path) and not overwrite:
            raise HTTPException(status_code=409, detail="Workflow already exists")

        _save_workflow_json(path, workflow)
        return {
            "status": "success",
            "name": name,
            "workflow_dir": workflow_dir,
        }

    @router.get(
        "/comfyui/pictures/{picture_id}/workflow",
        summary="Get ComfyUI workflow for a picture",
        description=(
            "Extracts and returns the ComfyUI workflow embedded in a picture's "
            "file metadata, if present."
        ),
    )
    def get_picture_comfyui_workflow(picture_id: str):
        pics = server.vault.db.run_immediate_read_task(
            Picture.find, id=picture_id, select_fields=["id", "file_path"]
        )
        if not pics:
            raise HTTPException(status_code=404, detail="Picture not found")
        pic = pics[0]

        file_path = ImageUtils.resolve_picture_path(
            server.vault.image_root, pic.file_path
        )
        if not file_path:
            raise HTTPException(
                status_code=404, detail="Picture file path could not be resolved"
            )

        try:
            embedded_metadata = ImageUtils.extract_embedded_metadata(file_path)
        except Exception as exc:
            logger.warning(
                "[comfyui] Failed to read embedded metadata for picture id=%s: %s",
                pic.id,
                exc,
            )
            raise HTTPException(
                status_code=500, detail="Failed to read embedded metadata"
            ) from exc

        workflow_info = extract_comfy_workflow_info(embedded_metadata)
        if not workflow_info:
            raise HTTPException(
                status_code=404,
                detail="No ComfyUI workflow found in picture metadata",
            )

        return workflow_info

    return router
