import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from sima_cli.sdk.install import _setup_sdk_extensions
from sima_cli.sdk.utils import (
    _extract_sdk_base_version,
    ensure_model_sdk_extension_installed,
    extract_short_name,
    get_local_sima_images,
    is_neat_elxr_image,
)


SAMPLE_DOCKER_IMAGES = """elxr:latest
783709528641.dkr.ecr.us-west-2.amazonaws.com/vdp-cli/elxr:2.0.0_Palette_SDK_master_B240
783709528641.dkr.ecr.us-west-2.amazonaws.com/vdp-cli/modelsdk:2.0.0_Palette_SDK_master_B240
ghcr.io/sima-neat/elxr:latest
"""


class TestSdkImageDetection(unittest.TestCase):
    @patch("sima_cli.sdk.utils.subprocess.check_output", return_value=SAMPLE_DOCKER_IMAGES)
    def test_get_local_sima_images_includes_ghcr_elxr(self, _mock_check_output):
        images = get_local_sima_images()
        self.assertIn("ghcr.io/sima-neat/elxr:latest", images)
        self.assertIn("elxr:latest", images)
        self.assertIn(
            "783709528641.dkr.ecr.us-west-2.amazonaws.com/vdp-cli/elxr:2.0.0_Palette_SDK_master_B240",
            images,
        )

    def test_extract_short_name_for_ghcr_elxr(self):
        self.assertEqual(extract_short_name("ghcr.io/sima-neat/elxr:latest"), "elxr")

    def test_extract_short_name_for_ghcr_elxr_sdk_alias(self):
        self.assertEqual(extract_short_name("ghcr.io/sima-neat/elxr-sdk:latest"), "elxr")

    def test_is_neat_elxr_image(self):
        self.assertTrue(is_neat_elxr_image("ghcr.io/sima-neat/elxr:latest"))
        self.assertTrue(is_neat_elxr_image("ghcr.io/sima-neat/elxr-sdk:latest"))
        self.assertTrue(is_neat_elxr_image("elxr:latest"))
        self.assertFalse(is_neat_elxr_image("artifacts.eng.sima.ai/elxr:2.1.0"))
        self.assertFalse(is_neat_elxr_image("ghcr.io/sima-neat/modelsdk:latest"))

    def test_setup_sdk_extensions_creates_home_folder_on_x86(self):
        with TemporaryDirectory() as tmpdir:
            with patch("sima_cli.sdk.install.platform.machine", return_value="x86_64"), \
                 patch("sima_cli.sdk.install.Path.home", return_value=Path(tmpdir)):
                extensions_dir = _setup_sdk_extensions(["ghcr.io/sima-neat/elxr:latest"])

            self.assertEqual(extensions_dir, str(Path(tmpdir) / "sima-sdk-extensions"))
            self.assertTrue(Path(extensions_dir).is_dir())

    def test_setup_sdk_extensions_skips_arm64(self):
        with TemporaryDirectory() as tmpdir:
            with patch("sima_cli.sdk.install.platform.machine", return_value="aarch64"), \
                 patch("sima_cli.sdk.install.Path.home", return_value=Path(tmpdir)):
                extensions_dir = _setup_sdk_extensions(["ghcr.io/sima-neat/elxr:latest"])

            self.assertEqual(extensions_dir, "")
            self.assertFalse((Path(tmpdir) / "sima-sdk-extensions").exists())

    def test_extract_sdk_base_version(self):
        sdk_release = "\n".join([
            "SDK Version = 2.0.0_Palette_SDK_neat_main_780365a",
            "eLXr Version = 2.0.0_release_neat_main_780365a",
        ])

        self.assertEqual(_extract_sdk_base_version(sdk_release), "2.0.0")

    def test_model_sdk_extension_skips_non_neat_elxr_image(self):
        with patch("sima_cli.sdk.utils._get_container_image_ref", return_value="artifacts.eng.sima.ai/elxr:2.1.0"), \
             patch("sima_cli.sdk.utils.yes_no_prompt") as prompt, \
             patch("sima_cli.sdk.utils.subprocess.run") as run:
            ensure_model_sdk_extension_installed("container", "docker")

        prompt.assert_not_called()
        run.assert_not_called()

    def test_model_sdk_extension_skips_when_user_declines(self):
        sdk_release = "SDK Version = 2.0.0_Palette_SDK_neat_main_780365a\n"
        read_result = unittest.mock.Mock(returncode=0, stdout=sdk_release)

        with patch("sima_cli.sdk.utils._get_container_image_ref", return_value="ghcr.io/sima-neat/elxr:latest"), \
             patch("sima_cli.sdk.utils.yes_no_prompt", return_value=False), \
             patch("sima_cli.sdk.utils.subprocess.run", return_value=read_result) as run, \
             patch("sima_cli.sdk.utils.run_command") as run_command:
            ensure_model_sdk_extension_installed("container", "docker")

        run.assert_called_once()
        run_command.assert_not_called()

    def test_model_sdk_extension_installs_for_neat_elxr_image(self):
        sdk_release = "SDK Version = 2.0.0_Palette_SDK_neat_main_780365a\n"
        read_result = unittest.mock.Mock(returncode=0, stdout=sdk_release)

        with patch("sima_cli.sdk.utils._get_container_image_ref", return_value="ghcr.io/sima-neat/elxr:latest"), \
             patch("sima_cli.sdk.utils.yes_no_prompt", return_value=True), \
             patch("sima_cli.sdk.utils.sys.stdin.isatty", return_value=True), \
             patch("sima_cli.sdk.utils.sys.stdout.isatty", return_value=True), \
             patch("sima_cli.sdk.utils.subprocess.run", return_value=read_result) as run, \
             patch("sima_cli.sdk.utils.run_command") as run_command:
            ensure_model_sdk_extension_installed("container", "docker")

        run.assert_called_once_with(
            ["docker", "exec", "container", "cat", "/etc/sdk-release"],
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(run_command.call_args_list, [
            unittest.mock.call([
                "docker",
                "exec",
                "-it",
                "-u",
                "docker",
                "container",
                "bash",
                "-lc",
                "sima-cli login",
            ]),
            unittest.mock.call([
                "docker",
                "exec",
                "-u",
                "docker",
                "container",
                "bash",
                "-lc",
                "mkdir -p ~/extension-installation && cd ~/extension-installation && sima-cli install -v 2.0.0 sdk-extensions/model",
            ]),
        ])


if __name__ == "__main__":
    unittest.main()
