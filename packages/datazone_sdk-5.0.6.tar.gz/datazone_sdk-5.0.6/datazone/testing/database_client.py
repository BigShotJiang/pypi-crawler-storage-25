import atexit
import os
import tempfile
from pathlib import Path

import deltalake as dl
import pandas as pd
import pyarrow as pa
import pyarrow.csv as pa_csv

from datazone.db.standard import DatabaseClient
from datazone.deltastorage.data_types import DataType


def _resolve_test_path(subfolder: str, filename: str | None = None) -> str:
    """Build a path relative to the currently running pytest test file."""
    test_dir = os.path.dirname(os.environ["PYTEST_CURRENT_TEST"])
    if filename is None:
        return os.path.join(test_dir, subfolder)
    return os.path.join(test_dir, subfolder, filename)


def _read_csv_to_pyarrow(filepath: str) -> pa.Table:
    """Read a typed CSV file into a PyArrow table.
    First line of the CSV must be a header with column names,
    optionally with type declarations in the format "column_name:type".
    Supported types are defined in :mod:`datazone.deltastorage.data_types`.
    Pyarrow uses the declared types to read the CSV, and falls back to inference for
    columns without a declared type.
    """
    with open(filepath, encoding="utf-8") as file_handle:
        header_line = file_handle.readline().strip()

    header_names = []
    declared_types: dict[str, pa.DataType] = {}
    for header_entry in header_line.split(","):
        name, separator, type_str = header_entry.partition(":")
        if separator:
            declared_types[name] = DataType.from_str(type_str).to_arrow()
        header_names.append(name)

    return pa_csv.read_csv(
        filepath,
        read_options=pa_csv.ReadOptions(
            column_names=header_names,
            skip_rows=1,
        ),
        convert_options=pa_csv.ConvertOptions(
            column_types=declared_types,
            null_values=["nan", ""],
        ),
    )


def read_df(filename: str, subfolder: str = "data") -> pd.DataFrame:
    """Read a test CSV file into a pandas DataFrame with query-compatible dtypes.

    Datetime columns are normalised to nanosecond precision to match the output
    of :meth:`~datazone.db.standard.DatabaseClient.query`.

    Args:
        filename: Name of the CSV file, e.g. ``"animals.df.csv"``.
        subfolder: Folder relative to the currently running test file.
            Defaults to ``"data"``.

    Returns:
        A pandas DataFrame whose datetime dtypes match those returned by
        ``DatabaseClient.query``.

    Example:
        >>> df = read_df("animals.df.csv")
        >>> df = read_df("animals.df.csv", subfolder="base")
    """
    path = _resolve_test_path(subfolder, filename)
    df = _read_csv_to_pyarrow(path).to_pandas()

    # Needed to match output from DatabaseClient.query
    # which returns timezone-aware datetimes at ns precision.
    for column in df.columns:
        dtype = df[column].dtype
        if isinstance(dtype, pd.DatetimeTZDtype):
            tz = dtype.tz
            df[column] = df[column].astype(f"datetime64[ns, {tz}]")
        elif pd.api.types.is_datetime64_dtype(dtype):
            df[column] = df[column].astype("datetime64[ns]")

    return df


def write_csv_folder_to_delta(
    data_path: str | os.PathLike[str],
    delta_root_path: str | os.PathLike[str],
    file_suffix: str = ".df.csv",
) -> dict[str, str]:
    """Write all matching CSV files in a folder as Delta tables under a root path.

    Each file named ``<table_name><file_suffix>`` becomes a Delta table at
    ``<delta_root_path>/<table_name>``.

    Args:
        data_path: Folder containing the CSV source files.
        delta_root_path: Destination root under which Delta tables are written.
        file_suffix: Filename suffix used to identify CSV files to materialize.
            Defaults to ``".df.csv"``.

    Returns:
        Mapping of table name to the path of the created Delta table.

    Example:
        >>> tables = write_csv_folder_to_delta("/path/to/csvs", "/tmp/delta_root")
        >>> tables = write_csv_folder_to_delta(
        ...     "/path/to/csvs", "/tmp/delta_root", file_suffix=".csv"
        ... )
    """
    source_dir = os.fspath(data_path)
    delta_root = os.fspath(delta_root_path)
    delta_tables: dict[str, str] = {}

    csv_paths = sorted(
        path for path in os.listdir(source_dir) if path.endswith(file_suffix)
    )
    for csv_path in csv_paths:
        table_name = csv_path.removesuffix(file_suffix)
        csv_filepath = os.path.join(source_dir, csv_path)
        delta_table_path = os.path.join(delta_root, table_name)
        dl.write_deltalake(
            delta_table_path,
            _read_csv_to_pyarrow(csv_filepath),
            mode="overwrite",
        )
        delta_tables[table_name] = delta_table_path

    return delta_tables


def create_test_database_client(
    data_path: str | os.PathLike[str] | None = None,
    subfolder: str = "data",
    file_suffix: str = ".df.csv",
) -> DatabaseClient:
    """Create a temporary Delta-backed DatabaseClient from a folder of CSV files.

    All CSV files matching ``file_suffix`` in ``data_path`` are written as Delta
    tables to a temporary directory. A plain
    :class:`~datazone.db.standard.DatabaseClient` pointing at that directory is
    returned. The temporary directory is cleaned up automatically by the pytest plugin
    after each test.

    Args:
        data_path: Folder containing the CSV source files. When omitted, defaults
            to the ``subfolder`` relative to the currently running test file.
        subfolder: Subfolder relative to the currently running test file, used when
            ``data_path`` is not given. Defaults to ``"data"``.
        file_suffix: Filename suffix that identifies CSV files to materialize.
            Defaults to ``".df.csv"``.

    Returns:
        A plain ``DatabaseClient`` backed by Delta tables in a temporary directory.

    Example:
        >>> db = create_test_database_client()
        >>> db = create_test_database_client(subfolder="base")
        >>> db = create_test_database_client(data_path="/path/to/csvs")
    """
    source_dir = (
        os.fspath(data_path) if data_path is not None else _resolve_test_path(subfolder)
    )
    temp_dir = tempfile.TemporaryDirectory(prefix="test_database_")

    # Clean up temp dirs when python exits
    atexit.register(temp_dir.cleanup)

    write_csv_folder_to_delta(source_dir, temp_dir.name, file_suffix=file_suffix)
    # DatabaseClient expects a file:// URL for local storage roots.
    return DatabaseClient(url=Path(temp_dir.name).as_uri())
