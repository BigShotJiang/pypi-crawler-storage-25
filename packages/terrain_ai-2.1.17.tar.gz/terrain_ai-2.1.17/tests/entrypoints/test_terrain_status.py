"""Tests for terrain status stale-repo detection."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from terrain.entrypoints.cli.cli import _get_repo_status_entries
from terrain.foundation.services.git_service import GitChangeDetector


# ---------------------------------------------------------------------------
# GitChangeDetector.count_commits_since tests
# ---------------------------------------------------------------------------

class TestCountCommitsSince:
    def test_returns_zero_when_no_commits(self, tmp_path):
        detector = GitChangeDetector()
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="")
            count = detector.count_commits_since(tmp_path, "2026-04-01T00:00:00+00:00")
        assert count == 0

    def test_returns_commit_count(self, tmp_path):
        detector = GitChangeDetector()
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout="abc1234 fix something\ndef5678 add feature\n"
            )
            count = detector.count_commits_since(tmp_path, "2026-04-01T00:00:00+00:00")
        assert count == 2

    def test_returns_none_when_not_a_git_repo(self, tmp_path):
        detector = GitChangeDetector()
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=128, stdout="")
            count = detector.count_commits_since(tmp_path, "2026-04-01T00:00:00+00:00")
        assert count is None

    def test_returns_none_on_subprocess_error(self, tmp_path):
        detector = GitChangeDetector()
        with patch("subprocess.run", side_effect=subprocess.SubprocessError("fail")):
            count = detector.count_commits_since(tmp_path, "2026-04-01T00:00:00+00:00")
        assert count is None

    def test_returns_none_on_timeout(self, tmp_path):
        detector = GitChangeDetector()
        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired(cmd="git", timeout=5)):
            count = detector.count_commits_since(tmp_path, "2026-04-01T00:00:00+00:00")
        assert count is None


# ---------------------------------------------------------------------------
# _get_repo_status_entries tests
# ---------------------------------------------------------------------------

class TestGetRepoStatusEntries:
    def _make_artifact_dir(self, ws: Path, name: str, repo_path: str, indexed_at: str) -> Path:
        artifact_dir = ws / name
        artifact_dir.mkdir()
        (artifact_dir / "meta.json").write_text(
            json.dumps({
                "repo_name": name,
                "repo_path": repo_path,
                "indexed_at": indexed_at,
            }),
            encoding="utf-8",
        )
        return artifact_dir

    def test_empty_workspace_returns_empty(self, tmp_path):
        entries = _get_repo_status_entries(tmp_path)
        assert entries == []

    def test_workspace_not_exist_returns_empty(self, tmp_path):
        entries = _get_repo_status_entries(tmp_path / "nonexistent")
        assert entries == []

    def test_up_to_date_repo(self, tmp_path):
        ws = tmp_path / "workspace"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()
        self._make_artifact_dir(ws, "myrepo_abc12345", str(repo), "2026-04-10T10:00:00+00:00")

        with patch("terrain.foundation.services.git_service.GitChangeDetector") as MockDetector:
            instance = MockDetector.return_value
            instance.count_commits_since.return_value = 0
            entries = _get_repo_status_entries(ws)

        assert len(entries) == 1
        assert entries[0]["status"] == "up-to-date"
        assert entries[0]["commits_since"] == 0
        assert entries[0]["name"] == "myrepo_abc12345"

    def test_stale_repo(self, tmp_path):
        ws = tmp_path / "workspace"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()
        self._make_artifact_dir(ws, "myrepo_abc12345", str(repo), "2026-04-10T10:00:00+00:00")

        with patch("terrain.foundation.services.git_service.GitChangeDetector") as MockDetector:
            instance = MockDetector.return_value
            instance.count_commits_since.return_value = 5
            entries = _get_repo_status_entries(ws)

        assert len(entries) == 1
        assert entries[0]["status"] == "stale"
        assert entries[0]["commits_since"] == 5

    def test_unknown_when_not_git_repo(self, tmp_path):
        ws = tmp_path / "workspace"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()
        self._make_artifact_dir(ws, "myrepo_abc12345", str(repo), "2026-04-10T10:00:00+00:00")

        with patch("terrain.foundation.services.git_service.GitChangeDetector") as MockDetector:
            instance = MockDetector.return_value
            instance.count_commits_since.return_value = None
            entries = _get_repo_status_entries(ws)

        assert len(entries) == 1
        assert entries[0]["status"] == "unknown"
        assert entries[0]["commits_since"] is None

    def test_unknown_when_repo_path_missing(self, tmp_path):
        ws = tmp_path / "workspace"
        ws.mkdir()
        nonexistent_repo = str(tmp_path / "nonexistent")
        self._make_artifact_dir(ws, "gone_abc12345", nonexistent_repo, "2026-04-10T10:00:00+00:00")

        with patch("terrain.foundation.services.git_service.GitChangeDetector") as MockDetector:
            instance = MockDetector.return_value
            instance.count_commits_since.return_value = None
            entries = _get_repo_status_entries(ws)

        assert len(entries) == 1
        assert entries[0]["status"] == "unknown"

    def test_multiple_repos(self, tmp_path):
        ws = tmp_path / "workspace"
        ws.mkdir()
        for name in ("alpha", "beta", "gamma"):
            repo = tmp_path / name
            repo.mkdir()
            self._make_artifact_dir(ws, f"{name}_deadbeef", str(repo), "2026-04-01T00:00:00+00:00")

        commit_counts = {"alpha_deadbeef": 0, "beta_deadbeef": 3, "gamma_deadbeef": None}

        def fake_count(repo_path: Path, indexed_at: str) -> int | None:
            for name, count in commit_counts.items():
                if name.split("_")[0] in str(repo_path):
                    return count
            return None

        with patch("terrain.foundation.services.git_service.GitChangeDetector") as MockDetector:
            instance = MockDetector.return_value
            instance.count_commits_since.side_effect = fake_count
            entries = _get_repo_status_entries(ws)

        statuses = {e["name"].split("_")[0]: e["status"] for e in entries}
        assert statuses["alpha"] == "up-to-date"
        assert statuses["beta"] == "stale"
        assert statuses["gamma"] == "unknown"

    def test_skips_dirs_without_meta_json(self, tmp_path):
        ws = tmp_path / "workspace"
        ws.mkdir()
        (ws / "no_meta_dir").mkdir()
        entries = _get_repo_status_entries(ws)
        assert entries == []


# ---------------------------------------------------------------------------
# GitChangeDetector.count_commits_since_sha — SHA-based counting
# ---------------------------------------------------------------------------

def _init_repo(path: Path) -> None:
    subprocess.run(["git", "init", "--initial-branch=main"], cwd=path, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.email", "t@t.com"], cwd=path, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.name", "T"], cwd=path, check=True, capture_output=True)


def _commit(path: Path, name: str, content: str, msg: str) -> str:
    (path / name).write_text(content)
    subprocess.run(["git", "add", "."], cwd=path, check=True, capture_output=True)
    subprocess.run(["git", "commit", "-m", msg], cwd=path, check=True, capture_output=True)
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=path, check=True, capture_output=True, text=True
    ).stdout.strip()
    return head


class TestCountCommitsSinceSha:
    def test_zero_when_head_equals_sha(self, tmp_path):
        _init_repo(tmp_path)
        head = _commit(tmp_path, "a.txt", "a", "first")
        assert GitChangeDetector().count_commits_since_sha(tmp_path, head) == 0

    def test_counts_commits_ahead_of_sha(self, tmp_path):
        _init_repo(tmp_path)
        anchor = _commit(tmp_path, "a.txt", "a", "first")
        _commit(tmp_path, "b.txt", "b", "second")
        _commit(tmp_path, "c.txt", "c", "third")
        assert GitChangeDetector().count_commits_since_sha(tmp_path, anchor) == 2

    def test_zero_after_amend(self, tmp_path):
        """git commit --amend rewrites the commit timestamp but same SHA semantics.

        Under the old `--since` strategy, the amended commit's new timestamp
        would be counted as a change. SHA-based counting reports 0 because
        HEAD's new SHA is what we would now record as last_indexed_commit.
        """
        _init_repo(tmp_path)
        _commit(tmp_path, "a.txt", "a", "first")
        # Amend — rewrites the commit (new SHA, new timestamp).
        subprocess.run(
            ["git", "commit", "--amend", "--no-edit", "--date=now"],
            cwd=tmp_path, check=True, capture_output=True,
        )
        new_head = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=tmp_path, check=True, capture_output=True, text=True
        ).stdout.strip()
        # Indexing captures the post-amend SHA — staleness should be 0.
        assert GitChangeDetector().count_commits_since_sha(tmp_path, new_head) == 0

    def test_none_when_sha_missing(self, tmp_path):
        """Force-push / rebase dropped the anchor SHA — must return None, not silently miscount."""
        _init_repo(tmp_path)
        _commit(tmp_path, "a.txt", "a", "first")
        bogus = "0" * 40
        assert GitChangeDetector().count_commits_since_sha(tmp_path, bogus) is None

    def test_none_for_empty_sha(self, tmp_path):
        assert GitChangeDetector().count_commits_since_sha(tmp_path, "") is None

    def test_none_on_timeout(self, tmp_path):
        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired(cmd="git", timeout=5)):
            assert GitChangeDetector().count_commits_since_sha(tmp_path, "abc1234") is None


# ---------------------------------------------------------------------------
# _get_repo_status_entries integration — SHA-preferred + legacy fallback
# ---------------------------------------------------------------------------

class TestStatusEntriesShaPath:
    def test_sha_path_reports_up_to_date(self, tmp_path):
        """When last_indexed_commit matches HEAD, status is up-to-date."""
        ws = tmp_path / "workspace"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()
        _init_repo(repo)
        head = _commit(repo, "a.txt", "a", "first")

        artifact_dir = ws / "myrepo_abc12345"
        artifact_dir.mkdir()
        (artifact_dir / "meta.json").write_text(json.dumps({
            "repo_name": "myrepo_abc12345",
            "repo_path": str(repo),
            "indexed_at": "2026-04-10T10:00:00+00:00",
            "last_indexed_commit": head,
        }))

        entries = _get_repo_status_entries(ws)
        assert entries[0]["status"] == "up-to-date"
        assert entries[0]["commits_since"] == 0

    def test_sha_path_reports_n_commits_ahead(self, tmp_path):
        """HEAD is 3 commits past last_indexed_commit → stale, commits_since==3."""
        ws = tmp_path / "workspace"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()
        _init_repo(repo)
        anchor = _commit(repo, "a.txt", "a", "first")
        _commit(repo, "b.txt", "b", "second")
        _commit(repo, "c.txt", "c", "third")
        _commit(repo, "d.txt", "d", "fourth")

        artifact_dir = ws / "myrepo_abc12345"
        artifact_dir.mkdir()
        (artifact_dir / "meta.json").write_text(json.dumps({
            "repo_name": "myrepo_abc12345",
            "repo_path": str(repo),
            "indexed_at": "2026-04-10T10:00:00+00:00",
            "last_indexed_commit": anchor,
        }))

        entries = _get_repo_status_entries(ws)
        assert entries[0]["status"] == "stale"
        assert entries[0]["commits_since"] == 3

    def test_sha_path_unknown_when_sha_force_pushed_away(self, tmp_path):
        """Simulate force-push: last_indexed_commit no longer exists in repo."""
        ws = tmp_path / "workspace"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()
        _init_repo(repo)
        _commit(repo, "a.txt", "a", "first")

        artifact_dir = ws / "myrepo_abc12345"
        artifact_dir.mkdir()
        (artifact_dir / "meta.json").write_text(json.dumps({
            "repo_name": "myrepo_abc12345",
            "repo_path": str(repo),
            "indexed_at": "2026-04-10T10:00:00+00:00",
            "last_indexed_commit": "0" * 40,  # SHA that no longer exists
        }))

        entries = _get_repo_status_entries(ws)
        assert entries[0]["status"] == "unknown"
        assert entries[0]["commits_since"] is None

    def test_legacy_fallback_when_last_indexed_commit_missing(self, tmp_path):
        """Old meta.json without last_indexed_commit — naive indexed_at still works via --since fallback."""
        ws = tmp_path / "workspace"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()
        # Legacy entry: no last_indexed_commit, naive timestamp
        artifact_dir = ws / "myrepo_abc12345"
        artifact_dir.mkdir()
        (artifact_dir / "meta.json").write_text(json.dumps({
            "repo_name": "myrepo_abc12345",
            "repo_path": str(repo),
            "indexed_at": "2026-04-10T10:00:00",  # naive legacy string
        }))

        with patch("terrain.foundation.services.git_service.GitChangeDetector") as MockDetector:
            instance = MockDetector.return_value
            instance.count_commits_since.return_value = 2
            entries = _get_repo_status_entries(ws)

        # Fallback went through count_commits_since with the legacy string
        instance.count_commits_since.assert_called_once()
        assert entries[0]["status"] == "stale"
        assert entries[0]["commits_since"] == 2


# ---------------------------------------------------------------------------
# _get_repo_status_entries exposes artifact_dir + indexed_head + current_head
# ---------------------------------------------------------------------------


class TestStatusEntriesHeadFields:
    """The MCP list_repositories tool joins on these fields — they must exist."""

    def test_entry_carries_artifact_dir_and_short_heads_when_up_to_date(self, tmp_path):
        ws = tmp_path / "workspace"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()
        _init_repo(repo)
        head = _commit(repo, "a.txt", "a", "first")

        artifact_dir = ws / "myrepo_abc12345"
        artifact_dir.mkdir()
        (artifact_dir / "meta.json").write_text(json.dumps({
            "repo_name": "myrepo",
            "repo_path": str(repo),
            "indexed_at": "2026-04-10T10:00:00+00:00",
            "last_indexed_commit": head,
        }))

        entries = _get_repo_status_entries(ws)
        assert len(entries) == 1
        e = entries[0]
        assert e["artifact_dir"] == "myrepo_abc12345"
        assert e["status"] == "up-to-date"
        assert e["indexed_head"] == head[:7]
        assert e["current_head"] == head[:7]

    def test_entry_reports_distinct_short_heads_when_stale(self, tmp_path):
        ws = tmp_path / "workspace"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()
        _init_repo(repo)
        anchor = _commit(repo, "a.txt", "a", "first")
        latest = _commit(repo, "b.txt", "b", "second")

        artifact_dir = ws / "myrepo_abc12345"
        artifact_dir.mkdir()
        (artifact_dir / "meta.json").write_text(json.dumps({
            "repo_name": "myrepo",
            "repo_path": str(repo),
            "indexed_at": "2026-04-10T10:00:00+00:00",
            "last_indexed_commit": anchor,
        }))

        entries = _get_repo_status_entries(ws)
        e = entries[0]
        assert e["status"] == "stale"
        assert e["indexed_head"] == anchor[:7]
        assert e["current_head"] == latest[:7]
        assert e["indexed_head"] != e["current_head"]
        # Short SHAs are 7 chars, never the full 40
        assert len(e["indexed_head"]) == 7
        assert len(e["current_head"]) == 7

    def test_entry_head_fields_none_when_not_git_repo(self, tmp_path):
        ws = tmp_path / "workspace"
        ws.mkdir()
        repo = tmp_path / "myrepo"   # plain dir, not a git repo
        repo.mkdir()

        artifact_dir = ws / "myrepo_abc12345"
        artifact_dir.mkdir()
        (artifact_dir / "meta.json").write_text(json.dumps({
            "repo_name": "myrepo",
            "repo_path": str(repo),
            "indexed_at": "2026-04-10T10:00:00+00:00",
            # no last_indexed_commit
        }))

        entries = _get_repo_status_entries(ws)
        e = entries[0]
        assert e["status"] == "unknown"
        assert e["indexed_head"] is None
        assert e["current_head"] is None


# ---------------------------------------------------------------------------
# MCP list_repositories handler embeds staleness / indexed_head / current_head
# ---------------------------------------------------------------------------


def _write_artifact(
    ws: Path,
    artifact_name: str,
    repo_path: Path,
    *,
    last_indexed_commit: str | None,
    graph_built: bool = True,
) -> None:
    artifact_dir = ws / artifact_name
    artifact_dir.mkdir()
    meta: dict = {
        "repo_name": artifact_name.split("_")[0],
        "repo_path": str(repo_path),
        "indexed_at": "2026-04-10T10:00:00+00:00",
        "steps": {"graph": graph_built, "api_docs": False, "embeddings": False, "wiki": False},
    }
    if last_indexed_commit is not None:
        meta["last_indexed_commit"] = last_indexed_commit
    (artifact_dir / "meta.json").write_text(json.dumps(meta))


def _list_repositories(ws: Path) -> dict:
    import asyncio

    from terrain.entrypoints.mcp.tools import MCPToolsRegistry

    registry = MCPToolsRegistry(workspace=ws)
    try:
        return asyncio.new_event_loop().run_until_complete(registry._handle_list_repositories())
    finally:
        registry.close()


class TestMcpListRepositoriesStaleness:
    """Covers the three staleness states exposed by the MCP list_repositories tool."""

    def test_up_to_date_repo_reports_up_to_date_and_equal_heads(self, tmp_path):
        ws = tmp_path / "ws"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()
        _init_repo(repo)
        head = _commit(repo, "a.txt", "a", "first")
        _write_artifact(ws, "myrepo_abc12345", repo, last_indexed_commit=head)

        result = _list_repositories(ws)
        repos = result["repositories"]
        assert len(repos) == 1
        r = repos[0]
        assert r["staleness"] == "up-to-date"
        assert r["indexed_head"] == head[:7]
        assert r["current_head"] == head[:7]
        assert r["commits_since"] == 0

    def test_stale_repo_reports_stale_with_distinct_short_shas(self, tmp_path):
        ws = tmp_path / "ws"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()
        _init_repo(repo)
        anchor = _commit(repo, "a.txt", "a", "first")
        latest = _commit(repo, "b.txt", "b", "second")
        _write_artifact(ws, "myrepo_abc12345", repo, last_indexed_commit=anchor)

        result = _list_repositories(ws)
        r = result["repositories"][0]
        assert r["staleness"] == "stale"
        assert r["indexed_head"] == anchor[:7]
        assert r["current_head"] == latest[:7]
        assert r["indexed_head"] != r["current_head"]
        assert r["commits_since"] == 1

    def test_stale_repo_reports_exact_commits_since_count(self, tmp_path):
        """HEAD advanced by 3 commits → commits_since must be exactly 3."""
        ws = tmp_path / "ws"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()
        _init_repo(repo)
        anchor = _commit(repo, "a.txt", "a", "first")
        _commit(repo, "b.txt", "b", "second")
        _commit(repo, "c.txt", "c", "third")
        _commit(repo, "d.txt", "d", "fourth")
        _write_artifact(ws, "myrepo_abc12345", repo, last_indexed_commit=anchor)

        result = _list_repositories(ws)
        r = result["repositories"][0]
        assert r["staleness"] == "stale"
        assert r["commits_since"] == 3

    def test_non_git_repo_reports_unknown(self, tmp_path):
        ws = tmp_path / "ws"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()  # not a git repo
        _write_artifact(ws, "myrepo_abc12345", repo, last_indexed_commit=None)

        result = _list_repositories(ws)
        r = result["repositories"][0]
        assert r["staleness"] == "unknown"
        assert r["indexed_head"] is None
        assert r["current_head"] is None
        assert r["commits_since"] is None

    def test_half_built_repo_without_graph_is_unknown(self, tmp_path):
        """Edge case: artifact dir exists but graph step never finished."""
        ws = tmp_path / "ws"
        ws.mkdir()
        repo = tmp_path / "myrepo"
        repo.mkdir()
        _init_repo(repo)
        head = _commit(repo, "a.txt", "a", "first")
        _write_artifact(
            ws, "myrepo_abc12345", repo,
            last_indexed_commit=head,
            graph_built=False,
        )

        result = _list_repositories(ws)
        r = result["repositories"][0]
        assert r["staleness"] == "unknown"
        assert r["indexed_head"] is None
        assert r["current_head"] is None
        assert r["commits_since"] is None

    def test_empty_workspace_returns_empty_list_not_error(self, tmp_path):
        ws = tmp_path / "empty"
        result = _list_repositories(ws)
        assert result["repositories"] == []
        assert result["repository_count"] == 0


# ---------------------------------------------------------------------------
# save_meta writes timezone-aware UTC for indexed_at
# ---------------------------------------------------------------------------

class TestSaveMetaIndexedAtAware:
    def test_indexed_at_is_timezone_aware_utc(self, tmp_path):
        from datetime import datetime
        from terrain.entrypoints.mcp.pipeline import save_meta

        save_meta(tmp_path, tmp_path / "repo", wiki_page_count=0)
        meta = json.loads((tmp_path / "meta.json").read_text())
        parsed = datetime.fromisoformat(meta["indexed_at"])
        assert parsed.tzinfo is not None, (
            f"indexed_at must be timezone-aware, got naive: {meta['indexed_at']!r}"
        )
        # And it should be UTC (offset == 0)
        assert parsed.utcoffset().total_seconds() == 0
