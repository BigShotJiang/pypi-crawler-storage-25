import sys


def main():
    print("TheWire has been renamed to Flue.")
    print("")
    print("To migrate, run:")
    print("  pip uninstall thewire")
    print("  pip install flue")
    print("  flue setup")
    print("")
    print("More info: https://pypi.org/project/flue/")
    sys.exit(0)


if __name__ == "__main__":
    main()
