# thewire → Flue

**TheWire has been renamed to [Flue](https://pypi.org/project/flue/).**

```bash
pip install flue
flue setup
```

This package now installs `flue` automatically. Please update your dependencies.
