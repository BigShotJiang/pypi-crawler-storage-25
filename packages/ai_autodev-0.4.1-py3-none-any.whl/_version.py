"""Version string (read by hatch at build time, importable as `_version`)."""

__version__ = "0.4.1"

__all__ = ["__version__"]
