"""
The 'worktoy.waitaminute' package provides the custom exceptions used
across the 'worktoy' library.
"""
#  AGPL-3.0 license
#  Copyright (c) 2025-2026 Asger Jon Vistisen
from __future__ import annotations

from ._type_exception import TypeException
from ._variable_not_none import VariableNotNone
from ._unpack_exception import UnpackException
from ._path_syntax_exception import PathSyntaxException
from ._subclass_exception import SubclassException
from ._missing_variable import MissingVariable
from . import desc
from . import meta
from . import dispatch
from . import keenum
from . import ezdata
from . import control_flow

__all__ = [
  'TypeException',
  'VariableNotNone',
  'UnpackException',
  'PathSyntaxException',
  'SubclassException',
  'MissingVariable',
  'desc',
  'meta',
  'dispatch',
  'keenum',
  'ezdata',
  'control_flow',
]
