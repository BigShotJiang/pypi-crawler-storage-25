class ReceiptCategoriser:
    """
    Suggests a category for a receipt based on the store name.
    """
    STORE_CATEGORIES = {
        'tesco': 'Groceries',
        'dunnes': 'Groceries',
        'aldi': 'Groceries',
        'lidl': 'Groceries',
        'starbucks': 'Food',
        'mcdonalds': 'Food',
        'subway': 'Food',
        'ryanair': 'Travel',
        'aer lingus': 'Travel',
        'uber': 'Travel',
        'zara': 'Shopping',
        'penneys': 'Shopping',
        'primark': 'Shopping',
    }

    def suggest_category(self, store_name):
        """
        Takes a store_name string and returns the suggested category.
        If no match is found, returns 'Other'.
        """
        if not store_name:
            return 'Other'
        store_name_lower = store_name.lower()
        for keyword, category in self.STORE_CATEGORIES.items():
            if keyword in store_name_lower:
                return category
        return 'Other'
