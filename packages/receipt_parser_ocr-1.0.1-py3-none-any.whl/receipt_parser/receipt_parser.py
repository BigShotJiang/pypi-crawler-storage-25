import re


class Receipt:
    def __init__(self, store_name, total_amount, payment_mode, date=None):
        self.store_name = store_name
        self.total_amount = total_amount
        self.payment_mode = payment_mode
        self.date = date

    def __repr__(self):
        return f"<Receipt {self.store_name} - {self.total_amount} - {self.payment_mode} - {self.date}>"


class ReceiptParser:

    # 🔥 CLEAN TEXT (MAIN FIX)
    def _clean_text(self, text):
        """
        Fix encoding issues where currency symbols become weird characters or '2'
        """

        # Try fixing encoding (common OCR issue)
        try:
            text = text.encode('latin1', errors='ignore').decode('utf-8', errors='ignore')
        except (UnicodeDecodeError, UnicodeEncodeError):
            pass

        # Replace common broken symbols
        replacements = {
            "â‚¬": "€",
            "Â£": "£",
            "â‚¹": "₹",
            "€": "€",
            "£": "£"
        }

        for bad, good in replacements.items():
            text = text.replace(bad, good)

        return text

    # 1️⃣ Extract store name
    def _extract_store_name(self, text):
        for line in text.splitlines():
            line = line.strip()
            if line:
                return line
        return None

    # 2️⃣ Extract date
    def _extract_date(self, text):
        match = re.search(r'\d{2}[\/\-\.]\d{2}[\/\-\.]\d{2,4}', text)
        if match:
            return match.group().replace('-', '/').replace('.', '/')
        return None

    # 3️⃣ Extract total amount (FIXED)
    def _extract_total(self, text):
        """
        Handles cases where € or £ becomes '2'
        """

        # Normalize weird OCR issues like "2 12.99" instead of "€12.99"
        text = re.sub(r'(?<=\s)2(?=\s*\d+[\.,]\d{2})', '', text)

        match = re.search(
            r'(?<!SUB)TOTAL.*?(?:EUR|€|\$|£)?\s*([\d]+[\.,]\d{2})',
            text,
            re.IGNORECASE
        )

        if match:
            amount_str = match.group(1).replace(',', '.')
            return float(amount_str)

        return None

    # 4️⃣ Extract payment mode
    def _extract_payment_mode(self, text):
        match = re.search(
            r'VISA|CASH|MASTERCARD|CONTACTLESS|DEBIT|AMEX|AMERICAN EXPRESS|CREDIT',
            text,
            re.IGNORECASE
        )
        if match:
            return match.group().upper()
        return None

    # 5️⃣ Main parse method
    def parse(self, text):
        """
        Full pipeline:
        CLEAN → EXTRACT
        """

        # 🔥 APPLY CLEANING FIRST
        text = self._clean_text(text)

        store_name = self._extract_store_name(text)
        date = self._extract_date(text)
        total_amount = self._extract_total(text)
        payment_mode = self._extract_payment_mode(text)

        return Receipt(
            store_name=store_name,
            total_amount=total_amount,
            payment_mode=payment_mode,
            date=date
        )