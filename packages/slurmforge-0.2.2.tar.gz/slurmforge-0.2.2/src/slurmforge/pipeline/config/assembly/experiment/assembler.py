from __future__ import annotations

from dataclasses import dataclass, field

from ...models import (
    EvalConfigSpec,
    ModelConfigSpec,
    OutputConfigSpec,
    PlanningHints,
    RunConfigSpec,
    StorageConfigSpec,
)
from ...runtime import (
    ArtifactsConfig,
    ClusterConfig,
    DispatchConfig,
    EnvConfig,
    LauncherConfig,
    NotifyConfig,
    ResourcesConfig,
    ValidationConfig,
)
from .inputs import ExperimentSectionInputs
from .sections import NormalizedExperimentSections


@dataclass(frozen=True)
class NormalizedExperimentContract:
    project: str
    experiment_name: str
    model: ModelConfigSpec | None
    run: RunConfigSpec
    launcher: LauncherConfig
    cluster: ClusterConfig
    env: EnvConfig
    resources: ResourcesConfig
    dispatch: DispatchConfig
    artifacts: ArtifactsConfig
    eval: EvalConfigSpec
    output: OutputConfigSpec
    notify: NotifyConfig
    validation: ValidationConfig
    hints: PlanningHints
    storage: StorageConfigSpec = field(default_factory=StorageConfigSpec)


def assemble_experiment_contract(
    inputs: ExperimentSectionInputs,
    sections: NormalizedExperimentSections,
    *,
    hints: PlanningHints,
) -> NormalizedExperimentContract:
    return NormalizedExperimentContract(
        project=inputs.project,
        experiment_name=inputs.experiment_name,
        model=sections.model,
        run=sections.run,
        launcher=sections.launcher,
        cluster=sections.cluster,
        env=sections.env,
        resources=sections.resources,
        dispatch=sections.dispatch,
        artifacts=sections.artifacts,
        eval=sections.eval,
        output=sections.output,
        notify=sections.notify,
        validation=sections.validation,
        hints=hints,
        storage=sections.storage,
    )
