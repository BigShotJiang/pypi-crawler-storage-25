"""Auto-ingest base protocol and data types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

from memex.models import ItemType


@dataclass(frozen=True)
class IngestItem:
    """A single item to be ingested from an auto-ingest source."""

    content: str
    title: str = ""
    source_url: str = ""
    item_type: ItemType = ItemType.NOTE
    author: str = ""
    tags: list[str] = field(default_factory=list)


class AutoIngestSource(Protocol):
    """Protocol for auto-ingest sources."""

    @property
    def name(self) -> str:
        """Human-readable source name."""
        ...

    @property
    def source_type(self) -> str:
        """Source type identifier (e.g. 'watch_folder', 'rss', 'gmail')."""
        ...

    def fetch(self) -> list[IngestItem]:
        """Fetch new items from the source. Returns items to ingest."""
        ...

    def configure(self, config: dict[str, Any]) -> None:
        """Apply configuration to the source."""
        ...
