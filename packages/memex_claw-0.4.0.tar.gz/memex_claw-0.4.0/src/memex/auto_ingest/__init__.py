"""Auto-ingest package — framework for automatic content ingestion from external sources."""
