"""Gmail auto-ingest — ingests sent messages and search results from Gmail."""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from memex.auto_ingest.base import IngestItem
from memex.knowledge_ingest_runs import (
    build_ingest_result,
    record_knowledge_ingest_projection,
    start_knowledge_ingest_run,
    update_knowledge_ingest_run,
)
from memex.models import ItemType
from memex.runtime_state import RuntimeStateRegistry
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

_URL_PATTERN = re.compile(r"https?://[^\s<>\"')]+", re.IGNORECASE)
_URL_REVIEW_THRESHOLD = 3


def extract_urls_from_body(body: str) -> list[str]:
    """Extract unique URLs from email body text, preserving order."""
    return list(dict.fromkeys(_URL_PATTERN.findall(body)))


def _message_to_ingest_item(
    msg: dict,
    *,
    tags: list[str] | None = None,
    title_prefix: str = "",
    source_url_prefix: str = "gmail://",
) -> IngestItem:
    """Convert a raw Gmail API message dict to an IngestItem."""
    subject = msg.get("subject", "(no subject)")
    return IngestItem(
        content=msg.get("body", ""),
        title=f"{title_prefix}{subject}",
        source_url=f"{source_url_prefix}{msg.get('id', '')}",
        item_type=ItemType.CONVERSATION,
        author=msg.get("from", msg.get("to", "")),
        tags=tags or ["gmail", "auto-ingest"],
    )


def post_process_urls(
    item: IngestItem,
    *,
    content_store: Any,
    memex_store: Any | None = None,
    embedding_backend: Any | None = None,
    notification_router: Any | None = None,
    session_id: str = "",
    trigger_surface: str = "tool",
) -> None:
    """Extract URLs from a Gmail item and either auto-ingest or create a review notification."""
    urls = extract_urls_from_body(item.content)
    if not urls:
        return

    if len(urls) <= _URL_REVIEW_THRESHOLD:
        from memex.memory.intake import ingest_from_url

        for url in urls:
            run = None
            try:
                if memex_store is not None:
                    run = start_knowledge_ingest_run(
                        memex_store,
                        ingest_kind="url",
                        trigger_surface=trigger_surface,
                        source_ref=url,
                        requested_item_type=ItemType.ARTICLE.value,
                        session_id=session_id,
                    )
                    run = update_knowledge_ingest_run(
                        memex_store,
                        run,
                        status="extracting",
                        phase="extracting",
                    )
                ingested_item = ingest_from_url(
                    url,
                    content_store=content_store,
                    memex_store=memex_store,
                    embedding_backend=embedding_backend,
                )
                if memex_store is not None and run is not None:
                    result = build_ingest_result(
                        ingested_item,
                        content_store=content_store,
                        world_model_store=memex_store,
                        source_ref=url,
                    )
                    run = update_knowledge_ingest_run(
                        memex_store,
                        run,
                        status="completed",
                        phase="completed",
                        result=result,
                        summary_model=ingested_item.summary.model
                        or "deterministic_extract",
                        payload_update={
                            "summary_mode": ingested_item.summary.model or "",
                        },
                        finished=True,
                    )
                    record_knowledge_ingest_projection(
                        memex_store,
                        run,
                        result=result,
                    )
            except ValueError:
                logger.info("Thin content from URL in email: %s", url)
                if memex_store is not None and run is not None:
                    fallback_result = _ingest_gmail_url_fallback(
                        url,
                        content_store=content_store,
                        memex_store=memex_store,
                        embedding_backend=embedding_backend,
                    )
                    run = update_knowledge_ingest_run(
                        memex_store,
                        run,
                        status="fallback_completed" if fallback_result else "failed",
                        phase="completed" if fallback_result else "failed",
                        result=fallback_result,
                        fallback_used=bool(fallback_result),
                        summary_model="deterministic_extract",
                        finished=True,
                    )
                    record_knowledge_ingest_projection(
                        memex_store,
                        run,
                        result=fallback_result,
                    )
            except Exception:
                logger.warning(
                    "Failed to ingest URL from email: %s", url, exc_info=True
                )
                if memex_store is not None and run is not None:
                    run = update_knowledge_ingest_run(
                        memex_store,
                        run,
                        status="failed",
                        phase="failed",
                        error="gmail embedded URL ingest failed",
                        summary_model="deterministic_extract",
                        finished=True,
                    )
                    record_knowledge_ingest_projection(memex_store, run)
    else:
        if notification_router is not None:
            from memex.models import NotificationPriority

            notification_router.notify(
                f"Email has {len(urls)} URLs to review",
                body=f"From: {item.title}\n\nURLs found:\n"
                + "\n".join(f"  {i + 1}. {u}" for i, u in enumerate(urls)),
                priority=NotificationPriority.NORMAL,
                source="gmail-auto-ingest",
                action_type="url_review",
                action_data={"urls": urls, "email_subject": item.title},
            )
        else:
            logger.warning(
                "Email '%s' has %d URLs but no notification_router to create review",
                item.title,
                len(urls),
            )


def ingest_gmail_item(
    item: IngestItem,
    *,
    content_store: Any,
    memex_store: Any | None = None,
    embedding_backend: Any | None = None,
    session_id: str = "",
    trigger_surface: str = "tool",
) -> Any:
    from memex.memory.intake import ingest

    run = None
    if memex_store is not None:
        run = start_knowledge_ingest_run(
            memex_store,
            ingest_kind="gmail",
            trigger_surface=trigger_surface,
            source_ref=item.source_url or item.title or "gmail",
            requested_item_type=item.item_type.value,
            session_id=session_id,
        )
        run = update_knowledge_ingest_run(
            memex_store,
            run,
            status="projecting",
            phase="projecting",
            payload_update={"summary_mode": "none"},
            summary_model="none",
        )
    ingested_item = ingest(
        item.content,
        type=item.item_type,
        title=item.title or None,
        source_url=item.source_url or None,
        author=item.author or None,
        tags=item.tags or None,
        content_store=content_store,
        memex_store=memex_store,
        embedding_backend=embedding_backend,
        generate_summary=False,
        session_id=session_id,
    )
    if memex_store is not None and run is not None:
        result = build_ingest_result(
            ingested_item,
            content_store=content_store,
            world_model_store=memex_store,
            source_ref=item.source_url or item.title or "gmail",
        )
        run = update_knowledge_ingest_run(
            memex_store,
            run,
            status="completed",
            phase="completed",
            result=result,
            summary_model="none",
            finished=True,
        )
        record_knowledge_ingest_projection(memex_store, run, result=result)
    return ingested_item


def _ingest_gmail_url_fallback(
    url: str,
    *,
    content_store: Any,
    memex_store: Any | None = None,
    embedding_backend: Any | None = None,
) -> dict[str, Any] | None:
    from memex.memory.intake import ingest

    item = ingest(
        url,
        type=ItemType.ARTICLE,
        title=url,
        source_url=url,
        content_store=content_store,
        memex_store=memex_store,
        embedding_backend=embedding_backend,
        generate_summary=False,
    )
    if memex_store is None:
        return None
    return build_ingest_result(
        item,
        content_store=content_store,
        world_model_store=memex_store,
        source_ref=url,
    )


def _process_gmail_audio_attachments(
    message_id: str,
    attachments: list[dict],
    *,
    content_store: Any,
    memex_store: Any | None = None,
    embedding_backend: Any | None = None,
    notification_router: Any | None = None,
    session_id: str = "",
    work_queue: Any | None = None,
    scheduler_store: Any | None = None,
) -> None:
    """Download, classify, and handle audio attachments from a Gmail message.

    Non-speech files: ingest tag metadata as NOTE, notify user, delete temp file.
    Speech files: routed to transcription pipeline if scheduler available.
    """
    import tempfile
    from pathlib import Path

    from memex.auto_ingest.audio_classify import build_discard_note, classify_audio
    from memex.integrations.gmail import GmailClient
    from memex.memory.intake import ingest
    from memex.models import ItemType

    try:
        client = GmailClient()
        client.authenticate()
    except Exception as exc:
        logger.warning("Cannot process Gmail audio attachments (auth failed): %s", exc)
        return

    for att in attachments:
        filename = att.get("filename", "attachment")
        attachment_id = att.get("attachment_id", "")
        if not attachment_id:
            continue

        suffix = Path(filename).suffix.lower() or ".bin"
        fd, tmp_name = tempfile.mkstemp(suffix=suffix)
        os.close(fd)
        tmp_path = Path(tmp_name)

        try:
            data = client.download_attachment(message_id, attachment_id)
            tmp_path.write_bytes(data)

            classified = classify_audio(tmp_path)

            if classified.is_speech:
                if work_queue is None or scheduler_store is None or memex_store is None:
                    logger.info(
                        "Gmail audio %s classified as speech — "
                        "no scheduler available, skipping transcription",
                        filename,
                    )
                else:
                    import shutil
                    import uuid
                    from pathlib import Path as _Path

                    from memex.meetings import submit_transcription
                    from memex.meetings.models import MeetingRecord, MeetingState
                    from memex.paths import resolve_store_path

                    meeting_id = str(uuid.uuid4())
                    now = utcnow()
                    audio_dir = _Path(resolve_store_path()).parent / "audio"
                    audio_dir.mkdir(parents=True, exist_ok=True)
                    stable_path = audio_dir / f"{meeting_id}{suffix}"
                    shutil.move(str(tmp_path), str(stable_path))
                    tmp_path = stable_path  # noqa: PLW2901

                    meeting_store = getattr(memex_store, "meetings", None)
                    if meeting_store is None:
                        logger.warning(
                            "Gmail audio %s skipped — no meeting store available",
                            filename,
                        )
                        continue
                    record = MeetingRecord(
                        meeting_id=meeting_id,
                        state=MeetingState.RECORDED,
                        title=f"Gmail voice — {now.strftime('%Y-%m-%d %H:%M')} ({filename})",
                        audio_path=str(stable_path),
                        started_at=now,
                        stopped_at=now,
                        notes=f"gmail://attachment/{message_id}/{attachment_id}",
                    )
                    meeting_store.create_meeting(record)
                    run_id = submit_transcription(
                        meeting_id, work_queue, scheduler_store
                    )
                    logger.info(
                        "Gmail audio %s queued for transcription (meeting %s, run %d)",
                        filename,
                        meeting_id[:8],
                        run_id,
                    )
                    if notification_router is not None:
                        from memex.models import NotificationPriority

                        notification_router.notify(
                            f"Voice memo queued: {filename}",
                            body=f"Gmail audio attachment transcription queued (run {run_id}).",
                            priority=NotificationPriority.NORMAL,
                            source="gmail:audio",
                        )
            else:
                label, content = build_discard_note(classified)
                try:
                    ingest(
                        content,
                        type=ItemType.NOTE,
                        title=label,
                        source_url=f"gmail://attachment/{message_id}/{attachment_id}",
                        tags=["audio-discard", "non-speech", "gmail"],
                        content_store=content_store,
                        memex_store=memex_store,
                        embedding_backend=embedding_backend,
                        generate_summary=False,
                        session_id=session_id,
                    )
                except Exception as exc:
                    logger.warning(
                        "Failed to ingest audio attachment metadata: %s", exc
                    )

                if notification_router is not None:
                    from memex.models import NotificationPriority

                    notification_router.notify(
                        f"Audio discarded: {label}",
                        body=(
                            f"{filename} (Gmail attachment on message {message_id}) "
                            f"was classified as non-voice audio "
                            f"(speech ratio: {classified.speech_ratio:.0%}) and discarded."
                        ),
                        priority=NotificationPriority.NORMAL,
                        source="gmail:audio",
                    )

        except Exception as exc:
            logger.warning(
                "Failed to process Gmail audio attachment %s: %s", filename, exc
            )
        finally:
            tmp_path.unlink(missing_ok=True)


@dataclass
class GmailIngestResult:
    """Result of ingesting Gmail messages."""

    total: int
    ingested: int


def ingest_gmail_messages(
    messages: list[dict],
    *,
    content_store: Any,
    memex_store: Any | None = None,
    embedding_backend: Any | None = None,
    notification_router: Any | None = None,
    tags: list[str] | None = None,
    title_prefix: str = "",
    source_url_prefix: str = "gmail://",
    session_id: str = "",
    activity_id: str | None = None,
    runtime_registry: RuntimeStateRegistry | None = None,
    trigger_surface: str = "tool",
    work_queue: Any | None = None,
    scheduler_store: Any | None = None,
) -> GmailIngestResult:
    """Convert raw Gmail messages to items, ingest them, and extract URLs from bodies.

    This is the shared ingest loop used by the builtin tool handler,
    the TUI /gmail command, and the scheduler auto-ingest registry.
    """
    from memex.telemetry import start_activity, update_activity

    activity = None
    owns_activity = activity_id is None
    if owns_activity:
        activity = start_activity(
            f"Ingesting Gmail batch ({len(messages)} messages)",
            source="gmail_ingest",
            session_id=session_id,
            background=True,
            runtime_registry=runtime_registry,
        )

    ingested = 0
    for index, m in enumerate(messages, start=1):
        if activity_id:
            update_activity(
                activity_id,
                f"Ingesting Gmail message {index}/{len(messages)}",
                source="gmail_ingest",
                session_id=session_id,
                background=True,
                runtime_registry=runtime_registry,
            )
        elif activity is not None:
            activity.update(f"Ingesting Gmail message {index}/{len(messages)}")
        item = _message_to_ingest_item(
            m,
            tags=tags,
            title_prefix=title_prefix,
            source_url_prefix=source_url_prefix,
        )
        try:
            ingest_gmail_item(
                item,
                content_store=content_store,
                memex_store=memex_store,
                embedding_backend=embedding_backend,
                session_id=session_id,
                trigger_surface=trigger_surface,
            )
            ingested += 1
        except Exception as exc:
            logger.warning("Failed to ingest Gmail message: %s", exc)
            continue

        post_process_urls(
            item,
            content_store=content_store,
            memex_store=memex_store,
            embedding_backend=embedding_backend,
            notification_router=notification_router,
            session_id=session_id,
            trigger_surface=trigger_surface,
        )

        audio_attachments = m.get("audio_attachments", [])
        if audio_attachments:
            _process_gmail_audio_attachments(
                m["id"],
                audio_attachments,
                content_store=content_store,
                memex_store=memex_store,
                embedding_backend=embedding_backend,
                notification_router=notification_router,
                session_id=session_id,
                work_queue=work_queue,
                scheduler_store=scheduler_store,
            )

    if owns_activity and activity is not None:
        activity.finish(label=f"Ingested Gmail batch: {ingested}/{len(messages)}")
    elif activity_id:
        update_activity(
            activity_id,
            f"Ingested Gmail batch: {ingested}/{len(messages)}",
            source="gmail_ingest",
            session_id=session_id,
            background=True,
            runtime_registry=runtime_registry,
        )

    return GmailIngestResult(total=len(messages), ingested=ingested)


class GmailAutoIngestSource:
    """Auto-ingest source for Gmail messages.

    Supports two modes:
    - Default: pulls sent messages
    - Query mode: runs a Gmail search query (set via configure())

    Requires Gmail integration to be configured (memex auth setup gmail).
    """

    def __init__(self) -> None:
        self._last_check: datetime | None = None
        self._query: str | None = None

    @property
    def name(self) -> str:
        return "gmail"

    @property
    def source_type(self) -> str:
        return "gmail"

    def configure(self, config: dict[str, Any]) -> None:
        self._query = config.get("query")
        if "last_check" in config:
            self._last_check = datetime.fromisoformat(config["last_check"])

    def fetch(self) -> list[IngestItem]:
        """Fetch messages from Gmail. Requires auth to be configured."""
        try:
            from memex.integrations.gmail import GmailClient
        except ImportError:
            raise RuntimeError(
                "Gmail integration not available. "
                "Install with: pip install memex-claw[google]"
            )

        try:
            client = GmailClient()
            client.authenticate()
        except RuntimeError:
            raise  # Auth errors already have clear messages
        except Exception as exc:
            raise RuntimeError(f"Gmail connection failed: {exc}") from exc

        if self._query:
            messages = client.search_messages(self._query)
            items = [
                _message_to_ingest_item(m, tags=["gmail", "search", "auto-ingest"])
                for m in messages
            ]
        else:
            messages = client.get_sent_messages(since=self._last_check)
            items = [
                _message_to_ingest_item(
                    m,
                    tags=["gmail", "sent", "auto-ingest"],
                    title_prefix="Sent: ",
                    source_url_prefix="gmail://sent/",
                )
                for m in messages
            ]

        self._last_check = utcnow()
        return items
