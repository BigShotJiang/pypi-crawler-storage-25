"""Auto-ingest source registry — manages sources and runs ingestion."""

from __future__ import annotations

import logging
from typing import Any

from memex.auto_ingest.base import AutoIngestSource, IngestItem
from memex.runtime_state import RuntimeStateRegistry

logger = logging.getLogger(__name__)


class SourceRegistry:
    """Registry of auto-ingest sources. Runs sources and pipes items through intake."""

    def __init__(self) -> None:
        self._sources: dict[str, AutoIngestSource] = {}

    def register(self, source: AutoIngestSource) -> None:
        """Register an auto-ingest source."""
        self._sources[source.name] = source

    def get_source(self, name: str) -> AutoIngestSource | None:
        return self._sources.get(name)

    def list_sources(self) -> list[str]:
        return list(self._sources.keys())

    def run_source(
        self,
        name: str,
        *,
        content_store: Any | None = None,
        memex_store: Any | None = None,
        embedding_backend: Any | None = None,
        notification_router: Any | None = None,
        session_id: str = "",
        runtime_registry: RuntimeStateRegistry | None = None,
        intake_store: Any | None = None,
    ) -> int:
        """Run a source and ingest all fetched items. Returns count of items ingested."""
        from memex.telemetry import start_activity

        source = self._sources.get(name)
        if source is None:
            raise ValueError(f"Unknown auto-ingest source: {name}")

        activity = start_activity(
            f"Auto-ingest: {name}",
            source=f"auto_ingest:{name}",
            session_id=session_id,
            background=True,
            runtime_registry=runtime_registry,
        )
        try:
            activity.update(f"Fetching from {name}")
            items = source.fetch()
        except Exception as exc:
            activity.finish(success=False, label=f"Auto-ingest failed: {name}")
            logger.error("Source %s fetch failed: %s", name, exc)
            raise

        if not items:
            activity.finish(label=f"Auto-ingest: {name} (0 items)")
            logger.debug("Source %s returned 0 items", name)
            return 0

        count = 0
        for index, item in enumerate(items, start=1):
            # Record intake for Gmail items so they can be replayed on failure
            intake_id: int | None = None
            if intake_store is not None and name == "gmail":
                from memex.models import ActionType

                try:
                    intake_id = intake_store.record(
                        "gmail",
                        ActionType.GMAIL_MESSAGE.value,
                        {
                            "source_url": item.source_url or "",
                            "title": item.title or "",
                            "content": item.content[:2000],
                            "item_type": item.item_type,
                            "author": item.author or "",
                            "metadata": item.metadata or {},
                        },
                    )
                except Exception:
                    logger.debug("Failed to record Gmail intake", exc_info=True)

            try:
                activity.update(f"Auto-ingest {name}: {index}/{len(items)}")
                self._ingest_item(
                    item,
                    content_store,
                    memex_store,
                    embedding_backend,
                    session_id,
                )
                count += 1
                if intake_id is not None:
                    try:
                        intake_store.mark_processed(intake_id)
                    except Exception:
                        logger.debug("Failed to mark intake processed", exc_info=True)
            except Exception as exc:
                logger.warning("Failed to ingest item from %s: %s", name, exc)
                if intake_id is not None:
                    try:
                        intake_store.mark_failed(intake_id, str(exc))
                    except Exception:
                        logger.debug("Failed to mark intake failed", exc_info=True)
                continue

            # Post-process Gmail items for URL extraction (see #39)
            if name == "gmail" and content_store is not None:
                from memex.auto_ingest.gmail import post_process_urls

                post_process_urls(
                    item,
                    content_store=content_store,
                    memex_store=memex_store,
                    embedding_backend=embedding_backend,
                    notification_router=notification_router,
                    session_id=session_id,
                    trigger_surface="gmail_auto_ingest",
                )

        logger.info("Ingested %d/%d items from %s", count, len(items), name)
        activity.finish(label=f"Auto-ingest {name}: {count}/{len(items)}")
        return count

    def _ingest_item(
        self,
        item: IngestItem,
        content_store: Any,
        memex_store: Any | None,
        embedding_backend: Any | None,
        session_id: str = "",
    ) -> None:
        """Pipe a single item through the intake pipeline."""
        if content_store is None:
            raise RuntimeError("content_store is required for auto-ingest")

        from memex.memory.intake import ingest

        if memex_store is not None and getattr(item, "source_url", "").startswith(
            "gmail://"
        ):
            from memex.auto_ingest.gmail import ingest_gmail_item

            ingest_gmail_item(
                item,
                content_store=content_store,
                memex_store=memex_store,
                embedding_backend=embedding_backend,
                session_id=session_id,
                trigger_surface="gmail_auto_ingest",
            )
            return

        ingest(
            item.content,
            type=item.item_type,
            title=item.title or None,
            source_url=item.source_url or None,
            author=item.author or None,
            tags=item.tags or None,
            content_store=content_store,
            memex_store=memex_store,
            embedding_backend=embedding_backend,
            generate_summary=False,
            session_id=session_id,
        )


def get_default_registry() -> SourceRegistry:
    """Create a registry with all available sources registered."""
    registry = SourceRegistry()

    # Watch folder (always available)
    try:
        from memex.auto_ingest.watch_folder import WatchFolderSource

        registry.register(WatchFolderSource())
    except Exception:
        pass

    # RSS (requires feedparser)
    try:
        from memex.auto_ingest.rss import RSSFeedSource

        registry.register(RSSFeedSource())
    except ImportError:
        pass

    # Gmail (skeleton — will raise on fetch if not configured)
    try:
        from memex.auto_ingest.gmail import GmailAutoIngestSource

        registry.register(GmailAutoIngestSource())
    except Exception:
        pass

    return registry
