"""Audio classification — speech vs. non-speech detection using Silero VAD.

Called at every entry point where an audio file arrives (Telegram voice/audio
messages, Gmail audio attachments, etc.) before any transcription or ingestion
is attempted.

Uses faster-whisper's bundled Silero VAD model (already a project dependency).
No additional downloads required after the first transcription run, which
caches the ONNX model in ~/.cache/huggingface/.

Speech path (is_speech=True): stub — callers log a notice and the file is
held for a future iteration that will route to orchestrate_transcription().

Non-speech path: callers ingest the VAD findings + tags as a NOTE, notify
the user, and delete the file.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# Extensions this classifier handles
AUDIO_EXTENSIONS = {".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac"}

# Fraction of audio frames flagged as voice-active to consider the file speech
_SPEECH_THRESHOLD = 0.30


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class AudioTags:
    """Metadata tags extracted from an audio file."""

    title: str = ""
    artist: str = ""
    album: str = ""
    year: str = ""
    genre: str = ""
    duration_seconds: float = 0.0
    format: str = ""


@dataclass
class AudioClassification:
    """Result of classifying an audio file as speech or non-speech."""

    path: Path
    is_speech: bool
    speech_ratio: float  # 0.0–1.0 fraction of frames with voice activity
    vad_available: bool  # False → VAD failed; is_speech defaults to False
    tags: AudioTags = field(default_factory=AudioTags)


# ---------------------------------------------------------------------------
# Tag extraction
# ---------------------------------------------------------------------------


def _extract_tags(path: Path) -> AudioTags:
    """Extract ID3/Vorbis tags.  Tries mutagen, then ID3v1 fallback for MP3."""
    tags = AudioTags(format=path.suffix.lower().lstrip("."))

    # mutagen is not a required dependency — use it if present
    try:
        import mutagen  # type: ignore[import-untyped]

        f = mutagen.File(path, easy=True)
        if f is not None:
            tags.duration_seconds = getattr(getattr(f, "info", None), "length", 0.0)
            tags.title = (f.get("title") or [""])[0]
            tags.artist = (f.get("artist") or [""])[0]
            tags.album = (f.get("album") or [""])[0]
            tags.year = (f.get("date") or [""])[0]
            tags.genre = (f.get("genre") or [""])[0]
        return tags
    except ImportError:
        pass
    except Exception as exc:
        logger.debug("mutagen failed for %s: %s", path.name, exc)

    # ID3v1 stdlib fallback for MP3 (magic "TAG" in last 128 bytes)
    if path.suffix.lower() == ".mp3":
        try:
            data = path.read_bytes()[-128:]
            if data[:3] == b"TAG":

                def _s(b: bytes) -> str:
                    return b.rstrip(b"\x00").decode("latin-1", errors="replace").strip()

                tags.title = _s(data[3:33])
                tags.artist = _s(data[33:63])
                tags.album = _s(data[63:93])
                tags.year = _s(data[93:97])
        except Exception as exc:
            logger.debug("ID3v1 fallback failed for %s: %s", path.name, exc)
    else:
        # soundfile can read duration for WAV / FLAC / OGG / AIFF
        try:
            import soundfile as sf  # type: ignore[import-untyped]

            tags.duration_seconds = sf.info(str(path)).duration
        except Exception:
            pass

    return tags


# ---------------------------------------------------------------------------
# VAD
# ---------------------------------------------------------------------------


def _run_vad(path: Path) -> tuple[float, bool]:
    """Return (speech_ratio, vad_available) via Silero VAD."""
    try:
        import soundfile as sf

        from memex.meetings.vad import speech_timestamps

        data, sr = sf.read(str(path), dtype="float32", always_2d=False)
        if data.ndim == 2:
            data = data.mean(axis=1)
        if sr != 16000:
            import numpy as np
            from scipy.signal import resample_poly

            data = resample_poly(data, 16000, sr).astype(np.float32)
        total = len(data)
        if total == 0:
            return 0.0, True
        timestamps = speech_timestamps(data, threshold=0.5, sampling_rate=16000)
        voiced = sum(t["end"] - t["start"] for t in timestamps)
        return float(voiced) / total, True

    except Exception as exc:
        logger.debug("Silero VAD failed for %s: %s", path.name, exc)
        return 0.0, False


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_discard_note(classified: AudioClassification) -> tuple[str, str]:
    """Return (title, content) for ingesting a discarded non-speech audio file.

    The caller is responsible for deleting the file and sending the user
    notification — this function only builds the storable metadata text.
    """
    tags = classified.tags
    label = " – ".join(filter(None, [tags.artist, tags.title])) or classified.path.stem

    lines = [
        f"# {label}",
        "",
        f"Audio file discarded as non-voice content "
        f"(speech ratio: {classified.speech_ratio:.0%}).",
        "",
        "## Tags",
    ]
    for key, val in [
        ("Artist", tags.artist),
        ("Title", tags.title),
        ("Album", tags.album),
        ("Year", tags.year),
        ("Genre", tags.genre),
        ("Format", tags.format),
        ("Duration", f"{tags.duration_seconds:.1f}s" if tags.duration_seconds else ""),
    ]:
        if val:
            lines.append(f"- **{key}**: {val}")

    if classified.vad_available:
        lines.append(f"- **VAD speech ratio**: {classified.speech_ratio:.1%}")
    else:
        lines.append("- **VAD**: unavailable — classified as non-speech by default")

    return label, "\n".join(lines)


def classify_audio(path: Path) -> AudioClassification:
    """Classify an audio file as speech or non-speech.

    Speech ratio is the fraction of audio frames flagged as voice-active by
    Silero VAD.  Files with ratio >= _SPEECH_THRESHOLD are treated as speech
    (meetings / voice memos).  If VAD is unavailable the file is conservatively
    classified as non-speech.
    """
    tags = _extract_tags(path)
    speech_ratio, vad_available = _run_vad(path)
    is_speech = vad_available and speech_ratio >= _SPEECH_THRESHOLD

    logger.debug(
        "classify_audio %s: ratio=%.2f is_speech=%s vad=%s",
        path.name,
        speech_ratio,
        is_speech,
        vad_available,
    )
    return AudioClassification(
        path=path,
        is_speech=is_speech,
        speech_ratio=speech_ratio,
        vad_available=vad_available,
        tags=tags,
    )
