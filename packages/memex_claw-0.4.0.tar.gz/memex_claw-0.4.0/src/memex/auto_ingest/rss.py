"""RSS feed auto-ingest — fetches and ingests articles from RSS feeds."""

from __future__ import annotations

import logging
from typing import Any

from memex.auto_ingest.base import IngestItem
from memex.models import ItemType

logger = logging.getLogger(__name__)


class RSSFeedSource:
    """Auto-ingest source for RSS feeds."""

    def __init__(self, feed_urls: list[str] | None = None) -> None:
        self._feed_urls: list[str] = feed_urls or []

    @property
    def name(self) -> str:
        return "rss"

    @property
    def source_type(self) -> str:
        return "rss"

    def configure(self, config: dict[str, Any]) -> None:
        if "feed_urls" in config:
            self._feed_urls = config["feed_urls"]

    def fetch(self) -> list[IngestItem]:
        """Fetch entries from all configured feeds."""
        try:
            import feedparser
        except ImportError:
            raise ImportError(
                "feedparser is required for RSS auto-ingest. "
                "Install with: pip install memex-claw"
            )

        if not self._feed_urls:
            return []

        items: list[IngestItem] = []
        for url in self._feed_urls:
            try:
                feed = feedparser.parse(url)
                for entry in feed.entries:
                    title = getattr(entry, "title", "")
                    link = getattr(entry, "link", "")
                    summary = getattr(entry, "summary", "")
                    author = getattr(entry, "author", "")
                    content = summary or getattr(entry, "description", "")

                    if not content and not title:
                        continue

                    items.append(
                        IngestItem(
                            content=content,
                            title=title,
                            source_url=link,
                            item_type=ItemType.ARTICLE,
                            author=author,
                            tags=["auto-ingest", "rss"],
                        )
                    )
            except Exception as exc:
                logger.warning("Failed to fetch RSS feed %s: %s", url, exc)

        return items
