"""Watch folder auto-ingest — polls ~/.memex/inbox/ for files to ingest."""

from __future__ import annotations

import logging
import shutil
from pathlib import Path
from typing import Any

from memex.auto_ingest.base import IngestItem
from memex.models import ItemType

logger = logging.getLogger(__name__)

# Supported file extensions
_SUPPORTED_EXTENSIONS = {".txt", ".md", ".html", ".json"}

# Type mapping by extension
_TYPE_MAP = {
    ".txt": ItemType.NOTE,
    ".md": ItemType.NOTE,
    ".html": ItemType.ARTICLE,
    ".json": ItemType.NOTE,
}


class WatchFolderSource:
    """Auto-ingest source that watches a folder for new files."""

    def __init__(self, inbox_path: Path | None = None) -> None:
        self._inbox = inbox_path or Path.home() / ".memex" / "inbox"
        self._processed = self._inbox / ".processed"

    @property
    def name(self) -> str:
        return "watch_folder"

    @property
    def source_type(self) -> str:
        return "watch_folder"

    def configure(self, config: dict[str, Any]) -> None:
        if "inbox_path" in config:
            self._inbox = Path(config["inbox_path"])
            self._processed = self._inbox / ".processed"

    def fetch(self) -> list[IngestItem]:
        """Scan inbox folder for supported files, return items, move to .processed/."""
        if not self._inbox.exists():
            return []

        self._processed.mkdir(parents=True, exist_ok=True)

        items: list[IngestItem] = []
        for path in sorted(self._inbox.iterdir()):
            if path.is_dir() or path.is_symlink():
                continue
            if path.suffix.lower() not in _SUPPORTED_EXTENSIONS:
                continue
            if path.name.startswith("."):
                continue

            try:
                content = path.read_text(encoding="utf-8")
                title = path.stem.replace("_", " ").replace("-", " ")
                item_type = _TYPE_MAP.get(path.suffix.lower(), ItemType.NOTE)

                items.append(
                    IngestItem(
                        content=content,
                        title=title,
                        source_url=f"file://{path}",
                        item_type=item_type,
                        tags=["auto-ingest", "watch-folder"],
                    )
                )

                # Move to processed
                dest = self._processed / path.name
                shutil.move(str(path), str(dest))
                logger.debug("Processed file: %s", path.name)
            except Exception as exc:
                logger.warning("Failed to process %s: %s", path, exc)

        return items
