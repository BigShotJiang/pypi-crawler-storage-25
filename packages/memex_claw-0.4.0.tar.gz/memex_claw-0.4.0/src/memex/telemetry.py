"""Shared activity and usage telemetry for non-turn work."""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass

from memex.event_bus import safe_publish
from memex.events import (
    ActivityFinished,
    ActivityStarted,
    ActivityUpdated,
    UsageRecorded,
)
from memex.runtime_state import RuntimeStateRegistry

logger = logging.getLogger(__name__)


def record_usage(
    *,
    cost_usd: float = 0.0,
    total_tokens: int = 0,
    session_id: str = "",
    source: str = "",
) -> None:
    """Record usage outside the normal run_turn middleware path."""
    if cost_usd <= 0 and total_tokens <= 0:
        return

    safe_publish(
        UsageRecorded(
            session_id=session_id,
            source=source,
            cost_usd=cost_usd,
            total_tokens=total_tokens,
        )
    )


@dataclass
class ActivityHandle:
    """Mutable handle for a long-running activity."""

    activity_id: str
    label: str
    source: str = ""
    session_id: str = ""
    background: bool = True
    runtime_registry: RuntimeStateRegistry | None = None
    _finished: bool = False

    def update(self, label: str) -> None:
        self.label = label
        registry = self.runtime_registry
        if registry is not None:
            registry.update_activity(self.activity_id, label=label)
        safe_publish(
            ActivityUpdated(
                activity_id=self.activity_id,
                label=label,
                source=self.source,
                session_id=self.session_id,
                background=self.background,
            )
        )

    def finish(self, *, success: bool = True, label: str = "") -> None:
        if self._finished:
            return
        self._finished = True
        final_label = label or self.label
        registry = self.runtime_registry
        if registry is not None:
            registry.finish_activity(
                self.activity_id,
                success=success,
                label=final_label,
            )
        safe_publish(
            ActivityFinished(
                activity_id=self.activity_id,
                label=final_label,
                source=self.source,
                session_id=self.session_id,
                background=self.background,
                success=success,
            )
        )


def start_activity(
    label: str,
    *,
    source: str = "",
    session_id: str = "",
    background: bool = True,
    runtime_registry: RuntimeStateRegistry | None = None,
) -> ActivityHandle:
    """Publish a start event and return a handle for updates/completion."""
    activity_id = str(uuid.uuid4())
    registry = runtime_registry
    if registry is not None:
        registry.start_activity(
            activity_id,
            label=label,
            source=source,
            session_id=session_id,
            background=background,
        )
    safe_publish(
        ActivityStarted(
            activity_id=activity_id,
            label=label,
            source=source,
            session_id=session_id,
            background=background,
        )
    )
    return ActivityHandle(
        activity_id=activity_id,
        label=label,
        source=source,
        session_id=session_id,
        background=background,
        runtime_registry=runtime_registry,
    )


def update_activity(
    activity_id: str,
    label: str,
    *,
    source: str = "",
    session_id: str = "",
    background: bool = True,
    runtime_registry: RuntimeStateRegistry | None = None,
) -> None:
    """Publish a point-in-time activity update without a retained handle."""
    registry = runtime_registry
    if registry is not None:
        registry.update_activity(activity_id, label=label)
    safe_publish(
        ActivityUpdated(
            activity_id=activity_id,
            label=label,
            source=source,
            session_id=session_id,
            background=background,
        )
    )


def finish_activity(
    activity_id: str,
    *,
    label: str = "",
    source: str = "",
    session_id: str = "",
    background: bool = True,
    success: bool = True,
    runtime_registry: RuntimeStateRegistry | None = None,
) -> None:
    """Publish a point-in-time activity completion without a retained handle."""
    registry = runtime_registry
    if registry is not None:
        registry.finish_activity(activity_id, success=success, label=label)
    safe_publish(
        ActivityFinished(
            activity_id=activity_id,
            label=label,
            source=source,
            session_id=session_id,
            background=background,
            success=success,
        )
    )
