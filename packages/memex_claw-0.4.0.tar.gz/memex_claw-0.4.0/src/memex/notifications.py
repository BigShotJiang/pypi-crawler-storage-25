"""Notification routing — priority batching and channel dispatch.

The live notification store is FathomNotificationAdapter (in fathom_facade.py).
NotificationRouter is used throughout the codebase to create and route notifications.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any

from memex.models import Notification, NotificationPriority
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)


class NotificationRouter:
    """Routes notifications to the appropriate channel based on priority and active interface."""

    def __init__(self, store: Any) -> None:
        self._store = store
        self._channels: dict[str, Any] = {}  # interface_name -> channel handler

    def register_channel(self, name: str, channel: Any) -> None:
        """Register a notification delivery channel."""
        self._channels[name] = channel

    def notify(
        self,
        title: str,
        *,
        body: str = "",
        priority: NotificationPriority = NotificationPriority.NORMAL,
        source: str = "",
        goal_id: str | None = None,
        action_type: str | None = None,
        action_data: dict[str, Any] | None = None,
    ) -> Notification:
        """Create and route a notification."""
        notification = Notification(
            notification_id=str(uuid.uuid4()),
            title=title,
            body=body,
            priority=priority,
            source=source,
            goal_id=goal_id,
            created_at=utcnow(),
            action_type=action_type,
            action_data=action_data or {},
        )
        self._store.create(notification)
        logger.info("Notification created: [%s] %s", priority.value, title)

        try:
            from memex.event_bus import get_bus
            from memex.events import NotificationCreated as NotifEvent

            get_bus().publish(
                NotifEvent(
                    notification_id=notification.notification_id,
                    title=title,
                    priority=priority.value,
                    source=source,
                )
            )
        except Exception:
            pass

        return notification
