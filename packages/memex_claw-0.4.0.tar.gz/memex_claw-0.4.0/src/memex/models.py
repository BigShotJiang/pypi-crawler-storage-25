"""All Pydantic schemas for Memex — single source of truth."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Turn events — lightweight frozen dataclasses for callback-driven UX
# ---------------------------------------------------------------------------


class TurnCancelled(Exception):
    """Raised to abort a turn in progress (e.g. user pressed Escape)."""


@dataclass(frozen=True)
class TurnEvent:
    """Base class for events emitted during run_turn()."""


@dataclass(frozen=True)
class TurnPhase(TurnEvent):
    """Emitted when the turn enters a new phase (classifying, thinking, reflecting)."""

    phase: str
    model: str = ""


@dataclass(frozen=True)
class ToolCallStarted(TurnEvent):
    """Emitted when a tool call begins."""

    tool_name: str
    arguments: dict = field(default_factory=dict)


@dataclass(frozen=True)
class ToolCallCompleted(TurnEvent):
    """Emitted when a tool call finishes."""

    tool_name: str
    success: bool
    duration_ms: int
    summary: str = ""


@dataclass(frozen=True)
class TurnCompleted(TurnEvent):
    """Emitted at the end of a turn with aggregate stats."""

    duration_ms: int
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    cost_usd: float
    model: str
    tool_call_count: int
    route_profile: str = ""
    prompt_mode: str = "full"


# ---------------------------------------------------------------------------
# Goal
# ---------------------------------------------------------------------------


class GoalStatus(str, Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    ABANDONED = "abandoned"
    BLOCKED = "blocked"
    FAILED = "failed"


class GoalPriority(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


PRIORITY_WEIGHTS: dict[GoalPriority, float] = {
    GoalPriority.CRITICAL: 1.0,
    GoalPriority.HIGH: 0.75,
    GoalPriority.MEDIUM: 0.5,
    GoalPriority.LOW: 0.25,
}


class Goal(BaseModel):
    goal_id: str
    parent_id: str | None = None
    title: str
    description: str = ""
    status: GoalStatus = GoalStatus.ACTIVE
    priority: GoalPriority = GoalPriority.MEDIUM
    blocked_by_goal_id: str | None = None
    blocked_reason: str | None = None
    failure_reason: str | None = None
    created_at: datetime
    updated_at: datetime
    last_touched_at: datetime
    deadline: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class GoalEntityLink(BaseModel):
    goal_id: str
    entity_id: str
    relationship: str = "related"
    created_at: datetime


class MeetingGoalLink(BaseModel):
    meeting_id: str
    goal_id: str
    relationship: str = "explicit"
    created_at: datetime


class MeetingEntityLink(BaseModel):
    meeting_id: str
    entity_id: str
    relationship: str = "attendee"
    created_at: datetime


class CalendarEvent(BaseModel):
    event_id: str
    provider: str
    title: str
    starts_at: datetime
    ends_at: datetime | None = None
    attendees: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    synced_at: datetime


# ---------------------------------------------------------------------------
# Input classification (LLM call #1)
# ---------------------------------------------------------------------------


class InputClassificationType(str, Enum):
    ADVANCES_GOAL = "advances_goal"
    NEW_GOAL = "new_goal"
    CONVERSATIONAL = "conversational"
    CLARIFICATION = "clarification"
    KNOWLEDGE_QUERY = "knowledge_query"


class InputClassification(BaseModel):
    classification: InputClassificationType
    goal_id: str | None = None
    confidence: float = 0.0
    reasoning: str = ""
    suggested_title: str = ""


class IntentFramePath(str, Enum):
    ACT = "act"
    DIRECT_ANSWER = "direct_answer"
    CLARIFY = "clarify"
    ABSTAIN = "abstain"


class IntentSlotState(BaseModel):
    name: str
    status: str = "resolved"
    description: str = ""
    value: str | None = None
    source: str | None = None
    required: bool = False


class IntentActionCandidate(BaseModel):
    name: str
    kind: str = "response_path"
    selected: bool = False
    rationale: str | None = None
    tool_candidates: list[str] = Field(default_factory=list)
    required_slots: list[str] = Field(default_factory=list)
    unresolved_required_slots: list[str] = Field(default_factory=list)


class IntentFrame(BaseModel):
    raw_input: str
    classification: InputClassificationType
    goal_id: str | None = None
    summary: str = ""
    selected_path: IntentFramePath = IntentFramePath.DIRECT_ANSWER
    selected_action_candidate: IntentActionCandidate | None = None
    unresolved_references: list[str] = Field(default_factory=list)
    missing_information: list[str] = Field(default_factory=list)
    slot_states: list[IntentSlotState] = Field(default_factory=list)
    confidence: float = 0.0
    rationale: str = ""
    created_at: datetime


# ---------------------------------------------------------------------------
# Prompt control (0.8 migration control-plane slice)
# ---------------------------------------------------------------------------


class PromptControlRouteProfile(str, Enum):
    ANALYTIC_STRICT = "analytic_strict"
    CREATIVE_OPEN = "creative_open"
    OPERATIONAL_TOOL = "operational_tool"
    RESEARCH_VERIFIED = "research_verified"
    SOCIAL_DRAFT = "social_draft"
    GUARDED_REVIEW = "guarded_review"


class PromptControlLintWarning(BaseModel):
    warning_type: str
    severity: Literal["low", "medium", "high"] = "low"
    message: str


class PromptControlPlanStepSnapshot(BaseModel):
    step_id: str
    step_kind: str
    title: str
    status: str
    progress_pct: int = 0
    blocked_reason: str = ""


class PromptControlPlanSnapshot(BaseModel):
    goal_id: str | None = None
    plan_id: str
    title: str
    status: str
    selected_step: PromptControlPlanStepSnapshot | None = None


class PromptControlArtifact(BaseModel):
    artifact_id: str
    session_id: str
    intent_id: str | None = None
    conversation_turn_id: int | None = None
    raw_input: str
    classification: str
    selected_path: str
    route_profile: PromptControlRouteProfile
    tool_policy: str
    validation_policy: str
    memory_policy: str
    response_contract: str
    route_rationale: str = ""
    parse_confidence: float = 0.0
    ambiguity_score: float = 0.0
    stylization_drift: float = 0.0
    high_stakes: bool = False
    detected_signals: list[str] = Field(default_factory=list)
    plan_snapshot: PromptControlPlanSnapshot | None = None
    tool_candidate_names: list[str] = Field(default_factory=list)
    lint_warnings: list[PromptControlLintWarning] = Field(default_factory=list)
    parser_version: str = "pc.v1"
    routing_version: str = "pc.v1"
    source_surface: str = "c03_c06_prompt_control"
    prompt_mode: str = "full"
    created_at: datetime
    updated_at: datetime


# ---------------------------------------------------------------------------
# Reflection (LLM call #3)
# ---------------------------------------------------------------------------


class NewSubgoal(BaseModel):
    parent_id: str
    title: str
    description: str = ""
    priority: GoalPriority = GoalPriority.MEDIUM


class GoalBlock(BaseModel):
    goal_id: str
    reason: str


class GoalFail(BaseModel):
    goal_id: str
    reason: str


class ObservedPreference(BaseModel):
    """A user preference observed during the conversation."""

    attribute: str  # e.g. "communication_style", "preferred_language"
    value: str  # e.g. "concise", "python"
    confidence: float = 0.5
    source: str = "single_observation"  # "explicit_statement", "repeated_pattern", "single_observation", "correction"


class ObservedConstraint(BaseModel):
    """A rule the user stated during the conversation."""

    rule: str  # e.g. "never auto-commit"
    reason: str = ""


class ObservedRejection(BaseModel):
    """An approach that was tried and didn't work or was rejected."""

    approach: str  # what was tried
    reason: str  # why it failed or was rejected
    context: str = ""  # optional additional context


class ObservedRetrievalFeedback(BaseModel):
    """User feedback about retrieved knowledge — positive or negative."""

    topic: str  # what the retrieval was about
    feedback: str  # "positive" or "negative"
    detail: str = ""  # optional: what was good/bad about it


class ReflectResult(BaseModel):
    intent_advanced: list[str] = Field(default_factory=list)
    new_subgoals: list[NewSubgoal] = Field(default_factory=list)
    goals_to_complete: list[str] = Field(default_factory=list)
    goals_to_pause: list[str] = Field(default_factory=list)
    goals_to_block: list[GoalBlock] = Field(default_factory=list)
    goals_to_fail: list[GoalFail] = Field(default_factory=list)
    confidence: float = 0.0
    reflection_note: str = ""
    session_context_update: dict[str, Any] = Field(default_factory=dict)

    # Layer 2 observations — detected by the LLM during reflection
    observed_preferences: list[ObservedPreference] = Field(default_factory=list)
    observed_constraints: list[ObservedConstraint] = Field(default_factory=list)
    rejected_approaches: list[ObservedRejection] = Field(default_factory=list)
    retrieval_feedback: list[ObservedRetrievalFeedback] = Field(default_factory=list)
    insight: str = ""  # cross-turn pattern noticed (empty = none)
    topic_shift: str = ""  # new topic if user changed domains (empty = none)


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------


class ConversationTurn(BaseModel):
    role: Literal["human", "assistant", "system", "tool_result"]
    content: str
    timestamp: datetime
    classification: InputClassification | None = None
    reflect_result: ReflectResult | None = None


class SessionContext(BaseModel):
    session_id: str
    started_at: datetime
    ended_at: datetime | None = None
    turn_count: int = 0
    working_memory: dict[str, Any] = Field(default_factory=dict)
    active_task_context: str | None = None
    conversation_history: list[ConversationTurn] = Field(default_factory=list)
    conversation_summary: str = ""
    last_classification: InputClassification | None = None
    last_intent_frame: IntentFrame | None = None
    last_prompt_control: PromptControlArtifact | None = None
    last_reflect: ReflectResult | None = None
    # Cache breakpoint state (used by MessageBuilder)
    cache_breakpoint: int = 0
    turns_since_cache_write: int = 0
    last_knowledge_hash: str | None = None


class HumanWorkingContext(BaseModel):
    timezone: str | None = None
    role: str = ""
    team: str = ""
    speaker_mappings: dict[str, str] = Field(default_factory=dict)


class HumanKnowledgeProfile(BaseModel):
    preferences: dict[str, str] = Field(default_factory=dict)
    notes: list[str] = Field(default_factory=list)
    expertise: list[str] = Field(default_factory=list)


class HumanPartnerProfile(BaseModel):
    partner_id: str = "default"
    name: str = ""
    communication_style: str = ""
    explanation_level: str = ""
    working_context: HumanWorkingContext = Field(default_factory=HumanWorkingContext)
    knowledge_profile: HumanKnowledgeProfile = Field(
        default_factory=HumanKnowledgeProfile
    )
    updated_at: datetime | None = None


class AgentCapability(BaseModel):
    capability_id: str
    title: str
    status: Literal["available", "degraded", "unavailable"] = "available"
    detail: str = ""
    source: str = ""
    updated_at: datetime | None = None


class AgentLimitation(BaseModel):
    limitation_id: str
    title: str
    detail: str = ""
    severity: Literal["info", "warn", "error"] = "info"
    recoverable: bool = True
    source: str = ""
    updated_at: datetime | None = None


class AgentSelfModel(BaseModel):
    agent_id: str = "memex"
    display_name: str = "Memex"
    capabilities: list[AgentCapability] = Field(default_factory=list)
    limitations: list[AgentLimitation] = Field(default_factory=list)
    degraded_modes: list[str] = Field(default_factory=list)
    operational_state: dict[str, Any] = Field(default_factory=dict)
    last_diagnostics: dict[str, Any] = Field(default_factory=dict)
    last_repair: dict[str, Any] = Field(default_factory=dict)
    updated_at: datetime | None = None


# ---------------------------------------------------------------------------
# World-model backbone (0.8 migration sidecar)
# ---------------------------------------------------------------------------


class WorldModelEntityType(str, Enum):
    HUMAN_PARTNER = "human_partner"
    AGENT_SELF = "agent_self"
    KNOWLEDGE_ENTITY = "knowledge_entity"


class WorldModelEntity(BaseModel):
    entity_id: str
    entity_type: WorldModelEntityType
    canonical_key: str
    display_name: str = ""
    status: str = "active"
    confidence: float = 1.0
    source_surface: str = ""
    created_at: datetime
    updated_at: datetime


class WorldModelEntityAttribute(BaseModel):
    attribute_id: str
    entity_id: str
    attribute_group: str
    attribute_key: str
    value_text: str | None = None
    value_json: Any | None = None
    confidence: float = 1.0
    provenance_kind: str = ""
    provenance_ref: str = ""
    observed_at: datetime
    updated_at: datetime


class WorldModelIntent(BaseModel):
    intent_id: str
    session_id: str
    goal_id: str | None = None
    conversation_turn_id: int | None = None
    raw_input: str
    classification: str
    selected_path: str
    summary: str = ""
    rationale: str = ""
    confidence: float = 0.0
    status: str = "proposed"
    unresolved_references: list[str] = Field(default_factory=list)
    missing_information: list[str] = Field(default_factory=list)
    source_surface: str = "c03_intent_frame"
    created_at: datetime
    updated_at: datetime


class WorldModelAction(BaseModel):
    action_id: str
    session_id: str | None = None
    meeting_id: str | None = None
    intent_id: str | None = None
    prompt_control_artifact_id: str | None = None
    conversation_turn_id: int | None = None
    action_kind: str
    action_name: str
    status: str = "active"
    payload: dict[str, Any] = Field(default_factory=dict)
    source_surface: str = ""
    created_at: datetime
    updated_at: datetime


class WorldModelObservation(BaseModel):
    observation_id: str
    session_id: str | None = None
    meeting_id: str | None = None
    action_id: str
    observation_kind: str
    summary: str = ""
    status: str = "observed"
    payload: dict[str, Any] = Field(default_factory=dict)
    source_surface: str = ""
    created_at: datetime
    updated_at: datetime


class WorldModelEvent(BaseModel):
    event_id: str
    session_id: str | None = None
    meeting_id: str | None = None
    conversation_turn_id: int | None = None
    event_kind: str
    title: str
    summary: str = ""
    payload: dict[str, Any] = Field(default_factory=dict)
    source_surface: str = ""
    created_at: datetime
    updated_at: datetime


class WorldModelActionPlan(BaseModel):
    plan_id: str
    goal_id: str | None = None
    title: str
    summary: str = ""
    status: str = "active"
    selected_step_id: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
    source_surface: str = ""
    created_at: datetime
    updated_at: datetime


class WorldModelPlanStep(BaseModel):
    step_id: str
    plan_id: str
    goal_id: str | None = None
    step_kind: str
    title: str
    description: str = ""
    status: str = "active"
    ordinal: int = 0
    blocked_reason: str = ""
    progress_pct: int = 0
    depends_on_step_ids: list[str] = Field(default_factory=list)
    blocked_by_step_ids: list[str] = Field(default_factory=list)
    payload: dict[str, Any] = Field(default_factory=dict)
    source_surface: str = ""
    created_at: datetime
    updated_at: datetime


class WorldModelExecutionRecord(BaseModel):
    execution_id: str
    session_id: str
    conversation_turn_id: int | None = None
    goal_id: str | None = None
    plan_id: str | None = None
    step_id: str | None = None
    execution_kind: str
    title: str
    summary: str = ""
    status: str = ""
    source_record_type: str
    source_record_id: str
    payload: dict[str, Any] = Field(default_factory=dict)
    source_surface: str = ""
    created_at: datetime
    updated_at: datetime


class WorldModelPlanStepTransition(BaseModel):
    transition_id: str
    step_id: str
    plan_id: str
    goal_id: str | None = None
    execution_id: str | None = None
    transition_kind: str
    from_status: str | None = None
    to_status: str | None = None
    blocked_reason: str | None = None
    blocked_by_step_ids: list[str] | None = None
    progress_pct: int | None = None
    summary: str = ""
    payload: dict[str, Any] = Field(default_factory=dict)
    source_surface: str = ""
    created_at: datetime
    updated_at: datetime


class WorldModelKnowledgeIngestRun(BaseModel):
    ingest_run_id: str
    ingest_kind: str
    trigger_surface: str
    session_id: str | None = None
    source_ref: str
    normalized_source_ref: str
    requested_item_type: str
    status: str
    phase: str
    fallback_used: bool = False
    item_id: str | None = None
    knowledge_id: str | None = None
    summary_model: str = ""
    error: str = ""
    payload: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime
    finished_at: datetime | None = None


class WorldModelGoal(BaseModel):
    goal_id: str
    parent_goal_id: str | None = None
    title: str
    description: str = ""
    status: str = "active"
    priority: str = "medium"
    blocked_by_goal_id: str | None = None
    blocked_reason: str = ""
    failure_reason: str = ""
    deadline_text: str = ""
    payload: dict[str, Any] = Field(default_factory=dict)
    source_surface: str = ""
    created_at: datetime
    updated_at: datetime


class WorldModelTask(BaseModel):
    task_id: str
    scheduled_task_id: str | None = None
    goal_id: str | None = None
    task_kind: str
    title: str
    description: str = ""
    status: str = "active"
    due_at: datetime | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
    source_surface: str = ""
    created_at: datetime
    updated_at: datetime


class WorldModelCommitment(BaseModel):
    commitment_id: str
    source_record_type: str = ""
    source_record_id: str = ""
    meeting_id: str | None = None
    semantic_item_id: str | None = None
    goal_id: str | None = None
    title: str
    description: str = ""
    assignee: str = ""
    deadline_text: str = ""
    agreed_by: str = ""
    status: str = "active"
    payload: dict[str, Any] = Field(default_factory=dict)
    source_surface: str = ""
    created_at: datetime
    updated_at: datetime


class WorldModelClaimEvaluation(BaseModel):
    evaluation_id: str
    knowledge_id: str
    item_id: str
    evaluation_kind: str
    title: str
    summary: str = ""
    status: str = "active"
    payload: dict[str, Any] = Field(default_factory=dict)
    source_surface: str = ""
    created_at: datetime
    updated_at: datetime


class WorldModelProvenanceLink(BaseModel):
    link_id: str
    source_record_type: str
    source_record_id: str
    target_record_type: str
    target_record_id: str
    relationship: str
    created_at: datetime


class WorldModelKnowledgeObject(BaseModel):
    knowledge_id: str
    item_id: str
    knowledge_type: str
    canonical_key: str
    title: str = ""
    source_url: str | None = None
    source_surface: str = ""
    payload: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


class WorldModelKnowledgeEntityLink(BaseModel):
    link_id: str
    knowledge_id: str
    entity_id: str
    relationship: str = "mentions"
    confidence: float = 0.0
    provenance_kind: str = ""
    provenance_ref: str = ""
    created_at: datetime


class WorldModelKnowledgeRelationship(BaseModel):
    relationship_id: str
    source_knowledge_id: str
    target_knowledge_id: str
    relationship_kind: str
    summary: str = ""
    confidence: float = 1.0
    source_surface: str = ""
    created_at: datetime
    updated_at: datetime


class WorldModelSemanticMapping(BaseModel):
    mapping_id: str
    mapping_kind: str
    source_value: str
    target_value: str
    scope_type: str
    scope_key: str
    source_surface: str = ""
    confidence: float = 1.0
    created_at: datetime
    updated_at: datetime


# ---------------------------------------------------------------------------
# Tools & Connectors (Phase 2)
# ---------------------------------------------------------------------------


class ToolDefinition(BaseModel):
    name: str
    description: str
    parameters: dict[str, Any] = Field(default_factory=dict)
    source: str  # "mcp:filesystem", "builtin", "http"
    required_capability: str  # "filesystem.read", "network.outbound", etc.
    always_present: bool = False
    keywords: list[str] = Field(default_factory=list)
    aliases: list[str] = Field(default_factory=list)
    capability_tags: list[str] = Field(default_factory=list)
    preferred_classifications: list[str] = Field(default_factory=list)
    supported_intent_paths: list[str] = Field(default_factory=list)


class ToolResult(BaseModel):
    tool_name: str
    success: bool
    content: str
    error: str | None = None
    source: str
    duration_ms: int
    metadata: dict[str, Any] = Field(default_factory=dict)
    boundary_tagged: bool = False


class AuditEntry(BaseModel):
    timestamp: datetime
    connector: str
    action: str
    capability_required: str = ""
    granted: bool = True
    goal_id: str | None = None
    session_id: str | None = None
    result_summary: str = ""
    duration_ms: int | None = None


class ConnectorHealth(BaseModel):
    name: str
    status: Literal["connected", "unavailable", "degraded"]
    last_check: datetime
    error: str | None = None
    tools_discovered: int = 0
    capability_prefix: str = ""


# ---------------------------------------------------------------------------
# Knowledge & Memory (Phase 3)
# ---------------------------------------------------------------------------


class ItemType(str, Enum):
    ARTICLE = "article"
    NOTE = "note"
    THOUGHT = "thought"
    LINK = "link"
    CLIPPING = "clipping"
    CONVERSATION = "conversation"
    VOICE_MEMO = "voice_memo"
    MEETING = "meeting"


class LinkCreator(str, Enum):
    AUTO = "auto"
    HUMAN = "human"
    AGENT = "agent"


class ProvenanceLink(BaseModel):
    source_description: str = ""
    url: str = ""
    accessed_at: datetime | None = None


class Provenance(BaseModel):
    source: str = ""
    author: str = ""
    captured_at: datetime | None = None
    chain: list[ProvenanceLink] = Field(default_factory=list)
    confidence: float = 0.0


class Summary(BaseModel):
    text: str = ""
    model: str = ""
    generated_at: datetime | None = None
    input_tokens: int = 0


class Item(BaseModel):
    item_id: str
    type: ItemType = ItemType.NOTE
    title: str
    body: str = ""
    source_url: str | None = None
    author: str = ""
    captured_at: datetime
    tags: list[str] = Field(default_factory=list)
    source_id: str | None = None
    half_life_days: float = 30.0
    last_accessed: datetime
    pinned: bool = False
    is_milestone: bool = False
    expires_at: datetime | None = None
    version: int = 1
    supersedes_id: str | None = None
    summary: Summary = Field(default_factory=Summary)
    provenance: Provenance = Field(default_factory=Provenance)
    metadata: dict[str, Any] = Field(default_factory=dict)
    deleted_at: datetime | None = None


class Source(BaseModel):
    source_id: str
    name: str
    domain: str = ""
    type: str = ""
    reputation_score: float = 0.5
    confidence: float = 0.0
    accuracy_history: list[float] = Field(default_factory=list)
    citation_count: int = 0
    human_feedback_count: int = 0
    created_at: datetime


class Link(BaseModel):
    source_item_id: str
    target_item_id: str
    relationship: str = ""
    strength: float = 0.5
    created_by: LinkCreator = LinkCreator.AUTO
    created_at: datetime


class LinkConfig(BaseModel):
    min_strength: float = 0.3
    max_auto_links_per_item: int = 10
    cross_type_penalty: float = 0.1
    time_proximity_bonus: float = 0.05
    display_threshold: float = 0.5


class RankConfig(BaseModel):
    relevance_exp: float = 1.0
    decay_exp: float = 0.5
    reputation_exp: float = 0.3
    pin_boost: float = 2.0


# ---------------------------------------------------------------------------
# Claude Code connector (Phase 4)
# ---------------------------------------------------------------------------


class ClaudeCodeResult(BaseModel):
    result: str
    session_id: str
    total_cost_usd: float
    duration_ms: int
    num_turns: int
    is_error: bool


class ClaudeCodeSession(BaseModel):
    session_id: str
    task_description: str
    working_directory: str
    created_at: datetime
    last_used_at: datetime
    total_cost_usd: float = 0.0
    total_turns: int = 0
    status: Literal["active", "completed", "failed"] = "active"


class Trail(BaseModel):
    trail_id: str
    name: str
    description: str = ""
    created_by: str = ""
    created_at: datetime
    updated_at: datetime


class TrailItem(BaseModel):
    trail_id: str
    item_id: str
    position: int
    annotation: str = ""


# ---------------------------------------------------------------------------
# Scheduler (Phase 6)
# ---------------------------------------------------------------------------


class ActionType(str, Enum):
    NOTIFICATION = "notification"
    PROMPT = "prompt"
    CALLABLE = "callable"
    AUTO_INGEST = "auto_ingest"
    TRANSCRIPTION = "transcription"
    TELEGRAM_MESSAGE = "telegram_message"
    GMAIL_MESSAGE = "gmail_message"


class ScheduledTask(BaseModel):
    task_id: str
    name: str
    description: str = ""
    cron_expr: str
    action_type: ActionType
    action_data: dict[str, Any] = Field(default_factory=dict)
    goal_id: str | None = None
    enabled: bool = True
    builtin: bool = False
    created_at: datetime
    updated_at: datetime


class TaskRun(BaseModel):
    run_id: int | str  # int auto-increment or str logical_id
    task_id: str | None  # None for ad-hoc items (no parent scheduled task)
    started_at: datetime | None = None  # NULL until execution actually begins
    completed_at: datetime | None = None
    status: str = "queued"  # queued, running, completed, failed, retrying
    result: str = ""
    error: str | None = None
    queued_at: datetime | None = None
    attempt: int = 0
    action_type: str | None = None
    action_data: dict[str, Any] | None = None
    max_retries: int = 3
    priority: int = 5


# ---------------------------------------------------------------------------
# Notifications (Phase 5)
# ---------------------------------------------------------------------------


class NotificationPriority(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    NORMAL = "normal"
    LOW = "low"


class Notification(BaseModel):
    notification_id: str
    title: str
    body: str = ""
    priority: NotificationPriority = NotificationPriority.NORMAL
    source: str = ""  # "scheduler", "reflect", "self_improvement", etc.
    goal_id: str | None = None
    created_at: datetime
    read_at: datetime | None = None
    dismissed_at: datetime | None = None
    action_type: str | None = None  # "approve", "review", "info"
    action_data: dict[str, Any] = Field(default_factory=dict)
