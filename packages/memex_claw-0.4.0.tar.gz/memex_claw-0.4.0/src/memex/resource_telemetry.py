"""Process resource telemetry for the Memex service.

Periodically collects memory, CPU, file-descriptor, thread, and GC metrics
and publishes them as domain events for trend analysis and alerting.
"""

from __future__ import annotations

import gc
import json
import logging
import os
import resource
import threading
import time
from collections import deque
from typing import Any

import psutil

from memex.event_bus import safe_publish
from memex.events import ResourceSnapshot
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

# Read once at import; service restart required to change.
_RSS_WARN_BYTES = int(
    os.environ.get("MEMEX_RSS_WARN_BYTES", str(1_610_612_736))
)  # 1.5 GB
_THREAD_WARN_COUNT = int(os.environ.get("MEMEX_THREAD_WARN_COUNT", "50"))
_FD_WARN_RATIO = float(os.environ.get("MEMEX_FD_WARN_RATIO", "0.8"))

_ALERT_COOLDOWN = 3600  # seconds, per warning key

# Cached Process object so cpu_percent() can diff against prior sample.
# Not protected by a lock — collect_snapshot() is not concurrent-safe and
# relies on the scheduler serializing calls to the resource_telemetry callable.
_proc: psutil.Process | None = None

# Structured warning: (key for cooldown dedup, human-readable message)
ThresholdAlert = tuple[str, str]

_MIB = 1024 * 1024


def _get_proc(pid: int | None = None) -> psutil.Process:
    global _proc
    if _proc is None or (pid is not None and _proc.pid != pid):
        _proc = psutil.Process(pid)
        _proc.cpu_percent(interval=None)  # prime the baseline
    return _proc


# ---------------------------------------------------------------------------
# Collection
# ---------------------------------------------------------------------------


def collect_snapshot(
    pid: int | None = None,
    fathom_store: Any = None,
) -> dict[str, Any]:
    """Gather process resource metrics.

    Returns a plain dict suitable for JSON serialization.
    """
    proc = _get_proc(pid)

    # memory_full_info() is a superset of memory_info() (includes USS)
    uss = 0
    try:
        mem = proc.memory_full_info()
        uss = getattr(mem, "uss", 0)
    except (psutil.AccessDenied, psutil.Error):
        mem = proc.memory_info()

    try:
        fd_count = proc.num_fds()
    except (psutil.AccessDenied, psutil.Error):
        fd_count = 0

    soft_limit, _hard = resource.getrlimit(resource.RLIMIT_NOFILE)

    # Child processes (MCP servers, etc.)
    children_rss = 0
    children_count = 0
    try:
        for child in proc.children(recursive=True):
            try:
                children_rss += child.memory_info().rss
                children_count += 1
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        pass

    gc_count = gc.get_count()
    gc_stats = gc.get_stats()
    gc_collections = tuple(s.get("collections", 0) for s in gc_stats)

    uptime = time.time() - proc.create_time()

    return {
        "timestamp": utcnow().isoformat(),
        "rss_bytes": mem.rss,
        "vms_bytes": mem.vms,
        "uss_bytes": uss,
        "rss_mb": mem.rss // _MIB,
        "vms_mb": mem.vms // _MIB,
        "uss_mb": uss // _MIB,
        "cpu_percent": proc.cpu_percent(interval=None),
        "thread_count": proc.num_threads(),
        "fd_count": fd_count,
        "fd_limit": soft_limit,
        "children_count": children_count,
        "children_rss_bytes": children_rss,
        "children_rss_mb": children_rss // _MIB,
        "gc_objects": sum(gc_count),
        "gc_collections": gc_collections,
        "uptime_seconds": round(uptime, 1),
        "extensions": _collect_extensions(fathom_store),
    }


_prev_fathom_stats: dict[str, int] | None = None
_prev_fathom_time: float = 0.0


def _collect_extensions(fathom_store: Any) -> dict[str, Any]:
    """Collect extension metrics (e.g. fathomdb resource stats)."""
    global _prev_fathom_stats, _prev_fathom_time
    ext: dict[str, Any] = {}
    if fathom_store is None or not hasattr(fathom_store, "get_resource_stats"):
        return ext
    try:
        raw = fathom_store.get_resource_stats()
    except Exception:
        logger.debug("fathomdb get_resource_stats failed", exc_info=True)
        return ext

    now = time.monotonic()
    stats: dict[str, Any] = dict(raw)

    # Compute rates from cumulative counters
    if _prev_fathom_stats is not None:
        dt = now - _prev_fathom_time
        if dt > 0:
            stats["queries_per_sec"] = round(
                (raw["queries_total"] - _prev_fathom_stats["queries_total"]) / dt, 2
            )
            stats["writes_per_sec"] = round(
                (raw["writes_total"] - _prev_fathom_stats["writes_total"]) / dt, 2
            )
            stats["errors_per_sec"] = round(
                (raw["errors_total"] - _prev_fathom_stats["errors_total"]) / dt, 2
            )

    # Cache hit ratio (lifetime)
    total_cache = raw["cache_hits"] + raw["cache_misses"]
    stats["cache_hit_ratio"] = (
        round(raw["cache_hits"] / total_cache, 4) if total_cache > 0 else None
    )

    _prev_fathom_stats = raw
    _prev_fathom_time = now
    ext["fathomdb"] = stats
    return ext


# ---------------------------------------------------------------------------
# Threshold evaluation
# ---------------------------------------------------------------------------


def evaluate_thresholds(snapshot: dict[str, Any]) -> list[ThresholdAlert]:
    """Return (key, message) pairs for any breached thresholds."""
    warnings: list[ThresholdAlert] = []

    rss = snapshot.get("rss_bytes", 0)
    if rss > _RSS_WARN_BYTES:
        warnings.append(
            (
                "rss",
                f"rss={rss // _MIB}MB exceeds limit {_RSS_WARN_BYTES // _MIB}MB",
            )
        )

    fd_count = snapshot.get("fd_count", 0)
    fd_limit = snapshot.get("fd_limit", 0)
    if fd_limit > 0 and fd_count > fd_limit * _FD_WARN_RATIO:
        warnings.append(
            (
                "fd_count",
                f"fd_count={fd_count} exceeds {_FD_WARN_RATIO:.0%} of limit {fd_limit}",
            )
        )

    threads = snapshot.get("thread_count", 0)
    if threads > _THREAD_WARN_COUNT:
        warnings.append(
            (
                "thread_count",
                f"thread_count={threads} exceeds limit {_THREAD_WARN_COUNT}",
            )
        )

    return warnings


# ---------------------------------------------------------------------------
# Store (in-memory ring buffer + event publishing)
# ---------------------------------------------------------------------------


class ResourceTelemetryStore:
    """Ring buffer of resource snapshots with event publishing."""

    def __init__(self, maxlen: int = 288) -> None:
        self._buffer: deque[dict[str, Any]] = deque(maxlen=maxlen)
        self._lock = threading.Lock()
        self._registry: Any = None  # RuntimeStateRegistry, set after init

    def set_registry(self, registry: Any) -> None:
        self._registry = registry

    def record(
        self,
        snapshot: dict[str, Any],
        warnings: list[ThresholdAlert] | None = None,
    ) -> None:
        """Append snapshot to ring buffer, publish event, update registry.

        Takes ownership of a copy — the caller's dict is not affected.
        """
        snapshot = {**snapshot, "warnings": warnings or []}

        with self._lock:
            self._buffer.append(snapshot)

        warning_messages = tuple(msg for _, msg in snapshot["warnings"])
        extensions_tuples = tuple(
            (k, json.dumps(v)) for k, v in snapshot.get("extensions", {}).items()
        )
        event = ResourceSnapshot(
            rss_bytes=snapshot["rss_bytes"],
            vms_bytes=snapshot["vms_bytes"],
            uss_bytes=snapshot["uss_bytes"],
            cpu_percent=snapshot["cpu_percent"],
            thread_count=snapshot["thread_count"],
            fd_count=snapshot["fd_count"],
            fd_limit=snapshot["fd_limit"],
            children_count=snapshot["children_count"],
            children_rss_bytes=snapshot["children_rss_bytes"],
            gc_objects=snapshot["gc_objects"],
            gc_collections=tuple(snapshot.get("gc_collections", ())),
            uptime_seconds=snapshot["uptime_seconds"],
            warnings=warning_messages,
            extensions=extensions_tuples,
        )
        safe_publish(event)

        if self._registry is not None:
            try:
                self._registry.set_resource_snapshot(snapshot)
            except Exception:
                logger.debug("Failed to update runtime registry", exc_info=True)

        logger.info(
            "resource_telemetry rss=%dMB vms=%dMB uss=%dMB cpu=%.1f%% "
            "threads=%d fds=%d/%d children=%d children_rss=%dMB gc_objects=%d",
            snapshot["rss_mb"],
            snapshot["vms_mb"],
            snapshot["uss_mb"],
            snapshot["cpu_percent"],
            snapshot["thread_count"],
            snapshot["fd_count"],
            snapshot["fd_limit"],
            snapshot["children_count"],
            snapshot["children_rss_mb"],
            snapshot["gc_objects"],
        )

    def latest(self) -> dict[str, Any] | None:
        with self._lock:
            if not self._buffer:
                return None
            return {**self._buffer[-1]}

    def history(self, limit: int = 288) -> list[dict[str, Any]]:
        with self._lock:
            items = [{**s} for s in self._buffer]
        return items[-limit:]


# ---------------------------------------------------------------------------
# Scheduler callable entry point
# ---------------------------------------------------------------------------

_last_alert_time: dict[str, float] = {}
_alert_lock = threading.Lock()


def run_collection(
    store: ResourceTelemetryStore,
    fathom_store: Any = None,
    notification_store: Any = None,
) -> str:
    """Collect resource snapshot, evaluate thresholds, record, and alert.

    Returns a summary string for the scheduler task run result.
    """
    snapshot = collect_snapshot(fathom_store=fathom_store)
    warnings = evaluate_thresholds(snapshot)
    store.record(snapshot, warnings=warnings)

    if warnings and notification_store is not None:
        now = time.monotonic()
        unseen = []
        with _alert_lock:
            for key, msg in warnings:
                if now - _last_alert_time.get(key, 0) >= _ALERT_COOLDOWN:
                    _last_alert_time[key] = now
                    unseen.append(msg)

        if unseen:
            try:
                from memex.models import NotificationPriority
                from memex.notifications import NotificationRouter

                router = NotificationRouter(notification_store)
                router.notify(
                    "Resource Warning",
                    body="; ".join(unseen),
                    priority=NotificationPriority.HIGH,
                    source="resource_telemetry",
                )
            except Exception:
                logger.warning(
                    "Failed to send resource warning notification", exc_info=True
                )

    warning_msgs = [msg for _, msg in warnings]
    warn_str = f" warnings=[{', '.join(warning_msgs)}]" if warnings else ""
    return f"rss={snapshot['rss_mb']}MB threads={snapshot['thread_count']} fds={snapshot['fd_count']}{warn_str}"


# ---------------------------------------------------------------------------
# Module singleton
# ---------------------------------------------------------------------------

_store: ResourceTelemetryStore | None = None
_store_lock = threading.Lock()


def init_telemetry_store(
    *,
    runtime_registry: Any = None,
    maxlen: int = 288,
) -> ResourceTelemetryStore:
    """Create or return the process-global telemetry store."""
    global _store
    with _store_lock:
        if _store is None:
            _store = ResourceTelemetryStore(maxlen=maxlen)
        if runtime_registry is not None:
            _store.set_registry(runtime_registry)
    return _store


def get_telemetry_store() -> ResourceTelemetryStore | None:
    """Return the telemetry store singleton, or None if not initialized."""
    return _store


def reset_telemetry_store() -> None:
    """Reset the singleton (for tests)."""
    global _store, _proc, _prev_fathom_stats, _prev_fathom_time
    with _store_lock:
        _store = None
    _proc = None
    _prev_fathom_stats = None
    _prev_fathom_time = 0.0
    with _alert_lock:
        _last_alert_time.clear()
