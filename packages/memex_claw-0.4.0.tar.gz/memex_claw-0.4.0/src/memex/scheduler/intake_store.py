"""IntakeStore stub.

The original sqlite3-backed IntakeStore has been replaced by
FathomIntakeAdapter in fathom_facade.py. This stub exists only
to prevent ImportError in guarded fallback paths.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


class IntakeStore:
    def __init__(self, conn: Any) -> None:
        logger.debug("IntakeStore: stub created (use FathomIntakeAdapter instead)")
