"""Work queue — thread-safe priority queue with worker pool and retry logic."""

from __future__ import annotations

import logging
import queue
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable

from memex.models import ActionType
from memex.runtime_state import RuntimeStateRegistry

logger = logging.getLogger(__name__)


class LLMUnavailableError(Exception):
    """Raised by dispatchers when the LLM proxy is down.

    The WorkQueue treats this specially: the retry attempt counter is NOT
    incremented and the item is re-enqueued after a 60-second hold.
    """


@dataclass(order=True)
class WorkItem:
    """A unit of work to be processed by the queue."""

    priority: int  # lower = higher priority
    task_id: str = field(compare=False)
    run_id: int | str = field(compare=False)
    action_type: str = field(compare=False)
    action_data: dict[str, Any] = field(compare=False, default_factory=dict)
    max_retries: int = field(compare=False, default=3)
    attempt: int = field(compare=False, default=0)
    llm_hold_count: int = field(compare=False, default=0)


# Dispatcher signature: (action_data, run_id) -> result string
DispatcherFn = Callable[[dict[str, Any], int], str]


class WorkQueue:
    """Thread-safe priority queue with worker pool for background task execution.

    Dispatchers are registered per action_type. The queue dequeues items,
    dispatches to the appropriate handler in the thread pool, and records
    results. Failed items are re-enqueued with exponential backoff up to
    max_retries.
    """

    def __init__(
        self,
        max_workers: int = 3,
        scheduler_store: Any | None = None,
        runtime_registry: RuntimeStateRegistry | None = None,
    ) -> None:
        self._queue: queue.PriorityQueue[WorkItem] = queue.PriorityQueue()
        self._max_workers = max_workers
        self._store = scheduler_store
        self._dispatchers: dict[str, DispatcherFn] = {}
        self._shutdown = threading.Event()
        self._paused = threading.Event()
        self._paused.set()  # starts unpaused
        self._consumer_thread: threading.Thread | None = None
        self._pool: ThreadPoolExecutor | None = None
        self._running_count = 0
        self._retrying_count = 0
        self._runtime_registry = runtime_registry

    def _sync_runtime_state(self) -> None:
        registry = self._runtime_registry
        if registry is not None:
            registry.set_queue_state(
                "work_queue",
                pending_count=self.pending_count,
                is_paused=self.is_paused,
                running_count=self._running_count,
                retrying_count=self._retrying_count,
                status="paused" if self.is_paused else "running",
            )

    def register_dispatcher(self, action_type: str, fn: DispatcherFn) -> None:
        """Register a handler for an action type."""
        self._dispatchers[action_type] = fn

    def enqueue(self, item: WorkItem) -> None:
        """Add a work item to the queue."""
        self._queue.put(item)
        if (
            self._runtime_registry is not None
            and item.action_type == ActionType.TRANSCRIPTION.value
        ):
            self._runtime_registry.bump_transcription_counts(queued_delta=1)
        self._sync_runtime_state()

    def start(self) -> None:
        """Start the consumer thread and worker pool."""
        if self._consumer_thread is not None:
            return
        self._shutdown.clear()
        self._pool = ThreadPoolExecutor(max_workers=self._max_workers)
        self._consumer_thread = threading.Thread(
            target=self._consumer_loop,
            daemon=True,
            name="memex-work-queue",
        )
        self._consumer_thread.start()
        self._sync_runtime_state()

    def stop(self, timeout: float = 30) -> None:
        """Signal shutdown and wait for drain."""
        self._shutdown.set()
        if self._consumer_thread is not None:
            self._consumer_thread.join(timeout=timeout)
            self._consumer_thread = None
        if self._pool is not None:
            self._pool.shutdown(wait=False, cancel_futures=True)
            self._pool = None
        self._running_count = 0
        self._retrying_count = 0
        self._sync_runtime_state()

    def pause(self) -> None:
        """Pause task dispatch. Queued items are preserved."""
        self._paused.clear()
        self._sync_runtime_state()

    def resume(self) -> None:
        """Resume task dispatch."""
        self._paused.set()
        self._sync_runtime_state()

    @property
    def is_paused(self) -> bool:
        return not self._paused.is_set()

    @property
    def pending_count(self) -> int:
        return self._queue.qsize()

    def _consumer_loop(self) -> None:
        """Main consumer loop — dequeue items and dispatch to pool."""
        while not self._shutdown.is_set():
            # Block while paused (check shutdown every second)
            while not self._paused.is_set():
                if self._shutdown.is_set():
                    return
                self._paused.wait(timeout=1.0)

            try:
                item = self._queue.get(timeout=1.0)
            except queue.Empty:
                continue

            try:
                pool = self._pool
                if pool is None:
                    break
                pool.submit(self._execute_item, item)
                self._sync_runtime_state()
            except RuntimeError:
                # Pool was shut down between check and submit
                break

    def _execute_item(self, item: WorkItem) -> None:
        """Execute a single work item with retry logic."""
        dispatcher = self._dispatchers.get(item.action_type)
        if dispatcher is None:
            logger.warning("No dispatcher for action_type=%s", item.action_type)
            if self._store:
                self._store.complete_run(
                    item.run_id,
                    status="failed",
                    error=f"No dispatcher for action_type: {item.action_type}",
                )
            return

        # Mark as running
        if self._store:
            self._store.update_run_status(item.run_id, "running", attempt=item.attempt)
        if item.attempt > 0 and self._retrying_count > 0:
            self._retrying_count -= 1
        self._running_count += 1
        if (
            self._runtime_registry is not None
            and item.action_type == ActionType.TRANSCRIPTION.value
        ):
            self._runtime_registry.bump_transcription_counts(
                queued_delta=-1, running_delta=1
            )
        self._sync_runtime_state()

        try:
            result = dispatcher(item.action_data, item.run_id)
            if self._store:
                self._store.complete_run(
                    item.run_id, status="completed", result=result or ""
                )
            logger.debug("Task %s completed (attempt %d)", item.task_id, item.attempt)

            try:
                from memex.event_bus import get_bus
                from memex.events import TaskRunCompleted

                get_bus().publish(
                    TaskRunCompleted(
                        task_id=item.task_id,
                        run_id=item.run_id,
                        status="completed",
                        result=result or "",
                    )
                )
            except Exception:
                pass
        except LLMUnavailableError as exc:
            # LLM is down — hold for 60s then re-enqueue WITHOUT burning a retry attempt.
            # Cap at 5 holds to avoid infinite retry when LLM is persistently unavailable.
            _MAX_LLM_HOLDS = 5
            holds = item.llm_hold_count + 1
            if holds > _MAX_LLM_HOLDS:
                logger.warning(
                    "Task %s: LLM unavailable after %d holds, giving up",
                    item.task_id,
                    holds,
                )
                if self._store:
                    self._store.complete_run(
                        item.run_id,
                        status="failed",
                        error=f"LLM unavailable after {holds} hold cycles: {exc}",
                    )
            else:
                logger.warning(
                    "Task %s: LLM unavailable, will retry in 60s (hold %d/%d)",
                    item.task_id,
                    holds,
                    _MAX_LLM_HOLDS,
                )
                if self._store:
                    self._store.update_run_status(
                        item.run_id, "retrying", attempt=item.attempt
                    )
                self._retrying_count += 1
                self._sync_runtime_state()
                if not self._shutdown.wait(60) and not self._shutdown.is_set():
                    # Re-enqueue with the SAME attempt count (not burned)
                    retry_item = WorkItem(
                        priority=item.priority,
                        task_id=item.task_id,
                        run_id=item.run_id,
                        action_type=item.action_type,
                        action_data=item.action_data,
                        max_retries=item.max_retries,
                        attempt=item.attempt,  # not incremented
                        llm_hold_count=holds,
                    )
                    self.enqueue(retry_item)
                    self._retrying_count = max(0, self._retrying_count - 1)
                    self._sync_runtime_state()
                else:
                    if self._store:
                        self._store.complete_run(
                            item.run_id,
                            status="failed",
                            error=f"Shutdown during LLM-unavailable hold: {exc}",
                        )
        except Exception as exc:
            logger.warning(
                "Task %s failed (attempt %d): %s", item.task_id, item.attempt, exc
            )
            if (
                self._runtime_registry is not None
                and item.action_type == ActionType.TRANSCRIPTION.value
            ):
                self._runtime_registry.bump_transcription_counts(error=str(exc))

            if item.attempt < item.max_retries:
                # Exponential backoff: 2^attempt seconds
                backoff = 2**item.attempt
                if self._store:
                    self._store.update_run_status(
                        item.run_id, "retrying", attempt=item.attempt
                    )
                self._retrying_count += 1
                self._sync_runtime_state()

                # Sleep for backoff then re-enqueue (only if not shutting down)
                if not self._shutdown.wait(backoff) and not self._shutdown.is_set():
                    retry_item = WorkItem(
                        priority=item.priority + 1,  # slightly lower priority
                        task_id=item.task_id,
                        run_id=item.run_id,
                        action_type=item.action_type,
                        action_data=item.action_data,
                        max_retries=item.max_retries,
                        attempt=item.attempt + 1,
                    )
                    self.enqueue(retry_item)
                    self._retrying_count = max(0, self._retrying_count - 1)
                    self._sync_runtime_state()
                elif self._shutdown.is_set():
                    # Shutting down — mark as failed rather than leaking into queue
                    if self._store:
                        self._store.complete_run(
                            item.run_id,
                            status="failed",
                            error=f"Shutdown during retry backoff (attempt {item.attempt})",
                        )
            else:
                if self._store:
                    self._store.complete_run(
                        item.run_id,
                        status="failed",
                        error=str(exc),
                    )
                logger.error("Task %s exhausted retries: %s", item.task_id, exc)

                try:
                    from memex.event_bus import get_bus
                    from memex.events import TaskRunCompleted

                    get_bus().publish(
                        TaskRunCompleted(
                            task_id=item.task_id,
                            run_id=item.run_id,
                            status="failed",
                            result=str(exc),
                        )
                    )
                except Exception:
                    pass
        finally:
            self._running_count = max(0, self._running_count - 1)
            if (
                self._runtime_registry is not None
                and item.action_type == ActionType.TRANSCRIPTION.value
            ):
                self._runtime_registry.bump_transcription_counts(running_delta=-1)
            self._sync_runtime_state()
