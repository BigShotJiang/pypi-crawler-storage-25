"""Scheduler engine — background cron loop that enqueues due tasks into the work queue."""

from __future__ import annotations

import concurrent.futures as _cf
import logging
import os
import threading
from datetime import timedelta
from typing import TYPE_CHECKING, Any

from memex.models import ActionType, NotificationPriority, ScheduledTask
from memex.utcnow import utcnow

if TYPE_CHECKING:
    from memex.store import MemexStore
from memex.scheduler.builtins import get_builtin_tasks
from memex.scheduler.cron_utils import is_due
from memex.scheduler.work_queue import WorkItem, WorkQueue
from memex.runtime_state import RuntimeStateRegistry

logger = logging.getLogger(__name__)

_TRANSCRIPTION_TIMEOUT = int(os.environ.get("MEMEX_TRANSCRIPTION_TIMEOUT", "1800"))

# Priority mapping: notification > callable > prompt > auto_ingest
_PRIORITY = {
    ActionType.NOTIFICATION: 0,
    ActionType.CALLABLE: 1,
    ActionType.PROMPT: 2,
    ActionType.TRANSCRIPTION: 2,
    ActionType.AUTO_INGEST: 3,
}


class SchedulerEngine:
    """Background cron-style scheduler with work queue execution.

    The engine runs a 60-second tick loop. Each tick:
    1. Loads enabled scheduled tasks
    2. Checks which are due (via cron expression + last run time)
    3. Enqueues due tasks into the work queue
    4. The work queue dispatches to registered handlers

    The engine owns the work queue lifecycle.
    """

    def __init__(
        self,
        scheduler_store: Any,
        *,
        api: Any | None = None,
        notification_store: Any | None = None,
        memex_store: MemexStore | None = None,
        max_workers: int = 3,
        tick_seconds: int = 60,
        runtime_registry: RuntimeStateRegistry | None = None,
    ) -> None:
        self._store = scheduler_store
        self._api = api
        self._notification_store = notification_store
        self._goal_store = memex_store
        self._intake_store = self._resolve_intake_store()
        self._tick_seconds = tick_seconds
        self._shutdown = threading.Event()
        self._thread: threading.Thread | None = None
        self._runtime_registry = runtime_registry

        # Work queue
        self._queue = WorkQueue(
            max_workers=max_workers,
            scheduler_store=scheduler_store,
            runtime_registry=runtime_registry,
        )

        # Register dispatchers
        self._queue.register_dispatcher(
            ActionType.NOTIFICATION.value, self._dispatch_notification
        )
        self._queue.register_dispatcher(
            ActionType.CALLABLE.value, self._dispatch_callable
        )
        self._queue.register_dispatcher(ActionType.PROMPT.value, self._dispatch_prompt)
        self._queue.register_dispatcher(
            ActionType.AUTO_INGEST.value, self._dispatch_auto_ingest
        )
        self._queue.register_dispatcher(
            ActionType.TRANSCRIPTION.value, self._dispatch_transcription
        )

        # Register telegram message dispatcher
        self._queue.register_dispatcher(
            ActionType.TELEGRAM_MESSAGE.value, self._dispatch_telegram_message
        )

        # Register gmail message dispatcher (for replaying failed Gmail items)
        self._queue.register_dispatcher(
            ActionType.GMAIL_MESSAGE.value, self._dispatch_gmail_message
        )

        # Seed built-in tasks
        self._store.seed_builtins(get_builtin_tasks())

    def _resolve_intake_store(self) -> Any:
        """Return intake adapter, or None."""
        if self._goal_store is None:
            return None
        return getattr(self._goal_store, "intake", None)

    @property
    def work_queue(self) -> WorkQueue:
        return self._queue

    def start(self) -> None:
        """Start the engine and work queue in background threads."""
        if self._thread is not None:
            return
        # Sweep task_runs left in running/retrying by a previous crashed session.
        # Workers are in-process; the process dying kills them but leaves DB rows stuck.
        stale = self._store.cleanup_stale_runs()
        if stale:
            logger.debug("Startup: marked %d stale task run(s) as failed", stale)
        else:
            logger.debug("Startup: state sweep found no stale task run(s)")
        self._shutdown.clear()
        self._queue.start()
        rehydrated = self._rehydrate_queued_runs()
        if rehydrated:
            logger.info("Startup: re-hydrated %d queued work item(s)", rehydrated)
        if self._runtime_registry is not None:
            self._runtime_registry.set_queue_state("scheduler", status="running")
        self._thread = threading.Thread(
            target=self._tick_loop,
            daemon=True,
            name="memex-scheduler",
        )
        self._thread.start()

    def stop(self, timeout: float = 30) -> None:
        """Stop the engine and work queue."""
        self._shutdown.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            self._thread = None
        self._queue.stop(timeout=timeout)
        if self._runtime_registry is not None:
            self._runtime_registry.set_queue_state("scheduler", status="stopped")

    def run_task_now(self, task_id: str) -> int | None:
        """Manually trigger a task. Returns run_id or None if task not found."""
        task = self._store.get_task(task_id)
        if task is None:
            return None
        return self._enqueue_task(task)

    def enqueue_adhoc(
        self,
        action_type: str,
        action_data: dict,
        *,
        priority: int = 5,
        max_retries: int = 3,
    ) -> int:
        """Enqueue an ad-hoc work item (not tied to a scheduled task). Returns run_id."""
        run_id = self._store.record_adhoc_run(
            action_type, action_data, priority=priority, max_retries=max_retries
        )
        item = WorkItem(
            priority=priority,
            task_id="adhoc",
            run_id=run_id,
            action_type=action_type,
            action_data=action_data,
            max_retries=max_retries,
        )
        self._queue.enqueue(item)
        logger.debug(
            "Enqueued ad-hoc item action_type=%s run_id=%s", action_type, run_id
        )
        return run_id

    def _rehydrate_queued_runs(self) -> int:
        """Re-enqueue task_runs rows left in status='queued' from a previous crashed session."""
        import json as _json

        rows = self._store.get_queued_runs()
        for row in rows:
            item = WorkItem(
                priority=row["priority"] or 5,
                task_id=row["task_id"] or "adhoc",
                run_id=row["run_id"],
                action_type=row["action_type"],
                action_data=row["action_data"]
                if isinstance(row["action_data"], dict)
                else _json.loads(row["action_data"] or "{}"),
                max_retries=row["max_retries"] or 3,
            )
            self._queue.enqueue(item)
        return len(rows)

    def _tick_loop(self) -> None:
        """Main scheduler loop — check for due tasks every tick."""
        while not self._shutdown.is_set():
            try:
                self._tick()
            except Exception:
                logger.error("Scheduler tick failed", exc_info=True)

            # Sleep in 1-second increments for responsive shutdown
            for _ in range(self._tick_seconds):
                if self._shutdown.is_set():
                    return
                self._shutdown.wait(1)

    def _tick(self) -> None:
        """Single scheduler tick — check all enabled tasks."""
        now = utcnow()
        tasks = self._store.list_tasks(enabled_only=True)

        for task in tasks:
            last_run = self._store.get_last_run(task.task_id)
            last_run_time = last_run.started_at if last_run else None

            if is_due(task.cron_expr, last_run_time, now):
                self._enqueue_task(task)

    def _enqueue_task(self, task: ScheduledTask) -> int:
        """Create a run record and enqueue work item."""
        now = utcnow()
        action_type_val = (
            task.action_type.value
            if hasattr(task.action_type, "value")
            else task.action_type
        )
        priority = _PRIORITY.get(task.action_type, 5)
        run_id = self._store.record_run(
            task.task_id,
            status="queued",
            queued_at=now,
            action_type=action_type_val,
            action_data=task.action_data,
            priority=priority,
        )

        item = WorkItem(
            priority=priority,
            task_id=task.task_id,
            run_id=run_id,
            action_type=action_type_val,
            action_data=task.action_data,
        )
        self._queue.enqueue(item)
        logger.debug("Enqueued task %s (run_id=%s)", task.name, run_id)
        return run_id

    # -- Dispatchers -----------------------------------------------------------

    def _dispatch_notification(self, action_data: dict, run_id: int) -> str:
        """Generate and deliver a notification."""
        generator = action_data.get("generator", "")

        if generator == "session_briefing" and self._goal_store is not None:
            from memex.scheduler.proactive import get_session_briefing

            briefing = get_session_briefing(self._goal_store)

            if self._notification_store is not None:
                from memex.notifications import NotificationRouter

                router = NotificationRouter(self._notification_store)
                router.notify(
                    "Morning Briefing",
                    body=briefing,
                    priority=NotificationPriority.NORMAL,
                    source="scheduler",
                )
            return briefing[:200]

        # Generic reminder notification
        if generator == "reminder":
            title = action_data.get("title", "Reminder")
            body = action_data.get("body", "")
            if self._notification_store is not None:
                from memex.notifications import NotificationRouter

                router = NotificationRouter(self._notification_store)
                priority_str = action_data.get("priority", "normal")
                try:
                    priority = NotificationPriority(priority_str)
                except ValueError:
                    priority = NotificationPriority.NORMAL
                router.notify(
                    title,
                    body=body,
                    priority=priority,
                    source="reminder",
                    goal_id=action_data.get("goal_id"),
                    action_data={
                        "task_id": action_data.get("task_id", ""),
                        "generator": "reminder",
                    },
                )

            # One-shot auto-disable
            if action_data.get("one_shot") and action_data.get("task_id"):
                self._store.toggle_task(action_data["task_id"], enabled=False)
                logger.info(
                    "One-shot reminder %s auto-disabled", action_data["task_id"]
                )

            return f"reminder: {title}"

        return f"notification:{generator}"

    def _dispatch_callable(self, action_data: dict, run_id: int) -> str:
        """Execute a registered callable."""
        callable_name = action_data.get("callable", "")

        if callable_name == "check_deadlines" and self._goal_store is not None:
            from memex.scheduler.proactive import DEADLINE_HOURS

            now = utcnow()
            horizon = now + timedelta(hours=DEADLINE_HOURS)
            deadlines = self._goal_store.get_approaching_deadlines(horizon)
            if deadlines and self._notification_store is not None:
                from memex.notifications import NotificationRouter

                router = NotificationRouter(self._notification_store)
                for g in deadlines[:3]:
                    delta = g.deadline - now if g.deadline else timedelta()
                    hours_left = max(0, delta.total_seconds() / 3600)
                    router.notify(
                        f"Deadline: {g.title}",
                        body=f"{hours_left:.0f}h remaining",
                        priority=NotificationPriority.HIGH,
                        source="scheduler",
                        goal_id=g.goal_id,
                    )
            return f"checked deadlines: {len(deadlines)} approaching"

        elif callable_name == "check_stale_goals" and self._goal_store is not None:
            from memex.scheduler.proactive import STALE_DAYS

            threshold = utcnow() - timedelta(days=STALE_DAYS)
            stale = self._goal_store.get_stale_goals(threshold)
            if stale and self._notification_store is not None:
                from memex.notifications import NotificationRouter

                router = NotificationRouter(self._notification_store)
                router.notify(
                    f"Stale Goals ({len(stale)})",
                    body=", ".join(g.title for g in stale[:5]),
                    priority=NotificationPriority.NORMAL,
                    source="scheduler",
                )
            return f"checked stale goals: {len(stale)} stale"

        elif callable_name == "forget_cleanup":
            grace_hours = int(os.environ.get("MEMEX_FORGET_GRACE_HOURS", "1"))
            cutoff = utcnow() - timedelta(hours=grace_hours)
            content_store = self._goal_store.content if self._goal_store else None
            if content_store is not None:
                purged = content_store.purge_deleted(cutoff)
                if purged:
                    logger.info(
                        "Purged %d soft-deleted items past %dh grace period",
                        purged,
                        grace_hours,
                    )
                return f"purged {purged} items"
            return "no content store configured"

        elif callable_name == "fts_rebuild" and self._goal_store is not None:
            counts = self._goal_store.rebuild_knowledge_projection()
            items = counts.get("items", 0)
            chunks = counts.get("chunks", 0)
            return f"knowledge projection rebuilt: {items} items, {chunks} chunks"

        elif (
            callable_name == "nightly_vec_regeneration" and self._goal_store is not None
        ):
            from fathomdb import VectorRegenerationConfig

            fathom = getattr(self._goal_store, "_fathom", None)
            if fathom is None:
                return "nightly_vec_regeneration: no fathom store configured"
            try:
                engine = fathom.world_model._engine
            except Exception:
                return "nightly_vec_regeneration: engine unavailable"
            results: list[str] = []
            for _kind in ("KnowledgeItem", "ConversationTurn"):
                try:
                    engine.admin.regenerate_vector_embeddings(
                        VectorRegenerationConfig(
                            kind=_kind,
                            profile="default",
                            chunking_policy="default",
                            preprocessing_policy="default",
                        )
                    )
                    results.append(f"{_kind}: ok")
                except Exception:
                    logger.warning(
                        "nightly_vec_regeneration failed for %s",
                        _kind,
                        exc_info=True,
                    )
                    results.append(f"{_kind}: failed")
            return f"vec regeneration: {', '.join(results)}"

        elif callable_name == "db_backup":
            from memex.backup import backup_fathomdb, rotate_backups

            backed: list[str] = []

            fathom = getattr(self._store, "_fathom", None)
            if fathom is None and hasattr(self._store, "engine"):
                fathom = self._store
            if fathom is not None:
                if backup_fathomdb(fathom, tag="scheduled"):
                    backed.append("fathomdb")

            rotate_backups()
            return f"backup: {', '.join(backed) if backed else 'nothing to back up'}"

        elif callable_name == "conversation_cleanup" and self._goal_store is not None:
            retention_days = int(
                os.environ.get("MEMEX_CONVERSATION_RETENTION_DAYS", "90")
            )
            cutoff = utcnow() - timedelta(days=retention_days)
            deleted = self._goal_store.cleanup_conversation_log(cutoff)
            if deleted:
                logger.info(
                    "Cleaned up %d conversation_log rows older than %d days",
                    deleted,
                    retention_days,
                )
            return f"conversation cleanup: {deleted} rows deleted"

        elif callable_name == "conversation_archive" and self._goal_store is not None:
            from memex.memory.cold_storage import archive_expired_conversations

            content_store = self._goal_store.content
            if content_store is not None:
                archived = archive_expired_conversations(content_store)
                return (
                    f"conversation archive: {archived} items archived to cold storage"
                )
            return "conversation archive: no content store configured"

        elif callable_name == "audio_cleanup" and self._goal_store is not None:
            from memex.meetings.cleanup import cleanup_audio

            meeting_store = getattr(self._store, "meetings", None)
            if meeting_store is None:
                return "audio cleanup: skipped (no meeting store available)"
            retention = int(os.environ.get("MEMEX_AUDIO_RETENTION_DAYS", "3"))
            deleted = cleanup_audio(meeting_store, retention_days=retention)
            return f"audio cleanup: {deleted} files deleted"

        elif callable_name == "memory_consolidation":
            content_store = self._goal_store.content if self._goal_store else None
            if content_store is not None:
                try:
                    from memex.memory.consolidation import consolidate_facts
                    from memex.memory.embeddings import SentenceTransformerBackend

                    embedding_backend = SentenceTransformerBackend()
                    merged = consolidate_facts(content_store, embedding_backend)
                    return f"memory consolidation: {merged} facts merged"
                except Exception as exc:
                    logger.error("Memory consolidation failed", exc_info=True)
                    return f"memory consolidation: failed ({type(exc).__name__})"
            return "memory consolidation: no content store configured"

        elif callable_name == "calendar_sync" and self._goal_store is not None:
            try:
                from memex.meetings.upcoming import sync_google_calendar_events

                count = sync_google_calendar_events(self._goal_store)
                return f"calendar sync: {count} events"
            except Exception as exc:
                logger.error("Calendar sync failed", exc_info=True)
                return f"calendar sync: failed ({type(exc).__name__})"

        elif callable_name == "meeting_briefings" and self._goal_store is not None:
            if self._notification_store is None:
                return "meeting briefings: no notification store configured"
            try:
                from memex.meetings.upcoming import prepare_meeting_briefings

                created = prepare_meeting_briefings(
                    self._goal_store,
                    self._notification_store,
                )
                return f"meeting briefings: {created} notifications"
            except Exception as exc:
                logger.error("Meeting briefing preparation failed", exc_info=True)
                return f"meeting briefings: failed ({type(exc).__name__})"

        elif callable_name == "resource_telemetry":
            from memex.resource_telemetry import get_telemetry_store, run_collection

            store = get_telemetry_store()
            if store is None:
                return "resource telemetry: store not initialized"
            fathom = getattr(self._goal_store, "_fathom", None)
            return run_collection(
                store,
                fathom_store=fathom,
                notification_store=self._notification_store,
            )

        return f"callable:{callable_name} (no handler)"

    def _dispatch_prompt(self, action_data: dict, run_id: int) -> str:
        """Send a prompt through the API."""
        from memex.llm import is_llm_available
        from memex.scheduler.work_queue import LLMUnavailableError

        prompt_name = action_data.get("prompt", "")

        if prompt_name == "weekly_review" and self._api is not None:
            if not is_llm_available():
                raise LLMUnavailableError(
                    "LLM proxy unavailable for weekly_review prompt"
                )
            from memex.interfaces.caller import CallerContext

            caller = CallerContext.owner("scheduler", f"scheduled-{run_id}")
            response, _ = self._api.chat(
                "Please give me a weekly review of my goals — what progressed, "
                "what's blocked, and what needs attention this week.",
                caller,
            )
            return response[:200]

        return f"prompt:{prompt_name} (no API)"

    def _dispatch_auto_ingest(self, action_data: dict, run_id: int) -> str:
        """Delegate to auto-ingest registry."""
        source_name = action_data.get("source", "")
        try:
            from memex.auto_ingest.registry import get_default_registry

            registry = get_default_registry()
            source = registry.get_source(source_name)
            if source is None:
                raise RuntimeError(f"Unknown auto-ingest source: {source_name}")
            source.configure(action_data)

            notification_router = None
            if self._notification_store is not None:
                from memex.notifications import NotificationRouter

                notification_router = NotificationRouter(self._notification_store)

            count = registry.run_source(
                source_name,
                content_store=self._goal_store.content if self._goal_store else None,
                memex_store=self._goal_store,
                notification_router=notification_router,
                runtime_registry=self._runtime_registry,
                intake_store=self._intake_store,
            )
            return f"ingested {count} items from {source_name}"
        except Exception as exc:
            raise RuntimeError(f"Auto-ingest {source_name} failed: {exc}") from exc

    def _dispatch_telegram_message(self, action_data: dict, run_id: int) -> str:
        """Process a queued Telegram message when LLM becomes available."""
        from memex.llm import is_llm_available
        from memex.scheduler.work_queue import LLMUnavailableError

        if not is_llm_available():
            raise LLMUnavailableError("LLM proxy unavailable for telegram message")

        if self._api is None:
            raise RuntimeError("No API configured for telegram message dispatch")

        text = action_data.get("text", "")
        session_id = action_data.get("session_id", f"telegram-retry-{run_id}")
        from memex.interfaces.caller import CallerContext

        caller = CallerContext.owner("telegram", session_id)
        response, _ = self._api.chat(text, caller)

        # Deliver response as a TUI notification (async Telegram context is gone)
        if self._notification_store is not None:
            from memex.notifications import NotificationRouter
            from memex.models import NotificationPriority

            NotificationRouter(self._notification_store).notify(
                "Queued Telegram reply",
                body=response[:500],
                priority=NotificationPriority.NORMAL,
                source="telegram-retry",
            )

        intake_id = action_data.get("intake_id")
        if intake_id and self._intake_store is not None:
            self._intake_store.mark_processed(int(intake_id))

        return f"telegram message processed: {len(response)} chars"

    def _dispatch_gmail_message(self, action_data: dict, run_id: int) -> str:
        """Re-ingest a single Gmail message from intake_log action_data.

        Note: ingest() is deterministic — no LLM call required. This dispatcher
        does NOT gate on LLM availability so Gmail replay works while proxy is down.
        """
        content_store = self._goal_store.content if self._goal_store else None
        if content_store is None:
            raise RuntimeError("No content store for gmail message dispatch")

        from memex.memory.intake import ingest

        ingest(
            action_data.get("content", ""),
            type=action_data.get("item_type", "EMAIL"),
            title=action_data.get("title") or None,
            source_url=action_data.get("source_url") or None,
            author=action_data.get("author") or None,
            content_store=content_store,
            memex_store=self._goal_store,
            embedding_backend=None,
            generate_summary=False,
            session_id=f"gmail-replay-{run_id}",
        )

        intake_id = action_data.get("intake_id")
        if intake_id and self._intake_store is not None:
            self._intake_store.mark_processed(int(intake_id))

        return "gmail message re-ingested"

    def _dispatch_transcription(self, action_data: dict, run_id: int) -> str:
        """Transcribe a recorded meeting."""
        meeting_id = action_data["meeting_id"]
        try:
            from memex.meetings.transcribe import orchestrate_transcription

            meeting_store = (
                getattr(self._goal_store, "meetings", None)
                if self._goal_store
                else None
            )
            if meeting_store is None:
                return f"transcription skipped: no meeting store available (meeting_id={meeting_id})"
            content_store = self._goal_store.content if self._goal_store else None

            # Load speaker mappings from human model if available
            speaker_mappings = None
            if self._goal_store is not None:
                try:
                    from memex.human_model import load_canonical_speaker_mappings

                    loaded_mappings = load_canonical_speaker_mappings(self._goal_store)
                    if loaded_mappings:
                        speaker_mappings = loaded_mappings
                except Exception:
                    logger.debug("Failed to load speaker mappings", exc_info=True)

            def _run() -> Any:
                return orchestrate_transcription(
                    meeting_id,
                    meeting_store=meeting_store,
                    content_store=content_store,
                    memex_store=self._goal_store,
                    notification_store=self._notification_store,
                    speaker_mappings=speaker_mappings,
                )

            executor = _cf.ThreadPoolExecutor(max_workers=1)
            future = executor.submit(_run)
            try:
                item = future.result(timeout=_TRANSCRIPTION_TIMEOUT)
            except _cf.TimeoutError:
                executor.shutdown(wait=False, cancel_futures=False)
                try:
                    from memex.meetings.models import MeetingState

                    record = meeting_store.get_meeting(meeting_id)
                    if record is not None and record.recordings:
                        recording = record.recordings[-1]
                        recording.state = MeetingState.FAILED
                        recording.error = (
                            f"Transcription timed out after {_TRANSCRIPTION_TIMEOUT}s. "
                            "Re-queue via the meetings drawer."
                        )
                        meeting_store.update_recording(recording)
                except Exception:
                    logger.debug(
                        "Failed to mark meeting %s FAILED after timeout",
                        meeting_id[:8],
                        exc_info=True,
                    )
                raise RuntimeError(
                    f"Transcription of meeting {meeting_id[:8]} "
                    f"timed out after {_TRANSCRIPTION_TIMEOUT}s"
                )
            finally:
                executor.shutdown(wait=False)

            if item is not None:
                return (
                    f"transcribed meeting {meeting_id[:8]} -> item {item.item_id[:8]}"
                )
            return f"transcribed meeting {meeting_id[:8]} (no content store)"
        except ImportError as exc:
            raise RuntimeError(
                "Transcription requires openai-whisper or nvidia-riva-client. "
                "Install with: pip install memex-claw[transcription]"
            ) from exc
