"""Proactive surfacing: staleness detection, deadline warnings, session briefing."""

from __future__ import annotations

from datetime import datetime, timedelta

from memex.models import GoalStatus, SessionContext
from memex.store import MemexStore
from memex.utcnow import utcnow

# Thresholds
STALE_DAYS = 14
DEADLINE_HOURS = 24
PROACTIVE_INTERVAL = 5  # turns between proactive messages


def check_proactive(
    session: SessionContext,
    store: MemexStore,
    now: datetime | None = None,
) -> str | None:
    """Check for proactive messages. Returns message or None.

    Priority: approaching deadlines > stale goals > blocked goals.
    Throttled to max 1 per PROACTIVE_INTERVAL turns.
    """
    now = now or utcnow()

    # Throttle
    if session.turn_count % PROACTIVE_INTERVAL != 0:
        return None
    if session.turn_count == 0:
        return None

    # Approaching deadlines
    horizon = now + timedelta(hours=DEADLINE_HOURS)
    deadline_goals = store.get_approaching_deadlines(horizon)
    if deadline_goals:
        g = deadline_goals[0]
        delta = g.deadline - now if g.deadline else timedelta()
        hours_left = max(0, delta.total_seconds() / 3600)
        return (
            f"Heads up: **{g.title}** has a deadline approaching "
            f"({hours_left:.0f}h remaining)."
        )

    # Stale goals
    threshold = now - timedelta(days=STALE_DAYS)
    stale = store.get_stale_goals(threshold)
    if stale:
        g = stale[0]
        days = (now - g.last_touched_at).days
        return (
            f"It's been {days} days since we last touched **{g.title}**. "
            f"Still relevant, or should we pause/abandon it?"
        )

    # Blocked goals
    blocked = store.list_goals(GoalStatus.BLOCKED)
    if blocked:
        g = blocked[0]
        return (
            f"Reminder: **{g.title}** is blocked"
            f"{' — ' + g.blocked_reason if g.blocked_reason else ''}. "
            f"Any updates?"
        )

    return None


def get_session_briefing(store: MemexStore, now: datetime | None = None) -> str:
    """Generate a briefing for session start."""
    now = now or utcnow()
    parts: list[str] = ["Here's where things stand:"]

    active = store.list_goals(GoalStatus.ACTIVE)
    if active:
        parts.append(f"\n**Active goals** ({len(active)}):")
        for g in active[:5]:
            parts.append(f"  - {g.title} ({g.priority.value})")
        if len(active) > 5:
            parts.append(f"  ... and {len(active) - 5} more")

    blocked = store.list_goals(GoalStatus.BLOCKED)
    if blocked:
        parts.append(f"\n**Blocked** ({len(blocked)}):")
        for g in blocked[:3]:
            reason = f" — {g.blocked_reason}" if g.blocked_reason else ""
            parts.append(f"  - {g.title}{reason}")

    # Deadlines
    horizon = now + timedelta(hours=DEADLINE_HOURS)
    deadlines = store.get_approaching_deadlines(horizon)
    if deadlines:
        parts.append(f"\n**Approaching deadlines** ({len(deadlines)}):")
        for g in deadlines[:3]:
            parts.append(f"  - {g.title} (due: {g.deadline})")

    # Stale
    threshold = now - timedelta(days=STALE_DAYS)
    stale = store.get_stale_goals(threshold)
    if stale:
        parts.append(f"\n**Stale** (untouched >{STALE_DAYS} days, {len(stale)}):")
        for g in stale[:3]:
            days = (now - g.last_touched_at).days
            parts.append(f"  - {g.title} ({days}d)")

    if len(parts) == 1:
        return "No active goals yet. What would you like to work on?"

    return "\n".join(parts)
