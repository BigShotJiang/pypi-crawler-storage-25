"""Cron expression utilities using croniter."""

from __future__ import annotations

from datetime import datetime, timezone

from croniter import croniter
from memex.utcnow import utcnow


def _format_time(dt: datetime) -> str:
    """Format time as '9:00 AM' (portable, no POSIX-only strftime flags)."""
    hour = dt.hour % 12 or 12
    return f"{hour}:{dt.minute:02d} {'AM' if dt.hour < 12 else 'PM'}"


def validate_cron(cron_expr: str) -> bool:
    """Return True if cron_expr is a valid 5-field cron expression."""
    return croniter.is_valid(cron_expr)


def next_fire_time(cron_expr: str, after: datetime | None = None) -> datetime:
    """Get the next fire time for a cron expression."""
    after = after or utcnow()
    cron = croniter(cron_expr, after)
    return cron.get_next(datetime)


def is_due(
    cron_expr: str, last_run: datetime | None, now: datetime | None = None
) -> bool:
    """Check if a cron task is due to run.

    A task is due if:
    - It has never run (last_run is None), OR
    - The next fire time after last_run is <= now

    Returns False if the cron expression is invalid.
    """
    now = now or utcnow()
    try:
        if last_run is None:
            # Validate cron expression before marking as due
            next_fire_time(cron_expr, after=now)
            return True
        # Ensure all datetimes are aware UTC for consistent comparison.
        if last_run.tzinfo is None:
            last_run = last_run.replace(tzinfo=timezone.utc)
        nxt = next_fire_time(cron_expr, after=last_run)
        if nxt.tzinfo is None:
            nxt = nxt.replace(tzinfo=timezone.utc)
        return nxt <= now
    except (ValueError, KeyError):
        return False


def format_human_readable(dt: datetime) -> str:
    """Format a datetime as 'Monday, March 9th @ 9:00 AM'."""
    day = dt.day
    if 11 <= day <= 13:
        suffix = "th"
    else:
        suffix = {1: "st", 2: "nd", 3: "rd"}.get(day % 10, "th")
    hour = dt.hour % 12 or 12
    minute = f"{dt.minute:02d}"
    ampm = "AM" if dt.hour < 12 else "PM"
    return f"{dt.strftime('%A, %B')} {day}{suffix} @ {hour}:{minute} {ampm}"


def format_cron_human(cron_expr: str) -> str:
    """Convert a cron expression to a human-readable description.

    Handles common patterns. Falls back to the raw expression.
    """
    parts = cron_expr.split()
    if len(parts) != 5:
        return cron_expr

    minute, hour, dom, month, dow = parts

    # Every N hours
    if minute.isdigit() and hour.startswith("*/"):
        interval = hour[2:]
        return f"Every {interval}h at :{minute.zfill(2)}"

    # Daily at specific time
    if (
        minute.isdigit()
        and hour.isdigit()
        and dom == "*"
        and month == "*"
        and dow == "*"
    ):
        t = datetime(2000, 1, 1, int(hour), int(minute))
        return f"Daily at {_format_time(t)}"

    # Weekly on specific day
    day_names = {
        "0": "Sunday",
        "1": "Monday",
        "2": "Tuesday",
        "3": "Wednesday",
        "4": "Thursday",
        "5": "Friday",
        "6": "Saturday",
        "7": "Sunday",
    }
    if (
        minute.isdigit()
        and hour.isdigit()
        and dom == "*"
        and month == "*"
        and dow in day_names
    ):
        t = datetime(2000, 1, 1, int(hour), int(minute))
        return f"Every {day_names[dow]} at {_format_time(t)}"

    return cron_expr
