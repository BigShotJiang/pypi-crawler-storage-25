"""Scheduler package — cron-based task scheduling with work queue execution."""

from memex.scheduler.proactive import (
    DEADLINE_HOURS,
    PROACTIVE_INTERVAL,
    STALE_DAYS,
    check_proactive,
    get_session_briefing,
)

__all__ = [
    "DEADLINE_HOURS",
    "PROACTIVE_INTERVAL",
    "STALE_DAYS",
    "check_proactive",
    "get_session_briefing",
]
