"""File-based credential storage in ~/.memex/auth/ with secure permissions."""

from __future__ import annotations

import json
import os
import stat
from datetime import datetime, timezone
from pathlib import Path
from memex.utcnow import utcnow


def _auth_dir() -> Path:
    """Get the auth directory, creating with secure permissions if needed."""
    d = Path.home() / ".memex" / "auth"
    if not d.exists():
        d.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(d, stat.S_IRWXU)  # 0700
        except OSError:
            pass
    return d


def _service_path(service: str) -> Path:
    """Get the credential file path for a service."""
    # Sanitize service name
    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in service)
    return _auth_dir() / f"{safe}.json"


def save_credentials(service: str, token_data: dict) -> None:
    """Save credentials for a service. Sets file permissions to 0600."""
    path = _service_path(service)
    data = {
        "service": service,
        "saved_at": utcnow().isoformat(),
        **token_data,
    }
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    try:
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)  # 0600
    except OSError:
        pass


def get_credentials(service: str) -> dict | None:
    """Load credentials for a service. Returns None if not found."""
    path = _service_path(service)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def delete_credentials(service: str) -> None:
    """Delete credentials for a service."""
    path = _service_path(service)
    if path.exists():
        path.unlink()


def list_services() -> list[str]:
    """List all services with stored credentials."""
    d = _auth_dir()
    if not d.exists():
        return []
    return [p.stem for p in sorted(d.glob("*.json"))]


def is_token_expired(token_data: dict) -> bool:
    """Check if an OAuth token is expired based on expires_at field."""
    expires_at = token_data.get("expires_at")
    if expires_at is None:
        return False
    try:
        if isinstance(expires_at, (int, float)):
            return datetime.fromtimestamp(expires_at, tz=timezone.utc) < utcnow()
        parsed = datetime.fromisoformat(expires_at)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed < utcnow()
    except (ValueError, TypeError, OSError):
        return True
