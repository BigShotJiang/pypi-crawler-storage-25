"""Generic OAuth2 + PKCE flow for service authentication."""

from __future__ import annotations

import base64
import hashlib
import http.server
import logging
import secrets
import urllib.parse
import webbrowser
from typing import Any

import httpx

from memex.auth.store import save_credentials

logger = logging.getLogger(__name__)


class OAuth2Flow:
    """Generic OAuth2 flow with optional PKCE support.

    Usage:
        flow = OAuth2Flow(
            service="outlook",
            client_id="...",
            auth_url="https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
            token_url="https://login.microsoftonline.com/common/oauth2/v2.0/token",
            scopes=["Calendars.Read"],
        )
        credentials = flow.run_local_server()
    """

    def __init__(
        self,
        service: str,
        client_id: str,
        auth_url: str,
        token_url: str,
        scopes: list[str],
        *,
        client_secret: str = "",
        use_pkce: bool = True,
        redirect_port: int = 8765,
    ) -> None:
        self.service = service
        self.client_id = client_id
        self.client_secret = client_secret
        self.auth_url = auth_url
        self.token_url = token_url
        self.scopes = scopes
        self.use_pkce = use_pkce
        self.redirect_port = redirect_port
        self.redirect_uri = f"http://localhost:{redirect_port}/callback"

        # PKCE values
        self._code_verifier = ""
        self._code_challenge = ""
        if use_pkce:
            self._code_verifier = secrets.token_urlsafe(64)
            digest = hashlib.sha256(self._code_verifier.encode()).digest()
            self._code_challenge = (
                base64.urlsafe_b64encode(digest).rstrip(b"=").decode()
            )

    def get_authorization_url(self) -> tuple[str, str]:
        """Build the authorization URL. Returns (url, state)."""
        state = secrets.token_urlsafe(32)
        params = {
            "client_id": self.client_id,
            "response_type": "code",
            "redirect_uri": self.redirect_uri,
            "scope": " ".join(self.scopes),
            "state": state,
        }
        if self.use_pkce:
            params["code_challenge"] = self._code_challenge
            params["code_challenge_method"] = "S256"
        url = f"{self.auth_url}?{urllib.parse.urlencode(params)}"
        return url, state

    def exchange_code(self, code: str, state: str) -> dict:
        """Exchange authorization code for tokens."""
        data = {
            "client_id": self.client_id,
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": self.redirect_uri,
        }
        if self.use_pkce:
            data["code_verifier"] = self._code_verifier
        if self.client_secret:
            data["client_secret"] = self.client_secret

        resp = httpx.post(self.token_url, data=data, timeout=30)
        resp.raise_for_status()
        token_data = resp.json()

        # Save credentials
        save_credentials(self.service, token_data)
        return token_data

    def refresh(self, refresh_token: str) -> dict:
        """Refresh an access token."""
        data = {
            "client_id": self.client_id,
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "scope": " ".join(self.scopes),
        }
        if self.client_secret:
            data["client_secret"] = self.client_secret

        resp = httpx.post(self.token_url, data=data, timeout=30)
        resp.raise_for_status()
        token_data = resp.json()

        save_credentials(self.service, token_data)
        return token_data

    def run_local_server(self) -> dict:
        """Run the full OAuth2 flow with a local callback server.

        Opens the browser for authorization, catches the callback on localhost.
        Returns the token data.
        """
        auth_url, state = self.get_authorization_url()
        result: dict[str, Any] = {}
        error: list[str] = []

        class CallbackHandler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)

                if "error" in query:
                    error.append(query["error"][0])
                    self.send_response(400)
                    self.end_headers()
                    self.wfile.write(
                        b"Authorization failed. You can close this window."
                    )
                    return

                code = query.get("code", [""])[0]
                returned_state = query.get("state", [""])[0]

                if returned_state != state:
                    error.append("State mismatch")
                    self.send_response(400)
                    self.end_headers()
                    self.wfile.write(b"State mismatch. You can close this window.")
                    return

                result["code"] = code
                self.send_response(200)
                self.end_headers()
                self.wfile.write(
                    b"Authorization successful! You can close this window."
                )

            def log_message(self, format, *args):
                pass  # Suppress HTTP server logs

        server = http.server.HTTPServer(
            ("localhost", self.redirect_port), CallbackHandler
        )

        print(f"\nOpening browser for {self.service} authorization...")
        print(f"If the browser doesn't open, visit:\n{auth_url}\n")
        webbrowser.open(auth_url)

        # Handle one request (the callback)
        server.handle_request()
        server.server_close()

        if error:
            raise RuntimeError(f"OAuth2 authorization failed: {error[0]}")

        if "code" not in result:
            raise RuntimeError("No authorization code received")

        return self.exchange_code(result["code"], state)
