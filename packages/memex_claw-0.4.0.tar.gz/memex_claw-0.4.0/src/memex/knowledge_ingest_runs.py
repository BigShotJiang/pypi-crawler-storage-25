"""Shared helpers for canonical knowledge-ingest lifecycle records."""

from __future__ import annotations

from typing import Any

from memex.models import Item, WorldModelKnowledgeIngestRun
from memex.utcnow import utcnow


def normalize_ingest_source_ref(source_ref: str) -> str:
    return source_ref.strip()


def knowledge_id_from_result(result: dict[str, Any] | None) -> str | None:
    if result is None:
        return None
    document_id = str(result.get("document_id") or "")
    if document_id.startswith("world_model_knowledge:"):
        return document_id.split(":", 1)[1]
    return None


def followup_document_id_for_item(
    item_id: str,
    *,
    content_store: Any,
    world_model_store: Any,
) -> str:
    from memex.memory.world_model_reads import resolve_world_model_reads

    try:
        reads = resolve_world_model_reads(
            content_store=content_store,
            world_model_store=world_model_store,
        )
        if reads is not None:
            document_id = reads.canonical_document_id_for_item(item_id)
            if document_id:
                return document_id
    except Exception:
        pass
    return f"content_item:{item_id}"


def build_ingest_result(
    item: Item,
    *,
    content_store: Any,
    world_model_store: Any,
    source_ref: str,
) -> dict[str, Any]:
    return {
        "item_id": item.item_id,
        "document_id": followup_document_id_for_item(
            item.item_id,
            content_store=content_store,
            world_model_store=world_model_store,
        ),
        "title": item.title or source_ref,
        "summary": item.summary.text or "",
        "source_url": item.source_url or source_ref,
    }


def start_knowledge_ingest_run(
    store: Any,
    *,
    ingest_kind: str,
    trigger_surface: str,
    source_ref: str,
    requested_item_type: str,
    session_id: str = "",
    payload: dict[str, Any] | None = None,
) -> WorldModelKnowledgeIngestRun:
    from memex.world_model_backbone import build_world_model_knowledge_ingest_run

    run = build_world_model_knowledge_ingest_run(
        ingest_kind=ingest_kind,
        trigger_surface=trigger_surface,
        source_ref=source_ref,
        normalized_source_ref=normalize_ingest_source_ref(source_ref),
        requested_item_type=requested_item_type,
        session_id=session_id or None,
        payload=payload or {},
    )
    store.upsert_world_model_knowledge_ingest_run(run)
    return run


def update_knowledge_ingest_run(
    store: Any,
    run: WorldModelKnowledgeIngestRun,
    *,
    status: str,
    phase: str,
    result: dict[str, Any] | None = None,
    fallback_used: bool | None = None,
    error: str | None = None,
    payload_update: dict[str, Any] | None = None,
    summary_model: str | None = None,
    finished: bool = False,
) -> WorldModelKnowledgeIngestRun:
    now = utcnow()
    payload = dict(run.payload)
    if payload_update:
        payload.update(payload_update)
    if result is not None:
        payload["result"] = dict(result)
    updated = run.model_copy(
        update={
            "status": status,
            "phase": phase,
            "fallback_used": run.fallback_used
            if fallback_used is None
            else fallback_used,
            "item_id": result.get("item_id") if result is not None else run.item_id,
            "knowledge_id": knowledge_id_from_result(result) or run.knowledge_id,
            "summary_model": (
                run.summary_model if summary_model is None else summary_model
            ),
            "error": run.error if error is None else error,
            "payload": payload,
            "updated_at": now,
            "finished_at": now if finished else run.finished_at,
        }
    )
    store.upsert_world_model_knowledge_ingest_run(updated)
    return updated


def record_knowledge_ingest_projection(
    store: Any,
    run: WorldModelKnowledgeIngestRun,
    *,
    result: dict[str, Any] | None = None,
) -> None:
    from memex.world_model_backbone import (
        build_world_model_knowledge_ingest_action,
        build_world_model_knowledge_ingest_event,
        build_world_model_knowledge_ingest_observation,
        build_world_model_provenance_link,
    )

    payload = dict(run.payload)
    payload["run_id"] = run.ingest_run_id
    payload["source_ref"] = run.source_ref
    payload["item_type"] = run.requested_item_type
    payload["fallback_used"] = run.fallback_used
    payload["error"] = run.error

    succeeded = run.status in {"completed", "fallback_completed"}
    summary = (
        f'Saved "{result.get("title") or run.source_ref}".'
        if succeeded and result is not None
        else f"Failed to ingest {run.source_ref}."
    )
    action = build_world_model_knowledge_ingest_action(
        ingest_kind=run.ingest_kind,
        session_id=run.session_id,
        source_ref=run.source_ref,
        item_type=run.requested_item_type,
        status="succeeded" if succeeded else "failed",
        payload=payload,
    )
    observation = build_world_model_knowledge_ingest_observation(
        action,
        summary=summary,
        status="succeeded" if succeeded else "failed",
        payload=payload,
    )
    event = build_world_model_knowledge_ingest_event(
        action,
        title=(
            f"Knowledge ingest: {result.get('title') or run.source_ref}"
            if result
            else f"Knowledge ingest failed: {run.source_ref}"
        ),
        summary=summary,
        payload=payload,
    )
    store.upsert_world_model_action(action)
    store.upsert_world_model_observation(observation)
    store.upsert_world_model_event(event)
    store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_observation",
            observation.observation_id,
            "world_model_action",
            action.action_id,
            "observed_from",
        )
    )
    store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_action",
            action.action_id,
            "knowledge_ingest_run",
            run.ingest_run_id,
            "tracks_ingest_run",
        )
    )
    store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_event",
            event.event_id,
            "knowledge_ingest_run",
            run.ingest_run_id,
            "records_ingest_run",
        )
    )
    if result is not None and run.knowledge_id:
        store.upsert_world_model_provenance_link(
            build_world_model_provenance_link(
                "knowledge_ingest_run",
                run.ingest_run_id,
                "world_model_knowledge",
                run.knowledge_id,
                "produced_fallback_bookmark"
                if run.fallback_used
                else "produced_knowledge",
            )
        )
    if result is not None:
        knowledge_id = knowledge_id_from_result(result)
        if knowledge_id:
            store.upsert_world_model_provenance_link(
                build_world_model_provenance_link(
                    "world_model_action",
                    action.action_id,
                    "world_model_knowledge",
                    knowledge_id,
                    "ingested_knowledge",
                )
            )
            store.upsert_world_model_provenance_link(
                build_world_model_provenance_link(
                    "world_model_event",
                    event.event_id,
                    "world_model_knowledge",
                    knowledge_id,
                    "records_ingest_of",
                )
            )
