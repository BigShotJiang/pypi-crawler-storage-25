"""Database backup — FathomDB backup with rotation."""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

# Default retention: keep last 24 backups (24h at hourly, or 24 days at daily)
DEFAULT_MAX_BACKUPS = int(os.environ.get("MEMEX_BACKUP_MAX", "24"))


def backup_dir() -> Path:
    """Return (and create) the backup directory."""
    d = Path.home() / ".memex" / "backups"
    d.mkdir(parents=True, exist_ok=True)
    return d


def backup_fathomdb(fathom_store: Any, *, tag: str = "") -> Path | None:
    """Safe backup of a fathomdb database via Engine.admin.safe_export().

    Uses fathomdb's built-in export which forces a WAL checkpoint before
    copying, ensuring the backup contains all committed data.
    Returns the backup path, or None on failure.
    """
    ts = utcnow().strftime("%Y%m%dT%H%M%S")
    suffix = f"-{tag}" if tag else ""
    dest = backup_dir() / f"fathom{suffix}-{ts}.db"

    try:
        admin = getattr(fathom_store, "admin", None)
        if admin is None:
            logger.debug("FathomStore has no admin — skipping backup")
            return None
        admin.safe_export(str(dest), force_checkpoint=True)
        logger.info("FathomDB backup: %s", dest.name)
        return dest
    except Exception:
        logger.error("FathomDB backup failed", exc_info=True)
        dest.unlink(missing_ok=True)
        return None


def rotate_backups(*, max_backups: int = DEFAULT_MAX_BACKUPS) -> int:
    """Delete oldest backups beyond the retention limit."""
    d = backup_dir()
    deleted = 0
    files = sorted(d.glob("*.db"), key=lambda f: f.stat().st_mtime, reverse=True)
    for old in files[max_backups:]:
        old.unlink()
        deleted += 1
        logger.debug("Rotated out backup: %s", old.name)
    return deleted


def backup_all(
    *,
    tag: str = "",
    max_backups: int = DEFAULT_MAX_BACKUPS,
) -> dict[str, Path | None]:
    """Run all backups and rotate."""
    from memex.paths import resolve_store_path

    results: dict[str, Path | None] = {}

    fathom_path = Path(resolve_store_path()).parent / "fathom.db"
    try:
        from memex.fathom_store import FathomStore

        fathom = FathomStore.open(str(fathom_path))
        results["fathomdb"] = backup_fathomdb(fathom, tag=tag)
        fathom.close()
    except Exception:
        logger.debug("FathomDB backup skipped", exc_info=True)

    rotate_backups(max_backups=max_backups)
    return results
