"""Deterministic prompt-budget helpers for the 0.8 runtime prompt."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

_CHARS_PER_TOKEN = 4
_TRUNCATION_MARKER = "\n... [prompt budget truncated]"


@dataclass(frozen=True)
class PromptBudgetConfig:
    stable_prefix_tokens: int = 1600
    dynamic_turn_tokens: int = 900
    retrieval_tokens: int = 750
    operator_tokens: int = 250


@dataclass(frozen=True)
class PromptBudgetSection:
    name: str
    text: str
    max_tokens: int


@dataclass(frozen=True)
class PromptBudgetUsage:
    """Per-section actual usage after budgeting."""

    section_name: str
    max_tokens: int
    actual_tokens_approx: int
    truncated: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "name": self.section_name,
            "max_tokens": self.max_tokens,
            "actual_tokens": self.actual_tokens_approx,
            "truncated": self.truncated,
        }


@dataclass(frozen=True)
class BudgetedPromptContext:
    stable_parts: list[str]
    dynamic_parts: list[str]
    operator_parts: list[str]
    retrieval_text: str
    usage: list[PromptBudgetUsage] = field(default_factory=list)


DEFAULT_PROMPT_BUDGET = PromptBudgetConfig()


def load_prompt_budget_config(
    settings: Any = None,
    base: PromptBudgetConfig | None = None,
) -> PromptBudgetConfig:
    """Load budget config from settings store, env vars, or base defaults.

    Resolution per field: settings table -> MEMEX_PROMPT_BUDGET_{FIELD} -> base.
    When base is None, uses DEFAULT_PROMPT_BUDGET.
    Returns the base config when settings is None or has no overrides.
    """
    if base is None:
        base = DEFAULT_PROMPT_BUDGET
    if settings is None:
        return base
    try:
        get_int = getattr(settings, "get_int", None)
        if not callable(get_int):
            return base
        stable = get_int("prompt_budget_stable", default=base.stable_prefix_tokens)
        dynamic = get_int("prompt_budget_dynamic", default=base.dynamic_turn_tokens)
        retrieval = get_int("prompt_budget_retrieval", default=base.retrieval_tokens)
        operator = get_int("prompt_budget_operator", default=base.operator_tokens)
        if not all(isinstance(v, int) for v in (stable, dynamic, retrieval, operator)):
            return base
        return PromptBudgetConfig(
            stable_prefix_tokens=stable,
            dynamic_turn_tokens=dynamic,
            retrieval_tokens=retrieval,
            operator_tokens=operator,
        )
    except Exception:
        return base


class PromptMode(str, Enum):
    """Controls which prompt sections are included."""

    FULL = "full"  # All sections (default)
    MINIMAL = "minimal"  # Drop low-value sections for sub-agents / quick_check
    BARE = "bare"  # Only governance + identity


_ROUTE_SUFFIXES = ("_strict", "_open", "_tool", "_verified", "_draft", "_review")


def abbreviate_route(route_profile: str, prompt_mode: str = "full") -> str:
    """Compact route profile label for TUI header display."""
    if not route_profile:
        return ""
    short = route_profile
    for suffix in _ROUTE_SUFFIXES:
        short = short.replace(suffix, "")
    if prompt_mode != "full":
        short = f"{short}/{prompt_mode}"
    return short


_MINIMAL_DROP = frozenset(
    {
        "skill_block",
        "session_items",
        "proactive_context",
        "world_model",
        "session_summary",
    }
)
_BARE_KEEP = frozenset({"governance", "identity"})


def filter_sections_for_mode(
    sections: list[PromptBudgetSection],
    *,
    mode: PromptMode,
) -> list[PromptBudgetSection]:
    """Filter prompt sections based on prompt mode."""
    if mode == PromptMode.FULL:
        return sections
    if mode == PromptMode.BARE:
        return [s for s in sections if s.name in _BARE_KEEP]
    # MINIMAL
    return [s for s in sections if s.name not in _MINIMAL_DROP]


def truncate_prompt_text(text: str, *, max_tokens: int) -> str:
    """Clip prompt text to an approximate token budget."""
    if not text:
        return ""

    max_chars = max_tokens * _CHARS_PER_TOKEN
    if max_chars <= 0:
        return ""
    if len(text) <= max_chars:
        return text

    marker = _TRUNCATION_MARKER
    if len(marker) >= max_chars:
        return text[:max_chars]

    cutoff = max_chars - len(marker)
    newline_cutoff = text.rfind("\n", 0, cutoff)
    if newline_cutoff >= int(cutoff * 0.6):
        cutoff = newline_cutoff

    return text[:cutoff].rstrip() + marker


def _budget_bucket(
    sections: list[PromptBudgetSection],
    *,
    bucket_tokens: int,
) -> tuple[list[str], list[PromptBudgetUsage]]:
    remaining_chars = bucket_tokens * _CHARS_PER_TOKEN
    kept: list[str] = []
    usage: list[PromptBudgetUsage] = []
    for section in sections:
        original_text = truncate_prompt_text(
            section.text, max_tokens=section.max_tokens
        )
        if not original_text or remaining_chars <= 0:
            if section.text:
                usage.append(
                    PromptBudgetUsage(section.name, section.max_tokens, 0, True)
                )
            continue
        separator_chars = 2 if kept else 0
        if remaining_chars <= separator_chars:
            usage.append(PromptBudgetUsage(section.name, section.max_tokens, 0, True))
            break
        if len(original_text) <= remaining_chars:
            if separator_chars:
                remaining_chars -= separator_chars
            kept.append(original_text)
            remaining_chars -= len(original_text)
            actual = len(original_text) // _CHARS_PER_TOKEN
            was_truncated = len(section.text) > len(original_text)
            usage.append(
                PromptBudgetUsage(
                    section.name, section.max_tokens, actual, was_truncated
                )
            )
            continue
        clipped = truncate_prompt_text(
            original_text,
            max_tokens=max((remaining_chars - separator_chars) // _CHARS_PER_TOKEN, 0),
        )
        if clipped:
            if separator_chars:
                remaining_chars -= separator_chars
            kept.append(clipped)
            remaining_chars -= len(clipped)
            actual = len(clipped) // _CHARS_PER_TOKEN
            usage.append(
                PromptBudgetUsage(section.name, section.max_tokens, actual, True)
            )
    return kept, usage


def budget_prompt_context(
    *,
    stable_sections: list[PromptBudgetSection],
    dynamic_sections: list[PromptBudgetSection],
    operator_sections: list[PromptBudgetSection],
    retrieval_text: str,
    config: PromptBudgetConfig = DEFAULT_PROMPT_BUDGET,
) -> BudgetedPromptContext:
    """Apply explicit bucket budgets to prompt sections."""
    stable_parts, stable_usage = _budget_bucket(
        stable_sections,
        bucket_tokens=config.stable_prefix_tokens,
    )
    dynamic_parts, dynamic_usage = _budget_bucket(
        dynamic_sections,
        bucket_tokens=config.dynamic_turn_tokens,
    )
    operator_parts, operator_usage = _budget_bucket(
        operator_sections,
        bucket_tokens=config.operator_tokens,
    )
    clipped_retrieval = truncate_prompt_text(
        retrieval_text,
        max_tokens=config.retrieval_tokens,
    )
    retrieval_usage = []
    if retrieval_text:
        retrieval_usage = [
            PromptBudgetUsage(
                "retrieval",
                config.retrieval_tokens,
                len(clipped_retrieval) // _CHARS_PER_TOKEN,
                len(retrieval_text) > len(clipped_retrieval),
            )
        ]

    return BudgetedPromptContext(
        stable_parts=stable_parts,
        dynamic_parts=dynamic_parts,
        operator_parts=operator_parts,
        retrieval_text=clipped_retrieval,
        usage=stable_usage + dynamic_usage + operator_usage + retrieval_usage,
    )
