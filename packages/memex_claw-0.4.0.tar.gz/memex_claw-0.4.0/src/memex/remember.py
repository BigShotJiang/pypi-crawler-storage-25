"""Remember tool — classify intent and store facts, context, or reminders."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta
from enum import Enum
from typing import TYPE_CHECKING, Any
from memex.utcnow import utcnow

if TYPE_CHECKING:
    from memex.memory.protocols import ContentStoreProtocol
    from memex.store import MemexStore

from pydantic import BaseModel

from memex.models import (
    ActionType,
    Goal,
    GoalPriority,
    GoalStatus,
    Item,
    ItemType,
    Provenance,
    ScheduledTask,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Classification schema
# ---------------------------------------------------------------------------


class RememberIntent(str, Enum):
    FACT = "fact"
    CONTEXT = "context"
    REMINDER = "reminder"


class RememberClassification(BaseModel):
    intent: RememberIntent
    title: str
    body: str
    tags: list[str] = []
    reminder_time: str | None = None  # ISO or natural language
    is_recurring: bool = False
    cron_expr: str | None = None
    is_actionable: bool = False  # Whether reminder should create a Goal


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def to_one_shot_cron(dt: datetime) -> str:
    """Convert a datetime to a cron expression that fires at that time.

    The scheduler marks one_shot tasks as disabled after first fire.
    """
    return f"{dt.minute} {dt.hour} {dt.day} {dt.month} *"


def _parse_reminder_time(time_str: str | None) -> datetime | None:
    """Parse a reminder time string — ISO first, dateparser fallback."""
    if not time_str:
        return None

    # Try ISO parse first
    try:
        return datetime.fromisoformat(time_str)
    except (ValueError, TypeError):
        pass

    # dateparser fallback
    try:
        import dateparser

        result = dateparser.parse(
            time_str,
            settings={"PREFER_DATES_FROM": "future"},
        )
        return result
    except Exception:
        logger.debug("dateparser failed for %r", time_str, exc_info=True)
        return None


def _classify(text: str, session_summary: str = "") -> RememberClassification:
    """Classify remember intent via LLM micro-call."""
    from memex.llm import chat_structured

    messages = [
        {
            "role": "system",
            "content": (
                "Given a user's request to 'remember' something, classify the intent and extract structured data.\n\n"
                "Intents:\n"
                "- FACT: A piece of information to store (password, preference, decision, reference, observation)\n"
                "- CONTEXT: User wants to save what was just discussed ('remember this', 'save this conversation')\n"
                "- REMINDER: User wants to be reminded to do something at a future time ('remember to X', 'remind me to Y on Z')\n\n"
                "For REMINDER: extract the time/date and set is_actionable=true if the reminder involves doing something "
                "(e.g. 'call mom', 'file taxes') vs just being informed (e.g. 'the meeting starts').\n\n"
                "Always generate a concise title and a body that captures the full content."
            ),
        },
        {
            "role": "user",
            "content": f"Remember request: {text}\n\nSession context: {session_summary or 'none'}",
        },
    ]

    return chat_structured(messages, RememberClassification)


# ---------------------------------------------------------------------------
# Storage paths
# ---------------------------------------------------------------------------


def _remember_fact(
    classification: RememberClassification,
    content_store: ContentStoreProtocol,
    memex_store: MemexStore | None = None,
    session_id: str = "",
) -> Item:
    """Store a fact as a NOTE item."""
    now = utcnow()
    item = Item(
        item_id=str(uuid.uuid4()),
        type=ItemType.NOTE,
        title=classification.title,
        body=classification.body,
        captured_at=now,
        last_accessed=now,
        tags=list(set(classification.tags + ["remembered"])),
        provenance=Provenance(
            source="remember",
            captured_at=now,
            confidence=1.0,
        ),
        metadata={
            "remember_source": "user_command",
            "session_id": session_id,
            "typed_knowledge": {
                "statement": classification.body,
                "claim_kind": "fact",
            },
        },
    )
    try:
        from memex.typed_knowledge import seed_typed_knowledge_metadata

        seed_typed_knowledge_metadata(item, item.metadata.get("typed_knowledge"))
    except Exception:
        logger.debug("Failed to seed remembered fact typed metadata", exc_info=True)
    content_store.create_item(item)
    try:
        from memex.typed_knowledge import sync_item_projection_if_needed

        sync_item_projection_if_needed(memex_store, content_store, item)
    except Exception:
        logger.debug(
            "Failed to sync remembered fact into typed knowledge", exc_info=True
        )
    return item


def _remember_context(
    classification: RememberClassification,
    content_store: ContentStoreProtocol,
    memex_store: MemexStore,
    session_id: str = "",
    session: Any = None,
) -> Item:
    """Capture current session context as a CONVERSATION item."""
    now = utcnow()

    # Build context body from session (use passed-in session to avoid double load)
    context_parts = []
    if session is None and memex_store is not None:
        try:
            session = memex_store.load_session()
        except Exception:
            logger.debug("Failed to load session for context capture", exc_info=True)

    if session is not None:
        if session.active_task_context:
            context_parts.append(f"## Active Task\n{session.active_task_context}")
        if session.conversation_summary:
            context_parts.append(
                f"## Conversation Summary\n{session.conversation_summary}"
            )
        recent = session.conversation_history[-5:]
        if recent:
            formatted = "\n".join(f"**{t.role}**: {t.content[:500]}" for t in recent)
            context_parts.append(f"## Recent Turns\n{formatted}")
        if session.working_memory:
            wm = "\n".join(f"- **{k}**: {v}" for k, v in session.working_memory.items())
            context_parts.append(f"## Working Memory\n{wm}")

    # LLM body supplements session state
    if classification.body:
        context_parts.insert(0, f"## Summary\n{classification.body}")

    body = "\n\n".join(context_parts) if context_parts else classification.body

    item = Item(
        item_id=str(uuid.uuid4()),
        type=ItemType.CONVERSATION,
        title=classification.title,
        body=body,
        captured_at=now,
        last_accessed=now,
        tags=list(set(classification.tags + ["session-capture"])),
        provenance=Provenance(
            source="session_capture",
            captured_at=now,
            confidence=1.0,
        ),
        metadata={
            "remember_source": "session_capture",
            "session_id": session_id,
            "turn_count": session.turn_count if session else 0,
            "typed_knowledge": {
                "summary": classification.body,
            },
        },
    )
    try:
        from memex.typed_knowledge import seed_typed_knowledge_metadata

        seed_typed_knowledge_metadata(item, item.metadata.get("typed_knowledge"))
    except Exception:
        logger.debug("Failed to seed remembered context typed metadata", exc_info=True)
    content_store.create_item(item)
    try:
        from memex.typed_knowledge import sync_item_projection_if_needed

        sync_item_projection_if_needed(memex_store, content_store, item)
    except Exception:
        logger.debug(
            "Failed to sync remembered context into typed knowledge", exc_info=True
        )
    return item


def _remember_reminder(
    classification: RememberClassification,
    scheduler_store: Any,
    memex_store: MemexStore,
    *,
    existing_goal_id: str | None = None,
) -> dict[str, Any]:
    """Create a ScheduledTask (+ optional Goal) for a reminder."""
    now = utcnow()
    task_id = f"reminder-{uuid.uuid4().hex[:12]}"

    # Parse reminder time
    remind_at = _parse_reminder_time(classification.reminder_time)

    # Build cron expression
    if classification.is_recurring and classification.cron_expr:
        cron_expr = classification.cron_expr
    elif remind_at:
        cron_expr = to_one_shot_cron(remind_at)
    else:
        # Default: 1 hour from now
        remind_at = now + timedelta(hours=1)
        cron_expr = to_one_shot_cron(remind_at)

    linked_goal_id = existing_goal_id

    # Create Goal for actionable reminders unless one was explicitly supplied.
    if (
        classification.is_actionable
        and memex_store is not None
        and linked_goal_id is None
    ):
        linked_goal_id = str(uuid.uuid4())
        goal = Goal(
            goal_id=linked_goal_id,
            title=classification.title,
            description=classification.body,
            status=GoalStatus.ACTIVE,
            priority=GoalPriority.MEDIUM,
            deadline=remind_at,
            created_at=now,
            updated_at=now,
            last_touched_at=now,
            metadata={
                "source": "remember",
                "reminder_task_id": task_id,
            },
        )
        memex_store.create_goal(goal)

    task = ScheduledTask(
        task_id=task_id,
        name=f"Reminder: {classification.title}",
        description=classification.body,
        cron_expr=cron_expr,
        action_type=ActionType.NOTIFICATION,
        goal_id=linked_goal_id,
        action_data={
            "generator": "reminder",
            "title": f"Reminder: {classification.title}",
            "body": classification.body,
            "priority": "normal",
            "one_shot": not classification.is_recurring,
            "remind_at": remind_at.isoformat() if remind_at else "",
            "task_id": task_id,
            "goal_id": linked_goal_id,
        },
        enabled=True,
        builtin=False,
        created_at=now,
        updated_at=now,
    )
    scheduler_store.create_task(task)

    result: dict[str, Any] = {
        "task_id": task_id,
        "remind_at": remind_at,
        "is_recurring": classification.is_recurring,
        "goal_created": (
            linked_goal_id is not None
            and existing_goal_id is None
            and classification.is_actionable
        ),
    }
    if linked_goal_id is not None:
        result["goal_id"] = linked_goal_id

    return result


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def _emit_remembered(item_id: str, title: str, intent: str) -> None:
    from memex.event_bus import safe_publish
    from memex.events import ItemRemembered

    safe_publish(ItemRemembered(item_id=item_id, title=title, intent=intent))


def execute_remember(
    text: str,
    *,
    content_store: ContentStoreProtocol,
    memex_store: MemexStore | None = None,
    scheduler_store: Any = None,
    goal_id: str | None = None,
    session_id: str = "",
    session_summary: str = "",
    session: Any = None,
) -> dict[str, Any]:
    """Classify intent and route to the appropriate storage path.

    Returns a dict with keys: intent, title, item_id/task_id, and any extras.
    """
    classification = _classify(text, session_summary)

    if classification.intent == RememberIntent.FACT:
        item = _remember_fact(classification, content_store, memex_store, session_id)
        _emit_remembered(item.item_id, item.title, "fact")
        return {
            "intent": "fact",
            "title": item.title,
            "item_id": item.item_id,
            "tags": item.tags,
        }

    elif classification.intent == RememberIntent.CONTEXT:
        item = _remember_context(
            classification,
            content_store,
            memex_store,
            session_id,
            session=session,
        )
        _emit_remembered(item.item_id, item.title, "context")
        return {
            "intent": "context",
            "title": item.title,
            "item_id": item.item_id,
            "tags": item.tags,
            "turn_count": item.metadata.get("turn_count", 0),
        }

    elif classification.intent == RememberIntent.REMINDER:
        if scheduler_store is None:
            raise RuntimeError(
                "Scheduler store not configured — cannot create reminders"
            )
        result = _remember_reminder(
            classification,
            scheduler_store,
            memex_store,
            existing_goal_id=goal_id,
        )
        _emit_remembered(result["task_id"], classification.title, "reminder")
        return {
            "intent": "reminder",
            "title": classification.title,
            "task_id": result["task_id"],
            "remind_at": result["remind_at"].isoformat()
            if result.get("remind_at")
            else None,
            "is_recurring": result["is_recurring"],
            "goal_id": result.get("goal_id"),
            "goal_created": result.get("goal_created", False),
        }

    else:
        raise ValueError(f"Unknown intent: {classification.intent}")
