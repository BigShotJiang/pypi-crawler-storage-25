"""Helpers for the additive 0.8 world-model backbone sidecar."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from memex.models import (
    AgentSelfModel,
    HumanPartnerProfile,
    IntentFrame,
    IntentFramePath,
    ToolResult,
    WorldModelAction,
    WorldModelEntity,
    WorldModelEntityAttribute,
    WorldModelEntityType,
    WorldModelEvent,
    WorldModelKnowledgeIngestRun,
    WorldModelIntent,
    WorldModelObservation,
    WorldModelProvenanceLink,
    WorldModelSemanticMapping,
)
from memex.utcnow import utcnow

PARTNER_CANONICAL_KEY = "partner/default"
AGENT_CANONICAL_KEY = "agent/memex"


def _now_or(value: datetime | None) -> datetime:
    return value or utcnow()


def _make_attr(
    entity_id: str,
    group: str,
    key: str,
    *,
    value_text: str | None = None,
    value_json: Any | None = None,
    provenance_kind: str,
    provenance_ref: str,
    observed_at: datetime,
    updated_at: datetime,
) -> WorldModelEntityAttribute:
    return WorldModelEntityAttribute(
        attribute_id=f"{entity_id}:{group}:{key}",
        entity_id=entity_id,
        attribute_group=group,
        attribute_key=key,
        value_text=value_text,
        value_json=value_json,
        provenance_kind=provenance_kind,
        provenance_ref=provenance_ref,
        observed_at=observed_at,
        updated_at=updated_at,
    )


def build_partner_backbone(
    profile: HumanPartnerProfile,
) -> tuple[WorldModelEntity, list[WorldModelEntityAttribute]]:
    updated_at = _now_or(profile.updated_at)
    entity = WorldModelEntity(
        entity_id=PARTNER_CANONICAL_KEY,
        entity_type=WorldModelEntityType.HUMAN_PARTNER,
        canonical_key=PARTNER_CANONICAL_KEY,
        display_name=profile.name,
        source_surface="c01_partner_profile",
        created_at=updated_at,
        updated_at=updated_at,
    )
    attrs: list[WorldModelEntityAttribute] = [
        _make_attr(
            entity.entity_id,
            "identity",
            "name",
            value_text=profile.name,
            provenance_kind="profile_save",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
        _make_attr(
            entity.entity_id,
            "identity",
            "communication_style",
            value_text=profile.communication_style,
            provenance_kind="profile_save",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
        _make_attr(
            entity.entity_id,
            "identity",
            "explanation_level",
            value_text=profile.explanation_level,
            provenance_kind="profile_save",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
        _make_attr(
            entity.entity_id,
            "working_context",
            "timezone",
            value_text=profile.working_context.timezone,
            provenance_kind="profile_save",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
        _make_attr(
            entity.entity_id,
            "working_context",
            "role",
            value_text=profile.working_context.role,
            provenance_kind="profile_save",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
        _make_attr(
            entity.entity_id,
            "working_context",
            "team",
            value_text=profile.working_context.team,
            provenance_kind="profile_save",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
        _make_attr(
            entity.entity_id,
            "working_context",
            "speaker_mappings",
            value_json=dict(profile.working_context.speaker_mappings),
            provenance_kind="profile_save",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
        _make_attr(
            entity.entity_id,
            "knowledge_profile",
            "preferences",
            value_json=dict(profile.knowledge_profile.preferences),
            provenance_kind="profile_save",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
        _make_attr(
            entity.entity_id,
            "knowledge_profile",
            "notes",
            value_json=list(profile.knowledge_profile.notes),
            provenance_kind="profile_save",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
        _make_attr(
            entity.entity_id,
            "knowledge_profile",
            "expertise",
            value_json=list(profile.knowledge_profile.expertise),
            provenance_kind="profile_save",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
    ]
    return entity, attrs


def build_partner_semantic_mappings(
    profile: HumanPartnerProfile,
) -> list[WorldModelSemanticMapping]:
    updated_at = _now_or(profile.updated_at)
    mappings: list[WorldModelSemanticMapping] = []
    for source_value, target_value in sorted(
        profile.working_context.speaker_mappings.items()
    ):
        source = str(source_value).strip()
        target = str(target_value).strip()
        if not source or not target:
            continue
        mappings.append(
            WorldModelSemanticMapping(
                mapping_id=f"{PARTNER_CANONICAL_KEY}:speaker_alias:{source}",
                mapping_kind="speaker_alias",
                source_value=source,
                target_value=target,
                scope_type="partner_profile",
                scope_key=PARTNER_CANONICAL_KEY,
                source_surface="c05_semantic_mapping",
                created_at=updated_at,
                updated_at=updated_at,
            )
        )
    return mappings


def build_agent_self_backbone(
    model: AgentSelfModel,
) -> tuple[WorldModelEntity, list[WorldModelEntityAttribute]]:
    updated_at = _now_or(model.updated_at)
    entity = WorldModelEntity(
        entity_id=AGENT_CANONICAL_KEY,
        entity_type=WorldModelEntityType.AGENT_SELF,
        canonical_key=AGENT_CANONICAL_KEY,
        display_name=model.display_name,
        source_surface="c02_agent_self_model",
        created_at=updated_at,
        updated_at=updated_at,
    )
    attrs: list[WorldModelEntityAttribute] = [
        _make_attr(
            entity.entity_id,
            "identity",
            "display_name",
            value_text=model.display_name,
            provenance_kind="self_state_refresh",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
        _make_attr(
            entity.entity_id,
            "operational_state",
            "root",
            value_json=dict(model.operational_state),
            provenance_kind="self_state_refresh",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
        _make_attr(
            entity.entity_id,
            "diagnostics",
            "root",
            value_json=dict(model.last_diagnostics),
            provenance_kind="self_state_refresh",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
        _make_attr(
            entity.entity_id,
            "repair",
            "root",
            value_json=dict(model.last_repair),
            provenance_kind="self_state_refresh",
            provenance_ref=entity.canonical_key,
            observed_at=updated_at,
            updated_at=updated_at,
        ),
    ]

    for capability in model.capabilities:
        attrs.append(
            _make_attr(
                entity.entity_id,
                "capability",
                capability.capability_id,
                value_json=capability.model_dump(mode="json"),
                provenance_kind="self_state_refresh",
                provenance_ref=entity.canonical_key,
                observed_at=updated_at,
                updated_at=updated_at,
            )
        )

    for limitation in model.limitations:
        attrs.append(
            _make_attr(
                entity.entity_id,
                "limitation",
                limitation.limitation_id,
                value_json=limitation.model_dump(mode="json"),
                provenance_kind="self_state_refresh",
                provenance_ref=entity.canonical_key,
                observed_at=updated_at,
                updated_at=updated_at,
            )
        )

    for mode in model.degraded_modes:
        attrs.append(
            _make_attr(
                entity.entity_id,
                "degraded_mode",
                mode,
                value_text=mode,
                provenance_kind="self_state_refresh",
                provenance_ref=entity.canonical_key,
                observed_at=updated_at,
                updated_at=updated_at,
            )
        )

    return entity, attrs


def _intent_status(frame: IntentFrame) -> str:
    if frame.selected_path == IntentFramePath.CLARIFY:
        return "clarify"
    if frame.selected_path == IntentFramePath.ABSTAIN:
        return "abstain"
    return "active"


def build_world_model_intent_id(
    session_id: str,
    conversation_turn_id: int | None = None,
) -> str:
    if conversation_turn_id is None:
        return f"session:{session_id}:intent:last"
    return f"session:{session_id}:intent:turn:{conversation_turn_id}"


def build_world_model_intent(
    session_id: str,
    frame: IntentFrame,
    *,
    conversation_turn_id: int | None = None,
    intent_id: str | None = None,
) -> WorldModelIntent:
    return WorldModelIntent(
        intent_id=intent_id
        or build_world_model_intent_id(
            session_id,
            conversation_turn_id,
        ),
        session_id=session_id,
        goal_id=frame.goal_id,
        conversation_turn_id=conversation_turn_id,
        raw_input=frame.raw_input,
        classification=frame.classification.value,
        selected_path=frame.selected_path.value,
        summary=frame.summary,
        rationale=frame.rationale,
        confidence=frame.confidence,
        status=_intent_status(frame),
        unresolved_references=list(frame.unresolved_references),
        missing_information=list(frame.missing_information),
        source_surface="c03_intent_frame",
        created_at=frame.created_at,
        updated_at=utcnow(),
    )


def build_world_model_tool_action(
    session_id: str,
    *,
    conversation_turn_id: int,
    intent_id: str | None,
    prompt_control_artifact_id: str | None,
    tool_call_id: str,
    tool_name: str,
    arguments: dict[str, Any],
    result: ToolResult,
    created_at: datetime | None = None,
) -> WorldModelAction:
    timestamp = _now_or(created_at)
    return WorldModelAction(
        action_id=f"session:{session_id}:action:turn:{conversation_turn_id}:tool:{tool_call_id}",
        session_id=session_id,
        intent_id=intent_id,
        prompt_control_artifact_id=prompt_control_artifact_id,
        conversation_turn_id=conversation_turn_id,
        action_kind="tool_call",
        action_name=tool_name,
        status="succeeded" if result.success else "failed",
        payload={
            "tool_call_id": tool_call_id,
            "arguments": dict(arguments),
            "tool_source": result.source,
        },
        source_surface="c08_tool_execution",
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_tool_observation(
    action: WorldModelAction,
    result: ToolResult,
    *,
    created_at: datetime | None = None,
) -> WorldModelObservation:
    timestamp = _now_or(created_at)
    summary = (result.content or result.error or "").strip()
    if summary:
        summary = summary.splitlines()[0][:160]
    return WorldModelObservation(
        observation_id=f"{action.action_id}:result",
        session_id=action.session_id,
        action_id=action.action_id,
        observation_kind="tool_result",
        summary=summary,
        status="succeeded" if result.success else "failed",
        payload={
            "success": result.success,
            "tool_name": action.action_name,
            "source": result.source,
            "duration_ms": result.duration_ms,
            "content": result.content,
            "error": result.error,
        },
        source_surface=action.source_surface,
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_decision_outcome_action(
    session_id: str,
    *,
    conversation_turn_id: int,
    intent_id: str | None,
    prompt_control_artifact_id: str | None,
    decision_name: str,
    status: str,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelAction:
    timestamp = _now_or(created_at)
    return WorldModelAction(
        action_id=f"session:{session_id}:action:turn:{conversation_turn_id}:decision:{decision_name}",
        session_id=session_id,
        intent_id=intent_id,
        prompt_control_artifact_id=prompt_control_artifact_id,
        conversation_turn_id=conversation_turn_id,
        action_kind="selected_action",
        action_name=decision_name,
        status=status,
        payload=dict(payload or {}),
        source_surface="c08_selected_action",
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_response_observation(
    action: WorldModelAction,
    response: str,
    *,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelObservation:
    timestamp = _now_or(created_at)
    body = dict(payload or {})
    body["content"] = response
    summary = response.strip().splitlines()[0][:160] if response.strip() else ""
    return WorldModelObservation(
        observation_id=f"{action.action_id}:response",
        session_id=action.session_id,
        action_id=action.action_id,
        observation_kind="user_visible_response",
        summary=summary,
        status="succeeded",
        payload=body,
        source_surface=action.source_surface,
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_turn_event(
    session_id: str,
    *,
    conversation_turn_id: int,
    title: str,
    summary: str,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelEvent:
    timestamp = _now_or(created_at)
    return WorldModelEvent(
        event_id=f"session:{session_id}:event:turn:{conversation_turn_id}",
        session_id=session_id,
        conversation_turn_id=conversation_turn_id,
        event_kind="turn_outcome",
        title=title,
        summary=summary.strip().splitlines()[0][:240] if summary.strip() else "",
        payload=dict(payload or {}),
        source_surface="c08_turn_event",
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_knowledge_ingest_action(
    *,
    ingest_kind: str,
    session_id: str | None,
    source_ref: str,
    item_type: str,
    status: str,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelAction:
    timestamp = _now_or(created_at)
    body = dict(payload or {})
    body["source_ref"] = source_ref
    body["item_type"] = item_type
    return WorldModelAction(
        action_id=f"knowledge_ingest:{ingest_kind}:{uuid.uuid4().hex}",
        session_id=session_id or None,
        action_kind="knowledge_ingest",
        action_name=f"ingest_{ingest_kind}",
        status=status,
        payload=body,
        source_surface="c05_knowledge_ingest",
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_knowledge_ingest_run(
    *,
    ingest_kind: str,
    trigger_surface: str,
    source_ref: str,
    normalized_source_ref: str,
    requested_item_type: str,
    session_id: str | None = None,
    status: str = "started",
    phase: str = "started",
    fallback_used: bool = False,
    item_id: str | None = None,
    knowledge_id: str | None = None,
    summary_model: str = "",
    error: str = "",
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
    finished_at: datetime | None = None,
) -> WorldModelKnowledgeIngestRun:
    timestamp = _now_or(created_at)
    return WorldModelKnowledgeIngestRun(
        ingest_run_id=f"{ingest_kind}:{uuid.uuid4().hex}",
        ingest_kind=ingest_kind,
        trigger_surface=trigger_surface,
        session_id=session_id or None,
        source_ref=source_ref,
        normalized_source_ref=normalized_source_ref,
        requested_item_type=requested_item_type,
        status=status,
        phase=phase,
        fallback_used=fallback_used,
        item_id=item_id,
        knowledge_id=knowledge_id,
        summary_model=summary_model,
        error=error,
        payload=dict(payload or {}),
        created_at=timestamp,
        updated_at=timestamp,
        finished_at=finished_at,
    )


def build_world_model_knowledge_ingest_observation(
    action: WorldModelAction,
    *,
    summary: str,
    status: str,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelObservation:
    timestamp = _now_or(created_at)
    return WorldModelObservation(
        observation_id=f"{action.action_id}:result",
        session_id=action.session_id,
        action_id=action.action_id,
        observation_kind="knowledge_ingest_result",
        summary=summary[:160],
        status=status,
        payload=dict(payload or {}),
        source_surface=action.source_surface,
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_knowledge_ingest_event(
    action: WorldModelAction,
    *,
    title: str,
    summary: str,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelEvent:
    timestamp = _now_or(created_at)
    return WorldModelEvent(
        event_id=f"{action.action_id}:event",
        session_id=action.session_id,
        event_kind="knowledge_ingest",
        title=title,
        summary=summary.strip().splitlines()[0][:240] if summary.strip() else "",
        payload=dict(payload or {}),
        source_surface=action.source_surface,
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_meeting_promotion_action(
    meeting_id: str,
    *,
    artifact_id: str,
    artifact_type: str,
    promoted_item_id: str,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelAction:
    timestamp = _now_or(created_at)
    body = dict(payload or {})
    body["artifact_id"] = artifact_id
    body["promoted_item_id"] = promoted_item_id
    return WorldModelAction(
        action_id=f"meeting:{meeting_id}:semantic_promotion:{artifact_id}",
        meeting_id=meeting_id,
        action_kind="meeting_semantic_promotion",
        action_name=artifact_type,
        status="succeeded",
        payload=body,
        source_surface="c04_meeting_semantic_promotion",
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_meeting_promotion_observation(
    action: WorldModelAction,
    *,
    promoted_item_id: str,
    summary: str,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelObservation:
    timestamp = _now_or(created_at)
    body = dict(payload or {})
    body["item_id"] = promoted_item_id
    return WorldModelObservation(
        observation_id=f"{action.action_id}:promotion",
        meeting_id=action.meeting_id,
        action_id=action.action_id,
        observation_kind="promoted_semantic_item",
        summary=summary[:160],
        status="succeeded",
        payload=body,
        source_surface=action.source_surface,
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_meeting_extraction_action(
    meeting_id: str,
    *,
    run_id: str,
    run_type: str,
    recording_id: str | None,
    status: str,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelAction:
    timestamp = _now_or(created_at)
    body = dict(payload or {})
    body["run_id"] = run_id
    if recording_id:
        body["recording_id"] = recording_id
    return WorldModelAction(
        action_id=f"meeting:{meeting_id}:extraction:{run_id}",
        meeting_id=meeting_id,
        action_kind="meeting_extraction",
        action_name=run_type,
        status=status,
        payload=body,
        source_surface="c04_meeting_extraction",
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_meeting_extraction_observation(
    action: WorldModelAction,
    *,
    summary: str,
    status: str,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelObservation:
    timestamp = _now_or(created_at)
    return WorldModelObservation(
        observation_id=f"{action.action_id}:result",
        meeting_id=action.meeting_id,
        action_id=action.action_id,
        observation_kind="meeting_extraction_result",
        summary=summary[:160],
        status=status,
        payload=dict(payload or {}),
        source_surface=action.source_surface,
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_meeting_semantic_sync_action(
    meeting_id: str,
    *,
    item_id: str,
    sync_reason: str,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelAction:
    timestamp = _now_or(created_at)
    body = dict(payload or {})
    body["item_id"] = item_id
    body["sync_reason"] = sync_reason
    return WorldModelAction(
        action_id=f"meeting:{meeting_id}:semantic_sync:{sync_reason}",
        meeting_id=meeting_id,
        action_kind="meeting_semantic_sync",
        action_name="item_projection_refresh",
        status="succeeded",
        payload=body,
        source_surface="c04_meeting_semantic_sync",
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_meeting_semantic_sync_observation(
    action: WorldModelAction,
    *,
    summary: str,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelObservation:
    timestamp = _now_or(created_at)
    return WorldModelObservation(
        observation_id=f"{action.action_id}:state",
        meeting_id=action.meeting_id,
        action_id=action.action_id,
        observation_kind="meeting_semantic_state",
        summary=summary[:160],
        status="succeeded",
        payload=dict(payload or {}),
        source_surface=action.source_surface,
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_meeting_semantic_promotion_action(
    meeting_id: str,
    *,
    artifact_id: str,
    artifact_type: str,
    semantic_item_id: str,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelAction:
    timestamp = _now_or(created_at)
    body = dict(payload or {})
    body["artifact_id"] = artifact_id
    body["artifact_type"] = artifact_type
    body["semantic_item_id"] = semantic_item_id
    return WorldModelAction(
        action_id=f"meeting:{meeting_id}:semantic_promotion:{artifact_id}",
        meeting_id=meeting_id,
        action_kind="meeting_semantic_promotion",
        action_name=artifact_type,
        status="succeeded",
        payload=body,
        source_surface="c04_meeting_semantic_promotion",
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_meeting_semantic_promotion_observation(
    action: WorldModelAction,
    *,
    semantic_item_id: str,
    summary: str,
    payload: dict[str, Any] | None = None,
    created_at: datetime | None = None,
) -> WorldModelObservation:
    timestamp = _now_or(created_at)
    body = dict(payload or {})
    body["item_id"] = semantic_item_id
    return WorldModelObservation(
        observation_id=f"{action.action_id}:promoted",
        meeting_id=action.meeting_id,
        action_id=action.action_id,
        observation_kind="promoted_semantic_item",
        summary=summary[:160],
        status="succeeded",
        payload=body,
        source_surface=action.source_surface,
        created_at=timestamp,
        updated_at=utcnow(),
    )


def build_world_model_provenance_link(
    source_record_type: str,
    source_record_id: str,
    target_record_type: str,
    target_record_id: str,
    relationship: str,
    *,
    created_at: datetime | None = None,
) -> WorldModelProvenanceLink:
    timestamp = _now_or(created_at)
    return WorldModelProvenanceLink(
        link_id=(
            f"{source_record_type}:{source_record_id}"
            f"->{relationship}:{target_record_type}:{target_record_id}"
        ),
        source_record_type=source_record_type,
        source_record_id=source_record_id,
        target_record_type=target_record_type,
        target_record_id=target_record_id,
        relationship=relationship,
        created_at=timestamp,
    )
