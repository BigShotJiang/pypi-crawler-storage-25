"""Session summary middleware — generates LDB-stored conversation summaries.

When a session ends with >= 3 human turns, generates a 150-word summary
via LLM micro-call and stores it as a type=conversation Item in the
knowledge store. These summaries are vector-searchable via the existing
retrieval pipeline.

Retention: conversation Items get 180-day half-life (6 months before decay
starts). When items expire, the cold-storage archiver writes them to
~/.memex/archive/ as JSON before deletion.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from memex.middleware import TurnMiddleware
from memex.models import SessionContext
from memex.store import MemexStore
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

_URL_PATTERN = re.compile(r"https?://[^\s<>\"')]+", re.IGNORECASE)

_MIN_TURNS_FOR_SUMMARY = 3

_SUMMARY_PROMPT = """\
Summarize this conversation session in about 150 words.
Focus on: topics discussed, decisions made, actions taken, and outcomes.
Include specific details (names, URLs, facts) that would help find this
conversation later via search.

Session turns:
{turns}
"""


class SessionSummaryMiddleware(TurnMiddleware):
    """Generates and stores session summaries in the knowledge store."""

    def __init__(self, content_store: Any = None) -> None:
        self._content_store = content_store

    def after_session(
        self,
        session: SessionContext,
        store: MemexStore,
    ) -> None:
        """If session has enough turns, summarize and store."""
        if session.turn_count < _MIN_TURNS_FOR_SUMMARY:
            return

        content_store = self._content_store or getattr(store, "content", None)
        if content_store is None:
            return

        try:
            self._summarize_and_store(session, store, content_store)
        except Exception:
            logger.debug(
                "Session summary failed for %s", session.session_id, exc_info=True
            )

    def _summarize_and_store(
        self,
        session: SessionContext,
        store: MemexStore,
        content_store: Any,
    ) -> None:
        """Generate summary via LLM and create a conversation Item."""
        # Gather turns from conversation_log
        turns = store.query_conversation_log(
            session_id=session.session_id,
            limit=200,
        )
        if not turns:
            # Fall back to in-memory history
            turns = [
                {"role": t.role, "content": t.content}
                for t in session.conversation_history
            ]

        if len(turns) < _MIN_TURNS_FOR_SUMMARY:
            return

        # Format turns for the summary prompt
        turn_lines = []
        for t in turns:
            if isinstance(t, dict):
                role = t.get("role", "?")
                content = t.get("content", "")
            else:
                role = getattr(t, "role", "?")
                content = getattr(t, "content", "")
            turn_lines.append(f"{role}: {content[:300]}")

        turns_text = "\n".join(turn_lines[-50:])  # Cap at last 50 turns

        # LLM micro-call
        from memex.llm import _get_cheap_model, chat

        summary = chat(
            [{"role": "user", "content": _SUMMARY_PROMPT.format(turns=turns_text)}],
            model=_get_cheap_model(),
            max_tokens=300,
        )

        if not summary or not summary.strip():
            return

        # Detect interface from session_id pattern
        interface = "unknown"
        sid = session.session_id
        if sid.startswith("telegram_"):
            interface = "telegram"
        elif sid.startswith("tui-"):
            interface = "tui"
        elif sid.startswith("cli-"):
            interface = "cli"

        # Extract URLs mentioned in the session for cold-storage preservation
        all_content = " ".join(
            t.get("content", "") if isinstance(t, dict) else getattr(t, "content", "")
            for t in turns
        )
        urls = list(
            dict.fromkeys(_URL_PATTERN.findall(all_content))
        )  # dedup, preserve order

        # Store as Item(type=conversation) with 180-day half-life
        from memex.memory.decay import DEFAULT_HALF_LIFE
        from memex.models import Item, ItemType

        item = Item(
            item_id=f"session-summary:{session.session_id}",
            type=ItemType.CONVERSATION,
            title=f"Session summary ({session.started_at.strftime('%Y-%m-%d')})",
            body=summary.strip(),
            source_url=f"session://{session.session_id}",
            captured_at=utcnow(),
            last_accessed=utcnow(),
            half_life_days=DEFAULT_HALF_LIFE[ItemType.CONVERSATION],
            metadata={
                "session_id": session.session_id,
                "turn_count": session.turn_count,
                "interface": interface,
                "urls": urls[:20],  # cap to avoid bloat
                "typed_knowledge": {
                    "summary": summary.strip(),
                    "urls": urls[:20],
                },
            },
        )

        try:
            from memex.typed_knowledge import seed_typed_knowledge_metadata

            seed_typed_knowledge_metadata(item, item.metadata.get("typed_knowledge"))
        except Exception:
            logger.debug("Failed to seed session summary typed metadata", exc_info=True)

        content_store.upsert_item(item)
        try:
            from memex.typed_knowledge import sync_item_projection_if_needed

            sync_item_projection_if_needed(store, content_store, item)
        except Exception:
            logger.debug(
                "Failed to sync session summary into typed knowledge", exc_info=True
            )
        logger.info(
            "Stored session summary for %s (%d turns, %s)",
            session.session_id[:12],
            session.turn_count,
            interface,
        )
