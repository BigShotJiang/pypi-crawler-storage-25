from __future__ import annotations

from datetime import datetime

from memex.meetings.models import MeetingIntelligenceArtifact, MeetingRecord
from memex.models import (
    ScheduledTask,
    WorldModelCommitment,
    WorldModelProvenanceLink,
    WorldModelTask,
)


def scheduled_task_qualifies_for_world_model_task(task: ScheduledTask) -> bool:
    generator = str(task.action_data.get("generator") or "").strip().lower()
    return not task.builtin and generator == "reminder"


def build_world_model_task_from_scheduled_task(task: ScheduledTask) -> WorldModelTask:
    due_at = None
    remind_at = str(task.action_data.get("remind_at") or "").strip()
    if remind_at:
        try:
            due_at = datetime.fromisoformat(remind_at)
        except ValueError:
            due_at = None
    status = "active" if task.enabled else "disabled"
    return WorldModelTask(
        task_id=task.task_id,
        scheduled_task_id=task.task_id,
        goal_id=task.goal_id,
        task_kind="scheduled_reminder",
        title=task.name,
        description=task.description,
        status=status,
        due_at=due_at,
        payload={
            "scheduled_task_id": task.task_id,
            "action_type": task.action_type.value,
            "cron_expr": task.cron_expr,
            "generator": task.action_data.get("generator"),
            "one_shot": bool(task.action_data.get("one_shot")),
            "goal_id": task.goal_id,
        },
        source_surface="c08_world_model_task",
        created_at=task.created_at,
        updated_at=task.updated_at,
    )


def build_world_model_task_provenance_links(
    task: WorldModelTask,
) -> list[WorldModelProvenanceLink]:
    links: list[WorldModelProvenanceLink] = []
    if task.goal_id:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_task:{task.task_id}"
                    f"->advances_goal:world_model_goal:{task.goal_id}"
                ),
                source_record_type="world_model_task",
                source_record_id=task.task_id,
                target_record_type="world_model_goal",
                target_record_id=task.goal_id,
                relationship="advances_goal",
                created_at=task.updated_at,
            )
        )
    return links


def build_world_model_commitment_from_meeting_artifact(
    record: MeetingRecord,
    artifact: MeetingIntelligenceArtifact,
    *,
    semantic_item_id: str | None,
) -> WorldModelCommitment:
    payload = artifact.payload if isinstance(artifact.payload, dict) else {}
    return WorldModelCommitment(
        commitment_id=artifact.artifact_id,
        source_record_type="meeting_artifact",
        source_record_id=artifact.artifact_id,
        meeting_id=record.meeting_id,
        semantic_item_id=semantic_item_id,
        goal_id=str(payload.get("promoted_goal_id") or "").strip() or None,
        title=artifact.content.strip() or "Meeting commitment",
        description=f"Commitment from meeting: {record.title}".strip(),
        assignee=str(payload.get("assignee") or "").strip(),
        deadline_text=str(payload.get("deadline") or "").strip(),
        agreed_by=str(payload.get("agreed_by") or "").strip(),
        status="active",
        payload={
            "artifact_id": artifact.artifact_id,
            "artifact_type": artifact.artifact_type.value,
            "meeting_title": record.title,
            "meeting_item_id": record.item_id,
            **payload,
        },
        source_surface="c08_world_model_commitment",
        created_at=artifact.created_at,
        updated_at=artifact.updated_at,
    )


def build_world_model_commitment_provenance_links(
    commitment: WorldModelCommitment,
) -> list[WorldModelProvenanceLink]:
    links: list[WorldModelProvenanceLink] = []
    if commitment.source_record_type and commitment.source_record_id:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_commitment:{commitment.commitment_id}"
                    f"->commits_from:{commitment.source_record_type}:{commitment.source_record_id}"
                ),
                source_record_type="world_model_commitment",
                source_record_id=commitment.commitment_id,
                target_record_type=commitment.source_record_type,
                target_record_id=commitment.source_record_id,
                relationship="commits_from",
                created_at=commitment.created_at,
            )
        )
    if commitment.semantic_item_id:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_commitment:{commitment.commitment_id}"
                    f"->updates:item:{commitment.semantic_item_id}"
                ),
                source_record_type="world_model_commitment",
                source_record_id=commitment.commitment_id,
                target_record_type="item",
                target_record_id=commitment.semantic_item_id,
                relationship="updates",
                created_at=commitment.updated_at,
            )
        )
    if commitment.goal_id:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_commitment:{commitment.commitment_id}"
                    f"->updates_goal:world_model_goal:{commitment.goal_id}"
                ),
                source_record_type="world_model_commitment",
                source_record_id=commitment.commitment_id,
                target_record_type="world_model_goal",
                target_record_id=commitment.goal_id,
                relationship="updates_goal",
                created_at=commitment.updated_at,
            )
        )
    return links
