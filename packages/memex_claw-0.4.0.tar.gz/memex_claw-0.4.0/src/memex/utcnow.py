"""Canonical UTC timestamp helper.

All datetimes in Memex should be timezone-aware UTC.
Use ``utcnow()`` instead of ``datetime.now()`` or ``datetime.utcnow()``.
"""

from datetime import datetime, timezone


def utcnow() -> datetime:
    """Return the current time as a timezone-aware UTC datetime."""
    return datetime.now(timezone.utc)
