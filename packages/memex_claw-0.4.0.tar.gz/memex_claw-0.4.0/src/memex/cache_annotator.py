"""Provider-specific cache annotation for LLM messages.

Adds cache_control markers appropriate to each provider:
- Anthropic: explicit cache_control breakpoints on content blocks
- OpenAI: no-op (automatic prefix caching)
"""

from __future__ import annotations

import copy
from abc import ABC, abstractmethod


class CacheAnnotator(ABC):
    """Adds provider-specific cache markers to messages."""

    @abstractmethod
    def annotate_system(self, system_msg: dict, prefix_block_count: int) -> dict:
        """Annotate the system message with cache breakpoint.

        prefix_block_count indicates how many leading content blocks
        are stable/cacheable.
        """

    @abstractmethod
    def annotate_history(self, messages: list[dict], breakpoint_idx: int) -> list[dict]:
        """Annotate conversation history with cache breakpoint
        after the message at breakpoint_idx."""


class AnthropicAnnotator(CacheAnnotator):
    """Adds cache_control: {"type": "ephemeral"} at breakpoints.

    Anthropic requires content blocks (not plain strings) for
    cache_control. This annotator converts string content to
    content block format and attaches the marker.
    """

    def annotate_system(self, system_msg: dict, prefix_block_count: int) -> dict:
        """Mark cacheable prefix blocks with cache_control."""
        msg = copy.deepcopy(system_msg)
        content = msg.get("content", [])

        if isinstance(content, str):
            # Fallback: wrap string in a single cached block
            msg["content"] = [
                {
                    "type": "text",
                    "text": content,
                    "cache_control": {"type": "ephemeral"},
                }
            ]
        elif isinstance(content, list) and content and prefix_block_count > 0:
            # Mark the last prefix block with cache_control
            idx = min(prefix_block_count - 1, len(content) - 1)
            content[idx] = {**content[idx], "cache_control": {"type": "ephemeral"}}
            msg["content"] = content

        return msg

    def annotate_history(self, messages: list[dict], breakpoint_idx: int) -> list[dict]:
        """Add cache_control to the message at breakpoint_idx."""
        if not messages or breakpoint_idx < 0 or breakpoint_idx >= len(messages):
            return messages

        result = copy.deepcopy(messages)
        target = result[breakpoint_idx]
        content = target.get("content", "")

        if isinstance(content, str):
            target["content"] = [
                {
                    "type": "text",
                    "text": content,
                    "cache_control": {"type": "ephemeral"},
                }
            ]
        elif isinstance(content, list) and content:
            # Add cache_control to the last content block
            content[-1] = copy.deepcopy(content[-1])
            content[-1]["cache_control"] = {"type": "ephemeral"}

        return result


class NoOpAnnotator(CacheAnnotator):
    """For providers with automatic caching (OpenAI).
    Flattens content blocks back to plain string (OpenAI doesn't support
    content-block format for system messages)."""

    def annotate_system(self, system_msg: dict, prefix_block_count: int) -> dict:
        content = system_msg.get("content", "")
        if isinstance(content, list):
            system_msg = {
                **system_msg,
                "content": "\n\n".join(b["text"] for b in content if b.get("text")),
            }
        return system_msg

    def annotate_history(self, messages: list[dict], breakpoint_idx: int) -> list[dict]:
        return messages


def annotator_for_model(model: str) -> CacheAnnotator:
    """Select annotator based on model name / provider prefix."""
    model_lower = model.lower()
    if any(p in model_lower for p in ("claude", "anthropic")):
        return AnthropicAnnotator()
    return NoOpAnnotator()
