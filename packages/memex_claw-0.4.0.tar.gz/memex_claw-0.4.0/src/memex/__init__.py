"""Memex: Personal AI partner with persistent intent tracking."""

__version__ = "0.1.0"
