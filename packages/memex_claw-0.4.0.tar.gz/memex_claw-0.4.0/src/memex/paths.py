"""Canonical path resolution for Memex data files.

Single source of truth for store and service paths. Every module that
needs to locate these files must import the helpers from here instead of
inlining env-var lookups or hard-coding Path.home().
"""

from __future__ import annotations

import os
from pathlib import Path


def resolve_store_path() -> str:
    """Return the store path.

    Resolution order:
      1. ``MEMEX_STORE`` environment variable (absolute or relative to cwd).
      2. ``<cwd>/.memex/memex.db`` fallback.

    Set ``MEMEX_STORE`` to an *absolute* path in ``.env`` so the resolution
    is stable regardless of which directory the process is launched from.
    """
    return os.environ.get("MEMEX_STORE", str(Path.cwd() / ".memex" / "memex.db"))


def resolve_service_lock_file() -> Path:
    """Return the path to the exclusive service lock file (.memex/service.lock).

    The service acquires an exclusive flock on this file before opening the
    store.  If a second instance tries to start, flock fails immediately and
    the process exits cleanly.  The OS releases the lock automatically when
    the process dies, so stale locks are not possible.
    """
    store = Path(resolve_store_path())
    return store.parent / "service.lock"


def resolve_service_url_file() -> Path:
    """Return the path to the service URL file (.memex/service.url).

    The service writes its URL here on startup and removes it on shutdown.
    Other processes (e.g. TUI) can read this file to auto-discover the service.
    """
    store = Path(resolve_store_path())
    return store.parent / "service.url"
