"""Meeting models — state machine, segments, and records."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any
from memex.utcnow import utcnow


class MeetingState(str, Enum):
    CREATED = "created"  # Draft: title/attendees set, no audio yet
    RECORDING = "recording"
    RECORDED = "recorded"
    QUEUED = "queued"
    TRANSCRIBING = "transcribing"
    TRANSCRIBED = "transcribed"
    TRANSCRIBED_POOR = "transcribed_poor"  # Transcribed but confidence below threshold
    INGESTED = "ingested"
    FAILED = "failed"


class MeetingIntelligenceArtifactType(str, Enum):
    TRANSCRIPT_SEGMENT = "transcript_segment"
    NOTE = "note"
    ACTION_ITEM = "action_item"
    DECISION = "decision"
    COMMITMENT = "commitment"
    OUTCOME = "outcome"


@dataclass(frozen=True)
class MeetingSegment:
    """A single speaker segment from a transcribed meeting."""

    speaker: str
    start: float  # seconds
    end: float  # seconds
    text: str


@dataclass
class MeetingRecording:
    """A single audio capture session associated with a meeting."""

    recording_id: str
    meeting_id: str
    sequence_number: int
    state: MeetingState
    audio_path: str = ""
    duration_seconds: float = 0.0
    sample_rate: int = 16000
    started_at: datetime | None = None
    stopped_at: datetime | None = None
    transcribed_at: datetime | None = None
    ingested_at: datetime | None = None
    segments: list[MeetingSegment] = field(default_factory=list)
    speaker_count: int = 0
    language: str = ""
    whisper_model: str = ""
    vad_threshold: float = 0.1
    transcription_quality: float = 0.0  # 0.0 = not yet assessed; 0.0–1.0 quality score
    tried_vad_thresholds: list = field(
        default_factory=list
    )  # VAD levels already attempted
    error: str = ""
    audio_deleted: bool = False
    created_at: datetime = field(default_factory=utcnow)
    updated_at: datetime = field(default_factory=utcnow)


@dataclass
class MeetingRecord:
    """Full meeting lifecycle record."""

    meeting_id: str
    state: MeetingState
    title: str = ""
    scheduled_for: datetime | None = None
    external_event_id: str | None = None
    calendar_source: str | None = None
    audio_path: str = ""
    duration_seconds: float = 0.0
    sample_rate: int = 16000
    started_at: datetime | None = None
    stopped_at: datetime | None = None
    transcribed_at: datetime | None = None
    ingested_at: datetime | None = None
    item_id: str | None = None
    segments: list[MeetingSegment] = field(default_factory=list)
    speaker_count: int = 0
    language: str = ""
    whisper_model: str = ""
    vad_threshold: float = 0.1
    error: str = ""
    audio_deleted: bool = False
    attendees: list[str] = field(default_factory=list)
    notes: str = ""
    action_items: list[dict] = field(default_factory=list)
    recordings: list[MeetingRecording] = field(default_factory=list)
    created_at: datetime = field(default_factory=utcnow)
    updated_at: datetime = field(default_factory=utcnow)


@dataclass
class MeetingIntelligenceArtifact:
    artifact_id: str
    meeting_id: str
    recording_id: str | None
    artifact_type: MeetingIntelligenceArtifactType
    ordinal: int = 0
    title: str = ""
    content: str = ""
    speaker: str = ""
    start_seconds: float | None = None
    end_seconds: float | None = None
    payload: dict[str, Any] = field(default_factory=dict)
    source_surface: str = ""
    created_at: datetime = field(default_factory=utcnow)
    updated_at: datetime = field(default_factory=utcnow)


@dataclass
class MeetingExtractionRun:
    run_id: str
    meeting_id: str
    recording_id: str | None
    run_type: str
    status: str
    model: str = ""
    artifact_count: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=utcnow)
    updated_at: datetime = field(default_factory=utcnow)
