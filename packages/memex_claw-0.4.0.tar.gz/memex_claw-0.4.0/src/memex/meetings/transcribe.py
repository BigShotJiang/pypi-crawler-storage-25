"""Transcription — Riva/Whisper STT + pyannote.audio diarization, orchestration pipeline."""

from __future__ import annotations

import json
import logging
import math
import os
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from memex.meetings.models import (
    MeetingExtractionRun,
    MeetingRecording,
    MeetingSegment,
    MeetingState,
)
from memex.meetings.semantic_projection import sync_meeting_item_projection
from memex.world_model_backbone import (
    build_world_model_meeting_extraction_action,
    build_world_model_meeting_extraction_observation,
    build_world_model_provenance_link,
)
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

_hf_patched = False


def _record_world_model_meeting_extraction(
    *,
    memex_store,
    run: MeetingExtractionRun,
    item_id: str | None = None,
) -> None:
    if memex_store is None:
        return

    payload = {
        "model": run.model,
        "artifact_count": run.artifact_count,
        "metadata": dict(run.metadata if isinstance(run.metadata, dict) else {}),
    }
    action = build_world_model_meeting_extraction_action(
        run.meeting_id,
        run_id=run.run_id,
        run_type=run.run_type,
        recording_id=run.recording_id,
        status=run.status,
        payload=payload,
        created_at=run.created_at,
    )
    summary = f"{run.run_type} {run.status} | artifacts={run.artifact_count}"
    observation = build_world_model_meeting_extraction_observation(
        action,
        summary=summary,
        status=run.status,
        payload=payload,
        created_at=run.updated_at,
    )
    memex_store.upsert_world_model_action(action)
    memex_store.upsert_world_model_observation(observation)
    memex_store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_action",
            action.action_id,
            "meeting_extraction_run",
            run.run_id,
            "updates",
            created_at=run.created_at,
        )
    )
    if run.recording_id:
        memex_store.upsert_world_model_provenance_link(
            build_world_model_provenance_link(
                "world_model_action",
                action.action_id,
                "meeting_recording",
                run.recording_id,
                "updates",
                created_at=run.created_at,
            )
        )
    if item_id:
        memex_store.upsert_world_model_provenance_link(
            build_world_model_provenance_link(
                "world_model_action",
                action.action_id,
                "item",
                item_id,
                "updates",
                created_at=run.updated_at,
            )
        )
    memex_store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_observation",
            observation.observation_id,
            "world_model_action",
            action.action_id,
            "observed_from",
            created_at=run.updated_at,
        )
    )


def _refresh_meeting_item_semantic_metadata(
    *,
    item_id: str,
    meeting_id: str,
    content_store,
    memex_store,
    meeting_store,
) -> None:
    if not item_id or content_store is None:
        return
    record = meeting_store.get_meeting(meeting_id) if meeting_store else None
    if record is None:
        return
    from memex.meetings.semantic_projection import (
        _refresh_meeting_item_semantic_metadata as _sp_refresh,
    )

    _sp_refresh(
        record=record,
        meeting_store=meeting_store,
        content_store=content_store,
        memex_store=memex_store,
    )


def _patch_hf_hub_download() -> None:
    """Strip removed ``use_auth_token`` kwarg from hf_hub_download.

    pyannote-audio 3.4.0 passes ``use_auth_token`` in multiple modules,
    but huggingface_hub >=1.0 removed it.  pyannote 4.x fixes this but
    requires torchcodec (unavailable on ARM/Tegra).  We patch once globally
    by replacing the function in every module that imported it.
    """
    global _hf_patched
    if _hf_patched:
        return
    _hf_patched = True

    import huggingface_hub

    _orig = huggingface_hub.hf_hub_download

    def _patched(*args, **kwargs):
        kwargs.pop("use_auth_token", None)
        return _orig(*args, **kwargs)

    # Replace in huggingface_hub itself
    huggingface_hub.hf_hub_download = _patched

    # Replace in every loaded module that holds a reference
    import sys

    for mod in list(sys.modules.values()):
        if mod is None:
            continue
        try:
            fn = getattr(mod, "hf_hub_download", None)
            if (
                fn is not None
                and fn is not _patched
                and getattr(fn, "__module__", "").startswith("huggingface_hub")
            ):
                mod.hf_hub_download = _patched
        except Exception:
            pass


# VAD escalation schedule: tried in order when quality is below threshold.
# None means vad_filter=False (no VAD filtering — pass all audio to Whisper).
_VAD_RETRY_SCHEDULE: list[float | None] = [0.1, 0.05, None]

# Quality score below this threshold triggers a retry with the next VAD level.
# Score is computed from faster-whisper avg_logprob: exp(avg_logprob).
# 0.45 ≈ exp(-0.8), typical boundary between acceptable and noisy speech.
_QUALITY_THRESHOLD: float = 0.45


def _compute_quality(raw_segments: list) -> float:
    """Compute a 0.0–1.0 quality score from faster-whisper raw segments.

    Combines per-segment log-probability confidence with speech-presence signal.
    Returns 0.0 when there are no segments (not assessed).
    """
    if not raw_segments:
        return 0.0
    scores = []
    for seg in raw_segments:
        # avg_logprob: 0.0 = perfect, more negative = less confident.
        # Clip at -2.0 to avoid exp underflow on very noisy segments.
        logprob_score = math.exp(max(-2.0, getattr(seg, "avg_logprob", -1.0)))
        # no_speech_prob: high value means Whisper thought this was silence/noise.
        speech_score = 1.0 - getattr(seg, "no_speech_prob", 0.0)
        scores.append(logprob_score * speech_score)
    return sum(scores) / len(scores)


@dataclass(frozen=True)
class TranscriptionResult:
    """Output from transcribe_meeting()."""

    segments: list[MeetingSegment]
    speaker_count: int
    language: str
    model: str
    duration_seconds: float
    quality: float = 0.0  # 0.0–1.0; 0.0 = not assessed
    tried_vad_thresholds: tuple = field(default_factory=tuple)  # thresholds attempted


def _format_timestamp(seconds: float) -> str:
    """Format seconds as M:SS or H:MM:SS."""
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


def _format_body(
    segments: list[MeetingSegment],
    speaker_mappings: dict[str, str] | None = None,
) -> str:
    """Format segments as plain text for FTS-searchable body.

    If speaker_mappings is provided, replaces speaker IDs (e.g. SPEAKER_00)
    with human-readable names.
    """
    mappings = speaker_mappings or {}
    lines = []
    for seg in segments:
        speaker = mappings.get(seg.speaker, seg.speaker)
        start = _format_timestamp(seg.start)
        end = _format_timestamp(seg.end)
        lines.append(f"[{speaker}] ({start}-{end}): {seg.text}")
    return "\n".join(lines)


def transcribe_meeting(
    audio_path: Path | str,
    *,
    model_size: str = "large-v2",
    language: str | None = None,
    diarize: bool = True,
    hf_token: str | None = None,
    vad_threshold: float | None = None,
    tried_vad_thresholds: list | None = None,
) -> TranscriptionResult:
    """Transcribe an audio file with optional speaker diarization.

    Applies audio preparation (normalization, silence trimming, high-pass filter)
    before transcription, uses Silero VAD pre-analysis to pick a starting
    threshold, and retries with more permissive VAD levels when quality is low.

    Loads the Whisper model once, then tries VAD levels from _VAD_RETRY_SCHEDULE
    (skipping any in ``tried_vad_thresholds``) until quality exceeds
    _QUALITY_THRESHOLD or all levels are exhausted.  Returns the best result
    found, along with the quality score and the full list of tried thresholds.

    Requires faster-whisper and (for diarization) pyannote.audio.

    Note: large-v2 is the default because real-world benchmarks show it has
    significantly lower hallucination rates on meeting/noisy audio than large-v3
    (Deepgram: v3 WER 53.4 vs v2 WER 12.7 on real-world data).
    """
    from memex.meetings.stt_backend import get_backend

    audio_path = Path(audio_path)
    if not audio_path.exists():
        raise FileNotFoundError(f"Audio file not found: {audio_path}")

    # --- Audio preparation: normalize, trim, highpass, resample ---
    from memex.meetings.audio_prep import prepare_audio
    import tempfile as _tempfile

    _prep_tmp = Path(_tempfile.mkdtemp(prefix="memex_transcribe_"))
    try:
        prep = prepare_audio(audio_path, tmp_dir=_prep_tmp)
    except Exception:
        logger.warning("Audio preparation failed; using original file", exc_info=True)

        class _FallbackPrep:
            path = audio_path
            analysis = None
            was_modified = False
            applied_steps: list = []

        prep = _FallbackPrep()  # type: ignore[assignment]

    transcribe_path = prep.path
    if prep.was_modified:
        logger.info("Audio prepared: steps=%s", prep.applied_steps)

    # 1. Get STT backend (Riva if available, else PyTorch Whisper)
    backend = get_backend()
    logger.info("Using STT backend: %s", backend.name)

    # 2. Transcribe via backend
    stt_result = backend.transcribe(
        transcribe_path,
        language=language,
        diarize=diarize,
    )

    if not stt_result.segments:
        return TranscriptionResult(
            segments=[],
            speaker_count=0,
            language=language or "",
            model=f"{backend.name}:{model_size}",
            duration_seconds=0.0,
            quality=0.0,
            tried_vad_thresholds=(),
        )

    # 3. Map STT segments to MeetingSegments
    has_speakers = any(s.speaker is not None for s in stt_result.segments)

    if diarize and not has_speakers:
        # Backend didn't provide speakers (Whisper) — use pyannote
        # Build raw segment objects for _diarize compatibility
        @dataclass
        class _RawSeg:
            start: float
            end: float
            text: str

        raw_for_diarize = [
            _RawSeg(start=s.start, end=s.end, text=s.text) for s in stt_result.segments
        ]
        segments = _diarize(audio_path, raw_for_diarize, hf_token=hf_token)
    else:
        segments = [
            MeetingSegment(
                speaker=s.speaker or "SPEAKER",
                start=s.start,
                end=s.end,
                text=s.text,
            )
            for s in stt_result.segments
        ]

    speakers = {s.speaker for s in segments}

    return TranscriptionResult(
        segments=segments,
        speaker_count=len(speakers),
        language=stt_result.language,
        model=f"{backend.name}:{model_size}",
        duration_seconds=stt_result.duration_seconds,
        quality=stt_result.quality,
        tried_vad_thresholds=(),
    )


def _get_speaker_for_segment(diarization, seg_start: float, seg_end: float) -> str:
    """Find the speaker with the most temporal overlap for a segment."""
    from pyannote.core import Segment as PyannoteSegment

    target = PyannoteSegment(seg_start, seg_end)
    speakers: dict[str, float] = {}
    for turn, _, speaker in diarization.itertracks(yield_label=True):
        overlap = target & turn
        if overlap is not None and overlap.duration > 0:
            speakers[speaker] = speakers.get(speaker, 0.0) + overlap.duration
    if not speakers:
        return "UNKNOWN"
    return max(speakers, key=speakers.get)


def _diarize(
    audio_path: Path,
    raw_segments: list,
    *,
    hf_token: str | None = None,
) -> list[MeetingSegment]:
    """Run pyannote.audio speaker diarization and assign speakers to segments."""
    token = hf_token or os.environ.get("MEMEX_HF_TOKEN", "")
    if not token:
        logger.warning(
            "No HF token for diarization (MEMEX_HF_TOKEN), falling back to no diarization"
        )
        return [
            MeetingSegment(
                speaker="SPEAKER",
                start=seg.start,
                end=seg.end,
                text=seg.text.strip(),
            )
            for seg in raw_segments
        ]

    try:
        from memex.memory.embeddings import preload_libgomp

        preload_libgomp()
        from pyannote.audio import Pipeline
    except ImportError:
        logger.warning(
            "pyannote.audio not installed, falling back to no diarization. "
            "Install with: pip install memex-claw[diarization]"
        )
        return [
            MeetingSegment(
                speaker="SPEAKER",
                start=seg.start,
                end=seg.end,
                text=seg.text.strip(),
            )
            for seg in raw_segments
        ]

    logger.info("Running speaker diarization with pyannote.audio")
    # pyannote 3.4.0 passes use_auth_token to hf_hub_download() throughout
    # its codebase, but huggingface_hub >=1.0 removed that kwarg.
    # pyannote 4.x fixes this but requires torchcodec (unavailable on ARM).
    # Patch hf_hub_download globally to strip the removed kwarg.
    os.environ.setdefault("HF_TOKEN", token)
    _patch_hf_hub_download()

    # Scope torch.load patch to Pipeline.from_pretrained() only.
    # pyannote 3.4 checkpoints need weights_only=False (custom types like
    # TorchVersion, Specifications). Restoring immediately after limits
    # unsafe deserialization to trusted HuggingFace model loading.
    try:
        import lightning_fabric.utilities.cloud_io as _cloud_io

        _orig_load = _cloud_io.torch.load

        def _scoped_load(*args, **kwargs):
            kwargs["weights_only"] = False
            return _orig_load(*args, **kwargs)

        _cloud_io.torch.load = _scoped_load
    except Exception:
        _cloud_io = None  # type: ignore[assignment]
        _orig_load = None

    try:
        pipeline = Pipeline.from_pretrained(
            "pyannote/speaker-diarization-3.1",
        )
    finally:
        if _cloud_io is not None and _orig_load is not None:
            _cloud_io.torch.load = _orig_load

    diarization = pipeline(str(audio_path))

    segments = []
    for seg in raw_segments:
        speaker = _get_speaker_for_segment(diarization, seg.start, seg.end)
        segments.append(
            MeetingSegment(
                speaker=speaker,
                start=seg.start,
                end=seg.end,
                text=seg.text.strip(),
            )
        )

    return segments


def _combine_recording_results(
    results: list[tuple[MeetingRecording, TranscriptionResult]],
) -> tuple[list[MeetingSegment], int, str, str, float]:
    combined_segments: list[MeetingSegment] = []
    speakers: set[str] = set()
    duration_total = 0.0
    language = ""
    model = ""

    for _recording, result in results:
        offset = duration_total
        for seg in result.segments:
            combined_segments.append(
                MeetingSegment(
                    speaker=seg.speaker,
                    start=seg.start + offset,
                    end=seg.end + offset,
                    text=seg.text,
                )
            )
        speakers.update(seg.speaker for seg in result.segments)
        duration_total += result.duration_seconds
        if result.language:
            language = result.language
        if result.model:
            model = result.model

    return combined_segments, len(speakers), language, model, duration_total


def _upsert_meeting_item(
    record,
    body: str,
    *,
    title: str,
    metadata: dict,
    content_store,
    memex_store=None,
    embedding_backend=None,
):
    from memex.memory.intake import ingest
    from memex.models import ItemType

    source_url = f"memex://meeting/{record.meeting_id}"
    existing = content_store.get_item(record.item_id) if record.item_id else None

    if existing is not None:
        content_store.create_version_snapshot(existing)
        existing.type = ItemType.MEETING
        existing.title = title
        existing.body = body
        existing.source_url = existing.source_url or source_url
        existing.metadata = metadata
        existing.last_accessed = utcnow()
        existing.version += 1
        content_store.update_item(existing)

        if hasattr(content_store, "delete_chunks") and hasattr(
            content_store, "create_chunks"
        ):
            try:
                from memex.memory.chunking import chunk_text
                from memex.memory.intake import _extract_chunk_entities

                content_store.delete_chunks(existing.item_id)
                chunks = chunk_text(body)
                if chunks:
                    chunk_embeddings = None
                    if embedding_backend:
                        chunk_embeddings = embedding_backend.embed_batch(
                            [c["text"] for c in chunks]
                        )
                    chunk_ids = content_store.create_chunks(
                        existing.item_id, chunks, chunk_embeddings
                    )
                    if hasattr(content_store, "create_mention"):
                        _extract_chunk_entities(
                            content_store,
                            chunks,
                            chunk_ids,
                            existing.type.value,
                            body,
                        )
            except Exception:
                logger.debug("Failed to rebuild meeting chunks", exc_info=True)

        return existing

    item = ingest(
        body,
        type=ItemType.MEETING,
        title=title,
        source_url=source_url,
        content_store=content_store,
        memex_store=memex_store,
        embedding_backend=embedding_backend,
        generate_summary=False,
    )
    item.metadata = metadata
    content_store.update_item(item)
    return item


def _publish_meeting_state(meeting_id: str, title: str, state: MeetingState) -> None:
    try:
        from memex.event_bus import get_bus
        from memex.events import MeetingStateChanged

        get_bus().publish(
            MeetingStateChanged(
                meeting_id=meeting_id,
                title=title,
                state=state.value,
            )
        )
    except Exception:
        pass


def _run_recording_transcription(
    record,
    rec: MeetingRecording,
) -> TranscriptionResult:
    result = transcribe_meeting(
        rec.audio_path,
        model_size=rec.whisper_model or record.whisper_model or "large-v2",
        diarize=True,
        vad_threshold=rec.vad_threshold,
        tried_vad_thresholds=list(rec.tried_vad_thresholds),
    )
    if not result.segments:
        raise ValueError(
            f"No speech detected in recording.\n"
            f"Audio file: {rec.audio_path}\n"
            "Check microphone volume or lower MEMEX_VAD_THRESHOLD (current default: 0.1)."
        )
    rec.segments = result.segments
    rec.speaker_count = result.speaker_count
    rec.language = result.language
    rec.whisper_model = result.model
    rec.duration_seconds = result.duration_seconds
    rec.transcribed_at = utcnow()
    rec.transcription_quality = result.quality
    # Accumulate tried thresholds — never shrink the list across retries.
    existing = set(rec.tried_vad_thresholds)
    rec.tried_vad_thresholds = list(rec.tried_vad_thresholds) + [
        t for t in result.tried_vad_thresholds if t not in existing
    ]
    if result.quality < _QUALITY_THRESHOLD:
        rec.state = MeetingState.TRANSCRIBED_POOR
        logger.info(
            "Recording %s transcription quality %.2f below threshold %.2f → TRANSCRIBED_POOR",
            rec.recording_id,
            result.quality,
            _QUALITY_THRESHOLD,
        )
    else:
        rec.state = MeetingState.TRANSCRIBED
    rec.error = ""
    return result


def _recording_result_from_row(rec: MeetingRecording) -> TranscriptionResult:
    return TranscriptionResult(
        segments=list(rec.segments),
        speaker_count=rec.speaker_count or len({s.speaker for s in rec.segments}),
        language=rec.language,
        model=rec.whisper_model,
        duration_seconds=rec.duration_seconds,
    )


def _build_meeting_projection(
    record,
    recordings: list[MeetingRecording],
    *,
    speaker_mappings: dict[str, str] | None = None,
    extract_action_items: bool = False,
) -> tuple[str, str, dict, int, str, str, float]:
    completed = [
        rec
        for rec in recordings
        if rec.state
        in (
            MeetingState.TRANSCRIBED,
            MeetingState.TRANSCRIBED_POOR,
            MeetingState.INGESTED,
        )
        and rec.segments
    ]
    if not completed:
        raise ValueError(f"Meeting {record.meeting_id} has no transcribed recordings")

    results = [(rec, _recording_result_from_row(rec)) for rec in completed]
    segments, speaker_count, language, model, duration_seconds = (
        _combine_recording_results(results)
    )
    body = _format_body(segments, speaker_mappings=speaker_mappings)
    title = (
        record.title
        or f"Meeting {record.started_at.strftime('%Y-%m-%d %H:%M') if record.started_at else 'Unknown'}"
    )

    meeting_meta: dict = {
        "meeting_id": record.meeting_id,
        "speaker_count": speaker_count,
        "language": language,
        "duration_seconds": duration_seconds,
        "recording_count": len(recordings),
        "recordings": [
            {
                "recording_id": rec.recording_id,
                "sequence_number": rec.sequence_number,
                "duration_seconds": rec.duration_seconds,
                "started_at": rec.started_at.isoformat() if rec.started_at else None,
                "stopped_at": rec.stopped_at.isoformat() if rec.stopped_at else None,
                "state": rec.state.value,
            }
            for rec in recordings
        ],
        "segments": [
            {"speaker": s.speaker, "start": s.start, "end": s.end, "text": s.text}
            for s in segments
        ],
    }
    if speaker_mappings:
        meeting_meta["speaker_mappings"] = speaker_mappings
    if extract_action_items and body:
        try:
            action_items = _extract_action_items(body)
            if action_items:
                meeting_meta["action_items"] = action_items
        except Exception:
            logger.warning("Action item extraction failed", exc_info=True)

    return (
        body,
        title,
        {"meeting": meeting_meta},
        speaker_count,
        language,
        model,
        duration_seconds,
    )


def _record_extraction_run(meeting_store, run: MeetingExtractionRun) -> None:
    """Persist a MeetingExtractionRun via the meeting store.

    Adapts between the high-level ``record_meeting_extraction_run`` method
    (if available) and the lower-level ``create_extraction_run`` +
    ``complete_extraction_run`` pair exposed by the fathomdb repository.
    """
    if hasattr(meeting_store, "record_meeting_extraction_run"):
        meeting_store.record_meeting_extraction_run(run)
        return

    try:
        meeting_store.create_extraction_run(
            run.run_id,
            run.meeting_id,
            run.run_type,
            status=run.status,
            recording_id=run.recording_id,
            model=run.model or None,
            metadata=run.metadata if run.metadata else None,
        )
        if run.status in ("success", "failed"):
            meeting_store.complete_extraction_run(
                run.run_id,
                status=run.status,
                artifact_count=run.artifact_count,
                metadata=run.metadata if run.metadata else None,
            )
    except Exception:
        logger.debug("Failed to record extraction run %s", run.run_id, exc_info=True)


def orchestrate_transcription(
    meeting_id: str,
    *,
    meeting_store,
    content_store=None,
    memex_store=None,
    embedding_backend=None,
    notification_store=None,
    speaker_mappings: dict[str, str] | None = None,
    extract_action_items: bool = True,
    recording_id: str | None = None,
):
    """Full transcription pipeline: transcribe -> ingest -> update record.

    Returns the ingested Item on success, raises on failure.
    """
    record = meeting_store.get_meeting(meeting_id)
    if record is None:
        raise ValueError(f"Meeting not found: {meeting_id}")

    recordings = [
        rec
        for rec in meeting_store.list_recordings(meeting_id)
        if rec.audio_path and rec.state != MeetingState.RECORDING
    ]
    if not recordings:
        raise ValueError(f"Meeting {meeting_id} has no recorded audio")

    if recording_id is not None:
        selected = next(
            (rec for rec in recordings if rec.recording_id == recording_id), None
        )
        if selected is None:
            raise ValueError(
                f"Recording not found for meeting {meeting_id}: {recording_id}"
            )
        recordings_to_transcribe = [selected]
    else:
        recordings_to_transcribe = list(recordings)

    pre_transcribe_state = record.state
    record.state = MeetingState.TRANSCRIBING
    meeting_store.update_meeting(record)
    for rec in recordings_to_transcribe:
        rec.audio_path = str(Path(rec.audio_path).resolve())
        rec.state = MeetingState.TRANSCRIBING
        meeting_store.update_recording(rec)
    _publish_meeting_state(
        meeting_id, record.title or meeting_id[:8], MeetingState.TRANSCRIBING
    )

    try:
        per_recording: list[tuple[MeetingRecording, TranscriptionResult]] = []
        for rec in recordings_to_transcribe:
            result = _run_recording_transcription(record, rec)
            meeting_store.update_recording(rec)
            per_recording.append((rec, result))

        # Build the full recording list.  We keep in-memory copies of the
        # recordings we just transcribed (they carry .segments which may not
        # survive a round-trip through the store) and merge them with any
        # previously-completed recordings fetched from the database.
        just_transcribed = {rec.recording_id: rec for rec, _ in per_recording}
        all_recordings = []
        for rec in meeting_store.list_recordings(meeting_id):
            if not rec.audio_path or rec.state == MeetingState.RECORDING:
                continue
            # Prefer the in-memory version (has segments) over the DB version.
            all_recordings.append(just_transcribed.pop(rec.recording_id, rec))
        # In case the store didn't return some we just transcribed, add them.
        all_recordings.extend(just_transcribed.values())
        (
            body,
            title,
            meeting_metadata,
            speaker_count,
            language,
            model,
            duration_seconds,
        ) = _build_meeting_projection(
            record,
            all_recordings,
            speaker_mappings=speaker_mappings,
            extract_action_items=extract_action_items,
        )
        now = utcnow()
        record = meeting_store.get_meeting(meeting_id) or record
        record.segments = [
            MeetingSegment(
                speaker=s["speaker"],
                start=s["start"],
                end=s["end"],
                text=s["text"],
            )
            for s in meeting_metadata["meeting"]["segments"]
        ]
        record.speaker_count = speaker_count
        record.language = language
        record.whisper_model = model
        record.duration_seconds = duration_seconds
        record.audio_path = all_recordings[-1].audio_path
        if extract_action_items:
            record.action_items = list(
                meeting_metadata["meeting"].get("action_items") or []
            )
        record.transcribed_at = now
        record.started_at = all_recordings[0].started_at or record.started_at
        record.stopped_at = all_recordings[-1].stopped_at or record.stopped_at
        record.state = MeetingState.TRANSCRIBED
        meeting_store.update_meeting(record)

        # Ingest into knowledge store
        if content_store is not None:
            item = _upsert_meeting_item(
                record,
                body,
                title=title,
                metadata=meeting_metadata,
                content_store=content_store,
                memex_store=memex_store,
                embedding_backend=embedding_backend,
            )

            record.item_id = item.item_id
            record.ingested_at = now
            record.state = MeetingState.INGESTED
            meeting_store.update_meeting(record)
            # The facade's update_meeting does not persist item_id or
            # ingested_at; fall through to the underlying repo to store them.
            try:
                repo = getattr(meeting_store, "_repo", meeting_store)
                repo.update_meeting(
                    record.meeting_id,
                    item_id=item.item_id,
                    ingested_at=now.isoformat(),
                )
            except Exception:
                logger.debug(
                    "Could not persist item_id on meeting %s",
                    record.meeting_id,
                    exc_info=True,
                )
            for rec in all_recordings:
                if rec.state not in (MeetingState.TRANSCRIBED, MeetingState.INGESTED):
                    continue
                rec.ingested_at = now
                rec.state = MeetingState.INGESTED
                meeting_store.update_recording(rec)
            sync_meeting_item_projection(
                record,
                meeting_store=meeting_store,
                content_store=content_store,
                memex_store=memex_store,
                bump_version=False,
            )

            # Notification on success
            if notification_store is not None:
                _notify_success(
                    notification_store,
                    title,
                    per_recording[-1][1],
                    meeting_notes=record.notes or "",
                )

            try:
                from memex.event_bus import get_bus
                from memex.events import MeetingTranscribed

                get_bus().publish(
                    MeetingTranscribed(
                        meeting_id=meeting_id,
                        title=title,
                        success=True,
                        item_id=item.item_id,
                    )
                )
            except Exception:
                pass

            success_run = MeetingExtractionRun(
                run_id=str(uuid.uuid4()),
                meeting_id=meeting_id,
                recording_id=recording_id,
                run_type="transcription_projection",
                status="success",
                model=model,
                artifact_count=len(meeting_store.list_meeting_artifacts(meeting_id)),
                metadata={
                    "speaker_count": speaker_count,
                    "language": language,
                    "recording_count": len(all_recordings),
                    "extract_action_items": extract_action_items,
                },
                created_at=now,
                updated_at=now,
            )
            _record_extraction_run(meeting_store, success_run)
            _record_world_model_meeting_extraction(
                memex_store=memex_store,
                run=success_run,
                item_id=item.item_id,
            )
            _refresh_meeting_item_semantic_metadata(
                item_id=item.item_id,
                meeting_id=meeting_id,
                content_store=content_store,
                memex_store=memex_store,
                meeting_store=meeting_store,
            )

            return item

        # No content store — just mark as transcribed
        record.state = MeetingState.TRANSCRIBED
        meeting_store.update_meeting(record)

        if notification_store is not None:
            _notify_success(notification_store, title, per_recording[-1][1])

        try:
            from memex.event_bus import get_bus
            from memex.events import MeetingTranscribed

            get_bus().publish(
                MeetingTranscribed(
                    meeting_id=meeting_id,
                    title=title,
                    success=True,
                )
            )
        except Exception:
            pass

        success_run = MeetingExtractionRun(
            run_id=str(uuid.uuid4()),
            meeting_id=meeting_id,
            recording_id=recording_id,
            run_type="transcription_projection",
            status="success",
            model=model,
            artifact_count=len(meeting_store.list_meeting_artifacts(meeting_id)),
            metadata={
                "speaker_count": speaker_count,
                "language": language,
                "recording_count": len(all_recordings),
                "extract_action_items": extract_action_items,
            },
            created_at=now,
            updated_at=now,
        )
        _record_extraction_run(meeting_store, success_run)
        _record_world_model_meeting_extraction(
            memex_store=memex_store,
            run=success_run,
        )

        return None

    except Exception as exc:
        for rec in recordings_to_transcribe:
            rec.state = MeetingState.FAILED
            rec.error = str(exc)
            meeting_store.update_recording(rec)

        if recording_id is None:
            record.state = MeetingState.FAILED
            record.error = str(exc)
            meeting_store.update_meeting(record)
        else:
            refreshed = meeting_store.get_meeting(meeting_id)
            if refreshed is not None:
                record = refreshed
            record.state = pre_transcribe_state
            meeting_store.update_meeting(record)

        if notification_store is not None:
            _notify_failure(notification_store, record.title or meeting_id[:8], exc)

        failure_time = utcnow()
        failure_run = MeetingExtractionRun(
            run_id=str(uuid.uuid4()),
            meeting_id=meeting_id,
            recording_id=recording_id,
            run_type="transcription_projection",
            status="failed",
            model="",
            artifact_count=0,
            metadata={
                "error": str(exc),
                "recording_count": len(recordings_to_transcribe),
                "extract_action_items": extract_action_items,
            },
            created_at=failure_time,
            updated_at=failure_time,
        )
        _record_extraction_run(meeting_store, failure_run)
        _record_world_model_meeting_extraction(
            memex_store=memex_store,
            run=failure_run,
        )

        try:
            from memex.event_bus import get_bus
            from memex.events import MeetingTranscribed

            get_bus().publish(
                MeetingTranscribed(
                    meeting_id=meeting_id,
                    title=record.title or meeting_id[:8],
                    success=False,
                )
            )
        except Exception:
            pass

        raise


_ACTION_ITEM_PROMPT = """\
Extract action items from this meeting transcript. Return a JSON array of objects, \
each with "assignee" (speaker name or "unassigned"), "action" (what needs to be done), \
and "deadline" (mentioned deadline or "none").

Only extract clear, concrete action items — things someone committed to doing. \
Do not extract vague discussion points. If there are no action items, return [].

Transcript:
{transcript}
"""


def _extract_action_items(body: str) -> list[dict[str, str]]:
    """Extract action items from transcript via LLM. Returns list of dicts."""
    from memex.llm import _get_cheap_model, chat

    prompt = _ACTION_ITEM_PROMPT.format(transcript=body[:8000])
    messages = [{"role": "user", "content": prompt}]
    result = chat(messages, model=_get_cheap_model(), max_tokens=1024)

    try:
        items = json.loads(result.strip())
        if isinstance(items, list):
            return items
    except (json.JSONDecodeError, TypeError):
        # Try to extract JSON array from response
        start = result.find("[")
        end = result.rfind("]")
        if start != -1 and end != -1:
            try:
                items = json.loads(result[start : end + 1])
                if isinstance(items, list):
                    return items
            except json.JSONDecodeError:
                pass
    return []


def _notify_success(
    notification_store,
    title: str,
    result: TranscriptionResult,
    meeting_notes: str = "",
) -> None:
    """Emit a NORMAL notification on successful transcription."""
    from memex.models import NotificationPriority
    from memex.notifications import NotificationRouter

    router = NotificationRouter(notification_store)
    duration_min = result.duration_seconds / 60
    router.notify(
        f"Meeting transcribed: {title}",
        body=f"{result.speaker_count} speakers, {duration_min:.0f}min, {len(result.segments)} segments",
        priority=NotificationPriority.NORMAL,
        source="meetings",
    )
    _maybe_send_telegram_completion(meeting_notes, title, result)


def _maybe_send_telegram_completion(
    notes: str, title: str, result: TranscriptionResult
) -> None:
    """If meeting originated from Telegram, send a completion message via bot API."""
    if "chat_id=" not in (notes or ""):
        return
    import os
    import urllib.error
    import urllib.request

    bot_token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    if not bot_token:
        return

    chat_id = ""
    for part in notes.split("|"):
        if part.startswith("chat_id="):
            chat_id = part[8:].strip()
            break
    if not chat_id:
        return

    duration_min = result.duration_seconds / 60
    text = (
        f"\u2713 Voice memo transcribed: {title}\n"
        f"{result.speaker_count} speaker(s), {duration_min:.0f} min"
    )
    try:
        payload = json.dumps({"chat_id": chat_id, "text": text}).encode()
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{bot_token}/sendMessage",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)  # nosec B310 — hardcoded https Telegram API URL
    except Exception:
        logger.debug("Failed to send Telegram completion message", exc_info=True)


def _notify_failure(notification_store, title: str, exc: Exception) -> None:
    """Emit a HIGH notification on transcription failure."""
    from memex.models import NotificationPriority
    from memex.notifications import NotificationRouter

    router = NotificationRouter(notification_store)
    router.notify(
        f"Meeting transcription failed: {title}",
        body=str(exc)[:200],
        priority=NotificationPriority.HIGH,
        source="meetings",
    )
