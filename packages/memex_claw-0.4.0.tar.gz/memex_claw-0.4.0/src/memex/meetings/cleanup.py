"""Audio retention cleanup — delete old audio files after transcription."""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def cleanup_audio(
    meeting_store: Any,
    *,
    retention_days: int | None = None,
) -> int:
    """Delete audio files for ingested meetings older than retention_days.

    If retention_days is None, reads MEMEX_AUDIO_RETENTION_DAYS env var (default 3).
    Returns count of files deleted.
    """
    if retention_days is None:
        retention_days = int(os.environ.get("MEMEX_AUDIO_RETENTION_DAYS", "3"))

    recordings = meeting_store.get_recordings_for_cleanup(retention_days)
    deleted = 0

    for recording in recordings:
        audio_path = Path(recording.audio_path)
        if audio_path.exists():
            try:
                audio_path.unlink()
                logger.info("Deleted audio: %s", audio_path)
            except OSError:
                logger.warning("Failed to delete audio: %s", audio_path, exc_info=True)
                continue
        else:
            logger.debug("Audio already gone: %s", audio_path)

        recording.audio_deleted = True
        meeting_store.update_recording(recording)
        deleted += 1

    return deleted
