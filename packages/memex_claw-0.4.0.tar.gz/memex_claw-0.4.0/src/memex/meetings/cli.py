"""Meeting CLI — parser registration and command handlers.

Exposes register_parser() and dispatch() for the central CLI to call.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from memex.cli import resolve_store_path
from memex.utcnow import utcnow


def _make_fathom_store():
    from memex.fathom_facade import make_fathom_store

    return make_fathom_store()


def register_parser(subparsers) -> argparse.ArgumentParser:
    """Add 'meeting' subcommands to argparse. Returns parser for help fallback."""
    meeting_parser = subparsers.add_parser(
        "meeting", help="Meeting capture & transcription"
    )
    meeting_subs = meeting_parser.add_subparsers(dest="meeting_command")
    mt_start = meeting_subs.add_parser("start", help="Start recording a meeting")
    mt_start.add_argument("--title", default=None, help="Meeting title")
    mt_start.add_argument(
        "--sample-rate",
        type=int,
        default=16000,
        help="Audio sample rate (default 16000)",
    )
    mt_start.add_argument(
        "--vad-threshold",
        type=float,
        default=None,
        help="VAD threshold 0.0-1.0 (default 0.2, env MEMEX_VAD_THRESHOLD)",
    )
    meeting_subs.add_parser("stop", help="Stop an active recording")
    meeting_subs.add_parser(
        "status", help="Show active recording or most recent meeting"
    )
    mt_list = meeting_subs.add_parser("list", help="List recent meetings")
    mt_list.add_argument("--all", action="store_true", help="Include failed meetings")
    mt_transcribe = meeting_subs.add_parser(
        "transcribe", help="Transcribe a recorded meeting"
    )
    mt_transcribe.add_argument(
        "id", nargs="?", default=None, help="Meeting ID (or prefix)"
    )
    mt_transcribe.add_argument("--model", default="large-v2", help="Whisper model size")
    mt_transcribe.add_argument(
        "--no-diarize", action="store_true", help="Disable speaker diarization"
    )
    mt_transcribe.add_argument(
        "--extract-actions",
        action="store_true",
        help="Extract action items via LLM (requires API key)",
    )
    return meeting_parser


def dispatch(args: argparse.Namespace, parser: argparse.ArgumentParser | None) -> None:
    """Route meeting subcommands to handler functions."""
    if not hasattr(args, "meeting_command") or args.meeting_command is None:
        if parser:
            parser.print_help()
        return
    elif args.meeting_command == "start":
        _cmd_meeting_start(args)
    elif args.meeting_command == "stop":
        _cmd_meeting_stop(args)
    elif args.meeting_command == "status":
        _cmd_meeting_status(args)
    elif args.meeting_command == "list":
        _cmd_meeting_list(args)
    elif args.meeting_command == "transcribe":
        _cmd_meeting_transcribe(args)


def _render_meter(
    level: float, vad_threshold: float, elapsed: float, bar_width: int = 30
) -> str:
    """Render a single-line level meter string."""
    mins, secs = divmod(int(elapsed), 60)
    filled = int(level * bar_width)
    bar_chars = list("░" * bar_width)
    for i in range(min(filled, bar_width)):
        bar_chars[i] = "█"
    # Place VAD marker
    vad_pos = int(vad_threshold * bar_width)
    if 0 <= vad_pos < bar_width:
        bar_chars[vad_pos] = "▼"
    bar = "".join(bar_chars)
    return f"\rRecording [{mins:02d}:{secs:02d}]  {bar} {level:.2f}  VAD {vad_threshold:.2f}  [+/-] adjust  [Ctrl+C] stop"


def _cmd_meeting_start(args: argparse.Namespace) -> None:
    """Start recording a meeting with interactive level meter."""
    import select
    import signal
    import termios
    import time
    import tty
    import uuid

    from memex.meetings.capture import AudioCapture
    from memex.meetings.models import MeetingRecord, MeetingState

    store = _make_fathom_store()
    try:
        meeting_store = store.meetings

        # A row stuck in state='recording' is stale from a crashed previous session.
        # The CLI is a fresh process so any active recording in the DB is orphaned.
        meeting_store.cleanup_stale_recordings()

        meeting_id = str(uuid.uuid4())
        title = getattr(args, "title", None) or ""
        sample_rate = getattr(args, "sample_rate", 16000) or 16000

        # Resolve VAD threshold: arg → env → 0.1
        vad_threshold = getattr(args, "vad_threshold", None)
        if vad_threshold is None:
            env_val = os.environ.get("MEMEX_VAD_THRESHOLD")
            vad_threshold = float(env_val) if env_val else 0.1

        audio_dir = Path(resolve_store_path()).parent / "audio"
        capture = AudioCapture(audio_dir, sample_rate=sample_rate)

        now = utcnow()
        record = MeetingRecord(
            meeting_id=meeting_id,
            state=MeetingState.RECORDING,
            title=title,
            sample_rate=sample_rate,
            vad_threshold=vad_threshold,
            started_at=now,
            created_at=now,
            updated_at=now,
        )

        audio_path = capture.start(meeting_id)
        record.audio_path = str(audio_path)
        meeting_store.create_meeting(record)

        print(f"Recording started: {meeting_id[:8]}")
        if title:
            print(f"Title: {title}")

        # Block until Ctrl+C or stop signal file
        stop_signal = audio_dir / ".stop_signal"
        start_time = time.monotonic()

        def _handle_stop(signum, frame):
            raise KeyboardInterrupt

        signal.signal(signal.SIGTERM, _handle_stop)

        # Enter terminal raw mode for interactive key handling
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)

        try:
            tty.setraw(fd)
            while capture.is_recording:
                elapsed = time.monotonic() - start_time
                line = _render_meter(capture.level, vad_threshold, elapsed)
                sys.stderr.write(line)
                sys.stderr.flush()

                # Non-blocking stdin check with 100ms timeout
                readable, _, _ = select.select([sys.stdin], [], [], 0.1)
                if readable:
                    ch = sys.stdin.read(1)
                    if ch in ("+", "="):
                        vad_threshold = min(vad_threshold + 0.05, 0.95)
                        record.vad_threshold = vad_threshold
                    elif ch in ("-", "_"):
                        vad_threshold = max(vad_threshold - 0.05, 0.05)
                        record.vad_threshold = vad_threshold
                    elif ch == "\x03":  # Ctrl+C
                        break

                if stop_signal.exists():
                    stop_signal.unlink()
                    break
        except KeyboardInterrupt:
            pass
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

        path, duration = capture.stop()
        record.audio_path = str(path)
        record.duration_seconds = duration
        record.stopped_at = utcnow()
        record.state = MeetingState.RECORDED
        meeting_store.update_meeting(record)

        sys.stderr.write("\r\033[K")  # Clear meter line
        sys.stderr.flush()
        print(
            f"Recording stopped: {duration:.1f}s (VAD threshold: {vad_threshold:.2f})"
        )
        print(f"Audio: {path}")
        print(f"Run `memex meeting transcribe {meeting_id[:8]}` to transcribe.")
    finally:
        store.close()


def _cmd_meeting_stop(args: argparse.Namespace) -> None:
    """Stop an active recording via stop signal file."""
    audio_dir = Path(resolve_store_path()).parent / "audio"
    stop_signal = audio_dir / ".stop_signal"
    audio_dir.mkdir(parents=True, exist_ok=True)
    stop_signal.touch()
    print("Stop signal sent. Recording will stop within 1 second.")


def _cmd_meeting_status(args: argparse.Namespace) -> None:
    """Show active recording or most recent meeting."""
    store = _make_fathom_store()
    try:
        meeting_store = store.meetings
        active = meeting_store.get_active_recording()

        if active:
            elapsed = (
                (utcnow() - active.started_at).total_seconds()
                if active.started_at
                else 0
            )
            print(f"Recording: {active.meeting_id[:8]}")
            if active.title:
                print(f"Title:     {active.title}")
            print(f"Elapsed:   {elapsed:.0f}s")
            return

        meetings = meeting_store.list_meetings(limit=1)
        if not meetings:
            print("No meetings found.")
            return

        m = meetings[0]
        print(f"ID:       {m.meeting_id[:8]}")
        print(f"State:    {m.state.value}")
        if m.title:
            print(f"Title:    {m.title}")
        if m.duration_seconds:
            print(f"Duration: {m.duration_seconds:.1f}s")
        if m.started_at:
            print(f"Started:  {m.started_at}")
        if m.speaker_count:
            print(f"Speakers: {m.speaker_count}")
    finally:
        store.close()


def _cmd_meeting_list(args: argparse.Namespace) -> None:
    """List recent meetings."""
    store = _make_fathom_store()
    try:
        include_all = getattr(args, "all", False)
        meetings = store.meetings.list_meetings(include_all=include_all)

        if not meetings:
            print("No meetings found.")
            return

        for m in meetings:
            title = m.title or "Untitled"
            dur = f" ({m.duration_seconds:.0f}s)" if m.duration_seconds else ""
            print(f"  [{m.state.value:12s}] {m.meeting_id[:8]} — {title}{dur}")
    finally:
        store.close()


def _cmd_meeting_transcribe(args: argparse.Namespace) -> None:
    """Synchronous transcription of a recorded meeting."""
    from memex.meetings.transcribe import orchestrate_transcription

    store = _make_fathom_store()
    try:
        meeting_store = store.meetings

        # Resolve meeting ID
        meeting_id = getattr(args, "id", None)
        if meeting_id:
            record = meeting_store.get_meeting(meeting_id)
            if not record:
                # Try prefix match
                meetings = meeting_store.list_meetings(include_all=True)
                matches = [m for m in meetings if m.meeting_id.startswith(meeting_id)]
                if len(matches) == 1:
                    record = matches[0]
                elif len(matches) > 1:
                    print(f"Ambiguous ID '{meeting_id}', matches:")
                    for m in matches:
                        print(f"  {m.meeting_id[:8]} — {m.title or 'Untitled'}")
                    return
                else:
                    print(f"Meeting not found: {meeting_id}")
                    return
        else:
            # Find most recent recorded meeting
            meetings = meeting_store.list_meetings(include_all=True)
            recorded = [m for m in meetings if m.state.value in ("recorded", "failed")]
            if not recorded:
                print("No recorded meetings to transcribe.")
                return
            record = recorded[0]

        model = getattr(args, "model", "large-v2") or "large-v2"
        record.whisper_model = model
        meeting_store.update_meeting(record)

        print(f"Transcribing {record.meeting_id[:8]}...")
        try:
            ns = getattr(store, "notifications", None)
        except Exception:
            ns = None

        # Load speaker mappings from human model
        speaker_mappings = None
        try:
            from memex.human_model import load_canonical_speaker_mappings

            loaded_mappings = load_canonical_speaker_mappings(store)
            if loaded_mappings:
                speaker_mappings = loaded_mappings
        except Exception:
            pass

        extract_actions = getattr(args, "extract_actions", False)

        item = orchestrate_transcription(
            record.meeting_id,
            meeting_store=meeting_store,
            content_store=store.content,
            memex_store=store,
            notification_store=ns,
            speaker_mappings=speaker_mappings,
            extract_action_items=extract_actions,
        )
        if item is not None:
            print(f"Transcribed: {item.title}  [{item.item_id[:8]}]")
            print(f"Speakers: {record.speaker_count}, Language: {record.language}")
            if extract_actions and item.metadata.get("meeting", {}).get("action_items"):
                actions = item.metadata["meeting"]["action_items"]
                print(f"Action items ({len(actions)}):")
                for ai in actions:
                    assignee = ai.get("assignee", "unassigned")
                    action = ai.get("action", "")
                    print(f"  - [{assignee}] {action}")
        else:
            print("Transcription complete (no content store).")
    finally:
        store.close()
