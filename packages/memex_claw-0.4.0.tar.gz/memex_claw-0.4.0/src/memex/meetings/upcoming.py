"""Upcoming meeting syncing and briefing helpers."""

from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta
from typing import Any

from memex.models import (
    Goal,
    MeetingEntityLink,
    NotificationPriority,
)
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)


def _content_store_for(store: Any) -> Any | None:
    cs = getattr(store, "_content_store", None)
    if cs is not None:
        return cs
    try:
        return store.content
    except Exception:
        return None


def _resolve_person_entity_id(
    content_store: Any, name: str, *, create: bool
) -> str | None:
    if not content_store or not hasattr(content_store, "find_entity"):
        return None
    try:
        entity_id = content_store.find_entity(name, "person")
        if entity_id:
            return entity_id
        if create and hasattr(content_store, "create_entity"):
            return content_store.create_entity(name, "person")
    except Exception:
        logger.debug("Failed to resolve person entity for %s", name, exc_info=True)
    return None


def sync_meeting_attendee_links(store: Any, meeting: Any) -> int:
    """Create meeting/entity links for attendees when the backend supports entities."""
    content_store = _content_store_for(store)
    if content_store is None:
        return 0

    linked = 0
    for attendee in meeting.attendees:
        entity_id = _resolve_person_entity_id(content_store, attendee, create=True)
        if entity_id is None:
            continue
        store.create_meeting_entity_link(
            MeetingEntityLink(
                meeting_id=meeting.meeting_id,
                entity_id=entity_id,
                relationship="attendee",
                created_at=utcnow(),
            )
        )
        linked += 1
    return linked


def sync_google_calendar_events(store: Any, *, now: datetime | None = None) -> int:
    """Sync upcoming Google Calendar events into store."""
    from memex.integrations.google_calendar import GoogleCalendarClient

    current = now or utcnow()
    horizon_days = int(os.environ.get("MEMEX_CALENDAR_SYNC_DAYS", "7"))
    horizon = current + timedelta(days=horizon_days)
    calendar_id = os.environ.get("MEMEX_GOOGLE_CALENDAR_ID", "primary")

    client = GoogleCalendarClient()
    try:
        client.authenticate()
    except Exception:
        logger.debug("Google Calendar auth unavailable", exc_info=True)
        return 0

    events = client.list_upcoming_events(
        now=current,
        horizon=horizon,
        calendar_id=calendar_id,
        limit=50,
    )
    for event in events:
        store.upsert_calendar_event(event)
    return len(events)


def list_upcoming_candidates(
    store: Any,
    *,
    now: datetime | None = None,
    horizon_hours: int = 24,
) -> list[dict[str, Any]]:
    """Return normalized upcoming meeting candidates from Memex and calendar."""
    current = now or utcnow()
    horizon = current + timedelta(hours=horizon_hours)
    candidates: list[dict[str, Any]] = []

    for meeting in store.meetings.list_upcoming_meetings(
        horizon=horizon, now=current, limit=20
    ):
        candidates.append(
            {
                "kind": "meeting",
                "key": f"meeting:{meeting.meeting_id}",
                "title": meeting.title or "Untitled Meeting",
                "starts_at": meeting.scheduled_for,
                "attendees": list(meeting.attendees),
                "meeting_id": meeting.meeting_id,
                "calendar_source": meeting.calendar_source or "memex",
            }
        )

    for event in store.list_upcoming_calendar_events(horizon):
        if event.starts_at < current:
            continue
        candidates.append(
            {
                "kind": "calendar",
                "key": f"calendar:{event.event_id}",
                "title": event.title,
                "starts_at": event.starts_at,
                "attendees": list(event.attendees),
                "event_id": event.event_id,
                "calendar_source": event.provider,
            }
        )

    candidates.sort(key=lambda candidate: candidate["starts_at"] or horizon)
    return candidates


def _ensure_entity_and_goal_links(
    store: Any,
    entity_id: str,
    name: str,
    entity_type: str = "person",
) -> None:
    """Ensure the WMEntity node exists and link matching goals to it."""
    try:
        fathom = getattr(store, "_fathom", None)
        if fathom and hasattr(fathom, "world_model"):
            fathom.world_model.upsert_entity(
                entity_id, entity_type, name, status="active"
            )
    except Exception:
        logger.debug("Failed to upsert entity %s", entity_id, exc_info=True)

    # Link goals whose title mentions this entity name
    try:
        from memex.models import GoalEntityLink

        all_goals = store.list_goals()
        existing = store.list_goals_for_entity(entity_id)
        already_linked_ids = {gl.goal_id for gl in existing}
        for goal in all_goals:
            if name.lower() in (goal.title or "").lower():
                if goal.goal_id in already_linked_ids:
                    continue
                store.create_goal_entity_link(
                    GoalEntityLink(
                        goal_id=goal.goal_id,
                        entity_id=entity_id,
                        relationship="mentioned_in_title",
                        created_at=utcnow(),
                    )
                )
                already_linked_ids.add(goal.goal_id)
    except Exception:
        logger.debug("Failed to link goals to entity %s", entity_id, exc_info=True)


def _collect_goals_for_candidate(store: Any, candidate: dict[str, Any]) -> list[Goal]:
    goals: dict[str, Goal] = {}

    if candidate["kind"] == "meeting":
        for link in store.list_meeting_goal_links(candidate["meeting_id"]):
            goal = store.get_goal(link.goal_id)
            if goal is not None:
                goals[goal.goal_id] = goal

        meeting_entity_links = store.list_meeting_entity_links(candidate["meeting_id"])
        for entity_link in meeting_entity_links:
            for goal_link in store.list_goals_for_entity(entity_link.entity_id):
                goal = store.get_goal(goal_link.goal_id)
                if goal is not None:
                    goals[goal.goal_id] = goal
    else:
        content_store = _content_store_for(store)
        if content_store is not None:
            for attendee in candidate["attendees"]:
                entity_id = _resolve_person_entity_id(
                    content_store, attendee, create=True
                )
                if entity_id is None:
                    continue
                _ensure_entity_and_goal_links(store, entity_id, attendee)
                for goal_link in store.list_goals_for_entity(entity_id):
                    goal = store.get_goal(goal_link.goal_id)
                    if goal is not None:
                        goals[goal.goal_id] = goal

    return list(goals.values())


def _build_briefing(candidate: dict[str, Any], goals: list[Goal], now: datetime) -> str:
    parts = [f"Meeting: {candidate['title']}"]
    if candidate.get("starts_at"):
        parts.append(f"When: {candidate['starts_at'].strftime('%Y-%m-%d %H:%M')}")
    if candidate["attendees"]:
        parts.append(f"Attendees: {', '.join(candidate['attendees'])}")

    if not goals:
        parts.append("No linked goals yet.")
        return "\n".join(parts)

    parts.append("Talking points:")
    for goal in goals[:5]:
        line = f"- {goal.title}"
        if goal.blocked_by_goal_id:
            blocker = store_blocker_title(goal, goals)  # type: ignore[name-defined]
            if blocker:
                line += f" [blocked by {blocker}]"
        elif goal.blocked_reason:
            line += f" [blocked: {goal.blocked_reason}]"
        if goal.deadline:
            hours_left = int(max(0, (goal.deadline - now).total_seconds() / 3600))
            line += f" [deadline in {hours_left}h]"
        parts.append(line)
    return "\n".join(parts)


def store_blocker_title(goal: Goal, goals: list[Goal]) -> str:
    if not goal.blocked_by_goal_id:
        return ""
    for candidate in goals:
        if candidate.goal_id == goal.blocked_by_goal_id:
            return candidate.title
    return goal.blocked_by_goal_id[:8]


def prepare_meeting_briefings(
    store: Any,
    notification_store: Any,
    *,
    now: datetime | None = None,
) -> int:
    """Create notifications for upcoming meetings with linked goal context."""
    current = now or utcnow()
    horizon_hours = int(os.environ.get("MEMEX_MEETING_PREP_HOURS", "24"))
    candidates = list_upcoming_candidates(
        store, now=current, horizon_hours=horizon_hours
    )
    if not candidates:
        return 0

    pending_keys = set()
    try:
        for notification in notification_store.list_pending(limit=100):
            meeting_key = notification.action_data.get("meeting_key")
            if meeting_key:
                pending_keys.add(meeting_key)
    except Exception:
        logger.debug("Failed to load pending notifications for dedupe", exc_info=True)

    created = 0
    from memex.notifications import NotificationRouter

    router = NotificationRouter(notification_store)
    for candidate in candidates:
        if candidate["key"] in pending_keys:
            continue

        if candidate["kind"] == "meeting":
            record = store.meetings.get_meeting(candidate["meeting_id"])
            if record is not None:
                sync_meeting_attendee_links(store, record)

        goals = _collect_goals_for_candidate(store, candidate)
        if not goals:
            continue

        body = _build_briefing(candidate, goals, current)
        router.notify(
            f"Prep: {candidate['title']}",
            body=body,
            priority=NotificationPriority.NORMAL,
            source="meeting_prep",
            goal_id=goals[0].goal_id if goals else None,
            action_data={
                "meeting_key": candidate["key"],
                "meeting_id": candidate.get("meeting_id", ""),
                "event_id": candidate.get("event_id", ""),
            },
        )
        created += 1

    return created
