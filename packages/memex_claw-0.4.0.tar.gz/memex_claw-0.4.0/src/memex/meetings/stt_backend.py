"""STT backend abstraction — Riva (primary) + PyTorch Whisper (fallback)."""

from __future__ import annotations

import logging
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class STTSegment:
    """A single transcription segment from any backend."""

    start: float
    end: float
    text: str
    confidence: float = 0.0  # 0.0-1.0 unified quality metric
    speaker: str | None = None  # populated by Riva diarization


@dataclass(frozen=True)
class STTResult:
    """Transcription output from any backend."""

    segments: list[STTSegment]
    language: str
    duration_seconds: float
    backend_name: str  # "riva" or "whisper-pytorch"
    quality: float = 0.0  # average segment confidence


class STTBackend(ABC):
    """Abstract speech-to-text backend."""

    name: str = ""

    @abstractmethod
    def transcribe(
        self,
        audio_path: Path,
        *,
        language: str | None = None,
        diarize: bool = True,
    ) -> STTResult: ...

    @abstractmethod
    def is_available(self) -> bool: ...


# ---------------------------------------------------------------------------
# Riva backend
# ---------------------------------------------------------------------------


class RivaBackend(STTBackend):
    """NVIDIA Riva ASR via gRPC."""

    name = "riva"

    def __init__(self, server: str = "localhost:50051"):
        self._server = server

    def is_available(self) -> bool:
        try:
            import grpc

            channel = grpc.insecure_channel(self._server)
            try:
                grpc.channel_ready_future(channel).result(timeout=2)
                return True
            except grpc.FutureTimeoutError:
                return False
            finally:
                channel.close()
        except Exception:
            return False

    def transcribe(
        self,
        audio_path: Path,
        *,
        language: str | None = None,
        diarize: bool = True,
    ) -> STTResult:
        import riva.client

        auth = riva.client.Auth(
            uri=self._server,
            use_ssl=False,
        )
        asr_service = riva.client.ASRService(auth)

        audio_path = Path(audio_path)
        with open(audio_path, "rb") as f:
            audio_data = f.read()

        lang = language or os.environ.get("MEMEX_ASR_LANGUAGE", "en-US")
        if len(lang) == 2:
            lang = f"{lang}-US" if lang == "en" else f"{lang}-{lang.upper()}"

        config = riva.client.RecognitionConfig(
            language_code=lang,
            max_alternatives=1,
            enable_automatic_punctuation=True,
            enable_word_time_offsets=True,
        )
        if diarize:
            config.diarization_config.enable_speaker_diarization = True

        response = asr_service.offline_recognize(audio_data, config)

        segments: list[STTSegment] = []
        for result in response.results:
            if not result.alternatives:
                continue
            alt = result.alternatives[0]
            if not alt.words:
                # Sentence-level result without word timestamps
                segments.append(
                    STTSegment(
                        start=0.0,
                        end=0.0,
                        text=alt.transcript.strip(),
                        confidence=alt.confidence,
                        speaker=None,
                    )
                )
                continue

            # Group words into speaker turns
            current_words: list[str] = []
            current_speaker: str | None = None
            seg_start: float = 0.0

            for word_info in alt.words:
                w_start = word_info.start_time / 1000.0  # ms -> seconds
                w_speaker = getattr(word_info, "speaker_tag", None)
                if isinstance(w_speaker, int):
                    w_speaker = f"SPEAKER_{w_speaker:02d}"

                if current_speaker is not None and w_speaker != current_speaker:
                    # Speaker changed — flush segment
                    segments.append(
                        STTSegment(
                            start=seg_start,
                            end=w_start,
                            text=" ".join(current_words).strip(),
                            confidence=alt.confidence,
                            speaker=current_speaker if diarize else None,
                        )
                    )
                    current_words = []
                    seg_start = w_start

                if not current_words:
                    seg_start = w_start
                current_speaker = w_speaker
                current_words.append(word_info.word)

            # Flush last segment
            if current_words:
                last_end = alt.words[-1].end_time / 1000.0  # ms -> seconds
                segments.append(
                    STTSegment(
                        start=seg_start,
                        end=last_end,
                        text=" ".join(current_words).strip(),
                        confidence=alt.confidence,
                        speaker=current_speaker if diarize else None,
                    )
                )

        duration = segments[-1].end if segments else 0.0
        quality = (
            sum(s.confidence for s in segments) / len(segments) if segments else 0.0
        )

        return STTResult(
            segments=segments,
            language=lang,
            duration_seconds=duration,
            backend_name=self.name,
            quality=quality,
        )


# ---------------------------------------------------------------------------
# PyTorch Whisper backend (fallback)
# ---------------------------------------------------------------------------


class WhisperPyTorchBackend(STTBackend):
    """OpenAI Whisper via PyTorch (GPU-accelerated on Jetson)."""

    name = "whisper-pytorch"

    def __init__(self, model_size: str = "large-v2"):
        self._model_size = model_size
        self._model = None

    def is_available(self) -> bool:
        try:
            import whisper  # noqa: F401

            return True
        except ImportError:
            return False

    def _load_model(self):
        if self._model is None:
            import whisper

            logger.info("Loading Whisper model: %s", self._model_size)
            self._model = whisper.load_model(self._model_size)
        return self._model

    def transcribe(
        self,
        audio_path: Path,
        *,
        language: str | None = None,
        diarize: bool = True,
        vad_threshold: float | None = None,
    ) -> STTResult:
        import math

        model = self._load_model()
        kwargs: dict = {"word_timestamps": True, "verbose": False}
        if language:
            kwargs["language"] = language

        result = model.transcribe(str(audio_path), **kwargs)

        segments: list[STTSegment] = []
        for seg in result.get("segments", []):
            avg_logprob = seg.get("avg_logprob", -1.0)
            no_speech_prob = seg.get("no_speech_prob", 0.0)
            confidence = math.exp(max(-2.0, avg_logprob)) * (1.0 - no_speech_prob)
            segments.append(
                STTSegment(
                    start=seg["start"],
                    end=seg["end"],
                    text=seg["text"].strip(),
                    confidence=confidence,
                    speaker=None,  # Whisper doesn't diarize
                )
            )

        detected_lang = result.get("language", language or "")
        duration = segments[-1].end if segments else 0.0
        quality = (
            sum(s.confidence for s in segments) / len(segments) if segments else 0.0
        )

        return STTResult(
            segments=segments,
            language=detected_lang,
            duration_seconds=duration,
            backend_name=self.name,
            quality=quality,
        )


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

_cached_backend: STTBackend | None = None


def get_backend(*, force: str | None = None) -> STTBackend:
    """Return the best available STT backend.

    Tries Riva first (if gRPC server is reachable), then PyTorch Whisper.
    Set MEMEX_STT_BACKEND=riva|whisper to force a specific backend.
    """
    global _cached_backend
    if _cached_backend is not None and force is None:
        return _cached_backend

    backend_env = force or os.environ.get("MEMEX_STT_BACKEND", "")

    if backend_env == "whisper":
        backend = WhisperPyTorchBackend()
        if backend.is_available():
            _cached_backend = backend
            return backend
        raise RuntimeError("Whisper backend requested but openai-whisper not installed")

    # Try Riva first (default)
    riva_server = os.environ.get("MEMEX_RIVA_SERVER", "localhost:50051")
    riva = RivaBackend(server=riva_server)

    if backend_env == "riva":
        if riva.is_available():
            _cached_backend = riva
            return riva
        raise RuntimeError(
            f"Riva backend requested but server not reachable at {riva_server}"
        )

    # Auto-select: Riva if available, else Whisper
    if riva.is_available():
        logger.info("Using Riva STT backend at %s", riva_server)
        _cached_backend = riva
        return riva

    whisper = WhisperPyTorchBackend()
    if whisper.is_available():
        logger.info("Riva not available; falling back to PyTorch Whisper")
        _cached_backend = whisper
        return whisper

    raise RuntimeError(
        "No STT backend available. Install openai-whisper or start Riva server."
    )
