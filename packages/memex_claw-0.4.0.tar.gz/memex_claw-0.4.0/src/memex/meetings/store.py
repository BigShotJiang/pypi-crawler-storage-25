"""Re-export FathomMeetingAdapter as MeetingStore for backward compatibility."""

from memex.fathom_facade import FathomMeetingAdapter as MeetingStore

__all__ = ["MeetingStore"]
