"""Audio preparation pipeline for Whisper transcription quality.

Steps applied (in order) when needed:
  1. Read with soundfile → float32 numpy array
  2. Mix stereo → mono
  3. Resample to 16 kHz (Whisper's native rate)
  4. Trim leading / trailing silence (energy-based)
  5. High-pass filter at 200 Hz (remove room rumble / DC offset)
  6. RMS-normalize if too quiet; peak-limit if clipping
  7. Write prepared WAV to tmp_dir if anything changed

A Silero VAD pre-analysis function is also provided to suggest a starting
VAD threshold based on actual speech density in the file.
"""

from __future__ import annotations

import logging
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import soundfile as sf

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Tunable constants (public so tests can inspect / override)
# ---------------------------------------------------------------------------
QUIET_RMS_THRESHOLD: float = 0.02  # RMS below this → normalize up
TARGET_RMS: float = 0.10  # target RMS when normalizing quiet audio
LOUD_PEAK_THRESHOLD: float = 0.95  # peak above this → peak-limit
HIGHPASS_CUTOFF_HZ: int = 200  # high-pass cutoff for room rumble removal
SILENCE_ENERGY_FRACTION: float = 0.05  # fraction of mean RMS used for silence gate
SILENCE_MIN_DURATION_S: float = 0.3  # minimum silence block to trim at edges
TARGET_SAMPLE_RATE: int = 16000  # Whisper's native rate


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class AudioAnalysis:
    """Properties of a raw audio file before any processing."""

    sample_rate: int
    channels: int
    duration_seconds: float
    rms_level: float  # mean RMS of the file (0.0–1.0 float range)
    peak_level: float  # max |sample| value
    is_too_quiet: bool  # rms < QUIET_RMS_THRESHOLD
    is_clipping: bool  # peak > LOUD_PEAK_THRESHOLD


@dataclass
class PreparedAudio:
    """Result of the audio preparation pipeline."""

    path: Path  # path to prepared file (may equal source)
    analysis: AudioAnalysis
    was_modified: bool
    applied_steps: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def analyze_audio(path: Path | str) -> AudioAnalysis:
    """Read an audio file and return level / format statistics."""
    path = Path(path)
    info = sf.info(str(path))
    data, _ = sf.read(str(path), dtype="float32", always_2d=False)

    # Convert to mono for level measurement
    mono = data.mean(axis=1) if data.ndim == 2 else data
    rms = float(np.sqrt(np.mean(mono**2)))
    peak = float(np.max(np.abs(mono)))
    channels = info.channels

    return AudioAnalysis(
        sample_rate=info.samplerate,
        channels=channels,
        duration_seconds=info.duration,
        rms_level=rms,
        peak_level=peak,
        is_too_quiet=rms < QUIET_RMS_THRESHOLD,
        is_clipping=peak > LOUD_PEAK_THRESHOLD,
    )


def prepare_audio(
    path: Path | str,
    *,
    tmp_dir: Path | None = None,
) -> PreparedAudio:
    """Apply the audio preparation pipeline to a file.

    Returns a PreparedAudio whose `path` field points to the processed file.
    If no modifications are needed the original path is returned and
    `was_modified` is False.
    """
    path = Path(path)
    analysis = analyze_audio(path)

    data, sr = sf.read(str(path), dtype="float32", always_2d=False)
    applied: list[str] = []
    modified = False

    # 1. Stereo → mono
    if data.ndim == 2:
        data = data.mean(axis=1)
        applied.append("to_mono")
        modified = True

    # 2. Resample to TARGET_SAMPLE_RATE
    if sr != TARGET_SAMPLE_RATE:
        data = _resample(data, sr, TARGET_SAMPLE_RATE)
        sr = TARGET_SAMPLE_RATE
        applied.append("resample")
        modified = True

    # 3. Trim leading / trailing silence
    trimmed = _trim_silence(data, sr)
    if len(trimmed) < len(data):
        data = trimmed
        applied.append("trim_silence")
        modified = True

    # 4. High-pass filter (remove room rumble) — only when sub-cutoff energy is
    #    dominant (> 15% of total), indicating real DC offset or low-freq rumble.
    if _has_low_freq_energy(data, sr, HIGHPASS_CUTOFF_HZ, threshold_fraction=0.15):
        data = _apply_highpass(data, sr, HIGHPASS_CUTOFF_HZ)
        applied.append("highpass")
        modified = True

    # 5. Normalize level
    # Prefer EBU R128 loudness normalization via ffmpeg (two-pass, highest quality).
    # Fall back to RMS-based normalization when ffmpeg is unavailable.
    rms = float(np.sqrt(np.mean(data**2))) if len(data) else 0.0
    peak = float(np.max(np.abs(data))) if len(data) else 0.0
    needs_normalize = (rms < QUIET_RMS_THRESHOLD and rms > 0) or (
        peak > LOUD_PEAK_THRESHOLD
    )

    # Lazy temp-dir factory — creates at most one directory regardless of how
    # many pipeline stages need it.
    def _get_tmp() -> Path:
        nonlocal tmp_dir
        if tmp_dir is None:
            tmp_dir = Path(tempfile.mkdtemp(prefix="memex_audio_prep_"))
        return tmp_dir

    if needs_normalize:
        # Write intermediate file so ffmpeg can read it
        _interim = _get_tmp() / f"{path.stem}_interim.wav"
        sf.write(str(_interim), data, sr)
        loudnorm_out = _ffmpeg_loudnorm(_interim, tmp_dir, path.stem)
        if loudnorm_out is not None:
            # ffmpeg loudnorm succeeded — read back the normalized audio
            data, sr = sf.read(str(loudnorm_out), dtype="float32", always_2d=False)
            applied.append("loudnorm")
        else:
            # ffmpeg unavailable — fall back to RMS normalization
            if rms < QUIET_RMS_THRESHOLD and rms > 0:
                scale = min(TARGET_RMS / rms, LOUD_PEAK_THRESHOLD / (peak + 1e-9))
                data = data * scale
                applied.append("normalize")
                peak = float(np.max(np.abs(data))) if len(data) else 0.0
            if peak > LOUD_PEAK_THRESHOLD:
                data = data * (LOUD_PEAK_THRESHOLD / peak)
                applied.append("peak_limit")
        modified = True

    if not modified:
        return PreparedAudio(
            path=path,
            analysis=analysis,
            was_modified=False,
            applied_steps=[],
        )

    # Write final prepared audio to tmp_dir
    out_path = _get_tmp() / f"{path.stem}_prepared.wav"
    sf.write(str(out_path), data, sr)

    logger.info(
        "Audio prep (%s): %s → %s  steps=%s",
        path.name,
        _fmt_dur(analysis.duration_seconds),
        _fmt_dur(len(data) / sr),
        applied,
    )

    return PreparedAudio(
        path=out_path,
        analysis=analysis,
        was_modified=True,
        applied_steps=applied,
    )


def suggest_vad_threshold(
    path: Path | str, *, sample_rate: int = TARGET_SAMPLE_RATE
) -> float | None:
    """Run Silero VAD at several thresholds and return the highest that still
    detects ≥ 15 % speech coverage.

    Returns None if no threshold produces sufficient coverage (audio is
    predominantly silence or non-speech).  Never raises — failures are logged
    and None is returned.
    """
    path = Path(path)
    try:
        from memex.meetings.vad import speech_timestamps
    except ImportError:
        logger.debug("Silero VAD not available; skipping VAD pre-analysis")
        return None

    try:
        data, sr = sf.read(str(path), dtype="float32", always_2d=False)
        if data.ndim == 2:
            data = data.mean(axis=1)
        if sr != sample_rate:
            data = _resample(data, sr, sample_rate)
        total_samples = len(data)
        if total_samples == 0:
            return None

        for threshold in (0.5, 0.4, 0.3, 0.2, 0.1):
            try:
                chunks = speech_timestamps(
                    data,
                    threshold=threshold,
                    sampling_rate=sample_rate,
                )
            except Exception:
                continue
            if not chunks:
                continue
            speech_samples = sum(c["end"] - c["start"] for c in chunks)
            coverage = speech_samples / total_samples
            if coverage >= 0.15:
                logger.info(
                    "VAD pre-analysis: threshold=%.1f gives %.0f%% coverage",
                    threshold,
                    coverage * 100,
                )
                return threshold

        logger.info("VAD pre-analysis: no threshold ≥ 0.1 gave sufficient coverage")
        return None

    except Exception:
        logger.debug("VAD pre-analysis failed", exc_info=True)
        return None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resample(data: np.ndarray, from_sr: int, to_sr: int) -> np.ndarray:
    """Resample audio using scipy.signal.resample_poly (integer ratios)."""
    try:
        from math import gcd
        from scipy.signal import resample_poly

        g = gcd(from_sr, to_sr)
        up, down = to_sr // g, from_sr // g
        return resample_poly(data, up, down).astype(np.float32)
    except ImportError:
        # scipy not available: fall back to numpy linear interpolation
        logger.warning("scipy not available; using numpy interpolation for resampling")
        original_length = len(data)
        target_length = int(original_length * to_sr / from_sr)
        x_old = np.linspace(0, 1, original_length)
        x_new = np.linspace(0, 1, target_length)
        return np.interp(x_new, x_old, data).astype(np.float32)


def _apply_highpass(data: np.ndarray, sr: int, cutoff_hz: int) -> np.ndarray:
    """Apply a Butterworth high-pass filter via scipy (if available).

    Falls back to simple mean subtraction (DC removal only) if scipy is absent.
    Returns the original array object if no filtering was applied.
    """
    try:
        from scipy.signal import butter, sosfilt

        nyq = sr / 2.0
        norm_cutoff = cutoff_hz / nyq
        if norm_cutoff >= 1.0:
            return data
        sos = butter(4, norm_cutoff, btype="high", output="sos")
        return sosfilt(sos, data).astype(np.float32)
    except ImportError:
        # scipy not available: remove DC offset only
        return (data - np.mean(data)).astype(np.float32)


def _trim_silence(
    data: np.ndarray,
    sr: int,
    *,
    energy_fraction: float = SILENCE_ENERGY_FRACTION,
    min_duration_s: float = SILENCE_MIN_DURATION_S,
) -> np.ndarray:
    """Trim leading and trailing silence using a short-time energy gate.

    Silence is defined as frames where RMS energy < energy_fraction × mean RMS.
    """
    if len(data) == 0:
        return data

    frame_len = max(1, sr // 100)  # 10 ms frames
    n_frames = len(data) // frame_len
    if n_frames < 2:
        return data

    frames = data[: n_frames * frame_len].reshape(n_frames, frame_len)
    rms_frames = np.sqrt(np.mean(frames**2, axis=1))
    mean_rms = float(np.mean(rms_frames))
    if mean_rms == 0:
        return data

    threshold = mean_rms * energy_fraction
    min_frames = max(1, int(min_duration_s * sr / frame_len))

    # Leading silence
    start_frame = 0
    for i, r in enumerate(rms_frames):
        if r >= threshold:
            start_frame = max(0, i - 1)
            break

    # Trailing silence (scan backwards)
    end_frame = n_frames
    for i in range(n_frames - 1, -1, -1):
        if rms_frames[i] >= threshold:
            end_frame = min(n_frames, i + 2)
            break

    trim_lead = start_frame * frame_len
    trim_trail = end_frame * frame_len

    # Only trim if we'd actually remove at least min_duration_s worth
    if (
        trim_lead < min_frames * frame_len
        and (len(data) - trim_trail) < min_frames * frame_len
    ):
        return data

    return data[trim_lead:trim_trail]


def _has_low_freq_energy(
    data: np.ndarray,
    sr: int,
    cutoff_hz: int,
    *,
    threshold_fraction: float = 0.15,
) -> bool:
    """Return True if sub-cutoff energy exceeds threshold_fraction of total energy.

    Uses a short FFT on the first few seconds to avoid processing the full file.
    """
    if len(data) == 0:
        return False
    # Analyse at most 5 seconds to keep this fast
    analysis_samples = min(len(data), sr * 5)
    window = data[:analysis_samples]
    freqs = np.fft.rfftfreq(len(window), 1 / sr)
    fft_mag = np.abs(np.fft.rfft(window)) ** 2
    total_power = float(np.sum(fft_mag))
    if total_power == 0:
        return False
    low_power = float(np.sum(fft_mag[freqs < cutoff_hz]))
    return (low_power / total_power) > threshold_fraction


def _ffmpeg_loudnorm(
    src: Path,
    tmp_dir: Path,
    stem: str,
    *,
    target_i: float = -16.0,  # integrated loudness LUFS (speech: -16 is good)
    target_tp: float = -1.5,  # true peak dBTP
    target_lra: float = 11.0,  # loudness range LU
) -> Path | None:
    """Apply EBU R128 loudness normalization via ffmpeg two-pass.

    Returns the path of the normalized WAV, or None if ffmpeg is unavailable
    or the normalization fails.  The output is always mono 16 kHz PCM.
    """
    import json
    import shutil as _shutil
    import subprocess

    if not _shutil.which("ffmpeg"):
        return None

    out_path = tmp_dir / f"{stem}_loudnorm.wav"
    filter_str = (
        f"loudnorm=I={target_i}:TP={target_tp}:LRA={target_lra}:print_format=json"
    )
    # Pass 1 — measure
    try:
        p1 = subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-i",
                str(src),
                "-af",
                filter_str,
                "-f",
                "null",
                "-",
            ],
            capture_output=True,
            text=True,
            timeout=120,
        )
    except Exception:
        logger.debug("ffmpeg loudnorm pass 1 failed", exc_info=True)
        return None

    # Parse measured values from stderr JSON block.
    # Anchor the search on the "input_i" key that loudnorm always emits, then
    # find the enclosing { } — this is robust to spurious {} fragments in other
    # ffmpeg progress/info lines.
    stderr = p1.stderr
    idx = stderr.find('"input_i"')
    if idx < 0:
        logger.debug("ffmpeg loudnorm: could not find JSON in stderr")
        return None
    json_start = stderr.rfind("{", 0, idx)
    json_end = stderr.find("}", idx)
    if json_start < 0 or json_end < 0:
        logger.debug("ffmpeg loudnorm: malformed JSON block in stderr")
        return None
    json_end += 1  # include the closing brace

    try:
        stats = json.loads(stderr[json_start:json_end])
    except json.JSONDecodeError:
        logger.debug("ffmpeg loudnorm: JSON parse failed")
        return None

    # Pass 2 — apply with measured values (avoids clipping artifacts)
    filter2 = (
        f"loudnorm=I={target_i}:TP={target_tp}:LRA={target_lra}"
        f":measured_I={stats.get('input_i', target_i)}"
        f":measured_TP={stats.get('input_tp', target_tp)}"
        f":measured_LRA={stats.get('input_lra', target_lra)}"
        f":measured_thresh={stats.get('input_thresh', -30)}"
        f":offset={stats.get('target_offset', 0)}"
        ":linear=true:print_format=none"
    )
    try:
        p2 = subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-i",
                str(src),
                "-af",
                filter2,
                "-ar",
                str(TARGET_SAMPLE_RATE),
                "-ac",
                "1",
                str(out_path),
            ],
            capture_output=True,
            timeout=120,
        )
        if p2.returncode != 0:
            logger.debug("ffmpeg loudnorm pass 2 failed: %s", p2.stderr[-500:])
            return None
    except Exception:
        logger.debug("ffmpeg loudnorm pass 2 exception", exc_info=True)
        return None

    return out_path


def _fmt_dur(seconds: float) -> str:
    m, s = divmod(int(seconds), 60)
    return f"{m}m{s:02d}s" if m else f"{s}s"
