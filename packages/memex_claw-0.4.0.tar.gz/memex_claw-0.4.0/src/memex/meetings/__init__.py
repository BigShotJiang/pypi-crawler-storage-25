"""Meeting capture & transcription package.

Public API:
    submit_transcription() — enqueue a recorded meeting for async transcription
"""

from typing import Any

from memex.models import ActionType


def submit_transcription(
    meeting_id: str,
    work_queue: Any,
    scheduler_store: Any,
) -> int:
    """Submit a recorded meeting for async transcription via the work queue.

    Creates an ad-hoc task run (not a scheduled task — transcription is
    event-driven, not cron) and enqueues a WorkItem.

    Returns the run_id for status tracking.
    """
    from memex.scheduler.work_queue import WorkItem

    task_id = f"transcribe-{meeting_id}"
    action_data = {"meeting_id": meeting_id}
    run_id = scheduler_store.record_run(
        task_id,
        status="queued",
        action_type=ActionType.TRANSCRIPTION.value,
        action_data=action_data,
        priority=2,
    )
    work_queue.enqueue(
        WorkItem(
            priority=2,
            task_id=task_id,
            run_id=run_id,
            action_type=ActionType.TRANSCRIPTION.value,
            action_data=action_data,
        )
    )
    return run_id
