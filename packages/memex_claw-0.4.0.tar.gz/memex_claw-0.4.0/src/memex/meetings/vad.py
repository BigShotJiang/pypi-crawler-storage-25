"""Silero VAD — cached model loader for speech timestamp detection."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

_model = None
_get_speech_timestamps = None


def get_silero_vad():
    """Return (model, get_speech_timestamps_fn). Cached after first call."""
    global _model, _get_speech_timestamps
    if _model is None:
        import torch

        _model, utils = torch.hub.load(
            "snakers4/silero-vad", "silero_vad", trust_repo=True, onnx=False
        )
        _get_speech_timestamps = utils[0]
    return _model, _get_speech_timestamps


def speech_timestamps(
    audio_data,
    *,
    threshold: float = 0.5,
    sampling_rate: int = 16000,
) -> list[dict]:
    """Run Silero VAD and return speech timestamp chunks.

    Each chunk is a dict with 'start' and 'end' keys (sample indices).
    Returns empty list on failure.
    """
    import torch

    model, get_ts = get_silero_vad()
    tensor = (
        audio_data
        if isinstance(audio_data, torch.Tensor)
        else torch.from_numpy(audio_data).float()
    )
    return get_ts(tensor, model, threshold=threshold, sampling_rate=sampling_rate)
