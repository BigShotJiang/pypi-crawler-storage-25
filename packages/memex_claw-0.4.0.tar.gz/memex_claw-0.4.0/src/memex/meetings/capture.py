"""Audio capture — record meeting audio to WAV via sounddevice/soundfile."""

from __future__ import annotations

import logging
import threading
from pathlib import Path
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)


def _require_audio_deps():
    """Lazy check for sounddevice + soundfile."""
    try:
        import sounddevice  # noqa: F401
        import soundfile  # noqa: F401
    except ImportError as exc:
        raise RuntimeError(
            "Audio recording requires sounddevice and soundfile. "
            "Install with: pip install memex-claw[audio]"
        ) from exc


class AudioCapture:
    """Record audio to WAV file using sounddevice/soundfile.

    Writes frames directly to disk via soundfile to keep RAM usage flat
    even for multi-hour meetings.
    """

    def __init__(
        self,
        audio_dir: Path,
        sample_rate: int = 16000,
        device: str | int | None = None,
    ) -> None:
        self._audio_dir = audio_dir
        self._sample_rate = sample_rate
        self._device = device
        self._stream = None
        self._file = None
        self._recording = False
        self._paused = False
        self._audio_path: Path | None = None
        self._lock = threading.Lock()
        self._current_rms: float = 0.0

    @property
    def level(self) -> float:
        """Current audio level (0.0-1.0 normalized RMS)."""
        return self._current_rms

    @property
    def is_recording(self) -> bool:
        return self._recording

    @property
    def is_paused(self) -> bool:
        return self._paused

    def _open_stream(self) -> None:
        import sounddevice as sd
        import numpy as np  # capture in closure, not per-frame import

        def callback(indata, frames, time_info, status):
            if status:
                logger.debug("sounddevice status: %s", status)
            data = indata.copy()
            # Compute RMS outside the file-write lock (read-only on copy)
            rms = float(np.sqrt(np.mean(data.astype(np.float32) ** 2))) / 32768.0
            self._current_rms = min(rms, 1.0)
            with self._lock:
                if self._file is not None:
                    self._file.write(data)

        self._stream = sd.InputStream(
            samplerate=self._sample_rate,
            channels=1,
            dtype="int16",
            callback=callback,
            device=self._device,
        )
        self._stream.start()

    def start(self, meeting_id: str) -> Path:
        """Start recording audio to a WAV file. Returns the file path."""
        _require_audio_deps()
        import soundfile as sf

        if self._recording or self._paused:
            raise RuntimeError("Already recording")

        self._audio_dir.mkdir(parents=True, exist_ok=True)
        timestamp = utcnow().strftime("%Y%m%dT%H%M%S")
        filename = f"{timestamp}_{meeting_id[:8]}.wav"
        self._audio_path = self._audio_dir / filename

        self._file = sf.SoundFile(
            str(self._audio_path),
            mode="w",
            samplerate=self._sample_rate,
            channels=1,
            format="WAV",
            subtype="PCM_16",
        )

        self._open_stream()
        self._recording = True
        self._paused = False
        logger.info("Recording started: %s", self._audio_path)
        return self._audio_path

    def pause(self) -> None:
        """Pause an active recording without finalizing the file."""
        if not self._recording:
            raise RuntimeError("Not recording")

        try:
            if self._stream is not None:
                self._stream.stop()
                self._stream.close()
                self._stream = None
        finally:
            self._recording = False
            self._paused = True
            self._current_rms = 0.0

    def resume(self) -> None:
        """Resume a paused recording."""
        if not self._paused:
            raise RuntimeError("Not paused")
        if self._file is None or self._audio_path is None:
            raise RuntimeError("No paused recording to resume")

        _require_audio_deps()
        self._open_stream()
        self._recording = True
        self._paused = False

    def stop(self) -> tuple[Path, float]:
        """Stop recording. Returns (audio_path, duration_seconds)."""
        if not self._recording and not self._paused:
            raise RuntimeError("Not recording")

        self._recording = False
        self._paused = False

        try:
            if self._stream is not None:
                self._stream.stop()
                self._stream.close()
                self._stream = None
        finally:
            # Ensure file is closed even if stream cleanup fails
            duration = 0.0
            with self._lock:
                if self._file is not None:
                    frames = self._file.tell()
                    duration = frames / self._sample_rate
                    self._file.close()
                    self._file = None

        path = self._audio_path
        if path is None:
            raise RuntimeError("No audio path — recording was not started")
        self._audio_path = None
        logger.info("Recording stopped: %.1fs", duration)
        return path, duration
