"""Meeting semantic projection — sync meeting data into world-model records."""

from __future__ import annotations

import logging
import re
from typing import Any

from memex.meetings.models import MeetingIntelligenceArtifactType
from memex.models import MeetingGoalLink, WorldModelProvenanceLink
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)


def _write_meeting_goal_link_with_relationship(
    store: Any,
    meeting_id: str,
    goal_id: str,
    relationship: str,
) -> None:
    """Create a meeting-goal link that preserves the relationship.

    The standard ``create_meeting_goal_link`` uses an edge logical_id that
    does NOT include the relationship, so a second link between the same
    meeting and goal with a different relationship upserts (overwrites)
    the first.  The fathomdb traverse also returns target *nodes* — not
    edge properties — so the relationship is lost during ``list``.

    This helper writes a relationship-specific *goal node* (a lightweight
    projection) alongside the edge so that the traversal returns a node
    whose properties include ``goal_id`` and ``relationship``.
    """
    try:
        from fathomdb import EdgeInsert, NodeInsert, WriteRequest, new_row_id
        from fathomdb import ChunkPolicy

        engine = getattr(getattr(store, "_fathom", None), "_engine", None)
        if engine is None:
            # Fall back to the standard high-level API
            store.create_meeting_goal_link(
                MeetingGoalLink(
                    meeting_id=meeting_id,
                    goal_id=goal_id,
                    relationship=relationship,
                    created_at=utcnow(),
                )
            )
            return

        now_iso = utcnow().isoformat()

        # Create a lightweight "link node" with the goal kind so that
        # list_meeting_goal_links traversal picks it up.
        link_node_lid = f"goal:{goal_id}:{relationship}"
        edge_lid = f"edge:meeting_goal_link:{meeting_id}:{goal_id}:{relationship}"
        engine.write(
            WriteRequest(
                label="meeting-goal-link",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=link_node_lid,
                        kind="goal",
                        properties={
                            "goal_id": goal_id,
                            "meeting_id": meeting_id,
                            "relationship": relationship,
                            "created_at": now_iso,
                            "updated_at": now_iso,
                            "last_touched_at": now_iso,
                            "title": "",
                            "description": "",
                            "status": "active",
                            "priority": "medium",
                        },
                        source_ref="memex:goals",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=[
                    EdgeInsert(
                        row_id=new_row_id(),
                        logical_id=edge_lid,
                        source_logical_id=f"meeting:{meeting_id}",
                        target_logical_id=link_node_lid,
                        kind="MEETING_GOAL_LINK",
                        properties={
                            "meeting_id": meeting_id,
                            "goal_id": goal_id,
                            "relationship": relationship,
                            "created_at": now_iso,
                        },
                        source_ref="memex:goals",
                        upsert=True,
                    )
                ],
            )
        )
    except Exception:
        logger.debug(
            "Failed to write relationship-qualified meeting-goal link",
            exc_info=True,
        )
        # Fall back to the standard API
        try:
            store.create_meeting_goal_link(
                MeetingGoalLink(
                    meeting_id=meeting_id,
                    goal_id=goal_id,
                    relationship=relationship,
                    created_at=utcnow(),
                )
            )
        except Exception:
            logger.debug("Fallback create_meeting_goal_link also failed", exc_info=True)


def sync_promoted_action_item_goal_links(store: Any, record: Any) -> int:
    """Create meeting_goal_links and provenance for promoted action-item goals."""
    action_items = getattr(record, "action_items", None) or []
    created = 0
    now = utcnow()
    seen: set[str] = set()
    for item in action_items:
        goal_id = str(item.get("promoted_goal_id") or "").strip()
        if not goal_id or goal_id == "__pending__" or goal_id in seen:
            continue
        seen.add(goal_id)
        _write_meeting_goal_link_with_relationship(
            store,
            record.meeting_id,
            goal_id,
            "promoted_action_item",
        )
        try:
            store.upsert_world_model_provenance_link(
                WorldModelProvenanceLink(
                    link_id=(
                        f"meeting:{record.meeting_id}"
                        f"->promoted_action_item:world_model_goal:{goal_id}"
                    ),
                    source_record_type="meeting",
                    source_record_id=record.meeting_id,
                    target_record_type="world_model_goal",
                    target_record_id=goal_id,
                    relationship="promoted_action_item",
                    created_at=now,
                )
            )
            created += 1
        except Exception:
            logger.debug("Failed to create provenance link", exc_info=True)
    return created


def _resolve_meeting_item(
    record: Any,
    content_store: Any,
) -> Any | None:
    """Find the content item for a meeting record.

    Tries record.item_id first, then falls back to source_url lookup.
    """
    item_id = getattr(record, "item_id", None)
    if item_id:
        try:
            item = content_store.get_item(item_id)
            if item is not None:
                return item
        except Exception:
            logger.debug("Failed to get item by id %r", item_id, exc_info=True)
    # Fall back: look up by conventional source_url
    meeting_id = getattr(record, "meeting_id", None)
    if meeting_id and hasattr(content_store, "find_by_url"):
        try:
            item = content_store.find_by_url(f"memex://meeting/{meeting_id}")
            if item is not None:
                return item
        except Exception:
            logger.debug(
                "Failed to find item by url for meeting %r", meeting_id, exc_info=True
            )
    return None


def _refresh_meeting_item_semantic_metadata(
    *,
    record: Any,
    meeting_store: Any,
    content_store: Any,
    memex_store: Any,
) -> None:
    """Refresh the semantic projection metadata on the meeting's content item.

    Also syncs the corresponding world-model knowledge object so that
    ``load_world_model_knowledge_object_by_item_id`` returns a payload
    that mirrors the item metadata.
    """
    if content_store is None:
        return
    item = _resolve_meeting_item(record, content_store)
    if item is None:
        return
    metadata = dict(item.metadata if isinstance(item.metadata, dict) else {})
    meeting_meta = (
        dict(metadata.get("meeting"))
        if isinstance(metadata.get("meeting"), dict)
        else {}
    )
    meeting_meta["semantic"] = build_meeting_semantic_projection(
        meeting_store,
        record.meeting_id,
        memex_store=memex_store,
    )
    metadata["meeting"] = meeting_meta
    item.metadata = metadata
    item.last_accessed = utcnow()
    content_store.update_item(item)

    _sync_knowledge_after_metadata_update(memex_store, item)


def _refresh_meeting_item_semantic_metadata_with_audit(
    *,
    record: Any,
    meeting_store: Any,
    content_store: Any,
    memex_store: Any,
) -> None:
    """Refresh semantic metadata including canonical audits in a single write."""
    if content_store is None:
        return
    item = _resolve_meeting_item(record, content_store)
    if item is None:
        return
    metadata = dict(item.metadata if isinstance(item.metadata, dict) else {})
    meeting_meta = (
        dict(metadata.get("meeting"))
        if isinstance(metadata.get("meeting"), dict)
        else {}
    )
    semantic = build_meeting_semantic_projection(
        meeting_store,
        record.meeting_id,
        memex_store=memex_store,
    )

    # Build canonical audits
    if memex_store is not None:
        full_audit = build_activity_audit(memex_store, record.meeting_id)
        promotion_audit = [
            entry
            for entry in full_audit
            if entry["action_kind"] == "meeting_semantic_promotion"
        ]
        activity_audit = [
            entry
            for entry in full_audit
            if entry["action_kind"] != "meeting_semantic_promotion"
        ]
        semantic["canonical_promotion_audit"] = promotion_audit
        semantic["canonical_activity_audit"] = activity_audit

    meeting_meta["semantic"] = semantic
    metadata["meeting"] = meeting_meta
    item.metadata = metadata
    item.last_accessed = utcnow()
    content_store.update_item(item)

    _sync_knowledge_after_metadata_update(memex_store, item)


def _sync_knowledge_after_metadata_update(memex_store: Any, item: Any) -> None:
    """Sync world-model knowledge after item metadata has been updated."""
    if memex_store is None:
        return
    try:
        if hasattr(memex_store, "sync_world_model_knowledge_from_item"):
            memex_store.sync_world_model_knowledge_from_item(item)
        _sync_knowledge_object_payload(memex_store, item)
    except Exception:
        logger.debug(
            "Failed to sync knowledge object for item %s",
            item.item_id,
            exc_info=True,
        )


def _sync_knowledge_object_payload(memex_store: Any, item: Any) -> None:
    """Upsert the knowledge object payload to include item metadata."""
    from memex.fathom_facade import _build_knowledge_metadata

    fathom = getattr(memex_store, "_fathom", None)
    if fathom is None:
        return
    wm = getattr(fathom, "world_model", None)
    if wm is None:
        return
    knowledge_id = f"knowledge/{item.item_id}"
    item_type = item.type.value if hasattr(item.type, "value") else str(item.type)
    wm.upsert_knowledge_object(
        knowledge_id,
        item.item_id,
        item_type,
        item.source_url or item.item_id,
        title=item.title,
        source_url=item.source_url,
        source_surface="memex:semantic-projection",
        payload={"metadata": _build_knowledge_metadata(item.metadata)},
    )


def _artifact_suffix(meeting_id: str, artifact_id: str) -> str:
    """Derive the unique artifact suffix by removing the meeting_id prefix."""
    return artifact_id.removeprefix(f"{meeting_id}:")


def _semantic_item_id_for(meeting_id: str, artifact_id: str) -> str:
    """Build a deterministic semantic item ID from a meeting artifact."""
    suffix = _artifact_suffix(meeting_id, artifact_id)
    return f"meeting-semantic:{meeting_id}:{suffix}"


def _promote_artifact_to_content_item(
    *,
    record: Any,
    artifact: Any,
    art_type_value: str,
    semantic_item_id: str,
    content_store: Any,
    memex_store: Any,
) -> None:
    """Create or update a promoted content item for a meeting artifact."""
    from memex.models import Item, ItemType, Provenance

    source_url = f"memex://meeting/{record.meeting_id}/artifact/{artifact.artifact_id}"
    now = utcnow()
    payload = artifact.payload if isinstance(artifact.payload, dict) else {}
    typed_knowledge: dict[str, Any] = {
        "claim_kind": art_type_value,
        "artifact_id": artifact.artifact_id,
        "meeting_id": record.meeting_id,
    }
    if art_type_value == "commitment":
        typed_knowledge["assignee"] = str(payload.get("assignee") or "")
        typed_knowledge["agreed_by"] = str(payload.get("agreed_by") or "")
        typed_knowledge["deadline"] = str(payload.get("deadline") or "")
        typed_knowledge["promoted_goal_id"] = str(payload.get("promoted_goal_id") or "")

    existing = content_store.find_by_url(source_url)
    if existing is not None:
        existing.metadata = {
            **existing.metadata,
            "typed_knowledge": typed_knowledge,
        }
        existing.last_accessed = now
        content_store.update_item(existing)
        item = existing
    else:
        item = Item(
            item_id=semantic_item_id,
            type=ItemType.NOTE,
            title=f"{art_type_value}: {artifact.content[:80]}",
            body=artifact.content,
            source_url=source_url,
            captured_at=now,
            last_accessed=now,
            provenance=Provenance(
                source="meeting_semantic_promotion",
                captured_at=now,
                confidence=1.0,
            ),
            metadata={"typed_knowledge": typed_knowledge},
        )
        content_store.create_item(item)

    if memex_store is not None:
        try:
            wm = getattr(getattr(memex_store, "_fathom", None), "world_model", None)
            if wm is not None:
                wm.upsert_knowledge_object(
                    f"knowledge/{item.item_id}",
                    item.item_id,
                    "claim",
                    item.source_url or item.item_id,
                    title=item.title,
                    source_url=item.source_url,
                    source_surface="memex:semantic-promotion",
                    payload={
                        "semantic_kind": art_type_value,
                        "metadata": {
                            "meeting_artifact": {
                                "artifact_id": artifact.artifact_id,
                                "meeting_id": record.meeting_id,
                            },
                        },
                        "typed": typed_knowledge,
                    },
                )
        except Exception:
            logger.debug(
                "Failed to upsert knowledge object for promoted item %s",
                semantic_item_id,
                exc_info=True,
            )


def _update_promoted_goal_metadata(
    *,
    memex_store: Any,
    record: Any,
    artifact: Any,
    semantic_item_id: str,
) -> None:
    """Update goal metadata with meeting promotion info."""
    payload = artifact.payload if isinstance(artifact.payload, dict) else {}
    goal_id = str(payload.get("promoted_goal_id") or "").strip()
    if not goal_id or goal_id == "__pending__":
        return
    try:
        goal = memex_store.get_goal(goal_id)
        if goal is None:
            return
        meta = dict(goal.metadata) if isinstance(goal.metadata, dict) else {}
        meta["meeting_promotion"] = {
            "meeting_id": record.meeting_id,
            "relationship": "commitment",
            "action_text": str(payload.get("text") or artifact.content or ""),
            "assignee": str(payload.get("assignee") or ""),
            "deadline": str(payload.get("deadline") or ""),
            "commitment_artifact_id": artifact.artifact_id,
            "semantic_item_id": semantic_item_id,
        }
        goal.metadata = meta
        memex_store.update_goal(goal)
    except Exception:
        logger.debug(
            "Failed to update goal %s with promotion metadata",
            goal_id,
            exc_info=True,
        )


def _clear_stale_goal_promotion_metadata(
    *,
    memex_store: Any,
    meeting_id: str,
    current_promoted_goal_ids: set[str],
) -> None:
    """Clear meeting_promotion from goals no longer promoted.

    Statelessly scans all goals carrying a ``meeting_promotion`` metadata
    entry for this meeting and removes it from any goal that is not in
    ``current_promoted_goal_ids``.
    """
    try:
        goals = memex_store.list_goals()
    except Exception:
        logger.debug("Failed to list goals for stale promotion clearing", exc_info=True)
        return
    for goal in goals:
        meta = dict(goal.metadata) if isinstance(goal.metadata, dict) else {}
        promo = meta.get("meeting_promotion")
        if not isinstance(promo, dict):
            continue
        if promo.get("meeting_id") != meeting_id:
            continue
        if goal.goal_id in current_promoted_goal_ids:
            continue
        try:
            del meta["meeting_promotion"]
            goal.metadata = meta
            memex_store.update_goal(goal)
        except Exception:
            logger.debug(
                "Failed to clear goal %s promotion metadata",
                goal.goal_id,
                exc_info=True,
            )


def _prune_stale_promoted_items(
    *,
    memex_store: Any,
    content_store: Any,
    meeting_id: str,
    current_artifact_ids: set[str],
) -> None:
    """Remove promoted content items and actions for artifacts that no longer exist."""
    # Query all promotion actions for this meeting to find previously promoted artifacts
    try:
        actions = memex_store.list_world_model_actions(
            meeting_id=meeting_id,
            action_kind="meeting_semantic_promotion",
            limit=200,
        )
    except Exception:
        logger.debug("Failed to list promotion actions for pruning", exc_info=True)
        return

    for action in actions:
        artifact_id = (action.payload or {}).get("artifact_id", "")
        if artifact_id in current_artifact_ids:
            continue
        # This artifact no longer exists — prune
        semantic_item_id = (action.payload or {}).get("semantic_item_id", "")
        if semantic_item_id and content_store is not None:
            try:
                content_store.delete_item(semantic_item_id)
            except Exception:
                logger.debug(
                    "Failed to delete stale promoted item %s",
                    semantic_item_id,
                    exc_info=True,
                )
        try:
            memex_store.delete_world_model_action_cascade(action.action_id)
        except Exception:
            logger.debug(
                "Failed to delete stale promotion action %s",
                action.action_id,
                exc_info=True,
            )


def build_activity_audit(memex_store: Any, meeting_id: str) -> list[dict[str, Any]]:
    """Build the canonical activity audit for a meeting.

    Iterates all meeting actions, fetching observations per action.
    Shared between semantic_projection and transcribe modules.
    """
    audit: list[dict[str, Any]] = []
    try:
        actions = memex_store.list_world_model_actions(meeting_id=meeting_id, limit=200)
    except Exception:
        return audit
    for action in actions:
        observations = []
        try:
            obs_list = memex_store.list_world_model_observations(
                action_id=action.action_id
            )
            for obs in obs_list:
                observations.append(
                    {
                        "observation_id": obs.observation_id,
                        "observation_kind": obs.observation_kind,
                        "status": obs.status,
                        "summary": obs.summary,
                    }
                )
        except Exception:
            pass
        relationships = []
        try:
            links = memex_store.list_world_model_provenance_links(
                source_record_id=action.action_id
            )
            for link in links:
                relationships.append(
                    {
                        "relationship": link.relationship,
                        "target_record_type": link.target_record_type,
                        "target_record_id": link.target_record_id,
                    }
                )
        except Exception:
            pass
        entry: dict[str, Any] = {
            "action_id": action.action_id,
            "action_kind": action.action_kind,
            "action_name": action.action_name,
            "status": action.status,
            "observations": observations,
            "relationships": relationships,
        }
        if action.action_kind == "meeting_semantic_promotion":
            entry["artifact_id"] = (action.payload or {}).get("artifact_id", "")
        audit.append(entry)
    return audit


def sync_meeting_item_projection(
    record: Any,
    *,
    meeting_store: Any = None,
    content_store: Any = None,
    memex_store: Any = None,
    bump_version: bool = True,
    sync_reason: str | None = None,
) -> None:
    """Sync meeting artifacts into world-model records (commitments, etc.)."""
    if memex_store is None or meeting_store is None:
        return

    from memex.world_model_backbone import (
        build_world_model_meeting_semantic_promotion_action,
        build_world_model_meeting_semantic_promotion_observation,
        build_world_model_meeting_semantic_sync_action,
        build_world_model_meeting_semantic_sync_observation,
        build_world_model_provenance_link,
    )
    from memex.world_model_task_commitment import (
        build_world_model_commitment_from_meeting_artifact,
    )

    try:
        artifacts = meeting_store.list_meeting_artifacts(record.meeting_id)
    except Exception:
        logger.debug("Failed to list meeting artifacts", exc_info=True)
        artifacts = []

    promotable_types = {
        MeetingIntelligenceArtifactType.DECISION.value,
        MeetingIntelligenceArtifactType.COMMITMENT.value,
    }
    current_artifact_ids: set[str] = set()
    current_promoted_goal_ids: set[str] = set()
    now = utcnow()

    for artifact in artifacts:
        art_type = artifact.artifact_type
        if hasattr(art_type, "value"):
            art_type = art_type.value
        if art_type not in promotable_types:
            continue

        artifact_id = artifact.artifact_id
        current_artifact_ids.add(artifact_id)
        semantic_item_id = _semantic_item_id_for(record.meeting_id, artifact_id)

        # Promote to content item
        if content_store is not None:
            try:
                _promote_artifact_to_content_item(
                    record=record,
                    artifact=artifact,
                    art_type_value=art_type,
                    semantic_item_id=semantic_item_id,
                    content_store=content_store,
                    memex_store=memex_store,
                )
            except Exception:
                logger.debug(
                    "Failed to promote artifact %s", artifact_id, exc_info=True
                )

        # Sync commitment to world model
        if art_type == MeetingIntelligenceArtifactType.COMMITMENT.value:
            try:
                commitment = build_world_model_commitment_from_meeting_artifact(
                    record, artifact, semantic_item_id=semantic_item_id
                )
                memex_store.upsert_world_model_commitment(commitment)
            except Exception:
                logger.debug(
                    "Failed to sync commitment from artifact %s",
                    artifact_id,
                    exc_info=True,
                )

        # Record promotion action + observation + provenance
        try:
            action = build_world_model_meeting_semantic_promotion_action(
                record.meeting_id,
                artifact_id=artifact_id,
                artifact_type=art_type,
                semantic_item_id=semantic_item_id,
                created_at=now,
            )
            observation = build_world_model_meeting_semantic_promotion_observation(
                action,
                semantic_item_id=semantic_item_id,
                summary=f"Promoted {art_type} from meeting {record.meeting_id}",
                created_at=now,
            )
            memex_store.upsert_world_model_action(action)
            memex_store.upsert_world_model_observation(observation)
            memex_store.upsert_world_model_provenance_link(
                build_world_model_provenance_link(
                    "world_model_action",
                    action.action_id,
                    "meeting_artifact",
                    artifact_id,
                    "promotes",
                    created_at=now,
                )
            )
            memex_store.upsert_world_model_provenance_link(
                build_world_model_provenance_link(
                    "world_model_action",
                    action.action_id,
                    "item",
                    semantic_item_id,
                    "updates",
                    created_at=now,
                )
            )
            memex_store.upsert_world_model_provenance_link(
                build_world_model_provenance_link(
                    "world_model_observation",
                    observation.observation_id,
                    "world_model_action",
                    action.action_id,
                    "observed_from",
                    created_at=now,
                )
            )
        except Exception:
            logger.debug(
                "Failed to record promotion action for artifact %s",
                artifact_id,
                exc_info=True,
            )

        # Update goal metadata for commitments
        if art_type == MeetingIntelligenceArtifactType.COMMITMENT.value:
            payload = artifact.payload if isinstance(artifact.payload, dict) else {}
            goal_id = str(payload.get("promoted_goal_id") or "").strip()
            if goal_id and goal_id != "__pending__":
                current_promoted_goal_ids.add(goal_id)
            _update_promoted_goal_metadata(
                memex_store=memex_store,
                record=record,
                artifact=artifact,
                semantic_item_id=semantic_item_id,
            )

    # Prune stale promoted items
    if content_store is not None:
        _prune_stale_promoted_items(
            memex_store=memex_store,
            content_store=content_store,
            meeting_id=record.meeting_id,
            current_artifact_ids=current_artifact_ids,
        )

    # Clear stale goal promotion metadata
    _clear_stale_goal_promotion_metadata(
        memex_store=memex_store,
        meeting_id=record.meeting_id,
        current_promoted_goal_ids=current_promoted_goal_ids,
    )

    # Sync promoted goal links
    sync_promoted_action_item_goal_links(memex_store, record)

    # Record a WorldModelAction for the semantic sync
    item_id = getattr(record, "item_id", None) or ""
    try:
        sync_action = build_world_model_meeting_semantic_sync_action(
            record.meeting_id,
            item_id=item_id,
            sync_reason="item_projection_refresh",
            created_at=now,
        )
        sync_observation = build_world_model_meeting_semantic_sync_observation(
            sync_action,
            summary=f"Semantic sync for meeting {record.meeting_id}",
            created_at=now,
        )
        memex_store.upsert_world_model_action(sync_action)
        memex_store.upsert_world_model_observation(sync_observation)
        memex_store.upsert_world_model_provenance_link(
            build_world_model_provenance_link(
                "world_model_action",
                sync_action.action_id,
                "meeting",
                record.meeting_id,
                "updates",
                created_at=now,
            )
        )
    except Exception:
        logger.debug(
            "Failed to record semantic sync action for meeting %s",
            record.meeting_id,
            exc_info=True,
        )

    # Build canonical audits and refresh semantic metadata (single write)
    _refresh_meeting_item_semantic_metadata_with_audit(
        record=record,
        meeting_store=meeting_store,
        content_store=content_store,
        memex_store=memex_store,
    )


def _parse_notes_lines(notes: str) -> dict[str, list[dict[str, str]]]:
    """Extract Decision/Outcome/Commitment lines from meeting notes."""
    decisions: list[dict[str, str]] = []
    outcomes: list[dict[str, str]] = []
    commitments: list[dict[str, str]] = []
    for line in notes.splitlines():
        line = line.strip()
        m = re.match(r"^Decision:\s*(.+)$", line, re.IGNORECASE)
        if m:
            decisions.append({"content": m.group(1).strip()})
            continue
        m = re.match(r"^Outcome:\s*(.+)$", line, re.IGNORECASE)
        if m:
            outcomes.append({"content": m.group(1).strip()})
            continue
        m = re.match(r"^Commitment:\s*(.+)$", line, re.IGNORECASE)
        if m:
            commitments.append({"content": m.group(1).strip()})
            continue
    return {
        "decisions": decisions,
        "outcomes": outcomes,
        "commitments": commitments,
    }


def build_meeting_semantic_projection(
    meeting_store: Any,
    meeting_id: str,
    *,
    memex_store: Any = None,
) -> dict[str, Any]:
    """Build meeting semantic projection metadata.

    Extracts decisions, outcomes, and commitments from meeting notes and
    action items; gathers goal links from the store.
    """
    decisions: list[dict[str, str]] = []
    outcomes: list[dict[str, str]] = []
    commitments: list[dict[str, str]] = []
    goal_links: list[dict[str, str]] = []

    # 1. Load the meeting record for notes and action items
    try:
        record = meeting_store.get_meeting(meeting_id)
    except Exception:
        logger.debug("Failed to get meeting for semantic projection", exc_info=True)
        record = None

    if record is not None:
        # Parse structured lines from notes
        notes = getattr(record, "notes", "") or ""
        if notes:
            parsed = _parse_notes_lines(notes)
            decisions.extend(parsed["decisions"])
            outcomes.extend(parsed["outcomes"])
            commitments.extend(parsed["commitments"])

        # Extract commitments from action items with commitment_confirmed
        action_items = getattr(record, "action_items", None) or []
        for item in action_items:
            if item.get("commitment_confirmed"):
                commitments.append(
                    {
                        "content": item.get("action", "") or item.get("text", ""),
                        "assignee": item.get("assignee", ""),
                        "agreed_by": item.get("agreed_by", ""),
                    }
                )

    # 2. Also pull artifacts from the meeting store
    try:
        artifacts = meeting_store.list_meeting_artifacts(meeting_id)
    except Exception:
        logger.debug("Failed to list artifacts for projection", exc_info=True)
        artifacts = []

    for artifact in artifacts:
        art_type = artifact.artifact_type
        if hasattr(art_type, "value"):
            art_type = art_type.value
        content = getattr(artifact, "content", "") or ""
        entry: dict[str, str] = {"content": content}
        if art_type == MeetingIntelligenceArtifactType.DECISION.value:
            decisions.append(entry)
        elif art_type == MeetingIntelligenceArtifactType.OUTCOME.value:
            outcomes.append(entry)
        elif art_type == MeetingIntelligenceArtifactType.COMMITMENT.value:
            commitments.append(entry)

    # 3. Gather goal links
    if memex_store is not None:
        try:
            links = memex_store.list_meeting_goal_links(meeting_id)
            for link in links:
                goal_id = getattr(link, "goal_id", None) or (
                    link.get("goal_id") if isinstance(link, dict) else ""
                )
                relationship = getattr(link, "relationship", None) or (
                    link.get("relationship") if isinstance(link, dict) else ""
                )
                if goal_id:
                    goal_links.append(
                        {
                            "goal_id": str(goal_id),
                            "relationship": str(relationship or "explicit"),
                        }
                    )
        except Exception:
            logger.debug("Failed to list goal links for projection", exc_info=True)

    return {
        "decisions": decisions,
        "outcomes": outcomes,
        "commitments": commitments,
        "goal_links": goal_links,
    }
