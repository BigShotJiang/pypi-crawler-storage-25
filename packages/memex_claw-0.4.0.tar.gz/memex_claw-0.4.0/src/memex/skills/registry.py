"""Skill registry — holds loaded skills and provides lookup."""

from __future__ import annotations

from memex.skills.loader import SkillDefinition


class SkillRegistry:
    """Manages registered skills and provides filtering."""

    def __init__(self) -> None:
        self._skills: dict[str, SkillDefinition] = {}

    def register(self, skill: SkillDefinition) -> None:
        """Register a skill by name."""
        self._skills[skill.name] = skill

    def unregister(self, name: str) -> bool:
        """Remove a skill by name. Returns True if it existed."""
        return self._skills.pop(name, None) is not None

    def get_skill(self, name: str) -> SkillDefinition | None:
        """Look up a skill by name."""
        return self._skills.get(name)

    def all_skills(self) -> list[SkillDefinition]:
        """Return all registered skills."""
        return list(self._skills.values())

    def get_prompt_candidates(self) -> list[SkillDefinition]:
        """Return skills eligible for system prompt injection.

        Excludes skills with disable_model_invocation=True.
        """
        return [s for s in self._skills.values() if not s.disable_model_invocation]

    def get_slash_commands(self) -> dict[str, SkillDefinition]:
        """Return user-invocable skills as a name→skill mapping."""
        return {s.name: s for s in self._skills.values() if s.user_invocable}
