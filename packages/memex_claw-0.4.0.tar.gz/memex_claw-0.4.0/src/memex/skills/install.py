"""Skill installation logic — clawdbot detection, OpenClaw search, comparison.

Extracts the install decision flow from the TUI so it can be tested
independently and reused across interfaces (TUI, CLI, programmatic).
"""

from __future__ import annotations

import difflib
import logging
import re
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any

logger = logging.getLogger(__name__)

# Known legacy metadata namespace keys that preceded 'openclaw'.
_LEGACY_NAMESPACES = {"clawdbot", "clawbot"}

# OpenClaw community skills repo on GitHub.
_OPENCLAW_SKILLS_REPO = "openclaw/skills"
_OPENCLAW_SKILLS_BRANCH = "main"


class SkillOrigin(Enum):
    """Which metadata namespace the skill uses."""

    OPENCLAW = auto()
    CLAWDBOT = auto()
    UNKNOWN = auto()


class InstallAction(Enum):
    """What the caller should do next."""

    PROCEED = auto()  # Install the skill as-is
    PROCEED_OPENCLAW = auto()  # Install the OpenClaw version instead
    CHOOSE = auto()  # Present choices to the user
    PROCEED_CLAWDBOT_ONLY = auto()  # No OpenClaw version found; install legacy


@dataclass
class SkillComparison:
    """Result of comparing a clawdbot skill to an OpenClaw candidate."""

    openclaw_content: str
    openclaw_url: str
    similarity: float  # 0.0–1.0


@dataclass
class InstallEvaluation:
    """Result of evaluating a skill for installation."""

    origin: SkillOrigin
    action: InstallAction
    skill_name: str
    clawdbot_content: str | None = None
    comparison: SkillComparison | None = None
    message: str = ""


def detect_origin(content: str) -> SkillOrigin:
    """Detect whether a SKILL.md uses openclaw or clawdbot metadata.

    Checks the YAML frontmatter ``metadata`` field for known namespace keys.
    """
    # Extract frontmatter
    fm_match = re.match(r"^---\s*\n(.*?)\n---", content, re.DOTALL)
    if not fm_match:
        return SkillOrigin.UNKNOWN

    fm_text = fm_match.group(1)

    # Check for legacy namespaces first (clawdbot, clawbot)
    # Matches JSON-style {"clawdbot": ...} and YAML-style clawdbot:
    for ns in _LEGACY_NAMESPACES:
        if re.search(rf'["\']?{ns}["\']?\s*[:\{{]', fm_text, re.IGNORECASE):
            return SkillOrigin.CLAWDBOT

    # Check for openclaw namespace
    if re.search(r'["\']?openclaw["\']?\s*[:\{]', fm_text, re.IGNORECASE):
        return SkillOrigin.OPENCLAW

    return SkillOrigin.UNKNOWN


def compute_similarity(content_a: str, content_b: str) -> float:
    """Compute similarity ratio between two SKILL.md files.

    Compares the body text (after frontmatter) using SequenceMatcher.
    Returns a float between 0.0 and 1.0.
    """
    body_a = _extract_body(content_a)
    body_b = _extract_body(content_b)
    return difflib.SequenceMatcher(None, body_a, body_b).ratio()


def _extract_body(content: str) -> str:
    """Extract the body (post-frontmatter) from a SKILL.md file."""
    fm_match = re.match(r"^---\s*\n.*?\n---\s*\n(.*)", content, re.DOTALL)
    if fm_match:
        return fm_match.group(1).strip()
    return content.strip()


def search_openclaw_version(
    skill_name: str,
    *,
    _fetch: Any | None = None,
) -> tuple[str | None, str | None]:
    """Search the OpenClaw community skills repo for a matching skill.

    Tries the GitHub API to find SKILL.md files in directories matching
    ``skill_name``. Returns ``(content, url)`` or ``(None, None)``.

    The ``_fetch`` parameter allows dependency injection for testing.
    """
    import json

    fetch = _fetch or _default_fetch

    # Strategy 1: GitHub search API (code search for the skill name)
    search_url = (
        f"https://api.github.com/search/code"
        f"?q=filename:SKILL.md+path:{_quote(skill_name)}"
        f"+repo:{_OPENCLAW_SKILLS_REPO}"
    )
    try:
        search_body = fetch(search_url)
        if search_body:
            results = json.loads(search_body)
            items = results.get("items", [])
            for item in items:
                path = item.get("path", "")
                # Match any SKILL.md in a directory named after the skill
                if f"/{skill_name}/SKILL.md" in path or path.endswith(
                    f"{skill_name}/SKILL.md"
                ):
                    raw_url = _raw_url_for_path(path)
                    raw_content = fetch(raw_url)
                    if (
                        raw_content
                        and detect_origin(raw_content) == SkillOrigin.OPENCLAW
                    ):
                        return raw_content, raw_url
    except Exception:
        logger.debug("GitHub search API failed", exc_info=True)

    # Strategy 2: Try repo contents API to list the skills/ directory
    try:
        contents_url = (
            f"https://api.github.com/repos/{_OPENCLAW_SKILLS_REPO}"
            f"/contents/skills?ref={_OPENCLAW_SKILLS_BRANCH}"
        )
        contents_body = fetch(contents_url)
        if contents_body:
            entries = json.loads(contents_body)
            # entries is a list of {name, path, type} for top-level authors
            for author_entry in entries:
                if author_entry.get("type") != "dir":
                    continue
                # Check if this author has the skill we're looking for
                skill_path = f"skills/{author_entry['name']}/{skill_name}/SKILL.md"
                raw_url = _raw_url_for_path(skill_path)
                raw_content = fetch(raw_url)
                if raw_content and detect_origin(raw_content) == SkillOrigin.OPENCLAW:
                    return raw_content, raw_url
    except Exception:
        logger.debug("GitHub contents API failed", exc_info=True)

    return None, None


def evaluate_skill(
    content: str,
    skill_name: str,
    *,
    _fetch: Any | None = None,
) -> InstallEvaluation:
    """Evaluate a skill for installation, checking for clawdbot/openclaw issues.

    If the skill uses the ``openclaw`` metadata namespace (or has no
    metadata namespace), returns PROCEED immediately.

    If the skill uses a legacy ``clawdbot``/``clawbot`` namespace:
    1. Searches the OpenClaw repo for an equivalent skill.
    2. If found and >= 90% similar → PROCEED_OPENCLAW (use the openclaw version).
    3. If found but < 90% similar → CHOOSE (let the user decide).
    4. If not found → PROCEED_CLAWDBOT_ONLY (install legacy with warning).
    """
    origin = detect_origin(content)

    if origin != SkillOrigin.CLAWDBOT:
        return InstallEvaluation(
            origin=origin,
            action=InstallAction.PROCEED,
            skill_name=skill_name,
        )

    # Legacy skill detected — search for OpenClaw version
    oc_content, oc_url = search_openclaw_version(skill_name, _fetch=_fetch)

    if oc_content is None:
        return InstallEvaluation(
            origin=SkillOrigin.CLAWDBOT,
            action=InstallAction.PROCEED_CLAWDBOT_ONLY,
            skill_name=skill_name,
            clawdbot_content=content,
            message=(
                f"This is a legacy Clawdbot skill. "
                f"No OpenClaw version of '{skill_name}' was found in the "
                f"community repository. Installing the Clawdbot version."
            ),
        )

    similarity = compute_similarity(content, oc_content)
    comparison = SkillComparison(
        openclaw_content=oc_content,
        openclaw_url=oc_url,
        similarity=similarity,
    )

    if similarity >= 0.9:
        return InstallEvaluation(
            origin=SkillOrigin.CLAWDBOT,
            action=InstallAction.PROCEED_OPENCLAW,
            skill_name=skill_name,
            clawdbot_content=content,
            comparison=comparison,
            message=(
                f"This is a legacy Clawdbot skill. An OpenClaw version was "
                f"found that is {similarity:.0%} identical. "
                f"Installing the OpenClaw version."
            ),
        )

    return InstallEvaluation(
        origin=SkillOrigin.CLAWDBOT,
        action=InstallAction.CHOOSE,
        skill_name=skill_name,
        clawdbot_content=content,
        comparison=comparison,
        message=(
            f"This is a legacy Clawdbot skill. An OpenClaw version was "
            f"found but is only {similarity:.0%} similar.\n"
            f"Options:\n"
            f"  /skill install --clawdbot   — install the Clawdbot version\n"
            f"  /skill install --openclaw   — install the OpenClaw version\n"
            f"  /skill install --cancel     — do not install either"
        ),
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _quote(text: str) -> str:
    """URL-encode a string for query parameters."""
    import urllib.parse

    return urllib.parse.quote(text, safe="")


def _raw_url_for_path(repo_path: str) -> str:
    """Convert a repo-relative path to a raw.githubusercontent.com URL."""
    return (
        f"https://raw.githubusercontent.com/{_OPENCLAW_SKILLS_REPO}"
        f"/{_OPENCLAW_SKILLS_BRANCH}/{repo_path}"
    )


def _default_fetch(url: str) -> str | None:
    """Fetch a URL using urllib. Returns body text or None on failure."""
    import urllib.request

    try:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "memex",
                "Accept": "application/vnd.github.v3+json",
            },
        )
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 — hardcoded GitHub API URL
            return resp.read().decode("utf-8")
    except Exception:
        logger.debug("Fetch failed: %s", url, exc_info=True)
        return None
