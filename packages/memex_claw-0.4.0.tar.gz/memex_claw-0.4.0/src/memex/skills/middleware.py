"""Skill middleware — prompt injection and tool gating for loaded skills."""

from __future__ import annotations

import logging
import os
from typing import Any

from memex.middleware import TurnMiddleware
from memex.models import SessionContext
from memex.skills.loader import SkillDefinition
from memex.skills.registry import SkillRegistry
from memex.tools import ToolRegistry

logger = logging.getLogger(__name__)


class SkillMiddleware(TurnMiddleware):
    """Injects skill instructions into prompts and enforces allowed-tools."""

    def __init__(
        self,
        skill_registry: SkillRegistry,
        tool_registry: ToolRegistry,
        max_count: int | None = None,
        max_tokens: int | None = None,
    ) -> None:
        self._skills = skill_registry
        self._tools = tool_registry
        self._max_count = (
            max_count
            if max_count is not None
            else int(os.environ.get("MEMEX_MAX_SKILL_COUNT", "10"))
        )
        self._max_tokens = (
            max_tokens
            if max_tokens is not None
            else int(os.environ.get("MEMEX_MAX_SKILL_TOKENS", "4000"))
        )

    def get_skill_block(
        self,
        user_input: str = "",
        active_goals: list[str] | None = None,
    ) -> str:
        """Build skill instruction block for prefix_parts (cached path).

        Selects skills by relevance within budget constraints.
        """
        goals = active_goals or []
        candidates = self._skills.get_prompt_candidates()
        if not candidates:
            return ""

        scored = [(self._score_skill(s, user_input, goals), s) for s in candidates]
        scored.sort(key=lambda x: x[0], reverse=True)

        selected: list[str] = []
        token_count = 0
        for _score, skill in scored[: self._max_count]:
            skill_text = f"## Skill: {skill.name}\n\n{skill.body}"
            skill_tokens = self._estimate_tokens(skill_text)
            if token_count + skill_tokens > self._max_tokens:
                continue
            selected.append(skill_text)
            token_count += skill_tokens

        if not selected:
            return ""
        return "# Active Skills\n\n" + "\n\n---\n\n".join(selected)

    def before_tool_call(
        self,
        session: SessionContext,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> tuple[dict[str, Any], bool]:
        """Enforce allowed-tools and apply parameter shims."""
        # Apply parameter translation for OpenClaw tool names
        from memex.skills.param_shims import PARAM_TRANSLATORS

        if tool_name in PARAM_TRANSLATORS:
            arguments = PARAM_TRANSLATORS[tool_name](arguments)

        # Enforce allowed-tools restriction for active skill
        active_skill: SkillDefinition | None = getattr(session, "_active_skill", None)
        if active_skill and active_skill.allowed_tools is not None:
            canonical = self._tools.resolve_alias(tool_name)
            if canonical not in active_skill.allowed_tools:
                return arguments, True  # blocked
        return arguments, False

    @staticmethod
    def _estimate_tokens(text: str) -> int:
        """Rough token estimate (~4 chars per token)."""
        return len(text) // 4

    def _score_skill(
        self,
        skill: SkillDefinition,
        user_input: str,
        goal_titles: list[str],
    ) -> float:
        """Score skill relevance by keyword overlap."""
        terms = set(user_input.lower().split())
        terms.update(w for g in goal_titles for w in g.lower().split())
        skill_terms = set(skill.name.lower().split("-"))
        skill_terms.update(skill.description.lower().split())
        if not skill_terms:
            return 0.0
        return len(terms & skill_terms) / len(skill_terms)
