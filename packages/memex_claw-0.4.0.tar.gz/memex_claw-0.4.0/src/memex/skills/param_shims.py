"""Parameter translators for OpenClaw → Memex tool argument mapping."""

from __future__ import annotations

import logging
import shlex
from typing import Any, Callable

logger = logging.getLogger(__name__)

PARAM_TRANSLATORS: dict[str, Callable[[dict[str, Any]], dict[str, Any]]] = {}


def translate_exec_params(arguments: dict[str, Any]) -> dict[str, Any]:
    """Translate OpenClaw exec params to Memex bash params."""
    translated: dict[str, Any] = {}
    command = arguments.get("command", "")
    if arguments.get("workdir"):
        command = f"cd {shlex.quote(arguments['workdir'])} && {command}"
    translated["command"] = command
    for unsupported in ("pty", "background", "elevated"):
        if arguments.get(unsupported):
            logger.warning(
                "exec param '%s' not supported by Memex, ignoring",
                unsupported,
            )
    return translated


PARAM_TRANSLATORS["exec"] = translate_exec_params
PARAM_TRANSLATORS["bash"] = translate_exec_params
