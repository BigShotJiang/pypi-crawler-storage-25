"""Maps OpenClaw config keys to Memex config equivalents."""

from __future__ import annotations

from typing import Callable


class SkillConfigRegistry:
    """Maps OpenClaw config keys to Memex config availability checks."""

    def __init__(self) -> None:
        self._mappings: dict[str, Callable[[], bool]] = {}

    def register(self, openclaw_key: str, check: Callable[[], bool]) -> None:
        """Register a config availability check for an OpenClaw key."""
        self._mappings[openclaw_key] = check

    def unregister(self, openclaw_key: str) -> None:
        """Remove a config availability check."""
        self._mappings.pop(openclaw_key, None)

    def is_satisfied(self, openclaw_key: str) -> bool:
        """Check if the OpenClaw config key's equivalent is available.

        Returns False for unknown keys.
        """
        check = self._mappings.get(openclaw_key)
        if check is None:
            return False
        return check()
