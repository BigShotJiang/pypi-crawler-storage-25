"""OpenClaw tool alias table and incompatible tools list."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from memex.tools import ToolRegistry

logger = logging.getLogger(__name__)

OPENCLAW_TOOL_ALIASES: dict[str, str] = {
    "exec": "bash",
    "read": "read_file",
    "write": "write_file",
    "edit": "edit_file",
    "apply_patch": "edit_file",
    "web_fetch": "web_fetch",
    "memory_search": "search_knowledge",
    "memory_get": "get_knowledge",
}

INCOMPATIBLE_TOOLS: set[str] = {
    "browser",
    "canvas",
    "nodes",
    "sessions_list",
    "sessions_history",
    "sessions_send",
    "sessions_spawn",
    "session_status",
    "agents_list",
    "image",
}


def apply_openclaw_aliases(registry: ToolRegistry) -> None:
    """Register OpenClaw tool name aliases for existing Memex tools.

    Only creates aliases for tools that actually exist in the registry.
    """
    for oc_name, memex_name in OPENCLAW_TOOL_ALIASES.items():
        if oc_name == memex_name:
            continue  # skip identity mappings
        tool = registry.get_tool(memex_name)
        if tool:
            registry.register_alias(oc_name, memex_name)
            logger.debug("Aliased '%s' → '%s'", oc_name, memex_name)
        else:
            logger.debug(
                "Skipping alias '%s' → '%s': target not registered",
                oc_name,
                memex_name,
            )
