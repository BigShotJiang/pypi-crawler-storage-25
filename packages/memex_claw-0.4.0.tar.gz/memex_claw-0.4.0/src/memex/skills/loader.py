"""SKILL.md loader — parses OpenClaw-compatible skill definitions."""

from __future__ import annotations

import logging
import os
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from memex.skills.config_registry import SkillConfigRegistry

logger = logging.getLogger(__name__)


@dataclass
class SkillDefinition:
    """A parsed skill from a SKILL.md file."""

    name: str
    description: str
    version: str
    body: str
    base_dir: Path
    user_invocable: bool = True
    disable_model_invocation: bool = False
    command_dispatch: str | None = None
    command_tool: str | None = None
    allowed_tools: list[str] | None = None
    emoji: str | None = None
    requires_env: list[str] = field(default_factory=list)
    requires_bins: list[str] = field(default_factory=list)
    requires_any_bins: list[str] = field(default_factory=list)
    requires_config: list[str] = field(default_factory=list)
    incompatible_tools: list[str] = field(default_factory=list)


def _parse_yaml_frontmatter(text: str) -> dict | None:
    """Parse YAML frontmatter between --- delimiters.

    Uses PyYAML if available, otherwise falls back to a simple parser
    for the single-line YAML subset OpenClaw uses.
    """
    try:
        import yaml

        return yaml.safe_load(text)
    except ImportError:
        pass

    # Simple fallback parser for flat/simple YAML
    result: dict = {}
    stack: list[tuple[int, dict]] = [(-1, result)]
    current_list: list | None = None
    current_list_indent: int = -1

    for line in text.splitlines():
        stripped = line.rstrip()
        if not stripped or stripped.startswith("#"):
            continue

        indent = len(line) - len(line.lstrip())

        # Check for list item continuation (- value)
        list_match = re.match(r"^(\s*)-\s+(.*)", line)
        if list_match and current_list is not None and indent >= current_list_indent:
            current_list.append(list_match.group(2).strip().strip("\"'"))
            continue

        # Not a list continuation — reset list tracking
        current_list = None
        current_list_indent = -1

        match = re.match(r"^(\s*)([\w-]+)\s*:\s*(.*)", line)
        if not match:
            continue

        key = match.group(2)
        value_str = match.group(3).strip()

        # Pop stack to find parent at lower indent
        while stack and stack[-1][0] >= indent:
            stack.pop()

        parent = stack[-1][1] if stack else result

        if value_str.startswith("[") and value_str.endswith("]"):
            # Inline list: ["a", "b"]
            items = [
                s.strip().strip("\"'") for s in value_str[1:-1].split(",") if s.strip()
            ]
            parent[key] = items
        elif value_str == "":
            # Nested dict or list follows
            child: dict = {}
            parent[key] = child
            stack.append((indent, child))
        elif value_str.lower() in ("true", "false"):
            parent[key] = value_str.lower() == "true"
        elif value_str.startswith("- "):
            # First item of a block list on the same line as key
            item = value_str[2:].strip().strip("\"'")
            lst: list = [item]
            parent[key] = lst
            current_list = lst
            current_list_indent = indent + 2  # expect continuation at deeper indent
        else:
            parent[key] = value_str.strip("\"'")

    return result


class SkillLoader:
    """Scans directories for SKILL.md files and produces SkillDefinitions."""

    def __init__(
        self,
        dirs: list[Path],
        config_registry: SkillConfigRegistry | None = None,
    ) -> None:
        self._dirs = dirs
        self._config_registry = config_registry

    def load_all(self) -> list[SkillDefinition]:
        """Load all skills from configured directories.

        Directories are scanned in reverse precedence order so that
        higher-precedence directories (later in the list) override
        lower-precedence ones.
        """
        skills: dict[str, SkillDefinition] = {}
        for d in self._dirs:
            if not d.is_dir():
                continue
            for skill_dir in sorted(d.iterdir()):
                if not skill_dir.is_dir():
                    continue
                skill_md = skill_dir / "SKILL.md"
                if skill_md.is_file():
                    try:
                        skill = self._parse(skill_md)
                    except Exception:
                        logger.debug("Failed to parse %s", skill_md, exc_info=True)
                        continue
                    if skill and self._requirements_met(skill):
                        skills[skill.name] = skill
        return list(skills.values())

    def _parse(self, path: Path) -> SkillDefinition | None:
        """Parse YAML frontmatter + markdown body from SKILL.md."""
        text = path.read_text(encoding="utf-8")
        skill_dir = path.parent

        # Split frontmatter from body
        fm_match = re.match(
            r"^---\s*\n(.*?)\n---\s*\n(.*)",
            text,
            re.DOTALL,
        )
        if not fm_match:
            logger.debug("No frontmatter in %s", path)
            return None

        fm_text = fm_match.group(1)
        body = fm_match.group(2).strip()

        meta = _parse_yaml_frontmatter(fm_text)
        if not meta:
            logger.debug("Empty frontmatter in %s", path)
            return None

        name = meta.get("name", skill_dir.name)
        description = meta.get("description", "")
        version = meta.get("version", "0.0.0")

        # Substitute {baseDir}
        body = body.replace("{baseDir}", str(skill_dir))

        # Extract OpenClaw metadata
        oc_meta = meta.get("metadata", {})
        if isinstance(oc_meta, dict):
            oc_meta = oc_meta.get("openclaw", {}) or {}
        else:
            oc_meta = {}
        requires = oc_meta.get("requires", {}) or {}

        # Detect incompatible tool references
        incompatible = self._detect_incompatible_refs(body)

        return SkillDefinition(
            name=name,
            description=str(description),
            version=str(version),
            body=body,
            base_dir=skill_dir,
            user_invocable=bool(meta.get("user-invocable", True)),
            disable_model_invocation=bool(meta.get("disable-model-invocation", False)),
            command_dispatch=meta.get("command-dispatch"),
            command_tool=meta.get("command-tool"),
            allowed_tools=meta.get("allowed-tools"),
            emoji=meta.get("emoji"),
            requires_env=requires.get("env", []) or [],
            requires_bins=requires.get("bins", []) or [],
            requires_any_bins=requires.get("anyBins", []) or [],
            requires_config=requires.get("config", []) or [],
            incompatible_tools=incompatible,
        )

    def _requirements_met(self, skill: SkillDefinition) -> bool:
        """Check env vars, binaries, config requirements."""
        for var in skill.requires_env:
            if not os.environ.get(var):
                logger.debug("Skill %s: missing env %s, skipping", skill.name, var)
                return False
        for bin_name in skill.requires_bins:
            if not shutil.which(bin_name):
                logger.debug(
                    "Skill %s: missing binary %s, skipping",
                    skill.name,
                    bin_name,
                )
                return False
        if skill.requires_any_bins:
            if not any(shutil.which(b) for b in skill.requires_any_bins):
                logger.debug(
                    "Skill %s: none of %s found, skipping",
                    skill.name,
                    skill.requires_any_bins,
                )
                return False
        for config_key in skill.requires_config:
            if self._config_registry and not self._config_registry.is_satisfied(
                config_key
            ):
                logger.debug(
                    "Skill %s: config %s not satisfied, skipping",
                    skill.name,
                    config_key,
                )
                return False
            elif not self._config_registry:
                logger.debug(
                    "Skill %s: no config registry, config %s unsatisfied",
                    skill.name,
                    config_key,
                )
                return False
        return True

    @staticmethod
    def _detect_incompatible_refs(body: str) -> list[str]:
        """Scan skill body for references to tools Memex cannot support."""
        from memex.skills.aliases import INCOMPATIBLE_TOOLS

        found = []
        for tool in INCOMPATIBLE_TOOLS:
            if re.search(rf"`{re.escape(tool)}`", body):
                found.append(tool)
        return found
