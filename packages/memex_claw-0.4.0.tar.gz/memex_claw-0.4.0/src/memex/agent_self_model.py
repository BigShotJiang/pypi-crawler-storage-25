"""Durable agent self-model helpers for the 0.8 rethink migration."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from memex.models import AgentCapability, AgentLimitation, AgentSelfModel
from memex.store import MemexStore
from memex.utcnow import utcnow

_RUNTIME_CAPABILITY_IDS = {"surface/status", "surface/post"}
_RUNTIME_LIMITATION_PREFIXES = ("degraded/", "error/")
_DIAGNOSTIC_LIMITATION_PREFIX = "diagnostic/"
_REPAIR_LIMITATION_PREFIX = "repair/"
_BLOCKED_TOOL_TAGS_BY_CAPABILITY_ID: dict[str, tuple[str, ...]] = {
    "connector/gmail": ("comm.gmail",),
}


def _status_to_capability_status(status: str) -> str:
    normalized = (status or "").lower()
    if normalized in {"degraded", "warn", "warning"}:
        return "degraded"
    if normalized in {"unavailable", "error", "failed", "disabled"}:
        return "unavailable"
    return "available"


def _capability_title(prefix: str, name: str) -> str:
    label = name.replace("_", " ").replace("-", " ").strip().title()
    return f"{prefix}: {label}" if prefix else label


def _base_runtime_capabilities(now: datetime) -> list[AgentCapability]:
    return [
        AgentCapability(
            capability_id="surface/status",
            title="Status and self-state",
            status="available",
            detail="Status, self-state, diagnostics, and repair surfaces are exposed.",
            source="api",
            updated_at=now,
        ),
        AgentCapability(
            capability_id="surface/post",
            title="POST and doctor",
            status="available",
            detail="Startup POST and doctor remain available through the API/CLI shell.",
            source="api",
            updated_at=now,
        ),
    ]


def _runtime_capabilities(
    runtime_state: dict[str, Any], *, observed_at: datetime
) -> list[AgentCapability]:
    capabilities = _base_runtime_capabilities(observed_at)

    for item in runtime_state.get("interfaces", []):
        capabilities.append(
            AgentCapability(
                capability_id=f"interface/{item.get('name', 'unknown')}",
                title=_capability_title("Interface", item.get("name", "unknown")),
                status=_status_to_capability_status(item.get("status", "")),
                detail=item.get("last_error") or item.get("status", ""),
                source=item.get("owner", "runtime"),
                updated_at=observed_at,
            )
        )

    for item in runtime_state.get("connectors", []):
        capabilities.append(
            AgentCapability(
                capability_id=f"connector/{item.get('name', 'unknown')}",
                title=_capability_title("Connector", item.get("name", "unknown")),
                status=_status_to_capability_status(item.get("status", "")),
                detail=item.get("error")
                or f"{item.get('tools_discovered', 0)} tools discovered",
                source="connector",
                updated_at=observed_at,
            )
        )

    for item in runtime_state.get("services", []):
        capabilities.append(
            AgentCapability(
                capability_id=f"service/{item.get('id', 'unknown')}",
                title=_capability_title(
                    "Service", item.get("name", item.get("id", "unknown"))
                ),
                status=_status_to_capability_status(item.get("status", "")),
                detail=item.get("last_error") or item.get("status", ""),
                source="service_manager",
                updated_at=observed_at,
            )
        )

    for item in runtime_state.get("plugins", {}).get("items", []):
        capabilities.append(
            AgentCapability(
                capability_id=f"plugin/{item.get('plugin_id', 'unknown')}",
                title=_capability_title(
                    "Plugin", item.get("name", item.get("plugin_id", "unknown"))
                ),
                status="available"
                if item.get("loaded")
                else _status_to_capability_status(item.get("status", "")),
                detail=item.get("error") or item.get("status", ""),
                source="plugin_registry",
                updated_at=observed_at,
            )
        )

    return capabilities


def _runtime_limitations(
    runtime_state: dict[str, Any], *, observed_at: datetime
) -> list[AgentLimitation]:
    limitations: list[AgentLimitation] = []
    for mode in runtime_state.get("process", {}).get("degraded_modes", []):
        limitations.append(
            AgentLimitation(
                limitation_id=f"degraded/{mode}",
                title=mode.replace("_", " "),
                detail="Runtime reported this degraded mode.",
                severity="warn",
                recoverable=True,
                source="runtime",
                updated_at=observed_at,
            )
        )

    for error in runtime_state.get("errors", []):
        limitations.append(
            AgentLimitation(
                limitation_id=f"error/{len(limitations)}",
                title=error.get("subsystem", "runtime error"),
                detail=error.get("message", ""),
                severity="warn" if error.get("recoverable", True) else "error",
                recoverable=error.get("recoverable", True),
                source=error.get("subsystem", "runtime"),
                updated_at=observed_at,
            )
        )
    return limitations


def apply_runtime_observation(
    model: AgentSelfModel,
    runtime_state: dict[str, Any],
) -> AgentSelfModel:
    observed_at = utcnow()
    updated = model.model_copy(deep=True)

    runtime_capabilities = _runtime_capabilities(runtime_state, observed_at=observed_at)
    managed_capability_ids = _RUNTIME_CAPABILITY_IDS | {
        cap.capability_id for cap in runtime_capabilities
    }
    preserved_capabilities = [
        cap
        for cap in updated.capabilities
        if cap.capability_id not in managed_capability_ids
    ]
    updated.capabilities = preserved_capabilities + runtime_capabilities

    runtime_limitations = _runtime_limitations(runtime_state, observed_at=observed_at)
    preserved_limitations = [
        limitation
        for limitation in updated.limitations
        if not limitation.limitation_id.startswith(_RUNTIME_LIMITATION_PREFIXES)
    ]
    updated.limitations = preserved_limitations + runtime_limitations

    updated.degraded_modes = list(
        runtime_state.get("process", {}).get("degraded_modes", [])
    )
    updated.operational_state = {
        "process": runtime_state.get("process", {}),
        "goals": runtime_state.get("goals", {}),
        "session": runtime_state.get("session", {}),
        "queues": runtime_state.get("queues", {}),
        "meetings": runtime_state.get("meetings", {}),
        "subagents": runtime_state.get("subagents", {}),
    }
    updated.updated_at = observed_at
    return updated


def apply_diagnostics_observation(
    model: AgentSelfModel,
    diagnostics: dict[str, Any],
) -> AgentSelfModel:
    observed_at = utcnow()
    updated = model.model_copy(deep=True)
    preserved_limitations = [
        limitation
        for limitation in updated.limitations
        if not limitation.limitation_id.startswith(_DIAGNOSTIC_LIMITATION_PREFIX)
    ]
    diagnostic_limitations: list[AgentLimitation] = []
    for check in (diagnostics or {}).get("checks", []):
        if check.get("status") == "ok":
            continue
        diagnostic_limitations.append(
            AgentLimitation(
                limitation_id=f"diagnostic/{check.get('name', 'unknown')}",
                title=check.get("name", "diagnostic"),
                detail=check.get("detail", ""),
                severity="warn" if check.get("status") == "warn" else "error",
                recoverable=check.get("status") != "fail",
                source="diagnostics",
                updated_at=observed_at,
            )
        )
    updated.limitations = preserved_limitations + diagnostic_limitations
    updated.last_diagnostics = diagnostics or {}
    updated.updated_at = observed_at
    return updated


def apply_repair_observation(
    model: AgentSelfModel,
    last_repair: dict[str, Any],
) -> AgentSelfModel:
    observed_at = utcnow()
    updated = model.model_copy(deep=True)
    preserved_limitations = [
        limitation
        for limitation in updated.limitations
        if not limitation.limitation_id.startswith(_REPAIR_LIMITATION_PREFIX)
    ]
    repair_limitations: list[AgentLimitation] = []
    if last_repair and not last_repair.get("ok"):
        repair_limitations.append(
            AgentLimitation(
                limitation_id=f"repair/{last_repair.get('action', 'unknown')}",
                title=last_repair.get("action", "repair"),
                detail=last_repair.get("detail", ""),
                severity="warn",
                recoverable=True,
                source="repair",
                updated_at=observed_at,
            )
        )
    updated.limitations = preserved_limitations + repair_limitations
    updated.last_repair = last_repair or {}
    updated.updated_at = observed_at
    return updated


def observe_agent_self_model(
    store: MemexStore,
    runtime_state: dict[str, Any],
    *,
    diagnostics: dict[str, Any] | None = None,
    last_repair: dict[str, Any] | None = None,
) -> AgentSelfModel:
    model = apply_runtime_observation(load_agent_self_model(store), runtime_state)
    if diagnostics is not None:
        model = apply_diagnostics_observation(model, diagnostics)
    if last_repair is not None:
        model = apply_repair_observation(model, last_repair)
    save_agent_self_model(model, store)
    return model


def project_agent_self_model(
    store: MemexStore,
    runtime_state: dict[str, Any],
) -> AgentSelfModel:
    """Project the durable self-model through live runtime state without persisting."""
    return apply_runtime_observation(load_agent_self_model(store), runtime_state)


def blocked_tool_capability_tags(model: AgentSelfModel) -> set[str]:
    blocked: set[str] = set()
    for capability in model.capabilities:
        if capability.status != "unavailable":
            continue
        blocked.update(
            _BLOCKED_TOOL_TAGS_BY_CAPABILITY_ID.get(capability.capability_id, ())
        )
    return blocked


def guarded_route_reason(model: AgentSelfModel) -> str:
    """Return a durable reason to route prompt-control into guarded review."""
    if model.degraded_modes:
        return f"degraded modes active: {', '.join(model.degraded_modes[:3])}"

    for limitation in model.limitations:
        if limitation.limitation_id.startswith("degraded/"):
            return f"degradation signal: {limitation.title}"
        if limitation.severity == "error" or not limitation.recoverable:
            return f"limitation signal: {limitation.title}"

    return ""


def has_guarded_route_signal(model: AgentSelfModel) -> bool:
    return bool(guarded_route_reason(model))


def load_agent_self_model(store: MemexStore) -> AgentSelfModel:
    loader = getattr(store, "load_agent_self_model", None)
    if callable(loader):
        model = loader()
        if isinstance(model, AgentSelfModel):
            return model
        if isinstance(model, dict):
            return AgentSelfModel.model_validate(model)
        if isinstance(model, str):
            return AgentSelfModel.model_validate_json(model)
    return AgentSelfModel()


def save_agent_self_model(model: AgentSelfModel, store: MemexStore) -> None:
    model.updated_at = utcnow()
    saver = getattr(store, "save_agent_self_model", None)
    if callable(saver):
        saver(model)


def format_for_prompt(model: AgentSelfModel) -> str:
    """Format the canonical agent self-model for the system prompt."""
    if (
        not model.degraded_modes
        and not model.capabilities
        and not model.limitations
        and not model.last_diagnostics
        and not model.last_repair
    ):
        return ""

    parts: list[str] = ["## About Memex"]

    if model.degraded_modes:
        parts.append(f"Degraded modes: {', '.join(model.degraded_modes)}")

    visible_capabilities = [
        cap for cap in model.capabilities if cap.status != "unavailable"
    ][:5]
    if visible_capabilities:
        parts.append("Current capabilities:")
        for capability in visible_capabilities:
            detail = f" — {capability.detail}" if capability.detail else ""
            parts.append(f"  - {capability.title} [{capability.status}]{detail}")

    if model.limitations:
        parts.append("Current limitations:")
        for limitation in model.limitations[:5]:
            detail = f" — {limitation.detail}" if limitation.detail else ""
            parts.append(f"  - {limitation.title} [{limitation.severity}]{detail}")

    return "\n".join(parts)
