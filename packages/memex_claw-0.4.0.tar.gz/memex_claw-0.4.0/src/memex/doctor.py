"""Memex init and doctor (power-on self-test).

`memex init`   — idempotent first-time setup
`memex doctor` — on-demand diagnostic
`startup_post()` — lightweight POST that runs at every startup via MemexAPI.create()
"""

from __future__ import annotations

import logging
import os
import shutil
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Check result model
# ---------------------------------------------------------------------------


@dataclass
class Check:
    """Result of a single diagnostic check."""

    name: str
    status: str  # "ok", "warn", "fail"
    detail: str = ""

    @property
    def icon(self) -> str:
        return {"ok": "\u2713", "warn": "!", "fail": "\u2717"}[self.status]


@dataclass
class DoctorReport:
    """Aggregated results from all checks."""

    checks: list[Check] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return all(c.status != "fail" for c in self.checks)

    def add(self, name: str, status: str, detail: str = "") -> None:
        self.checks.append(Check(name=name, status=status, detail=detail))

    def print(self) -> None:
        for c in self.checks:
            line = f"  {c.icon} {c.name}"
            if c.detail:
                line += f": {c.detail}"
            print(line)
        print()
        fails = [c for c in self.checks if c.status == "fail"]
        warns = [c for c in self.checks if c.status == "warn"]
        if fails:
            print(f"  {len(fails)} issue(s) must be fixed before Memex can run.")
        elif warns:
            print(f"  All clear ({len(warns)} optional warning(s)).")
        else:
            print("  All checks passed.")


def _check_fathomdb(store_path: str, *, name: str = "Knowledge store") -> Check:
    """Verify fathomdb engine can open and read."""
    fathom_path = Path(store_path).parent / "fathom.db"
    if not fathom_path.exists():
        return Check(
            name=name,
            status="warn",
            detail="fathomdb not initialized — will be created on first use",
        )
    try:
        from memex.fathom_store import FathomStore

        logger.debug("_check_fathomdb: opening FathomStore at %s", fathom_path)
        store = FathomStore.open(str(fathom_path))
        logger.debug("_check_fathomdb: FathomStore opened, probing...")
        try:
            # Light read probe — list operational collections
            desc = store.engine.admin.describe_operational_collection("audit_log")
            logger.debug("_check_fathomdb: probe done, desc=%s", desc is not None)
            detail = f"fathomdb v{fathom_path.stat().st_size // 1024}KB"
            if desc is not None:
                detail += ", collections registered"
            for _vec_kind in ("KnowledgeItem", "ConversationTurn"):
                try:
                    vec_profile = store.engine.admin.get_vec_profile(_vec_kind)
                    if vec_profile is None:
                        detail += f", VecProfile {_vec_kind}: unregistered"
                    else:
                        detail += f", VecProfile {_vec_kind}: {vec_profile.model_identity} @ {vec_profile.dimensions}d"
                except Exception:
                    detail += f", VecProfile {_vec_kind}: check failed"
        finally:
            logger.debug("_check_fathomdb: closing FathomStore")
            store.close()
            logger.debug("_check_fathomdb: FathomStore closed")
        return Check(name=name, status="ok", detail=detail)
    except Exception as exc:
        return Check(name=name, status="fail", detail=f"fathomdb error: {exc}")


def _check_dotenv(*, name: str = "Environment") -> Check:
    """Check that .env file exists and was loaded."""
    env_file = Path.cwd() / ".env"
    if not env_file.exists():
        return Check(
            name=name,
            status="warn",
            detail=".env file not found — using system environment only",
        )
    # Verify at least one key provider var is set (sign that load_dotenv worked)
    has_any = any(
        os.environ.get(k)
        for k in (
            "ANTHROPIC_API_KEY",
            "OPENAI_API_KEY",
            "AIRLOCK_MASTER_KEY",
            "TELEGRAM_BOT_TOKEN",
        )
    )
    if has_any:
        return Check(name=name, status="ok", detail=".env loaded")
    return Check(
        name=name,
        status="warn",
        detail=".env exists but no API keys or tokens found — check file contents",
    )


def _check_llm_api_key(*, name: str = "LLM API key") -> Check:
    providers = {
        "ANTHROPIC_API_KEY": "Anthropic",
        "OPENAI_API_KEY": "OpenAI",
        "GOOGLE_AISTUDIO_API_KEY": "Google AI Studio",
    }
    found = [
        provider for env_key, provider in providers.items() if os.environ.get(env_key)
    ]
    if found:
        return Check(name=name, status="ok", detail=", ".join(found))
    return Check(
        name=name,
        status="fail",
        detail="No API key found — set ANTHROPIC_API_KEY (or OPENAI_API_KEY, etc.) in .env",
    )


def _check_llm_proxy(*, name: str = "LLM proxy") -> Check:
    import urllib.request
    import urllib.error
    from memex.llm import _get_proxy_url, _get_proxy_key

    proxy_url = _get_proxy_url()
    if not proxy_url:
        return Check(
            name=name, status="ok", detail="direct access (no proxy configured)"
        )

    health_url = proxy_url.rstrip("/").removesuffix("/v1") + "/health"
    proxy_key = _get_proxy_key()
    req = urllib.request.Request(health_url)
    if proxy_key:
        req.add_header("Authorization", f"Bearer {proxy_key}")

    try:
        urllib.request.urlopen(req, timeout=3)  # nosec B310 — URL built from config
        return Check(name=name, status="ok", detail=f"{proxy_url} — reachable")
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            return Check(
                name=name,
                status="warn",
                detail=f"{proxy_url} — reachable (auth rejected, check AIRLOCK_MASTER_KEY)",
            )
        return Check(
            name=name,
            status="warn",
            detail=f"{proxy_url} — HTTP {exc.code} (proxy may be unhealthy)",
        )
    except OSError as exc:
        return Check(
            name=name,
            status="warn",
            detail=f"{proxy_url} — unreachable ({type(exc).__name__}: {exc})",
        )


def _check_telegram(*, name: str = "Telegram") -> Check:
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    user_id = os.environ.get("TELEGRAM_USER_ID")
    if token and user_id:
        user_count = len(user_id.split(","))
        return Check(
            name=name, status="ok", detail=f"configured ({user_count} allowed user(s))"
        )
    return Check(name=name, status="warn", detail="not configured (optional)")


# ---------------------------------------------------------------------------
# Init
# ---------------------------------------------------------------------------

_ENV_TEMPLATE = """\
# Memex environment variables
# Uncomment and fill in the values you need.

# --- LLM Provider API Keys (at least one required) ---
# ANTHROPIC_API_KEY=
# OPENAI_API_KEY=
# GOOGLE_AISTUDIO_API_KEY=

# --- Store ---
# MEMEX_STORE=.memex/memex.db


# --- Models (optional — sensible defaults used) ---
# MEMEX_RESPONSE_MODEL=anthropic/claude-sonnet-4-20250514
# MEMEX_CHEAP_MODEL=anthropic/claude-haiku-4-5-20251001

# --- Filesystem connector (configured in YAML) ---
# MEMEX_MCP_SERVERS_CONFIG=/path/to/mcp_servers.yaml

# --- Telegram (optional) ---
# TELEGRAM_BOT_TOKEN=
# TELEGRAM_USER_ID=

# --- Logging ---
# MEMEX_LOG_DIR=./log
"""

_SOUL_STUB = """\
# SOUL.md — Memex personality and character

You are Memex, a personal AI partner focused on helping your user achieve
their goals. You maintain context across conversations, remember preferences,
and proactively surface relevant information.

Tone: thoughtful, concise, direct. Avoid unnecessary filler.
"""

_CONSTITUTION_STUB = """\
# CONSTITUTION.md — Memex behavioral boundaries

## Hard rules
- Never fabricate citations or sources.
- Never impersonate the user or act on their behalf without explicit consent.
- Always distinguish between your own knowledge and retrieved content.
- Respect the user's stated constraints absolutely.
"""


def init(project_root: Path | None = None) -> list[str]:
    """Idempotent first-time setup. Returns list of actions taken."""
    root = project_root or Path.cwd()
    actions: list[str] = []

    # 1. .memex/ directory
    memex_dir = root / ".memex"
    if not memex_dir.exists():
        memex_dir.mkdir(parents=True, exist_ok=True)
        actions.append("Created .memex/ directory")
    else:
        actions.append(".memex/ already exists")

    # 2. Knowledge store (FathomDB) — create / open
    store_path = os.environ.get("MEMEX_STORE", str(memex_dir / "memex.db"))
    fathom_path = str(Path(store_path).parent / "fathom.db")
    try:
        from memex.fathom_store import FathomStore

        fathom = FathomStore.open(fathom_path)
        fathom.close()
        actions.append("Knowledge store ready (fathomdb)")
    except Exception as exc:
        actions.append(f"Knowledge store error: {exc}")

    # 4. Log directory
    log_dir = Path(os.environ.get("MEMEX_LOG_DIR", str(root / "log")))
    if not log_dir.exists():
        log_dir.mkdir(parents=True, exist_ok=True)
        actions.append(f"Created {log_dir}/ directory")
    else:
        actions.append(f"{log_dir}/ already exists")

    # 6. .env template
    env_file = root / ".env"
    if not env_file.exists():
        env_file.write_text(_ENV_TEMPLATE)
        actions.append("Created .env template (fill in your API keys)")
    else:
        actions.append(".env already exists")

    # 7. Governance files
    for name, stub in [
        ("SOUL.md", _SOUL_STUB),
        ("CONSTITUTION.md", _CONSTITUTION_STUB),
    ]:
        path = root / name
        if not path.exists():
            path.write_text(stub)
            actions.append(f"Created {name} (edit to customize)")
        else:
            actions.append(f"{name} already exists")

    # 8. .gitignore entry
    gitignore = root / ".gitignore"
    entries_to_add = [".env", "log/", ".memex/"]
    if gitignore.exists():
        content = gitignore.read_text()
        added = []
        for entry in entries_to_add:
            if entry not in content:
                added.append(entry)
        if added:
            with open(gitignore, "a") as f:
                f.write("\n# Memex\n")
                for entry in added:
                    f.write(f"{entry}\n")
            actions.append(f"Added {', '.join(added)} to .gitignore")
    else:
        gitignore.write_text("# Memex\n" + "\n".join(entries_to_add) + "\n")
        actions.append("Created .gitignore")

    return actions


# ---------------------------------------------------------------------------
# Doctor (POST)
# ---------------------------------------------------------------------------


def doctor(project_root: Path | None = None) -> DoctorReport:
    """Run diagnostic self-test. Returns structured report."""
    root = project_root or Path.cwd()
    report = DoctorReport()

    # 0. Environment (.env)
    logger.debug("doctor: checking dotenv")
    report.checks.append(_check_dotenv())

    # 1. .memex directory
    logger.debug("doctor: checking data directory")
    memex_dir = root / ".memex"
    if memex_dir.is_dir():
        report.add("Data directory", "ok", str(memex_dir))
    else:
        report.add("Data directory", "fail", f"{memex_dir} missing — run `memex init`")

    # 2. Knowledge store — verify fathomdb is actually accessible
    logger.debug("doctor: checking fathomdb")
    from memex.paths import resolve_store_path

    store_path = resolve_store_path()
    report.checks.append(_check_fathomdb(store_path))
    logger.debug("doctor: fathomdb check done")

    # 4. LLM API keys
    report.checks.append(_check_llm_api_key())

    # 5. Models
    response_model = os.environ.get(
        "MEMEX_RESPONSE_MODEL", "anthropic/claude-sonnet-4-20250514"
    )
    cheap_model = os.environ.get(
        "MEMEX_CHEAP_MODEL", "anthropic/claude-haiku-4-5-20251001"
    )
    report.add("LLM models", "ok", f"response={response_model}, cheap={cheap_model}")

    # 6. LLM proxy
    report.checks.append(_check_llm_proxy())

    # 7. Logging
    log_dir = Path(os.environ.get("MEMEX_LOG_DIR", str(root / "log")))
    if log_dir.is_dir():
        try:
            # Check writable
            test_file = log_dir / ".doctor_test"
            test_file.touch()
            test_file.unlink()
            log_count = len(list(log_dir.glob("*-memex.log")))
            report.add("Logging", "ok", f"{log_dir} ({log_count} log files)")
        except OSError as exc:
            report.add("Logging", "fail", f"{log_dir} not writable: {exc}")
    else:
        report.add("Logging", "warn", f"{log_dir} missing — will be created on startup")

    # 8. Governance files
    soul = root / "SOUL.md"
    constitution = root / "CONSTITUTION.md"
    identity = root / "IDENTITY.md"
    gov_files = []
    if constitution.exists():
        gov_files.append("CONSTITUTION.md")
    if soul.exists():
        gov_files.append("SOUL.md")
    if identity.exists():
        gov_files.append("IDENTITY.md")
    if constitution.exists() and soul.exists():
        report.add("Governance", "ok", " + ".join(gov_files))
    elif gov_files:
        missing = []
        if not constitution.exists():
            missing.append("CONSTITUTION.md")
        if not soul.exists():
            missing.append("SOUL.md")
        detail = " + ".join(gov_files)
        if missing:
            detail += f" ({', '.join(missing)} missing)"
        report.add("Governance", "warn", detail)
    else:
        report.add(
            "Governance", "warn", "No SOUL.md or CONSTITUTION.md — run `memex init`"
        )

    user_md = root / "USER.md"
    if user_md.exists():
        report.add("User context", "ok", "USER.md found")
    else:
        report.add(
            "User context",
            "ok",
            "No USER.md (optional — create to add static user context)",
        )

    # 8b. Prompt budget
    try:
        from memex.prompt_budget import DEFAULT_PROMPT_BUDGET, load_prompt_budget_config
        from memex.settings_store import SettingsStore

        conn = sqlite3.connect(store_path)
        conn.row_factory = sqlite3.Row
        try:
            config = load_prompt_budget_config(SettingsStore(conn))
            customized = config != DEFAULT_PROMPT_BUDGET
            detail = (
                f"stable={config.stable_prefix_tokens}, dynamic={config.dynamic_turn_tokens}, "
                f"retrieval={config.retrieval_tokens}, operator={config.operator_tokens}"
            )
            if customized:
                detail += " (customized)"
            report.add("Prompt budget", "ok", detail)
        finally:
            conn.close()
    except Exception as exc:
        report.add("Prompt budget", "ok", f"defaults (could not read settings: {exc})")

    # 8. Telegram — parallel check to MemexAPI.run_diagnostics() "telegram_config" check; update both if env vars change.
    report.checks.append(_check_telegram())

    # 9. Filesystem connector(s) — from YAML config
    from memex.mcp_servers import servers_config_from_env

    fs_config = servers_config_from_env()
    fs_entries = fs_config.filesystem_entries()
    if fs_entries:
        for entry in fs_entries:
            mode = "read+write" if entry.write else "read-only"
            roots = entry.roots
            existing = [r for r in roots if Path(r).is_dir()]
            if len(existing) == len(roots):
                report.add(
                    f"Filesystem ({entry.name})", "ok", f"{mode}, {len(roots)} root(s)"
                )
            else:
                missing = set(roots) - set(existing)
                report.add(
                    f"Filesystem ({entry.name})",
                    "warn",
                    f"{mode}, but missing directories: {', '.join(missing)}",
                )
    else:
        report.add("Filesystem", "warn", "not configured (optional)")

    # 10. Embeddings
    try:
        from memex.memory.embeddings import preload_libgomp

        preload_libgomp()
        import sentence_transformers  # noqa: F401

        report.add("Embeddings", "ok", "sentence-transformers available")
    except ImportError:
        report.add(
            "Embeddings",
            "warn",
            "sentence-transformers not installed — semantic search disabled",
        )

    # 11. Speaker diarization (pyannote + HF token)
    hf_token = (
        os.environ.get("HUGGINGFACE_TOKEN")
        or os.environ.get("HF_TOKEN")
        or os.environ.get("MEMEX_HF_TOKEN")
    )
    try:
        import pyannote.audio  # noqa: F401

        diarization_installed = True
    except ImportError:
        diarization_installed = False

    if diarization_installed:
        if hf_token:
            report.add(
                "Speaker diarization", "ok", "pyannote installed, HF token present"
            )
        else:
            report.add(
                "Speaker diarization",
                "warn",
                "pyannote installed but no HF token found (set HUGGINGFACE_TOKEN) — diarization will fail",
            )
    # If not installed, silently omit the check (diarization is optional)

    # 12a. STT backend availability
    try:
        from memex.meetings.stt_backend import get_backend

        backend = get_backend()
        report.add("STT backend", "ok", f"using {type(backend).__name__}")
    except RuntimeError:
        report.add(
            "STT backend",
            "warn",
            "no STT backend available — transcription disabled "
            "(pip install memex-claw[transcription])",
        )
    except Exception:
        report.add(
            "STT backend",
            "warn",
            "STT backend check failed — transcription may not work",
        )

    # 12b. NER (spaCy)
    try:
        import spacy  # noqa: F401

        try:
            spacy.load("en_core_web_sm")
            report.add("NER", "ok", "spacy + en_core_web_sm available")
        except OSError:
            report.add(
                "NER",
                "warn",
                "spacy installed but en_core_web_sm model missing — NER disabled",
            )
    except ImportError:
        pass  # spaCy is optional; silently omit

    # 13. MCP server commands (needed for configured servers)
    if fs_entries:
        cmds_checked: set[str] = set()
        for entry in fs_entries:
            if entry.command in cmds_checked:
                continue
            cmds_checked.add(entry.command)
            if not shutil.which(entry.command):
                report.add(
                    "MCP runtime",
                    "fail",
                    f"{entry.command} not found — {entry.name} connector will fail",
                )
                continue
            # For absolute-path commands (e.g. nvm-managed npx), verify node
            # is reachable — npx uses #!/usr/bin/env node which fails if node
            # isn't on PATH in the service environment.
            if os.path.isabs(entry.command):
                cmd_dir = str(Path(entry.command).parent)
                node_path = shutil.which(
                    "node", path=f"{cmd_dir}:{os.environ.get('PATH', '')}"
                )
                if node_path:
                    report.add(
                        "MCP runtime",
                        "ok",
                        f"{entry.command} found (node: {node_path})",
                    )
                else:
                    report.add(
                        "MCP runtime",
                        "warn",
                        f"{entry.command} found but node not on PATH — server may fail to start",
                    )
            else:
                report.add("MCP runtime", "ok", f"{entry.command} found")

    # 14. Resource telemetry
    try:
        from memex.resource_telemetry import get_telemetry_store

        rt_store = get_telemetry_store()
        if rt_store is not None:
            latest = rt_store.latest()
            if latest:
                rss_mb = latest["rss_mb"]
                fds = latest["fd_count"]
                threads = latest["thread_count"]
                warn_msgs = [msg for _, msg in latest.get("warnings", [])]
                detail = f"rss={rss_mb}MB threads={threads} fds={fds}"
                if warn_msgs:
                    report.add(
                        "Resource telemetry",
                        "warn",
                        f"{detail} [{'; '.join(warn_msgs)}]",
                    )
                else:
                    report.add("Resource telemetry", "ok", detail)
            else:
                report.add("Resource telemetry", "ok", "initialized, no data yet")
        else:
            report.add(
                "Resource telemetry", "ok", "not initialized (service not running)"
            )
    except Exception as exc:
        report.add("Resource telemetry", "warn", f"check failed: {exc}")

    # 12. Goal summary (via FathomDB)
    try:
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore

        fathom_path = str(Path(store_path).parent / "fathom.db")
        store = FathomMemexStore(FathomStore.open(fathom_path))
        try:
            all_goals = store.list_goals()
            from memex.models import GoalStatus

            active = sum(1 for g in all_goals if g.status == GoalStatus.ACTIVE)
            session = store.load_session()
            goal_detail = f"{len(all_goals)} total, {active} active"
            report.add("Goals", "ok", goal_detail)
            if session:
                report.add(
                    "Session",
                    "ok",
                    f"{session.session_id[:8]} ({session.turn_count} turns)",
                )
            else:
                report.add("Session", "ok", "none active")
        finally:
            store.close()
    except Exception as exc:
        report.add("Goals", "warn", f"could not read: {exc}")

    try:
        from memex.agent_self_model import (
            apply_diagnostics_observation,
            load_agent_self_model,
            save_agent_self_model,
        )
        from memex.fathom_facade import FathomMemexStore as _FMS
        from memex.fathom_store import FathomStore as _FS

        fathom_path = str(Path(store_path).parent / "fathom.db")
        store = _FMS(_FS.open(fathom_path))
        try:
            diagnostics = {
                "ok": report.ok,
                "checks": [
                    {"name": check.name, "status": check.status, "detail": check.detail}
                    for check in report.checks
                ],
            }
            model = apply_diagnostics_observation(
                load_agent_self_model(store), diagnostics
            )
            save_agent_self_model(model, store)
        finally:
            store.close()
    except Exception:
        logger.debug("Failed to persist doctor diagnostics", exc_info=True)

    if _is_fresh_setup(report):
        _print_getting_started()

    return report


def _is_fresh_setup(report: DoctorReport) -> bool:
    """Heuristic: LLM key present + zero active goals = fresh setup ready to go."""
    has_llm = any(c.name == "LLM API key" and c.status == "ok" for c in report.checks)
    goals_check = next((c for c in report.checks if c.name == "Goals"), None)
    has_zero_goals = goals_check is not None and "0 active" in (
        goals_check.detail or ""
    )
    return has_llm and has_zero_goals


def _print_getting_started() -> None:
    bar = "─" * 60
    print()
    print(bar)
    print("  Getting Started")
    print(bar)
    print("  1. Install and start the service daemon:")
    print("       memex install-service")
    print("       # or run in foreground: memex service")
    print()
    print("  2. Open the TUI in a second terminal:")
    print("       memex tui")
    print()
    print("  3. Or use CLI chat directly (no daemon needed):")
    print("       memex chat")
    print()
    print("  4. Create your first goal:")
    print("       Press 'a' in TUI, or just describe what you're working on in chat")
    print(bar)


# ---------------------------------------------------------------------------
# Backfill conversation search (search_text + embeddings)
# ---------------------------------------------------------------------------


def backfill_conversation_search(
    conn: sqlite3.Connection,
    *,
    embedding_backend: object | None = None,
    batch_size: int = 100,
) -> dict[str, int]:
    """Backfill search_text and conversation_embeddings for existing rows.

    Takes an existing connection (with v10 schema already applied) to avoid
    double-opening the database or missing migrations.

    Args:
        conn: SQLite connection from an existing MemexStore.
        embedding_backend: Optional EmbeddingBackend for batch-embedding turns.
            If None, only search_text enrichment runs (cheap, fast).
        batch_size: Commit interval for search_text updates.

    Returns dict with counts: {"enriched": N, "embedded": N}.
    """
    from memex.memory.conversation_search import (
        build_search_text,
        embed_conversation_turn,
    )

    counts = {"enriched": 0, "embedded": 0}

    # 1. Backfill search_text for rows where it's NULL
    try:
        rows = conn.execute(
            "SELECT id, content FROM conversation_log WHERE search_text IS NULL"
        ).fetchall()
        for row in rows:
            row_id = row[0] if isinstance(row, tuple) else row["id"]
            content = row[1] if isinstance(row, tuple) else row["content"]
            search_text = build_search_text(content)
            conn.execute(
                "UPDATE conversation_log SET search_text = ? WHERE id = ?",
                (search_text, row_id),
            )
            counts["enriched"] += 1
            if counts["enriched"] % batch_size == 0:
                conn.commit()
        conn.commit()
    except Exception:
        logger.warning("search_text backfill failed", exc_info=True)

    # 2. Batch-embed existing turn pairs (optional, expensive)
    if embedding_backend is not None:
        try:
            # Find assistant rows without embeddings
            rows = conn.execute(
                """SELECT cl.id, cl.session_id, cl.content
                   FROM conversation_log cl
                   LEFT JOIN conversation_embeddings ce ON ce.row_id = cl.id
                   WHERE ce.row_id IS NULL AND cl.role = 'assistant'
                   ORDER BY cl.id"""
            ).fetchall()

            for row in rows:
                row_id = row[0] if isinstance(row, tuple) else row["id"]
                session_id = row[1] if isinstance(row, tuple) else row["session_id"]
                content = row[2] if isinstance(row, tuple) else row["content"]

                # Find the preceding human turn in the same session
                human_row = conn.execute(
                    """SELECT content FROM conversation_log
                       WHERE session_id = ? AND id < ? AND role = 'human'
                       ORDER BY id DESC LIMIT 1""",
                    (session_id, row_id),
                ).fetchone()
                if human_row is None:
                    continue

                human_content = (
                    human_row[0]
                    if isinstance(human_row, tuple)
                    else human_row["content"]
                )
                embed_conversation_turn(
                    conn,
                    row_id,
                    human_content,
                    content,
                    embedding_backend,
                )
                counts["embedded"] += 1
        except Exception:
            logger.warning("Conversation embedding backfill failed", exc_info=True)

    return counts


# ---------------------------------------------------------------------------
# Startup POST — runs at every startup via MemexAPI.create()
# ---------------------------------------------------------------------------


def startup_post(project_root: Path | None = None) -> DoctorReport:
    """Lightweight power-on self-test that runs at every startup.

    Same checks as doctor(), but results are logged instead of printed.
    Returns the report so callers (MemexAPI, TUI) can display warnings.
    """
    # Clean stale service.url left by a previous crash (SIGKILL bypasses finally)
    try:
        from memex.paths import resolve_service_url_file

        url_file = resolve_service_url_file()
        if url_file.exists():
            import urllib.request

            url = url_file.read_text().strip()
            try:
                urllib.request.urlopen(url + "/v1/status", timeout=1)  # nosec B310 — URL from local service.url file
            except OSError:
                # Service URL file points to a dead process — clean it up
                url_file.unlink(missing_ok=True)
                logger.info("Removed stale service.url (%s)", url)
    except Exception:
        logger.debug("service.url cleanup check failed", exc_info=True)

    # Backup databases before anything else
    backup_ok = True
    try:
        from memex.backup import backup_all

        results = backup_all(tag="startup")
        backed = [k for k, v in results.items() if v is not None]
        failed = [k for k, v in results.items() if v is None]
        if backed:
            logger.info("Startup backup: %s", ", ".join(backed))
        if failed:
            backup_ok = False
            logger.warning("Startup backup incomplete — failed: %s", ", ".join(failed))
    except Exception:
        backup_ok = False
        logger.warning("Startup backup failed", exc_info=True)

    # Backfill conversation search_text for any un-enriched rows.
    # Fast (string concat + UPDATE, no LLM calls). Embeddings skipped
    # at startup — run `memex backfill-conversations --embed` for those.
    logger.debug("startup_post: starting conversation search backfill")
    try:
        from memex.paths import resolve_store_path as _resolve

        store_path = _resolve()
        if Path(store_path).exists():
            conn = sqlite3.connect(store_path)
            conn.row_factory = sqlite3.Row
            # Check if search_text column exists (v10+ schema)
            cols = [
                r[1]
                for r in conn.execute("PRAGMA table_info(conversation_log)").fetchall()
            ]
            if "search_text" in cols:
                result = backfill_conversation_search(conn, embedding_backend=None)
                if result["enriched"] > 0:
                    logger.info(
                        "Backfilled search_text for %d conversation rows",
                        result["enriched"],
                    )
            conn.close()
    except Exception:
        logger.debug("Conversation search backfill at startup failed", exc_info=True)

    logger.debug("startup_post: backfill done, calling doctor()")
    report = doctor(project_root)

    # Surface backup status in the report
    if not backup_ok:
        report.add("Startup backup", "warn", "one or more backups failed — check logs")

    for check in report.checks:
        if check.status == "ok":
            logger.info("POST %s: %s", check.name, check.detail)
        elif check.status == "warn":
            logger.warning("POST %s: %s", check.name, check.detail)
        else:
            logger.error("POST %s: %s", check.name, check.detail)

    if report.ok:
        logger.info("POST complete — all checks passed")
    else:
        fails = [c for c in report.checks if c.status == "fail"]
        logger.error(
            "POST complete — %d check(s) failed: %s",
            len(fails),
            ", ".join(c.name for c in fails),
        )

    return report
