"""Deterministic prompt-control helpers for the 0.8 migration slice."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib
from typing import Any

from memex.agent_self_model import guarded_route_reason, has_guarded_route_signal
from memex.models import (
    InputClassification,
    IntentFrame,
    IntentFramePath,
    PromptControlArtifact,
    PromptControlLintWarning,
    PromptControlPlanSnapshot,
    PromptControlRouteProfile,
)
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

_DEFAULT_CUES: dict[str, tuple[str, ...]] = {
    "creative": ("poet", "story", "fantasy", "roleplay", "imagine"),
    "persona": ("pretend", "act as", "you are a", "character"),
    "jailbreak": (
        "ignore previous instructions",
        "without telling",
        "bypass",
        "secretly",
        "trick",
    ),
    "social": ("draft", "reply", "respond", "email", "message"),
    "research": (
        "verify",
        "source",
        "sources",
        "citation",
        "citations",
        "cross-check",
        "latest",
        "recent",
    ),
    "high_stakes": (
        "medical",
        "diagnosis",
        "treatment",
        "prescribe",
        "legal",
        "lawsuit",
        "contract",
        "finance",
        "investment",
        "tax",
        "compliance",
    ),
}


def load_signal_cues(project_root: Path | None = None) -> dict[str, tuple[str, ...]]:
    """Load signal cues from SIGNALS.toml, falling back to defaults per section."""
    root = project_root or Path.cwd()
    signals_file = root / "SIGNALS.toml"
    if not signals_file.exists():
        return _DEFAULT_CUES
    try:
        with open(signals_file, "rb") as f:
            data = tomllib.load(f)
        result: dict[str, tuple[str, ...]] = {}
        for key, default in _DEFAULT_CUES.items():
            section = data.get(key, {})
            cues = section.get("cues") if isinstance(section, dict) else None
            if isinstance(cues, list):
                result[key] = tuple(str(c) for c in cues)
            else:
                result[key] = default
        return result
    except Exception:
        logger.warning("Failed to load SIGNALS.toml, using defaults", exc_info=True)
        return _DEFAULT_CUES


_ROUTE_POLICIES: dict[
    PromptControlRouteProfile,
    tuple[str, str, str, str],
] = {
    PromptControlRouteProfile.ANALYTIC_STRICT: (
        "limited_if_needed",
        "consistency_check",
        "preferences_only",
        "structured_answer",
    ),
    PromptControlRouteProfile.CREATIVE_OPEN: (
        "minimal_tools",
        "light_structure_check",
        "no_memory_by_default",
        "creative_response",
    ),
    PromptControlRouteProfile.OPERATIONAL_TOOL: (
        "enabled_per_permission",
        "action_result_check",
        "task_state",
        "action_summary",
    ),
    PromptControlRouteProfile.RESEARCH_VERIFIED: (
        "retrieval_and_verification",
        "citation_cross_check",
        "sources_and_conclusions",
        "cited_answer",
    ),
    PromptControlRouteProfile.SOCIAL_DRAFT: (
        "read_only_optional",
        "tone_intent_check",
        "user_requested_only",
        "social_draft",
    ),
    PromptControlRouteProfile.GUARDED_REVIEW: (
        "minimal_tools_guarded",
        "safety_scope_check",
        "no_memory_write",
        "guarded_review",
    ),
}


def _contains_any(text: str, phrases: tuple[str, ...]) -> bool:
    return any(phrase in text for phrase in phrases)


def _collect_signals(
    text: str,
    cues: dict[str, tuple[str, ...]] | None = None,
) -> tuple[set[str], list[PromptControlLintWarning], float, bool]:
    if cues is None:
        cues = _DEFAULT_CUES
    signals: set[str] = set()
    lint: list[PromptControlLintWarning] = []
    stylization_drift = 0.0

    if _contains_any(text, cues.get("creative", ())):
        signals.add("creative_mode")
        stylization_drift += 0.4
    if _contains_any(text, cues.get("persona", ())):
        signals.add("persona_drift")
        stylization_drift += 0.35
    if _contains_any(text, cues.get("jailbreak", ())):
        signals.add("jailbreak_risk")
        lint.append(
            PromptControlLintWarning(
                warning_type="prompt_injection_risk",
                severity="high",
                message="Instruction-override or jailbreak-adjacent language detected.",
            )
        )
    if _contains_any(text, cues.get("social", ())):
        signals.add("social_request")
    if _contains_any(text, cues.get("research", ())):
        signals.add("verification_needed")

    high_stakes = _contains_any(text, cues.get("high_stakes", ()))
    if high_stakes:
        signals.add("high_stakes")

    return signals, lint, min(stylization_drift, 1.0), high_stakes


def _choose_route_profile(
    classification: InputClassification,
    intent_frame: IntentFrame,
    *,
    signals: set[str],
    high_stakes: bool,
    agent_self_model: object | None,
) -> tuple[PromptControlRouteProfile, str]:
    if agent_self_model is not None and has_guarded_route_signal(agent_self_model):
        return (
            PromptControlRouteProfile.GUARDED_REVIEW,
            f"self-model signal detected; {guarded_route_reason(agent_self_model)}",
        )
    if high_stakes or "jailbreak_risk" in signals:
        return (
            PromptControlRouteProfile.GUARDED_REVIEW,
            "high-stakes or override-risk signals detected",
        )
    if intent_frame.selected_path == IntentFramePath.ACT:
        return (
            PromptControlRouteProfile.OPERATIONAL_TOOL,
            "selected act path requires operational execution policy",
        )
    if "social_request" in signals:
        return (
            PromptControlRouteProfile.SOCIAL_DRAFT,
            "social drafting cues detected",
        )
    if (
        classification.classification.value == "knowledge_query"
        and "verification_needed" in signals
    ):
        return (
            PromptControlRouteProfile.RESEARCH_VERIFIED,
            "knowledge query with explicit verification cues detected",
        )
    if "creative_mode" in signals or "persona_drift" in signals:
        return (
            PromptControlRouteProfile.CREATIVE_OPEN,
            "creative or persona cues detected without high-stakes constraints",
        )
    return (
        PromptControlRouteProfile.ANALYTIC_STRICT,
        "default analytical route selected",
    )


def build_prompt_control_artifact(
    session_id: str,
    *,
    user_input: str,
    classification: InputClassification,
    intent_frame: IntentFrame,
    agent_self_model: Any | None = None,
    plan_snapshot: PromptControlPlanSnapshot | None = None,
    tool_candidate_names: list[str] | None = None,
    intent_id: str | None = None,
    conversation_turn_id: int | None = None,
    project_root: Path | None = None,
    prompt_mode: str = "full",
) -> PromptControlArtifact:
    text = user_input.lower()
    cues = load_signal_cues(project_root)
    signals, lint_warnings, stylization_drift, high_stakes = _collect_signals(
        text, cues
    )
    ambiguity_score = min(1.0, len(intent_frame.unresolved_references) * 0.5)
    artifact_id = f"session:{session_id}:prompt_control:last"
    if conversation_turn_id is not None:
        artifact_id = f"session:{session_id}:prompt_control:turn:{conversation_turn_id}"

    if ambiguity_score > 0:
        lint_warnings.append(
            PromptControlLintWarning(
                warning_type="missing_context",
                severity="medium",
                message="Unresolved references detected; clarification is preferred before acting.",
            )
        )

    if high_stakes and stylization_drift > 0.0:
        lint_warnings.append(
            PromptControlLintWarning(
                warning_type="stylization_drift",
                severity="medium",
                message="Creative or persona language detected in a high-stakes request.",
            )
        )

    if plan_snapshot is not None:
        signals.add("plan_present")
        if plan_snapshot.status in {"done", "completed"}:
            signals.add("plan_complete")
        selected_step = plan_snapshot.selected_step
        if selected_step is not None:
            if selected_step.status == "blocked":
                signals.add("plan_step_blocked")
                lint_warnings.append(
                    PromptControlLintWarning(
                        warning_type="plan_step_blocked",
                        severity="medium",
                        message=(
                            "Current canonical plan step is blocked; avoid inventing progress "
                            "past the blocker without resolving it."
                        ),
                    )
                )
            elif selected_step.status == "in_progress":
                signals.add("plan_step_in_progress")
            elif selected_step.status == "active":
                signals.add("plan_step_ready")

    route_profile, route_rationale = _choose_route_profile(
        classification,
        intent_frame,
        signals=signals,
        high_stakes=high_stakes,
        agent_self_model=agent_self_model,
    )
    if agent_self_model is not None and has_guarded_route_signal(agent_self_model):
        signals.add("self_model_guarded")
    if plan_snapshot is not None:
        route_rationale = (
            f"{route_rationale}; plan={plan_snapshot.title} [{plan_snapshot.status}]"
        )
        if plan_snapshot.selected_step is not None:
            route_rationale += (
                " | step="
                f"{plan_snapshot.selected_step.title} "
                f"[{plan_snapshot.selected_step.status}]"
            )
    tool_policy, validation_policy, memory_policy, response_contract = _ROUTE_POLICIES[
        route_profile
    ]

    return PromptControlArtifact(
        artifact_id=artifact_id,
        session_id=session_id,
        intent_id=intent_id,
        conversation_turn_id=conversation_turn_id,
        raw_input=user_input,
        classification=classification.classification.value,
        selected_path=intent_frame.selected_path.value,
        route_profile=route_profile,
        tool_policy=tool_policy,
        validation_policy=validation_policy,
        memory_policy=memory_policy,
        response_contract=response_contract,
        route_rationale=route_rationale,
        parse_confidence=classification.confidence,
        ambiguity_score=ambiguity_score,
        stylization_drift=stylization_drift,
        high_stakes=high_stakes,
        detected_signals=sorted(signals),
        plan_snapshot=plan_snapshot,
        tool_candidate_names=list(tool_candidate_names or []),
        lint_warnings=lint_warnings,
        prompt_mode=prompt_mode,
        created_at=intent_frame.created_at,
        updated_at=utcnow(),
    )


def render_prompt_control_section(
    artifact: PromptControlArtifact | None,
) -> str:
    """Render a compact prompt-control policy section for prompt assembly."""
    if artifact is None:
        return ""

    lines = [
        "## Prompt Control",
        f"Route profile: {artifact.route_profile.value}",
        f"Selected path: {artifact.selected_path}",
        f"Tool policy: {artifact.tool_policy}",
        f"Validation policy: {artifact.validation_policy}",
        f"Memory policy: {artifact.memory_policy}",
        f"Response contract: {artifact.response_contract}",
    ]
    if artifact.plan_snapshot is not None:
        lines.append(
            f"Plan: {artifact.plan_snapshot.title} [{artifact.plan_snapshot.status}]"
        )
        selected_step = artifact.plan_snapshot.selected_step
        if selected_step is not None:
            step_bits = [selected_step.status]
            if selected_step.progress_pct > 0:
                step_bits.append(f"{selected_step.progress_pct}%")
            lines.append(
                f"Current step: {selected_step.title} [{', '.join(step_bits)}]"
            )
            if selected_step.blocked_reason:
                lines.append(f"Step blocker: {selected_step.blocked_reason}")
    if artifact.tool_candidate_names:
        lines.append("Tool candidates: " + ", ".join(artifact.tool_candidate_names[:8]))
    if artifact.lint_warnings:
        lines.append(
            "Warnings: "
            + ", ".join(warning.warning_type for warning in artifact.lint_warnings)
        )
    return "\n".join(lines)
