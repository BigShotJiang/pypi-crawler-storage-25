"""Persistent key/value settings store.

The live path uses FathomSettingsAdapter (in fathom_facade.py).
This module is kept as a namespace stub; the SettingsStore class
is still referenced by doctor.py for the prompt-budget check against
the legacy SQLite file.
"""

from __future__ import annotations

import os
import sqlite3
from typing import Any
from memex.utcnow import utcnow


class SettingsStore:
    """Read/write access to the user_settings table.

    Resolution order for numeric/string getters:
        user_settings table -> environment variable -> hardcoded default

    NOTE: Only used by doctor.py prompt-budget check against the legacy
    SQLite store.  All runtime settings go through FathomSettingsAdapter.
    """

    def __init__(self, conn: sqlite3.Connection) -> None:
        self._conn = conn

    def get(self, key: str, default: str | None = None) -> str | None:
        """Return the stored string value for key, or default if not set."""
        row = self._conn.execute(
            "SELECT value FROM user_settings WHERE key=?", (key,)
        ).fetchone()
        return row["value"] if row is not None else default

    def get_str(self, key: str, *, default: str = "") -> str:
        """Get a string setting with env-var fallback."""
        stored = self.get(key)
        if stored is not None:
            return stored
        env_val = os.environ.get(f"MEMEX_{key.upper()}")
        if env_val:
            return env_val
        return default

    def get_int(self, key: str, *, default: int = 0) -> int:
        """Get an int setting with env-var fallback."""
        stored = self.get(key)
        if stored is not None:
            try:
                return int(stored)
            except (ValueError, TypeError):
                pass
        env_val = os.environ.get(f"MEMEX_{key.upper()}")
        if env_val:
            try:
                return int(env_val)
            except ValueError:
                pass
        return default

    def get_float(self, key: str, *, default: float = 0.0) -> float:
        """Get a float setting with env-var fallback."""
        stored = self.get(key)
        if stored is not None:
            try:
                return float(stored)
            except (ValueError, TypeError):
                pass
        env_val = os.environ.get(f"MEMEX_{key.upper()}")
        if env_val:
            try:
                return float(env_val)
            except ValueError:
                pass
        return default

    def set(self, key: str, value: Any) -> None:
        """Upsert a setting."""
        now = utcnow().isoformat()
        self._conn.execute(
            """INSERT INTO user_settings (key, value, updated_at)
               VALUES (?, ?, ?)
               ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
            (key, str(value), now),
        )
        self._conn.commit()

    def delete(self, key: str) -> bool:
        """Remove a setting. Returns True if the key existed."""
        cur = self._conn.execute("DELETE FROM user_settings WHERE key=?", (key,))
        self._conn.commit()
        return cur.rowcount > 0

    def list_all(self) -> list[dict]:
        """Return all stored settings as a list of {key, value, updated_at} dicts."""
        rows = self._conn.execute(
            "SELECT key, value, updated_at FROM user_settings ORDER BY key"
        ).fetchall()
        return [dict(r) for r in rows]
