"""Tool registry with relevance filtering."""

from __future__ import annotations

import logging
import re

from memex.models import ToolDefinition
from memex.security import filter_permitted_tools

logger = logging.getLogger(__name__)

_CAPABILITY_SIGNAL_RULES: dict[str, tuple[str, ...]] = {
    "comm.gmail": ("gmail", "email", "mail", "inbox"),
    "content.web": (
        "url",
        "link",
        "website",
        "web page",
        "article",
        "youtube",
        "video",
    ),
    "web.fetch": ("fetch", "browse", "download", "open page", "read page"),
    "memory.search": (
        "search",
        "find",
        "lookup",
        "recall",
        "what do you remember",
        "remember about",
        "what do you know",
        "knowledge",
        "stored",
        "saved",
    ),
    "memory.write": (
        "remember this",
        "save this",
        "store this",
        "note this",
        "remind me",
        "bookmark this",
        "capture this",
        "remember",
        "save",
        "store",
        "note",
    ),
    "conversation.search": (
        "conversation",
        "chat history",
        "earlier",
        "previous",
        "said",
        "discussed",
        "talked about",
    ),
    "goals.read": ("goal", "goals", "intent", "objective", "priority", "working on"),
    "reminders.read": (
        "reminder",
        "reminders",
        "calendar",
        "upcoming",
        "scheduled",
        "agenda",
        "deadline",
    ),
    "system.inspect": (
        "status",
        "state",
        "runtime",
        "system",
        "yourself",
        "self",
        "connectors",
        "services",
        "plugins",
    ),
    "system.diagnostics": (
        "diagnostic",
        "diagnostics",
        "health check",
        "health",
        "check system",
        "system health",
    ),
    "system.repair": ("repair", "fix", "reset", "restart", "recover"),
    "system.logs": ("log", "logs", "error", "warning", "traceback", "crash"),
}

_TOKEN_RE = re.compile(r"[a-z0-9_+.-]+")


def _extract_capability_signals(
    user_input: str,
    *,
    classification: str | None = None,
    intent_path: str | None = None,
) -> set[str]:
    text = user_input.lower()
    signals: set[str] = set()
    for tag, phrases in _CAPABILITY_SIGNAL_RULES.items():
        if any(phrase in text for phrase in phrases):
            signals.add(tag)

    tokens = set(_TOKEN_RE.findall(text))
    if {"health", "check"} <= tokens:
        signals.add("system.diagnostics")
    if {"what", "remember"} <= tokens:
        signals.add("memory.search")

    if classification == "knowledge_query":
        signals.add("memory.search")
    elif classification == "clarification":
        signals.add("system.inspect")

    if intent_path == "direct_answer":
        signals.add("memory.search")

    return signals


class ToolRegistry:
    """Manages available tools and provides context-aware selection."""

    def __init__(self) -> None:
        self._tools: dict[str, ToolDefinition] = {}
        self._aliases: dict[str, str] = {}

    def register(self, tool: ToolDefinition) -> None:
        self._tools[tool.name] = tool
        for alias in tool.aliases:
            self._aliases[alias] = tool.name
        try:
            from memex.event_bus import get_bus
            from memex.events import ToolRegistered

            get_bus().publish(
                ToolRegistered(
                    tool_name=tool.name,
                    source=tool.source,
                    aliases=tuple(tool.aliases),
                )
            )
        except Exception:
            pass  # event bus may not be started yet during early startup

    def unregister_source(self, source: str) -> None:
        to_remove = {k for k, v in self._tools.items() if v.source == source}
        self._aliases = {a: c for a, c in self._aliases.items() if c not in to_remove}
        for name in to_remove:
            tool = self._tools[name]
            try:
                from memex.event_bus import get_bus
                from memex.events import ToolUnregistered

                get_bus().publish(
                    ToolUnregistered(
                        tool_name=name,
                        source=tool.source,
                    )
                )
            except Exception:
                pass
        self._tools = {k: v for k, v in self._tools.items() if v.source != source}

    def get_tool(self, name: str) -> ToolDefinition | None:
        canonical = self._aliases.get(name, name)
        return self._tools.get(canonical)

    def register_alias(self, alias: str, canonical: str) -> None:
        """Register an alias that maps to a canonical tool name."""
        self._aliases[alias] = canonical

    def resolve_alias(self, name: str) -> str:
        """Resolve an alias to its canonical tool name, or return name as-is."""
        return self._aliases.get(name, name)

    def all_tools(self) -> list[ToolDefinition]:
        return list(self._tools.values())

    def get_tools_for_context(
        self,
        user_input: str,
        active_goals: list[str],
        granted_capabilities: set[str],
        *,
        max_tools: int = 15,
        classification: str | None = None,
        intent_path: str | None = None,
        usage_boosts: dict[str, int] | None = None,
        blocked_capability_tags: set[str] | None = None,
    ) -> list[ToolDefinition]:
        """Select the most relevant tools for the current context.

        1. Capability filter
        2. Separate always_present tools
        3. Score remaining by capability signals + keyword overlap
        4. Exclude zero-scored tools (unless neutral or boosted by usage)
        5. Cap at max_tools (reduced for conversational turns)
        """
        # Conversational/clarification turns rarely need many tools
        if classification in ("conversational", "clarification"):
            max_tools = min(max_tools, 5)

        permitted = filter_permitted_tools(self.all_tools(), granted_capabilities)
        if not permitted:
            return []
        blocked_capability_tags = set(blocked_capability_tags or ())

        # Build context string for substring matching
        context_text = user_input.lower()
        for title in active_goals:
            context_text += " " + title.lower()
        capability_signals = _extract_capability_signals(
            user_input,
            classification=classification,
            intent_path=intent_path,
        )

        # Score tools by routing signals and keyword overlap.
        scored: list[
            tuple[float, bool, bool, ToolDefinition]
        ] = []  # (score, always_present, has_scoring_inputs, tool)
        for tool in permitted:
            if (
                blocked_capability_tags
                and set(tool.capability_tags) & blocked_capability_tags
            ):
                continue
            if (
                intent_path is not None
                and tool.supported_intent_paths
                and intent_path not in set(tool.supported_intent_paths)
            ):
                continue

            score = 0.0
            has_scoring_inputs = bool(tool.keywords or tool.capability_tags)

            capability_overlap = len(set(tool.capability_tags) & capability_signals)
            score += capability_overlap * 2.0

            if (
                classification
                and tool.preferred_classifications
                and classification in tool.preferred_classifications
            ):
                score += 1.5

            if (
                intent_path
                and tool.supported_intent_paths
                and intent_path in tool.supported_intent_paths
            ):
                score += 0.5

            if not tool.keywords:
                boost = 0.0
                if usage_boosts and tool.name in usage_boosts:
                    boost = min(usage_boosts[tool.name] / 10.0, 2.0)
                score += boost
                scored.append((score, tool.always_present, has_scoring_inputs, tool))
                continue

            overlap = sum(1 for kw in tool.keywords if kw.lower() in context_text)
            score += float(overlap)
            if usage_boosts and tool.name in usage_boosts:
                score += min(usage_boosts[tool.name] / 10.0, 2.0)
            scored.append((score, tool.always_present, has_scoring_inputs, tool))

        scored.sort(key=lambda x: (x[0], x[1]), reverse=True)

        eligible = [
            (score, always_present, tool)
            for score, always_present, has_scoring_inputs, tool in scored
            if always_present or not has_scoring_inputs or score > 0
        ]

        always_names = {
            tool.name for _score, always_present, tool in eligible if always_present
        }
        result: list[ToolDefinition] = []

        for _score, _always_present, tool in eligible:
            if tool.name in always_names and tool not in result:
                result.append(tool)

        for _score, _always_present, tool in eligible:
            if tool in result:
                continue
            result.append(tool)
            if len(result) >= max_tools:
                break

        if len(result) > max_tools:
            result = result[:max_tools]

        score_map = {tool.name: score for score, _always_present, tool in eligible}
        result.sort(
            key=lambda tool: (score_map.get(tool.name, 0.0), tool.always_present),
            reverse=True,
        )
        return result

    def get_matched_keywords(self, tool_name: str, context_text: str) -> list[str]:
        """Return which keywords matched for a tool in the given context."""
        tool = self._tools.get(tool_name)
        if not tool or not tool.keywords:
            return []
        lower = context_text.lower()
        return [kw for kw in tool.keywords if kw.lower() in lower]


def to_openai_tools(tools: list[ToolDefinition]) -> list[dict]:
    """Convert ToolDefinitions to OpenAI-format tool schemas for LLM."""
    result = []
    for t in tools:
        result.append(
            {
                "type": "function",
                "function": {
                    "name": t.name,
                    "description": t.description,
                    "parameters": t.parameters or {"type": "object", "properties": {}},
                },
            }
        )
    return result
