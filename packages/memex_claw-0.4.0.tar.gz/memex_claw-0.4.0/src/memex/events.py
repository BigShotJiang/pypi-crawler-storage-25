"""Domain events — frozen dataclasses with no application imports.

These are pure data carriers. The event bus dispatches them by type.
Subscribing to a base class (e.g. GoalChanged) receives all subclass events.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from memex.utcnow import utcnow


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DomainEvent:
    """Base for all domain events."""

    timestamp: datetime = field(default_factory=lambda: utcnow())


# ---------------------------------------------------------------------------
# Goal events
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class GoalChanged(DomainEvent):
    """Base for all goal mutations. Subscribe here to catch everything."""

    goal_id: str = ""
    title: str = ""


@dataclass(frozen=True)
class GoalCreated(GoalChanged):
    """A new goal was created."""

    parent_id: str | None = None


@dataclass(frozen=True)
class GoalStatusChanged(GoalChanged):
    """A goal's status changed (completed, paused, blocked, failed, active)."""

    old_status: str = ""
    new_status: str = ""


@dataclass(frozen=True)
class GoalUpdated(GoalChanged):
    """A goal was updated (touched, priority changed) without status change."""


# ---------------------------------------------------------------------------
# Notification events
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class NotificationCreated(DomainEvent):
    """A new notification was created."""

    notification_id: str = ""
    title: str = ""
    priority: str = "normal"
    source: str = ""


@dataclass(frozen=True)
class NotificationDismissed(DomainEvent):
    """A notification was dismissed."""

    notification_id: str = ""


# ---------------------------------------------------------------------------
# Knowledge events
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ItemIngested(DomainEvent):
    """A knowledge item was ingested or re-ingested."""

    item_id: str = ""
    title: str = ""
    item_type: str = "note"
    is_update: bool = False


# ---------------------------------------------------------------------------
# Remember / Forget events
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ItemRemembered(DomainEvent):
    """An item was stored via the remember tool."""

    item_id: str = ""
    title: str = ""
    intent: str = ""  # "fact", "context", "reminder"


@dataclass(frozen=True)
class ItemForgotten(DomainEvent):
    """An item was soft-deleted via the forget tool."""

    item_id: str = ""
    title: str = ""


@dataclass(frozen=True)
class ItemRestored(DomainEvent):
    """A soft-deleted item was restored."""

    item_id: str = ""
    title: str = ""


# ---------------------------------------------------------------------------
# Scheduler / work queue events
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TaskRunCompleted(DomainEvent):
    """A scheduled task run finished (success or failure)."""

    task_id: str = ""
    run_id: int = 0
    status: str = ""
    result: str = ""


# ---------------------------------------------------------------------------
# Meeting events
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MeetingStateChanged(DomainEvent):
    """A meeting's lifecycle state changed."""

    meeting_id: str = ""
    title: str = ""
    state: str = ""


@dataclass(frozen=True)
class MeetingTranscribed(DomainEvent):
    """A meeting was transcribed (success or failure)."""

    meeting_id: str = ""
    title: str = ""
    success: bool = True
    item_id: str | None = None


# ---------------------------------------------------------------------------
# Turn events
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TurnFinished(DomainEvent):
    """A conversational turn completed."""

    session_id: str = ""
    interface: str = ""  # "tui", "telegram", "cli", "mcp"


# ---------------------------------------------------------------------------
# Activity / usage events
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ActivityStarted(DomainEvent):
    """A long-running activity started."""

    activity_id: str = ""
    label: str = ""
    source: str = ""
    session_id: str = ""
    background: bool = True


@dataclass(frozen=True)
class ActivityUpdated(DomainEvent):
    """A long-running activity updated its label/progress."""

    activity_id: str = ""
    label: str = ""
    source: str = ""
    session_id: str = ""
    background: bool = True


@dataclass(frozen=True)
class ActivityFinished(DomainEvent):
    """A long-running activity finished."""

    activity_id: str = ""
    label: str = ""
    source: str = ""
    session_id: str = ""
    background: bool = True
    success: bool = True


@dataclass(frozen=True)
class UsageRecorded(DomainEvent):
    """Usage/cost recorded outside the normal turn-complete path."""

    session_id: str = ""
    source: str = ""
    cost_usd: float = 0.0
    total_tokens: int = 0


# ---------------------------------------------------------------------------
# Resource telemetry events
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ResourceSnapshot(DomainEvent):
    """Periodic process resource telemetry snapshot."""

    rss_bytes: int = 0
    vms_bytes: int = 0
    uss_bytes: int = 0
    cpu_percent: float = 0.0
    thread_count: int = 0
    fd_count: int = 0
    fd_limit: int = 0
    children_count: int = 0
    children_rss_bytes: int = 0
    gc_objects: int = 0
    gc_collections: tuple[int, ...] = ()
    uptime_seconds: float = 0.0
    warnings: tuple[str, ...] = ()
    extensions: tuple[tuple[str, str], ...] = ()


# ---------------------------------------------------------------------------
# Tool events
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ToolRegistered(DomainEvent):
    """A tool was registered in the tool registry."""

    tool_name: str = ""
    source: str = ""
    aliases: tuple[str, ...] = ()


@dataclass(frozen=True)
class ToolUnregistered(DomainEvent):
    """A tool was unregistered from the tool registry."""

    tool_name: str = ""
    source: str = ""


# ---------------------------------------------------------------------------
# Sub-agent events
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SubAgentStarted(DomainEvent):
    """A sub-agent was spawned."""

    agent_id: str = ""
    label: str = ""


@dataclass(frozen=True)
class SubAgentCompleted(DomainEvent):
    """A sub-agent finished (success or failure)."""

    agent_id: str = ""
    label: str = ""
    response: str = ""
    success: bool = True
    duration_ms: int = 0


@dataclass(frozen=True)
class SubAgentCancelled(DomainEvent):
    """A sub-agent was cancelled by the user."""

    agent_id: str = ""
    label: str = ""


# ---------------------------------------------------------------------------
# Plugin events
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PluginInstalled(DomainEvent):
    """An OpenClaw plugin was installed."""

    plugin_id: str = ""
    name: str = ""
    version: str = ""


@dataclass(frozen=True)
class PluginUninstalled(DomainEvent):
    """An OpenClaw plugin was uninstalled."""

    plugin_id: str = ""
    name: str = ""
