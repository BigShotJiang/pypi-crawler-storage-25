"""FathomMemexStore -- MemexStore-compatible facade over FathomStore.

Satisfies the MemexStore protocol by delegating all calls to the
appropriate FathomStore sub-repository.
"""

from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime
from typing import Any

from memex.fathom_store import FathomStore, _get_one
from memex.world_model_plans import (
    build_world_model_execution_record_provenance_links,
    build_world_model_plan_step_transition_provenance_links,
)
from memex.models import (
    Notification,
    NotificationPriority,
    AgentSelfModel,
    AuditEntry,
    CalendarEvent,
    ConnectorHealth,
    ConversationTurn,
    Goal,
    GoalEntityLink,
    GoalStatus,
    HumanPartnerProfile,
    Item,
    ItemType,
    MeetingEntityLink,
    MeetingGoalLink,
    PromptControlArtifact,
    SessionContext,
    WorldModelAction,
    WorldModelActionPlan,
    WorldModelClaimEvaluation,
    WorldModelCommitment,
    WorldModelEntity,
    WorldModelEntityAttribute,
    WorldModelEntityType,
    WorldModelEvent,
    WorldModelExecutionRecord,
    WorldModelGoal,
    WorldModelIntent,
    WorldModelKnowledgeEntityLink,
    WorldModelKnowledgeIngestRun,
    WorldModelKnowledgeObject,
    WorldModelKnowledgeRelationship,
    WorldModelObservation,
    WorldModelPlanStep,
    WorldModelPlanStepTransition,
    WorldModelProvenanceLink,
    WorldModelSemanticMapping,
    WorldModelTask,
    TaskRun,
)
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)


def _build_knowledge_metadata(metadata: dict[str, Any]) -> dict[str, Any]:
    """Whitelist only the metadata fields that downstream readers consume.

    The full item.metadata dict (especially for meetings) includes
    canonical_activity_audit and canonical_promotion_audit blobs that no
    code in src/memex structurally reads off the knowledge-object payload.
    See dev/notes/metadata-bloat-design.md for the analysis.
    """
    if not isinstance(metadata, dict):
        return {}
    meeting = metadata.get("meeting")
    if not isinstance(meeting, dict):
        return {}
    trimmed_meeting: dict[str, Any] = {}
    meeting_id = meeting.get("meeting_id")
    if meeting_id is not None:
        trimmed_meeting["meeting_id"] = meeting_id
    semantic = meeting.get("semantic")
    if isinstance(semantic, dict):
        trimmed_semantic: dict[str, Any] = {}
        for key in ("decisions", "outcomes", "commitments", "goal_links"):
            if key in semantic:
                trimmed_semantic[key] = semantic[key]
        if trimmed_semantic:
            trimmed_meeting["semantic"] = trimmed_semantic
    return {"meeting": trimmed_meeting} if trimmed_meeting else {}


def make_fathom_store(store_path: str | None = None) -> FathomMemexStore:
    """Shared factory: open FathomDB and return a MemexStore-compatible facade.

    Derives the fathom.db path from the MEMEX_STORE anchor directory.
    """
    from pathlib import Path

    from memex.paths import resolve_store_path

    p = store_path or resolve_store_path()
    fathom_path = str(Path(p).parent / "fathom.db")
    return FathomMemexStore(FathomStore.open(fathom_path))


def _enum_val(v: Any) -> Any:
    """Extract .value from enums, pass through other types."""
    return v.value if hasattr(v, "value") else v


def _dt_iso(v: Any) -> str | None:
    """Return ISO-8601 string for a datetime, or None."""
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.isoformat()
    return str(v)


# ---------------------------------------------------------------------------
# Sub-store adapters
# ---------------------------------------------------------------------------


class FathomSettingsAdapter:
    """SettingsStore-compatible adapter backed by FathomStore operational repo."""

    def __init__(self, fathom: FathomStore) -> None:
        self._fathom = fathom

    def get(self, key: str, default: str | None = None) -> str | None:
        """Return setting value by key."""
        val = self._fathom.operational.get_setting(key)
        return val if val is not None else default

    def get_str(self, key: str, *, default: str = "") -> str:
        """Return setting as string."""
        stored = self.get(key)
        if stored is not None:
            return stored
        env_val = os.environ.get(f"MEMEX_{key.upper()}")
        if env_val:
            return env_val
        return default

    def get_int(self, key: str, *, default: int = 0) -> int:
        """Return setting as integer."""
        stored = self.get(key)
        if stored is not None:
            try:
                return int(stored)
            except (ValueError, TypeError):
                pass
        env_val = os.environ.get(f"MEMEX_{key.upper()}")
        if env_val:
            try:
                return int(env_val)
            except ValueError:
                pass
        return default

    def get_float(self, key: str, *, default: float = 0.0) -> float:
        """Return setting as float."""
        stored = self.get(key)
        if stored is not None:
            try:
                return float(stored)
            except (ValueError, TypeError):
                pass
        env_val = os.environ.get(f"MEMEX_{key.upper()}")
        if env_val:
            try:
                return float(env_val)
            except ValueError:
                pass
        return default

    def set(self, key: str, value: Any) -> None:
        """Store a setting value."""
        self._fathom.operational.put_setting(key, str(value))

    def delete(self, key: str) -> bool:
        """Delete a setting by key."""
        current = self._fathom.operational.get_setting(key)
        if current is None:
            return False
        self._fathom.operational.delete_setting(key)
        return True

    def list_all(self) -> list[dict]:
        """Return all settings."""
        rows = self._fathom.operational.list_settings()
        return [
            {
                "key": r.get("key", ""),
                "value": r.get("value", ""),
                "updated_at": r.get("updated_at", ""),
            }
            for r in rows
        ]


class FathomContentAdapter:
    """ContentStore-compatible adapter backed by FathomStore.knowledge.

    Implements the full ContentStore protocol so callers that access
    store.content (scheduler tasks, retrieval, forget, fact_store,
    cold_storage) work against fathomdb.
    """

    _VERSION_COLLECTION = "version_snapshots"

    def __init__(self, fathom: FathomStore) -> None:
        self._fathom = fathom
        self._version_coll_ready = False

    # ── Ingest / CRUD ───────────────────────────────────────────────

    def ingest(self, item: Item) -> str:
        """Ingest a knowledge item."""
        return self._fathom.knowledge.ingest(
            item.item_id,
            item.title,
            item.body,
            item.type.value if hasattr(item.type, "value") else str(item.type),
            source_url=item.source_url,
            author=item.author,
            tags=item.tags,
            summary=item.summary.text if item.summary else None,
            metadata=item.metadata,
            pinned=item.pinned,
            provenance=item.provenance.model_dump(mode="json")
            if item.provenance
            else None,
        )

    def create_item(self, item: Item) -> None:
        """Create a knowledge item."""
        self.ingest(item)
        knowledge_id = f"ki-{item.item_id}"
        self._fathom.world_model.upsert_knowledge_object(
            knowledge_id,
            item.item_id,
            item.type.value if hasattr(item.type, "value") else str(item.type),
            item.source_url or item.item_id,
            title=item.title,
            source_url=item.source_url,
            source_surface="memex:knowledge-sync",
        )

    def upsert_item(self, item: Item) -> None:
        """Create or update a knowledge item."""
        self._fathom.knowledge.upsert_item(
            item.item_id,
            item.title,
            item.body,
            item.type.value if hasattr(item.type, "value") else str(item.type),
            source_url=item.source_url,
            author=item.author,
            tags=item.tags,
            summary=item.summary.text if item.summary else None,
            metadata=item.metadata,
            pinned=item.pinned,
            provenance=item.provenance.model_dump(mode="json")
            if item.provenance
            else None,
        )

    def get_item(self, item_id: str) -> Item | None:
        """Return item by ID."""
        return self._fathom.knowledge.get(item_id)

    # Keep legacy name for callers that use .get()
    def get(self, item_id: str) -> Item | None:
        """Return item by ID."""
        return self._fathom.knowledge.get(item_id)

    def get_items_batch(self, item_ids: list[str]) -> dict[str, Item]:
        """Fetch multiple items by ID."""
        items = self._fathom.knowledge.get_items_batch(item_ids)
        return {it.item_id: it for it in items}

    def update_item(self, item: Item) -> None:
        """Update an existing item."""
        self._fathom.knowledge.update(
            item.item_id,
            title=item.title,
            body=item.body,
            item_type=item.type.value
            if hasattr(item.type, "value")
            else str(item.type),
            source_url=item.source_url,
            author=item.author,
            tags=item.tags,
            summary=item.summary.text if item.summary else None,
            metadata=item.metadata,
            pinned=item.pinned,
        )

    def delete_item(self, item_id: str) -> None:
        """Hard-delete an item."""
        self._fathom.knowledge.delete_item(item_id)

    def find_by_url(self, url: str) -> Item | None:
        """Find item by source URL."""
        if url is None:
            return None
        return self._fathom.knowledge.find_by_url(url)

    def touch_item(self, item_id: str) -> None:
        """Update last_accessed timestamp."""
        self._fathom.knowledge.touch(item_id)

    def search(self, query: str, *, limit: int = 20) -> list[Item]:
        """Search items by query."""
        return self._fathom.knowledge.search(query, limit=limit)

    # ── list_items (ContentStore protocol signature) ────────────────

    def list_items(
        self,
        *,
        type: ItemType | None = None,
        pinned: bool | None = None,
        include_expired: bool = False,
        limit: int = 50,
        now: datetime | None = None,
    ) -> list[Item]:
        """List items with optional filters matching ContentStore protocol."""
        type_str = type.value if type is not None else None
        items = self._fathom.knowledge.list(
            item_type=type_str,
            pinned=pinned,
            limit=limit,
        )
        # Client-side filtering for fields fathomdb doesn't filter natively
        if not include_expired:
            current = (now or utcnow()).isoformat()
            items = [
                it
                for it in items
                if it.expires_at is None or it.expires_at.isoformat() > current
            ]
        return items

    # ── FTS search ──────────────────────────────────────────────────

    def fts_search(
        self,
        query: str,
        *,
        limit: int = 20,
        include_expired: bool = False,
        now: datetime | None = None,
        item_type: ItemType | None = None,
    ) -> list[tuple[Item, float]]:
        """Full-text search via fathomdb text_search.

        Returns (Item, relevance) tuples. fathomdb text_search does not
        return scores, so relevance is assigned by rank position (1.0 for
        first result, decaying linearly).
        """
        items = self._fathom.knowledge.search(query, limit=limit)
        # Client-side filters
        if item_type is not None:
            type_val = item_type.value if hasattr(item_type, "value") else item_type
            items = [
                it
                for it in items
                if (it.type.value if hasattr(it.type, "value") else it.type) == type_val
            ]
        if not include_expired:
            current = (now or utcnow()).isoformat()
            items = [
                it
                for it in items
                if it.expires_at is None or it.expires_at.isoformat() > current
            ]
        # Assign synthetic relevance scores by rank position
        results: list[tuple[Item, float]] = []
        for i, item in enumerate(items[:limit]):
            score = max(0.1, 1.0 - (i * 0.9 / max(limit - 1, 1)))
            results.append((item, score))
        return results

    # ── Soft-delete / restore / purge ───────────────────────────────

    def soft_delete_item(self, item_id: str) -> bool:
        """Soft-delete an item. Returns False if item not found."""
        try:
            if self._fathom.knowledge.get(item_id) is None:
                return False
            self._fathom.knowledge.soft_delete(item_id)
            return True
        except Exception:
            return False

    def restore_item(self, item_id: str) -> bool:
        """Restore a soft-deleted item. Returns False if item not found."""
        try:
            raw = _get_one(
                self._fathom.knowledge._engine,
                self._fathom.knowledge.ITEM_KIND,
                f"item:{item_id}",
            )
            if raw is None or raw.get("deleted_at") is None:
                return False
            self._fathom.knowledge.restore(item_id)
            return True
        except Exception:
            return False

    def purge_deleted(self, older_than: datetime) -> int:
        """Permanently remove soft-deleted items older than the cutoff."""
        return self._fathom.knowledge.purge_soft_deleted(older_than)

    def list_soft_deleted(self, *, limit: int = 50) -> list[Item]:
        """List soft-deleted items."""
        return self._fathom.knowledge.list_soft_deleted(limit=limit)

    # ── Versioning ──────────────────────────────────────────────────

    def _ensure_version_collection(self) -> None:
        """Lazily register the version_snapshots operational collection."""
        if self._version_coll_ready:
            return
        from fathomdb import (
            OperationalCollectionKind,
            OperationalRegisterRequest,
        )

        engine = self._fathom.engine
        existing = engine.admin.describe_operational_collection(
            self._VERSION_COLLECTION
        )
        if existing is None:
            try:
                engine.admin.register_operational_collection(
                    OperationalRegisterRequest(
                        name=self._VERSION_COLLECTION,
                        kind=OperationalCollectionKind.APPEND_ONLY_LOG,
                        schema_json="{}",
                        retention_json="{}",
                        filter_fields_json=(
                            '[{"name":"item_id","type":"string","modes":["exact"]}]'
                        ),
                        validation_json='{"format_version":1,"mode":"disabled","fields":[]}',
                        secondary_indexes_json="[]",
                        format_version=1,
                    )
                )
            except Exception:
                logger.debug(
                    "version_snapshots collection registration failed",
                    exc_info=True,
                )
        self._version_coll_ready = True

    def create_version_snapshot(self, item: Item) -> None:
        """Snapshot the current item state before a re-ingest overwrites it."""
        from fathomdb import OperationalAppend, WriteRequest

        self._ensure_version_collection()
        engine = self._fathom.engine
        payload: dict[str, Any] = {
            "item_id": item.item_id,
            "version": item.version,
            "title": item.title,
            "body": item.body,
            "source_url": item.source_url,
            "author": item.author,
            "tags": item.tags,
            "summary": item.summary.text if item.summary else None,
            "snapshot_at": utcnow().isoformat(),
        }
        engine.write(
            WriteRequest(
                label="version-snapshot",
                operational_writes=[
                    OperationalAppend(
                        collection=self._VERSION_COLLECTION,
                        record_key=item.item_id,
                        payload_json=payload,
                        source_ref="memex:version-snapshot",
                    )
                ],
            )
        )

    def get_versions(self, item_id: str) -> list[dict[str, Any]]:
        """Return version snapshots for an item."""
        from fathomdb import OperationalFilterClause, OperationalReadRequest

        self._ensure_version_collection()
        engine = self._fathom.engine
        try:
            report = engine.admin.read_operational_collection(
                OperationalReadRequest(
                    collection_name=self._VERSION_COLLECTION,
                    filters=[
                        OperationalFilterClause.exact("item_id", item_id),
                    ],
                    limit=100,
                )
            )
            return [r.payload_json for r in report.rows]
        except Exception:
            logger.debug(
                "get_versions: failed to read version_snapshots",
                exc_info=True,
            )
            return []

    # ── Sources ─────────────────────────────────────────────────────

    def create_source(self, source: Any) -> None:
        """Create a knowledge source."""
        self._fathom.knowledge.create_source(
            source.source_id,
            source.name,
            source.domain,
            source.type,
            reputation=getattr(source, "reputation_score", 0.5),
        )

    def get_source(self, source_id: str) -> Any:
        """Return a source by ID."""
        return self._fathom.knowledge.get_source(source_id)

    def find_source_by_domain(self, domain: str) -> Any:
        """Find a source by domain."""
        return self._fathom.knowledge.find_source_by_domain(domain)

    def update_source(self, source: Any) -> None:
        """Update a source."""
        self._fathom.knowledge.update_source(
            source.source_id,
            name=source.name,
            domain=source.domain,
            reputation=getattr(source, "reputation_score", 0.5),
        )

    # ── Links ───────────────────────────────────────────────────────

    def create_link(self, link: Any) -> None:
        """Create a link between items."""
        self._fathom.knowledge.create_link(
            link.source_item_id,
            link.target_item_id,
            link.relationship,
            strength=getattr(link, "strength", 0.5),
            created_by=getattr(link, "created_by", "auto"),
        )

    def get_links(
        self,
        item_id: str,
        *,
        min_strength: float = 0.0,
        created_by: Any = None,
    ) -> list[Any]:
        """Get links for an item."""
        links = self._fathom.knowledge.get_links(item_id)
        if min_strength > 0:
            links = [lk for lk in links if lk.get("strength", 0) >= min_strength]
        if created_by is not None:
            cb = created_by.value if hasattr(created_by, "value") else created_by
            links = [lk for lk in links if lk.get("created_by") == cb]
        return links

    def count_auto_links(self, item_id: str) -> int:
        """Count auto-created links for an item."""
        return self._fathom.knowledge.count_auto_links(item_id)

    # ── Trails ──────────────────────────────────────────────────────

    def create_trail(self, trail: Any) -> None:
        """Create a trail."""
        self._fathom.knowledge.create_trail(
            trail.trail_id,
            trail.name,
            description=getattr(trail, "description", ""),
        )

    def get_trail(self, trail_id: str) -> Any:
        """Get a trail by ID."""
        return None  # TODO: implement when needed

    def list_trails(self) -> list[Any]:
        """List all trails."""
        return []  # TODO: implement when needed

    def add_trail_item(self, ti: Any) -> None:
        """Add an item to a trail."""
        self._fathom.knowledge.add_trail_item(
            ti.trail_id,
            ti.item_id,
            ti.position,
            annotation=getattr(ti, "annotation", ""),
        )

    def get_trail_items(self, trail_id: str) -> list[Any]:
        """Get items in a trail."""
        return self._fathom.knowledge.get_trail_items(trail_id)

    # ── Embeddings ──────────────────────────────────────────────────

    def save_embedding(
        self,
        item_id: str,
        vector: bytes,
        model: str,
        dimensions: int,
    ) -> None:
        """No-op — fathomdb manages embeddings internally."""
        pass

    def get_embedding(self, item_id: str) -> tuple[bytes, str] | None:
        """Not available via fathomdb adapter."""
        return None

    def get_all_embeddings(self) -> list[tuple[str, bytes]]:
        """Not available via fathomdb adapter."""
        return []

    # ── Convenience ─────────────────────────────────────────────────

    def get_reputation_factor(self, source_id: str) -> float:
        """Return reputation for a source."""
        src = self._fathom.knowledge.get_source(source_id)
        if src is not None:
            return src.get("reputation", 0.5) if isinstance(src, dict) else 0.5
        return 0.5

    def get_next_trail_position(self, trail_id: str) -> int:
        """Return the next position for a trail item."""
        items = self._fathom.knowledge.get_trail_items(trail_id)
        return len(items)

    # ── Lifecycle ───────────────────────────────────────────────────

    def close(self) -> None:
        """No-op close."""
        pass  # FathomStore.close() handles everything


class FathomSchedulerAdapter:
    """Thin adapter so callers that access store.scheduler work."""

    def __init__(self, fathom: FathomStore) -> None:
        self._fathom = fathom
        self._repo = fathom.scheduler
        # Back-reference set by FathomMemexStore.__init__ after construction.
        self._memex_store: Any = None

    @staticmethod
    def _to_task_run(d: dict[str, Any]) -> TaskRun:
        """Convert fathomdb run dict to TaskRun model."""

        def _parse_dt(v: Any) -> datetime | None:
            if v is None:
                return None
            if isinstance(v, datetime):
                return v
            return datetime.fromisoformat(v)

        # fathomdb run_id is a string UUID; TaskRun.run_id is int.
        # Use the logical_id or run_id as-is — the field accepts int|str
        # at runtime even though the annotation says int.
        run_id = d.get("logical_id", d.get("run_id", ""))
        return TaskRun(
            run_id=run_id,
            task_id=d.get("task_id"),
            started_at=_parse_dt(d.get("started_at") or d.get("created_at")),
            completed_at=_parse_dt(d.get("completed_at")),
            status=d.get("status", "queued"),
            result=d.get("result", ""),
            error=d.get("error"),
            queued_at=_parse_dt(d.get("queued_at")),
            attempt=d.get("attempt", 0),
            action_type=d.get("action_type"),
            action_data=d.get("action_data"),
            max_retries=d.get("max_retries", 3),
            priority=d.get("priority", 5),
        )

    def _sync_world_model_task(self, task: Any) -> None:
        """Sync a ScheduledTask to the world-model task/provenance layer."""
        from memex.world_model_task_commitment import (
            build_world_model_task_from_scheduled_task,
            scheduled_task_qualifies_for_world_model_task,
        )

        if self._memex_store is None:
            return
        if not scheduled_task_qualifies_for_world_model_task(task):
            # Remove world-model task and its provenance links if it exists
            self._fathom.world_model.delete_provenance_links_for_source(
                "world_model_task",
                task.task_id,
            )
            try:
                self._fathom.world_model.delete_wm_task(task.task_id)
            except Exception:
                pass  # Task may not exist in world model
            return
        wm_task = build_world_model_task_from_scheduled_task(task)
        self._memex_store.upsert_world_model_task(wm_task)

    def create_task(self, task: Any) -> None:
        """Unpack ScheduledTask model into positional args for fathomdb repository."""
        self._repo.create_task(
            task.task_id,
            task.name,
            task.cron_expr,
            _enum_val(task.action_type),
            enabled=task.enabled,
            builtin=getattr(task, "builtin", False),
            action_data=task.action_data,
            goal_id=getattr(task, "goal_id", None),
        )
        self._sync_world_model_task(task)

    def update_task(self, task: Any) -> None:
        """Update a ScheduledTask — accepts a ScheduledTask model."""
        self._repo.update_task(
            task.task_id,
            name=task.name,
            description=task.description,
            cron_expr=task.cron_expr,
            action_type=_enum_val(task.action_type),
            action_data=task.action_data,
            goal_id=task.goal_id,
            enabled=task.enabled,
        )
        self._sync_world_model_task(task)

    def get_runs(self, task_id: str, *, limit: int = 10) -> list[TaskRun]:
        """Return runs as TaskRun models."""
        dicts = self._repo.get_runs(task_id, limit=limit)
        return [self._to_task_run(d) for d in dicts]

    def get_last_run(self, task_id: str) -> TaskRun | None:
        """Return the most recent run as a TaskRun model."""
        d = self._repo.get_last_run(task_id)
        return self._to_task_run(d) if d is not None else None

    def get_all_runs(self, *, limit: int = 50) -> list[TaskRun]:
        """Return all runs as TaskRun models."""
        dicts = self._repo.get_all_runs(limit=limit)
        return [self._to_task_run(d) for d in dicts]

    def __getattr__(self, name: str) -> Any:
        return getattr(self._repo, name)


class FathomMeetingAdapter:
    """Thin adapter so callers that access store.meetings work."""

    def __init__(self, fathom: FathomStore) -> None:
        self._fathom = fathom
        self._repo = fathom.meetings

    def create_meeting(self, record: Any) -> None:
        """Unpack MeetingRecord into positional args for fathomdb repository."""
        self._repo.create_meeting(
            record.meeting_id,
            record.title,
            state=_enum_val(record.state),
            attendees=getattr(record, "attendees", None) or [],
            notes=getattr(record, "notes", None),
            scheduled_for=_dt_iso(getattr(record, "scheduled_for", None)),
            action_items=getattr(record, "action_items", None) or [],
            item_id=getattr(record, "item_id", None),
            audio_path=getattr(record, "audio_path", None),
            stopped_at=record.stopped_at.isoformat()
            if getattr(record, "stopped_at", None)
            else None,
            started_at=record.started_at.isoformat()
            if getattr(record, "started_at", None)
            else None,
            audio_deleted=getattr(record, "audio_deleted", False),
        )
        for rec in getattr(record, "recordings", None) or []:
            self._repo.create_recording(
                rec.recording_id,
                rec.meeting_id,
                state=_enum_val(rec.state),
                sequence_number=getattr(rec, "sequence_number", 1),
                sample_rate=getattr(rec, "sample_rate", 16000),
                audio_path=getattr(rec, "audio_path", "") or "",
            )
        self._sync_meeting_intelligence(record)
        try:
            from memex.meetings.semantic_projection import (
                sync_promoted_action_item_goal_links,
            )

            sync_promoted_action_item_goal_links(self._parent, record)
        except Exception:
            pass

    def update_meeting(self, record: Any) -> None:
        """Unpack MeetingRecord into meeting_id + kwargs for fathomdb repository."""
        from dataclasses import asdict

        segments_raw = getattr(record, "segments", None) or []
        segments = [
            asdict(s) if hasattr(s, "__dataclass_fields__") else dict(s)
            for s in segments_raw
        ]
        self._repo.update_meeting(
            record.meeting_id,
            title=record.title,
            state=_enum_val(record.state),
            attendees=getattr(record, "attendees", None) or [],
            notes=getattr(record, "notes", None) or "",
            action_items=getattr(record, "action_items", None) or [],
            scheduled_for=_dt_iso(getattr(record, "scheduled_for", None)),
            error=getattr(record, "error", None) or "",
            audio_deleted=getattr(record, "audio_deleted", False),
            segments=segments,
            speaker_count=getattr(record, "speaker_count", 0),
            language=getattr(record, "language", ""),
            whisper_model=getattr(record, "whisper_model", ""),
            duration_seconds=getattr(record, "duration_seconds", 0.0),
            item_id=getattr(record, "item_id", None),
            audio_path=getattr(record, "audio_path", "") or "",
            ingested_at=record.ingested_at.isoformat()
            if getattr(record, "ingested_at", None)
            else None,
            transcribed_at=record.transcribed_at.isoformat()
            if getattr(record, "transcribed_at", None)
            else None,
            started_at=record.started_at.isoformat()
            if getattr(record, "started_at", None)
            else None,
            stopped_at=record.stopped_at.isoformat()
            if getattr(record, "stopped_at", None)
            else None,
        )
        self._sync_meeting_intelligence(record)
        try:
            from memex.meetings.semantic_projection import (
                sync_promoted_action_item_goal_links,
            )

            sync_promoted_action_item_goal_links(self._parent, record)
        except Exception:
            pass

        # Prune stale promoted_action_item links
        try:
            action_items = getattr(record, "action_items", None) or []
            current_goal_ids: set[str] = set()
            for item in action_items:
                gid = str(item.get("promoted_goal_id") or "").strip()
                if gid and gid != "__pending__":
                    current_goal_ids.add(gid)
            existing_links = self._parent.list_meeting_goal_links(record.meeting_id)
            for link in existing_links:
                if (
                    link.relationship == "promoted_action_item"
                    and link.goal_id not in current_goal_ids
                ):
                    self._parent._fathom.goals.delete_meeting_goal_link(
                        record.meeting_id,
                        link.goal_id,
                        link.relationship,
                    )
        except Exception:
            pass

    def list_meeting_artifacts(
        self,
        meeting_id: str,
        *,
        artifact_type: Any = None,
        recording_id: str | None = None,
    ) -> list[Any]:
        """Bridge to FathomStore list_artifacts."""
        at_str = _enum_val(artifact_type) if artifact_type is not None else None
        return self._repo.list_artifacts(meeting_id, artifact_type=at_str)

    @staticmethod
    def _action_item_establishes_commitment(item: dict) -> bool:
        status = str(item.get("commitment_status", "")).strip().lower()
        if status in {"agreed", "accepted", "committed", "confirmed"}:
            return True
        if bool(item.get("commitment_confirmed")):
            return True
        if bool(item.get("agreed_by")):
            return True
        if bool(item.get("accepted_constraints")):
            return True
        if bool(item.get("agreed_schedule")) or bool(item.get("agreed_deadline")):
            return True
        return False

    def _sync_meeting_intelligence(self, record: Any) -> None:
        """Create/update artifacts from meeting notes/action_items.

        Tracks all artifact IDs written during this sync and retires any
        stale note/decision/outcome/action_item/commitment artifacts that
        were not refreshed (handles the "rerun clears items" case).
        Transcript segments are only retired when new segments replace them.
        """
        import re
        from memex.meetings.models import MeetingIntelligenceArtifactType

        meeting_id = record.meeting_id
        notes = getattr(record, "notes", None) or ""
        action_items = getattr(record, "action_items", None) or []

        # Track artifact IDs written in this pass (excluding segments)
        written_ids: set[str] = set()

        # Create NOTE artifact from notes
        if notes:
            aid = f"{meeting_id}:note:0"
            written_ids.add(aid)
            self._repo.create_artifact(
                aid,
                meeting_id,
                MeetingIntelligenceArtifactType.NOTE.value,
                content=notes,
                payload={},
            )
            # Extract semantic artifacts from notes (decisions, commitments, outcomes)
            decision_index = 0
            commitment_index_note = 0
            outcome_index = 0
            for raw_line in notes.splitlines():
                line = raw_line.strip()
                if not line:
                    continue
                line = re.sub(r"^[*\-]\s*", "", line)
                lower = line.lower()
                if lower.startswith("decision:") or lower.startswith("decided:"):
                    content = line.split(":", 1)[1].strip()
                    if content:
                        aid = f"{meeting_id}:decision:{decision_index}"
                        written_ids.add(aid)
                        self._repo.create_artifact(
                            aid,
                            meeting_id,
                            MeetingIntelligenceArtifactType.DECISION.value,
                            content=content,
                            payload={},
                        )
                        decision_index += 1
                elif lower.startswith("commitment:") or lower.startswith("committed:"):
                    content = line.split(":", 1)[1].strip()
                    if content:
                        aid = f"{meeting_id}:commitment:note:{commitment_index_note}"
                        written_ids.add(aid)
                        self._repo.create_artifact(
                            aid,
                            meeting_id,
                            MeetingIntelligenceArtifactType.COMMITMENT.value,
                            content=content,
                            payload={},
                        )
                        commitment_index_note += 1
                elif lower.startswith("outcome:"):
                    content = line.split(":", 1)[1].strip()
                    if content:
                        aid = f"{meeting_id}:outcome:{outcome_index}"
                        written_ids.add(aid)
                        self._repo.create_artifact(
                            aid,
                            meeting_id,
                            MeetingIntelligenceArtifactType.OUTCOME.value,
                            content=content,
                            payload={},
                        )
                        outcome_index += 1

        # Create ACTION_ITEM and COMMITMENT artifacts from action_items
        for index, item in enumerate(action_items):
            content = item.get("text") or item.get("action") or ""
            aid = f"{meeting_id}:action_item:{index}"
            written_ids.add(aid)
            self._repo.create_artifact(
                aid,
                meeting_id,
                MeetingIntelligenceArtifactType.ACTION_ITEM.value,
                content=content,
                payload=dict(item),
            )
            if self._action_item_establishes_commitment(item):
                cid = f"{meeting_id}:commitment:{index}"
                written_ids.add(cid)
                self._repo.create_artifact(
                    cid,
                    meeting_id,
                    MeetingIntelligenceArtifactType.COMMITMENT.value,
                    content=content,
                    payload=dict(item),
                )

        # Retire stale non-segment artifacts that were not refreshed
        try:
            for art_type in (
                MeetingIntelligenceArtifactType.NOTE.value,
                MeetingIntelligenceArtifactType.DECISION.value,
                MeetingIntelligenceArtifactType.OUTCOME.value,
                MeetingIntelligenceArtifactType.ACTION_ITEM.value,
                MeetingIntelligenceArtifactType.COMMITMENT.value,
            ):
                self._repo.retire_artifacts(
                    meeting_id,
                    artifact_type=art_type,
                    keep_ids=written_ids,
                )
        except Exception:
            pass

        # Create TRANSCRIPT_SEGMENT artifacts from recording segments
        recordings = getattr(record, "recordings", None) or []
        for rec in recordings:
            rec_id = getattr(rec, "recording_id", None)
            segments = getattr(rec, "segments", None) or []
            for seg_idx, seg in enumerate(segments):
                self._repo.create_artifact(
                    f"{meeting_id}:{rec_id}:segment:{seg_idx}",
                    meeting_id,
                    MeetingIntelligenceArtifactType.TRANSCRIPT_SEGMENT.value,
                    recording_id=rec_id,
                    speaker=getattr(seg, "speaker", None),
                    content=getattr(seg, "text", ""),
                    start_seconds=getattr(seg, "start", 0.0),
                    end_seconds=getattr(seg, "end", 0.0),
                )

        # Also create TRANSCRIPT_SEGMENT artifacts from record.segments
        # (flat segments set during orchestrate_transcription)
        if not recordings:
            flat_segments = getattr(record, "segments", None) or []
            rec_id = None
            # Try to find the associated recording_id
            try:
                recs = self._repo.list_recordings(meeting_id)
                if recs:
                    rec_id = getattr(recs[0], "recording_id", None)
            except Exception:
                pass
            for seg_idx, seg in enumerate(flat_segments):
                self._repo.create_artifact(
                    f"{meeting_id}:{rec_id or 'flat'}:segment:{seg_idx}",
                    meeting_id,
                    MeetingIntelligenceArtifactType.TRANSCRIPT_SEGMENT.value,
                    recording_id=rec_id,
                    speaker=getattr(seg, "speaker", None),
                    content=getattr(seg, "text", ""),
                    start_seconds=getattr(seg, "start", 0.0),
                    end_seconds=getattr(seg, "end", 0.0),
                )

    def update_recording(self, recording: Any) -> None:
        """Unpack MeetingRecording into recording_id + kwargs for fathomdb repository.

        Also accepts a MeetingRecord (has meeting_id but no recording_id),
        in which case it delegates to update_meeting so the cleanup path
        can persist audio_deleted on the parent meeting.
        """
        if not hasattr(recording, "recording_id"):
            self.update_meeting(recording)
            return
        from dataclasses import asdict

        segments_raw = getattr(recording, "segments", None) or []
        segments = [
            asdict(s) if hasattr(s, "__dataclass_fields__") else dict(s)
            for s in segments_raw
        ]
        self._repo.update_recording(
            recording.recording_id,
            state=_enum_val(recording.state),
            audio_path=getattr(recording, "audio_path", "") or "",
            duration_seconds=getattr(recording, "duration_seconds", 0.0),
            sample_rate=getattr(recording, "sample_rate", 16000),
            started_at=recording.started_at.isoformat()
            if getattr(recording, "started_at", None)
            else None,
            stopped_at=recording.stopped_at.isoformat()
            if getattr(recording, "stopped_at", None)
            else None,
            transcribed_at=recording.transcribed_at.isoformat()
            if getattr(recording, "transcribed_at", None)
            else None,
            speaker_count=getattr(recording, "speaker_count", 0),
            language=getattr(recording, "language", ""),
            whisper_model=getattr(recording, "whisper_model", ""),
            vad_threshold=getattr(recording, "vad_threshold", 0.1),
            segments=segments,
            error=getattr(recording, "error", "") or "",
        )

    def record_meeting_extraction_run(self, run: Any) -> None:
        """Persist a MeetingExtractionRun via the underlying create/complete pair."""
        metadata = getattr(run, "metadata", None) or None
        self._repo.create_extraction_run(
            run.run_id,
            run.meeting_id,
            run.run_type,
            status=run.status,
            recording_id=getattr(run, "recording_id", None),
            model=getattr(run, "model", None) or None,
            metadata=metadata,
        )
        if run.status in ("success", "failed"):
            self._repo.complete_extraction_run(
                run.run_id,
                status=run.status,
                artifact_count=getattr(run, "artifact_count", 0),
                metadata=metadata,
            )

    def list_upcoming_meetings(
        self,
        *,
        horizon: datetime,
        now: datetime | None = None,
        limit: int = 20,
    ) -> list[Any]:
        """List upcoming meetings matching the MeetingStore protocol.

        The fathomdb MeetingsRepository.list_upcoming_meetings only accepts
        horizon as a string. This adapter converts the datetime args and
        applies now/limit filtering client-side.
        """
        horizon_str = (
            horizon.isoformat() if isinstance(horizon, datetime) else str(horizon)
        )
        meetings = self._repo.list_upcoming_meetings(horizon_str)
        # Client-side filter: only meetings at or after 'now'
        if now is not None:
            filtered = []
            for m in meetings:
                sf = m.scheduled_for
                if sf is None:
                    continue
                sf_str = sf.isoformat() if isinstance(sf, datetime) else str(sf)
                now_str = now.isoformat() if isinstance(now, datetime) else str(now)
                if sf_str >= now_str:
                    filtered.append(m)
            meetings = filtered
        return meetings[:limit]

    def list_meeting_extraction_runs(self, meeting_id: str) -> list:
        """Alias for repo.list_extraction_runs."""
        return self._repo.list_extraction_runs(meeting_id)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._repo, name)


class FathomIntakeAdapter:
    """IntakeStore-compatible adapter using FathomStore operational collections.

    Provides the same interface as ``IntakeStore`` (record, mark_processed,
    mark_failed, etc.) so callers can use this as a drop-in replacement
    when the caller needs a store-agnostic adapter.
    """

    def __init__(self, fathom: FathomStore) -> None:
        self._fathom = fathom
        self._counter = 0  # simple monotonic counter for intake IDs
        self._id_to_key: dict[int, str] = {}  # maps integer ID -> record_key

    def record(self, source: str, action_type: str, action_data: dict) -> int:
        """Write a new intake entry. Returns a monotonic integer ID."""
        self._counter += 1
        record_id = f"intake-{self._counter}-{int(time.time())}"
        self._id_to_key[self._counter] = record_id
        self._fathom.operational.put_intake_log(
            record_id,
            source=source,
            status="received",
            action_type=action_type,
            action_data=json.dumps(action_data),
        )
        return self._counter

    def _resolve_key(self, intake_id: int) -> str | None:
        """Resolve an integer intake ID to its string record key."""
        key = self._id_to_key.get(intake_id)
        if key is not None:
            return key
        # Fallback: scan all intake logs for a matching key pattern
        for entry in self._fathom.operational.list_intake_logs():
            rk = entry.get("_record_key", "")
            if rk.startswith(f"intake-{intake_id}-"):
                self._id_to_key[intake_id] = rk
                return rk
        return None

    def mark_queued(self, intake_id: int, run_id: int) -> None:
        """Set status='queued'."""
        key = self._resolve_key(intake_id)
        if key is not None:
            self._fathom.operational.update_intake_log_status(
                key, status="queued", run_id=run_id
            )

    def mark_processed(self, intake_id: int, *, run_id: int | None = None) -> None:
        """Set status='processed'."""
        key = self._resolve_key(intake_id)
        if key is not None:
            self._fathom.operational.update_intake_log_status(
                key, status="processed", run_id=run_id
            )

    def mark_failed(self, intake_id: int, error: str = "") -> None:
        """Set status='failed'."""
        key = self._resolve_key(intake_id)
        if key is not None:
            self._fathom.operational.update_intake_log_status(
                key, status="failed", error=error or None
            )

    def mark_dismissed(self, intake_id: int) -> None:
        """Set status='dismissed'."""
        key = self._resolve_key(intake_id)
        if key is not None:
            self._fathom.operational.update_intake_log_status(key, status="dismissed")

    def get(self, intake_id: int) -> dict[str, Any] | None:
        """Fetch a single intake_log entry by id."""
        key = self._resolve_key(intake_id)
        if key is None:
            return None
        return self._fathom.operational.get_intake_log(key)

    def get_recent(
        self,
        *,
        source: str | None = None,
        statuses: list[str] | None = None,
        hours: int = 24,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Query recent intake_log entries with optional filters."""
        from datetime import datetime, timedelta, timezone

        cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
        all_entries = self._fathom.operational.list_intake_logs()
        results = []
        for entry in all_entries:
            if source is not None and entry.get("source") != source:
                continue
            if statuses is not None and entry.get("status") not in statuses:
                continue
            received = entry.get("received_at")
            if received:
                try:
                    ts = datetime.fromisoformat(received)
                    if ts < cutoff:
                        continue
                except (ValueError, TypeError):
                    pass
            clean = {k: v for k, v in entry.items() if not k.startswith("_")}
            results.append(clean)
        results.sort(key=lambda r: r.get("received_at", ""), reverse=True)
        return results[:limit]


class FathomNotificationAdapter:
    """NotificationStore-compatible adapter backed by FathomStore.notifications.

    Bridges the ``NotificationStore`` interface (which callers like
    ``NotificationRouter`` expect) to the FathomStore ``NotificationsRepository``.
    """

    def __init__(self, fathom: FathomStore) -> None:
        self._fathom = fathom
        self._repo = fathom.notifications

    def create(self, notification: Notification) -> None:
        """Persist a new notification via FathomStore."""
        self._repo.create(
            notification.notification_id,
            notification.title,
            body=notification.body,
            priority=notification.priority.value,
            source=notification.source,
            goal_id=notification.goal_id,
            action_type=notification.action_type,
            action_data=notification.action_data,
        )

    def list_pending(
        self,
        *,
        min_priority: NotificationPriority | None = None,
        limit: int = 50,
    ) -> list[Notification]:
        """List unread, undismissed notifications."""
        # The FathomStore list_pending doesn't accept min_priority yet;
        # do client-side filtering if needed.
        results = self._repo.list_pending(limit=limit)
        if min_priority is not None:
            priority_order = ["critical", "high", "normal", "low"]
            cutoff = priority_order.index(min_priority.value)
            allowed = set(priority_order[: cutoff + 1])
            results = [n for n in results if n.priority.value in allowed]
        return results

    def mark_read(self, notification_id: str) -> None:
        """Mark a notification as read."""
        self._repo.mark_read(notification_id)

    def dismiss(self, notification_id: str) -> None:
        """Dismiss a notification."""
        self._repo.dismiss(notification_id)
        try:
            from memex.event_bus import get_bus
            from memex.events import NotificationDismissed

            get_bus().publish(NotificationDismissed(notification_id=notification_id))
        except Exception:
            pass

    def get(self, notification_id: str) -> Notification | None:
        """Get a single notification by ID."""
        return self._repo.get(notification_id)


# ---------------------------------------------------------------------------
# Main facade
# ---------------------------------------------------------------------------


class FathomMemexStore:
    """MemexStore-compatible wrapper around FathomStore.

    Delegates all calls to the appropriate FathomStore sub-repository
    so the rest of Memex can use this as a drop-in replacement for
    SqliteMemexStore.
    """

    def __init__(self, fathom: FathomStore) -> None:
        self._fathom = fathom
        self._content = FathomContentAdapter(fathom)
        self._content._memex_store = self  # back-reference for world-model resolution
        self._scheduler = FathomSchedulerAdapter(fathom)
        self._scheduler._memex_store = self  # back-reference for world-model sync
        self._meetings = FathomMeetingAdapter(fathom)
        self._meetings._parent = self  # back-reference for semantic projection
        self._settings = FathomSettingsAdapter(fathom)
        self._intake = FathomIntakeAdapter(fathom)
        self._notifications = FathomNotificationAdapter(fathom)

    # -- Connection & sub-stores ---------------------------------------------

    @property
    def conn(self) -> None:
        """Not applicable -- FathomStore has no raw connection object.

        Retained so ``getattr(store, 'conn', None)`` returns None rather
        than raising AttributeError.
        """
        return None

    @property
    def content(self) -> FathomContentAdapter:
        """Return the content adapter."""
        return self._content

    @property
    def scheduler(self) -> FathomSchedulerAdapter:
        """Return the scheduler adapter."""
        return self._scheduler

    @property
    def meetings(self) -> FathomMeetingAdapter:
        """Return the meetings adapter."""
        return self._meetings

    @property
    def intake(self) -> FathomIntakeAdapter:
        """Return the intake adapter (IntakeStore-compatible)."""
        return self._intake

    @property
    def notifications(self) -> FathomNotificationAdapter:
        """Return the notifications adapter (NotificationStore-compatible)."""
        return self._notifications

    @property
    def settings(self) -> FathomSettingsAdapter:
        """Return the settings adapter."""
        return self._settings

    @property
    def knowledge_backend(self) -> str:
        """Return the knowledge backend name."""
        return "fathomdb"

    @property
    def knowledge_degraded_modes(self) -> list[str]:
        """Return empty degraded modes list."""
        return []

    def rebuild_knowledge_projection(self) -> dict[str, int]:
        """Rebuild knowledge projections."""
        self._fathom.admin.rebuild_projections()
        return {"rebuilt": 1}

    # ======================================================================
    # Goals
    # ======================================================================

    def create_goal(self, goal: Goal) -> None:
        """Create a new goal and sync to world model."""
        from memex.world_model_goal import build_world_model_goal

        self._fathom.goals.create(
            goal.goal_id,
            goal.title,
            goal.description,
            goal.status.value,
            goal.priority.value,
            parent_id=goal.parent_id,
            blocked_by_goal_id=goal.blocked_by_goal_id,
            deadline=goal.deadline.isoformat() if goal.deadline else None,
            metadata=goal.metadata,
            created_at=goal.created_at.isoformat() if goal.created_at else None,
            updated_at=goal.updated_at.isoformat() if goal.updated_at else None,
            last_touched_at=goal.last_touched_at.isoformat()
            if goal.last_touched_at
            else None,
        )
        self.upsert_world_model_goal(build_world_model_goal(goal))

    def update_goal(self, goal: Goal) -> None:
        """Update an existing goal and sync to world model."""
        from memex.world_model_goal import build_world_model_goal

        self._fathom.goals.update(
            goal.goal_id,
            title=goal.title,
            description=goal.description,
            status=goal.status.value,
            priority=goal.priority.value,
            parent_id=goal.parent_id,
            blocked_by_goal_id=goal.blocked_by_goal_id,
            blocked_reason=goal.blocked_reason,
            failure_reason=goal.failure_reason,
            deadline=goal.deadline.isoformat() if goal.deadline else None,
            metadata=goal.metadata,
        )
        self.upsert_world_model_goal(build_world_model_goal(goal))

    def get_goal(self, goal_id: str) -> Goal | None:
        """Return goal by ID."""
        return self._fathom.goals.get(goal_id)

    def list_goals(self, status: GoalStatus | None = None) -> list[Goal]:
        """List goals with optional status filter."""
        status_str = status.value if status is not None else None
        return self._fathom.goals.list(status=status_str)

    def get_children(self, parent_id: str) -> list[Goal]:
        """Return child goals of a parent."""
        return self._fathom.goals.get_children(parent_id)

    def get_tree(self, root_id: str | None = None) -> list[Goal]:
        """Return goal tree from root."""
        return self._fathom.goals.get_tree(root_id)

    def get_stale_goals(self, threshold: datetime) -> list[Goal]:
        """Return goals not updated since threshold."""
        return self._fathom.goals.get_stale_goals(threshold)

    def get_approaching_deadlines(self, horizon: datetime) -> list[Goal]:
        """Return goals with approaching deadlines."""
        return self._fathom.goals.get_approaching_deadlines(horizon)

    def create_goal_entity_link(self, link: GoalEntityLink) -> None:
        """Link a goal to an entity."""
        self._fathom.goals.create_goal_entity_link(
            link.goal_id,
            link.entity_id,
            link.relationship,
        )

    def list_goal_entity_links(self, goal_id: str) -> list[GoalEntityLink]:
        """List entity links for a goal."""
        dicts = self._fathom.goals.list_goal_entity_links(goal_id)
        results: list[GoalEntityLink] = []
        for d in dicts:
            results.append(
                GoalEntityLink(
                    goal_id=d.get("goal_id", goal_id),
                    entity_id=d.get("entity_id", d.get("logical_id", "")),
                    relationship=d.get("relationship", "related"),
                    created_at=datetime.fromisoformat(d["created_at"])
                    if isinstance(d.get("created_at"), str)
                    else d.get("created_at", utcnow()),
                )
            )
        return results

    def list_goals_for_entity(self, entity_id: str) -> list[GoalEntityLink]:
        """List goals linked to an entity (reverse of list_goal_entity_links)."""
        dicts = self._fathom.goals.list_goals_for_entity(entity_id)
        results: list[GoalEntityLink] = []
        for d in dicts:
            results.append(
                GoalEntityLink(
                    goal_id=d.get(
                        "goal_id", d.get("logical_id", "").removeprefix("goal:")
                    ),
                    entity_id=entity_id,
                    relationship=d.get("relationship", "related"),
                    created_at=datetime.fromisoformat(d["created_at"])
                    if isinstance(d.get("created_at"), str)
                    else d.get("created_at", utcnow()),
                )
            )
        return results

    def create_meeting_goal_link(self, link: MeetingGoalLink) -> None:
        """Link a meeting to a goal and create provenance."""
        self._fathom.goals.create_meeting_goal_link(
            link.meeting_id,
            link.goal_id,
            link.relationship,
        )
        self.upsert_world_model_provenance_link(
            WorldModelProvenanceLink(
                link_id=(
                    f"meeting:{link.meeting_id}"
                    f"->{link.relationship}:world_model_goal:{link.goal_id}"
                ),
                source_record_type="meeting",
                source_record_id=link.meeting_id,
                target_record_type="world_model_goal",
                target_record_id=link.goal_id,
                relationship=link.relationship,
                created_at=link.created_at,
            )
        )

    def list_meeting_goal_links(self, meeting_id: str) -> list[MeetingGoalLink]:
        """List goal links for a meeting."""
        dicts = self._fathom.goals.list_meeting_goal_links(meeting_id)
        results: list[MeetingGoalLink] = []
        for d in dicts:
            results.append(
                MeetingGoalLink(
                    meeting_id=d.get("meeting_id", meeting_id),
                    goal_id=d.get("goal_id", d.get("logical_id", "")),
                    relationship=d.get("relationship", "explicit"),
                    created_at=datetime.fromisoformat(d["created_at"])
                    if isinstance(d.get("created_at"), str)
                    else d.get("created_at", utcnow()),
                )
            )
        return results

    def create_meeting_entity_link(self, link: MeetingEntityLink) -> None:
        """Link a meeting to an entity."""
        self._fathom.goals.create_meeting_entity_link(
            link.meeting_id,
            link.entity_id,
            link.relationship,
        )

    def list_meeting_entity_links(self, meeting_id: str) -> list[MeetingEntityLink]:
        """List entity links for a meeting."""
        dicts = self._fathom.goals.list_meeting_entity_links(meeting_id)
        results: list[MeetingEntityLink] = []
        for d in dicts:
            results.append(
                MeetingEntityLink(
                    meeting_id=meeting_id,
                    entity_id=d.get(
                        "entity_id",
                        d.get("logical_id", "").removeprefix("wm_entity:"),
                    ),
                    relationship=d.get("relationship", "attendee"),
                    created_at=datetime.fromisoformat(d["created_at"])
                    if isinstance(d.get("created_at"), str)
                    else d.get("created_at", utcnow()),
                )
            )
        return results

    def upsert_calendar_event(self, event: CalendarEvent) -> None:
        """Upsert a calendar event."""
        self._fathom.goals.upsert_calendar_event(
            event.event_id,
            event.provider,
            event.title,
            event.starts_at.isoformat(),
            ends_at=event.ends_at.isoformat() if event.ends_at else None,
            attendees=event.attendees,
            metadata=event.metadata,
        )

    def list_upcoming_calendar_events(self, horizon: datetime) -> list[CalendarEvent]:
        """List upcoming calendar events before *horizon*."""
        dicts = self._fathom.goals.list_upcoming_calendar_events(horizon.isoformat())
        results: list[CalendarEvent] = []
        for d in dicts:
            d = dict(d)
            d.pop("logical_id", None)
            for field in ("starts_at", "ends_at", "synced_at"):
                val = d.get(field)
                if isinstance(val, str):
                    d[field] = datetime.fromisoformat(val)
            if d.get("attendees") is None:
                d["attendees"] = []
            if d.get("metadata") is None:
                d["metadata"] = {}
            results.append(CalendarEvent(**d))
        return results

    # ======================================================================
    # Partner / agent / session
    # ======================================================================

    def save_partner_profile(self, profile: HumanPartnerProfile) -> None:
        """Save the partner profile."""
        self._fathom.operational.put_human_model(profile.model_dump(mode="json"))

    def load_partner_profile(self) -> HumanPartnerProfile | None:
        """Load the partner profile."""
        data = self._fathom.operational.get_human_model()
        if data is None:
            return None
        return HumanPartnerProfile.model_validate(data)

    def save_agent_self_model(self, model: AgentSelfModel) -> None:
        """Save the agent self-model."""
        self._fathom.operational.put_agent_self_model(model.model_dump(mode="json"))

    def load_agent_self_model(self) -> AgentSelfModel | None:
        """Load the agent self-model."""
        data = self._fathom.operational.get_agent_self_model()
        if data is None:
            return None
        return AgentSelfModel.model_validate(data)

    def save_session(self, ctx: SessionContext) -> None:
        """Save session context."""
        self._fathom.operational.put_session_context(ctx.model_dump(mode="json"))

    def load_session(self) -> SessionContext | None:
        """Load session context."""
        data = self._fathom.operational.get_session_context()
        if data is None:
            return None
        return SessionContext.model_validate(data)

    # ======================================================================
    # World-model entities & attributes
    # ======================================================================

    def upsert_world_model_entity(self, entity: WorldModelEntity) -> None:
        """Create or update a world-model entity."""
        etype = (
            entity.entity_type.value
            if hasattr(entity.entity_type, "value")
            else str(entity.entity_type)
        )
        self._fathom.world_model.upsert_entity(
            entity.entity_id,
            etype,
            entity.display_name,
            canonical_key=entity.canonical_key,
            status=entity.status,
            confidence=entity.confidence,
        )

    def replace_world_model_entity_attributes(
        self,
        entity_id: str,
        attributes: list[WorldModelEntityAttribute],
    ) -> None:
        """Replace entity attributes."""
        for attr in attributes:
            value = attr.value_text or (
                json.dumps(attr.value_json) if attr.value_json is not None else ""
            )
            self._fathom.world_model.set_entity_attribute(
                entity_id,
                attr.attribute_group,
                attr.attribute_key,
                value,
                confidence=attr.confidence,
            )

    def load_world_model_entity(
        self,
        entity_type: WorldModelEntityType | str,
        canonical_key: str,
    ) -> WorldModelEntity | None:
        """Load a world-model entity."""
        etype = entity_type.value if hasattr(entity_type, "value") else str(entity_type)
        return self._fathom.world_model.find_entity_by_canonical_key(
            etype, canonical_key
        )

    def list_world_model_entity_attributes(
        self,
        entity_id: str,
        attribute_group: str | None = None,
    ) -> list[WorldModelEntityAttribute]:
        """List attributes for an entity."""
        attrs = self._fathom.world_model.get_entity_attributes(entity_id)
        results: list[WorldModelEntityAttribute] = []
        now = utcnow()
        for a in attrs:
            if attribute_group is not None and a.get("group") != attribute_group:
                continue
            value = a.get("value", "")
            value_json = None
            value_text = value
            if isinstance(value, str):
                try:
                    value_json = json.loads(value)
                    value_text = None
                except (json.JSONDecodeError, TypeError):
                    pass
            results.append(
                WorldModelEntityAttribute(
                    attribute_id=f"{entity_id}:{a.get('group', '')}:{a.get('key', '')}",
                    entity_id=entity_id,
                    attribute_group=a.get("group", ""),
                    attribute_key=a.get("key", ""),
                    value_text=value_text,
                    value_json=value_json,
                    confidence=a.get("confidence", 1.0),
                    observed_at=now,
                    updated_at=now,
                )
            )
        return results

    # ======================================================================
    # World-model intents
    # ======================================================================

    def upsert_world_model_intent(self, intent: WorldModelIntent) -> None:
        """Store a world-model intent."""
        self._fathom.world_model.record_intent(
            intent.intent_id,
            intent.session_id,
            intent.raw_input,
            intent.classification,
            intent.selected_path,
            confidence=intent.confidence,
            goal_id=intent.goal_id,
            conversation_turn_id=intent.conversation_turn_id,
            summary=intent.summary,
            rationale=intent.rationale,
            status=intent.status,
            unresolved_references=intent.unresolved_references,
            missing_information=intent.missing_information,
            source_surface=intent.source_surface,
        )

    def load_latest_world_model_intent(
        self,
        session_id: str,
    ) -> WorldModelIntent | None:
        """Load latest intent for session."""
        return self._fathom.world_model.load_latest_intent(session_id)

    # ======================================================================
    # World-model actions
    # ======================================================================

    def upsert_world_model_action(self, action: WorldModelAction) -> None:
        """Store a world-model action."""
        self._fathom.world_model.record_action(
            action.action_id,
            action.session_id or "",
            action.action_kind,
            action.action_name,
            intent_id=action.intent_id,
            status=action.status,
            payload=action.payload,
            meeting_id=action.meeting_id,
            prompt_control_artifact_id=action.prompt_control_artifact_id,
            conversation_turn_id=action.conversation_turn_id,
            source_surface=action.source_surface,
        )

    def list_world_model_actions(
        self,
        *,
        session_id: str | None = None,
        meeting_id: str | None = None,
        intent_id: str | None = None,
        action_kind: str | None = None,
        limit: int = 50,
    ) -> list[WorldModelAction]:
        """List world-model actions."""
        actions = self._fathom.world_model.list_actions(
            session_id=session_id,
            action_kind=action_kind,
            limit=limit,
        )
        # Client-side filter for meeting_id and intent_id (not indexed)
        if meeting_id is not None:
            actions = [a for a in actions if a.meeting_id == meeting_id]
        if intent_id is not None:
            actions = [a for a in actions if a.intent_id == intent_id]
        return actions

    def load_world_model_action(self, action_id: str) -> WorldModelAction | None:
        """Load a single world-model action by ID via direct ``logical_id`` lookup."""
        return self._fathom.world_model.load_action(action_id)

    def delete_world_model_action_cascade(self, action_id: str) -> None:
        """Retire an action and its observations and their provenance links."""
        # Retire dependent observations (and any provenance links they own) first
        observations = self._fathom.world_model.list_observations(action_id=action_id)
        for obs in observations:
            self._fathom.world_model.delete_provenance_links_for_source(
                "world_model_observation", obs.observation_id
            )
            self._fathom.world_model.retire_observation(obs.observation_id)
        # Retire provenance links sourced from this action, then the action node itself.
        self._fathom.world_model.delete_provenance_links_for_source(
            "world_model_action", action_id
        )
        self._fathom.world_model.retire_action(action_id)

    # ======================================================================
    # World-model observations
    # ======================================================================

    def upsert_world_model_observation(
        self,
        observation: WorldModelObservation,
    ) -> None:
        """Store a world-model observation."""
        self._fathom.world_model.record_observation(
            observation.observation_id,
            observation.action_id,
            observation.observation_kind,
            observation.summary,
            status=observation.status,
            payload=observation.payload,
            session_id=observation.session_id,
            meeting_id=observation.meeting_id,
            source_surface=observation.source_surface,
        )

    def list_world_model_observations(
        self,
        *,
        action_id: str | None = None,
        session_id: str | None = None,
        meeting_id: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelObservation]:
        """List world-model observations."""
        observations = self._fathom.world_model.list_observations(
            action_id=action_id,
            session_id=session_id,
            limit=limit,
        )
        # Client-side filter for meeting_id (not indexed)
        if meeting_id is not None:
            observations = [o for o in observations if o.meeting_id == meeting_id]
        return observations

    # ======================================================================
    # World-model events
    # ======================================================================

    def upsert_world_model_event(self, event: WorldModelEvent) -> None:
        """Store a world-model event."""
        self._fathom.world_model.record_event(
            event.event_id,
            event.session_id or "",
            event.event_kind,
            event.title,
            summary=event.summary,
            meeting_id=event.meeting_id,
            payload=event.payload,
            conversation_turn_id=event.conversation_turn_id,
            source_surface=event.source_surface,
        )

    def list_world_model_events(
        self,
        *,
        session_id: str | None = None,
        meeting_id: str | None = None,
        event_kind: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelEvent]:
        """List world-model events."""
        events = self._fathom.world_model.list_events(
            session_id=session_id,
            event_kind=event_kind,
            limit=limit,
        )
        if meeting_id is not None:
            events = [e for e in events if getattr(e, "meeting_id", None) == meeting_id]
        return events

    def load_world_model_event(self, event_id: str) -> WorldModelEvent | None:
        """Load a world-model event by ID."""
        return self._fathom.world_model.load_event(event_id)

    # ======================================================================
    # World-model plans
    # ======================================================================

    def upsert_world_model_action_plan(self, plan: WorldModelActionPlan) -> None:
        """Store an action plan and its provenance links."""
        self._fathom.world_model.upsert_plan(plan)
        from memex.world_model_plans import (
            build_world_model_action_plan_provenance_links,
        )

        for link in build_world_model_action_plan_provenance_links(plan):
            self.upsert_world_model_provenance_link(link)

    def load_world_model_action_plan(self, plan_id: str) -> WorldModelActionPlan | None:
        """Load an action plan by ID."""
        return self._fathom.world_model.get_plan_typed(plan_id)

    def list_world_model_action_plans(
        self,
        *,
        goal_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelActionPlan]:
        """List action plans."""
        return self._fathom.world_model.list_plans(
            goal_id=goal_id,
            status=status,
            limit=limit,
        )

    def upsert_world_model_plan_step(self, step: WorldModelPlanStep) -> None:
        """Store a plan step and its provenance links."""
        self._fathom.world_model.upsert_plan_step(step)
        from memex.world_model_plans import build_world_model_plan_step_provenance_links

        for link in build_world_model_plan_step_provenance_links(step):
            self.upsert_world_model_provenance_link(link)

    def load_world_model_plan_step(self, step_id: str) -> WorldModelPlanStep | None:
        """Load a plan step by ID."""
        return self._fathom.world_model.load_plan_step(step_id)

    def list_world_model_plan_steps(
        self,
        *,
        plan_id: str | None = None,
        goal_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelPlanStep]:
        """List plan steps."""
        return self._fathom.world_model.list_plan_steps_typed(
            plan_id=plan_id,
            goal_id=goal_id,
            status=status,
            limit=limit,
        )

    # ======================================================================
    # World-model execution records
    # ======================================================================

    def upsert_world_model_execution_record(
        self,
        record: WorldModelExecutionRecord,
    ) -> None:
        """Store an execution record and maintain provenance links."""
        self._fathom.world_model.upsert_execution(record)
        for link in build_world_model_execution_record_provenance_links(record):
            self.upsert_world_model_provenance_link(link)

    def load_world_model_execution_record(
        self,
        execution_id: str,
    ) -> WorldModelExecutionRecord | None:
        """Load an execution record."""
        return self._fathom.world_model.load_execution(execution_id)

    def list_world_model_execution_records(
        self,
        *,
        session_id: str | None = None,
        plan_id: str | None = None,
        step_id: str | None = None,
        source_record_type: str | None = None,
        source_record_id: str | None = None,
        execution_kind: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelExecutionRecord]:
        """List execution records."""
        return self._fathom.world_model.list_executions_typed(
            session_id=session_id,
            plan_id=plan_id,
            step_id=step_id,
            source_record_type=source_record_type,
            source_record_id=source_record_id,
            execution_kind=execution_kind,
            limit=limit,
        )

    # ======================================================================
    # World-model knowledge ingest runs
    # ======================================================================

    def upsert_world_model_knowledge_ingest_run(
        self,
        run: WorldModelKnowledgeIngestRun,
    ) -> None:
        """Store an ingest run."""
        self._fathom.world_model.upsert_ingest_run(run)

    def load_world_model_knowledge_ingest_run(
        self,
        ingest_run_id: str,
    ) -> WorldModelKnowledgeIngestRun | None:
        """Load an ingest run."""
        return self._fathom.world_model.load_ingest_run(ingest_run_id)

    def list_world_model_knowledge_ingest_runs(
        self,
        *,
        session_id: str | None = None,
        source_ref: str | None = None,
        status: str | None = None,
        knowledge_id: str | None = None,
        item_id: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelKnowledgeIngestRun]:
        """List ingest runs."""
        return self._fathom.world_model.list_ingest_runs(
            session_id=session_id,
            source_ref=source_ref,
            status=status,
            knowledge_id=knowledge_id,
            item_id=item_id,
            limit=limit,
        )

    # ======================================================================
    # World-model plan step transitions
    # ======================================================================

    def append_world_model_plan_step_transition(
        self,
        transition: WorldModelPlanStepTransition,
    ) -> None:
        """Append a step transition and apply side-effects.

        After persisting the transition we
        update the step's status / progress / blocked fields, unblock
        dependent steps whose dependencies are now satisfied, and refresh
        the parent plan's status and selected_step_id.
        """
        self._fathom.world_model.append_transition(transition)

        # -- 1. Update the step itself ------------------------------------
        step = self.load_world_model_plan_step(transition.step_id)
        if step is not None:
            updated_step = step.model_copy(
                update={
                    "status": transition.to_status
                    if transition.to_status is not None
                    else step.status,
                    "blocked_reason": transition.blocked_reason
                    if transition.blocked_reason is not None
                    else step.blocked_reason,
                    "blocked_by_step_ids": transition.blocked_by_step_ids
                    if transition.blocked_by_step_ids is not None
                    else step.blocked_by_step_ids,
                    "progress_pct": max(0, min(100, transition.progress_pct))
                    if transition.progress_pct is not None
                    else step.progress_pct,
                    "updated_at": transition.updated_at,
                }
            )
            self.upsert_world_model_plan_step(updated_step)

        # -- 2. Refresh the action plan state (unblock deps, advance selection)
        self._refresh_world_model_action_plan_state(
            transition.plan_id,
            updated_at=transition.updated_at,
            completed_step_id=(
                transition.step_id
                if transition.to_status in {"done", "completed"}
                else None
            ),
        )

        # -- 3. Provenance links ------------------------------------------
        for link in build_world_model_plan_step_transition_provenance_links(transition):
            self.upsert_world_model_provenance_link(link)

    def load_world_model_plan_step_transition(
        self,
        transition_id: str,
    ) -> WorldModelPlanStepTransition | None:
        """Load a step transition."""
        return self._fathom.world_model.load_transition(transition_id)

    def list_world_model_plan_step_transitions(
        self,
        *,
        step_id: str | None = None,
        plan_id: str | None = None,
        execution_id: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelPlanStepTransition]:
        """List step transitions."""
        return self._fathom.world_model.list_transitions(
            step_id=step_id,
            plan_id=plan_id,
            execution_id=execution_id,
            limit=limit,
        )

    # ------------------------------------------------------------------
    # Plan-state helpers (mirrors SqliteMemexStore logic)
    # ------------------------------------------------------------------

    def _refresh_world_model_action_plan_state(
        self,
        plan_id: str,
        *,
        updated_at: datetime,
        completed_step_id: str | None = None,
    ) -> None:
        """Recompute plan status / selected_step_id after a transition."""
        plan = self.load_world_model_action_plan(plan_id)
        if plan is None:
            return
        steps = self.list_world_model_plan_steps(plan_id=plan_id, limit=1000)
        if not steps:
            return

        # Unblock dependent steps whose dependencies are now satisfied.
        done_step_ids = {s.step_id for s in steps if s.status in {"done", "completed"}}
        for s in steps:
            if s.status != "blocked":
                continue
            if completed_step_id is None or s.step_id == completed_step_id:
                continue
            required_step_ids = {
                sid.strip()
                for sid in [*s.depends_on_step_ids, *s.blocked_by_step_ids]
                if sid.strip()
            }
            if completed_step_id not in required_step_ids:
                continue
            if not required_step_ids.issubset(done_step_ids):
                continue
            self.upsert_world_model_plan_step(
                s.model_copy(
                    update={
                        "status": "active",
                        "blocked_reason": "",
                        "blocked_by_step_ids": [],
                        "updated_at": updated_at,
                    }
                )
            )

        # Re-read steps after possible unblocking.
        steps = self.list_world_model_plan_steps(plan_id=plan_id, limit=1000)
        incomplete_steps = [s for s in steps if s.status not in {"done", "completed"}]

        if not incomplete_steps:
            self.upsert_world_model_action_plan(
                plan.model_copy(
                    update={
                        "status": "done",
                        "selected_step_id": None,
                        "updated_at": updated_at,
                    }
                )
            )
            return

        # Pick selected_step_id: prefer in_progress > active > blocked.
        selected_step_id = next(
            (s.step_id for s in steps if s.status == "in_progress"), None
        )
        plan_status = "active"
        if selected_step_id is None:
            selected_step_id = next(
                (s.step_id for s in steps if s.status == "active"), None
            )
        if selected_step_id is None:
            selected_step_id = next(
                (s.step_id for s in steps if s.status == "blocked"), None
            )
            if selected_step_id is not None:
                plan_status = "blocked"
        if selected_step_id is None:
            selected_step_id = incomplete_steps[0].step_id

        self.upsert_world_model_action_plan(
            plan.model_copy(
                update={
                    "status": plan_status,
                    "selected_step_id": selected_step_id,
                    "updated_at": updated_at,
                }
            )
        )

    # ======================================================================
    # World-model goals / tasks / commitments
    # ======================================================================

    def upsert_world_model_goal(self, goal: WorldModelGoal) -> None:
        """Store a world-model goal and maintain provenance links."""
        self._fathom.world_model.upsert_wm_goal(
            goal.goal_id,
            goal.title,
            status=goal.status,
            priority=goal.priority,
            parent_goal_id=goal.parent_goal_id,
            description=goal.description,
            blocked_by_goal_id=goal.blocked_by_goal_id,
            blocked_reason=goal.blocked_reason,
            failure_reason=goal.failure_reason,
            deadline_text=goal.deadline_text,
            payload=goal.payload,
            source_surface=goal.source_surface,
        )
        if goal.parent_goal_id:
            self.upsert_world_model_provenance_link(
                WorldModelProvenanceLink(
                    link_id=(
                        f"world_model_goal:{goal.goal_id}"
                        f"->child_of:world_model_goal:{goal.parent_goal_id}"
                    ),
                    source_record_type="world_model_goal",
                    source_record_id=goal.goal_id,
                    target_record_type="world_model_goal",
                    target_record_id=goal.parent_goal_id,
                    relationship="child_of",
                    created_at=goal.updated_at,
                )
            )
        if goal.blocked_by_goal_id:
            self.upsert_world_model_provenance_link(
                WorldModelProvenanceLink(
                    link_id=(
                        f"world_model_goal:{goal.goal_id}"
                        f"->blocked_by:world_model_goal:{goal.blocked_by_goal_id}"
                    ),
                    source_record_type="world_model_goal",
                    source_record_id=goal.goal_id,
                    target_record_type="world_model_goal",
                    target_record_id=goal.blocked_by_goal_id,
                    relationship="blocked_by",
                    created_at=goal.updated_at,
                )
            )

    def load_world_model_goal(self, goal_id: str) -> WorldModelGoal | None:
        """Load a world-model goal."""
        return self._fathom.world_model.load_wm_goal(goal_id)

    def list_world_model_goals(
        self,
        *,
        status: str | None = None,
        parent_goal_id: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelGoal]:
        """List world-model goals."""
        goals = self._fathom.world_model.list_wm_goals(status=status, limit=limit)
        if parent_goal_id is not None:
            goals = [g for g in goals if g.parent_goal_id == parent_goal_id]
        return goals

    def upsert_world_model_task(self, task: WorldModelTask) -> None:
        """Store a world-model task and maintain provenance links."""
        from memex.world_model_task_commitment import (
            build_world_model_task_provenance_links,
        )

        self._fathom.world_model.upsert_wm_task(
            task.task_id,
            task.task_kind,
            task.title,
            goal_id=task.goal_id,
            status=task.status,
            scheduled_task_id=task.scheduled_task_id,
            description=task.description,
            due_at=task.due_at,
            payload=task.payload,
            source_surface=task.source_surface,
        )
        # Replace stale provenance links for this task
        self._fathom.world_model.delete_provenance_links_for_source(
            "world_model_task",
            task.task_id,
        )
        for link in build_world_model_task_provenance_links(task):
            self.upsert_world_model_provenance_link(link)

    def load_world_model_task(self, task_id: str) -> WorldModelTask | None:
        """Load a world-model task."""
        return self._fathom.world_model.load_wm_task(task_id)

    def list_world_model_tasks(
        self,
        *,
        goal_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelTask]:
        """List world-model tasks."""
        return self._fathom.world_model.list_wm_tasks(
            goal_id=goal_id,
            status=status,
            limit=limit,
        )

    def delete_world_model_task(self, task_id: str) -> None:
        """Delete a world-model task."""
        self._fathom.world_model.delete_wm_task(task_id)

    def upsert_world_model_commitment(self, commitment: WorldModelCommitment) -> None:
        """Store a world-model commitment and maintain provenance links."""
        from memex.world_model_task_commitment import (
            build_world_model_commitment_provenance_links,
        )

        self._fathom.world_model.upsert_wm_commitment(
            commitment.commitment_id,
            commitment.title,
            meeting_id=commitment.meeting_id,
            goal_id=commitment.goal_id,
            status=commitment.status,
            source_record_type=commitment.source_record_type,
            source_record_id=commitment.source_record_id,
            semantic_item_id=commitment.semantic_item_id,
            description=commitment.description,
            assignee=commitment.assignee,
            deadline_text=commitment.deadline_text,
            agreed_by=commitment.agreed_by,
            payload=commitment.payload,
            source_surface=commitment.source_surface,
        )
        # Replace stale provenance links for this commitment
        self._fathom.world_model.delete_provenance_links_for_source(
            "world_model_commitment",
            commitment.commitment_id,
        )
        for link in build_world_model_commitment_provenance_links(commitment):
            self.upsert_world_model_provenance_link(link)

    def load_world_model_commitment(
        self,
        commitment_id: str,
    ) -> WorldModelCommitment | None:
        """Load a world-model commitment."""
        return self._fathom.world_model.load_wm_commitment(commitment_id)

    def list_world_model_commitments(
        self,
        *,
        meeting_id: str | None = None,
        goal_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelCommitment]:
        """List world-model commitments."""
        return self._fathom.world_model.list_wm_commitments(
            meeting_id=meeting_id,
            goal_id=goal_id,
            status=status,
            limit=limit,
        )

    def delete_world_model_commitment(self, commitment_id: str) -> None:
        """Delete a world-model commitment."""
        self._fathom.world_model.delete_wm_commitment(commitment_id)

    # ======================================================================
    # World-model provenance
    # ======================================================================

    def upsert_world_model_provenance_link(
        self,
        link: WorldModelProvenanceLink,
    ) -> None:
        """Store a provenance link.

        Resolves source/target titles and statuses at write time and
        denormalizes them onto the WMProvenanceLink node so m005's
        property FTS can index them. This is the write-path half of the
        ``search_dependency_documents`` migration off the 5000-row Python
        scan — see ``dev/notes/wm-provenance-link-denormalization.md``.
        """
        from memex.memory.world_model_reads import resolve_record_title_status

        src_title, src_status = resolve_record_title_status(
            self, link.source_record_type, link.source_record_id
        )
        tgt_title, tgt_status = resolve_record_title_status(
            self, link.target_record_type, link.target_record_id
        )
        self._fathom.world_model.create_provenance_link(
            link.source_record_type,
            link.source_record_id,
            link.target_record_type,
            link.target_record_id,
            link.relationship,
            source_title=src_title,
            source_status=src_status,
            target_title=tgt_title,
            target_status=tgt_status,
        )

    def list_world_model_provenance_links(
        self,
        *,
        source_record_id: str | None = None,
        source_record_type: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelProvenanceLink]:
        """List provenance links."""
        dicts = self._fathom.world_model.list_provenance_links(
            source_type=source_record_type,
            source_id=source_record_id,
        )
        results: list[WorldModelProvenanceLink] = []
        for d in dicts[:limit]:
            d = dict(d)
            d.pop("logical_id", None)
            if isinstance(d.get("created_at"), str):
                d["created_at"] = datetime.fromisoformat(d["created_at"])
            # Map stored field names to model field names
            results.append(
                WorldModelProvenanceLink(
                    link_id=d.get(
                        "link_id",
                        f"{d.get('source_type', '')}:"
                        f"{d.get('source_id', '')}:"
                        f"{d.get('target_type', '')}:"
                        f"{d.get('target_id', '')}",
                    ),
                    source_record_type=d.get("source_type", ""),
                    source_record_id=d.get("source_id", ""),
                    target_record_type=d.get("target_type", ""),
                    target_record_id=d.get("target_id", ""),
                    relationship=d.get("relationship", ""),
                    created_at=d.get("created_at", utcnow()),
                )
            )
        return results

    # ======================================================================
    # Prompt control
    # ======================================================================

    def upsert_prompt_control_artifact(self, artifact: PromptControlArtifact) -> None:
        """Store a prompt control artifact."""
        self._fathom.world_model.upsert_prompt_control_artifact(
            artifact.artifact_id,
            artifact.session_id,
            artifact.raw_input,
            artifact.classification,
            artifact.selected_path,
            artifact.route_profile.value
            if hasattr(artifact.route_profile, "value")
            else str(artifact.route_profile),
            prompt_mode=artifact.prompt_mode,
            intent_id=artifact.intent_id,
            conversation_turn_id=artifact.conversation_turn_id,
            tool_policy=artifact.tool_policy,
            validation_policy=artifact.validation_policy,
            memory_policy=artifact.memory_policy,
            response_contract=artifact.response_contract,
            route_rationale=artifact.route_rationale,
            parse_confidence=artifact.parse_confidence,
            ambiguity_score=artifact.ambiguity_score,
            stylization_drift=artifact.stylization_drift,
            high_stakes=artifact.high_stakes,
            detected_signals=artifact.detected_signals,
            plan_snapshot=artifact.plan_snapshot.model_dump(mode="json")
            if artifact.plan_snapshot is not None
            else None,
            tool_candidate_names=artifact.tool_candidate_names,
            lint_warnings=[w.model_dump(mode="json") for w in artifact.lint_warnings]
            if artifact.lint_warnings
            else [],
            parser_version=artifact.parser_version,
            routing_version=artifact.routing_version,
            source_surface=artifact.source_surface,
        )

    def load_latest_prompt_control_artifact(
        self,
        session_id: str,
    ) -> PromptControlArtifact | None:
        """Load latest prompt control artifact."""
        return self._fathom.world_model.load_latest_prompt_control(session_id)

    def list_prompt_control_artifacts(
        self,
        session_id: str,
        limit: int = 20,
    ) -> list[PromptControlArtifact]:
        """List prompt control artifacts."""
        return self._fathom.world_model.list_prompt_control_artifacts(
            session_id,
            limit=limit,
        )

    # ======================================================================
    # Semantic mappings
    # ======================================================================

    def replace_world_model_semantic_mappings(
        self,
        *,
        scope_type: str,
        scope_key: str,
        mappings: list[WorldModelSemanticMapping],
    ) -> None:
        """Replace semantic mappings for a scope."""
        raw_mappings = [
            {
                "mapping_kind": m.mapping_kind,
                "source_value": m.source_value,
                "target_value": m.target_value,
            }
            for m in mappings
        ]
        self._fathom.world_model.replace_semantic_mappings(
            scope_type,
            scope_key,
            raw_mappings,
        )

    def list_world_model_semantic_mappings(
        self,
        *,
        scope_type: str | None = None,
        scope_key: str | None = None,
        mapping_kind: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelSemanticMapping]:
        """List semantic mappings."""
        mappings = self._fathom.world_model.list_semantic_mappings(
            scope_type=scope_type,
            scope_key=scope_key,
        )
        if mapping_kind is not None:
            mappings = [m for m in mappings if m.mapping_kind == mapping_kind]
        return mappings[:limit]

    def load_world_model_semantic_mapping(
        self,
        mapping_id: str,
    ) -> WorldModelSemanticMapping | None:
        """Load a semantic mapping by ID."""
        return self._fathom.world_model.load_semantic_mapping(mapping_id)

    # ======================================================================
    # Knowledge objects & entity links
    # ======================================================================

    def sync_world_model_knowledge_from_item(self, item: Item) -> None:
        """Sync knowledge from an item -- create/update a WMKnowledgeObject."""
        knowledge_id = f"knowledge/{item.item_id}"
        metadata = getattr(item, "metadata", None) or {}
        typed = metadata.get("typed_knowledge") or {}
        item_type_str = (
            item.type.value if hasattr(item.type, "value") else str(item.type)
        )
        knowledge_type = typed.get("knowledge_type") or ""
        if not knowledge_type and typed.get("claim_kind"):
            knowledge_type = "claim"
        if not knowledge_type and item_type_str == "conversation":
            knowledge_type = "session_summary"
        if not knowledge_type and item_type_str == "article":
            knowledge_type = "reference"
        if not knowledge_type:
            knowledge_type = item_type_str
        canonical_key = item.source_url or item.item_id
        payload: dict[str, Any] = {}
        if typed:
            payload.update(typed)
            payload["typed"] = typed
        if metadata.get("remember_source"):
            payload["remember_source"] = metadata["remember_source"]
        if metadata.get("interface"):
            payload["interface"] = metadata["interface"]
        if metadata.get("corrections"):
            payload["corrections"] = metadata["corrections"]
        payload["metadata"] = _build_knowledge_metadata(metadata)
        self._fathom.world_model.upsert_knowledge_object(
            knowledge_id,
            item.item_id,
            knowledge_type,
            canonical_key,
            title=item.title,
            source_url=item.source_url,
            source_surface="memex:knowledge-sync",
            payload=payload,
        )
        # Sync knowledge relationships from typed_knowledge
        relationships = typed.get("relationships") or []
        for rel in relationships:
            if not isinstance(rel, dict):
                continue
            rel_kind = str(rel.get("relationship_kind") or "").strip()
            target_item_id = str(rel.get("target_item_id") or "").strip()
            if not rel_kind or not target_item_id:
                continue
            target_knowledge_id = f"knowledge/{target_item_id}"
            rel_id = f"{knowledge_id}:{rel_kind}:{target_knowledge_id}"
            try:
                self._fathom.world_model.upsert_knowledge_relationship(
                    rel_id,
                    knowledge_id,
                    target_knowledge_id,
                    rel_kind,
                    summary=str(rel.get("summary") or ""),
                    source_surface="memex:knowledge-sync",
                )
            except Exception:
                pass
        # Sync claim evaluations from typed_knowledge
        claim_evals = typed.get("claim_evaluations") or []
        for ce in claim_evals:
            if not isinstance(ce, dict):
                continue
            eval_kind = str(ce.get("evaluation_kind") or "").strip()
            eval_title = str(ce.get("title") or "").strip()
            if not eval_kind or not eval_title:
                continue
            eval_id = f"{knowledge_id}:{eval_kind}:{eval_title}"
            try:
                self._fathom.world_model.upsert_claim_evaluation(
                    eval_id,
                    knowledge_id,
                    item.item_id,
                    eval_kind,
                    eval_title,
                    summary=str(ce.get("summary") or ""),
                    status=str(ce.get("status") or "active"),
                    payload=ce,
                    source_surface="memex:knowledge-sync",
                )
            except Exception:
                pass

    def list_world_model_knowledge_objects(
        self,
        *,
        limit: int = 500,
    ) -> list[WorldModelKnowledgeObject]:
        """List world-model knowledge objects."""
        return self._fathom.world_model.list_knowledge_objects(limit=limit)

    def load_world_model_knowledge_object_by_item_id(
        self,
        item_id: str,
    ) -> WorldModelKnowledgeObject | None:
        """Load knowledge object by item ID."""
        return self._fathom.world_model.load_knowledge_object_by_item_id(item_id)

    def list_world_model_knowledge_entity_links(
        self,
        knowledge_id: str,
    ) -> list[WorldModelKnowledgeEntityLink]:
        """List knowledge entity links."""
        return self._fathom.world_model.list_knowledge_entity_links(knowledge_id)

    def list_world_model_knowledge_relationships(
        self,
        *,
        source_knowledge_id: str | None = None,
        target_knowledge_id: str | None = None,
        relationship_kind: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelKnowledgeRelationship]:
        """List knowledge relationships."""
        return self._fathom.world_model.list_knowledge_relationships(
            source_knowledge_id=source_knowledge_id,
            target_knowledge_id=target_knowledge_id,
            relationship_kind=relationship_kind,
            limit=limit,
        )

    def list_world_model_claim_evaluations(
        self,
        *,
        knowledge_id: str | None = None,
        item_id: str | None = None,
        evaluation_kind: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelClaimEvaluation]:
        """List claim evaluations."""
        evals = self._fathom.world_model.list_claim_evaluations(
            knowledge_id=knowledge_id,
            limit=limit,
        )
        if item_id is not None:
            evals = [e for e in evals if e.item_id == item_id]
        if evaluation_kind is not None:
            evals = [e for e in evals if e.evaluation_kind == evaluation_kind]
        return evals

    def load_world_model_claim_evaluation(
        self,
        evaluation_id: str,
    ) -> WorldModelClaimEvaluation | None:
        """Load a claim evaluation."""
        return self._fathom.world_model.load_claim_evaluation(evaluation_id)

    # ======================================================================
    # Conversation log
    # ======================================================================

    # Adapter decision: ConversationRepository stores turns as fathomdb
    # nodes with properties (session_id, role, content, timestamp) and
    # optionally serialised classification/reflect_result JSON. The
    # ConversationTurn model has richer fields, but the model-to-dict and
    # dict-to-result conversions happen here at the facade boundary so the
    # conversation repo itself needs no change.

    def log_turn(self, session_id: str, turn: ConversationTurn) -> None:
        """Log a conversation turn."""
        try:
            self._fathom.conversation.log_turn(
                session_id,
                turn.role,
                turn.content,
                turn.timestamp,
                classification=(
                    turn.classification.model_dump_json()
                    if turn.classification
                    else None
                ),
                reflect_result=(
                    turn.reflect_result.model_dump_json()
                    if turn.reflect_result
                    else None
                ),
            )
        except Exception:
            logger.debug("Failed to log turn via FathomStore", exc_info=True)

    def query_conversation_log(
        self,
        *,
        session_id: str | None = None,
        role: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[dict]:
        """Query conversation log entries."""
        return self._fathom.conversation.query(
            session_id=session_id,
            role=role,
            since=since,
            limit=limit,
        )

    def fts_search_conversations(
        self,
        query: str,
        *,
        limit: int = 20,
        since: datetime | None = None,
    ) -> list[dict]:
        """Full-text search conversations."""
        # FathomStore search doesn't have a since parameter; filter client-side
        results = self._fathom.conversation.search(query, limit=limit)
        if since is not None:
            since_iso = since.isoformat()
            results = [r for r in results if r.get("timestamp", "") >= since_iso]
        return results

    def get_conversation_context(
        self,
        row_id: int,
        *,
        window: int = 5,
    ) -> list[dict]:
        """Get conversation context around a turn.

        Legacy callers pass integer row_id; fathomdb uses logical_id
        strings (e.g. ``turn:abc123``).  An integer row_id cannot be
        meaningfully translated to a logical_id, so this method is a no-op
        stub.
        TODO(phase-4g): callers must be updated to pass a logical_id instead.
        """
        return []

    def cleanup_conversation_log(self, before: datetime) -> int:
        """Remove old conversation entries."""
        return self._fathom.conversation.cleanup(before=before)

    # ======================================================================
    # Audit & health
    # ======================================================================

    def log_audit(self, entry: AuditEntry) -> None:
        """Log an audit entry."""
        self._fathom.operational.append_audit(
            connector=entry.connector,
            action=entry.action,
            granted=entry.granted,
            goal_id=entry.goal_id,
            session_id=entry.session_id,
            result_summary=entry.result_summary,
            duration_ms=entry.duration_ms,
        )

    def query_audit(
        self,
        *,
        connector: str | None = None,
        goal_id: str | None = None,
        session_id: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[AuditEntry]:
        """Query audit log entries."""
        rows = self._fathom.operational.list_audit(
            connector=connector,
            session_id=session_id,
            goal_id=goal_id,
            limit=limit,
        )
        results: list[AuditEntry] = []
        for r in rows:
            ts_str = r.get("timestamp", "")
            ts = datetime.fromisoformat(ts_str) if ts_str else utcnow()
            if since is not None and ts < since:
                continue
            results.append(
                AuditEntry(
                    timestamp=ts,
                    connector=r.get("connector", ""),
                    action=r.get("action", ""),
                    granted=r.get("granted", True),
                    goal_id=r.get("goal_id"),
                    session_id=r.get("session_id"),
                    result_summary=r.get("result_summary", ""),
                    duration_ms=r.get("duration_ms"),
                )
            )
        return results

    def save_connector_health(self, health: ConnectorHealth) -> None:
        """Save connector health status."""
        self._fathom.operational.put_connector_health(
            health.name,
            status=health.status,
            error=health.error,
            tools_discovered=health.tools_discovered,
        )

    def load_connector_health(self) -> list[ConnectorHealth]:
        """Load all connector health records."""
        rows = self._fathom.operational.list_connector_health()
        results: list[ConnectorHealth] = []
        for r in rows:
            ts_str = r.get("last_check", "")
            ts = datetime.fromisoformat(ts_str) if ts_str else utcnow()
            results.append(
                ConnectorHealth(
                    name=r.get("name", ""),
                    status=r.get("status", "unavailable"),
                    last_check=ts,
                    error=r.get("error"),
                    tools_discovered=r.get("tools_discovered", 0),
                )
            )
        return results

    def record_tool_usage(self, tool_name: str, keywords_matched: list[str]) -> None:
        """Record tool usage statistics."""
        for kw in keywords_matched:
            self._fathom.operational.record_tool_usage(tool_name, kw)

    def get_tool_usage_stats(self, tool_name: str | None = None) -> list[dict]:
        """Return tool usage statistics, optionally filtered by tool_name."""
        return self._fathom.operational.get_tool_usage_stats(tool_name=tool_name)

    # ======================================================================
    # Lifecycle
    # ======================================================================

    def close(self) -> None:
        """Close the underlying store."""
        self._fathom.close()
