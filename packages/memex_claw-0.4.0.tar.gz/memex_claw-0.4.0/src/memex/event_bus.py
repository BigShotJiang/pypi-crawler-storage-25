"""Lightweight in-process domain event bus.

Stdlib only — zero application imports. Extractable as a standalone library.

Publishers call publish(event) from any thread. A single consumer thread
drains the queue and dispatches to subscribers registered by event type.
Subscriber exceptions never propagate to publishers.
"""

from __future__ import annotations

import logging
import queue
import threading
from typing import Any, Callable

logger = logging.getLogger(__name__)

Subscriber = Callable[[Any], None]


class EventBus:
    """Thread-safe in-process pub/sub event bus.

    - publish() is non-blocking (enqueues to SimpleQueue)
    - Single consumer thread dispatches to subscribers
    - isinstance dispatch: subscribing to a base class receives subclass events
    - Subscriber exceptions are swallowed (logged at debug level)
    """

    def __init__(self) -> None:
        self._subscribers: dict[type, list[Subscriber]] = {}
        self._lock = threading.Lock()
        self._queue: queue.SimpleQueue = queue.SimpleQueue()
        self._shutdown = threading.Event()
        self._thread: threading.Thread | None = None

    def subscribe(self, event_type: type, fn: Subscriber) -> None:
        """Register a subscriber for a specific event type."""
        with self._lock:
            self._subscribers.setdefault(event_type, []).append(fn)

    def unsubscribe(self, event_type: type, fn: Subscriber) -> None:
        """Remove a subscriber. No-op if not found."""
        with self._lock:
            subs = self._subscribers.get(event_type, [])
            try:
                subs.remove(fn)
            except ValueError:
                pass

    def publish(self, event: object) -> None:
        """Enqueue an event for dispatch. Never blocks, never raises."""
        try:
            self._queue.put(event)
        except Exception:
            logger.debug("Failed to enqueue event", exc_info=True)

    def start(self) -> None:
        """Start the consumer thread."""
        if self._thread is not None:
            return
        self._shutdown.clear()
        self._thread = threading.Thread(
            target=self._consumer_loop,
            daemon=True,
            name="memex-event-bus",
        )
        self._thread.start()

    def stop(self, timeout: float = 5) -> None:
        """Signal shutdown, drain remaining events, then join."""
        self._shutdown.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            self._thread = None

    def _consumer_loop(self) -> None:
        """Drain queue and dispatch to subscribers."""
        try:
            while not self._shutdown.is_set():
                try:
                    event = self._queue.get(timeout=0.5)
                except queue.Empty:
                    continue
                self._dispatch(event)
            # Drain remaining events after shutdown signal
            while True:
                try:
                    event = self._queue.get_nowait()
                except queue.Empty:
                    break
                self._dispatch(event)
        except Exception:
            logger.error("Event bus consumer thread crashed", exc_info=True)

    def _dispatch(self, event: object) -> None:
        """Dispatch an event to all matching subscribers."""
        with self._lock:
            snapshot = [
                (event_type, list(subs))
                for event_type, subs in self._subscribers.items()
            ]
        for event_type, subs in snapshot:
            if isinstance(event, event_type):
                for fn in subs:
                    try:
                        fn(event)
                    except Exception:
                        logger.debug(
                            "Subscriber %s failed for %s",
                            fn,
                            type(event).__name__,
                            exc_info=True,
                        )


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_bus: EventBus | None = None
_bus_lock = threading.Lock()


def get_bus() -> EventBus:
    """Get or create the process-global event bus singleton."""
    global _bus
    if _bus is None:
        with _bus_lock:
            if _bus is None:
                _bus = EventBus()
                _bus.start()
    return _bus


def safe_publish(event: Any) -> None:
    """Publish a domain event, swallowing any errors.

    Use this from code where the event bus may not be initialized yet
    or where event delivery must never interrupt the caller.
    """
    try:
        get_bus().publish(event)
    except Exception:
        pass


def reset_bus() -> None:
    """Stop and discard the singleton. For tests."""
    global _bus
    with _bus_lock:
        if _bus is not None:
            _bus.stop()
            _bus = None
