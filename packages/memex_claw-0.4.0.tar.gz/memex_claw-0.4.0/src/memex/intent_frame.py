"""Intent-frame bridge between classification and execution."""

from __future__ import annotations

import re

from memex.models import (
    ConversationTurn,
    Goal,
    InputClassification,
    IntentActionCandidate,
    IntentFrame,
    IntentFramePath,
    IntentSlotState,
)
from memex.utcnow import utcnow

_AMBIGUOUS_REFERENCES = {
    "this",
    "that",
    "it",
    "these",
    "those",
    "them",
    "there",
    "here",
}

_NONAMBIGUOUS_CLAUSE_STARTERS = {
    "i",
    "you",
    "we",
    "they",
    "he",
    "she",
    "it",
    "the",
    "a",
    "an",
    "my",
    "your",
    "our",
    "his",
    "her",
    "their",
}

_RELATIVE_CLAUSE_FOLLOWERS = {
    "am",
    "are",
    "be",
    "been",
    "being",
    "can",
    "could",
    "did",
    "do",
    "does",
    "had",
    "has",
    "have",
    "is",
    "may",
    "might",
    "must",
    "should",
    "was",
    "were",
    "will",
    "would",
    "we",
    "you",
    "they",
    "he",
    "she",
    "who",
}

_NONAMBIGUOUS_OBJECT_FOLLOWERS = {
    "article",
    "bug",
    "code",
    "conversation",
    "doc",
    "document",
    "email",
    "file",
    "goal",
    "issue",
    "item",
    "link",
    "meeting",
    "message",
    "note",
    "notes",
    "page",
    "plan",
    "problem",
    "question",
    "recording",
    "reminder",
    "site",
    "summary",
    "task",
    "thread",
    "ticket",
    "transcript",
    "url",
    "video",
    "website",
    "job",
}


def _is_resolved_reference(
    token: str,
    previous_token: str | None,
    next_token: str | None,
) -> bool:
    if next_token is None:
        return False

    if token == "that" and next_token in _NONAMBIGUOUS_CLAUSE_STARTERS:
        return True

    if (
        token == "that"
        and previous_token is not None
        and previous_token not in _AMBIGUOUS_REFERENCES
        and next_token in _RELATIVE_CLAUSE_FOLLOWERS
    ):
        return True

    if (
        token in {"this", "that", "these", "those"}
        and next_token in _NONAMBIGUOUS_OBJECT_FOLLOWERS
    ):
        return True

    return False


def _find_unresolved_references(
    user_input: str,
    *,
    recent_turns: list[ConversationTurn] | None = None,
    active_goals: list[Goal] | None = None,
    goal_id: str | None = None,
) -> list[str]:
    recent_text = " ".join(
        turn.content.lower().strip() for turn in recent_turns or [] if turn.content
    )
    recent_tokens = set(re.findall(r"\b[\w'-]+\b", recent_text))
    has_resolving_context = (
        bool(goal_id)
        or bool(recent_tokens & _NONAMBIGUOUS_OBJECT_FOLLOWERS)
        or "http://" in recent_text
        or "https://" in recent_text
        or "memex://" in recent_text
    )

    tokens = re.findall(r"\b[\w'-]+\b", user_input.lower())
    found: list[str] = []
    for index, token in enumerate(tokens):
        if token not in _AMBIGUOUS_REFERENCES:
            continue
        previous_token = tokens[index - 1] if index > 0 else None
        next_token = tokens[index + 1] if index + 1 < len(tokens) else None
        if _is_resolved_reference(token, previous_token, next_token):
            continue
        if has_resolving_context:
            continue
        if token not in found:
            found.append(token)
    return found


def _slugify_slot_name(value: str, *, prefix: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")
    slug = slug[:48].strip("_")
    return f"{prefix}_{slug}" if slug else prefix


def _build_slot_states(
    unresolved_references: list[str],
    missing_information: list[str],
    *,
    include_missing_information: bool = True,
) -> list[IntentSlotState]:
    slot_states: list[IntentSlotState] = []

    for reference in unresolved_references:
        slot_states.append(
            IntentSlotState(
                name=_slugify_slot_name(reference, prefix="reference"),
                status="unresolved",
                description=f"Resolve what '{reference}' refers to.",
                source="reference_resolution",
                required=True,
            )
        )

    if include_missing_information:
        for index, detail in enumerate(missing_information, start=1):
            slot_states.append(
                IntentSlotState(
                    name=f"context_{index}",
                    status="missing",
                    description=detail,
                    source="missing_information",
                    required=True,
                )
            )

    return slot_states


def build_intent_frame(
    user_input: str,
    *,
    classification: InputClassification,
    recent_turns: list[ConversationTurn] | None = None,
    active_goals: list[Goal] | None = None,
) -> IntentFrame:
    unresolved = _find_unresolved_references(
        user_input,
        recent_turns=recent_turns,
        active_goals=active_goals,
        goal_id=classification.goal_id,
    )
    summary = classification.suggested_title or user_input[:120]
    path = IntentFramePath.DIRECT_ANSWER
    rationale = classification.reasoning
    missing_information: list[str] = []

    if (
        classification.confidence <= 0.05
        and "fallback" in classification.reasoning.lower()
    ):
        path = IntentFramePath.ABSTAIN
        rationale = "classification fallback with very low confidence"
        missing_information.append("more context or a rephrased request")
    elif unresolved:
        rationale = "clarify unresolved references before acting"
        missing_information.extend([f"what '{ref}' refers to" for ref in unresolved])
    elif classification.classification.value in {"advances_goal", "new_goal"}:
        path = IntentFramePath.ACT

    slot_states = _build_slot_states(
        [] if path == IntentFramePath.ABSTAIN else unresolved,
        missing_information,
        include_missing_information=(path == IntentFramePath.ABSTAIN or not unresolved),
    )
    unresolved_required_slots = [
        slot.name for slot in slot_states if slot.required and slot.status != "resolved"
    ]
    if unresolved_required_slots and path != IntentFramePath.ABSTAIN:
        path = IntentFramePath.CLARIFY

    selected_action_candidate = IntentActionCandidate(
        name=path.value,
        kind="tool_path" if path == IntentFramePath.ACT else "response_path",
        selected=True,
        rationale=rationale,
        required_slots=[slot.name for slot in slot_states if slot.required],
        unresolved_required_slots=unresolved_required_slots,
    )

    return IntentFrame(
        raw_input=user_input,
        classification=classification.classification,
        goal_id=classification.goal_id,
        summary=summary,
        selected_path=path,
        selected_action_candidate=selected_action_candidate,
        unresolved_references=unresolved,
        missing_information=missing_information,
        slot_states=slot_states,
        confidence=classification.confidence,
        rationale=rationale,
        created_at=utcnow(),
    )


def render_intent_response(frame: IntentFrame) -> str:
    selected_candidate = frame.selected_action_candidate
    selected_name = (
        selected_candidate.name
        if selected_candidate is not None
        else frame.selected_path.value
    )
    if selected_name == IntentFramePath.CLARIFY.value:
        unresolved_required_slots = (
            set(selected_candidate.unresolved_required_slots)
            if selected_candidate is not None
            else {
                slot.name
                for slot in frame.slot_states
                if slot.required and slot.status != "resolved"
            }
        )
        unresolved_slots = [
            slot for slot in frame.slot_states if slot.name in unresolved_required_slots
        ]
        unresolved_references = [
            slot.description.removeprefix("Resolve what ").removesuffix(" refers to.")
            for slot in unresolved_slots
            if slot.source == "reference_resolution"
        ]
        if unresolved_references:
            refs = ", ".join(unresolved_references)
            return f"I'm not sure what {refs} refers to here. Please clarify what you want me to act on."
        if unresolved_slots:
            requested = "; ".join(slot.description for slot in unresolved_slots)
            return f"Please clarify: {requested}"
        return "Please clarify what you want me to act on."
    if selected_name == IntentFramePath.ABSTAIN.value:
        return "I don't have enough confidence to act on that yet. Please rephrase or add a bit more context."
    return ""
