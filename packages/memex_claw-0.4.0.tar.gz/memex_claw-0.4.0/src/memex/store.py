"""MemexStore Protocol.

Defines the abstract interface shared by FathomMemexStore (production)
and any future store implementations.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Protocol

from memex.models import (
    AgentSelfModel,
    AuditEntry,
    CalendarEvent,
    WorldModelClaimEvaluation,
    ConnectorHealth,
    ConversationTurn,
    Goal,
    GoalEntityLink,
    GoalStatus,
    HumanPartnerProfile,
    Item,
    MeetingEntityLink,
    MeetingGoalLink,
    PromptControlArtifact,
    SessionContext,
    WorldModelAction,
    WorldModelCommitment,
    WorldModelEntity,
    WorldModelEntityAttribute,
    WorldModelEntityType,
    WorldModelEvent,
    WorldModelActionPlan,
    WorldModelExecutionRecord,
    WorldModelGoal,
    WorldModelKnowledgeIngestRun,
    WorldModelIntent,
    WorldModelKnowledgeEntityLink,
    WorldModelKnowledgeRelationship,
    WorldModelKnowledgeObject,
    WorldModelObservation,
    WorldModelPlanStep,
    WorldModelPlanStepTransition,
    WorldModelProvenanceLink,
    WorldModelSemanticMapping,
    WorldModelTask,
)


class MemexStore(Protocol):
    """Abstract store interface for goals and related data."""

    # -- Sub-stores -------------------------------------------------------------
    @property
    def content(self) -> Any: ...
    @property
    def scheduler(self) -> Any: ...
    @property
    def meetings(self) -> Any: ...
    @property
    def settings(self) -> Any: ...
    @property
    def knowledge_backend(self) -> str: ...
    @property
    def knowledge_degraded_modes(self) -> list[str]: ...
    def rebuild_knowledge_projection(self) -> dict[str, int]: ...

    # -- Goals -----------------------------------------------------------------
    def create_goal(self, goal: Goal) -> None: ...
    def update_goal(self, goal: Goal) -> None: ...
    def get_goal(self, goal_id: str) -> Goal | None: ...
    def list_goals(self, status: GoalStatus | None = None) -> list[Goal]: ...
    def get_children(self, parent_id: str) -> list[Goal]: ...
    def get_tree(self, root_id: str | None = None) -> list[Goal]: ...
    def get_stale_goals(self, threshold: datetime) -> list[Goal]: ...
    def get_approaching_deadlines(self, horizon: datetime) -> list[Goal]: ...
    def create_goal_entity_link(self, link: GoalEntityLink) -> None: ...
    def list_goal_entity_links(self, goal_id: str) -> list[GoalEntityLink]: ...
    def list_goals_for_entity(self, entity_id: str) -> list[GoalEntityLink]: ...
    def create_meeting_goal_link(self, link: MeetingGoalLink) -> None: ...
    def list_meeting_goal_links(self, meeting_id: str) -> list[MeetingGoalLink]: ...
    def create_meeting_entity_link(self, link: MeetingEntityLink) -> None: ...
    def list_meeting_entity_links(self, meeting_id: str) -> list[MeetingEntityLink]: ...
    def upsert_calendar_event(self, event: CalendarEvent) -> None: ...
    def list_upcoming_calendar_events(
        self, horizon: datetime
    ) -> list[CalendarEvent]: ...

    # -- Partner / agent / session --------------------------------------------
    def save_partner_profile(self, profile: HumanPartnerProfile) -> None: ...
    def load_partner_profile(self) -> HumanPartnerProfile | None: ...
    def save_agent_self_model(self, model: AgentSelfModel) -> None: ...
    def load_agent_self_model(self) -> AgentSelfModel | None: ...
    def save_session(self, ctx: SessionContext) -> None: ...
    def load_session(self) -> SessionContext | None: ...
    def upsert_world_model_entity(self, entity: WorldModelEntity) -> None: ...
    def replace_world_model_entity_attributes(
        self, entity_id: str, attributes: list[WorldModelEntityAttribute]
    ) -> None: ...
    def load_world_model_entity(
        self, entity_type: WorldModelEntityType | str, canonical_key: str
    ) -> WorldModelEntity | None: ...
    def list_world_model_entity_attributes(
        self, entity_id: str, attribute_group: str | None = None
    ) -> list[WorldModelEntityAttribute]: ...
    def upsert_world_model_intent(self, intent: WorldModelIntent) -> None: ...
    def load_latest_world_model_intent(
        self, session_id: str
    ) -> WorldModelIntent | None: ...
    def upsert_world_model_action(self, action: WorldModelAction) -> None: ...
    def list_world_model_actions(
        self,
        *,
        session_id: str | None = None,
        meeting_id: str | None = None,
        intent_id: str | None = None,
        action_kind: str | None = None,
        limit: int = 50,
    ) -> list[WorldModelAction]: ...
    def delete_world_model_action_cascade(self, action_id: str) -> None: ...
    def upsert_world_model_observation(
        self, observation: WorldModelObservation
    ) -> None: ...
    def list_world_model_observations(
        self,
        *,
        action_id: str | None = None,
        session_id: str | None = None,
        meeting_id: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelObservation]: ...
    def upsert_world_model_event(self, event: WorldModelEvent) -> None: ...
    def list_world_model_events(
        self,
        *,
        session_id: str | None = None,
        meeting_id: str | None = None,
        event_kind: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelEvent]: ...
    def load_world_model_event(
        self,
        event_id: str,
    ) -> WorldModelEvent | None: ...
    def upsert_world_model_action_plan(self, plan: WorldModelActionPlan) -> None: ...
    def load_world_model_action_plan(
        self, plan_id: str
    ) -> WorldModelActionPlan | None: ...
    def list_world_model_action_plans(
        self,
        *,
        goal_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelActionPlan]: ...
    def upsert_world_model_plan_step(self, step: WorldModelPlanStep) -> None: ...
    def load_world_model_plan_step(self, step_id: str) -> WorldModelPlanStep | None: ...
    def list_world_model_plan_steps(
        self,
        *,
        plan_id: str | None = None,
        goal_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelPlanStep]: ...
    def upsert_world_model_execution_record(
        self, record: WorldModelExecutionRecord
    ) -> None: ...
    def load_world_model_execution_record(
        self, execution_id: str
    ) -> WorldModelExecutionRecord | None: ...
    def list_world_model_execution_records(
        self,
        *,
        session_id: str | None = None,
        plan_id: str | None = None,
        step_id: str | None = None,
        source_record_type: str | None = None,
        source_record_id: str | None = None,
        execution_kind: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelExecutionRecord]: ...
    def upsert_world_model_knowledge_ingest_run(
        self, run: WorldModelKnowledgeIngestRun
    ) -> None: ...
    def load_world_model_knowledge_ingest_run(
        self, ingest_run_id: str
    ) -> WorldModelKnowledgeIngestRun | None: ...
    def list_world_model_knowledge_ingest_runs(
        self,
        *,
        session_id: str | None = None,
        source_ref: str | None = None,
        status: str | None = None,
        knowledge_id: str | None = None,
        item_id: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelKnowledgeIngestRun]: ...
    def append_world_model_plan_step_transition(
        self, transition: WorldModelPlanStepTransition
    ) -> None: ...
    def load_world_model_plan_step_transition(
        self, transition_id: str
    ) -> WorldModelPlanStepTransition | None: ...
    def list_world_model_plan_step_transitions(
        self,
        *,
        step_id: str | None = None,
        plan_id: str | None = None,
        execution_id: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelPlanStepTransition]: ...
    def upsert_world_model_goal(self, goal: WorldModelGoal) -> None: ...
    def load_world_model_goal(self, goal_id: str) -> WorldModelGoal | None: ...
    def list_world_model_goals(
        self,
        *,
        status: str | None = None,
        parent_goal_id: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelGoal]: ...
    def upsert_world_model_task(self, task: WorldModelTask) -> None: ...
    def load_world_model_task(self, task_id: str) -> WorldModelTask | None: ...
    def list_world_model_tasks(
        self,
        *,
        goal_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelTask]: ...
    def delete_world_model_task(self, task_id: str) -> None: ...
    def upsert_world_model_commitment(
        self, commitment: WorldModelCommitment
    ) -> None: ...
    def load_world_model_commitment(
        self,
        commitment_id: str,
    ) -> WorldModelCommitment | None: ...
    def list_world_model_commitments(
        self,
        *,
        meeting_id: str | None = None,
        goal_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelCommitment]: ...
    def delete_world_model_commitment(self, commitment_id: str) -> None: ...
    def upsert_world_model_provenance_link(
        self, link: WorldModelProvenanceLink
    ) -> None: ...
    def list_world_model_provenance_links(
        self,
        *,
        source_record_id: str | None = None,
        source_record_type: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelProvenanceLink]: ...
    def upsert_prompt_control_artifact(
        self, artifact: PromptControlArtifact
    ) -> None: ...
    def load_latest_prompt_control_artifact(
        self, session_id: str
    ) -> PromptControlArtifact | None: ...
    def list_prompt_control_artifacts(
        self, session_id: str, limit: int = 20
    ) -> list[PromptControlArtifact]: ...
    def replace_world_model_semantic_mappings(
        self,
        *,
        scope_type: str,
        scope_key: str,
        mappings: list[WorldModelSemanticMapping],
    ) -> None: ...
    def list_world_model_semantic_mappings(
        self,
        *,
        scope_type: str | None = None,
        scope_key: str | None = None,
        mapping_kind: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelSemanticMapping]: ...
    def load_world_model_semantic_mapping(
        self,
        mapping_id: str,
    ) -> WorldModelSemanticMapping | None: ...
    def sync_world_model_knowledge_from_item(self, item: Item) -> None: ...
    def load_world_model_knowledge_object_by_item_id(
        self, item_id: str
    ) -> WorldModelKnowledgeObject | None: ...
    def list_world_model_knowledge_entity_links(
        self, knowledge_id: str
    ) -> list[WorldModelKnowledgeEntityLink]: ...
    def list_world_model_knowledge_relationships(
        self,
        *,
        source_knowledge_id: str | None = None,
        target_knowledge_id: str | None = None,
        relationship_kind: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelKnowledgeRelationship]: ...
    def list_world_model_claim_evaluations(
        self,
        *,
        knowledge_id: str | None = None,
        item_id: str | None = None,
        evaluation_kind: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelClaimEvaluation]: ...
    def load_world_model_claim_evaluation(
        self,
        evaluation_id: str,
    ) -> WorldModelClaimEvaluation | None: ...

    # -- Conversation log ------------------------------------------------------
    def log_turn(self, session_id: str, turn: ConversationTurn) -> None: ...
    def query_conversation_log(
        self,
        *,
        session_id: str | None = None,
        role: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[dict]: ...
    def fts_search_conversations(
        self,
        query: str,
        *,
        limit: int = 20,
        since: datetime | None = None,
    ) -> list[dict]: ...
    def get_conversation_context(
        self,
        row_id: int,
        *,
        window: int = 5,
    ) -> list[dict]: ...
    def cleanup_conversation_log(self, before: datetime) -> int: ...

    # -- Audit & health --------------------------------------------------------
    def log_audit(self, entry: AuditEntry) -> None: ...
    def query_audit(
        self,
        *,
        connector: str | None = None,
        goal_id: str | None = None,
        session_id: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[AuditEntry]: ...
    def save_connector_health(self, health: ConnectorHealth) -> None: ...
    def load_connector_health(self) -> list[ConnectorHealth]: ...
    def record_tool_usage(
        self, tool_name: str, keywords_matched: list[str]
    ) -> None: ...
    def get_tool_usage_stats(self, tool_name: str | None = None) -> list[dict]: ...

    # -- Lifecycle -------------------------------------------------------------
    def close(self) -> None: ...
