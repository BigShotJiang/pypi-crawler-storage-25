"""Input classification — LLM call #1 (cheap model, structured output).

Fast-path: regex pre-classifier handles obvious inputs (greetings, simple
questions) without an LLM round-trip (~0ms vs 1.4-1.8s).  Falls through
to LLM for ambiguous inputs.
"""

from __future__ import annotations

import logging
import re

from memex.llm import _get_cheap_model, chat_structured
from memex.models import (
    ConversationTurn,
    Goal,
    InputClassification,
    InputClassificationType,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Fast-path regex pre-classifier (P1 latency fix)
# ---------------------------------------------------------------------------

_GREETING_RE = re.compile(
    r"^(?:hi|hello|hey|good\s*(?:morning|afternoon|evening|night)|"
    r"howdy|yo|sup|what'?s\s*up|how\s*are\s*you|how'?s\s*it\s*going)\s*[!?.]*$",
    re.IGNORECASE,
)

_URL_RE = re.compile(r"https?://\S+", re.IGNORECASE)


def _fast_classify(
    user_input: str,
    active_goals: list[Goal],
) -> InputClassification | None:
    """Try to classify without an LLM call.  Returns None if ambiguous."""
    stripped = user_input.strip()

    # Greetings with no goal context
    if _GREETING_RE.match(stripped) and not active_goals:
        return InputClassification(
            classification=InputClassificationType.CONVERSATIONAL,
            confidence=0.90,
            reasoning="fast-path: greeting pattern",
        )

    # URL sharing → knowledge ingest
    if _URL_RE.search(stripped) and len(stripped.split()) <= 10:
        return InputClassification(
            classification=InputClassificationType.KNOWLEDGE_QUERY,
            confidence=0.85,
            reasoning="fast-path: URL detected",
        )

    return None


_SYSTEM_PROMPT = """\
You are an input classifier for a personal AI assistant called Memex.
Given the user's message, recent conversation turns, and active goals,
classify the input into exactly one of these types:

- advances_goal: The user is working on or discussing an existing goal.
  Set goal_id to the most relevant goal.
- new_goal: The user is expressing a new intent or desire that should become a goal.
  Leave goal_id null.
- conversational: General chat, greetings, or off-topic discussion.
  Leave goal_id null.
- clarification: The user is asking for clarification about something Memex said.
  Set goal_id if it relates to a specific goal.
- knowledge_query: The user is asking about information, facts, or stored knowledge.
  Not about a goal — about retrieving or reasoning over what Memex knows.
  Leave goal_id null.

If classification is new_goal, set suggested_title to a short (3-8 word) goal title.
Respond with JSON matching the schema. Be concise in reasoning (one line).
"""


def classify_input(
    user_input: str,
    *,
    active_goals: list[Goal],
    recent_turns: list[ConversationTurn] | None = None,
    model: str | None = None,
) -> InputClassification:
    """Classify user input. Falls back to CONVERSATIONAL on any failure."""
    # Fast-path: skip LLM for obvious inputs (saves 1.4-1.8s)
    fast = _fast_classify(user_input, active_goals)
    if fast is not None:
        logger.info(
            "classify: %s (goal=%s, conf=%.2f) — %s",
            fast.classification.value,
            fast.goal_id,
            fast.confidence,
            fast.reasoning,
        )
        return fast

    messages: list[dict[str, str]] = [{"role": "system", "content": _SYSTEM_PROMPT}]

    # Build context
    context_parts: list[str] = []
    if active_goals:
        goal_lines = [
            f"- [{g.goal_id[:8]}] {g.title} ({g.status.value})" for g in active_goals
        ]
        context_parts.append("Active goals:\n" + "\n".join(goal_lines))

    if recent_turns:
        turn_lines = [f"{t.role}: {t.content[:200]}" for t in recent_turns[-3:]]
        context_parts.append("Recent turns:\n" + "\n".join(turn_lines))

    if context_parts:
        messages.append({"role": "user", "content": "\n\n".join(context_parts)})
        messages.append(
            {
                "role": "assistant",
                "content": "I understand the context. What is the user's new input?",
            }
        )

    messages.append({"role": "user", "content": user_input})

    try:
        result = chat_structured(
            messages,
            InputClassification,
            model=model or _get_cheap_model(),
        )
        logger.info(
            "classify: %s (goal=%s, conf=%.2f) — %s",
            result.classification.value,
            result.goal_id,
            result.confidence,
            result.reasoning,
        )
        return result
    except Exception:
        logger.warning(
            "Classification failed, falling back to CONVERSATIONAL", exc_info=True
        )
        return InputClassification(
            classification=InputClassificationType.CONVERSATIONAL,
            confidence=0.0,
            reasoning="classification failed — fallback",
        )
