"""Runtime self-state registry for Memex.

Tracks current in-process state for services, interfaces, connectors,
plugins, activities, meeting runtime, queues, and sub-agents.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime
import threading
from typing import Any
from memex.utcnow import utcnow


@dataclass
class RuntimeStateRegistry:
    """Thread-safe registry for Memex runtime self-state."""

    started_at: datetime = field(default_factory=utcnow)

    def __post_init__(self) -> None:
        self._lock = threading.RLock()
        self._process: dict[str, Any] = {
            "started_at": self.started_at.isoformat(),
            "store_path": "",
            "degraded_modes": [],
        }
        self._goals: dict[str, int] = {
            "total": 0,
            "active": 0,
            "blocked": 0,
            "completed": 0,
        }
        self._session: dict[str, Any] = {
            "session_id": None,
            "turn_count": 0,
            "active_interface": "",
            "session_cost_usd": 0.0,
        }
        self._interfaces: dict[str, dict[str, Any]] = {}
        self._services: dict[str, dict[str, Any]] = {}
        self._connectors: dict[str, dict[str, Any]] = {}
        self._plugins: dict[str, dict[str, Any]] = {}
        self._activities: dict[str, dict[str, Any]] = {}
        self._meetings: dict[str, Any] = {
            "active_recording": None,
            "queued_transcriptions": 0,
            "running_transcriptions": 0,
            "recent_transcription_errors": [],
        }
        self._queues: dict[str, Any] = {
            "scheduler_running": False,
            "work_queue_paused": False,
            "work_queue_pending": 0,
            "work_queue_running": 0,
            "retrying_count": 0,
            "items": [],
        }
        self._subagents: dict[str, Any] = {
            "running_count": 0,
            "agents": [],
        }
        self._resources: dict[str, Any] = {}
        self._errors: list[dict[str, Any]] = []
        self.set_interface_state(
            "meeting_capture",
            enabled=True,
            running=False,
            status="idle",
            owner="tui_local",
        )
        self.set_interface_state(
            "transcription_engine",
            enabled=True,
            running=False,
            status="idle",
            owner="tui_local",
        )

    def set_process_info(
        self,
        *,
        store_path: str = "",
        degraded_modes: list[str] | None = None,
    ) -> None:
        with self._lock:
            if store_path:
                self._process["store_path"] = store_path
            if degraded_modes is not None:
                self._process["degraded_modes"] = list(degraded_modes)

    def set_goals(
        self, *, total: int, active: int, blocked: int = 0, completed: int = 0
    ) -> None:
        with self._lock:
            self._goals = {
                "total": total,
                "active": active,
                "blocked": blocked,
                "completed": completed,
            }

    def set_session(
        self,
        *,
        session_id: str | None,
        turn_count: int = 0,
        active_interface: str = "",
        session_cost_usd: float | None = None,
    ) -> None:
        with self._lock:
            self._session = {
                "session_id": session_id,
                "turn_count": turn_count,
                "active_interface": active_interface,
                "session_cost_usd": (
                    self._session.get("session_cost_usd", 0.0)
                    if session_cost_usd is None
                    else session_cost_usd
                ),
            }

    def set_interface_state(
        self,
        name: str,
        *,
        enabled: bool | None = None,
        running: bool | None = None,
        status: str | None = None,
        owner: str | None = None,
        last_error: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        with self._lock:
            entry = self._interfaces.setdefault(
                name,
                {
                    "name": name,
                    "enabled": None,
                    "running": None,
                    "status": "unknown",
                    "owner": "",
                    "last_error": "",
                    "details": {},
                },
            )
            if enabled is not None:
                entry["enabled"] = enabled
            if running is not None:
                entry["running"] = running
            if status is not None:
                entry["status"] = status
            if owner is not None:
                entry["owner"] = owner
            if last_error is not None:
                entry["last_error"] = last_error
            if details:
                entry["details"].update(details)

    def set_service_registered(self, service_id: str, name: str) -> None:
        with self._lock:
            entry = self._services.setdefault(
                service_id,
                {
                    "id": service_id,
                    "name": name,
                    "registered": False,
                    "running": False,
                    "status": "new",
                    "last_error": "",
                },
            )
            entry["registered"] = True
            entry["name"] = name
            if entry["status"] == "new":
                entry["status"] = "registered"

    def set_service_running(self, service_id: str, *, name: str | None = None) -> None:
        with self._lock:
            entry = self._services.setdefault(
                service_id,
                {
                    "id": service_id,
                    "name": name or service_id,
                    "registered": True,
                    "running": False,
                    "status": "registered",
                    "last_error": "",
                },
            )
            if name is not None:
                entry["name"] = name
            entry["registered"] = True
            entry["running"] = True
            entry["status"] = "running"
            entry["last_error"] = ""

    def set_service_stopped(self, service_id: str) -> None:
        with self._lock:
            entry = self._services.setdefault(
                service_id,
                {
                    "id": service_id,
                    "name": service_id,
                    "registered": True,
                    "running": False,
                    "status": "stopped",
                    "last_error": "",
                },
            )
            entry["running"] = False
            entry["status"] = "stopped"

    def set_service_error(
        self, service_id: str, message: str, *, name: str | None = None
    ) -> None:
        with self._lock:
            entry = self._services.setdefault(
                service_id,
                {
                    "id": service_id,
                    "name": name or service_id,
                    "registered": True,
                    "running": False,
                    "status": "error",
                    "last_error": "",
                },
            )
            if name is not None:
                entry["name"] = name
            entry["status"] = "error"
            entry["running"] = False
            entry["last_error"] = message
        self.record_error("service", message)

    def set_connector_state(
        self,
        name: str,
        *,
        status: str,
        tools_discovered: int = 0,
        error: str = "",
        last_check: str = "",
        degraded: bool | None = None,
    ) -> None:
        with self._lock:
            entry = self._connectors.setdefault(
                name,
                {
                    "name": name,
                    "status": "unknown",
                    "tools_discovered": 0,
                    "error": "",
                    "last_check": "",
                    "degraded": False,
                },
            )
            entry["status"] = status
            entry["tools_discovered"] = tools_discovered
            entry["error"] = error
            entry["last_check"] = last_check
            if degraded is not None:
                entry["degraded"] = degraded

    def sync_plugins(self, plugin_infos: list[Any]) -> None:
        with self._lock:
            current_ids = set()
            for info in plugin_infos:
                manifest = info.manifest
                current_ids.add(manifest.id)
                self._plugins[manifest.id] = {
                    "plugin_id": manifest.id,
                    "name": manifest.name,
                    "version": manifest.version,
                    "kind": manifest.kind,
                    "installed": True,
                    "loaded": info.status == "loaded",
                    "status": info.status,
                    "error": info.error or "",
                }
            stale = [pid for pid in self._plugins if pid not in current_ids]
            for pid in stale:
                del self._plugins[pid]

    def set_plugin_loaded(self, plugin_id: str) -> None:
        with self._lock:
            entry = self._plugins.setdefault(
                plugin_id,
                {
                    "plugin_id": plugin_id,
                    "name": plugin_id,
                    "version": "",
                    "kind": "",
                    "installed": True,
                    "loaded": False,
                    "status": "installed",
                    "error": "",
                },
            )
            entry["loaded"] = True
            entry["status"] = "loaded"
            entry["error"] = ""

    def set_plugin_error(self, plugin_id: str, error: str) -> None:
        with self._lock:
            entry = self._plugins.setdefault(
                plugin_id,
                {
                    "plugin_id": plugin_id,
                    "name": plugin_id,
                    "version": "",
                    "kind": "",
                    "installed": True,
                    "loaded": False,
                    "status": "installed",
                    "error": "",
                },
            )
            entry["loaded"] = False
            entry["status"] = "error"
            entry["error"] = error
        self.record_error("plugin", error)

    def start_activity(
        self,
        activity_id: str,
        *,
        label: str,
        source: str = "",
        session_id: str = "",
        background: bool = True,
    ) -> None:
        with self._lock:
            now = utcnow().isoformat()
            self._activities[activity_id] = {
                "activity_id": activity_id,
                "label": label,
                "source": source,
                "session_id": session_id,
                "background": background,
                "started_at": now,
                "updated_at": now,
                "status": "running",
            }

    def update_activity(self, activity_id: str, *, label: str) -> None:
        with self._lock:
            entry = self._activities.get(activity_id)
            if entry is None:
                return
            entry["label"] = label
            entry["updated_at"] = utcnow().isoformat()

    def finish_activity(
        self,
        activity_id: str,
        *,
        success: bool = True,
        label: str = "",
    ) -> None:
        with self._lock:
            entry = self._activities.pop(activity_id, None)
        if entry is not None and not success:
            self.record_error(
                entry.get("source", "activity"),
                label or entry.get("label", "activity failed"),
            )

    def set_active_recording(self, recording: dict[str, Any] | None) -> None:
        with self._lock:
            self._meetings["active_recording"] = deepcopy(recording)
            running = recording is not None
            self.set_interface_state(
                "meeting_capture",
                enabled=True,
                running=running,
                status="paused"
                if recording and recording.get("paused")
                else ("recording" if running else "idle"),
                owner="tui_local",
                details=deepcopy(recording) if recording else {},
            )

    def set_transcription_summary(
        self,
        *,
        queued: int | None = None,
        running: int | None = None,
        error: str | None = None,
    ) -> None:
        with self._lock:
            if queued is not None:
                self._meetings["queued_transcriptions"] = queued
            if running is not None:
                self._meetings["running_transcriptions"] = running
            if error:
                errors = self._meetings.setdefault("recent_transcription_errors", [])
                errors.append(
                    {
                        "message": error,
                        "timestamp": utcnow().isoformat(),
                    }
                )
                self._meetings["recent_transcription_errors"] = errors[-10:]

    def bump_transcription_counts(
        self,
        *,
        queued_delta: int = 0,
        running_delta: int = 0,
        error: str | None = None,
    ) -> None:
        with self._lock:
            if queued_delta:
                self._meetings["queued_transcriptions"] = max(
                    0,
                    int(self._meetings.get("queued_transcriptions", 0)) + queued_delta,
                )
            if running_delta:
                self._meetings["running_transcriptions"] = max(
                    0,
                    int(self._meetings.get("running_transcriptions", 0))
                    + running_delta,
                )
        if error:
            self.set_transcription_summary(error=error)

    def set_queue_state(
        self,
        name: str,
        *,
        pending_count: int | None = None,
        is_paused: bool | None = None,
        running_count: int | None = None,
        retrying_count: int | None = None,
        status: str | None = None,
    ) -> None:
        with self._lock:
            items = self._queues.setdefault("items", [])
            existing = {item["name"]: item for item in items}
            entry = existing.setdefault(
                name,
                {
                    "name": name,
                    "pending_count": 0,
                    "is_paused": False,
                    "running_count": 0,
                    "retrying_count": 0,
                    "status": "idle",
                },
            )
            if pending_count is not None:
                entry["pending_count"] = pending_count
            if is_paused is not None:
                entry["is_paused"] = is_paused
            if running_count is not None:
                entry["running_count"] = running_count
            if retrying_count is not None:
                entry["retrying_count"] = retrying_count
            if status is not None:
                entry["status"] = status
            self._queues["items"] = sorted(
                existing.values(), key=lambda item: item["name"]
            )
            if name == "work_queue":
                self._queues["work_queue_pending"] = entry["pending_count"]
                self._queues["work_queue_paused"] = entry["is_paused"]
                self._queues["work_queue_running"] = entry["running_count"]
                self._queues["retrying_count"] = entry["retrying_count"]
            elif name == "scheduler":
                self._queues["scheduler_running"] = entry["status"] == "running"

    def sync_subagents(self, agents: list[Any]) -> None:
        with self._lock:
            rendered = []
            running_count = 0
            for agent in agents:
                if getattr(agent, "status", "") == "running":
                    running_count += 1
                rendered.append(
                    {
                        "agent_id": agent.agent_id,
                        "label": agent.label,
                        "status": agent.status,
                        "started_at": agent.started_at.isoformat(),
                        "elapsed_ms": agent.elapsed_ms,
                        "error": agent.error or "",
                    }
                )
            self._subagents = {
                "running_count": running_count,
                "agents": rendered,
            }

    def record_error(
        self, subsystem: str, message: str, *, recoverable: bool = True
    ) -> None:
        with self._lock:
            self._errors.append(
                {
                    "subsystem": subsystem,
                    "message": message,
                    "timestamp": utcnow().isoformat(),
                    "recoverable": recoverable,
                }
            )
            self._errors = self._errors[-20:]

    def set_resource_snapshot(self, snapshot: dict[str, Any]) -> None:
        """Update the latest resource telemetry snapshot."""
        with self._lock:
            self._resources = {
                "rss_mb": snapshot["rss_mb"],
                "vms_mb": snapshot["vms_mb"],
                "uss_mb": snapshot["uss_mb"],
                "cpu_percent": snapshot["cpu_percent"],
                "thread_count": snapshot["thread_count"],
                "fd_count": snapshot["fd_count"],
                "fd_limit": snapshot["fd_limit"],
                "children_count": snapshot["children_count"],
                "children_rss_mb": snapshot["children_rss_mb"],
                "warnings": [msg for _, msg in snapshot.get("warnings", [])],
                "extensions": snapshot.get("extensions", {}),
                "collected_at": snapshot.get("timestamp", ""),
            }

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            plugins = sorted(self._plugins.values(), key=lambda item: item["plugin_id"])
            return {
                "process": deepcopy(self._process),
                "goals": deepcopy(self._goals),
                "session": deepcopy(self._session),
                "interfaces": sorted(
                    deepcopy(list(self._interfaces.values())),
                    key=lambda item: item["name"],
                ),
                "services": sorted(
                    deepcopy(list(self._services.values())), key=lambda item: item["id"]
                ),
                "connectors": sorted(
                    deepcopy(list(self._connectors.values())),
                    key=lambda item: item["name"],
                ),
                "plugins": {
                    "installed_count": len(plugins),
                    "loaded_count": sum(1 for item in plugins if item["loaded"]),
                    "error_count": sum(
                        1 for item in plugins if item["status"] == "error"
                    ),
                    "items": deepcopy(plugins),
                },
                "activities": sorted(
                    deepcopy(list(self._activities.values())),
                    key=lambda item: item["activity_id"],
                ),
                "meetings": deepcopy(self._meetings),
                "queues": deepcopy(self._queues),
                "subagents": deepcopy(self._subagents),
                "resources": deepcopy(self._resources),
                "errors": deepcopy(self._errors),
            }
