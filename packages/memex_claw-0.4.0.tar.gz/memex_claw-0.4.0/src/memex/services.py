"""Service lifecycle management for background services.

Services are long-running background components (e.g., webhook listeners,
sync workers) with start/stop lifecycle, integrated with event bus and store.

Usage:
    mgr = ServiceManager(store=store, event_bus=bus, scheduler=scheduler)
    mgr.register(MyService(), config={"key": "value"})
    mgr.start_all()
    ...
    mgr.stop_all()
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from memex.event_bus import EventBus
from memex.runtime_state import RuntimeStateRegistry
from memex.store import MemexStore

logger = logging.getLogger(__name__)


@dataclass
class ServiceContext:
    """Runtime context provided to each service on start/stop."""

    config: dict[str, Any]
    store: MemexStore
    event_bus: EventBus
    scheduler: Any  # SchedulerEngine, typed as Any to avoid circular import
    logger: logging.Logger
    data_dir: Path


class Service(ABC):
    """Base class for background services."""

    @property
    @abstractmethod
    def id(self) -> str:
        """Unique identifier for this service."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable name."""

    @abstractmethod
    def start(self, ctx: ServiceContext) -> None:
        """Start the service. Called once by ServiceManager."""

    @abstractmethod
    def stop(self, ctx: ServiceContext) -> None:
        """Stop the service. Called once by ServiceManager."""


class ServiceManager:
    """Manages service registration, start, and stop lifecycle.

    Services are started in registration order and stopped in reverse order.
    Errors in one service never prevent others from starting/stopping.
    """

    def __init__(
        self,
        store: MemexStore,
        event_bus: EventBus,
        scheduler: Any = None,
        data_dir: Path | None = None,
        runtime_registry: RuntimeStateRegistry | None = None,
    ) -> None:
        self._store = store
        self._event_bus = event_bus
        self._scheduler = scheduler
        self._data_dir = data_dir or Path.home() / ".config" / "memex" / "services"
        self._runtime_registry = runtime_registry
        self._registered: list[tuple[Service, dict[str, Any]]] = []
        self._running: list[Service] = []

    def register(self, service: Service, config: dict[str, Any] | None = None) -> None:
        """Register a service without starting it."""
        self._registered.append((service, config or {}))
        if self._runtime_registry is not None:
            self._runtime_registry.set_service_registered(service.id, service.name)

    def start_all(self) -> None:
        """Start all registered services. Errors logged, not raised."""
        for service, config in self._registered:
            ctx = self._make_context(service, config)
            try:
                service.start(ctx)
                self._running.append(service)
                if self._runtime_registry is not None:
                    self._runtime_registry.set_service_running(
                        service.id, name=service.name
                    )
                logger.info("Service started: %s (%s)", service.name, service.id)
            except Exception:
                if self._runtime_registry is not None:
                    self._runtime_registry.set_service_error(
                        service.id,
                        "start failed",
                        name=service.name,
                    )
                logger.error(
                    "Failed to start service %s (%s)",
                    service.name,
                    service.id,
                    exc_info=True,
                )

    def stop_all(self) -> None:
        """Stop all running services in reverse order. Errors logged, not raised."""
        for service in reversed(self._running):
            config = self._config_for(service)
            ctx = self._make_context(service, config)
            try:
                service.stop(ctx)
                if self._runtime_registry is not None:
                    self._runtime_registry.set_service_stopped(service.id)
                logger.info("Service stopped: %s (%s)", service.name, service.id)
            except Exception:
                if self._runtime_registry is not None:
                    self._runtime_registry.set_service_error(
                        service.id,
                        "stop failed",
                        name=service.name,
                    )
                logger.error(
                    "Failed to stop service %s (%s)",
                    service.name,
                    service.id,
                    exc_info=True,
                )
        self._running.clear()

    @property
    def running(self) -> list[Service]:
        """List of currently running services."""
        return list(self._running)

    @property
    def registered(self) -> list[Service]:
        """List of all registered services."""
        return [svc for svc, _ in self._registered]

    def _make_context(self, service: Service, config: dict[str, Any]) -> ServiceContext:
        svc_data_dir = self._data_dir / service.id
        svc_data_dir.mkdir(parents=True, exist_ok=True)
        return ServiceContext(
            config=config,
            store=self._store,
            event_bus=self._event_bus,
            scheduler=self._scheduler,
            logger=logging.getLogger(f"memex.services.{service.id}"),
            data_dir=svc_data_dir,
        )

    def _config_for(self, service: Service) -> dict[str, Any]:
        for svc, config in self._registered:
            if svc is service:
                return config
        return {}
