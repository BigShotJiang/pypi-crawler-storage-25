"""Temporal query support — parse natural language time expressions and search across data types."""

from __future__ import annotations

import calendar
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class TemporalRange:
    """A time range parsed from a natural language expression."""

    start: datetime
    end: datetime
    expression: str = ""


@dataclass(frozen=True)
class TemporalResult:
    """A single result from a temporal search."""

    source_type: str  # "conversation", "goal", "item"
    title: str
    snippet: str
    timestamp: datetime
    source_id: str


# -- Parsing patterns ----------------------------------------------------------

# Sorted longest-first to prevent substring matching ("yesterday" in "day before yesterday")
_RELATIVE_DAYS = [
    ("day before yesterday", 2),
    ("yesterday", 1),
    ("today", 0),
]

_WEEKDAY_NAMES = {
    "monday": 0,
    "tuesday": 1,
    "wednesday": 2,
    "thursday": 3,
    "friday": 4,
    "saturday": 5,
    "sunday": 6,
    "mon": 0,
    "tue": 1,
    "tues": 1,
    "wed": 2,
    "thu": 3,
    "thurs": 3,
    "fri": 4,
    "sat": 5,
    "sun": 6,
}

_MONTH_NAMES = {
    "january": 1,
    "february": 2,
    "march": 3,
    "april": 4,
    "may": 5,
    "june": 6,
    "july": 7,
    "august": 8,
    "september": 9,
    "october": 10,
    "november": 11,
    "december": 12,
    "jan": 1,
    "feb": 2,
    "mar": 3,
    "apr": 4,
    "jun": 6,
    "jul": 7,
    "aug": 8,
    "sep": 9,
    "sept": 9,
    "oct": 10,
    "nov": 11,
    "dec": 12,
}

_ORDINAL_SUFFIX = re.compile(r"(\d+)(?:st|nd|rd|th)")


def parse_temporal(text: str, now: datetime | None = None) -> TemporalRange | None:
    """Parse a natural language temporal expression into a TemporalRange.

    Returns None if no temporal expression is detected.

    Supports:
    - 'today', 'yesterday'
    - 'N days/weeks/months ago'
    - 'last Monday', 'last Tuesday', etc.
    - 'last week', 'this week', 'last month', 'this month'
    - 'March 5th', 'January 2024', 'March 5'
    - 'between X and Y' (where X and Y are parseable)
    """
    now = now or utcnow()
    text_lower = text.lower().strip()

    # "between X and Y"
    between_match = re.search(r"between\s+(.+?)\s+and\s+(.+?)(?:\s*$)", text_lower)
    if between_match:
        start_range = parse_temporal(between_match.group(1), now)
        end_range = parse_temporal(between_match.group(2), now)
        if start_range and end_range:
            return TemporalRange(
                start=start_range.start,
                end=end_range.end,
                expression=text_lower,
            )

    # "today", "yesterday", "day before yesterday" (checked longest-first)
    for name, days_ago in _RELATIVE_DAYS:
        if name in text_lower:
            day = now - timedelta(days=days_ago)
            start = day.replace(hour=0, minute=0, second=0, microsecond=0)
            end = start + timedelta(days=1) - timedelta(microseconds=1)
            return TemporalRange(start=start, end=end, expression=name)

    # "N days/weeks/months ago"
    ago_match = re.search(r"(\d+)\s+(day|week|month)s?\s+ago", text_lower)
    if ago_match:
        n = int(ago_match.group(1))
        unit = ago_match.group(2)
        if unit == "day":
            day = now - timedelta(days=n)
            start = day.replace(hour=0, minute=0, second=0, microsecond=0)
            end = start + timedelta(days=1) - timedelta(microseconds=1)
        elif unit == "week":
            start = (now - timedelta(weeks=n)).replace(
                hour=0, minute=0, second=0, microsecond=0
            )
            # Start of that week (Monday)
            start = start - timedelta(days=start.weekday())
            end = start + timedelta(days=7) - timedelta(microseconds=1)
        else:  # month
            month = now.month - n
            year = now.year
            while month <= 0:
                month += 12
                year -= 1
            start = datetime(year, month, 1)
            last_day = calendar.monthrange(year, month)[1]
            end = datetime(year, month, last_day, 23, 59, 59, 999999)
        return TemporalRange(start=start, end=end, expression=ago_match.group(0))

    # "last week", "this week"
    if "last week" in text_lower:
        start = now - timedelta(days=now.weekday() + 7)
        start = start.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=7) - timedelta(microseconds=1)
        return TemporalRange(start=start, end=end, expression="last week")

    if "this week" in text_lower:
        start = now - timedelta(days=now.weekday())
        start = start.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=7) - timedelta(microseconds=1)
        return TemporalRange(start=start, end=end, expression="this week")

    # "last month", "this month"
    if "last month" in text_lower:
        first = now.replace(day=1) - timedelta(days=1)
        start = first.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        last_day = calendar.monthrange(start.year, start.month)[1]
        end = datetime(start.year, start.month, last_day, 23, 59, 59, 999999)
        return TemporalRange(start=start, end=end, expression="last month")

    if "this month" in text_lower:
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        last_day = calendar.monthrange(start.year, start.month)[1]
        end = datetime(start.year, start.month, last_day, 23, 59, 59, 999999)
        return TemporalRange(start=start, end=end, expression="this month")

    # "last Tuesday", "last Monday", etc.
    last_day_match = re.search(
        r"last\s+(" + "|".join(_WEEKDAY_NAMES.keys()) + r")", text_lower
    )
    if last_day_match:
        target_weekday = _WEEKDAY_NAMES[last_day_match.group(1)]
        days_back = (now.weekday() - target_weekday) % 7
        if days_back == 0:
            days_back = 7
        day = now - timedelta(days=days_back)
        start = day.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1) - timedelta(microseconds=1)
        return TemporalRange(start=start, end=end, expression=last_day_match.group(0))

    # "January 2024" (month + year, no day) — must be checked BEFORE month+day
    # to avoid "January 20" matching from "January 2024"
    month_year_match = re.search(
        r"(" + "|".join(_MONTH_NAMES.keys()) + r")\s+(\d{4})\b",
        text_lower,
    )
    if month_year_match:
        month = _MONTH_NAMES[month_year_match.group(1)]
        year = int(month_year_match.group(2))
        start = datetime(year, month, 1, 0, 0, 0)
        last_day = calendar.monthrange(year, month)[1]
        end = datetime(year, month, last_day, 23, 59, 59, 999999)
        return TemporalRange(start=start, end=end, expression=month_year_match.group(0))

    # "March 5th", "March 5", "March 5, 2024"
    month_day_match = re.search(
        r"("
        + "|".join(_MONTH_NAMES.keys())
        + r")\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s*(\d{4}))?",
        text_lower,
    )
    if month_day_match:
        month = _MONTH_NAMES[month_day_match.group(1)]
        day = int(month_day_match.group(2))
        year = int(month_day_match.group(3)) if month_day_match.group(3) else now.year
        try:
            start = datetime(year, month, day, 0, 0, 0)
            end = start + timedelta(days=1) - timedelta(microseconds=1)
            return TemporalRange(
                start=start, end=end, expression=month_day_match.group(0)
            )
        except ValueError:
            pass

    return None


def extract_temporal_from_query(
    query: str,
    now: datetime | None = None,
) -> tuple[str, TemporalRange | None]:
    """Extract temporal expression from a query string.

    Returns (cleaned_query, temporal_range).
    The cleaned_query has the temporal expression removed.
    """
    now = now or utcnow()
    temporal_range = parse_temporal(query, now)

    if temporal_range is None:
        return query, None

    # Remove the matched expression from the query
    cleaned = query
    if temporal_range.expression:
        # Case-insensitive removal
        pattern = re.compile(re.escape(temporal_range.expression), re.IGNORECASE)
        cleaned = pattern.sub("", cleaned).strip()
        # Clean up leftover connectors
        cleaned = re.sub(r"\b(from|since|during|in|on|for)\s*$", "", cleaned).strip()
        cleaned = re.sub(r"^\s*(from|since|during|in|on|for)\b", "", cleaned).strip()

    return cleaned or query, temporal_range


# -- Search across data types --------------------------------------------------


def _temporal_search_fathomdb(
    query: str,
    start: datetime,
    end: datetime,
    memex_store: Any,
    content_store: Any | None,
    limit: int,
) -> list[TemporalResult]:
    """FathomDB path: query conversations, goals, and items via store APIs."""
    results: list[TemporalResult] = []
    query_lower = query.lower() if query else ""

    # 1. Conversations
    try:
        entries = memex_store.query_conversation_log(since=start, limit=limit * 2)
        for entry in entries:
            ts_str = entry.get("timestamp", "")
            if not ts_str:
                continue
            ts = datetime.fromisoformat(ts_str) if isinstance(ts_str, str) else ts_str
            if ts < start or ts > end:
                continue
            content = str(entry.get("content") or "")
            if query_lower and query_lower not in content.lower():
                continue
            role = str(entry.get("role") or "")
            results.append(
                TemporalResult(
                    source_type="conversation",
                    title=f"[{role}] {content[:80]}",
                    snippet=content[:300],
                    timestamp=ts,
                    source_id=f"conv:{entry.get('id', entry.get('logical_id', ''))}",
                )
            )
    except Exception:
        logger.warning(
            "Temporal search (fathomdb) failed on conversations", exc_info=True
        )

    # 2. Goals
    try:
        goals = memex_store.list_goals()
        for goal in goals:
            created = goal.created_at
            updated = goal.updated_at
            in_range = (created and start <= created <= end) or (
                updated and start <= updated <= end
            )
            if not in_range:
                continue
            title = goal.title or ""
            desc = goal.description or ""
            if (
                query_lower
                and query_lower not in title.lower()
                and query_lower not in desc.lower()
            ):
                continue
            ts = updated or created or start
            status = (
                goal.status.value if hasattr(goal.status, "value") else str(goal.status)
            )
            results.append(
                TemporalResult(
                    source_type="goal",
                    title=f"{title} [{status}]",
                    snippet=desc[:300],
                    timestamp=ts,
                    source_id=goal.goal_id,
                )
            )
    except Exception:
        logger.warning("Temporal search (fathomdb) failed on goals", exc_info=True)

    # 3. Items
    if content_store is not None:
        try:
            items = content_store.list_items(limit=limit * 3)
            for item in items:
                captured = item.captured_at
                if not captured or captured < start or captured > end:
                    continue
                title = item.title or ""
                body = item.body or ""
                if (
                    query_lower
                    and query_lower not in title.lower()
                    and query_lower not in body.lower()
                ):
                    continue
                itype = (
                    item.type.value if hasattr(item.type, "value") else str(item.type)
                )
                results.append(
                    TemporalResult(
                        source_type="item",
                        title=f"[{itype}] {title}",
                        snippet=body[:300],
                        timestamp=captured,
                        source_id=item.item_id,
                    )
                )
        except Exception:
            logger.warning("Temporal search (fathomdb) failed on items", exc_info=True)

    results.sort(key=lambda r: r.timestamp, reverse=True)
    return results[:limit]


def temporal_search(
    query: str,
    temporal_range: TemporalRange,
    *,
    conn: Any,
    content_store: Any | None = None,
    limit: int = 20,
) -> list[TemporalResult]:
    """Search across conversation_log, goals, and items within a time range.

    Returns results sorted by timestamp (newest first).
    """
    results: list[TemporalResult] = []
    start = temporal_range.start
    end = temporal_range.end

    if conn is None:
        # FathomDB path: use store APIs instead of raw SQL
        memex_store = (
            getattr(content_store, "_memex_store", None) if content_store else None
        )
        if memex_store is not None:
            results = _temporal_search_fathomdb(
                query, start, end, memex_store, content_store, limit
            )
        return results

    start_iso = start.isoformat()
    end_iso = end.isoformat()

    # 1. Conversation log
    try:
        rows = conn.execute(
            """SELECT id, session_id, role, content, timestamp
               FROM conversation_log
               WHERE timestamp BETWEEN ? AND ?
               ORDER BY timestamp DESC LIMIT ?""",
            (start_iso, end_iso, limit),
        ).fetchall()

        for row in rows:
            content = row["content"] if hasattr(row, "keys") else row[3]
            role = row["role"] if hasattr(row, "keys") else row[2]
            ts_str = row["timestamp"] if hasattr(row, "keys") else row[4]
            rid = row["id"] if hasattr(row, "keys") else row[0]

            # Filter by query if present
            if query and query.lower() not in content.lower():
                continue

            results.append(
                TemporalResult(
                    source_type="conversation",
                    title=f"[{role}] {content[:80]}",
                    snippet=content[:300],
                    timestamp=datetime.fromisoformat(ts_str),
                    source_id=f"conv:{rid}",
                )
            )
    except Exception:
        logger.warning("Temporal search failed on conversation_log", exc_info=True)

    # 2. Goals
    try:
        rows = conn.execute(
            """SELECT goal_id, title, description, status, created_at, updated_at
               FROM goals
               WHERE created_at BETWEEN ? AND ? OR updated_at BETWEEN ? AND ?
               ORDER BY updated_at DESC LIMIT ?""",
            (start_iso, end_iso, start_iso, end_iso, limit),
        ).fetchall()

        for row in rows:
            gid = row["goal_id"] if hasattr(row, "keys") else row[0]
            title = row["title"] if hasattr(row, "keys") else row[1]
            desc = row["description"] if hasattr(row, "keys") else row[2]
            status = row["status"] if hasattr(row, "keys") else row[3]
            updated = row["updated_at"] if hasattr(row, "keys") else row[5]

            if (
                query
                and query.lower() not in title.lower()
                and query.lower() not in (desc or "").lower()
            ):
                continue

            results.append(
                TemporalResult(
                    source_type="goal",
                    title=f"{title} [{status}]",
                    snippet=desc[:300] if desc else "",
                    timestamp=datetime.fromisoformat(updated),
                    source_id=gid,
                )
            )
    except Exception:
        logger.warning("Temporal search failed on goals", exc_info=True)

    # 3. Items (knowledge store)
    try:
        rows = conn.execute(
            """SELECT item_id, title, body, type, captured_at
               FROM items
               WHERE captured_at BETWEEN ? AND ?
               ORDER BY captured_at DESC LIMIT ?""",
            (start_iso, end_iso, limit),
        ).fetchall()

        for row in rows:
            iid = row["item_id"] if hasattr(row, "keys") else row[0]
            title = row["title"] if hasattr(row, "keys") else row[1]
            body = row["body"] if hasattr(row, "keys") else row[2]
            itype = row["type"] if hasattr(row, "keys") else row[3]
            captured = row["captured_at"] if hasattr(row, "keys") else row[4]

            if (
                query
                and query.lower() not in title.lower()
                and query.lower() not in (body or "").lower()
            ):
                continue

            results.append(
                TemporalResult(
                    source_type="item",
                    title=f"[{itype}] {title}",
                    snippet=body[:300] if body else "",
                    timestamp=datetime.fromisoformat(captured),
                    source_id=iid,
                )
            )
    except Exception:
        logger.warning("Temporal search failed on items", exc_info=True)

    # Sort by timestamp descending, limit
    results.sort(key=lambda r: r.timestamp, reverse=True)
    return results[:limit]


def format_temporal_results(
    results: list[TemporalResult], temporal_range: TemporalRange
) -> str:
    """Format temporal search results for inclusion in the system prompt."""
    if not results:
        return ""

    parts = [f"## Retrieved Knowledge (time range: {temporal_range.expression})"]
    for i, r in enumerate(results, 1):
        ts_display = r.timestamp.strftime("%Y-%m-%d %H:%M")
        parts.append(f"### [{i}] {r.title}")
        parts.append(f"*{r.source_type} — {ts_display}*")
        if r.snippet:
            parts.append(r.snippet[:500])

    return "\n\n".join(parts)
