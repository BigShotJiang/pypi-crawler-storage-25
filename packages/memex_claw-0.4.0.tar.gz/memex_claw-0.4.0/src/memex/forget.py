"""Forget tool — search, soft-delete, restore, and purge items."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Any

from memex.memory.world_model_reads import resolve_world_model_reads
from memex.utcnow import utcnow

if TYPE_CHECKING:
    from memex.memory.protocols import ContentStoreProtocol
    from memex.store import MemexStore

logger = logging.getLogger(__name__)


@dataclass
class ForgetCandidate:
    """A candidate item for deletion."""

    id: str
    type: str  # "item", "goal", "scheduled_task"
    title: str
    snippet: str
    created_at: datetime | None = None


def search_candidates(
    query: str,
    content_store: ContentStoreProtocol,
    memex_store: MemexStore | None = None,
    scheduler_store: Any = None,
) -> list[ForgetCandidate]:
    """Search for items matching the query across all stores."""
    candidates: list[ForgetCandidate] = []
    q_lower = query.lower()

    # FTS search on content store
    if content_store is not None:
        try:
            world_model_reads = resolve_world_model_reads(
                content_store=content_store,
                world_model_store=memex_store,
            )
            results = content_store.fts_search(query, limit=10)
            knowledge_map = (
                world_model_reads.load_knowledge_map(
                    [item.item_id for item, _score in results]
                )
                if world_model_reads is not None and results
                else {}
            )
            for item, score in results:
                knowledge = knowledge_map.get(item.item_id)
                candidates.append(
                    ForgetCandidate(
                        id=(
                            f"world_model_knowledge:{knowledge.knowledge_id}"
                            if knowledge is not None
                            else f"content_item:{item.item_id}"
                        ),
                        type="item",
                        title=item.title,
                        snippet=(item.body or "")[:150],
                        created_at=item.captured_at,
                    )
                )
        except Exception:
            logger.debug("FTS search failed during forget", exc_info=True)

    # Search goals
    if memex_store is not None:
        try:
            from memex.models import GoalStatus

            goals = memex_store.list_goals(GoalStatus.ACTIVE)
            for g in goals:
                if q_lower in g.title.lower() or q_lower in g.description.lower():
                    candidates.append(
                        ForgetCandidate(
                            id=g.goal_id,
                            type="goal",
                            title=g.title,
                            snippet=g.description[:150],
                            created_at=g.created_at,
                        )
                    )
        except Exception:
            logger.debug("Goal search failed during forget", exc_info=True)

    # Search scheduled tasks
    if scheduler_store is not None:
        try:
            tasks = scheduler_store.list_tasks(enabled_only=True)
            for t in tasks:
                if t.builtin:
                    continue  # Don't offer to delete builtins
                if q_lower in t.name.lower() or q_lower in t.description.lower():
                    candidates.append(
                        ForgetCandidate(
                            id=t.task_id,
                            type="scheduled_task",
                            title=t.name,
                            snippet=t.description[:150],
                            created_at=t.created_at,
                        )
                    )
        except Exception:
            logger.debug("Task search failed during forget", exc_info=True)

    return candidates


def forget_items(
    item_ids: list[str],
    content_store: ContentStoreProtocol,
    memex_store: MemexStore | None = None,
    scheduler_store: Any = None,
) -> list[str]:
    """Soft-delete selected items. Returns list of confirmation messages."""
    messages: list[str] = []

    for raw_id in item_ids:
        item_id = _resolve_content_item_id(raw_id, content_store, memex_store) or raw_id
        content_only = _selection_is_content_only(raw_id)
        # Try content store first
        if content_store is not None:
            try:
                if content_store.soft_delete_item(item_id):
                    _publish_forgotten(item_id, "")
                    messages.append(
                        f"Soft-deleted item [{_display_for_selection_id(raw_id)}]"
                    )
                    continue
            except Exception:
                logger.debug("soft_delete_item failed for %s", item_id, exc_info=True)

        if content_only:
            messages.append(f"Not found: [{_display_for_selection_id(raw_id)}]")
            continue

        # Try goals
        if memex_store is not None:
            try:
                goal = memex_store.get_goal(item_id)
                if goal is not None:
                    from memex.models import GoalStatus

                    now = utcnow()
                    goal.status = GoalStatus.ABANDONED
                    goal.metadata["forgotten"] = True
                    goal.metadata["forgotten_at"] = now.isoformat()
                    goal.updated_at = now
                    memex_store.update_goal(goal)
                    _publish_forgotten(item_id, goal.title)
                    messages.append(
                        f"Abandoned goal [{_display_for_selection_id(raw_id)}] {goal.title}"
                    )
                    continue
            except Exception:
                logger.debug("Goal forget failed for %s", item_id, exc_info=True)

        # Try scheduled tasks
        if scheduler_store is not None:
            try:
                task = scheduler_store.get_task(item_id)
                if task is not None:
                    scheduler_store.toggle_task(item_id, enabled=False)
                    _publish_forgotten(item_id, task.name)
                    messages.append(
                        f"Disabled task [{_display_for_selection_id(raw_id)}] {task.name}"
                    )
                    continue
            except Exception:
                logger.debug("Task forget failed for %s", item_id, exc_info=True)

        messages.append(f"Not found: [{_display_for_selection_id(raw_id)}]")

    return messages


def restore_items(
    item_ids: list[str],
    content_store: Any,
    memex_store: MemexStore | None = None,
    scheduler_store: Any = None,
) -> list[str]:
    """Restore soft-deleted items. Returns list of confirmation messages."""
    messages: list[str] = []

    for raw_id in item_ids:
        item_id = _resolve_content_item_id(raw_id, content_store, memex_store) or raw_id
        content_only = _selection_is_content_only(raw_id)
        # Try content store
        if content_store is not None:
            try:
                if content_store.restore_item(item_id):
                    _publish_restored(item_id, "")
                    messages.append(
                        f"Restored item [{_display_for_selection_id(raw_id)}]"
                    )
                    continue
            except Exception:
                logger.debug("restore_item failed for %s", item_id, exc_info=True)

        if content_only:
            messages.append(f"Not found: [{_display_for_selection_id(raw_id)}]")
            continue

        # Try goals
        if memex_store is not None:
            try:
                goal = memex_store.get_goal(item_id)
                if goal is not None and goal.metadata.get("forgotten"):
                    from memex.models import GoalStatus

                    goal.status = GoalStatus.ACTIVE
                    goal.metadata.pop("forgotten", None)
                    goal.metadata.pop("forgotten_at", None)
                    goal.updated_at = utcnow()
                    memex_store.update_goal(goal)
                    _publish_restored(item_id, goal.title)
                    messages.append(
                        f"Restored goal [{_display_for_selection_id(raw_id)}] {goal.title}"
                    )
                    continue
            except Exception:
                logger.debug("Goal restore failed for %s", item_id, exc_info=True)

        # Try scheduled tasks
        if scheduler_store is not None:
            try:
                task = scheduler_store.get_task(item_id)
                if task is not None:
                    scheduler_store.toggle_task(item_id, enabled=True)
                    _publish_restored(item_id, task.name)
                    messages.append(
                        f"Re-enabled task [{_display_for_selection_id(raw_id)}] {task.name}"
                    )
                    continue
            except Exception:
                logger.debug("Task restore failed for %s", item_id, exc_info=True)

        messages.append(f"Not found: [{_display_for_selection_id(raw_id)}]")

    return messages


def _publish_forgotten(item_id: str, title: str) -> None:
    from memex.event_bus import safe_publish
    from memex.events import ItemForgotten

    safe_publish(ItemForgotten(item_id=item_id, title=title))


def _publish_restored(item_id: str, title: str) -> None:
    from memex.event_bus import safe_publish
    from memex.events import ItemRestored

    safe_publish(ItemRestored(item_id=item_id, title=title))


def _resolve_content_item_id(
    selection_id: str,
    content_store: Any,
    memex_store: MemexStore | None = None,
) -> str | None:
    if selection_id.startswith("content_item:"):
        return selection_id.split(":", 1)[1]
    if not selection_id.startswith("world_model_knowledge:"):
        return selection_id
    if content_store is None:
        return None
    knowledge_id = selection_id.split(":", 1)[1]
    store_for_reads = memex_store
    if store_for_reads is None:
        store_for_reads = getattr(content_store, "_memex_store", None)
    reads = resolve_world_model_reads(
        content_store=content_store,
        world_model_store=store_for_reads,
    )
    if reads is not None:
        hit = reads.load_knowledge_document_hit(knowledge_id)
        if hit is not None:
            return hit.knowledge.item_id
    # Fallback: extract item_id from known knowledge_id patterns
    for prefix in ("knowledge/", "ki-"):
        if knowledge_id.startswith(prefix):
            return knowledge_id[len(prefix) :]
    return None


def _selection_is_content_only(selection_id: str) -> bool:
    return selection_id.startswith("content_item:") or selection_id.startswith(
        "world_model_knowledge:"
    )


def _display_for_selection_id(selection_id: str) -> str:
    if selection_id.startswith("world_model_knowledge:") or selection_id.startswith(
        "content_item:"
    ):
        return selection_id
    return selection_id[:8]
