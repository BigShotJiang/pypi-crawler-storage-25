"""Cache-aware message construction for LLM calls.

Maintains a stable message prefix that maximizes cache hits across turns
and sub-tasks. Provider-agnostic; cache annotations are applied by a
pluggable CacheAnnotator.
"""

from __future__ import annotations

import copy
import hashlib
from typing import Any

from memex.cache_annotator import CacheAnnotator, annotator_for_model


class MessageBuilder:
    """Cache-aware message construction for LLM calls.

    Maintains a stable message prefix that maximizes cache hits
    across turns and sub-tasks. Provider-agnostic; cache annotations
    are applied by a pluggable CacheAnnotator.
    """

    def __init__(self, model: str) -> None:
        # Stable system prompt sections (rarely change)
        self._system_prefix_parts: list[str] = []
        # Dynamic system prompt sections (change per turn)
        self._system_dynamic_parts: list[str] = []
        # Conversation history (append-only within a session)
        self._history: list[dict[str, Any]] = []
        # Cache breakpoint: index into _history
        self._cache_breakpoint: int = 0
        # Turns since last breakpoint advance
        self._turns_since_write: int = 0
        # Provider annotation
        self._annotator: CacheAnnotator = annotator_for_model(model)
        self._model = model
        # Advance interval: provider-aware
        self._advance_interval: int = self._compute_advance_interval(model)
        # Knowledge dedup
        self._knowledge_hash: str | None = None
        self._knowledge_text: str = ""
        self._knowledge_is_cached: bool = False
        # Track total appended turns (user/assistant pairs)
        self._turn_count: int = 0

    @staticmethod
    def _compute_advance_interval(model: str) -> int:
        """Determine cache breakpoint advance interval based on provider.

        Anthropic: 3 (cache writes cost 1.25x, amortize over reads at 0.1x)
        OpenAI: 1 (no write fee, automatic caching)
        """
        model_lower = model.lower()
        if any(p in model_lower for p in ("claude", "anthropic")):
            return 3
        return 1

    # --- System prompt management ---

    def set_system_prefix(self, *parts: str) -> None:
        """Set stable system prompt sections (identity, governance, etc.).

        Call once at session start or when governance changes.
        """
        self._system_prefix_parts = [p for p in parts if p]

    def set_system_dynamic(self, *parts: str) -> None:
        """Set per-turn dynamic sections (goals, knowledge, summary).

        Call each turn before build().
        """
        self._system_dynamic_parts = [p for p in parts if p]

    def set_knowledge(self, knowledge: str) -> None:
        """Set retrieved knowledge with dedup detection.

        If unchanged from last turn, tracks that it can be placed in the
        cached region. Otherwise, it goes in the dynamic (uncached) section.
        """
        if not knowledge:
            self._knowledge_hash = None
            self._knowledge_text = ""
            self._knowledge_is_cached = False
            return

        new_hash = hashlib.sha256(knowledge.encode()).hexdigest()
        if new_hash == self._knowledge_hash:
            # Same knowledge as last turn — cacheable
            self._knowledge_is_cached = True
        else:
            # New knowledge — uncached
            self._knowledge_is_cached = False
            self._knowledge_hash = new_hash

        self._knowledge_text = knowledge

    # --- History management ---

    def append_turn(self, user_msg: str, assistant_msg: str) -> None:
        """Append a completed user/assistant exchange.

        Advances cache breakpoint per the 3rd turn rule.
        """
        self._history.append({"role": "user", "content": user_msg})
        self._history.append({"role": "assistant", "content": assistant_msg})
        self._turn_count += 1
        self._turns_since_write += 1

        # Advance cache breakpoint per the Nth turn rule
        if self._turns_since_write >= self._advance_interval:
            self._cache_breakpoint = len(self._history)
            self._turns_since_write = 0

    def append_tool_exchange(
        self,
        tool_calls: list[dict[str, Any]],
        tool_results: list[dict[str, Any]],
        response_text: str | None = None,
    ) -> None:
        """Append tool call/result messages (within a turn).

        These stay in the uncached tail until the turn completes.
        Each tool result is annotated with metadata for observation masking.
        """
        # Build a lookup from tool_call_id -> tool_name
        call_name_map: dict[str, str] = {}
        for tc in tool_calls:
            tc_id = tc.get("id", "")
            func = tc.get("function", {})
            call_name_map[tc_id] = func.get("name", "unknown")

        # Assistant message with tool_calls
        if tool_calls:
            self._history.append(
                {
                    "role": "assistant",
                    "content": response_text,
                    "tool_calls": tool_calls,
                }
            )
        # Tool result messages — annotated with metadata
        for result in tool_results:
            tool_call_id = result.get("tool_call_id", "")
            content = result.get("content", "")
            result["_tool_name"] = call_name_map.get(tool_call_id, "unknown")
            result["_turn_index"] = self._turn_count
            result["_char_count"] = len(content) if isinstance(content, str) else 0
            self._history.append(result)

    # --- Observation masking ---

    @staticmethod
    def _make_masked_content(tool_name: str, char_count: int) -> str:
        """Return a compact placeholder for a masked tool result."""
        return f"[{tool_name}: {char_count} chars of output]"

    def compact_history(self, max_entries: int = 80) -> None:
        """Trim old history entries to stay within budget.

        Finds a safe trim point at a turn boundary (after a non-tool-call
        assistant message) near the target and removes entries before it.
        """
        if len(self._history) <= max_entries:
            return

        # How many entries we need to remove
        trim_target = len(self._history) - max_entries

        # Search backward from trim_target for the latest safe trim point
        # (after a plain assistant message, not one with tool_calls)
        trim_at = 0
        for i in range(trim_target, -1, -1):
            if (
                self._history[i].get("role") == "assistant"
                and "tool_calls" not in self._history[i]
            ):
                trim_at = i + 1
                break

        if trim_at == 0:
            # Fallback: search forward from trim_target for the nearest safe point
            for i in range(trim_target + 1, len(self._history)):
                if (
                    self._history[i].get("role") == "assistant"
                    and "tool_calls" not in self._history[i]
                ):
                    trim_at = i + 1
                    break

        if trim_at > 0:
            self._history = self._history[trim_at:]
            self._cache_breakpoint = max(0, self._cache_breakpoint - trim_at)

    # --- Build ---

    def build(self, user_input: str) -> list[dict[str, Any]]:
        """Assemble the complete message array with cache annotations.

        Returns a standard list[dict] suitable for litellm.completion().
        Cache annotations (if any) are embedded in content blocks.
        Tool results from previous turns are replaced with compact
        placeholders to save tokens (observation masking).
        """
        # 0. Compact history if over budget
        self.compact_history()

        # 1. Build system message as content blocks
        blocks: list[dict[str, Any]] = []

        prefix_text = "\n\n".join(self._system_prefix_parts)
        if self._knowledge_text and self._knowledge_is_cached:
            prefix_text = prefix_text + "\n\n" + self._knowledge_text
        if prefix_text:
            blocks.append({"type": "text", "text": prefix_text})

        dynamic_parts = list(self._system_dynamic_parts)
        if self._knowledge_text and not self._knowledge_is_cached:
            dynamic_parts.insert(0, self._knowledge_text)
        dynamic_text = "\n\n".join(dynamic_parts)
        if dynamic_text:
            blocks.append({"type": "text", "text": dynamic_text})

        # Guarantee at least one block (APIs reject empty content)
        if not blocks:
            blocks.append({"type": "text", "text": ""})

        prefix_block_count = len(blocks) - (1 if dynamic_text else 0)
        system_msg: dict[str, Any] = {"role": "system", "content": blocks}

        # 2. Annotate system message
        system_msg = self._annotator.annotate_system(system_msg, prefix_block_count)

        # 3. Build conversation history with cache breakpoint
        history_messages = copy.deepcopy(self._history)
        if history_messages and self._cache_breakpoint > 0:
            bp_idx = min(self._cache_breakpoint - 1, len(history_messages) - 1)
            if bp_idx >= 0:
                history_messages = self._annotator.annotate_history(
                    history_messages, bp_idx
                )

        # 4. Observation masking: replace previous-turn tool results with placeholders
        #    _turn_count tracks completed turns. Tool exchanges appended while
        #    _turn_count == N belong to turn N (in-progress). After append_turn()
        #    bumps _turn_count to N+1, those results become "previous turn".
        for msg in history_messages:
            if msg.get("role") == "tool" and "_turn_index" in msg:
                if msg["_turn_index"] < self._turn_count:
                    msg["content"] = self._make_masked_content(
                        msg["_tool_name"], msg["_char_count"]
                    )

        # 5. Strip metadata keys from all tool result messages
        metadata_keys = ("_tool_name", "_turn_index", "_char_count")
        for msg in history_messages:
            if msg.get("role") == "tool":
                for key in metadata_keys:
                    msg.pop(key, None)

        # 6. Assemble
        messages: list[dict[str, Any]] = [system_msg]
        messages.extend(history_messages)
        messages.append({"role": "user", "content": user_input})

        return messages

    # --- Forking ---

    def fork(self) -> MessageBuilder:
        """Create a fork sharing the cached prefix.

        The fork has the same system prompt and history up to the
        cache breakpoint. Sub-tasks append their instruction and
        get cache hits on the shared prefix.
        """
        forked = MessageBuilder.__new__(MessageBuilder)
        # Share prefix (shallow copy of the list — parts are immutable strings)
        forked._system_prefix_parts = list(self._system_prefix_parts)
        forked._system_dynamic_parts = []  # Sub-task sets its own dynamic
        # Share history up to cache breakpoint
        forked._history = copy.deepcopy(self._history[: self._cache_breakpoint])
        forked._cache_breakpoint = self._cache_breakpoint
        forked._turns_since_write = 0
        forked._advance_interval = self._advance_interval
        forked._annotator = self._annotator
        forked._model = self._model
        forked._knowledge_hash = self._knowledge_hash
        forked._knowledge_text = ""
        forked._knowledge_is_cached = False
        forked._turn_count = 0
        return forked

    # --- State ---

    def cache_stats(self) -> dict[str, Any]:
        """Return cache state for diagnostics."""
        masked_count = sum(
            1
            for msg in self._history
            if msg.get("role") == "tool"
            and msg.get("_turn_index", self._turn_count) < self._turn_count
        )
        return {
            "cache_breakpoint": self._cache_breakpoint,
            "turns_since_write": self._turns_since_write,
            "advance_interval": self._advance_interval,
            "history_length": len(self._history),
            "turn_count": self._turn_count,
            "knowledge_cached": self._knowledge_is_cached,
            "knowledge_hash": self._knowledge_hash,
            "model": self._model,
            "masked_tool_results": masked_count,
        }
