"""Lightweight HTTP gateway for webhooks, OAuth callbacks, and health checks.

Runs in a background thread using stdlib http.server. Single port,
configurable routes with auth modes.

Usage:
    gw = HttpGateway(port=8080, auth_token="secret")
    gw.register_route(HttpRoute("/health", health_handler))
    gw.start()
    ...
    gw.stop()
"""

from __future__ import annotations

import json
import logging
import threading
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass
class HttpRequest:
    """Simplified HTTP request passed to route handlers."""

    method: str
    path: str
    headers: dict[str, str]
    body: bytes
    query: str = ""

    @property
    def json(self) -> Any:
        """Parse body as JSON. Raises ValueError on invalid JSON."""
        return json.loads(self.body) if self.body else None


@dataclass
class HttpResponse:
    """Response from a route handler."""

    status: int = 200
    body: str = ""
    content_type: str = "application/json"
    headers: dict[str, str] = field(default_factory=dict)

    @classmethod
    def json(cls, data: Any, status: int = 200) -> HttpResponse:
        return cls(
            status=status, body=json.dumps(data), content_type="application/json"
        )

    @classmethod
    def text(cls, text: str, status: int = 200) -> HttpResponse:
        return cls(status=status, body=text, content_type="text/plain")

    @classmethod
    def error(cls, message: str, status: int = 400) -> HttpResponse:
        return cls.json({"error": message}, status=status)


RouteHandler = Callable[[HttpRequest], HttpResponse]

# SSE handler signature: receives (request, send_event) where send_event(event_type, data)
# writes one SSE event and flushes. The handler blocks until the client disconnects.
SseHandler = Callable[[HttpRequest, Callable[[str, Any], None]], None]


@dataclass
class HttpRoute:
    """A registered HTTP route."""

    path: str
    handler: RouteHandler | None = None
    methods: set[str] = field(default_factory=lambda: {"GET", "POST"})
    auth: str = "none"  # "none", "gateway", "plugin"
    match: str = "exact"  # "exact" or "prefix"
    sse_handler: SseHandler | None = None  # if set, route is a streaming SSE endpoint


class HttpGateway:
    """Background HTTP server for webhooks and API endpoints."""

    def __init__(
        self,
        port: int = 8321,
        host: str = "127.0.0.1",
        auth_token: str | None = None,
    ) -> None:
        self._port = port
        self._host = host
        self._auth_token = auth_token
        self._routes: list[HttpRoute] = []
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    @property
    def port(self) -> int:
        return self._port

    @property
    def routes(self) -> list[HttpRoute]:
        return list(self._routes)

    def register_route(self, route: HttpRoute) -> None:
        """Register a route. Can be called before or after start()."""
        self._routes.append(route)

    def start(self) -> None:
        """Start the HTTP server in a background thread."""
        if self._server is not None:
            return

        gateway = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                self._handle("GET")

            def do_POST(self):
                self._handle("POST")

            def do_PUT(self):
                self._handle("PUT")

            def do_DELETE(self):
                self._handle("DELETE")

            def _handle(self, method: str):
                # Parse path and query
                path = self.path
                query = ""
                if "?" in path:
                    path, query = path.split("?", 1)

                # Find matching route
                route = gateway._match_route(path, method)
                if route is None:
                    self._respond(HttpResponse.error("Not found", 404))
                    return

                # Auth check
                if not gateway._check_auth(route, self.headers):
                    self._respond(HttpResponse.error("Unauthorized", 401))
                    return

                # Read body
                content_length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(content_length) if content_length > 0 else b""

                req = HttpRequest(
                    method=method,
                    path=path,
                    headers=dict(self.headers),
                    body=body,
                    query=query,
                )

                # SSE streaming route
                if route.sse_handler is not None:
                    self._handle_sse(route.sse_handler, req)
                    return

                try:
                    resp = route.handler(req)  # type: ignore[misc]
                except Exception:
                    logger.error("Route handler error for %s", path, exc_info=True)
                    resp = HttpResponse.error("Internal server error", 500)

                self._respond(resp)

            def _handle_sse(self, sse_handler: SseHandler, req: HttpRequest) -> None:
                """Write SSE headers and invoke the streaming handler."""
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Connection", "keep-alive")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()

                def send_event(
                    event_type: str, data: Any, event_id: int | None = None
                ) -> None:
                    parts = []
                    if event_id is not None:
                        parts.append(f"id: {event_id}")
                    parts.append(f"event: {event_type}")
                    parts.append(f"data: {json.dumps(data)}")
                    parts.append("")
                    parts.append("")
                    self.wfile.write("\n".join(parts).encode("utf-8"))
                    self.wfile.flush()

                try:
                    sse_handler(req, send_event)
                except (BrokenPipeError, ConnectionResetError):
                    pass
                except Exception:
                    logger.debug("SSE handler error", exc_info=True)

            def _respond(self, resp: HttpResponse):
                self.send_response(resp.status)
                self.send_header("Content-Type", resp.content_type)
                for k, v in resp.headers.items():
                    self.send_header(k, v)
                self.end_headers()
                if resp.body:
                    self.wfile.write(resp.body.encode("utf-8"))

            def log_message(self, format, *args):
                # Suppress default stderr logging
                logger.debug("HTTP %s", format % args)

        self._server = ThreadingHTTPServer((self._host, self._port), Handler)
        self._thread = threading.Thread(
            target=self._server.serve_forever,
            daemon=True,
            name="memex-http-gateway",
        )
        self._thread.start()
        logger.info("HTTP gateway started on %s:%d", self._host, self._port)

    def stop(self) -> None:
        """Stop the HTTP server."""
        if self._server is not None:
            self._server.shutdown()
            self._server = None
        if self._thread is not None:
            self._thread.join(timeout=5)
            self._thread = None
        logger.info("HTTP gateway stopped")

    def _match_route(self, path: str, method: str) -> HttpRoute | None:
        """Find the first matching route for a path and method."""
        for route in self._routes:
            if method not in route.methods:
                continue
            if route.match == "exact" and route.path == path:
                return route
            if route.match == "prefix" and path.startswith(route.path):
                return route
        return None

    def _check_auth(self, route: HttpRoute, headers: Any) -> bool:
        """Check authorization for a route."""
        if route.auth == "none":
            return True
        if route.auth == "gateway":
            if self._auth_token is None:
                return True  # No token configured = no auth required
            auth_header = headers.get("Authorization", "")
            return auth_header == f"Bearer {self._auth_token}"
        return False
