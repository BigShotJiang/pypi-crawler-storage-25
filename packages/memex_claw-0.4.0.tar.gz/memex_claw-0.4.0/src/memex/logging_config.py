"""Centralized logging configuration for Memex.

Sets up file logging to log/YYYYMMDD-HHMMSS-memex.log in JSONL format.
Console logging is suppressed (Textual TUI owns the terminal).
"""

from __future__ import annotations

import json
import logging
import os
import traceback
from datetime import datetime, timezone
from pathlib import Path
from memex.utcnow import utcnow


class _JSONLFormatter(logging.Formatter):
    """Formats each log record as a single JSON object (one per line)."""

    def format(self, record: logging.LogRecord) -> str:
        entry: dict[str, object] = {
            "timestamp": datetime.fromtimestamp(
                record.created, tz=timezone.utc
            ).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info and record.exc_info[0] is not None:
            entry["exc_info"] = "".join(traceback.format_exception(*record.exc_info))
        return json.dumps(entry, default=str)


def setup_logging(
    *,
    level: int = logging.DEBUG,
    log_dir: str | None = None,
    console: bool = False,
) -> Path:
    """Configure logging for the Memex process.

    Returns the path to the log file.
    """
    # Suppress LiteLLM console spam before it gets imported
    os.environ.setdefault("LITELLM_LOG", "WARNING")

    if log_dir is None:
        log_dir = os.environ.get(
            "MEMEX_LOG_DIR",
            str(Path.cwd() / "log"),
        )

    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)

    timestamp = utcnow().strftime("%Y%m%d-%H%M%S")
    log_file = log_path / f"{timestamp}-memex.log"

    formatter = _JSONLFormatter()

    # File handler — captures everything at the configured level
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(level)
    file_handler.setFormatter(formatter)

    # Configure root logger
    root = logging.getLogger()
    root.setLevel(level)
    root.addHandler(file_handler)

    # Console handler — only if explicitly requested (CLI chat mode)
    if console:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.WARNING)
        console_handler.setFormatter(formatter)
        root.addHandler(console_handler)

    # Quiet noisy third-party loggers and remove their console handlers
    for name in (
        "httpx",
        "httpcore",
        "litellm",
        "LiteLLM",
        "LiteLLM Proxy",
        "LiteLLM Router",
        "telegram",
        "apscheduler",
        "openai",
        "urllib3",
        "asyncio",
        # fathomdb schema bootstrap emits ~13 INFO lines per engine open;
        # useful for debugging but noisy in normal operation.
        "fathomdb_schema",
    ):
        third_party = logging.getLogger(name)
        third_party.setLevel(logging.WARNING)
        # Remove any pre-installed console handlers (LiteLLM adds its own)
        for handler in third_party.handlers[:]:
            if isinstance(handler, logging.StreamHandler) and not isinstance(
                handler, logging.FileHandler
            ):
                third_party.removeHandler(handler)

    logging.getLogger("memex").info("Logging initialized: %s", log_file)

    return log_file
