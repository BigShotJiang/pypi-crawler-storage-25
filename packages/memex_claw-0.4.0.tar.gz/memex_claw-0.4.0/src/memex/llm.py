"""LiteLLM wrapper for Memex. Handles chat and structured output.

Supports routing through a local LiteLLM proxy (Airlock) via AIRLOCK_PROXY_URL.
When set, all LLM calls try the proxy first; on connection error, they fall back
to direct provider access. Set AIRLOCK_MASTER_KEY for proxy authentication.
"""

from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.request
from typing import Any, TypeVar

import litellm
from pydantic import BaseModel

from memex.models import TurnCancelled

T = TypeVar("T", bound=BaseModel)

logger = logging.getLogger(__name__)

_RESPONSE_MODEL_FALLBACK = "anthropic/claude-sonnet-4-20250514"
_CHEAP_MODEL_FALLBACK = "anthropic/claude-haiku-4-5-20251001"
_VALID_REASONING_EFFORTS = ("low", "medium", "high")

# Known models with shortcuts and capabilities.
# Each entry: (full_name, supports_thinking)
_KNOWN_MODELS: dict[str, tuple[str, bool]] = {
    "opus-4-6": ("anthropic/claude-opus-4-6", True),
    "opus-4": ("anthropic/claude-opus-4-20250514", True),
    "sonnet-4-6": ("anthropic/claude-sonnet-4-6", True),
    "sonnet-4": ("anthropic/claude-sonnet-4-20250514", True),
    "haiku-4-5": ("anthropic/claude-haiku-4-5-20251001", True),
    "gpt-4o": ("openai/gpt-4o", False),
    "gpt-4o-mini": ("openai/gpt-4o-mini", False),
}
# Also index by full name for capability lookups
_MODEL_SUPPORTS_THINKING: dict[str, bool] = {
    full: thinks
    for _short, (full, thinks) in _KNOWN_MODELS.items()
    for full in (full, _short)  # index by both full name and shortcut
}

# Map full provider-prefixed model names to proxy short aliases.
# The airlock proxy registers models under short names; sending full names
# causes router metadata (litellm_params, model_info) to be unpopulated,
# crashing cost-based routing and budget limiter callbacks.
_PROXY_MODEL_MAP: dict[str, str] = {
    "anthropic/claude-sonnet-4-20250514": "openai/claude-sonnet",
    "anthropic/claude-sonnet-4-6": "openai/claude-sonnet",
    "anthropic/claude-haiku-4-5-20251001": "openai/claude-haiku",
    "anthropic/claude-opus-4-20250514": "openai/claude-opus",
    "anthropic/claude-opus-4-6": "openai/claude-opus",
    "openai/gpt-4o": "openai/gpt-4o",
    "openai/gpt-4o-mini": "openai/gpt-4o-mini",
}

# Runtime overrides (set via /model command). Take priority over env vars.
_runtime_response_model: str | None = None
_runtime_cheap_model: str | None = None
_runtime_reasoning_effort: str | None = None
# Temporarily disable proxy after a connection failure; re-probed every
# _PROXY_RETRY_INTERVAL seconds by is_llm_available().
_proxy_disabled: bool = False
_proxy_disabled_since: float = 0.0
_PROXY_RETRY_INTERVAL: float = 60.0  # seconds between re-probe attempts when disabled

# Backward-compatible module-level defaults (evaluated at import time).
# Prefer the _get helpers below for runtime resolution.
DEFAULT_RESPONSE_MODEL = os.environ.get(
    "MEMEX_RESPONSE_MODEL", _RESPONSE_MODEL_FALLBACK
)
DEFAULT_CHEAP_MODEL = os.environ.get("MEMEX_CHEAP_MODEL", _CHEAP_MODEL_FALLBACK)


def _get_response_model() -> str:
    return _runtime_response_model or os.environ.get(
        "MEMEX_RESPONSE_MODEL", _RESPONSE_MODEL_FALLBACK
    )


# Public alias for use by other modules (e.g. tools_builtin)
get_response_model = _get_response_model


def _get_cheap_model() -> str:
    return _runtime_cheap_model or os.environ.get(
        "MEMEX_CHEAP_MODEL", _CHEAP_MODEL_FALLBACK
    )


def _get_reasoning_effort() -> str | None:
    return _runtime_reasoning_effort


def set_response_model(model: str) -> None:
    """Set the response model at runtime (e.g. from /model command)."""
    global _runtime_response_model
    _runtime_response_model = model
    logger.info("Response model set to %s", model)


def set_cheap_model(model: str) -> None:
    """Set the cheap model at runtime."""
    global _runtime_cheap_model
    _runtime_cheap_model = model
    logger.info("Cheap model set to %s", model)


def set_reasoning_effort(level: str | None) -> None:
    """Set reasoning effort at runtime. None disables it."""
    global _runtime_reasoning_effort
    if level is not None and level not in _VALID_REASONING_EFFORTS:
        raise ValueError(
            f"Invalid reasoning effort: {level!r}. Must be one of {_VALID_REASONING_EFFORTS}"
        )
    _runtime_reasoning_effort = level
    logger.info("Reasoning effort set to %s", level)


def get_model_info() -> dict[str, str | None]:
    """Return current model configuration for display."""
    return {
        "response_model": _get_response_model(),
        "cheap_model": _get_cheap_model(),
        "reasoning_effort": _get_reasoning_effort(),
    }


def get_available_models() -> list[tuple[str, str, bool]]:
    """Return list of (shortcut, full_name, supports_thinking) for known models."""
    return [(short, full, thinks) for short, (full, thinks) in _KNOWN_MODELS.items()]


def model_supports_thinking(model: str) -> bool:
    """Check if a model supports reasoning/thinking. Unknown models return True (optimistic)."""
    return _MODEL_SUPPORTS_THINKING.get(model, True)


def resolve_model_shortcut(name: str) -> str | None:
    """Resolve a short model name to its full provider-prefixed string, or None if unknown."""
    entry = _KNOWN_MODELS.get(name)
    return entry[0] if entry else None


def _get_proxy_url() -> str | None:
    """Return the LLM proxy URL if configured, or None for direct access."""
    proxy_url = os.environ.get("AIRLOCK_PROXY_URL")
    if proxy_url:
        return proxy_url
    host = os.environ.get("AIRLOCK_HOST", "").strip()
    port = os.environ.get("AIRLOCK_PORT", "").strip()
    if not host and not port:
        return None
    if not host:
        host = "localhost"
    if not port:
        port = "4000"
    if host == "0.0.0.0":  # nosec B104 — immediately replaced with loopback
        host = "127.0.0.1"
    return f"http://{host}:{port}/v1"


def _get_proxy_key() -> str | None:
    """Return the proxy API key if configured."""
    return os.environ.get("AIRLOCK_MASTER_KEY")


def _get_proxy_extra_headers() -> dict[str, str]:
    """Return extra headers to send when routing via Airlock."""
    airlock_client = os.environ.get("AIRLOCK_CLIENT", "").strip()
    if not airlock_client:
        return {}
    return {
        "X-Airlock-Client": airlock_client,
    }


def _is_proxy_error(exc: Exception) -> bool:
    """Check if an exception is a proxy error worth falling back to direct.

    Catches both connection failures (proxy down) and server errors (proxy
    returned 5xx), since either means the proxy can't fulfill the request.
    """
    msg = str(exc).lower()
    connection_indicators = [
        "connection refused",
        "connect timeout",
        "connectionerror",
        "connection error",
        "name or service not known",
        "no route to host",
        "network unreachable",
        "connection reset",
        "connection aborted",
        "no connected db",
    ]
    if any(indicator in msg for indicator in connection_indicators):
        return True
    # Proxy returned a 5xx — treat as proxy failure, not upstream failure
    if (
        "internal server error" in msg
        or "bad gateway" in msg
        or "service unavailable" in msg
    ):
        return True
    return False


def is_llm_available() -> bool:
    """Cheap probe: can we reach the LLM proxy? Returns True when no proxy is configured.

    When using a direct provider (no proxy URL), we can't probe cheaply so we
    assume available. When using Airlock proxy, hits /health with a 2s timeout,
    sending the master key if configured (Airlock requires auth on /health).

    When _proxy_disabled is True after a prior failure, re-probes every
    _PROXY_RETRY_INTERVAL seconds and clears the flag if the proxy recovers.
    """
    global _proxy_disabled, _proxy_disabled_since
    if _proxy_disabled:
        if time.monotonic() - _proxy_disabled_since < _PROXY_RETRY_INTERVAL:
            return False
        # Retry window elapsed — fall through to probe
    proxy_url = _get_proxy_url()
    if not proxy_url:
        return True  # direct providers: assume available
    health_url = proxy_url.rstrip("/").removesuffix("/v1") + "/health"
    proxy_key = _get_proxy_key()
    req = urllib.request.Request(health_url)
    if proxy_key:
        req.add_header("Authorization", f"Bearer {proxy_key}")
    try:
        urllib.request.urlopen(req, timeout=2)  # nosec B310 — URL built from config
        if _proxy_disabled:
            logger.info("LLM proxy recovered, re-enabling")
            _proxy_disabled = False
        return True
    except urllib.error.HTTPError as exc:
        # 401 means proxy is running but rejected the key — treat as available.
        # Any other HTTP error (5xx) means proxy is unhealthy.
        if exc.code == 401:
            if _proxy_disabled:
                logger.info("LLM proxy recovered, re-enabling")
                _proxy_disabled = False
            return True
        return False
    except Exception:
        return False


def reset_proxy_disabled() -> None:
    """Force-clear proxy-disabled flag. Next is_llm_available() will re-probe."""
    global _proxy_disabled, _proxy_disabled_since
    if _proxy_disabled:
        logger.info(
            "reset_proxy_disabled: clearing flag (disabled since %.1f)",
            _proxy_disabled_since,
        )
        _proxy_disabled = False
        _proxy_disabled_since = 0.0


def get_proxy_status() -> dict:
    """Current LLM proxy health state. seconds_until_retry is 0.0 if not disabled."""
    now = time.monotonic()
    retry_at = (
        (_proxy_disabled_since + _PROXY_RETRY_INTERVAL) if _proxy_disabled else 0.0
    )
    return {
        "proxy_url": _get_proxy_url(),
        "disabled": _proxy_disabled,
        "seconds_until_retry": max(0.0, retry_at - now) if _proxy_disabled else 0.0,
    }


class TokenUsage(BaseModel):
    """Token usage from an LLM call."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost_usd: float = 0.0


def _extract_usage(resp: Any) -> TokenUsage:
    """Extract token usage from a LiteLLM response."""
    usage = getattr(resp, "usage", None)
    if usage is None:
        return TokenUsage()

    prompt = getattr(usage, "prompt_tokens", 0) or 0
    completion = getattr(usage, "completion_tokens", 0) or 0
    total = getattr(usage, "total_tokens", 0) or (prompt + completion)

    # LiteLLM tracks cost via response._hidden_params or litellm.completion_cost
    cost = 0.0
    try:
        cost = litellm.completion_cost(completion_response=resp) or 0.0
    except Exception:
        pass

    return TokenUsage(
        prompt_tokens=prompt,
        completion_tokens=completion,
        total_tokens=total,
        cost_usd=cost,
    )


def _completion_with_fallback(**kwargs: Any) -> Any:
    """Call litellm.completion, trying proxy first if configured.

    If AIRLOCK_PROXY_URL is set, routes through the proxy. On connection
    error, falls back to direct provider access (no api_base).
    Injects reasoning_effort if set at runtime.
    """
    effort = _get_reasoning_effort()
    if effort and "reasoning_effort" not in kwargs:
        kwargs["reasoning_effort"] = effort
        # Anthropic requires temperature=1 when thinking is enabled
        kwargs["temperature"] = 1

    # Default timeout: 120s to prevent indefinite hangs.
    # Extracted before proxy_kwargs so drop_params=True cannot strip it.
    call_timeout = kwargs.pop("timeout", 120)

    global _proxy_disabled, _proxy_disabled_since
    proxy_url = _get_proxy_url() if not _proxy_disabled else None
    if proxy_url:
        proxy_key = _get_proxy_key()
        proxy_kwargs = {
            **kwargs,
            "api_base": proxy_url,
            "drop_params": True,
            "timeout": call_timeout,
        }
        # Remap to proxy alias so router metadata is fully populated.
        # Use openai/ prefix since proxy speaks OpenAI-compatible protocol.
        model = proxy_kwargs.get("model", "")
        proxy_kwargs["model"] = _PROXY_MODEL_MAP.get(model, model)
        if proxy_key:
            proxy_kwargs["api_key"] = proxy_key
        extra_headers = _get_proxy_extra_headers()
        if extra_headers:
            proxy_kwargs["extra_headers"] = {
                **proxy_kwargs.get("extra_headers", {}),
                **extra_headers,
            }
        try:
            t0 = time.monotonic()
            result = litellm.completion(**proxy_kwargs)
            logger.debug("LLM proxy call completed in %.1fs", time.monotonic() - t0)
            return result
        except Exception as exc:
            if _is_proxy_error(exc):
                _proxy_disabled = True
                _proxy_disabled_since = time.monotonic()
                logger.warning(
                    "LLM proxy error (%s), will retry in %ds",
                    exc,
                    int(_PROXY_RETRY_INTERVAL),
                )
            else:
                raise
    t0 = time.monotonic()
    result = litellm.completion(**kwargs, timeout=call_timeout)
    logger.debug("LLM direct call completed in %.1fs", time.monotonic() - t0)
    return result


def chat(
    messages: list[dict[str, str]],
    *,
    model: str | None = None,
    temperature: float = 0.7,
    max_tokens: int = 2048,
) -> str:
    """Standard LLM completion. Returns assistant message content."""
    resp = _completion_with_fallback(
        model=model or _get_response_model(),
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    return resp.choices[0].message.content or ""


def chat_with_usage(
    messages: list[dict[str, str]],
    *,
    model: str | None = None,
    temperature: float = 0.7,
    max_tokens: int = 2048,
) -> tuple[str, TokenUsage]:
    """Standard LLM completion. Returns (content, token_usage)."""
    resp = _completion_with_fallback(
        model=model or _get_response_model(),
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    return resp.choices[0].message.content or "", _extract_usage(resp)


def chat_structured(
    messages: list[dict[str, str]],
    schema: type[T],
    *,
    model: str | None = None,
    temperature: float = 0.0,
    max_tokens: int = 1024,
) -> T:
    """LLM completion with forced structured output matching a Pydantic schema.

    Uses LiteLLM's response_format with json_schema to force structured output,
    then validates against the Pydantic model.
    """
    result, _ = chat_structured_with_usage(
        messages,
        schema,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    return result


def chat_structured_with_usage(
    messages: list[dict[str, str]],
    schema: type[T],
    *,
    model: str | None = None,
    temperature: float = 0.0,
    max_tokens: int = 1024,
) -> tuple[T, TokenUsage]:
    """LLM completion with structured output. Returns (result, token_usage)."""
    json_schema = schema.model_json_schema()

    resp = _completion_with_fallback(
        model=model or _get_cheap_model(),
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
        response_format={
            "type": "json_schema",
            "json_schema": {
                "name": schema.__name__,
                "schema": json_schema,
                "strict": False,
            },
        },
    )
    raw = resp.choices[0].message.content or "{}"
    data = json.loads(raw)
    return schema.model_validate(data), _extract_usage(resp)


def chat_streaming(
    messages: list[dict[str, str]],
    *,
    model: str | None = None,
    temperature: float = 0.7,
    max_tokens: int = 2048,
    on_token: Any = None,
) -> tuple[str, TokenUsage]:
    """Streaming LLM completion. Calls on_token(chunk) for each text chunk.

    Returns (full_content, token_usage).
    """
    if on_token is None:
        return chat_with_usage(
            messages, model=model, temperature=temperature, max_tokens=max_tokens
        )

    global _proxy_disabled, _proxy_disabled_since
    proxy_url = _get_proxy_url() if not _proxy_disabled else None
    kwargs: dict[str, Any] = {
        "model": model or _get_response_model(),
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": True,
    }
    effort = _get_reasoning_effort()
    if effort:
        kwargs["reasoning_effort"] = effort
        kwargs["temperature"] = 1  # Required by Anthropic with thinking enabled
    call_kwargs = kwargs
    if proxy_url:
        proxy_key = _get_proxy_key()
        call_kwargs = {**kwargs, "api_base": proxy_url, "drop_params": True}
        call_kwargs["model"] = _PROXY_MODEL_MAP.get(
            call_kwargs["model"], call_kwargs["model"]
        )
        if proxy_key:
            call_kwargs["api_key"] = proxy_key
        extra_headers = _get_proxy_extra_headers()
        if extra_headers:
            call_kwargs["extra_headers"] = {
                **call_kwargs.get("extra_headers", {}),
                **extra_headers,
            }

    accumulated = ""
    final_usage = TokenUsage()

    try:
        resp = litellm.completion(**call_kwargs)
        for chunk in resp:
            delta = chunk.choices[0].delta if chunk.choices else None
            if delta and delta.content:
                accumulated += delta.content
                try:
                    on_token(delta.content)
                except TurnCancelled:
                    raise
                except Exception:
                    pass
            # Extract usage from final chunk
            usage = getattr(chunk, "usage", None)
            if usage:
                final_usage = _extract_usage(chunk)
    except TurnCancelled:
        raise
    except Exception as exc:
        if proxy_url and _is_proxy_error(exc):
            _proxy_disabled = True
            _proxy_disabled_since = time.monotonic()
            logger.warning(
                "LLM proxy error (%s), will retry in %ds",
                exc,
                int(_PROXY_RETRY_INTERVAL),
            )
            content, usage = chat_with_usage(
                messages, model=model, temperature=temperature, max_tokens=max_tokens
            )
            # Deliver full content to callback since streaming wasn't possible
            if on_token is not None and content:
                try:
                    on_token(content)
                except TurnCancelled:
                    raise
                except Exception:
                    pass
            return content, usage
        raise

    # If streaming didn't provide usage, estimate from accumulated text
    if final_usage.total_tokens == 0 and accumulated:
        # Rough estimate: 1 token ≈ 4 chars
        est_completion = max(1, len(accumulated) // 4)
        final_usage = TokenUsage(
            completion_tokens=est_completion, total_tokens=est_completion
        )

    return accumulated, final_usage


def chat_with_tools_streaming(
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]],
    *,
    model: str | None = None,
    temperature: float = 0.7,
    max_tokens: int = 4096,
    on_token: Any = None,
) -> tuple[str, list[dict[str, Any]], TokenUsage]:
    """Tool-use LLM completion with on_token delivery for text responses.

    Tool calls require the full response to parse, so this always does a
    non-streaming call. When the final response is text-only (no tool_calls),
    it delivers the content via on_token for display.

    Returns (content, tool_calls, usage).
    """
    content, tool_calls, usage = chat_with_tools_and_usage(
        messages,
        tools,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    # Deliver text to callback when there are no tool calls (final response)
    if on_token is not None and content and not tool_calls:
        try:
            on_token(content)
        except TurnCancelled:
            raise
        except Exception:
            pass
    return content, tool_calls, usage


def chat_with_tools(
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]],
    *,
    model: str | None = None,
    temperature: float = 0.7,
    max_tokens: int = 4096,
) -> tuple[str, list[dict[str, Any]]]:
    """LLM completion with tool-use support.

    Returns (content, tool_calls) where tool_calls is a list of
    {"id": str, "name": str, "arguments": dict}.
    """
    content, tool_calls, _ = chat_with_tools_and_usage(
        messages,
        tools,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    return content, tool_calls


def chat_with_tools_and_usage(
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]],
    *,
    model: str | None = None,
    temperature: float = 0.7,
    max_tokens: int = 4096,
) -> tuple[str, list[dict[str, Any]], TokenUsage]:
    """LLM completion with tool-use support. Returns (content, tool_calls, usage).

    Detects truncation via finish_reason=length or failed argument JSON parsing,
    and automatically retries once with doubled max_tokens.
    """
    if not tools:
        content, usage = chat_with_usage(
            messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return content, [], usage

    # Build a lookup of required params per tool for truncation detection
    _required_params: dict[str, set[str]] = {}
    for t in tools:
        fn = t.get("function", {})
        params = fn.get("parameters", {})
        _required_params[fn.get("name", "")] = set(params.get("required", []))

    current_max = max_tokens
    cumulative_usage = TokenUsage()

    for attempt in range(2):  # At most one retry
        resp = _completion_with_fallback(
            model=model or _get_response_model(),
            messages=messages,
            tools=tools,
            temperature=temperature,
            max_tokens=current_max,
        )
        usage = _extract_usage(resp)
        cumulative_usage = TokenUsage(
            prompt_tokens=cumulative_usage.prompt_tokens + usage.prompt_tokens,
            completion_tokens=cumulative_usage.completion_tokens
            + usage.completion_tokens,
            cost_usd=cumulative_usage.cost_usd + usage.cost_usd,
        )

        if not resp.choices:
            return "", [], cumulative_usage

        choice = resp.choices[0]
        finish_reason = getattr(choice, "finish_reason", None)

        # Parse tool calls and detect truncation
        msg = choice.message
        content = msg.content or ""
        tool_calls: list[dict[str, Any]] = []
        has_parse_failure = False

        if msg.tool_calls:
            for tc in msg.tool_calls:
                args = tc.function.arguments
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        has_parse_failure = True
                        logger.warning(
                            "Failed to parse tool call arguments for %s "
                            "(truncated response, attempt %d). "
                            "Raw args (%d chars): %s",
                            tc.function.name,
                            attempt + 1,
                            len(args),
                            args[:200],
                        )
                        args = {}

                parsed_args = args if isinstance(args, dict) else {}

                # Check for missing required parameters (another truncation signal)
                required = _required_params.get(tc.function.name, set())
                if required and not required.issubset(parsed_args.keys()):
                    missing = required - parsed_args.keys()
                    has_parse_failure = True
                    logger.warning(
                        "Tool call %s missing required params %s (truncated response, attempt %d)",
                        tc.function.name,
                        missing,
                        attempt + 1,
                    )

                tool_calls.append(
                    {
                        "id": tc.id,
                        "name": tc.function.name,
                        "arguments": parsed_args,
                    }
                )

        # Retry if truncated: explicit finish_reason OR detected parse failures
        truncated = finish_reason == "length" or has_parse_failure
        if truncated and attempt == 0:
            retry_max = min(current_max * 2, 16384)
            logger.warning(
                "LLM response appears truncated (finish_reason=%s, parse_failure=%s, "
                "max_tokens=%d) — retrying with max_tokens=%d",
                finish_reason,
                has_parse_failure,
                current_max,
                retry_max,
            )
            current_max = retry_max
            tool_calls.clear()
            continue

        if truncated:
            logger.warning(
                "LLM response still truncated after retry (max_tokens=%d)",
                current_max,
            )
        break

    return content, tool_calls, cumulative_usage
