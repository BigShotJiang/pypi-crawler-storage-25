"""SOUL.md and CONSTITUTION.md loader for system prompt governance."""

from __future__ import annotations

from pathlib import Path

# Keywords that suggest a potential constitutional violation (fast pre-filter).
_VIOLATION_KEYWORDS = [
    "weapon",
    "mass harm",
    "impersonate",
    "fabricate citation",
    "sexual content",
    "deceive",
]


def load_governance(project_root: Path | None = None) -> str:
    """Load CONSTITUTION.md and SOUL.md, returning combined system prompt prefix.

    CONSTITUTION comes first (highest priority), then SOUL.
    Missing files are silently skipped — governance is optional until
    the user creates these files.
    """
    root = project_root or Path.cwd()
    parts: list[str] = []

    constitution = root / "CONSTITUTION.md"
    if constitution.exists():
        parts.append(constitution.read_text().strip())

    soul = root / "SOUL.md"
    if soul.exists():
        parts.append(soul.read_text().strip())

    return "\n\n---\n\n".join(parts)


def load_project_file(
    filename: str,
    project_root: Path | None = None,
    *,
    default: str | None = None,
) -> str | None:
    """Load and strip a text file from the project root.

    Returns the stripped file content, or *default* if the file is absent.
    """
    root = project_root or Path.cwd()
    path = root / filename
    if path.exists():
        return path.read_text().strip()
    return default


def load_identity(project_root: Path | None = None) -> str | None:
    """Load IDENTITY.md if it exists. Returns None if absent (triggers fallback)."""
    return load_project_file("IDENTITY.md", project_root)


def load_documentation(project_root: Path | None = None) -> str | None:
    """Load DOCUMENTATION.md if it exists. Returns None if absent."""
    return load_project_file("DOCUMENTATION.md", project_root)


def check_constitutional_violation(text: str) -> list[str]:
    """Fast keyword pre-filter for potential constitutional violations.

    Returns list of matched keywords. This is NOT a substitute for LLM judgment —
    it's a cheap early warning that something might need closer review.
    """
    text_lower = text.lower()
    return [kw for kw in _VIOLATION_KEYWORDS if kw in text_lower]
